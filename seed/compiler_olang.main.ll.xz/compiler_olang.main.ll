; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/olang:CommandLine" = type { i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, i1, { i64, ptr } }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/build:Config" = type { { i64, ptr }, { i64, ptr }, %"compiler/target:Target", %"compiler/cond:Consts", i1, i1, i1, i1, i1, i1, i64, i1, i1, { i64, ptr }, { i64, ptr }, i64, i64, i1, { i64, ptr }, { i64, ptr } }
%"compiler/target:Target" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i1, i1 }
%"compiler/cond:Consts" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/os:FileInfo" = type { i32, i64, i64 }
%"compiler/build:Unit" = type { { i64, ptr }, i32, { i64, ptr }, { i64, ptr } }
%"compiler/emit:Object" = type { { i64, ptr }, i32, { i64, ptr }, i64 }
%"compiler/emit:Emitter" = type { ptr, ptr, ptr, ptr, i1, i1, i1, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i64, i1, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, i64, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i1, i1, { i64, ptr }, i1, i64, i64, i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/build:Program" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/lower:Gap" = type { i64, %"compiler/source:Span", { i64, ptr } }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/emit:Reused" = type { i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64 }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, { i64, [3 x i64] }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/lower:Lowerer" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i32, i32, i32 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr } }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, ptr, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/scope:Scoper" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { ptr, ptr }, { ptr, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, i64, i1, %"compiler/typed:Plan", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, [2 x i64] }, i1, %"compiler/source:Span", { i64, [2 x i64] }, i1, { i64, [2 x i64] }, i1, i1, i1, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, [2 x i64] }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i64, { i64, [2 x i64] }, i1, i1, i1, i64, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i64, i32, i1, i1, i1, i1, i64, %"compiler/source:Span" }
%"compiler/typed:Plan" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/interp:Exec" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i32, %"compiler/lower:Lowerer", %"compiler/eval:Machine", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"compiler/eval:Machine" = type { ptr, i32, i64, i64, i64, i64, i64, i64, %"compiler/eval:Ptr", i32, { i64, [5 x i64] }, i1, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, i64, { i64, ptr }, { i64, ptr }, i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i64, { i64, ptr }, i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i64, i64, { i64, ptr }, i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/source:Span", i32 }
%"compiler/eval:Ptr" = type { i64, i64 }
%"compiler/fetch:Fetcher" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/source:Names" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/olang:Passes" = type { i64 }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/types:Table" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/load:Import" = type { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, { i64, ptr }, i64, i64 }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"std/prelude/text:LineIter" = type { { i64, ptr }, i64 }
@G_2ecompiler_2folang_2eBuild = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eCompile = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eDoc = constant <{ [8 x i8] }> <{ [8 x i8] c"\08\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eExplain = constant <{ [8 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eFix = constant <{ [8 x i8] }> <{ [8 x i8] c"\0B\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eFormat = constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eHelp = constant <{ [8 x i8] }> <{ [8 x i8] c"\07\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eInterp = constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eLsp = constant <{ [8 x i8] }> <{ [8 x i8] c"\09\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eMcp = constant <{ [8 x i8] }> <{ [8 x i8] c"\0A\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eModeUsage = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\2A\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeUsage.k1, [8 x i8] c"\22\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeUsage.k2, [8 x i8] c"\24\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeUsage.k3, [8 x i8] c"\24\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeUsage.k4, [8 x i8] c"\34\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeUsage.k5, [8 x i8] c"\26\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeUsage.k6, [8 x i8] c"\24\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeUsage.k7, [8 x i8] c"\11\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeUsage.k8, [8 x i8] c"\43\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeUsage.k9, [8 x i8] c"\15\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeUsage.k10, [8 x i8] c"\15\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeUsage.k11, [8 x i8] c"\27\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeUsage.k12 }>, align 64
@G_2ecompiler_2folang_2eModeUsage.k1 = internal constant <{ [42 x i8] }> <{ [42 x i8] c"\6F\6C\61\6E\67\20\5B\4F\50\54\49\4F\4E\2E\2E\2E\5D\20\46\49\4C\45\2E\6F\6C\61\6E\67\20\5B\41\52\47\55\4D\45\4E\54\2E\2E\2E\5D" }>, align 32
@G_2ecompiler_2folang_2eModeUsage.k2 = internal constant <{ [34 x i8] }> <{ [34 x i8] c"\6F\6C\61\6E\67\20\62\75\69\6C\64\20\5B\4F\50\54\49\4F\4E\2E\2E\2E\5D\20\46\49\4C\45\2E\6F\6C\61\6E\67" }>, align 32
@G_2ecompiler_2folang_2eModeUsage.k3 = internal constant <{ [36 x i8] }> <{ [36 x i8] c"\6F\6C\61\6E\67\20\63\6F\6D\70\69\6C\65\20\5B\4F\50\54\49\4F\4E\2E\2E\2E\5D\20\46\49\4C\45\2E\6F\6C\61\6E\67" }>, align 32
@G_2ecompiler_2folang_2eModeUsage.k4 = internal constant <{ [36 x i8] }> <{ [36 x i8] c"\6F\6C\61\6E\67\20\74\65\73\74\20\5B\4F\50\54\49\4F\4E\2E\2E\2E\5D\20\46\49\4C\45\2E\6F\6C\61\6E\67\2E\2E\2E" }>, align 32
@G_2ecompiler_2folang_2eModeUsage.k5 = internal constant <{ [52 x i8] }> <{ [52 x i8] c"\6F\6C\61\6E\67\20\69\6E\74\65\72\70\72\65\74\20\5B\4F\50\54\49\4F\4E\2E\2E\2E\5D\20\46\49\4C\45\2E\6F\6C\61\6E\67\20\5B\41\52\47\55\4D\45\4E\54\2E\2E\2E\5D" }>, align 32
@G_2ecompiler_2folang_2eModeUsage.k6 = internal constant <{ [38 x i8] }> <{ [38 x i8] c"\6F\6C\61\6E\67\20\66\6F\72\6D\61\74\20\5B\4F\50\54\49\4F\4E\2E\2E\2E\5D\20\46\49\4C\45\2E\6F\6C\61\6E\67\2E\2E\2E" }>, align 32
@G_2ecompiler_2folang_2eModeUsage.k7 = internal constant <{ [36 x i8] }> <{ [36 x i8] c"\6F\6C\61\6E\67\20\65\78\70\6C\61\69\6E\20\52\55\4C\45\20\7C\20\46\49\4C\45\2E\6F\6C\61\6E\67\20\4E\41\4D\45" }>, align 32
@G_2ecompiler_2folang_2eModeUsage.k8 = internal constant <{ [17 x i8] }> <{ [17 x i8] c"\6F\6C\61\6E\67\20\68\65\6C\70\20\5B\4D\4F\44\45\5D" }>, align 8
@G_2ecompiler_2folang_2eModeUsage.k9 = internal constant <{ [67 x i8] }> <{ [67 x i8] c"\6F\6C\61\6E\67\20\64\6F\63\20\5B\4F\50\54\49\4F\4E\2E\2E\2E\5D\20\46\49\4C\45\2E\6F\6C\61\6E\67\20\5B\4E\41\4D\45\5D\20\7C\20\2D\68\74\6D\6C\20\44\49\52\20\5B\46\49\4C\45\2E\6F\6C\61\6E\67\2E\2E\2E\5D" }>, align 64
@G_2ecompiler_2folang_2eModeUsage.k10 = internal constant <{ [21 x i8] }> <{ [21 x i8] c"\6F\6C\61\6E\67\20\6C\73\70\20\5B\4F\50\54\49\4F\4E\2E\2E\2E\5D" }>, align 8
@G_2ecompiler_2folang_2eModeUsage.k11 = internal constant <{ [21 x i8] }> <{ [21 x i8] c"\6F\6C\61\6E\67\20\6D\63\70\20\5B\4F\50\54\49\4F\4E\2E\2E\2E\5D" }>, align 8
@G_2ecompiler_2folang_2eModeUsage.k12 = internal constant <{ [39 x i8] }> <{ [39 x i8] c"\6F\6C\61\6E\67\20\66\69\78\20\5B\4F\50\54\49\4F\4E\2E\2E\2E\5D\20\46\49\4C\45\2E\6F\6C\61\6E\67\7C\44\49\52\2E\2E\2E" }>, align 32
@G_2ecompiler_2folang_2eModeWhat = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\6A\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWhat.k1, [8 x i8] c"\40\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWhat.k2, [8 x i8] c"\36\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWhat.k3, [8 x i8] c"\3E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWhat.k4, [8 x i8] c"\6E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWhat.k5, [8 x i8] c"\2E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWhat.k6, [8 x i8] c"\5D\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWhat.k7, [8 x i8] c"\24\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWhat.k8, [8 x i8] c"\44\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWhat.k9, [8 x i8] c"\57\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWhat.k10, [8 x i8] c"\54\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWhat.k11, [8 x i8] c"\74\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWhat.k12 }>, align 64
@G_2ecompiler_2folang_2eModeWhat.k1 = internal constant <{ [106 x i8] }> <{ [106 x i8] c"\62\75\69\6C\64\73\20\74\68\65\20\70\72\6F\67\72\61\6D\20\46\49\4C\45\2E\6F\6C\61\6E\67\20\69\73\20\74\68\65\20\72\6F\6F\74\20\6F\66\2C\20\61\73\20\62\75\69\6C\64\20\64\6F\65\73\2C\20\61\6E\64\20\72\75\6E\73\20\69\74\20\77\69\74\68\20\74\68\65\20\61\72\67\75\6D\65\6E\74\73\20\61\66\74\65\72\20\74\68\65\20\66\69\6C\65" }>, align 64
@G_2ecompiler_2folang_2eModeWhat.k2 = internal constant <{ [64 x i8] }> <{ [64 x i8] c"\62\75\69\6C\64\73\20\6F\6E\65\20\70\72\6F\67\72\61\6D\2C\20\46\49\4C\45\2E\6F\6C\61\6E\67\20\69\74\73\20\72\6F\6F\74\20\6D\6F\64\75\6C\65\2C\20\69\6E\74\6F\20\62\75\69\6C\64\2F\20\28\42\33\29" }>, align 64
@G_2ecompiler_2folang_2eModeWhat.k3 = internal constant <{ [54 x i8] }> <{ [54 x i8] c"\63\6F\6D\70\69\6C\65\73\20\6F\6E\65\20\6D\6F\64\75\6C\65\20\74\6F\20\61\6E\20\6F\62\6A\65\63\74\2C\20\6C\69\6E\6B\69\6E\67\20\6E\6F\74\68\69\6E\67\20\28\42\32\29" }>, align 32
@G_2ecompiler_2folang_2eModeWhat.k4 = internal constant <{ [62 x i8] }> <{ [62 x i8] c"\72\75\6E\73\20\65\61\63\68\20\66\69\6C\65\27\73\20\74\65\73\74\20\62\6C\6F\63\6B\73\2C\20\65\61\63\68\20\66\69\6C\65\20\62\75\69\6C\74\20\6F\6E\20\69\74\73\20\6F\77\6E\20\28\42\33\61\29" }>, align 32
@G_2ecompiler_2folang_2eModeWhat.k5 = internal constant <{ [110 x i8] }> <{ [110 x i8] c"\72\75\6E\73\20\74\68\65\20\70\72\6F\67\72\61\6D\20\62\79\20\63\6F\6D\70\69\6C\65\2D\74\69\6D\65\20\65\76\61\6C\75\61\74\69\6F\6E\20\69\6E\73\74\65\61\64\20\6F\66\20\62\75\69\6C\64\69\6E\67\20\69\74\2C\20\74\68\65\20\61\72\67\75\6D\65\6E\74\73\20\61\66\74\65\72\20\74\68\65\20\66\69\6C\65\20\69\74\73\20\6F\77\6E\20\28\42\33\65\29" }>, align 64
@G_2ecompiler_2folang_2eModeWhat.k6 = internal constant <{ [46 x i8] }> <{ [46 x i8] c"\72\65\77\72\69\74\65\73\20\65\61\63\68\20\66\69\6C\65\20\69\6E\20\6F\6C\61\6E\67\27\73\20\6F\6E\65\20\6C\61\79\6F\75\74\20\28\42\31\33\29" }>, align 32
@G_2ecompiler_2folang_2eModeWhat.k7 = internal constant <{ [93 x i8] }> <{ [93 x i8] c"\70\72\69\6E\74\73\20\61\20\72\75\6C\65\20\6F\66\20\74\68\65\20\73\70\65\63\69\66\69\63\61\74\69\6F\6E\20\28\42\31\31\61\29\2C\20\6F\72\20\61\20\74\6F\70\2D\6C\65\76\65\6C\20\69\74\65\6D\20\61\73\20\74\68\65\20\63\6F\6D\70\69\6C\65\72\20\73\65\65\73\20\69\74\20\28\42\31\31\62\29" }>, align 64
@G_2ecompiler_2folang_2eModeWhat.k8 = internal constant <{ [36 x i8] }> <{ [36 x i8] c"\6C\69\73\74\73\20\74\68\65\20\6D\6F\64\65\73\2C\20\6F\72\20\61\20\6D\6F\64\65\27\73\20\6F\70\74\69\6F\6E\73" }>, align 32
@G_2ecompiler_2folang_2eModeWhat.k9 = internal constant <{ [68 x i8] }> <{ [68 x i8] c"\70\72\69\6E\74\73\20\61\20\6D\6F\64\75\6C\65\27\73\20\64\6F\63\75\6D\65\6E\74\61\74\69\6F\6E\20\28\42\31\34\29\2C\20\6F\72\20\77\72\69\74\65\73\20\61\20\6C\69\62\72\61\72\79\27\73\20\61\73\20\48\54\4D\4C" }>, align 64
@G_2ecompiler_2folang_2eModeWhat.k10 = internal constant <{ [87 x i8] }> <{ [87 x i8] c"\73\65\72\76\65\73\20\74\68\65\20\4C\61\6E\67\75\61\67\65\20\53\65\72\76\65\72\20\50\72\6F\74\6F\63\6F\6C\20\6F\6E\20\74\68\65\20\73\74\61\6E\64\61\72\64\20\69\6E\70\75\74\20\61\6E\64\20\6F\75\74\70\75\74\2C\20\66\6F\72\20\65\64\69\74\6F\72\73\20\28\42\31\35\29" }>, align 64
@G_2ecompiler_2folang_2eModeWhat.k11 = internal constant <{ [84 x i8] }> <{ [84 x i8] c"\73\65\72\76\65\73\20\74\68\65\20\4D\6F\64\65\6C\20\43\6F\6E\74\65\78\74\20\50\72\6F\74\6F\63\6F\6C\20\6F\6E\20\74\68\65\20\73\74\61\6E\64\61\72\64\20\69\6E\70\75\74\20\61\6E\64\20\6F\75\74\70\75\74\2C\20\66\6F\72\20\61\67\65\6E\74\73\20\28\42\31\36\29" }>, align 64
@G_2ecompiler_2folang_2eModeWhat.k12 = internal constant <{ [116 x i8] }> <{ [116 x i8] c"\72\65\77\72\69\74\65\73\20\6F\6C\64\20\63\6F\64\65\20\74\6F\20\74\68\65\20\6C\61\6E\67\75\61\67\65\20\6F\66\20\74\6F\64\61\79\3A\20\65\76\65\72\79\20\6D\69\67\72\61\74\69\6F\6E\20\74\6F\6F\6C\20\6F\66\20\74\6F\6F\6C\73\2F\2C\20\69\6E\20\74\68\65\20\6F\72\64\65\72\20\74\68\65\20\63\68\61\6E\67\65\73\20\77\65\72\65\20\6D\61\64\65\20\28\42\31\37\29" }>, align 64
@G_2ecompiler_2folang_2eModeWords = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWords.k1, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWords.k2, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWords.k3, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWords.k4, [8 x i8] c"\09\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWords.k5, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWords.k6, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWords.k7, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWords.k8, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWords.k9, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWords.k10, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWords.k11, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWords.k12 }>, align 64
@G_2ecompiler_2folang_2eModeWords.k1 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2folang_2eModeWords.k2 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\62\75\69\6C\64" }>, align 8
@G_2ecompiler_2folang_2eModeWords.k3 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\63\6F\6D\70\69\6C\65" }>, align 8
@G_2ecompiler_2folang_2eModeWords.k4 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\74\65\73\74" }>, align 8
@G_2ecompiler_2folang_2eModeWords.k5 = internal constant <{ [9 x i8] }> <{ [9 x i8] c"\69\6E\74\65\72\70\72\65\74" }>, align 8
@G_2ecompiler_2folang_2eModeWords.k6 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\66\6F\72\6D\61\74" }>, align 8
@G_2ecompiler_2folang_2eModeWords.k7 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\65\78\70\6C\61\69\6E" }>, align 8
@G_2ecompiler_2folang_2eModeWords.k8 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\68\65\6C\70" }>, align 8
@G_2ecompiler_2folang_2eModeWords.k9 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\64\6F\63" }>, align 8
@G_2ecompiler_2folang_2eModeWords.k10 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\6C\73\70" }>, align 8
@G_2ecompiler_2folang_2eModeWords.k11 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\6D\63\70" }>, align 8
@G_2ecompiler_2folang_2eModeWords.k12 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\66\69\78" }>, align 8
@G_2ecompiler_2folang_2eOptModes = constant <{ [80 x i8] }> <{ [80 x i8] c"\06\00\00\00\00\00\00\00\0F\00\00\00\00\00\00\00\0F\00\00\00\00\00\00\00\0F\00\00\00\00\00\00\00\5F\07\00\00\00\00\00\00\5F\07\00\00\00\00\00\00\5F\07\00\00\00\00\00\00\20\08\00\00\00\00\00\00\0F\00\00\00\00\00\00\00\00\01\00\00\00\00\00\00" }>, align 64
@G_2ecompiler_2folang_2eOptValues = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptValues.k1, [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptValues.k2, [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptValues.k3, [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptValues.k4, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptValues.k5, [8 x i8] c"\0A\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptValues.k6, [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptValues.k7, [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptValues.k8, [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptValues.k9, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptValues.k10 }>, align 64
@G_2ecompiler_2folang_2eOptValues.k1 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\50\41\54\48" }>, align 8
@G_2ecompiler_2folang_2eOptValues.k2 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2folang_2eOptValues.k3 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2folang_2eOptValues.k4 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2folang_2eOptValues.k5 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\4E\41\4D\45" }>, align 8
@G_2ecompiler_2folang_2eOptValues.k6 = internal constant <{ [10 x i8] }> <{ [10 x i8] c"\4E\61\6D\65\3D\76\61\6C\75\65" }>, align 8
@G_2ecompiler_2folang_2eOptValues.k7 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2folang_2eOptValues.k8 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2folang_2eOptValues.k9 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2folang_2eOptValues.k10 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\44\49\52" }>, align 8
@G_2ecompiler_2folang_2eOptWhat = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\31\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWhat.k1, [8 x i8] c"\35\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWhat.k2, [8 x i8] c"\28\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWhat.k3, [8 x i8] c"\25\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWhat.k4, [8 x i8] c"\20\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWhat.k5, [8 x i8] c"\1E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWhat.k6, [8 x i8] c"\55\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWhat.k7, [8 x i8] c"\59\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWhat.k8, [8 x i8] c"\60\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWhat.k9, [8 x i8] c"\6D\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWhat.k10 }>, align 64
@G_2ecompiler_2folang_2eOptWhat.k1 = internal constant <{ [49 x i8] }> <{ [49 x i8] c"\77\72\69\74\65\73\20\74\68\65\20\65\78\65\63\75\74\61\62\6C\65\20\6F\72\20\74\68\65\20\6F\62\6A\65\63\74\20\74\6F\20\50\41\54\48\20\28\42\33\68\29" }>, align 32
@G_2ecompiler_2folang_2eOptWhat.k2 = internal constant <{ [53 x i8] }> <{ [53 x i8] c"\62\75\69\6C\64\73\20\75\6E\6F\70\74\69\6D\69\7A\65\64\2C\20\77\69\74\68\20\64\65\62\75\67\20\69\6E\66\6F\72\6D\61\74\69\6F\6E\20\28\42\32\63\2C\20\42\32\65\29" }>, align 32
@G_2ecompiler_2folang_2eOptWhat.k3 = internal constant <{ [40 x i8] }> <{ [40 x i8] c"\62\75\69\6C\64\73\20\77\69\74\68\20\74\68\65\20\64\61\74\61\20\72\61\63\65\20\64\65\74\65\63\74\6F\72\20\28\42\32\62\29" }>, align 32
@G_2ecompiler_2folang_2eOptWhat.k4 = internal constant <{ [37 x i8] }> <{ [37 x i8] c"\62\75\69\6C\64\73\20\77\69\74\68\20\74\68\65\20\73\63\6F\70\65\20\73\61\6E\69\74\69\7A\65\72\20\28\42\32\66\29" }>, align 32
@G_2ecompiler_2folang_2eOptWhat.k5 = internal constant <{ [32 x i8] }> <{ [32 x i8] c"\62\75\69\6C\64\73\20\66\6F\72\20\61\6E\6F\74\68\65\72\20\6D\61\63\68\69\6E\65\20\28\42\31\32\29" }>, align 32
@G_2ecompiler_2folang_2eOptWhat.k6 = internal constant <{ [30 x i8] }> <{ [30 x i8] c"\64\65\66\69\6E\65\73\20\61\20\62\75\69\6C\64\20\63\6F\6E\73\74\61\6E\74\20\28\42\31\30\29" }>, align 8
@G_2ecompiler_2folang_2eOptWhat.k7 = internal constant <{ [85 x i8] }> <{ [85 x i8] c"\6D\6F\76\65\73\20\74\68\65\20\72\65\6D\6F\74\65\20\72\65\70\6F\73\69\74\6F\72\69\65\73\20\74\68\65\20\62\75\69\6C\64\20\72\65\61\63\68\65\73\20\74\6F\20\74\68\65\69\72\20\72\65\66\73\27\20\63\75\72\72\65\6E\74\20\63\6F\6D\6D\69\74\73\20\28\4D\32\33\63\29" }>, align 64
@G_2ecompiler_2folang_2eOptWhat.k8 = internal constant <{ [89 x i8] }> <{ [89 x i8] c"\72\65\77\72\69\74\65\73\20\6E\6F\74\68\69\6E\67\3A\20\6C\69\73\74\73\20\65\61\63\68\20\66\69\6C\65\20\6E\6F\74\20\69\6E\20\74\68\65\20\6C\61\79\6F\75\74\20\28\42\31\33\29\2C\20\6F\72\20\74\68\61\74\20\66\69\78\20\77\6F\75\6C\64\20\63\68\61\6E\67\65\20\28\42\31\37\29" }>, align 64
@G_2ecompiler_2folang_2eOptWhat.k9 = internal constant <{ [96 x i8] }> <{ [96 x i8] c"\62\75\69\6C\64\73\20\66\6F\72\20\64\65\76\65\6C\6F\70\6D\65\6E\74\3A\20\2D\4F\32\20\77\69\74\68\6F\75\74\20\6C\69\6E\6B\2D\74\69\6D\65\20\6F\70\74\69\6D\69\7A\61\74\69\6F\6E\2C\20\66\61\73\74\65\72\20\74\6F\20\62\75\69\6C\64\2C\20\73\6C\6F\77\65\72\20\74\6F\20\72\75\6E\20\28\42\32\67\29" }>, align 64
@G_2ecompiler_2folang_2eOptWhat.k10 = internal constant <{ [109 x i8] }> <{ [109 x i8] c"\77\72\69\74\65\73\20\74\68\65\20\64\6F\63\75\6D\65\6E\74\61\74\69\6F\6E\20\61\73\20\48\54\4D\4C\20\69\6E\74\6F\20\44\49\52\2C\20\61\20\70\61\67\65\20\61\20\6D\6F\64\75\6C\65\3A\20\6F\66\20\65\61\63\68\20\46\49\4C\45\2C\20\6F\72\20\6F\66\20\73\74\64\20\77\68\65\72\65\20\6E\6F\6E\65\20\69\73\20\6E\61\6D\65\64\20\28\42\31\34\29" }>, align 64
@G_2ecompiler_2folang_2eOptWords = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWords.k1, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWords.k2, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWords.k3, [8 x i8] c"\09\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWords.k4, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWords.k5, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWords.k6, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWords.k7, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWords.k8, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWords.k9, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWords.k10 }>, align 64
@G_2ecompiler_2folang_2eOptWords.k1 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\2D\6F\75\74\70\75\74" }>, align 8
@G_2ecompiler_2folang_2eOptWords.k2 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\2D\64\65\62\75\67" }>, align 8
@G_2ecompiler_2folang_2eOptWords.k3 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\2D\72\61\63\65" }>, align 8
@G_2ecompiler_2folang_2eOptWords.k4 = internal constant <{ [9 x i8] }> <{ [9 x i8] c"\2D\73\61\6E\69\74\69\7A\65" }>, align 8
@G_2ecompiler_2folang_2eOptWords.k5 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\2D\74\61\72\67\65\74" }>, align 8
@G_2ecompiler_2folang_2eOptWords.k6 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\2D\64\65\66\69\6E\65" }>, align 8
@G_2ecompiler_2folang_2eOptWords.k7 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\2D\75\70\64\61\74\65" }>, align 8
@G_2ecompiler_2folang_2eOptWords.k8 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\2D\63\68\65\63\6B" }>, align 8
@G_2ecompiler_2folang_2eOptWords.k9 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\2D\71\75\69\63\6B" }>, align 8
@G_2ecompiler_2folang_2eOptWords.k10 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\2D\68\74\6D\6C" }>, align 8
@G_2ecompiler_2folang_2eRun = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eTest = constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eexplainedSrc = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\A7\02\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eexplainedSrc.k1 }>, align 8
@G_2ecompiler_2folang_2eexplainedSrc.k1 = internal constant <{ [679 x i8] }> <{ [679 x i8] c"\65\72\72\6F\72\20\4D\61\74\68\45\72\72\6F\72\20\7B\20\5A\45\52\4F\20\7D\0A\74\79\70\65\20\4E\20\73\74\72\75\63\74\28\76\20\49\36\34\2C\20\6E\65\78\74\20\4E\3F\26\29\20\7B\20\76\2C\20\6E\65\78\74\20\7D\0A\66\6E\20\28\6E\20\4E\26\29\20\56\61\6C\75\65\28\29\20\49\36\34\20\7B\20\72\65\74\75\72\6E\20\6E\2E\76\20\7D\0A\74\79\70\65\20\48\20\73\74\72\75\63\74\28\6E\20\4E\26\29\20\7B\20\6E\20\7D\0A\66\6E\20\77\72\61\70\28\6E\20\4E\26\29\20\48\20\7B\20\72\65\74\75\72\6E\20\48\28\6E\29\20\7D\0A\66\6E\20\64\69\76\6D\6F\64\28\61\20\49\36\34\2C\20\62\20\49\36\34\29\20\49\36\34\2C\20\49\36\34\20\3F\20\7B\0A\20\20\20\20\69\66\20\62\20\3D\3D\20\30\20\7B\20\65\72\72\6F\72\20\4D\61\74\68\45\72\72\6F\72\2E\5A\45\52\4F\20\7D\0A\20\20\20\20\72\65\74\75\72\6E\20\61\20\2F\20\62\2C\20\61\20\25\20\62\0A\7D\0A\66\6E\20\62\69\67\3C\54\3E\28\61\20\54\2C\20\62\20\54\29\20\54\20\7B\20\72\65\74\75\72\6E\20\61\20\69\66\20\61\20\3E\20\62\20\65\6C\73\65\20\62\20\7D\0A\74\79\70\65\20\53\68\20\65\6E\75\6D\20\7B\0A\20\20\20\20\57\68\6F\6C\65\20\4E\0A\20\20\20\20\50\61\72\74\73\28\61\20\49\36\34\2C\20\62\20\49\36\34\29\0A\20\20\20\20\4E\6F\6E\65\0A\7D\0A\41\6E\73\77\65\72\20\49\36\34\20\3D\20\36\20\2A\20\37\0A\66\6E\20\70\63\74\28\70\61\72\74\20\49\36\34\2C\20\77\68\6F\6C\65\20\49\36\34\29\20\70\20\49\36\34\20\5B\77\68\6F\6C\65\20\3E\20\30\2C\20\30\20\3C\3D\20\70\20\3C\3D\20\31\30\30\5D\20\7B\20\72\65\74\75\72\6E\20\70\61\72\74\20\2A\20\31\30\30\20\2F\20\77\68\6F\6C\65\20\7D\0A\66\6E\20\6C\69\6E\6B\28\61\20\6D\75\74\20\4E\26\2C\20\62\20\4E\26\29\20\5B\62\20\6F\75\74\6C\69\76\65\73\20\61\5D\20\7B\20\7D\0A\66\6E\20\6D\61\69\6E\28\29\20\3F\20\7B\0A\20\20\20\20\6E\6E\20\3A\3D\20\4E\28\70\63\74\28\31\2C\20\34\29\2C\20\6E\75\6C\6C\29\0A\20\20\20\20\6C\69\6E\6B\28\6E\6E\2C\20\6E\6E\29\0A\20\20\20\20\71\2C\20\5F\20\3A\3D\20\74\72\79\20\64\69\76\6D\6F\64\28\41\6E\73\77\65\72\2C\20\62\69\67\28\32\2C\20\33\29\29\0A\20\20\20\20\61\73\73\65\72\74\20\77\72\61\70\28\4E\28\71\2C\20\6E\75\6C\6C\29\29\2E\6E\2E\56\61\6C\75\65\28\29\20\3D\3D\20\31\34\0A\7D\0A" }>, align 64
define dso_local void @compiler_2folang_2eBuild_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 1, ptr @G_2ecompiler_2folang_2eBuild, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eCompile_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 2, ptr @G_2ecompiler_2folang_2eCompile, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eDoc_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 8, ptr @G_2ecompiler_2folang_2eDoc, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eExplain_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 6, ptr @G_2ecompiler_2folang_2eExplain, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eFix_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 11, ptr @G_2ecompiler_2folang_2eFix, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eFormat_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 5, ptr @G_2ecompiler_2folang_2eFormat, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eHelp_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 7, ptr @G_2ecompiler_2folang_2eHelp, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eInterp_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 4, ptr @G_2ecompiler_2folang_2eInterp, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eLsp_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 9, ptr @G_2ecompiler_2folang_2eLsp, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eMcp_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 10, ptr @G_2ecompiler_2folang_2eMcp, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eModeUsage_2einit() #0 {
entry:
  %l0 = alloca [12 x { i64, ptr }]
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 0
  store { i64, ptr } { i64 42, ptr @.d0 }, ptr %t1, !tbaa !37
  %t2 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 1
  store { i64, ptr } { i64 34, ptr @.d1 }, ptr %t2, !tbaa !37
  %t3 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 2
  store { i64, ptr } { i64 36, ptr @.d2 }, ptr %t3, !tbaa !37
  %t4 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 3
  store { i64, ptr } { i64 36, ptr @.d3 }, ptr %t4, !tbaa !37
  %t5 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 4
  store { i64, ptr } { i64 52, ptr @.d4 }, ptr %t5, !tbaa !37
  %t6 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 5
  store { i64, ptr } { i64 38, ptr @.d5 }, ptr %t6, !tbaa !37
  %t7 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 6
  store { i64, ptr } { i64 36, ptr @.d6 }, ptr %t7, !tbaa !37
  %t8 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 7
  store { i64, ptr } { i64 17, ptr @.d7 }, ptr %t8, !tbaa !37
  %t9 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 8
  store { i64, ptr } { i64 67, ptr @.d8 }, ptr %t9, !tbaa !37
  %t10 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 9
  store { i64, ptr } { i64 21, ptr @.d9 }, ptr %t10, !tbaa !37
  %t11 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 10
  store { i64, ptr } { i64 21, ptr @.d10 }, ptr %t11, !tbaa !37
  %t12 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 11
  store { i64, ptr } { i64 39, ptr @.d11 }, ptr %t12, !tbaa !37
  call void @llvm.memmove.p0.p0.i64(ptr @G_2ecompiler_2folang_2eModeUsage, ptr %l0, i64 192, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eModeWhat_2einit() #0 {
entry:
  %l0 = alloca [12 x { i64, ptr }]
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 0
  store { i64, ptr } { i64 106, ptr @.d12 }, ptr %t1, !tbaa !37
  %t2 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 1
  store { i64, ptr } { i64 64, ptr @.d13 }, ptr %t2, !tbaa !37
  %t3 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 2
  store { i64, ptr } { i64 54, ptr @.d14 }, ptr %t3, !tbaa !37
  %t4 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 3
  store { i64, ptr } { i64 62, ptr @.d15 }, ptr %t4, !tbaa !37
  %t5 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 4
  store { i64, ptr } { i64 110, ptr @.d16 }, ptr %t5, !tbaa !37
  %t6 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 5
  store { i64, ptr } { i64 46, ptr @.d17 }, ptr %t6, !tbaa !37
  %t7 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 6
  store { i64, ptr } { i64 93, ptr @.d18 }, ptr %t7, !tbaa !37
  %t8 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 7
  store { i64, ptr } { i64 36, ptr @.d19 }, ptr %t8, !tbaa !37
  %t9 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 8
  store { i64, ptr } { i64 68, ptr @.d20 }, ptr %t9, !tbaa !37
  %t10 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 9
  store { i64, ptr } { i64 87, ptr @.d21 }, ptr %t10, !tbaa !37
  %t11 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 10
  store { i64, ptr } { i64 84, ptr @.d22 }, ptr %t11, !tbaa !37
  %t12 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 11
  store { i64, ptr } { i64 116, ptr @.d23 }, ptr %t12, !tbaa !37
  call void @llvm.memmove.p0.p0.i64(ptr @G_2ecompiler_2folang_2eModeWhat, ptr %l0, i64 192, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eModeWords_2einit() #0 {
entry:
  %l0 = alloca [12 x { i64, ptr }]
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 0
  store { i64, ptr } { i64 0, ptr @.d24 }, ptr %t1, !tbaa !37
  %t2 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 1
  store { i64, ptr } { i64 5, ptr @.d25 }, ptr %t2, !tbaa !37
  %t3 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 2
  store { i64, ptr } { i64 7, ptr @.d26 }, ptr %t3, !tbaa !37
  %t4 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 3
  store { i64, ptr } { i64 4, ptr @.d27 }, ptr %t4, !tbaa !37
  %t5 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 4
  store { i64, ptr } { i64 9, ptr @.d28 }, ptr %t5, !tbaa !37
  %t6 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 5
  store { i64, ptr } { i64 6, ptr @.d29 }, ptr %t6, !tbaa !37
  %t7 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 6
  store { i64, ptr } { i64 7, ptr @.d30 }, ptr %t7, !tbaa !37
  %t8 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 7
  store { i64, ptr } { i64 4, ptr @.d31 }, ptr %t8, !tbaa !37
  %t9 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 8
  store { i64, ptr } { i64 3, ptr @.d32 }, ptr %t9, !tbaa !37
  %t10 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 9
  store { i64, ptr } { i64 3, ptr @.d33 }, ptr %t10, !tbaa !37
  %t11 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 10
  store { i64, ptr } { i64 3, ptr @.d34 }, ptr %t11, !tbaa !37
  %t12 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 11
  store { i64, ptr } { i64 3, ptr @.d35 }, ptr %t12, !tbaa !37
  call void @llvm.memmove.p0.p0.i64(ptr @G_2ecompiler_2folang_2eModeWords, ptr %l0, i64 192, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eOptModes_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t1 = insertvalue [10 x i64] undef, i64 6, 0
  %t2 = insertvalue [10 x i64] %t1, i64 15, 1
  %t3 = insertvalue [10 x i64] %t2, i64 15, 2
  %t4 = insertvalue [10 x i64] %t3, i64 15, 3
  %t5 = insertvalue [10 x i64] %t4, i64 1887, 4
  %t6 = insertvalue [10 x i64] %t5, i64 1887, 5
  %t7 = insertvalue [10 x i64] %t6, i64 1887, 6
  %t8 = insertvalue [10 x i64] %t7, i64 2080, 7
  %t9 = insertvalue [10 x i64] %t8, i64 15, 8
  %t10 = insertvalue [10 x i64] %t9, i64 256, 9
  store [10 x i64] %t10, ptr @G_2ecompiler_2folang_2eOptModes
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eOptValues_2einit() #0 {
entry:
  %l0 = alloca [10 x { i64, ptr }]
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr [10 x { i64, ptr }], ptr %l0, i64 0, i64 0
  store { i64, ptr } { i64 4, ptr @.d36 }, ptr %t1, !tbaa !37
  %t2 = getelementptr [10 x { i64, ptr }], ptr %l0, i64 0, i64 1
  store { i64, ptr } { i64 0, ptr @.d37 }, ptr %t2, !tbaa !37
  %t3 = getelementptr [10 x { i64, ptr }], ptr %l0, i64 0, i64 2
  store { i64, ptr } { i64 0, ptr @.d38 }, ptr %t3, !tbaa !37
  %t4 = getelementptr [10 x { i64, ptr }], ptr %l0, i64 0, i64 3
  store { i64, ptr } { i64 0, ptr @.d39 }, ptr %t4, !tbaa !37
  %t5 = getelementptr [10 x { i64, ptr }], ptr %l0, i64 0, i64 4
  store { i64, ptr } { i64 4, ptr @.d40 }, ptr %t5, !tbaa !37
  %t6 = getelementptr [10 x { i64, ptr }], ptr %l0, i64 0, i64 5
  store { i64, ptr } { i64 10, ptr @.d41 }, ptr %t6, !tbaa !37
  %t7 = getelementptr [10 x { i64, ptr }], ptr %l0, i64 0, i64 6
  store { i64, ptr } { i64 0, ptr @.d42 }, ptr %t7, !tbaa !37
  %t8 = getelementptr [10 x { i64, ptr }], ptr %l0, i64 0, i64 7
  store { i64, ptr } { i64 0, ptr @.d43 }, ptr %t8, !tbaa !37
  %t9 = getelementptr [10 x { i64, ptr }], ptr %l0, i64 0, i64 8
  store { i64, ptr } { i64 0, ptr @.d44 }, ptr %t9, !tbaa !37
  %t10 = getelementptr [10 x { i64, ptr }], ptr %l0, i64 0, i64 9
  store { i64, ptr } { i64 3, ptr @.d45 }, ptr %t10, !tbaa !37
  call void @llvm.memmove.p0.p0.i64(ptr @G_2ecompiler_2folang_2eOptValues, ptr %l0, i64 160, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eOptWhat_2einit() #0 {
entry:
  %l0 = alloca [10 x { i64, ptr }]
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr [10 x { i64, ptr }], ptr %l0, i64 0, i64 0
  store { i64, ptr } { i64 49, ptr @.d46 }, ptr %t1, !tbaa !37
  %t2 = getelementptr [10 x { i64, ptr }], ptr %l0, i64 0, i64 1
  store { i64, ptr } { i64 53, ptr @.d47 }, ptr %t2, !tbaa !37
  %t3 = getelementptr [10 x { i64, ptr }], ptr %l0, i64 0, i64 2
  store { i64, ptr } { i64 40, ptr @.d48 }, ptr %t3, !tbaa !37
  %t4 = getelementptr [10 x { i64, ptr }], ptr %l0, i64 0, i64 3
  store { i64, ptr } { i64 37, ptr @.d49 }, ptr %t4, !tbaa !37
  %t5 = getelementptr [10 x { i64, ptr }], ptr %l0, i64 0, i64 4
  store { i64, ptr } { i64 32, ptr @.d50 }, ptr %t5, !tbaa !37
  %t6 = getelementptr [10 x { i64, ptr }], ptr %l0, i64 0, i64 5
  store { i64, ptr } { i64 30, ptr @.d51 }, ptr %t6, !tbaa !37
  %t7 = getelementptr [10 x { i64, ptr }], ptr %l0, i64 0, i64 6
  store { i64, ptr } { i64 85, ptr @.d52 }, ptr %t7, !tbaa !37
  %t8 = getelementptr [10 x { i64, ptr }], ptr %l0, i64 0, i64 7
  store { i64, ptr } { i64 89, ptr @.d53 }, ptr %t8, !tbaa !37
  %t9 = getelementptr [10 x { i64, ptr }], ptr %l0, i64 0, i64 8
  store { i64, ptr } { i64 96, ptr @.d54 }, ptr %t9, !tbaa !37
  %t10 = getelementptr [10 x { i64, ptr }], ptr %l0, i64 0, i64 9
  store { i64, ptr } { i64 109, ptr @.d55 }, ptr %t10, !tbaa !37
  call void @llvm.memmove.p0.p0.i64(ptr @G_2ecompiler_2folang_2eOptWhat, ptr %l0, i64 160, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eOptWords_2einit() #0 {
entry:
  %l0 = alloca [10 x { i64, ptr }]
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr [10 x { i64, ptr }], ptr %l0, i64 0, i64 0
  store { i64, ptr } { i64 7, ptr @.d56 }, ptr %t1, !tbaa !37
  %t2 = getelementptr [10 x { i64, ptr }], ptr %l0, i64 0, i64 1
  store { i64, ptr } { i64 6, ptr @.d57 }, ptr %t2, !tbaa !37
  %t3 = getelementptr [10 x { i64, ptr }], ptr %l0, i64 0, i64 2
  store { i64, ptr } { i64 5, ptr @.d58 }, ptr %t3, !tbaa !37
  %t4 = getelementptr [10 x { i64, ptr }], ptr %l0, i64 0, i64 3
  store { i64, ptr } { i64 9, ptr @.d59 }, ptr %t4, !tbaa !37
  %t5 = getelementptr [10 x { i64, ptr }], ptr %l0, i64 0, i64 4
  store { i64, ptr } { i64 7, ptr @.d60 }, ptr %t5, !tbaa !37
  %t6 = getelementptr [10 x { i64, ptr }], ptr %l0, i64 0, i64 5
  store { i64, ptr } { i64 7, ptr @.d61 }, ptr %t6, !tbaa !37
  %t7 = getelementptr [10 x { i64, ptr }], ptr %l0, i64 0, i64 6
  store { i64, ptr } { i64 7, ptr @.d62 }, ptr %t7, !tbaa !37
  %t8 = getelementptr [10 x { i64, ptr }], ptr %l0, i64 0, i64 7
  store { i64, ptr } { i64 6, ptr @.d63 }, ptr %t8, !tbaa !37
  %t9 = getelementptr [10 x { i64, ptr }], ptr %l0, i64 0, i64 8
  store { i64, ptr } { i64 6, ptr @.d64 }, ptr %t9, !tbaa !37
  %t10 = getelementptr [10 x { i64, ptr }], ptr %l0, i64 0, i64 9
  store { i64, ptr } { i64 5, ptr @.d65 }, ptr %t10, !tbaa !37
  call void @llvm.memmove.p0.p0.i64(ptr @G_2ecompiler_2folang_2eOptWords, ptr %l0, i64 160, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local { i32, %"compiler/olang:CommandLine" } @compiler_2folang_2eParse(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l2 = alloca ptr
  %lp3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca %"compiler/olang:CommandLine"
  %l19 = alloca ptr
  %l20 = alloca %"compiler/msgs:Msg"
  %l21 = alloca i32
  %l23 = alloca { i64, ptr }
  %l25 = alloca i1
  %l27 = alloca i1
  %l28 = alloca { i64, ptr }
  %l30 = alloca i1
  %l32 = alloca { i64, ptr }
  %l34 = alloca i64
  %l37 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l40 = alloca %"compiler/msgs:Msg"
  %l41 = alloca i32
  %l49 = alloca { i64, ptr }
  %l55 = alloca i1
  %l56 = alloca [10 x { i64, ptr }]
  %l61 = alloca i64
  %l64 = alloca i64
  %l85 = alloca i1
  %l91 = alloca ptr
  %l92 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l96 = alloca %"compiler/msgs:Msg"
  %l97 = alloca i32
  %l101 = alloca i64
  %l105 = alloca ptr
  %l106 = alloca { i64, ptr }
  %l109 = alloca { i64, ptr }
  %l110 = alloca { i64, ptr }
  %l112 = alloca { i64, ptr }
  %l114 = alloca %"compiler/msgs:Msg"
  %l115 = alloca i32
  %l123 = alloca i1
  %l129 = alloca ptr
  %l133 = alloca %"compiler/msgs:Msg"
  %l134 = alloca i32
  %l136 = alloca { i64, ptr }
  %l172 = alloca i32
  %l192 = alloca i1
  %l195 = alloca i1
  %l198 = alloca ptr
  %l201 = alloca { i64, ptr }
  %l202 = alloca %"compiler/msgs:Msg"
  %l203 = alloca i32
  %l208 = alloca i1
  %l210 = alloca i1
  %l211 = alloca i1
  %l213 = alloca i64
  %l215 = alloca i1
  %l217 = alloca i1
  %l220 = alloca ptr
  %l222 = alloca { i64, ptr }
  %l223 = alloca %"compiler/msgs:Msg"
  %l224 = alloca i32
  %l232 = alloca i1
  %l239 = alloca i1
  %l241 = alloca i1
  %l243 = alloca i64
  %l245 = alloca i1
  %l247 = alloca i1
  %l256 = alloca ptr
  %l260 = alloca %"compiler/msgs:Msg"
  %l261 = alloca %"compiler/msgs:Msg"
  %l262 = alloca %"compiler/msgs:Msg"
  %l263 = alloca i32
  %l271 = alloca i1
  %l273 = alloca i1
  %l276 = alloca i64
  %l278 = alloca ptr
  %l280 = alloca %"compiler/msgs:Msg"
  %l281 = alloca i32
  %l283 = alloca ptr
  %l285 = alloca %"compiler/msgs:Msg"
  %l286 = alloca i32
  %l295 = alloca i1
  %l305 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %s41 = alloca %olang.scope
  %s42 = alloca %olang.scope
  %s45 = alloca %olang.scope
  %rv = alloca { i32, %"compiler/olang:CommandLine" }
  store { i64, ptr } %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"compiler/olang:CommandLine" @compiler_2folang_3aCommandLine_2ector(ptr %v3)
  store %"compiler/olang:CommandLine" %t1, ptr %l15
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 112, i64 8)
  store ptr %t2, ptr %lp3
  %t3 = load %"compiler/olang:CommandLine", ptr %l15
  %t4 = load ptr, ptr %lp3
  store %"compiler/olang:CommandLine" %t3, ptr %t4
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t9 = icmp slt i64 %t7, 2
  br i1 %t9, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = load ptr, ptr %l2, !tbaa !29
  store ptr %t11, ptr %l19, !tbaa !29
  %t12 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eUsage(ptr %s1)
  store %"compiler/msgs:Msg" %t12, ptr %l20
  br label %bb4
bb3:
  br label %bb8
bb4:
  %t13 = load ptr, ptr %l19, !tbaa !29
  %t14 = load %"compiler/msgs:Msg", ptr %l20
  %t15 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s1, ptr %t13, %"compiler/msgs:Msg" %t14)
  store i32 %t15, ptr %l21
  %t16 = icmp ne i32 %t15, 0
  br i1 %t16, label %bb6, label %ok.17
ok.17:
  br label %bb5
bb5:
  br label %bb7
bb6:
  %t18 = load i32, ptr %l21, !tbaa !23
  %t19 = lshr i32 %t18, 16
  %t20 = and i32 %t18, 65535
  %t21 = icmp eq i32 %t19, 1
  %t22 = select i1 %t21, i32 1, i32 0
  %t23 = icmp eq i32 %t18, 0
  %t24 = shl i32 %t22, 16
  %t25 = or i32 %t24, %t20
  %t26 = select i1 %t23, i32 0, i32 %t25
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t28 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t26, 0
  store { i32, %"compiler/olang:CommandLine" } %t28, ptr %rv
  br label %ret
bb7:
  call void @__olang_scope_close(ptr %s1)
  br label %bb8
bb8:
  store i64 1, ptr %l4, !tbaa !24
  %t29 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t29, ptr %l23, !tbaa !27
  %t30 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr { i64, ptr }, ptr %t31, i64 1
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !37
  %t35 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t33, { i64, ptr } { i64 1, ptr @.d66 })
  store i1 %t35, ptr %l25
  br label %bb9
bb9:
  %t36 = load i1, ptr %l25, !tbaa !21
  %t37 = xor i1 %t36, true
  br i1 %t37, label %bb10, label %bb11
bb10:
  %t39 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t39, ptr %l28, !tbaa !27
  %t40 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %t41, i64 1
  %t43 = load { i64, ptr }, ptr %t42, !tbaa !37
  %t45 = call i1 @compiler_2folang_2eendsWithOlang(ptr %v0, { i64, ptr } %t43)
  store i1 %t45, ptr %l30
  br label %bb12
bb11:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb13
bb12:
  %t46 = load i1, ptr %l30, !tbaa !21
  %t47 = xor i1 %t46, true
  store i1 %t47, ptr %l27, !tbaa !21
  br label %bb13
bb13:
  %t49 = load i1, ptr %l27, !tbaa !21
  br i1 %t49, label %bb14, label %bb15
bb14:
  %t50 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t50, ptr %l32, !tbaa !27
  %t51 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = getelementptr { i64, ptr }, ptr %t52, i64 1
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !37
  %t56 = call i64 @compiler_2folang_2emodeNumber(ptr %v0, { i64, ptr } %t54)
  store i64 %t56, ptr %l34
  br label %bb16
bb15:
  br label %bb24
bb16:
  %t57 = load i64, ptr %l34, !tbaa !24
  store i64 %t57, ptr %l5, !tbaa !24
  %t58 = load i64, ptr %l5, !tbaa !24
  %t60 = icmp slt i64 %t58, 0
  br i1 %t60, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s3
  %t62 = load ptr, ptr %l2, !tbaa !29
  store ptr %t62, ptr %l37, !tbaa !29
  %t63 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t63, ptr %l38, !tbaa !27
  %t64 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = getelementptr { i64, ptr }, ptr %t65, i64 1
  %t67 = load { i64, ptr }, ptr %t66, !tbaa !37
  %t69 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotAMode(ptr %v0, ptr %s3, { i64, ptr } %t67)
  store %"compiler/msgs:Msg" %t69, ptr %l40
  br label %bb19
bb18:
  br label %bb23
bb19:
  %t70 = load ptr, ptr %l37, !tbaa !29
  %t71 = load %"compiler/msgs:Msg", ptr %l40
  %t72 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s3, ptr %t70, %"compiler/msgs:Msg" %t71)
  store i32 %t72, ptr %l41
  %t73 = icmp ne i32 %t72, 0
  br i1 %t73, label %bb21, label %ok.74
ok.74:
  br label %bb20
bb20:
  br label %bb22
bb21:
  %t75 = load i32, ptr %l41, !tbaa !23
  %t76 = lshr i32 %t75, 16
  %t77 = and i32 %t75, 65535
  %t78 = icmp eq i32 %t76, 1
  %t79 = select i1 %t78, i32 1, i32 0
  %t80 = icmp eq i32 %t75, 0
  %t81 = shl i32 %t79, 16
  %t82 = or i32 %t81, %t77
  %t83 = select i1 %t80, i32 0, i32 %t82
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t85 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t83, 0
  store { i32, %"compiler/olang:CommandLine" } %t85, ptr %rv
  br label %ret
bb22:
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb23:
  %t86 = load i64, ptr %l5, !tbaa !24
  %t88 = load ptr, ptr %lp3
  %t89 = getelementptr %"compiler/olang:CommandLine", ptr %t88, i32 0, i32 0
  store i64 %t86, ptr %t89, !tbaa !24
  store i64 2, ptr %l4, !tbaa !24
  br label %bb24
bb24:
  br label %bb25
bb25:
  store %olang.scope zeroinitializer, ptr %s4
  %t90 = load i64, ptr %l4, !tbaa !24
  %t91 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t91, 0
  %t96 = icmp slt i64 %t90, %t93
  %t98 = xor i1 %t96, true
  br i1 %t98, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s4)
  br label %bb220
bb27:
  br label %bb28
bb28:
  %t100 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t100, ptr %l49, !tbaa !27
  %t101 = load i64, ptr %l4, !tbaa !24
  %t103 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = getelementptr { i64, ptr }, ptr %t104, i64 %t101
  %t106 = load { i64, ptr }, ptr %t105, !tbaa !37
  store { i64, ptr } %t106, ptr %l6, !tbaa !27
  %t108 = load i64, ptr %l4, !tbaa !24
  %t110 = add i64 %t108, 1
  store i64 %t110, ptr %l4, !tbaa !24
  %t112 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t114 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s4, { i64, ptr } %t112, { i64, ptr } { i64 1, ptr @.d67 })
  store i1 %t114, ptr %l55
  br label %bb29
bb29:
  %t115 = load i1, ptr %l55, !tbaa !21
  br i1 %t115, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s5
  store i64 -1, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l56, ptr @G_2ecompiler_2folang_2eOptWords, i64 160, i1 false)
  %t116 = load [10 x { i64, ptr }], ptr %l56
  store i64 10, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t118 = load i64, ptr %l9, !tbaa !24
  %t119 = load i64, ptr %l8, !tbaa !24
  %t122 = icmp sgt i64 %t118, %t119
  br i1 %t122, label %bb32, label %bb33
bb31:
  br label %bb130
bb32:
  %t124 = load i64, ptr %l10, !tbaa !24
  %t126 = icmp sgt i64 %t124, 0
  br i1 %t126, label %bb34, label %bb35
bb33:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb37
bb34:
  %t128 = load i64, ptr %l9, !tbaa !24
  %t129 = load i64, ptr %l8, !tbaa !24
  %t132 = sub i64 %t128, %t129
  %t133 = load i64, ptr %l10, !tbaa !24
  %t136 = add i64 %t132, %t133
  %t138 = sub i64 %t136, 1
  %t139 = load i64, ptr %l10, !tbaa !24
  %t142 = sdiv i64 %t138, %t139
  store i64 %t142, ptr %l64, !tbaa !24
  br label %bb36
bb35:
  store i64 0, ptr %l64, !tbaa !24
  br label %bb36
bb36:
  %t144 = load i64, ptr %l64, !tbaa !24
  store i64 %t144, ptr %l61, !tbaa !24
  br label %bb37
bb37:
  %t145 = load i64, ptr %l61, !tbaa !24
  store i64 %t145, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb38
bb38:
  store %olang.scope zeroinitializer, ptr %s7
  %t146 = load i64, ptr %l12, !tbaa !24
  %t147 = load i64, ptr %l11, !tbaa !24
  %t150 = icmp slt i64 %t146, %t147
  %t152 = xor i1 %t150, true
  br i1 %t152, label %bb39, label %bb40
bb39:
  call void @__olang_scope_close(ptr %s7)
  br label %bb47
bb40:
  br label %bb41
bb41:
  %t154 = load i64, ptr %l8, !tbaa !24
  %t155 = load i64, ptr %l12, !tbaa !24
  %t156 = load i64, ptr %l10, !tbaa !24
  %t159 = mul i64 %t155, %t156
  %t162 = add i64 %t154, %t159
  store i64 %t162, ptr %l13, !tbaa !24
  %t164 = load i64, ptr %l13, !tbaa !24
  %t166 = getelementptr [10 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eOptWords, i64 0, i64 %t164
  %t167 = load { i64, ptr }, ptr %t166, !tbaa !37
  %t168 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t169 = load ptr, ptr @__olang_prog_scope
  %t172 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t169, ptr %v0, { i64, ptr } %t167, { i64, ptr } %t168)
  store i1 %t172, ptr %l85
  br label %bb42
bb42:
  %t173 = load i1, ptr %l85, !tbaa !21
  br i1 %t173, label %bb43, label %bb44
bb43:
  %t174 = load i64, ptr %l13, !tbaa !24
  store i64 %t174, ptr %l7, !tbaa !24
  br label %bb45
bb44:
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s7)
  br label %bb46
bb46:
  %t176 = load i64, ptr %l12, !tbaa !24
  %t178 = add i64 %t176, 1
  store i64 %t178, ptr %l12, !tbaa !24
  br label %bb38
bb47:
  %t180 = load i64, ptr %l7, !tbaa !24
  %t182 = icmp slt i64 %t180, 0
  br i1 %t182, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s10
  %t184 = load ptr, ptr %l2, !tbaa !29
  store ptr %t184, ptr %l91, !tbaa !29
  %t185 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t185, ptr %l92, !tbaa !27
  %t186 = load ptr, ptr %lp3
  %t187 = getelementptr %"compiler/olang:CommandLine", ptr %t186, i32 0, i32 0
  %t188 = load i64, ptr %t187, !tbaa !24
  %t190 = call { i64, ptr } @compiler_2folang_2emodeName(ptr %s10, i64 %t188)
  store { i64, ptr } %t190, ptr %l94
  br label %bb50
bb49:
  br label %bb55
bb50:
  %t191 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t192 = extractvalue { i64, ptr } %t191, 0
  %t193 = extractvalue { i64, ptr } %t191, 1
  %t194 = mul i64 %t192, 1
  %t195 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t194)
  call void @llvm.memcpy.p0.p0.i64(ptr %t195, ptr %t193, i64 %t194, i1 false)
  %t196 = insertvalue { i64, ptr } undef, i64 %t192, 0
  %t197 = insertvalue { i64, ptr } %t196, ptr %t195, 1
  %t198 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t200 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownFlag(ptr %v0, ptr %s10, ptr %s10, { i64, ptr } %t198, { i64, ptr } %t197)
  store %"compiler/msgs:Msg" %t200, ptr %l96
  br label %bb51
bb51:
  %t201 = load ptr, ptr %l91, !tbaa !29
  %t202 = load %"compiler/msgs:Msg", ptr %l96
  %t203 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s10, ptr %t201, %"compiler/msgs:Msg" %t202)
  store i32 %t203, ptr %l97
  %t204 = icmp ne i32 %t203, 0
  br i1 %t204, label %bb53, label %ok.205
ok.205:
  br label %bb52
bb52:
  br label %bb54
bb53:
  %t206 = load i32, ptr %l97, !tbaa !23
  %t207 = lshr i32 %t206, 16
  %t208 = and i32 %t206, 65535
  %t209 = icmp eq i32 %t207, 1
  %t210 = select i1 %t209, i32 1, i32 0
  %t211 = icmp eq i32 %t206, 0
  %t212 = shl i32 %t210, 16
  %t213 = or i32 %t212, %t208
  %t214 = select i1 %t211, i32 0, i32 %t213
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t216 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t214, 0
  store { i32, %"compiler/olang:CommandLine" } %t216, ptr %rv
  br label %ret
bb54:
  call void @__olang_scope_close(ptr %s10)
  br label %bb55
bb55:
  %t217 = load i64, ptr %l7, !tbaa !24
  %t219 = getelementptr [10 x i64], ptr @G_2ecompiler_2folang_2eOptModes, i64 0, i64 %t217
  %t220 = load i64, ptr %t219, !tbaa !34
  %t221 = load ptr, ptr %lp3
  %t222 = getelementptr %"compiler/olang:CommandLine", ptr %t221, i32 0, i32 0
  %t223 = load i64, ptr %t222, !tbaa !24
  store i64 %t223, ptr %l101, !tbaa !24
  %t225 = load i64, ptr %l101, !tbaa !24
  %t226 = load i64, ptr %l101, !tbaa !24
  %t227 = ashr i64 %t220, %t226
  %t229 = and i64 %t227, 1
  %t231 = icmp eq i64 %t229, 0
  br i1 %t231, label %bb56, label %bb57
bb56:
  store %olang.scope zeroinitializer, ptr %s11
  %t233 = load ptr, ptr %l2, !tbaa !29
  store ptr %t233, ptr %l105, !tbaa !29
  %t234 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t234, ptr %l106, !tbaa !27
  %t235 = load i64, ptr %l7, !tbaa !24
  %t237 = getelementptr [10 x i64], ptr @G_2ecompiler_2folang_2eOptModes, i64 0, i64 %t235
  %t238 = load i64, ptr %t237, !tbaa !34
  %t240 = call { i64, ptr } @compiler_2folang_2emodesOf(ptr %s11, i64 %t238)
  store { i64, ptr } %t240, ptr %l109
  br label %bb58
bb57:
  br label %bb64
bb58:
  %t241 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t242 = extractvalue { i64, ptr } %t241, 0
  %t243 = extractvalue { i64, ptr } %t241, 1
  %t244 = mul i64 %t242, 1
  %t245 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t244)
  call void @llvm.memcpy.p0.p0.i64(ptr %t245, ptr %t243, i64 %t244, i1 false)
  %t246 = insertvalue { i64, ptr } undef, i64 %t242, 0
  %t247 = insertvalue { i64, ptr } %t246, ptr %t245, 1
  store { i64, ptr } %t247, ptr %l110, !tbaa !27
  %t248 = load ptr, ptr %lp3
  %t249 = getelementptr %"compiler/olang:CommandLine", ptr %t248, i32 0, i32 0
  %t250 = load i64, ptr %t249, !tbaa !24
  %t252 = call { i64, ptr } @compiler_2folang_2emodeName(ptr %s11, i64 %t250)
  store { i64, ptr } %t252, ptr %l112
  br label %bb59
bb59:
  %t253 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t254 = extractvalue { i64, ptr } %t253, 0
  %t255 = extractvalue { i64, ptr } %t253, 1
  %t256 = mul i64 %t254, 1
  %t257 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t256)
  call void @llvm.memcpy.p0.p0.i64(ptr %t257, ptr %t255, i64 %t256, i1 false)
  %t258 = insertvalue { i64, ptr } undef, i64 %t254, 0
  %t259 = insertvalue { i64, ptr } %t258, ptr %t257, 1
  %t260 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t261 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t263 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eOptionNotForMode(ptr %v0, ptr %s11, ptr %s11, ptr %s11, { i64, ptr } %t260, { i64, ptr } %t261, { i64, ptr } %t259)
  store %"compiler/msgs:Msg" %t263, ptr %l114
  br label %bb60
bb60:
  %t264 = load ptr, ptr %l105, !tbaa !29
  %t265 = load %"compiler/msgs:Msg", ptr %l114
  %t266 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s11, ptr %t264, %"compiler/msgs:Msg" %t265)
  store i32 %t266, ptr %l115
  %t267 = icmp ne i32 %t266, 0
  br i1 %t267, label %bb62, label %ok.268
ok.268:
  br label %bb61
bb61:
  br label %bb63
bb62:
  %t269 = load i32, ptr %l115, !tbaa !23
  %t270 = lshr i32 %t269, 16
  %t271 = and i32 %t269, 65535
  %t272 = icmp eq i32 %t270, 1
  %t273 = select i1 %t272, i32 1, i32 0
  %t274 = icmp eq i32 %t269, 0
  %t275 = shl i32 %t273, 16
  %t276 = or i32 %t275, %t271
  %t277 = select i1 %t274, i32 0, i32 %t276
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t279 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t277, 0
  store { i32, %"compiler/olang:CommandLine" } %t279, ptr %rv
  br label %ret
bb63:
  call void @__olang_scope_close(ptr %s11)
  br label %bb64
bb64:
  %t280 = load ptr, ptr %lp3
  %t281 = getelementptr %"compiler/olang:CommandLine", ptr %t280, i32 0, i32 5
  %t282 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t284 = extractvalue { i64, ptr } %t282, 1
  %t285 = extractvalue { i64, ptr } %t282, 0
  %t286 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t285)
  call void @olang_textcopy(ptr %t286, ptr %t284, i64 %t285)
  %t287 = insertvalue { i64, ptr } undef, i64 %t285, 0
  %t288 = insertvalue { i64, ptr } %t287, ptr %t286, 1
  %t290 = extractvalue { i64, ptr } %t288, 0
  %t291 = extractvalue { i64, ptr } %t288, 1
  %t292 = mul i64 %t290, 1
  %t293 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t292)
  call void @llvm.memcpy.p0.p0.i64(ptr %t293, ptr %t291, i64 %t292, i1 false)
  %t294 = insertvalue { i64, ptr } undef, i64 %t290, 0
  %t295 = insertvalue { i64, ptr } %t294, ptr %t293, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v3, ptr %v3, ptr %t281, { i64, ptr } %t295)
  br label %bb65
bb65:
  store { i64, ptr } { i64 0, ptr @.d68 }, ptr %l14, !tbaa !27
  %t298 = load i64, ptr %l7, !tbaa !24
  %t300 = getelementptr [10 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eOptValues, i64 0, i64 %t298
  %t301 = load { i64, ptr }, ptr %t300, !tbaa !37
  %t302 = load ptr, ptr @__olang_prog_scope
  %t304 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t302, ptr %s5, { i64, ptr } %t301, { i64, ptr } { i64 0, ptr @.d69 })
  store i1 %t304, ptr %l123
  br label %bb66
bb66:
  %t305 = load i1, ptr %l123, !tbaa !21
  %t306 = xor i1 %t305, true
  br i1 %t306, label %bb67, label %bb68
bb67:
  %t308 = load i64, ptr %l4, !tbaa !24
  %t309 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t311 = extractvalue { i64, ptr } %t309, 0
  %t314 = icmp sge i64 %t308, %t311
  br i1 %t314, label %bb69, label %bb70
bb68:
  br label %bb77
bb69:
  store %olang.scope zeroinitializer, ptr %s14
  %t316 = load ptr, ptr %l2, !tbaa !29
  store ptr %t316, ptr %l129, !tbaa !29
  %t317 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t318 = load i64, ptr %l7, !tbaa !24
  %t320 = getelementptr [10 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eOptValues, i64 0, i64 %t318
  %t321 = load { i64, ptr }, ptr %t320, !tbaa !37
  %t322 = load ptr, ptr @__olang_prog_scope
  %t325 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eOptionNeedsValue(ptr %v0, ptr %t322, ptr %s14, { i64, ptr } %t317, { i64, ptr } %t321)
  store %"compiler/msgs:Msg" %t325, ptr %l133
  br label %bb71
bb70:
  br label %bb75
bb71:
  %t326 = load ptr, ptr %l129, !tbaa !29
  %t327 = load %"compiler/msgs:Msg", ptr %l133
  %t328 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s14, ptr %t326, %"compiler/msgs:Msg" %t327)
  store i32 %t328, ptr %l134
  %t329 = icmp ne i32 %t328, 0
  br i1 %t329, label %bb73, label %ok.330
ok.330:
  br label %bb72
bb72:
  br label %bb74
bb73:
  %t331 = load i32, ptr %l134, !tbaa !23
  %t332 = lshr i32 %t331, 16
  %t333 = and i32 %t331, 65535
  %t334 = icmp eq i32 %t332, 1
  %t335 = select i1 %t334, i32 1, i32 0
  %t336 = icmp eq i32 %t331, 0
  %t337 = shl i32 %t335, 16
  %t338 = or i32 %t337, %t333
  %t339 = select i1 %t336, i32 0, i32 %t338
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t341 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t339, 0
  store { i32, %"compiler/olang:CommandLine" } %t341, ptr %rv
  br label %ret
bb74:
  call void @__olang_scope_close(ptr %s14)
  br label %bb75
bb75:
  %t342 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t342, ptr %l136, !tbaa !27
  %t343 = load i64, ptr %l4, !tbaa !24
  %t345 = getelementptr { i64, ptr }, ptr %l136, i32 0, i32 1
  %t346 = load ptr, ptr %t345, !tbaa !27
  %t347 = getelementptr { i64, ptr }, ptr %t346, i64 %t343
  %t348 = load { i64, ptr }, ptr %t347, !tbaa !37
  %t350 = extractvalue { i64, ptr } %t348, 1
  %t351 = extractvalue { i64, ptr } %t348, 0
  %t352 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t351)
  call void @olang_textcopy(ptr %t352, ptr %t350, i64 %t351)
  %t353 = insertvalue { i64, ptr } undef, i64 %t351, 0
  %t354 = insertvalue { i64, ptr } %t353, ptr %t352, 1
  %t356 = extractvalue { i64, ptr } %t354, 0
  %t357 = extractvalue { i64, ptr } %t354, 1
  %t358 = mul i64 %t356, 1
  %t359 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t358)
  call void @llvm.memcpy.p0.p0.i64(ptr %t359, ptr %t357, i64 %t358, i1 false)
  %t360 = insertvalue { i64, ptr } undef, i64 %t356, 0
  %t361 = insertvalue { i64, ptr } %t360, ptr %t359, 1
  store { i64, ptr } %t361, ptr %l14, !tbaa !27
  %t363 = load i64, ptr %l4, !tbaa !24
  %t365 = add i64 %t363, 1
  store i64 %t365, ptr %l4, !tbaa !24
  %t367 = load ptr, ptr %lp3
  %t368 = getelementptr %"compiler/olang:CommandLine", ptr %t367, i32 0, i32 5
  %t369 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t371 = extractvalue { i64, ptr } %t369, 1
  %t372 = extractvalue { i64, ptr } %t369, 0
  %t373 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t372)
  call void @olang_textcopy(ptr %t373, ptr %t371, i64 %t372)
  %t374 = insertvalue { i64, ptr } undef, i64 %t372, 0
  %t375 = insertvalue { i64, ptr } %t374, ptr %t373, 1
  %t377 = extractvalue { i64, ptr } %t375, 0
  %t378 = extractvalue { i64, ptr } %t375, 1
  %t379 = mul i64 %t377, 1
  %t380 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t379)
  call void @llvm.memcpy.p0.p0.i64(ptr %t380, ptr %t378, i64 %t379, i1 false)
  %t381 = insertvalue { i64, ptr } undef, i64 %t377, 0
  %t382 = insertvalue { i64, ptr } %t381, ptr %t380, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v3, ptr %v3, ptr %t368, { i64, ptr } %t382)
  br label %bb76
bb76:
  br label %bb77
bb77:
  %t385 = load i64, ptr %l7, !tbaa !24
  %t387 = icmp eq i64 %t385, 0
  br i1 %t387, label %bb78, label %bb79
bb78:
  %t389 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t391 = extractvalue { i64, ptr } %t389, 1
  %t392 = extractvalue { i64, ptr } %t389, 0
  %t393 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t392)
  call void @olang_textcopy(ptr %t393, ptr %t391, i64 %t392)
  %t394 = insertvalue { i64, ptr } undef, i64 %t392, 0
  %t395 = insertvalue { i64, ptr } %t394, ptr %t393, 1
  %t397 = extractvalue { i64, ptr } %t395, 0
  %t398 = extractvalue { i64, ptr } %t395, 1
  %t399 = mul i64 %t397, 1
  %t400 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t399)
  call void @llvm.memcpy.p0.p0.i64(ptr %t400, ptr %t398, i64 %t399, i1 false)
  %t401 = insertvalue { i64, ptr } undef, i64 %t397, 0
  %t402 = insertvalue { i64, ptr } %t401, ptr %t400, 1
  %t404 = load ptr, ptr %lp3
  %t405 = getelementptr %"compiler/olang:CommandLine", ptr %t404, i32 0, i32 7
  store { i64, ptr } %t402, ptr %t405, !tbaa !27
  br label %bb80
bb79:
  br label %bb80
bb80:
  %t406 = load i64, ptr %l7, !tbaa !24
  %t408 = icmp eq i64 %t406, 1
  br i1 %t408, label %bb81, label %bb82
bb81:
  %t410 = load ptr, ptr %l1, !tbaa !29
  %t412 = getelementptr %"compiler/build:Config", ptr %t410, i32 0, i32 4
  store i1 true, ptr %t412, !tbaa !21
  br label %bb83
bb82:
  br label %bb83
bb83:
  %t413 = load i64, ptr %l7, !tbaa !24
  %t415 = icmp eq i64 %t413, 2
  br i1 %t415, label %bb84, label %bb85
bb84:
  %t417 = load ptr, ptr %l1, !tbaa !29
  %t419 = getelementptr %"compiler/build:Config", ptr %t417, i32 0, i32 6
  store i1 true, ptr %t419, !tbaa !21
  br label %bb86
bb85:
  br label %bb86
bb86:
  %t420 = load i64, ptr %l7, !tbaa !24
  %t422 = icmp eq i64 %t420, 3
  br i1 %t422, label %bb87, label %bb88
bb87:
  %t424 = load ptr, ptr %l1, !tbaa !29
  %t426 = getelementptr %"compiler/build:Config", ptr %t424, i32 0, i32 7
  store i1 true, ptr %t426, !tbaa !21
  br label %bb89
bb88:
  br label %bb89
bb89:
  %t427 = load i64, ptr %l7, !tbaa !24
  %t429 = icmp eq i64 %t427, 4
  br i1 %t429, label %bb90, label %bb91
bb90:
  %t431 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t433 = extractvalue { i64, ptr } %t431, 1
  %t434 = extractvalue { i64, ptr } %t431, 0
  %t435 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t434)
  call void @olang_textcopy(ptr %t435, ptr %t433, i64 %t434)
  %t436 = insertvalue { i64, ptr } undef, i64 %t434, 0
  %t437 = insertvalue { i64, ptr } %t436, ptr %t435, 1
  %t439 = extractvalue { i64, ptr } %t437, 0
  %t440 = extractvalue { i64, ptr } %t437, 1
  %t441 = mul i64 %t439, 1
  %t442 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t441)
  call void @llvm.memcpy.p0.p0.i64(ptr %t442, ptr %t440, i64 %t441, i1 false)
  %t443 = insertvalue { i64, ptr } undef, i64 %t439, 0
  %t444 = insertvalue { i64, ptr } %t443, ptr %t442, 1
  %t446 = load ptr, ptr %lp3
  %t447 = getelementptr %"compiler/olang:CommandLine", ptr %t446, i32 0, i32 6
  store { i64, ptr } %t444, ptr %t447, !tbaa !27
  br label %bb92
bb91:
  br label %bb92
bb92:
  %t448 = load i64, ptr %l7, !tbaa !24
  %t450 = icmp eq i64 %t448, 5
  br i1 %t450, label %bb93, label %bb94
bb93:
  %t452 = load ptr, ptr %l1, !tbaa !29
  %t454 = getelementptr %"compiler/build:Config", ptr %t452, i32 0, i32 3
  %t455 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t456 = load ptr, ptr %l2, !tbaa !29
  %t460 = call i32 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eDefine(ptr %v1, ptr %s5, ptr %v2, ptr %t454, { i64, ptr } %t455, ptr %t456)
  store i32 %t460, ptr %l172
  %t461 = icmp ne i32 %t460, 0
  br i1 %t461, label %bb96, label %ok.462
ok.462:
  br label %bb95
bb94:
  br label %bb101
bb95:
  br label %bb100
bb96:
  %t463 = load i32, ptr %l172, !tbaa !23
  %t464 = ashr i32 %t463, 16
  %t466 = icmp eq i32 %t464, 1
  br i1 %t466, label %bb97, label %bb98
bb97:
  br label %bb99
bb98:
  %t468 = load i32, ptr %l172, !tbaa !23
  %t469 = lshr i32 %t468, 16
  %t470 = and i32 %t468, 65535
  %t471 = icmp eq i32 %t469, 1
  %t472 = select i1 %t471, i32 0, i32 0
  %t473 = icmp eq i32 %t468, 0
  %t474 = shl i32 %t472, 16
  %t475 = or i32 %t474, %t470
  %t476 = select i1 %t473, i32 0, i32 %t475
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t478 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t476, 0
  store { i32, %"compiler/olang:CommandLine" } %t478, ptr %rv
  br label %ret
bb99:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t480 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/olang:CommandLine" } %t480, ptr %rv
  br label %ret
bb100:
  br label %bb101
bb101:
  %t481 = load i64, ptr %l7, !tbaa !24
  %t483 = icmp eq i64 %t481, 6
  br i1 %t483, label %bb102, label %bb103
bb102:
  %t485 = load ptr, ptr %l1, !tbaa !29
  %t487 = getelementptr %"compiler/build:Config", ptr %t485, i32 0, i32 8
  store i1 true, ptr %t487, !tbaa !21
  br label %bb104
bb103:
  br label %bb104
bb104:
  %t488 = load i64, ptr %l7, !tbaa !24
  %t490 = icmp eq i64 %t488, 7
  br i1 %t490, label %bb105, label %bb106
bb105:
  %t492 = load ptr, ptr %lp3
  %t493 = getelementptr %"compiler/olang:CommandLine", ptr %t492, i32 0, i32 8
  store i1 true, ptr %t493, !tbaa !21
  br label %bb107
bb106:
  br label %bb107
bb107:
  %t494 = load i64, ptr %l7, !tbaa !24
  %t496 = icmp eq i64 %t494, 8
  br i1 %t496, label %bb108, label %bb109
bb108:
  %t498 = load ptr, ptr %l1, !tbaa !29
  %t500 = getelementptr %"compiler/build:Config", ptr %t498, i32 0, i32 5
  store i1 true, ptr %t500, !tbaa !21
  br label %bb110
bb109:
  br label %bb110
bb110:
  %t501 = load i64, ptr %l7, !tbaa !24
  %t503 = icmp eq i64 %t501, 9
  br i1 %t503, label %bb111, label %bb112
bb111:
  %t505 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t507 = extractvalue { i64, ptr } %t505, 1
  %t508 = extractvalue { i64, ptr } %t505, 0
  %t509 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t508)
  call void @olang_textcopy(ptr %t509, ptr %t507, i64 %t508)
  %t510 = insertvalue { i64, ptr } undef, i64 %t508, 0
  %t511 = insertvalue { i64, ptr } %t510, ptr %t509, 1
  %t513 = extractvalue { i64, ptr } %t511, 0
  %t514 = extractvalue { i64, ptr } %t511, 1
  %t515 = mul i64 %t513, 1
  %t516 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t515)
  call void @llvm.memcpy.p0.p0.i64(ptr %t516, ptr %t514, i64 %t515, i1 false)
  %t517 = insertvalue { i64, ptr } undef, i64 %t513, 0
  %t518 = insertvalue { i64, ptr } %t517, ptr %t516, 1
  %t520 = load ptr, ptr %lp3
  %t521 = getelementptr %"compiler/olang:CommandLine", ptr %t520, i32 0, i32 9
  store { i64, ptr } %t518, ptr %t521, !tbaa !27
  br label %bb113
bb112:
  br label %bb113
bb113:
  %t522 = load ptr, ptr %l1, !tbaa !29
  %t524 = getelementptr %"compiler/build:Config", ptr %t522, i32 0, i32 5
  %t525 = load i1, ptr %t524, !tbaa !21
  br i1 %t525, label %bb114, label %bb115
bb114:
  %t527 = load ptr, ptr %l1, !tbaa !29
  %t529 = getelementptr %"compiler/build:Config", ptr %t527, i32 0, i32 4
  %t530 = load i1, ptr %t529, !tbaa !21
  br i1 %t530, label %bb116, label %bb117
bb115:
  store i1 false, ptr %l192, !tbaa !21
  br label %bb119
bb116:
  store i1 true, ptr %l195, !tbaa !21
  br label %bb118
bb117:
  %t532 = load ptr, ptr %l1, !tbaa !29
  %t534 = getelementptr %"compiler/build:Config", ptr %t532, i32 0, i32 6
  %t535 = load i1, ptr %t534, !tbaa !21
  store i1 %t535, ptr %l195, !tbaa !21
  br label %bb118
bb118:
  %t537 = load i1, ptr %l195, !tbaa !21
  store i1 %t537, ptr %l192, !tbaa !21
  br label %bb119
bb119:
  %t538 = load i1, ptr %l192, !tbaa !21
  br i1 %t538, label %bb120, label %bb121
bb120:
  store %olang.scope zeroinitializer, ptr %s31
  %t539 = load ptr, ptr %l2, !tbaa !29
  store ptr %t539, ptr %l198, !tbaa !29
  %t540 = load ptr, ptr %l1, !tbaa !29
  %t542 = getelementptr %"compiler/build:Config", ptr %t540, i32 0, i32 4
  %t543 = load i1, ptr %t542, !tbaa !21
  br i1 %t543, label %bb122, label %bb123
bb121:
  br label %bb129
bb122:
  store { i64, ptr } { i64 6, ptr @.d70 }, ptr %l201, !tbaa !27
  br label %bb124
bb123:
  store { i64, ptr } { i64 5, ptr @.d71 }, ptr %l201, !tbaa !27
  br label %bb124
bb124:
  %t545 = load { i64, ptr }, ptr %l201, !tbaa !27
  %t546 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eQuickAlone(ptr %s31, ptr %s31, { i64, ptr } %t545)
  store %"compiler/msgs:Msg" %t546, ptr %l202
  br label %bb125
bb125:
  %t547 = load ptr, ptr %l198, !tbaa !29
  %t548 = load %"compiler/msgs:Msg", ptr %l202
  %t549 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s31, ptr %t547, %"compiler/msgs:Msg" %t548)
  store i32 %t549, ptr %l203
  %t550 = icmp ne i32 %t549, 0
  br i1 %t550, label %bb127, label %ok.551
ok.551:
  br label %bb126
bb126:
  br label %bb128
bb127:
  %t552 = load i32, ptr %l203, !tbaa !23
  %t553 = lshr i32 %t552, 16
  %t554 = and i32 %t552, 65535
  %t555 = icmp eq i32 %t553, 1
  %t556 = select i1 %t555, i32 1, i32 0
  %t557 = icmp eq i32 %t552, 0
  %t558 = shl i32 %t556, 16
  %t559 = or i32 %t558, %t554
  %t560 = select i1 %t557, i32 0, i32 %t559
  call void @__olang_scope_close(ptr %s31)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t562 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t560, 0
  store { i32, %"compiler/olang:CommandLine" } %t562, ptr %rv
  br label %ret
bb128:
  call void @__olang_scope_close(ptr %s31)
  br label %bb129
bb129:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  br label %bb219
bb130:
  %t563 = load ptr, ptr %lp3
  %t564 = getelementptr %"compiler/olang:CommandLine", ptr %t563, i32 0, i32 0
  %t565 = load i64, ptr %t564, !tbaa !24
  %t566 = load i64, ptr @G_2ecompiler_2folang_2eDoc, !tbaa !24
  %t569 = icmp eq i64 %t565, %t566
  br i1 %t569, label %bb131, label %bb132
bb131:
  %t571 = load ptr, ptr %lp3
  %t572 = getelementptr %"compiler/olang:CommandLine", ptr %t571, i32 0, i32 9
  %t573 = load { i64, ptr }, ptr %t572, !tbaa !27
  %t575 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s4, { i64, ptr } %t573, { i64, ptr } { i64 0, ptr @.d72 })
  store i1 %t575, ptr %l210
  br label %bb133
bb132:
  store i1 false, ptr %l208, !tbaa !21
  br label %bb134
bb133:
  %t576 = load i1, ptr %l210, !tbaa !21
  store i1 %t576, ptr %l208, !tbaa !21
  br label %bb134
bb134:
  %t577 = load i1, ptr %l208, !tbaa !21
  br i1 %t577, label %bb135, label %bb136
bb135:
  %t578 = load ptr, ptr %lp3
  %t579 = getelementptr %"compiler/olang:CommandLine", ptr %t578, i32 0, i32 1
  %t581 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v3, ptr %t579)
  store i64 %t581, ptr %l213
  br label %bb137
bb136:
  store i1 false, ptr %l211, !tbaa !21
  br label %bb138
bb137:
  %t582 = load i64, ptr %l213, !tbaa !24
  %t583 = icmp eq i64 %t582, 1
  store i1 %t583, ptr %l211, !tbaa !21
  br label %bb138
bb138:
  %t585 = load i1, ptr %l211, !tbaa !21
  br i1 %t585, label %bb139, label %bb140
bb139:
  %t586 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t588 = call i1 @compiler_2folang_2eendsWithOlang(ptr %v0, { i64, ptr } %t586)
  store i1 %t588, ptr %l217
  br label %bb141
bb140:
  store i1 false, ptr %l215, !tbaa !21
  br label %bb142
bb141:
  %t589 = load i1, ptr %l217, !tbaa !21
  %t590 = xor i1 %t589, true
  store i1 %t590, ptr %l215, !tbaa !21
  br label %bb142
bb142:
  %t592 = load i1, ptr %l215, !tbaa !21
  br i1 %t592, label %bb143, label %bb144
bb143:
  %t593 = load ptr, ptr %lp3
  %t594 = getelementptr %"compiler/olang:CommandLine", ptr %t593, i32 0, i32 3
  %t595 = load i1, ptr %t594, !tbaa !21
  br i1 %t595, label %bb145, label %bb146
bb144:
  br label %bb153
bb145:
  store %olang.scope zeroinitializer, ptr %s33
  %t597 = load ptr, ptr %l2, !tbaa !29
  store ptr %t597, ptr %l220, !tbaa !29
  %t598 = load ptr, ptr %lp3
  %t599 = getelementptr %"compiler/olang:CommandLine", ptr %t598, i32 0, i32 1
  %t601 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v3, ptr %v3, ptr %t599, i64 0)
  store { i64, ptr } %t601, ptr %l222
  br label %bb147
bb146:
  br label %bb152
bb147:
  %t602 = load { i64, ptr }, ptr %l222, !tbaa !27
  %t603 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDocOneName(ptr %v3, ptr %s33, { i64, ptr } %t602)
  store %"compiler/msgs:Msg" %t603, ptr %l223
  br label %bb148
bb148:
  %t604 = load ptr, ptr %l220, !tbaa !29
  %t605 = load %"compiler/msgs:Msg", ptr %l223
  %t606 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s33, ptr %t604, %"compiler/msgs:Msg" %t605)
  store i32 %t606, ptr %l224
  %t607 = icmp ne i32 %t606, 0
  br i1 %t607, label %bb150, label %ok.608
ok.608:
  br label %bb149
bb149:
  br label %bb151
bb150:
  %t609 = load i32, ptr %l224, !tbaa !23
  %t610 = lshr i32 %t609, 16
  %t611 = and i32 %t609, 65535
  %t612 = icmp eq i32 %t610, 1
  %t613 = select i1 %t612, i32 1, i32 0
  %t614 = icmp eq i32 %t609, 0
  %t615 = shl i32 %t613, 16
  %t616 = or i32 %t615, %t611
  %t617 = select i1 %t614, i32 0, i32 %t616
  call void @__olang_scope_close(ptr %s33)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t619 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t617, 0
  store { i32, %"compiler/olang:CommandLine" } %t619, ptr %rv
  br label %ret
bb151:
  call void @__olang_scope_close(ptr %s33)
  br label %bb152
bb152:
  %t620 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t622 = extractvalue { i64, ptr } %t620, 1
  %t623 = extractvalue { i64, ptr } %t620, 0
  %t624 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t623)
  call void @olang_textcopy(ptr %t624, ptr %t622, i64 %t623)
  %t625 = insertvalue { i64, ptr } undef, i64 %t623, 0
  %t626 = insertvalue { i64, ptr } %t625, ptr %t624, 1
  %t628 = extractvalue { i64, ptr } %t626, 0
  %t629 = extractvalue { i64, ptr } %t626, 1
  %t630 = mul i64 %t628, 1
  %t631 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t630)
  call void @llvm.memcpy.p0.p0.i64(ptr %t631, ptr %t629, i64 %t630, i1 false)
  %t632 = insertvalue { i64, ptr } undef, i64 %t628, 0
  %t633 = insertvalue { i64, ptr } %t632, ptr %t631, 1
  %t635 = load ptr, ptr %lp3
  %t636 = getelementptr %"compiler/olang:CommandLine", ptr %t635, i32 0, i32 2
  store { i64, ptr } %t633, ptr %t636, !tbaa !27
  %t637 = load ptr, ptr %lp3
  %t638 = getelementptr %"compiler/olang:CommandLine", ptr %t637, i32 0, i32 3
  store i1 true, ptr %t638, !tbaa !21
  call void @__olang_scope_close(ptr %s4)
  br label %bb219
bb153:
  %t639 = load ptr, ptr %lp3
  %t640 = getelementptr %"compiler/olang:CommandLine", ptr %t639, i32 0, i32 0
  %t641 = load i64, ptr %t640, !tbaa !24
  %t642 = load i64, ptr @G_2ecompiler_2folang_2eExplain, !tbaa !24
  %t645 = icmp eq i64 %t641, %t642
  br i1 %t645, label %bb154, label %bb155
bb154:
  store i1 true, ptr %l232, !tbaa !21
  br label %bb156
bb155:
  %t647 = load ptr, ptr %lp3
  %t648 = getelementptr %"compiler/olang:CommandLine", ptr %t647, i32 0, i32 0
  %t649 = load i64, ptr %t648, !tbaa !24
  %t650 = load i64, ptr @G_2ecompiler_2folang_2eHelp, !tbaa !24
  %t653 = icmp eq i64 %t649, %t650
  store i1 %t653, ptr %l232, !tbaa !21
  br label %bb156
bb156:
  %t655 = load i1, ptr %l232, !tbaa !21
  br i1 %t655, label %bb157, label %bb158
bb157:
  %t656 = load ptr, ptr %lp3
  %t657 = getelementptr %"compiler/olang:CommandLine", ptr %t656, i32 0, i32 0
  %t658 = load i64, ptr %t657, !tbaa !24
  %t659 = load i64, ptr @G_2ecompiler_2folang_2eExplain, !tbaa !24
  %t662 = icmp eq i64 %t658, %t659
  br i1 %t662, label %bb159, label %bb160
bb158:
  br label %bb185
bb159:
  %t664 = load ptr, ptr %lp3
  %t665 = getelementptr %"compiler/olang:CommandLine", ptr %t664, i32 0, i32 3
  %t666 = load i1, ptr %t665, !tbaa !21
  store i1 %t666, ptr %l239, !tbaa !21
  br label %bb161
bb160:
  store i1 false, ptr %l239, !tbaa !21
  br label %bb161
bb161:
  %t668 = load i1, ptr %l239, !tbaa !21
  br i1 %t668, label %bb162, label %bb163
bb162:
  %t669 = load ptr, ptr %lp3
  %t670 = getelementptr %"compiler/olang:CommandLine", ptr %t669, i32 0, i32 1
  %t672 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v3, ptr %t670)
  store i64 %t672, ptr %l243
  br label %bb164
bb163:
  store i1 false, ptr %l241, !tbaa !21
  br label %bb165
bb164:
  %t673 = load i64, ptr %l243, !tbaa !24
  %t674 = icmp eq i64 %t673, 0
  store i1 %t674, ptr %l241, !tbaa !21
  br label %bb165
bb165:
  %t676 = load i1, ptr %l241, !tbaa !21
  br i1 %t676, label %bb166, label %bb167
bb166:
  %t677 = load ptr, ptr %lp3
  %t678 = getelementptr %"compiler/olang:CommandLine", ptr %t677, i32 0, i32 2
  %t679 = load { i64, ptr }, ptr %t678, !tbaa !27
  %t681 = call i1 @compiler_2folang_2eendsWithOlang(ptr %v3, { i64, ptr } %t679)
  store i1 %t681, ptr %l247
  br label %bb168
bb167:
  store i1 false, ptr %l245, !tbaa !21
  br label %bb169
bb168:
  %t682 = load i1, ptr %l247, !tbaa !21
  store i1 %t682, ptr %l245, !tbaa !21
  br label %bb169
bb169:
  %t683 = load i1, ptr %l245, !tbaa !21
  br i1 %t683, label %bb170, label %bb171
bb170:
  %t684 = load ptr, ptr %lp3
  %t685 = getelementptr %"compiler/olang:CommandLine", ptr %t684, i32 0, i32 1
  %t686 = load ptr, ptr %lp3
  %t687 = getelementptr %"compiler/olang:CommandLine", ptr %t686, i32 0, i32 2
  %t688 = load { i64, ptr }, ptr %t687, !tbaa !27
  %t690 = extractvalue { i64, ptr } %t688, 1
  %t691 = extractvalue { i64, ptr } %t688, 0
  %t692 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t691)
  call void @olang_textcopy(ptr %t692, ptr %t690, i64 %t691)
  %t693 = insertvalue { i64, ptr } undef, i64 %t691, 0
  %t694 = insertvalue { i64, ptr } %t693, ptr %t692, 1
  %t696 = extractvalue { i64, ptr } %t694, 0
  %t697 = extractvalue { i64, ptr } %t694, 1
  %t698 = mul i64 %t696, 1
  %t699 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t698)
  call void @llvm.memcpy.p0.p0.i64(ptr %t699, ptr %t697, i64 %t698, i1 false)
  %t700 = insertvalue { i64, ptr } undef, i64 %t696, 0
  %t701 = insertvalue { i64, ptr } %t700, ptr %t699, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v3, ptr %v3, ptr %t685, { i64, ptr } %t701)
  br label %bb172
bb171:
  br label %bb173
bb172:
  %t704 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t706 = extractvalue { i64, ptr } %t704, 1
  %t707 = extractvalue { i64, ptr } %t704, 0
  %t708 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t707)
  call void @olang_textcopy(ptr %t708, ptr %t706, i64 %t707)
  %t709 = insertvalue { i64, ptr } undef, i64 %t707, 0
  %t710 = insertvalue { i64, ptr } %t709, ptr %t708, 1
  %t712 = extractvalue { i64, ptr } %t710, 0
  %t713 = extractvalue { i64, ptr } %t710, 1
  %t714 = mul i64 %t712, 1
  %t715 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t714)
  call void @llvm.memcpy.p0.p0.i64(ptr %t715, ptr %t713, i64 %t714, i1 false)
  %t716 = insertvalue { i64, ptr } undef, i64 %t712, 0
  %t717 = insertvalue { i64, ptr } %t716, ptr %t715, 1
  %t719 = load ptr, ptr %lp3
  %t720 = getelementptr %"compiler/olang:CommandLine", ptr %t719, i32 0, i32 2
  store { i64, ptr } %t717, ptr %t720, !tbaa !27
  call void @__olang_scope_close(ptr %s4)
  br label %bb219
bb173:
  %t721 = load ptr, ptr %lp3
  %t722 = getelementptr %"compiler/olang:CommandLine", ptr %t721, i32 0, i32 3
  %t723 = load i1, ptr %t722, !tbaa !21
  br i1 %t723, label %bb174, label %bb175
bb174:
  store %olang.scope zeroinitializer, ptr %s39
  %t725 = load ptr, ptr %l2, !tbaa !29
  store ptr %t725, ptr %l256, !tbaa !29
  %t726 = load ptr, ptr %lp3
  %t727 = getelementptr %"compiler/olang:CommandLine", ptr %t726, i32 0, i32 0
  %t728 = load i64, ptr %t727, !tbaa !24
  %t729 = load i64, ptr @G_2ecompiler_2folang_2eExplain, !tbaa !24
  %t732 = icmp eq i64 %t728, %t729
  br i1 %t732, label %bb176, label %bb177
bb175:
  br label %bb184
bb176:
  %t734 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eExplainNeedsRule(ptr %s39)
  store %"compiler/msgs:Msg" %t734, ptr %l261
  br label %bb178
bb177:
  %t735 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eHelpOneMode(ptr %s39)
  store %"compiler/msgs:Msg" %t735, ptr %l262
  br label %bb179
bb178:
  %t736 = load %"compiler/msgs:Msg", ptr %l261
  store %"compiler/msgs:Msg" %t736, ptr %l260
  br label %bb180
bb179:
  %t737 = load %"compiler/msgs:Msg", ptr %l262
  store %"compiler/msgs:Msg" %t737, ptr %l260
  br label %bb180
bb180:
  %t738 = load ptr, ptr %l256, !tbaa !29
  %t739 = load %"compiler/msgs:Msg", ptr %l260
  %t740 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s39, ptr %t738, %"compiler/msgs:Msg" %t739)
  store i32 %t740, ptr %l263
  %t741 = icmp ne i32 %t740, 0
  br i1 %t741, label %bb182, label %ok.742
ok.742:
  br label %bb181
bb181:
  br label %bb183
bb182:
  %t743 = load i32, ptr %l263, !tbaa !23
  %t744 = lshr i32 %t743, 16
  %t745 = and i32 %t743, 65535
  %t746 = icmp eq i32 %t744, 1
  %t747 = select i1 %t746, i32 1, i32 0
  %t748 = icmp eq i32 %t743, 0
  %t749 = shl i32 %t747, 16
  %t750 = or i32 %t749, %t745
  %t751 = select i1 %t748, i32 0, i32 %t750
  call void @__olang_scope_close(ptr %s39)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t753 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t751, 0
  store { i32, %"compiler/olang:CommandLine" } %t753, ptr %rv
  br label %ret
bb183:
  call void @__olang_scope_close(ptr %s39)
  br label %bb184
bb184:
  %t754 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t756 = extractvalue { i64, ptr } %t754, 1
  %t757 = extractvalue { i64, ptr } %t754, 0
  %t758 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t757)
  call void @olang_textcopy(ptr %t758, ptr %t756, i64 %t757)
  %t759 = insertvalue { i64, ptr } undef, i64 %t757, 0
  %t760 = insertvalue { i64, ptr } %t759, ptr %t758, 1
  %t762 = extractvalue { i64, ptr } %t760, 0
  %t763 = extractvalue { i64, ptr } %t760, 1
  %t764 = mul i64 %t762, 1
  %t765 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t764)
  call void @llvm.memcpy.p0.p0.i64(ptr %t765, ptr %t763, i64 %t764, i1 false)
  %t766 = insertvalue { i64, ptr } undef, i64 %t762, 0
  %t767 = insertvalue { i64, ptr } %t766, ptr %t765, 1
  %t769 = load ptr, ptr %lp3
  %t770 = getelementptr %"compiler/olang:CommandLine", ptr %t769, i32 0, i32 2
  store { i64, ptr } %t767, ptr %t770, !tbaa !27
  %t771 = load ptr, ptr %lp3
  %t772 = getelementptr %"compiler/olang:CommandLine", ptr %t771, i32 0, i32 3
  store i1 true, ptr %t772, !tbaa !21
  call void @__olang_scope_close(ptr %s4)
  br label %bb219
bb185:
  %t773 = load ptr, ptr %lp3
  %t774 = getelementptr %"compiler/olang:CommandLine", ptr %t773, i32 0, i32 0
  %t775 = load i64, ptr %t774, !tbaa !24
  %t776 = load i64, ptr @G_2ecompiler_2folang_2eRun, !tbaa !24
  %t779 = icmp eq i64 %t775, %t776
  br i1 %t779, label %bb186, label %bb187
bb186:
  %t781 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t783 = call i1 @compiler_2folang_2eendsWithOlang(ptr %v0, { i64, ptr } %t781)
  store i1 %t783, ptr %l273
  br label %bb188
bb187:
  store i1 false, ptr %l271, !tbaa !21
  br label %bb189
bb188:
  %t784 = load i1, ptr %l273, !tbaa !21
  %t785 = xor i1 %t784, true
  store i1 %t785, ptr %l271, !tbaa !21
  br label %bb189
bb189:
  %t787 = load i1, ptr %l271, !tbaa !21
  br i1 %t787, label %bb190, label %bb191
bb190:
  store %olang.scope zeroinitializer, ptr %s41
  %t788 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t790 = call i64 @compiler_2folang_2emodeNumber(ptr %v0, { i64, ptr } %t788)
  store i64 %t790, ptr %l276
  br label %bb192
bb191:
  br label %bb204
bb192:
  %t791 = load i64, ptr %l276, !tbaa !24
  %t792 = icmp sgt i64 %t791, 0
  br i1 %t792, label %bb193, label %bb194
bb193:
  store %olang.scope zeroinitializer, ptr %s42
  %t794 = load ptr, ptr %l2, !tbaa !29
  store ptr %t794, ptr %l278, !tbaa !29
  %t795 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t797 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eModeFirst(ptr %v0, ptr %s42, { i64, ptr } %t795)
  store %"compiler/msgs:Msg" %t797, ptr %l280
  br label %bb195
bb194:
  br label %bb199
bb195:
  %t798 = load ptr, ptr %l278, !tbaa !29
  %t799 = load %"compiler/msgs:Msg", ptr %l280
  %t800 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s42, ptr %t798, %"compiler/msgs:Msg" %t799)
  store i32 %t800, ptr %l281
  %t801 = icmp ne i32 %t800, 0
  br i1 %t801, label %bb197, label %ok.802
ok.802:
  br label %bb196
bb196:
  br label %bb198
bb197:
  %t803 = load i32, ptr %l281, !tbaa !23
  %t804 = lshr i32 %t803, 16
  %t805 = and i32 %t803, 65535
  %t806 = icmp eq i32 %t804, 1
  %t807 = select i1 %t806, i32 1, i32 0
  %t808 = icmp eq i32 %t803, 0
  %t809 = shl i32 %t807, 16
  %t810 = or i32 %t809, %t805
  %t811 = select i1 %t808, i32 0, i32 %t810
  call void @__olang_scope_close(ptr %s42)
  call void @__olang_scope_close(ptr %s41)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t813 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t811, 0
  store { i32, %"compiler/olang:CommandLine" } %t813, ptr %rv
  br label %ret
bb198:
  call void @__olang_scope_close(ptr %s42)
  br label %bb199
bb199:
  %t814 = load ptr, ptr %l2, !tbaa !29
  store ptr %t814, ptr %l283, !tbaa !29
  %t815 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t817 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotASource(ptr %v0, ptr %s41, { i64, ptr } %t815)
  store %"compiler/msgs:Msg" %t817, ptr %l285
  br label %bb200
bb200:
  %t818 = load ptr, ptr %l283, !tbaa !29
  %t819 = load %"compiler/msgs:Msg", ptr %l285
  %t820 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s41, ptr %t818, %"compiler/msgs:Msg" %t819)
  store i32 %t820, ptr %l286
  %t821 = icmp ne i32 %t820, 0
  br i1 %t821, label %bb202, label %ok.822
ok.822:
  br label %bb201
bb201:
  br label %bb203
bb202:
  %t823 = load i32, ptr %l286, !tbaa !23
  %t824 = lshr i32 %t823, 16
  %t825 = and i32 %t823, 65535
  %t826 = icmp eq i32 %t824, 1
  %t827 = select i1 %t826, i32 1, i32 0
  %t828 = icmp eq i32 %t823, 0
  %t829 = shl i32 %t827, 16
  %t830 = or i32 %t829, %t825
  %t831 = select i1 %t828, i32 0, i32 %t830
  call void @__olang_scope_close(ptr %s41)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t833 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t831, 0
  store { i32, %"compiler/olang:CommandLine" } %t833, ptr %rv
  br label %ret
bb203:
  call void @__olang_scope_close(ptr %s41)
  br label %bb204
bb204:
  %t834 = load ptr, ptr %lp3
  %t835 = getelementptr %"compiler/olang:CommandLine", ptr %t834, i32 0, i32 1
  %t836 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t838 = extractvalue { i64, ptr } %t836, 1
  %t839 = extractvalue { i64, ptr } %t836, 0
  %t840 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t839)
  call void @olang_textcopy(ptr %t840, ptr %t838, i64 %t839)
  %t841 = insertvalue { i64, ptr } undef, i64 %t839, 0
  %t842 = insertvalue { i64, ptr } %t841, ptr %t840, 1
  %t844 = extractvalue { i64, ptr } %t842, 0
  %t845 = extractvalue { i64, ptr } %t842, 1
  %t846 = mul i64 %t844, 1
  %t847 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t846)
  call void @llvm.memcpy.p0.p0.i64(ptr %t847, ptr %t845, i64 %t846, i1 false)
  %t848 = insertvalue { i64, ptr } undef, i64 %t844, 0
  %t849 = insertvalue { i64, ptr } %t848, ptr %t847, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v3, ptr %v3, ptr %t835, { i64, ptr } %t849)
  br label %bb205
bb205:
  %t852 = load ptr, ptr %lp3
  %t853 = getelementptr %"compiler/olang:CommandLine", ptr %t852, i32 0, i32 0
  %t854 = load i64, ptr %t853, !tbaa !24
  %t855 = load i64, ptr @G_2ecompiler_2folang_2eRun, !tbaa !24
  %t858 = icmp eq i64 %t854, %t855
  br i1 %t858, label %bb206, label %bb207
bb206:
  store i1 true, ptr %l295, !tbaa !21
  br label %bb208
bb207:
  %t860 = load ptr, ptr %lp3
  %t861 = getelementptr %"compiler/olang:CommandLine", ptr %t860, i32 0, i32 0
  %t862 = load i64, ptr %t861, !tbaa !24
  %t863 = load i64, ptr @G_2ecompiler_2folang_2eInterp, !tbaa !24
  %t866 = icmp eq i64 %t862, %t863
  store i1 %t866, ptr %l295, !tbaa !21
  br label %bb208
bb208:
  %t868 = load i1, ptr %l295, !tbaa !21
  br i1 %t868, label %bb209, label %bb210
bb209:
  br label %bb211
bb210:
  br label %bb218
bb211:
  store %olang.scope zeroinitializer, ptr %s45
  %t869 = load i64, ptr %l4, !tbaa !24
  %t870 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t872 = extractvalue { i64, ptr } %t870, 0
  %t875 = icmp slt i64 %t869, %t872
  %t877 = xor i1 %t875, true
  br i1 %t877, label %bb212, label %bb213
bb212:
  call void @__olang_scope_close(ptr %s45)
  br label %bb217
bb213:
  br label %bb214
bb214:
  %t879 = load ptr, ptr %lp3
  %t880 = getelementptr %"compiler/olang:CommandLine", ptr %t879, i32 0, i32 4
  %t881 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t881, ptr %l305, !tbaa !27
  %t882 = load i64, ptr %l4, !tbaa !24
  %t884 = getelementptr { i64, ptr }, ptr %l305, i32 0, i32 1
  %t885 = load ptr, ptr %t884, !tbaa !27
  %t886 = getelementptr { i64, ptr }, ptr %t885, i64 %t882
  %t887 = load { i64, ptr }, ptr %t886, !tbaa !37
  %t889 = extractvalue { i64, ptr } %t887, 1
  %t890 = extractvalue { i64, ptr } %t887, 0
  %t891 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t890)
  call void @olang_textcopy(ptr %t891, ptr %t889, i64 %t890)
  %t892 = insertvalue { i64, ptr } undef, i64 %t890, 0
  %t893 = insertvalue { i64, ptr } %t892, ptr %t891, 1
  %t895 = extractvalue { i64, ptr } %t893, 0
  %t896 = extractvalue { i64, ptr } %t893, 1
  %t897 = mul i64 %t895, 1
  %t898 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t897)
  call void @llvm.memcpy.p0.p0.i64(ptr %t898, ptr %t896, i64 %t897, i1 false)
  %t899 = insertvalue { i64, ptr } undef, i64 %t895, 0
  %t900 = insertvalue { i64, ptr } %t899, ptr %t898, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v3, ptr %v3, ptr %t880, { i64, ptr } %t900)
  br label %bb215
bb215:
  %t903 = load i64, ptr %l4, !tbaa !24
  %t905 = add i64 %t903, 1
  store i64 %t905, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s45)
  br label %bb216
bb216:
  br label %bb211
bb217:
  br label %bb218
bb218:
  call void @__olang_scope_close(ptr %s4)
  br label %bb219
bb219:
  br label %bb25
bb220:
  %t907 = load ptr, ptr %lp3
  %t908 = load %"compiler/olang:CommandLine", ptr %t907
  call void @__olang_scope_close(ptr %s0)
  %t910 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, %"compiler/olang:CommandLine" %t908, 1
  store { i32, %"compiler/olang:CommandLine" } %t910, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/olang:CommandLine" }, ptr %rv
  ret { i32, %"compiler/olang:CommandLine" } %rr
}

define dso_local { i32, %"compiler/olang:CommandLine" } @compiler_2folang_2ePrepare(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %lp3 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca %"compiler/olang:CommandLine"
  %l9 = alloca %"compiler/olang:CommandLine"
  %l10 = alloca i32
  %l21 = alloca ptr
  %l22 = alloca %"compiler/msgs:Msg"
  %l23 = alloca i32
  %l26 = alloca i64
  %l29 = alloca i1
  %l30 = alloca ptr
  %l32 = alloca %"compiler/msgs:Msg"
  %l33 = alloca i32
  %l39 = alloca i1
  %l43 = alloca i1
  %l45 = alloca i64
  %l47 = alloca ptr
  %l49 = alloca { i64, ptr }
  %l51 = alloca %"compiler/msgs:Msg"
  %l52 = alloca i32
  %l57 = alloca i1
  %l59 = alloca i1
  %l60 = alloca i1
  %l62 = alloca i64
  %l64 = alloca ptr
  %l66 = alloca i64
  %l68 = alloca %"compiler/msgs:Msg"
  %l70 = alloca { i64, ptr }
  %l72 = alloca %"compiler/msgs:Msg"
  %l74 = alloca { i64, ptr }
  %l76 = alloca %"compiler/msgs:Msg"
  %l77 = alloca i32
  %l80 = alloca i64
  %l82 = alloca i1
  %l86 = alloca i1
  %l90 = alloca i1
  %l94 = alloca ptr
  %l96 = alloca { i64, ptr }
  %l98 = alloca %"compiler/msgs:Msg"
  %l99 = alloca i32
  %l104 = alloca i1
  %l108 = alloca i1
  %l110 = alloca i64
  %l112 = alloca ptr
  %l114 = alloca { i64, ptr }
  %l116 = alloca %"compiler/msgs:Msg"
  %l117 = alloca i32
  %l122 = alloca i1
  %l128 = alloca i1
  %l132 = alloca i32
  %l138 = alloca ptr
  %l139 = alloca { i64, ptr }
  %l141 = alloca ptr
  %l142 = alloca { i64, ptr }
  %l143 = alloca { i64, ptr }
  %l144 = alloca i32
  %l145 = alloca { i64, ptr }
  %l151 = alloca i1
  %l155 = alloca i1
  %l159 = alloca ptr
  %l160 = alloca %"compiler/target:Target"
  %l161 = alloca { i64, ptr }
  %l163 = alloca { i64, ptr }
  %l167 = alloca i1
  %l169 = alloca i1
  %l172 = alloca i1
  %l174 = alloca %"compiler/target:Target"
  %l175 = alloca i32
  %l182 = alloca i1
  %l186 = alloca ptr
  %l188 = alloca { i64, ptr }
  %l191 = alloca %"compiler/msgs:Msg"
  %l192 = alloca i32
  %l198 = alloca ptr
  %l201 = alloca i1
  %l205 = alloca i1
  %l210 = alloca i32
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %rv = alloca { i32, %"compiler/olang:CommandLine" }
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t7 = call { i32, %"compiler/olang:CommandLine" } @compiler_2folang_2eParse(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, ptr %t2, ptr %t3)
  %t8 = extractvalue { i32, %"compiler/olang:CommandLine" } %t7, 1
  %t9 = extractvalue { i32, %"compiler/olang:CommandLine" } %t7, 0
  store i32 %t9, ptr %l10
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11
ok.11:
  store %"compiler/olang:CommandLine" %t8, ptr %l9
  br label %bb1
bb1:
  %t12 = load %"compiler/olang:CommandLine", ptr %l9
  store %"compiler/olang:CommandLine" %t12, ptr %l5
  br label %bb3
bb2:
  %t13 = load i32, ptr %l10, !tbaa !23
  %t14 = lshr i32 %t13, 16
  %t15 = and i32 %t13, 65535
  %t16 = icmp eq i32 %t14, 1
  %t17 = select i1 %t16, i32 1, i32 0
  %t18 = icmp eq i32 %t13, 0
  %t19 = shl i32 %t17, 16
  %t20 = or i32 %t19, %t15
  %t21 = select i1 %t18, i32 0, i32 %t20
  call void @__olang_scope_close(ptr %s0)
  %t23 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t21, 0
  store { i32, %"compiler/olang:CommandLine" } %t23, ptr %rv
  br label %ret
bb3:
  %t24 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 112, i64 8)
  store ptr %t24, ptr %lp3
  %t25 = load %"compiler/olang:CommandLine", ptr %l5
  %t26 = load ptr, ptr %lp3
  store %"compiler/olang:CommandLine" %t25, ptr %t26
  %t27 = load ptr, ptr %lp3
  %t28 = getelementptr %"compiler/olang:CommandLine", ptr %t27, i32 0, i32 0
  %t29 = load i64, ptr %t28, !tbaa !24
  %t30 = load i64, ptr @G_2ecompiler_2folang_2eHelp, !tbaa !24
  %t33 = icmp eq i64 %t29, %t30
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = load ptr, ptr %lp3
  %t36 = load %"compiler/olang:CommandLine", ptr %t35
  call void @__olang_scope_close(ptr %s0)
  %t38 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, %"compiler/olang:CommandLine" %t36, 1
  store { i32, %"compiler/olang:CommandLine" } %t38, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t39 = load ptr, ptr %lp3
  %t40 = getelementptr %"compiler/olang:CommandLine", ptr %t39, i32 0, i32 0
  %t41 = load i64, ptr %t40, !tbaa !24
  %t42 = load i64, ptr @G_2ecompiler_2folang_2eExplain, !tbaa !24
  %t45 = icmp eq i64 %t41, %t42
  br i1 %t45, label %bb7, label %bb8
bb7:
  %t47 = load ptr, ptr %lp3
  %t48 = getelementptr %"compiler/olang:CommandLine", ptr %t47, i32 0, i32 3
  %t49 = load i1, ptr %t48, !tbaa !21
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb9, label %bb10
bb8:
  br label %bb28
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t53 = load ptr, ptr %l2, !tbaa !29
  store ptr %t53, ptr %l21, !tbaa !29
  %t54 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eExplainNeedsRule(ptr %s3)
  store %"compiler/msgs:Msg" %t54, ptr %l22
  br label %bb11
bb10:
  br label %bb15
bb11:
  %t55 = load ptr, ptr %l21, !tbaa !29
  %t56 = load %"compiler/msgs:Msg", ptr %l22
  %t57 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s3, ptr %t55, %"compiler/msgs:Msg" %t56)
  store i32 %t57, ptr %l23
  %t58 = icmp ne i32 %t57, 0
  br i1 %t58, label %bb13, label %ok.59
ok.59:
  br label %bb12
bb12:
  br label %bb14
bb13:
  %t60 = load i32, ptr %l23, !tbaa !23
  %t61 = lshr i32 %t60, 16
  %t62 = and i32 %t60, 65535
  %t63 = icmp eq i32 %t61, 1
  %t64 = select i1 %t63, i32 1, i32 0
  %t65 = icmp eq i32 %t60, 0
  %t66 = shl i32 %t64, 16
  %t67 = or i32 %t66, %t62
  %t68 = select i1 %t65, i32 0, i32 %t67
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t70 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t68, 0
  store { i32, %"compiler/olang:CommandLine" } %t70, ptr %rv
  br label %ret
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb15:
  %t71 = load ptr, ptr %lp3
  %t72 = getelementptr %"compiler/olang:CommandLine", ptr %t71, i32 0, i32 1
  %t74 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v3, ptr %t72)
  store i64 %t74, ptr %l26
  br label %bb16
bb16:
  %t75 = load i64, ptr %l26, !tbaa !24
  %t76 = icmp eq i64 %t75, 0
  br i1 %t76, label %bb17, label %bb18
bb17:
  %t78 = load ptr, ptr %lp3
  %t79 = getelementptr %"compiler/olang:CommandLine", ptr %t78, i32 0, i32 2
  %t80 = load { i64, ptr }, ptr %t79, !tbaa !27
  %t82 = call i1 @compiler_2folang_2eendsWithOlang(ptr %v3, { i64, ptr } %t80)
  store i1 %t82, ptr %l29
  br label %bb19
bb18:
  br label %bb27
bb19:
  %t83 = load i1, ptr %l29, !tbaa !21
  br i1 %t83, label %bb20, label %bb21
bb20:
  store %olang.scope zeroinitializer, ptr %s5
  %t84 = load ptr, ptr %l2, !tbaa !29
  store ptr %t84, ptr %l30, !tbaa !29
  %t85 = load ptr, ptr %lp3
  %t86 = getelementptr %"compiler/olang:CommandLine", ptr %t85, i32 0, i32 2
  %t87 = load { i64, ptr }, ptr %t86, !tbaa !27
  %t89 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eExplainNeedsName(ptr %v3, ptr %s5, { i64, ptr } %t87)
  store %"compiler/msgs:Msg" %t89, ptr %l32
  br label %bb22
bb21:
  br label %bb26
bb22:
  %t90 = load ptr, ptr %l30, !tbaa !29
  %t91 = load %"compiler/msgs:Msg", ptr %l32
  %t92 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s5, ptr %t90, %"compiler/msgs:Msg" %t91)
  store i32 %t92, ptr %l33
  %t93 = icmp ne i32 %t92, 0
  br i1 %t93, label %bb24, label %ok.94
ok.94:
  br label %bb23
bb23:
  br label %bb25
bb24:
  %t95 = load i32, ptr %l33, !tbaa !23
  %t96 = lshr i32 %t95, 16
  %t97 = and i32 %t95, 65535
  %t98 = icmp eq i32 %t96, 1
  %t99 = select i1 %t98, i32 1, i32 0
  %t100 = icmp eq i32 %t95, 0
  %t101 = shl i32 %t99, 16
  %t102 = or i32 %t101, %t97
  %t103 = select i1 %t100, i32 0, i32 %t102
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t105 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t103, 0
  store { i32, %"compiler/olang:CommandLine" } %t105, ptr %rv
  br label %ret
bb25:
  call void @__olang_scope_close(ptr %s5)
  br label %bb26
bb26:
  %t106 = load ptr, ptr %lp3
  %t107 = load %"compiler/olang:CommandLine", ptr %t106
  call void @__olang_scope_close(ptr %s0)
  %t109 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, %"compiler/olang:CommandLine" %t107, 1
  store { i32, %"compiler/olang:CommandLine" } %t109, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t110 = load ptr, ptr %lp3
  %t111 = getelementptr %"compiler/olang:CommandLine", ptr %t110, i32 0, i32 0
  %t112 = load i64, ptr %t111, !tbaa !24
  %t113 = load i64, ptr @G_2ecompiler_2folang_2eLsp, !tbaa !24
  %t116 = icmp eq i64 %t112, %t113
  br i1 %t116, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb31
bb30:
  %t118 = load ptr, ptr %lp3
  %t119 = getelementptr %"compiler/olang:CommandLine", ptr %t118, i32 0, i32 0
  %t120 = load i64, ptr %t119, !tbaa !24
  %t121 = load i64, ptr @G_2ecompiler_2folang_2eMcp, !tbaa !24
  %t124 = icmp eq i64 %t120, %t121
  store i1 %t124, ptr %l39, !tbaa !21
  br label %bb31
bb31:
  %t126 = load i1, ptr %l39, !tbaa !21
  br i1 %t126, label %bb32, label %bb33
bb32:
  %t127 = load ptr, ptr %lp3
  %t128 = getelementptr %"compiler/olang:CommandLine", ptr %t127, i32 0, i32 1
  %t130 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v3, ptr %t128)
  store i64 %t130, ptr %l45
  br label %bb34
bb33:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb35
bb34:
  %t131 = load i64, ptr %l45, !tbaa !24
  %t132 = icmp sgt i64 %t131, 0
  store i1 %t132, ptr %l43, !tbaa !21
  br label %bb35
bb35:
  %t134 = load i1, ptr %l43, !tbaa !21
  br i1 %t134, label %bb36, label %bb37
bb36:
  store %olang.scope zeroinitializer, ptr %s6
  %t135 = load ptr, ptr %l2, !tbaa !29
  store ptr %t135, ptr %l47, !tbaa !29
  %t136 = load ptr, ptr %lp3
  %t137 = getelementptr %"compiler/olang:CommandLine", ptr %t136, i32 0, i32 0
  %t138 = load i64, ptr %t137, !tbaa !24
  %t140 = call { i64, ptr } @compiler_2folang_2emodeName(ptr %s6, i64 %t138)
  store { i64, ptr } %t140, ptr %l49
  br label %bb38
bb37:
  br label %bb43
bb38:
  %t141 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t141, 0
  %t143 = extractvalue { i64, ptr } %t141, 1
  %t144 = mul i64 %t142, 1
  %t145 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t144)
  call void @llvm.memcpy.p0.p0.i64(ptr %t145, ptr %t143, i64 %t144, i1 false)
  %t146 = insertvalue { i64, ptr } undef, i64 %t142, 0
  %t147 = insertvalue { i64, ptr } %t146, ptr %t145, 1
  %t149 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eModeNoFiles(ptr %s6, ptr %s6, { i64, ptr } %t147)
  store %"compiler/msgs:Msg" %t149, ptr %l51
  br label %bb39
bb39:
  %t150 = load ptr, ptr %l47, !tbaa !29
  %t151 = load %"compiler/msgs:Msg", ptr %l51
  %t152 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s6, ptr %t150, %"compiler/msgs:Msg" %t151)
  store i32 %t152, ptr %l52
  %t153 = icmp ne i32 %t152, 0
  br i1 %t153, label %bb41, label %ok.154
ok.154:
  br label %bb40
bb40:
  br label %bb42
bb41:
  %t155 = load i32, ptr %l52, !tbaa !23
  %t156 = lshr i32 %t155, 16
  %t157 = and i32 %t155, 65535
  %t158 = icmp eq i32 %t156, 1
  %t159 = select i1 %t158, i32 1, i32 0
  %t160 = icmp eq i32 %t155, 0
  %t161 = shl i32 %t159, 16
  %t162 = or i32 %t161, %t157
  %t163 = select i1 %t160, i32 0, i32 %t162
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t165 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t163, 0
  store { i32, %"compiler/olang:CommandLine" } %t165, ptr %rv
  br label %ret
bb42:
  call void @__olang_scope_close(ptr %s6)
  br label %bb43
bb43:
  %t166 = load ptr, ptr %lp3
  %t167 = getelementptr %"compiler/olang:CommandLine", ptr %t166, i32 0, i32 0
  %t168 = load i64, ptr %t167, !tbaa !24
  %t169 = load i64, ptr @G_2ecompiler_2folang_2eDoc, !tbaa !24
  %t172 = icmp eq i64 %t168, %t169
  br i1 %t172, label %bb44, label %bb45
bb44:
  %t174 = load ptr, ptr %lp3
  %t175 = getelementptr %"compiler/olang:CommandLine", ptr %t174, i32 0, i32 9
  %t176 = load { i64, ptr }, ptr %t175, !tbaa !27
  %t178 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s0, { i64, ptr } %t176, { i64, ptr } { i64 0, ptr @.d73 })
  store i1 %t178, ptr %l59
  br label %bb46
bb45:
  store i1 false, ptr %l57, !tbaa !21
  br label %bb47
bb46:
  %t179 = load i1, ptr %l59, !tbaa !21
  store i1 %t179, ptr %l57, !tbaa !21
  br label %bb47
bb47:
  %t180 = load i1, ptr %l57, !tbaa !21
  br i1 %t180, label %bb48, label %bb49
bb48:
  %t181 = load ptr, ptr %lp3
  %t182 = getelementptr %"compiler/olang:CommandLine", ptr %t181, i32 0, i32 1
  %t184 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v3, ptr %t182)
  store i64 %t184, ptr %l62
  br label %bb50
bb49:
  store i1 false, ptr %l60, !tbaa !21
  br label %bb51
bb50:
  %t185 = load i64, ptr %l62, !tbaa !24
  %t186 = icmp ne i64 %t185, 1
  store i1 %t186, ptr %l60, !tbaa !21
  br label %bb51
bb51:
  %t188 = load i1, ptr %l60, !tbaa !21
  br i1 %t188, label %bb52, label %bb53
bb52:
  store %olang.scope zeroinitializer, ptr %s7
  %t189 = load ptr, ptr %l2, !tbaa !29
  store ptr %t189, ptr %l64, !tbaa !29
  %t190 = load ptr, ptr %lp3
  %t191 = getelementptr %"compiler/olang:CommandLine", ptr %t190, i32 0, i32 1
  %t193 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v3, ptr %t191)
  store i64 %t193, ptr %l66
  br label %bb54
bb53:
  br label %bb65
bb54:
  %t194 = load i64, ptr %l66, !tbaa !24
  %t195 = icmp sgt i64 %t194, 1
  br i1 %t195, label %bb55, label %bb56
bb55:
  %t197 = load ptr, ptr %lp3
  %t198 = getelementptr %"compiler/olang:CommandLine", ptr %t197, i32 0, i32 0
  %t199 = load i64, ptr %t198, !tbaa !24
  %t201 = call { i64, ptr } @compiler_2folang_2emodeName(ptr %s7, i64 %t199)
  store { i64, ptr } %t201, ptr %l70
  br label %bb57
bb56:
  %t202 = load ptr, ptr %lp3
  %t203 = getelementptr %"compiler/olang:CommandLine", ptr %t202, i32 0, i32 0
  %t204 = load i64, ptr %t203, !tbaa !24
  %t206 = call { i64, ptr } @compiler_2folang_2emodeName(ptr %s7, i64 %t204)
  store { i64, ptr } %t206, ptr %l74
  br label %bb59
bb57:
  %t207 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t208 = extractvalue { i64, ptr } %t207, 0
  %t209 = extractvalue { i64, ptr } %t207, 1
  %t210 = mul i64 %t208, 1
  %t211 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t210)
  call void @llvm.memcpy.p0.p0.i64(ptr %t211, ptr %t209, i64 %t210, i1 false)
  %t212 = insertvalue { i64, ptr } undef, i64 %t208, 0
  %t213 = insertvalue { i64, ptr } %t212, ptr %t211, 1
  %t215 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eModeOneFile(ptr %s7, ptr %s7, { i64, ptr } %t213)
  store %"compiler/msgs:Msg" %t215, ptr %l72
  br label %bb58
bb58:
  %t216 = load %"compiler/msgs:Msg", ptr %l72
  store %"compiler/msgs:Msg" %t216, ptr %l68
  br label %bb61
bb59:
  %t217 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t218 = extractvalue { i64, ptr } %t217, 0
  %t219 = extractvalue { i64, ptr } %t217, 1
  %t220 = mul i64 %t218, 1
  %t221 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t220)
  call void @llvm.memcpy.p0.p0.i64(ptr %t221, ptr %t219, i64 %t220, i1 false)
  %t222 = insertvalue { i64, ptr } undef, i64 %t218, 0
  %t223 = insertvalue { i64, ptr } %t222, ptr %t221, 1
  %t225 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eModeNeedsFile(ptr %s7, ptr %s7, { i64, ptr } %t223)
  store %"compiler/msgs:Msg" %t225, ptr %l76
  br label %bb60
bb60:
  %t226 = load %"compiler/msgs:Msg", ptr %l76
  store %"compiler/msgs:Msg" %t226, ptr %l68
  br label %bb61
bb61:
  %t227 = load ptr, ptr %l64, !tbaa !29
  %t228 = load %"compiler/msgs:Msg", ptr %l68
  %t229 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s7, ptr %t227, %"compiler/msgs:Msg" %t228)
  store i32 %t229, ptr %l77
  %t230 = icmp ne i32 %t229, 0
  br i1 %t230, label %bb63, label %ok.231
ok.231:
  br label %bb62
bb62:
  br label %bb64
bb63:
  %t232 = load i32, ptr %l77, !tbaa !23
  %t233 = lshr i32 %t232, 16
  %t234 = and i32 %t232, 65535
  %t235 = icmp eq i32 %t233, 1
  %t236 = select i1 %t235, i32 1, i32 0
  %t237 = icmp eq i32 %t232, 0
  %t238 = shl i32 %t236, 16
  %t239 = or i32 %t238, %t234
  %t240 = select i1 %t237, i32 0, i32 %t239
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  %t242 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t240, 0
  store { i32, %"compiler/olang:CommandLine" } %t242, ptr %rv
  br label %ret
bb64:
  call void @__olang_scope_close(ptr %s7)
  br label %bb65
bb65:
  %t243 = load ptr, ptr %lp3
  %t244 = getelementptr %"compiler/olang:CommandLine", ptr %t243, i32 0, i32 1
  %t246 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v3, ptr %t244)
  store i64 %t246, ptr %l80
  br label %bb66
bb66:
  %t247 = load i64, ptr %l80, !tbaa !24
  %t248 = icmp eq i64 %t247, 0
  br i1 %t248, label %bb67, label %bb68
bb67:
  %t250 = load ptr, ptr %lp3
  %t251 = getelementptr %"compiler/olang:CommandLine", ptr %t250, i32 0, i32 0
  %t252 = load i64, ptr %t251, !tbaa !24
  %t253 = load i64, ptr @G_2ecompiler_2folang_2eLsp, !tbaa !24
  %t256 = icmp ne i64 %t252, %t253
  store i1 %t256, ptr %l82, !tbaa !21
  br label %bb69
bb68:
  store i1 false, ptr %l82, !tbaa !21
  br label %bb69
bb69:
  %t258 = load i1, ptr %l82, !tbaa !21
  br i1 %t258, label %bb70, label %bb71
bb70:
  %t259 = load ptr, ptr %lp3
  %t260 = getelementptr %"compiler/olang:CommandLine", ptr %t259, i32 0, i32 0
  %t261 = load i64, ptr %t260, !tbaa !24
  %t262 = load i64, ptr @G_2ecompiler_2folang_2eMcp, !tbaa !24
  %t265 = icmp ne i64 %t261, %t262
  store i1 %t265, ptr %l86, !tbaa !21
  br label %bb72
bb71:
  store i1 false, ptr %l86, !tbaa !21
  br label %bb72
bb72:
  %t267 = load i1, ptr %l86, !tbaa !21
  br i1 %t267, label %bb73, label %bb74
bb73:
  %t268 = load ptr, ptr %lp3
  %t269 = getelementptr %"compiler/olang:CommandLine", ptr %t268, i32 0, i32 0
  %t270 = load i64, ptr %t269, !tbaa !24
  %t271 = load i64, ptr @G_2ecompiler_2folang_2eDoc, !tbaa !24
  %t274 = icmp ne i64 %t270, %t271
  store i1 %t274, ptr %l90, !tbaa !21
  br label %bb75
bb74:
  store i1 false, ptr %l90, !tbaa !21
  br label %bb75
bb75:
  %t276 = load i1, ptr %l90, !tbaa !21
  br i1 %t276, label %bb76, label %bb77
bb76:
  store %olang.scope zeroinitializer, ptr %s8
  %t277 = load ptr, ptr %l2, !tbaa !29
  store ptr %t277, ptr %l94, !tbaa !29
  %t278 = load ptr, ptr %lp3
  %t279 = getelementptr %"compiler/olang:CommandLine", ptr %t278, i32 0, i32 0
  %t280 = load i64, ptr %t279, !tbaa !24
  %t282 = call { i64, ptr } @compiler_2folang_2emodeName(ptr %s8, i64 %t280)
  store { i64, ptr } %t282, ptr %l96
  br label %bb78
bb77:
  br label %bb83
bb78:
  %t283 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t284 = extractvalue { i64, ptr } %t283, 0
  %t285 = extractvalue { i64, ptr } %t283, 1
  %t286 = mul i64 %t284, 1
  %t287 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t286)
  call void @llvm.memcpy.p0.p0.i64(ptr %t287, ptr %t285, i64 %t286, i1 false)
  %t288 = insertvalue { i64, ptr } undef, i64 %t284, 0
  %t289 = insertvalue { i64, ptr } %t288, ptr %t287, 1
  %t291 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eModeNeedsFile(ptr %s8, ptr %s8, { i64, ptr } %t289)
  store %"compiler/msgs:Msg" %t291, ptr %l98
  br label %bb79
bb79:
  %t292 = load ptr, ptr %l94, !tbaa !29
  %t293 = load %"compiler/msgs:Msg", ptr %l98
  %t294 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s8, ptr %t292, %"compiler/msgs:Msg" %t293)
  store i32 %t294, ptr %l99
  %t295 = icmp ne i32 %t294, 0
  br i1 %t295, label %bb81, label %ok.296
ok.296:
  br label %bb80
bb80:
  br label %bb82
bb81:
  %t297 = load i32, ptr %l99, !tbaa !23
  %t298 = lshr i32 %t297, 16
  %t299 = and i32 %t297, 65535
  %t300 = icmp eq i32 %t298, 1
  %t301 = select i1 %t300, i32 1, i32 0
  %t302 = icmp eq i32 %t297, 0
  %t303 = shl i32 %t301, 16
  %t304 = or i32 %t303, %t299
  %t305 = select i1 %t302, i32 0, i32 %t304
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t307 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t305, 0
  store { i32, %"compiler/olang:CommandLine" } %t307, ptr %rv
  br label %ret
bb82:
  call void @__olang_scope_close(ptr %s8)
  br label %bb83
bb83:
  %t308 = load ptr, ptr %lp3
  %t309 = getelementptr %"compiler/olang:CommandLine", ptr %t308, i32 0, i32 0
  %t310 = load i64, ptr %t309, !tbaa !24
  %t311 = load i64, ptr @G_2ecompiler_2folang_2eBuild, !tbaa !24
  %t314 = icmp eq i64 %t310, %t311
  br i1 %t314, label %bb84, label %bb85
bb84:
  store i1 true, ptr %l104, !tbaa !21
  br label %bb86
bb85:
  %t316 = load ptr, ptr %lp3
  %t317 = getelementptr %"compiler/olang:CommandLine", ptr %t316, i32 0, i32 0
  %t318 = load i64, ptr %t317, !tbaa !24
  %t319 = load i64, ptr @G_2ecompiler_2folang_2eCompile, !tbaa !24
  %t322 = icmp eq i64 %t318, %t319
  store i1 %t322, ptr %l104, !tbaa !21
  br label %bb86
bb86:
  %t324 = load i1, ptr %l104, !tbaa !21
  br i1 %t324, label %bb87, label %bb88
bb87:
  %t325 = load ptr, ptr %lp3
  %t326 = getelementptr %"compiler/olang:CommandLine", ptr %t325, i32 0, i32 1
  %t328 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v3, ptr %t326)
  store i64 %t328, ptr %l110
  br label %bb89
bb88:
  store i1 false, ptr %l108, !tbaa !21
  br label %bb90
bb89:
  %t329 = load i64, ptr %l110, !tbaa !24
  %t330 = icmp ne i64 %t329, 1
  store i1 %t330, ptr %l108, !tbaa !21
  br label %bb90
bb90:
  %t332 = load i1, ptr %l108, !tbaa !21
  br i1 %t332, label %bb91, label %bb92
bb91:
  store %olang.scope zeroinitializer, ptr %s9
  %t333 = load ptr, ptr %l2, !tbaa !29
  store ptr %t333, ptr %l112, !tbaa !29
  %t334 = load ptr, ptr %lp3
  %t335 = getelementptr %"compiler/olang:CommandLine", ptr %t334, i32 0, i32 0
  %t336 = load i64, ptr %t335, !tbaa !24
  %t338 = call { i64, ptr } @compiler_2folang_2emodeName(ptr %s9, i64 %t336)
  store { i64, ptr } %t338, ptr %l114
  br label %bb93
bb92:
  br label %bb98
bb93:
  %t339 = load { i64, ptr }, ptr %l114, !tbaa !27
  %t340 = extractvalue { i64, ptr } %t339, 0
  %t341 = extractvalue { i64, ptr } %t339, 1
  %t342 = mul i64 %t340, 1
  %t343 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t342)
  call void @llvm.memcpy.p0.p0.i64(ptr %t343, ptr %t341, i64 %t342, i1 false)
  %t344 = insertvalue { i64, ptr } undef, i64 %t340, 0
  %t345 = insertvalue { i64, ptr } %t344, ptr %t343, 1
  %t347 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eModeOneFile(ptr %s9, ptr %s9, { i64, ptr } %t345)
  store %"compiler/msgs:Msg" %t347, ptr %l116
  br label %bb94
bb94:
  %t348 = load ptr, ptr %l112, !tbaa !29
  %t349 = load %"compiler/msgs:Msg", ptr %l116
  %t350 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s9, ptr %t348, %"compiler/msgs:Msg" %t349)
  store i32 %t350, ptr %l117
  %t351 = icmp ne i32 %t350, 0
  br i1 %t351, label %bb96, label %ok.352
ok.352:
  br label %bb95
bb95:
  br label %bb97
bb96:
  %t353 = load i32, ptr %l117, !tbaa !23
  %t354 = lshr i32 %t353, 16
  %t355 = and i32 %t353, 65535
  %t356 = icmp eq i32 %t354, 1
  %t357 = select i1 %t356, i32 1, i32 0
  %t358 = icmp eq i32 %t353, 0
  %t359 = shl i32 %t357, 16
  %t360 = or i32 %t359, %t355
  %t361 = select i1 %t358, i32 0, i32 %t360
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  %t363 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t361, 0
  store { i32, %"compiler/olang:CommandLine" } %t363, ptr %rv
  br label %ret
bb97:
  call void @__olang_scope_close(ptr %s9)
  br label %bb98
bb98:
  %t364 = load ptr, ptr %lp3
  %t365 = getelementptr %"compiler/olang:CommandLine", ptr %t364, i32 0, i32 0
  %t366 = load i64, ptr %t365, !tbaa !24
  %t367 = load i64, ptr @G_2ecompiler_2folang_2eFormat, !tbaa !24
  %t370 = icmp eq i64 %t366, %t367
  br i1 %t370, label %bb99, label %bb100
bb99:
  store i1 true, ptr %l122, !tbaa !21
  br label %bb101
bb100:
  %t372 = load ptr, ptr %lp3
  %t373 = getelementptr %"compiler/olang:CommandLine", ptr %t372, i32 0, i32 0
  %t374 = load i64, ptr %t373, !tbaa !24
  %t375 = load i64, ptr @G_2ecompiler_2folang_2eFix, !tbaa !24
  %t378 = icmp eq i64 %t374, %t375
  store i1 %t378, ptr %l122, !tbaa !21
  br label %bb101
bb101:
  %t380 = load i1, ptr %l122, !tbaa !21
  br i1 %t380, label %bb102, label %bb103
bb102:
  %t381 = load ptr, ptr %lp3
  %t382 = load %"compiler/olang:CommandLine", ptr %t381
  call void @__olang_scope_close(ptr %s0)
  %t384 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, %"compiler/olang:CommandLine" %t382, 1
  store { i32, %"compiler/olang:CommandLine" } %t384, ptr %rv
  br label %ret
bb103:
  br label %bb104
bb104:
  %t385 = load ptr, ptr %lp3
  %t386 = getelementptr %"compiler/olang:CommandLine", ptr %t385, i32 0, i32 7
  %t387 = load { i64, ptr }, ptr %t386, !tbaa !27
  %t389 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s0, { i64, ptr } %t387, { i64, ptr } { i64 0, ptr @.d74 })
  store i1 %t389, ptr %l128
  br label %bb105
bb105:
  %t390 = load i1, ptr %l128, !tbaa !21
  %t391 = xor i1 %t390, true
  br i1 %t391, label %bb106, label %bb107
bb106:
  %t393 = load ptr, ptr %lp3
  %t394 = getelementptr %"compiler/olang:CommandLine", ptr %t393, i32 0, i32 7
  %t395 = load { i64, ptr }, ptr %t394, !tbaa !27
  %t396 = load ptr, ptr %l2, !tbaa !29
  %t399 = call i32 @compiler_2folang_2echeckOutput(ptr %v3, ptr %v2, { i64, ptr } %t395, ptr %t396)
  store i32 %t399, ptr %l132
  %t400 = icmp ne i32 %t399, 0
  br i1 %t400, label %bb109, label %ok.401
ok.401:
  br label %bb108
bb107:
  br label %bb111
bb108:
  br label %bb110
bb109:
  %t402 = load i32, ptr %l132, !tbaa !23
  %t403 = lshr i32 %t402, 16
  %t404 = and i32 %t402, 65535
  %t405 = icmp eq i32 %t403, 1
  %t406 = select i1 %t405, i32 1, i32 0
  %t407 = icmp eq i32 %t402, 0
  %t408 = shl i32 %t406, 16
  %t409 = or i32 %t408, %t404
  %t410 = select i1 %t407, i32 0, i32 %t409
  call void @__olang_scope_close(ptr %s0)
  %t412 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t410, 0
  store { i32, %"compiler/olang:CommandLine" } %t412, ptr %rv
  br label %ret
bb110:
  br label %bb111
bb111:
  %t413 = load ptr, ptr %l1, !tbaa !29
  %t414 = load ptr, ptr %lp3
  %t415 = getelementptr %"compiler/olang:CommandLine", ptr %t414, i32 0, i32 7
  %t416 = load { i64, ptr }, ptr %t415, !tbaa !27
  %t418 = extractvalue { i64, ptr } %t416, 1
  %t419 = extractvalue { i64, ptr } %t416, 0
  %t420 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t419)
  call void @olang_textcopy(ptr %t420, ptr %t418, i64 %t419)
  %t421 = insertvalue { i64, ptr } undef, i64 %t419, 0
  %t422 = insertvalue { i64, ptr } %t421, ptr %t420, 1
  %t424 = extractvalue { i64, ptr } %t422, 0
  %t425 = extractvalue { i64, ptr } %t422, 1
  %t426 = mul i64 %t424, 1
  %t427 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t426)
  call void @llvm.memcpy.p0.p0.i64(ptr %t427, ptr %t425, i64 %t426, i1 false)
  %t428 = insertvalue { i64, ptr } undef, i64 %t424, 0
  %t429 = insertvalue { i64, ptr } %t428, ptr %t427, 1
  %t432 = getelementptr %"compiler/build:Config", ptr %t413, i32 0, i32 13
  store { i64, ptr } %t429, ptr %t432, !tbaa !27
  %t433 = load ptr, ptr %l1, !tbaa !29
  store ptr %t433, ptr %l138, !tbaa !29
  %t434 = call { i64, ptr } @compiler_2ftarget_2eFindClang(ptr %v1)
  store { i64, ptr } %t434, ptr %l139
  br label %bb112
bb112:
  %t435 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t436 = extractvalue { i64, ptr } %t435, 0
  %t437 = extractvalue { i64, ptr } %t435, 1
  %t438 = mul i64 %t436, 1
  %t439 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t438)
  call void @llvm.memcpy.p0.p0.i64(ptr %t439, ptr %t437, i64 %t438, i1 false)
  %t440 = insertvalue { i64, ptr } undef, i64 %t436, 0
  %t441 = insertvalue { i64, ptr } %t440, ptr %t439, 1
  %t443 = load ptr, ptr %l138, !tbaa !29
  %t444 = getelementptr %"compiler/build:Config", ptr %t443, i32 0, i32 1
  store { i64, ptr } %t441, ptr %t444, !tbaa !27
  %t445 = load ptr, ptr %l1, !tbaa !29
  store ptr %t445, ptr %l141, !tbaa !29
  %t446 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %v1, ptr %v1, { i64, ptr } { i64 13, ptr @.d75 })
  %t447 = extractvalue { i32, { i64, ptr } } %t446, 1
  %t448 = extractvalue { i32, { i64, ptr } } %t446, 0
  store i32 %t448, ptr %l144
  %t449 = icmp ne i32 %t448, 0
  br i1 %t449, label %bb114, label %ok.450
ok.450:
  store { i64, ptr } %t447, ptr %l143
  br label %bb113
bb113:
  %t451 = load { i64, ptr }, ptr %l143, !tbaa !27
  store { i64, ptr } %t451, ptr %l142, !tbaa !27
  br label %bb116
bb114:
  br label %bb115
bb115:
  store { i64, ptr } { i64 0, ptr @.d76 }, ptr %l145, !tbaa !27
  %t452 = load { i64, ptr }, ptr %l145, !tbaa !27
  %t454 = extractvalue { i64, ptr } %t452, 0
  %t455 = extractvalue { i64, ptr } %t452, 1
  %t456 = mul i64 %t454, 1
  %t457 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t456)
  call void @llvm.memcpy.p0.p0.i64(ptr %t457, ptr %t455, i64 %t456, i1 false)
  %t458 = insertvalue { i64, ptr } undef, i64 %t454, 0
  %t459 = insertvalue { i64, ptr } %t458, ptr %t457, 1
  store { i64, ptr } %t459, ptr %l142, !tbaa !27
  br label %bb116
bb116:
  %t461 = load { i64, ptr }, ptr %l142, !tbaa !27
  %t462 = load ptr, ptr %l141, !tbaa !29
  %t463 = getelementptr %"compiler/build:Config", ptr %t462, i32 0, i32 18
  store { i64, ptr } %t461, ptr %t463, !tbaa !27
  %t464 = load ptr, ptr %lp3
  %t465 = getelementptr %"compiler/olang:CommandLine", ptr %t464, i32 0, i32 0
  %t466 = load i64, ptr %t465, !tbaa !24
  %t467 = load i64, ptr @G_2ecompiler_2folang_2eDoc, !tbaa !24
  %t470 = icmp eq i64 %t466, %t467
  br i1 %t470, label %bb117, label %bb118
bb117:
  store i1 true, ptr %l151, !tbaa !21
  br label %bb119
bb118:
  %t472 = load ptr, ptr %lp3
  %t473 = getelementptr %"compiler/olang:CommandLine", ptr %t472, i32 0, i32 0
  %t474 = load i64, ptr %t473, !tbaa !24
  %t475 = load i64, ptr @G_2ecompiler_2folang_2eLsp, !tbaa !24
  %t478 = icmp eq i64 %t474, %t475
  store i1 %t478, ptr %l151, !tbaa !21
  br label %bb119
bb119:
  %t480 = load i1, ptr %l151, !tbaa !21
  br i1 %t480, label %bb120, label %bb121
bb120:
  store i1 true, ptr %l155, !tbaa !21
  br label %bb122
bb121:
  %t481 = load ptr, ptr %lp3
  %t482 = getelementptr %"compiler/olang:CommandLine", ptr %t481, i32 0, i32 0
  %t483 = load i64, ptr %t482, !tbaa !24
  %t484 = load i64, ptr @G_2ecompiler_2folang_2eMcp, !tbaa !24
  %t487 = icmp eq i64 %t483, %t484
  store i1 %t487, ptr %l155, !tbaa !21
  br label %bb122
bb122:
  %t489 = load i1, ptr %l155, !tbaa !21
  store i1 %t489, ptr %l4, !tbaa !21
  %t490 = load ptr, ptr %l1, !tbaa !29
  store ptr %t490, ptr %l159, !tbaa !29
  %t491 = load ptr, ptr %lp3
  %t492 = getelementptr %"compiler/olang:CommandLine", ptr %t491, i32 0, i32 6
  %t493 = load { i64, ptr }, ptr %t492, !tbaa !27
  store { i64, ptr } %t493, ptr %l161, !tbaa !27
  %t494 = load ptr, ptr %l1, !tbaa !29
  %t496 = getelementptr %"compiler/build:Config", ptr %t494, i32 0, i32 1
  %t497 = load { i64, ptr }, ptr %t496, !tbaa !27
  store { i64, ptr } %t497, ptr %l163, !tbaa !27
  %t498 = load ptr, ptr %lp3
  %t499 = getelementptr %"compiler/olang:CommandLine", ptr %t498, i32 0, i32 0
  %t500 = load i64, ptr %t499, !tbaa !24
  %t501 = load i64, ptr @G_2ecompiler_2folang_2eInterp, !tbaa !24
  %t504 = icmp eq i64 %t500, %t501
  br i1 %t504, label %bb123, label %bb124
bb123:
  store i1 true, ptr %l167, !tbaa !21
  br label %bb129
bb124:
  %t506 = load i1, ptr %l4, !tbaa !21
  br i1 %t506, label %bb125, label %bb126
bb125:
  %t508 = load ptr, ptr %l1, !tbaa !29
  %t510 = getelementptr %"compiler/build:Config", ptr %t508, i32 0, i32 1
  %t511 = load { i64, ptr }, ptr %t510, !tbaa !27
  %t513 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t511, { i64, ptr } { i64 0, ptr @.d77 })
  store i1 %t513, ptr %l172
  br label %bb127
bb126:
  store i1 false, ptr %l169, !tbaa !21
  br label %bb128
bb127:
  %t514 = load i1, ptr %l172, !tbaa !21
  store i1 %t514, ptr %l169, !tbaa !21
  br label %bb128
bb128:
  %t515 = load i1, ptr %l169, !tbaa !21
  store i1 %t515, ptr %l167, !tbaa !21
  br label %bb129
bb129:
  %t516 = load ptr, ptr %l2, !tbaa !29
  %t517 = load { i64, ptr }, ptr %l161, !tbaa !27
  %t518 = load { i64, ptr }, ptr %l163, !tbaa !27
  %t519 = load i1, ptr %l167, !tbaa !21
  %t521 = call { i32, %"compiler/target:Target" } @compiler_2ftarget_2eResolve(ptr %v3, ptr %v1, ptr %v2, ptr %v1, { i64, ptr } %t517, { i64, ptr } %t518, i1 %t519, ptr %t516)
  %t522 = extractvalue { i32, %"compiler/target:Target" } %t521, 1
  %t523 = extractvalue { i32, %"compiler/target:Target" } %t521, 0
  store i32 %t523, ptr %l175
  %t524 = icmp ne i32 %t523, 0
  br i1 %t524, label %bb131, label %ok.525
ok.525:
  store %"compiler/target:Target" %t522, ptr %l174
  br label %bb130
bb130:
  %t526 = load %"compiler/target:Target", ptr %l174
  store %"compiler/target:Target" %t526, ptr %l160
  br label %bb135
bb131:
  %t527 = load i32, ptr %l175, !tbaa !23
  %t528 = ashr i32 %t527, 16
  %t530 = icmp eq i32 %t528, 1
  br i1 %t530, label %bb132, label %bb133
bb132:
  br label %bb134
bb133:
  %t532 = load i32, ptr %l175, !tbaa !23
  %t533 = lshr i32 %t532, 16
  %t534 = and i32 %t532, 65535
  %t535 = icmp eq i32 %t533, 1
  %t536 = select i1 %t535, i32 0, i32 0
  %t537 = icmp eq i32 %t532, 0
  %t538 = shl i32 %t536, 16
  %t539 = or i32 %t538, %t534
  %t540 = select i1 %t537, i32 0, i32 %t539
  call void @__olang_scope_close(ptr %s0)
  %t542 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t540, 0
  store { i32, %"compiler/olang:CommandLine" } %t542, ptr %rv
  br label %ret
bb134:
  call void @__olang_scope_close(ptr %s0)
  %t544 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/olang:CommandLine" } %t544, ptr %rv
  br label %ret
bb135:
  %t545 = load %"compiler/target:Target", ptr %l160
  %t546 = load ptr, ptr %l159, !tbaa !29
  %t547 = getelementptr %"compiler/build:Config", ptr %t546, i32 0, i32 2
  store %"compiler/target:Target" %t545, ptr %t547
  %t548 = load ptr, ptr %l1, !tbaa !29
  %t550 = getelementptr %"compiler/build:Config", ptr %t548, i32 0, i32 2
  %t551 = getelementptr %"compiler/target:Target", ptr %t550, i32 0, i32 9
  %t552 = load i1, ptr %t551, !tbaa !21
  br i1 %t552, label %bb136, label %bb137
bb136:
  %t554 = load ptr, ptr %lp3
  %t555 = getelementptr %"compiler/olang:CommandLine", ptr %t554, i32 0, i32 0
  %t556 = load i64, ptr %t555, !tbaa !24
  %t557 = load i64, ptr @G_2ecompiler_2folang_2eCompile, !tbaa !24
  %t560 = icmp ne i64 %t556, %t557
  store i1 %t560, ptr %l182, !tbaa !21
  br label %bb138
bb137:
  store i1 false, ptr %l182, !tbaa !21
  br label %bb138
bb138:
  %t562 = load i1, ptr %l182, !tbaa !21
  br i1 %t562, label %bb139, label %bb140
bb139:
  store %olang.scope zeroinitializer, ptr %s14
  %t563 = load ptr, ptr %l2, !tbaa !29
  store ptr %t563, ptr %l186, !tbaa !29
  %t564 = load ptr, ptr %lp3
  %t565 = getelementptr %"compiler/olang:CommandLine", ptr %t564, i32 0, i32 0
  %t566 = load i64, ptr %t565, !tbaa !24
  %t568 = call { i64, ptr } @compiler_2folang_2emodeName(ptr %s14, i64 %t566)
  store { i64, ptr } %t568, ptr %l188
  br label %bb141
bb140:
  br label %bb146
bb141:
  %t569 = load { i64, ptr }, ptr %l188, !tbaa !27
  %t570 = extractvalue { i64, ptr } %t569, 0
  %t571 = extractvalue { i64, ptr } %t569, 1
  %t572 = mul i64 %t570, 1
  %t573 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t572)
  call void @llvm.memcpy.p0.p0.i64(ptr %t573, ptr %t571, i64 %t572, i1 false)
  %t574 = insertvalue { i64, ptr } undef, i64 %t570, 0
  %t575 = insertvalue { i64, ptr } %t574, ptr %t573, 1
  %t576 = load ptr, ptr %lp3
  %t577 = getelementptr %"compiler/olang:CommandLine", ptr %t576, i32 0, i32 6
  %t578 = load { i64, ptr }, ptr %t577, !tbaa !27
  %t581 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetForeignMode(ptr %s14, ptr %v3, ptr %s14, { i64, ptr } %t575, { i64, ptr } %t578)
  store %"compiler/msgs:Msg" %t581, ptr %l191
  br label %bb142
bb142:
  %t582 = load ptr, ptr %l186, !tbaa !29
  %t583 = load %"compiler/msgs:Msg", ptr %l191
  %t584 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s14, ptr %t582, %"compiler/msgs:Msg" %t583)
  store i32 %t584, ptr %l192
  %t585 = icmp ne i32 %t584, 0
  br i1 %t585, label %bb144, label %ok.586
ok.586:
  br label %bb143
bb143:
  br label %bb145
bb144:
  %t587 = load i32, ptr %l192, !tbaa !23
  %t588 = lshr i32 %t587, 16
  %t589 = and i32 %t587, 65535
  %t590 = icmp eq i32 %t588, 1
  %t591 = select i1 %t590, i32 1, i32 0
  %t592 = icmp eq i32 %t587, 0
  %t593 = shl i32 %t591, 16
  %t594 = or i32 %t593, %t589
  %t595 = select i1 %t592, i32 0, i32 %t594
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s0)
  %t597 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t595, 0
  store { i32, %"compiler/olang:CommandLine" } %t597, ptr %rv
  br label %ret
bb145:
  call void @__olang_scope_close(ptr %s14)
  br label %bb146
bb146:
  %t598 = load ptr, ptr %l1, !tbaa !29
  %t599 = load ptr, ptr %lp3
  %t600 = getelementptr %"compiler/olang:CommandLine", ptr %t599, i32 0, i32 0
  %t601 = load i64, ptr %t600, !tbaa !24
  %t602 = load i64, ptr @G_2ecompiler_2folang_2eTest, !tbaa !24
  %t605 = icmp eq i64 %t601, %t602
  %t608 = getelementptr %"compiler/build:Config", ptr %t598, i32 0, i32 9
  store i1 %t605, ptr %t608, !tbaa !21
  %t609 = load ptr, ptr %l1, !tbaa !29
  store ptr %t609, ptr %l198, !tbaa !29
  %t610 = load ptr, ptr %l1, !tbaa !29
  %t612 = getelementptr %"compiler/build:Config", ptr %t610, i32 0, i32 9
  %t613 = load i1, ptr %t612, !tbaa !21
  br i1 %t613, label %bb147, label %bb148
bb147:
  store i1 true, ptr %l201, !tbaa !21
  br label %bb149
bb148:
  %t615 = load ptr, ptr %lp3
  %t616 = getelementptr %"compiler/olang:CommandLine", ptr %t615, i32 0, i32 0
  %t617 = load i64, ptr %t616, !tbaa !24
  %t618 = load i64, ptr @G_2ecompiler_2folang_2eLsp, !tbaa !24
  %t621 = icmp eq i64 %t617, %t618
  store i1 %t621, ptr %l201, !tbaa !21
  br label %bb149
bb149:
  %t623 = load i1, ptr %l201, !tbaa !21
  br i1 %t623, label %bb150, label %bb151
bb150:
  store i1 true, ptr %l205, !tbaa !21
  br label %bb152
bb151:
  %t624 = load ptr, ptr %lp3
  %t625 = getelementptr %"compiler/olang:CommandLine", ptr %t624, i32 0, i32 0
  %t626 = load i64, ptr %t625, !tbaa !24
  %t627 = load i64, ptr @G_2ecompiler_2folang_2eMcp, !tbaa !24
  %t630 = icmp eq i64 %t626, %t627
  store i1 %t630, ptr %l205, !tbaa !21
  br label %bb152
bb152:
  %t632 = load ptr, ptr %l2, !tbaa !29
  %t633 = load ptr, ptr %l198, !tbaa !29
  %t634 = load i1, ptr %l205, !tbaa !21
  %t636 = call i32 @compiler_2folang_2ebuiltins(ptr %v1, ptr %v2, ptr %t633, i1 %t634, ptr %t632)
  store i32 %t636, ptr %l210
  %t637 = icmp ne i32 %t636, 0
  br i1 %t637, label %bb154, label %ok.638
ok.638:
  br label %bb153
bb153:
  br label %bb155
bb154:
  %t639 = load i32, ptr %l210, !tbaa !23
  %t640 = lshr i32 %t639, 16
  %t641 = and i32 %t639, 65535
  %t642 = icmp eq i32 %t640, 1
  %t643 = select i1 %t642, i32 1, i32 0
  %t644 = icmp eq i32 %t639, 0
  %t645 = shl i32 %t643, 16
  %t646 = or i32 %t645, %t641
  %t647 = select i1 %t644, i32 0, i32 %t646
  call void @__olang_scope_close(ptr %s0)
  %t649 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t647, 0
  store { i32, %"compiler/olang:CommandLine" } %t649, ptr %rv
  br label %ret
bb155:
  %t650 = load ptr, ptr %lp3
  %t651 = load %"compiler/olang:CommandLine", ptr %t650
  call void @__olang_scope_close(ptr %s0)
  %t653 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, %"compiler/olang:CommandLine" %t651, 1
  store { i32, %"compiler/olang:CommandLine" } %t653, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/olang:CommandLine" }, ptr %rv
  ret { i32, %"compiler/olang:CommandLine" } %rr
}

define dso_local void @compiler_2folang_2eRun_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr @G_2ecompiler_2folang_2eRun, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eTest_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 3, ptr @G_2ecompiler_2folang_2eTest, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2folang_2ebuildInputs(ptr %v0, ptr %v1, ptr %a0, i1 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"std/os:FileInfo"
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/target:Target"
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i32
  %l9 = alloca { i64, ptr }
  %l12 = alloca %"std/os:FileInfo"
  %l14 = alloca %"std/os:FileInfo"
  %l15 = alloca i32
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i32
  %l25 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca i64
  %l34 = alloca i1
  %l36 = alloca i1
  %l38 = alloca i1
  %l40 = alloca i1
  %l41 = alloca i1
  %l42 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %s0, ptr %s0, { i64, ptr } { i64 14, ptr @.d78 })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l8
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  store { i64, ptr } %t2, ptr %l7
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t6, ptr %l6, !tbaa !27
  br label %bb4
bb2:
  br label %bb3
bb3:
  store { i64, ptr } { i64 0, ptr @.d79 }, ptr %l9, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t10 = extractvalue { i64, ptr } %t7, 1
  %t11 = mul i64 %t9, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t10, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l6, !tbaa !27
  br label %bb4
bb4:
  %t16 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t16, ptr %l2, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t19 = call { i32, %"std/os:FileInfo" } @std_2fos_2eStat(ptr %s0, { i64, ptr } %t17)
  %t20 = extractvalue { i32, %"std/os:FileInfo" } %t19, 1
  %t21 = extractvalue { i32, %"std/os:FileInfo" } %t19, 0
  store i32 %t21, ptr %l15
  %t22 = icmp ne i32 %t21, 0
  br i1 %t22, label %bb6, label %ok.23
ok.23:
  store %"std/os:FileInfo" %t20, ptr %l14
  br label %bb5
bb5:
  %t24 = load %"std/os:FileInfo", ptr %l14
  store %"std/os:FileInfo" %t24, ptr %l12
  br label %bb10
bb6:
  %t25 = load i32, ptr %l15, !tbaa !23
  %t26 = ashr i32 %t25, 16
  %t28 = icmp eq i32 %t26, 1
  br i1 %t28, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_75a15dc32bd9c62d_7df2e713047d6551)
  unreachable
bb9:
  store { i64, ptr } { i64 0, ptr @.d80 }, ptr %l18, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t30, ptr %l19, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l20, !tbaa !24
  %t33 = load i64, ptr %l20, !tbaa !24
  %t34 = mul i64 %t33, 1
  %t35 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t34)
  %t36 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t35, 1
  store { i64, ptr } %t37, ptr %l21, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = load i64, ptr %l20, !tbaa !24
  %t43 = mul i64 %t42, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t39, ptr %t41, i64 %t43, i1 false)
  %t44 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t44, ptr %l19, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t45 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t45, ptr %rv
  br label %ret
bb10:
  %t46 = load %"std/os:FileInfo", ptr %l12
  store %"std/os:FileInfo" %t46, ptr %l3
  %t47 = call { i32, { i64, ptr } } @std_2fos_2eCwd(ptr %s0)
  %t48 = extractvalue { i32, { i64, ptr } } %t47, 1
  %t49 = extractvalue { i32, { i64, ptr } } %t47, 0
  store i32 %t49, ptr %l24
  %t50 = icmp ne i32 %t49, 0
  br i1 %t50, label %bb12, label %ok.51
ok.51:
  store { i64, ptr } %t48, ptr %l23
  br label %bb11
bb11:
  %t52 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t52, ptr %l22, !tbaa !27
  br label %bb14
bb12:
  br label %bb13
bb13:
  store { i64, ptr } { i64 0, ptr @.d81 }, ptr %l25, !tbaa !27
  %t53 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t53, 0
  %t56 = extractvalue { i64, ptr } %t53, 1
  %t57 = mul i64 %t55, 1
  %t58 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t57)
  call void @llvm.memcpy.p0.p0.i64(ptr %t58, ptr %t56, i64 %t57, i1 false)
  %t59 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t58, 1
  store { i64, ptr } %t60, ptr %l22, !tbaa !27
  br label %bb14
bb14:
  %t62 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t62, ptr %l4, !tbaa !27
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/build:Config", ptr %t63, i32 0, i32 2
  %t66 = load %"compiler/target:Target", ptr %t65
  store %"compiler/target:Target" %t66, ptr %l5
  %t68 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t68, ptr %l30, !tbaa !27
  %t69 = getelementptr %"std/os:FileInfo", ptr %l3, i32 0, i32 1
  %t70 = load i64, ptr %t69, !tbaa !24
  store i64 %t70, ptr %l31, !tbaa !24
  %t71 = getelementptr %"std/os:FileInfo", ptr %l3, i32 0, i32 2
  %t72 = load i64, ptr %t71, !tbaa !24
  store i64 %t72, ptr %l32, !tbaa !24
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/build:Config", ptr %t73, i32 0, i32 4
  %t76 = load i1, ptr %t75, !tbaa !21
  store i1 %t76, ptr %l34, !tbaa !21
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/build:Config", ptr %t77, i32 0, i32 6
  %t80 = load i1, ptr %t79, !tbaa !21
  store i1 %t80, ptr %l36, !tbaa !21
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/build:Config", ptr %t81, i32 0, i32 7
  %t84 = load i1, ptr %t83, !tbaa !21
  store i1 %t84, ptr %l38, !tbaa !21
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/build:Config", ptr %t85, i32 0, i32 5
  %t88 = load i1, ptr %t87, !tbaa !21
  store i1 %t88, ptr %l40, !tbaa !21
  store i1 %a1, ptr %l41, !tbaa !21
  %t90 = getelementptr %"compiler/target:Target", ptr %l5, i32 0, i32 1
  %t91 = load { i64, ptr }, ptr %t90, !tbaa !27
  store { i64, ptr } %t91, ptr %l42, !tbaa !27
  %t92 = getelementptr %"compiler/target:Target", ptr %l5, i32 0, i32 2
  %t93 = load { i64, ptr }, ptr %t92, !tbaa !27
  store { i64, ptr } %t93, ptr %l43, !tbaa !27
  %t94 = getelementptr %"compiler/target:Target", ptr %l5, i32 0, i32 4
  %t95 = load { i64, ptr }, ptr %t94, !tbaa !27
  store { i64, ptr } %t95, ptr %l44, !tbaa !27
  %t96 = getelementptr %"compiler/target:Target", ptr %l5, i32 0, i32 5
  %t97 = load { i64, ptr }, ptr %t96, !tbaa !27
  store { i64, ptr } %t97, ptr %l45, !tbaa !27
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/build:Config", ptr %t98, i32 0, i32 3
  %t102 = call { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eFingerprint(ptr %v0, ptr %s0, ptr %t100)
  store { i64, ptr } %t102, ptr %l48
  br label %bb15
bb15:
  %t103 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t103, ptr %l49, !tbaa !27
  %t104 = call { i64, ptr } @compiler_2fload_2eStdDir(ptr %s0)
  store { i64, ptr } %t104, ptr %l50
  br label %bb16
bb16:
  %t105 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t105, 1
  %t107 = extractvalue { i64, ptr } %t105, 0
  %t108 = extractvalue { i64, ptr } { i64 1, ptr @.d82 }, 1
  %t109 = extractvalue { i64, ptr } { i64 1, ptr @.d82 }, 0
  %t110 = add i64 %t107, %t109
  %t111 = load i64, ptr %l31, !tbaa !24
  %t112 = call i64 @__olang_fmt_i64(ptr null, i64 %t111)
  %t113 = add i64 %t110, %t112
  %t114 = extractvalue { i64, ptr } { i64 1, ptr @.d83 }, 1
  %t115 = extractvalue { i64, ptr } { i64 1, ptr @.d83 }, 0
  %t116 = add i64 %t113, %t115
  %t117 = load i64, ptr %l32, !tbaa !24
  %t118 = call i64 @__olang_fmt_i64(ptr null, i64 %t117)
  %t119 = add i64 %t116, %t118
  %t120 = extractvalue { i64, ptr } { i64 1, ptr @.d84 }, 1
  %t121 = extractvalue { i64, ptr } { i64 1, ptr @.d84 }, 0
  %t122 = add i64 %t119, %t121
  %t123 = load i1, ptr %l34, !tbaa !21
  %t124 = select i1 %t123, ptr @.c85, ptr @.c86
  %t125 = select i1 %t123, i64 4, i64 5
  %t126 = add i64 %t122, %t125
  %t127 = extractvalue { i64, ptr } { i64 1, ptr @.d87 }, 1
  %t128 = extractvalue { i64, ptr } { i64 1, ptr @.d87 }, 0
  %t129 = add i64 %t126, %t128
  %t130 = load i1, ptr %l36, !tbaa !21
  %t131 = select i1 %t130, ptr @.c85, ptr @.c86
  %t132 = select i1 %t130, i64 4, i64 5
  %t133 = add i64 %t129, %t132
  %t134 = extractvalue { i64, ptr } { i64 1, ptr @.d88 }, 1
  %t135 = extractvalue { i64, ptr } { i64 1, ptr @.d88 }, 0
  %t136 = add i64 %t133, %t135
  %t137 = load i1, ptr %l38, !tbaa !21
  %t138 = select i1 %t137, ptr @.c85, ptr @.c86
  %t139 = select i1 %t137, i64 4, i64 5
  %t140 = add i64 %t136, %t139
  %t141 = extractvalue { i64, ptr } { i64 1, ptr @.d89 }, 1
  %t142 = extractvalue { i64, ptr } { i64 1, ptr @.d89 }, 0
  %t143 = add i64 %t140, %t142
  %t144 = load i1, ptr %l40, !tbaa !21
  %t145 = select i1 %t144, ptr @.c85, ptr @.c86
  %t146 = select i1 %t144, i64 4, i64 5
  %t147 = add i64 %t143, %t146
  %t148 = extractvalue { i64, ptr } { i64 1, ptr @.d90 }, 1
  %t149 = extractvalue { i64, ptr } { i64 1, ptr @.d90 }, 0
  %t150 = add i64 %t147, %t149
  %t151 = load i1, ptr %l41, !tbaa !21
  %t152 = select i1 %t151, ptr @.c85, ptr @.c86
  %t153 = select i1 %t151, i64 4, i64 5
  %t154 = add i64 %t150, %t153
  %t155 = extractvalue { i64, ptr } { i64 1, ptr @.d91 }, 1
  %t156 = extractvalue { i64, ptr } { i64 1, ptr @.d91 }, 0
  %t157 = add i64 %t154, %t156
  %t158 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t159 = extractvalue { i64, ptr } %t158, 1
  %t160 = extractvalue { i64, ptr } %t158, 0
  %t161 = add i64 %t157, %t160
  %t162 = extractvalue { i64, ptr } { i64 1, ptr @.d92 }, 1
  %t163 = extractvalue { i64, ptr } { i64 1, ptr @.d92 }, 0
  %t164 = add i64 %t161, %t163
  %t165 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t166 = extractvalue { i64, ptr } %t165, 1
  %t167 = extractvalue { i64, ptr } %t165, 0
  %t168 = add i64 %t164, %t167
  %t169 = extractvalue { i64, ptr } { i64 1, ptr @.d93 }, 1
  %t170 = extractvalue { i64, ptr } { i64 1, ptr @.d93 }, 0
  %t171 = add i64 %t168, %t170
  %t172 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t173 = extractvalue { i64, ptr } %t172, 1
  %t174 = extractvalue { i64, ptr } %t172, 0
  %t175 = add i64 %t171, %t174
  %t176 = extractvalue { i64, ptr } { i64 1, ptr @.d94 }, 1
  %t177 = extractvalue { i64, ptr } { i64 1, ptr @.d94 }, 0
  %t178 = add i64 %t175, %t177
  %t179 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t180 = extractvalue { i64, ptr } %t179, 1
  %t181 = extractvalue { i64, ptr } %t179, 0
  %t182 = add i64 %t178, %t181
  %t183 = extractvalue { i64, ptr } { i64 1, ptr @.d95 }, 1
  %t184 = extractvalue { i64, ptr } { i64 1, ptr @.d95 }, 0
  %t185 = add i64 %t182, %t184
  %t186 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t187 = extractvalue { i64, ptr } %t186, 1
  %t188 = extractvalue { i64, ptr } %t186, 0
  %t189 = add i64 %t185, %t188
  %t190 = extractvalue { i64, ptr } { i64 1, ptr @.d96 }, 1
  %t191 = extractvalue { i64, ptr } { i64 1, ptr @.d96 }, 0
  %t192 = add i64 %t189, %t191
  %t193 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t194 = extractvalue { i64, ptr } %t193, 1
  %t195 = extractvalue { i64, ptr } %t193, 0
  %t196 = add i64 %t192, %t195
  %t197 = extractvalue { i64, ptr } { i64 1, ptr @.d97 }, 1
  %t198 = extractvalue { i64, ptr } { i64 1, ptr @.d97 }, 0
  %t199 = add i64 %t196, %t198
  %t200 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t201 = extractvalue { i64, ptr } %t200, 1
  %t202 = extractvalue { i64, ptr } %t200, 0
  %t203 = add i64 %t199, %t202
  %t204 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t203)
  call void @olang_textcopy(ptr %t204, ptr %t106, i64 %t107)
  %t205 = getelementptr i8, ptr %t204, i64 %t107
  call void @olang_textcopy(ptr %t205, ptr %t108, i64 %t109)
  %t206 = getelementptr i8, ptr %t205, i64 %t109
  %t207 = call i64 @__olang_fmt_i64(ptr %t206, i64 %t111)
  %t208 = getelementptr i8, ptr %t206, i64 %t112
  call void @olang_textcopy(ptr %t208, ptr %t114, i64 %t115)
  %t209 = getelementptr i8, ptr %t208, i64 %t115
  %t210 = call i64 @__olang_fmt_i64(ptr %t209, i64 %t117)
  %t211 = getelementptr i8, ptr %t209, i64 %t118
  call void @olang_textcopy(ptr %t211, ptr %t120, i64 %t121)
  %t212 = getelementptr i8, ptr %t211, i64 %t121
  call void @olang_textcopy(ptr %t212, ptr %t124, i64 %t125)
  %t213 = getelementptr i8, ptr %t212, i64 %t125
  call void @olang_textcopy(ptr %t213, ptr %t127, i64 %t128)
  %t214 = getelementptr i8, ptr %t213, i64 %t128
  call void @olang_textcopy(ptr %t214, ptr %t131, i64 %t132)
  %t215 = getelementptr i8, ptr %t214, i64 %t132
  call void @olang_textcopy(ptr %t215, ptr %t134, i64 %t135)
  %t216 = getelementptr i8, ptr %t215, i64 %t135
  call void @olang_textcopy(ptr %t216, ptr %t138, i64 %t139)
  %t217 = getelementptr i8, ptr %t216, i64 %t139
  call void @olang_textcopy(ptr %t217, ptr %t141, i64 %t142)
  %t218 = getelementptr i8, ptr %t217, i64 %t142
  call void @olang_textcopy(ptr %t218, ptr %t145, i64 %t146)
  %t219 = getelementptr i8, ptr %t218, i64 %t146
  call void @olang_textcopy(ptr %t219, ptr %t148, i64 %t149)
  %t220 = getelementptr i8, ptr %t219, i64 %t149
  call void @olang_textcopy(ptr %t220, ptr %t152, i64 %t153)
  %t221 = getelementptr i8, ptr %t220, i64 %t153
  call void @olang_textcopy(ptr %t221, ptr %t155, i64 %t156)
  %t222 = getelementptr i8, ptr %t221, i64 %t156
  call void @olang_textcopy(ptr %t222, ptr %t159, i64 %t160)
  %t223 = getelementptr i8, ptr %t222, i64 %t160
  call void @olang_textcopy(ptr %t223, ptr %t162, i64 %t163)
  %t224 = getelementptr i8, ptr %t223, i64 %t163
  call void @olang_textcopy(ptr %t224, ptr %t166, i64 %t167)
  %t225 = getelementptr i8, ptr %t224, i64 %t167
  call void @olang_textcopy(ptr %t225, ptr %t169, i64 %t170)
  %t226 = getelementptr i8, ptr %t225, i64 %t170
  call void @olang_textcopy(ptr %t226, ptr %t173, i64 %t174)
  %t227 = getelementptr i8, ptr %t226, i64 %t174
  call void @olang_textcopy(ptr %t227, ptr %t176, i64 %t177)
  %t228 = getelementptr i8, ptr %t227, i64 %t177
  call void @olang_textcopy(ptr %t228, ptr %t180, i64 %t181)
  %t229 = getelementptr i8, ptr %t228, i64 %t181
  call void @olang_textcopy(ptr %t229, ptr %t183, i64 %t184)
  %t230 = getelementptr i8, ptr %t229, i64 %t184
  call void @olang_textcopy(ptr %t230, ptr %t187, i64 %t188)
  %t231 = getelementptr i8, ptr %t230, i64 %t188
  call void @olang_textcopy(ptr %t231, ptr %t190, i64 %t191)
  %t232 = getelementptr i8, ptr %t231, i64 %t191
  call void @olang_textcopy(ptr %t232, ptr %t194, i64 %t195)
  %t233 = getelementptr i8, ptr %t232, i64 %t195
  call void @olang_textcopy(ptr %t233, ptr %t197, i64 %t198)
  %t234 = getelementptr i8, ptr %t233, i64 %t198
  call void @olang_textcopy(ptr %t234, ptr %t201, i64 %t202)
  %t235 = insertvalue { i64, ptr } undef, i64 %t203, 0
  %t236 = insertvalue { i64, ptr } %t235, ptr %t204, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t236, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2folang_2ebuiltins(ptr %v0, ptr %v1, ptr %a0, i1 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/target:Target"
  %l22 = alloca i1
  %l23 = alloca ptr
  %l25 = alloca %"compiler/msgs:Msg"
  %l26 = alloca i32
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l39 = alloca i64
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = insertvalue [8 x { i64, ptr }] undef, { i64, ptr } { i64 8, ptr @.d98 }, 0
  %t2 = insertvalue [8 x { i64, ptr }] %t1, { i64, ptr } { i64 10, ptr @.d99 }, 1
  %t3 = insertvalue [8 x { i64, ptr }] %t2, { i64, ptr } { i64 9, ptr @.d100 }, 2
  %t4 = insertvalue [8 x { i64, ptr }] %t3, { i64, ptr } { i64 16, ptr @.d101 }, 3
  %t5 = insertvalue [8 x { i64, ptr }] %t4, { i64, ptr } { i64 12, ptr @.d102 }, 4
  %t6 = insertvalue [8 x { i64, ptr }] %t5, { i64, ptr } { i64 10, ptr @.d103 }, 5
  %t7 = insertvalue [8 x { i64, ptr }] %t6, { i64, ptr } { i64 9, ptr @.d104 }, 6
  %t8 = insertvalue [8 x { i64, ptr }] %t7, { i64, ptr } { i64 9, ptr @.d105 }, 7
  %t10 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 128, i64 8)
  store [8 x { i64, ptr }] %t8, ptr %t10
  store ptr %t10, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  %t12 = load ptr, ptr %l3
  store i64 8, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t15 = load i64, ptr %l4, !tbaa !24
  %t16 = load i64, ptr %l5, !tbaa !24
  %t19 = icmp slt i64 %t15, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb3:
  br label %bb4
bb4:
  %t23 = load ptr, ptr %l3
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = getelementptr [8 x { i64, ptr }], ptr %t23, i64 0, i64 %t24
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !37
  store { i64, ptr } %t28, ptr %l6, !tbaa !27
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/build:Config", ptr %t30, i32 0, i32 3
  %t33 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t34 = load ptr, ptr @__olang_prog_scope
  %t37 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eHas(ptr %v0, ptr %t34, ptr %t32, { i64, ptr } %t33)
  store i1 %t37, ptr %l22
  br label %bb5
bb5:
  %t38 = load i1, ptr %l22, !tbaa !21
  br i1 %t38, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  store ptr %a2, ptr %l23, !tbaa !29
  %t40 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t41 = load ptr, ptr @__olang_prog_scope
  %t43 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefineBuiltin(ptr %t41, ptr %s3, { i64, ptr } %t40)
  store %"compiler/msgs:Msg" %t43, ptr %l25
  br label %bb8
bb7:
  br label %bb12
bb8:
  %t44 = load ptr, ptr %l23, !tbaa !29
  %t45 = load %"compiler/msgs:Msg", ptr %l25
  %t46 = call i32 @compiler_2folang_2eusage(ptr %v1, ptr %s3, ptr %t44, %"compiler/msgs:Msg" %t45)
  store i32 %t46, ptr %l26
  %t47 = icmp ne i32 %t46, 0
  br i1 %t47, label %bb10, label %ok.48
ok.48:
  br label %bb9
bb9:
  br label %bb11
bb10:
  %t49 = load i32, ptr %l26, !tbaa !23
  %t50 = lshr i32 %t49, 16
  %t51 = and i32 %t49, 65535
  %t52 = icmp eq i32 %t50, 1
  %t53 = select i1 %t52, i32 1, i32 0
  %t54 = icmp eq i32 %t49, 0
  %t55 = shl i32 %t53, 16
  %t56 = or i32 %t55, %t51
  %t57 = select i1 %t54, i32 0, i32 %t56
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  store i32 %t57, ptr %rv
  br label %ret
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb13:
  %t59 = load i64, ptr %l4, !tbaa !24
  %t61 = add i64 %t59, 1
  store i64 %t61, ptr %l4, !tbaa !24
  br label %bb1
bb14:
  call void @__olang_scope_close(ptr %s1)
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/build:Config", ptr %t63, i32 0, i32 2
  %t66 = load %"compiler/target:Target", ptr %t65
  store %"compiler/target:Target" %t66, ptr %l7
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/build:Config", ptr %t68, i32 0, i32 3
  store ptr %t70, ptr %l33, !tbaa !29
  %t71 = getelementptr %"compiler/target:Target", ptr %l7, i32 0, i32 3
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !27
  store { i64, ptr } %t72, ptr %l34, !tbaa !27
  %t73 = getelementptr %"compiler/target:Target", ptr %l7, i32 0, i32 2
  %t74 = load { i64, ptr }, ptr %t73, !tbaa !27
  store { i64, ptr } %t74, ptr %l35, !tbaa !27
  %t75 = getelementptr %"compiler/target:Target", ptr %l7, i32 0, i32 4
  %t76 = load { i64, ptr }, ptr %t75, !tbaa !27
  store { i64, ptr } %t76, ptr %l36, !tbaa !27
  %t77 = getelementptr %"compiler/target:Target", ptr %l7, i32 0, i32 7
  %t78 = load i64, ptr %t77, !tbaa !24
  store i64 %t78, ptr %l37, !tbaa !24
  %t79 = getelementptr %"compiler/target:Target", ptr %l7, i32 0, i32 8
  %t80 = load i1, ptr %t79, !tbaa !21
  br i1 %t80, label %bb15, label %bb16
bb15:
  store i64 1, ptr %l39, !tbaa !24
  br label %bb17
bb16:
  store i64 0, ptr %l39, !tbaa !24
  br label %bb17
bb17:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/build:Config", ptr %t82, i32 0, i32 4
  %t85 = load i1, ptr %t84, !tbaa !21
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/build:Config", ptr %t86, i32 0, i32 6
  %t89 = load i1, ptr %t88, !tbaa !21
  %t91 = load ptr, ptr %l33, !tbaa !29
  %t92 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t93 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t94 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t95 = load i64, ptr %l37, !tbaa !24
  %t96 = load i64, ptr %l39, !tbaa !24
  call void @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eBuiltins(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t91, { i64, ptr } %t92, { i64, ptr } %t93, { i64, ptr } %t94, i64 %t95, i64 %t96, i1 %t85, i1 %t89, i1 %a1)
  br label %bb18
bb18:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2folang_2echeckOutput(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l5 = alloca i1
  %l6 = alloca ptr
  %l8 = alloca %"compiler/msgs:Msg"
  %l9 = alloca i32
  %l11 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i64
  %l32 = alloca i1
  %l34 = alloca ptr
  %l37 = alloca %"compiler/msgs:Msg"
  %l38 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i32
  store { i64, ptr } %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fos_2eIsDir(ptr %v0, { i64, ptr } %t1)
  store i1 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i1, ptr %l5, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l6, !tbaa !29
  %t6 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eOutputIsDir(ptr %v0, ptr %s1, { i64, ptr } %t6)
  store %"compiler/msgs:Msg" %t8, ptr %l8
  br label %bb4
bb3:
  br label %bb8
bb4:
  %t9 = load ptr, ptr %l6, !tbaa !29
  %t10 = load %"compiler/msgs:Msg", ptr %l8
  %t11 = call i32 @compiler_2folang_2eusage(ptr %v1, ptr %s1, ptr %t9, %"compiler/msgs:Msg" %t10)
  store i32 %t11, ptr %l9
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb6, label %ok.13
ok.13:
  br label %bb5
bb5:
  br label %bb7
bb6:
  %t14 = load i32, ptr %l9, !tbaa !23
  %t15 = lshr i32 %t14, 16
  %t16 = and i32 %t14, 65535
  %t17 = icmp eq i32 %t15, 1
  %t18 = select i1 %t17, i32 1, i32 0
  %t19 = icmp eq i32 %t14, 0
  %t20 = shl i32 %t18, 16
  %t21 = or i32 %t20, %t16
  %t22 = select i1 %t19, i32 0, i32 %t21
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t22, ptr %rv
  br label %ret
bb7:
  call void @__olang_scope_close(ptr %s1)
  br label %bb8
bb8:
  %t24 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t26 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %s0, { i64, ptr } %t24, { i64, ptr } { i64 1, ptr @.d106 })
  %t27 = extractvalue { i32, i64 } %t26, 1
  %t28 = extractvalue { i32, i64 } %t26, 0
  store i32 %t28, ptr %l14
  %t29 = icmp ne i32 %t28, 0
  br i1 %t29, label %bb10, label %ok.30
ok.30:
  store i64 %t27, ptr %l13
  br label %bb9
bb9:
  %t31 = load i64, ptr %l13, !tbaa !24
  store i64 %t31, ptr %l11, !tbaa !24
  br label %bb12
bb10:
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb12:
  %t32 = load i64, ptr %l11, !tbaa !24
  store i64 %t32, ptr %l2, !tbaa !24
  %t33 = load i64, ptr %l2, !tbaa !24
  %t35 = icmp eq i64 %t33, 0
  br i1 %t35, label %bb13, label %bb14
bb13:
  %t37 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t37, ptr %l18, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 0
  store i64 %t39, ptr %l19, !tbaa !24
  %t40 = icmp sge i64 0, 0
  br i1 %t40, label %bb15, label %bb16
bb14:
  %t42 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t42, ptr %l24, !tbaa !27
  %t43 = load i64, ptr %l2, !tbaa !24
  store i64 %t43, ptr %l25, !tbaa !24
  %t44 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t44, 0
  store i64 %t45, ptr %l26, !tbaa !24
  %t46 = icmp sge i64 0, 0
  br i1 %t46, label %bb21, label %bb22
bb15:
  %t48 = icmp sle i64 0, 1
  br i1 %t48, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_12131eae1fe55f7a_2d06b34e1c9e748e)
  unreachable
bb17:
  %t50 = load i64, ptr %l19, !tbaa !24
  %t51 = icmp sle i64 1, %t50
  br i1 %t51, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_12131eae1fe55f7a_2d06b34e1c9e748e)
  unreachable
bb19:
  %t53 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr i8, ptr %t54, i64 0
  %t56 = sub i64 1, 0
  %t57 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t55, 1
  store { i64, ptr } %t58, ptr %l17, !tbaa !27
  br label %bb27
bb20:
  call void @__olang_check_failed(ptr @olang_loc_12131eae1fe55f7a_2d06b34e1c9e748e)
  unreachable
bb21:
  %t60 = load i64, ptr %l25, !tbaa !24
  %t61 = icmp sle i64 0, %t60
  br i1 %t61, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_12131eae1fe55f7a_2d06b34e1c9e748e)
  unreachable
bb23:
  %t63 = load i64, ptr %l25, !tbaa !24
  %t64 = load i64, ptr %l26, !tbaa !24
  %t65 = icmp sle i64 %t63, %t64
  br i1 %t65, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_12131eae1fe55f7a_2d06b34e1c9e748e)
  unreachable
bb25:
  %t67 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !27
  %t69 = load i64, ptr %l25, !tbaa !24
  %t70 = getelementptr i8, ptr %t68, i64 0
  %t71 = sub i64 %t69, 0
  %t72 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t70, 1
  store { i64, ptr } %t73, ptr %l17, !tbaa !27
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_12131eae1fe55f7a_2d06b34e1c9e748e)
  unreachable
bb27:
  %t75 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t75, ptr %l3, !tbaa !27
  %t76 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t78 = call i1 @std_2fos_2eIsDir(ptr %v0, { i64, ptr } %t76)
  store i1 %t78, ptr %l32
  br label %bb28
bb28:
  %t79 = load i1, ptr %l32, !tbaa !21
  %t80 = xor i1 %t79, true
  br i1 %t80, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s3
  %t82 = load ptr, ptr %l1, !tbaa !29
  store ptr %t82, ptr %l34, !tbaa !29
  %t83 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t84 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t87 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eOutputNoDir(ptr %v0, ptr %v0, ptr %s3, { i64, ptr } %t83, { i64, ptr } %t84)
  store %"compiler/msgs:Msg" %t87, ptr %l37
  br label %bb31
bb30:
  br label %bb35
bb31:
  %t88 = load ptr, ptr %l34, !tbaa !29
  %t89 = load %"compiler/msgs:Msg", ptr %l37
  %t90 = call i32 @compiler_2folang_2eusage(ptr %v1, ptr %s3, ptr %t88, %"compiler/msgs:Msg" %t89)
  store i32 %t90, ptr %l38
  %t91 = icmp ne i32 %t90, 0
  br i1 %t91, label %bb33, label %ok.92
ok.92:
  br label %bb32
bb32:
  br label %bb34
bb33:
  %t93 = load i32, ptr %l38, !tbaa !23
  %t94 = lshr i32 %t93, 16
  %t95 = and i32 %t93, 65535
  %t96 = icmp eq i32 %t94, 1
  %t97 = select i1 %t96, i32 1, i32 0
  %t98 = icmp eq i32 %t93, 0
  %t99 = shl i32 %t97, 16
  %t100 = or i32 %t99, %t95
  %t101 = select i1 %t98, i32 0, i32 %t100
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t101, ptr %rv
  br label %ret
bb34:
  call void @__olang_scope_close(ptr %s3)
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2folang_2echeckReuse(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, i32 %a6, ptr %a7) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l9 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca i1
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca %"compiler/build:Unit"
  %l20 = alloca i64
  %l28 = alloca ptr
  %l30 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l32 = alloca i64
  %l35 = alloca i64
  %l38 = alloca i64
  %l42 = alloca i64
  %l45 = alloca i64
  %l63 = alloca i64
  %l66 = alloca i64
  %l71 = alloca %"compiler/build:Unit"
  %l74 = alloca %"compiler/emit:Object"
  %l77 = alloca i1
  %l79 = alloca i1
  %l82 = alloca %"compiler/emit:Object"
  %l85 = alloca i1
  %l89 = alloca %"compiler/emit:Object"
  %l93 = alloca i32
  %l101 = alloca i64
  %l103 = alloca i64
  %l106 = alloca i32
  %l111 = alloca i64
  %l114 = alloca i32
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 60
  %t5 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eLen_3cI64_2c_20I64_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l20
  br label %bb1
bb1:
  %t6 = load i64, ptr %l20, !tbaa !24
  %t7 = icmp eq i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t21 = call ptr @compiler_2folang_2eemitter(ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %a2, ptr %a3, ptr %a4, ptr %a5, i32 %a6, ptr %a7)
  store ptr %t21, ptr %l28
  br label %bb5
bb5:
  %t22 = load ptr, ptr %l28, !tbaa !29
  %t25 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2ecompiler_2femit_3aEmitter_2eObjects(ptr %v5, ptr %s0, ptr %t22)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %l30
  br label %bb6
bb6:
  %t26 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l30
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t26, ptr %l9
  %t28 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aObject_3e_2eLen_3ccompiler_2femit_3aObject_3e(ptr %s0, ptr %l9)
  store i64 %t28, ptr %l32
  br label %bb7
bb7:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr %"compiler/build:Program", ptr %t29, i32 0, i32 0
  %t33 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2eLen_3ccompiler_2fbuild_3aUnit_3e(ptr %v1, ptr %t31)
  store i64 %t33, ptr %l35
  br label %bb8
bb8:
  %t34 = load i64, ptr %l32, !tbaa !24
  %t35 = load i64, ptr %l35, !tbaa !24
  %t36 = icmp ne i64 %t34, %t35
  store i1 %t36, ptr %l10, !tbaa !21
  store i64 0, ptr %l11, !tbaa !24
  %t39 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aObject_3e_2eLen_3ccompiler_2femit_3aObject_3e(ptr %s0, ptr %l9)
  store i64 %t39, ptr %l38
  br label %bb9
bb9:
  %t40 = load i64, ptr %l38, !tbaa !24
  store i64 %t40, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t41 = load i64, ptr %l12, !tbaa !24
  %t42 = load i64, ptr %l11, !tbaa !24
  %t45 = icmp sgt i64 %t41, %t42
  br i1 %t45, label %bb10, label %bb11
bb10:
  %t47 = load i64, ptr %l13, !tbaa !24
  %t49 = icmp sgt i64 %t47, 0
  br i1 %t49, label %bb12, label %bb13
bb11:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb15
bb12:
  %t51 = load i64, ptr %l12, !tbaa !24
  %t52 = load i64, ptr %l11, !tbaa !24
  %t55 = sub i64 %t51, %t52
  %t56 = load i64, ptr %l13, !tbaa !24
  %t59 = add i64 %t55, %t56
  %t61 = sub i64 %t59, 1
  %t62 = load i64, ptr %l13, !tbaa !24
  %t65 = sdiv i64 %t61, %t62
  store i64 %t65, ptr %l45, !tbaa !24
  br label %bb14
bb13:
  store i64 0, ptr %l45, !tbaa !24
  br label %bb14
bb14:
  %t67 = load i64, ptr %l45, !tbaa !24
  store i64 %t67, ptr %l42, !tbaa !24
  br label %bb15
bb15:
  %t68 = load i64, ptr %l42, !tbaa !24
  store i64 %t68, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb16
bb16:
  store %olang.scope zeroinitializer, ptr %s3
  %t69 = load i64, ptr %l15, !tbaa !24
  %t70 = load i64, ptr %l14, !tbaa !24
  %t73 = icmp slt i64 %t69, %t70
  %t75 = xor i1 %t73, true
  br i1 %t75, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s3)
  br label %bb43
bb18:
  br label %bb19
bb19:
  %t77 = load i64, ptr %l11, !tbaa !24
  %t78 = load i64, ptr %l15, !tbaa !24
  %t79 = load i64, ptr %l13, !tbaa !24
  %t82 = mul i64 %t78, %t79
  %t85 = add i64 %t77, %t82
  store i64 %t85, ptr %l16, !tbaa !24
  %t87 = load i64, ptr %l16, !tbaa !24
  store i64 %t87, ptr %l63, !tbaa !24
  %t88 = load ptr, ptr %l1, !tbaa !29
  %t90 = getelementptr %"compiler/build:Program", ptr %t88, i32 0, i32 0
  %t92 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2eLen_3ccompiler_2fbuild_3aUnit_3e(ptr %v1, ptr %t90)
  store i64 %t92, ptr %l66
  br label %bb20
bb20:
  %t93 = load i64, ptr %l63, !tbaa !24
  %t94 = load i64, ptr %l66, !tbaa !24
  %t95 = icmp sge i64 %t93, %t94
  br i1 %t95, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s3)
  br label %bb43
bb22:
  br label %bb23
bb23:
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t99 = getelementptr %"compiler/build:Program", ptr %t97, i32 0, i32 0
  %t100 = load i64, ptr %l16, !tbaa !24
  %t103 = call %"compiler/build:Unit" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2eAt_3ccompiler_2fbuild_3aUnit_3e(ptr %v1, ptr %v1, ptr %t99, i64 %t100)
  store %"compiler/build:Unit" %t103, ptr %l71
  br label %bb24
bb24:
  %t104 = load %"compiler/build:Unit", ptr %l71
  store %"compiler/build:Unit" %t104, ptr %l17
  %t105 = load i64, ptr %l16, !tbaa !24
  %t108 = call %"compiler/emit:Object" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aObject_3e_2eAt_3ccompiler_2femit_3aObject_3e(ptr %s0, ptr %s0, ptr %l9, i64 %t105)
  store %"compiler/emit:Object" %t108, ptr %l74
  br label %bb25
bb25:
  %t109 = getelementptr %"compiler/emit:Object", ptr %l74, i32 0, i32 0
  %t110 = load { i64, ptr }, ptr %t109, !tbaa !27
  %t111 = getelementptr %"compiler/build:Unit", ptr %l17, i32 0, i32 0
  %t112 = load { i64, ptr }, ptr %t111, !tbaa !27
  %t115 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %v1, { i64, ptr } %t110, { i64, ptr } %t112)
  store i1 %t115, ptr %l77
  br label %bb26
bb26:
  %t116 = load i1, ptr %l77, !tbaa !21
  %t117 = xor i1 %t116, true
  br i1 %t117, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l79, !tbaa !21
  br label %bb31
bb28:
  %t119 = load i64, ptr %l16, !tbaa !24
  %t122 = call %"compiler/emit:Object" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aObject_3e_2eAt_3ccompiler_2femit_3aObject_3e(ptr %s0, ptr %s0, ptr %l9, i64 %t119)
  store %"compiler/emit:Object" %t122, ptr %l82
  br label %bb29
bb29:
  %t123 = getelementptr %"compiler/emit:Object", ptr %l82, i32 0, i32 2
  %t124 = load { i64, ptr }, ptr %t123, !tbaa !27
  %t125 = getelementptr %"compiler/build:Unit", ptr %l17, i32 0, i32 2
  %t126 = load { i64, ptr }, ptr %t125, !tbaa !27
  %t129 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %v1, { i64, ptr } %t124, { i64, ptr } %t126)
  store i1 %t129, ptr %l85
  br label %bb30
bb30:
  %t130 = load i1, ptr %l85, !tbaa !21
  %t131 = xor i1 %t130, true
  store i1 %t131, ptr %l79, !tbaa !21
  br label %bb31
bb31:
  %t133 = load i1, ptr %l79, !tbaa !21
  br i1 %t133, label %bb32, label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s5
  %t134 = load i64, ptr %l16, !tbaa !24
  %t137 = call %"compiler/emit:Object" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aObject_3e_2eAt_3ccompiler_2femit_3aObject_3e(ptr %s0, ptr %s0, ptr %l9, i64 %t134)
  store %"compiler/emit:Object" %t137, ptr %l89
  br label %bb34
bb33:
  br label %bb41
bb34:
  %t138 = getelementptr %"compiler/emit:Object", ptr %l89, i32 0, i32 0
  %t139 = load { i64, ptr }, ptr %t138, !tbaa !27
  %t140 = extractvalue { i64, ptr } { i64 20, ptr @.d107 }, 1
  %t141 = extractvalue { i64, ptr } { i64 20, ptr @.d107 }, 0
  %t143 = extractvalue { i64, ptr } %t139, 1
  %t144 = extractvalue { i64, ptr } %t139, 0
  %t145 = add i64 %t141, %t144
  %t146 = extractvalue { i64, ptr } { i64 9, ptr @.d108 }, 1
  %t147 = extractvalue { i64, ptr } { i64 9, ptr @.d108 }, 0
  %t148 = add i64 %t145, %t147
  %t149 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t148)
  call void @olang_textcopy(ptr %t149, ptr %t140, i64 %t141)
  %t150 = getelementptr i8, ptr %t149, i64 %t141
  call void @olang_textcopy(ptr %t150, ptr %t143, i64 %t144)
  %t151 = getelementptr i8, ptr %t150, i64 %t144
  call void @olang_textcopy(ptr %t151, ptr %t146, i64 %t147)
  %t152 = insertvalue { i64, ptr } undef, i64 %t148, 0
  %t153 = insertvalue { i64, ptr } %t152, ptr %t149, 1
  %t155 = extractvalue { i64, ptr } %t153, 0
  %t156 = extractvalue { i64, ptr } %t153, 1
  %t157 = mul i64 %t155, 1
  %t158 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t157)
  call void @llvm.memcpy.p0.p0.i64(ptr %t158, ptr %t156, i64 %t157, i1 false)
  %t159 = insertvalue { i64, ptr } undef, i64 %t155, 0
  %t160 = insertvalue { i64, ptr } %t159, ptr %t158, 1
  %t162 = call i32 @std_2fio_2ePrintErr(ptr %s5, { i64, ptr } %t160)
  store i32 %t162, ptr %l93
  %t163 = icmp ne i32 %t162, 0
  br i1 %t163, label %bb36, label %ok.164
ok.164:
  br label %bb35
bb35:
  br label %bb40
bb36:
  %t165 = load i32, ptr %l93, !tbaa !23
  %t166 = ashr i32 %t165, 16
  %t168 = icmp eq i32 %t166, 1
  br i1 %t168, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  call void @__olang_check_failed(ptr @olang_loc_dd8573ae343ff812_8decdc106ea08ebe)
  unreachable
bb39:
  br label %bb40
bb40:
  store i1 true, ptr %l10, !tbaa !21
  call void @__olang_scope_close(ptr %s5)
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s3)
  br label %bb42
bb42:
  %t170 = load i64, ptr %l15, !tbaa !24
  %t172 = add i64 %t170, 1
  store i64 %t172, ptr %l15, !tbaa !24
  br label %bb16
bb43:
  %t174 = load i1, ptr %l10, !tbaa !21
  br i1 %t174, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s9
  %t176 = load ptr, ptr %l1, !tbaa !29
  %t178 = getelementptr %"compiler/build:Program", ptr %t176, i32 0, i32 0
  %t180 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2eLen_3ccompiler_2fbuild_3aUnit_3e(ptr %v1, ptr %t178)
  store i64 %t180, ptr %l101
  br label %bb46
bb45:
  br label %bb55
bb46:
  %t182 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aObject_3e_2eLen_3ccompiler_2femit_3aObject_3e(ptr %s0, ptr %l9)
  store i64 %t182, ptr %l103
  br label %bb47
bb47:
  %t183 = extractvalue { i64, ptr } { i64 20, ptr @.d109 }, 1
  %t184 = extractvalue { i64, ptr } { i64 20, ptr @.d109 }, 0
  %t185 = load i64, ptr %l101, !tbaa !24
  %t186 = call i64 @__olang_fmt_i64(ptr null, i64 %t185)
  %t187 = add i64 %t184, %t186
  %t188 = extractvalue { i64, ptr } { i64 10, ptr @.d110 }, 1
  %t189 = extractvalue { i64, ptr } { i64 10, ptr @.d110 }, 0
  %t190 = add i64 %t187, %t189
  %t191 = load i64, ptr %l103, !tbaa !24
  %t192 = call i64 @__olang_fmt_i64(ptr null, i64 %t191)
  %t193 = add i64 %t190, %t192
  %t194 = extractvalue { i64, ptr } { i64 16, ptr @.d111 }, 1
  %t195 = extractvalue { i64, ptr } { i64 16, ptr @.d111 }, 0
  %t196 = add i64 %t193, %t195
  %t197 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t196)
  call void @olang_textcopy(ptr %t197, ptr %t183, i64 %t184)
  %t198 = getelementptr i8, ptr %t197, i64 %t184
  %t199 = call i64 @__olang_fmt_i64(ptr %t198, i64 %t185)
  %t200 = getelementptr i8, ptr %t198, i64 %t186
  call void @olang_textcopy(ptr %t200, ptr %t188, i64 %t189)
  %t201 = getelementptr i8, ptr %t200, i64 %t189
  %t202 = call i64 @__olang_fmt_i64(ptr %t201, i64 %t191)
  %t203 = getelementptr i8, ptr %t201, i64 %t192
  call void @olang_textcopy(ptr %t203, ptr %t194, i64 %t195)
  %t204 = insertvalue { i64, ptr } undef, i64 %t196, 0
  %t205 = insertvalue { i64, ptr } %t204, ptr %t197, 1
  %t207 = extractvalue { i64, ptr } %t205, 0
  %t208 = extractvalue { i64, ptr } %t205, 1
  %t209 = mul i64 %t207, 1
  %t210 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t209)
  call void @llvm.memcpy.p0.p0.i64(ptr %t210, ptr %t208, i64 %t209, i1 false)
  %t211 = insertvalue { i64, ptr } undef, i64 %t207, 0
  %t212 = insertvalue { i64, ptr } %t211, ptr %t210, 1
  %t214 = call i32 @std_2fio_2ePrintErr(ptr %s9, { i64, ptr } %t212)
  store i32 %t214, ptr %l106
  %t215 = icmp ne i32 %t214, 0
  br i1 %t215, label %bb49, label %ok.216
ok.216:
  br label %bb48
bb48:
  br label %bb53
bb49:
  %t217 = load i32, ptr %l106, !tbaa !23
  %t218 = ashr i32 %t217, 16
  %t220 = icmp eq i32 %t218, 1
  br i1 %t220, label %bb50, label %bb51
bb50:
  br label %bb52
bb51:
  call void @__olang_check_failed(ptr @olang_loc_1ac4aff2f4082213_2cf9008d871781bf)
  unreachable
bb52:
  br label %bb53
bb53:
  call void @std_2fos_2eExit(i32 3)
  unreachable
bb54:
  call void @__olang_check_failed(ptr @olang_loc_32421bf44abb9df8_94a4451618780c84)
  unreachable
bb55:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/emit:Emitter", ptr %t222, i32 0, i32 60
  %t226 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eLen_3cI64_2c_20I64_3e(ptr %v0, ptr %t224)
  store i64 %t226, ptr %l111
  br label %bb56
bb56:
  %t227 = extractvalue { i64, ptr } { i64 20, ptr @.d112 }, 1
  %t228 = extractvalue { i64, ptr } { i64 20, ptr @.d112 }, 0
  %t229 = load i64, ptr %l111, !tbaa !24
  %t230 = call i64 @__olang_fmt_i64(ptr null, i64 %t229)
  %t231 = add i64 %t228, %t230
  %t232 = extractvalue { i64, ptr } { i64 39, ptr @.d113 }, 1
  %t233 = extractvalue { i64, ptr } { i64 39, ptr @.d113 }, 0
  %t234 = add i64 %t231, %t233
  %t235 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t234)
  call void @olang_textcopy(ptr %t235, ptr %t227, i64 %t228)
  %t236 = getelementptr i8, ptr %t235, i64 %t228
  %t237 = call i64 @__olang_fmt_i64(ptr %t236, i64 %t229)
  %t238 = getelementptr i8, ptr %t236, i64 %t230
  call void @olang_textcopy(ptr %t238, ptr %t232, i64 %t233)
  %t239 = insertvalue { i64, ptr } undef, i64 %t234, 0
  %t240 = insertvalue { i64, ptr } %t239, ptr %t235, 1
  %t242 = extractvalue { i64, ptr } %t240, 0
  %t243 = extractvalue { i64, ptr } %t240, 1
  %t244 = mul i64 %t242, 1
  %t245 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t244)
  call void @llvm.memcpy.p0.p0.i64(ptr %t245, ptr %t243, i64 %t244, i1 false)
  %t246 = insertvalue { i64, ptr } undef, i64 %t242, 0
  %t247 = insertvalue { i64, ptr } %t246, ptr %t245, 1
  %t249 = call i32 @std_2fio_2ePrintErr(ptr %s0, { i64, ptr } %t247)
  store i32 %t249, ptr %l114
  %t250 = icmp ne i32 %t249, 0
  br i1 %t250, label %bb58, label %ok.251
ok.251:
  br label %bb57
bb57:
  br label %bb62
bb58:
  %t252 = load i32, ptr %l114, !tbaa !23
  %t253 = ashr i32 %t252, 16
  %t255 = icmp eq i32 %t253, 1
  br i1 %t255, label %bb59, label %bb60
bb59:
  br label %bb61
bb60:
  call void @__olang_check_failed(ptr @olang_loc_2cc05bc0974a48c9_c5f1014419607875)
  unreachable
bb61:
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2folang_2ecompiler_2folang_3aPasses_2eAnalyze(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i32 %a2, ptr %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca %"compiler/lower:Gap"
  %l28 = alloca %"compiler/target:Target"
  %l29 = alloca i1
  %l30 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l31 = alloca ptr
  %l32 = alloca i64
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca %"compiler/emit:Object"
  %l37 = alloca %"compiler/emit:Reused"
  %l38 = alloca { i64, ptr }
  %l39 = alloca ptr
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca ptr
  %l49 = alloca { i64, ptr }
  %l50 = alloca i32
  %l52 = alloca ptr
  %l55 = alloca ptr
  %l60 = alloca ptr
  %l61 = alloca i32
  %l65 = alloca %"compiler/check:Checker"
  %l70 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l73 = alloca i64
  %l77 = alloca i64
  %l80 = alloca i64
  %l81 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l85 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l88 = alloca i64
  %l91 = alloca i1
  %l95 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l101 = alloca %"compiler/lower:Lowerer"
  %l106 = alloca ptr
  %l109 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l111 = alloca i64
  %l120 = alloca ptr
  %l130 = alloca { i64, ptr }
  %l131 = alloca ptr
  %l135 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l137 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l146 = alloca ptr
  %l148 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l151 = alloca i64
  %l153 = alloca i1
  %l156 = alloca i64
  %l160 = alloca { i64, ptr }
  %l163 = alloca { i64, ptr }
  %l164 = alloca i32
  %l174 = alloca { i64, ptr }
  %l187 = alloca { i64, ptr }
  %l190 = alloca { i64, ptr }
  %l191 = alloca i32
  %l201 = alloca { i64, ptr }
  %l208 = alloca { i64, ptr }
  %l219 = alloca i64
  %l224 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l226 = alloca { i64, ptr }
  %l229 = alloca { i64, ptr }
  %l230 = alloca i32
  %l240 = alloca { i64, ptr }
  %l248 = alloca %"compiler/emit:Reused"
  %l249 = alloca ptr
  %l253 = alloca ptr
  %l256 = alloca { i64, ptr }
  %l259 = alloca { i64, ptr }
  %l261 = alloca { i64, ptr }
  %l264 = alloca { i64, ptr }
  %l265 = alloca i32
  %l276 = alloca { i64, ptr }
  %l279 = alloca { i64, ptr }
  %l284 = alloca { i64, ptr }
  %l285 = alloca i32
  %l295 = alloca { i64, ptr }
  %l296 = alloca i1
  %l299 = alloca { i64, ptr }
  %l302 = alloca i1
  %l303 = alloca i32
  %l307 = alloca %"compiler/build:Unit"
  %l309 = alloca ptr
  %l312 = alloca { i64, ptr }
  %l330 = alloca { i64, ptr }
  %l331 = alloca i1
  %l333 = alloca i32
  %l354 = alloca %"compiler/build:Unit"
  %l359 = alloca i1
  %l362 = alloca i1
  %l365 = alloca ptr
  %l367 = alloca { i64, ptr }
  %l393 = alloca { i64, ptr }
  %l394 = alloca { i64, ptr }
  %l395 = alloca i32
  %l396 = alloca { i64, ptr }
  %l399 = alloca i1
  %l409 = alloca ptr
  %l411 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l413 = alloca i64
  %l416 = alloca ptr
  %l417 = alloca { i64, ptr }
  %l425 = alloca { i64, ptr }
  %l426 = alloca i32
  %l433 = alloca ptr
  %l434 = alloca { i64, ptr }
  %l442 = alloca { i64, ptr }
  %l443 = alloca i32
  %s0 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %rv = alloca i32
  %t33 = alloca %"compiler/check:Checker", align 8
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l2
  %t3 = trunc i64 2 to i32
  %t4 = icmp eq i32 %t1, %t3
  store i1 %t4, ptr %l6, !tbaa !21
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 5, ptr @.d114 })
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l3, !tbaa !29
  %t9 = load ptr, ptr %l5, !tbaa !29
  %t14 = call { i32, ptr } @compiler_2folang_2ecompiler_2folang_3aPasses_2eload(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, ptr %t8, ptr %t9)
  %t15 = extractvalue { i32, ptr } %t14, 1
  %t16 = extractvalue { i32, ptr } %t14, 0
  store i32 %t16, ptr %l61
  %t17 = icmp ne i32 %t16, 0
  br i1 %t17, label %bb3, label %ok.18
ok.18:
  store ptr %t15, ptr %l60
  br label %bb2
bb2:
  %t19 = load ptr, ptr %l60, !tbaa !29
  store ptr %t19, ptr %l55, !tbaa !29
  br label %bb4
bb3:
  %t20 = load i32, ptr %l61, !tbaa !23
  %t21 = lshr i32 %t20, 16
  %t22 = and i32 %t20, 65535
  %t23 = icmp eq i32 %t21, 1
  %t24 = select i1 %t23, i32 1, i32 0
  %t25 = icmp eq i32 %t20, 0
  %t26 = shl i32 %t24, 16
  %t27 = or i32 %t26, %t22
  %t28 = select i1 %t25, i32 0, i32 %t27
  call void @__olang_scope_close(ptr %s0)
  store i32 %t28, ptr %rv
  br label %ret
bb4:
  %t30 = load ptr, ptr %l55, !tbaa !29
  store ptr %t30, ptr %l7, !tbaa !29
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 4, ptr @.d115 })
  br label %bb5
bb5:
  %t31 = load ptr, ptr %l7, !tbaa !29
  %t32 = load i1, ptr %l6, !tbaa !21
  call void @compiler_2finterp_2eAnalyze(ptr %t33, ptr %v2, ptr %v2, ptr %t31, i1 %t32)
  call void @llvm.memmove.p0.p0.i64(ptr %l65, ptr %t33, i64 672, i1 false)
  br label %bb6
bb6:
  %t36 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 672, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t36, ptr %l65, i64 672, i1 false)
  store ptr %t36, ptr %l8, !tbaa !29
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 5, ptr @.d116 })
  br label %bb7
bb7:
  %t38 = load i32, ptr %l2
  %t40 = trunc i64 1 to i32
  %t41 = icmp eq i32 %t38, %t40
  br i1 %t41, label %bb8, label %bb9
bb8:
  %t43 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eCheckMain(ptr %v2, ptr %t43)
  br label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb11
bb11:
  %t45 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t45, ptr %l70
  br label %bb12
bb12:
  %t46 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l70
  %t47 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t46, ptr %t47
  store ptr %t47, ptr %l9, !tbaa !29
  %t49 = load ptr, ptr %l5, !tbaa !29
  %t51 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v2, ptr %t49)
  store i64 %t51, ptr %l73
  br label %bb13
bb13:
  %t52 = load i64, ptr %l73, !tbaa !24
  %t53 = icmp eq i64 %t52, 0
  store i1 %t53, ptr %l10, !tbaa !21
  %t55 = load i1, ptr %l10, !tbaa !21
  br i1 %t55, label %bb14, label %bb15
bb14:
  %t57 = load ptr, ptr %l8, !tbaa !29
  %t59 = call i64 @compiler_2finterp_2eDecideValues(ptr %v2, ptr %t57)
  store i64 %t59, ptr %l77
  br label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb17
bb17:
  %t60 = load ptr, ptr %l8, !tbaa !29
  %t61 = load ptr, ptr %l9, !tbaa !29
  %t64 = call i64 @compiler_2finterp_2eDecideAsserts(ptr %v2, ptr %v2, ptr %t60, ptr %t61)
  store i64 %t64, ptr %l80
  br label %bb18
bb18:
  %t65 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2ector(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t65, ptr %l81
  br label %bb19
bb19:
  %t66 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l81
  %t67 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t66, ptr %t67
  store ptr %t67, ptr %l11, !tbaa !29
  %t69 = load i1, ptr %l10, !tbaa !21
  br i1 %t69, label %bb20, label %bb21
bb20:
  %t71 = load ptr, ptr %l8, !tbaa !29
  %t73 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2finterp_2eBake(ptr %v2, ptr %v2, ptr %t71)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t73, ptr %l85
  br label %bb22
bb21:
  br label %bb23
bb22:
  %t74 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l85
  %t75 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t74, ptr %t75
  store ptr %t75, ptr %l11, !tbaa !29
  br label %bb23
bb23:
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 8, ptr @.d117 })
  br label %bb24
bb24:
  %t77 = load ptr, ptr %l5, !tbaa !29
  %t79 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v2, ptr %t77)
  store i64 %t79, ptr %l88
  br label %bb25
bb25:
  %t80 = load i64, ptr %l88, !tbaa !24
  %t81 = icmp sgt i64 %t80, 0
  br i1 %t81, label %bb26, label %bb27
bb26:
  %t83 = load ptr, ptr %l5, !tbaa !29
  %t85 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHasFatal(ptr %v2, ptr %t83)
  store i1 %t85, ptr %l91
  br label %bb28
bb27:
  br label %bb33
bb28:
  %t86 = load i1, ptr %l91, !tbaa !21
  %t87 = xor i1 %t86, true
  br i1 %t87, label %bb29, label %bb30
bb29:
  %t89 = load ptr, ptr %l8, !tbaa !29
  %t90 = load ptr, ptr %l3, !tbaa !29
  %t93 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2folang_2eplacement(ptr %v2, ptr %v2, ptr %v2, ptr %t89, ptr %t90)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t93, ptr %l95
  br label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb33:
  %t95 = load ptr, ptr %l8, !tbaa !29
  %t97 = getelementptr %"compiler/check:Checker", ptr %t95, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t99 = load ptr, ptr %l8, !tbaa !29
  %t101 = getelementptr %"compiler/check:Checker", ptr %t99, i32 0, i32 10
  %t102 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t101
  %t105 = call %"compiler/lower:Lowerer" @compiler_2flower_3aLowerer_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %t98, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t102)
  store %"compiler/lower:Lowerer" %t105, ptr %l101
  br label %bb34
bb34:
  %t106 = load %"compiler/lower:Lowerer", ptr %l101
  %t107 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 112, i64 8)
  store %"compiler/lower:Lowerer" %t106, ptr %t107
  store ptr %t107, ptr %l12, !tbaa !29
  %t109 = load ptr, ptr %l12, !tbaa !29
  %t110 = load ptr, ptr %l9, !tbaa !29
  %t112 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t110
  %t115 = getelementptr %"compiler/lower:Lowerer", ptr %t109, i32 0, i32 6
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t112, ptr %t115
  %t116 = load ptr, ptr %l12, !tbaa !29
  store ptr %t116, ptr %l106, !tbaa !29
  %t117 = load ptr, ptr %l8, !tbaa !29
  %t118 = load ptr, ptr %l3, !tbaa !29
  %t121 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2folang_2eplacement(ptr %v2, ptr %v2, ptr %v2, ptr %t117, ptr %t118)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t121, ptr %l109
  br label %bb35
bb35:
  %t122 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l109
  %t123 = load ptr, ptr %l106, !tbaa !29
  %t124 = getelementptr %"compiler/lower:Lowerer", ptr %t123, i32 0, i32 2
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t122, ptr %t124
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 5, ptr @.d118 })
  br label %bb36
bb36:
  %t125 = load ptr, ptr %l5, !tbaa !29
  %t127 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v2, ptr %t125)
  store i64 %t127, ptr %l111
  br label %bb37
bb37:
  %t128 = load i64, ptr %l111, !tbaa !24
  %t129 = icmp sgt i64 %t128, 0
  br i1 %t129, label %bb38, label %bb39
bb38:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb39:
  br label %bb40
bb40:
  %t132 = load ptr, ptr %l8, !tbaa !29
  %t133 = load ptr, ptr %l12, !tbaa !29
  %t134 = load ptr, ptr %l5, !tbaa !29
  %t135 = load ptr, ptr %l3, !tbaa !29
  %t136 = load i32, ptr %l2
  %t137 = load ptr, ptr %l11, !tbaa !29
  %t144 = call ptr @compiler_2folang_2eemitter(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %t132, ptr %t133, ptr %t134, ptr %t135, i32 %t136, ptr %t137)
  store ptr %t144, ptr %l120
  br label %bb41
bb41:
  %t145 = load ptr, ptr %l120, !tbaa !29
  store ptr %t145, ptr %l13, !tbaa !29
  %t146 = icmp sge i64 0, 0
  br i1 %t146, label %bb42, label %bb43
bb42:
  %t148 = icmp sle i64 0, 576460752303423487
  br i1 %t148, label %bb44, label %bb45
bb43:
  call void @__olang_check_failed(ptr @olang_loc_1d5612d13136b02e_cf27d9d671de6fa2)
  unreachable
bb44:
  %t150 = mul i64 0, 16
  %t151 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t150)
  %t152 = insertvalue { i64, ptr } undef, i64 0, 0
  %t153 = insertvalue { i64, ptr } %t152, ptr %t151, 1
  store { i64, ptr } %t153, ptr %l14, !tbaa !27
  %t155 = load i32, ptr %l2
  %t157 = trunc i64 0 to i32
  %t158 = icmp eq i32 %t155, %t157
  %t160 = xor i1 %t158, true
  br i1 %t160, label %bb46, label %bb47
bb45:
  call void @__olang_check_failed(ptr @olang_loc_1d5612d13136b02e_cf27d9d671de6fa2)
  unreachable
bb46:
  %t162 = load ptr, ptr %l7, !tbaa !29
  %t163 = load ptr, ptr %l3, !tbaa !29
  %t164 = load i1, ptr %l6, !tbaa !21
  %t168 = call { i64, ptr } @compiler_2folang_2emoduleKeys(ptr %v2, ptr %v2, ptr %t162, ptr %t163, i1 %t164)
  store { i64, ptr } %t168, ptr %l130
  br label %bb48
bb47:
  br label %bb50
bb48:
  %t169 = load { i64, ptr }, ptr %l130, !tbaa !27
  store { i64, ptr } %t169, ptr %l14, !tbaa !27
  %t170 = load ptr, ptr %l13, !tbaa !29
  store ptr %t170, ptr %l131, !tbaa !29
  %t171 = load ptr, ptr %l7, !tbaa !29
  %t172 = load ptr, ptr %l3, !tbaa !29
  %t173 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t177 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2folang_2ereusable(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %t171, ptr %t172, { i64, ptr } %t173)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t177, ptr %l135
  br label %bb49
bb49:
  %t178 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l135
  %t179 = load ptr, ptr %l131, !tbaa !29
  %t180 = getelementptr %"compiler/emit:Emitter", ptr %t179, i32 0, i32 59
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t178, ptr %t180
  br label %bb50
bb50:
  %t181 = load ptr, ptr %l13, !tbaa !29
  %t183 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2ecompiler_2femit_3aEmitter_2eObjects(ptr %v2, ptr %v3, ptr %t181)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t183, ptr %l137
  br label %bb51
bb51:
  %t184 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l137
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t184, ptr %l15
  %t185 = load ptr, ptr %l13, !tbaa !29
  %t187 = getelementptr %"compiler/emit:Emitter", ptr %t185, i32 0, i32 62
  %t188 = load i1, ptr %t187, !tbaa !21
  br i1 %t188, label %bb52, label %bb53
bb52:
  %t190 = load ptr, ptr %l8, !tbaa !29
  %t191 = load ptr, ptr %l12, !tbaa !29
  %t192 = load ptr, ptr %l5, !tbaa !29
  %t193 = load ptr, ptr %l3, !tbaa !29
  %t194 = load i32, ptr %l2
  %t195 = load ptr, ptr %l11, !tbaa !29
  %t202 = call ptr @compiler_2folang_2eemitter(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %t190, ptr %t191, ptr %t192, ptr %t193, i32 %t194, ptr %t195)
  store ptr %t202, ptr %l146
  br label %bb54
bb53:
  br label %bb56
bb54:
  %t203 = load ptr, ptr %l146, !tbaa !29
  store ptr %t203, ptr %l13, !tbaa !29
  %t204 = load ptr, ptr %l13, !tbaa !29
  %t206 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2ecompiler_2femit_3aEmitter_2eObjects(ptr %v2, ptr %v3, ptr %t204)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t206, ptr %l148
  br label %bb55
bb55:
  %t207 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l148
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t207, ptr %l15
  br label %bb56
bb56:
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 10, ptr @.d119 })
  br label %bb57
bb57:
  %t208 = load ptr, ptr %l13, !tbaa !29
  %t210 = getelementptr %"compiler/emit:Emitter", ptr %t208, i32 0, i32 8
  %t212 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v2, ptr %t210)
  store i64 %t212, ptr %l151
  br label %bb58
bb58:
  %t213 = load i64, ptr %l151, !tbaa !24
  %t214 = icmp sgt i64 %t213, 0
  br i1 %t214, label %bb59, label %bb60
bb59:
  store i1 true, ptr %l153, !tbaa !21
  br label %bb62
bb60:
  %t216 = load ptr, ptr %l12, !tbaa !29
  %t218 = getelementptr %"compiler/lower:Lowerer", ptr %t216, i32 0, i32 3
  %t220 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3aGap_3e_2eLen_3ccompiler_2flower_3aGap_3e(ptr %v2, ptr %t218)
  store i64 %t220, ptr %l156
  br label %bb61
bb61:
  %t221 = load i64, ptr %l156, !tbaa !24
  %t222 = icmp sgt i64 %t221, 0
  store i1 %t222, ptr %l153, !tbaa !21
  br label %bb62
bb62:
  %t224 = load i1, ptr %l153, !tbaa !21
  br i1 %t224, label %bb63, label %bb64
bb63:
  %t225 = load ptr, ptr %l13, !tbaa !29
  %t227 = getelementptr %"compiler/emit:Emitter", ptr %t225, i32 0, i32 8
  store ptr %t227, ptr %l16, !tbaa !29
  store i64 0, ptr %l17, !tbaa !24
  br label %bb65
bb64:
  br label %bb98
bb65:
  store %olang.scope zeroinitializer, ptr %s11
  %t229 = load ptr, ptr %l16, !tbaa !29
  %t230 = load i64, ptr %l17, !tbaa !24
  %t233 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v2, ptr %t229, i64 %t230)
  %t234 = extractvalue { i32, { i64, ptr } } %t233, 1
  %t235 = extractvalue { i32, { i64, ptr } } %t233, 0
  store i32 %t235, ptr %l164
  %t236 = icmp ne i32 %t235, 0
  br i1 %t236, label %bb67, label %ok.237
ok.237:
  store { i64, ptr } %t234, ptr %l163
  br label %bb66
bb66:
  %t238 = load { i64, ptr }, ptr %l163, !tbaa !27
  store { i64, ptr } %t238, ptr %l160, !tbaa !27
  br label %bb71
bb67:
  %t239 = load i32, ptr %l164, !tbaa !23
  %t240 = ashr i32 %t239, 16
  %t242 = icmp eq i32 %t240, 1
  br i1 %t242, label %bb68, label %bb69
bb68:
  br label %bb70
bb69:
  %t244 = load i32, ptr %l164, !tbaa !23
  %t245 = lshr i32 %t244, 16
  %t246 = and i32 %t244, 65535
  %t247 = icmp eq i32 %t245, 1
  %t248 = select i1 %t247, i32 0, i32 0
  %t249 = icmp eq i32 %t244, 0
  %t250 = shl i32 %t248, 16
  %t251 = or i32 %t250, %t246
  %t252 = select i1 %t249, i32 0, i32 %t251
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t252, ptr %rv
  br label %ret
bb70:
  call void @__olang_scope_close(ptr %s11)
  br label %bb80
bb71:
  %t254 = load { i64, ptr }, ptr %l160, !tbaa !27
  store { i64, ptr } %t254, ptr %l18, !tbaa !27
  %t255 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t257 = extractvalue { i64, ptr } %t255, 0
  store i64 %t257, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb72
bb72:
  store %olang.scope zeroinitializer, ptr %s12
  %t259 = load i64, ptr %l20, !tbaa !24
  %t260 = load i64, ptr %l19, !tbaa !24
  %t263 = icmp slt i64 %t259, %t260
  %t265 = xor i1 %t263, true
  br i1 %t265, label %bb73, label %bb74
bb73:
  call void @__olang_scope_close(ptr %s12)
  br label %bb78
bb74:
  br label %bb75
bb75:
  %t267 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t267, ptr %l174, !tbaa !27
  %t268 = load i64, ptr %l20, !tbaa !24
  %t270 = getelementptr { i64, ptr }, ptr %l174, i32 0, i32 1
  %t271 = load ptr, ptr %t270, !tbaa !27
  %t272 = getelementptr { i64, ptr }, ptr %t271, i64 %t268
  %t273 = load { i64, ptr }, ptr %t272, !tbaa !37
  %t276 = extractvalue { i64, ptr } { i64 17, ptr @.d120 }, 1
  %t277 = extractvalue { i64, ptr } { i64 17, ptr @.d120 }, 0
  %t279 = extractvalue { i64, ptr } %t273, 1
  %t280 = extractvalue { i64, ptr } %t273, 0
  %t281 = add i64 %t277, %t280
  %t282 = extractvalue { i64, ptr } { i64 4, ptr @.d121 }, 1
  %t283 = extractvalue { i64, ptr } { i64 4, ptr @.d121 }, 0
  %t284 = add i64 %t281, %t283
  %t285 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t284)
  call void @olang_textcopy(ptr %t285, ptr %t276, i64 %t277)
  %t286 = getelementptr i8, ptr %t285, i64 %t277
  call void @olang_textcopy(ptr %t286, ptr %t279, i64 %t280)
  %t287 = getelementptr i8, ptr %t286, i64 %t280
  call void @olang_textcopy(ptr %t287, ptr %t282, i64 %t283)
  %t288 = insertvalue { i64, ptr } undef, i64 %t284, 0
  %t289 = insertvalue { i64, ptr } %t288, ptr %t285, 1
  %t291 = extractvalue { i64, ptr } %t289, 0
  %t292 = extractvalue { i64, ptr } %t289, 1
  %t293 = mul i64 %t291, 1
  %t294 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t293)
  call void @llvm.memcpy.p0.p0.i64(ptr %t294, ptr %t292, i64 %t293, i1 false)
  %t295 = insertvalue { i64, ptr } undef, i64 %t291, 0
  %t296 = insertvalue { i64, ptr } %t295, ptr %t294, 1
  call void @compiler_2fbuild_2eUnbuildable(ptr %s12, { i64, ptr } %t296)
  br label %bb76
bb76:
  call void @__olang_scope_close(ptr %s12)
  br label %bb77
bb77:
  %t298 = load i64, ptr %l20, !tbaa !24
  %t300 = add i64 %t298, 1
  store i64 %t300, ptr %l20, !tbaa !24
  br label %bb72
bb78:
  %t302 = load i64, ptr %l17, !tbaa !24
  %t303 = load i64, ptr %l19, !tbaa !24
  %t306 = add i64 %t302, %t303
  store i64 %t306, ptr %l17, !tbaa !24
  call void @__olang_scope_close(ptr %s11)
  br label %bb79
bb79:
  br label %bb65
bb80:
  %t308 = load ptr, ptr %l12, !tbaa !29
  %t310 = getelementptr %"compiler/lower:Lowerer", ptr %t308, i32 0, i32 3
  store ptr %t310, ptr %l22, !tbaa !29
  store i64 0, ptr %l23, !tbaa !24
  br label %bb81
bb81:
  store %olang.scope zeroinitializer, ptr %s16
  %t312 = load ptr, ptr %l22, !tbaa !29
  %t313 = load i64, ptr %l23, !tbaa !24
  %t316 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3aGap_3e_2eRunFrom_3ccompiler_2flower_3aGap_3e(ptr %v2, ptr %t312, i64 %t313)
  %t317 = extractvalue { i32, { i64, ptr } } %t316, 1
  %t318 = extractvalue { i32, { i64, ptr } } %t316, 0
  store i32 %t318, ptr %l191
  %t319 = icmp ne i32 %t318, 0
  br i1 %t319, label %bb83, label %ok.320
ok.320:
  store { i64, ptr } %t317, ptr %l190
  br label %bb82
bb82:
  %t321 = load { i64, ptr }, ptr %l190, !tbaa !27
  store { i64, ptr } %t321, ptr %l187, !tbaa !27
  br label %bb87
bb83:
  %t322 = load i32, ptr %l191, !tbaa !23
  %t323 = ashr i32 %t322, 16
  %t325 = icmp eq i32 %t323, 1
  br i1 %t325, label %bb84, label %bb85
bb84:
  br label %bb86
bb85:
  %t327 = load i32, ptr %l191, !tbaa !23
  %t328 = lshr i32 %t327, 16
  %t329 = and i32 %t327, 65535
  %t330 = icmp eq i32 %t328, 1
  %t331 = select i1 %t330, i32 0, i32 0
  %t332 = icmp eq i32 %t327, 0
  %t333 = shl i32 %t331, 16
  %t334 = or i32 %t333, %t329
  %t335 = select i1 %t332, i32 0, i32 %t334
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t335, ptr %rv
  br label %ret
bb86:
  call void @__olang_scope_close(ptr %s16)
  br label %bb97
bb87:
  %t337 = load { i64, ptr }, ptr %l187, !tbaa !27
  store { i64, ptr } %t337, ptr %l24, !tbaa !27
  %t338 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t340 = extractvalue { i64, ptr } %t338, 0
  store i64 %t340, ptr %l25, !tbaa !24
  store i64 0, ptr %l26, !tbaa !24
  br label %bb88
bb88:
  store %olang.scope zeroinitializer, ptr %s17
  %t342 = load i64, ptr %l26, !tbaa !24
  %t343 = load i64, ptr %l25, !tbaa !24
  %t346 = icmp slt i64 %t342, %t343
  %t348 = xor i1 %t346, true
  br i1 %t348, label %bb89, label %bb90
bb89:
  call void @__olang_scope_close(ptr %s17)
  br label %bb95
bb90:
  br label %bb91
bb91:
  %t350 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t350, ptr %l201, !tbaa !27
  %t351 = load i64, ptr %l26, !tbaa !24
  %t353 = getelementptr { i64, ptr }, ptr %l201, i32 0, i32 1
  %t354 = load ptr, ptr %t353, !tbaa !27
  %t355 = getelementptr %"compiler/lower:Gap", ptr %t354, i64 %t351
  %t356 = load %"compiler/lower:Gap", ptr %t355
  store %"compiler/lower:Gap" %t356, ptr %l27
  %t358 = load ptr, ptr %l5, !tbaa !29
  %t359 = getelementptr %"compiler/lower:Gap", ptr %l27, i32 0, i32 0
  %t360 = load i64, ptr %t359, !tbaa !24
  %t361 = getelementptr %"compiler/lower:Gap", ptr %l27, i32 0, i32 1
  %t362 = getelementptr %"compiler/source:Span", ptr %t361, i32 0, i32 0
  %t363 = load i32, ptr %t362, !tbaa !23
  %t365 = sext i32 %t363 to i64
  %t369 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v2, ptr %s17, ptr %t358, i64 %t360, i64 %t365)
  store { i64, ptr } %t369, ptr %l208
  br label %bb92
bb92:
  %t370 = getelementptr %"compiler/lower:Gap", ptr %l27, i32 0, i32 2
  %t371 = load { i64, ptr }, ptr %t370, !tbaa !27
  %t372 = load { i64, ptr }, ptr %l208, !tbaa !27
  %t373 = extractvalue { i64, ptr } %t372, 1
  %t374 = extractvalue { i64, ptr } %t372, 0
  %t375 = extractvalue { i64, ptr } { i64 20, ptr @.d122 }, 1
  %t376 = extractvalue { i64, ptr } { i64 20, ptr @.d122 }, 0
  %t377 = add i64 %t374, %t376
  %t379 = extractvalue { i64, ptr } %t371, 1
  %t380 = extractvalue { i64, ptr } %t371, 0
  %t381 = add i64 %t377, %t380
  %t382 = extractvalue { i64, ptr } { i64 4, ptr @.d123 }, 1
  %t383 = extractvalue { i64, ptr } { i64 4, ptr @.d123 }, 0
  %t384 = add i64 %t381, %t383
  %t385 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t384)
  call void @olang_textcopy(ptr %t385, ptr %t373, i64 %t374)
  %t386 = getelementptr i8, ptr %t385, i64 %t374
  call void @olang_textcopy(ptr %t386, ptr %t375, i64 %t376)
  %t387 = getelementptr i8, ptr %t386, i64 %t376
  call void @olang_textcopy(ptr %t387, ptr %t379, i64 %t380)
  %t388 = getelementptr i8, ptr %t387, i64 %t380
  call void @olang_textcopy(ptr %t388, ptr %t382, i64 %t383)
  %t389 = insertvalue { i64, ptr } undef, i64 %t384, 0
  %t390 = insertvalue { i64, ptr } %t389, ptr %t385, 1
  %t392 = extractvalue { i64, ptr } %t390, 0
  %t393 = extractvalue { i64, ptr } %t390, 1
  %t394 = mul i64 %t392, 1
  %t395 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t394)
  call void @llvm.memcpy.p0.p0.i64(ptr %t395, ptr %t393, i64 %t394, i1 false)
  %t396 = insertvalue { i64, ptr } undef, i64 %t392, 0
  %t397 = insertvalue { i64, ptr } %t396, ptr %t395, 1
  call void @compiler_2fbuild_2eUnbuildable(ptr %s17, { i64, ptr } %t397)
  br label %bb93
bb93:
  call void @__olang_scope_close(ptr %s17)
  br label %bb94
bb94:
  %t399 = load i64, ptr %l26, !tbaa !24
  %t401 = add i64 %t399, 1
  store i64 %t401, ptr %l26, !tbaa !24
  br label %bb88
bb95:
  %t403 = load i64, ptr %l23, !tbaa !24
  %t404 = load i64, ptr %l25, !tbaa !24
  %t407 = add i64 %t403, %t404
  store i64 %t407, ptr %l23, !tbaa !24
  call void @__olang_scope_close(ptr %s16)
  br label %bb96
bb96:
  br label %bb81
bb97:
  call void @__olang_scope_close(ptr %s0)
  store i32 65537, ptr %rv
  br label %ret
bb98:
  %t410 = load ptr, ptr %l5, !tbaa !29
  %t412 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v2, ptr %t410)
  store i64 %t412, ptr %l219
  br label %bb99
bb99:
  %t413 = load i64, ptr %l219, !tbaa !24
  %t414 = icmp sgt i64 %t413, 0
  br i1 %t414, label %bb100, label %bb101
bb100:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb101:
  br label %bb102
bb102:
  %t417 = load ptr, ptr %l3, !tbaa !29
  %t419 = getelementptr %"compiler/build:Config", ptr %t417, i32 0, i32 2
  %t420 = load %"compiler/target:Target", ptr %t419
  store %"compiler/target:Target" %t420, ptr %l28
  store i1 false, ptr %l29, !tbaa !21
  %t422 = load ptr, ptr @__olang_prog_scope
  %t423 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t422)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t423, ptr %l224
  br label %bb103
bb103:
  %t424 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l224
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t424, ptr %l30
  store ptr %l15, ptr %l31, !tbaa !29
  store i64 0, ptr %l32, !tbaa !24
  br label %bb104
bb104:
  store %olang.scope zeroinitializer, ptr %s22
  %t426 = load ptr, ptr %l31, !tbaa !29
  %t427 = load i64, ptr %l32, !tbaa !24
  %t430 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aObject_3e_2eRunFrom_3ccompiler_2femit_3aObject_3e(ptr %v3, ptr %t426, i64 %t427)
  %t431 = extractvalue { i32, { i64, ptr } } %t430, 1
  %t432 = extractvalue { i32, { i64, ptr } } %t430, 0
  store i32 %t432, ptr %l230
  %t433 = icmp ne i32 %t432, 0
  br i1 %t433, label %bb106, label %ok.434
ok.434:
  store { i64, ptr } %t431, ptr %l229
  br label %bb105
bb105:
  %t435 = load { i64, ptr }, ptr %l229, !tbaa !27
  store { i64, ptr } %t435, ptr %l226, !tbaa !27
  br label %bb110
bb106:
  %t436 = load i32, ptr %l230, !tbaa !23
  %t437 = ashr i32 %t436, 16
  %t439 = icmp eq i32 %t437, 1
  br i1 %t439, label %bb107, label %bb108
bb107:
  br label %bb109
bb108:
  %t441 = load i32, ptr %l230, !tbaa !23
  %t442 = lshr i32 %t441, 16
  %t443 = and i32 %t441, 65535
  %t444 = icmp eq i32 %t442, 1
  %t445 = select i1 %t444, i32 0, i32 0
  %t446 = icmp eq i32 %t441, 0
  %t447 = shl i32 %t445, 16
  %t448 = or i32 %t447, %t443
  %t449 = select i1 %t446, i32 0, i32 %t448
  call void @__olang_scope_close(ptr %s22)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t449, ptr %rv
  br label %ret
bb109:
  call void @__olang_scope_close(ptr %s22)
  br label %bb196
bb110:
  %t451 = load { i64, ptr }, ptr %l226, !tbaa !27
  store { i64, ptr } %t451, ptr %l33, !tbaa !27
  %t452 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t454 = extractvalue { i64, ptr } %t452, 0
  store i64 %t454, ptr %l34, !tbaa !24
  store i64 0, ptr %l35, !tbaa !24
  br label %bb111
bb111:
  store %olang.scope zeroinitializer, ptr %s23
  %t456 = load i64, ptr %l35, !tbaa !24
  %t457 = load i64, ptr %l34, !tbaa !24
  %t460 = icmp slt i64 %t456, %t457
  %t462 = xor i1 %t460, true
  br i1 %t462, label %bb112, label %bb113
bb112:
  call void @__olang_scope_close(ptr %s23)
  br label %bb194
bb113:
  br label %bb114
bb114:
  %t464 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t464, ptr %l240, !tbaa !27
  %t465 = load i64, ptr %l35, !tbaa !24
  %t467 = getelementptr { i64, ptr }, ptr %l240, i32 0, i32 1
  %t468 = load ptr, ptr %t467, !tbaa !27
  %t469 = getelementptr %"compiler/emit:Object", ptr %t468, i64 %t465
  %t470 = load %"compiler/emit:Object", ptr %t469
  store %"compiler/emit:Object" %t470, ptr %l36
  %t472 = getelementptr %"compiler/emit:Object", ptr %l36, i32 0, i32 3
  %t473 = load i64, ptr %t472, !tbaa !24
  %t475 = icmp sge i64 %t473, 0
  br i1 %t475, label %bb115, label %bb116
bb115:
  store %olang.scope zeroinitializer, ptr %s24
  %t477 = load ptr, ptr %l13, !tbaa !29
  %t479 = getelementptr %"compiler/emit:Emitter", ptr %t477, i32 0, i32 59
  %t480 = getelementptr %"compiler/emit:Object", ptr %l36, i32 0, i32 3
  %t481 = load i64, ptr %t480, !tbaa !24
  %t484 = call %"compiler/emit:Reused" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aReused_3e_2eAt_3ccompiler_2femit_3aReused_3e(ptr %v2, ptr %v2, ptr %t479, i64 %t481)
  store %"compiler/emit:Reused" %t484, ptr %l248
  br label %bb117
bb116:
  br label %bb154
bb117:
  %t485 = load %"compiler/emit:Reused", ptr %l248
  store %"compiler/emit:Reused" %t485, ptr %l37
  %t486 = load ptr, ptr %l3, !tbaa !29
  store ptr %t486, ptr %l249, !tbaa !29
  %t487 = load ptr, ptr %l7, !tbaa !29
  %t489 = getelementptr %"compiler/load:Loader", ptr %t487, i32 0, i32 5
  %t490 = getelementptr %"compiler/emit:Reused", ptr %l37, i32 0, i32 0
  %t491 = load i64, ptr %t490, !tbaa !24
  %t494 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v2, ptr %v2, ptr %t489, i64 %t491)
  store ptr %t494, ptr %l253
  br label %bb118
bb118:
  %t495 = load ptr, ptr %l253, !tbaa !29
  %t497 = getelementptr %"compiler/load:Module", ptr %t495, i32 0, i32 2
  %t498 = load { i64, ptr }, ptr %t497, !tbaa !27
  %t499 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t499, ptr %l256, !tbaa !27
  %t500 = getelementptr %"compiler/emit:Reused", ptr %l37, i32 0, i32 0
  %t501 = load i64, ptr %t500, !tbaa !24
  %t503 = getelementptr { i64, ptr }, ptr %l256, i32 0, i32 1
  %t504 = load ptr, ptr %t503, !tbaa !27
  %t505 = getelementptr { i64, ptr }, ptr %t504, i64 %t501
  %t506 = load { i64, ptr }, ptr %t505, !tbaa !37
  %t507 = load ptr, ptr %l249, !tbaa !29
  %t510 = call { i64, ptr } @compiler_2folang_2erecordPath(ptr %v2, ptr %v2, ptr %v2, ptr %s24, ptr %t507, { i64, ptr } %t498, { i64, ptr } %t506)
  store { i64, ptr } %t510, ptr %l259
  br label %bb119
bb119:
  %t511 = load { i64, ptr }, ptr %l259, !tbaa !27
  store { i64, ptr } %t511, ptr %l38, !tbaa !27
  %t512 = getelementptr %"compiler/emit:Reused", ptr %l37, i32 0, i32 1
  store ptr %t512, ptr %l39, !tbaa !29
  store i64 0, ptr %l40, !tbaa !24
  store i64 0, ptr %l41, !tbaa !24
  br label %bb120
bb120:
  store %olang.scope zeroinitializer, ptr %s26
  %t514 = load ptr, ptr %l39, !tbaa !29
  %t515 = load i64, ptr %l40, !tbaa !24
  %t518 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v2, ptr %t514, i64 %t515)
  %t519 = extractvalue { i32, { i64, ptr } } %t518, 1
  %t520 = extractvalue { i32, { i64, ptr } } %t518, 0
  store i32 %t520, ptr %l265
  %t521 = icmp ne i32 %t520, 0
  br i1 %t521, label %bb122, label %ok.522
ok.522:
  store { i64, ptr } %t519, ptr %l264
  br label %bb121
bb121:
  %t523 = load { i64, ptr }, ptr %l264, !tbaa !27
  store { i64, ptr } %t523, ptr %l261, !tbaa !27
  br label %bb126
bb122:
  %t524 = load i32, ptr %l265, !tbaa !23
  %t525 = ashr i32 %t524, 16
  %t527 = icmp eq i32 %t525, 1
  br i1 %t527, label %bb123, label %bb124
bb123:
  br label %bb125
bb124:
  %t529 = load i32, ptr %l265, !tbaa !23
  %t530 = lshr i32 %t529, 16
  %t531 = and i32 %t529, 65535
  %t532 = icmp eq i32 %t530, 1
  %t533 = select i1 %t532, i32 0, i32 0
  %t534 = icmp eq i32 %t529, 0
  %t535 = shl i32 %t533, 16
  %t536 = or i32 %t535, %t531
  %t537 = select i1 %t534, i32 0, i32 %t536
  call void @__olang_scope_close(ptr %s26)
  call void @__olang_scope_close(ptr %s24)
  call void @__olang_scope_close(ptr %s23)
  call void @__olang_scope_close(ptr %s22)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t537, ptr %rv
  br label %ret
bb125:
  call void @__olang_scope_close(ptr %s26)
  br label %bb152
bb126:
  %t539 = load { i64, ptr }, ptr %l261, !tbaa !27
  store { i64, ptr } %t539, ptr %l42, !tbaa !27
  %t540 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t542 = extractvalue { i64, ptr } %t540, 0
  store i64 %t542, ptr %l43, !tbaa !24
  store i64 0, ptr %l44, !tbaa !24
  br label %bb127
bb127:
  store %olang.scope zeroinitializer, ptr %s27
  %t544 = load i64, ptr %l44, !tbaa !24
  %t545 = load i64, ptr %l43, !tbaa !24
  %t548 = icmp slt i64 %t544, %t545
  %t550 = xor i1 %t548, true
  br i1 %t550, label %bb128, label %bb129
bb128:
  call void @__olang_scope_close(ptr %s27)
  br label %bb150
bb129:
  br label %bb130
bb130:
  %t552 = load i64, ptr %l41, !tbaa !24
  store i64 %t552, ptr %l45, !tbaa !24
  %t554 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t554, ptr %l276, !tbaa !27
  %t555 = load i64, ptr %l44, !tbaa !24
  %t557 = getelementptr { i64, ptr }, ptr %l276, i32 0, i32 1
  %t558 = load ptr, ptr %t557, !tbaa !27
  %t559 = getelementptr { i64, ptr }, ptr %t558, i64 %t555
  %t560 = load { i64, ptr }, ptr %t559, !tbaa !37
  store { i64, ptr } %t560, ptr %l46, !tbaa !27
  %t562 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t563 = load i64, ptr %l45, !tbaa !24
  %t565 = extractvalue { i64, ptr } %t562, 1
  %t566 = extractvalue { i64, ptr } %t562, 0
  %t567 = extractvalue { i64, ptr } { i64 2, ptr @.d124 }, 1
  %t568 = extractvalue { i64, ptr } { i64 2, ptr @.d124 }, 0
  %t569 = add i64 %t566, %t568
  %t571 = call i64 @__olang_fmt_i64(ptr null, i64 %t563)
  %t572 = add i64 %t569, %t571
  %t573 = extractvalue { i64, ptr } { i64 3, ptr @.d125 }, 1
  %t574 = extractvalue { i64, ptr } { i64 3, ptr @.d125 }, 0
  %t575 = add i64 %t572, %t574
  %t576 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t575)
  call void @olang_textcopy(ptr %t576, ptr %t565, i64 %t566)
  %t577 = getelementptr i8, ptr %t576, i64 %t566
  call void @olang_textcopy(ptr %t577, ptr %t567, i64 %t568)
  %t578 = getelementptr i8, ptr %t577, i64 %t568
  %t579 = call i64 @__olang_fmt_i64(ptr %t578, i64 %t563)
  %t580 = getelementptr i8, ptr %t578, i64 %t571
  call void @olang_textcopy(ptr %t580, ptr %t573, i64 %t574)
  %t581 = insertvalue { i64, ptr } undef, i64 %t575, 0
  %t582 = insertvalue { i64, ptr } %t581, ptr %t576, 1
  %t584 = extractvalue { i64, ptr } %t582, 0
  %t585 = extractvalue { i64, ptr } %t582, 1
  %t586 = mul i64 %t584, 1
  %t587 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t586)
  call void @llvm.memcpy.p0.p0.i64(ptr %t587, ptr %t585, i64 %t586, i1 false)
  %t588 = insertvalue { i64, ptr } undef, i64 %t584, 0
  %t589 = insertvalue { i64, ptr } %t588, ptr %t587, 1
  %t591 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v3, ptr %v3, { i64, ptr } %t589)
  %t592 = extractvalue { i32, { i64, ptr } } %t591, 1
  %t593 = extractvalue { i32, { i64, ptr } } %t591, 0
  store i32 %t593, ptr %l285
  %t594 = icmp ne i32 %t593, 0
  br i1 %t594, label %bb132, label %ok.595
ok.595:
  store { i64, ptr } %t592, ptr %l284
  br label %bb131
bb131:
  %t596 = load { i64, ptr }, ptr %l284, !tbaa !27
  store { i64, ptr } %t596, ptr %l279, !tbaa !27
  br label %bb137
bb132:
  %t597 = load i32, ptr %l285, !tbaa !23
  %t598 = ashr i32 %t597, 16
  %t600 = icmp eq i32 %t598, 1
  br i1 %t600, label %bb133, label %bb134
bb133:
  br label %bb135
bb134:
  %t602 = load i32, ptr %l285, !tbaa !23
  %t603 = lshr i32 %t602, 16
  %t604 = and i32 %t602, 65535
  %t605 = icmp eq i32 %t603, 1
  %t606 = select i1 %t605, i32 0, i32 0
  %t607 = icmp eq i32 %t602, 0
  %t608 = shl i32 %t606, 16
  %t609 = or i32 %t608, %t604
  %t610 = select i1 %t607, i32 0, i32 %t609
  call void @__olang_scope_close(ptr %s27)
  call void @__olang_scope_close(ptr %s26)
  call void @__olang_scope_close(ptr %s24)
  call void @__olang_scope_close(ptr %s23)
  call void @__olang_scope_close(ptr %s22)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t610, ptr %rv
  br label %ret
bb135:
  store %olang.scope zeroinitializer, ptr %s29
  %t612 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t613 = extractvalue { i64, ptr } { i64 11, ptr @.d126 }, 1
  %t614 = extractvalue { i64, ptr } { i64 11, ptr @.d126 }, 0
  %t616 = extractvalue { i64, ptr } %t612, 1
  %t617 = extractvalue { i64, ptr } %t612, 0
  %t618 = add i64 %t614, %t617
  %t619 = extractvalue { i64, ptr } { i64 27, ptr @.d127 }, 1
  %t620 = extractvalue { i64, ptr } { i64 27, ptr @.d127 }, 0
  %t621 = add i64 %t618, %t620
  %t622 = call ptr @__olang_scope_alloc(ptr %s29, i64 %t621)
  call void @olang_textcopy(ptr %t622, ptr %t613, i64 %t614)
  %t623 = getelementptr i8, ptr %t622, i64 %t614
  call void @olang_textcopy(ptr %t623, ptr %t616, i64 %t617)
  %t624 = getelementptr i8, ptr %t623, i64 %t617
  call void @olang_textcopy(ptr %t624, ptr %t619, i64 %t620)
  %t625 = insertvalue { i64, ptr } undef, i64 %t621, 0
  %t626 = insertvalue { i64, ptr } %t625, ptr %t622, 1
  %t628 = extractvalue { i64, ptr } %t626, 0
  %t629 = extractvalue { i64, ptr } %t626, 1
  %t630 = mul i64 %t628, 1
  %t631 = call ptr @__olang_scope_alloc(ptr %s29, i64 %t630)
  call void @llvm.memcpy.p0.p0.i64(ptr %t631, ptr %t629, i64 %t630, i1 false)
  %t632 = insertvalue { i64, ptr } undef, i64 %t628, 0
  %t633 = insertvalue { i64, ptr } %t632, ptr %t631, 1
  call void @compiler_2fbuild_2eUnbuildable(ptr %s29, { i64, ptr } %t633)
  br label %bb136
bb136:
  call void @__olang_scope_close(ptr %s29)
  call void @__olang_scope_close(ptr %s27)
  call void @__olang_scope_close(ptr %s26)
  call void @__olang_scope_close(ptr %s24)
  call void @__olang_scope_close(ptr %s23)
  call void @__olang_scope_close(ptr %s22)
  call void @__olang_scope_close(ptr %s0)
  store i32 65537, ptr %rv
  br label %ret
bb137:
  %t636 = load { i64, ptr }, ptr %l279, !tbaa !27
  store { i64, ptr } %t636, ptr %l47, !tbaa !27
  %t637 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } { i64 16, ptr @.d128 }, ptr %l295, !tbaa !27
  %t640 = load { i64, ptr }, ptr %l295, !tbaa !27
  %t641 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v3, ptr %s27, { i64, ptr } %t637, { i64, ptr } %t640)
  store i1 %t641, ptr %l296
  br label %bb138
bb138:
  %t642 = load i1, ptr %l296, !tbaa !21
  br i1 %t642, label %bb139, label %bb140
bb139:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb141
bb140:
  br label %bb141
bb141:
  %t643 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t645 = extractvalue { i64, ptr } %t643, 1
  %t646 = extractvalue { i64, ptr } %t643, 0
  %t647 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t646)
  call void @olang_textcopy(ptr %t647, ptr %t645, i64 %t646)
  %t648 = insertvalue { i64, ptr } undef, i64 %t646, 0
  %t649 = insertvalue { i64, ptr } %t648, ptr %t647, 1
  %t651 = extractvalue { i64, ptr } %t649, 0
  %t652 = extractvalue { i64, ptr } %t649, 1
  %t653 = mul i64 %t651, 1
  %t654 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t653)
  call void @llvm.memcpy.p0.p0.i64(ptr %t654, ptr %t652, i64 %t653, i1 false)
  %t655 = insertvalue { i64, ptr } undef, i64 %t651, 0
  %t656 = insertvalue { i64, ptr } %t655, ptr %t654, 1
  store { i64, ptr } %t656, ptr %l299, !tbaa !27
  %t657 = getelementptr %"compiler/emit:Reused", ptr %l37, i32 0, i32 2
  %t658 = load i64, ptr %l45, !tbaa !24
  %t661 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v2, ptr %t657, i64 %t658)
  store i1 %t661, ptr %l302
  br label %bb142
bb142:
  %t662 = load i1, ptr %l302, !tbaa !21
  br i1 %t662, label %bb143, label %bb144
bb143:
  store i32 4, ptr %l303
  br label %bb145
bb144:
  store i32 0, ptr %l303
  br label %bb145
bb145:
  %t665 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t666 = load { i64, ptr }, ptr %l299, !tbaa !27
  %t667 = load i32, ptr %l303
  %t669 = call %"compiler/build:Unit" @compiler_2fbuild_3aUnit_2ector(ptr %v3, ptr %v3, ptr %v3, { i64, ptr } %t666, i32 %t667, { i64, ptr } %t665)
  store %"compiler/build:Unit" %t669, ptr %l307
  br label %bb146
bb146:
  %t670 = load %"compiler/build:Unit", ptr %l307
  %t671 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 56, i64 8)
  store %"compiler/build:Unit" %t670, ptr %t671
  store ptr %t671, ptr %l48, !tbaa !29
  %t673 = load ptr, ptr %l48, !tbaa !29
  store ptr %t673, ptr %l309, !tbaa !29
  %t674 = getelementptr %"compiler/emit:Reused", ptr %l37, i32 0, i32 3
  %t675 = load i64, ptr %l45, !tbaa !24
  %t678 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v2, ptr %s27, ptr %t674, i64 %t675)
  store { i64, ptr } %t678, ptr %l312
  br label %bb147
bb147:
  %t679 = load { i64, ptr }, ptr %l312, !tbaa !27
  %t680 = extractvalue { i64, ptr } %t679, 1
  %t681 = extractvalue { i64, ptr } %t679, 0
  %t682 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t681)
  call void @olang_textcopy(ptr %t682, ptr %t680, i64 %t681)
  %t683 = insertvalue { i64, ptr } undef, i64 %t681, 0
  %t684 = insertvalue { i64, ptr } %t683, ptr %t682, 1
  %t686 = extractvalue { i64, ptr } %t684, 0
  %t687 = extractvalue { i64, ptr } %t684, 1
  %t688 = mul i64 %t686, 1
  %t689 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t688)
  call void @llvm.memcpy.p0.p0.i64(ptr %t689, ptr %t687, i64 %t688, i1 false)
  %t690 = insertvalue { i64, ptr } undef, i64 %t686, 0
  %t691 = insertvalue { i64, ptr } %t690, ptr %t689, 1
  %t693 = load ptr, ptr %l309, !tbaa !29
  %t694 = getelementptr %"compiler/build:Unit", ptr %t693, i32 0, i32 3
  store { i64, ptr } %t691, ptr %t694, !tbaa !27
  %t695 = load ptr, ptr %l4, !tbaa !29
  %t697 = getelementptr %"compiler/build:Program", ptr %t695, i32 0, i32 0
  %t698 = load ptr, ptr %l48, !tbaa !29
  %t700 = load %"compiler/build:Unit", ptr %t698
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2ePush_3ccompiler_2fbuild_3aUnit_3e(ptr %v3, ptr %v3, ptr %t697, %"compiler/build:Unit" %t700)
  br label %bb148
bb148:
  call void @__olang_scope_close(ptr %s27)
  br label %bb149
bb149:
  %t703 = load i64, ptr %l44, !tbaa !24
  %t705 = add i64 %t703, 1
  store i64 %t705, ptr %l44, !tbaa !24
  %t707 = load i64, ptr %l41, !tbaa !24
  %t709 = add i64 %t707, 1
  store i64 %t709, ptr %l41, !tbaa !24
  br label %bb127
bb150:
  %t711 = load i64, ptr %l40, !tbaa !24
  %t712 = load i64, ptr %l43, !tbaa !24
  %t715 = add i64 %t711, %t712
  store i64 %t715, ptr %l40, !tbaa !24
  call void @__olang_scope_close(ptr %s26)
  br label %bb151
bb151:
  br label %bb120
bb152:
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l30, { i64, ptr } { i64 0, ptr @.d129 })
  br label %bb153
bb153:
  call void @__olang_scope_close(ptr %s24)
  call void @__olang_scope_close(ptr %s23)
  br label %bb193
bb154:
  %t718 = getelementptr %"compiler/emit:Object", ptr %l36, i32 0, i32 2
  %t719 = load { i64, ptr }, ptr %t718, !tbaa !27
  store { i64, ptr } %t719, ptr %l49, !tbaa !27
  %t721 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } { i64 16, ptr @.d130 }, ptr %l330, !tbaa !27
  %t724 = load { i64, ptr }, ptr %l330, !tbaa !27
  %t725 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v3, ptr %s23, { i64, ptr } %t721, { i64, ptr } %t724)
  store i1 %t725, ptr %l331
  br label %bb155
bb155:
  %t726 = load i1, ptr %l331, !tbaa !21
  br i1 %t726, label %bb156, label %bb157
bb156:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb158
bb157:
  br label %bb158
bb158:
  %t727 = getelementptr %"compiler/emit:Object", ptr %l36, i32 0, i32 1
  %t728 = load i32, ptr %t727
  store i32 %t728, ptr %l50
  %t730 = load i32, ptr %l50
  %t732 = trunc i64 0 to i32
  %t733 = icmp eq i32 %t730, %t732
  br i1 %t733, label %bb159, label %bb160
bb159:
  br label %bb161
bb160:
  br label %bb162
bb161:
  store i32 0, ptr %l333
  br label %bb179
bb162:
  %t736 = load i32, ptr %l50
  %t738 = trunc i64 1 to i32
  %t739 = icmp eq i32 %t736, %t738
  br i1 %t739, label %bb163, label %bb164
bb163:
  br label %bb165
bb164:
  br label %bb166
bb165:
  store i32 1, ptr %l333
  br label %bb179
bb166:
  %t742 = load i32, ptr %l50
  %t744 = trunc i64 2 to i32
  %t745 = icmp eq i32 %t742, %t744
  br i1 %t745, label %bb167, label %bb168
bb167:
  br label %bb169
bb168:
  br label %bb170
bb169:
  store i32 2, ptr %l333
  br label %bb179
bb170:
  %t748 = load i32, ptr %l50
  %t750 = trunc i64 3 to i32
  %t751 = icmp eq i32 %t748, %t750
  br i1 %t751, label %bb171, label %bb172
bb171:
  br label %bb173
bb172:
  br label %bb174
bb173:
  store i32 3, ptr %l333
  br label %bb179
bb174:
  %t754 = load i32, ptr %l50
  %t756 = trunc i64 4 to i32
  %t757 = icmp eq i32 %t754, %t756
  br i1 %t757, label %bb175, label %bb176
bb175:
  br label %bb177
bb176:
  br label %bb178
bb177:
  store i32 4, ptr %l333
  br label %bb179
bb178:
  call void @__olang_check_failed(ptr @olang_loc_5772a8514d833044_b816e84cde98ab20)
  unreachable
bb179:
  %t760 = load i32, ptr %l333
  %t761 = getelementptr %"compiler/emit:Object", ptr %l36, i32 0, i32 0
  %t762 = load { i64, ptr }, ptr %t761, !tbaa !27
  %t764 = extractvalue { i64, ptr } %t762, 1
  %t765 = extractvalue { i64, ptr } %t762, 0
  %t766 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t765)
  call void @olang_textcopy(ptr %t766, ptr %t764, i64 %t765)
  %t767 = insertvalue { i64, ptr } undef, i64 %t765, 0
  %t768 = insertvalue { i64, ptr } %t767, ptr %t766, 1
  %t770 = extractvalue { i64, ptr } %t768, 0
  %t771 = extractvalue { i64, ptr } %t768, 1
  %t772 = mul i64 %t770, 1
  %t773 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t772)
  call void @llvm.memcpy.p0.p0.i64(ptr %t773, ptr %t771, i64 %t772, i1 false)
  %t774 = insertvalue { i64, ptr } undef, i64 %t770, 0
  %t775 = insertvalue { i64, ptr } %t774, ptr %t773, 1
  %t777 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t781 = call %"compiler/build:Unit" @compiler_2fbuild_3aUnit_2ector(ptr %v3, ptr %v3, ptr %v3, { i64, ptr } %t775, i32 %t760, { i64, ptr } %t777)
  store %"compiler/build:Unit" %t781, ptr %l354
  br label %bb180
bb180:
  %t782 = load %"compiler/build:Unit", ptr %l354
  %t783 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 56, i64 8)
  store %"compiler/build:Unit" %t782, ptr %t783
  store ptr %t783, ptr %l52, !tbaa !29
  %t785 = load i32, ptr %l2
  %t787 = trunc i64 0 to i32
  %t788 = icmp eq i32 %t785, %t787
  %t790 = xor i1 %t788, true
  br i1 %t790, label %bb181, label %bb182
bb181:
  %t792 = getelementptr %"compiler/emit:Object", ptr %l36, i32 0, i32 1
  %t793 = load i32, ptr %t792
  %t795 = trunc i64 0 to i32
  %t796 = icmp eq i32 %t793, %t795
  br i1 %t796, label %bb183, label %bb184
bb182:
  store i1 false, ptr %l359, !tbaa !21
  br label %bb186
bb183:
  store i1 true, ptr %l362, !tbaa !21
  br label %bb185
bb184:
  %t798 = getelementptr %"compiler/emit:Object", ptr %l36, i32 0, i32 1
  %t799 = load i32, ptr %t798
  %t801 = trunc i64 4 to i32
  %t802 = icmp eq i32 %t799, %t801
  store i1 %t802, ptr %l362, !tbaa !21
  br label %bb185
bb185:
  %t804 = load i1, ptr %l362, !tbaa !21
  store i1 %t804, ptr %l359, !tbaa !21
  br label %bb186
bb186:
  %t805 = load i1, ptr %l359, !tbaa !21
  br i1 %t805, label %bb187, label %bb188
bb187:
  %t806 = load ptr, ptr %l52, !tbaa !29
  store ptr %t806, ptr %l365, !tbaa !29
  %t807 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t809 = call { i64, ptr } @compiler_2fbuild_2eIrHash(ptr %v3, ptr %v3, { i64, ptr } %t807)
  store { i64, ptr } %t809, ptr %l367
  br label %bb189
bb188:
  br label %bb190
bb189:
  %t810 = load { i64, ptr }, ptr %l367, !tbaa !27
  %t811 = extractvalue { i64, ptr } %t810, 0
  %t812 = extractvalue { i64, ptr } %t810, 1
  %t813 = mul i64 %t811, 1
  %t814 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t813)
  call void @llvm.memcpy.p0.p0.i64(ptr %t814, ptr %t812, i64 %t813, i1 false)
  %t815 = insertvalue { i64, ptr } undef, i64 %t811, 0
  %t816 = insertvalue { i64, ptr } %t815, ptr %t814, 1
  %t818 = load ptr, ptr %l365, !tbaa !29
  %t819 = getelementptr %"compiler/build:Unit", ptr %t818, i32 0, i32 3
  store { i64, ptr } %t816, ptr %t819, !tbaa !27
  br label %bb190
bb190:
  %t820 = load ptr, ptr %l52, !tbaa !29
  %t822 = getelementptr %"compiler/build:Unit", ptr %t820, i32 0, i32 3
  %t823 = load { i64, ptr }, ptr %t822, !tbaa !27
  %t825 = extractvalue { i64, ptr } %t823, 1
  %t826 = extractvalue { i64, ptr } %t823, 0
  %t827 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t826)
  call void @olang_textcopy(ptr %t827, ptr %t825, i64 %t826)
  %t828 = insertvalue { i64, ptr } undef, i64 %t826, 0
  %t829 = insertvalue { i64, ptr } %t828, ptr %t827, 1
  %t831 = extractvalue { i64, ptr } %t829, 0
  %t832 = extractvalue { i64, ptr } %t829, 1
  %t833 = mul i64 %t831, 1
  %t834 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t833)
  call void @llvm.memcpy.p0.p0.i64(ptr %t834, ptr %t832, i64 %t833, i1 false)
  %t835 = insertvalue { i64, ptr } undef, i64 %t831, 0
  %t836 = insertvalue { i64, ptr } %t835, ptr %t834, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l30, { i64, ptr } %t836)
  br label %bb191
bb191:
  %t839 = load ptr, ptr %l4, !tbaa !29
  %t841 = getelementptr %"compiler/build:Program", ptr %t839, i32 0, i32 0
  %t842 = load ptr, ptr %l52, !tbaa !29
  %t844 = load %"compiler/build:Unit", ptr %t842
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2ePush_3ccompiler_2fbuild_3aUnit_3e(ptr %v3, ptr %v3, ptr %t841, %"compiler/build:Unit" %t844)
  br label %bb192
bb192:
  call void @__olang_scope_close(ptr %s23)
  br label %bb193
bb193:
  %t847 = load i64, ptr %l35, !tbaa !24
  %t849 = add i64 %t847, 1
  store i64 %t849, ptr %l35, !tbaa !24
  br label %bb111
bb194:
  %t851 = load i64, ptr %l32, !tbaa !24
  %t852 = load i64, ptr %l34, !tbaa !24
  %t855 = add i64 %t851, %t852
  store i64 %t855, ptr %l32, !tbaa !24
  call void @__olang_scope_close(ptr %s22)
  br label %bb195
bb195:
  br label %bb104
bb196:
  %t857 = load i32, ptr %l2
  %t859 = trunc i64 0 to i32
  %t860 = icmp eq i32 %t857, %t859
  %t862 = xor i1 %t860, true
  br i1 %t862, label %bb197, label %bb198
bb197:
  %t864 = load ptr, ptr %l7, !tbaa !29
  %t865 = load ptr, ptr %l3, !tbaa !29
  %t866 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t867 = load ptr, ptr %l13, !tbaa !29
  %t869 = getelementptr %"compiler/emit:Emitter", ptr %t867, i32 0, i32 61
  call void @compiler_2folang_2ekeep(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v3, ptr %s0, ptr %t864, ptr %t865, { i64, ptr } %t866, ptr %t869, ptr %l15, ptr %l30)
  br label %bb199
bb198:
  br label %bb200
bb199:
  br label %bb200
bb200:
  %t876 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 16, ptr @.d131 })
  %t877 = extractvalue { i32, { i64, ptr } } %t876, 1
  %t878 = extractvalue { i32, { i64, ptr } } %t876, 0
  store i32 %t878, ptr %l395
  %t879 = icmp ne i32 %t878, 0
  br i1 %t879, label %bb202, label %ok.880
ok.880:
  store { i64, ptr } %t877, ptr %l394
  br label %bb201
bb201:
  %t881 = load { i64, ptr }, ptr %l394, !tbaa !27
  store { i64, ptr } %t881, ptr %l393, !tbaa !27
  br label %bb204
bb202:
  br label %bb203
bb203:
  store { i64, ptr } { i64 0, ptr @.d132 }, ptr %l396, !tbaa !27
  %t882 = load { i64, ptr }, ptr %l396, !tbaa !27
  %t884 = extractvalue { i64, ptr } %t882, 0
  %t885 = extractvalue { i64, ptr } %t882, 1
  %t886 = mul i64 %t884, 1
  %t887 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t886)
  call void @llvm.memcpy.p0.p0.i64(ptr %t887, ptr %t885, i64 %t886, i1 false)
  %t888 = insertvalue { i64, ptr } undef, i64 %t884, 0
  %t889 = insertvalue { i64, ptr } %t888, ptr %t887, 1
  store { i64, ptr } %t889, ptr %l393, !tbaa !27
  br label %bb204
bb204:
  %t891 = load { i64, ptr }, ptr %l393, !tbaa !27
  %t892 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t891, { i64, ptr } { i64 0, ptr @.d133 })
  store i1 %t892, ptr %l399
  br label %bb205
bb205:
  %t893 = load i1, ptr %l399, !tbaa !21
  %t894 = xor i1 %t893, true
  br i1 %t894, label %bb206, label %bb207
bb206:
  %t896 = load ptr, ptr %l13, !tbaa !29
  %t897 = load ptr, ptr %l4, !tbaa !29
  %t898 = load ptr, ptr %l8, !tbaa !29
  %t899 = load ptr, ptr %l12, !tbaa !29
  %t900 = load ptr, ptr %l5, !tbaa !29
  %t901 = load ptr, ptr %l3, !tbaa !29
  %t902 = load i32, ptr %l2
  %t903 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2folang_2echeckReuse(ptr %v2, ptr %v3, ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %t896, ptr %t897, ptr %t898, ptr %t899, ptr %t900, ptr %t901, i32 %t902, ptr %t903)
  br label %bb208
bb207:
  br label %bb209
bb208:
  br label %bb209
bb209:
  %t912 = load ptr, ptr %l4, !tbaa !29
  store ptr %t912, ptr %l409, !tbaa !29
  %t913 = load ptr, ptr %l7, !tbaa !29
  %t915 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fload_2ecompiler_2fload_3aLoader_2eLinks(ptr %v2, ptr %v3, ptr %t913)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t915, ptr %l411
  br label %bb210
bb210:
  %t916 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l411
  %t917 = load ptr, ptr %l409, !tbaa !29
  %t918 = getelementptr %"compiler/build:Program", ptr %t917, i32 0, i32 3
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t916, ptr %t918
  %t919 = load ptr, ptr %l5, !tbaa !29
  %t921 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v2, ptr %t919)
  store i64 %t921, ptr %l413
  br label %bb211
bb211:
  %t922 = load i64, ptr %l413, !tbaa !24
  %t923 = icmp sgt i64 %t922, 0
  br i1 %t923, label %bb212, label %bb213
bb212:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb213:
  br label %bb214
bb214:
  %t926 = load ptr, ptr %l4, !tbaa !29
  store ptr %t926, ptr %l416, !tbaa !29
  %t927 = getelementptr %"compiler/target:Target", ptr %l28, i32 0, i32 1
  %t928 = load { i64, ptr }, ptr %t927, !tbaa !27
  %t929 = getelementptr %"compiler/target:Target", ptr %l28, i32 0, i32 2
  %t930 = load { i64, ptr }, ptr %t929, !tbaa !27
  %t931 = getelementptr %"compiler/target:Target", ptr %l28, i32 0, i32 5
  %t932 = load { i64, ptr }, ptr %t931, !tbaa !27
  %t933 = load ptr, ptr %l3, !tbaa !29
  %t935 = getelementptr %"compiler/build:Config", ptr %t933, i32 0, i32 7
  %t936 = load i1, ptr %t935, !tbaa !21
  %t937 = load ptr, ptr %l3, !tbaa !29
  %t939 = getelementptr %"compiler/build:Config", ptr %t937, i32 0, i32 6
  %t940 = load i1, ptr %t939, !tbaa !21
  %t946 = call { i32, { i64, ptr } } @compiler_2fruntime_2eIr(ptr %v2, ptr %v2, ptr %v2, ptr %v3, { i64, ptr } %t928, { i64, ptr } %t930, { i64, ptr } %t932, i1 %t936, i1 %t940)
  %t947 = extractvalue { i32, { i64, ptr } } %t946, 1
  %t948 = extractvalue { i32, { i64, ptr } } %t946, 0
  store i32 %t948, ptr %l426
  %t949 = icmp ne i32 %t948, 0
  br i1 %t949, label %bb216, label %ok.950
ok.950:
  store { i64, ptr } %t947, ptr %l425
  br label %bb215
bb215:
  %t951 = load { i64, ptr }, ptr %l425, !tbaa !27
  store { i64, ptr } %t951, ptr %l417, !tbaa !27
  br label %bb220
bb216:
  %t952 = load i32, ptr %l426, !tbaa !23
  %t953 = ashr i32 %t952, 16
  %t955 = icmp eq i32 %t953, 1
  br i1 %t955, label %bb217, label %bb218
bb217:
  br label %bb219
bb218:
  %t957 = load i32, ptr %l426, !tbaa !23
  %t958 = lshr i32 %t957, 16
  %t959 = and i32 %t957, 65535
  %t960 = icmp eq i32 %t958, 1
  %t961 = select i1 %t960, i32 0, i32 0
  %t962 = icmp eq i32 %t957, 0
  %t963 = shl i32 %t961, 16
  %t964 = or i32 %t963, %t959
  %t965 = select i1 %t962, i32 0, i32 %t964
  call void @__olang_scope_close(ptr %s0)
  store i32 %t965, ptr %rv
  br label %ret
bb219:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb220:
  %t968 = load { i64, ptr }, ptr %l417, !tbaa !27
  %t969 = extractvalue { i64, ptr } %t968, 0
  %t970 = extractvalue { i64, ptr } %t968, 1
  %t971 = mul i64 %t969, 1
  %t972 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t971)
  call void @llvm.memcpy.p0.p0.i64(ptr %t972, ptr %t970, i64 %t971, i1 false)
  %t973 = insertvalue { i64, ptr } undef, i64 %t969, 0
  %t974 = insertvalue { i64, ptr } %t973, ptr %t972, 1
  %t976 = load ptr, ptr %l416, !tbaa !29
  %t977 = getelementptr %"compiler/build:Program", ptr %t976, i32 0, i32 1
  store { i64, ptr } %t974, ptr %t977, !tbaa !27
  %t978 = load i1, ptr %l29, !tbaa !21
  br i1 %t978, label %bb221, label %bb222
bb221:
  %t980 = load ptr, ptr %l4, !tbaa !29
  store ptr %t980, ptr %l433, !tbaa !29
  %t981 = getelementptr %"compiler/target:Target", ptr %l28, i32 0, i32 1
  %t982 = load { i64, ptr }, ptr %t981, !tbaa !27
  %t983 = getelementptr %"compiler/target:Target", ptr %l28, i32 0, i32 2
  %t984 = load { i64, ptr }, ptr %t983, !tbaa !27
  %t985 = getelementptr %"compiler/target:Target", ptr %l28, i32 0, i32 5
  %t986 = load { i64, ptr }, ptr %t985, !tbaa !27
  %t987 = load ptr, ptr %l3, !tbaa !29
  %t989 = getelementptr %"compiler/build:Config", ptr %t987, i32 0, i32 7
  %t990 = load i1, ptr %t989, !tbaa !21
  %t991 = load ptr, ptr %l3, !tbaa !29
  %t993 = getelementptr %"compiler/build:Config", ptr %t991, i32 0, i32 6
  %t994 = load i1, ptr %t993, !tbaa !21
  %t1000 = call { i32, { i64, ptr } } @compiler_2fruntime_2eDyncallIr(ptr %v2, ptr %v2, ptr %v2, ptr %v3, { i64, ptr } %t982, { i64, ptr } %t984, { i64, ptr } %t986, i1 %t990, i1 %t994)
  %t1001 = extractvalue { i32, { i64, ptr } } %t1000, 1
  %t1002 = extractvalue { i32, { i64, ptr } } %t1000, 0
  store i32 %t1002, ptr %l443
  %t1003 = icmp ne i32 %t1002, 0
  br i1 %t1003, label %bb224, label %ok.1004
ok.1004:
  store { i64, ptr } %t1001, ptr %l442
  br label %bb223
bb222:
  br label %bb229
bb223:
  %t1005 = load { i64, ptr }, ptr %l442, !tbaa !27
  store { i64, ptr } %t1005, ptr %l434, !tbaa !27
  br label %bb228
bb224:
  %t1006 = load i32, ptr %l443, !tbaa !23
  %t1007 = ashr i32 %t1006, 16
  %t1009 = icmp eq i32 %t1007, 1
  br i1 %t1009, label %bb225, label %bb226
bb225:
  br label %bb227
bb226:
  %t1011 = load i32, ptr %l443, !tbaa !23
  %t1012 = lshr i32 %t1011, 16
  %t1013 = and i32 %t1011, 65535
  %t1014 = icmp eq i32 %t1012, 1
  %t1015 = select i1 %t1014, i32 0, i32 0
  %t1016 = icmp eq i32 %t1011, 0
  %t1017 = shl i32 %t1015, 16
  %t1018 = or i32 %t1017, %t1013
  %t1019 = select i1 %t1016, i32 0, i32 %t1018
  call void @__olang_scope_close(ptr %s0)
  store i32 %t1019, ptr %rv
  br label %ret
bb227:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb228:
  %t1022 = load { i64, ptr }, ptr %l434, !tbaa !27
  %t1023 = extractvalue { i64, ptr } %t1022, 0
  %t1024 = extractvalue { i64, ptr } %t1022, 1
  %t1025 = mul i64 %t1023, 1
  %t1026 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t1025)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1026, ptr %t1024, i64 %t1025, i1 false)
  %t1027 = insertvalue { i64, ptr } undef, i64 %t1023, 0
  %t1028 = insertvalue { i64, ptr } %t1027, ptr %t1026, 1
  %t1030 = load ptr, ptr %l433, !tbaa !29
  %t1031 = getelementptr %"compiler/build:Program", ptr %t1030, i32 0, i32 2
  store { i64, ptr } %t1028, ptr %t1031, !tbaa !27
  br label %bb229
bb229:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2folang_2ecompiler_2folang_3aPasses_2eExplain(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca ptr
  %lp11 = alloca ptr
  %l12 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i32
  %l21 = alloca %"compiler/check:Checker"
  %l23 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l26 = alloca i64
  %l30 = alloca i64
  %l33 = alloca i64
  %l36 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l38 = alloca i64
  %l45 = alloca %"compiler/scope:Scoper"
  %l55 = alloca i64
  %l63 = alloca %"compiler/interp:Exec"
  %l68 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %l76 = alloca i32
  %l80 = alloca ptr
  %l81 = alloca { i64, [3 x i64] }
  %l84 = alloca %"compiler/msgs:Msg"
  %l85 = alloca i64
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  %t28 = alloca %"compiler/check:Checker", align 8
  %t73 = alloca %"compiler/scope:Scoper", align 8
  %t122 = alloca %"compiler/interp:Exec", align 8
  %t172 = alloca { i64, [3 x i64] }, align 8
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t4 = load ptr, ptr %l4, !tbaa !29
  %t9 = call { i32, ptr } @compiler_2folang_2ecompiler_2folang_3aPasses_2eload(ptr %v0, ptr %v1, ptr %v3, ptr %a0, { i64, ptr } %t2, ptr %a3, ptr %t4)
  %t10 = extractvalue { i32, ptr } %t9, 1
  %t11 = extractvalue { i32, ptr } %t9, 0
  store i32 %t11, ptr %l18
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb2, label %ok.13
ok.13:
  store ptr %t10, ptr %l17
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l17, !tbaa !29
  store ptr %t14, ptr %l12, !tbaa !29
  br label %bb3
bb2:
  %t15 = load i32, ptr %l18, !tbaa !23
  %t16 = lshr i32 %t15, 16
  %t17 = and i32 %t15, 65535
  %t18 = icmp eq i32 %t16, 1
  %t19 = select i1 %t18, i32 1, i32 0
  %t20 = icmp eq i32 %t15, 0
  %t21 = shl i32 %t19, 16
  %t22 = or i32 %t21, %t17
  %t23 = select i1 %t20, i32 0, i32 %t22
  %t25 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t23, 0
  store { i32, { i64, ptr } } %t25, ptr %rv
  br label %ret
bb3:
  %t26 = load ptr, ptr %l12, !tbaa !29
  store ptr %t26, ptr %l5, !tbaa !29
  %t27 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2finterp_2eAnalyze(ptr %t28, ptr %v3, ptr %v3, ptr %t27, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l21, ptr %t28, i64 672, i1 false)
  br label %bb4
bb4:
  %t30 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 672, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %l21, i64 672, i1 false)
  store ptr %t30, ptr %l6, !tbaa !29
  %t32 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v3)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t32, ptr %l23
  br label %bb5
bb5:
  %t33 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l23
  %t34 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 8, i64 8)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t33, ptr %t34
  store ptr %t34, ptr %l7, !tbaa !29
  %t36 = load ptr, ptr %l4, !tbaa !29
  %t38 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v3, ptr %t36)
  store i64 %t38, ptr %l26
  br label %bb6
bb6:
  %t39 = load i64, ptr %l26, !tbaa !24
  %t40 = icmp eq i64 %t39, 0
  store i1 %t40, ptr %l8, !tbaa !21
  %t42 = load i1, ptr %l8, !tbaa !21
  br i1 %t42, label %bb7, label %bb8
bb7:
  %t44 = load ptr, ptr %l6, !tbaa !29
  %t46 = call i64 @compiler_2finterp_2eDecideValues(ptr %v3, ptr %t44)
  store i64 %t46, ptr %l30
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb10
bb10:
  %t47 = load ptr, ptr %l6, !tbaa !29
  %t48 = load ptr, ptr %l7, !tbaa !29
  %t51 = call i64 @compiler_2finterp_2eDecideAsserts(ptr %v3, ptr %v3, ptr %t47, ptr %t48)
  store i64 %t51, ptr %l33
  br label %bb11
bb11:
  %t52 = load i1, ptr %l8, !tbaa !21
  br i1 %t52, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t54 = load ptr, ptr %l6, !tbaa !29
  %t56 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2finterp_2eBake(ptr %v3, ptr %s2, ptr %t54)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t56, ptr %l36
  br label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb15:
  %t57 = load ptr, ptr %l4, !tbaa !29
  %t59 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v3, ptr %t57)
  store i64 %t59, ptr %l38
  br label %bb16
bb16:
  %t60 = load i64, ptr %l38, !tbaa !24
  %t61 = icmp sgt i64 %t60, 0
  br i1 %t61, label %bb17, label %bb18
bb17:
  %t64 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t64, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t65 = load ptr, ptr %l6, !tbaa !29
  %t67 = getelementptr %"compiler/check:Checker", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t69 = load ptr, ptr %l6, !tbaa !29
  %t71 = getelementptr %"compiler/check:Checker", ptr %t69, i32 0, i32 10
  %t72 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t71
  call void @compiler_2fscope_3aScoper_2ector(ptr %t73, ptr %v3, ptr %v3, ptr %v3, ptr %t68, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t72)
  call void @llvm.memmove.p0.p0.i64(ptr %l45, ptr %t73, i64 992, i1 false)
  br label %bb20
bb20:
  %t76 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 992, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t76, ptr %l45, i64 992, i1 false)
  store ptr %t76, ptr %l9, !tbaa !29
  %t78 = load ptr, ptr %l9, !tbaa !29
  %t79 = load ptr, ptr %l6, !tbaa !29
  %t80 = getelementptr { ptr, ptr }, ptr null, i32 1
  %t81 = ptrtoint ptr %t80 to i64
  %t82 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 %t81, i64 8)
  %t83 = getelementptr { ptr, ptr }, ptr %t82, i32 0, i32 0
  store ptr %t79, ptr %t83, !tbaa !28
  call void @__olang_scope_escape(ptr %v3)
  %t85 = getelementptr { ptr, ptr }, ptr %t82, i32 0, i32 1
  store ptr %v3, ptr %t85, !tbaa !28
  %t86 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_134, 0
  %t87 = insertvalue { ptr, ptr } %t86, ptr %t82, 1
  %t90 = getelementptr %"compiler/scope:Scoper", ptr %t78, i32 0, i32 4
  store { ptr, ptr } %t87, ptr %t90
  %t91 = load ptr, ptr %l9, !tbaa !29
  %t92 = load ptr, ptr %l6, !tbaa !29
  %t93 = getelementptr { ptr, ptr }, ptr null, i32 1
  %t94 = ptrtoint ptr %t93 to i64
  %t95 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 %t94, i64 8)
  %t96 = getelementptr { ptr, ptr }, ptr %t95, i32 0, i32 0
  store ptr %t92, ptr %t96, !tbaa !28
  call void @__olang_scope_escape(ptr %v3)
  %t98 = getelementptr { ptr, ptr }, ptr %t95, i32 0, i32 1
  store ptr %v3, ptr %t98, !tbaa !28
  %t99 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_135, 0
  %t100 = insertvalue { ptr, ptr } %t99, ptr %t95, 1
  %t103 = getelementptr %"compiler/scope:Scoper", ptr %t91, i32 0, i32 5
  store { ptr, ptr } %t100, ptr %t103
  %t104 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eRun(ptr %v3, ptr %t104)
  br label %bb21
bb21:
  %t106 = load ptr, ptr %l4, !tbaa !29
  %t108 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v3, ptr %t106)
  store i64 %t108, ptr %l55
  br label %bb22
bb22:
  %t109 = load i64, ptr %l55, !tbaa !24
  %t110 = icmp sgt i64 %t109, 0
  br i1 %t110, label %bb23, label %bb24
bb23:
  %t113 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t113, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  %t114 = load ptr, ptr %l6, !tbaa !29
  %t116 = getelementptr %"compiler/check:Checker", ptr %t114, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !29
  %t118 = load ptr, ptr %l6, !tbaa !29
  %t120 = getelementptr %"compiler/check:Checker", ptr %t118, i32 0, i32 10
  %t121 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t120
  call void @compiler_2finterp_3aExec_2ector(ptr %t122, ptr %v3, ptr %v3, ptr %v3, ptr %t117, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t121, i32 0)
  call void @llvm.memmove.p0.p0.i64(ptr %l63, ptr %t122, i64 896, i1 false)
  br label %bb26
bb26:
  %t126 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 896, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t126, ptr %l63, i64 896, i1 false)
  store ptr %t126, ptr %l10, !tbaa !29
  %t128 = load ptr, ptr %l10, !tbaa !29
  %t129 = load ptr, ptr %l6, !tbaa !29
  %t131 = getelementptr %"compiler/check:Checker", ptr %t129, i32 0, i32 83
  %t132 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t131
  %t135 = getelementptr %"compiler/interp:Exec", ptr %t128, i32 0, i32 10
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t132, ptr %t135
  %t136 = load ptr, ptr %l6, !tbaa !29
  %t137 = load ptr, ptr %l9, !tbaa !29
  %t138 = load ptr, ptr %l10, !tbaa !29
  %t139 = load ptr, ptr %l5, !tbaa !29
  %t141 = getelementptr %"compiler/load:Loader", ptr %t139, i32 0, i32 7
  %t142 = load i64, ptr %t141, !tbaa !24
  %t143 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t149 = call { i32, { i64, ptr } } @compiler_2fexplain_2eItem(ptr %v3, ptr %v3, ptr %v3, ptr %v2, ptr %v4, ptr %t136, ptr %t137, ptr %t138, i64 %t142, { i64, ptr } %t143)
  %t150 = extractvalue { i32, { i64, ptr } } %t149, 1
  %t151 = extractvalue { i32, { i64, ptr } } %t149, 0
  store i32 %t151, ptr %l76
  %t152 = icmp ne i32 %t151, 0
  br i1 %t152, label %bb28, label %ok.153
ok.153:
  store { i64, ptr } %t150, ptr %l75
  br label %bb27
bb27:
  %t154 = load { i64, ptr }, ptr %l75, !tbaa !27
  store { i64, ptr } %t154, ptr %l68, !tbaa !27
  br label %bb34
bb28:
  %t155 = load i32, ptr %l76, !tbaa !23
  %t156 = ashr i32 %t155, 16
  %t158 = icmp eq i32 %t156, 1
  br i1 %t158, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  %t160 = load i32, ptr %l76, !tbaa !23
  %t161 = lshr i32 %t160, 16
  %t162 = and i32 %t160, 65535
  %t163 = icmp eq i32 %t161, 1
  %t164 = select i1 %t163, i32 0, i32 0
  %t165 = icmp eq i32 %t160, 0
  %t166 = shl i32 %t164, 16
  %t167 = or i32 %t166, %t162
  %t168 = select i1 %t165, i32 0, i32 %t167
  %t170 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t168, 0
  store { i32, { i64, ptr } } %t170, ptr %rv
  br label %ret
bb31:
  store %olang.scope zeroinitializer, ptr %s5
  %t171 = load ptr, ptr %l4, !tbaa !29
  store ptr %t171, ptr %l80, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t172
  %t173 = getelementptr { i64, [3 x i64] }, ptr %t172, i32 0, i32 0
  store i64 0, ptr %t173
  %t174 = load { i64, [3 x i64] }, ptr %t172
  store { i64, [3 x i64] } %t174, ptr %l81
  %t175 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t176 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t179 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eExplainNoItem(ptr %v2, ptr %v1, ptr %s5, { i64, ptr } %t175, { i64, ptr } %t176)
  store %"compiler/msgs:Msg" %t179, ptr %l84
  br label %bb32
bb32:
  %t180 = load ptr, ptr %l80, !tbaa !29
  %t181 = load { i64, [3 x i64] }, ptr %l81
  %t182 = load %"compiler/msgs:Msg", ptr %l84
  %t183 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v3, ptr %s5, ptr %t180, { i64, [3 x i64] } %t181, %"compiler/msgs:Msg" %t182)
  store i64 %t183, ptr %l85
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s5)
  %t185 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t185, ptr %rv
  br label %ret
bb34:
  %t186 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 16, i64 8)
  store ptr %t186, ptr %lp11
  %t187 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t188 = load ptr, ptr %lp11
  store { i64, ptr } %t187, ptr %t188, !tbaa !27
  %t189 = load ptr, ptr %lp11
  %t190 = load { i64, ptr }, ptr %t189, !tbaa !27
  %t192 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t190, 1
  store { i32, { i64, ptr } } %t192, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, i32 } @compiler_2folang_2ecompiler_2folang_3aPasses_2eInterpret(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l4 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca i32
  %l15 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca i32
  %l24 = alloca %"compiler/check:Checker"
  %l26 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l29 = alloca i64
  %l33 = alloca i64
  %l36 = alloca i64
  %l39 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l41 = alloca i64
  %l49 = alloca %"compiler/interp:Exec"
  %l63 = alloca { i64, ptr }
  %l76 = alloca i32
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca { i32, i32 }
  %t28 = alloca %"compiler/check:Checker", align 8
  %t73 = alloca %"compiler/interp:Exec", align 8
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t4 = load ptr, ptr %l4, !tbaa !29
  %t9 = call { i32, ptr } @compiler_2folang_2ecompiler_2folang_3aPasses_2eload(ptr %v0, ptr %v1, ptr %v3, ptr %a0, { i64, ptr } %a1, ptr %a3, ptr %t4)
  %t10 = extractvalue { i32, ptr } %t9, 1
  %t11 = extractvalue { i32, ptr } %t9, 0
  store i32 %t11, ptr %l21
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb2, label %ok.13
ok.13:
  store ptr %t10, ptr %l20
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l20, !tbaa !29
  store ptr %t14, ptr %l15, !tbaa !29
  br label %bb3
bb2:
  %t15 = load i32, ptr %l21, !tbaa !23
  %t16 = lshr i32 %t15, 16
  %t17 = and i32 %t15, 65535
  %t18 = icmp eq i32 %t16, 1
  %t19 = select i1 %t18, i32 1, i32 0
  %t20 = icmp eq i32 %t15, 0
  %t21 = shl i32 %t19, 16
  %t22 = or i32 %t21, %t17
  %t23 = select i1 %t20, i32 0, i32 %t22
  %t25 = insertvalue { i32, i32 } zeroinitializer, i32 %t23, 0
  store { i32, i32 } %t25, ptr %rv
  br label %ret
bb3:
  %t26 = load ptr, ptr %l15, !tbaa !29
  call void @compiler_2finterp_2eAnalyze(ptr %t28, ptr %v3, ptr %v3, ptr %t26, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l24, ptr %t28, i64 672, i1 false)
  br label %bb4
bb4:
  %t30 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 672, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %l24, i64 672, i1 false)
  store ptr %t30, ptr %l6, !tbaa !29
  %t32 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v3)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t32, ptr %l26
  br label %bb5
bb5:
  %t33 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l26
  %t34 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 8, i64 8)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t33, ptr %t34
  store ptr %t34, ptr %l7, !tbaa !29
  %t36 = load ptr, ptr %l4, !tbaa !29
  %t38 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v3, ptr %t36)
  store i64 %t38, ptr %l29
  br label %bb6
bb6:
  %t39 = load i64, ptr %l29, !tbaa !24
  %t40 = icmp eq i64 %t39, 0
  store i1 %t40, ptr %l8, !tbaa !21
  %t42 = load i1, ptr %l8, !tbaa !21
  br i1 %t42, label %bb7, label %bb8
bb7:
  %t44 = load ptr, ptr %l6, !tbaa !29
  %t46 = call i64 @compiler_2finterp_2eDecideValues(ptr %v3, ptr %t44)
  store i64 %t46, ptr %l33
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb10
bb10:
  %t47 = load ptr, ptr %l6, !tbaa !29
  %t48 = load ptr, ptr %l7, !tbaa !29
  %t51 = call i64 @compiler_2finterp_2eDecideAsserts(ptr %v3, ptr %v3, ptr %t47, ptr %t48)
  store i64 %t51, ptr %l36
  br label %bb11
bb11:
  %t52 = load i1, ptr %l8, !tbaa !21
  br i1 %t52, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t54 = load ptr, ptr %l6, !tbaa !29
  %t56 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2finterp_2eBake(ptr %v3, ptr %s2, ptr %t54)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t56, ptr %l39
  br label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb15:
  %t57 = load ptr, ptr %l4, !tbaa !29
  %t59 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v3, ptr %t57)
  store i64 %t59, ptr %l41
  br label %bb16
bb16:
  %t60 = load i64, ptr %l41, !tbaa !24
  %t61 = icmp sgt i64 %t60, 0
  br i1 %t61, label %bb17, label %bb18
bb17:
  %t64 = insertvalue { i32, i32 } zeroinitializer, i32 65536, 0
  store { i32, i32 } %t64, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t65 = load ptr, ptr %l6, !tbaa !29
  %t67 = getelementptr %"compiler/check:Checker", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t69 = load ptr, ptr %l6, !tbaa !29
  %t71 = getelementptr %"compiler/check:Checker", ptr %t69, i32 0, i32 10
  %t72 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t71
  call void @compiler_2finterp_3aExec_2ector(ptr %t73, ptr %v3, ptr %v3, ptr %v3, ptr %t68, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t72, i32 1)
  call void @llvm.memmove.p0.p0.i64(ptr %l49, ptr %t73, i64 896, i1 false)
  br label %bb20
bb20:
  %t77 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 896, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t77, ptr %l49, i64 896, i1 false)
  store ptr %t77, ptr %l9, !tbaa !29
  %t79 = load ptr, ptr %l9, !tbaa !29
  %t80 = load ptr, ptr %l7, !tbaa !29
  %t82 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t80
  %t85 = getelementptr %"compiler/interp:Exec", ptr %t79, i32 0, i32 3
  %t86 = getelementptr %"compiler/lower:Lowerer", ptr %t85, i32 0, i32 6
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t82, ptr %t86
  %t87 = load ptr, ptr %l9, !tbaa !29
  %t89 = getelementptr %"compiler/interp:Exec", ptr %t87, i32 0, i32 3
  %t90 = getelementptr %"compiler/lower:Lowerer", ptr %t89, i32 0, i32 5
  store i1 true, ptr %t90, !tbaa !21
  %t91 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2ePlace(ptr %v3, ptr %t91)
  br label %bb21
bb21:
  store { i64, ptr } %a2, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t95 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t95, 0
  store i64 %t97, ptr %l12, !tbaa !24
  br label %bb22
bb22:
  store %olang.scope zeroinitializer, ptr %s5
  %t99 = load i64, ptr %l11, !tbaa !24
  %t100 = load i64, ptr %l12, !tbaa !24
  %t103 = icmp slt i64 %t99, %t100
  %t105 = xor i1 %t103, true
  br i1 %t105, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s5)
  br label %bb28
bb24:
  br label %bb25
bb25:
  %t107 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t107, ptr %l63, !tbaa !27
  %t108 = load i64, ptr %l11, !tbaa !24
  %t110 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr { i64, ptr }, ptr %t111, i64 %t108
  %t113 = load { i64, ptr }, ptr %t112, !tbaa !37
  %t115 = load ptr, ptr %l9, !tbaa !29
  %t117 = getelementptr %"compiler/interp:Exec", ptr %t115, i32 0, i32 4
  %t118 = getelementptr %"compiler/eval:Machine", ptr %t117, i32 0, i32 64
  %t121 = extractvalue { i64, ptr } %t113, 1
  %t122 = extractvalue { i64, ptr } %t113, 0
  %t123 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t122)
  call void @olang_textcopy(ptr %t123, ptr %t121, i64 %t122)
  %t124 = insertvalue { i64, ptr } undef, i64 %t122, 0
  %t125 = insertvalue { i64, ptr } %t124, ptr %t123, 1
  %t127 = extractvalue { i64, ptr } %t125, 0
  %t128 = extractvalue { i64, ptr } %t125, 1
  %t129 = mul i64 %t127, 1
  %t130 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t129)
  call void @llvm.memcpy.p0.p0.i64(ptr %t130, ptr %t128, i64 %t129, i1 false)
  %t131 = insertvalue { i64, ptr } undef, i64 %t127, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr %t130, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v3, ptr %v3, ptr %t118, { i64, ptr } %t132)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s5)
  br label %bb27
bb27:
  %t135 = load i64, ptr %l11, !tbaa !24
  %t137 = add i64 %t135, 1
  store i64 %t137, ptr %l11, !tbaa !24
  br label %bb22
bb28:
  %t139 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eInterpCrash, !tbaa !27
  %t140 = load ptr, ptr @__olang_prog_scope
  call void @std_2fos_2eOnCrash(ptr %t140, { i64, ptr } %t139)
  br label %bb29
bb29:
  %t142 = load ptr, ptr %l9, !tbaa !29
  %t143 = load ptr, ptr %l4, !tbaa !29
  %t146 = call i32 @compiler_2finterp_2ecompiler_2finterp_3aExec_2eRunMain(ptr %v3, ptr %v3, ptr %t142, ptr %t143)
  store i32 %t146, ptr %l76
  br label %bb30
bb30:
  %t147 = load i32, ptr %l76, !tbaa !23
  store i32 %t147, ptr %l14, !tbaa !23
  %t148 = load i32, ptr %l14, !tbaa !23
  %t150 = icmp eq i32 %t148, 134
  br i1 %t150, label %bb31, label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s8
  call void @std_2fos_2eOnCrash(ptr %s8, { i64, ptr } { i64 0, ptr @.d136 })
  br label %bb33
bb32:
  br label %bb35
bb33:
  call void @abort()
  unreachable
bb34:
  call void @__olang_check_failed(ptr @olang_loc_312804dbefbae76a_26e5fd70c2793cc6)
  unreachable
bb35:
  %t152 = load i32, ptr %l14, !tbaa !23
  %t154 = insertvalue { i32, i32 } zeroinitializer, i32 %t152, 1
  store { i32, i32 } %t154, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i32 }, ptr %rv
  ret { i32, i32 } %rr
}

define dso_local { i32, ptr } @compiler_2folang_2ecompiler_2folang_3aPasses_2eload(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l16 = alloca %"compiler/fetch:Fetcher"
  %l18 = alloca %"compiler/source:Names"
  %l20 = alloca { i64, ptr }
  %l27 = alloca %"compiler/load:Loader"
  %l31 = alloca i64
  %l32 = alloca ptr
  %l35 = alloca i64
  %l37 = alloca i64
  %rv = alloca { i32, ptr }
  store { i64, ptr } %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = call { i64, ptr } @compiler_2fload_2eLockPath(ptr %v1, ptr %v2, { i64, ptr } %t1)
  store { i64, ptr } %t3, ptr %l8
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t4, 0
  %t6 = extractvalue { i64, ptr } %t4, 1
  %t7 = mul i64 %t5, 1
  %t8 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t7)
  call void @llvm.memcpy.p0.p0.i64(ptr %t8, ptr %t6, i64 %t7, i1 false)
  %t9 = insertvalue { i64, ptr } undef, i64 %t5, 0
  %t10 = insertvalue { i64, ptr } %t9, ptr %t8, 1
  store { i64, ptr } %t10, ptr %l9, !tbaa !27
  %t11 = call { i64, ptr } @compiler_2ffetch_2eCacheDir(ptr %v2)
  store { i64, ptr } %t11, ptr %l10
  br label %bb2
bb2:
  %t12 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 0
  %t14 = extractvalue { i64, ptr } %t12, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l11, !tbaa !27
  %t19 = call { i64, ptr } @compiler_2ffetch_2eGitBase(ptr %v2)
  store { i64, ptr } %t19, ptr %l12
  br label %bb3
bb3:
  %t20 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t20, 0
  %t22 = extractvalue { i64, ptr } %t20, 1
  %t23 = mul i64 %t21, 1
  %t24 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t23)
  call void @llvm.memcpy.p0.p0.i64(ptr %t24, ptr %t22, i64 %t23, i1 false)
  %t25 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t24, 1
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t29 = getelementptr %"compiler/build:Config", ptr %t27, i32 0, i32 8
  %t30 = load i1, ptr %t29, !tbaa !21
  %t31 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t35 = call %"compiler/fetch:Fetcher" @compiler_2ffetch_3aFetcher_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t31, { i64, ptr } %t32, { i64, ptr } %t26, i1 %t30, i1 false)
  store %"compiler/fetch:Fetcher" %t35, ptr %l16
  br label %bb4
bb4:
  %t36 = load %"compiler/fetch:Fetcher", ptr %l16
  %t37 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 88, i64 8)
  store %"compiler/fetch:Fetcher" %t36, ptr %t37
  store ptr %t37, ptr %l4, !tbaa !29
  %t39 = call %"compiler/source:Names" @compiler_2fsource_3aNames_2ector(ptr %v2)
  store %"compiler/source:Names" %t39, ptr %l18
  br label %bb5
bb5:
  %t40 = load %"compiler/source:Names", ptr %l18
  %t41 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store %"compiler/source:Names" %t40, ptr %t41
  store ptr %t41, ptr %l5, !tbaa !29
  %t43 = call { i64, ptr } @compiler_2fload_2eStdDir(ptr %v2)
  store { i64, ptr } %t43, ptr %l20
  br label %bb6
bb6:
  %t44 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t44, 0
  %t46 = extractvalue { i64, ptr } %t44, 1
  %t47 = mul i64 %t45, 1
  %t48 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t47)
  call void @llvm.memcpy.p0.p0.i64(ptr %t48, ptr %t46, i64 %t47, i1 false)
  %t49 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  %t51 = load ptr, ptr %l2, !tbaa !29
  %t53 = getelementptr %"compiler/build:Config", ptr %t51, i32 0, i32 3
  %t54 = load ptr, ptr %l4, !tbaa !29
  %t55 = load ptr, ptr %l5, !tbaa !29
  %t56 = load ptr, ptr %l3, !tbaa !29
  %t62 = call %"compiler/load:Loader" @compiler_2fload_3aLoader_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t50, ptr %t53, ptr %t54, ptr %t55, ptr %t56)
  store %"compiler/load:Loader" %t62, ptr %l27
  br label %bb7
bb7:
  %t63 = load %"compiler/load:Loader", ptr %l27
  %t64 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 112, i64 8)
  store %"compiler/load:Loader" %t63, ptr %t64
  store ptr %t64, ptr %l6, !tbaa !29
  %t66 = load ptr, ptr %l6, !tbaa !29
  %t67 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t70 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eLoad(ptr %v2, ptr %v1, ptr %t66, { i64, ptr } %t67)
  store i64 %t70, ptr %l31
  br label %bb8
bb8:
  store ptr %a0, ptr %l32, !tbaa !29
  %t72 = load ptr, ptr %l6, !tbaa !29
  %t74 = getelementptr %"compiler/load:Loader", ptr %t72, i32 0, i32 5
  %t76 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v2, ptr %t74)
  store i64 %t76, ptr %l35
  br label %bb9
bb9:
  %t77 = load i64, ptr %l35, !tbaa !24
  %t78 = load ptr, ptr %l32, !tbaa !29
  %t79 = getelementptr %"compiler/olang:Passes", ptr %t78, i32 0, i32 0
  store i64 %t77, ptr %t79, !tbaa !24
  %t80 = load ptr, ptr %l3, !tbaa !29
  %t82 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v2, ptr %t80)
  store i64 %t82, ptr %l37
  br label %bb10
bb10:
  %t83 = load i64, ptr %l37, !tbaa !24
  %t84 = icmp sgt i64 %t83, 0
  br i1 %t84, label %bb11, label %bb12
bb11:
  %t87 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t87, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t88 = load ptr, ptr %l6, !tbaa !29
  %t90 = insertvalue { i32, ptr } zeroinitializer, ptr %t88, 1
  store { i32, ptr } %t90, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i32 @compiler_2folang_2edrive(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"compiler/olang:Passes"
  %l2 = alloca %"compiler/olang:Passes"
  %l5 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"compiler/olang:Passes" @compiler_2folang_3aPasses_2ector(ptr %s0)
  store %"compiler/olang:Passes" %t1, ptr %l2
  br label %bb1
bb1:
  %t2 = load %"compiler/olang:Passes", ptr %l2
  store %"compiler/olang:Passes" %t2, ptr %l1
  %t6 = call i32 @compiler_2folang_2eRunWith_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %s0, { i64, ptr } %a0, ptr %l1)
  store i32 %t6, ptr %l5
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t7 = load i32, ptr %l5, !tbaa !23
  store i32 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local ptr @compiler_2folang_2eemitter(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, ptr %a3, i32 %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l6 = alloca i1
  %l7 = alloca ptr
  %l17 = alloca %"compiler/emit:Emitter"
  %l24 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l52 = alloca i1
  %l59 = alloca i1
  %rv = alloca ptr
  %t18 = alloca %"compiler/emit:Emitter", align 8
  store ptr %a0, ptr %l0
  store ptr %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l4
  %t3 = trunc i64 2 to i32
  %t4 = icmp eq i32 %t1, %t3
  store i1 %t4, ptr %l6, !tbaa !21
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  call void @compiler_2femit_3aEmitter_2ector(ptr %t18, ptr %v0, ptr %v1, ptr %v2, ptr %v0, ptr %v3, ptr %t9, ptr %a1, ptr %a2, ptr %t17)
  call void @llvm.memmove.p0.p0.i64(ptr %l17, ptr %t18, i64 544, i1 false)
  br label %bb1
bb1:
  %t23 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 544, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t23, ptr %l17, i64 544, i1 false)
  store ptr %t23, ptr %l7, !tbaa !29
  %t25 = load ptr, ptr %l7, !tbaa !29
  %t26 = load i1, ptr %l6, !tbaa !21
  %t29 = getelementptr %"compiler/emit:Emitter", ptr %t25, i32 0, i32 4
  store i1 %t26, ptr %t29, !tbaa !21
  %t30 = load ptr, ptr %l7, !tbaa !29
  %t33 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a5
  %t36 = getelementptr %"compiler/emit:Emitter", ptr %t30, i32 0, i32 43
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t33, ptr %t36
  %t37 = load ptr, ptr %l7, !tbaa !29
  store ptr %t37, ptr %l24, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t40 = getelementptr %"compiler/build:Config", ptr %t38, i32 0, i32 6
  %t41 = load i1, ptr %t40, !tbaa !21
  br i1 %t41, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 16, ptr @.d137 }, ptr %l27, !tbaa !27
  br label %bb4
bb3:
  store { i64, ptr } { i64 0, ptr @.d138 }, ptr %l27, !tbaa !27
  br label %bb4
bb4:
  %t43 = load ptr, ptr %l3, !tbaa !29
  %t45 = getelementptr %"compiler/build:Config", ptr %t43, i32 0, i32 2
  %t46 = getelementptr %"compiler/target:Target", ptr %t45, i32 0, i32 5
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t48, 1
  %t50 = extractvalue { i64, ptr } %t48, 0
  %t52 = extractvalue { i64, ptr } %t47, 1
  %t53 = extractvalue { i64, ptr } %t47, 0
  %t54 = add i64 %t50, %t53
  %t55 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t54)
  call void @olang_textcopy(ptr %t55, ptr %t49, i64 %t50)
  %t56 = getelementptr i8, ptr %t55, i64 %t50
  call void @olang_textcopy(ptr %t56, ptr %t52, i64 %t53)
  %t57 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t55, 1
  %t60 = extractvalue { i64, ptr } %t58, 0
  %t61 = extractvalue { i64, ptr } %t58, 1
  %t62 = mul i64 %t60, 1
  %t63 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t62)
  call void @llvm.memcpy.p0.p0.i64(ptr %t63, ptr %t61, i64 %t62, i1 false)
  %t64 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t63, 1
  %t67 = load ptr, ptr %l24, !tbaa !29
  %t68 = getelementptr %"compiler/emit:Emitter", ptr %t67, i32 0, i32 7
  store { i64, ptr } %t65, ptr %t68, !tbaa !27
  %t69 = load ptr, ptr %l7, !tbaa !29
  %t70 = load i32, ptr %l4
  %t72 = trunc i64 0 to i32
  %t73 = icmp eq i32 %t70, %t72
  %t76 = getelementptr %"compiler/emit:Emitter", ptr %t69, i32 0, i32 37
  store i1 %t73, ptr %t76, !tbaa !21
  %t77 = load ptr, ptr %l7, !tbaa !29
  %t78 = load ptr, ptr %l3, !tbaa !29
  %t80 = getelementptr %"compiler/build:Config", ptr %t78, i32 0, i32 2
  %t81 = getelementptr %"compiler/target:Target", ptr %t80, i32 0, i32 1
  %t82 = load { i64, ptr }, ptr %t81, !tbaa !27
  %t85 = getelementptr %"compiler/emit:Emitter", ptr %t77, i32 0, i32 20
  store { i64, ptr } %t82, ptr %t85, !tbaa !27
  %t86 = load ptr, ptr %l7, !tbaa !29
  %t87 = load ptr, ptr %l3, !tbaa !29
  %t89 = getelementptr %"compiler/build:Config", ptr %t87, i32 0, i32 2
  %t90 = getelementptr %"compiler/target:Target", ptr %t89, i32 0, i32 2
  %t91 = load { i64, ptr }, ptr %t90, !tbaa !27
  %t94 = getelementptr %"compiler/emit:Emitter", ptr %t86, i32 0, i32 44
  store { i64, ptr } %t91, ptr %t94, !tbaa !27
  %t95 = load ptr, ptr %l7, !tbaa !29
  %t96 = load ptr, ptr %l3, !tbaa !29
  %t98 = getelementptr %"compiler/build:Config", ptr %t96, i32 0, i32 7
  %t99 = load i1, ptr %t98, !tbaa !21
  %t102 = getelementptr %"compiler/emit:Emitter", ptr %t95, i32 0, i32 45
  store i1 %t99, ptr %t102, !tbaa !21
  %t103 = load ptr, ptr %l7, !tbaa !29
  %t104 = load ptr, ptr %l3, !tbaa !29
  %t106 = getelementptr %"compiler/build:Config", ptr %t104, i32 0, i32 4
  %t107 = load i1, ptr %t106, !tbaa !21
  %t110 = getelementptr %"compiler/emit:Emitter", ptr %t103, i32 0, i32 5
  store i1 %t107, ptr %t110, !tbaa !21
  %t111 = load ptr, ptr %l7, !tbaa !29
  %t112 = load i1, ptr %l6, !tbaa !21
  %t115 = getelementptr %"compiler/emit:Emitter", ptr %t111, i32 0, i32 6
  store i1 %t112, ptr %t115, !tbaa !21
  %t116 = load ptr, ptr %l7, !tbaa !29
  store ptr %t116, ptr %l49, !tbaa !29
  %t117 = load ptr, ptr %l3, !tbaa !29
  %t119 = getelementptr %"compiler/build:Config", ptr %t117, i32 0, i32 4
  %t120 = load i1, ptr %t119, !tbaa !21
  br i1 %t120, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l52, !tbaa !21
  br label %bb7
bb6:
  %t122 = load ptr, ptr %l3, !tbaa !29
  %t124 = getelementptr %"compiler/build:Config", ptr %t122, i32 0, i32 6
  %t125 = load i1, ptr %t124, !tbaa !21
  store i1 %t125, ptr %l52, !tbaa !21
  br label %bb7
bb7:
  %t127 = load i1, ptr %l52, !tbaa !21
  %t128 = load ptr, ptr %l49, !tbaa !29
  %t129 = getelementptr %"compiler/emit:Emitter", ptr %t128, i32 0, i32 46
  store i1 %t127, ptr %t129, !tbaa !21
  %t130 = load ptr, ptr %l7, !tbaa !29
  %t131 = load i64, ptr @G_2ecompiler_2fbuild_2eThinFrom, !tbaa !24
  %t134 = getelementptr %"compiler/emit:Emitter", ptr %t130, i32 0, i32 38
  store i64 %t131, ptr %t134, !tbaa !24
  %t135 = load ptr, ptr %l3, !tbaa !29
  %t137 = getelementptr %"compiler/build:Config", ptr %t135, i32 0, i32 5
  %t138 = load i1, ptr %t137, !tbaa !21
  br i1 %t138, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l59, !tbaa !21
  br label %bb10
bb9:
  %t140 = load ptr, ptr %l3, !tbaa !29
  %t142 = getelementptr %"compiler/build:Config", ptr %t140, i32 0, i32 4
  %t143 = load i1, ptr %t142, !tbaa !21
  store i1 %t143, ptr %l59, !tbaa !21
  br label %bb10
bb10:
  %t145 = load i1, ptr %l59, !tbaa !21
  br i1 %t145, label %bb11, label %bb12
bb11:
  %t146 = load ptr, ptr %l7, !tbaa !29
  %t147 = load i64, ptr @G_2ecompiler_2femit_2ePartSizeDev, !tbaa !24
  %t150 = getelementptr %"compiler/emit:Emitter", ptr %t146, i32 0, i32 39
  store i64 %t147, ptr %t150, !tbaa !24
  br label %bb13
bb12:
  br label %bb13
bb13:
  %t151 = load ptr, ptr %l7, !tbaa !29
  %t152 = load i32, ptr %l4
  %t154 = trunc i64 0 to i32
  %t155 = icmp eq i32 %t152, %t154
  %t157 = xor i1 %t155, true
  %t160 = getelementptr %"compiler/emit:Emitter", ptr %t151, i32 0, i32 64
  store i1 %t157, ptr %t160, !tbaa !21
  %t161 = load ptr, ptr %l7, !tbaa !29
  store ptr %t161, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2folang_2eendsWithOlang(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l4 = alloca i1
  %l6 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp sgt i64 %t3, 6
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t9 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %s0, { i64, ptr } %t7, { i64, ptr } { i64 6, ptr @.d139 })
  store i1 %t9, ptr %l6
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb4
bb3:
  %t10 = load i1, ptr %l6, !tbaa !21
  store i1 %t10, ptr %l4, !tbaa !21
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t11 = load i1, ptr %l4, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2folang_2eexplainRule(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %lp4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca { i64, [3 x i64] }
  %l16 = alloca %"compiler/msgs:Msg"
  %l17 = alloca i64
  %l19 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i32
  %l25 = alloca ptr
  %l26 = alloca { i64, [3 x i64] }
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca i64
  %l45 = alloca %"compiler/msgs:Msg"
  %l46 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  %t28 = alloca { i64, [3 x i64] }, align 8
  %t53 = alloca { i64, [3 x i64] }, align 8
  store { i64, ptr } %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i64, ptr } @compiler_2fdiag_2eSpecPath(ptr %s0)
  store { i64, ptr } %t1, ptr %l5
  br label %bb1
bb1:
  %t2 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t2, ptr %l2, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s0, { i64, ptr } %t3)
  %t6 = extractvalue { i32, { i64, ptr } } %t5, 1
  %t7 = extractvalue { i32, { i64, ptr } } %t5, 0
  store i32 %t7, ptr %l9
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb3, label %ok.9
ok.9:
  store { i64, ptr } %t6, ptr %l8
  br label %bb2
bb2:
  %t10 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t10, ptr %l6, !tbaa !27
  br label %bb9
bb3:
  %t11 = load i32, ptr %l9, !tbaa !23
  %t12 = ashr i32 %t11, 16
  %t14 = icmp eq i32 %t12, 1
  br i1 %t14, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load i32, ptr %l9, !tbaa !23
  %t17 = lshr i32 %t16, 16
  %t18 = and i32 %t16, 65535
  %t19 = icmp eq i32 %t17, 1
  %t20 = select i1 %t19, i32 0, i32 0
  %t21 = icmp eq i32 %t16, 0
  %t22 = shl i32 %t20, 16
  %t23 = or i32 %t22, %t18
  %t24 = select i1 %t21, i32 0, i32 %t23
  call void @__olang_scope_close(ptr %s0)
  %t26 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t24, 0
  store { i32, { i64, ptr } } %t26, ptr %rv
  br label %ret
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t27 = load ptr, ptr %l1, !tbaa !29
  store ptr %t27, ptr %l13, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t28
  %t29 = getelementptr { i64, [3 x i64] }, ptr %t28, i32 0, i32 0
  store i64 0, ptr %t29
  %t30 = load { i64, [3 x i64] }, ptr %t28
  store { i64, [3 x i64] } %t30, ptr %l14
  %t31 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t33 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoSpec(ptr %s0, ptr %s1, { i64, ptr } %t31)
  store %"compiler/msgs:Msg" %t33, ptr %l16
  br label %bb7
bb7:
  %t34 = load ptr, ptr %l13, !tbaa !29
  %t35 = load { i64, [3 x i64] }, ptr %l14
  %t36 = load %"compiler/msgs:Msg", ptr %l16
  %t37 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v1, ptr %s1, ptr %t34, { i64, [3 x i64] } %t35, %"compiler/msgs:Msg" %t36)
  store i64 %t37, ptr %l17
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t39 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t39, ptr %rv
  br label %ret
bb9:
  %t40 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t43 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t46 = call { i32, { i64, ptr } } @compiler_2fdiag_2eExplain(ptr %s0, ptr %v0, ptr %v2, { i64, ptr } %t40, { i64, ptr } %t43)
  %t47 = extractvalue { i32, { i64, ptr } } %t46, 1
  %t48 = extractvalue { i32, { i64, ptr } } %t46, 0
  store i32 %t48, ptr %l24
  %t49 = icmp ne i32 %t48, 0
  br i1 %t49, label %bb11, label %ok.50
ok.50:
  store { i64, ptr } %t47, ptr %l23
  br label %bb10
bb10:
  %t51 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t51, ptr %l19, !tbaa !27
  br label %bb28
bb11:
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t52 = load ptr, ptr %l1, !tbaa !29
  store ptr %t52, ptr %l25, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t53
  %t54 = getelementptr { i64, [3 x i64] }, ptr %t53, i32 0, i32 0
  store i64 0, ptr %t54
  %t55 = load { i64, [3 x i64] }, ptr %t53
  store { i64, [3 x i64] } %t55, ptr %l26
  %t56 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t56, ptr %l27, !tbaa !27
  %t57 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t57, 0
  store i64 %t58, ptr %l28, !tbaa !24
  %t59 = icmp sge i64 0, 0
  br i1 %t59, label %bb13, label %bb14
bb13:
  %t61 = icmp sle i64 0, 1
  br i1 %t61, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_8c7e755ea0eb9876_6b14028370dd0cea)
  unreachable
bb15:
  %t63 = load i64, ptr %l28, !tbaa !24
  %t64 = icmp sle i64 1, %t63
  br i1 %t64, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_8c7e755ea0eb9876_6b14028370dd0cea)
  unreachable
bb17:
  %t66 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !27
  %t68 = getelementptr i8, ptr %t67, i64 0
  %t69 = sub i64 1, 0
  %t70 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t68, 1
  %t73 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eToUpper(ptr %v0, ptr %s2, { i64, ptr } %t71)
  store { i64, ptr } %t73, ptr %l33
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_8c7e755ea0eb9876_6b14028370dd0cea)
  unreachable
bb19:
  %t74 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t74, ptr %l34, !tbaa !27
  %t75 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t75, 0
  store i64 %t78, ptr %l37, !tbaa !24
  %t79 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t79, 0
  store i64 %t80, ptr %l38, !tbaa !24
  %t81 = icmp sge i64 1, 0
  br i1 %t81, label %bb20, label %bb21
bb20:
  %t83 = load i64, ptr %l37, !tbaa !24
  %t84 = icmp sle i64 1, %t83
  br i1 %t84, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_8c7e755ea0eb9876_6b14028370dd0cea)
  unreachable
bb22:
  %t86 = load i64, ptr %l37, !tbaa !24
  %t87 = load i64, ptr %l38, !tbaa !24
  %t88 = icmp sle i64 %t86, %t87
  br i1 %t88, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_8c7e755ea0eb9876_6b14028370dd0cea)
  unreachable
bb24:
  %t90 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = load i64, ptr %l37, !tbaa !24
  %t93 = getelementptr i8, ptr %t91, i64 1
  %t94 = sub i64 %t92, 1
  %t95 = insertvalue { i64, ptr } undef, i64 %t94, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %t93, 1
  %t97 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t97, 1
  %t99 = extractvalue { i64, ptr } %t97, 0
  %t101 = extractvalue { i64, ptr } %t96, 1
  %t102 = extractvalue { i64, ptr } %t96, 0
  %t103 = add i64 %t99, %t102
  %t104 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t103)
  call void @olang_textcopy(ptr %t104, ptr %t98, i64 %t99)
  %t105 = getelementptr i8, ptr %t104, i64 %t99
  call void @olang_textcopy(ptr %t105, ptr %t101, i64 %t102)
  %t106 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t104, 1
  %t109 = extractvalue { i64, ptr } %t107, 0
  %t110 = extractvalue { i64, ptr } %t107, 1
  %t111 = mul i64 %t109, 1
  %t112 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t111)
  call void @llvm.memcpy.p0.p0.i64(ptr %t112, ptr %t110, i64 %t111, i1 false)
  %t113 = insertvalue { i64, ptr } undef, i64 %t109, 0
  %t114 = insertvalue { i64, ptr } %t113, ptr %t112, 1
  %t116 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoRule(ptr %s2, ptr %s2, { i64, ptr } %t114)
  store %"compiler/msgs:Msg" %t116, ptr %l45
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_8c7e755ea0eb9876_6b14028370dd0cea)
  unreachable
bb26:
  %t117 = load ptr, ptr %l25, !tbaa !29
  %t118 = load { i64, [3 x i64] }, ptr %l26
  %t119 = load %"compiler/msgs:Msg", ptr %l45
  %t120 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v1, ptr %s2, ptr %t117, { i64, [3 x i64] } %t118, %"compiler/msgs:Msg" %t119)
  store i64 %t120, ptr %l46
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t122 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t122, ptr %rv
  br label %ret
bb28:
  %t123 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t123, ptr %lp4
  %t124 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t125 = load ptr, ptr %lp4
  store { i64, ptr } %t124, ptr %t125, !tbaa !27
  %t126 = load ptr, ptr %lp4
  %t127 = load { i64, ptr }, ptr %t126, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t129 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t127, 1
  store { i32, { i64, ptr } } %t129, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local void @compiler_2folang_2eexplainedSrc_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t1 = extractvalue { i64, ptr } { i64 25, ptr @.d140 }, 1
  %t2 = extractvalue { i64, ptr } { i64 25, ptr @.d140 }, 0
  %t3 = extractvalue { i64, ptr } { i64 43, ptr @.d141 }, 1
  %t4 = extractvalue { i64, ptr } { i64 43, ptr @.d141 }, 0
  %t5 = add i64 %t2, %t4
  %t6 = extractvalue { i64, ptr } { i64 37, ptr @.d142 }, 1
  %t7 = extractvalue { i64, ptr } { i64 37, ptr @.d142 }, 0
  %t8 = add i64 %t5, %t7
  %t9 = extractvalue { i64, ptr } { i64 26, ptr @.d143 }, 1
  %t10 = extractvalue { i64, ptr } { i64 26, ptr @.d143 }, 0
  %t11 = add i64 %t8, %t10
  %t12 = extractvalue { i64, ptr } { i64 32, ptr @.d144 }, 1
  %t13 = extractvalue { i64, ptr } { i64 32, ptr @.d144 }, 0
  %t14 = add i64 %t11, %t13
  %t15 = extractvalue { i64, ptr } { i64 37, ptr @.d145 }, 1
  %t16 = extractvalue { i64, ptr } { i64 37, ptr @.d145 }, 0
  %t17 = add i64 %t14, %t16
  %t18 = extractvalue { i64, ptr } { i64 39, ptr @.d146 }, 1
  %t19 = extractvalue { i64, ptr } { i64 39, ptr @.d146 }, 0
  %t20 = add i64 %t17, %t19
  %t21 = extractvalue { i64, ptr } { i64 24, ptr @.d147 }, 1
  %t22 = extractvalue { i64, ptr } { i64 24, ptr @.d147 }, 0
  %t23 = add i64 %t20, %t22
  %t24 = extractvalue { i64, ptr } { i64 2, ptr @.d148 }, 1
  %t25 = extractvalue { i64, ptr } { i64 2, ptr @.d148 }, 0
  %t26 = add i64 %t23, %t25
  %t27 = extractvalue { i64, ptr } { i64 51, ptr @.d149 }, 1
  %t28 = extractvalue { i64, ptr } { i64 51, ptr @.d149 }, 0
  %t29 = add i64 %t26, %t28
  %t30 = extractvalue { i64, ptr } { i64 62, ptr @.d150 }, 1
  %t31 = extractvalue { i64, ptr } { i64 62, ptr @.d150 }, 0
  %t32 = add i64 %t29, %t31
  %t33 = extractvalue { i64, ptr } { i64 19, ptr @.d151 }, 1
  %t34 = extractvalue { i64, ptr } { i64 19, ptr @.d151 }, 0
  %t35 = add i64 %t32, %t34
  %t36 = extractvalue { i64, ptr } { i64 91, ptr @.d152 }, 1
  %t37 = extractvalue { i64, ptr } { i64 91, ptr @.d152 }, 0
  %t38 = add i64 %t35, %t37
  %t39 = extractvalue { i64, ptr } { i64 43, ptr @.d153 }, 1
  %t40 = extractvalue { i64, ptr } { i64 43, ptr @.d153 }, 0
  %t41 = add i64 %t38, %t40
  %t42 = extractvalue { i64, ptr } { i64 14, ptr @.d154 }, 1
  %t43 = extractvalue { i64, ptr } { i64 14, ptr @.d154 }, 0
  %t44 = add i64 %t41, %t43
  %t45 = extractvalue { i64, ptr } { i64 29, ptr @.d155 }, 1
  %t46 = extractvalue { i64, ptr } { i64 29, ptr @.d155 }, 0
  %t47 = add i64 %t44, %t46
  %t48 = extractvalue { i64, ptr } { i64 17, ptr @.d156 }, 1
  %t49 = extractvalue { i64, ptr } { i64 17, ptr @.d156 }, 0
  %t50 = add i64 %t47, %t49
  %t51 = extractvalue { i64, ptr } { i64 42, ptr @.d157 }, 1
  %t52 = extractvalue { i64, ptr } { i64 42, ptr @.d157 }, 0
  %t53 = add i64 %t50, %t52
  %t54 = extractvalue { i64, ptr } { i64 44, ptr @.d158 }, 1
  %t55 = extractvalue { i64, ptr } { i64 44, ptr @.d158 }, 0
  %t56 = add i64 %t53, %t55
  %t57 = extractvalue { i64, ptr } { i64 2, ptr @.d159 }, 1
  %t58 = extractvalue { i64, ptr } { i64 2, ptr @.d159 }, 0
  %t59 = add i64 %t56, %t58
  %t60 = load ptr, ptr @__olang_prog_scope
  %t61 = call ptr @__olang_scope_alloc(ptr %t60, i64 %t59)
  call void @olang_textcopy(ptr %t61, ptr %t1, i64 %t2)
  %t62 = getelementptr i8, ptr %t61, i64 %t2
  call void @olang_textcopy(ptr %t62, ptr %t3, i64 %t4)
  %t63 = getelementptr i8, ptr %t62, i64 %t4
  call void @olang_textcopy(ptr %t63, ptr %t6, i64 %t7)
  %t64 = getelementptr i8, ptr %t63, i64 %t7
  call void @olang_textcopy(ptr %t64, ptr %t9, i64 %t10)
  %t65 = getelementptr i8, ptr %t64, i64 %t10
  call void @olang_textcopy(ptr %t65, ptr %t12, i64 %t13)
  %t66 = getelementptr i8, ptr %t65, i64 %t13
  call void @olang_textcopy(ptr %t66, ptr %t15, i64 %t16)
  %t67 = getelementptr i8, ptr %t66, i64 %t16
  call void @olang_textcopy(ptr %t67, ptr %t18, i64 %t19)
  %t68 = getelementptr i8, ptr %t67, i64 %t19
  call void @olang_textcopy(ptr %t68, ptr %t21, i64 %t22)
  %t69 = getelementptr i8, ptr %t68, i64 %t22
  call void @olang_textcopy(ptr %t69, ptr %t24, i64 %t25)
  %t70 = getelementptr i8, ptr %t69, i64 %t25
  call void @olang_textcopy(ptr %t70, ptr %t27, i64 %t28)
  %t71 = getelementptr i8, ptr %t70, i64 %t28
  call void @olang_textcopy(ptr %t71, ptr %t30, i64 %t31)
  %t72 = getelementptr i8, ptr %t71, i64 %t31
  call void @olang_textcopy(ptr %t72, ptr %t33, i64 %t34)
  %t73 = getelementptr i8, ptr %t72, i64 %t34
  call void @olang_textcopy(ptr %t73, ptr %t36, i64 %t37)
  %t74 = getelementptr i8, ptr %t73, i64 %t37
  call void @olang_textcopy(ptr %t74, ptr %t39, i64 %t40)
  %t75 = getelementptr i8, ptr %t74, i64 %t40
  call void @olang_textcopy(ptr %t75, ptr %t42, i64 %t43)
  %t76 = getelementptr i8, ptr %t75, i64 %t43
  call void @olang_textcopy(ptr %t76, ptr %t45, i64 %t46)
  %t77 = getelementptr i8, ptr %t76, i64 %t46
  call void @olang_textcopy(ptr %t77, ptr %t48, i64 %t49)
  %t78 = getelementptr i8, ptr %t77, i64 %t49
  call void @olang_textcopy(ptr %t78, ptr %t51, i64 %t52)
  %t79 = getelementptr i8, ptr %t78, i64 %t52
  call void @olang_textcopy(ptr %t79, ptr %t54, i64 %t55)
  %t80 = getelementptr i8, ptr %t79, i64 %t55
  call void @olang_textcopy(ptr %t80, ptr %t57, i64 %t58)
  %t81 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t61, 1
  %t84 = load ptr, ptr @__olang_prog_scope
  %t85 = extractvalue { i64, ptr } %t82, 0
  %t86 = extractvalue { i64, ptr } %t82, 1
  %t87 = mul i64 %t85, 1
  %t88 = call ptr @__olang_scope_alloc(ptr %t84, i64 %t87)
  call void @llvm.memcpy.p0.p0.i64(ptr %t88, ptr %t86, i64 %t87, i1 false)
  %t89 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  store { i64, ptr } %t90, ptr @G_2ecompiler_2folang_2eexplainedSrc, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2folang_2eformat(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l9 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/olang:CommandLine", ptr %t1, i32 0, i32 8
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 2, ptr @.d160 }, ptr %l3, !tbaa !27
  br label %bb3
bb2:
  store { i64, ptr } { i64 2, ptr @.d161 }, ptr %l3, !tbaa !27
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/olang:CommandLine", ptr %t6, i32 0, i32 1
  %t10 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hd4bdf3befe2f7a35847f168802c5df68(ptr %v0, ptr %v0, ptr %t8)
  store { i64, ptr } %t10, ptr %l6
  br label %bb4
bb4:
  %t11 = call { i64, ptr } @compiler_2fload_2eStdDir(ptr %s0)
  store { i64, ptr } %t11, ptr %l7
  br label %bb5
bb5:
  %t12 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 0
  %t14 = extractvalue { i64, ptr } %t12, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t19 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t20 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t22 = call i32 @compiler_2ffmt_2eFiles(ptr %s0, ptr %v0, ptr %s0, { i64, ptr } %t19, { i64, ptr } %t20, { i64, ptr } %t18)
  store i32 %t22, ptr %l9
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load i32, ptr %l9, !tbaa !23
  store i32 %t23, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2folang_2ehelp(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i1
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca %"std/prelude/text:StringBuilder"
  %l23 = alloca ptr
  %l24 = alloca { i64, ptr }
  %l29 = alloca [12 x { i64, ptr }]
  %l34 = alloca i64
  %l37 = alloca i64
  %l55 = alloca ptr
  %l58 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l69 = alloca i64
  %l70 = alloca { i64, ptr }
  %l73 = alloca i1
  %l74 = alloca i64
  %l78 = alloca i64
  %l81 = alloca ptr
  %l84 = alloca %"compiler/msgs:Msg"
  %l85 = alloca i32
  %l94 = alloca [10 x { i64, ptr }]
  %l99 = alloca i64
  %l102 = alloca i64
  %l122 = alloca i64
  %l130 = alloca { i64, ptr }
  %l133 = alloca i1
  %l135 = alloca { i64, ptr }
  %l139 = alloca ptr
  %l141 = alloca { i64, ptr }
  %l149 = alloca { i64, ptr }
  %l150 = alloca { i64, ptr }
  %l151 = alloca i64
  %l152 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l18
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l18
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/olang:CommandLine", ptr %t3, i32 0, i32 3
  %t6 = load i1, ptr %t5, !tbaa !21
  %t8 = xor i1 %t6, true
  br i1 %t8, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s1, ptr %l2, { i64, ptr } { i64 96, ptr @.d162 })
  br label %bb4
bb3:
  br label %bb23
bb4:
  store ptr %l2, ptr %l23, !tbaa !29
  %t11 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadEnd(ptr %s1, ptr %s1, { i64, ptr } { i64 10, ptr @.d163 }, i64 11, i8 32)
  store { i64, ptr } %t11, ptr %l24
  br label %bb5
bb5:
  %t12 = load i64, ptr @G_2ecompiler_2folang_2eRun, !tbaa !24
  %t14 = getelementptr [12 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eModeWhat, i64 0, i64 %t12
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !37
  %t16 = extractvalue { i64, ptr } { i64 2, ptr @.d164 }, 1
  %t17 = extractvalue { i64, ptr } { i64 2, ptr @.d164 }, 0
  %t18 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t18, 1
  %t20 = extractvalue { i64, ptr } %t18, 0
  %t21 = add i64 %t17, %t20
  %t22 = extractvalue { i64, ptr } { i64 1, ptr @.d165 }, 1
  %t23 = extractvalue { i64, ptr } { i64 1, ptr @.d165 }, 0
  %t24 = add i64 %t21, %t23
  %t26 = extractvalue { i64, ptr } %t15, 1
  %t27 = extractvalue { i64, ptr } %t15, 0
  %t28 = add i64 %t24, %t27
  %t29 = extractvalue { i64, ptr } { i64 1, ptr @.d166 }, 1
  %t30 = extractvalue { i64, ptr } { i64 1, ptr @.d166 }, 0
  %t31 = add i64 %t28, %t30
  %t32 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t31)
  call void @olang_textcopy(ptr %t32, ptr %t16, i64 %t17)
  %t33 = getelementptr i8, ptr %t32, i64 %t17
  call void @olang_textcopy(ptr %t33, ptr %t19, i64 %t20)
  %t34 = getelementptr i8, ptr %t33, i64 %t20
  call void @olang_textcopy(ptr %t34, ptr %t22, i64 %t23)
  %t35 = getelementptr i8, ptr %t34, i64 %t23
  call void @olang_textcopy(ptr %t35, ptr %t26, i64 %t27)
  %t36 = getelementptr i8, ptr %t35, i64 %t27
  call void @olang_textcopy(ptr %t36, ptr %t29, i64 %t30)
  %t37 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t32, 1
  %t40 = extractvalue { i64, ptr } %t38, 0
  %t41 = extractvalue { i64, ptr } %t38, 1
  %t42 = mul i64 %t40, 1
  %t43 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t42)
  call void @llvm.memcpy.p0.p0.i64(ptr %t43, ptr %t41, i64 %t42, i1 false)
  %t44 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  %t46 = load ptr, ptr %l23, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s1, ptr %t46, { i64, ptr } %t45)
  br label %bb6
bb6:
  store i64 1, ptr %l3, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l29, ptr @G_2ecompiler_2folang_2eModeWords, i64 192, i1 false)
  %t48 = load [12 x { i64, ptr }], ptr %l29
  store i64 12, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t50 = load i64, ptr %l4, !tbaa !24
  %t51 = load i64, ptr %l3, !tbaa !24
  %t54 = icmp sgt i64 %t50, %t51
  br i1 %t54, label %bb7, label %bb8
bb7:
  %t56 = load i64, ptr %l5, !tbaa !24
  %t58 = icmp sgt i64 %t56, 0
  br i1 %t58, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb12
bb9:
  %t60 = load i64, ptr %l4, !tbaa !24
  %t61 = load i64, ptr %l3, !tbaa !24
  %t64 = sub i64 %t60, %t61
  %t65 = load i64, ptr %l5, !tbaa !24
  %t68 = add i64 %t64, %t65
  %t70 = sub i64 %t68, 1
  %t71 = load i64, ptr %l5, !tbaa !24
  %t74 = sdiv i64 %t70, %t71
  store i64 %t74, ptr %l37, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb11
bb11:
  %t76 = load i64, ptr %l37, !tbaa !24
  store i64 %t76, ptr %l34, !tbaa !24
  br label %bb12
bb12:
  %t77 = load i64, ptr %l34, !tbaa !24
  store i64 %t77, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s4
  %t78 = load i64, ptr %l7, !tbaa !24
  %t79 = load i64, ptr %l6, !tbaa !24
  %t82 = icmp slt i64 %t78, %t79
  %t84 = xor i1 %t82, true
  br i1 %t84, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s4)
  br label %bb20
bb15:
  br label %bb16
bb16:
  %t86 = load i64, ptr %l3, !tbaa !24
  %t87 = load i64, ptr %l7, !tbaa !24
  %t88 = load i64, ptr %l5, !tbaa !24
  %t91 = mul i64 %t87, %t88
  %t94 = add i64 %t86, %t91
  store i64 %t94, ptr %l8, !tbaa !24
  store ptr %l2, ptr %l55, !tbaa !29
  %t96 = load i64, ptr %l8, !tbaa !24
  %t98 = getelementptr [12 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eModeWords, i64 0, i64 %t96
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !37
  %t100 = load ptr, ptr @__olang_prog_scope
  %t102 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadEnd(ptr %t100, ptr %s4, { i64, ptr } %t99, i64 11, i8 32)
  store { i64, ptr } %t102, ptr %l58
  br label %bb17
bb17:
  %t103 = load i64, ptr %l8, !tbaa !24
  %t105 = getelementptr [12 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eModeWhat, i64 0, i64 %t103
  %t106 = load { i64, ptr }, ptr %t105, !tbaa !37
  %t107 = extractvalue { i64, ptr } { i64 2, ptr @.d167 }, 1
  %t108 = extractvalue { i64, ptr } { i64 2, ptr @.d167 }, 0
  %t109 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t109, 1
  %t111 = extractvalue { i64, ptr } %t109, 0
  %t112 = add i64 %t108, %t111
  %t113 = extractvalue { i64, ptr } { i64 1, ptr @.d168 }, 1
  %t114 = extractvalue { i64, ptr } { i64 1, ptr @.d168 }, 0
  %t115 = add i64 %t112, %t114
  %t117 = extractvalue { i64, ptr } %t106, 1
  %t118 = extractvalue { i64, ptr } %t106, 0
  %t119 = add i64 %t115, %t118
  %t120 = extractvalue { i64, ptr } { i64 1, ptr @.d169 }, 1
  %t121 = extractvalue { i64, ptr } { i64 1, ptr @.d169 }, 0
  %t122 = add i64 %t119, %t121
  %t123 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t122)
  call void @olang_textcopy(ptr %t123, ptr %t107, i64 %t108)
  %t124 = getelementptr i8, ptr %t123, i64 %t108
  call void @olang_textcopy(ptr %t124, ptr %t110, i64 %t111)
  %t125 = getelementptr i8, ptr %t124, i64 %t111
  call void @olang_textcopy(ptr %t125, ptr %t113, i64 %t114)
  %t126 = getelementptr i8, ptr %t125, i64 %t114
  call void @olang_textcopy(ptr %t126, ptr %t117, i64 %t118)
  %t127 = getelementptr i8, ptr %t126, i64 %t118
  call void @olang_textcopy(ptr %t127, ptr %t120, i64 %t121)
  %t128 = insertvalue { i64, ptr } undef, i64 %t122, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t123, 1
  %t131 = extractvalue { i64, ptr } %t129, 0
  %t132 = extractvalue { i64, ptr } %t129, 1
  %t133 = mul i64 %t131, 1
  %t134 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t133)
  call void @llvm.memcpy.p0.p0.i64(ptr %t134, ptr %t132, i64 %t133, i1 false)
  %t135 = insertvalue { i64, ptr } undef, i64 %t131, 0
  %t136 = insertvalue { i64, ptr } %t135, ptr %t134, 1
  %t137 = load ptr, ptr %l55, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %t137, { i64, ptr } %t136)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s4)
  br label %bb19
bb19:
  %t139 = load i64, ptr %l7, !tbaa !24
  %t141 = add i64 %t139, 1
  store i64 %t141, ptr %l7, !tbaa !24
  br label %bb13
bb20:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s1, ptr %l2, { i64, ptr } { i64 85, ptr @.d170 })
  br label %bb21
bb21:
  %t145 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l2)
  store { i64, ptr } %t145, ptr %l67
  br label %bb22
bb22:
  %t146 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t146, ptr %l68, !tbaa !27
  %t147 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t148 = extractvalue { i64, ptr } %t147, 0
  store i64 %t148, ptr %l69, !tbaa !24
  %t149 = load i64, ptr %l69, !tbaa !24
  %t150 = mul i64 %t149, 1
  %t151 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t150)
  %t152 = insertvalue { i64, ptr } undef, i64 %t149, 0
  %t153 = insertvalue { i64, ptr } %t152, ptr %t151, 1
  store { i64, ptr } %t153, ptr %l70, !tbaa !27
  %t154 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !27
  %t156 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !27
  %t158 = load i64, ptr %l69, !tbaa !24
  %t159 = mul i64 %t158, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t155, ptr %t157, i64 %t159, i1 false)
  %t160 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t160, ptr %l68, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t161 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t162 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t161, 1
  store { i32, { i64, ptr } } %t162, ptr %rv
  br label %ret
bb23:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t165 = getelementptr %"compiler/olang:CommandLine", ptr %t163, i32 0, i32 2
  %t166 = load { i64, ptr }, ptr %t165, !tbaa !27
  %t168 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t166, { i64, ptr } { i64 3, ptr @.d171 })
  store i1 %t168, ptr %l73
  br label %bb24
bb24:
  %t169 = load i1, ptr %l73, !tbaa !21
  br i1 %t169, label %bb25, label %bb26
bb25:
  %t170 = load i64, ptr @G_2ecompiler_2folang_2eRun, !tbaa !24
  store i64 %t170, ptr %l74, !tbaa !24
  br label %bb28
bb26:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t174 = getelementptr %"compiler/olang:CommandLine", ptr %t172, i32 0, i32 2
  %t175 = load { i64, ptr }, ptr %t174, !tbaa !27
  %t177 = call i64 @compiler_2folang_2emodeNumber(ptr %v0, { i64, ptr } %t175)
  store i64 %t177, ptr %l78
  br label %bb27
bb27:
  %t178 = load i64, ptr %l78, !tbaa !24
  store i64 %t178, ptr %l74, !tbaa !24
  br label %bb28
bb28:
  %t179 = load i64, ptr %l74, !tbaa !24
  store i64 %t179, ptr %l9, !tbaa !24
  %t180 = load i64, ptr %l9, !tbaa !24
  %t182 = icmp slt i64 %t180, 0
  br i1 %t182, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s7
  store ptr %a1, ptr %l81, !tbaa !29
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/olang:CommandLine", ptr %t185, i32 0, i32 2
  %t188 = load { i64, ptr }, ptr %t187, !tbaa !27
  %t190 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotAMode(ptr %v0, ptr %s7, { i64, ptr } %t188)
  store %"compiler/msgs:Msg" %t190, ptr %l84
  br label %bb31
bb30:
  br label %bb35
bb31:
  %t191 = load ptr, ptr %l81, !tbaa !29
  %t192 = load %"compiler/msgs:Msg", ptr %l84
  %t193 = call i32 @compiler_2folang_2eusage(ptr %v1, ptr %s7, ptr %t191, %"compiler/msgs:Msg" %t192)
  store i32 %t193, ptr %l85
  %t194 = icmp ne i32 %t193, 0
  br i1 %t194, label %bb33, label %ok.195
ok.195:
  br label %bb32
bb32:
  br label %bb34
bb33:
  %t196 = load i32, ptr %l85, !tbaa !23
  %t197 = lshr i32 %t196, 16
  %t198 = and i32 %t196, 65535
  %t199 = icmp eq i32 %t197, 1
  %t200 = select i1 %t199, i32 1, i32 0
  %t201 = icmp eq i32 %t196, 0
  %t202 = shl i32 %t200, 16
  %t203 = or i32 %t202, %t198
  %t204 = select i1 %t201, i32 0, i32 %t203
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  %t206 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t204, 0
  store { i32, { i64, ptr } } %t206, ptr %rv
  br label %ret
bb34:
  call void @__olang_scope_close(ptr %s7)
  br label %bb35
bb35:
  %t207 = load i64, ptr %l9, !tbaa !24
  %t209 = getelementptr [12 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eModeUsage, i64 0, i64 %t207
  %t210 = load { i64, ptr }, ptr %t209, !tbaa !37
  %t211 = load i64, ptr %l9, !tbaa !24
  %t213 = getelementptr [12 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eModeWhat, i64 0, i64 %t211
  %t214 = load { i64, ptr }, ptr %t213, !tbaa !37
  %t215 = extractvalue { i64, ptr } { i64 7, ptr @.d172 }, 1
  %t216 = extractvalue { i64, ptr } { i64 7, ptr @.d172 }, 0
  %t218 = extractvalue { i64, ptr } %t210, 1
  %t219 = extractvalue { i64, ptr } %t210, 0
  %t220 = add i64 %t216, %t219
  %t221 = extractvalue { i64, ptr } { i64 1, ptr @.d173 }, 1
  %t222 = extractvalue { i64, ptr } { i64 1, ptr @.d173 }, 0
  %t223 = add i64 %t220, %t222
  %t225 = extractvalue { i64, ptr } %t214, 1
  %t226 = extractvalue { i64, ptr } %t214, 0
  %t227 = add i64 %t223, %t226
  %t228 = extractvalue { i64, ptr } { i64 1, ptr @.d174 }, 1
  %t229 = extractvalue { i64, ptr } { i64 1, ptr @.d174 }, 0
  %t230 = add i64 %t227, %t229
  %t231 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t230)
  call void @olang_textcopy(ptr %t231, ptr %t215, i64 %t216)
  %t232 = getelementptr i8, ptr %t231, i64 %t216
  call void @olang_textcopy(ptr %t232, ptr %t218, i64 %t219)
  %t233 = getelementptr i8, ptr %t232, i64 %t219
  call void @olang_textcopy(ptr %t233, ptr %t221, i64 %t222)
  %t234 = getelementptr i8, ptr %t233, i64 %t222
  call void @olang_textcopy(ptr %t234, ptr %t225, i64 %t226)
  %t235 = getelementptr i8, ptr %t234, i64 %t226
  call void @olang_textcopy(ptr %t235, ptr %t228, i64 %t229)
  %t236 = insertvalue { i64, ptr } undef, i64 %t230, 0
  %t237 = insertvalue { i64, ptr } %t236, ptr %t231, 1
  %t239 = extractvalue { i64, ptr } %t237, 0
  %t240 = extractvalue { i64, ptr } %t237, 1
  %t241 = mul i64 %t239, 1
  %t242 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t241)
  call void @llvm.memcpy.p0.p0.i64(ptr %t242, ptr %t240, i64 %t241, i1 false)
  %t243 = insertvalue { i64, ptr } undef, i64 %t239, 0
  %t244 = insertvalue { i64, ptr } %t243, ptr %t242, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } %t244)
  br label %bb36
bb36:
  store i1 false, ptr %l10, !tbaa !21
  store i64 0, ptr %l11, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l94, ptr @G_2ecompiler_2folang_2eOptWords, i64 160, i1 false)
  %t247 = load [10 x { i64, ptr }], ptr %l94
  store i64 10, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t249 = load i64, ptr %l12, !tbaa !24
  %t250 = load i64, ptr %l11, !tbaa !24
  %t253 = icmp sgt i64 %t249, %t250
  br i1 %t253, label %bb37, label %bb38
bb37:
  %t255 = load i64, ptr %l13, !tbaa !24
  %t257 = icmp sgt i64 %t255, 0
  br i1 %t257, label %bb39, label %bb40
bb38:
  store i64 0, ptr %l99, !tbaa !24
  br label %bb42
bb39:
  %t259 = load i64, ptr %l12, !tbaa !24
  %t260 = load i64, ptr %l11, !tbaa !24
  %t263 = sub i64 %t259, %t260
  %t264 = load i64, ptr %l13, !tbaa !24
  %t267 = add i64 %t263, %t264
  %t269 = sub i64 %t267, 1
  %t270 = load i64, ptr %l13, !tbaa !24
  %t273 = sdiv i64 %t269, %t270
  store i64 %t273, ptr %l102, !tbaa !24
  br label %bb41
bb40:
  store i64 0, ptr %l102, !tbaa !24
  br label %bb41
bb41:
  %t275 = load i64, ptr %l102, !tbaa !24
  store i64 %t275, ptr %l99, !tbaa !24
  br label %bb42
bb42:
  %t276 = load i64, ptr %l99, !tbaa !24
  store i64 %t276, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb43
bb43:
  store %olang.scope zeroinitializer, ptr %s10
  %t277 = load i64, ptr %l15, !tbaa !24
  %t278 = load i64, ptr %l14, !tbaa !24
  %t281 = icmp slt i64 %t277, %t278
  %t283 = xor i1 %t281, true
  br i1 %t283, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s10)
  br label %bb61
bb45:
  br label %bb46
bb46:
  %t285 = load i64, ptr %l11, !tbaa !24
  %t286 = load i64, ptr %l15, !tbaa !24
  %t287 = load i64, ptr %l13, !tbaa !24
  %t290 = mul i64 %t286, %t287
  %t293 = add i64 %t285, %t290
  store i64 %t293, ptr %l16, !tbaa !24
  %t295 = load i64, ptr %l16, !tbaa !24
  %t297 = getelementptr [10 x i64], ptr @G_2ecompiler_2folang_2eOptModes, i64 0, i64 %t295
  %t298 = load i64, ptr %t297, !tbaa !34
  %t299 = load i64, ptr %l9, !tbaa !24
  store i64 %t299, ptr %l122, !tbaa !24
  %t301 = load i64, ptr %l122, !tbaa !24
  %t302 = load i64, ptr %l122, !tbaa !24
  %t303 = ashr i64 %t298, %t302
  %t305 = and i64 %t303, 1
  %t307 = icmp eq i64 %t305, 0
  br i1 %t307, label %bb47, label %bb48
bb47:
  call void @__olang_scope_close(ptr %s10)
  br label %bb60
bb48:
  br label %bb49
bb49:
  %t309 = load i1, ptr %l10, !tbaa !21
  %t311 = xor i1 %t309, true
  br i1 %t311, label %bb50, label %bb51
bb50:
  store %olang.scope zeroinitializer, ptr %s12
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s12, ptr %l2, { i64, ptr } { i64 10, ptr @.d175 })
  br label %bb52
bb51:
  br label %bb53
bb52:
  call void @__olang_scope_close(ptr %s12)
  br label %bb53
bb53:
  store i1 true, ptr %l10, !tbaa !21
  %t314 = load i64, ptr %l16, !tbaa !24
  %t316 = getelementptr [10 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eOptWords, i64 0, i64 %t314
  %t317 = load { i64, ptr }, ptr %t316, !tbaa !37
  store { i64, ptr } %t317, ptr %l130, !tbaa !27
  %t318 = load i64, ptr %l16, !tbaa !24
  %t320 = getelementptr [10 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eOptValues, i64 0, i64 %t318
  %t321 = load { i64, ptr }, ptr %t320, !tbaa !37
  %t322 = load ptr, ptr @__olang_prog_scope
  %t324 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t322, ptr %s10, { i64, ptr } %t321, { i64, ptr } { i64 0, ptr @.d176 })
  store i1 %t324, ptr %l133
  br label %bb54
bb54:
  %t325 = load i1, ptr %l133, !tbaa !21
  %t326 = xor i1 %t325, true
  br i1 %t326, label %bb55, label %bb56
bb55:
  store { i64, ptr } { i64 1, ptr @.d177 }, ptr %l135, !tbaa !27
  br label %bb57
bb56:
  store { i64, ptr } { i64 0, ptr @.d178 }, ptr %l135, !tbaa !27
  br label %bb57
bb57:
  %t328 = load i64, ptr %l16, !tbaa !24
  %t330 = getelementptr [10 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eOptValues, i64 0, i64 %t328
  %t331 = load { i64, ptr }, ptr %t330, !tbaa !37
  %t332 = load { i64, ptr }, ptr %l130, !tbaa !27
  %t333 = extractvalue { i64, ptr } %t332, 1
  %t334 = extractvalue { i64, ptr } %t332, 0
  %t335 = load { i64, ptr }, ptr %l135, !tbaa !27
  %t336 = extractvalue { i64, ptr } %t335, 1
  %t337 = extractvalue { i64, ptr } %t335, 0
  %t338 = add i64 %t334, %t337
  %t340 = extractvalue { i64, ptr } %t331, 1
  %t341 = extractvalue { i64, ptr } %t331, 0
  %t342 = add i64 %t338, %t341
  %t343 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t342)
  call void @olang_textcopy(ptr %t343, ptr %t333, i64 %t334)
  %t344 = getelementptr i8, ptr %t343, i64 %t334
  call void @olang_textcopy(ptr %t344, ptr %t336, i64 %t337)
  %t345 = getelementptr i8, ptr %t344, i64 %t337
  call void @olang_textcopy(ptr %t345, ptr %t340, i64 %t341)
  %t346 = insertvalue { i64, ptr } undef, i64 %t342, 0
  %t347 = insertvalue { i64, ptr } %t346, ptr %t343, 1
  store ptr %l2, ptr %l139, !tbaa !29
  %t351 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadEnd(ptr %s10, ptr %s10, { i64, ptr } %t347, i64 18, i8 32)
  store { i64, ptr } %t351, ptr %l141
  br label %bb58
bb58:
  %t352 = load i64, ptr %l16, !tbaa !24
  %t354 = getelementptr [10 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eOptWhat, i64 0, i64 %t352
  %t355 = load { i64, ptr }, ptr %t354, !tbaa !37
  %t356 = extractvalue { i64, ptr } { i64 2, ptr @.d179 }, 1
  %t357 = extractvalue { i64, ptr } { i64 2, ptr @.d179 }, 0
  %t358 = load { i64, ptr }, ptr %l141, !tbaa !27
  %t359 = extractvalue { i64, ptr } %t358, 1
  %t360 = extractvalue { i64, ptr } %t358, 0
  %t361 = add i64 %t357, %t360
  %t362 = extractvalue { i64, ptr } { i64 1, ptr @.d180 }, 1
  %t363 = extractvalue { i64, ptr } { i64 1, ptr @.d180 }, 0
  %t364 = add i64 %t361, %t363
  %t366 = extractvalue { i64, ptr } %t355, 1
  %t367 = extractvalue { i64, ptr } %t355, 0
  %t368 = add i64 %t364, %t367
  %t369 = extractvalue { i64, ptr } { i64 1, ptr @.d181 }, 1
  %t370 = extractvalue { i64, ptr } { i64 1, ptr @.d181 }, 0
  %t371 = add i64 %t368, %t370
  %t372 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t371)
  call void @olang_textcopy(ptr %t372, ptr %t356, i64 %t357)
  %t373 = getelementptr i8, ptr %t372, i64 %t357
  call void @olang_textcopy(ptr %t373, ptr %t359, i64 %t360)
  %t374 = getelementptr i8, ptr %t373, i64 %t360
  call void @olang_textcopy(ptr %t374, ptr %t362, i64 %t363)
  %t375 = getelementptr i8, ptr %t374, i64 %t363
  call void @olang_textcopy(ptr %t375, ptr %t366, i64 %t367)
  %t376 = getelementptr i8, ptr %t375, i64 %t367
  call void @olang_textcopy(ptr %t376, ptr %t369, i64 %t370)
  %t377 = insertvalue { i64, ptr } undef, i64 %t371, 0
  %t378 = insertvalue { i64, ptr } %t377, ptr %t372, 1
  %t380 = extractvalue { i64, ptr } %t378, 0
  %t381 = extractvalue { i64, ptr } %t378, 1
  %t382 = mul i64 %t380, 1
  %t383 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t382)
  call void @llvm.memcpy.p0.p0.i64(ptr %t383, ptr %t381, i64 %t382, i1 false)
  %t384 = insertvalue { i64, ptr } undef, i64 %t380, 0
  %t385 = insertvalue { i64, ptr } %t384, ptr %t383, 1
  %t386 = load ptr, ptr %l139, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s10, ptr %t386, { i64, ptr } %t385)
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s10)
  br label %bb60
bb60:
  %t388 = load i64, ptr %l15, !tbaa !24
  %t390 = add i64 %t388, 1
  store i64 %t390, ptr %l15, !tbaa !24
  br label %bb43
bb61:
  %t393 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l2)
  store { i64, ptr } %t393, ptr %l149
  br label %bb62
bb62:
  %t394 = load { i64, ptr }, ptr %l149, !tbaa !27
  store { i64, ptr } %t394, ptr %l150, !tbaa !27
  %t395 = load { i64, ptr }, ptr %l150, !tbaa !27
  %t396 = extractvalue { i64, ptr } %t395, 0
  store i64 %t396, ptr %l151, !tbaa !24
  %t397 = load i64, ptr %l151, !tbaa !24
  %t398 = mul i64 %t397, 1
  %t399 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t398)
  %t400 = insertvalue { i64, ptr } undef, i64 %t397, 0
  %t401 = insertvalue { i64, ptr } %t400, ptr %t399, 1
  store { i64, ptr } %t401, ptr %l152, !tbaa !27
  %t402 = getelementptr { i64, ptr }, ptr %l152, i32 0, i32 1
  %t403 = load ptr, ptr %t402, !tbaa !27
  %t404 = getelementptr { i64, ptr }, ptr %l150, i32 0, i32 1
  %t405 = load ptr, ptr %t404, !tbaa !27
  %t406 = load i64, ptr %l151, !tbaa !24
  %t407 = mul i64 %t406, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t403, ptr %t405, i64 %t407, i1 false)
  %t408 = load { i64, ptr }, ptr %l152, !tbaa !27
  store { i64, ptr } %t408, ptr %l150, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t409 = load { i64, ptr }, ptr %l150, !tbaa !27
  %t410 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t409, 1
  store { i32, { i64, ptr } } %t410, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local void @compiler_2folang_2ekeep(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, { i64, ptr } %a2, ptr %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca %"compiler/emit:Reused"
  %l13 = alloca { i64, ptr }
  %l14 = alloca %"std/prelude/text:StringBuilder"
  %l15 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca i1
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l30 = alloca i64
  %l36 = alloca i32
  %l39 = alloca i32
  %l41 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l45 = alloca i32
  %l54 = alloca { i64, ptr }
  %l61 = alloca i1
  %l62 = alloca { i64, ptr }
  %l65 = alloca i1
  %l66 = alloca ptr
  %l70 = alloca ptr
  %l73 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l77 = alloca %"std/prelude/text:StringBuilder"
  %l78 = alloca ptr
  %l79 = alloca i64
  %l81 = alloca { i64, ptr }
  %l84 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l86 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l90 = alloca i32
  %l99 = alloca { i64, ptr }
  %l104 = alloca i1
  %l117 = alloca i64
  %l121 = alloca i64
  %l124 = alloca i64
  %l145 = alloca { i64, ptr }
  %l151 = alloca %"compiler/emit:Object"
  %l154 = alloca i1
  %l156 = alloca ptr
  %l159 = alloca i1
  %l160 = alloca { i64, ptr }
  %l165 = alloca { i64, ptr }
  %l168 = alloca { i64, ptr }
  %l176 = alloca { i64, ptr }
  %l178 = alloca { i64, ptr }
  %l180 = alloca i1
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s16 = alloca %olang.scope
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t3 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aReused_3e_2eLen_3ccompiler_2femit_3aReused_3e(ptr %v3, ptr %t1)
  store i64 %t3, ptr %l30
  br label %bb1
bb1:
  %t4 = load i64, ptr %l30, !tbaa !24
  %t5 = icmp eq i64 %t4, 0
  br i1 %t5, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t9 = getelementptr %"compiler/build:Config", ptr %t7, i32 0, i32 0
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 1
  %t13 = extractvalue { i64, ptr } %t10, 0
  %t14 = extractvalue { i64, ptr } { i64 4, ptr @.d182 }, 1
  %t15 = extractvalue { i64, ptr } { i64 4, ptr @.d182 }, 0
  %t16 = add i64 %t13, %t15
  %t17 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t16)
  call void @olang_textcopy(ptr %t17, ptr %t12, i64 %t13)
  %t18 = getelementptr i8, ptr %t17, i64 %t13
  call void @olang_textcopy(ptr %t18, ptr %t14, i64 %t15)
  %t19 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t17, 1
  %t22 = extractvalue { i64, ptr } %t20, 0
  %t23 = extractvalue { i64, ptr } %t20, 1
  %t24 = mul i64 %t22, 1
  %t25 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  %t29 = call i32 @std_2fos_2eMkDirAll(ptr %s0, { i64, ptr } %t27)
  store i32 %t29, ptr %l36
  %t30 = icmp ne i32 %t29, 0
  br i1 %t30, label %bb6, label %ok.31
ok.31:
  br label %bb5
bb5:
  br label %bb10
bb6:
  %t32 = load i32, ptr %l36, !tbaa !23
  %t33 = ashr i32 %t32, 16
  %t35 = icmp eq i32 %t33, 1
  br i1 %t35, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_4bbc6d12b4c2aef5_61de3414d98ea881)
  unreachable
bb9:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb10:
  %t37 = call i32 @compiler_2fbuild_2ePid()
  store i32 %t37, ptr %l39
  br label %bb11
bb11:
  %t38 = load i32, ptr %l39, !tbaa !23
  store i32 %t38, ptr %l6, !tbaa !23
  %t39 = load ptr, ptr %l3, !tbaa !29
  store ptr %t39, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s5
  %t41 = load ptr, ptr %l7, !tbaa !29
  %t42 = load i64, ptr %l8, !tbaa !24
  %t45 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aReused_3e_2eRunFrom_3ccompiler_2femit_3aReused_3e(ptr %v3, ptr %t41, i64 %t42)
  %t46 = extractvalue { i32, { i64, ptr } } %t45, 1
  %t47 = extractvalue { i32, { i64, ptr } } %t45, 0
  store i32 %t47, ptr %l45
  %t48 = icmp ne i32 %t47, 0
  br i1 %t48, label %bb14, label %ok.49
ok.49:
  store { i64, ptr } %t46, ptr %l44
  br label %bb13
bb13:
  %t50 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t50, ptr %l41, !tbaa !27
  br label %bb18
bb14:
  %t51 = load i32, ptr %l45, !tbaa !23
  %t52 = ashr i32 %t51, 16
  %t54 = icmp eq i32 %t52, 1
  br i1 %t54, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_1a6fb0e4b3da4304_63cb76792ee304f0)
  unreachable
bb17:
  call void @__olang_scope_close(ptr %s5)
  br label %bb93
bb18:
  %t56 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t56, ptr %l9, !tbaa !27
  %t57 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t57, 0
  store i64 %t59, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb19
bb19:
  store %olang.scope zeroinitializer, ptr %s6
  %t61 = load i64, ptr %l11, !tbaa !24
  %t62 = load i64, ptr %l10, !tbaa !24
  %t65 = icmp slt i64 %t61, %t62
  %t67 = xor i1 %t65, true
  br i1 %t67, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s6)
  br label %bb91
bb21:
  br label %bb22
bb22:
  %t69 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t69, ptr %l54, !tbaa !27
  %t70 = load i64, ptr %l11, !tbaa !24
  %t72 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr %"compiler/emit:Reused", ptr %t73, i64 %t70
  %t75 = load %"compiler/emit:Reused", ptr %t74
  store %"compiler/emit:Reused" %t75, ptr %l12
  %t77 = getelementptr %"compiler/emit:Reused", ptr %l12, i32 0, i32 0
  %t78 = load i64, ptr %t77, !tbaa !24
  %t79 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t79, 0
  %t84 = icmp sge i64 %t78, %t81
  br i1 %t84, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l61, !tbaa !21
  br label %bb26
bb24:
  %t86 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t86, ptr %l62, !tbaa !27
  %t87 = getelementptr %"compiler/emit:Reused", ptr %l12, i32 0, i32 0
  %t88 = load i64, ptr %t87, !tbaa !24
  %t90 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr { i64, ptr }, ptr %t91, i64 %t88
  %t93 = load { i64, ptr }, ptr %t92, !tbaa !37
  %t95 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s6, { i64, ptr } %t93, { i64, ptr } { i64 0, ptr @.d183 })
  store i1 %t95, ptr %l65
  br label %bb25
bb25:
  %t96 = load i1, ptr %l65, !tbaa !21
  store i1 %t96, ptr %l61, !tbaa !21
  br label %bb26
bb26:
  %t97 = load i1, ptr %l61, !tbaa !21
  br i1 %t97, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s6)
  br label %bb90
bb28:
  br label %bb29
bb29:
  %t98 = load ptr, ptr %l1, !tbaa !29
  store ptr %t98, ptr %l66, !tbaa !29
  %t101 = getelementptr %"compiler/load:Loader", ptr %a0, i32 0, i32 5
  %t102 = getelementptr %"compiler/emit:Reused", ptr %l12, i32 0, i32 0
  %t103 = load i64, ptr %t102, !tbaa !24
  %t106 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t101, i64 %t103)
  store ptr %t106, ptr %l70
  br label %bb30
bb30:
  %t107 = load ptr, ptr %l70, !tbaa !29
  %t109 = getelementptr %"compiler/load:Module", ptr %t107, i32 0, i32 2
  %t110 = load { i64, ptr }, ptr %t109, !tbaa !27
  %t111 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t111, ptr %l73, !tbaa !27
  %t112 = getelementptr %"compiler/emit:Reused", ptr %l12, i32 0, i32 0
  %t113 = load i64, ptr %t112, !tbaa !24
  %t115 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = getelementptr { i64, ptr }, ptr %t116, i64 %t113
  %t118 = load { i64, ptr }, ptr %t117, !tbaa !37
  %t119 = load ptr, ptr %l66, !tbaa !29
  %t122 = call { i64, ptr } @compiler_2folang_2erecordPath(ptr %v1, ptr %v0, ptr %v2, ptr %s6, ptr %t119, { i64, ptr } %t110, { i64, ptr } %t118)
  store { i64, ptr } %t122, ptr %l76
  br label %bb31
bb31:
  %t123 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t123, ptr %l13, !tbaa !27
  %t124 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s6)
  store %"std/prelude/text:StringBuilder" %t124, ptr %l77
  br label %bb32
bb32:
  %t125 = load %"std/prelude/text:StringBuilder", ptr %l77
  store %"std/prelude/text:StringBuilder" %t125, ptr %l14
  store ptr %l14, ptr %l78, !tbaa !29
  %t126 = getelementptr %"compiler/emit:Reused", ptr %l12, i32 0, i32 4
  %t127 = load i64, ptr %t126, !tbaa !24
  store i64 %t127, ptr %l79, !tbaa !24
  %t128 = getelementptr %"compiler/emit:Reused", ptr %l12, i32 0, i32 5
  %t129 = load i1, ptr %t128, !tbaa !21
  br i1 %t129, label %bb33, label %bb34
bb33:
  store { i64, ptr } { i64 1, ptr @.d184 }, ptr %l81, !tbaa !27
  br label %bb35
bb34:
  store { i64, ptr } { i64 1, ptr @.d185 }, ptr %l81, !tbaa !27
  br label %bb35
bb35:
  %t131 = extractvalue { i64, ptr } { i64 25, ptr @.d186 }, 1
  %t132 = extractvalue { i64, ptr } { i64 25, ptr @.d186 }, 0
  %t133 = load i64, ptr %l79, !tbaa !24
  %t134 = call i64 @__olang_fmt_i64(ptr null, i64 %t133)
  %t135 = add i64 %t132, %t134
  %t136 = extractvalue { i64, ptr } { i64 7, ptr @.d187 }, 1
  %t137 = extractvalue { i64, ptr } { i64 7, ptr @.d187 }, 0
  %t138 = add i64 %t135, %t137
  %t139 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t139, 1
  %t141 = extractvalue { i64, ptr } %t139, 0
  %t142 = add i64 %t138, %t141
  %t143 = extractvalue { i64, ptr } { i64 1, ptr @.d188 }, 1
  %t144 = extractvalue { i64, ptr } { i64 1, ptr @.d188 }, 0
  %t145 = add i64 %t142, %t144
  %t146 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t145)
  call void @olang_textcopy(ptr %t146, ptr %t131, i64 %t132)
  %t147 = getelementptr i8, ptr %t146, i64 %t132
  %t148 = call i64 @__olang_fmt_i64(ptr %t147, i64 %t133)
  %t149 = getelementptr i8, ptr %t147, i64 %t134
  call void @olang_textcopy(ptr %t149, ptr %t136, i64 %t137)
  %t150 = getelementptr i8, ptr %t149, i64 %t137
  call void @olang_textcopy(ptr %t150, ptr %t140, i64 %t141)
  %t151 = getelementptr i8, ptr %t150, i64 %t141
  call void @olang_textcopy(ptr %t151, ptr %t143, i64 %t144)
  %t152 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t153 = insertvalue { i64, ptr } %t152, ptr %t146, 1
  %t155 = extractvalue { i64, ptr } %t153, 0
  %t156 = extractvalue { i64, ptr } %t153, 1
  %t157 = mul i64 %t155, 1
  %t158 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t157)
  call void @llvm.memcpy.p0.p0.i64(ptr %t158, ptr %t156, i64 %t157, i1 false)
  %t159 = insertvalue { i64, ptr } undef, i64 %t155, 0
  %t160 = insertvalue { i64, ptr } %t159, ptr %t158, 1
  %t161 = load ptr, ptr %l78, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s6, ptr %s6, ptr %t161, { i64, ptr } %t160)
  br label %bb36
bb36:
  %t163 = load ptr, ptr @__olang_prog_scope
  %t164 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %t163)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t164, ptr %l84
  br label %bb37
bb37:
  %t165 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l84
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t165, ptr %l15
  %t166 = getelementptr %"compiler/emit:Reused", ptr %l12, i32 0, i32 6
  store ptr %t166, ptr %l16, !tbaa !29
  store i64 0, ptr %l17, !tbaa !24
  br label %bb38
bb38:
  store %olang.scope zeroinitializer, ptr %s10
  %t168 = load ptr, ptr %l16, !tbaa !29
  %t169 = load i64, ptr %l17, !tbaa !24
  %t172 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v3, ptr %t168, i64 %t169)
  %t173 = extractvalue { i32, { i64, ptr } } %t172, 1
  %t174 = extractvalue { i32, { i64, ptr } } %t172, 0
  store i32 %t174, ptr %l90
  %t175 = icmp ne i32 %t174, 0
  br i1 %t175, label %bb40, label %ok.176
ok.176:
  store { i64, ptr } %t173, ptr %l89
  br label %bb39
bb39:
  %t177 = load { i64, ptr }, ptr %l89, !tbaa !27
  store { i64, ptr } %t177, ptr %l86, !tbaa !27
  br label %bb44
bb40:
  %t178 = load i32, ptr %l90, !tbaa !23
  %t179 = ashr i32 %t178, 16
  %t181 = icmp eq i32 %t179, 1
  br i1 %t181, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  call void @__olang_check_failed(ptr @olang_loc_b2c46c5c2279b83f_c4a092c9ae7cf92b)
  unreachable
bb43:
  call void @__olang_scope_close(ptr %s10)
  br label %bb58
bb44:
  %t183 = load { i64, ptr }, ptr %l86, !tbaa !27
  store { i64, ptr } %t183, ptr %l18, !tbaa !27
  %t184 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t186 = extractvalue { i64, ptr } %t184, 0
  store i64 %t186, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb45
bb45:
  store %olang.scope zeroinitializer, ptr %s11
  %t188 = load i64, ptr %l20, !tbaa !24
  %t189 = load i64, ptr %l19, !tbaa !24
  %t192 = icmp slt i64 %t188, %t189
  %t194 = xor i1 %t192, true
  br i1 %t194, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s11)
  br label %bb56
bb47:
  br label %bb48
bb48:
  %t196 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t196, ptr %l99, !tbaa !27
  %t197 = load i64, ptr %l20, !tbaa !24
  %t199 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !27
  %t201 = getelementptr { i64, ptr }, ptr %t200, i64 %t197
  %t202 = load { i64, ptr }, ptr %t201, !tbaa !37
  store { i64, ptr } %t202, ptr %l21, !tbaa !27
  %t204 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t207 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %s6, ptr %v3, ptr %l15, { i64, ptr } %t204)
  store i1 %t207, ptr %l104
  br label %bb49
bb49:
  %t208 = load i1, ptr %l104, !tbaa !21
  br i1 %t208, label %bb50, label %bb51
bb50:
  call void @__olang_scope_close(ptr %s11)
  br label %bb55
bb51:
  br label %bb52
bb52:
  %t209 = load { i64, ptr }, ptr %l21, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H2b85ceff512af6e6ca26c554a1c16247(ptr %s6, ptr %v3, ptr %l15, { i64, ptr } %t209, i1 true)
  br label %bb53
bb53:
  %t212 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t213 = extractvalue { i64, ptr } { i64 5, ptr @.d189 }, 1
  %t214 = extractvalue { i64, ptr } { i64 5, ptr @.d189 }, 0
  %t216 = extractvalue { i64, ptr } %t212, 1
  %t217 = extractvalue { i64, ptr } %t212, 0
  %t218 = add i64 %t214, %t217
  %t219 = extractvalue { i64, ptr } { i64 1, ptr @.d190 }, 1
  %t220 = extractvalue { i64, ptr } { i64 1, ptr @.d190 }, 0
  %t221 = add i64 %t218, %t220
  %t222 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t221)
  call void @olang_textcopy(ptr %t222, ptr %t213, i64 %t214)
  %t223 = getelementptr i8, ptr %t222, i64 %t214
  call void @olang_textcopy(ptr %t223, ptr %t216, i64 %t217)
  %t224 = getelementptr i8, ptr %t223, i64 %t217
  call void @olang_textcopy(ptr %t224, ptr %t219, i64 %t220)
  %t225 = insertvalue { i64, ptr } undef, i64 %t221, 0
  %t226 = insertvalue { i64, ptr } %t225, ptr %t222, 1
  %t228 = extractvalue { i64, ptr } %t226, 0
  %t229 = extractvalue { i64, ptr } %t226, 1
  %t230 = mul i64 %t228, 1
  %t231 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t230)
  call void @llvm.memcpy.p0.p0.i64(ptr %t231, ptr %t229, i64 %t230, i1 false)
  %t232 = insertvalue { i64, ptr } undef, i64 %t228, 0
  %t233 = insertvalue { i64, ptr } %t232, ptr %t231, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s6, ptr %s11, ptr %l14, { i64, ptr } %t233)
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s11)
  br label %bb55
bb55:
  %t236 = load i64, ptr %l20, !tbaa !24
  %t238 = add i64 %t236, 1
  store i64 %t238, ptr %l20, !tbaa !24
  br label %bb45
bb56:
  %t240 = load i64, ptr %l17, !tbaa !24
  %t241 = load i64, ptr %l19, !tbaa !24
  %t244 = add i64 %t240, %t241
  store i64 %t244, ptr %l17, !tbaa !24
  call void @__olang_scope_close(ptr %s10)
  br label %bb57
bb57:
  br label %bb38
bb58:
  store i1 true, ptr %l22, !tbaa !21
  store i64 0, ptr %l23, !tbaa !24
  %t246 = getelementptr %"compiler/emit:Reused", ptr %l12, i32 0, i32 1
  %t248 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v3, ptr %t246)
  store i64 %t248, ptr %l117
  br label %bb59
bb59:
  %t249 = load i64, ptr %l117, !tbaa !24
  store i64 %t249, ptr %l24, !tbaa !24
  store i64 1, ptr %l25, !tbaa !24
  %t250 = load i64, ptr %l24, !tbaa !24
  %t251 = load i64, ptr %l23, !tbaa !24
  %t254 = icmp sgt i64 %t250, %t251
  br i1 %t254, label %bb60, label %bb61
bb60:
  %t256 = load i64, ptr %l25, !tbaa !24
  %t258 = icmp sgt i64 %t256, 0
  br i1 %t258, label %bb62, label %bb63
bb61:
  store i64 0, ptr %l121, !tbaa !24
  br label %bb65
bb62:
  %t260 = load i64, ptr %l24, !tbaa !24
  %t261 = load i64, ptr %l23, !tbaa !24
  %t264 = sub i64 %t260, %t261
  %t265 = load i64, ptr %l25, !tbaa !24
  %t268 = add i64 %t264, %t265
  %t270 = sub i64 %t268, 1
  %t271 = load i64, ptr %l25, !tbaa !24
  %t274 = sdiv i64 %t270, %t271
  store i64 %t274, ptr %l124, !tbaa !24
  br label %bb64
bb63:
  store i64 0, ptr %l124, !tbaa !24
  br label %bb64
bb64:
  %t276 = load i64, ptr %l124, !tbaa !24
  store i64 %t276, ptr %l121, !tbaa !24
  br label %bb65
bb65:
  %t277 = load i64, ptr %l121, !tbaa !24
  store i64 %t277, ptr %l26, !tbaa !24
  store i64 0, ptr %l27, !tbaa !24
  br label %bb66
bb66:
  store %olang.scope zeroinitializer, ptr %s16
  %t278 = load i64, ptr %l27, !tbaa !24
  %t279 = load i64, ptr %l26, !tbaa !24
  %t282 = icmp slt i64 %t278, %t279
  %t284 = xor i1 %t282, true
  br i1 %t284, label %bb67, label %bb68
bb67:
  call void @__olang_scope_close(ptr %s16)
  br label %bb83
bb68:
  br label %bb69
bb69:
  %t286 = load i64, ptr %l23, !tbaa !24
  %t287 = load i64, ptr %l27, !tbaa !24
  %t288 = load i64, ptr %l25, !tbaa !24
  %t291 = mul i64 %t287, %t288
  %t294 = add i64 %t286, %t291
  store i64 %t294, ptr %l28, !tbaa !24
  %t296 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t297 = load i64, ptr %l28, !tbaa !24
  %t299 = extractvalue { i64, ptr } %t296, 1
  %t300 = extractvalue { i64, ptr } %t296, 0
  %t301 = extractvalue { i64, ptr } { i64 2, ptr @.d191 }, 1
  %t302 = extractvalue { i64, ptr } { i64 2, ptr @.d191 }, 0
  %t303 = add i64 %t300, %t302
  %t305 = call i64 @__olang_fmt_i64(ptr null, i64 %t297)
  %t306 = add i64 %t303, %t305
  %t307 = extractvalue { i64, ptr } { i64 3, ptr @.d192 }, 1
  %t308 = extractvalue { i64, ptr } { i64 3, ptr @.d192 }, 0
  %t309 = add i64 %t306, %t308
  %t310 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t309)
  call void @olang_textcopy(ptr %t310, ptr %t299, i64 %t300)
  %t311 = getelementptr i8, ptr %t310, i64 %t300
  call void @olang_textcopy(ptr %t311, ptr %t301, i64 %t302)
  %t312 = getelementptr i8, ptr %t311, i64 %t302
  %t313 = call i64 @__olang_fmt_i64(ptr %t312, i64 %t297)
  %t314 = getelementptr i8, ptr %t312, i64 %t305
  call void @olang_textcopy(ptr %t314, ptr %t307, i64 %t308)
  %t315 = insertvalue { i64, ptr } undef, i64 %t309, 0
  %t316 = insertvalue { i64, ptr } %t315, ptr %t310, 1
  %t318 = extractvalue { i64, ptr } %t316, 0
  %t319 = extractvalue { i64, ptr } %t316, 1
  %t320 = mul i64 %t318, 1
  %t321 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t320)
  call void @llvm.memcpy.p0.p0.i64(ptr %t321, ptr %t319, i64 %t320, i1 false)
  %t322 = insertvalue { i64, ptr } undef, i64 %t318, 0
  %t323 = insertvalue { i64, ptr } %t322, ptr %t321, 1
  store { i64, ptr } %t323, ptr %l145, !tbaa !27
  %t326 = getelementptr %"compiler/emit:Reused", ptr %l12, i32 0, i32 7
  %t327 = load i64, ptr %t326, !tbaa !24
  %t328 = load i64, ptr %l28, !tbaa !24
  %t331 = add i64 %t327, %t328
  %t334 = call %"compiler/emit:Object" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aObject_3e_2eAt_3ccompiler_2femit_3aObject_3e(ptr %v4, ptr %v4, ptr %a4, i64 %t331)
  store %"compiler/emit:Object" %t334, ptr %l151
  br label %bb70
bb70:
  %t335 = getelementptr %"compiler/emit:Object", ptr %l151, i32 0, i32 2
  %t336 = load { i64, ptr }, ptr %t335, !tbaa !27
  %t337 = load i32, ptr %l6, !tbaa !23
  %t338 = load { i64, ptr }, ptr %l145, !tbaa !27
  %t341 = call i1 @compiler_2folang_2eputFile(ptr %s16, ptr %v4, { i64, ptr } %t338, { i64, ptr } %t336, i32 %t337)
  store i1 %t341, ptr %l154
  br label %bb71
bb71:
  %t342 = load i1, ptr %l154, !tbaa !21
  %t343 = xor i1 %t342, true
  br i1 %t343, label %bb72, label %bb73
bb72:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb74
bb73:
  br label %bb74
bb74:
  store ptr %l14, ptr %l156, !tbaa !29
  %t345 = getelementptr %"compiler/emit:Reused", ptr %l12, i32 0, i32 2
  %t346 = load i64, ptr %l28, !tbaa !24
  %t349 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v3, ptr %t345, i64 %t346)
  store i1 %t349, ptr %l159
  br label %bb75
bb75:
  %t350 = load i1, ptr %l159, !tbaa !21
  br i1 %t350, label %bb76, label %bb77
bb76:
  store { i64, ptr } { i64 5, ptr @.d193 }, ptr %l160, !tbaa !27
  br label %bb78
bb77:
  store { i64, ptr } { i64 5, ptr @.d194 }, ptr %l160, !tbaa !27
  br label %bb78
bb78:
  %t352 = getelementptr %"compiler/emit:Reused", ptr %l12, i32 0, i32 7
  %t353 = load i64, ptr %t352, !tbaa !24
  %t354 = load i64, ptr %l28, !tbaa !24
  %t357 = add i64 %t353, %t354
  %t360 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v5, ptr %s16, ptr %a5, i64 %t357)
  store { i64, ptr } %t360, ptr %l165
  br label %bb79
bb79:
  %t361 = getelementptr %"compiler/emit:Reused", ptr %l12, i32 0, i32 1
  %t362 = load i64, ptr %l28, !tbaa !24
  %t365 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v3, ptr %s16, ptr %t361, i64 %t362)
  store { i64, ptr } %t365, ptr %l168
  br label %bb80
bb80:
  %t366 = load { i64, ptr }, ptr %l160, !tbaa !27
  %t367 = extractvalue { i64, ptr } %t366, 1
  %t368 = extractvalue { i64, ptr } %t366, 0
  %t369 = load { i64, ptr }, ptr %l165, !tbaa !27
  %t370 = extractvalue { i64, ptr } %t369, 1
  %t371 = extractvalue { i64, ptr } %t369, 0
  %t372 = add i64 %t368, %t371
  %t373 = extractvalue { i64, ptr } { i64 1, ptr @.d195 }, 1
  %t374 = extractvalue { i64, ptr } { i64 1, ptr @.d195 }, 0
  %t375 = add i64 %t372, %t374
  %t376 = load { i64, ptr }, ptr %l168, !tbaa !27
  %t377 = extractvalue { i64, ptr } %t376, 1
  %t378 = extractvalue { i64, ptr } %t376, 0
  %t379 = add i64 %t375, %t378
  %t380 = extractvalue { i64, ptr } { i64 1, ptr @.d196 }, 1
  %t381 = extractvalue { i64, ptr } { i64 1, ptr @.d196 }, 0
  %t382 = add i64 %t379, %t381
  %t383 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t382)
  call void @olang_textcopy(ptr %t383, ptr %t367, i64 %t368)
  %t384 = getelementptr i8, ptr %t383, i64 %t368
  call void @olang_textcopy(ptr %t384, ptr %t370, i64 %t371)
  %t385 = getelementptr i8, ptr %t384, i64 %t371
  call void @olang_textcopy(ptr %t385, ptr %t373, i64 %t374)
  %t386 = getelementptr i8, ptr %t385, i64 %t374
  call void @olang_textcopy(ptr %t386, ptr %t377, i64 %t378)
  %t387 = getelementptr i8, ptr %t386, i64 %t378
  call void @olang_textcopy(ptr %t387, ptr %t380, i64 %t381)
  %t388 = insertvalue { i64, ptr } undef, i64 %t382, 0
  %t389 = insertvalue { i64, ptr } %t388, ptr %t383, 1
  %t391 = extractvalue { i64, ptr } %t389, 0
  %t392 = extractvalue { i64, ptr } %t389, 1
  %t393 = mul i64 %t391, 1
  %t394 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t393)
  call void @llvm.memcpy.p0.p0.i64(ptr %t394, ptr %t392, i64 %t393, i1 false)
  %t395 = insertvalue { i64, ptr } undef, i64 %t391, 0
  %t396 = insertvalue { i64, ptr } %t395, ptr %t394, 1
  %t397 = load ptr, ptr %l156, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s6, ptr %s16, ptr %t397, { i64, ptr } %t396)
  br label %bb81
bb81:
  call void @__olang_scope_close(ptr %s16)
  br label %bb82
bb82:
  %t399 = load i64, ptr %l27, !tbaa !24
  %t401 = add i64 %t399, 1
  store i64 %t401, ptr %l27, !tbaa !24
  br label %bb66
bb83:
  %t403 = load i1, ptr %l22, !tbaa !21
  %t405 = xor i1 %t403, true
  br i1 %t405, label %bb84, label %bb85
bb84:
  call void @__olang_scope_close(ptr %s6)
  br label %bb90
bb85:
  br label %bb86
bb86:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s6, ptr %s6, ptr %l14, { i64, ptr } { i64 4, ptr @.d197 })
  br label %bb87
bb87:
  %t408 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t408, ptr %l176, !tbaa !27
  %t410 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s6, ptr %s6, ptr %l14)
  store { i64, ptr } %t410, ptr %l178
  br label %bb88
bb88:
  %t411 = load i32, ptr %l6, !tbaa !23
  %t412 = load { i64, ptr }, ptr %l176, !tbaa !27
  %t413 = load { i64, ptr }, ptr %l178, !tbaa !27
  %t415 = call i1 @compiler_2folang_2eputFile(ptr %s6, ptr %s6, { i64, ptr } %t412, { i64, ptr } %t413, i32 %t411)
  store i1 %t415, ptr %l180
  br label %bb89
bb89:
  call void @__olang_scope_close(ptr %s6)
  br label %bb90
bb90:
  %t416 = load i64, ptr %l11, !tbaa !24
  %t418 = add i64 %t416, 1
  store i64 %t418, ptr %l11, !tbaa !24
  br label %bb19
bb91:
  %t420 = load i64, ptr %l8, !tbaa !24
  %t421 = load i64, ptr %l10, !tbaa !24
  %t424 = add i64 %t420, %t421
  store i64 %t424, ptr %l8, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb92
bb92:
  br label %bb12
bb93:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2emain() #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l6 = alloca i32
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  call void @std_2fos_2eOnCrash(ptr %s0, { i64, ptr } { i64 97, ptr @.d198 })
  br label %bb1
bb1:
  %t1 = call { i64, ptr } @std_2fos_2eArgs(ptr %s0)
  store { i64, ptr } %t1, ptr %l1
  br label %bb2
bb2:
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t2, ptr %l0, !tbaa !27
  %t3 = call i1 @compiler_2folang_2eroomFor(i64 1073741824)
  store i1 %t3, ptr %l2
  br label %bb3
bb3:
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb4, label %bb5
bb4:
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t6 = getelementptr { { i64, ptr }, ptr }, ptr null, i32 1
  %t7 = ptrtoint ptr %t6 to i64
  %t8 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 %t7, i64 8)
  %t9 = getelementptr { { i64, ptr }, ptr }, ptr %t8, i32 0, i32 0
  store { i64, ptr } %t5, ptr %t9, !tbaa !28
  call void @__olang_scope_escape(ptr %s0)
  %t11 = getelementptr { { i64, ptr }, ptr }, ptr %t8, i32 0, i32 1
  store ptr %s0, ptr %t11, !tbaa !28
  %t12 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_199, 0
  %t13 = insertvalue { ptr, ptr } %t12, ptr %t8, 1
  %t15 = extractvalue { ptr, ptr } %t13, 0
  %t16 = extractvalue { ptr, ptr } %t13, 1
  call void @std_2fos_2eRunOnStack(ptr %s0, i64 1073741824, ptr %t15, ptr %t16)
  br label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb7
bb7:
  %t17 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t19 = call i32 @compiler_2folang_2edrive(ptr %s0, { i64, ptr } %t17)
  store i32 %t19, ptr %l6
  br label %bb8
bb8:
  %t20 = load i32, ptr %l6, !tbaa !23
  call void @std_2fos_2eExit(i32 %t20)
  unreachable
bb9:
  call void @__olang_check_failed(ptr @olang_loc_73b8d8bbbab8f911_f56ba933d304b59d)
  unreachable
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2folang_2emodeName(ptr %v0, i64 %a0) #0 {
entry:
  %l0 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store i64 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !24
  %t2 = load i64, ptr @G_2ecompiler_2folang_2eRun, !tbaa !24
  %t5 = icmp eq i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 14, ptr @.d200 }, ptr %l5, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t7, ptr %l4, !tbaa !27
  br label %bb3
bb2:
  %t9 = load i64, ptr %l0, !tbaa !24
  %t11 = getelementptr [12 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eModeWords, i64 0, i64 %t9
  %t12 = load { i64, ptr }, ptr %t11, !tbaa !37
  %t14 = extractvalue { i64, ptr } %t12, 1
  %t15 = extractvalue { i64, ptr } %t12, 0
  %t16 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t14, i64 %t15)
  %t17 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l4, !tbaa !27
  br label %bb3
bb3:
  %t20 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t20, 0
  store i64 %t21, ptr %l10, !tbaa !24
  %t22 = load i64, ptr %l10, !tbaa !24
  %t23 = mul i64 %t22, 1
  %t24 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t23)
  %t25 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t24, 1
  store { i64, ptr } %t26, ptr %l11, !tbaa !27
  %t27 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = load i64, ptr %l10, !tbaa !24
  %t32 = mul i64 %t31, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t28, ptr %t30, i64 %t32, i1 false)
  %t33 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t33, ptr %l4, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t34, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2folang_2emodeNumber(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca [12 x { i64, ptr }]
  %l12 = alloca i64
  %l15 = alloca i64
  %l36 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store i64 1, ptr %l1, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l7, ptr @G_2ecompiler_2folang_2eModeWords, i64 192, i1 false)
  %t1 = load [12 x { i64, ptr }], ptr %l7
  store i64 12, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t3 = load i64, ptr %l2, !tbaa !24
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = icmp sgt i64 %t3, %t4
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp sgt i64 %t9, 0
  br i1 %t11, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l12, !tbaa !24
  br label %bb6
bb3:
  %t13 = load i64, ptr %l2, !tbaa !24
  %t14 = load i64, ptr %l1, !tbaa !24
  %t17 = sub i64 %t13, %t14
  %t18 = load i64, ptr %l3, !tbaa !24
  %t21 = add i64 %t17, %t18
  %t23 = sub i64 %t21, 1
  %t24 = load i64, ptr %l3, !tbaa !24
  %t27 = sdiv i64 %t23, %t24
  store i64 %t27, ptr %l15, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb5
bb5:
  %t29 = load i64, ptr %l15, !tbaa !24
  store i64 %t29, ptr %l12, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l12, !tbaa !24
  store i64 %t30, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t31 = load i64, ptr %l5, !tbaa !24
  %t32 = load i64, ptr %l4, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb9:
  br label %bb10
bb10:
  %t39 = load i64, ptr %l1, !tbaa !24
  %t40 = load i64, ptr %l5, !tbaa !24
  %t41 = load i64, ptr %l3, !tbaa !24
  %t44 = mul i64 %t40, %t41
  %t47 = add i64 %t39, %t44
  store i64 %t47, ptr %l6, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  %t51 = getelementptr [12 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eModeWords, i64 0, i64 %t49
  %t52 = load { i64, ptr }, ptr %t51, !tbaa !37
  %t54 = load ptr, ptr @__olang_prog_scope
  %t57 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t54, ptr %v0, { i64, ptr } %t52, { i64, ptr } %a0)
  store i1 %t57, ptr %l36
  br label %bb11
bb11:
  %t58 = load i1, ptr %l36, !tbaa !21
  br i1 %t58, label %bb12, label %bb13
bb12:
  %t59 = load i64, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  store i64 %t59, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb15:
  %t61 = load i64, ptr %l5, !tbaa !24
  %t63 = add i64 %t61, 1
  store i64 %t63, ptr %l5, !tbaa !24
  br label %bb7
bb16:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2folang_2emodesOf(ptr %v0, i64 %a0) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca %"std/prelude/text:StringBuilder"
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca [12 x { i64, ptr }]
  %l21 = alloca i64
  %l24 = alloca i64
  %l44 = alloca i64
  %l50 = alloca %"std/prelude/text:StringBuilder"
  %l51 = alloca [12 x { i64, ptr }]
  %l56 = alloca i64
  %l59 = alloca i64
  %l78 = alloca i64
  %l86 = alloca ptr
  %l90 = alloca { i64, ptr }
  %l91 = alloca ptr
  %l93 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %l100 = alloca i64
  %l101 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store i64 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 0, ptr %l1, !tbaa !24
  store i64 0, ptr %l2, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l16, ptr @G_2ecompiler_2folang_2eModeWords, i64 192, i1 false)
  %t1 = load [12 x { i64, ptr }], ptr %l16
  store i64 12, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t3 = load i64, ptr %l3, !tbaa !24
  %t4 = load i64, ptr %l2, !tbaa !24
  %t7 = icmp sgt i64 %t3, %t4
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp sgt i64 %t9, 0
  br i1 %t11, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb6
bb3:
  %t13 = load i64, ptr %l3, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t17 = sub i64 %t13, %t14
  %t18 = load i64, ptr %l4, !tbaa !24
  %t21 = add i64 %t17, %t18
  %t23 = sub i64 %t21, 1
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = sdiv i64 %t23, %t24
  store i64 %t27, ptr %l24, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb5
bb5:
  %t29 = load i64, ptr %l24, !tbaa !24
  store i64 %t29, ptr %l21, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l21, !tbaa !24
  store i64 %t30, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t31 = load i64, ptr %l6, !tbaa !24
  %t32 = load i64, ptr %l5, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb9:
  br label %bb10
bb10:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load i64, ptr %l6, !tbaa !24
  %t41 = load i64, ptr %l4, !tbaa !24
  %t44 = mul i64 %t40, %t41
  %t47 = add i64 %t39, %t44
  %t49 = load i64, ptr %l1, !tbaa !24
  %t50 = load i64, ptr %l0, !tbaa !24
  store i64 %t47, ptr %l44, !tbaa !24
  %t53 = load i64, ptr %l44, !tbaa !24
  %t54 = load i64, ptr %l44, !tbaa !24
  %t55 = ashr i64 %t50, %t54
  %t57 = and i64 %t55, 1
  %t60 = add i64 %t49, %t57
  store i64 %t60, ptr %l1, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb11:
  %t62 = load i64, ptr %l6, !tbaa !24
  %t64 = add i64 %t62, 1
  store i64 %t64, ptr %l6, !tbaa !24
  br label %bb7
bb12:
  %t66 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t66, ptr %l50
  br label %bb13
bb13:
  %t67 = load %"std/prelude/text:StringBuilder", ptr %l50
  store %"std/prelude/text:StringBuilder" %t67, ptr %l8
  store i64 0, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l51, ptr @G_2ecompiler_2folang_2eModeWords, i64 192, i1 false)
  %t68 = load [12 x { i64, ptr }], ptr %l51
  store i64 12, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t70 = load i64, ptr %l11, !tbaa !24
  %t71 = load i64, ptr %l10, !tbaa !24
  %t74 = icmp sgt i64 %t70, %t71
  br i1 %t74, label %bb14, label %bb15
bb14:
  %t76 = load i64, ptr %l12, !tbaa !24
  %t78 = icmp sgt i64 %t76, 0
  br i1 %t78, label %bb16, label %bb17
bb15:
  store i64 0, ptr %l56, !tbaa !24
  br label %bb19
bb16:
  %t80 = load i64, ptr %l11, !tbaa !24
  %t81 = load i64, ptr %l10, !tbaa !24
  %t84 = sub i64 %t80, %t81
  %t85 = load i64, ptr %l12, !tbaa !24
  %t88 = add i64 %t84, %t85
  %t90 = sub i64 %t88, 1
  %t91 = load i64, ptr %l12, !tbaa !24
  %t94 = sdiv i64 %t90, %t91
  store i64 %t94, ptr %l59, !tbaa !24
  br label %bb18
bb17:
  store i64 0, ptr %l59, !tbaa !24
  br label %bb18
bb18:
  %t96 = load i64, ptr %l59, !tbaa !24
  store i64 %t96, ptr %l56, !tbaa !24
  br label %bb19
bb19:
  %t97 = load i64, ptr %l56, !tbaa !24
  store i64 %t97, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s5
  %t98 = load i64, ptr %l14, !tbaa !24
  %t99 = load i64, ptr %l13, !tbaa !24
  %t102 = icmp slt i64 %t98, %t99
  %t104 = xor i1 %t102, true
  br i1 %t104, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s5)
  br label %bb37
bb22:
  br label %bb23
bb23:
  %t106 = load i64, ptr %l10, !tbaa !24
  %t107 = load i64, ptr %l14, !tbaa !24
  %t108 = load i64, ptr %l12, !tbaa !24
  %t111 = mul i64 %t107, %t108
  %t114 = add i64 %t106, %t111
  store i64 %t114, ptr %l15, !tbaa !24
  %t116 = load i64, ptr %l0, !tbaa !24
  %t117 = load i64, ptr %l15, !tbaa !24
  store i64 %t117, ptr %l78, !tbaa !24
  %t119 = load i64, ptr %l78, !tbaa !24
  %t120 = load i64, ptr %l78, !tbaa !24
  %t121 = ashr i64 %t116, %t120
  %t123 = and i64 %t121, 1
  %t125 = icmp eq i64 %t123, 0
  br i1 %t125, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s5)
  br label %bb36
bb25:
  br label %bb26
bb26:
  %t127 = load i64, ptr %l9, !tbaa !24
  %t129 = add i64 %t127, 1
  store i64 %t129, ptr %l9, !tbaa !24
  %t131 = load i64, ptr %l9, !tbaa !24
  %t133 = icmp sgt i64 %t131, 1
  br i1 %t133, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s7
  store ptr %l8, ptr %l86, !tbaa !29
  %t135 = load i64, ptr %l9, !tbaa !24
  %t136 = load i64, ptr %l1, !tbaa !24
  %t139 = icmp eq i64 %t135, %t136
  br i1 %t139, label %bb29, label %bb30
bb28:
  br label %bb33
bb29:
  store { i64, ptr } { i64 5, ptr @.d201 }, ptr %l90, !tbaa !27
  br label %bb31
bb30:
  store { i64, ptr } { i64 2, ptr @.d202 }, ptr %l90, !tbaa !27
  br label %bb31
bb31:
  %t141 = load ptr, ptr %l86, !tbaa !29
  %t142 = load { i64, ptr }, ptr %l90, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %t141, { i64, ptr } %t142)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s7)
  br label %bb33
bb33:
  store ptr %l8, ptr %l91, !tbaa !29
  %t143 = load i64, ptr %l15, !tbaa !24
  %t145 = call { i64, ptr } @compiler_2folang_2emodeName(ptr %s5, i64 %t143)
  store { i64, ptr } %t145, ptr %l93
  br label %bb34
bb34:
  %t146 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t147 = extractvalue { i64, ptr } %t146, 0
  %t148 = extractvalue { i64, ptr } %t146, 1
  %t149 = mul i64 %t147, 1
  %t150 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t149)
  call void @llvm.memcpy.p0.p0.i64(ptr %t150, ptr %t148, i64 %t149, i1 false)
  %t151 = insertvalue { i64, ptr } undef, i64 %t147, 0
  %t152 = insertvalue { i64, ptr } %t151, ptr %t150, 1
  %t153 = load ptr, ptr %l91, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %t153, { i64, ptr } %t152)
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s5)
  br label %bb36
bb36:
  %t155 = load i64, ptr %l14, !tbaa !24
  %t157 = add i64 %t155, 1
  store i64 %t157, ptr %l14, !tbaa !24
  br label %bb20
bb37:
  %t160 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v0, ptr %l8)
  store { i64, ptr } %t160, ptr %l98
  br label %bb38
bb38:
  %t161 = load { i64, ptr }, ptr %l98, !tbaa !27
  store { i64, ptr } %t161, ptr %l99, !tbaa !27
  %t162 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t163 = extractvalue { i64, ptr } %t162, 0
  store i64 %t163, ptr %l100, !tbaa !24
  %t164 = load i64, ptr %l100, !tbaa !24
  %t165 = mul i64 %t164, 1
  %t166 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t165)
  %t167 = insertvalue { i64, ptr } undef, i64 %t164, 0
  %t168 = insertvalue { i64, ptr } %t167, ptr %t166, 1
  store { i64, ptr } %t168, ptr %l101, !tbaa !27
  %t169 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !27
  %t171 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t172 = load ptr, ptr %t171, !tbaa !27
  %t173 = load i64, ptr %l100, !tbaa !24
  %t174 = mul i64 %t173, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t170, ptr %t172, i64 %t174, i1 false)
  %t175 = load { i64, ptr }, ptr %l101, !tbaa !27
  store { i64, ptr } %t175, ptr %l99, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t176 = load { i64, ptr }, ptr %l99, !tbaa !27
  store { i64, ptr } %t176, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2folang_2emoduleKeys(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l25 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca i64
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca %"compiler/load:Import"
  %l39 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l40 = alloca ptr
  %l41 = alloca i64
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l56 = alloca { i64, ptr }
  %l58 = alloca i1
  %l60 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l67 = alloca ptr
  %l69 = alloca { i64, ptr }
  %l73 = alloca ptr
  %l79 = alloca i64
  %l87 = alloca i64
  %l90 = alloca i64
  %l110 = alloca ptr
  %l111 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l121 = alloca ptr
  %l126 = alloca { i64, ptr }
  %l135 = alloca { i64, ptr }
  %l138 = alloca i64
  %l140 = alloca { i64, ptr }
  %l148 = alloca i64
  %l151 = alloca i64
  %l173 = alloca i64
  %l176 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l177 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l184 = alloca i64
  %l187 = alloca i64
  %l207 = alloca ptr
  %l215 = alloca i64
  %l218 = alloca i64
  %l220 = alloca i64
  %l221 = alloca i32
  %l229 = alloca ptr
  %l232 = alloca { i64, ptr }
  %l235 = alloca { i64, ptr }
  %l236 = alloca i32
  %l245 = alloca { i64, ptr }
  %l250 = alloca i1
  %l263 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l270 = alloca { i64, ptr }
  %l273 = alloca { i64, ptr }
  %l274 = alloca i32
  %l283 = alloca { i64, ptr }
  %l286 = alloca ptr
  %l289 = alloca ptr
  %l301 = alloca { i64, ptr }
  %l302 = alloca i64
  %l304 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t19 = alloca i64
  %t119 = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/load:Loader", ptr %t1, i32 0, i32 5
  %t4 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t3
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %l3
  %t7 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v0, ptr %l3)
  store i64 %t7, ptr %l49
  br label %bb1
bb1:
  %t8 = load i64, ptr %l49, !tbaa !24
  store i64 %t8, ptr %l4, !tbaa !24
  %t9 = load i64, ptr %l4, !tbaa !24
  store i64 %t9, ptr %l50, !tbaa !24
  %t10 = load i64, ptr %l50, !tbaa !24
  %t11 = icmp sge i64 %t10, 0
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l50, !tbaa !24
  %t14 = icmp sle i64 %t13, 576460752303423487
  br i1 %t14, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @olang_loc_73c3116820f750d_32f9964414b76079)
  unreachable
bb4:
  %t16 = load i64, ptr %l50, !tbaa !24
  %t17 = mul i64 %t16, 16
  %t18 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t17)
  store i64 0, ptr %t19
  br label %fill.20
fill.20:
  %t23 = load i64, ptr %t19
  %t24 = icmp slt i64 %t23, %t16
  br i1 %t24, label %fillb.21, label %filld.22
fillb.21:
  %t25 = getelementptr { i64, ptr }, ptr %t18, i64 %t23
  store { i64, ptr } { i64 0, ptr @.d203 }, ptr %t25
  %t26 = add i64 %t23, 1
  store i64 %t26, ptr %t19
  br label %fill.20
filld.22:
  %t27 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t18, 1
  store { i64, ptr } %t28, ptr %l5, !tbaa !27
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t34 = call { i64, ptr } @compiler_2folang_2ebuildInputs(ptr %v1, ptr %s0, ptr %t30, i1 %a2)
  store { i64, ptr } %t34, ptr %l56
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_73c3116820f750d_32f9964414b76079)
  unreachable
bb6:
  %t35 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t35, ptr %l6, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t38 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t36, { i64, ptr } { i64 0, ptr @.d204 })
  store i1 %t38, ptr %l58
  br label %bb7
bb7:
  %t39 = load i1, ptr %l58, !tbaa !21
  br i1 %t39, label %bb8, label %bb9
bb8:
  %t40 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t40, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t42 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t42, ptr %l60, !tbaa !27
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = getelementptr %"compiler/build:Config", ptr %t43, i32 0, i32 4
  %t46 = load i1, ptr %t45, !tbaa !21
  br i1 %t46, label %bb11, label %bb12
bb11:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/load:Loader", ptr %t48, i32 0, i32 7
  %t51 = load i64, ptr %t50, !tbaa !24
  %t54 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %l3, i64 %t51)
  store ptr %t54, ptr %l67
  br label %bb13
bb12:
  store { i64, ptr } { i64 0, ptr @.d205 }, ptr %l63, !tbaa !27
  br label %bb15
bb13:
  %t55 = load ptr, ptr %l67, !tbaa !29
  %t57 = getelementptr %"compiler/load:Module", ptr %t55, i32 0, i32 2
  %t58 = load { i64, ptr }, ptr %t57, !tbaa !27
  store { i64, ptr } %t58, ptr %l69, !tbaa !27
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/load:Loader", ptr %t59, i32 0, i32 7
  %t62 = load i64, ptr %t61, !tbaa !24
  %t65 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %l3, i64 %t62)
  store ptr %t65, ptr %l73
  br label %bb14
bb14:
  %t66 = load ptr, ptr %l73, !tbaa !29
  %t68 = getelementptr %"compiler/load:Module", ptr %t66, i32 0, i32 0
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  %t70 = extractvalue { i64, ptr } { i64 6, ptr @.d206 }, 1
  %t71 = extractvalue { i64, ptr } { i64 6, ptr @.d206 }, 0
  %t72 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t72, 1
  %t74 = extractvalue { i64, ptr } %t72, 0
  %t75 = add i64 %t71, %t74
  %t76 = extractvalue { i64, ptr } { i64 1, ptr @.d207 }, 1
  %t77 = extractvalue { i64, ptr } { i64 1, ptr @.d207 }, 0
  %t78 = add i64 %t75, %t77
  %t80 = extractvalue { i64, ptr } %t69, 1
  %t81 = extractvalue { i64, ptr } %t69, 0
  %t82 = add i64 %t78, %t81
  %t83 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t82)
  call void @olang_textcopy(ptr %t83, ptr %t70, i64 %t71)
  %t84 = getelementptr i8, ptr %t83, i64 %t71
  call void @olang_textcopy(ptr %t84, ptr %t73, i64 %t74)
  %t85 = getelementptr i8, ptr %t84, i64 %t74
  call void @olang_textcopy(ptr %t85, ptr %t76, i64 %t77)
  %t86 = getelementptr i8, ptr %t85, i64 %t77
  call void @olang_textcopy(ptr %t86, ptr %t80, i64 %t81)
  %t87 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t88 = insertvalue { i64, ptr } %t87, ptr %t83, 1
  %t90 = extractvalue { i64, ptr } %t88, 0
  %t91 = extractvalue { i64, ptr } %t88, 1
  %t92 = mul i64 %t90, 1
  %t93 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t92)
  call void @llvm.memcpy.p0.p0.i64(ptr %t93, ptr %t91, i64 %t92, i1 false)
  %t94 = insertvalue { i64, ptr } undef, i64 %t90, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t93, 1
  store { i64, ptr } %t95, ptr %l63, !tbaa !27
  br label %bb15
bb15:
  %t97 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t97, 1
  %t99 = extractvalue { i64, ptr } %t97, 0
  %t100 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 1
  %t102 = extractvalue { i64, ptr } %t100, 0
  %t103 = add i64 %t99, %t102
  %t104 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t103)
  call void @olang_textcopy(ptr %t104, ptr %t98, i64 %t99)
  %t105 = getelementptr i8, ptr %t104, i64 %t99
  call void @olang_textcopy(ptr %t105, ptr %t101, i64 %t102)
  %t106 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t104, 1
  store { i64, ptr } %t107, ptr %l7, !tbaa !27
  %t109 = load i64, ptr %l4, !tbaa !24
  store i64 %t109, ptr %l79, !tbaa !24
  %t110 = load i64, ptr %l79, !tbaa !24
  %t111 = icmp sge i64 %t110, 0
  br i1 %t111, label %bb16, label %bb17
bb16:
  %t113 = load i64, ptr %l79, !tbaa !24
  %t114 = icmp sle i64 %t113, 576460752303423487
  br i1 %t114, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_23d2168bab4aeae0_126950dc9613ccec)
  unreachable
bb18:
  %t116 = load i64, ptr %l79, !tbaa !24
  %t117 = mul i64 %t116, 16
  %t118 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t117)
  store i64 0, ptr %t119
  br label %fill.120
fill.120:
  %t123 = load i64, ptr %t119
  %t124 = icmp slt i64 %t123, %t116
  br i1 %t124, label %fillb.121, label %filld.122
fillb.121:
  %t125 = getelementptr { i64, ptr }, ptr %t118, i64 %t123
  store { i64, ptr } { i64 0, ptr @.d208 }, ptr %t125
  %t126 = add i64 %t123, 1
  store i64 %t126, ptr %t119
  br label %fill.120
filld.122:
  %t127 = insertvalue { i64, ptr } undef, i64 %t116, 0
  %t128 = insertvalue { i64, ptr } %t127, ptr %t118, 1
  store { i64, ptr } %t128, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t130 = load i64, ptr %l4, !tbaa !24
  store i64 %t130, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t132 = load i64, ptr %l10, !tbaa !24
  %t133 = load i64, ptr %l9, !tbaa !24
  %t136 = icmp sgt i64 %t132, %t133
  br i1 %t136, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_23d2168bab4aeae0_126950dc9613ccec)
  unreachable
bb20:
  %t138 = load i64, ptr %l11, !tbaa !24
  %t140 = icmp sgt i64 %t138, 0
  br i1 %t140, label %bb22, label %bb23
bb21:
  store i64 0, ptr %l87, !tbaa !24
  br label %bb25
bb22:
  %t142 = load i64, ptr %l10, !tbaa !24
  %t143 = load i64, ptr %l9, !tbaa !24
  %t146 = sub i64 %t142, %t143
  %t147 = load i64, ptr %l11, !tbaa !24
  %t150 = add i64 %t146, %t147
  %t152 = sub i64 %t150, 1
  %t153 = load i64, ptr %l11, !tbaa !24
  %t156 = sdiv i64 %t152, %t153
  store i64 %t156, ptr %l90, !tbaa !24
  br label %bb24
bb23:
  store i64 0, ptr %l90, !tbaa !24
  br label %bb24
bb24:
  %t158 = load i64, ptr %l90, !tbaa !24
  store i64 %t158, ptr %l87, !tbaa !24
  br label %bb25
bb25:
  %t159 = load i64, ptr %l87, !tbaa !24
  store i64 %t159, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb26
bb26:
  store %olang.scope zeroinitializer, ptr %s5
  %t160 = load i64, ptr %l13, !tbaa !24
  %t161 = load i64, ptr %l12, !tbaa !24
  %t164 = icmp slt i64 %t160, %t161
  %t166 = xor i1 %t164, true
  br i1 %t166, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s5)
  br label %bb44
bb28:
  br label %bb29
bb29:
  %t168 = load i64, ptr %l9, !tbaa !24
  %t169 = load i64, ptr %l13, !tbaa !24
  %t170 = load i64, ptr %l11, !tbaa !24
  %t173 = mul i64 %t169, %t170
  %t176 = add i64 %t168, %t173
  store i64 %t176, ptr %l14, !tbaa !24
  %t178 = load i64, ptr %l14, !tbaa !24
  %t181 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %l3, i64 %t178)
  store ptr %t181, ptr %l110
  br label %bb30
bb30:
  %t182 = load ptr, ptr %l110, !tbaa !29
  store ptr %t182, ptr %l15, !tbaa !29
  %t183 = load ptr, ptr @__olang_prog_scope
  %t184 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t183)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t184, ptr %l111
  br label %bb31
bb31:
  %t185 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l111
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t185, ptr %l16
  %t186 = load ptr, ptr %l15, !tbaa !29
  %t188 = getelementptr %"compiler/load:Module", ptr %t186, i32 0, i32 2
  %t189 = load { i64, ptr }, ptr %t188, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s5, ptr %v0, ptr %l16, { i64, ptr } %t189)
  br label %bb32
bb32:
  %t192 = load ptr, ptr %l15, !tbaa !29
  %t194 = getelementptr %"compiler/load:Module", ptr %t192, i32 0, i32 0
  %t195 = load { i64, ptr }, ptr %t194, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s5, ptr %v0, ptr %l16, { i64, ptr } %t195)
  br label %bb33
bb33:
  %t198 = load ptr, ptr %l15, !tbaa !29
  %t200 = getelementptr %"compiler/load:Module", ptr %t198, i32 0, i32 1
  %t201 = load { i64, ptr }, ptr %t200, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s5, ptr %v0, ptr %l16, { i64, ptr } %t201)
  br label %bb34
bb34:
  store ptr %l16, ptr %l121, !tbaa !29
  %t204 = load ptr, ptr %l15, !tbaa !29
  %t206 = getelementptr %"compiler/load:Module", ptr %t204, i32 0, i32 6
  %t207 = load ptr, ptr %t206, !tbaa !29
  %t209 = icmp eq ptr %t207, null
  %t211 = xor i1 %t209, true
  br i1 %t211, label %bb35, label %bb36
bb35:
  %t213 = load ptr, ptr %l15, !tbaa !29
  %t215 = getelementptr %"compiler/load:Module", ptr %t213, i32 0, i32 6
  %t216 = load ptr, ptr %t215, !tbaa !29
  %t218 = icmp eq ptr %t216, null
  br i1 %t218, label %bb37, label %bb38
bb36:
  store { i64, ptr } { i64 0, ptr @.d209 }, ptr %l135, !tbaa !27
  %t220 = load { i64, ptr }, ptr %l135, !tbaa !27
  store { i64, ptr } %t220, ptr %l126, !tbaa !27
  br label %bb40
bb37:
  call void @__olang_check_failed(ptr @olang_loc_a3d985a905b98e7d_1a99d62f9ee112a1)
  unreachable
bb38:
  br label %bb39
bb39:
  %t222 = load ptr, ptr %l15, !tbaa !29
  %t224 = getelementptr %"compiler/load:Module", ptr %t222, i32 0, i32 6
  %t225 = load ptr, ptr %t224, !tbaa !29
  %t228 = getelementptr %"compiler/source:Source", ptr %t225, i32 0, i32 1
  %t229 = load { i64, ptr }, ptr %t228, !tbaa !27
  store { i64, ptr } %t229, ptr %l126, !tbaa !27
  br label %bb40
bb40:
  %t232 = load { i64, ptr }, ptr %l126, !tbaa !27
  %t233 = extractvalue { i64, ptr } %t232, 0
  %t234 = extractvalue { i64, ptr } %t232, 1
  %t235 = mul i64 %t233, 1
  %t236 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t235)
  call void @llvm.memcpy.p0.p0.i64(ptr %t236, ptr %t234, i64 %t235, i1 false)
  %t237 = insertvalue { i64, ptr } undef, i64 %t233, 0
  %t238 = insertvalue { i64, ptr } %t237, ptr %t236, 1
  %t239 = load ptr, ptr %l121, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s5, ptr %s5, ptr %t239, { i64, ptr } %t238)
  br label %bb41
bb41:
  %t241 = load i64, ptr %l14, !tbaa !24
  store i64 %t241, ptr %l138, !tbaa !24
  %t243 = call { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %s5, ptr %s0, ptr %l16)
  store { i64, ptr } %t243, ptr %l140
  br label %bb42
bb42:
  %t244 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t245 = extractvalue { i64, ptr } %t244, 0
  %t246 = extractvalue { i64, ptr } %t244, 1
  %t247 = mul i64 %t245, 1
  %t248 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t247)
  call void @llvm.memcpy.p0.p0.i64(ptr %t248, ptr %t246, i64 %t247, i1 false)
  %t249 = insertvalue { i64, ptr } undef, i64 %t245, 0
  %t250 = insertvalue { i64, ptr } %t249, ptr %t248, 1
  %t252 = load i64, ptr %l138, !tbaa !24
  %t253 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t254 = load ptr, ptr %t253, !tbaa !27
  %t255 = getelementptr { i64, ptr }, ptr %t254, i64 %t252
  store { i64, ptr } %t250, ptr %t255, !tbaa !37
  call void @__olang_scope_close(ptr %s5)
  br label %bb43
bb43:
  %t256 = load i64, ptr %l13, !tbaa !24
  %t258 = add i64 %t256, 1
  store i64 %t258, ptr %l13, !tbaa !24
  br label %bb26
bb44:
  store i64 0, ptr %l17, !tbaa !24
  %t260 = load i64, ptr %l4, !tbaa !24
  store i64 %t260, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t262 = load i64, ptr %l18, !tbaa !24
  %t263 = load i64, ptr %l17, !tbaa !24
  %t266 = icmp sgt i64 %t262, %t263
  br i1 %t266, label %bb45, label %bb46
bb45:
  %t268 = load i64, ptr %l19, !tbaa !24
  %t270 = icmp sgt i64 %t268, 0
  br i1 %t270, label %bb47, label %bb48
bb46:
  store i64 0, ptr %l148, !tbaa !24
  br label %bb50
bb47:
  %t272 = load i64, ptr %l18, !tbaa !24
  %t273 = load i64, ptr %l17, !tbaa !24
  %t276 = sub i64 %t272, %t273
  %t277 = load i64, ptr %l19, !tbaa !24
  %t280 = add i64 %t276, %t277
  %t282 = sub i64 %t280, 1
  %t283 = load i64, ptr %l19, !tbaa !24
  %t286 = sdiv i64 %t282, %t283
  store i64 %t286, ptr %l151, !tbaa !24
  br label %bb49
bb48:
  store i64 0, ptr %l151, !tbaa !24
  br label %bb49
bb49:
  %t288 = load i64, ptr %l151, !tbaa !24
  store i64 %t288, ptr %l148, !tbaa !24
  br label %bb50
bb50:
  %t289 = load i64, ptr %l148, !tbaa !24
  store i64 %t289, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb51
bb51:
  store %olang.scope zeroinitializer, ptr %s8
  %t290 = load i64, ptr %l21, !tbaa !24
  %t291 = load i64, ptr %l20, !tbaa !24
  %t294 = icmp slt i64 %t290, %t291
  %t296 = xor i1 %t294, true
  br i1 %t296, label %bb52, label %bb53
bb52:
  call void @__olang_scope_close(ptr %s8)
  br label %bb141
bb53:
  br label %bb54
bb54:
  %t298 = load i64, ptr %l17, !tbaa !24
  %t299 = load i64, ptr %l21, !tbaa !24
  %t300 = load i64, ptr %l19, !tbaa !24
  %t303 = mul i64 %t299, %t300
  %t306 = add i64 %t298, %t303
  store i64 %t306, ptr %l22, !tbaa !24
  %t308 = load i64, ptr %l22, !tbaa !24
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t311 = getelementptr %"compiler/load:Loader", ptr %t309, i32 0, i32 7
  %t312 = load i64, ptr %t311, !tbaa !24
  %t315 = icmp eq i64 %t308, %t312
  br i1 %t315, label %bb55, label %bb56
bb55:
  call void @__olang_scope_close(ptr %s8)
  br label %bb140
bb56:
  br label %bb57
bb57:
  %t317 = load i64, ptr %l4, !tbaa !24
  store i64 %t317, ptr %l173, !tbaa !24
  %t318 = load i64, ptr %l173, !tbaa !24
  %t319 = icmp sge i64 %t318, 0
  br i1 %t319, label %bb58, label %bb59
bb58:
  %t321 = load i64, ptr %l173, !tbaa !24
  %t322 = mul i64 %t321, 1
  %t323 = call ptr @__olang_scope_alloc_zeroed(ptr %s8, i64 %t322)
  %t324 = insertvalue { i64, ptr } undef, i64 %t321, 0
  %t325 = insertvalue { i64, ptr } %t324, ptr %t323, 1
  store { i64, ptr } %t325, ptr %l23, !tbaa !27
  %t327 = load ptr, ptr @__olang_prog_scope
  %t328 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t327)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t328, ptr %l176
  br label %bb60
bb59:
  call void @__olang_check_failed(ptr @olang_loc_32de2828e497f50e_77e9a884b57210fa)
  unreachable
bb60:
  %t329 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l176
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t329, ptr %l24
  %t330 = load ptr, ptr @__olang_prog_scope
  %t331 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t330)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t331, ptr %l177
  br label %bb61
bb61:
  %t332 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l177
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t332, ptr %l25
  %t333 = load i64, ptr %l22, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s8, ptr %l25, i64 %t333)
  br label %bb62
bb62:
  store i64 0, ptr %l26, !tbaa !24
  %t336 = load i64, ptr %l4, !tbaa !24
  store i64 %t336, ptr %l27, !tbaa !24
  store i64 1, ptr %l28, !tbaa !24
  %t338 = load i64, ptr %l27, !tbaa !24
  %t339 = load i64, ptr %l26, !tbaa !24
  %t342 = icmp sgt i64 %t338, %t339
  br i1 %t342, label %bb63, label %bb64
bb63:
  %t344 = load i64, ptr %l28, !tbaa !24
  %t346 = icmp sgt i64 %t344, 0
  br i1 %t346, label %bb65, label %bb66
bb64:
  store i64 0, ptr %l184, !tbaa !24
  br label %bb68
bb65:
  %t348 = load i64, ptr %l27, !tbaa !24
  %t349 = load i64, ptr %l26, !tbaa !24
  %t352 = sub i64 %t348, %t349
  %t353 = load i64, ptr %l28, !tbaa !24
  %t356 = add i64 %t352, %t353
  %t358 = sub i64 %t356, 1
  %t359 = load i64, ptr %l28, !tbaa !24
  %t362 = sdiv i64 %t358, %t359
  store i64 %t362, ptr %l187, !tbaa !24
  br label %bb67
bb66:
  store i64 0, ptr %l187, !tbaa !24
  br label %bb67
bb67:
  %t364 = load i64, ptr %l187, !tbaa !24
  store i64 %t364, ptr %l184, !tbaa !24
  br label %bb68
bb68:
  %t365 = load i64, ptr %l184, !tbaa !24
  store i64 %t365, ptr %l29, !tbaa !24
  store i64 0, ptr %l30, !tbaa !24
  br label %bb69
bb69:
  store %olang.scope zeroinitializer, ptr %s11
  %t366 = load i64, ptr %l30, !tbaa !24
  %t367 = load i64, ptr %l29, !tbaa !24
  %t370 = icmp slt i64 %t366, %t367
  %t372 = xor i1 %t370, true
  br i1 %t372, label %bb70, label %bb71
bb70:
  call void @__olang_scope_close(ptr %s11)
  br label %bb79
bb71:
  br label %bb72
bb72:
  %t374 = load i64, ptr %l26, !tbaa !24
  %t375 = load i64, ptr %l30, !tbaa !24
  %t376 = load i64, ptr %l28, !tbaa !24
  %t379 = mul i64 %t375, %t376
  %t382 = add i64 %t374, %t379
  store i64 %t382, ptr %l31, !tbaa !24
  %t384 = load i64, ptr %l31, !tbaa !24
  %t387 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %l3, i64 %t384)
  store ptr %t387, ptr %l207
  br label %bb73
bb73:
  %t388 = load ptr, ptr %l207, !tbaa !29
  %t390 = getelementptr %"compiler/load:Module", ptr %t388, i32 0, i32 3
  %t391 = load i1, ptr %t390, !tbaa !21
  br i1 %t391, label %bb74, label %bb75
bb74:
  %t393 = load i64, ptr %l31, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s8, ptr %l25, i64 %t393)
  br label %bb76
bb75:
  br label %bb77
bb76:
  br label %bb77
bb77:
  call void @__olang_scope_close(ptr %s11)
  br label %bb78
bb78:
  %t396 = load i64, ptr %l30, !tbaa !24
  %t398 = add i64 %t396, 1
  store i64 %t398, ptr %l30, !tbaa !24
  br label %bb69
bb79:
  br label %bb80
bb80:
  store %olang.scope zeroinitializer, ptr %s14
  %t401 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %s8, ptr %l25)
  store i64 %t401, ptr %l215
  br label %bb81
bb81:
  %t402 = load i64, ptr %l215, !tbaa !24
  %t403 = icmp sgt i64 %t402, 0
  %t405 = xor i1 %t403, true
  br i1 %t405, label %bb82, label %bb83
bb82:
  call void @__olang_scope_close(ptr %s14)
  br label %bb117
bb83:
  br label %bb84
bb84:
  %t408 = call { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %s8, ptr %l25)
  %t409 = extractvalue { i32, i64 } %t408, 1
  %t410 = extractvalue { i32, i64 } %t408, 0
  store i32 %t410, ptr %l221
  %t411 = icmp ne i32 %t410, 0
  br i1 %t411, label %bb86, label %ok.412
ok.412:
  store i64 %t409, ptr %l220
  br label %bb85
bb85:
  %t413 = load i64, ptr %l220, !tbaa !24
  store i64 %t413, ptr %l218, !tbaa !24
  br label %bb88
bb86:
  br label %bb87
bb87:
  call void @__olang_scope_close(ptr %s14)
  br label %bb117
bb88:
  %t414 = load i64, ptr %l218, !tbaa !24
  store i64 %t414, ptr %l32, !tbaa !24
  %t415 = load i64, ptr %l32, !tbaa !24
  %t417 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t418 = load ptr, ptr %t417, !tbaa !27
  %t419 = getelementptr i1, ptr %t418, i64 %t415
  %t420 = load i1, ptr %t419, !tbaa !31
  br i1 %t420, label %bb89, label %bb90
bb89:
  call void @__olang_scope_close(ptr %s14)
  br label %bb116
bb90:
  br label %bb91
bb91:
  %t422 = load i64, ptr %l32, !tbaa !24
  %t424 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t425 = load ptr, ptr %t424, !tbaa !27
  %t426 = getelementptr i1, ptr %t425, i64 %t422
  store i1 true, ptr %t426, !tbaa !31
  %t427 = load i64, ptr %l32, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s8, ptr %l24, i64 %t427)
  br label %bb92
bb92:
  %t430 = load i64, ptr %l32, !tbaa !24
  %t433 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %l3, i64 %t430)
  store ptr %t433, ptr %l229
  br label %bb93
bb93:
  %t434 = load ptr, ptr %l229, !tbaa !29
  %t436 = getelementptr %"compiler/load:Module", ptr %t434, i32 0, i32 11
  store ptr %t436, ptr %l33, !tbaa !29
  store i64 0, ptr %l34, !tbaa !24
  br label %bb94
bb94:
  store %olang.scope zeroinitializer, ptr %s18
  %t438 = load ptr, ptr %l33, !tbaa !29
  %t439 = load i64, ptr %l34, !tbaa !24
  %t442 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2eRunFrom_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %t438, i64 %t439)
  %t443 = extractvalue { i32, { i64, ptr } } %t442, 1
  %t444 = extractvalue { i32, { i64, ptr } } %t442, 0
  store i32 %t444, ptr %l236
  %t445 = icmp ne i32 %t444, 0
  br i1 %t445, label %bb96, label %ok.446
ok.446:
  store { i64, ptr } %t443, ptr %l235
  br label %bb95
bb95:
  %t447 = load { i64, ptr }, ptr %l235, !tbaa !27
  store { i64, ptr } %t447, ptr %l232, !tbaa !27
  br label %bb100
bb96:
  %t448 = load i32, ptr %l236, !tbaa !23
  %t449 = ashr i32 %t448, 16
  %t451 = icmp eq i32 %t449, 1
  br i1 %t451, label %bb97, label %bb98
bb97:
  br label %bb99
bb98:
  call void @__olang_check_failed(ptr @olang_loc_17924e4a5a364c2_ee2f8c79d153819e)
  unreachable
bb99:
  call void @__olang_scope_close(ptr %s18)
  br label %bb115
bb100:
  %t453 = load { i64, ptr }, ptr %l232, !tbaa !27
  store { i64, ptr } %t453, ptr %l35, !tbaa !27
  %t454 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t456 = extractvalue { i64, ptr } %t454, 0
  store i64 %t456, ptr %l36, !tbaa !24
  store i64 0, ptr %l37, !tbaa !24
  br label %bb101
bb101:
  store %olang.scope zeroinitializer, ptr %s19
  %t458 = load i64, ptr %l37, !tbaa !24
  %t459 = load i64, ptr %l36, !tbaa !24
  %t462 = icmp slt i64 %t458, %t459
  %t464 = xor i1 %t462, true
  br i1 %t464, label %bb102, label %bb103
bb102:
  call void @__olang_scope_close(ptr %s19)
  br label %bb113
bb103:
  br label %bb104
bb104:
  %t466 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t466, ptr %l245, !tbaa !27
  %t467 = load i64, ptr %l37, !tbaa !24
  %t469 = getelementptr { i64, ptr }, ptr %l245, i32 0, i32 1
  %t470 = load ptr, ptr %t469, !tbaa !27
  %t471 = getelementptr %"compiler/load:Import", ptr %t470, i64 %t467
  %t472 = load %"compiler/load:Import", ptr %t471
  store %"compiler/load:Import" %t472, ptr %l38
  %t474 = getelementptr %"compiler/load:Import", ptr %l38, i32 0, i32 5
  %t475 = load i64, ptr %t474, !tbaa !24
  %t477 = icmp sge i64 %t475, 0
  br i1 %t477, label %bb105, label %bb106
bb105:
  %t479 = getelementptr %"compiler/load:Import", ptr %l38, i32 0, i32 5
  %t480 = load i64, ptr %t479, !tbaa !24
  %t482 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t483 = load ptr, ptr %t482, !tbaa !27
  %t484 = getelementptr i1, ptr %t483, i64 %t480
  %t485 = load i1, ptr %t484, !tbaa !31
  %t487 = xor i1 %t485, true
  store i1 %t487, ptr %l250, !tbaa !21
  br label %bb107
bb106:
  store i1 false, ptr %l250, !tbaa !21
  br label %bb107
bb107:
  %t489 = load i1, ptr %l250, !tbaa !21
  br i1 %t489, label %bb108, label %bb109
bb108:
  %t490 = getelementptr %"compiler/load:Import", ptr %l38, i32 0, i32 5
  %t491 = load i64, ptr %t490, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s8, ptr %l25, i64 %t491)
  br label %bb110
bb109:
  br label %bb111
bb110:
  br label %bb111
bb111:
  call void @__olang_scope_close(ptr %s19)
  br label %bb112
bb112:
  %t494 = load i64, ptr %l37, !tbaa !24
  %t496 = add i64 %t494, 1
  store i64 %t496, ptr %l37, !tbaa !24
  br label %bb101
bb113:
  %t498 = load i64, ptr %l34, !tbaa !24
  %t499 = load i64, ptr %l36, !tbaa !24
  %t502 = add i64 %t498, %t499
  store i64 %t502, ptr %l34, !tbaa !24
  call void @__olang_scope_close(ptr %s18)
  br label %bb114
bb114:
  br label %bb94
bb115:
  call void @__olang_scope_close(ptr %s14)
  br label %bb116
bb116:
  br label %bb80
bb117:
  %t504 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_210, 0
  %t505 = insertvalue { ptr, ptr } %t504, ptr null, 1
  %t508 = extractvalue { ptr, ptr } %t505, 0
  %t509 = extractvalue { ptr, ptr } %t505, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSort_3cI64_3e(ptr %s8, ptr %s8, ptr %l24, ptr %t508, ptr %t509)
  br label %bb118
bb118:
  %t510 = load ptr, ptr @__olang_prog_scope
  %t511 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t510)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t511, ptr %l263
  br label %bb119
bb119:
  %t512 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l263
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t512, ptr %l39
  %t513 = load { i64, ptr }, ptr %l7, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s8, ptr %s0, ptr %l39, { i64, ptr } %t513)
  br label %bb120
bb120:
  %t516 = load i64, ptr %l22, !tbaa !24
  %t518 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t519 = load ptr, ptr %t518, !tbaa !27
  %t520 = getelementptr { i64, ptr }, ptr %t519, i64 %t516
  %t521 = load { i64, ptr }, ptr %t520, !tbaa !37
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s8, ptr %s0, ptr %l39, { i64, ptr } %t521)
  br label %bb121
bb121:
  store ptr %l24, ptr %l40, !tbaa !29
  store i64 0, ptr %l41, !tbaa !24
  br label %bb122
bb122:
  store %olang.scope zeroinitializer, ptr %s23
  %t525 = load ptr, ptr %l40, !tbaa !29
  %t526 = load i64, ptr %l41, !tbaa !24
  %t529 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %s8, ptr %t525, i64 %t526)
  %t530 = extractvalue { i32, { i64, ptr } } %t529, 1
  %t531 = extractvalue { i32, { i64, ptr } } %t529, 0
  store i32 %t531, ptr %l274
  %t532 = icmp ne i32 %t531, 0
  br i1 %t532, label %bb124, label %ok.533
ok.533:
  store { i64, ptr } %t530, ptr %l273
  br label %bb123
bb123:
  %t534 = load { i64, ptr }, ptr %l273, !tbaa !27
  store { i64, ptr } %t534, ptr %l270, !tbaa !27
  br label %bb128
bb124:
  %t535 = load i32, ptr %l274, !tbaa !23
  %t536 = ashr i32 %t535, 16
  %t538 = icmp eq i32 %t536, 1
  br i1 %t538, label %bb125, label %bb126
bb125:
  br label %bb127
bb126:
  call void @__olang_check_failed(ptr @olang_loc_3d75cb007153ac43_568e8d111effec1f)
  unreachable
bb127:
  call void @__olang_scope_close(ptr %s23)
  br label %bb138
bb128:
  %t540 = load { i64, ptr }, ptr %l270, !tbaa !27
  store { i64, ptr } %t540, ptr %l42, !tbaa !27
  %t541 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t543 = extractvalue { i64, ptr } %t541, 0
  store i64 %t543, ptr %l43, !tbaa !24
  store i64 0, ptr %l44, !tbaa !24
  br label %bb129
bb129:
  store %olang.scope zeroinitializer, ptr %s24
  %t545 = load i64, ptr %l44, !tbaa !24
  %t546 = load i64, ptr %l43, !tbaa !24
  %t549 = icmp slt i64 %t545, %t546
  %t551 = xor i1 %t549, true
  br i1 %t551, label %bb130, label %bb131
bb130:
  call void @__olang_scope_close(ptr %s24)
  br label %bb136
bb131:
  br label %bb132
bb132:
  %t553 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t553, ptr %l283, !tbaa !27
  %t554 = load i64, ptr %l44, !tbaa !24
  %t556 = getelementptr { i64, ptr }, ptr %l283, i32 0, i32 1
  %t557 = load ptr, ptr %t556, !tbaa !27
  %t558 = getelementptr i64, ptr %t557, i64 %t554
  %t559 = load i64, ptr %t558, !tbaa !34
  store i64 %t559, ptr %l45, !tbaa !24
  store ptr %l39, ptr %l286, !tbaa !29
  %t561 = load i64, ptr %l45, !tbaa !24
  %t564 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %l3, i64 %t561)
  store ptr %t564, ptr %l289
  br label %bb133
bb133:
  %t565 = load ptr, ptr %l289, !tbaa !29
  %t567 = getelementptr %"compiler/load:Module", ptr %t565, i32 0, i32 2
  %t568 = load { i64, ptr }, ptr %t567, !tbaa !27
  %t569 = load i64, ptr %l45, !tbaa !24
  %t571 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t572 = load ptr, ptr %t571, !tbaa !27
  %t573 = getelementptr { i64, ptr }, ptr %t572, i64 %t569
  %t574 = load { i64, ptr }, ptr %t573, !tbaa !37
  %t576 = extractvalue { i64, ptr } %t568, 1
  %t577 = extractvalue { i64, ptr } %t568, 0
  %t578 = extractvalue { i64, ptr } { i64 1, ptr @.d211 }, 1
  %t579 = extractvalue { i64, ptr } { i64 1, ptr @.d211 }, 0
  %t580 = add i64 %t577, %t579
  %t582 = extractvalue { i64, ptr } %t574, 1
  %t583 = extractvalue { i64, ptr } %t574, 0
  %t584 = add i64 %t580, %t583
  %t585 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t584)
  call void @olang_textcopy(ptr %t585, ptr %t576, i64 %t577)
  %t586 = getelementptr i8, ptr %t585, i64 %t577
  call void @olang_textcopy(ptr %t586, ptr %t578, i64 %t579)
  %t587 = getelementptr i8, ptr %t586, i64 %t579
  call void @olang_textcopy(ptr %t587, ptr %t582, i64 %t583)
  %t588 = insertvalue { i64, ptr } undef, i64 %t584, 0
  %t589 = insertvalue { i64, ptr } %t588, ptr %t585, 1
  %t591 = extractvalue { i64, ptr } %t589, 0
  %t592 = extractvalue { i64, ptr } %t589, 1
  %t593 = mul i64 %t591, 1
  %t594 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t593)
  call void @llvm.memcpy.p0.p0.i64(ptr %t594, ptr %t592, i64 %t593, i1 false)
  %t595 = insertvalue { i64, ptr } undef, i64 %t591, 0
  %t596 = insertvalue { i64, ptr } %t595, ptr %t594, 1
  %t597 = load ptr, ptr %l286, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s8, ptr %s8, ptr %t597, { i64, ptr } %t596)
  br label %bb134
bb134:
  call void @__olang_scope_close(ptr %s24)
  br label %bb135
bb135:
  %t599 = load i64, ptr %l44, !tbaa !24
  %t601 = add i64 %t599, 1
  store i64 %t601, ptr %l44, !tbaa !24
  br label %bb129
bb136:
  %t603 = load i64, ptr %l41, !tbaa !24
  %t604 = load i64, ptr %l43, !tbaa !24
  %t607 = add i64 %t603, %t604
  store i64 %t607, ptr %l41, !tbaa !24
  call void @__olang_scope_close(ptr %s23)
  br label %bb137
bb137:
  br label %bb122
bb138:
  %t609 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t609, ptr %l301, !tbaa !27
  %t610 = load i64, ptr %l22, !tbaa !24
  store i64 %t610, ptr %l302, !tbaa !24
  %t612 = call { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %s8, ptr %v1, ptr %l39)
  store { i64, ptr } %t612, ptr %l304
  br label %bb139
bb139:
  %t613 = load { i64, ptr }, ptr %l304, !tbaa !27
  %t614 = extractvalue { i64, ptr } %t613, 0
  %t615 = extractvalue { i64, ptr } %t613, 1
  %t616 = mul i64 %t614, 1
  %t617 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t616)
  call void @llvm.memcpy.p0.p0.i64(ptr %t617, ptr %t615, i64 %t616, i1 false)
  %t618 = insertvalue { i64, ptr } undef, i64 %t614, 0
  %t619 = insertvalue { i64, ptr } %t618, ptr %t617, 1
  %t621 = load i64, ptr %l302, !tbaa !24
  %t622 = getelementptr { i64, ptr }, ptr %l301, i32 0, i32 1
  %t623 = load ptr, ptr %t622, !tbaa !27
  %t624 = getelementptr { i64, ptr }, ptr %t623, i64 %t621
  store { i64, ptr } %t619, ptr %t624, !tbaa !37
  call void @__olang_scope_close(ptr %s8)
  br label %bb140
bb140:
  %t625 = load i64, ptr %l21, !tbaa !24
  %t627 = add i64 %t625, 1
  store i64 %t627, ptr %l21, !tbaa !24
  br label %bb51
bb141:
  %t629 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t629, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2folang_2eplacement(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l7 = alloca %"compiler/scope:Scoper"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %t9 = alloca %"compiler/scope:Scoper", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 10
  %t8 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t7
  call void @compiler_2fscope_3aScoper_2ector(ptr %t9, ptr %v0, ptr %v0, ptr %v1, ptr %t4, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t8)
  call void @llvm.memmove.p0.p0.i64(ptr %l7, ptr %t9, i64 992, i1 false)
  br label %bb1
bb1:
  %t12 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 992, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t12, ptr %l7, i64 992, i1 false)
  store ptr %t12, ptr %l2, !tbaa !29
  %t14 = load ptr, ptr %l2, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr { ptr, ptr }, ptr null, i32 1
  %t17 = ptrtoint ptr %t16 to i64
  %t18 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 %t17, i64 8)
  %t19 = getelementptr { ptr, ptr }, ptr %t18, i32 0, i32 0
  store ptr %t15, ptr %t19, !tbaa !28
  call void @__olang_scope_escape(ptr %v0)
  %t21 = getelementptr { ptr, ptr }, ptr %t18, i32 0, i32 1
  store ptr %v0, ptr %t21, !tbaa !28
  %t22 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_212, 0
  %t23 = insertvalue { ptr, ptr } %t22, ptr %t18, 1
  %t26 = getelementptr %"compiler/scope:Scoper", ptr %t14, i32 0, i32 4
  store { ptr, ptr } %t23, ptr %t26
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr { ptr, ptr }, ptr null, i32 1
  %t30 = ptrtoint ptr %t29 to i64
  %t31 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 %t30, i64 8)
  %t32 = getelementptr { ptr, ptr }, ptr %t31, i32 0, i32 0
  store ptr %t28, ptr %t32, !tbaa !28
  call void @__olang_scope_escape(ptr %v0)
  %t34 = getelementptr { ptr, ptr }, ptr %t31, i32 0, i32 1
  store ptr %v0, ptr %t34, !tbaa !28
  %t35 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_213, 0
  %t36 = insertvalue { ptr, ptr } %t35, ptr %t31, 1
  %t39 = getelementptr %"compiler/scope:Scoper", ptr %t27, i32 0, i32 5
  store { ptr, ptr } %t36, ptr %t39
  %t40 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eRun(ptr %v1, ptr %t40)
  br label %bb2
bb2:
  %t42 = load ptr, ptr %l2, !tbaa !29
  %t44 = getelementptr %"compiler/scope:Scoper", ptr %t42, i32 0, i32 2
  %t45 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t44
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t45, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local i1 @compiler_2folang_2eputFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1, i32 %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l10 = alloca i32
  %l16 = alloca i32
  %l20 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t1, 1
  %t5 = extractvalue { i64, ptr } %t1, 0
  %t6 = extractvalue { i64, ptr } { i64 1, ptr @.d214 }, 1
  %t7 = extractvalue { i64, ptr } { i64 1, ptr @.d214 }, 0
  %t8 = add i64 %t5, %t7
  %t10 = sext i32 %a2 to i64
  %t11 = call i64 @__olang_fmt_i64(ptr null, i64 %t10)
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 4, ptr @.d215 }, 1
  %t14 = extractvalue { i64, ptr } { i64 4, ptr @.d215 }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t4, i64 %t5)
  %t17 = getelementptr i8, ptr %t16, i64 %t5
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  %t19 = call i64 @__olang_fmt_i64(ptr %t18, i64 %t10)
  %t20 = getelementptr i8, ptr %t18, i64 %t11
  call void @olang_textcopy(ptr %t20, ptr %t13, i64 %t14)
  %t21 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t16, 1
  store { i64, ptr } %t22, ptr %l3, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t29 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %v1, { i64, ptr } %t24, { i64, ptr } %a1)
  store i32 %t29, ptr %l10
  %t30 = icmp ne i32 %t29, 0
  br i1 %t30, label %bb2, label %ok.31
ok.31:
  br label %bb1
bb1:
  br label %bb6
bb2:
  %t32 = load i32, ptr %l10, !tbaa !23
  %t33 = ashr i32 %t32, 16
  %t35 = icmp eq i32 %t33, 1
  br i1 %t35, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_525dfa3cfb0bfb03_4e25463d9369c1cf)
  unreachable
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb6:
  %t38 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t42 = call i32 @std_2fos_2eRename(ptr %s0, ptr %v0, { i64, ptr } %t38, { i64, ptr } %t39)
  store i32 %t42, ptr %l16
  %t43 = icmp ne i32 %t42, 0
  br i1 %t43, label %bb8, label %ok.44
ok.44:
  br label %bb7
bb7:
  br label %bb18
bb8:
  %t45 = load i32, ptr %l16, !tbaa !23
  %t46 = ashr i32 %t45, 16
  %t48 = icmp eq i32 %t46, 1
  br i1 %t48, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_8e0c0d4d9d5e4982_1d0736507b33918e)
  unreachable
bb11:
  %t50 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t52 = call i32 @std_2fos_2eRemove(ptr %s0, { i64, ptr } %t50)
  store i32 %t52, ptr %l20
  %t53 = icmp ne i32 %t52, 0
  br i1 %t53, label %bb13, label %ok.54
ok.54:
  br label %bb12
bb12:
  br label %bb17
bb13:
  %t55 = load i32, ptr %l20, !tbaa !23
  %t56 = ashr i32 %t55, 16
  %t58 = icmp eq i32 %t56, 1
  br i1 %t58, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_b96489c868b59f9_7d9f173036255045)
  unreachable
bb16:
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb18:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2folang_2erecordPath(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/build:Config", ptr %a0, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l4, !tbaa !27
  %t7 = call { i64, ptr } @compiler_2fbuild_2eReadable(ptr %v1, ptr %s0, { i64, ptr } %a1)
  store { i64, ptr } %t7, ptr %l6
  br label %bb1
bb1:
  store { i64, ptr } %a2, ptr %l7, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t9, 0
  store i64 %t10, ptr %l8, !tbaa !24
  %t11 = icmp sge i64 0, 0
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = icmp sle i64 0, 20
  br i1 %t13, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @olang_loc_a5855f4dee34d57_8118d8286dddc923)
  unreachable
bb4:
  %t15 = load i64, ptr %l8, !tbaa !24
  %t16 = icmp sle i64 20, %t15
  br i1 %t16, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_a5855f4dee34d57_8118d8286dddc923)
  unreachable
bb6:
  %t18 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i8, ptr %t19, i64 0
  %t21 = sub i64 20, 0
  %t22 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t20, 1
  %t24 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t24, 1
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t27 = extractvalue { i64, ptr } { i64 5, ptr @.d216 }, 1
  %t28 = extractvalue { i64, ptr } { i64 5, ptr @.d216 }, 0
  %t29 = add i64 %t26, %t28
  %t30 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t30, 1
  %t32 = extractvalue { i64, ptr } %t30, 0
  %t33 = add i64 %t29, %t32
  %t34 = extractvalue { i64, ptr } { i64 1, ptr @.d217 }, 1
  %t35 = extractvalue { i64, ptr } { i64 1, ptr @.d217 }, 0
  %t36 = add i64 %t33, %t35
  %t38 = extractvalue { i64, ptr } %t23, 1
  %t39 = extractvalue { i64, ptr } %t23, 0
  %t40 = add i64 %t36, %t39
  %t41 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t40)
  call void @olang_textcopy(ptr %t41, ptr %t25, i64 %t26)
  %t42 = getelementptr i8, ptr %t41, i64 %t26
  call void @olang_textcopy(ptr %t42, ptr %t27, i64 %t28)
  %t43 = getelementptr i8, ptr %t42, i64 %t28
  call void @olang_textcopy(ptr %t43, ptr %t31, i64 %t32)
  %t44 = getelementptr i8, ptr %t43, i64 %t32
  call void @olang_textcopy(ptr %t44, ptr %t34, i64 %t35)
  %t45 = getelementptr i8, ptr %t44, i64 %t35
  call void @olang_textcopy(ptr %t45, ptr %t38, i64 %t39)
  %t46 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t41, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t47, ptr %rv
  br label %ret
bb7:
  call void @__olang_check_failed(ptr @olang_loc_a5855f4dee34d57_8118d8286dddc923)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2folang_2ereusable(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %lp3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %lp12 = alloca ptr
  %l13 = alloca i1
  %l14 = alloca %"std/prelude/text:LineIter"
  %l15 = alloca { i64, ptr }
  %l16 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l22 = alloca i64
  %l25 = alloca i64
  %l43 = alloca { i64, ptr }
  %l46 = alloca i1
  %l47 = alloca ptr
  %l51 = alloca ptr
  %l54 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l61 = alloca i32
  %l65 = alloca %"compiler/emit:Reused"
  %l67 = alloca %"std/prelude/text:LineIter"
  %l68 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l71 = alloca i32
  %l75 = alloca i1
  %l77 = alloca i1
  %l78 = alloca i64
  %l79 = alloca { i64, ptr }
  %l82 = alloca i64
  %l83 = alloca i64
  %l87 = alloca { i64, ptr }
  %l88 = alloca i64
  %l89 = alloca i32
  %l90 = alloca i64
  %l91 = alloca i32
  %l93 = alloca i1
  %l94 = alloca { i64, ptr }
  %l97 = alloca i64
  %l98 = alloca i64
  %l103 = alloca i1
  %l105 = alloca i1
  %l106 = alloca ptr
  %l107 = alloca { i64, ptr }
  %l110 = alloca i64
  %l111 = alloca i64
  %l119 = alloca i1
  %l120 = alloca i1
  %l122 = alloca i1
  %l126 = alloca i1
  %l127 = alloca { i64, ptr }
  %l130 = alloca i1
  %l131 = alloca { i64, ptr }
  %l133 = alloca i64
  %l136 = alloca i1
  %l138 = alloca ptr
  %l139 = alloca { i64, ptr }
  %l140 = alloca i64
  %l147 = alloca ptr
  %l148 = alloca { i64, ptr }
  %l151 = alloca i64
  %l152 = alloca i64
  %l159 = alloca ptr
  %l161 = alloca i1
  %l163 = alloca i1
  %l165 = alloca i64
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aReused_3e(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l16
  br label %bb1
bb1:
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 8, i64 8)
  store ptr %t3, ptr %lp3
  %t4 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l16
  %t5 = load ptr, ptr %lp3
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %t5
  store i64 0, ptr %l4, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t10 = load i64, ptr %l5, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp sgt i64 %t10, %t11
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load i64, ptr %l6, !tbaa !24
  %t18 = icmp sgt i64 %t16, 0
  br i1 %t18, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb7
bb4:
  %t20 = load i64, ptr %l5, !tbaa !24
  %t21 = load i64, ptr %l4, !tbaa !24
  %t24 = sub i64 %t20, %t21
  %t25 = load i64, ptr %l6, !tbaa !24
  %t28 = add i64 %t24, %t25
  %t30 = sub i64 %t28, 1
  %t31 = load i64, ptr %l6, !tbaa !24
  %t34 = sdiv i64 %t30, %t31
  store i64 %t34, ptr %l25, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb6
bb6:
  %t36 = load i64, ptr %l25, !tbaa !24
  store i64 %t36, ptr %l22, !tbaa !24
  br label %bb7
bb7:
  %t37 = load i64, ptr %l22, !tbaa !24
  store i64 %t37, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t38 = load i64, ptr %l8, !tbaa !24
  %t39 = load i64, ptr %l7, !tbaa !24
  %t42 = icmp slt i64 %t38, %t39
  %t44 = xor i1 %t42, true
  br i1 %t44, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb121
bb10:
  br label %bb11
bb11:
  %t46 = load i64, ptr %l4, !tbaa !24
  %t47 = load i64, ptr %l8, !tbaa !24
  %t48 = load i64, ptr %l6, !tbaa !24
  %t51 = mul i64 %t47, %t48
  %t54 = add i64 %t46, %t51
  store i64 %t54, ptr %l9, !tbaa !24
  %t56 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t56, ptr %l43, !tbaa !27
  %t57 = load i64, ptr %l9, !tbaa !24
  %t59 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr { i64, ptr }, ptr %t60, i64 %t57
  %t62 = load { i64, ptr }, ptr %t61, !tbaa !37
  %t64 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s2, { i64, ptr } %t62, { i64, ptr } { i64 0, ptr @.d218 })
  store i1 %t64, ptr %l46
  br label %bb12
bb12:
  %t65 = load i1, ptr %l46, !tbaa !21
  br i1 %t65, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb120
bb14:
  br label %bb15
bb15:
  store ptr %a1, ptr %l47, !tbaa !29
  %t69 = getelementptr %"compiler/load:Loader", ptr %a0, i32 0, i32 5
  %t70 = load i64, ptr %l9, !tbaa !24
  %t73 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t69, i64 %t70)
  store ptr %t73, ptr %l51
  br label %bb16
bb16:
  %t74 = load ptr, ptr %l51, !tbaa !29
  %t76 = getelementptr %"compiler/load:Module", ptr %t74, i32 0, i32 2
  %t77 = load { i64, ptr }, ptr %t76, !tbaa !27
  %t78 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t78, ptr %l54, !tbaa !27
  %t79 = load i64, ptr %l9, !tbaa !24
  %t81 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr { i64, ptr }, ptr %t82, i64 %t79
  %t84 = load { i64, ptr }, ptr %t83, !tbaa !37
  %t85 = load ptr, ptr %l47, !tbaa !29
  %t88 = call { i64, ptr } @compiler_2folang_2erecordPath(ptr %v1, ptr %v0, ptr %v2, ptr %s2, ptr %t85, { i64, ptr } %t77, { i64, ptr } %t84)
  store { i64, ptr } %t88, ptr %l57
  br label %bb17
bb17:
  %t89 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t89, ptr %l10, !tbaa !27
  %t90 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t92 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s2, ptr %s2, { i64, ptr } %t90)
  %t93 = extractvalue { i32, { i64, ptr } } %t92, 1
  %t94 = extractvalue { i32, { i64, ptr } } %t92, 0
  store i32 %t94, ptr %l61
  %t95 = icmp ne i32 %t94, 0
  br i1 %t95, label %bb19, label %ok.96
ok.96:
  store { i64, ptr } %t93, ptr %l60
  br label %bb18
bb18:
  %t97 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t97, ptr %l58, !tbaa !27
  br label %bb23
bb19:
  %t98 = load i32, ptr %l61, !tbaa !23
  %t99 = ashr i32 %t98, 16
  %t101 = icmp eq i32 %t99, 1
  br i1 %t101, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_ab41c76c9764eb19_14bd85dfef8a6745)
  unreachable
bb22:
  call void @__olang_scope_close(ptr %s2)
  br label %bb120
bb23:
  %t103 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t103, ptr %l11, !tbaa !27
  %t104 = load i64, ptr %l9, !tbaa !24
  %t106 = call %"compiler/emit:Reused" @compiler_2femit_3aReused_2ector(ptr %v3, i64 %t104)
  store %"compiler/emit:Reused" %t106, ptr %l65
  br label %bb24
bb24:
  %t107 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 64, i64 8)
  store ptr %t107, ptr %lp12
  %t108 = load %"compiler/emit:Reused", ptr %l65
  %t109 = load ptr, ptr %lp12
  store %"compiler/emit:Reused" %t108, ptr %t109
  store i1 false, ptr %l13, !tbaa !21
  %t110 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t112 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %s2, ptr %s2, { i64, ptr } %t110)
  store %"std/prelude/text:LineIter" %t112, ptr %l67
  br label %bb25
bb25:
  %t113 = load %"std/prelude/text:LineIter", ptr %l67
  store %"std/prelude/text:LineIter" %t113, ptr %l14
  br label %bb26
bb26:
  store %olang.scope zeroinitializer, ptr %s6
  %t115 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %s2, ptr %l14)
  %t116 = extractvalue { i32, { i64, ptr } } %t115, 1
  %t117 = extractvalue { i32, { i64, ptr } } %t115, 0
  store i32 %t117, ptr %l71
  %t118 = icmp ne i32 %t117, 0
  br i1 %t118, label %bb28, label %ok.119
ok.119:
  store { i64, ptr } %t116, ptr %l70
  br label %bb27
bb27:
  %t120 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t120, ptr %l68, !tbaa !27
  br label %bb32
bb28:
  %t121 = load i32, ptr %l71, !tbaa !23
  %t122 = ashr i32 %t121, 16
  %t124 = icmp eq i32 %t122, 1
  br i1 %t124, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_d540fbb856ad9648_e6cd81c31b943694)
  unreachable
bb31:
  call void @__olang_scope_close(ptr %s6)
  br label %bb111
bb32:
  %t126 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t126, ptr %l15, !tbaa !27
  %t127 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t129 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s6, { i64, ptr } %t127, { i64, ptr } { i64 3, ptr @.d219 })
  store i1 %t129, ptr %l75
  br label %bb33
bb33:
  %t130 = load i1, ptr %l75, !tbaa !21
  br i1 %t130, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb109
bb35:
  store %olang.scope zeroinitializer, ptr %s8
  %t131 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t133 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s2, ptr %s8, { i64, ptr } %t131, { i64, ptr } { i64 5, ptr @.d220 })
  store i1 %t133, ptr %l77
  br label %bb36
bb36:
  %t134 = load i1, ptr %l77, !tbaa !21
  br i1 %t134, label %bb37, label %bb38
bb37:
  store %olang.scope zeroinitializer, ptr %s9
  %t135 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t135, ptr %l79, !tbaa !27
  %t136 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t139 = extractvalue { i64, ptr } %t136, 0
  store i64 %t139, ptr %l82, !tbaa !24
  %t140 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t141 = extractvalue { i64, ptr } %t140, 0
  store i64 %t141, ptr %l83, !tbaa !24
  %t142 = icmp sge i64 5, 0
  br i1 %t142, label %bb39, label %bb40
bb38:
  store %olang.scope zeroinitializer, ptr %s10
  %t144 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t146 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s2, ptr %s10, { i64, ptr } %t144, { i64, ptr } { i64 6, ptr @.d221 })
  store i1 %t146, ptr %l93
  br label %bb51
bb39:
  %t147 = load i64, ptr %l82, !tbaa !24
  %t148 = icmp sle i64 5, %t147
  br i1 %t148, label %bb41, label %bb42
bb40:
  call void @__olang_check_failed(ptr @olang_loc_30bb4d1d04b77ae4_b48bc1201be9b2a0)
  unreachable
bb41:
  %t150 = load i64, ptr %l82, !tbaa !24
  %t151 = load i64, ptr %l83, !tbaa !24
  %t152 = icmp sle i64 %t150, %t151
  br i1 %t152, label %bb43, label %bb44
bb42:
  call void @__olang_check_failed(ptr @olang_loc_30bb4d1d04b77ae4_b48bc1201be9b2a0)
  unreachable
bb43:
  %t154 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !27
  %t156 = load i64, ptr %l82, !tbaa !24
  %t157 = getelementptr i8, ptr %t155, i64 5
  %t158 = sub i64 %t156, 5
  %t159 = insertvalue { i64, ptr } undef, i64 %t158, 0
  %t160 = insertvalue { i64, ptr } %t159, ptr %t157, 1
  store { i64, ptr } %t160, ptr %l87, !tbaa !27
  %t161 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s9, i64 10)
  %t162 = extractvalue { i32, i64 } %t161, 1
  %t163 = extractvalue { i32, i64 } %t161, 0
  store i32 %t163, ptr %l89
  %t164 = icmp ne i32 %t163, 0
  br i1 %t164, label %bb46, label %ok.165
ok.165:
  store i64 %t162, ptr %l88
  br label %bb45
bb44:
  call void @__olang_check_failed(ptr @olang_loc_30bb4d1d04b77ae4_b48bc1201be9b2a0)
  unreachable
bb45:
  %t166 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t167 = load i64, ptr %l88, !tbaa !24
  %t168 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s2, { i64, ptr } %t166, i64 %t167)
  %t169 = extractvalue { i32, i64 } %t168, 1
  %t170 = extractvalue { i32, i64 } %t168, 0
  store i32 %t170, ptr %l91
  %t171 = icmp ne i32 %t170, 0
  br i1 %t171, label %bb49, label %ok.172
ok.172:
  store i64 %t169, ptr %l90
  br label %bb48
bb46:
  br label %bb47
bb47:
  store i64 0, ptr %l78, !tbaa !24
  br label %bb50
bb48:
  %t173 = load i64, ptr %l90, !tbaa !24
  store i64 %t173, ptr %l78, !tbaa !24
  br label %bb50
bb49:
  br label %bb47
bb50:
  %t174 = load i64, ptr %l78, !tbaa !24
  %t175 = load ptr, ptr %lp12
  %t176 = getelementptr %"compiler/emit:Reused", ptr %t175, i32 0, i32 4
  store i64 %t174, ptr %t176, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  br label %bb108
bb51:
  %t177 = load i1, ptr %l93, !tbaa !21
  br i1 %t177, label %bb52, label %bb53
bb52:
  store %olang.scope zeroinitializer, ptr %s11
  %t178 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t178, ptr %l94, !tbaa !27
  %t179 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t182 = extractvalue { i64, ptr } %t179, 0
  store i64 %t182, ptr %l97, !tbaa !24
  %t183 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t184 = extractvalue { i64, ptr } %t183, 0
  store i64 %t184, ptr %l98, !tbaa !24
  %t185 = icmp sge i64 6, 0
  br i1 %t185, label %bb54, label %bb55
bb53:
  store %olang.scope zeroinitializer, ptr %s12
  %t187 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t189 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s2, ptr %s12, { i64, ptr } %t187, { i64, ptr } { i64 5, ptr @.d222 })
  store i1 %t189, ptr %l105
  br label %bb61
bb54:
  %t190 = load i64, ptr %l97, !tbaa !24
  %t191 = icmp sle i64 6, %t190
  br i1 %t191, label %bb56, label %bb57
bb55:
  call void @__olang_check_failed(ptr @olang_loc_e09c8d310c475dd1_b9a5b78f48e38cfd)
  unreachable
bb56:
  %t193 = load i64, ptr %l97, !tbaa !24
  %t194 = load i64, ptr %l98, !tbaa !24
  %t195 = icmp sle i64 %t193, %t194
  br i1 %t195, label %bb58, label %bb59
bb57:
  call void @__olang_check_failed(ptr @olang_loc_e09c8d310c475dd1_b9a5b78f48e38cfd)
  unreachable
bb58:
  %t197 = getelementptr { i64, ptr }, ptr %l94, i32 0, i32 1
  %t198 = load ptr, ptr %t197, !tbaa !27
  %t199 = load i64, ptr %l97, !tbaa !24
  %t200 = getelementptr i8, ptr %t198, i64 6
  %t201 = sub i64 %t199, 6
  %t202 = insertvalue { i64, ptr } undef, i64 %t201, 0
  %t203 = insertvalue { i64, ptr } %t202, ptr %t200, 1
  %t205 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s11, { i64, ptr } %t203, { i64, ptr } { i64 1, ptr @.d223 })
  store i1 %t205, ptr %l103
  br label %bb60
bb59:
  call void @__olang_check_failed(ptr @olang_loc_e09c8d310c475dd1_b9a5b78f48e38cfd)
  unreachable
bb60:
  %t206 = load i1, ptr %l103, !tbaa !21
  %t207 = load ptr, ptr %lp12
  %t208 = getelementptr %"compiler/emit:Reused", ptr %t207, i32 0, i32 5
  store i1 %t206, ptr %t208, !tbaa !21
  call void @__olang_scope_close(ptr %s11)
  br label %bb107
bb61:
  %t209 = load i1, ptr %l105, !tbaa !21
  br i1 %t209, label %bb62, label %bb63
bb62:
  %t210 = load ptr, ptr %lp12
  %t211 = getelementptr %"compiler/emit:Reused", ptr %t210, i32 0, i32 6
  store ptr %t211, ptr %l106, !tbaa !29
  %t212 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t212, ptr %l107, !tbaa !27
  %t213 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t216 = extractvalue { i64, ptr } %t213, 0
  store i64 %t216, ptr %l110, !tbaa !24
  %t217 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t218 = extractvalue { i64, ptr } %t217, 0
  store i64 %t218, ptr %l111, !tbaa !24
  %t219 = icmp sge i64 5, 0
  br i1 %t219, label %bb64, label %bb65
bb63:
  store %olang.scope zeroinitializer, ptr %s15
  %t221 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t223 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s2, ptr %s15, { i64, ptr } %t221, { i64, ptr } { i64 5, ptr @.d224 })
  store i1 %t223, ptr %l119
  br label %bb71
bb64:
  %t224 = load i64, ptr %l110, !tbaa !24
  %t225 = icmp sle i64 5, %t224
  br i1 %t225, label %bb66, label %bb67
bb65:
  call void @__olang_check_failed(ptr @olang_loc_b7226a2473daafee_95f7e6f063520982)
  unreachable
bb66:
  %t227 = load i64, ptr %l110, !tbaa !24
  %t228 = load i64, ptr %l111, !tbaa !24
  %t229 = icmp sle i64 %t227, %t228
  br i1 %t229, label %bb68, label %bb69
bb67:
  call void @__olang_check_failed(ptr @olang_loc_b7226a2473daafee_95f7e6f063520982)
  unreachable
bb68:
  %t231 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t232 = load ptr, ptr %t231, !tbaa !27
  %t233 = load i64, ptr %l110, !tbaa !24
  %t234 = getelementptr i8, ptr %t232, i64 5
  %t235 = sub i64 %t233, 5
  %t236 = insertvalue { i64, ptr } undef, i64 %t235, 0
  %t237 = insertvalue { i64, ptr } %t236, ptr %t234, 1
  %t239 = extractvalue { i64, ptr } %t237, 1
  %t240 = extractvalue { i64, ptr } %t237, 0
  %t241 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t240)
  call void @olang_textcopy(ptr %t241, ptr %t239, i64 %t240)
  %t242 = insertvalue { i64, ptr } undef, i64 %t240, 0
  %t243 = insertvalue { i64, ptr } %t242, ptr %t241, 1
  %t245 = extractvalue { i64, ptr } %t243, 0
  %t246 = extractvalue { i64, ptr } %t243, 1
  %t247 = mul i64 %t245, 1
  %t248 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t247)
  call void @llvm.memcpy.p0.p0.i64(ptr %t248, ptr %t246, i64 %t247, i1 false)
  %t249 = insertvalue { i64, ptr } undef, i64 %t245, 0
  %t250 = insertvalue { i64, ptr } %t249, ptr %t248, 1
  %t251 = load ptr, ptr %l106, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v3, ptr %v3, ptr %t251, { i64, ptr } %t250)
  br label %bb70
bb69:
  call void @__olang_check_failed(ptr @olang_loc_b7226a2473daafee_95f7e6f063520982)
  unreachable
bb70:
  br label %bb106
bb71:
  %t253 = load i1, ptr %l119, !tbaa !21
  br i1 %t253, label %bb72, label %bb73
bb72:
  store i1 true, ptr %l120, !tbaa !21
  br label %bb75
bb73:
  %t254 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t256 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s2, ptr %s15, { i64, ptr } %t254, { i64, ptr } { i64 5, ptr @.d225 })
  store i1 %t256, ptr %l122
  br label %bb74
bb74:
  %t257 = load i1, ptr %l122, !tbaa !21
  store i1 %t257, ptr %l120, !tbaa !21
  br label %bb75
bb75:
  %t258 = load i1, ptr %l120, !tbaa !21
  br i1 %t258, label %bb76, label %bb77
bb76:
  store %olang.scope zeroinitializer, ptr %s16
  %t259 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t261 = extractvalue { i64, ptr } %t259, 0
  %t263 = icmp slt i64 %t261, 71
  br i1 %t263, label %bb78, label %bb79
bb77:
  br label %bb105
bb78:
  store i1 true, ptr %l126, !tbaa !21
  br label %bb80
bb79:
  %t265 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t265, ptr %l127, !tbaa !27
  %t266 = getelementptr { i64, ptr }, ptr %l127, i32 0, i32 1
  %t267 = load ptr, ptr %t266, !tbaa !27
  %t268 = getelementptr i8, ptr %t267, i64 69
  %t269 = load i8, ptr %t268, !tbaa !32
  %t271 = icmp ne i8 %t269, 32
  store i1 %t271, ptr %l126, !tbaa !21
  br label %bb80
bb80:
  %t273 = load i1, ptr %l126, !tbaa !21
  br i1 %t273, label %bb81, label %bb82
bb81:
  store i1 true, ptr %l130, !tbaa !21
  br label %bb85
bb82:
  %t274 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t274, ptr %l131, !tbaa !27
  %t275 = load ptr, ptr %lp12
  %t276 = getelementptr %"compiler/emit:Reused", ptr %t275, i32 0, i32 1
  %t278 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v3, ptr %t276)
  store i64 %t278, ptr %l133
  br label %bb83
bb83:
  %t279 = load { i64, ptr }, ptr %l131, !tbaa !27
  %t280 = extractvalue { i64, ptr } %t279, 1
  %t281 = extractvalue { i64, ptr } %t279, 0
  %t282 = extractvalue { i64, ptr } { i64 2, ptr @.d226 }, 1
  %t283 = extractvalue { i64, ptr } { i64 2, ptr @.d226 }, 0
  %t284 = add i64 %t281, %t283
  %t285 = load i64, ptr %l133, !tbaa !24
  %t286 = call i64 @__olang_fmt_i64(ptr null, i64 %t285)
  %t287 = add i64 %t284, %t286
  %t288 = extractvalue { i64, ptr } { i64 3, ptr @.d227 }, 1
  %t289 = extractvalue { i64, ptr } { i64 3, ptr @.d227 }, 0
  %t290 = add i64 %t287, %t289
  %t291 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t290)
  call void @olang_textcopy(ptr %t291, ptr %t280, i64 %t281)
  %t292 = getelementptr i8, ptr %t291, i64 %t281
  call void @olang_textcopy(ptr %t292, ptr %t282, i64 %t283)
  %t293 = getelementptr i8, ptr %t292, i64 %t283
  %t294 = call i64 @__olang_fmt_i64(ptr %t293, i64 %t285)
  %t295 = getelementptr i8, ptr %t293, i64 %t286
  call void @olang_textcopy(ptr %t295, ptr %t288, i64 %t289)
  %t296 = insertvalue { i64, ptr } undef, i64 %t290, 0
  %t297 = insertvalue { i64, ptr } %t296, ptr %t291, 1
  %t299 = extractvalue { i64, ptr } %t297, 0
  %t300 = extractvalue { i64, ptr } %t297, 1
  %t301 = mul i64 %t299, 1
  %t302 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t301)
  call void @llvm.memcpy.p0.p0.i64(ptr %t302, ptr %t300, i64 %t301, i1 false)
  %t303 = insertvalue { i64, ptr } undef, i64 %t299, 0
  %t304 = insertvalue { i64, ptr } %t303, ptr %t302, 1
  %t306 = call i1 @std_2fos_2eExists(ptr %s16, { i64, ptr } %t304)
  store i1 %t306, ptr %l136
  br label %bb84
bb84:
  %t307 = load i1, ptr %l136, !tbaa !21
  %t308 = xor i1 %t307, true
  store i1 %t308, ptr %l130, !tbaa !21
  br label %bb85
bb85:
  %t310 = load i1, ptr %l130, !tbaa !21
  br i1 %t310, label %bb86, label %bb87
bb86:
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s6)
  br label %bb111
bb87:
  br label %bb88
bb88:
  %t311 = load ptr, ptr %lp12
  %t312 = getelementptr %"compiler/emit:Reused", ptr %t311, i32 0, i32 3
  store ptr %t312, ptr %l138, !tbaa !29
  %t313 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t313, ptr %l139, !tbaa !27
  %t314 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t315 = extractvalue { i64, ptr } %t314, 0
  store i64 %t315, ptr %l140, !tbaa !24
  %t316 = icmp sge i64 5, 0
  br i1 %t316, label %bb89, label %bb90
bb89:
  %t318 = icmp sle i64 5, 69
  br i1 %t318, label %bb91, label %bb92
bb90:
  call void @__olang_check_failed(ptr @olang_loc_8b5a25ea6dff5deb_e266ef1e1aa7167f)
  unreachable
bb91:
  %t320 = load i64, ptr %l140, !tbaa !24
  %t321 = icmp sle i64 69, %t320
  br i1 %t321, label %bb93, label %bb94
bb92:
  call void @__olang_check_failed(ptr @olang_loc_8b5a25ea6dff5deb_e266ef1e1aa7167f)
  unreachable
bb93:
  %t323 = getelementptr { i64, ptr }, ptr %l139, i32 0, i32 1
  %t324 = load ptr, ptr %t323, !tbaa !27
  %t325 = getelementptr i8, ptr %t324, i64 5
  %t326 = sub i64 69, 5
  %t327 = insertvalue { i64, ptr } undef, i64 %t326, 0
  %t328 = insertvalue { i64, ptr } %t327, ptr %t325, 1
  %t330 = extractvalue { i64, ptr } %t328, 1
  %t331 = extractvalue { i64, ptr } %t328, 0
  %t332 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t331)
  call void @olang_textcopy(ptr %t332, ptr %t330, i64 %t331)
  %t333 = insertvalue { i64, ptr } undef, i64 %t331, 0
  %t334 = insertvalue { i64, ptr } %t333, ptr %t332, 1
  %t336 = extractvalue { i64, ptr } %t334, 0
  %t337 = extractvalue { i64, ptr } %t334, 1
  %t338 = mul i64 %t336, 1
  %t339 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t338)
  call void @llvm.memcpy.p0.p0.i64(ptr %t339, ptr %t337, i64 %t338, i1 false)
  %t340 = insertvalue { i64, ptr } undef, i64 %t336, 0
  %t341 = insertvalue { i64, ptr } %t340, ptr %t339, 1
  %t342 = load ptr, ptr %l138, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v3, ptr %v3, ptr %t342, { i64, ptr } %t341)
  br label %bb95
bb94:
  call void @__olang_check_failed(ptr @olang_loc_8b5a25ea6dff5deb_e266ef1e1aa7167f)
  unreachable
bb95:
  %t344 = load ptr, ptr %lp12
  %t345 = getelementptr %"compiler/emit:Reused", ptr %t344, i32 0, i32 1
  store ptr %t345, ptr %l147, !tbaa !29
  %t346 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t346, ptr %l148, !tbaa !27
  %t347 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t350 = extractvalue { i64, ptr } %t347, 0
  store i64 %t350, ptr %l151, !tbaa !24
  %t351 = load { i64, ptr }, ptr %l148, !tbaa !27
  %t352 = extractvalue { i64, ptr } %t351, 0
  store i64 %t352, ptr %l152, !tbaa !24
  %t353 = icmp sge i64 70, 0
  br i1 %t353, label %bb96, label %bb97
bb96:
  %t355 = load i64, ptr %l151, !tbaa !24
  %t356 = icmp sle i64 70, %t355
  br i1 %t356, label %bb98, label %bb99
bb97:
  call void @__olang_check_failed(ptr @olang_loc_ba89f34926a12070_1be1301c9cbce214)
  unreachable
bb98:
  %t358 = load i64, ptr %l151, !tbaa !24
  %t359 = load i64, ptr %l152, !tbaa !24
  %t360 = icmp sle i64 %t358, %t359
  br i1 %t360, label %bb100, label %bb101
bb99:
  call void @__olang_check_failed(ptr @olang_loc_ba89f34926a12070_1be1301c9cbce214)
  unreachable
bb100:
  %t362 = getelementptr { i64, ptr }, ptr %l148, i32 0, i32 1
  %t363 = load ptr, ptr %t362, !tbaa !27
  %t364 = load i64, ptr %l151, !tbaa !24
  %t365 = getelementptr i8, ptr %t363, i64 70
  %t366 = sub i64 %t364, 70
  %t367 = insertvalue { i64, ptr } undef, i64 %t366, 0
  %t368 = insertvalue { i64, ptr } %t367, ptr %t365, 1
  %t370 = extractvalue { i64, ptr } %t368, 1
  %t371 = extractvalue { i64, ptr } %t368, 0
  %t372 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t371)
  call void @olang_textcopy(ptr %t372, ptr %t370, i64 %t371)
  %t373 = insertvalue { i64, ptr } undef, i64 %t371, 0
  %t374 = insertvalue { i64, ptr } %t373, ptr %t372, 1
  %t376 = extractvalue { i64, ptr } %t374, 0
  %t377 = extractvalue { i64, ptr } %t374, 1
  %t378 = mul i64 %t376, 1
  %t379 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t378)
  call void @llvm.memcpy.p0.p0.i64(ptr %t379, ptr %t377, i64 %t378, i1 false)
  %t380 = insertvalue { i64, ptr } undef, i64 %t376, 0
  %t381 = insertvalue { i64, ptr } %t380, ptr %t379, 1
  %t382 = load ptr, ptr %l147, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v3, ptr %v3, ptr %t382, { i64, ptr } %t381)
  br label %bb102
bb101:
  call void @__olang_check_failed(ptr @olang_loc_ba89f34926a12070_1be1301c9cbce214)
  unreachable
bb102:
  %t384 = load ptr, ptr %lp12
  %t385 = getelementptr %"compiler/emit:Reused", ptr %t384, i32 0, i32 2
  store ptr %t385, ptr %l159, !tbaa !29
  %t386 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t388 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s2, ptr %s16, { i64, ptr } %t386, { i64, ptr } { i64 5, ptr @.d228 })
  store i1 %t388, ptr %l161
  br label %bb103
bb103:
  %t389 = load ptr, ptr %l159, !tbaa !29
  %t390 = load i1, ptr %l161, !tbaa !21
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %v3, ptr %t389, i1 %t390)
  br label %bb104
bb104:
  call void @__olang_scope_close(ptr %s16)
  br label %bb105
bb105:
  call void @__olang_scope_close(ptr %s15)
  br label %bb106
bb106:
  call void @__olang_scope_close(ptr %s12)
  br label %bb107
bb107:
  call void @__olang_scope_close(ptr %s10)
  br label %bb108
bb108:
  call void @__olang_scope_close(ptr %s8)
  br label %bb109
bb109:
  call void @__olang_scope_close(ptr %s6)
  br label %bb110
bb110:
  br label %bb26
bb111:
  %t391 = load i1, ptr %l13, !tbaa !21
  br i1 %t391, label %bb112, label %bb113
bb112:
  %t393 = load ptr, ptr %lp12
  %t394 = getelementptr %"compiler/emit:Reused", ptr %t393, i32 0, i32 1
  %t396 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v3, ptr %t394)
  store i64 %t396, ptr %l165
  br label %bb114
bb113:
  store i1 false, ptr %l163, !tbaa !21
  br label %bb115
bb114:
  %t397 = load i64, ptr %l165, !tbaa !24
  %t398 = icmp sgt i64 %t397, 0
  store i1 %t398, ptr %l163, !tbaa !21
  br label %bb115
bb115:
  %t400 = load i1, ptr %l163, !tbaa !21
  br i1 %t400, label %bb116, label %bb117
bb116:
  %t401 = load ptr, ptr %lp3
  %t402 = load ptr, ptr %lp12
  %t403 = load %"compiler/emit:Reused", ptr %t402
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aReused_3e_2ePush_3ccompiler_2femit_3aReused_3e(ptr %v3, ptr %v3, ptr %t401, %"compiler/emit:Reused" %t403)
  br label %bb118
bb117:
  br label %bb119
bb118:
  br label %bb119
bb119:
  call void @__olang_scope_close(ptr %s2)
  br label %bb120
bb120:
  %t406 = load i64, ptr %l8, !tbaa !24
  %t408 = add i64 %t406, 1
  store i64 %t408, ptr %l8, !tbaa !24
  br label %bb8
bb121:
  %t410 = load ptr, ptr %lp3
  %t411 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t410
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t411, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local i1 @compiler_2folang_2eroomFor(i64 %a0) #0 {
entry:
  %l1 = alloca [2 x i64]
  %l6 = alloca i32
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = insertvalue [2 x i64] undef, i64 0, 0
  %t2 = insertvalue [2 x i64] %t1, i64 0, 1
  store [2 x i64] %t2, ptr %l1
  %t5 = insertvalue { i64, ptr } undef, i64 2, 0
  %t6 = insertvalue { i64, ptr } %t5, ptr %l1, 1
  %t9 = extractvalue { i64, ptr } %t6, 1
  %t10 = extractvalue { i64, ptr } %t6, 0
  %t11 = call i32 @getrlimit(i32 9, ptr %t9)
  store i32 %t11, ptr %l6
  br label %bb1
bb1:
  %t12 = load i32, ptr %l6, !tbaa !23
  %t13 = icmp ne i32 %t12, 0
  br i1 %t13, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t16 = getelementptr [2 x i64], ptr %l1, i64 0, i64 0
  %t17 = load i64, ptr %t16, !tbaa !85
  %t22 = icmp ugt i64 %t17, %a0
  store i1 %t22, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2folang_2esaid(ptr %v0, ptr %a0) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l4 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v0, ptr %s0, ptr %a0)
  store { i64, ptr } %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t4, 0
  %t6 = extractvalue { i64, ptr } %t4, 1
  %t7 = mul i64 %t5, 1
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @llvm.memcpy.p0.p0.i64(ptr %t8, ptr %t6, i64 %t7, i1 false)
  %t9 = insertvalue { i64, ptr } undef, i64 %t5, 0
  %t10 = insertvalue { i64, ptr } %t9, ptr %t8, 1
  %t12 = call i32 @compiler_2folang_2ewrite(ptr %s0, { i64, ptr } %t10)
  store i32 %t12, ptr %l4
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2folang_2eusage(ptr %v0, ptr %v1, ptr %a0, %"compiler/msgs:Msg" %a1) #0 {
entry:
  %l5 = alloca i64
  %rv = alloca i32
  %t2 = alloca { i64, [3 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  store { i64, [3 x i64] } zeroinitializer, ptr %t2
  %t3 = getelementptr { i64, [3 x i64] }, ptr %t2, i32 0, i32 0
  store i64 0, ptr %t3
  %t4 = load { i64, [3 x i64] }, ptr %t2
  %t9 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %t4, %"compiler/msgs:Msg" %a1)
  store i64 %t9, ptr %l5
  br label %bb1
bb1:
  store i32 65536, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2folang_2ewrite(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l2 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i32 @std_2fio_2ePrint(ptr %v0, { i64, ptr } %a0)
  store i32 %t3, ptr %l2
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  br label %bb1
bb1:
  br label %bb6
bb2:
  %t6 = load i32, ptr %l2, !tbaa !23
  %t7 = ashr i32 %t6, 16
  %t9 = icmp eq i32 %t7, 1
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_524754f243909c7f_c56b4bf250637b8b)
  unreachable
bb5:
  store i32 1, ptr %rv
  br label %ret
bb6:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"compiler/olang:CommandLine" @compiler_2folang_3aCommandLine_2ector(ptr %v0) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i1
  %l4 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l11 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/olang:CommandLine"
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l0, !tbaa !24
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l10
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l1
  store { i64, ptr } { i64 0, ptr @.d229 }, ptr %l2, !tbaa !27
  store i1 false, ptr %l3, !tbaa !21
  %t4 = load ptr, ptr @__olang_prog_scope
  %t5 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t4)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, ptr %l11
  br label %bb2
bb2:
  %t6 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t6, ptr %l4
  %t7 = load ptr, ptr @__olang_prog_scope
  %t8 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t7)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %l12
  br label %bb3
bb3:
  %t9 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l12
  store { i64, ptr } { i64 6, ptr @.d230 }, ptr %l6, !tbaa !27
  store { i64, ptr } { i64 0, ptr @.d231 }, ptr %l7, !tbaa !27
  store { i64, ptr } { i64 0, ptr @.d232 }, ptr %l9, !tbaa !27
  %t10 = load i64, ptr %l0, !tbaa !24
  %t11 = insertvalue %"compiler/olang:CommandLine" undef, i64 %t10, 0
  %t12 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l1
  %t13 = insertvalue %"compiler/olang:CommandLine" %t11, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, 1
  %t14 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t15 = insertvalue %"compiler/olang:CommandLine" %t13, { i64, ptr } %t14, 2
  %t16 = load i1, ptr %l3, !tbaa !21
  %t17 = insertvalue %"compiler/olang:CommandLine" %t15, i1 %t16, 3
  %t18 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l4
  %t19 = insertvalue %"compiler/olang:CommandLine" %t17, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t18, 4
  %t21 = insertvalue %"compiler/olang:CommandLine" %t19, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t9, 5
  %t22 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t23 = insertvalue %"compiler/olang:CommandLine" %t21, { i64, ptr } %t22, 6
  %t24 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t25 = insertvalue %"compiler/olang:CommandLine" %t23, { i64, ptr } %t24, 7
  %t27 = insertvalue %"compiler/olang:CommandLine" %t25, i1 false, 8
  %t28 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t29 = insertvalue %"compiler/olang:CommandLine" %t27, { i64, ptr } %t28, 9
  store %"compiler/olang:CommandLine" %t29, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/olang:CommandLine", ptr %rv
  ret %"compiler/olang:CommandLine" %rr
}

define dso_local %"compiler/olang:Passes" @compiler_2folang_3aPasses_2ector(ptr %v0) #0 {
entry:
  %rv = alloca %"compiler/olang:Passes"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = insertvalue %"compiler/olang:Passes" undef, i64 0, 0
  store %"compiler/olang:Passes" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/olang:Passes", ptr %rv
  ret %"compiler/olang:Passes" %rr
}

define i32 @main(i32 %argc, ptr %argv) #0 {
entry:
  store i32 %argc, ptr @__olang_argc
  store ptr %argv, ptr @__olang_argv
  call void @__olang_thread_init()
  call void @compiler_2fbuild_2ePhaseAt_2einit()
  call void @std_2ffilepath_2elivePath_2einit()
  call void @compiler_2folang_2emain()
  ret i32 0
}

define dso_local void @olang_2einit_2ecompiler_2folang() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2folang_2eModeWords_2einit()
  br label %bb1
bb1:
  call void @compiler_2folang_2eRun_2einit()
  br label %bb2
bb2:
  call void @compiler_2folang_2eBuild_2einit()
  br label %bb3
bb3:
  call void @compiler_2folang_2eCompile_2einit()
  br label %bb4
bb4:
  call void @compiler_2folang_2eTest_2einit()
  br label %bb5
bb5:
  call void @compiler_2folang_2eInterp_2einit()
  br label %bb6
bb6:
  call void @compiler_2folang_2eFormat_2einit()
  br label %bb7
bb7:
  call void @compiler_2folang_2eExplain_2einit()
  br label %bb8
bb8:
  call void @compiler_2folang_2eHelp_2einit()
  br label %bb9
bb9:
  call void @compiler_2folang_2eDoc_2einit()
  br label %bb10
bb10:
  call void @compiler_2folang_2eLsp_2einit()
  br label %bb11
bb11:
  call void @compiler_2folang_2eMcp_2einit()
  br label %bb12
bb12:
  call void @compiler_2folang_2eFix_2einit()
  br label %bb13
bb13:
  call void @compiler_2folang_2eModeUsage_2einit()
  br label %bb14
bb14:
  call void @compiler_2folang_2eModeWhat_2einit()
  br label %bb15
bb15:
  call void @compiler_2folang_2eOptWords_2einit()
  br label %bb16
bb16:
  call void @compiler_2folang_2eOptValues_2einit()
  br label %bb17
bb17:
  call void @compiler_2folang_2eOptModes_2einit()
  br label %bb18
bb18:
  call void @compiler_2folang_2eOptWhat_2einit()
  br label %bb19
bb19:
  call void @compiler_2folang_2eexplainedSrc_2einit()
  br label %bb20
bb20:
  br label %ret
ret:
  ret void
}

@.d0 = private constant [42 x i8] c"olang [OPTION...] FILE.olang [ARGUMENT...]"
@.d1 = private constant [34 x i8] c"olang build [OPTION...] FILE.olang"
@.d2 = private constant [36 x i8] c"olang compile [OPTION...] FILE.olang"
@.d3 = private constant [36 x i8] c"olang test [OPTION...] FILE.olang..."
@.d4 = private constant [52 x i8] c"olang interpret [OPTION...] FILE.olang [ARGUMENT...]"
@.d5 = private constant [38 x i8] c"olang format [OPTION...] FILE.olang..."
@.d6 = private constant [36 x i8] c"olang explain RULE | FILE.olang NAME"
@.d7 = private constant [17 x i8] c"olang help [MODE]"
@.d8 = private constant [67 x i8] c"olang doc [OPTION...] FILE.olang [NAME] | -html DIR [FILE.olang...]"
@.d9 = private constant [21 x i8] c"olang lsp [OPTION...]"
@.d10 = private constant [21 x i8] c"olang mcp [OPTION...]"
@.d11 = private constant [39 x i8] c"olang fix [OPTION...] FILE.olang|DIR..."
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d12 = private constant [106 x i8] c"builds the program FILE.olang is the root of, as build does, and runs it with the arguments after the file"
@.d13 = private constant [64 x i8] c"builds one program, FILE.olang its root module, into build/ (B3)"
@.d14 = private constant [54 x i8] c"compiles one module to an object, linking nothing (B2)"
@.d15 = private constant [62 x i8] c"runs each file's test blocks, each file built on its own (B3a)"
@.d16 = private constant [110 x i8] c"runs the program by compile-time evaluation instead of building it, the arguments after the file its own (B3e)"
@.d17 = private constant [46 x i8] c"rewrites each file in olang's one layout (B13)"
@.d18 = private constant [93 x i8] c"prints a rule of the specification (B11a), or a top-level item as the compiler sees it (B11b)"
@.d19 = private constant [36 x i8] c"lists the modes, or a mode's options"
@.d20 = private constant [68 x i8] c"prints a module's documentation (B14), or writes a library's as HTML"
@.d21 = private constant [87 x i8] c"serves the Language Server Protocol on the standard input and output, for editors (B15)"
@.d22 = private constant [84 x i8] c"serves the Model Context Protocol on the standard input and output, for agents (B16)"
@.d23 = private constant [116 x i8] c"rewrites old code to the language of today: every migration tool of tools/, in the order the changes were made (B17)"
@.d24 = private constant [0 x i8] c""
@.d25 = private constant [5 x i8] c"build"
@.d26 = private constant [7 x i8] c"compile"
@.d27 = private constant [4 x i8] c"test"
@.d28 = private constant [9 x i8] c"interpret"
@.d29 = private constant [6 x i8] c"format"
@.d30 = private constant [7 x i8] c"explain"
@.d31 = private constant [4 x i8] c"help"
@.d32 = private constant [3 x i8] c"doc"
@.d33 = private constant [3 x i8] c"lsp"
@.d34 = private constant [3 x i8] c"mcp"
@.d35 = private constant [3 x i8] c"fix"
@.d36 = private constant [4 x i8] c"PATH"
@.d37 = private constant [0 x i8] c""
@.d38 = private constant [0 x i8] c""
@.d39 = private constant [0 x i8] c""
@.d40 = private constant [4 x i8] c"NAME"
@.d41 = private constant [10 x i8] c"Name=value"
@.d42 = private constant [0 x i8] c""
@.d43 = private constant [0 x i8] c""
@.d44 = private constant [0 x i8] c""
@.d45 = private constant [3 x i8] c"DIR"
@.d46 = private constant [49 x i8] c"writes the executable or the object to PATH (B3h)"
@.d47 = private constant [53 x i8] c"builds unoptimized, with debug information (B2c, B2e)"
@.d48 = private constant [40 x i8] c"builds with the data race detector (B2b)"
@.d49 = private constant [37 x i8] c"builds with the scope sanitizer (B2f)"
@.d50 = private constant [32 x i8] c"builds for another machine (B12)"
@.d51 = private constant [30 x i8] c"defines a build constant (B10)"
@.d52 = private constant [85 x i8] c"moves the remote repositories the build reaches to their refs' current commits (M23c)"
@.d53 = private constant [89 x i8] c"rewrites nothing: lists each file not in the layout (B13), or that fix would change (B17)"
@.d54 = private constant [96 x i8] c"builds for development: -O2 without link-time optimization, faster to build, slower to run (B2g)"
@.d55 = private constant [109 x i8] c"writes the documentation as HTML into DIR, a page a module: of each FILE, or of std where none is named (B14)"
@.d56 = private constant [7 x i8] c"-output"
@.d57 = private constant [6 x i8] c"-debug"
@.d58 = private constant [5 x i8] c"-race"
@.d59 = private constant [9 x i8] c"-sanitize"
@.d60 = private constant [7 x i8] c"-target"
@.d61 = private constant [7 x i8] c"-define"
@.d62 = private constant [7 x i8] c"-update"
@.d63 = private constant [6 x i8] c"-check"
@.d64 = private constant [6 x i8] c"-quick"
@.d65 = private constant [5 x i8] c"-html"
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d66 = private constant [1 x i8] c"-"
@.d67 = private constant [1 x i8] c"-"
@__olang_prog_scope = external thread_local(initialexec) global ptr
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d68 = private constant [0 x i8] c""
@.d69 = private constant [0 x i8] c""
@.d70 = private constant [6 x i8] c"-debug"
@.d71 = private constant [5 x i8] c"-race"
@.d72 = private constant [0 x i8] c""
@.d73 = private constant [0 x i8] c""
@.d74 = private constant [0 x i8] c""
@.d75 = private constant [13 x i8] c"OLANG_OBJECTS"
@.d76 = private constant [0 x i8] c""
@.d77 = private constant [0 x i8] c""
@.d78 = private constant [14 x i8] c"/proc/self/exe"
@.d79 = private constant [0 x i8] c""
declare void @__olang_check_failed(ptr)
@.d80 = private constant [0 x i8] c""
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d81 = private constant [0 x i8] c""
@.d82 = private constant [1 x i8] c" "
declare i64 @__olang_fmt_i64(ptr, i64)
@.d83 = private constant [1 x i8] c" "
@.d84 = private constant [1 x i8] c"\0A"
@.c85 = private unnamed_addr constant [5 x i8] c"true\00"
@.c86 = private unnamed_addr constant [6 x i8] c"false\00"
@.d87 = private constant [1 x i8] c" "
@.d88 = private constant [1 x i8] c" "
@.d89 = private constant [1 x i8] c" "
@.d90 = private constant [1 x i8] c" "
@.d91 = private constant [1 x i8] c"\0A"
@.d92 = private constant [1 x i8] c"\0A"
@.d93 = private constant [1 x i8] c"\0A"
@.d94 = private constant [1 x i8] c"\0A"
@.d95 = private constant [1 x i8] c"\0A"
@.d96 = private constant [1 x i8] c"\0A"
@.d97 = private constant [1 x i8] c"\0A"
@.d98 = private constant [8 x i8] c"TargetOs"
@.d99 = private constant [10 x i8] c"TargetArch"
@.d100 = private constant [9 x i8] c"TargetCpu"
@.d101 = private constant [16 x i8] c"TargetVectorBits"
@.d102 = private constant [12 x i8] c"TargetHasFma"
@.d103 = private constant [10 x i8] c"DebugBuild"
@.d104 = private constant [9 x i8] c"RaceBuild"
@.d105 = private constant [9 x i8] c"TestBuild"
@.d106 = private constant [1 x i8] c"/"
@.d107 = private constant [20 x i8] c"olang: reuse check: "
@.d108 = private constant [9 x i8] c" differs\0A"
@.d109 = private constant [20 x i8] c"olang: reuse check: "
@.d110 = private constant [10 x i8] c" objects, "
@.d111 = private constant [16 x i8] c" written afresh\0A"
@.d112 = private constant [20 x i8] c"olang: reuse check: "
@.d113 = private constant [39 x i8] c" modules reused, every object the same\0A"
@.d114 = private constant [5 x i8] c"start"
@.d115 = private constant [4 x i8] c"load"
@.d116 = private constant [5 x i8] c"check"
@.d117 = private constant [8 x i8] c"evaluate"
@.d118 = private constant [5 x i8] c"scope"
@.d119 = private constant [10 x i8] c"lower+emit"
@.d120 = private constant [17 x i8] c"it does not emit "
@.d121 = private constant [4 x i8] c" yet"
@.d122 = private constant [20 x i8] c": it does not lower "
@.d123 = private constant [4 x i8] c" yet"
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d124 = private constant [2 x i8] c".p"
@.d125 = private constant [3 x i8] c".ll"
@.d126 = private constant [11 x i8] c"its record "
@.d127 = private constant [27 x i8] c" was lost while it was read"
@.d128 = private constant [16 x i8] c"@__olang_dyncall"
@.d129 = private constant [0 x i8] c""
@.d130 = private constant [16 x i8] c"@__olang_dyncall"
@.d131 = private constant [16 x i8] c"OLANG_CHECKREUSE"
@.d132 = private constant [0 x i8] c""
@.d133 = private constant [0 x i8] c""
define available_externally void @__olang_scope_escape(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %un = icmp eq ptr %o, null
  br i1 %un, label %claim, label %done
claim:
  %me = load ptr, ptr @__olang_self
  store atomic ptr %me, ptr %op monotonic, align 8
  br label %done
done:
  ret void
}
define internal { i64, ptr } @olang_lambda_134(ptr %env, ptr %v0, i64 %a0) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  %cp0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  %vq0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eInstNote(ptr %vc0, ptr %v0, ptr %cv0, i64 %a0)
  store { i64, ptr } %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t6, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define internal { i64, ptr } @olang_lambda_135(ptr %env, ptr %v0, i32 %a0) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  %cp0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  %vq0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %vc0, ptr %v0, ptr %cv0, i32 %a0)
  store { i64, ptr } %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t6, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

@.d136 = private constant [0 x i8] c""
declare void @abort() noreturn
@.d137 = private constant [16 x i8] c"sanitize_thread "
@.d138 = private constant [0 x i8] c""
@.d139 = private constant [6 x i8] c".olang"
@.d140 = private constant [25 x i8] c"error MathError { ZERO }\0A"
@.d141 = private constant [43 x i8] c"type N struct(v I64, next N?&) { v, next }\0A"
@.d142 = private constant [37 x i8] c"fn (n N&) Value() I64 { return n.v }\0A"
@.d143 = private constant [26 x i8] c"type H struct(n N&) { n }\0A"
@.d144 = private constant [32 x i8] c"fn wrap(n N&) H { return H(n) }\0A"
@.d145 = private constant [37 x i8] c"fn divmod(a I64, b I64) I64, I64 ? {\0A"
@.d146 = private constant [39 x i8] c"    if b == 0 { error MathError.ZERO }\0A"
@.d147 = private constant [24 x i8] c"    return a / b, a % b\0A"
@.d148 = private constant [2 x i8] c"}\0A"
@.d149 = private constant [51 x i8] c"fn big<T>(a T, b T) T { return a if a > b else b }\0A"
@.d150 = private constant [62 x i8] c"type Sh enum {\0A    Whole N\0A    Parts(a I64, b I64)\0A    None\0A}\0A"
@.d151 = private constant [19 x i8] c"Answer I64 = 6 * 7\0A"
@.d152 = private constant [91 x i8] c"fn pct(part I64, whole I64) p I64 [whole > 0, 0 <= p <= 100] { return part * 100 / whole }\0A"
@.d153 = private constant [43 x i8] c"fn link(a mut N&, b N&) [b outlives a] { }\0A"
@.d154 = private constant [14 x i8] c"fn main() ? {\0A"
@.d155 = private constant [29 x i8] c"    nn := N(pct(1, 4), null)\0A"
@.d156 = private constant [17 x i8] c"    link(nn, nn)\0A"
@.d157 = private constant [42 x i8] c"    q, _ := try divmod(Answer, big(2, 3))\0A"
@.d158 = private constant [44 x i8] c"    assert wrap(N(q, null)).n.Value() == 14\0A"
@.d159 = private constant [2 x i8] c"}\0A"
@.d160 = private constant [2 x i8] c"-l"
@.d161 = private constant [2 x i8] c"-f"
@.d162 = private constant [96 x i8] c"usage: olang MODE [OPTION...] FILE...   or   olang [OPTION...] FILE.olang [ARGUMENT...]\0A\0Amodes:\0A"
@.d163 = private constant [10 x i8] c"FILE.olang"
@.d164 = private constant [2 x i8] c"  "
@.d165 = private constant [1 x i8] c" "
@.d166 = private constant [1 x i8] c"\0A"
@.d167 = private constant [2 x i8] c"  "
@.d168 = private constant [1 x i8] c" "
@.d169 = private constant [1 x i8] c"\0A"
@.d170 = private constant [85 x i8] c"\0A'olang help MODE' lists a mode's options; 'olang help run' those of running a file.\0A"
@.d171 = private constant [3 x i8] c"run"
@.d172 = private constant [7 x i8] c"usage: "
@.d173 = private constant [1 x i8] c"\0A"
@.d174 = private constant [1 x i8] c"\0A"
@.d175 = private constant [10 x i8] c"\0Aoptions:\0A"
@.d176 = private constant [0 x i8] c""
@.d177 = private constant [1 x i8] c" "
@.d178 = private constant [0 x i8] c""
@.d179 = private constant [2 x i8] c"  "
@.d180 = private constant [1 x i8] c" "
@.d181 = private constant [1 x i8] c"\0A"
@.d182 = private constant [4 x i8] c"/rec"
@.d183 = private constant [0 x i8] c""
@.d184 = private constant [1 x i8] c"1"
@.d185 = private constant [1 x i8] c"0"
@.d186 = private constant [25 x i8] c"olang module record\0Asize "
@.d187 = private constant [7 x i8] c"\0Asplit "
@.d188 = private constant [1 x i8] c"\0A"
define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d189 = private constant [5 x i8] c"inst "
@.d190 = private constant [1 x i8] c"\0A"
@.d191 = private constant [2 x i8] c".p"
@.d192 = private constant [3 x i8] c".ll"
@.d193 = private constant [5 x i8] c"locs "
@.d194 = private constant [5 x i8] c"part "
@.d195 = private constant [1 x i8] c" "
@.d196 = private constant [1 x i8] c"\0A"
@.d197 = private constant [4 x i8] c"end\0A"
@.d198 = private constant [97 x i8] c"olang: internal compiler error: the compiler crashed - a bug in the compiler, not in the program\0A"
define internal void @olang_lambda_199(ptr %env) #0 {
entry:
  %l2 = alloca i32
  %cp0 = getelementptr { { i64, ptr }, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load { i64, ptr }, ptr %cp0, !tbaa !28
  %vq0 = getelementptr { { i64, ptr }, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i32 @compiler_2folang_2edrive(ptr %vc0, { i64, ptr } %cv0)
  store i32 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i32, ptr %l2, !tbaa !23
  call void @std_2fos_2eExit(i32 %t4)
  unreachable
bb2:
  call void @__olang_check_failed(ptr @olang_loc_6a9437d164e18f65_777063661d50beb9)
  unreachable
ret:
  ret void
}

@.d200 = private constant [14 x i8] c"running a file"
@.d201 = private constant [5 x i8] c" and "
@.d202 = private constant [2 x i8] c", "
@.d203 = private constant [0 x i8] c""
@.d204 = private constant [0 x i8] c""
@.d205 = private constant [0 x i8] c""
@.d206 = private constant [6 x i8] c"\0Aroot "
@.d207 = private constant [1 x i8] c" "
@.d208 = private constant [0 x i8] c""
@.d209 = private constant [0 x i8] c""
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define internal i1 @olang_lambda_210(ptr %env, i64 %a0, i64 %a1) #0 {
entry:
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = icmp slt i64 %a0, %a1
  store i1 %t5, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d211 = private constant [1 x i8] c" "
define internal { i64, ptr } @olang_lambda_212(ptr %env, ptr %v0, i64 %a0) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  %cp0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  %vq0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eInstNote(ptr %vc0, ptr %v0, ptr %cv0, i64 %a0)
  store { i64, ptr } %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t6, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define internal { i64, ptr } @olang_lambda_213(ptr %env, ptr %v0, i32 %a0) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  %cp0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  %vq0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %vc0, ptr %v0, ptr %cv0, i32 %a0)
  store { i64, ptr } %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t6, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

@.d214 = private constant [1 x i8] c"."
@.d215 = private constant [4 x i8] c".tmp"
@.d216 = private constant [5 x i8] c"/rec/"
@.d217 = private constant [1 x i8] c"."
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aReused_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2femit_3aReused_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d218 = private constant [0 x i8] c""
@.d219 = private constant [3 x i8] c"end"
@.d220 = private constant [5 x i8] c"size "
@.d221 = private constant [6 x i8] c"split "
@.d222 = private constant [5 x i8] c"inst "
@.d223 = private constant [1 x i8] c"1"
@.d224 = private constant [5 x i8] c"part "
@.d225 = private constant [5 x i8] c"locs "
@.d226 = private constant [2 x i8] c".p"
@.d227 = private constant [3 x i8] c".ll"
@.d228 = private constant [5 x i8] c"locs "
declare i32 @getrlimit(i32, ptr)
@.d229 = private constant [0 x i8] c""
@.d230 = private constant [6 x i8] c"native"
@.d231 = private constant [0 x i8] c""
@.d232 = private constant [0 x i8] c""
@__olang_argc = external global i32
@__olang_argv = external global ptr
declare void @__olang_thread_init()
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@__olang_self = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
declare ptr @__olang_scope_mine_slow(ptr) noinline
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eUsage(ptr %v0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotAMode(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownFlag(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eOptionNotForMode(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eOptionNeedsValue(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eDefine(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, ptr %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eQuickAlone(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDocOneName(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eExplainNeedsRule(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eHelpOneMode(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eModeFirst(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotASource(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eExplainNeedsName(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eModeNoFiles(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eModeOneFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eModeNeedsFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2ftarget_2eFindClang(ptr %v0)
declare { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, %"compiler/target:Target" } @compiler_2ftarget_2eResolve(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, ptr %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetForeignMode(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, %"std/os:FileInfo" } @std_2fos_2eStat(ptr %v0, { i64, ptr } %a0)
@olang_loc_75a15dc32bd9c62d_7df2e713047d6551 = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fos_2eCwd(ptr %v0)
declare { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eFingerprint(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2fload_2eStdDir(ptr %v0)
declare i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eHas(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefineBuiltin(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eBuiltins(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, i64 %a4, i64 %a5, i1 %a6, i1 %a7, i1 %a8)
declare i1 @std_2fos_2eIsDir(ptr %v0, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eOutputIsDir(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_12131eae1fe55f7a_2d06b34e1c9e748e = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eOutputNoDir(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eLen_3cI64_2c_20I64_3e(ptr %v0, ptr %a0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2ecompiler_2femit_3aEmitter_2eObjects(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aObject_3e_2eLen_3ccompiler_2femit_3aObject_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2eLen_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %a0)
declare %"compiler/build:Unit" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2eAt_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/emit:Object" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aObject_3e_2eAt_3ccompiler_2femit_3aObject_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @std_2fio_2ePrintErr(ptr %v0, { i64, ptr } %a0)
@olang_loc_dd8573ae343ff812_8decdc106ea08ebe = external constant [0 x i8]
@olang_loc_1ac4aff2f4082213_2cf9008d871781bf = external constant [0 x i8]
declare void @std_2fos_2eExit(i32 %a0)
@olang_loc_32421bf44abb9df8_94a4451618780c84 = external constant [0 x i8]
@olang_loc_2cc05bc0974a48c9_c5f1014419607875 = external constant [0 x i8]
declare void @compiler_2fbuild_2ePhase(ptr %v0, { i64, ptr } %a0)
declare void @compiler_2finterp_2eAnalyze(ptr %out, ptr %v0, ptr %v1, ptr %a0, i1 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eCheckMain(ptr %v0, ptr %a0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v0, ptr %a0)
declare i64 @compiler_2finterp_2eDecideValues(ptr %v0, ptr %a0)
declare i64 @compiler_2finterp_2eDecideAsserts(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2finterp_2eBake(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHasFatal(ptr %v0, ptr %a0)
declare %"compiler/lower:Lowerer" @compiler_2flower_3aLowerer_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1)
@olang_loc_1d5612d13136b02e_cf27d9d671de6fa2 = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3aGap_3e_2eLen_3ccompiler_2flower_3aGap_3e(ptr %v0, ptr %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fbuild_2eUnbuildable(ptr %v0, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3aGap_3e_2eRunFrom_3ccompiler_2flower_3aGap_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aObject_3e_2eRunFrom_3ccompiler_2femit_3aObject_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/emit:Reused" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aReused_3e_2eAt_3ccompiler_2femit_3aReused_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/build:Unit" @compiler_2fbuild_3aUnit_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, i32 %a1, { i64, ptr } %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2ePush_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/build:Unit" %a1)
@olang_loc_5772a8514d833044_b816e84cde98ab20 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fbuild_2eIrHash(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fload_2ecompiler_2fload_3aLoader_2eLinks(ptr %v0, ptr %v1, ptr %a0)
declare { i32, { i64, ptr } } @compiler_2fruntime_2eIr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3, i1 %a4)
declare { i32, { i64, ptr } } @compiler_2fruntime_2eDyncallIr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3, i1 %a4)
declare void @compiler_2fscope_3aScoper_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eRun(ptr %v0, ptr %a0)
declare void @compiler_2finterp_3aExec_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1, i32 %a2)
declare { i32, { i64, ptr } } @compiler_2fexplain_2eItem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, i64 %a3, { i64, ptr } %a4)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eExplainNoItem(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare void @compiler_2finterp_2ecompiler_2finterp_3aExec_2ePlace(ptr %v0, ptr %a0)
@G_2ecompiler_2feval_2eInterpCrash = external constant <{ [8 x i8], ptr }>
declare void @std_2fos_2eOnCrash(ptr %v0, { i64, ptr } %a0)
declare i32 @compiler_2finterp_2ecompiler_2finterp_3aExec_2eRunMain(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_312804dbefbae76a_26e5fd70c2793cc6 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fload_2eLockPath(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2ffetch_2eCacheDir(ptr %v0)
declare { i64, ptr } @compiler_2ffetch_2eGitBase(ptr %v0)
declare %"compiler/fetch:Fetcher" @compiler_2ffetch_3aFetcher_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3, i1 %a4)
declare %"compiler/source:Names" @compiler_2fsource_3aNames_2ector(ptr %v0)
declare %"compiler/load:Loader" @compiler_2fload_3aLoader_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4)
declare i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eLoad(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v0, ptr %a0)
declare i32 @compiler_2folang_2eRunWith_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1)
declare void @compiler_2femit_3aEmitter_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, ptr %a3)
@G_2ecompiler_2fbuild_2eThinFrom = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\80\00\00\00\00\00" }>, align 8
@G_2ecompiler_2femit_2ePartSizeDev = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\08\00\00\00\00\00" }>, align 8
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fdiag_2eSpecPath(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoSpec(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @compiler_2fdiag_2eExplain(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_8c7e755ea0eb9876_6b14028370dd0cea = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eToUpper(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoRule(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hd4bdf3befe2f7a35847f168802c5df68(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2ffmt_2eFiles(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadEnd(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i8 %a2)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aReused_3e_2eLen_3ccompiler_2femit_3aReused_3e(ptr %v0, ptr %a0)
declare i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %a0)
@olang_loc_4bbc6d12b4c2aef5_61de3414d98ea881 = external constant [0 x i8]
declare i32 @compiler_2fbuild_2ePid()
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aReused_3e_2eRunFrom_3ccompiler_2femit_3aReused_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_1a6fb0e4b3da4304_63cb76792ee304f0 = external constant [0 x i8]
@olang_loc_b2c46c5c2279b83f_c4a092c9ae7cf92b = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H2b85ceff512af6e6ca26c554a1c16247(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i1 %a2)
declare { i64, ptr } @std_2fos_2eArgs(ptr %v0)
declare void @std_2fos_2eRunOnStack(ptr %v0, i64 %a0, ptr %a1c, ptr %a1e)
@olang_loc_73b8d8bbbab8f911_f56ba933d304b59d = external constant [0 x i8]
@olang_loc_73c3116820f750d_32f9964414b76079 = external constant [0 x i8]
@olang_loc_23d2168bab4aeae0_126950dc9613ccec = external constant [0 x i8]
@olang_loc_a3d985a905b98e7d_1a99d62f9ee112a1 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_32de2828e497f50e_77e9a884b57210fa = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2eRunFrom_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_17924e4a5a364c2_ee2f8c79d153819e = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSort_3cI64_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1c, ptr %a1e)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_3d75cb007153ac43_568e8d111effec1f = external constant [0 x i8]
declare i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_525dfa3cfb0bfb03_4e25463d9369c1cf = external constant [0 x i8]
declare i32 @std_2fos_2eRename(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_8e0c0d4d9d5e4982_1d0736507b33918e = external constant [0 x i8]
declare i32 @std_2fos_2eRemove(ptr %v0, { i64, ptr } %a0)
@olang_loc_b96489c868b59f9_7d9f173036255045 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fbuild_2eReadable(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_a5855f4dee34d57_8118d8286dddc923 = external constant [0 x i8]
@olang_loc_ab41c76c9764eb19_14bd85dfef8a6745 = external constant [0 x i8]
declare %"compiler/emit:Reused" @compiler_2femit_3aReused_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %a0)
@olang_loc_d540fbb856ad9648_e6cd81c31b943694 = external constant [0 x i8]
@olang_loc_30bb4d1d04b77ae4_b48bc1201be9b2a0 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %a0, i64 %a1)
@olang_loc_e09c8d310c475dd1_b9a5b78f48e38cfd = external constant [0 x i8]
@olang_loc_b7226a2473daafee_95f7e6f063520982 = external constant [0 x i8]
declare i1 @std_2fos_2eExists(ptr %v0, { i64, ptr } %a0)
@olang_loc_8b5a25ea6dff5deb_e266ef1e1aa7167f = external constant [0 x i8]
@olang_loc_ba89f34926a12070_1be1301c9cbce214 = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aReused_3e_2ePush_3ccompiler_2femit_3aReused_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/emit:Reused" %a1)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v0, ptr %v1, ptr %a0)
declare i32 @std_2fio_2ePrint(ptr %v0, { i64, ptr } %a0)
@olang_loc_524754f243909c7f_c56b4bf250637b8b = external constant [0 x i8]
declare void @compiler_2fbuild_2ePhaseAt_2einit()
declare void @std_2ffilepath_2elivePath_2einit()
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eInstNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2ector(ptr %v0)
@olang_loc_6a9437d164e18f65_777063661d50beb9 = external constant [0 x i8]
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2femit_3aReused_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
