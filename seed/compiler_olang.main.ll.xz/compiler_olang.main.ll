; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/olang:CommandLine" = type { i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, i1, { i64, ptr } }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/msgs:Nearest" = type { { i64, ptr }, { i64, ptr }, i64 }
%"compiler/build:Config" = type { { i64, ptr }, { i64, ptr }, %"compiler/target:Target", %"compiler/cond:Consts", i1, i1, i1, i1, i1, i1, { i64, ptr }, i64, i1, i1, i64, i1, i1, { i64, ptr }, { i64, ptr }, i64, i64, i1, { i64, ptr }, { i64, ptr } }
%"compiler/target:Target" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i1, i1 }
%"compiler/cond:Consts" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/os:FileInfo" = type { i32, i64, i64 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/os:Output" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/build:Unit" = type { { i64, ptr }, i32, { i64, ptr }, { i64, ptr } }
%"compiler/emit:Object" = type { { i64, ptr }, i32, { i64, ptr }, i64 }
%"compiler/emit:Emitter" = type { ptr, ptr, ptr, ptr, i1, i1, i1, i1, { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i64, i1, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, i64, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i1, { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i64, { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, i64, i64, i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/build:Program" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/check:Gap" = type { i64, %"compiler/source:Span", { i64, ptr } }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/lower:Gap" = type { i64, %"compiler/source:Span", { i64, ptr } }
%"compiler/emit:Reused" = type { i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64 }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i64, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, { i64, [3 x i64] }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i64, i64, i64, i64, i64, i64, i64, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i1, %"std/prelude/text:StringBuilder", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/lower:Lowerer" = type { ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i32, i32 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/free:Free" = type { ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, i1, i1 }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/scope:Scoper" = type { ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { ptr, ptr }, { ptr, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, i64, i1, %"compiler/typed:Plan", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, [2 x i64] }, i1, i1, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, [2 x i64] }, i1, %"compiler/source:Span", { i64, [2 x i64] }, i1, { i64, [2 x i64] }, i1, i1, i1, %"compiler/source:Span", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, [2 x i64] }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i64, { i64, [2 x i64] }, i1, i1, i1, i64, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i64, i64, i1, i32, i1, i1, i1, i1, i64, %"compiler/source:Span" }
%"compiler/typed:Plan" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/interp:Exec" = type { ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i32, %"compiler/lower:Lowerer", %"compiler/eval:Machine", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"compiler/eval:Machine" = type { ptr, i32, i64, i64, i64, i64, i64, i64, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/eval:Ptr", i32, { i64, [5 x i64] }, i1, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, i64, { i64, ptr }, { i64, ptr }, i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i64, { i64, ptr }, i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i64, i64, { i64, ptr }, i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/source:Span", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/source:Span", i32 }
%"compiler/eval:Ptr" = type { i64, i64 }
%"compiler/fetch:Fetcher" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/source:Names" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/olang:Passes" = type { i64 }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/load:Import" = type { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, { i64, ptr }, i64, i64, { i64, ptr }, %"compiler/source:Span" }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"std/prelude/text:LineIter" = type { { i64, ptr }, i64 }
%"<sys/resource.h>:rlimit" = type { i64, i64 }
@G_2ecompiler_2folang_2eBindgen = constant <{ [8 x i8] }> <{ [8 x i8] c"\0C\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eBuild = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eCompile = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eDoc = constant <{ [8 x i8] }> <{ [8 x i8] c"\08\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eExplain = constant <{ [8 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eFix = constant <{ [8 x i8] }> <{ [8 x i8] c"\0B\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eFormat = constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eHelp = constant <{ [8 x i8] }> <{ [8 x i8] c"\07\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eInterp = constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eLsp = constant <{ [8 x i8] }> <{ [8 x i8] c"\09\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eMcp = constant <{ [8 x i8] }> <{ [8 x i8] c"\0A\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eModeUsage = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\2A\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeUsage.k1, [8 x i8] c"\22\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeUsage.k2, [8 x i8] c"\24\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeUsage.k3, [8 x i8] c"\24\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeUsage.k4, [8 x i8] c"\34\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeUsage.k5, [8 x i8] c"\26\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeUsage.k6, [8 x i8] c"\24\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeUsage.k7, [8 x i8] c"\11\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeUsage.k8, [8 x i8] c"\43\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeUsage.k9, [8 x i8] c"\15\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeUsage.k10, [8 x i8] c"\15\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeUsage.k11, [8 x i8] c"\27\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeUsage.k12, [8 x i8] c"\22\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeUsage.k13 }>, align 64
@G_2ecompiler_2folang_2eModeUsage.k1 = internal constant <{ [42 x i8] }> <{ [42 x i8] c"\6F\6C\61\6E\67\20\5B\4F\50\54\49\4F\4E\2E\2E\2E\5D\20\46\49\4C\45\2E\6F\6C\61\6E\67\20\5B\41\52\47\55\4D\45\4E\54\2E\2E\2E\5D" }>, align 32
@G_2ecompiler_2folang_2eModeUsage.k2 = internal constant <{ [34 x i8] }> <{ [34 x i8] c"\6F\6C\61\6E\67\20\62\75\69\6C\64\20\5B\4F\50\54\49\4F\4E\2E\2E\2E\5D\20\46\49\4C\45\2E\6F\6C\61\6E\67" }>, align 32
@G_2ecompiler_2folang_2eModeUsage.k3 = internal constant <{ [36 x i8] }> <{ [36 x i8] c"\6F\6C\61\6E\67\20\63\6F\6D\70\69\6C\65\20\5B\4F\50\54\49\4F\4E\2E\2E\2E\5D\20\46\49\4C\45\2E\6F\6C\61\6E\67" }>, align 32
@G_2ecompiler_2folang_2eModeUsage.k4 = internal constant <{ [36 x i8] }> <{ [36 x i8] c"\6F\6C\61\6E\67\20\74\65\73\74\20\5B\4F\50\54\49\4F\4E\2E\2E\2E\5D\20\46\49\4C\45\2E\6F\6C\61\6E\67\2E\2E\2E" }>, align 32
@G_2ecompiler_2folang_2eModeUsage.k5 = internal constant <{ [52 x i8] }> <{ [52 x i8] c"\6F\6C\61\6E\67\20\69\6E\74\65\72\70\72\65\74\20\5B\4F\50\54\49\4F\4E\2E\2E\2E\5D\20\46\49\4C\45\2E\6F\6C\61\6E\67\20\5B\41\52\47\55\4D\45\4E\54\2E\2E\2E\5D" }>, align 32
@G_2ecompiler_2folang_2eModeUsage.k6 = internal constant <{ [38 x i8] }> <{ [38 x i8] c"\6F\6C\61\6E\67\20\66\6F\72\6D\61\74\20\5B\4F\50\54\49\4F\4E\2E\2E\2E\5D\20\46\49\4C\45\2E\6F\6C\61\6E\67\2E\2E\2E" }>, align 32
@G_2ecompiler_2folang_2eModeUsage.k7 = internal constant <{ [36 x i8] }> <{ [36 x i8] c"\6F\6C\61\6E\67\20\65\78\70\6C\61\69\6E\20\52\55\4C\45\20\7C\20\46\49\4C\45\2E\6F\6C\61\6E\67\20\4E\41\4D\45" }>, align 32
@G_2ecompiler_2folang_2eModeUsage.k8 = internal constant <{ [17 x i8] }> <{ [17 x i8] c"\6F\6C\61\6E\67\20\68\65\6C\70\20\5B\4D\4F\44\45\5D" }>, align 8
@G_2ecompiler_2folang_2eModeUsage.k9 = internal constant <{ [67 x i8] }> <{ [67 x i8] c"\6F\6C\61\6E\67\20\64\6F\63\20\5B\4F\50\54\49\4F\4E\2E\2E\2E\5D\20\46\49\4C\45\2E\6F\6C\61\6E\67\20\5B\4E\41\4D\45\5D\20\7C\20\2D\68\74\6D\6C\20\44\49\52\20\5B\46\49\4C\45\2E\6F\6C\61\6E\67\2E\2E\2E\5D" }>, align 64
@G_2ecompiler_2folang_2eModeUsage.k10 = internal constant <{ [21 x i8] }> <{ [21 x i8] c"\6F\6C\61\6E\67\20\6C\73\70\20\5B\4F\50\54\49\4F\4E\2E\2E\2E\5D" }>, align 8
@G_2ecompiler_2folang_2eModeUsage.k11 = internal constant <{ [21 x i8] }> <{ [21 x i8] c"\6F\6C\61\6E\67\20\6D\63\70\20\5B\4F\50\54\49\4F\4E\2E\2E\2E\5D" }>, align 8
@G_2ecompiler_2folang_2eModeUsage.k12 = internal constant <{ [39 x i8] }> <{ [39 x i8] c"\6F\6C\61\6E\67\20\66\69\78\20\5B\4F\50\54\49\4F\4E\2E\2E\2E\5D\20\46\49\4C\45\2E\6F\6C\61\6E\67\7C\44\49\52\2E\2E\2E" }>, align 32
@G_2ecompiler_2folang_2eModeUsage.k13 = internal constant <{ [34 x i8] }> <{ [34 x i8] c"\6F\6C\61\6E\67\20\62\69\6E\64\67\65\6E\20\5B\4F\50\54\49\4F\4E\2E\2E\2E\5D\20\48\45\41\44\45\52\2E\68" }>, align 32
@G_2ecompiler_2folang_2eModeWhat = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\6A\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWhat.k1, [8 x i8] c"\40\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWhat.k2, [8 x i8] c"\36\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWhat.k3, [8 x i8] c"\3E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWhat.k4, [8 x i8] c"\6E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWhat.k5, [8 x i8] c"\2E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWhat.k6, [8 x i8] c"\5D\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWhat.k7, [8 x i8] c"\24\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWhat.k8, [8 x i8] c"\44\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWhat.k9, [8 x i8] c"\57\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWhat.k10, [8 x i8] c"\54\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWhat.k11, [8 x i8] c"\74\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWhat.k12, [8 x i8] c"\4C\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWhat.k13 }>, align 64
@G_2ecompiler_2folang_2eModeWhat.k1 = internal constant <{ [106 x i8] }> <{ [106 x i8] c"\62\75\69\6C\64\73\20\74\68\65\20\70\72\6F\67\72\61\6D\20\46\49\4C\45\2E\6F\6C\61\6E\67\20\69\73\20\74\68\65\20\72\6F\6F\74\20\6F\66\2C\20\61\73\20\62\75\69\6C\64\20\64\6F\65\73\2C\20\61\6E\64\20\72\75\6E\73\20\69\74\20\77\69\74\68\20\74\68\65\20\61\72\67\75\6D\65\6E\74\73\20\61\66\74\65\72\20\74\68\65\20\66\69\6C\65" }>, align 64
@G_2ecompiler_2folang_2eModeWhat.k2 = internal constant <{ [64 x i8] }> <{ [64 x i8] c"\62\75\69\6C\64\73\20\6F\6E\65\20\70\72\6F\67\72\61\6D\2C\20\46\49\4C\45\2E\6F\6C\61\6E\67\20\69\74\73\20\72\6F\6F\74\20\6D\6F\64\75\6C\65\2C\20\69\6E\74\6F\20\62\75\69\6C\64\2F\20\28\42\33\29" }>, align 64
@G_2ecompiler_2folang_2eModeWhat.k3 = internal constant <{ [54 x i8] }> <{ [54 x i8] c"\63\6F\6D\70\69\6C\65\73\20\6F\6E\65\20\6D\6F\64\75\6C\65\20\74\6F\20\61\6E\20\6F\62\6A\65\63\74\2C\20\6C\69\6E\6B\69\6E\67\20\6E\6F\74\68\69\6E\67\20\28\42\32\29" }>, align 32
@G_2ecompiler_2folang_2eModeWhat.k4 = internal constant <{ [62 x i8] }> <{ [62 x i8] c"\72\75\6E\73\20\65\61\63\68\20\66\69\6C\65\27\73\20\74\65\73\74\20\62\6C\6F\63\6B\73\2C\20\65\61\63\68\20\66\69\6C\65\20\62\75\69\6C\74\20\6F\6E\20\69\74\73\20\6F\77\6E\20\28\42\33\61\29" }>, align 32
@G_2ecompiler_2folang_2eModeWhat.k5 = internal constant <{ [110 x i8] }> <{ [110 x i8] c"\72\75\6E\73\20\74\68\65\20\70\72\6F\67\72\61\6D\20\62\79\20\63\6F\6D\70\69\6C\65\2D\74\69\6D\65\20\65\76\61\6C\75\61\74\69\6F\6E\20\69\6E\73\74\65\61\64\20\6F\66\20\62\75\69\6C\64\69\6E\67\20\69\74\2C\20\74\68\65\20\61\72\67\75\6D\65\6E\74\73\20\61\66\74\65\72\20\74\68\65\20\66\69\6C\65\20\69\74\73\20\6F\77\6E\20\28\42\33\65\29" }>, align 64
@G_2ecompiler_2folang_2eModeWhat.k6 = internal constant <{ [46 x i8] }> <{ [46 x i8] c"\72\65\77\72\69\74\65\73\20\65\61\63\68\20\66\69\6C\65\20\69\6E\20\6F\6C\61\6E\67\27\73\20\6F\6E\65\20\6C\61\79\6F\75\74\20\28\42\31\33\29" }>, align 32
@G_2ecompiler_2folang_2eModeWhat.k7 = internal constant <{ [93 x i8] }> <{ [93 x i8] c"\70\72\69\6E\74\73\20\61\20\72\75\6C\65\20\6F\66\20\74\68\65\20\73\70\65\63\69\66\69\63\61\74\69\6F\6E\20\28\42\31\31\61\29\2C\20\6F\72\20\61\20\74\6F\70\2D\6C\65\76\65\6C\20\69\74\65\6D\20\61\73\20\74\68\65\20\63\6F\6D\70\69\6C\65\72\20\73\65\65\73\20\69\74\20\28\42\31\31\62\29" }>, align 64
@G_2ecompiler_2folang_2eModeWhat.k8 = internal constant <{ [36 x i8] }> <{ [36 x i8] c"\6C\69\73\74\73\20\74\68\65\20\6D\6F\64\65\73\2C\20\6F\72\20\61\20\6D\6F\64\65\27\73\20\6F\70\74\69\6F\6E\73" }>, align 32
@G_2ecompiler_2folang_2eModeWhat.k9 = internal constant <{ [68 x i8] }> <{ [68 x i8] c"\70\72\69\6E\74\73\20\61\20\6D\6F\64\75\6C\65\27\73\20\64\6F\63\75\6D\65\6E\74\61\74\69\6F\6E\20\28\42\31\34\29\2C\20\6F\72\20\77\72\69\74\65\73\20\61\20\6C\69\62\72\61\72\79\27\73\20\61\73\20\48\54\4D\4C" }>, align 64
@G_2ecompiler_2folang_2eModeWhat.k10 = internal constant <{ [87 x i8] }> <{ [87 x i8] c"\73\65\72\76\65\73\20\74\68\65\20\4C\61\6E\67\75\61\67\65\20\53\65\72\76\65\72\20\50\72\6F\74\6F\63\6F\6C\20\6F\6E\20\74\68\65\20\73\74\61\6E\64\61\72\64\20\69\6E\70\75\74\20\61\6E\64\20\6F\75\74\70\75\74\2C\20\66\6F\72\20\65\64\69\74\6F\72\73\20\28\42\31\35\29" }>, align 64
@G_2ecompiler_2folang_2eModeWhat.k11 = internal constant <{ [84 x i8] }> <{ [84 x i8] c"\73\65\72\76\65\73\20\74\68\65\20\4D\6F\64\65\6C\20\43\6F\6E\74\65\78\74\20\50\72\6F\74\6F\63\6F\6C\20\6F\6E\20\74\68\65\20\73\74\61\6E\64\61\72\64\20\69\6E\70\75\74\20\61\6E\64\20\6F\75\74\70\75\74\2C\20\66\6F\72\20\61\67\65\6E\74\73\20\28\42\31\36\29" }>, align 64
@G_2ecompiler_2folang_2eModeWhat.k12 = internal constant <{ [116 x i8] }> <{ [116 x i8] c"\72\65\77\72\69\74\65\73\20\6F\6C\64\20\63\6F\64\65\20\74\6F\20\74\68\65\20\6C\61\6E\67\75\61\67\65\20\6F\66\20\74\6F\64\61\79\3A\20\65\76\65\72\79\20\6D\69\67\72\61\74\69\6F\6E\20\74\6F\6F\6C\20\6F\66\20\74\6F\6F\6C\73\2F\2C\20\69\6E\20\74\68\65\20\6F\72\64\65\72\20\74\68\65\20\63\68\61\6E\67\65\73\20\77\65\72\65\20\6D\61\64\65\20\28\42\31\37\29" }>, align 64
@G_2ecompiler_2folang_2eModeWhat.k13 = internal constant <{ [76 x i8] }> <{ [76 x i8] c"\77\72\69\74\65\73\20\61\20\43\20\68\65\61\64\65\72\27\73\20\64\65\63\6C\61\72\61\74\69\6F\6E\73\20\61\73\20\6F\6C\61\6E\67\20\64\65\63\6C\61\72\65\73\20\74\68\65\6D\2C\20\72\65\61\64\20\62\79\20\63\6C\61\6E\67\20\28\58\31\36\29" }>, align 64
@G_2ecompiler_2folang_2eModeWords = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWords.k1, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWords.k2, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWords.k3, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWords.k4, [8 x i8] c"\09\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWords.k5, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWords.k6, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWords.k7, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWords.k8, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWords.k9, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWords.k10, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWords.k11, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWords.k12, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWords.k13 }>, align 64
@G_2ecompiler_2folang_2eModeWords.k1 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2folang_2eModeWords.k2 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\62\75\69\6C\64" }>, align 8
@G_2ecompiler_2folang_2eModeWords.k3 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\63\6F\6D\70\69\6C\65" }>, align 8
@G_2ecompiler_2folang_2eModeWords.k4 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\74\65\73\74" }>, align 8
@G_2ecompiler_2folang_2eModeWords.k5 = internal constant <{ [9 x i8] }> <{ [9 x i8] c"\69\6E\74\65\72\70\72\65\74" }>, align 8
@G_2ecompiler_2folang_2eModeWords.k6 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\66\6F\72\6D\61\74" }>, align 8
@G_2ecompiler_2folang_2eModeWords.k7 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\65\78\70\6C\61\69\6E" }>, align 8
@G_2ecompiler_2folang_2eModeWords.k8 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\68\65\6C\70" }>, align 8
@G_2ecompiler_2folang_2eModeWords.k9 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\64\6F\63" }>, align 8
@G_2ecompiler_2folang_2eModeWords.k10 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\6C\73\70" }>, align 8
@G_2ecompiler_2folang_2eModeWords.k11 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\6D\63\70" }>, align 8
@G_2ecompiler_2folang_2eModeWords.k12 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\66\69\78" }>, align 8
@G_2ecompiler_2folang_2eModeWords.k13 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\62\69\6E\64\67\65\6E" }>, align 8
@G_2ecompiler_2folang_2eOptModes = constant <{ [112 x i8] }> <{ [112 x i8] c"\06\10\00\00\00\00\00\00\0F\00\00\00\00\00\00\00\0F\00\00\00\00\00\00\00\0F\00\00\00\00\00\00\00\5F\07\00\00\00\00\00\00\5F\07\00\00\00\00\00\00\5F\07\00\00\00\00\00\00\20\08\00\00\00\00\00\00\0F\00\00\00\00\00\00\00\00\01\00\00\00\00\00\00\02\00\00\00\00\00\00\00\0B\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00" }>, align 64
@G_2ecompiler_2folang_2eOptValues = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptValues.k1, [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptValues.k2, [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptValues.k3, [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptValues.k4, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptValues.k5, [8 x i8] c"\0A\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptValues.k6, [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptValues.k7, [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptValues.k8, [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptValues.k9, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptValues.k10, [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptValues.k11, [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptValues.k12, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptValues.k13, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptValues.k14 }>, align 64
@G_2ecompiler_2folang_2eOptValues.k1 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\50\41\54\48" }>, align 8
@G_2ecompiler_2folang_2eOptValues.k2 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2folang_2eOptValues.k3 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2folang_2eOptValues.k4 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2folang_2eOptValues.k5 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\4E\41\4D\45" }>, align 8
@G_2ecompiler_2folang_2eOptValues.k6 = internal constant <{ [10 x i8] }> <{ [10 x i8] c"\4E\61\6D\65\3D\76\61\6C\75\65" }>, align 8
@G_2ecompiler_2folang_2eOptValues.k7 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2folang_2eOptValues.k8 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2folang_2eOptValues.k9 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2folang_2eOptValues.k10 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\44\49\52" }>, align 8
@G_2ecompiler_2folang_2eOptValues.k11 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2folang_2eOptValues.k12 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2folang_2eOptValues.k13 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\4E\41\4D\45" }>, align 8
@G_2ecompiler_2folang_2eOptValues.k14 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\53\45\43\4F\4E\44\53" }>, align 8
@G_2ecompiler_2folang_2eOptWhat = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\4E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWhat.k1, [8 x i8] c"\35\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWhat.k2, [8 x i8] c"\28\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWhat.k3, [8 x i8] c"\25\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWhat.k4, [8 x i8] c"\20\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWhat.k5, [8 x i8] c"\1E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWhat.k6, [8 x i8] c"\55\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWhat.k7, [8 x i8] c"\59\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWhat.k8, [8 x i8] c"\60\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWhat.k9, [8 x i8] c"\6D\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWhat.k10, [8 x i8] c"\53\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWhat.k11, [8 x i8] c"\58\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWhat.k12, [8 x i8] c"\6E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWhat.k13, [8 x i8] c"\2D\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWhat.k14 }>, align 64
@G_2ecompiler_2folang_2eOptWhat.k1 = internal constant <{ [78 x i8] }> <{ [78 x i8] c"\77\72\69\74\65\73\20\74\68\65\20\65\78\65\63\75\74\61\62\6C\65\2C\20\74\68\65\20\6F\62\6A\65\63\74\20\6F\72\20\62\69\6E\64\67\65\6E\27\73\20\64\65\63\6C\61\72\61\74\69\6F\6E\73\20\74\6F\20\50\41\54\48\20\28\42\33\68\2C\20\58\31\36\29" }>, align 64
@G_2ecompiler_2folang_2eOptWhat.k2 = internal constant <{ [53 x i8] }> <{ [53 x i8] c"\62\75\69\6C\64\73\20\75\6E\6F\70\74\69\6D\69\7A\65\64\2C\20\77\69\74\68\20\64\65\62\75\67\20\69\6E\66\6F\72\6D\61\74\69\6F\6E\20\28\42\32\63\2C\20\42\32\65\29" }>, align 32
@G_2ecompiler_2folang_2eOptWhat.k3 = internal constant <{ [40 x i8] }> <{ [40 x i8] c"\62\75\69\6C\64\73\20\77\69\74\68\20\74\68\65\20\64\61\74\61\20\72\61\63\65\20\64\65\74\65\63\74\6F\72\20\28\42\32\62\29" }>, align 32
@G_2ecompiler_2folang_2eOptWhat.k4 = internal constant <{ [37 x i8] }> <{ [37 x i8] c"\62\75\69\6C\64\73\20\77\69\74\68\20\74\68\65\20\73\63\6F\70\65\20\73\61\6E\69\74\69\7A\65\72\20\28\42\32\66\29" }>, align 32
@G_2ecompiler_2folang_2eOptWhat.k5 = internal constant <{ [32 x i8] }> <{ [32 x i8] c"\62\75\69\6C\64\73\20\66\6F\72\20\61\6E\6F\74\68\65\72\20\6D\61\63\68\69\6E\65\20\28\42\31\32\29" }>, align 32
@G_2ecompiler_2folang_2eOptWhat.k6 = internal constant <{ [30 x i8] }> <{ [30 x i8] c"\64\65\66\69\6E\65\73\20\61\20\62\75\69\6C\64\20\63\6F\6E\73\74\61\6E\74\20\28\42\31\30\29" }>, align 8
@G_2ecompiler_2folang_2eOptWhat.k7 = internal constant <{ [85 x i8] }> <{ [85 x i8] c"\6D\6F\76\65\73\20\74\68\65\20\72\65\6D\6F\74\65\20\72\65\70\6F\73\69\74\6F\72\69\65\73\20\74\68\65\20\62\75\69\6C\64\20\72\65\61\63\68\65\73\20\74\6F\20\74\68\65\69\72\20\72\65\66\73\27\20\63\75\72\72\65\6E\74\20\63\6F\6D\6D\69\74\73\20\28\4D\32\33\63\29" }>, align 64
@G_2ecompiler_2folang_2eOptWhat.k8 = internal constant <{ [89 x i8] }> <{ [89 x i8] c"\72\65\77\72\69\74\65\73\20\6E\6F\74\68\69\6E\67\3A\20\6C\69\73\74\73\20\65\61\63\68\20\66\69\6C\65\20\6E\6F\74\20\69\6E\20\74\68\65\20\6C\61\79\6F\75\74\20\28\42\31\33\29\2C\20\6F\72\20\74\68\61\74\20\66\69\78\20\77\6F\75\6C\64\20\63\68\61\6E\67\65\20\28\42\31\37\29" }>, align 64
@G_2ecompiler_2folang_2eOptWhat.k9 = internal constant <{ [96 x i8] }> <{ [96 x i8] c"\62\75\69\6C\64\73\20\66\6F\72\20\64\65\76\65\6C\6F\70\6D\65\6E\74\3A\20\2D\4F\32\20\77\69\74\68\6F\75\74\20\6C\69\6E\6B\2D\74\69\6D\65\20\6F\70\74\69\6D\69\7A\61\74\69\6F\6E\2C\20\66\61\73\74\65\72\20\74\6F\20\62\75\69\6C\64\2C\20\73\6C\6F\77\65\72\20\74\6F\20\72\75\6E\20\28\42\32\67\29" }>, align 64
@G_2ecompiler_2folang_2eOptWhat.k10 = internal constant <{ [109 x i8] }> <{ [109 x i8] c"\77\72\69\74\65\73\20\74\68\65\20\64\6F\63\75\6D\65\6E\74\61\74\69\6F\6E\20\61\73\20\48\54\4D\4C\20\69\6E\74\6F\20\44\49\52\2C\20\61\20\70\61\67\65\20\61\20\6D\6F\64\75\6C\65\3A\20\6F\66\20\65\61\63\68\20\46\49\4C\45\2C\20\6F\72\20\6F\66\20\73\74\64\20\77\68\65\72\65\20\6E\6F\6E\65\20\69\73\20\6E\61\6D\65\64\20\28\42\31\34\29" }>, align 64
@G_2ecompiler_2folang_2eOptWhat.k11 = internal constant <{ [83 x i8] }> <{ [83 x i8] c"\62\75\69\6C\64\73\20\61\20\73\68\61\72\65\64\20\6C\69\62\72\61\72\79\20\6C\69\62\4E\41\4D\45\2E\73\6F\20\6F\66\20\74\68\65\20\65\78\70\6F\72\74\20\66\6E\73\2C\20\61\6E\64\20\69\74\73\20\43\20\68\65\61\64\65\72\20\4E\41\4D\45\2E\68\20\28\58\31\34\29" }>, align 64
@G_2ecompiler_2folang_2eOptWhat.k12 = internal constant <{ [88 x i8] }> <{ [88 x i8] c"\72\65\70\6F\72\74\73\20\74\68\65\20\70\6C\61\63\65\73\20\74\68\61\74\20\6B\65\65\70\20\77\68\61\74\20\74\68\65\79\20\6C\65\74\20\67\6F\20\6F\66\20\75\6E\74\69\6C\20\74\68\65\69\72\20\73\63\6F\70\65\20\63\6C\6F\73\65\73\2C\20\61\6E\64\20\77\68\79\20\28\42\31\38\29" }>, align 64
@G_2ecompiler_2folang_2eOptWhat.k13 = internal constant <{ [110 x i8] }> <{ [110 x i8] c"\66\75\7A\7A\65\73\20\74\68\65\20\6F\6E\65\20\74\65\73\74\20\4E\41\4D\45\20\6E\61\6D\65\73\20\28\61\73\20\74\65\73\74\27\73\20\77\6F\72\64\73\20\64\6F\29\20\77\69\74\68\20\6C\69\62\46\75\7A\7A\65\72\2C\20\66\61\69\6C\69\6E\67\20\69\6E\70\75\74\73\20\73\61\76\65\64\20\62\65\73\69\64\65\20\74\68\65\20\66\69\6C\65\20\28\42\31\39\29" }>, align 64
@G_2ecompiler_2folang_2eOptWhat.k14 = internal constant <{ [45 x i8] }> <{ [45 x i8] c"\77\69\74\68\20\2D\66\75\7A\7A\3A\20\73\74\6F\70\73\20\66\75\7A\7A\69\6E\67\20\61\66\74\65\72\20\53\45\43\4F\4E\44\53\20\28\42\31\39\29" }>, align 32
@G_2ecompiler_2folang_2eOptWords = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWords.k1, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWords.k2, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWords.k3, [8 x i8] c"\09\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWords.k4, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWords.k5, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWords.k6, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWords.k7, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWords.k8, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWords.k9, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWords.k10, [8 x i8] c"\08\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWords.k11, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWords.k12, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWords.k13, [8 x i8] c"\09\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWords.k14 }>, align 64
@G_2ecompiler_2folang_2eOptWords.k1 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\2D\6F\75\74\70\75\74" }>, align 8
@G_2ecompiler_2folang_2eOptWords.k2 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\2D\64\65\62\75\67" }>, align 8
@G_2ecompiler_2folang_2eOptWords.k3 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\2D\72\61\63\65" }>, align 8
@G_2ecompiler_2folang_2eOptWords.k4 = internal constant <{ [9 x i8] }> <{ [9 x i8] c"\2D\73\61\6E\69\74\69\7A\65" }>, align 8
@G_2ecompiler_2folang_2eOptWords.k5 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\2D\74\61\72\67\65\74" }>, align 8
@G_2ecompiler_2folang_2eOptWords.k6 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\2D\64\65\66\69\6E\65" }>, align 8
@G_2ecompiler_2folang_2eOptWords.k7 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\2D\75\70\64\61\74\65" }>, align 8
@G_2ecompiler_2folang_2eOptWords.k8 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\2D\63\68\65\63\6B" }>, align 8
@G_2ecompiler_2folang_2eOptWords.k9 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\2D\71\75\69\63\6B" }>, align 8
@G_2ecompiler_2folang_2eOptWords.k10 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\2D\68\74\6D\6C" }>, align 8
@G_2ecompiler_2folang_2eOptWords.k11 = internal constant <{ [8 x i8] }> <{ [8 x i8] c"\2D\6C\69\62\72\61\72\79" }>, align 8
@G_2ecompiler_2folang_2eOptWords.k12 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\2D\6D\65\6D\6F\72\79" }>, align 8
@G_2ecompiler_2folang_2eOptWords.k13 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\2D\66\75\7A\7A" }>, align 8
@G_2ecompiler_2folang_2eOptWords.k14 = internal constant <{ [9 x i8] }> <{ [9 x i8] c"\2D\66\75\7A\7A\74\69\6D\65" }>, align 8
@G_2ecompiler_2folang_2eRun = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eTest = constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eexplainedSrc = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\A7\02\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eexplainedSrc.k1 }>, align 8
@G_2ecompiler_2folang_2eexplainedSrc.k1 = internal constant <{ [679 x i8] }> <{ [679 x i8] c"\74\79\70\65\20\4D\61\74\68\45\72\72\6F\72\20\65\72\72\6F\72\20\7B\20\5A\45\52\4F\20\7D\0A\74\79\70\65\20\4E\20\73\74\72\75\63\74\28\76\20\49\36\34\2C\20\6E\65\78\74\20\4E\3F\26\29\20\7B\20\76\2C\20\6E\65\78\74\20\7D\0A\66\6E\20\28\6E\20\4E\26\29\20\56\61\6C\75\65\28\29\20\49\36\34\20\7B\20\72\65\74\75\72\6E\20\6E\2E\76\20\7D\0A\74\79\70\65\20\48\20\73\74\72\75\63\74\28\6E\20\4E\26\29\20\7B\20\6E\20\7D\0A\66\6E\20\77\72\61\70\28\6E\20\4E\26\29\20\48\20\7B\20\72\65\74\75\72\6E\20\48\28\6E\29\20\7D\0A\66\6E\20\64\69\76\6D\6F\64\28\61\20\49\36\34\2C\20\62\20\49\36\34\29\20\49\36\34\2C\20\49\36\34\20\3F\20\7B\0A\20\20\20\20\69\66\20\62\20\3D\3D\20\30\20\7B\20\65\72\72\6F\72\20\4D\61\74\68\45\72\72\6F\72\2E\5A\45\52\4F\20\7D\0A\20\20\20\20\72\65\74\75\72\6E\20\61\20\2F\20\62\2C\20\61\20\25\20\62\0A\7D\0A\66\6E\20\62\69\67\3C\54\3E\28\61\20\54\2C\20\62\20\54\29\20\54\20\7B\20\72\65\74\75\72\6E\20\61\20\69\66\20\61\20\3E\20\62\20\65\6C\73\65\20\62\20\7D\0A\74\79\70\65\20\53\68\20\65\6E\75\6D\20\7B\0A\20\20\20\20\57\68\6F\6C\65\20\4E\0A\20\20\20\20\50\61\72\74\73\28\61\20\49\36\34\2C\20\62\20\49\36\34\29\0A\20\20\20\20\4E\6F\6E\65\0A\7D\0A\41\6E\73\77\65\72\20\49\36\34\20\3D\20\36\20\2A\20\37\0A\66\6E\20\70\63\74\28\70\61\72\74\20\49\36\34\2C\20\77\68\6F\6C\65\20\49\36\34\29\20\5B\77\68\6F\6C\65\20\3E\20\30\2C\20\70\61\72\74\20\3E\3D\20\30\5D\20\49\36\34\20\7B\20\72\65\74\75\72\6E\20\70\61\72\74\20\2A\20\31\30\30\20\2F\20\77\68\6F\6C\65\20\7D\0A\66\6E\20\6C\69\6E\6B\28\61\20\6D\75\74\20\4E\26\2C\20\62\20\4E\26\29\20\5B\62\20\6F\75\74\6C\69\76\65\73\20\61\5D\20\7B\20\7D\0A\66\6E\20\6D\61\69\6E\28\29\20\3F\20\7B\0A\20\20\20\20\6E\6E\20\3A\3D\20\4E\28\70\63\74\28\31\2C\20\34\29\21\2C\20\6E\75\6C\6C\29\0A\20\20\20\20\6C\69\6E\6B\28\6E\6E\2C\20\6E\6E\29\0A\20\20\20\20\71\2C\20\5F\20\3A\3D\20\74\72\79\20\64\69\76\6D\6F\64\28\41\6E\73\77\65\72\2C\20\62\69\67\28\32\2C\20\33\29\29\0A\20\20\20\20\61\73\73\65\72\74\20\77\72\61\70\28\4E\28\71\2C\20\6E\75\6C\6C\29\29\2E\6E\2E\56\61\6C\75\65\28\29\20\3D\3D\20\31\34\0A\7D\0A" }>, align 64
define dso_local void @compiler_2folang_2eBindgen_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 12, ptr @G_2ecompiler_2folang_2eBindgen, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eBuild_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 1, ptr @G_2ecompiler_2folang_2eBuild, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eCompile_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 2, ptr @G_2ecompiler_2folang_2eCompile, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eDoc_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 8, ptr @G_2ecompiler_2folang_2eDoc, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eExplain_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 6, ptr @G_2ecompiler_2folang_2eExplain, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eFix_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 11, ptr @G_2ecompiler_2folang_2eFix, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eFormat_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 5, ptr @G_2ecompiler_2folang_2eFormat, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eHelp_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 7, ptr @G_2ecompiler_2folang_2eHelp, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eInterp_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 4, ptr @G_2ecompiler_2folang_2eInterp, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eLsp_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 9, ptr @G_2ecompiler_2folang_2eLsp, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eMcp_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 10, ptr @G_2ecompiler_2folang_2eMcp, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eModeUsage_2einit() #0 {
entry:
  %l0 = alloca [13 x { i64, ptr }]
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 0
  store { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d0, i32 0, i32 1) }, ptr %t1, !tbaa !37
  %t2 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 1
  store { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d1, i32 0, i32 1) }, ptr %t2, !tbaa !37
  %t3 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 2
  store { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d2, i32 0, i32 1) }, ptr %t3, !tbaa !37
  %t4 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 3
  store { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d3, i32 0, i32 1) }, ptr %t4, !tbaa !37
  %t5 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 4
  store { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d4, i32 0, i32 1) }, ptr %t5, !tbaa !37
  %t6 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 5
  store { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d5, i32 0, i32 1) }, ptr %t6, !tbaa !37
  %t7 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 6
  store { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d6, i32 0, i32 1) }, ptr %t7, !tbaa !37
  %t8 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 7
  store { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d7, i32 0, i32 1) }, ptr %t8, !tbaa !37
  %t9 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 8
  store { i64, ptr } { i64 67, ptr getelementptr inbounds (<{ i64, [67 x i8] }>, ptr @.d8, i32 0, i32 1) }, ptr %t9, !tbaa !37
  %t10 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 9
  store { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d9, i32 0, i32 1) }, ptr %t10, !tbaa !37
  %t11 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 10
  store { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d10, i32 0, i32 1) }, ptr %t11, !tbaa !37
  %t12 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 11
  store { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d11, i32 0, i32 1) }, ptr %t12, !tbaa !37
  %t13 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 12
  store { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d12, i32 0, i32 1) }, ptr %t13, !tbaa !37
  call void @llvm.memmove.p0.p0.i64(ptr @G_2ecompiler_2folang_2eModeUsage, ptr %l0, i64 208, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eModeWhat_2einit() #0 {
entry:
  %l0 = alloca [13 x { i64, ptr }]
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 0
  store { i64, ptr } { i64 106, ptr getelementptr inbounds (<{ i64, [106 x i8] }>, ptr @.d13, i32 0, i32 1) }, ptr %t1, !tbaa !37
  %t2 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 1
  store { i64, ptr } { i64 64, ptr getelementptr inbounds (<{ i64, [64 x i8] }>, ptr @.d14, i32 0, i32 1) }, ptr %t2, !tbaa !37
  %t3 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 2
  store { i64, ptr } { i64 54, ptr getelementptr inbounds (<{ i64, [54 x i8] }>, ptr @.d15, i32 0, i32 1) }, ptr %t3, !tbaa !37
  %t4 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 3
  store { i64, ptr } { i64 62, ptr getelementptr inbounds (<{ i64, [62 x i8] }>, ptr @.d16, i32 0, i32 1) }, ptr %t4, !tbaa !37
  %t5 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 4
  store { i64, ptr } { i64 110, ptr getelementptr inbounds (<{ i64, [110 x i8] }>, ptr @.d17, i32 0, i32 1) }, ptr %t5, !tbaa !37
  %t6 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 5
  store { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d18, i32 0, i32 1) }, ptr %t6, !tbaa !37
  %t7 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 6
  store { i64, ptr } { i64 93, ptr getelementptr inbounds (<{ i64, [93 x i8] }>, ptr @.d19, i32 0, i32 1) }, ptr %t7, !tbaa !37
  %t8 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 7
  store { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d20, i32 0, i32 1) }, ptr %t8, !tbaa !37
  %t9 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 8
  store { i64, ptr } { i64 68, ptr getelementptr inbounds (<{ i64, [68 x i8] }>, ptr @.d21, i32 0, i32 1) }, ptr %t9, !tbaa !37
  %t10 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 9
  store { i64, ptr } { i64 87, ptr getelementptr inbounds (<{ i64, [87 x i8] }>, ptr @.d22, i32 0, i32 1) }, ptr %t10, !tbaa !37
  %t11 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 10
  store { i64, ptr } { i64 84, ptr getelementptr inbounds (<{ i64, [84 x i8] }>, ptr @.d23, i32 0, i32 1) }, ptr %t11, !tbaa !37
  %t12 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 11
  store { i64, ptr } { i64 116, ptr getelementptr inbounds (<{ i64, [116 x i8] }>, ptr @.d24, i32 0, i32 1) }, ptr %t12, !tbaa !37
  %t13 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 12
  store { i64, ptr } { i64 76, ptr getelementptr inbounds (<{ i64, [76 x i8] }>, ptr @.d25, i32 0, i32 1) }, ptr %t13, !tbaa !37
  call void @llvm.memmove.p0.p0.i64(ptr @G_2ecompiler_2folang_2eModeWhat, ptr %l0, i64 208, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eModeWords_2einit() #0 {
entry:
  %l0 = alloca [13 x { i64, ptr }]
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 0
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d26, i32 0, i32 1) }, ptr %t1, !tbaa !37
  %t2 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 1
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d27, i32 0, i32 1) }, ptr %t2, !tbaa !37
  %t3 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 2
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d28, i32 0, i32 1) }, ptr %t3, !tbaa !37
  %t4 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 3
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d29, i32 0, i32 1) }, ptr %t4, !tbaa !37
  %t5 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 4
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d30, i32 0, i32 1) }, ptr %t5, !tbaa !37
  %t6 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 5
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d31, i32 0, i32 1) }, ptr %t6, !tbaa !37
  %t7 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 6
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d32, i32 0, i32 1) }, ptr %t7, !tbaa !37
  %t8 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 7
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d33, i32 0, i32 1) }, ptr %t8, !tbaa !37
  %t9 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 8
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d34, i32 0, i32 1) }, ptr %t9, !tbaa !37
  %t10 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 9
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d35, i32 0, i32 1) }, ptr %t10, !tbaa !37
  %t11 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 10
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d36, i32 0, i32 1) }, ptr %t11, !tbaa !37
  %t12 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 11
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d37, i32 0, i32 1) }, ptr %t12, !tbaa !37
  %t13 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 12
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d38, i32 0, i32 1) }, ptr %t13, !tbaa !37
  call void @llvm.memmove.p0.p0.i64(ptr @G_2ecompiler_2folang_2eModeWords, ptr %l0, i64 208, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eOptModes_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t1 = insertvalue [14 x i64] undef, i64 4102, 0
  %t2 = insertvalue [14 x i64] %t1, i64 15, 1
  %t3 = insertvalue [14 x i64] %t2, i64 15, 2
  %t4 = insertvalue [14 x i64] %t3, i64 15, 3
  %t5 = insertvalue [14 x i64] %t4, i64 1887, 4
  %t6 = insertvalue [14 x i64] %t5, i64 1887, 5
  %t7 = insertvalue [14 x i64] %t6, i64 1887, 6
  %t8 = insertvalue [14 x i64] %t7, i64 2080, 7
  %t9 = insertvalue [14 x i64] %t8, i64 15, 8
  %t10 = insertvalue [14 x i64] %t9, i64 256, 9
  %t11 = insertvalue [14 x i64] %t10, i64 2, 10
  %t12 = insertvalue [14 x i64] %t11, i64 11, 11
  %t13 = insertvalue [14 x i64] %t12, i64 8, 12
  %t14 = insertvalue [14 x i64] %t13, i64 8, 13
  store [14 x i64] %t14, ptr @G_2ecompiler_2folang_2eOptModes
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eOptValues_2einit() #0 {
entry:
  %l0 = alloca [14 x { i64, ptr }]
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr [14 x { i64, ptr }], ptr %l0, i64 0, i64 0
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d39, i32 0, i32 1) }, ptr %t1, !tbaa !37
  %t2 = getelementptr [14 x { i64, ptr }], ptr %l0, i64 0, i64 1
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d40, i32 0, i32 1) }, ptr %t2, !tbaa !37
  %t3 = getelementptr [14 x { i64, ptr }], ptr %l0, i64 0, i64 2
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d41, i32 0, i32 1) }, ptr %t3, !tbaa !37
  %t4 = getelementptr [14 x { i64, ptr }], ptr %l0, i64 0, i64 3
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d42, i32 0, i32 1) }, ptr %t4, !tbaa !37
  %t5 = getelementptr [14 x { i64, ptr }], ptr %l0, i64 0, i64 4
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d43, i32 0, i32 1) }, ptr %t5, !tbaa !37
  %t6 = getelementptr [14 x { i64, ptr }], ptr %l0, i64 0, i64 5
  store { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d44, i32 0, i32 1) }, ptr %t6, !tbaa !37
  %t7 = getelementptr [14 x { i64, ptr }], ptr %l0, i64 0, i64 6
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d45, i32 0, i32 1) }, ptr %t7, !tbaa !37
  %t8 = getelementptr [14 x { i64, ptr }], ptr %l0, i64 0, i64 7
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d46, i32 0, i32 1) }, ptr %t8, !tbaa !37
  %t9 = getelementptr [14 x { i64, ptr }], ptr %l0, i64 0, i64 8
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d47, i32 0, i32 1) }, ptr %t9, !tbaa !37
  %t10 = getelementptr [14 x { i64, ptr }], ptr %l0, i64 0, i64 9
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d48, i32 0, i32 1) }, ptr %t10, !tbaa !37
  %t11 = getelementptr [14 x { i64, ptr }], ptr %l0, i64 0, i64 10
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d49, i32 0, i32 1) }, ptr %t11, !tbaa !37
  %t12 = getelementptr [14 x { i64, ptr }], ptr %l0, i64 0, i64 11
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d50, i32 0, i32 1) }, ptr %t12, !tbaa !37
  %t13 = getelementptr [14 x { i64, ptr }], ptr %l0, i64 0, i64 12
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d51, i32 0, i32 1) }, ptr %t13, !tbaa !37
  %t14 = getelementptr [14 x { i64, ptr }], ptr %l0, i64 0, i64 13
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d52, i32 0, i32 1) }, ptr %t14, !tbaa !37
  call void @llvm.memmove.p0.p0.i64(ptr @G_2ecompiler_2folang_2eOptValues, ptr %l0, i64 224, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eOptWhat_2einit() #0 {
entry:
  %l0 = alloca [14 x { i64, ptr }]
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr [14 x { i64, ptr }], ptr %l0, i64 0, i64 0
  store { i64, ptr } { i64 78, ptr getelementptr inbounds (<{ i64, [78 x i8] }>, ptr @.d53, i32 0, i32 1) }, ptr %t1, !tbaa !37
  %t2 = getelementptr [14 x { i64, ptr }], ptr %l0, i64 0, i64 1
  store { i64, ptr } { i64 53, ptr getelementptr inbounds (<{ i64, [53 x i8] }>, ptr @.d54, i32 0, i32 1) }, ptr %t2, !tbaa !37
  %t3 = getelementptr [14 x { i64, ptr }], ptr %l0, i64 0, i64 2
  store { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d55, i32 0, i32 1) }, ptr %t3, !tbaa !37
  %t4 = getelementptr [14 x { i64, ptr }], ptr %l0, i64 0, i64 3
  store { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d56, i32 0, i32 1) }, ptr %t4, !tbaa !37
  %t5 = getelementptr [14 x { i64, ptr }], ptr %l0, i64 0, i64 4
  store { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d57, i32 0, i32 1) }, ptr %t5, !tbaa !37
  %t6 = getelementptr [14 x { i64, ptr }], ptr %l0, i64 0, i64 5
  store { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d58, i32 0, i32 1) }, ptr %t6, !tbaa !37
  %t7 = getelementptr [14 x { i64, ptr }], ptr %l0, i64 0, i64 6
  store { i64, ptr } { i64 85, ptr getelementptr inbounds (<{ i64, [85 x i8] }>, ptr @.d59, i32 0, i32 1) }, ptr %t7, !tbaa !37
  %t8 = getelementptr [14 x { i64, ptr }], ptr %l0, i64 0, i64 7
  store { i64, ptr } { i64 89, ptr getelementptr inbounds (<{ i64, [89 x i8] }>, ptr @.d60, i32 0, i32 1) }, ptr %t8, !tbaa !37
  %t9 = getelementptr [14 x { i64, ptr }], ptr %l0, i64 0, i64 8
  store { i64, ptr } { i64 96, ptr getelementptr inbounds (<{ i64, [96 x i8] }>, ptr @.d61, i32 0, i32 1) }, ptr %t9, !tbaa !37
  %t10 = getelementptr [14 x { i64, ptr }], ptr %l0, i64 0, i64 9
  store { i64, ptr } { i64 109, ptr getelementptr inbounds (<{ i64, [109 x i8] }>, ptr @.d62, i32 0, i32 1) }, ptr %t10, !tbaa !37
  %t11 = getelementptr [14 x { i64, ptr }], ptr %l0, i64 0, i64 10
  store { i64, ptr } { i64 83, ptr getelementptr inbounds (<{ i64, [83 x i8] }>, ptr @.d63, i32 0, i32 1) }, ptr %t11, !tbaa !37
  %t12 = getelementptr [14 x { i64, ptr }], ptr %l0, i64 0, i64 11
  store { i64, ptr } { i64 88, ptr getelementptr inbounds (<{ i64, [88 x i8] }>, ptr @.d64, i32 0, i32 1) }, ptr %t12, !tbaa !37
  %t13 = getelementptr [14 x { i64, ptr }], ptr %l0, i64 0, i64 12
  store { i64, ptr } { i64 110, ptr getelementptr inbounds (<{ i64, [110 x i8] }>, ptr @.d65, i32 0, i32 1) }, ptr %t13, !tbaa !37
  %t14 = getelementptr [14 x { i64, ptr }], ptr %l0, i64 0, i64 13
  store { i64, ptr } { i64 45, ptr getelementptr inbounds (<{ i64, [45 x i8] }>, ptr @.d66, i32 0, i32 1) }, ptr %t14, !tbaa !37
  call void @llvm.memmove.p0.p0.i64(ptr @G_2ecompiler_2folang_2eOptWhat, ptr %l0, i64 224, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eOptWords_2einit() #0 {
entry:
  %l0 = alloca [14 x { i64, ptr }]
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr [14 x { i64, ptr }], ptr %l0, i64 0, i64 0
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d67, i32 0, i32 1) }, ptr %t1, !tbaa !37
  %t2 = getelementptr [14 x { i64, ptr }], ptr %l0, i64 0, i64 1
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d68, i32 0, i32 1) }, ptr %t2, !tbaa !37
  %t3 = getelementptr [14 x { i64, ptr }], ptr %l0, i64 0, i64 2
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d69, i32 0, i32 1) }, ptr %t3, !tbaa !37
  %t4 = getelementptr [14 x { i64, ptr }], ptr %l0, i64 0, i64 3
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d70, i32 0, i32 1) }, ptr %t4, !tbaa !37
  %t5 = getelementptr [14 x { i64, ptr }], ptr %l0, i64 0, i64 4
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d71, i32 0, i32 1) }, ptr %t5, !tbaa !37
  %t6 = getelementptr [14 x { i64, ptr }], ptr %l0, i64 0, i64 5
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d72, i32 0, i32 1) }, ptr %t6, !tbaa !37
  %t7 = getelementptr [14 x { i64, ptr }], ptr %l0, i64 0, i64 6
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d73, i32 0, i32 1) }, ptr %t7, !tbaa !37
  %t8 = getelementptr [14 x { i64, ptr }], ptr %l0, i64 0, i64 7
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d74, i32 0, i32 1) }, ptr %t8, !tbaa !37
  %t9 = getelementptr [14 x { i64, ptr }], ptr %l0, i64 0, i64 8
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d75, i32 0, i32 1) }, ptr %t9, !tbaa !37
  %t10 = getelementptr [14 x { i64, ptr }], ptr %l0, i64 0, i64 9
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d76, i32 0, i32 1) }, ptr %t10, !tbaa !37
  %t11 = getelementptr [14 x { i64, ptr }], ptr %l0, i64 0, i64 10
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d77, i32 0, i32 1) }, ptr %t11, !tbaa !37
  %t12 = getelementptr [14 x { i64, ptr }], ptr %l0, i64 0, i64 11
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d78, i32 0, i32 1) }, ptr %t12, !tbaa !37
  %t13 = getelementptr [14 x { i64, ptr }], ptr %l0, i64 0, i64 12
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d79, i32 0, i32 1) }, ptr %t13, !tbaa !37
  %t14 = getelementptr [14 x { i64, ptr }], ptr %l0, i64 0, i64 13
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d80, i32 0, i32 1) }, ptr %t14, !tbaa !37
  call void @llvm.memmove.p0.p0.i64(ptr @G_2ecompiler_2folang_2eOptWords, ptr %l0, i64 224, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local { i32, %"compiler/olang:CommandLine" } @compiler_2folang_2eParse(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l2 = alloca ptr
  %lp3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca %"compiler/olang:CommandLine"
  %l25 = alloca ptr
  %l26 = alloca %"compiler/msgs:Msg"
  %l27 = alloca i32
  %l29 = alloca { i64, ptr }
  %l31 = alloca i1
  %l33 = alloca i1
  %l34 = alloca { i64, ptr }
  %l36 = alloca i1
  %l38 = alloca { i64, ptr }
  %l40 = alloca i64
  %l43 = alloca ptr
  %l44 = alloca { i64, ptr }
  %l46 = alloca %"compiler/msgs:Msg"
  %l47 = alloca i32
  %l55 = alloca { i64, ptr }
  %l61 = alloca i1
  %l62 = alloca [14 x { i64, ptr }]
  %l67 = alloca i64
  %l70 = alloca i64
  %l91 = alloca i1
  %l98 = alloca %"compiler/msgs:Nearest"
  %l114 = alloca ptr
  %l115 = alloca { i64, ptr }
  %l117 = alloca { i64, ptr }
  %l118 = alloca { i64, ptr }
  %l120 = alloca { i64, ptr }
  %l122 = alloca %"compiler/msgs:Msg"
  %l123 = alloca i32
  %l127 = alloca i64
  %l131 = alloca ptr
  %l132 = alloca { i64, ptr }
  %l135 = alloca { i64, ptr }
  %l136 = alloca { i64, ptr }
  %l138 = alloca { i64, ptr }
  %l140 = alloca %"compiler/msgs:Msg"
  %l141 = alloca i32
  %l149 = alloca i1
  %l155 = alloca ptr
  %l159 = alloca %"compiler/msgs:Msg"
  %l160 = alloca i32
  %l162 = alloca { i64, ptr }
  %l198 = alloca i32
  %l200 = alloca i1
  %l229 = alloca i64
  %l230 = alloca { i64, ptr }
  %l231 = alloca i64
  %l232 = alloca i32
  %l233 = alloca i64
  %l234 = alloca i32
  %l237 = alloca ptr
  %l239 = alloca %"compiler/msgs:Msg"
  %l240 = alloca i32
  %l246 = alloca i1
  %l249 = alloca i1
  %l252 = alloca ptr
  %l255 = alloca { i64, ptr }
  %l256 = alloca %"compiler/msgs:Msg"
  %l257 = alloca i32
  %l262 = alloca i1
  %l264 = alloca i1
  %l265 = alloca i1
  %l267 = alloca i64
  %l269 = alloca i1
  %l271 = alloca i1
  %l274 = alloca ptr
  %l276 = alloca { i64, ptr }
  %l277 = alloca %"compiler/msgs:Msg"
  %l278 = alloca i32
  %l286 = alloca i1
  %l293 = alloca i1
  %l295 = alloca i1
  %l297 = alloca i64
  %l299 = alloca i1
  %l301 = alloca i1
  %l310 = alloca ptr
  %l314 = alloca %"compiler/msgs:Msg"
  %l315 = alloca %"compiler/msgs:Msg"
  %l316 = alloca %"compiler/msgs:Msg"
  %l317 = alloca i32
  %l325 = alloca i1
  %l327 = alloca i1
  %l330 = alloca i64
  %l332 = alloca ptr
  %l334 = alloca %"compiler/msgs:Msg"
  %l335 = alloca i32
  %l337 = alloca ptr
  %l339 = alloca %"compiler/msgs:Msg"
  %l340 = alloca i32
  %l345 = alloca i1
  %l347 = alloca i64
  %l349 = alloca i1
  %l351 = alloca i1
  %l353 = alloca i1
  %l355 = alloca i1
  %l368 = alloca i1
  %l378 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s38 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %s40 = alloca %olang.scope
  %s42 = alloca %olang.scope
  %s48 = alloca %olang.scope
  %s50 = alloca %olang.scope
  %s51 = alloca %olang.scope
  %rv = alloca { i32, %"compiler/olang:CommandLine" }
  store { i64, ptr } %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"compiler/olang:CommandLine" @compiler_2folang_3aCommandLine_2ector(ptr %v3)
  store %"compiler/olang:CommandLine" %t1, ptr %l21
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 120, i64 8)
  store ptr %t2, ptr %lp3
  %t3 = load %"compiler/olang:CommandLine", ptr %l21
  %t4 = load ptr, ptr %lp3
  store %"compiler/olang:CommandLine" %t3, ptr %t4
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t9 = icmp slt i64 %t7, 2
  br i1 %t9, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = load ptr, ptr %l2, !tbaa !29
  store ptr %t11, ptr %l25, !tbaa !29
  %t12 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eUsage(ptr %s1)
  store %"compiler/msgs:Msg" %t12, ptr %l26
  br label %bb4
bb3:
  br label %bb8
bb4:
  %t13 = load ptr, ptr %l25, !tbaa !29
  %t14 = load %"compiler/msgs:Msg", ptr %l26
  %t15 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s1, ptr %t13, %"compiler/msgs:Msg" %t14)
  store i32 %t15, ptr %l27
  %t16 = icmp ne i32 %t15, 0
  br i1 %t16, label %bb6, label %ok.17
ok.17:
  br label %bb5
bb5:
  br label %bb7
bb6:
  %t18 = load i32, ptr %l27, !tbaa !23
  %t19 = lshr i32 %t18, 16
  %t20 = and i32 %t18, 65535
  %t21 = icmp eq i32 %t19, 1
  %t22 = select i1 %t21, i32 1, i32 0
  %t23 = icmp eq i32 %t18, 0
  %t24 = shl i32 %t22, 16
  %t25 = or i32 %t24, %t20
  %t26 = select i1 %t23, i32 0, i32 %t25
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t28 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t26, 0
  store { i32, %"compiler/olang:CommandLine" } %t28, ptr %rv
  br label %ret
bb7:
  call void @__olang_scope_close(ptr %s1)
  br label %bb8
bb8:
  store i64 1, ptr %l4, !tbaa !24
  %t29 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t29, ptr %l29, !tbaa !27
  %t30 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr { i64, ptr }, ptr %t31, i64 1
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !37
  %t35 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t33, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d81, i32 0, i32 1) })
  store i1 %t35, ptr %l31
  br label %bb9
bb9:
  %t36 = load i1, ptr %l31, !tbaa !21
  %t37 = xor i1 %t36, true
  br i1 %t37, label %bb10, label %bb11
bb10:
  %t39 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t39, ptr %l34, !tbaa !27
  %t40 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %t41, i64 1
  %t43 = load { i64, ptr }, ptr %t42, !tbaa !37
  %t45 = call i1 @compiler_2folang_2eendsWithOlang(ptr %v0, { i64, ptr } %t43)
  store i1 %t45, ptr %l36
  br label %bb12
bb11:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb13
bb12:
  %t46 = load i1, ptr %l36, !tbaa !21
  %t47 = xor i1 %t46, true
  store i1 %t47, ptr %l33, !tbaa !21
  br label %bb13
bb13:
  %t49 = load i1, ptr %l33, !tbaa !21
  br i1 %t49, label %bb14, label %bb15
bb14:
  %t50 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t50, ptr %l38, !tbaa !27
  %t51 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = getelementptr { i64, ptr }, ptr %t52, i64 1
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !37
  %t56 = call i64 @compiler_2folang_2emodeNumber(ptr %v0, { i64, ptr } %t54)
  store i64 %t56, ptr %l40
  br label %bb16
bb15:
  br label %bb24
bb16:
  %t57 = load i64, ptr %l40, !tbaa !24
  store i64 %t57, ptr %l5, !tbaa !24
  %t58 = load i64, ptr %l5, !tbaa !24
  %t60 = icmp slt i64 %t58, 0
  br i1 %t60, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s3
  %t62 = load ptr, ptr %l2, !tbaa !29
  store ptr %t62, ptr %l43, !tbaa !29
  %t63 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t63, ptr %l44, !tbaa !27
  %t64 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = getelementptr { i64, ptr }, ptr %t65, i64 1
  %t67 = load { i64, ptr }, ptr %t66, !tbaa !37
  %t69 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotAMode(ptr %v0, ptr %s3, { i64, ptr } %t67)
  store %"compiler/msgs:Msg" %t69, ptr %l46
  br label %bb19
bb18:
  br label %bb23
bb19:
  %t70 = load ptr, ptr %l43, !tbaa !29
  %t71 = load %"compiler/msgs:Msg", ptr %l46
  %t72 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s3, ptr %t70, %"compiler/msgs:Msg" %t71)
  store i32 %t72, ptr %l47
  %t73 = icmp ne i32 %t72, 0
  br i1 %t73, label %bb21, label %ok.74
ok.74:
  br label %bb20
bb20:
  br label %bb22
bb21:
  %t75 = load i32, ptr %l47, !tbaa !23
  %t76 = lshr i32 %t75, 16
  %t77 = and i32 %t75, 65535
  %t78 = icmp eq i32 %t76, 1
  %t79 = select i1 %t78, i32 1, i32 0
  %t80 = icmp eq i32 %t75, 0
  %t81 = shl i32 %t79, 16
  %t82 = or i32 %t81, %t77
  %t83 = select i1 %t80, i32 0, i32 %t82
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t85 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t83, 0
  store { i32, %"compiler/olang:CommandLine" } %t85, ptr %rv
  br label %ret
bb22:
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb23:
  %t86 = load i64, ptr %l5, !tbaa !24
  %t88 = load ptr, ptr %lp3
  %t89 = getelementptr %"compiler/olang:CommandLine", ptr %t88, i32 0, i32 0
  store i64 %t86, ptr %t89, !tbaa !24
  store i64 2, ptr %l4, !tbaa !24
  br label %bb24
bb24:
  br label %bb25
bb25:
  store %olang.scope zeroinitializer, ptr %s4
  %t90 = load i64, ptr %l4, !tbaa !24
  %t91 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t91, 0
  %t96 = icmp slt i64 %t90, %t93
  %t98 = xor i1 %t96, true
  br i1 %t98, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s4)
  br label %bb268
bb27:
  br label %bb28
bb28:
  %t100 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t100, ptr %l55, !tbaa !27
  %t101 = load i64, ptr %l4, !tbaa !24
  %t103 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = getelementptr { i64, ptr }, ptr %t104, i64 %t101
  %t106 = load { i64, ptr }, ptr %t105, !tbaa !37
  store { i64, ptr } %t106, ptr %l6, !tbaa !27
  %t108 = load i64, ptr %l4, !tbaa !24
  %t110 = add i64 %t108, 1
  store i64 %t110, ptr %l4, !tbaa !24
  %t112 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t114 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s4, { i64, ptr } %t112, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d82, i32 0, i32 1) })
  store i1 %t114, ptr %l61
  br label %bb29
bb29:
  %t115 = load i1, ptr %l61, !tbaa !21
  br i1 %t115, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s5
  store i64 -1, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l62, ptr @G_2ecompiler_2folang_2eOptWords, i64 224, i1 false)
  %t116 = load [14 x { i64, ptr }], ptr %l62
  store i64 14, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t118 = load i64, ptr %l9, !tbaa !24
  %t119 = load i64, ptr %l8, !tbaa !24
  %t122 = icmp sgt i64 %t118, %t119
  br i1 %t122, label %bb32, label %bb33
bb31:
  br label %bb162
bb32:
  %t124 = load i64, ptr %l10, !tbaa !24
  %t126 = icmp sgt i64 %t124, 0
  br i1 %t126, label %bb34, label %bb35
bb33:
  store i64 0, ptr %l67, !tbaa !24
  br label %bb37
bb34:
  %t128 = load i64, ptr %l9, !tbaa !24
  %t129 = load i64, ptr %l8, !tbaa !24
  %t132 = sub i64 %t128, %t129
  %t133 = load i64, ptr %l10, !tbaa !24
  %t136 = add i64 %t132, %t133
  %t138 = sub i64 %t136, 1
  %t139 = load i64, ptr %l10, !tbaa !24
  %t142 = sdiv i64 %t138, %t139
  store i64 %t142, ptr %l70, !tbaa !24
  br label %bb36
bb35:
  store i64 0, ptr %l70, !tbaa !24
  br label %bb36
bb36:
  %t144 = load i64, ptr %l70, !tbaa !24
  store i64 %t144, ptr %l67, !tbaa !24
  br label %bb37
bb37:
  %t145 = load i64, ptr %l67, !tbaa !24
  store i64 %t145, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb38
bb38:
  %t146 = load i64, ptr %l12, !tbaa !24
  %t147 = load i64, ptr %l11, !tbaa !24
  %t150 = icmp slt i64 %t146, %t147
  %t152 = xor i1 %t150, true
  br i1 %t152, label %bb39, label %bb40
bb39:
  br label %bb47
bb40:
  br label %bb41
bb41:
  %t154 = load i64, ptr %l8, !tbaa !24
  %t155 = load i64, ptr %l12, !tbaa !24
  %t156 = load i64, ptr %l10, !tbaa !24
  %t159 = mul i64 %t155, %t156
  %t162 = add i64 %t154, %t159
  store i64 %t162, ptr %l13, !tbaa !24
  %t164 = load i64, ptr %l13, !tbaa !24
  %t166 = getelementptr [14 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eOptWords, i64 0, i64 %t164
  %t167 = load { i64, ptr }, ptr %t166, !tbaa !37
  %t168 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t169 = load ptr, ptr @__olang_prog_scope
  %t172 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t169, ptr %v0, { i64, ptr } %t167, { i64, ptr } %t168)
  store i1 %t172, ptr %l91
  br label %bb42
bb42:
  %t173 = load i1, ptr %l91, !tbaa !21
  br i1 %t173, label %bb43, label %bb44
bb43:
  %t174 = load i64, ptr %l13, !tbaa !24
  store i64 %t174, ptr %l7, !tbaa !24
  br label %bb45
bb44:
  br label %bb45
bb45:
  br label %bb46
bb46:
  %t176 = load i64, ptr %l12, !tbaa !24
  %t178 = add i64 %t176, 1
  store i64 %t178, ptr %l12, !tbaa !24
  br label %bb38
bb47:
  %t180 = load i64, ptr %l7, !tbaa !24
  %t182 = icmp slt i64 %t180, 0
  br i1 %t182, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s10
  %t184 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t186 = call %"compiler/msgs:Nearest" @compiler_2fmsgs_3aNearest_2ector(ptr %v0, ptr %s10, { i64, ptr } %t184)
  store %"compiler/msgs:Nearest" %t186, ptr %l98
  br label %bb50
bb49:
  br label %bb64
bb50:
  %t187 = load %"compiler/msgs:Nearest", ptr %l98
  %t188 = call ptr @__olang_scope_alloc_a(ptr %s10, i64 40, i64 8)
  store %"compiler/msgs:Nearest" %t187, ptr %t188
  store ptr %t188, ptr %l14, !tbaa !29
  store ptr @G_2ecompiler_2folang_2eOptWords, ptr %l15
  store i64 0, ptr %l16, !tbaa !24
  %t191 = load ptr, ptr %l15
  store i64 14, ptr %l17, !tbaa !24
  br label %bb51
bb51:
  %t194 = load i64, ptr %l16, !tbaa !24
  %t195 = load i64, ptr %l17, !tbaa !24
  %t198 = icmp slt i64 %t194, %t195
  %t200 = xor i1 %t198, true
  br i1 %t200, label %bb52, label %bb53
bb52:
  br label %bb57
bb53:
  br label %bb54
bb54:
  %t202 = load ptr, ptr %l15
  %t203 = load i64, ptr %l16, !tbaa !24
  %t206 = getelementptr [14 x { i64, ptr }], ptr %t202, i64 0, i64 %t203
  %t207 = load { i64, ptr }, ptr %t206, !tbaa !37
  %t209 = load ptr, ptr %l14, !tbaa !29
  %t211 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eOffer(ptr %s10, ptr %t211, ptr %t209, { i64, ptr } %t207)
  br label %bb55
bb55:
  br label %bb56
bb56:
  %t214 = load i64, ptr %l16, !tbaa !24
  %t216 = add i64 %t214, 1
  store i64 %t216, ptr %l16, !tbaa !24
  br label %bb51
bb57:
  %t218 = load ptr, ptr %l2, !tbaa !29
  store ptr %t218, ptr %l114, !tbaa !29
  %t219 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t219, ptr %l115, !tbaa !27
  %t220 = load ptr, ptr %lp3
  %t221 = getelementptr %"compiler/olang:CommandLine", ptr %t220, i32 0, i32 0
  %t222 = load i64, ptr %t221, !tbaa !24
  %t224 = call { i64, ptr } @compiler_2folang_2emodeName(ptr %s10, i64 %t222)
  store { i64, ptr } %t224, ptr %l117
  br label %bb58
bb58:
  %t225 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t226 = extractvalue { i64, ptr } %t225, 0
  %t227 = extractvalue { i64, ptr } %t225, 1
  %t228 = mul i64 %t226, 1
  %t229 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t228)
  call void @llvm.memcpy.p0.p0.i64(ptr %t229, ptr %t227, i64 %t228, i1 false)
  %t230 = insertvalue { i64, ptr } undef, i64 %t226, 0
  %t231 = insertvalue { i64, ptr } %t230, ptr %t229, 1
  store { i64, ptr } %t231, ptr %l118, !tbaa !27
  %t232 = load ptr, ptr %l14, !tbaa !29
  %t234 = call { i64, ptr } @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eHint(ptr %s10, ptr %s10, ptr %t232)
  store { i64, ptr } %t234, ptr %l120
  br label %bb59
bb59:
  %t235 = load { i64, ptr }, ptr %l120, !tbaa !27
  %t236 = extractvalue { i64, ptr } %t235, 0
  %t237 = extractvalue { i64, ptr } %t235, 1
  %t238 = mul i64 %t236, 1
  %t239 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t238)
  call void @llvm.memcpy.p0.p0.i64(ptr %t239, ptr %t237, i64 %t238, i1 false)
  %t240 = insertvalue { i64, ptr } undef, i64 %t236, 0
  %t241 = insertvalue { i64, ptr } %t240, ptr %t239, 1
  %t242 = load { i64, ptr }, ptr %l115, !tbaa !27
  %t243 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t245 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownFlag(ptr %v0, ptr %s10, ptr %s10, ptr %s10, { i64, ptr } %t242, { i64, ptr } %t243, { i64, ptr } %t241)
  store %"compiler/msgs:Msg" %t245, ptr %l122
  br label %bb60
bb60:
  %t246 = load ptr, ptr %l114, !tbaa !29
  %t247 = load %"compiler/msgs:Msg", ptr %l122
  %t248 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s10, ptr %t246, %"compiler/msgs:Msg" %t247)
  store i32 %t248, ptr %l123
  %t249 = icmp ne i32 %t248, 0
  br i1 %t249, label %bb62, label %ok.250
ok.250:
  br label %bb61
bb61:
  br label %bb63
bb62:
  %t251 = load i32, ptr %l123, !tbaa !23
  %t252 = lshr i32 %t251, 16
  %t253 = and i32 %t251, 65535
  %t254 = icmp eq i32 %t252, 1
  %t255 = select i1 %t254, i32 1, i32 0
  %t256 = icmp eq i32 %t251, 0
  %t257 = shl i32 %t255, 16
  %t258 = or i32 %t257, %t253
  %t259 = select i1 %t256, i32 0, i32 %t258
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t261 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t259, 0
  store { i32, %"compiler/olang:CommandLine" } %t261, ptr %rv
  br label %ret
bb63:
  call void @__olang_scope_close(ptr %s10)
  br label %bb64
bb64:
  %t262 = load i64, ptr %l7, !tbaa !24
  %t264 = getelementptr [14 x i64], ptr @G_2ecompiler_2folang_2eOptModes, i64 0, i64 %t262
  %t265 = load i64, ptr %t264, !tbaa !34
  %t266 = load ptr, ptr %lp3
  %t267 = getelementptr %"compiler/olang:CommandLine", ptr %t266, i32 0, i32 0
  %t268 = load i64, ptr %t267, !tbaa !24
  store i64 %t268, ptr %l127, !tbaa !24
  %t270 = load i64, ptr %l127, !tbaa !24
  %t271 = load i64, ptr %l127, !tbaa !24
  %t272 = ashr i64 %t265, %t271
  %t274 = and i64 %t272, 1
  %t276 = icmp eq i64 %t274, 0
  br i1 %t276, label %bb65, label %bb66
bb65:
  store %olang.scope zeroinitializer, ptr %s14
  %t278 = load ptr, ptr %l2, !tbaa !29
  store ptr %t278, ptr %l131, !tbaa !29
  %t279 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t279, ptr %l132, !tbaa !27
  %t280 = load i64, ptr %l7, !tbaa !24
  %t282 = getelementptr [14 x i64], ptr @G_2ecompiler_2folang_2eOptModes, i64 0, i64 %t280
  %t283 = load i64, ptr %t282, !tbaa !34
  %t285 = call { i64, ptr } @compiler_2folang_2emodesOf(ptr %s14, i64 %t283)
  store { i64, ptr } %t285, ptr %l135
  br label %bb67
bb66:
  br label %bb73
bb67:
  %t286 = load { i64, ptr }, ptr %l135, !tbaa !27
  %t287 = extractvalue { i64, ptr } %t286, 0
  %t288 = extractvalue { i64, ptr } %t286, 1
  %t289 = mul i64 %t287, 1
  %t290 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t289)
  call void @llvm.memcpy.p0.p0.i64(ptr %t290, ptr %t288, i64 %t289, i1 false)
  %t291 = insertvalue { i64, ptr } undef, i64 %t287, 0
  %t292 = insertvalue { i64, ptr } %t291, ptr %t290, 1
  store { i64, ptr } %t292, ptr %l136, !tbaa !27
  %t293 = load ptr, ptr %lp3
  %t294 = getelementptr %"compiler/olang:CommandLine", ptr %t293, i32 0, i32 0
  %t295 = load i64, ptr %t294, !tbaa !24
  %t297 = call { i64, ptr } @compiler_2folang_2emodeName(ptr %s14, i64 %t295)
  store { i64, ptr } %t297, ptr %l138
  br label %bb68
bb68:
  %t298 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t299 = extractvalue { i64, ptr } %t298, 0
  %t300 = extractvalue { i64, ptr } %t298, 1
  %t301 = mul i64 %t299, 1
  %t302 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t301)
  call void @llvm.memcpy.p0.p0.i64(ptr %t302, ptr %t300, i64 %t301, i1 false)
  %t303 = insertvalue { i64, ptr } undef, i64 %t299, 0
  %t304 = insertvalue { i64, ptr } %t303, ptr %t302, 1
  %t305 = load { i64, ptr }, ptr %l132, !tbaa !27
  %t306 = load { i64, ptr }, ptr %l136, !tbaa !27
  %t308 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eOptionNotForMode(ptr %v0, ptr %s14, ptr %s14, ptr %s14, { i64, ptr } %t305, { i64, ptr } %t306, { i64, ptr } %t304)
  store %"compiler/msgs:Msg" %t308, ptr %l140
  br label %bb69
bb69:
  %t309 = load ptr, ptr %l131, !tbaa !29
  %t310 = load %"compiler/msgs:Msg", ptr %l140
  %t311 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s14, ptr %t309, %"compiler/msgs:Msg" %t310)
  store i32 %t311, ptr %l141
  %t312 = icmp ne i32 %t311, 0
  br i1 %t312, label %bb71, label %ok.313
ok.313:
  br label %bb70
bb70:
  br label %bb72
bb71:
  %t314 = load i32, ptr %l141, !tbaa !23
  %t315 = lshr i32 %t314, 16
  %t316 = and i32 %t314, 65535
  %t317 = icmp eq i32 %t315, 1
  %t318 = select i1 %t317, i32 1, i32 0
  %t319 = icmp eq i32 %t314, 0
  %t320 = shl i32 %t318, 16
  %t321 = or i32 %t320, %t316
  %t322 = select i1 %t319, i32 0, i32 %t321
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t324 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t322, 0
  store { i32, %"compiler/olang:CommandLine" } %t324, ptr %rv
  br label %ret
bb72:
  call void @__olang_scope_close(ptr %s14)
  br label %bb73
bb73:
  %t325 = load ptr, ptr %lp3
  %t326 = getelementptr %"compiler/olang:CommandLine", ptr %t325, i32 0, i32 6
  %t327 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t329 = extractvalue { i64, ptr } %t327, 1
  %t330 = extractvalue { i64, ptr } %t327, 0
  %t331 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t330)
  call void @olang_textcopy(ptr %t331, ptr %t329, i64 %t330)
  %t332 = insertvalue { i64, ptr } undef, i64 %t330, 0
  %t333 = insertvalue { i64, ptr } %t332, ptr %t331, 1
  %t335 = extractvalue { i64, ptr } %t333, 0
  %t336 = extractvalue { i64, ptr } %t333, 1
  %t337 = mul i64 %t335, 1
  %t338 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t337)
  call void @llvm.memcpy.p0.p0.i64(ptr %t338, ptr %t336, i64 %t337, i1 false)
  %t339 = insertvalue { i64, ptr } undef, i64 %t335, 0
  %t340 = insertvalue { i64, ptr } %t339, ptr %t338, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v3, ptr %v3, ptr %t326, { i64, ptr } %t340)
  br label %bb74
bb74:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d83, i32 0, i32 1) }, ptr %l19, !tbaa !27
  %t343 = load i64, ptr %l7, !tbaa !24
  %t345 = getelementptr [14 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eOptValues, i64 0, i64 %t343
  %t346 = load { i64, ptr }, ptr %t345, !tbaa !37
  %t347 = load ptr, ptr @__olang_prog_scope
  %t349 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t347, ptr %s5, { i64, ptr } %t346, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d84, i32 0, i32 1) })
  store i1 %t349, ptr %l149
  br label %bb75
bb75:
  %t350 = load i1, ptr %l149, !tbaa !21
  %t351 = xor i1 %t350, true
  br i1 %t351, label %bb76, label %bb77
bb76:
  %t353 = load i64, ptr %l4, !tbaa !24
  %t354 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t356 = extractvalue { i64, ptr } %t354, 0
  %t359 = icmp sge i64 %t353, %t356
  br i1 %t359, label %bb78, label %bb79
bb77:
  br label %bb86
bb78:
  store %olang.scope zeroinitializer, ptr %s17
  %t361 = load ptr, ptr %l2, !tbaa !29
  store ptr %t361, ptr %l155, !tbaa !29
  %t362 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t363 = load i64, ptr %l7, !tbaa !24
  %t365 = getelementptr [14 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eOptValues, i64 0, i64 %t363
  %t366 = load { i64, ptr }, ptr %t365, !tbaa !37
  %t367 = load ptr, ptr @__olang_prog_scope
  %t370 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eOptionNeedsValue(ptr %v0, ptr %t367, ptr %s17, { i64, ptr } %t362, { i64, ptr } %t366)
  store %"compiler/msgs:Msg" %t370, ptr %l159
  br label %bb80
bb79:
  br label %bb84
bb80:
  %t371 = load ptr, ptr %l155, !tbaa !29
  %t372 = load %"compiler/msgs:Msg", ptr %l159
  %t373 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s17, ptr %t371, %"compiler/msgs:Msg" %t372)
  store i32 %t373, ptr %l160
  %t374 = icmp ne i32 %t373, 0
  br i1 %t374, label %bb82, label %ok.375
ok.375:
  br label %bb81
bb81:
  br label %bb83
bb82:
  %t376 = load i32, ptr %l160, !tbaa !23
  %t377 = lshr i32 %t376, 16
  %t378 = and i32 %t376, 65535
  %t379 = icmp eq i32 %t377, 1
  %t380 = select i1 %t379, i32 1, i32 0
  %t381 = icmp eq i32 %t376, 0
  %t382 = shl i32 %t380, 16
  %t383 = or i32 %t382, %t378
  %t384 = select i1 %t381, i32 0, i32 %t383
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t386 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t384, 0
  store { i32, %"compiler/olang:CommandLine" } %t386, ptr %rv
  br label %ret
bb83:
  call void @__olang_scope_close(ptr %s17)
  br label %bb84
bb84:
  %t387 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t387, ptr %l162, !tbaa !27
  %t388 = load i64, ptr %l4, !tbaa !24
  %t390 = getelementptr { i64, ptr }, ptr %l162, i32 0, i32 1
  %t391 = load ptr, ptr %t390, !tbaa !27
  %t392 = getelementptr { i64, ptr }, ptr %t391, i64 %t388
  %t393 = load { i64, ptr }, ptr %t392, !tbaa !37
  %t395 = extractvalue { i64, ptr } %t393, 1
  %t396 = extractvalue { i64, ptr } %t393, 0
  %t397 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t396)
  call void @olang_textcopy(ptr %t397, ptr %t395, i64 %t396)
  %t398 = insertvalue { i64, ptr } undef, i64 %t396, 0
  %t399 = insertvalue { i64, ptr } %t398, ptr %t397, 1
  %t401 = extractvalue { i64, ptr } %t399, 0
  %t402 = extractvalue { i64, ptr } %t399, 1
  %t403 = mul i64 %t401, 1
  %t404 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t403)
  call void @llvm.memcpy.p0.p0.i64(ptr %t404, ptr %t402, i64 %t403, i1 false)
  %t405 = insertvalue { i64, ptr } undef, i64 %t401, 0
  %t406 = insertvalue { i64, ptr } %t405, ptr %t404, 1
  store { i64, ptr } %t406, ptr %l19, !tbaa !27
  %t408 = load i64, ptr %l4, !tbaa !24
  %t410 = add i64 %t408, 1
  store i64 %t410, ptr %l4, !tbaa !24
  %t412 = load ptr, ptr %lp3
  %t413 = getelementptr %"compiler/olang:CommandLine", ptr %t412, i32 0, i32 6
  %t414 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t416 = extractvalue { i64, ptr } %t414, 1
  %t417 = extractvalue { i64, ptr } %t414, 0
  %t418 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t417)
  call void @olang_textcopy(ptr %t418, ptr %t416, i64 %t417)
  %t419 = insertvalue { i64, ptr } undef, i64 %t417, 0
  %t420 = insertvalue { i64, ptr } %t419, ptr %t418, 1
  %t422 = extractvalue { i64, ptr } %t420, 0
  %t423 = extractvalue { i64, ptr } %t420, 1
  %t424 = mul i64 %t422, 1
  %t425 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t424)
  call void @llvm.memcpy.p0.p0.i64(ptr %t425, ptr %t423, i64 %t424, i1 false)
  %t426 = insertvalue { i64, ptr } undef, i64 %t422, 0
  %t427 = insertvalue { i64, ptr } %t426, ptr %t425, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v3, ptr %v3, ptr %t413, { i64, ptr } %t427)
  br label %bb85
bb85:
  br label %bb86
bb86:
  %t430 = load i64, ptr %l7, !tbaa !24
  %t432 = icmp eq i64 %t430, 0
  br i1 %t432, label %bb87, label %bb88
bb87:
  %t434 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t436 = extractvalue { i64, ptr } %t434, 1
  %t437 = extractvalue { i64, ptr } %t434, 0
  %t438 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t437)
  call void @olang_textcopy(ptr %t438, ptr %t436, i64 %t437)
  %t439 = insertvalue { i64, ptr } undef, i64 %t437, 0
  %t440 = insertvalue { i64, ptr } %t439, ptr %t438, 1
  %t442 = extractvalue { i64, ptr } %t440, 0
  %t443 = extractvalue { i64, ptr } %t440, 1
  %t444 = mul i64 %t442, 1
  %t445 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t444)
  call void @llvm.memcpy.p0.p0.i64(ptr %t445, ptr %t443, i64 %t444, i1 false)
  %t446 = insertvalue { i64, ptr } undef, i64 %t442, 0
  %t447 = insertvalue { i64, ptr } %t446, ptr %t445, 1
  %t449 = load ptr, ptr %lp3
  %t450 = getelementptr %"compiler/olang:CommandLine", ptr %t449, i32 0, i32 8
  store { i64, ptr } %t447, ptr %t450, !tbaa !27
  br label %bb89
bb88:
  br label %bb89
bb89:
  %t451 = load i64, ptr %l7, !tbaa !24
  %t453 = icmp eq i64 %t451, 1
  br i1 %t453, label %bb90, label %bb91
bb90:
  %t455 = load ptr, ptr %l1, !tbaa !29
  %t457 = getelementptr %"compiler/build:Config", ptr %t455, i32 0, i32 4
  store i1 true, ptr %t457, !tbaa !21
  br label %bb92
bb91:
  br label %bb92
bb92:
  %t458 = load i64, ptr %l7, !tbaa !24
  %t460 = icmp eq i64 %t458, 2
  br i1 %t460, label %bb93, label %bb94
bb93:
  %t462 = load ptr, ptr %l1, !tbaa !29
  %t464 = getelementptr %"compiler/build:Config", ptr %t462, i32 0, i32 6
  store i1 true, ptr %t464, !tbaa !21
  br label %bb95
bb94:
  br label %bb95
bb95:
  %t465 = load i64, ptr %l7, !tbaa !24
  %t467 = icmp eq i64 %t465, 3
  br i1 %t467, label %bb96, label %bb97
bb96:
  %t469 = load ptr, ptr %l1, !tbaa !29
  %t471 = getelementptr %"compiler/build:Config", ptr %t469, i32 0, i32 7
  store i1 true, ptr %t471, !tbaa !21
  br label %bb98
bb97:
  br label %bb98
bb98:
  %t472 = load i64, ptr %l7, !tbaa !24
  %t474 = icmp eq i64 %t472, 4
  br i1 %t474, label %bb99, label %bb100
bb99:
  %t476 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t478 = extractvalue { i64, ptr } %t476, 1
  %t479 = extractvalue { i64, ptr } %t476, 0
  %t480 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t479)
  call void @olang_textcopy(ptr %t480, ptr %t478, i64 %t479)
  %t481 = insertvalue { i64, ptr } undef, i64 %t479, 0
  %t482 = insertvalue { i64, ptr } %t481, ptr %t480, 1
  %t484 = extractvalue { i64, ptr } %t482, 0
  %t485 = extractvalue { i64, ptr } %t482, 1
  %t486 = mul i64 %t484, 1
  %t487 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t486)
  call void @llvm.memcpy.p0.p0.i64(ptr %t487, ptr %t485, i64 %t486, i1 false)
  %t488 = insertvalue { i64, ptr } undef, i64 %t484, 0
  %t489 = insertvalue { i64, ptr } %t488, ptr %t487, 1
  %t491 = load ptr, ptr %lp3
  %t492 = getelementptr %"compiler/olang:CommandLine", ptr %t491, i32 0, i32 7
  store { i64, ptr } %t489, ptr %t492, !tbaa !27
  br label %bb101
bb100:
  br label %bb101
bb101:
  %t493 = load i64, ptr %l7, !tbaa !24
  %t495 = icmp eq i64 %t493, 5
  br i1 %t495, label %bb102, label %bb103
bb102:
  %t497 = load ptr, ptr %l1, !tbaa !29
  %t499 = getelementptr %"compiler/build:Config", ptr %t497, i32 0, i32 3
  %t500 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t501 = load ptr, ptr %l2, !tbaa !29
  %t505 = call i32 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eDefine(ptr %v1, ptr %s5, ptr %v2, ptr %t499, { i64, ptr } %t500, ptr %t501)
  store i32 %t505, ptr %l198
  %t506 = icmp ne i32 %t505, 0
  br i1 %t506, label %bb105, label %ok.507
ok.507:
  br label %bb104
bb103:
  br label %bb108
bb104:
  br label %bb107
bb105:
  %t508 = load i32, ptr %l198, !tbaa !23
  %t509 = ashr i32 %t508, 16
  %t511 = icmp eq i32 %t509, 1
  store i1 %t511, ptr %l200, !tbaa !21
  br label %bb106
bb106:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t513 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/olang:CommandLine" } %t513, ptr %rv
  br label %ret
bb107:
  br label %bb108
bb108:
  %t514 = load i64, ptr %l7, !tbaa !24
  %t516 = icmp eq i64 %t514, 6
  br i1 %t516, label %bb109, label %bb110
bb109:
  %t518 = load ptr, ptr %l1, !tbaa !29
  %t520 = getelementptr %"compiler/build:Config", ptr %t518, i32 0, i32 12
  store i1 true, ptr %t520, !tbaa !21
  br label %bb111
bb110:
  br label %bb111
bb111:
  %t521 = load i64, ptr %l7, !tbaa !24
  %t523 = icmp eq i64 %t521, 7
  br i1 %t523, label %bb112, label %bb113
bb112:
  %t525 = load ptr, ptr %lp3
  %t526 = getelementptr %"compiler/olang:CommandLine", ptr %t525, i32 0, i32 9
  store i1 true, ptr %t526, !tbaa !21
  br label %bb114
bb113:
  br label %bb114
bb114:
  %t527 = load i64, ptr %l7, !tbaa !24
  %t529 = icmp eq i64 %t527, 8
  br i1 %t529, label %bb115, label %bb116
bb115:
  %t531 = load ptr, ptr %l1, !tbaa !29
  %t533 = getelementptr %"compiler/build:Config", ptr %t531, i32 0, i32 5
  store i1 true, ptr %t533, !tbaa !21
  br label %bb117
bb116:
  br label %bb117
bb117:
  %t534 = load i64, ptr %l7, !tbaa !24
  %t536 = icmp eq i64 %t534, 9
  br i1 %t536, label %bb118, label %bb119
bb118:
  %t538 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t540 = extractvalue { i64, ptr } %t538, 1
  %t541 = extractvalue { i64, ptr } %t538, 0
  %t542 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t541)
  call void @olang_textcopy(ptr %t542, ptr %t540, i64 %t541)
  %t543 = insertvalue { i64, ptr } undef, i64 %t541, 0
  %t544 = insertvalue { i64, ptr } %t543, ptr %t542, 1
  %t546 = extractvalue { i64, ptr } %t544, 0
  %t547 = extractvalue { i64, ptr } %t544, 1
  %t548 = mul i64 %t546, 1
  %t549 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t548)
  call void @llvm.memcpy.p0.p0.i64(ptr %t549, ptr %t547, i64 %t548, i1 false)
  %t550 = insertvalue { i64, ptr } undef, i64 %t546, 0
  %t551 = insertvalue { i64, ptr } %t550, ptr %t549, 1
  %t553 = load ptr, ptr %lp3
  %t554 = getelementptr %"compiler/olang:CommandLine", ptr %t553, i32 0, i32 10
  store { i64, ptr } %t551, ptr %t554, !tbaa !27
  br label %bb120
bb119:
  br label %bb120
bb120:
  %t555 = load i64, ptr %l7, !tbaa !24
  %t557 = icmp eq i64 %t555, 10
  br i1 %t557, label %bb121, label %bb122
bb121:
  %t559 = load ptr, ptr %l1, !tbaa !29
  %t561 = getelementptr %"compiler/build:Config", ptr %t559, i32 0, i32 9
  store i1 true, ptr %t561, !tbaa !21
  br label %bb123
bb122:
  br label %bb123
bb123:
  %t562 = load i64, ptr %l7, !tbaa !24
  %t564 = icmp eq i64 %t562, 11
  br i1 %t564, label %bb124, label %bb125
bb124:
  %t566 = load ptr, ptr %l1, !tbaa !29
  %t568 = getelementptr %"compiler/build:Config", ptr %t566, i32 0, i32 8
  store i1 true, ptr %t568, !tbaa !21
  br label %bb126
bb125:
  br label %bb126
bb126:
  %t569 = load i64, ptr %l7, !tbaa !24
  %t571 = icmp eq i64 %t569, 12
  br i1 %t571, label %bb127, label %bb128
bb127:
  %t573 = load ptr, ptr %l1, !tbaa !29
  %t574 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t576 = extractvalue { i64, ptr } %t574, 1
  %t577 = extractvalue { i64, ptr } %t574, 0
  %t578 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t577)
  call void @olang_textcopy(ptr %t578, ptr %t576, i64 %t577)
  %t579 = insertvalue { i64, ptr } undef, i64 %t577, 0
  %t580 = insertvalue { i64, ptr } %t579, ptr %t578, 1
  %t582 = extractvalue { i64, ptr } %t580, 0
  %t583 = extractvalue { i64, ptr } %t580, 1
  %t584 = mul i64 %t582, 1
  %t585 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t584)
  call void @llvm.memcpy.p0.p0.i64(ptr %t585, ptr %t583, i64 %t584, i1 false)
  %t586 = insertvalue { i64, ptr } undef, i64 %t582, 0
  %t587 = insertvalue { i64, ptr } %t586, ptr %t585, 1
  %t590 = getelementptr %"compiler/build:Config", ptr %t573, i32 0, i32 10
  store { i64, ptr } %t587, ptr %t590, !tbaa !27
  br label %bb129
bb128:
  br label %bb129
bb129:
  %t591 = load i64, ptr %l7, !tbaa !24
  %t593 = icmp eq i64 %t591, 13
  br i1 %t593, label %bb130, label %bb131
bb130:
  store %olang.scope zeroinitializer, ptr %s38
  %t595 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t595, ptr %l230, !tbaa !27
  %t596 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s38, i64 10)
  %t597 = extractvalue { i32, i64 } %t596, 1
  %t598 = extractvalue { i32, i64 } %t596, 0
  store i32 %t598, ptr %l232
  %t599 = icmp ne i32 %t598, 0
  br i1 %t599, label %bb133, label %ok.600
ok.600:
  store i64 %t597, ptr %l231
  br label %bb132
bb131:
  br label %bb145
bb132:
  %t601 = load { i64, ptr }, ptr %l230, !tbaa !27
  %t602 = load i64, ptr %l231, !tbaa !24
  %t603 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s5, { i64, ptr } %t601, i64 %t602)
  %t604 = extractvalue { i32, i64 } %t603, 1
  %t605 = extractvalue { i32, i64 } %t603, 0
  store i32 %t605, ptr %l234
  %t606 = icmp ne i32 %t605, 0
  br i1 %t606, label %bb136, label %ok.607
ok.607:
  store i64 %t604, ptr %l233
  br label %bb135
bb133:
  br label %bb134
bb134:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l229, !tbaa !24
  br label %bb137
bb135:
  %t608 = load i64, ptr %l233, !tbaa !24
  store i64 %t608, ptr %l229, !tbaa !24
  br label %bb137
bb136:
  br label %bb134
bb137:
  %t609 = load i64, ptr %l229, !tbaa !24
  store i64 %t609, ptr %l20, !tbaa !24
  %t610 = load i64, ptr %l20, !tbaa !24
  %t612 = icmp slt i64 %t610, 1
  br i1 %t612, label %bb138, label %bb139
bb138:
  store %olang.scope zeroinitializer, ptr %s39
  %t614 = load ptr, ptr %l2, !tbaa !29
  store ptr %t614, ptr %l237, !tbaa !29
  %t615 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t617 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eFuzzTimeNotNumber(ptr %s5, ptr %s39, { i64, ptr } %t615)
  store %"compiler/msgs:Msg" %t617, ptr %l239
  br label %bb140
bb139:
  br label %bb144
bb140:
  %t618 = load ptr, ptr %l237, !tbaa !29
  %t619 = load %"compiler/msgs:Msg", ptr %l239
  %t620 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s39, ptr %t618, %"compiler/msgs:Msg" %t619)
  store i32 %t620, ptr %l240
  %t621 = icmp ne i32 %t620, 0
  br i1 %t621, label %bb142, label %ok.622
ok.622:
  br label %bb141
bb141:
  br label %bb143
bb142:
  %t623 = load i32, ptr %l240, !tbaa !23
  %t624 = lshr i32 %t623, 16
  %t625 = and i32 %t623, 65535
  %t626 = icmp eq i32 %t624, 1
  %t627 = select i1 %t626, i32 1, i32 0
  %t628 = icmp eq i32 %t623, 0
  %t629 = shl i32 %t627, 16
  %t630 = or i32 %t629, %t625
  %t631 = select i1 %t628, i32 0, i32 %t630
  call void @__olang_scope_close(ptr %s39)
  call void @__olang_scope_close(ptr %s38)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t633 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t631, 0
  store { i32, %"compiler/olang:CommandLine" } %t633, ptr %rv
  br label %ret
bb143:
  call void @__olang_scope_close(ptr %s39)
  br label %bb144
bb144:
  %t634 = load ptr, ptr %l1, !tbaa !29
  %t635 = load i64, ptr %l20, !tbaa !24
  %t638 = getelementptr %"compiler/build:Config", ptr %t634, i32 0, i32 11
  store i64 %t635, ptr %t638, !tbaa !24
  call void @__olang_scope_close(ptr %s38)
  br label %bb145
bb145:
  %t639 = load ptr, ptr %l1, !tbaa !29
  %t641 = getelementptr %"compiler/build:Config", ptr %t639, i32 0, i32 5
  %t642 = load i1, ptr %t641, !tbaa !21
  br i1 %t642, label %bb146, label %bb147
bb146:
  %t644 = load ptr, ptr %l1, !tbaa !29
  %t646 = getelementptr %"compiler/build:Config", ptr %t644, i32 0, i32 4
  %t647 = load i1, ptr %t646, !tbaa !21
  br i1 %t647, label %bb148, label %bb149
bb147:
  store i1 false, ptr %l246, !tbaa !21
  br label %bb151
bb148:
  store i1 true, ptr %l249, !tbaa !21
  br label %bb150
bb149:
  %t649 = load ptr, ptr %l1, !tbaa !29
  %t651 = getelementptr %"compiler/build:Config", ptr %t649, i32 0, i32 6
  %t652 = load i1, ptr %t651, !tbaa !21
  store i1 %t652, ptr %l249, !tbaa !21
  br label %bb150
bb150:
  %t654 = load i1, ptr %l249, !tbaa !21
  store i1 %t654, ptr %l246, !tbaa !21
  br label %bb151
bb151:
  %t655 = load i1, ptr %l246, !tbaa !21
  br i1 %t655, label %bb152, label %bb153
bb152:
  store %olang.scope zeroinitializer, ptr %s40
  %t656 = load ptr, ptr %l2, !tbaa !29
  store ptr %t656, ptr %l252, !tbaa !29
  %t657 = load ptr, ptr %l1, !tbaa !29
  %t659 = getelementptr %"compiler/build:Config", ptr %t657, i32 0, i32 4
  %t660 = load i1, ptr %t659, !tbaa !21
  br i1 %t660, label %bb154, label %bb155
bb153:
  br label %bb161
bb154:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d85, i32 0, i32 1) }, ptr %l255, !tbaa !27
  br label %bb156
bb155:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d86, i32 0, i32 1) }, ptr %l255, !tbaa !27
  br label %bb156
bb156:
  %t662 = load { i64, ptr }, ptr %l255, !tbaa !27
  %t663 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eQuickAlone(ptr %s40, ptr %s40, { i64, ptr } %t662)
  store %"compiler/msgs:Msg" %t663, ptr %l256
  br label %bb157
bb157:
  %t664 = load ptr, ptr %l252, !tbaa !29
  %t665 = load %"compiler/msgs:Msg", ptr %l256
  %t666 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s40, ptr %t664, %"compiler/msgs:Msg" %t665)
  store i32 %t666, ptr %l257
  %t667 = icmp ne i32 %t666, 0
  br i1 %t667, label %bb159, label %ok.668
ok.668:
  br label %bb158
bb158:
  br label %bb160
bb159:
  %t669 = load i32, ptr %l257, !tbaa !23
  %t670 = lshr i32 %t669, 16
  %t671 = and i32 %t669, 65535
  %t672 = icmp eq i32 %t670, 1
  %t673 = select i1 %t672, i32 1, i32 0
  %t674 = icmp eq i32 %t669, 0
  %t675 = shl i32 %t673, 16
  %t676 = or i32 %t675, %t671
  %t677 = select i1 %t674, i32 0, i32 %t676
  call void @__olang_scope_close(ptr %s40)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t679 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t677, 0
  store { i32, %"compiler/olang:CommandLine" } %t679, ptr %rv
  br label %ret
bb160:
  call void @__olang_scope_close(ptr %s40)
  br label %bb161
bb161:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  br label %bb267
bb162:
  %t680 = load ptr, ptr %lp3
  %t681 = getelementptr %"compiler/olang:CommandLine", ptr %t680, i32 0, i32 0
  %t682 = load i64, ptr %t681, !tbaa !24
  %t683 = load i64, ptr @G_2ecompiler_2folang_2eDoc, !tbaa !24
  %t686 = icmp eq i64 %t682, %t683
  br i1 %t686, label %bb163, label %bb164
bb163:
  %t688 = load ptr, ptr %lp3
  %t689 = getelementptr %"compiler/olang:CommandLine", ptr %t688, i32 0, i32 10
  %t690 = load { i64, ptr }, ptr %t689, !tbaa !27
  %t692 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s4, { i64, ptr } %t690, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d87, i32 0, i32 1) })
  store i1 %t692, ptr %l264
  br label %bb165
bb164:
  store i1 false, ptr %l262, !tbaa !21
  br label %bb166
bb165:
  %t693 = load i1, ptr %l264, !tbaa !21
  store i1 %t693, ptr %l262, !tbaa !21
  br label %bb166
bb166:
  %t694 = load i1, ptr %l262, !tbaa !21
  br i1 %t694, label %bb167, label %bb168
bb167:
  %t695 = load ptr, ptr %lp3
  %t696 = getelementptr %"compiler/olang:CommandLine", ptr %t695, i32 0, i32 1
  %t698 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v3, ptr %t696)
  store i64 %t698, ptr %l267
  br label %bb169
bb168:
  store i1 false, ptr %l265, !tbaa !21
  br label %bb170
bb169:
  %t699 = load i64, ptr %l267, !tbaa !24
  %t700 = icmp eq i64 %t699, 1
  store i1 %t700, ptr %l265, !tbaa !21
  br label %bb170
bb170:
  %t702 = load i1, ptr %l265, !tbaa !21
  br i1 %t702, label %bb171, label %bb172
bb171:
  %t703 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t705 = call i1 @compiler_2folang_2eendsWithOlang(ptr %v0, { i64, ptr } %t703)
  store i1 %t705, ptr %l271
  br label %bb173
bb172:
  store i1 false, ptr %l269, !tbaa !21
  br label %bb174
bb173:
  %t706 = load i1, ptr %l271, !tbaa !21
  %t707 = xor i1 %t706, true
  store i1 %t707, ptr %l269, !tbaa !21
  br label %bb174
bb174:
  %t709 = load i1, ptr %l269, !tbaa !21
  br i1 %t709, label %bb175, label %bb176
bb175:
  %t710 = load ptr, ptr %lp3
  %t711 = getelementptr %"compiler/olang:CommandLine", ptr %t710, i32 0, i32 4
  %t712 = load i1, ptr %t711, !tbaa !21
  br i1 %t712, label %bb177, label %bb178
bb176:
  br label %bb185
bb177:
  store %olang.scope zeroinitializer, ptr %s42
  %t714 = load ptr, ptr %l2, !tbaa !29
  store ptr %t714, ptr %l274, !tbaa !29
  %t715 = load ptr, ptr %lp3
  %t716 = getelementptr %"compiler/olang:CommandLine", ptr %t715, i32 0, i32 1
  %t718 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v3, ptr %v3, ptr %t716, i64 0)
  store { i64, ptr } %t718, ptr %l276
  br label %bb179
bb178:
  br label %bb184
bb179:
  %t719 = load { i64, ptr }, ptr %l276, !tbaa !27
  %t720 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDocOneName(ptr %v3, ptr %s42, { i64, ptr } %t719)
  store %"compiler/msgs:Msg" %t720, ptr %l277
  br label %bb180
bb180:
  %t721 = load ptr, ptr %l274, !tbaa !29
  %t722 = load %"compiler/msgs:Msg", ptr %l277
  %t723 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s42, ptr %t721, %"compiler/msgs:Msg" %t722)
  store i32 %t723, ptr %l278
  %t724 = icmp ne i32 %t723, 0
  br i1 %t724, label %bb182, label %ok.725
ok.725:
  br label %bb181
bb181:
  br label %bb183
bb182:
  %t726 = load i32, ptr %l278, !tbaa !23
  %t727 = lshr i32 %t726, 16
  %t728 = and i32 %t726, 65535
  %t729 = icmp eq i32 %t727, 1
  %t730 = select i1 %t729, i32 1, i32 0
  %t731 = icmp eq i32 %t726, 0
  %t732 = shl i32 %t730, 16
  %t733 = or i32 %t732, %t728
  %t734 = select i1 %t731, i32 0, i32 %t733
  call void @__olang_scope_close(ptr %s42)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t736 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t734, 0
  store { i32, %"compiler/olang:CommandLine" } %t736, ptr %rv
  br label %ret
bb183:
  call void @__olang_scope_close(ptr %s42)
  br label %bb184
bb184:
  %t737 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t739 = extractvalue { i64, ptr } %t737, 1
  %t740 = extractvalue { i64, ptr } %t737, 0
  %t741 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t740)
  call void @olang_textcopy(ptr %t741, ptr %t739, i64 %t740)
  %t742 = insertvalue { i64, ptr } undef, i64 %t740, 0
  %t743 = insertvalue { i64, ptr } %t742, ptr %t741, 1
  %t745 = extractvalue { i64, ptr } %t743, 0
  %t746 = extractvalue { i64, ptr } %t743, 1
  %t747 = mul i64 %t745, 1
  %t748 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t747)
  call void @llvm.memcpy.p0.p0.i64(ptr %t748, ptr %t746, i64 %t747, i1 false)
  %t749 = insertvalue { i64, ptr } undef, i64 %t745, 0
  %t750 = insertvalue { i64, ptr } %t749, ptr %t748, 1
  %t752 = load ptr, ptr %lp3
  %t753 = getelementptr %"compiler/olang:CommandLine", ptr %t752, i32 0, i32 3
  store { i64, ptr } %t750, ptr %t753, !tbaa !27
  %t754 = load ptr, ptr %lp3
  %t755 = getelementptr %"compiler/olang:CommandLine", ptr %t754, i32 0, i32 4
  store i1 true, ptr %t755, !tbaa !21
  call void @__olang_scope_close(ptr %s4)
  br label %bb267
bb185:
  %t756 = load ptr, ptr %lp3
  %t757 = getelementptr %"compiler/olang:CommandLine", ptr %t756, i32 0, i32 0
  %t758 = load i64, ptr %t757, !tbaa !24
  %t759 = load i64, ptr @G_2ecompiler_2folang_2eExplain, !tbaa !24
  %t762 = icmp eq i64 %t758, %t759
  br i1 %t762, label %bb186, label %bb187
bb186:
  store i1 true, ptr %l286, !tbaa !21
  br label %bb188
bb187:
  %t764 = load ptr, ptr %lp3
  %t765 = getelementptr %"compiler/olang:CommandLine", ptr %t764, i32 0, i32 0
  %t766 = load i64, ptr %t765, !tbaa !24
  %t767 = load i64, ptr @G_2ecompiler_2folang_2eHelp, !tbaa !24
  %t770 = icmp eq i64 %t766, %t767
  store i1 %t770, ptr %l286, !tbaa !21
  br label %bb188
bb188:
  %t772 = load i1, ptr %l286, !tbaa !21
  br i1 %t772, label %bb189, label %bb190
bb189:
  %t773 = load ptr, ptr %lp3
  %t774 = getelementptr %"compiler/olang:CommandLine", ptr %t773, i32 0, i32 0
  %t775 = load i64, ptr %t774, !tbaa !24
  %t776 = load i64, ptr @G_2ecompiler_2folang_2eExplain, !tbaa !24
  %t779 = icmp eq i64 %t775, %t776
  br i1 %t779, label %bb191, label %bb192
bb190:
  br label %bb217
bb191:
  %t781 = load ptr, ptr %lp3
  %t782 = getelementptr %"compiler/olang:CommandLine", ptr %t781, i32 0, i32 4
  %t783 = load i1, ptr %t782, !tbaa !21
  store i1 %t783, ptr %l293, !tbaa !21
  br label %bb193
bb192:
  store i1 false, ptr %l293, !tbaa !21
  br label %bb193
bb193:
  %t785 = load i1, ptr %l293, !tbaa !21
  br i1 %t785, label %bb194, label %bb195
bb194:
  %t786 = load ptr, ptr %lp3
  %t787 = getelementptr %"compiler/olang:CommandLine", ptr %t786, i32 0, i32 1
  %t789 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v3, ptr %t787)
  store i64 %t789, ptr %l297
  br label %bb196
bb195:
  store i1 false, ptr %l295, !tbaa !21
  br label %bb197
bb196:
  %t790 = load i64, ptr %l297, !tbaa !24
  %t791 = icmp eq i64 %t790, 0
  store i1 %t791, ptr %l295, !tbaa !21
  br label %bb197
bb197:
  %t793 = load i1, ptr %l295, !tbaa !21
  br i1 %t793, label %bb198, label %bb199
bb198:
  %t794 = load ptr, ptr %lp3
  %t795 = getelementptr %"compiler/olang:CommandLine", ptr %t794, i32 0, i32 3
  %t796 = load { i64, ptr }, ptr %t795, !tbaa !27
  %t798 = call i1 @compiler_2folang_2eendsWithOlang(ptr %v3, { i64, ptr } %t796)
  store i1 %t798, ptr %l301
  br label %bb200
bb199:
  store i1 false, ptr %l299, !tbaa !21
  br label %bb201
bb200:
  %t799 = load i1, ptr %l301, !tbaa !21
  store i1 %t799, ptr %l299, !tbaa !21
  br label %bb201
bb201:
  %t800 = load i1, ptr %l299, !tbaa !21
  br i1 %t800, label %bb202, label %bb203
bb202:
  %t801 = load ptr, ptr %lp3
  %t802 = getelementptr %"compiler/olang:CommandLine", ptr %t801, i32 0, i32 1
  %t803 = load ptr, ptr %lp3
  %t804 = getelementptr %"compiler/olang:CommandLine", ptr %t803, i32 0, i32 3
  %t805 = load { i64, ptr }, ptr %t804, !tbaa !27
  %t807 = extractvalue { i64, ptr } %t805, 1
  %t808 = extractvalue { i64, ptr } %t805, 0
  %t809 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t808)
  call void @olang_textcopy(ptr %t809, ptr %t807, i64 %t808)
  %t810 = insertvalue { i64, ptr } undef, i64 %t808, 0
  %t811 = insertvalue { i64, ptr } %t810, ptr %t809, 1
  %t813 = extractvalue { i64, ptr } %t811, 0
  %t814 = extractvalue { i64, ptr } %t811, 1
  %t815 = mul i64 %t813, 1
  %t816 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t815)
  call void @llvm.memcpy.p0.p0.i64(ptr %t816, ptr %t814, i64 %t815, i1 false)
  %t817 = insertvalue { i64, ptr } undef, i64 %t813, 0
  %t818 = insertvalue { i64, ptr } %t817, ptr %t816, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v3, ptr %v3, ptr %t802, { i64, ptr } %t818)
  br label %bb204
bb203:
  br label %bb205
bb204:
  %t821 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t823 = extractvalue { i64, ptr } %t821, 1
  %t824 = extractvalue { i64, ptr } %t821, 0
  %t825 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t824)
  call void @olang_textcopy(ptr %t825, ptr %t823, i64 %t824)
  %t826 = insertvalue { i64, ptr } undef, i64 %t824, 0
  %t827 = insertvalue { i64, ptr } %t826, ptr %t825, 1
  %t829 = extractvalue { i64, ptr } %t827, 0
  %t830 = extractvalue { i64, ptr } %t827, 1
  %t831 = mul i64 %t829, 1
  %t832 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t831)
  call void @llvm.memcpy.p0.p0.i64(ptr %t832, ptr %t830, i64 %t831, i1 false)
  %t833 = insertvalue { i64, ptr } undef, i64 %t829, 0
  %t834 = insertvalue { i64, ptr } %t833, ptr %t832, 1
  %t836 = load ptr, ptr %lp3
  %t837 = getelementptr %"compiler/olang:CommandLine", ptr %t836, i32 0, i32 3
  store { i64, ptr } %t834, ptr %t837, !tbaa !27
  call void @__olang_scope_close(ptr %s4)
  br label %bb267
bb205:
  %t838 = load ptr, ptr %lp3
  %t839 = getelementptr %"compiler/olang:CommandLine", ptr %t838, i32 0, i32 4
  %t840 = load i1, ptr %t839, !tbaa !21
  br i1 %t840, label %bb206, label %bb207
bb206:
  store %olang.scope zeroinitializer, ptr %s48
  %t842 = load ptr, ptr %l2, !tbaa !29
  store ptr %t842, ptr %l310, !tbaa !29
  %t843 = load ptr, ptr %lp3
  %t844 = getelementptr %"compiler/olang:CommandLine", ptr %t843, i32 0, i32 0
  %t845 = load i64, ptr %t844, !tbaa !24
  %t846 = load i64, ptr @G_2ecompiler_2folang_2eExplain, !tbaa !24
  %t849 = icmp eq i64 %t845, %t846
  br i1 %t849, label %bb208, label %bb209
bb207:
  br label %bb216
bb208:
  %t851 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eExplainNeedsRule(ptr %s48)
  store %"compiler/msgs:Msg" %t851, ptr %l315
  br label %bb210
bb209:
  %t852 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eHelpOneMode(ptr %s48)
  store %"compiler/msgs:Msg" %t852, ptr %l316
  br label %bb211
bb210:
  %t853 = load %"compiler/msgs:Msg", ptr %l315
  store %"compiler/msgs:Msg" %t853, ptr %l314
  br label %bb212
bb211:
  %t854 = load %"compiler/msgs:Msg", ptr %l316
  store %"compiler/msgs:Msg" %t854, ptr %l314
  br label %bb212
bb212:
  %t855 = load ptr, ptr %l310, !tbaa !29
  %t856 = load %"compiler/msgs:Msg", ptr %l314
  %t857 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s48, ptr %t855, %"compiler/msgs:Msg" %t856)
  store i32 %t857, ptr %l317
  %t858 = icmp ne i32 %t857, 0
  br i1 %t858, label %bb214, label %ok.859
ok.859:
  br label %bb213
bb213:
  br label %bb215
bb214:
  %t860 = load i32, ptr %l317, !tbaa !23
  %t861 = lshr i32 %t860, 16
  %t862 = and i32 %t860, 65535
  %t863 = icmp eq i32 %t861, 1
  %t864 = select i1 %t863, i32 1, i32 0
  %t865 = icmp eq i32 %t860, 0
  %t866 = shl i32 %t864, 16
  %t867 = or i32 %t866, %t862
  %t868 = select i1 %t865, i32 0, i32 %t867
  call void @__olang_scope_close(ptr %s48)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t870 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t868, 0
  store { i32, %"compiler/olang:CommandLine" } %t870, ptr %rv
  br label %ret
bb215:
  call void @__olang_scope_close(ptr %s48)
  br label %bb216
bb216:
  %t871 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t873 = extractvalue { i64, ptr } %t871, 1
  %t874 = extractvalue { i64, ptr } %t871, 0
  %t875 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t874)
  call void @olang_textcopy(ptr %t875, ptr %t873, i64 %t874)
  %t876 = insertvalue { i64, ptr } undef, i64 %t874, 0
  %t877 = insertvalue { i64, ptr } %t876, ptr %t875, 1
  %t879 = extractvalue { i64, ptr } %t877, 0
  %t880 = extractvalue { i64, ptr } %t877, 1
  %t881 = mul i64 %t879, 1
  %t882 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t881)
  call void @llvm.memcpy.p0.p0.i64(ptr %t882, ptr %t880, i64 %t881, i1 false)
  %t883 = insertvalue { i64, ptr } undef, i64 %t879, 0
  %t884 = insertvalue { i64, ptr } %t883, ptr %t882, 1
  %t886 = load ptr, ptr %lp3
  %t887 = getelementptr %"compiler/olang:CommandLine", ptr %t886, i32 0, i32 3
  store { i64, ptr } %t884, ptr %t887, !tbaa !27
  %t888 = load ptr, ptr %lp3
  %t889 = getelementptr %"compiler/olang:CommandLine", ptr %t888, i32 0, i32 4
  store i1 true, ptr %t889, !tbaa !21
  call void @__olang_scope_close(ptr %s4)
  br label %bb267
bb217:
  %t890 = load ptr, ptr %lp3
  %t891 = getelementptr %"compiler/olang:CommandLine", ptr %t890, i32 0, i32 0
  %t892 = load i64, ptr %t891, !tbaa !24
  %t893 = load i64, ptr @G_2ecompiler_2folang_2eRun, !tbaa !24
  %t896 = icmp eq i64 %t892, %t893
  br i1 %t896, label %bb218, label %bb219
bb218:
  %t898 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t900 = call i1 @compiler_2folang_2eendsWithOlang(ptr %v0, { i64, ptr } %t898)
  store i1 %t900, ptr %l327
  br label %bb220
bb219:
  store i1 false, ptr %l325, !tbaa !21
  br label %bb221
bb220:
  %t901 = load i1, ptr %l327, !tbaa !21
  %t902 = xor i1 %t901, true
  store i1 %t902, ptr %l325, !tbaa !21
  br label %bb221
bb221:
  %t904 = load i1, ptr %l325, !tbaa !21
  br i1 %t904, label %bb222, label %bb223
bb222:
  store %olang.scope zeroinitializer, ptr %s50
  %t905 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t907 = call i64 @compiler_2folang_2emodeNumber(ptr %v0, { i64, ptr } %t905)
  store i64 %t907, ptr %l330
  br label %bb224
bb223:
  br label %bb236
bb224:
  %t908 = load i64, ptr %l330, !tbaa !24
  %t909 = icmp sgt i64 %t908, 0
  br i1 %t909, label %bb225, label %bb226
bb225:
  store %olang.scope zeroinitializer, ptr %s51
  %t911 = load ptr, ptr %l2, !tbaa !29
  store ptr %t911, ptr %l332, !tbaa !29
  %t912 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t914 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eModeFirst(ptr %v0, ptr %s51, { i64, ptr } %t912)
  store %"compiler/msgs:Msg" %t914, ptr %l334
  br label %bb227
bb226:
  br label %bb231
bb227:
  %t915 = load ptr, ptr %l332, !tbaa !29
  %t916 = load %"compiler/msgs:Msg", ptr %l334
  %t917 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s51, ptr %t915, %"compiler/msgs:Msg" %t916)
  store i32 %t917, ptr %l335
  %t918 = icmp ne i32 %t917, 0
  br i1 %t918, label %bb229, label %ok.919
ok.919:
  br label %bb228
bb228:
  br label %bb230
bb229:
  %t920 = load i32, ptr %l335, !tbaa !23
  %t921 = lshr i32 %t920, 16
  %t922 = and i32 %t920, 65535
  %t923 = icmp eq i32 %t921, 1
  %t924 = select i1 %t923, i32 1, i32 0
  %t925 = icmp eq i32 %t920, 0
  %t926 = shl i32 %t924, 16
  %t927 = or i32 %t926, %t922
  %t928 = select i1 %t925, i32 0, i32 %t927
  call void @__olang_scope_close(ptr %s51)
  call void @__olang_scope_close(ptr %s50)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t930 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t928, 0
  store { i32, %"compiler/olang:CommandLine" } %t930, ptr %rv
  br label %ret
bb230:
  call void @__olang_scope_close(ptr %s51)
  br label %bb231
bb231:
  %t931 = load ptr, ptr %l2, !tbaa !29
  store ptr %t931, ptr %l337, !tbaa !29
  %t932 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t934 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotASource(ptr %v0, ptr %s50, { i64, ptr } %t932)
  store %"compiler/msgs:Msg" %t934, ptr %l339
  br label %bb232
bb232:
  %t935 = load ptr, ptr %l337, !tbaa !29
  %t936 = load %"compiler/msgs:Msg", ptr %l339
  %t937 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s50, ptr %t935, %"compiler/msgs:Msg" %t936)
  store i32 %t937, ptr %l340
  %t938 = icmp ne i32 %t937, 0
  br i1 %t938, label %bb234, label %ok.939
ok.939:
  br label %bb233
bb233:
  br label %bb235
bb234:
  %t940 = load i32, ptr %l340, !tbaa !23
  %t941 = lshr i32 %t940, 16
  %t942 = and i32 %t940, 65535
  %t943 = icmp eq i32 %t941, 1
  %t944 = select i1 %t943, i32 1, i32 0
  %t945 = icmp eq i32 %t940, 0
  %t946 = shl i32 %t944, 16
  %t947 = or i32 %t946, %t942
  %t948 = select i1 %t945, i32 0, i32 %t947
  call void @__olang_scope_close(ptr %s50)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t950 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t948, 0
  store { i32, %"compiler/olang:CommandLine" } %t950, ptr %rv
  br label %ret
bb235:
  call void @__olang_scope_close(ptr %s50)
  br label %bb236
bb236:
  %t951 = load ptr, ptr %lp3
  %t952 = getelementptr %"compiler/olang:CommandLine", ptr %t951, i32 0, i32 0
  %t953 = load i64, ptr %t952, !tbaa !24
  %t954 = load i64, ptr @G_2ecompiler_2folang_2eTest, !tbaa !24
  %t957 = icmp eq i64 %t953, %t954
  br i1 %t957, label %bb237, label %bb238
bb237:
  %t959 = load ptr, ptr %lp3
  %t960 = getelementptr %"compiler/olang:CommandLine", ptr %t959, i32 0, i32 1
  %t962 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v3, ptr %t960)
  store i64 %t962, ptr %l347
  br label %bb239
bb238:
  store i1 false, ptr %l345, !tbaa !21
  br label %bb240
bb239:
  %t963 = load i64, ptr %l347, !tbaa !24
  %t964 = icmp sgt i64 %t963, 0
  store i1 %t964, ptr %l345, !tbaa !21
  br label %bb240
bb240:
  %t966 = load i1, ptr %l345, !tbaa !21
  br i1 %t966, label %bb241, label %bb242
bb241:
  %t967 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t969 = call i1 @compiler_2folang_2eendsWithOlang(ptr %v0, { i64, ptr } %t967)
  store i1 %t969, ptr %l351
  br label %bb243
bb242:
  store i1 false, ptr %l349, !tbaa !21
  br label %bb244
bb243:
  %t970 = load i1, ptr %l351, !tbaa !21
  %t971 = xor i1 %t970, true
  store i1 %t971, ptr %l349, !tbaa !21
  br label %bb244
bb244:
  %t973 = load i1, ptr %l349, !tbaa !21
  br i1 %t973, label %bb245, label %bb246
bb245:
  %t974 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t976 = call i1 @std_2fos_2eExists(ptr %v0, { i64, ptr } %t974)
  store i1 %t976, ptr %l355
  br label %bb247
bb246:
  store i1 false, ptr %l353, !tbaa !21
  br label %bb248
bb247:
  %t977 = load i1, ptr %l355, !tbaa !21
  %t978 = xor i1 %t977, true
  store i1 %t978, ptr %l353, !tbaa !21
  br label %bb248
bb248:
  %t980 = load i1, ptr %l353, !tbaa !21
  br i1 %t980, label %bb249, label %bb250
bb249:
  %t981 = load ptr, ptr %lp3
  %t982 = getelementptr %"compiler/olang:CommandLine", ptr %t981, i32 0, i32 2
  %t983 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t985 = extractvalue { i64, ptr } %t983, 1
  %t986 = extractvalue { i64, ptr } %t983, 0
  %t987 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t986)
  call void @olang_textcopy(ptr %t987, ptr %t985, i64 %t986)
  %t988 = insertvalue { i64, ptr } undef, i64 %t986, 0
  %t989 = insertvalue { i64, ptr } %t988, ptr %t987, 1
  %t991 = extractvalue { i64, ptr } %t989, 0
  %t992 = extractvalue { i64, ptr } %t989, 1
  %t993 = mul i64 %t991, 1
  %t994 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t993)
  call void @llvm.memcpy.p0.p0.i64(ptr %t994, ptr %t992, i64 %t993, i1 false)
  %t995 = insertvalue { i64, ptr } undef, i64 %t991, 0
  %t996 = insertvalue { i64, ptr } %t995, ptr %t994, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v3, ptr %v3, ptr %t982, { i64, ptr } %t996)
  br label %bb251
bb250:
  br label %bb252
bb251:
  call void @__olang_scope_close(ptr %s4)
  br label %bb267
bb252:
  %t999 = load ptr, ptr %lp3
  %t1000 = getelementptr %"compiler/olang:CommandLine", ptr %t999, i32 0, i32 1
  %t1001 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t1003 = extractvalue { i64, ptr } %t1001, 1
  %t1004 = extractvalue { i64, ptr } %t1001, 0
  %t1005 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t1004)
  call void @olang_textcopy(ptr %t1005, ptr %t1003, i64 %t1004)
  %t1006 = insertvalue { i64, ptr } undef, i64 %t1004, 0
  %t1007 = insertvalue { i64, ptr } %t1006, ptr %t1005, 1
  %t1009 = extractvalue { i64, ptr } %t1007, 0
  %t1010 = extractvalue { i64, ptr } %t1007, 1
  %t1011 = mul i64 %t1009, 1
  %t1012 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t1011)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1012, ptr %t1010, i64 %t1011, i1 false)
  %t1013 = insertvalue { i64, ptr } undef, i64 %t1009, 0
  %t1014 = insertvalue { i64, ptr } %t1013, ptr %t1012, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v3, ptr %v3, ptr %t1000, { i64, ptr } %t1014)
  br label %bb253
bb253:
  %t1017 = load ptr, ptr %lp3
  %t1018 = getelementptr %"compiler/olang:CommandLine", ptr %t1017, i32 0, i32 0
  %t1019 = load i64, ptr %t1018, !tbaa !24
  %t1020 = load i64, ptr @G_2ecompiler_2folang_2eRun, !tbaa !24
  %t1023 = icmp eq i64 %t1019, %t1020
  br i1 %t1023, label %bb254, label %bb255
bb254:
  store i1 true, ptr %l368, !tbaa !21
  br label %bb256
bb255:
  %t1025 = load ptr, ptr %lp3
  %t1026 = getelementptr %"compiler/olang:CommandLine", ptr %t1025, i32 0, i32 0
  %t1027 = load i64, ptr %t1026, !tbaa !24
  %t1028 = load i64, ptr @G_2ecompiler_2folang_2eInterp, !tbaa !24
  %t1031 = icmp eq i64 %t1027, %t1028
  store i1 %t1031, ptr %l368, !tbaa !21
  br label %bb256
bb256:
  %t1033 = load i1, ptr %l368, !tbaa !21
  br i1 %t1033, label %bb257, label %bb258
bb257:
  br label %bb259
bb258:
  br label %bb266
bb259:
  %t1034 = load i64, ptr %l4, !tbaa !24
  %t1035 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t1037 = extractvalue { i64, ptr } %t1035, 0
  %t1040 = icmp slt i64 %t1034, %t1037
  %t1042 = xor i1 %t1040, true
  br i1 %t1042, label %bb260, label %bb261
bb260:
  br label %bb265
bb261:
  br label %bb262
bb262:
  %t1044 = load ptr, ptr %lp3
  %t1045 = getelementptr %"compiler/olang:CommandLine", ptr %t1044, i32 0, i32 5
  %t1046 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1046, ptr %l378, !tbaa !27
  %t1047 = load i64, ptr %l4, !tbaa !24
  %t1049 = getelementptr { i64, ptr }, ptr %l378, i32 0, i32 1
  %t1050 = load ptr, ptr %t1049, !tbaa !27
  %t1051 = getelementptr { i64, ptr }, ptr %t1050, i64 %t1047
  %t1052 = load { i64, ptr }, ptr %t1051, !tbaa !37
  %t1054 = extractvalue { i64, ptr } %t1052, 1
  %t1055 = extractvalue { i64, ptr } %t1052, 0
  %t1056 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t1055)
  call void @olang_textcopy(ptr %t1056, ptr %t1054, i64 %t1055)
  %t1057 = insertvalue { i64, ptr } undef, i64 %t1055, 0
  %t1058 = insertvalue { i64, ptr } %t1057, ptr %t1056, 1
  %t1060 = extractvalue { i64, ptr } %t1058, 0
  %t1061 = extractvalue { i64, ptr } %t1058, 1
  %t1062 = mul i64 %t1060, 1
  %t1063 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t1062)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1063, ptr %t1061, i64 %t1062, i1 false)
  %t1064 = insertvalue { i64, ptr } undef, i64 %t1060, 0
  %t1065 = insertvalue { i64, ptr } %t1064, ptr %t1063, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v3, ptr %v3, ptr %t1045, { i64, ptr } %t1065)
  br label %bb263
bb263:
  %t1068 = load i64, ptr %l4, !tbaa !24
  %t1070 = add i64 %t1068, 1
  store i64 %t1070, ptr %l4, !tbaa !24
  br label %bb264
bb264:
  br label %bb259
bb265:
  br label %bb266
bb266:
  call void @__olang_scope_close(ptr %s4)
  br label %bb267
bb267:
  br label %bb25
bb268:
  %t1072 = load ptr, ptr %lp3
  %t1073 = load %"compiler/olang:CommandLine", ptr %t1072
  call void @__olang_scope_close(ptr %s0)
  %t1075 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, %"compiler/olang:CommandLine" %t1073, 1
  store { i32, %"compiler/olang:CommandLine" } %t1075, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/olang:CommandLine" }, ptr %rv
  ret { i32, %"compiler/olang:CommandLine" } %rr
}

define dso_local { i32, %"compiler/olang:CommandLine" } @compiler_2folang_2ePrepare(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %lp3 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca i1
  %l6 = alloca %"compiler/olang:CommandLine"
  %l10 = alloca %"compiler/olang:CommandLine"
  %l11 = alloca i32
  %l22 = alloca ptr
  %l23 = alloca %"compiler/msgs:Msg"
  %l24 = alloca i32
  %l27 = alloca i64
  %l30 = alloca i1
  %l31 = alloca ptr
  %l33 = alloca %"compiler/msgs:Msg"
  %l34 = alloca i32
  %l40 = alloca i1
  %l44 = alloca i1
  %l46 = alloca i64
  %l48 = alloca ptr
  %l50 = alloca { i64, ptr }
  %l52 = alloca %"compiler/msgs:Msg"
  %l53 = alloca i32
  %l58 = alloca i1
  %l60 = alloca i1
  %l61 = alloca i1
  %l63 = alloca i64
  %l65 = alloca ptr
  %l67 = alloca i64
  %l69 = alloca %"compiler/msgs:Msg"
  %l71 = alloca { i64, ptr }
  %l73 = alloca %"compiler/msgs:Msg"
  %l75 = alloca { i64, ptr }
  %l77 = alloca %"compiler/msgs:Msg"
  %l78 = alloca i32
  %l81 = alloca i64
  %l83 = alloca i1
  %l87 = alloca i1
  %l91 = alloca i1
  %l95 = alloca ptr
  %l97 = alloca { i64, ptr }
  %l99 = alloca %"compiler/msgs:Msg"
  %l100 = alloca i32
  %l105 = alloca i1
  %l109 = alloca i1
  %l113 = alloca i1
  %l115 = alloca i64
  %l117 = alloca ptr
  %l119 = alloca { i64, ptr }
  %l121 = alloca %"compiler/msgs:Msg"
  %l122 = alloca i32
  %l127 = alloca i1
  %l130 = alloca i1
  %l131 = alloca ptr
  %l132 = alloca %"compiler/msgs:Msg"
  %l133 = alloca i32
  %l137 = alloca i1
  %l139 = alloca i1
  %l141 = alloca i64
  %l143 = alloca ptr
  %l144 = alloca %"compiler/msgs:Msg"
  %l145 = alloca i32
  %l150 = alloca i1
  %l156 = alloca i1
  %l160 = alloca i32
  %l170 = alloca ptr
  %l171 = alloca { i64, ptr }
  %l173 = alloca ptr
  %l174 = alloca { i64, ptr }
  %l175 = alloca { i64, ptr }
  %l176 = alloca i32
  %l177 = alloca { i64, ptr }
  %l183 = alloca i1
  %l187 = alloca i1
  %l191 = alloca ptr
  %l192 = alloca %"compiler/target:Target"
  %l193 = alloca { i64, ptr }
  %l195 = alloca { i64, ptr }
  %l199 = alloca i1
  %l201 = alloca i1
  %l204 = alloca i1
  %l206 = alloca %"compiler/target:Target"
  %l207 = alloca i32
  %l209 = alloca i1
  %l214 = alloca i1
  %l218 = alloca i1
  %l222 = alloca i1
  %l228 = alloca i1
  %l231 = alloca ptr
  %l233 = alloca { i64, ptr }
  %l236 = alloca %"compiler/msgs:Msg"
  %l237 = alloca i32
  %l243 = alloca ptr
  %l246 = alloca i1
  %l250 = alloca i1
  %l255 = alloca i32
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %rv = alloca { i32, %"compiler/olang:CommandLine" }
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t7 = call { i32, %"compiler/olang:CommandLine" } @compiler_2folang_2eParse(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, ptr %t2, ptr %t3)
  %t8 = extractvalue { i32, %"compiler/olang:CommandLine" } %t7, 1
  %t9 = extractvalue { i32, %"compiler/olang:CommandLine" } %t7, 0
  store i32 %t9, ptr %l11
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11
ok.11:
  store %"compiler/olang:CommandLine" %t8, ptr %l10
  br label %bb1
bb1:
  %t12 = load %"compiler/olang:CommandLine", ptr %l10
  store %"compiler/olang:CommandLine" %t12, ptr %l6
  br label %bb3
bb2:
  %t13 = load i32, ptr %l11, !tbaa !23
  %t14 = lshr i32 %t13, 16
  %t15 = and i32 %t13, 65535
  %t16 = icmp eq i32 %t14, 1
  %t17 = select i1 %t16, i32 1, i32 0
  %t18 = icmp eq i32 %t13, 0
  %t19 = shl i32 %t17, 16
  %t20 = or i32 %t19, %t15
  %t21 = select i1 %t18, i32 0, i32 %t20
  call void @__olang_scope_close(ptr %s0)
  %t23 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t21, 0
  store { i32, %"compiler/olang:CommandLine" } %t23, ptr %rv
  br label %ret
bb3:
  %t24 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 120, i64 8)
  store ptr %t24, ptr %lp3
  %t25 = load %"compiler/olang:CommandLine", ptr %l6
  %t26 = load ptr, ptr %lp3
  store %"compiler/olang:CommandLine" %t25, ptr %t26
  %t27 = load ptr, ptr %lp3
  %t28 = getelementptr %"compiler/olang:CommandLine", ptr %t27, i32 0, i32 0
  %t29 = load i64, ptr %t28, !tbaa !24
  %t30 = load i64, ptr @G_2ecompiler_2folang_2eHelp, !tbaa !24
  %t33 = icmp eq i64 %t29, %t30
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = load ptr, ptr %lp3
  %t36 = load %"compiler/olang:CommandLine", ptr %t35
  call void @__olang_scope_close(ptr %s0)
  %t38 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, %"compiler/olang:CommandLine" %t36, 1
  store { i32, %"compiler/olang:CommandLine" } %t38, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t39 = load ptr, ptr %lp3
  %t40 = getelementptr %"compiler/olang:CommandLine", ptr %t39, i32 0, i32 0
  %t41 = load i64, ptr %t40, !tbaa !24
  %t42 = load i64, ptr @G_2ecompiler_2folang_2eExplain, !tbaa !24
  %t45 = icmp eq i64 %t41, %t42
  br i1 %t45, label %bb7, label %bb8
bb7:
  %t47 = load ptr, ptr %lp3
  %t48 = getelementptr %"compiler/olang:CommandLine", ptr %t47, i32 0, i32 4
  %t49 = load i1, ptr %t48, !tbaa !21
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb9, label %bb10
bb8:
  br label %bb28
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t53 = load ptr, ptr %l2, !tbaa !29
  store ptr %t53, ptr %l22, !tbaa !29
  %t54 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eExplainNeedsRule(ptr %s3)
  store %"compiler/msgs:Msg" %t54, ptr %l23
  br label %bb11
bb10:
  br label %bb15
bb11:
  %t55 = load ptr, ptr %l22, !tbaa !29
  %t56 = load %"compiler/msgs:Msg", ptr %l23
  %t57 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s3, ptr %t55, %"compiler/msgs:Msg" %t56)
  store i32 %t57, ptr %l24
  %t58 = icmp ne i32 %t57, 0
  br i1 %t58, label %bb13, label %ok.59
ok.59:
  br label %bb12
bb12:
  br label %bb14
bb13:
  %t60 = load i32, ptr %l24, !tbaa !23
  %t61 = lshr i32 %t60, 16
  %t62 = and i32 %t60, 65535
  %t63 = icmp eq i32 %t61, 1
  %t64 = select i1 %t63, i32 1, i32 0
  %t65 = icmp eq i32 %t60, 0
  %t66 = shl i32 %t64, 16
  %t67 = or i32 %t66, %t62
  %t68 = select i1 %t65, i32 0, i32 %t67
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t70 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t68, 0
  store { i32, %"compiler/olang:CommandLine" } %t70, ptr %rv
  br label %ret
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb15:
  %t71 = load ptr, ptr %lp3
  %t72 = getelementptr %"compiler/olang:CommandLine", ptr %t71, i32 0, i32 1
  %t74 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v3, ptr %t72)
  store i64 %t74, ptr %l27
  br label %bb16
bb16:
  %t75 = load i64, ptr %l27, !tbaa !24
  %t76 = icmp eq i64 %t75, 0
  br i1 %t76, label %bb17, label %bb18
bb17:
  %t78 = load ptr, ptr %lp3
  %t79 = getelementptr %"compiler/olang:CommandLine", ptr %t78, i32 0, i32 3
  %t80 = load { i64, ptr }, ptr %t79, !tbaa !27
  %t82 = call i1 @compiler_2folang_2eendsWithOlang(ptr %v3, { i64, ptr } %t80)
  store i1 %t82, ptr %l30
  br label %bb19
bb18:
  br label %bb27
bb19:
  %t83 = load i1, ptr %l30, !tbaa !21
  br i1 %t83, label %bb20, label %bb21
bb20:
  store %olang.scope zeroinitializer, ptr %s5
  %t84 = load ptr, ptr %l2, !tbaa !29
  store ptr %t84, ptr %l31, !tbaa !29
  %t85 = load ptr, ptr %lp3
  %t86 = getelementptr %"compiler/olang:CommandLine", ptr %t85, i32 0, i32 3
  %t87 = load { i64, ptr }, ptr %t86, !tbaa !27
  %t89 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eExplainNeedsName(ptr %v3, ptr %s5, { i64, ptr } %t87)
  store %"compiler/msgs:Msg" %t89, ptr %l33
  br label %bb22
bb21:
  br label %bb26
bb22:
  %t90 = load ptr, ptr %l31, !tbaa !29
  %t91 = load %"compiler/msgs:Msg", ptr %l33
  %t92 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s5, ptr %t90, %"compiler/msgs:Msg" %t91)
  store i32 %t92, ptr %l34
  %t93 = icmp ne i32 %t92, 0
  br i1 %t93, label %bb24, label %ok.94
ok.94:
  br label %bb23
bb23:
  br label %bb25
bb24:
  %t95 = load i32, ptr %l34, !tbaa !23
  %t96 = lshr i32 %t95, 16
  %t97 = and i32 %t95, 65535
  %t98 = icmp eq i32 %t96, 1
  %t99 = select i1 %t98, i32 1, i32 0
  %t100 = icmp eq i32 %t95, 0
  %t101 = shl i32 %t99, 16
  %t102 = or i32 %t101, %t97
  %t103 = select i1 %t100, i32 0, i32 %t102
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t105 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t103, 0
  store { i32, %"compiler/olang:CommandLine" } %t105, ptr %rv
  br label %ret
bb25:
  call void @__olang_scope_close(ptr %s5)
  br label %bb26
bb26:
  %t106 = load ptr, ptr %lp3
  %t107 = load %"compiler/olang:CommandLine", ptr %t106
  call void @__olang_scope_close(ptr %s0)
  %t109 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, %"compiler/olang:CommandLine" %t107, 1
  store { i32, %"compiler/olang:CommandLine" } %t109, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t110 = load ptr, ptr %lp3
  %t111 = getelementptr %"compiler/olang:CommandLine", ptr %t110, i32 0, i32 0
  %t112 = load i64, ptr %t111, !tbaa !24
  %t113 = load i64, ptr @G_2ecompiler_2folang_2eLsp, !tbaa !24
  %t116 = icmp eq i64 %t112, %t113
  br i1 %t116, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb31
bb30:
  %t118 = load ptr, ptr %lp3
  %t119 = getelementptr %"compiler/olang:CommandLine", ptr %t118, i32 0, i32 0
  %t120 = load i64, ptr %t119, !tbaa !24
  %t121 = load i64, ptr @G_2ecompiler_2folang_2eMcp, !tbaa !24
  %t124 = icmp eq i64 %t120, %t121
  store i1 %t124, ptr %l40, !tbaa !21
  br label %bb31
bb31:
  %t126 = load i1, ptr %l40, !tbaa !21
  br i1 %t126, label %bb32, label %bb33
bb32:
  %t127 = load ptr, ptr %lp3
  %t128 = getelementptr %"compiler/olang:CommandLine", ptr %t127, i32 0, i32 1
  %t130 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v3, ptr %t128)
  store i64 %t130, ptr %l46
  br label %bb34
bb33:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb35
bb34:
  %t131 = load i64, ptr %l46, !tbaa !24
  %t132 = icmp sgt i64 %t131, 0
  store i1 %t132, ptr %l44, !tbaa !21
  br label %bb35
bb35:
  %t134 = load i1, ptr %l44, !tbaa !21
  br i1 %t134, label %bb36, label %bb37
bb36:
  store %olang.scope zeroinitializer, ptr %s6
  %t135 = load ptr, ptr %l2, !tbaa !29
  store ptr %t135, ptr %l48, !tbaa !29
  %t136 = load ptr, ptr %lp3
  %t137 = getelementptr %"compiler/olang:CommandLine", ptr %t136, i32 0, i32 0
  %t138 = load i64, ptr %t137, !tbaa !24
  %t140 = call { i64, ptr } @compiler_2folang_2emodeName(ptr %s6, i64 %t138)
  store { i64, ptr } %t140, ptr %l50
  br label %bb38
bb37:
  br label %bb43
bb38:
  %t141 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t141, 0
  %t143 = extractvalue { i64, ptr } %t141, 1
  %t144 = mul i64 %t142, 1
  %t145 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t144)
  call void @llvm.memcpy.p0.p0.i64(ptr %t145, ptr %t143, i64 %t144, i1 false)
  %t146 = insertvalue { i64, ptr } undef, i64 %t142, 0
  %t147 = insertvalue { i64, ptr } %t146, ptr %t145, 1
  %t149 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eModeNoFiles(ptr %s6, ptr %s6, { i64, ptr } %t147)
  store %"compiler/msgs:Msg" %t149, ptr %l52
  br label %bb39
bb39:
  %t150 = load ptr, ptr %l48, !tbaa !29
  %t151 = load %"compiler/msgs:Msg", ptr %l52
  %t152 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s6, ptr %t150, %"compiler/msgs:Msg" %t151)
  store i32 %t152, ptr %l53
  %t153 = icmp ne i32 %t152, 0
  br i1 %t153, label %bb41, label %ok.154
ok.154:
  br label %bb40
bb40:
  br label %bb42
bb41:
  %t155 = load i32, ptr %l53, !tbaa !23
  %t156 = lshr i32 %t155, 16
  %t157 = and i32 %t155, 65535
  %t158 = icmp eq i32 %t156, 1
  %t159 = select i1 %t158, i32 1, i32 0
  %t160 = icmp eq i32 %t155, 0
  %t161 = shl i32 %t159, 16
  %t162 = or i32 %t161, %t157
  %t163 = select i1 %t160, i32 0, i32 %t162
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t165 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t163, 0
  store { i32, %"compiler/olang:CommandLine" } %t165, ptr %rv
  br label %ret
bb42:
  call void @__olang_scope_close(ptr %s6)
  br label %bb43
bb43:
  %t166 = load ptr, ptr %lp3
  %t167 = getelementptr %"compiler/olang:CommandLine", ptr %t166, i32 0, i32 0
  %t168 = load i64, ptr %t167, !tbaa !24
  %t169 = load i64, ptr @G_2ecompiler_2folang_2eDoc, !tbaa !24
  %t172 = icmp eq i64 %t168, %t169
  br i1 %t172, label %bb44, label %bb45
bb44:
  %t174 = load ptr, ptr %lp3
  %t175 = getelementptr %"compiler/olang:CommandLine", ptr %t174, i32 0, i32 10
  %t176 = load { i64, ptr }, ptr %t175, !tbaa !27
  %t178 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s0, { i64, ptr } %t176, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d88, i32 0, i32 1) })
  store i1 %t178, ptr %l60
  br label %bb46
bb45:
  store i1 false, ptr %l58, !tbaa !21
  br label %bb47
bb46:
  %t179 = load i1, ptr %l60, !tbaa !21
  store i1 %t179, ptr %l58, !tbaa !21
  br label %bb47
bb47:
  %t180 = load i1, ptr %l58, !tbaa !21
  br i1 %t180, label %bb48, label %bb49
bb48:
  %t181 = load ptr, ptr %lp3
  %t182 = getelementptr %"compiler/olang:CommandLine", ptr %t181, i32 0, i32 1
  %t184 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v3, ptr %t182)
  store i64 %t184, ptr %l63
  br label %bb50
bb49:
  store i1 false, ptr %l61, !tbaa !21
  br label %bb51
bb50:
  %t185 = load i64, ptr %l63, !tbaa !24
  %t186 = icmp ne i64 %t185, 1
  store i1 %t186, ptr %l61, !tbaa !21
  br label %bb51
bb51:
  %t188 = load i1, ptr %l61, !tbaa !21
  br i1 %t188, label %bb52, label %bb53
bb52:
  store %olang.scope zeroinitializer, ptr %s7
  %t189 = load ptr, ptr %l2, !tbaa !29
  store ptr %t189, ptr %l65, !tbaa !29
  %t190 = load ptr, ptr %lp3
  %t191 = getelementptr %"compiler/olang:CommandLine", ptr %t190, i32 0, i32 1
  %t193 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v3, ptr %t191)
  store i64 %t193, ptr %l67
  br label %bb54
bb53:
  br label %bb65
bb54:
  %t194 = load i64, ptr %l67, !tbaa !24
  %t195 = icmp sgt i64 %t194, 1
  br i1 %t195, label %bb55, label %bb56
bb55:
  %t197 = load ptr, ptr %lp3
  %t198 = getelementptr %"compiler/olang:CommandLine", ptr %t197, i32 0, i32 0
  %t199 = load i64, ptr %t198, !tbaa !24
  %t201 = call { i64, ptr } @compiler_2folang_2emodeName(ptr %s7, i64 %t199)
  store { i64, ptr } %t201, ptr %l71
  br label %bb57
bb56:
  %t202 = load ptr, ptr %lp3
  %t203 = getelementptr %"compiler/olang:CommandLine", ptr %t202, i32 0, i32 0
  %t204 = load i64, ptr %t203, !tbaa !24
  %t206 = call { i64, ptr } @compiler_2folang_2emodeName(ptr %s7, i64 %t204)
  store { i64, ptr } %t206, ptr %l75
  br label %bb59
bb57:
  %t207 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t208 = extractvalue { i64, ptr } %t207, 0
  %t209 = extractvalue { i64, ptr } %t207, 1
  %t210 = mul i64 %t208, 1
  %t211 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t210)
  call void @llvm.memcpy.p0.p0.i64(ptr %t211, ptr %t209, i64 %t210, i1 false)
  %t212 = insertvalue { i64, ptr } undef, i64 %t208, 0
  %t213 = insertvalue { i64, ptr } %t212, ptr %t211, 1
  %t215 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eModeOneFile(ptr %s7, ptr %s7, { i64, ptr } %t213)
  store %"compiler/msgs:Msg" %t215, ptr %l73
  br label %bb58
bb58:
  %t216 = load %"compiler/msgs:Msg", ptr %l73
  store %"compiler/msgs:Msg" %t216, ptr %l69
  br label %bb61
bb59:
  %t217 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t218 = extractvalue { i64, ptr } %t217, 0
  %t219 = extractvalue { i64, ptr } %t217, 1
  %t220 = mul i64 %t218, 1
  %t221 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t220)
  call void @llvm.memcpy.p0.p0.i64(ptr %t221, ptr %t219, i64 %t220, i1 false)
  %t222 = insertvalue { i64, ptr } undef, i64 %t218, 0
  %t223 = insertvalue { i64, ptr } %t222, ptr %t221, 1
  %t225 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eModeNeedsFile(ptr %s7, ptr %s7, { i64, ptr } %t223)
  store %"compiler/msgs:Msg" %t225, ptr %l77
  br label %bb60
bb60:
  %t226 = load %"compiler/msgs:Msg", ptr %l77
  store %"compiler/msgs:Msg" %t226, ptr %l69
  br label %bb61
bb61:
  %t227 = load ptr, ptr %l65, !tbaa !29
  %t228 = load %"compiler/msgs:Msg", ptr %l69
  %t229 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s7, ptr %t227, %"compiler/msgs:Msg" %t228)
  store i32 %t229, ptr %l78
  %t230 = icmp ne i32 %t229, 0
  br i1 %t230, label %bb63, label %ok.231
ok.231:
  br label %bb62
bb62:
  br label %bb64
bb63:
  %t232 = load i32, ptr %l78, !tbaa !23
  %t233 = lshr i32 %t232, 16
  %t234 = and i32 %t232, 65535
  %t235 = icmp eq i32 %t233, 1
  %t236 = select i1 %t235, i32 1, i32 0
  %t237 = icmp eq i32 %t232, 0
  %t238 = shl i32 %t236, 16
  %t239 = or i32 %t238, %t234
  %t240 = select i1 %t237, i32 0, i32 %t239
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  %t242 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t240, 0
  store { i32, %"compiler/olang:CommandLine" } %t242, ptr %rv
  br label %ret
bb64:
  call void @__olang_scope_close(ptr %s7)
  br label %bb65
bb65:
  %t243 = load ptr, ptr %lp3
  %t244 = getelementptr %"compiler/olang:CommandLine", ptr %t243, i32 0, i32 1
  %t246 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v3, ptr %t244)
  store i64 %t246, ptr %l81
  br label %bb66
bb66:
  %t247 = load i64, ptr %l81, !tbaa !24
  %t248 = icmp eq i64 %t247, 0
  br i1 %t248, label %bb67, label %bb68
bb67:
  %t250 = load ptr, ptr %lp3
  %t251 = getelementptr %"compiler/olang:CommandLine", ptr %t250, i32 0, i32 0
  %t252 = load i64, ptr %t251, !tbaa !24
  %t253 = load i64, ptr @G_2ecompiler_2folang_2eLsp, !tbaa !24
  %t256 = icmp ne i64 %t252, %t253
  store i1 %t256, ptr %l83, !tbaa !21
  br label %bb69
bb68:
  store i1 false, ptr %l83, !tbaa !21
  br label %bb69
bb69:
  %t258 = load i1, ptr %l83, !tbaa !21
  br i1 %t258, label %bb70, label %bb71
bb70:
  %t259 = load ptr, ptr %lp3
  %t260 = getelementptr %"compiler/olang:CommandLine", ptr %t259, i32 0, i32 0
  %t261 = load i64, ptr %t260, !tbaa !24
  %t262 = load i64, ptr @G_2ecompiler_2folang_2eMcp, !tbaa !24
  %t265 = icmp ne i64 %t261, %t262
  store i1 %t265, ptr %l87, !tbaa !21
  br label %bb72
bb71:
  store i1 false, ptr %l87, !tbaa !21
  br label %bb72
bb72:
  %t267 = load i1, ptr %l87, !tbaa !21
  br i1 %t267, label %bb73, label %bb74
bb73:
  %t268 = load ptr, ptr %lp3
  %t269 = getelementptr %"compiler/olang:CommandLine", ptr %t268, i32 0, i32 0
  %t270 = load i64, ptr %t269, !tbaa !24
  %t271 = load i64, ptr @G_2ecompiler_2folang_2eDoc, !tbaa !24
  %t274 = icmp ne i64 %t270, %t271
  store i1 %t274, ptr %l91, !tbaa !21
  br label %bb75
bb74:
  store i1 false, ptr %l91, !tbaa !21
  br label %bb75
bb75:
  %t276 = load i1, ptr %l91, !tbaa !21
  br i1 %t276, label %bb76, label %bb77
bb76:
  store %olang.scope zeroinitializer, ptr %s8
  %t277 = load ptr, ptr %l2, !tbaa !29
  store ptr %t277, ptr %l95, !tbaa !29
  %t278 = load ptr, ptr %lp3
  %t279 = getelementptr %"compiler/olang:CommandLine", ptr %t278, i32 0, i32 0
  %t280 = load i64, ptr %t279, !tbaa !24
  %t282 = call { i64, ptr } @compiler_2folang_2emodeName(ptr %s8, i64 %t280)
  store { i64, ptr } %t282, ptr %l97
  br label %bb78
bb77:
  br label %bb83
bb78:
  %t283 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t284 = extractvalue { i64, ptr } %t283, 0
  %t285 = extractvalue { i64, ptr } %t283, 1
  %t286 = mul i64 %t284, 1
  %t287 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t286)
  call void @llvm.memcpy.p0.p0.i64(ptr %t287, ptr %t285, i64 %t286, i1 false)
  %t288 = insertvalue { i64, ptr } undef, i64 %t284, 0
  %t289 = insertvalue { i64, ptr } %t288, ptr %t287, 1
  %t291 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eModeNeedsFile(ptr %s8, ptr %s8, { i64, ptr } %t289)
  store %"compiler/msgs:Msg" %t291, ptr %l99
  br label %bb79
bb79:
  %t292 = load ptr, ptr %l95, !tbaa !29
  %t293 = load %"compiler/msgs:Msg", ptr %l99
  %t294 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s8, ptr %t292, %"compiler/msgs:Msg" %t293)
  store i32 %t294, ptr %l100
  %t295 = icmp ne i32 %t294, 0
  br i1 %t295, label %bb81, label %ok.296
ok.296:
  br label %bb80
bb80:
  br label %bb82
bb81:
  %t297 = load i32, ptr %l100, !tbaa !23
  %t298 = lshr i32 %t297, 16
  %t299 = and i32 %t297, 65535
  %t300 = icmp eq i32 %t298, 1
  %t301 = select i1 %t300, i32 1, i32 0
  %t302 = icmp eq i32 %t297, 0
  %t303 = shl i32 %t301, 16
  %t304 = or i32 %t303, %t299
  %t305 = select i1 %t302, i32 0, i32 %t304
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t307 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t305, 0
  store { i32, %"compiler/olang:CommandLine" } %t307, ptr %rv
  br label %ret
bb82:
  call void @__olang_scope_close(ptr %s8)
  br label %bb83
bb83:
  %t308 = load ptr, ptr %lp3
  %t309 = getelementptr %"compiler/olang:CommandLine", ptr %t308, i32 0, i32 0
  %t310 = load i64, ptr %t309, !tbaa !24
  %t311 = load i64, ptr @G_2ecompiler_2folang_2eBuild, !tbaa !24
  %t314 = icmp eq i64 %t310, %t311
  br i1 %t314, label %bb84, label %bb85
bb84:
  store i1 true, ptr %l105, !tbaa !21
  br label %bb86
bb85:
  %t316 = load ptr, ptr %lp3
  %t317 = getelementptr %"compiler/olang:CommandLine", ptr %t316, i32 0, i32 0
  %t318 = load i64, ptr %t317, !tbaa !24
  %t319 = load i64, ptr @G_2ecompiler_2folang_2eCompile, !tbaa !24
  %t322 = icmp eq i64 %t318, %t319
  store i1 %t322, ptr %l105, !tbaa !21
  br label %bb86
bb86:
  %t324 = load i1, ptr %l105, !tbaa !21
  br i1 %t324, label %bb87, label %bb88
bb87:
  store i1 true, ptr %l109, !tbaa !21
  br label %bb89
bb88:
  %t325 = load ptr, ptr %lp3
  %t326 = getelementptr %"compiler/olang:CommandLine", ptr %t325, i32 0, i32 0
  %t327 = load i64, ptr %t326, !tbaa !24
  %t328 = load i64, ptr @G_2ecompiler_2folang_2eBindgen, !tbaa !24
  %t331 = icmp eq i64 %t327, %t328
  store i1 %t331, ptr %l109, !tbaa !21
  br label %bb89
bb89:
  %t333 = load i1, ptr %l109, !tbaa !21
  br i1 %t333, label %bb90, label %bb91
bb90:
  %t334 = load ptr, ptr %lp3
  %t335 = getelementptr %"compiler/olang:CommandLine", ptr %t334, i32 0, i32 1
  %t337 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v3, ptr %t335)
  store i64 %t337, ptr %l115
  br label %bb92
bb91:
  store i1 false, ptr %l113, !tbaa !21
  br label %bb93
bb92:
  %t338 = load i64, ptr %l115, !tbaa !24
  %t339 = icmp ne i64 %t338, 1
  store i1 %t339, ptr %l113, !tbaa !21
  br label %bb93
bb93:
  %t341 = load i1, ptr %l113, !tbaa !21
  br i1 %t341, label %bb94, label %bb95
bb94:
  store %olang.scope zeroinitializer, ptr %s9
  %t342 = load ptr, ptr %l2, !tbaa !29
  store ptr %t342, ptr %l117, !tbaa !29
  %t343 = load ptr, ptr %lp3
  %t344 = getelementptr %"compiler/olang:CommandLine", ptr %t343, i32 0, i32 0
  %t345 = load i64, ptr %t344, !tbaa !24
  %t347 = call { i64, ptr } @compiler_2folang_2emodeName(ptr %s9, i64 %t345)
  store { i64, ptr } %t347, ptr %l119
  br label %bb96
bb95:
  br label %bb101
bb96:
  %t348 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t349 = extractvalue { i64, ptr } %t348, 0
  %t350 = extractvalue { i64, ptr } %t348, 1
  %t351 = mul i64 %t349, 1
  %t352 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t351)
  call void @llvm.memcpy.p0.p0.i64(ptr %t352, ptr %t350, i64 %t351, i1 false)
  %t353 = insertvalue { i64, ptr } undef, i64 %t349, 0
  %t354 = insertvalue { i64, ptr } %t353, ptr %t352, 1
  %t356 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eModeOneFile(ptr %s9, ptr %s9, { i64, ptr } %t354)
  store %"compiler/msgs:Msg" %t356, ptr %l121
  br label %bb97
bb97:
  %t357 = load ptr, ptr %l117, !tbaa !29
  %t358 = load %"compiler/msgs:Msg", ptr %l121
  %t359 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s9, ptr %t357, %"compiler/msgs:Msg" %t358)
  store i32 %t359, ptr %l122
  %t360 = icmp ne i32 %t359, 0
  br i1 %t360, label %bb99, label %ok.361
ok.361:
  br label %bb98
bb98:
  br label %bb100
bb99:
  %t362 = load i32, ptr %l122, !tbaa !23
  %t363 = lshr i32 %t362, 16
  %t364 = and i32 %t362, 65535
  %t365 = icmp eq i32 %t363, 1
  %t366 = select i1 %t365, i32 1, i32 0
  %t367 = icmp eq i32 %t362, 0
  %t368 = shl i32 %t366, 16
  %t369 = or i32 %t368, %t364
  %t370 = select i1 %t367, i32 0, i32 %t369
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  %t372 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t370, 0
  store { i32, %"compiler/olang:CommandLine" } %t372, ptr %rv
  br label %ret
bb100:
  call void @__olang_scope_close(ptr %s9)
  br label %bb101
bb101:
  %t373 = load ptr, ptr %l1, !tbaa !29
  %t375 = getelementptr %"compiler/build:Config", ptr %t373, i32 0, i32 11
  %t376 = load i64, ptr %t375, !tbaa !24
  %t378 = icmp sgt i64 %t376, 0
  br i1 %t378, label %bb102, label %bb103
bb102:
  %t380 = load ptr, ptr %l1, !tbaa !29
  %t382 = getelementptr %"compiler/build:Config", ptr %t380, i32 0, i32 10
  %t383 = load { i64, ptr }, ptr %t382, !tbaa !27
  %t385 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t383, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d89, i32 0, i32 1) })
  store i1 %t385, ptr %l130
  br label %bb104
bb103:
  store i1 false, ptr %l127, !tbaa !21
  br label %bb105
bb104:
  %t386 = load i1, ptr %l130, !tbaa !21
  store i1 %t386, ptr %l127, !tbaa !21
  br label %bb105
bb105:
  %t387 = load i1, ptr %l127, !tbaa !21
  br i1 %t387, label %bb106, label %bb107
bb106:
  store %olang.scope zeroinitializer, ptr %s10
  %t388 = load ptr, ptr %l2, !tbaa !29
  store ptr %t388, ptr %l131, !tbaa !29
  %t389 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eFuzzTimeAlone(ptr %s10)
  store %"compiler/msgs:Msg" %t389, ptr %l132
  br label %bb108
bb107:
  br label %bb112
bb108:
  %t390 = load ptr, ptr %l131, !tbaa !29
  %t391 = load %"compiler/msgs:Msg", ptr %l132
  %t392 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s10, ptr %t390, %"compiler/msgs:Msg" %t391)
  store i32 %t392, ptr %l133
  %t393 = icmp ne i32 %t392, 0
  br i1 %t393, label %bb110, label %ok.394
ok.394:
  br label %bb109
bb109:
  br label %bb111
bb110:
  %t395 = load i32, ptr %l133, !tbaa !23
  %t396 = lshr i32 %t395, 16
  %t397 = and i32 %t395, 65535
  %t398 = icmp eq i32 %t396, 1
  %t399 = select i1 %t398, i32 1, i32 0
  %t400 = icmp eq i32 %t395, 0
  %t401 = shl i32 %t399, 16
  %t402 = or i32 %t401, %t397
  %t403 = select i1 %t400, i32 0, i32 %t402
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  %t405 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t403, 0
  store { i32, %"compiler/olang:CommandLine" } %t405, ptr %rv
  br label %ret
bb111:
  call void @__olang_scope_close(ptr %s10)
  br label %bb112
bb112:
  %t406 = load ptr, ptr %l1, !tbaa !29
  %t408 = getelementptr %"compiler/build:Config", ptr %t406, i32 0, i32 10
  %t409 = load { i64, ptr }, ptr %t408, !tbaa !27
  %t411 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t409, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d90, i32 0, i32 1) })
  store i1 %t411, ptr %l137
  br label %bb113
bb113:
  %t412 = load i1, ptr %l137, !tbaa !21
  %t413 = xor i1 %t412, true
  br i1 %t413, label %bb114, label %bb115
bb114:
  %t415 = load ptr, ptr %lp3
  %t416 = getelementptr %"compiler/olang:CommandLine", ptr %t415, i32 0, i32 1
  %t418 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v3, ptr %t416)
  store i64 %t418, ptr %l141
  br label %bb116
bb115:
  store i1 false, ptr %l139, !tbaa !21
  br label %bb117
bb116:
  %t419 = load i64, ptr %l141, !tbaa !24
  %t420 = icmp ne i64 %t419, 1
  store i1 %t420, ptr %l139, !tbaa !21
  br label %bb117
bb117:
  %t422 = load i1, ptr %l139, !tbaa !21
  br i1 %t422, label %bb118, label %bb119
bb118:
  store %olang.scope zeroinitializer, ptr %s11
  %t423 = load ptr, ptr %l2, !tbaa !29
  store ptr %t423, ptr %l143, !tbaa !29
  %t424 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eModeOneFile(ptr %s11, ptr %s11, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d91, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t424, ptr %l144
  br label %bb120
bb119:
  br label %bb124
bb120:
  %t425 = load ptr, ptr %l143, !tbaa !29
  %t426 = load %"compiler/msgs:Msg", ptr %l144
  %t427 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s11, ptr %t425, %"compiler/msgs:Msg" %t426)
  store i32 %t427, ptr %l145
  %t428 = icmp ne i32 %t427, 0
  br i1 %t428, label %bb122, label %ok.429
ok.429:
  br label %bb121
bb121:
  br label %bb123
bb122:
  %t430 = load i32, ptr %l145, !tbaa !23
  %t431 = lshr i32 %t430, 16
  %t432 = and i32 %t430, 65535
  %t433 = icmp eq i32 %t431, 1
  %t434 = select i1 %t433, i32 1, i32 0
  %t435 = icmp eq i32 %t430, 0
  %t436 = shl i32 %t434, 16
  %t437 = or i32 %t436, %t432
  %t438 = select i1 %t435, i32 0, i32 %t437
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  %t440 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t438, 0
  store { i32, %"compiler/olang:CommandLine" } %t440, ptr %rv
  br label %ret
bb123:
  call void @__olang_scope_close(ptr %s11)
  br label %bb124
bb124:
  %t441 = load ptr, ptr %lp3
  %t442 = getelementptr %"compiler/olang:CommandLine", ptr %t441, i32 0, i32 0
  %t443 = load i64, ptr %t442, !tbaa !24
  %t444 = load i64, ptr @G_2ecompiler_2folang_2eFormat, !tbaa !24
  %t447 = icmp eq i64 %t443, %t444
  br i1 %t447, label %bb125, label %bb126
bb125:
  store i1 true, ptr %l150, !tbaa !21
  br label %bb127
bb126:
  %t449 = load ptr, ptr %lp3
  %t450 = getelementptr %"compiler/olang:CommandLine", ptr %t449, i32 0, i32 0
  %t451 = load i64, ptr %t450, !tbaa !24
  %t452 = load i64, ptr @G_2ecompiler_2folang_2eFix, !tbaa !24
  %t455 = icmp eq i64 %t451, %t452
  store i1 %t455, ptr %l150, !tbaa !21
  br label %bb127
bb127:
  %t457 = load i1, ptr %l150, !tbaa !21
  br i1 %t457, label %bb128, label %bb129
bb128:
  %t458 = load ptr, ptr %lp3
  %t459 = load %"compiler/olang:CommandLine", ptr %t458
  call void @__olang_scope_close(ptr %s0)
  %t461 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, %"compiler/olang:CommandLine" %t459, 1
  store { i32, %"compiler/olang:CommandLine" } %t461, ptr %rv
  br label %ret
bb129:
  br label %bb130
bb130:
  %t462 = load ptr, ptr %lp3
  %t463 = getelementptr %"compiler/olang:CommandLine", ptr %t462, i32 0, i32 8
  %t464 = load { i64, ptr }, ptr %t463, !tbaa !27
  %t466 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s0, { i64, ptr } %t464, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d92, i32 0, i32 1) })
  store i1 %t466, ptr %l156
  br label %bb131
bb131:
  %t467 = load i1, ptr %l156, !tbaa !21
  %t468 = xor i1 %t467, true
  br i1 %t468, label %bb132, label %bb133
bb132:
  %t470 = load ptr, ptr %lp3
  %t471 = getelementptr %"compiler/olang:CommandLine", ptr %t470, i32 0, i32 8
  %t472 = load { i64, ptr }, ptr %t471, !tbaa !27
  %t473 = load ptr, ptr %l2, !tbaa !29
  %t476 = call i32 @compiler_2folang_2echeckOutput(ptr %v3, ptr %v2, { i64, ptr } %t472, ptr %t473)
  store i32 %t476, ptr %l160
  %t477 = icmp ne i32 %t476, 0
  br i1 %t477, label %bb135, label %ok.478
ok.478:
  br label %bb134
bb133:
  br label %bb137
bb134:
  br label %bb136
bb135:
  %t479 = load i32, ptr %l160, !tbaa !23
  %t480 = lshr i32 %t479, 16
  %t481 = and i32 %t479, 65535
  %t482 = icmp eq i32 %t480, 1
  %t483 = select i1 %t482, i32 1, i32 0
  %t484 = icmp eq i32 %t479, 0
  %t485 = shl i32 %t483, 16
  %t486 = or i32 %t485, %t481
  %t487 = select i1 %t484, i32 0, i32 %t486
  call void @__olang_scope_close(ptr %s0)
  %t489 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t487, 0
  store { i32, %"compiler/olang:CommandLine" } %t489, ptr %rv
  br label %ret
bb136:
  br label %bb137
bb137:
  %t490 = load ptr, ptr %lp3
  %t491 = getelementptr %"compiler/olang:CommandLine", ptr %t490, i32 0, i32 0
  %t492 = load i64, ptr %t491, !tbaa !24
  %t493 = load i64, ptr @G_2ecompiler_2folang_2eBindgen, !tbaa !24
  %t496 = icmp eq i64 %t492, %t493
  br i1 %t496, label %bb138, label %bb139
bb138:
  %t498 = load ptr, ptr %lp3
  %t499 = load %"compiler/olang:CommandLine", ptr %t498
  call void @__olang_scope_close(ptr %s0)
  %t501 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, %"compiler/olang:CommandLine" %t499, 1
  store { i32, %"compiler/olang:CommandLine" } %t501, ptr %rv
  br label %ret
bb139:
  br label %bb140
bb140:
  %t502 = load ptr, ptr %l1, !tbaa !29
  %t503 = load ptr, ptr %lp3
  %t504 = getelementptr %"compiler/olang:CommandLine", ptr %t503, i32 0, i32 8
  %t505 = load { i64, ptr }, ptr %t504, !tbaa !27
  %t507 = extractvalue { i64, ptr } %t505, 1
  %t508 = extractvalue { i64, ptr } %t505, 0
  %t509 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t508)
  call void @olang_textcopy(ptr %t509, ptr %t507, i64 %t508)
  %t510 = insertvalue { i64, ptr } undef, i64 %t508, 0
  %t511 = insertvalue { i64, ptr } %t510, ptr %t509, 1
  %t513 = extractvalue { i64, ptr } %t511, 0
  %t514 = extractvalue { i64, ptr } %t511, 1
  %t515 = mul i64 %t513, 1
  %t516 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t515)
  call void @llvm.memcpy.p0.p0.i64(ptr %t516, ptr %t514, i64 %t515, i1 false)
  %t517 = insertvalue { i64, ptr } undef, i64 %t513, 0
  %t518 = insertvalue { i64, ptr } %t517, ptr %t516, 1
  %t521 = getelementptr %"compiler/build:Config", ptr %t502, i32 0, i32 17
  store { i64, ptr } %t518, ptr %t521, !tbaa !27
  %t522 = load ptr, ptr %l1, !tbaa !29
  store ptr %t522, ptr %l170, !tbaa !29
  %t523 = call { i64, ptr } @compiler_2ftarget_2eFindClang(ptr %v1)
  store { i64, ptr } %t523, ptr %l171
  br label %bb141
bb141:
  %t524 = load { i64, ptr }, ptr %l171, !tbaa !27
  %t525 = extractvalue { i64, ptr } %t524, 0
  %t526 = extractvalue { i64, ptr } %t524, 1
  %t527 = mul i64 %t525, 1
  %t528 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t527)
  call void @llvm.memcpy.p0.p0.i64(ptr %t528, ptr %t526, i64 %t527, i1 false)
  %t529 = insertvalue { i64, ptr } undef, i64 %t525, 0
  %t530 = insertvalue { i64, ptr } %t529, ptr %t528, 1
  %t532 = load ptr, ptr %l170, !tbaa !29
  %t533 = getelementptr %"compiler/build:Config", ptr %t532, i32 0, i32 1
  store { i64, ptr } %t530, ptr %t533, !tbaa !27
  %t534 = load ptr, ptr %l1, !tbaa !29
  store ptr %t534, ptr %l173, !tbaa !29
  %t535 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %v1, ptr %v1, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d93, i32 0, i32 1) })
  %t536 = extractvalue { i32, { i64, ptr } } %t535, 1
  %t537 = extractvalue { i32, { i64, ptr } } %t535, 0
  store i32 %t537, ptr %l176
  %t538 = icmp ne i32 %t537, 0
  br i1 %t538, label %bb143, label %ok.539
ok.539:
  store { i64, ptr } %t536, ptr %l175
  br label %bb142
bb142:
  %t540 = load { i64, ptr }, ptr %l175, !tbaa !27
  store { i64, ptr } %t540, ptr %l174, !tbaa !27
  br label %bb145
bb143:
  br label %bb144
bb144:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d94, i32 0, i32 1) }, ptr %l177, !tbaa !27
  %t541 = load { i64, ptr }, ptr %l177, !tbaa !27
  %t543 = extractvalue { i64, ptr } %t541, 0
  %t544 = extractvalue { i64, ptr } %t541, 1
  %t545 = mul i64 %t543, 1
  %t546 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t545)
  call void @llvm.memcpy.p0.p0.i64(ptr %t546, ptr %t544, i64 %t545, i1 false)
  %t547 = insertvalue { i64, ptr } undef, i64 %t543, 0
  %t548 = insertvalue { i64, ptr } %t547, ptr %t546, 1
  store { i64, ptr } %t548, ptr %l174, !tbaa !27
  br label %bb145
bb145:
  %t550 = load { i64, ptr }, ptr %l174, !tbaa !27
  %t551 = load ptr, ptr %l173, !tbaa !29
  %t552 = getelementptr %"compiler/build:Config", ptr %t551, i32 0, i32 22
  store { i64, ptr } %t550, ptr %t552, !tbaa !27
  %t553 = load ptr, ptr %lp3
  %t554 = getelementptr %"compiler/olang:CommandLine", ptr %t553, i32 0, i32 0
  %t555 = load i64, ptr %t554, !tbaa !24
  %t556 = load i64, ptr @G_2ecompiler_2folang_2eDoc, !tbaa !24
  %t559 = icmp eq i64 %t555, %t556
  br i1 %t559, label %bb146, label %bb147
bb146:
  store i1 true, ptr %l183, !tbaa !21
  br label %bb148
bb147:
  %t561 = load ptr, ptr %lp3
  %t562 = getelementptr %"compiler/olang:CommandLine", ptr %t561, i32 0, i32 0
  %t563 = load i64, ptr %t562, !tbaa !24
  %t564 = load i64, ptr @G_2ecompiler_2folang_2eLsp, !tbaa !24
  %t567 = icmp eq i64 %t563, %t564
  store i1 %t567, ptr %l183, !tbaa !21
  br label %bb148
bb148:
  %t569 = load i1, ptr %l183, !tbaa !21
  br i1 %t569, label %bb149, label %bb150
bb149:
  store i1 true, ptr %l187, !tbaa !21
  br label %bb151
bb150:
  %t570 = load ptr, ptr %lp3
  %t571 = getelementptr %"compiler/olang:CommandLine", ptr %t570, i32 0, i32 0
  %t572 = load i64, ptr %t571, !tbaa !24
  %t573 = load i64, ptr @G_2ecompiler_2folang_2eMcp, !tbaa !24
  %t576 = icmp eq i64 %t572, %t573
  store i1 %t576, ptr %l187, !tbaa !21
  br label %bb151
bb151:
  %t578 = load i1, ptr %l187, !tbaa !21
  store i1 %t578, ptr %l4, !tbaa !21
  %t579 = load ptr, ptr %l1, !tbaa !29
  store ptr %t579, ptr %l191, !tbaa !29
  %t580 = load ptr, ptr %lp3
  %t581 = getelementptr %"compiler/olang:CommandLine", ptr %t580, i32 0, i32 7
  %t582 = load { i64, ptr }, ptr %t581, !tbaa !27
  store { i64, ptr } %t582, ptr %l193, !tbaa !27
  %t583 = load ptr, ptr %l1, !tbaa !29
  %t585 = getelementptr %"compiler/build:Config", ptr %t583, i32 0, i32 1
  %t586 = load { i64, ptr }, ptr %t585, !tbaa !27
  store { i64, ptr } %t586, ptr %l195, !tbaa !27
  %t587 = load ptr, ptr %lp3
  %t588 = getelementptr %"compiler/olang:CommandLine", ptr %t587, i32 0, i32 0
  %t589 = load i64, ptr %t588, !tbaa !24
  %t590 = load i64, ptr @G_2ecompiler_2folang_2eInterp, !tbaa !24
  %t593 = icmp eq i64 %t589, %t590
  br i1 %t593, label %bb152, label %bb153
bb152:
  store i1 true, ptr %l199, !tbaa !21
  br label %bb158
bb153:
  %t595 = load i1, ptr %l4, !tbaa !21
  br i1 %t595, label %bb154, label %bb155
bb154:
  %t597 = load ptr, ptr %l1, !tbaa !29
  %t599 = getelementptr %"compiler/build:Config", ptr %t597, i32 0, i32 1
  %t600 = load { i64, ptr }, ptr %t599, !tbaa !27
  %t602 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t600, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d95, i32 0, i32 1) })
  store i1 %t602, ptr %l204
  br label %bb156
bb155:
  store i1 false, ptr %l201, !tbaa !21
  br label %bb157
bb156:
  %t603 = load i1, ptr %l204, !tbaa !21
  store i1 %t603, ptr %l201, !tbaa !21
  br label %bb157
bb157:
  %t604 = load i1, ptr %l201, !tbaa !21
  store i1 %t604, ptr %l199, !tbaa !21
  br label %bb158
bb158:
  %t605 = load ptr, ptr %l2, !tbaa !29
  %t606 = load { i64, ptr }, ptr %l193, !tbaa !27
  %t607 = load { i64, ptr }, ptr %l195, !tbaa !27
  %t608 = load i1, ptr %l199, !tbaa !21
  %t610 = call { i32, %"compiler/target:Target" } @compiler_2ftarget_2eResolve(ptr %v3, ptr %v1, ptr %v2, ptr %v1, { i64, ptr } %t606, { i64, ptr } %t607, i1 %t608, ptr %t605)
  %t611 = extractvalue { i32, %"compiler/target:Target" } %t610, 1
  %t612 = extractvalue { i32, %"compiler/target:Target" } %t610, 0
  store i32 %t612, ptr %l207
  %t613 = icmp ne i32 %t612, 0
  br i1 %t613, label %bb160, label %ok.614
ok.614:
  store %"compiler/target:Target" %t611, ptr %l206
  br label %bb159
bb159:
  %t615 = load %"compiler/target:Target", ptr %l206
  store %"compiler/target:Target" %t615, ptr %l192
  br label %bb162
bb160:
  %t616 = load i32, ptr %l207, !tbaa !23
  %t617 = ashr i32 %t616, 16
  %t619 = icmp eq i32 %t617, 1
  store i1 %t619, ptr %l209, !tbaa !21
  br label %bb161
bb161:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  %t621 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/olang:CommandLine" } %t621, ptr %rv
  br label %ret
bb162:
  %t622 = load %"compiler/target:Target", ptr %l192
  %t623 = load ptr, ptr %l191, !tbaa !29
  %t624 = getelementptr %"compiler/build:Config", ptr %t623, i32 0, i32 2
  store %"compiler/target:Target" %t622, ptr %t624
  %t625 = load ptr, ptr %lp3
  %t626 = getelementptr %"compiler/olang:CommandLine", ptr %t625, i32 0, i32 0
  %t627 = load i64, ptr %t626, !tbaa !24
  %t628 = load i64, ptr @G_2ecompiler_2folang_2eCompile, !tbaa !24
  %t631 = icmp eq i64 %t627, %t628
  br i1 %t631, label %bb163, label %bb164
bb163:
  store i1 true, ptr %l214, !tbaa !21
  br label %bb165
bb164:
  %t633 = load ptr, ptr %lp3
  %t634 = getelementptr %"compiler/olang:CommandLine", ptr %t633, i32 0, i32 0
  %t635 = load i64, ptr %t634, !tbaa !24
  %t636 = load i64, ptr @G_2ecompiler_2folang_2eBuild, !tbaa !24
  %t639 = icmp eq i64 %t635, %t636
  store i1 %t639, ptr %l214, !tbaa !21
  br label %bb165
bb165:
  %t641 = load i1, ptr %l214, !tbaa !21
  br i1 %t641, label %bb166, label %bb167
bb166:
  store i1 true, ptr %l218, !tbaa !21
  br label %bb168
bb167:
  %t642 = load ptr, ptr %lp3
  %t643 = getelementptr %"compiler/olang:CommandLine", ptr %t642, i32 0, i32 0
  %t644 = load i64, ptr %t643, !tbaa !24
  %t645 = load i64, ptr @G_2ecompiler_2folang_2eTest, !tbaa !24
  %t648 = icmp eq i64 %t644, %t645
  store i1 %t648, ptr %l218, !tbaa !21
  br label %bb168
bb168:
  %t650 = load i1, ptr %l218, !tbaa !21
  br i1 %t650, label %bb169, label %bb170
bb169:
  store i1 true, ptr %l222, !tbaa !21
  br label %bb171
bb170:
  %t651 = load ptr, ptr %lp3
  %t652 = getelementptr %"compiler/olang:CommandLine", ptr %t651, i32 0, i32 0
  %t653 = load i64, ptr %t652, !tbaa !24
  %t654 = load i64, ptr @G_2ecompiler_2folang_2eRun, !tbaa !24
  %t657 = icmp eq i64 %t653, %t654
  store i1 %t657, ptr %l222, !tbaa !21
  br label %bb171
bb171:
  %t659 = load i1, ptr %l222, !tbaa !21
  store i1 %t659, ptr %l5, !tbaa !21
  %t660 = load ptr, ptr %l1, !tbaa !29
  %t662 = getelementptr %"compiler/build:Config", ptr %t660, i32 0, i32 2
  %t663 = getelementptr %"compiler/target:Target", ptr %t662, i32 0, i32 9
  %t664 = load i1, ptr %t663, !tbaa !21
  br i1 %t664, label %bb172, label %bb173
bb172:
  %t666 = load i1, ptr %l5, !tbaa !21
  %t668 = xor i1 %t666, true
  store i1 %t668, ptr %l228, !tbaa !21
  br label %bb174
bb173:
  store i1 false, ptr %l228, !tbaa !21
  br label %bb174
bb174:
  %t670 = load i1, ptr %l228, !tbaa !21
  br i1 %t670, label %bb175, label %bb176
bb175:
  store %olang.scope zeroinitializer, ptr %s17
  %t671 = load ptr, ptr %l2, !tbaa !29
  store ptr %t671, ptr %l231, !tbaa !29
  %t672 = load ptr, ptr %lp3
  %t673 = getelementptr %"compiler/olang:CommandLine", ptr %t672, i32 0, i32 0
  %t674 = load i64, ptr %t673, !tbaa !24
  %t676 = call { i64, ptr } @compiler_2folang_2emodeName(ptr %s17, i64 %t674)
  store { i64, ptr } %t676, ptr %l233
  br label %bb177
bb176:
  br label %bb182
bb177:
  %t677 = load { i64, ptr }, ptr %l233, !tbaa !27
  %t678 = extractvalue { i64, ptr } %t677, 0
  %t679 = extractvalue { i64, ptr } %t677, 1
  %t680 = mul i64 %t678, 1
  %t681 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t680)
  call void @llvm.memcpy.p0.p0.i64(ptr %t681, ptr %t679, i64 %t680, i1 false)
  %t682 = insertvalue { i64, ptr } undef, i64 %t678, 0
  %t683 = insertvalue { i64, ptr } %t682, ptr %t681, 1
  %t684 = load ptr, ptr %lp3
  %t685 = getelementptr %"compiler/olang:CommandLine", ptr %t684, i32 0, i32 7
  %t686 = load { i64, ptr }, ptr %t685, !tbaa !27
  %t689 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetForeignMode(ptr %s17, ptr %v3, ptr %s17, { i64, ptr } %t683, { i64, ptr } %t686)
  store %"compiler/msgs:Msg" %t689, ptr %l236
  br label %bb178
bb178:
  %t690 = load ptr, ptr %l231, !tbaa !29
  %t691 = load %"compiler/msgs:Msg", ptr %l236
  %t692 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s17, ptr %t690, %"compiler/msgs:Msg" %t691)
  store i32 %t692, ptr %l237
  %t693 = icmp ne i32 %t692, 0
  br i1 %t693, label %bb180, label %ok.694
ok.694:
  br label %bb179
bb179:
  br label %bb181
bb180:
  %t695 = load i32, ptr %l237, !tbaa !23
  %t696 = lshr i32 %t695, 16
  %t697 = and i32 %t695, 65535
  %t698 = icmp eq i32 %t696, 1
  %t699 = select i1 %t698, i32 1, i32 0
  %t700 = icmp eq i32 %t695, 0
  %t701 = shl i32 %t699, 16
  %t702 = or i32 %t701, %t697
  %t703 = select i1 %t700, i32 0, i32 %t702
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s0)
  %t705 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t703, 0
  store { i32, %"compiler/olang:CommandLine" } %t705, ptr %rv
  br label %ret
bb181:
  call void @__olang_scope_close(ptr %s17)
  br label %bb182
bb182:
  %t706 = load ptr, ptr %l1, !tbaa !29
  %t707 = load ptr, ptr %lp3
  %t708 = getelementptr %"compiler/olang:CommandLine", ptr %t707, i32 0, i32 0
  %t709 = load i64, ptr %t708, !tbaa !24
  %t710 = load i64, ptr @G_2ecompiler_2folang_2eTest, !tbaa !24
  %t713 = icmp eq i64 %t709, %t710
  %t716 = getelementptr %"compiler/build:Config", ptr %t706, i32 0, i32 13
  store i1 %t713, ptr %t716, !tbaa !21
  %t717 = load ptr, ptr %l1, !tbaa !29
  store ptr %t717, ptr %l243, !tbaa !29
  %t718 = load ptr, ptr %l1, !tbaa !29
  %t720 = getelementptr %"compiler/build:Config", ptr %t718, i32 0, i32 13
  %t721 = load i1, ptr %t720, !tbaa !21
  br i1 %t721, label %bb183, label %bb184
bb183:
  store i1 true, ptr %l246, !tbaa !21
  br label %bb185
bb184:
  %t723 = load ptr, ptr %lp3
  %t724 = getelementptr %"compiler/olang:CommandLine", ptr %t723, i32 0, i32 0
  %t725 = load i64, ptr %t724, !tbaa !24
  %t726 = load i64, ptr @G_2ecompiler_2folang_2eLsp, !tbaa !24
  %t729 = icmp eq i64 %t725, %t726
  store i1 %t729, ptr %l246, !tbaa !21
  br label %bb185
bb185:
  %t731 = load i1, ptr %l246, !tbaa !21
  br i1 %t731, label %bb186, label %bb187
bb186:
  store i1 true, ptr %l250, !tbaa !21
  br label %bb188
bb187:
  %t732 = load ptr, ptr %lp3
  %t733 = getelementptr %"compiler/olang:CommandLine", ptr %t732, i32 0, i32 0
  %t734 = load i64, ptr %t733, !tbaa !24
  %t735 = load i64, ptr @G_2ecompiler_2folang_2eMcp, !tbaa !24
  %t738 = icmp eq i64 %t734, %t735
  store i1 %t738, ptr %l250, !tbaa !21
  br label %bb188
bb188:
  %t740 = load ptr, ptr %l2, !tbaa !29
  %t741 = load ptr, ptr %l243, !tbaa !29
  %t742 = load i1, ptr %l250, !tbaa !21
  %t744 = call i32 @compiler_2folang_2ebuiltins(ptr %v1, ptr %v2, ptr %t741, i1 %t742, ptr %t740)
  store i32 %t744, ptr %l255
  %t745 = icmp ne i32 %t744, 0
  br i1 %t745, label %bb190, label %ok.746
ok.746:
  br label %bb189
bb189:
  br label %bb191
bb190:
  %t747 = load i32, ptr %l255, !tbaa !23
  %t748 = lshr i32 %t747, 16
  %t749 = and i32 %t747, 65535
  %t750 = icmp eq i32 %t748, 1
  %t751 = select i1 %t750, i32 1, i32 0
  %t752 = icmp eq i32 %t747, 0
  %t753 = shl i32 %t751, 16
  %t754 = or i32 %t753, %t749
  %t755 = select i1 %t752, i32 0, i32 %t754
  call void @__olang_scope_close(ptr %s0)
  %t757 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t755, 0
  store { i32, %"compiler/olang:CommandLine" } %t757, ptr %rv
  br label %ret
bb191:
  %t758 = load ptr, ptr %lp3
  %t759 = load %"compiler/olang:CommandLine", ptr %t758
  call void @__olang_scope_close(ptr %s0)
  %t761 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, %"compiler/olang:CommandLine" %t759, 1
  store { i32, %"compiler/olang:CommandLine" } %t761, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/olang:CommandLine" }, ptr %rv
  ret { i32, %"compiler/olang:CommandLine" } %rr
}

define dso_local void @compiler_2folang_2eRun_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr @G_2ecompiler_2folang_2eRun, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eTest_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 3, ptr @G_2ecompiler_2folang_2eTest, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2folang_2ebuildInputs(ptr %v0, ptr %v1, ptr %a0, i1 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"std/os:FileInfo"
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/target:Target"
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i32
  %l9 = alloca { i64, ptr }
  %l12 = alloca %"std/os:FileInfo"
  %l14 = alloca %"std/os:FileInfo"
  %l15 = alloca i32
  %l17 = alloca i1
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i32
  %l25 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca i64
  %l34 = alloca i1
  %l36 = alloca i1
  %l38 = alloca i1
  %l40 = alloca i1
  %l42 = alloca i1
  %l43 = alloca i1
  %l44 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %s0, ptr %s0, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d96, i32 0, i32 1) })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l8
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  store { i64, ptr } %t2, ptr %l7
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t6, ptr %l6, !tbaa !27
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d97, i32 0, i32 1) }, ptr %l9, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t10 = extractvalue { i64, ptr } %t7, 1
  %t11 = mul i64 %t9, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t10, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l6, !tbaa !27
  br label %bb4
bb4:
  %t16 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t16, ptr %l2, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t19 = call { i32, %"std/os:FileInfo" } @std_2fos_2eStat(ptr %s0, { i64, ptr } %t17)
  %t20 = extractvalue { i32, %"std/os:FileInfo" } %t19, 1
  %t21 = extractvalue { i32, %"std/os:FileInfo" } %t19, 0
  store i32 %t21, ptr %l15
  %t22 = icmp ne i32 %t21, 0
  br i1 %t22, label %bb6, label %ok.23
ok.23:
  store %"std/os:FileInfo" %t20, ptr %l14
  br label %bb5
bb5:
  %t24 = load %"std/os:FileInfo", ptr %l14
  store %"std/os:FileInfo" %t24, ptr %l12
  br label %bb8
bb6:
  %t25 = load i32, ptr %l15, !tbaa !23
  %t26 = ashr i32 %t25, 16
  %t28 = icmp eq i32 %t26, 1
  store i1 %t28, ptr %l17, !tbaa !21
  br label %bb7
bb7:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d98, i32 0, i32 1) }, ptr %l18, !tbaa !27
  %t29 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t29, ptr %l19, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t30, 0
  store i64 %t31, ptr %l20, !tbaa !24
  %t32 = load i64, ptr %l20, !tbaa !24
  %t33 = mul i64 %t32, 1
  %t34 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t33)
  %t35 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  store { i64, ptr } %t36, ptr %l21, !tbaa !27
  %t37 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = load i64, ptr %l20, !tbaa !24
  %t42 = mul i64 %t41, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t38, ptr %t40, i64 %t42, i1 false)
  %t43 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t43, ptr %l19, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t44 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t44, ptr %rv
  br label %ret
bb8:
  %t45 = load %"std/os:FileInfo", ptr %l12
  store %"std/os:FileInfo" %t45, ptr %l3
  %t46 = call { i32, { i64, ptr } } @std_2fos_2eCwd(ptr %s0)
  %t47 = extractvalue { i32, { i64, ptr } } %t46, 1
  %t48 = extractvalue { i32, { i64, ptr } } %t46, 0
  store i32 %t48, ptr %l24
  %t49 = icmp ne i32 %t48, 0
  br i1 %t49, label %bb10, label %ok.50
ok.50:
  store { i64, ptr } %t47, ptr %l23
  br label %bb9
bb9:
  %t51 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t51, ptr %l22, !tbaa !27
  br label %bb12
bb10:
  br label %bb11
bb11:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d99, i32 0, i32 1) }, ptr %l25, !tbaa !27
  %t52 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t52, 0
  %t55 = extractvalue { i64, ptr } %t52, 1
  %t56 = mul i64 %t54, 1
  %t57 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t56)
  call void @llvm.memcpy.p0.p0.i64(ptr %t57, ptr %t55, i64 %t56, i1 false)
  %t58 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t57, 1
  store { i64, ptr } %t59, ptr %l22, !tbaa !27
  br label %bb12
bb12:
  %t61 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t61, ptr %l4, !tbaa !27
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/build:Config", ptr %t62, i32 0, i32 2
  %t65 = load %"compiler/target:Target", ptr %t64
  store %"compiler/target:Target" %t65, ptr %l5
  %t67 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t67, ptr %l30, !tbaa !27
  %t68 = getelementptr %"std/os:FileInfo", ptr %l3, i32 0, i32 1
  %t69 = load i64, ptr %t68, !tbaa !24
  store i64 %t69, ptr %l31, !tbaa !24
  %t70 = getelementptr %"std/os:FileInfo", ptr %l3, i32 0, i32 2
  %t71 = load i64, ptr %t70, !tbaa !24
  store i64 %t71, ptr %l32, !tbaa !24
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/build:Config", ptr %t72, i32 0, i32 4
  %t75 = load i1, ptr %t74, !tbaa !21
  store i1 %t75, ptr %l34, !tbaa !21
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/build:Config", ptr %t76, i32 0, i32 6
  %t79 = load i1, ptr %t78, !tbaa !21
  store i1 %t79, ptr %l36, !tbaa !21
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/build:Config", ptr %t80, i32 0, i32 7
  %t83 = load i1, ptr %t82, !tbaa !21
  store i1 %t83, ptr %l38, !tbaa !21
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/build:Config", ptr %t84, i32 0, i32 5
  %t87 = load i1, ptr %t86, !tbaa !21
  store i1 %t87, ptr %l40, !tbaa !21
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/build:Config", ptr %t88, i32 0, i32 9
  %t91 = load i1, ptr %t90, !tbaa !21
  store i1 %t91, ptr %l42, !tbaa !21
  store i1 %a1, ptr %l43, !tbaa !21
  %t93 = getelementptr %"compiler/target:Target", ptr %l5, i32 0, i32 1
  %t94 = load { i64, ptr }, ptr %t93, !tbaa !27
  store { i64, ptr } %t94, ptr %l44, !tbaa !27
  %t95 = getelementptr %"compiler/target:Target", ptr %l5, i32 0, i32 2
  %t96 = load { i64, ptr }, ptr %t95, !tbaa !27
  store { i64, ptr } %t96, ptr %l45, !tbaa !27
  %t97 = getelementptr %"compiler/target:Target", ptr %l5, i32 0, i32 4
  %t98 = load { i64, ptr }, ptr %t97, !tbaa !27
  store { i64, ptr } %t98, ptr %l46, !tbaa !27
  %t99 = getelementptr %"compiler/target:Target", ptr %l5, i32 0, i32 5
  %t100 = load { i64, ptr }, ptr %t99, !tbaa !27
  store { i64, ptr } %t100, ptr %l47, !tbaa !27
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/build:Config", ptr %t101, i32 0, i32 3
  %t105 = call { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eFingerprint(ptr %v0, ptr %s0, ptr %t103)
  store { i64, ptr } %t105, ptr %l50
  br label %bb13
bb13:
  %t106 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t106, ptr %l51, !tbaa !27
  %t107 = call { i64, ptr } @compiler_2fload_2eStdDir(ptr %s0)
  store { i64, ptr } %t107, ptr %l52
  br label %bb14
bb14:
  %t108 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t108, 1
  %t110 = extractvalue { i64, ptr } %t108, 0
  %t111 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d100, i32 0, i32 1) }, 1
  %t112 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d100, i32 0, i32 1) }, 0
  %t113 = add i64 %t110, %t112
  %t114 = load i64, ptr %l31, !tbaa !24
  %t115 = call i64 @__olang_fmt_i64(ptr null, i64 %t114)
  %t116 = add i64 %t113, %t115
  %t117 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d100, i32 0, i32 1) }, 1
  %t118 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d100, i32 0, i32 1) }, 0
  %t119 = add i64 %t116, %t118
  %t120 = load i64, ptr %l32, !tbaa !24
  %t121 = call i64 @__olang_fmt_i64(ptr null, i64 %t120)
  %t122 = add i64 %t119, %t121
  %t123 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d101, i32 0, i32 1) }, 1
  %t124 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d101, i32 0, i32 1) }, 0
  %t125 = add i64 %t122, %t124
  %t126 = load i1, ptr %l34, !tbaa !21
  %t127 = select i1 %t126, ptr @.c102, ptr @.c103
  %t128 = select i1 %t126, i64 4, i64 5
  %t129 = add i64 %t125, %t128
  %t130 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d100, i32 0, i32 1) }, 1
  %t131 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d100, i32 0, i32 1) }, 0
  %t132 = add i64 %t129, %t131
  %t133 = load i1, ptr %l36, !tbaa !21
  %t134 = select i1 %t133, ptr @.c102, ptr @.c103
  %t135 = select i1 %t133, i64 4, i64 5
  %t136 = add i64 %t132, %t135
  %t137 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d100, i32 0, i32 1) }, 1
  %t138 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d100, i32 0, i32 1) }, 0
  %t139 = add i64 %t136, %t138
  %t140 = load i1, ptr %l38, !tbaa !21
  %t141 = select i1 %t140, ptr @.c102, ptr @.c103
  %t142 = select i1 %t140, i64 4, i64 5
  %t143 = add i64 %t139, %t142
  %t144 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d100, i32 0, i32 1) }, 1
  %t145 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d100, i32 0, i32 1) }, 0
  %t146 = add i64 %t143, %t145
  %t147 = load i1, ptr %l40, !tbaa !21
  %t148 = select i1 %t147, ptr @.c102, ptr @.c103
  %t149 = select i1 %t147, i64 4, i64 5
  %t150 = add i64 %t146, %t149
  %t151 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d100, i32 0, i32 1) }, 1
  %t152 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d100, i32 0, i32 1) }, 0
  %t153 = add i64 %t150, %t152
  %t154 = load i1, ptr %l42, !tbaa !21
  %t155 = select i1 %t154, ptr @.c102, ptr @.c103
  %t156 = select i1 %t154, i64 4, i64 5
  %t157 = add i64 %t153, %t156
  %t158 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d100, i32 0, i32 1) }, 1
  %t159 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d100, i32 0, i32 1) }, 0
  %t160 = add i64 %t157, %t159
  %t161 = load i1, ptr %l43, !tbaa !21
  %t162 = select i1 %t161, ptr @.c102, ptr @.c103
  %t163 = select i1 %t161, i64 4, i64 5
  %t164 = add i64 %t160, %t163
  %t165 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d101, i32 0, i32 1) }, 1
  %t166 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d101, i32 0, i32 1) }, 0
  %t167 = add i64 %t164, %t166
  %t168 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t168, 1
  %t170 = extractvalue { i64, ptr } %t168, 0
  %t171 = add i64 %t167, %t170
  %t172 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d101, i32 0, i32 1) }, 1
  %t173 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d101, i32 0, i32 1) }, 0
  %t174 = add i64 %t171, %t173
  %t175 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t176 = extractvalue { i64, ptr } %t175, 1
  %t177 = extractvalue { i64, ptr } %t175, 0
  %t178 = add i64 %t174, %t177
  %t179 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d101, i32 0, i32 1) }, 1
  %t180 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d101, i32 0, i32 1) }, 0
  %t181 = add i64 %t178, %t180
  %t182 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t183 = extractvalue { i64, ptr } %t182, 1
  %t184 = extractvalue { i64, ptr } %t182, 0
  %t185 = add i64 %t181, %t184
  %t186 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d101, i32 0, i32 1) }, 1
  %t187 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d101, i32 0, i32 1) }, 0
  %t188 = add i64 %t185, %t187
  %t189 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t190 = extractvalue { i64, ptr } %t189, 1
  %t191 = extractvalue { i64, ptr } %t189, 0
  %t192 = add i64 %t188, %t191
  %t193 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d101, i32 0, i32 1) }, 1
  %t194 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d101, i32 0, i32 1) }, 0
  %t195 = add i64 %t192, %t194
  %t196 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t197 = extractvalue { i64, ptr } %t196, 1
  %t198 = extractvalue { i64, ptr } %t196, 0
  %t199 = add i64 %t195, %t198
  %t200 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d101, i32 0, i32 1) }, 1
  %t201 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d101, i32 0, i32 1) }, 0
  %t202 = add i64 %t199, %t201
  %t203 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t204 = extractvalue { i64, ptr } %t203, 1
  %t205 = extractvalue { i64, ptr } %t203, 0
  %t206 = add i64 %t202, %t205
  %t207 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d101, i32 0, i32 1) }, 1
  %t208 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d101, i32 0, i32 1) }, 0
  %t209 = add i64 %t206, %t208
  %t210 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t211 = extractvalue { i64, ptr } %t210, 1
  %t212 = extractvalue { i64, ptr } %t210, 0
  %t213 = add i64 %t209, %t212
  %t214 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t213)
  call void @olang_textcopy(ptr %t214, ptr %t109, i64 %t110)
  %t215 = getelementptr i8, ptr %t214, i64 %t110
  call void @olang_textcopy(ptr %t215, ptr %t111, i64 %t112)
  %t216 = getelementptr i8, ptr %t215, i64 %t112
  %t217 = call i64 @__olang_fmt_i64(ptr %t216, i64 %t114)
  %t218 = getelementptr i8, ptr %t216, i64 %t115
  call void @olang_textcopy(ptr %t218, ptr %t117, i64 %t118)
  %t219 = getelementptr i8, ptr %t218, i64 %t118
  %t220 = call i64 @__olang_fmt_i64(ptr %t219, i64 %t120)
  %t221 = getelementptr i8, ptr %t219, i64 %t121
  call void @olang_textcopy(ptr %t221, ptr %t123, i64 %t124)
  %t222 = getelementptr i8, ptr %t221, i64 %t124
  call void @olang_textcopy(ptr %t222, ptr %t127, i64 %t128)
  %t223 = getelementptr i8, ptr %t222, i64 %t128
  call void @olang_textcopy(ptr %t223, ptr %t130, i64 %t131)
  %t224 = getelementptr i8, ptr %t223, i64 %t131
  call void @olang_textcopy(ptr %t224, ptr %t134, i64 %t135)
  %t225 = getelementptr i8, ptr %t224, i64 %t135
  call void @olang_textcopy(ptr %t225, ptr %t137, i64 %t138)
  %t226 = getelementptr i8, ptr %t225, i64 %t138
  call void @olang_textcopy(ptr %t226, ptr %t141, i64 %t142)
  %t227 = getelementptr i8, ptr %t226, i64 %t142
  call void @olang_textcopy(ptr %t227, ptr %t144, i64 %t145)
  %t228 = getelementptr i8, ptr %t227, i64 %t145
  call void @olang_textcopy(ptr %t228, ptr %t148, i64 %t149)
  %t229 = getelementptr i8, ptr %t228, i64 %t149
  call void @olang_textcopy(ptr %t229, ptr %t151, i64 %t152)
  %t230 = getelementptr i8, ptr %t229, i64 %t152
  call void @olang_textcopy(ptr %t230, ptr %t155, i64 %t156)
  %t231 = getelementptr i8, ptr %t230, i64 %t156
  call void @olang_textcopy(ptr %t231, ptr %t158, i64 %t159)
  %t232 = getelementptr i8, ptr %t231, i64 %t159
  call void @olang_textcopy(ptr %t232, ptr %t162, i64 %t163)
  %t233 = getelementptr i8, ptr %t232, i64 %t163
  call void @olang_textcopy(ptr %t233, ptr %t165, i64 %t166)
  %t234 = getelementptr i8, ptr %t233, i64 %t166
  call void @olang_textcopy(ptr %t234, ptr %t169, i64 %t170)
  %t235 = getelementptr i8, ptr %t234, i64 %t170
  call void @olang_textcopy(ptr %t235, ptr %t172, i64 %t173)
  %t236 = getelementptr i8, ptr %t235, i64 %t173
  call void @olang_textcopy(ptr %t236, ptr %t176, i64 %t177)
  %t237 = getelementptr i8, ptr %t236, i64 %t177
  call void @olang_textcopy(ptr %t237, ptr %t179, i64 %t180)
  %t238 = getelementptr i8, ptr %t237, i64 %t180
  call void @olang_textcopy(ptr %t238, ptr %t183, i64 %t184)
  %t239 = getelementptr i8, ptr %t238, i64 %t184
  call void @olang_textcopy(ptr %t239, ptr %t186, i64 %t187)
  %t240 = getelementptr i8, ptr %t239, i64 %t187
  call void @olang_textcopy(ptr %t240, ptr %t190, i64 %t191)
  %t241 = getelementptr i8, ptr %t240, i64 %t191
  call void @olang_textcopy(ptr %t241, ptr %t193, i64 %t194)
  %t242 = getelementptr i8, ptr %t241, i64 %t194
  call void @olang_textcopy(ptr %t242, ptr %t197, i64 %t198)
  %t243 = getelementptr i8, ptr %t242, i64 %t198
  call void @olang_textcopy(ptr %t243, ptr %t200, i64 %t201)
  %t244 = getelementptr i8, ptr %t243, i64 %t201
  call void @olang_textcopy(ptr %t244, ptr %t204, i64 %t205)
  %t245 = getelementptr i8, ptr %t244, i64 %t205
  call void @olang_textcopy(ptr %t245, ptr %t207, i64 %t208)
  %t246 = getelementptr i8, ptr %t245, i64 %t208
  call void @olang_textcopy(ptr %t246, ptr %t211, i64 %t212)
  %t247 = insertvalue { i64, ptr } undef, i64 %t213, 0
  %t248 = insertvalue { i64, ptr } %t247, ptr %t214, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t248, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2folang_2ebuiltins(ptr %v0, ptr %v1, ptr %a0, i1 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/target:Target"
  %l22 = alloca i1
  %l23 = alloca ptr
  %l25 = alloca %"compiler/msgs:Msg"
  %l26 = alloca i32
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l39 = alloca i64
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = insertvalue [8 x { i64, ptr }] undef, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d104, i32 0, i32 1) }, 0
  %t2 = insertvalue [8 x { i64, ptr }] %t1, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d105, i32 0, i32 1) }, 1
  %t3 = insertvalue [8 x { i64, ptr }] %t2, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d106, i32 0, i32 1) }, 2
  %t4 = insertvalue [8 x { i64, ptr }] %t3, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d107, i32 0, i32 1) }, 3
  %t5 = insertvalue [8 x { i64, ptr }] %t4, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d108, i32 0, i32 1) }, 4
  %t6 = insertvalue [8 x { i64, ptr }] %t5, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d109, i32 0, i32 1) }, 5
  %t7 = insertvalue [8 x { i64, ptr }] %t6, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d110, i32 0, i32 1) }, 6
  %t8 = insertvalue [8 x { i64, ptr }] %t7, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d111, i32 0, i32 1) }, 7
  %t10 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 128, i64 8)
  store [8 x { i64, ptr }] %t8, ptr %t10
  store ptr %t10, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  %t12 = load ptr, ptr %l3
  store i64 8, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  %t15 = load i64, ptr %l4, !tbaa !24
  %t16 = load i64, ptr %l5, !tbaa !24
  %t19 = icmp slt i64 %t15, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb2, label %bb3
bb2:
  br label %bb14
bb3:
  br label %bb4
bb4:
  %t23 = load ptr, ptr %l3
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = getelementptr [8 x { i64, ptr }], ptr %t23, i64 0, i64 %t24
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !37
  store { i64, ptr } %t28, ptr %l6, !tbaa !27
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/build:Config", ptr %t30, i32 0, i32 3
  %t33 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t34 = load ptr, ptr @__olang_prog_scope
  %t37 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eHas(ptr %v0, ptr %t34, ptr %t32, { i64, ptr } %t33)
  store i1 %t37, ptr %l22
  br label %bb5
bb5:
  %t38 = load i1, ptr %l22, !tbaa !21
  br i1 %t38, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  store ptr %a2, ptr %l23, !tbaa !29
  %t40 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t41 = load ptr, ptr @__olang_prog_scope
  %t43 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefineBuiltin(ptr %t41, ptr %s3, { i64, ptr } %t40)
  store %"compiler/msgs:Msg" %t43, ptr %l25
  br label %bb8
bb7:
  br label %bb12
bb8:
  %t44 = load ptr, ptr %l23, !tbaa !29
  %t45 = load %"compiler/msgs:Msg", ptr %l25
  %t46 = call i32 @compiler_2folang_2eusage(ptr %v1, ptr %s3, ptr %t44, %"compiler/msgs:Msg" %t45)
  store i32 %t46, ptr %l26
  %t47 = icmp ne i32 %t46, 0
  br i1 %t47, label %bb10, label %ok.48
ok.48:
  br label %bb9
bb9:
  br label %bb11
bb10:
  %t49 = load i32, ptr %l26, !tbaa !23
  %t50 = lshr i32 %t49, 16
  %t51 = and i32 %t49, 65535
  %t52 = icmp eq i32 %t50, 1
  %t53 = select i1 %t52, i32 1, i32 0
  %t54 = icmp eq i32 %t49, 0
  %t55 = shl i32 %t53, 16
  %t56 = or i32 %t55, %t51
  %t57 = select i1 %t54, i32 0, i32 %t56
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s1)
  store i32 %t57, ptr %rv
  br label %ret
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t59 = load i64, ptr %l4, !tbaa !24
  %t61 = add i64 %t59, 1
  store i64 %t61, ptr %l4, !tbaa !24
  br label %bb1
bb14:
  call void @__olang_scope_close(ptr %s1)
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/build:Config", ptr %t63, i32 0, i32 2
  %t66 = load %"compiler/target:Target", ptr %t65
  store %"compiler/target:Target" %t66, ptr %l7
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/build:Config", ptr %t68, i32 0, i32 3
  store ptr %t70, ptr %l33, !tbaa !29
  %t71 = getelementptr %"compiler/target:Target", ptr %l7, i32 0, i32 3
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !27
  store { i64, ptr } %t72, ptr %l34, !tbaa !27
  %t73 = getelementptr %"compiler/target:Target", ptr %l7, i32 0, i32 2
  %t74 = load { i64, ptr }, ptr %t73, !tbaa !27
  store { i64, ptr } %t74, ptr %l35, !tbaa !27
  %t75 = getelementptr %"compiler/target:Target", ptr %l7, i32 0, i32 4
  %t76 = load { i64, ptr }, ptr %t75, !tbaa !27
  store { i64, ptr } %t76, ptr %l36, !tbaa !27
  %t77 = getelementptr %"compiler/target:Target", ptr %l7, i32 0, i32 7
  %t78 = load i64, ptr %t77, !tbaa !24
  store i64 %t78, ptr %l37, !tbaa !24
  %t79 = getelementptr %"compiler/target:Target", ptr %l7, i32 0, i32 8
  %t80 = load i1, ptr %t79, !tbaa !21
  br i1 %t80, label %bb15, label %bb16
bb15:
  store i64 1, ptr %l39, !tbaa !24
  br label %bb17
bb16:
  store i64 0, ptr %l39, !tbaa !24
  br label %bb17
bb17:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/build:Config", ptr %t82, i32 0, i32 4
  %t85 = load i1, ptr %t84, !tbaa !21
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/build:Config", ptr %t86, i32 0, i32 6
  %t89 = load i1, ptr %t88, !tbaa !21
  %t91 = load ptr, ptr %l33, !tbaa !29
  %t92 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t93 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t94 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t95 = load i64, ptr %l37, !tbaa !24
  %t96 = load i64, ptr %l39, !tbaa !24
  call void @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eBuiltins(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t91, { i64, ptr } %t92, { i64, ptr } %t93, { i64, ptr } %t94, i64 %t95, i64 %t96, i1 %t85, i1 %t89, i1 %a1)
  br label %bb18
bb18:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2folang_2ecIr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, ptr %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca %"std/prelude/text:StringBuilder"
  %l12 = alloca ptr
  %l13 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca %"std/os:Output"
  %lp18 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l20 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l27 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l29 = alloca i64
  %l31 = alloca i64
  %l36 = alloca { i64, ptr }
  %l49 = alloca [11 x { i64, ptr }]
  %l66 = alloca %"std/prelude/text:StringBuilder"
  %l68 = alloca i64
  %l70 = alloca i64
  %l75 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %l90 = alloca i64
  %l91 = alloca i64
  %l95 = alloca { i64, ptr }
  %l97 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %l100 = alloca i64
  %l106 = alloca { i64, ptr }
  %l108 = alloca { i64, ptr }
  %l109 = alloca i32
  %l111 = alloca i1
  %l112 = alloca { i64, ptr }
  %l116 = alloca i1
  %l119 = alloca { i64, ptr }
  %l120 = alloca i64
  %l121 = alloca { i64, ptr }
  %l124 = alloca i1
  %l125 = alloca { i64, ptr }
  %l126 = alloca { i64, ptr }
  %l127 = alloca i64
  %l128 = alloca { i64, ptr }
  %l129 = alloca %"std/os:Output"
  %l131 = alloca { i64, ptr }
  %l134 = alloca %"std/os:Output"
  %l135 = alloca i32
  %l137 = alloca i1
  %l138 = alloca { i64, ptr }
  %l139 = alloca { i64, ptr }
  %l140 = alloca i64
  %l141 = alloca { i64, ptr }
  %l145 = alloca i32
  %l147 = alloca i1
  %l148 = alloca { i64, ptr }
  %l149 = alloca { i64, ptr }
  %l150 = alloca i64
  %l151 = alloca { i64, ptr }
  %l155 = alloca { i64, ptr }
  %l156 = alloca { i64, ptr }
  %l157 = alloca i32
  %l161 = alloca i32
  %l163 = alloca i1
  %l167 = alloca i32
  %l169 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l20
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l20
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l3
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t5 = getelementptr %"compiler/build:Config", ptr %t3, i32 0, i32 1
  %t6 = load { i64, ptr }, ptr %t5, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 1
  %t9 = extractvalue { i64, ptr } %t6, 0
  %t10 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t9)
  call void @olang_textcopy(ptr %t10, ptr %t8, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t15 = extractvalue { i64, ptr } %t12, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l3, { i64, ptr } %t19)
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t24 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eCFlags(ptr %v2, ptr %s2, ptr %t22)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t24, ptr %l27
  br label %bb3
bb3:
  %t25 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l27
  %t26 = call ptr @__olang_scope_alloc_a(ptr %s2, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %t26
  store ptr %t26, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb4
bb4:
  %t28 = load i64, ptr %l5, !tbaa !24
  store i64 %t28, ptr %l29, !tbaa !24
  %t29 = load ptr, ptr %l4, !tbaa !29
  %t31 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s2, ptr %t29)
  store i64 %t31, ptr %l31
  br label %bb5
bb5:
  %t32 = load i64, ptr %l29, !tbaa !24
  %t33 = load i64, ptr %l31, !tbaa !24
  %t34 = icmp slt i64 %t32, %t33
  %t36 = xor i1 %t34, true
  br i1 %t36, label %bb6, label %bb7
bb6:
  br label %bb12
bb7:
  br label %bb8
bb8:
  %t38 = load ptr, ptr %l4, !tbaa !29
  %t39 = load i64, ptr %l5, !tbaa !24
  %t42 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s2, ptr %s2, ptr %t38, i64 %t39)
  store { i64, ptr } %t42, ptr %l36
  br label %bb9
bb9:
  %t43 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t43, 1
  %t47 = extractvalue { i64, ptr } %t43, 0
  %t48 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t47)
  call void @olang_textcopy(ptr %t48, ptr %t46, i64 %t47)
  %t49 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  %t52 = extractvalue { i64, ptr } %t50, 0
  %t53 = extractvalue { i64, ptr } %t50, 1
  %t54 = mul i64 %t52, 1
  %t55 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t54)
  call void @llvm.memcpy.p0.p0.i64(ptr %t55, ptr %t53, i64 %t54, i1 false)
  %t56 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l3, { i64, ptr } %t57)
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t60 = load i64, ptr %l5, !tbaa !24
  %t62 = add i64 %t60, 1
  store i64 %t62, ptr %l5, !tbaa !24
  br label %bb4
bb12:
  call void @__olang_scope_close(ptr %s2)
  %t64 = load ptr, ptr %l2, !tbaa !29
  %t66 = getelementptr %"compiler/build:Config", ptr %t64, i32 0, i32 4
  %t67 = load i1, ptr %t66, !tbaa !21
  br i1 %t67, label %bb13, label %bb14
bb13:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l3, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d112, i32 0, i32 1) })
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb16
bb16:
  %t70 = load ptr, ptr %l2, !tbaa !29
  %t72 = getelementptr %"compiler/build:Config", ptr %t70, i32 0, i32 6
  %t73 = load i1, ptr %t72, !tbaa !21
  br i1 %t73, label %bb17, label %bb18
bb17:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l3, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d113, i32 0, i32 1) })
  br label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s8
  %t76 = getelementptr [11 x { i64, ptr }], ptr %l49, i64 0, i64 0
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d114, i32 0, i32 1) }, ptr %t76, !tbaa !37
  %t77 = getelementptr [11 x { i64, ptr }], ptr %l49, i64 0, i64 1
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d115, i32 0, i32 1) }, ptr %t77, !tbaa !37
  %t78 = getelementptr [11 x { i64, ptr }], ptr %l49, i64 0, i64 2
  store { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d116, i32 0, i32 1) }, ptr %t78, !tbaa !37
  %t79 = getelementptr [11 x { i64, ptr }], ptr %l49, i64 0, i64 3
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d117, i32 0, i32 1) }, ptr %t79, !tbaa !37
  %t80 = getelementptr [11 x { i64, ptr }], ptr %l49, i64 0, i64 4
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d118, i32 0, i32 1) }, ptr %t80, !tbaa !37
  %t81 = getelementptr [11 x { i64, ptr }], ptr %l49, i64 0, i64 5
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d119, i32 0, i32 1) }, ptr %t81, !tbaa !37
  %t82 = getelementptr [11 x { i64, ptr }], ptr %l49, i64 0, i64 6
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d120, i32 0, i32 1) }, ptr %t82, !tbaa !37
  %t83 = getelementptr [11 x { i64, ptr }], ptr %l49, i64 0, i64 7
  store { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d121, i32 0, i32 1) }, ptr %t83, !tbaa !37
  %t84 = getelementptr [11 x { i64, ptr }], ptr %l49, i64 0, i64 8
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d122, i32 0, i32 1) }, ptr %t84, !tbaa !37
  %t85 = getelementptr [11 x { i64, ptr }], ptr %l49, i64 0, i64 9
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d123, i32 0, i32 1) }, ptr %t85, !tbaa !37
  %t86 = getelementptr [11 x { i64, ptr }], ptr %l49, i64 0, i64 10
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d124, i32 0, i32 1) }, ptr %t86, !tbaa !37
  %t87 = call ptr @__olang_scope_alloc_a(ptr %s8, i64 176, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t87, ptr %l49, i64 176, i1 false)
  store ptr %t87, ptr %l7
  store i64 0, ptr %l8, !tbaa !24
  %t89 = load ptr, ptr %l7
  store i64 11, ptr %l9, !tbaa !24
  br label %bb21
bb21:
  %t92 = load i64, ptr %l8, !tbaa !24
  %t93 = load i64, ptr %l9, !tbaa !24
  %t96 = icmp slt i64 %t92, %t93
  %t98 = xor i1 %t96, true
  br i1 %t98, label %bb22, label %bb23
bb22:
  br label %bb27
bb23:
  br label %bb24
bb24:
  %t100 = load ptr, ptr %l7
  %t101 = load i64, ptr %l8, !tbaa !24
  %t104 = getelementptr [11 x { i64, ptr }], ptr %t100, i64 0, i64 %t101
  %t105 = load { i64, ptr }, ptr %t104, !tbaa !37
  %t109 = extractvalue { i64, ptr } %t105, 1
  %t110 = extractvalue { i64, ptr } %t105, 0
  %t111 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t110)
  call void @olang_textcopy(ptr %t111, ptr %t109, i64 %t110)
  %t112 = insertvalue { i64, ptr } undef, i64 %t110, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t111, 1
  %t115 = extractvalue { i64, ptr } %t113, 0
  %t116 = extractvalue { i64, ptr } %t113, 1
  %t117 = mul i64 %t115, 1
  %t118 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t117)
  call void @llvm.memcpy.p0.p0.i64(ptr %t118, ptr %t116, i64 %t117, i1 false)
  %t119 = insertvalue { i64, ptr } undef, i64 %t115, 0
  %t120 = insertvalue { i64, ptr } %t119, ptr %t118, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l3, { i64, ptr } %t120)
  br label %bb25
bb25:
  br label %bb26
bb26:
  %t123 = load i64, ptr %l8, !tbaa !24
  %t125 = add i64 %t123, 1
  store i64 %t125, ptr %l8, !tbaa !24
  br label %bb21
bb27:
  call void @__olang_scope_close(ptr %s8)
  %t127 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t127, ptr %l66
  br label %bb28
bb28:
  %t128 = load %"std/prelude/text:StringBuilder", ptr %l66
  store %"std/prelude/text:StringBuilder" %t128, ptr %l11
  store ptr %l3, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  br label %bb29
bb29:
  store %olang.scope zeroinitializer, ptr %s13
  %t130 = load i64, ptr %l13, !tbaa !24
  store i64 %t130, ptr %l68, !tbaa !24
  %t131 = load ptr, ptr %l12, !tbaa !29
  %t133 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %t131)
  store i64 %t133, ptr %l70
  br label %bb30
bb30:
  %t134 = load i64, ptr %l68, !tbaa !24
  %t135 = load i64, ptr %l70, !tbaa !24
  %t136 = icmp slt i64 %t134, %t135
  %t138 = xor i1 %t136, true
  br i1 %t138, label %bb31, label %bb32
bb31:
  call void @__olang_scope_close(ptr %s13)
  br label %bb37
bb32:
  br label %bb33
bb33:
  %t140 = load ptr, ptr %l12, !tbaa !29
  %t141 = load i64, ptr %l13, !tbaa !24
  %t144 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t140, i64 %t141)
  store { i64, ptr } %t144, ptr %l75
  br label %bb34
bb34:
  %t145 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t148 = extractvalue { i64, ptr } %t145, 1
  %t149 = extractvalue { i64, ptr } %t145, 0
  %t150 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d125, i32 0, i32 1) }, 1
  %t151 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d125, i32 0, i32 1) }, 0
  %t152 = add i64 %t149, %t151
  %t153 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t152)
  call void @olang_textcopy(ptr %t153, ptr %t148, i64 %t149)
  %t154 = getelementptr i8, ptr %t153, i64 %t149
  call void @olang_textcopy(ptr %t154, ptr %t150, i64 %t151)
  %t155 = insertvalue { i64, ptr } undef, i64 %t152, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t153, 1
  %t158 = extractvalue { i64, ptr } %t156, 0
  %t159 = extractvalue { i64, ptr } %t156, 1
  %t160 = mul i64 %t158, 1
  %t161 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t160)
  call void @llvm.memcpy.p0.p0.i64(ptr %t161, ptr %t159, i64 %t160, i1 false)
  %t162 = insertvalue { i64, ptr } undef, i64 %t158, 0
  %t163 = insertvalue { i64, ptr } %t162, ptr %t161, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s13, ptr %l11, { i64, ptr } %t163)
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s13)
  br label %bb36
bb36:
  %t166 = load i64, ptr %l13, !tbaa !24
  %t168 = add i64 %t166, 1
  store i64 %t168, ptr %l13, !tbaa !24
  br label %bb29
bb37:
  %t170 = load ptr, ptr %l2, !tbaa !29
  %t172 = getelementptr %"compiler/build:Config", ptr %t170, i32 0, i32 2
  %t173 = getelementptr %"compiler/target:Target", ptr %t172, i32 0, i32 5
  %t174 = load { i64, ptr }, ptr %t173, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v2, ptr %l11, { i64, ptr } %t174)
  br label %bb38
bb38:
  %t177 = load { i64, ptr }, ptr %l1, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v1, ptr %l11, { i64, ptr } %t177)
  br label %bb39
bb39:
  %t180 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t180, ptr %l87, !tbaa !27
  %t181 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t183 = extractvalue { i64, ptr } %t181, 0
  %t185 = sub i64 %t183, 2
  store i64 %t185, ptr %l90, !tbaa !24
  %t186 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t187 = extractvalue { i64, ptr } %t186, 0
  store i64 %t187, ptr %l91, !tbaa !24
  %t188 = icmp sge i64 0, 0
  br i1 %t188, label %bb40, label %bb41
bb40:
  %t190 = load i64, ptr %l90, !tbaa !24
  %t191 = icmp sle i64 0, %t190
  br i1 %t191, label %bb42, label %bb43
bb41:
  call void @__olang_check_failed(ptr @olang_loc_57b10a8a18d2546b_cbe9beb9d768873f)
  unreachable
bb42:
  %t193 = load i64, ptr %l90, !tbaa !24
  %t194 = load i64, ptr %l91, !tbaa !24
  %t195 = icmp sle i64 %t193, %t194
  br i1 %t195, label %bb44, label %bb45
bb43:
  call void @__olang_check_failed(ptr @olang_loc_57b10a8a18d2546b_cbe9beb9d768873f)
  unreachable
bb44:
  %t197 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t198 = load ptr, ptr %t197, !tbaa !27
  %t199 = load i64, ptr %l90, !tbaa !24
  %t200 = getelementptr i8, ptr %t198, i64 0
  %t201 = sub i64 %t199, 0
  %t202 = insertvalue { i64, ptr } undef, i64 %t201, 0
  %t203 = insertvalue { i64, ptr } %t202, ptr %t200, 1
  store { i64, ptr } %t203, ptr %l95, !tbaa !27
  %t205 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l11)
  store { i64, ptr } %t205, ptr %l97
  br label %bb46
bb45:
  call void @__olang_check_failed(ptr @olang_loc_57b10a8a18d2546b_cbe9beb9d768873f)
  unreachable
bb46:
  %t206 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t208 = call { i64, ptr } @std_2fsha256_2eHex(ptr %s0, ptr %s0, { i64, ptr } %t206)
  store { i64, ptr } %t208, ptr %l99
  br label %bb47
bb47:
  %t209 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t210 = extractvalue { i64, ptr } %t209, 0
  store i64 %t210, ptr %l100, !tbaa !24
  %t211 = icmp sge i64 0, 0
  br i1 %t211, label %bb48, label %bb49
bb48:
  %t213 = icmp sle i64 0, 16
  br i1 %t213, label %bb50, label %bb51
bb49:
  call void @__olang_check_failed(ptr @olang_loc_57b10a8a18d2546b_cbe9beb9d768873f)
  unreachable
bb50:
  %t215 = load i64, ptr %l100, !tbaa !24
  %t216 = icmp sle i64 16, %t215
  br i1 %t216, label %bb52, label %bb53
bb51:
  call void @__olang_check_failed(ptr @olang_loc_57b10a8a18d2546b_cbe9beb9d768873f)
  unreachable
bb52:
  %t218 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t219 = load ptr, ptr %t218, !tbaa !27
  %t220 = getelementptr i8, ptr %t219, i64 0
  %t221 = sub i64 16, 0
  %t222 = insertvalue { i64, ptr } undef, i64 %t221, 0
  %t223 = insertvalue { i64, ptr } %t222, ptr %t220, 1
  %t224 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t225 = extractvalue { i64, ptr } %t224, 1
  %t226 = extractvalue { i64, ptr } %t224, 0
  %t227 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d126, i32 0, i32 1) }, 1
  %t228 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d126, i32 0, i32 1) }, 0
  %t229 = add i64 %t226, %t228
  %t231 = extractvalue { i64, ptr } %t223, 1
  %t232 = extractvalue { i64, ptr } %t223, 0
  %t233 = add i64 %t229, %t232
  %t234 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d127, i32 0, i32 1) }, 1
  %t235 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d127, i32 0, i32 1) }, 0
  %t236 = add i64 %t233, %t235
  %t237 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t236)
  call void @olang_textcopy(ptr %t237, ptr %t225, i64 %t226)
  %t238 = getelementptr i8, ptr %t237, i64 %t226
  call void @olang_textcopy(ptr %t238, ptr %t227, i64 %t228)
  %t239 = getelementptr i8, ptr %t238, i64 %t228
  call void @olang_textcopy(ptr %t239, ptr %t231, i64 %t232)
  %t240 = getelementptr i8, ptr %t239, i64 %t232
  call void @olang_textcopy(ptr %t240, ptr %t234, i64 %t235)
  %t241 = insertvalue { i64, ptr } undef, i64 %t236, 0
  %t242 = insertvalue { i64, ptr } %t241, ptr %t237, 1
  store { i64, ptr } %t242, ptr %l15, !tbaa !27
  %t244 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t246 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s0, { i64, ptr } %t244)
  %t247 = extractvalue { i32, { i64, ptr } } %t246, 1
  %t248 = extractvalue { i32, { i64, ptr } } %t246, 0
  store i32 %t248, ptr %l109
  %t249 = icmp ne i32 %t248, 0
  br i1 %t249, label %bb55, label %ok.250
ok.250:
  store { i64, ptr } %t247, ptr %l108
  br label %bb54
bb53:
  call void @__olang_check_failed(ptr @olang_loc_57b10a8a18d2546b_cbe9beb9d768873f)
  unreachable
bb54:
  %t251 = load { i64, ptr }, ptr %l108, !tbaa !27
  store { i64, ptr } %t251, ptr %l106, !tbaa !27
  br label %bb57
bb55:
  %t252 = load i32, ptr %l109, !tbaa !23
  %t253 = ashr i32 %t252, 16
  %t255 = icmp eq i32 %t253, 1
  store i1 %t255, ptr %l111, !tbaa !21
  br label %bb56
bb56:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d128, i32 0, i32 1) }, ptr %l112, !tbaa !27
  %t256 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t258 = extractvalue { i64, ptr } %t256, 0
  %t259 = extractvalue { i64, ptr } %t256, 1
  %t260 = mul i64 %t258, 1
  %t261 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t260)
  call void @llvm.memcpy.p0.p0.i64(ptr %t261, ptr %t259, i64 %t260, i1 false)
  %t262 = insertvalue { i64, ptr } undef, i64 %t258, 0
  %t263 = insertvalue { i64, ptr } %t262, ptr %t261, 1
  store { i64, ptr } %t263, ptr %l106, !tbaa !27
  br label %bb57
bb57:
  %t265 = load { i64, ptr }, ptr %l106, !tbaa !27
  store { i64, ptr } %t265, ptr %l16, !tbaa !27
  %t266 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t268 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t266, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d129, i32 0, i32 1) })
  store i1 %t268, ptr %l116
  br label %bb58
bb58:
  %t269 = load i1, ptr %l116, !tbaa !21
  %t270 = xor i1 %t269, true
  br i1 %t270, label %bb59, label %bb60
bb59:
  %t272 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t272, ptr %l119, !tbaa !27
  %t274 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t275 = extractvalue { i64, ptr } %t274, 0
  store i64 %t275, ptr %l120, !tbaa !24
  %t276 = load i64, ptr %l120, !tbaa !24
  %t277 = mul i64 %t276, 1
  %t278 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t277)
  %t279 = insertvalue { i64, ptr } undef, i64 %t276, 0
  %t280 = insertvalue { i64, ptr } %t279, ptr %t278, 1
  store { i64, ptr } %t280, ptr %l121, !tbaa !27
  %t281 = getelementptr { i64, ptr }, ptr %l121, i32 0, i32 1
  %t282 = load ptr, ptr %t281, !tbaa !27
  %t283 = getelementptr { i64, ptr }, ptr %l119, i32 0, i32 1
  %t284 = load ptr, ptr %t283, !tbaa !27
  %t285 = load i64, ptr %l120, !tbaa !24
  %t286 = mul i64 %t285, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t282, ptr %t284, i64 %t286, i1 false)
  %t287 = load { i64, ptr }, ptr %l121, !tbaa !27
  store { i64, ptr } %t287, ptr %l119, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t288 = load { i64, ptr }, ptr %l119, !tbaa !27
  store { i64, ptr } %t288, ptr %rv
  br label %ret
bb60:
  br label %bb61
bb61:
  %t289 = load ptr, ptr %l2, !tbaa !29
  %t291 = getelementptr %"compiler/build:Config", ptr %t289, i32 0, i32 1
  %t292 = load { i64, ptr }, ptr %t291, !tbaa !27
  %t294 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t292, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d130, i32 0, i32 1) })
  store i1 %t294, ptr %l124
  br label %bb62
bb62:
  %t295 = load i1, ptr %l124, !tbaa !21
  br i1 %t295, label %bb63, label %bb64
bb63:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d131, i32 0, i32 1) }, ptr %l125, !tbaa !27
  %t296 = load { i64, ptr }, ptr %l125, !tbaa !27
  store { i64, ptr } %t296, ptr %l126, !tbaa !27
  %t297 = load { i64, ptr }, ptr %l126, !tbaa !27
  %t298 = extractvalue { i64, ptr } %t297, 0
  store i64 %t298, ptr %l127, !tbaa !24
  %t299 = load i64, ptr %l127, !tbaa !24
  %t300 = mul i64 %t299, 1
  %t301 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t300)
  %t302 = insertvalue { i64, ptr } undef, i64 %t299, 0
  %t303 = insertvalue { i64, ptr } %t302, ptr %t301, 1
  store { i64, ptr } %t303, ptr %l128, !tbaa !27
  %t304 = getelementptr { i64, ptr }, ptr %l128, i32 0, i32 1
  %t305 = load ptr, ptr %t304, !tbaa !27
  %t306 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t307 = load ptr, ptr %t306, !tbaa !27
  %t308 = load i64, ptr %l127, !tbaa !24
  %t309 = mul i64 %t308, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t305, ptr %t307, i64 %t309, i1 false)
  %t310 = load { i64, ptr }, ptr %l128, !tbaa !27
  store { i64, ptr } %t310, ptr %l126, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t311 = load { i64, ptr }, ptr %l126, !tbaa !27
  store { i64, ptr } %t311, ptr %rv
  br label %ret
bb64:
  br label %bb65
bb65:
  %t313 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %s0, ptr %s0, ptr %l3)
  store { i64, ptr } %t313, ptr %l131
  br label %bb66
bb66:
  %t314 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t316 = load { i64, ptr }, ptr %l131, !tbaa !27
  %t318 = call { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %s0, ptr %v1, ptr %s0, ptr %s0, { i64, ptr } %t316, { i64, ptr } %t314, i1 true, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d132, i32 0, i32 1) })
  %t319 = extractvalue { i32, %"std/os:Output" } %t318, 1
  %t320 = extractvalue { i32, %"std/os:Output" } %t318, 0
  store i32 %t320, ptr %l135
  %t321 = icmp ne i32 %t320, 0
  br i1 %t321, label %bb68, label %ok.322
ok.322:
  store %"std/os:Output" %t319, ptr %l134
  br label %bb67
bb67:
  %t323 = load %"std/os:Output", ptr %l134
  store %"std/os:Output" %t323, ptr %l129
  br label %bb70
bb68:
  %t324 = load i32, ptr %l135, !tbaa !23
  %t325 = ashr i32 %t324, 16
  %t327 = icmp eq i32 %t325, 1
  store i1 %t327, ptr %l137, !tbaa !21
  br label %bb69
bb69:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d133, i32 0, i32 1) }, ptr %l138, !tbaa !27
  %t328 = load { i64, ptr }, ptr %l138, !tbaa !27
  store { i64, ptr } %t328, ptr %l139, !tbaa !27
  %t329 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t330 = extractvalue { i64, ptr } %t329, 0
  store i64 %t330, ptr %l140, !tbaa !24
  %t331 = load i64, ptr %l140, !tbaa !24
  %t332 = mul i64 %t331, 1
  %t333 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t332)
  %t334 = insertvalue { i64, ptr } undef, i64 %t331, 0
  %t335 = insertvalue { i64, ptr } %t334, ptr %t333, 1
  store { i64, ptr } %t335, ptr %l141, !tbaa !27
  %t336 = getelementptr { i64, ptr }, ptr %l141, i32 0, i32 1
  %t337 = load ptr, ptr %t336, !tbaa !27
  %t338 = getelementptr { i64, ptr }, ptr %l139, i32 0, i32 1
  %t339 = load ptr, ptr %t338, !tbaa !27
  %t340 = load i64, ptr %l140, !tbaa !24
  %t341 = mul i64 %t340, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t337, ptr %t339, i64 %t341, i1 false)
  %t342 = load { i64, ptr }, ptr %l141, !tbaa !27
  store { i64, ptr } %t342, ptr %l139, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t343 = load { i64, ptr }, ptr %l139, !tbaa !27
  store { i64, ptr } %t343, ptr %rv
  br label %ret
bb70:
  %t344 = load %"std/os:Output", ptr %l129
  store %"std/os:Output" %t344, ptr %l17
  %t345 = getelementptr %"std/os:Output", ptr %l17, i32 0, i32 0
  %t346 = load i32, ptr %t345, !tbaa !23
  %t348 = icmp ne i32 %t346, 0
  br i1 %t348, label %bb71, label %bb72
bb71:
  %t350 = getelementptr %"std/os:Output", ptr %l17, i32 0, i32 2
  %t351 = load { i64, ptr }, ptr %t350, !tbaa !27
  %t353 = call i32 @std_2fio_2ePrintErr(ptr %s0, { i64, ptr } %t351)
  store i32 %t353, ptr %l145
  %t354 = icmp ne i32 %t353, 0
  br i1 %t354, label %bb74, label %ok.355
ok.355:
  br label %bb73
bb72:
  br label %bb77
bb73:
  br label %bb76
bb74:
  %t356 = load i32, ptr %l145, !tbaa !23
  %t357 = ashr i32 %t356, 16
  %t359 = icmp eq i32 %t357, 1
  store i1 %t359, ptr %l147, !tbaa !21
  br label %bb75
bb75:
  call void @__olang_ert_req_clear()
  br label %bb76
bb76:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d134, i32 0, i32 1) }, ptr %l148, !tbaa !27
  %t360 = load { i64, ptr }, ptr %l148, !tbaa !27
  store { i64, ptr } %t360, ptr %l149, !tbaa !27
  %t361 = load { i64, ptr }, ptr %l149, !tbaa !27
  %t362 = extractvalue { i64, ptr } %t361, 0
  store i64 %t362, ptr %l150, !tbaa !24
  %t363 = load i64, ptr %l150, !tbaa !24
  %t364 = mul i64 %t363, 1
  %t365 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t364)
  %t366 = insertvalue { i64, ptr } undef, i64 %t363, 0
  %t367 = insertvalue { i64, ptr } %t366, ptr %t365, 1
  store { i64, ptr } %t367, ptr %l151, !tbaa !27
  %t368 = getelementptr { i64, ptr }, ptr %l151, i32 0, i32 1
  %t369 = load ptr, ptr %t368, !tbaa !27
  %t370 = getelementptr { i64, ptr }, ptr %l149, i32 0, i32 1
  %t371 = load ptr, ptr %t370, !tbaa !27
  %t372 = load i64, ptr %l150, !tbaa !24
  %t373 = mul i64 %t372, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t369, ptr %t371, i64 %t373, i1 false)
  %t374 = load { i64, ptr }, ptr %l151, !tbaa !27
  store { i64, ptr } %t374, ptr %l149, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t375 = load { i64, ptr }, ptr %l149, !tbaa !27
  store { i64, ptr } %t375, ptr %rv
  br label %ret
bb77:
  %t376 = getelementptr %"std/os:Output", ptr %l17, i32 0, i32 1
  %t377 = load { i64, ptr }, ptr %t376, !tbaa !27
  %t378 = load ptr, ptr %l2, !tbaa !29
  %t380 = getelementptr %"compiler/build:Config", ptr %t378, i32 0, i32 2
  %t381 = getelementptr %"compiler/target:Target", ptr %t380, i32 0, i32 5
  %t382 = load { i64, ptr }, ptr %t381, !tbaa !27
  %t385 = call { i64, ptr } @compiler_2folang_2eretarget(ptr %s0, ptr %v2, ptr %v3, { i64, ptr } %t377, { i64, ptr } %t382)
  store { i64, ptr } %t385, ptr %l155
  br label %bb78
bb78:
  %t386 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 16, i64 8)
  store ptr %t386, ptr %lp18
  %t387 = load { i64, ptr }, ptr %l155, !tbaa !27
  %t388 = load ptr, ptr %lp18
  store { i64, ptr } %t387, ptr %t388, !tbaa !27
  %t389 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t389, ptr %l156, !tbaa !27
  %t390 = call i32 @compiler_2fbuild_2ePid()
  store i32 %t390, ptr %l157
  br label %bb79
bb79:
  %t391 = load { i64, ptr }, ptr %l156, !tbaa !27
  %t392 = extractvalue { i64, ptr } %t391, 1
  %t393 = extractvalue { i64, ptr } %t391, 0
  %t394 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d135, i32 0, i32 1) }, 1
  %t395 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d135, i32 0, i32 1) }, 0
  %t396 = add i64 %t393, %t395
  %t397 = load i32, ptr %l157, !tbaa !23
  %t398 = sext i32 %t397 to i64
  %t399 = call i64 @__olang_fmt_i64(ptr null, i64 %t398)
  %t400 = add i64 %t396, %t399
  %t401 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d136, i32 0, i32 1) }, 1
  %t402 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d136, i32 0, i32 1) }, 0
  %t403 = add i64 %t400, %t402
  %t404 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t403)
  call void @olang_textcopy(ptr %t404, ptr %t392, i64 %t393)
  %t405 = getelementptr i8, ptr %t404, i64 %t393
  call void @olang_textcopy(ptr %t405, ptr %t394, i64 %t395)
  %t406 = getelementptr i8, ptr %t405, i64 %t395
  %t407 = call i64 @__olang_fmt_i64(ptr %t406, i64 %t398)
  %t408 = getelementptr i8, ptr %t406, i64 %t399
  call void @olang_textcopy(ptr %t408, ptr %t401, i64 %t402)
  %t409 = insertvalue { i64, ptr } undef, i64 %t403, 0
  %t410 = insertvalue { i64, ptr } %t409, ptr %t404, 1
  store { i64, ptr } %t410, ptr %l19, !tbaa !27
  %t412 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t413 = load ptr, ptr %lp18
  %t414 = load { i64, ptr }, ptr %t413, !tbaa !27
  %t417 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %v3, { i64, ptr } %t412, { i64, ptr } %t414)
  store i32 %t417, ptr %l161
  %t418 = icmp ne i32 %t417, 0
  br i1 %t418, label %bb81, label %ok.419
ok.419:
  br label %bb80
bb80:
  br label %bb83
bb81:
  %t420 = load i32, ptr %l161, !tbaa !23
  %t421 = ashr i32 %t420, 16
  %t423 = icmp eq i32 %t421, 1
  store i1 %t423, ptr %l163, !tbaa !21
  br label %bb82
bb82:
  call void @__olang_ert_req_clear()
  %t424 = load ptr, ptr %lp18
  %t425 = load { i64, ptr }, ptr %t424, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t425, ptr %rv
  br label %ret
bb83:
  %t427 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t428 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t431 = call i32 @std_2fos_2eRename(ptr %s0, ptr %s0, { i64, ptr } %t427, { i64, ptr } %t428)
  store i32 %t431, ptr %l167
  %t432 = icmp ne i32 %t431, 0
  br i1 %t432, label %bb85, label %ok.433
ok.433:
  br label %bb84
bb84:
  br label %bb87
bb85:
  %t434 = load i32, ptr %l167, !tbaa !23
  %t435 = ashr i32 %t434, 16
  %t437 = icmp eq i32 %t435, 1
  store i1 %t437, ptr %l169, !tbaa !21
  br label %bb86
bb86:
  call void @__olang_ert_req_clear()
  br label %bb87
bb87:
  %t438 = load ptr, ptr %lp18
  %t439 = load { i64, ptr }, ptr %t438, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t439, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2folang_2ecLibrary(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"std/os:FileInfo"
  %l4 = alloca %"std/os:FileInfo"
  %l5 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca ptr
  %l7 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca %"std/os:Output"
  %l14 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l24 = alloca %"std/os:FileInfo"
  %l26 = alloca %"std/os:FileInfo"
  %l27 = alloca i32
  %l29 = alloca i1
  %l30 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca { i64, ptr }
  %l34 = alloca %"std/os:FileInfo"
  %l36 = alloca %"std/os:FileInfo"
  %l37 = alloca i32
  %l39 = alloca i1
  %l41 = alloca %"std/os:FileInfo"
  %l45 = alloca i1
  %l51 = alloca i1
  %l52 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l54 = alloca i64
  %l55 = alloca { i64, ptr }
  %l56 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l63 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l65 = alloca i64
  %l67 = alloca i64
  %l72 = alloca { i64, ptr }
  %l83 = alloca [9 x { i64, ptr }]
  %l100 = alloca %"std/os:Output"
  %l102 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %l104 = alloca %"std/os:Output"
  %l105 = alloca i32
  %l107 = alloca i1
  %l108 = alloca { i64, ptr }
  %l109 = alloca { i64, ptr }
  %l110 = alloca i64
  %l111 = alloca { i64, ptr }
  %l115 = alloca { i64, ptr }
  %l121 = alloca i32
  %l123 = alloca i1
  %l124 = alloca { i64, ptr }
  %l125 = alloca { i64, ptr }
  %l126 = alloca i64
  %l127 = alloca { i64, ptr }
  %l129 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l14, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t2, 0
  %t6 = sub i64 %t4, 2
  store i64 %t6, ptr %l17, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t7, 0
  store i64 %t8, ptr %l18, !tbaa !24
  %t9 = icmp sge i64 0, 0
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l17, !tbaa !24
  %t12 = icmp sle i64 0, %t11
  br i1 %t12, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_7f1024592ae32589_c3207624e3c1a39d)
  unreachable
bb3:
  %t14 = load i64, ptr %l17, !tbaa !24
  %t15 = load i64, ptr %l18, !tbaa !24
  %t16 = icmp sle i64 %t14, %t15
  br i1 %t16, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_7f1024592ae32589_c3207624e3c1a39d)
  unreachable
bb5:
  %t18 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = load i64, ptr %l17, !tbaa !24
  %t21 = getelementptr i8, ptr %t19, i64 0
  %t22 = sub i64 %t20, 0
  %t23 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t21, 1
  %t26 = extractvalue { i64, ptr } %t24, 1
  %t27 = extractvalue { i64, ptr } %t24, 0
  %t28 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d137, i32 0, i32 1) }, 1
  %t29 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d137, i32 0, i32 1) }, 0
  %t30 = add i64 %t27, %t29
  %t31 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t30)
  call void @olang_textcopy(ptr %t31, ptr %t26, i64 %t27)
  %t32 = getelementptr i8, ptr %t31, i64 %t27
  call void @olang_textcopy(ptr %t32, ptr %t28, i64 %t29)
  %t33 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t31, 1
  store { i64, ptr } %t34, ptr %l2, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t38 = call { i32, %"std/os:FileInfo" } @std_2fos_2eStat(ptr %v0, { i64, ptr } %t36)
  %t39 = extractvalue { i32, %"std/os:FileInfo" } %t38, 1
  %t40 = extractvalue { i32, %"std/os:FileInfo" } %t38, 0
  store i32 %t40, ptr %l27
  %t41 = icmp ne i32 %t40, 0
  br i1 %t41, label %bb8, label %ok.42
ok.42:
  store %"std/os:FileInfo" %t39, ptr %l26
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_7f1024592ae32589_c3207624e3c1a39d)
  unreachable
bb7:
  %t43 = load %"std/os:FileInfo", ptr %l26
  store %"std/os:FileInfo" %t43, ptr %l24
  br label %bb10
bb8:
  %t44 = load i32, ptr %l27, !tbaa !23
  %t45 = ashr i32 %t44, 16
  %t47 = icmp eq i32 %t45, 1
  store i1 %t47, ptr %l29, !tbaa !21
  br label %bb9
bb9:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d138, i32 0, i32 1) }, ptr %l30, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t48, ptr %l31, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 0
  store i64 %t50, ptr %l32, !tbaa !24
  %t51 = load i64, ptr %l32, !tbaa !24
  %t52 = mul i64 %t51, 1
  %t53 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t52)
  %t54 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t53, 1
  store { i64, ptr } %t55, ptr %l33, !tbaa !27
  %t56 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = load i64, ptr %l32, !tbaa !24
  %t61 = mul i64 %t60, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t57, ptr %t59, i64 %t61, i1 false)
  %t62 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t62, ptr %l31, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t63 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t63, ptr %rv
  br label %ret
bb10:
  %t64 = load %"std/os:FileInfo", ptr %l24
  store %"std/os:FileInfo" %t64, ptr %l3
  %t65 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t67 = call { i32, %"std/os:FileInfo" } @std_2fos_2eStat(ptr %s0, { i64, ptr } %t65)
  %t68 = extractvalue { i32, %"std/os:FileInfo" } %t67, 1
  %t69 = extractvalue { i32, %"std/os:FileInfo" } %t67, 0
  store i32 %t69, ptr %l37
  %t70 = icmp ne i32 %t69, 0
  br i1 %t70, label %bb12, label %ok.71
ok.71:
  store %"std/os:FileInfo" %t68, ptr %l36
  br label %bb11
bb11:
  %t72 = load %"std/os:FileInfo", ptr %l36
  store %"std/os:FileInfo" %t72, ptr %l34
  br label %bb15
bb12:
  %t73 = load i32, ptr %l37, !tbaa !23
  %t74 = ashr i32 %t73, 16
  %t76 = icmp eq i32 %t74, 1
  store i1 %t76, ptr %l39, !tbaa !21
  br label %bb13
bb13:
  call void @__olang_ert_req_clear()
  %t78 = call %"std/os:FileInfo" @std_2fos_3aFileInfo_2ector(ptr %s0, i32 2, i64 0, i64 0)
  store %"std/os:FileInfo" %t78, ptr %l41
  br label %bb14
bb14:
  %t79 = load %"std/os:FileInfo", ptr %l41
  store %"std/os:FileInfo" %t79, ptr %l34
  br label %bb15
bb15:
  %t80 = load %"std/os:FileInfo", ptr %l34
  store %"std/os:FileInfo" %t80, ptr %l4
  %t81 = getelementptr %"std/os:FileInfo", ptr %l4, i32 0, i32 0
  %t82 = load i32, ptr %t81
  %t84 = trunc i64 0 to i32
  %t85 = icmp eq i32 %t82, %t84
  %t87 = xor i1 %t85, true
  br i1 %t87, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l45, !tbaa !21
  br label %bb18
bb17:
  %t89 = getelementptr %"std/os:FileInfo", ptr %l4, i32 0, i32 2
  %t90 = load i64, ptr %t89, !tbaa !24
  %t91 = getelementptr %"std/os:FileInfo", ptr %l3, i32 0, i32 2
  %t92 = load i64, ptr %t91, !tbaa !24
  %t95 = icmp slt i64 %t90, %t92
  store i1 %t95, ptr %l45, !tbaa !21
  br label %bb18
bb18:
  %t97 = load i1, ptr %l45, !tbaa !21
  br i1 %t97, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t98 = load ptr, ptr %l1, !tbaa !29
  %t100 = getelementptr %"compiler/build:Config", ptr %t98, i32 0, i32 1
  %t101 = load { i64, ptr }, ptr %t100, !tbaa !27
  %t103 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s3, { i64, ptr } %t101, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d139, i32 0, i32 1) })
  store i1 %t103, ptr %l51
  br label %bb21
bb20:
  br label %bb57
bb21:
  %t104 = load i1, ptr %l51, !tbaa !21
  br i1 %t104, label %bb22, label %bb23
bb22:
  store { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d140, i32 0, i32 1) }, ptr %l52, !tbaa !27
  %t105 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t105, ptr %l53, !tbaa !27
  %t106 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t106, 0
  store i64 %t107, ptr %l54, !tbaa !24
  %t108 = load i64, ptr %l54, !tbaa !24
  %t109 = mul i64 %t108, 1
  %t110 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t109)
  %t111 = insertvalue { i64, ptr } undef, i64 %t108, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  store { i64, ptr } %t112, ptr %l55, !tbaa !27
  %t113 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = load i64, ptr %l54, !tbaa !24
  %t118 = mul i64 %t117, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t114, ptr %t116, i64 %t118, i1 false)
  %t119 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t119, ptr %l53, !tbaa !27
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t120 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t120, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  %t121 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s3, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t121, ptr %l56
  br label %bb25
bb25:
  %t122 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l56
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t122, ptr %l5
  %t123 = load ptr, ptr %l1, !tbaa !29
  %t125 = getelementptr %"compiler/build:Config", ptr %t123, i32 0, i32 1
  %t126 = load { i64, ptr }, ptr %t125, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t126, 1
  %t129 = extractvalue { i64, ptr } %t126, 0
  %t130 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t129)
  call void @olang_textcopy(ptr %t130, ptr %t128, i64 %t129)
  %t131 = insertvalue { i64, ptr } undef, i64 %t129, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr %t130, 1
  %t134 = extractvalue { i64, ptr } %t132, 0
  %t135 = extractvalue { i64, ptr } %t132, 1
  %t136 = mul i64 %t134, 1
  %t137 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t136)
  call void @llvm.memcpy.p0.p0.i64(ptr %t137, ptr %t135, i64 %t136, i1 false)
  %t138 = insertvalue { i64, ptr } undef, i64 %t134, 0
  %t139 = insertvalue { i64, ptr } %t138, ptr %t137, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s3, ptr %s3, ptr %l5, { i64, ptr } %t139)
  br label %bb26
bb26:
  store %olang.scope zeroinitializer, ptr %s6
  %t142 = load ptr, ptr %l1, !tbaa !29
  %t144 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eCFlags(ptr %v1, ptr %s6, ptr %t142)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t144, ptr %l63
  br label %bb27
bb27:
  %t145 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l63
  %t146 = call ptr @__olang_scope_alloc_a(ptr %s6, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t145, ptr %t146
  store ptr %t146, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb28
bb28:
  %t148 = load i64, ptr %l7, !tbaa !24
  store i64 %t148, ptr %l65, !tbaa !24
  %t149 = load ptr, ptr %l6, !tbaa !29
  %t151 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s6, ptr %t149)
  store i64 %t151, ptr %l67
  br label %bb29
bb29:
  %t152 = load i64, ptr %l65, !tbaa !24
  %t153 = load i64, ptr %l67, !tbaa !24
  %t154 = icmp slt i64 %t152, %t153
  %t156 = xor i1 %t154, true
  br i1 %t156, label %bb30, label %bb31
bb30:
  br label %bb36
bb31:
  br label %bb32
bb32:
  %t158 = load ptr, ptr %l6, !tbaa !29
  %t159 = load i64, ptr %l7, !tbaa !24
  %t162 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s6, ptr %s6, ptr %t158, i64 %t159)
  store { i64, ptr } %t162, ptr %l72
  br label %bb33
bb33:
  %t163 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t166 = extractvalue { i64, ptr } %t163, 1
  %t167 = extractvalue { i64, ptr } %t163, 0
  %t168 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t167)
  call void @olang_textcopy(ptr %t168, ptr %t166, i64 %t167)
  %t169 = insertvalue { i64, ptr } undef, i64 %t167, 0
  %t170 = insertvalue { i64, ptr } %t169, ptr %t168, 1
  %t172 = extractvalue { i64, ptr } %t170, 0
  %t173 = extractvalue { i64, ptr } %t170, 1
  %t174 = mul i64 %t172, 1
  %t175 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t174)
  call void @llvm.memcpy.p0.p0.i64(ptr %t175, ptr %t173, i64 %t174, i1 false)
  %t176 = insertvalue { i64, ptr } undef, i64 %t172, 0
  %t177 = insertvalue { i64, ptr } %t176, ptr %t175, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s3, ptr %s3, ptr %l5, { i64, ptr } %t177)
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t180 = load i64, ptr %l7, !tbaa !24
  %t182 = add i64 %t180, 1
  store i64 %t182, ptr %l7, !tbaa !24
  br label %bb28
bb36:
  call void @__olang_scope_close(ptr %s6)
  store %olang.scope zeroinitializer, ptr %s10
  %t184 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t186 = extractvalue { i64, ptr } %t184, 1
  %t187 = extractvalue { i64, ptr } %t184, 0
  %t188 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d141, i32 0, i32 1) }, 1
  %t189 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d141, i32 0, i32 1) }, 0
  %t190 = add i64 %t187, %t189
  %t191 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t190)
  call void @olang_textcopy(ptr %t191, ptr %t186, i64 %t187)
  %t192 = getelementptr i8, ptr %t191, i64 %t187
  call void @olang_textcopy(ptr %t192, ptr %t188, i64 %t189)
  %t193 = insertvalue { i64, ptr } undef, i64 %t190, 0
  %t194 = insertvalue { i64, ptr } %t193, ptr %t191, 1
  %t196 = extractvalue { i64, ptr } %t194, 0
  %t197 = extractvalue { i64, ptr } %t194, 1
  %t198 = mul i64 %t196, 1
  %t199 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t198)
  call void @llvm.memcpy.p0.p0.i64(ptr %t199, ptr %t197, i64 %t198, i1 false)
  %t200 = insertvalue { i64, ptr } undef, i64 %t196, 0
  %t201 = insertvalue { i64, ptr } %t200, ptr %t199, 1
  %t202 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t203 = getelementptr [9 x { i64, ptr }], ptr %l83, i64 0, i64 0
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d142, i32 0, i32 1) }, ptr %t203, !tbaa !37
  %t204 = getelementptr [9 x { i64, ptr }], ptr %l83, i64 0, i64 1
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d143, i32 0, i32 1) }, ptr %t204, !tbaa !37
  %t205 = getelementptr [9 x { i64, ptr }], ptr %l83, i64 0, i64 2
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d144, i32 0, i32 1) }, ptr %t205, !tbaa !37
  %t206 = getelementptr [9 x { i64, ptr }], ptr %l83, i64 0, i64 3
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d145, i32 0, i32 1) }, ptr %t206, !tbaa !37
  %t207 = getelementptr [9 x { i64, ptr }], ptr %l83, i64 0, i64 4
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d146, i32 0, i32 1) }, ptr %t207, !tbaa !37
  %t208 = getelementptr [9 x { i64, ptr }], ptr %l83, i64 0, i64 5
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d147, i32 0, i32 1) }, ptr %t208, !tbaa !37
  %t209 = getelementptr [9 x { i64, ptr }], ptr %l83, i64 0, i64 6
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d148, i32 0, i32 1) }, ptr %t209, !tbaa !37
  %t210 = getelementptr [9 x { i64, ptr }], ptr %l83, i64 0, i64 7
  store { i64, ptr } %t201, ptr %t210, !tbaa !37
  %t212 = getelementptr [9 x { i64, ptr }], ptr %l83, i64 0, i64 8
  store { i64, ptr } %t202, ptr %t212, !tbaa !37
  %t214 = call ptr @__olang_scope_alloc_a(ptr %s10, i64 144, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t214, ptr %l83, i64 144, i1 false)
  store ptr %t214, ptr %l9
  store i64 0, ptr %l10, !tbaa !24
  %t216 = load ptr, ptr %l9
  store i64 9, ptr %l11, !tbaa !24
  br label %bb37
bb37:
  %t219 = load i64, ptr %l10, !tbaa !24
  %t220 = load i64, ptr %l11, !tbaa !24
  %t223 = icmp slt i64 %t219, %t220
  %t225 = xor i1 %t223, true
  br i1 %t225, label %bb38, label %bb39
bb38:
  br label %bb43
bb39:
  br label %bb40
bb40:
  %t227 = load ptr, ptr %l9
  %t228 = load i64, ptr %l10, !tbaa !24
  %t231 = getelementptr [9 x { i64, ptr }], ptr %t227, i64 0, i64 %t228
  %t232 = load { i64, ptr }, ptr %t231, !tbaa !37
  %t236 = extractvalue { i64, ptr } %t232, 1
  %t237 = extractvalue { i64, ptr } %t232, 0
  %t238 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t237)
  call void @olang_textcopy(ptr %t238, ptr %t236, i64 %t237)
  %t239 = insertvalue { i64, ptr } undef, i64 %t237, 0
  %t240 = insertvalue { i64, ptr } %t239, ptr %t238, 1
  %t242 = extractvalue { i64, ptr } %t240, 0
  %t243 = extractvalue { i64, ptr } %t240, 1
  %t244 = mul i64 %t242, 1
  %t245 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t244)
  call void @llvm.memcpy.p0.p0.i64(ptr %t245, ptr %t243, i64 %t244, i1 false)
  %t246 = insertvalue { i64, ptr } undef, i64 %t242, 0
  %t247 = insertvalue { i64, ptr } %t246, ptr %t245, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s3, ptr %s3, ptr %l5, { i64, ptr } %t247)
  br label %bb41
bb41:
  br label %bb42
bb42:
  %t250 = load i64, ptr %l10, !tbaa !24
  %t252 = add i64 %t250, 1
  store i64 %t252, ptr %l10, !tbaa !24
  br label %bb37
bb43:
  call void @__olang_scope_close(ptr %s10)
  %t255 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %s3, ptr %s3, ptr %l5)
  store { i64, ptr } %t255, ptr %l102
  br label %bb44
bb44:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d149, i32 0, i32 1) }, ptr %l103, !tbaa !27
  %t256 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t257 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t258 = call { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %s3, ptr %s3, ptr %s3, ptr %s3, { i64, ptr } %t256, { i64, ptr } %t257, i1 true, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d132, i32 0, i32 1) })
  %t259 = extractvalue { i32, %"std/os:Output" } %t258, 1
  %t260 = extractvalue { i32, %"std/os:Output" } %t258, 0
  store i32 %t260, ptr %l105
  %t261 = icmp ne i32 %t260, 0
  br i1 %t261, label %bb46, label %ok.262
ok.262:
  store %"std/os:Output" %t259, ptr %l104
  br label %bb45
bb45:
  %t263 = load %"std/os:Output", ptr %l104
  store %"std/os:Output" %t263, ptr %l100
  br label %bb48
bb46:
  %t264 = load i32, ptr %l105, !tbaa !23
  %t265 = ashr i32 %t264, 16
  %t267 = icmp eq i32 %t265, 1
  store i1 %t267, ptr %l107, !tbaa !21
  br label %bb47
bb47:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d150, i32 0, i32 1) }, ptr %l108, !tbaa !27
  %t268 = load { i64, ptr }, ptr %l108, !tbaa !27
  store { i64, ptr } %t268, ptr %l109, !tbaa !27
  %t269 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t270 = extractvalue { i64, ptr } %t269, 0
  store i64 %t270, ptr %l110, !tbaa !24
  %t271 = load i64, ptr %l110, !tbaa !24
  %t272 = mul i64 %t271, 1
  %t273 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t272)
  %t274 = insertvalue { i64, ptr } undef, i64 %t271, 0
  %t275 = insertvalue { i64, ptr } %t274, ptr %t273, 1
  store { i64, ptr } %t275, ptr %l111, !tbaa !27
  %t276 = getelementptr { i64, ptr }, ptr %l111, i32 0, i32 1
  %t277 = load ptr, ptr %t276, !tbaa !27
  %t278 = getelementptr { i64, ptr }, ptr %l109, i32 0, i32 1
  %t279 = load ptr, ptr %t278, !tbaa !27
  %t280 = load i64, ptr %l110, !tbaa !24
  %t281 = mul i64 %t280, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t277, ptr %t279, i64 %t281, i1 false)
  %t282 = load { i64, ptr }, ptr %l111, !tbaa !27
  store { i64, ptr } %t282, ptr %l109, !tbaa !27
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t283 = load { i64, ptr }, ptr %l109, !tbaa !27
  store { i64, ptr } %t283, ptr %rv
  br label %ret
bb48:
  %t284 = load %"std/os:Output", ptr %l100
  store %"std/os:Output" %t284, ptr %l13
  %t285 = getelementptr %"std/os:Output", ptr %l13, i32 0, i32 0
  %t286 = load i32, ptr %t285, !tbaa !23
  %t288 = icmp ne i32 %t286, 0
  br i1 %t288, label %bb49, label %bb50
bb49:
  %t290 = getelementptr %"std/os:Output", ptr %l13, i32 0, i32 2
  %t291 = load { i64, ptr }, ptr %t290, !tbaa !27
  %t293 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %s3, { i64, ptr } %t291)
  store { i64, ptr } %t293, ptr %l115
  br label %bb51
bb50:
  br label %bb52
bb51:
  %t294 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d151, i32 0, i32 1) }, 1
  %t295 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d151, i32 0, i32 1) }, 0
  %t296 = load { i64, ptr }, ptr %l115, !tbaa !27
  %t297 = extractvalue { i64, ptr } %t296, 1
  %t298 = extractvalue { i64, ptr } %t296, 0
  %t299 = add i64 %t295, %t298
  %t300 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t299)
  call void @olang_textcopy(ptr %t300, ptr %t294, i64 %t295)
  %t301 = getelementptr i8, ptr %t300, i64 %t295
  call void @olang_textcopy(ptr %t301, ptr %t297, i64 %t298)
  %t302 = insertvalue { i64, ptr } undef, i64 %t299, 0
  %t303 = insertvalue { i64, ptr } %t302, ptr %t300, 1
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t303, ptr %rv
  br label %ret
bb52:
  %t305 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t307 = extractvalue { i64, ptr } %t305, 1
  %t308 = extractvalue { i64, ptr } %t305, 0
  %t309 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d152, i32 0, i32 1) }, 1
  %t310 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d152, i32 0, i32 1) }, 0
  %t311 = add i64 %t308, %t310
  %t312 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t311)
  call void @olang_textcopy(ptr %t312, ptr %t307, i64 %t308)
  %t313 = getelementptr i8, ptr %t312, i64 %t308
  call void @olang_textcopy(ptr %t313, ptr %t309, i64 %t310)
  %t314 = insertvalue { i64, ptr } undef, i64 %t311, 0
  %t315 = insertvalue { i64, ptr } %t314, ptr %t312, 1
  %t317 = extractvalue { i64, ptr } %t315, 0
  %t318 = extractvalue { i64, ptr } %t315, 1
  %t319 = mul i64 %t317, 1
  %t320 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t319)
  call void @llvm.memcpy.p0.p0.i64(ptr %t320, ptr %t318, i64 %t319, i1 false)
  %t321 = insertvalue { i64, ptr } undef, i64 %t317, 0
  %t322 = insertvalue { i64, ptr } %t321, ptr %t320, 1
  %t323 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t326 = call i32 @std_2fos_2eRename(ptr %s3, ptr %s0, { i64, ptr } %t322, { i64, ptr } %t323)
  store i32 %t326, ptr %l121
  %t327 = icmp ne i32 %t326, 0
  br i1 %t327, label %bb54, label %ok.328
ok.328:
  br label %bb53
bb53:
  br label %bb56
bb54:
  %t329 = load i32, ptr %l121, !tbaa !23
  %t330 = ashr i32 %t329, 16
  %t332 = icmp eq i32 %t330, 1
  store i1 %t332, ptr %l123, !tbaa !21
  br label %bb55
bb55:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d153, i32 0, i32 1) }, ptr %l124, !tbaa !27
  %t333 = load { i64, ptr }, ptr %l124, !tbaa !27
  store { i64, ptr } %t333, ptr %l125, !tbaa !27
  %t334 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t335 = extractvalue { i64, ptr } %t334, 0
  store i64 %t335, ptr %l126, !tbaa !24
  %t336 = load i64, ptr %l126, !tbaa !24
  %t337 = mul i64 %t336, 1
  %t338 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t337)
  %t339 = insertvalue { i64, ptr } undef, i64 %t336, 0
  %t340 = insertvalue { i64, ptr } %t339, ptr %t338, 1
  store { i64, ptr } %t340, ptr %l127, !tbaa !27
  %t341 = getelementptr { i64, ptr }, ptr %l127, i32 0, i32 1
  %t342 = load ptr, ptr %t341, !tbaa !27
  %t343 = getelementptr { i64, ptr }, ptr %l125, i32 0, i32 1
  %t344 = load ptr, ptr %t343, !tbaa !27
  %t345 = load i64, ptr %l126, !tbaa !24
  %t346 = mul i64 %t345, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t342, ptr %t344, i64 %t346, i1 false)
  %t347 = load { i64, ptr }, ptr %l127, !tbaa !27
  store { i64, ptr } %t347, ptr %l125, !tbaa !27
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t348 = load { i64, ptr }, ptr %l125, !tbaa !27
  store { i64, ptr } %t348, ptr %rv
  br label %ret
bb56:
  call void @__olang_scope_close(ptr %s3)
  br label %bb57
bb57:
  %t349 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t351 = call { i64, ptr } @compiler_2finterp_2eLoadLibrary(ptr %s0, ptr %v2, { i64, ptr } %t349)
  store { i64, ptr } %t351, ptr %l129
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s0)
  %t352 = load { i64, ptr }, ptr %l129, !tbaa !27
  store { i64, ptr } %t352, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2folang_2echeckOutput(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l5 = alloca i1
  %l6 = alloca ptr
  %l8 = alloca %"compiler/msgs:Msg"
  %l9 = alloca i32
  %l11 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i64
  %l32 = alloca i1
  %l34 = alloca ptr
  %l37 = alloca %"compiler/msgs:Msg"
  %l38 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i32
  store { i64, ptr } %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fos_2eIsDir(ptr %v0, { i64, ptr } %t1)
  store i1 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i1, ptr %l5, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l6, !tbaa !29
  %t6 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eOutputIsDir(ptr %v0, ptr %s1, { i64, ptr } %t6)
  store %"compiler/msgs:Msg" %t8, ptr %l8
  br label %bb4
bb3:
  br label %bb8
bb4:
  %t9 = load ptr, ptr %l6, !tbaa !29
  %t10 = load %"compiler/msgs:Msg", ptr %l8
  %t11 = call i32 @compiler_2folang_2eusage(ptr %v1, ptr %s1, ptr %t9, %"compiler/msgs:Msg" %t10)
  store i32 %t11, ptr %l9
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb6, label %ok.13
ok.13:
  br label %bb5
bb5:
  br label %bb7
bb6:
  %t14 = load i32, ptr %l9, !tbaa !23
  %t15 = lshr i32 %t14, 16
  %t16 = and i32 %t14, 65535
  %t17 = icmp eq i32 %t15, 1
  %t18 = select i1 %t17, i32 1, i32 0
  %t19 = icmp eq i32 %t14, 0
  %t20 = shl i32 %t18, 16
  %t21 = or i32 %t20, %t16
  %t22 = select i1 %t19, i32 0, i32 %t21
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t22, ptr %rv
  br label %ret
bb7:
  call void @__olang_scope_close(ptr %s1)
  br label %bb8
bb8:
  %t24 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t26 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %s0, { i64, ptr } %t24, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d154, i32 0, i32 1) })
  %t27 = extractvalue { i32, i64 } %t26, 1
  %t28 = extractvalue { i32, i64 } %t26, 0
  store i32 %t28, ptr %l14
  %t29 = icmp ne i32 %t28, 0
  br i1 %t29, label %bb10, label %ok.30
ok.30:
  store i64 %t27, ptr %l13
  br label %bb9
bb9:
  %t31 = load i64, ptr %l13, !tbaa !24
  store i64 %t31, ptr %l11, !tbaa !24
  br label %bb12
bb10:
  br label %bb11
bb11:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb12:
  %t32 = load i64, ptr %l11, !tbaa !24
  store i64 %t32, ptr %l2, !tbaa !24
  %t33 = load i64, ptr %l2, !tbaa !24
  %t35 = icmp eq i64 %t33, 0
  br i1 %t35, label %bb13, label %bb14
bb13:
  %t37 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t37, ptr %l18, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 0
  store i64 %t39, ptr %l19, !tbaa !24
  %t40 = icmp sge i64 0, 0
  br i1 %t40, label %bb15, label %bb16
bb14:
  %t42 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t42, ptr %l24, !tbaa !27
  %t43 = load i64, ptr %l2, !tbaa !24
  store i64 %t43, ptr %l25, !tbaa !24
  %t44 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t44, 0
  store i64 %t45, ptr %l26, !tbaa !24
  %t46 = icmp sge i64 0, 0
  br i1 %t46, label %bb21, label %bb22
bb15:
  %t48 = icmp sle i64 0, 1
  br i1 %t48, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_12131eae1fe55f7a_2d06b34e1c9e748e)
  unreachable
bb17:
  %t50 = load i64, ptr %l19, !tbaa !24
  %t51 = icmp sle i64 1, %t50
  br i1 %t51, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_12131eae1fe55f7a_2d06b34e1c9e748e)
  unreachable
bb19:
  %t53 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr i8, ptr %t54, i64 0
  %t56 = sub i64 1, 0
  %t57 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t55, 1
  store { i64, ptr } %t58, ptr %l17, !tbaa !27
  br label %bb27
bb20:
  call void @__olang_check_failed(ptr @olang_loc_12131eae1fe55f7a_2d06b34e1c9e748e)
  unreachable
bb21:
  %t60 = load i64, ptr %l25, !tbaa !24
  %t61 = icmp sle i64 0, %t60
  br i1 %t61, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_12131eae1fe55f7a_2d06b34e1c9e748e)
  unreachable
bb23:
  %t63 = load i64, ptr %l25, !tbaa !24
  %t64 = load i64, ptr %l26, !tbaa !24
  %t65 = icmp sle i64 %t63, %t64
  br i1 %t65, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_12131eae1fe55f7a_2d06b34e1c9e748e)
  unreachable
bb25:
  %t67 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !27
  %t69 = load i64, ptr %l25, !tbaa !24
  %t70 = getelementptr i8, ptr %t68, i64 0
  %t71 = sub i64 %t69, 0
  %t72 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t70, 1
  store { i64, ptr } %t73, ptr %l17, !tbaa !27
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_12131eae1fe55f7a_2d06b34e1c9e748e)
  unreachable
bb27:
  %t75 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t75, ptr %l3, !tbaa !27
  %t76 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t78 = call i1 @std_2fos_2eIsDir(ptr %v0, { i64, ptr } %t76)
  store i1 %t78, ptr %l32
  br label %bb28
bb28:
  %t79 = load i1, ptr %l32, !tbaa !21
  %t80 = xor i1 %t79, true
  br i1 %t80, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s3
  %t82 = load ptr, ptr %l1, !tbaa !29
  store ptr %t82, ptr %l34, !tbaa !29
  %t83 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t84 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t87 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eOutputNoDir(ptr %v0, ptr %v0, ptr %s3, { i64, ptr } %t83, { i64, ptr } %t84)
  store %"compiler/msgs:Msg" %t87, ptr %l37
  br label %bb31
bb30:
  br label %bb35
bb31:
  %t88 = load ptr, ptr %l34, !tbaa !29
  %t89 = load %"compiler/msgs:Msg", ptr %l37
  %t90 = call i32 @compiler_2folang_2eusage(ptr %v1, ptr %s3, ptr %t88, %"compiler/msgs:Msg" %t89)
  store i32 %t90, ptr %l38
  %t91 = icmp ne i32 %t90, 0
  br i1 %t91, label %bb33, label %ok.92
ok.92:
  br label %bb32
bb32:
  br label %bb34
bb33:
  %t93 = load i32, ptr %l38, !tbaa !23
  %t94 = lshr i32 %t93, 16
  %t95 = and i32 %t93, 65535
  %t96 = icmp eq i32 %t94, 1
  %t97 = select i1 %t96, i32 1, i32 0
  %t98 = icmp eq i32 %t93, 0
  %t99 = shl i32 %t97, 16
  %t100 = or i32 %t99, %t95
  %t101 = select i1 %t98, i32 0, i32 %t100
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t101, ptr %rv
  br label %ret
bb34:
  call void @__olang_scope_close(ptr %s3)
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2folang_2echeckReuse(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, i32 %a6, ptr %a7) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l9 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca i1
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca %"compiler/build:Unit"
  %l20 = alloca i64
  %l28 = alloca ptr
  %l30 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l32 = alloca i64
  %l35 = alloca i64
  %l38 = alloca i64
  %l42 = alloca i64
  %l45 = alloca i64
  %l63 = alloca i64
  %l66 = alloca i64
  %l71 = alloca %"compiler/build:Unit"
  %l74 = alloca %"compiler/emit:Object"
  %l77 = alloca i1
  %l79 = alloca i1
  %l82 = alloca %"compiler/emit:Object"
  %l85 = alloca i1
  %l89 = alloca %"compiler/emit:Object"
  %l93 = alloca i32
  %l95 = alloca i1
  %l101 = alloca i64
  %l103 = alloca i64
  %l106 = alloca i32
  %l108 = alloca i1
  %l111 = alloca i64
  %l114 = alloca i32
  %l116 = alloca i1
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 67
  %t5 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eLen_3cI64_2c_20I64_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l20
  br label %bb1
bb1:
  %t6 = load i64, ptr %l20, !tbaa !24
  %t7 = icmp eq i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t21 = call ptr @compiler_2folang_2eemitter(ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %a2, ptr %a3, ptr %a4, ptr %a5, i32 %a6, ptr %a7)
  store ptr %t21, ptr %l28
  br label %bb5
bb5:
  %t22 = load ptr, ptr %l28, !tbaa !29
  %t25 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2ecompiler_2femit_3aEmitter_2eObjects(ptr %v5, ptr %s0, ptr %t22)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %l30
  br label %bb6
bb6:
  %t26 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l30
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t26, ptr %l9
  %t28 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2femit_3aObject_3e_2eLen_3ccompiler_2femit_3aObject_3e(ptr %s0, ptr %l9)
  store i64 %t28, ptr %l32
  br label %bb7
bb7:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr %"compiler/build:Program", ptr %t29, i32 0, i32 0
  %t33 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2eLen_3ccompiler_2fbuild_3aUnit_3e(ptr %v1, ptr %t31)
  store i64 %t33, ptr %l35
  br label %bb8
bb8:
  %t34 = load i64, ptr %l32, !tbaa !24
  %t35 = load i64, ptr %l35, !tbaa !24
  %t36 = icmp ne i64 %t34, %t35
  store i1 %t36, ptr %l10, !tbaa !21
  store i64 0, ptr %l11, !tbaa !24
  %t39 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2femit_3aObject_3e_2eLen_3ccompiler_2femit_3aObject_3e(ptr %s0, ptr %l9)
  store i64 %t39, ptr %l38
  br label %bb9
bb9:
  %t40 = load i64, ptr %l38, !tbaa !24
  store i64 %t40, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t41 = load i64, ptr %l12, !tbaa !24
  %t42 = load i64, ptr %l11, !tbaa !24
  %t45 = icmp sgt i64 %t41, %t42
  br i1 %t45, label %bb10, label %bb11
bb10:
  %t47 = load i64, ptr %l13, !tbaa !24
  %t49 = icmp sgt i64 %t47, 0
  br i1 %t49, label %bb12, label %bb13
bb11:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb15
bb12:
  %t51 = load i64, ptr %l12, !tbaa !24
  %t52 = load i64, ptr %l11, !tbaa !24
  %t55 = sub i64 %t51, %t52
  %t56 = load i64, ptr %l13, !tbaa !24
  %t59 = add i64 %t55, %t56
  %t61 = sub i64 %t59, 1
  %t62 = load i64, ptr %l13, !tbaa !24
  %t65 = sdiv i64 %t61, %t62
  store i64 %t65, ptr %l45, !tbaa !24
  br label %bb14
bb13:
  store i64 0, ptr %l45, !tbaa !24
  br label %bb14
bb14:
  %t67 = load i64, ptr %l45, !tbaa !24
  store i64 %t67, ptr %l42, !tbaa !24
  br label %bb15
bb15:
  %t68 = load i64, ptr %l42, !tbaa !24
  store i64 %t68, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb16
bb16:
  %t69 = load i64, ptr %l15, !tbaa !24
  %t70 = load i64, ptr %l14, !tbaa !24
  %t73 = icmp slt i64 %t69, %t70
  %t75 = xor i1 %t73, true
  br i1 %t75, label %bb17, label %bb18
bb17:
  br label %bb41
bb18:
  br label %bb19
bb19:
  %t77 = load i64, ptr %l11, !tbaa !24
  %t78 = load i64, ptr %l15, !tbaa !24
  %t79 = load i64, ptr %l13, !tbaa !24
  %t82 = mul i64 %t78, %t79
  %t85 = add i64 %t77, %t82
  store i64 %t85, ptr %l16, !tbaa !24
  %t87 = load i64, ptr %l16, !tbaa !24
  store i64 %t87, ptr %l63, !tbaa !24
  %t88 = load ptr, ptr %l1, !tbaa !29
  %t90 = getelementptr %"compiler/build:Program", ptr %t88, i32 0, i32 0
  %t92 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2eLen_3ccompiler_2fbuild_3aUnit_3e(ptr %v1, ptr %t90)
  store i64 %t92, ptr %l66
  br label %bb20
bb20:
  %t93 = load i64, ptr %l63, !tbaa !24
  %t94 = load i64, ptr %l66, !tbaa !24
  %t95 = icmp sge i64 %t93, %t94
  br i1 %t95, label %bb21, label %bb22
bb21:
  br label %bb41
bb22:
  br label %bb23
bb23:
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t99 = getelementptr %"compiler/build:Program", ptr %t97, i32 0, i32 0
  %t100 = load i64, ptr %l16, !tbaa !24
  %t103 = call %"compiler/build:Unit" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2eAt_3ccompiler_2fbuild_3aUnit_3e(ptr %v1, ptr %v1, ptr %t99, i64 %t100)
  store %"compiler/build:Unit" %t103, ptr %l71
  br label %bb24
bb24:
  %t104 = load %"compiler/build:Unit", ptr %l71
  store %"compiler/build:Unit" %t104, ptr %l17
  %t105 = load i64, ptr %l16, !tbaa !24
  %t108 = call %"compiler/emit:Object" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2femit_3aObject_3e_2eAt_3ccompiler_2femit_3aObject_3e(ptr %s0, ptr %s0, ptr %l9, i64 %t105)
  store %"compiler/emit:Object" %t108, ptr %l74
  br label %bb25
bb25:
  %t109 = getelementptr %"compiler/emit:Object", ptr %l74, i32 0, i32 0
  %t110 = load { i64, ptr }, ptr %t109, !tbaa !27
  %t111 = getelementptr %"compiler/build:Unit", ptr %l17, i32 0, i32 0
  %t112 = load { i64, ptr }, ptr %t111, !tbaa !27
  %t115 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %v1, { i64, ptr } %t110, { i64, ptr } %t112)
  store i1 %t115, ptr %l77
  br label %bb26
bb26:
  %t116 = load i1, ptr %l77, !tbaa !21
  %t117 = xor i1 %t116, true
  br i1 %t117, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l79, !tbaa !21
  br label %bb31
bb28:
  %t119 = load i64, ptr %l16, !tbaa !24
  %t122 = call %"compiler/emit:Object" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2femit_3aObject_3e_2eAt_3ccompiler_2femit_3aObject_3e(ptr %s0, ptr %s0, ptr %l9, i64 %t119)
  store %"compiler/emit:Object" %t122, ptr %l82
  br label %bb29
bb29:
  %t123 = getelementptr %"compiler/emit:Object", ptr %l82, i32 0, i32 2
  %t124 = load { i64, ptr }, ptr %t123, !tbaa !27
  %t125 = getelementptr %"compiler/build:Unit", ptr %l17, i32 0, i32 2
  %t126 = load { i64, ptr }, ptr %t125, !tbaa !27
  %t129 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %v1, { i64, ptr } %t124, { i64, ptr } %t126)
  store i1 %t129, ptr %l85
  br label %bb30
bb30:
  %t130 = load i1, ptr %l85, !tbaa !21
  %t131 = xor i1 %t130, true
  store i1 %t131, ptr %l79, !tbaa !21
  br label %bb31
bb31:
  %t133 = load i1, ptr %l79, !tbaa !21
  br i1 %t133, label %bb32, label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s5
  %t134 = load i64, ptr %l16, !tbaa !24
  %t137 = call %"compiler/emit:Object" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2femit_3aObject_3e_2eAt_3ccompiler_2femit_3aObject_3e(ptr %s0, ptr %s0, ptr %l9, i64 %t134)
  store %"compiler/emit:Object" %t137, ptr %l89
  br label %bb34
bb33:
  br label %bb39
bb34:
  %t138 = getelementptr %"compiler/emit:Object", ptr %l89, i32 0, i32 0
  %t139 = load { i64, ptr }, ptr %t138, !tbaa !27
  %t140 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d155, i32 0, i32 1) }, 1
  %t141 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d155, i32 0, i32 1) }, 0
  %t143 = extractvalue { i64, ptr } %t139, 1
  %t144 = extractvalue { i64, ptr } %t139, 0
  %t145 = add i64 %t141, %t144
  %t146 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d156, i32 0, i32 1) }, 1
  %t147 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d156, i32 0, i32 1) }, 0
  %t148 = add i64 %t145, %t147
  %t149 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t148)
  call void @olang_textcopy(ptr %t149, ptr %t140, i64 %t141)
  %t150 = getelementptr i8, ptr %t149, i64 %t141
  call void @olang_textcopy(ptr %t150, ptr %t143, i64 %t144)
  %t151 = getelementptr i8, ptr %t150, i64 %t144
  call void @olang_textcopy(ptr %t151, ptr %t146, i64 %t147)
  %t152 = insertvalue { i64, ptr } undef, i64 %t148, 0
  %t153 = insertvalue { i64, ptr } %t152, ptr %t149, 1
  %t155 = extractvalue { i64, ptr } %t153, 0
  %t156 = extractvalue { i64, ptr } %t153, 1
  %t157 = mul i64 %t155, 1
  %t158 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t157)
  call void @llvm.memcpy.p0.p0.i64(ptr %t158, ptr %t156, i64 %t157, i1 false)
  %t159 = insertvalue { i64, ptr } undef, i64 %t155, 0
  %t160 = insertvalue { i64, ptr } %t159, ptr %t158, 1
  %t162 = call i32 @std_2fio_2ePrintErr(ptr %s5, { i64, ptr } %t160)
  store i32 %t162, ptr %l93
  %t163 = icmp ne i32 %t162, 0
  br i1 %t163, label %bb36, label %ok.164
ok.164:
  br label %bb35
bb35:
  br label %bb38
bb36:
  %t165 = load i32, ptr %l93, !tbaa !23
  %t166 = ashr i32 %t165, 16
  %t168 = icmp eq i32 %t166, 1
  store i1 %t168, ptr %l95, !tbaa !21
  br label %bb37
bb37:
  call void @__olang_ert_req_clear()
  br label %bb38
bb38:
  store i1 true, ptr %l10, !tbaa !21
  call void @__olang_scope_close(ptr %s5)
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t169 = load i64, ptr %l15, !tbaa !24
  %t171 = add i64 %t169, 1
  store i64 %t171, ptr %l15, !tbaa !24
  br label %bb16
bb41:
  %t173 = load i1, ptr %l10, !tbaa !21
  br i1 %t173, label %bb42, label %bb43
bb42:
  store %olang.scope zeroinitializer, ptr %s9
  %t175 = load ptr, ptr %l1, !tbaa !29
  %t177 = getelementptr %"compiler/build:Program", ptr %t175, i32 0, i32 0
  %t179 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2eLen_3ccompiler_2fbuild_3aUnit_3e(ptr %v1, ptr %t177)
  store i64 %t179, ptr %l101
  br label %bb44
bb43:
  br label %bb51
bb44:
  %t181 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2femit_3aObject_3e_2eLen_3ccompiler_2femit_3aObject_3e(ptr %s0, ptr %l9)
  store i64 %t181, ptr %l103
  br label %bb45
bb45:
  %t182 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d157, i32 0, i32 1) }, 1
  %t183 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d157, i32 0, i32 1) }, 0
  %t184 = load i64, ptr %l101, !tbaa !24
  %t185 = call i64 @__olang_fmt_i64(ptr null, i64 %t184)
  %t186 = add i64 %t183, %t185
  %t187 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d158, i32 0, i32 1) }, 1
  %t188 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d158, i32 0, i32 1) }, 0
  %t189 = add i64 %t186, %t188
  %t190 = load i64, ptr %l103, !tbaa !24
  %t191 = call i64 @__olang_fmt_i64(ptr null, i64 %t190)
  %t192 = add i64 %t189, %t191
  %t193 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d159, i32 0, i32 1) }, 1
  %t194 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d159, i32 0, i32 1) }, 0
  %t195 = add i64 %t192, %t194
  %t196 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t195)
  call void @olang_textcopy(ptr %t196, ptr %t182, i64 %t183)
  %t197 = getelementptr i8, ptr %t196, i64 %t183
  %t198 = call i64 @__olang_fmt_i64(ptr %t197, i64 %t184)
  %t199 = getelementptr i8, ptr %t197, i64 %t185
  call void @olang_textcopy(ptr %t199, ptr %t187, i64 %t188)
  %t200 = getelementptr i8, ptr %t199, i64 %t188
  %t201 = call i64 @__olang_fmt_i64(ptr %t200, i64 %t190)
  %t202 = getelementptr i8, ptr %t200, i64 %t191
  call void @olang_textcopy(ptr %t202, ptr %t193, i64 %t194)
  %t203 = insertvalue { i64, ptr } undef, i64 %t195, 0
  %t204 = insertvalue { i64, ptr } %t203, ptr %t196, 1
  %t206 = extractvalue { i64, ptr } %t204, 0
  %t207 = extractvalue { i64, ptr } %t204, 1
  %t208 = mul i64 %t206, 1
  %t209 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t208)
  call void @llvm.memcpy.p0.p0.i64(ptr %t209, ptr %t207, i64 %t208, i1 false)
  %t210 = insertvalue { i64, ptr } undef, i64 %t206, 0
  %t211 = insertvalue { i64, ptr } %t210, ptr %t209, 1
  %t213 = call i32 @std_2fio_2ePrintErr(ptr %s9, { i64, ptr } %t211)
  store i32 %t213, ptr %l106
  %t214 = icmp ne i32 %t213, 0
  br i1 %t214, label %bb47, label %ok.215
ok.215:
  br label %bb46
bb46:
  br label %bb49
bb47:
  %t216 = load i32, ptr %l106, !tbaa !23
  %t217 = ashr i32 %t216, 16
  %t219 = icmp eq i32 %t217, 1
  store i1 %t219, ptr %l108, !tbaa !21
  br label %bb48
bb48:
  call void @__olang_ert_req_clear()
  br label %bb49
bb49:
  call void @std_2fos_2eExit(i32 3)
  unreachable
bb50:
  call void @__olang_check_failed(ptr @olang_loc_dd8573ae343ff812_8decdc106ea08ebe)
  unreachable
bb51:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t222 = getelementptr %"compiler/emit:Emitter", ptr %t220, i32 0, i32 67
  %t224 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eLen_3cI64_2c_20I64_3e(ptr %v0, ptr %t222)
  store i64 %t224, ptr %l111
  br label %bb52
bb52:
  %t225 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d160, i32 0, i32 1) }, 1
  %t226 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d160, i32 0, i32 1) }, 0
  %t227 = load i64, ptr %l111, !tbaa !24
  %t228 = call i64 @__olang_fmt_i64(ptr null, i64 %t227)
  %t229 = add i64 %t226, %t228
  %t230 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d161, i32 0, i32 1) }, 1
  %t231 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d161, i32 0, i32 1) }, 0
  %t232 = add i64 %t229, %t231
  %t233 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t232)
  call void @olang_textcopy(ptr %t233, ptr %t225, i64 %t226)
  %t234 = getelementptr i8, ptr %t233, i64 %t226
  %t235 = call i64 @__olang_fmt_i64(ptr %t234, i64 %t227)
  %t236 = getelementptr i8, ptr %t234, i64 %t228
  call void @olang_textcopy(ptr %t236, ptr %t230, i64 %t231)
  %t237 = insertvalue { i64, ptr } undef, i64 %t232, 0
  %t238 = insertvalue { i64, ptr } %t237, ptr %t233, 1
  %t240 = extractvalue { i64, ptr } %t238, 0
  %t241 = extractvalue { i64, ptr } %t238, 1
  %t242 = mul i64 %t240, 1
  %t243 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t242)
  call void @llvm.memcpy.p0.p0.i64(ptr %t243, ptr %t241, i64 %t242, i1 false)
  %t244 = insertvalue { i64, ptr } undef, i64 %t240, 0
  %t245 = insertvalue { i64, ptr } %t244, ptr %t243, 1
  %t247 = call i32 @std_2fio_2ePrintErr(ptr %s0, { i64, ptr } %t245)
  store i32 %t247, ptr %l114
  %t248 = icmp ne i32 %t247, 0
  br i1 %t248, label %bb54, label %ok.249
ok.249:
  br label %bb53
bb53:
  br label %bb56
bb54:
  %t250 = load i32, ptr %l114, !tbaa !23
  %t251 = ashr i32 %t250, 16
  %t253 = icmp eq i32 %t251, 1
  store i1 %t253, ptr %l116, !tbaa !21
  br label %bb55
bb55:
  call void @__olang_ert_req_clear()
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2folang_2ecompiler_2folang_3aPasses_2eAnalyze(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i32 %a2, ptr %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca %"compiler/check:Gap"
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l19 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l20 = alloca ptr
  %l21 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca i64
  %l28 = alloca %"compiler/lower:Gap"
  %l29 = alloca %"compiler/target:Target"
  %l30 = alloca i1
  %l31 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l32 = alloca ptr
  %l33 = alloca i64
  %l34 = alloca %"compiler/emit:Object"
  %l35 = alloca %"compiler/emit:Reused"
  %l36 = alloca { i64, ptr }
  %l37 = alloca ptr
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca ptr
  %l43 = alloca { i64, ptr }
  %l44 = alloca i32
  %l46 = alloca ptr
  %l47 = alloca ptr
  %l48 = alloca i64
  %l49 = alloca ptr
  %lp51 = alloca ptr
  %l52 = alloca ptr
  %l53 = alloca i64
  %l57 = alloca ptr
  %l62 = alloca ptr
  %l63 = alloca i32
  %l67 = alloca %"compiler/check:Checker"
  %l71 = alloca i1
  %l76 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l79 = alloca i64
  %l83 = alloca i64
  %l86 = alloca i64
  %l87 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l91 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l94 = alloca i64
  %l97 = alloca i1
  %l101 = alloca ptr
  %l105 = alloca i64
  %l109 = alloca i64
  %l111 = alloca i64
  %l116 = alloca %"compiler/check:Gap"
  %l121 = alloca { i64, ptr }
  %l132 = alloca %"compiler/lower:Lowerer"
  %l137 = alloca ptr
  %l138 = alloca ptr
  %l141 = alloca i64
  %l144 = alloca ptr
  %l153 = alloca i1
  %l155 = alloca i64
  %l158 = alloca { i64, ptr }
  %l160 = alloca i32
  %l162 = alloca i1
  %l163 = alloca { i64, ptr }
  %l164 = alloca { i64, ptr }
  %l165 = alloca i32
  %l166 = alloca { i64, ptr }
  %l169 = alloca i1
  %l172 = alloca { i64, ptr }
  %l174 = alloca i32
  %l176 = alloca i1
  %l178 = alloca i64
  %l187 = alloca ptr
  %l197 = alloca { i64, ptr }
  %l198 = alloca ptr
  %l202 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l204 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l213 = alloca ptr
  %l215 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l218 = alloca i1
  %l223 = alloca ptr
  %l224 = alloca { i64, [3 x i64] }
  %l227 = alloca %"compiler/msgs:Msg"
  %l228 = alloca i64
  %l232 = alloca ptr
  %l233 = alloca { i64, [3 x i64] }
  %l238 = alloca %"compiler/msgs:Msg"
  %l239 = alloca i64
  %l247 = alloca i64
  %l249 = alloca i64
  %l254 = alloca { i64, ptr }
  %l264 = alloca i64
  %l266 = alloca i1
  %l269 = alloca i64
  %l273 = alloca i64
  %l275 = alloca i64
  %l280 = alloca { i64, ptr }
  %l288 = alloca i64
  %l290 = alloca i64
  %l295 = alloca %"compiler/lower:Gap"
  %l300 = alloca { i64, ptr }
  %l308 = alloca i64
  %l313 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l315 = alloca i64
  %l317 = alloca i64
  %l322 = alloca %"compiler/emit:Object"
  %l328 = alloca %"compiler/emit:Reused"
  %l329 = alloca ptr
  %l333 = alloca ptr
  %l336 = alloca { i64, ptr }
  %l339 = alloca { i64, ptr }
  %l341 = alloca i64
  %l343 = alloca i64
  %l349 = alloca { i64, ptr }
  %l350 = alloca { i64, ptr }
  %l355 = alloca { i64, ptr }
  %l356 = alloca i32
  %l358 = alloca i1
  %l365 = alloca { i64, ptr }
  %l366 = alloca i1
  %l370 = alloca { i64, ptr }
  %l374 = alloca { i64, ptr }
  %l377 = alloca i1
  %l378 = alloca i32
  %l382 = alloca %"compiler/build:Unit"
  %l384 = alloca ptr
  %l387 = alloca { i64, ptr }
  %l400 = alloca { i64, ptr }
  %l401 = alloca i1
  %l405 = alloca { i64, ptr }
  %l408 = alloca i32
  %l429 = alloca %"compiler/build:Unit"
  %l434 = alloca i1
  %l437 = alloca i1
  %l440 = alloca ptr
  %l442 = alloca { i64, ptr }
  %l467 = alloca i64
  %l469 = alloca i64
  %l474 = alloca ptr
  %l477 = alloca i1
  %l478 = alloca { i64, ptr }
  %l481 = alloca { i64, ptr }
  %l482 = alloca i32
  %l484 = alloca i1
  %l494 = alloca { i64, ptr }
  %l495 = alloca i64
  %l496 = alloca { i64, ptr }
  %l498 = alloca i1
  %l505 = alloca ptr
  %l512 = alloca %"compiler/build:Unit"
  %l515 = alloca { i64, ptr }
  %l516 = alloca { i64, ptr }
  %l517 = alloca i32
  %l518 = alloca { i64, ptr }
  %l521 = alloca i1
  %l531 = alloca ptr
  %l533 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l535 = alloca i64
  %l541 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l543 = alloca i64
  %l545 = alloca i64
  %l550 = alloca { i64, ptr }
  %l558 = alloca ptr
  %l559 = alloca ptr
  %l561 = alloca { i64, ptr }
  %l564 = alloca { i64, ptr }
  %l566 = alloca ptr
  %l567 = alloca { i64, ptr }
  %l575 = alloca { i64, ptr }
  %l576 = alloca i32
  %l578 = alloca i1
  %l583 = alloca ptr
  %l586 = alloca { i64, ptr }
  %l589 = alloca ptr
  %l590 = alloca { i64, ptr }
  %l598 = alloca { i64, ptr }
  %l599 = alloca i32
  %l601 = alloca i1
  %l606 = alloca ptr
  %l609 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s37 = alloca %olang.scope
  %s38 = alloca %olang.scope
  %s40 = alloca %olang.scope
  %s42 = alloca %olang.scope
  %s62 = alloca %olang.scope
  %s64 = alloca %olang.scope
  %s66 = alloca %olang.scope
  %s73 = alloca %olang.scope
  %rv = alloca i32
  %t33 = alloca %"compiler/check:Checker", align 8
  %t397 = alloca { i64, [3 x i64] }, align 8
  %t418 = alloca { i64, [3 x i64] }, align 8
  store { i64, ptr } %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l2
  %t3 = trunc i64 2 to i32
  %t4 = icmp eq i32 %t1, %t3
  store i1 %t4, ptr %l6, !tbaa !21
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d162, i32 0, i32 1) })
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t8 = load ptr, ptr %l3, !tbaa !29
  %t9 = load ptr, ptr %l5, !tbaa !29
  %t14 = call { i32, ptr } @compiler_2folang_2ecompiler_2folang_3aPasses_2eload(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %t7, ptr %t8, ptr %t9)
  %t15 = extractvalue { i32, ptr } %t14, 1
  %t16 = extractvalue { i32, ptr } %t14, 0
  store i32 %t16, ptr %l63
  %t17 = icmp ne i32 %t16, 0
  br i1 %t17, label %bb3, label %ok.18
ok.18:
  store ptr %t15, ptr %l62
  br label %bb2
bb2:
  %t19 = load ptr, ptr %l62, !tbaa !29
  store ptr %t19, ptr %l57, !tbaa !29
  br label %bb4
bb3:
  %t20 = load i32, ptr %l63, !tbaa !23
  %t21 = lshr i32 %t20, 16
  %t22 = and i32 %t20, 65535
  %t23 = icmp eq i32 %t21, 1
  %t24 = select i1 %t23, i32 1, i32 0
  %t25 = icmp eq i32 %t20, 0
  %t26 = shl i32 %t24, 16
  %t27 = or i32 %t26, %t22
  %t28 = select i1 %t25, i32 0, i32 %t27
  call void @__olang_scope_close(ptr %s0)
  store i32 %t28, ptr %rv
  br label %ret
bb4:
  %t30 = load ptr, ptr %l57, !tbaa !29
  store ptr %t30, ptr %l7, !tbaa !29
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d163, i32 0, i32 1) })
  br label %bb5
bb5:
  %t31 = load ptr, ptr %l7, !tbaa !29
  %t32 = load i1, ptr %l6, !tbaa !21
  call void @compiler_2finterp_2eAnalyze(ptr %t33, ptr %v2, ptr %v2, ptr %t31, i1 %t32)
  call void @llvm.memmove.p0.p0.i64(ptr %l67, ptr %t33, i64 888, i1 false)
  br label %bb6
bb6:
  %t36 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 888, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t36, ptr %l67, i64 888, i1 false)
  store ptr %t36, ptr %l8, !tbaa !29
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d164, i32 0, i32 1) })
  br label %bb7
bb7:
  %t38 = load i32, ptr %l2
  %t40 = trunc i64 1 to i32
  %t41 = icmp eq i32 %t38, %t40
  br i1 %t41, label %bb8, label %bb9
bb8:
  %t43 = load ptr, ptr %l3, !tbaa !29
  %t45 = getelementptr %"compiler/build:Config", ptr %t43, i32 0, i32 9
  %t46 = load i1, ptr %t45, !tbaa !21
  %t48 = xor i1 %t46, true
  store i1 %t48, ptr %l71, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l71, !tbaa !21
  br label %bb10
bb10:
  %t50 = load i1, ptr %l71, !tbaa !21
  br i1 %t50, label %bb11, label %bb12
bb11:
  %t51 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eCheckMain(ptr %v2, ptr %t51)
  br label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb14
bb14:
  %t53 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t53, ptr %l76
  br label %bb15
bb15:
  %t54 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l76
  %t55 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t54, ptr %t55
  store ptr %t55, ptr %l9, !tbaa !29
  %t57 = load ptr, ptr %l5, !tbaa !29
  %t59 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v2, ptr %t57)
  store i64 %t59, ptr %l79
  br label %bb16
bb16:
  %t60 = load i64, ptr %l79, !tbaa !24
  %t61 = icmp eq i64 %t60, 0
  store i1 %t61, ptr %l10, !tbaa !21
  %t63 = load i1, ptr %l10, !tbaa !21
  br i1 %t63, label %bb17, label %bb18
bb17:
  %t65 = load ptr, ptr %l8, !tbaa !29
  %t67 = call i64 @compiler_2finterp_2eDecideValues(ptr %v2, ptr %t65)
  store i64 %t67, ptr %l83
  br label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb20
bb20:
  %t68 = load ptr, ptr %l8, !tbaa !29
  %t69 = load ptr, ptr %l9, !tbaa !29
  %t72 = call i64 @compiler_2finterp_2eDecideAsserts(ptr %v2, ptr %v2, ptr %t68, ptr %t69)
  store i64 %t72, ptr %l86
  br label %bb21
bb21:
  %t73 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2ector(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t73, ptr %l87
  br label %bb22
bb22:
  %t74 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l87
  %t75 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t74, ptr %t75
  store ptr %t75, ptr %l11, !tbaa !29
  %t77 = load i1, ptr %l10, !tbaa !21
  br i1 %t77, label %bb23, label %bb24
bb23:
  %t79 = load ptr, ptr %l8, !tbaa !29
  %t81 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2finterp_2eBake(ptr %v2, ptr %v2, ptr %t79)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t81, ptr %l91
  br label %bb25
bb24:
  br label %bb26
bb25:
  %t82 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l91
  %t83 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t82, ptr %t83
  store ptr %t83, ptr %l11, !tbaa !29
  br label %bb26
bb26:
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d165, i32 0, i32 1) })
  br label %bb27
bb27:
  %t85 = load ptr, ptr %l5, !tbaa !29
  %t87 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v2, ptr %t85)
  store i64 %t87, ptr %l94
  br label %bb28
bb28:
  %t88 = load i64, ptr %l94, !tbaa !24
  %t89 = icmp sgt i64 %t88, 0
  br i1 %t89, label %bb29, label %bb30
bb29:
  %t91 = load ptr, ptr %l5, !tbaa !29
  %t93 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHasFatal(ptr %v2, ptr %t91)
  store i1 %t93, ptr %l97
  br label %bb31
bb30:
  br label %bb36
bb31:
  %t94 = load i1, ptr %l97, !tbaa !21
  %t95 = xor i1 %t94, true
  br i1 %t95, label %bb32, label %bb33
bb32:
  %t97 = load ptr, ptr %l8, !tbaa !29
  %t98 = load ptr, ptr %l3, !tbaa !29
  %t101 = call ptr @compiler_2folang_2eplacement(ptr %v2, ptr %v2, ptr %t97, ptr %t98, i64 -1, i1 false)
  store ptr %t101, ptr %l101
  br label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb36:
  %t103 = load ptr, ptr %l8, !tbaa !29
  %t105 = getelementptr %"compiler/check:Checker", ptr %t103, i32 0, i32 13
  %t107 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aGap_3e_2eLen_3ccompiler_2fcheck_3aGap_3e(ptr %v2, ptr %t105)
  store i64 %t107, ptr %l105
  br label %bb37
bb37:
  %t108 = load i64, ptr %l105, !tbaa !24
  %t109 = icmp sgt i64 %t108, 0
  br i1 %t109, label %bb38, label %bb39
bb38:
  %t111 = load ptr, ptr %l8, !tbaa !29
  %t113 = getelementptr %"compiler/check:Checker", ptr %t111, i32 0, i32 13
  store ptr %t113, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  br label %bb40
bb39:
  br label %bb50
bb40:
  store %olang.scope zeroinitializer, ptr %s8
  %t115 = load i64, ptr %l13, !tbaa !24
  store i64 %t115, ptr %l109, !tbaa !24
  %t116 = load ptr, ptr %l12, !tbaa !29
  %t118 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aGap_3e_2eLen_3ccompiler_2fcheck_3aGap_3e(ptr %v2, ptr %t116)
  store i64 %t118, ptr %l111
  br label %bb41
bb41:
  %t119 = load i64, ptr %l109, !tbaa !24
  %t120 = load i64, ptr %l111, !tbaa !24
  %t121 = icmp slt i64 %t119, %t120
  %t123 = xor i1 %t121, true
  br i1 %t123, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s8)
  br label %bb49
bb43:
  br label %bb44
bb44:
  %t125 = load ptr, ptr %l12, !tbaa !29
  %t126 = load i64, ptr %l13, !tbaa !24
  %t129 = call %"compiler/check:Gap" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aGap_3e_2eAt_3ccompiler_2fcheck_3aGap_3e(ptr %v2, ptr %v2, ptr %t125, i64 %t126)
  store %"compiler/check:Gap" %t129, ptr %l116
  br label %bb45
bb45:
  %t130 = load %"compiler/check:Gap", ptr %l116
  store %"compiler/check:Gap" %t130, ptr %l14
  %t131 = load ptr, ptr %l5, !tbaa !29
  %t132 = getelementptr %"compiler/check:Gap", ptr %l14, i32 0, i32 0
  %t133 = load i64, ptr %t132, !tbaa !24
  %t134 = getelementptr %"compiler/check:Gap", ptr %l14, i32 0, i32 1
  %t135 = getelementptr %"compiler/source:Span", ptr %t134, i32 0, i32 0
  %t136 = load i32, ptr %t135, !tbaa !23
  %t138 = sext i32 %t136 to i64
  %t142 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v2, ptr %s8, ptr %t131, i64 %t133, i64 %t138)
  store { i64, ptr } %t142, ptr %l121
  br label %bb46
bb46:
  %t143 = getelementptr %"compiler/check:Gap", ptr %l14, i32 0, i32 2
  %t144 = load { i64, ptr }, ptr %t143, !tbaa !27
  %t145 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t146 = extractvalue { i64, ptr } %t145, 1
  %t147 = extractvalue { i64, ptr } %t145, 0
  %t148 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d166, i32 0, i32 1) }, 1
  %t149 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d166, i32 0, i32 1) }, 0
  %t150 = add i64 %t147, %t149
  %t152 = extractvalue { i64, ptr } %t144, 1
  %t153 = extractvalue { i64, ptr } %t144, 0
  %t154 = add i64 %t150, %t153
  %t155 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d167, i32 0, i32 1) }, 1
  %t156 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d167, i32 0, i32 1) }, 0
  %t157 = add i64 %t154, %t156
  %t158 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t157)
  call void @olang_textcopy(ptr %t158, ptr %t146, i64 %t147)
  %t159 = getelementptr i8, ptr %t158, i64 %t147
  call void @olang_textcopy(ptr %t159, ptr %t148, i64 %t149)
  %t160 = getelementptr i8, ptr %t159, i64 %t149
  call void @olang_textcopy(ptr %t160, ptr %t152, i64 %t153)
  %t161 = getelementptr i8, ptr %t160, i64 %t153
  call void @olang_textcopy(ptr %t161, ptr %t155, i64 %t156)
  %t162 = insertvalue { i64, ptr } undef, i64 %t157, 0
  %t163 = insertvalue { i64, ptr } %t162, ptr %t158, 1
  %t165 = extractvalue { i64, ptr } %t163, 0
  %t166 = extractvalue { i64, ptr } %t163, 1
  %t167 = mul i64 %t165, 1
  %t168 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t167)
  call void @llvm.memcpy.p0.p0.i64(ptr %t168, ptr %t166, i64 %t167, i1 false)
  %t169 = insertvalue { i64, ptr } undef, i64 %t165, 0
  %t170 = insertvalue { i64, ptr } %t169, ptr %t168, 1
  call void @compiler_2fbuild_2eUnbuildable(ptr %s8, { i64, ptr } %t170)
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s8)
  br label %bb48
bb48:
  %t172 = load i64, ptr %l13, !tbaa !24
  %t174 = add i64 %t172, 1
  store i64 %t174, ptr %l13, !tbaa !24
  br label %bb40
bb49:
  call void @__olang_scope_close(ptr %s0)
  store i32 65537, ptr %rv
  br label %ret
bb50:
  %t177 = load ptr, ptr %l8, !tbaa !29
  %t179 = getelementptr %"compiler/check:Checker", ptr %t177, i32 0, i32 1
  %t180 = load ptr, ptr %t179, !tbaa !29
  %t181 = load ptr, ptr %l8, !tbaa !29
  %t183 = getelementptr %"compiler/check:Checker", ptr %t181, i32 0, i32 12
  %t184 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t183
  %t187 = call %"compiler/lower:Lowerer" @compiler_2flower_3aLowerer_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %t180, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t184)
  store %"compiler/lower:Lowerer" %t187, ptr %l132
  br label %bb51
bb51:
  %t188 = load %"compiler/lower:Lowerer", ptr %l132
  %t189 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 120, i64 8)
  store %"compiler/lower:Lowerer" %t188, ptr %t189
  store ptr %t189, ptr %l15, !tbaa !29
  %t191 = load ptr, ptr %l15, !tbaa !29
  %t192 = load ptr, ptr %l9, !tbaa !29
  %t194 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t192
  %t197 = getelementptr %"compiler/lower:Lowerer", ptr %t191, i32 0, i32 7
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t194, ptr %t197
  %t198 = load ptr, ptr %l8, !tbaa !29
  store ptr %t198, ptr %l137, !tbaa !29
  %t199 = load ptr, ptr %l3, !tbaa !29
  store ptr %t199, ptr %l138, !tbaa !29
  %t200 = load i32, ptr %l2
  %t202 = trunc i64 0 to i32
  %t203 = icmp eq i32 %t200, %t202
  br i1 %t203, label %bb52, label %bb53
bb52:
  store i64 -1, ptr %l141, !tbaa !24
  br label %bb54
bb53:
  %t205 = load ptr, ptr %l7, !tbaa !29
  %t207 = getelementptr %"compiler/load:Loader", ptr %t205, i32 0, i32 7
  %t208 = load i64, ptr %t207, !tbaa !24
  store i64 %t208, ptr %l141, !tbaa !24
  br label %bb54
bb54:
  %t210 = load ptr, ptr %l137, !tbaa !29
  %t211 = load ptr, ptr %l138, !tbaa !29
  %t212 = load i64, ptr %l141, !tbaa !24
  %t213 = call ptr @compiler_2folang_2eplacement(ptr %v2, ptr %v2, ptr %t210, ptr %t211, i64 %t212, i1 true)
  store ptr %t213, ptr %l144
  br label %bb55
bb55:
  %t214 = load ptr, ptr %l144, !tbaa !29
  store ptr %t214, ptr %l16, !tbaa !29
  %t215 = load ptr, ptr %l15, !tbaa !29
  %t216 = load ptr, ptr %l16, !tbaa !29
  %t218 = getelementptr %"compiler/free:Free", ptr %t216, i32 0, i32 3
  %t219 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t218
  %t222 = getelementptr %"compiler/lower:Lowerer", ptr %t215, i32 0, i32 2
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t219, ptr %t222
  %t223 = load ptr, ptr %l15, !tbaa !29
  %t224 = load ptr, ptr %l16, !tbaa !29
  %t228 = getelementptr %"compiler/lower:Lowerer", ptr %t223, i32 0, i32 3
  store ptr %t224, ptr %t228, !tbaa !29
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d168, i32 0, i32 1) })
  br label %bb56
bb56:
  %t229 = load ptr, ptr %l3, !tbaa !29
  %t231 = getelementptr %"compiler/build:Config", ptr %t229, i32 0, i32 8
  %t232 = load i1, ptr %t231, !tbaa !21
  br i1 %t232, label %bb57, label %bb58
bb57:
  %t234 = load ptr, ptr %l5, !tbaa !29
  %t236 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v2, ptr %t234)
  store i64 %t236, ptr %l155
  br label %bb59
bb58:
  store i1 false, ptr %l153, !tbaa !21
  br label %bb60
bb59:
  %t237 = load i64, ptr %l155, !tbaa !24
  %t238 = icmp eq i64 %t237, 0
  store i1 %t238, ptr %l153, !tbaa !21
  br label %bb60
bb60:
  %t240 = load i1, ptr %l153, !tbaa !21
  br i1 %t240, label %bb61, label %bb62
bb61:
  store %olang.scope zeroinitializer, ptr %s11
  %t241 = load ptr, ptr %l16, !tbaa !29
  %t243 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2eReport(ptr %v2, ptr %s11, ptr %t241)
  store { i64, ptr } %t243, ptr %l158
  br label %bb63
bb62:
  br label %bb68
bb63:
  %t244 = load { i64, ptr }, ptr %l158, !tbaa !27
  %t245 = extractvalue { i64, ptr } %t244, 0
  %t246 = extractvalue { i64, ptr } %t244, 1
  %t247 = mul i64 %t245, 1
  %t248 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t247)
  call void @llvm.memcpy.p0.p0.i64(ptr %t248, ptr %t246, i64 %t247, i1 false)
  %t249 = insertvalue { i64, ptr } undef, i64 %t245, 0
  %t250 = insertvalue { i64, ptr } %t249, ptr %t248, 1
  %t252 = call i32 @std_2fio_2ePrint(ptr %s11, { i64, ptr } %t250)
  store i32 %t252, ptr %l160
  %t253 = icmp ne i32 %t252, 0
  br i1 %t253, label %bb65, label %ok.254
ok.254:
  br label %bb64
bb64:
  br label %bb67
bb65:
  %t255 = load i32, ptr %l160, !tbaa !23
  %t256 = ashr i32 %t255, 16
  %t258 = icmp eq i32 %t256, 1
  store i1 %t258, ptr %l162, !tbaa !21
  br label %bb66
bb66:
  call void @__olang_ert_req_clear()
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s11)
  br label %bb68
bb68:
  %t259 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d169, i32 0, i32 1) })
  %t260 = extractvalue { i32, { i64, ptr } } %t259, 1
  %t261 = extractvalue { i32, { i64, ptr } } %t259, 0
  store i32 %t261, ptr %l165
  %t262 = icmp ne i32 %t261, 0
  br i1 %t262, label %bb70, label %ok.263
ok.263:
  store { i64, ptr } %t260, ptr %l164
  br label %bb69
bb69:
  %t264 = load { i64, ptr }, ptr %l164, !tbaa !27
  store { i64, ptr } %t264, ptr %l163, !tbaa !27
  br label %bb72
bb70:
  br label %bb71
bb71:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d170, i32 0, i32 1) }, ptr %l166, !tbaa !27
  %t265 = load { i64, ptr }, ptr %l166, !tbaa !27
  %t267 = extractvalue { i64, ptr } %t265, 0
  %t268 = extractvalue { i64, ptr } %t265, 1
  %t269 = mul i64 %t267, 1
  %t270 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t269)
  call void @llvm.memcpy.p0.p0.i64(ptr %t270, ptr %t268, i64 %t269, i1 false)
  %t271 = insertvalue { i64, ptr } undef, i64 %t267, 0
  %t272 = insertvalue { i64, ptr } %t271, ptr %t270, 1
  store { i64, ptr } %t272, ptr %l163, !tbaa !27
  br label %bb72
bb72:
  %t274 = load { i64, ptr }, ptr %l163, !tbaa !27
  %t275 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t274, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d171, i32 0, i32 1) })
  store i1 %t275, ptr %l169
  br label %bb73
bb73:
  %t276 = load i1, ptr %l169, !tbaa !21
  %t277 = xor i1 %t276, true
  br i1 %t277, label %bb74, label %bb75
bb74:
  store %olang.scope zeroinitializer, ptr %s13
  %t279 = load ptr, ptr %l16, !tbaa !29
  %t281 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2eDump(ptr %v2, ptr %s13, ptr %t279)
  store { i64, ptr } %t281, ptr %l172
  br label %bb76
bb75:
  br label %bb81
bb76:
  %t282 = load { i64, ptr }, ptr %l172, !tbaa !27
  %t283 = extractvalue { i64, ptr } %t282, 0
  %t284 = extractvalue { i64, ptr } %t282, 1
  %t285 = mul i64 %t283, 1
  %t286 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t285)
  call void @llvm.memcpy.p0.p0.i64(ptr %t286, ptr %t284, i64 %t285, i1 false)
  %t287 = insertvalue { i64, ptr } undef, i64 %t283, 0
  %t288 = insertvalue { i64, ptr } %t287, ptr %t286, 1
  %t290 = call i32 @std_2fio_2ePrintErr(ptr %s13, { i64, ptr } %t288)
  store i32 %t290, ptr %l174
  %t291 = icmp ne i32 %t290, 0
  br i1 %t291, label %bb78, label %ok.292
ok.292:
  br label %bb77
bb77:
  br label %bb80
bb78:
  %t293 = load i32, ptr %l174, !tbaa !23
  %t294 = ashr i32 %t293, 16
  %t296 = icmp eq i32 %t294, 1
  store i1 %t296, ptr %l176, !tbaa !21
  br label %bb79
bb79:
  call void @__olang_ert_req_clear()
  br label %bb80
bb80:
  call void @__olang_scope_close(ptr %s13)
  br label %bb81
bb81:
  %t297 = load ptr, ptr %l5, !tbaa !29
  %t299 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v2, ptr %t297)
  store i64 %t299, ptr %l178
  br label %bb82
bb82:
  %t300 = load i64, ptr %l178, !tbaa !24
  %t301 = icmp sgt i64 %t300, 0
  br i1 %t301, label %bb83, label %bb84
bb83:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb84:
  br label %bb85
bb85:
  %t304 = load ptr, ptr %l8, !tbaa !29
  %t305 = load ptr, ptr %l15, !tbaa !29
  %t306 = load ptr, ptr %l5, !tbaa !29
  %t307 = load ptr, ptr %l3, !tbaa !29
  %t308 = load i32, ptr %l2
  %t309 = load ptr, ptr %l11, !tbaa !29
  %t316 = call ptr @compiler_2folang_2eemitter(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %t304, ptr %t305, ptr %t306, ptr %t307, i32 %t308, ptr %t309)
  store ptr %t316, ptr %l187
  br label %bb86
bb86:
  %t317 = load ptr, ptr %l187, !tbaa !29
  store ptr %t317, ptr %l17, !tbaa !29
  %t318 = icmp sge i64 0, 0
  br i1 %t318, label %bb87, label %bb88
bb87:
  %t320 = icmp sle i64 0, 576460752303423487
  br i1 %t320, label %bb89, label %bb90
bb88:
  call void @__olang_check_failed(ptr @olang_loc_1d5612d13136b02e_cf27d9d671de6fa2)
  unreachable
bb89:
  %t322 = mul i64 0, 16
  %t323 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t322)
  %t324 = insertvalue { i64, ptr } undef, i64 0, 0
  %t325 = insertvalue { i64, ptr } %t324, ptr %t323, 1
  store { i64, ptr } %t325, ptr %l18, !tbaa !27
  %t327 = load i32, ptr %l2
  %t329 = trunc i64 0 to i32
  %t330 = icmp eq i32 %t327, %t329
  %t332 = xor i1 %t330, true
  br i1 %t332, label %bb91, label %bb92
bb90:
  call void @__olang_check_failed(ptr @olang_loc_1d5612d13136b02e_cf27d9d671de6fa2)
  unreachable
bb91:
  %t334 = load ptr, ptr %l7, !tbaa !29
  %t335 = load ptr, ptr %l3, !tbaa !29
  %t336 = load i1, ptr %l6, !tbaa !21
  %t340 = call { i64, ptr } @compiler_2folang_2emoduleKeys(ptr %v2, ptr %v2, ptr %t334, ptr %t335, i1 %t336)
  store { i64, ptr } %t340, ptr %l197
  br label %bb93
bb92:
  br label %bb95
bb93:
  %t341 = load { i64, ptr }, ptr %l197, !tbaa !27
  store { i64, ptr } %t341, ptr %l18, !tbaa !27
  %t342 = load ptr, ptr %l17, !tbaa !29
  store ptr %t342, ptr %l198, !tbaa !29
  %t343 = load ptr, ptr %l7, !tbaa !29
  %t344 = load ptr, ptr %l3, !tbaa !29
  %t345 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t349 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2folang_2ereusable(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %t343, ptr %t344, { i64, ptr } %t345)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t349, ptr %l202
  br label %bb94
bb94:
  %t350 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l202
  %t351 = load ptr, ptr %l198, !tbaa !29
  %t352 = getelementptr %"compiler/emit:Emitter", ptr %t351, i32 0, i32 66
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t350, ptr %t352
  br label %bb95
bb95:
  %t353 = load ptr, ptr %l17, !tbaa !29
  %t355 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2ecompiler_2femit_3aEmitter_2eObjects(ptr %v2, ptr %v3, ptr %t353)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t355, ptr %l204
  br label %bb96
bb96:
  %t356 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l204
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t356, ptr %l19
  %t357 = load ptr, ptr %l17, !tbaa !29
  %t359 = getelementptr %"compiler/emit:Emitter", ptr %t357, i32 0, i32 69
  %t360 = load i1, ptr %t359, !tbaa !21
  br i1 %t360, label %bb97, label %bb98
bb97:
  %t362 = load ptr, ptr %l8, !tbaa !29
  %t363 = load ptr, ptr %l15, !tbaa !29
  %t364 = load ptr, ptr %l5, !tbaa !29
  %t365 = load ptr, ptr %l3, !tbaa !29
  %t366 = load i32, ptr %l2
  %t367 = load ptr, ptr %l11, !tbaa !29
  %t374 = call ptr @compiler_2folang_2eemitter(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %t362, ptr %t363, ptr %t364, ptr %t365, i32 %t366, ptr %t367)
  store ptr %t374, ptr %l213
  br label %bb99
bb98:
  br label %bb101
bb99:
  %t375 = load ptr, ptr %l213, !tbaa !29
  store ptr %t375, ptr %l17, !tbaa !29
  %t376 = load ptr, ptr %l17, !tbaa !29
  %t378 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2ecompiler_2femit_3aEmitter_2eObjects(ptr %v2, ptr %v3, ptr %t376)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t378, ptr %l215
  br label %bb100
bb100:
  %t379 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l215
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t379, ptr %l19
  br label %bb101
bb101:
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d172, i32 0, i32 1) })
  br label %bb102
bb102:
  %t380 = load ptr, ptr %l17, !tbaa !29
  %t382 = getelementptr %"compiler/emit:Emitter", ptr %t380, i32 0, i32 47
  %t383 = load { i64, ptr }, ptr %t382, !tbaa !27
  %t385 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t383, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d173, i32 0, i32 1) })
  store i1 %t385, ptr %l218
  br label %bb103
bb103:
  %t386 = load i1, ptr %l218, !tbaa !21
  %t387 = xor i1 %t386, true
  br i1 %t387, label %bb104, label %bb105
bb104:
  %t389 = load ptr, ptr %l17, !tbaa !29
  %t391 = getelementptr %"compiler/emit:Emitter", ptr %t389, i32 0, i32 50
  %t392 = load i64, ptr %t391, !tbaa !24
  %t394 = icmp eq i64 %t392, 0
  br i1 %t394, label %bb106, label %bb107
bb105:
  br label %bb116
bb106:
  store %olang.scope zeroinitializer, ptr %s19
  %t396 = load ptr, ptr %l5, !tbaa !29
  store ptr %t396, ptr %l223, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t397
  %t398 = getelementptr { i64, [3 x i64] }, ptr %t397, i32 0, i32 0
  store i64 0, ptr %t398
  %t399 = load { i64, [3 x i64] }, ptr %t397
  store { i64, [3 x i64] } %t399, ptr %l224
  %t400 = load ptr, ptr %l17, !tbaa !29
  %t402 = getelementptr %"compiler/emit:Emitter", ptr %t400, i32 0, i32 47
  %t403 = load { i64, ptr }, ptr %t402, !tbaa !27
  %t405 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eFuzzNoTest(ptr %v2, ptr %s19, { i64, ptr } %t403)
  store %"compiler/msgs:Msg" %t405, ptr %l227
  br label %bb108
bb107:
  br label %bb110
bb108:
  %t406 = load ptr, ptr %l223, !tbaa !29
  %t407 = load { i64, [3 x i64] }, ptr %l224
  %t408 = load %"compiler/msgs:Msg", ptr %l227
  %t409 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v2, ptr %s19, ptr %t406, { i64, [3 x i64] } %t407, %"compiler/msgs:Msg" %t408)
  store i64 %t409, ptr %l228
  br label %bb109
bb109:
  call void @__olang_scope_close(ptr %s19)
  br label %bb110
bb110:
  %t410 = load ptr, ptr %l17, !tbaa !29
  %t412 = getelementptr %"compiler/emit:Emitter", ptr %t410, i32 0, i32 50
  %t413 = load i64, ptr %t412, !tbaa !24
  %t415 = icmp sgt i64 %t413, 1
  br i1 %t415, label %bb111, label %bb112
bb111:
  store %olang.scope zeroinitializer, ptr %s20
  %t417 = load ptr, ptr %l5, !tbaa !29
  store ptr %t417, ptr %l232, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t418
  %t419 = getelementptr { i64, [3 x i64] }, ptr %t418, i32 0, i32 0
  store i64 0, ptr %t419
  %t420 = load { i64, [3 x i64] }, ptr %t418
  store { i64, [3 x i64] } %t420, ptr %l233
  %t421 = load ptr, ptr %l17, !tbaa !29
  %t423 = getelementptr %"compiler/emit:Emitter", ptr %t421, i32 0, i32 47
  %t424 = load { i64, ptr }, ptr %t423, !tbaa !27
  %t425 = load ptr, ptr %l17, !tbaa !29
  %t427 = getelementptr %"compiler/emit:Emitter", ptr %t425, i32 0, i32 51
  %t428 = load { i64, ptr }, ptr %t427, !tbaa !27
  %t431 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eFuzzManyTests(ptr %v2, ptr %v2, ptr %s20, { i64, ptr } %t424, { i64, ptr } %t428)
  store %"compiler/msgs:Msg" %t431, ptr %l238
  br label %bb113
bb112:
  br label %bb115
bb113:
  %t432 = load ptr, ptr %l232, !tbaa !29
  %t433 = load { i64, [3 x i64] }, ptr %l233
  %t434 = load %"compiler/msgs:Msg", ptr %l238
  %t435 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v2, ptr %s20, ptr %t432, { i64, [3 x i64] } %t433, %"compiler/msgs:Msg" %t434)
  store i64 %t435, ptr %l239
  br label %bb114
bb114:
  call void @__olang_scope_close(ptr %s20)
  br label %bb115
bb115:
  %t436 = load ptr, ptr %l4, !tbaa !29
  %t437 = load ptr, ptr %l17, !tbaa !29
  %t439 = getelementptr %"compiler/emit:Emitter", ptr %t437, i32 0, i32 52
  %t440 = load { i64, ptr }, ptr %t439, !tbaa !27
  %t442 = extractvalue { i64, ptr } %t440, 1
  %t443 = extractvalue { i64, ptr } %t440, 0
  %t444 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t443)
  call void @olang_textcopy(ptr %t444, ptr %t442, i64 %t443)
  %t445 = insertvalue { i64, ptr } undef, i64 %t443, 0
  %t446 = insertvalue { i64, ptr } %t445, ptr %t444, 1
  %t448 = extractvalue { i64, ptr } %t446, 0
  %t449 = extractvalue { i64, ptr } %t446, 1
  %t450 = mul i64 %t448, 1
  %t451 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t450)
  call void @llvm.memcpy.p0.p0.i64(ptr %t451, ptr %t449, i64 %t450, i1 false)
  %t452 = insertvalue { i64, ptr } undef, i64 %t448, 0
  %t453 = insertvalue { i64, ptr } %t452, ptr %t451, 1
  %t456 = getelementptr %"compiler/build:Program", ptr %t436, i32 0, i32 6
  store { i64, ptr } %t453, ptr %t456, !tbaa !27
  br label %bb116
bb116:
  %t457 = load ptr, ptr %l17, !tbaa !29
  %t459 = getelementptr %"compiler/emit:Emitter", ptr %t457, i32 0, i32 48
  store ptr %t459, ptr %l20, !tbaa !29
  store i64 0, ptr %l21, !tbaa !24
  br label %bb117
bb117:
  %t461 = load i64, ptr %l21, !tbaa !24
  store i64 %t461, ptr %l247, !tbaa !24
  %t462 = load ptr, ptr %l20, !tbaa !29
  %t464 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v2, ptr %t462)
  store i64 %t464, ptr %l249
  br label %bb118
bb118:
  %t465 = load i64, ptr %l247, !tbaa !24
  %t466 = load i64, ptr %l249, !tbaa !24
  %t467 = icmp slt i64 %t465, %t466
  %t469 = xor i1 %t467, true
  br i1 %t469, label %bb119, label %bb120
bb119:
  br label %bb125
bb120:
  br label %bb121
bb121:
  %t471 = load ptr, ptr %l20, !tbaa !29
  %t472 = load i64, ptr %l21, !tbaa !24
  %t475 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v2, ptr %v2, ptr %t471, i64 %t472)
  store { i64, ptr } %t475, ptr %l254
  br label %bb122
bb122:
  %t476 = load { i64, ptr }, ptr %l254, !tbaa !27
  %t477 = load ptr, ptr %l4, !tbaa !29
  %t479 = getelementptr %"compiler/build:Program", ptr %t477, i32 0, i32 7
  %t482 = extractvalue { i64, ptr } %t476, 1
  %t483 = extractvalue { i64, ptr } %t476, 0
  %t484 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t483)
  call void @olang_textcopy(ptr %t484, ptr %t482, i64 %t483)
  %t485 = insertvalue { i64, ptr } undef, i64 %t483, 0
  %t486 = insertvalue { i64, ptr } %t485, ptr %t484, 1
  %t488 = extractvalue { i64, ptr } %t486, 0
  %t489 = extractvalue { i64, ptr } %t486, 1
  %t490 = mul i64 %t488, 1
  %t491 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t490)
  call void @llvm.memcpy.p0.p0.i64(ptr %t491, ptr %t489, i64 %t490, i1 false)
  %t492 = insertvalue { i64, ptr } undef, i64 %t488, 0
  %t493 = insertvalue { i64, ptr } %t492, ptr %t491, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v3, ptr %v3, ptr %t479, { i64, ptr } %t493)
  br label %bb123
bb123:
  br label %bb124
bb124:
  %t496 = load i64, ptr %l21, !tbaa !24
  %t498 = add i64 %t496, 1
  store i64 %t498, ptr %l21, !tbaa !24
  br label %bb117
bb125:
  %t500 = load ptr, ptr %l17, !tbaa !29
  %t502 = getelementptr %"compiler/emit:Emitter", ptr %t500, i32 0, i32 9
  %t504 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v2, ptr %t502)
  store i64 %t504, ptr %l264
  br label %bb126
bb126:
  %t505 = load i64, ptr %l264, !tbaa !24
  %t506 = icmp sgt i64 %t505, 0
  br i1 %t506, label %bb127, label %bb128
bb127:
  store i1 true, ptr %l266, !tbaa !21
  br label %bb130
bb128:
  %t508 = load ptr, ptr %l15, !tbaa !29
  %t510 = getelementptr %"compiler/lower:Lowerer", ptr %t508, i32 0, i32 4
  %t512 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aGap_3e_2eLen_3ccompiler_2flower_3aGap_3e(ptr %v2, ptr %t510)
  store i64 %t512, ptr %l269
  br label %bb129
bb129:
  %t513 = load i64, ptr %l269, !tbaa !24
  %t514 = icmp sgt i64 %t513, 0
  store i1 %t514, ptr %l266, !tbaa !21
  br label %bb130
bb130:
  %t516 = load i1, ptr %l266, !tbaa !21
  br i1 %t516, label %bb131, label %bb132
bb131:
  %t517 = load ptr, ptr %l17, !tbaa !29
  %t519 = getelementptr %"compiler/emit:Emitter", ptr %t517, i32 0, i32 9
  store ptr %t519, ptr %l23, !tbaa !29
  store i64 0, ptr %l24, !tbaa !24
  br label %bb133
bb132:
  br label %bb152
bb133:
  store %olang.scope zeroinitializer, ptr %s28
  %t521 = load i64, ptr %l24, !tbaa !24
  store i64 %t521, ptr %l273, !tbaa !24
  %t522 = load ptr, ptr %l23, !tbaa !29
  %t524 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v2, ptr %t522)
  store i64 %t524, ptr %l275
  br label %bb134
bb134:
  %t525 = load i64, ptr %l273, !tbaa !24
  %t526 = load i64, ptr %l275, !tbaa !24
  %t527 = icmp slt i64 %t525, %t526
  %t529 = xor i1 %t527, true
  br i1 %t529, label %bb135, label %bb136
bb135:
  call void @__olang_scope_close(ptr %s28)
  br label %bb141
bb136:
  br label %bb137
bb137:
  %t531 = load ptr, ptr %l23, !tbaa !29
  %t532 = load i64, ptr %l24, !tbaa !24
  %t535 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v2, ptr %v2, ptr %t531, i64 %t532)
  store { i64, ptr } %t535, ptr %l280
  br label %bb138
bb138:
  %t536 = load { i64, ptr }, ptr %l280, !tbaa !27
  %t538 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d174, i32 0, i32 1) }, 1
  %t539 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d174, i32 0, i32 1) }, 0
  %t541 = extractvalue { i64, ptr } %t536, 1
  %t542 = extractvalue { i64, ptr } %t536, 0
  %t543 = add i64 %t539, %t542
  %t544 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d175, i32 0, i32 1) }, 1
  %t545 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d175, i32 0, i32 1) }, 0
  %t546 = add i64 %t543, %t545
  %t547 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t546)
  call void @olang_textcopy(ptr %t547, ptr %t538, i64 %t539)
  %t548 = getelementptr i8, ptr %t547, i64 %t539
  call void @olang_textcopy(ptr %t548, ptr %t541, i64 %t542)
  %t549 = getelementptr i8, ptr %t548, i64 %t542
  call void @olang_textcopy(ptr %t549, ptr %t544, i64 %t545)
  %t550 = insertvalue { i64, ptr } undef, i64 %t546, 0
  %t551 = insertvalue { i64, ptr } %t550, ptr %t547, 1
  %t553 = extractvalue { i64, ptr } %t551, 0
  %t554 = extractvalue { i64, ptr } %t551, 1
  %t555 = mul i64 %t553, 1
  %t556 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t555)
  call void @llvm.memcpy.p0.p0.i64(ptr %t556, ptr %t554, i64 %t555, i1 false)
  %t557 = insertvalue { i64, ptr } undef, i64 %t553, 0
  %t558 = insertvalue { i64, ptr } %t557, ptr %t556, 1
  call void @compiler_2fbuild_2eUnbuildable(ptr %s28, { i64, ptr } %t558)
  br label %bb139
bb139:
  call void @__olang_scope_close(ptr %s28)
  br label %bb140
bb140:
  %t560 = load i64, ptr %l24, !tbaa !24
  %t562 = add i64 %t560, 1
  store i64 %t562, ptr %l24, !tbaa !24
  br label %bb133
bb141:
  %t564 = load ptr, ptr %l15, !tbaa !29
  %t566 = getelementptr %"compiler/lower:Lowerer", ptr %t564, i32 0, i32 4
  store ptr %t566, ptr %l26, !tbaa !29
  store i64 0, ptr %l27, !tbaa !24
  br label %bb142
bb142:
  store %olang.scope zeroinitializer, ptr %s32
  %t568 = load i64, ptr %l27, !tbaa !24
  store i64 %t568, ptr %l288, !tbaa !24
  %t569 = load ptr, ptr %l26, !tbaa !29
  %t571 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aGap_3e_2eLen_3ccompiler_2flower_3aGap_3e(ptr %v2, ptr %t569)
  store i64 %t571, ptr %l290
  br label %bb143
bb143:
  %t572 = load i64, ptr %l288, !tbaa !24
  %t573 = load i64, ptr %l290, !tbaa !24
  %t574 = icmp slt i64 %t572, %t573
  %t576 = xor i1 %t574, true
  br i1 %t576, label %bb144, label %bb145
bb144:
  call void @__olang_scope_close(ptr %s32)
  br label %bb151
bb145:
  br label %bb146
bb146:
  %t578 = load ptr, ptr %l26, !tbaa !29
  %t579 = load i64, ptr %l27, !tbaa !24
  %t582 = call %"compiler/lower:Gap" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aGap_3e_2eAt_3ccompiler_2flower_3aGap_3e(ptr %v2, ptr %v2, ptr %t578, i64 %t579)
  store %"compiler/lower:Gap" %t582, ptr %l295
  br label %bb147
bb147:
  %t583 = load %"compiler/lower:Gap", ptr %l295
  store %"compiler/lower:Gap" %t583, ptr %l28
  %t584 = load ptr, ptr %l5, !tbaa !29
  %t585 = getelementptr %"compiler/lower:Gap", ptr %l28, i32 0, i32 0
  %t586 = load i64, ptr %t585, !tbaa !24
  %t587 = getelementptr %"compiler/lower:Gap", ptr %l28, i32 0, i32 1
  %t588 = getelementptr %"compiler/source:Span", ptr %t587, i32 0, i32 0
  %t589 = load i32, ptr %t588, !tbaa !23
  %t591 = sext i32 %t589 to i64
  %t595 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v2, ptr %s32, ptr %t584, i64 %t586, i64 %t591)
  store { i64, ptr } %t595, ptr %l300
  br label %bb148
bb148:
  %t596 = getelementptr %"compiler/lower:Gap", ptr %l28, i32 0, i32 2
  %t597 = load { i64, ptr }, ptr %t596, !tbaa !27
  %t598 = load { i64, ptr }, ptr %l300, !tbaa !27
  %t599 = extractvalue { i64, ptr } %t598, 1
  %t600 = extractvalue { i64, ptr } %t598, 0
  %t601 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d176, i32 0, i32 1) }, 1
  %t602 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d176, i32 0, i32 1) }, 0
  %t603 = add i64 %t600, %t602
  %t605 = extractvalue { i64, ptr } %t597, 1
  %t606 = extractvalue { i64, ptr } %t597, 0
  %t607 = add i64 %t603, %t606
  %t608 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d177, i32 0, i32 1) }, 1
  %t609 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d177, i32 0, i32 1) }, 0
  %t610 = add i64 %t607, %t609
  %t611 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t610)
  call void @olang_textcopy(ptr %t611, ptr %t599, i64 %t600)
  %t612 = getelementptr i8, ptr %t611, i64 %t600
  call void @olang_textcopy(ptr %t612, ptr %t601, i64 %t602)
  %t613 = getelementptr i8, ptr %t612, i64 %t602
  call void @olang_textcopy(ptr %t613, ptr %t605, i64 %t606)
  %t614 = getelementptr i8, ptr %t613, i64 %t606
  call void @olang_textcopy(ptr %t614, ptr %t608, i64 %t609)
  %t615 = insertvalue { i64, ptr } undef, i64 %t610, 0
  %t616 = insertvalue { i64, ptr } %t615, ptr %t611, 1
  %t618 = extractvalue { i64, ptr } %t616, 0
  %t619 = extractvalue { i64, ptr } %t616, 1
  %t620 = mul i64 %t618, 1
  %t621 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t620)
  call void @llvm.memcpy.p0.p0.i64(ptr %t621, ptr %t619, i64 %t620, i1 false)
  %t622 = insertvalue { i64, ptr } undef, i64 %t618, 0
  %t623 = insertvalue { i64, ptr } %t622, ptr %t621, 1
  call void @compiler_2fbuild_2eUnbuildable(ptr %s32, { i64, ptr } %t623)
  br label %bb149
bb149:
  call void @__olang_scope_close(ptr %s32)
  br label %bb150
bb150:
  %t625 = load i64, ptr %l27, !tbaa !24
  %t627 = add i64 %t625, 1
  store i64 %t627, ptr %l27, !tbaa !24
  br label %bb142
bb151:
  call void @__olang_scope_close(ptr %s0)
  store i32 65537, ptr %rv
  br label %ret
bb152:
  %t630 = load ptr, ptr %l5, !tbaa !29
  %t632 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v2, ptr %t630)
  store i64 %t632, ptr %l308
  br label %bb153
bb153:
  %t633 = load i64, ptr %l308, !tbaa !24
  %t634 = icmp sgt i64 %t633, 0
  br i1 %t634, label %bb154, label %bb155
bb154:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb155:
  br label %bb156
bb156:
  %t637 = load ptr, ptr %l3, !tbaa !29
  %t639 = getelementptr %"compiler/build:Config", ptr %t637, i32 0, i32 2
  %t640 = load %"compiler/target:Target", ptr %t639
  store %"compiler/target:Target" %t640, ptr %l29
  store i1 false, ptr %l30, !tbaa !21
  %t642 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t642, ptr %l313
  br label %bb157
bb157:
  %t643 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l313
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t643, ptr %l31
  store ptr %l19, ptr %l32, !tbaa !29
  store i64 0, ptr %l33, !tbaa !24
  br label %bb158
bb158:
  store %olang.scope zeroinitializer, ptr %s37
  %t645 = load i64, ptr %l33, !tbaa !24
  store i64 %t645, ptr %l315, !tbaa !24
  %t646 = load ptr, ptr %l32, !tbaa !29
  %t648 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2femit_3aObject_3e_2eLen_3ccompiler_2femit_3aObject_3e(ptr %v3, ptr %t646)
  store i64 %t648, ptr %l317
  br label %bb159
bb159:
  %t649 = load i64, ptr %l315, !tbaa !24
  %t650 = load i64, ptr %l317, !tbaa !24
  %t651 = icmp slt i64 %t649, %t650
  %t653 = xor i1 %t651, true
  br i1 %t653, label %bb160, label %bb161
bb160:
  call void @__olang_scope_close(ptr %s37)
  br label %bb242
bb161:
  br label %bb162
bb162:
  %t655 = load ptr, ptr %l32, !tbaa !29
  %t656 = load i64, ptr %l33, !tbaa !24
  %t659 = call %"compiler/emit:Object" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2femit_3aObject_3e_2eAt_3ccompiler_2femit_3aObject_3e(ptr %v3, ptr %v3, ptr %t655, i64 %t656)
  store %"compiler/emit:Object" %t659, ptr %l322
  br label %bb163
bb163:
  %t660 = load %"compiler/emit:Object", ptr %l322
  store %"compiler/emit:Object" %t660, ptr %l34
  %t661 = getelementptr %"compiler/emit:Object", ptr %l34, i32 0, i32 3
  %t662 = load i64, ptr %t661, !tbaa !24
  %t664 = icmp sge i64 %t662, 0
  br i1 %t664, label %bb164, label %bb165
bb164:
  store %olang.scope zeroinitializer, ptr %s38
  %t666 = load ptr, ptr %l17, !tbaa !29
  %t668 = getelementptr %"compiler/emit:Emitter", ptr %t666, i32 0, i32 66
  %t669 = getelementptr %"compiler/emit:Object", ptr %l34, i32 0, i32 3
  %t670 = load i64, ptr %t669, !tbaa !24
  %t673 = call %"compiler/emit:Reused" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2femit_3aReused_3e_2eAt_3ccompiler_2femit_3aReused_3e(ptr %v2, ptr %v2, ptr %t668, i64 %t670)
  store %"compiler/emit:Reused" %t673, ptr %l328
  br label %bb166
bb165:
  br label %bb198
bb166:
  %t674 = load %"compiler/emit:Reused", ptr %l328
  store %"compiler/emit:Reused" %t674, ptr %l35
  %t675 = load ptr, ptr %l3, !tbaa !29
  store ptr %t675, ptr %l329, !tbaa !29
  %t676 = load ptr, ptr %l7, !tbaa !29
  %t678 = getelementptr %"compiler/load:Loader", ptr %t676, i32 0, i32 5
  %t679 = getelementptr %"compiler/emit:Reused", ptr %l35, i32 0, i32 0
  %t680 = load i64, ptr %t679, !tbaa !24
  %t683 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v2, ptr %v2, ptr %t678, i64 %t680)
  store ptr %t683, ptr %l333
  br label %bb167
bb167:
  %t684 = load ptr, ptr %l333, !tbaa !29
  %t686 = getelementptr %"compiler/load:Module", ptr %t684, i32 0, i32 2
  %t687 = load { i64, ptr }, ptr %t686, !tbaa !27
  %t688 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t688, ptr %l336, !tbaa !27
  %t689 = getelementptr %"compiler/emit:Reused", ptr %l35, i32 0, i32 0
  %t690 = load i64, ptr %t689, !tbaa !24
  %t692 = getelementptr { i64, ptr }, ptr %l336, i32 0, i32 1
  %t693 = load ptr, ptr %t692, !tbaa !27
  %t694 = getelementptr { i64, ptr }, ptr %t693, i64 %t690
  %t695 = load { i64, ptr }, ptr %t694, !tbaa !37
  %t696 = load ptr, ptr %l329, !tbaa !29
  %t699 = call { i64, ptr } @compiler_2folang_2erecordPath(ptr %v2, ptr %v2, ptr %v2, ptr %s38, ptr %t696, { i64, ptr } %t687, { i64, ptr } %t695)
  store { i64, ptr } %t699, ptr %l339
  br label %bb168
bb168:
  %t700 = load { i64, ptr }, ptr %l339, !tbaa !27
  store { i64, ptr } %t700, ptr %l36, !tbaa !27
  %t701 = getelementptr %"compiler/emit:Reused", ptr %l35, i32 0, i32 1
  store ptr %t701, ptr %l37, !tbaa !29
  store i64 0, ptr %l38, !tbaa !24
  br label %bb169
bb169:
  store %olang.scope zeroinitializer, ptr %s40
  %t703 = load i64, ptr %l38, !tbaa !24
  store i64 %t703, ptr %l341, !tbaa !24
  %t704 = load ptr, ptr %l37, !tbaa !29
  %t706 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v2, ptr %t704)
  store i64 %t706, ptr %l343
  br label %bb170
bb170:
  %t707 = load i64, ptr %l341, !tbaa !24
  %t708 = load i64, ptr %l343, !tbaa !24
  %t709 = icmp slt i64 %t707, %t708
  %t711 = xor i1 %t709, true
  br i1 %t711, label %bb171, label %bb172
bb171:
  call void @__olang_scope_close(ptr %s40)
  br label %bb196
bb172:
  br label %bb173
bb173:
  %t713 = load i64, ptr %l38, !tbaa !24
  store i64 %t713, ptr %l39, !tbaa !24
  %t715 = load ptr, ptr %l37, !tbaa !29
  %t716 = load i64, ptr %l38, !tbaa !24
  %t719 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v2, ptr %v2, ptr %t715, i64 %t716)
  store { i64, ptr } %t719, ptr %l349
  br label %bb174
bb174:
  %t720 = load { i64, ptr }, ptr %l349, !tbaa !27
  store { i64, ptr } %t720, ptr %l40, !tbaa !27
  %t721 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t722 = load i64, ptr %l39, !tbaa !24
  %t724 = extractvalue { i64, ptr } %t721, 1
  %t725 = extractvalue { i64, ptr } %t721, 0
  %t726 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d178, i32 0, i32 1) }, 1
  %t727 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d178, i32 0, i32 1) }, 0
  %t728 = add i64 %t725, %t727
  %t730 = call i64 @__olang_fmt_i64(ptr null, i64 %t722)
  %t731 = add i64 %t728, %t730
  %t732 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d179, i32 0, i32 1) }, 1
  %t733 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d179, i32 0, i32 1) }, 0
  %t734 = add i64 %t731, %t733
  %t735 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t734)
  call void @olang_textcopy(ptr %t735, ptr %t724, i64 %t725)
  %t736 = getelementptr i8, ptr %t735, i64 %t725
  call void @olang_textcopy(ptr %t736, ptr %t726, i64 %t727)
  %t737 = getelementptr i8, ptr %t736, i64 %t727
  %t738 = call i64 @__olang_fmt_i64(ptr %t737, i64 %t722)
  %t739 = getelementptr i8, ptr %t737, i64 %t730
  call void @olang_textcopy(ptr %t739, ptr %t732, i64 %t733)
  %t740 = insertvalue { i64, ptr } undef, i64 %t734, 0
  %t741 = insertvalue { i64, ptr } %t740, ptr %t735, 1
  %t743 = extractvalue { i64, ptr } %t741, 0
  %t744 = extractvalue { i64, ptr } %t741, 1
  %t745 = mul i64 %t743, 1
  %t746 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t745)
  call void @llvm.memcpy.p0.p0.i64(ptr %t746, ptr %t744, i64 %t745, i1 false)
  %t747 = insertvalue { i64, ptr } undef, i64 %t743, 0
  %t748 = insertvalue { i64, ptr } %t747, ptr %t746, 1
  %t750 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v3, ptr %v3, { i64, ptr } %t748)
  %t751 = extractvalue { i32, { i64, ptr } } %t750, 1
  %t752 = extractvalue { i32, { i64, ptr } } %t750, 0
  store i32 %t752, ptr %l356
  %t753 = icmp ne i32 %t752, 0
  br i1 %t753, label %bb176, label %ok.754
ok.754:
  store { i64, ptr } %t751, ptr %l355
  br label %bb175
bb175:
  %t755 = load { i64, ptr }, ptr %l355, !tbaa !27
  store { i64, ptr } %t755, ptr %l350, !tbaa !27
  br label %bb179
bb176:
  %t756 = load i32, ptr %l356, !tbaa !23
  %t757 = ashr i32 %t756, 16
  %t759 = icmp eq i32 %t757, 1
  store i1 %t759, ptr %l358, !tbaa !21
  br label %bb177
bb177:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s42
  %t760 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t761 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d180, i32 0, i32 1) }, 1
  %t762 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d180, i32 0, i32 1) }, 0
  %t764 = extractvalue { i64, ptr } %t760, 1
  %t765 = extractvalue { i64, ptr } %t760, 0
  %t766 = add i64 %t762, %t765
  %t767 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d181, i32 0, i32 1) }, 1
  %t768 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d181, i32 0, i32 1) }, 0
  %t769 = add i64 %t766, %t768
  %t770 = call ptr @__olang_scope_alloc(ptr %s42, i64 %t769)
  call void @olang_textcopy(ptr %t770, ptr %t761, i64 %t762)
  %t771 = getelementptr i8, ptr %t770, i64 %t762
  call void @olang_textcopy(ptr %t771, ptr %t764, i64 %t765)
  %t772 = getelementptr i8, ptr %t771, i64 %t765
  call void @olang_textcopy(ptr %t772, ptr %t767, i64 %t768)
  %t773 = insertvalue { i64, ptr } undef, i64 %t769, 0
  %t774 = insertvalue { i64, ptr } %t773, ptr %t770, 1
  %t776 = extractvalue { i64, ptr } %t774, 0
  %t777 = extractvalue { i64, ptr } %t774, 1
  %t778 = mul i64 %t776, 1
  %t779 = call ptr @__olang_scope_alloc(ptr %s42, i64 %t778)
  call void @llvm.memcpy.p0.p0.i64(ptr %t779, ptr %t777, i64 %t778, i1 false)
  %t780 = insertvalue { i64, ptr } undef, i64 %t776, 0
  %t781 = insertvalue { i64, ptr } %t780, ptr %t779, 1
  call void @compiler_2fbuild_2eUnbuildable(ptr %s42, { i64, ptr } %t781)
  br label %bb178
bb178:
  call void @__olang_scope_close(ptr %s42)
  call void @__olang_scope_close(ptr %s40)
  call void @__olang_scope_close(ptr %s38)
  call void @__olang_scope_close(ptr %s37)
  call void @__olang_scope_close(ptr %s0)
  store i32 65537, ptr %rv
  br label %ret
bb179:
  %t784 = load { i64, ptr }, ptr %l350, !tbaa !27
  store { i64, ptr } %t784, ptr %l41, !tbaa !27
  %t785 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d182, i32 0, i32 1) }, ptr %l365, !tbaa !27
  %t788 = load { i64, ptr }, ptr %l365, !tbaa !27
  %t789 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v3, ptr %s40, { i64, ptr } %t785, { i64, ptr } %t788)
  store i1 %t789, ptr %l366
  br label %bb180
bb180:
  %t790 = load i1, ptr %l366, !tbaa !21
  br i1 %t790, label %bb181, label %bb182
bb181:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb183
bb182:
  br label %bb183
bb183:
  %t791 = load ptr, ptr %l17, !tbaa !29
  %t793 = getelementptr %"compiler/emit:Emitter", ptr %t791, i32 0, i32 6
  %t794 = load i1, ptr %t793, !tbaa !21
  br i1 %t794, label %bb184, label %bb185
bb184:
  %t796 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t798 = call { i64, ptr } @compiler_2folang_2elibraryIr(ptr %v3, ptr %v3, { i64, ptr } %t796)
  store { i64, ptr } %t798, ptr %l370
  br label %bb186
bb185:
  br label %bb187
bb186:
  %t799 = load { i64, ptr }, ptr %l370, !tbaa !27
  %t800 = extractvalue { i64, ptr } %t799, 0
  %t801 = extractvalue { i64, ptr } %t799, 1
  %t802 = mul i64 %t800, 1
  %t803 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t802)
  call void @llvm.memcpy.p0.p0.i64(ptr %t803, ptr %t801, i64 %t802, i1 false)
  %t804 = insertvalue { i64, ptr } undef, i64 %t800, 0
  %t805 = insertvalue { i64, ptr } %t804, ptr %t803, 1
  store { i64, ptr } %t805, ptr %l41, !tbaa !27
  br label %bb187
bb187:
  %t807 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t809 = extractvalue { i64, ptr } %t807, 1
  %t810 = extractvalue { i64, ptr } %t807, 0
  %t811 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t810)
  call void @olang_textcopy(ptr %t811, ptr %t809, i64 %t810)
  %t812 = insertvalue { i64, ptr } undef, i64 %t810, 0
  %t813 = insertvalue { i64, ptr } %t812, ptr %t811, 1
  %t815 = extractvalue { i64, ptr } %t813, 0
  %t816 = extractvalue { i64, ptr } %t813, 1
  %t817 = mul i64 %t815, 1
  %t818 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t817)
  call void @llvm.memcpy.p0.p0.i64(ptr %t818, ptr %t816, i64 %t817, i1 false)
  %t819 = insertvalue { i64, ptr } undef, i64 %t815, 0
  %t820 = insertvalue { i64, ptr } %t819, ptr %t818, 1
  store { i64, ptr } %t820, ptr %l374, !tbaa !27
  %t821 = getelementptr %"compiler/emit:Reused", ptr %l35, i32 0, i32 2
  %t822 = load i64, ptr %l39, !tbaa !24
  %t825 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v2, ptr %t821, i64 %t822)
  store i1 %t825, ptr %l377
  br label %bb188
bb188:
  %t826 = load i1, ptr %l377, !tbaa !21
  br i1 %t826, label %bb189, label %bb190
bb189:
  store i32 4, ptr %l378
  br label %bb191
bb190:
  store i32 0, ptr %l378
  br label %bb191
bb191:
  %t829 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t830 = load { i64, ptr }, ptr %l374, !tbaa !27
  %t831 = load i32, ptr %l378
  %t833 = call %"compiler/build:Unit" @compiler_2fbuild_3aUnit_2ector(ptr %v3, ptr %v3, ptr %v3, { i64, ptr } %t830, i32 %t831, { i64, ptr } %t829)
  store %"compiler/build:Unit" %t833, ptr %l382
  br label %bb192
bb192:
  %t834 = load %"compiler/build:Unit", ptr %l382
  %t835 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 56, i64 8)
  store %"compiler/build:Unit" %t834, ptr %t835
  store ptr %t835, ptr %l42, !tbaa !29
  %t837 = load ptr, ptr %l42, !tbaa !29
  store ptr %t837, ptr %l384, !tbaa !29
  %t838 = getelementptr %"compiler/emit:Reused", ptr %l35, i32 0, i32 3
  %t839 = load i64, ptr %l39, !tbaa !24
  %t842 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v2, ptr %s40, ptr %t838, i64 %t839)
  store { i64, ptr } %t842, ptr %l387
  br label %bb193
bb193:
  %t843 = load { i64, ptr }, ptr %l387, !tbaa !27
  %t844 = extractvalue { i64, ptr } %t843, 1
  %t845 = extractvalue { i64, ptr } %t843, 0
  %t846 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t845)
  call void @olang_textcopy(ptr %t846, ptr %t844, i64 %t845)
  %t847 = insertvalue { i64, ptr } undef, i64 %t845, 0
  %t848 = insertvalue { i64, ptr } %t847, ptr %t846, 1
  %t850 = extractvalue { i64, ptr } %t848, 0
  %t851 = extractvalue { i64, ptr } %t848, 1
  %t852 = mul i64 %t850, 1
  %t853 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t852)
  call void @llvm.memcpy.p0.p0.i64(ptr %t853, ptr %t851, i64 %t852, i1 false)
  %t854 = insertvalue { i64, ptr } undef, i64 %t850, 0
  %t855 = insertvalue { i64, ptr } %t854, ptr %t853, 1
  %t857 = load ptr, ptr %l384, !tbaa !29
  %t858 = getelementptr %"compiler/build:Unit", ptr %t857, i32 0, i32 3
  store { i64, ptr } %t855, ptr %t858, !tbaa !27
  %t859 = load ptr, ptr %l4, !tbaa !29
  %t861 = getelementptr %"compiler/build:Program", ptr %t859, i32 0, i32 0
  %t862 = load ptr, ptr %l42, !tbaa !29
  %t864 = load %"compiler/build:Unit", ptr %t862
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2ePush_3ccompiler_2fbuild_3aUnit_3e(ptr %v3, ptr %v3, ptr %t861, %"compiler/build:Unit" %t864)
  br label %bb194
bb194:
  call void @__olang_scope_close(ptr %s40)
  br label %bb195
bb195:
  %t867 = load i64, ptr %l38, !tbaa !24
  %t869 = add i64 %t867, 1
  store i64 %t869, ptr %l38, !tbaa !24
  br label %bb169
bb196:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l31, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d183, i32 0, i32 1) })
  br label %bb197
bb197:
  call void @__olang_scope_close(ptr %s38)
  call void @__olang_scope_close(ptr %s37)
  br label %bb241
bb198:
  %t872 = getelementptr %"compiler/emit:Object", ptr %l34, i32 0, i32 2
  %t873 = load { i64, ptr }, ptr %t872, !tbaa !27
  store { i64, ptr } %t873, ptr %l43, !tbaa !27
  %t875 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d184, i32 0, i32 1) }, ptr %l400, !tbaa !27
  %t878 = load { i64, ptr }, ptr %l400, !tbaa !27
  %t879 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v3, ptr %s37, { i64, ptr } %t875, { i64, ptr } %t878)
  store i1 %t879, ptr %l401
  br label %bb199
bb199:
  %t880 = load i1, ptr %l401, !tbaa !21
  br i1 %t880, label %bb200, label %bb201
bb200:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb202
bb201:
  br label %bb202
bb202:
  %t881 = load ptr, ptr %l17, !tbaa !29
  %t883 = getelementptr %"compiler/emit:Emitter", ptr %t881, i32 0, i32 6
  %t884 = load i1, ptr %t883, !tbaa !21
  br i1 %t884, label %bb203, label %bb204
bb203:
  %t886 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t888 = call { i64, ptr } @compiler_2folang_2elibraryIr(ptr %v3, ptr %v3, { i64, ptr } %t886)
  store { i64, ptr } %t888, ptr %l405
  br label %bb205
bb204:
  br label %bb206
bb205:
  %t889 = load { i64, ptr }, ptr %l405, !tbaa !27
  %t890 = extractvalue { i64, ptr } %t889, 0
  %t891 = extractvalue { i64, ptr } %t889, 1
  %t892 = mul i64 %t890, 1
  %t893 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t892)
  call void @llvm.memcpy.p0.p0.i64(ptr %t893, ptr %t891, i64 %t892, i1 false)
  %t894 = insertvalue { i64, ptr } undef, i64 %t890, 0
  %t895 = insertvalue { i64, ptr } %t894, ptr %t893, 1
  store { i64, ptr } %t895, ptr %l43, !tbaa !27
  br label %bb206
bb206:
  %t897 = getelementptr %"compiler/emit:Object", ptr %l34, i32 0, i32 1
  %t898 = load i32, ptr %t897
  store i32 %t898, ptr %l44
  %t900 = load i32, ptr %l44
  %t902 = trunc i64 0 to i32
  %t903 = icmp eq i32 %t900, %t902
  br i1 %t903, label %bb207, label %bb208
bb207:
  br label %bb209
bb208:
  br label %bb210
bb209:
  store i32 0, ptr %l408
  br label %bb227
bb210:
  %t906 = load i32, ptr %l44
  %t908 = trunc i64 1 to i32
  %t909 = icmp eq i32 %t906, %t908
  br i1 %t909, label %bb211, label %bb212
bb211:
  br label %bb213
bb212:
  br label %bb214
bb213:
  store i32 1, ptr %l408
  br label %bb227
bb214:
  %t912 = load i32, ptr %l44
  %t914 = trunc i64 2 to i32
  %t915 = icmp eq i32 %t912, %t914
  br i1 %t915, label %bb215, label %bb216
bb215:
  br label %bb217
bb216:
  br label %bb218
bb217:
  store i32 2, ptr %l408
  br label %bb227
bb218:
  %t918 = load i32, ptr %l44
  %t920 = trunc i64 3 to i32
  %t921 = icmp eq i32 %t918, %t920
  br i1 %t921, label %bb219, label %bb220
bb219:
  br label %bb221
bb220:
  br label %bb222
bb221:
  store i32 3, ptr %l408
  br label %bb227
bb222:
  %t924 = load i32, ptr %l44
  %t926 = trunc i64 4 to i32
  %t927 = icmp eq i32 %t924, %t926
  br i1 %t927, label %bb223, label %bb224
bb223:
  br label %bb225
bb224:
  br label %bb226
bb225:
  store i32 4, ptr %l408
  br label %bb227
bb226:
  call void @__olang_check_failed(ptr @olang_loc_5772a8514d833044_b816e84cde98ab20)
  unreachable
bb227:
  %t930 = load i32, ptr %l408
  %t931 = getelementptr %"compiler/emit:Object", ptr %l34, i32 0, i32 0
  %t932 = load { i64, ptr }, ptr %t931, !tbaa !27
  %t934 = extractvalue { i64, ptr } %t932, 1
  %t935 = extractvalue { i64, ptr } %t932, 0
  %t936 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t935)
  call void @olang_textcopy(ptr %t936, ptr %t934, i64 %t935)
  %t937 = insertvalue { i64, ptr } undef, i64 %t935, 0
  %t938 = insertvalue { i64, ptr } %t937, ptr %t936, 1
  %t940 = extractvalue { i64, ptr } %t938, 0
  %t941 = extractvalue { i64, ptr } %t938, 1
  %t942 = mul i64 %t940, 1
  %t943 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t942)
  call void @llvm.memcpy.p0.p0.i64(ptr %t943, ptr %t941, i64 %t942, i1 false)
  %t944 = insertvalue { i64, ptr } undef, i64 %t940, 0
  %t945 = insertvalue { i64, ptr } %t944, ptr %t943, 1
  %t947 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t951 = call %"compiler/build:Unit" @compiler_2fbuild_3aUnit_2ector(ptr %v3, ptr %v3, ptr %v3, { i64, ptr } %t945, i32 %t930, { i64, ptr } %t947)
  store %"compiler/build:Unit" %t951, ptr %l429
  br label %bb228
bb228:
  %t952 = load %"compiler/build:Unit", ptr %l429
  %t953 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 56, i64 8)
  store %"compiler/build:Unit" %t952, ptr %t953
  store ptr %t953, ptr %l46, !tbaa !29
  %t955 = load i32, ptr %l2
  %t957 = trunc i64 0 to i32
  %t958 = icmp eq i32 %t955, %t957
  %t960 = xor i1 %t958, true
  br i1 %t960, label %bb229, label %bb230
bb229:
  %t962 = getelementptr %"compiler/emit:Object", ptr %l34, i32 0, i32 1
  %t963 = load i32, ptr %t962
  %t965 = trunc i64 0 to i32
  %t966 = icmp eq i32 %t963, %t965
  br i1 %t966, label %bb231, label %bb232
bb230:
  store i1 false, ptr %l434, !tbaa !21
  br label %bb234
bb231:
  store i1 true, ptr %l437, !tbaa !21
  br label %bb233
bb232:
  %t968 = getelementptr %"compiler/emit:Object", ptr %l34, i32 0, i32 1
  %t969 = load i32, ptr %t968
  %t971 = trunc i64 4 to i32
  %t972 = icmp eq i32 %t969, %t971
  store i1 %t972, ptr %l437, !tbaa !21
  br label %bb233
bb233:
  %t974 = load i1, ptr %l437, !tbaa !21
  store i1 %t974, ptr %l434, !tbaa !21
  br label %bb234
bb234:
  %t975 = load i1, ptr %l434, !tbaa !21
  br i1 %t975, label %bb235, label %bb236
bb235:
  %t976 = load ptr, ptr %l46, !tbaa !29
  store ptr %t976, ptr %l440, !tbaa !29
  %t977 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t979 = call { i64, ptr } @compiler_2fbuild_2eIrHash(ptr %v3, ptr %v3, { i64, ptr } %t977)
  store { i64, ptr } %t979, ptr %l442
  br label %bb237
bb236:
  br label %bb238
bb237:
  %t980 = load { i64, ptr }, ptr %l442, !tbaa !27
  %t981 = extractvalue { i64, ptr } %t980, 0
  %t982 = extractvalue { i64, ptr } %t980, 1
  %t983 = mul i64 %t981, 1
  %t984 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t983)
  call void @llvm.memcpy.p0.p0.i64(ptr %t984, ptr %t982, i64 %t983, i1 false)
  %t985 = insertvalue { i64, ptr } undef, i64 %t981, 0
  %t986 = insertvalue { i64, ptr } %t985, ptr %t984, 1
  %t988 = load ptr, ptr %l440, !tbaa !29
  %t989 = getelementptr %"compiler/build:Unit", ptr %t988, i32 0, i32 3
  store { i64, ptr } %t986, ptr %t989, !tbaa !27
  br label %bb238
bb238:
  %t990 = load ptr, ptr %l46, !tbaa !29
  %t992 = getelementptr %"compiler/build:Unit", ptr %t990, i32 0, i32 3
  %t993 = load { i64, ptr }, ptr %t992, !tbaa !27
  %t995 = extractvalue { i64, ptr } %t993, 1
  %t996 = extractvalue { i64, ptr } %t993, 0
  %t997 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t996)
  call void @olang_textcopy(ptr %t997, ptr %t995, i64 %t996)
  %t998 = insertvalue { i64, ptr } undef, i64 %t996, 0
  %t999 = insertvalue { i64, ptr } %t998, ptr %t997, 1
  %t1001 = extractvalue { i64, ptr } %t999, 0
  %t1002 = extractvalue { i64, ptr } %t999, 1
  %t1003 = mul i64 %t1001, 1
  %t1004 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1003)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1004, ptr %t1002, i64 %t1003, i1 false)
  %t1005 = insertvalue { i64, ptr } undef, i64 %t1001, 0
  %t1006 = insertvalue { i64, ptr } %t1005, ptr %t1004, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l31, { i64, ptr } %t1006)
  br label %bb239
bb239:
  %t1009 = load ptr, ptr %l4, !tbaa !29
  %t1011 = getelementptr %"compiler/build:Program", ptr %t1009, i32 0, i32 0
  %t1012 = load ptr, ptr %l46, !tbaa !29
  %t1014 = load %"compiler/build:Unit", ptr %t1012
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2ePush_3ccompiler_2fbuild_3aUnit_3e(ptr %v3, ptr %v3, ptr %t1011, %"compiler/build:Unit" %t1014)
  br label %bb240
bb240:
  call void @__olang_scope_close(ptr %s37)
  br label %bb241
bb241:
  %t1017 = load i64, ptr %l33, !tbaa !24
  %t1019 = add i64 %t1017, 1
  store i64 %t1019, ptr %l33, !tbaa !24
  br label %bb158
bb242:
  %t1021 = load i32, ptr %l2
  %t1023 = trunc i64 0 to i32
  %t1024 = icmp eq i32 %t1021, %t1023
  %t1026 = xor i1 %t1024, true
  br i1 %t1026, label %bb243, label %bb244
bb243:
  %t1028 = load ptr, ptr %l7, !tbaa !29
  %t1029 = load ptr, ptr %l3, !tbaa !29
  %t1030 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t1031 = load ptr, ptr %l17, !tbaa !29
  %t1033 = getelementptr %"compiler/emit:Emitter", ptr %t1031, i32 0, i32 68
  call void @compiler_2folang_2ekeep(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v3, ptr %s0, ptr %t1028, ptr %t1029, { i64, ptr } %t1030, ptr %t1033, ptr %l19, ptr %l31)
  br label %bb245
bb244:
  br label %bb246
bb245:
  br label %bb246
bb246:
  %t1040 = load ptr, ptr %l7, !tbaa !29
  %t1042 = getelementptr %"compiler/load:Loader", ptr %t1040, i32 0, i32 5
  store ptr %t1042, ptr %l47, !tbaa !29
  store i64 0, ptr %l48, !tbaa !24
  br label %bb247
bb247:
  store %olang.scope zeroinitializer, ptr %s62
  %t1044 = load i64, ptr %l48, !tbaa !24
  store i64 %t1044, ptr %l467, !tbaa !24
  %t1045 = load ptr, ptr %l47, !tbaa !29
  %t1047 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v2, ptr %t1045)
  store i64 %t1047, ptr %l469
  br label %bb248
bb248:
  %t1048 = load i64, ptr %l467, !tbaa !24
  %t1049 = load i64, ptr %l469, !tbaa !24
  %t1050 = icmp slt i64 %t1048, %t1049
  %t1052 = xor i1 %t1050, true
  br i1 %t1052, label %bb249, label %bb250
bb249:
  call void @__olang_scope_close(ptr %s62)
  br label %bb271
bb250:
  br label %bb251
bb251:
  %t1054 = load ptr, ptr %l47, !tbaa !29
  %t1055 = load i64, ptr %l48, !tbaa !24
  %t1058 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v2, ptr %v2, ptr %t1054, i64 %t1055)
  store ptr %t1058, ptr %l474
  br label %bb252
bb252:
  %t1059 = load ptr, ptr %l474, !tbaa !29
  store ptr %t1059, ptr %l49, !tbaa !29
  %t1060 = load ptr, ptr %l49, !tbaa !29
  %t1062 = getelementptr %"compiler/load:Module", ptr %t1060, i32 0, i32 31
  %t1063 = load { i64, ptr }, ptr %t1062, !tbaa !27
  %t1065 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s62, { i64, ptr } %t1063, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d185, i32 0, i32 1) })
  store i1 %t1065, ptr %l477
  br label %bb253
bb253:
  %t1066 = load i1, ptr %l477, !tbaa !21
  br i1 %t1066, label %bb254, label %bb255
bb254:
  call void @__olang_scope_close(ptr %s62)
  br label %bb270
bb255:
  br label %bb256
bb256:
  %t1067 = load ptr, ptr %l49, !tbaa !29
  %t1069 = getelementptr %"compiler/load:Module", ptr %t1067, i32 0, i32 31
  %t1070 = load { i64, ptr }, ptr %t1069, !tbaa !27
  %t1072 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v2, ptr %s62, { i64, ptr } %t1070)
  %t1073 = extractvalue { i32, { i64, ptr } } %t1072, 1
  %t1074 = extractvalue { i32, { i64, ptr } } %t1072, 0
  store i32 %t1074, ptr %l482
  %t1075 = icmp ne i32 %t1074, 0
  br i1 %t1075, label %bb258, label %ok.1076
ok.1076:
  store { i64, ptr } %t1073, ptr %l481
  br label %bb257
bb257:
  %t1077 = load { i64, ptr }, ptr %l481, !tbaa !27
  store { i64, ptr } %t1077, ptr %l478, !tbaa !27
  br label %bb261
bb258:
  %t1078 = load i32, ptr %l482, !tbaa !23
  %t1079 = ashr i32 %t1078, 16
  %t1081 = icmp eq i32 %t1079, 1
  store i1 %t1081, ptr %l484, !tbaa !21
  br label %bb259
bb259:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s64
  %t1082 = load ptr, ptr %l49, !tbaa !29
  %t1084 = getelementptr %"compiler/load:Module", ptr %t1082, i32 0, i32 31
  %t1085 = load { i64, ptr }, ptr %t1084, !tbaa !27
  %t1086 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d186, i32 0, i32 1) }, 1
  %t1087 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d186, i32 0, i32 1) }, 0
  %t1089 = extractvalue { i64, ptr } %t1085, 1
  %t1090 = extractvalue { i64, ptr } %t1085, 0
  %t1091 = add i64 %t1087, %t1090
  %t1092 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d187, i32 0, i32 1) }, 1
  %t1093 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d187, i32 0, i32 1) }, 0
  %t1094 = add i64 %t1091, %t1093
  %t1095 = call ptr @__olang_scope_alloc(ptr %s64, i64 %t1094)
  call void @olang_textcopy(ptr %t1095, ptr %t1086, i64 %t1087)
  %t1096 = getelementptr i8, ptr %t1095, i64 %t1087
  call void @olang_textcopy(ptr %t1096, ptr %t1089, i64 %t1090)
  %t1097 = getelementptr i8, ptr %t1096, i64 %t1090
  call void @olang_textcopy(ptr %t1097, ptr %t1092, i64 %t1093)
  %t1098 = insertvalue { i64, ptr } undef, i64 %t1094, 0
  %t1099 = insertvalue { i64, ptr } %t1098, ptr %t1095, 1
  %t1101 = extractvalue { i64, ptr } %t1099, 0
  %t1102 = extractvalue { i64, ptr } %t1099, 1
  %t1103 = mul i64 %t1101, 1
  %t1104 = call ptr @__olang_scope_alloc(ptr %s64, i64 %t1103)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1104, ptr %t1102, i64 %t1103, i1 false)
  %t1105 = insertvalue { i64, ptr } undef, i64 %t1101, 0
  %t1106 = insertvalue { i64, ptr } %t1105, ptr %t1104, 1
  call void @compiler_2fbuild_2eUnbuildable(ptr %s64, { i64, ptr } %t1106)
  br label %bb260
bb260:
  call void @__olang_scope_close(ptr %s64)
  call void @__olang_scope_close(ptr %s62)
  call void @__olang_scope_close(ptr %s0)
  store i32 65537, ptr %rv
  br label %ret
bb261:
  %t1109 = load { i64, ptr }, ptr %l478, !tbaa !27
  %t1110 = load ptr, ptr %l49, !tbaa !29
  %t1112 = getelementptr %"compiler/load:Module", ptr %t1110, i32 0, i32 31
  %t1113 = load { i64, ptr }, ptr %t1112, !tbaa !27
  %t1115 = load ptr, ptr %l3, !tbaa !29
  %t1119 = call { i64, ptr } @compiler_2folang_2ecIr(ptr %v2, ptr %s62, ptr %v2, ptr %v3, { i64, ptr } %t1113, { i64, ptr } %t1109, ptr %t1115)
  store { i64, ptr } %t1119, ptr %l494
  br label %bb262
bb262:
  %t1120 = load { i64, ptr }, ptr %l494, !tbaa !27
  %t1121 = extractvalue { i64, ptr } %t1120, 0
  store i64 %t1121, ptr %l495, !tbaa !24
  %t1122 = load i64, ptr %l495, !tbaa !24
  %t1123 = mul i64 %t1122, 1
  %t1124 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t1123)
  %t1125 = insertvalue { i64, ptr } undef, i64 %t1122, 0
  %t1126 = insertvalue { i64, ptr } %t1125, ptr %t1124, 1
  store { i64, ptr } %t1126, ptr %l496, !tbaa !27
  %t1127 = getelementptr { i64, ptr }, ptr %l496, i32 0, i32 1
  %t1128 = load ptr, ptr %t1127, !tbaa !27
  %t1129 = getelementptr { i64, ptr }, ptr %l494, i32 0, i32 1
  %t1130 = load ptr, ptr %t1129, !tbaa !27
  %t1131 = load i64, ptr %l495, !tbaa !24
  %t1132 = mul i64 %t1131, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1128, ptr %t1130, i64 %t1132, i1 false)
  %t1133 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 16, i64 8)
  store ptr %t1133, ptr %lp51
  %t1134 = load { i64, ptr }, ptr %l496, !tbaa !27
  %t1135 = load ptr, ptr %lp51
  store { i64, ptr } %t1134, ptr %t1135, !tbaa !27
  %t1136 = load ptr, ptr %lp51
  %t1137 = load { i64, ptr }, ptr %t1136, !tbaa !27
  %t1139 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s62, { i64, ptr } %t1137, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d188, i32 0, i32 1) })
  store i1 %t1139, ptr %l498
  br label %bb263
bb263:
  %t1140 = load i1, ptr %l498, !tbaa !21
  br i1 %t1140, label %bb264, label %bb265
bb264:
  store %olang.scope zeroinitializer, ptr %s66
  %t1141 = load ptr, ptr %l49, !tbaa !29
  %t1143 = getelementptr %"compiler/load:Module", ptr %t1141, i32 0, i32 31
  %t1144 = load { i64, ptr }, ptr %t1143, !tbaa !27
  %t1145 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d189, i32 0, i32 1) }, 1
  %t1146 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d189, i32 0, i32 1) }, 0
  %t1148 = extractvalue { i64, ptr } %t1144, 1
  %t1149 = extractvalue { i64, ptr } %t1144, 0
  %t1150 = add i64 %t1146, %t1149
  %t1151 = call ptr @__olang_scope_alloc(ptr %s66, i64 %t1150)
  call void @olang_textcopy(ptr %t1151, ptr %t1145, i64 %t1146)
  %t1152 = getelementptr i8, ptr %t1151, i64 %t1146
  call void @olang_textcopy(ptr %t1152, ptr %t1148, i64 %t1149)
  %t1153 = insertvalue { i64, ptr } undef, i64 %t1150, 0
  %t1154 = insertvalue { i64, ptr } %t1153, ptr %t1151, 1
  %t1156 = extractvalue { i64, ptr } %t1154, 0
  %t1157 = extractvalue { i64, ptr } %t1154, 1
  %t1158 = mul i64 %t1156, 1
  %t1159 = call ptr @__olang_scope_alloc(ptr %s66, i64 %t1158)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1159, ptr %t1157, i64 %t1158, i1 false)
  %t1160 = insertvalue { i64, ptr } undef, i64 %t1156, 0
  %t1161 = insertvalue { i64, ptr } %t1160, ptr %t1159, 1
  call void @compiler_2fbuild_2eUnbuildable(ptr %s66, { i64, ptr } %t1161)
  br label %bb266
bb265:
  br label %bb267
bb266:
  call void @__olang_scope_close(ptr %s66)
  call void @__olang_scope_close(ptr %s62)
  call void @__olang_scope_close(ptr %s0)
  store i32 65537, ptr %rv
  br label %ret
bb267:
  %t1164 = load ptr, ptr %l4, !tbaa !29
  %t1166 = getelementptr %"compiler/build:Program", ptr %t1164, i32 0, i32 0
  store ptr %t1166, ptr %l505, !tbaa !29
  %t1167 = load ptr, ptr %l49, !tbaa !29
  %t1169 = getelementptr %"compiler/load:Module", ptr %t1167, i32 0, i32 2
  %t1170 = load { i64, ptr }, ptr %t1169, !tbaa !27
  %t1171 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d190, i32 0, i32 1) }, 1
  %t1172 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d190, i32 0, i32 1) }, 0
  %t1174 = extractvalue { i64, ptr } %t1170, 1
  %t1175 = extractvalue { i64, ptr } %t1170, 0
  %t1176 = add i64 %t1172, %t1175
  %t1177 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t1176)
  call void @olang_textcopy(ptr %t1177, ptr %t1171, i64 %t1172)
  %t1178 = getelementptr i8, ptr %t1177, i64 %t1172
  call void @olang_textcopy(ptr %t1178, ptr %t1174, i64 %t1175)
  %t1179 = insertvalue { i64, ptr } undef, i64 %t1176, 0
  %t1180 = insertvalue { i64, ptr } %t1179, ptr %t1177, 1
  %t1182 = extractvalue { i64, ptr } %t1180, 0
  %t1183 = extractvalue { i64, ptr } %t1180, 1
  %t1184 = mul i64 %t1182, 1
  %t1185 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t1184)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1185, ptr %t1183, i64 %t1184, i1 false)
  %t1186 = insertvalue { i64, ptr } undef, i64 %t1182, 0
  %t1187 = insertvalue { i64, ptr } %t1186, ptr %t1185, 1
  %t1188 = load ptr, ptr %lp51
  %t1189 = load { i64, ptr }, ptr %t1188, !tbaa !27
  %t1193 = call %"compiler/build:Unit" @compiler_2fbuild_3aUnit_2ector(ptr %v3, ptr %v3, ptr %v3, { i64, ptr } %t1187, i32 0, { i64, ptr } %t1189)
  store %"compiler/build:Unit" %t1193, ptr %l512
  br label %bb268
bb268:
  %t1194 = load ptr, ptr %l505, !tbaa !29
  %t1195 = load %"compiler/build:Unit", ptr %l512
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2ePush_3ccompiler_2fbuild_3aUnit_3e(ptr %v3, ptr %v3, ptr %t1194, %"compiler/build:Unit" %t1195)
  br label %bb269
bb269:
  call void @__olang_scope_close(ptr %s62)
  br label %bb270
bb270:
  %t1196 = load i64, ptr %l48, !tbaa !24
  %t1198 = add i64 %t1196, 1
  store i64 %t1198, ptr %l48, !tbaa !24
  br label %bb247
bb271:
  %t1200 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d191, i32 0, i32 1) })
  %t1201 = extractvalue { i32, { i64, ptr } } %t1200, 1
  %t1202 = extractvalue { i32, { i64, ptr } } %t1200, 0
  store i32 %t1202, ptr %l517
  %t1203 = icmp ne i32 %t1202, 0
  br i1 %t1203, label %bb273, label %ok.1204
ok.1204:
  store { i64, ptr } %t1201, ptr %l516
  br label %bb272
bb272:
  %t1205 = load { i64, ptr }, ptr %l516, !tbaa !27
  store { i64, ptr } %t1205, ptr %l515, !tbaa !27
  br label %bb275
bb273:
  br label %bb274
bb274:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d192, i32 0, i32 1) }, ptr %l518, !tbaa !27
  %t1206 = load { i64, ptr }, ptr %l518, !tbaa !27
  %t1208 = extractvalue { i64, ptr } %t1206, 0
  %t1209 = extractvalue { i64, ptr } %t1206, 1
  %t1210 = mul i64 %t1208, 1
  %t1211 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1210)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1211, ptr %t1209, i64 %t1210, i1 false)
  %t1212 = insertvalue { i64, ptr } undef, i64 %t1208, 0
  %t1213 = insertvalue { i64, ptr } %t1212, ptr %t1211, 1
  store { i64, ptr } %t1213, ptr %l515, !tbaa !27
  br label %bb275
bb275:
  %t1215 = load { i64, ptr }, ptr %l515, !tbaa !27
  %t1216 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t1215, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d193, i32 0, i32 1) })
  store i1 %t1216, ptr %l521
  br label %bb276
bb276:
  %t1217 = load i1, ptr %l521, !tbaa !21
  %t1218 = xor i1 %t1217, true
  br i1 %t1218, label %bb277, label %bb278
bb277:
  %t1220 = load ptr, ptr %l17, !tbaa !29
  %t1221 = load ptr, ptr %l4, !tbaa !29
  %t1222 = load ptr, ptr %l8, !tbaa !29
  %t1223 = load ptr, ptr %l15, !tbaa !29
  %t1224 = load ptr, ptr %l5, !tbaa !29
  %t1225 = load ptr, ptr %l3, !tbaa !29
  %t1226 = load i32, ptr %l2
  %t1227 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2folang_2echeckReuse(ptr %v2, ptr %v3, ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %t1220, ptr %t1221, ptr %t1222, ptr %t1223, ptr %t1224, ptr %t1225, i32 %t1226, ptr %t1227)
  br label %bb279
bb278:
  br label %bb280
bb279:
  br label %bb280
bb280:
  %t1236 = load ptr, ptr %l4, !tbaa !29
  store ptr %t1236, ptr %l531, !tbaa !29
  %t1237 = load ptr, ptr %l7, !tbaa !29
  %t1239 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fload_2ecompiler_2fload_3aLoader_2eLinks(ptr %v2, ptr %v3, ptr %t1237)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1239, ptr %l533
  br label %bb281
bb281:
  %t1240 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l533
  %t1241 = load ptr, ptr %l531, !tbaa !29
  %t1242 = getelementptr %"compiler/build:Program", ptr %t1241, i32 0, i32 3
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1240, ptr %t1242
  %t1243 = load ptr, ptr %l5, !tbaa !29
  %t1245 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v2, ptr %t1243)
  store i64 %t1245, ptr %l535
  br label %bb282
bb282:
  %t1246 = load i64, ptr %l535, !tbaa !24
  %t1247 = icmp sgt i64 %t1246, 0
  br i1 %t1247, label %bb283, label %bb284
bb283:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb284:
  br label %bb285
bb285:
  %t1250 = load ptr, ptr %l17, !tbaa !29
  %t1252 = getelementptr %"compiler/emit:Emitter", ptr %t1250, i32 0, i32 6
  %t1253 = load i1, ptr %t1252, !tbaa !21
  br i1 %t1253, label %bb286, label %bb287
bb286:
  store %olang.scope zeroinitializer, ptr %s73
  %t1255 = load ptr, ptr %l17, !tbaa !29
  %t1257 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2ecompiler_2femit_3aEmitter_2eExportNames(ptr %v2, ptr %s73, ptr %t1255)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1257, ptr %l541
  br label %bb288
bb287:
  br label %bb300
bb288:
  %t1258 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l541
  %t1259 = call ptr @__olang_scope_alloc_a(ptr %s73, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1258, ptr %t1259
  store ptr %t1259, ptr %l52, !tbaa !29
  store i64 0, ptr %l53, !tbaa !24
  br label %bb289
bb289:
  %t1261 = load i64, ptr %l53, !tbaa !24
  store i64 %t1261, ptr %l543, !tbaa !24
  %t1262 = load ptr, ptr %l52, !tbaa !29
  %t1264 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s73, ptr %t1262)
  store i64 %t1264, ptr %l545
  br label %bb290
bb290:
  %t1265 = load i64, ptr %l543, !tbaa !24
  %t1266 = load i64, ptr %l545, !tbaa !24
  %t1267 = icmp slt i64 %t1265, %t1266
  %t1269 = xor i1 %t1267, true
  br i1 %t1269, label %bb291, label %bb292
bb291:
  br label %bb297
bb292:
  br label %bb293
bb293:
  %t1271 = load ptr, ptr %l52, !tbaa !29
  %t1272 = load i64, ptr %l53, !tbaa !24
  %t1275 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s73, ptr %s73, ptr %t1271, i64 %t1272)
  store { i64, ptr } %t1275, ptr %l550
  br label %bb294
bb294:
  %t1276 = load { i64, ptr }, ptr %l550, !tbaa !27
  %t1277 = load ptr, ptr %l4, !tbaa !29
  %t1279 = getelementptr %"compiler/build:Program", ptr %t1277, i32 0, i32 4
  %t1282 = extractvalue { i64, ptr } %t1276, 1
  %t1283 = extractvalue { i64, ptr } %t1276, 0
  %t1284 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t1283)
  call void @olang_textcopy(ptr %t1284, ptr %t1282, i64 %t1283)
  %t1285 = insertvalue { i64, ptr } undef, i64 %t1283, 0
  %t1286 = insertvalue { i64, ptr } %t1285, ptr %t1284, 1
  %t1288 = extractvalue { i64, ptr } %t1286, 0
  %t1289 = extractvalue { i64, ptr } %t1286, 1
  %t1290 = mul i64 %t1288, 1
  %t1291 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t1290)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1291, ptr %t1289, i64 %t1290, i1 false)
  %t1292 = insertvalue { i64, ptr } undef, i64 %t1288, 0
  %t1293 = insertvalue { i64, ptr } %t1292, ptr %t1291, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v3, ptr %v3, ptr %t1279, { i64, ptr } %t1293)
  br label %bb295
bb295:
  br label %bb296
bb296:
  %t1296 = load i64, ptr %l53, !tbaa !24
  %t1298 = add i64 %t1296, 1
  store i64 %t1298, ptr %l53, !tbaa !24
  br label %bb289
bb297:
  call void @__olang_scope_close(ptr %s73)
  %t1300 = load ptr, ptr %l4, !tbaa !29
  store ptr %t1300, ptr %l558, !tbaa !29
  %t1301 = load ptr, ptr %l17, !tbaa !29
  store ptr %t1301, ptr %l559, !tbaa !29
  %t1302 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t1304 = call { i64, ptr } @compiler_2fbuild_2eLibName(ptr %v1, ptr %v3, { i64, ptr } %t1302)
  store { i64, ptr } %t1304, ptr %l561
  br label %bb298
bb298:
  %t1305 = load { i64, ptr }, ptr %l561, !tbaa !27
  %t1306 = extractvalue { i64, ptr } %t1305, 0
  %t1307 = extractvalue { i64, ptr } %t1305, 1
  %t1308 = mul i64 %t1306, 1
  %t1309 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t1308)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1309, ptr %t1307, i64 %t1308, i1 false)
  %t1310 = insertvalue { i64, ptr } undef, i64 %t1306, 0
  %t1311 = insertvalue { i64, ptr } %t1310, ptr %t1309, 1
  %t1312 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t1313 = load ptr, ptr %l559, !tbaa !29
  %t1316 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eHeader(ptr %v2, ptr %v3, ptr %v1, ptr %v3, ptr %t1313, { i64, ptr } %t1311, { i64, ptr } %t1312)
  store { i64, ptr } %t1316, ptr %l564
  br label %bb299
bb299:
  %t1317 = load { i64, ptr }, ptr %l564, !tbaa !27
  %t1318 = extractvalue { i64, ptr } %t1317, 0
  %t1319 = extractvalue { i64, ptr } %t1317, 1
  %t1320 = mul i64 %t1318, 1
  %t1321 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t1320)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1321, ptr %t1319, i64 %t1320, i1 false)
  %t1322 = insertvalue { i64, ptr } undef, i64 %t1318, 0
  %t1323 = insertvalue { i64, ptr } %t1322, ptr %t1321, 1
  %t1325 = load ptr, ptr %l558, !tbaa !29
  %t1326 = getelementptr %"compiler/build:Program", ptr %t1325, i32 0, i32 5
  store { i64, ptr } %t1323, ptr %t1326, !tbaa !27
  br label %bb300
bb300:
  %t1327 = load ptr, ptr %l4, !tbaa !29
  store ptr %t1327, ptr %l566, !tbaa !29
  %t1328 = getelementptr %"compiler/target:Target", ptr %l29, i32 0, i32 1
  %t1329 = load { i64, ptr }, ptr %t1328, !tbaa !27
  %t1330 = getelementptr %"compiler/target:Target", ptr %l29, i32 0, i32 2
  %t1331 = load { i64, ptr }, ptr %t1330, !tbaa !27
  %t1332 = getelementptr %"compiler/target:Target", ptr %l29, i32 0, i32 5
  %t1333 = load { i64, ptr }, ptr %t1332, !tbaa !27
  %t1334 = load ptr, ptr %l3, !tbaa !29
  %t1336 = getelementptr %"compiler/build:Config", ptr %t1334, i32 0, i32 7
  %t1337 = load i1, ptr %t1336, !tbaa !21
  %t1338 = load ptr, ptr %l3, !tbaa !29
  %t1340 = getelementptr %"compiler/build:Config", ptr %t1338, i32 0, i32 6
  %t1341 = load i1, ptr %t1340, !tbaa !21
  %t1347 = call { i32, { i64, ptr } } @compiler_2fruntime_2eIr(ptr %v2, ptr %v2, ptr %v2, ptr %v3, { i64, ptr } %t1329, { i64, ptr } %t1331, { i64, ptr } %t1333, i1 %t1337, i1 %t1341)
  %t1348 = extractvalue { i32, { i64, ptr } } %t1347, 1
  %t1349 = extractvalue { i32, { i64, ptr } } %t1347, 0
  store i32 %t1349, ptr %l576
  %t1350 = icmp ne i32 %t1349, 0
  br i1 %t1350, label %bb302, label %ok.1351
ok.1351:
  store { i64, ptr } %t1348, ptr %l575
  br label %bb301
bb301:
  %t1352 = load { i64, ptr }, ptr %l575, !tbaa !27
  store { i64, ptr } %t1352, ptr %l567, !tbaa !27
  br label %bb304
bb302:
  %t1353 = load i32, ptr %l576, !tbaa !23
  %t1354 = ashr i32 %t1353, 16
  %t1356 = icmp eq i32 %t1354, 1
  store i1 %t1356, ptr %l578, !tbaa !21
  br label %bb303
bb303:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb304:
  %t1358 = load { i64, ptr }, ptr %l567, !tbaa !27
  %t1359 = extractvalue { i64, ptr } %t1358, 0
  %t1360 = extractvalue { i64, ptr } %t1358, 1
  %t1361 = mul i64 %t1359, 1
  %t1362 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t1361)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1362, ptr %t1360, i64 %t1361, i1 false)
  %t1363 = insertvalue { i64, ptr } undef, i64 %t1359, 0
  %t1364 = insertvalue { i64, ptr } %t1363, ptr %t1362, 1
  %t1366 = load ptr, ptr %l566, !tbaa !29
  %t1367 = getelementptr %"compiler/build:Program", ptr %t1366, i32 0, i32 1
  store { i64, ptr } %t1364, ptr %t1367, !tbaa !27
  %t1368 = load ptr, ptr %l17, !tbaa !29
  %t1370 = getelementptr %"compiler/emit:Emitter", ptr %t1368, i32 0, i32 6
  %t1371 = load i1, ptr %t1370, !tbaa !21
  br i1 %t1371, label %bb305, label %bb306
bb305:
  %t1373 = load ptr, ptr %l4, !tbaa !29
  store ptr %t1373, ptr %l583, !tbaa !29
  %t1374 = load ptr, ptr %l4, !tbaa !29
  %t1376 = getelementptr %"compiler/build:Program", ptr %t1374, i32 0, i32 1
  %t1377 = load { i64, ptr }, ptr %t1376, !tbaa !27
  %t1379 = call { i64, ptr } @compiler_2folang_2elibraryIr(ptr %v3, ptr %v3, { i64, ptr } %t1377)
  store { i64, ptr } %t1379, ptr %l586
  br label %bb307
bb306:
  br label %bb308
bb307:
  %t1380 = load { i64, ptr }, ptr %l586, !tbaa !27
  %t1381 = extractvalue { i64, ptr } %t1380, 0
  %t1382 = extractvalue { i64, ptr } %t1380, 1
  %t1383 = mul i64 %t1381, 1
  %t1384 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t1383)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1384, ptr %t1382, i64 %t1383, i1 false)
  %t1385 = insertvalue { i64, ptr } undef, i64 %t1381, 0
  %t1386 = insertvalue { i64, ptr } %t1385, ptr %t1384, 1
  %t1388 = load ptr, ptr %l583, !tbaa !29
  %t1389 = getelementptr %"compiler/build:Program", ptr %t1388, i32 0, i32 1
  store { i64, ptr } %t1386, ptr %t1389, !tbaa !27
  br label %bb308
bb308:
  %t1390 = load i1, ptr %l30, !tbaa !21
  br i1 %t1390, label %bb309, label %bb310
bb309:
  %t1392 = load ptr, ptr %l4, !tbaa !29
  store ptr %t1392, ptr %l589, !tbaa !29
  %t1393 = getelementptr %"compiler/target:Target", ptr %l29, i32 0, i32 1
  %t1394 = load { i64, ptr }, ptr %t1393, !tbaa !27
  %t1395 = getelementptr %"compiler/target:Target", ptr %l29, i32 0, i32 2
  %t1396 = load { i64, ptr }, ptr %t1395, !tbaa !27
  %t1397 = getelementptr %"compiler/target:Target", ptr %l29, i32 0, i32 5
  %t1398 = load { i64, ptr }, ptr %t1397, !tbaa !27
  %t1399 = load ptr, ptr %l3, !tbaa !29
  %t1401 = getelementptr %"compiler/build:Config", ptr %t1399, i32 0, i32 7
  %t1402 = load i1, ptr %t1401, !tbaa !21
  %t1403 = load ptr, ptr %l3, !tbaa !29
  %t1405 = getelementptr %"compiler/build:Config", ptr %t1403, i32 0, i32 6
  %t1406 = load i1, ptr %t1405, !tbaa !21
  %t1412 = call { i32, { i64, ptr } } @compiler_2fruntime_2eDyncallIr(ptr %v2, ptr %v2, ptr %v2, ptr %v3, { i64, ptr } %t1394, { i64, ptr } %t1396, { i64, ptr } %t1398, i1 %t1402, i1 %t1406)
  %t1413 = extractvalue { i32, { i64, ptr } } %t1412, 1
  %t1414 = extractvalue { i32, { i64, ptr } } %t1412, 0
  store i32 %t1414, ptr %l599
  %t1415 = icmp ne i32 %t1414, 0
  br i1 %t1415, label %bb312, label %ok.1416
ok.1416:
  store { i64, ptr } %t1413, ptr %l598
  br label %bb311
bb310:
  br label %bb319
bb311:
  %t1417 = load { i64, ptr }, ptr %l598, !tbaa !27
  store { i64, ptr } %t1417, ptr %l590, !tbaa !27
  br label %bb314
bb312:
  %t1418 = load i32, ptr %l599, !tbaa !23
  %t1419 = ashr i32 %t1418, 16
  %t1421 = icmp eq i32 %t1419, 1
  store i1 %t1421, ptr %l601, !tbaa !21
  br label %bb313
bb313:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb314:
  %t1423 = load { i64, ptr }, ptr %l590, !tbaa !27
  %t1424 = extractvalue { i64, ptr } %t1423, 0
  %t1425 = extractvalue { i64, ptr } %t1423, 1
  %t1426 = mul i64 %t1424, 1
  %t1427 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t1426)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1427, ptr %t1425, i64 %t1426, i1 false)
  %t1428 = insertvalue { i64, ptr } undef, i64 %t1424, 0
  %t1429 = insertvalue { i64, ptr } %t1428, ptr %t1427, 1
  %t1431 = load ptr, ptr %l589, !tbaa !29
  %t1432 = getelementptr %"compiler/build:Program", ptr %t1431, i32 0, i32 2
  store { i64, ptr } %t1429, ptr %t1432, !tbaa !27
  %t1433 = load ptr, ptr %l17, !tbaa !29
  %t1435 = getelementptr %"compiler/emit:Emitter", ptr %t1433, i32 0, i32 6
  %t1436 = load i1, ptr %t1435, !tbaa !21
  br i1 %t1436, label %bb315, label %bb316
bb315:
  %t1438 = load ptr, ptr %l4, !tbaa !29
  store ptr %t1438, ptr %l606, !tbaa !29
  %t1439 = load ptr, ptr %l4, !tbaa !29
  %t1441 = getelementptr %"compiler/build:Program", ptr %t1439, i32 0, i32 2
  %t1442 = load { i64, ptr }, ptr %t1441, !tbaa !27
  %t1444 = call { i64, ptr } @compiler_2folang_2elibraryIr(ptr %v3, ptr %v3, { i64, ptr } %t1442)
  store { i64, ptr } %t1444, ptr %l609
  br label %bb317
bb316:
  br label %bb318
bb317:
  %t1445 = load { i64, ptr }, ptr %l609, !tbaa !27
  %t1446 = extractvalue { i64, ptr } %t1445, 0
  %t1447 = extractvalue { i64, ptr } %t1445, 1
  %t1448 = mul i64 %t1446, 1
  %t1449 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t1448)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1449, ptr %t1447, i64 %t1448, i1 false)
  %t1450 = insertvalue { i64, ptr } undef, i64 %t1446, 0
  %t1451 = insertvalue { i64, ptr } %t1450, ptr %t1449, 1
  %t1453 = load ptr, ptr %l606, !tbaa !29
  %t1454 = getelementptr %"compiler/build:Program", ptr %t1453, i32 0, i32 2
  store { i64, ptr } %t1451, ptr %t1454, !tbaa !27
  br label %bb318
bb318:
  br label %bb319
bb319:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2folang_2ecompiler_2folang_3aPasses_2eExplain(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca ptr
  %lp11 = alloca ptr
  %l12 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i32
  %l21 = alloca %"compiler/check:Checker"
  %l23 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l26 = alloca i64
  %l30 = alloca i64
  %l33 = alloca i64
  %l36 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l38 = alloca i64
  %l45 = alloca %"compiler/scope:Scoper"
  %l55 = alloca i64
  %l63 = alloca %"compiler/interp:Exec"
  %l68 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %l76 = alloca i32
  %l78 = alloca i1
  %l79 = alloca ptr
  %l80 = alloca { i64, [3 x i64] }
  %l83 = alloca %"compiler/msgs:Msg"
  %l84 = alloca i64
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  %t28 = alloca %"compiler/check:Checker", align 8
  %t73 = alloca %"compiler/scope:Scoper", align 8
  %t122 = alloca %"compiler/interp:Exec", align 8
  %t160 = alloca { i64, [3 x i64] }, align 8
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t4 = load ptr, ptr %l4, !tbaa !29
  %t9 = call { i32, ptr } @compiler_2folang_2ecompiler_2folang_3aPasses_2eload(ptr %v0, ptr %v1, ptr %v3, ptr %a0, { i64, ptr } %t2, ptr %a3, ptr %t4)
  %t10 = extractvalue { i32, ptr } %t9, 1
  %t11 = extractvalue { i32, ptr } %t9, 0
  store i32 %t11, ptr %l18
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb2, label %ok.13
ok.13:
  store ptr %t10, ptr %l17
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l17, !tbaa !29
  store ptr %t14, ptr %l12, !tbaa !29
  br label %bb3
bb2:
  %t15 = load i32, ptr %l18, !tbaa !23
  %t16 = lshr i32 %t15, 16
  %t17 = and i32 %t15, 65535
  %t18 = icmp eq i32 %t16, 1
  %t19 = select i1 %t18, i32 1, i32 0
  %t20 = icmp eq i32 %t15, 0
  %t21 = shl i32 %t19, 16
  %t22 = or i32 %t21, %t17
  %t23 = select i1 %t20, i32 0, i32 %t22
  %t25 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t23, 0
  store { i32, { i64, ptr } } %t25, ptr %rv
  br label %ret
bb3:
  %t26 = load ptr, ptr %l12, !tbaa !29
  store ptr %t26, ptr %l5, !tbaa !29
  %t27 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2finterp_2eAnalyze(ptr %t28, ptr %v3, ptr %v3, ptr %t27, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l21, ptr %t28, i64 888, i1 false)
  br label %bb4
bb4:
  %t30 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 888, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %l21, i64 888, i1 false)
  store ptr %t30, ptr %l6, !tbaa !29
  %t32 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v3)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t32, ptr %l23
  br label %bb5
bb5:
  %t33 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l23
  %t34 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 8, i64 8)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t33, ptr %t34
  store ptr %t34, ptr %l7, !tbaa !29
  %t36 = load ptr, ptr %l4, !tbaa !29
  %t38 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v3, ptr %t36)
  store i64 %t38, ptr %l26
  br label %bb6
bb6:
  %t39 = load i64, ptr %l26, !tbaa !24
  %t40 = icmp eq i64 %t39, 0
  store i1 %t40, ptr %l8, !tbaa !21
  %t42 = load i1, ptr %l8, !tbaa !21
  br i1 %t42, label %bb7, label %bb8
bb7:
  %t44 = load ptr, ptr %l6, !tbaa !29
  %t46 = call i64 @compiler_2finterp_2eDecideValues(ptr %v3, ptr %t44)
  store i64 %t46, ptr %l30
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb10
bb10:
  %t47 = load ptr, ptr %l6, !tbaa !29
  %t48 = load ptr, ptr %l7, !tbaa !29
  %t51 = call i64 @compiler_2finterp_2eDecideAsserts(ptr %v3, ptr %v3, ptr %t47, ptr %t48)
  store i64 %t51, ptr %l33
  br label %bb11
bb11:
  %t52 = load i1, ptr %l8, !tbaa !21
  br i1 %t52, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t54 = load ptr, ptr %l6, !tbaa !29
  %t56 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2finterp_2eBake(ptr %v3, ptr %s2, ptr %t54)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t56, ptr %l36
  br label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb15:
  %t57 = load ptr, ptr %l4, !tbaa !29
  %t59 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v3, ptr %t57)
  store i64 %t59, ptr %l38
  br label %bb16
bb16:
  %t60 = load i64, ptr %l38, !tbaa !24
  %t61 = icmp sgt i64 %t60, 0
  br i1 %t61, label %bb17, label %bb18
bb17:
  %t64 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t64, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t65 = load ptr, ptr %l6, !tbaa !29
  %t67 = getelementptr %"compiler/check:Checker", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t69 = load ptr, ptr %l6, !tbaa !29
  %t71 = getelementptr %"compiler/check:Checker", ptr %t69, i32 0, i32 12
  %t72 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t71
  call void @compiler_2fscope_3aScoper_2ector(ptr %t73, ptr %v3, ptr %v3, ptr %v3, ptr %t68, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t72)
  call void @llvm.memmove.p0.p0.i64(ptr %l45, ptr %t73, i64 1112, i1 false)
  br label %bb20
bb20:
  %t76 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 1112, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t76, ptr %l45, i64 1112, i1 false)
  store ptr %t76, ptr %l9, !tbaa !29
  %t78 = load ptr, ptr %l9, !tbaa !29
  %t79 = load ptr, ptr %l6, !tbaa !29
  %t80 = getelementptr { ptr, ptr }, ptr null, i32 1
  %t81 = ptrtoint ptr %t80 to i64
  %t82 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 %t81, i64 8)
  %t83 = getelementptr { ptr, ptr }, ptr %t82, i32 0, i32 0
  store ptr %t79, ptr %t83, !tbaa !28
  call void @__olang_scope_escape(ptr %v3)
  %t85 = getelementptr { ptr, ptr }, ptr %t82, i32 0, i32 1
  store ptr %v3, ptr %t85, !tbaa !28
  %t86 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_194, 0
  %t87 = insertvalue { ptr, ptr } %t86, ptr %t82, 1
  %t90 = getelementptr %"compiler/scope:Scoper", ptr %t78, i32 0, i32 4
  store { ptr, ptr } %t87, ptr %t90
  %t91 = load ptr, ptr %l9, !tbaa !29
  %t92 = load ptr, ptr %l6, !tbaa !29
  %t93 = getelementptr { ptr, ptr }, ptr null, i32 1
  %t94 = ptrtoint ptr %t93 to i64
  %t95 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 %t94, i64 8)
  %t96 = getelementptr { ptr, ptr }, ptr %t95, i32 0, i32 0
  store ptr %t92, ptr %t96, !tbaa !28
  call void @__olang_scope_escape(ptr %v3)
  %t98 = getelementptr { ptr, ptr }, ptr %t95, i32 0, i32 1
  store ptr %v3, ptr %t98, !tbaa !28
  %t99 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_195, 0
  %t100 = insertvalue { ptr, ptr } %t99, ptr %t95, 1
  %t103 = getelementptr %"compiler/scope:Scoper", ptr %t91, i32 0, i32 5
  store { ptr, ptr } %t100, ptr %t103
  %t104 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eRun(ptr %v3, ptr %t104)
  br label %bb21
bb21:
  %t106 = load ptr, ptr %l4, !tbaa !29
  %t108 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v3, ptr %t106)
  store i64 %t108, ptr %l55
  br label %bb22
bb22:
  %t109 = load i64, ptr %l55, !tbaa !24
  %t110 = icmp sgt i64 %t109, 0
  br i1 %t110, label %bb23, label %bb24
bb23:
  %t113 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t113, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  %t114 = load ptr, ptr %l6, !tbaa !29
  %t116 = getelementptr %"compiler/check:Checker", ptr %t114, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !29
  %t118 = load ptr, ptr %l6, !tbaa !29
  %t120 = getelementptr %"compiler/check:Checker", ptr %t118, i32 0, i32 12
  %t121 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t120
  call void @compiler_2finterp_3aExec_2ector(ptr %t122, ptr %v3, ptr %v3, ptr %v3, ptr %t117, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t121, i32 0)
  call void @llvm.memmove.p0.p0.i64(ptr %l63, ptr %t122, i64 992, i1 false)
  br label %bb26
bb26:
  %t126 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 992, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t126, ptr %l63, i64 992, i1 false)
  store ptr %t126, ptr %l10, !tbaa !29
  %t128 = load ptr, ptr %l10, !tbaa !29
  %t129 = load ptr, ptr %l6, !tbaa !29
  %t131 = getelementptr %"compiler/check:Checker", ptr %t129, i32 0, i32 102
  %t132 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t131
  %t135 = getelementptr %"compiler/interp:Exec", ptr %t128, i32 0, i32 10
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t132, ptr %t135
  %t136 = load ptr, ptr %l6, !tbaa !29
  %t137 = load ptr, ptr %l9, !tbaa !29
  %t138 = load ptr, ptr %l10, !tbaa !29
  %t139 = load ptr, ptr %l5, !tbaa !29
  %t141 = getelementptr %"compiler/load:Loader", ptr %t139, i32 0, i32 7
  %t142 = load i64, ptr %t141, !tbaa !24
  %t143 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t149 = call { i32, { i64, ptr } } @compiler_2fexplain_2eItem(ptr %v3, ptr %v3, ptr %v3, ptr %v2, ptr %v4, ptr %t136, ptr %t137, ptr %t138, i64 %t142, { i64, ptr } %t143)
  %t150 = extractvalue { i32, { i64, ptr } } %t149, 1
  %t151 = extractvalue { i32, { i64, ptr } } %t149, 0
  store i32 %t151, ptr %l76
  %t152 = icmp ne i32 %t151, 0
  br i1 %t152, label %bb28, label %ok.153
ok.153:
  store { i64, ptr } %t150, ptr %l75
  br label %bb27
bb27:
  %t154 = load { i64, ptr }, ptr %l75, !tbaa !27
  store { i64, ptr } %t154, ptr %l68, !tbaa !27
  br label %bb32
bb28:
  %t155 = load i32, ptr %l76, !tbaa !23
  %t156 = ashr i32 %t155, 16
  %t158 = icmp eq i32 %t156, 1
  store i1 %t158, ptr %l78, !tbaa !21
  br label %bb29
bb29:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s5
  %t159 = load ptr, ptr %l4, !tbaa !29
  store ptr %t159, ptr %l79, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t160
  %t161 = getelementptr { i64, [3 x i64] }, ptr %t160, i32 0, i32 0
  store i64 0, ptr %t161
  %t162 = load { i64, [3 x i64] }, ptr %t160
  store { i64, [3 x i64] } %t162, ptr %l80
  %t163 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t164 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t167 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eExplainNoItem(ptr %v2, ptr %v1, ptr %s5, { i64, ptr } %t163, { i64, ptr } %t164)
  store %"compiler/msgs:Msg" %t167, ptr %l83
  br label %bb30
bb30:
  %t168 = load ptr, ptr %l79, !tbaa !29
  %t169 = load { i64, [3 x i64] }, ptr %l80
  %t170 = load %"compiler/msgs:Msg", ptr %l83
  %t171 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v3, ptr %s5, ptr %t168, { i64, [3 x i64] } %t169, %"compiler/msgs:Msg" %t170)
  store i64 %t171, ptr %l84
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s5)
  %t173 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t173, ptr %rv
  br label %ret
bb32:
  %t174 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 16, i64 8)
  store ptr %t174, ptr %lp11
  %t175 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t176 = load ptr, ptr %lp11
  store { i64, ptr } %t175, ptr %t176, !tbaa !27
  %t177 = load ptr, ptr %lp11
  %t178 = load { i64, ptr }, ptr %t177, !tbaa !27
  %t180 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t178, 1
  store { i32, { i64, ptr } } %t180, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, i32 } @compiler_2folang_2ecompiler_2folang_3aPasses_2eInterpret(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l23 = alloca i32
  %l24 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca i32
  %l33 = alloca %"compiler/check:Checker"
  %l35 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l38 = alloca i64
  %l42 = alloca i64
  %l45 = alloca i64
  %l48 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l50 = alloca i64
  %l54 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l56 = alloca i64
  %l58 = alloca i64
  %l63 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l67 = alloca i1
  %l69 = alloca ptr
  %l70 = alloca { i64, [3 x i64] }
  %l72 = alloca i1
  %l73 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l77 = alloca i64
  %l78 = alloca i64
  %l89 = alloca %"compiler/msgs:Msg"
  %l90 = alloca i64
  %l95 = alloca i64
  %l97 = alloca i64
  %l102 = alloca ptr
  %l105 = alloca i1
  %l109 = alloca { i64, ptr }
  %l111 = alloca i1
  %l113 = alloca ptr
  %l114 = alloca { i64, [3 x i64] }
  %l118 = alloca %"compiler/msgs:Msg"
  %l119 = alloca i64
  %l123 = alloca i64
  %l131 = alloca %"compiler/interp:Exec"
  %l141 = alloca ptr
  %l143 = alloca i64
  %l159 = alloca { i64, ptr }
  %l172 = alloca i32
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %rv = alloca { i32, i32 }
  %t28 = alloca %"compiler/check:Checker", align 8
  %t98 = alloca { i64, [3 x i64] }, align 8
  %t212 = alloca { i64, [3 x i64] }, align 8
  %t247 = alloca %"compiler/interp:Exec", align 8
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t3 = load ptr, ptr %l3, !tbaa !29
  %t4 = load ptr, ptr %l4, !tbaa !29
  %t9 = call { i32, ptr } @compiler_2folang_2ecompiler_2folang_3aPasses_2eload(ptr %v0, ptr %v1, ptr %v3, ptr %a0, { i64, ptr } %a1, ptr %t3, ptr %t4)
  %t10 = extractvalue { i32, ptr } %t9, 1
  %t11 = extractvalue { i32, ptr } %t9, 0
  store i32 %t11, ptr %l30
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb2, label %ok.13
ok.13:
  store ptr %t10, ptr %l29
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l29, !tbaa !29
  store ptr %t14, ptr %l24, !tbaa !29
  br label %bb3
bb2:
  %t15 = load i32, ptr %l30, !tbaa !23
  %t16 = lshr i32 %t15, 16
  %t17 = and i32 %t15, 65535
  %t18 = icmp eq i32 %t16, 1
  %t19 = select i1 %t18, i32 1, i32 0
  %t20 = icmp eq i32 %t15, 0
  %t21 = shl i32 %t19, 16
  %t22 = or i32 %t21, %t17
  %t23 = select i1 %t20, i32 0, i32 %t22
  %t25 = insertvalue { i32, i32 } zeroinitializer, i32 %t23, 0
  store { i32, i32 } %t25, ptr %rv
  br label %ret
bb3:
  %t26 = load ptr, ptr %l24, !tbaa !29
  store ptr %t26, ptr %l5, !tbaa !29
  %t27 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2finterp_2eAnalyze(ptr %t28, ptr %v3, ptr %v3, ptr %t27, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l33, ptr %t28, i64 888, i1 false)
  br label %bb4
bb4:
  %t30 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 888, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %l33, i64 888, i1 false)
  store ptr %t30, ptr %l6, !tbaa !29
  %t32 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v3)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t32, ptr %l35
  br label %bb5
bb5:
  %t33 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l35
  %t34 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 8, i64 8)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t33, ptr %t34
  store ptr %t34, ptr %l7, !tbaa !29
  %t36 = load ptr, ptr %l4, !tbaa !29
  %t38 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v3, ptr %t36)
  store i64 %t38, ptr %l38
  br label %bb6
bb6:
  %t39 = load i64, ptr %l38, !tbaa !24
  %t40 = icmp eq i64 %t39, 0
  store i1 %t40, ptr %l8, !tbaa !21
  %t42 = load i1, ptr %l8, !tbaa !21
  br i1 %t42, label %bb7, label %bb8
bb7:
  %t44 = load ptr, ptr %l6, !tbaa !29
  %t46 = call i64 @compiler_2finterp_2eDecideValues(ptr %v3, ptr %t44)
  store i64 %t46, ptr %l42
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb10
bb10:
  %t47 = load ptr, ptr %l6, !tbaa !29
  %t48 = load ptr, ptr %l7, !tbaa !29
  %t51 = call i64 @compiler_2finterp_2eDecideAsserts(ptr %v3, ptr %v3, ptr %t47, ptr %t48)
  store i64 %t51, ptr %l45
  br label %bb11
bb11:
  %t52 = load i1, ptr %l8, !tbaa !21
  br i1 %t52, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t54 = load ptr, ptr %l6, !tbaa !29
  %t56 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2finterp_2eBake(ptr %v3, ptr %s2, ptr %t54)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t56, ptr %l48
  br label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb15:
  %t57 = load ptr, ptr %l4, !tbaa !29
  %t59 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v3, ptr %t57)
  store i64 %t59, ptr %l50
  br label %bb16
bb16:
  %t60 = load i64, ptr %l50, !tbaa !24
  %t61 = icmp sgt i64 %t60, 0
  br i1 %t61, label %bb17, label %bb18
bb17:
  %t64 = insertvalue { i32, i32 } zeroinitializer, i32 65536, 0
  store { i32, i32 } %t64, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  store %olang.scope zeroinitializer, ptr %s4
  %t65 = load ptr, ptr %l5, !tbaa !29
  %t67 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fload_2ecompiler_2fload_3aLoader_2eLinks(ptr %v3, ptr %s4, ptr %t65)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t67, ptr %l54
  br label %bb20
bb20:
  %t68 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l54
  %t69 = call ptr @__olang_scope_alloc_a(ptr %s4, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t68, ptr %t69
  store ptr %t69, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s5
  %t71 = load i64, ptr %l10, !tbaa !24
  store i64 %t71, ptr %l56, !tbaa !24
  %t72 = load ptr, ptr %l9, !tbaa !29
  %t74 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s4, ptr %t72)
  store i64 %t74, ptr %l58
  br label %bb22
bb22:
  %t75 = load i64, ptr %l56, !tbaa !24
  %t76 = load i64, ptr %l58, !tbaa !24
  %t77 = icmp slt i64 %t75, %t76
  %t79 = xor i1 %t77, true
  br i1 %t79, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s5)
  br label %bb45
bb24:
  br label %bb25
bb25:
  %t81 = load ptr, ptr %l9, !tbaa !29
  %t82 = load i64, ptr %l10, !tbaa !24
  %t85 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s4, ptr %s4, ptr %t81, i64 %t82)
  store { i64, ptr } %t85, ptr %l63
  br label %bb26
bb26:
  %t86 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t86, ptr %l11, !tbaa !27
  %t87 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t89 = call { i64, ptr } @compiler_2finterp_2eLoadLibrary(ptr %s4, ptr %s5, { i64, ptr } %t87)
  store { i64, ptr } %t89, ptr %l65
  br label %bb27
bb27:
  %t90 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t90, ptr %l12, !tbaa !27
  %t91 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t93 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s5, ptr %s5, { i64, ptr } %t91, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d196, i32 0, i32 1) })
  store i1 %t93, ptr %l67
  br label %bb28
bb28:
  %t94 = load i1, ptr %l67, !tbaa !21
  %t95 = xor i1 %t94, true
  br i1 %t95, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s6
  %t97 = load ptr, ptr %l4, !tbaa !29
  store ptr %t97, ptr %l69, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t98
  %t99 = getelementptr { i64, [3 x i64] }, ptr %t98, i32 0, i32 0
  store i64 0, ptr %t99
  %t100 = load { i64, [3 x i64] }, ptr %t98
  store { i64, [3 x i64] } %t100, ptr %l70
  %t101 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t103 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s4, ptr %s6, { i64, ptr } %t101, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d197, i32 0, i32 1) })
  store i1 %t103, ptr %l72
  br label %bb31
bb30:
  br label %bb43
bb31:
  %t104 = load i1, ptr %l72, !tbaa !21
  br i1 %t104, label %bb32, label %bb33
bb32:
  %t105 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t105, ptr %l74, !tbaa !27
  %t106 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t106, 0
  store i64 %t109, ptr %l77, !tbaa !24
  %t110 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t111 = extractvalue { i64, ptr } %t110, 0
  store i64 %t111, ptr %l78, !tbaa !24
  %t112 = icmp sge i64 2, 0
  br i1 %t112, label %bb34, label %bb35
bb33:
  %t114 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t116 = extractvalue { i64, ptr } %t114, 1
  %t117 = extractvalue { i64, ptr } %t114, 0
  %t118 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t117)
  call void @olang_textcopy(ptr %t118, ptr %t116, i64 %t117)
  %t119 = insertvalue { i64, ptr } undef, i64 %t117, 0
  %t120 = insertvalue { i64, ptr } %t119, ptr %t118, 1
  %t122 = extractvalue { i64, ptr } %t120, 0
  %t123 = extractvalue { i64, ptr } %t120, 1
  %t124 = mul i64 %t122, 1
  %t125 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t124)
  call void @llvm.memcpy.p0.p0.i64(ptr %t125, ptr %t123, i64 %t124, i1 false)
  %t126 = insertvalue { i64, ptr } undef, i64 %t122, 0
  %t127 = insertvalue { i64, ptr } %t126, ptr %t125, 1
  store { i64, ptr } %t127, ptr %l73, !tbaa !27
  br label %bb40
bb34:
  %t129 = load i64, ptr %l77, !tbaa !24
  %t130 = icmp sle i64 2, %t129
  br i1 %t130, label %bb36, label %bb37
bb35:
  call void @__olang_check_failed(ptr @olang_loc_436dc8a09a076c49_2aa9a29c41caf045)
  unreachable
bb36:
  %t132 = load i64, ptr %l77, !tbaa !24
  %t133 = load i64, ptr %l78, !tbaa !24
  %t134 = icmp sle i64 %t132, %t133
  br i1 %t134, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_436dc8a09a076c49_2aa9a29c41caf045)
  unreachable
bb38:
  %t136 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !27
  %t138 = load i64, ptr %l77, !tbaa !24
  %t139 = getelementptr i8, ptr %t137, i64 2
  %t140 = sub i64 %t138, 2
  %t141 = insertvalue { i64, ptr } undef, i64 %t140, 0
  %t142 = insertvalue { i64, ptr } %t141, ptr %t139, 1
  %t144 = extractvalue { i64, ptr } %t142, 1
  %t145 = extractvalue { i64, ptr } %t142, 0
  %t146 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t145)
  call void @olang_textcopy(ptr %t146, ptr %t144, i64 %t145)
  %t147 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t146, 1
  %t150 = extractvalue { i64, ptr } %t148, 0
  %t151 = extractvalue { i64, ptr } %t148, 1
  %t152 = mul i64 %t150, 1
  %t153 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t152)
  call void @llvm.memcpy.p0.p0.i64(ptr %t153, ptr %t151, i64 %t152, i1 false)
  %t154 = insertvalue { i64, ptr } undef, i64 %t150, 0
  %t155 = insertvalue { i64, ptr } %t154, ptr %t153, 1
  store { i64, ptr } %t155, ptr %l73, !tbaa !27
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_436dc8a09a076c49_2aa9a29c41caf045)
  unreachable
bb40:
  %t157 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t158 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t160 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eInterpLink(ptr %s6, ptr %s5, ptr %s6, { i64, ptr } %t158, { i64, ptr } %t157)
  store %"compiler/msgs:Msg" %t160, ptr %l89
  br label %bb41
bb41:
  %t161 = load ptr, ptr %l69, !tbaa !29
  %t162 = load { i64, [3 x i64] }, ptr %l70
  %t163 = load %"compiler/msgs:Msg", ptr %l89
  %t164 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v3, ptr %s6, ptr %t161, { i64, [3 x i64] } %t162, %"compiler/msgs:Msg" %t163)
  store i64 %t164, ptr %l90
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s6)
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s5)
  br label %bb44
bb44:
  %t165 = load i64, ptr %l10, !tbaa !24
  %t167 = add i64 %t165, 1
  store i64 %t167, ptr %l10, !tbaa !24
  br label %bb21
bb45:
  call void @__olang_scope_close(ptr %s4)
  %t169 = load ptr, ptr %l5, !tbaa !29
  %t171 = getelementptr %"compiler/load:Loader", ptr %t169, i32 0, i32 5
  store ptr %t171, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb46
bb46:
  store %olang.scope zeroinitializer, ptr %s11
  %t173 = load i64, ptr %l14, !tbaa !24
  store i64 %t173, ptr %l95, !tbaa !24
  %t174 = load ptr, ptr %l13, !tbaa !29
  %t176 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v3, ptr %t174)
  store i64 %t176, ptr %l97
  br label %bb47
bb47:
  %t177 = load i64, ptr %l95, !tbaa !24
  %t178 = load i64, ptr %l97, !tbaa !24
  %t179 = icmp slt i64 %t177, %t178
  %t181 = xor i1 %t179, true
  br i1 %t181, label %bb48, label %bb49
bb48:
  call void @__olang_scope_close(ptr %s11)
  br label %bb64
bb49:
  br label %bb50
bb50:
  %t183 = load ptr, ptr %l13, !tbaa !29
  %t184 = load i64, ptr %l14, !tbaa !24
  %t187 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v3, ptr %v3, ptr %t183, i64 %t184)
  store ptr %t187, ptr %l102
  br label %bb51
bb51:
  %t188 = load ptr, ptr %l102, !tbaa !29
  store ptr %t188, ptr %l15, !tbaa !29
  %t189 = load ptr, ptr %l15, !tbaa !29
  %t191 = getelementptr %"compiler/load:Module", ptr %t189, i32 0, i32 31
  %t192 = load { i64, ptr }, ptr %t191, !tbaa !27
  %t194 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s11, { i64, ptr } %t192, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d198, i32 0, i32 1) })
  store i1 %t194, ptr %l105
  br label %bb52
bb52:
  %t195 = load i1, ptr %l105, !tbaa !21
  br i1 %t195, label %bb53, label %bb54
bb53:
  call void @__olang_scope_close(ptr %s11)
  br label %bb63
bb54:
  br label %bb55
bb55:
  %t196 = load ptr, ptr %l15, !tbaa !29
  %t198 = getelementptr %"compiler/load:Module", ptr %t196, i32 0, i32 31
  %t199 = load { i64, ptr }, ptr %t198, !tbaa !27
  %t200 = load ptr, ptr %l3, !tbaa !29
  %t203 = call { i64, ptr } @compiler_2folang_2ecLibrary(ptr %v3, ptr %v3, ptr %s11, { i64, ptr } %t199, ptr %t200)
  store { i64, ptr } %t203, ptr %l109
  br label %bb56
bb56:
  %t204 = load { i64, ptr }, ptr %l109, !tbaa !27
  store { i64, ptr } %t204, ptr %l16, !tbaa !27
  %t205 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t207 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s11, ptr %s11, { i64, ptr } %t205, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d199, i32 0, i32 1) })
  store i1 %t207, ptr %l111
  br label %bb57
bb57:
  %t208 = load i1, ptr %l111, !tbaa !21
  %t209 = xor i1 %t208, true
  br i1 %t209, label %bb58, label %bb59
bb58:
  store %olang.scope zeroinitializer, ptr %s13
  %t211 = load ptr, ptr %l4, !tbaa !29
  store ptr %t211, ptr %l113, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t212
  %t213 = getelementptr { i64, [3 x i64] }, ptr %t212, i32 0, i32 0
  store i64 0, ptr %t213
  %t214 = load { i64, [3 x i64] }, ptr %t212
  store { i64, [3 x i64] } %t214, ptr %l114
  %t215 = load ptr, ptr %l15, !tbaa !29
  %t217 = getelementptr %"compiler/load:Module", ptr %t215, i32 0, i32 31
  %t218 = load { i64, ptr }, ptr %t217, !tbaa !27
  %t219 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t222 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eInterpLink(ptr %v3, ptr %s11, ptr %s13, { i64, ptr } %t218, { i64, ptr } %t219)
  store %"compiler/msgs:Msg" %t222, ptr %l118
  br label %bb60
bb59:
  br label %bb62
bb60:
  %t223 = load ptr, ptr %l113, !tbaa !29
  %t224 = load { i64, [3 x i64] }, ptr %l114
  %t225 = load %"compiler/msgs:Msg", ptr %l118
  %t226 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v3, ptr %s13, ptr %t223, { i64, [3 x i64] } %t224, %"compiler/msgs:Msg" %t225)
  store i64 %t226, ptr %l119
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s13)
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s11)
  br label %bb63
bb63:
  %t227 = load i64, ptr %l14, !tbaa !24
  %t229 = add i64 %t227, 1
  store i64 %t229, ptr %l14, !tbaa !24
  br label %bb46
bb64:
  %t231 = load ptr, ptr %l4, !tbaa !29
  %t233 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v3, ptr %t231)
  store i64 %t233, ptr %l123
  br label %bb65
bb65:
  %t234 = load i64, ptr %l123, !tbaa !24
  %t235 = icmp sgt i64 %t234, 0
  br i1 %t235, label %bb66, label %bb67
bb66:
  %t238 = insertvalue { i32, i32 } zeroinitializer, i32 65536, 0
  store { i32, i32 } %t238, ptr %rv
  br label %ret
bb67:
  br label %bb68
bb68:
  %t239 = load ptr, ptr %l6, !tbaa !29
  %t241 = getelementptr %"compiler/check:Checker", ptr %t239, i32 0, i32 1
  %t242 = load ptr, ptr %t241, !tbaa !29
  %t243 = load ptr, ptr %l6, !tbaa !29
  %t245 = getelementptr %"compiler/check:Checker", ptr %t243, i32 0, i32 12
  %t246 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t245
  call void @compiler_2finterp_3aExec_2ector(ptr %t247, ptr %v3, ptr %v3, ptr %v3, ptr %t242, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t246, i32 1)
  call void @llvm.memmove.p0.p0.i64(ptr %l131, ptr %t247, i64 992, i1 false)
  br label %bb69
bb69:
  %t251 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 992, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t251, ptr %l131, i64 992, i1 false)
  store ptr %t251, ptr %l17, !tbaa !29
  %t253 = load ptr, ptr %l17, !tbaa !29
  %t254 = load ptr, ptr %l7, !tbaa !29
  %t256 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t254
  %t259 = getelementptr %"compiler/interp:Exec", ptr %t253, i32 0, i32 3
  %t260 = getelementptr %"compiler/lower:Lowerer", ptr %t259, i32 0, i32 7
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t256, ptr %t260
  %t261 = load ptr, ptr %l17, !tbaa !29
  %t263 = getelementptr %"compiler/interp:Exec", ptr %t261, i32 0, i32 3
  %t264 = getelementptr %"compiler/lower:Lowerer", ptr %t263, i32 0, i32 6
  store i1 true, ptr %t264, !tbaa !21
  %t265 = load ptr, ptr %l6, !tbaa !29
  %t266 = load ptr, ptr %l3, !tbaa !29
  %t267 = load ptr, ptr %l5, !tbaa !29
  %t269 = getelementptr %"compiler/load:Loader", ptr %t267, i32 0, i32 7
  %t270 = load i64, ptr %t269, !tbaa !24
  %t274 = call ptr @compiler_2folang_2eplacement(ptr %v3, ptr %v3, ptr %t265, ptr %t266, i64 %t270, i1 true)
  store ptr %t274, ptr %l141
  br label %bb70
bb70:
  %t275 = load ptr, ptr %l141, !tbaa !29
  store ptr %t275, ptr %l18, !tbaa !29
  %t276 = load ptr, ptr %l4, !tbaa !29
  %t278 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v3, ptr %t276)
  store i64 %t278, ptr %l143
  br label %bb71
bb71:
  %t279 = load i64, ptr %l143, !tbaa !24
  %t280 = icmp sgt i64 %t279, 0
  br i1 %t280, label %bb72, label %bb73
bb72:
  %t283 = insertvalue { i32, i32 } zeroinitializer, i32 65536, 0
  store { i32, i32 } %t283, ptr %rv
  br label %ret
bb73:
  br label %bb74
bb74:
  %t284 = load ptr, ptr %l17, !tbaa !29
  %t285 = load ptr, ptr %l18, !tbaa !29
  %t287 = getelementptr %"compiler/free:Free", ptr %t285, i32 0, i32 3
  %t288 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t287
  %t291 = getelementptr %"compiler/interp:Exec", ptr %t284, i32 0, i32 3
  %t292 = getelementptr %"compiler/lower:Lowerer", ptr %t291, i32 0, i32 2
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t288, ptr %t292
  %t293 = load ptr, ptr %l17, !tbaa !29
  %t294 = load ptr, ptr %l18, !tbaa !29
  %t298 = getelementptr %"compiler/interp:Exec", ptr %t293, i32 0, i32 3
  %t299 = getelementptr %"compiler/lower:Lowerer", ptr %t298, i32 0, i32 3
  store ptr %t294, ptr %t299, !tbaa !29
  store { i64, ptr } %a2, ptr %l19, !tbaa !27
  store i64 0, ptr %l20, !tbaa !24
  %t302 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t304 = extractvalue { i64, ptr } %t302, 0
  store i64 %t304, ptr %l21, !tbaa !24
  br label %bb75
bb75:
  %t306 = load i64, ptr %l20, !tbaa !24
  %t307 = load i64, ptr %l21, !tbaa !24
  %t310 = icmp slt i64 %t306, %t307
  %t312 = xor i1 %t310, true
  br i1 %t312, label %bb76, label %bb77
bb76:
  br label %bb81
bb77:
  br label %bb78
bb78:
  %t314 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t314, ptr %l159, !tbaa !27
  %t315 = load i64, ptr %l20, !tbaa !24
  %t317 = getelementptr { i64, ptr }, ptr %l159, i32 0, i32 1
  %t318 = load ptr, ptr %t317, !tbaa !27
  %t319 = getelementptr { i64, ptr }, ptr %t318, i64 %t315
  %t320 = load { i64, ptr }, ptr %t319, !tbaa !37
  %t322 = load ptr, ptr %l17, !tbaa !29
  %t324 = getelementptr %"compiler/interp:Exec", ptr %t322, i32 0, i32 4
  %t325 = getelementptr %"compiler/eval:Machine", ptr %t324, i32 0, i32 74
  %t328 = extractvalue { i64, ptr } %t320, 1
  %t329 = extractvalue { i64, ptr } %t320, 0
  %t330 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t329)
  call void @olang_textcopy(ptr %t330, ptr %t328, i64 %t329)
  %t331 = insertvalue { i64, ptr } undef, i64 %t329, 0
  %t332 = insertvalue { i64, ptr } %t331, ptr %t330, 1
  %t334 = extractvalue { i64, ptr } %t332, 0
  %t335 = extractvalue { i64, ptr } %t332, 1
  %t336 = mul i64 %t334, 1
  %t337 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t336)
  call void @llvm.memcpy.p0.p0.i64(ptr %t337, ptr %t335, i64 %t336, i1 false)
  %t338 = insertvalue { i64, ptr } undef, i64 %t334, 0
  %t339 = insertvalue { i64, ptr } %t338, ptr %t337, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v3, ptr %v3, ptr %t325, { i64, ptr } %t339)
  br label %bb79
bb79:
  br label %bb80
bb80:
  %t342 = load i64, ptr %l20, !tbaa !24
  %t344 = add i64 %t342, 1
  store i64 %t344, ptr %l20, !tbaa !24
  br label %bb75
bb81:
  %t346 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eInterpCrash, !tbaa !27
  %t347 = load ptr, ptr @__olang_prog_scope
  call void @std_2fos_2eOnCrash(ptr %t347, { i64, ptr } %t346)
  br label %bb82
bb82:
  %t349 = load ptr, ptr %l17, !tbaa !29
  %t350 = load ptr, ptr %l4, !tbaa !29
  %t353 = call i32 @compiler_2finterp_2ecompiler_2finterp_3aExec_2eRunMain(ptr %v3, ptr %v3, ptr %t349, ptr %t350)
  store i32 %t353, ptr %l172
  br label %bb83
bb83:
  %t354 = load i32, ptr %l172, !tbaa !23
  store i32 %t354, ptr %l23, !tbaa !23
  %t355 = load i32, ptr %l23, !tbaa !23
  %t357 = icmp eq i32 %t355, 134
  br i1 %t357, label %bb84, label %bb85
bb84:
  store %olang.scope zeroinitializer, ptr %s21
  call void @std_2fos_2eOnCrash(ptr %s21, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d200, i32 0, i32 1) })
  br label %bb86
bb85:
  br label %bb88
bb86:
  call void @abort()
  unreachable
bb87:
  call void @__olang_check_failed(ptr @olang_loc_d9ce39c2cb08642b_edb226294df0b2a7)
  unreachable
bb88:
  %t359 = load i32, ptr %l23, !tbaa !23
  %t361 = insertvalue { i32, i32 } zeroinitializer, i32 %t359, 1
  store { i32, i32 } %t361, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i32 }, ptr %rv
  ret { i32, i32 } %rr
}

define dso_local { i32, ptr } @compiler_2folang_2ecompiler_2folang_3aPasses_2eload(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l19 = alloca %"compiler/fetch:Fetcher"
  %l21 = alloca %"compiler/source:Names"
  %l23 = alloca { i64, ptr }
  %l30 = alloca %"compiler/load:Loader"
  %l38 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l40 = alloca i64
  %l42 = alloca i64
  %l47 = alloca { i64, ptr }
  %l57 = alloca i64
  %l58 = alloca ptr
  %l61 = alloca i64
  %l63 = alloca i64
  %s2 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t57 = alloca %"compiler/load:Loader", align 8
  store { i64, ptr } %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = call { i64, ptr } @compiler_2fload_2eLockPath(ptr %v1, ptr %v2, { i64, ptr } %t1)
  store { i64, ptr } %t3, ptr %l11
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t4, 0
  %t6 = extractvalue { i64, ptr } %t4, 1
  %t7 = mul i64 %t5, 1
  %t8 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t7)
  call void @llvm.memcpy.p0.p0.i64(ptr %t8, ptr %t6, i64 %t7, i1 false)
  %t9 = insertvalue { i64, ptr } undef, i64 %t5, 0
  %t10 = insertvalue { i64, ptr } %t9, ptr %t8, 1
  store { i64, ptr } %t10, ptr %l12, !tbaa !27
  %t11 = call { i64, ptr } @compiler_2ffetch_2eCacheDir(ptr %v2)
  store { i64, ptr } %t11, ptr %l13
  br label %bb2
bb2:
  %t12 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 0
  %t14 = extractvalue { i64, ptr } %t12, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l14, !tbaa !27
  %t19 = call { i64, ptr } @compiler_2ffetch_2eGitBase(ptr %v2)
  store { i64, ptr } %t19, ptr %l15
  br label %bb3
bb3:
  %t20 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t20, 0
  %t22 = extractvalue { i64, ptr } %t20, 1
  %t23 = mul i64 %t21, 1
  %t24 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t23)
  call void @llvm.memcpy.p0.p0.i64(ptr %t24, ptr %t22, i64 %t23, i1 false)
  %t25 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t24, 1
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t29 = getelementptr %"compiler/build:Config", ptr %t27, i32 0, i32 12
  %t30 = load i1, ptr %t29, !tbaa !21
  %t31 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t35 = call %"compiler/fetch:Fetcher" @compiler_2ffetch_3aFetcher_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t31, { i64, ptr } %t32, { i64, ptr } %t26, i1 %t30, i1 false)
  store %"compiler/fetch:Fetcher" %t35, ptr %l19
  br label %bb4
bb4:
  %t36 = load %"compiler/fetch:Fetcher", ptr %l19
  %t37 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 88, i64 8)
  store %"compiler/fetch:Fetcher" %t36, ptr %t37
  store ptr %t37, ptr %l4, !tbaa !29
  %t39 = call %"compiler/source:Names" @compiler_2fsource_3aNames_2ector(ptr %v2)
  store %"compiler/source:Names" %t39, ptr %l21
  br label %bb5
bb5:
  %t40 = load %"compiler/source:Names", ptr %l21
  %t41 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store %"compiler/source:Names" %t40, ptr %t41
  store ptr %t41, ptr %l5, !tbaa !29
  %t43 = call { i64, ptr } @compiler_2fload_2eStdDir(ptr %v2)
  store { i64, ptr } %t43, ptr %l23
  br label %bb6
bb6:
  %t44 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t44, 0
  %t46 = extractvalue { i64, ptr } %t44, 1
  %t47 = mul i64 %t45, 1
  %t48 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t47)
  call void @llvm.memcpy.p0.p0.i64(ptr %t48, ptr %t46, i64 %t47, i1 false)
  %t49 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  %t51 = load ptr, ptr %l2, !tbaa !29
  %t53 = getelementptr %"compiler/build:Config", ptr %t51, i32 0, i32 3
  %t54 = load ptr, ptr %l4, !tbaa !29
  %t55 = load ptr, ptr %l5, !tbaa !29
  %t56 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fload_3aLoader_2ector(ptr %t57, ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t50, ptr %t53, ptr %t54, ptr %t55, ptr %t56)
  call void @llvm.memmove.p0.p0.i64(ptr %l30, ptr %t57, i64 144, i1 false)
  br label %bb7
bb7:
  %t63 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 144, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t63, ptr %l30, i64 144, i1 false)
  store ptr %t63, ptr %l6, !tbaa !29
  %t65 = load ptr, ptr %l6, !tbaa !29
  %t66 = load ptr, ptr %l2, !tbaa !29
  %t68 = getelementptr %"compiler/build:Config", ptr %t66, i32 0, i32 1
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t69, 1
  %t72 = extractvalue { i64, ptr } %t69, 0
  %t73 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t72)
  call void @olang_textcopy(ptr %t73, ptr %t71, i64 %t72)
  %t74 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  %t77 = extractvalue { i64, ptr } %t75, 0
  %t78 = extractvalue { i64, ptr } %t75, 1
  %t79 = mul i64 %t77, 1
  %t80 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t79)
  call void @llvm.memcpy.p0.p0.i64(ptr %t80, ptr %t78, i64 %t79, i1 false)
  %t81 = insertvalue { i64, ptr } undef, i64 %t77, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t80, 1
  %t85 = getelementptr %"compiler/load:Loader", ptr %t65, i32 0, i32 12
  store { i64, ptr } %t82, ptr %t85, !tbaa !27
  store %olang.scope zeroinitializer, ptr %s2
  %t86 = load ptr, ptr %l2, !tbaa !29
  %t88 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eCFlags(ptr %v2, ptr %s2, ptr %t86)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t88, ptr %l38
  br label %bb8
bb8:
  %t89 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l38
  %t90 = call ptr @__olang_scope_alloc_a(ptr %s2, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t89, ptr %t90
  store ptr %t90, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  %t92 = load i64, ptr %l8, !tbaa !24
  store i64 %t92, ptr %l40, !tbaa !24
  %t93 = load ptr, ptr %l7, !tbaa !29
  %t95 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s2, ptr %t93)
  store i64 %t95, ptr %l42
  br label %bb10
bb10:
  %t96 = load i64, ptr %l40, !tbaa !24
  %t97 = load i64, ptr %l42, !tbaa !24
  %t98 = icmp slt i64 %t96, %t97
  %t100 = xor i1 %t98, true
  br i1 %t100, label %bb11, label %bb12
bb11:
  br label %bb17
bb12:
  br label %bb13
bb13:
  %t102 = load ptr, ptr %l7, !tbaa !29
  %t103 = load i64, ptr %l8, !tbaa !24
  %t106 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s2, ptr %s2, ptr %t102, i64 %t103)
  store { i64, ptr } %t106, ptr %l47
  br label %bb14
bb14:
  %t107 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t108 = load ptr, ptr %l6, !tbaa !29
  %t110 = getelementptr %"compiler/load:Loader", ptr %t108, i32 0, i32 13
  %t113 = extractvalue { i64, ptr } %t107, 1
  %t114 = extractvalue { i64, ptr } %t107, 0
  %t115 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t114)
  call void @olang_textcopy(ptr %t115, ptr %t113, i64 %t114)
  %t116 = insertvalue { i64, ptr } undef, i64 %t114, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr %t115, 1
  %t119 = extractvalue { i64, ptr } %t117, 0
  %t120 = extractvalue { i64, ptr } %t117, 1
  %t121 = mul i64 %t119, 1
  %t122 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t121)
  call void @llvm.memcpy.p0.p0.i64(ptr %t122, ptr %t120, i64 %t121, i1 false)
  %t123 = insertvalue { i64, ptr } undef, i64 %t119, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr %t122, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v2, ptr %v2, ptr %t110, { i64, ptr } %t124)
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t127 = load i64, ptr %l8, !tbaa !24
  %t129 = add i64 %t127, 1
  store i64 %t129, ptr %l8, !tbaa !24
  br label %bb9
bb17:
  call void @__olang_scope_close(ptr %s2)
  %t131 = load ptr, ptr %l6, !tbaa !29
  %t132 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t135 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eLoad(ptr %v2, ptr %v1, ptr %t131, { i64, ptr } %t132)
  store i64 %t135, ptr %l57
  br label %bb18
bb18:
  store ptr %a0, ptr %l58, !tbaa !29
  %t137 = load ptr, ptr %l6, !tbaa !29
  %t139 = getelementptr %"compiler/load:Loader", ptr %t137, i32 0, i32 5
  %t141 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v2, ptr %t139)
  store i64 %t141, ptr %l61
  br label %bb19
bb19:
  %t142 = load i64, ptr %l61, !tbaa !24
  %t143 = load ptr, ptr %l58, !tbaa !29
  %t144 = getelementptr %"compiler/olang:Passes", ptr %t143, i32 0, i32 0
  store i64 %t142, ptr %t144, !tbaa !24
  %t145 = load ptr, ptr %l3, !tbaa !29
  %t147 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v2, ptr %t145)
  store i64 %t147, ptr %l63
  br label %bb20
bb20:
  %t148 = load i64, ptr %l63, !tbaa !24
  %t149 = icmp sgt i64 %t148, 0
  br i1 %t149, label %bb21, label %bb22
bb21:
  %t152 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t152, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t153 = load ptr, ptr %l6, !tbaa !29
  %t155 = insertvalue { i32, ptr } zeroinitializer, ptr %t153, 1
  store { i32, ptr } %t155, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i32 @compiler_2folang_2edrive(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"compiler/olang:Passes"
  %l2 = alloca %"compiler/olang:Passes"
  %l5 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"compiler/olang:Passes" @compiler_2folang_3aPasses_2ector(ptr %s0)
  store %"compiler/olang:Passes" %t1, ptr %l2
  br label %bb1
bb1:
  %t2 = load %"compiler/olang:Passes", ptr %l2
  store %"compiler/olang:Passes" %t2, ptr %l1
  %t6 = call i32 @compiler_2folang_2eRunWith_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %s0, { i64, ptr } %a0, ptr %l1)
  store i32 %t6, ptr %l5
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t7 = load i32, ptr %l5, !tbaa !23
  store i32 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local ptr @compiler_2folang_2eemitter(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, ptr %a3, i32 %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l6 = alloca i1
  %l7 = alloca ptr
  %l17 = alloca %"compiler/emit:Emitter"
  %l24 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l52 = alloca i1
  %l55 = alloca ptr
  %l58 = alloca i1
  %l65 = alloca i1
  %rv = alloca ptr
  %t18 = alloca %"compiler/emit:Emitter", align 8
  store ptr %a0, ptr %l0
  store ptr %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l4
  %t3 = trunc i64 2 to i32
  %t4 = icmp eq i32 %t1, %t3
  store i1 %t4, ptr %l6, !tbaa !21
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  call void @compiler_2femit_3aEmitter_2ector(ptr %t18, ptr %v0, ptr %v1, ptr %v2, ptr %v0, ptr %v3, ptr %t9, ptr %a1, ptr %a2, ptr %t17)
  call void @llvm.memmove.p0.p0.i64(ptr %l17, ptr %t18, i64 632, i1 false)
  br label %bb1
bb1:
  %t23 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 632, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t23, ptr %l17, i64 632, i1 false)
  store ptr %t23, ptr %l7, !tbaa !29
  %t25 = load ptr, ptr %l7, !tbaa !29
  %t26 = load i1, ptr %l6, !tbaa !21
  %t29 = getelementptr %"compiler/emit:Emitter", ptr %t25, i32 0, i32 4
  store i1 %t26, ptr %t29, !tbaa !21
  %t30 = load ptr, ptr %l7, !tbaa !29
  %t33 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a5
  %t36 = getelementptr %"compiler/emit:Emitter", ptr %t30, i32 0, i32 44
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t33, ptr %t36
  %t37 = load ptr, ptr %l7, !tbaa !29
  store ptr %t37, ptr %l24, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t40 = getelementptr %"compiler/build:Config", ptr %t38, i32 0, i32 6
  %t41 = load i1, ptr %t40, !tbaa !21
  br i1 %t41, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d201, i32 0, i32 1) }, ptr %l27, !tbaa !27
  br label %bb4
bb3:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d202, i32 0, i32 1) }, ptr %l27, !tbaa !27
  br label %bb4
bb4:
  %t43 = load ptr, ptr %l3, !tbaa !29
  %t45 = getelementptr %"compiler/build:Config", ptr %t43, i32 0, i32 2
  %t46 = getelementptr %"compiler/target:Target", ptr %t45, i32 0, i32 5
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t48, 1
  %t50 = extractvalue { i64, ptr } %t48, 0
  %t52 = extractvalue { i64, ptr } %t47, 1
  %t53 = extractvalue { i64, ptr } %t47, 0
  %t54 = add i64 %t50, %t53
  %t55 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t54)
  call void @olang_textcopy(ptr %t55, ptr %t49, i64 %t50)
  %t56 = getelementptr i8, ptr %t55, i64 %t50
  call void @olang_textcopy(ptr %t56, ptr %t52, i64 %t53)
  %t57 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t55, 1
  %t60 = extractvalue { i64, ptr } %t58, 0
  %t61 = extractvalue { i64, ptr } %t58, 1
  %t62 = mul i64 %t60, 1
  %t63 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t62)
  call void @llvm.memcpy.p0.p0.i64(ptr %t63, ptr %t61, i64 %t62, i1 false)
  %t64 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t63, 1
  %t67 = load ptr, ptr %l24, !tbaa !29
  %t68 = getelementptr %"compiler/emit:Emitter", ptr %t67, i32 0, i32 8
  store { i64, ptr } %t65, ptr %t68, !tbaa !27
  %t69 = load ptr, ptr %l7, !tbaa !29
  %t70 = load i32, ptr %l4
  %t72 = trunc i64 0 to i32
  %t73 = icmp eq i32 %t70, %t72
  %t76 = getelementptr %"compiler/emit:Emitter", ptr %t69, i32 0, i32 38
  store i1 %t73, ptr %t76, !tbaa !21
  %t77 = load ptr, ptr %l7, !tbaa !29
  %t78 = load ptr, ptr %l3, !tbaa !29
  %t80 = getelementptr %"compiler/build:Config", ptr %t78, i32 0, i32 2
  %t81 = getelementptr %"compiler/target:Target", ptr %t80, i32 0, i32 1
  %t82 = load { i64, ptr }, ptr %t81, !tbaa !27
  %t85 = getelementptr %"compiler/emit:Emitter", ptr %t77, i32 0, i32 21
  store { i64, ptr } %t82, ptr %t85, !tbaa !27
  %t86 = load ptr, ptr %l7, !tbaa !29
  %t87 = load ptr, ptr %l3, !tbaa !29
  %t89 = getelementptr %"compiler/build:Config", ptr %t87, i32 0, i32 2
  %t90 = getelementptr %"compiler/target:Target", ptr %t89, i32 0, i32 2
  %t91 = load { i64, ptr }, ptr %t90, !tbaa !27
  %t94 = getelementptr %"compiler/emit:Emitter", ptr %t86, i32 0, i32 45
  store { i64, ptr } %t91, ptr %t94, !tbaa !27
  %t95 = load ptr, ptr %l7, !tbaa !29
  %t96 = load ptr, ptr %l3, !tbaa !29
  %t98 = getelementptr %"compiler/build:Config", ptr %t96, i32 0, i32 7
  %t99 = load i1, ptr %t98, !tbaa !21
  %t102 = getelementptr %"compiler/emit:Emitter", ptr %t95, i32 0, i32 46
  store i1 %t99, ptr %t102, !tbaa !21
  %t103 = load ptr, ptr %l7, !tbaa !29
  %t104 = load ptr, ptr %l3, !tbaa !29
  %t106 = getelementptr %"compiler/build:Config", ptr %t104, i32 0, i32 4
  %t107 = load i1, ptr %t106, !tbaa !21
  %t110 = getelementptr %"compiler/emit:Emitter", ptr %t103, i32 0, i32 5
  store i1 %t107, ptr %t110, !tbaa !21
  %t111 = load ptr, ptr %l7, !tbaa !29
  %t112 = load i1, ptr %l6, !tbaa !21
  %t115 = getelementptr %"compiler/emit:Emitter", ptr %t111, i32 0, i32 7
  store i1 %t112, ptr %t115, !tbaa !21
  %t116 = load ptr, ptr %l7, !tbaa !29
  store ptr %t116, ptr %l49, !tbaa !29
  %t117 = load ptr, ptr %l3, !tbaa !29
  %t119 = getelementptr %"compiler/build:Config", ptr %t117, i32 0, i32 4
  %t120 = load i1, ptr %t119, !tbaa !21
  br i1 %t120, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l52, !tbaa !21
  br label %bb7
bb6:
  %t122 = load ptr, ptr %l3, !tbaa !29
  %t124 = getelementptr %"compiler/build:Config", ptr %t122, i32 0, i32 6
  %t125 = load i1, ptr %t124, !tbaa !21
  store i1 %t125, ptr %l52, !tbaa !21
  br label %bb7
bb7:
  %t127 = load i1, ptr %l52, !tbaa !21
  %t128 = load ptr, ptr %l49, !tbaa !29
  %t129 = getelementptr %"compiler/emit:Emitter", ptr %t128, i32 0, i32 53
  store i1 %t127, ptr %t129, !tbaa !21
  %t130 = load ptr, ptr %l7, !tbaa !29
  store ptr %t130, ptr %l55, !tbaa !29
  %t131 = load ptr, ptr %l3, !tbaa !29
  %t133 = getelementptr %"compiler/build:Config", ptr %t131, i32 0, i32 9
  %t134 = load i1, ptr %t133, !tbaa !21
  br i1 %t134, label %bb8, label %bb9
bb8:
  %t136 = load i32, ptr %l4
  %t138 = trunc i64 1 to i32
  %t139 = icmp eq i32 %t136, %t138
  store i1 %t139, ptr %l58, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l58, !tbaa !21
  br label %bb10
bb10:
  %t141 = load i1, ptr %l58, !tbaa !21
  %t142 = load ptr, ptr %l55, !tbaa !29
  %t143 = getelementptr %"compiler/emit:Emitter", ptr %t142, i32 0, i32 6
  store i1 %t141, ptr %t143, !tbaa !21
  %t144 = load ptr, ptr %l7, !tbaa !29
  %t145 = load i64, ptr @G_2ecompiler_2fbuild_2eThinFrom, !tbaa !24
  %t148 = getelementptr %"compiler/emit:Emitter", ptr %t144, i32 0, i32 39
  store i64 %t145, ptr %t148, !tbaa !24
  %t149 = load ptr, ptr %l3, !tbaa !29
  %t151 = getelementptr %"compiler/build:Config", ptr %t149, i32 0, i32 5
  %t152 = load i1, ptr %t151, !tbaa !21
  br i1 %t152, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l65, !tbaa !21
  br label %bb13
bb12:
  %t154 = load ptr, ptr %l3, !tbaa !29
  %t156 = getelementptr %"compiler/build:Config", ptr %t154, i32 0, i32 4
  %t157 = load i1, ptr %t156, !tbaa !21
  store i1 %t157, ptr %l65, !tbaa !21
  br label %bb13
bb13:
  %t159 = load i1, ptr %l65, !tbaa !21
  br i1 %t159, label %bb14, label %bb15
bb14:
  %t160 = load ptr, ptr %l7, !tbaa !29
  %t161 = load i64, ptr @G_2ecompiler_2femit_2ePartSizeDev, !tbaa !24
  %t164 = getelementptr %"compiler/emit:Emitter", ptr %t160, i32 0, i32 40
  store i64 %t161, ptr %t164, !tbaa !24
  br label %bb16
bb15:
  br label %bb16
bb16:
  %t165 = load ptr, ptr %l7, !tbaa !29
  %t166 = load i32, ptr %l4
  %t168 = trunc i64 0 to i32
  %t169 = icmp eq i32 %t166, %t168
  %t171 = xor i1 %t169, true
  %t174 = getelementptr %"compiler/emit:Emitter", ptr %t165, i32 0, i32 71
  store i1 %t171, ptr %t174, !tbaa !21
  %t175 = load i1, ptr %l6, !tbaa !21
  br i1 %t175, label %bb17, label %bb18
bb17:
  %t177 = load ptr, ptr %l7, !tbaa !29
  %t178 = load ptr, ptr %l3, !tbaa !29
  %t180 = getelementptr %"compiler/build:Config", ptr %t178, i32 0, i32 10
  %t181 = load { i64, ptr }, ptr %t180, !tbaa !27
  %t183 = extractvalue { i64, ptr } %t181, 1
  %t184 = extractvalue { i64, ptr } %t181, 0
  %t185 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t184)
  call void @olang_textcopy(ptr %t185, ptr %t183, i64 %t184)
  %t186 = insertvalue { i64, ptr } undef, i64 %t184, 0
  %t187 = insertvalue { i64, ptr } %t186, ptr %t185, 1
  %t189 = extractvalue { i64, ptr } %t187, 0
  %t190 = extractvalue { i64, ptr } %t187, 1
  %t191 = mul i64 %t189, 1
  %t192 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t191)
  call void @llvm.memcpy.p0.p0.i64(ptr %t192, ptr %t190, i64 %t191, i1 false)
  %t193 = insertvalue { i64, ptr } undef, i64 %t189, 0
  %t194 = insertvalue { i64, ptr } %t193, ptr %t192, 1
  %t197 = getelementptr %"compiler/emit:Emitter", ptr %t177, i32 0, i32 47
  store { i64, ptr } %t194, ptr %t197, !tbaa !27
  %t198 = load ptr, ptr %l7, !tbaa !29
  %t199 = load ptr, ptr %l3, !tbaa !29
  %t201 = getelementptr %"compiler/build:Config", ptr %t199, i32 0, i32 0
  %t202 = load { i64, ptr }, ptr %t201, !tbaa !27
  %t204 = extractvalue { i64, ptr } %t202, 1
  %t205 = extractvalue { i64, ptr } %t202, 0
  %t206 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d203, i32 0, i32 1) }, 1
  %t207 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d203, i32 0, i32 1) }, 0
  %t208 = add i64 %t205, %t207
  %t209 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t208)
  call void @olang_textcopy(ptr %t209, ptr %t204, i64 %t205)
  %t210 = getelementptr i8, ptr %t209, i64 %t205
  call void @olang_textcopy(ptr %t210, ptr %t206, i64 %t207)
  %t211 = insertvalue { i64, ptr } undef, i64 %t208, 0
  %t212 = insertvalue { i64, ptr } %t211, ptr %t209, 1
  %t214 = extractvalue { i64, ptr } %t212, 0
  %t215 = extractvalue { i64, ptr } %t212, 1
  %t216 = mul i64 %t214, 1
  %t217 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t216)
  call void @llvm.memcpy.p0.p0.i64(ptr %t217, ptr %t215, i64 %t216, i1 false)
  %t218 = insertvalue { i64, ptr } undef, i64 %t214, 0
  %t219 = insertvalue { i64, ptr } %t218, ptr %t217, 1
  %t222 = getelementptr %"compiler/emit:Emitter", ptr %t198, i32 0, i32 49
  store { i64, ptr } %t219, ptr %t222, !tbaa !27
  br label %bb19
bb18:
  br label %bb19
bb19:
  %t223 = load ptr, ptr %l7, !tbaa !29
  store ptr %t223, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2folang_2eendsWithOlang(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l4 = alloca i1
  %l6 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp sgt i64 %t3, 6
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t9 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %s0, { i64, ptr } %t7, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d204, i32 0, i32 1) })
  store i1 %t9, ptr %l6
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb4
bb3:
  %t10 = load i1, ptr %l6, !tbaa !21
  store i1 %t10, ptr %l4, !tbaa !21
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t11 = load i1, ptr %l4, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2folang_2eexplainRule(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %lp4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i32
  %l11 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca { i64, [3 x i64] }
  %l15 = alloca %"compiler/msgs:Msg"
  %l16 = alloca i64
  %l18 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca i32
  %l24 = alloca ptr
  %l25 = alloca { i64, [3 x i64] }
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l44 = alloca %"compiler/msgs:Msg"
  %l45 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  %t16 = alloca { i64, [3 x i64] }, align 8
  %t41 = alloca { i64, [3 x i64] }, align 8
  store { i64, ptr } %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i64, ptr } @compiler_2fdiag_2eSpecPath(ptr %s0)
  store { i64, ptr } %t1, ptr %l5
  br label %bb1
bb1:
  %t2 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t2, ptr %l2, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s0, { i64, ptr } %t3)
  %t6 = extractvalue { i32, { i64, ptr } } %t5, 1
  %t7 = extractvalue { i32, { i64, ptr } } %t5, 0
  store i32 %t7, ptr %l9
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb3, label %ok.9
ok.9:
  store { i64, ptr } %t6, ptr %l8
  br label %bb2
bb2:
  %t10 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t10, ptr %l6, !tbaa !27
  br label %bb7
bb3:
  %t11 = load i32, ptr %l9, !tbaa !23
  %t12 = ashr i32 %t11, 16
  %t14 = icmp eq i32 %t12, 1
  store i1 %t14, ptr %l11, !tbaa !21
  br label %bb4
bb4:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s1
  %t15 = load ptr, ptr %l1, !tbaa !29
  store ptr %t15, ptr %l12, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t16
  %t17 = getelementptr { i64, [3 x i64] }, ptr %t16, i32 0, i32 0
  store i64 0, ptr %t17
  %t18 = load { i64, [3 x i64] }, ptr %t16
  store { i64, [3 x i64] } %t18, ptr %l13
  %t19 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoSpec(ptr %s0, ptr %s1, { i64, ptr } %t19)
  store %"compiler/msgs:Msg" %t21, ptr %l15
  br label %bb5
bb5:
  %t22 = load ptr, ptr %l12, !tbaa !29
  %t23 = load { i64, [3 x i64] }, ptr %l13
  %t24 = load %"compiler/msgs:Msg", ptr %l15
  %t25 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v1, ptr %s1, ptr %t22, { i64, [3 x i64] } %t23, %"compiler/msgs:Msg" %t24)
  store i64 %t25, ptr %l16
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t27 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t27, ptr %rv
  br label %ret
bb7:
  %t28 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t34 = call { i32, { i64, ptr } } @compiler_2fdiag_2eExplain(ptr %s0, ptr %v0, ptr %v2, { i64, ptr } %t28, { i64, ptr } %t31)
  %t35 = extractvalue { i32, { i64, ptr } } %t34, 1
  %t36 = extractvalue { i32, { i64, ptr } } %t34, 0
  store i32 %t36, ptr %l23
  %t37 = icmp ne i32 %t36, 0
  br i1 %t37, label %bb9, label %ok.38
ok.38:
  store { i64, ptr } %t35, ptr %l22
  br label %bb8
bb8:
  %t39 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t39, ptr %l18, !tbaa !27
  br label %bb26
bb9:
  br label %bb10
bb10:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s2
  %t40 = load ptr, ptr %l1, !tbaa !29
  store ptr %t40, ptr %l24, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t41
  %t42 = getelementptr { i64, [3 x i64] }, ptr %t41, i32 0, i32 0
  store i64 0, ptr %t42
  %t43 = load { i64, [3 x i64] }, ptr %t41
  store { i64, [3 x i64] } %t43, ptr %l25
  %t44 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t44, ptr %l26, !tbaa !27
  %t45 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t45, 0
  store i64 %t46, ptr %l27, !tbaa !24
  %t47 = icmp sge i64 0, 0
  br i1 %t47, label %bb11, label %bb12
bb11:
  %t49 = icmp sle i64 0, 1
  br i1 %t49, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_8c7e755ea0eb9876_6b14028370dd0cea)
  unreachable
bb13:
  %t51 = load i64, ptr %l27, !tbaa !24
  %t52 = icmp sle i64 1, %t51
  br i1 %t52, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_8c7e755ea0eb9876_6b14028370dd0cea)
  unreachable
bb15:
  %t54 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr i8, ptr %t55, i64 0
  %t57 = sub i64 1, 0
  %t58 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t56, 1
  %t61 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eToUpper(ptr %v0, ptr %s2, { i64, ptr } %t59)
  store { i64, ptr } %t61, ptr %l32
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_8c7e755ea0eb9876_6b14028370dd0cea)
  unreachable
bb17:
  %t62 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t62, ptr %l33, !tbaa !27
  %t63 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t63, 0
  store i64 %t66, ptr %l36, !tbaa !24
  %t67 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t67, 0
  store i64 %t68, ptr %l37, !tbaa !24
  %t69 = icmp sge i64 1, 0
  br i1 %t69, label %bb18, label %bb19
bb18:
  %t71 = load i64, ptr %l36, !tbaa !24
  %t72 = icmp sle i64 1, %t71
  br i1 %t72, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_8c7e755ea0eb9876_6b14028370dd0cea)
  unreachable
bb20:
  %t74 = load i64, ptr %l36, !tbaa !24
  %t75 = load i64, ptr %l37, !tbaa !24
  %t76 = icmp sle i64 %t74, %t75
  br i1 %t76, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_8c7e755ea0eb9876_6b14028370dd0cea)
  unreachable
bb22:
  %t78 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = load i64, ptr %l36, !tbaa !24
  %t81 = getelementptr i8, ptr %t79, i64 1
  %t82 = sub i64 %t80, 1
  %t83 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t81, 1
  %t85 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t85, 1
  %t87 = extractvalue { i64, ptr } %t85, 0
  %t89 = extractvalue { i64, ptr } %t84, 1
  %t90 = extractvalue { i64, ptr } %t84, 0
  %t91 = add i64 %t87, %t90
  %t92 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t91)
  call void @olang_textcopy(ptr %t92, ptr %t86, i64 %t87)
  %t93 = getelementptr i8, ptr %t92, i64 %t87
  call void @olang_textcopy(ptr %t93, ptr %t89, i64 %t90)
  %t94 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t92, 1
  %t97 = extractvalue { i64, ptr } %t95, 0
  %t98 = extractvalue { i64, ptr } %t95, 1
  %t99 = mul i64 %t97, 1
  %t100 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t99)
  call void @llvm.memcpy.p0.p0.i64(ptr %t100, ptr %t98, i64 %t99, i1 false)
  %t101 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t100, 1
  %t104 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoRule(ptr %s2, ptr %s2, { i64, ptr } %t102)
  store %"compiler/msgs:Msg" %t104, ptr %l44
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_8c7e755ea0eb9876_6b14028370dd0cea)
  unreachable
bb24:
  %t105 = load ptr, ptr %l24, !tbaa !29
  %t106 = load { i64, [3 x i64] }, ptr %l25
  %t107 = load %"compiler/msgs:Msg", ptr %l44
  %t108 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v1, ptr %s2, ptr %t105, { i64, [3 x i64] } %t106, %"compiler/msgs:Msg" %t107)
  store i64 %t108, ptr %l45
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t110 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t110, ptr %rv
  br label %ret
bb26:
  %t111 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t111, ptr %lp4
  %t112 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t113 = load ptr, ptr %lp4
  store { i64, ptr } %t112, ptr %t113, !tbaa !27
  %t114 = load ptr, ptr %lp4
  %t115 = load { i64, ptr }, ptr %t114, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t117 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t115, 1
  store { i32, { i64, ptr } } %t117, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local void @compiler_2folang_2eexplainedSrc_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t1 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d205, i32 0, i32 1) }, 1
  %t2 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d205, i32 0, i32 1) }, 0
  %t3 = extractvalue { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d206, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d206, i32 0, i32 1) }, 0
  %t5 = add i64 %t2, %t4
  %t6 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d207, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d207, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t9 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d208, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d208, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t12 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d209, i32 0, i32 1) }, 1
  %t13 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d209, i32 0, i32 1) }, 0
  %t14 = add i64 %t11, %t13
  %t15 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d210, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d210, i32 0, i32 1) }, 0
  %t17 = add i64 %t14, %t16
  %t18 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d211, i32 0, i32 1) }, 1
  %t19 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d211, i32 0, i32 1) }, 0
  %t20 = add i64 %t17, %t19
  %t21 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d212, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d212, i32 0, i32 1) }, 0
  %t23 = add i64 %t20, %t22
  %t24 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d213, i32 0, i32 1) }, 1
  %t25 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d213, i32 0, i32 1) }, 0
  %t26 = add i64 %t23, %t25
  %t27 = extractvalue { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d214, i32 0, i32 1) }, 1
  %t28 = extractvalue { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d214, i32 0, i32 1) }, 0
  %t29 = add i64 %t26, %t28
  %t30 = extractvalue { i64, ptr } { i64 62, ptr getelementptr inbounds (<{ i64, [62 x i8] }>, ptr @.d215, i32 0, i32 1) }, 1
  %t31 = extractvalue { i64, ptr } { i64 62, ptr getelementptr inbounds (<{ i64, [62 x i8] }>, ptr @.d215, i32 0, i32 1) }, 0
  %t32 = add i64 %t29, %t31
  %t33 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d216, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d216, i32 0, i32 1) }, 0
  %t35 = add i64 %t32, %t34
  %t36 = extractvalue { i64, ptr } { i64 85, ptr getelementptr inbounds (<{ i64, [85 x i8] }>, ptr @.d217, i32 0, i32 1) }, 1
  %t37 = extractvalue { i64, ptr } { i64 85, ptr getelementptr inbounds (<{ i64, [85 x i8] }>, ptr @.d217, i32 0, i32 1) }, 0
  %t38 = add i64 %t35, %t37
  %t39 = extractvalue { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d218, i32 0, i32 1) }, 1
  %t40 = extractvalue { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d218, i32 0, i32 1) }, 0
  %t41 = add i64 %t38, %t40
  %t42 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d219, i32 0, i32 1) }, 1
  %t43 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d219, i32 0, i32 1) }, 0
  %t44 = add i64 %t41, %t43
  %t45 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d220, i32 0, i32 1) }, 1
  %t46 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d220, i32 0, i32 1) }, 0
  %t47 = add i64 %t44, %t46
  %t48 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d221, i32 0, i32 1) }, 1
  %t49 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d221, i32 0, i32 1) }, 0
  %t50 = add i64 %t47, %t49
  %t51 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d222, i32 0, i32 1) }, 1
  %t52 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d222, i32 0, i32 1) }, 0
  %t53 = add i64 %t50, %t52
  %t54 = extractvalue { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d223, i32 0, i32 1) }, 1
  %t55 = extractvalue { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d223, i32 0, i32 1) }, 0
  %t56 = add i64 %t53, %t55
  %t57 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d213, i32 0, i32 1) }, 1
  %t58 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d213, i32 0, i32 1) }, 0
  %t59 = add i64 %t56, %t58
  %t60 = load ptr, ptr @__olang_prog_scope
  %t61 = call ptr @__olang_scope_alloc(ptr %t60, i64 %t59)
  call void @olang_textcopy(ptr %t61, ptr %t1, i64 %t2)
  %t62 = getelementptr i8, ptr %t61, i64 %t2
  call void @olang_textcopy(ptr %t62, ptr %t3, i64 %t4)
  %t63 = getelementptr i8, ptr %t62, i64 %t4
  call void @olang_textcopy(ptr %t63, ptr %t6, i64 %t7)
  %t64 = getelementptr i8, ptr %t63, i64 %t7
  call void @olang_textcopy(ptr %t64, ptr %t9, i64 %t10)
  %t65 = getelementptr i8, ptr %t64, i64 %t10
  call void @olang_textcopy(ptr %t65, ptr %t12, i64 %t13)
  %t66 = getelementptr i8, ptr %t65, i64 %t13
  call void @olang_textcopy(ptr %t66, ptr %t15, i64 %t16)
  %t67 = getelementptr i8, ptr %t66, i64 %t16
  call void @olang_textcopy(ptr %t67, ptr %t18, i64 %t19)
  %t68 = getelementptr i8, ptr %t67, i64 %t19
  call void @olang_textcopy(ptr %t68, ptr %t21, i64 %t22)
  %t69 = getelementptr i8, ptr %t68, i64 %t22
  call void @olang_textcopy(ptr %t69, ptr %t24, i64 %t25)
  %t70 = getelementptr i8, ptr %t69, i64 %t25
  call void @olang_textcopy(ptr %t70, ptr %t27, i64 %t28)
  %t71 = getelementptr i8, ptr %t70, i64 %t28
  call void @olang_textcopy(ptr %t71, ptr %t30, i64 %t31)
  %t72 = getelementptr i8, ptr %t71, i64 %t31
  call void @olang_textcopy(ptr %t72, ptr %t33, i64 %t34)
  %t73 = getelementptr i8, ptr %t72, i64 %t34
  call void @olang_textcopy(ptr %t73, ptr %t36, i64 %t37)
  %t74 = getelementptr i8, ptr %t73, i64 %t37
  call void @olang_textcopy(ptr %t74, ptr %t39, i64 %t40)
  %t75 = getelementptr i8, ptr %t74, i64 %t40
  call void @olang_textcopy(ptr %t75, ptr %t42, i64 %t43)
  %t76 = getelementptr i8, ptr %t75, i64 %t43
  call void @olang_textcopy(ptr %t76, ptr %t45, i64 %t46)
  %t77 = getelementptr i8, ptr %t76, i64 %t46
  call void @olang_textcopy(ptr %t77, ptr %t48, i64 %t49)
  %t78 = getelementptr i8, ptr %t77, i64 %t49
  call void @olang_textcopy(ptr %t78, ptr %t51, i64 %t52)
  %t79 = getelementptr i8, ptr %t78, i64 %t52
  call void @olang_textcopy(ptr %t79, ptr %t54, i64 %t55)
  %t80 = getelementptr i8, ptr %t79, i64 %t55
  call void @olang_textcopy(ptr %t80, ptr %t57, i64 %t58)
  %t81 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t61, 1
  %t84 = load ptr, ptr @__olang_prog_scope
  %t85 = extractvalue { i64, ptr } %t82, 0
  %t86 = extractvalue { i64, ptr } %t82, 1
  %t87 = mul i64 %t85, 1
  %t88 = call ptr @__olang_scope_alloc(ptr %t84, i64 %t87)
  call void @llvm.memcpy.p0.p0.i64(ptr %t88, ptr %t86, i64 %t87, i1 false)
  %t89 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  store { i64, ptr } %t90, ptr @G_2ecompiler_2folang_2eexplainedSrc, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2folang_2eformat(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l9 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/olang:CommandLine", ptr %t1, i32 0, i32 9
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d224, i32 0, i32 1) }, ptr %l3, !tbaa !27
  br label %bb3
bb2:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d225, i32 0, i32 1) }, ptr %l3, !tbaa !27
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/olang:CommandLine", ptr %t6, i32 0, i32 1
  %t10 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v0, ptr %v0, ptr %t8)
  store { i64, ptr } %t10, ptr %l6
  br label %bb4
bb4:
  %t11 = call { i64, ptr } @compiler_2fload_2eStdDir(ptr %s0)
  store { i64, ptr } %t11, ptr %l7
  br label %bb5
bb5:
  %t12 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 0
  %t14 = extractvalue { i64, ptr } %t12, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t19 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t20 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t22 = call i32 @compiler_2ffmt_2eFiles(ptr %s0, ptr %v0, ptr %s0, { i64, ptr } %t19, { i64, ptr } %t20, { i64, ptr } %t18)
  store i32 %t22, ptr %l9
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load i32, ptr %l9, !tbaa !23
  store i32 %t23, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2folang_2ehelp(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i1
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca %"std/prelude/text:StringBuilder"
  %l23 = alloca ptr
  %l24 = alloca { i64, ptr }
  %l29 = alloca [13 x { i64, ptr }]
  %l34 = alloca i64
  %l37 = alloca i64
  %l55 = alloca ptr
  %l58 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l69 = alloca i64
  %l70 = alloca { i64, ptr }
  %l73 = alloca i1
  %l74 = alloca i64
  %l78 = alloca i64
  %l81 = alloca ptr
  %l84 = alloca %"compiler/msgs:Msg"
  %l85 = alloca i32
  %l94 = alloca [14 x { i64, ptr }]
  %l99 = alloca i64
  %l102 = alloca i64
  %l122 = alloca i64
  %l130 = alloca { i64, ptr }
  %l133 = alloca i1
  %l135 = alloca { i64, ptr }
  %l139 = alloca ptr
  %l141 = alloca { i64, ptr }
  %l149 = alloca { i64, ptr }
  %l150 = alloca { i64, ptr }
  %l151 = alloca i64
  %l152 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l18
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l18
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/olang:CommandLine", ptr %t3, i32 0, i32 4
  %t6 = load i1, ptr %t5, !tbaa !21
  %t8 = xor i1 %t6, true
  br i1 %t8, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s1, ptr %l2, { i64, ptr } { i64 96, ptr getelementptr inbounds (<{ i64, [96 x i8] }>, ptr @.d226, i32 0, i32 1) })
  br label %bb4
bb3:
  br label %bb23
bb4:
  store ptr %l2, ptr %l23, !tbaa !29
  %t11 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadEnd(ptr %s1, ptr %s1, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d227, i32 0, i32 1) }, i64 11, i8 32)
  store { i64, ptr } %t11, ptr %l24
  br label %bb5
bb5:
  %t12 = load i64, ptr @G_2ecompiler_2folang_2eRun, !tbaa !24
  %t14 = getelementptr [13 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eModeWhat, i64 0, i64 %t12
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !37
  %t16 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d228, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d228, i32 0, i32 1) }, 0
  %t18 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t18, 1
  %t20 = extractvalue { i64, ptr } %t18, 0
  %t21 = add i64 %t17, %t20
  %t22 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d229, i32 0, i32 1) }, 1
  %t23 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d229, i32 0, i32 1) }, 0
  %t24 = add i64 %t21, %t23
  %t26 = extractvalue { i64, ptr } %t15, 1
  %t27 = extractvalue { i64, ptr } %t15, 0
  %t28 = add i64 %t24, %t27
  %t29 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d230, i32 0, i32 1) }, 1
  %t30 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d230, i32 0, i32 1) }, 0
  %t31 = add i64 %t28, %t30
  %t32 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t31)
  call void @olang_textcopy(ptr %t32, ptr %t16, i64 %t17)
  %t33 = getelementptr i8, ptr %t32, i64 %t17
  call void @olang_textcopy(ptr %t33, ptr %t19, i64 %t20)
  %t34 = getelementptr i8, ptr %t33, i64 %t20
  call void @olang_textcopy(ptr %t34, ptr %t22, i64 %t23)
  %t35 = getelementptr i8, ptr %t34, i64 %t23
  call void @olang_textcopy(ptr %t35, ptr %t26, i64 %t27)
  %t36 = getelementptr i8, ptr %t35, i64 %t27
  call void @olang_textcopy(ptr %t36, ptr %t29, i64 %t30)
  %t37 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t32, 1
  %t40 = extractvalue { i64, ptr } %t38, 0
  %t41 = extractvalue { i64, ptr } %t38, 1
  %t42 = mul i64 %t40, 1
  %t43 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t42)
  call void @llvm.memcpy.p0.p0.i64(ptr %t43, ptr %t41, i64 %t42, i1 false)
  %t44 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  %t46 = load ptr, ptr %l23, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s1, ptr %t46, { i64, ptr } %t45)
  br label %bb6
bb6:
  store i64 1, ptr %l3, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l29, ptr @G_2ecompiler_2folang_2eModeWords, i64 208, i1 false)
  %t48 = load [13 x { i64, ptr }], ptr %l29
  store i64 13, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t50 = load i64, ptr %l4, !tbaa !24
  %t51 = load i64, ptr %l3, !tbaa !24
  %t54 = icmp sgt i64 %t50, %t51
  br i1 %t54, label %bb7, label %bb8
bb7:
  %t56 = load i64, ptr %l5, !tbaa !24
  %t58 = icmp sgt i64 %t56, 0
  br i1 %t58, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb12
bb9:
  %t60 = load i64, ptr %l4, !tbaa !24
  %t61 = load i64, ptr %l3, !tbaa !24
  %t64 = sub i64 %t60, %t61
  %t65 = load i64, ptr %l5, !tbaa !24
  %t68 = add i64 %t64, %t65
  %t70 = sub i64 %t68, 1
  %t71 = load i64, ptr %l5, !tbaa !24
  %t74 = sdiv i64 %t70, %t71
  store i64 %t74, ptr %l37, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb11
bb11:
  %t76 = load i64, ptr %l37, !tbaa !24
  store i64 %t76, ptr %l34, !tbaa !24
  br label %bb12
bb12:
  %t77 = load i64, ptr %l34, !tbaa !24
  store i64 %t77, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s4
  %t78 = load i64, ptr %l7, !tbaa !24
  %t79 = load i64, ptr %l6, !tbaa !24
  %t82 = icmp slt i64 %t78, %t79
  %t84 = xor i1 %t82, true
  br i1 %t84, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s4)
  br label %bb20
bb15:
  br label %bb16
bb16:
  %t86 = load i64, ptr %l3, !tbaa !24
  %t87 = load i64, ptr %l7, !tbaa !24
  %t88 = load i64, ptr %l5, !tbaa !24
  %t91 = mul i64 %t87, %t88
  %t94 = add i64 %t86, %t91
  store i64 %t94, ptr %l8, !tbaa !24
  store ptr %l2, ptr %l55, !tbaa !29
  %t96 = load i64, ptr %l8, !tbaa !24
  %t98 = getelementptr [13 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eModeWords, i64 0, i64 %t96
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !37
  %t100 = load ptr, ptr @__olang_prog_scope
  %t102 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadEnd(ptr %t100, ptr %s4, { i64, ptr } %t99, i64 11, i8 32)
  store { i64, ptr } %t102, ptr %l58
  br label %bb17
bb17:
  %t103 = load i64, ptr %l8, !tbaa !24
  %t105 = getelementptr [13 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eModeWhat, i64 0, i64 %t103
  %t106 = load { i64, ptr }, ptr %t105, !tbaa !37
  %t107 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d231, i32 0, i32 1) }, 1
  %t108 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d231, i32 0, i32 1) }, 0
  %t109 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t109, 1
  %t111 = extractvalue { i64, ptr } %t109, 0
  %t112 = add i64 %t108, %t111
  %t113 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d232, i32 0, i32 1) }, 1
  %t114 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d232, i32 0, i32 1) }, 0
  %t115 = add i64 %t112, %t114
  %t117 = extractvalue { i64, ptr } %t106, 1
  %t118 = extractvalue { i64, ptr } %t106, 0
  %t119 = add i64 %t115, %t118
  %t120 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d233, i32 0, i32 1) }, 1
  %t121 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d233, i32 0, i32 1) }, 0
  %t122 = add i64 %t119, %t121
  %t123 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t122)
  call void @olang_textcopy(ptr %t123, ptr %t107, i64 %t108)
  %t124 = getelementptr i8, ptr %t123, i64 %t108
  call void @olang_textcopy(ptr %t124, ptr %t110, i64 %t111)
  %t125 = getelementptr i8, ptr %t124, i64 %t111
  call void @olang_textcopy(ptr %t125, ptr %t113, i64 %t114)
  %t126 = getelementptr i8, ptr %t125, i64 %t114
  call void @olang_textcopy(ptr %t126, ptr %t117, i64 %t118)
  %t127 = getelementptr i8, ptr %t126, i64 %t118
  call void @olang_textcopy(ptr %t127, ptr %t120, i64 %t121)
  %t128 = insertvalue { i64, ptr } undef, i64 %t122, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t123, 1
  %t131 = extractvalue { i64, ptr } %t129, 0
  %t132 = extractvalue { i64, ptr } %t129, 1
  %t133 = mul i64 %t131, 1
  %t134 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t133)
  call void @llvm.memcpy.p0.p0.i64(ptr %t134, ptr %t132, i64 %t133, i1 false)
  %t135 = insertvalue { i64, ptr } undef, i64 %t131, 0
  %t136 = insertvalue { i64, ptr } %t135, ptr %t134, 1
  %t137 = load ptr, ptr %l55, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %t137, { i64, ptr } %t136)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s4)
  br label %bb19
bb19:
  %t139 = load i64, ptr %l7, !tbaa !24
  %t141 = add i64 %t139, 1
  store i64 %t141, ptr %l7, !tbaa !24
  br label %bb13
bb20:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s1, ptr %l2, { i64, ptr } { i64 85, ptr getelementptr inbounds (<{ i64, [85 x i8] }>, ptr @.d234, i32 0, i32 1) })
  br label %bb21
bb21:
  %t145 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l2)
  store { i64, ptr } %t145, ptr %l67
  br label %bb22
bb22:
  %t146 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t146, ptr %l68, !tbaa !27
  %t147 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t148 = extractvalue { i64, ptr } %t147, 0
  store i64 %t148, ptr %l69, !tbaa !24
  %t149 = load i64, ptr %l69, !tbaa !24
  %t150 = mul i64 %t149, 1
  %t151 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t150)
  %t152 = insertvalue { i64, ptr } undef, i64 %t149, 0
  %t153 = insertvalue { i64, ptr } %t152, ptr %t151, 1
  store { i64, ptr } %t153, ptr %l70, !tbaa !27
  %t154 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !27
  %t156 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !27
  %t158 = load i64, ptr %l69, !tbaa !24
  %t159 = mul i64 %t158, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t155, ptr %t157, i64 %t159, i1 false)
  %t160 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t160, ptr %l68, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t161 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t162 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t161, 1
  store { i32, { i64, ptr } } %t162, ptr %rv
  br label %ret
bb23:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t165 = getelementptr %"compiler/olang:CommandLine", ptr %t163, i32 0, i32 3
  %t166 = load { i64, ptr }, ptr %t165, !tbaa !27
  %t168 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t166, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d235, i32 0, i32 1) })
  store i1 %t168, ptr %l73
  br label %bb24
bb24:
  %t169 = load i1, ptr %l73, !tbaa !21
  br i1 %t169, label %bb25, label %bb26
bb25:
  %t170 = load i64, ptr @G_2ecompiler_2folang_2eRun, !tbaa !24
  store i64 %t170, ptr %l74, !tbaa !24
  br label %bb28
bb26:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t174 = getelementptr %"compiler/olang:CommandLine", ptr %t172, i32 0, i32 3
  %t175 = load { i64, ptr }, ptr %t174, !tbaa !27
  %t177 = call i64 @compiler_2folang_2emodeNumber(ptr %v0, { i64, ptr } %t175)
  store i64 %t177, ptr %l78
  br label %bb27
bb27:
  %t178 = load i64, ptr %l78, !tbaa !24
  store i64 %t178, ptr %l74, !tbaa !24
  br label %bb28
bb28:
  %t179 = load i64, ptr %l74, !tbaa !24
  store i64 %t179, ptr %l9, !tbaa !24
  %t180 = load i64, ptr %l9, !tbaa !24
  %t182 = icmp slt i64 %t180, 0
  br i1 %t182, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s7
  store ptr %a1, ptr %l81, !tbaa !29
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/olang:CommandLine", ptr %t185, i32 0, i32 3
  %t188 = load { i64, ptr }, ptr %t187, !tbaa !27
  %t190 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotAMode(ptr %v0, ptr %s7, { i64, ptr } %t188)
  store %"compiler/msgs:Msg" %t190, ptr %l84
  br label %bb31
bb30:
  br label %bb35
bb31:
  %t191 = load ptr, ptr %l81, !tbaa !29
  %t192 = load %"compiler/msgs:Msg", ptr %l84
  %t193 = call i32 @compiler_2folang_2eusage(ptr %v1, ptr %s7, ptr %t191, %"compiler/msgs:Msg" %t192)
  store i32 %t193, ptr %l85
  %t194 = icmp ne i32 %t193, 0
  br i1 %t194, label %bb33, label %ok.195
ok.195:
  br label %bb32
bb32:
  br label %bb34
bb33:
  %t196 = load i32, ptr %l85, !tbaa !23
  %t197 = lshr i32 %t196, 16
  %t198 = and i32 %t196, 65535
  %t199 = icmp eq i32 %t197, 1
  %t200 = select i1 %t199, i32 1, i32 0
  %t201 = icmp eq i32 %t196, 0
  %t202 = shl i32 %t200, 16
  %t203 = or i32 %t202, %t198
  %t204 = select i1 %t201, i32 0, i32 %t203
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  %t206 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t204, 0
  store { i32, { i64, ptr } } %t206, ptr %rv
  br label %ret
bb34:
  call void @__olang_scope_close(ptr %s7)
  br label %bb35
bb35:
  %t207 = load i64, ptr %l9, !tbaa !24
  %t209 = getelementptr [13 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eModeUsage, i64 0, i64 %t207
  %t210 = load { i64, ptr }, ptr %t209, !tbaa !37
  %t211 = load i64, ptr %l9, !tbaa !24
  %t213 = getelementptr [13 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eModeWhat, i64 0, i64 %t211
  %t214 = load { i64, ptr }, ptr %t213, !tbaa !37
  %t215 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d236, i32 0, i32 1) }, 1
  %t216 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d236, i32 0, i32 1) }, 0
  %t218 = extractvalue { i64, ptr } %t210, 1
  %t219 = extractvalue { i64, ptr } %t210, 0
  %t220 = add i64 %t216, %t219
  %t221 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d237, i32 0, i32 1) }, 1
  %t222 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d237, i32 0, i32 1) }, 0
  %t223 = add i64 %t220, %t222
  %t225 = extractvalue { i64, ptr } %t214, 1
  %t226 = extractvalue { i64, ptr } %t214, 0
  %t227 = add i64 %t223, %t226
  %t228 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d237, i32 0, i32 1) }, 1
  %t229 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d237, i32 0, i32 1) }, 0
  %t230 = add i64 %t227, %t229
  %t231 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t230)
  call void @olang_textcopy(ptr %t231, ptr %t215, i64 %t216)
  %t232 = getelementptr i8, ptr %t231, i64 %t216
  call void @olang_textcopy(ptr %t232, ptr %t218, i64 %t219)
  %t233 = getelementptr i8, ptr %t232, i64 %t219
  call void @olang_textcopy(ptr %t233, ptr %t221, i64 %t222)
  %t234 = getelementptr i8, ptr %t233, i64 %t222
  call void @olang_textcopy(ptr %t234, ptr %t225, i64 %t226)
  %t235 = getelementptr i8, ptr %t234, i64 %t226
  call void @olang_textcopy(ptr %t235, ptr %t228, i64 %t229)
  %t236 = insertvalue { i64, ptr } undef, i64 %t230, 0
  %t237 = insertvalue { i64, ptr } %t236, ptr %t231, 1
  %t239 = extractvalue { i64, ptr } %t237, 0
  %t240 = extractvalue { i64, ptr } %t237, 1
  %t241 = mul i64 %t239, 1
  %t242 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t241)
  call void @llvm.memcpy.p0.p0.i64(ptr %t242, ptr %t240, i64 %t241, i1 false)
  %t243 = insertvalue { i64, ptr } undef, i64 %t239, 0
  %t244 = insertvalue { i64, ptr } %t243, ptr %t242, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } %t244)
  br label %bb36
bb36:
  store i1 false, ptr %l10, !tbaa !21
  store i64 0, ptr %l11, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l94, ptr @G_2ecompiler_2folang_2eOptWords, i64 224, i1 false)
  %t247 = load [14 x { i64, ptr }], ptr %l94
  store i64 14, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t249 = load i64, ptr %l12, !tbaa !24
  %t250 = load i64, ptr %l11, !tbaa !24
  %t253 = icmp sgt i64 %t249, %t250
  br i1 %t253, label %bb37, label %bb38
bb37:
  %t255 = load i64, ptr %l13, !tbaa !24
  %t257 = icmp sgt i64 %t255, 0
  br i1 %t257, label %bb39, label %bb40
bb38:
  store i64 0, ptr %l99, !tbaa !24
  br label %bb42
bb39:
  %t259 = load i64, ptr %l12, !tbaa !24
  %t260 = load i64, ptr %l11, !tbaa !24
  %t263 = sub i64 %t259, %t260
  %t264 = load i64, ptr %l13, !tbaa !24
  %t267 = add i64 %t263, %t264
  %t269 = sub i64 %t267, 1
  %t270 = load i64, ptr %l13, !tbaa !24
  %t273 = sdiv i64 %t269, %t270
  store i64 %t273, ptr %l102, !tbaa !24
  br label %bb41
bb40:
  store i64 0, ptr %l102, !tbaa !24
  br label %bb41
bb41:
  %t275 = load i64, ptr %l102, !tbaa !24
  store i64 %t275, ptr %l99, !tbaa !24
  br label %bb42
bb42:
  %t276 = load i64, ptr %l99, !tbaa !24
  store i64 %t276, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb43
bb43:
  store %olang.scope zeroinitializer, ptr %s10
  %t277 = load i64, ptr %l15, !tbaa !24
  %t278 = load i64, ptr %l14, !tbaa !24
  %t281 = icmp slt i64 %t277, %t278
  %t283 = xor i1 %t281, true
  br i1 %t283, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s10)
  br label %bb61
bb45:
  br label %bb46
bb46:
  %t285 = load i64, ptr %l11, !tbaa !24
  %t286 = load i64, ptr %l15, !tbaa !24
  %t287 = load i64, ptr %l13, !tbaa !24
  %t290 = mul i64 %t286, %t287
  %t293 = add i64 %t285, %t290
  store i64 %t293, ptr %l16, !tbaa !24
  %t295 = load i64, ptr %l16, !tbaa !24
  %t297 = getelementptr [14 x i64], ptr @G_2ecompiler_2folang_2eOptModes, i64 0, i64 %t295
  %t298 = load i64, ptr %t297, !tbaa !34
  %t299 = load i64, ptr %l9, !tbaa !24
  store i64 %t299, ptr %l122, !tbaa !24
  %t301 = load i64, ptr %l122, !tbaa !24
  %t302 = load i64, ptr %l122, !tbaa !24
  %t303 = ashr i64 %t298, %t302
  %t305 = and i64 %t303, 1
  %t307 = icmp eq i64 %t305, 0
  br i1 %t307, label %bb47, label %bb48
bb47:
  call void @__olang_scope_close(ptr %s10)
  br label %bb60
bb48:
  br label %bb49
bb49:
  %t309 = load i1, ptr %l10, !tbaa !21
  %t311 = xor i1 %t309, true
  br i1 %t311, label %bb50, label %bb51
bb50:
  store %olang.scope zeroinitializer, ptr %s12
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s12, ptr %l2, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d238, i32 0, i32 1) })
  br label %bb52
bb51:
  br label %bb53
bb52:
  call void @__olang_scope_close(ptr %s12)
  br label %bb53
bb53:
  store i1 true, ptr %l10, !tbaa !21
  %t314 = load i64, ptr %l16, !tbaa !24
  %t316 = getelementptr [14 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eOptWords, i64 0, i64 %t314
  %t317 = load { i64, ptr }, ptr %t316, !tbaa !37
  store { i64, ptr } %t317, ptr %l130, !tbaa !27
  %t318 = load i64, ptr %l16, !tbaa !24
  %t320 = getelementptr [14 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eOptValues, i64 0, i64 %t318
  %t321 = load { i64, ptr }, ptr %t320, !tbaa !37
  %t322 = load ptr, ptr @__olang_prog_scope
  %t324 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t322, ptr %s10, { i64, ptr } %t321, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d239, i32 0, i32 1) })
  store i1 %t324, ptr %l133
  br label %bb54
bb54:
  %t325 = load i1, ptr %l133, !tbaa !21
  %t326 = xor i1 %t325, true
  br i1 %t326, label %bb55, label %bb56
bb55:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d240, i32 0, i32 1) }, ptr %l135, !tbaa !27
  br label %bb57
bb56:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d241, i32 0, i32 1) }, ptr %l135, !tbaa !27
  br label %bb57
bb57:
  %t328 = load i64, ptr %l16, !tbaa !24
  %t330 = getelementptr [14 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eOptValues, i64 0, i64 %t328
  %t331 = load { i64, ptr }, ptr %t330, !tbaa !37
  %t332 = load { i64, ptr }, ptr %l130, !tbaa !27
  %t333 = extractvalue { i64, ptr } %t332, 1
  %t334 = extractvalue { i64, ptr } %t332, 0
  %t335 = load { i64, ptr }, ptr %l135, !tbaa !27
  %t336 = extractvalue { i64, ptr } %t335, 1
  %t337 = extractvalue { i64, ptr } %t335, 0
  %t338 = add i64 %t334, %t337
  %t340 = extractvalue { i64, ptr } %t331, 1
  %t341 = extractvalue { i64, ptr } %t331, 0
  %t342 = add i64 %t338, %t341
  %t343 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t342)
  call void @olang_textcopy(ptr %t343, ptr %t333, i64 %t334)
  %t344 = getelementptr i8, ptr %t343, i64 %t334
  call void @olang_textcopy(ptr %t344, ptr %t336, i64 %t337)
  %t345 = getelementptr i8, ptr %t344, i64 %t337
  call void @olang_textcopy(ptr %t345, ptr %t340, i64 %t341)
  %t346 = insertvalue { i64, ptr } undef, i64 %t342, 0
  %t347 = insertvalue { i64, ptr } %t346, ptr %t343, 1
  store ptr %l2, ptr %l139, !tbaa !29
  %t351 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadEnd(ptr %s10, ptr %s10, { i64, ptr } %t347, i64 18, i8 32)
  store { i64, ptr } %t351, ptr %l141
  br label %bb58
bb58:
  %t352 = load i64, ptr %l16, !tbaa !24
  %t354 = getelementptr [14 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eOptWhat, i64 0, i64 %t352
  %t355 = load { i64, ptr }, ptr %t354, !tbaa !37
  %t356 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d242, i32 0, i32 1) }, 1
  %t357 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d242, i32 0, i32 1) }, 0
  %t358 = load { i64, ptr }, ptr %l141, !tbaa !27
  %t359 = extractvalue { i64, ptr } %t358, 1
  %t360 = extractvalue { i64, ptr } %t358, 0
  %t361 = add i64 %t357, %t360
  %t362 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d243, i32 0, i32 1) }, 1
  %t363 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d243, i32 0, i32 1) }, 0
  %t364 = add i64 %t361, %t363
  %t366 = extractvalue { i64, ptr } %t355, 1
  %t367 = extractvalue { i64, ptr } %t355, 0
  %t368 = add i64 %t364, %t367
  %t369 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d244, i32 0, i32 1) }, 1
  %t370 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d244, i32 0, i32 1) }, 0
  %t371 = add i64 %t368, %t370
  %t372 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t371)
  call void @olang_textcopy(ptr %t372, ptr %t356, i64 %t357)
  %t373 = getelementptr i8, ptr %t372, i64 %t357
  call void @olang_textcopy(ptr %t373, ptr %t359, i64 %t360)
  %t374 = getelementptr i8, ptr %t373, i64 %t360
  call void @olang_textcopy(ptr %t374, ptr %t362, i64 %t363)
  %t375 = getelementptr i8, ptr %t374, i64 %t363
  call void @olang_textcopy(ptr %t375, ptr %t366, i64 %t367)
  %t376 = getelementptr i8, ptr %t375, i64 %t367
  call void @olang_textcopy(ptr %t376, ptr %t369, i64 %t370)
  %t377 = insertvalue { i64, ptr } undef, i64 %t371, 0
  %t378 = insertvalue { i64, ptr } %t377, ptr %t372, 1
  %t380 = extractvalue { i64, ptr } %t378, 0
  %t381 = extractvalue { i64, ptr } %t378, 1
  %t382 = mul i64 %t380, 1
  %t383 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t382)
  call void @llvm.memcpy.p0.p0.i64(ptr %t383, ptr %t381, i64 %t382, i1 false)
  %t384 = insertvalue { i64, ptr } undef, i64 %t380, 0
  %t385 = insertvalue { i64, ptr } %t384, ptr %t383, 1
  %t386 = load ptr, ptr %l139, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s10, ptr %t386, { i64, ptr } %t385)
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s10)
  br label %bb60
bb60:
  %t388 = load i64, ptr %l15, !tbaa !24
  %t390 = add i64 %t388, 1
  store i64 %t390, ptr %l15, !tbaa !24
  br label %bb43
bb61:
  %t393 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l2)
  store { i64, ptr } %t393, ptr %l149
  br label %bb62
bb62:
  %t394 = load { i64, ptr }, ptr %l149, !tbaa !27
  store { i64, ptr } %t394, ptr %l150, !tbaa !27
  %t395 = load { i64, ptr }, ptr %l150, !tbaa !27
  %t396 = extractvalue { i64, ptr } %t395, 0
  store i64 %t396, ptr %l151, !tbaa !24
  %t397 = load i64, ptr %l151, !tbaa !24
  %t398 = mul i64 %t397, 1
  %t399 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t398)
  %t400 = insertvalue { i64, ptr } undef, i64 %t397, 0
  %t401 = insertvalue { i64, ptr } %t400, ptr %t399, 1
  store { i64, ptr } %t401, ptr %l152, !tbaa !27
  %t402 = getelementptr { i64, ptr }, ptr %l152, i32 0, i32 1
  %t403 = load ptr, ptr %t402, !tbaa !27
  %t404 = getelementptr { i64, ptr }, ptr %l150, i32 0, i32 1
  %t405 = load ptr, ptr %t404, !tbaa !27
  %t406 = load i64, ptr %l151, !tbaa !24
  %t407 = mul i64 %t406, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t403, ptr %t405, i64 %t407, i1 false)
  %t408 = load { i64, ptr }, ptr %l152, !tbaa !27
  store { i64, ptr } %t408, ptr %l150, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t409 = load { i64, ptr }, ptr %l150, !tbaa !27
  %t410 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t409, 1
  store { i32, { i64, ptr } } %t410, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local void @compiler_2folang_2ekeep(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, { i64, ptr } %a2, ptr %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca %"compiler/emit:Reused"
  %l10 = alloca { i64, ptr }
  %l11 = alloca %"std/prelude/text:StringBuilder"
  %l12 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca i1
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l24 = alloca i64
  %l30 = alloca i32
  %l32 = alloca i1
  %l33 = alloca i32
  %l35 = alloca i64
  %l37 = alloca i64
  %l42 = alloca %"compiler/emit:Reused"
  %l47 = alloca i1
  %l48 = alloca { i64, ptr }
  %l51 = alloca i1
  %l52 = alloca ptr
  %l56 = alloca ptr
  %l59 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l63 = alloca %"std/prelude/text:StringBuilder"
  %l64 = alloca ptr
  %l65 = alloca i64
  %l67 = alloca { i64, ptr }
  %l70 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l72 = alloca i64
  %l74 = alloca i64
  %l79 = alloca { i64, ptr }
  %l82 = alloca i1
  %l92 = alloca i64
  %l96 = alloca i64
  %l99 = alloca i64
  %l120 = alloca { i64, ptr }
  %l126 = alloca %"compiler/emit:Object"
  %l129 = alloca i1
  %l131 = alloca ptr
  %l134 = alloca i1
  %l135 = alloca { i64, ptr }
  %l140 = alloca { i64, ptr }
  %l143 = alloca { i64, ptr }
  %l151 = alloca { i64, ptr }
  %l153 = alloca { i64, ptr }
  %l155 = alloca i1
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s14 = alloca %olang.scope
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t3 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2femit_3aReused_3e_2eLen_3ccompiler_2femit_3aReused_3e(ptr %v3, ptr %t1)
  store i64 %t3, ptr %l24
  br label %bb1
bb1:
  %t4 = load i64, ptr %l24, !tbaa !24
  %t5 = icmp eq i64 %t4, 0
  br i1 %t5, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t9 = getelementptr %"compiler/build:Config", ptr %t7, i32 0, i32 0
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 1
  %t13 = extractvalue { i64, ptr } %t10, 0
  %t14 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d245, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d245, i32 0, i32 1) }, 0
  %t16 = add i64 %t13, %t15
  %t17 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t16)
  call void @olang_textcopy(ptr %t17, ptr %t12, i64 %t13)
  %t18 = getelementptr i8, ptr %t17, i64 %t13
  call void @olang_textcopy(ptr %t18, ptr %t14, i64 %t15)
  %t19 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t17, 1
  %t22 = extractvalue { i64, ptr } %t20, 0
  %t23 = extractvalue { i64, ptr } %t20, 1
  %t24 = mul i64 %t22, 1
  %t25 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  %t29 = call i32 @std_2fos_2eMkDirAll(ptr %s0, { i64, ptr } %t27)
  store i32 %t29, ptr %l30
  %t30 = icmp ne i32 %t29, 0
  br i1 %t30, label %bb6, label %ok.31
ok.31:
  br label %bb5
bb5:
  br label %bb8
bb6:
  %t32 = load i32, ptr %l30, !tbaa !23
  %t33 = ashr i32 %t32, 16
  %t35 = icmp eq i32 %t33, 1
  store i1 %t35, ptr %l32, !tbaa !21
  br label %bb7
bb7:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb8:
  %t36 = call i32 @compiler_2fbuild_2ePid()
  store i32 %t36, ptr %l33
  br label %bb9
bb9:
  %t37 = load i32, ptr %l33, !tbaa !23
  store i32 %t37, ptr %l6, !tbaa !23
  %t38 = load ptr, ptr %l3, !tbaa !29
  store ptr %t38, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s5
  %t40 = load i64, ptr %l8, !tbaa !24
  store i64 %t40, ptr %l35, !tbaa !24
  %t41 = load ptr, ptr %l7, !tbaa !29
  %t43 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2femit_3aReused_3e_2eLen_3ccompiler_2femit_3aReused_3e(ptr %v3, ptr %t41)
  store i64 %t43, ptr %l37
  br label %bb11
bb11:
  %t44 = load i64, ptr %l35, !tbaa !24
  %t45 = load i64, ptr %l37, !tbaa !24
  %t46 = icmp slt i64 %t44, %t45
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s5)
  br label %bb77
bb13:
  br label %bb14
bb14:
  %t50 = load ptr, ptr %l7, !tbaa !29
  %t51 = load i64, ptr %l8, !tbaa !24
  %t54 = call %"compiler/emit:Reused" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2femit_3aReused_3e_2eAt_3ccompiler_2femit_3aReused_3e(ptr %v3, ptr %v3, ptr %t50, i64 %t51)
  store %"compiler/emit:Reused" %t54, ptr %l42
  br label %bb15
bb15:
  %t55 = load %"compiler/emit:Reused", ptr %l42
  store %"compiler/emit:Reused" %t55, ptr %l9
  %t56 = getelementptr %"compiler/emit:Reused", ptr %l9, i32 0, i32 0
  %t57 = load i64, ptr %t56, !tbaa !24
  %t58 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t58, 0
  %t63 = icmp sge i64 %t57, %t60
  br i1 %t63, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l47, !tbaa !21
  br label %bb19
bb17:
  %t65 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t65, ptr %l48, !tbaa !27
  %t66 = getelementptr %"compiler/emit:Reused", ptr %l9, i32 0, i32 0
  %t67 = load i64, ptr %t66, !tbaa !24
  %t69 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr { i64, ptr }, ptr %t70, i64 %t67
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !37
  %t74 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s5, { i64, ptr } %t72, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d246, i32 0, i32 1) })
  store i1 %t74, ptr %l51
  br label %bb18
bb18:
  %t75 = load i1, ptr %l51, !tbaa !21
  store i1 %t75, ptr %l47, !tbaa !21
  br label %bb19
bb19:
  %t76 = load i1, ptr %l47, !tbaa !21
  br i1 %t76, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s5)
  br label %bb76
bb21:
  br label %bb22
bb22:
  %t77 = load ptr, ptr %l1, !tbaa !29
  store ptr %t77, ptr %l52, !tbaa !29
  %t80 = getelementptr %"compiler/load:Loader", ptr %a0, i32 0, i32 5
  %t81 = getelementptr %"compiler/emit:Reused", ptr %l9, i32 0, i32 0
  %t82 = load i64, ptr %t81, !tbaa !24
  %t85 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t80, i64 %t82)
  store ptr %t85, ptr %l56
  br label %bb23
bb23:
  %t86 = load ptr, ptr %l56, !tbaa !29
  %t88 = getelementptr %"compiler/load:Module", ptr %t86, i32 0, i32 2
  %t89 = load { i64, ptr }, ptr %t88, !tbaa !27
  %t90 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t90, ptr %l59, !tbaa !27
  %t91 = getelementptr %"compiler/emit:Reused", ptr %l9, i32 0, i32 0
  %t92 = load i64, ptr %t91, !tbaa !24
  %t94 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = getelementptr { i64, ptr }, ptr %t95, i64 %t92
  %t97 = load { i64, ptr }, ptr %t96, !tbaa !37
  %t98 = load ptr, ptr %l52, !tbaa !29
  %t101 = call { i64, ptr } @compiler_2folang_2erecordPath(ptr %v1, ptr %v0, ptr %v2, ptr %s5, ptr %t98, { i64, ptr } %t89, { i64, ptr } %t97)
  store { i64, ptr } %t101, ptr %l62
  br label %bb24
bb24:
  %t102 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t102, ptr %l10, !tbaa !27
  %t103 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s5)
  store %"std/prelude/text:StringBuilder" %t103, ptr %l63
  br label %bb25
bb25:
  %t104 = load %"std/prelude/text:StringBuilder", ptr %l63
  store %"std/prelude/text:StringBuilder" %t104, ptr %l11
  store ptr %l11, ptr %l64, !tbaa !29
  %t105 = getelementptr %"compiler/emit:Reused", ptr %l9, i32 0, i32 4
  %t106 = load i64, ptr %t105, !tbaa !24
  store i64 %t106, ptr %l65, !tbaa !24
  %t107 = getelementptr %"compiler/emit:Reused", ptr %l9, i32 0, i32 5
  %t108 = load i1, ptr %t107, !tbaa !21
  br i1 %t108, label %bb26, label %bb27
bb26:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d247, i32 0, i32 1) }, ptr %l67, !tbaa !27
  br label %bb28
bb27:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d248, i32 0, i32 1) }, ptr %l67, !tbaa !27
  br label %bb28
bb28:
  %t110 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d249, i32 0, i32 1) }, 1
  %t111 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d249, i32 0, i32 1) }, 0
  %t112 = load i64, ptr %l65, !tbaa !24
  %t113 = call i64 @__olang_fmt_i64(ptr null, i64 %t112)
  %t114 = add i64 %t111, %t113
  %t115 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d250, i32 0, i32 1) }, 1
  %t116 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d250, i32 0, i32 1) }, 0
  %t117 = add i64 %t114, %t116
  %t118 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t118, 1
  %t120 = extractvalue { i64, ptr } %t118, 0
  %t121 = add i64 %t117, %t120
  %t122 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d251, i32 0, i32 1) }, 1
  %t123 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d251, i32 0, i32 1) }, 0
  %t124 = add i64 %t121, %t123
  %t125 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t124)
  call void @olang_textcopy(ptr %t125, ptr %t110, i64 %t111)
  %t126 = getelementptr i8, ptr %t125, i64 %t111
  %t127 = call i64 @__olang_fmt_i64(ptr %t126, i64 %t112)
  %t128 = getelementptr i8, ptr %t126, i64 %t113
  call void @olang_textcopy(ptr %t128, ptr %t115, i64 %t116)
  %t129 = getelementptr i8, ptr %t128, i64 %t116
  call void @olang_textcopy(ptr %t129, ptr %t119, i64 %t120)
  %t130 = getelementptr i8, ptr %t129, i64 %t120
  call void @olang_textcopy(ptr %t130, ptr %t122, i64 %t123)
  %t131 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr %t125, 1
  %t134 = extractvalue { i64, ptr } %t132, 0
  %t135 = extractvalue { i64, ptr } %t132, 1
  %t136 = mul i64 %t134, 1
  %t137 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t136)
  call void @llvm.memcpy.p0.p0.i64(ptr %t137, ptr %t135, i64 %t136, i1 false)
  %t138 = insertvalue { i64, ptr } undef, i64 %t134, 0
  %t139 = insertvalue { i64, ptr } %t138, ptr %t137, 1
  %t140 = load ptr, ptr %l64, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s5, ptr %s5, ptr %t140, { i64, ptr } %t139)
  br label %bb29
bb29:
  %t142 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %s5)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t142, ptr %l70
  br label %bb30
bb30:
  %t143 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l70
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t143, ptr %l12
  %t144 = getelementptr %"compiler/emit:Reused", ptr %l9, i32 0, i32 6
  store ptr %t144, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb31
bb31:
  store %olang.scope zeroinitializer, ptr %s9
  %t146 = load i64, ptr %l14, !tbaa !24
  store i64 %t146, ptr %l72, !tbaa !24
  %t147 = load ptr, ptr %l13, !tbaa !29
  %t149 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v3, ptr %t147)
  store i64 %t149, ptr %l74
  br label %bb32
bb32:
  %t150 = load i64, ptr %l72, !tbaa !24
  %t151 = load i64, ptr %l74, !tbaa !24
  %t152 = icmp slt i64 %t150, %t151
  %t154 = xor i1 %t152, true
  br i1 %t154, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s9)
  br label %bb44
bb34:
  br label %bb35
bb35:
  %t156 = load ptr, ptr %l13, !tbaa !29
  %t157 = load i64, ptr %l14, !tbaa !24
  %t160 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v3, ptr %v3, ptr %t156, i64 %t157)
  store { i64, ptr } %t160, ptr %l79
  br label %bb36
bb36:
  %t161 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t161, ptr %l15, !tbaa !27
  %t162 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t165 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %s5, ptr %v3, ptr %l12, { i64, ptr } %t162)
  store i1 %t165, ptr %l82
  br label %bb37
bb37:
  %t166 = load i1, ptr %l82, !tbaa !21
  br i1 %t166, label %bb38, label %bb39
bb38:
  call void @__olang_scope_close(ptr %s9)
  br label %bb43
bb39:
  br label %bb40
bb40:
  %t167 = load { i64, ptr }, ptr %l15, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H2b85ceff512af6e6ca26c554a1c16247(ptr %s5, ptr %v3, ptr %l12, { i64, ptr } %t167, i1 true)
  br label %bb41
bb41:
  %t170 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t171 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d252, i32 0, i32 1) }, 1
  %t172 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d252, i32 0, i32 1) }, 0
  %t174 = extractvalue { i64, ptr } %t170, 1
  %t175 = extractvalue { i64, ptr } %t170, 0
  %t176 = add i64 %t172, %t175
  %t177 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d253, i32 0, i32 1) }, 1
  %t178 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d253, i32 0, i32 1) }, 0
  %t179 = add i64 %t176, %t178
  %t180 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t179)
  call void @olang_textcopy(ptr %t180, ptr %t171, i64 %t172)
  %t181 = getelementptr i8, ptr %t180, i64 %t172
  call void @olang_textcopy(ptr %t181, ptr %t174, i64 %t175)
  %t182 = getelementptr i8, ptr %t181, i64 %t175
  call void @olang_textcopy(ptr %t182, ptr %t177, i64 %t178)
  %t183 = insertvalue { i64, ptr } undef, i64 %t179, 0
  %t184 = insertvalue { i64, ptr } %t183, ptr %t180, 1
  %t186 = extractvalue { i64, ptr } %t184, 0
  %t187 = extractvalue { i64, ptr } %t184, 1
  %t188 = mul i64 %t186, 1
  %t189 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t188)
  call void @llvm.memcpy.p0.p0.i64(ptr %t189, ptr %t187, i64 %t188, i1 false)
  %t190 = insertvalue { i64, ptr } undef, i64 %t186, 0
  %t191 = insertvalue { i64, ptr } %t190, ptr %t189, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s5, ptr %s9, ptr %l11, { i64, ptr } %t191)
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s9)
  br label %bb43
bb43:
  %t194 = load i64, ptr %l14, !tbaa !24
  %t196 = add i64 %t194, 1
  store i64 %t196, ptr %l14, !tbaa !24
  br label %bb31
bb44:
  store i1 true, ptr %l16, !tbaa !21
  store i64 0, ptr %l17, !tbaa !24
  %t198 = getelementptr %"compiler/emit:Reused", ptr %l9, i32 0, i32 1
  %t200 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v3, ptr %t198)
  store i64 %t200, ptr %l92
  br label %bb45
bb45:
  %t201 = load i64, ptr %l92, !tbaa !24
  store i64 %t201, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t202 = load i64, ptr %l18, !tbaa !24
  %t203 = load i64, ptr %l17, !tbaa !24
  %t206 = icmp sgt i64 %t202, %t203
  br i1 %t206, label %bb46, label %bb47
bb46:
  %t208 = load i64, ptr %l19, !tbaa !24
  %t210 = icmp sgt i64 %t208, 0
  br i1 %t210, label %bb48, label %bb49
bb47:
  store i64 0, ptr %l96, !tbaa !24
  br label %bb51
bb48:
  %t212 = load i64, ptr %l18, !tbaa !24
  %t213 = load i64, ptr %l17, !tbaa !24
  %t216 = sub i64 %t212, %t213
  %t217 = load i64, ptr %l19, !tbaa !24
  %t220 = add i64 %t216, %t217
  %t222 = sub i64 %t220, 1
  %t223 = load i64, ptr %l19, !tbaa !24
  %t226 = sdiv i64 %t222, %t223
  store i64 %t226, ptr %l99, !tbaa !24
  br label %bb50
bb49:
  store i64 0, ptr %l99, !tbaa !24
  br label %bb50
bb50:
  %t228 = load i64, ptr %l99, !tbaa !24
  store i64 %t228, ptr %l96, !tbaa !24
  br label %bb51
bb51:
  %t229 = load i64, ptr %l96, !tbaa !24
  store i64 %t229, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb52
bb52:
  store %olang.scope zeroinitializer, ptr %s14
  %t230 = load i64, ptr %l21, !tbaa !24
  %t231 = load i64, ptr %l20, !tbaa !24
  %t234 = icmp slt i64 %t230, %t231
  %t236 = xor i1 %t234, true
  br i1 %t236, label %bb53, label %bb54
bb53:
  call void @__olang_scope_close(ptr %s14)
  br label %bb69
bb54:
  br label %bb55
bb55:
  %t238 = load i64, ptr %l17, !tbaa !24
  %t239 = load i64, ptr %l21, !tbaa !24
  %t240 = load i64, ptr %l19, !tbaa !24
  %t243 = mul i64 %t239, %t240
  %t246 = add i64 %t238, %t243
  store i64 %t246, ptr %l22, !tbaa !24
  %t248 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t249 = load i64, ptr %l22, !tbaa !24
  %t251 = extractvalue { i64, ptr } %t248, 1
  %t252 = extractvalue { i64, ptr } %t248, 0
  %t253 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d254, i32 0, i32 1) }, 1
  %t254 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d254, i32 0, i32 1) }, 0
  %t255 = add i64 %t252, %t254
  %t257 = call i64 @__olang_fmt_i64(ptr null, i64 %t249)
  %t258 = add i64 %t255, %t257
  %t259 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d255, i32 0, i32 1) }, 1
  %t260 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d255, i32 0, i32 1) }, 0
  %t261 = add i64 %t258, %t260
  %t262 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t261)
  call void @olang_textcopy(ptr %t262, ptr %t251, i64 %t252)
  %t263 = getelementptr i8, ptr %t262, i64 %t252
  call void @olang_textcopy(ptr %t263, ptr %t253, i64 %t254)
  %t264 = getelementptr i8, ptr %t263, i64 %t254
  %t265 = call i64 @__olang_fmt_i64(ptr %t264, i64 %t249)
  %t266 = getelementptr i8, ptr %t264, i64 %t257
  call void @olang_textcopy(ptr %t266, ptr %t259, i64 %t260)
  %t267 = insertvalue { i64, ptr } undef, i64 %t261, 0
  %t268 = insertvalue { i64, ptr } %t267, ptr %t262, 1
  %t270 = extractvalue { i64, ptr } %t268, 0
  %t271 = extractvalue { i64, ptr } %t268, 1
  %t272 = mul i64 %t270, 1
  %t273 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t272)
  call void @llvm.memcpy.p0.p0.i64(ptr %t273, ptr %t271, i64 %t272, i1 false)
  %t274 = insertvalue { i64, ptr } undef, i64 %t270, 0
  %t275 = insertvalue { i64, ptr } %t274, ptr %t273, 1
  store { i64, ptr } %t275, ptr %l120, !tbaa !27
  %t278 = getelementptr %"compiler/emit:Reused", ptr %l9, i32 0, i32 7
  %t279 = load i64, ptr %t278, !tbaa !24
  %t280 = load i64, ptr %l22, !tbaa !24
  %t283 = add i64 %t279, %t280
  %t286 = call %"compiler/emit:Object" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2femit_3aObject_3e_2eAt_3ccompiler_2femit_3aObject_3e(ptr %v4, ptr %v4, ptr %a4, i64 %t283)
  store %"compiler/emit:Object" %t286, ptr %l126
  br label %bb56
bb56:
  %t287 = getelementptr %"compiler/emit:Object", ptr %l126, i32 0, i32 2
  %t288 = load { i64, ptr }, ptr %t287, !tbaa !27
  %t289 = load i32, ptr %l6, !tbaa !23
  %t290 = load { i64, ptr }, ptr %l120, !tbaa !27
  %t293 = call i1 @compiler_2folang_2eputFile(ptr %s14, ptr %v4, { i64, ptr } %t290, { i64, ptr } %t288, i32 %t289)
  store i1 %t293, ptr %l129
  br label %bb57
bb57:
  %t294 = load i1, ptr %l129, !tbaa !21
  %t295 = xor i1 %t294, true
  br i1 %t295, label %bb58, label %bb59
bb58:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb60
bb59:
  br label %bb60
bb60:
  store ptr %l11, ptr %l131, !tbaa !29
  %t297 = getelementptr %"compiler/emit:Reused", ptr %l9, i32 0, i32 2
  %t298 = load i64, ptr %l22, !tbaa !24
  %t301 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v3, ptr %t297, i64 %t298)
  store i1 %t301, ptr %l134
  br label %bb61
bb61:
  %t302 = load i1, ptr %l134, !tbaa !21
  br i1 %t302, label %bb62, label %bb63
bb62:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d256, i32 0, i32 1) }, ptr %l135, !tbaa !27
  br label %bb64
bb63:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d257, i32 0, i32 1) }, ptr %l135, !tbaa !27
  br label %bb64
bb64:
  %t304 = getelementptr %"compiler/emit:Reused", ptr %l9, i32 0, i32 7
  %t305 = load i64, ptr %t304, !tbaa !24
  %t306 = load i64, ptr %l22, !tbaa !24
  %t309 = add i64 %t305, %t306
  %t312 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v5, ptr %s14, ptr %a5, i64 %t309)
  store { i64, ptr } %t312, ptr %l140
  br label %bb65
bb65:
  %t313 = getelementptr %"compiler/emit:Reused", ptr %l9, i32 0, i32 1
  %t314 = load i64, ptr %l22, !tbaa !24
  %t317 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v3, ptr %s14, ptr %t313, i64 %t314)
  store { i64, ptr } %t317, ptr %l143
  br label %bb66
bb66:
  %t318 = load { i64, ptr }, ptr %l135, !tbaa !27
  %t319 = extractvalue { i64, ptr } %t318, 1
  %t320 = extractvalue { i64, ptr } %t318, 0
  %t321 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t322 = extractvalue { i64, ptr } %t321, 1
  %t323 = extractvalue { i64, ptr } %t321, 0
  %t324 = add i64 %t320, %t323
  %t325 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d258, i32 0, i32 1) }, 1
  %t326 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d258, i32 0, i32 1) }, 0
  %t327 = add i64 %t324, %t326
  %t328 = load { i64, ptr }, ptr %l143, !tbaa !27
  %t329 = extractvalue { i64, ptr } %t328, 1
  %t330 = extractvalue { i64, ptr } %t328, 0
  %t331 = add i64 %t327, %t330
  %t332 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d259, i32 0, i32 1) }, 1
  %t333 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d259, i32 0, i32 1) }, 0
  %t334 = add i64 %t331, %t333
  %t335 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t334)
  call void @olang_textcopy(ptr %t335, ptr %t319, i64 %t320)
  %t336 = getelementptr i8, ptr %t335, i64 %t320
  call void @olang_textcopy(ptr %t336, ptr %t322, i64 %t323)
  %t337 = getelementptr i8, ptr %t336, i64 %t323
  call void @olang_textcopy(ptr %t337, ptr %t325, i64 %t326)
  %t338 = getelementptr i8, ptr %t337, i64 %t326
  call void @olang_textcopy(ptr %t338, ptr %t329, i64 %t330)
  %t339 = getelementptr i8, ptr %t338, i64 %t330
  call void @olang_textcopy(ptr %t339, ptr %t332, i64 %t333)
  %t340 = insertvalue { i64, ptr } undef, i64 %t334, 0
  %t341 = insertvalue { i64, ptr } %t340, ptr %t335, 1
  %t343 = extractvalue { i64, ptr } %t341, 0
  %t344 = extractvalue { i64, ptr } %t341, 1
  %t345 = mul i64 %t343, 1
  %t346 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t345)
  call void @llvm.memcpy.p0.p0.i64(ptr %t346, ptr %t344, i64 %t345, i1 false)
  %t347 = insertvalue { i64, ptr } undef, i64 %t343, 0
  %t348 = insertvalue { i64, ptr } %t347, ptr %t346, 1
  %t349 = load ptr, ptr %l131, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s5, ptr %s14, ptr %t349, { i64, ptr } %t348)
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s14)
  br label %bb68
bb68:
  %t351 = load i64, ptr %l21, !tbaa !24
  %t353 = add i64 %t351, 1
  store i64 %t353, ptr %l21, !tbaa !24
  br label %bb52
bb69:
  %t355 = load i1, ptr %l16, !tbaa !21
  %t357 = xor i1 %t355, true
  br i1 %t357, label %bb70, label %bb71
bb70:
  call void @__olang_scope_close(ptr %s5)
  br label %bb76
bb71:
  br label %bb72
bb72:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s5, ptr %s5, ptr %l11, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d260, i32 0, i32 1) })
  br label %bb73
bb73:
  %t360 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t360, ptr %l151, !tbaa !27
  %t362 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s5, ptr %s5, ptr %l11)
  store { i64, ptr } %t362, ptr %l153
  br label %bb74
bb74:
  %t363 = load i32, ptr %l6, !tbaa !23
  %t364 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t365 = load { i64, ptr }, ptr %l153, !tbaa !27
  %t367 = call i1 @compiler_2folang_2eputFile(ptr %s5, ptr %s5, { i64, ptr } %t364, { i64, ptr } %t365, i32 %t363)
  store i1 %t367, ptr %l155
  br label %bb75
bb75:
  call void @__olang_scope_close(ptr %s5)
  br label %bb76
bb76:
  %t368 = load i64, ptr %l8, !tbaa !24
  %t370 = add i64 %t368, 1
  store i64 %t370, ptr %l8, !tbaa !24
  br label %bb10
bb77:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2folang_2elibraryIr(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d261, i32 0, i32 1) }, ptr %l3, !tbaa !27
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d262, i32 0, i32 1) }, ptr %l4, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t6 = call { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %a0, { i64, ptr } %t4, { i64, ptr } %t5)
  store { i64, ptr } %t6, ptr %l5
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t7, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2folang_2emain() #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l6 = alloca i32
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  call void @std_2fos_2eOnCrash(ptr %s0, { i64, ptr } { i64 97, ptr getelementptr inbounds (<{ i64, [97 x i8] }>, ptr @.d263, i32 0, i32 1) })
  br label %bb1
bb1:
  %t1 = call { i64, ptr } @std_2fos_2eArgs(ptr %s0)
  store { i64, ptr } %t1, ptr %l1
  br label %bb2
bb2:
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t2, ptr %l0, !tbaa !27
  %t3 = call i1 @compiler_2folang_2eroomFor(i64 1073741824)
  store i1 %t3, ptr %l2
  br label %bb3
bb3:
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb4, label %bb5
bb4:
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t6 = getelementptr { { i64, ptr }, ptr }, ptr null, i32 1
  %t7 = ptrtoint ptr %t6 to i64
  %t8 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 %t7, i64 8)
  %t9 = getelementptr { { i64, ptr }, ptr }, ptr %t8, i32 0, i32 0
  store { i64, ptr } %t5, ptr %t9, !tbaa !28
  call void @__olang_scope_escape(ptr %s0)
  %t11 = getelementptr { { i64, ptr }, ptr }, ptr %t8, i32 0, i32 1
  store ptr %s0, ptr %t11, !tbaa !28
  %t12 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_264, 0
  %t13 = insertvalue { ptr, ptr } %t12, ptr %t8, 1
  %t15 = extractvalue { ptr, ptr } %t13, 0
  %t16 = extractvalue { ptr, ptr } %t13, 1
  call void @std_2fos_2eRunOnStack(ptr %s0, i64 1073741824, ptr %t15, ptr %t16)
  br label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb7
bb7:
  %t17 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t19 = call i32 @compiler_2folang_2edrive(ptr %s0, { i64, ptr } %t17)
  store i32 %t19, ptr %l6
  br label %bb8
bb8:
  %t20 = load i32, ptr %l6, !tbaa !23
  call void @std_2fos_2eExit(i32 %t20)
  unreachable
bb9:
  call void @__olang_check_failed(ptr @olang_loc_73b8d8bbbab8f911_f56ba933d304b59d)
  unreachable
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2folang_2emodeName(ptr %v0, i64 %a0) #0 {
entry:
  %l0 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store i64 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !24
  %t2 = load i64, ptr @G_2ecompiler_2folang_2eRun, !tbaa !24
  %t5 = icmp eq i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d265, i32 0, i32 1) }, ptr %l5, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t7, ptr %l4, !tbaa !27
  br label %bb3
bb2:
  %t9 = load i64, ptr %l0, !tbaa !24
  %t11 = getelementptr [13 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eModeWords, i64 0, i64 %t9
  %t12 = load { i64, ptr }, ptr %t11, !tbaa !37
  %t14 = extractvalue { i64, ptr } %t12, 1
  %t15 = extractvalue { i64, ptr } %t12, 0
  %t16 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t14, i64 %t15)
  %t17 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l4, !tbaa !27
  br label %bb3
bb3:
  %t20 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t20, 0
  store i64 %t21, ptr %l10, !tbaa !24
  %t22 = load i64, ptr %l10, !tbaa !24
  %t23 = mul i64 %t22, 1
  %t24 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t23)
  %t25 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t24, 1
  store { i64, ptr } %t26, ptr %l11, !tbaa !27
  %t27 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = load i64, ptr %l10, !tbaa !24
  %t32 = mul i64 %t31, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t28, ptr %t30, i64 %t32, i1 false)
  %t33 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t33, ptr %l4, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t34, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2folang_2emodeNumber(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca [13 x { i64, ptr }]
  %l12 = alloca i64
  %l15 = alloca i64
  %l36 = alloca i1
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store i64 1, ptr %l1, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l7, ptr @G_2ecompiler_2folang_2eModeWords, i64 208, i1 false)
  %t1 = load [13 x { i64, ptr }], ptr %l7
  store i64 13, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t3 = load i64, ptr %l2, !tbaa !24
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = icmp sgt i64 %t3, %t4
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp sgt i64 %t9, 0
  br i1 %t11, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l12, !tbaa !24
  br label %bb6
bb3:
  %t13 = load i64, ptr %l2, !tbaa !24
  %t14 = load i64, ptr %l1, !tbaa !24
  %t17 = sub i64 %t13, %t14
  %t18 = load i64, ptr %l3, !tbaa !24
  %t21 = add i64 %t17, %t18
  %t23 = sub i64 %t21, 1
  %t24 = load i64, ptr %l3, !tbaa !24
  %t27 = sdiv i64 %t23, %t24
  store i64 %t27, ptr %l15, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb5
bb5:
  %t29 = load i64, ptr %l15, !tbaa !24
  store i64 %t29, ptr %l12, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l12, !tbaa !24
  store i64 %t30, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb7
bb7:
  %t31 = load i64, ptr %l5, !tbaa !24
  %t32 = load i64, ptr %l4, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb8, label %bb9
bb8:
  br label %bb16
bb9:
  br label %bb10
bb10:
  %t39 = load i64, ptr %l1, !tbaa !24
  %t40 = load i64, ptr %l5, !tbaa !24
  %t41 = load i64, ptr %l3, !tbaa !24
  %t44 = mul i64 %t40, %t41
  %t47 = add i64 %t39, %t44
  store i64 %t47, ptr %l6, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  %t51 = getelementptr [13 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eModeWords, i64 0, i64 %t49
  %t52 = load { i64, ptr }, ptr %t51, !tbaa !37
  %t54 = load ptr, ptr @__olang_prog_scope
  %t57 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t54, ptr %v0, { i64, ptr } %t52, { i64, ptr } %a0)
  store i1 %t57, ptr %l36
  br label %bb11
bb11:
  %t58 = load i1, ptr %l36, !tbaa !21
  br i1 %t58, label %bb12, label %bb13
bb12:
  %t59 = load i64, ptr %l6, !tbaa !24
  store i64 %t59, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t61 = load i64, ptr %l5, !tbaa !24
  %t63 = add i64 %t61, 1
  store i64 %t63, ptr %l5, !tbaa !24
  br label %bb7
bb16:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2folang_2emodesOf(ptr %v0, i64 %a0) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca %"std/prelude/text:StringBuilder"
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca [13 x { i64, ptr }]
  %l21 = alloca i64
  %l24 = alloca i64
  %l44 = alloca i64
  %l50 = alloca %"std/prelude/text:StringBuilder"
  %l51 = alloca [13 x { i64, ptr }]
  %l56 = alloca i64
  %l59 = alloca i64
  %l78 = alloca i64
  %l86 = alloca ptr
  %l90 = alloca { i64, ptr }
  %l91 = alloca ptr
  %l93 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %l100 = alloca i64
  %l101 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store i64 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 0, ptr %l1, !tbaa !24
  store i64 0, ptr %l2, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l16, ptr @G_2ecompiler_2folang_2eModeWords, i64 208, i1 false)
  %t1 = load [13 x { i64, ptr }], ptr %l16
  store i64 13, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t3 = load i64, ptr %l3, !tbaa !24
  %t4 = load i64, ptr %l2, !tbaa !24
  %t7 = icmp sgt i64 %t3, %t4
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp sgt i64 %t9, 0
  br i1 %t11, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb6
bb3:
  %t13 = load i64, ptr %l3, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t17 = sub i64 %t13, %t14
  %t18 = load i64, ptr %l4, !tbaa !24
  %t21 = add i64 %t17, %t18
  %t23 = sub i64 %t21, 1
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = sdiv i64 %t23, %t24
  store i64 %t27, ptr %l24, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb5
bb5:
  %t29 = load i64, ptr %l24, !tbaa !24
  store i64 %t29, ptr %l21, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l21, !tbaa !24
  store i64 %t30, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  %t31 = load i64, ptr %l6, !tbaa !24
  %t32 = load i64, ptr %l5, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb8, label %bb9
bb8:
  br label %bb12
bb9:
  br label %bb10
bb10:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load i64, ptr %l6, !tbaa !24
  %t41 = load i64, ptr %l4, !tbaa !24
  %t44 = mul i64 %t40, %t41
  %t47 = add i64 %t39, %t44
  %t49 = load i64, ptr %l1, !tbaa !24
  %t50 = load i64, ptr %l0, !tbaa !24
  store i64 %t47, ptr %l44, !tbaa !24
  %t53 = load i64, ptr %l44, !tbaa !24
  %t54 = load i64, ptr %l44, !tbaa !24
  %t55 = ashr i64 %t50, %t54
  %t57 = and i64 %t55, 1
  %t60 = add i64 %t49, %t57
  store i64 %t60, ptr %l1, !tbaa !24
  br label %bb11
bb11:
  %t62 = load i64, ptr %l6, !tbaa !24
  %t64 = add i64 %t62, 1
  store i64 %t64, ptr %l6, !tbaa !24
  br label %bb7
bb12:
  %t66 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t66, ptr %l50
  br label %bb13
bb13:
  %t67 = load %"std/prelude/text:StringBuilder", ptr %l50
  store %"std/prelude/text:StringBuilder" %t67, ptr %l8
  store i64 0, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l51, ptr @G_2ecompiler_2folang_2eModeWords, i64 208, i1 false)
  %t68 = load [13 x { i64, ptr }], ptr %l51
  store i64 13, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t70 = load i64, ptr %l11, !tbaa !24
  %t71 = load i64, ptr %l10, !tbaa !24
  %t74 = icmp sgt i64 %t70, %t71
  br i1 %t74, label %bb14, label %bb15
bb14:
  %t76 = load i64, ptr %l12, !tbaa !24
  %t78 = icmp sgt i64 %t76, 0
  br i1 %t78, label %bb16, label %bb17
bb15:
  store i64 0, ptr %l56, !tbaa !24
  br label %bb19
bb16:
  %t80 = load i64, ptr %l11, !tbaa !24
  %t81 = load i64, ptr %l10, !tbaa !24
  %t84 = sub i64 %t80, %t81
  %t85 = load i64, ptr %l12, !tbaa !24
  %t88 = add i64 %t84, %t85
  %t90 = sub i64 %t88, 1
  %t91 = load i64, ptr %l12, !tbaa !24
  %t94 = sdiv i64 %t90, %t91
  store i64 %t94, ptr %l59, !tbaa !24
  br label %bb18
bb17:
  store i64 0, ptr %l59, !tbaa !24
  br label %bb18
bb18:
  %t96 = load i64, ptr %l59, !tbaa !24
  store i64 %t96, ptr %l56, !tbaa !24
  br label %bb19
bb19:
  %t97 = load i64, ptr %l56, !tbaa !24
  store i64 %t97, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s5
  %t98 = load i64, ptr %l14, !tbaa !24
  %t99 = load i64, ptr %l13, !tbaa !24
  %t102 = icmp slt i64 %t98, %t99
  %t104 = xor i1 %t102, true
  br i1 %t104, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s5)
  br label %bb37
bb22:
  br label %bb23
bb23:
  %t106 = load i64, ptr %l10, !tbaa !24
  %t107 = load i64, ptr %l14, !tbaa !24
  %t108 = load i64, ptr %l12, !tbaa !24
  %t111 = mul i64 %t107, %t108
  %t114 = add i64 %t106, %t111
  store i64 %t114, ptr %l15, !tbaa !24
  %t116 = load i64, ptr %l0, !tbaa !24
  %t117 = load i64, ptr %l15, !tbaa !24
  store i64 %t117, ptr %l78, !tbaa !24
  %t119 = load i64, ptr %l78, !tbaa !24
  %t120 = load i64, ptr %l78, !tbaa !24
  %t121 = ashr i64 %t116, %t120
  %t123 = and i64 %t121, 1
  %t125 = icmp eq i64 %t123, 0
  br i1 %t125, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s5)
  br label %bb36
bb25:
  br label %bb26
bb26:
  %t127 = load i64, ptr %l9, !tbaa !24
  %t129 = add i64 %t127, 1
  store i64 %t129, ptr %l9, !tbaa !24
  %t131 = load i64, ptr %l9, !tbaa !24
  %t133 = icmp sgt i64 %t131, 1
  br i1 %t133, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s7
  store ptr %l8, ptr %l86, !tbaa !29
  %t135 = load i64, ptr %l9, !tbaa !24
  %t136 = load i64, ptr %l1, !tbaa !24
  %t139 = icmp eq i64 %t135, %t136
  br i1 %t139, label %bb29, label %bb30
bb28:
  br label %bb33
bb29:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d266, i32 0, i32 1) }, ptr %l90, !tbaa !27
  br label %bb31
bb30:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d267, i32 0, i32 1) }, ptr %l90, !tbaa !27
  br label %bb31
bb31:
  %t141 = load ptr, ptr %l86, !tbaa !29
  %t142 = load { i64, ptr }, ptr %l90, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %t141, { i64, ptr } %t142)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s7)
  br label %bb33
bb33:
  store ptr %l8, ptr %l91, !tbaa !29
  %t143 = load i64, ptr %l15, !tbaa !24
  %t145 = call { i64, ptr } @compiler_2folang_2emodeName(ptr %s5, i64 %t143)
  store { i64, ptr } %t145, ptr %l93
  br label %bb34
bb34:
  %t146 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t147 = extractvalue { i64, ptr } %t146, 0
  %t148 = extractvalue { i64, ptr } %t146, 1
  %t149 = mul i64 %t147, 1
  %t150 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t149)
  call void @llvm.memcpy.p0.p0.i64(ptr %t150, ptr %t148, i64 %t149, i1 false)
  %t151 = insertvalue { i64, ptr } undef, i64 %t147, 0
  %t152 = insertvalue { i64, ptr } %t151, ptr %t150, 1
  %t153 = load ptr, ptr %l91, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %t153, { i64, ptr } %t152)
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s5)
  br label %bb36
bb36:
  %t155 = load i64, ptr %l14, !tbaa !24
  %t157 = add i64 %t155, 1
  store i64 %t157, ptr %l14, !tbaa !24
  br label %bb20
bb37:
  %t160 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v0, ptr %l8)
  store { i64, ptr } %t160, ptr %l98
  br label %bb38
bb38:
  %t161 = load { i64, ptr }, ptr %l98, !tbaa !27
  store { i64, ptr } %t161, ptr %l99, !tbaa !27
  %t162 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t163 = extractvalue { i64, ptr } %t162, 0
  store i64 %t163, ptr %l100, !tbaa !24
  %t164 = load i64, ptr %l100, !tbaa !24
  %t165 = mul i64 %t164, 1
  %t166 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t165)
  %t167 = insertvalue { i64, ptr } undef, i64 %t164, 0
  %t168 = insertvalue { i64, ptr } %t167, ptr %t166, 1
  store { i64, ptr } %t168, ptr %l101, !tbaa !27
  %t169 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !27
  %t171 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t172 = load ptr, ptr %t171, !tbaa !27
  %t173 = load i64, ptr %l100, !tbaa !24
  %t174 = mul i64 %t173, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t170, ptr %t172, i64 %t174, i1 false)
  %t175 = load { i64, ptr }, ptr %l101, !tbaa !27
  store { i64, ptr } %t175, ptr %l99, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t176 = load { i64, ptr }, ptr %l99, !tbaa !27
  store { i64, ptr } %t176, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2folang_2emoduleKeys(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca { i64, ptr }
  %l27 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l28 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca ptr
  %l37 = alloca i64
  %l38 = alloca %"compiler/load:Import"
  %l39 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l40 = alloca ptr
  %l41 = alloca i64
  %l42 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l53 = alloca { i64, ptr }
  %l55 = alloca i1
  %l57 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l64 = alloca ptr
  %l66 = alloca { i64, ptr }
  %l70 = alloca ptr
  %l76 = alloca i64
  %l84 = alloca i64
  %l87 = alloca i64
  %l107 = alloca ptr
  %l108 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l118 = alloca ptr
  %l123 = alloca { i64, ptr }
  %l132 = alloca { i64, ptr }
  %l137 = alloca i64
  %l139 = alloca i64
  %l144 = alloca { i64, ptr }
  %l145 = alloca ptr
  %l146 = alloca { i64, ptr }
  %l149 = alloca { i64, ptr }
  %l151 = alloca { i64, ptr }
  %l156 = alloca i64
  %l158 = alloca { i64, ptr }
  %l166 = alloca i64
  %l169 = alloca i64
  %l191 = alloca i64
  %l194 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l195 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l202 = alloca i64
  %l205 = alloca i64
  %l225 = alloca ptr
  %l233 = alloca i64
  %l236 = alloca i64
  %l238 = alloca i64
  %l239 = alloca i32
  %l247 = alloca ptr
  %l250 = alloca i64
  %l252 = alloca i64
  %l257 = alloca %"compiler/load:Import"
  %l260 = alloca i1
  %l270 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l277 = alloca i64
  %l279 = alloca i64
  %l284 = alloca i64
  %l285 = alloca ptr
  %l288 = alloca ptr
  %l297 = alloca { i64, ptr }
  %l298 = alloca i64
  %l300 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t19 = alloca i64
  %t119 = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/load:Loader", ptr %t1, i32 0, i32 5
  %t4 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t3
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %l3
  %t7 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %l3)
  store i64 %t7, ptr %l46
  br label %bb1
bb1:
  %t8 = load i64, ptr %l46, !tbaa !24
  store i64 %t8, ptr %l4, !tbaa !24
  %t9 = load i64, ptr %l4, !tbaa !24
  store i64 %t9, ptr %l47, !tbaa !24
  %t10 = load i64, ptr %l47, !tbaa !24
  %t11 = icmp sge i64 %t10, 0
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l47, !tbaa !24
  %t14 = icmp sle i64 %t13, 576460752303423487
  br i1 %t14, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @olang_loc_73c3116820f750d_32f9964414b76079)
  unreachable
bb4:
  %t16 = load i64, ptr %l47, !tbaa !24
  %t17 = mul i64 %t16, 16
  %t18 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t17)
  store i64 0, ptr %t19
  br label %fill.20
fill.20:
  %t23 = load i64, ptr %t19
  %t24 = icmp slt i64 %t23, %t16
  br i1 %t24, label %fillb.21, label %filld.22
fillb.21:
  %t25 = getelementptr { i64, ptr }, ptr %t18, i64 %t23
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d268, i32 0, i32 1) }, ptr %t25
  %t26 = add i64 %t23, 1
  store i64 %t26, ptr %t19
  br label %fill.20
filld.22:
  %t27 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t18, 1
  store { i64, ptr } %t28, ptr %l5, !tbaa !27
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t34 = call { i64, ptr } @compiler_2folang_2ebuildInputs(ptr %v1, ptr %s0, ptr %t30, i1 %a2)
  store { i64, ptr } %t34, ptr %l53
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_73c3116820f750d_32f9964414b76079)
  unreachable
bb6:
  %t35 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t35, ptr %l6, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t38 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t36, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d269, i32 0, i32 1) })
  store i1 %t38, ptr %l55
  br label %bb7
bb7:
  %t39 = load i1, ptr %l55, !tbaa !21
  br i1 %t39, label %bb8, label %bb9
bb8:
  %t40 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t40, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t42 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t42, ptr %l57, !tbaa !27
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = getelementptr %"compiler/build:Config", ptr %t43, i32 0, i32 4
  %t46 = load i1, ptr %t45, !tbaa !21
  br i1 %t46, label %bb11, label %bb12
bb11:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/load:Loader", ptr %t48, i32 0, i32 7
  %t51 = load i64, ptr %t50, !tbaa !24
  %t54 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %l3, i64 %t51)
  store ptr %t54, ptr %l64
  br label %bb13
bb12:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d270, i32 0, i32 1) }, ptr %l60, !tbaa !27
  br label %bb15
bb13:
  %t55 = load ptr, ptr %l64, !tbaa !29
  %t57 = getelementptr %"compiler/load:Module", ptr %t55, i32 0, i32 2
  %t58 = load { i64, ptr }, ptr %t57, !tbaa !27
  store { i64, ptr } %t58, ptr %l66, !tbaa !27
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/load:Loader", ptr %t59, i32 0, i32 7
  %t62 = load i64, ptr %t61, !tbaa !24
  %t65 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %l3, i64 %t62)
  store ptr %t65, ptr %l70
  br label %bb14
bb14:
  %t66 = load ptr, ptr %l70, !tbaa !29
  %t68 = getelementptr %"compiler/load:Module", ptr %t66, i32 0, i32 0
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  %t70 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d271, i32 0, i32 1) }, 1
  %t71 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d271, i32 0, i32 1) }, 0
  %t72 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t72, 1
  %t74 = extractvalue { i64, ptr } %t72, 0
  %t75 = add i64 %t71, %t74
  %t76 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d272, i32 0, i32 1) }, 1
  %t77 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d272, i32 0, i32 1) }, 0
  %t78 = add i64 %t75, %t77
  %t80 = extractvalue { i64, ptr } %t69, 1
  %t81 = extractvalue { i64, ptr } %t69, 0
  %t82 = add i64 %t78, %t81
  %t83 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t82)
  call void @olang_textcopy(ptr %t83, ptr %t70, i64 %t71)
  %t84 = getelementptr i8, ptr %t83, i64 %t71
  call void @olang_textcopy(ptr %t84, ptr %t73, i64 %t74)
  %t85 = getelementptr i8, ptr %t84, i64 %t74
  call void @olang_textcopy(ptr %t85, ptr %t76, i64 %t77)
  %t86 = getelementptr i8, ptr %t85, i64 %t77
  call void @olang_textcopy(ptr %t86, ptr %t80, i64 %t81)
  %t87 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t88 = insertvalue { i64, ptr } %t87, ptr %t83, 1
  %t90 = extractvalue { i64, ptr } %t88, 0
  %t91 = extractvalue { i64, ptr } %t88, 1
  %t92 = mul i64 %t90, 1
  %t93 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t92)
  call void @llvm.memcpy.p0.p0.i64(ptr %t93, ptr %t91, i64 %t92, i1 false)
  %t94 = insertvalue { i64, ptr } undef, i64 %t90, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t93, 1
  store { i64, ptr } %t95, ptr %l60, !tbaa !27
  br label %bb15
bb15:
  %t97 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t97, 1
  %t99 = extractvalue { i64, ptr } %t97, 0
  %t100 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 1
  %t102 = extractvalue { i64, ptr } %t100, 0
  %t103 = add i64 %t99, %t102
  %t104 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t103)
  call void @olang_textcopy(ptr %t104, ptr %t98, i64 %t99)
  %t105 = getelementptr i8, ptr %t104, i64 %t99
  call void @olang_textcopy(ptr %t105, ptr %t101, i64 %t102)
  %t106 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t104, 1
  store { i64, ptr } %t107, ptr %l7, !tbaa !27
  %t109 = load i64, ptr %l4, !tbaa !24
  store i64 %t109, ptr %l76, !tbaa !24
  %t110 = load i64, ptr %l76, !tbaa !24
  %t111 = icmp sge i64 %t110, 0
  br i1 %t111, label %bb16, label %bb17
bb16:
  %t113 = load i64, ptr %l76, !tbaa !24
  %t114 = icmp sle i64 %t113, 576460752303423487
  br i1 %t114, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_23d2168bab4aeae0_126950dc9613ccec)
  unreachable
bb18:
  %t116 = load i64, ptr %l76, !tbaa !24
  %t117 = mul i64 %t116, 16
  %t118 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t117)
  store i64 0, ptr %t119
  br label %fill.120
fill.120:
  %t123 = load i64, ptr %t119
  %t124 = icmp slt i64 %t123, %t116
  br i1 %t124, label %fillb.121, label %filld.122
fillb.121:
  %t125 = getelementptr { i64, ptr }, ptr %t118, i64 %t123
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d273, i32 0, i32 1) }, ptr %t125
  %t126 = add i64 %t123, 1
  store i64 %t126, ptr %t119
  br label %fill.120
filld.122:
  %t127 = insertvalue { i64, ptr } undef, i64 %t116, 0
  %t128 = insertvalue { i64, ptr } %t127, ptr %t118, 1
  store { i64, ptr } %t128, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t130 = load i64, ptr %l4, !tbaa !24
  store i64 %t130, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t132 = load i64, ptr %l10, !tbaa !24
  %t133 = load i64, ptr %l9, !tbaa !24
  %t136 = icmp sgt i64 %t132, %t133
  br i1 %t136, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_23d2168bab4aeae0_126950dc9613ccec)
  unreachable
bb20:
  %t138 = load i64, ptr %l11, !tbaa !24
  %t140 = icmp sgt i64 %t138, 0
  br i1 %t140, label %bb22, label %bb23
bb21:
  store i64 0, ptr %l84, !tbaa !24
  br label %bb25
bb22:
  %t142 = load i64, ptr %l10, !tbaa !24
  %t143 = load i64, ptr %l9, !tbaa !24
  %t146 = sub i64 %t142, %t143
  %t147 = load i64, ptr %l11, !tbaa !24
  %t150 = add i64 %t146, %t147
  %t152 = sub i64 %t150, 1
  %t153 = load i64, ptr %l11, !tbaa !24
  %t156 = sdiv i64 %t152, %t153
  store i64 %t156, ptr %l87, !tbaa !24
  br label %bb24
bb23:
  store i64 0, ptr %l87, !tbaa !24
  br label %bb24
bb24:
  %t158 = load i64, ptr %l87, !tbaa !24
  store i64 %t158, ptr %l84, !tbaa !24
  br label %bb25
bb25:
  %t159 = load i64, ptr %l84, !tbaa !24
  store i64 %t159, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb26
bb26:
  store %olang.scope zeroinitializer, ptr %s5
  %t160 = load i64, ptr %l13, !tbaa !24
  %t161 = load i64, ptr %l12, !tbaa !24
  %t164 = icmp slt i64 %t160, %t161
  %t166 = xor i1 %t164, true
  br i1 %t166, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s5)
  br label %bb55
bb28:
  br label %bb29
bb29:
  %t168 = load i64, ptr %l9, !tbaa !24
  %t169 = load i64, ptr %l13, !tbaa !24
  %t170 = load i64, ptr %l11, !tbaa !24
  %t173 = mul i64 %t169, %t170
  %t176 = add i64 %t168, %t173
  store i64 %t176, ptr %l14, !tbaa !24
  %t178 = load i64, ptr %l14, !tbaa !24
  %t181 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %l3, i64 %t178)
  store ptr %t181, ptr %l107
  br label %bb30
bb30:
  %t182 = load ptr, ptr %l107, !tbaa !29
  store ptr %t182, ptr %l15, !tbaa !29
  %t183 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s5, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t183, ptr %l108
  br label %bb31
bb31:
  %t184 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l108
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t184, ptr %l16
  %t185 = load ptr, ptr %l15, !tbaa !29
  %t187 = getelementptr %"compiler/load:Module", ptr %t185, i32 0, i32 2
  %t188 = load { i64, ptr }, ptr %t187, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s5, ptr %v0, ptr %l16, { i64, ptr } %t188)
  br label %bb32
bb32:
  %t191 = load ptr, ptr %l15, !tbaa !29
  %t193 = getelementptr %"compiler/load:Module", ptr %t191, i32 0, i32 0
  %t194 = load { i64, ptr }, ptr %t193, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s5, ptr %v0, ptr %l16, { i64, ptr } %t194)
  br label %bb33
bb33:
  %t197 = load ptr, ptr %l15, !tbaa !29
  %t199 = getelementptr %"compiler/load:Module", ptr %t197, i32 0, i32 1
  %t200 = load { i64, ptr }, ptr %t199, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s5, ptr %v0, ptr %l16, { i64, ptr } %t200)
  br label %bb34
bb34:
  store ptr %l16, ptr %l118, !tbaa !29
  %t203 = load ptr, ptr %l15, !tbaa !29
  %t205 = getelementptr %"compiler/load:Module", ptr %t203, i32 0, i32 6
  %t206 = load ptr, ptr %t205, !tbaa !29
  %t208 = icmp eq ptr %t206, null
  %t210 = xor i1 %t208, true
  br i1 %t210, label %bb35, label %bb36
bb35:
  %t212 = load ptr, ptr %l15, !tbaa !29
  %t214 = getelementptr %"compiler/load:Module", ptr %t212, i32 0, i32 6
  %t215 = load ptr, ptr %t214, !tbaa !29
  %t217 = icmp eq ptr %t215, null
  br i1 %t217, label %bb37, label %bb38
bb36:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d274, i32 0, i32 1) }, ptr %l132, !tbaa !27
  %t219 = load { i64, ptr }, ptr %l132, !tbaa !27
  store { i64, ptr } %t219, ptr %l123, !tbaa !27
  br label %bb40
bb37:
  call void @__olang_check_failed(ptr @olang_loc_a3d985a905b98e7d_1a99d62f9ee112a1)
  unreachable
bb38:
  br label %bb39
bb39:
  %t221 = load ptr, ptr %l15, !tbaa !29
  %t223 = getelementptr %"compiler/load:Module", ptr %t221, i32 0, i32 6
  %t224 = load ptr, ptr %t223, !tbaa !29
  %t227 = getelementptr %"compiler/source:Source", ptr %t224, i32 0, i32 1
  %t228 = load { i64, ptr }, ptr %t227, !tbaa !27
  store { i64, ptr } %t228, ptr %l123, !tbaa !27
  br label %bb40
bb40:
  %t231 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t232 = extractvalue { i64, ptr } %t231, 0
  %t233 = extractvalue { i64, ptr } %t231, 1
  %t234 = mul i64 %t232, 1
  %t235 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t234)
  call void @llvm.memcpy.p0.p0.i64(ptr %t235, ptr %t233, i64 %t234, i1 false)
  %t236 = insertvalue { i64, ptr } undef, i64 %t232, 0
  %t237 = insertvalue { i64, ptr } %t236, ptr %t235, 1
  %t238 = load ptr, ptr %l118, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s5, ptr %s5, ptr %t238, { i64, ptr } %t237)
  br label %bb41
bb41:
  %t240 = load ptr, ptr %l15, !tbaa !29
  %t242 = getelementptr %"compiler/load:Module", ptr %t240, i32 0, i32 29
  store ptr %t242, ptr %l17, !tbaa !29
  store i64 0, ptr %l18, !tbaa !24
  br label %bb42
bb42:
  store %olang.scope zeroinitializer, ptr %s7
  %t244 = load i64, ptr %l18, !tbaa !24
  store i64 %t244, ptr %l137, !tbaa !24
  %t245 = load ptr, ptr %l17, !tbaa !29
  %t247 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t245)
  store i64 %t247, ptr %l139
  br label %bb43
bb43:
  %t248 = load i64, ptr %l137, !tbaa !24
  %t249 = load i64, ptr %l139, !tbaa !24
  %t250 = icmp slt i64 %t248, %t249
  %t252 = xor i1 %t250, true
  br i1 %t252, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s7)
  br label %bb52
bb45:
  br label %bb46
bb46:
  %t254 = load ptr, ptr %l17, !tbaa !29
  %t255 = load i64, ptr %l18, !tbaa !24
  %t258 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t254, i64 %t255)
  store { i64, ptr } %t258, ptr %l144
  br label %bb47
bb47:
  %t259 = load { i64, ptr }, ptr %l144, !tbaa !27
  store { i64, ptr } %t259, ptr %l19, !tbaa !27
  store ptr %l16, ptr %l145, !tbaa !29
  %t260 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t260, ptr %l146, !tbaa !27
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t262 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t265 = call { i64, ptr } @compiler_2fload_2ecompiler_2fload_3aLoader_2eEmbedded(ptr %v0, ptr %v0, ptr %t261, { i64, ptr } %t262)
  store { i64, ptr } %t265, ptr %l149
  br label %bb48
bb48:
  %t266 = load { i64, ptr }, ptr %l149, !tbaa !27
  %t268 = call { i64, ptr } @compiler_2fbuild_2eIrHash(ptr %v0, ptr %s7, { i64, ptr } %t266)
  store { i64, ptr } %t268, ptr %l151
  br label %bb49
bb49:
  %t269 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d275, i32 0, i32 1) }, 1
  %t270 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d275, i32 0, i32 1) }, 0
  %t271 = load { i64, ptr }, ptr %l146, !tbaa !27
  %t272 = extractvalue { i64, ptr } %t271, 1
  %t273 = extractvalue { i64, ptr } %t271, 0
  %t274 = add i64 %t270, %t273
  %t275 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d276, i32 0, i32 1) }, 1
  %t276 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d276, i32 0, i32 1) }, 0
  %t277 = add i64 %t274, %t276
  %t278 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t279 = extractvalue { i64, ptr } %t278, 1
  %t280 = extractvalue { i64, ptr } %t278, 0
  %t281 = add i64 %t277, %t280
  %t282 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t281)
  call void @olang_textcopy(ptr %t282, ptr %t269, i64 %t270)
  %t283 = getelementptr i8, ptr %t282, i64 %t270
  call void @olang_textcopy(ptr %t283, ptr %t272, i64 %t273)
  %t284 = getelementptr i8, ptr %t283, i64 %t273
  call void @olang_textcopy(ptr %t284, ptr %t275, i64 %t276)
  %t285 = getelementptr i8, ptr %t284, i64 %t276
  call void @olang_textcopy(ptr %t285, ptr %t279, i64 %t280)
  %t286 = insertvalue { i64, ptr } undef, i64 %t281, 0
  %t287 = insertvalue { i64, ptr } %t286, ptr %t282, 1
  %t289 = extractvalue { i64, ptr } %t287, 0
  %t290 = extractvalue { i64, ptr } %t287, 1
  %t291 = mul i64 %t289, 1
  %t292 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t291)
  call void @llvm.memcpy.p0.p0.i64(ptr %t292, ptr %t290, i64 %t291, i1 false)
  %t293 = insertvalue { i64, ptr } undef, i64 %t289, 0
  %t294 = insertvalue { i64, ptr } %t293, ptr %t292, 1
  %t295 = load ptr, ptr %l145, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s5, ptr %s5, ptr %t295, { i64, ptr } %t294)
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s7)
  br label %bb51
bb51:
  %t297 = load i64, ptr %l18, !tbaa !24
  %t299 = add i64 %t297, 1
  store i64 %t299, ptr %l18, !tbaa !24
  br label %bb42
bb52:
  %t301 = load i64, ptr %l14, !tbaa !24
  store i64 %t301, ptr %l156, !tbaa !24
  %t303 = call { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %s5, ptr %s0, ptr %l16)
  store { i64, ptr } %t303, ptr %l158
  br label %bb53
bb53:
  %t304 = load { i64, ptr }, ptr %l158, !tbaa !27
  %t305 = extractvalue { i64, ptr } %t304, 0
  %t306 = extractvalue { i64, ptr } %t304, 1
  %t307 = mul i64 %t305, 1
  %t308 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t307)
  call void @llvm.memcpy.p0.p0.i64(ptr %t308, ptr %t306, i64 %t307, i1 false)
  %t309 = insertvalue { i64, ptr } undef, i64 %t305, 0
  %t310 = insertvalue { i64, ptr } %t309, ptr %t308, 1
  %t312 = load i64, ptr %l156, !tbaa !24
  %t313 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t314 = load ptr, ptr %t313, !tbaa !27
  %t315 = getelementptr { i64, ptr }, ptr %t314, i64 %t312
  store { i64, ptr } %t310, ptr %t315, !tbaa !37
  call void @__olang_scope_close(ptr %s5)
  br label %bb54
bb54:
  %t316 = load i64, ptr %l13, !tbaa !24
  %t318 = add i64 %t316, 1
  store i64 %t318, ptr %l13, !tbaa !24
  br label %bb26
bb55:
  store i64 0, ptr %l20, !tbaa !24
  %t320 = load i64, ptr %l4, !tbaa !24
  store i64 %t320, ptr %l21, !tbaa !24
  store i64 1, ptr %l22, !tbaa !24
  %t322 = load i64, ptr %l21, !tbaa !24
  %t323 = load i64, ptr %l20, !tbaa !24
  %t326 = icmp sgt i64 %t322, %t323
  br i1 %t326, label %bb56, label %bb57
bb56:
  %t328 = load i64, ptr %l22, !tbaa !24
  %t330 = icmp sgt i64 %t328, 0
  br i1 %t330, label %bb58, label %bb59
bb57:
  store i64 0, ptr %l166, !tbaa !24
  br label %bb61
bb58:
  %t332 = load i64, ptr %l21, !tbaa !24
  %t333 = load i64, ptr %l20, !tbaa !24
  %t336 = sub i64 %t332, %t333
  %t337 = load i64, ptr %l22, !tbaa !24
  %t340 = add i64 %t336, %t337
  %t342 = sub i64 %t340, 1
  %t343 = load i64, ptr %l22, !tbaa !24
  %t346 = sdiv i64 %t342, %t343
  store i64 %t346, ptr %l169, !tbaa !24
  br label %bb60
bb59:
  store i64 0, ptr %l169, !tbaa !24
  br label %bb60
bb60:
  %t348 = load i64, ptr %l169, !tbaa !24
  store i64 %t348, ptr %l166, !tbaa !24
  br label %bb61
bb61:
  %t349 = load i64, ptr %l166, !tbaa !24
  store i64 %t349, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb62
bb62:
  store %olang.scope zeroinitializer, ptr %s12
  %t350 = load i64, ptr %l24, !tbaa !24
  %t351 = load i64, ptr %l23, !tbaa !24
  %t354 = icmp slt i64 %t350, %t351
  %t356 = xor i1 %t354, true
  br i1 %t356, label %bb63, label %bb64
bb63:
  call void @__olang_scope_close(ptr %s12)
  br label %bb138
bb64:
  br label %bb65
bb65:
  %t358 = load i64, ptr %l20, !tbaa !24
  %t359 = load i64, ptr %l24, !tbaa !24
  %t360 = load i64, ptr %l22, !tbaa !24
  %t363 = mul i64 %t359, %t360
  %t366 = add i64 %t358, %t363
  store i64 %t366, ptr %l25, !tbaa !24
  %t368 = load i64, ptr %l25, !tbaa !24
  %t369 = load ptr, ptr %l0, !tbaa !29
  %t371 = getelementptr %"compiler/load:Loader", ptr %t369, i32 0, i32 7
  %t372 = load i64, ptr %t371, !tbaa !24
  %t375 = icmp eq i64 %t368, %t372
  br i1 %t375, label %bb66, label %bb67
bb66:
  call void @__olang_scope_close(ptr %s12)
  br label %bb137
bb67:
  br label %bb68
bb68:
  %t377 = load i64, ptr %l4, !tbaa !24
  store i64 %t377, ptr %l191, !tbaa !24
  %t378 = load i64, ptr %l191, !tbaa !24
  %t379 = icmp sge i64 %t378, 0
  br i1 %t379, label %bb69, label %bb70
bb69:
  %t381 = load i64, ptr %l191, !tbaa !24
  %t382 = mul i64 %t381, 1
  %t383 = call ptr @__olang_scope_alloc_zeroed(ptr %s12, i64 %t382)
  %t384 = insertvalue { i64, ptr } undef, i64 %t381, 0
  %t385 = insertvalue { i64, ptr } %t384, ptr %t383, 1
  store { i64, ptr } %t385, ptr %l26, !tbaa !27
  %t387 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s12, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t387, ptr %l194
  br label %bb71
bb70:
  call void @__olang_check_failed(ptr @olang_loc_32de2828e497f50e_77e9a884b57210fa)
  unreachable
bb71:
  %t388 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l194
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t388, ptr %l27
  %t389 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s12, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t389, ptr %l195
  br label %bb72
bb72:
  %t390 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l195
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t390, ptr %l28
  %t391 = load i64, ptr %l25, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s12, ptr %l28, i64 %t391)
  br label %bb73
bb73:
  store i64 0, ptr %l29, !tbaa !24
  %t394 = load i64, ptr %l4, !tbaa !24
  store i64 %t394, ptr %l30, !tbaa !24
  store i64 1, ptr %l31, !tbaa !24
  %t396 = load i64, ptr %l30, !tbaa !24
  %t397 = load i64, ptr %l29, !tbaa !24
  %t400 = icmp sgt i64 %t396, %t397
  br i1 %t400, label %bb74, label %bb75
bb74:
  %t402 = load i64, ptr %l31, !tbaa !24
  %t404 = icmp sgt i64 %t402, 0
  br i1 %t404, label %bb76, label %bb77
bb75:
  store i64 0, ptr %l202, !tbaa !24
  br label %bb79
bb76:
  %t406 = load i64, ptr %l30, !tbaa !24
  %t407 = load i64, ptr %l29, !tbaa !24
  %t410 = sub i64 %t406, %t407
  %t411 = load i64, ptr %l31, !tbaa !24
  %t414 = add i64 %t410, %t411
  %t416 = sub i64 %t414, 1
  %t417 = load i64, ptr %l31, !tbaa !24
  %t420 = sdiv i64 %t416, %t417
  store i64 %t420, ptr %l205, !tbaa !24
  br label %bb78
bb77:
  store i64 0, ptr %l205, !tbaa !24
  br label %bb78
bb78:
  %t422 = load i64, ptr %l205, !tbaa !24
  store i64 %t422, ptr %l202, !tbaa !24
  br label %bb79
bb79:
  %t423 = load i64, ptr %l202, !tbaa !24
  store i64 %t423, ptr %l32, !tbaa !24
  store i64 0, ptr %l33, !tbaa !24
  br label %bb80
bb80:
  %t424 = load i64, ptr %l33, !tbaa !24
  %t425 = load i64, ptr %l32, !tbaa !24
  %t428 = icmp slt i64 %t424, %t425
  %t430 = xor i1 %t428, true
  br i1 %t430, label %bb81, label %bb82
bb81:
  br label %bb90
bb82:
  br label %bb83
bb83:
  %t432 = load i64, ptr %l29, !tbaa !24
  %t433 = load i64, ptr %l33, !tbaa !24
  %t434 = load i64, ptr %l31, !tbaa !24
  %t437 = mul i64 %t433, %t434
  %t440 = add i64 %t432, %t437
  store i64 %t440, ptr %l34, !tbaa !24
  %t442 = load i64, ptr %l34, !tbaa !24
  %t445 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %l3, i64 %t442)
  store ptr %t445, ptr %l225
  br label %bb84
bb84:
  %t446 = load ptr, ptr %l225, !tbaa !29
  %t448 = getelementptr %"compiler/load:Module", ptr %t446, i32 0, i32 3
  %t449 = load i1, ptr %t448, !tbaa !21
  br i1 %t449, label %bb85, label %bb86
bb85:
  %t451 = load i64, ptr %l34, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s12, ptr %l28, i64 %t451)
  br label %bb87
bb86:
  br label %bb88
bb87:
  br label %bb88
bb88:
  br label %bb89
bb89:
  %t454 = load i64, ptr %l33, !tbaa !24
  %t456 = add i64 %t454, 1
  store i64 %t456, ptr %l33, !tbaa !24
  br label %bb80
bb90:
  br label %bb91
bb91:
  %t459 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s12, ptr %l28)
  store i64 %t459, ptr %l233
  br label %bb92
bb92:
  %t460 = load i64, ptr %l233, !tbaa !24
  %t461 = icmp sgt i64 %t460, 0
  %t463 = xor i1 %t461, true
  br i1 %t463, label %bb93, label %bb94
bb93:
  br label %bb121
bb94:
  br label %bb95
bb95:
  %t466 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %s12, ptr %l28)
  %t467 = extractvalue { i32, i64 } %t466, 1
  %t468 = extractvalue { i32, i64 } %t466, 0
  store i32 %t468, ptr %l239
  %t469 = icmp ne i32 %t468, 0
  br i1 %t469, label %bb97, label %ok.470
ok.470:
  store i64 %t467, ptr %l238
  br label %bb96
bb96:
  %t471 = load i64, ptr %l238, !tbaa !24
  store i64 %t471, ptr %l236, !tbaa !24
  br label %bb99
bb97:
  br label %bb98
bb98:
  call void @__olang_ert_req_clear()
  br label %bb121
bb99:
  %t472 = load i64, ptr %l236, !tbaa !24
  store i64 %t472, ptr %l35, !tbaa !24
  %t473 = load i64, ptr %l35, !tbaa !24
  %t475 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t476 = load ptr, ptr %t475, !tbaa !27
  %t477 = getelementptr i1, ptr %t476, i64 %t473
  %t478 = load i1, ptr %t477, !tbaa !31
  br i1 %t478, label %bb100, label %bb101
bb100:
  br label %bb120
bb101:
  br label %bb102
bb102:
  %t480 = load i64, ptr %l35, !tbaa !24
  %t482 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t483 = load ptr, ptr %t482, !tbaa !27
  %t484 = getelementptr i1, ptr %t483, i64 %t480
  store i1 true, ptr %t484, !tbaa !31
  %t485 = load i64, ptr %l35, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s12, ptr %l27, i64 %t485)
  br label %bb103
bb103:
  %t488 = load i64, ptr %l35, !tbaa !24
  %t491 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %l3, i64 %t488)
  store ptr %t491, ptr %l247
  br label %bb104
bb104:
  %t492 = load ptr, ptr %l247, !tbaa !29
  %t494 = getelementptr %"compiler/load:Module", ptr %t492, i32 0, i32 11
  store ptr %t494, ptr %l36, !tbaa !29
  store i64 0, ptr %l37, !tbaa !24
  br label %bb105
bb105:
  %t496 = load i64, ptr %l37, !tbaa !24
  store i64 %t496, ptr %l250, !tbaa !24
  %t497 = load ptr, ptr %l36, !tbaa !29
  %t499 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eLen_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %t497)
  store i64 %t499, ptr %l252
  br label %bb106
bb106:
  %t500 = load i64, ptr %l250, !tbaa !24
  %t501 = load i64, ptr %l252, !tbaa !24
  %t502 = icmp slt i64 %t500, %t501
  %t504 = xor i1 %t502, true
  br i1 %t504, label %bb107, label %bb108
bb107:
  br label %bb119
bb108:
  br label %bb109
bb109:
  %t506 = load ptr, ptr %l36, !tbaa !29
  %t507 = load i64, ptr %l37, !tbaa !24
  %t510 = call %"compiler/load:Import" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eAt_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v0, ptr %t506, i64 %t507)
  store %"compiler/load:Import" %t510, ptr %l257
  br label %bb110
bb110:
  %t511 = load %"compiler/load:Import", ptr %l257
  store %"compiler/load:Import" %t511, ptr %l38
  %t512 = getelementptr %"compiler/load:Import", ptr %l38, i32 0, i32 5
  %t513 = load i64, ptr %t512, !tbaa !24
  %t515 = icmp sge i64 %t513, 0
  br i1 %t515, label %bb111, label %bb112
bb111:
  %t517 = getelementptr %"compiler/load:Import", ptr %l38, i32 0, i32 5
  %t518 = load i64, ptr %t517, !tbaa !24
  %t520 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t521 = load ptr, ptr %t520, !tbaa !27
  %t522 = getelementptr i1, ptr %t521, i64 %t518
  %t523 = load i1, ptr %t522, !tbaa !31
  %t525 = xor i1 %t523, true
  store i1 %t525, ptr %l260, !tbaa !21
  br label %bb113
bb112:
  store i1 false, ptr %l260, !tbaa !21
  br label %bb113
bb113:
  %t527 = load i1, ptr %l260, !tbaa !21
  br i1 %t527, label %bb114, label %bb115
bb114:
  %t528 = getelementptr %"compiler/load:Import", ptr %l38, i32 0, i32 5
  %t529 = load i64, ptr %t528, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s12, ptr %l28, i64 %t529)
  br label %bb116
bb115:
  br label %bb117
bb116:
  br label %bb117
bb117:
  br label %bb118
bb118:
  %t532 = load i64, ptr %l37, !tbaa !24
  %t534 = add i64 %t532, 1
  store i64 %t534, ptr %l37, !tbaa !24
  br label %bb105
bb119:
  br label %bb120
bb120:
  br label %bb91
bb121:
  %t536 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_277, 0
  %t537 = insertvalue { ptr, ptr } %t536, ptr null, 1
  %t540 = extractvalue { ptr, ptr } %t537, 0
  %t541 = extractvalue { ptr, ptr } %t537, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %s12, ptr %s12, ptr %l27, ptr %t540, ptr %t541)
  br label %bb122
bb122:
  %t542 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s12, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t542, ptr %l270
  br label %bb123
bb123:
  %t543 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l270
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t543, ptr %l39
  %t544 = load { i64, ptr }, ptr %l7, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s12, ptr %s0, ptr %l39, { i64, ptr } %t544)
  br label %bb124
bb124:
  %t547 = load i64, ptr %l25, !tbaa !24
  %t549 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t550 = load ptr, ptr %t549, !tbaa !27
  %t551 = getelementptr { i64, ptr }, ptr %t550, i64 %t547
  %t552 = load { i64, ptr }, ptr %t551, !tbaa !37
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s12, ptr %s0, ptr %l39, { i64, ptr } %t552)
  br label %bb125
bb125:
  store ptr %l27, ptr %l40, !tbaa !29
  store i64 0, ptr %l41, !tbaa !24
  br label %bb126
bb126:
  %t556 = load i64, ptr %l41, !tbaa !24
  store i64 %t556, ptr %l277, !tbaa !24
  %t557 = load ptr, ptr %l40, !tbaa !29
  %t559 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s12, ptr %t557)
  store i64 %t559, ptr %l279
  br label %bb127
bb127:
  %t560 = load i64, ptr %l277, !tbaa !24
  %t561 = load i64, ptr %l279, !tbaa !24
  %t562 = icmp slt i64 %t560, %t561
  %t564 = xor i1 %t562, true
  br i1 %t564, label %bb128, label %bb129
bb128:
  br label %bb135
bb129:
  br label %bb130
bb130:
  %t566 = load ptr, ptr %l40, !tbaa !29
  %t567 = load i64, ptr %l41, !tbaa !24
  %t570 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s12, ptr %t566, i64 %t567)
  store i64 %t570, ptr %l284
  br label %bb131
bb131:
  %t571 = load i64, ptr %l284, !tbaa !24
  store i64 %t571, ptr %l42, !tbaa !24
  store ptr %l39, ptr %l285, !tbaa !29
  %t572 = load i64, ptr %l42, !tbaa !24
  %t575 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %l3, i64 %t572)
  store ptr %t575, ptr %l288
  br label %bb132
bb132:
  %t576 = load ptr, ptr %l288, !tbaa !29
  %t578 = getelementptr %"compiler/load:Module", ptr %t576, i32 0, i32 2
  %t579 = load { i64, ptr }, ptr %t578, !tbaa !27
  %t580 = load i64, ptr %l42, !tbaa !24
  %t582 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t583 = load ptr, ptr %t582, !tbaa !27
  %t584 = getelementptr { i64, ptr }, ptr %t583, i64 %t580
  %t585 = load { i64, ptr }, ptr %t584, !tbaa !37
  %t587 = extractvalue { i64, ptr } %t579, 1
  %t588 = extractvalue { i64, ptr } %t579, 0
  %t589 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d278, i32 0, i32 1) }, 1
  %t590 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d278, i32 0, i32 1) }, 0
  %t591 = add i64 %t588, %t590
  %t593 = extractvalue { i64, ptr } %t585, 1
  %t594 = extractvalue { i64, ptr } %t585, 0
  %t595 = add i64 %t591, %t594
  %t596 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t595)
  call void @olang_textcopy(ptr %t596, ptr %t587, i64 %t588)
  %t597 = getelementptr i8, ptr %t596, i64 %t588
  call void @olang_textcopy(ptr %t597, ptr %t589, i64 %t590)
  %t598 = getelementptr i8, ptr %t597, i64 %t590
  call void @olang_textcopy(ptr %t598, ptr %t593, i64 %t594)
  %t599 = insertvalue { i64, ptr } undef, i64 %t595, 0
  %t600 = insertvalue { i64, ptr } %t599, ptr %t596, 1
  %t602 = extractvalue { i64, ptr } %t600, 0
  %t603 = extractvalue { i64, ptr } %t600, 1
  %t604 = mul i64 %t602, 1
  %t605 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t604)
  call void @llvm.memcpy.p0.p0.i64(ptr %t605, ptr %t603, i64 %t604, i1 false)
  %t606 = insertvalue { i64, ptr } undef, i64 %t602, 0
  %t607 = insertvalue { i64, ptr } %t606, ptr %t605, 1
  %t608 = load ptr, ptr %l285, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s12, ptr %s12, ptr %t608, { i64, ptr } %t607)
  br label %bb133
bb133:
  br label %bb134
bb134:
  %t610 = load i64, ptr %l41, !tbaa !24
  %t612 = add i64 %t610, 1
  store i64 %t612, ptr %l41, !tbaa !24
  br label %bb126
bb135:
  %t614 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t614, ptr %l297, !tbaa !27
  %t615 = load i64, ptr %l25, !tbaa !24
  store i64 %t615, ptr %l298, !tbaa !24
  %t617 = call { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %s12, ptr %v1, ptr %l39)
  store { i64, ptr } %t617, ptr %l300
  br label %bb136
bb136:
  %t618 = load { i64, ptr }, ptr %l300, !tbaa !27
  %t619 = extractvalue { i64, ptr } %t618, 0
  %t620 = extractvalue { i64, ptr } %t618, 1
  %t621 = mul i64 %t619, 1
  %t622 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t621)
  call void @llvm.memcpy.p0.p0.i64(ptr %t622, ptr %t620, i64 %t621, i1 false)
  %t623 = insertvalue { i64, ptr } undef, i64 %t619, 0
  %t624 = insertvalue { i64, ptr } %t623, ptr %t622, 1
  %t626 = load i64, ptr %l298, !tbaa !24
  %t627 = getelementptr { i64, ptr }, ptr %l297, i32 0, i32 1
  %t628 = load ptr, ptr %t627, !tbaa !27
  %t629 = getelementptr { i64, ptr }, ptr %t628, i64 %t626
  store { i64, ptr } %t624, ptr %t629, !tbaa !37
  call void @__olang_scope_close(ptr %s12)
  br label %bb137
bb137:
  %t630 = load i64, ptr %l24, !tbaa !24
  %t632 = add i64 %t630, 1
  store i64 %t632, ptr %l24, !tbaa !24
  br label %bb62
bb138:
  %t634 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t634, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local ptr @compiler_2folang_2eplacement(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l10 = alloca %"compiler/scope:Scoper"
  %l24 = alloca %"compiler/free:Free"
  %l26 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca i32
  %l30 = alloca { i64, ptr }
  %l33 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  %t9 = alloca %"compiler/scope:Scoper", align 8
  %t51 = alloca %"compiler/free:Free", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 12
  %t8 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t7
  call void @compiler_2fscope_3aScoper_2ector(ptr %t9, ptr %v0, ptr %v0, ptr %v1, ptr %t4, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t8)
  call void @llvm.memmove.p0.p0.i64(ptr %l10, ptr %t9, i64 1112, i1 false)
  br label %bb1
bb1:
  %t12 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 1112, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t12, ptr %l10, i64 1112, i1 false)
  store ptr %t12, ptr %l4, !tbaa !29
  %t14 = load ptr, ptr %l4, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr { ptr, ptr }, ptr null, i32 1
  %t17 = ptrtoint ptr %t16 to i64
  %t18 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 %t17, i64 8)
  %t19 = getelementptr { ptr, ptr }, ptr %t18, i32 0, i32 0
  store ptr %t15, ptr %t19, !tbaa !28
  call void @__olang_scope_escape(ptr %v0)
  %t21 = getelementptr { ptr, ptr }, ptr %t18, i32 0, i32 1
  store ptr %v0, ptr %t21, !tbaa !28
  %t22 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_279, 0
  %t23 = insertvalue { ptr, ptr } %t22, ptr %t18, 1
  %t26 = getelementptr %"compiler/scope:Scoper", ptr %t14, i32 0, i32 4
  store { ptr, ptr } %t23, ptr %t26
  %t27 = load ptr, ptr %l4, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr { ptr, ptr }, ptr null, i32 1
  %t30 = ptrtoint ptr %t29 to i64
  %t31 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 %t30, i64 8)
  %t32 = getelementptr { ptr, ptr }, ptr %t31, i32 0, i32 0
  store ptr %t28, ptr %t32, !tbaa !28
  call void @__olang_scope_escape(ptr %v0)
  %t34 = getelementptr { ptr, ptr }, ptr %t31, i32 0, i32 1
  store ptr %v0, ptr %t34, !tbaa !28
  %t35 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_280, 0
  %t36 = insertvalue { ptr, ptr } %t35, ptr %t31, 1
  %t39 = getelementptr %"compiler/scope:Scoper", ptr %t27, i32 0, i32 5
  store { ptr, ptr } %t36, ptr %t39
  %t40 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eRun(ptr %v1, ptr %t40)
  br label %bb2
bb2:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/check:Checker", ptr %t42, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/check:Checker", ptr %t46, i32 0, i32 12
  %t49 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t48
  %t50 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2ffree_3aFree_2ector(ptr %t51, ptr %v0, ptr %v0, ptr %v1, ptr %v1, ptr %t45, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t49, ptr %t50)
  call void @llvm.memmove.p0.p0.i64(ptr %l24, ptr %t51, i64 520, i1 false)
  br label %bb3
bb3:
  %t55 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 520, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t55, ptr %l24, i64 520, i1 false)
  store ptr %t55, ptr %l5, !tbaa !29
  %t57 = load ptr, ptr %l5, !tbaa !29
  store ptr %t57, ptr %l26, !tbaa !29
  %t58 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d281, i32 0, i32 1) })
  %t59 = extractvalue { i32, { i64, ptr } } %t58, 1
  %t60 = extractvalue { i32, { i64, ptr } } %t58, 0
  store i32 %t60, ptr %l29
  %t61 = icmp ne i32 %t60, 0
  br i1 %t61, label %bb5, label %ok.62
ok.62:
  store { i64, ptr } %t59, ptr %l28
  br label %bb4
bb4:
  %t63 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t63, ptr %l27, !tbaa !27
  br label %bb7
bb5:
  br label %bb6
bb6:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d282, i32 0, i32 1) }, ptr %l30, !tbaa !27
  %t64 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t64, 0
  %t67 = extractvalue { i64, ptr } %t64, 1
  %t68 = mul i64 %t66, 1
  %t69 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t68)
  call void @llvm.memcpy.p0.p0.i64(ptr %t69, ptr %t67, i64 %t68, i1 false)
  %t70 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t69, 1
  store { i64, ptr } %t71, ptr %l27, !tbaa !27
  br label %bb7
bb7:
  %t73 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t74 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t73, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d283, i32 0, i32 1) })
  store i1 %t74, ptr %l33
  br label %bb8
bb8:
  %t75 = load i1, ptr %l33, !tbaa !21
  %t76 = xor i1 %t75, true
  %t78 = load ptr, ptr %l26, !tbaa !29
  %t79 = getelementptr %"compiler/free:Free", ptr %t78, i32 0, i32 68
  store i1 %t76, ptr %t79, !tbaa !21
  %t80 = load ptr, ptr %l5, !tbaa !29
  %t81 = load ptr, ptr %l4, !tbaa !29
  %t83 = getelementptr %"compiler/scope:Scoper", ptr %t81, i32 0, i32 2
  %t84 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t83
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eDecide(ptr %v1, ptr %v1, ptr %t80, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t84, i64 %a2, i1 %a3)
  br label %bb9
bb9:
  %t91 = load ptr, ptr %l5, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t91, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2folang_2eputFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1, i32 %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l10 = alloca i32
  %l12 = alloca i1
  %l16 = alloca i32
  %l18 = alloca i1
  %l20 = alloca i32
  %l22 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t1, 1
  %t5 = extractvalue { i64, ptr } %t1, 0
  %t6 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d284, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d284, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t10 = sext i32 %a2 to i64
  %t11 = call i64 @__olang_fmt_i64(ptr null, i64 %t10)
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d285, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d285, i32 0, i32 1) }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t4, i64 %t5)
  %t17 = getelementptr i8, ptr %t16, i64 %t5
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  %t19 = call i64 @__olang_fmt_i64(ptr %t18, i64 %t10)
  %t20 = getelementptr i8, ptr %t18, i64 %t11
  call void @olang_textcopy(ptr %t20, ptr %t13, i64 %t14)
  %t21 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t16, 1
  store { i64, ptr } %t22, ptr %l3, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t29 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %v1, { i64, ptr } %t24, { i64, ptr } %a1)
  store i32 %t29, ptr %l10
  %t30 = icmp ne i32 %t29, 0
  br i1 %t30, label %bb2, label %ok.31
ok.31:
  br label %bb1
bb1:
  br label %bb4
bb2:
  %t32 = load i32, ptr %l10, !tbaa !23
  %t33 = ashr i32 %t32, 16
  %t35 = icmp eq i32 %t33, 1
  store i1 %t35, ptr %l12, !tbaa !21
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb4:
  %t37 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t41 = call i32 @std_2fos_2eRename(ptr %s0, ptr %v0, { i64, ptr } %t37, { i64, ptr } %t38)
  store i32 %t41, ptr %l16
  %t42 = icmp ne i32 %t41, 0
  br i1 %t42, label %bb6, label %ok.43
ok.43:
  br label %bb5
bb5:
  br label %bb12
bb6:
  %t44 = load i32, ptr %l16, !tbaa !23
  %t45 = ashr i32 %t44, 16
  %t47 = icmp eq i32 %t45, 1
  store i1 %t47, ptr %l18, !tbaa !21
  br label %bb7
bb7:
  call void @__olang_ert_req_clear()
  %t48 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t50 = call i32 @std_2fos_2eRemove(ptr %s0, { i64, ptr } %t48)
  store i32 %t50, ptr %l20
  %t51 = icmp ne i32 %t50, 0
  br i1 %t51, label %bb9, label %ok.52
ok.52:
  br label %bb8
bb8:
  br label %bb11
bb9:
  %t53 = load i32, ptr %l20, !tbaa !23
  %t54 = ashr i32 %t53, 16
  %t56 = icmp eq i32 %t54, 1
  store i1 %t56, ptr %l22, !tbaa !21
  br label %bb10
bb10:
  call void @__olang_ert_req_clear()
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb12:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2folang_2erecordPath(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/build:Config", ptr %a0, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l4, !tbaa !27
  %t7 = call { i64, ptr } @compiler_2fbuild_2eReadable(ptr %v1, ptr %s0, { i64, ptr } %a1)
  store { i64, ptr } %t7, ptr %l6
  br label %bb1
bb1:
  store { i64, ptr } %a2, ptr %l7, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t9, 0
  store i64 %t10, ptr %l8, !tbaa !24
  %t11 = icmp sge i64 0, 0
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = icmp sle i64 0, 20
  br i1 %t13, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @olang_loc_a5855f4dee34d57_8118d8286dddc923)
  unreachable
bb4:
  %t15 = load i64, ptr %l8, !tbaa !24
  %t16 = icmp sle i64 20, %t15
  br i1 %t16, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_a5855f4dee34d57_8118d8286dddc923)
  unreachable
bb6:
  %t18 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i8, ptr %t19, i64 0
  %t21 = sub i64 20, 0
  %t22 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t20, 1
  %t24 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t24, 1
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t27 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d286, i32 0, i32 1) }, 1
  %t28 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d286, i32 0, i32 1) }, 0
  %t29 = add i64 %t26, %t28
  %t30 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t30, 1
  %t32 = extractvalue { i64, ptr } %t30, 0
  %t33 = add i64 %t29, %t32
  %t34 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d287, i32 0, i32 1) }, 1
  %t35 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d287, i32 0, i32 1) }, 0
  %t36 = add i64 %t33, %t35
  %t38 = extractvalue { i64, ptr } %t23, 1
  %t39 = extractvalue { i64, ptr } %t23, 0
  %t40 = add i64 %t36, %t39
  %t41 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t40)
  call void @olang_textcopy(ptr %t41, ptr %t25, i64 %t26)
  %t42 = getelementptr i8, ptr %t41, i64 %t26
  call void @olang_textcopy(ptr %t42, ptr %t27, i64 %t28)
  %t43 = getelementptr i8, ptr %t42, i64 %t28
  call void @olang_textcopy(ptr %t43, ptr %t31, i64 %t32)
  %t44 = getelementptr i8, ptr %t43, i64 %t32
  call void @olang_textcopy(ptr %t44, ptr %t34, i64 %t35)
  %t45 = getelementptr i8, ptr %t44, i64 %t35
  call void @olang_textcopy(ptr %t45, ptr %t38, i64 %t39)
  %t46 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t41, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t47, ptr %rv
  br label %ret
bb7:
  call void @__olang_check_failed(ptr @olang_loc_a5855f4dee34d57_8118d8286dddc923)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2folang_2eretarget(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca %"std/prelude/text:LineIter"
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca %"std/prelude/text:StringBuilder"
  %l15 = alloca %"std/prelude/text:LineIter"
  %l16 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i32
  %l21 = alloca i1
  %l23 = alloca i1
  %l24 = alloca i1
  %l27 = alloca { i64, ptr }
  %l28 = alloca i1
  %l46 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i32
  %l53 = alloca i64
  %l57 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i64
  %l66 = alloca i64
  %l67 = alloca i32
  %l70 = alloca i64
  %l71 = alloca i64
  %l75 = alloca { i64, ptr }
  %l82 = alloca i64
  %l84 = alloca i64
  %l85 = alloca i64
  %l90 = alloca { i64, ptr }
  %l92 = alloca i64
  %l96 = alloca i64
  %l98 = alloca i64
  %l99 = alloca i32
  %l104 = alloca ptr
  %l105 = alloca i64
  %l106 = alloca i64
  %l110 = alloca { i64, ptr }
  %l111 = alloca { i64, ptr }
  %l112 = alloca i64
  %l114 = alloca i64
  %l115 = alloca i64
  %l124 = alloca { i64, ptr }
  %l125 = alloca { i64, ptr }
  %l126 = alloca i64
  %l127 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l13
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l13
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  %t5 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v0, { i64, ptr } %a0)
  store %"std/prelude/text:LineIter" %t5, ptr %l15
  br label %bb2
bb2:
  %t6 = load %"std/prelude/text:LineIter", ptr %l15
  store %"std/prelude/text:LineIter" %t6, ptr %l3
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t8 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %l3)
  %t9 = extractvalue { i32, { i64, ptr } } %t8, 1
  %t10 = extractvalue { i32, { i64, ptr } } %t8, 0
  store i32 %t10, ptr %l19
  %t11 = icmp ne i32 %t10, 0
  br i1 %t11, label %bb5, label %ok.12
ok.12:
  store { i64, ptr } %t9, ptr %l18
  br label %bb4
bb4:
  %t13 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t13, ptr %l16, !tbaa !27
  br label %bb7
bb5:
  %t14 = load i32, ptr %l19, !tbaa !23
  %t15 = ashr i32 %t14, 16
  %t17 = icmp eq i32 %t15, 1
  store i1 %t17, ptr %l21, !tbaa !21
  br label %bb6
bb6:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb82
bb7:
  %t18 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t18, ptr %l4, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t21 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t19, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d288, i32 0, i32 1) })
  store i1 %t21, ptr %l23
  br label %bb8
bb8:
  %t22 = load i1, ptr %l23, !tbaa !21
  br i1 %t22, label %bb9, label %bb10
bb9:
  %t23 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d289, i32 0, i32 1) }, ptr %l27, !tbaa !27
  %t26 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t27 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s2, { i64, ptr } %t23, { i64, ptr } %t26)
  store i1 %t27, ptr %l28
  br label %bb11
bb10:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb12
bb11:
  %t28 = load i1, ptr %l28, !tbaa !21
  store i1 %t28, ptr %l24, !tbaa !21
  br label %bb12
bb12:
  %t29 = load i1, ptr %l24, !tbaa !21
  %t30 = xor i1 %t29, true
  br i1 %t30, label %bb13, label %bb14
bb13:
  %t32 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %l2, { i64, ptr } %t32)
  br label %bb15
bb14:
  br label %bb17
bb15:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 10)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb81
bb17:
  %t36 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t36, 1
  %t39 = extractvalue { i64, ptr } %t36, 0
  %t40 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t39)
  call void @olang_textcopy(ptr %t40, ptr %t38, i64 %t39)
  %t41 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  store { i64, ptr } %t42, ptr %l5, !tbaa !27
  store %olang.scope zeroinitializer, ptr %s5
  %t44 = insertvalue [3 x { i64, ptr }] undef, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d290, i32 0, i32 1) }, 0
  %t45 = insertvalue [3 x { i64, ptr }] %t44, { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d291, i32 0, i32 1) }, 1
  %t46 = insertvalue [3 x { i64, ptr }] %t45, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d292, i32 0, i32 1) }, 2
  %t48 = call ptr @__olang_scope_alloc_a(ptr %s5, i64 48, i64 8)
  store [3 x { i64, ptr }] %t46, ptr %t48
  store ptr %t48, ptr %l6
  store i64 0, ptr %l7, !tbaa !24
  %t50 = load ptr, ptr %l6
  store i64 3, ptr %l8, !tbaa !24
  br label %bb18
bb18:
  %t53 = load i64, ptr %l7, !tbaa !24
  %t54 = load i64, ptr %l8, !tbaa !24
  %t57 = icmp slt i64 %t53, %t54
  %t59 = xor i1 %t57, true
  br i1 %t59, label %bb19, label %bb20
bb19:
  br label %bb58
bb20:
  br label %bb21
bb21:
  %t61 = load ptr, ptr %l6
  %t62 = load i64, ptr %l7, !tbaa !24
  %t65 = getelementptr [3 x { i64, ptr }], ptr %t61, i64 0, i64 %t62
  %t66 = load { i64, ptr }, ptr %t65, !tbaa !37
  store { i64, ptr } %t66, ptr %l9, !tbaa !27
  %t68 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t69 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t70 = load ptr, ptr @__olang_prog_scope
  %t73 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %s2, ptr %t70, { i64, ptr } %t68, { i64, ptr } %t69)
  %t74 = extractvalue { i32, i64 } %t73, 1
  %t75 = extractvalue { i32, i64 } %t73, 0
  store i32 %t75, ptr %l50
  %t76 = icmp ne i32 %t75, 0
  br i1 %t76, label %bb23, label %ok.77
ok.77:
  store i64 %t74, ptr %l49
  br label %bb22
bb22:
  %t78 = load i64, ptr %l49, !tbaa !24
  store i64 %t78, ptr %l46, !tbaa !24
  br label %bb25
bb23:
  br label %bb24
bb24:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l46, !tbaa !24
  br label %bb25
bb25:
  %t79 = load i64, ptr %l46, !tbaa !24
  store i64 %t79, ptr %l10, !tbaa !24
  %t80 = load i64, ptr %l10, !tbaa !24
  %t82 = icmp slt i64 %t80, 0
  br i1 %t82, label %bb26, label %bb27
bb26:
  br label %bb57
bb27:
  br label %bb28
bb28:
  %t84 = load i64, ptr %l10, !tbaa !24
  %t85 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t85, 0
  %t90 = add i64 %t84, %t87
  store i64 %t90, ptr %l57, !tbaa !24
  %t91 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t91, 0
  store i64 %t93, ptr %l59, !tbaa !24
  %t94 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t94, 0
  store i64 %t95, ptr %l60, !tbaa !24
  %t96 = load i64, ptr %l57, !tbaa !24
  %t97 = icmp sge i64 %t96, 0
  br i1 %t97, label %bb29, label %bb30
bb29:
  %t99 = load i64, ptr %l57, !tbaa !24
  %t100 = load i64, ptr %l59, !tbaa !24
  %t101 = icmp sle i64 %t99, %t100
  br i1 %t101, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_f7f4c072cfaa5bcd_bcba1f0f81b5e6d1)
  unreachable
bb31:
  %t103 = load i64, ptr %l59, !tbaa !24
  %t104 = load i64, ptr %l60, !tbaa !24
  %t105 = icmp sle i64 %t103, %t104
  br i1 %t105, label %bb33, label %bb34
bb32:
  call void @__olang_check_failed(ptr @olang_loc_f7f4c072cfaa5bcd_bcba1f0f81b5e6d1)
  unreachable
bb33:
  %t107 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = load i64, ptr %l57, !tbaa !24
  %t110 = load i64, ptr %l59, !tbaa !24
  %t111 = getelementptr i8, ptr %t108, i64 %t109
  %t112 = sub i64 %t110, %t109
  %t113 = insertvalue { i64, ptr } undef, i64 %t112, 0
  %t114 = insertvalue { i64, ptr } %t113, ptr %t111, 1
  %t117 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %s2, { i64, ptr } %t114, i8 34)
  %t118 = extractvalue { i32, i64 } %t117, 1
  %t119 = extractvalue { i32, i64 } %t117, 0
  store i32 %t119, ptr %l67
  %t120 = icmp ne i32 %t119, 0
  br i1 %t120, label %bb36, label %ok.121
ok.121:
  store i64 %t118, ptr %l66
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_f7f4c072cfaa5bcd_bcba1f0f81b5e6d1)
  unreachable
bb35:
  %t122 = load i64, ptr %l66, !tbaa !24
  store i64 %t122, ptr %l53, !tbaa !24
  br label %bb38
bb36:
  br label %bb37
bb37:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l53, !tbaa !24
  br label %bb38
bb38:
  %t123 = load i64, ptr %l53, !tbaa !24
  store i64 %t123, ptr %l11, !tbaa !24
  %t124 = load i64, ptr %l11, !tbaa !24
  %t126 = icmp slt i64 %t124, 0
  br i1 %t126, label %bb39, label %bb40
bb39:
  br label %bb57
bb40:
  br label %bb41
bb41:
  %t128 = load i64, ptr %l10, !tbaa !24
  store i64 %t128, ptr %l70, !tbaa !24
  %t129 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t130 = extractvalue { i64, ptr } %t129, 0
  store i64 %t130, ptr %l71, !tbaa !24
  %t131 = icmp sge i64 0, 0
  br i1 %t131, label %bb42, label %bb43
bb42:
  %t133 = load i64, ptr %l70, !tbaa !24
  %t134 = icmp sle i64 0, %t133
  br i1 %t134, label %bb44, label %bb45
bb43:
  call void @__olang_check_failed(ptr @olang_loc_e0ebb5362b30f9f0_cd8defb7a2603e4)
  unreachable
bb44:
  %t136 = load i64, ptr %l70, !tbaa !24
  %t137 = load i64, ptr %l71, !tbaa !24
  %t138 = icmp sle i64 %t136, %t137
  br i1 %t138, label %bb46, label %bb47
bb45:
  call void @__olang_check_failed(ptr @olang_loc_e0ebb5362b30f9f0_cd8defb7a2603e4)
  unreachable
bb46:
  %t140 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !27
  %t142 = load i64, ptr %l70, !tbaa !24
  %t143 = getelementptr i8, ptr %t141, i64 0
  %t144 = sub i64 %t142, 0
  %t145 = insertvalue { i64, ptr } undef, i64 %t144, 0
  %t146 = insertvalue { i64, ptr } %t145, ptr %t143, 1
  store { i64, ptr } %t146, ptr %l75, !tbaa !27
  %t147 = load i64, ptr %l10, !tbaa !24
  %t148 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t150 = extractvalue { i64, ptr } %t148, 0
  %t153 = add i64 %t147, %t150
  %t154 = load i64, ptr %l11, !tbaa !24
  %t157 = add i64 %t153, %t154
  %t159 = add i64 %t157, 1
  store i64 %t159, ptr %l82, !tbaa !24
  %t160 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t162 = extractvalue { i64, ptr } %t160, 0
  store i64 %t162, ptr %l84, !tbaa !24
  %t163 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t164 = extractvalue { i64, ptr } %t163, 0
  store i64 %t164, ptr %l85, !tbaa !24
  %t165 = load i64, ptr %l82, !tbaa !24
  %t166 = icmp sge i64 %t165, 0
  br i1 %t166, label %bb48, label %bb49
bb47:
  call void @__olang_check_failed(ptr @olang_loc_e0ebb5362b30f9f0_cd8defb7a2603e4)
  unreachable
bb48:
  %t168 = load i64, ptr %l82, !tbaa !24
  %t169 = load i64, ptr %l84, !tbaa !24
  %t170 = icmp sle i64 %t168, %t169
  br i1 %t170, label %bb50, label %bb51
bb49:
  call void @__olang_check_failed(ptr @olang_loc_e0ebb5362b30f9f0_cd8defb7a2603e4)
  unreachable
bb50:
  %t172 = load i64, ptr %l84, !tbaa !24
  %t173 = load i64, ptr %l85, !tbaa !24
  %t174 = icmp sle i64 %t172, %t173
  br i1 %t174, label %bb52, label %bb53
bb51:
  call void @__olang_check_failed(ptr @olang_loc_e0ebb5362b30f9f0_cd8defb7a2603e4)
  unreachable
bb52:
  %t176 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = load i64, ptr %l82, !tbaa !24
  %t179 = load i64, ptr %l84, !tbaa !24
  %t180 = getelementptr i8, ptr %t177, i64 %t178
  %t181 = sub i64 %t179, %t178
  %t182 = insertvalue { i64, ptr } undef, i64 %t181, 0
  %t183 = insertvalue { i64, ptr } %t182, ptr %t180, 1
  %t184 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t185 = extractvalue { i64, ptr } %t184, 1
  %t186 = extractvalue { i64, ptr } %t184, 0
  %t188 = extractvalue { i64, ptr } %t183, 1
  %t189 = extractvalue { i64, ptr } %t183, 0
  %t190 = add i64 %t186, %t189
  %t191 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t190)
  call void @olang_textcopy(ptr %t191, ptr %t185, i64 %t186)
  %t192 = getelementptr i8, ptr %t191, i64 %t186
  call void @olang_textcopy(ptr %t192, ptr %t188, i64 %t189)
  %t193 = insertvalue { i64, ptr } undef, i64 %t190, 0
  %t194 = insertvalue { i64, ptr } %t193, ptr %t191, 1
  store { i64, ptr } %t194, ptr %l90, !tbaa !27
  %t195 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t196 = extractvalue { i64, ptr } %t195, 0
  %t197 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t198 = extractvalue { i64, ptr } %t197, 0
  store i64 %t198, ptr %l92, !tbaa !24
  %t200 = load i64, ptr %l92, !tbaa !24
  %t201 = icmp eq i64 %t196, %t200
  br i1 %t201, label %bb54, label %bb55
bb53:
  call void @__olang_check_failed(ptr @olang_loc_e0ebb5362b30f9f0_cd8defb7a2603e4)
  unreachable
bb54:
  %t203 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t204 = load ptr, ptr %t203, !tbaa !27
  %t205 = getelementptr { i64, ptr }, ptr %l90, i32 0, i32 1
  %t206 = load ptr, ptr %t205, !tbaa !27
  %t207 = load i64, ptr %l92, !tbaa !24
  %t208 = mul i64 %t207, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t204, ptr %t206, i64 %t208, i1 false)
  br label %bb56
bb55:
  %t209 = load { i64, ptr }, ptr %l90, !tbaa !27
  store { i64, ptr } %t209, ptr %l5, !tbaa !27
  br label %bb56
bb56:
  br label %bb57
bb57:
  %t210 = load i64, ptr %l7, !tbaa !24
  %t212 = add i64 %t210, 1
  store i64 %t212, ptr %l7, !tbaa !24
  br label %bb18
bb58:
  call void @__olang_scope_close(ptr %s5)
  %t214 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t216 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %s2, ptr %s2, { i64, ptr } %t214, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d293, i32 0, i32 1) })
  %t217 = extractvalue { i32, i64 } %t216, 1
  %t218 = extractvalue { i32, i64 } %t216, 0
  store i32 %t218, ptr %l99
  %t219 = icmp ne i32 %t218, 0
  br i1 %t219, label %bb60, label %ok.220
ok.220:
  store i64 %t217, ptr %l98
  br label %bb59
bb59:
  %t221 = load i64, ptr %l98, !tbaa !24
  store i64 %t221, ptr %l96, !tbaa !24
  br label %bb62
bb60:
  br label %bb61
bb61:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l96, !tbaa !24
  br label %bb62
bb62:
  %t222 = load i64, ptr %l96, !tbaa !24
  store i64 %t222, ptr %l12, !tbaa !24
  %t223 = load i64, ptr %l12, !tbaa !24
  %t225 = icmp slt i64 %t223, 0
  br i1 %t225, label %bb63, label %bb64
bb63:
  %t227 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %l2, { i64, ptr } %t227)
  br label %bb65
bb64:
  store %olang.scope zeroinitializer, ptr %s12
  store ptr %l2, ptr %l104, !tbaa !29
  %t230 = load i64, ptr %l12, !tbaa !24
  store i64 %t230, ptr %l105, !tbaa !24
  %t231 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t232 = extractvalue { i64, ptr } %t231, 0
  store i64 %t232, ptr %l106, !tbaa !24
  %t233 = icmp sge i64 0, 0
  br i1 %t233, label %bb66, label %bb67
bb65:
  br label %bb79
bb66:
  %t235 = load i64, ptr %l105, !tbaa !24
  %t236 = icmp sle i64 0, %t235
  br i1 %t236, label %bb68, label %bb69
bb67:
  call void @__olang_check_failed(ptr @olang_loc_b1bbe7d7728f376b_6cafbb8887a833cf)
  unreachable
bb68:
  %t238 = load i64, ptr %l105, !tbaa !24
  %t239 = load i64, ptr %l106, !tbaa !24
  %t240 = icmp sle i64 %t238, %t239
  br i1 %t240, label %bb70, label %bb71
bb69:
  call void @__olang_check_failed(ptr @olang_loc_b1bbe7d7728f376b_6cafbb8887a833cf)
  unreachable
bb70:
  %t242 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t243 = load ptr, ptr %t242, !tbaa !27
  %t244 = load i64, ptr %l105, !tbaa !24
  %t245 = getelementptr i8, ptr %t243, i64 0
  %t246 = sub i64 %t244, 0
  %t247 = insertvalue { i64, ptr } undef, i64 %t246, 0
  %t248 = insertvalue { i64, ptr } %t247, ptr %t245, 1
  store { i64, ptr } %t248, ptr %l110, !tbaa !27
  store { i64, ptr } %a1, ptr %l111, !tbaa !27
  %t250 = load i64, ptr %l12, !tbaa !24
  store i64 %t250, ptr %l112, !tbaa !24
  %t251 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t253 = extractvalue { i64, ptr } %t251, 0
  store i64 %t253, ptr %l114, !tbaa !24
  %t254 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t255 = extractvalue { i64, ptr } %t254, 0
  store i64 %t255, ptr %l115, !tbaa !24
  %t256 = load i64, ptr %l112, !tbaa !24
  %t257 = icmp sge i64 %t256, 0
  br i1 %t257, label %bb72, label %bb73
bb71:
  call void @__olang_check_failed(ptr @olang_loc_b1bbe7d7728f376b_6cafbb8887a833cf)
  unreachable
bb72:
  %t259 = load i64, ptr %l112, !tbaa !24
  %t260 = load i64, ptr %l114, !tbaa !24
  %t261 = icmp sle i64 %t259, %t260
  br i1 %t261, label %bb74, label %bb75
bb73:
  call void @__olang_check_failed(ptr @olang_loc_b1bbe7d7728f376b_6cafbb8887a833cf)
  unreachable
bb74:
  %t263 = load i64, ptr %l114, !tbaa !24
  %t264 = load i64, ptr %l115, !tbaa !24
  %t265 = icmp sle i64 %t263, %t264
  br i1 %t265, label %bb76, label %bb77
bb75:
  call void @__olang_check_failed(ptr @olang_loc_b1bbe7d7728f376b_6cafbb8887a833cf)
  unreachable
bb76:
  %t267 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t268 = load ptr, ptr %t267, !tbaa !27
  %t269 = load i64, ptr %l112, !tbaa !24
  %t270 = load i64, ptr %l114, !tbaa !24
  %t271 = getelementptr i8, ptr %t268, i64 %t269
  %t272 = sub i64 %t270, %t269
  %t273 = insertvalue { i64, ptr } undef, i64 %t272, 0
  %t274 = insertvalue { i64, ptr } %t273, ptr %t271, 1
  %t275 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t276 = extractvalue { i64, ptr } %t275, 1
  %t277 = extractvalue { i64, ptr } %t275, 0
  %t278 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t279 = extractvalue { i64, ptr } %t278, 1
  %t280 = extractvalue { i64, ptr } %t278, 0
  %t281 = add i64 %t277, %t280
  %t282 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d294, i32 0, i32 1) }, 1
  %t283 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d294, i32 0, i32 1) }, 0
  %t284 = add i64 %t281, %t283
  %t286 = extractvalue { i64, ptr } %t274, 1
  %t287 = extractvalue { i64, ptr } %t274, 0
  %t288 = add i64 %t284, %t287
  %t289 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t288)
  call void @olang_textcopy(ptr %t289, ptr %t276, i64 %t277)
  %t290 = getelementptr i8, ptr %t289, i64 %t277
  call void @olang_textcopy(ptr %t290, ptr %t279, i64 %t280)
  %t291 = getelementptr i8, ptr %t290, i64 %t280
  call void @olang_textcopy(ptr %t291, ptr %t282, i64 %t283)
  %t292 = getelementptr i8, ptr %t291, i64 %t283
  call void @olang_textcopy(ptr %t292, ptr %t286, i64 %t287)
  %t293 = insertvalue { i64, ptr } undef, i64 %t288, 0
  %t294 = insertvalue { i64, ptr } %t293, ptr %t289, 1
  %t296 = extractvalue { i64, ptr } %t294, 0
  %t297 = extractvalue { i64, ptr } %t294, 1
  %t298 = mul i64 %t296, 1
  %t299 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t298)
  call void @llvm.memcpy.p0.p0.i64(ptr %t299, ptr %t297, i64 %t298, i1 false)
  %t300 = insertvalue { i64, ptr } undef, i64 %t296, 0
  %t301 = insertvalue { i64, ptr } %t300, ptr %t299, 1
  %t302 = load ptr, ptr %l104, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s12, ptr %t302, { i64, ptr } %t301)
  br label %bb78
bb77:
  call void @__olang_check_failed(ptr @olang_loc_b1bbe7d7728f376b_6cafbb8887a833cf)
  unreachable
bb78:
  call void @__olang_scope_close(ptr %s12)
  br label %bb79
bb79:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 10)
  br label %bb80
bb80:
  call void @__olang_scope_close(ptr %s2)
  br label %bb81
bb81:
  br label %bb3
bb82:
  %t306 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l2)
  store { i64, ptr } %t306, ptr %l124
  br label %bb83
bb83:
  %t307 = load { i64, ptr }, ptr %l124, !tbaa !27
  store { i64, ptr } %t307, ptr %l125, !tbaa !27
  %t308 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t309 = extractvalue { i64, ptr } %t308, 0
  store i64 %t309, ptr %l126, !tbaa !24
  %t310 = load i64, ptr %l126, !tbaa !24
  %t311 = mul i64 %t310, 1
  %t312 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t311)
  %t313 = insertvalue { i64, ptr } undef, i64 %t310, 0
  %t314 = insertvalue { i64, ptr } %t313, ptr %t312, 1
  store { i64, ptr } %t314, ptr %l127, !tbaa !27
  %t315 = getelementptr { i64, ptr }, ptr %l127, i32 0, i32 1
  %t316 = load ptr, ptr %t315, !tbaa !27
  %t317 = getelementptr { i64, ptr }, ptr %l125, i32 0, i32 1
  %t318 = load ptr, ptr %t317, !tbaa !27
  %t319 = load i64, ptr %l126, !tbaa !24
  %t320 = mul i64 %t319, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t316, ptr %t318, i64 %t320, i1 false)
  %t321 = load { i64, ptr }, ptr %l127, !tbaa !27
  store { i64, ptr } %t321, ptr %l125, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t322 = load { i64, ptr }, ptr %l125, !tbaa !27
  store { i64, ptr } %t322, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2folang_2ereusable(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %lp3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %lp12 = alloca ptr
  %l13 = alloca i1
  %l14 = alloca %"std/prelude/text:LineIter"
  %l15 = alloca { i64, ptr }
  %l16 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l22 = alloca i64
  %l25 = alloca i64
  %l43 = alloca { i64, ptr }
  %l46 = alloca i1
  %l47 = alloca ptr
  %l51 = alloca ptr
  %l54 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l61 = alloca i32
  %l63 = alloca i1
  %l65 = alloca %"compiler/emit:Reused"
  %l67 = alloca %"std/prelude/text:LineIter"
  %l68 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l71 = alloca i32
  %l73 = alloca i1
  %l75 = alloca i1
  %l77 = alloca i1
  %l78 = alloca i64
  %l79 = alloca { i64, ptr }
  %l82 = alloca i64
  %l83 = alloca i64
  %l87 = alloca { i64, ptr }
  %l88 = alloca i64
  %l89 = alloca i32
  %l90 = alloca i64
  %l91 = alloca i32
  %l93 = alloca i1
  %l94 = alloca { i64, ptr }
  %l97 = alloca i64
  %l98 = alloca i64
  %l103 = alloca i1
  %l105 = alloca i1
  %l106 = alloca ptr
  %l107 = alloca { i64, ptr }
  %l110 = alloca i64
  %l111 = alloca i64
  %l119 = alloca i1
  %l120 = alloca i1
  %l122 = alloca i1
  %l126 = alloca i1
  %l127 = alloca { i64, ptr }
  %l130 = alloca i1
  %l131 = alloca { i64, ptr }
  %l133 = alloca i64
  %l136 = alloca i1
  %l138 = alloca ptr
  %l139 = alloca { i64, ptr }
  %l140 = alloca i64
  %l147 = alloca ptr
  %l148 = alloca { i64, ptr }
  %l151 = alloca i64
  %l152 = alloca i64
  %l159 = alloca ptr
  %l161 = alloca i1
  %l163 = alloca i1
  %l165 = alloca i64
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2femit_3aReused_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l16
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 8, i64 8)
  store ptr %t2, ptr %lp3
  %t3 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l16
  %t4 = load ptr, ptr %lp3
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %t4
  store i64 0, ptr %l4, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t9 = load i64, ptr %l5, !tbaa !24
  %t10 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb2, label %bb3
bb2:
  %t15 = load i64, ptr %l6, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb7
bb4:
  %t19 = load i64, ptr %l5, !tbaa !24
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l6, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l6, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l25, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb6
bb6:
  %t35 = load i64, ptr %l25, !tbaa !24
  store i64 %t35, ptr %l22, !tbaa !24
  br label %bb7
bb7:
  %t36 = load i64, ptr %l22, !tbaa !24
  store i64 %t36, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t37 = load i64, ptr %l8, !tbaa !24
  %t38 = load i64, ptr %l7, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb117
bb10:
  br label %bb11
bb11:
  %t45 = load i64, ptr %l4, !tbaa !24
  %t46 = load i64, ptr %l8, !tbaa !24
  %t47 = load i64, ptr %l6, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  store i64 %t53, ptr %l9, !tbaa !24
  %t55 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t55, ptr %l43, !tbaa !27
  %t56 = load i64, ptr %l9, !tbaa !24
  %t58 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr { i64, ptr }, ptr %t59, i64 %t56
  %t61 = load { i64, ptr }, ptr %t60, !tbaa !37
  %t63 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s2, { i64, ptr } %t61, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d295, i32 0, i32 1) })
  store i1 %t63, ptr %l46
  br label %bb12
bb12:
  %t64 = load i1, ptr %l46, !tbaa !21
  br i1 %t64, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb116
bb14:
  br label %bb15
bb15:
  store ptr %a1, ptr %l47, !tbaa !29
  %t68 = getelementptr %"compiler/load:Loader", ptr %a0, i32 0, i32 5
  %t69 = load i64, ptr %l9, !tbaa !24
  %t72 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t68, i64 %t69)
  store ptr %t72, ptr %l51
  br label %bb16
bb16:
  %t73 = load ptr, ptr %l51, !tbaa !29
  %t75 = getelementptr %"compiler/load:Module", ptr %t73, i32 0, i32 2
  %t76 = load { i64, ptr }, ptr %t75, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t77, ptr %l54, !tbaa !27
  %t78 = load i64, ptr %l9, !tbaa !24
  %t80 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = getelementptr { i64, ptr }, ptr %t81, i64 %t78
  %t83 = load { i64, ptr }, ptr %t82, !tbaa !37
  %t84 = load ptr, ptr %l47, !tbaa !29
  %t87 = call { i64, ptr } @compiler_2folang_2erecordPath(ptr %v1, ptr %v0, ptr %v2, ptr %s2, ptr %t84, { i64, ptr } %t76, { i64, ptr } %t83)
  store { i64, ptr } %t87, ptr %l57
  br label %bb17
bb17:
  %t88 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t88, ptr %l10, !tbaa !27
  %t89 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t91 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s2, ptr %s2, { i64, ptr } %t89)
  %t92 = extractvalue { i32, { i64, ptr } } %t91, 1
  %t93 = extractvalue { i32, { i64, ptr } } %t91, 0
  store i32 %t93, ptr %l61
  %t94 = icmp ne i32 %t93, 0
  br i1 %t94, label %bb19, label %ok.95
ok.95:
  store { i64, ptr } %t92, ptr %l60
  br label %bb18
bb18:
  %t96 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t96, ptr %l58, !tbaa !27
  br label %bb21
bb19:
  %t97 = load i32, ptr %l61, !tbaa !23
  %t98 = ashr i32 %t97, 16
  %t100 = icmp eq i32 %t98, 1
  store i1 %t100, ptr %l63, !tbaa !21
  br label %bb20
bb20:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb116
bb21:
  %t101 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t101, ptr %l11, !tbaa !27
  %t102 = load i64, ptr %l9, !tbaa !24
  %t104 = call %"compiler/emit:Reused" @compiler_2femit_3aReused_2ector(ptr %v3, i64 %t102)
  store %"compiler/emit:Reused" %t104, ptr %l65
  br label %bb22
bb22:
  %t105 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 64, i64 8)
  store ptr %t105, ptr %lp12
  %t106 = load %"compiler/emit:Reused", ptr %l65
  %t107 = load ptr, ptr %lp12
  store %"compiler/emit:Reused" %t106, ptr %t107
  store i1 false, ptr %l13, !tbaa !21
  %t108 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t110 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %s2, ptr %s2, { i64, ptr } %t108)
  store %"std/prelude/text:LineIter" %t110, ptr %l67
  br label %bb23
bb23:
  %t111 = load %"std/prelude/text:LineIter", ptr %l67
  store %"std/prelude/text:LineIter" %t111, ptr %l14
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s6
  %t113 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %s2, ptr %l14)
  %t114 = extractvalue { i32, { i64, ptr } } %t113, 1
  %t115 = extractvalue { i32, { i64, ptr } } %t113, 0
  store i32 %t115, ptr %l71
  %t116 = icmp ne i32 %t115, 0
  br i1 %t116, label %bb26, label %ok.117
ok.117:
  store { i64, ptr } %t114, ptr %l70
  br label %bb25
bb25:
  %t118 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t118, ptr %l68, !tbaa !27
  br label %bb28
bb26:
  %t119 = load i32, ptr %l71, !tbaa !23
  %t120 = ashr i32 %t119, 16
  %t122 = icmp eq i32 %t120, 1
  store i1 %t122, ptr %l73, !tbaa !21
  br label %bb27
bb27:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s6)
  br label %bb107
bb28:
  %t123 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t123, ptr %l15, !tbaa !27
  %t124 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t126 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s6, { i64, ptr } %t124, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d296, i32 0, i32 1) })
  store i1 %t126, ptr %l75
  br label %bb29
bb29:
  %t127 = load i1, ptr %l75, !tbaa !21
  br i1 %t127, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb105
bb31:
  store %olang.scope zeroinitializer, ptr %s8
  %t128 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t130 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s2, ptr %s8, { i64, ptr } %t128, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d297, i32 0, i32 1) })
  store i1 %t130, ptr %l77
  br label %bb32
bb32:
  %t131 = load i1, ptr %l77, !tbaa !21
  br i1 %t131, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s9
  %t132 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t132, ptr %l79, !tbaa !27
  %t133 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t133, 0
  store i64 %t136, ptr %l82, !tbaa !24
  %t137 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t137, 0
  store i64 %t138, ptr %l83, !tbaa !24
  %t139 = icmp sge i64 5, 0
  br i1 %t139, label %bb35, label %bb36
bb34:
  store %olang.scope zeroinitializer, ptr %s10
  %t141 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t143 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s2, ptr %s10, { i64, ptr } %t141, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d298, i32 0, i32 1) })
  store i1 %t143, ptr %l93
  br label %bb47
bb35:
  %t144 = load i64, ptr %l82, !tbaa !24
  %t145 = icmp sle i64 5, %t144
  br i1 %t145, label %bb37, label %bb38
bb36:
  call void @__olang_check_failed(ptr @olang_loc_ff68d2ed4a63ad2_3df325967a6cbd9e)
  unreachable
bb37:
  %t147 = load i64, ptr %l82, !tbaa !24
  %t148 = load i64, ptr %l83, !tbaa !24
  %t149 = icmp sle i64 %t147, %t148
  br i1 %t149, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @olang_loc_ff68d2ed4a63ad2_3df325967a6cbd9e)
  unreachable
bb39:
  %t151 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = load i64, ptr %l82, !tbaa !24
  %t154 = getelementptr i8, ptr %t152, i64 5
  %t155 = sub i64 %t153, 5
  %t156 = insertvalue { i64, ptr } undef, i64 %t155, 0
  %t157 = insertvalue { i64, ptr } %t156, ptr %t154, 1
  store { i64, ptr } %t157, ptr %l87, !tbaa !27
  %t158 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s9, i64 10)
  %t159 = extractvalue { i32, i64 } %t158, 1
  %t160 = extractvalue { i32, i64 } %t158, 0
  store i32 %t160, ptr %l89
  %t161 = icmp ne i32 %t160, 0
  br i1 %t161, label %bb42, label %ok.162
ok.162:
  store i64 %t159, ptr %l88
  br label %bb41
bb40:
  call void @__olang_check_failed(ptr @olang_loc_ff68d2ed4a63ad2_3df325967a6cbd9e)
  unreachable
bb41:
  %t163 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t164 = load i64, ptr %l88, !tbaa !24
  %t165 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s2, { i64, ptr } %t163, i64 %t164)
  %t166 = extractvalue { i32, i64 } %t165, 1
  %t167 = extractvalue { i32, i64 } %t165, 0
  store i32 %t167, ptr %l91
  %t168 = icmp ne i32 %t167, 0
  br i1 %t168, label %bb45, label %ok.169
ok.169:
  store i64 %t166, ptr %l90
  br label %bb44
bb42:
  br label %bb43
bb43:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l78, !tbaa !24
  br label %bb46
bb44:
  %t170 = load i64, ptr %l90, !tbaa !24
  store i64 %t170, ptr %l78, !tbaa !24
  br label %bb46
bb45:
  br label %bb43
bb46:
  %t171 = load i64, ptr %l78, !tbaa !24
  %t172 = load ptr, ptr %lp12
  %t173 = getelementptr %"compiler/emit:Reused", ptr %t172, i32 0, i32 4
  store i64 %t171, ptr %t173, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  br label %bb104
bb47:
  %t174 = load i1, ptr %l93, !tbaa !21
  br i1 %t174, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s11
  %t175 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t175, ptr %l94, !tbaa !27
  %t176 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t179 = extractvalue { i64, ptr } %t176, 0
  store i64 %t179, ptr %l97, !tbaa !24
  %t180 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t181 = extractvalue { i64, ptr } %t180, 0
  store i64 %t181, ptr %l98, !tbaa !24
  %t182 = icmp sge i64 6, 0
  br i1 %t182, label %bb50, label %bb51
bb49:
  store %olang.scope zeroinitializer, ptr %s12
  %t184 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t186 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s2, ptr %s12, { i64, ptr } %t184, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d299, i32 0, i32 1) })
  store i1 %t186, ptr %l105
  br label %bb57
bb50:
  %t187 = load i64, ptr %l97, !tbaa !24
  %t188 = icmp sle i64 6, %t187
  br i1 %t188, label %bb52, label %bb53
bb51:
  call void @__olang_check_failed(ptr @olang_loc_909229aa1239aacf_261ce50abd32cd9b)
  unreachable
bb52:
  %t190 = load i64, ptr %l97, !tbaa !24
  %t191 = load i64, ptr %l98, !tbaa !24
  %t192 = icmp sle i64 %t190, %t191
  br i1 %t192, label %bb54, label %bb55
bb53:
  call void @__olang_check_failed(ptr @olang_loc_909229aa1239aacf_261ce50abd32cd9b)
  unreachable
bb54:
  %t194 = getelementptr { i64, ptr }, ptr %l94, i32 0, i32 1
  %t195 = load ptr, ptr %t194, !tbaa !27
  %t196 = load i64, ptr %l97, !tbaa !24
  %t197 = getelementptr i8, ptr %t195, i64 6
  %t198 = sub i64 %t196, 6
  %t199 = insertvalue { i64, ptr } undef, i64 %t198, 0
  %t200 = insertvalue { i64, ptr } %t199, ptr %t197, 1
  %t202 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s11, { i64, ptr } %t200, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d300, i32 0, i32 1) })
  store i1 %t202, ptr %l103
  br label %bb56
bb55:
  call void @__olang_check_failed(ptr @olang_loc_909229aa1239aacf_261ce50abd32cd9b)
  unreachable
bb56:
  %t203 = load i1, ptr %l103, !tbaa !21
  %t204 = load ptr, ptr %lp12
  %t205 = getelementptr %"compiler/emit:Reused", ptr %t204, i32 0, i32 5
  store i1 %t203, ptr %t205, !tbaa !21
  call void @__olang_scope_close(ptr %s11)
  br label %bb103
bb57:
  %t206 = load i1, ptr %l105, !tbaa !21
  br i1 %t206, label %bb58, label %bb59
bb58:
  %t207 = load ptr, ptr %lp12
  %t208 = getelementptr %"compiler/emit:Reused", ptr %t207, i32 0, i32 6
  store ptr %t208, ptr %l106, !tbaa !29
  %t209 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t209, ptr %l107, !tbaa !27
  %t210 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t213 = extractvalue { i64, ptr } %t210, 0
  store i64 %t213, ptr %l110, !tbaa !24
  %t214 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t215 = extractvalue { i64, ptr } %t214, 0
  store i64 %t215, ptr %l111, !tbaa !24
  %t216 = icmp sge i64 5, 0
  br i1 %t216, label %bb60, label %bb61
bb59:
  store %olang.scope zeroinitializer, ptr %s15
  %t218 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t220 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s2, ptr %s15, { i64, ptr } %t218, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d301, i32 0, i32 1) })
  store i1 %t220, ptr %l119
  br label %bb67
bb60:
  %t221 = load i64, ptr %l110, !tbaa !24
  %t222 = icmp sle i64 5, %t221
  br i1 %t222, label %bb62, label %bb63
bb61:
  call void @__olang_check_failed(ptr @olang_loc_30bb4d1d04b77ae4_b48bc1201be9b2a0)
  unreachable
bb62:
  %t224 = load i64, ptr %l110, !tbaa !24
  %t225 = load i64, ptr %l111, !tbaa !24
  %t226 = icmp sle i64 %t224, %t225
  br i1 %t226, label %bb64, label %bb65
bb63:
  call void @__olang_check_failed(ptr @olang_loc_30bb4d1d04b77ae4_b48bc1201be9b2a0)
  unreachable
bb64:
  %t228 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t229 = load ptr, ptr %t228, !tbaa !27
  %t230 = load i64, ptr %l110, !tbaa !24
  %t231 = getelementptr i8, ptr %t229, i64 5
  %t232 = sub i64 %t230, 5
  %t233 = insertvalue { i64, ptr } undef, i64 %t232, 0
  %t234 = insertvalue { i64, ptr } %t233, ptr %t231, 1
  %t236 = extractvalue { i64, ptr } %t234, 1
  %t237 = extractvalue { i64, ptr } %t234, 0
  %t238 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t237)
  call void @olang_textcopy(ptr %t238, ptr %t236, i64 %t237)
  %t239 = insertvalue { i64, ptr } undef, i64 %t237, 0
  %t240 = insertvalue { i64, ptr } %t239, ptr %t238, 1
  %t242 = extractvalue { i64, ptr } %t240, 0
  %t243 = extractvalue { i64, ptr } %t240, 1
  %t244 = mul i64 %t242, 1
  %t245 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t244)
  call void @llvm.memcpy.p0.p0.i64(ptr %t245, ptr %t243, i64 %t244, i1 false)
  %t246 = insertvalue { i64, ptr } undef, i64 %t242, 0
  %t247 = insertvalue { i64, ptr } %t246, ptr %t245, 1
  %t248 = load ptr, ptr %l106, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v3, ptr %v3, ptr %t248, { i64, ptr } %t247)
  br label %bb66
bb65:
  call void @__olang_check_failed(ptr @olang_loc_30bb4d1d04b77ae4_b48bc1201be9b2a0)
  unreachable
bb66:
  br label %bb102
bb67:
  %t250 = load i1, ptr %l119, !tbaa !21
  br i1 %t250, label %bb68, label %bb69
bb68:
  store i1 true, ptr %l120, !tbaa !21
  br label %bb71
bb69:
  %t251 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t253 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s2, ptr %s15, { i64, ptr } %t251, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d302, i32 0, i32 1) })
  store i1 %t253, ptr %l122
  br label %bb70
bb70:
  %t254 = load i1, ptr %l122, !tbaa !21
  store i1 %t254, ptr %l120, !tbaa !21
  br label %bb71
bb71:
  %t255 = load i1, ptr %l120, !tbaa !21
  br i1 %t255, label %bb72, label %bb73
bb72:
  store %olang.scope zeroinitializer, ptr %s16
  %t256 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t258 = extractvalue { i64, ptr } %t256, 0
  %t260 = icmp slt i64 %t258, 71
  br i1 %t260, label %bb74, label %bb75
bb73:
  br label %bb101
bb74:
  store i1 true, ptr %l126, !tbaa !21
  br label %bb76
bb75:
  %t262 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t262, ptr %l127, !tbaa !27
  %t263 = getelementptr { i64, ptr }, ptr %l127, i32 0, i32 1
  %t264 = load ptr, ptr %t263, !tbaa !27
  %t265 = getelementptr i8, ptr %t264, i64 69
  %t266 = load i8, ptr %t265, !tbaa !32
  %t268 = icmp ne i8 %t266, 32
  store i1 %t268, ptr %l126, !tbaa !21
  br label %bb76
bb76:
  %t270 = load i1, ptr %l126, !tbaa !21
  br i1 %t270, label %bb77, label %bb78
bb77:
  store i1 true, ptr %l130, !tbaa !21
  br label %bb81
bb78:
  %t271 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t271, ptr %l131, !tbaa !27
  %t272 = load ptr, ptr %lp12
  %t273 = getelementptr %"compiler/emit:Reused", ptr %t272, i32 0, i32 1
  %t275 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v3, ptr %t273)
  store i64 %t275, ptr %l133
  br label %bb79
bb79:
  %t276 = load { i64, ptr }, ptr %l131, !tbaa !27
  %t277 = extractvalue { i64, ptr } %t276, 1
  %t278 = extractvalue { i64, ptr } %t276, 0
  %t279 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d303, i32 0, i32 1) }, 1
  %t280 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d303, i32 0, i32 1) }, 0
  %t281 = add i64 %t278, %t280
  %t282 = load i64, ptr %l133, !tbaa !24
  %t283 = call i64 @__olang_fmt_i64(ptr null, i64 %t282)
  %t284 = add i64 %t281, %t283
  %t285 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d304, i32 0, i32 1) }, 1
  %t286 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d304, i32 0, i32 1) }, 0
  %t287 = add i64 %t284, %t286
  %t288 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t287)
  call void @olang_textcopy(ptr %t288, ptr %t277, i64 %t278)
  %t289 = getelementptr i8, ptr %t288, i64 %t278
  call void @olang_textcopy(ptr %t289, ptr %t279, i64 %t280)
  %t290 = getelementptr i8, ptr %t289, i64 %t280
  %t291 = call i64 @__olang_fmt_i64(ptr %t290, i64 %t282)
  %t292 = getelementptr i8, ptr %t290, i64 %t283
  call void @olang_textcopy(ptr %t292, ptr %t285, i64 %t286)
  %t293 = insertvalue { i64, ptr } undef, i64 %t287, 0
  %t294 = insertvalue { i64, ptr } %t293, ptr %t288, 1
  %t296 = extractvalue { i64, ptr } %t294, 0
  %t297 = extractvalue { i64, ptr } %t294, 1
  %t298 = mul i64 %t296, 1
  %t299 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t298)
  call void @llvm.memcpy.p0.p0.i64(ptr %t299, ptr %t297, i64 %t298, i1 false)
  %t300 = insertvalue { i64, ptr } undef, i64 %t296, 0
  %t301 = insertvalue { i64, ptr } %t300, ptr %t299, 1
  %t303 = call i1 @std_2fos_2eExists(ptr %s16, { i64, ptr } %t301)
  store i1 %t303, ptr %l136
  br label %bb80
bb80:
  %t304 = load i1, ptr %l136, !tbaa !21
  %t305 = xor i1 %t304, true
  store i1 %t305, ptr %l130, !tbaa !21
  br label %bb81
bb81:
  %t307 = load i1, ptr %l130, !tbaa !21
  br i1 %t307, label %bb82, label %bb83
bb82:
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s6)
  br label %bb107
bb83:
  br label %bb84
bb84:
  %t308 = load ptr, ptr %lp12
  %t309 = getelementptr %"compiler/emit:Reused", ptr %t308, i32 0, i32 3
  store ptr %t309, ptr %l138, !tbaa !29
  %t310 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t310, ptr %l139, !tbaa !27
  %t311 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t312 = extractvalue { i64, ptr } %t311, 0
  store i64 %t312, ptr %l140, !tbaa !24
  %t313 = icmp sge i64 5, 0
  br i1 %t313, label %bb85, label %bb86
bb85:
  %t315 = icmp sle i64 5, 69
  br i1 %t315, label %bb87, label %bb88
bb86:
  call void @__olang_check_failed(ptr @olang_loc_e09c8d310c475dd1_b9a5b78f48e38cfd)
  unreachable
bb87:
  %t317 = load i64, ptr %l140, !tbaa !24
  %t318 = icmp sle i64 69, %t317
  br i1 %t318, label %bb89, label %bb90
bb88:
  call void @__olang_check_failed(ptr @olang_loc_e09c8d310c475dd1_b9a5b78f48e38cfd)
  unreachable
bb89:
  %t320 = getelementptr { i64, ptr }, ptr %l139, i32 0, i32 1
  %t321 = load ptr, ptr %t320, !tbaa !27
  %t322 = getelementptr i8, ptr %t321, i64 5
  %t323 = sub i64 69, 5
  %t324 = insertvalue { i64, ptr } undef, i64 %t323, 0
  %t325 = insertvalue { i64, ptr } %t324, ptr %t322, 1
  %t327 = extractvalue { i64, ptr } %t325, 1
  %t328 = extractvalue { i64, ptr } %t325, 0
  %t329 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t328)
  call void @olang_textcopy(ptr %t329, ptr %t327, i64 %t328)
  %t330 = insertvalue { i64, ptr } undef, i64 %t328, 0
  %t331 = insertvalue { i64, ptr } %t330, ptr %t329, 1
  %t333 = extractvalue { i64, ptr } %t331, 0
  %t334 = extractvalue { i64, ptr } %t331, 1
  %t335 = mul i64 %t333, 1
  %t336 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t335)
  call void @llvm.memcpy.p0.p0.i64(ptr %t336, ptr %t334, i64 %t335, i1 false)
  %t337 = insertvalue { i64, ptr } undef, i64 %t333, 0
  %t338 = insertvalue { i64, ptr } %t337, ptr %t336, 1
  %t339 = load ptr, ptr %l138, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v3, ptr %v3, ptr %t339, { i64, ptr } %t338)
  br label %bb91
bb90:
  call void @__olang_check_failed(ptr @olang_loc_e09c8d310c475dd1_b9a5b78f48e38cfd)
  unreachable
bb91:
  %t341 = load ptr, ptr %lp12
  %t342 = getelementptr %"compiler/emit:Reused", ptr %t341, i32 0, i32 1
  store ptr %t342, ptr %l147, !tbaa !29
  %t343 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t343, ptr %l148, !tbaa !27
  %t344 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t347 = extractvalue { i64, ptr } %t344, 0
  store i64 %t347, ptr %l151, !tbaa !24
  %t348 = load { i64, ptr }, ptr %l148, !tbaa !27
  %t349 = extractvalue { i64, ptr } %t348, 0
  store i64 %t349, ptr %l152, !tbaa !24
  %t350 = icmp sge i64 70, 0
  br i1 %t350, label %bb92, label %bb93
bb92:
  %t352 = load i64, ptr %l151, !tbaa !24
  %t353 = icmp sle i64 70, %t352
  br i1 %t353, label %bb94, label %bb95
bb93:
  call void @__olang_check_failed(ptr @olang_loc_b7226a2473daafee_95f7e6f063520982)
  unreachable
bb94:
  %t355 = load i64, ptr %l151, !tbaa !24
  %t356 = load i64, ptr %l152, !tbaa !24
  %t357 = icmp sle i64 %t355, %t356
  br i1 %t357, label %bb96, label %bb97
bb95:
  call void @__olang_check_failed(ptr @olang_loc_b7226a2473daafee_95f7e6f063520982)
  unreachable
bb96:
  %t359 = getelementptr { i64, ptr }, ptr %l148, i32 0, i32 1
  %t360 = load ptr, ptr %t359, !tbaa !27
  %t361 = load i64, ptr %l151, !tbaa !24
  %t362 = getelementptr i8, ptr %t360, i64 70
  %t363 = sub i64 %t361, 70
  %t364 = insertvalue { i64, ptr } undef, i64 %t363, 0
  %t365 = insertvalue { i64, ptr } %t364, ptr %t362, 1
  %t367 = extractvalue { i64, ptr } %t365, 1
  %t368 = extractvalue { i64, ptr } %t365, 0
  %t369 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t368)
  call void @olang_textcopy(ptr %t369, ptr %t367, i64 %t368)
  %t370 = insertvalue { i64, ptr } undef, i64 %t368, 0
  %t371 = insertvalue { i64, ptr } %t370, ptr %t369, 1
  %t373 = extractvalue { i64, ptr } %t371, 0
  %t374 = extractvalue { i64, ptr } %t371, 1
  %t375 = mul i64 %t373, 1
  %t376 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t375)
  call void @llvm.memcpy.p0.p0.i64(ptr %t376, ptr %t374, i64 %t375, i1 false)
  %t377 = insertvalue { i64, ptr } undef, i64 %t373, 0
  %t378 = insertvalue { i64, ptr } %t377, ptr %t376, 1
  %t379 = load ptr, ptr %l147, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v3, ptr %v3, ptr %t379, { i64, ptr } %t378)
  br label %bb98
bb97:
  call void @__olang_check_failed(ptr @olang_loc_b7226a2473daafee_95f7e6f063520982)
  unreachable
bb98:
  %t381 = load ptr, ptr %lp12
  %t382 = getelementptr %"compiler/emit:Reused", ptr %t381, i32 0, i32 2
  store ptr %t382, ptr %l159, !tbaa !29
  %t383 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t385 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s2, ptr %s16, { i64, ptr } %t383, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d305, i32 0, i32 1) })
  store i1 %t385, ptr %l161
  br label %bb99
bb99:
  %t386 = load ptr, ptr %l159, !tbaa !29
  %t387 = load i1, ptr %l161, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v3, ptr %t386, i1 %t387)
  br label %bb100
bb100:
  call void @__olang_scope_close(ptr %s16)
  br label %bb101
bb101:
  call void @__olang_scope_close(ptr %s15)
  br label %bb102
bb102:
  call void @__olang_scope_close(ptr %s12)
  br label %bb103
bb103:
  call void @__olang_scope_close(ptr %s10)
  br label %bb104
bb104:
  call void @__olang_scope_close(ptr %s8)
  br label %bb105
bb105:
  call void @__olang_scope_close(ptr %s6)
  br label %bb106
bb106:
  br label %bb24
bb107:
  %t388 = load i1, ptr %l13, !tbaa !21
  br i1 %t388, label %bb108, label %bb109
bb108:
  %t390 = load ptr, ptr %lp12
  %t391 = getelementptr %"compiler/emit:Reused", ptr %t390, i32 0, i32 1
  %t393 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v3, ptr %t391)
  store i64 %t393, ptr %l165
  br label %bb110
bb109:
  store i1 false, ptr %l163, !tbaa !21
  br label %bb111
bb110:
  %t394 = load i64, ptr %l165, !tbaa !24
  %t395 = icmp sgt i64 %t394, 0
  store i1 %t395, ptr %l163, !tbaa !21
  br label %bb111
bb111:
  %t397 = load i1, ptr %l163, !tbaa !21
  br i1 %t397, label %bb112, label %bb113
bb112:
  %t398 = load ptr, ptr %lp3
  %t399 = load ptr, ptr %lp12
  %t400 = load %"compiler/emit:Reused", ptr %t399
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2femit_3aReused_3e_2ePush_3ccompiler_2femit_3aReused_3e(ptr %v3, ptr %v3, ptr %t398, %"compiler/emit:Reused" %t400)
  br label %bb114
bb113:
  br label %bb115
bb114:
  br label %bb115
bb115:
  call void @__olang_scope_close(ptr %s2)
  br label %bb116
bb116:
  %t403 = load i64, ptr %l8, !tbaa !24
  %t405 = add i64 %t403, 1
  store i64 %t405, ptr %l8, !tbaa !24
  br label %bb8
bb117:
  %t407 = load ptr, ptr %lp3
  %t408 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t407
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t408, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local i1 @compiler_2folang_2eroomFor(i64 %a0) #0 {
entry:
  %l1 = alloca %"<sys/resource.h>:rlimit"
  %l2 = alloca %"<sys/resource.h>:rlimit"
  %l5 = alloca i32
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"<sys/resource.h>:rlimit" @olang_2eHelperKind_2eZero_2e_3csys_2fresource_2eh_3e_3arlimit()
  store %"<sys/resource.h>:rlimit" %t1, ptr %l2
  br label %bb1
bb1:
  %t2 = load %"<sys/resource.h>:rlimit", ptr %l2
  store %"<sys/resource.h>:rlimit" %t2, ptr %l1
  %t3 = load i32, ptr @G_2e_3csys_2fresource_2eh_3e_2eRLIMIT__AS, !tbaa !23
  %t6 = call i32 @getrlimit(i32 %t3, ptr %l1)
  store i32 %t6, ptr %l5
  br label %bb2
bb2:
  %t7 = load i32, ptr %l5, !tbaa !23
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb3, label %bb4
bb3:
  store i1 true, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t11 = getelementptr %"<sys/resource.h>:rlimit", ptr %l1, i32 0, i32 0
  %t12 = load i64, ptr %t11, !tbaa !65
  %t17 = icmp ugt i64 %t12, %a0
  store i1 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2folang_2esaid(ptr %v0, ptr %a0) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l4 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v0, ptr %s0, ptr %a0)
  store { i64, ptr } %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t4, 0
  %t6 = extractvalue { i64, ptr } %t4, 1
  %t7 = mul i64 %t5, 1
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @llvm.memcpy.p0.p0.i64(ptr %t8, ptr %t6, i64 %t7, i1 false)
  %t9 = insertvalue { i64, ptr } undef, i64 %t5, 0
  %t10 = insertvalue { i64, ptr } %t9, ptr %t8, 1
  %t12 = call i32 @compiler_2folang_2ewrite(ptr %s0, { i64, ptr } %t10)
  store i32 %t12, ptr %l4
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2folang_2eusage(ptr %v0, ptr %v1, ptr %a0, %"compiler/msgs:Msg" %a1) #0 {
entry:
  %l5 = alloca i64
  %rv = alloca i32
  %t2 = alloca { i64, [3 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  store { i64, [3 x i64] } zeroinitializer, ptr %t2
  %t3 = getelementptr { i64, [3 x i64] }, ptr %t2, i32 0, i32 0
  store i64 0, ptr %t3
  %t4 = load { i64, [3 x i64] }, ptr %t2
  %t9 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %t4, %"compiler/msgs:Msg" %a1)
  store i64 %t9, ptr %l5
  br label %bb1
bb1:
  store i32 65536, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2folang_2ewrite(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l2 = alloca i32
  %l4 = alloca i1
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i32 @std_2fio_2ePrint(ptr %v0, { i64, ptr } %a0)
  store i32 %t3, ptr %l2
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  br label %bb1
bb1:
  br label %bb4
bb2:
  %t6 = load i32, ptr %l2, !tbaa !23
  %t7 = ashr i32 %t6, 16
  %t9 = icmp eq i32 %t7, 1
  store i1 %t9, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store i32 1, ptr %rv
  br label %ret
bb4:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"compiler/olang:CommandLine" @compiler_2folang_3aCommandLine_2ector(ptr %v0) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l2 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l13 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/olang:CommandLine"
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l0, !tbaa !24
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l1
  %t3 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l12
  br label %bb2
bb2:
  %t4 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l12
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %l2
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d306, i32 0, i32 1) }, ptr %l3, !tbaa !27
  store i1 false, ptr %l4, !tbaa !21
  %t5 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, ptr %l13
  br label %bb3
bb3:
  %t6 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t6, ptr %l5
  %t7 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t7, ptr %l14
  br label %bb4
bb4:
  %t8 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l14
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d307, i32 0, i32 1) }, ptr %l7, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d308, i32 0, i32 1) }, ptr %l8, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d309, i32 0, i32 1) }, ptr %l10, !tbaa !27
  %t9 = load i64, ptr %l0, !tbaa !24
  %t10 = insertvalue %"compiler/olang:CommandLine" undef, i64 %t9, 0
  %t11 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l1
  %t12 = insertvalue %"compiler/olang:CommandLine" %t10, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t11, 1
  %t13 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l2
  %t14 = insertvalue %"compiler/olang:CommandLine" %t12, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, 2
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t16 = insertvalue %"compiler/olang:CommandLine" %t14, { i64, ptr } %t15, 3
  %t17 = load i1, ptr %l4, !tbaa !21
  %t18 = insertvalue %"compiler/olang:CommandLine" %t16, i1 %t17, 4
  %t19 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l5
  %t20 = insertvalue %"compiler/olang:CommandLine" %t18, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t19, 5
  %t22 = insertvalue %"compiler/olang:CommandLine" %t20, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, 6
  %t23 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t24 = insertvalue %"compiler/olang:CommandLine" %t22, { i64, ptr } %t23, 7
  %t25 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t26 = insertvalue %"compiler/olang:CommandLine" %t24, { i64, ptr } %t25, 8
  %t28 = insertvalue %"compiler/olang:CommandLine" %t26, i1 false, 9
  %t29 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t30 = insertvalue %"compiler/olang:CommandLine" %t28, { i64, ptr } %t29, 10
  store %"compiler/olang:CommandLine" %t30, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/olang:CommandLine", ptr %rv
  ret %"compiler/olang:CommandLine" %rr
}

define dso_local %"compiler/olang:Passes" @compiler_2folang_3aPasses_2ector(ptr %v0) #0 {
entry:
  %rv = alloca %"compiler/olang:Passes"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = insertvalue %"compiler/olang:Passes" undef, i64 0, 0
  store %"compiler/olang:Passes" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/olang:Passes", ptr %rv
  ret %"compiler/olang:Passes" %rr
}

define i32 @main(i32 %argc, ptr %argv) #0 {
entry:
  store i32 %argc, ptr @__olang_argc
  store ptr %argv, ptr @__olang_argv
  call void @__olang_thread_init()
  call void @std_2ffilepath_2elivePath_2einit()
  call void @compiler_2fbuild_2ePhaseAt_2einit()
  call void @compiler_2folang_2emain()
  ret i32 0
}

define dso_local void @olang_2einit_2ecompiler_2folang() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2folang_2eModeWords_2einit()
  br label %bb1
bb1:
  call void @compiler_2folang_2eRun_2einit()
  br label %bb2
bb2:
  call void @compiler_2folang_2eBuild_2einit()
  br label %bb3
bb3:
  call void @compiler_2folang_2eCompile_2einit()
  br label %bb4
bb4:
  call void @compiler_2folang_2eTest_2einit()
  br label %bb5
bb5:
  call void @compiler_2folang_2eInterp_2einit()
  br label %bb6
bb6:
  call void @compiler_2folang_2eFormat_2einit()
  br label %bb7
bb7:
  call void @compiler_2folang_2eExplain_2einit()
  br label %bb8
bb8:
  call void @compiler_2folang_2eHelp_2einit()
  br label %bb9
bb9:
  call void @compiler_2folang_2eDoc_2einit()
  br label %bb10
bb10:
  call void @compiler_2folang_2eLsp_2einit()
  br label %bb11
bb11:
  call void @compiler_2folang_2eMcp_2einit()
  br label %bb12
bb12:
  call void @compiler_2folang_2eFix_2einit()
  br label %bb13
bb13:
  call void @compiler_2folang_2eBindgen_2einit()
  br label %bb14
bb14:
  call void @compiler_2folang_2eModeUsage_2einit()
  br label %bb15
bb15:
  call void @compiler_2folang_2eModeWhat_2einit()
  br label %bb16
bb16:
  call void @compiler_2folang_2eOptWords_2einit()
  br label %bb17
bb17:
  call void @compiler_2folang_2eOptValues_2einit()
  br label %bb18
bb18:
  call void @compiler_2folang_2eOptModes_2einit()
  br label %bb19
bb19:
  call void @compiler_2folang_2eOptWhat_2einit()
  br label %bb20
bb20:
  call void @compiler_2folang_2eexplainedSrc_2einit()
  br label %bb21
bb21:
  br label %ret
ret:
  ret void
}

@.d0 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c"olang [OPTION...] FILE.olang [ARGUMENT...]" }>, align 8
@.d1 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c"olang build [OPTION...] FILE.olang" }>, align 8
@.d2 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"olang compile [OPTION...] FILE.olang" }>, align 8
@.d3 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"olang test [OPTION...] FILE.olang..." }>, align 8
@.d4 = private constant <{ i64, [52 x i8] }> <{ i64 0, [52 x i8] c"olang interpret [OPTION...] FILE.olang [ARGUMENT...]" }>, align 8
@.d5 = private constant <{ i64, [38 x i8] }> <{ i64 0, [38 x i8] c"olang format [OPTION...] FILE.olang..." }>, align 8
@.d6 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"olang explain RULE | FILE.olang NAME" }>, align 8
@.d7 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"olang help [MODE]" }>, align 8
@.d8 = private constant <{ i64, [67 x i8] }> <{ i64 0, [67 x i8] c"olang doc [OPTION...] FILE.olang [NAME] | -html DIR [FILE.olang...]" }>, align 8
@.d9 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"olang lsp [OPTION...]" }>, align 8
@.d10 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"olang mcp [OPTION...]" }>, align 8
@.d11 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c"olang fix [OPTION...] FILE.olang|DIR..." }>, align 8
@.d12 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c"olang bindgen [OPTION...] HEADER.h" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d13 = private constant <{ i64, [106 x i8] }> <{ i64 0, [106 x i8] c"builds the program FILE.olang is the root of, as build does, and runs it with the arguments after the file" }>, align 8
@.d14 = private constant <{ i64, [64 x i8] }> <{ i64 0, [64 x i8] c"builds one program, FILE.olang its root module, into build/ (B3)" }>, align 8
@.d15 = private constant <{ i64, [54 x i8] }> <{ i64 0, [54 x i8] c"compiles one module to an object, linking nothing (B2)" }>, align 8
@.d16 = private constant <{ i64, [62 x i8] }> <{ i64 0, [62 x i8] c"runs each file's test blocks, each file built on its own (B3a)" }>, align 8
@.d17 = private constant <{ i64, [110 x i8] }> <{ i64 0, [110 x i8] c"runs the program by compile-time evaluation instead of building it, the arguments after the file its own (B3e)" }>, align 8
@.d18 = private constant <{ i64, [46 x i8] }> <{ i64 0, [46 x i8] c"rewrites each file in olang's one layout (B13)" }>, align 8
@.d19 = private constant <{ i64, [93 x i8] }> <{ i64 0, [93 x i8] c"prints a rule of the specification (B11a), or a top-level item as the compiler sees it (B11b)" }>, align 8
@.d20 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"lists the modes, or a mode's options" }>, align 8
@.d21 = private constant <{ i64, [68 x i8] }> <{ i64 0, [68 x i8] c"prints a module's documentation (B14), or writes a library's as HTML" }>, align 8
@.d22 = private constant <{ i64, [87 x i8] }> <{ i64 0, [87 x i8] c"serves the Language Server Protocol on the standard input and output, for editors (B15)" }>, align 8
@.d23 = private constant <{ i64, [84 x i8] }> <{ i64 0, [84 x i8] c"serves the Model Context Protocol on the standard input and output, for agents (B16)" }>, align 8
@.d24 = private constant <{ i64, [116 x i8] }> <{ i64 0, [116 x i8] c"rewrites old code to the language of today: every migration tool of tools/, in the order the changes were made (B17)" }>, align 8
@.d25 = private constant <{ i64, [76 x i8] }> <{ i64 0, [76 x i8] c"writes a C header's declarations as olang declares them, read by clang (X16)" }>, align 8
@.d26 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d27 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"build" }>, align 8
@.d28 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"compile" }>, align 8
@.d29 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"test" }>, align 8
@.d30 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"interpret" }>, align 8
@.d31 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"format" }>, align 8
@.d32 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"explain" }>, align 8
@.d33 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"help" }>, align 8
@.d34 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"doc" }>, align 8
@.d35 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"lsp" }>, align 8
@.d36 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"mcp" }>, align 8
@.d37 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fix" }>, align 8
@.d38 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"bindgen" }>, align 8
@.d39 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"PATH" }>, align 8
@.d40 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d41 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d42 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d43 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"NAME" }>, align 8
@.d44 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"Name=value" }>, align 8
@.d45 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d46 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d47 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d48 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"DIR" }>, align 8
@.d49 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d50 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d51 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"NAME" }>, align 8
@.d52 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"SECONDS" }>, align 8
@.d53 = private constant <{ i64, [78 x i8] }> <{ i64 0, [78 x i8] c"writes the executable, the object or bindgen's declarations to PATH (B3h, X16)" }>, align 8
@.d54 = private constant <{ i64, [53 x i8] }> <{ i64 0, [53 x i8] c"builds unoptimized, with debug information (B2c, B2e)" }>, align 8
@.d55 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"builds with the data race detector (B2b)" }>, align 8
@.d56 = private constant <{ i64, [37 x i8] }> <{ i64 0, [37 x i8] c"builds with the scope sanitizer (B2f)" }>, align 8
@.d57 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"builds for another machine (B12)" }>, align 8
@.d58 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"defines a build constant (B10)" }>, align 8
@.d59 = private constant <{ i64, [85 x i8] }> <{ i64 0, [85 x i8] c"moves the remote repositories the build reaches to their refs' current commits (M23c)" }>, align 8
@.d60 = private constant <{ i64, [89 x i8] }> <{ i64 0, [89 x i8] c"rewrites nothing: lists each file not in the layout (B13), or that fix would change (B17)" }>, align 8
@.d61 = private constant <{ i64, [96 x i8] }> <{ i64 0, [96 x i8] c"builds for development: -O2 without link-time optimization, faster to build, slower to run (B2g)" }>, align 8
@.d62 = private constant <{ i64, [109 x i8] }> <{ i64 0, [109 x i8] c"writes the documentation as HTML into DIR, a page a module: of each FILE, or of std where none is named (B14)" }>, align 8
@.d63 = private constant <{ i64, [83 x i8] }> <{ i64 0, [83 x i8] c"builds a shared library libNAME.so of the export fns, and its C header NAME.h (X14)" }>, align 8
@.d64 = private constant <{ i64, [88 x i8] }> <{ i64 0, [88 x i8] c"reports the places that keep what they let go of until their scope closes, and why (B18)" }>, align 8
@.d65 = private constant <{ i64, [110 x i8] }> <{ i64 0, [110 x i8] c"fuzzes the one test NAME names (as test's words do) with libFuzzer, failing inputs saved beside the file (B19)" }>, align 8
@.d66 = private constant <{ i64, [45 x i8] }> <{ i64 0, [45 x i8] c"with -fuzz: stops fuzzing after SECONDS (B19)" }>, align 8
@.d67 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"-output" }>, align 8
@.d68 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"-debug" }>, align 8
@.d69 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"-race" }>, align 8
@.d70 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"-sanitize" }>, align 8
@.d71 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"-target" }>, align 8
@.d72 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"-define" }>, align 8
@.d73 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"-update" }>, align 8
@.d74 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"-check" }>, align 8
@.d75 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"-quick" }>, align 8
@.d76 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"-html" }>, align 8
@.d77 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"-library" }>, align 8
@.d78 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"-memory" }>, align 8
@.d79 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"-fuzz" }>, align 8
@.d80 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"-fuzztime" }>, align 8
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d81 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"-" }>, align 8
@.d82 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"-" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d83 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d84 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @__olang_ert_req_clear()
@.d85 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"-debug" }>, align 8
@.d86 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"-race" }>, align 8
@.d87 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d88 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d89 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d90 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d91 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"fuzzing" }>, align 8
@.d92 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d93 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"OLANG_OBJECTS" }>, align 8
@.d94 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d95 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d96 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"/proc/self/exe" }>, align 8
@.d97 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d98 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d99 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d100 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d101 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.c102 = private unnamed_addr constant [5 x i8] c"true\00"
@.c103 = private unnamed_addr constant [6 x i8] c"false\00"
@.d104 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"TargetOs" }>, align 8
@.d105 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"TargetArch" }>, align 8
@.d106 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"TargetCpu" }>, align 8
@.d107 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"TargetVectorBits" }>, align 8
@.d108 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"TargetHasFma" }>, align 8
@.d109 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"DebugBuild" }>, align 8
@.d110 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"RaceBuild" }>, align 8
@.d111 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"TestBuild" }>, align 8
@.d112 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-g" }>, align 8
@.d113 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"-fsanitize=thread" }>, align 8
@.d114 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"-O2" }>, align 8
@.d115 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"-Xclang" }>, align 8
@.d116 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"-disable-llvm-passes" }>, align 8
@.d117 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-w" }>, align 8
@.d118 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-x" }>, align 8
@.d119 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"c" }>, align 8
@.d120 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-S" }>, align 8
@.d121 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"-emit-llvm" }>, align 8
@.d122 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-o" }>, align 8
@.d123 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"-" }>, align 8
@.d124 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"-" }>, align 8
@.d125 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
declare void @__olang_check_failed(ptr)
@.d126 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d127 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c".ll" }>, align 8
@.d128 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d129 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d130 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d131 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d132 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d133 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d134 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d135 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d136 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c".tmp" }>, align 8
@.d137 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c".so" }>, align 8
@.d138 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"its code is lost" }>, align 8
@.d139 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d140 = private constant <{ i64, [44 x i8] }> <{ i64 0, [44 x i8] c"a C import's code needs clang to be compiled" }>, align 8
@.d141 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c".tmp" }>, align 8
@.d142 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"-shared" }>, align 8
@.d143 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"-fPIC" }>, align 8
@.d144 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"-O2" }>, align 8
@.d145 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-w" }>, align 8
@.d146 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-x" }>, align 8
@.d147 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"c" }>, align 8
@.d148 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-o" }>, align 8
@.d149 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d150 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"clang could not be run" }>, align 8
@.d151 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c"clang could not compile it: " }>, align 8
@.d152 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c".tmp" }>, align 8
@.d153 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"its library cannot be written" }>, align 8
@.d154 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d155 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"olang: reuse check: " }>, align 8
@.d156 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" differs\0A" }>, align 8
@.d157 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"olang: reuse check: " }>, align 8
@.d158 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" objects, " }>, align 8
@.d159 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c" written afresh\0A" }>, align 8
@.d160 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"olang: reuse check: " }>, align 8
@.d161 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c" modules reused, every object the same\0A" }>, align 8
@.d162 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"start" }>, align 8
@.d163 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"load" }>, align 8
@.d164 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"check" }>, align 8
@.d165 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"evaluate" }>, align 8
@.d166 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c": it does not check " }>, align 8
@.d167 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" yet" }>, align 8
@.d168 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"scope" }>, align 8
@.d169 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"OLANG_FREEDUMP" }>, align 8
@.d170 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d171 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d172 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"lower+emit" }>, align 8
@.d173 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d174 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"it does not emit " }>, align 8
@.d175 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" yet" }>, align 8
@.d176 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c": it does not lower " }>, align 8
@.d177 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" yet" }>, align 8
@.d178 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".p" }>, align 8
@.d179 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c".ll" }>, align 8
@.d180 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"its record " }>, align 8
@.d181 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c" was lost while it was read" }>, align 8
@.d182 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"@__olang_dyncall" }>, align 8
@.d183 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d184 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"@__olang_dyncall" }>, align 8
@.d185 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d186 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"its C import's code " }>, align 8
@.d187 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c" was lost while it was read" }>, align 8
@.d188 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d189 = private constant <{ i64, [41 x i8] }> <{ i64 0, [41 x i8] c"clang cannot compile its C import's code " }>, align 8
@.d190 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"c_" }>, align 8
@.d191 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"OLANG_CHECKREUSE" }>, align 8
@.d192 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d193 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define available_externally void @__olang_scope_escape(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %un = icmp eq ptr %o, null
  br i1 %un, label %claim, label %done
claim:
  %me = load ptr, ptr @__olang_self
  store atomic ptr %me, ptr %op monotonic, align 8
  br label %done
done:
  ret void
}
define internal { i64, ptr } @olang_lambda_194(ptr %env, ptr %v0, i64 %a0) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  %cp0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  %vq0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eInstNote(ptr %vc0, ptr %v0, ptr %cv0, i64 %a0)
  store { i64, ptr } %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t6, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define internal { i64, ptr } @olang_lambda_195(ptr %env, ptr %v0, i32 %a0) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  %cp0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  %vq0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %vc0, ptr %v0, ptr %cv0, i32 %a0)
  store { i64, ptr } %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t6, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

@.d196 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d197 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-l" }>, align 8
@.d198 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d199 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d200 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @abort() noreturn
@.d201 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"sanitize_thread " }>, align 8
@.d202 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d203 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"/fuzz" }>, align 8
@.d204 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
@.d205 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"type MathError error { ZERO }\0A" }>, align 8
@.d206 = private constant <{ i64, [43 x i8] }> <{ i64 0, [43 x i8] c"type N struct(v I64, next N?&) { v, next }\0A" }>, align 8
@.d207 = private constant <{ i64, [37 x i8] }> <{ i64 0, [37 x i8] c"fn (n N&) Value() I64 { return n.v }\0A" }>, align 8
@.d208 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"type H struct(n N&) { n }\0A" }>, align 8
@.d209 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"fn wrap(n N&) H { return H(n) }\0A" }>, align 8
@.d210 = private constant <{ i64, [37 x i8] }> <{ i64 0, [37 x i8] c"fn divmod(a I64, b I64) I64, I64 ? {\0A" }>, align 8
@.d211 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c"    if b == 0 { error MathError.ZERO }\0A" }>, align 8
@.d212 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"    return a / b, a % b\0A" }>, align 8
@.d213 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"}\0A" }>, align 8
@.d214 = private constant <{ i64, [51 x i8] }> <{ i64 0, [51 x i8] c"fn big<T>(a T, b T) T { return a if a > b else b }\0A" }>, align 8
@.d215 = private constant <{ i64, [62 x i8] }> <{ i64 0, [62 x i8] c"type Sh enum {\0A    Whole N\0A    Parts(a I64, b I64)\0A    None\0A}\0A" }>, align 8
@.d216 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"Answer I64 = 6 * 7\0A" }>, align 8
@.d217 = private constant <{ i64, [85 x i8] }> <{ i64 0, [85 x i8] c"fn pct(part I64, whole I64) [whole > 0, part >= 0] I64 { return part * 100 / whole }\0A" }>, align 8
@.d218 = private constant <{ i64, [43 x i8] }> <{ i64 0, [43 x i8] c"fn link(a mut N&, b N&) [b outlives a] { }\0A" }>, align 8
@.d219 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"fn main() ? {\0A" }>, align 8
@.d220 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"    nn := N(pct(1, 4)!, null)\0A" }>, align 8
@.d221 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"    link(nn, nn)\0A" }>, align 8
@.d222 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c"    q, _ := try divmod(Answer, big(2, 3))\0A" }>, align 8
@.d223 = private constant <{ i64, [44 x i8] }> <{ i64 0, [44 x i8] c"    assert wrap(N(q, null)).n.Value() == 14\0A" }>, align 8
@.d224 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-l" }>, align 8
@.d225 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-f" }>, align 8
@.d226 = private constant <{ i64, [96 x i8] }> <{ i64 0, [96 x i8] c"usage: olang MODE [OPTION...] FILE...   or   olang [OPTION...] FILE.olang [ARGUMENT...]\0A\0Amodes:\0A" }>, align 8
@.d227 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"FILE.olang" }>, align 8
@.d228 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d229 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d230 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d231 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d232 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d233 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d234 = private constant <{ i64, [85 x i8] }> <{ i64 0, [85 x i8] c"\0A'olang help MODE' lists a mode's options; 'olang help run' those of running a file.\0A" }>, align 8
@.d235 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"run" }>, align 8
@.d236 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"usage: " }>, align 8
@.d237 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d238 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"\0Aoptions:\0A" }>, align 8
@.d239 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d240 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d241 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d242 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d243 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d244 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d245 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"/rec" }>, align 8
@.d246 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d247 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"1" }>, align 8
@.d248 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"0" }>, align 8
@.d249 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"olang module record\0Asize " }>, align 8
@.d250 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"\0Asplit " }>, align 8
@.d251 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d252 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"inst " }>, align 8
@.d253 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d254 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".p" }>, align 8
@.d255 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c".ll" }>, align 8
@.d256 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"locs " }>, align 8
@.d257 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"part " }>, align 8
@.d258 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d259 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d260 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"end\0A" }>, align 8
@.d261 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"thread_local(initialexec)" }>, align 8
@.d262 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"thread_local" }>, align 8
@.d263 = private constant <{ i64, [97 x i8] }> <{ i64 0, [97 x i8] c"olang: internal compiler error: the compiler crashed - a bug in the compiler, not in the program\0A" }>, align 8
define internal void @olang_lambda_264(ptr %env) #0 {
entry:
  %l2 = alloca i32
  %cp0 = getelementptr { { i64, ptr }, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load { i64, ptr }, ptr %cp0, !tbaa !28
  %vq0 = getelementptr { { i64, ptr }, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i32 @compiler_2folang_2edrive(ptr %vc0, { i64, ptr } %cv0)
  store i32 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i32, ptr %l2, !tbaa !23
  call void @std_2fos_2eExit(i32 %t4)
  unreachable
bb2:
  call void @__olang_check_failed(ptr @olang_loc_6a9437d164e18f65_777063661d50beb9)
  unreachable
ret:
  ret void
}

@.d265 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"running a file" }>, align 8
@.d266 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" and " }>, align 8
@.d267 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d268 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d269 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d270 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d271 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"\0Aroot " }>, align 8
@.d272 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d273 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d274 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d275 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"embed " }>, align 8
@.d276 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
define internal i1 @olang_lambda_277(ptr %env, i64 %a0, i64 %a1) #0 {
entry:
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = icmp slt i64 %a0, %a1
  store i1 %t5, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d278 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
define internal { i64, ptr } @olang_lambda_279(ptr %env, ptr %v0, i64 %a0) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  %cp0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  %vq0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eInstNote(ptr %vc0, ptr %v0, ptr %cv0, i64 %a0)
  store { i64, ptr } %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t6, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define internal { i64, ptr } @olang_lambda_280(ptr %env, ptr %v0, i32 %a0) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  %cp0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  %vq0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %vc0, ptr %v0, ptr %cv0, i32 %a0)
  store { i64, ptr } %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t6, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

@.d281 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"OLANG_FREEDUMP" }>, align 8
@.d282 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d283 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d284 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d285 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c".tmp" }>, align 8
@.d286 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"/rec/" }>, align 8
@.d287 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d288 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"attributes #" }>, align 8
@.d289 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"\22target-cpu\22" }>, align 8
@.d290 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"\22target-cpu\22=\22" }>, align 8
@.d291 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"\22target-features\22=\22" }>, align 8
@.d292 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"\22tune-cpu\22=\22" }>, align 8
@.d293 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
@.d294 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d295 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d296 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"end" }>, align 8
@.d297 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"size " }>, align 8
@.d298 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"split " }>, align 8
@.d299 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"inst " }>, align 8
@.d300 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"1" }>, align 8
@.d301 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"part " }>, align 8
@.d302 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"locs " }>, align 8
@.d303 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".p" }>, align 8
@.d304 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c".ll" }>, align 8
@.d305 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"locs " }>, align 8
define linkonce_odr %"<sys/resource.h>:rlimit" @olang_2eHelperKind_2eZero_2e_3csys_2fresource_2eh_3e_3arlimit() #0 {
entry:
  %l0 = alloca %"<sys/resource.h>:rlimit"
  %rv = alloca %"<sys/resource.h>:rlimit"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"<sys/resource.h>:rlimit" @_3csys_2fresource_2eh_3e_3arlimit_2ector(ptr %t1)
  store %"<sys/resource.h>:rlimit" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"<sys/resource.h>:rlimit", ptr %l0
  store %"<sys/resource.h>:rlimit" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"<sys/resource.h>:rlimit", ptr %rv
  ret %"<sys/resource.h>:rlimit" %rr
}

declare i32 @getrlimit(i32, ptr)
@.d306 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d307 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"native" }>, align 8
@.d308 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d309 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@__olang_argc = external global i32
@__olang_argv = external global ptr
declare void @__olang_thread_init()
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@__olang_self = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
declare ptr @__olang_scope_mine_slow(ptr) noinline
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eUsage(ptr %v0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotAMode(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Nearest" @compiler_2fmsgs_3aNearest_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eOffer(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eHint(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownFlag(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eOptionNotForMode(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eOptionNeedsValue(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eDefine(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, ptr %a2)
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eFuzzTimeNotNumber(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eQuickAlone(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDocOneName(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eExplainNeedsRule(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eHelpOneMode(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eModeFirst(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotASource(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fos_2eExists(ptr %v0, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eExplainNeedsName(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eModeNoFiles(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eModeOneFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eModeNeedsFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eFuzzTimeAlone(ptr %v0)
declare { i64, ptr } @compiler_2ftarget_2eFindClang(ptr %v0)
declare { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, %"compiler/target:Target" } @compiler_2ftarget_2eResolve(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, ptr %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetForeignMode(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, %"std/os:FileInfo" } @std_2fos_2eStat(ptr %v0, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fos_2eCwd(ptr %v0)
declare { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eFingerprint(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2fload_2eStdDir(ptr %v0)
declare i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eHas(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefineBuiltin(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eBuiltins(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, i64 %a4, i64 %a5, i1 %a6, i1 %a7, i1 %a8)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eCFlags(ptr %v0, ptr %v1, ptr %a0)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_57b10a8a18d2546b_cbe9beb9d768873f = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @std_2fsha256_2eHex(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3)
declare i32 @std_2fio_2ePrintErr(ptr %v0, { i64, ptr } %a0)
declare i32 @compiler_2fbuild_2ePid()
declare i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @std_2fos_2eRename(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_7f1024592ae32589_c3207624e3c1a39d = external constant [0 x i8]
declare %"std/os:FileInfo" @std_2fos_3aFileInfo_2ector(ptr %v0, i32 %a0, i64 %a1, i64 %a2)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2finterp_2eLoadLibrary(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fos_2eIsDir(ptr %v0, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eOutputIsDir(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_12131eae1fe55f7a_2d06b34e1c9e748e = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eOutputNoDir(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eLen_3cI64_2c_20I64_3e(ptr %v0, ptr %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2ecompiler_2femit_3aEmitter_2eObjects(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2femit_3aObject_3e_2eLen_3ccompiler_2femit_3aObject_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2eLen_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %a0)
declare %"compiler/build:Unit" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2eAt_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/emit:Object" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2femit_3aObject_3e_2eAt_3ccompiler_2femit_3aObject_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fos_2eExit(i32 %a0)
@olang_loc_dd8573ae343ff812_8decdc106ea08ebe = external constant [0 x i8]
declare void @compiler_2fbuild_2ePhase(ptr %v0, { i64, ptr } %a0)
declare void @compiler_2finterp_2eAnalyze(ptr %out, ptr %v0, ptr %v1, ptr %a0, i1 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eCheckMain(ptr %v0, ptr %a0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v0, ptr %a0)
declare i64 @compiler_2finterp_2eDecideValues(ptr %v0, ptr %a0)
declare i64 @compiler_2finterp_2eDecideAsserts(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2finterp_2eBake(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHasFatal(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aGap_3e_2eLen_3ccompiler_2fcheck_3aGap_3e(ptr %v0, ptr %a0)
declare %"compiler/check:Gap" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aGap_3e_2eAt_3ccompiler_2fcheck_3aGap_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2)
declare void @compiler_2fbuild_2eUnbuildable(ptr %v0, { i64, ptr } %a0)
declare %"compiler/lower:Lowerer" @compiler_2flower_3aLowerer_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %a1)
declare { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2eReport(ptr %v0, ptr %v1, ptr %a0)
declare i32 @std_2fio_2ePrint(ptr %v0, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2eDump(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_1d5612d13136b02e_cf27d9d671de6fa2 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eFuzzNoTest(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eFuzzManyTests(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aGap_3e_2eLen_3ccompiler_2flower_3aGap_3e(ptr %v0, ptr %a0)
declare %"compiler/lower:Gap" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aGap_3e_2eAt_3ccompiler_2flower_3aGap_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/emit:Reused" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2femit_3aReused_3e_2eAt_3ccompiler_2femit_3aReused_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/build:Unit" @compiler_2fbuild_3aUnit_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, i32 %a1, { i64, ptr } %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2ePush_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/build:Unit" %a1)
@olang_loc_5772a8514d833044_b816e84cde98ab20 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fbuild_2eIrHash(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fload_2ecompiler_2fload_3aLoader_2eLinks(ptr %v0, ptr %v1, ptr %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2ecompiler_2femit_3aEmitter_2eExportNames(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2fbuild_2eLibName(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eHeader(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare { i32, { i64, ptr } } @compiler_2fruntime_2eIr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3, i1 %a4)
declare { i32, { i64, ptr } } @compiler_2fruntime_2eDyncallIr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3, i1 %a4)
declare void @compiler_2fscope_3aScoper_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eRun(ptr %v0, ptr %a0)
declare void @compiler_2finterp_3aExec_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %a1, i32 %a2)
declare { i32, { i64, ptr } } @compiler_2fexplain_2eItem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, i64 %a3, { i64, ptr } %a4)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eExplainNoItem(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_436dc8a09a076c49_2aa9a29c41caf045 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eInterpLink(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@G_2ecompiler_2feval_2eInterpCrash = external constant <{ [8 x i8], ptr }>
declare void @std_2fos_2eOnCrash(ptr %v0, { i64, ptr } %a0)
declare i32 @compiler_2finterp_2ecompiler_2finterp_3aExec_2eRunMain(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_d9ce39c2cb08642b_edb226294df0b2a7 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fload_2eLockPath(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2ffetch_2eCacheDir(ptr %v0)
declare { i64, ptr } @compiler_2ffetch_2eGitBase(ptr %v0)
declare %"compiler/fetch:Fetcher" @compiler_2ffetch_3aFetcher_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3, i1 %a4)
declare %"compiler/source:Names" @compiler_2fsource_3aNames_2ector(ptr %v0)
declare void @compiler_2fload_3aLoader_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4)
declare i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eLoad(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2folang_2eRunWith_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1)
declare void @compiler_2femit_3aEmitter_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, ptr %a3)
@G_2ecompiler_2fbuild_2eThinFrom = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\80\00\00\00\00\00" }>, align 8
@G_2ecompiler_2femit_2ePartSizeDev = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\08\00\00\00\00\00" }>, align 8
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fdiag_2eSpecPath(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoSpec(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @compiler_2fdiag_2eExplain(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_8c7e755ea0eb9876_6b14028370dd0cea = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eToUpper(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoRule(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2ffmt_2eFiles(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadEnd(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i8 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2femit_3aReused_3e_2eLen_3ccompiler_2femit_3aReused_3e(ptr %v0, ptr %a0)
declare i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H2b85ceff512af6e6ca26c554a1c16247(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i1 %a2)
declare { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare { i64, ptr } @std_2fos_2eArgs(ptr %v0)
declare void @std_2fos_2eRunOnStack(ptr %v0, i64 %a0, ptr %a1c, ptr %a1e)
@olang_loc_73b8d8bbbab8f911_f56ba933d304b59d = external constant [0 x i8]
@olang_loc_73c3116820f750d_32f9964414b76079 = external constant [0 x i8]
@olang_loc_23d2168bab4aeae0_126950dc9613ccec = external constant [0 x i8]
@olang_loc_a3d985a905b98e7d_1a99d62f9ee112a1 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fload_2ecompiler_2fload_3aLoader_2eEmbedded(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %v0, ptr %v1, ptr %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_32de2828e497f50e_77e9a884b57210fa = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eLen_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %a0)
declare %"compiler/load:Import" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eAt_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1c, ptr %a1e)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2ffree_3aFree_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %a1, ptr %a2)
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eDecide(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %a1, i64 %a2, i1 %a3)
declare i32 @std_2fos_2eRemove(ptr %v0, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fbuild_2eReadable(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_a5855f4dee34d57_8118d8286dddc923 = external constant [0 x i8]
declare %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_f7f4c072cfaa5bcd_bcba1f0f81b5e6d1 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %a0, i8 %a1)
@olang_loc_e0ebb5362b30f9f0_cd8defb7a2603e4 = external constant [0 x i8]
@olang_loc_b1bbe7d7728f376b_6cafbb8887a833cf = external constant [0 x i8]
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2femit_3aReused_3e_2ector(ptr %v0, i64 %a0)
declare %"compiler/emit:Reused" @compiler_2femit_3aReused_2ector(ptr %v0, i64 %a0)
@olang_loc_ff68d2ed4a63ad2_3df325967a6cbd9e = external constant [0 x i8]
@olang_loc_909229aa1239aacf_261ce50abd32cd9b = external constant [0 x i8]
@olang_loc_30bb4d1d04b77ae4_b48bc1201be9b2a0 = external constant [0 x i8]
@olang_loc_e09c8d310c475dd1_b9a5b78f48e38cfd = external constant [0 x i8]
@olang_loc_b7226a2473daafee_95f7e6f063520982 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2femit_3aReused_3e_2ePush_3ccompiler_2femit_3aReused_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/emit:Reused" %a1)
@G_2e_3csys_2fresource_2eh_3e_2eRLIMIT__AS = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\09\00\00\00" }>, align 8
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2ffilepath_2elivePath_2einit()
declare void @compiler_2fbuild_2ePhaseAt_2einit()
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eInstNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2ector(ptr %v0)
@olang_loc_6a9437d164e18f65_777063661d50beb9 = external constant [0 x i8]
declare %"<sys/resource.h>:rlimit" @_3csys_2fresource_2eh_3e_3arlimit_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
