; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%"compiler/olang:CommandLine" = type { i64, %"std/prelude/list:List<std/prelude/text:String&>", { i64, ptr }, i1, %"std/prelude/list:List<std/prelude/text:String&>", %"std/prelude/list:List<std/prelude/text:String&>", { i64, ptr }, { i64, ptr }, i1 }
%"std/prelude/list:List<std/prelude/text:String&>" = type { ptr }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/build:Config" = type { { i64, ptr }, { i64, ptr }, %"compiler/target:Target", %"compiler/cond:Consts", i1, i1, i1, i1, i1, i64, i1, i1, { i64, ptr }, { i64, ptr }, i64, i64, { i64, ptr } }
%"compiler/target:Target" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i1, i1 }
%"compiler/cond:Consts" = type { %"std/prelude/list:List<std/prelude/text:String&>", %"std/prelude/list:List<compiler/cond:Value>", %"std/prelude/list:List<Bool>", %"std/prelude/list:List<Bool>", %"std/prelude/list:List<Bool>", %"std/prelude/list:List<std/prelude/text:String&>", %"std/prelude/list:List<std/prelude/text:String&>" }
%"std/prelude/list:List<compiler/cond:Value>" = type { ptr }
%"std/prelude/list:List<Bool>" = type { ptr }
%"std/prelude/list:List<compiler/emit:Object>" = type { ptr }
%"compiler/lower:Gap" = type { i64, %"compiler/source:Span", { i64, ptr } }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/emit:Object" = type { { i64, ptr }, i32, { i64, ptr } }
%"compiler/check:Checker" = type { ptr, i1, i1, %"std/prelude/list:List<compiler/typed:Place&>", %"std/prelude/list:List<mut compiler/typed:Body&>", %"std/prelude/list:List<compiler/check:Gap>", %"std/prelude/list:List<mut compiler/check:frame&>", %"std/prelude/list:List<I64>", i64, %"std/prelude/list:List<I64>", %"std/prelude/map:Map<I64, I64>", %"std/prelude/map:Map<std/pair:Pair<I64, I64>, I64>", %"std/prelude/map:Map<I64, I64>", i32, %"std/prelude/map:Map<std/pair:Pair<I64, I64>, I64>", %"std/prelude/map:Map<std/pair:Pair<I64, I64>, compiler/types:TypeId>", %"std/prelude/list:List<compiler/typed:Expr&>", %"std/prelude/list:List<compiler/typed:Stmt&>", %"std/prelude/list:List<compiler/check:atRec>", i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map<I64, Bool>", %"std/prelude/map:Map<I64, compiler/types:ListId>", %"std/prelude/list:List<std/pair:Pair<I64, I64>>", %"std/prelude/map:Map<I64, Bool>", %"std/prelude/map:Map<std/pair:Pair<I64, I64>, compiler/types:ListId>", %"std/prelude/map:Map<std/pair:Pair<I64, I64>, compiler/types:ListId>", i64, %"std/prelude/map:Map<compiler/types:TypeId, Bool>", %"std/prelude/map:Map<std/pair:Pair<I64, I64>, compiler/source:NameId>", %"std/prelude/map:Map<std/pair:Pair<I64, I64>, Bool>", %"std/prelude/map:Map<std/pair:Pair<I64, I64>, compiler/check:roOrigin>", %"std/prelude/map:Map<std/pair:Pair<I64, I64>, Bool>", %"std/prelude/list:List<std/pair:Pair<std/pair:Pair<I64, I64>, std/pair:Pair<I64, I64>>>", %"std/prelude/list:List<compiler/check:roArg>", %"std/prelude/list:List<compiler/check:roFn>", %"std/prelude/map:Map<std/pair:Pair<I64, I64>, std/prelude/list:List<compiler/typed:Expr&>>", %"std/prelude/map:Map<std/pair:Pair<I64, I64>, Bool>", %"std/prelude/list:List<std/pair:Pair<I64, compiler/typed:Expr&>>", %"std/prelude/list:List<std/pair:Pair<I64, compiler/typed:Expr&>>", %"std/prelude/list:List<compiler/check:roDeepArg>", %"std/prelude/list:List<compiler/check:roArg>", %"std/prelude/map:Map<std/pair:Pair<I64, I64>, Bool>", %"std/prelude/map:Map<std/pair:Pair<I64, I64>, Bool>", %"std/prelude/map:Map<I64, Bool>", i64, %"std/prelude/map:Map<std/pair:Pair<I64, I64>, Bool>", %"std/prelude/list:List<compiler/check:Ask>", %"std/prelude/list:List<compiler/check:AssertAsk>", %"std/prelude/map:Map<I64, Bool>" }
%"std/prelude/list:List<compiler/typed:Place&>" = type { ptr }
%"std/prelude/list:List<mut compiler/typed:Body&>" = type { ptr }
%"std/prelude/list:List<compiler/check:Gap>" = type { ptr }
%"std/prelude/list:List<mut compiler/check:frame&>" = type { ptr }
%"std/prelude/list:List<I64>" = type { ptr }
%"std/prelude/map:Map<I64, I64>" = type { ptr }
%"std/prelude/map:Map<std/pair:Pair<I64, I64>, I64>" = type { ptr }
%"std/prelude/map:Map<std/pair:Pair<I64, I64>, compiler/types:TypeId>" = type { ptr }
%"std/prelude/list:List<compiler/typed:Expr&>" = type { ptr }
%"std/prelude/list:List<compiler/typed:Stmt&>" = type { ptr }
%"std/prelude/list:List<compiler/check:atRec>" = type { ptr }
%"std/prelude/map:Map<I64, Bool>" = type { ptr }
%"std/prelude/map:Map<I64, compiler/types:ListId>" = type { ptr }
%"std/prelude/list:List<std/pair:Pair<I64, I64>>" = type { ptr }
%"std/prelude/map:Map<std/pair:Pair<I64, I64>, compiler/types:ListId>" = type { ptr }
%"std/prelude/map:Map<compiler/types:TypeId, Bool>" = type { ptr }
%"std/prelude/map:Map<std/pair:Pair<I64, I64>, compiler/source:NameId>" = type { ptr }
%"std/prelude/map:Map<std/pair:Pair<I64, I64>, Bool>" = type { ptr }
%"std/prelude/map:Map<std/pair:Pair<I64, I64>, compiler/check:roOrigin>" = type { ptr }
%"std/prelude/list:List<std/pair:Pair<std/pair:Pair<I64, I64>, std/pair:Pair<I64, I64>>>" = type { ptr }
%"std/prelude/list:List<compiler/check:roArg>" = type { ptr }
%"std/prelude/list:List<compiler/check:roFn>" = type { ptr }
%"std/prelude/map:Map<std/pair:Pair<I64, I64>, std/prelude/list:List<compiler/typed:Expr&>>" = type { ptr }
%"std/prelude/list:List<std/pair:Pair<I64, compiler/typed:Expr&>>" = type { ptr }
%"std/prelude/list:List<compiler/check:roDeepArg>" = type { ptr }
%"std/prelude/list:List<compiler/check:Ask>" = type { ptr }
%"std/prelude/list:List<compiler/check:AssertAsk>" = type { ptr }
%"compiler/lower:Lowerer" = type { ptr, %"std/prelude/list:List<mut compiler/typed:Body&>", %"std/prelude/list:List<compiler/typed:Plan>", %"std/prelude/list:List<compiler/lower:Gap>", i1, %"std/prelude/map:Map<std/pair:Pair<I64, I64>, Bool>", %"std/prelude/list:List<compiler/mir:FnKey>", %"std/prelude/map:Map<compiler/mir:FnKey, Bool>", %"std/prelude/map:Map<compiler/types:TypeId, I64>", %"std/prelude/map:Map<compiler/types:TypeId, I64>", i1, i32, i32, i32 }
%"std/prelude/list:List<compiler/typed:Plan>" = type { ptr }
%"std/prelude/list:List<compiler/lower:Gap>" = type { ptr }
%"std/prelude/list:List<compiler/mir:FnKey>" = type { ptr }
%"std/prelude/map:Map<compiler/mir:FnKey, Bool>" = type { ptr }
%"std/prelude/map:Map<compiler/types:TypeId, I64>" = type { ptr }
%"compiler/emit:Emitter" = type { ptr, ptr, ptr, ptr, i1, i1, { i64, ptr }, %"std/prelude/list:List<std/prelude/text:String&>", %"std/prelude/list:List<compiler/mir:FnKey>", %"std/prelude/map:Map<compiler/mir:FnKey, I64>", i64, %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<compiler/source:NameId>", %"std/prelude/list:List<compiler/types:TypeId>", %"std/prelude/map:Map<compiler/types:TypeId, Bool>", %"std/prelude/list:List<std/prelude/text:String&>", %"std/prelude/list:List<std/prelude/text:String&>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<std/prelude/text:String&>", %"std/prelude/map:Map<std/prelude/text:String&, I64>", %"std/prelude/list:List<Array<I64>&>", { i64, ptr }, i64, i1, i64, %"std/prelude/map:Map<std/prelude/text:String&, std/prelude/text:String&>", %"std/prelude/list:List<std/prelude/text:String&>", %"std/prelude/map:Map<std/prelude/text:String&, Bool>", %"std/prelude/list:List<compiler/mir:FnKey>", %"std/prelude/list:List<compiler/types:TypeId>", %"std/prelude/list:List<compiler/types:TypeId>", %"std/prelude/list:List<compiler/types:TypeId>", %"std/prelude/map:Map<std/prelude/text:String&, Bool>", %"std/prelude/list:List<compiler/mir:FnKey>", %"std/prelude/map:Map<compiler/mir:FnKey, Bool>", %"std/prelude/map:Map<compiler/types:TypeId, I64>", %"std/prelude/map:Map<compiler/types:TypeId, I64>", i1, i1, i1, %"std/prelude/list:List<std/prelude/text:String&>", %"std/prelude/map:Map<std/prelude/text:String&, I64>", %"std/prelude/map:Map<I64, compiler/eval:Image>" }
%"std/prelude/map:Map<compiler/mir:FnKey, I64>" = type { ptr }
%"std/prelude/list:List<compiler/source:NameId>" = type { ptr }
%"std/prelude/list:List<compiler/types:TypeId>" = type { ptr }
%"std/prelude/map:Map<std/prelude/text:String&, I64>" = type { ptr }
%"std/prelude/list:List<Array<I64>&>" = type { ptr }
%"std/prelude/map:Map<std/prelude/text:String&, std/prelude/text:String&>" = type { ptr }
%"std/prelude/map:Map<std/prelude/text:String&, Bool>" = type { ptr }
%"std/prelude/map:Map<I64, compiler/eval:Image>" = type { ptr }
%"compiler/build:Unit" = type { { i64, ptr }, i32, { i64, ptr } }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map<I64, compiler/types:DeclId>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", %"std/prelude/map:Map<I64, I64>", %"std/prelude/map:Map<I64, I64>", %"std/prelude/list:List<compiler/generic:varRow>", %"std/prelude/map:Map<std/pair:Pair<I64, I64>, I64>", %"std/prelude/map:Map<I64, Bool>", %"std/prelude/map:Map<std/prelude/text:String&, I64>", %"std/prelude/map:Map<std/pair:Pair<I64, I64>, Bool>", i64, %"std/prelude/map:Map<I64, compiler/generic:pattern>", %"std/prelude/list:List<compiler/generic:fnRow>", %"std/prelude/map:Map<I64, Bool>", %"std/prelude/map:Map<I64, compiler/types:TypeId>", %"std/prelude/map:Map<std/pair:Pair<I64, I64>, I64>", %"std/prelude/map:Map<std/pair:Pair<I64, I64>, I64>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<compiler/generic:instance>", %"std/prelude/map:Map<std/pair:Pair<I64, compiler/types:ListId>, I64>", %"std/prelude/map:Map<compiler/types:ListId, compiler/types:ListId>", %"std/prelude/map:Map<I64, Bool>", i64, %"std/prelude/map:Map<I64, Bool>", i64, %"compiler/generic:Origin", %"std/prelude/map:Map<compiler/types:TypeId, compiler/generic:Origin>", %"std/prelude/map:Map<compiler/types:TypeId, Bool>", %"std/prelude/map:Map<std/prelude/text:String&, I64>", %"std/prelude/list:List<compiler/generic:ConstAsk>" }
%"compiler/types:Table" = type { ptr, %"std/prelude/list:List<compiler/types:data>", %"std/prelude/map:Map<compiler/types:data, compiler/types:TypeId>", %"std/prelude/list:List<I32>", %"std/prelude/list:List<Array<compiler/types:TypeId>&>", %"std/prelude/map:Map<Array<compiler/types:TypeId>&, compiler/types:ListId>", %"std/prelude/list:List<Array<compiler/source:NameId>&>", %"std/prelude/list:List<compiler/types:ListId>", %"std/prelude/map:Map<std/prelude/text:String&, I64>", %"std/prelude/list:List<std/prelude/text:String&>", %"std/prelude/map:Map<std/prelude/text:String&, I64>", %"std/prelude/list:List<compiler/types:decl>", %"std/prelude/list:List<std/prelude/text:String&>", %"std/prelude/map:Map<std/prelude/text:String&, compiler/types:DeclId>", %"std/prelude/map:Map<compiler/types:TypeId, compiler/types:body>", %"std/prelude/map:Map<compiler/types:TypeId, Array<compiler/source:NameId>&>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<std/prelude/text:String&>", %"std/prelude/list:List<compiler/types:TypeId>", %"std/prelude/list:List<Array<I64>&>", %"std/prelude/map:Map<Array<I64>&, compiler/types:ScopesId>", %"std/prelude/list:List<Array<I64>&>", %"std/prelude/map:Map<Array<I64>&, I64>", %"std/prelude/map:Map<compiler/types:TypeId, I64>", i1 }
%"std/prelude/list:List<compiler/types:data>" = type { ptr }
%"std/prelude/map:Map<compiler/types:data, compiler/types:TypeId>" = type { ptr }
%"std/prelude/list:List<I32>" = type { ptr }
%"std/prelude/list:List<Array<compiler/types:TypeId>&>" = type { ptr }
%"std/prelude/map:Map<Array<compiler/types:TypeId>&, compiler/types:ListId>" = type { ptr }
%"std/prelude/list:List<Array<compiler/source:NameId>&>" = type { ptr }
%"std/prelude/list:List<compiler/types:ListId>" = type { ptr }
%"std/prelude/list:List<compiler/types:decl>" = type { ptr }
%"std/prelude/map:Map<std/prelude/text:String&, compiler/types:DeclId>" = type { ptr }
%"std/prelude/map:Map<compiler/types:TypeId, compiler/types:body>" = type { ptr }
%"std/prelude/map:Map<compiler/types:TypeId, Array<compiler/source:NameId>&>" = type { ptr }
%"std/prelude/map:Map<Array<I64>&, compiler/types:ScopesId>" = type { ptr }
%"std/prelude/map:Map<Array<I64>&, I64>" = type { ptr }
%"std/prelude/map:Map<I64, compiler/types:DeclId>" = type { ptr }
%"std/prelude/list:List<compiler/generic:varRow>" = type { ptr }
%"std/prelude/map:Map<I64, compiler/generic:pattern>" = type { ptr }
%"std/prelude/list:List<compiler/generic:fnRow>" = type { ptr }
%"std/prelude/map:Map<I64, compiler/types:TypeId>" = type { ptr }
%"std/prelude/list:List<compiler/generic:instance>" = type { ptr }
%"std/prelude/map:Map<std/pair:Pair<I64, compiler/types:ListId>, I64>" = type { ptr }
%"std/prelude/map:Map<compiler/types:ListId, compiler/types:ListId>" = type { ptr }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"std/prelude/map:Map<compiler/types:TypeId, compiler/generic:Origin>" = type { ptr }
%"std/prelude/list:List<compiler/generic:ConstAsk>" = type { ptr }
%"compiler/build:Program" = type { %"std/prelude/list:List<compiler/build:Unit>", { i64, ptr }, { i64, ptr } }
%"std/prelude/list:List<compiler/build:Unit>" = type { ptr }
%"compiler/interp:Exec" = type { ptr, %"std/prelude/list:List<mut compiler/typed:Body&>", i32, %"compiler/lower:Lowerer", %"compiler/eval:Machine", %"std/prelude/list:List<compiler/mir:FnKey>", %"std/prelude/map:Map<compiler/mir:FnKey, Bool>", %"std/prelude/map:Map<compiler/types:TypeId, I64>", %"std/prelude/map:Map<I64, Bool>", %"std/prelude/list:List<I64>", %"std/prelude/map:Map<I64, Bool>", i1 }
%"compiler/eval:Machine" = type { ptr, i32, i64, i64, i64, i64, i64, %"compiler/eval:Ptr", i32, { i64, [5 x i64] }, i1, %"std/prelude/list:List<compiler/mir:Fn>", { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map<compiler/mir:FnKey, I64>", %"std/prelude/list:List<compiler/mir:FnKey>", %"std/prelude/map:Map<compiler/mir:FnKey, I64>", %"std/prelude/list:List<I64>", %"std/prelude/map:Map<I64, std/prelude/text:String&>", %"std/prelude/map:Map<I64, I64>", %"std/prelude/map:Map<compiler/types:TypeId, compiler/mir:FnKey>", %"std/prelude/list:List<compiler/eval:global>", %"std/prelude/map:Map<compiler/eval:gkey, I64>", %"std/prelude/map:Map<compiler/eval:dkey, I64>", { i64, ptr }, { i64, ptr }, i64, { i64, ptr }, { i64, ptr }, i64, %"std/prelude/list:List<I64>", %"std/prelude/list:List<compiler/eval:scope>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<compiler/eval:reg>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<compiler/eval:task>", %"std/prelude/list:List<I64>", { i64, ptr }, i64, { i64, ptr }, i64, %"std/prelude/list:List<I64>", i64, i64, { i64, ptr }, i64, i64, %"std/prelude/map:Map<compiler/types:TypeId, I64>", %"std/prelude/list:List<I64>", %"std/prelude/map:Map<compiler/types:TypeId, Bool>", i64, %"compiler/source:Span", %"std/prelude/list:List<std/prelude/text:String&>", %"std/prelude/list:List<I64>", i64, %"std/prelude/list:List<I64>", i64, %"compiler/source:Span", i32 }
%"compiler/eval:Ptr" = type { i64, i64 }
%"std/prelude/list:List<compiler/mir:Fn>" = type { ptr }
%"std/prelude/map:Map<I64, std/prelude/text:String&>" = type { ptr }
%"std/prelude/map:Map<compiler/types:TypeId, compiler/mir:FnKey>" = type { ptr }
%"std/prelude/list:List<compiler/eval:global>" = type { ptr }
%"std/prelude/map:Map<compiler/eval:gkey, I64>" = type { ptr }
%"std/prelude/map:Map<compiler/eval:dkey, I64>" = type { ptr }
%"std/prelude/list:List<compiler/eval:scope>" = type { ptr }
%"std/prelude/list:List<compiler/eval:reg>" = type { ptr }
%"std/prelude/list:List<compiler/eval:task>" = type { ptr }
%"compiler/fetch:Fetcher" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i1, i1, %"std/prelude/list:List<std/prelude/text:String&>", %"std/prelude/list:List<std/prelude/text:String&>", %"std/prelude/list:List<std/prelude/text:String&>", %"std/prelude/list:List<std/prelude/text:String&>" }
%"compiler/source:Names" = type { %"std/prelude/list:List<std/prelude/text:String&>", %"std/prelude/map:Map<std/prelude/text:String&, compiler/source:NameId>" }
%"std/prelude/map:Map<std/prelude/text:String&, compiler/source:NameId>" = type { ptr }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/list:List<mut compiler/load:Module&>", %"std/prelude/list:List<std/prelude/text:String&>", i64, { i64, ptr }, { i64, ptr } }
%"std/prelude/list:List<mut compiler/load:Module&>" = type { ptr }
%"compiler/olang:Passes" = type { i64 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List<std/prelude/text:Char>" }
%"std/prelude/list:List<std/prelude/text:Char>" = type { ptr }
%"compiler/scope:Scoper" = type { ptr, %"std/prelude/list:List<mut compiler/typed:Body&>", %"std/prelude/list:List<compiler/typed:Plan>", %"std/prelude/list:List<compiler/scope:Gap>", { ptr, ptr }, { ptr, ptr }, %"std/prelude/list:List<mut compiler/scope:summary&>", %"std/prelude/map:Map<compiler/types:TypeId, I64>", %"std/prelude/map:Map<compiler/types:TypeId, I64>", %"std/prelude/map:Map<std/pair:Pair<I64, I64>, I64>", %"std/prelude/map:Map<I64, std/prelude/text:String&>", %"std/prelude/list:List<Bool>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<Bool>", %"std/prelude/list:List<I64>", i64, %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", ptr, i64, i1, %"compiler/typed:Plan", %"std/prelude/list:List<compiler/scope:Term>", %"std/prelude/list:List<compiler/scope:Term>", %"std/prelude/list:List<compiler/typed:BlockId>", %"std/prelude/list:List<compiler/scope:rel>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<compiler/scope:Term>", %"compiler/source:Span", i64, %"std/prelude/map:Map<I64, compiler/typed:Expr&>", %"std/prelude/map:Map<I64, compiler/scope:Term>", %"std/prelude/map:Map<I64, compiler/typed:Expr&>", %"std/prelude/map:Map<I64, I64>", %"std/prelude/list:List<compiler/scope:Term>", %"std/prelude/list:List<I64>", %"std/prelude/map:Map<I64, I64>", %"std/prelude/map:Map<std/pair:Pair<I64, I64>, Bool>", i64, i1, %"std/prelude/map:Map<I64, std/prelude/list:List<compiler/scope:Term>>", %"std/prelude/map:Map<I64, Bool>", %"std/prelude/map:Map<I64, Bool>", i64, i64, %"std/prelude/list:List<compiler/scope:Term>", i1, %"std/prelude/list:List<compiler/typed:Place&>", %"std/prelude/list:List<Bool>", %"std/prelude/list:List<Bool>", i1, %"std/prelude/list:List<compiler/source:Span>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<compiler/source:Span>", %"std/prelude/list:List<Bool>", i1, i1, %"std/prelude/list:List<compiler/typed:BlockId>", { i64, [2 x i64] }, i1, %"compiler/source:Span", { i64, [2 x i64] }, i1, { i64, [2 x i64] }, i1, i1, i1, %"compiler/source:Span", %"std/prelude/list:List<compiler/scope:fnUse>", %"std/prelude/list:List<Bool>", %"std/prelude/list:List<Bool>", %"std/prelude/list:List<Bool>", %"std/prelude/list:List<compiler/scope:Term>", %"std/prelude/list:List<Bool>", %"std/prelude/map:Map<I64, compiler/scope:Term>", %"std/prelude/map:Map<std/pair:Pair<I64, I64>, I64>", %"std/prelude/map:Map<std/pair:Pair<I64, I64>, I64>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", i1, i64, { i64, [2 x i64] }, i1, i1, %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", i1, i64, i32, i1, i1 }
%"std/prelude/list:List<compiler/scope:Gap>" = type { ptr }
%"std/prelude/list:List<mut compiler/scope:summary&>" = type { ptr }
%"compiler/typed:Plan" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/list:List<compiler/typed:Scope>" }
%"std/prelude/list:List<compiler/typed:Scope>" = type { ptr }
%"std/prelude/list:List<compiler/scope:Term>" = type { ptr }
%"std/prelude/list:List<compiler/typed:BlockId>" = type { ptr }
%"std/prelude/list:List<compiler/scope:rel>" = type { ptr }
%"std/prelude/map:Map<I64, compiler/typed:Expr&>" = type { ptr }
%"std/prelude/map:Map<I64, compiler/scope:Term>" = type { ptr }
%"std/prelude/map:Map<I64, std/prelude/list:List<compiler/scope:Term>>" = type { ptr }
%"std/prelude/list:List<compiler/source:Span>" = type { ptr }
%"std/prelude/list:List<compiler/scope:fnUse>" = type { ptr }
@G_2ecompiler_2folang_2eBuild = global i64 zeroinitializer
@G_2ecompiler_2folang_2eCompile = global i64 zeroinitializer
@G_2ecompiler_2folang_2eExplain = global i64 zeroinitializer
@G_2ecompiler_2folang_2eFormat = global i64 zeroinitializer
@G_2ecompiler_2folang_2eHelp = global i64 zeroinitializer
@G_2ecompiler_2folang_2eInterp = global i64 zeroinitializer
@G_2ecompiler_2folang_2eModeUsage = global { i64, ptr } zeroinitializer
@G_2ecompiler_2folang_2eModeWhat = global { i64, ptr } zeroinitializer
@G_2ecompiler_2folang_2eModeWords = global { i64, ptr } zeroinitializer
@G_2ecompiler_2folang_2eOptModes = global { i64, ptr } zeroinitializer
@G_2ecompiler_2folang_2eOptValues = global { i64, ptr } zeroinitializer
@G_2ecompiler_2folang_2eOptWhat = global { i64, ptr } zeroinitializer
@G_2ecompiler_2folang_2eOptWords = global { i64, ptr } zeroinitializer
@G_2ecompiler_2folang_2eRun = global i64 zeroinitializer
@G_2ecompiler_2folang_2eTest = global i64 zeroinitializer
define dso_local void @compiler_2folang_2eBuild_2einit() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 1, ptr @G_2ecompiler_2folang_2eBuild
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eCompile_2einit() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 2, ptr @G_2ecompiler_2folang_2eCompile
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eExplain_2einit() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 6, ptr @G_2ecompiler_2folang_2eExplain
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eFormat_2einit() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 5, ptr @G_2ecompiler_2folang_2eFormat
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eHelp_2einit() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 7, ptr @G_2ecompiler_2folang_2eHelp
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eInterp_2einit() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 4, ptr @G_2ecompiler_2folang_2eInterp
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eModeUsage_2einit() #0 {
entry:
  %l0 = alloca [8 x { i64, ptr }]
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i1
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = insertvalue [8 x { i64, ptr }] undef, { i64, ptr } { i64 42, ptr @.d0 }, 0
  %t2 = insertvalue [8 x { i64, ptr }] %t1, { i64, ptr } { i64 34, ptr @.d1 }, 1
  %t3 = insertvalue [8 x { i64, ptr }] %t2, { i64, ptr } { i64 36, ptr @.d2 }, 2
  %t4 = insertvalue [8 x { i64, ptr }] %t3, { i64, ptr } { i64 36, ptr @.d3 }, 3
  %t5 = insertvalue [8 x { i64, ptr }] %t4, { i64, ptr } { i64 52, ptr @.d4 }, 4
  %t6 = insertvalue [8 x { i64, ptr }] %t5, { i64, ptr } { i64 38, ptr @.d5 }, 5
  %t7 = insertvalue [8 x { i64, ptr }] %t6, { i64, ptr } { i64 18, ptr @.d6 }, 6
  %t8 = insertvalue [8 x { i64, ptr }] %t7, { i64, ptr } { i64 17, ptr @.d7 }, 7
  store [8 x { i64, ptr }] %t8, ptr %l0
  %t9 = load [8 x { i64, ptr }], ptr %l0
  %t10 = load ptr, ptr @__olang_prog_scope
  %t11 = call ptr @__olang_scope_alloc(ptr %t10, i64 128)
  store [8 x { i64, ptr }] %t9, ptr %t11
  %t12 = insertvalue { i64, ptr } undef, i64 8, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  store { i64, ptr } %t13, ptr %l1
  %t14 = load { i64, ptr }, ptr @G_2ecompiler_2folang_2eModeUsage
  %t15 = extractvalue { i64, ptr } %t14, 0
  store i64 %t15, ptr %l2
  %t16 = load { i64, ptr }, ptr %l1
  %t17 = extractvalue { i64, ptr } %t16, 0
  store i64 %t17, ptr %l3
  %t18 = load i64, ptr %l2
  %t19 = load i64, ptr %l3
  %t20 = icmp eq i64 %t18, %t19
  store i1 %t20, ptr %l4
  %t21 = load i1, ptr %l4
  br i1 %t21, label %bb1, label %bb2
bb1:
  %t22 = getelementptr { i64, ptr }, ptr @G_2ecompiler_2folang_2eModeUsage, i32 0, i32 1
  %t23 = load ptr, ptr %t22
  %t24 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t25 = load ptr, ptr %t24
  %t26 = load i64, ptr %l3
  %t27 = mul i64 %t26, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t23, ptr %t25, i64 %t27, i1 false)
  br label %bb3
bb2:
  %t28 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t28, ptr @G_2ecompiler_2folang_2eModeUsage
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eModeWhat_2einit() #0 {
entry:
  %l0 = alloca [8 x { i64, ptr }]
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i1
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = insertvalue [8 x { i64, ptr }] undef, { i64, ptr } { i64 106, ptr @.d8 }, 0
  %t2 = insertvalue [8 x { i64, ptr }] %t1, { i64, ptr } { i64 64, ptr @.d9 }, 1
  %t3 = insertvalue [8 x { i64, ptr }] %t2, { i64, ptr } { i64 54, ptr @.d10 }, 2
  %t4 = insertvalue [8 x { i64, ptr }] %t3, { i64, ptr } { i64 62, ptr @.d11 }, 3
  %t5 = insertvalue [8 x { i64, ptr }] %t4, { i64, ptr } { i64 110, ptr @.d12 }, 4
  %t6 = insertvalue [8 x { i64, ptr }] %t5, { i64, ptr } { i64 46, ptr @.d13 }, 5
  %t7 = insertvalue [8 x { i64, ptr }] %t6, { i64, ptr } { i64 41, ptr @.d14 }, 6
  %t8 = insertvalue [8 x { i64, ptr }] %t7, { i64, ptr } { i64 36, ptr @.d15 }, 7
  store [8 x { i64, ptr }] %t8, ptr %l0
  %t9 = load [8 x { i64, ptr }], ptr %l0
  %t10 = load ptr, ptr @__olang_prog_scope
  %t11 = call ptr @__olang_scope_alloc(ptr %t10, i64 128)
  store [8 x { i64, ptr }] %t9, ptr %t11
  %t12 = insertvalue { i64, ptr } undef, i64 8, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  store { i64, ptr } %t13, ptr %l1
  %t14 = load { i64, ptr }, ptr @G_2ecompiler_2folang_2eModeWhat
  %t15 = extractvalue { i64, ptr } %t14, 0
  store i64 %t15, ptr %l2
  %t16 = load { i64, ptr }, ptr %l1
  %t17 = extractvalue { i64, ptr } %t16, 0
  store i64 %t17, ptr %l3
  %t18 = load i64, ptr %l2
  %t19 = load i64, ptr %l3
  %t20 = icmp eq i64 %t18, %t19
  store i1 %t20, ptr %l4
  %t21 = load i1, ptr %l4
  br i1 %t21, label %bb1, label %bb2
bb1:
  %t22 = getelementptr { i64, ptr }, ptr @G_2ecompiler_2folang_2eModeWhat, i32 0, i32 1
  %t23 = load ptr, ptr %t22
  %t24 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t25 = load ptr, ptr %t24
  %t26 = load i64, ptr %l3
  %t27 = mul i64 %t26, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t23, ptr %t25, i64 %t27, i1 false)
  br label %bb3
bb2:
  %t28 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t28, ptr @G_2ecompiler_2folang_2eModeWhat
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eModeWords_2einit() #0 {
entry:
  %l0 = alloca [8 x { i64, ptr }]
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i1
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = insertvalue [8 x { i64, ptr }] undef, { i64, ptr } { i64 0, ptr @.d16 }, 0
  %t2 = insertvalue [8 x { i64, ptr }] %t1, { i64, ptr } { i64 5, ptr @.d17 }, 1
  %t3 = insertvalue [8 x { i64, ptr }] %t2, { i64, ptr } { i64 7, ptr @.d18 }, 2
  %t4 = insertvalue [8 x { i64, ptr }] %t3, { i64, ptr } { i64 4, ptr @.d19 }, 3
  %t5 = insertvalue [8 x { i64, ptr }] %t4, { i64, ptr } { i64 9, ptr @.d20 }, 4
  %t6 = insertvalue [8 x { i64, ptr }] %t5, { i64, ptr } { i64 6, ptr @.d21 }, 5
  %t7 = insertvalue [8 x { i64, ptr }] %t6, { i64, ptr } { i64 7, ptr @.d22 }, 6
  %t8 = insertvalue [8 x { i64, ptr }] %t7, { i64, ptr } { i64 4, ptr @.d23 }, 7
  store [8 x { i64, ptr }] %t8, ptr %l0
  %t9 = load [8 x { i64, ptr }], ptr %l0
  %t10 = load ptr, ptr @__olang_prog_scope
  %t11 = call ptr @__olang_scope_alloc(ptr %t10, i64 128)
  store [8 x { i64, ptr }] %t9, ptr %t11
  %t12 = insertvalue { i64, ptr } undef, i64 8, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  store { i64, ptr } %t13, ptr %l1
  %t14 = load { i64, ptr }, ptr @G_2ecompiler_2folang_2eModeWords
  %t15 = extractvalue { i64, ptr } %t14, 0
  store i64 %t15, ptr %l2
  %t16 = load { i64, ptr }, ptr %l1
  %t17 = extractvalue { i64, ptr } %t16, 0
  store i64 %t17, ptr %l3
  %t18 = load i64, ptr %l2
  %t19 = load i64, ptr %l3
  %t20 = icmp eq i64 %t18, %t19
  store i1 %t20, ptr %l4
  %t21 = load i1, ptr %l4
  br i1 %t21, label %bb1, label %bb2
bb1:
  %t22 = getelementptr { i64, ptr }, ptr @G_2ecompiler_2folang_2eModeWords, i32 0, i32 1
  %t23 = load ptr, ptr %t22
  %t24 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t25 = load ptr, ptr %t24
  %t26 = load i64, ptr %l3
  %t27 = mul i64 %t26, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t23, ptr %t25, i64 %t27, i1 false)
  br label %bb3
bb2:
  %t28 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t28, ptr @G_2ecompiler_2folang_2eModeWords
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eOptModes_2einit() #0 {
entry:
  %l0 = alloca [8 x i64]
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i1
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = insertvalue [8 x i64] undef, i64 6, 0
  %t2 = insertvalue [8 x i64] %t1, i64 15, 1
  %t3 = insertvalue [8 x i64] %t2, i64 15, 2
  %t4 = insertvalue [8 x i64] %t3, i64 15, 3
  %t5 = insertvalue [8 x i64] %t4, i64 31, 4
  %t6 = insertvalue [8 x i64] %t5, i64 31, 5
  %t7 = insertvalue [8 x i64] %t6, i64 31, 6
  %t8 = insertvalue [8 x i64] %t7, i64 32, 7
  store [8 x i64] %t8, ptr %l0
  %t9 = load [8 x i64], ptr %l0
  %t10 = load ptr, ptr @__olang_prog_scope
  %t11 = call ptr @__olang_scope_alloc(ptr %t10, i64 64)
  store [8 x i64] %t9, ptr %t11
  %t12 = insertvalue { i64, ptr } undef, i64 8, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  store { i64, ptr } %t13, ptr %l1
  %t14 = load { i64, ptr }, ptr @G_2ecompiler_2folang_2eOptModes
  %t15 = extractvalue { i64, ptr } %t14, 0
  store i64 %t15, ptr %l2
  %t16 = load { i64, ptr }, ptr %l1
  %t17 = extractvalue { i64, ptr } %t16, 0
  store i64 %t17, ptr %l3
  %t18 = load i64, ptr %l2
  %t19 = load i64, ptr %l3
  %t20 = icmp eq i64 %t18, %t19
  store i1 %t20, ptr %l4
  %t21 = load i1, ptr %l4
  br i1 %t21, label %bb1, label %bb2
bb1:
  %t22 = getelementptr { i64, ptr }, ptr @G_2ecompiler_2folang_2eOptModes, i32 0, i32 1
  %t23 = load ptr, ptr %t22
  %t24 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t25 = load ptr, ptr %t24
  %t26 = load i64, ptr %l3
  %t27 = mul i64 %t26, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t23, ptr %t25, i64 %t27, i1 false)
  br label %bb3
bb2:
  %t28 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t28, ptr @G_2ecompiler_2folang_2eOptModes
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eOptValues_2einit() #0 {
entry:
  %l0 = alloca [8 x { i64, ptr }]
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i1
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = insertvalue [8 x { i64, ptr }] undef, { i64, ptr } { i64 4, ptr @.d24 }, 0
  %t2 = insertvalue [8 x { i64, ptr }] %t1, { i64, ptr } { i64 0, ptr @.d25 }, 1
  %t3 = insertvalue [8 x { i64, ptr }] %t2, { i64, ptr } { i64 0, ptr @.d26 }, 2
  %t4 = insertvalue [8 x { i64, ptr }] %t3, { i64, ptr } { i64 0, ptr @.d27 }, 3
  %t5 = insertvalue [8 x { i64, ptr }] %t4, { i64, ptr } { i64 4, ptr @.d28 }, 4
  %t6 = insertvalue [8 x { i64, ptr }] %t5, { i64, ptr } { i64 10, ptr @.d29 }, 5
  %t7 = insertvalue [8 x { i64, ptr }] %t6, { i64, ptr } { i64 0, ptr @.d30 }, 6
  %t8 = insertvalue [8 x { i64, ptr }] %t7, { i64, ptr } { i64 0, ptr @.d31 }, 7
  store [8 x { i64, ptr }] %t8, ptr %l0
  %t9 = load [8 x { i64, ptr }], ptr %l0
  %t10 = load ptr, ptr @__olang_prog_scope
  %t11 = call ptr @__olang_scope_alloc(ptr %t10, i64 128)
  store [8 x { i64, ptr }] %t9, ptr %t11
  %t12 = insertvalue { i64, ptr } undef, i64 8, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  store { i64, ptr } %t13, ptr %l1
  %t14 = load { i64, ptr }, ptr @G_2ecompiler_2folang_2eOptValues
  %t15 = extractvalue { i64, ptr } %t14, 0
  store i64 %t15, ptr %l2
  %t16 = load { i64, ptr }, ptr %l1
  %t17 = extractvalue { i64, ptr } %t16, 0
  store i64 %t17, ptr %l3
  %t18 = load i64, ptr %l2
  %t19 = load i64, ptr %l3
  %t20 = icmp eq i64 %t18, %t19
  store i1 %t20, ptr %l4
  %t21 = load i1, ptr %l4
  br i1 %t21, label %bb1, label %bb2
bb1:
  %t22 = getelementptr { i64, ptr }, ptr @G_2ecompiler_2folang_2eOptValues, i32 0, i32 1
  %t23 = load ptr, ptr %t22
  %t24 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t25 = load ptr, ptr %t24
  %t26 = load i64, ptr %l3
  %t27 = mul i64 %t26, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t23, ptr %t25, i64 %t27, i1 false)
  br label %bb3
bb2:
  %t28 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t28, ptr @G_2ecompiler_2folang_2eOptValues
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eOptWhat_2einit() #0 {
entry:
  %l0 = alloca [8 x { i64, ptr }]
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i1
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = insertvalue [8 x { i64, ptr }] undef, { i64, ptr } { i64 49, ptr @.d32 }, 0
  %t2 = insertvalue [8 x { i64, ptr }] %t1, { i64, ptr } { i64 53, ptr @.d33 }, 1
  %t3 = insertvalue [8 x { i64, ptr }] %t2, { i64, ptr } { i64 40, ptr @.d34 }, 2
  %t4 = insertvalue [8 x { i64, ptr }] %t3, { i64, ptr } { i64 37, ptr @.d35 }, 3
  %t5 = insertvalue [8 x { i64, ptr }] %t4, { i64, ptr } { i64 32, ptr @.d36 }, 4
  %t6 = insertvalue [8 x { i64, ptr }] %t5, { i64, ptr } { i64 30, ptr @.d37 }, 5
  %t7 = insertvalue [8 x { i64, ptr }] %t6, { i64, ptr } { i64 85, ptr @.d38 }, 6
  %t8 = insertvalue [8 x { i64, ptr }] %t7, { i64, ptr } { i64 57, ptr @.d39 }, 7
  store [8 x { i64, ptr }] %t8, ptr %l0
  %t9 = load [8 x { i64, ptr }], ptr %l0
  %t10 = load ptr, ptr @__olang_prog_scope
  %t11 = call ptr @__olang_scope_alloc(ptr %t10, i64 128)
  store [8 x { i64, ptr }] %t9, ptr %t11
  %t12 = insertvalue { i64, ptr } undef, i64 8, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  store { i64, ptr } %t13, ptr %l1
  %t14 = load { i64, ptr }, ptr @G_2ecompiler_2folang_2eOptWhat
  %t15 = extractvalue { i64, ptr } %t14, 0
  store i64 %t15, ptr %l2
  %t16 = load { i64, ptr }, ptr %l1
  %t17 = extractvalue { i64, ptr } %t16, 0
  store i64 %t17, ptr %l3
  %t18 = load i64, ptr %l2
  %t19 = load i64, ptr %l3
  %t20 = icmp eq i64 %t18, %t19
  store i1 %t20, ptr %l4
  %t21 = load i1, ptr %l4
  br i1 %t21, label %bb1, label %bb2
bb1:
  %t22 = getelementptr { i64, ptr }, ptr @G_2ecompiler_2folang_2eOptWhat, i32 0, i32 1
  %t23 = load ptr, ptr %t22
  %t24 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t25 = load ptr, ptr %t24
  %t26 = load i64, ptr %l3
  %t27 = mul i64 %t26, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t23, ptr %t25, i64 %t27, i1 false)
  br label %bb3
bb2:
  %t28 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t28, ptr @G_2ecompiler_2folang_2eOptWhat
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eOptWords_2einit() #0 {
entry:
  %l0 = alloca [8 x { i64, ptr }]
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i1
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = insertvalue [8 x { i64, ptr }] undef, { i64, ptr } { i64 7, ptr @.d40 }, 0
  %t2 = insertvalue [8 x { i64, ptr }] %t1, { i64, ptr } { i64 6, ptr @.d41 }, 1
  %t3 = insertvalue [8 x { i64, ptr }] %t2, { i64, ptr } { i64 5, ptr @.d42 }, 2
  %t4 = insertvalue [8 x { i64, ptr }] %t3, { i64, ptr } { i64 9, ptr @.d43 }, 3
  %t5 = insertvalue [8 x { i64, ptr }] %t4, { i64, ptr } { i64 7, ptr @.d44 }, 4
  %t6 = insertvalue [8 x { i64, ptr }] %t5, { i64, ptr } { i64 7, ptr @.d45 }, 5
  %t7 = insertvalue [8 x { i64, ptr }] %t6, { i64, ptr } { i64 7, ptr @.d46 }, 6
  %t8 = insertvalue [8 x { i64, ptr }] %t7, { i64, ptr } { i64 6, ptr @.d47 }, 7
  store [8 x { i64, ptr }] %t8, ptr %l0
  %t9 = load [8 x { i64, ptr }], ptr %l0
  %t10 = load ptr, ptr @__olang_prog_scope
  %t11 = call ptr @__olang_scope_alloc(ptr %t10, i64 128)
  store [8 x { i64, ptr }] %t9, ptr %t11
  %t12 = insertvalue { i64, ptr } undef, i64 8, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  store { i64, ptr } %t13, ptr %l1
  %t14 = load { i64, ptr }, ptr @G_2ecompiler_2folang_2eOptWords
  %t15 = extractvalue { i64, ptr } %t14, 0
  store i64 %t15, ptr %l2
  %t16 = load { i64, ptr }, ptr %l1
  %t17 = extractvalue { i64, ptr } %t16, 0
  store i64 %t17, ptr %l3
  %t18 = load i64, ptr %l2
  %t19 = load i64, ptr %l3
  %t20 = icmp eq i64 %t18, %t19
  store i1 %t20, ptr %l4
  %t21 = load i1, ptr %l4
  br i1 %t21, label %bb1, label %bb2
bb1:
  %t22 = getelementptr { i64, ptr }, ptr @G_2ecompiler_2folang_2eOptWords, i32 0, i32 1
  %t23 = load ptr, ptr %t22
  %t24 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t25 = load ptr, ptr %t24
  %t26 = load i64, ptr %l3
  %t27 = mul i64 %t26, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t23, ptr %t25, i64 %t27, i1 false)
  br label %bb3
bb2:
  %t28 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t28, ptr @G_2ecompiler_2folang_2eOptWords
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i32, %"compiler/olang:CommandLine" } @compiler_2folang_2eParse(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l2 = alloca ptr
  %lp3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca %"compiler/olang:CommandLine"
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca %"compiler/msgs:Msg"
  %l21 = alloca i32
  %l22 = alloca i32
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca i1
  %l26 = alloca i1
  %l27 = alloca i1
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i1
  %l31 = alloca i1
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca %"compiler/msgs:Msg"
  %l41 = alloca i32
  %l42 = alloca i32
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l47 = alloca i1
  %l48 = alloca i1
  %l49 = alloca { i64, ptr }
  %l50 = alloca i64
  %l51 = alloca { i64, ptr }
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca { i64, ptr }
  %l55 = alloca i1
  %l56 = alloca { i64, ptr }
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i1
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i1
  %l64 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca i64
  %l68 = alloca i64
  %l69 = alloca i64
  %l70 = alloca i64
  %l71 = alloca i64
  %l72 = alloca i64
  %l73 = alloca i64
  %l74 = alloca i64
  %l75 = alloca i1
  %l76 = alloca i1
  %l77 = alloca i64
  %l78 = alloca i64
  %l79 = alloca i64
  %l80 = alloca i64
  %l81 = alloca i64
  %l82 = alloca i64
  %l83 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l85 = alloca i1
  %l86 = alloca i64
  %l87 = alloca i64
  %l88 = alloca i64
  %l89 = alloca i64
  %l90 = alloca i1
  %l91 = alloca ptr
  %l92 = alloca { i64, ptr }
  %l93 = alloca i64
  %l94 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l96 = alloca %"compiler/msgs:Msg"
  %l97 = alloca i32
  %l98 = alloca i32
  %l99 = alloca i64
  %l100 = alloca i64
  %l101 = alloca i64
  %l102 = alloca i64
  %l103 = alloca i64
  %l104 = alloca i1
  %l105 = alloca ptr
  %l106 = alloca { i64, ptr }
  %l107 = alloca i64
  %l108 = alloca i64
  %l109 = alloca { i64, ptr }
  %l110 = alloca { i64, ptr }
  %l111 = alloca i64
  %l112 = alloca { i64, ptr }
  %l113 = alloca { i64, ptr }
  %l114 = alloca %"compiler/msgs:Msg"
  %l115 = alloca i32
  %l116 = alloca i32
  %l117 = alloca ptr
  %l118 = alloca { i64, ptr }
  %l119 = alloca { i64, ptr }
  %l120 = alloca { i64, ptr }
  %l121 = alloca i64
  %l122 = alloca { i64, ptr }
  %l123 = alloca i1
  %l124 = alloca i1
  %l125 = alloca i64
  %l126 = alloca { i64, ptr }
  %l127 = alloca i64
  %l128 = alloca i1
  %l129 = alloca ptr
  %l130 = alloca { i64, ptr }
  %l131 = alloca i64
  %l132 = alloca { i64, ptr }
  %l133 = alloca %"compiler/msgs:Msg"
  %l134 = alloca i32
  %l135 = alloca i32
  %l136 = alloca { i64, ptr }
  %l137 = alloca i64
  %l138 = alloca { i64, ptr }
  %l139 = alloca { i64, ptr }
  %l140 = alloca { i64, ptr }
  %l141 = alloca i64
  %l142 = alloca i64
  %l143 = alloca ptr
  %l144 = alloca { i64, ptr }
  %l145 = alloca { i64, ptr }
  %l146 = alloca { i64, ptr }
  %l147 = alloca i64
  %l148 = alloca i1
  %l149 = alloca { i64, ptr }
  %l150 = alloca { i64, ptr }
  %l151 = alloca { i64, ptr }
  %l152 = alloca i64
  %l153 = alloca i1
  %l154 = alloca ptr
  %l155 = alloca i64
  %l156 = alloca i1
  %l157 = alloca ptr
  %l158 = alloca i64
  %l159 = alloca i1
  %l160 = alloca ptr
  %l161 = alloca i64
  %l162 = alloca i1
  %l163 = alloca { i64, ptr }
  %l164 = alloca { i64, ptr }
  %l165 = alloca { i64, ptr }
  %l166 = alloca i64
  %l167 = alloca i1
  %l168 = alloca ptr
  %l169 = alloca ptr
  %l170 = alloca { i64, ptr }
  %l171 = alloca ptr
  %l172 = alloca i32
  %l173 = alloca i32
  %l174 = alloca i1
  %l175 = alloca i32
  %l176 = alloca i32
  %l177 = alloca i64
  %l178 = alloca i1
  %l179 = alloca ptr
  %l180 = alloca i64
  %l181 = alloca i1
  %l182 = alloca i64
  %l183 = alloca i64
  %l184 = alloca i1
  %l185 = alloca i1
  %l186 = alloca i64
  %l187 = alloca i64
  %l188 = alloca i1
  %l189 = alloca i1
  %l190 = alloca ptr
  %l191 = alloca i64
  %l192 = alloca i64
  %l193 = alloca i1
  %l194 = alloca %"compiler/msgs:Msg"
  %l195 = alloca %"compiler/msgs:Msg"
  %l196 = alloca %"compiler/msgs:Msg"
  %l197 = alloca i32
  %l198 = alloca i32
  %l199 = alloca { i64, ptr }
  %l200 = alloca { i64, ptr }
  %l201 = alloca { i64, ptr }
  %l202 = alloca i64
  %l203 = alloca i64
  %l204 = alloca i1
  %l205 = alloca i1
  %l206 = alloca { i64, ptr }
  %l207 = alloca i1
  %l208 = alloca i1
  %l209 = alloca { i64, ptr }
  %l210 = alloca i64
  %l211 = alloca i1
  %l212 = alloca ptr
  %l213 = alloca { i64, ptr }
  %l214 = alloca %"compiler/msgs:Msg"
  %l215 = alloca i32
  %l216 = alloca i32
  %l217 = alloca ptr
  %l218 = alloca { i64, ptr }
  %l219 = alloca %"compiler/msgs:Msg"
  %l220 = alloca i32
  %l221 = alloca i32
  %l222 = alloca ptr
  %l223 = alloca { i64, ptr }
  %l224 = alloca { i64, ptr }
  %l225 = alloca { i64, ptr }
  %l226 = alloca i64
  %l227 = alloca i64
  %l228 = alloca i1
  %l229 = alloca i1
  %l230 = alloca i64
  %l231 = alloca i64
  %l232 = alloca i1
  %l233 = alloca i64
  %l234 = alloca { i64, ptr }
  %l235 = alloca i64
  %l236 = alloca i1
  %l237 = alloca i1
  %l238 = alloca ptr
  %l239 = alloca { i64, ptr }
  %l240 = alloca i64
  %l241 = alloca { i64, ptr }
  %l242 = alloca { i64, ptr }
  %l243 = alloca { i64, ptr }
  %l244 = alloca i64
  %l245 = alloca i64
  %l246 = alloca %"compiler/olang:CommandLine"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.builder
  %s12room = alloca [64 x i8], align 8
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.builder
  %s15room = alloca [64 x i8], align 8
  %s16 = alloca %olang.builder
  %s16room = alloca [64 x i8], align 8
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.builder
  %s18room = alloca [64 x i8], align 8
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.builder
  %s23room = alloca [64 x i8], align 8
  %s24 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s30 = alloca %olang.builder
  %s30room = alloca [64 x i8], align 8
  %s31 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s33 = alloca %olang.builder
  %s33room = alloca [64 x i8], align 8
  %s34 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %s36 = alloca %olang.builder
  %s36room = alloca [64 x i8], align 8
  %rv = alloca { i32, %"compiler/olang:CommandLine" }
  store { i64, ptr } %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"compiler/olang:CommandLine" @compiler_2folang_3aCommandLine_2ector(ptr %v3)
  store %"compiler/olang:CommandLine" %t1, ptr %l15
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 96, i64 8)
  store ptr %t2, ptr %lp3
  %t3 = load %"compiler/olang:CommandLine", ptr %l15
  %t4 = load ptr, ptr %lp3
  store %"compiler/olang:CommandLine" %t3, ptr %t4
  %t5 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t5, ptr %l16
  %t6 = load { i64, ptr }, ptr %l16
  %t7 = extractvalue { i64, ptr } %t6, 0
  store i64 %t7, ptr %l17
  %t8 = load i64, ptr %l17
  %t9 = icmp slt i64 %t8, 2
  store i1 %t9, ptr %l18
  %t10 = load i1, ptr %l18
  br i1 %t10, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = load ptr, ptr %l2
  store ptr %t11, ptr %l19
  %t12 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eUsage(ptr %s1)
  store %"compiler/msgs:Msg" %t12, ptr %l20
  br label %bb4
bb3:
  br label %bb8
bb4:
  %t13 = load ptr, ptr %l19
  %t14 = load %"compiler/msgs:Msg", ptr %l20
  %t15 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s1, ptr %t13, %"compiler/msgs:Msg" %t14)
  store i32 %t15, ptr %l21
  %t16 = icmp ne i32 %t15, 0
  br i1 %t16, label %bb6, label %ok.17
ok.17:
  br label %bb5
bb5:
  br label %bb7
bb6:
  %t18 = load i32, ptr %l21
  %t19 = lshr i32 %t18, 16
  %t20 = and i32 %t18, 65535
  %t21 = icmp eq i32 %t19, 1
  %t22 = select i1 %t21, i32 1, i32 0
  %t23 = icmp eq i32 %t18, 0
  %t24 = shl i32 %t22, 16
  %t25 = or i32 %t24, %t20
  %t26 = select i1 %t23, i32 0, i32 %t25
  store i32 %t26, ptr %l22
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t27 = load i32, ptr %l22
  %t28 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t27, 0
  store { i32, %"compiler/olang:CommandLine" } %t28, ptr %rv
  br label %ret
bb7:
  call void @__olang_scope_close(ptr %s1)
  br label %bb8
bb8:
  store i64 1, ptr %l4
  %t29 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t29, ptr %l23
  %t30 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t31 = load ptr, ptr %t30
  %t32 = getelementptr { i64, ptr }, ptr %t31, i64 1
  %t33 = load { i64, ptr }, ptr %t32
  store { i64, ptr } %t33, ptr %l24
  %t34 = load { i64, ptr }, ptr %l24
  %t35 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t34, { i64, ptr } { i64 1, ptr @.d48 })
  store i1 %t35, ptr %l25
  br label %bb9
bb9:
  %t36 = load i1, ptr %l25
  %t37 = xor i1 %t36, true
  store i1 %t37, ptr %l26
  %t38 = load i1, ptr %l26
  br i1 %t38, label %bb10, label %bb11
bb10:
  %t39 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t39, ptr %l28
  %t40 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t41 = load ptr, ptr %t40
  %t42 = getelementptr { i64, ptr }, ptr %t41, i64 1
  %t43 = load { i64, ptr }, ptr %t42
  store { i64, ptr } %t43, ptr %l29
  %t44 = load { i64, ptr }, ptr %l29
  %t45 = call i1 @compiler_2folang_2eendsWithOlang(ptr %v0, { i64, ptr } %t44)
  store i1 %t45, ptr %l30
  br label %bb12
bb11:
  store i1 false, ptr %l27
  br label %bb13
bb12:
  %t46 = load i1, ptr %l30
  %t47 = xor i1 %t46, true
  store i1 %t47, ptr %l31
  %t48 = load i1, ptr %l31
  store i1 %t48, ptr %l27
  br label %bb13
bb13:
  %t49 = load i1, ptr %l27
  br i1 %t49, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s2
  %t50 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t50, ptr %l32
  %t51 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t52 = load ptr, ptr %t51
  %t53 = getelementptr { i64, ptr }, ptr %t52, i64 1
  %t54 = load { i64, ptr }, ptr %t53
  store { i64, ptr } %t54, ptr %l33
  %t55 = load { i64, ptr }, ptr %l33
  %t56 = call i64 @compiler_2folang_2emodeNumber(ptr %v0, { i64, ptr } %t55)
  store i64 %t56, ptr %l34
  br label %bb16
bb15:
  br label %bb24
bb16:
  %t57 = load i64, ptr %l34
  store i64 %t57, ptr %l5
  %t58 = load i64, ptr %l5
  store i64 %t58, ptr %l35
  %t59 = load i64, ptr %l35
  %t60 = icmp slt i64 %t59, 0
  store i1 %t60, ptr %l36
  %t61 = load i1, ptr %l36
  br i1 %t61, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s3
  %t62 = load ptr, ptr %l2
  store ptr %t62, ptr %l37
  %t63 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t63, ptr %l38
  %t64 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t65 = load ptr, ptr %t64
  %t66 = getelementptr { i64, ptr }, ptr %t65, i64 1
  %t67 = load { i64, ptr }, ptr %t66
  store { i64, ptr } %t67, ptr %l39
  %t68 = load { i64, ptr }, ptr %l39
  %t69 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotAMode(ptr %v0, ptr %s3, { i64, ptr } %t68)
  store %"compiler/msgs:Msg" %t69, ptr %l40
  br label %bb19
bb18:
  br label %bb23
bb19:
  %t70 = load ptr, ptr %l37
  %t71 = load %"compiler/msgs:Msg", ptr %l40
  %t72 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s3, ptr %t70, %"compiler/msgs:Msg" %t71)
  store i32 %t72, ptr %l41
  %t73 = icmp ne i32 %t72, 0
  br i1 %t73, label %bb21, label %ok.74
ok.74:
  br label %bb20
bb20:
  br label %bb22
bb21:
  %t75 = load i32, ptr %l41
  %t76 = lshr i32 %t75, 16
  %t77 = and i32 %t75, 65535
  %t78 = icmp eq i32 %t76, 1
  %t79 = select i1 %t78, i32 1, i32 0
  %t80 = icmp eq i32 %t75, 0
  %t81 = shl i32 %t79, 16
  %t82 = or i32 %t81, %t77
  %t83 = select i1 %t80, i32 0, i32 %t82
  store i32 %t83, ptr %l42
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t84 = load i32, ptr %l42
  %t85 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t84, 0
  store { i32, %"compiler/olang:CommandLine" } %t85, ptr %rv
  br label %ret
bb22:
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb23:
  %t86 = load i64, ptr %l5
  store i64 %t86, ptr %l43
  %t87 = load i64, ptr %l43
  %t88 = load ptr, ptr %lp3
  %t89 = getelementptr %"compiler/olang:CommandLine", ptr %t88, i32 0, i32 0
  store i64 %t87, ptr %t89
  store i64 2, ptr %l4
  call void @__olang_scope_close(ptr %s2)
  br label %bb24
bb24:
  br label %bb25
bb25:
  store %olang.scope zeroinitializer, ptr %s4
  %t90 = load i64, ptr %l4
  store i64 %t90, ptr %l44
  %t91 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t91, ptr %l45
  %t92 = load { i64, ptr }, ptr %l45
  %t93 = extractvalue { i64, ptr } %t92, 0
  store i64 %t93, ptr %l46
  %t94 = load i64, ptr %l44
  %t95 = load i64, ptr %l46
  %t96 = icmp slt i64 %t94, %t95
  store i1 %t96, ptr %l47
  %t97 = load i1, ptr %l47
  %t98 = xor i1 %t97, true
  store i1 %t98, ptr %l48
  %t99 = load i1, ptr %l48
  br i1 %t99, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s4)
  br label %bb160
bb27:
  br label %bb28
bb28:
  %t100 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t100, ptr %l49
  %t101 = load i64, ptr %l4
  store i64 %t101, ptr %l50
  %t102 = load i64, ptr %l50
  %t103 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t104 = load ptr, ptr %t103
  %t105 = getelementptr { i64, ptr }, ptr %t104, i64 %t102
  %t106 = load { i64, ptr }, ptr %t105
  store { i64, ptr } %t106, ptr %l51
  %t107 = load { i64, ptr }, ptr %l51
  store { i64, ptr } %t107, ptr %l6
  %t108 = load i64, ptr %l4
  store i64 %t108, ptr %l52
  %t109 = load i64, ptr %l52
  %t110 = add i64 %t109, 1
  store i64 %t110, ptr %l53
  %t111 = load i64, ptr %l53
  store i64 %t111, ptr %l4
  %t112 = load { i64, ptr }, ptr %l6
  store { i64, ptr } %t112, ptr %l54
  %t113 = load { i64, ptr }, ptr %l54
  %t114 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s4, { i64, ptr } %t113, { i64, ptr } { i64 1, ptr @.d49 })
  store i1 %t114, ptr %l55
  br label %bb29
bb29:
  %t115 = load i1, ptr %l55
  br i1 %t115, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s5
  store i64 -1, ptr %l7
  store %olang.scope zeroinitializer, ptr %s6
  store i64 0, ptr %l8
  %t116 = load { i64, ptr }, ptr @G_2ecompiler_2folang_2eOptWords
  store { i64, ptr } %t116, ptr %l56
  %t117 = load { i64, ptr }, ptr %l56
  %t118 = extractvalue { i64, ptr } %t117, 0
  store i64 %t118, ptr %l57
  %t119 = load i64, ptr %l57
  store i64 %t119, ptr %l9
  store i64 1, ptr %l10
  %t120 = load i64, ptr %l9
  store i64 %t120, ptr %l58
  %t121 = load i64, ptr %l8
  store i64 %t121, ptr %l59
  %t122 = load i64, ptr %l58
  %t123 = load i64, ptr %l59
  %t124 = icmp sgt i64 %t122, %t123
  store i1 %t124, ptr %l60
  %t125 = load i1, ptr %l60
  br i1 %t125, label %bb32, label %bb33
bb31:
  br label %bb108
bb32:
  %t126 = load i64, ptr %l10
  store i64 %t126, ptr %l62
  %t127 = load i64, ptr %l62
  %t128 = icmp sgt i64 %t127, 0
  store i1 %t128, ptr %l63
  %t129 = load i1, ptr %l63
  br i1 %t129, label %bb34, label %bb35
bb33:
  store i64 0, ptr %l61
  br label %bb37
bb34:
  %t130 = load i64, ptr %l9
  store i64 %t130, ptr %l65
  %t131 = load i64, ptr %l8
  store i64 %t131, ptr %l66
  %t132 = load i64, ptr %l65
  %t133 = load i64, ptr %l66
  %t134 = sub i64 %t132, %t133
  store i64 %t134, ptr %l67
  %t135 = load i64, ptr %l10
  store i64 %t135, ptr %l68
  %t136 = load i64, ptr %l67
  %t137 = load i64, ptr %l68
  %t138 = add i64 %t136, %t137
  store i64 %t138, ptr %l69
  %t139 = load i64, ptr %l69
  %t140 = sub i64 %t139, 1
  store i64 %t140, ptr %l70
  %t141 = load i64, ptr %l10
  store i64 %t141, ptr %l71
  %t142 = load i64, ptr %l70
  %t143 = load i64, ptr %l71
  %t144 = sdiv i64 %t142, %t143
  store i64 %t144, ptr %l72
  %t145 = load i64, ptr %l72
  store i64 %t145, ptr %l64
  br label %bb36
bb35:
  store i64 0, ptr %l64
  br label %bb36
bb36:
  %t146 = load i64, ptr %l64
  store i64 %t146, ptr %l61
  br label %bb37
bb37:
  %t147 = load i64, ptr %l61
  store i64 %t147, ptr %l11
  store i64 0, ptr %l12
  br label %bb38
bb38:
  store %olang.scope zeroinitializer, ptr %s7
  %t148 = load i64, ptr %l12
  store i64 %t148, ptr %l73
  %t149 = load i64, ptr %l11
  store i64 %t149, ptr %l74
  %t150 = load i64, ptr %l73
  %t151 = load i64, ptr %l74
  %t152 = icmp slt i64 %t150, %t151
  store i1 %t152, ptr %l75
  %t153 = load i1, ptr %l75
  %t154 = xor i1 %t153, true
  store i1 %t154, ptr %l76
  %t155 = load i1, ptr %l76
  br i1 %t155, label %bb39, label %bb40
bb39:
  call void @__olang_scope_close(ptr %s7)
  br label %bb47
bb40:
  br label %bb41
bb41:
  %t156 = load i64, ptr %l8
  store i64 %t156, ptr %l77
  %t157 = load i64, ptr %l12
  store i64 %t157, ptr %l78
  %t158 = load i64, ptr %l10
  store i64 %t158, ptr %l79
  %t159 = load i64, ptr %l78
  %t160 = load i64, ptr %l79
  %t161 = mul i64 %t159, %t160
  store i64 %t161, ptr %l80
  %t162 = load i64, ptr %l77
  %t163 = load i64, ptr %l80
  %t164 = add i64 %t162, %t163
  store i64 %t164, ptr %l81
  %t165 = load i64, ptr %l81
  store i64 %t165, ptr %l13
  %t166 = load i64, ptr %l13
  store i64 %t166, ptr %l82
  %t167 = load i64, ptr %l82
  %t168 = getelementptr { i64, ptr }, ptr @G_2ecompiler_2folang_2eOptWords, i32 0, i32 1
  %t169 = load ptr, ptr %t168
  %t170 = getelementptr { i64, ptr }, ptr %t169, i64 %t167
  %t171 = load { i64, ptr }, ptr %t170
  store { i64, ptr } %t171, ptr %l83
  %t172 = load { i64, ptr }, ptr %l6
  store { i64, ptr } %t172, ptr %l84
  %t173 = load ptr, ptr @__olang_prog_scope
  %t174 = load { i64, ptr }, ptr %l83
  %t175 = load { i64, ptr }, ptr %l84
  %t176 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t173, ptr %v0, { i64, ptr } %t174, { i64, ptr } %t175)
  store i1 %t176, ptr %l85
  br label %bb42
bb42:
  %t177 = load i1, ptr %l85
  br i1 %t177, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s8
  %t178 = load i64, ptr %l13
  store i64 %t178, ptr %l86
  %t179 = load i64, ptr %l86
  store i64 %t179, ptr %l7
  call void @__olang_scope_close(ptr %s8)
  br label %bb45
bb44:
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s7)
  br label %bb46
bb46:
  store %olang.scope zeroinitializer, ptr %s9
  %t180 = load i64, ptr %l12
  store i64 %t180, ptr %l87
  %t181 = load i64, ptr %l87
  %t182 = add i64 %t181, 1
  store i64 %t182, ptr %l88
  %t183 = load i64, ptr %l88
  store i64 %t183, ptr %l12
  call void @__olang_scope_close(ptr %s9)
  br label %bb38
bb47:
  call void @__olang_scope_close(ptr %s6)
  %t184 = load i64, ptr %l7
  store i64 %t184, ptr %l89
  %t185 = load i64, ptr %l89
  %t186 = icmp slt i64 %t185, 0
  store i1 %t186, ptr %l90
  %t187 = load i1, ptr %l90
  br i1 %t187, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s10
  %t188 = load ptr, ptr %l2
  store ptr %t188, ptr %l91
  %t189 = load { i64, ptr }, ptr %l6
  store { i64, ptr } %t189, ptr %l92
  %t190 = load ptr, ptr %lp3
  %t191 = getelementptr %"compiler/olang:CommandLine", ptr %t190, i32 0, i32 0
  %t192 = load i64, ptr %t191
  store i64 %t192, ptr %l93
  %t193 = load i64, ptr %l93
  %t194 = call { i64, ptr } @compiler_2folang_2emodeName(ptr %s10, i64 %t193)
  store { i64, ptr } %t194, ptr %l94
  br label %bb50
bb49:
  br label %bb55
bb50:
  %t195 = load { i64, ptr }, ptr %l94
  %t196 = extractvalue { i64, ptr } %t195, 0
  %t197 = extractvalue { i64, ptr } %t195, 1
  %t198 = mul i64 %t196, 1
  %t199 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t198)
  call void @llvm.memcpy.p0.p0.i64(ptr %t199, ptr %t197, i64 %t198, i1 false)
  %t200 = insertvalue { i64, ptr } undef, i64 %t196, 0
  %t201 = insertvalue { i64, ptr } %t200, ptr %t199, 1
  store { i64, ptr } %t201, ptr %l95
  %t202 = load { i64, ptr }, ptr %l92
  %t203 = load { i64, ptr }, ptr %l95
  %t204 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownFlag(ptr %v0, ptr %s10, ptr %s10, { i64, ptr } %t202, { i64, ptr } %t203)
  store %"compiler/msgs:Msg" %t204, ptr %l96
  br label %bb51
bb51:
  %t205 = load ptr, ptr %l91
  %t206 = load %"compiler/msgs:Msg", ptr %l96
  %t207 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s10, ptr %t205, %"compiler/msgs:Msg" %t206)
  store i32 %t207, ptr %l97
  %t208 = icmp ne i32 %t207, 0
  br i1 %t208, label %bb53, label %ok.209
ok.209:
  br label %bb52
bb52:
  br label %bb54
bb53:
  %t210 = load i32, ptr %l97
  %t211 = lshr i32 %t210, 16
  %t212 = and i32 %t210, 65535
  %t213 = icmp eq i32 %t211, 1
  %t214 = select i1 %t213, i32 1, i32 0
  %t215 = icmp eq i32 %t210, 0
  %t216 = shl i32 %t214, 16
  %t217 = or i32 %t216, %t212
  %t218 = select i1 %t215, i32 0, i32 %t217
  store i32 %t218, ptr %l98
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t219 = load i32, ptr %l98
  %t220 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t219, 0
  store { i32, %"compiler/olang:CommandLine" } %t220, ptr %rv
  br label %ret
bb54:
  call void @__olang_scope_close(ptr %s10)
  br label %bb55
bb55:
  %t221 = load i64, ptr %l7
  store i64 %t221, ptr %l99
  %t222 = load i64, ptr %l99
  %t223 = getelementptr { i64, ptr }, ptr @G_2ecompiler_2folang_2eOptModes, i32 0, i32 1
  %t224 = load ptr, ptr %t223
  %t225 = getelementptr i64, ptr %t224, i64 %t222
  %t226 = load i64, ptr %t225
  store i64 %t226, ptr %l100
  %t227 = load ptr, ptr %lp3
  %t228 = getelementptr %"compiler/olang:CommandLine", ptr %t227, i32 0, i32 0
  %t229 = load i64, ptr %t228
  store i64 %t229, ptr %l101
  %t230 = load i64, ptr %l100
  %t231 = load i64, ptr %l101
  %t232 = load i64, ptr %l101
  %t233 = ashr i64 %t230, %t232
  store i64 %t233, ptr %l102
  %t234 = load i64, ptr %l102
  %t235 = and i64 %t234, 1
  store i64 %t235, ptr %l103
  %t236 = load i64, ptr %l103
  %t237 = icmp eq i64 %t236, 0
  store i1 %t237, ptr %l104
  %t238 = load i1, ptr %l104
  br i1 %t238, label %bb56, label %bb57
bb56:
  store %olang.scope zeroinitializer, ptr %s11
  %t239 = load ptr, ptr %l2
  store ptr %t239, ptr %l105
  %t240 = load { i64, ptr }, ptr %l6
  store { i64, ptr } %t240, ptr %l106
  %t241 = load i64, ptr %l7
  store i64 %t241, ptr %l107
  %t242 = load i64, ptr %l107
  %t243 = getelementptr { i64, ptr }, ptr @G_2ecompiler_2folang_2eOptModes, i32 0, i32 1
  %t244 = load ptr, ptr %t243
  %t245 = getelementptr i64, ptr %t244, i64 %t242
  %t246 = load i64, ptr %t245
  store i64 %t246, ptr %l108
  %t247 = load i64, ptr %l108
  %t248 = call { i64, ptr } @compiler_2folang_2emodesOf(ptr %s11, i64 %t247)
  store { i64, ptr } %t248, ptr %l109
  br label %bb58
bb57:
  br label %bb64
bb58:
  %t249 = load { i64, ptr }, ptr %l109
  %t250 = extractvalue { i64, ptr } %t249, 0
  %t251 = extractvalue { i64, ptr } %t249, 1
  %t252 = mul i64 %t250, 1
  %t253 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t252)
  call void @llvm.memcpy.p0.p0.i64(ptr %t253, ptr %t251, i64 %t252, i1 false)
  %t254 = insertvalue { i64, ptr } undef, i64 %t250, 0
  %t255 = insertvalue { i64, ptr } %t254, ptr %t253, 1
  store { i64, ptr } %t255, ptr %l110
  %t256 = load ptr, ptr %lp3
  %t257 = getelementptr %"compiler/olang:CommandLine", ptr %t256, i32 0, i32 0
  %t258 = load i64, ptr %t257
  store i64 %t258, ptr %l111
  %t259 = load i64, ptr %l111
  %t260 = call { i64, ptr } @compiler_2folang_2emodeName(ptr %s11, i64 %t259)
  store { i64, ptr } %t260, ptr %l112
  br label %bb59
bb59:
  %t261 = load { i64, ptr }, ptr %l112
  %t262 = extractvalue { i64, ptr } %t261, 0
  %t263 = extractvalue { i64, ptr } %t261, 1
  %t264 = mul i64 %t262, 1
  %t265 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t264)
  call void @llvm.memcpy.p0.p0.i64(ptr %t265, ptr %t263, i64 %t264, i1 false)
  %t266 = insertvalue { i64, ptr } undef, i64 %t262, 0
  %t267 = insertvalue { i64, ptr } %t266, ptr %t265, 1
  store { i64, ptr } %t267, ptr %l113
  %t268 = load { i64, ptr }, ptr %l106
  %t269 = load { i64, ptr }, ptr %l110
  %t270 = load { i64, ptr }, ptr %l113
  %t271 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eOptionNotForMode(ptr %v0, ptr %s11, ptr %s11, ptr %s11, { i64, ptr } %t268, { i64, ptr } %t269, { i64, ptr } %t270)
  store %"compiler/msgs:Msg" %t271, ptr %l114
  br label %bb60
bb60:
  %t272 = load ptr, ptr %l105
  %t273 = load %"compiler/msgs:Msg", ptr %l114
  %t274 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s11, ptr %t272, %"compiler/msgs:Msg" %t273)
  store i32 %t274, ptr %l115
  %t275 = icmp ne i32 %t274, 0
  br i1 %t275, label %bb62, label %ok.276
ok.276:
  br label %bb61
bb61:
  br label %bb63
bb62:
  %t277 = load i32, ptr %l115
  %t278 = lshr i32 %t277, 16
  %t279 = and i32 %t277, 65535
  %t280 = icmp eq i32 %t278, 1
  %t281 = select i1 %t280, i32 1, i32 0
  %t282 = icmp eq i32 %t277, 0
  %t283 = shl i32 %t281, 16
  %t284 = or i32 %t283, %t279
  %t285 = select i1 %t282, i32 0, i32 %t284
  store i32 %t285, ptr %l116
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t286 = load i32, ptr %l116
  %t287 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t286, 0
  store { i32, %"compiler/olang:CommandLine" } %t287, ptr %rv
  br label %ret
bb63:
  call void @__olang_scope_close(ptr %s11)
  br label %bb64
bb64:
  %t288 = load ptr, ptr %lp3
  %t289 = getelementptr %"compiler/olang:CommandLine", ptr %t288, i32 0, i32 5
  store ptr %t289, ptr %l117
  %t290 = load { i64, ptr }, ptr %l6
  store { i64, ptr } %t290, ptr %l118
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s12
  store ptr %s12room, ptr %s12
  %t291 = load { i64, ptr }, ptr %l118
  %t292 = extractvalue { i64, ptr } %t291, 1
  %t293 = extractvalue { i64, ptr } %t291, 0
  call void @__olang_sb_put(ptr %s12, ptr %t292, i64 %t293)
  %t294 = load ptr, ptr %s12
  %t295 = getelementptr %olang.builder, ptr %s12, i32 0, i32 1
  %t296 = load i64, ptr %t295
  %t297 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t296)
  call void @llvm.memcpy.p0.p0.i64(ptr %t297, ptr %t294, i64 %t296, i1 false)
  %t298 = insertvalue { i64, ptr } undef, i64 %t296, 0
  %t299 = insertvalue { i64, ptr } %t298, ptr %t297, 1
  store { i64, ptr } %t299, ptr %l119
  call void @__olang_sb_done(ptr %s12)
  %t300 = load { i64, ptr }, ptr %l119
  %t301 = extractvalue { i64, ptr } %t300, 0
  %t302 = extractvalue { i64, ptr } %t300, 1
  %t303 = mul i64 %t301, 1
  %t304 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t303)
  call void @llvm.memcpy.p0.p0.i64(ptr %t304, ptr %t302, i64 %t303, i1 false)
  %t305 = insertvalue { i64, ptr } undef, i64 %t301, 0
  %t306 = insertvalue { i64, ptr } %t305, ptr %t304, 1
  store { i64, ptr } %t306, ptr %l120
  %t307 = load ptr, ptr %l117
  %t308 = load { i64, ptr }, ptr %l120
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v3, ptr %v3, ptr %t307, { i64, ptr } %t308)
  br label %bb65
bb65:
  store { i64, ptr } { i64 0, ptr @.d50 }, ptr %l14
  %t309 = load i64, ptr %l7
  store i64 %t309, ptr %l121
  %t310 = load i64, ptr %l121
  %t311 = getelementptr { i64, ptr }, ptr @G_2ecompiler_2folang_2eOptValues, i32 0, i32 1
  %t312 = load ptr, ptr %t311
  %t313 = getelementptr { i64, ptr }, ptr %t312, i64 %t310
  %t314 = load { i64, ptr }, ptr %t313
  store { i64, ptr } %t314, ptr %l122
  %t315 = load ptr, ptr @__olang_prog_scope
  %t316 = load { i64, ptr }, ptr %l122
  %t317 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t315, ptr %s5, { i64, ptr } %t316, { i64, ptr } { i64 0, ptr @.d51 })
  store i1 %t317, ptr %l123
  br label %bb66
bb66:
  %t318 = load i1, ptr %l123
  %t319 = xor i1 %t318, true
  store i1 %t319, ptr %l124
  %t320 = load i1, ptr %l124
  br i1 %t320, label %bb67, label %bb68
bb67:
  store %olang.scope zeroinitializer, ptr %s13
  %t321 = load i64, ptr %l4
  store i64 %t321, ptr %l125
  %t322 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t322, ptr %l126
  %t323 = load { i64, ptr }, ptr %l126
  %t324 = extractvalue { i64, ptr } %t323, 0
  store i64 %t324, ptr %l127
  %t325 = load i64, ptr %l125
  %t326 = load i64, ptr %l127
  %t327 = icmp sge i64 %t325, %t326
  store i1 %t327, ptr %l128
  %t328 = load i1, ptr %l128
  br i1 %t328, label %bb69, label %bb70
bb68:
  br label %bb77
bb69:
  store %olang.scope zeroinitializer, ptr %s14
  %t329 = load ptr, ptr %l2
  store ptr %t329, ptr %l129
  %t330 = load { i64, ptr }, ptr %l6
  store { i64, ptr } %t330, ptr %l130
  %t331 = load i64, ptr %l7
  store i64 %t331, ptr %l131
  %t332 = load i64, ptr %l131
  %t333 = getelementptr { i64, ptr }, ptr @G_2ecompiler_2folang_2eOptValues, i32 0, i32 1
  %t334 = load ptr, ptr %t333
  %t335 = getelementptr { i64, ptr }, ptr %t334, i64 %t332
  %t336 = load { i64, ptr }, ptr %t335
  store { i64, ptr } %t336, ptr %l132
  %t337 = load ptr, ptr @__olang_prog_scope
  %t338 = load { i64, ptr }, ptr %l130
  %t339 = load { i64, ptr }, ptr %l132
  %t340 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eOptionNeedsValue(ptr %v0, ptr %t337, ptr %s14, { i64, ptr } %t338, { i64, ptr } %t339)
  store %"compiler/msgs:Msg" %t340, ptr %l133
  br label %bb71
bb70:
  br label %bb75
bb71:
  %t341 = load ptr, ptr %l129
  %t342 = load %"compiler/msgs:Msg", ptr %l133
  %t343 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s14, ptr %t341, %"compiler/msgs:Msg" %t342)
  store i32 %t343, ptr %l134
  %t344 = icmp ne i32 %t343, 0
  br i1 %t344, label %bb73, label %ok.345
ok.345:
  br label %bb72
bb72:
  br label %bb74
bb73:
  %t346 = load i32, ptr %l134
  %t347 = lshr i32 %t346, 16
  %t348 = and i32 %t346, 65535
  %t349 = icmp eq i32 %t347, 1
  %t350 = select i1 %t349, i32 1, i32 0
  %t351 = icmp eq i32 %t346, 0
  %t352 = shl i32 %t350, 16
  %t353 = or i32 %t352, %t348
  %t354 = select i1 %t351, i32 0, i32 %t353
  store i32 %t354, ptr %l135
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t355 = load i32, ptr %l135
  %t356 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t355, 0
  store { i32, %"compiler/olang:CommandLine" } %t356, ptr %rv
  br label %ret
bb74:
  call void @__olang_scope_close(ptr %s14)
  br label %bb75
bb75:
  %t357 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t357, ptr %l136
  %t358 = load i64, ptr %l4
  store i64 %t358, ptr %l137
  %t359 = load i64, ptr %l137
  %t360 = getelementptr { i64, ptr }, ptr %l136, i32 0, i32 1
  %t361 = load ptr, ptr %t360
  %t362 = getelementptr { i64, ptr }, ptr %t361, i64 %t359
  %t363 = load { i64, ptr }, ptr %t362
  store { i64, ptr } %t363, ptr %l138
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s15
  store ptr %s15room, ptr %s15
  %t364 = load { i64, ptr }, ptr %l138
  %t365 = extractvalue { i64, ptr } %t364, 1
  %t366 = extractvalue { i64, ptr } %t364, 0
  call void @__olang_sb_put(ptr %s15, ptr %t365, i64 %t366)
  %t367 = load ptr, ptr %s15
  %t368 = getelementptr %olang.builder, ptr %s15, i32 0, i32 1
  %t369 = load i64, ptr %t368
  %t370 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t369)
  call void @llvm.memcpy.p0.p0.i64(ptr %t370, ptr %t367, i64 %t369, i1 false)
  %t371 = insertvalue { i64, ptr } undef, i64 %t369, 0
  %t372 = insertvalue { i64, ptr } %t371, ptr %t370, 1
  store { i64, ptr } %t372, ptr %l139
  call void @__olang_sb_done(ptr %s15)
  %t373 = load { i64, ptr }, ptr %l139
  %t374 = extractvalue { i64, ptr } %t373, 0
  %t375 = extractvalue { i64, ptr } %t373, 1
  %t376 = mul i64 %t374, 1
  %t377 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t376)
  call void @llvm.memcpy.p0.p0.i64(ptr %t377, ptr %t375, i64 %t376, i1 false)
  %t378 = insertvalue { i64, ptr } undef, i64 %t374, 0
  %t379 = insertvalue { i64, ptr } %t378, ptr %t377, 1
  store { i64, ptr } %t379, ptr %l140
  %t380 = load { i64, ptr }, ptr %l140
  store { i64, ptr } %t380, ptr %l14
  %t381 = load i64, ptr %l4
  store i64 %t381, ptr %l141
  %t382 = load i64, ptr %l141
  %t383 = add i64 %t382, 1
  store i64 %t383, ptr %l142
  %t384 = load i64, ptr %l142
  store i64 %t384, ptr %l4
  %t385 = load ptr, ptr %lp3
  %t386 = getelementptr %"compiler/olang:CommandLine", ptr %t385, i32 0, i32 5
  store ptr %t386, ptr %l143
  %t387 = load { i64, ptr }, ptr %l14
  store { i64, ptr } %t387, ptr %l144
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s16
  store ptr %s16room, ptr %s16
  %t388 = load { i64, ptr }, ptr %l144
  %t389 = extractvalue { i64, ptr } %t388, 1
  %t390 = extractvalue { i64, ptr } %t388, 0
  call void @__olang_sb_put(ptr %s16, ptr %t389, i64 %t390)
  %t391 = load ptr, ptr %s16
  %t392 = getelementptr %olang.builder, ptr %s16, i32 0, i32 1
  %t393 = load i64, ptr %t392
  %t394 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t393)
  call void @llvm.memcpy.p0.p0.i64(ptr %t394, ptr %t391, i64 %t393, i1 false)
  %t395 = insertvalue { i64, ptr } undef, i64 %t393, 0
  %t396 = insertvalue { i64, ptr } %t395, ptr %t394, 1
  store { i64, ptr } %t396, ptr %l145
  call void @__olang_sb_done(ptr %s16)
  %t397 = load { i64, ptr }, ptr %l145
  %t398 = extractvalue { i64, ptr } %t397, 0
  %t399 = extractvalue { i64, ptr } %t397, 1
  %t400 = mul i64 %t398, 1
  %t401 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t400)
  call void @llvm.memcpy.p0.p0.i64(ptr %t401, ptr %t399, i64 %t400, i1 false)
  %t402 = insertvalue { i64, ptr } undef, i64 %t398, 0
  %t403 = insertvalue { i64, ptr } %t402, ptr %t401, 1
  store { i64, ptr } %t403, ptr %l146
  %t404 = load ptr, ptr %l143
  %t405 = load { i64, ptr }, ptr %l146
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v3, ptr %v3, ptr %t404, { i64, ptr } %t405)
  br label %bb76
bb76:
  call void @__olang_scope_close(ptr %s13)
  br label %bb77
bb77:
  %t406 = load i64, ptr %l7
  store i64 %t406, ptr %l147
  %t407 = load i64, ptr %l147
  %t408 = icmp eq i64 %t407, 0
  store i1 %t408, ptr %l148
  %t409 = load i1, ptr %l148
  br i1 %t409, label %bb78, label %bb79
bb78:
  store %olang.scope zeroinitializer, ptr %s17
  %t410 = load { i64, ptr }, ptr %l14
  store { i64, ptr } %t410, ptr %l149
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s18
  store ptr %s18room, ptr %s18
  %t411 = load { i64, ptr }, ptr %l149
  %t412 = extractvalue { i64, ptr } %t411, 1
  %t413 = extractvalue { i64, ptr } %t411, 0
  call void @__olang_sb_put(ptr %s18, ptr %t412, i64 %t413)
  %t414 = load ptr, ptr %s18
  %t415 = getelementptr %olang.builder, ptr %s18, i32 0, i32 1
  %t416 = load i64, ptr %t415
  %t417 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t416)
  call void @llvm.memcpy.p0.p0.i64(ptr %t417, ptr %t414, i64 %t416, i1 false)
  %t418 = insertvalue { i64, ptr } undef, i64 %t416, 0
  %t419 = insertvalue { i64, ptr } %t418, ptr %t417, 1
  store { i64, ptr } %t419, ptr %l150
  call void @__olang_sb_done(ptr %s18)
  %t420 = load { i64, ptr }, ptr %l150
  %t421 = extractvalue { i64, ptr } %t420, 0
  %t422 = extractvalue { i64, ptr } %t420, 1
  %t423 = mul i64 %t421, 1
  %t424 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t423)
  call void @llvm.memcpy.p0.p0.i64(ptr %t424, ptr %t422, i64 %t423, i1 false)
  %t425 = insertvalue { i64, ptr } undef, i64 %t421, 0
  %t426 = insertvalue { i64, ptr } %t425, ptr %t424, 1
  store { i64, ptr } %t426, ptr %l151
  %t427 = load { i64, ptr }, ptr %l151
  %t428 = load ptr, ptr %lp3
  %t429 = getelementptr %"compiler/olang:CommandLine", ptr %t428, i32 0, i32 7
  store { i64, ptr } %t427, ptr %t429
  call void @__olang_scope_close(ptr %s17)
  br label %bb80
bb79:
  br label %bb80
bb80:
  %t430 = load i64, ptr %l7
  store i64 %t430, ptr %l152
  %t431 = load i64, ptr %l152
  %t432 = icmp eq i64 %t431, 1
  store i1 %t432, ptr %l153
  %t433 = load i1, ptr %l153
  br i1 %t433, label %bb81, label %bb82
bb81:
  store %olang.scope zeroinitializer, ptr %s19
  %t434 = load ptr, ptr %l1
  store ptr %t434, ptr %l154
  %t435 = load ptr, ptr %l154
  %t436 = getelementptr %"compiler/build:Config", ptr %t435, i32 0, i32 4
  store i1 true, ptr %t436
  call void @__olang_scope_close(ptr %s19)
  br label %bb83
bb82:
  br label %bb83
bb83:
  %t437 = load i64, ptr %l7
  store i64 %t437, ptr %l155
  %t438 = load i64, ptr %l155
  %t439 = icmp eq i64 %t438, 2
  store i1 %t439, ptr %l156
  %t440 = load i1, ptr %l156
  br i1 %t440, label %bb84, label %bb85
bb84:
  store %olang.scope zeroinitializer, ptr %s20
  %t441 = load ptr, ptr %l1
  store ptr %t441, ptr %l157
  %t442 = load ptr, ptr %l157
  %t443 = getelementptr %"compiler/build:Config", ptr %t442, i32 0, i32 5
  store i1 true, ptr %t443
  call void @__olang_scope_close(ptr %s20)
  br label %bb86
bb85:
  br label %bb86
bb86:
  %t444 = load i64, ptr %l7
  store i64 %t444, ptr %l158
  %t445 = load i64, ptr %l158
  %t446 = icmp eq i64 %t445, 3
  store i1 %t446, ptr %l159
  %t447 = load i1, ptr %l159
  br i1 %t447, label %bb87, label %bb88
bb87:
  store %olang.scope zeroinitializer, ptr %s21
  %t448 = load ptr, ptr %l1
  store ptr %t448, ptr %l160
  %t449 = load ptr, ptr %l160
  %t450 = getelementptr %"compiler/build:Config", ptr %t449, i32 0, i32 6
  store i1 true, ptr %t450
  call void @__olang_scope_close(ptr %s21)
  br label %bb89
bb88:
  br label %bb89
bb89:
  %t451 = load i64, ptr %l7
  store i64 %t451, ptr %l161
  %t452 = load i64, ptr %l161
  %t453 = icmp eq i64 %t452, 4
  store i1 %t453, ptr %l162
  %t454 = load i1, ptr %l162
  br i1 %t454, label %bb90, label %bb91
bb90:
  store %olang.scope zeroinitializer, ptr %s22
  %t455 = load { i64, ptr }, ptr %l14
  store { i64, ptr } %t455, ptr %l163
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s23
  store ptr %s23room, ptr %s23
  %t456 = load { i64, ptr }, ptr %l163
  %t457 = extractvalue { i64, ptr } %t456, 1
  %t458 = extractvalue { i64, ptr } %t456, 0
  call void @__olang_sb_put(ptr %s23, ptr %t457, i64 %t458)
  %t459 = load ptr, ptr %s23
  %t460 = getelementptr %olang.builder, ptr %s23, i32 0, i32 1
  %t461 = load i64, ptr %t460
  %t462 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t461)
  call void @llvm.memcpy.p0.p0.i64(ptr %t462, ptr %t459, i64 %t461, i1 false)
  %t463 = insertvalue { i64, ptr } undef, i64 %t461, 0
  %t464 = insertvalue { i64, ptr } %t463, ptr %t462, 1
  store { i64, ptr } %t464, ptr %l164
  call void @__olang_sb_done(ptr %s23)
  %t465 = load { i64, ptr }, ptr %l164
  %t466 = extractvalue { i64, ptr } %t465, 0
  %t467 = extractvalue { i64, ptr } %t465, 1
  %t468 = mul i64 %t466, 1
  %t469 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t468)
  call void @llvm.memcpy.p0.p0.i64(ptr %t469, ptr %t467, i64 %t468, i1 false)
  %t470 = insertvalue { i64, ptr } undef, i64 %t466, 0
  %t471 = insertvalue { i64, ptr } %t470, ptr %t469, 1
  store { i64, ptr } %t471, ptr %l165
  %t472 = load { i64, ptr }, ptr %l165
  %t473 = load ptr, ptr %lp3
  %t474 = getelementptr %"compiler/olang:CommandLine", ptr %t473, i32 0, i32 6
  store { i64, ptr } %t472, ptr %t474
  call void @__olang_scope_close(ptr %s22)
  br label %bb92
bb91:
  br label %bb92
bb92:
  %t475 = load i64, ptr %l7
  store i64 %t475, ptr %l166
  %t476 = load i64, ptr %l166
  %t477 = icmp eq i64 %t476, 5
  store i1 %t477, ptr %l167
  %t478 = load i1, ptr %l167
  br i1 %t478, label %bb93, label %bb94
bb93:
  store %olang.scope zeroinitializer, ptr %s24
  %t479 = load ptr, ptr %l1
  store ptr %t479, ptr %l168
  %t480 = load ptr, ptr %l168
  %t481 = getelementptr %"compiler/build:Config", ptr %t480, i32 0, i32 3
  store ptr %t481, ptr %l169
  %t482 = load { i64, ptr }, ptr %l14
  store { i64, ptr } %t482, ptr %l170
  %t483 = load ptr, ptr %l2
  store ptr %t483, ptr %l171
  %t484 = load ptr, ptr %l169
  %t485 = load { i64, ptr }, ptr %l170
  %t486 = load ptr, ptr %l171
  %t487 = call i32 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eDefine(ptr %v1, ptr %s5, ptr %v2, ptr %t484, { i64, ptr } %t485, ptr %t486)
  store i32 %t487, ptr %l172
  %t488 = icmp ne i32 %t487, 0
  br i1 %t488, label %bb96, label %ok.489
ok.489:
  br label %bb95
bb94:
  br label %bb101
bb95:
  br label %bb100
bb96:
  %t490 = load i32, ptr %l172
  %t491 = ashr i32 %t490, 16
  store i32 %t491, ptr %l173
  %t492 = load i32, ptr %l173
  %t493 = icmp eq i32 %t492, 1
  store i1 %t493, ptr %l174
  %t494 = load i1, ptr %l174
  br i1 %t494, label %bb97, label %bb98
bb97:
  br label %bb99
bb98:
  %t495 = load i32, ptr %l172
  %t496 = lshr i32 %t495, 16
  %t497 = and i32 %t495, 65535
  %t498 = icmp eq i32 %t496, 1
  %t499 = select i1 %t498, i32 0, i32 0
  %t500 = icmp eq i32 %t495, 0
  %t501 = shl i32 %t499, 16
  %t502 = or i32 %t501, %t497
  %t503 = select i1 %t500, i32 0, i32 %t502
  store i32 %t503, ptr %l175
  call void @__olang_scope_close(ptr %s24)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t504 = load i32, ptr %l175
  %t505 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t504, 0
  store { i32, %"compiler/olang:CommandLine" } %t505, ptr %rv
  br label %ret
bb99:
  store %olang.scope zeroinitializer, ptr %s25
  store i32 65536, ptr %l176
  call void @__olang_scope_close(ptr %s25)
  call void @__olang_scope_close(ptr %s24)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t506 = load i32, ptr %l176
  %t507 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t506, 0
  store { i32, %"compiler/olang:CommandLine" } %t507, ptr %rv
  br label %ret
bb100:
  call void @__olang_scope_close(ptr %s24)
  br label %bb101
bb101:
  %t508 = load i64, ptr %l7
  store i64 %t508, ptr %l177
  %t509 = load i64, ptr %l177
  %t510 = icmp eq i64 %t509, 6
  store i1 %t510, ptr %l178
  %t511 = load i1, ptr %l178
  br i1 %t511, label %bb102, label %bb103
bb102:
  store %olang.scope zeroinitializer, ptr %s26
  %t512 = load ptr, ptr %l1
  store ptr %t512, ptr %l179
  %t513 = load ptr, ptr %l179
  %t514 = getelementptr %"compiler/build:Config", ptr %t513, i32 0, i32 7
  store i1 true, ptr %t514
  call void @__olang_scope_close(ptr %s26)
  br label %bb104
bb103:
  br label %bb104
bb104:
  %t515 = load i64, ptr %l7
  store i64 %t515, ptr %l180
  %t516 = load i64, ptr %l180
  %t517 = icmp eq i64 %t516, 7
  store i1 %t517, ptr %l181
  %t518 = load i1, ptr %l181
  br i1 %t518, label %bb105, label %bb106
bb105:
  store %olang.scope zeroinitializer, ptr %s27
  %t519 = load ptr, ptr %lp3
  %t520 = getelementptr %"compiler/olang:CommandLine", ptr %t519, i32 0, i32 8
  store i1 true, ptr %t520
  call void @__olang_scope_close(ptr %s27)
  br label %bb107
bb106:
  br label %bb107
bb107:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  br label %bb159
bb108:
  %t521 = load ptr, ptr %lp3
  %t522 = getelementptr %"compiler/olang:CommandLine", ptr %t521, i32 0, i32 0
  %t523 = load i64, ptr %t522
  store i64 %t523, ptr %l182
  %t524 = load i64, ptr @G_2ecompiler_2folang_2eExplain
  store i64 %t524, ptr %l183
  %t525 = load i64, ptr %l182
  %t526 = load i64, ptr %l183
  %t527 = icmp eq i64 %t525, %t526
  store i1 %t527, ptr %l184
  %t528 = load i1, ptr %l184
  br i1 %t528, label %bb109, label %bb110
bb109:
  store i1 true, ptr %l185
  br label %bb111
bb110:
  %t529 = load ptr, ptr %lp3
  %t530 = getelementptr %"compiler/olang:CommandLine", ptr %t529, i32 0, i32 0
  %t531 = load i64, ptr %t530
  store i64 %t531, ptr %l186
  %t532 = load i64, ptr @G_2ecompiler_2folang_2eHelp
  store i64 %t532, ptr %l187
  %t533 = load i64, ptr %l186
  %t534 = load i64, ptr %l187
  %t535 = icmp eq i64 %t533, %t534
  store i1 %t535, ptr %l188
  %t536 = load i1, ptr %l188
  store i1 %t536, ptr %l185
  br label %bb111
bb111:
  %t537 = load i1, ptr %l185
  br i1 %t537, label %bb112, label %bb113
bb112:
  store %olang.scope zeroinitializer, ptr %s28
  %t538 = load ptr, ptr %lp3
  %t539 = getelementptr %"compiler/olang:CommandLine", ptr %t538, i32 0, i32 3
  %t540 = load i1, ptr %t539
  store i1 %t540, ptr %l189
  %t541 = load i1, ptr %l189
  br i1 %t541, label %bb114, label %bb115
bb113:
  br label %bb125
bb114:
  store %olang.scope zeroinitializer, ptr %s29
  %t542 = load ptr, ptr %l2
  store ptr %t542, ptr %l190
  %t543 = load ptr, ptr %lp3
  %t544 = getelementptr %"compiler/olang:CommandLine", ptr %t543, i32 0, i32 0
  %t545 = load i64, ptr %t544
  store i64 %t545, ptr %l191
  %t546 = load i64, ptr @G_2ecompiler_2folang_2eExplain
  store i64 %t546, ptr %l192
  %t547 = load i64, ptr %l191
  %t548 = load i64, ptr %l192
  %t549 = icmp eq i64 %t547, %t548
  store i1 %t549, ptr %l193
  %t550 = load i1, ptr %l193
  br i1 %t550, label %bb116, label %bb117
bb115:
  br label %bb124
bb116:
  %t551 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eExplainNeedsRule(ptr %s29)
  store %"compiler/msgs:Msg" %t551, ptr %l195
  br label %bb118
bb117:
  %t552 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eHelpOneMode(ptr %s29)
  store %"compiler/msgs:Msg" %t552, ptr %l196
  br label %bb119
bb118:
  %t553 = load %"compiler/msgs:Msg", ptr %l195
  store %"compiler/msgs:Msg" %t553, ptr %l194
  br label %bb120
bb119:
  %t554 = load %"compiler/msgs:Msg", ptr %l196
  store %"compiler/msgs:Msg" %t554, ptr %l194
  br label %bb120
bb120:
  %t555 = load ptr, ptr %l190
  %t556 = load %"compiler/msgs:Msg", ptr %l194
  %t557 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s29, ptr %t555, %"compiler/msgs:Msg" %t556)
  store i32 %t557, ptr %l197
  %t558 = icmp ne i32 %t557, 0
  br i1 %t558, label %bb122, label %ok.559
ok.559:
  br label %bb121
bb121:
  br label %bb123
bb122:
  %t560 = load i32, ptr %l197
  %t561 = lshr i32 %t560, 16
  %t562 = and i32 %t560, 65535
  %t563 = icmp eq i32 %t561, 1
  %t564 = select i1 %t563, i32 1, i32 0
  %t565 = icmp eq i32 %t560, 0
  %t566 = shl i32 %t564, 16
  %t567 = or i32 %t566, %t562
  %t568 = select i1 %t565, i32 0, i32 %t567
  store i32 %t568, ptr %l198
  call void @__olang_scope_close(ptr %s29)
  call void @__olang_scope_close(ptr %s28)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t569 = load i32, ptr %l198
  %t570 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t569, 0
  store { i32, %"compiler/olang:CommandLine" } %t570, ptr %rv
  br label %ret
bb123:
  call void @__olang_scope_close(ptr %s29)
  br label %bb124
bb124:
  %t571 = load { i64, ptr }, ptr %l6
  store { i64, ptr } %t571, ptr %l199
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s30
  store ptr %s30room, ptr %s30
  %t572 = load { i64, ptr }, ptr %l199
  %t573 = extractvalue { i64, ptr } %t572, 1
  %t574 = extractvalue { i64, ptr } %t572, 0
  call void @__olang_sb_put(ptr %s30, ptr %t573, i64 %t574)
  %t575 = load ptr, ptr %s30
  %t576 = getelementptr %olang.builder, ptr %s30, i32 0, i32 1
  %t577 = load i64, ptr %t576
  %t578 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t577)
  call void @llvm.memcpy.p0.p0.i64(ptr %t578, ptr %t575, i64 %t577, i1 false)
  %t579 = insertvalue { i64, ptr } undef, i64 %t577, 0
  %t580 = insertvalue { i64, ptr } %t579, ptr %t578, 1
  store { i64, ptr } %t580, ptr %l200
  call void @__olang_sb_done(ptr %s30)
  %t581 = load { i64, ptr }, ptr %l200
  %t582 = extractvalue { i64, ptr } %t581, 0
  %t583 = extractvalue { i64, ptr } %t581, 1
  %t584 = mul i64 %t582, 1
  %t585 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t584)
  call void @llvm.memcpy.p0.p0.i64(ptr %t585, ptr %t583, i64 %t584, i1 false)
  %t586 = insertvalue { i64, ptr } undef, i64 %t582, 0
  %t587 = insertvalue { i64, ptr } %t586, ptr %t585, 1
  store { i64, ptr } %t587, ptr %l201
  %t588 = load { i64, ptr }, ptr %l201
  %t589 = load ptr, ptr %lp3
  %t590 = getelementptr %"compiler/olang:CommandLine", ptr %t589, i32 0, i32 2
  store { i64, ptr } %t588, ptr %t590
  %t591 = load ptr, ptr %lp3
  %t592 = getelementptr %"compiler/olang:CommandLine", ptr %t591, i32 0, i32 3
  store i1 true, ptr %t592
  call void @__olang_scope_close(ptr %s28)
  call void @__olang_scope_close(ptr %s4)
  br label %bb159
bb125:
  %t593 = load ptr, ptr %lp3
  %t594 = getelementptr %"compiler/olang:CommandLine", ptr %t593, i32 0, i32 0
  %t595 = load i64, ptr %t594
  store i64 %t595, ptr %l202
  %t596 = load i64, ptr @G_2ecompiler_2folang_2eRun
  store i64 %t596, ptr %l203
  %t597 = load i64, ptr %l202
  %t598 = load i64, ptr %l203
  %t599 = icmp eq i64 %t597, %t598
  store i1 %t599, ptr %l204
  %t600 = load i1, ptr %l204
  br i1 %t600, label %bb126, label %bb127
bb126:
  %t601 = load { i64, ptr }, ptr %l6
  store { i64, ptr } %t601, ptr %l206
  %t602 = load { i64, ptr }, ptr %l206
  %t603 = call i1 @compiler_2folang_2eendsWithOlang(ptr %v0, { i64, ptr } %t602)
  store i1 %t603, ptr %l207
  br label %bb128
bb127:
  store i1 false, ptr %l205
  br label %bb129
bb128:
  %t604 = load i1, ptr %l207
  %t605 = xor i1 %t604, true
  store i1 %t605, ptr %l208
  %t606 = load i1, ptr %l208
  store i1 %t606, ptr %l205
  br label %bb129
bb129:
  %t607 = load i1, ptr %l205
  br i1 %t607, label %bb130, label %bb131
bb130:
  store %olang.scope zeroinitializer, ptr %s31
  %t608 = load { i64, ptr }, ptr %l6
  store { i64, ptr } %t608, ptr %l209
  %t609 = load { i64, ptr }, ptr %l209
  %t610 = call i64 @compiler_2folang_2emodeNumber(ptr %v0, { i64, ptr } %t609)
  store i64 %t610, ptr %l210
  br label %bb132
bb131:
  br label %bb144
bb132:
  %t611 = load i64, ptr %l210
  %t612 = icmp sgt i64 %t611, 0
  store i1 %t612, ptr %l211
  %t613 = load i1, ptr %l211
  br i1 %t613, label %bb133, label %bb134
bb133:
  store %olang.scope zeroinitializer, ptr %s32
  %t614 = load ptr, ptr %l2
  store ptr %t614, ptr %l212
  %t615 = load { i64, ptr }, ptr %l6
  store { i64, ptr } %t615, ptr %l213
  %t616 = load { i64, ptr }, ptr %l213
  %t617 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eModeFirst(ptr %v0, ptr %s32, { i64, ptr } %t616)
  store %"compiler/msgs:Msg" %t617, ptr %l214
  br label %bb135
bb134:
  br label %bb139
bb135:
  %t618 = load ptr, ptr %l212
  %t619 = load %"compiler/msgs:Msg", ptr %l214
  %t620 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s32, ptr %t618, %"compiler/msgs:Msg" %t619)
  store i32 %t620, ptr %l215
  %t621 = icmp ne i32 %t620, 0
  br i1 %t621, label %bb137, label %ok.622
ok.622:
  br label %bb136
bb136:
  br label %bb138
bb137:
  %t623 = load i32, ptr %l215
  %t624 = lshr i32 %t623, 16
  %t625 = and i32 %t623, 65535
  %t626 = icmp eq i32 %t624, 1
  %t627 = select i1 %t626, i32 1, i32 0
  %t628 = icmp eq i32 %t623, 0
  %t629 = shl i32 %t627, 16
  %t630 = or i32 %t629, %t625
  %t631 = select i1 %t628, i32 0, i32 %t630
  store i32 %t631, ptr %l216
  call void @__olang_scope_close(ptr %s32)
  call void @__olang_scope_close(ptr %s31)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t632 = load i32, ptr %l216
  %t633 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t632, 0
  store { i32, %"compiler/olang:CommandLine" } %t633, ptr %rv
  br label %ret
bb138:
  call void @__olang_scope_close(ptr %s32)
  br label %bb139
bb139:
  %t634 = load ptr, ptr %l2
  store ptr %t634, ptr %l217
  %t635 = load { i64, ptr }, ptr %l6
  store { i64, ptr } %t635, ptr %l218
  %t636 = load { i64, ptr }, ptr %l218
  %t637 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotASource(ptr %v0, ptr %s31, { i64, ptr } %t636)
  store %"compiler/msgs:Msg" %t637, ptr %l219
  br label %bb140
bb140:
  %t638 = load ptr, ptr %l217
  %t639 = load %"compiler/msgs:Msg", ptr %l219
  %t640 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s31, ptr %t638, %"compiler/msgs:Msg" %t639)
  store i32 %t640, ptr %l220
  %t641 = icmp ne i32 %t640, 0
  br i1 %t641, label %bb142, label %ok.642
ok.642:
  br label %bb141
bb141:
  br label %bb143
bb142:
  %t643 = load i32, ptr %l220
  %t644 = lshr i32 %t643, 16
  %t645 = and i32 %t643, 65535
  %t646 = icmp eq i32 %t644, 1
  %t647 = select i1 %t646, i32 1, i32 0
  %t648 = icmp eq i32 %t643, 0
  %t649 = shl i32 %t647, 16
  %t650 = or i32 %t649, %t645
  %t651 = select i1 %t648, i32 0, i32 %t650
  store i32 %t651, ptr %l221
  call void @__olang_scope_close(ptr %s31)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t652 = load i32, ptr %l221
  %t653 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t652, 0
  store { i32, %"compiler/olang:CommandLine" } %t653, ptr %rv
  br label %ret
bb143:
  call void @__olang_scope_close(ptr %s31)
  br label %bb144
bb144:
  %t654 = load ptr, ptr %lp3
  %t655 = getelementptr %"compiler/olang:CommandLine", ptr %t654, i32 0, i32 1
  store ptr %t655, ptr %l222
  %t656 = load { i64, ptr }, ptr %l6
  store { i64, ptr } %t656, ptr %l223
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s33
  store ptr %s33room, ptr %s33
  %t657 = load { i64, ptr }, ptr %l223
  %t658 = extractvalue { i64, ptr } %t657, 1
  %t659 = extractvalue { i64, ptr } %t657, 0
  call void @__olang_sb_put(ptr %s33, ptr %t658, i64 %t659)
  %t660 = load ptr, ptr %s33
  %t661 = getelementptr %olang.builder, ptr %s33, i32 0, i32 1
  %t662 = load i64, ptr %t661
  %t663 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t662)
  call void @llvm.memcpy.p0.p0.i64(ptr %t663, ptr %t660, i64 %t662, i1 false)
  %t664 = insertvalue { i64, ptr } undef, i64 %t662, 0
  %t665 = insertvalue { i64, ptr } %t664, ptr %t663, 1
  store { i64, ptr } %t665, ptr %l224
  call void @__olang_sb_done(ptr %s33)
  %t666 = load { i64, ptr }, ptr %l224
  %t667 = extractvalue { i64, ptr } %t666, 0
  %t668 = extractvalue { i64, ptr } %t666, 1
  %t669 = mul i64 %t667, 1
  %t670 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t669)
  call void @llvm.memcpy.p0.p0.i64(ptr %t670, ptr %t668, i64 %t669, i1 false)
  %t671 = insertvalue { i64, ptr } undef, i64 %t667, 0
  %t672 = insertvalue { i64, ptr } %t671, ptr %t670, 1
  store { i64, ptr } %t672, ptr %l225
  %t673 = load ptr, ptr %l222
  %t674 = load { i64, ptr }, ptr %l225
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v3, ptr %v3, ptr %t673, { i64, ptr } %t674)
  br label %bb145
bb145:
  %t675 = load ptr, ptr %lp3
  %t676 = getelementptr %"compiler/olang:CommandLine", ptr %t675, i32 0, i32 0
  %t677 = load i64, ptr %t676
  store i64 %t677, ptr %l226
  %t678 = load i64, ptr @G_2ecompiler_2folang_2eRun
  store i64 %t678, ptr %l227
  %t679 = load i64, ptr %l226
  %t680 = load i64, ptr %l227
  %t681 = icmp eq i64 %t679, %t680
  store i1 %t681, ptr %l228
  %t682 = load i1, ptr %l228
  br i1 %t682, label %bb146, label %bb147
bb146:
  store i1 true, ptr %l229
  br label %bb148
bb147:
  %t683 = load ptr, ptr %lp3
  %t684 = getelementptr %"compiler/olang:CommandLine", ptr %t683, i32 0, i32 0
  %t685 = load i64, ptr %t684
  store i64 %t685, ptr %l230
  %t686 = load i64, ptr @G_2ecompiler_2folang_2eInterp
  store i64 %t686, ptr %l231
  %t687 = load i64, ptr %l230
  %t688 = load i64, ptr %l231
  %t689 = icmp eq i64 %t687, %t688
  store i1 %t689, ptr %l232
  %t690 = load i1, ptr %l232
  store i1 %t690, ptr %l229
  br label %bb148
bb148:
  %t691 = load i1, ptr %l229
  br i1 %t691, label %bb149, label %bb150
bb149:
  store %olang.scope zeroinitializer, ptr %s34
  br label %bb151
bb150:
  br label %bb158
bb151:
  store %olang.scope zeroinitializer, ptr %s35
  %t692 = load i64, ptr %l4
  store i64 %t692, ptr %l233
  %t693 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t693, ptr %l234
  %t694 = load { i64, ptr }, ptr %l234
  %t695 = extractvalue { i64, ptr } %t694, 0
  store i64 %t695, ptr %l235
  %t696 = load i64, ptr %l233
  %t697 = load i64, ptr %l235
  %t698 = icmp slt i64 %t696, %t697
  store i1 %t698, ptr %l236
  %t699 = load i1, ptr %l236
  %t700 = xor i1 %t699, true
  store i1 %t700, ptr %l237
  %t701 = load i1, ptr %l237
  br i1 %t701, label %bb152, label %bb153
bb152:
  call void @__olang_scope_close(ptr %s35)
  br label %bb157
bb153:
  br label %bb154
bb154:
  %t702 = load ptr, ptr %lp3
  %t703 = getelementptr %"compiler/olang:CommandLine", ptr %t702, i32 0, i32 4
  store ptr %t703, ptr %l238
  %t704 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t704, ptr %l239
  %t705 = load i64, ptr %l4
  store i64 %t705, ptr %l240
  %t706 = load i64, ptr %l240
  %t707 = getelementptr { i64, ptr }, ptr %l239, i32 0, i32 1
  %t708 = load ptr, ptr %t707
  %t709 = getelementptr { i64, ptr }, ptr %t708, i64 %t706
  %t710 = load { i64, ptr }, ptr %t709
  store { i64, ptr } %t710, ptr %l241
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s36
  store ptr %s36room, ptr %s36
  %t711 = load { i64, ptr }, ptr %l241
  %t712 = extractvalue { i64, ptr } %t711, 1
  %t713 = extractvalue { i64, ptr } %t711, 0
  call void @__olang_sb_put(ptr %s36, ptr %t712, i64 %t713)
  %t714 = load ptr, ptr %s36
  %t715 = getelementptr %olang.builder, ptr %s36, i32 0, i32 1
  %t716 = load i64, ptr %t715
  %t717 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t716)
  call void @llvm.memcpy.p0.p0.i64(ptr %t717, ptr %t714, i64 %t716, i1 false)
  %t718 = insertvalue { i64, ptr } undef, i64 %t716, 0
  %t719 = insertvalue { i64, ptr } %t718, ptr %t717, 1
  store { i64, ptr } %t719, ptr %l242
  call void @__olang_sb_done(ptr %s36)
  %t720 = load { i64, ptr }, ptr %l242
  %t721 = extractvalue { i64, ptr } %t720, 0
  %t722 = extractvalue { i64, ptr } %t720, 1
  %t723 = mul i64 %t721, 1
  %t724 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t723)
  call void @llvm.memcpy.p0.p0.i64(ptr %t724, ptr %t722, i64 %t723, i1 false)
  %t725 = insertvalue { i64, ptr } undef, i64 %t721, 0
  %t726 = insertvalue { i64, ptr } %t725, ptr %t724, 1
  store { i64, ptr } %t726, ptr %l243
  %t727 = load ptr, ptr %l238
  %t728 = load { i64, ptr }, ptr %l243
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v3, ptr %v3, ptr %t727, { i64, ptr } %t728)
  br label %bb155
bb155:
  %t729 = load i64, ptr %l4
  store i64 %t729, ptr %l244
  %t730 = load i64, ptr %l244
  %t731 = add i64 %t730, 1
  store i64 %t731, ptr %l245
  %t732 = load i64, ptr %l245
  store i64 %t732, ptr %l4
  call void @__olang_scope_close(ptr %s35)
  br label %bb156
bb156:
  br label %bb151
bb157:
  call void @__olang_scope_close(ptr %s34)
  br label %bb158
bb158:
  call void @__olang_scope_close(ptr %s4)
  br label %bb159
bb159:
  br label %bb25
bb160:
  %t733 = load ptr, ptr %lp3
  %t734 = load %"compiler/olang:CommandLine", ptr %t733
  store %"compiler/olang:CommandLine" %t734, ptr %l246
  call void @__olang_scope_close(ptr %s0)
  %t735 = load %"compiler/olang:CommandLine", ptr %l246
  %t736 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, %"compiler/olang:CommandLine" %t735, 1
  store { i32, %"compiler/olang:CommandLine" } %t736, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/olang:CommandLine" }, ptr %rv
  ret { i32, %"compiler/olang:CommandLine" } %rr
}

define dso_local { i32, %"compiler/olang:CommandLine" } @compiler_2folang_2ePrepare(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l2 = alloca ptr
  %lp3 = alloca ptr
  %l4 = alloca %"compiler/olang:CommandLine"
  %l5 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca %"compiler/olang:CommandLine"
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i1
  %l14 = alloca %"compiler/olang:CommandLine"
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i1
  %l18 = alloca i1
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca %"compiler/msgs:Msg"
  %l22 = alloca i32
  %l23 = alloca i32
  %l24 = alloca %"compiler/olang:CommandLine"
  %l25 = alloca ptr
  %l26 = alloca i64
  %l27 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca i64
  %l30 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l32 = alloca %"compiler/msgs:Msg"
  %l33 = alloca i32
  %l34 = alloca i32
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i1
  %l38 = alloca i1
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i1
  %l42 = alloca i1
  %l43 = alloca ptr
  %l44 = alloca i64
  %l45 = alloca i1
  %l46 = alloca ptr
  %l47 = alloca i64
  %l48 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l50 = alloca %"compiler/msgs:Msg"
  %l51 = alloca i32
  %l52 = alloca i32
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i1
  %l56 = alloca %"compiler/olang:CommandLine"
  %l57 = alloca { i64, ptr }
  %l58 = alloca i1
  %l59 = alloca i1
  %l60 = alloca { i64, ptr }
  %l61 = alloca ptr
  %l62 = alloca i32
  %l63 = alloca i32
  %l64 = alloca ptr
  %l65 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l68 = alloca ptr
  %l69 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l71 = alloca ptr
  %l72 = alloca %"compiler/target:Target"
  %l73 = alloca { i64, ptr }
  %l74 = alloca ptr
  %l75 = alloca { i64, ptr }
  %l76 = alloca i64
  %l77 = alloca i64
  %l78 = alloca i1
  %l79 = alloca ptr
  %l80 = alloca %"compiler/target:Target"
  %l81 = alloca i32
  %l82 = alloca i32
  %l83 = alloca i1
  %l84 = alloca i32
  %l85 = alloca i32
  %l86 = alloca ptr
  %l87 = alloca i1
  %l88 = alloca i1
  %l89 = alloca i64
  %l90 = alloca i64
  %l91 = alloca i1
  %l92 = alloca ptr
  %l93 = alloca i64
  %l94 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l97 = alloca %"compiler/msgs:Msg"
  %l98 = alloca i32
  %l99 = alloca i32
  %l100 = alloca ptr
  %l101 = alloca i64
  %l102 = alloca i64
  %l103 = alloca i1
  %l104 = alloca ptr
  %l105 = alloca ptr
  %l106 = alloca i1
  %l107 = alloca ptr
  %l108 = alloca i32
  %l109 = alloca i32
  %l110 = alloca %"compiler/olang:CommandLine"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.builder
  %s8room = alloca [64 x i8], align 8
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca { i32, %"compiler/olang:CommandLine" }
  store { i64, ptr } %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l5
  %t2 = load ptr, ptr %l1
  store ptr %t2, ptr %l6
  %t3 = load ptr, ptr %l2
  store ptr %t3, ptr %l7
  %t4 = load { i64, ptr }, ptr %l5
  %t5 = load ptr, ptr %l6
  %t6 = load ptr, ptr %l7
  %t7 = call { i32, %"compiler/olang:CommandLine" } @compiler_2folang_2eParse(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %t4, ptr %t5, ptr %t6)
  %t8 = extractvalue { i32, %"compiler/olang:CommandLine" } %t7, 1
  %t9 = extractvalue { i32, %"compiler/olang:CommandLine" } %t7, 0
  store i32 %t9, ptr %l9
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11
ok.11:
  store %"compiler/olang:CommandLine" %t8, ptr %l8
  br label %bb1
bb1:
  %t12 = load %"compiler/olang:CommandLine", ptr %l8
  store %"compiler/olang:CommandLine" %t12, ptr %l4
  br label %bb3
bb2:
  %t13 = load i32, ptr %l9
  %t14 = lshr i32 %t13, 16
  %t15 = and i32 %t13, 65535
  %t16 = icmp eq i32 %t14, 1
  %t17 = select i1 %t16, i32 1, i32 0
  %t18 = icmp eq i32 %t13, 0
  %t19 = shl i32 %t17, 16
  %t20 = or i32 %t19, %t15
  %t21 = select i1 %t18, i32 0, i32 %t20
  store i32 %t21, ptr %l10
  call void @__olang_scope_close(ptr %s0)
  %t22 = load i32, ptr %l10
  %t23 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t22, 0
  store { i32, %"compiler/olang:CommandLine" } %t23, ptr %rv
  br label %ret
bb3:
  %t24 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 96, i64 8)
  store ptr %t24, ptr %lp3
  %t25 = load %"compiler/olang:CommandLine", ptr %l4
  %t26 = load ptr, ptr %lp3
  store %"compiler/olang:CommandLine" %t25, ptr %t26
  %t27 = load ptr, ptr %lp3
  %t28 = getelementptr %"compiler/olang:CommandLine", ptr %t27, i32 0, i32 0
  %t29 = load i64, ptr %t28
  store i64 %t29, ptr %l11
  %t30 = load i64, ptr @G_2ecompiler_2folang_2eHelp
  store i64 %t30, ptr %l12
  %t31 = load i64, ptr %l11
  %t32 = load i64, ptr %l12
  %t33 = icmp eq i64 %t31, %t32
  store i1 %t33, ptr %l13
  %t34 = load i1, ptr %l13
  br i1 %t34, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t35 = load ptr, ptr %lp3
  %t36 = load %"compiler/olang:CommandLine", ptr %t35
  store %"compiler/olang:CommandLine" %t36, ptr %l14
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t37 = load %"compiler/olang:CommandLine", ptr %l14
  %t38 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, %"compiler/olang:CommandLine" %t37, 1
  store { i32, %"compiler/olang:CommandLine" } %t38, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t39 = load ptr, ptr %lp3
  %t40 = getelementptr %"compiler/olang:CommandLine", ptr %t39, i32 0, i32 0
  %t41 = load i64, ptr %t40
  store i64 %t41, ptr %l15
  %t42 = load i64, ptr @G_2ecompiler_2folang_2eExplain
  store i64 %t42, ptr %l16
  %t43 = load i64, ptr %l15
  %t44 = load i64, ptr %l16
  %t45 = icmp eq i64 %t43, %t44
  store i1 %t45, ptr %l17
  %t46 = load i1, ptr %l17
  br i1 %t46, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t47 = load ptr, ptr %lp3
  %t48 = getelementptr %"compiler/olang:CommandLine", ptr %t47, i32 0, i32 3
  %t49 = load i1, ptr %t48
  store i1 %t49, ptr %l18
  %t50 = load i1, ptr %l18
  %t51 = xor i1 %t50, true
  store i1 %t51, ptr %l19
  %t52 = load i1, ptr %l19
  br i1 %t52, label %bb9, label %bb10
bb8:
  br label %bb16
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t53 = load ptr, ptr %l2
  store ptr %t53, ptr %l20
  %t54 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eExplainNeedsRule(ptr %s3)
  store %"compiler/msgs:Msg" %t54, ptr %l21
  br label %bb11
bb10:
  br label %bb15
bb11:
  %t55 = load ptr, ptr %l20
  %t56 = load %"compiler/msgs:Msg", ptr %l21
  %t57 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s3, ptr %t55, %"compiler/msgs:Msg" %t56)
  store i32 %t57, ptr %l22
  %t58 = icmp ne i32 %t57, 0
  br i1 %t58, label %bb13, label %ok.59
ok.59:
  br label %bb12
bb12:
  br label %bb14
bb13:
  %t60 = load i32, ptr %l22
  %t61 = lshr i32 %t60, 16
  %t62 = and i32 %t60, 65535
  %t63 = icmp eq i32 %t61, 1
  %t64 = select i1 %t63, i32 1, i32 0
  %t65 = icmp eq i32 %t60, 0
  %t66 = shl i32 %t64, 16
  %t67 = or i32 %t66, %t62
  %t68 = select i1 %t65, i32 0, i32 %t67
  store i32 %t68, ptr %l23
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t69 = load i32, ptr %l23
  %t70 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t69, 0
  store { i32, %"compiler/olang:CommandLine" } %t70, ptr %rv
  br label %ret
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb15:
  %t71 = load ptr, ptr %lp3
  %t72 = load %"compiler/olang:CommandLine", ptr %t71
  store %"compiler/olang:CommandLine" %t72, ptr %l24
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t73 = load %"compiler/olang:CommandLine", ptr %l24
  %t74 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, %"compiler/olang:CommandLine" %t73, 1
  store { i32, %"compiler/olang:CommandLine" } %t74, ptr %rv
  br label %ret
bb16:
  %t75 = load ptr, ptr %lp3
  %t76 = getelementptr %"compiler/olang:CommandLine", ptr %t75, i32 0, i32 1
  store ptr %t76, ptr %l25
  %t77 = load ptr, ptr %l25
  %t78 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v3, ptr %t77)
  store i64 %t78, ptr %l26
  br label %bb17
bb17:
  %t79 = load i64, ptr %l26
  %t80 = icmp eq i64 %t79, 0
  store i1 %t80, ptr %l27
  %t81 = load i1, ptr %l27
  br i1 %t81, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s4
  %t82 = load ptr, ptr %l2
  store ptr %t82, ptr %l28
  %t83 = load ptr, ptr %lp3
  %t84 = getelementptr %"compiler/olang:CommandLine", ptr %t83, i32 0, i32 0
  %t85 = load i64, ptr %t84
  store i64 %t85, ptr %l29
  %t86 = load i64, ptr %l29
  %t87 = call { i64, ptr } @compiler_2folang_2emodeName(ptr %s4, i64 %t86)
  store { i64, ptr } %t87, ptr %l30
  br label %bb20
bb19:
  br label %bb25
bb20:
  %t88 = load { i64, ptr }, ptr %l30
  %t89 = extractvalue { i64, ptr } %t88, 0
  %t90 = extractvalue { i64, ptr } %t88, 1
  %t91 = mul i64 %t89, 1
  %t92 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t91)
  call void @llvm.memcpy.p0.p0.i64(ptr %t92, ptr %t90, i64 %t91, i1 false)
  %t93 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t92, 1
  store { i64, ptr } %t94, ptr %l31
  %t95 = load { i64, ptr }, ptr %l31
  %t96 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eModeNeedsFile(ptr %s4, ptr %s4, { i64, ptr } %t95)
  store %"compiler/msgs:Msg" %t96, ptr %l32
  br label %bb21
bb21:
  %t97 = load ptr, ptr %l28
  %t98 = load %"compiler/msgs:Msg", ptr %l32
  %t99 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s4, ptr %t97, %"compiler/msgs:Msg" %t98)
  store i32 %t99, ptr %l33
  %t100 = icmp ne i32 %t99, 0
  br i1 %t100, label %bb23, label %ok.101
ok.101:
  br label %bb22
bb22:
  br label %bb24
bb23:
  %t102 = load i32, ptr %l33
  %t103 = lshr i32 %t102, 16
  %t104 = and i32 %t102, 65535
  %t105 = icmp eq i32 %t103, 1
  %t106 = select i1 %t105, i32 1, i32 0
  %t107 = icmp eq i32 %t102, 0
  %t108 = shl i32 %t106, 16
  %t109 = or i32 %t108, %t104
  %t110 = select i1 %t107, i32 0, i32 %t109
  store i32 %t110, ptr %l34
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t111 = load i32, ptr %l34
  %t112 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t111, 0
  store { i32, %"compiler/olang:CommandLine" } %t112, ptr %rv
  br label %ret
bb24:
  call void @__olang_scope_close(ptr %s4)
  br label %bb25
bb25:
  %t113 = load ptr, ptr %lp3
  %t114 = getelementptr %"compiler/olang:CommandLine", ptr %t113, i32 0, i32 0
  %t115 = load i64, ptr %t114
  store i64 %t115, ptr %l35
  %t116 = load i64, ptr @G_2ecompiler_2folang_2eBuild
  store i64 %t116, ptr %l36
  %t117 = load i64, ptr %l35
  %t118 = load i64, ptr %l36
  %t119 = icmp eq i64 %t117, %t118
  store i1 %t119, ptr %l37
  %t120 = load i1, ptr %l37
  br i1 %t120, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l38
  br label %bb28
bb27:
  %t121 = load ptr, ptr %lp3
  %t122 = getelementptr %"compiler/olang:CommandLine", ptr %t121, i32 0, i32 0
  %t123 = load i64, ptr %t122
  store i64 %t123, ptr %l39
  %t124 = load i64, ptr @G_2ecompiler_2folang_2eCompile
  store i64 %t124, ptr %l40
  %t125 = load i64, ptr %l39
  %t126 = load i64, ptr %l40
  %t127 = icmp eq i64 %t125, %t126
  store i1 %t127, ptr %l41
  %t128 = load i1, ptr %l41
  store i1 %t128, ptr %l38
  br label %bb28
bb28:
  %t129 = load i1, ptr %l38
  br i1 %t129, label %bb29, label %bb30
bb29:
  %t130 = load ptr, ptr %lp3
  %t131 = getelementptr %"compiler/olang:CommandLine", ptr %t130, i32 0, i32 1
  store ptr %t131, ptr %l43
  %t132 = load ptr, ptr %l43
  %t133 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v3, ptr %t132)
  store i64 %t133, ptr %l44
  br label %bb31
bb30:
  store i1 false, ptr %l42
  br label %bb32
bb31:
  %t134 = load i64, ptr %l44
  %t135 = icmp ne i64 %t134, 1
  store i1 %t135, ptr %l45
  %t136 = load i1, ptr %l45
  store i1 %t136, ptr %l42
  br label %bb32
bb32:
  %t137 = load i1, ptr %l42
  br i1 %t137, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s5
  %t138 = load ptr, ptr %l2
  store ptr %t138, ptr %l46
  %t139 = load ptr, ptr %lp3
  %t140 = getelementptr %"compiler/olang:CommandLine", ptr %t139, i32 0, i32 0
  %t141 = load i64, ptr %t140
  store i64 %t141, ptr %l47
  %t142 = load i64, ptr %l47
  %t143 = call { i64, ptr } @compiler_2folang_2emodeName(ptr %s5, i64 %t142)
  store { i64, ptr } %t143, ptr %l48
  br label %bb35
bb34:
  br label %bb40
bb35:
  %t144 = load { i64, ptr }, ptr %l48
  %t145 = extractvalue { i64, ptr } %t144, 0
  %t146 = extractvalue { i64, ptr } %t144, 1
  %t147 = mul i64 %t145, 1
  %t148 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t147)
  call void @llvm.memcpy.p0.p0.i64(ptr %t148, ptr %t146, i64 %t147, i1 false)
  %t149 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t150 = insertvalue { i64, ptr } %t149, ptr %t148, 1
  store { i64, ptr } %t150, ptr %l49
  %t151 = load { i64, ptr }, ptr %l49
  %t152 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eModeOneFile(ptr %s5, ptr %s5, { i64, ptr } %t151)
  store %"compiler/msgs:Msg" %t152, ptr %l50
  br label %bb36
bb36:
  %t153 = load ptr, ptr %l46
  %t154 = load %"compiler/msgs:Msg", ptr %l50
  %t155 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s5, ptr %t153, %"compiler/msgs:Msg" %t154)
  store i32 %t155, ptr %l51
  %t156 = icmp ne i32 %t155, 0
  br i1 %t156, label %bb38, label %ok.157
ok.157:
  br label %bb37
bb37:
  br label %bb39
bb38:
  %t158 = load i32, ptr %l51
  %t159 = lshr i32 %t158, 16
  %t160 = and i32 %t158, 65535
  %t161 = icmp eq i32 %t159, 1
  %t162 = select i1 %t161, i32 1, i32 0
  %t163 = icmp eq i32 %t158, 0
  %t164 = shl i32 %t162, 16
  %t165 = or i32 %t164, %t160
  %t166 = select i1 %t163, i32 0, i32 %t165
  store i32 %t166, ptr %l52
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t167 = load i32, ptr %l52
  %t168 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t167, 0
  store { i32, %"compiler/olang:CommandLine" } %t168, ptr %rv
  br label %ret
bb39:
  call void @__olang_scope_close(ptr %s5)
  br label %bb40
bb40:
  %t169 = load ptr, ptr %lp3
  %t170 = getelementptr %"compiler/olang:CommandLine", ptr %t169, i32 0, i32 0
  %t171 = load i64, ptr %t170
  store i64 %t171, ptr %l53
  %t172 = load i64, ptr @G_2ecompiler_2folang_2eFormat
  store i64 %t172, ptr %l54
  %t173 = load i64, ptr %l53
  %t174 = load i64, ptr %l54
  %t175 = icmp eq i64 %t173, %t174
  store i1 %t175, ptr %l55
  %t176 = load i1, ptr %l55
  br i1 %t176, label %bb41, label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s6
  %t177 = load ptr, ptr %lp3
  %t178 = load %"compiler/olang:CommandLine", ptr %t177
  store %"compiler/olang:CommandLine" %t178, ptr %l56
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t179 = load %"compiler/olang:CommandLine", ptr %l56
  %t180 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, %"compiler/olang:CommandLine" %t179, 1
  store { i32, %"compiler/olang:CommandLine" } %t180, ptr %rv
  br label %ret
bb42:
  br label %bb43
bb43:
  %t181 = load ptr, ptr %lp3
  %t182 = getelementptr %"compiler/olang:CommandLine", ptr %t181, i32 0, i32 7
  %t183 = load { i64, ptr }, ptr %t182
  store { i64, ptr } %t183, ptr %l57
  %t184 = load { i64, ptr }, ptr %l57
  %t185 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s0, { i64, ptr } %t184, { i64, ptr } { i64 0, ptr @.d52 })
  store i1 %t185, ptr %l58
  br label %bb44
bb44:
  %t186 = load i1, ptr %l58
  %t187 = xor i1 %t186, true
  store i1 %t187, ptr %l59
  %t188 = load i1, ptr %l59
  br i1 %t188, label %bb45, label %bb46
bb45:
  store %olang.scope zeroinitializer, ptr %s7
  %t189 = load ptr, ptr %lp3
  %t190 = getelementptr %"compiler/olang:CommandLine", ptr %t189, i32 0, i32 7
  %t191 = load { i64, ptr }, ptr %t190
  store { i64, ptr } %t191, ptr %l60
  %t192 = load ptr, ptr %l2
  store ptr %t192, ptr %l61
  %t193 = load { i64, ptr }, ptr %l60
  %t194 = load ptr, ptr %l61
  %t195 = call i32 @compiler_2folang_2echeckOutput(ptr %v3, ptr %v2, { i64, ptr } %t193, ptr %t194)
  store i32 %t195, ptr %l62
  %t196 = icmp ne i32 %t195, 0
  br i1 %t196, label %bb48, label %ok.197
ok.197:
  br label %bb47
bb46:
  br label %bb50
bb47:
  br label %bb49
bb48:
  %t198 = load i32, ptr %l62
  %t199 = lshr i32 %t198, 16
  %t200 = and i32 %t198, 65535
  %t201 = icmp eq i32 %t199, 1
  %t202 = select i1 %t201, i32 1, i32 0
  %t203 = icmp eq i32 %t198, 0
  %t204 = shl i32 %t202, 16
  %t205 = or i32 %t204, %t200
  %t206 = select i1 %t203, i32 0, i32 %t205
  store i32 %t206, ptr %l63
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  %t207 = load i32, ptr %l63
  %t208 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t207, 0
  store { i32, %"compiler/olang:CommandLine" } %t208, ptr %rv
  br label %ret
bb49:
  call void @__olang_scope_close(ptr %s7)
  br label %bb50
bb50:
  %t209 = load ptr, ptr %l1
  store ptr %t209, ptr %l64
  %t210 = load ptr, ptr %lp3
  %t211 = getelementptr %"compiler/olang:CommandLine", ptr %t210, i32 0, i32 7
  %t212 = load { i64, ptr }, ptr %t211
  store { i64, ptr } %t212, ptr %l65
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s8
  store ptr %s8room, ptr %s8
  %t213 = load { i64, ptr }, ptr %l65
  %t214 = extractvalue { i64, ptr } %t213, 1
  %t215 = extractvalue { i64, ptr } %t213, 0
  call void @__olang_sb_put(ptr %s8, ptr %t214, i64 %t215)
  %t216 = load ptr, ptr %s8
  %t217 = getelementptr %olang.builder, ptr %s8, i32 0, i32 1
  %t218 = load i64, ptr %t217
  %t219 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t218)
  call void @llvm.memcpy.p0.p0.i64(ptr %t219, ptr %t216, i64 %t218, i1 false)
  %t220 = insertvalue { i64, ptr } undef, i64 %t218, 0
  %t221 = insertvalue { i64, ptr } %t220, ptr %t219, 1
  store { i64, ptr } %t221, ptr %l66
  call void @__olang_sb_done(ptr %s8)
  %t222 = load { i64, ptr }, ptr %l66
  %t223 = extractvalue { i64, ptr } %t222, 0
  %t224 = extractvalue { i64, ptr } %t222, 1
  %t225 = mul i64 %t223, 1
  %t226 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t225)
  call void @llvm.memcpy.p0.p0.i64(ptr %t226, ptr %t224, i64 %t225, i1 false)
  %t227 = insertvalue { i64, ptr } undef, i64 %t223, 0
  %t228 = insertvalue { i64, ptr } %t227, ptr %t226, 1
  store { i64, ptr } %t228, ptr %l67
  %t229 = load { i64, ptr }, ptr %l67
  %t230 = load ptr, ptr %l64
  %t231 = getelementptr %"compiler/build:Config", ptr %t230, i32 0, i32 12
  store { i64, ptr } %t229, ptr %t231
  %t232 = load ptr, ptr %l1
  store ptr %t232, ptr %l68
  %t233 = call { i64, ptr } @compiler_2ftarget_2eFindClang(ptr %v1)
  store { i64, ptr } %t233, ptr %l69
  br label %bb51
bb51:
  %t234 = load { i64, ptr }, ptr %l69
  %t235 = extractvalue { i64, ptr } %t234, 0
  %t236 = extractvalue { i64, ptr } %t234, 1
  %t237 = mul i64 %t235, 1
  %t238 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t237)
  call void @llvm.memcpy.p0.p0.i64(ptr %t238, ptr %t236, i64 %t237, i1 false)
  %t239 = insertvalue { i64, ptr } undef, i64 %t235, 0
  %t240 = insertvalue { i64, ptr } %t239, ptr %t238, 1
  store { i64, ptr } %t240, ptr %l70
  %t241 = load { i64, ptr }, ptr %l70
  %t242 = load ptr, ptr %l68
  %t243 = getelementptr %"compiler/build:Config", ptr %t242, i32 0, i32 1
  store { i64, ptr } %t241, ptr %t243
  %t244 = load ptr, ptr %l1
  store ptr %t244, ptr %l71
  %t245 = load ptr, ptr %lp3
  %t246 = getelementptr %"compiler/olang:CommandLine", ptr %t245, i32 0, i32 6
  %t247 = load { i64, ptr }, ptr %t246
  store { i64, ptr } %t247, ptr %l73
  %t248 = load ptr, ptr %l1
  store ptr %t248, ptr %l74
  %t249 = load ptr, ptr %l74
  %t250 = getelementptr %"compiler/build:Config", ptr %t249, i32 0, i32 1
  %t251 = load { i64, ptr }, ptr %t250
  store { i64, ptr } %t251, ptr %l75
  %t252 = load ptr, ptr %lp3
  %t253 = getelementptr %"compiler/olang:CommandLine", ptr %t252, i32 0, i32 0
  %t254 = load i64, ptr %t253
  store i64 %t254, ptr %l76
  %t255 = load i64, ptr @G_2ecompiler_2folang_2eInterp
  store i64 %t255, ptr %l77
  %t256 = load i64, ptr %l76
  %t257 = load i64, ptr %l77
  %t258 = icmp eq i64 %t256, %t257
  store i1 %t258, ptr %l78
  %t259 = load ptr, ptr %l2
  store ptr %t259, ptr %l79
  %t260 = load { i64, ptr }, ptr %l73
  %t261 = load { i64, ptr }, ptr %l75
  %t262 = load i1, ptr %l78
  %t263 = load ptr, ptr %l79
  %t264 = call { i32, %"compiler/target:Target" } @compiler_2ftarget_2eResolve(ptr %v3, ptr %v1, ptr %v2, ptr %v1, { i64, ptr } %t260, { i64, ptr } %t261, i1 %t262, ptr %t263)
  %t265 = extractvalue { i32, %"compiler/target:Target" } %t264, 1
  %t266 = extractvalue { i32, %"compiler/target:Target" } %t264, 0
  store i32 %t266, ptr %l81
  %t267 = icmp ne i32 %t266, 0
  br i1 %t267, label %bb53, label %ok.268
ok.268:
  store %"compiler/target:Target" %t265, ptr %l80
  br label %bb52
bb52:
  %t269 = load %"compiler/target:Target", ptr %l80
  store %"compiler/target:Target" %t269, ptr %l72
  br label %bb57
bb53:
  %t270 = load i32, ptr %l81
  %t271 = ashr i32 %t270, 16
  store i32 %t271, ptr %l82
  %t272 = load i32, ptr %l82
  %t273 = icmp eq i32 %t272, 1
  store i1 %t273, ptr %l83
  %t274 = load i1, ptr %l83
  br i1 %t274, label %bb54, label %bb55
bb54:
  br label %bb56
bb55:
  %t275 = load i32, ptr %l81
  %t276 = lshr i32 %t275, 16
  %t277 = and i32 %t275, 65535
  %t278 = icmp eq i32 %t276, 1
  %t279 = select i1 %t278, i32 0, i32 0
  %t280 = icmp eq i32 %t275, 0
  %t281 = shl i32 %t279, 16
  %t282 = or i32 %t281, %t277
  %t283 = select i1 %t280, i32 0, i32 %t282
  store i32 %t283, ptr %l84
  call void @__olang_scope_close(ptr %s0)
  %t284 = load i32, ptr %l84
  %t285 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t284, 0
  store { i32, %"compiler/olang:CommandLine" } %t285, ptr %rv
  br label %ret
bb56:
  store %olang.scope zeroinitializer, ptr %s9
  store i32 65536, ptr %l85
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  %t286 = load i32, ptr %l85
  %t287 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t286, 0
  store { i32, %"compiler/olang:CommandLine" } %t287, ptr %rv
  br label %ret
bb57:
  %t288 = load %"compiler/target:Target", ptr %l72
  %t289 = load ptr, ptr %l71
  %t290 = getelementptr %"compiler/build:Config", ptr %t289, i32 0, i32 2
  store %"compiler/target:Target" %t288, ptr %t290
  %t291 = load ptr, ptr %l1
  store ptr %t291, ptr %l86
  %t292 = load ptr, ptr %l86
  %t293 = getelementptr %"compiler/build:Config", ptr %t292, i32 0, i32 2
  %t294 = getelementptr %"compiler/target:Target", ptr %t293, i32 0, i32 9
  %t295 = load i1, ptr %t294
  store i1 %t295, ptr %l87
  %t296 = load i1, ptr %l87
  br i1 %t296, label %bb58, label %bb59
bb58:
  %t297 = load ptr, ptr %lp3
  %t298 = getelementptr %"compiler/olang:CommandLine", ptr %t297, i32 0, i32 0
  %t299 = load i64, ptr %t298
  store i64 %t299, ptr %l89
  %t300 = load i64, ptr @G_2ecompiler_2folang_2eCompile
  store i64 %t300, ptr %l90
  %t301 = load i64, ptr %l89
  %t302 = load i64, ptr %l90
  %t303 = icmp ne i64 %t301, %t302
  store i1 %t303, ptr %l91
  %t304 = load i1, ptr %l91
  store i1 %t304, ptr %l88
  br label %bb60
bb59:
  store i1 false, ptr %l88
  br label %bb60
bb60:
  %t305 = load i1, ptr %l88
  br i1 %t305, label %bb61, label %bb62
bb61:
  store %olang.scope zeroinitializer, ptr %s10
  %t306 = load ptr, ptr %l2
  store ptr %t306, ptr %l92
  %t307 = load ptr, ptr %lp3
  %t308 = getelementptr %"compiler/olang:CommandLine", ptr %t307, i32 0, i32 0
  %t309 = load i64, ptr %t308
  store i64 %t309, ptr %l93
  %t310 = load i64, ptr %l93
  %t311 = call { i64, ptr } @compiler_2folang_2emodeName(ptr %s10, i64 %t310)
  store { i64, ptr } %t311, ptr %l94
  br label %bb63
bb62:
  br label %bb68
bb63:
  %t312 = load { i64, ptr }, ptr %l94
  %t313 = extractvalue { i64, ptr } %t312, 0
  %t314 = extractvalue { i64, ptr } %t312, 1
  %t315 = mul i64 %t313, 1
  %t316 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t315)
  call void @llvm.memcpy.p0.p0.i64(ptr %t316, ptr %t314, i64 %t315, i1 false)
  %t317 = insertvalue { i64, ptr } undef, i64 %t313, 0
  %t318 = insertvalue { i64, ptr } %t317, ptr %t316, 1
  store { i64, ptr } %t318, ptr %l95
  %t319 = load ptr, ptr %lp3
  %t320 = getelementptr %"compiler/olang:CommandLine", ptr %t319, i32 0, i32 6
  %t321 = load { i64, ptr }, ptr %t320
  store { i64, ptr } %t321, ptr %l96
  %t322 = load { i64, ptr }, ptr %l95
  %t323 = load { i64, ptr }, ptr %l96
  %t324 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetForeignMode(ptr %s10, ptr %v3, ptr %s10, { i64, ptr } %t322, { i64, ptr } %t323)
  store %"compiler/msgs:Msg" %t324, ptr %l97
  br label %bb64
bb64:
  %t325 = load ptr, ptr %l92
  %t326 = load %"compiler/msgs:Msg", ptr %l97
  %t327 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s10, ptr %t325, %"compiler/msgs:Msg" %t326)
  store i32 %t327, ptr %l98
  %t328 = icmp ne i32 %t327, 0
  br i1 %t328, label %bb66, label %ok.329
ok.329:
  br label %bb65
bb65:
  br label %bb67
bb66:
  %t330 = load i32, ptr %l98
  %t331 = lshr i32 %t330, 16
  %t332 = and i32 %t330, 65535
  %t333 = icmp eq i32 %t331, 1
  %t334 = select i1 %t333, i32 1, i32 0
  %t335 = icmp eq i32 %t330, 0
  %t336 = shl i32 %t334, 16
  %t337 = or i32 %t336, %t332
  %t338 = select i1 %t335, i32 0, i32 %t337
  store i32 %t338, ptr %l99
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  %t339 = load i32, ptr %l99
  %t340 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t339, 0
  store { i32, %"compiler/olang:CommandLine" } %t340, ptr %rv
  br label %ret
bb67:
  call void @__olang_scope_close(ptr %s10)
  br label %bb68
bb68:
  %t341 = load ptr, ptr %l1
  store ptr %t341, ptr %l100
  %t342 = load ptr, ptr %lp3
  %t343 = getelementptr %"compiler/olang:CommandLine", ptr %t342, i32 0, i32 0
  %t344 = load i64, ptr %t343
  store i64 %t344, ptr %l101
  %t345 = load i64, ptr @G_2ecompiler_2folang_2eTest
  store i64 %t345, ptr %l102
  %t346 = load i64, ptr %l101
  %t347 = load i64, ptr %l102
  %t348 = icmp eq i64 %t346, %t347
  store i1 %t348, ptr %l103
  %t349 = load i1, ptr %l103
  %t350 = load ptr, ptr %l100
  %t351 = getelementptr %"compiler/build:Config", ptr %t350, i32 0, i32 8
  store i1 %t349, ptr %t351
  %t352 = load ptr, ptr %l1
  store ptr %t352, ptr %l104
  %t353 = load ptr, ptr %l1
  store ptr %t353, ptr %l105
  %t354 = load ptr, ptr %l105
  %t355 = getelementptr %"compiler/build:Config", ptr %t354, i32 0, i32 8
  %t356 = load i1, ptr %t355
  store i1 %t356, ptr %l106
  %t357 = load ptr, ptr %l2
  store ptr %t357, ptr %l107
  %t358 = load ptr, ptr %l104
  %t359 = load i1, ptr %l106
  %t360 = load ptr, ptr %l107
  %t361 = call i32 @compiler_2folang_2ebuiltins(ptr %v1, ptr %v2, ptr %t358, i1 %t359, ptr %t360)
  store i32 %t361, ptr %l108
  %t362 = icmp ne i32 %t361, 0
  br i1 %t362, label %bb70, label %ok.363
ok.363:
  br label %bb69
bb69:
  br label %bb71
bb70:
  %t364 = load i32, ptr %l108
  %t365 = lshr i32 %t364, 16
  %t366 = and i32 %t364, 65535
  %t367 = icmp eq i32 %t365, 1
  %t368 = select i1 %t367, i32 1, i32 0
  %t369 = icmp eq i32 %t364, 0
  %t370 = shl i32 %t368, 16
  %t371 = or i32 %t370, %t366
  %t372 = select i1 %t369, i32 0, i32 %t371
  store i32 %t372, ptr %l109
  call void @__olang_scope_close(ptr %s0)
  %t373 = load i32, ptr %l109
  %t374 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t373, 0
  store { i32, %"compiler/olang:CommandLine" } %t374, ptr %rv
  br label %ret
bb71:
  %t375 = load ptr, ptr %lp3
  %t376 = load %"compiler/olang:CommandLine", ptr %t375
  store %"compiler/olang:CommandLine" %t376, ptr %l110
  call void @__olang_scope_close(ptr %s0)
  %t377 = load %"compiler/olang:CommandLine", ptr %l110
  %t378 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, %"compiler/olang:CommandLine" %t377, 1
  store { i32, %"compiler/olang:CommandLine" } %t378, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/olang:CommandLine" }, ptr %rv
  ret { i32, %"compiler/olang:CommandLine" } %rr
}

define dso_local void @compiler_2folang_2eRun_2einit() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 0, ptr @G_2ecompiler_2folang_2eRun
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eTest_2einit() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 3, ptr @G_2ecompiler_2folang_2eTest
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2folang_2ebuiltins(ptr %v0, ptr %v1, ptr %a0, i1 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i1
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/target:Target"
  %l8 = alloca [8 x { i64, ptr }]
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i1
  %l15 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l22 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca { i64, ptr }
  %l25 = alloca %"compiler/msgs:Msg"
  %l26 = alloca i32
  %l27 = alloca i32
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca ptr
  %l31 = alloca %"compiler/target:Target"
  %l32 = alloca ptr
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca i1
  %l39 = alloca i64
  %l40 = alloca ptr
  %l41 = alloca i1
  %l42 = alloca ptr
  %l43 = alloca i1
  %l44 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i1 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = insertvalue [8 x { i64, ptr }] undef, { i64, ptr } { i64 8, ptr @.d53 }, 0
  %t2 = insertvalue [8 x { i64, ptr }] %t1, { i64, ptr } { i64 10, ptr @.d54 }, 1
  %t3 = insertvalue [8 x { i64, ptr }] %t2, { i64, ptr } { i64 9, ptr @.d55 }, 2
  %t4 = insertvalue [8 x { i64, ptr }] %t3, { i64, ptr } { i64 16, ptr @.d56 }, 3
  %t5 = insertvalue [8 x { i64, ptr }] %t4, { i64, ptr } { i64 12, ptr @.d57 }, 4
  %t6 = insertvalue [8 x { i64, ptr }] %t5, { i64, ptr } { i64 10, ptr @.d58 }, 5
  %t7 = insertvalue [8 x { i64, ptr }] %t6, { i64, ptr } { i64 9, ptr @.d59 }, 6
  %t8 = insertvalue [8 x { i64, ptr }] %t7, { i64, ptr } { i64 9, ptr @.d60 }, 7
  store [8 x { i64, ptr }] %t8, ptr %l8
  %t9 = load [8 x { i64, ptr }], ptr %l8
  %t10 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 128, i64 8)
  store [8 x { i64, ptr }] %t9, ptr %t10
  store ptr %t10, ptr %l9
  %t11 = load ptr, ptr %l9
  store ptr %t11, ptr %l3
  store i64 0, ptr %l4
  %t12 = load ptr, ptr %l3
  store ptr %t12, ptr %l10
  %t13 = load ptr, ptr %l10
  store i64 8, ptr %l11
  %t14 = load i64, ptr %l11
  store i64 %t14, ptr %l5
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t15 = load i64, ptr %l4
  store i64 %t15, ptr %l12
  %t16 = load i64, ptr %l5
  store i64 %t16, ptr %l13
  %t17 = load i64, ptr %l12
  %t18 = load i64, ptr %l13
  %t19 = icmp slt i64 %t17, %t18
  store i1 %t19, ptr %l14
  %t20 = load i1, ptr %l14
  %t21 = xor i1 %t20, true
  store i1 %t21, ptr %l15
  %t22 = load i1, ptr %l15
  br i1 %t22, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb3:
  br label %bb4
bb4:
  %t23 = load ptr, ptr %l3
  store ptr %t23, ptr %l16
  %t24 = load i64, ptr %l4
  store i64 %t24, ptr %l17
  %t25 = load ptr, ptr %l16
  %t26 = load i64, ptr %l17
  %t27 = getelementptr [8 x { i64, ptr }], ptr %t25, i64 0, i64 %t26
  %t28 = load { i64, ptr }, ptr %t27
  store { i64, ptr } %t28, ptr %l18
  %t29 = load { i64, ptr }, ptr %l18
  store { i64, ptr } %t29, ptr %l6
  %t30 = load ptr, ptr %l0
  store ptr %t30, ptr %l19
  %t31 = load ptr, ptr %l19
  %t32 = getelementptr %"compiler/build:Config", ptr %t31, i32 0, i32 3
  store ptr %t32, ptr %l20
  %t33 = load { i64, ptr }, ptr %l6
  store { i64, ptr } %t33, ptr %l21
  %t34 = load ptr, ptr @__olang_prog_scope
  %t35 = load ptr, ptr %l20
  %t36 = load { i64, ptr }, ptr %l21
  %t37 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eHas(ptr %v0, ptr %t34, ptr %t35, { i64, ptr } %t36)
  store i1 %t37, ptr %l22
  br label %bb5
bb5:
  %t38 = load i1, ptr %l22
  br i1 %t38, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  %t39 = load ptr, ptr %l2
  store ptr %t39, ptr %l23
  %t40 = load { i64, ptr }, ptr %l6
  store { i64, ptr } %t40, ptr %l24
  %t41 = load ptr, ptr @__olang_prog_scope
  %t42 = load { i64, ptr }, ptr %l24
  %t43 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefineBuiltin(ptr %t41, ptr %s3, { i64, ptr } %t42)
  store %"compiler/msgs:Msg" %t43, ptr %l25
  br label %bb8
bb7:
  br label %bb12
bb8:
  %t44 = load ptr, ptr %l23
  %t45 = load %"compiler/msgs:Msg", ptr %l25
  %t46 = call i32 @compiler_2folang_2eusage(ptr %v1, ptr %s3, ptr %t44, %"compiler/msgs:Msg" %t45)
  store i32 %t46, ptr %l26
  %t47 = icmp ne i32 %t46, 0
  br i1 %t47, label %bb10, label %ok.48
ok.48:
  br label %bb9
bb9:
  br label %bb11
bb10:
  %t49 = load i32, ptr %l26
  %t50 = lshr i32 %t49, 16
  %t51 = and i32 %t49, 65535
  %t52 = icmp eq i32 %t50, 1
  %t53 = select i1 %t52, i32 1, i32 0
  %t54 = icmp eq i32 %t49, 0
  %t55 = shl i32 %t53, 16
  %t56 = or i32 %t55, %t51
  %t57 = select i1 %t54, i32 0, i32 %t56
  store i32 %t57, ptr %l27
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t58 = load i32, ptr %l27
  store i32 %t58, ptr %rv
  br label %ret
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s4
  %t59 = load i64, ptr %l4
  store i64 %t59, ptr %l28
  %t60 = load i64, ptr %l28
  %t61 = add i64 %t60, 1
  store i64 %t61, ptr %l29
  %t62 = load i64, ptr %l29
  store i64 %t62, ptr %l4
  call void @__olang_scope_close(ptr %s4)
  br label %bb1
bb14:
  call void @__olang_scope_close(ptr %s1)
  %t63 = load ptr, ptr %l0
  store ptr %t63, ptr %l30
  %t64 = load ptr, ptr %l30
  %t65 = getelementptr %"compiler/build:Config", ptr %t64, i32 0, i32 2
  %t66 = load %"compiler/target:Target", ptr %t65
  store %"compiler/target:Target" %t66, ptr %l31
  %t67 = load %"compiler/target:Target", ptr %l31
  store %"compiler/target:Target" %t67, ptr %l7
  %t68 = load ptr, ptr %l0
  store ptr %t68, ptr %l32
  %t69 = load ptr, ptr %l32
  %t70 = getelementptr %"compiler/build:Config", ptr %t69, i32 0, i32 3
  store ptr %t70, ptr %l33
  %t71 = getelementptr %"compiler/target:Target", ptr %l7, i32 0, i32 3
  %t72 = load { i64, ptr }, ptr %t71
  store { i64, ptr } %t72, ptr %l34
  %t73 = getelementptr %"compiler/target:Target", ptr %l7, i32 0, i32 2
  %t74 = load { i64, ptr }, ptr %t73
  store { i64, ptr } %t74, ptr %l35
  %t75 = getelementptr %"compiler/target:Target", ptr %l7, i32 0, i32 4
  %t76 = load { i64, ptr }, ptr %t75
  store { i64, ptr } %t76, ptr %l36
  %t77 = getelementptr %"compiler/target:Target", ptr %l7, i32 0, i32 7
  %t78 = load i64, ptr %t77
  store i64 %t78, ptr %l37
  %t79 = getelementptr %"compiler/target:Target", ptr %l7, i32 0, i32 8
  %t80 = load i1, ptr %t79
  store i1 %t80, ptr %l38
  %t81 = load i1, ptr %l38
  br i1 %t81, label %bb15, label %bb16
bb15:
  store i64 1, ptr %l39
  br label %bb17
bb16:
  store i64 0, ptr %l39
  br label %bb17
bb17:
  %t82 = load ptr, ptr %l0
  store ptr %t82, ptr %l40
  %t83 = load ptr, ptr %l40
  %t84 = getelementptr %"compiler/build:Config", ptr %t83, i32 0, i32 4
  %t85 = load i1, ptr %t84
  store i1 %t85, ptr %l41
  %t86 = load ptr, ptr %l0
  store ptr %t86, ptr %l42
  %t87 = load ptr, ptr %l42
  %t88 = getelementptr %"compiler/build:Config", ptr %t87, i32 0, i32 5
  %t89 = load i1, ptr %t88
  store i1 %t89, ptr %l43
  %t90 = load i1, ptr %l1
  store i1 %t90, ptr %l44
  %t91 = load ptr, ptr %l33
  %t92 = load { i64, ptr }, ptr %l34
  %t93 = load { i64, ptr }, ptr %l35
  %t94 = load { i64, ptr }, ptr %l36
  %t95 = load i64, ptr %l37
  %t96 = load i64, ptr %l39
  %t97 = load i1, ptr %l41
  %t98 = load i1, ptr %l43
  %t99 = load i1, ptr %l44
  call void @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eBuiltins(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t91, { i64, ptr } %t92, { i64, ptr } %t93, { i64, ptr } %t94, i64 %t95, i64 %t96, i1 %t97, i1 %t98, i1 %t99)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2folang_2echeckOutput(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca %"compiler/msgs:Msg"
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca i64
  %l16 = alloca i1
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i1
  %l21 = alloca i1
  %l22 = alloca i1
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i1
  %l28 = alloca i1
  %l29 = alloca i1
  %l30 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l32 = alloca i1
  %l33 = alloca i1
  %l34 = alloca ptr
  %l35 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l37 = alloca %"compiler/msgs:Msg"
  %l38 = alloca i32
  %l39 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i32
  store { i64, ptr } %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l4
  %t2 = load { i64, ptr }, ptr %l4
  %t3 = call i1 @std_2fos_2eIsDir(ptr %v0, { i64, ptr } %t2)
  store i1 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i1, ptr %l5
  br i1 %t4, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = load ptr, ptr %l1
  store ptr %t5, ptr %l6
  %t6 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t6, ptr %l7
  %t7 = load { i64, ptr }, ptr %l7
  %t8 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eOutputIsDir(ptr %v0, ptr %s1, { i64, ptr } %t7)
  store %"compiler/msgs:Msg" %t8, ptr %l8
  br label %bb4
bb3:
  br label %bb8
bb4:
  %t9 = load ptr, ptr %l6
  %t10 = load %"compiler/msgs:Msg", ptr %l8
  %t11 = call i32 @compiler_2folang_2eusage(ptr %v1, ptr %s1, ptr %t9, %"compiler/msgs:Msg" %t10)
  store i32 %t11, ptr %l9
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb6, label %ok.13
ok.13:
  br label %bb5
bb5:
  br label %bb7
bb6:
  %t14 = load i32, ptr %l9
  %t15 = lshr i32 %t14, 16
  %t16 = and i32 %t14, 65535
  %t17 = icmp eq i32 %t15, 1
  %t18 = select i1 %t17, i32 1, i32 0
  %t19 = icmp eq i32 %t14, 0
  %t20 = shl i32 %t18, 16
  %t21 = or i32 %t20, %t16
  %t22 = select i1 %t19, i32 0, i32 %t21
  store i32 %t22, ptr %l10
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t23 = load i32, ptr %l10
  store i32 %t23, ptr %rv
  br label %ret
bb7:
  call void @__olang_scope_close(ptr %s1)
  br label %bb8
bb8:
  %t24 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t24, ptr %l12
  %t25 = load { i64, ptr }, ptr %l12
  %t26 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %s0, { i64, ptr } %t25, { i64, ptr } { i64 1, ptr @.d61 })
  %t27 = extractvalue { i32, i64 } %t26, 1
  %t28 = extractvalue { i32, i64 } %t26, 0
  store i32 %t28, ptr %l14
  %t29 = icmp ne i32 %t28, 0
  br i1 %t29, label %bb10, label %ok.30
ok.30:
  store i64 %t27, ptr %l13
  br label %bb9
bb9:
  %t31 = load i64, ptr %l13
  store i64 %t31, ptr %l11
  br label %bb12
bb10:
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb12:
  %t32 = load i64, ptr %l11
  store i64 %t32, ptr %l2
  %t33 = load i64, ptr %l2
  store i64 %t33, ptr %l15
  %t34 = load i64, ptr %l15
  %t35 = icmp eq i64 %t34, 0
  store i1 %t35, ptr %l16
  %t36 = load i1, ptr %l16
  br i1 %t36, label %bb13, label %bb14
bb13:
  %t37 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t37, ptr %l18
  %t38 = load { i64, ptr }, ptr %l18
  %t39 = extractvalue { i64, ptr } %t38, 0
  store i64 %t39, ptr %l19
  %t40 = icmp sge i64 0, 0
  store i1 %t40, ptr %l20
  %t41 = load i1, ptr %l20
  br i1 %t41, label %bb15, label %bb16
bb14:
  %t42 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t42, ptr %l24
  %t43 = load i64, ptr %l2
  store i64 %t43, ptr %l25
  %t44 = load { i64, ptr }, ptr %l24
  %t45 = extractvalue { i64, ptr } %t44, 0
  store i64 %t45, ptr %l26
  %t46 = icmp sge i64 0, 0
  store i1 %t46, ptr %l27
  %t47 = load i1, ptr %l27
  br i1 %t47, label %bb21, label %bb22
bb15:
  %t48 = icmp sle i64 0, 1
  store i1 %t48, ptr %l21
  %t49 = load i1, ptr %l21
  br i1 %t49, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @.c62)
  unreachable
bb17:
  %t50 = load i64, ptr %l19
  %t51 = icmp sle i64 1, %t50
  store i1 %t51, ptr %l22
  %t52 = load i1, ptr %l22
  br i1 %t52, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @.c62)
  unreachable
bb19:
  %t53 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t54 = load ptr, ptr %t53
  %t55 = getelementptr i8, ptr %t54, i64 0
  %t56 = sub i64 1, 0
  %t57 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t55, 1
  store { i64, ptr } %t58, ptr %l23
  %t59 = load { i64, ptr }, ptr %l23
  store { i64, ptr } %t59, ptr %l17
  br label %bb27
bb20:
  call void @__olang_check_failed(ptr @.c62)
  unreachable
bb21:
  %t60 = load i64, ptr %l25
  %t61 = icmp sle i64 0, %t60
  store i1 %t61, ptr %l28
  %t62 = load i1, ptr %l28
  br i1 %t62, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @.c62)
  unreachable
bb23:
  %t63 = load i64, ptr %l25
  %t64 = load i64, ptr %l26
  %t65 = icmp sle i64 %t63, %t64
  store i1 %t65, ptr %l29
  %t66 = load i1, ptr %l29
  br i1 %t66, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @.c62)
  unreachable
bb25:
  %t67 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t68 = load ptr, ptr %t67
  %t69 = load i64, ptr %l25
  %t70 = getelementptr i8, ptr %t68, i64 0
  %t71 = sub i64 %t69, 0
  %t72 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t70, 1
  store { i64, ptr } %t73, ptr %l30
  %t74 = load { i64, ptr }, ptr %l30
  store { i64, ptr } %t74, ptr %l17
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @.c62)
  unreachable
bb27:
  %t75 = load { i64, ptr }, ptr %l17
  store { i64, ptr } %t75, ptr %l3
  %t76 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t76, ptr %l31
  %t77 = load { i64, ptr }, ptr %l31
  %t78 = call i1 @std_2fos_2eIsDir(ptr %v0, { i64, ptr } %t77)
  store i1 %t78, ptr %l32
  br label %bb28
bb28:
  %t79 = load i1, ptr %l32
  %t80 = xor i1 %t79, true
  store i1 %t80, ptr %l33
  %t81 = load i1, ptr %l33
  br i1 %t81, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s3
  %t82 = load ptr, ptr %l1
  store ptr %t82, ptr %l34
  %t83 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t83, ptr %l35
  %t84 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t84, ptr %l36
  %t85 = load { i64, ptr }, ptr %l35
  %t86 = load { i64, ptr }, ptr %l36
  %t87 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eOutputNoDir(ptr %v0, ptr %v0, ptr %s3, { i64, ptr } %t85, { i64, ptr } %t86)
  store %"compiler/msgs:Msg" %t87, ptr %l37
  br label %bb31
bb30:
  br label %bb35
bb31:
  %t88 = load ptr, ptr %l34
  %t89 = load %"compiler/msgs:Msg", ptr %l37
  %t90 = call i32 @compiler_2folang_2eusage(ptr %v1, ptr %s3, ptr %t88, %"compiler/msgs:Msg" %t89)
  store i32 %t90, ptr %l38
  %t91 = icmp ne i32 %t90, 0
  br i1 %t91, label %bb33, label %ok.92
ok.92:
  br label %bb32
bb32:
  br label %bb34
bb33:
  %t93 = load i32, ptr %l38
  %t94 = lshr i32 %t93, 16
  %t95 = and i32 %t93, 65535
  %t96 = icmp eq i32 %t94, 1
  %t97 = select i1 %t96, i32 1, i32 0
  %t98 = icmp eq i32 %t93, 0
  %t99 = shl i32 %t97, 16
  %t100 = or i32 %t99, %t95
  %t101 = select i1 %t98, i32 0, i32 %t100
  store i32 %t101, ptr %l39
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t102 = load i32, ptr %l39
  store i32 %t102, ptr %rv
  br label %ret
bb34:
  call void @__olang_scope_close(ptr %s3)
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2folang_2ecompiler_2folang_3aPasses_2eAnalyze(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i32 %a2, ptr %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca %"std/prelude/list:List<compiler/emit:Object>"
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca %"compiler/lower:Gap"
  %l25 = alloca %"compiler/target:Target"
  %l26 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca %"compiler/emit:Object"
  %l33 = alloca { i64, ptr }
  %l34 = alloca i32
  %l35 = alloca i32
  %l36 = alloca i32
  %l37 = alloca ptr
  %l38 = alloca i32
  %l39 = alloca ptr
  %l40 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca ptr
  %l43 = alloca { i64, ptr }
  %l44 = alloca ptr
  %l45 = alloca ptr
  %l46 = alloca ptr
  %l47 = alloca i32
  %l48 = alloca i32
  %l49 = alloca ptr
  %l50 = alloca i1
  %l51 = alloca %"compiler/check:Checker"
  %l52 = alloca ptr
  %l53 = alloca %"std/prelude/map:Map<std/pair:Pair<I64, I64>, Bool>"
  %l54 = alloca ptr
  %l55 = alloca ptr
  %l56 = alloca ptr
  %l57 = alloca i64
  %l58 = alloca ptr
  %l59 = alloca i64
  %l60 = alloca i1
  %l61 = alloca i32
  %l62 = alloca ptr
  %l63 = alloca ptr
  %l64 = alloca ptr
  %l65 = alloca %"std/prelude/list:List<mut compiler/typed:Body&>"
  %l66 = alloca %"compiler/lower:Lowerer"
  %l67 = alloca ptr
  %l68 = alloca ptr
  %l69 = alloca ptr
  %l70 = alloca %"std/prelude/map:Map<std/pair:Pair<I64, I64>, Bool>"
  %l71 = alloca ptr
  %l72 = alloca ptr
  %l73 = alloca ptr
  %l74 = alloca %"std/prelude/list:List<compiler/typed:Plan>"
  %l75 = alloca ptr
  %l76 = alloca i64
  %l77 = alloca i1
  %l78 = alloca i32
  %l79 = alloca ptr
  %l80 = alloca ptr
  %l81 = alloca ptr
  %l82 = alloca ptr
  %l83 = alloca ptr
  %l84 = alloca ptr
  %l85 = alloca ptr
  %l86 = alloca %"compiler/emit:Emitter"
  %l87 = alloca ptr
  %l88 = alloca ptr
  %l89 = alloca i1
  %l90 = alloca ptr
  %l91 = alloca ptr
  %l92 = alloca i1
  %l93 = alloca { i64, ptr }
  %l94 = alloca ptr
  %l95 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l97 = alloca { i64, ptr }
  %l98 = alloca ptr
  %l99 = alloca i32
  %l100 = alloca ptr
  %l101 = alloca i32
  %l102 = alloca ptr
  %l103 = alloca i1
  %l104 = alloca ptr
  %l105 = alloca ptr
  %l106 = alloca { i64, ptr }
  %l107 = alloca ptr
  %l108 = alloca ptr
  %l109 = alloca i1
  %l110 = alloca ptr
  %l111 = alloca %"std/prelude/list:List<compiler/emit:Object>"
  %l112 = alloca ptr
  %l113 = alloca ptr
  %l114 = alloca i64
  %l115 = alloca i1
  %l116 = alloca i1
  %l117 = alloca ptr
  %l118 = alloca ptr
  %l119 = alloca i64
  %l120 = alloca i1
  %l121 = alloca ptr
  %l122 = alloca ptr
  %l123 = alloca { i64, ptr }
  %l124 = alloca ptr
  %l125 = alloca i64
  %l126 = alloca { i64, ptr }
  %l127 = alloca i32
  %l128 = alloca i32
  %l129 = alloca i1
  %l130 = alloca i32
  %l131 = alloca { i64, ptr }
  %l132 = alloca i64
  %l133 = alloca i64
  %l134 = alloca i64
  %l135 = alloca i1
  %l136 = alloca i1
  %l137 = alloca { i64, ptr }
  %l138 = alloca i64
  %l139 = alloca { i64, ptr }
  %l140 = alloca { i64, ptr }
  %l141 = alloca { i64, ptr }
  %l142 = alloca { i64, ptr }
  %l143 = alloca i64
  %l144 = alloca i64
  %l145 = alloca i64
  %l146 = alloca i64
  %l147 = alloca i64
  %l148 = alloca ptr
  %l149 = alloca ptr
  %l150 = alloca { i64, ptr }
  %l151 = alloca ptr
  %l152 = alloca i64
  %l153 = alloca { i64, ptr }
  %l154 = alloca i32
  %l155 = alloca i32
  %l156 = alloca i1
  %l157 = alloca i32
  %l158 = alloca { i64, ptr }
  %l159 = alloca i64
  %l160 = alloca i64
  %l161 = alloca i64
  %l162 = alloca i1
  %l163 = alloca i1
  %l164 = alloca { i64, ptr }
  %l165 = alloca i64
  %l166 = alloca %"compiler/lower:Gap"
  %l167 = alloca ptr
  %l168 = alloca i64
  %l169 = alloca i32
  %l170 = alloca i64
  %l171 = alloca { i64, ptr }
  %l172 = alloca { i64, ptr }
  %l173 = alloca { i64, ptr }
  %l174 = alloca { i64, ptr }
  %l175 = alloca i64
  %l176 = alloca i64
  %l177 = alloca i64
  %l178 = alloca i64
  %l179 = alloca i64
  %l180 = alloca i32
  %l181 = alloca ptr
  %l182 = alloca i64
  %l183 = alloca i1
  %l184 = alloca i32
  %l185 = alloca ptr
  %l186 = alloca %"compiler/target:Target"
  %l187 = alloca ptr
  %l188 = alloca { i64, ptr }
  %l189 = alloca ptr
  %l190 = alloca i64
  %l191 = alloca { i64, ptr }
  %l192 = alloca i32
  %l193 = alloca i32
  %l194 = alloca i1
  %l195 = alloca i32
  %l196 = alloca { i64, ptr }
  %l197 = alloca i64
  %l198 = alloca i64
  %l199 = alloca i64
  %l200 = alloca i1
  %l201 = alloca i1
  %l202 = alloca { i64, ptr }
  %l203 = alloca i64
  %l204 = alloca %"compiler/emit:Object"
  %l205 = alloca { i64, ptr }
  %l206 = alloca { i64, ptr }
  %l207 = alloca { i64, ptr }
  %l208 = alloca { i64, ptr }
  %l209 = alloca i1
  %l210 = alloca i32
  %l211 = alloca i32
  %l212 = alloca i32
  %l213 = alloca i1
  %l214 = alloca i32
  %l215 = alloca i32
  %l216 = alloca i1
  %l217 = alloca i32
  %l218 = alloca i32
  %l219 = alloca i1
  %l220 = alloca i32
  %l221 = alloca i32
  %l222 = alloca i1
  %l223 = alloca i32
  %l224 = alloca ptr
  %l225 = alloca ptr
  %l226 = alloca { i64, ptr }
  %l227 = alloca { i64, ptr }
  %l228 = alloca { i64, ptr }
  %l229 = alloca i32
  %l230 = alloca { i64, ptr }
  %l231 = alloca %"compiler/build:Unit"
  %l232 = alloca i64
  %l233 = alloca i64
  %l234 = alloca i64
  %l235 = alloca i64
  %l236 = alloca i64
  %l237 = alloca ptr
  %l238 = alloca { i64, ptr }
  %l239 = alloca { i64, ptr }
  %l240 = alloca { i64, ptr }
  %l241 = alloca { i64, ptr }
  %l242 = alloca ptr
  %l243 = alloca i1
  %l244 = alloca ptr
  %l245 = alloca i1
  %l246 = alloca { i64, ptr }
  %l247 = alloca i32
  %l248 = alloca i32
  %l249 = alloca i1
  %l250 = alloca i32
  %l251 = alloca i32
  %l252 = alloca { i64, ptr }
  %l253 = alloca i1
  %l254 = alloca ptr
  %l255 = alloca { i64, ptr }
  %l256 = alloca { i64, ptr }
  %l257 = alloca { i64, ptr }
  %l258 = alloca { i64, ptr }
  %l259 = alloca ptr
  %l260 = alloca i1
  %l261 = alloca ptr
  %l262 = alloca i1
  %l263 = alloca { i64, ptr }
  %l264 = alloca i32
  %l265 = alloca i32
  %l266 = alloca i1
  %l267 = alloca i32
  %l268 = alloca i32
  %l269 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.builder
  %s3room = alloca [64 x i8], align 8
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.builder
  %s8room = alloca [64 x i8], align 8
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.builder
  %s13room = alloca [64 x i8], align 8
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.builder
  %s24room = alloca [64 x i8], align 8
  %s25 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %rv = alloca i32
  %t33 = alloca %"compiler/check:Checker", align 8
  %t105 = alloca %"compiler/emit:Emitter", align 8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l2
  store i32 %t1, ptr %l36
  store ptr %l36, ptr %l37
  store i32 2, ptr %l38
  store ptr %l38, ptr %l39
  %t2 = load ptr, ptr %l37
  %t3 = load ptr, ptr %l39
  %t4 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fbuild_3aKind(ptr %t2, ptr %t3)
  store i1 %t4, ptr %l40
  br label %bb1
bb1:
  %t5 = load i1, ptr %l40
  store i1 %t5, ptr %l6
  %t6 = load ptr, ptr %l0
  store ptr %t6, ptr %l42
  %t7 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t7, ptr %l43
  %t8 = load ptr, ptr %l3
  store ptr %t8, ptr %l44
  %t9 = load ptr, ptr %l5
  store ptr %t9, ptr %l45
  %t10 = load ptr, ptr %l42
  %t11 = load { i64, ptr }, ptr %l43
  %t12 = load ptr, ptr %l44
  %t13 = load ptr, ptr %l45
  %t14 = call { i32, ptr } @compiler_2folang_2ecompiler_2folang_3aPasses_2eload(ptr %v0, ptr %v1, ptr %v2, ptr %t10, { i64, ptr } %t11, ptr %t12, ptr %t13)
  %t15 = extractvalue { i32, ptr } %t14, 1
  %t16 = extractvalue { i32, ptr } %t14, 0
  store i32 %t16, ptr %l47
  %t17 = icmp ne i32 %t16, 0
  br i1 %t17, label %bb3, label %ok.18
ok.18:
  store ptr %t15, ptr %l46
  br label %bb2
bb2:
  %t19 = load ptr, ptr %l46
  store ptr %t19, ptr %l41
  br label %bb4
bb3:
  %t20 = load i32, ptr %l47
  %t21 = lshr i32 %t20, 16
  %t22 = and i32 %t20, 65535
  %t23 = icmp eq i32 %t21, 1
  %t24 = select i1 %t23, i32 1, i32 0
  %t25 = icmp eq i32 %t20, 0
  %t26 = shl i32 %t24, 16
  %t27 = or i32 %t26, %t22
  %t28 = select i1 %t25, i32 0, i32 %t27
  store i32 %t28, ptr %l48
  call void @__olang_scope_close(ptr %s0)
  %t29 = load i32, ptr %l48
  store i32 %t29, ptr %rv
  br label %ret
bb4:
  %t30 = load ptr, ptr %l41
  store ptr %t30, ptr %l7
  %t31 = load ptr, ptr %l7
  store ptr %t31, ptr %l49
  %t32 = load i1, ptr %l6
  store i1 %t32, ptr %l50
  %t34 = load ptr, ptr %l49
  %t35 = load i1, ptr %l50
  call void @compiler_2finterp_2eAnalyze(ptr %t33, ptr %v2, ptr %v2, ptr %t34, i1 %t35)
  %t36 = load %"compiler/check:Checker", ptr %t33
  store %"compiler/check:Checker" %t36, ptr %l51
  br label %bb5
bb5:
  %t37 = load %"compiler/check:Checker", ptr %l51
  %t38 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 432, i64 8)
  store %"compiler/check:Checker" %t37, ptr %t38
  store ptr %t38, ptr %l52
  %t39 = load ptr, ptr %l52
  store ptr %t39, ptr %l8
  %t40 = call %"std/prelude/map:Map<std/pair:Pair<I64, I64>, Bool>" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v2)
  store %"std/prelude/map:Map<std/pair:Pair<I64, I64>, Bool>" %t40, ptr %l53
  br label %bb6
bb6:
  %t41 = load %"std/prelude/map:Map<std/pair:Pair<I64, I64>, Bool>", ptr %l53
  %t42 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store %"std/prelude/map:Map<std/pair:Pair<I64, I64>, Bool>" %t41, ptr %t42
  store ptr %t42, ptr %l54
  %t43 = load ptr, ptr %l54
  store ptr %t43, ptr %l9
  %t44 = load ptr, ptr %l8
  store ptr %t44, ptr %l55
  %t45 = load ptr, ptr %l9
  store ptr %t45, ptr %l56
  %t46 = load ptr, ptr %l55
  %t47 = load ptr, ptr %l56
  %t48 = call i64 @compiler_2finterp_2eDecideAsserts(ptr %v2, ptr %v2, ptr %t46, ptr %t47)
  store i64 %t48, ptr %l57
  br label %bb7
bb7:
  %t49 = load ptr, ptr %l5
  store ptr %t49, ptr %l58
  %t50 = load ptr, ptr %l58
  %t51 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v2, ptr %t50)
  store i64 %t51, ptr %l59
  br label %bb8
bb8:
  %t52 = load i64, ptr %l59
  %t53 = icmp sgt i64 %t52, 0
  store i1 %t53, ptr %l60
  %t54 = load i1, ptr %l60
  br i1 %t54, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s1
  store i32 65536, ptr %l61
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t55 = load i32, ptr %l61
  store i32 %t55, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t56 = load ptr, ptr %l8
  store ptr %t56, ptr %l62
  %t57 = load ptr, ptr %l62
  %t58 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 0
  %t59 = load ptr, ptr %t58
  store ptr %t59, ptr %l63
  %t60 = load ptr, ptr %l8
  store ptr %t60, ptr %l64
  %t61 = load ptr, ptr %l64
  %t62 = getelementptr %"compiler/check:Checker", ptr %t61, i32 0, i32 4
  %t63 = load %"std/prelude/list:List<mut compiler/typed:Body&>", ptr %t62
  store %"std/prelude/list:List<mut compiler/typed:Body&>" %t63, ptr %l65
  %t64 = load ptr, ptr %l63
  %t65 = load %"std/prelude/list:List<mut compiler/typed:Body&>", ptr %l65
  %t66 = call %"compiler/lower:Lowerer" @compiler_2flower_3aLowerer_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %t64, %"std/prelude/list:List<mut compiler/typed:Body&>" %t65)
  store %"compiler/lower:Lowerer" %t66, ptr %l66
  br label %bb12
bb12:
  %t67 = load %"compiler/lower:Lowerer", ptr %l66
  %t68 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 96, i64 8)
  store %"compiler/lower:Lowerer" %t67, ptr %t68
  store ptr %t68, ptr %l67
  %t69 = load ptr, ptr %l67
  store ptr %t69, ptr %l10
  %t70 = load ptr, ptr %l10
  store ptr %t70, ptr %l68
  %t71 = load ptr, ptr %l9
  store ptr %t71, ptr %l69
  %t72 = load ptr, ptr %l69
  %t73 = load %"std/prelude/map:Map<std/pair:Pair<I64, I64>, Bool>", ptr %t72
  store %"std/prelude/map:Map<std/pair:Pair<I64, I64>, Bool>" %t73, ptr %l70
  %t74 = load %"std/prelude/map:Map<std/pair:Pair<I64, I64>, Bool>", ptr %l70
  %t75 = load ptr, ptr %l68
  %t76 = getelementptr %"compiler/lower:Lowerer", ptr %t75, i32 0, i32 5
  store %"std/prelude/map:Map<std/pair:Pair<I64, I64>, Bool>" %t74, ptr %t76
  %t77 = load ptr, ptr %l10
  store ptr %t77, ptr %l71
  %t78 = load ptr, ptr %l8
  store ptr %t78, ptr %l72
  %t79 = load ptr, ptr %l3
  store ptr %t79, ptr %l73
  %t80 = load ptr, ptr %l72
  %t81 = load ptr, ptr %l73
  %t82 = call %"std/prelude/list:List<compiler/typed:Plan>" @compiler_2folang_2eplacement(ptr %v2, ptr %v2, ptr %v2, ptr %t80, ptr %t81)
  store %"std/prelude/list:List<compiler/typed:Plan>" %t82, ptr %l74
  br label %bb13
bb13:
  %t83 = load %"std/prelude/list:List<compiler/typed:Plan>", ptr %l74
  %t84 = load ptr, ptr %l71
  %t85 = getelementptr %"compiler/lower:Lowerer", ptr %t84, i32 0, i32 2
  store %"std/prelude/list:List<compiler/typed:Plan>" %t83, ptr %t85
  %t86 = load ptr, ptr %l5
  store ptr %t86, ptr %l75
  %t87 = load ptr, ptr %l75
  %t88 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v2, ptr %t87)
  store i64 %t88, ptr %l76
  br label %bb14
bb14:
  %t89 = load i64, ptr %l76
  %t90 = icmp sgt i64 %t89, 0
  store i1 %t90, ptr %l77
  %t91 = load i1, ptr %l77
  br i1 %t91, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  store i32 65536, ptr %l78
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t92 = load i32, ptr %l78
  store i32 %t92, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t93 = load ptr, ptr %l8
  store ptr %t93, ptr %l79
  %t94 = load ptr, ptr %l79
  %t95 = getelementptr %"compiler/check:Checker", ptr %t94, i32 0, i32 0
  %t96 = load ptr, ptr %t95
  store ptr %t96, ptr %l80
  %t97 = load ptr, ptr %l10
  store ptr %t97, ptr %l81
  %t98 = load ptr, ptr %l5
  store ptr %t98, ptr %l82
  %t99 = load ptr, ptr %l8
  store ptr %t99, ptr %l83
  %t100 = load ptr, ptr %l83
  %t101 = getelementptr %"compiler/check:Checker", ptr %t100, i32 0, i32 0
  %t102 = load ptr, ptr %t101
  store ptr %t102, ptr %l84
  %t103 = load ptr, ptr %l84
  %t104 = getelementptr %"compiler/generic:Program", ptr %t103, i32 0, i32 2
  store ptr %t104, ptr %l85
  %t106 = load ptr, ptr %l80
  %t107 = load ptr, ptr %l81
  %t108 = load ptr, ptr %l82
  %t109 = load ptr, ptr %l85
  call void @compiler_2femit_3aEmitter_2ector(ptr %t105, ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %t106, ptr %t107, ptr %t108, ptr %t109)
  %t110 = load %"compiler/emit:Emitter", ptr %t105
  store %"compiler/emit:Emitter" %t110, ptr %l86
  br label %bb18
bb18:
  %t111 = load %"compiler/emit:Emitter", ptr %l86
  %t112 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 360, i64 8)
  store %"compiler/emit:Emitter" %t111, ptr %t112
  store ptr %t112, ptr %l87
  %t113 = load ptr, ptr %l87
  store ptr %t113, ptr %l11
  %t114 = load ptr, ptr %l11
  store ptr %t114, ptr %l88
  %t115 = load i1, ptr %l6
  store i1 %t115, ptr %l89
  %t116 = load i1, ptr %l89
  %t117 = load ptr, ptr %l88
  %t118 = getelementptr %"compiler/emit:Emitter", ptr %t117, i32 0, i32 4
  store i1 %t116, ptr %t118
  %t119 = load ptr, ptr %l11
  store ptr %t119, ptr %l90
  %t120 = load ptr, ptr %l3
  store ptr %t120, ptr %l91
  %t121 = load ptr, ptr %l91
  %t122 = getelementptr %"compiler/build:Config", ptr %t121, i32 0, i32 5
  %t123 = load i1, ptr %t122
  store i1 %t123, ptr %l92
  %t124 = load i1, ptr %l92
  br i1 %t124, label %bb19, label %bb20
bb19:
  store { i64, ptr } { i64 16, ptr @.d63 }, ptr %l93
  br label %bb21
bb20:
  store { i64, ptr } { i64 0, ptr @.d64 }, ptr %l93
  br label %bb21
bb21:
  %t125 = load ptr, ptr %l3
  store ptr %t125, ptr %l94
  %t126 = load ptr, ptr %l94
  %t127 = getelementptr %"compiler/build:Config", ptr %t126, i32 0, i32 2
  %t128 = getelementptr %"compiler/target:Target", ptr %t127, i32 0, i32 5
  %t129 = load { i64, ptr }, ptr %t128
  store { i64, ptr } %t129, ptr %l95
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s3
  store ptr %s3room, ptr %s3
  %t130 = load { i64, ptr }, ptr %l93
  %t131 = extractvalue { i64, ptr } %t130, 1
  %t132 = extractvalue { i64, ptr } %t130, 0
  call void @__olang_sb_put(ptr %s3, ptr %t131, i64 %t132)
  %t133 = load { i64, ptr }, ptr %l95
  %t134 = extractvalue { i64, ptr } %t133, 1
  %t135 = extractvalue { i64, ptr } %t133, 0
  call void @__olang_sb_put(ptr %s3, ptr %t134, i64 %t135)
  %t136 = load ptr, ptr %s3
  %t137 = getelementptr %olang.builder, ptr %s3, i32 0, i32 1
  %t138 = load i64, ptr %t137
  %t139 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t138)
  call void @llvm.memcpy.p0.p0.i64(ptr %t139, ptr %t136, i64 %t138, i1 false)
  %t140 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t141 = insertvalue { i64, ptr } %t140, ptr %t139, 1
  store { i64, ptr } %t141, ptr %l96
  call void @__olang_sb_done(ptr %s3)
  %t142 = load { i64, ptr }, ptr %l96
  %t143 = extractvalue { i64, ptr } %t142, 0
  %t144 = extractvalue { i64, ptr } %t142, 1
  %t145 = mul i64 %t143, 1
  %t146 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t145)
  call void @llvm.memcpy.p0.p0.i64(ptr %t146, ptr %t144, i64 %t145, i1 false)
  %t147 = insertvalue { i64, ptr } undef, i64 %t143, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t146, 1
  store { i64, ptr } %t148, ptr %l97
  %t149 = load { i64, ptr }, ptr %l97
  %t150 = load ptr, ptr %l90
  %t151 = getelementptr %"compiler/emit:Emitter", ptr %t150, i32 0, i32 6
  store { i64, ptr } %t149, ptr %t151
  %t152 = load ptr, ptr %l11
  store ptr %t152, ptr %l98
  %t153 = load i32, ptr %l2
  store i32 %t153, ptr %l99
  store ptr %l99, ptr %l100
  store i32 0, ptr %l101
  store ptr %l101, ptr %l102
  %t154 = load ptr, ptr %l100
  %t155 = load ptr, ptr %l102
  %t156 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fbuild_3aKind(ptr %t154, ptr %t155)
  store i1 %t156, ptr %l103
  br label %bb22
bb22:
  %t157 = load i1, ptr %l103
  %t158 = load ptr, ptr %l98
  %t159 = getelementptr %"compiler/emit:Emitter", ptr %t158, i32 0, i32 41
  store i1 %t157, ptr %t159
  %t160 = load ptr, ptr %l11
  store ptr %t160, ptr %l104
  %t161 = load ptr, ptr %l3
  store ptr %t161, ptr %l105
  %t162 = load ptr, ptr %l105
  %t163 = getelementptr %"compiler/build:Config", ptr %t162, i32 0, i32 2
  %t164 = getelementptr %"compiler/target:Target", ptr %t163, i32 0, i32 1
  %t165 = load { i64, ptr }, ptr %t164
  store { i64, ptr } %t165, ptr %l106
  %t166 = load { i64, ptr }, ptr %l106
  %t167 = load ptr, ptr %l104
  %t168 = getelementptr %"compiler/emit:Emitter", ptr %t167, i32 0, i32 24
  store { i64, ptr } %t166, ptr %t168
  %t169 = load ptr, ptr %l11
  store ptr %t169, ptr %l107
  %t170 = load ptr, ptr %l3
  store ptr %t170, ptr %l108
  %t171 = load ptr, ptr %l108
  %t172 = getelementptr %"compiler/build:Config", ptr %t171, i32 0, i32 4
  %t173 = load i1, ptr %t172
  store i1 %t173, ptr %l109
  %t174 = load i1, ptr %l109
  %t175 = load ptr, ptr %l107
  %t176 = getelementptr %"compiler/emit:Emitter", ptr %t175, i32 0, i32 5
  store i1 %t174, ptr %t176
  %t177 = load ptr, ptr %l11
  store ptr %t177, ptr %l110
  %t178 = load ptr, ptr %l110
  %t179 = call %"std/prelude/list:List<compiler/emit:Object>" @compiler_2femit_2ecompiler_2femit_3aEmitter_2eObjects(ptr %v2, ptr %v3, ptr %t178)
  store %"std/prelude/list:List<compiler/emit:Object>" %t179, ptr %l111
  br label %bb23
bb23:
  %t180 = load %"std/prelude/list:List<compiler/emit:Object>", ptr %l111
  store %"std/prelude/list:List<compiler/emit:Object>" %t180, ptr %l12
  %t181 = load ptr, ptr %l11
  store ptr %t181, ptr %l112
  %t182 = load ptr, ptr %l112
  %t183 = getelementptr %"compiler/emit:Emitter", ptr %t182, i32 0, i32 7
  store ptr %t183, ptr %l113
  %t184 = load ptr, ptr %l113
  %t185 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v2, ptr %t184)
  store i64 %t185, ptr %l114
  br label %bb24
bb24:
  %t186 = load i64, ptr %l114
  %t187 = icmp sgt i64 %t186, 0
  store i1 %t187, ptr %l115
  %t188 = load i1, ptr %l115
  br i1 %t188, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l116
  br label %bb28
bb26:
  %t189 = load ptr, ptr %l10
  store ptr %t189, ptr %l117
  %t190 = load ptr, ptr %l117
  %t191 = getelementptr %"compiler/lower:Lowerer", ptr %t190, i32 0, i32 3
  store ptr %t191, ptr %l118
  %t192 = load ptr, ptr %l118
  %t193 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3aGap_3e_2eLen_3ccompiler_2flower_3aGap_3e(ptr %v2, ptr %t192)
  store i64 %t193, ptr %l119
  br label %bb27
bb27:
  %t194 = load i64, ptr %l119
  %t195 = icmp sgt i64 %t194, 0
  store i1 %t195, ptr %l120
  %t196 = load i1, ptr %l120
  store i1 %t196, ptr %l116
  br label %bb28
bb28:
  %t197 = load i1, ptr %l116
  br i1 %t197, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s4
  store %olang.scope zeroinitializer, ptr %s5
  %t198 = load ptr, ptr %l11
  store ptr %t198, ptr %l121
  %t199 = load ptr, ptr %l121
  %t200 = getelementptr %"compiler/emit:Emitter", ptr %t199, i32 0, i32 7
  store ptr %t200, ptr %l122
  %t201 = load ptr, ptr %l122
  store ptr %t201, ptr %l13
  store i64 0, ptr %l14
  br label %bb31
bb30:
  br label %bb64
bb31:
  store %olang.scope zeroinitializer, ptr %s6
  %t202 = load ptr, ptr %l13
  store ptr %t202, ptr %l124
  %t203 = load i64, ptr %l14
  store i64 %t203, ptr %l125
  %t204 = load ptr, ptr %l124
  %t205 = load i64, ptr %l125
  %t206 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v2, ptr %t204, i64 %t205)
  %t207 = extractvalue { i32, { i64, ptr } } %t206, 1
  %t208 = extractvalue { i32, { i64, ptr } } %t206, 0
  store i32 %t208, ptr %l127
  %t209 = icmp ne i32 %t208, 0
  br i1 %t209, label %bb33, label %ok.210
ok.210:
  store { i64, ptr } %t207, ptr %l126
  br label %bb32
bb32:
  %t211 = load { i64, ptr }, ptr %l126
  store { i64, ptr } %t211, ptr %l123
  br label %bb37
bb33:
  %t212 = load i32, ptr %l127
  %t213 = ashr i32 %t212, 16
  store i32 %t213, ptr %l128
  %t214 = load i32, ptr %l128
  %t215 = icmp eq i32 %t214, 1
  store i1 %t215, ptr %l129
  %t216 = load i1, ptr %l129
  br i1 %t216, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  %t217 = load i32, ptr %l127
  %t218 = lshr i32 %t217, 16
  %t219 = and i32 %t217, 65535
  %t220 = icmp eq i32 %t218, 1
  %t221 = select i1 %t220, i32 0, i32 0
  %t222 = icmp eq i32 %t217, 0
  %t223 = shl i32 %t221, 16
  %t224 = or i32 %t223, %t219
  %t225 = select i1 %t222, i32 0, i32 %t224
  store i32 %t225, ptr %l130
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t226 = load i32, ptr %l130
  store i32 %t226, ptr %rv
  br label %ret
bb36:
  call void @__olang_scope_close(ptr %s6)
  br label %bb46
bb37:
  %t227 = load { i64, ptr }, ptr %l123
  store { i64, ptr } %t227, ptr %l15
  %t228 = load { i64, ptr }, ptr %l15
  store { i64, ptr } %t228, ptr %l131
  %t229 = load { i64, ptr }, ptr %l131
  %t230 = extractvalue { i64, ptr } %t229, 0
  store i64 %t230, ptr %l132
  %t231 = load i64, ptr %l132
  store i64 %t231, ptr %l16
  store i64 0, ptr %l17
  br label %bb38
bb38:
  store %olang.scope zeroinitializer, ptr %s7
  %t232 = load i64, ptr %l17
  store i64 %t232, ptr %l133
  %t233 = load i64, ptr %l16
  store i64 %t233, ptr %l134
  %t234 = load i64, ptr %l133
  %t235 = load i64, ptr %l134
  %t236 = icmp slt i64 %t234, %t235
  store i1 %t236, ptr %l135
  %t237 = load i1, ptr %l135
  %t238 = xor i1 %t237, true
  store i1 %t238, ptr %l136
  %t239 = load i1, ptr %l136
  br i1 %t239, label %bb39, label %bb40
bb39:
  call void @__olang_scope_close(ptr %s7)
  br label %bb44
bb40:
  br label %bb41
bb41:
  %t240 = load { i64, ptr }, ptr %l15
  store { i64, ptr } %t240, ptr %l137
  %t241 = load i64, ptr %l17
  store i64 %t241, ptr %l138
  %t242 = load i64, ptr %l138
  %t243 = getelementptr { i64, ptr }, ptr %l137, i32 0, i32 1
  %t244 = load ptr, ptr %t243
  %t245 = getelementptr { i64, ptr }, ptr %t244, i64 %t242
  %t246 = load { i64, ptr }, ptr %t245
  store { i64, ptr } %t246, ptr %l139
  %t247 = load { i64, ptr }, ptr %l139
  store { i64, ptr } %t247, ptr %l18
  %t248 = load { i64, ptr }, ptr %l18
  store { i64, ptr } %t248, ptr %l140
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s8
  store ptr %s8room, ptr %s8
  %t249 = extractvalue { i64, ptr } { i64 17, ptr @.d65 }, 1
  %t250 = extractvalue { i64, ptr } { i64 17, ptr @.d65 }, 0
  call void @__olang_sb_put(ptr %s8, ptr %t249, i64 %t250)
  %t251 = load { i64, ptr }, ptr %l140
  %t252 = extractvalue { i64, ptr } %t251, 1
  %t253 = extractvalue { i64, ptr } %t251, 0
  call void @__olang_sb_put(ptr %s8, ptr %t252, i64 %t253)
  %t254 = extractvalue { i64, ptr } { i64 4, ptr @.d66 }, 1
  %t255 = extractvalue { i64, ptr } { i64 4, ptr @.d66 }, 0
  call void @__olang_sb_put(ptr %s8, ptr %t254, i64 %t255)
  %t256 = load ptr, ptr %s8
  %t257 = getelementptr %olang.builder, ptr %s8, i32 0, i32 1
  %t258 = load i64, ptr %t257
  %t259 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t258)
  call void @llvm.memcpy.p0.p0.i64(ptr %t259, ptr %t256, i64 %t258, i1 false)
  %t260 = insertvalue { i64, ptr } undef, i64 %t258, 0
  %t261 = insertvalue { i64, ptr } %t260, ptr %t259, 1
  store { i64, ptr } %t261, ptr %l141
  call void @__olang_sb_done(ptr %s8)
  %t262 = load { i64, ptr }, ptr %l141
  %t263 = extractvalue { i64, ptr } %t262, 0
  %t264 = extractvalue { i64, ptr } %t262, 1
  %t265 = mul i64 %t263, 1
  %t266 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t265)
  call void @llvm.memcpy.p0.p0.i64(ptr %t266, ptr %t264, i64 %t265, i1 false)
  %t267 = insertvalue { i64, ptr } undef, i64 %t263, 0
  %t268 = insertvalue { i64, ptr } %t267, ptr %t266, 1
  store { i64, ptr } %t268, ptr %l142
  %t269 = load { i64, ptr }, ptr %l142
  call void @compiler_2fbuild_2eUnbuildable(ptr %s7, { i64, ptr } %t269)
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s7)
  br label %bb43
bb43:
  store %olang.scope zeroinitializer, ptr %s9
  %t270 = load i64, ptr %l17
  store i64 %t270, ptr %l143
  %t271 = load i64, ptr %l143
  %t272 = add i64 %t271, 1
  store i64 %t272, ptr %l144
  %t273 = load i64, ptr %l144
  store i64 %t273, ptr %l17
  call void @__olang_scope_close(ptr %s9)
  br label %bb38
bb44:
  %t274 = load i64, ptr %l14
  store i64 %t274, ptr %l145
  %t275 = load i64, ptr %l16
  store i64 %t275, ptr %l146
  %t276 = load i64, ptr %l145
  %t277 = load i64, ptr %l146
  %t278 = add i64 %t276, %t277
  store i64 %t278, ptr %l147
  %t279 = load i64, ptr %l147
  store i64 %t279, ptr %l14
  call void @__olang_scope_close(ptr %s6)
  br label %bb45
bb45:
  br label %bb31
bb46:
  call void @__olang_scope_close(ptr %s5)
  store %olang.scope zeroinitializer, ptr %s10
  %t280 = load ptr, ptr %l10
  store ptr %t280, ptr %l148
  %t281 = load ptr, ptr %l148
  %t282 = getelementptr %"compiler/lower:Lowerer", ptr %t281, i32 0, i32 3
  store ptr %t282, ptr %l149
  %t283 = load ptr, ptr %l149
  store ptr %t283, ptr %l19
  store i64 0, ptr %l20
  br label %bb47
bb47:
  store %olang.scope zeroinitializer, ptr %s11
  %t284 = load ptr, ptr %l19
  store ptr %t284, ptr %l151
  %t285 = load i64, ptr %l20
  store i64 %t285, ptr %l152
  %t286 = load ptr, ptr %l151
  %t287 = load i64, ptr %l152
  %t288 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3aGap_3e_2eRunFrom_3ccompiler_2flower_3aGap_3e(ptr %v2, ptr %t286, i64 %t287)
  %t289 = extractvalue { i32, { i64, ptr } } %t288, 1
  %t290 = extractvalue { i32, { i64, ptr } } %t288, 0
  store i32 %t290, ptr %l154
  %t291 = icmp ne i32 %t290, 0
  br i1 %t291, label %bb49, label %ok.292
ok.292:
  store { i64, ptr } %t289, ptr %l153
  br label %bb48
bb48:
  %t293 = load { i64, ptr }, ptr %l153
  store { i64, ptr } %t293, ptr %l150
  br label %bb53
bb49:
  %t294 = load i32, ptr %l154
  %t295 = ashr i32 %t294, 16
  store i32 %t295, ptr %l155
  %t296 = load i32, ptr %l155
  %t297 = icmp eq i32 %t296, 1
  store i1 %t297, ptr %l156
  %t298 = load i1, ptr %l156
  br i1 %t298, label %bb50, label %bb51
bb50:
  br label %bb52
bb51:
  %t299 = load i32, ptr %l154
  %t300 = lshr i32 %t299, 16
  %t301 = and i32 %t299, 65535
  %t302 = icmp eq i32 %t300, 1
  %t303 = select i1 %t302, i32 0, i32 0
  %t304 = icmp eq i32 %t299, 0
  %t305 = shl i32 %t303, 16
  %t306 = or i32 %t305, %t301
  %t307 = select i1 %t304, i32 0, i32 %t306
  store i32 %t307, ptr %l157
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t308 = load i32, ptr %l157
  store i32 %t308, ptr %rv
  br label %ret
bb52:
  call void @__olang_scope_close(ptr %s11)
  br label %bb63
bb53:
  %t309 = load { i64, ptr }, ptr %l150
  store { i64, ptr } %t309, ptr %l21
  %t310 = load { i64, ptr }, ptr %l21
  store { i64, ptr } %t310, ptr %l158
  %t311 = load { i64, ptr }, ptr %l158
  %t312 = extractvalue { i64, ptr } %t311, 0
  store i64 %t312, ptr %l159
  %t313 = load i64, ptr %l159
  store i64 %t313, ptr %l22
  store i64 0, ptr %l23
  br label %bb54
bb54:
  store %olang.scope zeroinitializer, ptr %s12
  %t314 = load i64, ptr %l23
  store i64 %t314, ptr %l160
  %t315 = load i64, ptr %l22
  store i64 %t315, ptr %l161
  %t316 = load i64, ptr %l160
  %t317 = load i64, ptr %l161
  %t318 = icmp slt i64 %t316, %t317
  store i1 %t318, ptr %l162
  %t319 = load i1, ptr %l162
  %t320 = xor i1 %t319, true
  store i1 %t320, ptr %l163
  %t321 = load i1, ptr %l163
  br i1 %t321, label %bb55, label %bb56
bb55:
  call void @__olang_scope_close(ptr %s12)
  br label %bb61
bb56:
  br label %bb57
bb57:
  %t322 = load { i64, ptr }, ptr %l21
  store { i64, ptr } %t322, ptr %l164
  %t323 = load i64, ptr %l23
  store i64 %t323, ptr %l165
  %t324 = load i64, ptr %l165
  %t325 = getelementptr { i64, ptr }, ptr %l164, i32 0, i32 1
  %t326 = load ptr, ptr %t325
  %t327 = getelementptr %"compiler/lower:Gap", ptr %t326, i64 %t324
  %t328 = load %"compiler/lower:Gap", ptr %t327
  store %"compiler/lower:Gap" %t328, ptr %l166
  %t329 = load %"compiler/lower:Gap", ptr %l166
  store %"compiler/lower:Gap" %t329, ptr %l24
  %t330 = load ptr, ptr %l5
  store ptr %t330, ptr %l167
  %t331 = getelementptr %"compiler/lower:Gap", ptr %l24, i32 0, i32 0
  %t332 = load i64, ptr %t331
  store i64 %t332, ptr %l168
  %t333 = getelementptr %"compiler/lower:Gap", ptr %l24, i32 0, i32 1
  %t334 = getelementptr %"compiler/source:Span", ptr %t333, i32 0, i32 0
  %t335 = load i32, ptr %t334
  store i32 %t335, ptr %l169
  %t336 = load i32, ptr %l169
  %t337 = sext i32 %t336 to i64
  store i64 %t337, ptr %l170
  %t338 = load ptr, ptr %l167
  %t339 = load i64, ptr %l168
  %t340 = load i64, ptr %l170
  %t341 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v2, ptr %s12, ptr %t338, i64 %t339, i64 %t340)
  store { i64, ptr } %t341, ptr %l171
  br label %bb58
bb58:
  %t342 = getelementptr %"compiler/lower:Gap", ptr %l24, i32 0, i32 2
  %t343 = load { i64, ptr }, ptr %t342
  store { i64, ptr } %t343, ptr %l172
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s13
  store ptr %s13room, ptr %s13
  %t344 = load { i64, ptr }, ptr %l171
  %t345 = extractvalue { i64, ptr } %t344, 1
  %t346 = extractvalue { i64, ptr } %t344, 0
  call void @__olang_sb_put(ptr %s13, ptr %t345, i64 %t346)
  %t347 = extractvalue { i64, ptr } { i64 20, ptr @.d67 }, 1
  %t348 = extractvalue { i64, ptr } { i64 20, ptr @.d67 }, 0
  call void @__olang_sb_put(ptr %s13, ptr %t347, i64 %t348)
  %t349 = load { i64, ptr }, ptr %l172
  %t350 = extractvalue { i64, ptr } %t349, 1
  %t351 = extractvalue { i64, ptr } %t349, 0
  call void @__olang_sb_put(ptr %s13, ptr %t350, i64 %t351)
  %t352 = extractvalue { i64, ptr } { i64 4, ptr @.d68 }, 1
  %t353 = extractvalue { i64, ptr } { i64 4, ptr @.d68 }, 0
  call void @__olang_sb_put(ptr %s13, ptr %t352, i64 %t353)
  %t354 = load ptr, ptr %s13
  %t355 = getelementptr %olang.builder, ptr %s13, i32 0, i32 1
  %t356 = load i64, ptr %t355
  %t357 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t356)
  call void @llvm.memcpy.p0.p0.i64(ptr %t357, ptr %t354, i64 %t356, i1 false)
  %t358 = insertvalue { i64, ptr } undef, i64 %t356, 0
  %t359 = insertvalue { i64, ptr } %t358, ptr %t357, 1
  store { i64, ptr } %t359, ptr %l173
  call void @__olang_sb_done(ptr %s13)
  %t360 = load { i64, ptr }, ptr %l173
  %t361 = extractvalue { i64, ptr } %t360, 0
  %t362 = extractvalue { i64, ptr } %t360, 1
  %t363 = mul i64 %t361, 1
  %t364 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t363)
  call void @llvm.memcpy.p0.p0.i64(ptr %t364, ptr %t362, i64 %t363, i1 false)
  %t365 = insertvalue { i64, ptr } undef, i64 %t361, 0
  %t366 = insertvalue { i64, ptr } %t365, ptr %t364, 1
  store { i64, ptr } %t366, ptr %l174
  %t367 = load { i64, ptr }, ptr %l174
  call void @compiler_2fbuild_2eUnbuildable(ptr %s12, { i64, ptr } %t367)
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s12)
  br label %bb60
bb60:
  store %olang.scope zeroinitializer, ptr %s14
  %t368 = load i64, ptr %l23
  store i64 %t368, ptr %l175
  %t369 = load i64, ptr %l175
  %t370 = add i64 %t369, 1
  store i64 %t370, ptr %l176
  %t371 = load i64, ptr %l176
  store i64 %t371, ptr %l23
  call void @__olang_scope_close(ptr %s14)
  br label %bb54
bb61:
  %t372 = load i64, ptr %l20
  store i64 %t372, ptr %l177
  %t373 = load i64, ptr %l22
  store i64 %t373, ptr %l178
  %t374 = load i64, ptr %l177
  %t375 = load i64, ptr %l178
  %t376 = add i64 %t374, %t375
  store i64 %t376, ptr %l179
  %t377 = load i64, ptr %l179
  store i64 %t377, ptr %l20
  call void @__olang_scope_close(ptr %s11)
  br label %bb62
bb62:
  br label %bb47
bb63:
  call void @__olang_scope_close(ptr %s10)
  store i32 65537, ptr %l180
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t378 = load i32, ptr %l180
  store i32 %t378, ptr %rv
  br label %ret
bb64:
  %t379 = load ptr, ptr %l5
  store ptr %t379, ptr %l181
  %t380 = load ptr, ptr %l181
  %t381 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v2, ptr %t380)
  store i64 %t381, ptr %l182
  br label %bb65
bb65:
  %t382 = load i64, ptr %l182
  %t383 = icmp sgt i64 %t382, 0
  store i1 %t383, ptr %l183
  %t384 = load i1, ptr %l183
  br i1 %t384, label %bb66, label %bb67
bb66:
  store %olang.scope zeroinitializer, ptr %s15
  store i32 65536, ptr %l184
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  %t385 = load i32, ptr %l184
  store i32 %t385, ptr %rv
  br label %ret
bb67:
  br label %bb68
bb68:
  %t386 = load ptr, ptr %l3
  store ptr %t386, ptr %l185
  %t387 = load ptr, ptr %l185
  %t388 = getelementptr %"compiler/build:Config", ptr %t387, i32 0, i32 2
  %t389 = load %"compiler/target:Target", ptr %t388
  store %"compiler/target:Target" %t389, ptr %l186
  %t390 = load %"compiler/target:Target", ptr %l186
  store %"compiler/target:Target" %t390, ptr %l25
  store i1 false, ptr %l26
  store %olang.scope zeroinitializer, ptr %s16
  store ptr %l12, ptr %l187
  %t391 = load ptr, ptr %l187
  store ptr %t391, ptr %l27
  store i64 0, ptr %l28
  br label %bb69
bb69:
  store %olang.scope zeroinitializer, ptr %s17
  %t392 = load ptr, ptr %l27
  store ptr %t392, ptr %l189
  %t393 = load i64, ptr %l28
  store i64 %t393, ptr %l190
  %t394 = load ptr, ptr %l189
  %t395 = load i64, ptr %l190
  %t396 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aObject_3e_2eRunFrom_3ccompiler_2femit_3aObject_3e(ptr %v3, ptr %t394, i64 %t395)
  %t397 = extractvalue { i32, { i64, ptr } } %t396, 1
  %t398 = extractvalue { i32, { i64, ptr } } %t396, 0
  store i32 %t398, ptr %l192
  %t399 = icmp ne i32 %t398, 0
  br i1 %t399, label %bb71, label %ok.400
ok.400:
  store { i64, ptr } %t397, ptr %l191
  br label %bb70
bb70:
  %t401 = load { i64, ptr }, ptr %l191
  store { i64, ptr } %t401, ptr %l188
  br label %bb75
bb71:
  %t402 = load i32, ptr %l192
  %t403 = ashr i32 %t402, 16
  store i32 %t403, ptr %l193
  %t404 = load i32, ptr %l193
  %t405 = icmp eq i32 %t404, 1
  store i1 %t405, ptr %l194
  %t406 = load i1, ptr %l194
  br i1 %t406, label %bb72, label %bb73
bb72:
  br label %bb74
bb73:
  %t407 = load i32, ptr %l192
  %t408 = lshr i32 %t407, 16
  %t409 = and i32 %t407, 65535
  %t410 = icmp eq i32 %t408, 1
  %t411 = select i1 %t410, i32 0, i32 0
  %t412 = icmp eq i32 %t407, 0
  %t413 = shl i32 %t411, 16
  %t414 = or i32 %t413, %t409
  %t415 = select i1 %t412, i32 0, i32 %t414
  store i32 %t415, ptr %l195
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s0)
  %t416 = load i32, ptr %l195
  store i32 %t416, ptr %rv
  br label %ret
bb74:
  call void @__olang_scope_close(ptr %s17)
  br label %bb106
bb75:
  %t417 = load { i64, ptr }, ptr %l188
  store { i64, ptr } %t417, ptr %l29
  %t418 = load { i64, ptr }, ptr %l29
  store { i64, ptr } %t418, ptr %l196
  %t419 = load { i64, ptr }, ptr %l196
  %t420 = extractvalue { i64, ptr } %t419, 0
  store i64 %t420, ptr %l197
  %t421 = load i64, ptr %l197
  store i64 %t421, ptr %l30
  store i64 0, ptr %l31
  br label %bb76
bb76:
  store %olang.scope zeroinitializer, ptr %s18
  %t422 = load i64, ptr %l31
  store i64 %t422, ptr %l198
  %t423 = load i64, ptr %l30
  store i64 %t423, ptr %l199
  %t424 = load i64, ptr %l198
  %t425 = load i64, ptr %l199
  %t426 = icmp slt i64 %t424, %t425
  store i1 %t426, ptr %l200
  %t427 = load i1, ptr %l200
  %t428 = xor i1 %t427, true
  store i1 %t428, ptr %l201
  %t429 = load i1, ptr %l201
  br i1 %t429, label %bb77, label %bb78
bb77:
  call void @__olang_scope_close(ptr %s18)
  br label %bb104
bb78:
  br label %bb79
bb79:
  %t430 = load { i64, ptr }, ptr %l29
  store { i64, ptr } %t430, ptr %l202
  %t431 = load i64, ptr %l31
  store i64 %t431, ptr %l203
  %t432 = load i64, ptr %l203
  %t433 = getelementptr { i64, ptr }, ptr %l202, i32 0, i32 1
  %t434 = load ptr, ptr %t433
  %t435 = getelementptr %"compiler/emit:Object", ptr %t434, i64 %t432
  %t436 = load %"compiler/emit:Object", ptr %t435
  store %"compiler/emit:Object" %t436, ptr %l204
  %t437 = load %"compiler/emit:Object", ptr %l204
  store %"compiler/emit:Object" %t437, ptr %l32
  %t438 = getelementptr %"compiler/emit:Object", ptr %l32, i32 0, i32 2
  %t439 = load { i64, ptr }, ptr %t438
  store { i64, ptr } %t439, ptr %l205
  %t440 = load { i64, ptr }, ptr %l205
  store { i64, ptr } %t440, ptr %l33
  %t441 = load { i64, ptr }, ptr %l33
  store { i64, ptr } %t441, ptr %l206
  %t442 = load { i64, ptr }, ptr %l206
  store { i64, ptr } %t442, ptr %l207
  store { i64, ptr } { i64 16, ptr @.d69 }, ptr %l208
  %t443 = load { i64, ptr }, ptr %l207
  %t444 = load { i64, ptr }, ptr %l208
  %t445 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v3, ptr %s18, { i64, ptr } %t443, { i64, ptr } %t444)
  store i1 %t445, ptr %l209
  br label %bb80
bb80:
  %t446 = load i1, ptr %l209
  br i1 %t446, label %bb81, label %bb82
bb81:
  store %olang.scope zeroinitializer, ptr %s19
  store i1 true, ptr %l26
  call void @__olang_scope_close(ptr %s19)
  br label %bb83
bb82:
  br label %bb83
bb83:
  %t447 = getelementptr %"compiler/emit:Object", ptr %l32, i32 0, i32 1
  %t448 = load i32, ptr %t447
  store i32 %t448, ptr %l210
  %t449 = load i32, ptr %l210
  store i32 %t449, ptr %l34
  %t450 = load i32, ptr %l34
  store i32 %t450, ptr %l212
  %t451 = load i32, ptr %l212
  %t452 = trunc i64 0 to i32
  %t453 = icmp eq i32 %t451, %t452
  store i1 %t453, ptr %l213
  %t454 = load i1, ptr %l213
  br i1 %t454, label %bb84, label %bb85
bb84:
  br label %bb86
bb85:
  br label %bb87
bb86:
  store %olang.scope zeroinitializer, ptr %s20
  store i32 0, ptr %l214
  %t455 = load i32, ptr %l214
  store i32 %t455, ptr %l211
  call void @__olang_scope_close(ptr %s20)
  br label %bb100
bb87:
  %t456 = load i32, ptr %l34
  store i32 %t456, ptr %l215
  %t457 = load i32, ptr %l215
  %t458 = trunc i64 1 to i32
  %t459 = icmp eq i32 %t457, %t458
  store i1 %t459, ptr %l216
  %t460 = load i1, ptr %l216
  br i1 %t460, label %bb88, label %bb89
bb88:
  br label %bb90
bb89:
  br label %bb91
bb90:
  store %olang.scope zeroinitializer, ptr %s21
  store i32 1, ptr %l217
  %t461 = load i32, ptr %l217
  store i32 %t461, ptr %l211
  call void @__olang_scope_close(ptr %s21)
  br label %bb100
bb91:
  %t462 = load i32, ptr %l34
  store i32 %t462, ptr %l218
  %t463 = load i32, ptr %l218
  %t464 = trunc i64 2 to i32
  %t465 = icmp eq i32 %t463, %t464
  store i1 %t465, ptr %l219
  %t466 = load i1, ptr %l219
  br i1 %t466, label %bb92, label %bb93
bb92:
  br label %bb94
bb93:
  br label %bb95
bb94:
  store %olang.scope zeroinitializer, ptr %s22
  store i32 2, ptr %l220
  %t467 = load i32, ptr %l220
  store i32 %t467, ptr %l211
  call void @__olang_scope_close(ptr %s22)
  br label %bb100
bb95:
  %t468 = load i32, ptr %l34
  store i32 %t468, ptr %l221
  %t469 = load i32, ptr %l221
  %t470 = trunc i64 3 to i32
  %t471 = icmp eq i32 %t469, %t470
  store i1 %t471, ptr %l222
  %t472 = load i1, ptr %l222
  br i1 %t472, label %bb96, label %bb97
bb96:
  br label %bb98
bb97:
  br label %bb99
bb98:
  store %olang.scope zeroinitializer, ptr %s23
  store i32 3, ptr %l223
  %t473 = load i32, ptr %l223
  store i32 %t473, ptr %l211
  call void @__olang_scope_close(ptr %s23)
  br label %bb100
bb99:
  call void @__olang_check_failed(ptr @.c70)
  unreachable
bb100:
  %t474 = load i32, ptr %l211
  store i32 %t474, ptr %l35
  %t475 = load ptr, ptr %l4
  store ptr %t475, ptr %l224
  %t476 = load ptr, ptr %l224
  %t477 = getelementptr %"compiler/build:Program", ptr %t476, i32 0, i32 0
  store ptr %t477, ptr %l225
  %t478 = getelementptr %"compiler/emit:Object", ptr %l32, i32 0, i32 0
  %t479 = load { i64, ptr }, ptr %t478
  store { i64, ptr } %t479, ptr %l226
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s24
  store ptr %s24room, ptr %s24
  %t480 = load { i64, ptr }, ptr %l226
  %t481 = extractvalue { i64, ptr } %t480, 1
  %t482 = extractvalue { i64, ptr } %t480, 0
  call void @__olang_sb_put(ptr %s24, ptr %t481, i64 %t482)
  %t483 = load ptr, ptr %s24
  %t484 = getelementptr %olang.builder, ptr %s24, i32 0, i32 1
  %t485 = load i64, ptr %t484
  %t486 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t485)
  call void @llvm.memcpy.p0.p0.i64(ptr %t486, ptr %t483, i64 %t485, i1 false)
  %t487 = insertvalue { i64, ptr } undef, i64 %t485, 0
  %t488 = insertvalue { i64, ptr } %t487, ptr %t486, 1
  store { i64, ptr } %t488, ptr %l227
  call void @__olang_sb_done(ptr %s24)
  %t489 = load { i64, ptr }, ptr %l227
  %t490 = extractvalue { i64, ptr } %t489, 0
  %t491 = extractvalue { i64, ptr } %t489, 1
  %t492 = mul i64 %t490, 1
  %t493 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t492)
  call void @llvm.memcpy.p0.p0.i64(ptr %t493, ptr %t491, i64 %t492, i1 false)
  %t494 = insertvalue { i64, ptr } undef, i64 %t490, 0
  %t495 = insertvalue { i64, ptr } %t494, ptr %t493, 1
  store { i64, ptr } %t495, ptr %l228
  %t496 = load i32, ptr %l35
  store i32 %t496, ptr %l229
  %t497 = load { i64, ptr }, ptr %l33
  store { i64, ptr } %t497, ptr %l230
  %t498 = load { i64, ptr }, ptr %l228
  %t499 = load i32, ptr %l229
  %t500 = load { i64, ptr }, ptr %l230
  %t501 = call %"compiler/build:Unit" @compiler_2fbuild_3aUnit_2ector(ptr %v3, ptr %v3, ptr %v3, { i64, ptr } %t498, i32 %t499, { i64, ptr } %t500)
  store %"compiler/build:Unit" %t501, ptr %l231
  br label %bb101
bb101:
  %t502 = load ptr, ptr %l225
  %t503 = load %"compiler/build:Unit", ptr %l231
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2ePush_3ccompiler_2fbuild_3aUnit_3e(ptr %v3, ptr %v3, ptr %t502, %"compiler/build:Unit" %t503)
  br label %bb102
bb102:
  call void @__olang_scope_close(ptr %s18)
  br label %bb103
bb103:
  store %olang.scope zeroinitializer, ptr %s25
  %t504 = load i64, ptr %l31
  store i64 %t504, ptr %l232
  %t505 = load i64, ptr %l232
  %t506 = add i64 %t505, 1
  store i64 %t506, ptr %l233
  %t507 = load i64, ptr %l233
  store i64 %t507, ptr %l31
  call void @__olang_scope_close(ptr %s25)
  br label %bb76
bb104:
  %t508 = load i64, ptr %l28
  store i64 %t508, ptr %l234
  %t509 = load i64, ptr %l30
  store i64 %t509, ptr %l235
  %t510 = load i64, ptr %l234
  %t511 = load i64, ptr %l235
  %t512 = add i64 %t510, %t511
  store i64 %t512, ptr %l236
  %t513 = load i64, ptr %l236
  store i64 %t513, ptr %l28
  call void @__olang_scope_close(ptr %s17)
  br label %bb105
bb105:
  br label %bb69
bb106:
  call void @__olang_scope_close(ptr %s16)
  %t514 = load ptr, ptr %l4
  store ptr %t514, ptr %l237
  %t515 = getelementptr %"compiler/target:Target", ptr %l25, i32 0, i32 1
  %t516 = load { i64, ptr }, ptr %t515
  store { i64, ptr } %t516, ptr %l239
  %t517 = getelementptr %"compiler/target:Target", ptr %l25, i32 0, i32 2
  %t518 = load { i64, ptr }, ptr %t517
  store { i64, ptr } %t518, ptr %l240
  %t519 = getelementptr %"compiler/target:Target", ptr %l25, i32 0, i32 5
  %t520 = load { i64, ptr }, ptr %t519
  store { i64, ptr } %t520, ptr %l241
  %t521 = load ptr, ptr %l3
  store ptr %t521, ptr %l242
  %t522 = load ptr, ptr %l242
  %t523 = getelementptr %"compiler/build:Config", ptr %t522, i32 0, i32 6
  %t524 = load i1, ptr %t523
  store i1 %t524, ptr %l243
  %t525 = load ptr, ptr %l3
  store ptr %t525, ptr %l244
  %t526 = load ptr, ptr %l244
  %t527 = getelementptr %"compiler/build:Config", ptr %t526, i32 0, i32 5
  %t528 = load i1, ptr %t527
  store i1 %t528, ptr %l245
  %t529 = load { i64, ptr }, ptr %l239
  %t530 = load { i64, ptr }, ptr %l240
  %t531 = load { i64, ptr }, ptr %l241
  %t532 = load i1, ptr %l243
  %t533 = load i1, ptr %l245
  %t534 = call { i32, { i64, ptr } } @compiler_2fruntime_2eIr(ptr %v2, ptr %v2, ptr %v2, ptr %v3, { i64, ptr } %t529, { i64, ptr } %t530, { i64, ptr } %t531, i1 %t532, i1 %t533)
  %t535 = extractvalue { i32, { i64, ptr } } %t534, 1
  %t536 = extractvalue { i32, { i64, ptr } } %t534, 0
  store i32 %t536, ptr %l247
  %t537 = icmp ne i32 %t536, 0
  br i1 %t537, label %bb108, label %ok.538
ok.538:
  store { i64, ptr } %t535, ptr %l246
  br label %bb107
bb107:
  %t539 = load { i64, ptr }, ptr %l246
  store { i64, ptr } %t539, ptr %l238
  br label %bb112
bb108:
  %t540 = load i32, ptr %l247
  %t541 = ashr i32 %t540, 16
  store i32 %t541, ptr %l248
  %t542 = load i32, ptr %l248
  %t543 = icmp eq i32 %t542, 1
  store i1 %t543, ptr %l249
  %t544 = load i1, ptr %l249
  br i1 %t544, label %bb109, label %bb110
bb109:
  br label %bb111
bb110:
  %t545 = load i32, ptr %l247
  %t546 = lshr i32 %t545, 16
  %t547 = and i32 %t545, 65535
  %t548 = icmp eq i32 %t546, 1
  %t549 = select i1 %t548, i32 0, i32 0
  %t550 = icmp eq i32 %t545, 0
  %t551 = shl i32 %t549, 16
  %t552 = or i32 %t551, %t547
  %t553 = select i1 %t550, i32 0, i32 %t552
  store i32 %t553, ptr %l250
  call void @__olang_scope_close(ptr %s0)
  %t554 = load i32, ptr %l250
  store i32 %t554, ptr %rv
  br label %ret
bb111:
  store %olang.scope zeroinitializer, ptr %s26
  store i32 65536, ptr %l251
  call void @__olang_scope_close(ptr %s26)
  call void @__olang_scope_close(ptr %s0)
  %t555 = load i32, ptr %l251
  store i32 %t555, ptr %rv
  br label %ret
bb112:
  %t556 = load { i64, ptr }, ptr %l238
  %t557 = extractvalue { i64, ptr } %t556, 0
  %t558 = extractvalue { i64, ptr } %t556, 1
  %t559 = mul i64 %t557, 1
  %t560 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t559)
  call void @llvm.memcpy.p0.p0.i64(ptr %t560, ptr %t558, i64 %t559, i1 false)
  %t561 = insertvalue { i64, ptr } undef, i64 %t557, 0
  %t562 = insertvalue { i64, ptr } %t561, ptr %t560, 1
  store { i64, ptr } %t562, ptr %l252
  %t563 = load { i64, ptr }, ptr %l252
  %t564 = load ptr, ptr %l237
  %t565 = getelementptr %"compiler/build:Program", ptr %t564, i32 0, i32 1
  store { i64, ptr } %t563, ptr %t565
  %t566 = load i1, ptr %l26
  store i1 %t566, ptr %l253
  %t567 = load i1, ptr %l253
  br i1 %t567, label %bb113, label %bb114
bb113:
  store %olang.scope zeroinitializer, ptr %s27
  %t568 = load ptr, ptr %l4
  store ptr %t568, ptr %l254
  %t569 = getelementptr %"compiler/target:Target", ptr %l25, i32 0, i32 1
  %t570 = load { i64, ptr }, ptr %t569
  store { i64, ptr } %t570, ptr %l256
  %t571 = getelementptr %"compiler/target:Target", ptr %l25, i32 0, i32 2
  %t572 = load { i64, ptr }, ptr %t571
  store { i64, ptr } %t572, ptr %l257
  %t573 = getelementptr %"compiler/target:Target", ptr %l25, i32 0, i32 5
  %t574 = load { i64, ptr }, ptr %t573
  store { i64, ptr } %t574, ptr %l258
  %t575 = load ptr, ptr %l3
  store ptr %t575, ptr %l259
  %t576 = load ptr, ptr %l259
  %t577 = getelementptr %"compiler/build:Config", ptr %t576, i32 0, i32 6
  %t578 = load i1, ptr %t577
  store i1 %t578, ptr %l260
  %t579 = load ptr, ptr %l3
  store ptr %t579, ptr %l261
  %t580 = load ptr, ptr %l261
  %t581 = getelementptr %"compiler/build:Config", ptr %t580, i32 0, i32 5
  %t582 = load i1, ptr %t581
  store i1 %t582, ptr %l262
  %t583 = load { i64, ptr }, ptr %l256
  %t584 = load { i64, ptr }, ptr %l257
  %t585 = load { i64, ptr }, ptr %l258
  %t586 = load i1, ptr %l260
  %t587 = load i1, ptr %l262
  %t588 = call { i32, { i64, ptr } } @compiler_2fruntime_2eDyncallIr(ptr %v2, ptr %v2, ptr %v2, ptr %v3, { i64, ptr } %t583, { i64, ptr } %t584, { i64, ptr } %t585, i1 %t586, i1 %t587)
  %t589 = extractvalue { i32, { i64, ptr } } %t588, 1
  %t590 = extractvalue { i32, { i64, ptr } } %t588, 0
  store i32 %t590, ptr %l264
  %t591 = icmp ne i32 %t590, 0
  br i1 %t591, label %bb116, label %ok.592
ok.592:
  store { i64, ptr } %t589, ptr %l263
  br label %bb115
bb114:
  br label %bb121
bb115:
  %t593 = load { i64, ptr }, ptr %l263
  store { i64, ptr } %t593, ptr %l255
  br label %bb120
bb116:
  %t594 = load i32, ptr %l264
  %t595 = ashr i32 %t594, 16
  store i32 %t595, ptr %l265
  %t596 = load i32, ptr %l265
  %t597 = icmp eq i32 %t596, 1
  store i1 %t597, ptr %l266
  %t598 = load i1, ptr %l266
  br i1 %t598, label %bb117, label %bb118
bb117:
  br label %bb119
bb118:
  %t599 = load i32, ptr %l264
  %t600 = lshr i32 %t599, 16
  %t601 = and i32 %t599, 65535
  %t602 = icmp eq i32 %t600, 1
  %t603 = select i1 %t602, i32 0, i32 0
  %t604 = icmp eq i32 %t599, 0
  %t605 = shl i32 %t603, 16
  %t606 = or i32 %t605, %t601
  %t607 = select i1 %t604, i32 0, i32 %t606
  store i32 %t607, ptr %l267
  call void @__olang_scope_close(ptr %s27)
  call void @__olang_scope_close(ptr %s0)
  %t608 = load i32, ptr %l267
  store i32 %t608, ptr %rv
  br label %ret
bb119:
  store %olang.scope zeroinitializer, ptr %s28
  store i32 65536, ptr %l268
  call void @__olang_scope_close(ptr %s28)
  call void @__olang_scope_close(ptr %s27)
  call void @__olang_scope_close(ptr %s0)
  %t609 = load i32, ptr %l268
  store i32 %t609, ptr %rv
  br label %ret
bb120:
  %t610 = load { i64, ptr }, ptr %l255
  %t611 = extractvalue { i64, ptr } %t610, 0
  %t612 = extractvalue { i64, ptr } %t610, 1
  %t613 = mul i64 %t611, 1
  %t614 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t613)
  call void @llvm.memcpy.p0.p0.i64(ptr %t614, ptr %t612, i64 %t613, i1 false)
  %t615 = insertvalue { i64, ptr } undef, i64 %t611, 0
  %t616 = insertvalue { i64, ptr } %t615, ptr %t614, 1
  store { i64, ptr } %t616, ptr %l269
  %t617 = load { i64, ptr }, ptr %l269
  %t618 = load ptr, ptr %l254
  %t619 = getelementptr %"compiler/build:Program", ptr %t618, i32 0, i32 2
  store { i64, ptr } %t617, ptr %t619
  call void @__olang_scope_close(ptr %s27)
  br label %bb121
bb121:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, i32 } @compiler_2folang_2ecompiler_2folang_3aPasses_2eInterpret(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca i32
  %l21 = alloca ptr
  %l22 = alloca %"compiler/check:Checker"
  %l23 = alloca ptr
  %l24 = alloca %"std/prelude/map:Map<std/pair:Pair<I64, I64>, Bool>"
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca i64
  %l29 = alloca ptr
  %l30 = alloca i64
  %l31 = alloca i1
  %l32 = alloca i32
  %l33 = alloca ptr
  %l34 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca %"std/prelude/list:List<mut compiler/typed:Body&>"
  %l37 = alloca i32
  %l38 = alloca %"compiler/interp:Exec"
  %l39 = alloca ptr
  %l40 = alloca ptr
  %l41 = alloca ptr
  %l42 = alloca %"std/prelude/map:Map<std/pair:Pair<I64, I64>, Bool>"
  %l43 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i1
  %l49 = alloca i1
  %l50 = alloca { i64, ptr }
  %l51 = alloca i64
  %l52 = alloca { i64, ptr }
  %l53 = alloca ptr
  %l54 = alloca ptr
  %l55 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca ptr
  %l61 = alloca ptr
  %l62 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.builder
  %s4room = alloca [64 x i8], align 8
  %s5 = alloca %olang.scope
  %rv = alloca { i32, i32 }
  %t28 = alloca %"compiler/check:Checker", align 8
  %t59 = alloca %"compiler/interp:Exec", align 8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l14
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l15
  %t3 = load ptr, ptr %l3
  store ptr %t3, ptr %l16
  %t4 = load ptr, ptr %l4
  store ptr %t4, ptr %l17
  %t5 = load ptr, ptr %l14
  %t6 = load { i64, ptr }, ptr %l15
  %t7 = load ptr, ptr %l16
  %t8 = load ptr, ptr %l17
  %t9 = call { i32, ptr } @compiler_2folang_2ecompiler_2folang_3aPasses_2eload(ptr %v0, ptr %v1, ptr %v3, ptr %t5, { i64, ptr } %t6, ptr %t7, ptr %t8)
  %t10 = extractvalue { i32, ptr } %t9, 1
  %t11 = extractvalue { i32, ptr } %t9, 0
  store i32 %t11, ptr %l19
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb2, label %ok.13
ok.13:
  store ptr %t10, ptr %l18
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l18
  store ptr %t14, ptr %l13
  br label %bb3
bb2:
  %t15 = load i32, ptr %l19
  %t16 = lshr i32 %t15, 16
  %t17 = and i32 %t15, 65535
  %t18 = icmp eq i32 %t16, 1
  %t19 = select i1 %t18, i32 1, i32 0
  %t20 = icmp eq i32 %t15, 0
  %t21 = shl i32 %t19, 16
  %t22 = or i32 %t21, %t17
  %t23 = select i1 %t20, i32 0, i32 %t22
  store i32 %t23, ptr %l20
  call void @__olang_scope_close(ptr %s0)
  %t24 = load i32, ptr %l20
  %t25 = insertvalue { i32, i32 } zeroinitializer, i32 %t24, 0
  store { i32, i32 } %t25, ptr %rv
  br label %ret
bb3:
  %t26 = load ptr, ptr %l13
  store ptr %t26, ptr %l5
  %t27 = load ptr, ptr %l5
  store ptr %t27, ptr %l21
  %t29 = load ptr, ptr %l21
  call void @compiler_2finterp_2eAnalyze(ptr %t28, ptr %v3, ptr %v3, ptr %t29, i1 false)
  %t30 = load %"compiler/check:Checker", ptr %t28
  store %"compiler/check:Checker" %t30, ptr %l22
  br label %bb4
bb4:
  %t31 = load %"compiler/check:Checker", ptr %l22
  %t32 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 432, i64 8)
  store %"compiler/check:Checker" %t31, ptr %t32
  store ptr %t32, ptr %l23
  %t33 = load ptr, ptr %l23
  store ptr %t33, ptr %l6
  %t34 = call %"std/prelude/map:Map<std/pair:Pair<I64, I64>, Bool>" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v3)
  store %"std/prelude/map:Map<std/pair:Pair<I64, I64>, Bool>" %t34, ptr %l24
  br label %bb5
bb5:
  %t35 = load %"std/prelude/map:Map<std/pair:Pair<I64, I64>, Bool>", ptr %l24
  %t36 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 8, i64 8)
  store %"std/prelude/map:Map<std/pair:Pair<I64, I64>, Bool>" %t35, ptr %t36
  store ptr %t36, ptr %l25
  %t37 = load ptr, ptr %l25
  store ptr %t37, ptr %l7
  %t38 = load ptr, ptr %l6
  store ptr %t38, ptr %l26
  %t39 = load ptr, ptr %l7
  store ptr %t39, ptr %l27
  %t40 = load ptr, ptr %l26
  %t41 = load ptr, ptr %l27
  %t42 = call i64 @compiler_2finterp_2eDecideAsserts(ptr %v3, ptr %v3, ptr %t40, ptr %t41)
  store i64 %t42, ptr %l28
  br label %bb6
bb6:
  %t43 = load ptr, ptr %l4
  store ptr %t43, ptr %l29
  %t44 = load ptr, ptr %l29
  %t45 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v3, ptr %t44)
  store i64 %t45, ptr %l30
  br label %bb7
bb7:
  %t46 = load i64, ptr %l30
  %t47 = icmp sgt i64 %t46, 0
  store i1 %t47, ptr %l31
  %t48 = load i1, ptr %l31
  br i1 %t48, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s1
  store i32 65536, ptr %l32
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t49 = load i32, ptr %l32
  %t50 = insertvalue { i32, i32 } zeroinitializer, i32 %t49, 0
  store { i32, i32 } %t50, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t51 = load ptr, ptr %l6
  store ptr %t51, ptr %l33
  %t52 = load ptr, ptr %l33
  %t53 = getelementptr %"compiler/check:Checker", ptr %t52, i32 0, i32 0
  %t54 = load ptr, ptr %t53
  store ptr %t54, ptr %l34
  %t55 = load ptr, ptr %l6
  store ptr %t55, ptr %l35
  %t56 = load ptr, ptr %l35
  %t57 = getelementptr %"compiler/check:Checker", ptr %t56, i32 0, i32 4
  %t58 = load %"std/prelude/list:List<mut compiler/typed:Body&>", ptr %t57
  store %"std/prelude/list:List<mut compiler/typed:Body&>" %t58, ptr %l36
  store i32 1, ptr %l37
  %t60 = load ptr, ptr %l34
  %t61 = load %"std/prelude/list:List<mut compiler/typed:Body&>", ptr %l36
  %t62 = load i32, ptr %l37
  call void @compiler_2finterp_3aExec_2ector(ptr %t59, ptr %v3, ptr %v3, ptr %v3, ptr %t60, %"std/prelude/list:List<mut compiler/typed:Body&>" %t61, i32 %t62)
  %t63 = load %"compiler/interp:Exec", ptr %t59
  store %"compiler/interp:Exec" %t63, ptr %l38
  br label %bb11
bb11:
  %t64 = load %"compiler/interp:Exec", ptr %l38
  %t65 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 800, i64 8)
  store %"compiler/interp:Exec" %t64, ptr %t65
  store ptr %t65, ptr %l39
  %t66 = load ptr, ptr %l39
  store ptr %t66, ptr %l8
  %t67 = load ptr, ptr %l8
  store ptr %t67, ptr %l40
  %t68 = load ptr, ptr %l7
  store ptr %t68, ptr %l41
  %t69 = load ptr, ptr %l41
  %t70 = load %"std/prelude/map:Map<std/pair:Pair<I64, I64>, Bool>", ptr %t69
  store %"std/prelude/map:Map<std/pair:Pair<I64, I64>, Bool>" %t70, ptr %l42
  %t71 = load %"std/prelude/map:Map<std/pair:Pair<I64, I64>, Bool>", ptr %l42
  %t72 = load ptr, ptr %l40
  %t73 = getelementptr %"compiler/interp:Exec", ptr %t72, i32 0, i32 3
  %t74 = getelementptr %"compiler/lower:Lowerer", ptr %t73, i32 0, i32 5
  store %"std/prelude/map:Map<std/pair:Pair<I64, I64>, Bool>" %t71, ptr %t74
  store %olang.scope zeroinitializer, ptr %s2
  %t75 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t75, ptr %l43
  %t76 = load { i64, ptr }, ptr %l43
  store { i64, ptr } %t76, ptr %l9
  store i64 0, ptr %l10
  %t77 = load { i64, ptr }, ptr %l9
  store { i64, ptr } %t77, ptr %l44
  %t78 = load { i64, ptr }, ptr %l44
  %t79 = extractvalue { i64, ptr } %t78, 0
  store i64 %t79, ptr %l45
  %t80 = load i64, ptr %l45
  store i64 %t80, ptr %l11
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t81 = load i64, ptr %l10
  store i64 %t81, ptr %l46
  %t82 = load i64, ptr %l11
  store i64 %t82, ptr %l47
  %t83 = load i64, ptr %l46
  %t84 = load i64, ptr %l47
  %t85 = icmp slt i64 %t83, %t84
  store i1 %t85, ptr %l48
  %t86 = load i1, ptr %l48
  %t87 = xor i1 %t86, true
  store i1 %t87, ptr %l49
  %t88 = load i1, ptr %l49
  br i1 %t88, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb18
bb14:
  br label %bb15
bb15:
  %t89 = load { i64, ptr }, ptr %l9
  store { i64, ptr } %t89, ptr %l50
  %t90 = load i64, ptr %l10
  store i64 %t90, ptr %l51
  %t91 = load i64, ptr %l51
  %t92 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t93 = load ptr, ptr %t92
  %t94 = getelementptr { i64, ptr }, ptr %t93, i64 %t91
  %t95 = load { i64, ptr }, ptr %t94
  store { i64, ptr } %t95, ptr %l52
  %t96 = load { i64, ptr }, ptr %l52
  store { i64, ptr } %t96, ptr %l12
  %t97 = load ptr, ptr %l8
  store ptr %t97, ptr %l53
  %t98 = load ptr, ptr %l53
  %t99 = getelementptr %"compiler/interp:Exec", ptr %t98, i32 0, i32 4
  %t100 = getelementptr %"compiler/eval:Machine", ptr %t99, i32 0, i32 54
  store ptr %t100, ptr %l54
  %t101 = load { i64, ptr }, ptr %l12
  store { i64, ptr } %t101, ptr %l55
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s4
  store ptr %s4room, ptr %s4
  %t102 = load { i64, ptr }, ptr %l55
  %t103 = extractvalue { i64, ptr } %t102, 1
  %t104 = extractvalue { i64, ptr } %t102, 0
  call void @__olang_sb_put(ptr %s4, ptr %t103, i64 %t104)
  %t105 = load ptr, ptr %s4
  %t106 = getelementptr %olang.builder, ptr %s4, i32 0, i32 1
  %t107 = load i64, ptr %t106
  %t108 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t107)
  call void @llvm.memcpy.p0.p0.i64(ptr %t108, ptr %t105, i64 %t107, i1 false)
  %t109 = insertvalue { i64, ptr } undef, i64 %t107, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t108, 1
  store { i64, ptr } %t110, ptr %l56
  call void @__olang_sb_done(ptr %s4)
  %t111 = load { i64, ptr }, ptr %l56
  %t112 = extractvalue { i64, ptr } %t111, 0
  %t113 = extractvalue { i64, ptr } %t111, 1
  %t114 = mul i64 %t112, 1
  %t115 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t114)
  call void @llvm.memcpy.p0.p0.i64(ptr %t115, ptr %t113, i64 %t114, i1 false)
  %t116 = insertvalue { i64, ptr } undef, i64 %t112, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr %t115, 1
  store { i64, ptr } %t117, ptr %l57
  %t118 = load ptr, ptr %l54
  %t119 = load { i64, ptr }, ptr %l57
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v3, ptr %v3, ptr %t118, { i64, ptr } %t119)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s5
  %t120 = load i64, ptr %l10
  store i64 %t120, ptr %l58
  %t121 = load i64, ptr %l58
  %t122 = add i64 %t121, 1
  store i64 %t122, ptr %l59
  %t123 = load i64, ptr %l59
  store i64 %t123, ptr %l10
  call void @__olang_scope_close(ptr %s5)
  br label %bb12
bb18:
  call void @__olang_scope_close(ptr %s2)
  %t124 = load ptr, ptr %l8
  store ptr %t124, ptr %l60
  %t125 = load ptr, ptr %l4
  store ptr %t125, ptr %l61
  %t126 = load ptr, ptr %l60
  %t127 = load ptr, ptr %l61
  %t128 = call i32 @compiler_2finterp_2ecompiler_2finterp_3aExec_2eRunMain(ptr %v3, ptr %v3, ptr %t126, ptr %t127)
  store i32 %t128, ptr %l62
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s0)
  %t129 = load i32, ptr %l62
  %t130 = insertvalue { i32, i32 } zeroinitializer, i32 %t129, 1
  store { i32, i32 } %t130, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i32 }, ptr %rv
  ret { i32, i32 } %rr
}

define dso_local { i32, ptr } @compiler_2folang_2ecompiler_2folang_3aPasses_2eload(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca ptr
  %l15 = alloca i1
  %l16 = alloca %"compiler/fetch:Fetcher"
  %l17 = alloca ptr
  %l18 = alloca %"compiler/source:Names"
  %l19 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca %"compiler/load:Loader"
  %l28 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca ptr
  %l34 = alloca ptr
  %l35 = alloca i64
  %l36 = alloca ptr
  %l37 = alloca i64
  %l38 = alloca i1
  %l39 = alloca i32
  %l40 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t1, ptr %l7
  %t2 = load { i64, ptr }, ptr %l7
  %t3 = call { i64, ptr } @compiler_2fload_2eLockPath(ptr %v1, ptr %v2, { i64, ptr } %t2)
  store { i64, ptr } %t3, ptr %l8
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l8
  %t5 = extractvalue { i64, ptr } %t4, 0
  %t6 = extractvalue { i64, ptr } %t4, 1
  %t7 = mul i64 %t5, 1
  %t8 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t7)
  call void @llvm.memcpy.p0.p0.i64(ptr %t8, ptr %t6, i64 %t7, i1 false)
  %t9 = insertvalue { i64, ptr } undef, i64 %t5, 0
  %t10 = insertvalue { i64, ptr } %t9, ptr %t8, 1
  store { i64, ptr } %t10, ptr %l9
  %t11 = call { i64, ptr } @compiler_2ffetch_2eCacheDir(ptr %v2)
  store { i64, ptr } %t11, ptr %l10
  br label %bb2
bb2:
  %t12 = load { i64, ptr }, ptr %l10
  %t13 = extractvalue { i64, ptr } %t12, 0
  %t14 = extractvalue { i64, ptr } %t12, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l11
  %t19 = call { i64, ptr } @compiler_2ffetch_2eGitBase(ptr %v2)
  store { i64, ptr } %t19, ptr %l12
  br label %bb3
bb3:
  %t20 = load { i64, ptr }, ptr %l12
  %t21 = extractvalue { i64, ptr } %t20, 0
  %t22 = extractvalue { i64, ptr } %t20, 1
  %t23 = mul i64 %t21, 1
  %t24 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t23)
  call void @llvm.memcpy.p0.p0.i64(ptr %t24, ptr %t22, i64 %t23, i1 false)
  %t25 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t24, 1
  store { i64, ptr } %t26, ptr %l13
  %t27 = load ptr, ptr %l2
  store ptr %t27, ptr %l14
  %t28 = load ptr, ptr %l14
  %t29 = getelementptr %"compiler/build:Config", ptr %t28, i32 0, i32 7
  %t30 = load i1, ptr %t29
  store i1 %t30, ptr %l15
  %t31 = load { i64, ptr }, ptr %l9
  %t32 = load { i64, ptr }, ptr %l11
  %t33 = load { i64, ptr }, ptr %l13
  %t34 = load i1, ptr %l15
  %t35 = call %"compiler/fetch:Fetcher" @compiler_2ffetch_3aFetcher_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t31, { i64, ptr } %t32, { i64, ptr } %t33, i1 %t34, i1 false)
  store %"compiler/fetch:Fetcher" %t35, ptr %l16
  br label %bb4
bb4:
  %t36 = load %"compiler/fetch:Fetcher", ptr %l16
  %t37 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 88, i64 8)
  store %"compiler/fetch:Fetcher" %t36, ptr %t37
  store ptr %t37, ptr %l17
  %t38 = load ptr, ptr %l17
  store ptr %t38, ptr %l4
  %t39 = call %"compiler/source:Names" @compiler_2fsource_3aNames_2ector(ptr %v2)
  store %"compiler/source:Names" %t39, ptr %l18
  br label %bb5
bb5:
  %t40 = load %"compiler/source:Names", ptr %l18
  %t41 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store %"compiler/source:Names" %t40, ptr %t41
  store ptr %t41, ptr %l19
  %t42 = load ptr, ptr %l19
  store ptr %t42, ptr %l5
  %t43 = call { i64, ptr } @compiler_2fload_2eStdDir(ptr %v2)
  store { i64, ptr } %t43, ptr %l20
  br label %bb6
bb6:
  %t44 = load { i64, ptr }, ptr %l20
  %t45 = extractvalue { i64, ptr } %t44, 0
  %t46 = extractvalue { i64, ptr } %t44, 1
  %t47 = mul i64 %t45, 1
  %t48 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t47)
  call void @llvm.memcpy.p0.p0.i64(ptr %t48, ptr %t46, i64 %t47, i1 false)
  %t49 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  store { i64, ptr } %t50, ptr %l21
  %t51 = load ptr, ptr %l2
  store ptr %t51, ptr %l22
  %t52 = load ptr, ptr %l22
  %t53 = getelementptr %"compiler/build:Config", ptr %t52, i32 0, i32 3
  store ptr %t53, ptr %l23
  %t54 = load ptr, ptr %l4
  store ptr %t54, ptr %l24
  %t55 = load ptr, ptr %l5
  store ptr %t55, ptr %l25
  %t56 = load ptr, ptr %l3
  store ptr %t56, ptr %l26
  %t57 = load { i64, ptr }, ptr %l21
  %t58 = load ptr, ptr %l23
  %t59 = load ptr, ptr %l24
  %t60 = load ptr, ptr %l25
  %t61 = load ptr, ptr %l26
  %t62 = call %"compiler/load:Loader" @compiler_2fload_3aLoader_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t57, ptr %t58, ptr %t59, ptr %t60, ptr %t61)
  store %"compiler/load:Loader" %t62, ptr %l27
  br label %bb7
bb7:
  %t63 = load %"compiler/load:Loader", ptr %l27
  %t64 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 104, i64 8)
  store %"compiler/load:Loader" %t63, ptr %t64
  store ptr %t64, ptr %l28
  %t65 = load ptr, ptr %l28
  store ptr %t65, ptr %l6
  %t66 = load ptr, ptr %l6
  store ptr %t66, ptr %l29
  %t67 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t67, ptr %l30
  %t68 = load ptr, ptr %l29
  %t69 = load { i64, ptr }, ptr %l30
  %t70 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eLoad(ptr %v2, ptr %v1, ptr %t68, { i64, ptr } %t69)
  store i64 %t70, ptr %l31
  br label %bb8
bb8:
  %t71 = load ptr, ptr %l0
  store ptr %t71, ptr %l32
  %t72 = load ptr, ptr %l6
  store ptr %t72, ptr %l33
  %t73 = load ptr, ptr %l33
  %t74 = getelementptr %"compiler/load:Loader", ptr %t73, i32 0, i32 5
  store ptr %t74, ptr %l34
  %t75 = load ptr, ptr %l34
  %t76 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v2, ptr %t75)
  store i64 %t76, ptr %l35
  br label %bb9
bb9:
  %t77 = load i64, ptr %l35
  %t78 = load ptr, ptr %l32
  %t79 = getelementptr %"compiler/olang:Passes", ptr %t78, i32 0, i32 0
  store i64 %t77, ptr %t79
  %t80 = load ptr, ptr %l3
  store ptr %t80, ptr %l36
  %t81 = load ptr, ptr %l36
  %t82 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v2, ptr %t81)
  store i64 %t82, ptr %l37
  br label %bb10
bb10:
  %t83 = load i64, ptr %l37
  %t84 = icmp sgt i64 %t83, 0
  store i1 %t84, ptr %l38
  %t85 = load i1, ptr %l38
  br i1 %t85, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s1
  store i32 65536, ptr %l39
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t86 = load i32, ptr %l39
  %t87 = insertvalue { i32, ptr } zeroinitializer, i32 %t86, 0
  store { i32, ptr } %t87, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t88 = load ptr, ptr %l6
  store ptr %t88, ptr %l40
  call void @__olang_scope_close(ptr %s0)
  %t89 = load ptr, ptr %l40
  %t90 = insertvalue { i32, ptr } zeroinitializer, ptr %t89, 1
  store { i32, ptr } %t90, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i32 @compiler_2folang_2edrive(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"compiler/olang:Passes"
  %l2 = alloca %"compiler/olang:Passes"
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"compiler/olang:Passes" @compiler_2folang_3aPasses_2ector(ptr %s0)
  store %"compiler/olang:Passes" %t1, ptr %l2
  br label %bb1
bb1:
  %t2 = load %"compiler/olang:Passes", ptr %l2
  store %"compiler/olang:Passes" %t2, ptr %l1
  %t3 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t3, ptr %l3
  store ptr %l1, ptr %l4
  %t4 = load { i64, ptr }, ptr %l3
  %t5 = load ptr, ptr %l4
  %t6 = call i32 @compiler_2folang_2eRunWith_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %s0, { i64, ptr } %t4, ptr %t5)
  store i32 %t6, ptr %l5
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t7 = load i32, ptr %l5
  store i32 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2folang_2eendsWithOlang(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i1
  %l4 = alloca i1
  %l5 = alloca { i64, ptr }
  %l6 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l1
  %t2 = load { i64, ptr }, ptr %l1
  %t3 = extractvalue { i64, ptr } %t2, 0
  store i64 %t3, ptr %l2
  %t4 = load i64, ptr %l2
  %t5 = icmp sgt i64 %t4, 6
  store i1 %t5, ptr %l3
  %t6 = load i1, ptr %l3
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t7 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t7, ptr %l5
  %t8 = load { i64, ptr }, ptr %l5
  %t9 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %s0, { i64, ptr } %t8, { i64, ptr } { i64 6, ptr @.d71 })
  store i1 %t9, ptr %l6
  br label %bb3
bb2:
  store i1 false, ptr %l4
  br label %bb4
bb3:
  %t10 = load i1, ptr %l6
  store i1 %t10, ptr %l4
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t11 = load i1, ptr %l4
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2folang_2eexplain(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %lp4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i1
  %l12 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca { i64, [3 x i64] }
  %l15 = alloca { i64, ptr }
  %l16 = alloca %"compiler/msgs:Msg"
  %l17 = alloca i64
  %l18 = alloca i32
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i32
  %l25 = alloca ptr
  %l26 = alloca { i64, [3 x i64] }
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca i1
  %l30 = alloca i1
  %l31 = alloca i1
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i1
  %l40 = alloca i1
  %l41 = alloca i1
  %l42 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l45 = alloca %"compiler/msgs:Msg"
  %l46 = alloca i64
  %l47 = alloca i32
  %l48 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.builder
  %s3room = alloca [64 x i8], align 8
  %rv = alloca { i32, { i64, ptr } }
  %t28 = alloca { i64, [3 x i64] }, align 8
  %t53 = alloca { i64, [3 x i64] }, align 8
  store { i64, ptr } %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i64, ptr } @compiler_2fdiag_2eSpecPath(ptr %s0)
  store { i64, ptr } %t1, ptr %l5
  br label %bb1
bb1:
  %t2 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t2, ptr %l2
  %t3 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t3, ptr %l7
  %t4 = load { i64, ptr }, ptr %l7
  %t5 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s0, { i64, ptr } %t4)
  %t6 = extractvalue { i32, { i64, ptr } } %t5, 1
  %t7 = extractvalue { i32, { i64, ptr } } %t5, 0
  store i32 %t7, ptr %l9
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb3, label %ok.9
ok.9:
  store { i64, ptr } %t6, ptr %l8
  br label %bb2
bb2:
  %t10 = load { i64, ptr }, ptr %l8
  store { i64, ptr } %t10, ptr %l6
  br label %bb9
bb3:
  %t11 = load i32, ptr %l9
  %t12 = ashr i32 %t11, 16
  store i32 %t12, ptr %l10
  %t13 = load i32, ptr %l10
  %t14 = icmp eq i32 %t13, 1
  store i1 %t14, ptr %l11
  %t15 = load i1, ptr %l11
  br i1 %t15, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load i32, ptr %l9
  %t17 = lshr i32 %t16, 16
  %t18 = and i32 %t16, 65535
  %t19 = icmp eq i32 %t17, 1
  %t20 = select i1 %t19, i32 0, i32 0
  %t21 = icmp eq i32 %t16, 0
  %t22 = shl i32 %t20, 16
  %t23 = or i32 %t22, %t18
  %t24 = select i1 %t21, i32 0, i32 %t23
  store i32 %t24, ptr %l12
  call void @__olang_scope_close(ptr %s0)
  %t25 = load i32, ptr %l12
  %t26 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t25, 0
  store { i32, { i64, ptr } } %t26, ptr %rv
  br label %ret
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t27 = load ptr, ptr %l1
  store ptr %t27, ptr %l13
  store { i64, [3 x i64] } zeroinitializer, ptr %t28
  %t29 = getelementptr { i64, [3 x i64] }, ptr %t28, i32 0, i32 0
  store i64 0, ptr %t29
  %t30 = load { i64, [3 x i64] }, ptr %t28
  store { i64, [3 x i64] } %t30, ptr %l14
  %t31 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t31, ptr %l15
  %t32 = load { i64, ptr }, ptr %l15
  %t33 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoSpec(ptr %s0, ptr %s1, { i64, ptr } %t32)
  store %"compiler/msgs:Msg" %t33, ptr %l16
  br label %bb7
bb7:
  %t34 = load ptr, ptr %l13
  %t35 = load { i64, [3 x i64] }, ptr %l14
  %t36 = load %"compiler/msgs:Msg", ptr %l16
  %t37 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v1, ptr %s1, ptr %t34, { i64, [3 x i64] } %t35, %"compiler/msgs:Msg" %t36)
  store i64 %t37, ptr %l17
  br label %bb8
bb8:
  store i32 65536, ptr %l18
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t38 = load i32, ptr %l18
  %t39 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t38, 0
  store { i32, { i64, ptr } } %t39, ptr %rv
  br label %ret
bb9:
  %t40 = load { i64, ptr }, ptr %l6
  store { i64, ptr } %t40, ptr %l3
  %t41 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t41, ptr %l20
  %t42 = load { i64, ptr }, ptr %l20
  store { i64, ptr } %t42, ptr %l21
  %t43 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t43, ptr %l22
  %t44 = load { i64, ptr }, ptr %l21
  %t45 = load { i64, ptr }, ptr %l22
  %t46 = call { i32, { i64, ptr } } @compiler_2fdiag_2eExplain(ptr %s0, ptr %v0, ptr %v2, { i64, ptr } %t44, { i64, ptr } %t45)
  %t47 = extractvalue { i32, { i64, ptr } } %t46, 1
  %t48 = extractvalue { i32, { i64, ptr } } %t46, 0
  store i32 %t48, ptr %l24
  %t49 = icmp ne i32 %t48, 0
  br i1 %t49, label %bb11, label %ok.50
ok.50:
  store { i64, ptr } %t47, ptr %l23
  br label %bb10
bb10:
  %t51 = load { i64, ptr }, ptr %l23
  store { i64, ptr } %t51, ptr %l19
  br label %bb28
bb11:
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t52 = load ptr, ptr %l1
  store ptr %t52, ptr %l25
  store { i64, [3 x i64] } zeroinitializer, ptr %t53
  %t54 = getelementptr { i64, [3 x i64] }, ptr %t53, i32 0, i32 0
  store i64 0, ptr %t54
  %t55 = load { i64, [3 x i64] }, ptr %t53
  store { i64, [3 x i64] } %t55, ptr %l26
  %t56 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t56, ptr %l27
  %t57 = load { i64, ptr }, ptr %l27
  %t58 = extractvalue { i64, ptr } %t57, 0
  store i64 %t58, ptr %l28
  %t59 = icmp sge i64 0, 0
  store i1 %t59, ptr %l29
  %t60 = load i1, ptr %l29
  br i1 %t60, label %bb13, label %bb14
bb13:
  %t61 = icmp sle i64 0, 1
  store i1 %t61, ptr %l30
  %t62 = load i1, ptr %l30
  br i1 %t62, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @.c72)
  unreachable
bb15:
  %t63 = load i64, ptr %l28
  %t64 = icmp sle i64 1, %t63
  store i1 %t64, ptr %l31
  %t65 = load i1, ptr %l31
  br i1 %t65, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @.c72)
  unreachable
bb17:
  %t66 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t67 = load ptr, ptr %t66
  %t68 = getelementptr i8, ptr %t67, i64 0
  %t69 = sub i64 1, 0
  %t70 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t68, 1
  store { i64, ptr } %t71, ptr %l32
  %t72 = load { i64, ptr }, ptr %l32
  %t73 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eToUpper(ptr %v0, ptr %s2, { i64, ptr } %t72)
  store { i64, ptr } %t73, ptr %l33
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @.c72)
  unreachable
bb19:
  %t74 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t74, ptr %l34
  %t75 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t75, ptr %l35
  %t76 = load { i64, ptr }, ptr %l35
  store { i64, ptr } %t76, ptr %l36
  %t77 = load { i64, ptr }, ptr %l36
  %t78 = extractvalue { i64, ptr } %t77, 0
  store i64 %t78, ptr %l37
  %t79 = load { i64, ptr }, ptr %l34
  %t80 = extractvalue { i64, ptr } %t79, 0
  store i64 %t80, ptr %l38
  %t81 = icmp sge i64 1, 0
  store i1 %t81, ptr %l39
  %t82 = load i1, ptr %l39
  br i1 %t82, label %bb20, label %bb21
bb20:
  %t83 = load i64, ptr %l37
  %t84 = icmp sle i64 1, %t83
  store i1 %t84, ptr %l40
  %t85 = load i1, ptr %l40
  br i1 %t85, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @.c72)
  unreachable
bb22:
  %t86 = load i64, ptr %l37
  %t87 = load i64, ptr %l38
  %t88 = icmp sle i64 %t86, %t87
  store i1 %t88, ptr %l41
  %t89 = load i1, ptr %l41
  br i1 %t89, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @.c72)
  unreachable
bb24:
  %t90 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t91 = load ptr, ptr %t90
  %t92 = load i64, ptr %l37
  %t93 = getelementptr i8, ptr %t91, i64 1
  %t94 = sub i64 %t92, 1
  %t95 = insertvalue { i64, ptr } undef, i64 %t94, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %t93, 1
  store { i64, ptr } %t96, ptr %l42
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s3
  store ptr %s3room, ptr %s3
  %t97 = load { i64, ptr }, ptr %l33
  %t98 = extractvalue { i64, ptr } %t97, 1
  %t99 = extractvalue { i64, ptr } %t97, 0
  call void @__olang_sb_put(ptr %s3, ptr %t98, i64 %t99)
  %t100 = load { i64, ptr }, ptr %l42
  %t101 = extractvalue { i64, ptr } %t100, 1
  %t102 = extractvalue { i64, ptr } %t100, 0
  call void @__olang_sb_put(ptr %s3, ptr %t101, i64 %t102)
  %t103 = load ptr, ptr %s3
  %t104 = getelementptr %olang.builder, ptr %s3, i32 0, i32 1
  %t105 = load i64, ptr %t104
  %t106 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t105)
  call void @llvm.memcpy.p0.p0.i64(ptr %t106, ptr %t103, i64 %t105, i1 false)
  %t107 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t106, 1
  store { i64, ptr } %t108, ptr %l43
  call void @__olang_sb_done(ptr %s3)
  %t109 = load { i64, ptr }, ptr %l43
  %t110 = extractvalue { i64, ptr } %t109, 0
  %t111 = extractvalue { i64, ptr } %t109, 1
  %t112 = mul i64 %t110, 1
  %t113 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t112)
  call void @llvm.memcpy.p0.p0.i64(ptr %t113, ptr %t111, i64 %t112, i1 false)
  %t114 = insertvalue { i64, ptr } undef, i64 %t110, 0
  %t115 = insertvalue { i64, ptr } %t114, ptr %t113, 1
  store { i64, ptr } %t115, ptr %l44
  %t116 = load { i64, ptr }, ptr %l44
  %t117 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoRule(ptr %s2, ptr %s2, { i64, ptr } %t116)
  store %"compiler/msgs:Msg" %t117, ptr %l45
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @.c72)
  unreachable
bb26:
  %t118 = load ptr, ptr %l25
  %t119 = load { i64, [3 x i64] }, ptr %l26
  %t120 = load %"compiler/msgs:Msg", ptr %l45
  %t121 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v1, ptr %s2, ptr %t118, { i64, [3 x i64] } %t119, %"compiler/msgs:Msg" %t120)
  store i64 %t121, ptr %l46
  br label %bb27
bb27:
  store i32 65536, ptr %l47
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t122 = load i32, ptr %l47
  %t123 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t122, 0
  store { i32, { i64, ptr } } %t123, ptr %rv
  br label %ret
bb28:
  %t124 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t124, ptr %lp4
  %t125 = load { i64, ptr }, ptr %l19
  %t126 = load ptr, ptr %lp4
  store { i64, ptr } %t125, ptr %t126
  %t127 = load ptr, ptr %lp4
  %t128 = load { i64, ptr }, ptr %t127
  store { i64, ptr } %t128, ptr %l48
  call void @__olang_scope_close(ptr %s0)
  %t129 = load { i64, ptr }, ptr %l48
  %t130 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t129, 1
  store { i32, { i64, ptr } } %t130, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i32 @compiler_2folang_2eformat(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l1
  %t2 = load ptr, ptr %l1
  %t3 = getelementptr %"compiler/olang:CommandLine", ptr %t2, i32 0, i32 8
  %t4 = load i1, ptr %t3
  store i1 %t4, ptr %l2
  %t5 = load i1, ptr %l2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 2, ptr @.d73 }, ptr %l3
  br label %bb3
bb2:
  store { i64, ptr } { i64 2, ptr @.d74 }, ptr %l3
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0
  store ptr %t6, ptr %l4
  %t7 = load ptr, ptr %l4
  %t8 = getelementptr %"compiler/olang:CommandLine", ptr %t7, i32 0, i32 1
  store ptr %t8, ptr %l5
  %t9 = load ptr, ptr %l5
  %t10 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hd4bdf3befe2f7a35847f168802c5df68(ptr %v0, ptr %v0, ptr %t9)
  store { i64, ptr } %t10, ptr %l6
  br label %bb4
bb4:
  %t11 = call { i64, ptr } @compiler_2fload_2eStdDir(ptr %s0)
  store { i64, ptr } %t11, ptr %l7
  br label %bb5
bb5:
  %t12 = load { i64, ptr }, ptr %l7
  %t13 = extractvalue { i64, ptr } %t12, 0
  %t14 = extractvalue { i64, ptr } %t12, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l8
  %t19 = load { i64, ptr }, ptr %l3
  %t20 = load { i64, ptr }, ptr %l6
  %t21 = load { i64, ptr }, ptr %l8
  %t22 = call i32 @compiler_2ffmt_2eFiles(ptr %s0, ptr %v0, ptr %s0, { i64, ptr } %t19, { i64, ptr } %t20, { i64, ptr } %t21)
  store i32 %t22, ptr %l9
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load i32, ptr %l9
  store i32 %t23, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2folang_2ehelp(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i1
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca %"std/prelude/text:StringBuilder"
  %l19 = alloca ptr
  %l20 = alloca i1
  %l21 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i1
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i1
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i1
  %l49 = alloca i1
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca ptr
  %l56 = alloca i64
  %l57 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l59 = alloca i64
  %l60 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca ptr
  %l66 = alloca ptr
  %l67 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l69 = alloca i64
  %l70 = alloca { i64, ptr }
  %l71 = alloca ptr
  %l72 = alloca { i64, ptr }
  %l73 = alloca i1
  %l74 = alloca i64
  %l75 = alloca i64
  %l76 = alloca ptr
  %l77 = alloca { i64, ptr }
  %l78 = alloca i64
  %l79 = alloca i64
  %l80 = alloca i1
  %l81 = alloca ptr
  %l82 = alloca ptr
  %l83 = alloca { i64, ptr }
  %l84 = alloca %"compiler/msgs:Msg"
  %l85 = alloca i32
  %l86 = alloca i32
  %l87 = alloca ptr
  %l88 = alloca i64
  %l89 = alloca { i64, ptr }
  %l90 = alloca i64
  %l91 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l95 = alloca i64
  %l96 = alloca i64
  %l97 = alloca i64
  %l98 = alloca i1
  %l99 = alloca i64
  %l100 = alloca i64
  %l101 = alloca i1
  %l102 = alloca i64
  %l103 = alloca i64
  %l104 = alloca i64
  %l105 = alloca i64
  %l106 = alloca i64
  %l107 = alloca i64
  %l108 = alloca i64
  %l109 = alloca i64
  %l110 = alloca i64
  %l111 = alloca i64
  %l112 = alloca i64
  %l113 = alloca i1
  %l114 = alloca i1
  %l115 = alloca i64
  %l116 = alloca i64
  %l117 = alloca i64
  %l118 = alloca i64
  %l119 = alloca i64
  %l120 = alloca i64
  %l121 = alloca i64
  %l122 = alloca i64
  %l123 = alloca i64
  %l124 = alloca i64
  %l125 = alloca i1
  %l126 = alloca i1
  %l127 = alloca i1
  %l128 = alloca ptr
  %l129 = alloca i64
  %l130 = alloca { i64, ptr }
  %l131 = alloca i64
  %l132 = alloca { i64, ptr }
  %l133 = alloca i1
  %l134 = alloca i1
  %l135 = alloca { i64, ptr }
  %l136 = alloca i64
  %l137 = alloca { i64, ptr }
  %l138 = alloca { i64, ptr }
  %l139 = alloca ptr
  %l140 = alloca { i64, ptr }
  %l141 = alloca { i64, ptr }
  %l142 = alloca i64
  %l143 = alloca { i64, ptr }
  %l144 = alloca { i64, ptr }
  %l145 = alloca { i64, ptr }
  %l146 = alloca i64
  %l147 = alloca i64
  %l148 = alloca ptr
  %l149 = alloca { i64, ptr }
  %l150 = alloca { i64, ptr }
  %l151 = alloca i64
  %l152 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.builder
  %s2room = alloca [64 x i8], align 8
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.builder
  %s5room = alloca [64 x i8], align 8
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.builder
  %s8room = alloca [64 x i8], align 8
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.builder
  %s13room = alloca [64 x i8], align 8
  %s14 = alloca %olang.builder
  %s14room = alloca [64 x i8], align 8
  %s15 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l18
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l18
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  %t3 = load ptr, ptr %l0
  store ptr %t3, ptr %l19
  %t4 = load ptr, ptr %l19
  %t5 = getelementptr %"compiler/olang:CommandLine", ptr %t4, i32 0, i32 3
  %t6 = load i1, ptr %t5
  store i1 %t6, ptr %l20
  %t7 = load i1, ptr %l20
  %t8 = xor i1 %t7, true
  store i1 %t8, ptr %l21
  %t9 = load i1, ptr %l21
  br i1 %t9, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  store ptr %l2, ptr %l22
  %t10 = load ptr, ptr %l22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s1, ptr %t10, { i64, ptr } { i64 96, ptr @.d75 })
  br label %bb4
bb3:
  br label %bb23
bb4:
  store ptr %l2, ptr %l23
  %t11 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadEnd(ptr %s1, ptr %s1, { i64, ptr } { i64 10, ptr @.d76 }, i64 11, i8 32)
  store { i64, ptr } %t11, ptr %l24
  br label %bb5
bb5:
  %t12 = load i64, ptr @G_2ecompiler_2folang_2eRun
  store i64 %t12, ptr %l25
  %t13 = load i64, ptr %l25
  %t14 = getelementptr { i64, ptr }, ptr @G_2ecompiler_2folang_2eModeWhat, i32 0, i32 1
  %t15 = load ptr, ptr %t14
  %t16 = getelementptr { i64, ptr }, ptr %t15, i64 %t13
  %t17 = load { i64, ptr }, ptr %t16
  store { i64, ptr } %t17, ptr %l26
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s2
  store ptr %s2room, ptr %s2
  %t18 = extractvalue { i64, ptr } { i64 2, ptr @.d77 }, 1
  %t19 = extractvalue { i64, ptr } { i64 2, ptr @.d77 }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t18, i64 %t19)
  %t20 = load { i64, ptr }, ptr %l24
  %t21 = extractvalue { i64, ptr } %t20, 1
  %t22 = extractvalue { i64, ptr } %t20, 0
  call void @__olang_sb_put(ptr %s2, ptr %t21, i64 %t22)
  %t23 = extractvalue { i64, ptr } { i64 1, ptr @.d78 }, 1
  %t24 = extractvalue { i64, ptr } { i64 1, ptr @.d78 }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t23, i64 %t24)
  %t25 = load { i64, ptr }, ptr %l26
  %t26 = extractvalue { i64, ptr } %t25, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  call void @__olang_sb_put(ptr %s2, ptr %t26, i64 %t27)
  %t28 = extractvalue { i64, ptr } { i64 1, ptr @.d79 }, 1
  %t29 = extractvalue { i64, ptr } { i64 1, ptr @.d79 }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t28, i64 %t29)
  %t30 = load ptr, ptr %s2
  %t31 = getelementptr %olang.builder, ptr %s2, i32 0, i32 1
  %t32 = load i64, ptr %t31
  %t33 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t32)
  call void @llvm.memcpy.p0.p0.i64(ptr %t33, ptr %t30, i64 %t32, i1 false)
  %t34 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t33, 1
  store { i64, ptr } %t35, ptr %l27
  call void @__olang_sb_done(ptr %s2)
  %t36 = load { i64, ptr }, ptr %l27
  %t37 = extractvalue { i64, ptr } %t36, 0
  %t38 = extractvalue { i64, ptr } %t36, 1
  %t39 = mul i64 %t37, 1
  %t40 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t39)
  call void @llvm.memcpy.p0.p0.i64(ptr %t40, ptr %t38, i64 %t39, i1 false)
  %t41 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  store { i64, ptr } %t42, ptr %l28
  %t43 = load ptr, ptr %l23
  %t44 = load { i64, ptr }, ptr %l28
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s1, ptr %t43, { i64, ptr } %t44)
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  store i64 1, ptr %l3
  %t45 = load { i64, ptr }, ptr @G_2ecompiler_2folang_2eModeWords
  store { i64, ptr } %t45, ptr %l29
  %t46 = load { i64, ptr }, ptr %l29
  %t47 = extractvalue { i64, ptr } %t46, 0
  store i64 %t47, ptr %l30
  %t48 = load i64, ptr %l30
  store i64 %t48, ptr %l4
  store i64 1, ptr %l5
  %t49 = load i64, ptr %l4
  store i64 %t49, ptr %l31
  %t50 = load i64, ptr %l3
  store i64 %t50, ptr %l32
  %t51 = load i64, ptr %l31
  %t52 = load i64, ptr %l32
  %t53 = icmp sgt i64 %t51, %t52
  store i1 %t53, ptr %l33
  %t54 = load i1, ptr %l33
  br i1 %t54, label %bb7, label %bb8
bb7:
  %t55 = load i64, ptr %l5
  store i64 %t55, ptr %l35
  %t56 = load i64, ptr %l35
  %t57 = icmp sgt i64 %t56, 0
  store i1 %t57, ptr %l36
  %t58 = load i1, ptr %l36
  br i1 %t58, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l34
  br label %bb12
bb9:
  %t59 = load i64, ptr %l4
  store i64 %t59, ptr %l38
  %t60 = load i64, ptr %l3
  store i64 %t60, ptr %l39
  %t61 = load i64, ptr %l38
  %t62 = load i64, ptr %l39
  %t63 = sub i64 %t61, %t62
  store i64 %t63, ptr %l40
  %t64 = load i64, ptr %l5
  store i64 %t64, ptr %l41
  %t65 = load i64, ptr %l40
  %t66 = load i64, ptr %l41
  %t67 = add i64 %t65, %t66
  store i64 %t67, ptr %l42
  %t68 = load i64, ptr %l42
  %t69 = sub i64 %t68, 1
  store i64 %t69, ptr %l43
  %t70 = load i64, ptr %l5
  store i64 %t70, ptr %l44
  %t71 = load i64, ptr %l43
  %t72 = load i64, ptr %l44
  %t73 = sdiv i64 %t71, %t72
  store i64 %t73, ptr %l45
  %t74 = load i64, ptr %l45
  store i64 %t74, ptr %l37
  br label %bb11
bb10:
  store i64 0, ptr %l37
  br label %bb11
bb11:
  %t75 = load i64, ptr %l37
  store i64 %t75, ptr %l34
  br label %bb12
bb12:
  %t76 = load i64, ptr %l34
  store i64 %t76, ptr %l6
  store i64 0, ptr %l7
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s4
  %t77 = load i64, ptr %l7
  store i64 %t77, ptr %l46
  %t78 = load i64, ptr %l6
  store i64 %t78, ptr %l47
  %t79 = load i64, ptr %l46
  %t80 = load i64, ptr %l47
  %t81 = icmp slt i64 %t79, %t80
  store i1 %t81, ptr %l48
  %t82 = load i1, ptr %l48
  %t83 = xor i1 %t82, true
  store i1 %t83, ptr %l49
  %t84 = load i1, ptr %l49
  br i1 %t84, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s4)
  br label %bb20
bb15:
  br label %bb16
bb16:
  %t85 = load i64, ptr %l3
  store i64 %t85, ptr %l50
  %t86 = load i64, ptr %l7
  store i64 %t86, ptr %l51
  %t87 = load i64, ptr %l5
  store i64 %t87, ptr %l52
  %t88 = load i64, ptr %l51
  %t89 = load i64, ptr %l52
  %t90 = mul i64 %t88, %t89
  store i64 %t90, ptr %l53
  %t91 = load i64, ptr %l50
  %t92 = load i64, ptr %l53
  %t93 = add i64 %t91, %t92
  store i64 %t93, ptr %l54
  %t94 = load i64, ptr %l54
  store i64 %t94, ptr %l8
  store ptr %l2, ptr %l55
  %t95 = load i64, ptr %l8
  store i64 %t95, ptr %l56
  %t96 = load i64, ptr %l56
  %t97 = getelementptr { i64, ptr }, ptr @G_2ecompiler_2folang_2eModeWords, i32 0, i32 1
  %t98 = load ptr, ptr %t97
  %t99 = getelementptr { i64, ptr }, ptr %t98, i64 %t96
  %t100 = load { i64, ptr }, ptr %t99
  store { i64, ptr } %t100, ptr %l57
  %t101 = load ptr, ptr @__olang_prog_scope
  %t102 = load { i64, ptr }, ptr %l57
  %t103 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadEnd(ptr %t101, ptr %s4, { i64, ptr } %t102, i64 11, i8 32)
  store { i64, ptr } %t103, ptr %l58
  br label %bb17
bb17:
  %t104 = load i64, ptr %l8
  store i64 %t104, ptr %l59
  %t105 = load i64, ptr %l59
  %t106 = getelementptr { i64, ptr }, ptr @G_2ecompiler_2folang_2eModeWhat, i32 0, i32 1
  %t107 = load ptr, ptr %t106
  %t108 = getelementptr { i64, ptr }, ptr %t107, i64 %t105
  %t109 = load { i64, ptr }, ptr %t108
  store { i64, ptr } %t109, ptr %l60
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s5
  store ptr %s5room, ptr %s5
  %t110 = extractvalue { i64, ptr } { i64 2, ptr @.d80 }, 1
  %t111 = extractvalue { i64, ptr } { i64 2, ptr @.d80 }, 0
  call void @__olang_sb_put(ptr %s5, ptr %t110, i64 %t111)
  %t112 = load { i64, ptr }, ptr %l58
  %t113 = extractvalue { i64, ptr } %t112, 1
  %t114 = extractvalue { i64, ptr } %t112, 0
  call void @__olang_sb_put(ptr %s5, ptr %t113, i64 %t114)
  %t115 = extractvalue { i64, ptr } { i64 1, ptr @.d81 }, 1
  %t116 = extractvalue { i64, ptr } { i64 1, ptr @.d81 }, 0
  call void @__olang_sb_put(ptr %s5, ptr %t115, i64 %t116)
  %t117 = load { i64, ptr }, ptr %l60
  %t118 = extractvalue { i64, ptr } %t117, 1
  %t119 = extractvalue { i64, ptr } %t117, 0
  call void @__olang_sb_put(ptr %s5, ptr %t118, i64 %t119)
  %t120 = extractvalue { i64, ptr } { i64 1, ptr @.d82 }, 1
  %t121 = extractvalue { i64, ptr } { i64 1, ptr @.d82 }, 0
  call void @__olang_sb_put(ptr %s5, ptr %t120, i64 %t121)
  %t122 = load ptr, ptr %s5
  %t123 = getelementptr %olang.builder, ptr %s5, i32 0, i32 1
  %t124 = load i64, ptr %t123
  %t125 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t124)
  call void @llvm.memcpy.p0.p0.i64(ptr %t125, ptr %t122, i64 %t124, i1 false)
  %t126 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t127 = insertvalue { i64, ptr } %t126, ptr %t125, 1
  store { i64, ptr } %t127, ptr %l61
  call void @__olang_sb_done(ptr %s5)
  %t128 = load { i64, ptr }, ptr %l61
  %t129 = extractvalue { i64, ptr } %t128, 0
  %t130 = extractvalue { i64, ptr } %t128, 1
  %t131 = mul i64 %t129, 1
  %t132 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t131)
  call void @llvm.memcpy.p0.p0.i64(ptr %t132, ptr %t130, i64 %t131, i1 false)
  %t133 = insertvalue { i64, ptr } undef, i64 %t129, 0
  %t134 = insertvalue { i64, ptr } %t133, ptr %t132, 1
  store { i64, ptr } %t134, ptr %l62
  %t135 = load ptr, ptr %l55
  %t136 = load { i64, ptr }, ptr %l62
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %t135, { i64, ptr } %t136)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s4)
  br label %bb19
bb19:
  store %olang.scope zeroinitializer, ptr %s6
  %t137 = load i64, ptr %l7
  store i64 %t137, ptr %l63
  %t138 = load i64, ptr %l63
  %t139 = add i64 %t138, 1
  store i64 %t139, ptr %l64
  %t140 = load i64, ptr %l64
  store i64 %t140, ptr %l7
  call void @__olang_scope_close(ptr %s6)
  br label %bb13
bb20:
  call void @__olang_scope_close(ptr %s3)
  store ptr %l2, ptr %l65
  %t141 = load ptr, ptr %l65
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s1, ptr %t141, { i64, ptr } { i64 85, ptr @.d83 })
  br label %bb21
bb21:
  store ptr %l2, ptr %l66
  %t142 = load ptr, ptr %l66
  %t143 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %t142)
  store { i64, ptr } %t143, ptr %l67
  br label %bb22
bb22:
  %t144 = load { i64, ptr }, ptr %l67
  store { i64, ptr } %t144, ptr %l68
  %t145 = load { i64, ptr }, ptr %l68
  %t146 = extractvalue { i64, ptr } %t145, 0
  store i64 %t146, ptr %l69
  %t147 = load i64, ptr %l69
  %t148 = mul i64 %t147, 1
  %t149 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t148)
  %t150 = insertvalue { i64, ptr } undef, i64 %t147, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t149, 1
  store { i64, ptr } %t151, ptr %l70
  %t152 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t153 = load ptr, ptr %t152
  %t154 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t155 = load ptr, ptr %t154
  %t156 = load i64, ptr %l69
  %t157 = mul i64 %t156, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t153, ptr %t155, i64 %t157, i1 false)
  %t158 = load { i64, ptr }, ptr %l70
  store { i64, ptr } %t158, ptr %l68
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t159 = load { i64, ptr }, ptr %l68
  %t160 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t159, 1
  store { i32, { i64, ptr } } %t160, ptr %rv
  br label %ret
bb23:
  %t161 = load ptr, ptr %l0
  store ptr %t161, ptr %l71
  %t162 = load ptr, ptr %l71
  %t163 = getelementptr %"compiler/olang:CommandLine", ptr %t162, i32 0, i32 2
  %t164 = load { i64, ptr }, ptr %t163
  store { i64, ptr } %t164, ptr %l72
  %t165 = load { i64, ptr }, ptr %l72
  %t166 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t165, { i64, ptr } { i64 3, ptr @.d84 })
  store i1 %t166, ptr %l73
  br label %bb24
bb24:
  %t167 = load i1, ptr %l73
  br i1 %t167, label %bb25, label %bb26
bb25:
  %t168 = load i64, ptr @G_2ecompiler_2folang_2eRun
  store i64 %t168, ptr %l75
  %t169 = load i64, ptr %l75
  store i64 %t169, ptr %l74
  br label %bb28
bb26:
  %t170 = load ptr, ptr %l0
  store ptr %t170, ptr %l76
  %t171 = load ptr, ptr %l76
  %t172 = getelementptr %"compiler/olang:CommandLine", ptr %t171, i32 0, i32 2
  %t173 = load { i64, ptr }, ptr %t172
  store { i64, ptr } %t173, ptr %l77
  %t174 = load { i64, ptr }, ptr %l77
  %t175 = call i64 @compiler_2folang_2emodeNumber(ptr %v0, { i64, ptr } %t174)
  store i64 %t175, ptr %l78
  br label %bb27
bb27:
  %t176 = load i64, ptr %l78
  store i64 %t176, ptr %l74
  br label %bb28
bb28:
  %t177 = load i64, ptr %l74
  store i64 %t177, ptr %l9
  %t178 = load i64, ptr %l9
  store i64 %t178, ptr %l79
  %t179 = load i64, ptr %l79
  %t180 = icmp slt i64 %t179, 0
  store i1 %t180, ptr %l80
  %t181 = load i1, ptr %l80
  br i1 %t181, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s7
  %t182 = load ptr, ptr %l1
  store ptr %t182, ptr %l81
  %t183 = load ptr, ptr %l0
  store ptr %t183, ptr %l82
  %t184 = load ptr, ptr %l82
  %t185 = getelementptr %"compiler/olang:CommandLine", ptr %t184, i32 0, i32 2
  %t186 = load { i64, ptr }, ptr %t185
  store { i64, ptr } %t186, ptr %l83
  %t187 = load { i64, ptr }, ptr %l83
  %t188 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotAMode(ptr %v0, ptr %s7, { i64, ptr } %t187)
  store %"compiler/msgs:Msg" %t188, ptr %l84
  br label %bb31
bb30:
  br label %bb35
bb31:
  %t189 = load ptr, ptr %l81
  %t190 = load %"compiler/msgs:Msg", ptr %l84
  %t191 = call i32 @compiler_2folang_2eusage(ptr %v1, ptr %s7, ptr %t189, %"compiler/msgs:Msg" %t190)
  store i32 %t191, ptr %l85
  %t192 = icmp ne i32 %t191, 0
  br i1 %t192, label %bb33, label %ok.193
ok.193:
  br label %bb32
bb32:
  br label %bb34
bb33:
  %t194 = load i32, ptr %l85
  %t195 = lshr i32 %t194, 16
  %t196 = and i32 %t194, 65535
  %t197 = icmp eq i32 %t195, 1
  %t198 = select i1 %t197, i32 1, i32 0
  %t199 = icmp eq i32 %t194, 0
  %t200 = shl i32 %t198, 16
  %t201 = or i32 %t200, %t196
  %t202 = select i1 %t199, i32 0, i32 %t201
  store i32 %t202, ptr %l86
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  %t203 = load i32, ptr %l86
  %t204 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t203, 0
  store { i32, { i64, ptr } } %t204, ptr %rv
  br label %ret
bb34:
  call void @__olang_scope_close(ptr %s7)
  br label %bb35
bb35:
  store ptr %l2, ptr %l87
  %t205 = load i64, ptr %l9
  store i64 %t205, ptr %l88
  %t206 = load i64, ptr %l88
  %t207 = getelementptr { i64, ptr }, ptr @G_2ecompiler_2folang_2eModeUsage, i32 0, i32 1
  %t208 = load ptr, ptr %t207
  %t209 = getelementptr { i64, ptr }, ptr %t208, i64 %t206
  %t210 = load { i64, ptr }, ptr %t209
  store { i64, ptr } %t210, ptr %l89
  %t211 = load i64, ptr %l9
  store i64 %t211, ptr %l90
  %t212 = load i64, ptr %l90
  %t213 = getelementptr { i64, ptr }, ptr @G_2ecompiler_2folang_2eModeWhat, i32 0, i32 1
  %t214 = load ptr, ptr %t213
  %t215 = getelementptr { i64, ptr }, ptr %t214, i64 %t212
  %t216 = load { i64, ptr }, ptr %t215
  store { i64, ptr } %t216, ptr %l91
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s8
  store ptr %s8room, ptr %s8
  %t217 = extractvalue { i64, ptr } { i64 7, ptr @.d85 }, 1
  %t218 = extractvalue { i64, ptr } { i64 7, ptr @.d85 }, 0
  call void @__olang_sb_put(ptr %s8, ptr %t217, i64 %t218)
  %t219 = load { i64, ptr }, ptr %l89
  %t220 = extractvalue { i64, ptr } %t219, 1
  %t221 = extractvalue { i64, ptr } %t219, 0
  call void @__olang_sb_put(ptr %s8, ptr %t220, i64 %t221)
  %t222 = extractvalue { i64, ptr } { i64 1, ptr @.d86 }, 1
  %t223 = extractvalue { i64, ptr } { i64 1, ptr @.d86 }, 0
  call void @__olang_sb_put(ptr %s8, ptr %t222, i64 %t223)
  %t224 = load { i64, ptr }, ptr %l91
  %t225 = extractvalue { i64, ptr } %t224, 1
  %t226 = extractvalue { i64, ptr } %t224, 0
  call void @__olang_sb_put(ptr %s8, ptr %t225, i64 %t226)
  %t227 = extractvalue { i64, ptr } { i64 1, ptr @.d87 }, 1
  %t228 = extractvalue { i64, ptr } { i64 1, ptr @.d87 }, 0
  call void @__olang_sb_put(ptr %s8, ptr %t227, i64 %t228)
  %t229 = load ptr, ptr %s8
  %t230 = getelementptr %olang.builder, ptr %s8, i32 0, i32 1
  %t231 = load i64, ptr %t230
  %t232 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t231)
  call void @llvm.memcpy.p0.p0.i64(ptr %t232, ptr %t229, i64 %t231, i1 false)
  %t233 = insertvalue { i64, ptr } undef, i64 %t231, 0
  %t234 = insertvalue { i64, ptr } %t233, ptr %t232, 1
  store { i64, ptr } %t234, ptr %l92
  call void @__olang_sb_done(ptr %s8)
  %t235 = load { i64, ptr }, ptr %l92
  %t236 = extractvalue { i64, ptr } %t235, 0
  %t237 = extractvalue { i64, ptr } %t235, 1
  %t238 = mul i64 %t236, 1
  %t239 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t238)
  call void @llvm.memcpy.p0.p0.i64(ptr %t239, ptr %t237, i64 %t238, i1 false)
  %t240 = insertvalue { i64, ptr } undef, i64 %t236, 0
  %t241 = insertvalue { i64, ptr } %t240, ptr %t239, 1
  store { i64, ptr } %t241, ptr %l93
  %t242 = load ptr, ptr %l87
  %t243 = load { i64, ptr }, ptr %l93
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t242, { i64, ptr } %t243)
  br label %bb36
bb36:
  store i1 false, ptr %l10
  store %olang.scope zeroinitializer, ptr %s9
  store i64 0, ptr %l11
  %t244 = load { i64, ptr }, ptr @G_2ecompiler_2folang_2eOptWords
  store { i64, ptr } %t244, ptr %l94
  %t245 = load { i64, ptr }, ptr %l94
  %t246 = extractvalue { i64, ptr } %t245, 0
  store i64 %t246, ptr %l95
  %t247 = load i64, ptr %l95
  store i64 %t247, ptr %l12
  store i64 1, ptr %l13
  %t248 = load i64, ptr %l12
  store i64 %t248, ptr %l96
  %t249 = load i64, ptr %l11
  store i64 %t249, ptr %l97
  %t250 = load i64, ptr %l96
  %t251 = load i64, ptr %l97
  %t252 = icmp sgt i64 %t250, %t251
  store i1 %t252, ptr %l98
  %t253 = load i1, ptr %l98
  br i1 %t253, label %bb37, label %bb38
bb37:
  %t254 = load i64, ptr %l13
  store i64 %t254, ptr %l100
  %t255 = load i64, ptr %l100
  %t256 = icmp sgt i64 %t255, 0
  store i1 %t256, ptr %l101
  %t257 = load i1, ptr %l101
  br i1 %t257, label %bb39, label %bb40
bb38:
  store i64 0, ptr %l99
  br label %bb42
bb39:
  %t258 = load i64, ptr %l12
  store i64 %t258, ptr %l103
  %t259 = load i64, ptr %l11
  store i64 %t259, ptr %l104
  %t260 = load i64, ptr %l103
  %t261 = load i64, ptr %l104
  %t262 = sub i64 %t260, %t261
  store i64 %t262, ptr %l105
  %t263 = load i64, ptr %l13
  store i64 %t263, ptr %l106
  %t264 = load i64, ptr %l105
  %t265 = load i64, ptr %l106
  %t266 = add i64 %t264, %t265
  store i64 %t266, ptr %l107
  %t267 = load i64, ptr %l107
  %t268 = sub i64 %t267, 1
  store i64 %t268, ptr %l108
  %t269 = load i64, ptr %l13
  store i64 %t269, ptr %l109
  %t270 = load i64, ptr %l108
  %t271 = load i64, ptr %l109
  %t272 = sdiv i64 %t270, %t271
  store i64 %t272, ptr %l110
  %t273 = load i64, ptr %l110
  store i64 %t273, ptr %l102
  br label %bb41
bb40:
  store i64 0, ptr %l102
  br label %bb41
bb41:
  %t274 = load i64, ptr %l102
  store i64 %t274, ptr %l99
  br label %bb42
bb42:
  %t275 = load i64, ptr %l99
  store i64 %t275, ptr %l14
  store i64 0, ptr %l15
  br label %bb43
bb43:
  store %olang.scope zeroinitializer, ptr %s10
  %t276 = load i64, ptr %l15
  store i64 %t276, ptr %l111
  %t277 = load i64, ptr %l14
  store i64 %t277, ptr %l112
  %t278 = load i64, ptr %l111
  %t279 = load i64, ptr %l112
  %t280 = icmp slt i64 %t278, %t279
  store i1 %t280, ptr %l113
  %t281 = load i1, ptr %l113
  %t282 = xor i1 %t281, true
  store i1 %t282, ptr %l114
  %t283 = load i1, ptr %l114
  br i1 %t283, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s10)
  br label %bb61
bb45:
  br label %bb46
bb46:
  %t284 = load i64, ptr %l11
  store i64 %t284, ptr %l115
  %t285 = load i64, ptr %l15
  store i64 %t285, ptr %l116
  %t286 = load i64, ptr %l13
  store i64 %t286, ptr %l117
  %t287 = load i64, ptr %l116
  %t288 = load i64, ptr %l117
  %t289 = mul i64 %t287, %t288
  store i64 %t289, ptr %l118
  %t290 = load i64, ptr %l115
  %t291 = load i64, ptr %l118
  %t292 = add i64 %t290, %t291
  store i64 %t292, ptr %l119
  %t293 = load i64, ptr %l119
  store i64 %t293, ptr %l16
  %t294 = load i64, ptr %l16
  store i64 %t294, ptr %l120
  %t295 = load i64, ptr %l120
  %t296 = getelementptr { i64, ptr }, ptr @G_2ecompiler_2folang_2eOptModes, i32 0, i32 1
  %t297 = load ptr, ptr %t296
  %t298 = getelementptr i64, ptr %t297, i64 %t295
  %t299 = load i64, ptr %t298
  store i64 %t299, ptr %l121
  %t300 = load i64, ptr %l9
  store i64 %t300, ptr %l122
  %t301 = load i64, ptr %l121
  %t302 = load i64, ptr %l122
  %t303 = load i64, ptr %l122
  %t304 = ashr i64 %t301, %t303
  store i64 %t304, ptr %l123
  %t305 = load i64, ptr %l123
  %t306 = and i64 %t305, 1
  store i64 %t306, ptr %l124
  %t307 = load i64, ptr %l124
  %t308 = icmp eq i64 %t307, 0
  store i1 %t308, ptr %l125
  %t309 = load i1, ptr %l125
  br i1 %t309, label %bb47, label %bb48
bb47:
  store %olang.scope zeroinitializer, ptr %s11
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s10)
  br label %bb60
bb48:
  br label %bb49
bb49:
  %t310 = load i1, ptr %l10
  store i1 %t310, ptr %l126
  %t311 = load i1, ptr %l126
  %t312 = xor i1 %t311, true
  store i1 %t312, ptr %l127
  %t313 = load i1, ptr %l127
  br i1 %t313, label %bb50, label %bb51
bb50:
  store %olang.scope zeroinitializer, ptr %s12
  store ptr %l2, ptr %l128
  %t314 = load ptr, ptr %l128
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s12, ptr %t314, { i64, ptr } { i64 10, ptr @.d88 })
  br label %bb52
bb51:
  br label %bb53
bb52:
  call void @__olang_scope_close(ptr %s12)
  br label %bb53
bb53:
  store i1 true, ptr %l10
  %t315 = load i64, ptr %l16
  store i64 %t315, ptr %l129
  %t316 = load i64, ptr %l129
  %t317 = getelementptr { i64, ptr }, ptr @G_2ecompiler_2folang_2eOptWords, i32 0, i32 1
  %t318 = load ptr, ptr %t317
  %t319 = getelementptr { i64, ptr }, ptr %t318, i64 %t316
  %t320 = load { i64, ptr }, ptr %t319
  store { i64, ptr } %t320, ptr %l130
  %t321 = load i64, ptr %l16
  store i64 %t321, ptr %l131
  %t322 = load i64, ptr %l131
  %t323 = getelementptr { i64, ptr }, ptr @G_2ecompiler_2folang_2eOptValues, i32 0, i32 1
  %t324 = load ptr, ptr %t323
  %t325 = getelementptr { i64, ptr }, ptr %t324, i64 %t322
  %t326 = load { i64, ptr }, ptr %t325
  store { i64, ptr } %t326, ptr %l132
  %t327 = load ptr, ptr @__olang_prog_scope
  %t328 = load { i64, ptr }, ptr %l132
  %t329 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t327, ptr %s10, { i64, ptr } %t328, { i64, ptr } { i64 0, ptr @.d89 })
  store i1 %t329, ptr %l133
  br label %bb54
bb54:
  %t330 = load i1, ptr %l133
  %t331 = xor i1 %t330, true
  store i1 %t331, ptr %l134
  %t332 = load i1, ptr %l134
  br i1 %t332, label %bb55, label %bb56
bb55:
  store { i64, ptr } { i64 1, ptr @.d90 }, ptr %l135
  br label %bb57
bb56:
  store { i64, ptr } { i64 0, ptr @.d91 }, ptr %l135
  br label %bb57
bb57:
  %t333 = load i64, ptr %l16
  store i64 %t333, ptr %l136
  %t334 = load i64, ptr %l136
  %t335 = getelementptr { i64, ptr }, ptr @G_2ecompiler_2folang_2eOptValues, i32 0, i32 1
  %t336 = load ptr, ptr %t335
  %t337 = getelementptr { i64, ptr }, ptr %t336, i64 %t334
  %t338 = load { i64, ptr }, ptr %t337
  store { i64, ptr } %t338, ptr %l137
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s13
  store ptr %s13room, ptr %s13
  %t339 = load { i64, ptr }, ptr %l130
  %t340 = extractvalue { i64, ptr } %t339, 1
  %t341 = extractvalue { i64, ptr } %t339, 0
  call void @__olang_sb_put(ptr %s13, ptr %t340, i64 %t341)
  %t342 = load { i64, ptr }, ptr %l135
  %t343 = extractvalue { i64, ptr } %t342, 1
  %t344 = extractvalue { i64, ptr } %t342, 0
  call void @__olang_sb_put(ptr %s13, ptr %t343, i64 %t344)
  %t345 = load { i64, ptr }, ptr %l137
  %t346 = extractvalue { i64, ptr } %t345, 1
  %t347 = extractvalue { i64, ptr } %t345, 0
  call void @__olang_sb_put(ptr %s13, ptr %t346, i64 %t347)
  %t348 = load ptr, ptr %s13
  %t349 = getelementptr %olang.builder, ptr %s13, i32 0, i32 1
  %t350 = load i64, ptr %t349
  %t351 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t350)
  call void @llvm.memcpy.p0.p0.i64(ptr %t351, ptr %t348, i64 %t350, i1 false)
  %t352 = insertvalue { i64, ptr } undef, i64 %t350, 0
  %t353 = insertvalue { i64, ptr } %t352, ptr %t351, 1
  store { i64, ptr } %t353, ptr %l138
  call void @__olang_sb_done(ptr %s13)
  %t354 = load { i64, ptr }, ptr %l138
  store { i64, ptr } %t354, ptr %l17
  store ptr %l2, ptr %l139
  %t355 = load { i64, ptr }, ptr %l17
  store { i64, ptr } %t355, ptr %l140
  %t356 = load { i64, ptr }, ptr %l140
  %t357 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadEnd(ptr %s10, ptr %s10, { i64, ptr } %t356, i64 18, i8 32)
  store { i64, ptr } %t357, ptr %l141
  br label %bb58
bb58:
  %t358 = load i64, ptr %l16
  store i64 %t358, ptr %l142
  %t359 = load i64, ptr %l142
  %t360 = getelementptr { i64, ptr }, ptr @G_2ecompiler_2folang_2eOptWhat, i32 0, i32 1
  %t361 = load ptr, ptr %t360
  %t362 = getelementptr { i64, ptr }, ptr %t361, i64 %t359
  %t363 = load { i64, ptr }, ptr %t362
  store { i64, ptr } %t363, ptr %l143
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s14
  store ptr %s14room, ptr %s14
  %t364 = extractvalue { i64, ptr } { i64 2, ptr @.d92 }, 1
  %t365 = extractvalue { i64, ptr } { i64 2, ptr @.d92 }, 0
  call void @__olang_sb_put(ptr %s14, ptr %t364, i64 %t365)
  %t366 = load { i64, ptr }, ptr %l141
  %t367 = extractvalue { i64, ptr } %t366, 1
  %t368 = extractvalue { i64, ptr } %t366, 0
  call void @__olang_sb_put(ptr %s14, ptr %t367, i64 %t368)
  %t369 = extractvalue { i64, ptr } { i64 1, ptr @.d93 }, 1
  %t370 = extractvalue { i64, ptr } { i64 1, ptr @.d93 }, 0
  call void @__olang_sb_put(ptr %s14, ptr %t369, i64 %t370)
  %t371 = load { i64, ptr }, ptr %l143
  %t372 = extractvalue { i64, ptr } %t371, 1
  %t373 = extractvalue { i64, ptr } %t371, 0
  call void @__olang_sb_put(ptr %s14, ptr %t372, i64 %t373)
  %t374 = extractvalue { i64, ptr } { i64 1, ptr @.d94 }, 1
  %t375 = extractvalue { i64, ptr } { i64 1, ptr @.d94 }, 0
  call void @__olang_sb_put(ptr %s14, ptr %t374, i64 %t375)
  %t376 = load ptr, ptr %s14
  %t377 = getelementptr %olang.builder, ptr %s14, i32 0, i32 1
  %t378 = load i64, ptr %t377
  %t379 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t378)
  call void @llvm.memcpy.p0.p0.i64(ptr %t379, ptr %t376, i64 %t378, i1 false)
  %t380 = insertvalue { i64, ptr } undef, i64 %t378, 0
  %t381 = insertvalue { i64, ptr } %t380, ptr %t379, 1
  store { i64, ptr } %t381, ptr %l144
  call void @__olang_sb_done(ptr %s14)
  %t382 = load { i64, ptr }, ptr %l144
  %t383 = extractvalue { i64, ptr } %t382, 0
  %t384 = extractvalue { i64, ptr } %t382, 1
  %t385 = mul i64 %t383, 1
  %t386 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t385)
  call void @llvm.memcpy.p0.p0.i64(ptr %t386, ptr %t384, i64 %t385, i1 false)
  %t387 = insertvalue { i64, ptr } undef, i64 %t383, 0
  %t388 = insertvalue { i64, ptr } %t387, ptr %t386, 1
  store { i64, ptr } %t388, ptr %l145
  %t389 = load ptr, ptr %l139
  %t390 = load { i64, ptr }, ptr %l145
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s10, ptr %t389, { i64, ptr } %t390)
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s10)
  br label %bb60
bb60:
  store %olang.scope zeroinitializer, ptr %s15
  %t391 = load i64, ptr %l15
  store i64 %t391, ptr %l146
  %t392 = load i64, ptr %l146
  %t393 = add i64 %t392, 1
  store i64 %t393, ptr %l147
  %t394 = load i64, ptr %l147
  store i64 %t394, ptr %l15
  call void @__olang_scope_close(ptr %s15)
  br label %bb43
bb61:
  call void @__olang_scope_close(ptr %s9)
  store ptr %l2, ptr %l148
  %t395 = load ptr, ptr %l148
  %t396 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %t395)
  store { i64, ptr } %t396, ptr %l149
  br label %bb62
bb62:
  %t397 = load { i64, ptr }, ptr %l149
  store { i64, ptr } %t397, ptr %l150
  %t398 = load { i64, ptr }, ptr %l150
  %t399 = extractvalue { i64, ptr } %t398, 0
  store i64 %t399, ptr %l151
  %t400 = load i64, ptr %l151
  %t401 = mul i64 %t400, 1
  %t402 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t401)
  %t403 = insertvalue { i64, ptr } undef, i64 %t400, 0
  %t404 = insertvalue { i64, ptr } %t403, ptr %t402, 1
  store { i64, ptr } %t404, ptr %l152
  %t405 = getelementptr { i64, ptr }, ptr %l152, i32 0, i32 1
  %t406 = load ptr, ptr %t405
  %t407 = getelementptr { i64, ptr }, ptr %l150, i32 0, i32 1
  %t408 = load ptr, ptr %t407
  %t409 = load i64, ptr %l151
  %t410 = mul i64 %t409, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t406, ptr %t408, i64 %t410, i1 false)
  %t411 = load { i64, ptr }, ptr %l152
  store { i64, ptr } %t411, ptr %l150
  call void @__olang_scope_close(ptr %s0)
  %t412 = load { i64, ptr }, ptr %l150
  %t413 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t412, 1
  store { i32, { i64, ptr } } %t413, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local void @compiler_2folang_2emain() #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { ptr, ptr }
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  call void @std_2fos_2eOnCrash(ptr %s0, { i64, ptr } { i64 97, ptr @.d95 })
  br label %bb1
bb1:
  %t1 = call { i64, ptr } @std_2fos_2eArgs(ptr %s0)
  store { i64, ptr } %t1, ptr %l1
  br label %bb2
bb2:
  %t2 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t2, ptr %l0
  %t3 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t3, ptr %l2
  %t4 = getelementptr { { i64, ptr }, ptr }, ptr null, i32 1
  %t5 = ptrtoint ptr %t4 to i64
  %t6 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 %t5, i64 8)
  %t7 = load { i64, ptr }, ptr %l2
  %t8 = getelementptr { { i64, ptr }, ptr }, ptr %t6, i32 0, i32 0
  store { i64, ptr } %t7, ptr %t8
  %t9 = getelementptr { { i64, ptr }, ptr }, ptr %t6, i32 0, i32 1
  store ptr %s0, ptr %t9
  %t10 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_96, 0
  %t11 = insertvalue { ptr, ptr } %t10, ptr %t6, 1
  store { ptr, ptr } %t11, ptr %l3
  %t12 = load { ptr, ptr }, ptr %l3
  %t13 = extractvalue { ptr, ptr } %t12, 0
  %t14 = extractvalue { ptr, ptr } %t12, 1
  call void @std_2fos_2eRunOnStack(ptr %s0, i64 1073741824, ptr %t13, ptr %t14)
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2folang_2emodeName(ptr %v0, i64 %a0) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i1
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store i64 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l0
  store i64 %t1, ptr %l1
  %t2 = load i64, ptr @G_2ecompiler_2folang_2eRun
  store i64 %t2, ptr %l2
  %t3 = load i64, ptr %l1
  %t4 = load i64, ptr %l2
  %t5 = icmp eq i64 %t3, %t4
  store i1 %t5, ptr %l3
  %t6 = load i1, ptr %l3
  br i1 %t6, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 14, ptr @.d97 }, ptr %l5
  %t7 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t7, ptr %l6
  %t8 = load { i64, ptr }, ptr %l6
  store { i64, ptr } %t8, ptr %l4
  br label %bb3
bb2:
  %t9 = load i64, ptr %l0
  store i64 %t9, ptr %l7
  %t10 = load i64, ptr %l7
  %t11 = getelementptr { i64, ptr }, ptr @G_2ecompiler_2folang_2eModeWords, i32 0, i32 1
  %t12 = load ptr, ptr %t11
  %t13 = getelementptr { i64, ptr }, ptr %t12, i64 %t10
  %t14 = load { i64, ptr }, ptr %t13
  store { i64, ptr } %t14, ptr %l8
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t15 = load { i64, ptr }, ptr %l8
  %t16 = extractvalue { i64, ptr } %t15, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  call void @__olang_sb_put(ptr %s1, ptr %t16, i64 %t17)
  %t18 = load ptr, ptr %s1
  %t19 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t20 = load i64, ptr %t19
  %t21 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t20)
  call void @llvm.memcpy.p0.p0.i64(ptr %t21, ptr %t18, i64 %t20, i1 false)
  %t22 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l9
  call void @__olang_sb_done(ptr %s1)
  %t24 = load { i64, ptr }, ptr %l9
  store { i64, ptr } %t24, ptr %l4
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load { i64, ptr }, ptr %l4
  store { i64, ptr } %t25, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2folang_2emodeNumber(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i1
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i1
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i1
  %l27 = alloca i1
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca i1
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store %olang.scope zeroinitializer, ptr %s1
  store i64 1, ptr %l1
  %t1 = load { i64, ptr }, ptr @G_2ecompiler_2folang_2eModeWords
  store { i64, ptr } %t1, ptr %l7
  %t2 = load { i64, ptr }, ptr %l7
  %t3 = extractvalue { i64, ptr } %t2, 0
  store i64 %t3, ptr %l8
  %t4 = load i64, ptr %l8
  store i64 %t4, ptr %l2
  store i64 1, ptr %l3
  %t5 = load i64, ptr %l2
  store i64 %t5, ptr %l9
  %t6 = load i64, ptr %l1
  store i64 %t6, ptr %l10
  %t7 = load i64, ptr %l9
  %t8 = load i64, ptr %l10
  %t9 = icmp sgt i64 %t7, %t8
  store i1 %t9, ptr %l11
  %t10 = load i1, ptr %l11
  br i1 %t10, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l3
  store i64 %t11, ptr %l13
  %t12 = load i64, ptr %l13
  %t13 = icmp sgt i64 %t12, 0
  store i1 %t13, ptr %l14
  %t14 = load i1, ptr %l14
  br i1 %t14, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l12
  br label %bb6
bb3:
  %t15 = load i64, ptr %l2
  store i64 %t15, ptr %l16
  %t16 = load i64, ptr %l1
  store i64 %t16, ptr %l17
  %t17 = load i64, ptr %l16
  %t18 = load i64, ptr %l17
  %t19 = sub i64 %t17, %t18
  store i64 %t19, ptr %l18
  %t20 = load i64, ptr %l3
  store i64 %t20, ptr %l19
  %t21 = load i64, ptr %l18
  %t22 = load i64, ptr %l19
  %t23 = add i64 %t21, %t22
  store i64 %t23, ptr %l20
  %t24 = load i64, ptr %l20
  %t25 = sub i64 %t24, 1
  store i64 %t25, ptr %l21
  %t26 = load i64, ptr %l3
  store i64 %t26, ptr %l22
  %t27 = load i64, ptr %l21
  %t28 = load i64, ptr %l22
  %t29 = sdiv i64 %t27, %t28
  store i64 %t29, ptr %l23
  %t30 = load i64, ptr %l23
  store i64 %t30, ptr %l15
  br label %bb5
bb4:
  store i64 0, ptr %l15
  br label %bb5
bb5:
  %t31 = load i64, ptr %l15
  store i64 %t31, ptr %l12
  br label %bb6
bb6:
  %t32 = load i64, ptr %l12
  store i64 %t32, ptr %l4
  store i64 0, ptr %l5
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t33 = load i64, ptr %l5
  store i64 %t33, ptr %l24
  %t34 = load i64, ptr %l4
  store i64 %t34, ptr %l25
  %t35 = load i64, ptr %l24
  %t36 = load i64, ptr %l25
  %t37 = icmp slt i64 %t35, %t36
  store i1 %t37, ptr %l26
  %t38 = load i1, ptr %l26
  %t39 = xor i1 %t38, true
  store i1 %t39, ptr %l27
  %t40 = load i1, ptr %l27
  br i1 %t40, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb9:
  br label %bb10
bb10:
  %t41 = load i64, ptr %l1
  store i64 %t41, ptr %l28
  %t42 = load i64, ptr %l5
  store i64 %t42, ptr %l29
  %t43 = load i64, ptr %l3
  store i64 %t43, ptr %l30
  %t44 = load i64, ptr %l29
  %t45 = load i64, ptr %l30
  %t46 = mul i64 %t44, %t45
  store i64 %t46, ptr %l31
  %t47 = load i64, ptr %l28
  %t48 = load i64, ptr %l31
  %t49 = add i64 %t47, %t48
  store i64 %t49, ptr %l32
  %t50 = load i64, ptr %l32
  store i64 %t50, ptr %l6
  %t51 = load i64, ptr %l6
  store i64 %t51, ptr %l33
  %t52 = load i64, ptr %l33
  %t53 = getelementptr { i64, ptr }, ptr @G_2ecompiler_2folang_2eModeWords, i32 0, i32 1
  %t54 = load ptr, ptr %t53
  %t55 = getelementptr { i64, ptr }, ptr %t54, i64 %t52
  %t56 = load { i64, ptr }, ptr %t55
  store { i64, ptr } %t56, ptr %l34
  %t57 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t57, ptr %l35
  %t58 = load ptr, ptr @__olang_prog_scope
  %t59 = load { i64, ptr }, ptr %l34
  %t60 = load { i64, ptr }, ptr %l35
  %t61 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t58, ptr %v0, { i64, ptr } %t59, { i64, ptr } %t60)
  store i1 %t61, ptr %l36
  br label %bb11
bb11:
  %t62 = load i1, ptr %l36
  br i1 %t62, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t63 = load i64, ptr %l6
  store i64 %t63, ptr %l37
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t64 = load i64, ptr %l37
  store i64 %t64, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s4
  %t65 = load i64, ptr %l5
  store i64 %t65, ptr %l38
  %t66 = load i64, ptr %l38
  %t67 = add i64 %t66, 1
  store i64 %t67, ptr %l39
  %t68 = load i64, ptr %l39
  store i64 %t68, ptr %l5
  call void @__olang_scope_close(ptr %s4)
  br label %bb7
bb16:
  call void @__olang_scope_close(ptr %s1)
  store i64 -1, ptr %l40
  call void @__olang_scope_close(ptr %s0)
  %t69 = load i64, ptr %l40
  store i64 %t69, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2folang_2emodesOf(ptr %v0, i64 %a0) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"std/prelude/text:StringBuilder"
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i1
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i1
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i1
  %l36 = alloca i1
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca %"std/prelude/text:StringBuilder"
  %l51 = alloca { i64, ptr }
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i1
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i1
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca i64
  %l68 = alloca i64
  %l69 = alloca i64
  %l70 = alloca i1
  %l71 = alloca i1
  %l72 = alloca i64
  %l73 = alloca i64
  %l74 = alloca i64
  %l75 = alloca i64
  %l76 = alloca i64
  %l77 = alloca i64
  %l78 = alloca i64
  %l79 = alloca i64
  %l80 = alloca i64
  %l81 = alloca i1
  %l82 = alloca i64
  %l83 = alloca i64
  %l84 = alloca i64
  %l85 = alloca i1
  %l86 = alloca ptr
  %l87 = alloca i64
  %l88 = alloca i64
  %l89 = alloca i1
  %l90 = alloca { i64, ptr }
  %l91 = alloca ptr
  %l92 = alloca i64
  %l93 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l95 = alloca i64
  %l96 = alloca i64
  %l97 = alloca ptr
  %l98 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %l100 = alloca i64
  %l101 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store i64 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 0, ptr %l1
  store %olang.scope zeroinitializer, ptr %s1
  store i64 0, ptr %l2
  %t1 = load { i64, ptr }, ptr @G_2ecompiler_2folang_2eModeWords
  store { i64, ptr } %t1, ptr %l16
  %t2 = load { i64, ptr }, ptr %l16
  %t3 = extractvalue { i64, ptr } %t2, 0
  store i64 %t3, ptr %l17
  %t4 = load i64, ptr %l17
  store i64 %t4, ptr %l3
  store i64 1, ptr %l4
  %t5 = load i64, ptr %l3
  store i64 %t5, ptr %l18
  %t6 = load i64, ptr %l2
  store i64 %t6, ptr %l19
  %t7 = load i64, ptr %l18
  %t8 = load i64, ptr %l19
  %t9 = icmp sgt i64 %t7, %t8
  store i1 %t9, ptr %l20
  %t10 = load i1, ptr %l20
  br i1 %t10, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l4
  store i64 %t11, ptr %l22
  %t12 = load i64, ptr %l22
  %t13 = icmp sgt i64 %t12, 0
  store i1 %t13, ptr %l23
  %t14 = load i1, ptr %l23
  br i1 %t14, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l21
  br label %bb6
bb3:
  %t15 = load i64, ptr %l3
  store i64 %t15, ptr %l25
  %t16 = load i64, ptr %l2
  store i64 %t16, ptr %l26
  %t17 = load i64, ptr %l25
  %t18 = load i64, ptr %l26
  %t19 = sub i64 %t17, %t18
  store i64 %t19, ptr %l27
  %t20 = load i64, ptr %l4
  store i64 %t20, ptr %l28
  %t21 = load i64, ptr %l27
  %t22 = load i64, ptr %l28
  %t23 = add i64 %t21, %t22
  store i64 %t23, ptr %l29
  %t24 = load i64, ptr %l29
  %t25 = sub i64 %t24, 1
  store i64 %t25, ptr %l30
  %t26 = load i64, ptr %l4
  store i64 %t26, ptr %l31
  %t27 = load i64, ptr %l30
  %t28 = load i64, ptr %l31
  %t29 = sdiv i64 %t27, %t28
  store i64 %t29, ptr %l32
  %t30 = load i64, ptr %l32
  store i64 %t30, ptr %l24
  br label %bb5
bb4:
  store i64 0, ptr %l24
  br label %bb5
bb5:
  %t31 = load i64, ptr %l24
  store i64 %t31, ptr %l21
  br label %bb6
bb6:
  %t32 = load i64, ptr %l21
  store i64 %t32, ptr %l5
  store i64 0, ptr %l6
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t33 = load i64, ptr %l6
  store i64 %t33, ptr %l33
  %t34 = load i64, ptr %l5
  store i64 %t34, ptr %l34
  %t35 = load i64, ptr %l33
  %t36 = load i64, ptr %l34
  %t37 = icmp slt i64 %t35, %t36
  store i1 %t37, ptr %l35
  %t38 = load i1, ptr %l35
  %t39 = xor i1 %t38, true
  store i1 %t39, ptr %l36
  %t40 = load i1, ptr %l36
  br i1 %t40, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb9:
  br label %bb10
bb10:
  %t41 = load i64, ptr %l2
  store i64 %t41, ptr %l37
  %t42 = load i64, ptr %l6
  store i64 %t42, ptr %l38
  %t43 = load i64, ptr %l4
  store i64 %t43, ptr %l39
  %t44 = load i64, ptr %l38
  %t45 = load i64, ptr %l39
  %t46 = mul i64 %t44, %t45
  store i64 %t46, ptr %l40
  %t47 = load i64, ptr %l37
  %t48 = load i64, ptr %l40
  %t49 = add i64 %t47, %t48
  store i64 %t49, ptr %l41
  %t50 = load i64, ptr %l41
  store i64 %t50, ptr %l7
  %t51 = load i64, ptr %l1
  store i64 %t51, ptr %l42
  %t52 = load i64, ptr %l0
  store i64 %t52, ptr %l43
  %t53 = load i64, ptr %l7
  store i64 %t53, ptr %l44
  %t54 = load i64, ptr %l43
  %t55 = load i64, ptr %l44
  %t56 = load i64, ptr %l44
  %t57 = ashr i64 %t54, %t56
  store i64 %t57, ptr %l45
  %t58 = load i64, ptr %l45
  %t59 = and i64 %t58, 1
  store i64 %t59, ptr %l46
  %t60 = load i64, ptr %l42
  %t61 = load i64, ptr %l46
  %t62 = add i64 %t60, %t61
  store i64 %t62, ptr %l47
  %t63 = load i64, ptr %l47
  store i64 %t63, ptr %l1
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t64 = load i64, ptr %l6
  store i64 %t64, ptr %l48
  %t65 = load i64, ptr %l48
  %t66 = add i64 %t65, 1
  store i64 %t66, ptr %l49
  %t67 = load i64, ptr %l49
  store i64 %t67, ptr %l6
  call void @__olang_scope_close(ptr %s3)
  br label %bb7
bb12:
  call void @__olang_scope_close(ptr %s1)
  %t68 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t68, ptr %l50
  br label %bb13
bb13:
  %t69 = load %"std/prelude/text:StringBuilder", ptr %l50
  store %"std/prelude/text:StringBuilder" %t69, ptr %l8
  store i64 0, ptr %l9
  store %olang.scope zeroinitializer, ptr %s4
  store i64 0, ptr %l10
  %t70 = load { i64, ptr }, ptr @G_2ecompiler_2folang_2eModeWords
  store { i64, ptr } %t70, ptr %l51
  %t71 = load { i64, ptr }, ptr %l51
  %t72 = extractvalue { i64, ptr } %t71, 0
  store i64 %t72, ptr %l52
  %t73 = load i64, ptr %l52
  store i64 %t73, ptr %l11
  store i64 1, ptr %l12
  %t74 = load i64, ptr %l11
  store i64 %t74, ptr %l53
  %t75 = load i64, ptr %l10
  store i64 %t75, ptr %l54
  %t76 = load i64, ptr %l53
  %t77 = load i64, ptr %l54
  %t78 = icmp sgt i64 %t76, %t77
  store i1 %t78, ptr %l55
  %t79 = load i1, ptr %l55
  br i1 %t79, label %bb14, label %bb15
bb14:
  %t80 = load i64, ptr %l12
  store i64 %t80, ptr %l57
  %t81 = load i64, ptr %l57
  %t82 = icmp sgt i64 %t81, 0
  store i1 %t82, ptr %l58
  %t83 = load i1, ptr %l58
  br i1 %t83, label %bb16, label %bb17
bb15:
  store i64 0, ptr %l56
  br label %bb19
bb16:
  %t84 = load i64, ptr %l11
  store i64 %t84, ptr %l60
  %t85 = load i64, ptr %l10
  store i64 %t85, ptr %l61
  %t86 = load i64, ptr %l60
  %t87 = load i64, ptr %l61
  %t88 = sub i64 %t86, %t87
  store i64 %t88, ptr %l62
  %t89 = load i64, ptr %l12
  store i64 %t89, ptr %l63
  %t90 = load i64, ptr %l62
  %t91 = load i64, ptr %l63
  %t92 = add i64 %t90, %t91
  store i64 %t92, ptr %l64
  %t93 = load i64, ptr %l64
  %t94 = sub i64 %t93, 1
  store i64 %t94, ptr %l65
  %t95 = load i64, ptr %l12
  store i64 %t95, ptr %l66
  %t96 = load i64, ptr %l65
  %t97 = load i64, ptr %l66
  %t98 = sdiv i64 %t96, %t97
  store i64 %t98, ptr %l67
  %t99 = load i64, ptr %l67
  store i64 %t99, ptr %l59
  br label %bb18
bb17:
  store i64 0, ptr %l59
  br label %bb18
bb18:
  %t100 = load i64, ptr %l59
  store i64 %t100, ptr %l56
  br label %bb19
bb19:
  %t101 = load i64, ptr %l56
  store i64 %t101, ptr %l13
  store i64 0, ptr %l14
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s5
  %t102 = load i64, ptr %l14
  store i64 %t102, ptr %l68
  %t103 = load i64, ptr %l13
  store i64 %t103, ptr %l69
  %t104 = load i64, ptr %l68
  %t105 = load i64, ptr %l69
  %t106 = icmp slt i64 %t104, %t105
  store i1 %t106, ptr %l70
  %t107 = load i1, ptr %l70
  %t108 = xor i1 %t107, true
  store i1 %t108, ptr %l71
  %t109 = load i1, ptr %l71
  br i1 %t109, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s5)
  br label %bb37
bb22:
  br label %bb23
bb23:
  %t110 = load i64, ptr %l10
  store i64 %t110, ptr %l72
  %t111 = load i64, ptr %l14
  store i64 %t111, ptr %l73
  %t112 = load i64, ptr %l12
  store i64 %t112, ptr %l74
  %t113 = load i64, ptr %l73
  %t114 = load i64, ptr %l74
  %t115 = mul i64 %t113, %t114
  store i64 %t115, ptr %l75
  %t116 = load i64, ptr %l72
  %t117 = load i64, ptr %l75
  %t118 = add i64 %t116, %t117
  store i64 %t118, ptr %l76
  %t119 = load i64, ptr %l76
  store i64 %t119, ptr %l15
  %t120 = load i64, ptr %l0
  store i64 %t120, ptr %l77
  %t121 = load i64, ptr %l15
  store i64 %t121, ptr %l78
  %t122 = load i64, ptr %l77
  %t123 = load i64, ptr %l78
  %t124 = load i64, ptr %l78
  %t125 = ashr i64 %t122, %t124
  store i64 %t125, ptr %l79
  %t126 = load i64, ptr %l79
  %t127 = and i64 %t126, 1
  store i64 %t127, ptr %l80
  %t128 = load i64, ptr %l80
  %t129 = icmp eq i64 %t128, 0
  store i1 %t129, ptr %l81
  %t130 = load i1, ptr %l81
  br i1 %t130, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s6
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  br label %bb36
bb25:
  br label %bb26
bb26:
  %t131 = load i64, ptr %l9
  store i64 %t131, ptr %l82
  %t132 = load i64, ptr %l82
  %t133 = add i64 %t132, 1
  store i64 %t133, ptr %l83
  %t134 = load i64, ptr %l83
  store i64 %t134, ptr %l9
  %t135 = load i64, ptr %l9
  store i64 %t135, ptr %l84
  %t136 = load i64, ptr %l84
  %t137 = icmp sgt i64 %t136, 1
  store i1 %t137, ptr %l85
  %t138 = load i1, ptr %l85
  br i1 %t138, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s7
  store ptr %l8, ptr %l86
  %t139 = load i64, ptr %l9
  store i64 %t139, ptr %l87
  %t140 = load i64, ptr %l1
  store i64 %t140, ptr %l88
  %t141 = load i64, ptr %l87
  %t142 = load i64, ptr %l88
  %t143 = icmp eq i64 %t141, %t142
  store i1 %t143, ptr %l89
  %t144 = load i1, ptr %l89
  br i1 %t144, label %bb29, label %bb30
bb28:
  br label %bb33
bb29:
  store { i64, ptr } { i64 5, ptr @.d98 }, ptr %l90
  br label %bb31
bb30:
  store { i64, ptr } { i64 2, ptr @.d99 }, ptr %l90
  br label %bb31
bb31:
  %t145 = load ptr, ptr %l86
  %t146 = load { i64, ptr }, ptr %l90
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %t145, { i64, ptr } %t146)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s7)
  br label %bb33
bb33:
  store ptr %l8, ptr %l91
  %t147 = load i64, ptr %l15
  store i64 %t147, ptr %l92
  %t148 = load i64, ptr %l92
  %t149 = call { i64, ptr } @compiler_2folang_2emodeName(ptr %s5, i64 %t148)
  store { i64, ptr } %t149, ptr %l93
  br label %bb34
bb34:
  %t150 = load { i64, ptr }, ptr %l93
  %t151 = extractvalue { i64, ptr } %t150, 0
  %t152 = extractvalue { i64, ptr } %t150, 1
  %t153 = mul i64 %t151, 1
  %t154 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t153)
  call void @llvm.memcpy.p0.p0.i64(ptr %t154, ptr %t152, i64 %t153, i1 false)
  %t155 = insertvalue { i64, ptr } undef, i64 %t151, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t154, 1
  store { i64, ptr } %t156, ptr %l94
  %t157 = load ptr, ptr %l91
  %t158 = load { i64, ptr }, ptr %l94
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %t157, { i64, ptr } %t158)
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s5)
  br label %bb36
bb36:
  store %olang.scope zeroinitializer, ptr %s8
  %t159 = load i64, ptr %l14
  store i64 %t159, ptr %l95
  %t160 = load i64, ptr %l95
  %t161 = add i64 %t160, 1
  store i64 %t161, ptr %l96
  %t162 = load i64, ptr %l96
  store i64 %t162, ptr %l14
  call void @__olang_scope_close(ptr %s8)
  br label %bb20
bb37:
  call void @__olang_scope_close(ptr %s4)
  store ptr %l8, ptr %l97
  %t163 = load ptr, ptr %l97
  %t164 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v0, ptr %t163)
  store { i64, ptr } %t164, ptr %l98
  br label %bb38
bb38:
  %t165 = load { i64, ptr }, ptr %l98
  store { i64, ptr } %t165, ptr %l99
  %t166 = load { i64, ptr }, ptr %l99
  %t167 = extractvalue { i64, ptr } %t166, 0
  store i64 %t167, ptr %l100
  %t168 = load i64, ptr %l100
  %t169 = mul i64 %t168, 1
  %t170 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t169)
  %t171 = insertvalue { i64, ptr } undef, i64 %t168, 0
  %t172 = insertvalue { i64, ptr } %t171, ptr %t170, 1
  store { i64, ptr } %t172, ptr %l101
  %t173 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t174 = load ptr, ptr %t173
  %t175 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t176 = load ptr, ptr %t175
  %t177 = load i64, ptr %l100
  %t178 = mul i64 %t177, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t174, ptr %t176, i64 %t178, i1 false)
  %t179 = load { i64, ptr }, ptr %l101
  store { i64, ptr } %t179, ptr %l99
  call void @__olang_scope_close(ptr %s0)
  %t180 = load { i64, ptr }, ptr %l99
  store { i64, ptr } %t180, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"std/prelude/list:List<compiler/typed:Plan>" @compiler_2folang_2eplacement(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca %"std/prelude/list:List<mut compiler/typed:Body&>"
  %l7 = alloca %"compiler/scope:Scoper"
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca %"std/prelude/list:List<compiler/typed:Plan>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List<compiler/typed:Plan>"
  %t9 = alloca %"compiler/scope:Scoper", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l3
  %t2 = load ptr, ptr %l3
  %t3 = getelementptr %"compiler/check:Checker", ptr %t2, i32 0, i32 0
  %t4 = load ptr, ptr %t3
  store ptr %t4, ptr %l4
  %t5 = load ptr, ptr %l0
  store ptr %t5, ptr %l5
  %t6 = load ptr, ptr %l5
  %t7 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 4
  %t8 = load %"std/prelude/list:List<mut compiler/typed:Body&>", ptr %t7
  store %"std/prelude/list:List<mut compiler/typed:Body&>" %t8, ptr %l6
  %t10 = load ptr, ptr %l4
  %t11 = load %"std/prelude/list:List<mut compiler/typed:Body&>", ptr %l6
  call void @compiler_2fscope_3aScoper_2ector(ptr %t9, ptr %v0, ptr %v0, ptr %v1, ptr %t10, %"std/prelude/list:List<mut compiler/typed:Body&>" %t11)
  %t12 = load %"compiler/scope:Scoper", ptr %t9
  store %"compiler/scope:Scoper" %t12, ptr %l7
  br label %bb1
bb1:
  %t13 = load %"compiler/scope:Scoper", ptr %l7
  %t14 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 880, i64 8)
  store %"compiler/scope:Scoper" %t13, ptr %t14
  store ptr %t14, ptr %l8
  %t15 = load ptr, ptr %l8
  store ptr %t15, ptr %l2
  %t16 = load ptr, ptr %l2
  store ptr %t16, ptr %l9
  %t17 = load ptr, ptr %l9
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eRun(ptr %v1, ptr %t17)
  br label %bb2
bb2:
  %t18 = load ptr, ptr %l2
  store ptr %t18, ptr %l10
  %t19 = load ptr, ptr %l10
  %t20 = getelementptr %"compiler/scope:Scoper", ptr %t19, i32 0, i32 2
  %t21 = load %"std/prelude/list:List<compiler/typed:Plan>", ptr %t20
  store %"std/prelude/list:List<compiler/typed:Plan>" %t21, ptr %l11
  call void @__olang_scope_close(ptr %s0)
  %t22 = load %"std/prelude/list:List<compiler/typed:Plan>", ptr %l11
  store %"std/prelude/list:List<compiler/typed:Plan>" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List<compiler/typed:Plan>", ptr %rv
  ret %"std/prelude/list:List<compiler/typed:Plan>" %rr
}

define dso_local i32 @compiler_2folang_2esaid(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l1
  %t2 = load ptr, ptr %l1
  %t3 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v0, ptr %s0, ptr %t2)
  store { i64, ptr } %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 0
  %t6 = extractvalue { i64, ptr } %t4, 1
  %t7 = mul i64 %t5, 1
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @llvm.memcpy.p0.p0.i64(ptr %t8, ptr %t6, i64 %t7, i1 false)
  %t9 = insertvalue { i64, ptr } undef, i64 %t5, 0
  %t10 = insertvalue { i64, ptr } %t9, ptr %t8, 1
  store { i64, ptr } %t10, ptr %l3
  %t11 = load { i64, ptr }, ptr %l3
  %t12 = call i32 @compiler_2folang_2ewrite(ptr %s0, { i64, ptr } %t11)
  store i32 %t12, ptr %l4
  br label %bb2
bb2:
  store i32 1, ptr %l5
  call void @__olang_scope_close(ptr %s0)
  %t13 = load i32, ptr %l5
  store i32 %t13, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2folang_2eusage(ptr %v0, ptr %v1, ptr %a0, %"compiler/msgs:Msg" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/msgs:Msg"
  %l2 = alloca ptr
  %l3 = alloca { i64, [3 x i64] }
  %l4 = alloca %"compiler/msgs:Msg"
  %l5 = alloca i64
  %l6 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  %t2 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/msgs:Msg" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l2
  store { i64, [3 x i64] } zeroinitializer, ptr %t2
  %t3 = getelementptr { i64, [3 x i64] }, ptr %t2, i32 0, i32 0
  store i64 0, ptr %t3
  %t4 = load { i64, [3 x i64] }, ptr %t2
  store { i64, [3 x i64] } %t4, ptr %l3
  %t5 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t5, ptr %l4
  %t6 = load ptr, ptr %l2
  %t7 = load { i64, [3 x i64] }, ptr %l3
  %t8 = load %"compiler/msgs:Msg", ptr %l4
  %t9 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %t6, { i64, [3 x i64] } %t7, %"compiler/msgs:Msg" %t8)
  store i64 %t9, ptr %l5
  br label %bb1
bb1:
  store i32 65536, ptr %l6
  call void @__olang_scope_close(ptr %s0)
  %t10 = load i32, ptr %l6
  store i32 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2folang_2ewrite(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i1
  %l5 = alloca i32
  %l6 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l1
  %t2 = load { i64, ptr }, ptr %l1
  %t3 = call i32 @std_2fio_2ePrint(ptr %v0, { i64, ptr } %t2)
  store i32 %t3, ptr %l2
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  br label %bb1
bb1:
  br label %bb6
bb2:
  %t6 = load i32, ptr %l2
  %t7 = ashr i32 %t6, 16
  store i32 %t7, ptr %l3
  %t8 = load i32, ptr %l3
  %t9 = icmp eq i32 %t8, 1
  store i1 %t9, ptr %l4
  %t10 = load i1, ptr %l4
  br i1 %t10, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @.c100)
  unreachable
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  store i32 1, ptr %l5
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t11 = load i32, ptr %l5
  store i32 %t11, ptr %rv
  br label %ret
bb6:
  store i32 0, ptr %l6
  call void @__olang_scope_close(ptr %s0)
  %t12 = load i32, ptr %l6
  store i32 %t12, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"compiler/olang:CommandLine" @compiler_2folang_3aCommandLine_2ector(ptr %v0) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i1
  %l4 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l5 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i1
  %l9 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l10 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l11 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l12 = alloca %"compiler/olang:CommandLine"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/olang:CommandLine"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 0, ptr %l0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<std/prelude/text:String&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t1)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t2, ptr %l9
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l9
  store %"std/prelude/list:List<std/prelude/text:String&>" %t3, ptr %l1
  store { i64, ptr } { i64 0, ptr @.d101 }, ptr %l2
  store i1 false, ptr %l3
  %t4 = load ptr, ptr @__olang_prog_scope
  %t5 = call %"std/prelude/list:List<std/prelude/text:String&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t4)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t5, ptr %l10
  br label %bb2
bb2:
  %t6 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l10
  store %"std/prelude/list:List<std/prelude/text:String&>" %t6, ptr %l4
  %t7 = load ptr, ptr @__olang_prog_scope
  %t8 = call %"std/prelude/list:List<std/prelude/text:String&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t7)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t8, ptr %l11
  br label %bb3
bb3:
  %t9 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l11
  store %"std/prelude/list:List<std/prelude/text:String&>" %t9, ptr %l5
  store { i64, ptr } { i64 6, ptr @.d102 }, ptr %l6
  store { i64, ptr } { i64 0, ptr @.d103 }, ptr %l7
  store i1 false, ptr %l8
  %t10 = load i64, ptr %l0
  %t11 = insertvalue %"compiler/olang:CommandLine" undef, i64 %t10, 0
  %t12 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l1
  %t13 = insertvalue %"compiler/olang:CommandLine" %t11, %"std/prelude/list:List<std/prelude/text:String&>" %t12, 1
  %t14 = load { i64, ptr }, ptr %l2
  %t15 = insertvalue %"compiler/olang:CommandLine" %t13, { i64, ptr } %t14, 2
  %t16 = load i1, ptr %l3
  %t17 = insertvalue %"compiler/olang:CommandLine" %t15, i1 %t16, 3
  %t18 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l4
  %t19 = insertvalue %"compiler/olang:CommandLine" %t17, %"std/prelude/list:List<std/prelude/text:String&>" %t18, 4
  %t20 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l5
  %t21 = insertvalue %"compiler/olang:CommandLine" %t19, %"std/prelude/list:List<std/prelude/text:String&>" %t20, 5
  %t22 = load { i64, ptr }, ptr %l6
  %t23 = insertvalue %"compiler/olang:CommandLine" %t21, { i64, ptr } %t22, 6
  %t24 = load { i64, ptr }, ptr %l7
  %t25 = insertvalue %"compiler/olang:CommandLine" %t23, { i64, ptr } %t24, 7
  %t26 = load i1, ptr %l8
  %t27 = insertvalue %"compiler/olang:CommandLine" %t25, i1 %t26, 8
  store %"compiler/olang:CommandLine" %t27, ptr %l12
  call void @__olang_scope_close(ptr %s0)
  %t28 = load %"compiler/olang:CommandLine", ptr %l12
  store %"compiler/olang:CommandLine" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/olang:CommandLine", ptr %rv
  ret %"compiler/olang:CommandLine" %rr
}

define dso_local %"compiler/olang:Passes" @compiler_2folang_3aPasses_2ector(ptr %v0) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca %"compiler/olang:Passes"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/olang:Passes"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 0, ptr %l0
  %t1 = load i64, ptr %l0
  %t2 = insertvalue %"compiler/olang:Passes" undef, i64 %t1, 0
  store %"compiler/olang:Passes" %t2, ptr %l1
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/olang:Passes", ptr %l1
  store %"compiler/olang:Passes" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/olang:Passes", ptr %rv
  ret %"compiler/olang:Passes" %rr
}

define i32 @main(i32 %argc, ptr %argv) #0 {
entry:
  store i32 %argc, ptr @__olang_argc
  store ptr %argv, ptr @__olang_argv
  call void @__olang_thread_init()
  call void @std_2fprelude_2farray_2esortRun_2einit()
  call void @std_2fprelude_2farray_2esortBlock_2einit()
  call void @std_2fprelude_2flist_2efirstChunkLog_2einit()
  call void @std_2fprelude_2flist_2efirstChunk_2einit()
  call void @std_2fprelude_2fnumber_2ePi_2einit()
  call void @std_2fprelude_2fnumber_2eEuler_2einit()
  call void @std_2fprelude_2fnumber_2eInf_2einit()
  call void @std_2fprelude_2fnumber_2eNaN_2einit()
  call void @std_2fprelude_2ftext_2eexactPow10_2einit()
  call void @std_2fprelude_2ftext_2edecimalShifts_2einit()
  call void @std_2fprelude_2ftext_2emask63_2einit()
  call void @std_2fprelude_2ftext_2epow10Mant_2einit()
  call void @std_2fio_2eStdin_2einit()
  call void @std_2fio_2eStdout_2einit()
  call void @std_2fio_2eStderr_2einit()
  call void @std_2fcancel_2eClockRealtime_2einit()
  call void @std_2fcancel_2eClockMonotonic_2einit()
  call void @std_2fcancel_2ePollNs_2einit()
  call void @std_2fchan_2eMutexWords_2einit()
  call void @std_2fchan_2eCondWords_2einit()
  call void @compiler_2fmsgs_2eEndOfLine_2einit()
  call void @compiler_2fmsgs_2eEndOfFile_2einit()
  call void @compiler_2fdiag_2ePending_2einit()
  call void @compiler_2fdiag_2eChosen_2einit()
  call void @compiler_2fdiag_2eDropped_2einit()
  call void @compiler_2fdiag_2eCut_2einit()
  call void @compiler_2fdiag_2eExcerptMax_2einit()
  call void @compiler_2fdiag_2eExcerptAround_2einit()
  call void @compiler_2ftoken_2eLineBreak_2einit()
  call void @compiler_2ftoken_2eSpace_2einit()
  call void @compiler_2ftoken_2eLineStart_2einit()
  call void @compiler_2fcond_2eLiteralIntBits_2einit()
  call void @compiler_2ftarget_2eArchs_2einit()
  call void @compiler_2ftarget_2eArchCpuFlags_2einit()
  call void @compiler_2ftarget_2eArchDefaultCpus_2einit()
  call void @compiler_2ftarget_2eIeeeUnsafe_2einit()
  call void @compiler_2ftarget_2eLevelFlags_2einit()
  call void @compiler_2ftarget_2eSkylakeProbe_2einit()
  call void @compiler_2fbuild_2eShaK_2einit()
  call void @std_2fpair_2ePairOfTextBaked_2einit()
  call void @std_2ffilepath_2ecleanCases_2einit()
  call void @std_2ffilepath_2ecleanMissesBaked_2einit()
  call void @std_2ffilepath_2epartCases_2einit()
  call void @std_2ffilepath_2epartMissesBaked_2einit()
  call void @std_2ffilepath_2erelCases_2einit()
  call void @std_2ffilepath_2erelMissesBaked_2einit()
  call void @std_2ffilepath_2elivePath_2einit()
  call void @compiler_2fparse_2eMaxNesting_2einit()
  call void @compiler_2fload_2eNotYet_2einit()
  call void @compiler_2fload_2ePending_2einit()
  call void @compiler_2fload_2eNoBranch_2einit()
  call void @compiler_2ftypes_2eReadOnly_2einit()
  call void @compiler_2ftypes_2eWritable_2einit()
  call void @compiler_2ftypes_2eOwning_2einit()
  call void @compiler_2ftypes_2eRoleFn_2einit()
  call void @compiler_2ftypes_2eRoleCtor_2einit()
  call void @compiler_2ftypes_2eRoleDtor_2einit()
  call void @compiler_2ftypes_2eOwnScope_2einit()
  call void @compiler_2ftypes_2eFromTypeVar_2einit()
  call void @compiler_2ftypes_2eResultVar_2einit()
  call void @compiler_2ftypes_2eClosingVar_2einit()
  call void @compiler_2ftypes_2eNotLaidOut_2einit()
  call void @compiler_2ftypes_2eLayingOut_2einit()
  call void @compiler_2ftypes_2eLaidOut_2einit()
  call void @compiler_2ftypes_2eNoLayout_2einit()
  call void @compiler_2ftypes_2eUnknownT_2einit()
  call void @compiler_2ftypes_2eVoidT_2einit()
  call void @compiler_2ftypes_2eBoolT_2einit()
  call void @compiler_2ftypes_2eNullT_2einit()
  call void @compiler_2ftypes_2eDefaultErrT_2einit()
  call void @compiler_2ftypes_2eNoreturnT_2einit()
  call void @compiler_2ftypes_2eprimNames_2einit()
  call void @compiler_2ftypes_2eprimLlvm_2einit()
  call void @compiler_2ftypes_2eprimBits_2einit()
  call void @compiler_2ftypes_2eBigAggregate_2einit()
  call void @compiler_2fgeneric_2eNoOrigin_2einit()
  call void @compiler_2fgeneric_2eMaxDepth_2einit()
  call void @compiler_2fgeneric_2eMaxChain_2einit()
  call void @compiler_2fgeneric_2eFolded_2einit()
  call void @compiler_2fgeneric_2ePending_2einit()
  call void @compiler_2fgeneric_2eUnfolded_2einit()
  call void @compiler_2fgeneric_2eArrayKey_2einit()
  call void @compiler_2fscope_2eWhyHolds_2einit()
  call void @compiler_2fscope_2eWhyField_2einit()
  call void @compiler_2fscope_2eHolds_2einit()
  call void @compiler_2fscope_2eObliged_2einit()
  call void @compiler_2fscope_2eFailsBlock_2einit()
  call void @compiler_2fscope_2eFailsUnknown_2einit()
  call void @compiler_2fscope_2eFnNamed_2einit()
  call void @compiler_2fscope_2eFnLambda_2einit()
  call void @compiler_2fscope_2eFnCall_2einit()
  call void @compiler_2fscope_2eUseThru_2einit()
  call void @compiler_2fscope_2eUseView_2einit()
  call void @compiler_2fscope_2eFitLocal_2einit()
  call void @compiler_2fscope_2eFitField_2einit()
  call void @compiler_2fscope_2eFitGlobal_2einit()
  call void @compiler_2fscope_2eFitReturn_2einit()
  call void @compiler_2fscope_2eFitValue_2einit()
  call void @compiler_2fscope_2eFitPayload_2einit()
  call void @compiler_2fscope_2eFitDecl_2einit()
  call void @compiler_2fscope_2eFitOwn_2einit()
  call void @compiler_2fscope_2eFitElem_2einit()
  call void @compiler_2fmir_2eNoBlock_2einit()
  call void @compiler_2fmir_2eNoLocal_2einit()
  call void @compiler_2fmir_2eNoScope_2einit()
  call void @compiler_2fmir_2eEmpty_2einit()
  call void @compiler_2fmir_2eNoPlace_2einit()
  call void @compiler_2fmir_2eI32T_2einit()
  call void @compiler_2fmir_2eI64T_2einit()
  call void @compiler_2fmir_2eSp0_2einit()
  call void @compiler_2fcheck_2eOpShapes_2einit()
  call void @compiler_2fcheck_2eBounds_2einit()
  call void @compiler_2fcheck_2eDivideByZero_2einit()
  call void @compiler_2fcheck_2eOverflow_2einit()
  call void @compiler_2fcheck_2eInvalid_2einit()
  call void @compiler_2fcheck_2eWrongCase_2einit()
  call void @compiler_2fcheck_2eRoStored_2einit()
  call void @compiler_2fcheck_2eRoDecl_2einit()
  call void @compiler_2fcheck_2eRoReturned_2einit()
  call void @compiler_2fcheck_2eRoGlobal_2einit()
  call void @compiler_2fcheck_2eliteralOrder_2einit()
  call void @compiler_2flower_2eOutOfBounds_2einit()
  call void @compiler_2flower_2eDivideByZero_2einit()
  call void @compiler_2flower_2eOverflow_2einit()
  call void @compiler_2flower_2eInvalid_2einit()
  call void @compiler_2flower_2eWrongCase_2einit()
  call void @compiler_2funparse_2eMaxIndent_2einit()
  call void @compiler_2feval_2eWhyMutableGlobal_2einit()
  call void @compiler_2feval_2eWhyChangeable_2einit()
  call void @compiler_2feval_2eWhyWritesGlobal_2einit()
  call void @compiler_2feval_2eWhyCycle_2einit()
  call void @compiler_2feval_2eWhyNoValue_2einit()
  call void @compiler_2feval_2eWhyDestructor_2einit()
  call void @compiler_2feval_2eWhyExtern_2einit()
  call void @compiler_2feval_2eWhyEnds_2einit()
  call void @compiler_2feval_2eWhySteps_2einit()
  call void @compiler_2feval_2eWhyMemory_2einit()
  call void @compiler_2feval_2eWhyDepth_2einit()
  call void @compiler_2feval_2eWhyRunDepth_2einit()
  call void @compiler_2feval_2eWhyNull_2einit()
  call void @compiler_2feval_2eWhyNullCall_2einit()
  call void @compiler_2feval_2eWhyClosed_2einit()
  call void @compiler_2feval_2eWhyOutside_2einit()
  call void @compiler_2feval_2eWhyBeyond_2einit()
  call void @compiler_2feval_2eWhyReadOnly_2einit()
  call void @compiler_2feval_2eWhyDivZero_2einit()
  call void @compiler_2feval_2eWhyDivMin_2einit()
  call void @compiler_2feval_2eWhyShift_2einit()
  call void @compiler_2feval_2eWhyConvert_2einit()
  call void @compiler_2feval_2eWhyNaNOp_2einit()
  call void @compiler_2feval_2eWhyNaNSignal_2einit()
  call void @compiler_2feval_2eWhyNoBody_2einit()
  call void @compiler_2feval_2eWhyNotModelled_2einit()
  call void @compiler_2feval_2eWhyPayload_2einit()
  call void @compiler_2feval_2eWhyLong_2einit()
  call void @compiler_2feval_2eWhyFfiFind_2einit()
  call void @compiler_2feval_2eWhyFfiPass_2einit()
  call void @compiler_2feval_2eWhyNoClause_2einit()
  call void @compiler_2feval_2eWhyWaits_2einit()
  call void @compiler_2feval_2eNullPtr_2einit()
  call void @compiler_2feval_2eslotBits_2einit()
  call void @compiler_2feval_2eslotMask_2einit()
  call void @compiler_2feval_2eaFree_2einit()
  call void @compiler_2feval_2eaValue_2einit()
  call void @compiler_2feval_2eaData_2einit()
  call void @compiler_2feval_2eaGlobal_2einit()
  call void @compiler_2feval_2eaCode_2einit()
  call void @compiler_2feval_2esBlock_2einit()
  call void @compiler_2feval_2esStore_2einit()
  call void @compiler_2feval_2esProgram_2einit()
  call void @compiler_2feval_2esInert_2einit()
  call void @compiler_2feval_2esBuilder_2einit()
  call void @compiler_2feval_2esRegion_2einit()
  call void @compiler_2feval_2esJoin_2einit()
  call void @compiler_2feval_2egDtor_2einit()
  call void @compiler_2feval_2egOwner_2einit()
  call void @compiler_2feval_2erRequest_2einit()
  call void @compiler_2feval_2erCall_2einit()
  call void @compiler_2feval_2erDtor_2einit()
  call void @compiler_2feval_2erTask_2einit()
  call void @compiler_2feval_2erClause_2einit()
  call void @compiler_2feval_2erGlobal_2einit()
  call void @compiler_2feval_2etRaised_2einit()
  call void @compiler_2feval_2etCall_2einit()
  call void @compiler_2feval_2etJoin_2einit()
  call void @compiler_2feval_2etraceKept_2einit()
  call void @compiler_2feval_2evVoid_2einit()
  call void @compiler_2feval_2evBool_2einit()
  call void @compiler_2feval_2evInt_2einit()
  call void @compiler_2feval_2evUint_2einit()
  call void @compiler_2feval_2evFloat_2einit()
  call void @compiler_2feval_2evPtr_2einit()
  call void @compiler_2feval_2evPair_2einit()
  call void @compiler_2feval_2evFunc_2einit()
  call void @compiler_2feval_2evEnum_2einit()
  call void @compiler_2feval_2evOrd_2einit()
  call void @compiler_2feval_2evAgg_2einit()
  call void @compiler_2feval_2evFixed_2einit()
  call void @compiler_2feval_2evNone_2einit()
  call void @compiler_2feval_2emathNames_2einit()
  call void @compiler_2feval_2emathArity_2einit()
  call void @compiler_2feval_2eSp0_2einit()
  call void @compiler_2feval_2eB0_2einit()
  call void @compiler_2feval_2eS0_2einit()
  call void @compiler_2feval_2eIntOps_2einit()
  call void @compiler_2feval_2eCmpOps_2einit()
  call void @compiler_2feval_2eFloatOps_2einit()
  call void @compiler_2feval_2eNumNames_2einit()
  call void @compiler_2femit_2eHomeShared_2einit()
  call void @compiler_2femit_2eHomeLocal_2einit()
  call void @compiler_2femit_2eHomeInst_2einit()
  call void @compiler_2femit_2eruntimeTypes_2einit()
  call void @compiler_2fruntime_2eArchs_2einit()
  call void @compiler_2fruntime_2eFactNames_2einit()
  call void @compiler_2fruntime_2eFactX86_2einit()
  call void @compiler_2fruntime_2eFactArm_2einit()
  call void @compiler_2fruntime_2eHeaderTbaa_2einit()
  call void @compiler_2folang_2eModeWords_2einit()
  call void @compiler_2folang_2eRun_2einit()
  call void @compiler_2folang_2eBuild_2einit()
  call void @compiler_2folang_2eCompile_2einit()
  call void @compiler_2folang_2eTest_2einit()
  call void @compiler_2folang_2eInterp_2einit()
  call void @compiler_2folang_2eFormat_2einit()
  call void @compiler_2folang_2eExplain_2einit()
  call void @compiler_2folang_2eHelp_2einit()
  call void @compiler_2folang_2eModeUsage_2einit()
  call void @compiler_2folang_2eModeWhat_2einit()
  call void @compiler_2folang_2eOptWords_2einit()
  call void @compiler_2folang_2eOptValues_2einit()
  call void @compiler_2folang_2eOptModes_2einit()
  call void @compiler_2folang_2eOptWhat_2einit()
  call void @compiler_2folang_2emain()
  ret i32 0
}

define dso_local void @olang_2einit_2ecompiler_2folang() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  call void @compiler_2folang_2eModeWords_2einit()
  br label %bb1
bb1:
  call void @compiler_2folang_2eRun_2einit()
  br label %bb2
bb2:
  call void @compiler_2folang_2eBuild_2einit()
  br label %bb3
bb3:
  call void @compiler_2folang_2eCompile_2einit()
  br label %bb4
bb4:
  call void @compiler_2folang_2eTest_2einit()
  br label %bb5
bb5:
  call void @compiler_2folang_2eInterp_2einit()
  br label %bb6
bb6:
  call void @compiler_2folang_2eFormat_2einit()
  br label %bb7
bb7:
  call void @compiler_2folang_2eExplain_2einit()
  br label %bb8
bb8:
  call void @compiler_2folang_2eHelp_2einit()
  br label %bb9
bb9:
  call void @compiler_2folang_2eModeUsage_2einit()
  br label %bb10
bb10:
  call void @compiler_2folang_2eModeWhat_2einit()
  br label %bb11
bb11:
  call void @compiler_2folang_2eOptWords_2einit()
  br label %bb12
bb12:
  call void @compiler_2folang_2eOptValues_2einit()
  br label %bb13
bb13:
  call void @compiler_2folang_2eOptModes_2einit()
  br label %bb14
bb14:
  call void @compiler_2folang_2eOptWhat_2einit()
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

declare void @__olang_scope_close(ptr)
@.d0 = private constant [42 x i8] c"olang [OPTION...] FILE.olang [ARGUMENT...]"
@.d1 = private constant [34 x i8] c"olang build [OPTION...] FILE.olang"
@.d2 = private constant [36 x i8] c"olang compile [OPTION...] FILE.olang"
@.d3 = private constant [36 x i8] c"olang test [OPTION...] FILE.olang..."
@.d4 = private constant [52 x i8] c"olang interpret [OPTION...] FILE.olang [ARGUMENT...]"
@.d5 = private constant [38 x i8] c"olang format [OPTION...] FILE.olang..."
@.d6 = private constant [18 x i8] c"olang explain RULE"
@.d7 = private constant [17 x i8] c"olang help [MODE]"
@__olang_prog_scope = external thread_local(initialexec) global ptr
declare ptr @__olang_scope_alloc(ptr, i64)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d8 = private constant [106 x i8] c"builds the program FILE.olang is the root of, as build does, and runs it with the arguments after the file"
@.d9 = private constant [64 x i8] c"builds one program, FILE.olang its root module, into build/ (B3)"
@.d10 = private constant [54 x i8] c"compiles one module to an object, linking nothing (B2)"
@.d11 = private constant [62 x i8] c"runs each file's test blocks, each file built on its own (B3a)"
@.d12 = private constant [110 x i8] c"runs the program by compile-time evaluation instead of building it, the arguments after the file its own (B3e)"
@.d13 = private constant [46 x i8] c"rewrites each file in olang's one layout (B13)"
@.d14 = private constant [41 x i8] c"prints a rule of the specification (B11a)"
@.d15 = private constant [36 x i8] c"lists the modes, or a mode's options"
@.d16 = private constant [0 x i8] c""
@.d17 = private constant [5 x i8] c"build"
@.d18 = private constant [7 x i8] c"compile"
@.d19 = private constant [4 x i8] c"test"
@.d20 = private constant [9 x i8] c"interpret"
@.d21 = private constant [6 x i8] c"format"
@.d22 = private constant [7 x i8] c"explain"
@.d23 = private constant [4 x i8] c"help"
@.d24 = private constant [4 x i8] c"PATH"
@.d25 = private constant [0 x i8] c""
@.d26 = private constant [0 x i8] c""
@.d27 = private constant [0 x i8] c""
@.d28 = private constant [4 x i8] c"NAME"
@.d29 = private constant [10 x i8] c"Name=value"
@.d30 = private constant [0 x i8] c""
@.d31 = private constant [0 x i8] c""
@.d32 = private constant [49 x i8] c"writes the executable or the object to PATH (B3h)"
@.d33 = private constant [53 x i8] c"builds unoptimized, with debug information (B2c, B2e)"
@.d34 = private constant [40 x i8] c"builds with the data race detector (B2b)"
@.d35 = private constant [37 x i8] c"builds with the scope sanitizer (B2f)"
@.d36 = private constant [32 x i8] c"builds for another machine (B12)"
@.d37 = private constant [30 x i8] c"defines a build constant (B10)"
@.d38 = private constant [85 x i8] c"moves the remote repositories the build reaches to their refs' current commits (M23c)"
@.d39 = private constant [57 x i8] c"rewrites nothing: lists each file not in the layout (B13)"
@.d40 = private constant [7 x i8] c"-output"
@.d41 = private constant [6 x i8] c"-debug"
@.d42 = private constant [5 x i8] c"-race"
@.d43 = private constant [9 x i8] c"-sanitize"
@.d44 = private constant [7 x i8] c"-target"
@.d45 = private constant [7 x i8] c"-define"
@.d46 = private constant [7 x i8] c"-update"
@.d47 = private constant [6 x i8] c"-check"
declare ptr @__olang_scope_alloc_a(ptr, i64, i64)
@.d48 = private constant [1 x i8] c"-"
@.d49 = private constant [1 x i8] c"-"
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare void @__olang_sb_put(ptr, ptr, i64)
declare void @__olang_sb_done(ptr)
@.d50 = private constant [0 x i8] c""
@.d51 = private constant [0 x i8] c""
@.d52 = private constant [0 x i8] c""
@.d53 = private constant [8 x i8] c"TargetOs"
@.d54 = private constant [10 x i8] c"TargetArch"
@.d55 = private constant [9 x i8] c"TargetCpu"
@.d56 = private constant [16 x i8] c"TargetVectorBits"
@.d57 = private constant [12 x i8] c"TargetHasFma"
@.d58 = private constant [10 x i8] c"DebugBuild"
@.d59 = private constant [9 x i8] c"RaceBuild"
@.d60 = private constant [9 x i8] c"TestBuild"
@.d61 = private constant [1 x i8] c"/"
declare void @__olang_check_failed(ptr)
@.c62 = private unnamed_addr constant [53 x i8] c"compiler/olang.olang:223: slice bounds out of range\0A\00"
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fbuild_3aKind(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i1 true, ptr %l2
  %t1 = load ptr, ptr %l0
  %t2 = load i32, ptr %t1
  %t3 = sext i32 %t2 to i64
  store i64 %t3, ptr %l3
  %t4 = load ptr, ptr %l1
  %t5 = load i32, ptr %t4
  %t6 = sext i32 %t5 to i64
  store i64 %t6, ptr %l4
  %t7 = load i64, ptr %l3
  %t8 = load i64, ptr %l4
  %t9 = icmp eq i64 %t7, %t8
  store i1 %t9, ptr %l5
  %t10 = load i1, ptr %l5
  br i1 %t10, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2
  br label %bb3
bb2:
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t11 = load i1, ptr %l2
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d63 = private constant [16 x i8] c"sanitize_thread "
@.d64 = private constant [0 x i8] c""
@.d65 = private constant [17 x i8] c"it does not emit "
@.d66 = private constant [4 x i8] c" yet"
@.d67 = private constant [20 x i8] c": it does not lower "
@.d68 = private constant [4 x i8] c" yet"
@.d69 = private constant [16 x i8] c"@__olang_dyncall"
@.c70 = private unnamed_addr constant [52 x i8] c"compiler/olang.olang:383: reached unreachable code\0A\00"
@.d71 = private constant [6 x i8] c".olang"
@.c72 = private unnamed_addr constant [53 x i8] c"compiler/olang.olang:284: slice bounds out of range\0A\00"
@.d73 = private constant [2 x i8] c"-l"
@.d74 = private constant [2 x i8] c"-f"
@.d75 = private constant [96 x i8] c"usage: olang MODE [OPTION...] FILE...   or   olang [OPTION...] FILE.olang [ARGUMENT...]\0A\0Amodes:\0A"
@.d76 = private constant [10 x i8] c"FILE.olang"
@.d77 = private constant [2 x i8] c"  "
@.d78 = private constant [1 x i8] c" "
@.d79 = private constant [1 x i8] c"\0A"
@.d80 = private constant [2 x i8] c"  "
@.d81 = private constant [1 x i8] c" "
@.d82 = private constant [1 x i8] c"\0A"
@.d83 = private constant [85 x i8] c"\0A'olang help MODE' lists a mode's options; 'olang help run' those of running a file.\0A"
declare ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d84 = private constant [3 x i8] c"run"
@.d85 = private constant [7 x i8] c"usage: "
@.d86 = private constant [1 x i8] c"\0A"
@.d87 = private constant [1 x i8] c"\0A"
@.d88 = private constant [10 x i8] c"\0Aoptions:\0A"
@.d89 = private constant [0 x i8] c""
@.d90 = private constant [1 x i8] c" "
@.d91 = private constant [0 x i8] c""
@.d92 = private constant [2 x i8] c"  "
@.d93 = private constant [1 x i8] c" "
@.d94 = private constant [1 x i8] c"\0A"
@.d95 = private constant [97 x i8] c"olang: internal compiler error: the compiler crashed - a bug in the compiler, not in the program\0A"
define internal void @olang_lambda_96(ptr %env) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %s0 = alloca %olang.scope
  %cp0 = getelementptr { { i64, ptr }, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load { i64, ptr }, ptr %cp0
  store { i64, ptr } %cv0, ptr %l0
  %vq0 = getelementptr { { i64, ptr }, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l1
  %t2 = load { i64, ptr }, ptr %l1
  %t3 = call i32 @compiler_2folang_2edrive(ptr %vc0, { i64, ptr } %t2)
  store i32 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i32, ptr %l2
  call void @std_2fos_2eExit(i32 %t4)
  unreachable
bb2:
  call void @__olang_check_failed(ptr @.c104)
  unreachable
ret:
  ret void
}

@.d97 = private constant [14 x i8] c"running a file"
@.d98 = private constant [5 x i8] c" and "
@.d99 = private constant [2 x i8] c", "
@.c100 = private unnamed_addr constant [52 x i8] c"compiler/olang.olang:327: reached unreachable code\0A\00"
define linkonce_odr %"std/prelude/list:List<std/prelude/text:String&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<std/prelude/text:String&>" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l0
  store %"std/prelude/list:List<std/prelude/text:String&>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %rv
  ret %"std/prelude/list:List<std/prelude/text:String&>" %rr
}

@.d101 = private constant [0 x i8] c""
@.d102 = private constant [6 x i8] c"native"
@.d103 = private constant [0 x i8] c""
@__olang_argc = external global i32
@__olang_argv = external global ptr
declare void @__olang_thread_init()
declare ptr @__olang_capture_scope(ptr)
@.c104 = private unnamed_addr constant [51 x i8] c"compiler/olang.olang:38: reached unreachable code\0A\00"
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eUsage(ptr %v0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotAMode(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownFlag(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eOptionNotForMode(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eOptionNeedsValue(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eDefine(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, ptr %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eExplainNeedsRule(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eHelpOneMode(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eModeFirst(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotASource(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eModeNeedsFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eModeOneFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2ftarget_2eFindClang(ptr %v0)
declare { i32, %"compiler/target:Target" } @compiler_2ftarget_2eResolve(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, ptr %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetForeignMode(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eHas(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefineBuiltin(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eBuiltins(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, i64 %a4, i64 %a5, i1 %a6, i1 %a7, i1 %a8)
declare i1 @std_2fos_2eIsDir(ptr %v0, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eOutputIsDir(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eOutputNoDir(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2finterp_2eAnalyze(ptr %out, ptr %v0, ptr %v1, ptr %a0, i1 %a1)
declare %"std/prelude/map:Map<std/pair:Pair<I64, I64>, Bool>" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
declare i64 @compiler_2finterp_2eDecideAsserts(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v0, ptr %a0)
declare %"compiler/lower:Lowerer" @compiler_2flower_3aLowerer_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"std/prelude/list:List<mut compiler/typed:Body&>" %a1)
declare void @compiler_2femit_3aEmitter_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, ptr %a3)
declare %"std/prelude/list:List<compiler/emit:Object>" @compiler_2femit_2ecompiler_2femit_3aEmitter_2eObjects(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3aGap_3e_2eLen_3ccompiler_2flower_3aGap_3e(ptr %v0, ptr %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fbuild_2eUnbuildable(ptr %v0, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3aGap_3e_2eRunFrom_3ccompiler_2flower_3aGap_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aObject_3e_2eRunFrom_3ccompiler_2femit_3aObject_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/build:Unit" @compiler_2fbuild_3aUnit_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, i32 %a1, { i64, ptr } %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2ePush_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/build:Unit" %a1)
declare { i32, { i64, ptr } } @compiler_2fruntime_2eIr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3, i1 %a4)
declare { i32, { i64, ptr } } @compiler_2fruntime_2eDyncallIr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3, i1 %a4)
declare void @compiler_2finterp_3aExec_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"std/prelude/list:List<mut compiler/typed:Body&>" %a1, i32 %a2)
declare i32 @compiler_2finterp_2ecompiler_2finterp_3aExec_2eRunMain(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fload_2eLockPath(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2ffetch_2eCacheDir(ptr %v0)
declare { i64, ptr } @compiler_2ffetch_2eGitBase(ptr %v0)
declare %"compiler/fetch:Fetcher" @compiler_2ffetch_3aFetcher_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3, i1 %a4)
declare %"compiler/source:Names" @compiler_2fsource_3aNames_2ector(ptr %v0)
declare { i64, ptr } @compiler_2fload_2eStdDir(ptr %v0)
declare %"compiler/load:Loader" @compiler_2fload_3aLoader_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4)
declare i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eLoad(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v0, ptr %a0)
declare i32 @compiler_2folang_2eRunWith_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fdiag_2eSpecPath(ptr %v0)
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoSpec(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare { i32, { i64, ptr } } @compiler_2fdiag_2eExplain(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eToUpper(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoRule(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hd4bdf3befe2f7a35847f168802c5df68(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2ffmt_2eFiles(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadEnd(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i8 %a2)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fos_2eOnCrash(ptr %v0, { i64, ptr } %a0)
declare { i64, ptr } @std_2fos_2eArgs(ptr %v0)
declare void @std_2fos_2eRunOnStack(ptr %v0, i64 %a0, ptr %a1c, ptr %a1e)
declare void @compiler_2fscope_3aScoper_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"std/prelude/list:List<mut compiler/typed:Body&>" %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eRun(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v0, ptr %v1, ptr %a0)
declare i32 @std_2fio_2ePrint(ptr %v0, { i64, ptr } %a0)
declare void @std_2fprelude_2farray_2esortRun_2einit()
declare void @std_2fprelude_2farray_2esortBlock_2einit()
declare void @std_2fprelude_2flist_2efirstChunkLog_2einit()
declare void @std_2fprelude_2flist_2efirstChunk_2einit()
declare void @std_2fprelude_2fnumber_2ePi_2einit()
declare void @std_2fprelude_2fnumber_2eEuler_2einit()
declare void @std_2fprelude_2fnumber_2eInf_2einit()
declare void @std_2fprelude_2fnumber_2eNaN_2einit()
declare void @std_2fprelude_2ftext_2eexactPow10_2einit()
declare void @std_2fprelude_2ftext_2edecimalShifts_2einit()
declare void @std_2fprelude_2ftext_2emask63_2einit()
declare void @std_2fprelude_2ftext_2epow10Mant_2einit()
declare void @std_2fio_2eStdin_2einit()
declare void @std_2fio_2eStdout_2einit()
declare void @std_2fio_2eStderr_2einit()
declare void @std_2fcancel_2eClockRealtime_2einit()
declare void @std_2fcancel_2eClockMonotonic_2einit()
declare void @std_2fcancel_2ePollNs_2einit()
declare void @std_2fchan_2eMutexWords_2einit()
declare void @std_2fchan_2eCondWords_2einit()
declare void @compiler_2fmsgs_2eEndOfLine_2einit()
declare void @compiler_2fmsgs_2eEndOfFile_2einit()
declare void @compiler_2fdiag_2ePending_2einit()
declare void @compiler_2fdiag_2eChosen_2einit()
declare void @compiler_2fdiag_2eDropped_2einit()
declare void @compiler_2fdiag_2eCut_2einit()
declare void @compiler_2fdiag_2eExcerptMax_2einit()
declare void @compiler_2fdiag_2eExcerptAround_2einit()
declare void @compiler_2ftoken_2eLineBreak_2einit()
declare void @compiler_2ftoken_2eSpace_2einit()
declare void @compiler_2ftoken_2eLineStart_2einit()
declare void @compiler_2fcond_2eLiteralIntBits_2einit()
declare void @compiler_2ftarget_2eArchs_2einit()
declare void @compiler_2ftarget_2eArchCpuFlags_2einit()
declare void @compiler_2ftarget_2eArchDefaultCpus_2einit()
declare void @compiler_2ftarget_2eIeeeUnsafe_2einit()
declare void @compiler_2ftarget_2eLevelFlags_2einit()
declare void @compiler_2ftarget_2eSkylakeProbe_2einit()
declare void @compiler_2fbuild_2eShaK_2einit()
declare void @std_2fpair_2ePairOfTextBaked_2einit()
declare void @std_2ffilepath_2ecleanCases_2einit()
declare void @std_2ffilepath_2ecleanMissesBaked_2einit()
declare void @std_2ffilepath_2epartCases_2einit()
declare void @std_2ffilepath_2epartMissesBaked_2einit()
declare void @std_2ffilepath_2erelCases_2einit()
declare void @std_2ffilepath_2erelMissesBaked_2einit()
declare void @std_2ffilepath_2elivePath_2einit()
declare void @compiler_2fparse_2eMaxNesting_2einit()
declare void @compiler_2fload_2eNotYet_2einit()
declare void @compiler_2fload_2ePending_2einit()
declare void @compiler_2fload_2eNoBranch_2einit()
declare void @compiler_2ftypes_2eReadOnly_2einit()
declare void @compiler_2ftypes_2eWritable_2einit()
declare void @compiler_2ftypes_2eOwning_2einit()
declare void @compiler_2ftypes_2eRoleFn_2einit()
declare void @compiler_2ftypes_2eRoleCtor_2einit()
declare void @compiler_2ftypes_2eRoleDtor_2einit()
declare void @compiler_2ftypes_2eOwnScope_2einit()
declare void @compiler_2ftypes_2eFromTypeVar_2einit()
declare void @compiler_2ftypes_2eResultVar_2einit()
declare void @compiler_2ftypes_2eClosingVar_2einit()
declare void @compiler_2ftypes_2eNotLaidOut_2einit()
declare void @compiler_2ftypes_2eLayingOut_2einit()
declare void @compiler_2ftypes_2eLaidOut_2einit()
declare void @compiler_2ftypes_2eNoLayout_2einit()
declare void @compiler_2ftypes_2eUnknownT_2einit()
declare void @compiler_2ftypes_2eVoidT_2einit()
declare void @compiler_2ftypes_2eBoolT_2einit()
declare void @compiler_2ftypes_2eNullT_2einit()
declare void @compiler_2ftypes_2eDefaultErrT_2einit()
declare void @compiler_2ftypes_2eNoreturnT_2einit()
declare void @compiler_2ftypes_2eprimNames_2einit()
declare void @compiler_2ftypes_2eprimLlvm_2einit()
declare void @compiler_2ftypes_2eprimBits_2einit()
declare void @compiler_2ftypes_2eBigAggregate_2einit()
declare void @compiler_2fgeneric_2eNoOrigin_2einit()
declare void @compiler_2fgeneric_2eMaxDepth_2einit()
declare void @compiler_2fgeneric_2eMaxChain_2einit()
declare void @compiler_2fgeneric_2eFolded_2einit()
declare void @compiler_2fgeneric_2ePending_2einit()
declare void @compiler_2fgeneric_2eUnfolded_2einit()
declare void @compiler_2fgeneric_2eArrayKey_2einit()
declare void @compiler_2fscope_2eWhyHolds_2einit()
declare void @compiler_2fscope_2eWhyField_2einit()
declare void @compiler_2fscope_2eHolds_2einit()
declare void @compiler_2fscope_2eObliged_2einit()
declare void @compiler_2fscope_2eFailsBlock_2einit()
declare void @compiler_2fscope_2eFailsUnknown_2einit()
declare void @compiler_2fscope_2eFnNamed_2einit()
declare void @compiler_2fscope_2eFnLambda_2einit()
declare void @compiler_2fscope_2eFnCall_2einit()
declare void @compiler_2fscope_2eUseThru_2einit()
declare void @compiler_2fscope_2eUseView_2einit()
declare void @compiler_2fscope_2eFitLocal_2einit()
declare void @compiler_2fscope_2eFitField_2einit()
declare void @compiler_2fscope_2eFitGlobal_2einit()
declare void @compiler_2fscope_2eFitReturn_2einit()
declare void @compiler_2fscope_2eFitValue_2einit()
declare void @compiler_2fscope_2eFitPayload_2einit()
declare void @compiler_2fscope_2eFitDecl_2einit()
declare void @compiler_2fscope_2eFitOwn_2einit()
declare void @compiler_2fscope_2eFitElem_2einit()
declare void @compiler_2fmir_2eNoBlock_2einit()
declare void @compiler_2fmir_2eNoLocal_2einit()
declare void @compiler_2fmir_2eNoScope_2einit()
declare void @compiler_2fmir_2eEmpty_2einit()
declare void @compiler_2fmir_2eNoPlace_2einit()
declare void @compiler_2fmir_2eI32T_2einit()
declare void @compiler_2fmir_2eI64T_2einit()
declare void @compiler_2fmir_2eSp0_2einit()
declare void @compiler_2fcheck_2eOpShapes_2einit()
declare void @compiler_2fcheck_2eBounds_2einit()
declare void @compiler_2fcheck_2eDivideByZero_2einit()
declare void @compiler_2fcheck_2eOverflow_2einit()
declare void @compiler_2fcheck_2eInvalid_2einit()
declare void @compiler_2fcheck_2eWrongCase_2einit()
declare void @compiler_2fcheck_2eRoStored_2einit()
declare void @compiler_2fcheck_2eRoDecl_2einit()
declare void @compiler_2fcheck_2eRoReturned_2einit()
declare void @compiler_2fcheck_2eRoGlobal_2einit()
declare void @compiler_2fcheck_2eliteralOrder_2einit()
declare void @compiler_2flower_2eOutOfBounds_2einit()
declare void @compiler_2flower_2eDivideByZero_2einit()
declare void @compiler_2flower_2eOverflow_2einit()
declare void @compiler_2flower_2eInvalid_2einit()
declare void @compiler_2flower_2eWrongCase_2einit()
declare void @compiler_2funparse_2eMaxIndent_2einit()
declare void @compiler_2feval_2eWhyMutableGlobal_2einit()
declare void @compiler_2feval_2eWhyChangeable_2einit()
declare void @compiler_2feval_2eWhyWritesGlobal_2einit()
declare void @compiler_2feval_2eWhyCycle_2einit()
declare void @compiler_2feval_2eWhyNoValue_2einit()
declare void @compiler_2feval_2eWhyDestructor_2einit()
declare void @compiler_2feval_2eWhyExtern_2einit()
declare void @compiler_2feval_2eWhyEnds_2einit()
declare void @compiler_2feval_2eWhySteps_2einit()
declare void @compiler_2feval_2eWhyMemory_2einit()
declare void @compiler_2feval_2eWhyDepth_2einit()
declare void @compiler_2feval_2eWhyRunDepth_2einit()
declare void @compiler_2feval_2eWhyNull_2einit()
declare void @compiler_2feval_2eWhyNullCall_2einit()
declare void @compiler_2feval_2eWhyClosed_2einit()
declare void @compiler_2feval_2eWhyOutside_2einit()
declare void @compiler_2feval_2eWhyBeyond_2einit()
declare void @compiler_2feval_2eWhyReadOnly_2einit()
declare void @compiler_2feval_2eWhyDivZero_2einit()
declare void @compiler_2feval_2eWhyDivMin_2einit()
declare void @compiler_2feval_2eWhyShift_2einit()
declare void @compiler_2feval_2eWhyConvert_2einit()
declare void @compiler_2feval_2eWhyNaNOp_2einit()
declare void @compiler_2feval_2eWhyNaNSignal_2einit()
declare void @compiler_2feval_2eWhyNoBody_2einit()
declare void @compiler_2feval_2eWhyNotModelled_2einit()
declare void @compiler_2feval_2eWhyPayload_2einit()
declare void @compiler_2feval_2eWhyLong_2einit()
declare void @compiler_2feval_2eWhyFfiFind_2einit()
declare void @compiler_2feval_2eWhyFfiPass_2einit()
declare void @compiler_2feval_2eWhyNoClause_2einit()
declare void @compiler_2feval_2eWhyWaits_2einit()
declare void @compiler_2feval_2eNullPtr_2einit()
declare void @compiler_2feval_2eslotBits_2einit()
declare void @compiler_2feval_2eslotMask_2einit()
declare void @compiler_2feval_2eaFree_2einit()
declare void @compiler_2feval_2eaValue_2einit()
declare void @compiler_2feval_2eaData_2einit()
declare void @compiler_2feval_2eaGlobal_2einit()
declare void @compiler_2feval_2eaCode_2einit()
declare void @compiler_2feval_2esBlock_2einit()
declare void @compiler_2feval_2esStore_2einit()
declare void @compiler_2feval_2esProgram_2einit()
declare void @compiler_2feval_2esInert_2einit()
declare void @compiler_2feval_2esBuilder_2einit()
declare void @compiler_2feval_2esRegion_2einit()
declare void @compiler_2feval_2esJoin_2einit()
declare void @compiler_2feval_2egDtor_2einit()
declare void @compiler_2feval_2egOwner_2einit()
declare void @compiler_2feval_2erRequest_2einit()
declare void @compiler_2feval_2erCall_2einit()
declare void @compiler_2feval_2erDtor_2einit()
declare void @compiler_2feval_2erTask_2einit()
declare void @compiler_2feval_2erClause_2einit()
declare void @compiler_2feval_2erGlobal_2einit()
declare void @compiler_2feval_2etRaised_2einit()
declare void @compiler_2feval_2etCall_2einit()
declare void @compiler_2feval_2etJoin_2einit()
declare void @compiler_2feval_2etraceKept_2einit()
declare void @compiler_2feval_2evVoid_2einit()
declare void @compiler_2feval_2evBool_2einit()
declare void @compiler_2feval_2evInt_2einit()
declare void @compiler_2feval_2evUint_2einit()
declare void @compiler_2feval_2evFloat_2einit()
declare void @compiler_2feval_2evPtr_2einit()
declare void @compiler_2feval_2evPair_2einit()
declare void @compiler_2feval_2evFunc_2einit()
declare void @compiler_2feval_2evEnum_2einit()
declare void @compiler_2feval_2evOrd_2einit()
declare void @compiler_2feval_2evAgg_2einit()
declare void @compiler_2feval_2evFixed_2einit()
declare void @compiler_2feval_2evNone_2einit()
declare void @compiler_2feval_2emathNames_2einit()
declare void @compiler_2feval_2emathArity_2einit()
declare void @compiler_2feval_2eSp0_2einit()
declare void @compiler_2feval_2eB0_2einit()
declare void @compiler_2feval_2eS0_2einit()
declare void @compiler_2feval_2eIntOps_2einit()
declare void @compiler_2feval_2eCmpOps_2einit()
declare void @compiler_2feval_2eFloatOps_2einit()
declare void @compiler_2feval_2eNumNames_2einit()
declare void @compiler_2femit_2eHomeShared_2einit()
declare void @compiler_2femit_2eHomeLocal_2einit()
declare void @compiler_2femit_2eHomeInst_2einit()
declare void @compiler_2femit_2eruntimeTypes_2einit()
declare void @compiler_2fruntime_2eArchs_2einit()
declare void @compiler_2fruntime_2eFactNames_2einit()
declare void @compiler_2fruntime_2eFactX86_2einit()
declare void @compiler_2fruntime_2eFactArm_2einit()
declare void @compiler_2fruntime_2eHeaderTbaa_2einit()
declare void @std_2fos_2eExit(i32 %a0)
declare %"std/prelude/list:List<std/prelude/text:String&>" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
