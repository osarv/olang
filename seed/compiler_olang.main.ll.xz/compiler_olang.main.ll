; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/olang:CommandLine" = type { i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, i1, { i64, ptr } }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/build:Config" = type { { i64, ptr }, { i64, ptr }, %"compiler/target:Target", %"compiler/cond:Consts", i1, i1, i1, i1, i1, i1, i1, i1, i64, i1, i1, { i64, ptr }, { i64, ptr }, i64, i64, i1, { i64, ptr }, { i64, ptr } }
%"compiler/target:Target" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i1, i1 }
%"compiler/cond:Consts" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/os:FileInfo" = type { i32, i64, i64 }
%"compiler/build:Unit" = type { { i64, ptr }, i32, { i64, ptr }, { i64, ptr } }
%"compiler/emit:Object" = type { { i64, ptr }, i32, { i64, ptr }, i64 }
%"compiler/emit:Emitter" = type { ptr, ptr, ptr, ptr, i1, i1, i1, i1, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i64, i1, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, i64, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i1, i1, { i64, ptr }, i1, i64, i64, i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/build:Program" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr } }
%"compiler/lower:Gap" = type { i64, %"compiler/source:Span", { i64, ptr } }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/emit:Reused" = type { i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64 }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i64, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, { i64, [3 x i64] }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/lower:Lowerer" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i32, i32 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/free:Free" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i64, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, i1, i1 }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, ptr, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/scope:Scoper" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { ptr, ptr }, { ptr, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, i64, i1, %"compiler/typed:Plan", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, [2 x i64] }, i1, %"compiler/source:Span", { i64, [2 x i64] }, i1, { i64, [2 x i64] }, i1, i1, i1, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, [2 x i64] }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i64, { i64, [2 x i64] }, i1, i1, i1, i64, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i64, i64, i1, i32, i1, i1, i1, i1, i64, %"compiler/source:Span" }
%"compiler/typed:Plan" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/interp:Exec" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i32, %"compiler/lower:Lowerer", %"compiler/eval:Machine", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"compiler/eval:Machine" = type { ptr, i32, i64, i64, i64, i64, i64, i64, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/eval:Ptr", i32, { i64, [5 x i64] }, i1, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, i64, { i64, ptr }, { i64, ptr }, i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i64, { i64, ptr }, i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i64, i64, { i64, ptr }, i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/source:Span", i32 }
%"compiler/eval:Ptr" = type { i64, i64 }
%"compiler/fetch:Fetcher" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/source:Names" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/olang:Passes" = type { i64 }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/types:Table" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/load:Import" = type { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, { i64, ptr }, i64, i64 }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"std/prelude/text:LineIter" = type { { i64, ptr }, i64 }
@G_2ecompiler_2folang_2eBindgen = constant <{ [8 x i8] }> <{ [8 x i8] c"\0C\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eBuild = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eCompile = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eDoc = constant <{ [8 x i8] }> <{ [8 x i8] c"\08\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eExplain = constant <{ [8 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eFix = constant <{ [8 x i8] }> <{ [8 x i8] c"\0B\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eFormat = constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eHelp = constant <{ [8 x i8] }> <{ [8 x i8] c"\07\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eInterp = constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eLsp = constant <{ [8 x i8] }> <{ [8 x i8] c"\09\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eMcp = constant <{ [8 x i8] }> <{ [8 x i8] c"\0A\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eModeUsage = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\2A\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeUsage.k1, [8 x i8] c"\22\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeUsage.k2, [8 x i8] c"\24\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeUsage.k3, [8 x i8] c"\24\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeUsage.k4, [8 x i8] c"\34\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeUsage.k5, [8 x i8] c"\26\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeUsage.k6, [8 x i8] c"\24\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeUsage.k7, [8 x i8] c"\11\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeUsage.k8, [8 x i8] c"\43\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeUsage.k9, [8 x i8] c"\15\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeUsage.k10, [8 x i8] c"\15\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeUsage.k11, [8 x i8] c"\27\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeUsage.k12, [8 x i8] c"\22\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeUsage.k13 }>, align 64
@G_2ecompiler_2folang_2eModeUsage.k1 = internal constant <{ [42 x i8] }> <{ [42 x i8] c"\6F\6C\61\6E\67\20\5B\4F\50\54\49\4F\4E\2E\2E\2E\5D\20\46\49\4C\45\2E\6F\6C\61\6E\67\20\5B\41\52\47\55\4D\45\4E\54\2E\2E\2E\5D" }>, align 32
@G_2ecompiler_2folang_2eModeUsage.k2 = internal constant <{ [34 x i8] }> <{ [34 x i8] c"\6F\6C\61\6E\67\20\62\75\69\6C\64\20\5B\4F\50\54\49\4F\4E\2E\2E\2E\5D\20\46\49\4C\45\2E\6F\6C\61\6E\67" }>, align 32
@G_2ecompiler_2folang_2eModeUsage.k3 = internal constant <{ [36 x i8] }> <{ [36 x i8] c"\6F\6C\61\6E\67\20\63\6F\6D\70\69\6C\65\20\5B\4F\50\54\49\4F\4E\2E\2E\2E\5D\20\46\49\4C\45\2E\6F\6C\61\6E\67" }>, align 32
@G_2ecompiler_2folang_2eModeUsage.k4 = internal constant <{ [36 x i8] }> <{ [36 x i8] c"\6F\6C\61\6E\67\20\74\65\73\74\20\5B\4F\50\54\49\4F\4E\2E\2E\2E\5D\20\46\49\4C\45\2E\6F\6C\61\6E\67\2E\2E\2E" }>, align 32
@G_2ecompiler_2folang_2eModeUsage.k5 = internal constant <{ [52 x i8] }> <{ [52 x i8] c"\6F\6C\61\6E\67\20\69\6E\74\65\72\70\72\65\74\20\5B\4F\50\54\49\4F\4E\2E\2E\2E\5D\20\46\49\4C\45\2E\6F\6C\61\6E\67\20\5B\41\52\47\55\4D\45\4E\54\2E\2E\2E\5D" }>, align 32
@G_2ecompiler_2folang_2eModeUsage.k6 = internal constant <{ [38 x i8] }> <{ [38 x i8] c"\6F\6C\61\6E\67\20\66\6F\72\6D\61\74\20\5B\4F\50\54\49\4F\4E\2E\2E\2E\5D\20\46\49\4C\45\2E\6F\6C\61\6E\67\2E\2E\2E" }>, align 32
@G_2ecompiler_2folang_2eModeUsage.k7 = internal constant <{ [36 x i8] }> <{ [36 x i8] c"\6F\6C\61\6E\67\20\65\78\70\6C\61\69\6E\20\52\55\4C\45\20\7C\20\46\49\4C\45\2E\6F\6C\61\6E\67\20\4E\41\4D\45" }>, align 32
@G_2ecompiler_2folang_2eModeUsage.k8 = internal constant <{ [17 x i8] }> <{ [17 x i8] c"\6F\6C\61\6E\67\20\68\65\6C\70\20\5B\4D\4F\44\45\5D" }>, align 8
@G_2ecompiler_2folang_2eModeUsage.k9 = internal constant <{ [67 x i8] }> <{ [67 x i8] c"\6F\6C\61\6E\67\20\64\6F\63\20\5B\4F\50\54\49\4F\4E\2E\2E\2E\5D\20\46\49\4C\45\2E\6F\6C\61\6E\67\20\5B\4E\41\4D\45\5D\20\7C\20\2D\68\74\6D\6C\20\44\49\52\20\5B\46\49\4C\45\2E\6F\6C\61\6E\67\2E\2E\2E\5D" }>, align 64
@G_2ecompiler_2folang_2eModeUsage.k10 = internal constant <{ [21 x i8] }> <{ [21 x i8] c"\6F\6C\61\6E\67\20\6C\73\70\20\5B\4F\50\54\49\4F\4E\2E\2E\2E\5D" }>, align 8
@G_2ecompiler_2folang_2eModeUsage.k11 = internal constant <{ [21 x i8] }> <{ [21 x i8] c"\6F\6C\61\6E\67\20\6D\63\70\20\5B\4F\50\54\49\4F\4E\2E\2E\2E\5D" }>, align 8
@G_2ecompiler_2folang_2eModeUsage.k12 = internal constant <{ [39 x i8] }> <{ [39 x i8] c"\6F\6C\61\6E\67\20\66\69\78\20\5B\4F\50\54\49\4F\4E\2E\2E\2E\5D\20\46\49\4C\45\2E\6F\6C\61\6E\67\7C\44\49\52\2E\2E\2E" }>, align 32
@G_2ecompiler_2folang_2eModeUsage.k13 = internal constant <{ [34 x i8] }> <{ [34 x i8] c"\6F\6C\61\6E\67\20\62\69\6E\64\67\65\6E\20\5B\4F\50\54\49\4F\4E\2E\2E\2E\5D\20\48\45\41\44\45\52\2E\68" }>, align 32
@G_2ecompiler_2folang_2eModeWhat = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\6A\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWhat.k1, [8 x i8] c"\40\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWhat.k2, [8 x i8] c"\36\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWhat.k3, [8 x i8] c"\3E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWhat.k4, [8 x i8] c"\6E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWhat.k5, [8 x i8] c"\2E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWhat.k6, [8 x i8] c"\5D\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWhat.k7, [8 x i8] c"\24\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWhat.k8, [8 x i8] c"\44\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWhat.k9, [8 x i8] c"\57\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWhat.k10, [8 x i8] c"\54\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWhat.k11, [8 x i8] c"\74\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWhat.k12, [8 x i8] c"\4C\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWhat.k13 }>, align 64
@G_2ecompiler_2folang_2eModeWhat.k1 = internal constant <{ [106 x i8] }> <{ [106 x i8] c"\62\75\69\6C\64\73\20\74\68\65\20\70\72\6F\67\72\61\6D\20\46\49\4C\45\2E\6F\6C\61\6E\67\20\69\73\20\74\68\65\20\72\6F\6F\74\20\6F\66\2C\20\61\73\20\62\75\69\6C\64\20\64\6F\65\73\2C\20\61\6E\64\20\72\75\6E\73\20\69\74\20\77\69\74\68\20\74\68\65\20\61\72\67\75\6D\65\6E\74\73\20\61\66\74\65\72\20\74\68\65\20\66\69\6C\65" }>, align 64
@G_2ecompiler_2folang_2eModeWhat.k2 = internal constant <{ [64 x i8] }> <{ [64 x i8] c"\62\75\69\6C\64\73\20\6F\6E\65\20\70\72\6F\67\72\61\6D\2C\20\46\49\4C\45\2E\6F\6C\61\6E\67\20\69\74\73\20\72\6F\6F\74\20\6D\6F\64\75\6C\65\2C\20\69\6E\74\6F\20\62\75\69\6C\64\2F\20\28\42\33\29" }>, align 64
@G_2ecompiler_2folang_2eModeWhat.k3 = internal constant <{ [54 x i8] }> <{ [54 x i8] c"\63\6F\6D\70\69\6C\65\73\20\6F\6E\65\20\6D\6F\64\75\6C\65\20\74\6F\20\61\6E\20\6F\62\6A\65\63\74\2C\20\6C\69\6E\6B\69\6E\67\20\6E\6F\74\68\69\6E\67\20\28\42\32\29" }>, align 32
@G_2ecompiler_2folang_2eModeWhat.k4 = internal constant <{ [62 x i8] }> <{ [62 x i8] c"\72\75\6E\73\20\65\61\63\68\20\66\69\6C\65\27\73\20\74\65\73\74\20\62\6C\6F\63\6B\73\2C\20\65\61\63\68\20\66\69\6C\65\20\62\75\69\6C\74\20\6F\6E\20\69\74\73\20\6F\77\6E\20\28\42\33\61\29" }>, align 32
@G_2ecompiler_2folang_2eModeWhat.k5 = internal constant <{ [110 x i8] }> <{ [110 x i8] c"\72\75\6E\73\20\74\68\65\20\70\72\6F\67\72\61\6D\20\62\79\20\63\6F\6D\70\69\6C\65\2D\74\69\6D\65\20\65\76\61\6C\75\61\74\69\6F\6E\20\69\6E\73\74\65\61\64\20\6F\66\20\62\75\69\6C\64\69\6E\67\20\69\74\2C\20\74\68\65\20\61\72\67\75\6D\65\6E\74\73\20\61\66\74\65\72\20\74\68\65\20\66\69\6C\65\20\69\74\73\20\6F\77\6E\20\28\42\33\65\29" }>, align 64
@G_2ecompiler_2folang_2eModeWhat.k6 = internal constant <{ [46 x i8] }> <{ [46 x i8] c"\72\65\77\72\69\74\65\73\20\65\61\63\68\20\66\69\6C\65\20\69\6E\20\6F\6C\61\6E\67\27\73\20\6F\6E\65\20\6C\61\79\6F\75\74\20\28\42\31\33\29" }>, align 32
@G_2ecompiler_2folang_2eModeWhat.k7 = internal constant <{ [93 x i8] }> <{ [93 x i8] c"\70\72\69\6E\74\73\20\61\20\72\75\6C\65\20\6F\66\20\74\68\65\20\73\70\65\63\69\66\69\63\61\74\69\6F\6E\20\28\42\31\31\61\29\2C\20\6F\72\20\61\20\74\6F\70\2D\6C\65\76\65\6C\20\69\74\65\6D\20\61\73\20\74\68\65\20\63\6F\6D\70\69\6C\65\72\20\73\65\65\73\20\69\74\20\28\42\31\31\62\29" }>, align 64
@G_2ecompiler_2folang_2eModeWhat.k8 = internal constant <{ [36 x i8] }> <{ [36 x i8] c"\6C\69\73\74\73\20\74\68\65\20\6D\6F\64\65\73\2C\20\6F\72\20\61\20\6D\6F\64\65\27\73\20\6F\70\74\69\6F\6E\73" }>, align 32
@G_2ecompiler_2folang_2eModeWhat.k9 = internal constant <{ [68 x i8] }> <{ [68 x i8] c"\70\72\69\6E\74\73\20\61\20\6D\6F\64\75\6C\65\27\73\20\64\6F\63\75\6D\65\6E\74\61\74\69\6F\6E\20\28\42\31\34\29\2C\20\6F\72\20\77\72\69\74\65\73\20\61\20\6C\69\62\72\61\72\79\27\73\20\61\73\20\48\54\4D\4C" }>, align 64
@G_2ecompiler_2folang_2eModeWhat.k10 = internal constant <{ [87 x i8] }> <{ [87 x i8] c"\73\65\72\76\65\73\20\74\68\65\20\4C\61\6E\67\75\61\67\65\20\53\65\72\76\65\72\20\50\72\6F\74\6F\63\6F\6C\20\6F\6E\20\74\68\65\20\73\74\61\6E\64\61\72\64\20\69\6E\70\75\74\20\61\6E\64\20\6F\75\74\70\75\74\2C\20\66\6F\72\20\65\64\69\74\6F\72\73\20\28\42\31\35\29" }>, align 64
@G_2ecompiler_2folang_2eModeWhat.k11 = internal constant <{ [84 x i8] }> <{ [84 x i8] c"\73\65\72\76\65\73\20\74\68\65\20\4D\6F\64\65\6C\20\43\6F\6E\74\65\78\74\20\50\72\6F\74\6F\63\6F\6C\20\6F\6E\20\74\68\65\20\73\74\61\6E\64\61\72\64\20\69\6E\70\75\74\20\61\6E\64\20\6F\75\74\70\75\74\2C\20\66\6F\72\20\61\67\65\6E\74\73\20\28\42\31\36\29" }>, align 64
@G_2ecompiler_2folang_2eModeWhat.k12 = internal constant <{ [116 x i8] }> <{ [116 x i8] c"\72\65\77\72\69\74\65\73\20\6F\6C\64\20\63\6F\64\65\20\74\6F\20\74\68\65\20\6C\61\6E\67\75\61\67\65\20\6F\66\20\74\6F\64\61\79\3A\20\65\76\65\72\79\20\6D\69\67\72\61\74\69\6F\6E\20\74\6F\6F\6C\20\6F\66\20\74\6F\6F\6C\73\2F\2C\20\69\6E\20\74\68\65\20\6F\72\64\65\72\20\74\68\65\20\63\68\61\6E\67\65\73\20\77\65\72\65\20\6D\61\64\65\20\28\42\31\37\29" }>, align 64
@G_2ecompiler_2folang_2eModeWhat.k13 = internal constant <{ [76 x i8] }> <{ [76 x i8] c"\77\72\69\74\65\73\20\61\20\43\20\68\65\61\64\65\72\27\73\20\64\65\63\6C\61\72\61\74\69\6F\6E\73\20\61\73\20\6F\6C\61\6E\67\20\64\65\63\6C\61\72\65\73\20\74\68\65\6D\2C\20\72\65\61\64\20\62\79\20\63\6C\61\6E\67\20\28\58\31\36\29" }>, align 64
@G_2ecompiler_2folang_2eModeWords = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWords.k1, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWords.k2, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWords.k3, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWords.k4, [8 x i8] c"\09\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWords.k5, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWords.k6, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWords.k7, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWords.k8, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWords.k9, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWords.k10, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWords.k11, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWords.k12, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWords.k13 }>, align 64
@G_2ecompiler_2folang_2eModeWords.k1 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2folang_2eModeWords.k2 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\62\75\69\6C\64" }>, align 8
@G_2ecompiler_2folang_2eModeWords.k3 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\63\6F\6D\70\69\6C\65" }>, align 8
@G_2ecompiler_2folang_2eModeWords.k4 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\74\65\73\74" }>, align 8
@G_2ecompiler_2folang_2eModeWords.k5 = internal constant <{ [9 x i8] }> <{ [9 x i8] c"\69\6E\74\65\72\70\72\65\74" }>, align 8
@G_2ecompiler_2folang_2eModeWords.k6 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\66\6F\72\6D\61\74" }>, align 8
@G_2ecompiler_2folang_2eModeWords.k7 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\65\78\70\6C\61\69\6E" }>, align 8
@G_2ecompiler_2folang_2eModeWords.k8 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\68\65\6C\70" }>, align 8
@G_2ecompiler_2folang_2eModeWords.k9 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\64\6F\63" }>, align 8
@G_2ecompiler_2folang_2eModeWords.k10 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\6C\73\70" }>, align 8
@G_2ecompiler_2folang_2eModeWords.k11 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\6D\63\70" }>, align 8
@G_2ecompiler_2folang_2eModeWords.k12 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\66\69\78" }>, align 8
@G_2ecompiler_2folang_2eModeWords.k13 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\62\69\6E\64\67\65\6E" }>, align 8
@G_2ecompiler_2folang_2eOptModes = constant <{ [96 x i8] }> <{ [96 x i8] c"\06\10\00\00\00\00\00\00\0F\00\00\00\00\00\00\00\0F\00\00\00\00\00\00\00\0F\00\00\00\00\00\00\00\5F\07\00\00\00\00\00\00\5F\07\00\00\00\00\00\00\5F\07\00\00\00\00\00\00\20\08\00\00\00\00\00\00\0F\00\00\00\00\00\00\00\00\01\00\00\00\00\00\00\02\00\00\00\00\00\00\00\0B\00\00\00\00\00\00\00" }>, align 64
@G_2ecompiler_2folang_2eOptValues = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptValues.k1, [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptValues.k2, [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptValues.k3, [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptValues.k4, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptValues.k5, [8 x i8] c"\0A\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptValues.k6, [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptValues.k7, [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptValues.k8, [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptValues.k9, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptValues.k10, [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptValues.k11, [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptValues.k12 }>, align 64
@G_2ecompiler_2folang_2eOptValues.k1 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\50\41\54\48" }>, align 8
@G_2ecompiler_2folang_2eOptValues.k2 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2folang_2eOptValues.k3 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2folang_2eOptValues.k4 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2folang_2eOptValues.k5 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\4E\41\4D\45" }>, align 8
@G_2ecompiler_2folang_2eOptValues.k6 = internal constant <{ [10 x i8] }> <{ [10 x i8] c"\4E\61\6D\65\3D\76\61\6C\75\65" }>, align 8
@G_2ecompiler_2folang_2eOptValues.k7 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2folang_2eOptValues.k8 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2folang_2eOptValues.k9 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2folang_2eOptValues.k10 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\44\49\52" }>, align 8
@G_2ecompiler_2folang_2eOptValues.k11 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2folang_2eOptValues.k12 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2folang_2eOptWhat = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\4E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWhat.k1, [8 x i8] c"\35\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWhat.k2, [8 x i8] c"\28\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWhat.k3, [8 x i8] c"\25\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWhat.k4, [8 x i8] c"\20\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWhat.k5, [8 x i8] c"\1E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWhat.k6, [8 x i8] c"\55\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWhat.k7, [8 x i8] c"\59\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWhat.k8, [8 x i8] c"\60\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWhat.k9, [8 x i8] c"\6D\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWhat.k10, [8 x i8] c"\53\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWhat.k11, [8 x i8] c"\58\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWhat.k12 }>, align 64
@G_2ecompiler_2folang_2eOptWhat.k1 = internal constant <{ [78 x i8] }> <{ [78 x i8] c"\77\72\69\74\65\73\20\74\68\65\20\65\78\65\63\75\74\61\62\6C\65\2C\20\74\68\65\20\6F\62\6A\65\63\74\20\6F\72\20\62\69\6E\64\67\65\6E\27\73\20\64\65\63\6C\61\72\61\74\69\6F\6E\73\20\74\6F\20\50\41\54\48\20\28\42\33\68\2C\20\58\31\36\29" }>, align 64
@G_2ecompiler_2folang_2eOptWhat.k2 = internal constant <{ [53 x i8] }> <{ [53 x i8] c"\62\75\69\6C\64\73\20\75\6E\6F\70\74\69\6D\69\7A\65\64\2C\20\77\69\74\68\20\64\65\62\75\67\20\69\6E\66\6F\72\6D\61\74\69\6F\6E\20\28\42\32\63\2C\20\42\32\65\29" }>, align 32
@G_2ecompiler_2folang_2eOptWhat.k3 = internal constant <{ [40 x i8] }> <{ [40 x i8] c"\62\75\69\6C\64\73\20\77\69\74\68\20\74\68\65\20\64\61\74\61\20\72\61\63\65\20\64\65\74\65\63\74\6F\72\20\28\42\32\62\29" }>, align 32
@G_2ecompiler_2folang_2eOptWhat.k4 = internal constant <{ [37 x i8] }> <{ [37 x i8] c"\62\75\69\6C\64\73\20\77\69\74\68\20\74\68\65\20\73\63\6F\70\65\20\73\61\6E\69\74\69\7A\65\72\20\28\42\32\66\29" }>, align 32
@G_2ecompiler_2folang_2eOptWhat.k5 = internal constant <{ [32 x i8] }> <{ [32 x i8] c"\62\75\69\6C\64\73\20\66\6F\72\20\61\6E\6F\74\68\65\72\20\6D\61\63\68\69\6E\65\20\28\42\31\32\29" }>, align 32
@G_2ecompiler_2folang_2eOptWhat.k6 = internal constant <{ [30 x i8] }> <{ [30 x i8] c"\64\65\66\69\6E\65\73\20\61\20\62\75\69\6C\64\20\63\6F\6E\73\74\61\6E\74\20\28\42\31\30\29" }>, align 8
@G_2ecompiler_2folang_2eOptWhat.k7 = internal constant <{ [85 x i8] }> <{ [85 x i8] c"\6D\6F\76\65\73\20\74\68\65\20\72\65\6D\6F\74\65\20\72\65\70\6F\73\69\74\6F\72\69\65\73\20\74\68\65\20\62\75\69\6C\64\20\72\65\61\63\68\65\73\20\74\6F\20\74\68\65\69\72\20\72\65\66\73\27\20\63\75\72\72\65\6E\74\20\63\6F\6D\6D\69\74\73\20\28\4D\32\33\63\29" }>, align 64
@G_2ecompiler_2folang_2eOptWhat.k8 = internal constant <{ [89 x i8] }> <{ [89 x i8] c"\72\65\77\72\69\74\65\73\20\6E\6F\74\68\69\6E\67\3A\20\6C\69\73\74\73\20\65\61\63\68\20\66\69\6C\65\20\6E\6F\74\20\69\6E\20\74\68\65\20\6C\61\79\6F\75\74\20\28\42\31\33\29\2C\20\6F\72\20\74\68\61\74\20\66\69\78\20\77\6F\75\6C\64\20\63\68\61\6E\67\65\20\28\42\31\37\29" }>, align 64
@G_2ecompiler_2folang_2eOptWhat.k9 = internal constant <{ [96 x i8] }> <{ [96 x i8] c"\62\75\69\6C\64\73\20\66\6F\72\20\64\65\76\65\6C\6F\70\6D\65\6E\74\3A\20\2D\4F\32\20\77\69\74\68\6F\75\74\20\6C\69\6E\6B\2D\74\69\6D\65\20\6F\70\74\69\6D\69\7A\61\74\69\6F\6E\2C\20\66\61\73\74\65\72\20\74\6F\20\62\75\69\6C\64\2C\20\73\6C\6F\77\65\72\20\74\6F\20\72\75\6E\20\28\42\32\67\29" }>, align 64
@G_2ecompiler_2folang_2eOptWhat.k10 = internal constant <{ [109 x i8] }> <{ [109 x i8] c"\77\72\69\74\65\73\20\74\68\65\20\64\6F\63\75\6D\65\6E\74\61\74\69\6F\6E\20\61\73\20\48\54\4D\4C\20\69\6E\74\6F\20\44\49\52\2C\20\61\20\70\61\67\65\20\61\20\6D\6F\64\75\6C\65\3A\20\6F\66\20\65\61\63\68\20\46\49\4C\45\2C\20\6F\72\20\6F\66\20\73\74\64\20\77\68\65\72\65\20\6E\6F\6E\65\20\69\73\20\6E\61\6D\65\64\20\28\42\31\34\29" }>, align 64
@G_2ecompiler_2folang_2eOptWhat.k11 = internal constant <{ [83 x i8] }> <{ [83 x i8] c"\62\75\69\6C\64\73\20\61\20\73\68\61\72\65\64\20\6C\69\62\72\61\72\79\20\6C\69\62\4E\41\4D\45\2E\73\6F\20\6F\66\20\74\68\65\20\65\78\70\6F\72\74\20\66\6E\73\2C\20\61\6E\64\20\69\74\73\20\43\20\68\65\61\64\65\72\20\4E\41\4D\45\2E\68\20\28\58\31\34\29" }>, align 64
@G_2ecompiler_2folang_2eOptWhat.k12 = internal constant <{ [88 x i8] }> <{ [88 x i8] c"\72\65\70\6F\72\74\73\20\74\68\65\20\70\6C\61\63\65\73\20\74\68\61\74\20\6B\65\65\70\20\77\68\61\74\20\74\68\65\79\20\6C\65\74\20\67\6F\20\6F\66\20\75\6E\74\69\6C\20\74\68\65\69\72\20\73\63\6F\70\65\20\63\6C\6F\73\65\73\2C\20\61\6E\64\20\77\68\79\20\28\42\31\38\29" }>, align 64
@G_2ecompiler_2folang_2eOptWords = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWords.k1, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWords.k2, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWords.k3, [8 x i8] c"\09\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWords.k4, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWords.k5, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWords.k6, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWords.k7, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWords.k8, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWords.k9, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWords.k10, [8 x i8] c"\08\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWords.k11, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWords.k12 }>, align 64
@G_2ecompiler_2folang_2eOptWords.k1 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\2D\6F\75\74\70\75\74" }>, align 8
@G_2ecompiler_2folang_2eOptWords.k2 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\2D\64\65\62\75\67" }>, align 8
@G_2ecompiler_2folang_2eOptWords.k3 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\2D\72\61\63\65" }>, align 8
@G_2ecompiler_2folang_2eOptWords.k4 = internal constant <{ [9 x i8] }> <{ [9 x i8] c"\2D\73\61\6E\69\74\69\7A\65" }>, align 8
@G_2ecompiler_2folang_2eOptWords.k5 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\2D\74\61\72\67\65\74" }>, align 8
@G_2ecompiler_2folang_2eOptWords.k6 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\2D\64\65\66\69\6E\65" }>, align 8
@G_2ecompiler_2folang_2eOptWords.k7 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\2D\75\70\64\61\74\65" }>, align 8
@G_2ecompiler_2folang_2eOptWords.k8 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\2D\63\68\65\63\6B" }>, align 8
@G_2ecompiler_2folang_2eOptWords.k9 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\2D\71\75\69\63\6B" }>, align 8
@G_2ecompiler_2folang_2eOptWords.k10 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\2D\68\74\6D\6C" }>, align 8
@G_2ecompiler_2folang_2eOptWords.k11 = internal constant <{ [8 x i8] }> <{ [8 x i8] c"\2D\6C\69\62\72\61\72\79" }>, align 8
@G_2ecompiler_2folang_2eOptWords.k12 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\2D\6D\65\6D\6F\72\79" }>, align 8
@G_2ecompiler_2folang_2eRun = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eTest = constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eexplainedSrc = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\A7\02\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eexplainedSrc.k1 }>, align 8
@G_2ecompiler_2folang_2eexplainedSrc.k1 = internal constant <{ [679 x i8] }> <{ [679 x i8] c"\74\79\70\65\20\4D\61\74\68\45\72\72\6F\72\20\65\72\72\6F\72\20\7B\20\5A\45\52\4F\20\7D\0A\74\79\70\65\20\4E\20\73\74\72\75\63\74\28\76\20\49\36\34\2C\20\6E\65\78\74\20\4E\3F\26\29\20\7B\20\76\2C\20\6E\65\78\74\20\7D\0A\66\6E\20\28\6E\20\4E\26\29\20\56\61\6C\75\65\28\29\20\49\36\34\20\7B\20\72\65\74\75\72\6E\20\6E\2E\76\20\7D\0A\74\79\70\65\20\48\20\73\74\72\75\63\74\28\6E\20\4E\26\29\20\7B\20\6E\20\7D\0A\66\6E\20\77\72\61\70\28\6E\20\4E\26\29\20\48\20\7B\20\72\65\74\75\72\6E\20\48\28\6E\29\20\7D\0A\66\6E\20\64\69\76\6D\6F\64\28\61\20\49\36\34\2C\20\62\20\49\36\34\29\20\49\36\34\2C\20\49\36\34\20\3F\20\7B\0A\20\20\20\20\69\66\20\62\20\3D\3D\20\30\20\7B\20\65\72\72\6F\72\20\4D\61\74\68\45\72\72\6F\72\2E\5A\45\52\4F\20\7D\0A\20\20\20\20\72\65\74\75\72\6E\20\61\20\2F\20\62\2C\20\61\20\25\20\62\0A\7D\0A\66\6E\20\62\69\67\3C\54\3E\28\61\20\54\2C\20\62\20\54\29\20\54\20\7B\20\72\65\74\75\72\6E\20\61\20\69\66\20\61\20\3E\20\62\20\65\6C\73\65\20\62\20\7D\0A\74\79\70\65\20\53\68\20\65\6E\75\6D\20\7B\0A\20\20\20\20\57\68\6F\6C\65\20\4E\0A\20\20\20\20\50\61\72\74\73\28\61\20\49\36\34\2C\20\62\20\49\36\34\29\0A\20\20\20\20\4E\6F\6E\65\0A\7D\0A\41\6E\73\77\65\72\20\49\36\34\20\3D\20\36\20\2A\20\37\0A\66\6E\20\70\63\74\28\70\61\72\74\20\49\36\34\2C\20\77\68\6F\6C\65\20\49\36\34\29\20\5B\77\68\6F\6C\65\20\3E\20\30\2C\20\70\61\72\74\20\3E\3D\20\30\5D\20\49\36\34\20\7B\20\72\65\74\75\72\6E\20\70\61\72\74\20\2A\20\31\30\30\20\2F\20\77\68\6F\6C\65\20\7D\0A\66\6E\20\6C\69\6E\6B\28\61\20\6D\75\74\20\4E\26\2C\20\62\20\4E\26\29\20\5B\62\20\6F\75\74\6C\69\76\65\73\20\61\5D\20\7B\20\7D\0A\66\6E\20\6D\61\69\6E\28\29\20\3F\20\7B\0A\20\20\20\20\6E\6E\20\3A\3D\20\4E\28\70\63\74\28\31\2C\20\34\29\21\2C\20\6E\75\6C\6C\29\0A\20\20\20\20\6C\69\6E\6B\28\6E\6E\2C\20\6E\6E\29\0A\20\20\20\20\71\2C\20\5F\20\3A\3D\20\74\72\79\20\64\69\76\6D\6F\64\28\41\6E\73\77\65\72\2C\20\62\69\67\28\32\2C\20\33\29\29\0A\20\20\20\20\61\73\73\65\72\74\20\77\72\61\70\28\4E\28\71\2C\20\6E\75\6C\6C\29\29\2E\6E\2E\56\61\6C\75\65\28\29\20\3D\3D\20\31\34\0A\7D\0A" }>, align 64
define dso_local void @compiler_2folang_2eBindgen_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 12, ptr @G_2ecompiler_2folang_2eBindgen, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eBuild_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 1, ptr @G_2ecompiler_2folang_2eBuild, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eCompile_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 2, ptr @G_2ecompiler_2folang_2eCompile, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eDoc_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 8, ptr @G_2ecompiler_2folang_2eDoc, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eExplain_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 6, ptr @G_2ecompiler_2folang_2eExplain, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eFix_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 11, ptr @G_2ecompiler_2folang_2eFix, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eFormat_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 5, ptr @G_2ecompiler_2folang_2eFormat, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eHelp_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 7, ptr @G_2ecompiler_2folang_2eHelp, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eInterp_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 4, ptr @G_2ecompiler_2folang_2eInterp, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eLsp_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 9, ptr @G_2ecompiler_2folang_2eLsp, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eMcp_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 10, ptr @G_2ecompiler_2folang_2eMcp, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eModeUsage_2einit() #0 {
entry:
  %l0 = alloca [13 x { i64, ptr }]
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 0
  store { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d0, i32 0, i32 1) }, ptr %t1, !tbaa !37
  %t2 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 1
  store { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d1, i32 0, i32 1) }, ptr %t2, !tbaa !37
  %t3 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 2
  store { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d2, i32 0, i32 1) }, ptr %t3, !tbaa !37
  %t4 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 3
  store { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d3, i32 0, i32 1) }, ptr %t4, !tbaa !37
  %t5 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 4
  store { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d4, i32 0, i32 1) }, ptr %t5, !tbaa !37
  %t6 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 5
  store { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d5, i32 0, i32 1) }, ptr %t6, !tbaa !37
  %t7 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 6
  store { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d6, i32 0, i32 1) }, ptr %t7, !tbaa !37
  %t8 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 7
  store { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d7, i32 0, i32 1) }, ptr %t8, !tbaa !37
  %t9 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 8
  store { i64, ptr } { i64 67, ptr getelementptr inbounds (<{ i64, [67 x i8] }>, ptr @.d8, i32 0, i32 1) }, ptr %t9, !tbaa !37
  %t10 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 9
  store { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d9, i32 0, i32 1) }, ptr %t10, !tbaa !37
  %t11 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 10
  store { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d10, i32 0, i32 1) }, ptr %t11, !tbaa !37
  %t12 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 11
  store { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d11, i32 0, i32 1) }, ptr %t12, !tbaa !37
  %t13 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 12
  store { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d12, i32 0, i32 1) }, ptr %t13, !tbaa !37
  call void @llvm.memmove.p0.p0.i64(ptr @G_2ecompiler_2folang_2eModeUsage, ptr %l0, i64 208, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eModeWhat_2einit() #0 {
entry:
  %l0 = alloca [13 x { i64, ptr }]
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 0
  store { i64, ptr } { i64 106, ptr getelementptr inbounds (<{ i64, [106 x i8] }>, ptr @.d13, i32 0, i32 1) }, ptr %t1, !tbaa !37
  %t2 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 1
  store { i64, ptr } { i64 64, ptr getelementptr inbounds (<{ i64, [64 x i8] }>, ptr @.d14, i32 0, i32 1) }, ptr %t2, !tbaa !37
  %t3 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 2
  store { i64, ptr } { i64 54, ptr getelementptr inbounds (<{ i64, [54 x i8] }>, ptr @.d15, i32 0, i32 1) }, ptr %t3, !tbaa !37
  %t4 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 3
  store { i64, ptr } { i64 62, ptr getelementptr inbounds (<{ i64, [62 x i8] }>, ptr @.d16, i32 0, i32 1) }, ptr %t4, !tbaa !37
  %t5 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 4
  store { i64, ptr } { i64 110, ptr getelementptr inbounds (<{ i64, [110 x i8] }>, ptr @.d17, i32 0, i32 1) }, ptr %t5, !tbaa !37
  %t6 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 5
  store { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d18, i32 0, i32 1) }, ptr %t6, !tbaa !37
  %t7 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 6
  store { i64, ptr } { i64 93, ptr getelementptr inbounds (<{ i64, [93 x i8] }>, ptr @.d19, i32 0, i32 1) }, ptr %t7, !tbaa !37
  %t8 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 7
  store { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d20, i32 0, i32 1) }, ptr %t8, !tbaa !37
  %t9 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 8
  store { i64, ptr } { i64 68, ptr getelementptr inbounds (<{ i64, [68 x i8] }>, ptr @.d21, i32 0, i32 1) }, ptr %t9, !tbaa !37
  %t10 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 9
  store { i64, ptr } { i64 87, ptr getelementptr inbounds (<{ i64, [87 x i8] }>, ptr @.d22, i32 0, i32 1) }, ptr %t10, !tbaa !37
  %t11 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 10
  store { i64, ptr } { i64 84, ptr getelementptr inbounds (<{ i64, [84 x i8] }>, ptr @.d23, i32 0, i32 1) }, ptr %t11, !tbaa !37
  %t12 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 11
  store { i64, ptr } { i64 116, ptr getelementptr inbounds (<{ i64, [116 x i8] }>, ptr @.d24, i32 0, i32 1) }, ptr %t12, !tbaa !37
  %t13 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 12
  store { i64, ptr } { i64 76, ptr getelementptr inbounds (<{ i64, [76 x i8] }>, ptr @.d25, i32 0, i32 1) }, ptr %t13, !tbaa !37
  call void @llvm.memmove.p0.p0.i64(ptr @G_2ecompiler_2folang_2eModeWhat, ptr %l0, i64 208, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eModeWords_2einit() #0 {
entry:
  %l0 = alloca [13 x { i64, ptr }]
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 0
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d26, i32 0, i32 1) }, ptr %t1, !tbaa !37
  %t2 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 1
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d27, i32 0, i32 1) }, ptr %t2, !tbaa !37
  %t3 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 2
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d28, i32 0, i32 1) }, ptr %t3, !tbaa !37
  %t4 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 3
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d29, i32 0, i32 1) }, ptr %t4, !tbaa !37
  %t5 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 4
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d30, i32 0, i32 1) }, ptr %t5, !tbaa !37
  %t6 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 5
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d31, i32 0, i32 1) }, ptr %t6, !tbaa !37
  %t7 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 6
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d32, i32 0, i32 1) }, ptr %t7, !tbaa !37
  %t8 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 7
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d33, i32 0, i32 1) }, ptr %t8, !tbaa !37
  %t9 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 8
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d34, i32 0, i32 1) }, ptr %t9, !tbaa !37
  %t10 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 9
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d35, i32 0, i32 1) }, ptr %t10, !tbaa !37
  %t11 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 10
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d36, i32 0, i32 1) }, ptr %t11, !tbaa !37
  %t12 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 11
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d37, i32 0, i32 1) }, ptr %t12, !tbaa !37
  %t13 = getelementptr [13 x { i64, ptr }], ptr %l0, i64 0, i64 12
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d38, i32 0, i32 1) }, ptr %t13, !tbaa !37
  call void @llvm.memmove.p0.p0.i64(ptr @G_2ecompiler_2folang_2eModeWords, ptr %l0, i64 208, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eOptModes_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t1 = insertvalue [12 x i64] undef, i64 4102, 0
  %t2 = insertvalue [12 x i64] %t1, i64 15, 1
  %t3 = insertvalue [12 x i64] %t2, i64 15, 2
  %t4 = insertvalue [12 x i64] %t3, i64 15, 3
  %t5 = insertvalue [12 x i64] %t4, i64 1887, 4
  %t6 = insertvalue [12 x i64] %t5, i64 1887, 5
  %t7 = insertvalue [12 x i64] %t6, i64 1887, 6
  %t8 = insertvalue [12 x i64] %t7, i64 2080, 7
  %t9 = insertvalue [12 x i64] %t8, i64 15, 8
  %t10 = insertvalue [12 x i64] %t9, i64 256, 9
  %t11 = insertvalue [12 x i64] %t10, i64 2, 10
  %t12 = insertvalue [12 x i64] %t11, i64 11, 11
  store [12 x i64] %t12, ptr @G_2ecompiler_2folang_2eOptModes
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eOptValues_2einit() #0 {
entry:
  %l0 = alloca [12 x { i64, ptr }]
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 0
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d39, i32 0, i32 1) }, ptr %t1, !tbaa !37
  %t2 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 1
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d40, i32 0, i32 1) }, ptr %t2, !tbaa !37
  %t3 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 2
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d41, i32 0, i32 1) }, ptr %t3, !tbaa !37
  %t4 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 3
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d42, i32 0, i32 1) }, ptr %t4, !tbaa !37
  %t5 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 4
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d43, i32 0, i32 1) }, ptr %t5, !tbaa !37
  %t6 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 5
  store { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d44, i32 0, i32 1) }, ptr %t6, !tbaa !37
  %t7 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 6
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d45, i32 0, i32 1) }, ptr %t7, !tbaa !37
  %t8 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 7
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d46, i32 0, i32 1) }, ptr %t8, !tbaa !37
  %t9 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 8
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d47, i32 0, i32 1) }, ptr %t9, !tbaa !37
  %t10 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 9
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d48, i32 0, i32 1) }, ptr %t10, !tbaa !37
  %t11 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 10
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d49, i32 0, i32 1) }, ptr %t11, !tbaa !37
  %t12 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 11
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d50, i32 0, i32 1) }, ptr %t12, !tbaa !37
  call void @llvm.memmove.p0.p0.i64(ptr @G_2ecompiler_2folang_2eOptValues, ptr %l0, i64 192, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eOptWhat_2einit() #0 {
entry:
  %l0 = alloca [12 x { i64, ptr }]
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 0
  store { i64, ptr } { i64 78, ptr getelementptr inbounds (<{ i64, [78 x i8] }>, ptr @.d51, i32 0, i32 1) }, ptr %t1, !tbaa !37
  %t2 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 1
  store { i64, ptr } { i64 53, ptr getelementptr inbounds (<{ i64, [53 x i8] }>, ptr @.d52, i32 0, i32 1) }, ptr %t2, !tbaa !37
  %t3 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 2
  store { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d53, i32 0, i32 1) }, ptr %t3, !tbaa !37
  %t4 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 3
  store { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d54, i32 0, i32 1) }, ptr %t4, !tbaa !37
  %t5 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 4
  store { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d55, i32 0, i32 1) }, ptr %t5, !tbaa !37
  %t6 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 5
  store { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d56, i32 0, i32 1) }, ptr %t6, !tbaa !37
  %t7 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 6
  store { i64, ptr } { i64 85, ptr getelementptr inbounds (<{ i64, [85 x i8] }>, ptr @.d57, i32 0, i32 1) }, ptr %t7, !tbaa !37
  %t8 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 7
  store { i64, ptr } { i64 89, ptr getelementptr inbounds (<{ i64, [89 x i8] }>, ptr @.d58, i32 0, i32 1) }, ptr %t8, !tbaa !37
  %t9 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 8
  store { i64, ptr } { i64 96, ptr getelementptr inbounds (<{ i64, [96 x i8] }>, ptr @.d59, i32 0, i32 1) }, ptr %t9, !tbaa !37
  %t10 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 9
  store { i64, ptr } { i64 109, ptr getelementptr inbounds (<{ i64, [109 x i8] }>, ptr @.d60, i32 0, i32 1) }, ptr %t10, !tbaa !37
  %t11 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 10
  store { i64, ptr } { i64 83, ptr getelementptr inbounds (<{ i64, [83 x i8] }>, ptr @.d61, i32 0, i32 1) }, ptr %t11, !tbaa !37
  %t12 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 11
  store { i64, ptr } { i64 88, ptr getelementptr inbounds (<{ i64, [88 x i8] }>, ptr @.d62, i32 0, i32 1) }, ptr %t12, !tbaa !37
  call void @llvm.memmove.p0.p0.i64(ptr @G_2ecompiler_2folang_2eOptWhat, ptr %l0, i64 192, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eOptWords_2einit() #0 {
entry:
  %l0 = alloca [12 x { i64, ptr }]
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 0
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d63, i32 0, i32 1) }, ptr %t1, !tbaa !37
  %t2 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 1
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d64, i32 0, i32 1) }, ptr %t2, !tbaa !37
  %t3 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 2
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d65, i32 0, i32 1) }, ptr %t3, !tbaa !37
  %t4 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 3
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d66, i32 0, i32 1) }, ptr %t4, !tbaa !37
  %t5 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 4
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d67, i32 0, i32 1) }, ptr %t5, !tbaa !37
  %t6 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 5
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d68, i32 0, i32 1) }, ptr %t6, !tbaa !37
  %t7 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 6
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d69, i32 0, i32 1) }, ptr %t7, !tbaa !37
  %t8 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 7
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d70, i32 0, i32 1) }, ptr %t8, !tbaa !37
  %t9 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 8
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d71, i32 0, i32 1) }, ptr %t9, !tbaa !37
  %t10 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 9
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d72, i32 0, i32 1) }, ptr %t10, !tbaa !37
  %t11 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 10
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d73, i32 0, i32 1) }, ptr %t11, !tbaa !37
  %t12 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 11
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d74, i32 0, i32 1) }, ptr %t12, !tbaa !37
  call void @llvm.memmove.p0.p0.i64(ptr @G_2ecompiler_2folang_2eOptWords, ptr %l0, i64 192, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local { i32, %"compiler/olang:CommandLine" } @compiler_2folang_2eParse(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l2 = alloca ptr
  %lp3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca %"compiler/olang:CommandLine"
  %l19 = alloca ptr
  %l20 = alloca %"compiler/msgs:Msg"
  %l21 = alloca i32
  %l23 = alloca { i64, ptr }
  %l25 = alloca i1
  %l27 = alloca i1
  %l28 = alloca { i64, ptr }
  %l30 = alloca i1
  %l32 = alloca { i64, ptr }
  %l34 = alloca i64
  %l37 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l40 = alloca %"compiler/msgs:Msg"
  %l41 = alloca i32
  %l49 = alloca { i64, ptr }
  %l55 = alloca i1
  %l56 = alloca [12 x { i64, ptr }]
  %l61 = alloca i64
  %l64 = alloca i64
  %l85 = alloca i1
  %l91 = alloca ptr
  %l92 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l96 = alloca %"compiler/msgs:Msg"
  %l97 = alloca i32
  %l101 = alloca i64
  %l105 = alloca ptr
  %l106 = alloca { i64, ptr }
  %l109 = alloca { i64, ptr }
  %l110 = alloca { i64, ptr }
  %l112 = alloca { i64, ptr }
  %l114 = alloca %"compiler/msgs:Msg"
  %l115 = alloca i32
  %l123 = alloca i1
  %l129 = alloca ptr
  %l133 = alloca %"compiler/msgs:Msg"
  %l134 = alloca i32
  %l136 = alloca { i64, ptr }
  %l172 = alloca i32
  %l198 = alloca i1
  %l201 = alloca i1
  %l204 = alloca ptr
  %l207 = alloca { i64, ptr }
  %l208 = alloca %"compiler/msgs:Msg"
  %l209 = alloca i32
  %l214 = alloca i1
  %l216 = alloca i1
  %l217 = alloca i1
  %l219 = alloca i64
  %l221 = alloca i1
  %l223 = alloca i1
  %l226 = alloca ptr
  %l228 = alloca { i64, ptr }
  %l229 = alloca %"compiler/msgs:Msg"
  %l230 = alloca i32
  %l238 = alloca i1
  %l245 = alloca i1
  %l247 = alloca i1
  %l249 = alloca i64
  %l251 = alloca i1
  %l253 = alloca i1
  %l262 = alloca ptr
  %l266 = alloca %"compiler/msgs:Msg"
  %l267 = alloca %"compiler/msgs:Msg"
  %l268 = alloca %"compiler/msgs:Msg"
  %l269 = alloca i32
  %l277 = alloca i1
  %l279 = alloca i1
  %l282 = alloca i64
  %l284 = alloca ptr
  %l286 = alloca %"compiler/msgs:Msg"
  %l287 = alloca i32
  %l289 = alloca ptr
  %l291 = alloca %"compiler/msgs:Msg"
  %l292 = alloca i32
  %l301 = alloca i1
  %l311 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %s41 = alloca %olang.scope
  %s43 = alloca %olang.scope
  %s44 = alloca %olang.scope
  %s47 = alloca %olang.scope
  %rv = alloca { i32, %"compiler/olang:CommandLine" }
  store { i64, ptr } %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"compiler/olang:CommandLine" @compiler_2folang_3aCommandLine_2ector(ptr %v3)
  store %"compiler/olang:CommandLine" %t1, ptr %l15
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 112, i64 8)
  store ptr %t2, ptr %lp3
  %t3 = load %"compiler/olang:CommandLine", ptr %l15
  %t4 = load ptr, ptr %lp3
  store %"compiler/olang:CommandLine" %t3, ptr %t4
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t9 = icmp slt i64 %t7, 2
  br i1 %t9, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = load ptr, ptr %l2, !tbaa !29
  store ptr %t11, ptr %l19, !tbaa !29
  %t12 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eUsage(ptr %s1)
  store %"compiler/msgs:Msg" %t12, ptr %l20
  br label %bb4
bb3:
  br label %bb8
bb4:
  %t13 = load ptr, ptr %l19, !tbaa !29
  %t14 = load %"compiler/msgs:Msg", ptr %l20
  %t15 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s1, ptr %t13, %"compiler/msgs:Msg" %t14)
  store i32 %t15, ptr %l21
  %t16 = icmp ne i32 %t15, 0
  br i1 %t16, label %bb6, label %ok.17
ok.17:
  br label %bb5
bb5:
  br label %bb7
bb6:
  %t18 = load i32, ptr %l21, !tbaa !23
  %t19 = lshr i32 %t18, 16
  %t20 = and i32 %t18, 65535
  %t21 = icmp eq i32 %t19, 1
  %t22 = select i1 %t21, i32 1, i32 0
  %t23 = icmp eq i32 %t18, 0
  %t24 = shl i32 %t22, 16
  %t25 = or i32 %t24, %t20
  %t26 = select i1 %t23, i32 0, i32 %t25
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t28 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t26, 0
  store { i32, %"compiler/olang:CommandLine" } %t28, ptr %rv
  br label %ret
bb7:
  call void @__olang_scope_close(ptr %s1)
  br label %bb8
bb8:
  store i64 1, ptr %l4, !tbaa !24
  %t29 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t29, ptr %l23, !tbaa !27
  %t30 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr { i64, ptr }, ptr %t31, i64 1
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !37
  %t35 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t33, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d75, i32 0, i32 1) })
  store i1 %t35, ptr %l25
  br label %bb9
bb9:
  %t36 = load i1, ptr %l25, !tbaa !21
  %t37 = xor i1 %t36, true
  br i1 %t37, label %bb10, label %bb11
bb10:
  %t39 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t39, ptr %l28, !tbaa !27
  %t40 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %t41, i64 1
  %t43 = load { i64, ptr }, ptr %t42, !tbaa !37
  %t45 = call i1 @compiler_2folang_2eendsWithOlang(ptr %v0, { i64, ptr } %t43)
  store i1 %t45, ptr %l30
  br label %bb12
bb11:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb13
bb12:
  %t46 = load i1, ptr %l30, !tbaa !21
  %t47 = xor i1 %t46, true
  store i1 %t47, ptr %l27, !tbaa !21
  br label %bb13
bb13:
  %t49 = load i1, ptr %l27, !tbaa !21
  br i1 %t49, label %bb14, label %bb15
bb14:
  %t50 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t50, ptr %l32, !tbaa !27
  %t51 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = getelementptr { i64, ptr }, ptr %t52, i64 1
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !37
  %t56 = call i64 @compiler_2folang_2emodeNumber(ptr %v0, { i64, ptr } %t54)
  store i64 %t56, ptr %l34
  br label %bb16
bb15:
  br label %bb24
bb16:
  %t57 = load i64, ptr %l34, !tbaa !24
  store i64 %t57, ptr %l5, !tbaa !24
  %t58 = load i64, ptr %l5, !tbaa !24
  %t60 = icmp slt i64 %t58, 0
  br i1 %t60, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s3
  %t62 = load ptr, ptr %l2, !tbaa !29
  store ptr %t62, ptr %l37, !tbaa !29
  %t63 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t63, ptr %l38, !tbaa !27
  %t64 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = getelementptr { i64, ptr }, ptr %t65, i64 1
  %t67 = load { i64, ptr }, ptr %t66, !tbaa !37
  %t69 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotAMode(ptr %v0, ptr %s3, { i64, ptr } %t67)
  store %"compiler/msgs:Msg" %t69, ptr %l40
  br label %bb19
bb18:
  br label %bb23
bb19:
  %t70 = load ptr, ptr %l37, !tbaa !29
  %t71 = load %"compiler/msgs:Msg", ptr %l40
  %t72 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s3, ptr %t70, %"compiler/msgs:Msg" %t71)
  store i32 %t72, ptr %l41
  %t73 = icmp ne i32 %t72, 0
  br i1 %t73, label %bb21, label %ok.74
ok.74:
  br label %bb20
bb20:
  br label %bb22
bb21:
  %t75 = load i32, ptr %l41, !tbaa !23
  %t76 = lshr i32 %t75, 16
  %t77 = and i32 %t75, 65535
  %t78 = icmp eq i32 %t76, 1
  %t79 = select i1 %t78, i32 1, i32 0
  %t80 = icmp eq i32 %t75, 0
  %t81 = shl i32 %t79, 16
  %t82 = or i32 %t81, %t77
  %t83 = select i1 %t80, i32 0, i32 %t82
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t85 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t83, 0
  store { i32, %"compiler/olang:CommandLine" } %t85, ptr %rv
  br label %ret
bb22:
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb23:
  %t86 = load i64, ptr %l5, !tbaa !24
  %t88 = load ptr, ptr %lp3
  %t89 = getelementptr %"compiler/olang:CommandLine", ptr %t88, i32 0, i32 0
  store i64 %t86, ptr %t89, !tbaa !24
  store i64 2, ptr %l4, !tbaa !24
  br label %bb24
bb24:
  br label %bb25
bb25:
  store %olang.scope zeroinitializer, ptr %s4
  %t90 = load i64, ptr %l4, !tbaa !24
  %t91 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t91, 0
  %t96 = icmp slt i64 %t90, %t93
  %t98 = xor i1 %t96, true
  br i1 %t98, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s4)
  br label %bb226
bb27:
  br label %bb28
bb28:
  %t100 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t100, ptr %l49, !tbaa !27
  %t101 = load i64, ptr %l4, !tbaa !24
  %t103 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = getelementptr { i64, ptr }, ptr %t104, i64 %t101
  %t106 = load { i64, ptr }, ptr %t105, !tbaa !37
  store { i64, ptr } %t106, ptr %l6, !tbaa !27
  %t108 = load i64, ptr %l4, !tbaa !24
  %t110 = add i64 %t108, 1
  store i64 %t110, ptr %l4, !tbaa !24
  %t112 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t114 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s4, { i64, ptr } %t112, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d76, i32 0, i32 1) })
  store i1 %t114, ptr %l55
  br label %bb29
bb29:
  %t115 = load i1, ptr %l55, !tbaa !21
  br i1 %t115, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s5
  store i64 -1, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l56, ptr @G_2ecompiler_2folang_2eOptWords, i64 192, i1 false)
  %t116 = load [12 x { i64, ptr }], ptr %l56
  store i64 12, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t118 = load i64, ptr %l9, !tbaa !24
  %t119 = load i64, ptr %l8, !tbaa !24
  %t122 = icmp sgt i64 %t118, %t119
  br i1 %t122, label %bb32, label %bb33
bb31:
  br label %bb136
bb32:
  %t124 = load i64, ptr %l10, !tbaa !24
  %t126 = icmp sgt i64 %t124, 0
  br i1 %t126, label %bb34, label %bb35
bb33:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb37
bb34:
  %t128 = load i64, ptr %l9, !tbaa !24
  %t129 = load i64, ptr %l8, !tbaa !24
  %t132 = sub i64 %t128, %t129
  %t133 = load i64, ptr %l10, !tbaa !24
  %t136 = add i64 %t132, %t133
  %t138 = sub i64 %t136, 1
  %t139 = load i64, ptr %l10, !tbaa !24
  %t142 = sdiv i64 %t138, %t139
  store i64 %t142, ptr %l64, !tbaa !24
  br label %bb36
bb35:
  store i64 0, ptr %l64, !tbaa !24
  br label %bb36
bb36:
  %t144 = load i64, ptr %l64, !tbaa !24
  store i64 %t144, ptr %l61, !tbaa !24
  br label %bb37
bb37:
  %t145 = load i64, ptr %l61, !tbaa !24
  store i64 %t145, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb38
bb38:
  store %olang.scope zeroinitializer, ptr %s7
  %t146 = load i64, ptr %l12, !tbaa !24
  %t147 = load i64, ptr %l11, !tbaa !24
  %t150 = icmp slt i64 %t146, %t147
  %t152 = xor i1 %t150, true
  br i1 %t152, label %bb39, label %bb40
bb39:
  call void @__olang_scope_close(ptr %s7)
  br label %bb47
bb40:
  br label %bb41
bb41:
  %t154 = load i64, ptr %l8, !tbaa !24
  %t155 = load i64, ptr %l12, !tbaa !24
  %t156 = load i64, ptr %l10, !tbaa !24
  %t159 = mul i64 %t155, %t156
  %t162 = add i64 %t154, %t159
  store i64 %t162, ptr %l13, !tbaa !24
  %t164 = load i64, ptr %l13, !tbaa !24
  %t166 = getelementptr [12 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eOptWords, i64 0, i64 %t164
  %t167 = load { i64, ptr }, ptr %t166, !tbaa !37
  %t168 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t169 = load ptr, ptr @__olang_prog_scope
  %t172 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t169, ptr %v0, { i64, ptr } %t167, { i64, ptr } %t168)
  store i1 %t172, ptr %l85
  br label %bb42
bb42:
  %t173 = load i1, ptr %l85, !tbaa !21
  br i1 %t173, label %bb43, label %bb44
bb43:
  %t174 = load i64, ptr %l13, !tbaa !24
  store i64 %t174, ptr %l7, !tbaa !24
  br label %bb45
bb44:
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s7)
  br label %bb46
bb46:
  %t176 = load i64, ptr %l12, !tbaa !24
  %t178 = add i64 %t176, 1
  store i64 %t178, ptr %l12, !tbaa !24
  br label %bb38
bb47:
  %t180 = load i64, ptr %l7, !tbaa !24
  %t182 = icmp slt i64 %t180, 0
  br i1 %t182, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s10
  %t184 = load ptr, ptr %l2, !tbaa !29
  store ptr %t184, ptr %l91, !tbaa !29
  %t185 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t185, ptr %l92, !tbaa !27
  %t186 = load ptr, ptr %lp3
  %t187 = getelementptr %"compiler/olang:CommandLine", ptr %t186, i32 0, i32 0
  %t188 = load i64, ptr %t187, !tbaa !24
  %t190 = call { i64, ptr } @compiler_2folang_2emodeName(ptr %s10, i64 %t188)
  store { i64, ptr } %t190, ptr %l94
  br label %bb50
bb49:
  br label %bb55
bb50:
  %t191 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t192 = extractvalue { i64, ptr } %t191, 0
  %t193 = extractvalue { i64, ptr } %t191, 1
  %t194 = mul i64 %t192, 1
  %t195 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t194)
  call void @llvm.memcpy.p0.p0.i64(ptr %t195, ptr %t193, i64 %t194, i1 false)
  %t196 = insertvalue { i64, ptr } undef, i64 %t192, 0
  %t197 = insertvalue { i64, ptr } %t196, ptr %t195, 1
  %t198 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t200 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownFlag(ptr %v0, ptr %s10, ptr %s10, { i64, ptr } %t198, { i64, ptr } %t197)
  store %"compiler/msgs:Msg" %t200, ptr %l96
  br label %bb51
bb51:
  %t201 = load ptr, ptr %l91, !tbaa !29
  %t202 = load %"compiler/msgs:Msg", ptr %l96
  %t203 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s10, ptr %t201, %"compiler/msgs:Msg" %t202)
  store i32 %t203, ptr %l97
  %t204 = icmp ne i32 %t203, 0
  br i1 %t204, label %bb53, label %ok.205
ok.205:
  br label %bb52
bb52:
  br label %bb54
bb53:
  %t206 = load i32, ptr %l97, !tbaa !23
  %t207 = lshr i32 %t206, 16
  %t208 = and i32 %t206, 65535
  %t209 = icmp eq i32 %t207, 1
  %t210 = select i1 %t209, i32 1, i32 0
  %t211 = icmp eq i32 %t206, 0
  %t212 = shl i32 %t210, 16
  %t213 = or i32 %t212, %t208
  %t214 = select i1 %t211, i32 0, i32 %t213
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t216 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t214, 0
  store { i32, %"compiler/olang:CommandLine" } %t216, ptr %rv
  br label %ret
bb54:
  call void @__olang_scope_close(ptr %s10)
  br label %bb55
bb55:
  %t217 = load i64, ptr %l7, !tbaa !24
  %t219 = getelementptr [12 x i64], ptr @G_2ecompiler_2folang_2eOptModes, i64 0, i64 %t217
  %t220 = load i64, ptr %t219, !tbaa !34
  %t221 = load ptr, ptr %lp3
  %t222 = getelementptr %"compiler/olang:CommandLine", ptr %t221, i32 0, i32 0
  %t223 = load i64, ptr %t222, !tbaa !24
  store i64 %t223, ptr %l101, !tbaa !24
  %t225 = load i64, ptr %l101, !tbaa !24
  %t226 = load i64, ptr %l101, !tbaa !24
  %t227 = ashr i64 %t220, %t226
  %t229 = and i64 %t227, 1
  %t231 = icmp eq i64 %t229, 0
  br i1 %t231, label %bb56, label %bb57
bb56:
  store %olang.scope zeroinitializer, ptr %s11
  %t233 = load ptr, ptr %l2, !tbaa !29
  store ptr %t233, ptr %l105, !tbaa !29
  %t234 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t234, ptr %l106, !tbaa !27
  %t235 = load i64, ptr %l7, !tbaa !24
  %t237 = getelementptr [12 x i64], ptr @G_2ecompiler_2folang_2eOptModes, i64 0, i64 %t235
  %t238 = load i64, ptr %t237, !tbaa !34
  %t240 = call { i64, ptr } @compiler_2folang_2emodesOf(ptr %s11, i64 %t238)
  store { i64, ptr } %t240, ptr %l109
  br label %bb58
bb57:
  br label %bb64
bb58:
  %t241 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t242 = extractvalue { i64, ptr } %t241, 0
  %t243 = extractvalue { i64, ptr } %t241, 1
  %t244 = mul i64 %t242, 1
  %t245 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t244)
  call void @llvm.memcpy.p0.p0.i64(ptr %t245, ptr %t243, i64 %t244, i1 false)
  %t246 = insertvalue { i64, ptr } undef, i64 %t242, 0
  %t247 = insertvalue { i64, ptr } %t246, ptr %t245, 1
  store { i64, ptr } %t247, ptr %l110, !tbaa !27
  %t248 = load ptr, ptr %lp3
  %t249 = getelementptr %"compiler/olang:CommandLine", ptr %t248, i32 0, i32 0
  %t250 = load i64, ptr %t249, !tbaa !24
  %t252 = call { i64, ptr } @compiler_2folang_2emodeName(ptr %s11, i64 %t250)
  store { i64, ptr } %t252, ptr %l112
  br label %bb59
bb59:
  %t253 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t254 = extractvalue { i64, ptr } %t253, 0
  %t255 = extractvalue { i64, ptr } %t253, 1
  %t256 = mul i64 %t254, 1
  %t257 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t256)
  call void @llvm.memcpy.p0.p0.i64(ptr %t257, ptr %t255, i64 %t256, i1 false)
  %t258 = insertvalue { i64, ptr } undef, i64 %t254, 0
  %t259 = insertvalue { i64, ptr } %t258, ptr %t257, 1
  %t260 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t261 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t263 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eOptionNotForMode(ptr %v0, ptr %s11, ptr %s11, ptr %s11, { i64, ptr } %t260, { i64, ptr } %t261, { i64, ptr } %t259)
  store %"compiler/msgs:Msg" %t263, ptr %l114
  br label %bb60
bb60:
  %t264 = load ptr, ptr %l105, !tbaa !29
  %t265 = load %"compiler/msgs:Msg", ptr %l114
  %t266 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s11, ptr %t264, %"compiler/msgs:Msg" %t265)
  store i32 %t266, ptr %l115
  %t267 = icmp ne i32 %t266, 0
  br i1 %t267, label %bb62, label %ok.268
ok.268:
  br label %bb61
bb61:
  br label %bb63
bb62:
  %t269 = load i32, ptr %l115, !tbaa !23
  %t270 = lshr i32 %t269, 16
  %t271 = and i32 %t269, 65535
  %t272 = icmp eq i32 %t270, 1
  %t273 = select i1 %t272, i32 1, i32 0
  %t274 = icmp eq i32 %t269, 0
  %t275 = shl i32 %t273, 16
  %t276 = or i32 %t275, %t271
  %t277 = select i1 %t274, i32 0, i32 %t276
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t279 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t277, 0
  store { i32, %"compiler/olang:CommandLine" } %t279, ptr %rv
  br label %ret
bb63:
  call void @__olang_scope_close(ptr %s11)
  br label %bb64
bb64:
  %t280 = load ptr, ptr %lp3
  %t281 = getelementptr %"compiler/olang:CommandLine", ptr %t280, i32 0, i32 5
  %t282 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t284 = extractvalue { i64, ptr } %t282, 1
  %t285 = extractvalue { i64, ptr } %t282, 0
  %t286 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t285)
  call void @olang_textcopy(ptr %t286, ptr %t284, i64 %t285)
  %t287 = insertvalue { i64, ptr } undef, i64 %t285, 0
  %t288 = insertvalue { i64, ptr } %t287, ptr %t286, 1
  %t290 = extractvalue { i64, ptr } %t288, 0
  %t291 = extractvalue { i64, ptr } %t288, 1
  %t292 = mul i64 %t290, 1
  %t293 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t292)
  call void @llvm.memcpy.p0.p0.i64(ptr %t293, ptr %t291, i64 %t292, i1 false)
  %t294 = insertvalue { i64, ptr } undef, i64 %t290, 0
  %t295 = insertvalue { i64, ptr } %t294, ptr %t293, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v3, ptr %v3, ptr %t281, { i64, ptr } %t295)
  br label %bb65
bb65:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d77, i32 0, i32 1) }, ptr %l14, !tbaa !27
  %t298 = load i64, ptr %l7, !tbaa !24
  %t300 = getelementptr [12 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eOptValues, i64 0, i64 %t298
  %t301 = load { i64, ptr }, ptr %t300, !tbaa !37
  %t302 = load ptr, ptr @__olang_prog_scope
  %t304 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t302, ptr %s5, { i64, ptr } %t301, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d78, i32 0, i32 1) })
  store i1 %t304, ptr %l123
  br label %bb66
bb66:
  %t305 = load i1, ptr %l123, !tbaa !21
  %t306 = xor i1 %t305, true
  br i1 %t306, label %bb67, label %bb68
bb67:
  %t308 = load i64, ptr %l4, !tbaa !24
  %t309 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t311 = extractvalue { i64, ptr } %t309, 0
  %t314 = icmp sge i64 %t308, %t311
  br i1 %t314, label %bb69, label %bb70
bb68:
  br label %bb77
bb69:
  store %olang.scope zeroinitializer, ptr %s14
  %t316 = load ptr, ptr %l2, !tbaa !29
  store ptr %t316, ptr %l129, !tbaa !29
  %t317 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t318 = load i64, ptr %l7, !tbaa !24
  %t320 = getelementptr [12 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eOptValues, i64 0, i64 %t318
  %t321 = load { i64, ptr }, ptr %t320, !tbaa !37
  %t322 = load ptr, ptr @__olang_prog_scope
  %t325 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eOptionNeedsValue(ptr %v0, ptr %t322, ptr %s14, { i64, ptr } %t317, { i64, ptr } %t321)
  store %"compiler/msgs:Msg" %t325, ptr %l133
  br label %bb71
bb70:
  br label %bb75
bb71:
  %t326 = load ptr, ptr %l129, !tbaa !29
  %t327 = load %"compiler/msgs:Msg", ptr %l133
  %t328 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s14, ptr %t326, %"compiler/msgs:Msg" %t327)
  store i32 %t328, ptr %l134
  %t329 = icmp ne i32 %t328, 0
  br i1 %t329, label %bb73, label %ok.330
ok.330:
  br label %bb72
bb72:
  br label %bb74
bb73:
  %t331 = load i32, ptr %l134, !tbaa !23
  %t332 = lshr i32 %t331, 16
  %t333 = and i32 %t331, 65535
  %t334 = icmp eq i32 %t332, 1
  %t335 = select i1 %t334, i32 1, i32 0
  %t336 = icmp eq i32 %t331, 0
  %t337 = shl i32 %t335, 16
  %t338 = or i32 %t337, %t333
  %t339 = select i1 %t336, i32 0, i32 %t338
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t341 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t339, 0
  store { i32, %"compiler/olang:CommandLine" } %t341, ptr %rv
  br label %ret
bb74:
  call void @__olang_scope_close(ptr %s14)
  br label %bb75
bb75:
  %t342 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t342, ptr %l136, !tbaa !27
  %t343 = load i64, ptr %l4, !tbaa !24
  %t345 = getelementptr { i64, ptr }, ptr %l136, i32 0, i32 1
  %t346 = load ptr, ptr %t345, !tbaa !27
  %t347 = getelementptr { i64, ptr }, ptr %t346, i64 %t343
  %t348 = load { i64, ptr }, ptr %t347, !tbaa !37
  %t350 = extractvalue { i64, ptr } %t348, 1
  %t351 = extractvalue { i64, ptr } %t348, 0
  %t352 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t351)
  call void @olang_textcopy(ptr %t352, ptr %t350, i64 %t351)
  %t353 = insertvalue { i64, ptr } undef, i64 %t351, 0
  %t354 = insertvalue { i64, ptr } %t353, ptr %t352, 1
  %t356 = extractvalue { i64, ptr } %t354, 0
  %t357 = extractvalue { i64, ptr } %t354, 1
  %t358 = mul i64 %t356, 1
  %t359 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t358)
  call void @llvm.memcpy.p0.p0.i64(ptr %t359, ptr %t357, i64 %t358, i1 false)
  %t360 = insertvalue { i64, ptr } undef, i64 %t356, 0
  %t361 = insertvalue { i64, ptr } %t360, ptr %t359, 1
  store { i64, ptr } %t361, ptr %l14, !tbaa !27
  %t363 = load i64, ptr %l4, !tbaa !24
  %t365 = add i64 %t363, 1
  store i64 %t365, ptr %l4, !tbaa !24
  %t367 = load ptr, ptr %lp3
  %t368 = getelementptr %"compiler/olang:CommandLine", ptr %t367, i32 0, i32 5
  %t369 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t371 = extractvalue { i64, ptr } %t369, 1
  %t372 = extractvalue { i64, ptr } %t369, 0
  %t373 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t372)
  call void @olang_textcopy(ptr %t373, ptr %t371, i64 %t372)
  %t374 = insertvalue { i64, ptr } undef, i64 %t372, 0
  %t375 = insertvalue { i64, ptr } %t374, ptr %t373, 1
  %t377 = extractvalue { i64, ptr } %t375, 0
  %t378 = extractvalue { i64, ptr } %t375, 1
  %t379 = mul i64 %t377, 1
  %t380 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t379)
  call void @llvm.memcpy.p0.p0.i64(ptr %t380, ptr %t378, i64 %t379, i1 false)
  %t381 = insertvalue { i64, ptr } undef, i64 %t377, 0
  %t382 = insertvalue { i64, ptr } %t381, ptr %t380, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v3, ptr %v3, ptr %t368, { i64, ptr } %t382)
  br label %bb76
bb76:
  br label %bb77
bb77:
  %t385 = load i64, ptr %l7, !tbaa !24
  %t387 = icmp eq i64 %t385, 0
  br i1 %t387, label %bb78, label %bb79
bb78:
  %t389 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t391 = extractvalue { i64, ptr } %t389, 1
  %t392 = extractvalue { i64, ptr } %t389, 0
  %t393 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t392)
  call void @olang_textcopy(ptr %t393, ptr %t391, i64 %t392)
  %t394 = insertvalue { i64, ptr } undef, i64 %t392, 0
  %t395 = insertvalue { i64, ptr } %t394, ptr %t393, 1
  %t397 = extractvalue { i64, ptr } %t395, 0
  %t398 = extractvalue { i64, ptr } %t395, 1
  %t399 = mul i64 %t397, 1
  %t400 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t399)
  call void @llvm.memcpy.p0.p0.i64(ptr %t400, ptr %t398, i64 %t399, i1 false)
  %t401 = insertvalue { i64, ptr } undef, i64 %t397, 0
  %t402 = insertvalue { i64, ptr } %t401, ptr %t400, 1
  %t404 = load ptr, ptr %lp3
  %t405 = getelementptr %"compiler/olang:CommandLine", ptr %t404, i32 0, i32 7
  store { i64, ptr } %t402, ptr %t405, !tbaa !27
  br label %bb80
bb79:
  br label %bb80
bb80:
  %t406 = load i64, ptr %l7, !tbaa !24
  %t408 = icmp eq i64 %t406, 1
  br i1 %t408, label %bb81, label %bb82
bb81:
  %t410 = load ptr, ptr %l1, !tbaa !29
  %t412 = getelementptr %"compiler/build:Config", ptr %t410, i32 0, i32 4
  store i1 true, ptr %t412, !tbaa !21
  br label %bb83
bb82:
  br label %bb83
bb83:
  %t413 = load i64, ptr %l7, !tbaa !24
  %t415 = icmp eq i64 %t413, 2
  br i1 %t415, label %bb84, label %bb85
bb84:
  %t417 = load ptr, ptr %l1, !tbaa !29
  %t419 = getelementptr %"compiler/build:Config", ptr %t417, i32 0, i32 6
  store i1 true, ptr %t419, !tbaa !21
  br label %bb86
bb85:
  br label %bb86
bb86:
  %t420 = load i64, ptr %l7, !tbaa !24
  %t422 = icmp eq i64 %t420, 3
  br i1 %t422, label %bb87, label %bb88
bb87:
  %t424 = load ptr, ptr %l1, !tbaa !29
  %t426 = getelementptr %"compiler/build:Config", ptr %t424, i32 0, i32 7
  store i1 true, ptr %t426, !tbaa !21
  br label %bb89
bb88:
  br label %bb89
bb89:
  %t427 = load i64, ptr %l7, !tbaa !24
  %t429 = icmp eq i64 %t427, 4
  br i1 %t429, label %bb90, label %bb91
bb90:
  %t431 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t433 = extractvalue { i64, ptr } %t431, 1
  %t434 = extractvalue { i64, ptr } %t431, 0
  %t435 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t434)
  call void @olang_textcopy(ptr %t435, ptr %t433, i64 %t434)
  %t436 = insertvalue { i64, ptr } undef, i64 %t434, 0
  %t437 = insertvalue { i64, ptr } %t436, ptr %t435, 1
  %t439 = extractvalue { i64, ptr } %t437, 0
  %t440 = extractvalue { i64, ptr } %t437, 1
  %t441 = mul i64 %t439, 1
  %t442 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t441)
  call void @llvm.memcpy.p0.p0.i64(ptr %t442, ptr %t440, i64 %t441, i1 false)
  %t443 = insertvalue { i64, ptr } undef, i64 %t439, 0
  %t444 = insertvalue { i64, ptr } %t443, ptr %t442, 1
  %t446 = load ptr, ptr %lp3
  %t447 = getelementptr %"compiler/olang:CommandLine", ptr %t446, i32 0, i32 6
  store { i64, ptr } %t444, ptr %t447, !tbaa !27
  br label %bb92
bb91:
  br label %bb92
bb92:
  %t448 = load i64, ptr %l7, !tbaa !24
  %t450 = icmp eq i64 %t448, 5
  br i1 %t450, label %bb93, label %bb94
bb93:
  %t452 = load ptr, ptr %l1, !tbaa !29
  %t454 = getelementptr %"compiler/build:Config", ptr %t452, i32 0, i32 3
  %t455 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t456 = load ptr, ptr %l2, !tbaa !29
  %t460 = call i32 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eDefine(ptr %v1, ptr %s5, ptr %v2, ptr %t454, { i64, ptr } %t455, ptr %t456)
  store i32 %t460, ptr %l172
  %t461 = icmp ne i32 %t460, 0
  br i1 %t461, label %bb96, label %ok.462
ok.462:
  br label %bb95
bb94:
  br label %bb101
bb95:
  br label %bb100
bb96:
  %t463 = load i32, ptr %l172, !tbaa !23
  %t464 = ashr i32 %t463, 16
  %t466 = icmp eq i32 %t464, 1
  br i1 %t466, label %bb97, label %bb98
bb97:
  br label %bb99
bb98:
  %t468 = load i32, ptr %l172, !tbaa !23
  %t469 = lshr i32 %t468, 16
  %t470 = and i32 %t468, 65535
  %t471 = icmp eq i32 %t469, 1
  %t472 = select i1 %t471, i32 0, i32 0
  %t473 = icmp eq i32 %t468, 0
  %t474 = shl i32 %t472, 16
  %t475 = or i32 %t474, %t470
  %t476 = select i1 %t473, i32 0, i32 %t475
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t478 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t476, 0
  store { i32, %"compiler/olang:CommandLine" } %t478, ptr %rv
  br label %ret
bb99:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t480 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/olang:CommandLine" } %t480, ptr %rv
  br label %ret
bb100:
  br label %bb101
bb101:
  %t481 = load i64, ptr %l7, !tbaa !24
  %t483 = icmp eq i64 %t481, 6
  br i1 %t483, label %bb102, label %bb103
bb102:
  %t485 = load ptr, ptr %l1, !tbaa !29
  %t487 = getelementptr %"compiler/build:Config", ptr %t485, i32 0, i32 10
  store i1 true, ptr %t487, !tbaa !21
  br label %bb104
bb103:
  br label %bb104
bb104:
  %t488 = load i64, ptr %l7, !tbaa !24
  %t490 = icmp eq i64 %t488, 7
  br i1 %t490, label %bb105, label %bb106
bb105:
  %t492 = load ptr, ptr %lp3
  %t493 = getelementptr %"compiler/olang:CommandLine", ptr %t492, i32 0, i32 8
  store i1 true, ptr %t493, !tbaa !21
  br label %bb107
bb106:
  br label %bb107
bb107:
  %t494 = load i64, ptr %l7, !tbaa !24
  %t496 = icmp eq i64 %t494, 8
  br i1 %t496, label %bb108, label %bb109
bb108:
  %t498 = load ptr, ptr %l1, !tbaa !29
  %t500 = getelementptr %"compiler/build:Config", ptr %t498, i32 0, i32 5
  store i1 true, ptr %t500, !tbaa !21
  br label %bb110
bb109:
  br label %bb110
bb110:
  %t501 = load i64, ptr %l7, !tbaa !24
  %t503 = icmp eq i64 %t501, 9
  br i1 %t503, label %bb111, label %bb112
bb111:
  %t505 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t507 = extractvalue { i64, ptr } %t505, 1
  %t508 = extractvalue { i64, ptr } %t505, 0
  %t509 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t508)
  call void @olang_textcopy(ptr %t509, ptr %t507, i64 %t508)
  %t510 = insertvalue { i64, ptr } undef, i64 %t508, 0
  %t511 = insertvalue { i64, ptr } %t510, ptr %t509, 1
  %t513 = extractvalue { i64, ptr } %t511, 0
  %t514 = extractvalue { i64, ptr } %t511, 1
  %t515 = mul i64 %t513, 1
  %t516 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t515)
  call void @llvm.memcpy.p0.p0.i64(ptr %t516, ptr %t514, i64 %t515, i1 false)
  %t517 = insertvalue { i64, ptr } undef, i64 %t513, 0
  %t518 = insertvalue { i64, ptr } %t517, ptr %t516, 1
  %t520 = load ptr, ptr %lp3
  %t521 = getelementptr %"compiler/olang:CommandLine", ptr %t520, i32 0, i32 9
  store { i64, ptr } %t518, ptr %t521, !tbaa !27
  br label %bb113
bb112:
  br label %bb113
bb113:
  %t522 = load i64, ptr %l7, !tbaa !24
  %t524 = icmp eq i64 %t522, 10
  br i1 %t524, label %bb114, label %bb115
bb114:
  %t526 = load ptr, ptr %l1, !tbaa !29
  %t528 = getelementptr %"compiler/build:Config", ptr %t526, i32 0, i32 9
  store i1 true, ptr %t528, !tbaa !21
  br label %bb116
bb115:
  br label %bb116
bb116:
  %t529 = load i64, ptr %l7, !tbaa !24
  %t531 = icmp eq i64 %t529, 11
  br i1 %t531, label %bb117, label %bb118
bb117:
  %t533 = load ptr, ptr %l1, !tbaa !29
  %t535 = getelementptr %"compiler/build:Config", ptr %t533, i32 0, i32 8
  store i1 true, ptr %t535, !tbaa !21
  br label %bb119
bb118:
  br label %bb119
bb119:
  %t536 = load ptr, ptr %l1, !tbaa !29
  %t538 = getelementptr %"compiler/build:Config", ptr %t536, i32 0, i32 5
  %t539 = load i1, ptr %t538, !tbaa !21
  br i1 %t539, label %bb120, label %bb121
bb120:
  %t541 = load ptr, ptr %l1, !tbaa !29
  %t543 = getelementptr %"compiler/build:Config", ptr %t541, i32 0, i32 4
  %t544 = load i1, ptr %t543, !tbaa !21
  br i1 %t544, label %bb122, label %bb123
bb121:
  store i1 false, ptr %l198, !tbaa !21
  br label %bb125
bb122:
  store i1 true, ptr %l201, !tbaa !21
  br label %bb124
bb123:
  %t546 = load ptr, ptr %l1, !tbaa !29
  %t548 = getelementptr %"compiler/build:Config", ptr %t546, i32 0, i32 6
  %t549 = load i1, ptr %t548, !tbaa !21
  store i1 %t549, ptr %l201, !tbaa !21
  br label %bb124
bb124:
  %t551 = load i1, ptr %l201, !tbaa !21
  store i1 %t551, ptr %l198, !tbaa !21
  br label %bb125
bb125:
  %t552 = load i1, ptr %l198, !tbaa !21
  br i1 %t552, label %bb126, label %bb127
bb126:
  store %olang.scope zeroinitializer, ptr %s33
  %t553 = load ptr, ptr %l2, !tbaa !29
  store ptr %t553, ptr %l204, !tbaa !29
  %t554 = load ptr, ptr %l1, !tbaa !29
  %t556 = getelementptr %"compiler/build:Config", ptr %t554, i32 0, i32 4
  %t557 = load i1, ptr %t556, !tbaa !21
  br i1 %t557, label %bb128, label %bb129
bb127:
  br label %bb135
bb128:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d79, i32 0, i32 1) }, ptr %l207, !tbaa !27
  br label %bb130
bb129:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d80, i32 0, i32 1) }, ptr %l207, !tbaa !27
  br label %bb130
bb130:
  %t559 = load { i64, ptr }, ptr %l207, !tbaa !27
  %t560 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eQuickAlone(ptr %s33, ptr %s33, { i64, ptr } %t559)
  store %"compiler/msgs:Msg" %t560, ptr %l208
  br label %bb131
bb131:
  %t561 = load ptr, ptr %l204, !tbaa !29
  %t562 = load %"compiler/msgs:Msg", ptr %l208
  %t563 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s33, ptr %t561, %"compiler/msgs:Msg" %t562)
  store i32 %t563, ptr %l209
  %t564 = icmp ne i32 %t563, 0
  br i1 %t564, label %bb133, label %ok.565
ok.565:
  br label %bb132
bb132:
  br label %bb134
bb133:
  %t566 = load i32, ptr %l209, !tbaa !23
  %t567 = lshr i32 %t566, 16
  %t568 = and i32 %t566, 65535
  %t569 = icmp eq i32 %t567, 1
  %t570 = select i1 %t569, i32 1, i32 0
  %t571 = icmp eq i32 %t566, 0
  %t572 = shl i32 %t570, 16
  %t573 = or i32 %t572, %t568
  %t574 = select i1 %t571, i32 0, i32 %t573
  call void @__olang_scope_close(ptr %s33)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t576 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t574, 0
  store { i32, %"compiler/olang:CommandLine" } %t576, ptr %rv
  br label %ret
bb134:
  call void @__olang_scope_close(ptr %s33)
  br label %bb135
bb135:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  br label %bb225
bb136:
  %t577 = load ptr, ptr %lp3
  %t578 = getelementptr %"compiler/olang:CommandLine", ptr %t577, i32 0, i32 0
  %t579 = load i64, ptr %t578, !tbaa !24
  %t580 = load i64, ptr @G_2ecompiler_2folang_2eDoc, !tbaa !24
  %t583 = icmp eq i64 %t579, %t580
  br i1 %t583, label %bb137, label %bb138
bb137:
  %t585 = load ptr, ptr %lp3
  %t586 = getelementptr %"compiler/olang:CommandLine", ptr %t585, i32 0, i32 9
  %t587 = load { i64, ptr }, ptr %t586, !tbaa !27
  %t589 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s4, { i64, ptr } %t587, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d81, i32 0, i32 1) })
  store i1 %t589, ptr %l216
  br label %bb139
bb138:
  store i1 false, ptr %l214, !tbaa !21
  br label %bb140
bb139:
  %t590 = load i1, ptr %l216, !tbaa !21
  store i1 %t590, ptr %l214, !tbaa !21
  br label %bb140
bb140:
  %t591 = load i1, ptr %l214, !tbaa !21
  br i1 %t591, label %bb141, label %bb142
bb141:
  %t592 = load ptr, ptr %lp3
  %t593 = getelementptr %"compiler/olang:CommandLine", ptr %t592, i32 0, i32 1
  %t595 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v3, ptr %t593)
  store i64 %t595, ptr %l219
  br label %bb143
bb142:
  store i1 false, ptr %l217, !tbaa !21
  br label %bb144
bb143:
  %t596 = load i64, ptr %l219, !tbaa !24
  %t597 = icmp eq i64 %t596, 1
  store i1 %t597, ptr %l217, !tbaa !21
  br label %bb144
bb144:
  %t599 = load i1, ptr %l217, !tbaa !21
  br i1 %t599, label %bb145, label %bb146
bb145:
  %t600 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t602 = call i1 @compiler_2folang_2eendsWithOlang(ptr %v0, { i64, ptr } %t600)
  store i1 %t602, ptr %l223
  br label %bb147
bb146:
  store i1 false, ptr %l221, !tbaa !21
  br label %bb148
bb147:
  %t603 = load i1, ptr %l223, !tbaa !21
  %t604 = xor i1 %t603, true
  store i1 %t604, ptr %l221, !tbaa !21
  br label %bb148
bb148:
  %t606 = load i1, ptr %l221, !tbaa !21
  br i1 %t606, label %bb149, label %bb150
bb149:
  %t607 = load ptr, ptr %lp3
  %t608 = getelementptr %"compiler/olang:CommandLine", ptr %t607, i32 0, i32 3
  %t609 = load i1, ptr %t608, !tbaa !21
  br i1 %t609, label %bb151, label %bb152
bb150:
  br label %bb159
bb151:
  store %olang.scope zeroinitializer, ptr %s35
  %t611 = load ptr, ptr %l2, !tbaa !29
  store ptr %t611, ptr %l226, !tbaa !29
  %t612 = load ptr, ptr %lp3
  %t613 = getelementptr %"compiler/olang:CommandLine", ptr %t612, i32 0, i32 1
  %t615 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v3, ptr %v3, ptr %t613, i64 0)
  store { i64, ptr } %t615, ptr %l228
  br label %bb153
bb152:
  br label %bb158
bb153:
  %t616 = load { i64, ptr }, ptr %l228, !tbaa !27
  %t617 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDocOneName(ptr %v3, ptr %s35, { i64, ptr } %t616)
  store %"compiler/msgs:Msg" %t617, ptr %l229
  br label %bb154
bb154:
  %t618 = load ptr, ptr %l226, !tbaa !29
  %t619 = load %"compiler/msgs:Msg", ptr %l229
  %t620 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s35, ptr %t618, %"compiler/msgs:Msg" %t619)
  store i32 %t620, ptr %l230
  %t621 = icmp ne i32 %t620, 0
  br i1 %t621, label %bb156, label %ok.622
ok.622:
  br label %bb155
bb155:
  br label %bb157
bb156:
  %t623 = load i32, ptr %l230, !tbaa !23
  %t624 = lshr i32 %t623, 16
  %t625 = and i32 %t623, 65535
  %t626 = icmp eq i32 %t624, 1
  %t627 = select i1 %t626, i32 1, i32 0
  %t628 = icmp eq i32 %t623, 0
  %t629 = shl i32 %t627, 16
  %t630 = or i32 %t629, %t625
  %t631 = select i1 %t628, i32 0, i32 %t630
  call void @__olang_scope_close(ptr %s35)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t633 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t631, 0
  store { i32, %"compiler/olang:CommandLine" } %t633, ptr %rv
  br label %ret
bb157:
  call void @__olang_scope_close(ptr %s35)
  br label %bb158
bb158:
  %t634 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t636 = extractvalue { i64, ptr } %t634, 1
  %t637 = extractvalue { i64, ptr } %t634, 0
  %t638 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t637)
  call void @olang_textcopy(ptr %t638, ptr %t636, i64 %t637)
  %t639 = insertvalue { i64, ptr } undef, i64 %t637, 0
  %t640 = insertvalue { i64, ptr } %t639, ptr %t638, 1
  %t642 = extractvalue { i64, ptr } %t640, 0
  %t643 = extractvalue { i64, ptr } %t640, 1
  %t644 = mul i64 %t642, 1
  %t645 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t644)
  call void @llvm.memcpy.p0.p0.i64(ptr %t645, ptr %t643, i64 %t644, i1 false)
  %t646 = insertvalue { i64, ptr } undef, i64 %t642, 0
  %t647 = insertvalue { i64, ptr } %t646, ptr %t645, 1
  %t649 = load ptr, ptr %lp3
  %t650 = getelementptr %"compiler/olang:CommandLine", ptr %t649, i32 0, i32 2
  store { i64, ptr } %t647, ptr %t650, !tbaa !27
  %t651 = load ptr, ptr %lp3
  %t652 = getelementptr %"compiler/olang:CommandLine", ptr %t651, i32 0, i32 3
  store i1 true, ptr %t652, !tbaa !21
  call void @__olang_scope_close(ptr %s4)
  br label %bb225
bb159:
  %t653 = load ptr, ptr %lp3
  %t654 = getelementptr %"compiler/olang:CommandLine", ptr %t653, i32 0, i32 0
  %t655 = load i64, ptr %t654, !tbaa !24
  %t656 = load i64, ptr @G_2ecompiler_2folang_2eExplain, !tbaa !24
  %t659 = icmp eq i64 %t655, %t656
  br i1 %t659, label %bb160, label %bb161
bb160:
  store i1 true, ptr %l238, !tbaa !21
  br label %bb162
bb161:
  %t661 = load ptr, ptr %lp3
  %t662 = getelementptr %"compiler/olang:CommandLine", ptr %t661, i32 0, i32 0
  %t663 = load i64, ptr %t662, !tbaa !24
  %t664 = load i64, ptr @G_2ecompiler_2folang_2eHelp, !tbaa !24
  %t667 = icmp eq i64 %t663, %t664
  store i1 %t667, ptr %l238, !tbaa !21
  br label %bb162
bb162:
  %t669 = load i1, ptr %l238, !tbaa !21
  br i1 %t669, label %bb163, label %bb164
bb163:
  %t670 = load ptr, ptr %lp3
  %t671 = getelementptr %"compiler/olang:CommandLine", ptr %t670, i32 0, i32 0
  %t672 = load i64, ptr %t671, !tbaa !24
  %t673 = load i64, ptr @G_2ecompiler_2folang_2eExplain, !tbaa !24
  %t676 = icmp eq i64 %t672, %t673
  br i1 %t676, label %bb165, label %bb166
bb164:
  br label %bb191
bb165:
  %t678 = load ptr, ptr %lp3
  %t679 = getelementptr %"compiler/olang:CommandLine", ptr %t678, i32 0, i32 3
  %t680 = load i1, ptr %t679, !tbaa !21
  store i1 %t680, ptr %l245, !tbaa !21
  br label %bb167
bb166:
  store i1 false, ptr %l245, !tbaa !21
  br label %bb167
bb167:
  %t682 = load i1, ptr %l245, !tbaa !21
  br i1 %t682, label %bb168, label %bb169
bb168:
  %t683 = load ptr, ptr %lp3
  %t684 = getelementptr %"compiler/olang:CommandLine", ptr %t683, i32 0, i32 1
  %t686 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v3, ptr %t684)
  store i64 %t686, ptr %l249
  br label %bb170
bb169:
  store i1 false, ptr %l247, !tbaa !21
  br label %bb171
bb170:
  %t687 = load i64, ptr %l249, !tbaa !24
  %t688 = icmp eq i64 %t687, 0
  store i1 %t688, ptr %l247, !tbaa !21
  br label %bb171
bb171:
  %t690 = load i1, ptr %l247, !tbaa !21
  br i1 %t690, label %bb172, label %bb173
bb172:
  %t691 = load ptr, ptr %lp3
  %t692 = getelementptr %"compiler/olang:CommandLine", ptr %t691, i32 0, i32 2
  %t693 = load { i64, ptr }, ptr %t692, !tbaa !27
  %t695 = call i1 @compiler_2folang_2eendsWithOlang(ptr %v3, { i64, ptr } %t693)
  store i1 %t695, ptr %l253
  br label %bb174
bb173:
  store i1 false, ptr %l251, !tbaa !21
  br label %bb175
bb174:
  %t696 = load i1, ptr %l253, !tbaa !21
  store i1 %t696, ptr %l251, !tbaa !21
  br label %bb175
bb175:
  %t697 = load i1, ptr %l251, !tbaa !21
  br i1 %t697, label %bb176, label %bb177
bb176:
  %t698 = load ptr, ptr %lp3
  %t699 = getelementptr %"compiler/olang:CommandLine", ptr %t698, i32 0, i32 1
  %t700 = load ptr, ptr %lp3
  %t701 = getelementptr %"compiler/olang:CommandLine", ptr %t700, i32 0, i32 2
  %t702 = load { i64, ptr }, ptr %t701, !tbaa !27
  %t704 = extractvalue { i64, ptr } %t702, 1
  %t705 = extractvalue { i64, ptr } %t702, 0
  %t706 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t705)
  call void @olang_textcopy(ptr %t706, ptr %t704, i64 %t705)
  %t707 = insertvalue { i64, ptr } undef, i64 %t705, 0
  %t708 = insertvalue { i64, ptr } %t707, ptr %t706, 1
  %t710 = extractvalue { i64, ptr } %t708, 0
  %t711 = extractvalue { i64, ptr } %t708, 1
  %t712 = mul i64 %t710, 1
  %t713 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t712)
  call void @llvm.memcpy.p0.p0.i64(ptr %t713, ptr %t711, i64 %t712, i1 false)
  %t714 = insertvalue { i64, ptr } undef, i64 %t710, 0
  %t715 = insertvalue { i64, ptr } %t714, ptr %t713, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v3, ptr %v3, ptr %t699, { i64, ptr } %t715)
  br label %bb178
bb177:
  br label %bb179
bb178:
  %t718 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t720 = extractvalue { i64, ptr } %t718, 1
  %t721 = extractvalue { i64, ptr } %t718, 0
  %t722 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t721)
  call void @olang_textcopy(ptr %t722, ptr %t720, i64 %t721)
  %t723 = insertvalue { i64, ptr } undef, i64 %t721, 0
  %t724 = insertvalue { i64, ptr } %t723, ptr %t722, 1
  %t726 = extractvalue { i64, ptr } %t724, 0
  %t727 = extractvalue { i64, ptr } %t724, 1
  %t728 = mul i64 %t726, 1
  %t729 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t728)
  call void @llvm.memcpy.p0.p0.i64(ptr %t729, ptr %t727, i64 %t728, i1 false)
  %t730 = insertvalue { i64, ptr } undef, i64 %t726, 0
  %t731 = insertvalue { i64, ptr } %t730, ptr %t729, 1
  %t733 = load ptr, ptr %lp3
  %t734 = getelementptr %"compiler/olang:CommandLine", ptr %t733, i32 0, i32 2
  store { i64, ptr } %t731, ptr %t734, !tbaa !27
  call void @__olang_scope_close(ptr %s4)
  br label %bb225
bb179:
  %t735 = load ptr, ptr %lp3
  %t736 = getelementptr %"compiler/olang:CommandLine", ptr %t735, i32 0, i32 3
  %t737 = load i1, ptr %t736, !tbaa !21
  br i1 %t737, label %bb180, label %bb181
bb180:
  store %olang.scope zeroinitializer, ptr %s41
  %t739 = load ptr, ptr %l2, !tbaa !29
  store ptr %t739, ptr %l262, !tbaa !29
  %t740 = load ptr, ptr %lp3
  %t741 = getelementptr %"compiler/olang:CommandLine", ptr %t740, i32 0, i32 0
  %t742 = load i64, ptr %t741, !tbaa !24
  %t743 = load i64, ptr @G_2ecompiler_2folang_2eExplain, !tbaa !24
  %t746 = icmp eq i64 %t742, %t743
  br i1 %t746, label %bb182, label %bb183
bb181:
  br label %bb190
bb182:
  %t748 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eExplainNeedsRule(ptr %s41)
  store %"compiler/msgs:Msg" %t748, ptr %l267
  br label %bb184
bb183:
  %t749 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eHelpOneMode(ptr %s41)
  store %"compiler/msgs:Msg" %t749, ptr %l268
  br label %bb185
bb184:
  %t750 = load %"compiler/msgs:Msg", ptr %l267
  store %"compiler/msgs:Msg" %t750, ptr %l266
  br label %bb186
bb185:
  %t751 = load %"compiler/msgs:Msg", ptr %l268
  store %"compiler/msgs:Msg" %t751, ptr %l266
  br label %bb186
bb186:
  %t752 = load ptr, ptr %l262, !tbaa !29
  %t753 = load %"compiler/msgs:Msg", ptr %l266
  %t754 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s41, ptr %t752, %"compiler/msgs:Msg" %t753)
  store i32 %t754, ptr %l269
  %t755 = icmp ne i32 %t754, 0
  br i1 %t755, label %bb188, label %ok.756
ok.756:
  br label %bb187
bb187:
  br label %bb189
bb188:
  %t757 = load i32, ptr %l269, !tbaa !23
  %t758 = lshr i32 %t757, 16
  %t759 = and i32 %t757, 65535
  %t760 = icmp eq i32 %t758, 1
  %t761 = select i1 %t760, i32 1, i32 0
  %t762 = icmp eq i32 %t757, 0
  %t763 = shl i32 %t761, 16
  %t764 = or i32 %t763, %t759
  %t765 = select i1 %t762, i32 0, i32 %t764
  call void @__olang_scope_close(ptr %s41)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t767 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t765, 0
  store { i32, %"compiler/olang:CommandLine" } %t767, ptr %rv
  br label %ret
bb189:
  call void @__olang_scope_close(ptr %s41)
  br label %bb190
bb190:
  %t768 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t770 = extractvalue { i64, ptr } %t768, 1
  %t771 = extractvalue { i64, ptr } %t768, 0
  %t772 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t771)
  call void @olang_textcopy(ptr %t772, ptr %t770, i64 %t771)
  %t773 = insertvalue { i64, ptr } undef, i64 %t771, 0
  %t774 = insertvalue { i64, ptr } %t773, ptr %t772, 1
  %t776 = extractvalue { i64, ptr } %t774, 0
  %t777 = extractvalue { i64, ptr } %t774, 1
  %t778 = mul i64 %t776, 1
  %t779 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t778)
  call void @llvm.memcpy.p0.p0.i64(ptr %t779, ptr %t777, i64 %t778, i1 false)
  %t780 = insertvalue { i64, ptr } undef, i64 %t776, 0
  %t781 = insertvalue { i64, ptr } %t780, ptr %t779, 1
  %t783 = load ptr, ptr %lp3
  %t784 = getelementptr %"compiler/olang:CommandLine", ptr %t783, i32 0, i32 2
  store { i64, ptr } %t781, ptr %t784, !tbaa !27
  %t785 = load ptr, ptr %lp3
  %t786 = getelementptr %"compiler/olang:CommandLine", ptr %t785, i32 0, i32 3
  store i1 true, ptr %t786, !tbaa !21
  call void @__olang_scope_close(ptr %s4)
  br label %bb225
bb191:
  %t787 = load ptr, ptr %lp3
  %t788 = getelementptr %"compiler/olang:CommandLine", ptr %t787, i32 0, i32 0
  %t789 = load i64, ptr %t788, !tbaa !24
  %t790 = load i64, ptr @G_2ecompiler_2folang_2eRun, !tbaa !24
  %t793 = icmp eq i64 %t789, %t790
  br i1 %t793, label %bb192, label %bb193
bb192:
  %t795 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t797 = call i1 @compiler_2folang_2eendsWithOlang(ptr %v0, { i64, ptr } %t795)
  store i1 %t797, ptr %l279
  br label %bb194
bb193:
  store i1 false, ptr %l277, !tbaa !21
  br label %bb195
bb194:
  %t798 = load i1, ptr %l279, !tbaa !21
  %t799 = xor i1 %t798, true
  store i1 %t799, ptr %l277, !tbaa !21
  br label %bb195
bb195:
  %t801 = load i1, ptr %l277, !tbaa !21
  br i1 %t801, label %bb196, label %bb197
bb196:
  store %olang.scope zeroinitializer, ptr %s43
  %t802 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t804 = call i64 @compiler_2folang_2emodeNumber(ptr %v0, { i64, ptr } %t802)
  store i64 %t804, ptr %l282
  br label %bb198
bb197:
  br label %bb210
bb198:
  %t805 = load i64, ptr %l282, !tbaa !24
  %t806 = icmp sgt i64 %t805, 0
  br i1 %t806, label %bb199, label %bb200
bb199:
  store %olang.scope zeroinitializer, ptr %s44
  %t808 = load ptr, ptr %l2, !tbaa !29
  store ptr %t808, ptr %l284, !tbaa !29
  %t809 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t811 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eModeFirst(ptr %v0, ptr %s44, { i64, ptr } %t809)
  store %"compiler/msgs:Msg" %t811, ptr %l286
  br label %bb201
bb200:
  br label %bb205
bb201:
  %t812 = load ptr, ptr %l284, !tbaa !29
  %t813 = load %"compiler/msgs:Msg", ptr %l286
  %t814 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s44, ptr %t812, %"compiler/msgs:Msg" %t813)
  store i32 %t814, ptr %l287
  %t815 = icmp ne i32 %t814, 0
  br i1 %t815, label %bb203, label %ok.816
ok.816:
  br label %bb202
bb202:
  br label %bb204
bb203:
  %t817 = load i32, ptr %l287, !tbaa !23
  %t818 = lshr i32 %t817, 16
  %t819 = and i32 %t817, 65535
  %t820 = icmp eq i32 %t818, 1
  %t821 = select i1 %t820, i32 1, i32 0
  %t822 = icmp eq i32 %t817, 0
  %t823 = shl i32 %t821, 16
  %t824 = or i32 %t823, %t819
  %t825 = select i1 %t822, i32 0, i32 %t824
  call void @__olang_scope_close(ptr %s44)
  call void @__olang_scope_close(ptr %s43)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t827 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t825, 0
  store { i32, %"compiler/olang:CommandLine" } %t827, ptr %rv
  br label %ret
bb204:
  call void @__olang_scope_close(ptr %s44)
  br label %bb205
bb205:
  %t828 = load ptr, ptr %l2, !tbaa !29
  store ptr %t828, ptr %l289, !tbaa !29
  %t829 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t831 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotASource(ptr %v0, ptr %s43, { i64, ptr } %t829)
  store %"compiler/msgs:Msg" %t831, ptr %l291
  br label %bb206
bb206:
  %t832 = load ptr, ptr %l289, !tbaa !29
  %t833 = load %"compiler/msgs:Msg", ptr %l291
  %t834 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s43, ptr %t832, %"compiler/msgs:Msg" %t833)
  store i32 %t834, ptr %l292
  %t835 = icmp ne i32 %t834, 0
  br i1 %t835, label %bb208, label %ok.836
ok.836:
  br label %bb207
bb207:
  br label %bb209
bb208:
  %t837 = load i32, ptr %l292, !tbaa !23
  %t838 = lshr i32 %t837, 16
  %t839 = and i32 %t837, 65535
  %t840 = icmp eq i32 %t838, 1
  %t841 = select i1 %t840, i32 1, i32 0
  %t842 = icmp eq i32 %t837, 0
  %t843 = shl i32 %t841, 16
  %t844 = or i32 %t843, %t839
  %t845 = select i1 %t842, i32 0, i32 %t844
  call void @__olang_scope_close(ptr %s43)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t847 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t845, 0
  store { i32, %"compiler/olang:CommandLine" } %t847, ptr %rv
  br label %ret
bb209:
  call void @__olang_scope_close(ptr %s43)
  br label %bb210
bb210:
  %t848 = load ptr, ptr %lp3
  %t849 = getelementptr %"compiler/olang:CommandLine", ptr %t848, i32 0, i32 1
  %t850 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t852 = extractvalue { i64, ptr } %t850, 1
  %t853 = extractvalue { i64, ptr } %t850, 0
  %t854 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t853)
  call void @olang_textcopy(ptr %t854, ptr %t852, i64 %t853)
  %t855 = insertvalue { i64, ptr } undef, i64 %t853, 0
  %t856 = insertvalue { i64, ptr } %t855, ptr %t854, 1
  %t858 = extractvalue { i64, ptr } %t856, 0
  %t859 = extractvalue { i64, ptr } %t856, 1
  %t860 = mul i64 %t858, 1
  %t861 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t860)
  call void @llvm.memcpy.p0.p0.i64(ptr %t861, ptr %t859, i64 %t860, i1 false)
  %t862 = insertvalue { i64, ptr } undef, i64 %t858, 0
  %t863 = insertvalue { i64, ptr } %t862, ptr %t861, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v3, ptr %v3, ptr %t849, { i64, ptr } %t863)
  br label %bb211
bb211:
  %t866 = load ptr, ptr %lp3
  %t867 = getelementptr %"compiler/olang:CommandLine", ptr %t866, i32 0, i32 0
  %t868 = load i64, ptr %t867, !tbaa !24
  %t869 = load i64, ptr @G_2ecompiler_2folang_2eRun, !tbaa !24
  %t872 = icmp eq i64 %t868, %t869
  br i1 %t872, label %bb212, label %bb213
bb212:
  store i1 true, ptr %l301, !tbaa !21
  br label %bb214
bb213:
  %t874 = load ptr, ptr %lp3
  %t875 = getelementptr %"compiler/olang:CommandLine", ptr %t874, i32 0, i32 0
  %t876 = load i64, ptr %t875, !tbaa !24
  %t877 = load i64, ptr @G_2ecompiler_2folang_2eInterp, !tbaa !24
  %t880 = icmp eq i64 %t876, %t877
  store i1 %t880, ptr %l301, !tbaa !21
  br label %bb214
bb214:
  %t882 = load i1, ptr %l301, !tbaa !21
  br i1 %t882, label %bb215, label %bb216
bb215:
  br label %bb217
bb216:
  br label %bb224
bb217:
  store %olang.scope zeroinitializer, ptr %s47
  %t883 = load i64, ptr %l4, !tbaa !24
  %t884 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t886 = extractvalue { i64, ptr } %t884, 0
  %t889 = icmp slt i64 %t883, %t886
  %t891 = xor i1 %t889, true
  br i1 %t891, label %bb218, label %bb219
bb218:
  call void @__olang_scope_close(ptr %s47)
  br label %bb223
bb219:
  br label %bb220
bb220:
  %t893 = load ptr, ptr %lp3
  %t894 = getelementptr %"compiler/olang:CommandLine", ptr %t893, i32 0, i32 4
  %t895 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t895, ptr %l311, !tbaa !27
  %t896 = load i64, ptr %l4, !tbaa !24
  %t898 = getelementptr { i64, ptr }, ptr %l311, i32 0, i32 1
  %t899 = load ptr, ptr %t898, !tbaa !27
  %t900 = getelementptr { i64, ptr }, ptr %t899, i64 %t896
  %t901 = load { i64, ptr }, ptr %t900, !tbaa !37
  %t903 = extractvalue { i64, ptr } %t901, 1
  %t904 = extractvalue { i64, ptr } %t901, 0
  %t905 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t904)
  call void @olang_textcopy(ptr %t905, ptr %t903, i64 %t904)
  %t906 = insertvalue { i64, ptr } undef, i64 %t904, 0
  %t907 = insertvalue { i64, ptr } %t906, ptr %t905, 1
  %t909 = extractvalue { i64, ptr } %t907, 0
  %t910 = extractvalue { i64, ptr } %t907, 1
  %t911 = mul i64 %t909, 1
  %t912 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t911)
  call void @llvm.memcpy.p0.p0.i64(ptr %t912, ptr %t910, i64 %t911, i1 false)
  %t913 = insertvalue { i64, ptr } undef, i64 %t909, 0
  %t914 = insertvalue { i64, ptr } %t913, ptr %t912, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v3, ptr %v3, ptr %t894, { i64, ptr } %t914)
  br label %bb221
bb221:
  %t917 = load i64, ptr %l4, !tbaa !24
  %t919 = add i64 %t917, 1
  store i64 %t919, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s47)
  br label %bb222
bb222:
  br label %bb217
bb223:
  br label %bb224
bb224:
  call void @__olang_scope_close(ptr %s4)
  br label %bb225
bb225:
  br label %bb25
bb226:
  %t921 = load ptr, ptr %lp3
  %t922 = load %"compiler/olang:CommandLine", ptr %t921
  call void @__olang_scope_close(ptr %s0)
  %t924 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, %"compiler/olang:CommandLine" %t922, 1
  store { i32, %"compiler/olang:CommandLine" } %t924, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/olang:CommandLine" }, ptr %rv
  ret { i32, %"compiler/olang:CommandLine" } %rr
}

define dso_local { i32, %"compiler/olang:CommandLine" } @compiler_2folang_2ePrepare(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %lp3 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca i1
  %l6 = alloca %"compiler/olang:CommandLine"
  %l10 = alloca %"compiler/olang:CommandLine"
  %l11 = alloca i32
  %l22 = alloca ptr
  %l23 = alloca %"compiler/msgs:Msg"
  %l24 = alloca i32
  %l27 = alloca i64
  %l30 = alloca i1
  %l31 = alloca ptr
  %l33 = alloca %"compiler/msgs:Msg"
  %l34 = alloca i32
  %l40 = alloca i1
  %l44 = alloca i1
  %l46 = alloca i64
  %l48 = alloca ptr
  %l50 = alloca { i64, ptr }
  %l52 = alloca %"compiler/msgs:Msg"
  %l53 = alloca i32
  %l58 = alloca i1
  %l60 = alloca i1
  %l61 = alloca i1
  %l63 = alloca i64
  %l65 = alloca ptr
  %l67 = alloca i64
  %l69 = alloca %"compiler/msgs:Msg"
  %l71 = alloca { i64, ptr }
  %l73 = alloca %"compiler/msgs:Msg"
  %l75 = alloca { i64, ptr }
  %l77 = alloca %"compiler/msgs:Msg"
  %l78 = alloca i32
  %l81 = alloca i64
  %l83 = alloca i1
  %l87 = alloca i1
  %l91 = alloca i1
  %l95 = alloca ptr
  %l97 = alloca { i64, ptr }
  %l99 = alloca %"compiler/msgs:Msg"
  %l100 = alloca i32
  %l105 = alloca i1
  %l109 = alloca i1
  %l113 = alloca i1
  %l115 = alloca i64
  %l117 = alloca ptr
  %l119 = alloca { i64, ptr }
  %l121 = alloca %"compiler/msgs:Msg"
  %l122 = alloca i32
  %l127 = alloca i1
  %l133 = alloca i1
  %l137 = alloca i32
  %l147 = alloca ptr
  %l148 = alloca { i64, ptr }
  %l150 = alloca ptr
  %l151 = alloca { i64, ptr }
  %l152 = alloca { i64, ptr }
  %l153 = alloca i32
  %l154 = alloca { i64, ptr }
  %l160 = alloca i1
  %l164 = alloca i1
  %l168 = alloca ptr
  %l169 = alloca %"compiler/target:Target"
  %l170 = alloca { i64, ptr }
  %l172 = alloca { i64, ptr }
  %l176 = alloca i1
  %l178 = alloca i1
  %l181 = alloca i1
  %l183 = alloca %"compiler/target:Target"
  %l184 = alloca i32
  %l192 = alloca i1
  %l196 = alloca i1
  %l200 = alloca i1
  %l206 = alloca i1
  %l209 = alloca ptr
  %l211 = alloca { i64, ptr }
  %l214 = alloca %"compiler/msgs:Msg"
  %l215 = alloca i32
  %l221 = alloca ptr
  %l224 = alloca i1
  %l228 = alloca i1
  %l233 = alloca i32
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %rv = alloca { i32, %"compiler/olang:CommandLine" }
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t7 = call { i32, %"compiler/olang:CommandLine" } @compiler_2folang_2eParse(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, ptr %t2, ptr %t3)
  %t8 = extractvalue { i32, %"compiler/olang:CommandLine" } %t7, 1
  %t9 = extractvalue { i32, %"compiler/olang:CommandLine" } %t7, 0
  store i32 %t9, ptr %l11
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11
ok.11:
  store %"compiler/olang:CommandLine" %t8, ptr %l10
  br label %bb1
bb1:
  %t12 = load %"compiler/olang:CommandLine", ptr %l10
  store %"compiler/olang:CommandLine" %t12, ptr %l6
  br label %bb3
bb2:
  %t13 = load i32, ptr %l11, !tbaa !23
  %t14 = lshr i32 %t13, 16
  %t15 = and i32 %t13, 65535
  %t16 = icmp eq i32 %t14, 1
  %t17 = select i1 %t16, i32 1, i32 0
  %t18 = icmp eq i32 %t13, 0
  %t19 = shl i32 %t17, 16
  %t20 = or i32 %t19, %t15
  %t21 = select i1 %t18, i32 0, i32 %t20
  call void @__olang_scope_close(ptr %s0)
  %t23 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t21, 0
  store { i32, %"compiler/olang:CommandLine" } %t23, ptr %rv
  br label %ret
bb3:
  %t24 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 112, i64 8)
  store ptr %t24, ptr %lp3
  %t25 = load %"compiler/olang:CommandLine", ptr %l6
  %t26 = load ptr, ptr %lp3
  store %"compiler/olang:CommandLine" %t25, ptr %t26
  %t27 = load ptr, ptr %lp3
  %t28 = getelementptr %"compiler/olang:CommandLine", ptr %t27, i32 0, i32 0
  %t29 = load i64, ptr %t28, !tbaa !24
  %t30 = load i64, ptr @G_2ecompiler_2folang_2eHelp, !tbaa !24
  %t33 = icmp eq i64 %t29, %t30
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = load ptr, ptr %lp3
  %t36 = load %"compiler/olang:CommandLine", ptr %t35
  call void @__olang_scope_close(ptr %s0)
  %t38 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, %"compiler/olang:CommandLine" %t36, 1
  store { i32, %"compiler/olang:CommandLine" } %t38, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t39 = load ptr, ptr %lp3
  %t40 = getelementptr %"compiler/olang:CommandLine", ptr %t39, i32 0, i32 0
  %t41 = load i64, ptr %t40, !tbaa !24
  %t42 = load i64, ptr @G_2ecompiler_2folang_2eExplain, !tbaa !24
  %t45 = icmp eq i64 %t41, %t42
  br i1 %t45, label %bb7, label %bb8
bb7:
  %t47 = load ptr, ptr %lp3
  %t48 = getelementptr %"compiler/olang:CommandLine", ptr %t47, i32 0, i32 3
  %t49 = load i1, ptr %t48, !tbaa !21
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb9, label %bb10
bb8:
  br label %bb28
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t53 = load ptr, ptr %l2, !tbaa !29
  store ptr %t53, ptr %l22, !tbaa !29
  %t54 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eExplainNeedsRule(ptr %s3)
  store %"compiler/msgs:Msg" %t54, ptr %l23
  br label %bb11
bb10:
  br label %bb15
bb11:
  %t55 = load ptr, ptr %l22, !tbaa !29
  %t56 = load %"compiler/msgs:Msg", ptr %l23
  %t57 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s3, ptr %t55, %"compiler/msgs:Msg" %t56)
  store i32 %t57, ptr %l24
  %t58 = icmp ne i32 %t57, 0
  br i1 %t58, label %bb13, label %ok.59
ok.59:
  br label %bb12
bb12:
  br label %bb14
bb13:
  %t60 = load i32, ptr %l24, !tbaa !23
  %t61 = lshr i32 %t60, 16
  %t62 = and i32 %t60, 65535
  %t63 = icmp eq i32 %t61, 1
  %t64 = select i1 %t63, i32 1, i32 0
  %t65 = icmp eq i32 %t60, 0
  %t66 = shl i32 %t64, 16
  %t67 = or i32 %t66, %t62
  %t68 = select i1 %t65, i32 0, i32 %t67
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t70 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t68, 0
  store { i32, %"compiler/olang:CommandLine" } %t70, ptr %rv
  br label %ret
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb15:
  %t71 = load ptr, ptr %lp3
  %t72 = getelementptr %"compiler/olang:CommandLine", ptr %t71, i32 0, i32 1
  %t74 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v3, ptr %t72)
  store i64 %t74, ptr %l27
  br label %bb16
bb16:
  %t75 = load i64, ptr %l27, !tbaa !24
  %t76 = icmp eq i64 %t75, 0
  br i1 %t76, label %bb17, label %bb18
bb17:
  %t78 = load ptr, ptr %lp3
  %t79 = getelementptr %"compiler/olang:CommandLine", ptr %t78, i32 0, i32 2
  %t80 = load { i64, ptr }, ptr %t79, !tbaa !27
  %t82 = call i1 @compiler_2folang_2eendsWithOlang(ptr %v3, { i64, ptr } %t80)
  store i1 %t82, ptr %l30
  br label %bb19
bb18:
  br label %bb27
bb19:
  %t83 = load i1, ptr %l30, !tbaa !21
  br i1 %t83, label %bb20, label %bb21
bb20:
  store %olang.scope zeroinitializer, ptr %s5
  %t84 = load ptr, ptr %l2, !tbaa !29
  store ptr %t84, ptr %l31, !tbaa !29
  %t85 = load ptr, ptr %lp3
  %t86 = getelementptr %"compiler/olang:CommandLine", ptr %t85, i32 0, i32 2
  %t87 = load { i64, ptr }, ptr %t86, !tbaa !27
  %t89 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eExplainNeedsName(ptr %v3, ptr %s5, { i64, ptr } %t87)
  store %"compiler/msgs:Msg" %t89, ptr %l33
  br label %bb22
bb21:
  br label %bb26
bb22:
  %t90 = load ptr, ptr %l31, !tbaa !29
  %t91 = load %"compiler/msgs:Msg", ptr %l33
  %t92 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s5, ptr %t90, %"compiler/msgs:Msg" %t91)
  store i32 %t92, ptr %l34
  %t93 = icmp ne i32 %t92, 0
  br i1 %t93, label %bb24, label %ok.94
ok.94:
  br label %bb23
bb23:
  br label %bb25
bb24:
  %t95 = load i32, ptr %l34, !tbaa !23
  %t96 = lshr i32 %t95, 16
  %t97 = and i32 %t95, 65535
  %t98 = icmp eq i32 %t96, 1
  %t99 = select i1 %t98, i32 1, i32 0
  %t100 = icmp eq i32 %t95, 0
  %t101 = shl i32 %t99, 16
  %t102 = or i32 %t101, %t97
  %t103 = select i1 %t100, i32 0, i32 %t102
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t105 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t103, 0
  store { i32, %"compiler/olang:CommandLine" } %t105, ptr %rv
  br label %ret
bb25:
  call void @__olang_scope_close(ptr %s5)
  br label %bb26
bb26:
  %t106 = load ptr, ptr %lp3
  %t107 = load %"compiler/olang:CommandLine", ptr %t106
  call void @__olang_scope_close(ptr %s0)
  %t109 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, %"compiler/olang:CommandLine" %t107, 1
  store { i32, %"compiler/olang:CommandLine" } %t109, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t110 = load ptr, ptr %lp3
  %t111 = getelementptr %"compiler/olang:CommandLine", ptr %t110, i32 0, i32 0
  %t112 = load i64, ptr %t111, !tbaa !24
  %t113 = load i64, ptr @G_2ecompiler_2folang_2eLsp, !tbaa !24
  %t116 = icmp eq i64 %t112, %t113
  br i1 %t116, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb31
bb30:
  %t118 = load ptr, ptr %lp3
  %t119 = getelementptr %"compiler/olang:CommandLine", ptr %t118, i32 0, i32 0
  %t120 = load i64, ptr %t119, !tbaa !24
  %t121 = load i64, ptr @G_2ecompiler_2folang_2eMcp, !tbaa !24
  %t124 = icmp eq i64 %t120, %t121
  store i1 %t124, ptr %l40, !tbaa !21
  br label %bb31
bb31:
  %t126 = load i1, ptr %l40, !tbaa !21
  br i1 %t126, label %bb32, label %bb33
bb32:
  %t127 = load ptr, ptr %lp3
  %t128 = getelementptr %"compiler/olang:CommandLine", ptr %t127, i32 0, i32 1
  %t130 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v3, ptr %t128)
  store i64 %t130, ptr %l46
  br label %bb34
bb33:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb35
bb34:
  %t131 = load i64, ptr %l46, !tbaa !24
  %t132 = icmp sgt i64 %t131, 0
  store i1 %t132, ptr %l44, !tbaa !21
  br label %bb35
bb35:
  %t134 = load i1, ptr %l44, !tbaa !21
  br i1 %t134, label %bb36, label %bb37
bb36:
  store %olang.scope zeroinitializer, ptr %s6
  %t135 = load ptr, ptr %l2, !tbaa !29
  store ptr %t135, ptr %l48, !tbaa !29
  %t136 = load ptr, ptr %lp3
  %t137 = getelementptr %"compiler/olang:CommandLine", ptr %t136, i32 0, i32 0
  %t138 = load i64, ptr %t137, !tbaa !24
  %t140 = call { i64, ptr } @compiler_2folang_2emodeName(ptr %s6, i64 %t138)
  store { i64, ptr } %t140, ptr %l50
  br label %bb38
bb37:
  br label %bb43
bb38:
  %t141 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t141, 0
  %t143 = extractvalue { i64, ptr } %t141, 1
  %t144 = mul i64 %t142, 1
  %t145 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t144)
  call void @llvm.memcpy.p0.p0.i64(ptr %t145, ptr %t143, i64 %t144, i1 false)
  %t146 = insertvalue { i64, ptr } undef, i64 %t142, 0
  %t147 = insertvalue { i64, ptr } %t146, ptr %t145, 1
  %t149 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eModeNoFiles(ptr %s6, ptr %s6, { i64, ptr } %t147)
  store %"compiler/msgs:Msg" %t149, ptr %l52
  br label %bb39
bb39:
  %t150 = load ptr, ptr %l48, !tbaa !29
  %t151 = load %"compiler/msgs:Msg", ptr %l52
  %t152 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s6, ptr %t150, %"compiler/msgs:Msg" %t151)
  store i32 %t152, ptr %l53
  %t153 = icmp ne i32 %t152, 0
  br i1 %t153, label %bb41, label %ok.154
ok.154:
  br label %bb40
bb40:
  br label %bb42
bb41:
  %t155 = load i32, ptr %l53, !tbaa !23
  %t156 = lshr i32 %t155, 16
  %t157 = and i32 %t155, 65535
  %t158 = icmp eq i32 %t156, 1
  %t159 = select i1 %t158, i32 1, i32 0
  %t160 = icmp eq i32 %t155, 0
  %t161 = shl i32 %t159, 16
  %t162 = or i32 %t161, %t157
  %t163 = select i1 %t160, i32 0, i32 %t162
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t165 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t163, 0
  store { i32, %"compiler/olang:CommandLine" } %t165, ptr %rv
  br label %ret
bb42:
  call void @__olang_scope_close(ptr %s6)
  br label %bb43
bb43:
  %t166 = load ptr, ptr %lp3
  %t167 = getelementptr %"compiler/olang:CommandLine", ptr %t166, i32 0, i32 0
  %t168 = load i64, ptr %t167, !tbaa !24
  %t169 = load i64, ptr @G_2ecompiler_2folang_2eDoc, !tbaa !24
  %t172 = icmp eq i64 %t168, %t169
  br i1 %t172, label %bb44, label %bb45
bb44:
  %t174 = load ptr, ptr %lp3
  %t175 = getelementptr %"compiler/olang:CommandLine", ptr %t174, i32 0, i32 9
  %t176 = load { i64, ptr }, ptr %t175, !tbaa !27
  %t178 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s0, { i64, ptr } %t176, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d82, i32 0, i32 1) })
  store i1 %t178, ptr %l60
  br label %bb46
bb45:
  store i1 false, ptr %l58, !tbaa !21
  br label %bb47
bb46:
  %t179 = load i1, ptr %l60, !tbaa !21
  store i1 %t179, ptr %l58, !tbaa !21
  br label %bb47
bb47:
  %t180 = load i1, ptr %l58, !tbaa !21
  br i1 %t180, label %bb48, label %bb49
bb48:
  %t181 = load ptr, ptr %lp3
  %t182 = getelementptr %"compiler/olang:CommandLine", ptr %t181, i32 0, i32 1
  %t184 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v3, ptr %t182)
  store i64 %t184, ptr %l63
  br label %bb50
bb49:
  store i1 false, ptr %l61, !tbaa !21
  br label %bb51
bb50:
  %t185 = load i64, ptr %l63, !tbaa !24
  %t186 = icmp ne i64 %t185, 1
  store i1 %t186, ptr %l61, !tbaa !21
  br label %bb51
bb51:
  %t188 = load i1, ptr %l61, !tbaa !21
  br i1 %t188, label %bb52, label %bb53
bb52:
  store %olang.scope zeroinitializer, ptr %s7
  %t189 = load ptr, ptr %l2, !tbaa !29
  store ptr %t189, ptr %l65, !tbaa !29
  %t190 = load ptr, ptr %lp3
  %t191 = getelementptr %"compiler/olang:CommandLine", ptr %t190, i32 0, i32 1
  %t193 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v3, ptr %t191)
  store i64 %t193, ptr %l67
  br label %bb54
bb53:
  br label %bb65
bb54:
  %t194 = load i64, ptr %l67, !tbaa !24
  %t195 = icmp sgt i64 %t194, 1
  br i1 %t195, label %bb55, label %bb56
bb55:
  %t197 = load ptr, ptr %lp3
  %t198 = getelementptr %"compiler/olang:CommandLine", ptr %t197, i32 0, i32 0
  %t199 = load i64, ptr %t198, !tbaa !24
  %t201 = call { i64, ptr } @compiler_2folang_2emodeName(ptr %s7, i64 %t199)
  store { i64, ptr } %t201, ptr %l71
  br label %bb57
bb56:
  %t202 = load ptr, ptr %lp3
  %t203 = getelementptr %"compiler/olang:CommandLine", ptr %t202, i32 0, i32 0
  %t204 = load i64, ptr %t203, !tbaa !24
  %t206 = call { i64, ptr } @compiler_2folang_2emodeName(ptr %s7, i64 %t204)
  store { i64, ptr } %t206, ptr %l75
  br label %bb59
bb57:
  %t207 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t208 = extractvalue { i64, ptr } %t207, 0
  %t209 = extractvalue { i64, ptr } %t207, 1
  %t210 = mul i64 %t208, 1
  %t211 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t210)
  call void @llvm.memcpy.p0.p0.i64(ptr %t211, ptr %t209, i64 %t210, i1 false)
  %t212 = insertvalue { i64, ptr } undef, i64 %t208, 0
  %t213 = insertvalue { i64, ptr } %t212, ptr %t211, 1
  %t215 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eModeOneFile(ptr %s7, ptr %s7, { i64, ptr } %t213)
  store %"compiler/msgs:Msg" %t215, ptr %l73
  br label %bb58
bb58:
  %t216 = load %"compiler/msgs:Msg", ptr %l73
  store %"compiler/msgs:Msg" %t216, ptr %l69
  br label %bb61
bb59:
  %t217 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t218 = extractvalue { i64, ptr } %t217, 0
  %t219 = extractvalue { i64, ptr } %t217, 1
  %t220 = mul i64 %t218, 1
  %t221 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t220)
  call void @llvm.memcpy.p0.p0.i64(ptr %t221, ptr %t219, i64 %t220, i1 false)
  %t222 = insertvalue { i64, ptr } undef, i64 %t218, 0
  %t223 = insertvalue { i64, ptr } %t222, ptr %t221, 1
  %t225 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eModeNeedsFile(ptr %s7, ptr %s7, { i64, ptr } %t223)
  store %"compiler/msgs:Msg" %t225, ptr %l77
  br label %bb60
bb60:
  %t226 = load %"compiler/msgs:Msg", ptr %l77
  store %"compiler/msgs:Msg" %t226, ptr %l69
  br label %bb61
bb61:
  %t227 = load ptr, ptr %l65, !tbaa !29
  %t228 = load %"compiler/msgs:Msg", ptr %l69
  %t229 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s7, ptr %t227, %"compiler/msgs:Msg" %t228)
  store i32 %t229, ptr %l78
  %t230 = icmp ne i32 %t229, 0
  br i1 %t230, label %bb63, label %ok.231
ok.231:
  br label %bb62
bb62:
  br label %bb64
bb63:
  %t232 = load i32, ptr %l78, !tbaa !23
  %t233 = lshr i32 %t232, 16
  %t234 = and i32 %t232, 65535
  %t235 = icmp eq i32 %t233, 1
  %t236 = select i1 %t235, i32 1, i32 0
  %t237 = icmp eq i32 %t232, 0
  %t238 = shl i32 %t236, 16
  %t239 = or i32 %t238, %t234
  %t240 = select i1 %t237, i32 0, i32 %t239
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  %t242 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t240, 0
  store { i32, %"compiler/olang:CommandLine" } %t242, ptr %rv
  br label %ret
bb64:
  call void @__olang_scope_close(ptr %s7)
  br label %bb65
bb65:
  %t243 = load ptr, ptr %lp3
  %t244 = getelementptr %"compiler/olang:CommandLine", ptr %t243, i32 0, i32 1
  %t246 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v3, ptr %t244)
  store i64 %t246, ptr %l81
  br label %bb66
bb66:
  %t247 = load i64, ptr %l81, !tbaa !24
  %t248 = icmp eq i64 %t247, 0
  br i1 %t248, label %bb67, label %bb68
bb67:
  %t250 = load ptr, ptr %lp3
  %t251 = getelementptr %"compiler/olang:CommandLine", ptr %t250, i32 0, i32 0
  %t252 = load i64, ptr %t251, !tbaa !24
  %t253 = load i64, ptr @G_2ecompiler_2folang_2eLsp, !tbaa !24
  %t256 = icmp ne i64 %t252, %t253
  store i1 %t256, ptr %l83, !tbaa !21
  br label %bb69
bb68:
  store i1 false, ptr %l83, !tbaa !21
  br label %bb69
bb69:
  %t258 = load i1, ptr %l83, !tbaa !21
  br i1 %t258, label %bb70, label %bb71
bb70:
  %t259 = load ptr, ptr %lp3
  %t260 = getelementptr %"compiler/olang:CommandLine", ptr %t259, i32 0, i32 0
  %t261 = load i64, ptr %t260, !tbaa !24
  %t262 = load i64, ptr @G_2ecompiler_2folang_2eMcp, !tbaa !24
  %t265 = icmp ne i64 %t261, %t262
  store i1 %t265, ptr %l87, !tbaa !21
  br label %bb72
bb71:
  store i1 false, ptr %l87, !tbaa !21
  br label %bb72
bb72:
  %t267 = load i1, ptr %l87, !tbaa !21
  br i1 %t267, label %bb73, label %bb74
bb73:
  %t268 = load ptr, ptr %lp3
  %t269 = getelementptr %"compiler/olang:CommandLine", ptr %t268, i32 0, i32 0
  %t270 = load i64, ptr %t269, !tbaa !24
  %t271 = load i64, ptr @G_2ecompiler_2folang_2eDoc, !tbaa !24
  %t274 = icmp ne i64 %t270, %t271
  store i1 %t274, ptr %l91, !tbaa !21
  br label %bb75
bb74:
  store i1 false, ptr %l91, !tbaa !21
  br label %bb75
bb75:
  %t276 = load i1, ptr %l91, !tbaa !21
  br i1 %t276, label %bb76, label %bb77
bb76:
  store %olang.scope zeroinitializer, ptr %s8
  %t277 = load ptr, ptr %l2, !tbaa !29
  store ptr %t277, ptr %l95, !tbaa !29
  %t278 = load ptr, ptr %lp3
  %t279 = getelementptr %"compiler/olang:CommandLine", ptr %t278, i32 0, i32 0
  %t280 = load i64, ptr %t279, !tbaa !24
  %t282 = call { i64, ptr } @compiler_2folang_2emodeName(ptr %s8, i64 %t280)
  store { i64, ptr } %t282, ptr %l97
  br label %bb78
bb77:
  br label %bb83
bb78:
  %t283 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t284 = extractvalue { i64, ptr } %t283, 0
  %t285 = extractvalue { i64, ptr } %t283, 1
  %t286 = mul i64 %t284, 1
  %t287 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t286)
  call void @llvm.memcpy.p0.p0.i64(ptr %t287, ptr %t285, i64 %t286, i1 false)
  %t288 = insertvalue { i64, ptr } undef, i64 %t284, 0
  %t289 = insertvalue { i64, ptr } %t288, ptr %t287, 1
  %t291 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eModeNeedsFile(ptr %s8, ptr %s8, { i64, ptr } %t289)
  store %"compiler/msgs:Msg" %t291, ptr %l99
  br label %bb79
bb79:
  %t292 = load ptr, ptr %l95, !tbaa !29
  %t293 = load %"compiler/msgs:Msg", ptr %l99
  %t294 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s8, ptr %t292, %"compiler/msgs:Msg" %t293)
  store i32 %t294, ptr %l100
  %t295 = icmp ne i32 %t294, 0
  br i1 %t295, label %bb81, label %ok.296
ok.296:
  br label %bb80
bb80:
  br label %bb82
bb81:
  %t297 = load i32, ptr %l100, !tbaa !23
  %t298 = lshr i32 %t297, 16
  %t299 = and i32 %t297, 65535
  %t300 = icmp eq i32 %t298, 1
  %t301 = select i1 %t300, i32 1, i32 0
  %t302 = icmp eq i32 %t297, 0
  %t303 = shl i32 %t301, 16
  %t304 = or i32 %t303, %t299
  %t305 = select i1 %t302, i32 0, i32 %t304
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t307 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t305, 0
  store { i32, %"compiler/olang:CommandLine" } %t307, ptr %rv
  br label %ret
bb82:
  call void @__olang_scope_close(ptr %s8)
  br label %bb83
bb83:
  %t308 = load ptr, ptr %lp3
  %t309 = getelementptr %"compiler/olang:CommandLine", ptr %t308, i32 0, i32 0
  %t310 = load i64, ptr %t309, !tbaa !24
  %t311 = load i64, ptr @G_2ecompiler_2folang_2eBuild, !tbaa !24
  %t314 = icmp eq i64 %t310, %t311
  br i1 %t314, label %bb84, label %bb85
bb84:
  store i1 true, ptr %l105, !tbaa !21
  br label %bb86
bb85:
  %t316 = load ptr, ptr %lp3
  %t317 = getelementptr %"compiler/olang:CommandLine", ptr %t316, i32 0, i32 0
  %t318 = load i64, ptr %t317, !tbaa !24
  %t319 = load i64, ptr @G_2ecompiler_2folang_2eCompile, !tbaa !24
  %t322 = icmp eq i64 %t318, %t319
  store i1 %t322, ptr %l105, !tbaa !21
  br label %bb86
bb86:
  %t324 = load i1, ptr %l105, !tbaa !21
  br i1 %t324, label %bb87, label %bb88
bb87:
  store i1 true, ptr %l109, !tbaa !21
  br label %bb89
bb88:
  %t325 = load ptr, ptr %lp3
  %t326 = getelementptr %"compiler/olang:CommandLine", ptr %t325, i32 0, i32 0
  %t327 = load i64, ptr %t326, !tbaa !24
  %t328 = load i64, ptr @G_2ecompiler_2folang_2eBindgen, !tbaa !24
  %t331 = icmp eq i64 %t327, %t328
  store i1 %t331, ptr %l109, !tbaa !21
  br label %bb89
bb89:
  %t333 = load i1, ptr %l109, !tbaa !21
  br i1 %t333, label %bb90, label %bb91
bb90:
  %t334 = load ptr, ptr %lp3
  %t335 = getelementptr %"compiler/olang:CommandLine", ptr %t334, i32 0, i32 1
  %t337 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v3, ptr %t335)
  store i64 %t337, ptr %l115
  br label %bb92
bb91:
  store i1 false, ptr %l113, !tbaa !21
  br label %bb93
bb92:
  %t338 = load i64, ptr %l115, !tbaa !24
  %t339 = icmp ne i64 %t338, 1
  store i1 %t339, ptr %l113, !tbaa !21
  br label %bb93
bb93:
  %t341 = load i1, ptr %l113, !tbaa !21
  br i1 %t341, label %bb94, label %bb95
bb94:
  store %olang.scope zeroinitializer, ptr %s9
  %t342 = load ptr, ptr %l2, !tbaa !29
  store ptr %t342, ptr %l117, !tbaa !29
  %t343 = load ptr, ptr %lp3
  %t344 = getelementptr %"compiler/olang:CommandLine", ptr %t343, i32 0, i32 0
  %t345 = load i64, ptr %t344, !tbaa !24
  %t347 = call { i64, ptr } @compiler_2folang_2emodeName(ptr %s9, i64 %t345)
  store { i64, ptr } %t347, ptr %l119
  br label %bb96
bb95:
  br label %bb101
bb96:
  %t348 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t349 = extractvalue { i64, ptr } %t348, 0
  %t350 = extractvalue { i64, ptr } %t348, 1
  %t351 = mul i64 %t349, 1
  %t352 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t351)
  call void @llvm.memcpy.p0.p0.i64(ptr %t352, ptr %t350, i64 %t351, i1 false)
  %t353 = insertvalue { i64, ptr } undef, i64 %t349, 0
  %t354 = insertvalue { i64, ptr } %t353, ptr %t352, 1
  %t356 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eModeOneFile(ptr %s9, ptr %s9, { i64, ptr } %t354)
  store %"compiler/msgs:Msg" %t356, ptr %l121
  br label %bb97
bb97:
  %t357 = load ptr, ptr %l117, !tbaa !29
  %t358 = load %"compiler/msgs:Msg", ptr %l121
  %t359 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s9, ptr %t357, %"compiler/msgs:Msg" %t358)
  store i32 %t359, ptr %l122
  %t360 = icmp ne i32 %t359, 0
  br i1 %t360, label %bb99, label %ok.361
ok.361:
  br label %bb98
bb98:
  br label %bb100
bb99:
  %t362 = load i32, ptr %l122, !tbaa !23
  %t363 = lshr i32 %t362, 16
  %t364 = and i32 %t362, 65535
  %t365 = icmp eq i32 %t363, 1
  %t366 = select i1 %t365, i32 1, i32 0
  %t367 = icmp eq i32 %t362, 0
  %t368 = shl i32 %t366, 16
  %t369 = or i32 %t368, %t364
  %t370 = select i1 %t367, i32 0, i32 %t369
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  %t372 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t370, 0
  store { i32, %"compiler/olang:CommandLine" } %t372, ptr %rv
  br label %ret
bb100:
  call void @__olang_scope_close(ptr %s9)
  br label %bb101
bb101:
  %t373 = load ptr, ptr %lp3
  %t374 = getelementptr %"compiler/olang:CommandLine", ptr %t373, i32 0, i32 0
  %t375 = load i64, ptr %t374, !tbaa !24
  %t376 = load i64, ptr @G_2ecompiler_2folang_2eFormat, !tbaa !24
  %t379 = icmp eq i64 %t375, %t376
  br i1 %t379, label %bb102, label %bb103
bb102:
  store i1 true, ptr %l127, !tbaa !21
  br label %bb104
bb103:
  %t381 = load ptr, ptr %lp3
  %t382 = getelementptr %"compiler/olang:CommandLine", ptr %t381, i32 0, i32 0
  %t383 = load i64, ptr %t382, !tbaa !24
  %t384 = load i64, ptr @G_2ecompiler_2folang_2eFix, !tbaa !24
  %t387 = icmp eq i64 %t383, %t384
  store i1 %t387, ptr %l127, !tbaa !21
  br label %bb104
bb104:
  %t389 = load i1, ptr %l127, !tbaa !21
  br i1 %t389, label %bb105, label %bb106
bb105:
  %t390 = load ptr, ptr %lp3
  %t391 = load %"compiler/olang:CommandLine", ptr %t390
  call void @__olang_scope_close(ptr %s0)
  %t393 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, %"compiler/olang:CommandLine" %t391, 1
  store { i32, %"compiler/olang:CommandLine" } %t393, ptr %rv
  br label %ret
bb106:
  br label %bb107
bb107:
  %t394 = load ptr, ptr %lp3
  %t395 = getelementptr %"compiler/olang:CommandLine", ptr %t394, i32 0, i32 7
  %t396 = load { i64, ptr }, ptr %t395, !tbaa !27
  %t398 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s0, { i64, ptr } %t396, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d83, i32 0, i32 1) })
  store i1 %t398, ptr %l133
  br label %bb108
bb108:
  %t399 = load i1, ptr %l133, !tbaa !21
  %t400 = xor i1 %t399, true
  br i1 %t400, label %bb109, label %bb110
bb109:
  %t402 = load ptr, ptr %lp3
  %t403 = getelementptr %"compiler/olang:CommandLine", ptr %t402, i32 0, i32 7
  %t404 = load { i64, ptr }, ptr %t403, !tbaa !27
  %t405 = load ptr, ptr %l2, !tbaa !29
  %t408 = call i32 @compiler_2folang_2echeckOutput(ptr %v3, ptr %v2, { i64, ptr } %t404, ptr %t405)
  store i32 %t408, ptr %l137
  %t409 = icmp ne i32 %t408, 0
  br i1 %t409, label %bb112, label %ok.410
ok.410:
  br label %bb111
bb110:
  br label %bb114
bb111:
  br label %bb113
bb112:
  %t411 = load i32, ptr %l137, !tbaa !23
  %t412 = lshr i32 %t411, 16
  %t413 = and i32 %t411, 65535
  %t414 = icmp eq i32 %t412, 1
  %t415 = select i1 %t414, i32 1, i32 0
  %t416 = icmp eq i32 %t411, 0
  %t417 = shl i32 %t415, 16
  %t418 = or i32 %t417, %t413
  %t419 = select i1 %t416, i32 0, i32 %t418
  call void @__olang_scope_close(ptr %s0)
  %t421 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t419, 0
  store { i32, %"compiler/olang:CommandLine" } %t421, ptr %rv
  br label %ret
bb113:
  br label %bb114
bb114:
  %t422 = load ptr, ptr %lp3
  %t423 = getelementptr %"compiler/olang:CommandLine", ptr %t422, i32 0, i32 0
  %t424 = load i64, ptr %t423, !tbaa !24
  %t425 = load i64, ptr @G_2ecompiler_2folang_2eBindgen, !tbaa !24
  %t428 = icmp eq i64 %t424, %t425
  br i1 %t428, label %bb115, label %bb116
bb115:
  %t430 = load ptr, ptr %lp3
  %t431 = load %"compiler/olang:CommandLine", ptr %t430
  call void @__olang_scope_close(ptr %s0)
  %t433 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, %"compiler/olang:CommandLine" %t431, 1
  store { i32, %"compiler/olang:CommandLine" } %t433, ptr %rv
  br label %ret
bb116:
  br label %bb117
bb117:
  %t434 = load ptr, ptr %l1, !tbaa !29
  %t435 = load ptr, ptr %lp3
  %t436 = getelementptr %"compiler/olang:CommandLine", ptr %t435, i32 0, i32 7
  %t437 = load { i64, ptr }, ptr %t436, !tbaa !27
  %t439 = extractvalue { i64, ptr } %t437, 1
  %t440 = extractvalue { i64, ptr } %t437, 0
  %t441 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t440)
  call void @olang_textcopy(ptr %t441, ptr %t439, i64 %t440)
  %t442 = insertvalue { i64, ptr } undef, i64 %t440, 0
  %t443 = insertvalue { i64, ptr } %t442, ptr %t441, 1
  %t445 = extractvalue { i64, ptr } %t443, 0
  %t446 = extractvalue { i64, ptr } %t443, 1
  %t447 = mul i64 %t445, 1
  %t448 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t447)
  call void @llvm.memcpy.p0.p0.i64(ptr %t448, ptr %t446, i64 %t447, i1 false)
  %t449 = insertvalue { i64, ptr } undef, i64 %t445, 0
  %t450 = insertvalue { i64, ptr } %t449, ptr %t448, 1
  %t453 = getelementptr %"compiler/build:Config", ptr %t434, i32 0, i32 15
  store { i64, ptr } %t450, ptr %t453, !tbaa !27
  %t454 = load ptr, ptr %l1, !tbaa !29
  store ptr %t454, ptr %l147, !tbaa !29
  %t455 = call { i64, ptr } @compiler_2ftarget_2eFindClang(ptr %v1)
  store { i64, ptr } %t455, ptr %l148
  br label %bb118
bb118:
  %t456 = load { i64, ptr }, ptr %l148, !tbaa !27
  %t457 = extractvalue { i64, ptr } %t456, 0
  %t458 = extractvalue { i64, ptr } %t456, 1
  %t459 = mul i64 %t457, 1
  %t460 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t459)
  call void @llvm.memcpy.p0.p0.i64(ptr %t460, ptr %t458, i64 %t459, i1 false)
  %t461 = insertvalue { i64, ptr } undef, i64 %t457, 0
  %t462 = insertvalue { i64, ptr } %t461, ptr %t460, 1
  %t464 = load ptr, ptr %l147, !tbaa !29
  %t465 = getelementptr %"compiler/build:Config", ptr %t464, i32 0, i32 1
  store { i64, ptr } %t462, ptr %t465, !tbaa !27
  %t466 = load ptr, ptr %l1, !tbaa !29
  store ptr %t466, ptr %l150, !tbaa !29
  %t467 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %v1, ptr %v1, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d84, i32 0, i32 1) })
  %t468 = extractvalue { i32, { i64, ptr } } %t467, 1
  %t469 = extractvalue { i32, { i64, ptr } } %t467, 0
  store i32 %t469, ptr %l153
  %t470 = icmp ne i32 %t469, 0
  br i1 %t470, label %bb120, label %ok.471
ok.471:
  store { i64, ptr } %t468, ptr %l152
  br label %bb119
bb119:
  %t472 = load { i64, ptr }, ptr %l152, !tbaa !27
  store { i64, ptr } %t472, ptr %l151, !tbaa !27
  br label %bb122
bb120:
  br label %bb121
bb121:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d85, i32 0, i32 1) }, ptr %l154, !tbaa !27
  %t473 = load { i64, ptr }, ptr %l154, !tbaa !27
  %t475 = extractvalue { i64, ptr } %t473, 0
  %t476 = extractvalue { i64, ptr } %t473, 1
  %t477 = mul i64 %t475, 1
  %t478 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t477)
  call void @llvm.memcpy.p0.p0.i64(ptr %t478, ptr %t476, i64 %t477, i1 false)
  %t479 = insertvalue { i64, ptr } undef, i64 %t475, 0
  %t480 = insertvalue { i64, ptr } %t479, ptr %t478, 1
  store { i64, ptr } %t480, ptr %l151, !tbaa !27
  br label %bb122
bb122:
  %t482 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t483 = load ptr, ptr %l150, !tbaa !29
  %t484 = getelementptr %"compiler/build:Config", ptr %t483, i32 0, i32 20
  store { i64, ptr } %t482, ptr %t484, !tbaa !27
  %t485 = load ptr, ptr %lp3
  %t486 = getelementptr %"compiler/olang:CommandLine", ptr %t485, i32 0, i32 0
  %t487 = load i64, ptr %t486, !tbaa !24
  %t488 = load i64, ptr @G_2ecompiler_2folang_2eDoc, !tbaa !24
  %t491 = icmp eq i64 %t487, %t488
  br i1 %t491, label %bb123, label %bb124
bb123:
  store i1 true, ptr %l160, !tbaa !21
  br label %bb125
bb124:
  %t493 = load ptr, ptr %lp3
  %t494 = getelementptr %"compiler/olang:CommandLine", ptr %t493, i32 0, i32 0
  %t495 = load i64, ptr %t494, !tbaa !24
  %t496 = load i64, ptr @G_2ecompiler_2folang_2eLsp, !tbaa !24
  %t499 = icmp eq i64 %t495, %t496
  store i1 %t499, ptr %l160, !tbaa !21
  br label %bb125
bb125:
  %t501 = load i1, ptr %l160, !tbaa !21
  br i1 %t501, label %bb126, label %bb127
bb126:
  store i1 true, ptr %l164, !tbaa !21
  br label %bb128
bb127:
  %t502 = load ptr, ptr %lp3
  %t503 = getelementptr %"compiler/olang:CommandLine", ptr %t502, i32 0, i32 0
  %t504 = load i64, ptr %t503, !tbaa !24
  %t505 = load i64, ptr @G_2ecompiler_2folang_2eMcp, !tbaa !24
  %t508 = icmp eq i64 %t504, %t505
  store i1 %t508, ptr %l164, !tbaa !21
  br label %bb128
bb128:
  %t510 = load i1, ptr %l164, !tbaa !21
  store i1 %t510, ptr %l4, !tbaa !21
  %t511 = load ptr, ptr %l1, !tbaa !29
  store ptr %t511, ptr %l168, !tbaa !29
  %t512 = load ptr, ptr %lp3
  %t513 = getelementptr %"compiler/olang:CommandLine", ptr %t512, i32 0, i32 6
  %t514 = load { i64, ptr }, ptr %t513, !tbaa !27
  store { i64, ptr } %t514, ptr %l170, !tbaa !27
  %t515 = load ptr, ptr %l1, !tbaa !29
  %t517 = getelementptr %"compiler/build:Config", ptr %t515, i32 0, i32 1
  %t518 = load { i64, ptr }, ptr %t517, !tbaa !27
  store { i64, ptr } %t518, ptr %l172, !tbaa !27
  %t519 = load ptr, ptr %lp3
  %t520 = getelementptr %"compiler/olang:CommandLine", ptr %t519, i32 0, i32 0
  %t521 = load i64, ptr %t520, !tbaa !24
  %t522 = load i64, ptr @G_2ecompiler_2folang_2eInterp, !tbaa !24
  %t525 = icmp eq i64 %t521, %t522
  br i1 %t525, label %bb129, label %bb130
bb129:
  store i1 true, ptr %l176, !tbaa !21
  br label %bb135
bb130:
  %t527 = load i1, ptr %l4, !tbaa !21
  br i1 %t527, label %bb131, label %bb132
bb131:
  %t529 = load ptr, ptr %l1, !tbaa !29
  %t531 = getelementptr %"compiler/build:Config", ptr %t529, i32 0, i32 1
  %t532 = load { i64, ptr }, ptr %t531, !tbaa !27
  %t534 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t532, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d86, i32 0, i32 1) })
  store i1 %t534, ptr %l181
  br label %bb133
bb132:
  store i1 false, ptr %l178, !tbaa !21
  br label %bb134
bb133:
  %t535 = load i1, ptr %l181, !tbaa !21
  store i1 %t535, ptr %l178, !tbaa !21
  br label %bb134
bb134:
  %t536 = load i1, ptr %l178, !tbaa !21
  store i1 %t536, ptr %l176, !tbaa !21
  br label %bb135
bb135:
  %t537 = load ptr, ptr %l2, !tbaa !29
  %t538 = load { i64, ptr }, ptr %l170, !tbaa !27
  %t539 = load { i64, ptr }, ptr %l172, !tbaa !27
  %t540 = load i1, ptr %l176, !tbaa !21
  %t542 = call { i32, %"compiler/target:Target" } @compiler_2ftarget_2eResolve(ptr %v3, ptr %v1, ptr %v2, ptr %v1, { i64, ptr } %t538, { i64, ptr } %t539, i1 %t540, ptr %t537)
  %t543 = extractvalue { i32, %"compiler/target:Target" } %t542, 1
  %t544 = extractvalue { i32, %"compiler/target:Target" } %t542, 0
  store i32 %t544, ptr %l184
  %t545 = icmp ne i32 %t544, 0
  br i1 %t545, label %bb137, label %ok.546
ok.546:
  store %"compiler/target:Target" %t543, ptr %l183
  br label %bb136
bb136:
  %t547 = load %"compiler/target:Target", ptr %l183
  store %"compiler/target:Target" %t547, ptr %l169
  br label %bb141
bb137:
  %t548 = load i32, ptr %l184, !tbaa !23
  %t549 = ashr i32 %t548, 16
  %t551 = icmp eq i32 %t549, 1
  br i1 %t551, label %bb138, label %bb139
bb138:
  br label %bb140
bb139:
  %t553 = load i32, ptr %l184, !tbaa !23
  %t554 = lshr i32 %t553, 16
  %t555 = and i32 %t553, 65535
  %t556 = icmp eq i32 %t554, 1
  %t557 = select i1 %t556, i32 0, i32 0
  %t558 = icmp eq i32 %t553, 0
  %t559 = shl i32 %t557, 16
  %t560 = or i32 %t559, %t555
  %t561 = select i1 %t558, i32 0, i32 %t560
  call void @__olang_scope_close(ptr %s0)
  %t563 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t561, 0
  store { i32, %"compiler/olang:CommandLine" } %t563, ptr %rv
  br label %ret
bb140:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  %t565 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/olang:CommandLine" } %t565, ptr %rv
  br label %ret
bb141:
  %t566 = load %"compiler/target:Target", ptr %l169
  %t567 = load ptr, ptr %l168, !tbaa !29
  %t568 = getelementptr %"compiler/build:Config", ptr %t567, i32 0, i32 2
  store %"compiler/target:Target" %t566, ptr %t568
  %t569 = load ptr, ptr %lp3
  %t570 = getelementptr %"compiler/olang:CommandLine", ptr %t569, i32 0, i32 0
  %t571 = load i64, ptr %t570, !tbaa !24
  %t572 = load i64, ptr @G_2ecompiler_2folang_2eCompile, !tbaa !24
  %t575 = icmp eq i64 %t571, %t572
  br i1 %t575, label %bb142, label %bb143
bb142:
  store i1 true, ptr %l192, !tbaa !21
  br label %bb144
bb143:
  %t577 = load ptr, ptr %lp3
  %t578 = getelementptr %"compiler/olang:CommandLine", ptr %t577, i32 0, i32 0
  %t579 = load i64, ptr %t578, !tbaa !24
  %t580 = load i64, ptr @G_2ecompiler_2folang_2eBuild, !tbaa !24
  %t583 = icmp eq i64 %t579, %t580
  store i1 %t583, ptr %l192, !tbaa !21
  br label %bb144
bb144:
  %t585 = load i1, ptr %l192, !tbaa !21
  br i1 %t585, label %bb145, label %bb146
bb145:
  store i1 true, ptr %l196, !tbaa !21
  br label %bb147
bb146:
  %t586 = load ptr, ptr %lp3
  %t587 = getelementptr %"compiler/olang:CommandLine", ptr %t586, i32 0, i32 0
  %t588 = load i64, ptr %t587, !tbaa !24
  %t589 = load i64, ptr @G_2ecompiler_2folang_2eTest, !tbaa !24
  %t592 = icmp eq i64 %t588, %t589
  store i1 %t592, ptr %l196, !tbaa !21
  br label %bb147
bb147:
  %t594 = load i1, ptr %l196, !tbaa !21
  br i1 %t594, label %bb148, label %bb149
bb148:
  store i1 true, ptr %l200, !tbaa !21
  br label %bb150
bb149:
  %t595 = load ptr, ptr %lp3
  %t596 = getelementptr %"compiler/olang:CommandLine", ptr %t595, i32 0, i32 0
  %t597 = load i64, ptr %t596, !tbaa !24
  %t598 = load i64, ptr @G_2ecompiler_2folang_2eRun, !tbaa !24
  %t601 = icmp eq i64 %t597, %t598
  store i1 %t601, ptr %l200, !tbaa !21
  br label %bb150
bb150:
  %t603 = load i1, ptr %l200, !tbaa !21
  store i1 %t603, ptr %l5, !tbaa !21
  %t604 = load ptr, ptr %l1, !tbaa !29
  %t606 = getelementptr %"compiler/build:Config", ptr %t604, i32 0, i32 2
  %t607 = getelementptr %"compiler/target:Target", ptr %t606, i32 0, i32 9
  %t608 = load i1, ptr %t607, !tbaa !21
  br i1 %t608, label %bb151, label %bb152
bb151:
  %t610 = load i1, ptr %l5, !tbaa !21
  %t612 = xor i1 %t610, true
  store i1 %t612, ptr %l206, !tbaa !21
  br label %bb153
bb152:
  store i1 false, ptr %l206, !tbaa !21
  br label %bb153
bb153:
  %t614 = load i1, ptr %l206, !tbaa !21
  br i1 %t614, label %bb154, label %bb155
bb154:
  store %olang.scope zeroinitializer, ptr %s15
  %t615 = load ptr, ptr %l2, !tbaa !29
  store ptr %t615, ptr %l209, !tbaa !29
  %t616 = load ptr, ptr %lp3
  %t617 = getelementptr %"compiler/olang:CommandLine", ptr %t616, i32 0, i32 0
  %t618 = load i64, ptr %t617, !tbaa !24
  %t620 = call { i64, ptr } @compiler_2folang_2emodeName(ptr %s15, i64 %t618)
  store { i64, ptr } %t620, ptr %l211
  br label %bb156
bb155:
  br label %bb161
bb156:
  %t621 = load { i64, ptr }, ptr %l211, !tbaa !27
  %t622 = extractvalue { i64, ptr } %t621, 0
  %t623 = extractvalue { i64, ptr } %t621, 1
  %t624 = mul i64 %t622, 1
  %t625 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t624)
  call void @llvm.memcpy.p0.p0.i64(ptr %t625, ptr %t623, i64 %t624, i1 false)
  %t626 = insertvalue { i64, ptr } undef, i64 %t622, 0
  %t627 = insertvalue { i64, ptr } %t626, ptr %t625, 1
  %t628 = load ptr, ptr %lp3
  %t629 = getelementptr %"compiler/olang:CommandLine", ptr %t628, i32 0, i32 6
  %t630 = load { i64, ptr }, ptr %t629, !tbaa !27
  %t633 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetForeignMode(ptr %s15, ptr %v3, ptr %s15, { i64, ptr } %t627, { i64, ptr } %t630)
  store %"compiler/msgs:Msg" %t633, ptr %l214
  br label %bb157
bb157:
  %t634 = load ptr, ptr %l209, !tbaa !29
  %t635 = load %"compiler/msgs:Msg", ptr %l214
  %t636 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s15, ptr %t634, %"compiler/msgs:Msg" %t635)
  store i32 %t636, ptr %l215
  %t637 = icmp ne i32 %t636, 0
  br i1 %t637, label %bb159, label %ok.638
ok.638:
  br label %bb158
bb158:
  br label %bb160
bb159:
  %t639 = load i32, ptr %l215, !tbaa !23
  %t640 = lshr i32 %t639, 16
  %t641 = and i32 %t639, 65535
  %t642 = icmp eq i32 %t640, 1
  %t643 = select i1 %t642, i32 1, i32 0
  %t644 = icmp eq i32 %t639, 0
  %t645 = shl i32 %t643, 16
  %t646 = or i32 %t645, %t641
  %t647 = select i1 %t644, i32 0, i32 %t646
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  %t649 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t647, 0
  store { i32, %"compiler/olang:CommandLine" } %t649, ptr %rv
  br label %ret
bb160:
  call void @__olang_scope_close(ptr %s15)
  br label %bb161
bb161:
  %t650 = load ptr, ptr %l1, !tbaa !29
  %t651 = load ptr, ptr %lp3
  %t652 = getelementptr %"compiler/olang:CommandLine", ptr %t651, i32 0, i32 0
  %t653 = load i64, ptr %t652, !tbaa !24
  %t654 = load i64, ptr @G_2ecompiler_2folang_2eTest, !tbaa !24
  %t657 = icmp eq i64 %t653, %t654
  %t660 = getelementptr %"compiler/build:Config", ptr %t650, i32 0, i32 11
  store i1 %t657, ptr %t660, !tbaa !21
  %t661 = load ptr, ptr %l1, !tbaa !29
  store ptr %t661, ptr %l221, !tbaa !29
  %t662 = load ptr, ptr %l1, !tbaa !29
  %t664 = getelementptr %"compiler/build:Config", ptr %t662, i32 0, i32 11
  %t665 = load i1, ptr %t664, !tbaa !21
  br i1 %t665, label %bb162, label %bb163
bb162:
  store i1 true, ptr %l224, !tbaa !21
  br label %bb164
bb163:
  %t667 = load ptr, ptr %lp3
  %t668 = getelementptr %"compiler/olang:CommandLine", ptr %t667, i32 0, i32 0
  %t669 = load i64, ptr %t668, !tbaa !24
  %t670 = load i64, ptr @G_2ecompiler_2folang_2eLsp, !tbaa !24
  %t673 = icmp eq i64 %t669, %t670
  store i1 %t673, ptr %l224, !tbaa !21
  br label %bb164
bb164:
  %t675 = load i1, ptr %l224, !tbaa !21
  br i1 %t675, label %bb165, label %bb166
bb165:
  store i1 true, ptr %l228, !tbaa !21
  br label %bb167
bb166:
  %t676 = load ptr, ptr %lp3
  %t677 = getelementptr %"compiler/olang:CommandLine", ptr %t676, i32 0, i32 0
  %t678 = load i64, ptr %t677, !tbaa !24
  %t679 = load i64, ptr @G_2ecompiler_2folang_2eMcp, !tbaa !24
  %t682 = icmp eq i64 %t678, %t679
  store i1 %t682, ptr %l228, !tbaa !21
  br label %bb167
bb167:
  %t684 = load ptr, ptr %l2, !tbaa !29
  %t685 = load ptr, ptr %l221, !tbaa !29
  %t686 = load i1, ptr %l228, !tbaa !21
  %t688 = call i32 @compiler_2folang_2ebuiltins(ptr %v1, ptr %v2, ptr %t685, i1 %t686, ptr %t684)
  store i32 %t688, ptr %l233
  %t689 = icmp ne i32 %t688, 0
  br i1 %t689, label %bb169, label %ok.690
ok.690:
  br label %bb168
bb168:
  br label %bb170
bb169:
  %t691 = load i32, ptr %l233, !tbaa !23
  %t692 = lshr i32 %t691, 16
  %t693 = and i32 %t691, 65535
  %t694 = icmp eq i32 %t692, 1
  %t695 = select i1 %t694, i32 1, i32 0
  %t696 = icmp eq i32 %t691, 0
  %t697 = shl i32 %t695, 16
  %t698 = or i32 %t697, %t693
  %t699 = select i1 %t696, i32 0, i32 %t698
  call void @__olang_scope_close(ptr %s0)
  %t701 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t699, 0
  store { i32, %"compiler/olang:CommandLine" } %t701, ptr %rv
  br label %ret
bb170:
  %t702 = load ptr, ptr %lp3
  %t703 = load %"compiler/olang:CommandLine", ptr %t702
  call void @__olang_scope_close(ptr %s0)
  %t705 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, %"compiler/olang:CommandLine" %t703, 1
  store { i32, %"compiler/olang:CommandLine" } %t705, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/olang:CommandLine" }, ptr %rv
  ret { i32, %"compiler/olang:CommandLine" } %rr
}

define dso_local void @compiler_2folang_2eRun_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr @G_2ecompiler_2folang_2eRun, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eTest_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 3, ptr @G_2ecompiler_2folang_2eTest, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2folang_2ebuildInputs(ptr %v0, ptr %v1, ptr %a0, i1 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"std/os:FileInfo"
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/target:Target"
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i32
  %l9 = alloca { i64, ptr }
  %l12 = alloca %"std/os:FileInfo"
  %l14 = alloca %"std/os:FileInfo"
  %l15 = alloca i32
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i32
  %l25 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca i64
  %l34 = alloca i1
  %l36 = alloca i1
  %l38 = alloca i1
  %l40 = alloca i1
  %l42 = alloca i1
  %l43 = alloca i1
  %l44 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %s0, ptr %s0, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d87, i32 0, i32 1) })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l8
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  store { i64, ptr } %t2, ptr %l7
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t6, ptr %l6, !tbaa !27
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d88, i32 0, i32 1) }, ptr %l9, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t10 = extractvalue { i64, ptr } %t7, 1
  %t11 = mul i64 %t9, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t10, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l6, !tbaa !27
  br label %bb4
bb4:
  %t16 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t16, ptr %l2, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t19 = call { i32, %"std/os:FileInfo" } @std_2fos_2eStat(ptr %s0, { i64, ptr } %t17)
  %t20 = extractvalue { i32, %"std/os:FileInfo" } %t19, 1
  %t21 = extractvalue { i32, %"std/os:FileInfo" } %t19, 0
  store i32 %t21, ptr %l15
  %t22 = icmp ne i32 %t21, 0
  br i1 %t22, label %bb6, label %ok.23
ok.23:
  store %"std/os:FileInfo" %t20, ptr %l14
  br label %bb5
bb5:
  %t24 = load %"std/os:FileInfo", ptr %l14
  store %"std/os:FileInfo" %t24, ptr %l12
  br label %bb10
bb6:
  %t25 = load i32, ptr %l15, !tbaa !23
  %t26 = ashr i32 %t25, 16
  %t28 = icmp eq i32 %t26, 1
  br i1 %t28, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_75a15dc32bd9c62d_7df2e713047d6551)
  unreachable
bb9:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d89, i32 0, i32 1) }, ptr %l18, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t30, ptr %l19, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l20, !tbaa !24
  %t33 = load i64, ptr %l20, !tbaa !24
  %t34 = mul i64 %t33, 1
  %t35 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t34)
  %t36 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t35, 1
  store { i64, ptr } %t37, ptr %l21, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = load i64, ptr %l20, !tbaa !24
  %t43 = mul i64 %t42, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t39, ptr %t41, i64 %t43, i1 false)
  %t44 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t44, ptr %l19, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t45 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t45, ptr %rv
  br label %ret
bb10:
  %t46 = load %"std/os:FileInfo", ptr %l12
  store %"std/os:FileInfo" %t46, ptr %l3
  %t47 = call { i32, { i64, ptr } } @std_2fos_2eCwd(ptr %s0)
  %t48 = extractvalue { i32, { i64, ptr } } %t47, 1
  %t49 = extractvalue { i32, { i64, ptr } } %t47, 0
  store i32 %t49, ptr %l24
  %t50 = icmp ne i32 %t49, 0
  br i1 %t50, label %bb12, label %ok.51
ok.51:
  store { i64, ptr } %t48, ptr %l23
  br label %bb11
bb11:
  %t52 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t52, ptr %l22, !tbaa !27
  br label %bb14
bb12:
  br label %bb13
bb13:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d90, i32 0, i32 1) }, ptr %l25, !tbaa !27
  %t53 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t53, 0
  %t56 = extractvalue { i64, ptr } %t53, 1
  %t57 = mul i64 %t55, 1
  %t58 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t57)
  call void @llvm.memcpy.p0.p0.i64(ptr %t58, ptr %t56, i64 %t57, i1 false)
  %t59 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t58, 1
  store { i64, ptr } %t60, ptr %l22, !tbaa !27
  br label %bb14
bb14:
  %t62 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t62, ptr %l4, !tbaa !27
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/build:Config", ptr %t63, i32 0, i32 2
  %t66 = load %"compiler/target:Target", ptr %t65
  store %"compiler/target:Target" %t66, ptr %l5
  %t68 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t68, ptr %l30, !tbaa !27
  %t69 = getelementptr %"std/os:FileInfo", ptr %l3, i32 0, i32 1
  %t70 = load i64, ptr %t69, !tbaa !24
  store i64 %t70, ptr %l31, !tbaa !24
  %t71 = getelementptr %"std/os:FileInfo", ptr %l3, i32 0, i32 2
  %t72 = load i64, ptr %t71, !tbaa !24
  store i64 %t72, ptr %l32, !tbaa !24
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/build:Config", ptr %t73, i32 0, i32 4
  %t76 = load i1, ptr %t75, !tbaa !21
  store i1 %t76, ptr %l34, !tbaa !21
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/build:Config", ptr %t77, i32 0, i32 6
  %t80 = load i1, ptr %t79, !tbaa !21
  store i1 %t80, ptr %l36, !tbaa !21
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/build:Config", ptr %t81, i32 0, i32 7
  %t84 = load i1, ptr %t83, !tbaa !21
  store i1 %t84, ptr %l38, !tbaa !21
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/build:Config", ptr %t85, i32 0, i32 5
  %t88 = load i1, ptr %t87, !tbaa !21
  store i1 %t88, ptr %l40, !tbaa !21
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/build:Config", ptr %t89, i32 0, i32 9
  %t92 = load i1, ptr %t91, !tbaa !21
  store i1 %t92, ptr %l42, !tbaa !21
  store i1 %a1, ptr %l43, !tbaa !21
  %t94 = getelementptr %"compiler/target:Target", ptr %l5, i32 0, i32 1
  %t95 = load { i64, ptr }, ptr %t94, !tbaa !27
  store { i64, ptr } %t95, ptr %l44, !tbaa !27
  %t96 = getelementptr %"compiler/target:Target", ptr %l5, i32 0, i32 2
  %t97 = load { i64, ptr }, ptr %t96, !tbaa !27
  store { i64, ptr } %t97, ptr %l45, !tbaa !27
  %t98 = getelementptr %"compiler/target:Target", ptr %l5, i32 0, i32 4
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !27
  store { i64, ptr } %t99, ptr %l46, !tbaa !27
  %t100 = getelementptr %"compiler/target:Target", ptr %l5, i32 0, i32 5
  %t101 = load { i64, ptr }, ptr %t100, !tbaa !27
  store { i64, ptr } %t101, ptr %l47, !tbaa !27
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/build:Config", ptr %t102, i32 0, i32 3
  %t106 = call { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eFingerprint(ptr %v0, ptr %s0, ptr %t104)
  store { i64, ptr } %t106, ptr %l50
  br label %bb15
bb15:
  %t107 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t107, ptr %l51, !tbaa !27
  %t108 = call { i64, ptr } @compiler_2fload_2eStdDir(ptr %s0)
  store { i64, ptr } %t108, ptr %l52
  br label %bb16
bb16:
  %t109 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t109, 1
  %t111 = extractvalue { i64, ptr } %t109, 0
  %t112 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d91, i32 0, i32 1) }, 1
  %t113 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d91, i32 0, i32 1) }, 0
  %t114 = add i64 %t111, %t113
  %t115 = load i64, ptr %l31, !tbaa !24
  %t116 = call i64 @__olang_fmt_i64(ptr null, i64 %t115)
  %t117 = add i64 %t114, %t116
  %t118 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d91, i32 0, i32 1) }, 1
  %t119 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d91, i32 0, i32 1) }, 0
  %t120 = add i64 %t117, %t119
  %t121 = load i64, ptr %l32, !tbaa !24
  %t122 = call i64 @__olang_fmt_i64(ptr null, i64 %t121)
  %t123 = add i64 %t120, %t122
  %t124 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d92, i32 0, i32 1) }, 1
  %t125 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d92, i32 0, i32 1) }, 0
  %t126 = add i64 %t123, %t125
  %t127 = load i1, ptr %l34, !tbaa !21
  %t128 = select i1 %t127, ptr @.c93, ptr @.c94
  %t129 = select i1 %t127, i64 4, i64 5
  %t130 = add i64 %t126, %t129
  %t131 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d91, i32 0, i32 1) }, 1
  %t132 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d91, i32 0, i32 1) }, 0
  %t133 = add i64 %t130, %t132
  %t134 = load i1, ptr %l36, !tbaa !21
  %t135 = select i1 %t134, ptr @.c93, ptr @.c94
  %t136 = select i1 %t134, i64 4, i64 5
  %t137 = add i64 %t133, %t136
  %t138 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d91, i32 0, i32 1) }, 1
  %t139 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d91, i32 0, i32 1) }, 0
  %t140 = add i64 %t137, %t139
  %t141 = load i1, ptr %l38, !tbaa !21
  %t142 = select i1 %t141, ptr @.c93, ptr @.c94
  %t143 = select i1 %t141, i64 4, i64 5
  %t144 = add i64 %t140, %t143
  %t145 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d91, i32 0, i32 1) }, 1
  %t146 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d91, i32 0, i32 1) }, 0
  %t147 = add i64 %t144, %t146
  %t148 = load i1, ptr %l40, !tbaa !21
  %t149 = select i1 %t148, ptr @.c93, ptr @.c94
  %t150 = select i1 %t148, i64 4, i64 5
  %t151 = add i64 %t147, %t150
  %t152 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d91, i32 0, i32 1) }, 1
  %t153 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d91, i32 0, i32 1) }, 0
  %t154 = add i64 %t151, %t153
  %t155 = load i1, ptr %l42, !tbaa !21
  %t156 = select i1 %t155, ptr @.c93, ptr @.c94
  %t157 = select i1 %t155, i64 4, i64 5
  %t158 = add i64 %t154, %t157
  %t159 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d91, i32 0, i32 1) }, 1
  %t160 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d91, i32 0, i32 1) }, 0
  %t161 = add i64 %t158, %t160
  %t162 = load i1, ptr %l43, !tbaa !21
  %t163 = select i1 %t162, ptr @.c93, ptr @.c94
  %t164 = select i1 %t162, i64 4, i64 5
  %t165 = add i64 %t161, %t164
  %t166 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d92, i32 0, i32 1) }, 1
  %t167 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d92, i32 0, i32 1) }, 0
  %t168 = add i64 %t165, %t167
  %t169 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t170 = extractvalue { i64, ptr } %t169, 1
  %t171 = extractvalue { i64, ptr } %t169, 0
  %t172 = add i64 %t168, %t171
  %t173 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d92, i32 0, i32 1) }, 1
  %t174 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d92, i32 0, i32 1) }, 0
  %t175 = add i64 %t172, %t174
  %t176 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t177 = extractvalue { i64, ptr } %t176, 1
  %t178 = extractvalue { i64, ptr } %t176, 0
  %t179 = add i64 %t175, %t178
  %t180 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d92, i32 0, i32 1) }, 1
  %t181 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d92, i32 0, i32 1) }, 0
  %t182 = add i64 %t179, %t181
  %t183 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t184 = extractvalue { i64, ptr } %t183, 1
  %t185 = extractvalue { i64, ptr } %t183, 0
  %t186 = add i64 %t182, %t185
  %t187 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d92, i32 0, i32 1) }, 1
  %t188 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d92, i32 0, i32 1) }, 0
  %t189 = add i64 %t186, %t188
  %t190 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t191 = extractvalue { i64, ptr } %t190, 1
  %t192 = extractvalue { i64, ptr } %t190, 0
  %t193 = add i64 %t189, %t192
  %t194 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d92, i32 0, i32 1) }, 1
  %t195 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d92, i32 0, i32 1) }, 0
  %t196 = add i64 %t193, %t195
  %t197 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t198 = extractvalue { i64, ptr } %t197, 1
  %t199 = extractvalue { i64, ptr } %t197, 0
  %t200 = add i64 %t196, %t199
  %t201 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d92, i32 0, i32 1) }, 1
  %t202 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d92, i32 0, i32 1) }, 0
  %t203 = add i64 %t200, %t202
  %t204 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t205 = extractvalue { i64, ptr } %t204, 1
  %t206 = extractvalue { i64, ptr } %t204, 0
  %t207 = add i64 %t203, %t206
  %t208 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d92, i32 0, i32 1) }, 1
  %t209 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d92, i32 0, i32 1) }, 0
  %t210 = add i64 %t207, %t209
  %t211 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t212 = extractvalue { i64, ptr } %t211, 1
  %t213 = extractvalue { i64, ptr } %t211, 0
  %t214 = add i64 %t210, %t213
  %t215 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t214)
  call void @olang_textcopy(ptr %t215, ptr %t110, i64 %t111)
  %t216 = getelementptr i8, ptr %t215, i64 %t111
  call void @olang_textcopy(ptr %t216, ptr %t112, i64 %t113)
  %t217 = getelementptr i8, ptr %t216, i64 %t113
  %t218 = call i64 @__olang_fmt_i64(ptr %t217, i64 %t115)
  %t219 = getelementptr i8, ptr %t217, i64 %t116
  call void @olang_textcopy(ptr %t219, ptr %t118, i64 %t119)
  %t220 = getelementptr i8, ptr %t219, i64 %t119
  %t221 = call i64 @__olang_fmt_i64(ptr %t220, i64 %t121)
  %t222 = getelementptr i8, ptr %t220, i64 %t122
  call void @olang_textcopy(ptr %t222, ptr %t124, i64 %t125)
  %t223 = getelementptr i8, ptr %t222, i64 %t125
  call void @olang_textcopy(ptr %t223, ptr %t128, i64 %t129)
  %t224 = getelementptr i8, ptr %t223, i64 %t129
  call void @olang_textcopy(ptr %t224, ptr %t131, i64 %t132)
  %t225 = getelementptr i8, ptr %t224, i64 %t132
  call void @olang_textcopy(ptr %t225, ptr %t135, i64 %t136)
  %t226 = getelementptr i8, ptr %t225, i64 %t136
  call void @olang_textcopy(ptr %t226, ptr %t138, i64 %t139)
  %t227 = getelementptr i8, ptr %t226, i64 %t139
  call void @olang_textcopy(ptr %t227, ptr %t142, i64 %t143)
  %t228 = getelementptr i8, ptr %t227, i64 %t143
  call void @olang_textcopy(ptr %t228, ptr %t145, i64 %t146)
  %t229 = getelementptr i8, ptr %t228, i64 %t146
  call void @olang_textcopy(ptr %t229, ptr %t149, i64 %t150)
  %t230 = getelementptr i8, ptr %t229, i64 %t150
  call void @olang_textcopy(ptr %t230, ptr %t152, i64 %t153)
  %t231 = getelementptr i8, ptr %t230, i64 %t153
  call void @olang_textcopy(ptr %t231, ptr %t156, i64 %t157)
  %t232 = getelementptr i8, ptr %t231, i64 %t157
  call void @olang_textcopy(ptr %t232, ptr %t159, i64 %t160)
  %t233 = getelementptr i8, ptr %t232, i64 %t160
  call void @olang_textcopy(ptr %t233, ptr %t163, i64 %t164)
  %t234 = getelementptr i8, ptr %t233, i64 %t164
  call void @olang_textcopy(ptr %t234, ptr %t166, i64 %t167)
  %t235 = getelementptr i8, ptr %t234, i64 %t167
  call void @olang_textcopy(ptr %t235, ptr %t170, i64 %t171)
  %t236 = getelementptr i8, ptr %t235, i64 %t171
  call void @olang_textcopy(ptr %t236, ptr %t173, i64 %t174)
  %t237 = getelementptr i8, ptr %t236, i64 %t174
  call void @olang_textcopy(ptr %t237, ptr %t177, i64 %t178)
  %t238 = getelementptr i8, ptr %t237, i64 %t178
  call void @olang_textcopy(ptr %t238, ptr %t180, i64 %t181)
  %t239 = getelementptr i8, ptr %t238, i64 %t181
  call void @olang_textcopy(ptr %t239, ptr %t184, i64 %t185)
  %t240 = getelementptr i8, ptr %t239, i64 %t185
  call void @olang_textcopy(ptr %t240, ptr %t187, i64 %t188)
  %t241 = getelementptr i8, ptr %t240, i64 %t188
  call void @olang_textcopy(ptr %t241, ptr %t191, i64 %t192)
  %t242 = getelementptr i8, ptr %t241, i64 %t192
  call void @olang_textcopy(ptr %t242, ptr %t194, i64 %t195)
  %t243 = getelementptr i8, ptr %t242, i64 %t195
  call void @olang_textcopy(ptr %t243, ptr %t198, i64 %t199)
  %t244 = getelementptr i8, ptr %t243, i64 %t199
  call void @olang_textcopy(ptr %t244, ptr %t201, i64 %t202)
  %t245 = getelementptr i8, ptr %t244, i64 %t202
  call void @olang_textcopy(ptr %t245, ptr %t205, i64 %t206)
  %t246 = getelementptr i8, ptr %t245, i64 %t206
  call void @olang_textcopy(ptr %t246, ptr %t208, i64 %t209)
  %t247 = getelementptr i8, ptr %t246, i64 %t209
  call void @olang_textcopy(ptr %t247, ptr %t212, i64 %t213)
  %t248 = insertvalue { i64, ptr } undef, i64 %t214, 0
  %t249 = insertvalue { i64, ptr } %t248, ptr %t215, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t249, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2folang_2ebuiltins(ptr %v0, ptr %v1, ptr %a0, i1 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/target:Target"
  %l22 = alloca i1
  %l23 = alloca ptr
  %l25 = alloca %"compiler/msgs:Msg"
  %l26 = alloca i32
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l39 = alloca i64
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = insertvalue [8 x { i64, ptr }] undef, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d95, i32 0, i32 1) }, 0
  %t2 = insertvalue [8 x { i64, ptr }] %t1, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d96, i32 0, i32 1) }, 1
  %t3 = insertvalue [8 x { i64, ptr }] %t2, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d97, i32 0, i32 1) }, 2
  %t4 = insertvalue [8 x { i64, ptr }] %t3, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d98, i32 0, i32 1) }, 3
  %t5 = insertvalue [8 x { i64, ptr }] %t4, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d99, i32 0, i32 1) }, 4
  %t6 = insertvalue [8 x { i64, ptr }] %t5, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d100, i32 0, i32 1) }, 5
  %t7 = insertvalue [8 x { i64, ptr }] %t6, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d101, i32 0, i32 1) }, 6
  %t8 = insertvalue [8 x { i64, ptr }] %t7, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d102, i32 0, i32 1) }, 7
  %t10 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 128, i64 8)
  store [8 x { i64, ptr }] %t8, ptr %t10
  store ptr %t10, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  %t12 = load ptr, ptr %l3
  store i64 8, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t15 = load i64, ptr %l4, !tbaa !24
  %t16 = load i64, ptr %l5, !tbaa !24
  %t19 = icmp slt i64 %t15, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb3:
  br label %bb4
bb4:
  %t23 = load ptr, ptr %l3
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = getelementptr [8 x { i64, ptr }], ptr %t23, i64 0, i64 %t24
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !37
  store { i64, ptr } %t28, ptr %l6, !tbaa !27
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/build:Config", ptr %t30, i32 0, i32 3
  %t33 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t34 = load ptr, ptr @__olang_prog_scope
  %t37 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eHas(ptr %v0, ptr %t34, ptr %t32, { i64, ptr } %t33)
  store i1 %t37, ptr %l22
  br label %bb5
bb5:
  %t38 = load i1, ptr %l22, !tbaa !21
  br i1 %t38, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  store ptr %a2, ptr %l23, !tbaa !29
  %t40 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t41 = load ptr, ptr @__olang_prog_scope
  %t43 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefineBuiltin(ptr %t41, ptr %s3, { i64, ptr } %t40)
  store %"compiler/msgs:Msg" %t43, ptr %l25
  br label %bb8
bb7:
  br label %bb12
bb8:
  %t44 = load ptr, ptr %l23, !tbaa !29
  %t45 = load %"compiler/msgs:Msg", ptr %l25
  %t46 = call i32 @compiler_2folang_2eusage(ptr %v1, ptr %s3, ptr %t44, %"compiler/msgs:Msg" %t45)
  store i32 %t46, ptr %l26
  %t47 = icmp ne i32 %t46, 0
  br i1 %t47, label %bb10, label %ok.48
ok.48:
  br label %bb9
bb9:
  br label %bb11
bb10:
  %t49 = load i32, ptr %l26, !tbaa !23
  %t50 = lshr i32 %t49, 16
  %t51 = and i32 %t49, 65535
  %t52 = icmp eq i32 %t50, 1
  %t53 = select i1 %t52, i32 1, i32 0
  %t54 = icmp eq i32 %t49, 0
  %t55 = shl i32 %t53, 16
  %t56 = or i32 %t55, %t51
  %t57 = select i1 %t54, i32 0, i32 %t56
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  store i32 %t57, ptr %rv
  br label %ret
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb13:
  %t59 = load i64, ptr %l4, !tbaa !24
  %t61 = add i64 %t59, 1
  store i64 %t61, ptr %l4, !tbaa !24
  br label %bb1
bb14:
  call void @__olang_scope_close(ptr %s1)
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/build:Config", ptr %t63, i32 0, i32 2
  %t66 = load %"compiler/target:Target", ptr %t65
  store %"compiler/target:Target" %t66, ptr %l7
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/build:Config", ptr %t68, i32 0, i32 3
  store ptr %t70, ptr %l33, !tbaa !29
  %t71 = getelementptr %"compiler/target:Target", ptr %l7, i32 0, i32 3
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !27
  store { i64, ptr } %t72, ptr %l34, !tbaa !27
  %t73 = getelementptr %"compiler/target:Target", ptr %l7, i32 0, i32 2
  %t74 = load { i64, ptr }, ptr %t73, !tbaa !27
  store { i64, ptr } %t74, ptr %l35, !tbaa !27
  %t75 = getelementptr %"compiler/target:Target", ptr %l7, i32 0, i32 4
  %t76 = load { i64, ptr }, ptr %t75, !tbaa !27
  store { i64, ptr } %t76, ptr %l36, !tbaa !27
  %t77 = getelementptr %"compiler/target:Target", ptr %l7, i32 0, i32 7
  %t78 = load i64, ptr %t77, !tbaa !24
  store i64 %t78, ptr %l37, !tbaa !24
  %t79 = getelementptr %"compiler/target:Target", ptr %l7, i32 0, i32 8
  %t80 = load i1, ptr %t79, !tbaa !21
  br i1 %t80, label %bb15, label %bb16
bb15:
  store i64 1, ptr %l39, !tbaa !24
  br label %bb17
bb16:
  store i64 0, ptr %l39, !tbaa !24
  br label %bb17
bb17:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/build:Config", ptr %t82, i32 0, i32 4
  %t85 = load i1, ptr %t84, !tbaa !21
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/build:Config", ptr %t86, i32 0, i32 6
  %t89 = load i1, ptr %t88, !tbaa !21
  %t91 = load ptr, ptr %l33, !tbaa !29
  %t92 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t93 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t94 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t95 = load i64, ptr %l37, !tbaa !24
  %t96 = load i64, ptr %l39, !tbaa !24
  call void @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eBuiltins(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t91, { i64, ptr } %t92, { i64, ptr } %t93, { i64, ptr } %t94, i64 %t95, i64 %t96, i1 %t85, i1 %t89, i1 %a1)
  br label %bb18
bb18:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2folang_2echeckOutput(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l5 = alloca i1
  %l6 = alloca ptr
  %l8 = alloca %"compiler/msgs:Msg"
  %l9 = alloca i32
  %l11 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i64
  %l32 = alloca i1
  %l34 = alloca ptr
  %l37 = alloca %"compiler/msgs:Msg"
  %l38 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i32
  store { i64, ptr } %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fos_2eIsDir(ptr %v0, { i64, ptr } %t1)
  store i1 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i1, ptr %l5, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l6, !tbaa !29
  %t6 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eOutputIsDir(ptr %v0, ptr %s1, { i64, ptr } %t6)
  store %"compiler/msgs:Msg" %t8, ptr %l8
  br label %bb4
bb3:
  br label %bb8
bb4:
  %t9 = load ptr, ptr %l6, !tbaa !29
  %t10 = load %"compiler/msgs:Msg", ptr %l8
  %t11 = call i32 @compiler_2folang_2eusage(ptr %v1, ptr %s1, ptr %t9, %"compiler/msgs:Msg" %t10)
  store i32 %t11, ptr %l9
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb6, label %ok.13
ok.13:
  br label %bb5
bb5:
  br label %bb7
bb6:
  %t14 = load i32, ptr %l9, !tbaa !23
  %t15 = lshr i32 %t14, 16
  %t16 = and i32 %t14, 65535
  %t17 = icmp eq i32 %t15, 1
  %t18 = select i1 %t17, i32 1, i32 0
  %t19 = icmp eq i32 %t14, 0
  %t20 = shl i32 %t18, 16
  %t21 = or i32 %t20, %t16
  %t22 = select i1 %t19, i32 0, i32 %t21
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t22, ptr %rv
  br label %ret
bb7:
  call void @__olang_scope_close(ptr %s1)
  br label %bb8
bb8:
  %t24 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t26 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %s0, { i64, ptr } %t24, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d103, i32 0, i32 1) })
  %t27 = extractvalue { i32, i64 } %t26, 1
  %t28 = extractvalue { i32, i64 } %t26, 0
  store i32 %t28, ptr %l14
  %t29 = icmp ne i32 %t28, 0
  br i1 %t29, label %bb10, label %ok.30
ok.30:
  store i64 %t27, ptr %l13
  br label %bb9
bb9:
  %t31 = load i64, ptr %l13, !tbaa !24
  store i64 %t31, ptr %l11, !tbaa !24
  br label %bb12
bb10:
  br label %bb11
bb11:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb12:
  %t32 = load i64, ptr %l11, !tbaa !24
  store i64 %t32, ptr %l2, !tbaa !24
  %t33 = load i64, ptr %l2, !tbaa !24
  %t35 = icmp eq i64 %t33, 0
  br i1 %t35, label %bb13, label %bb14
bb13:
  %t37 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t37, ptr %l18, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 0
  store i64 %t39, ptr %l19, !tbaa !24
  %t40 = icmp sge i64 0, 0
  br i1 %t40, label %bb15, label %bb16
bb14:
  %t42 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t42, ptr %l24, !tbaa !27
  %t43 = load i64, ptr %l2, !tbaa !24
  store i64 %t43, ptr %l25, !tbaa !24
  %t44 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t44, 0
  store i64 %t45, ptr %l26, !tbaa !24
  %t46 = icmp sge i64 0, 0
  br i1 %t46, label %bb21, label %bb22
bb15:
  %t48 = icmp sle i64 0, 1
  br i1 %t48, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_12131eae1fe55f7a_2d06b34e1c9e748e)
  unreachable
bb17:
  %t50 = load i64, ptr %l19, !tbaa !24
  %t51 = icmp sle i64 1, %t50
  br i1 %t51, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_12131eae1fe55f7a_2d06b34e1c9e748e)
  unreachable
bb19:
  %t53 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr i8, ptr %t54, i64 0
  %t56 = sub i64 1, 0
  %t57 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t55, 1
  store { i64, ptr } %t58, ptr %l17, !tbaa !27
  br label %bb27
bb20:
  call void @__olang_check_failed(ptr @olang_loc_12131eae1fe55f7a_2d06b34e1c9e748e)
  unreachable
bb21:
  %t60 = load i64, ptr %l25, !tbaa !24
  %t61 = icmp sle i64 0, %t60
  br i1 %t61, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_12131eae1fe55f7a_2d06b34e1c9e748e)
  unreachable
bb23:
  %t63 = load i64, ptr %l25, !tbaa !24
  %t64 = load i64, ptr %l26, !tbaa !24
  %t65 = icmp sle i64 %t63, %t64
  br i1 %t65, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_12131eae1fe55f7a_2d06b34e1c9e748e)
  unreachable
bb25:
  %t67 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !27
  %t69 = load i64, ptr %l25, !tbaa !24
  %t70 = getelementptr i8, ptr %t68, i64 0
  %t71 = sub i64 %t69, 0
  %t72 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t70, 1
  store { i64, ptr } %t73, ptr %l17, !tbaa !27
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_12131eae1fe55f7a_2d06b34e1c9e748e)
  unreachable
bb27:
  %t75 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t75, ptr %l3, !tbaa !27
  %t76 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t78 = call i1 @std_2fos_2eIsDir(ptr %v0, { i64, ptr } %t76)
  store i1 %t78, ptr %l32
  br label %bb28
bb28:
  %t79 = load i1, ptr %l32, !tbaa !21
  %t80 = xor i1 %t79, true
  br i1 %t80, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s3
  %t82 = load ptr, ptr %l1, !tbaa !29
  store ptr %t82, ptr %l34, !tbaa !29
  %t83 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t84 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t87 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eOutputNoDir(ptr %v0, ptr %v0, ptr %s3, { i64, ptr } %t83, { i64, ptr } %t84)
  store %"compiler/msgs:Msg" %t87, ptr %l37
  br label %bb31
bb30:
  br label %bb35
bb31:
  %t88 = load ptr, ptr %l34, !tbaa !29
  %t89 = load %"compiler/msgs:Msg", ptr %l37
  %t90 = call i32 @compiler_2folang_2eusage(ptr %v1, ptr %s3, ptr %t88, %"compiler/msgs:Msg" %t89)
  store i32 %t90, ptr %l38
  %t91 = icmp ne i32 %t90, 0
  br i1 %t91, label %bb33, label %ok.92
ok.92:
  br label %bb32
bb32:
  br label %bb34
bb33:
  %t93 = load i32, ptr %l38, !tbaa !23
  %t94 = lshr i32 %t93, 16
  %t95 = and i32 %t93, 65535
  %t96 = icmp eq i32 %t94, 1
  %t97 = select i1 %t96, i32 1, i32 0
  %t98 = icmp eq i32 %t93, 0
  %t99 = shl i32 %t97, 16
  %t100 = or i32 %t99, %t95
  %t101 = select i1 %t98, i32 0, i32 %t100
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t101, ptr %rv
  br label %ret
bb34:
  call void @__olang_scope_close(ptr %s3)
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2folang_2echeckReuse(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, i32 %a6, ptr %a7) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l9 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca i1
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca %"compiler/build:Unit"
  %l20 = alloca i64
  %l28 = alloca ptr
  %l30 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l32 = alloca i64
  %l35 = alloca i64
  %l38 = alloca i64
  %l42 = alloca i64
  %l45 = alloca i64
  %l63 = alloca i64
  %l66 = alloca i64
  %l71 = alloca %"compiler/build:Unit"
  %l74 = alloca %"compiler/emit:Object"
  %l77 = alloca i1
  %l79 = alloca i1
  %l82 = alloca %"compiler/emit:Object"
  %l85 = alloca i1
  %l89 = alloca %"compiler/emit:Object"
  %l93 = alloca i32
  %l101 = alloca i64
  %l103 = alloca i64
  %l106 = alloca i32
  %l111 = alloca i64
  %l114 = alloca i32
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 61
  %t5 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eLen_3cI64_2c_20I64_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l20
  br label %bb1
bb1:
  %t6 = load i64, ptr %l20, !tbaa !24
  %t7 = icmp eq i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t21 = call ptr @compiler_2folang_2eemitter(ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %a2, ptr %a3, ptr %a4, ptr %a5, i32 %a6, ptr %a7)
  store ptr %t21, ptr %l28
  br label %bb5
bb5:
  %t22 = load ptr, ptr %l28, !tbaa !29
  %t25 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2ecompiler_2femit_3aEmitter_2eObjects(ptr %v5, ptr %s0, ptr %t22)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %l30
  br label %bb6
bb6:
  %t26 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l30
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t26, ptr %l9
  %t28 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aObject_3e_2eLen_3ccompiler_2femit_3aObject_3e(ptr %s0, ptr %l9)
  store i64 %t28, ptr %l32
  br label %bb7
bb7:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr %"compiler/build:Program", ptr %t29, i32 0, i32 0
  %t33 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2eLen_3ccompiler_2fbuild_3aUnit_3e(ptr %v1, ptr %t31)
  store i64 %t33, ptr %l35
  br label %bb8
bb8:
  %t34 = load i64, ptr %l32, !tbaa !24
  %t35 = load i64, ptr %l35, !tbaa !24
  %t36 = icmp ne i64 %t34, %t35
  store i1 %t36, ptr %l10, !tbaa !21
  store i64 0, ptr %l11, !tbaa !24
  %t39 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aObject_3e_2eLen_3ccompiler_2femit_3aObject_3e(ptr %s0, ptr %l9)
  store i64 %t39, ptr %l38
  br label %bb9
bb9:
  %t40 = load i64, ptr %l38, !tbaa !24
  store i64 %t40, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t41 = load i64, ptr %l12, !tbaa !24
  %t42 = load i64, ptr %l11, !tbaa !24
  %t45 = icmp sgt i64 %t41, %t42
  br i1 %t45, label %bb10, label %bb11
bb10:
  %t47 = load i64, ptr %l13, !tbaa !24
  %t49 = icmp sgt i64 %t47, 0
  br i1 %t49, label %bb12, label %bb13
bb11:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb15
bb12:
  %t51 = load i64, ptr %l12, !tbaa !24
  %t52 = load i64, ptr %l11, !tbaa !24
  %t55 = sub i64 %t51, %t52
  %t56 = load i64, ptr %l13, !tbaa !24
  %t59 = add i64 %t55, %t56
  %t61 = sub i64 %t59, 1
  %t62 = load i64, ptr %l13, !tbaa !24
  %t65 = sdiv i64 %t61, %t62
  store i64 %t65, ptr %l45, !tbaa !24
  br label %bb14
bb13:
  store i64 0, ptr %l45, !tbaa !24
  br label %bb14
bb14:
  %t67 = load i64, ptr %l45, !tbaa !24
  store i64 %t67, ptr %l42, !tbaa !24
  br label %bb15
bb15:
  %t68 = load i64, ptr %l42, !tbaa !24
  store i64 %t68, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb16
bb16:
  store %olang.scope zeroinitializer, ptr %s3
  %t69 = load i64, ptr %l15, !tbaa !24
  %t70 = load i64, ptr %l14, !tbaa !24
  %t73 = icmp slt i64 %t69, %t70
  %t75 = xor i1 %t73, true
  br i1 %t75, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s3)
  br label %bb43
bb18:
  br label %bb19
bb19:
  %t77 = load i64, ptr %l11, !tbaa !24
  %t78 = load i64, ptr %l15, !tbaa !24
  %t79 = load i64, ptr %l13, !tbaa !24
  %t82 = mul i64 %t78, %t79
  %t85 = add i64 %t77, %t82
  store i64 %t85, ptr %l16, !tbaa !24
  %t87 = load i64, ptr %l16, !tbaa !24
  store i64 %t87, ptr %l63, !tbaa !24
  %t88 = load ptr, ptr %l1, !tbaa !29
  %t90 = getelementptr %"compiler/build:Program", ptr %t88, i32 0, i32 0
  %t92 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2eLen_3ccompiler_2fbuild_3aUnit_3e(ptr %v1, ptr %t90)
  store i64 %t92, ptr %l66
  br label %bb20
bb20:
  %t93 = load i64, ptr %l63, !tbaa !24
  %t94 = load i64, ptr %l66, !tbaa !24
  %t95 = icmp sge i64 %t93, %t94
  br i1 %t95, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s3)
  br label %bb43
bb22:
  br label %bb23
bb23:
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t99 = getelementptr %"compiler/build:Program", ptr %t97, i32 0, i32 0
  %t100 = load i64, ptr %l16, !tbaa !24
  %t103 = call %"compiler/build:Unit" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2eAt_3ccompiler_2fbuild_3aUnit_3e(ptr %v1, ptr %v1, ptr %t99, i64 %t100)
  store %"compiler/build:Unit" %t103, ptr %l71
  br label %bb24
bb24:
  %t104 = load %"compiler/build:Unit", ptr %l71
  store %"compiler/build:Unit" %t104, ptr %l17
  %t105 = load i64, ptr %l16, !tbaa !24
  %t108 = call %"compiler/emit:Object" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aObject_3e_2eAt_3ccompiler_2femit_3aObject_3e(ptr %s0, ptr %s0, ptr %l9, i64 %t105)
  store %"compiler/emit:Object" %t108, ptr %l74
  br label %bb25
bb25:
  %t109 = getelementptr %"compiler/emit:Object", ptr %l74, i32 0, i32 0
  %t110 = load { i64, ptr }, ptr %t109, !tbaa !27
  %t111 = getelementptr %"compiler/build:Unit", ptr %l17, i32 0, i32 0
  %t112 = load { i64, ptr }, ptr %t111, !tbaa !27
  %t115 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %v1, { i64, ptr } %t110, { i64, ptr } %t112)
  store i1 %t115, ptr %l77
  br label %bb26
bb26:
  %t116 = load i1, ptr %l77, !tbaa !21
  %t117 = xor i1 %t116, true
  br i1 %t117, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l79, !tbaa !21
  br label %bb31
bb28:
  %t119 = load i64, ptr %l16, !tbaa !24
  %t122 = call %"compiler/emit:Object" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aObject_3e_2eAt_3ccompiler_2femit_3aObject_3e(ptr %s0, ptr %s0, ptr %l9, i64 %t119)
  store %"compiler/emit:Object" %t122, ptr %l82
  br label %bb29
bb29:
  %t123 = getelementptr %"compiler/emit:Object", ptr %l82, i32 0, i32 2
  %t124 = load { i64, ptr }, ptr %t123, !tbaa !27
  %t125 = getelementptr %"compiler/build:Unit", ptr %l17, i32 0, i32 2
  %t126 = load { i64, ptr }, ptr %t125, !tbaa !27
  %t129 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %v1, { i64, ptr } %t124, { i64, ptr } %t126)
  store i1 %t129, ptr %l85
  br label %bb30
bb30:
  %t130 = load i1, ptr %l85, !tbaa !21
  %t131 = xor i1 %t130, true
  store i1 %t131, ptr %l79, !tbaa !21
  br label %bb31
bb31:
  %t133 = load i1, ptr %l79, !tbaa !21
  br i1 %t133, label %bb32, label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s5
  %t134 = load i64, ptr %l16, !tbaa !24
  %t137 = call %"compiler/emit:Object" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aObject_3e_2eAt_3ccompiler_2femit_3aObject_3e(ptr %s0, ptr %s0, ptr %l9, i64 %t134)
  store %"compiler/emit:Object" %t137, ptr %l89
  br label %bb34
bb33:
  br label %bb41
bb34:
  %t138 = getelementptr %"compiler/emit:Object", ptr %l89, i32 0, i32 0
  %t139 = load { i64, ptr }, ptr %t138, !tbaa !27
  %t140 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d104, i32 0, i32 1) }, 1
  %t141 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d104, i32 0, i32 1) }, 0
  %t143 = extractvalue { i64, ptr } %t139, 1
  %t144 = extractvalue { i64, ptr } %t139, 0
  %t145 = add i64 %t141, %t144
  %t146 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d105, i32 0, i32 1) }, 1
  %t147 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d105, i32 0, i32 1) }, 0
  %t148 = add i64 %t145, %t147
  %t149 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t148)
  call void @olang_textcopy(ptr %t149, ptr %t140, i64 %t141)
  %t150 = getelementptr i8, ptr %t149, i64 %t141
  call void @olang_textcopy(ptr %t150, ptr %t143, i64 %t144)
  %t151 = getelementptr i8, ptr %t150, i64 %t144
  call void @olang_textcopy(ptr %t151, ptr %t146, i64 %t147)
  %t152 = insertvalue { i64, ptr } undef, i64 %t148, 0
  %t153 = insertvalue { i64, ptr } %t152, ptr %t149, 1
  %t155 = extractvalue { i64, ptr } %t153, 0
  %t156 = extractvalue { i64, ptr } %t153, 1
  %t157 = mul i64 %t155, 1
  %t158 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t157)
  call void @llvm.memcpy.p0.p0.i64(ptr %t158, ptr %t156, i64 %t157, i1 false)
  %t159 = insertvalue { i64, ptr } undef, i64 %t155, 0
  %t160 = insertvalue { i64, ptr } %t159, ptr %t158, 1
  %t162 = call i32 @std_2fio_2ePrintErr(ptr %s5, { i64, ptr } %t160)
  store i32 %t162, ptr %l93
  %t163 = icmp ne i32 %t162, 0
  br i1 %t163, label %bb36, label %ok.164
ok.164:
  br label %bb35
bb35:
  br label %bb40
bb36:
  %t165 = load i32, ptr %l93, !tbaa !23
  %t166 = ashr i32 %t165, 16
  %t168 = icmp eq i32 %t166, 1
  br i1 %t168, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  call void @__olang_check_failed(ptr @olang_loc_dd8573ae343ff812_8decdc106ea08ebe)
  unreachable
bb39:
  call void @__olang_ert_req_clear()
  br label %bb40
bb40:
  store i1 true, ptr %l10, !tbaa !21
  call void @__olang_scope_close(ptr %s5)
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s3)
  br label %bb42
bb42:
  %t170 = load i64, ptr %l15, !tbaa !24
  %t172 = add i64 %t170, 1
  store i64 %t172, ptr %l15, !tbaa !24
  br label %bb16
bb43:
  %t174 = load i1, ptr %l10, !tbaa !21
  br i1 %t174, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s9
  %t176 = load ptr, ptr %l1, !tbaa !29
  %t178 = getelementptr %"compiler/build:Program", ptr %t176, i32 0, i32 0
  %t180 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2eLen_3ccompiler_2fbuild_3aUnit_3e(ptr %v1, ptr %t178)
  store i64 %t180, ptr %l101
  br label %bb46
bb45:
  br label %bb55
bb46:
  %t182 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aObject_3e_2eLen_3ccompiler_2femit_3aObject_3e(ptr %s0, ptr %l9)
  store i64 %t182, ptr %l103
  br label %bb47
bb47:
  %t183 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d106, i32 0, i32 1) }, 1
  %t184 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d106, i32 0, i32 1) }, 0
  %t185 = load i64, ptr %l101, !tbaa !24
  %t186 = call i64 @__olang_fmt_i64(ptr null, i64 %t185)
  %t187 = add i64 %t184, %t186
  %t188 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d107, i32 0, i32 1) }, 1
  %t189 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d107, i32 0, i32 1) }, 0
  %t190 = add i64 %t187, %t189
  %t191 = load i64, ptr %l103, !tbaa !24
  %t192 = call i64 @__olang_fmt_i64(ptr null, i64 %t191)
  %t193 = add i64 %t190, %t192
  %t194 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d108, i32 0, i32 1) }, 1
  %t195 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d108, i32 0, i32 1) }, 0
  %t196 = add i64 %t193, %t195
  %t197 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t196)
  call void @olang_textcopy(ptr %t197, ptr %t183, i64 %t184)
  %t198 = getelementptr i8, ptr %t197, i64 %t184
  %t199 = call i64 @__olang_fmt_i64(ptr %t198, i64 %t185)
  %t200 = getelementptr i8, ptr %t198, i64 %t186
  call void @olang_textcopy(ptr %t200, ptr %t188, i64 %t189)
  %t201 = getelementptr i8, ptr %t200, i64 %t189
  %t202 = call i64 @__olang_fmt_i64(ptr %t201, i64 %t191)
  %t203 = getelementptr i8, ptr %t201, i64 %t192
  call void @olang_textcopy(ptr %t203, ptr %t194, i64 %t195)
  %t204 = insertvalue { i64, ptr } undef, i64 %t196, 0
  %t205 = insertvalue { i64, ptr } %t204, ptr %t197, 1
  %t207 = extractvalue { i64, ptr } %t205, 0
  %t208 = extractvalue { i64, ptr } %t205, 1
  %t209 = mul i64 %t207, 1
  %t210 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t209)
  call void @llvm.memcpy.p0.p0.i64(ptr %t210, ptr %t208, i64 %t209, i1 false)
  %t211 = insertvalue { i64, ptr } undef, i64 %t207, 0
  %t212 = insertvalue { i64, ptr } %t211, ptr %t210, 1
  %t214 = call i32 @std_2fio_2ePrintErr(ptr %s9, { i64, ptr } %t212)
  store i32 %t214, ptr %l106
  %t215 = icmp ne i32 %t214, 0
  br i1 %t215, label %bb49, label %ok.216
ok.216:
  br label %bb48
bb48:
  br label %bb53
bb49:
  %t217 = load i32, ptr %l106, !tbaa !23
  %t218 = ashr i32 %t217, 16
  %t220 = icmp eq i32 %t218, 1
  br i1 %t220, label %bb50, label %bb51
bb50:
  br label %bb52
bb51:
  call void @__olang_check_failed(ptr @olang_loc_1ac4aff2f4082213_2cf9008d871781bf)
  unreachable
bb52:
  call void @__olang_ert_req_clear()
  br label %bb53
bb53:
  call void @std_2fos_2eExit(i32 3)
  unreachable
bb54:
  call void @__olang_check_failed(ptr @olang_loc_32421bf44abb9df8_94a4451618780c84)
  unreachable
bb55:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/emit:Emitter", ptr %t222, i32 0, i32 61
  %t226 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eLen_3cI64_2c_20I64_3e(ptr %v0, ptr %t224)
  store i64 %t226, ptr %l111
  br label %bb56
bb56:
  %t227 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d109, i32 0, i32 1) }, 1
  %t228 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d109, i32 0, i32 1) }, 0
  %t229 = load i64, ptr %l111, !tbaa !24
  %t230 = call i64 @__olang_fmt_i64(ptr null, i64 %t229)
  %t231 = add i64 %t228, %t230
  %t232 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d110, i32 0, i32 1) }, 1
  %t233 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d110, i32 0, i32 1) }, 0
  %t234 = add i64 %t231, %t233
  %t235 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t234)
  call void @olang_textcopy(ptr %t235, ptr %t227, i64 %t228)
  %t236 = getelementptr i8, ptr %t235, i64 %t228
  %t237 = call i64 @__olang_fmt_i64(ptr %t236, i64 %t229)
  %t238 = getelementptr i8, ptr %t236, i64 %t230
  call void @olang_textcopy(ptr %t238, ptr %t232, i64 %t233)
  %t239 = insertvalue { i64, ptr } undef, i64 %t234, 0
  %t240 = insertvalue { i64, ptr } %t239, ptr %t235, 1
  %t242 = extractvalue { i64, ptr } %t240, 0
  %t243 = extractvalue { i64, ptr } %t240, 1
  %t244 = mul i64 %t242, 1
  %t245 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t244)
  call void @llvm.memcpy.p0.p0.i64(ptr %t245, ptr %t243, i64 %t244, i1 false)
  %t246 = insertvalue { i64, ptr } undef, i64 %t242, 0
  %t247 = insertvalue { i64, ptr } %t246, ptr %t245, 1
  %t249 = call i32 @std_2fio_2ePrintErr(ptr %s0, { i64, ptr } %t247)
  store i32 %t249, ptr %l114
  %t250 = icmp ne i32 %t249, 0
  br i1 %t250, label %bb58, label %ok.251
ok.251:
  br label %bb57
bb57:
  br label %bb62
bb58:
  %t252 = load i32, ptr %l114, !tbaa !23
  %t253 = ashr i32 %t252, 16
  %t255 = icmp eq i32 %t253, 1
  br i1 %t255, label %bb59, label %bb60
bb59:
  br label %bb61
bb60:
  call void @__olang_check_failed(ptr @olang_loc_2cc05bc0974a48c9_c5f1014419607875)
  unreachable
bb61:
  call void @__olang_ert_req_clear()
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2folang_2ecompiler_2folang_3aPasses_2eAnalyze(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i32 %a2, ptr %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l16 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca %"compiler/lower:Gap"
  %l29 = alloca %"compiler/target:Target"
  %l30 = alloca i1
  %l31 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l32 = alloca ptr
  %l33 = alloca i64
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca %"compiler/emit:Object"
  %l38 = alloca %"compiler/emit:Reused"
  %l39 = alloca { i64, ptr }
  %l40 = alloca ptr
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca { i64, ptr }
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l50 = alloca { i64, ptr }
  %l51 = alloca i32
  %l53 = alloca ptr
  %l54 = alloca ptr
  %l55 = alloca i64
  %l56 = alloca { i64, ptr }
  %l57 = alloca i64
  %l58 = alloca i64
  %l62 = alloca ptr
  %l67 = alloca ptr
  %l68 = alloca i32
  %l72 = alloca %"compiler/check:Checker"
  %l76 = alloca i1
  %l81 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l84 = alloca i64
  %l88 = alloca i64
  %l91 = alloca i64
  %l92 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l96 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l99 = alloca i64
  %l102 = alloca i1
  %l106 = alloca ptr
  %l112 = alloca %"compiler/lower:Lowerer"
  %l117 = alloca ptr
  %l118 = alloca ptr
  %l121 = alloca i64
  %l124 = alloca ptr
  %l133 = alloca i1
  %l135 = alloca i64
  %l138 = alloca { i64, ptr }
  %l140 = alloca i32
  %l144 = alloca { i64, ptr }
  %l145 = alloca { i64, ptr }
  %l146 = alloca i32
  %l147 = alloca { i64, ptr }
  %l150 = alloca i1
  %l153 = alloca { i64, ptr }
  %l155 = alloca i32
  %l160 = alloca i64
  %l169 = alloca ptr
  %l179 = alloca { i64, ptr }
  %l180 = alloca ptr
  %l184 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l186 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l195 = alloca ptr
  %l197 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l200 = alloca i64
  %l202 = alloca i1
  %l205 = alloca i64
  %l209 = alloca { i64, ptr }
  %l212 = alloca { i64, ptr }
  %l213 = alloca i32
  %l223 = alloca { i64, ptr }
  %l236 = alloca { i64, ptr }
  %l239 = alloca { i64, ptr }
  %l240 = alloca i32
  %l250 = alloca { i64, ptr }
  %l257 = alloca { i64, ptr }
  %l268 = alloca i64
  %l273 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l275 = alloca { i64, ptr }
  %l278 = alloca { i64, ptr }
  %l279 = alloca i32
  %l289 = alloca { i64, ptr }
  %l297 = alloca %"compiler/emit:Reused"
  %l298 = alloca ptr
  %l302 = alloca ptr
  %l305 = alloca { i64, ptr }
  %l308 = alloca { i64, ptr }
  %l310 = alloca { i64, ptr }
  %l313 = alloca { i64, ptr }
  %l314 = alloca i32
  %l325 = alloca { i64, ptr }
  %l328 = alloca { i64, ptr }
  %l333 = alloca { i64, ptr }
  %l334 = alloca i32
  %l344 = alloca { i64, ptr }
  %l345 = alloca i1
  %l349 = alloca { i64, ptr }
  %l353 = alloca { i64, ptr }
  %l356 = alloca i1
  %l357 = alloca i32
  %l361 = alloca %"compiler/build:Unit"
  %l363 = alloca ptr
  %l366 = alloca { i64, ptr }
  %l384 = alloca { i64, ptr }
  %l385 = alloca i1
  %l389 = alloca { i64, ptr }
  %l392 = alloca i32
  %l413 = alloca %"compiler/build:Unit"
  %l418 = alloca i1
  %l421 = alloca i1
  %l424 = alloca ptr
  %l426 = alloca { i64, ptr }
  %l452 = alloca { i64, ptr }
  %l453 = alloca { i64, ptr }
  %l454 = alloca i32
  %l455 = alloca { i64, ptr }
  %l458 = alloca i1
  %l468 = alloca ptr
  %l470 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l472 = alloca i64
  %l478 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l480 = alloca { i64, ptr }
  %l483 = alloca { i64, ptr }
  %l484 = alloca i32
  %l494 = alloca { i64, ptr }
  %l507 = alloca ptr
  %l508 = alloca ptr
  %l510 = alloca { i64, ptr }
  %l513 = alloca { i64, ptr }
  %l515 = alloca ptr
  %l516 = alloca { i64, ptr }
  %l524 = alloca { i64, ptr }
  %l525 = alloca i32
  %l533 = alloca ptr
  %l536 = alloca { i64, ptr }
  %l539 = alloca ptr
  %l540 = alloca { i64, ptr }
  %l548 = alloca { i64, ptr }
  %l549 = alloca i32
  %l557 = alloca ptr
  %l560 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s55 = alloca %olang.scope
  %s56 = alloca %olang.scope
  %s57 = alloca %olang.scope
  %rv = alloca i32
  %t33 = alloca %"compiler/check:Checker", align 8
  store { i64, ptr } %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l2
  %t3 = trunc i64 2 to i32
  %t4 = icmp eq i32 %t1, %t3
  store i1 %t4, ptr %l6, !tbaa !21
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d111, i32 0, i32 1) })
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t8 = load ptr, ptr %l3, !tbaa !29
  %t9 = load ptr, ptr %l5, !tbaa !29
  %t14 = call { i32, ptr } @compiler_2folang_2ecompiler_2folang_3aPasses_2eload(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %t7, ptr %t8, ptr %t9)
  %t15 = extractvalue { i32, ptr } %t14, 1
  %t16 = extractvalue { i32, ptr } %t14, 0
  store i32 %t16, ptr %l68
  %t17 = icmp ne i32 %t16, 0
  br i1 %t17, label %bb3, label %ok.18
ok.18:
  store ptr %t15, ptr %l67
  br label %bb2
bb2:
  %t19 = load ptr, ptr %l67, !tbaa !29
  store ptr %t19, ptr %l62, !tbaa !29
  br label %bb4
bb3:
  %t20 = load i32, ptr %l68, !tbaa !23
  %t21 = lshr i32 %t20, 16
  %t22 = and i32 %t20, 65535
  %t23 = icmp eq i32 %t21, 1
  %t24 = select i1 %t23, i32 1, i32 0
  %t25 = icmp eq i32 %t20, 0
  %t26 = shl i32 %t24, 16
  %t27 = or i32 %t26, %t22
  %t28 = select i1 %t25, i32 0, i32 %t27
  call void @__olang_scope_close(ptr %s0)
  store i32 %t28, ptr %rv
  br label %ret
bb4:
  %t30 = load ptr, ptr %l62, !tbaa !29
  store ptr %t30, ptr %l7, !tbaa !29
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d112, i32 0, i32 1) })
  br label %bb5
bb5:
  %t31 = load ptr, ptr %l7, !tbaa !29
  %t32 = load i1, ptr %l6, !tbaa !21
  call void @compiler_2finterp_2eAnalyze(ptr %t33, ptr %v2, ptr %v2, ptr %t31, i1 %t32)
  call void @llvm.memmove.p0.p0.i64(ptr %l72, ptr %t33, i64 752, i1 false)
  br label %bb6
bb6:
  %t36 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 752, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t36, ptr %l72, i64 752, i1 false)
  store ptr %t36, ptr %l8, !tbaa !29
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d113, i32 0, i32 1) })
  br label %bb7
bb7:
  %t38 = load i32, ptr %l2
  %t40 = trunc i64 1 to i32
  %t41 = icmp eq i32 %t38, %t40
  br i1 %t41, label %bb8, label %bb9
bb8:
  %t43 = load ptr, ptr %l3, !tbaa !29
  %t45 = getelementptr %"compiler/build:Config", ptr %t43, i32 0, i32 9
  %t46 = load i1, ptr %t45, !tbaa !21
  %t48 = xor i1 %t46, true
  store i1 %t48, ptr %l76, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l76, !tbaa !21
  br label %bb10
bb10:
  %t50 = load i1, ptr %l76, !tbaa !21
  br i1 %t50, label %bb11, label %bb12
bb11:
  %t51 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eCheckMain(ptr %v2, ptr %t51)
  br label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb14
bb14:
  %t53 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t53, ptr %l81
  br label %bb15
bb15:
  %t54 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l81
  %t55 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t54, ptr %t55
  store ptr %t55, ptr %l9, !tbaa !29
  %t57 = load ptr, ptr %l5, !tbaa !29
  %t59 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v2, ptr %t57)
  store i64 %t59, ptr %l84
  br label %bb16
bb16:
  %t60 = load i64, ptr %l84, !tbaa !24
  %t61 = icmp eq i64 %t60, 0
  store i1 %t61, ptr %l10, !tbaa !21
  %t63 = load i1, ptr %l10, !tbaa !21
  br i1 %t63, label %bb17, label %bb18
bb17:
  %t65 = load ptr, ptr %l8, !tbaa !29
  %t67 = call i64 @compiler_2finterp_2eDecideValues(ptr %v2, ptr %t65)
  store i64 %t67, ptr %l88
  br label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb20
bb20:
  %t68 = load ptr, ptr %l8, !tbaa !29
  %t69 = load ptr, ptr %l9, !tbaa !29
  %t72 = call i64 @compiler_2finterp_2eDecideAsserts(ptr %v2, ptr %v2, ptr %t68, ptr %t69)
  store i64 %t72, ptr %l91
  br label %bb21
bb21:
  %t73 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2ector(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t73, ptr %l92
  br label %bb22
bb22:
  %t74 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l92
  %t75 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t74, ptr %t75
  store ptr %t75, ptr %l11, !tbaa !29
  %t77 = load i1, ptr %l10, !tbaa !21
  br i1 %t77, label %bb23, label %bb24
bb23:
  %t79 = load ptr, ptr %l8, !tbaa !29
  %t81 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2finterp_2eBake(ptr %v2, ptr %v2, ptr %t79)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t81, ptr %l96
  br label %bb25
bb24:
  br label %bb26
bb25:
  %t82 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l96
  %t83 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t82, ptr %t83
  store ptr %t83, ptr %l11, !tbaa !29
  br label %bb26
bb26:
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d114, i32 0, i32 1) })
  br label %bb27
bb27:
  %t85 = load ptr, ptr %l5, !tbaa !29
  %t87 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v2, ptr %t85)
  store i64 %t87, ptr %l99
  br label %bb28
bb28:
  %t88 = load i64, ptr %l99, !tbaa !24
  %t89 = icmp sgt i64 %t88, 0
  br i1 %t89, label %bb29, label %bb30
bb29:
  %t91 = load ptr, ptr %l5, !tbaa !29
  %t93 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHasFatal(ptr %v2, ptr %t91)
  store i1 %t93, ptr %l102
  br label %bb31
bb30:
  br label %bb36
bb31:
  %t94 = load i1, ptr %l102, !tbaa !21
  %t95 = xor i1 %t94, true
  br i1 %t95, label %bb32, label %bb33
bb32:
  %t97 = load ptr, ptr %l8, !tbaa !29
  %t98 = load ptr, ptr %l3, !tbaa !29
  %t101 = call ptr @compiler_2folang_2eplacement(ptr %v2, ptr %v2, ptr %t97, ptr %t98, i64 -1, i1 false)
  store ptr %t101, ptr %l106
  br label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb36:
  %t103 = load ptr, ptr %l8, !tbaa !29
  %t105 = getelementptr %"compiler/check:Checker", ptr %t103, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t107 = load ptr, ptr %l8, !tbaa !29
  %t109 = getelementptr %"compiler/check:Checker", ptr %t107, i32 0, i32 11
  %t110 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t109
  %t113 = call %"compiler/lower:Lowerer" @compiler_2flower_3aLowerer_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %t106, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t110)
  store %"compiler/lower:Lowerer" %t113, ptr %l112
  br label %bb37
bb37:
  %t114 = load %"compiler/lower:Lowerer", ptr %l112
  %t115 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 120, i64 8)
  store %"compiler/lower:Lowerer" %t114, ptr %t115
  store ptr %t115, ptr %l12, !tbaa !29
  %t117 = load ptr, ptr %l12, !tbaa !29
  %t118 = load ptr, ptr %l9, !tbaa !29
  %t120 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t118
  %t123 = getelementptr %"compiler/lower:Lowerer", ptr %t117, i32 0, i32 7
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t120, ptr %t123
  %t124 = load ptr, ptr %l8, !tbaa !29
  store ptr %t124, ptr %l117, !tbaa !29
  %t125 = load ptr, ptr %l3, !tbaa !29
  store ptr %t125, ptr %l118, !tbaa !29
  %t126 = load i32, ptr %l2
  %t128 = trunc i64 0 to i32
  %t129 = icmp eq i32 %t126, %t128
  br i1 %t129, label %bb38, label %bb39
bb38:
  store i64 -1, ptr %l121, !tbaa !24
  br label %bb40
bb39:
  %t131 = load ptr, ptr %l7, !tbaa !29
  %t133 = getelementptr %"compiler/load:Loader", ptr %t131, i32 0, i32 7
  %t134 = load i64, ptr %t133, !tbaa !24
  store i64 %t134, ptr %l121, !tbaa !24
  br label %bb40
bb40:
  %t136 = load ptr, ptr %l117, !tbaa !29
  %t137 = load ptr, ptr %l118, !tbaa !29
  %t138 = load i64, ptr %l121, !tbaa !24
  %t139 = call ptr @compiler_2folang_2eplacement(ptr %v2, ptr %v2, ptr %t136, ptr %t137, i64 %t138, i1 true)
  store ptr %t139, ptr %l124
  br label %bb41
bb41:
  %t140 = load ptr, ptr %l124, !tbaa !29
  store ptr %t140, ptr %l13, !tbaa !29
  %t141 = load ptr, ptr %l12, !tbaa !29
  %t142 = load ptr, ptr %l13, !tbaa !29
  %t144 = getelementptr %"compiler/free:Free", ptr %t142, i32 0, i32 3
  %t145 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t144
  %t148 = getelementptr %"compiler/lower:Lowerer", ptr %t141, i32 0, i32 2
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t145, ptr %t148
  %t149 = load ptr, ptr %l12, !tbaa !29
  %t150 = load ptr, ptr %l13, !tbaa !29
  %t154 = getelementptr %"compiler/lower:Lowerer", ptr %t149, i32 0, i32 3
  store ptr %t150, ptr %t154, !tbaa !29
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d115, i32 0, i32 1) })
  br label %bb42
bb42:
  %t155 = load ptr, ptr %l3, !tbaa !29
  %t157 = getelementptr %"compiler/build:Config", ptr %t155, i32 0, i32 8
  %t158 = load i1, ptr %t157, !tbaa !21
  br i1 %t158, label %bb43, label %bb44
bb43:
  %t160 = load ptr, ptr %l5, !tbaa !29
  %t162 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v2, ptr %t160)
  store i64 %t162, ptr %l135
  br label %bb45
bb44:
  store i1 false, ptr %l133, !tbaa !21
  br label %bb46
bb45:
  %t163 = load i64, ptr %l135, !tbaa !24
  %t164 = icmp eq i64 %t163, 0
  store i1 %t164, ptr %l133, !tbaa !21
  br label %bb46
bb46:
  %t166 = load i1, ptr %l133, !tbaa !21
  br i1 %t166, label %bb47, label %bb48
bb47:
  store %olang.scope zeroinitializer, ptr %s6
  %t167 = load ptr, ptr %l13, !tbaa !29
  %t169 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2eReport(ptr %v2, ptr %s6, ptr %t167)
  store { i64, ptr } %t169, ptr %l138
  br label %bb49
bb48:
  br label %bb56
bb49:
  %t170 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t171 = extractvalue { i64, ptr } %t170, 0
  %t172 = extractvalue { i64, ptr } %t170, 1
  %t173 = mul i64 %t171, 1
  %t174 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t173)
  call void @llvm.memcpy.p0.p0.i64(ptr %t174, ptr %t172, i64 %t173, i1 false)
  %t175 = insertvalue { i64, ptr } undef, i64 %t171, 0
  %t176 = insertvalue { i64, ptr } %t175, ptr %t174, 1
  %t178 = call i32 @std_2fio_2ePrint(ptr %s6, { i64, ptr } %t176)
  store i32 %t178, ptr %l140
  %t179 = icmp ne i32 %t178, 0
  br i1 %t179, label %bb51, label %ok.180
ok.180:
  br label %bb50
bb50:
  br label %bb55
bb51:
  %t181 = load i32, ptr %l140, !tbaa !23
  %t182 = ashr i32 %t181, 16
  %t184 = icmp eq i32 %t182, 1
  br i1 %t184, label %bb52, label %bb53
bb52:
  br label %bb54
bb53:
  %t186 = load i32, ptr %l140, !tbaa !23
  %t187 = lshr i32 %t186, 16
  %t188 = and i32 %t186, 65535
  %t189 = icmp eq i32 %t187, 1
  %t190 = select i1 %t189, i32 0, i32 0
  %t191 = icmp eq i32 %t186, 0
  %t192 = shl i32 %t190, 16
  %t193 = or i32 %t192, %t188
  %t194 = select i1 %t191, i32 0, i32 %t193
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t194, ptr %rv
  br label %ret
bb54:
  call void @__olang_ert_req_clear()
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s6)
  br label %bb56
bb56:
  %t196 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d116, i32 0, i32 1) })
  %t197 = extractvalue { i32, { i64, ptr } } %t196, 1
  %t198 = extractvalue { i32, { i64, ptr } } %t196, 0
  store i32 %t198, ptr %l146
  %t199 = icmp ne i32 %t198, 0
  br i1 %t199, label %bb58, label %ok.200
ok.200:
  store { i64, ptr } %t197, ptr %l145
  br label %bb57
bb57:
  %t201 = load { i64, ptr }, ptr %l145, !tbaa !27
  store { i64, ptr } %t201, ptr %l144, !tbaa !27
  br label %bb60
bb58:
  br label %bb59
bb59:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d117, i32 0, i32 1) }, ptr %l147, !tbaa !27
  %t202 = load { i64, ptr }, ptr %l147, !tbaa !27
  %t204 = extractvalue { i64, ptr } %t202, 0
  %t205 = extractvalue { i64, ptr } %t202, 1
  %t206 = mul i64 %t204, 1
  %t207 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t206)
  call void @llvm.memcpy.p0.p0.i64(ptr %t207, ptr %t205, i64 %t206, i1 false)
  %t208 = insertvalue { i64, ptr } undef, i64 %t204, 0
  %t209 = insertvalue { i64, ptr } %t208, ptr %t207, 1
  store { i64, ptr } %t209, ptr %l144, !tbaa !27
  br label %bb60
bb60:
  %t211 = load { i64, ptr }, ptr %l144, !tbaa !27
  %t212 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t211, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d118, i32 0, i32 1) })
  store i1 %t212, ptr %l150
  br label %bb61
bb61:
  %t213 = load i1, ptr %l150, !tbaa !21
  %t214 = xor i1 %t213, true
  br i1 %t214, label %bb62, label %bb63
bb62:
  store %olang.scope zeroinitializer, ptr %s8
  %t216 = load ptr, ptr %l13, !tbaa !29
  %t218 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2eDump(ptr %v2, ptr %s8, ptr %t216)
  store { i64, ptr } %t218, ptr %l153
  br label %bb64
bb63:
  br label %bb71
bb64:
  %t219 = load { i64, ptr }, ptr %l153, !tbaa !27
  %t220 = extractvalue { i64, ptr } %t219, 0
  %t221 = extractvalue { i64, ptr } %t219, 1
  %t222 = mul i64 %t220, 1
  %t223 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t222)
  call void @llvm.memcpy.p0.p0.i64(ptr %t223, ptr %t221, i64 %t222, i1 false)
  %t224 = insertvalue { i64, ptr } undef, i64 %t220, 0
  %t225 = insertvalue { i64, ptr } %t224, ptr %t223, 1
  %t227 = call i32 @std_2fio_2ePrintErr(ptr %s8, { i64, ptr } %t225)
  store i32 %t227, ptr %l155
  %t228 = icmp ne i32 %t227, 0
  br i1 %t228, label %bb66, label %ok.229
ok.229:
  br label %bb65
bb65:
  br label %bb70
bb66:
  %t230 = load i32, ptr %l155, !tbaa !23
  %t231 = ashr i32 %t230, 16
  %t233 = icmp eq i32 %t231, 1
  br i1 %t233, label %bb67, label %bb68
bb67:
  br label %bb69
bb68:
  %t235 = load i32, ptr %l155, !tbaa !23
  %t236 = lshr i32 %t235, 16
  %t237 = and i32 %t235, 65535
  %t238 = icmp eq i32 %t236, 1
  %t239 = select i1 %t238, i32 0, i32 0
  %t240 = icmp eq i32 %t235, 0
  %t241 = shl i32 %t239, 16
  %t242 = or i32 %t241, %t237
  %t243 = select i1 %t240, i32 0, i32 %t242
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t243, ptr %rv
  br label %ret
bb69:
  call void @__olang_ert_req_clear()
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s8)
  br label %bb71
bb71:
  %t245 = load ptr, ptr %l5, !tbaa !29
  %t247 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v2, ptr %t245)
  store i64 %t247, ptr %l160
  br label %bb72
bb72:
  %t248 = load i64, ptr %l160, !tbaa !24
  %t249 = icmp sgt i64 %t248, 0
  br i1 %t249, label %bb73, label %bb74
bb73:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb74:
  br label %bb75
bb75:
  %t252 = load ptr, ptr %l8, !tbaa !29
  %t253 = load ptr, ptr %l12, !tbaa !29
  %t254 = load ptr, ptr %l5, !tbaa !29
  %t255 = load ptr, ptr %l3, !tbaa !29
  %t256 = load i32, ptr %l2
  %t257 = load ptr, ptr %l11, !tbaa !29
  %t264 = call ptr @compiler_2folang_2eemitter(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %t252, ptr %t253, ptr %t254, ptr %t255, i32 %t256, ptr %t257)
  store ptr %t264, ptr %l169
  br label %bb76
bb76:
  %t265 = load ptr, ptr %l169, !tbaa !29
  store ptr %t265, ptr %l14, !tbaa !29
  %t266 = icmp sge i64 0, 0
  br i1 %t266, label %bb77, label %bb78
bb77:
  %t268 = icmp sle i64 0, 576460752303423487
  br i1 %t268, label %bb79, label %bb80
bb78:
  call void @__olang_check_failed(ptr @olang_loc_1d5612d13136b02e_cf27d9d671de6fa2)
  unreachable
bb79:
  %t270 = mul i64 0, 16
  %t271 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t270)
  %t272 = insertvalue { i64, ptr } undef, i64 0, 0
  %t273 = insertvalue { i64, ptr } %t272, ptr %t271, 1
  store { i64, ptr } %t273, ptr %l15, !tbaa !27
  %t275 = load i32, ptr %l2
  %t277 = trunc i64 0 to i32
  %t278 = icmp eq i32 %t275, %t277
  %t280 = xor i1 %t278, true
  br i1 %t280, label %bb81, label %bb82
bb80:
  call void @__olang_check_failed(ptr @olang_loc_1d5612d13136b02e_cf27d9d671de6fa2)
  unreachable
bb81:
  %t282 = load ptr, ptr %l7, !tbaa !29
  %t283 = load ptr, ptr %l3, !tbaa !29
  %t284 = load i1, ptr %l6, !tbaa !21
  %t288 = call { i64, ptr } @compiler_2folang_2emoduleKeys(ptr %v2, ptr %v2, ptr %t282, ptr %t283, i1 %t284)
  store { i64, ptr } %t288, ptr %l179
  br label %bb83
bb82:
  br label %bb85
bb83:
  %t289 = load { i64, ptr }, ptr %l179, !tbaa !27
  store { i64, ptr } %t289, ptr %l15, !tbaa !27
  %t290 = load ptr, ptr %l14, !tbaa !29
  store ptr %t290, ptr %l180, !tbaa !29
  %t291 = load ptr, ptr %l7, !tbaa !29
  %t292 = load ptr, ptr %l3, !tbaa !29
  %t293 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t297 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2folang_2ereusable(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %t291, ptr %t292, { i64, ptr } %t293)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t297, ptr %l184
  br label %bb84
bb84:
  %t298 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l184
  %t299 = load ptr, ptr %l180, !tbaa !29
  %t300 = getelementptr %"compiler/emit:Emitter", ptr %t299, i32 0, i32 60
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t298, ptr %t300
  br label %bb85
bb85:
  %t301 = load ptr, ptr %l14, !tbaa !29
  %t303 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2ecompiler_2femit_3aEmitter_2eObjects(ptr %v2, ptr %v3, ptr %t301)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t303, ptr %l186
  br label %bb86
bb86:
  %t304 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l186
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t304, ptr %l16
  %t305 = load ptr, ptr %l14, !tbaa !29
  %t307 = getelementptr %"compiler/emit:Emitter", ptr %t305, i32 0, i32 63
  %t308 = load i1, ptr %t307, !tbaa !21
  br i1 %t308, label %bb87, label %bb88
bb87:
  %t310 = load ptr, ptr %l8, !tbaa !29
  %t311 = load ptr, ptr %l12, !tbaa !29
  %t312 = load ptr, ptr %l5, !tbaa !29
  %t313 = load ptr, ptr %l3, !tbaa !29
  %t314 = load i32, ptr %l2
  %t315 = load ptr, ptr %l11, !tbaa !29
  %t322 = call ptr @compiler_2folang_2eemitter(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %t310, ptr %t311, ptr %t312, ptr %t313, i32 %t314, ptr %t315)
  store ptr %t322, ptr %l195
  br label %bb89
bb88:
  br label %bb91
bb89:
  %t323 = load ptr, ptr %l195, !tbaa !29
  store ptr %t323, ptr %l14, !tbaa !29
  %t324 = load ptr, ptr %l14, !tbaa !29
  %t326 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2ecompiler_2femit_3aEmitter_2eObjects(ptr %v2, ptr %v3, ptr %t324)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t326, ptr %l197
  br label %bb90
bb90:
  %t327 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l197
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t327, ptr %l16
  br label %bb91
bb91:
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d119, i32 0, i32 1) })
  br label %bb92
bb92:
  %t328 = load ptr, ptr %l14, !tbaa !29
  %t330 = getelementptr %"compiler/emit:Emitter", ptr %t328, i32 0, i32 9
  %t332 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v2, ptr %t330)
  store i64 %t332, ptr %l200
  br label %bb93
bb93:
  %t333 = load i64, ptr %l200, !tbaa !24
  %t334 = icmp sgt i64 %t333, 0
  br i1 %t334, label %bb94, label %bb95
bb94:
  store i1 true, ptr %l202, !tbaa !21
  br label %bb97
bb95:
  %t336 = load ptr, ptr %l12, !tbaa !29
  %t338 = getelementptr %"compiler/lower:Lowerer", ptr %t336, i32 0, i32 4
  %t340 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3aGap_3e_2eLen_3ccompiler_2flower_3aGap_3e(ptr %v2, ptr %t338)
  store i64 %t340, ptr %l205
  br label %bb96
bb96:
  %t341 = load i64, ptr %l205, !tbaa !24
  %t342 = icmp sgt i64 %t341, 0
  store i1 %t342, ptr %l202, !tbaa !21
  br label %bb97
bb97:
  %t344 = load i1, ptr %l202, !tbaa !21
  br i1 %t344, label %bb98, label %bb99
bb98:
  %t345 = load ptr, ptr %l14, !tbaa !29
  %t347 = getelementptr %"compiler/emit:Emitter", ptr %t345, i32 0, i32 9
  store ptr %t347, ptr %l17, !tbaa !29
  store i64 0, ptr %l18, !tbaa !24
  br label %bb100
bb99:
  br label %bb133
bb100:
  store %olang.scope zeroinitializer, ptr %s15
  %t349 = load ptr, ptr %l17, !tbaa !29
  %t350 = load i64, ptr %l18, !tbaa !24
  %t353 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v2, ptr %t349, i64 %t350)
  %t354 = extractvalue { i32, { i64, ptr } } %t353, 1
  %t355 = extractvalue { i32, { i64, ptr } } %t353, 0
  store i32 %t355, ptr %l213
  %t356 = icmp ne i32 %t355, 0
  br i1 %t356, label %bb102, label %ok.357
ok.357:
  store { i64, ptr } %t354, ptr %l212
  br label %bb101
bb101:
  %t358 = load { i64, ptr }, ptr %l212, !tbaa !27
  store { i64, ptr } %t358, ptr %l209, !tbaa !27
  br label %bb106
bb102:
  %t359 = load i32, ptr %l213, !tbaa !23
  %t360 = ashr i32 %t359, 16
  %t362 = icmp eq i32 %t360, 1
  br i1 %t362, label %bb103, label %bb104
bb103:
  br label %bb105
bb104:
  %t364 = load i32, ptr %l213, !tbaa !23
  %t365 = lshr i32 %t364, 16
  %t366 = and i32 %t364, 65535
  %t367 = icmp eq i32 %t365, 1
  %t368 = select i1 %t367, i32 0, i32 0
  %t369 = icmp eq i32 %t364, 0
  %t370 = shl i32 %t368, 16
  %t371 = or i32 %t370, %t366
  %t372 = select i1 %t369, i32 0, i32 %t371
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t372, ptr %rv
  br label %ret
bb105:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s15)
  br label %bb115
bb106:
  %t374 = load { i64, ptr }, ptr %l209, !tbaa !27
  store { i64, ptr } %t374, ptr %l19, !tbaa !27
  %t375 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t377 = extractvalue { i64, ptr } %t375, 0
  store i64 %t377, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb107
bb107:
  store %olang.scope zeroinitializer, ptr %s16
  %t379 = load i64, ptr %l21, !tbaa !24
  %t380 = load i64, ptr %l20, !tbaa !24
  %t383 = icmp slt i64 %t379, %t380
  %t385 = xor i1 %t383, true
  br i1 %t385, label %bb108, label %bb109
bb108:
  call void @__olang_scope_close(ptr %s16)
  br label %bb113
bb109:
  br label %bb110
bb110:
  %t387 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t387, ptr %l223, !tbaa !27
  %t388 = load i64, ptr %l21, !tbaa !24
  %t390 = getelementptr { i64, ptr }, ptr %l223, i32 0, i32 1
  %t391 = load ptr, ptr %t390, !tbaa !27
  %t392 = getelementptr { i64, ptr }, ptr %t391, i64 %t388
  %t393 = load { i64, ptr }, ptr %t392, !tbaa !37
  %t396 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d120, i32 0, i32 1) }, 1
  %t397 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d120, i32 0, i32 1) }, 0
  %t399 = extractvalue { i64, ptr } %t393, 1
  %t400 = extractvalue { i64, ptr } %t393, 0
  %t401 = add i64 %t397, %t400
  %t402 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d121, i32 0, i32 1) }, 1
  %t403 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d121, i32 0, i32 1) }, 0
  %t404 = add i64 %t401, %t403
  %t405 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t404)
  call void @olang_textcopy(ptr %t405, ptr %t396, i64 %t397)
  %t406 = getelementptr i8, ptr %t405, i64 %t397
  call void @olang_textcopy(ptr %t406, ptr %t399, i64 %t400)
  %t407 = getelementptr i8, ptr %t406, i64 %t400
  call void @olang_textcopy(ptr %t407, ptr %t402, i64 %t403)
  %t408 = insertvalue { i64, ptr } undef, i64 %t404, 0
  %t409 = insertvalue { i64, ptr } %t408, ptr %t405, 1
  %t411 = extractvalue { i64, ptr } %t409, 0
  %t412 = extractvalue { i64, ptr } %t409, 1
  %t413 = mul i64 %t411, 1
  %t414 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t413)
  call void @llvm.memcpy.p0.p0.i64(ptr %t414, ptr %t412, i64 %t413, i1 false)
  %t415 = insertvalue { i64, ptr } undef, i64 %t411, 0
  %t416 = insertvalue { i64, ptr } %t415, ptr %t414, 1
  call void @compiler_2fbuild_2eUnbuildable(ptr %s16, { i64, ptr } %t416)
  br label %bb111
bb111:
  call void @__olang_scope_close(ptr %s16)
  br label %bb112
bb112:
  %t418 = load i64, ptr %l21, !tbaa !24
  %t420 = add i64 %t418, 1
  store i64 %t420, ptr %l21, !tbaa !24
  br label %bb107
bb113:
  %t422 = load i64, ptr %l18, !tbaa !24
  %t423 = load i64, ptr %l20, !tbaa !24
  %t426 = add i64 %t422, %t423
  store i64 %t426, ptr %l18, !tbaa !24
  call void @__olang_scope_close(ptr %s15)
  br label %bb114
bb114:
  br label %bb100
bb115:
  %t428 = load ptr, ptr %l12, !tbaa !29
  %t430 = getelementptr %"compiler/lower:Lowerer", ptr %t428, i32 0, i32 4
  store ptr %t430, ptr %l23, !tbaa !29
  store i64 0, ptr %l24, !tbaa !24
  br label %bb116
bb116:
  store %olang.scope zeroinitializer, ptr %s20
  %t432 = load ptr, ptr %l23, !tbaa !29
  %t433 = load i64, ptr %l24, !tbaa !24
  %t436 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3aGap_3e_2eRunFrom_3ccompiler_2flower_3aGap_3e(ptr %v2, ptr %t432, i64 %t433)
  %t437 = extractvalue { i32, { i64, ptr } } %t436, 1
  %t438 = extractvalue { i32, { i64, ptr } } %t436, 0
  store i32 %t438, ptr %l240
  %t439 = icmp ne i32 %t438, 0
  br i1 %t439, label %bb118, label %ok.440
ok.440:
  store { i64, ptr } %t437, ptr %l239
  br label %bb117
bb117:
  %t441 = load { i64, ptr }, ptr %l239, !tbaa !27
  store { i64, ptr } %t441, ptr %l236, !tbaa !27
  br label %bb122
bb118:
  %t442 = load i32, ptr %l240, !tbaa !23
  %t443 = ashr i32 %t442, 16
  %t445 = icmp eq i32 %t443, 1
  br i1 %t445, label %bb119, label %bb120
bb119:
  br label %bb121
bb120:
  %t447 = load i32, ptr %l240, !tbaa !23
  %t448 = lshr i32 %t447, 16
  %t449 = and i32 %t447, 65535
  %t450 = icmp eq i32 %t448, 1
  %t451 = select i1 %t450, i32 0, i32 0
  %t452 = icmp eq i32 %t447, 0
  %t453 = shl i32 %t451, 16
  %t454 = or i32 %t453, %t449
  %t455 = select i1 %t452, i32 0, i32 %t454
  call void @__olang_scope_close(ptr %s20)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t455, ptr %rv
  br label %ret
bb121:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s20)
  br label %bb132
bb122:
  %t457 = load { i64, ptr }, ptr %l236, !tbaa !27
  store { i64, ptr } %t457, ptr %l25, !tbaa !27
  %t458 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t460 = extractvalue { i64, ptr } %t458, 0
  store i64 %t460, ptr %l26, !tbaa !24
  store i64 0, ptr %l27, !tbaa !24
  br label %bb123
bb123:
  store %olang.scope zeroinitializer, ptr %s21
  %t462 = load i64, ptr %l27, !tbaa !24
  %t463 = load i64, ptr %l26, !tbaa !24
  %t466 = icmp slt i64 %t462, %t463
  %t468 = xor i1 %t466, true
  br i1 %t468, label %bb124, label %bb125
bb124:
  call void @__olang_scope_close(ptr %s21)
  br label %bb130
bb125:
  br label %bb126
bb126:
  %t470 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t470, ptr %l250, !tbaa !27
  %t471 = load i64, ptr %l27, !tbaa !24
  %t473 = getelementptr { i64, ptr }, ptr %l250, i32 0, i32 1
  %t474 = load ptr, ptr %t473, !tbaa !27
  %t475 = getelementptr %"compiler/lower:Gap", ptr %t474, i64 %t471
  %t476 = load %"compiler/lower:Gap", ptr %t475
  store %"compiler/lower:Gap" %t476, ptr %l28
  %t478 = load ptr, ptr %l5, !tbaa !29
  %t479 = getelementptr %"compiler/lower:Gap", ptr %l28, i32 0, i32 0
  %t480 = load i64, ptr %t479, !tbaa !24
  %t481 = getelementptr %"compiler/lower:Gap", ptr %l28, i32 0, i32 1
  %t482 = getelementptr %"compiler/source:Span", ptr %t481, i32 0, i32 0
  %t483 = load i32, ptr %t482, !tbaa !23
  %t485 = sext i32 %t483 to i64
  %t489 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v2, ptr %s21, ptr %t478, i64 %t480, i64 %t485)
  store { i64, ptr } %t489, ptr %l257
  br label %bb127
bb127:
  %t490 = getelementptr %"compiler/lower:Gap", ptr %l28, i32 0, i32 2
  %t491 = load { i64, ptr }, ptr %t490, !tbaa !27
  %t492 = load { i64, ptr }, ptr %l257, !tbaa !27
  %t493 = extractvalue { i64, ptr } %t492, 1
  %t494 = extractvalue { i64, ptr } %t492, 0
  %t495 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d122, i32 0, i32 1) }, 1
  %t496 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d122, i32 0, i32 1) }, 0
  %t497 = add i64 %t494, %t496
  %t499 = extractvalue { i64, ptr } %t491, 1
  %t500 = extractvalue { i64, ptr } %t491, 0
  %t501 = add i64 %t497, %t500
  %t502 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d123, i32 0, i32 1) }, 1
  %t503 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d123, i32 0, i32 1) }, 0
  %t504 = add i64 %t501, %t503
  %t505 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t504)
  call void @olang_textcopy(ptr %t505, ptr %t493, i64 %t494)
  %t506 = getelementptr i8, ptr %t505, i64 %t494
  call void @olang_textcopy(ptr %t506, ptr %t495, i64 %t496)
  %t507 = getelementptr i8, ptr %t506, i64 %t496
  call void @olang_textcopy(ptr %t507, ptr %t499, i64 %t500)
  %t508 = getelementptr i8, ptr %t507, i64 %t500
  call void @olang_textcopy(ptr %t508, ptr %t502, i64 %t503)
  %t509 = insertvalue { i64, ptr } undef, i64 %t504, 0
  %t510 = insertvalue { i64, ptr } %t509, ptr %t505, 1
  %t512 = extractvalue { i64, ptr } %t510, 0
  %t513 = extractvalue { i64, ptr } %t510, 1
  %t514 = mul i64 %t512, 1
  %t515 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t514)
  call void @llvm.memcpy.p0.p0.i64(ptr %t515, ptr %t513, i64 %t514, i1 false)
  %t516 = insertvalue { i64, ptr } undef, i64 %t512, 0
  %t517 = insertvalue { i64, ptr } %t516, ptr %t515, 1
  call void @compiler_2fbuild_2eUnbuildable(ptr %s21, { i64, ptr } %t517)
  br label %bb128
bb128:
  call void @__olang_scope_close(ptr %s21)
  br label %bb129
bb129:
  %t519 = load i64, ptr %l27, !tbaa !24
  %t521 = add i64 %t519, 1
  store i64 %t521, ptr %l27, !tbaa !24
  br label %bb123
bb130:
  %t523 = load i64, ptr %l24, !tbaa !24
  %t524 = load i64, ptr %l26, !tbaa !24
  %t527 = add i64 %t523, %t524
  store i64 %t527, ptr %l24, !tbaa !24
  call void @__olang_scope_close(ptr %s20)
  br label %bb131
bb131:
  br label %bb116
bb132:
  call void @__olang_scope_close(ptr %s0)
  store i32 65537, ptr %rv
  br label %ret
bb133:
  %t530 = load ptr, ptr %l5, !tbaa !29
  %t532 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v2, ptr %t530)
  store i64 %t532, ptr %l268
  br label %bb134
bb134:
  %t533 = load i64, ptr %l268, !tbaa !24
  %t534 = icmp sgt i64 %t533, 0
  br i1 %t534, label %bb135, label %bb136
bb135:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb136:
  br label %bb137
bb137:
  %t537 = load ptr, ptr %l3, !tbaa !29
  %t539 = getelementptr %"compiler/build:Config", ptr %t537, i32 0, i32 2
  %t540 = load %"compiler/target:Target", ptr %t539
  store %"compiler/target:Target" %t540, ptr %l29
  store i1 false, ptr %l30, !tbaa !21
  %t542 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t542, ptr %l273
  br label %bb138
bb138:
  %t543 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l273
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t543, ptr %l31
  store ptr %l16, ptr %l32, !tbaa !29
  store i64 0, ptr %l33, !tbaa !24
  br label %bb139
bb139:
  store %olang.scope zeroinitializer, ptr %s26
  %t545 = load ptr, ptr %l32, !tbaa !29
  %t546 = load i64, ptr %l33, !tbaa !24
  %t549 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aObject_3e_2eRunFrom_3ccompiler_2femit_3aObject_3e(ptr %v3, ptr %t545, i64 %t546)
  %t550 = extractvalue { i32, { i64, ptr } } %t549, 1
  %t551 = extractvalue { i32, { i64, ptr } } %t549, 0
  store i32 %t551, ptr %l279
  %t552 = icmp ne i32 %t551, 0
  br i1 %t552, label %bb141, label %ok.553
ok.553:
  store { i64, ptr } %t550, ptr %l278
  br label %bb140
bb140:
  %t554 = load { i64, ptr }, ptr %l278, !tbaa !27
  store { i64, ptr } %t554, ptr %l275, !tbaa !27
  br label %bb145
bb141:
  %t555 = load i32, ptr %l279, !tbaa !23
  %t556 = ashr i32 %t555, 16
  %t558 = icmp eq i32 %t556, 1
  br i1 %t558, label %bb142, label %bb143
bb142:
  br label %bb144
bb143:
  %t560 = load i32, ptr %l279, !tbaa !23
  %t561 = lshr i32 %t560, 16
  %t562 = and i32 %t560, 65535
  %t563 = icmp eq i32 %t561, 1
  %t564 = select i1 %t563, i32 0, i32 0
  %t565 = icmp eq i32 %t560, 0
  %t566 = shl i32 %t564, 16
  %t567 = or i32 %t566, %t562
  %t568 = select i1 %t565, i32 0, i32 %t567
  call void @__olang_scope_close(ptr %s26)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t568, ptr %rv
  br label %ret
bb144:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s26)
  br label %bb239
bb145:
  %t570 = load { i64, ptr }, ptr %l275, !tbaa !27
  store { i64, ptr } %t570, ptr %l34, !tbaa !27
  %t571 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t573 = extractvalue { i64, ptr } %t571, 0
  store i64 %t573, ptr %l35, !tbaa !24
  store i64 0, ptr %l36, !tbaa !24
  br label %bb146
bb146:
  store %olang.scope zeroinitializer, ptr %s27
  %t575 = load i64, ptr %l36, !tbaa !24
  %t576 = load i64, ptr %l35, !tbaa !24
  %t579 = icmp slt i64 %t575, %t576
  %t581 = xor i1 %t579, true
  br i1 %t581, label %bb147, label %bb148
bb147:
  call void @__olang_scope_close(ptr %s27)
  br label %bb237
bb148:
  br label %bb149
bb149:
  %t583 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t583, ptr %l289, !tbaa !27
  %t584 = load i64, ptr %l36, !tbaa !24
  %t586 = getelementptr { i64, ptr }, ptr %l289, i32 0, i32 1
  %t587 = load ptr, ptr %t586, !tbaa !27
  %t588 = getelementptr %"compiler/emit:Object", ptr %t587, i64 %t584
  %t589 = load %"compiler/emit:Object", ptr %t588
  store %"compiler/emit:Object" %t589, ptr %l37
  %t591 = getelementptr %"compiler/emit:Object", ptr %l37, i32 0, i32 3
  %t592 = load i64, ptr %t591, !tbaa !24
  %t594 = icmp sge i64 %t592, 0
  br i1 %t594, label %bb150, label %bb151
bb150:
  store %olang.scope zeroinitializer, ptr %s28
  %t596 = load ptr, ptr %l14, !tbaa !29
  %t598 = getelementptr %"compiler/emit:Emitter", ptr %t596, i32 0, i32 60
  %t599 = getelementptr %"compiler/emit:Object", ptr %l37, i32 0, i32 3
  %t600 = load i64, ptr %t599, !tbaa !24
  %t603 = call %"compiler/emit:Reused" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aReused_3e_2eAt_3ccompiler_2femit_3aReused_3e(ptr %v2, ptr %v2, ptr %t598, i64 %t600)
  store %"compiler/emit:Reused" %t603, ptr %l297
  br label %bb152
bb151:
  br label %bb193
bb152:
  %t604 = load %"compiler/emit:Reused", ptr %l297
  store %"compiler/emit:Reused" %t604, ptr %l38
  %t605 = load ptr, ptr %l3, !tbaa !29
  store ptr %t605, ptr %l298, !tbaa !29
  %t606 = load ptr, ptr %l7, !tbaa !29
  %t608 = getelementptr %"compiler/load:Loader", ptr %t606, i32 0, i32 5
  %t609 = getelementptr %"compiler/emit:Reused", ptr %l38, i32 0, i32 0
  %t610 = load i64, ptr %t609, !tbaa !24
  %t613 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v2, ptr %v2, ptr %t608, i64 %t610)
  store ptr %t613, ptr %l302
  br label %bb153
bb153:
  %t614 = load ptr, ptr %l302, !tbaa !29
  %t616 = getelementptr %"compiler/load:Module", ptr %t614, i32 0, i32 2
  %t617 = load { i64, ptr }, ptr %t616, !tbaa !27
  %t618 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t618, ptr %l305, !tbaa !27
  %t619 = getelementptr %"compiler/emit:Reused", ptr %l38, i32 0, i32 0
  %t620 = load i64, ptr %t619, !tbaa !24
  %t622 = getelementptr { i64, ptr }, ptr %l305, i32 0, i32 1
  %t623 = load ptr, ptr %t622, !tbaa !27
  %t624 = getelementptr { i64, ptr }, ptr %t623, i64 %t620
  %t625 = load { i64, ptr }, ptr %t624, !tbaa !37
  %t626 = load ptr, ptr %l298, !tbaa !29
  %t629 = call { i64, ptr } @compiler_2folang_2erecordPath(ptr %v2, ptr %v2, ptr %v2, ptr %s28, ptr %t626, { i64, ptr } %t617, { i64, ptr } %t625)
  store { i64, ptr } %t629, ptr %l308
  br label %bb154
bb154:
  %t630 = load { i64, ptr }, ptr %l308, !tbaa !27
  store { i64, ptr } %t630, ptr %l39, !tbaa !27
  %t631 = getelementptr %"compiler/emit:Reused", ptr %l38, i32 0, i32 1
  store ptr %t631, ptr %l40, !tbaa !29
  store i64 0, ptr %l41, !tbaa !24
  store i64 0, ptr %l42, !tbaa !24
  br label %bb155
bb155:
  store %olang.scope zeroinitializer, ptr %s30
  %t633 = load ptr, ptr %l40, !tbaa !29
  %t634 = load i64, ptr %l41, !tbaa !24
  %t637 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v2, ptr %t633, i64 %t634)
  %t638 = extractvalue { i32, { i64, ptr } } %t637, 1
  %t639 = extractvalue { i32, { i64, ptr } } %t637, 0
  store i32 %t639, ptr %l314
  %t640 = icmp ne i32 %t639, 0
  br i1 %t640, label %bb157, label %ok.641
ok.641:
  store { i64, ptr } %t638, ptr %l313
  br label %bb156
bb156:
  %t642 = load { i64, ptr }, ptr %l313, !tbaa !27
  store { i64, ptr } %t642, ptr %l310, !tbaa !27
  br label %bb161
bb157:
  %t643 = load i32, ptr %l314, !tbaa !23
  %t644 = ashr i32 %t643, 16
  %t646 = icmp eq i32 %t644, 1
  br i1 %t646, label %bb158, label %bb159
bb158:
  br label %bb160
bb159:
  %t648 = load i32, ptr %l314, !tbaa !23
  %t649 = lshr i32 %t648, 16
  %t650 = and i32 %t648, 65535
  %t651 = icmp eq i32 %t649, 1
  %t652 = select i1 %t651, i32 0, i32 0
  %t653 = icmp eq i32 %t648, 0
  %t654 = shl i32 %t652, 16
  %t655 = or i32 %t654, %t650
  %t656 = select i1 %t653, i32 0, i32 %t655
  call void @__olang_scope_close(ptr %s30)
  call void @__olang_scope_close(ptr %s28)
  call void @__olang_scope_close(ptr %s27)
  call void @__olang_scope_close(ptr %s26)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t656, ptr %rv
  br label %ret
bb160:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s30)
  br label %bb191
bb161:
  %t658 = load { i64, ptr }, ptr %l310, !tbaa !27
  store { i64, ptr } %t658, ptr %l43, !tbaa !27
  %t659 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t661 = extractvalue { i64, ptr } %t659, 0
  store i64 %t661, ptr %l44, !tbaa !24
  store i64 0, ptr %l45, !tbaa !24
  br label %bb162
bb162:
  store %olang.scope zeroinitializer, ptr %s31
  %t663 = load i64, ptr %l45, !tbaa !24
  %t664 = load i64, ptr %l44, !tbaa !24
  %t667 = icmp slt i64 %t663, %t664
  %t669 = xor i1 %t667, true
  br i1 %t669, label %bb163, label %bb164
bb163:
  call void @__olang_scope_close(ptr %s31)
  br label %bb189
bb164:
  br label %bb165
bb165:
  %t671 = load i64, ptr %l42, !tbaa !24
  store i64 %t671, ptr %l46, !tbaa !24
  %t673 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t673, ptr %l325, !tbaa !27
  %t674 = load i64, ptr %l45, !tbaa !24
  %t676 = getelementptr { i64, ptr }, ptr %l325, i32 0, i32 1
  %t677 = load ptr, ptr %t676, !tbaa !27
  %t678 = getelementptr { i64, ptr }, ptr %t677, i64 %t674
  %t679 = load { i64, ptr }, ptr %t678, !tbaa !37
  store { i64, ptr } %t679, ptr %l47, !tbaa !27
  %t681 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t682 = load i64, ptr %l46, !tbaa !24
  %t684 = extractvalue { i64, ptr } %t681, 1
  %t685 = extractvalue { i64, ptr } %t681, 0
  %t686 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d124, i32 0, i32 1) }, 1
  %t687 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d124, i32 0, i32 1) }, 0
  %t688 = add i64 %t685, %t687
  %t690 = call i64 @__olang_fmt_i64(ptr null, i64 %t682)
  %t691 = add i64 %t688, %t690
  %t692 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d125, i32 0, i32 1) }, 1
  %t693 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d125, i32 0, i32 1) }, 0
  %t694 = add i64 %t691, %t693
  %t695 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t694)
  call void @olang_textcopy(ptr %t695, ptr %t684, i64 %t685)
  %t696 = getelementptr i8, ptr %t695, i64 %t685
  call void @olang_textcopy(ptr %t696, ptr %t686, i64 %t687)
  %t697 = getelementptr i8, ptr %t696, i64 %t687
  %t698 = call i64 @__olang_fmt_i64(ptr %t697, i64 %t682)
  %t699 = getelementptr i8, ptr %t697, i64 %t690
  call void @olang_textcopy(ptr %t699, ptr %t692, i64 %t693)
  %t700 = insertvalue { i64, ptr } undef, i64 %t694, 0
  %t701 = insertvalue { i64, ptr } %t700, ptr %t695, 1
  %t703 = extractvalue { i64, ptr } %t701, 0
  %t704 = extractvalue { i64, ptr } %t701, 1
  %t705 = mul i64 %t703, 1
  %t706 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t705)
  call void @llvm.memcpy.p0.p0.i64(ptr %t706, ptr %t704, i64 %t705, i1 false)
  %t707 = insertvalue { i64, ptr } undef, i64 %t703, 0
  %t708 = insertvalue { i64, ptr } %t707, ptr %t706, 1
  %t710 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v3, ptr %v3, { i64, ptr } %t708)
  %t711 = extractvalue { i32, { i64, ptr } } %t710, 1
  %t712 = extractvalue { i32, { i64, ptr } } %t710, 0
  store i32 %t712, ptr %l334
  %t713 = icmp ne i32 %t712, 0
  br i1 %t713, label %bb167, label %ok.714
ok.714:
  store { i64, ptr } %t711, ptr %l333
  br label %bb166
bb166:
  %t715 = load { i64, ptr }, ptr %l333, !tbaa !27
  store { i64, ptr } %t715, ptr %l328, !tbaa !27
  br label %bb172
bb167:
  %t716 = load i32, ptr %l334, !tbaa !23
  %t717 = ashr i32 %t716, 16
  %t719 = icmp eq i32 %t717, 1
  br i1 %t719, label %bb168, label %bb169
bb168:
  br label %bb170
bb169:
  %t721 = load i32, ptr %l334, !tbaa !23
  %t722 = lshr i32 %t721, 16
  %t723 = and i32 %t721, 65535
  %t724 = icmp eq i32 %t722, 1
  %t725 = select i1 %t724, i32 0, i32 0
  %t726 = icmp eq i32 %t721, 0
  %t727 = shl i32 %t725, 16
  %t728 = or i32 %t727, %t723
  %t729 = select i1 %t726, i32 0, i32 %t728
  call void @__olang_scope_close(ptr %s31)
  call void @__olang_scope_close(ptr %s30)
  call void @__olang_scope_close(ptr %s28)
  call void @__olang_scope_close(ptr %s27)
  call void @__olang_scope_close(ptr %s26)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t729, ptr %rv
  br label %ret
bb170:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s33
  %t731 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t732 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d126, i32 0, i32 1) }, 1
  %t733 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d126, i32 0, i32 1) }, 0
  %t735 = extractvalue { i64, ptr } %t731, 1
  %t736 = extractvalue { i64, ptr } %t731, 0
  %t737 = add i64 %t733, %t736
  %t738 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d127, i32 0, i32 1) }, 1
  %t739 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d127, i32 0, i32 1) }, 0
  %t740 = add i64 %t737, %t739
  %t741 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t740)
  call void @olang_textcopy(ptr %t741, ptr %t732, i64 %t733)
  %t742 = getelementptr i8, ptr %t741, i64 %t733
  call void @olang_textcopy(ptr %t742, ptr %t735, i64 %t736)
  %t743 = getelementptr i8, ptr %t742, i64 %t736
  call void @olang_textcopy(ptr %t743, ptr %t738, i64 %t739)
  %t744 = insertvalue { i64, ptr } undef, i64 %t740, 0
  %t745 = insertvalue { i64, ptr } %t744, ptr %t741, 1
  %t747 = extractvalue { i64, ptr } %t745, 0
  %t748 = extractvalue { i64, ptr } %t745, 1
  %t749 = mul i64 %t747, 1
  %t750 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t749)
  call void @llvm.memcpy.p0.p0.i64(ptr %t750, ptr %t748, i64 %t749, i1 false)
  %t751 = insertvalue { i64, ptr } undef, i64 %t747, 0
  %t752 = insertvalue { i64, ptr } %t751, ptr %t750, 1
  call void @compiler_2fbuild_2eUnbuildable(ptr %s33, { i64, ptr } %t752)
  br label %bb171
bb171:
  call void @__olang_scope_close(ptr %s33)
  call void @__olang_scope_close(ptr %s31)
  call void @__olang_scope_close(ptr %s30)
  call void @__olang_scope_close(ptr %s28)
  call void @__olang_scope_close(ptr %s27)
  call void @__olang_scope_close(ptr %s26)
  call void @__olang_scope_close(ptr %s0)
  store i32 65537, ptr %rv
  br label %ret
bb172:
  %t755 = load { i64, ptr }, ptr %l328, !tbaa !27
  store { i64, ptr } %t755, ptr %l48, !tbaa !27
  %t756 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d128, i32 0, i32 1) }, ptr %l344, !tbaa !27
  %t759 = load { i64, ptr }, ptr %l344, !tbaa !27
  %t760 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v3, ptr %s31, { i64, ptr } %t756, { i64, ptr } %t759)
  store i1 %t760, ptr %l345
  br label %bb173
bb173:
  %t761 = load i1, ptr %l345, !tbaa !21
  br i1 %t761, label %bb174, label %bb175
bb174:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb176
bb175:
  br label %bb176
bb176:
  %t762 = load ptr, ptr %l14, !tbaa !29
  %t764 = getelementptr %"compiler/emit:Emitter", ptr %t762, i32 0, i32 6
  %t765 = load i1, ptr %t764, !tbaa !21
  br i1 %t765, label %bb177, label %bb178
bb177:
  %t767 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t769 = call { i64, ptr } @compiler_2folang_2elibraryIr(ptr %v3, ptr %v3, { i64, ptr } %t767)
  store { i64, ptr } %t769, ptr %l349
  br label %bb179
bb178:
  br label %bb180
bb179:
  %t770 = load { i64, ptr }, ptr %l349, !tbaa !27
  %t771 = extractvalue { i64, ptr } %t770, 0
  %t772 = extractvalue { i64, ptr } %t770, 1
  %t773 = mul i64 %t771, 1
  %t774 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t773)
  call void @llvm.memcpy.p0.p0.i64(ptr %t774, ptr %t772, i64 %t773, i1 false)
  %t775 = insertvalue { i64, ptr } undef, i64 %t771, 0
  %t776 = insertvalue { i64, ptr } %t775, ptr %t774, 1
  store { i64, ptr } %t776, ptr %l48, !tbaa !27
  br label %bb180
bb180:
  %t778 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t780 = extractvalue { i64, ptr } %t778, 1
  %t781 = extractvalue { i64, ptr } %t778, 0
  %t782 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t781)
  call void @olang_textcopy(ptr %t782, ptr %t780, i64 %t781)
  %t783 = insertvalue { i64, ptr } undef, i64 %t781, 0
  %t784 = insertvalue { i64, ptr } %t783, ptr %t782, 1
  %t786 = extractvalue { i64, ptr } %t784, 0
  %t787 = extractvalue { i64, ptr } %t784, 1
  %t788 = mul i64 %t786, 1
  %t789 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t788)
  call void @llvm.memcpy.p0.p0.i64(ptr %t789, ptr %t787, i64 %t788, i1 false)
  %t790 = insertvalue { i64, ptr } undef, i64 %t786, 0
  %t791 = insertvalue { i64, ptr } %t790, ptr %t789, 1
  store { i64, ptr } %t791, ptr %l353, !tbaa !27
  %t792 = getelementptr %"compiler/emit:Reused", ptr %l38, i32 0, i32 2
  %t793 = load i64, ptr %l46, !tbaa !24
  %t796 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v2, ptr %t792, i64 %t793)
  store i1 %t796, ptr %l356
  br label %bb181
bb181:
  %t797 = load i1, ptr %l356, !tbaa !21
  br i1 %t797, label %bb182, label %bb183
bb182:
  store i32 4, ptr %l357
  br label %bb184
bb183:
  store i32 0, ptr %l357
  br label %bb184
bb184:
  %t800 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t801 = load { i64, ptr }, ptr %l353, !tbaa !27
  %t802 = load i32, ptr %l357
  %t804 = call %"compiler/build:Unit" @compiler_2fbuild_3aUnit_2ector(ptr %v3, ptr %v3, ptr %v3, { i64, ptr } %t801, i32 %t802, { i64, ptr } %t800)
  store %"compiler/build:Unit" %t804, ptr %l361
  br label %bb185
bb185:
  %t805 = load %"compiler/build:Unit", ptr %l361
  %t806 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 56, i64 8)
  store %"compiler/build:Unit" %t805, ptr %t806
  store ptr %t806, ptr %l49, !tbaa !29
  %t808 = load ptr, ptr %l49, !tbaa !29
  store ptr %t808, ptr %l363, !tbaa !29
  %t809 = getelementptr %"compiler/emit:Reused", ptr %l38, i32 0, i32 3
  %t810 = load i64, ptr %l46, !tbaa !24
  %t813 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v2, ptr %s31, ptr %t809, i64 %t810)
  store { i64, ptr } %t813, ptr %l366
  br label %bb186
bb186:
  %t814 = load { i64, ptr }, ptr %l366, !tbaa !27
  %t815 = extractvalue { i64, ptr } %t814, 1
  %t816 = extractvalue { i64, ptr } %t814, 0
  %t817 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t816)
  call void @olang_textcopy(ptr %t817, ptr %t815, i64 %t816)
  %t818 = insertvalue { i64, ptr } undef, i64 %t816, 0
  %t819 = insertvalue { i64, ptr } %t818, ptr %t817, 1
  %t821 = extractvalue { i64, ptr } %t819, 0
  %t822 = extractvalue { i64, ptr } %t819, 1
  %t823 = mul i64 %t821, 1
  %t824 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t823)
  call void @llvm.memcpy.p0.p0.i64(ptr %t824, ptr %t822, i64 %t823, i1 false)
  %t825 = insertvalue { i64, ptr } undef, i64 %t821, 0
  %t826 = insertvalue { i64, ptr } %t825, ptr %t824, 1
  %t828 = load ptr, ptr %l363, !tbaa !29
  %t829 = getelementptr %"compiler/build:Unit", ptr %t828, i32 0, i32 3
  store { i64, ptr } %t826, ptr %t829, !tbaa !27
  %t830 = load ptr, ptr %l4, !tbaa !29
  %t832 = getelementptr %"compiler/build:Program", ptr %t830, i32 0, i32 0
  %t833 = load ptr, ptr %l49, !tbaa !29
  %t835 = load %"compiler/build:Unit", ptr %t833
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2ePush_3ccompiler_2fbuild_3aUnit_3e(ptr %v3, ptr %v3, ptr %t832, %"compiler/build:Unit" %t835)
  br label %bb187
bb187:
  call void @__olang_scope_close(ptr %s31)
  br label %bb188
bb188:
  %t838 = load i64, ptr %l45, !tbaa !24
  %t840 = add i64 %t838, 1
  store i64 %t840, ptr %l45, !tbaa !24
  %t842 = load i64, ptr %l42, !tbaa !24
  %t844 = add i64 %t842, 1
  store i64 %t844, ptr %l42, !tbaa !24
  br label %bb162
bb189:
  %t846 = load i64, ptr %l41, !tbaa !24
  %t847 = load i64, ptr %l44, !tbaa !24
  %t850 = add i64 %t846, %t847
  store i64 %t850, ptr %l41, !tbaa !24
  call void @__olang_scope_close(ptr %s30)
  br label %bb190
bb190:
  br label %bb155
bb191:
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l31, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d129, i32 0, i32 1) })
  br label %bb192
bb192:
  call void @__olang_scope_close(ptr %s28)
  call void @__olang_scope_close(ptr %s27)
  br label %bb236
bb193:
  %t853 = getelementptr %"compiler/emit:Object", ptr %l37, i32 0, i32 2
  %t854 = load { i64, ptr }, ptr %t853, !tbaa !27
  store { i64, ptr } %t854, ptr %l50, !tbaa !27
  %t856 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d130, i32 0, i32 1) }, ptr %l384, !tbaa !27
  %t859 = load { i64, ptr }, ptr %l384, !tbaa !27
  %t860 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v3, ptr %s27, { i64, ptr } %t856, { i64, ptr } %t859)
  store i1 %t860, ptr %l385
  br label %bb194
bb194:
  %t861 = load i1, ptr %l385, !tbaa !21
  br i1 %t861, label %bb195, label %bb196
bb195:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb197
bb196:
  br label %bb197
bb197:
  %t862 = load ptr, ptr %l14, !tbaa !29
  %t864 = getelementptr %"compiler/emit:Emitter", ptr %t862, i32 0, i32 6
  %t865 = load i1, ptr %t864, !tbaa !21
  br i1 %t865, label %bb198, label %bb199
bb198:
  %t867 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t869 = call { i64, ptr } @compiler_2folang_2elibraryIr(ptr %v3, ptr %v3, { i64, ptr } %t867)
  store { i64, ptr } %t869, ptr %l389
  br label %bb200
bb199:
  br label %bb201
bb200:
  %t870 = load { i64, ptr }, ptr %l389, !tbaa !27
  %t871 = extractvalue { i64, ptr } %t870, 0
  %t872 = extractvalue { i64, ptr } %t870, 1
  %t873 = mul i64 %t871, 1
  %t874 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t873)
  call void @llvm.memcpy.p0.p0.i64(ptr %t874, ptr %t872, i64 %t873, i1 false)
  %t875 = insertvalue { i64, ptr } undef, i64 %t871, 0
  %t876 = insertvalue { i64, ptr } %t875, ptr %t874, 1
  store { i64, ptr } %t876, ptr %l50, !tbaa !27
  br label %bb201
bb201:
  %t878 = getelementptr %"compiler/emit:Object", ptr %l37, i32 0, i32 1
  %t879 = load i32, ptr %t878
  store i32 %t879, ptr %l51
  %t881 = load i32, ptr %l51
  %t883 = trunc i64 0 to i32
  %t884 = icmp eq i32 %t881, %t883
  br i1 %t884, label %bb202, label %bb203
bb202:
  br label %bb204
bb203:
  br label %bb205
bb204:
  store i32 0, ptr %l392
  br label %bb222
bb205:
  %t887 = load i32, ptr %l51
  %t889 = trunc i64 1 to i32
  %t890 = icmp eq i32 %t887, %t889
  br i1 %t890, label %bb206, label %bb207
bb206:
  br label %bb208
bb207:
  br label %bb209
bb208:
  store i32 1, ptr %l392
  br label %bb222
bb209:
  %t893 = load i32, ptr %l51
  %t895 = trunc i64 2 to i32
  %t896 = icmp eq i32 %t893, %t895
  br i1 %t896, label %bb210, label %bb211
bb210:
  br label %bb212
bb211:
  br label %bb213
bb212:
  store i32 2, ptr %l392
  br label %bb222
bb213:
  %t899 = load i32, ptr %l51
  %t901 = trunc i64 3 to i32
  %t902 = icmp eq i32 %t899, %t901
  br i1 %t902, label %bb214, label %bb215
bb214:
  br label %bb216
bb215:
  br label %bb217
bb216:
  store i32 3, ptr %l392
  br label %bb222
bb217:
  %t905 = load i32, ptr %l51
  %t907 = trunc i64 4 to i32
  %t908 = icmp eq i32 %t905, %t907
  br i1 %t908, label %bb218, label %bb219
bb218:
  br label %bb220
bb219:
  br label %bb221
bb220:
  store i32 4, ptr %l392
  br label %bb222
bb221:
  call void @__olang_check_failed(ptr @olang_loc_5772a8514d833044_b816e84cde98ab20)
  unreachable
bb222:
  %t911 = load i32, ptr %l392
  %t912 = getelementptr %"compiler/emit:Object", ptr %l37, i32 0, i32 0
  %t913 = load { i64, ptr }, ptr %t912, !tbaa !27
  %t915 = extractvalue { i64, ptr } %t913, 1
  %t916 = extractvalue { i64, ptr } %t913, 0
  %t917 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t916)
  call void @olang_textcopy(ptr %t917, ptr %t915, i64 %t916)
  %t918 = insertvalue { i64, ptr } undef, i64 %t916, 0
  %t919 = insertvalue { i64, ptr } %t918, ptr %t917, 1
  %t921 = extractvalue { i64, ptr } %t919, 0
  %t922 = extractvalue { i64, ptr } %t919, 1
  %t923 = mul i64 %t921, 1
  %t924 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t923)
  call void @llvm.memcpy.p0.p0.i64(ptr %t924, ptr %t922, i64 %t923, i1 false)
  %t925 = insertvalue { i64, ptr } undef, i64 %t921, 0
  %t926 = insertvalue { i64, ptr } %t925, ptr %t924, 1
  %t928 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t932 = call %"compiler/build:Unit" @compiler_2fbuild_3aUnit_2ector(ptr %v3, ptr %v3, ptr %v3, { i64, ptr } %t926, i32 %t911, { i64, ptr } %t928)
  store %"compiler/build:Unit" %t932, ptr %l413
  br label %bb223
bb223:
  %t933 = load %"compiler/build:Unit", ptr %l413
  %t934 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 56, i64 8)
  store %"compiler/build:Unit" %t933, ptr %t934
  store ptr %t934, ptr %l53, !tbaa !29
  %t936 = load i32, ptr %l2
  %t938 = trunc i64 0 to i32
  %t939 = icmp eq i32 %t936, %t938
  %t941 = xor i1 %t939, true
  br i1 %t941, label %bb224, label %bb225
bb224:
  %t943 = getelementptr %"compiler/emit:Object", ptr %l37, i32 0, i32 1
  %t944 = load i32, ptr %t943
  %t946 = trunc i64 0 to i32
  %t947 = icmp eq i32 %t944, %t946
  br i1 %t947, label %bb226, label %bb227
bb225:
  store i1 false, ptr %l418, !tbaa !21
  br label %bb229
bb226:
  store i1 true, ptr %l421, !tbaa !21
  br label %bb228
bb227:
  %t949 = getelementptr %"compiler/emit:Object", ptr %l37, i32 0, i32 1
  %t950 = load i32, ptr %t949
  %t952 = trunc i64 4 to i32
  %t953 = icmp eq i32 %t950, %t952
  store i1 %t953, ptr %l421, !tbaa !21
  br label %bb228
bb228:
  %t955 = load i1, ptr %l421, !tbaa !21
  store i1 %t955, ptr %l418, !tbaa !21
  br label %bb229
bb229:
  %t956 = load i1, ptr %l418, !tbaa !21
  br i1 %t956, label %bb230, label %bb231
bb230:
  %t957 = load ptr, ptr %l53, !tbaa !29
  store ptr %t957, ptr %l424, !tbaa !29
  %t958 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t960 = call { i64, ptr } @compiler_2fbuild_2eIrHash(ptr %v3, ptr %v3, { i64, ptr } %t958)
  store { i64, ptr } %t960, ptr %l426
  br label %bb232
bb231:
  br label %bb233
bb232:
  %t961 = load { i64, ptr }, ptr %l426, !tbaa !27
  %t962 = extractvalue { i64, ptr } %t961, 0
  %t963 = extractvalue { i64, ptr } %t961, 1
  %t964 = mul i64 %t962, 1
  %t965 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t964)
  call void @llvm.memcpy.p0.p0.i64(ptr %t965, ptr %t963, i64 %t964, i1 false)
  %t966 = insertvalue { i64, ptr } undef, i64 %t962, 0
  %t967 = insertvalue { i64, ptr } %t966, ptr %t965, 1
  %t969 = load ptr, ptr %l424, !tbaa !29
  %t970 = getelementptr %"compiler/build:Unit", ptr %t969, i32 0, i32 3
  store { i64, ptr } %t967, ptr %t970, !tbaa !27
  br label %bb233
bb233:
  %t971 = load ptr, ptr %l53, !tbaa !29
  %t973 = getelementptr %"compiler/build:Unit", ptr %t971, i32 0, i32 3
  %t974 = load { i64, ptr }, ptr %t973, !tbaa !27
  %t976 = extractvalue { i64, ptr } %t974, 1
  %t977 = extractvalue { i64, ptr } %t974, 0
  %t978 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t977)
  call void @olang_textcopy(ptr %t978, ptr %t976, i64 %t977)
  %t979 = insertvalue { i64, ptr } undef, i64 %t977, 0
  %t980 = insertvalue { i64, ptr } %t979, ptr %t978, 1
  %t982 = extractvalue { i64, ptr } %t980, 0
  %t983 = extractvalue { i64, ptr } %t980, 1
  %t984 = mul i64 %t982, 1
  %t985 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t984)
  call void @llvm.memcpy.p0.p0.i64(ptr %t985, ptr %t983, i64 %t984, i1 false)
  %t986 = insertvalue { i64, ptr } undef, i64 %t982, 0
  %t987 = insertvalue { i64, ptr } %t986, ptr %t985, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l31, { i64, ptr } %t987)
  br label %bb234
bb234:
  %t990 = load ptr, ptr %l4, !tbaa !29
  %t992 = getelementptr %"compiler/build:Program", ptr %t990, i32 0, i32 0
  %t993 = load ptr, ptr %l53, !tbaa !29
  %t995 = load %"compiler/build:Unit", ptr %t993
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2ePush_3ccompiler_2fbuild_3aUnit_3e(ptr %v3, ptr %v3, ptr %t992, %"compiler/build:Unit" %t995)
  br label %bb235
bb235:
  call void @__olang_scope_close(ptr %s27)
  br label %bb236
bb236:
  %t998 = load i64, ptr %l36, !tbaa !24
  %t1000 = add i64 %t998, 1
  store i64 %t1000, ptr %l36, !tbaa !24
  br label %bb146
bb237:
  %t1002 = load i64, ptr %l33, !tbaa !24
  %t1003 = load i64, ptr %l35, !tbaa !24
  %t1006 = add i64 %t1002, %t1003
  store i64 %t1006, ptr %l33, !tbaa !24
  call void @__olang_scope_close(ptr %s26)
  br label %bb238
bb238:
  br label %bb139
bb239:
  %t1008 = load i32, ptr %l2
  %t1010 = trunc i64 0 to i32
  %t1011 = icmp eq i32 %t1008, %t1010
  %t1013 = xor i1 %t1011, true
  br i1 %t1013, label %bb240, label %bb241
bb240:
  %t1015 = load ptr, ptr %l7, !tbaa !29
  %t1016 = load ptr, ptr %l3, !tbaa !29
  %t1017 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t1018 = load ptr, ptr %l14, !tbaa !29
  %t1020 = getelementptr %"compiler/emit:Emitter", ptr %t1018, i32 0, i32 62
  call void @compiler_2folang_2ekeep(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v3, ptr %s0, ptr %t1015, ptr %t1016, { i64, ptr } %t1017, ptr %t1020, ptr %l16, ptr %l31)
  br label %bb242
bb241:
  br label %bb243
bb242:
  br label %bb243
bb243:
  %t1027 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d131, i32 0, i32 1) })
  %t1028 = extractvalue { i32, { i64, ptr } } %t1027, 1
  %t1029 = extractvalue { i32, { i64, ptr } } %t1027, 0
  store i32 %t1029, ptr %l454
  %t1030 = icmp ne i32 %t1029, 0
  br i1 %t1030, label %bb245, label %ok.1031
ok.1031:
  store { i64, ptr } %t1028, ptr %l453
  br label %bb244
bb244:
  %t1032 = load { i64, ptr }, ptr %l453, !tbaa !27
  store { i64, ptr } %t1032, ptr %l452, !tbaa !27
  br label %bb247
bb245:
  br label %bb246
bb246:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d132, i32 0, i32 1) }, ptr %l455, !tbaa !27
  %t1033 = load { i64, ptr }, ptr %l455, !tbaa !27
  %t1035 = extractvalue { i64, ptr } %t1033, 0
  %t1036 = extractvalue { i64, ptr } %t1033, 1
  %t1037 = mul i64 %t1035, 1
  %t1038 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1037)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1038, ptr %t1036, i64 %t1037, i1 false)
  %t1039 = insertvalue { i64, ptr } undef, i64 %t1035, 0
  %t1040 = insertvalue { i64, ptr } %t1039, ptr %t1038, 1
  store { i64, ptr } %t1040, ptr %l452, !tbaa !27
  br label %bb247
bb247:
  %t1042 = load { i64, ptr }, ptr %l452, !tbaa !27
  %t1043 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t1042, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d133, i32 0, i32 1) })
  store i1 %t1043, ptr %l458
  br label %bb248
bb248:
  %t1044 = load i1, ptr %l458, !tbaa !21
  %t1045 = xor i1 %t1044, true
  br i1 %t1045, label %bb249, label %bb250
bb249:
  %t1047 = load ptr, ptr %l14, !tbaa !29
  %t1048 = load ptr, ptr %l4, !tbaa !29
  %t1049 = load ptr, ptr %l8, !tbaa !29
  %t1050 = load ptr, ptr %l12, !tbaa !29
  %t1051 = load ptr, ptr %l5, !tbaa !29
  %t1052 = load ptr, ptr %l3, !tbaa !29
  %t1053 = load i32, ptr %l2
  %t1054 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2folang_2echeckReuse(ptr %v2, ptr %v3, ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %t1047, ptr %t1048, ptr %t1049, ptr %t1050, ptr %t1051, ptr %t1052, i32 %t1053, ptr %t1054)
  br label %bb251
bb250:
  br label %bb252
bb251:
  br label %bb252
bb252:
  %t1063 = load ptr, ptr %l4, !tbaa !29
  store ptr %t1063, ptr %l468, !tbaa !29
  %t1064 = load ptr, ptr %l7, !tbaa !29
  %t1066 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fload_2ecompiler_2fload_3aLoader_2eLinks(ptr %v2, ptr %v3, ptr %t1064)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1066, ptr %l470
  br label %bb253
bb253:
  %t1067 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l470
  %t1068 = load ptr, ptr %l468, !tbaa !29
  %t1069 = getelementptr %"compiler/build:Program", ptr %t1068, i32 0, i32 3
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1067, ptr %t1069
  %t1070 = load ptr, ptr %l5, !tbaa !29
  %t1072 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v2, ptr %t1070)
  store i64 %t1072, ptr %l472
  br label %bb254
bb254:
  %t1073 = load i64, ptr %l472, !tbaa !24
  %t1074 = icmp sgt i64 %t1073, 0
  br i1 %t1074, label %bb255, label %bb256
bb255:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb256:
  br label %bb257
bb257:
  %t1077 = load ptr, ptr %l14, !tbaa !29
  %t1079 = getelementptr %"compiler/emit:Emitter", ptr %t1077, i32 0, i32 6
  %t1080 = load i1, ptr %t1079, !tbaa !21
  br i1 %t1080, label %bb258, label %bb259
bb258:
  store %olang.scope zeroinitializer, ptr %s55
  %t1082 = load ptr, ptr %l14, !tbaa !29
  %t1084 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2ecompiler_2femit_3aEmitter_2eExportNames(ptr %v2, ptr %s55, ptr %t1082)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1084, ptr %l478
  br label %bb260
bb259:
  br label %bb279
bb260:
  %t1085 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l478
  %t1086 = call ptr @__olang_scope_alloc_a(ptr %s55, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1085, ptr %t1086
  store ptr %t1086, ptr %l54, !tbaa !29
  store i64 0, ptr %l55, !tbaa !24
  br label %bb261
bb261:
  store %olang.scope zeroinitializer, ptr %s56
  %t1088 = load ptr, ptr %l54, !tbaa !29
  %t1089 = load i64, ptr %l55, !tbaa !24
  %t1092 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %s55, ptr %t1088, i64 %t1089)
  %t1093 = extractvalue { i32, { i64, ptr } } %t1092, 1
  %t1094 = extractvalue { i32, { i64, ptr } } %t1092, 0
  store i32 %t1094, ptr %l484
  %t1095 = icmp ne i32 %t1094, 0
  br i1 %t1095, label %bb263, label %ok.1096
ok.1096:
  store { i64, ptr } %t1093, ptr %l483
  br label %bb262
bb262:
  %t1097 = load { i64, ptr }, ptr %l483, !tbaa !27
  store { i64, ptr } %t1097, ptr %l480, !tbaa !27
  br label %bb267
bb263:
  %t1098 = load i32, ptr %l484, !tbaa !23
  %t1099 = ashr i32 %t1098, 16
  %t1101 = icmp eq i32 %t1099, 1
  br i1 %t1101, label %bb264, label %bb265
bb264:
  br label %bb266
bb265:
  %t1103 = load i32, ptr %l484, !tbaa !23
  %t1104 = lshr i32 %t1103, 16
  %t1105 = and i32 %t1103, 65535
  %t1106 = icmp eq i32 %t1104, 1
  %t1107 = select i1 %t1106, i32 0, i32 0
  %t1108 = icmp eq i32 %t1103, 0
  %t1109 = shl i32 %t1107, 16
  %t1110 = or i32 %t1109, %t1105
  %t1111 = select i1 %t1108, i32 0, i32 %t1110
  call void @__olang_scope_close(ptr %s56)
  call void @__olang_scope_close(ptr %s55)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t1111, ptr %rv
  br label %ret
bb266:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s56)
  br label %bb276
bb267:
  %t1113 = load { i64, ptr }, ptr %l480, !tbaa !27
  store { i64, ptr } %t1113, ptr %l56, !tbaa !27
  %t1114 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t1116 = extractvalue { i64, ptr } %t1114, 0
  store i64 %t1116, ptr %l57, !tbaa !24
  store i64 0, ptr %l58, !tbaa !24
  br label %bb268
bb268:
  store %olang.scope zeroinitializer, ptr %s57
  %t1118 = load i64, ptr %l58, !tbaa !24
  %t1119 = load i64, ptr %l57, !tbaa !24
  %t1122 = icmp slt i64 %t1118, %t1119
  %t1124 = xor i1 %t1122, true
  br i1 %t1124, label %bb269, label %bb270
bb269:
  call void @__olang_scope_close(ptr %s57)
  br label %bb274
bb270:
  br label %bb271
bb271:
  %t1126 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t1126, ptr %l494, !tbaa !27
  %t1127 = load i64, ptr %l58, !tbaa !24
  %t1129 = getelementptr { i64, ptr }, ptr %l494, i32 0, i32 1
  %t1130 = load ptr, ptr %t1129, !tbaa !27
  %t1131 = getelementptr { i64, ptr }, ptr %t1130, i64 %t1127
  %t1132 = load { i64, ptr }, ptr %t1131, !tbaa !37
  %t1134 = load ptr, ptr %l4, !tbaa !29
  %t1136 = getelementptr %"compiler/build:Program", ptr %t1134, i32 0, i32 4
  %t1139 = extractvalue { i64, ptr } %t1132, 1
  %t1140 = extractvalue { i64, ptr } %t1132, 0
  %t1141 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t1140)
  call void @olang_textcopy(ptr %t1141, ptr %t1139, i64 %t1140)
  %t1142 = insertvalue { i64, ptr } undef, i64 %t1140, 0
  %t1143 = insertvalue { i64, ptr } %t1142, ptr %t1141, 1
  %t1145 = extractvalue { i64, ptr } %t1143, 0
  %t1146 = extractvalue { i64, ptr } %t1143, 1
  %t1147 = mul i64 %t1145, 1
  %t1148 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t1147)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1148, ptr %t1146, i64 %t1147, i1 false)
  %t1149 = insertvalue { i64, ptr } undef, i64 %t1145, 0
  %t1150 = insertvalue { i64, ptr } %t1149, ptr %t1148, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v3, ptr %v3, ptr %t1136, { i64, ptr } %t1150)
  br label %bb272
bb272:
  call void @__olang_scope_close(ptr %s57)
  br label %bb273
bb273:
  %t1153 = load i64, ptr %l58, !tbaa !24
  %t1155 = add i64 %t1153, 1
  store i64 %t1155, ptr %l58, !tbaa !24
  br label %bb268
bb274:
  %t1157 = load i64, ptr %l55, !tbaa !24
  %t1158 = load i64, ptr %l57, !tbaa !24
  %t1161 = add i64 %t1157, %t1158
  store i64 %t1161, ptr %l55, !tbaa !24
  call void @__olang_scope_close(ptr %s56)
  br label %bb275
bb275:
  br label %bb261
bb276:
  call void @__olang_scope_close(ptr %s55)
  %t1163 = load ptr, ptr %l4, !tbaa !29
  store ptr %t1163, ptr %l507, !tbaa !29
  %t1164 = load ptr, ptr %l14, !tbaa !29
  store ptr %t1164, ptr %l508, !tbaa !29
  %t1165 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t1167 = call { i64, ptr } @compiler_2fbuild_2eLibName(ptr %v1, ptr %v3, { i64, ptr } %t1165)
  store { i64, ptr } %t1167, ptr %l510
  br label %bb277
bb277:
  %t1168 = load { i64, ptr }, ptr %l510, !tbaa !27
  %t1169 = extractvalue { i64, ptr } %t1168, 0
  %t1170 = extractvalue { i64, ptr } %t1168, 1
  %t1171 = mul i64 %t1169, 1
  %t1172 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t1171)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1172, ptr %t1170, i64 %t1171, i1 false)
  %t1173 = insertvalue { i64, ptr } undef, i64 %t1169, 0
  %t1174 = insertvalue { i64, ptr } %t1173, ptr %t1172, 1
  %t1175 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t1176 = load ptr, ptr %l508, !tbaa !29
  %t1179 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eHeader(ptr %v2, ptr %v3, ptr %v1, ptr %v3, ptr %t1176, { i64, ptr } %t1174, { i64, ptr } %t1175)
  store { i64, ptr } %t1179, ptr %l513
  br label %bb278
bb278:
  %t1180 = load { i64, ptr }, ptr %l513, !tbaa !27
  %t1181 = extractvalue { i64, ptr } %t1180, 0
  %t1182 = extractvalue { i64, ptr } %t1180, 1
  %t1183 = mul i64 %t1181, 1
  %t1184 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t1183)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1184, ptr %t1182, i64 %t1183, i1 false)
  %t1185 = insertvalue { i64, ptr } undef, i64 %t1181, 0
  %t1186 = insertvalue { i64, ptr } %t1185, ptr %t1184, 1
  %t1188 = load ptr, ptr %l507, !tbaa !29
  %t1189 = getelementptr %"compiler/build:Program", ptr %t1188, i32 0, i32 5
  store { i64, ptr } %t1186, ptr %t1189, !tbaa !27
  br label %bb279
bb279:
  %t1190 = load ptr, ptr %l4, !tbaa !29
  store ptr %t1190, ptr %l515, !tbaa !29
  %t1191 = getelementptr %"compiler/target:Target", ptr %l29, i32 0, i32 1
  %t1192 = load { i64, ptr }, ptr %t1191, !tbaa !27
  %t1193 = getelementptr %"compiler/target:Target", ptr %l29, i32 0, i32 2
  %t1194 = load { i64, ptr }, ptr %t1193, !tbaa !27
  %t1195 = getelementptr %"compiler/target:Target", ptr %l29, i32 0, i32 5
  %t1196 = load { i64, ptr }, ptr %t1195, !tbaa !27
  %t1197 = load ptr, ptr %l3, !tbaa !29
  %t1199 = getelementptr %"compiler/build:Config", ptr %t1197, i32 0, i32 7
  %t1200 = load i1, ptr %t1199, !tbaa !21
  %t1201 = load ptr, ptr %l3, !tbaa !29
  %t1203 = getelementptr %"compiler/build:Config", ptr %t1201, i32 0, i32 6
  %t1204 = load i1, ptr %t1203, !tbaa !21
  %t1210 = call { i32, { i64, ptr } } @compiler_2fruntime_2eIr(ptr %v2, ptr %v2, ptr %v2, ptr %v3, { i64, ptr } %t1192, { i64, ptr } %t1194, { i64, ptr } %t1196, i1 %t1200, i1 %t1204)
  %t1211 = extractvalue { i32, { i64, ptr } } %t1210, 1
  %t1212 = extractvalue { i32, { i64, ptr } } %t1210, 0
  store i32 %t1212, ptr %l525
  %t1213 = icmp ne i32 %t1212, 0
  br i1 %t1213, label %bb281, label %ok.1214
ok.1214:
  store { i64, ptr } %t1211, ptr %l524
  br label %bb280
bb280:
  %t1215 = load { i64, ptr }, ptr %l524, !tbaa !27
  store { i64, ptr } %t1215, ptr %l516, !tbaa !27
  br label %bb285
bb281:
  %t1216 = load i32, ptr %l525, !tbaa !23
  %t1217 = ashr i32 %t1216, 16
  %t1219 = icmp eq i32 %t1217, 1
  br i1 %t1219, label %bb282, label %bb283
bb282:
  br label %bb284
bb283:
  %t1221 = load i32, ptr %l525, !tbaa !23
  %t1222 = lshr i32 %t1221, 16
  %t1223 = and i32 %t1221, 65535
  %t1224 = icmp eq i32 %t1222, 1
  %t1225 = select i1 %t1224, i32 0, i32 0
  %t1226 = icmp eq i32 %t1221, 0
  %t1227 = shl i32 %t1225, 16
  %t1228 = or i32 %t1227, %t1223
  %t1229 = select i1 %t1226, i32 0, i32 %t1228
  call void @__olang_scope_close(ptr %s0)
  store i32 %t1229, ptr %rv
  br label %ret
bb284:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb285:
  %t1232 = load { i64, ptr }, ptr %l516, !tbaa !27
  %t1233 = extractvalue { i64, ptr } %t1232, 0
  %t1234 = extractvalue { i64, ptr } %t1232, 1
  %t1235 = mul i64 %t1233, 1
  %t1236 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t1235)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1236, ptr %t1234, i64 %t1235, i1 false)
  %t1237 = insertvalue { i64, ptr } undef, i64 %t1233, 0
  %t1238 = insertvalue { i64, ptr } %t1237, ptr %t1236, 1
  %t1240 = load ptr, ptr %l515, !tbaa !29
  %t1241 = getelementptr %"compiler/build:Program", ptr %t1240, i32 0, i32 1
  store { i64, ptr } %t1238, ptr %t1241, !tbaa !27
  %t1242 = load ptr, ptr %l14, !tbaa !29
  %t1244 = getelementptr %"compiler/emit:Emitter", ptr %t1242, i32 0, i32 6
  %t1245 = load i1, ptr %t1244, !tbaa !21
  br i1 %t1245, label %bb286, label %bb287
bb286:
  %t1247 = load ptr, ptr %l4, !tbaa !29
  store ptr %t1247, ptr %l533, !tbaa !29
  %t1248 = load ptr, ptr %l4, !tbaa !29
  %t1250 = getelementptr %"compiler/build:Program", ptr %t1248, i32 0, i32 1
  %t1251 = load { i64, ptr }, ptr %t1250, !tbaa !27
  %t1253 = call { i64, ptr } @compiler_2folang_2elibraryIr(ptr %v3, ptr %v3, { i64, ptr } %t1251)
  store { i64, ptr } %t1253, ptr %l536
  br label %bb288
bb287:
  br label %bb289
bb288:
  %t1254 = load { i64, ptr }, ptr %l536, !tbaa !27
  %t1255 = extractvalue { i64, ptr } %t1254, 0
  %t1256 = extractvalue { i64, ptr } %t1254, 1
  %t1257 = mul i64 %t1255, 1
  %t1258 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t1257)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1258, ptr %t1256, i64 %t1257, i1 false)
  %t1259 = insertvalue { i64, ptr } undef, i64 %t1255, 0
  %t1260 = insertvalue { i64, ptr } %t1259, ptr %t1258, 1
  %t1262 = load ptr, ptr %l533, !tbaa !29
  %t1263 = getelementptr %"compiler/build:Program", ptr %t1262, i32 0, i32 1
  store { i64, ptr } %t1260, ptr %t1263, !tbaa !27
  br label %bb289
bb289:
  %t1264 = load i1, ptr %l30, !tbaa !21
  br i1 %t1264, label %bb290, label %bb291
bb290:
  %t1266 = load ptr, ptr %l4, !tbaa !29
  store ptr %t1266, ptr %l539, !tbaa !29
  %t1267 = getelementptr %"compiler/target:Target", ptr %l29, i32 0, i32 1
  %t1268 = load { i64, ptr }, ptr %t1267, !tbaa !27
  %t1269 = getelementptr %"compiler/target:Target", ptr %l29, i32 0, i32 2
  %t1270 = load { i64, ptr }, ptr %t1269, !tbaa !27
  %t1271 = getelementptr %"compiler/target:Target", ptr %l29, i32 0, i32 5
  %t1272 = load { i64, ptr }, ptr %t1271, !tbaa !27
  %t1273 = load ptr, ptr %l3, !tbaa !29
  %t1275 = getelementptr %"compiler/build:Config", ptr %t1273, i32 0, i32 7
  %t1276 = load i1, ptr %t1275, !tbaa !21
  %t1277 = load ptr, ptr %l3, !tbaa !29
  %t1279 = getelementptr %"compiler/build:Config", ptr %t1277, i32 0, i32 6
  %t1280 = load i1, ptr %t1279, !tbaa !21
  %t1286 = call { i32, { i64, ptr } } @compiler_2fruntime_2eDyncallIr(ptr %v2, ptr %v2, ptr %v2, ptr %v3, { i64, ptr } %t1268, { i64, ptr } %t1270, { i64, ptr } %t1272, i1 %t1276, i1 %t1280)
  %t1287 = extractvalue { i32, { i64, ptr } } %t1286, 1
  %t1288 = extractvalue { i32, { i64, ptr } } %t1286, 0
  store i32 %t1288, ptr %l549
  %t1289 = icmp ne i32 %t1288, 0
  br i1 %t1289, label %bb293, label %ok.1290
ok.1290:
  store { i64, ptr } %t1287, ptr %l548
  br label %bb292
bb291:
  br label %bb302
bb292:
  %t1291 = load { i64, ptr }, ptr %l548, !tbaa !27
  store { i64, ptr } %t1291, ptr %l540, !tbaa !27
  br label %bb297
bb293:
  %t1292 = load i32, ptr %l549, !tbaa !23
  %t1293 = ashr i32 %t1292, 16
  %t1295 = icmp eq i32 %t1293, 1
  br i1 %t1295, label %bb294, label %bb295
bb294:
  br label %bb296
bb295:
  %t1297 = load i32, ptr %l549, !tbaa !23
  %t1298 = lshr i32 %t1297, 16
  %t1299 = and i32 %t1297, 65535
  %t1300 = icmp eq i32 %t1298, 1
  %t1301 = select i1 %t1300, i32 0, i32 0
  %t1302 = icmp eq i32 %t1297, 0
  %t1303 = shl i32 %t1301, 16
  %t1304 = or i32 %t1303, %t1299
  %t1305 = select i1 %t1302, i32 0, i32 %t1304
  call void @__olang_scope_close(ptr %s0)
  store i32 %t1305, ptr %rv
  br label %ret
bb296:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb297:
  %t1308 = load { i64, ptr }, ptr %l540, !tbaa !27
  %t1309 = extractvalue { i64, ptr } %t1308, 0
  %t1310 = extractvalue { i64, ptr } %t1308, 1
  %t1311 = mul i64 %t1309, 1
  %t1312 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t1311)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1312, ptr %t1310, i64 %t1311, i1 false)
  %t1313 = insertvalue { i64, ptr } undef, i64 %t1309, 0
  %t1314 = insertvalue { i64, ptr } %t1313, ptr %t1312, 1
  %t1316 = load ptr, ptr %l539, !tbaa !29
  %t1317 = getelementptr %"compiler/build:Program", ptr %t1316, i32 0, i32 2
  store { i64, ptr } %t1314, ptr %t1317, !tbaa !27
  %t1318 = load ptr, ptr %l14, !tbaa !29
  %t1320 = getelementptr %"compiler/emit:Emitter", ptr %t1318, i32 0, i32 6
  %t1321 = load i1, ptr %t1320, !tbaa !21
  br i1 %t1321, label %bb298, label %bb299
bb298:
  %t1323 = load ptr, ptr %l4, !tbaa !29
  store ptr %t1323, ptr %l557, !tbaa !29
  %t1324 = load ptr, ptr %l4, !tbaa !29
  %t1326 = getelementptr %"compiler/build:Program", ptr %t1324, i32 0, i32 2
  %t1327 = load { i64, ptr }, ptr %t1326, !tbaa !27
  %t1329 = call { i64, ptr } @compiler_2folang_2elibraryIr(ptr %v3, ptr %v3, { i64, ptr } %t1327)
  store { i64, ptr } %t1329, ptr %l560
  br label %bb300
bb299:
  br label %bb301
bb300:
  %t1330 = load { i64, ptr }, ptr %l560, !tbaa !27
  %t1331 = extractvalue { i64, ptr } %t1330, 0
  %t1332 = extractvalue { i64, ptr } %t1330, 1
  %t1333 = mul i64 %t1331, 1
  %t1334 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t1333)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1334, ptr %t1332, i64 %t1333, i1 false)
  %t1335 = insertvalue { i64, ptr } undef, i64 %t1331, 0
  %t1336 = insertvalue { i64, ptr } %t1335, ptr %t1334, 1
  %t1338 = load ptr, ptr %l557, !tbaa !29
  %t1339 = getelementptr %"compiler/build:Program", ptr %t1338, i32 0, i32 2
  store { i64, ptr } %t1336, ptr %t1339, !tbaa !27
  br label %bb301
bb301:
  br label %bb302
bb302:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2folang_2ecompiler_2folang_3aPasses_2eExplain(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca ptr
  %lp11 = alloca ptr
  %l12 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i32
  %l21 = alloca %"compiler/check:Checker"
  %l23 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l26 = alloca i64
  %l30 = alloca i64
  %l33 = alloca i64
  %l36 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l38 = alloca i64
  %l45 = alloca %"compiler/scope:Scoper"
  %l55 = alloca i64
  %l63 = alloca %"compiler/interp:Exec"
  %l68 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %l76 = alloca i32
  %l80 = alloca ptr
  %l81 = alloca { i64, [3 x i64] }
  %l84 = alloca %"compiler/msgs:Msg"
  %l85 = alloca i64
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  %t28 = alloca %"compiler/check:Checker", align 8
  %t73 = alloca %"compiler/scope:Scoper", align 8
  %t122 = alloca %"compiler/interp:Exec", align 8
  %t172 = alloca { i64, [3 x i64] }, align 8
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t4 = load ptr, ptr %l4, !tbaa !29
  %t9 = call { i32, ptr } @compiler_2folang_2ecompiler_2folang_3aPasses_2eload(ptr %v0, ptr %v1, ptr %v3, ptr %a0, { i64, ptr } %t2, ptr %a3, ptr %t4)
  %t10 = extractvalue { i32, ptr } %t9, 1
  %t11 = extractvalue { i32, ptr } %t9, 0
  store i32 %t11, ptr %l18
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb2, label %ok.13
ok.13:
  store ptr %t10, ptr %l17
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l17, !tbaa !29
  store ptr %t14, ptr %l12, !tbaa !29
  br label %bb3
bb2:
  %t15 = load i32, ptr %l18, !tbaa !23
  %t16 = lshr i32 %t15, 16
  %t17 = and i32 %t15, 65535
  %t18 = icmp eq i32 %t16, 1
  %t19 = select i1 %t18, i32 1, i32 0
  %t20 = icmp eq i32 %t15, 0
  %t21 = shl i32 %t19, 16
  %t22 = or i32 %t21, %t17
  %t23 = select i1 %t20, i32 0, i32 %t22
  %t25 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t23, 0
  store { i32, { i64, ptr } } %t25, ptr %rv
  br label %ret
bb3:
  %t26 = load ptr, ptr %l12, !tbaa !29
  store ptr %t26, ptr %l5, !tbaa !29
  %t27 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2finterp_2eAnalyze(ptr %t28, ptr %v3, ptr %v3, ptr %t27, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l21, ptr %t28, i64 752, i1 false)
  br label %bb4
bb4:
  %t30 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 752, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %l21, i64 752, i1 false)
  store ptr %t30, ptr %l6, !tbaa !29
  %t32 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v3)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t32, ptr %l23
  br label %bb5
bb5:
  %t33 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l23
  %t34 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 8, i64 8)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t33, ptr %t34
  store ptr %t34, ptr %l7, !tbaa !29
  %t36 = load ptr, ptr %l4, !tbaa !29
  %t38 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v3, ptr %t36)
  store i64 %t38, ptr %l26
  br label %bb6
bb6:
  %t39 = load i64, ptr %l26, !tbaa !24
  %t40 = icmp eq i64 %t39, 0
  store i1 %t40, ptr %l8, !tbaa !21
  %t42 = load i1, ptr %l8, !tbaa !21
  br i1 %t42, label %bb7, label %bb8
bb7:
  %t44 = load ptr, ptr %l6, !tbaa !29
  %t46 = call i64 @compiler_2finterp_2eDecideValues(ptr %v3, ptr %t44)
  store i64 %t46, ptr %l30
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb10
bb10:
  %t47 = load ptr, ptr %l6, !tbaa !29
  %t48 = load ptr, ptr %l7, !tbaa !29
  %t51 = call i64 @compiler_2finterp_2eDecideAsserts(ptr %v3, ptr %v3, ptr %t47, ptr %t48)
  store i64 %t51, ptr %l33
  br label %bb11
bb11:
  %t52 = load i1, ptr %l8, !tbaa !21
  br i1 %t52, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t54 = load ptr, ptr %l6, !tbaa !29
  %t56 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2finterp_2eBake(ptr %v3, ptr %s2, ptr %t54)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t56, ptr %l36
  br label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb15:
  %t57 = load ptr, ptr %l4, !tbaa !29
  %t59 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v3, ptr %t57)
  store i64 %t59, ptr %l38
  br label %bb16
bb16:
  %t60 = load i64, ptr %l38, !tbaa !24
  %t61 = icmp sgt i64 %t60, 0
  br i1 %t61, label %bb17, label %bb18
bb17:
  %t64 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t64, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t65 = load ptr, ptr %l6, !tbaa !29
  %t67 = getelementptr %"compiler/check:Checker", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t69 = load ptr, ptr %l6, !tbaa !29
  %t71 = getelementptr %"compiler/check:Checker", ptr %t69, i32 0, i32 11
  %t72 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t71
  call void @compiler_2fscope_3aScoper_2ector(ptr %t73, ptr %v3, ptr %v3, ptr %v3, ptr %t68, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t72)
  call void @llvm.memmove.p0.p0.i64(ptr %l45, ptr %t73, i64 1072, i1 false)
  br label %bb20
bb20:
  %t76 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 1072, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t76, ptr %l45, i64 1072, i1 false)
  store ptr %t76, ptr %l9, !tbaa !29
  %t78 = load ptr, ptr %l9, !tbaa !29
  %t79 = load ptr, ptr %l6, !tbaa !29
  %t80 = getelementptr { ptr, ptr }, ptr null, i32 1
  %t81 = ptrtoint ptr %t80 to i64
  %t82 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 %t81, i64 8)
  %t83 = getelementptr { ptr, ptr }, ptr %t82, i32 0, i32 0
  store ptr %t79, ptr %t83, !tbaa !28
  call void @__olang_scope_escape(ptr %v3)
  %t85 = getelementptr { ptr, ptr }, ptr %t82, i32 0, i32 1
  store ptr %v3, ptr %t85, !tbaa !28
  %t86 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_134, 0
  %t87 = insertvalue { ptr, ptr } %t86, ptr %t82, 1
  %t90 = getelementptr %"compiler/scope:Scoper", ptr %t78, i32 0, i32 4
  store { ptr, ptr } %t87, ptr %t90
  %t91 = load ptr, ptr %l9, !tbaa !29
  %t92 = load ptr, ptr %l6, !tbaa !29
  %t93 = getelementptr { ptr, ptr }, ptr null, i32 1
  %t94 = ptrtoint ptr %t93 to i64
  %t95 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 %t94, i64 8)
  %t96 = getelementptr { ptr, ptr }, ptr %t95, i32 0, i32 0
  store ptr %t92, ptr %t96, !tbaa !28
  call void @__olang_scope_escape(ptr %v3)
  %t98 = getelementptr { ptr, ptr }, ptr %t95, i32 0, i32 1
  store ptr %v3, ptr %t98, !tbaa !28
  %t99 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_135, 0
  %t100 = insertvalue { ptr, ptr } %t99, ptr %t95, 1
  %t103 = getelementptr %"compiler/scope:Scoper", ptr %t91, i32 0, i32 5
  store { ptr, ptr } %t100, ptr %t103
  %t104 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eRun(ptr %v3, ptr %t104)
  br label %bb21
bb21:
  %t106 = load ptr, ptr %l4, !tbaa !29
  %t108 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v3, ptr %t106)
  store i64 %t108, ptr %l55
  br label %bb22
bb22:
  %t109 = load i64, ptr %l55, !tbaa !24
  %t110 = icmp sgt i64 %t109, 0
  br i1 %t110, label %bb23, label %bb24
bb23:
  %t113 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t113, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  %t114 = load ptr, ptr %l6, !tbaa !29
  %t116 = getelementptr %"compiler/check:Checker", ptr %t114, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !29
  %t118 = load ptr, ptr %l6, !tbaa !29
  %t120 = getelementptr %"compiler/check:Checker", ptr %t118, i32 0, i32 11
  %t121 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t120
  call void @compiler_2finterp_3aExec_2ector(ptr %t122, ptr %v3, ptr %v3, ptr %v3, ptr %t117, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t121, i32 0)
  call void @llvm.memmove.p0.p0.i64(ptr %l63, ptr %t122, i64 976, i1 false)
  br label %bb26
bb26:
  %t126 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 976, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t126, ptr %l63, i64 976, i1 false)
  store ptr %t126, ptr %l10, !tbaa !29
  %t128 = load ptr, ptr %l10, !tbaa !29
  %t129 = load ptr, ptr %l6, !tbaa !29
  %t131 = getelementptr %"compiler/check:Checker", ptr %t129, i32 0, i32 87
  %t132 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t131
  %t135 = getelementptr %"compiler/interp:Exec", ptr %t128, i32 0, i32 10
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t132, ptr %t135
  %t136 = load ptr, ptr %l6, !tbaa !29
  %t137 = load ptr, ptr %l9, !tbaa !29
  %t138 = load ptr, ptr %l10, !tbaa !29
  %t139 = load ptr, ptr %l5, !tbaa !29
  %t141 = getelementptr %"compiler/load:Loader", ptr %t139, i32 0, i32 7
  %t142 = load i64, ptr %t141, !tbaa !24
  %t143 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t149 = call { i32, { i64, ptr } } @compiler_2fexplain_2eItem(ptr %v3, ptr %v3, ptr %v3, ptr %v2, ptr %v4, ptr %t136, ptr %t137, ptr %t138, i64 %t142, { i64, ptr } %t143)
  %t150 = extractvalue { i32, { i64, ptr } } %t149, 1
  %t151 = extractvalue { i32, { i64, ptr } } %t149, 0
  store i32 %t151, ptr %l76
  %t152 = icmp ne i32 %t151, 0
  br i1 %t152, label %bb28, label %ok.153
ok.153:
  store { i64, ptr } %t150, ptr %l75
  br label %bb27
bb27:
  %t154 = load { i64, ptr }, ptr %l75, !tbaa !27
  store { i64, ptr } %t154, ptr %l68, !tbaa !27
  br label %bb34
bb28:
  %t155 = load i32, ptr %l76, !tbaa !23
  %t156 = ashr i32 %t155, 16
  %t158 = icmp eq i32 %t156, 1
  br i1 %t158, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  %t160 = load i32, ptr %l76, !tbaa !23
  %t161 = lshr i32 %t160, 16
  %t162 = and i32 %t160, 65535
  %t163 = icmp eq i32 %t161, 1
  %t164 = select i1 %t163, i32 0, i32 0
  %t165 = icmp eq i32 %t160, 0
  %t166 = shl i32 %t164, 16
  %t167 = or i32 %t166, %t162
  %t168 = select i1 %t165, i32 0, i32 %t167
  %t170 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t168, 0
  store { i32, { i64, ptr } } %t170, ptr %rv
  br label %ret
bb31:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s5
  %t171 = load ptr, ptr %l4, !tbaa !29
  store ptr %t171, ptr %l80, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t172
  %t173 = getelementptr { i64, [3 x i64] }, ptr %t172, i32 0, i32 0
  store i64 0, ptr %t173
  %t174 = load { i64, [3 x i64] }, ptr %t172
  store { i64, [3 x i64] } %t174, ptr %l81
  %t175 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t176 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t179 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eExplainNoItem(ptr %v2, ptr %v1, ptr %s5, { i64, ptr } %t175, { i64, ptr } %t176)
  store %"compiler/msgs:Msg" %t179, ptr %l84
  br label %bb32
bb32:
  %t180 = load ptr, ptr %l80, !tbaa !29
  %t181 = load { i64, [3 x i64] }, ptr %l81
  %t182 = load %"compiler/msgs:Msg", ptr %l84
  %t183 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v3, ptr %s5, ptr %t180, { i64, [3 x i64] } %t181, %"compiler/msgs:Msg" %t182)
  store i64 %t183, ptr %l85
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s5)
  %t185 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t185, ptr %rv
  br label %ret
bb34:
  %t186 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 16, i64 8)
  store ptr %t186, ptr %lp11
  %t187 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t188 = load ptr, ptr %lp11
  store { i64, ptr } %t187, ptr %t188, !tbaa !27
  %t189 = load ptr, ptr %lp11
  %t190 = load { i64, ptr }, ptr %t189, !tbaa !27
  %t192 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t190, 1
  store { i32, { i64, ptr } } %t192, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, i32 } @compiler_2folang_2ecompiler_2folang_3aPasses_2eInterpret(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l22 = alloca i32
  %l23 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca i32
  %l32 = alloca %"compiler/check:Checker"
  %l34 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l37 = alloca i64
  %l41 = alloca i64
  %l44 = alloca i64
  %l47 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l49 = alloca i64
  %l53 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l55 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l59 = alloca i32
  %l69 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l75 = alloca i1
  %l77 = alloca ptr
  %l78 = alloca { i64, [3 x i64] }
  %l80 = alloca i1
  %l81 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  %l85 = alloca i64
  %l86 = alloca i64
  %l97 = alloca %"compiler/msgs:Msg"
  %l98 = alloca i64
  %l105 = alloca i64
  %l113 = alloca %"compiler/interp:Exec"
  %l123 = alloca ptr
  %l125 = alloca i64
  %l141 = alloca { i64, ptr }
  %l154 = alloca i32
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %rv = alloca { i32, i32 }
  %t28 = alloca %"compiler/check:Checker", align 8
  %t129 = alloca { i64, [3 x i64] }, align 8
  %t222 = alloca %"compiler/interp:Exec", align 8
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t3 = load ptr, ptr %l3, !tbaa !29
  %t4 = load ptr, ptr %l4, !tbaa !29
  %t9 = call { i32, ptr } @compiler_2folang_2ecompiler_2folang_3aPasses_2eload(ptr %v0, ptr %v1, ptr %v3, ptr %a0, { i64, ptr } %a1, ptr %t3, ptr %t4)
  %t10 = extractvalue { i32, ptr } %t9, 1
  %t11 = extractvalue { i32, ptr } %t9, 0
  store i32 %t11, ptr %l29
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb2, label %ok.13
ok.13:
  store ptr %t10, ptr %l28
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l28, !tbaa !29
  store ptr %t14, ptr %l23, !tbaa !29
  br label %bb3
bb2:
  %t15 = load i32, ptr %l29, !tbaa !23
  %t16 = lshr i32 %t15, 16
  %t17 = and i32 %t15, 65535
  %t18 = icmp eq i32 %t16, 1
  %t19 = select i1 %t18, i32 1, i32 0
  %t20 = icmp eq i32 %t15, 0
  %t21 = shl i32 %t19, 16
  %t22 = or i32 %t21, %t17
  %t23 = select i1 %t20, i32 0, i32 %t22
  %t25 = insertvalue { i32, i32 } zeroinitializer, i32 %t23, 0
  store { i32, i32 } %t25, ptr %rv
  br label %ret
bb3:
  %t26 = load ptr, ptr %l23, !tbaa !29
  store ptr %t26, ptr %l5, !tbaa !29
  %t27 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2finterp_2eAnalyze(ptr %t28, ptr %v3, ptr %v3, ptr %t27, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l32, ptr %t28, i64 752, i1 false)
  br label %bb4
bb4:
  %t30 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 752, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %l32, i64 752, i1 false)
  store ptr %t30, ptr %l6, !tbaa !29
  %t32 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v3)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t32, ptr %l34
  br label %bb5
bb5:
  %t33 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l34
  %t34 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 8, i64 8)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t33, ptr %t34
  store ptr %t34, ptr %l7, !tbaa !29
  %t36 = load ptr, ptr %l4, !tbaa !29
  %t38 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v3, ptr %t36)
  store i64 %t38, ptr %l37
  br label %bb6
bb6:
  %t39 = load i64, ptr %l37, !tbaa !24
  %t40 = icmp eq i64 %t39, 0
  store i1 %t40, ptr %l8, !tbaa !21
  %t42 = load i1, ptr %l8, !tbaa !21
  br i1 %t42, label %bb7, label %bb8
bb7:
  %t44 = load ptr, ptr %l6, !tbaa !29
  %t46 = call i64 @compiler_2finterp_2eDecideValues(ptr %v3, ptr %t44)
  store i64 %t46, ptr %l41
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb10
bb10:
  %t47 = load ptr, ptr %l6, !tbaa !29
  %t48 = load ptr, ptr %l7, !tbaa !29
  %t51 = call i64 @compiler_2finterp_2eDecideAsserts(ptr %v3, ptr %v3, ptr %t47, ptr %t48)
  store i64 %t51, ptr %l44
  br label %bb11
bb11:
  %t52 = load i1, ptr %l8, !tbaa !21
  br i1 %t52, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t54 = load ptr, ptr %l6, !tbaa !29
  %t56 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2finterp_2eBake(ptr %v3, ptr %s2, ptr %t54)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t56, ptr %l47
  br label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb15:
  %t57 = load ptr, ptr %l4, !tbaa !29
  %t59 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v3, ptr %t57)
  store i64 %t59, ptr %l49
  br label %bb16
bb16:
  %t60 = load i64, ptr %l49, !tbaa !24
  %t61 = icmp sgt i64 %t60, 0
  br i1 %t61, label %bb17, label %bb18
bb17:
  %t64 = insertvalue { i32, i32 } zeroinitializer, i32 65536, 0
  store { i32, i32 } %t64, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  store %olang.scope zeroinitializer, ptr %s4
  %t65 = load ptr, ptr %l5, !tbaa !29
  %t67 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fload_2ecompiler_2fload_3aLoader_2eLinks(ptr %v3, ptr %s4, ptr %t65)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t67, ptr %l53
  br label %bb20
bb20:
  %t68 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l53
  %t69 = call ptr @__olang_scope_alloc_a(ptr %s4, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t68, ptr %t69
  store ptr %t69, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s5
  %t71 = load ptr, ptr %l9, !tbaa !29
  %t72 = load i64, ptr %l10, !tbaa !24
  %t75 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %s4, ptr %t71, i64 %t72)
  %t76 = extractvalue { i32, { i64, ptr } } %t75, 1
  %t77 = extractvalue { i32, { i64, ptr } } %t75, 0
  store i32 %t77, ptr %l59
  %t78 = icmp ne i32 %t77, 0
  br i1 %t78, label %bb23, label %ok.79
ok.79:
  store { i64, ptr } %t76, ptr %l58
  br label %bb22
bb22:
  %t80 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t80, ptr %l55, !tbaa !27
  br label %bb27
bb23:
  %t81 = load i32, ptr %l59, !tbaa !23
  %t82 = ashr i32 %t81, 16
  %t84 = icmp eq i32 %t82, 1
  br i1 %t84, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  %t86 = load i32, ptr %l59, !tbaa !23
  %t87 = lshr i32 %t86, 16
  %t88 = and i32 %t86, 65535
  %t89 = icmp eq i32 %t87, 1
  %t90 = select i1 %t89, i32 0, i32 0
  %t91 = icmp eq i32 %t86, 0
  %t92 = shl i32 %t90, 16
  %t93 = or i32 %t92, %t88
  %t94 = select i1 %t91, i32 0, i32 %t93
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  %t96 = insertvalue { i32, i32 } zeroinitializer, i32 %t94, 0
  store { i32, i32 } %t96, ptr %rv
  br label %ret
bb26:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s5)
  br label %bb52
bb27:
  %t97 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t97, ptr %l11, !tbaa !27
  %t98 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t98, 0
  store i64 %t100, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb28
bb28:
  store %olang.scope zeroinitializer, ptr %s6
  %t102 = load i64, ptr %l13, !tbaa !24
  %t103 = load i64, ptr %l12, !tbaa !24
  %t106 = icmp slt i64 %t102, %t103
  %t108 = xor i1 %t106, true
  br i1 %t108, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s6)
  br label %bb50
bb30:
  br label %bb31
bb31:
  %t110 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t110, ptr %l69, !tbaa !27
  %t111 = load i64, ptr %l13, !tbaa !24
  %t113 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = getelementptr { i64, ptr }, ptr %t114, i64 %t111
  %t116 = load { i64, ptr }, ptr %t115, !tbaa !37
  store { i64, ptr } %t116, ptr %l14, !tbaa !27
  %t118 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t120 = call { i64, ptr } @compiler_2finterp_2eLoadLibrary(ptr %s4, ptr %s6, { i64, ptr } %t118)
  store { i64, ptr } %t120, ptr %l73
  br label %bb32
bb32:
  %t121 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t121, ptr %l15, !tbaa !27
  %t122 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t124 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s6, ptr %s6, { i64, ptr } %t122, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d136, i32 0, i32 1) })
  store i1 %t124, ptr %l75
  br label %bb33
bb33:
  %t125 = load i1, ptr %l75, !tbaa !21
  %t126 = xor i1 %t125, true
  br i1 %t126, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s7
  %t128 = load ptr, ptr %l4, !tbaa !29
  store ptr %t128, ptr %l77, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t129
  %t130 = getelementptr { i64, [3 x i64] }, ptr %t129, i32 0, i32 0
  store i64 0, ptr %t130
  %t131 = load { i64, [3 x i64] }, ptr %t129
  store { i64, [3 x i64] } %t131, ptr %l78
  %t132 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t134 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s4, ptr %s7, { i64, ptr } %t132, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d137, i32 0, i32 1) })
  store i1 %t134, ptr %l80
  br label %bb36
bb35:
  br label %bb48
bb36:
  %t135 = load i1, ptr %l80, !tbaa !21
  br i1 %t135, label %bb37, label %bb38
bb37:
  %t136 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t136, ptr %l82, !tbaa !27
  %t137 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t137, 0
  store i64 %t140, ptr %l85, !tbaa !24
  %t141 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t141, 0
  store i64 %t142, ptr %l86, !tbaa !24
  %t143 = icmp sge i64 2, 0
  br i1 %t143, label %bb39, label %bb40
bb38:
  %t145 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t147 = extractvalue { i64, ptr } %t145, 1
  %t148 = extractvalue { i64, ptr } %t145, 0
  %t149 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t148)
  call void @olang_textcopy(ptr %t149, ptr %t147, i64 %t148)
  %t150 = insertvalue { i64, ptr } undef, i64 %t148, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t149, 1
  %t153 = extractvalue { i64, ptr } %t151, 0
  %t154 = extractvalue { i64, ptr } %t151, 1
  %t155 = mul i64 %t153, 1
  %t156 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t155)
  call void @llvm.memcpy.p0.p0.i64(ptr %t156, ptr %t154, i64 %t155, i1 false)
  %t157 = insertvalue { i64, ptr } undef, i64 %t153, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t156, 1
  store { i64, ptr } %t158, ptr %l81, !tbaa !27
  br label %bb45
bb39:
  %t160 = load i64, ptr %l85, !tbaa !24
  %t161 = icmp sle i64 2, %t160
  br i1 %t161, label %bb41, label %bb42
bb40:
  call void @__olang_check_failed(ptr @olang_loc_436dc8a09a076c49_2aa9a29c41caf045)
  unreachable
bb41:
  %t163 = load i64, ptr %l85, !tbaa !24
  %t164 = load i64, ptr %l86, !tbaa !24
  %t165 = icmp sle i64 %t163, %t164
  br i1 %t165, label %bb43, label %bb44
bb42:
  call void @__olang_check_failed(ptr @olang_loc_436dc8a09a076c49_2aa9a29c41caf045)
  unreachable
bb43:
  %t167 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t168 = load ptr, ptr %t167, !tbaa !27
  %t169 = load i64, ptr %l85, !tbaa !24
  %t170 = getelementptr i8, ptr %t168, i64 2
  %t171 = sub i64 %t169, 2
  %t172 = insertvalue { i64, ptr } undef, i64 %t171, 0
  %t173 = insertvalue { i64, ptr } %t172, ptr %t170, 1
  %t175 = extractvalue { i64, ptr } %t173, 1
  %t176 = extractvalue { i64, ptr } %t173, 0
  %t177 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t176)
  call void @olang_textcopy(ptr %t177, ptr %t175, i64 %t176)
  %t178 = insertvalue { i64, ptr } undef, i64 %t176, 0
  %t179 = insertvalue { i64, ptr } %t178, ptr %t177, 1
  %t181 = extractvalue { i64, ptr } %t179, 0
  %t182 = extractvalue { i64, ptr } %t179, 1
  %t183 = mul i64 %t181, 1
  %t184 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t183)
  call void @llvm.memcpy.p0.p0.i64(ptr %t184, ptr %t182, i64 %t183, i1 false)
  %t185 = insertvalue { i64, ptr } undef, i64 %t181, 0
  %t186 = insertvalue { i64, ptr } %t185, ptr %t184, 1
  store { i64, ptr } %t186, ptr %l81, !tbaa !27
  br label %bb45
bb44:
  call void @__olang_check_failed(ptr @olang_loc_436dc8a09a076c49_2aa9a29c41caf045)
  unreachable
bb45:
  %t188 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t189 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t191 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eInterpLink(ptr %s7, ptr %s6, ptr %s7, { i64, ptr } %t189, { i64, ptr } %t188)
  store %"compiler/msgs:Msg" %t191, ptr %l97
  br label %bb46
bb46:
  %t192 = load ptr, ptr %l77, !tbaa !29
  %t193 = load { i64, [3 x i64] }, ptr %l78
  %t194 = load %"compiler/msgs:Msg", ptr %l97
  %t195 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v3, ptr %s7, ptr %t192, { i64, [3 x i64] } %t193, %"compiler/msgs:Msg" %t194)
  store i64 %t195, ptr %l98
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s7)
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s6)
  br label %bb49
bb49:
  %t196 = load i64, ptr %l13, !tbaa !24
  %t198 = add i64 %t196, 1
  store i64 %t198, ptr %l13, !tbaa !24
  br label %bb28
bb50:
  %t200 = load i64, ptr %l10, !tbaa !24
  %t201 = load i64, ptr %l12, !tbaa !24
  %t204 = add i64 %t200, %t201
  store i64 %t204, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb51
bb51:
  br label %bb21
bb52:
  call void @__olang_scope_close(ptr %s4)
  %t206 = load ptr, ptr %l4, !tbaa !29
  %t208 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v3, ptr %t206)
  store i64 %t208, ptr %l105
  br label %bb53
bb53:
  %t209 = load i64, ptr %l105, !tbaa !24
  %t210 = icmp sgt i64 %t209, 0
  br i1 %t210, label %bb54, label %bb55
bb54:
  %t213 = insertvalue { i32, i32 } zeroinitializer, i32 65536, 0
  store { i32, i32 } %t213, ptr %rv
  br label %ret
bb55:
  br label %bb56
bb56:
  %t214 = load ptr, ptr %l6, !tbaa !29
  %t216 = getelementptr %"compiler/check:Checker", ptr %t214, i32 0, i32 1
  %t217 = load ptr, ptr %t216, !tbaa !29
  %t218 = load ptr, ptr %l6, !tbaa !29
  %t220 = getelementptr %"compiler/check:Checker", ptr %t218, i32 0, i32 11
  %t221 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t220
  call void @compiler_2finterp_3aExec_2ector(ptr %t222, ptr %v3, ptr %v3, ptr %v3, ptr %t217, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t221, i32 1)
  call void @llvm.memmove.p0.p0.i64(ptr %l113, ptr %t222, i64 976, i1 false)
  br label %bb57
bb57:
  %t226 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 976, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t226, ptr %l113, i64 976, i1 false)
  store ptr %t226, ptr %l16, !tbaa !29
  %t228 = load ptr, ptr %l16, !tbaa !29
  %t229 = load ptr, ptr %l7, !tbaa !29
  %t231 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t229
  %t234 = getelementptr %"compiler/interp:Exec", ptr %t228, i32 0, i32 3
  %t235 = getelementptr %"compiler/lower:Lowerer", ptr %t234, i32 0, i32 7
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t231, ptr %t235
  %t236 = load ptr, ptr %l16, !tbaa !29
  %t238 = getelementptr %"compiler/interp:Exec", ptr %t236, i32 0, i32 3
  %t239 = getelementptr %"compiler/lower:Lowerer", ptr %t238, i32 0, i32 6
  store i1 true, ptr %t239, !tbaa !21
  %t240 = load ptr, ptr %l6, !tbaa !29
  %t241 = load ptr, ptr %l3, !tbaa !29
  %t242 = load ptr, ptr %l5, !tbaa !29
  %t244 = getelementptr %"compiler/load:Loader", ptr %t242, i32 0, i32 7
  %t245 = load i64, ptr %t244, !tbaa !24
  %t249 = call ptr @compiler_2folang_2eplacement(ptr %v3, ptr %v3, ptr %t240, ptr %t241, i64 %t245, i1 true)
  store ptr %t249, ptr %l123
  br label %bb58
bb58:
  %t250 = load ptr, ptr %l123, !tbaa !29
  store ptr %t250, ptr %l17, !tbaa !29
  %t251 = load ptr, ptr %l4, !tbaa !29
  %t253 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v3, ptr %t251)
  store i64 %t253, ptr %l125
  br label %bb59
bb59:
  %t254 = load i64, ptr %l125, !tbaa !24
  %t255 = icmp sgt i64 %t254, 0
  br i1 %t255, label %bb60, label %bb61
bb60:
  %t258 = insertvalue { i32, i32 } zeroinitializer, i32 65536, 0
  store { i32, i32 } %t258, ptr %rv
  br label %ret
bb61:
  br label %bb62
bb62:
  %t259 = load ptr, ptr %l16, !tbaa !29
  %t260 = load ptr, ptr %l17, !tbaa !29
  %t262 = getelementptr %"compiler/free:Free", ptr %t260, i32 0, i32 3
  %t263 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t262
  %t266 = getelementptr %"compiler/interp:Exec", ptr %t259, i32 0, i32 3
  %t267 = getelementptr %"compiler/lower:Lowerer", ptr %t266, i32 0, i32 2
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t263, ptr %t267
  %t268 = load ptr, ptr %l16, !tbaa !29
  %t269 = load ptr, ptr %l17, !tbaa !29
  %t273 = getelementptr %"compiler/interp:Exec", ptr %t268, i32 0, i32 3
  %t274 = getelementptr %"compiler/lower:Lowerer", ptr %t273, i32 0, i32 3
  store ptr %t269, ptr %t274, !tbaa !29
  store { i64, ptr } %a2, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t277 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t279 = extractvalue { i64, ptr } %t277, 0
  store i64 %t279, ptr %l20, !tbaa !24
  br label %bb63
bb63:
  store %olang.scope zeroinitializer, ptr %s14
  %t281 = load i64, ptr %l19, !tbaa !24
  %t282 = load i64, ptr %l20, !tbaa !24
  %t285 = icmp slt i64 %t281, %t282
  %t287 = xor i1 %t285, true
  br i1 %t287, label %bb64, label %bb65
bb64:
  call void @__olang_scope_close(ptr %s14)
  br label %bb69
bb65:
  br label %bb66
bb66:
  %t289 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t289, ptr %l141, !tbaa !27
  %t290 = load i64, ptr %l19, !tbaa !24
  %t292 = getelementptr { i64, ptr }, ptr %l141, i32 0, i32 1
  %t293 = load ptr, ptr %t292, !tbaa !27
  %t294 = getelementptr { i64, ptr }, ptr %t293, i64 %t290
  %t295 = load { i64, ptr }, ptr %t294, !tbaa !37
  %t297 = load ptr, ptr %l16, !tbaa !29
  %t299 = getelementptr %"compiler/interp:Exec", ptr %t297, i32 0, i32 4
  %t300 = getelementptr %"compiler/eval:Machine", ptr %t299, i32 0, i32 72
  %t303 = extractvalue { i64, ptr } %t295, 1
  %t304 = extractvalue { i64, ptr } %t295, 0
  %t305 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t304)
  call void @olang_textcopy(ptr %t305, ptr %t303, i64 %t304)
  %t306 = insertvalue { i64, ptr } undef, i64 %t304, 0
  %t307 = insertvalue { i64, ptr } %t306, ptr %t305, 1
  %t309 = extractvalue { i64, ptr } %t307, 0
  %t310 = extractvalue { i64, ptr } %t307, 1
  %t311 = mul i64 %t309, 1
  %t312 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t311)
  call void @llvm.memcpy.p0.p0.i64(ptr %t312, ptr %t310, i64 %t311, i1 false)
  %t313 = insertvalue { i64, ptr } undef, i64 %t309, 0
  %t314 = insertvalue { i64, ptr } %t313, ptr %t312, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v3, ptr %v3, ptr %t300, { i64, ptr } %t314)
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s14)
  br label %bb68
bb68:
  %t317 = load i64, ptr %l19, !tbaa !24
  %t319 = add i64 %t317, 1
  store i64 %t319, ptr %l19, !tbaa !24
  br label %bb63
bb69:
  %t321 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eInterpCrash, !tbaa !27
  %t322 = load ptr, ptr @__olang_prog_scope
  call void @std_2fos_2eOnCrash(ptr %t322, { i64, ptr } %t321)
  br label %bb70
bb70:
  %t324 = load ptr, ptr %l16, !tbaa !29
  %t325 = load ptr, ptr %l4, !tbaa !29
  %t328 = call i32 @compiler_2finterp_2ecompiler_2finterp_3aExec_2eRunMain(ptr %v3, ptr %v3, ptr %t324, ptr %t325)
  store i32 %t328, ptr %l154
  br label %bb71
bb71:
  %t329 = load i32, ptr %l154, !tbaa !23
  store i32 %t329, ptr %l22, !tbaa !23
  %t330 = load i32, ptr %l22, !tbaa !23
  %t332 = icmp eq i32 %t330, 134
  br i1 %t332, label %bb72, label %bb73
bb72:
  store %olang.scope zeroinitializer, ptr %s17
  call void @std_2fos_2eOnCrash(ptr %s17, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d138, i32 0, i32 1) })
  br label %bb74
bb73:
  br label %bb76
bb74:
  call void @abort()
  unreachable
bb75:
  call void @__olang_check_failed(ptr @olang_loc_d9ce39c2cb08642b_edb226294df0b2a7)
  unreachable
bb76:
  %t334 = load i32, ptr %l22, !tbaa !23
  %t336 = insertvalue { i32, i32 } zeroinitializer, i32 %t334, 1
  store { i32, i32 } %t336, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i32 }, ptr %rv
  ret { i32, i32 } %rr
}

define dso_local { i32, ptr } @compiler_2folang_2ecompiler_2folang_3aPasses_2eload(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l16 = alloca %"compiler/fetch:Fetcher"
  %l18 = alloca %"compiler/source:Names"
  %l20 = alloca { i64, ptr }
  %l27 = alloca %"compiler/load:Loader"
  %l31 = alloca i64
  %l32 = alloca ptr
  %l35 = alloca i64
  %l37 = alloca i64
  %rv = alloca { i32, ptr }
  store { i64, ptr } %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = call { i64, ptr } @compiler_2fload_2eLockPath(ptr %v1, ptr %v2, { i64, ptr } %t1)
  store { i64, ptr } %t3, ptr %l8
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t4, 0
  %t6 = extractvalue { i64, ptr } %t4, 1
  %t7 = mul i64 %t5, 1
  %t8 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t7)
  call void @llvm.memcpy.p0.p0.i64(ptr %t8, ptr %t6, i64 %t7, i1 false)
  %t9 = insertvalue { i64, ptr } undef, i64 %t5, 0
  %t10 = insertvalue { i64, ptr } %t9, ptr %t8, 1
  store { i64, ptr } %t10, ptr %l9, !tbaa !27
  %t11 = call { i64, ptr } @compiler_2ffetch_2eCacheDir(ptr %v2)
  store { i64, ptr } %t11, ptr %l10
  br label %bb2
bb2:
  %t12 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 0
  %t14 = extractvalue { i64, ptr } %t12, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l11, !tbaa !27
  %t19 = call { i64, ptr } @compiler_2ffetch_2eGitBase(ptr %v2)
  store { i64, ptr } %t19, ptr %l12
  br label %bb3
bb3:
  %t20 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t20, 0
  %t22 = extractvalue { i64, ptr } %t20, 1
  %t23 = mul i64 %t21, 1
  %t24 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t23)
  call void @llvm.memcpy.p0.p0.i64(ptr %t24, ptr %t22, i64 %t23, i1 false)
  %t25 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t24, 1
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t29 = getelementptr %"compiler/build:Config", ptr %t27, i32 0, i32 10
  %t30 = load i1, ptr %t29, !tbaa !21
  %t31 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t35 = call %"compiler/fetch:Fetcher" @compiler_2ffetch_3aFetcher_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t31, { i64, ptr } %t32, { i64, ptr } %t26, i1 %t30, i1 false)
  store %"compiler/fetch:Fetcher" %t35, ptr %l16
  br label %bb4
bb4:
  %t36 = load %"compiler/fetch:Fetcher", ptr %l16
  %t37 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 88, i64 8)
  store %"compiler/fetch:Fetcher" %t36, ptr %t37
  store ptr %t37, ptr %l4, !tbaa !29
  %t39 = call %"compiler/source:Names" @compiler_2fsource_3aNames_2ector(ptr %v2)
  store %"compiler/source:Names" %t39, ptr %l18
  br label %bb5
bb5:
  %t40 = load %"compiler/source:Names", ptr %l18
  %t41 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store %"compiler/source:Names" %t40, ptr %t41
  store ptr %t41, ptr %l5, !tbaa !29
  %t43 = call { i64, ptr } @compiler_2fload_2eStdDir(ptr %v2)
  store { i64, ptr } %t43, ptr %l20
  br label %bb6
bb6:
  %t44 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t44, 0
  %t46 = extractvalue { i64, ptr } %t44, 1
  %t47 = mul i64 %t45, 1
  %t48 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t47)
  call void @llvm.memcpy.p0.p0.i64(ptr %t48, ptr %t46, i64 %t47, i1 false)
  %t49 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  %t51 = load ptr, ptr %l2, !tbaa !29
  %t53 = getelementptr %"compiler/build:Config", ptr %t51, i32 0, i32 3
  %t54 = load ptr, ptr %l4, !tbaa !29
  %t55 = load ptr, ptr %l5, !tbaa !29
  %t56 = load ptr, ptr %l3, !tbaa !29
  %t62 = call %"compiler/load:Loader" @compiler_2fload_3aLoader_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t50, ptr %t53, ptr %t54, ptr %t55, ptr %t56)
  store %"compiler/load:Loader" %t62, ptr %l27
  br label %bb7
bb7:
  %t63 = load %"compiler/load:Loader", ptr %l27
  %t64 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 120, i64 8)
  store %"compiler/load:Loader" %t63, ptr %t64
  store ptr %t64, ptr %l6, !tbaa !29
  %t66 = load ptr, ptr %l6, !tbaa !29
  %t67 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t70 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eLoad(ptr %v2, ptr %v1, ptr %t66, { i64, ptr } %t67)
  store i64 %t70, ptr %l31
  br label %bb8
bb8:
  store ptr %a0, ptr %l32, !tbaa !29
  %t72 = load ptr, ptr %l6, !tbaa !29
  %t74 = getelementptr %"compiler/load:Loader", ptr %t72, i32 0, i32 5
  %t76 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v2, ptr %t74)
  store i64 %t76, ptr %l35
  br label %bb9
bb9:
  %t77 = load i64, ptr %l35, !tbaa !24
  %t78 = load ptr, ptr %l32, !tbaa !29
  %t79 = getelementptr %"compiler/olang:Passes", ptr %t78, i32 0, i32 0
  store i64 %t77, ptr %t79, !tbaa !24
  %t80 = load ptr, ptr %l3, !tbaa !29
  %t82 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v2, ptr %t80)
  store i64 %t82, ptr %l37
  br label %bb10
bb10:
  %t83 = load i64, ptr %l37, !tbaa !24
  %t84 = icmp sgt i64 %t83, 0
  br i1 %t84, label %bb11, label %bb12
bb11:
  %t87 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t87, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t88 = load ptr, ptr %l6, !tbaa !29
  %t90 = insertvalue { i32, ptr } zeroinitializer, ptr %t88, 1
  store { i32, ptr } %t90, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i32 @compiler_2folang_2edrive(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"compiler/olang:Passes"
  %l2 = alloca %"compiler/olang:Passes"
  %l5 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"compiler/olang:Passes" @compiler_2folang_3aPasses_2ector(ptr %s0)
  store %"compiler/olang:Passes" %t1, ptr %l2
  br label %bb1
bb1:
  %t2 = load %"compiler/olang:Passes", ptr %l2
  store %"compiler/olang:Passes" %t2, ptr %l1
  %t6 = call i32 @compiler_2folang_2eRunWith_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %s0, { i64, ptr } %a0, ptr %l1)
  store i32 %t6, ptr %l5
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t7 = load i32, ptr %l5, !tbaa !23
  store i32 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local ptr @compiler_2folang_2eemitter(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, ptr %a3, i32 %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l6 = alloca i1
  %l7 = alloca ptr
  %l17 = alloca %"compiler/emit:Emitter"
  %l24 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l52 = alloca i1
  %l55 = alloca ptr
  %l58 = alloca i1
  %l65 = alloca i1
  %rv = alloca ptr
  %t18 = alloca %"compiler/emit:Emitter", align 8
  store ptr %a0, ptr %l0
  store ptr %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l4
  %t3 = trunc i64 2 to i32
  %t4 = icmp eq i32 %t1, %t3
  store i1 %t4, ptr %l6, !tbaa !21
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  call void @compiler_2femit_3aEmitter_2ector(ptr %t18, ptr %v0, ptr %v1, ptr %v2, ptr %v0, ptr %v3, ptr %t9, ptr %a1, ptr %a2, ptr %t17)
  call void @llvm.memmove.p0.p0.i64(ptr %l17, ptr %t18, i64 544, i1 false)
  br label %bb1
bb1:
  %t23 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 544, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t23, ptr %l17, i64 544, i1 false)
  store ptr %t23, ptr %l7, !tbaa !29
  %t25 = load ptr, ptr %l7, !tbaa !29
  %t26 = load i1, ptr %l6, !tbaa !21
  %t29 = getelementptr %"compiler/emit:Emitter", ptr %t25, i32 0, i32 4
  store i1 %t26, ptr %t29, !tbaa !21
  %t30 = load ptr, ptr %l7, !tbaa !29
  %t33 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a5
  %t36 = getelementptr %"compiler/emit:Emitter", ptr %t30, i32 0, i32 44
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t33, ptr %t36
  %t37 = load ptr, ptr %l7, !tbaa !29
  store ptr %t37, ptr %l24, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t40 = getelementptr %"compiler/build:Config", ptr %t38, i32 0, i32 6
  %t41 = load i1, ptr %t40, !tbaa !21
  br i1 %t41, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d139, i32 0, i32 1) }, ptr %l27, !tbaa !27
  br label %bb4
bb3:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d140, i32 0, i32 1) }, ptr %l27, !tbaa !27
  br label %bb4
bb4:
  %t43 = load ptr, ptr %l3, !tbaa !29
  %t45 = getelementptr %"compiler/build:Config", ptr %t43, i32 0, i32 2
  %t46 = getelementptr %"compiler/target:Target", ptr %t45, i32 0, i32 5
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t48, 1
  %t50 = extractvalue { i64, ptr } %t48, 0
  %t52 = extractvalue { i64, ptr } %t47, 1
  %t53 = extractvalue { i64, ptr } %t47, 0
  %t54 = add i64 %t50, %t53
  %t55 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t54)
  call void @olang_textcopy(ptr %t55, ptr %t49, i64 %t50)
  %t56 = getelementptr i8, ptr %t55, i64 %t50
  call void @olang_textcopy(ptr %t56, ptr %t52, i64 %t53)
  %t57 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t55, 1
  %t60 = extractvalue { i64, ptr } %t58, 0
  %t61 = extractvalue { i64, ptr } %t58, 1
  %t62 = mul i64 %t60, 1
  %t63 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t62)
  call void @llvm.memcpy.p0.p0.i64(ptr %t63, ptr %t61, i64 %t62, i1 false)
  %t64 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t63, 1
  %t67 = load ptr, ptr %l24, !tbaa !29
  %t68 = getelementptr %"compiler/emit:Emitter", ptr %t67, i32 0, i32 8
  store { i64, ptr } %t65, ptr %t68, !tbaa !27
  %t69 = load ptr, ptr %l7, !tbaa !29
  %t70 = load i32, ptr %l4
  %t72 = trunc i64 0 to i32
  %t73 = icmp eq i32 %t70, %t72
  %t76 = getelementptr %"compiler/emit:Emitter", ptr %t69, i32 0, i32 38
  store i1 %t73, ptr %t76, !tbaa !21
  %t77 = load ptr, ptr %l7, !tbaa !29
  %t78 = load ptr, ptr %l3, !tbaa !29
  %t80 = getelementptr %"compiler/build:Config", ptr %t78, i32 0, i32 2
  %t81 = getelementptr %"compiler/target:Target", ptr %t80, i32 0, i32 1
  %t82 = load { i64, ptr }, ptr %t81, !tbaa !27
  %t85 = getelementptr %"compiler/emit:Emitter", ptr %t77, i32 0, i32 21
  store { i64, ptr } %t82, ptr %t85, !tbaa !27
  %t86 = load ptr, ptr %l7, !tbaa !29
  %t87 = load ptr, ptr %l3, !tbaa !29
  %t89 = getelementptr %"compiler/build:Config", ptr %t87, i32 0, i32 2
  %t90 = getelementptr %"compiler/target:Target", ptr %t89, i32 0, i32 2
  %t91 = load { i64, ptr }, ptr %t90, !tbaa !27
  %t94 = getelementptr %"compiler/emit:Emitter", ptr %t86, i32 0, i32 45
  store { i64, ptr } %t91, ptr %t94, !tbaa !27
  %t95 = load ptr, ptr %l7, !tbaa !29
  %t96 = load ptr, ptr %l3, !tbaa !29
  %t98 = getelementptr %"compiler/build:Config", ptr %t96, i32 0, i32 7
  %t99 = load i1, ptr %t98, !tbaa !21
  %t102 = getelementptr %"compiler/emit:Emitter", ptr %t95, i32 0, i32 46
  store i1 %t99, ptr %t102, !tbaa !21
  %t103 = load ptr, ptr %l7, !tbaa !29
  %t104 = load ptr, ptr %l3, !tbaa !29
  %t106 = getelementptr %"compiler/build:Config", ptr %t104, i32 0, i32 4
  %t107 = load i1, ptr %t106, !tbaa !21
  %t110 = getelementptr %"compiler/emit:Emitter", ptr %t103, i32 0, i32 5
  store i1 %t107, ptr %t110, !tbaa !21
  %t111 = load ptr, ptr %l7, !tbaa !29
  %t112 = load i1, ptr %l6, !tbaa !21
  %t115 = getelementptr %"compiler/emit:Emitter", ptr %t111, i32 0, i32 7
  store i1 %t112, ptr %t115, !tbaa !21
  %t116 = load ptr, ptr %l7, !tbaa !29
  store ptr %t116, ptr %l49, !tbaa !29
  %t117 = load ptr, ptr %l3, !tbaa !29
  %t119 = getelementptr %"compiler/build:Config", ptr %t117, i32 0, i32 4
  %t120 = load i1, ptr %t119, !tbaa !21
  br i1 %t120, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l52, !tbaa !21
  br label %bb7
bb6:
  %t122 = load ptr, ptr %l3, !tbaa !29
  %t124 = getelementptr %"compiler/build:Config", ptr %t122, i32 0, i32 6
  %t125 = load i1, ptr %t124, !tbaa !21
  store i1 %t125, ptr %l52, !tbaa !21
  br label %bb7
bb7:
  %t127 = load i1, ptr %l52, !tbaa !21
  %t128 = load ptr, ptr %l49, !tbaa !29
  %t129 = getelementptr %"compiler/emit:Emitter", ptr %t128, i32 0, i32 47
  store i1 %t127, ptr %t129, !tbaa !21
  %t130 = load ptr, ptr %l7, !tbaa !29
  store ptr %t130, ptr %l55, !tbaa !29
  %t131 = load ptr, ptr %l3, !tbaa !29
  %t133 = getelementptr %"compiler/build:Config", ptr %t131, i32 0, i32 9
  %t134 = load i1, ptr %t133, !tbaa !21
  br i1 %t134, label %bb8, label %bb9
bb8:
  %t136 = load i32, ptr %l4
  %t138 = trunc i64 1 to i32
  %t139 = icmp eq i32 %t136, %t138
  store i1 %t139, ptr %l58, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l58, !tbaa !21
  br label %bb10
bb10:
  %t141 = load i1, ptr %l58, !tbaa !21
  %t142 = load ptr, ptr %l55, !tbaa !29
  %t143 = getelementptr %"compiler/emit:Emitter", ptr %t142, i32 0, i32 6
  store i1 %t141, ptr %t143, !tbaa !21
  %t144 = load ptr, ptr %l7, !tbaa !29
  %t145 = load i64, ptr @G_2ecompiler_2fbuild_2eThinFrom, !tbaa !24
  %t148 = getelementptr %"compiler/emit:Emitter", ptr %t144, i32 0, i32 39
  store i64 %t145, ptr %t148, !tbaa !24
  %t149 = load ptr, ptr %l3, !tbaa !29
  %t151 = getelementptr %"compiler/build:Config", ptr %t149, i32 0, i32 5
  %t152 = load i1, ptr %t151, !tbaa !21
  br i1 %t152, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l65, !tbaa !21
  br label %bb13
bb12:
  %t154 = load ptr, ptr %l3, !tbaa !29
  %t156 = getelementptr %"compiler/build:Config", ptr %t154, i32 0, i32 4
  %t157 = load i1, ptr %t156, !tbaa !21
  store i1 %t157, ptr %l65, !tbaa !21
  br label %bb13
bb13:
  %t159 = load i1, ptr %l65, !tbaa !21
  br i1 %t159, label %bb14, label %bb15
bb14:
  %t160 = load ptr, ptr %l7, !tbaa !29
  %t161 = load i64, ptr @G_2ecompiler_2femit_2ePartSizeDev, !tbaa !24
  %t164 = getelementptr %"compiler/emit:Emitter", ptr %t160, i32 0, i32 40
  store i64 %t161, ptr %t164, !tbaa !24
  br label %bb16
bb15:
  br label %bb16
bb16:
  %t165 = load ptr, ptr %l7, !tbaa !29
  %t166 = load i32, ptr %l4
  %t168 = trunc i64 0 to i32
  %t169 = icmp eq i32 %t166, %t168
  %t171 = xor i1 %t169, true
  %t174 = getelementptr %"compiler/emit:Emitter", ptr %t165, i32 0, i32 65
  store i1 %t171, ptr %t174, !tbaa !21
  %t175 = load ptr, ptr %l7, !tbaa !29
  store ptr %t175, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2folang_2eendsWithOlang(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l4 = alloca i1
  %l6 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp sgt i64 %t3, 6
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t9 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %s0, { i64, ptr } %t7, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d141, i32 0, i32 1) })
  store i1 %t9, ptr %l6
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb4
bb3:
  %t10 = load i1, ptr %l6, !tbaa !21
  store i1 %t10, ptr %l4, !tbaa !21
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t11 = load i1, ptr %l4, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2folang_2eexplainRule(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %lp4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca { i64, [3 x i64] }
  %l16 = alloca %"compiler/msgs:Msg"
  %l17 = alloca i64
  %l19 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i32
  %l25 = alloca ptr
  %l26 = alloca { i64, [3 x i64] }
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca i64
  %l45 = alloca %"compiler/msgs:Msg"
  %l46 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  %t28 = alloca { i64, [3 x i64] }, align 8
  %t53 = alloca { i64, [3 x i64] }, align 8
  store { i64, ptr } %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i64, ptr } @compiler_2fdiag_2eSpecPath(ptr %s0)
  store { i64, ptr } %t1, ptr %l5
  br label %bb1
bb1:
  %t2 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t2, ptr %l2, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s0, { i64, ptr } %t3)
  %t6 = extractvalue { i32, { i64, ptr } } %t5, 1
  %t7 = extractvalue { i32, { i64, ptr } } %t5, 0
  store i32 %t7, ptr %l9
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb3, label %ok.9
ok.9:
  store { i64, ptr } %t6, ptr %l8
  br label %bb2
bb2:
  %t10 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t10, ptr %l6, !tbaa !27
  br label %bb9
bb3:
  %t11 = load i32, ptr %l9, !tbaa !23
  %t12 = ashr i32 %t11, 16
  %t14 = icmp eq i32 %t12, 1
  br i1 %t14, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load i32, ptr %l9, !tbaa !23
  %t17 = lshr i32 %t16, 16
  %t18 = and i32 %t16, 65535
  %t19 = icmp eq i32 %t17, 1
  %t20 = select i1 %t19, i32 0, i32 0
  %t21 = icmp eq i32 %t16, 0
  %t22 = shl i32 %t20, 16
  %t23 = or i32 %t22, %t18
  %t24 = select i1 %t21, i32 0, i32 %t23
  call void @__olang_scope_close(ptr %s0)
  %t26 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t24, 0
  store { i32, { i64, ptr } } %t26, ptr %rv
  br label %ret
bb6:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s1
  %t27 = load ptr, ptr %l1, !tbaa !29
  store ptr %t27, ptr %l13, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t28
  %t29 = getelementptr { i64, [3 x i64] }, ptr %t28, i32 0, i32 0
  store i64 0, ptr %t29
  %t30 = load { i64, [3 x i64] }, ptr %t28
  store { i64, [3 x i64] } %t30, ptr %l14
  %t31 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t33 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoSpec(ptr %s0, ptr %s1, { i64, ptr } %t31)
  store %"compiler/msgs:Msg" %t33, ptr %l16
  br label %bb7
bb7:
  %t34 = load ptr, ptr %l13, !tbaa !29
  %t35 = load { i64, [3 x i64] }, ptr %l14
  %t36 = load %"compiler/msgs:Msg", ptr %l16
  %t37 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v1, ptr %s1, ptr %t34, { i64, [3 x i64] } %t35, %"compiler/msgs:Msg" %t36)
  store i64 %t37, ptr %l17
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t39 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t39, ptr %rv
  br label %ret
bb9:
  %t40 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t43 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t46 = call { i32, { i64, ptr } } @compiler_2fdiag_2eExplain(ptr %s0, ptr %v0, ptr %v2, { i64, ptr } %t40, { i64, ptr } %t43)
  %t47 = extractvalue { i32, { i64, ptr } } %t46, 1
  %t48 = extractvalue { i32, { i64, ptr } } %t46, 0
  store i32 %t48, ptr %l24
  %t49 = icmp ne i32 %t48, 0
  br i1 %t49, label %bb11, label %ok.50
ok.50:
  store { i64, ptr } %t47, ptr %l23
  br label %bb10
bb10:
  %t51 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t51, ptr %l19, !tbaa !27
  br label %bb28
bb11:
  br label %bb12
bb12:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s2
  %t52 = load ptr, ptr %l1, !tbaa !29
  store ptr %t52, ptr %l25, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t53
  %t54 = getelementptr { i64, [3 x i64] }, ptr %t53, i32 0, i32 0
  store i64 0, ptr %t54
  %t55 = load { i64, [3 x i64] }, ptr %t53
  store { i64, [3 x i64] } %t55, ptr %l26
  %t56 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t56, ptr %l27, !tbaa !27
  %t57 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t57, 0
  store i64 %t58, ptr %l28, !tbaa !24
  %t59 = icmp sge i64 0, 0
  br i1 %t59, label %bb13, label %bb14
bb13:
  %t61 = icmp sle i64 0, 1
  br i1 %t61, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_8c7e755ea0eb9876_6b14028370dd0cea)
  unreachable
bb15:
  %t63 = load i64, ptr %l28, !tbaa !24
  %t64 = icmp sle i64 1, %t63
  br i1 %t64, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_8c7e755ea0eb9876_6b14028370dd0cea)
  unreachable
bb17:
  %t66 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !27
  %t68 = getelementptr i8, ptr %t67, i64 0
  %t69 = sub i64 1, 0
  %t70 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t68, 1
  %t73 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eToUpper(ptr %v0, ptr %s2, { i64, ptr } %t71)
  store { i64, ptr } %t73, ptr %l33
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_8c7e755ea0eb9876_6b14028370dd0cea)
  unreachable
bb19:
  %t74 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t74, ptr %l34, !tbaa !27
  %t75 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t75, 0
  store i64 %t78, ptr %l37, !tbaa !24
  %t79 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t79, 0
  store i64 %t80, ptr %l38, !tbaa !24
  %t81 = icmp sge i64 1, 0
  br i1 %t81, label %bb20, label %bb21
bb20:
  %t83 = load i64, ptr %l37, !tbaa !24
  %t84 = icmp sle i64 1, %t83
  br i1 %t84, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_8c7e755ea0eb9876_6b14028370dd0cea)
  unreachable
bb22:
  %t86 = load i64, ptr %l37, !tbaa !24
  %t87 = load i64, ptr %l38, !tbaa !24
  %t88 = icmp sle i64 %t86, %t87
  br i1 %t88, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_8c7e755ea0eb9876_6b14028370dd0cea)
  unreachable
bb24:
  %t90 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = load i64, ptr %l37, !tbaa !24
  %t93 = getelementptr i8, ptr %t91, i64 1
  %t94 = sub i64 %t92, 1
  %t95 = insertvalue { i64, ptr } undef, i64 %t94, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %t93, 1
  %t97 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t97, 1
  %t99 = extractvalue { i64, ptr } %t97, 0
  %t101 = extractvalue { i64, ptr } %t96, 1
  %t102 = extractvalue { i64, ptr } %t96, 0
  %t103 = add i64 %t99, %t102
  %t104 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t103)
  call void @olang_textcopy(ptr %t104, ptr %t98, i64 %t99)
  %t105 = getelementptr i8, ptr %t104, i64 %t99
  call void @olang_textcopy(ptr %t105, ptr %t101, i64 %t102)
  %t106 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t104, 1
  %t109 = extractvalue { i64, ptr } %t107, 0
  %t110 = extractvalue { i64, ptr } %t107, 1
  %t111 = mul i64 %t109, 1
  %t112 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t111)
  call void @llvm.memcpy.p0.p0.i64(ptr %t112, ptr %t110, i64 %t111, i1 false)
  %t113 = insertvalue { i64, ptr } undef, i64 %t109, 0
  %t114 = insertvalue { i64, ptr } %t113, ptr %t112, 1
  %t116 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoRule(ptr %s2, ptr %s2, { i64, ptr } %t114)
  store %"compiler/msgs:Msg" %t116, ptr %l45
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_8c7e755ea0eb9876_6b14028370dd0cea)
  unreachable
bb26:
  %t117 = load ptr, ptr %l25, !tbaa !29
  %t118 = load { i64, [3 x i64] }, ptr %l26
  %t119 = load %"compiler/msgs:Msg", ptr %l45
  %t120 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v1, ptr %s2, ptr %t117, { i64, [3 x i64] } %t118, %"compiler/msgs:Msg" %t119)
  store i64 %t120, ptr %l46
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t122 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t122, ptr %rv
  br label %ret
bb28:
  %t123 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t123, ptr %lp4
  %t124 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t125 = load ptr, ptr %lp4
  store { i64, ptr } %t124, ptr %t125, !tbaa !27
  %t126 = load ptr, ptr %lp4
  %t127 = load { i64, ptr }, ptr %t126, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t129 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t127, 1
  store { i32, { i64, ptr } } %t129, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local void @compiler_2folang_2eexplainedSrc_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t1 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d142, i32 0, i32 1) }, 1
  %t2 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d142, i32 0, i32 1) }, 0
  %t3 = extractvalue { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d143, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d143, i32 0, i32 1) }, 0
  %t5 = add i64 %t2, %t4
  %t6 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d144, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d144, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t9 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d145, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d145, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t12 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d146, i32 0, i32 1) }, 1
  %t13 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d146, i32 0, i32 1) }, 0
  %t14 = add i64 %t11, %t13
  %t15 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d147, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d147, i32 0, i32 1) }, 0
  %t17 = add i64 %t14, %t16
  %t18 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d148, i32 0, i32 1) }, 1
  %t19 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d148, i32 0, i32 1) }, 0
  %t20 = add i64 %t17, %t19
  %t21 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d149, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d149, i32 0, i32 1) }, 0
  %t23 = add i64 %t20, %t22
  %t24 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d150, i32 0, i32 1) }, 1
  %t25 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d150, i32 0, i32 1) }, 0
  %t26 = add i64 %t23, %t25
  %t27 = extractvalue { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d151, i32 0, i32 1) }, 1
  %t28 = extractvalue { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d151, i32 0, i32 1) }, 0
  %t29 = add i64 %t26, %t28
  %t30 = extractvalue { i64, ptr } { i64 62, ptr getelementptr inbounds (<{ i64, [62 x i8] }>, ptr @.d152, i32 0, i32 1) }, 1
  %t31 = extractvalue { i64, ptr } { i64 62, ptr getelementptr inbounds (<{ i64, [62 x i8] }>, ptr @.d152, i32 0, i32 1) }, 0
  %t32 = add i64 %t29, %t31
  %t33 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d153, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d153, i32 0, i32 1) }, 0
  %t35 = add i64 %t32, %t34
  %t36 = extractvalue { i64, ptr } { i64 85, ptr getelementptr inbounds (<{ i64, [85 x i8] }>, ptr @.d154, i32 0, i32 1) }, 1
  %t37 = extractvalue { i64, ptr } { i64 85, ptr getelementptr inbounds (<{ i64, [85 x i8] }>, ptr @.d154, i32 0, i32 1) }, 0
  %t38 = add i64 %t35, %t37
  %t39 = extractvalue { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d155, i32 0, i32 1) }, 1
  %t40 = extractvalue { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d155, i32 0, i32 1) }, 0
  %t41 = add i64 %t38, %t40
  %t42 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d156, i32 0, i32 1) }, 1
  %t43 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d156, i32 0, i32 1) }, 0
  %t44 = add i64 %t41, %t43
  %t45 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d157, i32 0, i32 1) }, 1
  %t46 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d157, i32 0, i32 1) }, 0
  %t47 = add i64 %t44, %t46
  %t48 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d158, i32 0, i32 1) }, 1
  %t49 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d158, i32 0, i32 1) }, 0
  %t50 = add i64 %t47, %t49
  %t51 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d159, i32 0, i32 1) }, 1
  %t52 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d159, i32 0, i32 1) }, 0
  %t53 = add i64 %t50, %t52
  %t54 = extractvalue { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d160, i32 0, i32 1) }, 1
  %t55 = extractvalue { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d160, i32 0, i32 1) }, 0
  %t56 = add i64 %t53, %t55
  %t57 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d150, i32 0, i32 1) }, 1
  %t58 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d150, i32 0, i32 1) }, 0
  %t59 = add i64 %t56, %t58
  %t60 = load ptr, ptr @__olang_prog_scope
  %t61 = call ptr @__olang_scope_alloc(ptr %t60, i64 %t59)
  call void @olang_textcopy(ptr %t61, ptr %t1, i64 %t2)
  %t62 = getelementptr i8, ptr %t61, i64 %t2
  call void @olang_textcopy(ptr %t62, ptr %t3, i64 %t4)
  %t63 = getelementptr i8, ptr %t62, i64 %t4
  call void @olang_textcopy(ptr %t63, ptr %t6, i64 %t7)
  %t64 = getelementptr i8, ptr %t63, i64 %t7
  call void @olang_textcopy(ptr %t64, ptr %t9, i64 %t10)
  %t65 = getelementptr i8, ptr %t64, i64 %t10
  call void @olang_textcopy(ptr %t65, ptr %t12, i64 %t13)
  %t66 = getelementptr i8, ptr %t65, i64 %t13
  call void @olang_textcopy(ptr %t66, ptr %t15, i64 %t16)
  %t67 = getelementptr i8, ptr %t66, i64 %t16
  call void @olang_textcopy(ptr %t67, ptr %t18, i64 %t19)
  %t68 = getelementptr i8, ptr %t67, i64 %t19
  call void @olang_textcopy(ptr %t68, ptr %t21, i64 %t22)
  %t69 = getelementptr i8, ptr %t68, i64 %t22
  call void @olang_textcopy(ptr %t69, ptr %t24, i64 %t25)
  %t70 = getelementptr i8, ptr %t69, i64 %t25
  call void @olang_textcopy(ptr %t70, ptr %t27, i64 %t28)
  %t71 = getelementptr i8, ptr %t70, i64 %t28
  call void @olang_textcopy(ptr %t71, ptr %t30, i64 %t31)
  %t72 = getelementptr i8, ptr %t71, i64 %t31
  call void @olang_textcopy(ptr %t72, ptr %t33, i64 %t34)
  %t73 = getelementptr i8, ptr %t72, i64 %t34
  call void @olang_textcopy(ptr %t73, ptr %t36, i64 %t37)
  %t74 = getelementptr i8, ptr %t73, i64 %t37
  call void @olang_textcopy(ptr %t74, ptr %t39, i64 %t40)
  %t75 = getelementptr i8, ptr %t74, i64 %t40
  call void @olang_textcopy(ptr %t75, ptr %t42, i64 %t43)
  %t76 = getelementptr i8, ptr %t75, i64 %t43
  call void @olang_textcopy(ptr %t76, ptr %t45, i64 %t46)
  %t77 = getelementptr i8, ptr %t76, i64 %t46
  call void @olang_textcopy(ptr %t77, ptr %t48, i64 %t49)
  %t78 = getelementptr i8, ptr %t77, i64 %t49
  call void @olang_textcopy(ptr %t78, ptr %t51, i64 %t52)
  %t79 = getelementptr i8, ptr %t78, i64 %t52
  call void @olang_textcopy(ptr %t79, ptr %t54, i64 %t55)
  %t80 = getelementptr i8, ptr %t79, i64 %t55
  call void @olang_textcopy(ptr %t80, ptr %t57, i64 %t58)
  %t81 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t61, 1
  %t84 = load ptr, ptr @__olang_prog_scope
  %t85 = extractvalue { i64, ptr } %t82, 0
  %t86 = extractvalue { i64, ptr } %t82, 1
  %t87 = mul i64 %t85, 1
  %t88 = call ptr @__olang_scope_alloc(ptr %t84, i64 %t87)
  call void @llvm.memcpy.p0.p0.i64(ptr %t88, ptr %t86, i64 %t87, i1 false)
  %t89 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  store { i64, ptr } %t90, ptr @G_2ecompiler_2folang_2eexplainedSrc, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2folang_2eformat(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l9 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/olang:CommandLine", ptr %t1, i32 0, i32 8
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d161, i32 0, i32 1) }, ptr %l3, !tbaa !27
  br label %bb3
bb2:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d162, i32 0, i32 1) }, ptr %l3, !tbaa !27
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/olang:CommandLine", ptr %t6, i32 0, i32 1
  %t10 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hd4bdf3befe2f7a35847f168802c5df68(ptr %v0, ptr %v0, ptr %t8)
  store { i64, ptr } %t10, ptr %l6
  br label %bb4
bb4:
  %t11 = call { i64, ptr } @compiler_2fload_2eStdDir(ptr %s0)
  store { i64, ptr } %t11, ptr %l7
  br label %bb5
bb5:
  %t12 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 0
  %t14 = extractvalue { i64, ptr } %t12, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t19 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t20 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t22 = call i32 @compiler_2ffmt_2eFiles(ptr %s0, ptr %v0, ptr %s0, { i64, ptr } %t19, { i64, ptr } %t20, { i64, ptr } %t18)
  store i32 %t22, ptr %l9
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load i32, ptr %l9, !tbaa !23
  store i32 %t23, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2folang_2ehelp(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i1
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca %"std/prelude/text:StringBuilder"
  %l23 = alloca ptr
  %l24 = alloca { i64, ptr }
  %l29 = alloca [13 x { i64, ptr }]
  %l34 = alloca i64
  %l37 = alloca i64
  %l55 = alloca ptr
  %l58 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l69 = alloca i64
  %l70 = alloca { i64, ptr }
  %l73 = alloca i1
  %l74 = alloca i64
  %l78 = alloca i64
  %l81 = alloca ptr
  %l84 = alloca %"compiler/msgs:Msg"
  %l85 = alloca i32
  %l94 = alloca [12 x { i64, ptr }]
  %l99 = alloca i64
  %l102 = alloca i64
  %l122 = alloca i64
  %l130 = alloca { i64, ptr }
  %l133 = alloca i1
  %l135 = alloca { i64, ptr }
  %l139 = alloca ptr
  %l141 = alloca { i64, ptr }
  %l149 = alloca { i64, ptr }
  %l150 = alloca { i64, ptr }
  %l151 = alloca i64
  %l152 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l18
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l18
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/olang:CommandLine", ptr %t3, i32 0, i32 3
  %t6 = load i1, ptr %t5, !tbaa !21
  %t8 = xor i1 %t6, true
  br i1 %t8, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s1, ptr %l2, { i64, ptr } { i64 96, ptr getelementptr inbounds (<{ i64, [96 x i8] }>, ptr @.d163, i32 0, i32 1) })
  br label %bb4
bb3:
  br label %bb23
bb4:
  store ptr %l2, ptr %l23, !tbaa !29
  %t11 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadEnd(ptr %s1, ptr %s1, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d164, i32 0, i32 1) }, i64 11, i8 32)
  store { i64, ptr } %t11, ptr %l24
  br label %bb5
bb5:
  %t12 = load i64, ptr @G_2ecompiler_2folang_2eRun, !tbaa !24
  %t14 = getelementptr [13 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eModeWhat, i64 0, i64 %t12
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !37
  %t16 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d165, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d165, i32 0, i32 1) }, 0
  %t18 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t18, 1
  %t20 = extractvalue { i64, ptr } %t18, 0
  %t21 = add i64 %t17, %t20
  %t22 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d166, i32 0, i32 1) }, 1
  %t23 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d166, i32 0, i32 1) }, 0
  %t24 = add i64 %t21, %t23
  %t26 = extractvalue { i64, ptr } %t15, 1
  %t27 = extractvalue { i64, ptr } %t15, 0
  %t28 = add i64 %t24, %t27
  %t29 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d167, i32 0, i32 1) }, 1
  %t30 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d167, i32 0, i32 1) }, 0
  %t31 = add i64 %t28, %t30
  %t32 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t31)
  call void @olang_textcopy(ptr %t32, ptr %t16, i64 %t17)
  %t33 = getelementptr i8, ptr %t32, i64 %t17
  call void @olang_textcopy(ptr %t33, ptr %t19, i64 %t20)
  %t34 = getelementptr i8, ptr %t33, i64 %t20
  call void @olang_textcopy(ptr %t34, ptr %t22, i64 %t23)
  %t35 = getelementptr i8, ptr %t34, i64 %t23
  call void @olang_textcopy(ptr %t35, ptr %t26, i64 %t27)
  %t36 = getelementptr i8, ptr %t35, i64 %t27
  call void @olang_textcopy(ptr %t36, ptr %t29, i64 %t30)
  %t37 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t32, 1
  %t40 = extractvalue { i64, ptr } %t38, 0
  %t41 = extractvalue { i64, ptr } %t38, 1
  %t42 = mul i64 %t40, 1
  %t43 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t42)
  call void @llvm.memcpy.p0.p0.i64(ptr %t43, ptr %t41, i64 %t42, i1 false)
  %t44 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  %t46 = load ptr, ptr %l23, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s1, ptr %t46, { i64, ptr } %t45)
  br label %bb6
bb6:
  store i64 1, ptr %l3, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l29, ptr @G_2ecompiler_2folang_2eModeWords, i64 208, i1 false)
  %t48 = load [13 x { i64, ptr }], ptr %l29
  store i64 13, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t50 = load i64, ptr %l4, !tbaa !24
  %t51 = load i64, ptr %l3, !tbaa !24
  %t54 = icmp sgt i64 %t50, %t51
  br i1 %t54, label %bb7, label %bb8
bb7:
  %t56 = load i64, ptr %l5, !tbaa !24
  %t58 = icmp sgt i64 %t56, 0
  br i1 %t58, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb12
bb9:
  %t60 = load i64, ptr %l4, !tbaa !24
  %t61 = load i64, ptr %l3, !tbaa !24
  %t64 = sub i64 %t60, %t61
  %t65 = load i64, ptr %l5, !tbaa !24
  %t68 = add i64 %t64, %t65
  %t70 = sub i64 %t68, 1
  %t71 = load i64, ptr %l5, !tbaa !24
  %t74 = sdiv i64 %t70, %t71
  store i64 %t74, ptr %l37, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb11
bb11:
  %t76 = load i64, ptr %l37, !tbaa !24
  store i64 %t76, ptr %l34, !tbaa !24
  br label %bb12
bb12:
  %t77 = load i64, ptr %l34, !tbaa !24
  store i64 %t77, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s4
  %t78 = load i64, ptr %l7, !tbaa !24
  %t79 = load i64, ptr %l6, !tbaa !24
  %t82 = icmp slt i64 %t78, %t79
  %t84 = xor i1 %t82, true
  br i1 %t84, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s4)
  br label %bb20
bb15:
  br label %bb16
bb16:
  %t86 = load i64, ptr %l3, !tbaa !24
  %t87 = load i64, ptr %l7, !tbaa !24
  %t88 = load i64, ptr %l5, !tbaa !24
  %t91 = mul i64 %t87, %t88
  %t94 = add i64 %t86, %t91
  store i64 %t94, ptr %l8, !tbaa !24
  store ptr %l2, ptr %l55, !tbaa !29
  %t96 = load i64, ptr %l8, !tbaa !24
  %t98 = getelementptr [13 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eModeWords, i64 0, i64 %t96
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !37
  %t100 = load ptr, ptr @__olang_prog_scope
  %t102 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadEnd(ptr %t100, ptr %s4, { i64, ptr } %t99, i64 11, i8 32)
  store { i64, ptr } %t102, ptr %l58
  br label %bb17
bb17:
  %t103 = load i64, ptr %l8, !tbaa !24
  %t105 = getelementptr [13 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eModeWhat, i64 0, i64 %t103
  %t106 = load { i64, ptr }, ptr %t105, !tbaa !37
  %t107 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d168, i32 0, i32 1) }, 1
  %t108 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d168, i32 0, i32 1) }, 0
  %t109 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t109, 1
  %t111 = extractvalue { i64, ptr } %t109, 0
  %t112 = add i64 %t108, %t111
  %t113 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d169, i32 0, i32 1) }, 1
  %t114 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d169, i32 0, i32 1) }, 0
  %t115 = add i64 %t112, %t114
  %t117 = extractvalue { i64, ptr } %t106, 1
  %t118 = extractvalue { i64, ptr } %t106, 0
  %t119 = add i64 %t115, %t118
  %t120 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d170, i32 0, i32 1) }, 1
  %t121 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d170, i32 0, i32 1) }, 0
  %t122 = add i64 %t119, %t121
  %t123 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t122)
  call void @olang_textcopy(ptr %t123, ptr %t107, i64 %t108)
  %t124 = getelementptr i8, ptr %t123, i64 %t108
  call void @olang_textcopy(ptr %t124, ptr %t110, i64 %t111)
  %t125 = getelementptr i8, ptr %t124, i64 %t111
  call void @olang_textcopy(ptr %t125, ptr %t113, i64 %t114)
  %t126 = getelementptr i8, ptr %t125, i64 %t114
  call void @olang_textcopy(ptr %t126, ptr %t117, i64 %t118)
  %t127 = getelementptr i8, ptr %t126, i64 %t118
  call void @olang_textcopy(ptr %t127, ptr %t120, i64 %t121)
  %t128 = insertvalue { i64, ptr } undef, i64 %t122, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t123, 1
  %t131 = extractvalue { i64, ptr } %t129, 0
  %t132 = extractvalue { i64, ptr } %t129, 1
  %t133 = mul i64 %t131, 1
  %t134 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t133)
  call void @llvm.memcpy.p0.p0.i64(ptr %t134, ptr %t132, i64 %t133, i1 false)
  %t135 = insertvalue { i64, ptr } undef, i64 %t131, 0
  %t136 = insertvalue { i64, ptr } %t135, ptr %t134, 1
  %t137 = load ptr, ptr %l55, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %t137, { i64, ptr } %t136)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s4)
  br label %bb19
bb19:
  %t139 = load i64, ptr %l7, !tbaa !24
  %t141 = add i64 %t139, 1
  store i64 %t141, ptr %l7, !tbaa !24
  br label %bb13
bb20:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s1, ptr %l2, { i64, ptr } { i64 85, ptr getelementptr inbounds (<{ i64, [85 x i8] }>, ptr @.d171, i32 0, i32 1) })
  br label %bb21
bb21:
  %t145 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l2)
  store { i64, ptr } %t145, ptr %l67
  br label %bb22
bb22:
  %t146 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t146, ptr %l68, !tbaa !27
  %t147 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t148 = extractvalue { i64, ptr } %t147, 0
  store i64 %t148, ptr %l69, !tbaa !24
  %t149 = load i64, ptr %l69, !tbaa !24
  %t150 = mul i64 %t149, 1
  %t151 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t150)
  %t152 = insertvalue { i64, ptr } undef, i64 %t149, 0
  %t153 = insertvalue { i64, ptr } %t152, ptr %t151, 1
  store { i64, ptr } %t153, ptr %l70, !tbaa !27
  %t154 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !27
  %t156 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !27
  %t158 = load i64, ptr %l69, !tbaa !24
  %t159 = mul i64 %t158, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t155, ptr %t157, i64 %t159, i1 false)
  %t160 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t160, ptr %l68, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t161 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t162 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t161, 1
  store { i32, { i64, ptr } } %t162, ptr %rv
  br label %ret
bb23:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t165 = getelementptr %"compiler/olang:CommandLine", ptr %t163, i32 0, i32 2
  %t166 = load { i64, ptr }, ptr %t165, !tbaa !27
  %t168 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t166, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d172, i32 0, i32 1) })
  store i1 %t168, ptr %l73
  br label %bb24
bb24:
  %t169 = load i1, ptr %l73, !tbaa !21
  br i1 %t169, label %bb25, label %bb26
bb25:
  %t170 = load i64, ptr @G_2ecompiler_2folang_2eRun, !tbaa !24
  store i64 %t170, ptr %l74, !tbaa !24
  br label %bb28
bb26:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t174 = getelementptr %"compiler/olang:CommandLine", ptr %t172, i32 0, i32 2
  %t175 = load { i64, ptr }, ptr %t174, !tbaa !27
  %t177 = call i64 @compiler_2folang_2emodeNumber(ptr %v0, { i64, ptr } %t175)
  store i64 %t177, ptr %l78
  br label %bb27
bb27:
  %t178 = load i64, ptr %l78, !tbaa !24
  store i64 %t178, ptr %l74, !tbaa !24
  br label %bb28
bb28:
  %t179 = load i64, ptr %l74, !tbaa !24
  store i64 %t179, ptr %l9, !tbaa !24
  %t180 = load i64, ptr %l9, !tbaa !24
  %t182 = icmp slt i64 %t180, 0
  br i1 %t182, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s7
  store ptr %a1, ptr %l81, !tbaa !29
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/olang:CommandLine", ptr %t185, i32 0, i32 2
  %t188 = load { i64, ptr }, ptr %t187, !tbaa !27
  %t190 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotAMode(ptr %v0, ptr %s7, { i64, ptr } %t188)
  store %"compiler/msgs:Msg" %t190, ptr %l84
  br label %bb31
bb30:
  br label %bb35
bb31:
  %t191 = load ptr, ptr %l81, !tbaa !29
  %t192 = load %"compiler/msgs:Msg", ptr %l84
  %t193 = call i32 @compiler_2folang_2eusage(ptr %v1, ptr %s7, ptr %t191, %"compiler/msgs:Msg" %t192)
  store i32 %t193, ptr %l85
  %t194 = icmp ne i32 %t193, 0
  br i1 %t194, label %bb33, label %ok.195
ok.195:
  br label %bb32
bb32:
  br label %bb34
bb33:
  %t196 = load i32, ptr %l85, !tbaa !23
  %t197 = lshr i32 %t196, 16
  %t198 = and i32 %t196, 65535
  %t199 = icmp eq i32 %t197, 1
  %t200 = select i1 %t199, i32 1, i32 0
  %t201 = icmp eq i32 %t196, 0
  %t202 = shl i32 %t200, 16
  %t203 = or i32 %t202, %t198
  %t204 = select i1 %t201, i32 0, i32 %t203
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  %t206 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t204, 0
  store { i32, { i64, ptr } } %t206, ptr %rv
  br label %ret
bb34:
  call void @__olang_scope_close(ptr %s7)
  br label %bb35
bb35:
  %t207 = load i64, ptr %l9, !tbaa !24
  %t209 = getelementptr [13 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eModeUsage, i64 0, i64 %t207
  %t210 = load { i64, ptr }, ptr %t209, !tbaa !37
  %t211 = load i64, ptr %l9, !tbaa !24
  %t213 = getelementptr [13 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eModeWhat, i64 0, i64 %t211
  %t214 = load { i64, ptr }, ptr %t213, !tbaa !37
  %t215 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d173, i32 0, i32 1) }, 1
  %t216 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d173, i32 0, i32 1) }, 0
  %t218 = extractvalue { i64, ptr } %t210, 1
  %t219 = extractvalue { i64, ptr } %t210, 0
  %t220 = add i64 %t216, %t219
  %t221 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d174, i32 0, i32 1) }, 1
  %t222 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d174, i32 0, i32 1) }, 0
  %t223 = add i64 %t220, %t222
  %t225 = extractvalue { i64, ptr } %t214, 1
  %t226 = extractvalue { i64, ptr } %t214, 0
  %t227 = add i64 %t223, %t226
  %t228 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d174, i32 0, i32 1) }, 1
  %t229 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d174, i32 0, i32 1) }, 0
  %t230 = add i64 %t227, %t229
  %t231 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t230)
  call void @olang_textcopy(ptr %t231, ptr %t215, i64 %t216)
  %t232 = getelementptr i8, ptr %t231, i64 %t216
  call void @olang_textcopy(ptr %t232, ptr %t218, i64 %t219)
  %t233 = getelementptr i8, ptr %t232, i64 %t219
  call void @olang_textcopy(ptr %t233, ptr %t221, i64 %t222)
  %t234 = getelementptr i8, ptr %t233, i64 %t222
  call void @olang_textcopy(ptr %t234, ptr %t225, i64 %t226)
  %t235 = getelementptr i8, ptr %t234, i64 %t226
  call void @olang_textcopy(ptr %t235, ptr %t228, i64 %t229)
  %t236 = insertvalue { i64, ptr } undef, i64 %t230, 0
  %t237 = insertvalue { i64, ptr } %t236, ptr %t231, 1
  %t239 = extractvalue { i64, ptr } %t237, 0
  %t240 = extractvalue { i64, ptr } %t237, 1
  %t241 = mul i64 %t239, 1
  %t242 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t241)
  call void @llvm.memcpy.p0.p0.i64(ptr %t242, ptr %t240, i64 %t241, i1 false)
  %t243 = insertvalue { i64, ptr } undef, i64 %t239, 0
  %t244 = insertvalue { i64, ptr } %t243, ptr %t242, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } %t244)
  br label %bb36
bb36:
  store i1 false, ptr %l10, !tbaa !21
  store i64 0, ptr %l11, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l94, ptr @G_2ecompiler_2folang_2eOptWords, i64 192, i1 false)
  %t247 = load [12 x { i64, ptr }], ptr %l94
  store i64 12, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t249 = load i64, ptr %l12, !tbaa !24
  %t250 = load i64, ptr %l11, !tbaa !24
  %t253 = icmp sgt i64 %t249, %t250
  br i1 %t253, label %bb37, label %bb38
bb37:
  %t255 = load i64, ptr %l13, !tbaa !24
  %t257 = icmp sgt i64 %t255, 0
  br i1 %t257, label %bb39, label %bb40
bb38:
  store i64 0, ptr %l99, !tbaa !24
  br label %bb42
bb39:
  %t259 = load i64, ptr %l12, !tbaa !24
  %t260 = load i64, ptr %l11, !tbaa !24
  %t263 = sub i64 %t259, %t260
  %t264 = load i64, ptr %l13, !tbaa !24
  %t267 = add i64 %t263, %t264
  %t269 = sub i64 %t267, 1
  %t270 = load i64, ptr %l13, !tbaa !24
  %t273 = sdiv i64 %t269, %t270
  store i64 %t273, ptr %l102, !tbaa !24
  br label %bb41
bb40:
  store i64 0, ptr %l102, !tbaa !24
  br label %bb41
bb41:
  %t275 = load i64, ptr %l102, !tbaa !24
  store i64 %t275, ptr %l99, !tbaa !24
  br label %bb42
bb42:
  %t276 = load i64, ptr %l99, !tbaa !24
  store i64 %t276, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb43
bb43:
  store %olang.scope zeroinitializer, ptr %s10
  %t277 = load i64, ptr %l15, !tbaa !24
  %t278 = load i64, ptr %l14, !tbaa !24
  %t281 = icmp slt i64 %t277, %t278
  %t283 = xor i1 %t281, true
  br i1 %t283, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s10)
  br label %bb61
bb45:
  br label %bb46
bb46:
  %t285 = load i64, ptr %l11, !tbaa !24
  %t286 = load i64, ptr %l15, !tbaa !24
  %t287 = load i64, ptr %l13, !tbaa !24
  %t290 = mul i64 %t286, %t287
  %t293 = add i64 %t285, %t290
  store i64 %t293, ptr %l16, !tbaa !24
  %t295 = load i64, ptr %l16, !tbaa !24
  %t297 = getelementptr [12 x i64], ptr @G_2ecompiler_2folang_2eOptModes, i64 0, i64 %t295
  %t298 = load i64, ptr %t297, !tbaa !34
  %t299 = load i64, ptr %l9, !tbaa !24
  store i64 %t299, ptr %l122, !tbaa !24
  %t301 = load i64, ptr %l122, !tbaa !24
  %t302 = load i64, ptr %l122, !tbaa !24
  %t303 = ashr i64 %t298, %t302
  %t305 = and i64 %t303, 1
  %t307 = icmp eq i64 %t305, 0
  br i1 %t307, label %bb47, label %bb48
bb47:
  call void @__olang_scope_close(ptr %s10)
  br label %bb60
bb48:
  br label %bb49
bb49:
  %t309 = load i1, ptr %l10, !tbaa !21
  %t311 = xor i1 %t309, true
  br i1 %t311, label %bb50, label %bb51
bb50:
  store %olang.scope zeroinitializer, ptr %s12
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s12, ptr %l2, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d175, i32 0, i32 1) })
  br label %bb52
bb51:
  br label %bb53
bb52:
  call void @__olang_scope_close(ptr %s12)
  br label %bb53
bb53:
  store i1 true, ptr %l10, !tbaa !21
  %t314 = load i64, ptr %l16, !tbaa !24
  %t316 = getelementptr [12 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eOptWords, i64 0, i64 %t314
  %t317 = load { i64, ptr }, ptr %t316, !tbaa !37
  store { i64, ptr } %t317, ptr %l130, !tbaa !27
  %t318 = load i64, ptr %l16, !tbaa !24
  %t320 = getelementptr [12 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eOptValues, i64 0, i64 %t318
  %t321 = load { i64, ptr }, ptr %t320, !tbaa !37
  %t322 = load ptr, ptr @__olang_prog_scope
  %t324 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t322, ptr %s10, { i64, ptr } %t321, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d176, i32 0, i32 1) })
  store i1 %t324, ptr %l133
  br label %bb54
bb54:
  %t325 = load i1, ptr %l133, !tbaa !21
  %t326 = xor i1 %t325, true
  br i1 %t326, label %bb55, label %bb56
bb55:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d177, i32 0, i32 1) }, ptr %l135, !tbaa !27
  br label %bb57
bb56:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d178, i32 0, i32 1) }, ptr %l135, !tbaa !27
  br label %bb57
bb57:
  %t328 = load i64, ptr %l16, !tbaa !24
  %t330 = getelementptr [12 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eOptValues, i64 0, i64 %t328
  %t331 = load { i64, ptr }, ptr %t330, !tbaa !37
  %t332 = load { i64, ptr }, ptr %l130, !tbaa !27
  %t333 = extractvalue { i64, ptr } %t332, 1
  %t334 = extractvalue { i64, ptr } %t332, 0
  %t335 = load { i64, ptr }, ptr %l135, !tbaa !27
  %t336 = extractvalue { i64, ptr } %t335, 1
  %t337 = extractvalue { i64, ptr } %t335, 0
  %t338 = add i64 %t334, %t337
  %t340 = extractvalue { i64, ptr } %t331, 1
  %t341 = extractvalue { i64, ptr } %t331, 0
  %t342 = add i64 %t338, %t341
  %t343 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t342)
  call void @olang_textcopy(ptr %t343, ptr %t333, i64 %t334)
  %t344 = getelementptr i8, ptr %t343, i64 %t334
  call void @olang_textcopy(ptr %t344, ptr %t336, i64 %t337)
  %t345 = getelementptr i8, ptr %t344, i64 %t337
  call void @olang_textcopy(ptr %t345, ptr %t340, i64 %t341)
  %t346 = insertvalue { i64, ptr } undef, i64 %t342, 0
  %t347 = insertvalue { i64, ptr } %t346, ptr %t343, 1
  store ptr %l2, ptr %l139, !tbaa !29
  %t351 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadEnd(ptr %s10, ptr %s10, { i64, ptr } %t347, i64 18, i8 32)
  store { i64, ptr } %t351, ptr %l141
  br label %bb58
bb58:
  %t352 = load i64, ptr %l16, !tbaa !24
  %t354 = getelementptr [12 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eOptWhat, i64 0, i64 %t352
  %t355 = load { i64, ptr }, ptr %t354, !tbaa !37
  %t356 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d179, i32 0, i32 1) }, 1
  %t357 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d179, i32 0, i32 1) }, 0
  %t358 = load { i64, ptr }, ptr %l141, !tbaa !27
  %t359 = extractvalue { i64, ptr } %t358, 1
  %t360 = extractvalue { i64, ptr } %t358, 0
  %t361 = add i64 %t357, %t360
  %t362 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d180, i32 0, i32 1) }, 1
  %t363 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d180, i32 0, i32 1) }, 0
  %t364 = add i64 %t361, %t363
  %t366 = extractvalue { i64, ptr } %t355, 1
  %t367 = extractvalue { i64, ptr } %t355, 0
  %t368 = add i64 %t364, %t367
  %t369 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d181, i32 0, i32 1) }, 1
  %t370 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d181, i32 0, i32 1) }, 0
  %t371 = add i64 %t368, %t370
  %t372 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t371)
  call void @olang_textcopy(ptr %t372, ptr %t356, i64 %t357)
  %t373 = getelementptr i8, ptr %t372, i64 %t357
  call void @olang_textcopy(ptr %t373, ptr %t359, i64 %t360)
  %t374 = getelementptr i8, ptr %t373, i64 %t360
  call void @olang_textcopy(ptr %t374, ptr %t362, i64 %t363)
  %t375 = getelementptr i8, ptr %t374, i64 %t363
  call void @olang_textcopy(ptr %t375, ptr %t366, i64 %t367)
  %t376 = getelementptr i8, ptr %t375, i64 %t367
  call void @olang_textcopy(ptr %t376, ptr %t369, i64 %t370)
  %t377 = insertvalue { i64, ptr } undef, i64 %t371, 0
  %t378 = insertvalue { i64, ptr } %t377, ptr %t372, 1
  %t380 = extractvalue { i64, ptr } %t378, 0
  %t381 = extractvalue { i64, ptr } %t378, 1
  %t382 = mul i64 %t380, 1
  %t383 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t382)
  call void @llvm.memcpy.p0.p0.i64(ptr %t383, ptr %t381, i64 %t382, i1 false)
  %t384 = insertvalue { i64, ptr } undef, i64 %t380, 0
  %t385 = insertvalue { i64, ptr } %t384, ptr %t383, 1
  %t386 = load ptr, ptr %l139, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s10, ptr %t386, { i64, ptr } %t385)
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s10)
  br label %bb60
bb60:
  %t388 = load i64, ptr %l15, !tbaa !24
  %t390 = add i64 %t388, 1
  store i64 %t390, ptr %l15, !tbaa !24
  br label %bb43
bb61:
  %t393 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l2)
  store { i64, ptr } %t393, ptr %l149
  br label %bb62
bb62:
  %t394 = load { i64, ptr }, ptr %l149, !tbaa !27
  store { i64, ptr } %t394, ptr %l150, !tbaa !27
  %t395 = load { i64, ptr }, ptr %l150, !tbaa !27
  %t396 = extractvalue { i64, ptr } %t395, 0
  store i64 %t396, ptr %l151, !tbaa !24
  %t397 = load i64, ptr %l151, !tbaa !24
  %t398 = mul i64 %t397, 1
  %t399 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t398)
  %t400 = insertvalue { i64, ptr } undef, i64 %t397, 0
  %t401 = insertvalue { i64, ptr } %t400, ptr %t399, 1
  store { i64, ptr } %t401, ptr %l152, !tbaa !27
  %t402 = getelementptr { i64, ptr }, ptr %l152, i32 0, i32 1
  %t403 = load ptr, ptr %t402, !tbaa !27
  %t404 = getelementptr { i64, ptr }, ptr %l150, i32 0, i32 1
  %t405 = load ptr, ptr %t404, !tbaa !27
  %t406 = load i64, ptr %l151, !tbaa !24
  %t407 = mul i64 %t406, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t403, ptr %t405, i64 %t407, i1 false)
  %t408 = load { i64, ptr }, ptr %l152, !tbaa !27
  store { i64, ptr } %t408, ptr %l150, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t409 = load { i64, ptr }, ptr %l150, !tbaa !27
  %t410 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t409, 1
  store { i32, { i64, ptr } } %t410, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local void @compiler_2folang_2ekeep(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, { i64, ptr } %a2, ptr %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca %"compiler/emit:Reused"
  %l13 = alloca { i64, ptr }
  %l14 = alloca %"std/prelude/text:StringBuilder"
  %l15 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca i1
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l30 = alloca i64
  %l36 = alloca i32
  %l39 = alloca i32
  %l41 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l45 = alloca i32
  %l54 = alloca { i64, ptr }
  %l61 = alloca i1
  %l62 = alloca { i64, ptr }
  %l65 = alloca i1
  %l66 = alloca ptr
  %l70 = alloca ptr
  %l73 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l77 = alloca %"std/prelude/text:StringBuilder"
  %l78 = alloca ptr
  %l79 = alloca i64
  %l81 = alloca { i64, ptr }
  %l84 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l86 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l90 = alloca i32
  %l99 = alloca { i64, ptr }
  %l104 = alloca i1
  %l117 = alloca i64
  %l121 = alloca i64
  %l124 = alloca i64
  %l145 = alloca { i64, ptr }
  %l151 = alloca %"compiler/emit:Object"
  %l154 = alloca i1
  %l156 = alloca ptr
  %l159 = alloca i1
  %l160 = alloca { i64, ptr }
  %l165 = alloca { i64, ptr }
  %l168 = alloca { i64, ptr }
  %l176 = alloca { i64, ptr }
  %l178 = alloca { i64, ptr }
  %l180 = alloca i1
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s16 = alloca %olang.scope
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t3 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aReused_3e_2eLen_3ccompiler_2femit_3aReused_3e(ptr %v3, ptr %t1)
  store i64 %t3, ptr %l30
  br label %bb1
bb1:
  %t4 = load i64, ptr %l30, !tbaa !24
  %t5 = icmp eq i64 %t4, 0
  br i1 %t5, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t9 = getelementptr %"compiler/build:Config", ptr %t7, i32 0, i32 0
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 1
  %t13 = extractvalue { i64, ptr } %t10, 0
  %t14 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d182, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d182, i32 0, i32 1) }, 0
  %t16 = add i64 %t13, %t15
  %t17 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t16)
  call void @olang_textcopy(ptr %t17, ptr %t12, i64 %t13)
  %t18 = getelementptr i8, ptr %t17, i64 %t13
  call void @olang_textcopy(ptr %t18, ptr %t14, i64 %t15)
  %t19 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t17, 1
  %t22 = extractvalue { i64, ptr } %t20, 0
  %t23 = extractvalue { i64, ptr } %t20, 1
  %t24 = mul i64 %t22, 1
  %t25 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  %t29 = call i32 @std_2fos_2eMkDirAll(ptr %s0, { i64, ptr } %t27)
  store i32 %t29, ptr %l36
  %t30 = icmp ne i32 %t29, 0
  br i1 %t30, label %bb6, label %ok.31
ok.31:
  br label %bb5
bb5:
  br label %bb10
bb6:
  %t32 = load i32, ptr %l36, !tbaa !23
  %t33 = ashr i32 %t32, 16
  %t35 = icmp eq i32 %t33, 1
  br i1 %t35, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_4bbc6d12b4c2aef5_61de3414d98ea881)
  unreachable
bb9:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb10:
  %t37 = call i32 @compiler_2fbuild_2ePid()
  store i32 %t37, ptr %l39
  br label %bb11
bb11:
  %t38 = load i32, ptr %l39, !tbaa !23
  store i32 %t38, ptr %l6, !tbaa !23
  %t39 = load ptr, ptr %l3, !tbaa !29
  store ptr %t39, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s5
  %t41 = load ptr, ptr %l7, !tbaa !29
  %t42 = load i64, ptr %l8, !tbaa !24
  %t45 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aReused_3e_2eRunFrom_3ccompiler_2femit_3aReused_3e(ptr %v3, ptr %t41, i64 %t42)
  %t46 = extractvalue { i32, { i64, ptr } } %t45, 1
  %t47 = extractvalue { i32, { i64, ptr } } %t45, 0
  store i32 %t47, ptr %l45
  %t48 = icmp ne i32 %t47, 0
  br i1 %t48, label %bb14, label %ok.49
ok.49:
  store { i64, ptr } %t46, ptr %l44
  br label %bb13
bb13:
  %t50 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t50, ptr %l41, !tbaa !27
  br label %bb18
bb14:
  %t51 = load i32, ptr %l45, !tbaa !23
  %t52 = ashr i32 %t51, 16
  %t54 = icmp eq i32 %t52, 1
  br i1 %t54, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_1a6fb0e4b3da4304_63cb76792ee304f0)
  unreachable
bb17:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s5)
  br label %bb93
bb18:
  %t56 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t56, ptr %l9, !tbaa !27
  %t57 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t57, 0
  store i64 %t59, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb19
bb19:
  store %olang.scope zeroinitializer, ptr %s6
  %t61 = load i64, ptr %l11, !tbaa !24
  %t62 = load i64, ptr %l10, !tbaa !24
  %t65 = icmp slt i64 %t61, %t62
  %t67 = xor i1 %t65, true
  br i1 %t67, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s6)
  br label %bb91
bb21:
  br label %bb22
bb22:
  %t69 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t69, ptr %l54, !tbaa !27
  %t70 = load i64, ptr %l11, !tbaa !24
  %t72 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr %"compiler/emit:Reused", ptr %t73, i64 %t70
  %t75 = load %"compiler/emit:Reused", ptr %t74
  store %"compiler/emit:Reused" %t75, ptr %l12
  %t77 = getelementptr %"compiler/emit:Reused", ptr %l12, i32 0, i32 0
  %t78 = load i64, ptr %t77, !tbaa !24
  %t79 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t79, 0
  %t84 = icmp sge i64 %t78, %t81
  br i1 %t84, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l61, !tbaa !21
  br label %bb26
bb24:
  %t86 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t86, ptr %l62, !tbaa !27
  %t87 = getelementptr %"compiler/emit:Reused", ptr %l12, i32 0, i32 0
  %t88 = load i64, ptr %t87, !tbaa !24
  %t90 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr { i64, ptr }, ptr %t91, i64 %t88
  %t93 = load { i64, ptr }, ptr %t92, !tbaa !37
  %t95 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s6, { i64, ptr } %t93, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d183, i32 0, i32 1) })
  store i1 %t95, ptr %l65
  br label %bb25
bb25:
  %t96 = load i1, ptr %l65, !tbaa !21
  store i1 %t96, ptr %l61, !tbaa !21
  br label %bb26
bb26:
  %t97 = load i1, ptr %l61, !tbaa !21
  br i1 %t97, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s6)
  br label %bb90
bb28:
  br label %bb29
bb29:
  %t98 = load ptr, ptr %l1, !tbaa !29
  store ptr %t98, ptr %l66, !tbaa !29
  %t101 = getelementptr %"compiler/load:Loader", ptr %a0, i32 0, i32 5
  %t102 = getelementptr %"compiler/emit:Reused", ptr %l12, i32 0, i32 0
  %t103 = load i64, ptr %t102, !tbaa !24
  %t106 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t101, i64 %t103)
  store ptr %t106, ptr %l70
  br label %bb30
bb30:
  %t107 = load ptr, ptr %l70, !tbaa !29
  %t109 = getelementptr %"compiler/load:Module", ptr %t107, i32 0, i32 2
  %t110 = load { i64, ptr }, ptr %t109, !tbaa !27
  %t111 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t111, ptr %l73, !tbaa !27
  %t112 = getelementptr %"compiler/emit:Reused", ptr %l12, i32 0, i32 0
  %t113 = load i64, ptr %t112, !tbaa !24
  %t115 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = getelementptr { i64, ptr }, ptr %t116, i64 %t113
  %t118 = load { i64, ptr }, ptr %t117, !tbaa !37
  %t119 = load ptr, ptr %l66, !tbaa !29
  %t122 = call { i64, ptr } @compiler_2folang_2erecordPath(ptr %v1, ptr %v0, ptr %v2, ptr %s6, ptr %t119, { i64, ptr } %t110, { i64, ptr } %t118)
  store { i64, ptr } %t122, ptr %l76
  br label %bb31
bb31:
  %t123 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t123, ptr %l13, !tbaa !27
  %t124 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s6)
  store %"std/prelude/text:StringBuilder" %t124, ptr %l77
  br label %bb32
bb32:
  %t125 = load %"std/prelude/text:StringBuilder", ptr %l77
  store %"std/prelude/text:StringBuilder" %t125, ptr %l14
  store ptr %l14, ptr %l78, !tbaa !29
  %t126 = getelementptr %"compiler/emit:Reused", ptr %l12, i32 0, i32 4
  %t127 = load i64, ptr %t126, !tbaa !24
  store i64 %t127, ptr %l79, !tbaa !24
  %t128 = getelementptr %"compiler/emit:Reused", ptr %l12, i32 0, i32 5
  %t129 = load i1, ptr %t128, !tbaa !21
  br i1 %t129, label %bb33, label %bb34
bb33:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d184, i32 0, i32 1) }, ptr %l81, !tbaa !27
  br label %bb35
bb34:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d185, i32 0, i32 1) }, ptr %l81, !tbaa !27
  br label %bb35
bb35:
  %t131 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d186, i32 0, i32 1) }, 1
  %t132 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d186, i32 0, i32 1) }, 0
  %t133 = load i64, ptr %l79, !tbaa !24
  %t134 = call i64 @__olang_fmt_i64(ptr null, i64 %t133)
  %t135 = add i64 %t132, %t134
  %t136 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d187, i32 0, i32 1) }, 1
  %t137 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d187, i32 0, i32 1) }, 0
  %t138 = add i64 %t135, %t137
  %t139 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t139, 1
  %t141 = extractvalue { i64, ptr } %t139, 0
  %t142 = add i64 %t138, %t141
  %t143 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d188, i32 0, i32 1) }, 1
  %t144 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d188, i32 0, i32 1) }, 0
  %t145 = add i64 %t142, %t144
  %t146 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t145)
  call void @olang_textcopy(ptr %t146, ptr %t131, i64 %t132)
  %t147 = getelementptr i8, ptr %t146, i64 %t132
  %t148 = call i64 @__olang_fmt_i64(ptr %t147, i64 %t133)
  %t149 = getelementptr i8, ptr %t147, i64 %t134
  call void @olang_textcopy(ptr %t149, ptr %t136, i64 %t137)
  %t150 = getelementptr i8, ptr %t149, i64 %t137
  call void @olang_textcopy(ptr %t150, ptr %t140, i64 %t141)
  %t151 = getelementptr i8, ptr %t150, i64 %t141
  call void @olang_textcopy(ptr %t151, ptr %t143, i64 %t144)
  %t152 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t153 = insertvalue { i64, ptr } %t152, ptr %t146, 1
  %t155 = extractvalue { i64, ptr } %t153, 0
  %t156 = extractvalue { i64, ptr } %t153, 1
  %t157 = mul i64 %t155, 1
  %t158 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t157)
  call void @llvm.memcpy.p0.p0.i64(ptr %t158, ptr %t156, i64 %t157, i1 false)
  %t159 = insertvalue { i64, ptr } undef, i64 %t155, 0
  %t160 = insertvalue { i64, ptr } %t159, ptr %t158, 1
  %t161 = load ptr, ptr %l78, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s6, ptr %s6, ptr %t161, { i64, ptr } %t160)
  br label %bb36
bb36:
  %t163 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %s6)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t163, ptr %l84
  br label %bb37
bb37:
  %t164 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l84
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t164, ptr %l15
  %t165 = getelementptr %"compiler/emit:Reused", ptr %l12, i32 0, i32 6
  store ptr %t165, ptr %l16, !tbaa !29
  store i64 0, ptr %l17, !tbaa !24
  br label %bb38
bb38:
  store %olang.scope zeroinitializer, ptr %s10
  %t167 = load ptr, ptr %l16, !tbaa !29
  %t168 = load i64, ptr %l17, !tbaa !24
  %t171 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v3, ptr %t167, i64 %t168)
  %t172 = extractvalue { i32, { i64, ptr } } %t171, 1
  %t173 = extractvalue { i32, { i64, ptr } } %t171, 0
  store i32 %t173, ptr %l90
  %t174 = icmp ne i32 %t173, 0
  br i1 %t174, label %bb40, label %ok.175
ok.175:
  store { i64, ptr } %t172, ptr %l89
  br label %bb39
bb39:
  %t176 = load { i64, ptr }, ptr %l89, !tbaa !27
  store { i64, ptr } %t176, ptr %l86, !tbaa !27
  br label %bb44
bb40:
  %t177 = load i32, ptr %l90, !tbaa !23
  %t178 = ashr i32 %t177, 16
  %t180 = icmp eq i32 %t178, 1
  br i1 %t180, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  call void @__olang_check_failed(ptr @olang_loc_b2c46c5c2279b83f_c4a092c9ae7cf92b)
  unreachable
bb43:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s10)
  br label %bb58
bb44:
  %t182 = load { i64, ptr }, ptr %l86, !tbaa !27
  store { i64, ptr } %t182, ptr %l18, !tbaa !27
  %t183 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t185 = extractvalue { i64, ptr } %t183, 0
  store i64 %t185, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb45
bb45:
  store %olang.scope zeroinitializer, ptr %s11
  %t187 = load i64, ptr %l20, !tbaa !24
  %t188 = load i64, ptr %l19, !tbaa !24
  %t191 = icmp slt i64 %t187, %t188
  %t193 = xor i1 %t191, true
  br i1 %t193, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s11)
  br label %bb56
bb47:
  br label %bb48
bb48:
  %t195 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t195, ptr %l99, !tbaa !27
  %t196 = load i64, ptr %l20, !tbaa !24
  %t198 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t199 = load ptr, ptr %t198, !tbaa !27
  %t200 = getelementptr { i64, ptr }, ptr %t199, i64 %t196
  %t201 = load { i64, ptr }, ptr %t200, !tbaa !37
  store { i64, ptr } %t201, ptr %l21, !tbaa !27
  %t203 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t206 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %s6, ptr %v3, ptr %l15, { i64, ptr } %t203)
  store i1 %t206, ptr %l104
  br label %bb49
bb49:
  %t207 = load i1, ptr %l104, !tbaa !21
  br i1 %t207, label %bb50, label %bb51
bb50:
  call void @__olang_scope_close(ptr %s11)
  br label %bb55
bb51:
  br label %bb52
bb52:
  %t208 = load { i64, ptr }, ptr %l21, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H2b85ceff512af6e6ca26c554a1c16247(ptr %s6, ptr %v3, ptr %l15, { i64, ptr } %t208, i1 true)
  br label %bb53
bb53:
  %t211 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t212 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d189, i32 0, i32 1) }, 1
  %t213 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d189, i32 0, i32 1) }, 0
  %t215 = extractvalue { i64, ptr } %t211, 1
  %t216 = extractvalue { i64, ptr } %t211, 0
  %t217 = add i64 %t213, %t216
  %t218 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d190, i32 0, i32 1) }, 1
  %t219 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d190, i32 0, i32 1) }, 0
  %t220 = add i64 %t217, %t219
  %t221 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t220)
  call void @olang_textcopy(ptr %t221, ptr %t212, i64 %t213)
  %t222 = getelementptr i8, ptr %t221, i64 %t213
  call void @olang_textcopy(ptr %t222, ptr %t215, i64 %t216)
  %t223 = getelementptr i8, ptr %t222, i64 %t216
  call void @olang_textcopy(ptr %t223, ptr %t218, i64 %t219)
  %t224 = insertvalue { i64, ptr } undef, i64 %t220, 0
  %t225 = insertvalue { i64, ptr } %t224, ptr %t221, 1
  %t227 = extractvalue { i64, ptr } %t225, 0
  %t228 = extractvalue { i64, ptr } %t225, 1
  %t229 = mul i64 %t227, 1
  %t230 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t229)
  call void @llvm.memcpy.p0.p0.i64(ptr %t230, ptr %t228, i64 %t229, i1 false)
  %t231 = insertvalue { i64, ptr } undef, i64 %t227, 0
  %t232 = insertvalue { i64, ptr } %t231, ptr %t230, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s6, ptr %s11, ptr %l14, { i64, ptr } %t232)
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s11)
  br label %bb55
bb55:
  %t235 = load i64, ptr %l20, !tbaa !24
  %t237 = add i64 %t235, 1
  store i64 %t237, ptr %l20, !tbaa !24
  br label %bb45
bb56:
  %t239 = load i64, ptr %l17, !tbaa !24
  %t240 = load i64, ptr %l19, !tbaa !24
  %t243 = add i64 %t239, %t240
  store i64 %t243, ptr %l17, !tbaa !24
  call void @__olang_scope_close(ptr %s10)
  br label %bb57
bb57:
  br label %bb38
bb58:
  store i1 true, ptr %l22, !tbaa !21
  store i64 0, ptr %l23, !tbaa !24
  %t245 = getelementptr %"compiler/emit:Reused", ptr %l12, i32 0, i32 1
  %t247 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v3, ptr %t245)
  store i64 %t247, ptr %l117
  br label %bb59
bb59:
  %t248 = load i64, ptr %l117, !tbaa !24
  store i64 %t248, ptr %l24, !tbaa !24
  store i64 1, ptr %l25, !tbaa !24
  %t249 = load i64, ptr %l24, !tbaa !24
  %t250 = load i64, ptr %l23, !tbaa !24
  %t253 = icmp sgt i64 %t249, %t250
  br i1 %t253, label %bb60, label %bb61
bb60:
  %t255 = load i64, ptr %l25, !tbaa !24
  %t257 = icmp sgt i64 %t255, 0
  br i1 %t257, label %bb62, label %bb63
bb61:
  store i64 0, ptr %l121, !tbaa !24
  br label %bb65
bb62:
  %t259 = load i64, ptr %l24, !tbaa !24
  %t260 = load i64, ptr %l23, !tbaa !24
  %t263 = sub i64 %t259, %t260
  %t264 = load i64, ptr %l25, !tbaa !24
  %t267 = add i64 %t263, %t264
  %t269 = sub i64 %t267, 1
  %t270 = load i64, ptr %l25, !tbaa !24
  %t273 = sdiv i64 %t269, %t270
  store i64 %t273, ptr %l124, !tbaa !24
  br label %bb64
bb63:
  store i64 0, ptr %l124, !tbaa !24
  br label %bb64
bb64:
  %t275 = load i64, ptr %l124, !tbaa !24
  store i64 %t275, ptr %l121, !tbaa !24
  br label %bb65
bb65:
  %t276 = load i64, ptr %l121, !tbaa !24
  store i64 %t276, ptr %l26, !tbaa !24
  store i64 0, ptr %l27, !tbaa !24
  br label %bb66
bb66:
  store %olang.scope zeroinitializer, ptr %s16
  %t277 = load i64, ptr %l27, !tbaa !24
  %t278 = load i64, ptr %l26, !tbaa !24
  %t281 = icmp slt i64 %t277, %t278
  %t283 = xor i1 %t281, true
  br i1 %t283, label %bb67, label %bb68
bb67:
  call void @__olang_scope_close(ptr %s16)
  br label %bb83
bb68:
  br label %bb69
bb69:
  %t285 = load i64, ptr %l23, !tbaa !24
  %t286 = load i64, ptr %l27, !tbaa !24
  %t287 = load i64, ptr %l25, !tbaa !24
  %t290 = mul i64 %t286, %t287
  %t293 = add i64 %t285, %t290
  store i64 %t293, ptr %l28, !tbaa !24
  %t295 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t296 = load i64, ptr %l28, !tbaa !24
  %t298 = extractvalue { i64, ptr } %t295, 1
  %t299 = extractvalue { i64, ptr } %t295, 0
  %t300 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d191, i32 0, i32 1) }, 1
  %t301 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d191, i32 0, i32 1) }, 0
  %t302 = add i64 %t299, %t301
  %t304 = call i64 @__olang_fmt_i64(ptr null, i64 %t296)
  %t305 = add i64 %t302, %t304
  %t306 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d192, i32 0, i32 1) }, 1
  %t307 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d192, i32 0, i32 1) }, 0
  %t308 = add i64 %t305, %t307
  %t309 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t308)
  call void @olang_textcopy(ptr %t309, ptr %t298, i64 %t299)
  %t310 = getelementptr i8, ptr %t309, i64 %t299
  call void @olang_textcopy(ptr %t310, ptr %t300, i64 %t301)
  %t311 = getelementptr i8, ptr %t310, i64 %t301
  %t312 = call i64 @__olang_fmt_i64(ptr %t311, i64 %t296)
  %t313 = getelementptr i8, ptr %t311, i64 %t304
  call void @olang_textcopy(ptr %t313, ptr %t306, i64 %t307)
  %t314 = insertvalue { i64, ptr } undef, i64 %t308, 0
  %t315 = insertvalue { i64, ptr } %t314, ptr %t309, 1
  %t317 = extractvalue { i64, ptr } %t315, 0
  %t318 = extractvalue { i64, ptr } %t315, 1
  %t319 = mul i64 %t317, 1
  %t320 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t319)
  call void @llvm.memcpy.p0.p0.i64(ptr %t320, ptr %t318, i64 %t319, i1 false)
  %t321 = insertvalue { i64, ptr } undef, i64 %t317, 0
  %t322 = insertvalue { i64, ptr } %t321, ptr %t320, 1
  store { i64, ptr } %t322, ptr %l145, !tbaa !27
  %t325 = getelementptr %"compiler/emit:Reused", ptr %l12, i32 0, i32 7
  %t326 = load i64, ptr %t325, !tbaa !24
  %t327 = load i64, ptr %l28, !tbaa !24
  %t330 = add i64 %t326, %t327
  %t333 = call %"compiler/emit:Object" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aObject_3e_2eAt_3ccompiler_2femit_3aObject_3e(ptr %v4, ptr %v4, ptr %a4, i64 %t330)
  store %"compiler/emit:Object" %t333, ptr %l151
  br label %bb70
bb70:
  %t334 = getelementptr %"compiler/emit:Object", ptr %l151, i32 0, i32 2
  %t335 = load { i64, ptr }, ptr %t334, !tbaa !27
  %t336 = load i32, ptr %l6, !tbaa !23
  %t337 = load { i64, ptr }, ptr %l145, !tbaa !27
  %t340 = call i1 @compiler_2folang_2eputFile(ptr %s16, ptr %v4, { i64, ptr } %t337, { i64, ptr } %t335, i32 %t336)
  store i1 %t340, ptr %l154
  br label %bb71
bb71:
  %t341 = load i1, ptr %l154, !tbaa !21
  %t342 = xor i1 %t341, true
  br i1 %t342, label %bb72, label %bb73
bb72:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb74
bb73:
  br label %bb74
bb74:
  store ptr %l14, ptr %l156, !tbaa !29
  %t344 = getelementptr %"compiler/emit:Reused", ptr %l12, i32 0, i32 2
  %t345 = load i64, ptr %l28, !tbaa !24
  %t348 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v3, ptr %t344, i64 %t345)
  store i1 %t348, ptr %l159
  br label %bb75
bb75:
  %t349 = load i1, ptr %l159, !tbaa !21
  br i1 %t349, label %bb76, label %bb77
bb76:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d193, i32 0, i32 1) }, ptr %l160, !tbaa !27
  br label %bb78
bb77:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d194, i32 0, i32 1) }, ptr %l160, !tbaa !27
  br label %bb78
bb78:
  %t351 = getelementptr %"compiler/emit:Reused", ptr %l12, i32 0, i32 7
  %t352 = load i64, ptr %t351, !tbaa !24
  %t353 = load i64, ptr %l28, !tbaa !24
  %t356 = add i64 %t352, %t353
  %t359 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v5, ptr %s16, ptr %a5, i64 %t356)
  store { i64, ptr } %t359, ptr %l165
  br label %bb79
bb79:
  %t360 = getelementptr %"compiler/emit:Reused", ptr %l12, i32 0, i32 1
  %t361 = load i64, ptr %l28, !tbaa !24
  %t364 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v3, ptr %s16, ptr %t360, i64 %t361)
  store { i64, ptr } %t364, ptr %l168
  br label %bb80
bb80:
  %t365 = load { i64, ptr }, ptr %l160, !tbaa !27
  %t366 = extractvalue { i64, ptr } %t365, 1
  %t367 = extractvalue { i64, ptr } %t365, 0
  %t368 = load { i64, ptr }, ptr %l165, !tbaa !27
  %t369 = extractvalue { i64, ptr } %t368, 1
  %t370 = extractvalue { i64, ptr } %t368, 0
  %t371 = add i64 %t367, %t370
  %t372 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d195, i32 0, i32 1) }, 1
  %t373 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d195, i32 0, i32 1) }, 0
  %t374 = add i64 %t371, %t373
  %t375 = load { i64, ptr }, ptr %l168, !tbaa !27
  %t376 = extractvalue { i64, ptr } %t375, 1
  %t377 = extractvalue { i64, ptr } %t375, 0
  %t378 = add i64 %t374, %t377
  %t379 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d196, i32 0, i32 1) }, 1
  %t380 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d196, i32 0, i32 1) }, 0
  %t381 = add i64 %t378, %t380
  %t382 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t381)
  call void @olang_textcopy(ptr %t382, ptr %t366, i64 %t367)
  %t383 = getelementptr i8, ptr %t382, i64 %t367
  call void @olang_textcopy(ptr %t383, ptr %t369, i64 %t370)
  %t384 = getelementptr i8, ptr %t383, i64 %t370
  call void @olang_textcopy(ptr %t384, ptr %t372, i64 %t373)
  %t385 = getelementptr i8, ptr %t384, i64 %t373
  call void @olang_textcopy(ptr %t385, ptr %t376, i64 %t377)
  %t386 = getelementptr i8, ptr %t385, i64 %t377
  call void @olang_textcopy(ptr %t386, ptr %t379, i64 %t380)
  %t387 = insertvalue { i64, ptr } undef, i64 %t381, 0
  %t388 = insertvalue { i64, ptr } %t387, ptr %t382, 1
  %t390 = extractvalue { i64, ptr } %t388, 0
  %t391 = extractvalue { i64, ptr } %t388, 1
  %t392 = mul i64 %t390, 1
  %t393 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t392)
  call void @llvm.memcpy.p0.p0.i64(ptr %t393, ptr %t391, i64 %t392, i1 false)
  %t394 = insertvalue { i64, ptr } undef, i64 %t390, 0
  %t395 = insertvalue { i64, ptr } %t394, ptr %t393, 1
  %t396 = load ptr, ptr %l156, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s6, ptr %s16, ptr %t396, { i64, ptr } %t395)
  br label %bb81
bb81:
  call void @__olang_scope_close(ptr %s16)
  br label %bb82
bb82:
  %t398 = load i64, ptr %l27, !tbaa !24
  %t400 = add i64 %t398, 1
  store i64 %t400, ptr %l27, !tbaa !24
  br label %bb66
bb83:
  %t402 = load i1, ptr %l22, !tbaa !21
  %t404 = xor i1 %t402, true
  br i1 %t404, label %bb84, label %bb85
bb84:
  call void @__olang_scope_close(ptr %s6)
  br label %bb90
bb85:
  br label %bb86
bb86:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s6, ptr %s6, ptr %l14, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d197, i32 0, i32 1) })
  br label %bb87
bb87:
  %t407 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t407, ptr %l176, !tbaa !27
  %t409 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s6, ptr %s6, ptr %l14)
  store { i64, ptr } %t409, ptr %l178
  br label %bb88
bb88:
  %t410 = load i32, ptr %l6, !tbaa !23
  %t411 = load { i64, ptr }, ptr %l176, !tbaa !27
  %t412 = load { i64, ptr }, ptr %l178, !tbaa !27
  %t414 = call i1 @compiler_2folang_2eputFile(ptr %s6, ptr %s6, { i64, ptr } %t411, { i64, ptr } %t412, i32 %t410)
  store i1 %t414, ptr %l180
  br label %bb89
bb89:
  call void @__olang_scope_close(ptr %s6)
  br label %bb90
bb90:
  %t415 = load i64, ptr %l11, !tbaa !24
  %t417 = add i64 %t415, 1
  store i64 %t417, ptr %l11, !tbaa !24
  br label %bb19
bb91:
  %t419 = load i64, ptr %l8, !tbaa !24
  %t420 = load i64, ptr %l10, !tbaa !24
  %t423 = add i64 %t419, %t420
  store i64 %t423, ptr %l8, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb92
bb92:
  br label %bb12
bb93:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2folang_2elibraryIr(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d198, i32 0, i32 1) }, ptr %l3, !tbaa !27
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d199, i32 0, i32 1) }, ptr %l4, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t6 = call { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %a0, { i64, ptr } %t4, { i64, ptr } %t5)
  store { i64, ptr } %t6, ptr %l5
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t7, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2folang_2emain() #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l6 = alloca i32
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  call void @std_2fos_2eOnCrash(ptr %s0, { i64, ptr } { i64 97, ptr getelementptr inbounds (<{ i64, [97 x i8] }>, ptr @.d200, i32 0, i32 1) })
  br label %bb1
bb1:
  %t1 = call { i64, ptr } @std_2fos_2eArgs(ptr %s0)
  store { i64, ptr } %t1, ptr %l1
  br label %bb2
bb2:
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t2, ptr %l0, !tbaa !27
  %t3 = call i1 @compiler_2folang_2eroomFor(i64 1073741824)
  store i1 %t3, ptr %l2
  br label %bb3
bb3:
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb4, label %bb5
bb4:
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t6 = getelementptr { { i64, ptr }, ptr }, ptr null, i32 1
  %t7 = ptrtoint ptr %t6 to i64
  %t8 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 %t7, i64 8)
  %t9 = getelementptr { { i64, ptr }, ptr }, ptr %t8, i32 0, i32 0
  store { i64, ptr } %t5, ptr %t9, !tbaa !28
  call void @__olang_scope_escape(ptr %s0)
  %t11 = getelementptr { { i64, ptr }, ptr }, ptr %t8, i32 0, i32 1
  store ptr %s0, ptr %t11, !tbaa !28
  %t12 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_201, 0
  %t13 = insertvalue { ptr, ptr } %t12, ptr %t8, 1
  %t15 = extractvalue { ptr, ptr } %t13, 0
  %t16 = extractvalue { ptr, ptr } %t13, 1
  call void @std_2fos_2eRunOnStack(ptr %s0, i64 1073741824, ptr %t15, ptr %t16)
  br label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb7
bb7:
  %t17 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t19 = call i32 @compiler_2folang_2edrive(ptr %s0, { i64, ptr } %t17)
  store i32 %t19, ptr %l6
  br label %bb8
bb8:
  %t20 = load i32, ptr %l6, !tbaa !23
  call void @std_2fos_2eExit(i32 %t20)
  unreachable
bb9:
  call void @__olang_check_failed(ptr @olang_loc_73b8d8bbbab8f911_f56ba933d304b59d)
  unreachable
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2folang_2emodeName(ptr %v0, i64 %a0) #0 {
entry:
  %l0 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store i64 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !24
  %t2 = load i64, ptr @G_2ecompiler_2folang_2eRun, !tbaa !24
  %t5 = icmp eq i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d202, i32 0, i32 1) }, ptr %l5, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t7, ptr %l4, !tbaa !27
  br label %bb3
bb2:
  %t9 = load i64, ptr %l0, !tbaa !24
  %t11 = getelementptr [13 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eModeWords, i64 0, i64 %t9
  %t12 = load { i64, ptr }, ptr %t11, !tbaa !37
  %t14 = extractvalue { i64, ptr } %t12, 1
  %t15 = extractvalue { i64, ptr } %t12, 0
  %t16 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t14, i64 %t15)
  %t17 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l4, !tbaa !27
  br label %bb3
bb3:
  %t20 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t20, 0
  store i64 %t21, ptr %l10, !tbaa !24
  %t22 = load i64, ptr %l10, !tbaa !24
  %t23 = mul i64 %t22, 1
  %t24 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t23)
  %t25 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t24, 1
  store { i64, ptr } %t26, ptr %l11, !tbaa !27
  %t27 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = load i64, ptr %l10, !tbaa !24
  %t32 = mul i64 %t31, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t28, ptr %t30, i64 %t32, i1 false)
  %t33 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t33, ptr %l4, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t34, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2folang_2emodeNumber(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca [13 x { i64, ptr }]
  %l12 = alloca i64
  %l15 = alloca i64
  %l36 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store i64 1, ptr %l1, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l7, ptr @G_2ecompiler_2folang_2eModeWords, i64 208, i1 false)
  %t1 = load [13 x { i64, ptr }], ptr %l7
  store i64 13, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t3 = load i64, ptr %l2, !tbaa !24
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = icmp sgt i64 %t3, %t4
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp sgt i64 %t9, 0
  br i1 %t11, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l12, !tbaa !24
  br label %bb6
bb3:
  %t13 = load i64, ptr %l2, !tbaa !24
  %t14 = load i64, ptr %l1, !tbaa !24
  %t17 = sub i64 %t13, %t14
  %t18 = load i64, ptr %l3, !tbaa !24
  %t21 = add i64 %t17, %t18
  %t23 = sub i64 %t21, 1
  %t24 = load i64, ptr %l3, !tbaa !24
  %t27 = sdiv i64 %t23, %t24
  store i64 %t27, ptr %l15, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb5
bb5:
  %t29 = load i64, ptr %l15, !tbaa !24
  store i64 %t29, ptr %l12, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l12, !tbaa !24
  store i64 %t30, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t31 = load i64, ptr %l5, !tbaa !24
  %t32 = load i64, ptr %l4, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb9:
  br label %bb10
bb10:
  %t39 = load i64, ptr %l1, !tbaa !24
  %t40 = load i64, ptr %l5, !tbaa !24
  %t41 = load i64, ptr %l3, !tbaa !24
  %t44 = mul i64 %t40, %t41
  %t47 = add i64 %t39, %t44
  store i64 %t47, ptr %l6, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  %t51 = getelementptr [13 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eModeWords, i64 0, i64 %t49
  %t52 = load { i64, ptr }, ptr %t51, !tbaa !37
  %t54 = load ptr, ptr @__olang_prog_scope
  %t57 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t54, ptr %v0, { i64, ptr } %t52, { i64, ptr } %a0)
  store i1 %t57, ptr %l36
  br label %bb11
bb11:
  %t58 = load i1, ptr %l36, !tbaa !21
  br i1 %t58, label %bb12, label %bb13
bb12:
  %t59 = load i64, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  store i64 %t59, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb15:
  %t61 = load i64, ptr %l5, !tbaa !24
  %t63 = add i64 %t61, 1
  store i64 %t63, ptr %l5, !tbaa !24
  br label %bb7
bb16:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2folang_2emodesOf(ptr %v0, i64 %a0) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca %"std/prelude/text:StringBuilder"
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca [13 x { i64, ptr }]
  %l21 = alloca i64
  %l24 = alloca i64
  %l44 = alloca i64
  %l50 = alloca %"std/prelude/text:StringBuilder"
  %l51 = alloca [13 x { i64, ptr }]
  %l56 = alloca i64
  %l59 = alloca i64
  %l78 = alloca i64
  %l86 = alloca ptr
  %l90 = alloca { i64, ptr }
  %l91 = alloca ptr
  %l93 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %l100 = alloca i64
  %l101 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store i64 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 0, ptr %l1, !tbaa !24
  store i64 0, ptr %l2, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l16, ptr @G_2ecompiler_2folang_2eModeWords, i64 208, i1 false)
  %t1 = load [13 x { i64, ptr }], ptr %l16
  store i64 13, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t3 = load i64, ptr %l3, !tbaa !24
  %t4 = load i64, ptr %l2, !tbaa !24
  %t7 = icmp sgt i64 %t3, %t4
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp sgt i64 %t9, 0
  br i1 %t11, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb6
bb3:
  %t13 = load i64, ptr %l3, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t17 = sub i64 %t13, %t14
  %t18 = load i64, ptr %l4, !tbaa !24
  %t21 = add i64 %t17, %t18
  %t23 = sub i64 %t21, 1
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = sdiv i64 %t23, %t24
  store i64 %t27, ptr %l24, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb5
bb5:
  %t29 = load i64, ptr %l24, !tbaa !24
  store i64 %t29, ptr %l21, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l21, !tbaa !24
  store i64 %t30, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t31 = load i64, ptr %l6, !tbaa !24
  %t32 = load i64, ptr %l5, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb9:
  br label %bb10
bb10:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load i64, ptr %l6, !tbaa !24
  %t41 = load i64, ptr %l4, !tbaa !24
  %t44 = mul i64 %t40, %t41
  %t47 = add i64 %t39, %t44
  %t49 = load i64, ptr %l1, !tbaa !24
  %t50 = load i64, ptr %l0, !tbaa !24
  store i64 %t47, ptr %l44, !tbaa !24
  %t53 = load i64, ptr %l44, !tbaa !24
  %t54 = load i64, ptr %l44, !tbaa !24
  %t55 = ashr i64 %t50, %t54
  %t57 = and i64 %t55, 1
  %t60 = add i64 %t49, %t57
  store i64 %t60, ptr %l1, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb11:
  %t62 = load i64, ptr %l6, !tbaa !24
  %t64 = add i64 %t62, 1
  store i64 %t64, ptr %l6, !tbaa !24
  br label %bb7
bb12:
  %t66 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t66, ptr %l50
  br label %bb13
bb13:
  %t67 = load %"std/prelude/text:StringBuilder", ptr %l50
  store %"std/prelude/text:StringBuilder" %t67, ptr %l8
  store i64 0, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l51, ptr @G_2ecompiler_2folang_2eModeWords, i64 208, i1 false)
  %t68 = load [13 x { i64, ptr }], ptr %l51
  store i64 13, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t70 = load i64, ptr %l11, !tbaa !24
  %t71 = load i64, ptr %l10, !tbaa !24
  %t74 = icmp sgt i64 %t70, %t71
  br i1 %t74, label %bb14, label %bb15
bb14:
  %t76 = load i64, ptr %l12, !tbaa !24
  %t78 = icmp sgt i64 %t76, 0
  br i1 %t78, label %bb16, label %bb17
bb15:
  store i64 0, ptr %l56, !tbaa !24
  br label %bb19
bb16:
  %t80 = load i64, ptr %l11, !tbaa !24
  %t81 = load i64, ptr %l10, !tbaa !24
  %t84 = sub i64 %t80, %t81
  %t85 = load i64, ptr %l12, !tbaa !24
  %t88 = add i64 %t84, %t85
  %t90 = sub i64 %t88, 1
  %t91 = load i64, ptr %l12, !tbaa !24
  %t94 = sdiv i64 %t90, %t91
  store i64 %t94, ptr %l59, !tbaa !24
  br label %bb18
bb17:
  store i64 0, ptr %l59, !tbaa !24
  br label %bb18
bb18:
  %t96 = load i64, ptr %l59, !tbaa !24
  store i64 %t96, ptr %l56, !tbaa !24
  br label %bb19
bb19:
  %t97 = load i64, ptr %l56, !tbaa !24
  store i64 %t97, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s5
  %t98 = load i64, ptr %l14, !tbaa !24
  %t99 = load i64, ptr %l13, !tbaa !24
  %t102 = icmp slt i64 %t98, %t99
  %t104 = xor i1 %t102, true
  br i1 %t104, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s5)
  br label %bb37
bb22:
  br label %bb23
bb23:
  %t106 = load i64, ptr %l10, !tbaa !24
  %t107 = load i64, ptr %l14, !tbaa !24
  %t108 = load i64, ptr %l12, !tbaa !24
  %t111 = mul i64 %t107, %t108
  %t114 = add i64 %t106, %t111
  store i64 %t114, ptr %l15, !tbaa !24
  %t116 = load i64, ptr %l0, !tbaa !24
  %t117 = load i64, ptr %l15, !tbaa !24
  store i64 %t117, ptr %l78, !tbaa !24
  %t119 = load i64, ptr %l78, !tbaa !24
  %t120 = load i64, ptr %l78, !tbaa !24
  %t121 = ashr i64 %t116, %t120
  %t123 = and i64 %t121, 1
  %t125 = icmp eq i64 %t123, 0
  br i1 %t125, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s5)
  br label %bb36
bb25:
  br label %bb26
bb26:
  %t127 = load i64, ptr %l9, !tbaa !24
  %t129 = add i64 %t127, 1
  store i64 %t129, ptr %l9, !tbaa !24
  %t131 = load i64, ptr %l9, !tbaa !24
  %t133 = icmp sgt i64 %t131, 1
  br i1 %t133, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s7
  store ptr %l8, ptr %l86, !tbaa !29
  %t135 = load i64, ptr %l9, !tbaa !24
  %t136 = load i64, ptr %l1, !tbaa !24
  %t139 = icmp eq i64 %t135, %t136
  br i1 %t139, label %bb29, label %bb30
bb28:
  br label %bb33
bb29:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d203, i32 0, i32 1) }, ptr %l90, !tbaa !27
  br label %bb31
bb30:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d204, i32 0, i32 1) }, ptr %l90, !tbaa !27
  br label %bb31
bb31:
  %t141 = load ptr, ptr %l86, !tbaa !29
  %t142 = load { i64, ptr }, ptr %l90, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %t141, { i64, ptr } %t142)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s7)
  br label %bb33
bb33:
  store ptr %l8, ptr %l91, !tbaa !29
  %t143 = load i64, ptr %l15, !tbaa !24
  %t145 = call { i64, ptr } @compiler_2folang_2emodeName(ptr %s5, i64 %t143)
  store { i64, ptr } %t145, ptr %l93
  br label %bb34
bb34:
  %t146 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t147 = extractvalue { i64, ptr } %t146, 0
  %t148 = extractvalue { i64, ptr } %t146, 1
  %t149 = mul i64 %t147, 1
  %t150 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t149)
  call void @llvm.memcpy.p0.p0.i64(ptr %t150, ptr %t148, i64 %t149, i1 false)
  %t151 = insertvalue { i64, ptr } undef, i64 %t147, 0
  %t152 = insertvalue { i64, ptr } %t151, ptr %t150, 1
  %t153 = load ptr, ptr %l91, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %t153, { i64, ptr } %t152)
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s5)
  br label %bb36
bb36:
  %t155 = load i64, ptr %l14, !tbaa !24
  %t157 = add i64 %t155, 1
  store i64 %t157, ptr %l14, !tbaa !24
  br label %bb20
bb37:
  %t160 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v0, ptr %l8)
  store { i64, ptr } %t160, ptr %l98
  br label %bb38
bb38:
  %t161 = load { i64, ptr }, ptr %l98, !tbaa !27
  store { i64, ptr } %t161, ptr %l99, !tbaa !27
  %t162 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t163 = extractvalue { i64, ptr } %t162, 0
  store i64 %t163, ptr %l100, !tbaa !24
  %t164 = load i64, ptr %l100, !tbaa !24
  %t165 = mul i64 %t164, 1
  %t166 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t165)
  %t167 = insertvalue { i64, ptr } undef, i64 %t164, 0
  %t168 = insertvalue { i64, ptr } %t167, ptr %t166, 1
  store { i64, ptr } %t168, ptr %l101, !tbaa !27
  %t169 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !27
  %t171 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t172 = load ptr, ptr %t171, !tbaa !27
  %t173 = load i64, ptr %l100, !tbaa !24
  %t174 = mul i64 %t173, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t170, ptr %t172, i64 %t174, i1 false)
  %t175 = load { i64, ptr }, ptr %l101, !tbaa !27
  store { i64, ptr } %t175, ptr %l99, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t176 = load { i64, ptr }, ptr %l99, !tbaa !27
  store { i64, ptr } %t176, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2folang_2emoduleKeys(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %l30 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l31 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca ptr
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca %"compiler/load:Import"
  %l45 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l46 = alloca ptr
  %l47 = alloca i64
  %l48 = alloca { i64, ptr }
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i64
  %l62 = alloca { i64, ptr }
  %l64 = alloca i1
  %l66 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l73 = alloca ptr
  %l75 = alloca { i64, ptr }
  %l79 = alloca ptr
  %l85 = alloca i64
  %l93 = alloca i64
  %l96 = alloca i64
  %l116 = alloca ptr
  %l117 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l127 = alloca ptr
  %l132 = alloca { i64, ptr }
  %l141 = alloca { i64, ptr }
  %l146 = alloca { i64, ptr }
  %l149 = alloca { i64, ptr }
  %l150 = alloca i32
  %l159 = alloca { i64, ptr }
  %l162 = alloca ptr
  %l163 = alloca { i64, ptr }
  %l166 = alloca { i64, ptr }
  %l168 = alloca { i64, ptr }
  %l176 = alloca i64
  %l178 = alloca { i64, ptr }
  %l186 = alloca i64
  %l189 = alloca i64
  %l211 = alloca i64
  %l214 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l215 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l222 = alloca i64
  %l225 = alloca i64
  %l245 = alloca ptr
  %l253 = alloca i64
  %l256 = alloca i64
  %l258 = alloca i64
  %l259 = alloca i32
  %l267 = alloca ptr
  %l270 = alloca { i64, ptr }
  %l273 = alloca { i64, ptr }
  %l274 = alloca i32
  %l283 = alloca { i64, ptr }
  %l288 = alloca i1
  %l301 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l308 = alloca { i64, ptr }
  %l311 = alloca { i64, ptr }
  %l312 = alloca i32
  %l321 = alloca { i64, ptr }
  %l324 = alloca ptr
  %l327 = alloca ptr
  %l339 = alloca { i64, ptr }
  %l340 = alloca i64
  %l342 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t19 = alloca i64
  %t119 = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/load:Loader", ptr %t1, i32 0, i32 5
  %t4 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t3
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %l3
  %t7 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v0, ptr %l3)
  store i64 %t7, ptr %l55
  br label %bb1
bb1:
  %t8 = load i64, ptr %l55, !tbaa !24
  store i64 %t8, ptr %l4, !tbaa !24
  %t9 = load i64, ptr %l4, !tbaa !24
  store i64 %t9, ptr %l56, !tbaa !24
  %t10 = load i64, ptr %l56, !tbaa !24
  %t11 = icmp sge i64 %t10, 0
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l56, !tbaa !24
  %t14 = icmp sle i64 %t13, 576460752303423487
  br i1 %t14, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @olang_loc_73c3116820f750d_32f9964414b76079)
  unreachable
bb4:
  %t16 = load i64, ptr %l56, !tbaa !24
  %t17 = mul i64 %t16, 16
  %t18 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t17)
  store i64 0, ptr %t19
  br label %fill.20
fill.20:
  %t23 = load i64, ptr %t19
  %t24 = icmp slt i64 %t23, %t16
  br i1 %t24, label %fillb.21, label %filld.22
fillb.21:
  %t25 = getelementptr { i64, ptr }, ptr %t18, i64 %t23
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d205, i32 0, i32 1) }, ptr %t25
  %t26 = add i64 %t23, 1
  store i64 %t26, ptr %t19
  br label %fill.20
filld.22:
  %t27 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t18, 1
  store { i64, ptr } %t28, ptr %l5, !tbaa !27
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t34 = call { i64, ptr } @compiler_2folang_2ebuildInputs(ptr %v1, ptr %s0, ptr %t30, i1 %a2)
  store { i64, ptr } %t34, ptr %l62
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_73c3116820f750d_32f9964414b76079)
  unreachable
bb6:
  %t35 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t35, ptr %l6, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t38 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t36, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d206, i32 0, i32 1) })
  store i1 %t38, ptr %l64
  br label %bb7
bb7:
  %t39 = load i1, ptr %l64, !tbaa !21
  br i1 %t39, label %bb8, label %bb9
bb8:
  %t40 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t40, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t42 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t42, ptr %l66, !tbaa !27
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = getelementptr %"compiler/build:Config", ptr %t43, i32 0, i32 4
  %t46 = load i1, ptr %t45, !tbaa !21
  br i1 %t46, label %bb11, label %bb12
bb11:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/load:Loader", ptr %t48, i32 0, i32 7
  %t51 = load i64, ptr %t50, !tbaa !24
  %t54 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %l3, i64 %t51)
  store ptr %t54, ptr %l73
  br label %bb13
bb12:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d207, i32 0, i32 1) }, ptr %l69, !tbaa !27
  br label %bb15
bb13:
  %t55 = load ptr, ptr %l73, !tbaa !29
  %t57 = getelementptr %"compiler/load:Module", ptr %t55, i32 0, i32 2
  %t58 = load { i64, ptr }, ptr %t57, !tbaa !27
  store { i64, ptr } %t58, ptr %l75, !tbaa !27
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/load:Loader", ptr %t59, i32 0, i32 7
  %t62 = load i64, ptr %t61, !tbaa !24
  %t65 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %l3, i64 %t62)
  store ptr %t65, ptr %l79
  br label %bb14
bb14:
  %t66 = load ptr, ptr %l79, !tbaa !29
  %t68 = getelementptr %"compiler/load:Module", ptr %t66, i32 0, i32 0
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  %t70 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d208, i32 0, i32 1) }, 1
  %t71 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d208, i32 0, i32 1) }, 0
  %t72 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t72, 1
  %t74 = extractvalue { i64, ptr } %t72, 0
  %t75 = add i64 %t71, %t74
  %t76 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d209, i32 0, i32 1) }, 1
  %t77 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d209, i32 0, i32 1) }, 0
  %t78 = add i64 %t75, %t77
  %t80 = extractvalue { i64, ptr } %t69, 1
  %t81 = extractvalue { i64, ptr } %t69, 0
  %t82 = add i64 %t78, %t81
  %t83 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t82)
  call void @olang_textcopy(ptr %t83, ptr %t70, i64 %t71)
  %t84 = getelementptr i8, ptr %t83, i64 %t71
  call void @olang_textcopy(ptr %t84, ptr %t73, i64 %t74)
  %t85 = getelementptr i8, ptr %t84, i64 %t74
  call void @olang_textcopy(ptr %t85, ptr %t76, i64 %t77)
  %t86 = getelementptr i8, ptr %t85, i64 %t77
  call void @olang_textcopy(ptr %t86, ptr %t80, i64 %t81)
  %t87 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t88 = insertvalue { i64, ptr } %t87, ptr %t83, 1
  %t90 = extractvalue { i64, ptr } %t88, 0
  %t91 = extractvalue { i64, ptr } %t88, 1
  %t92 = mul i64 %t90, 1
  %t93 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t92)
  call void @llvm.memcpy.p0.p0.i64(ptr %t93, ptr %t91, i64 %t92, i1 false)
  %t94 = insertvalue { i64, ptr } undef, i64 %t90, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t93, 1
  store { i64, ptr } %t95, ptr %l69, !tbaa !27
  br label %bb15
bb15:
  %t97 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t97, 1
  %t99 = extractvalue { i64, ptr } %t97, 0
  %t100 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 1
  %t102 = extractvalue { i64, ptr } %t100, 0
  %t103 = add i64 %t99, %t102
  %t104 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t103)
  call void @olang_textcopy(ptr %t104, ptr %t98, i64 %t99)
  %t105 = getelementptr i8, ptr %t104, i64 %t99
  call void @olang_textcopy(ptr %t105, ptr %t101, i64 %t102)
  %t106 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t104, 1
  store { i64, ptr } %t107, ptr %l7, !tbaa !27
  %t109 = load i64, ptr %l4, !tbaa !24
  store i64 %t109, ptr %l85, !tbaa !24
  %t110 = load i64, ptr %l85, !tbaa !24
  %t111 = icmp sge i64 %t110, 0
  br i1 %t111, label %bb16, label %bb17
bb16:
  %t113 = load i64, ptr %l85, !tbaa !24
  %t114 = icmp sle i64 %t113, 576460752303423487
  br i1 %t114, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_23d2168bab4aeae0_126950dc9613ccec)
  unreachable
bb18:
  %t116 = load i64, ptr %l85, !tbaa !24
  %t117 = mul i64 %t116, 16
  %t118 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t117)
  store i64 0, ptr %t119
  br label %fill.120
fill.120:
  %t123 = load i64, ptr %t119
  %t124 = icmp slt i64 %t123, %t116
  br i1 %t124, label %fillb.121, label %filld.122
fillb.121:
  %t125 = getelementptr { i64, ptr }, ptr %t118, i64 %t123
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d210, i32 0, i32 1) }, ptr %t125
  %t126 = add i64 %t123, 1
  store i64 %t126, ptr %t119
  br label %fill.120
filld.122:
  %t127 = insertvalue { i64, ptr } undef, i64 %t116, 0
  %t128 = insertvalue { i64, ptr } %t127, ptr %t118, 1
  store { i64, ptr } %t128, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t130 = load i64, ptr %l4, !tbaa !24
  store i64 %t130, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t132 = load i64, ptr %l10, !tbaa !24
  %t133 = load i64, ptr %l9, !tbaa !24
  %t136 = icmp sgt i64 %t132, %t133
  br i1 %t136, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_23d2168bab4aeae0_126950dc9613ccec)
  unreachable
bb20:
  %t138 = load i64, ptr %l11, !tbaa !24
  %t140 = icmp sgt i64 %t138, 0
  br i1 %t140, label %bb22, label %bb23
bb21:
  store i64 0, ptr %l93, !tbaa !24
  br label %bb25
bb22:
  %t142 = load i64, ptr %l10, !tbaa !24
  %t143 = load i64, ptr %l9, !tbaa !24
  %t146 = sub i64 %t142, %t143
  %t147 = load i64, ptr %l11, !tbaa !24
  %t150 = add i64 %t146, %t147
  %t152 = sub i64 %t150, 1
  %t153 = load i64, ptr %l11, !tbaa !24
  %t156 = sdiv i64 %t152, %t153
  store i64 %t156, ptr %l96, !tbaa !24
  br label %bb24
bb23:
  store i64 0, ptr %l96, !tbaa !24
  br label %bb24
bb24:
  %t158 = load i64, ptr %l96, !tbaa !24
  store i64 %t158, ptr %l93, !tbaa !24
  br label %bb25
bb25:
  %t159 = load i64, ptr %l93, !tbaa !24
  store i64 %t159, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb26
bb26:
  store %olang.scope zeroinitializer, ptr %s5
  %t160 = load i64, ptr %l13, !tbaa !24
  %t161 = load i64, ptr %l12, !tbaa !24
  %t164 = icmp slt i64 %t160, %t161
  %t166 = xor i1 %t164, true
  br i1 %t166, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s5)
  br label %bb62
bb28:
  br label %bb29
bb29:
  %t168 = load i64, ptr %l9, !tbaa !24
  %t169 = load i64, ptr %l13, !tbaa !24
  %t170 = load i64, ptr %l11, !tbaa !24
  %t173 = mul i64 %t169, %t170
  %t176 = add i64 %t168, %t173
  store i64 %t176, ptr %l14, !tbaa !24
  %t178 = load i64, ptr %l14, !tbaa !24
  %t181 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %l3, i64 %t178)
  store ptr %t181, ptr %l116
  br label %bb30
bb30:
  %t182 = load ptr, ptr %l116, !tbaa !29
  store ptr %t182, ptr %l15, !tbaa !29
  %t183 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %s5)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t183, ptr %l117
  br label %bb31
bb31:
  %t184 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l117
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t184, ptr %l16
  %t185 = load ptr, ptr %l15, !tbaa !29
  %t187 = getelementptr %"compiler/load:Module", ptr %t185, i32 0, i32 2
  %t188 = load { i64, ptr }, ptr %t187, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s5, ptr %v0, ptr %l16, { i64, ptr } %t188)
  br label %bb32
bb32:
  %t191 = load ptr, ptr %l15, !tbaa !29
  %t193 = getelementptr %"compiler/load:Module", ptr %t191, i32 0, i32 0
  %t194 = load { i64, ptr }, ptr %t193, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s5, ptr %v0, ptr %l16, { i64, ptr } %t194)
  br label %bb33
bb33:
  %t197 = load ptr, ptr %l15, !tbaa !29
  %t199 = getelementptr %"compiler/load:Module", ptr %t197, i32 0, i32 1
  %t200 = load { i64, ptr }, ptr %t199, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s5, ptr %v0, ptr %l16, { i64, ptr } %t200)
  br label %bb34
bb34:
  store ptr %l16, ptr %l127, !tbaa !29
  %t203 = load ptr, ptr %l15, !tbaa !29
  %t205 = getelementptr %"compiler/load:Module", ptr %t203, i32 0, i32 6
  %t206 = load ptr, ptr %t205, !tbaa !29
  %t208 = icmp eq ptr %t206, null
  %t210 = xor i1 %t208, true
  br i1 %t210, label %bb35, label %bb36
bb35:
  %t212 = load ptr, ptr %l15, !tbaa !29
  %t214 = getelementptr %"compiler/load:Module", ptr %t212, i32 0, i32 6
  %t215 = load ptr, ptr %t214, !tbaa !29
  %t217 = icmp eq ptr %t215, null
  br i1 %t217, label %bb37, label %bb38
bb36:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d211, i32 0, i32 1) }, ptr %l141, !tbaa !27
  %t219 = load { i64, ptr }, ptr %l141, !tbaa !27
  store { i64, ptr } %t219, ptr %l132, !tbaa !27
  br label %bb40
bb37:
  call void @__olang_check_failed(ptr @olang_loc_a3d985a905b98e7d_1a99d62f9ee112a1)
  unreachable
bb38:
  br label %bb39
bb39:
  %t221 = load ptr, ptr %l15, !tbaa !29
  %t223 = getelementptr %"compiler/load:Module", ptr %t221, i32 0, i32 6
  %t224 = load ptr, ptr %t223, !tbaa !29
  %t227 = getelementptr %"compiler/source:Source", ptr %t224, i32 0, i32 1
  %t228 = load { i64, ptr }, ptr %t227, !tbaa !27
  store { i64, ptr } %t228, ptr %l132, !tbaa !27
  br label %bb40
bb40:
  %t231 = load { i64, ptr }, ptr %l132, !tbaa !27
  %t232 = extractvalue { i64, ptr } %t231, 0
  %t233 = extractvalue { i64, ptr } %t231, 1
  %t234 = mul i64 %t232, 1
  %t235 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t234)
  call void @llvm.memcpy.p0.p0.i64(ptr %t235, ptr %t233, i64 %t234, i1 false)
  %t236 = insertvalue { i64, ptr } undef, i64 %t232, 0
  %t237 = insertvalue { i64, ptr } %t236, ptr %t235, 1
  %t238 = load ptr, ptr %l127, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s5, ptr %s5, ptr %t238, { i64, ptr } %t237)
  br label %bb41
bb41:
  %t240 = load ptr, ptr %l15, !tbaa !29
  %t242 = getelementptr %"compiler/load:Module", ptr %t240, i32 0, i32 29
  store ptr %t242, ptr %l17, !tbaa !29
  store i64 0, ptr %l18, !tbaa !24
  br label %bb42
bb42:
  store %olang.scope zeroinitializer, ptr %s7
  %t244 = load ptr, ptr %l17, !tbaa !29
  %t245 = load i64, ptr %l18, !tbaa !24
  %t248 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v0, ptr %t244, i64 %t245)
  %t249 = extractvalue { i32, { i64, ptr } } %t248, 1
  %t250 = extractvalue { i32, { i64, ptr } } %t248, 0
  store i32 %t250, ptr %l150
  %t251 = icmp ne i32 %t250, 0
  br i1 %t251, label %bb44, label %ok.252
ok.252:
  store { i64, ptr } %t249, ptr %l149
  br label %bb43
bb43:
  %t253 = load { i64, ptr }, ptr %l149, !tbaa !27
  store { i64, ptr } %t253, ptr %l146, !tbaa !27
  br label %bb48
bb44:
  %t254 = load i32, ptr %l150, !tbaa !23
  %t255 = ashr i32 %t254, 16
  %t257 = icmp eq i32 %t255, 1
  br i1 %t257, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  call void @__olang_check_failed(ptr @olang_loc_28ebd020d3001495_4ad5579e3d579679)
  unreachable
bb47:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s7)
  br label %bb59
bb48:
  %t259 = load { i64, ptr }, ptr %l146, !tbaa !27
  store { i64, ptr } %t259, ptr %l19, !tbaa !27
  %t260 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t262 = extractvalue { i64, ptr } %t260, 0
  store i64 %t262, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb49
bb49:
  store %olang.scope zeroinitializer, ptr %s8
  %t264 = load i64, ptr %l21, !tbaa !24
  %t265 = load i64, ptr %l20, !tbaa !24
  %t268 = icmp slt i64 %t264, %t265
  %t270 = xor i1 %t268, true
  br i1 %t270, label %bb50, label %bb51
bb50:
  call void @__olang_scope_close(ptr %s8)
  br label %bb57
bb51:
  br label %bb52
bb52:
  %t272 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t272, ptr %l159, !tbaa !27
  %t273 = load i64, ptr %l21, !tbaa !24
  %t275 = getelementptr { i64, ptr }, ptr %l159, i32 0, i32 1
  %t276 = load ptr, ptr %t275, !tbaa !27
  %t277 = getelementptr { i64, ptr }, ptr %t276, i64 %t273
  %t278 = load { i64, ptr }, ptr %t277, !tbaa !37
  store { i64, ptr } %t278, ptr %l22, !tbaa !27
  store ptr %l16, ptr %l162, !tbaa !29
  %t280 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t280, ptr %l163, !tbaa !27
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t282 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t285 = call { i64, ptr } @compiler_2fload_2ecompiler_2fload_3aLoader_2eEmbedded(ptr %v0, ptr %v0, ptr %t281, { i64, ptr } %t282)
  store { i64, ptr } %t285, ptr %l166
  br label %bb53
bb53:
  %t286 = load { i64, ptr }, ptr %l166, !tbaa !27
  %t288 = call { i64, ptr } @compiler_2fbuild_2eIrHash(ptr %v0, ptr %s8, { i64, ptr } %t286)
  store { i64, ptr } %t288, ptr %l168
  br label %bb54
bb54:
  %t289 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d212, i32 0, i32 1) }, 1
  %t290 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d212, i32 0, i32 1) }, 0
  %t291 = load { i64, ptr }, ptr %l163, !tbaa !27
  %t292 = extractvalue { i64, ptr } %t291, 1
  %t293 = extractvalue { i64, ptr } %t291, 0
  %t294 = add i64 %t290, %t293
  %t295 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d213, i32 0, i32 1) }, 1
  %t296 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d213, i32 0, i32 1) }, 0
  %t297 = add i64 %t294, %t296
  %t298 = load { i64, ptr }, ptr %l168, !tbaa !27
  %t299 = extractvalue { i64, ptr } %t298, 1
  %t300 = extractvalue { i64, ptr } %t298, 0
  %t301 = add i64 %t297, %t300
  %t302 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t301)
  call void @olang_textcopy(ptr %t302, ptr %t289, i64 %t290)
  %t303 = getelementptr i8, ptr %t302, i64 %t290
  call void @olang_textcopy(ptr %t303, ptr %t292, i64 %t293)
  %t304 = getelementptr i8, ptr %t303, i64 %t293
  call void @olang_textcopy(ptr %t304, ptr %t295, i64 %t296)
  %t305 = getelementptr i8, ptr %t304, i64 %t296
  call void @olang_textcopy(ptr %t305, ptr %t299, i64 %t300)
  %t306 = insertvalue { i64, ptr } undef, i64 %t301, 0
  %t307 = insertvalue { i64, ptr } %t306, ptr %t302, 1
  %t309 = extractvalue { i64, ptr } %t307, 0
  %t310 = extractvalue { i64, ptr } %t307, 1
  %t311 = mul i64 %t309, 1
  %t312 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t311)
  call void @llvm.memcpy.p0.p0.i64(ptr %t312, ptr %t310, i64 %t311, i1 false)
  %t313 = insertvalue { i64, ptr } undef, i64 %t309, 0
  %t314 = insertvalue { i64, ptr } %t313, ptr %t312, 1
  %t315 = load ptr, ptr %l162, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s5, ptr %s5, ptr %t315, { i64, ptr } %t314)
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s8)
  br label %bb56
bb56:
  %t317 = load i64, ptr %l21, !tbaa !24
  %t319 = add i64 %t317, 1
  store i64 %t319, ptr %l21, !tbaa !24
  br label %bb49
bb57:
  %t321 = load i64, ptr %l18, !tbaa !24
  %t322 = load i64, ptr %l20, !tbaa !24
  %t325 = add i64 %t321, %t322
  store i64 %t325, ptr %l18, !tbaa !24
  call void @__olang_scope_close(ptr %s7)
  br label %bb58
bb58:
  br label %bb42
bb59:
  %t327 = load i64, ptr %l14, !tbaa !24
  store i64 %t327, ptr %l176, !tbaa !24
  %t329 = call { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %s5, ptr %s0, ptr %l16)
  store { i64, ptr } %t329, ptr %l178
  br label %bb60
bb60:
  %t330 = load { i64, ptr }, ptr %l178, !tbaa !27
  %t331 = extractvalue { i64, ptr } %t330, 0
  %t332 = extractvalue { i64, ptr } %t330, 1
  %t333 = mul i64 %t331, 1
  %t334 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t333)
  call void @llvm.memcpy.p0.p0.i64(ptr %t334, ptr %t332, i64 %t333, i1 false)
  %t335 = insertvalue { i64, ptr } undef, i64 %t331, 0
  %t336 = insertvalue { i64, ptr } %t335, ptr %t334, 1
  %t338 = load i64, ptr %l176, !tbaa !24
  %t339 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t340 = load ptr, ptr %t339, !tbaa !27
  %t341 = getelementptr { i64, ptr }, ptr %t340, i64 %t338
  store { i64, ptr } %t336, ptr %t341, !tbaa !37
  call void @__olang_scope_close(ptr %s5)
  br label %bb61
bb61:
  %t342 = load i64, ptr %l13, !tbaa !24
  %t344 = add i64 %t342, 1
  store i64 %t344, ptr %l13, !tbaa !24
  br label %bb26
bb62:
  store i64 0, ptr %l23, !tbaa !24
  %t346 = load i64, ptr %l4, !tbaa !24
  store i64 %t346, ptr %l24, !tbaa !24
  store i64 1, ptr %l25, !tbaa !24
  %t348 = load i64, ptr %l24, !tbaa !24
  %t349 = load i64, ptr %l23, !tbaa !24
  %t352 = icmp sgt i64 %t348, %t349
  br i1 %t352, label %bb63, label %bb64
bb63:
  %t354 = load i64, ptr %l25, !tbaa !24
  %t356 = icmp sgt i64 %t354, 0
  br i1 %t356, label %bb65, label %bb66
bb64:
  store i64 0, ptr %l186, !tbaa !24
  br label %bb68
bb65:
  %t358 = load i64, ptr %l24, !tbaa !24
  %t359 = load i64, ptr %l23, !tbaa !24
  %t362 = sub i64 %t358, %t359
  %t363 = load i64, ptr %l25, !tbaa !24
  %t366 = add i64 %t362, %t363
  %t368 = sub i64 %t366, 1
  %t369 = load i64, ptr %l25, !tbaa !24
  %t372 = sdiv i64 %t368, %t369
  store i64 %t372, ptr %l189, !tbaa !24
  br label %bb67
bb66:
  store i64 0, ptr %l189, !tbaa !24
  br label %bb67
bb67:
  %t374 = load i64, ptr %l189, !tbaa !24
  store i64 %t374, ptr %l186, !tbaa !24
  br label %bb68
bb68:
  %t375 = load i64, ptr %l186, !tbaa !24
  store i64 %t375, ptr %l26, !tbaa !24
  store i64 0, ptr %l27, !tbaa !24
  br label %bb69
bb69:
  store %olang.scope zeroinitializer, ptr %s13
  %t376 = load i64, ptr %l27, !tbaa !24
  %t377 = load i64, ptr %l26, !tbaa !24
  %t380 = icmp slt i64 %t376, %t377
  %t382 = xor i1 %t380, true
  br i1 %t382, label %bb70, label %bb71
bb70:
  call void @__olang_scope_close(ptr %s13)
  br label %bb159
bb71:
  br label %bb72
bb72:
  %t384 = load i64, ptr %l23, !tbaa !24
  %t385 = load i64, ptr %l27, !tbaa !24
  %t386 = load i64, ptr %l25, !tbaa !24
  %t389 = mul i64 %t385, %t386
  %t392 = add i64 %t384, %t389
  store i64 %t392, ptr %l28, !tbaa !24
  %t394 = load i64, ptr %l28, !tbaa !24
  %t395 = load ptr, ptr %l0, !tbaa !29
  %t397 = getelementptr %"compiler/load:Loader", ptr %t395, i32 0, i32 7
  %t398 = load i64, ptr %t397, !tbaa !24
  %t401 = icmp eq i64 %t394, %t398
  br i1 %t401, label %bb73, label %bb74
bb73:
  call void @__olang_scope_close(ptr %s13)
  br label %bb158
bb74:
  br label %bb75
bb75:
  %t403 = load i64, ptr %l4, !tbaa !24
  store i64 %t403, ptr %l211, !tbaa !24
  %t404 = load i64, ptr %l211, !tbaa !24
  %t405 = icmp sge i64 %t404, 0
  br i1 %t405, label %bb76, label %bb77
bb76:
  %t407 = load i64, ptr %l211, !tbaa !24
  %t408 = mul i64 %t407, 1
  %t409 = call ptr @__olang_scope_alloc_zeroed(ptr %s13, i64 %t408)
  %t410 = insertvalue { i64, ptr } undef, i64 %t407, 0
  %t411 = insertvalue { i64, ptr } %t410, ptr %t409, 1
  store { i64, ptr } %t411, ptr %l29, !tbaa !27
  %t413 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %s13)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t413, ptr %l214
  br label %bb78
bb77:
  call void @__olang_check_failed(ptr @olang_loc_68c6c1ff5359bbb9_e0dcea9ab8fa86cd)
  unreachable
bb78:
  %t414 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l214
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t414, ptr %l30
  %t415 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %s13)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t415, ptr %l215
  br label %bb79
bb79:
  %t416 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l215
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t416, ptr %l31
  %t417 = load i64, ptr %l28, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s13, ptr %l31, i64 %t417)
  br label %bb80
bb80:
  store i64 0, ptr %l32, !tbaa !24
  %t420 = load i64, ptr %l4, !tbaa !24
  store i64 %t420, ptr %l33, !tbaa !24
  store i64 1, ptr %l34, !tbaa !24
  %t422 = load i64, ptr %l33, !tbaa !24
  %t423 = load i64, ptr %l32, !tbaa !24
  %t426 = icmp sgt i64 %t422, %t423
  br i1 %t426, label %bb81, label %bb82
bb81:
  %t428 = load i64, ptr %l34, !tbaa !24
  %t430 = icmp sgt i64 %t428, 0
  br i1 %t430, label %bb83, label %bb84
bb82:
  store i64 0, ptr %l222, !tbaa !24
  br label %bb86
bb83:
  %t432 = load i64, ptr %l33, !tbaa !24
  %t433 = load i64, ptr %l32, !tbaa !24
  %t436 = sub i64 %t432, %t433
  %t437 = load i64, ptr %l34, !tbaa !24
  %t440 = add i64 %t436, %t437
  %t442 = sub i64 %t440, 1
  %t443 = load i64, ptr %l34, !tbaa !24
  %t446 = sdiv i64 %t442, %t443
  store i64 %t446, ptr %l225, !tbaa !24
  br label %bb85
bb84:
  store i64 0, ptr %l225, !tbaa !24
  br label %bb85
bb85:
  %t448 = load i64, ptr %l225, !tbaa !24
  store i64 %t448, ptr %l222, !tbaa !24
  br label %bb86
bb86:
  %t449 = load i64, ptr %l222, !tbaa !24
  store i64 %t449, ptr %l35, !tbaa !24
  store i64 0, ptr %l36, !tbaa !24
  br label %bb87
bb87:
  store %olang.scope zeroinitializer, ptr %s16
  %t450 = load i64, ptr %l36, !tbaa !24
  %t451 = load i64, ptr %l35, !tbaa !24
  %t454 = icmp slt i64 %t450, %t451
  %t456 = xor i1 %t454, true
  br i1 %t456, label %bb88, label %bb89
bb88:
  call void @__olang_scope_close(ptr %s16)
  br label %bb97
bb89:
  br label %bb90
bb90:
  %t458 = load i64, ptr %l32, !tbaa !24
  %t459 = load i64, ptr %l36, !tbaa !24
  %t460 = load i64, ptr %l34, !tbaa !24
  %t463 = mul i64 %t459, %t460
  %t466 = add i64 %t458, %t463
  store i64 %t466, ptr %l37, !tbaa !24
  %t468 = load i64, ptr %l37, !tbaa !24
  %t471 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %l3, i64 %t468)
  store ptr %t471, ptr %l245
  br label %bb91
bb91:
  %t472 = load ptr, ptr %l245, !tbaa !29
  %t474 = getelementptr %"compiler/load:Module", ptr %t472, i32 0, i32 3
  %t475 = load i1, ptr %t474, !tbaa !21
  br i1 %t475, label %bb92, label %bb93
bb92:
  %t477 = load i64, ptr %l37, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s13, ptr %l31, i64 %t477)
  br label %bb94
bb93:
  br label %bb95
bb94:
  br label %bb95
bb95:
  call void @__olang_scope_close(ptr %s16)
  br label %bb96
bb96:
  %t480 = load i64, ptr %l36, !tbaa !24
  %t482 = add i64 %t480, 1
  store i64 %t482, ptr %l36, !tbaa !24
  br label %bb87
bb97:
  br label %bb98
bb98:
  store %olang.scope zeroinitializer, ptr %s19
  %t485 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %s13, ptr %l31)
  store i64 %t485, ptr %l253
  br label %bb99
bb99:
  %t486 = load i64, ptr %l253, !tbaa !24
  %t487 = icmp sgt i64 %t486, 0
  %t489 = xor i1 %t487, true
  br i1 %t489, label %bb100, label %bb101
bb100:
  call void @__olang_scope_close(ptr %s19)
  br label %bb135
bb101:
  br label %bb102
bb102:
  %t492 = call { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %s13, ptr %l31)
  %t493 = extractvalue { i32, i64 } %t492, 1
  %t494 = extractvalue { i32, i64 } %t492, 0
  store i32 %t494, ptr %l259
  %t495 = icmp ne i32 %t494, 0
  br i1 %t495, label %bb104, label %ok.496
ok.496:
  store i64 %t493, ptr %l258
  br label %bb103
bb103:
  %t497 = load i64, ptr %l258, !tbaa !24
  store i64 %t497, ptr %l256, !tbaa !24
  br label %bb106
bb104:
  br label %bb105
bb105:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s19)
  br label %bb135
bb106:
  %t498 = load i64, ptr %l256, !tbaa !24
  store i64 %t498, ptr %l38, !tbaa !24
  %t499 = load i64, ptr %l38, !tbaa !24
  %t501 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t502 = load ptr, ptr %t501, !tbaa !27
  %t503 = getelementptr i1, ptr %t502, i64 %t499
  %t504 = load i1, ptr %t503, !tbaa !31
  br i1 %t504, label %bb107, label %bb108
bb107:
  call void @__olang_scope_close(ptr %s19)
  br label %bb134
bb108:
  br label %bb109
bb109:
  %t506 = load i64, ptr %l38, !tbaa !24
  %t508 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t509 = load ptr, ptr %t508, !tbaa !27
  %t510 = getelementptr i1, ptr %t509, i64 %t506
  store i1 true, ptr %t510, !tbaa !31
  %t511 = load i64, ptr %l38, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s13, ptr %l30, i64 %t511)
  br label %bb110
bb110:
  %t514 = load i64, ptr %l38, !tbaa !24
  %t517 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %l3, i64 %t514)
  store ptr %t517, ptr %l267
  br label %bb111
bb111:
  %t518 = load ptr, ptr %l267, !tbaa !29
  %t520 = getelementptr %"compiler/load:Module", ptr %t518, i32 0, i32 11
  store ptr %t520, ptr %l39, !tbaa !29
  store i64 0, ptr %l40, !tbaa !24
  br label %bb112
bb112:
  store %olang.scope zeroinitializer, ptr %s23
  %t522 = load ptr, ptr %l39, !tbaa !29
  %t523 = load i64, ptr %l40, !tbaa !24
  %t526 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2eRunFrom_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %t522, i64 %t523)
  %t527 = extractvalue { i32, { i64, ptr } } %t526, 1
  %t528 = extractvalue { i32, { i64, ptr } } %t526, 0
  store i32 %t528, ptr %l274
  %t529 = icmp ne i32 %t528, 0
  br i1 %t529, label %bb114, label %ok.530
ok.530:
  store { i64, ptr } %t527, ptr %l273
  br label %bb113
bb113:
  %t531 = load { i64, ptr }, ptr %l273, !tbaa !27
  store { i64, ptr } %t531, ptr %l270, !tbaa !27
  br label %bb118
bb114:
  %t532 = load i32, ptr %l274, !tbaa !23
  %t533 = ashr i32 %t532, 16
  %t535 = icmp eq i32 %t533, 1
  br i1 %t535, label %bb115, label %bb116
bb115:
  br label %bb117
bb116:
  call void @__olang_check_failed(ptr @olang_loc_3d75cb007153ac43_568e8d111effec1f)
  unreachable
bb117:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s23)
  br label %bb133
bb118:
  %t537 = load { i64, ptr }, ptr %l270, !tbaa !27
  store { i64, ptr } %t537, ptr %l41, !tbaa !27
  %t538 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t540 = extractvalue { i64, ptr } %t538, 0
  store i64 %t540, ptr %l42, !tbaa !24
  store i64 0, ptr %l43, !tbaa !24
  br label %bb119
bb119:
  store %olang.scope zeroinitializer, ptr %s24
  %t542 = load i64, ptr %l43, !tbaa !24
  %t543 = load i64, ptr %l42, !tbaa !24
  %t546 = icmp slt i64 %t542, %t543
  %t548 = xor i1 %t546, true
  br i1 %t548, label %bb120, label %bb121
bb120:
  call void @__olang_scope_close(ptr %s24)
  br label %bb131
bb121:
  br label %bb122
bb122:
  %t550 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t550, ptr %l283, !tbaa !27
  %t551 = load i64, ptr %l43, !tbaa !24
  %t553 = getelementptr { i64, ptr }, ptr %l283, i32 0, i32 1
  %t554 = load ptr, ptr %t553, !tbaa !27
  %t555 = getelementptr %"compiler/load:Import", ptr %t554, i64 %t551
  %t556 = load %"compiler/load:Import", ptr %t555
  store %"compiler/load:Import" %t556, ptr %l44
  %t558 = getelementptr %"compiler/load:Import", ptr %l44, i32 0, i32 5
  %t559 = load i64, ptr %t558, !tbaa !24
  %t561 = icmp sge i64 %t559, 0
  br i1 %t561, label %bb123, label %bb124
bb123:
  %t563 = getelementptr %"compiler/load:Import", ptr %l44, i32 0, i32 5
  %t564 = load i64, ptr %t563, !tbaa !24
  %t566 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t567 = load ptr, ptr %t566, !tbaa !27
  %t568 = getelementptr i1, ptr %t567, i64 %t564
  %t569 = load i1, ptr %t568, !tbaa !31
  %t571 = xor i1 %t569, true
  store i1 %t571, ptr %l288, !tbaa !21
  br label %bb125
bb124:
  store i1 false, ptr %l288, !tbaa !21
  br label %bb125
bb125:
  %t573 = load i1, ptr %l288, !tbaa !21
  br i1 %t573, label %bb126, label %bb127
bb126:
  %t574 = getelementptr %"compiler/load:Import", ptr %l44, i32 0, i32 5
  %t575 = load i64, ptr %t574, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s13, ptr %l31, i64 %t575)
  br label %bb128
bb127:
  br label %bb129
bb128:
  br label %bb129
bb129:
  call void @__olang_scope_close(ptr %s24)
  br label %bb130
bb130:
  %t578 = load i64, ptr %l43, !tbaa !24
  %t580 = add i64 %t578, 1
  store i64 %t580, ptr %l43, !tbaa !24
  br label %bb119
bb131:
  %t582 = load i64, ptr %l40, !tbaa !24
  %t583 = load i64, ptr %l42, !tbaa !24
  %t586 = add i64 %t582, %t583
  store i64 %t586, ptr %l40, !tbaa !24
  call void @__olang_scope_close(ptr %s23)
  br label %bb132
bb132:
  br label %bb112
bb133:
  call void @__olang_scope_close(ptr %s19)
  br label %bb134
bb134:
  br label %bb98
bb135:
  %t588 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_214, 0
  %t589 = insertvalue { ptr, ptr } %t588, ptr null, 1
  %t592 = extractvalue { ptr, ptr } %t589, 0
  %t593 = extractvalue { ptr, ptr } %t589, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %s13, ptr %s13, ptr %l30, ptr %t592, ptr %t593)
  br label %bb136
bb136:
  %t594 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %s13)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t594, ptr %l301
  br label %bb137
bb137:
  %t595 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l301
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t595, ptr %l45
  %t596 = load { i64, ptr }, ptr %l7, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s13, ptr %s0, ptr %l45, { i64, ptr } %t596)
  br label %bb138
bb138:
  %t599 = load i64, ptr %l28, !tbaa !24
  %t601 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t602 = load ptr, ptr %t601, !tbaa !27
  %t603 = getelementptr { i64, ptr }, ptr %t602, i64 %t599
  %t604 = load { i64, ptr }, ptr %t603, !tbaa !37
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s13, ptr %s0, ptr %l45, { i64, ptr } %t604)
  br label %bb139
bb139:
  store ptr %l30, ptr %l46, !tbaa !29
  store i64 0, ptr %l47, !tbaa !24
  br label %bb140
bb140:
  store %olang.scope zeroinitializer, ptr %s28
  %t608 = load ptr, ptr %l46, !tbaa !29
  %t609 = load i64, ptr %l47, !tbaa !24
  %t612 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %s13, ptr %t608, i64 %t609)
  %t613 = extractvalue { i32, { i64, ptr } } %t612, 1
  %t614 = extractvalue { i32, { i64, ptr } } %t612, 0
  store i32 %t614, ptr %l312
  %t615 = icmp ne i32 %t614, 0
  br i1 %t615, label %bb142, label %ok.616
ok.616:
  store { i64, ptr } %t613, ptr %l311
  br label %bb141
bb141:
  %t617 = load { i64, ptr }, ptr %l311, !tbaa !27
  store { i64, ptr } %t617, ptr %l308, !tbaa !27
  br label %bb146
bb142:
  %t618 = load i32, ptr %l312, !tbaa !23
  %t619 = ashr i32 %t618, 16
  %t621 = icmp eq i32 %t619, 1
  br i1 %t621, label %bb143, label %bb144
bb143:
  br label %bb145
bb144:
  call void @__olang_check_failed(ptr @olang_loc_7d47a64265939568_77c8ba1e6120f9e4)
  unreachable
bb145:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s28)
  br label %bb156
bb146:
  %t623 = load { i64, ptr }, ptr %l308, !tbaa !27
  store { i64, ptr } %t623, ptr %l48, !tbaa !27
  %t624 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t626 = extractvalue { i64, ptr } %t624, 0
  store i64 %t626, ptr %l49, !tbaa !24
  store i64 0, ptr %l50, !tbaa !24
  br label %bb147
bb147:
  store %olang.scope zeroinitializer, ptr %s29
  %t628 = load i64, ptr %l50, !tbaa !24
  %t629 = load i64, ptr %l49, !tbaa !24
  %t632 = icmp slt i64 %t628, %t629
  %t634 = xor i1 %t632, true
  br i1 %t634, label %bb148, label %bb149
bb148:
  call void @__olang_scope_close(ptr %s29)
  br label %bb154
bb149:
  br label %bb150
bb150:
  %t636 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t636, ptr %l321, !tbaa !27
  %t637 = load i64, ptr %l50, !tbaa !24
  %t639 = getelementptr { i64, ptr }, ptr %l321, i32 0, i32 1
  %t640 = load ptr, ptr %t639, !tbaa !27
  %t641 = getelementptr i64, ptr %t640, i64 %t637
  %t642 = load i64, ptr %t641, !tbaa !34
  store i64 %t642, ptr %l51, !tbaa !24
  store ptr %l45, ptr %l324, !tbaa !29
  %t644 = load i64, ptr %l51, !tbaa !24
  %t647 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %l3, i64 %t644)
  store ptr %t647, ptr %l327
  br label %bb151
bb151:
  %t648 = load ptr, ptr %l327, !tbaa !29
  %t650 = getelementptr %"compiler/load:Module", ptr %t648, i32 0, i32 2
  %t651 = load { i64, ptr }, ptr %t650, !tbaa !27
  %t652 = load i64, ptr %l51, !tbaa !24
  %t654 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t655 = load ptr, ptr %t654, !tbaa !27
  %t656 = getelementptr { i64, ptr }, ptr %t655, i64 %t652
  %t657 = load { i64, ptr }, ptr %t656, !tbaa !37
  %t659 = extractvalue { i64, ptr } %t651, 1
  %t660 = extractvalue { i64, ptr } %t651, 0
  %t661 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d215, i32 0, i32 1) }, 1
  %t662 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d215, i32 0, i32 1) }, 0
  %t663 = add i64 %t660, %t662
  %t665 = extractvalue { i64, ptr } %t657, 1
  %t666 = extractvalue { i64, ptr } %t657, 0
  %t667 = add i64 %t663, %t666
  %t668 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t667)
  call void @olang_textcopy(ptr %t668, ptr %t659, i64 %t660)
  %t669 = getelementptr i8, ptr %t668, i64 %t660
  call void @olang_textcopy(ptr %t669, ptr %t661, i64 %t662)
  %t670 = getelementptr i8, ptr %t669, i64 %t662
  call void @olang_textcopy(ptr %t670, ptr %t665, i64 %t666)
  %t671 = insertvalue { i64, ptr } undef, i64 %t667, 0
  %t672 = insertvalue { i64, ptr } %t671, ptr %t668, 1
  %t674 = extractvalue { i64, ptr } %t672, 0
  %t675 = extractvalue { i64, ptr } %t672, 1
  %t676 = mul i64 %t674, 1
  %t677 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t676)
  call void @llvm.memcpy.p0.p0.i64(ptr %t677, ptr %t675, i64 %t676, i1 false)
  %t678 = insertvalue { i64, ptr } undef, i64 %t674, 0
  %t679 = insertvalue { i64, ptr } %t678, ptr %t677, 1
  %t680 = load ptr, ptr %l324, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s13, ptr %s13, ptr %t680, { i64, ptr } %t679)
  br label %bb152
bb152:
  call void @__olang_scope_close(ptr %s29)
  br label %bb153
bb153:
  %t682 = load i64, ptr %l50, !tbaa !24
  %t684 = add i64 %t682, 1
  store i64 %t684, ptr %l50, !tbaa !24
  br label %bb147
bb154:
  %t686 = load i64, ptr %l47, !tbaa !24
  %t687 = load i64, ptr %l49, !tbaa !24
  %t690 = add i64 %t686, %t687
  store i64 %t690, ptr %l47, !tbaa !24
  call void @__olang_scope_close(ptr %s28)
  br label %bb155
bb155:
  br label %bb140
bb156:
  %t692 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t692, ptr %l339, !tbaa !27
  %t693 = load i64, ptr %l28, !tbaa !24
  store i64 %t693, ptr %l340, !tbaa !24
  %t695 = call { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %s13, ptr %v1, ptr %l45)
  store { i64, ptr } %t695, ptr %l342
  br label %bb157
bb157:
  %t696 = load { i64, ptr }, ptr %l342, !tbaa !27
  %t697 = extractvalue { i64, ptr } %t696, 0
  %t698 = extractvalue { i64, ptr } %t696, 1
  %t699 = mul i64 %t697, 1
  %t700 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t699)
  call void @llvm.memcpy.p0.p0.i64(ptr %t700, ptr %t698, i64 %t699, i1 false)
  %t701 = insertvalue { i64, ptr } undef, i64 %t697, 0
  %t702 = insertvalue { i64, ptr } %t701, ptr %t700, 1
  %t704 = load i64, ptr %l340, !tbaa !24
  %t705 = getelementptr { i64, ptr }, ptr %l339, i32 0, i32 1
  %t706 = load ptr, ptr %t705, !tbaa !27
  %t707 = getelementptr { i64, ptr }, ptr %t706, i64 %t704
  store { i64, ptr } %t702, ptr %t707, !tbaa !37
  call void @__olang_scope_close(ptr %s13)
  br label %bb158
bb158:
  %t708 = load i64, ptr %l27, !tbaa !24
  %t710 = add i64 %t708, 1
  store i64 %t710, ptr %l27, !tbaa !24
  br label %bb69
bb159:
  %t712 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t712, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local ptr @compiler_2folang_2eplacement(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l10 = alloca %"compiler/scope:Scoper"
  %l24 = alloca %"compiler/free:Free"
  %l26 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca i32
  %l30 = alloca { i64, ptr }
  %l33 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  %t9 = alloca %"compiler/scope:Scoper", align 8
  %t51 = alloca %"compiler/free:Free", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 11
  %t8 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t7
  call void @compiler_2fscope_3aScoper_2ector(ptr %t9, ptr %v0, ptr %v0, ptr %v1, ptr %t4, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t8)
  call void @llvm.memmove.p0.p0.i64(ptr %l10, ptr %t9, i64 1072, i1 false)
  br label %bb1
bb1:
  %t12 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 1072, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t12, ptr %l10, i64 1072, i1 false)
  store ptr %t12, ptr %l4, !tbaa !29
  %t14 = load ptr, ptr %l4, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr { ptr, ptr }, ptr null, i32 1
  %t17 = ptrtoint ptr %t16 to i64
  %t18 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 %t17, i64 8)
  %t19 = getelementptr { ptr, ptr }, ptr %t18, i32 0, i32 0
  store ptr %t15, ptr %t19, !tbaa !28
  call void @__olang_scope_escape(ptr %v0)
  %t21 = getelementptr { ptr, ptr }, ptr %t18, i32 0, i32 1
  store ptr %v0, ptr %t21, !tbaa !28
  %t22 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_216, 0
  %t23 = insertvalue { ptr, ptr } %t22, ptr %t18, 1
  %t26 = getelementptr %"compiler/scope:Scoper", ptr %t14, i32 0, i32 4
  store { ptr, ptr } %t23, ptr %t26
  %t27 = load ptr, ptr %l4, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr { ptr, ptr }, ptr null, i32 1
  %t30 = ptrtoint ptr %t29 to i64
  %t31 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 %t30, i64 8)
  %t32 = getelementptr { ptr, ptr }, ptr %t31, i32 0, i32 0
  store ptr %t28, ptr %t32, !tbaa !28
  call void @__olang_scope_escape(ptr %v0)
  %t34 = getelementptr { ptr, ptr }, ptr %t31, i32 0, i32 1
  store ptr %v0, ptr %t34, !tbaa !28
  %t35 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_217, 0
  %t36 = insertvalue { ptr, ptr } %t35, ptr %t31, 1
  %t39 = getelementptr %"compiler/scope:Scoper", ptr %t27, i32 0, i32 5
  store { ptr, ptr } %t36, ptr %t39
  %t40 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eRun(ptr %v1, ptr %t40)
  br label %bb2
bb2:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/check:Checker", ptr %t42, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/check:Checker", ptr %t46, i32 0, i32 11
  %t49 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t48
  %t50 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2ffree_3aFree_2ector(ptr %t51, ptr %v0, ptr %v0, ptr %v1, ptr %v1, ptr %t45, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t49, ptr %t50)
  call void @llvm.memmove.p0.p0.i64(ptr %l24, ptr %t51, i64 520, i1 false)
  br label %bb3
bb3:
  %t55 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 520, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t55, ptr %l24, i64 520, i1 false)
  store ptr %t55, ptr %l5, !tbaa !29
  %t57 = load ptr, ptr %l5, !tbaa !29
  store ptr %t57, ptr %l26, !tbaa !29
  %t58 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d218, i32 0, i32 1) })
  %t59 = extractvalue { i32, { i64, ptr } } %t58, 1
  %t60 = extractvalue { i32, { i64, ptr } } %t58, 0
  store i32 %t60, ptr %l29
  %t61 = icmp ne i32 %t60, 0
  br i1 %t61, label %bb5, label %ok.62
ok.62:
  store { i64, ptr } %t59, ptr %l28
  br label %bb4
bb4:
  %t63 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t63, ptr %l27, !tbaa !27
  br label %bb7
bb5:
  br label %bb6
bb6:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d219, i32 0, i32 1) }, ptr %l30, !tbaa !27
  %t64 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t64, 0
  %t67 = extractvalue { i64, ptr } %t64, 1
  %t68 = mul i64 %t66, 1
  %t69 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t68)
  call void @llvm.memcpy.p0.p0.i64(ptr %t69, ptr %t67, i64 %t68, i1 false)
  %t70 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t69, 1
  store { i64, ptr } %t71, ptr %l27, !tbaa !27
  br label %bb7
bb7:
  %t73 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t74 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t73, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d220, i32 0, i32 1) })
  store i1 %t74, ptr %l33
  br label %bb8
bb8:
  %t75 = load i1, ptr %l33, !tbaa !21
  %t76 = xor i1 %t75, true
  %t78 = load ptr, ptr %l26, !tbaa !29
  %t79 = getelementptr %"compiler/free:Free", ptr %t78, i32 0, i32 68
  store i1 %t76, ptr %t79, !tbaa !21
  %t80 = load ptr, ptr %l5, !tbaa !29
  %t81 = load ptr, ptr %l4, !tbaa !29
  %t83 = getelementptr %"compiler/scope:Scoper", ptr %t81, i32 0, i32 2
  %t84 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t83
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eDecide(ptr %v1, ptr %v1, ptr %t80, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t84, i64 %a2, i1 %a3)
  br label %bb9
bb9:
  %t91 = load ptr, ptr %l5, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t91, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2folang_2eputFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1, i32 %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l10 = alloca i32
  %l16 = alloca i32
  %l20 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t1, 1
  %t5 = extractvalue { i64, ptr } %t1, 0
  %t6 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d221, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d221, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t10 = sext i32 %a2 to i64
  %t11 = call i64 @__olang_fmt_i64(ptr null, i64 %t10)
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d222, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d222, i32 0, i32 1) }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t4, i64 %t5)
  %t17 = getelementptr i8, ptr %t16, i64 %t5
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  %t19 = call i64 @__olang_fmt_i64(ptr %t18, i64 %t10)
  %t20 = getelementptr i8, ptr %t18, i64 %t11
  call void @olang_textcopy(ptr %t20, ptr %t13, i64 %t14)
  %t21 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t16, 1
  store { i64, ptr } %t22, ptr %l3, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t29 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %v1, { i64, ptr } %t24, { i64, ptr } %a1)
  store i32 %t29, ptr %l10
  %t30 = icmp ne i32 %t29, 0
  br i1 %t30, label %bb2, label %ok.31
ok.31:
  br label %bb1
bb1:
  br label %bb6
bb2:
  %t32 = load i32, ptr %l10, !tbaa !23
  %t33 = ashr i32 %t32, 16
  %t35 = icmp eq i32 %t33, 1
  br i1 %t35, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_525dfa3cfb0bfb03_4e25463d9369c1cf)
  unreachable
bb5:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb6:
  %t38 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t42 = call i32 @std_2fos_2eRename(ptr %s0, ptr %v0, { i64, ptr } %t38, { i64, ptr } %t39)
  store i32 %t42, ptr %l16
  %t43 = icmp ne i32 %t42, 0
  br i1 %t43, label %bb8, label %ok.44
ok.44:
  br label %bb7
bb7:
  br label %bb18
bb8:
  %t45 = load i32, ptr %l16, !tbaa !23
  %t46 = ashr i32 %t45, 16
  %t48 = icmp eq i32 %t46, 1
  br i1 %t48, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_8e0c0d4d9d5e4982_1d0736507b33918e)
  unreachable
bb11:
  call void @__olang_ert_req_clear()
  %t50 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t52 = call i32 @std_2fos_2eRemove(ptr %s0, { i64, ptr } %t50)
  store i32 %t52, ptr %l20
  %t53 = icmp ne i32 %t52, 0
  br i1 %t53, label %bb13, label %ok.54
ok.54:
  br label %bb12
bb12:
  br label %bb17
bb13:
  %t55 = load i32, ptr %l20, !tbaa !23
  %t56 = ashr i32 %t55, 16
  %t58 = icmp eq i32 %t56, 1
  br i1 %t58, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_b96489c868b59f9_7d9f173036255045)
  unreachable
bb16:
  call void @__olang_ert_req_clear()
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb18:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2folang_2erecordPath(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/build:Config", ptr %a0, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l4, !tbaa !27
  %t7 = call { i64, ptr } @compiler_2fbuild_2eReadable(ptr %v1, ptr %s0, { i64, ptr } %a1)
  store { i64, ptr } %t7, ptr %l6
  br label %bb1
bb1:
  store { i64, ptr } %a2, ptr %l7, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t9, 0
  store i64 %t10, ptr %l8, !tbaa !24
  %t11 = icmp sge i64 0, 0
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = icmp sle i64 0, 20
  br i1 %t13, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @olang_loc_a5855f4dee34d57_8118d8286dddc923)
  unreachable
bb4:
  %t15 = load i64, ptr %l8, !tbaa !24
  %t16 = icmp sle i64 20, %t15
  br i1 %t16, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_a5855f4dee34d57_8118d8286dddc923)
  unreachable
bb6:
  %t18 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i8, ptr %t19, i64 0
  %t21 = sub i64 20, 0
  %t22 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t20, 1
  %t24 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t24, 1
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t27 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d223, i32 0, i32 1) }, 1
  %t28 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d223, i32 0, i32 1) }, 0
  %t29 = add i64 %t26, %t28
  %t30 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t30, 1
  %t32 = extractvalue { i64, ptr } %t30, 0
  %t33 = add i64 %t29, %t32
  %t34 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d224, i32 0, i32 1) }, 1
  %t35 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d224, i32 0, i32 1) }, 0
  %t36 = add i64 %t33, %t35
  %t38 = extractvalue { i64, ptr } %t23, 1
  %t39 = extractvalue { i64, ptr } %t23, 0
  %t40 = add i64 %t36, %t39
  %t41 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t40)
  call void @olang_textcopy(ptr %t41, ptr %t25, i64 %t26)
  %t42 = getelementptr i8, ptr %t41, i64 %t26
  call void @olang_textcopy(ptr %t42, ptr %t27, i64 %t28)
  %t43 = getelementptr i8, ptr %t42, i64 %t28
  call void @olang_textcopy(ptr %t43, ptr %t31, i64 %t32)
  %t44 = getelementptr i8, ptr %t43, i64 %t32
  call void @olang_textcopy(ptr %t44, ptr %t34, i64 %t35)
  %t45 = getelementptr i8, ptr %t44, i64 %t35
  call void @olang_textcopy(ptr %t45, ptr %t38, i64 %t39)
  %t46 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t41, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t47, ptr %rv
  br label %ret
bb7:
  call void @__olang_check_failed(ptr @olang_loc_a5855f4dee34d57_8118d8286dddc923)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2folang_2ereusable(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %lp3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %lp12 = alloca ptr
  %l13 = alloca i1
  %l14 = alloca %"std/prelude/text:LineIter"
  %l15 = alloca { i64, ptr }
  %l16 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l22 = alloca i64
  %l25 = alloca i64
  %l43 = alloca { i64, ptr }
  %l46 = alloca i1
  %l47 = alloca ptr
  %l51 = alloca ptr
  %l54 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l61 = alloca i32
  %l65 = alloca %"compiler/emit:Reused"
  %l67 = alloca %"std/prelude/text:LineIter"
  %l68 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l71 = alloca i32
  %l75 = alloca i1
  %l77 = alloca i1
  %l78 = alloca i64
  %l79 = alloca { i64, ptr }
  %l82 = alloca i64
  %l83 = alloca i64
  %l87 = alloca { i64, ptr }
  %l88 = alloca i64
  %l89 = alloca i32
  %l90 = alloca i64
  %l91 = alloca i32
  %l93 = alloca i1
  %l94 = alloca { i64, ptr }
  %l97 = alloca i64
  %l98 = alloca i64
  %l103 = alloca i1
  %l105 = alloca i1
  %l106 = alloca ptr
  %l107 = alloca { i64, ptr }
  %l110 = alloca i64
  %l111 = alloca i64
  %l119 = alloca i1
  %l120 = alloca i1
  %l122 = alloca i1
  %l126 = alloca i1
  %l127 = alloca { i64, ptr }
  %l130 = alloca i1
  %l131 = alloca { i64, ptr }
  %l133 = alloca i64
  %l136 = alloca i1
  %l138 = alloca ptr
  %l139 = alloca { i64, ptr }
  %l140 = alloca i64
  %l147 = alloca ptr
  %l148 = alloca { i64, ptr }
  %l151 = alloca i64
  %l152 = alloca i64
  %l159 = alloca ptr
  %l161 = alloca i1
  %l163 = alloca i1
  %l165 = alloca i64
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aReused_3e(ptr %v3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l16
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 8, i64 8)
  store ptr %t2, ptr %lp3
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l16
  %t4 = load ptr, ptr %lp3
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %t4
  store i64 0, ptr %l4, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t9 = load i64, ptr %l5, !tbaa !24
  %t10 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb2, label %bb3
bb2:
  %t15 = load i64, ptr %l6, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb7
bb4:
  %t19 = load i64, ptr %l5, !tbaa !24
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l6, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l6, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l25, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb6
bb6:
  %t35 = load i64, ptr %l25, !tbaa !24
  store i64 %t35, ptr %l22, !tbaa !24
  br label %bb7
bb7:
  %t36 = load i64, ptr %l22, !tbaa !24
  store i64 %t36, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t37 = load i64, ptr %l8, !tbaa !24
  %t38 = load i64, ptr %l7, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb121
bb10:
  br label %bb11
bb11:
  %t45 = load i64, ptr %l4, !tbaa !24
  %t46 = load i64, ptr %l8, !tbaa !24
  %t47 = load i64, ptr %l6, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  store i64 %t53, ptr %l9, !tbaa !24
  %t55 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t55, ptr %l43, !tbaa !27
  %t56 = load i64, ptr %l9, !tbaa !24
  %t58 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr { i64, ptr }, ptr %t59, i64 %t56
  %t61 = load { i64, ptr }, ptr %t60, !tbaa !37
  %t63 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s2, { i64, ptr } %t61, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d225, i32 0, i32 1) })
  store i1 %t63, ptr %l46
  br label %bb12
bb12:
  %t64 = load i1, ptr %l46, !tbaa !21
  br i1 %t64, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb120
bb14:
  br label %bb15
bb15:
  store ptr %a1, ptr %l47, !tbaa !29
  %t68 = getelementptr %"compiler/load:Loader", ptr %a0, i32 0, i32 5
  %t69 = load i64, ptr %l9, !tbaa !24
  %t72 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t68, i64 %t69)
  store ptr %t72, ptr %l51
  br label %bb16
bb16:
  %t73 = load ptr, ptr %l51, !tbaa !29
  %t75 = getelementptr %"compiler/load:Module", ptr %t73, i32 0, i32 2
  %t76 = load { i64, ptr }, ptr %t75, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t77, ptr %l54, !tbaa !27
  %t78 = load i64, ptr %l9, !tbaa !24
  %t80 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = getelementptr { i64, ptr }, ptr %t81, i64 %t78
  %t83 = load { i64, ptr }, ptr %t82, !tbaa !37
  %t84 = load ptr, ptr %l47, !tbaa !29
  %t87 = call { i64, ptr } @compiler_2folang_2erecordPath(ptr %v1, ptr %v0, ptr %v2, ptr %s2, ptr %t84, { i64, ptr } %t76, { i64, ptr } %t83)
  store { i64, ptr } %t87, ptr %l57
  br label %bb17
bb17:
  %t88 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t88, ptr %l10, !tbaa !27
  %t89 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t91 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s2, ptr %s2, { i64, ptr } %t89)
  %t92 = extractvalue { i32, { i64, ptr } } %t91, 1
  %t93 = extractvalue { i32, { i64, ptr } } %t91, 0
  store i32 %t93, ptr %l61
  %t94 = icmp ne i32 %t93, 0
  br i1 %t94, label %bb19, label %ok.95
ok.95:
  store { i64, ptr } %t92, ptr %l60
  br label %bb18
bb18:
  %t96 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t96, ptr %l58, !tbaa !27
  br label %bb23
bb19:
  %t97 = load i32, ptr %l61, !tbaa !23
  %t98 = ashr i32 %t97, 16
  %t100 = icmp eq i32 %t98, 1
  br i1 %t100, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_ab41c76c9764eb19_14bd85dfef8a6745)
  unreachable
bb22:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb120
bb23:
  %t102 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t102, ptr %l11, !tbaa !27
  %t103 = load i64, ptr %l9, !tbaa !24
  %t105 = call %"compiler/emit:Reused" @compiler_2femit_3aReused_2ector(ptr %v3, i64 %t103)
  store %"compiler/emit:Reused" %t105, ptr %l65
  br label %bb24
bb24:
  %t106 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 64, i64 8)
  store ptr %t106, ptr %lp12
  %t107 = load %"compiler/emit:Reused", ptr %l65
  %t108 = load ptr, ptr %lp12
  store %"compiler/emit:Reused" %t107, ptr %t108
  store i1 false, ptr %l13, !tbaa !21
  %t109 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t111 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %s2, ptr %s2, { i64, ptr } %t109)
  store %"std/prelude/text:LineIter" %t111, ptr %l67
  br label %bb25
bb25:
  %t112 = load %"std/prelude/text:LineIter", ptr %l67
  store %"std/prelude/text:LineIter" %t112, ptr %l14
  br label %bb26
bb26:
  store %olang.scope zeroinitializer, ptr %s6
  %t114 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %s2, ptr %l14)
  %t115 = extractvalue { i32, { i64, ptr } } %t114, 1
  %t116 = extractvalue { i32, { i64, ptr } } %t114, 0
  store i32 %t116, ptr %l71
  %t117 = icmp ne i32 %t116, 0
  br i1 %t117, label %bb28, label %ok.118
ok.118:
  store { i64, ptr } %t115, ptr %l70
  br label %bb27
bb27:
  %t119 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t119, ptr %l68, !tbaa !27
  br label %bb32
bb28:
  %t120 = load i32, ptr %l71, !tbaa !23
  %t121 = ashr i32 %t120, 16
  %t123 = icmp eq i32 %t121, 1
  br i1 %t123, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_d540fbb856ad9648_e6cd81c31b943694)
  unreachable
bb31:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s6)
  br label %bb111
bb32:
  %t125 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t125, ptr %l15, !tbaa !27
  %t126 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t128 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s6, { i64, ptr } %t126, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d226, i32 0, i32 1) })
  store i1 %t128, ptr %l75
  br label %bb33
bb33:
  %t129 = load i1, ptr %l75, !tbaa !21
  br i1 %t129, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb109
bb35:
  store %olang.scope zeroinitializer, ptr %s8
  %t130 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t132 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s2, ptr %s8, { i64, ptr } %t130, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d227, i32 0, i32 1) })
  store i1 %t132, ptr %l77
  br label %bb36
bb36:
  %t133 = load i1, ptr %l77, !tbaa !21
  br i1 %t133, label %bb37, label %bb38
bb37:
  store %olang.scope zeroinitializer, ptr %s9
  %t134 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t134, ptr %l79, !tbaa !27
  %t135 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t135, 0
  store i64 %t138, ptr %l82, !tbaa !24
  %t139 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t139, 0
  store i64 %t140, ptr %l83, !tbaa !24
  %t141 = icmp sge i64 5, 0
  br i1 %t141, label %bb39, label %bb40
bb38:
  store %olang.scope zeroinitializer, ptr %s10
  %t143 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t145 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s2, ptr %s10, { i64, ptr } %t143, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d228, i32 0, i32 1) })
  store i1 %t145, ptr %l93
  br label %bb51
bb39:
  %t146 = load i64, ptr %l82, !tbaa !24
  %t147 = icmp sle i64 5, %t146
  br i1 %t147, label %bb41, label %bb42
bb40:
  call void @__olang_check_failed(ptr @olang_loc_30bb4d1d04b77ae4_b48bc1201be9b2a0)
  unreachable
bb41:
  %t149 = load i64, ptr %l82, !tbaa !24
  %t150 = load i64, ptr %l83, !tbaa !24
  %t151 = icmp sle i64 %t149, %t150
  br i1 %t151, label %bb43, label %bb44
bb42:
  call void @__olang_check_failed(ptr @olang_loc_30bb4d1d04b77ae4_b48bc1201be9b2a0)
  unreachable
bb43:
  %t153 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !27
  %t155 = load i64, ptr %l82, !tbaa !24
  %t156 = getelementptr i8, ptr %t154, i64 5
  %t157 = sub i64 %t155, 5
  %t158 = insertvalue { i64, ptr } undef, i64 %t157, 0
  %t159 = insertvalue { i64, ptr } %t158, ptr %t156, 1
  store { i64, ptr } %t159, ptr %l87, !tbaa !27
  %t160 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s9, i64 10)
  %t161 = extractvalue { i32, i64 } %t160, 1
  %t162 = extractvalue { i32, i64 } %t160, 0
  store i32 %t162, ptr %l89
  %t163 = icmp ne i32 %t162, 0
  br i1 %t163, label %bb46, label %ok.164
ok.164:
  store i64 %t161, ptr %l88
  br label %bb45
bb44:
  call void @__olang_check_failed(ptr @olang_loc_30bb4d1d04b77ae4_b48bc1201be9b2a0)
  unreachable
bb45:
  %t165 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t166 = load i64, ptr %l88, !tbaa !24
  %t167 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s2, { i64, ptr } %t165, i64 %t166)
  %t168 = extractvalue { i32, i64 } %t167, 1
  %t169 = extractvalue { i32, i64 } %t167, 0
  store i32 %t169, ptr %l91
  %t170 = icmp ne i32 %t169, 0
  br i1 %t170, label %bb49, label %ok.171
ok.171:
  store i64 %t168, ptr %l90
  br label %bb48
bb46:
  br label %bb47
bb47:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l78, !tbaa !24
  br label %bb50
bb48:
  %t172 = load i64, ptr %l90, !tbaa !24
  store i64 %t172, ptr %l78, !tbaa !24
  br label %bb50
bb49:
  br label %bb47
bb50:
  %t173 = load i64, ptr %l78, !tbaa !24
  %t174 = load ptr, ptr %lp12
  %t175 = getelementptr %"compiler/emit:Reused", ptr %t174, i32 0, i32 4
  store i64 %t173, ptr %t175, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  br label %bb108
bb51:
  %t176 = load i1, ptr %l93, !tbaa !21
  br i1 %t176, label %bb52, label %bb53
bb52:
  store %olang.scope zeroinitializer, ptr %s11
  %t177 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t177, ptr %l94, !tbaa !27
  %t178 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t181 = extractvalue { i64, ptr } %t178, 0
  store i64 %t181, ptr %l97, !tbaa !24
  %t182 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t183 = extractvalue { i64, ptr } %t182, 0
  store i64 %t183, ptr %l98, !tbaa !24
  %t184 = icmp sge i64 6, 0
  br i1 %t184, label %bb54, label %bb55
bb53:
  store %olang.scope zeroinitializer, ptr %s12
  %t186 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t188 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s2, ptr %s12, { i64, ptr } %t186, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d229, i32 0, i32 1) })
  store i1 %t188, ptr %l105
  br label %bb61
bb54:
  %t189 = load i64, ptr %l97, !tbaa !24
  %t190 = icmp sle i64 6, %t189
  br i1 %t190, label %bb56, label %bb57
bb55:
  call void @__olang_check_failed(ptr @olang_loc_e09c8d310c475dd1_b9a5b78f48e38cfd)
  unreachable
bb56:
  %t192 = load i64, ptr %l97, !tbaa !24
  %t193 = load i64, ptr %l98, !tbaa !24
  %t194 = icmp sle i64 %t192, %t193
  br i1 %t194, label %bb58, label %bb59
bb57:
  call void @__olang_check_failed(ptr @olang_loc_e09c8d310c475dd1_b9a5b78f48e38cfd)
  unreachable
bb58:
  %t196 = getelementptr { i64, ptr }, ptr %l94, i32 0, i32 1
  %t197 = load ptr, ptr %t196, !tbaa !27
  %t198 = load i64, ptr %l97, !tbaa !24
  %t199 = getelementptr i8, ptr %t197, i64 6
  %t200 = sub i64 %t198, 6
  %t201 = insertvalue { i64, ptr } undef, i64 %t200, 0
  %t202 = insertvalue { i64, ptr } %t201, ptr %t199, 1
  %t204 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s11, { i64, ptr } %t202, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d230, i32 0, i32 1) })
  store i1 %t204, ptr %l103
  br label %bb60
bb59:
  call void @__olang_check_failed(ptr @olang_loc_e09c8d310c475dd1_b9a5b78f48e38cfd)
  unreachable
bb60:
  %t205 = load i1, ptr %l103, !tbaa !21
  %t206 = load ptr, ptr %lp12
  %t207 = getelementptr %"compiler/emit:Reused", ptr %t206, i32 0, i32 5
  store i1 %t205, ptr %t207, !tbaa !21
  call void @__olang_scope_close(ptr %s11)
  br label %bb107
bb61:
  %t208 = load i1, ptr %l105, !tbaa !21
  br i1 %t208, label %bb62, label %bb63
bb62:
  %t209 = load ptr, ptr %lp12
  %t210 = getelementptr %"compiler/emit:Reused", ptr %t209, i32 0, i32 6
  store ptr %t210, ptr %l106, !tbaa !29
  %t211 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t211, ptr %l107, !tbaa !27
  %t212 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t215 = extractvalue { i64, ptr } %t212, 0
  store i64 %t215, ptr %l110, !tbaa !24
  %t216 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t217 = extractvalue { i64, ptr } %t216, 0
  store i64 %t217, ptr %l111, !tbaa !24
  %t218 = icmp sge i64 5, 0
  br i1 %t218, label %bb64, label %bb65
bb63:
  store %olang.scope zeroinitializer, ptr %s15
  %t220 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t222 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s2, ptr %s15, { i64, ptr } %t220, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d231, i32 0, i32 1) })
  store i1 %t222, ptr %l119
  br label %bb71
bb64:
  %t223 = load i64, ptr %l110, !tbaa !24
  %t224 = icmp sle i64 5, %t223
  br i1 %t224, label %bb66, label %bb67
bb65:
  call void @__olang_check_failed(ptr @olang_loc_b7226a2473daafee_95f7e6f063520982)
  unreachable
bb66:
  %t226 = load i64, ptr %l110, !tbaa !24
  %t227 = load i64, ptr %l111, !tbaa !24
  %t228 = icmp sle i64 %t226, %t227
  br i1 %t228, label %bb68, label %bb69
bb67:
  call void @__olang_check_failed(ptr @olang_loc_b7226a2473daafee_95f7e6f063520982)
  unreachable
bb68:
  %t230 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t231 = load ptr, ptr %t230, !tbaa !27
  %t232 = load i64, ptr %l110, !tbaa !24
  %t233 = getelementptr i8, ptr %t231, i64 5
  %t234 = sub i64 %t232, 5
  %t235 = insertvalue { i64, ptr } undef, i64 %t234, 0
  %t236 = insertvalue { i64, ptr } %t235, ptr %t233, 1
  %t238 = extractvalue { i64, ptr } %t236, 1
  %t239 = extractvalue { i64, ptr } %t236, 0
  %t240 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t239)
  call void @olang_textcopy(ptr %t240, ptr %t238, i64 %t239)
  %t241 = insertvalue { i64, ptr } undef, i64 %t239, 0
  %t242 = insertvalue { i64, ptr } %t241, ptr %t240, 1
  %t244 = extractvalue { i64, ptr } %t242, 0
  %t245 = extractvalue { i64, ptr } %t242, 1
  %t246 = mul i64 %t244, 1
  %t247 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t246)
  call void @llvm.memcpy.p0.p0.i64(ptr %t247, ptr %t245, i64 %t246, i1 false)
  %t248 = insertvalue { i64, ptr } undef, i64 %t244, 0
  %t249 = insertvalue { i64, ptr } %t248, ptr %t247, 1
  %t250 = load ptr, ptr %l106, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v3, ptr %v3, ptr %t250, { i64, ptr } %t249)
  br label %bb70
bb69:
  call void @__olang_check_failed(ptr @olang_loc_b7226a2473daafee_95f7e6f063520982)
  unreachable
bb70:
  br label %bb106
bb71:
  %t252 = load i1, ptr %l119, !tbaa !21
  br i1 %t252, label %bb72, label %bb73
bb72:
  store i1 true, ptr %l120, !tbaa !21
  br label %bb75
bb73:
  %t253 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t255 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s2, ptr %s15, { i64, ptr } %t253, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d232, i32 0, i32 1) })
  store i1 %t255, ptr %l122
  br label %bb74
bb74:
  %t256 = load i1, ptr %l122, !tbaa !21
  store i1 %t256, ptr %l120, !tbaa !21
  br label %bb75
bb75:
  %t257 = load i1, ptr %l120, !tbaa !21
  br i1 %t257, label %bb76, label %bb77
bb76:
  store %olang.scope zeroinitializer, ptr %s16
  %t258 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t260 = extractvalue { i64, ptr } %t258, 0
  %t262 = icmp slt i64 %t260, 71
  br i1 %t262, label %bb78, label %bb79
bb77:
  br label %bb105
bb78:
  store i1 true, ptr %l126, !tbaa !21
  br label %bb80
bb79:
  %t264 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t264, ptr %l127, !tbaa !27
  %t265 = getelementptr { i64, ptr }, ptr %l127, i32 0, i32 1
  %t266 = load ptr, ptr %t265, !tbaa !27
  %t267 = getelementptr i8, ptr %t266, i64 69
  %t268 = load i8, ptr %t267, !tbaa !32
  %t270 = icmp ne i8 %t268, 32
  store i1 %t270, ptr %l126, !tbaa !21
  br label %bb80
bb80:
  %t272 = load i1, ptr %l126, !tbaa !21
  br i1 %t272, label %bb81, label %bb82
bb81:
  store i1 true, ptr %l130, !tbaa !21
  br label %bb85
bb82:
  %t273 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t273, ptr %l131, !tbaa !27
  %t274 = load ptr, ptr %lp12
  %t275 = getelementptr %"compiler/emit:Reused", ptr %t274, i32 0, i32 1
  %t277 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v3, ptr %t275)
  store i64 %t277, ptr %l133
  br label %bb83
bb83:
  %t278 = load { i64, ptr }, ptr %l131, !tbaa !27
  %t279 = extractvalue { i64, ptr } %t278, 1
  %t280 = extractvalue { i64, ptr } %t278, 0
  %t281 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d233, i32 0, i32 1) }, 1
  %t282 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d233, i32 0, i32 1) }, 0
  %t283 = add i64 %t280, %t282
  %t284 = load i64, ptr %l133, !tbaa !24
  %t285 = call i64 @__olang_fmt_i64(ptr null, i64 %t284)
  %t286 = add i64 %t283, %t285
  %t287 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d234, i32 0, i32 1) }, 1
  %t288 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d234, i32 0, i32 1) }, 0
  %t289 = add i64 %t286, %t288
  %t290 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t289)
  call void @olang_textcopy(ptr %t290, ptr %t279, i64 %t280)
  %t291 = getelementptr i8, ptr %t290, i64 %t280
  call void @olang_textcopy(ptr %t291, ptr %t281, i64 %t282)
  %t292 = getelementptr i8, ptr %t291, i64 %t282
  %t293 = call i64 @__olang_fmt_i64(ptr %t292, i64 %t284)
  %t294 = getelementptr i8, ptr %t292, i64 %t285
  call void @olang_textcopy(ptr %t294, ptr %t287, i64 %t288)
  %t295 = insertvalue { i64, ptr } undef, i64 %t289, 0
  %t296 = insertvalue { i64, ptr } %t295, ptr %t290, 1
  %t298 = extractvalue { i64, ptr } %t296, 0
  %t299 = extractvalue { i64, ptr } %t296, 1
  %t300 = mul i64 %t298, 1
  %t301 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t300)
  call void @llvm.memcpy.p0.p0.i64(ptr %t301, ptr %t299, i64 %t300, i1 false)
  %t302 = insertvalue { i64, ptr } undef, i64 %t298, 0
  %t303 = insertvalue { i64, ptr } %t302, ptr %t301, 1
  %t305 = call i1 @std_2fos_2eExists(ptr %s16, { i64, ptr } %t303)
  store i1 %t305, ptr %l136
  br label %bb84
bb84:
  %t306 = load i1, ptr %l136, !tbaa !21
  %t307 = xor i1 %t306, true
  store i1 %t307, ptr %l130, !tbaa !21
  br label %bb85
bb85:
  %t309 = load i1, ptr %l130, !tbaa !21
  br i1 %t309, label %bb86, label %bb87
bb86:
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s6)
  br label %bb111
bb87:
  br label %bb88
bb88:
  %t310 = load ptr, ptr %lp12
  %t311 = getelementptr %"compiler/emit:Reused", ptr %t310, i32 0, i32 3
  store ptr %t311, ptr %l138, !tbaa !29
  %t312 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t312, ptr %l139, !tbaa !27
  %t313 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t314 = extractvalue { i64, ptr } %t313, 0
  store i64 %t314, ptr %l140, !tbaa !24
  %t315 = icmp sge i64 5, 0
  br i1 %t315, label %bb89, label %bb90
bb89:
  %t317 = icmp sle i64 5, 69
  br i1 %t317, label %bb91, label %bb92
bb90:
  call void @__olang_check_failed(ptr @olang_loc_8b5a25ea6dff5deb_e266ef1e1aa7167f)
  unreachable
bb91:
  %t319 = load i64, ptr %l140, !tbaa !24
  %t320 = icmp sle i64 69, %t319
  br i1 %t320, label %bb93, label %bb94
bb92:
  call void @__olang_check_failed(ptr @olang_loc_8b5a25ea6dff5deb_e266ef1e1aa7167f)
  unreachable
bb93:
  %t322 = getelementptr { i64, ptr }, ptr %l139, i32 0, i32 1
  %t323 = load ptr, ptr %t322, !tbaa !27
  %t324 = getelementptr i8, ptr %t323, i64 5
  %t325 = sub i64 69, 5
  %t326 = insertvalue { i64, ptr } undef, i64 %t325, 0
  %t327 = insertvalue { i64, ptr } %t326, ptr %t324, 1
  %t329 = extractvalue { i64, ptr } %t327, 1
  %t330 = extractvalue { i64, ptr } %t327, 0
  %t331 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t330)
  call void @olang_textcopy(ptr %t331, ptr %t329, i64 %t330)
  %t332 = insertvalue { i64, ptr } undef, i64 %t330, 0
  %t333 = insertvalue { i64, ptr } %t332, ptr %t331, 1
  %t335 = extractvalue { i64, ptr } %t333, 0
  %t336 = extractvalue { i64, ptr } %t333, 1
  %t337 = mul i64 %t335, 1
  %t338 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t337)
  call void @llvm.memcpy.p0.p0.i64(ptr %t338, ptr %t336, i64 %t337, i1 false)
  %t339 = insertvalue { i64, ptr } undef, i64 %t335, 0
  %t340 = insertvalue { i64, ptr } %t339, ptr %t338, 1
  %t341 = load ptr, ptr %l138, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v3, ptr %v3, ptr %t341, { i64, ptr } %t340)
  br label %bb95
bb94:
  call void @__olang_check_failed(ptr @olang_loc_8b5a25ea6dff5deb_e266ef1e1aa7167f)
  unreachable
bb95:
  %t343 = load ptr, ptr %lp12
  %t344 = getelementptr %"compiler/emit:Reused", ptr %t343, i32 0, i32 1
  store ptr %t344, ptr %l147, !tbaa !29
  %t345 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t345, ptr %l148, !tbaa !27
  %t346 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t349 = extractvalue { i64, ptr } %t346, 0
  store i64 %t349, ptr %l151, !tbaa !24
  %t350 = load { i64, ptr }, ptr %l148, !tbaa !27
  %t351 = extractvalue { i64, ptr } %t350, 0
  store i64 %t351, ptr %l152, !tbaa !24
  %t352 = icmp sge i64 70, 0
  br i1 %t352, label %bb96, label %bb97
bb96:
  %t354 = load i64, ptr %l151, !tbaa !24
  %t355 = icmp sle i64 70, %t354
  br i1 %t355, label %bb98, label %bb99
bb97:
  call void @__olang_check_failed(ptr @olang_loc_ba89f34926a12070_1be1301c9cbce214)
  unreachable
bb98:
  %t357 = load i64, ptr %l151, !tbaa !24
  %t358 = load i64, ptr %l152, !tbaa !24
  %t359 = icmp sle i64 %t357, %t358
  br i1 %t359, label %bb100, label %bb101
bb99:
  call void @__olang_check_failed(ptr @olang_loc_ba89f34926a12070_1be1301c9cbce214)
  unreachable
bb100:
  %t361 = getelementptr { i64, ptr }, ptr %l148, i32 0, i32 1
  %t362 = load ptr, ptr %t361, !tbaa !27
  %t363 = load i64, ptr %l151, !tbaa !24
  %t364 = getelementptr i8, ptr %t362, i64 70
  %t365 = sub i64 %t363, 70
  %t366 = insertvalue { i64, ptr } undef, i64 %t365, 0
  %t367 = insertvalue { i64, ptr } %t366, ptr %t364, 1
  %t369 = extractvalue { i64, ptr } %t367, 1
  %t370 = extractvalue { i64, ptr } %t367, 0
  %t371 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t370)
  call void @olang_textcopy(ptr %t371, ptr %t369, i64 %t370)
  %t372 = insertvalue { i64, ptr } undef, i64 %t370, 0
  %t373 = insertvalue { i64, ptr } %t372, ptr %t371, 1
  %t375 = extractvalue { i64, ptr } %t373, 0
  %t376 = extractvalue { i64, ptr } %t373, 1
  %t377 = mul i64 %t375, 1
  %t378 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t377)
  call void @llvm.memcpy.p0.p0.i64(ptr %t378, ptr %t376, i64 %t377, i1 false)
  %t379 = insertvalue { i64, ptr } undef, i64 %t375, 0
  %t380 = insertvalue { i64, ptr } %t379, ptr %t378, 1
  %t381 = load ptr, ptr %l147, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v3, ptr %v3, ptr %t381, { i64, ptr } %t380)
  br label %bb102
bb101:
  call void @__olang_check_failed(ptr @olang_loc_ba89f34926a12070_1be1301c9cbce214)
  unreachable
bb102:
  %t383 = load ptr, ptr %lp12
  %t384 = getelementptr %"compiler/emit:Reused", ptr %t383, i32 0, i32 2
  store ptr %t384, ptr %l159, !tbaa !29
  %t385 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t387 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s2, ptr %s16, { i64, ptr } %t385, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d235, i32 0, i32 1) })
  store i1 %t387, ptr %l161
  br label %bb103
bb103:
  %t388 = load ptr, ptr %l159, !tbaa !29
  %t389 = load i1, ptr %l161, !tbaa !21
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %v3, ptr %t388, i1 %t389)
  br label %bb104
bb104:
  call void @__olang_scope_close(ptr %s16)
  br label %bb105
bb105:
  call void @__olang_scope_close(ptr %s15)
  br label %bb106
bb106:
  call void @__olang_scope_close(ptr %s12)
  br label %bb107
bb107:
  call void @__olang_scope_close(ptr %s10)
  br label %bb108
bb108:
  call void @__olang_scope_close(ptr %s8)
  br label %bb109
bb109:
  call void @__olang_scope_close(ptr %s6)
  br label %bb110
bb110:
  br label %bb26
bb111:
  %t390 = load i1, ptr %l13, !tbaa !21
  br i1 %t390, label %bb112, label %bb113
bb112:
  %t392 = load ptr, ptr %lp12
  %t393 = getelementptr %"compiler/emit:Reused", ptr %t392, i32 0, i32 1
  %t395 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v3, ptr %t393)
  store i64 %t395, ptr %l165
  br label %bb114
bb113:
  store i1 false, ptr %l163, !tbaa !21
  br label %bb115
bb114:
  %t396 = load i64, ptr %l165, !tbaa !24
  %t397 = icmp sgt i64 %t396, 0
  store i1 %t397, ptr %l163, !tbaa !21
  br label %bb115
bb115:
  %t399 = load i1, ptr %l163, !tbaa !21
  br i1 %t399, label %bb116, label %bb117
bb116:
  %t400 = load ptr, ptr %lp3
  %t401 = load ptr, ptr %lp12
  %t402 = load %"compiler/emit:Reused", ptr %t401
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aReused_3e_2ePush_3ccompiler_2femit_3aReused_3e(ptr %v3, ptr %v3, ptr %t400, %"compiler/emit:Reused" %t402)
  br label %bb118
bb117:
  br label %bb119
bb118:
  br label %bb119
bb119:
  call void @__olang_scope_close(ptr %s2)
  br label %bb120
bb120:
  %t405 = load i64, ptr %l8, !tbaa !24
  %t407 = add i64 %t405, 1
  store i64 %t407, ptr %l8, !tbaa !24
  br label %bb8
bb121:
  %t409 = load ptr, ptr %lp3
  %t410 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t409
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t410, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local i1 @compiler_2folang_2eroomFor(i64 %a0) #0 {
entry:
  %l1 = alloca [2 x i64]
  %l6 = alloca i32
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = insertvalue [2 x i64] undef, i64 0, 0
  %t2 = insertvalue [2 x i64] %t1, i64 0, 1
  store [2 x i64] %t2, ptr %l1
  %t5 = insertvalue { i64, ptr } undef, i64 2, 0
  %t6 = insertvalue { i64, ptr } %t5, ptr %l1, 1
  %t9 = extractvalue { i64, ptr } %t6, 1
  %t10 = extractvalue { i64, ptr } %t6, 0
  %t11 = call i32 @getrlimit(i32 9, ptr %t9)
  store i32 %t11, ptr %l6
  br label %bb1
bb1:
  %t12 = load i32, ptr %l6, !tbaa !23
  %t13 = icmp ne i32 %t12, 0
  br i1 %t13, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t16 = getelementptr [2 x i64], ptr %l1, i64 0, i64 0
  %t17 = load i64, ptr %t16, !tbaa !85
  %t22 = icmp ugt i64 %t17, %a0
  store i1 %t22, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2folang_2esaid(ptr %v0, ptr %a0) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l4 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v0, ptr %s0, ptr %a0)
  store { i64, ptr } %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t4, 0
  %t6 = extractvalue { i64, ptr } %t4, 1
  %t7 = mul i64 %t5, 1
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @llvm.memcpy.p0.p0.i64(ptr %t8, ptr %t6, i64 %t7, i1 false)
  %t9 = insertvalue { i64, ptr } undef, i64 %t5, 0
  %t10 = insertvalue { i64, ptr } %t9, ptr %t8, 1
  %t12 = call i32 @compiler_2folang_2ewrite(ptr %s0, { i64, ptr } %t10)
  store i32 %t12, ptr %l4
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2folang_2eusage(ptr %v0, ptr %v1, ptr %a0, %"compiler/msgs:Msg" %a1) #0 {
entry:
  %l5 = alloca i64
  %rv = alloca i32
  %t2 = alloca { i64, [3 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  store { i64, [3 x i64] } zeroinitializer, ptr %t2
  %t3 = getelementptr { i64, [3 x i64] }, ptr %t2, i32 0, i32 0
  store i64 0, ptr %t3
  %t4 = load { i64, [3 x i64] }, ptr %t2
  %t9 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %t4, %"compiler/msgs:Msg" %a1)
  store i64 %t9, ptr %l5
  br label %bb1
bb1:
  store i32 65536, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2folang_2ewrite(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l2 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i32 @std_2fio_2ePrint(ptr %v0, { i64, ptr } %a0)
  store i32 %t3, ptr %l2
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  br label %bb1
bb1:
  br label %bb6
bb2:
  %t6 = load i32, ptr %l2, !tbaa !23
  %t7 = ashr i32 %t6, 16
  %t9 = icmp eq i32 %t7, 1
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_524754f243909c7f_c56b4bf250637b8b)
  unreachable
bb5:
  call void @__olang_ert_req_clear()
  store i32 1, ptr %rv
  br label %ret
bb6:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"compiler/olang:CommandLine" @compiler_2folang_3aCommandLine_2ector(ptr %v0) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i1
  %l4 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l11 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/olang:CommandLine"
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l0, !tbaa !24
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l10
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l1
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d236, i32 0, i32 1) }, ptr %l2, !tbaa !27
  store i1 false, ptr %l3, !tbaa !21
  %t3 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l11
  br label %bb2
bb2:
  %t4 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %l4
  %t5 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, ptr %l12
  br label %bb3
bb3:
  %t6 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l12
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d237, i32 0, i32 1) }, ptr %l6, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d238, i32 0, i32 1) }, ptr %l7, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d239, i32 0, i32 1) }, ptr %l9, !tbaa !27
  %t7 = load i64, ptr %l0, !tbaa !24
  %t8 = insertvalue %"compiler/olang:CommandLine" undef, i64 %t7, 0
  %t9 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l1
  %t10 = insertvalue %"compiler/olang:CommandLine" %t8, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t9, 1
  %t11 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = insertvalue %"compiler/olang:CommandLine" %t10, { i64, ptr } %t11, 2
  %t13 = load i1, ptr %l3, !tbaa !21
  %t14 = insertvalue %"compiler/olang:CommandLine" %t12, i1 %t13, 3
  %t15 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l4
  %t16 = insertvalue %"compiler/olang:CommandLine" %t14, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, 4
  %t18 = insertvalue %"compiler/olang:CommandLine" %t16, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t6, 5
  %t19 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t20 = insertvalue %"compiler/olang:CommandLine" %t18, { i64, ptr } %t19, 6
  %t21 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t22 = insertvalue %"compiler/olang:CommandLine" %t20, { i64, ptr } %t21, 7
  %t24 = insertvalue %"compiler/olang:CommandLine" %t22, i1 false, 8
  %t25 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t26 = insertvalue %"compiler/olang:CommandLine" %t24, { i64, ptr } %t25, 9
  store %"compiler/olang:CommandLine" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/olang:CommandLine", ptr %rv
  ret %"compiler/olang:CommandLine" %rr
}

define dso_local %"compiler/olang:Passes" @compiler_2folang_3aPasses_2ector(ptr %v0) #0 {
entry:
  %rv = alloca %"compiler/olang:Passes"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = insertvalue %"compiler/olang:Passes" undef, i64 0, 0
  store %"compiler/olang:Passes" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/olang:Passes", ptr %rv
  ret %"compiler/olang:Passes" %rr
}

define i32 @main(i32 %argc, ptr %argv) #0 {
entry:
  store i32 %argc, ptr @__olang_argc
  store ptr %argv, ptr @__olang_argv
  call void @__olang_thread_init()
  call void @std_2ffilepath_2elivePath_2einit()
  call void @compiler_2fbuild_2ePhaseAt_2einit()
  call void @compiler_2folang_2emain()
  ret i32 0
}

define dso_local void @olang_2einit_2ecompiler_2folang() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2folang_2eModeWords_2einit()
  br label %bb1
bb1:
  call void @compiler_2folang_2eRun_2einit()
  br label %bb2
bb2:
  call void @compiler_2folang_2eBuild_2einit()
  br label %bb3
bb3:
  call void @compiler_2folang_2eCompile_2einit()
  br label %bb4
bb4:
  call void @compiler_2folang_2eTest_2einit()
  br label %bb5
bb5:
  call void @compiler_2folang_2eInterp_2einit()
  br label %bb6
bb6:
  call void @compiler_2folang_2eFormat_2einit()
  br label %bb7
bb7:
  call void @compiler_2folang_2eExplain_2einit()
  br label %bb8
bb8:
  call void @compiler_2folang_2eHelp_2einit()
  br label %bb9
bb9:
  call void @compiler_2folang_2eDoc_2einit()
  br label %bb10
bb10:
  call void @compiler_2folang_2eLsp_2einit()
  br label %bb11
bb11:
  call void @compiler_2folang_2eMcp_2einit()
  br label %bb12
bb12:
  call void @compiler_2folang_2eFix_2einit()
  br label %bb13
bb13:
  call void @compiler_2folang_2eBindgen_2einit()
  br label %bb14
bb14:
  call void @compiler_2folang_2eModeUsage_2einit()
  br label %bb15
bb15:
  call void @compiler_2folang_2eModeWhat_2einit()
  br label %bb16
bb16:
  call void @compiler_2folang_2eOptWords_2einit()
  br label %bb17
bb17:
  call void @compiler_2folang_2eOptValues_2einit()
  br label %bb18
bb18:
  call void @compiler_2folang_2eOptModes_2einit()
  br label %bb19
bb19:
  call void @compiler_2folang_2eOptWhat_2einit()
  br label %bb20
bb20:
  call void @compiler_2folang_2eexplainedSrc_2einit()
  br label %bb21
bb21:
  br label %ret
ret:
  ret void
}

@.d0 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c"olang [OPTION...] FILE.olang [ARGUMENT...]" }>, align 8
@.d1 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c"olang build [OPTION...] FILE.olang" }>, align 8
@.d2 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"olang compile [OPTION...] FILE.olang" }>, align 8
@.d3 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"olang test [OPTION...] FILE.olang..." }>, align 8
@.d4 = private constant <{ i64, [52 x i8] }> <{ i64 0, [52 x i8] c"olang interpret [OPTION...] FILE.olang [ARGUMENT...]" }>, align 8
@.d5 = private constant <{ i64, [38 x i8] }> <{ i64 0, [38 x i8] c"olang format [OPTION...] FILE.olang..." }>, align 8
@.d6 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"olang explain RULE | FILE.olang NAME" }>, align 8
@.d7 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"olang help [MODE]" }>, align 8
@.d8 = private constant <{ i64, [67 x i8] }> <{ i64 0, [67 x i8] c"olang doc [OPTION...] FILE.olang [NAME] | -html DIR [FILE.olang...]" }>, align 8
@.d9 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"olang lsp [OPTION...]" }>, align 8
@.d10 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"olang mcp [OPTION...]" }>, align 8
@.d11 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c"olang fix [OPTION...] FILE.olang|DIR..." }>, align 8
@.d12 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c"olang bindgen [OPTION...] HEADER.h" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d13 = private constant <{ i64, [106 x i8] }> <{ i64 0, [106 x i8] c"builds the program FILE.olang is the root of, as build does, and runs it with the arguments after the file" }>, align 8
@.d14 = private constant <{ i64, [64 x i8] }> <{ i64 0, [64 x i8] c"builds one program, FILE.olang its root module, into build/ (B3)" }>, align 8
@.d15 = private constant <{ i64, [54 x i8] }> <{ i64 0, [54 x i8] c"compiles one module to an object, linking nothing (B2)" }>, align 8
@.d16 = private constant <{ i64, [62 x i8] }> <{ i64 0, [62 x i8] c"runs each file's test blocks, each file built on its own (B3a)" }>, align 8
@.d17 = private constant <{ i64, [110 x i8] }> <{ i64 0, [110 x i8] c"runs the program by compile-time evaluation instead of building it, the arguments after the file its own (B3e)" }>, align 8
@.d18 = private constant <{ i64, [46 x i8] }> <{ i64 0, [46 x i8] c"rewrites each file in olang's one layout (B13)" }>, align 8
@.d19 = private constant <{ i64, [93 x i8] }> <{ i64 0, [93 x i8] c"prints a rule of the specification (B11a), or a top-level item as the compiler sees it (B11b)" }>, align 8
@.d20 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"lists the modes, or a mode's options" }>, align 8
@.d21 = private constant <{ i64, [68 x i8] }> <{ i64 0, [68 x i8] c"prints a module's documentation (B14), or writes a library's as HTML" }>, align 8
@.d22 = private constant <{ i64, [87 x i8] }> <{ i64 0, [87 x i8] c"serves the Language Server Protocol on the standard input and output, for editors (B15)" }>, align 8
@.d23 = private constant <{ i64, [84 x i8] }> <{ i64 0, [84 x i8] c"serves the Model Context Protocol on the standard input and output, for agents (B16)" }>, align 8
@.d24 = private constant <{ i64, [116 x i8] }> <{ i64 0, [116 x i8] c"rewrites old code to the language of today: every migration tool of tools/, in the order the changes were made (B17)" }>, align 8
@.d25 = private constant <{ i64, [76 x i8] }> <{ i64 0, [76 x i8] c"writes a C header's declarations as olang declares them, read by clang (X16)" }>, align 8
@.d26 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d27 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"build" }>, align 8
@.d28 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"compile" }>, align 8
@.d29 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"test" }>, align 8
@.d30 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"interpret" }>, align 8
@.d31 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"format" }>, align 8
@.d32 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"explain" }>, align 8
@.d33 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"help" }>, align 8
@.d34 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"doc" }>, align 8
@.d35 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"lsp" }>, align 8
@.d36 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"mcp" }>, align 8
@.d37 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fix" }>, align 8
@.d38 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"bindgen" }>, align 8
@.d39 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"PATH" }>, align 8
@.d40 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d41 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d42 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d43 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"NAME" }>, align 8
@.d44 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"Name=value" }>, align 8
@.d45 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d46 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d47 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d48 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"DIR" }>, align 8
@.d49 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d50 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d51 = private constant <{ i64, [78 x i8] }> <{ i64 0, [78 x i8] c"writes the executable, the object or bindgen's declarations to PATH (B3h, X16)" }>, align 8
@.d52 = private constant <{ i64, [53 x i8] }> <{ i64 0, [53 x i8] c"builds unoptimized, with debug information (B2c, B2e)" }>, align 8
@.d53 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"builds with the data race detector (B2b)" }>, align 8
@.d54 = private constant <{ i64, [37 x i8] }> <{ i64 0, [37 x i8] c"builds with the scope sanitizer (B2f)" }>, align 8
@.d55 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"builds for another machine (B12)" }>, align 8
@.d56 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"defines a build constant (B10)" }>, align 8
@.d57 = private constant <{ i64, [85 x i8] }> <{ i64 0, [85 x i8] c"moves the remote repositories the build reaches to their refs' current commits (M23c)" }>, align 8
@.d58 = private constant <{ i64, [89 x i8] }> <{ i64 0, [89 x i8] c"rewrites nothing: lists each file not in the layout (B13), or that fix would change (B17)" }>, align 8
@.d59 = private constant <{ i64, [96 x i8] }> <{ i64 0, [96 x i8] c"builds for development: -O2 without link-time optimization, faster to build, slower to run (B2g)" }>, align 8
@.d60 = private constant <{ i64, [109 x i8] }> <{ i64 0, [109 x i8] c"writes the documentation as HTML into DIR, a page a module: of each FILE, or of std where none is named (B14)" }>, align 8
@.d61 = private constant <{ i64, [83 x i8] }> <{ i64 0, [83 x i8] c"builds a shared library libNAME.so of the export fns, and its C header NAME.h (X14)" }>, align 8
@.d62 = private constant <{ i64, [88 x i8] }> <{ i64 0, [88 x i8] c"reports the places that keep what they let go of until their scope closes, and why (B18)" }>, align 8
@.d63 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"-output" }>, align 8
@.d64 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"-debug" }>, align 8
@.d65 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"-race" }>, align 8
@.d66 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"-sanitize" }>, align 8
@.d67 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"-target" }>, align 8
@.d68 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"-define" }>, align 8
@.d69 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"-update" }>, align 8
@.d70 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"-check" }>, align 8
@.d71 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"-quick" }>, align 8
@.d72 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"-html" }>, align 8
@.d73 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"-library" }>, align 8
@.d74 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"-memory" }>, align 8
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d75 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"-" }>, align 8
@.d76 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"-" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d77 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d78 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @__olang_ert_req_clear()
@.d79 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"-debug" }>, align 8
@.d80 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"-race" }>, align 8
@.d81 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d82 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d83 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d84 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"OLANG_OBJECTS" }>, align 8
@.d85 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d86 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d87 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"/proc/self/exe" }>, align 8
@.d88 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @__olang_check_failed(ptr)
@.d89 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d90 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d91 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d92 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.c93 = private unnamed_addr constant [5 x i8] c"true\00"
@.c94 = private unnamed_addr constant [6 x i8] c"false\00"
@.d95 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"TargetOs" }>, align 8
@.d96 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"TargetArch" }>, align 8
@.d97 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"TargetCpu" }>, align 8
@.d98 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"TargetVectorBits" }>, align 8
@.d99 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"TargetHasFma" }>, align 8
@.d100 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"DebugBuild" }>, align 8
@.d101 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"RaceBuild" }>, align 8
@.d102 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"TestBuild" }>, align 8
@.d103 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d104 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"olang: reuse check: " }>, align 8
@.d105 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" differs\0A" }>, align 8
@.d106 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"olang: reuse check: " }>, align 8
@.d107 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" objects, " }>, align 8
@.d108 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c" written afresh\0A" }>, align 8
@.d109 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"olang: reuse check: " }>, align 8
@.d110 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c" modules reused, every object the same\0A" }>, align 8
@.d111 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"start" }>, align 8
@.d112 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"load" }>, align 8
@.d113 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"check" }>, align 8
@.d114 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"evaluate" }>, align 8
@.d115 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"scope" }>, align 8
@.d116 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"OLANG_FREEDUMP" }>, align 8
@.d117 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d118 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d119 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"lower+emit" }>, align 8
@.d120 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"it does not emit " }>, align 8
@.d121 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" yet" }>, align 8
@.d122 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c": it does not lower " }>, align 8
@.d123 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" yet" }>, align 8
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d124 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".p" }>, align 8
@.d125 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c".ll" }>, align 8
@.d126 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"its record " }>, align 8
@.d127 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c" was lost while it was read" }>, align 8
@.d128 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"@__olang_dyncall" }>, align 8
@.d129 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d130 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"@__olang_dyncall" }>, align 8
@.d131 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"OLANG_CHECKREUSE" }>, align 8
@.d132 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d133 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define available_externally void @__olang_scope_escape(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %un = icmp eq ptr %o, null
  br i1 %un, label %claim, label %done
claim:
  %me = load ptr, ptr @__olang_self
  store atomic ptr %me, ptr %op monotonic, align 8
  br label %done
done:
  ret void
}
define internal { i64, ptr } @olang_lambda_134(ptr %env, ptr %v0, i64 %a0) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  %cp0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  %vq0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eInstNote(ptr %vc0, ptr %v0, ptr %cv0, i64 %a0)
  store { i64, ptr } %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t6, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define internal { i64, ptr } @olang_lambda_135(ptr %env, ptr %v0, i32 %a0) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  %cp0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  %vq0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %vc0, ptr %v0, ptr %cv0, i32 %a0)
  store { i64, ptr } %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t6, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

@.d136 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d137 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-l" }>, align 8
@.d138 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @abort() noreturn
@.d139 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"sanitize_thread " }>, align 8
@.d140 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d141 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
@.d142 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"type MathError error { ZERO }\0A" }>, align 8
@.d143 = private constant <{ i64, [43 x i8] }> <{ i64 0, [43 x i8] c"type N struct(v I64, next N?&) { v, next }\0A" }>, align 8
@.d144 = private constant <{ i64, [37 x i8] }> <{ i64 0, [37 x i8] c"fn (n N&) Value() I64 { return n.v }\0A" }>, align 8
@.d145 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"type H struct(n N&) { n }\0A" }>, align 8
@.d146 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"fn wrap(n N&) H { return H(n) }\0A" }>, align 8
@.d147 = private constant <{ i64, [37 x i8] }> <{ i64 0, [37 x i8] c"fn divmod(a I64, b I64) I64, I64 ? {\0A" }>, align 8
@.d148 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c"    if b == 0 { error MathError.ZERO }\0A" }>, align 8
@.d149 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"    return a / b, a % b\0A" }>, align 8
@.d150 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"}\0A" }>, align 8
@.d151 = private constant <{ i64, [51 x i8] }> <{ i64 0, [51 x i8] c"fn big<T>(a T, b T) T { return a if a > b else b }\0A" }>, align 8
@.d152 = private constant <{ i64, [62 x i8] }> <{ i64 0, [62 x i8] c"type Sh enum {\0A    Whole N\0A    Parts(a I64, b I64)\0A    None\0A}\0A" }>, align 8
@.d153 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"Answer I64 = 6 * 7\0A" }>, align 8
@.d154 = private constant <{ i64, [85 x i8] }> <{ i64 0, [85 x i8] c"fn pct(part I64, whole I64) [whole > 0, part >= 0] I64 { return part * 100 / whole }\0A" }>, align 8
@.d155 = private constant <{ i64, [43 x i8] }> <{ i64 0, [43 x i8] c"fn link(a mut N&, b N&) [b outlives a] { }\0A" }>, align 8
@.d156 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"fn main() ? {\0A" }>, align 8
@.d157 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"    nn := N(pct(1, 4)!, null)\0A" }>, align 8
@.d158 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"    link(nn, nn)\0A" }>, align 8
@.d159 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c"    q, _ := try divmod(Answer, big(2, 3))\0A" }>, align 8
@.d160 = private constant <{ i64, [44 x i8] }> <{ i64 0, [44 x i8] c"    assert wrap(N(q, null)).n.Value() == 14\0A" }>, align 8
@.d161 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-l" }>, align 8
@.d162 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-f" }>, align 8
@.d163 = private constant <{ i64, [96 x i8] }> <{ i64 0, [96 x i8] c"usage: olang MODE [OPTION...] FILE...   or   olang [OPTION...] FILE.olang [ARGUMENT...]\0A\0Amodes:\0A" }>, align 8
@.d164 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"FILE.olang" }>, align 8
@.d165 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d166 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d167 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d168 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d169 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d170 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d171 = private constant <{ i64, [85 x i8] }> <{ i64 0, [85 x i8] c"\0A'olang help MODE' lists a mode's options; 'olang help run' those of running a file.\0A" }>, align 8
@.d172 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"run" }>, align 8
@.d173 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"usage: " }>, align 8
@.d174 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d175 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"\0Aoptions:\0A" }>, align 8
@.d176 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d177 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d178 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d179 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d180 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d181 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d182 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"/rec" }>, align 8
@.d183 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d184 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"1" }>, align 8
@.d185 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"0" }>, align 8
@.d186 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"olang module record\0Asize " }>, align 8
@.d187 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"\0Asplit " }>, align 8
@.d188 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d189 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"inst " }>, align 8
@.d190 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d191 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".p" }>, align 8
@.d192 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c".ll" }>, align 8
@.d193 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"locs " }>, align 8
@.d194 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"part " }>, align 8
@.d195 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d196 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d197 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"end\0A" }>, align 8
@.d198 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"thread_local(initialexec)" }>, align 8
@.d199 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"thread_local" }>, align 8
@.d200 = private constant <{ i64, [97 x i8] }> <{ i64 0, [97 x i8] c"olang: internal compiler error: the compiler crashed - a bug in the compiler, not in the program\0A" }>, align 8
define internal void @olang_lambda_201(ptr %env) #0 {
entry:
  %l2 = alloca i32
  %cp0 = getelementptr { { i64, ptr }, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load { i64, ptr }, ptr %cp0, !tbaa !28
  %vq0 = getelementptr { { i64, ptr }, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i32 @compiler_2folang_2edrive(ptr %vc0, { i64, ptr } %cv0)
  store i32 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i32, ptr %l2, !tbaa !23
  call void @std_2fos_2eExit(i32 %t4)
  unreachable
bb2:
  call void @__olang_check_failed(ptr @olang_loc_6a9437d164e18f65_777063661d50beb9)
  unreachable
ret:
  ret void
}

@.d202 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"running a file" }>, align 8
@.d203 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" and " }>, align 8
@.d204 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d205 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d206 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d207 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d208 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"\0Aroot " }>, align 8
@.d209 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d210 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d211 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d212 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"embed " }>, align 8
@.d213 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define internal i1 @olang_lambda_214(ptr %env, i64 %a0, i64 %a1) #0 {
entry:
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = icmp slt i64 %a0, %a1
  store i1 %t5, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d215 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
define internal { i64, ptr } @olang_lambda_216(ptr %env, ptr %v0, i64 %a0) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  %cp0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  %vq0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eInstNote(ptr %vc0, ptr %v0, ptr %cv0, i64 %a0)
  store { i64, ptr } %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t6, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define internal { i64, ptr } @olang_lambda_217(ptr %env, ptr %v0, i32 %a0) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  %cp0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  %vq0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %vc0, ptr %v0, ptr %cv0, i32 %a0)
  store { i64, ptr } %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t6, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

@.d218 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"OLANG_FREEDUMP" }>, align 8
@.d219 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d220 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d221 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d222 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c".tmp" }>, align 8
@.d223 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"/rec/" }>, align 8
@.d224 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aReused_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2femit_3aReused_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d225 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d226 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"end" }>, align 8
@.d227 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"size " }>, align 8
@.d228 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"split " }>, align 8
@.d229 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"inst " }>, align 8
@.d230 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"1" }>, align 8
@.d231 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"part " }>, align 8
@.d232 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"locs " }>, align 8
@.d233 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".p" }>, align 8
@.d234 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c".ll" }>, align 8
@.d235 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"locs " }>, align 8
declare i32 @getrlimit(i32, ptr)
@.d236 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d237 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"native" }>, align 8
@.d238 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d239 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@__olang_argc = external global i32
@__olang_argv = external global ptr
declare void @__olang_thread_init()
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@__olang_self = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
declare ptr @__olang_scope_mine_slow(ptr) noinline
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eUsage(ptr %v0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotAMode(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownFlag(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eOptionNotForMode(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eOptionNeedsValue(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eDefine(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, ptr %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eQuickAlone(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDocOneName(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eExplainNeedsRule(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eHelpOneMode(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eModeFirst(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotASource(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eExplainNeedsName(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eModeNoFiles(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eModeOneFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eModeNeedsFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2ftarget_2eFindClang(ptr %v0)
declare { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, %"compiler/target:Target" } @compiler_2ftarget_2eResolve(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, ptr %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetForeignMode(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, %"std/os:FileInfo" } @std_2fos_2eStat(ptr %v0, { i64, ptr } %a0)
@olang_loc_75a15dc32bd9c62d_7df2e713047d6551 = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fos_2eCwd(ptr %v0)
declare { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eFingerprint(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2fload_2eStdDir(ptr %v0)
declare i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eHas(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefineBuiltin(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eBuiltins(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, i64 %a4, i64 %a5, i1 %a6, i1 %a7, i1 %a8)
declare i1 @std_2fos_2eIsDir(ptr %v0, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eOutputIsDir(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_12131eae1fe55f7a_2d06b34e1c9e748e = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eOutputNoDir(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eLen_3cI64_2c_20I64_3e(ptr %v0, ptr %a0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2ecompiler_2femit_3aEmitter_2eObjects(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aObject_3e_2eLen_3ccompiler_2femit_3aObject_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2eLen_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %a0)
declare %"compiler/build:Unit" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2eAt_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/emit:Object" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aObject_3e_2eAt_3ccompiler_2femit_3aObject_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @std_2fio_2ePrintErr(ptr %v0, { i64, ptr } %a0)
@olang_loc_dd8573ae343ff812_8decdc106ea08ebe = external constant [0 x i8]
@olang_loc_1ac4aff2f4082213_2cf9008d871781bf = external constant [0 x i8]
declare void @std_2fos_2eExit(i32 %a0)
@olang_loc_32421bf44abb9df8_94a4451618780c84 = external constant [0 x i8]
@olang_loc_2cc05bc0974a48c9_c5f1014419607875 = external constant [0 x i8]
declare void @compiler_2fbuild_2ePhase(ptr %v0, { i64, ptr } %a0)
declare void @compiler_2finterp_2eAnalyze(ptr %out, ptr %v0, ptr %v1, ptr %a0, i1 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eCheckMain(ptr %v0, ptr %a0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v0, ptr %a0)
declare i64 @compiler_2finterp_2eDecideValues(ptr %v0, ptr %a0)
declare i64 @compiler_2finterp_2eDecideAsserts(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2finterp_2eBake(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHasFatal(ptr %v0, ptr %a0)
declare %"compiler/lower:Lowerer" @compiler_2flower_3aLowerer_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1)
declare { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2eReport(ptr %v0, ptr %v1, ptr %a0)
declare i32 @std_2fio_2ePrint(ptr %v0, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2eDump(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_1d5612d13136b02e_cf27d9d671de6fa2 = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3aGap_3e_2eLen_3ccompiler_2flower_3aGap_3e(ptr %v0, ptr %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fbuild_2eUnbuildable(ptr %v0, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3aGap_3e_2eRunFrom_3ccompiler_2flower_3aGap_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aObject_3e_2eRunFrom_3ccompiler_2femit_3aObject_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/emit:Reused" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aReused_3e_2eAt_3ccompiler_2femit_3aReused_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/build:Unit" @compiler_2fbuild_3aUnit_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, i32 %a1, { i64, ptr } %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2ePush_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/build:Unit" %a1)
@olang_loc_5772a8514d833044_b816e84cde98ab20 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fbuild_2eIrHash(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fload_2ecompiler_2fload_3aLoader_2eLinks(ptr %v0, ptr %v1, ptr %a0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2ecompiler_2femit_3aEmitter_2eExportNames(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2fbuild_2eLibName(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eHeader(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare { i32, { i64, ptr } } @compiler_2fruntime_2eIr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3, i1 %a4)
declare { i32, { i64, ptr } } @compiler_2fruntime_2eDyncallIr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3, i1 %a4)
declare void @compiler_2fscope_3aScoper_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eRun(ptr %v0, ptr %a0)
declare void @compiler_2finterp_3aExec_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1, i32 %a2)
declare { i32, { i64, ptr } } @compiler_2fexplain_2eItem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, i64 %a3, { i64, ptr } %a4)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eExplainNoItem(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare { i64, ptr } @compiler_2finterp_2eLoadLibrary(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_436dc8a09a076c49_2aa9a29c41caf045 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eInterpLink(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@G_2ecompiler_2feval_2eInterpCrash = external constant <{ [8 x i8], ptr }>
declare void @std_2fos_2eOnCrash(ptr %v0, { i64, ptr } %a0)
declare i32 @compiler_2finterp_2ecompiler_2finterp_3aExec_2eRunMain(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_d9ce39c2cb08642b_edb226294df0b2a7 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fload_2eLockPath(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2ffetch_2eCacheDir(ptr %v0)
declare { i64, ptr } @compiler_2ffetch_2eGitBase(ptr %v0)
declare %"compiler/fetch:Fetcher" @compiler_2ffetch_3aFetcher_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3, i1 %a4)
declare %"compiler/source:Names" @compiler_2fsource_3aNames_2ector(ptr %v0)
declare %"compiler/load:Loader" @compiler_2fload_3aLoader_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4)
declare i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eLoad(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v0, ptr %a0)
declare i32 @compiler_2folang_2eRunWith_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1)
declare void @compiler_2femit_3aEmitter_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, ptr %a3)
@G_2ecompiler_2fbuild_2eThinFrom = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\80\00\00\00\00\00" }>, align 8
@G_2ecompiler_2femit_2ePartSizeDev = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\08\00\00\00\00\00" }>, align 8
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fdiag_2eSpecPath(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoSpec(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @compiler_2fdiag_2eExplain(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_8c7e755ea0eb9876_6b14028370dd0cea = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eToUpper(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoRule(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hd4bdf3befe2f7a35847f168802c5df68(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2ffmt_2eFiles(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadEnd(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i8 %a2)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aReused_3e_2eLen_3ccompiler_2femit_3aReused_3e(ptr %v0, ptr %a0)
declare i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %a0)
@olang_loc_4bbc6d12b4c2aef5_61de3414d98ea881 = external constant [0 x i8]
declare i32 @compiler_2fbuild_2ePid()
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aReused_3e_2eRunFrom_3ccompiler_2femit_3aReused_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_1a6fb0e4b3da4304_63cb76792ee304f0 = external constant [0 x i8]
@olang_loc_b2c46c5c2279b83f_c4a092c9ae7cf92b = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H2b85ceff512af6e6ca26c554a1c16247(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i1 %a2)
declare { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare { i64, ptr } @std_2fos_2eArgs(ptr %v0)
declare void @std_2fos_2eRunOnStack(ptr %v0, i64 %a0, ptr %a1c, ptr %a1e)
@olang_loc_73b8d8bbbab8f911_f56ba933d304b59d = external constant [0 x i8]
@olang_loc_73c3116820f750d_32f9964414b76079 = external constant [0 x i8]
@olang_loc_23d2168bab4aeae0_126950dc9613ccec = external constant [0 x i8]
@olang_loc_a3d985a905b98e7d_1a99d62f9ee112a1 = external constant [0 x i8]
@olang_loc_28ebd020d3001495_4ad5579e3d579679 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fload_2ecompiler_2fload_3aLoader_2eEmbedded(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_68c6c1ff5359bbb9_e0dcea9ab8fa86cd = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2eRunFrom_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_3d75cb007153ac43_568e8d111effec1f = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1c, ptr %a1e)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_7d47a64265939568_77c8ba1e6120f9e4 = external constant [0 x i8]
declare void @compiler_2ffree_3aFree_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1, ptr %a2)
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eDecide(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1, i64 %a2, i1 %a3)
declare i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_525dfa3cfb0bfb03_4e25463d9369c1cf = external constant [0 x i8]
declare i32 @std_2fos_2eRename(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_8e0c0d4d9d5e4982_1d0736507b33918e = external constant [0 x i8]
declare i32 @std_2fos_2eRemove(ptr %v0, { i64, ptr } %a0)
@olang_loc_b96489c868b59f9_7d9f173036255045 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fbuild_2eReadable(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_a5855f4dee34d57_8118d8286dddc923 = external constant [0 x i8]
@olang_loc_ab41c76c9764eb19_14bd85dfef8a6745 = external constant [0 x i8]
declare %"compiler/emit:Reused" @compiler_2femit_3aReused_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %a0)
@olang_loc_d540fbb856ad9648_e6cd81c31b943694 = external constant [0 x i8]
@olang_loc_30bb4d1d04b77ae4_b48bc1201be9b2a0 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %a0, i64 %a1)
@olang_loc_e09c8d310c475dd1_b9a5b78f48e38cfd = external constant [0 x i8]
@olang_loc_b7226a2473daafee_95f7e6f063520982 = external constant [0 x i8]
declare i1 @std_2fos_2eExists(ptr %v0, { i64, ptr } %a0)
@olang_loc_8b5a25ea6dff5deb_e266ef1e1aa7167f = external constant [0 x i8]
@olang_loc_ba89f34926a12070_1be1301c9cbce214 = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aReused_3e_2ePush_3ccompiler_2femit_3aReused_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/emit:Reused" %a1)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_524754f243909c7f_c56b4bf250637b8b = external constant [0 x i8]
declare void @std_2ffilepath_2elivePath_2einit()
declare void @compiler_2fbuild_2ePhaseAt_2einit()
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eInstNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2ector(ptr %v0)
@olang_loc_6a9437d164e18f65_777063661d50beb9 = external constant [0 x i8]
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2femit_3aReused_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
