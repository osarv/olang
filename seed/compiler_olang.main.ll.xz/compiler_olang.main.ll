; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/olang:CommandLine" = type { i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, i1 }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/build:Config" = type { { i64, ptr }, { i64, ptr }, %"compiler/target:Target", %"compiler/cond:Consts", i1, i1, i1, i1, i1, i64, i1, i1, { i64, ptr }, { i64, ptr }, i64, i64, i1, { i64, ptr } }
%"compiler/target:Target" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i1, i1 }
%"compiler/cond:Consts" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/os:FileInfo" = type { i32, i64, i64 }
%"compiler/build:Unit" = type { { i64, ptr }, i32, { i64, ptr }, { i64, ptr } }
%"compiler/emit:Object" = type { { i64, ptr }, i32, { i64, ptr }, i64 }
%"compiler/emit:Emitter" = type { ptr, ptr, ptr, ptr, i1, i1, i1, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i64, i1, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i1, i1, { i64, ptr }, i1, i64, i64, i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/build:Program" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr } }
%"compiler/lower:Gap" = type { i64, %"compiler/source:Span", { i64, ptr } }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/emit:Reused" = type { i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64 }
%"compiler/check:Checker" = type { ptr, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/lower:Lowerer" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i32, i32, i32 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, { i64, ptr }, { i64, ptr } }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, ptr, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/interp:Exec" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i32, %"compiler/lower:Lowerer", %"compiler/eval:Machine", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"compiler/eval:Machine" = type { ptr, i32, i64, i64, i64, i64, i64, i64, %"compiler/eval:Ptr", i32, { i64, [5 x i64] }, i1, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, i64, { i64, ptr }, { i64, ptr }, i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i64, { i64, ptr }, i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i64, i64, { i64, ptr }, i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/source:Span", i32 }
%"compiler/eval:Ptr" = type { i64, i64 }
%"compiler/fetch:Fetcher" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/source:Names" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/olang:Passes" = type { i64 }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/types:Table" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/load:Import" = type { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, { i64, ptr }, i64, i64 }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/scope:Scoper" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { ptr, ptr }, { ptr, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, i64, i1, %"compiler/typed:Plan", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, [2 x i64] }, i1, %"compiler/source:Span", { i64, [2 x i64] }, i1, { i64, [2 x i64] }, i1, i1, i1, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, [2 x i64] }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i64, { i64, [2 x i64] }, i1, i1, i1, i64, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i64, i32, i1, i1, i1, i1, i64, %"compiler/source:Span" }
%"compiler/typed:Plan" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/text:LineIter" = type { { i64, ptr }, i64 }
@G_2ecompiler_2folang_2eBuild = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eCompile = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eExplain = constant <{ [8 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eFormat = constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eHelp = constant <{ [8 x i8] }> <{ [8 x i8] c"\07\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eInterp = constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eModeUsage = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\2A\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeUsage.k1, [8 x i8] c"\22\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeUsage.k2, [8 x i8] c"\24\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeUsage.k3, [8 x i8] c"\24\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeUsage.k4, [8 x i8] c"\34\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeUsage.k5, [8 x i8] c"\26\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeUsage.k6, [8 x i8] c"\12\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeUsage.k7, [8 x i8] c"\11\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeUsage.k8 }>, align 64
@G_2ecompiler_2folang_2eModeUsage.k1 = internal constant <{ [42 x i8] }> <{ [42 x i8] c"\6F\6C\61\6E\67\20\5B\4F\50\54\49\4F\4E\2E\2E\2E\5D\20\46\49\4C\45\2E\6F\6C\61\6E\67\20\5B\41\52\47\55\4D\45\4E\54\2E\2E\2E\5D" }>, align 32
@G_2ecompiler_2folang_2eModeUsage.k2 = internal constant <{ [34 x i8] }> <{ [34 x i8] c"\6F\6C\61\6E\67\20\62\75\69\6C\64\20\5B\4F\50\54\49\4F\4E\2E\2E\2E\5D\20\46\49\4C\45\2E\6F\6C\61\6E\67" }>, align 32
@G_2ecompiler_2folang_2eModeUsage.k3 = internal constant <{ [36 x i8] }> <{ [36 x i8] c"\6F\6C\61\6E\67\20\63\6F\6D\70\69\6C\65\20\5B\4F\50\54\49\4F\4E\2E\2E\2E\5D\20\46\49\4C\45\2E\6F\6C\61\6E\67" }>, align 32
@G_2ecompiler_2folang_2eModeUsage.k4 = internal constant <{ [36 x i8] }> <{ [36 x i8] c"\6F\6C\61\6E\67\20\74\65\73\74\20\5B\4F\50\54\49\4F\4E\2E\2E\2E\5D\20\46\49\4C\45\2E\6F\6C\61\6E\67\2E\2E\2E" }>, align 32
@G_2ecompiler_2folang_2eModeUsage.k5 = internal constant <{ [52 x i8] }> <{ [52 x i8] c"\6F\6C\61\6E\67\20\69\6E\74\65\72\70\72\65\74\20\5B\4F\50\54\49\4F\4E\2E\2E\2E\5D\20\46\49\4C\45\2E\6F\6C\61\6E\67\20\5B\41\52\47\55\4D\45\4E\54\2E\2E\2E\5D" }>, align 32
@G_2ecompiler_2folang_2eModeUsage.k6 = internal constant <{ [38 x i8] }> <{ [38 x i8] c"\6F\6C\61\6E\67\20\66\6F\72\6D\61\74\20\5B\4F\50\54\49\4F\4E\2E\2E\2E\5D\20\46\49\4C\45\2E\6F\6C\61\6E\67\2E\2E\2E" }>, align 32
@G_2ecompiler_2folang_2eModeUsage.k7 = internal constant <{ [18 x i8] }> <{ [18 x i8] c"\6F\6C\61\6E\67\20\65\78\70\6C\61\69\6E\20\52\55\4C\45" }>, align 8
@G_2ecompiler_2folang_2eModeUsage.k8 = internal constant <{ [17 x i8] }> <{ [17 x i8] c"\6F\6C\61\6E\67\20\68\65\6C\70\20\5B\4D\4F\44\45\5D" }>, align 8
@G_2ecompiler_2folang_2eModeWhat = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\6A\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWhat.k1, [8 x i8] c"\40\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWhat.k2, [8 x i8] c"\36\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWhat.k3, [8 x i8] c"\3E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWhat.k4, [8 x i8] c"\6E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWhat.k5, [8 x i8] c"\2E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWhat.k6, [8 x i8] c"\29\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWhat.k7, [8 x i8] c"\24\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWhat.k8 }>, align 64
@G_2ecompiler_2folang_2eModeWhat.k1 = internal constant <{ [106 x i8] }> <{ [106 x i8] c"\62\75\69\6C\64\73\20\74\68\65\20\70\72\6F\67\72\61\6D\20\46\49\4C\45\2E\6F\6C\61\6E\67\20\69\73\20\74\68\65\20\72\6F\6F\74\20\6F\66\2C\20\61\73\20\62\75\69\6C\64\20\64\6F\65\73\2C\20\61\6E\64\20\72\75\6E\73\20\69\74\20\77\69\74\68\20\74\68\65\20\61\72\67\75\6D\65\6E\74\73\20\61\66\74\65\72\20\74\68\65\20\66\69\6C\65" }>, align 64
@G_2ecompiler_2folang_2eModeWhat.k2 = internal constant <{ [64 x i8] }> <{ [64 x i8] c"\62\75\69\6C\64\73\20\6F\6E\65\20\70\72\6F\67\72\61\6D\2C\20\46\49\4C\45\2E\6F\6C\61\6E\67\20\69\74\73\20\72\6F\6F\74\20\6D\6F\64\75\6C\65\2C\20\69\6E\74\6F\20\62\75\69\6C\64\2F\20\28\42\33\29" }>, align 64
@G_2ecompiler_2folang_2eModeWhat.k3 = internal constant <{ [54 x i8] }> <{ [54 x i8] c"\63\6F\6D\70\69\6C\65\73\20\6F\6E\65\20\6D\6F\64\75\6C\65\20\74\6F\20\61\6E\20\6F\62\6A\65\63\74\2C\20\6C\69\6E\6B\69\6E\67\20\6E\6F\74\68\69\6E\67\20\28\42\32\29" }>, align 32
@G_2ecompiler_2folang_2eModeWhat.k4 = internal constant <{ [62 x i8] }> <{ [62 x i8] c"\72\75\6E\73\20\65\61\63\68\20\66\69\6C\65\27\73\20\74\65\73\74\20\62\6C\6F\63\6B\73\2C\20\65\61\63\68\20\66\69\6C\65\20\62\75\69\6C\74\20\6F\6E\20\69\74\73\20\6F\77\6E\20\28\42\33\61\29" }>, align 32
@G_2ecompiler_2folang_2eModeWhat.k5 = internal constant <{ [110 x i8] }> <{ [110 x i8] c"\72\75\6E\73\20\74\68\65\20\70\72\6F\67\72\61\6D\20\62\79\20\63\6F\6D\70\69\6C\65\2D\74\69\6D\65\20\65\76\61\6C\75\61\74\69\6F\6E\20\69\6E\73\74\65\61\64\20\6F\66\20\62\75\69\6C\64\69\6E\67\20\69\74\2C\20\74\68\65\20\61\72\67\75\6D\65\6E\74\73\20\61\66\74\65\72\20\74\68\65\20\66\69\6C\65\20\69\74\73\20\6F\77\6E\20\28\42\33\65\29" }>, align 64
@G_2ecompiler_2folang_2eModeWhat.k6 = internal constant <{ [46 x i8] }> <{ [46 x i8] c"\72\65\77\72\69\74\65\73\20\65\61\63\68\20\66\69\6C\65\20\69\6E\20\6F\6C\61\6E\67\27\73\20\6F\6E\65\20\6C\61\79\6F\75\74\20\28\42\31\33\29" }>, align 32
@G_2ecompiler_2folang_2eModeWhat.k7 = internal constant <{ [41 x i8] }> <{ [41 x i8] c"\70\72\69\6E\74\73\20\61\20\72\75\6C\65\20\6F\66\20\74\68\65\20\73\70\65\63\69\66\69\63\61\74\69\6F\6E\20\28\42\31\31\61\29" }>, align 32
@G_2ecompiler_2folang_2eModeWhat.k8 = internal constant <{ [36 x i8] }> <{ [36 x i8] c"\6C\69\73\74\73\20\74\68\65\20\6D\6F\64\65\73\2C\20\6F\72\20\61\20\6D\6F\64\65\27\73\20\6F\70\74\69\6F\6E\73" }>, align 32
@G_2ecompiler_2folang_2eModeWords = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWords.k1, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWords.k2, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWords.k3, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWords.k4, [8 x i8] c"\09\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWords.k5, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWords.k6, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWords.k7, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eModeWords.k8 }>, align 64
@G_2ecompiler_2folang_2eModeWords.k1 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2folang_2eModeWords.k2 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\62\75\69\6C\64" }>, align 8
@G_2ecompiler_2folang_2eModeWords.k3 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\63\6F\6D\70\69\6C\65" }>, align 8
@G_2ecompiler_2folang_2eModeWords.k4 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\74\65\73\74" }>, align 8
@G_2ecompiler_2folang_2eModeWords.k5 = internal constant <{ [9 x i8] }> <{ [9 x i8] c"\69\6E\74\65\72\70\72\65\74" }>, align 8
@G_2ecompiler_2folang_2eModeWords.k6 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\66\6F\72\6D\61\74" }>, align 8
@G_2ecompiler_2folang_2eModeWords.k7 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\65\78\70\6C\61\69\6E" }>, align 8
@G_2ecompiler_2folang_2eModeWords.k8 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\68\65\6C\70" }>, align 8
@G_2ecompiler_2folang_2eOptModes = constant <{ [64 x i8] }> <{ [64 x i8] c"\06\00\00\00\00\00\00\00\0F\00\00\00\00\00\00\00\0F\00\00\00\00\00\00\00\0F\00\00\00\00\00\00\00\1F\00\00\00\00\00\00\00\1F\00\00\00\00\00\00\00\1F\00\00\00\00\00\00\00\20\00\00\00\00\00\00\00" }>, align 64
@G_2ecompiler_2folang_2eOptValues = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptValues.k1, [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptValues.k2, [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptValues.k3, [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptValues.k4, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptValues.k5, [8 x i8] c"\0A\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptValues.k6, [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptValues.k7, [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptValues.k8 }>, align 64
@G_2ecompiler_2folang_2eOptValues.k1 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\50\41\54\48" }>, align 8
@G_2ecompiler_2folang_2eOptValues.k2 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2folang_2eOptValues.k3 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2folang_2eOptValues.k4 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2folang_2eOptValues.k5 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\4E\41\4D\45" }>, align 8
@G_2ecompiler_2folang_2eOptValues.k6 = internal constant <{ [10 x i8] }> <{ [10 x i8] c"\4E\61\6D\65\3D\76\61\6C\75\65" }>, align 8
@G_2ecompiler_2folang_2eOptValues.k7 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2folang_2eOptValues.k8 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2folang_2eOptWhat = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\31\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWhat.k1, [8 x i8] c"\35\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWhat.k2, [8 x i8] c"\28\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWhat.k3, [8 x i8] c"\25\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWhat.k4, [8 x i8] c"\20\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWhat.k5, [8 x i8] c"\1E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWhat.k6, [8 x i8] c"\55\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWhat.k7, [8 x i8] c"\39\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWhat.k8 }>, align 64
@G_2ecompiler_2folang_2eOptWhat.k1 = internal constant <{ [49 x i8] }> <{ [49 x i8] c"\77\72\69\74\65\73\20\74\68\65\20\65\78\65\63\75\74\61\62\6C\65\20\6F\72\20\74\68\65\20\6F\62\6A\65\63\74\20\74\6F\20\50\41\54\48\20\28\42\33\68\29" }>, align 32
@G_2ecompiler_2folang_2eOptWhat.k2 = internal constant <{ [53 x i8] }> <{ [53 x i8] c"\62\75\69\6C\64\73\20\75\6E\6F\70\74\69\6D\69\7A\65\64\2C\20\77\69\74\68\20\64\65\62\75\67\20\69\6E\66\6F\72\6D\61\74\69\6F\6E\20\28\42\32\63\2C\20\42\32\65\29" }>, align 32
@G_2ecompiler_2folang_2eOptWhat.k3 = internal constant <{ [40 x i8] }> <{ [40 x i8] c"\62\75\69\6C\64\73\20\77\69\74\68\20\74\68\65\20\64\61\74\61\20\72\61\63\65\20\64\65\74\65\63\74\6F\72\20\28\42\32\62\29" }>, align 32
@G_2ecompiler_2folang_2eOptWhat.k4 = internal constant <{ [37 x i8] }> <{ [37 x i8] c"\62\75\69\6C\64\73\20\77\69\74\68\20\74\68\65\20\73\63\6F\70\65\20\73\61\6E\69\74\69\7A\65\72\20\28\42\32\66\29" }>, align 32
@G_2ecompiler_2folang_2eOptWhat.k5 = internal constant <{ [32 x i8] }> <{ [32 x i8] c"\62\75\69\6C\64\73\20\66\6F\72\20\61\6E\6F\74\68\65\72\20\6D\61\63\68\69\6E\65\20\28\42\31\32\29" }>, align 32
@G_2ecompiler_2folang_2eOptWhat.k6 = internal constant <{ [30 x i8] }> <{ [30 x i8] c"\64\65\66\69\6E\65\73\20\61\20\62\75\69\6C\64\20\63\6F\6E\73\74\61\6E\74\20\28\42\31\30\29" }>, align 8
@G_2ecompiler_2folang_2eOptWhat.k7 = internal constant <{ [85 x i8] }> <{ [85 x i8] c"\6D\6F\76\65\73\20\74\68\65\20\72\65\6D\6F\74\65\20\72\65\70\6F\73\69\74\6F\72\69\65\73\20\74\68\65\20\62\75\69\6C\64\20\72\65\61\63\68\65\73\20\74\6F\20\74\68\65\69\72\20\72\65\66\73\27\20\63\75\72\72\65\6E\74\20\63\6F\6D\6D\69\74\73\20\28\4D\32\33\63\29" }>, align 64
@G_2ecompiler_2folang_2eOptWhat.k8 = internal constant <{ [57 x i8] }> <{ [57 x i8] c"\72\65\77\72\69\74\65\73\20\6E\6F\74\68\69\6E\67\3A\20\6C\69\73\74\73\20\65\61\63\68\20\66\69\6C\65\20\6E\6F\74\20\69\6E\20\74\68\65\20\6C\61\79\6F\75\74\20\28\42\31\33\29" }>, align 32
@G_2ecompiler_2folang_2eOptWords = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWords.k1, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWords.k2, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWords.k3, [8 x i8] c"\09\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWords.k4, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWords.k5, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWords.k6, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWords.k7, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2folang_2eOptWords.k8 }>, align 64
@G_2ecompiler_2folang_2eOptWords.k1 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\2D\6F\75\74\70\75\74" }>, align 8
@G_2ecompiler_2folang_2eOptWords.k2 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\2D\64\65\62\75\67" }>, align 8
@G_2ecompiler_2folang_2eOptWords.k3 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\2D\72\61\63\65" }>, align 8
@G_2ecompiler_2folang_2eOptWords.k4 = internal constant <{ [9 x i8] }> <{ [9 x i8] c"\2D\73\61\6E\69\74\69\7A\65" }>, align 8
@G_2ecompiler_2folang_2eOptWords.k5 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\2D\74\61\72\67\65\74" }>, align 8
@G_2ecompiler_2folang_2eOptWords.k6 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\2D\64\65\66\69\6E\65" }>, align 8
@G_2ecompiler_2folang_2eOptWords.k7 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\2D\75\70\64\61\74\65" }>, align 8
@G_2ecompiler_2folang_2eOptWords.k8 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\2D\63\68\65\63\6B" }>, align 8
@G_2ecompiler_2folang_2eRun = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eTest = constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
define dso_local void @compiler_2folang_2eBuild_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 1, ptr @G_2ecompiler_2folang_2eBuild, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eCompile_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 2, ptr @G_2ecompiler_2folang_2eCompile, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eExplain_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 6, ptr @G_2ecompiler_2folang_2eExplain, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eFormat_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 5, ptr @G_2ecompiler_2folang_2eFormat, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eHelp_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 7, ptr @G_2ecompiler_2folang_2eHelp, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eInterp_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 4, ptr @G_2ecompiler_2folang_2eInterp, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eModeUsage_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t1 = insertvalue [8 x { i64, ptr }] undef, { i64, ptr } { i64 42, ptr @.d0 }, 0
  %t2 = insertvalue [8 x { i64, ptr }] %t1, { i64, ptr } { i64 34, ptr @.d1 }, 1
  %t3 = insertvalue [8 x { i64, ptr }] %t2, { i64, ptr } { i64 36, ptr @.d2 }, 2
  %t4 = insertvalue [8 x { i64, ptr }] %t3, { i64, ptr } { i64 36, ptr @.d3 }, 3
  %t5 = insertvalue [8 x { i64, ptr }] %t4, { i64, ptr } { i64 52, ptr @.d4 }, 4
  %t6 = insertvalue [8 x { i64, ptr }] %t5, { i64, ptr } { i64 38, ptr @.d5 }, 5
  %t7 = insertvalue [8 x { i64, ptr }] %t6, { i64, ptr } { i64 18, ptr @.d6 }, 6
  %t8 = insertvalue [8 x { i64, ptr }] %t7, { i64, ptr } { i64 17, ptr @.d7 }, 7
  store [8 x { i64, ptr }] %t8, ptr @G_2ecompiler_2folang_2eModeUsage
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eModeWhat_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t1 = insertvalue [8 x { i64, ptr }] undef, { i64, ptr } { i64 106, ptr @.d8 }, 0
  %t2 = insertvalue [8 x { i64, ptr }] %t1, { i64, ptr } { i64 64, ptr @.d9 }, 1
  %t3 = insertvalue [8 x { i64, ptr }] %t2, { i64, ptr } { i64 54, ptr @.d10 }, 2
  %t4 = insertvalue [8 x { i64, ptr }] %t3, { i64, ptr } { i64 62, ptr @.d11 }, 3
  %t5 = insertvalue [8 x { i64, ptr }] %t4, { i64, ptr } { i64 110, ptr @.d12 }, 4
  %t6 = insertvalue [8 x { i64, ptr }] %t5, { i64, ptr } { i64 46, ptr @.d13 }, 5
  %t7 = insertvalue [8 x { i64, ptr }] %t6, { i64, ptr } { i64 41, ptr @.d14 }, 6
  %t8 = insertvalue [8 x { i64, ptr }] %t7, { i64, ptr } { i64 36, ptr @.d15 }, 7
  store [8 x { i64, ptr }] %t8, ptr @G_2ecompiler_2folang_2eModeWhat
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eModeWords_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t1 = insertvalue [8 x { i64, ptr }] undef, { i64, ptr } { i64 0, ptr @.d16 }, 0
  %t2 = insertvalue [8 x { i64, ptr }] %t1, { i64, ptr } { i64 5, ptr @.d17 }, 1
  %t3 = insertvalue [8 x { i64, ptr }] %t2, { i64, ptr } { i64 7, ptr @.d18 }, 2
  %t4 = insertvalue [8 x { i64, ptr }] %t3, { i64, ptr } { i64 4, ptr @.d19 }, 3
  %t5 = insertvalue [8 x { i64, ptr }] %t4, { i64, ptr } { i64 9, ptr @.d20 }, 4
  %t6 = insertvalue [8 x { i64, ptr }] %t5, { i64, ptr } { i64 6, ptr @.d21 }, 5
  %t7 = insertvalue [8 x { i64, ptr }] %t6, { i64, ptr } { i64 7, ptr @.d22 }, 6
  %t8 = insertvalue [8 x { i64, ptr }] %t7, { i64, ptr } { i64 4, ptr @.d23 }, 7
  store [8 x { i64, ptr }] %t8, ptr @G_2ecompiler_2folang_2eModeWords
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eOptModes_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t1 = insertvalue [8 x i64] undef, i64 6, 0
  %t2 = insertvalue [8 x i64] %t1, i64 15, 1
  %t3 = insertvalue [8 x i64] %t2, i64 15, 2
  %t4 = insertvalue [8 x i64] %t3, i64 15, 3
  %t5 = insertvalue [8 x i64] %t4, i64 31, 4
  %t6 = insertvalue [8 x i64] %t5, i64 31, 5
  %t7 = insertvalue [8 x i64] %t6, i64 31, 6
  %t8 = insertvalue [8 x i64] %t7, i64 32, 7
  store [8 x i64] %t8, ptr @G_2ecompiler_2folang_2eOptModes
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eOptValues_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t1 = insertvalue [8 x { i64, ptr }] undef, { i64, ptr } { i64 4, ptr @.d24 }, 0
  %t2 = insertvalue [8 x { i64, ptr }] %t1, { i64, ptr } { i64 0, ptr @.d25 }, 1
  %t3 = insertvalue [8 x { i64, ptr }] %t2, { i64, ptr } { i64 0, ptr @.d26 }, 2
  %t4 = insertvalue [8 x { i64, ptr }] %t3, { i64, ptr } { i64 0, ptr @.d27 }, 3
  %t5 = insertvalue [8 x { i64, ptr }] %t4, { i64, ptr } { i64 4, ptr @.d28 }, 4
  %t6 = insertvalue [8 x { i64, ptr }] %t5, { i64, ptr } { i64 10, ptr @.d29 }, 5
  %t7 = insertvalue [8 x { i64, ptr }] %t6, { i64, ptr } { i64 0, ptr @.d30 }, 6
  %t8 = insertvalue [8 x { i64, ptr }] %t7, { i64, ptr } { i64 0, ptr @.d31 }, 7
  store [8 x { i64, ptr }] %t8, ptr @G_2ecompiler_2folang_2eOptValues
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eOptWhat_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t1 = insertvalue [8 x { i64, ptr }] undef, { i64, ptr } { i64 49, ptr @.d32 }, 0
  %t2 = insertvalue [8 x { i64, ptr }] %t1, { i64, ptr } { i64 53, ptr @.d33 }, 1
  %t3 = insertvalue [8 x { i64, ptr }] %t2, { i64, ptr } { i64 40, ptr @.d34 }, 2
  %t4 = insertvalue [8 x { i64, ptr }] %t3, { i64, ptr } { i64 37, ptr @.d35 }, 3
  %t5 = insertvalue [8 x { i64, ptr }] %t4, { i64, ptr } { i64 32, ptr @.d36 }, 4
  %t6 = insertvalue [8 x { i64, ptr }] %t5, { i64, ptr } { i64 30, ptr @.d37 }, 5
  %t7 = insertvalue [8 x { i64, ptr }] %t6, { i64, ptr } { i64 85, ptr @.d38 }, 6
  %t8 = insertvalue [8 x { i64, ptr }] %t7, { i64, ptr } { i64 57, ptr @.d39 }, 7
  store [8 x { i64, ptr }] %t8, ptr @G_2ecompiler_2folang_2eOptWhat
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eOptWords_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t1 = insertvalue [8 x { i64, ptr }] undef, { i64, ptr } { i64 7, ptr @.d40 }, 0
  %t2 = insertvalue [8 x { i64, ptr }] %t1, { i64, ptr } { i64 6, ptr @.d41 }, 1
  %t3 = insertvalue [8 x { i64, ptr }] %t2, { i64, ptr } { i64 5, ptr @.d42 }, 2
  %t4 = insertvalue [8 x { i64, ptr }] %t3, { i64, ptr } { i64 9, ptr @.d43 }, 3
  %t5 = insertvalue [8 x { i64, ptr }] %t4, { i64, ptr } { i64 7, ptr @.d44 }, 4
  %t6 = insertvalue [8 x { i64, ptr }] %t5, { i64, ptr } { i64 7, ptr @.d45 }, 5
  %t7 = insertvalue [8 x { i64, ptr }] %t6, { i64, ptr } { i64 7, ptr @.d46 }, 6
  %t8 = insertvalue [8 x { i64, ptr }] %t7, { i64, ptr } { i64 6, ptr @.d47 }, 7
  store [8 x { i64, ptr }] %t8, ptr @G_2ecompiler_2folang_2eOptWords
  br label %ret
ret:
  ret void
}

define dso_local { i32, %"compiler/olang:CommandLine" } @compiler_2folang_2eParse(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l2 = alloca ptr
  %lp3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca %"compiler/olang:CommandLine"
  %l19 = alloca ptr
  %l20 = alloca %"compiler/msgs:Msg"
  %l21 = alloca i32
  %l23 = alloca { i64, ptr }
  %l25 = alloca i1
  %l27 = alloca i1
  %l28 = alloca { i64, ptr }
  %l30 = alloca i1
  %l32 = alloca { i64, ptr }
  %l34 = alloca i64
  %l37 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l40 = alloca %"compiler/msgs:Msg"
  %l41 = alloca i32
  %l49 = alloca { i64, ptr }
  %l55 = alloca i1
  %l61 = alloca i64
  %l64 = alloca i64
  %l85 = alloca i1
  %l91 = alloca ptr
  %l92 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l96 = alloca %"compiler/msgs:Msg"
  %l97 = alloca i32
  %l101 = alloca i64
  %l105 = alloca ptr
  %l106 = alloca { i64, ptr }
  %l109 = alloca { i64, ptr }
  %l110 = alloca { i64, ptr }
  %l112 = alloca { i64, ptr }
  %l114 = alloca %"compiler/msgs:Msg"
  %l115 = alloca i32
  %l123 = alloca i1
  %l129 = alloca ptr
  %l133 = alloca %"compiler/msgs:Msg"
  %l134 = alloca i32
  %l136 = alloca { i64, ptr }
  %l172 = alloca i32
  %l185 = alloca i1
  %l190 = alloca ptr
  %l194 = alloca %"compiler/msgs:Msg"
  %l195 = alloca %"compiler/msgs:Msg"
  %l196 = alloca %"compiler/msgs:Msg"
  %l197 = alloca i32
  %l205 = alloca i1
  %l207 = alloca i1
  %l210 = alloca i64
  %l212 = alloca ptr
  %l214 = alloca %"compiler/msgs:Msg"
  %l215 = alloca i32
  %l217 = alloca ptr
  %l219 = alloca %"compiler/msgs:Msg"
  %l220 = alloca i32
  %l229 = alloca i1
  %l239 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %rv = alloca { i32, %"compiler/olang:CommandLine" }
  store { i64, ptr } %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"compiler/olang:CommandLine" @compiler_2folang_3aCommandLine_2ector(ptr %v3)
  store %"compiler/olang:CommandLine" %t1, ptr %l15
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 96, i64 8)
  store ptr %t2, ptr %lp3
  %t3 = load %"compiler/olang:CommandLine", ptr %l15
  %t4 = load ptr, ptr %lp3
  store %"compiler/olang:CommandLine" %t3, ptr %t4
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t9 = icmp slt i64 %t7, 2
  br i1 %t9, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = load ptr, ptr %l2, !tbaa !29
  store ptr %t11, ptr %l19, !tbaa !29
  %t12 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eUsage(ptr %s1)
  store %"compiler/msgs:Msg" %t12, ptr %l20
  br label %bb4
bb3:
  br label %bb8
bb4:
  %t13 = load ptr, ptr %l19, !tbaa !29
  %t14 = load %"compiler/msgs:Msg", ptr %l20
  %t15 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s1, ptr %t13, %"compiler/msgs:Msg" %t14)
  store i32 %t15, ptr %l21
  %t16 = icmp ne i32 %t15, 0
  br i1 %t16, label %bb6, label %ok.17
ok.17:
  br label %bb5
bb5:
  br label %bb7
bb6:
  %t18 = load i32, ptr %l21, !tbaa !23
  %t19 = lshr i32 %t18, 16
  %t20 = and i32 %t18, 65535
  %t21 = icmp eq i32 %t19, 1
  %t22 = select i1 %t21, i32 1, i32 0
  %t23 = icmp eq i32 %t18, 0
  %t24 = shl i32 %t22, 16
  %t25 = or i32 %t24, %t20
  %t26 = select i1 %t23, i32 0, i32 %t25
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t28 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t26, 0
  store { i32, %"compiler/olang:CommandLine" } %t28, ptr %rv
  br label %ret
bb7:
  call void @__olang_scope_close(ptr %s1)
  br label %bb8
bb8:
  store i64 1, ptr %l4, !tbaa !24
  %t29 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t29, ptr %l23, !tbaa !27
  %t30 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr { i64, ptr }, ptr %t31, i64 1
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !37
  %t35 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t33, { i64, ptr } { i64 1, ptr @.d48 })
  store i1 %t35, ptr %l25
  br label %bb9
bb9:
  %t36 = load i1, ptr %l25, !tbaa !21
  %t37 = xor i1 %t36, true
  br i1 %t37, label %bb10, label %bb11
bb10:
  %t39 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t39, ptr %l28, !tbaa !27
  %t40 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %t41, i64 1
  %t43 = load { i64, ptr }, ptr %t42, !tbaa !37
  %t45 = call i1 @compiler_2folang_2eendsWithOlang(ptr %v0, { i64, ptr } %t43)
  store i1 %t45, ptr %l30
  br label %bb12
bb11:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb13
bb12:
  %t46 = load i1, ptr %l30, !tbaa !21
  %t47 = xor i1 %t46, true
  store i1 %t47, ptr %l27, !tbaa !21
  br label %bb13
bb13:
  %t49 = load i1, ptr %l27, !tbaa !21
  br i1 %t49, label %bb14, label %bb15
bb14:
  %t50 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t50, ptr %l32, !tbaa !27
  %t51 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = getelementptr { i64, ptr }, ptr %t52, i64 1
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !37
  %t56 = call i64 @compiler_2folang_2emodeNumber(ptr %v0, { i64, ptr } %t54)
  store i64 %t56, ptr %l34
  br label %bb16
bb15:
  br label %bb24
bb16:
  %t57 = load i64, ptr %l34, !tbaa !24
  store i64 %t57, ptr %l5, !tbaa !24
  %t58 = load i64, ptr %l5, !tbaa !24
  %t60 = icmp slt i64 %t58, 0
  br i1 %t60, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s3
  %t62 = load ptr, ptr %l2, !tbaa !29
  store ptr %t62, ptr %l37, !tbaa !29
  %t63 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t63, ptr %l38, !tbaa !27
  %t64 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = getelementptr { i64, ptr }, ptr %t65, i64 1
  %t67 = load { i64, ptr }, ptr %t66, !tbaa !37
  %t69 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotAMode(ptr %v0, ptr %s3, { i64, ptr } %t67)
  store %"compiler/msgs:Msg" %t69, ptr %l40
  br label %bb19
bb18:
  br label %bb23
bb19:
  %t70 = load ptr, ptr %l37, !tbaa !29
  %t71 = load %"compiler/msgs:Msg", ptr %l40
  %t72 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s3, ptr %t70, %"compiler/msgs:Msg" %t71)
  store i32 %t72, ptr %l41
  %t73 = icmp ne i32 %t72, 0
  br i1 %t73, label %bb21, label %ok.74
ok.74:
  br label %bb20
bb20:
  br label %bb22
bb21:
  %t75 = load i32, ptr %l41, !tbaa !23
  %t76 = lshr i32 %t75, 16
  %t77 = and i32 %t75, 65535
  %t78 = icmp eq i32 %t76, 1
  %t79 = select i1 %t78, i32 1, i32 0
  %t80 = icmp eq i32 %t75, 0
  %t81 = shl i32 %t79, 16
  %t82 = or i32 %t81, %t77
  %t83 = select i1 %t80, i32 0, i32 %t82
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t85 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t83, 0
  store { i32, %"compiler/olang:CommandLine" } %t85, ptr %rv
  br label %ret
bb22:
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb23:
  %t86 = load i64, ptr %l5, !tbaa !24
  %t88 = load ptr, ptr %lp3
  %t89 = getelementptr %"compiler/olang:CommandLine", ptr %t88, i32 0, i32 0
  store i64 %t86, ptr %t89, !tbaa !24
  store i64 2, ptr %l4, !tbaa !24
  br label %bb24
bb24:
  br label %bb25
bb25:
  store %olang.scope zeroinitializer, ptr %s4
  %t90 = load i64, ptr %l4, !tbaa !24
  %t91 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t91, 0
  %t96 = icmp slt i64 %t90, %t93
  %t98 = xor i1 %t96, true
  br i1 %t98, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s4)
  br label %bb160
bb27:
  br label %bb28
bb28:
  %t100 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t100, ptr %l49, !tbaa !27
  %t101 = load i64, ptr %l4, !tbaa !24
  %t103 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = getelementptr { i64, ptr }, ptr %t104, i64 %t101
  %t106 = load { i64, ptr }, ptr %t105, !tbaa !37
  store { i64, ptr } %t106, ptr %l6, !tbaa !27
  %t108 = load i64, ptr %l4, !tbaa !24
  %t110 = add i64 %t108, 1
  store i64 %t110, ptr %l4, !tbaa !24
  %t112 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t114 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s4, { i64, ptr } %t112, { i64, ptr } { i64 1, ptr @.d49 })
  store i1 %t114, ptr %l55
  br label %bb29
bb29:
  %t115 = load i1, ptr %l55, !tbaa !21
  br i1 %t115, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s5
  store i64 -1, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  %t116 = load [8 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eOptWords
  store i64 8, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t119 = load i64, ptr %l9, !tbaa !24
  %t120 = load i64, ptr %l8, !tbaa !24
  %t123 = icmp sgt i64 %t119, %t120
  br i1 %t123, label %bb32, label %bb33
bb31:
  br label %bb108
bb32:
  %t125 = load i64, ptr %l10, !tbaa !24
  %t127 = icmp sgt i64 %t125, 0
  br i1 %t127, label %bb34, label %bb35
bb33:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb37
bb34:
  %t129 = load i64, ptr %l9, !tbaa !24
  %t130 = load i64, ptr %l8, !tbaa !24
  %t133 = sub i64 %t129, %t130
  %t134 = load i64, ptr %l10, !tbaa !24
  %t137 = add i64 %t133, %t134
  %t139 = sub i64 %t137, 1
  %t140 = load i64, ptr %l10, !tbaa !24
  %t143 = sdiv i64 %t139, %t140
  store i64 %t143, ptr %l64, !tbaa !24
  br label %bb36
bb35:
  store i64 0, ptr %l64, !tbaa !24
  br label %bb36
bb36:
  %t145 = load i64, ptr %l64, !tbaa !24
  store i64 %t145, ptr %l61, !tbaa !24
  br label %bb37
bb37:
  %t146 = load i64, ptr %l61, !tbaa !24
  store i64 %t146, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb38
bb38:
  store %olang.scope zeroinitializer, ptr %s7
  %t147 = load i64, ptr %l12, !tbaa !24
  %t148 = load i64, ptr %l11, !tbaa !24
  %t151 = icmp slt i64 %t147, %t148
  %t153 = xor i1 %t151, true
  br i1 %t153, label %bb39, label %bb40
bb39:
  call void @__olang_scope_close(ptr %s7)
  br label %bb47
bb40:
  br label %bb41
bb41:
  %t155 = load i64, ptr %l8, !tbaa !24
  %t156 = load i64, ptr %l12, !tbaa !24
  %t157 = load i64, ptr %l10, !tbaa !24
  %t160 = mul i64 %t156, %t157
  %t163 = add i64 %t155, %t160
  store i64 %t163, ptr %l13, !tbaa !24
  %t165 = load i64, ptr %l13, !tbaa !24
  %t167 = getelementptr [8 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eOptWords, i64 0, i64 %t165
  %t168 = load { i64, ptr }, ptr %t167, !tbaa !37
  %t169 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t170 = load ptr, ptr @__olang_prog_scope
  %t173 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t170, ptr %v0, { i64, ptr } %t168, { i64, ptr } %t169)
  store i1 %t173, ptr %l85
  br label %bb42
bb42:
  %t174 = load i1, ptr %l85, !tbaa !21
  br i1 %t174, label %bb43, label %bb44
bb43:
  %t175 = load i64, ptr %l13, !tbaa !24
  store i64 %t175, ptr %l7, !tbaa !24
  br label %bb45
bb44:
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s7)
  br label %bb46
bb46:
  %t177 = load i64, ptr %l12, !tbaa !24
  %t179 = add i64 %t177, 1
  store i64 %t179, ptr %l12, !tbaa !24
  br label %bb38
bb47:
  %t181 = load i64, ptr %l7, !tbaa !24
  %t183 = icmp slt i64 %t181, 0
  br i1 %t183, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s10
  %t185 = load ptr, ptr %l2, !tbaa !29
  store ptr %t185, ptr %l91, !tbaa !29
  %t186 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t186, ptr %l92, !tbaa !27
  %t187 = load ptr, ptr %lp3
  %t188 = getelementptr %"compiler/olang:CommandLine", ptr %t187, i32 0, i32 0
  %t189 = load i64, ptr %t188, !tbaa !24
  %t191 = call { i64, ptr } @compiler_2folang_2emodeName(ptr %s10, i64 %t189)
  store { i64, ptr } %t191, ptr %l94
  br label %bb50
bb49:
  br label %bb55
bb50:
  %t192 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t193 = extractvalue { i64, ptr } %t192, 0
  %t194 = extractvalue { i64, ptr } %t192, 1
  %t195 = mul i64 %t193, 1
  %t196 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t195)
  call void @llvm.memcpy.p0.p0.i64(ptr %t196, ptr %t194, i64 %t195, i1 false)
  %t197 = insertvalue { i64, ptr } undef, i64 %t193, 0
  %t198 = insertvalue { i64, ptr } %t197, ptr %t196, 1
  %t199 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t201 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownFlag(ptr %v0, ptr %s10, ptr %s10, { i64, ptr } %t199, { i64, ptr } %t198)
  store %"compiler/msgs:Msg" %t201, ptr %l96
  br label %bb51
bb51:
  %t202 = load ptr, ptr %l91, !tbaa !29
  %t203 = load %"compiler/msgs:Msg", ptr %l96
  %t204 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s10, ptr %t202, %"compiler/msgs:Msg" %t203)
  store i32 %t204, ptr %l97
  %t205 = icmp ne i32 %t204, 0
  br i1 %t205, label %bb53, label %ok.206
ok.206:
  br label %bb52
bb52:
  br label %bb54
bb53:
  %t207 = load i32, ptr %l97, !tbaa !23
  %t208 = lshr i32 %t207, 16
  %t209 = and i32 %t207, 65535
  %t210 = icmp eq i32 %t208, 1
  %t211 = select i1 %t210, i32 1, i32 0
  %t212 = icmp eq i32 %t207, 0
  %t213 = shl i32 %t211, 16
  %t214 = or i32 %t213, %t209
  %t215 = select i1 %t212, i32 0, i32 %t214
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t217 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t215, 0
  store { i32, %"compiler/olang:CommandLine" } %t217, ptr %rv
  br label %ret
bb54:
  call void @__olang_scope_close(ptr %s10)
  br label %bb55
bb55:
  %t218 = load i64, ptr %l7, !tbaa !24
  %t220 = getelementptr [8 x i64], ptr @G_2ecompiler_2folang_2eOptModes, i64 0, i64 %t218
  %t221 = load i64, ptr %t220, !tbaa !34
  %t222 = load ptr, ptr %lp3
  %t223 = getelementptr %"compiler/olang:CommandLine", ptr %t222, i32 0, i32 0
  %t224 = load i64, ptr %t223, !tbaa !24
  store i64 %t224, ptr %l101, !tbaa !24
  %t226 = load i64, ptr %l101, !tbaa !24
  %t227 = load i64, ptr %l101, !tbaa !24
  %t228 = ashr i64 %t221, %t227
  %t230 = and i64 %t228, 1
  %t232 = icmp eq i64 %t230, 0
  br i1 %t232, label %bb56, label %bb57
bb56:
  store %olang.scope zeroinitializer, ptr %s11
  %t234 = load ptr, ptr %l2, !tbaa !29
  store ptr %t234, ptr %l105, !tbaa !29
  %t235 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t235, ptr %l106, !tbaa !27
  %t236 = load i64, ptr %l7, !tbaa !24
  %t238 = getelementptr [8 x i64], ptr @G_2ecompiler_2folang_2eOptModes, i64 0, i64 %t236
  %t239 = load i64, ptr %t238, !tbaa !34
  %t241 = call { i64, ptr } @compiler_2folang_2emodesOf(ptr %s11, i64 %t239)
  store { i64, ptr } %t241, ptr %l109
  br label %bb58
bb57:
  br label %bb64
bb58:
  %t242 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t243 = extractvalue { i64, ptr } %t242, 0
  %t244 = extractvalue { i64, ptr } %t242, 1
  %t245 = mul i64 %t243, 1
  %t246 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t245)
  call void @llvm.memcpy.p0.p0.i64(ptr %t246, ptr %t244, i64 %t245, i1 false)
  %t247 = insertvalue { i64, ptr } undef, i64 %t243, 0
  %t248 = insertvalue { i64, ptr } %t247, ptr %t246, 1
  store { i64, ptr } %t248, ptr %l110, !tbaa !27
  %t249 = load ptr, ptr %lp3
  %t250 = getelementptr %"compiler/olang:CommandLine", ptr %t249, i32 0, i32 0
  %t251 = load i64, ptr %t250, !tbaa !24
  %t253 = call { i64, ptr } @compiler_2folang_2emodeName(ptr %s11, i64 %t251)
  store { i64, ptr } %t253, ptr %l112
  br label %bb59
bb59:
  %t254 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t255 = extractvalue { i64, ptr } %t254, 0
  %t256 = extractvalue { i64, ptr } %t254, 1
  %t257 = mul i64 %t255, 1
  %t258 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t257)
  call void @llvm.memcpy.p0.p0.i64(ptr %t258, ptr %t256, i64 %t257, i1 false)
  %t259 = insertvalue { i64, ptr } undef, i64 %t255, 0
  %t260 = insertvalue { i64, ptr } %t259, ptr %t258, 1
  %t261 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t262 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t264 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eOptionNotForMode(ptr %v0, ptr %s11, ptr %s11, ptr %s11, { i64, ptr } %t261, { i64, ptr } %t262, { i64, ptr } %t260)
  store %"compiler/msgs:Msg" %t264, ptr %l114
  br label %bb60
bb60:
  %t265 = load ptr, ptr %l105, !tbaa !29
  %t266 = load %"compiler/msgs:Msg", ptr %l114
  %t267 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s11, ptr %t265, %"compiler/msgs:Msg" %t266)
  store i32 %t267, ptr %l115
  %t268 = icmp ne i32 %t267, 0
  br i1 %t268, label %bb62, label %ok.269
ok.269:
  br label %bb61
bb61:
  br label %bb63
bb62:
  %t270 = load i32, ptr %l115, !tbaa !23
  %t271 = lshr i32 %t270, 16
  %t272 = and i32 %t270, 65535
  %t273 = icmp eq i32 %t271, 1
  %t274 = select i1 %t273, i32 1, i32 0
  %t275 = icmp eq i32 %t270, 0
  %t276 = shl i32 %t274, 16
  %t277 = or i32 %t276, %t272
  %t278 = select i1 %t275, i32 0, i32 %t277
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t280 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t278, 0
  store { i32, %"compiler/olang:CommandLine" } %t280, ptr %rv
  br label %ret
bb63:
  call void @__olang_scope_close(ptr %s11)
  br label %bb64
bb64:
  %t281 = load ptr, ptr %lp3
  %t282 = getelementptr %"compiler/olang:CommandLine", ptr %t281, i32 0, i32 5
  %t283 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t285 = extractvalue { i64, ptr } %t283, 1
  %t286 = extractvalue { i64, ptr } %t283, 0
  %t287 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t286)
  call void @olang_textcopy(ptr %t287, ptr %t285, i64 %t286)
  %t288 = insertvalue { i64, ptr } undef, i64 %t286, 0
  %t289 = insertvalue { i64, ptr } %t288, ptr %t287, 1
  %t291 = extractvalue { i64, ptr } %t289, 0
  %t292 = extractvalue { i64, ptr } %t289, 1
  %t293 = mul i64 %t291, 1
  %t294 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t293)
  call void @llvm.memcpy.p0.p0.i64(ptr %t294, ptr %t292, i64 %t293, i1 false)
  %t295 = insertvalue { i64, ptr } undef, i64 %t291, 0
  %t296 = insertvalue { i64, ptr } %t295, ptr %t294, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v3, ptr %v3, ptr %t282, { i64, ptr } %t296)
  br label %bb65
bb65:
  store { i64, ptr } { i64 0, ptr @.d50 }, ptr %l14, !tbaa !27
  %t299 = load i64, ptr %l7, !tbaa !24
  %t301 = getelementptr [8 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eOptValues, i64 0, i64 %t299
  %t302 = load { i64, ptr }, ptr %t301, !tbaa !37
  %t303 = load ptr, ptr @__olang_prog_scope
  %t305 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t303, ptr %s5, { i64, ptr } %t302, { i64, ptr } { i64 0, ptr @.d51 })
  store i1 %t305, ptr %l123
  br label %bb66
bb66:
  %t306 = load i1, ptr %l123, !tbaa !21
  %t307 = xor i1 %t306, true
  br i1 %t307, label %bb67, label %bb68
bb67:
  %t309 = load i64, ptr %l4, !tbaa !24
  %t310 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t312 = extractvalue { i64, ptr } %t310, 0
  %t315 = icmp sge i64 %t309, %t312
  br i1 %t315, label %bb69, label %bb70
bb68:
  br label %bb77
bb69:
  store %olang.scope zeroinitializer, ptr %s14
  %t317 = load ptr, ptr %l2, !tbaa !29
  store ptr %t317, ptr %l129, !tbaa !29
  %t318 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t319 = load i64, ptr %l7, !tbaa !24
  %t321 = getelementptr [8 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eOptValues, i64 0, i64 %t319
  %t322 = load { i64, ptr }, ptr %t321, !tbaa !37
  %t323 = load ptr, ptr @__olang_prog_scope
  %t326 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eOptionNeedsValue(ptr %v0, ptr %t323, ptr %s14, { i64, ptr } %t318, { i64, ptr } %t322)
  store %"compiler/msgs:Msg" %t326, ptr %l133
  br label %bb71
bb70:
  br label %bb75
bb71:
  %t327 = load ptr, ptr %l129, !tbaa !29
  %t328 = load %"compiler/msgs:Msg", ptr %l133
  %t329 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s14, ptr %t327, %"compiler/msgs:Msg" %t328)
  store i32 %t329, ptr %l134
  %t330 = icmp ne i32 %t329, 0
  br i1 %t330, label %bb73, label %ok.331
ok.331:
  br label %bb72
bb72:
  br label %bb74
bb73:
  %t332 = load i32, ptr %l134, !tbaa !23
  %t333 = lshr i32 %t332, 16
  %t334 = and i32 %t332, 65535
  %t335 = icmp eq i32 %t333, 1
  %t336 = select i1 %t335, i32 1, i32 0
  %t337 = icmp eq i32 %t332, 0
  %t338 = shl i32 %t336, 16
  %t339 = or i32 %t338, %t334
  %t340 = select i1 %t337, i32 0, i32 %t339
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t342 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t340, 0
  store { i32, %"compiler/olang:CommandLine" } %t342, ptr %rv
  br label %ret
bb74:
  call void @__olang_scope_close(ptr %s14)
  br label %bb75
bb75:
  %t343 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t343, ptr %l136, !tbaa !27
  %t344 = load i64, ptr %l4, !tbaa !24
  %t346 = getelementptr { i64, ptr }, ptr %l136, i32 0, i32 1
  %t347 = load ptr, ptr %t346, !tbaa !27
  %t348 = getelementptr { i64, ptr }, ptr %t347, i64 %t344
  %t349 = load { i64, ptr }, ptr %t348, !tbaa !37
  %t351 = extractvalue { i64, ptr } %t349, 1
  %t352 = extractvalue { i64, ptr } %t349, 0
  %t353 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t352)
  call void @olang_textcopy(ptr %t353, ptr %t351, i64 %t352)
  %t354 = insertvalue { i64, ptr } undef, i64 %t352, 0
  %t355 = insertvalue { i64, ptr } %t354, ptr %t353, 1
  %t357 = extractvalue { i64, ptr } %t355, 0
  %t358 = extractvalue { i64, ptr } %t355, 1
  %t359 = mul i64 %t357, 1
  %t360 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t359)
  call void @llvm.memcpy.p0.p0.i64(ptr %t360, ptr %t358, i64 %t359, i1 false)
  %t361 = insertvalue { i64, ptr } undef, i64 %t357, 0
  %t362 = insertvalue { i64, ptr } %t361, ptr %t360, 1
  store { i64, ptr } %t362, ptr %l14, !tbaa !27
  %t364 = load i64, ptr %l4, !tbaa !24
  %t366 = add i64 %t364, 1
  store i64 %t366, ptr %l4, !tbaa !24
  %t368 = load ptr, ptr %lp3
  %t369 = getelementptr %"compiler/olang:CommandLine", ptr %t368, i32 0, i32 5
  %t370 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t372 = extractvalue { i64, ptr } %t370, 1
  %t373 = extractvalue { i64, ptr } %t370, 0
  %t374 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t373)
  call void @olang_textcopy(ptr %t374, ptr %t372, i64 %t373)
  %t375 = insertvalue { i64, ptr } undef, i64 %t373, 0
  %t376 = insertvalue { i64, ptr } %t375, ptr %t374, 1
  %t378 = extractvalue { i64, ptr } %t376, 0
  %t379 = extractvalue { i64, ptr } %t376, 1
  %t380 = mul i64 %t378, 1
  %t381 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t380)
  call void @llvm.memcpy.p0.p0.i64(ptr %t381, ptr %t379, i64 %t380, i1 false)
  %t382 = insertvalue { i64, ptr } undef, i64 %t378, 0
  %t383 = insertvalue { i64, ptr } %t382, ptr %t381, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v3, ptr %v3, ptr %t369, { i64, ptr } %t383)
  br label %bb76
bb76:
  br label %bb77
bb77:
  %t386 = load i64, ptr %l7, !tbaa !24
  %t388 = icmp eq i64 %t386, 0
  br i1 %t388, label %bb78, label %bb79
bb78:
  %t390 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t392 = extractvalue { i64, ptr } %t390, 1
  %t393 = extractvalue { i64, ptr } %t390, 0
  %t394 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t393)
  call void @olang_textcopy(ptr %t394, ptr %t392, i64 %t393)
  %t395 = insertvalue { i64, ptr } undef, i64 %t393, 0
  %t396 = insertvalue { i64, ptr } %t395, ptr %t394, 1
  %t398 = extractvalue { i64, ptr } %t396, 0
  %t399 = extractvalue { i64, ptr } %t396, 1
  %t400 = mul i64 %t398, 1
  %t401 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t400)
  call void @llvm.memcpy.p0.p0.i64(ptr %t401, ptr %t399, i64 %t400, i1 false)
  %t402 = insertvalue { i64, ptr } undef, i64 %t398, 0
  %t403 = insertvalue { i64, ptr } %t402, ptr %t401, 1
  %t405 = load ptr, ptr %lp3
  %t406 = getelementptr %"compiler/olang:CommandLine", ptr %t405, i32 0, i32 7
  store { i64, ptr } %t403, ptr %t406, !tbaa !27
  br label %bb80
bb79:
  br label %bb80
bb80:
  %t407 = load i64, ptr %l7, !tbaa !24
  %t409 = icmp eq i64 %t407, 1
  br i1 %t409, label %bb81, label %bb82
bb81:
  %t411 = load ptr, ptr %l1, !tbaa !29
  %t413 = getelementptr %"compiler/build:Config", ptr %t411, i32 0, i32 4
  store i1 true, ptr %t413, !tbaa !21
  br label %bb83
bb82:
  br label %bb83
bb83:
  %t414 = load i64, ptr %l7, !tbaa !24
  %t416 = icmp eq i64 %t414, 2
  br i1 %t416, label %bb84, label %bb85
bb84:
  %t418 = load ptr, ptr %l1, !tbaa !29
  %t420 = getelementptr %"compiler/build:Config", ptr %t418, i32 0, i32 5
  store i1 true, ptr %t420, !tbaa !21
  br label %bb86
bb85:
  br label %bb86
bb86:
  %t421 = load i64, ptr %l7, !tbaa !24
  %t423 = icmp eq i64 %t421, 3
  br i1 %t423, label %bb87, label %bb88
bb87:
  %t425 = load ptr, ptr %l1, !tbaa !29
  %t427 = getelementptr %"compiler/build:Config", ptr %t425, i32 0, i32 6
  store i1 true, ptr %t427, !tbaa !21
  br label %bb89
bb88:
  br label %bb89
bb89:
  %t428 = load i64, ptr %l7, !tbaa !24
  %t430 = icmp eq i64 %t428, 4
  br i1 %t430, label %bb90, label %bb91
bb90:
  %t432 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t434 = extractvalue { i64, ptr } %t432, 1
  %t435 = extractvalue { i64, ptr } %t432, 0
  %t436 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t435)
  call void @olang_textcopy(ptr %t436, ptr %t434, i64 %t435)
  %t437 = insertvalue { i64, ptr } undef, i64 %t435, 0
  %t438 = insertvalue { i64, ptr } %t437, ptr %t436, 1
  %t440 = extractvalue { i64, ptr } %t438, 0
  %t441 = extractvalue { i64, ptr } %t438, 1
  %t442 = mul i64 %t440, 1
  %t443 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t442)
  call void @llvm.memcpy.p0.p0.i64(ptr %t443, ptr %t441, i64 %t442, i1 false)
  %t444 = insertvalue { i64, ptr } undef, i64 %t440, 0
  %t445 = insertvalue { i64, ptr } %t444, ptr %t443, 1
  %t447 = load ptr, ptr %lp3
  %t448 = getelementptr %"compiler/olang:CommandLine", ptr %t447, i32 0, i32 6
  store { i64, ptr } %t445, ptr %t448, !tbaa !27
  br label %bb92
bb91:
  br label %bb92
bb92:
  %t449 = load i64, ptr %l7, !tbaa !24
  %t451 = icmp eq i64 %t449, 5
  br i1 %t451, label %bb93, label %bb94
bb93:
  %t453 = load ptr, ptr %l1, !tbaa !29
  %t455 = getelementptr %"compiler/build:Config", ptr %t453, i32 0, i32 3
  %t456 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t457 = load ptr, ptr %l2, !tbaa !29
  %t461 = call i32 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eDefine(ptr %v1, ptr %s5, ptr %v2, ptr %t455, { i64, ptr } %t456, ptr %t457)
  store i32 %t461, ptr %l172
  %t462 = icmp ne i32 %t461, 0
  br i1 %t462, label %bb96, label %ok.463
ok.463:
  br label %bb95
bb94:
  br label %bb101
bb95:
  br label %bb100
bb96:
  %t464 = load i32, ptr %l172, !tbaa !23
  %t465 = ashr i32 %t464, 16
  %t467 = icmp eq i32 %t465, 1
  br i1 %t467, label %bb97, label %bb98
bb97:
  br label %bb99
bb98:
  %t469 = load i32, ptr %l172, !tbaa !23
  %t470 = lshr i32 %t469, 16
  %t471 = and i32 %t469, 65535
  %t472 = icmp eq i32 %t470, 1
  %t473 = select i1 %t472, i32 0, i32 0
  %t474 = icmp eq i32 %t469, 0
  %t475 = shl i32 %t473, 16
  %t476 = or i32 %t475, %t471
  %t477 = select i1 %t474, i32 0, i32 %t476
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t479 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t477, 0
  store { i32, %"compiler/olang:CommandLine" } %t479, ptr %rv
  br label %ret
bb99:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t481 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/olang:CommandLine" } %t481, ptr %rv
  br label %ret
bb100:
  br label %bb101
bb101:
  %t482 = load i64, ptr %l7, !tbaa !24
  %t484 = icmp eq i64 %t482, 6
  br i1 %t484, label %bb102, label %bb103
bb102:
  %t486 = load ptr, ptr %l1, !tbaa !29
  %t488 = getelementptr %"compiler/build:Config", ptr %t486, i32 0, i32 7
  store i1 true, ptr %t488, !tbaa !21
  br label %bb104
bb103:
  br label %bb104
bb104:
  %t489 = load i64, ptr %l7, !tbaa !24
  %t491 = icmp eq i64 %t489, 7
  br i1 %t491, label %bb105, label %bb106
bb105:
  %t493 = load ptr, ptr %lp3
  %t494 = getelementptr %"compiler/olang:CommandLine", ptr %t493, i32 0, i32 8
  store i1 true, ptr %t494, !tbaa !21
  br label %bb107
bb106:
  br label %bb107
bb107:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  br label %bb159
bb108:
  %t495 = load ptr, ptr %lp3
  %t496 = getelementptr %"compiler/olang:CommandLine", ptr %t495, i32 0, i32 0
  %t497 = load i64, ptr %t496, !tbaa !24
  %t498 = load i64, ptr @G_2ecompiler_2folang_2eExplain, !tbaa !24
  %t501 = icmp eq i64 %t497, %t498
  br i1 %t501, label %bb109, label %bb110
bb109:
  store i1 true, ptr %l185, !tbaa !21
  br label %bb111
bb110:
  %t503 = load ptr, ptr %lp3
  %t504 = getelementptr %"compiler/olang:CommandLine", ptr %t503, i32 0, i32 0
  %t505 = load i64, ptr %t504, !tbaa !24
  %t506 = load i64, ptr @G_2ecompiler_2folang_2eHelp, !tbaa !24
  %t509 = icmp eq i64 %t505, %t506
  store i1 %t509, ptr %l185, !tbaa !21
  br label %bb111
bb111:
  %t511 = load i1, ptr %l185, !tbaa !21
  br i1 %t511, label %bb112, label %bb113
bb112:
  %t512 = load ptr, ptr %lp3
  %t513 = getelementptr %"compiler/olang:CommandLine", ptr %t512, i32 0, i32 3
  %t514 = load i1, ptr %t513, !tbaa !21
  br i1 %t514, label %bb114, label %bb115
bb113:
  br label %bb125
bb114:
  store %olang.scope zeroinitializer, ptr %s29
  %t516 = load ptr, ptr %l2, !tbaa !29
  store ptr %t516, ptr %l190, !tbaa !29
  %t517 = load ptr, ptr %lp3
  %t518 = getelementptr %"compiler/olang:CommandLine", ptr %t517, i32 0, i32 0
  %t519 = load i64, ptr %t518, !tbaa !24
  %t520 = load i64, ptr @G_2ecompiler_2folang_2eExplain, !tbaa !24
  %t523 = icmp eq i64 %t519, %t520
  br i1 %t523, label %bb116, label %bb117
bb115:
  br label %bb124
bb116:
  %t525 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eExplainNeedsRule(ptr %s29)
  store %"compiler/msgs:Msg" %t525, ptr %l195
  br label %bb118
bb117:
  %t526 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eHelpOneMode(ptr %s29)
  store %"compiler/msgs:Msg" %t526, ptr %l196
  br label %bb119
bb118:
  %t527 = load %"compiler/msgs:Msg", ptr %l195
  store %"compiler/msgs:Msg" %t527, ptr %l194
  br label %bb120
bb119:
  %t528 = load %"compiler/msgs:Msg", ptr %l196
  store %"compiler/msgs:Msg" %t528, ptr %l194
  br label %bb120
bb120:
  %t529 = load ptr, ptr %l190, !tbaa !29
  %t530 = load %"compiler/msgs:Msg", ptr %l194
  %t531 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s29, ptr %t529, %"compiler/msgs:Msg" %t530)
  store i32 %t531, ptr %l197
  %t532 = icmp ne i32 %t531, 0
  br i1 %t532, label %bb122, label %ok.533
ok.533:
  br label %bb121
bb121:
  br label %bb123
bb122:
  %t534 = load i32, ptr %l197, !tbaa !23
  %t535 = lshr i32 %t534, 16
  %t536 = and i32 %t534, 65535
  %t537 = icmp eq i32 %t535, 1
  %t538 = select i1 %t537, i32 1, i32 0
  %t539 = icmp eq i32 %t534, 0
  %t540 = shl i32 %t538, 16
  %t541 = or i32 %t540, %t536
  %t542 = select i1 %t539, i32 0, i32 %t541
  call void @__olang_scope_close(ptr %s29)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t544 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t542, 0
  store { i32, %"compiler/olang:CommandLine" } %t544, ptr %rv
  br label %ret
bb123:
  call void @__olang_scope_close(ptr %s29)
  br label %bb124
bb124:
  %t545 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t547 = extractvalue { i64, ptr } %t545, 1
  %t548 = extractvalue { i64, ptr } %t545, 0
  %t549 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t548)
  call void @olang_textcopy(ptr %t549, ptr %t547, i64 %t548)
  %t550 = insertvalue { i64, ptr } undef, i64 %t548, 0
  %t551 = insertvalue { i64, ptr } %t550, ptr %t549, 1
  %t553 = extractvalue { i64, ptr } %t551, 0
  %t554 = extractvalue { i64, ptr } %t551, 1
  %t555 = mul i64 %t553, 1
  %t556 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t555)
  call void @llvm.memcpy.p0.p0.i64(ptr %t556, ptr %t554, i64 %t555, i1 false)
  %t557 = insertvalue { i64, ptr } undef, i64 %t553, 0
  %t558 = insertvalue { i64, ptr } %t557, ptr %t556, 1
  %t560 = load ptr, ptr %lp3
  %t561 = getelementptr %"compiler/olang:CommandLine", ptr %t560, i32 0, i32 2
  store { i64, ptr } %t558, ptr %t561, !tbaa !27
  %t562 = load ptr, ptr %lp3
  %t563 = getelementptr %"compiler/olang:CommandLine", ptr %t562, i32 0, i32 3
  store i1 true, ptr %t563, !tbaa !21
  call void @__olang_scope_close(ptr %s4)
  br label %bb159
bb125:
  %t564 = load ptr, ptr %lp3
  %t565 = getelementptr %"compiler/olang:CommandLine", ptr %t564, i32 0, i32 0
  %t566 = load i64, ptr %t565, !tbaa !24
  %t567 = load i64, ptr @G_2ecompiler_2folang_2eRun, !tbaa !24
  %t570 = icmp eq i64 %t566, %t567
  br i1 %t570, label %bb126, label %bb127
bb126:
  %t572 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t574 = call i1 @compiler_2folang_2eendsWithOlang(ptr %v0, { i64, ptr } %t572)
  store i1 %t574, ptr %l207
  br label %bb128
bb127:
  store i1 false, ptr %l205, !tbaa !21
  br label %bb129
bb128:
  %t575 = load i1, ptr %l207, !tbaa !21
  %t576 = xor i1 %t575, true
  store i1 %t576, ptr %l205, !tbaa !21
  br label %bb129
bb129:
  %t578 = load i1, ptr %l205, !tbaa !21
  br i1 %t578, label %bb130, label %bb131
bb130:
  store %olang.scope zeroinitializer, ptr %s31
  %t579 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t581 = call i64 @compiler_2folang_2emodeNumber(ptr %v0, { i64, ptr } %t579)
  store i64 %t581, ptr %l210
  br label %bb132
bb131:
  br label %bb144
bb132:
  %t582 = load i64, ptr %l210, !tbaa !24
  %t583 = icmp sgt i64 %t582, 0
  br i1 %t583, label %bb133, label %bb134
bb133:
  store %olang.scope zeroinitializer, ptr %s32
  %t585 = load ptr, ptr %l2, !tbaa !29
  store ptr %t585, ptr %l212, !tbaa !29
  %t586 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t588 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eModeFirst(ptr %v0, ptr %s32, { i64, ptr } %t586)
  store %"compiler/msgs:Msg" %t588, ptr %l214
  br label %bb135
bb134:
  br label %bb139
bb135:
  %t589 = load ptr, ptr %l212, !tbaa !29
  %t590 = load %"compiler/msgs:Msg", ptr %l214
  %t591 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s32, ptr %t589, %"compiler/msgs:Msg" %t590)
  store i32 %t591, ptr %l215
  %t592 = icmp ne i32 %t591, 0
  br i1 %t592, label %bb137, label %ok.593
ok.593:
  br label %bb136
bb136:
  br label %bb138
bb137:
  %t594 = load i32, ptr %l215, !tbaa !23
  %t595 = lshr i32 %t594, 16
  %t596 = and i32 %t594, 65535
  %t597 = icmp eq i32 %t595, 1
  %t598 = select i1 %t597, i32 1, i32 0
  %t599 = icmp eq i32 %t594, 0
  %t600 = shl i32 %t598, 16
  %t601 = or i32 %t600, %t596
  %t602 = select i1 %t599, i32 0, i32 %t601
  call void @__olang_scope_close(ptr %s32)
  call void @__olang_scope_close(ptr %s31)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t604 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t602, 0
  store { i32, %"compiler/olang:CommandLine" } %t604, ptr %rv
  br label %ret
bb138:
  call void @__olang_scope_close(ptr %s32)
  br label %bb139
bb139:
  %t605 = load ptr, ptr %l2, !tbaa !29
  store ptr %t605, ptr %l217, !tbaa !29
  %t606 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t608 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotASource(ptr %v0, ptr %s31, { i64, ptr } %t606)
  store %"compiler/msgs:Msg" %t608, ptr %l219
  br label %bb140
bb140:
  %t609 = load ptr, ptr %l217, !tbaa !29
  %t610 = load %"compiler/msgs:Msg", ptr %l219
  %t611 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s31, ptr %t609, %"compiler/msgs:Msg" %t610)
  store i32 %t611, ptr %l220
  %t612 = icmp ne i32 %t611, 0
  br i1 %t612, label %bb142, label %ok.613
ok.613:
  br label %bb141
bb141:
  br label %bb143
bb142:
  %t614 = load i32, ptr %l220, !tbaa !23
  %t615 = lshr i32 %t614, 16
  %t616 = and i32 %t614, 65535
  %t617 = icmp eq i32 %t615, 1
  %t618 = select i1 %t617, i32 1, i32 0
  %t619 = icmp eq i32 %t614, 0
  %t620 = shl i32 %t618, 16
  %t621 = or i32 %t620, %t616
  %t622 = select i1 %t619, i32 0, i32 %t621
  call void @__olang_scope_close(ptr %s31)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t624 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t622, 0
  store { i32, %"compiler/olang:CommandLine" } %t624, ptr %rv
  br label %ret
bb143:
  call void @__olang_scope_close(ptr %s31)
  br label %bb144
bb144:
  %t625 = load ptr, ptr %lp3
  %t626 = getelementptr %"compiler/olang:CommandLine", ptr %t625, i32 0, i32 1
  %t627 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t629 = extractvalue { i64, ptr } %t627, 1
  %t630 = extractvalue { i64, ptr } %t627, 0
  %t631 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t630)
  call void @olang_textcopy(ptr %t631, ptr %t629, i64 %t630)
  %t632 = insertvalue { i64, ptr } undef, i64 %t630, 0
  %t633 = insertvalue { i64, ptr } %t632, ptr %t631, 1
  %t635 = extractvalue { i64, ptr } %t633, 0
  %t636 = extractvalue { i64, ptr } %t633, 1
  %t637 = mul i64 %t635, 1
  %t638 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t637)
  call void @llvm.memcpy.p0.p0.i64(ptr %t638, ptr %t636, i64 %t637, i1 false)
  %t639 = insertvalue { i64, ptr } undef, i64 %t635, 0
  %t640 = insertvalue { i64, ptr } %t639, ptr %t638, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v3, ptr %v3, ptr %t626, { i64, ptr } %t640)
  br label %bb145
bb145:
  %t643 = load ptr, ptr %lp3
  %t644 = getelementptr %"compiler/olang:CommandLine", ptr %t643, i32 0, i32 0
  %t645 = load i64, ptr %t644, !tbaa !24
  %t646 = load i64, ptr @G_2ecompiler_2folang_2eRun, !tbaa !24
  %t649 = icmp eq i64 %t645, %t646
  br i1 %t649, label %bb146, label %bb147
bb146:
  store i1 true, ptr %l229, !tbaa !21
  br label %bb148
bb147:
  %t651 = load ptr, ptr %lp3
  %t652 = getelementptr %"compiler/olang:CommandLine", ptr %t651, i32 0, i32 0
  %t653 = load i64, ptr %t652, !tbaa !24
  %t654 = load i64, ptr @G_2ecompiler_2folang_2eInterp, !tbaa !24
  %t657 = icmp eq i64 %t653, %t654
  store i1 %t657, ptr %l229, !tbaa !21
  br label %bb148
bb148:
  %t659 = load i1, ptr %l229, !tbaa !21
  br i1 %t659, label %bb149, label %bb150
bb149:
  br label %bb151
bb150:
  br label %bb158
bb151:
  store %olang.scope zeroinitializer, ptr %s35
  %t660 = load i64, ptr %l4, !tbaa !24
  %t661 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t663 = extractvalue { i64, ptr } %t661, 0
  %t666 = icmp slt i64 %t660, %t663
  %t668 = xor i1 %t666, true
  br i1 %t668, label %bb152, label %bb153
bb152:
  call void @__olang_scope_close(ptr %s35)
  br label %bb157
bb153:
  br label %bb154
bb154:
  %t670 = load ptr, ptr %lp3
  %t671 = getelementptr %"compiler/olang:CommandLine", ptr %t670, i32 0, i32 4
  %t672 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t672, ptr %l239, !tbaa !27
  %t673 = load i64, ptr %l4, !tbaa !24
  %t675 = getelementptr { i64, ptr }, ptr %l239, i32 0, i32 1
  %t676 = load ptr, ptr %t675, !tbaa !27
  %t677 = getelementptr { i64, ptr }, ptr %t676, i64 %t673
  %t678 = load { i64, ptr }, ptr %t677, !tbaa !37
  %t680 = extractvalue { i64, ptr } %t678, 1
  %t681 = extractvalue { i64, ptr } %t678, 0
  %t682 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t681)
  call void @olang_textcopy(ptr %t682, ptr %t680, i64 %t681)
  %t683 = insertvalue { i64, ptr } undef, i64 %t681, 0
  %t684 = insertvalue { i64, ptr } %t683, ptr %t682, 1
  %t686 = extractvalue { i64, ptr } %t684, 0
  %t687 = extractvalue { i64, ptr } %t684, 1
  %t688 = mul i64 %t686, 1
  %t689 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t688)
  call void @llvm.memcpy.p0.p0.i64(ptr %t689, ptr %t687, i64 %t688, i1 false)
  %t690 = insertvalue { i64, ptr } undef, i64 %t686, 0
  %t691 = insertvalue { i64, ptr } %t690, ptr %t689, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v3, ptr %v3, ptr %t671, { i64, ptr } %t691)
  br label %bb155
bb155:
  %t694 = load i64, ptr %l4, !tbaa !24
  %t696 = add i64 %t694, 1
  store i64 %t696, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s35)
  br label %bb156
bb156:
  br label %bb151
bb157:
  br label %bb158
bb158:
  call void @__olang_scope_close(ptr %s4)
  br label %bb159
bb159:
  br label %bb25
bb160:
  %t698 = load ptr, ptr %lp3
  %t699 = load %"compiler/olang:CommandLine", ptr %t698
  call void @__olang_scope_close(ptr %s0)
  %t701 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, %"compiler/olang:CommandLine" %t699, 1
  store { i32, %"compiler/olang:CommandLine" } %t701, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/olang:CommandLine" }, ptr %rv
  ret { i32, %"compiler/olang:CommandLine" } %rr
}

define dso_local { i32, %"compiler/olang:CommandLine" } @compiler_2folang_2ePrepare(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %lp3 = alloca ptr
  %l4 = alloca %"compiler/olang:CommandLine"
  %l8 = alloca %"compiler/olang:CommandLine"
  %l9 = alloca i32
  %l20 = alloca ptr
  %l21 = alloca %"compiler/msgs:Msg"
  %l22 = alloca i32
  %l26 = alloca i64
  %l28 = alloca ptr
  %l30 = alloca { i64, ptr }
  %l32 = alloca %"compiler/msgs:Msg"
  %l33 = alloca i32
  %l38 = alloca i1
  %l42 = alloca i1
  %l44 = alloca i64
  %l46 = alloca ptr
  %l48 = alloca { i64, ptr }
  %l50 = alloca %"compiler/msgs:Msg"
  %l51 = alloca i32
  %l58 = alloca i1
  %l62 = alloca i32
  %l68 = alloca ptr
  %l69 = alloca { i64, ptr }
  %l71 = alloca ptr
  %l72 = alloca %"compiler/target:Target"
  %l80 = alloca %"compiler/target:Target"
  %l81 = alloca i32
  %l88 = alloca i1
  %l92 = alloca ptr
  %l94 = alloca { i64, ptr }
  %l97 = alloca %"compiler/msgs:Msg"
  %l98 = alloca i32
  %l108 = alloca i32
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca { i32, %"compiler/olang:CommandLine" }
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t7 = call { i32, %"compiler/olang:CommandLine" } @compiler_2folang_2eParse(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, ptr %t2, ptr %t3)
  %t8 = extractvalue { i32, %"compiler/olang:CommandLine" } %t7, 1
  %t9 = extractvalue { i32, %"compiler/olang:CommandLine" } %t7, 0
  store i32 %t9, ptr %l9
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11
ok.11:
  store %"compiler/olang:CommandLine" %t8, ptr %l8
  br label %bb1
bb1:
  %t12 = load %"compiler/olang:CommandLine", ptr %l8
  store %"compiler/olang:CommandLine" %t12, ptr %l4
  br label %bb3
bb2:
  %t13 = load i32, ptr %l9, !tbaa !23
  %t14 = lshr i32 %t13, 16
  %t15 = and i32 %t13, 65535
  %t16 = icmp eq i32 %t14, 1
  %t17 = select i1 %t16, i32 1, i32 0
  %t18 = icmp eq i32 %t13, 0
  %t19 = shl i32 %t17, 16
  %t20 = or i32 %t19, %t15
  %t21 = select i1 %t18, i32 0, i32 %t20
  call void @__olang_scope_close(ptr %s0)
  %t23 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t21, 0
  store { i32, %"compiler/olang:CommandLine" } %t23, ptr %rv
  br label %ret
bb3:
  %t24 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 96, i64 8)
  store ptr %t24, ptr %lp3
  %t25 = load %"compiler/olang:CommandLine", ptr %l4
  %t26 = load ptr, ptr %lp3
  store %"compiler/olang:CommandLine" %t25, ptr %t26
  %t27 = load ptr, ptr %lp3
  %t28 = getelementptr %"compiler/olang:CommandLine", ptr %t27, i32 0, i32 0
  %t29 = load i64, ptr %t28, !tbaa !24
  %t30 = load i64, ptr @G_2ecompiler_2folang_2eHelp, !tbaa !24
  %t33 = icmp eq i64 %t29, %t30
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = load ptr, ptr %lp3
  %t36 = load %"compiler/olang:CommandLine", ptr %t35
  call void @__olang_scope_close(ptr %s0)
  %t38 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, %"compiler/olang:CommandLine" %t36, 1
  store { i32, %"compiler/olang:CommandLine" } %t38, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t39 = load ptr, ptr %lp3
  %t40 = getelementptr %"compiler/olang:CommandLine", ptr %t39, i32 0, i32 0
  %t41 = load i64, ptr %t40, !tbaa !24
  %t42 = load i64, ptr @G_2ecompiler_2folang_2eExplain, !tbaa !24
  %t45 = icmp eq i64 %t41, %t42
  br i1 %t45, label %bb7, label %bb8
bb7:
  %t47 = load ptr, ptr %lp3
  %t48 = getelementptr %"compiler/olang:CommandLine", ptr %t47, i32 0, i32 3
  %t49 = load i1, ptr %t48, !tbaa !21
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb9, label %bb10
bb8:
  br label %bb16
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t53 = load ptr, ptr %l2, !tbaa !29
  store ptr %t53, ptr %l20, !tbaa !29
  %t54 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eExplainNeedsRule(ptr %s3)
  store %"compiler/msgs:Msg" %t54, ptr %l21
  br label %bb11
bb10:
  br label %bb15
bb11:
  %t55 = load ptr, ptr %l20, !tbaa !29
  %t56 = load %"compiler/msgs:Msg", ptr %l21
  %t57 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s3, ptr %t55, %"compiler/msgs:Msg" %t56)
  store i32 %t57, ptr %l22
  %t58 = icmp ne i32 %t57, 0
  br i1 %t58, label %bb13, label %ok.59
ok.59:
  br label %bb12
bb12:
  br label %bb14
bb13:
  %t60 = load i32, ptr %l22, !tbaa !23
  %t61 = lshr i32 %t60, 16
  %t62 = and i32 %t60, 65535
  %t63 = icmp eq i32 %t61, 1
  %t64 = select i1 %t63, i32 1, i32 0
  %t65 = icmp eq i32 %t60, 0
  %t66 = shl i32 %t64, 16
  %t67 = or i32 %t66, %t62
  %t68 = select i1 %t65, i32 0, i32 %t67
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t70 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t68, 0
  store { i32, %"compiler/olang:CommandLine" } %t70, ptr %rv
  br label %ret
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb15:
  %t71 = load ptr, ptr %lp3
  %t72 = load %"compiler/olang:CommandLine", ptr %t71
  call void @__olang_scope_close(ptr %s0)
  %t74 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, %"compiler/olang:CommandLine" %t72, 1
  store { i32, %"compiler/olang:CommandLine" } %t74, ptr %rv
  br label %ret
bb16:
  %t75 = load ptr, ptr %lp3
  %t76 = getelementptr %"compiler/olang:CommandLine", ptr %t75, i32 0, i32 1
  %t78 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v3, ptr %t76)
  store i64 %t78, ptr %l26
  br label %bb17
bb17:
  %t79 = load i64, ptr %l26, !tbaa !24
  %t80 = icmp eq i64 %t79, 0
  br i1 %t80, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s4
  %t82 = load ptr, ptr %l2, !tbaa !29
  store ptr %t82, ptr %l28, !tbaa !29
  %t83 = load ptr, ptr %lp3
  %t84 = getelementptr %"compiler/olang:CommandLine", ptr %t83, i32 0, i32 0
  %t85 = load i64, ptr %t84, !tbaa !24
  %t87 = call { i64, ptr } @compiler_2folang_2emodeName(ptr %s4, i64 %t85)
  store { i64, ptr } %t87, ptr %l30
  br label %bb20
bb19:
  br label %bb25
bb20:
  %t88 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t89 = extractvalue { i64, ptr } %t88, 0
  %t90 = extractvalue { i64, ptr } %t88, 1
  %t91 = mul i64 %t89, 1
  %t92 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t91)
  call void @llvm.memcpy.p0.p0.i64(ptr %t92, ptr %t90, i64 %t91, i1 false)
  %t93 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t92, 1
  %t96 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eModeNeedsFile(ptr %s4, ptr %s4, { i64, ptr } %t94)
  store %"compiler/msgs:Msg" %t96, ptr %l32
  br label %bb21
bb21:
  %t97 = load ptr, ptr %l28, !tbaa !29
  %t98 = load %"compiler/msgs:Msg", ptr %l32
  %t99 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s4, ptr %t97, %"compiler/msgs:Msg" %t98)
  store i32 %t99, ptr %l33
  %t100 = icmp ne i32 %t99, 0
  br i1 %t100, label %bb23, label %ok.101
ok.101:
  br label %bb22
bb22:
  br label %bb24
bb23:
  %t102 = load i32, ptr %l33, !tbaa !23
  %t103 = lshr i32 %t102, 16
  %t104 = and i32 %t102, 65535
  %t105 = icmp eq i32 %t103, 1
  %t106 = select i1 %t105, i32 1, i32 0
  %t107 = icmp eq i32 %t102, 0
  %t108 = shl i32 %t106, 16
  %t109 = or i32 %t108, %t104
  %t110 = select i1 %t107, i32 0, i32 %t109
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t112 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t110, 0
  store { i32, %"compiler/olang:CommandLine" } %t112, ptr %rv
  br label %ret
bb24:
  call void @__olang_scope_close(ptr %s4)
  br label %bb25
bb25:
  %t113 = load ptr, ptr %lp3
  %t114 = getelementptr %"compiler/olang:CommandLine", ptr %t113, i32 0, i32 0
  %t115 = load i64, ptr %t114, !tbaa !24
  %t116 = load i64, ptr @G_2ecompiler_2folang_2eBuild, !tbaa !24
  %t119 = icmp eq i64 %t115, %t116
  br i1 %t119, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb28
bb27:
  %t121 = load ptr, ptr %lp3
  %t122 = getelementptr %"compiler/olang:CommandLine", ptr %t121, i32 0, i32 0
  %t123 = load i64, ptr %t122, !tbaa !24
  %t124 = load i64, ptr @G_2ecompiler_2folang_2eCompile, !tbaa !24
  %t127 = icmp eq i64 %t123, %t124
  store i1 %t127, ptr %l38, !tbaa !21
  br label %bb28
bb28:
  %t129 = load i1, ptr %l38, !tbaa !21
  br i1 %t129, label %bb29, label %bb30
bb29:
  %t130 = load ptr, ptr %lp3
  %t131 = getelementptr %"compiler/olang:CommandLine", ptr %t130, i32 0, i32 1
  %t133 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v3, ptr %t131)
  store i64 %t133, ptr %l44
  br label %bb31
bb30:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb32
bb31:
  %t134 = load i64, ptr %l44, !tbaa !24
  %t135 = icmp ne i64 %t134, 1
  store i1 %t135, ptr %l42, !tbaa !21
  br label %bb32
bb32:
  %t137 = load i1, ptr %l42, !tbaa !21
  br i1 %t137, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s5
  %t138 = load ptr, ptr %l2, !tbaa !29
  store ptr %t138, ptr %l46, !tbaa !29
  %t139 = load ptr, ptr %lp3
  %t140 = getelementptr %"compiler/olang:CommandLine", ptr %t139, i32 0, i32 0
  %t141 = load i64, ptr %t140, !tbaa !24
  %t143 = call { i64, ptr } @compiler_2folang_2emodeName(ptr %s5, i64 %t141)
  store { i64, ptr } %t143, ptr %l48
  br label %bb35
bb34:
  br label %bb40
bb35:
  %t144 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t145 = extractvalue { i64, ptr } %t144, 0
  %t146 = extractvalue { i64, ptr } %t144, 1
  %t147 = mul i64 %t145, 1
  %t148 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t147)
  call void @llvm.memcpy.p0.p0.i64(ptr %t148, ptr %t146, i64 %t147, i1 false)
  %t149 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t150 = insertvalue { i64, ptr } %t149, ptr %t148, 1
  %t152 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eModeOneFile(ptr %s5, ptr %s5, { i64, ptr } %t150)
  store %"compiler/msgs:Msg" %t152, ptr %l50
  br label %bb36
bb36:
  %t153 = load ptr, ptr %l46, !tbaa !29
  %t154 = load %"compiler/msgs:Msg", ptr %l50
  %t155 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s5, ptr %t153, %"compiler/msgs:Msg" %t154)
  store i32 %t155, ptr %l51
  %t156 = icmp ne i32 %t155, 0
  br i1 %t156, label %bb38, label %ok.157
ok.157:
  br label %bb37
bb37:
  br label %bb39
bb38:
  %t158 = load i32, ptr %l51, !tbaa !23
  %t159 = lshr i32 %t158, 16
  %t160 = and i32 %t158, 65535
  %t161 = icmp eq i32 %t159, 1
  %t162 = select i1 %t161, i32 1, i32 0
  %t163 = icmp eq i32 %t158, 0
  %t164 = shl i32 %t162, 16
  %t165 = or i32 %t164, %t160
  %t166 = select i1 %t163, i32 0, i32 %t165
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t168 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t166, 0
  store { i32, %"compiler/olang:CommandLine" } %t168, ptr %rv
  br label %ret
bb39:
  call void @__olang_scope_close(ptr %s5)
  br label %bb40
bb40:
  %t169 = load ptr, ptr %lp3
  %t170 = getelementptr %"compiler/olang:CommandLine", ptr %t169, i32 0, i32 0
  %t171 = load i64, ptr %t170, !tbaa !24
  %t172 = load i64, ptr @G_2ecompiler_2folang_2eFormat, !tbaa !24
  %t175 = icmp eq i64 %t171, %t172
  br i1 %t175, label %bb41, label %bb42
bb41:
  %t177 = load ptr, ptr %lp3
  %t178 = load %"compiler/olang:CommandLine", ptr %t177
  call void @__olang_scope_close(ptr %s0)
  %t180 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, %"compiler/olang:CommandLine" %t178, 1
  store { i32, %"compiler/olang:CommandLine" } %t180, ptr %rv
  br label %ret
bb42:
  br label %bb43
bb43:
  %t181 = load ptr, ptr %lp3
  %t182 = getelementptr %"compiler/olang:CommandLine", ptr %t181, i32 0, i32 7
  %t183 = load { i64, ptr }, ptr %t182, !tbaa !27
  %t185 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s0, { i64, ptr } %t183, { i64, ptr } { i64 0, ptr @.d52 })
  store i1 %t185, ptr %l58
  br label %bb44
bb44:
  %t186 = load i1, ptr %l58, !tbaa !21
  %t187 = xor i1 %t186, true
  br i1 %t187, label %bb45, label %bb46
bb45:
  %t189 = load ptr, ptr %lp3
  %t190 = getelementptr %"compiler/olang:CommandLine", ptr %t189, i32 0, i32 7
  %t191 = load { i64, ptr }, ptr %t190, !tbaa !27
  %t192 = load ptr, ptr %l2, !tbaa !29
  %t195 = call i32 @compiler_2folang_2echeckOutput(ptr %v3, ptr %v2, { i64, ptr } %t191, ptr %t192)
  store i32 %t195, ptr %l62
  %t196 = icmp ne i32 %t195, 0
  br i1 %t196, label %bb48, label %ok.197
ok.197:
  br label %bb47
bb46:
  br label %bb50
bb47:
  br label %bb49
bb48:
  %t198 = load i32, ptr %l62, !tbaa !23
  %t199 = lshr i32 %t198, 16
  %t200 = and i32 %t198, 65535
  %t201 = icmp eq i32 %t199, 1
  %t202 = select i1 %t201, i32 1, i32 0
  %t203 = icmp eq i32 %t198, 0
  %t204 = shl i32 %t202, 16
  %t205 = or i32 %t204, %t200
  %t206 = select i1 %t203, i32 0, i32 %t205
  call void @__olang_scope_close(ptr %s0)
  %t208 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t206, 0
  store { i32, %"compiler/olang:CommandLine" } %t208, ptr %rv
  br label %ret
bb49:
  br label %bb50
bb50:
  %t209 = load ptr, ptr %l1, !tbaa !29
  %t210 = load ptr, ptr %lp3
  %t211 = getelementptr %"compiler/olang:CommandLine", ptr %t210, i32 0, i32 7
  %t212 = load { i64, ptr }, ptr %t211, !tbaa !27
  %t214 = extractvalue { i64, ptr } %t212, 1
  %t215 = extractvalue { i64, ptr } %t212, 0
  %t216 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t215)
  call void @olang_textcopy(ptr %t216, ptr %t214, i64 %t215)
  %t217 = insertvalue { i64, ptr } undef, i64 %t215, 0
  %t218 = insertvalue { i64, ptr } %t217, ptr %t216, 1
  %t220 = extractvalue { i64, ptr } %t218, 0
  %t221 = extractvalue { i64, ptr } %t218, 1
  %t222 = mul i64 %t220, 1
  %t223 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t222)
  call void @llvm.memcpy.p0.p0.i64(ptr %t223, ptr %t221, i64 %t222, i1 false)
  %t224 = insertvalue { i64, ptr } undef, i64 %t220, 0
  %t225 = insertvalue { i64, ptr } %t224, ptr %t223, 1
  %t228 = getelementptr %"compiler/build:Config", ptr %t209, i32 0, i32 12
  store { i64, ptr } %t225, ptr %t228, !tbaa !27
  %t229 = load ptr, ptr %l1, !tbaa !29
  store ptr %t229, ptr %l68, !tbaa !29
  %t230 = call { i64, ptr } @compiler_2ftarget_2eFindClang(ptr %v1)
  store { i64, ptr } %t230, ptr %l69
  br label %bb51
bb51:
  %t231 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t232 = extractvalue { i64, ptr } %t231, 0
  %t233 = extractvalue { i64, ptr } %t231, 1
  %t234 = mul i64 %t232, 1
  %t235 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t234)
  call void @llvm.memcpy.p0.p0.i64(ptr %t235, ptr %t233, i64 %t234, i1 false)
  %t236 = insertvalue { i64, ptr } undef, i64 %t232, 0
  %t237 = insertvalue { i64, ptr } %t236, ptr %t235, 1
  %t239 = load ptr, ptr %l68, !tbaa !29
  %t240 = getelementptr %"compiler/build:Config", ptr %t239, i32 0, i32 1
  store { i64, ptr } %t237, ptr %t240, !tbaa !27
  %t241 = load ptr, ptr %l1, !tbaa !29
  store ptr %t241, ptr %l71, !tbaa !29
  %t242 = load ptr, ptr %lp3
  %t243 = getelementptr %"compiler/olang:CommandLine", ptr %t242, i32 0, i32 6
  %t244 = load { i64, ptr }, ptr %t243, !tbaa !27
  %t245 = load ptr, ptr %l1, !tbaa !29
  %t247 = getelementptr %"compiler/build:Config", ptr %t245, i32 0, i32 1
  %t248 = load { i64, ptr }, ptr %t247, !tbaa !27
  %t249 = load ptr, ptr %lp3
  %t250 = getelementptr %"compiler/olang:CommandLine", ptr %t249, i32 0, i32 0
  %t251 = load i64, ptr %t250, !tbaa !24
  %t252 = load i64, ptr @G_2ecompiler_2folang_2eInterp, !tbaa !24
  %t255 = icmp eq i64 %t251, %t252
  %t256 = load ptr, ptr %l2, !tbaa !29
  %t261 = call { i32, %"compiler/target:Target" } @compiler_2ftarget_2eResolve(ptr %v3, ptr %v1, ptr %v2, ptr %v1, { i64, ptr } %t244, { i64, ptr } %t248, i1 %t255, ptr %t256)
  %t262 = extractvalue { i32, %"compiler/target:Target" } %t261, 1
  %t263 = extractvalue { i32, %"compiler/target:Target" } %t261, 0
  store i32 %t263, ptr %l81
  %t264 = icmp ne i32 %t263, 0
  br i1 %t264, label %bb53, label %ok.265
ok.265:
  store %"compiler/target:Target" %t262, ptr %l80
  br label %bb52
bb52:
  %t266 = load %"compiler/target:Target", ptr %l80
  store %"compiler/target:Target" %t266, ptr %l72
  br label %bb57
bb53:
  %t267 = load i32, ptr %l81, !tbaa !23
  %t268 = ashr i32 %t267, 16
  %t270 = icmp eq i32 %t268, 1
  br i1 %t270, label %bb54, label %bb55
bb54:
  br label %bb56
bb55:
  %t272 = load i32, ptr %l81, !tbaa !23
  %t273 = lshr i32 %t272, 16
  %t274 = and i32 %t272, 65535
  %t275 = icmp eq i32 %t273, 1
  %t276 = select i1 %t275, i32 0, i32 0
  %t277 = icmp eq i32 %t272, 0
  %t278 = shl i32 %t276, 16
  %t279 = or i32 %t278, %t274
  %t280 = select i1 %t277, i32 0, i32 %t279
  call void @__olang_scope_close(ptr %s0)
  %t282 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t280, 0
  store { i32, %"compiler/olang:CommandLine" } %t282, ptr %rv
  br label %ret
bb56:
  call void @__olang_scope_close(ptr %s0)
  %t284 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/olang:CommandLine" } %t284, ptr %rv
  br label %ret
bb57:
  %t285 = load %"compiler/target:Target", ptr %l72
  %t286 = load ptr, ptr %l71, !tbaa !29
  %t287 = getelementptr %"compiler/build:Config", ptr %t286, i32 0, i32 2
  store %"compiler/target:Target" %t285, ptr %t287
  %t288 = load ptr, ptr %l1, !tbaa !29
  %t290 = getelementptr %"compiler/build:Config", ptr %t288, i32 0, i32 2
  %t291 = getelementptr %"compiler/target:Target", ptr %t290, i32 0, i32 9
  %t292 = load i1, ptr %t291, !tbaa !21
  br i1 %t292, label %bb58, label %bb59
bb58:
  %t294 = load ptr, ptr %lp3
  %t295 = getelementptr %"compiler/olang:CommandLine", ptr %t294, i32 0, i32 0
  %t296 = load i64, ptr %t295, !tbaa !24
  %t297 = load i64, ptr @G_2ecompiler_2folang_2eCompile, !tbaa !24
  %t300 = icmp ne i64 %t296, %t297
  store i1 %t300, ptr %l88, !tbaa !21
  br label %bb60
bb59:
  store i1 false, ptr %l88, !tbaa !21
  br label %bb60
bb60:
  %t302 = load i1, ptr %l88, !tbaa !21
  br i1 %t302, label %bb61, label %bb62
bb61:
  store %olang.scope zeroinitializer, ptr %s10
  %t303 = load ptr, ptr %l2, !tbaa !29
  store ptr %t303, ptr %l92, !tbaa !29
  %t304 = load ptr, ptr %lp3
  %t305 = getelementptr %"compiler/olang:CommandLine", ptr %t304, i32 0, i32 0
  %t306 = load i64, ptr %t305, !tbaa !24
  %t308 = call { i64, ptr } @compiler_2folang_2emodeName(ptr %s10, i64 %t306)
  store { i64, ptr } %t308, ptr %l94
  br label %bb63
bb62:
  br label %bb68
bb63:
  %t309 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t310 = extractvalue { i64, ptr } %t309, 0
  %t311 = extractvalue { i64, ptr } %t309, 1
  %t312 = mul i64 %t310, 1
  %t313 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t312)
  call void @llvm.memcpy.p0.p0.i64(ptr %t313, ptr %t311, i64 %t312, i1 false)
  %t314 = insertvalue { i64, ptr } undef, i64 %t310, 0
  %t315 = insertvalue { i64, ptr } %t314, ptr %t313, 1
  %t316 = load ptr, ptr %lp3
  %t317 = getelementptr %"compiler/olang:CommandLine", ptr %t316, i32 0, i32 6
  %t318 = load { i64, ptr }, ptr %t317, !tbaa !27
  %t321 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetForeignMode(ptr %s10, ptr %v3, ptr %s10, { i64, ptr } %t315, { i64, ptr } %t318)
  store %"compiler/msgs:Msg" %t321, ptr %l97
  br label %bb64
bb64:
  %t322 = load ptr, ptr %l92, !tbaa !29
  %t323 = load %"compiler/msgs:Msg", ptr %l97
  %t324 = call i32 @compiler_2folang_2eusage(ptr %v2, ptr %s10, ptr %t322, %"compiler/msgs:Msg" %t323)
  store i32 %t324, ptr %l98
  %t325 = icmp ne i32 %t324, 0
  br i1 %t325, label %bb66, label %ok.326
ok.326:
  br label %bb65
bb65:
  br label %bb67
bb66:
  %t327 = load i32, ptr %l98, !tbaa !23
  %t328 = lshr i32 %t327, 16
  %t329 = and i32 %t327, 65535
  %t330 = icmp eq i32 %t328, 1
  %t331 = select i1 %t330, i32 1, i32 0
  %t332 = icmp eq i32 %t327, 0
  %t333 = shl i32 %t331, 16
  %t334 = or i32 %t333, %t329
  %t335 = select i1 %t332, i32 0, i32 %t334
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  %t337 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t335, 0
  store { i32, %"compiler/olang:CommandLine" } %t337, ptr %rv
  br label %ret
bb67:
  call void @__olang_scope_close(ptr %s10)
  br label %bb68
bb68:
  %t338 = load ptr, ptr %l1, !tbaa !29
  %t339 = load ptr, ptr %lp3
  %t340 = getelementptr %"compiler/olang:CommandLine", ptr %t339, i32 0, i32 0
  %t341 = load i64, ptr %t340, !tbaa !24
  %t342 = load i64, ptr @G_2ecompiler_2folang_2eTest, !tbaa !24
  %t345 = icmp eq i64 %t341, %t342
  %t348 = getelementptr %"compiler/build:Config", ptr %t338, i32 0, i32 8
  store i1 %t345, ptr %t348, !tbaa !21
  %t349 = load ptr, ptr %l1, !tbaa !29
  %t350 = load ptr, ptr %l1, !tbaa !29
  %t352 = getelementptr %"compiler/build:Config", ptr %t350, i32 0, i32 8
  %t353 = load i1, ptr %t352, !tbaa !21
  %t354 = load ptr, ptr %l2, !tbaa !29
  %t358 = call i32 @compiler_2folang_2ebuiltins(ptr %v1, ptr %v2, ptr %t349, i1 %t353, ptr %t354)
  store i32 %t358, ptr %l108
  %t359 = icmp ne i32 %t358, 0
  br i1 %t359, label %bb70, label %ok.360
ok.360:
  br label %bb69
bb69:
  br label %bb71
bb70:
  %t361 = load i32, ptr %l108, !tbaa !23
  %t362 = lshr i32 %t361, 16
  %t363 = and i32 %t361, 65535
  %t364 = icmp eq i32 %t362, 1
  %t365 = select i1 %t364, i32 1, i32 0
  %t366 = icmp eq i32 %t361, 0
  %t367 = shl i32 %t365, 16
  %t368 = or i32 %t367, %t363
  %t369 = select i1 %t366, i32 0, i32 %t368
  call void @__olang_scope_close(ptr %s0)
  %t371 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, i32 %t369, 0
  store { i32, %"compiler/olang:CommandLine" } %t371, ptr %rv
  br label %ret
bb71:
  %t372 = load ptr, ptr %lp3
  %t373 = load %"compiler/olang:CommandLine", ptr %t372
  call void @__olang_scope_close(ptr %s0)
  %t375 = insertvalue { i32, %"compiler/olang:CommandLine" } zeroinitializer, %"compiler/olang:CommandLine" %t373, 1
  store { i32, %"compiler/olang:CommandLine" } %t375, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/olang:CommandLine" }, ptr %rv
  ret { i32, %"compiler/olang:CommandLine" } %rr
}

define dso_local void @compiler_2folang_2eRun_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr @G_2ecompiler_2folang_2eRun, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2eTest_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 3, ptr @G_2ecompiler_2folang_2eTest, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2folang_2ebuildInputs(ptr %v0, ptr %v1, ptr %a0, i1 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"std/os:FileInfo"
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/target:Target"
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i32
  %l9 = alloca { i64, ptr }
  %l12 = alloca %"std/os:FileInfo"
  %l14 = alloca %"std/os:FileInfo"
  %l15 = alloca i32
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i32
  %l25 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca i64
  %l34 = alloca i1
  %l36 = alloca i1
  %l38 = alloca i1
  %l39 = alloca i1
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %s0, ptr %s0, { i64, ptr } { i64 14, ptr @.d53 })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l8
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  store { i64, ptr } %t2, ptr %l7
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t6, ptr %l6, !tbaa !27
  br label %bb4
bb2:
  br label %bb3
bb3:
  store { i64, ptr } { i64 0, ptr @.d54 }, ptr %l9, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t10 = extractvalue { i64, ptr } %t7, 1
  %t11 = mul i64 %t9, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t10, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l6, !tbaa !27
  br label %bb4
bb4:
  %t16 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t16, ptr %l2, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t19 = call { i32, %"std/os:FileInfo" } @std_2fos_2eStat(ptr %s0, { i64, ptr } %t17)
  %t20 = extractvalue { i32, %"std/os:FileInfo" } %t19, 1
  %t21 = extractvalue { i32, %"std/os:FileInfo" } %t19, 0
  store i32 %t21, ptr %l15
  %t22 = icmp ne i32 %t21, 0
  br i1 %t22, label %bb6, label %ok.23
ok.23:
  store %"std/os:FileInfo" %t20, ptr %l14
  br label %bb5
bb5:
  %t24 = load %"std/os:FileInfo", ptr %l14
  store %"std/os:FileInfo" %t24, ptr %l12
  br label %bb10
bb6:
  %t25 = load i32, ptr %l15, !tbaa !23
  %t26 = ashr i32 %t25, 16
  %t28 = icmp eq i32 %t26, 1
  br i1 %t28, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @.c55)
  unreachable
bb9:
  store { i64, ptr } { i64 0, ptr @.d56 }, ptr %l18, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t30, ptr %l19, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l20, !tbaa !24
  %t33 = load i64, ptr %l20, !tbaa !24
  %t34 = mul i64 %t33, 1
  %t35 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t34)
  %t36 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t35, 1
  store { i64, ptr } %t37, ptr %l21, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = load i64, ptr %l20, !tbaa !24
  %t43 = mul i64 %t42, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t39, ptr %t41, i64 %t43, i1 false)
  %t44 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t44, ptr %l19, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t45 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t45, ptr %rv
  br label %ret
bb10:
  %t46 = load %"std/os:FileInfo", ptr %l12
  store %"std/os:FileInfo" %t46, ptr %l3
  %t47 = call { i32, { i64, ptr } } @std_2fos_2eCwd(ptr %s0)
  %t48 = extractvalue { i32, { i64, ptr } } %t47, 1
  %t49 = extractvalue { i32, { i64, ptr } } %t47, 0
  store i32 %t49, ptr %l24
  %t50 = icmp ne i32 %t49, 0
  br i1 %t50, label %bb12, label %ok.51
ok.51:
  store { i64, ptr } %t48, ptr %l23
  br label %bb11
bb11:
  %t52 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t52, ptr %l22, !tbaa !27
  br label %bb14
bb12:
  br label %bb13
bb13:
  store { i64, ptr } { i64 0, ptr @.d57 }, ptr %l25, !tbaa !27
  %t53 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t53, 0
  %t56 = extractvalue { i64, ptr } %t53, 1
  %t57 = mul i64 %t55, 1
  %t58 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t57)
  call void @llvm.memcpy.p0.p0.i64(ptr %t58, ptr %t56, i64 %t57, i1 false)
  %t59 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t58, 1
  store { i64, ptr } %t60, ptr %l22, !tbaa !27
  br label %bb14
bb14:
  %t62 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t62, ptr %l4, !tbaa !27
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/build:Config", ptr %t63, i32 0, i32 2
  %t66 = load %"compiler/target:Target", ptr %t65
  store %"compiler/target:Target" %t66, ptr %l5
  %t68 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t68, ptr %l30, !tbaa !27
  %t69 = getelementptr %"std/os:FileInfo", ptr %l3, i32 0, i32 1
  %t70 = load i64, ptr %t69, !tbaa !24
  store i64 %t70, ptr %l31, !tbaa !24
  %t71 = getelementptr %"std/os:FileInfo", ptr %l3, i32 0, i32 2
  %t72 = load i64, ptr %t71, !tbaa !24
  store i64 %t72, ptr %l32, !tbaa !24
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/build:Config", ptr %t73, i32 0, i32 4
  %t76 = load i1, ptr %t75, !tbaa !21
  store i1 %t76, ptr %l34, !tbaa !21
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/build:Config", ptr %t77, i32 0, i32 5
  %t80 = load i1, ptr %t79, !tbaa !21
  store i1 %t80, ptr %l36, !tbaa !21
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/build:Config", ptr %t81, i32 0, i32 6
  %t84 = load i1, ptr %t83, !tbaa !21
  store i1 %t84, ptr %l38, !tbaa !21
  store i1 %a1, ptr %l39, !tbaa !21
  %t86 = getelementptr %"compiler/target:Target", ptr %l5, i32 0, i32 1
  %t87 = load { i64, ptr }, ptr %t86, !tbaa !27
  store { i64, ptr } %t87, ptr %l40, !tbaa !27
  %t88 = getelementptr %"compiler/target:Target", ptr %l5, i32 0, i32 2
  %t89 = load { i64, ptr }, ptr %t88, !tbaa !27
  store { i64, ptr } %t89, ptr %l41, !tbaa !27
  %t90 = getelementptr %"compiler/target:Target", ptr %l5, i32 0, i32 4
  %t91 = load { i64, ptr }, ptr %t90, !tbaa !27
  store { i64, ptr } %t91, ptr %l42, !tbaa !27
  %t92 = getelementptr %"compiler/target:Target", ptr %l5, i32 0, i32 5
  %t93 = load { i64, ptr }, ptr %t92, !tbaa !27
  store { i64, ptr } %t93, ptr %l43, !tbaa !27
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/build:Config", ptr %t94, i32 0, i32 3
  %t98 = call { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eFingerprint(ptr %v0, ptr %s0, ptr %t96)
  store { i64, ptr } %t98, ptr %l46
  br label %bb15
bb15:
  %t99 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t99, ptr %l47, !tbaa !27
  %t100 = call { i64, ptr } @compiler_2fload_2eStdDir(ptr %s0)
  store { i64, ptr } %t100, ptr %l48
  br label %bb16
bb16:
  %t101 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t101, 1
  %t103 = extractvalue { i64, ptr } %t101, 0
  %t104 = extractvalue { i64, ptr } { i64 1, ptr @.d58 }, 1
  %t105 = extractvalue { i64, ptr } { i64 1, ptr @.d58 }, 0
  %t106 = add i64 %t103, %t105
  %t107 = load i64, ptr %l31, !tbaa !24
  %t108 = call i64 @__olang_fmt_i64(ptr null, i64 %t107)
  %t109 = add i64 %t106, %t108
  %t110 = extractvalue { i64, ptr } { i64 1, ptr @.d59 }, 1
  %t111 = extractvalue { i64, ptr } { i64 1, ptr @.d59 }, 0
  %t112 = add i64 %t109, %t111
  %t113 = load i64, ptr %l32, !tbaa !24
  %t114 = call i64 @__olang_fmt_i64(ptr null, i64 %t113)
  %t115 = add i64 %t112, %t114
  %t116 = extractvalue { i64, ptr } { i64 1, ptr @.d60 }, 1
  %t117 = extractvalue { i64, ptr } { i64 1, ptr @.d60 }, 0
  %t118 = add i64 %t115, %t117
  %t119 = load i1, ptr %l34, !tbaa !21
  %t120 = select i1 %t119, ptr @.c61, ptr @.c62
  %t121 = select i1 %t119, i64 4, i64 5
  %t122 = add i64 %t118, %t121
  %t123 = extractvalue { i64, ptr } { i64 1, ptr @.d63 }, 1
  %t124 = extractvalue { i64, ptr } { i64 1, ptr @.d63 }, 0
  %t125 = add i64 %t122, %t124
  %t126 = load i1, ptr %l36, !tbaa !21
  %t127 = select i1 %t126, ptr @.c61, ptr @.c62
  %t128 = select i1 %t126, i64 4, i64 5
  %t129 = add i64 %t125, %t128
  %t130 = extractvalue { i64, ptr } { i64 1, ptr @.d64 }, 1
  %t131 = extractvalue { i64, ptr } { i64 1, ptr @.d64 }, 0
  %t132 = add i64 %t129, %t131
  %t133 = load i1, ptr %l38, !tbaa !21
  %t134 = select i1 %t133, ptr @.c61, ptr @.c62
  %t135 = select i1 %t133, i64 4, i64 5
  %t136 = add i64 %t132, %t135
  %t137 = extractvalue { i64, ptr } { i64 1, ptr @.d65 }, 1
  %t138 = extractvalue { i64, ptr } { i64 1, ptr @.d65 }, 0
  %t139 = add i64 %t136, %t138
  %t140 = load i1, ptr %l39, !tbaa !21
  %t141 = select i1 %t140, ptr @.c61, ptr @.c62
  %t142 = select i1 %t140, i64 4, i64 5
  %t143 = add i64 %t139, %t142
  %t144 = extractvalue { i64, ptr } { i64 1, ptr @.d66 }, 1
  %t145 = extractvalue { i64, ptr } { i64 1, ptr @.d66 }, 0
  %t146 = add i64 %t143, %t145
  %t147 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t148 = extractvalue { i64, ptr } %t147, 1
  %t149 = extractvalue { i64, ptr } %t147, 0
  %t150 = add i64 %t146, %t149
  %t151 = extractvalue { i64, ptr } { i64 1, ptr @.d67 }, 1
  %t152 = extractvalue { i64, ptr } { i64 1, ptr @.d67 }, 0
  %t153 = add i64 %t150, %t152
  %t154 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t155 = extractvalue { i64, ptr } %t154, 1
  %t156 = extractvalue { i64, ptr } %t154, 0
  %t157 = add i64 %t153, %t156
  %t158 = extractvalue { i64, ptr } { i64 1, ptr @.d68 }, 1
  %t159 = extractvalue { i64, ptr } { i64 1, ptr @.d68 }, 0
  %t160 = add i64 %t157, %t159
  %t161 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t162 = extractvalue { i64, ptr } %t161, 1
  %t163 = extractvalue { i64, ptr } %t161, 0
  %t164 = add i64 %t160, %t163
  %t165 = extractvalue { i64, ptr } { i64 1, ptr @.d69 }, 1
  %t166 = extractvalue { i64, ptr } { i64 1, ptr @.d69 }, 0
  %t167 = add i64 %t164, %t166
  %t168 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t168, 1
  %t170 = extractvalue { i64, ptr } %t168, 0
  %t171 = add i64 %t167, %t170
  %t172 = extractvalue { i64, ptr } { i64 1, ptr @.d70 }, 1
  %t173 = extractvalue { i64, ptr } { i64 1, ptr @.d70 }, 0
  %t174 = add i64 %t171, %t173
  %t175 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t176 = extractvalue { i64, ptr } %t175, 1
  %t177 = extractvalue { i64, ptr } %t175, 0
  %t178 = add i64 %t174, %t177
  %t179 = extractvalue { i64, ptr } { i64 1, ptr @.d71 }, 1
  %t180 = extractvalue { i64, ptr } { i64 1, ptr @.d71 }, 0
  %t181 = add i64 %t178, %t180
  %t182 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t183 = extractvalue { i64, ptr } %t182, 1
  %t184 = extractvalue { i64, ptr } %t182, 0
  %t185 = add i64 %t181, %t184
  %t186 = extractvalue { i64, ptr } { i64 1, ptr @.d72 }, 1
  %t187 = extractvalue { i64, ptr } { i64 1, ptr @.d72 }, 0
  %t188 = add i64 %t185, %t187
  %t189 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t190 = extractvalue { i64, ptr } %t189, 1
  %t191 = extractvalue { i64, ptr } %t189, 0
  %t192 = add i64 %t188, %t191
  %t193 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t192)
  call void @olang_textcopy(ptr %t193, ptr %t102, i64 %t103)
  %t194 = getelementptr i8, ptr %t193, i64 %t103
  call void @olang_textcopy(ptr %t194, ptr %t104, i64 %t105)
  %t195 = getelementptr i8, ptr %t194, i64 %t105
  %t196 = call i64 @__olang_fmt_i64(ptr %t195, i64 %t107)
  %t197 = getelementptr i8, ptr %t195, i64 %t108
  call void @olang_textcopy(ptr %t197, ptr %t110, i64 %t111)
  %t198 = getelementptr i8, ptr %t197, i64 %t111
  %t199 = call i64 @__olang_fmt_i64(ptr %t198, i64 %t113)
  %t200 = getelementptr i8, ptr %t198, i64 %t114
  call void @olang_textcopy(ptr %t200, ptr %t116, i64 %t117)
  %t201 = getelementptr i8, ptr %t200, i64 %t117
  call void @olang_textcopy(ptr %t201, ptr %t120, i64 %t121)
  %t202 = getelementptr i8, ptr %t201, i64 %t121
  call void @olang_textcopy(ptr %t202, ptr %t123, i64 %t124)
  %t203 = getelementptr i8, ptr %t202, i64 %t124
  call void @olang_textcopy(ptr %t203, ptr %t127, i64 %t128)
  %t204 = getelementptr i8, ptr %t203, i64 %t128
  call void @olang_textcopy(ptr %t204, ptr %t130, i64 %t131)
  %t205 = getelementptr i8, ptr %t204, i64 %t131
  call void @olang_textcopy(ptr %t205, ptr %t134, i64 %t135)
  %t206 = getelementptr i8, ptr %t205, i64 %t135
  call void @olang_textcopy(ptr %t206, ptr %t137, i64 %t138)
  %t207 = getelementptr i8, ptr %t206, i64 %t138
  call void @olang_textcopy(ptr %t207, ptr %t141, i64 %t142)
  %t208 = getelementptr i8, ptr %t207, i64 %t142
  call void @olang_textcopy(ptr %t208, ptr %t144, i64 %t145)
  %t209 = getelementptr i8, ptr %t208, i64 %t145
  call void @olang_textcopy(ptr %t209, ptr %t148, i64 %t149)
  %t210 = getelementptr i8, ptr %t209, i64 %t149
  call void @olang_textcopy(ptr %t210, ptr %t151, i64 %t152)
  %t211 = getelementptr i8, ptr %t210, i64 %t152
  call void @olang_textcopy(ptr %t211, ptr %t155, i64 %t156)
  %t212 = getelementptr i8, ptr %t211, i64 %t156
  call void @olang_textcopy(ptr %t212, ptr %t158, i64 %t159)
  %t213 = getelementptr i8, ptr %t212, i64 %t159
  call void @olang_textcopy(ptr %t213, ptr %t162, i64 %t163)
  %t214 = getelementptr i8, ptr %t213, i64 %t163
  call void @olang_textcopy(ptr %t214, ptr %t165, i64 %t166)
  %t215 = getelementptr i8, ptr %t214, i64 %t166
  call void @olang_textcopy(ptr %t215, ptr %t169, i64 %t170)
  %t216 = getelementptr i8, ptr %t215, i64 %t170
  call void @olang_textcopy(ptr %t216, ptr %t172, i64 %t173)
  %t217 = getelementptr i8, ptr %t216, i64 %t173
  call void @olang_textcopy(ptr %t217, ptr %t176, i64 %t177)
  %t218 = getelementptr i8, ptr %t217, i64 %t177
  call void @olang_textcopy(ptr %t218, ptr %t179, i64 %t180)
  %t219 = getelementptr i8, ptr %t218, i64 %t180
  call void @olang_textcopy(ptr %t219, ptr %t183, i64 %t184)
  %t220 = getelementptr i8, ptr %t219, i64 %t184
  call void @olang_textcopy(ptr %t220, ptr %t186, i64 %t187)
  %t221 = getelementptr i8, ptr %t220, i64 %t187
  call void @olang_textcopy(ptr %t221, ptr %t190, i64 %t191)
  %t222 = insertvalue { i64, ptr } undef, i64 %t192, 0
  %t223 = insertvalue { i64, ptr } %t222, ptr %t193, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t223, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2folang_2ebuiltins(ptr %v0, ptr %v1, ptr %a0, i1 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/target:Target"
  %l22 = alloca i1
  %l23 = alloca ptr
  %l25 = alloca %"compiler/msgs:Msg"
  %l26 = alloca i32
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l39 = alloca i64
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = insertvalue [8 x { i64, ptr }] undef, { i64, ptr } { i64 8, ptr @.d73 }, 0
  %t2 = insertvalue [8 x { i64, ptr }] %t1, { i64, ptr } { i64 10, ptr @.d74 }, 1
  %t3 = insertvalue [8 x { i64, ptr }] %t2, { i64, ptr } { i64 9, ptr @.d75 }, 2
  %t4 = insertvalue [8 x { i64, ptr }] %t3, { i64, ptr } { i64 16, ptr @.d76 }, 3
  %t5 = insertvalue [8 x { i64, ptr }] %t4, { i64, ptr } { i64 12, ptr @.d77 }, 4
  %t6 = insertvalue [8 x { i64, ptr }] %t5, { i64, ptr } { i64 10, ptr @.d78 }, 5
  %t7 = insertvalue [8 x { i64, ptr }] %t6, { i64, ptr } { i64 9, ptr @.d79 }, 6
  %t8 = insertvalue [8 x { i64, ptr }] %t7, { i64, ptr } { i64 9, ptr @.d80 }, 7
  %t10 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 128, i64 8)
  store [8 x { i64, ptr }] %t8, ptr %t10
  store ptr %t10, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  %t12 = load ptr, ptr %l3
  store i64 8, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t15 = load i64, ptr %l4, !tbaa !24
  %t16 = load i64, ptr %l5, !tbaa !24
  %t19 = icmp slt i64 %t15, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb3:
  br label %bb4
bb4:
  %t23 = load ptr, ptr %l3
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = getelementptr [8 x { i64, ptr }], ptr %t23, i64 0, i64 %t24
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !37
  store { i64, ptr } %t28, ptr %l6, !tbaa !27
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/build:Config", ptr %t30, i32 0, i32 3
  %t33 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t34 = load ptr, ptr @__olang_prog_scope
  %t37 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eHas(ptr %v0, ptr %t34, ptr %t32, { i64, ptr } %t33)
  store i1 %t37, ptr %l22
  br label %bb5
bb5:
  %t38 = load i1, ptr %l22, !tbaa !21
  br i1 %t38, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  store ptr %a2, ptr %l23, !tbaa !29
  %t40 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t41 = load ptr, ptr @__olang_prog_scope
  %t43 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefineBuiltin(ptr %t41, ptr %s3, { i64, ptr } %t40)
  store %"compiler/msgs:Msg" %t43, ptr %l25
  br label %bb8
bb7:
  br label %bb12
bb8:
  %t44 = load ptr, ptr %l23, !tbaa !29
  %t45 = load %"compiler/msgs:Msg", ptr %l25
  %t46 = call i32 @compiler_2folang_2eusage(ptr %v1, ptr %s3, ptr %t44, %"compiler/msgs:Msg" %t45)
  store i32 %t46, ptr %l26
  %t47 = icmp ne i32 %t46, 0
  br i1 %t47, label %bb10, label %ok.48
ok.48:
  br label %bb9
bb9:
  br label %bb11
bb10:
  %t49 = load i32, ptr %l26, !tbaa !23
  %t50 = lshr i32 %t49, 16
  %t51 = and i32 %t49, 65535
  %t52 = icmp eq i32 %t50, 1
  %t53 = select i1 %t52, i32 1, i32 0
  %t54 = icmp eq i32 %t49, 0
  %t55 = shl i32 %t53, 16
  %t56 = or i32 %t55, %t51
  %t57 = select i1 %t54, i32 0, i32 %t56
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  store i32 %t57, ptr %rv
  br label %ret
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb13:
  %t59 = load i64, ptr %l4, !tbaa !24
  %t61 = add i64 %t59, 1
  store i64 %t61, ptr %l4, !tbaa !24
  br label %bb1
bb14:
  call void @__olang_scope_close(ptr %s1)
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/build:Config", ptr %t63, i32 0, i32 2
  %t66 = load %"compiler/target:Target", ptr %t65
  store %"compiler/target:Target" %t66, ptr %l7
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/build:Config", ptr %t68, i32 0, i32 3
  store ptr %t70, ptr %l33, !tbaa !29
  %t71 = getelementptr %"compiler/target:Target", ptr %l7, i32 0, i32 3
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !27
  store { i64, ptr } %t72, ptr %l34, !tbaa !27
  %t73 = getelementptr %"compiler/target:Target", ptr %l7, i32 0, i32 2
  %t74 = load { i64, ptr }, ptr %t73, !tbaa !27
  store { i64, ptr } %t74, ptr %l35, !tbaa !27
  %t75 = getelementptr %"compiler/target:Target", ptr %l7, i32 0, i32 4
  %t76 = load { i64, ptr }, ptr %t75, !tbaa !27
  store { i64, ptr } %t76, ptr %l36, !tbaa !27
  %t77 = getelementptr %"compiler/target:Target", ptr %l7, i32 0, i32 7
  %t78 = load i64, ptr %t77, !tbaa !24
  store i64 %t78, ptr %l37, !tbaa !24
  %t79 = getelementptr %"compiler/target:Target", ptr %l7, i32 0, i32 8
  %t80 = load i1, ptr %t79, !tbaa !21
  br i1 %t80, label %bb15, label %bb16
bb15:
  store i64 1, ptr %l39, !tbaa !24
  br label %bb17
bb16:
  store i64 0, ptr %l39, !tbaa !24
  br label %bb17
bb17:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/build:Config", ptr %t82, i32 0, i32 4
  %t85 = load i1, ptr %t84, !tbaa !21
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/build:Config", ptr %t86, i32 0, i32 5
  %t89 = load i1, ptr %t88, !tbaa !21
  %t91 = load ptr, ptr %l33, !tbaa !29
  %t92 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t93 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t94 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t95 = load i64, ptr %l37, !tbaa !24
  %t96 = load i64, ptr %l39, !tbaa !24
  call void @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eBuiltins(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t91, { i64, ptr } %t92, { i64, ptr } %t93, { i64, ptr } %t94, i64 %t95, i64 %t96, i1 %t85, i1 %t89, i1 %a1)
  br label %bb18
bb18:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2folang_2echeckOutput(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l5 = alloca i1
  %l6 = alloca ptr
  %l8 = alloca %"compiler/msgs:Msg"
  %l9 = alloca i32
  %l11 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i64
  %l32 = alloca i1
  %l34 = alloca ptr
  %l37 = alloca %"compiler/msgs:Msg"
  %l38 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i32
  store { i64, ptr } %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fos_2eIsDir(ptr %v0, { i64, ptr } %t1)
  store i1 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i1, ptr %l5, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l6, !tbaa !29
  %t6 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eOutputIsDir(ptr %v0, ptr %s1, { i64, ptr } %t6)
  store %"compiler/msgs:Msg" %t8, ptr %l8
  br label %bb4
bb3:
  br label %bb8
bb4:
  %t9 = load ptr, ptr %l6, !tbaa !29
  %t10 = load %"compiler/msgs:Msg", ptr %l8
  %t11 = call i32 @compiler_2folang_2eusage(ptr %v1, ptr %s1, ptr %t9, %"compiler/msgs:Msg" %t10)
  store i32 %t11, ptr %l9
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb6, label %ok.13
ok.13:
  br label %bb5
bb5:
  br label %bb7
bb6:
  %t14 = load i32, ptr %l9, !tbaa !23
  %t15 = lshr i32 %t14, 16
  %t16 = and i32 %t14, 65535
  %t17 = icmp eq i32 %t15, 1
  %t18 = select i1 %t17, i32 1, i32 0
  %t19 = icmp eq i32 %t14, 0
  %t20 = shl i32 %t18, 16
  %t21 = or i32 %t20, %t16
  %t22 = select i1 %t19, i32 0, i32 %t21
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t22, ptr %rv
  br label %ret
bb7:
  call void @__olang_scope_close(ptr %s1)
  br label %bb8
bb8:
  %t24 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t26 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %s0, { i64, ptr } %t24, { i64, ptr } { i64 1, ptr @.d81 })
  %t27 = extractvalue { i32, i64 } %t26, 1
  %t28 = extractvalue { i32, i64 } %t26, 0
  store i32 %t28, ptr %l14
  %t29 = icmp ne i32 %t28, 0
  br i1 %t29, label %bb10, label %ok.30
ok.30:
  store i64 %t27, ptr %l13
  br label %bb9
bb9:
  %t31 = load i64, ptr %l13, !tbaa !24
  store i64 %t31, ptr %l11, !tbaa !24
  br label %bb12
bb10:
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb12:
  %t32 = load i64, ptr %l11, !tbaa !24
  store i64 %t32, ptr %l2, !tbaa !24
  %t33 = load i64, ptr %l2, !tbaa !24
  %t35 = icmp eq i64 %t33, 0
  br i1 %t35, label %bb13, label %bb14
bb13:
  %t37 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t37, ptr %l18, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 0
  store i64 %t39, ptr %l19, !tbaa !24
  %t40 = icmp sge i64 0, 0
  br i1 %t40, label %bb15, label %bb16
bb14:
  %t42 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t42, ptr %l24, !tbaa !27
  %t43 = load i64, ptr %l2, !tbaa !24
  store i64 %t43, ptr %l25, !tbaa !24
  %t44 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t44, 0
  store i64 %t45, ptr %l26, !tbaa !24
  %t46 = icmp sge i64 0, 0
  br i1 %t46, label %bb21, label %bb22
bb15:
  %t48 = icmp sle i64 0, 1
  br i1 %t48, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @.c82)
  unreachable
bb17:
  %t50 = load i64, ptr %l19, !tbaa !24
  %t51 = icmp sle i64 1, %t50
  br i1 %t51, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @.c82)
  unreachable
bb19:
  %t53 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr i8, ptr %t54, i64 0
  %t56 = sub i64 1, 0
  %t57 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t55, 1
  store { i64, ptr } %t58, ptr %l17, !tbaa !27
  br label %bb27
bb20:
  call void @__olang_check_failed(ptr @.c82)
  unreachable
bb21:
  %t60 = load i64, ptr %l25, !tbaa !24
  %t61 = icmp sle i64 0, %t60
  br i1 %t61, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @.c82)
  unreachable
bb23:
  %t63 = load i64, ptr %l25, !tbaa !24
  %t64 = load i64, ptr %l26, !tbaa !24
  %t65 = icmp sle i64 %t63, %t64
  br i1 %t65, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @.c82)
  unreachable
bb25:
  %t67 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !27
  %t69 = load i64, ptr %l25, !tbaa !24
  %t70 = getelementptr i8, ptr %t68, i64 0
  %t71 = sub i64 %t69, 0
  %t72 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t70, 1
  store { i64, ptr } %t73, ptr %l17, !tbaa !27
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @.c82)
  unreachable
bb27:
  %t75 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t75, ptr %l3, !tbaa !27
  %t76 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t78 = call i1 @std_2fos_2eIsDir(ptr %v0, { i64, ptr } %t76)
  store i1 %t78, ptr %l32
  br label %bb28
bb28:
  %t79 = load i1, ptr %l32, !tbaa !21
  %t80 = xor i1 %t79, true
  br i1 %t80, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s3
  %t82 = load ptr, ptr %l1, !tbaa !29
  store ptr %t82, ptr %l34, !tbaa !29
  %t83 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t84 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t87 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eOutputNoDir(ptr %v0, ptr %v0, ptr %s3, { i64, ptr } %t83, { i64, ptr } %t84)
  store %"compiler/msgs:Msg" %t87, ptr %l37
  br label %bb31
bb30:
  br label %bb35
bb31:
  %t88 = load ptr, ptr %l34, !tbaa !29
  %t89 = load %"compiler/msgs:Msg", ptr %l37
  %t90 = call i32 @compiler_2folang_2eusage(ptr %v1, ptr %s3, ptr %t88, %"compiler/msgs:Msg" %t89)
  store i32 %t90, ptr %l38
  %t91 = icmp ne i32 %t90, 0
  br i1 %t91, label %bb33, label %ok.92
ok.92:
  br label %bb32
bb32:
  br label %bb34
bb33:
  %t93 = load i32, ptr %l38, !tbaa !23
  %t94 = lshr i32 %t93, 16
  %t95 = and i32 %t93, 65535
  %t96 = icmp eq i32 %t94, 1
  %t97 = select i1 %t96, i32 1, i32 0
  %t98 = icmp eq i32 %t93, 0
  %t99 = shl i32 %t97, 16
  %t100 = or i32 %t99, %t95
  %t101 = select i1 %t98, i32 0, i32 %t100
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t101, ptr %rv
  br label %ret
bb34:
  call void @__olang_scope_close(ptr %s3)
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2folang_2echeckReuse(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5, i32 %a6, ptr %a7) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l9 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca i1
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca %"compiler/build:Unit"
  %l20 = alloca i64
  %l28 = alloca ptr
  %l30 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l32 = alloca i64
  %l35 = alloca i64
  %l38 = alloca i64
  %l42 = alloca i64
  %l45 = alloca i64
  %l63 = alloca i64
  %l66 = alloca i64
  %l71 = alloca %"compiler/build:Unit"
  %l74 = alloca %"compiler/emit:Object"
  %l77 = alloca i1
  %l79 = alloca i1
  %l82 = alloca %"compiler/emit:Object"
  %l85 = alloca i1
  %l89 = alloca %"compiler/emit:Object"
  %l93 = alloca i32
  %l101 = alloca i64
  %l103 = alloca i64
  %l106 = alloca i32
  %l111 = alloca i64
  %l114 = alloca i32
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 59
  %t5 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eLen_3cI64_2c_20I64_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l20
  br label %bb1
bb1:
  %t6 = load i64, ptr %l20, !tbaa !24
  %t7 = icmp eq i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t21 = call ptr @compiler_2folang_2eemitter(ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %a2, ptr %a3, ptr %a4, ptr %a5, i32 %a6, ptr %a7)
  store ptr %t21, ptr %l28
  br label %bb5
bb5:
  %t22 = load ptr, ptr %l28, !tbaa !29
  %t25 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2ecompiler_2femit_3aEmitter_2eObjects(ptr %v5, ptr %s0, ptr %t22)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %l30
  br label %bb6
bb6:
  %t26 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l30
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t26, ptr %l9
  %t28 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aObject_3e_2eLen_3ccompiler_2femit_3aObject_3e(ptr %s0, ptr %l9)
  store i64 %t28, ptr %l32
  br label %bb7
bb7:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr %"compiler/build:Program", ptr %t29, i32 0, i32 0
  %t33 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2eLen_3ccompiler_2fbuild_3aUnit_3e(ptr %v1, ptr %t31)
  store i64 %t33, ptr %l35
  br label %bb8
bb8:
  %t34 = load i64, ptr %l32, !tbaa !24
  %t35 = load i64, ptr %l35, !tbaa !24
  %t36 = icmp ne i64 %t34, %t35
  store i1 %t36, ptr %l10, !tbaa !21
  store i64 0, ptr %l11, !tbaa !24
  %t39 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aObject_3e_2eLen_3ccompiler_2femit_3aObject_3e(ptr %s0, ptr %l9)
  store i64 %t39, ptr %l38
  br label %bb9
bb9:
  %t40 = load i64, ptr %l38, !tbaa !24
  store i64 %t40, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t41 = load i64, ptr %l12, !tbaa !24
  %t42 = load i64, ptr %l11, !tbaa !24
  %t45 = icmp sgt i64 %t41, %t42
  br i1 %t45, label %bb10, label %bb11
bb10:
  %t47 = load i64, ptr %l13, !tbaa !24
  %t49 = icmp sgt i64 %t47, 0
  br i1 %t49, label %bb12, label %bb13
bb11:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb15
bb12:
  %t51 = load i64, ptr %l12, !tbaa !24
  %t52 = load i64, ptr %l11, !tbaa !24
  %t55 = sub i64 %t51, %t52
  %t56 = load i64, ptr %l13, !tbaa !24
  %t59 = add i64 %t55, %t56
  %t61 = sub i64 %t59, 1
  %t62 = load i64, ptr %l13, !tbaa !24
  %t65 = sdiv i64 %t61, %t62
  store i64 %t65, ptr %l45, !tbaa !24
  br label %bb14
bb13:
  store i64 0, ptr %l45, !tbaa !24
  br label %bb14
bb14:
  %t67 = load i64, ptr %l45, !tbaa !24
  store i64 %t67, ptr %l42, !tbaa !24
  br label %bb15
bb15:
  %t68 = load i64, ptr %l42, !tbaa !24
  store i64 %t68, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb16
bb16:
  store %olang.scope zeroinitializer, ptr %s3
  %t69 = load i64, ptr %l15, !tbaa !24
  %t70 = load i64, ptr %l14, !tbaa !24
  %t73 = icmp slt i64 %t69, %t70
  %t75 = xor i1 %t73, true
  br i1 %t75, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s3)
  br label %bb43
bb18:
  br label %bb19
bb19:
  %t77 = load i64, ptr %l11, !tbaa !24
  %t78 = load i64, ptr %l15, !tbaa !24
  %t79 = load i64, ptr %l13, !tbaa !24
  %t82 = mul i64 %t78, %t79
  %t85 = add i64 %t77, %t82
  store i64 %t85, ptr %l16, !tbaa !24
  %t87 = load i64, ptr %l16, !tbaa !24
  store i64 %t87, ptr %l63, !tbaa !24
  %t88 = load ptr, ptr %l1, !tbaa !29
  %t90 = getelementptr %"compiler/build:Program", ptr %t88, i32 0, i32 0
  %t92 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2eLen_3ccompiler_2fbuild_3aUnit_3e(ptr %v1, ptr %t90)
  store i64 %t92, ptr %l66
  br label %bb20
bb20:
  %t93 = load i64, ptr %l63, !tbaa !24
  %t94 = load i64, ptr %l66, !tbaa !24
  %t95 = icmp sge i64 %t93, %t94
  br i1 %t95, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s3)
  br label %bb43
bb22:
  br label %bb23
bb23:
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t99 = getelementptr %"compiler/build:Program", ptr %t97, i32 0, i32 0
  %t100 = load i64, ptr %l16, !tbaa !24
  %t103 = call %"compiler/build:Unit" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2eAt_3ccompiler_2fbuild_3aUnit_3e(ptr %v1, ptr %v1, ptr %t99, i64 %t100)
  store %"compiler/build:Unit" %t103, ptr %l71
  br label %bb24
bb24:
  %t104 = load %"compiler/build:Unit", ptr %l71
  store %"compiler/build:Unit" %t104, ptr %l17
  %t105 = load i64, ptr %l16, !tbaa !24
  %t108 = call %"compiler/emit:Object" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aObject_3e_2eAt_3ccompiler_2femit_3aObject_3e(ptr %s0, ptr %s0, ptr %l9, i64 %t105)
  store %"compiler/emit:Object" %t108, ptr %l74
  br label %bb25
bb25:
  %t109 = getelementptr %"compiler/emit:Object", ptr %l74, i32 0, i32 0
  %t110 = load { i64, ptr }, ptr %t109, !tbaa !27
  %t111 = getelementptr %"compiler/build:Unit", ptr %l17, i32 0, i32 0
  %t112 = load { i64, ptr }, ptr %t111, !tbaa !27
  %t115 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %v1, { i64, ptr } %t110, { i64, ptr } %t112)
  store i1 %t115, ptr %l77
  br label %bb26
bb26:
  %t116 = load i1, ptr %l77, !tbaa !21
  %t117 = xor i1 %t116, true
  br i1 %t117, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l79, !tbaa !21
  br label %bb31
bb28:
  %t119 = load i64, ptr %l16, !tbaa !24
  %t122 = call %"compiler/emit:Object" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aObject_3e_2eAt_3ccompiler_2femit_3aObject_3e(ptr %s0, ptr %s0, ptr %l9, i64 %t119)
  store %"compiler/emit:Object" %t122, ptr %l82
  br label %bb29
bb29:
  %t123 = getelementptr %"compiler/emit:Object", ptr %l82, i32 0, i32 2
  %t124 = load { i64, ptr }, ptr %t123, !tbaa !27
  %t125 = getelementptr %"compiler/build:Unit", ptr %l17, i32 0, i32 2
  %t126 = load { i64, ptr }, ptr %t125, !tbaa !27
  %t129 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %v1, { i64, ptr } %t124, { i64, ptr } %t126)
  store i1 %t129, ptr %l85
  br label %bb30
bb30:
  %t130 = load i1, ptr %l85, !tbaa !21
  %t131 = xor i1 %t130, true
  store i1 %t131, ptr %l79, !tbaa !21
  br label %bb31
bb31:
  %t133 = load i1, ptr %l79, !tbaa !21
  br i1 %t133, label %bb32, label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s5
  %t134 = load i64, ptr %l16, !tbaa !24
  %t137 = call %"compiler/emit:Object" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aObject_3e_2eAt_3ccompiler_2femit_3aObject_3e(ptr %s0, ptr %s0, ptr %l9, i64 %t134)
  store %"compiler/emit:Object" %t137, ptr %l89
  br label %bb34
bb33:
  br label %bb41
bb34:
  %t138 = getelementptr %"compiler/emit:Object", ptr %l89, i32 0, i32 0
  %t139 = load { i64, ptr }, ptr %t138, !tbaa !27
  %t140 = extractvalue { i64, ptr } { i64 20, ptr @.d83 }, 1
  %t141 = extractvalue { i64, ptr } { i64 20, ptr @.d83 }, 0
  %t143 = extractvalue { i64, ptr } %t139, 1
  %t144 = extractvalue { i64, ptr } %t139, 0
  %t145 = add i64 %t141, %t144
  %t146 = extractvalue { i64, ptr } { i64 9, ptr @.d84 }, 1
  %t147 = extractvalue { i64, ptr } { i64 9, ptr @.d84 }, 0
  %t148 = add i64 %t145, %t147
  %t149 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t148)
  call void @olang_textcopy(ptr %t149, ptr %t140, i64 %t141)
  %t150 = getelementptr i8, ptr %t149, i64 %t141
  call void @olang_textcopy(ptr %t150, ptr %t143, i64 %t144)
  %t151 = getelementptr i8, ptr %t150, i64 %t144
  call void @olang_textcopy(ptr %t151, ptr %t146, i64 %t147)
  %t152 = insertvalue { i64, ptr } undef, i64 %t148, 0
  %t153 = insertvalue { i64, ptr } %t152, ptr %t149, 1
  %t155 = extractvalue { i64, ptr } %t153, 0
  %t156 = extractvalue { i64, ptr } %t153, 1
  %t157 = mul i64 %t155, 1
  %t158 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t157)
  call void @llvm.memcpy.p0.p0.i64(ptr %t158, ptr %t156, i64 %t157, i1 false)
  %t159 = insertvalue { i64, ptr } undef, i64 %t155, 0
  %t160 = insertvalue { i64, ptr } %t159, ptr %t158, 1
  %t162 = call i32 @std_2fio_2ePrintErr(ptr %s5, { i64, ptr } %t160)
  store i32 %t162, ptr %l93
  %t163 = icmp ne i32 %t162, 0
  br i1 %t163, label %bb36, label %ok.164
ok.164:
  br label %bb35
bb35:
  br label %bb40
bb36:
  %t165 = load i32, ptr %l93, !tbaa !23
  %t166 = ashr i32 %t165, 16
  %t168 = icmp eq i32 %t166, 1
  br i1 %t168, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  call void @__olang_check_failed(ptr @.c85)
  unreachable
bb39:
  br label %bb40
bb40:
  store i1 true, ptr %l10, !tbaa !21
  call void @__olang_scope_close(ptr %s5)
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s3)
  br label %bb42
bb42:
  %t170 = load i64, ptr %l15, !tbaa !24
  %t172 = add i64 %t170, 1
  store i64 %t172, ptr %l15, !tbaa !24
  br label %bb16
bb43:
  %t174 = load i1, ptr %l10, !tbaa !21
  br i1 %t174, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s9
  %t176 = load ptr, ptr %l1, !tbaa !29
  %t178 = getelementptr %"compiler/build:Program", ptr %t176, i32 0, i32 0
  %t180 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2eLen_3ccompiler_2fbuild_3aUnit_3e(ptr %v1, ptr %t178)
  store i64 %t180, ptr %l101
  br label %bb46
bb45:
  br label %bb55
bb46:
  %t182 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aObject_3e_2eLen_3ccompiler_2femit_3aObject_3e(ptr %s0, ptr %l9)
  store i64 %t182, ptr %l103
  br label %bb47
bb47:
  %t183 = extractvalue { i64, ptr } { i64 20, ptr @.d86 }, 1
  %t184 = extractvalue { i64, ptr } { i64 20, ptr @.d86 }, 0
  %t185 = load i64, ptr %l101, !tbaa !24
  %t186 = call i64 @__olang_fmt_i64(ptr null, i64 %t185)
  %t187 = add i64 %t184, %t186
  %t188 = extractvalue { i64, ptr } { i64 10, ptr @.d87 }, 1
  %t189 = extractvalue { i64, ptr } { i64 10, ptr @.d87 }, 0
  %t190 = add i64 %t187, %t189
  %t191 = load i64, ptr %l103, !tbaa !24
  %t192 = call i64 @__olang_fmt_i64(ptr null, i64 %t191)
  %t193 = add i64 %t190, %t192
  %t194 = extractvalue { i64, ptr } { i64 16, ptr @.d88 }, 1
  %t195 = extractvalue { i64, ptr } { i64 16, ptr @.d88 }, 0
  %t196 = add i64 %t193, %t195
  %t197 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t196)
  call void @olang_textcopy(ptr %t197, ptr %t183, i64 %t184)
  %t198 = getelementptr i8, ptr %t197, i64 %t184
  %t199 = call i64 @__olang_fmt_i64(ptr %t198, i64 %t185)
  %t200 = getelementptr i8, ptr %t198, i64 %t186
  call void @olang_textcopy(ptr %t200, ptr %t188, i64 %t189)
  %t201 = getelementptr i8, ptr %t200, i64 %t189
  %t202 = call i64 @__olang_fmt_i64(ptr %t201, i64 %t191)
  %t203 = getelementptr i8, ptr %t201, i64 %t192
  call void @olang_textcopy(ptr %t203, ptr %t194, i64 %t195)
  %t204 = insertvalue { i64, ptr } undef, i64 %t196, 0
  %t205 = insertvalue { i64, ptr } %t204, ptr %t197, 1
  %t207 = extractvalue { i64, ptr } %t205, 0
  %t208 = extractvalue { i64, ptr } %t205, 1
  %t209 = mul i64 %t207, 1
  %t210 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t209)
  call void @llvm.memcpy.p0.p0.i64(ptr %t210, ptr %t208, i64 %t209, i1 false)
  %t211 = insertvalue { i64, ptr } undef, i64 %t207, 0
  %t212 = insertvalue { i64, ptr } %t211, ptr %t210, 1
  %t214 = call i32 @std_2fio_2ePrintErr(ptr %s9, { i64, ptr } %t212)
  store i32 %t214, ptr %l106
  %t215 = icmp ne i32 %t214, 0
  br i1 %t215, label %bb49, label %ok.216
ok.216:
  br label %bb48
bb48:
  br label %bb53
bb49:
  %t217 = load i32, ptr %l106, !tbaa !23
  %t218 = ashr i32 %t217, 16
  %t220 = icmp eq i32 %t218, 1
  br i1 %t220, label %bb50, label %bb51
bb50:
  br label %bb52
bb51:
  call void @__olang_check_failed(ptr @.c89)
  unreachable
bb52:
  br label %bb53
bb53:
  call void @std_2fos_2eExit(i32 3)
  unreachable
bb54:
  call void @__olang_check_failed(ptr @.c90)
  unreachable
bb55:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/emit:Emitter", ptr %t222, i32 0, i32 59
  %t226 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eLen_3cI64_2c_20I64_3e(ptr %v0, ptr %t224)
  store i64 %t226, ptr %l111
  br label %bb56
bb56:
  %t227 = extractvalue { i64, ptr } { i64 20, ptr @.d91 }, 1
  %t228 = extractvalue { i64, ptr } { i64 20, ptr @.d91 }, 0
  %t229 = load i64, ptr %l111, !tbaa !24
  %t230 = call i64 @__olang_fmt_i64(ptr null, i64 %t229)
  %t231 = add i64 %t228, %t230
  %t232 = extractvalue { i64, ptr } { i64 39, ptr @.d92 }, 1
  %t233 = extractvalue { i64, ptr } { i64 39, ptr @.d92 }, 0
  %t234 = add i64 %t231, %t233
  %t235 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t234)
  call void @olang_textcopy(ptr %t235, ptr %t227, i64 %t228)
  %t236 = getelementptr i8, ptr %t235, i64 %t228
  %t237 = call i64 @__olang_fmt_i64(ptr %t236, i64 %t229)
  %t238 = getelementptr i8, ptr %t236, i64 %t230
  call void @olang_textcopy(ptr %t238, ptr %t232, i64 %t233)
  %t239 = insertvalue { i64, ptr } undef, i64 %t234, 0
  %t240 = insertvalue { i64, ptr } %t239, ptr %t235, 1
  %t242 = extractvalue { i64, ptr } %t240, 0
  %t243 = extractvalue { i64, ptr } %t240, 1
  %t244 = mul i64 %t242, 1
  %t245 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t244)
  call void @llvm.memcpy.p0.p0.i64(ptr %t245, ptr %t243, i64 %t244, i1 false)
  %t246 = insertvalue { i64, ptr } undef, i64 %t242, 0
  %t247 = insertvalue { i64, ptr } %t246, ptr %t245, 1
  %t249 = call i32 @std_2fio_2ePrintErr(ptr %s0, { i64, ptr } %t247)
  store i32 %t249, ptr %l114
  %t250 = icmp ne i32 %t249, 0
  br i1 %t250, label %bb58, label %ok.251
ok.251:
  br label %bb57
bb57:
  br label %bb62
bb58:
  %t252 = load i32, ptr %l114, !tbaa !23
  %t253 = ashr i32 %t252, 16
  %t255 = icmp eq i32 %t253, 1
  br i1 %t255, label %bb59, label %bb60
bb59:
  br label %bb61
bb60:
  call void @__olang_check_failed(ptr @.c93)
  unreachable
bb61:
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2folang_2ecompiler_2folang_3aPasses_2eAnalyze(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i32 %a2, ptr %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca %"compiler/lower:Gap"
  %l28 = alloca %"compiler/target:Target"
  %l29 = alloca i1
  %l30 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l31 = alloca ptr
  %l32 = alloca i64
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca %"compiler/emit:Object"
  %l37 = alloca %"compiler/emit:Reused"
  %l38 = alloca { i64, ptr }
  %l39 = alloca ptr
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca ptr
  %l49 = alloca { i64, ptr }
  %l50 = alloca i32
  %l52 = alloca ptr
  %l53 = alloca i32
  %l55 = alloca i32
  %l57 = alloca i1
  %l58 = alloca ptr
  %l63 = alloca ptr
  %l64 = alloca i32
  %l68 = alloca %"compiler/check:Checker"
  %l70 = alloca i32
  %l72 = alloca i32
  %l74 = alloca i1
  %l76 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l79 = alloca i64
  %l83 = alloca i64
  %l86 = alloca i64
  %l87 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l91 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l94 = alloca i64
  %l97 = alloca i1
  %l101 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l107 = alloca %"compiler/lower:Lowerer"
  %l112 = alloca ptr
  %l115 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l117 = alloca i64
  %l126 = alloca ptr
  %l130 = alloca i32
  %l132 = alloca i32
  %l134 = alloca i1
  %l139 = alloca { i64, ptr }
  %l140 = alloca ptr
  %l144 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l146 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l155 = alloca ptr
  %l157 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l160 = alloca i64
  %l162 = alloca i1
  %l165 = alloca i64
  %l169 = alloca { i64, ptr }
  %l172 = alloca { i64, ptr }
  %l173 = alloca i32
  %l183 = alloca { i64, ptr }
  %l196 = alloca { i64, ptr }
  %l199 = alloca { i64, ptr }
  %l200 = alloca i32
  %l210 = alloca { i64, ptr }
  %l217 = alloca { i64, ptr }
  %l228 = alloca i64
  %l233 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l235 = alloca { i64, ptr }
  %l238 = alloca { i64, ptr }
  %l239 = alloca i32
  %l249 = alloca { i64, ptr }
  %l257 = alloca %"compiler/emit:Reused"
  %l258 = alloca ptr
  %l262 = alloca ptr
  %l265 = alloca { i64, ptr }
  %l268 = alloca { i64, ptr }
  %l270 = alloca { i64, ptr }
  %l273 = alloca { i64, ptr }
  %l274 = alloca i32
  %l285 = alloca { i64, ptr }
  %l288 = alloca { i64, ptr }
  %l293 = alloca { i64, ptr }
  %l294 = alloca i32
  %l304 = alloca { i64, ptr }
  %l305 = alloca i1
  %l311 = alloca %"compiler/build:Unit"
  %l313 = alloca ptr
  %l316 = alloca { i64, ptr }
  %l334 = alloca { i64, ptr }
  %l335 = alloca i1
  %l337 = alloca i32
  %l355 = alloca %"compiler/build:Unit"
  %l357 = alloca i32
  %l359 = alloca i32
  %l361 = alloca i1
  %l363 = alloca i1
  %l364 = alloca i32
  %l366 = alloca i32
  %l368 = alloca i1
  %l369 = alloca ptr
  %l371 = alloca { i64, ptr }
  %l387 = alloca i32
  %l389 = alloca i32
  %l391 = alloca i1
  %l400 = alloca { i64, ptr }
  %l401 = alloca { i64, ptr }
  %l402 = alloca i32
  %l403 = alloca { i64, ptr }
  %l406 = alloca i1
  %l416 = alloca ptr
  %l417 = alloca { i64, ptr }
  %l425 = alloca { i64, ptr }
  %l426 = alloca i32
  %l433 = alloca ptr
  %l434 = alloca { i64, ptr }
  %l442 = alloca { i64, ptr }
  %l443 = alloca i32
  %s0 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %rv = alloca i32
  %t33 = alloca %"compiler/check:Checker", align 8
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l2
  store i32 %t1, ptr %l53
  store i32 2, ptr %l55
  %t4 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fbuild_3aKind(ptr %l53, ptr %l55)
  store i1 %t4, ptr %l57
  br label %bb1
bb1:
  %t5 = load i1, ptr %l57, !tbaa !21
  store i1 %t5, ptr %l6, !tbaa !21
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 5, ptr @.d94 })
  br label %bb2
bb2:
  %t8 = load ptr, ptr %l3, !tbaa !29
  %t9 = load ptr, ptr %l5, !tbaa !29
  %t14 = call { i32, ptr } @compiler_2folang_2ecompiler_2folang_3aPasses_2eload(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, ptr %t8, ptr %t9)
  %t15 = extractvalue { i32, ptr } %t14, 1
  %t16 = extractvalue { i32, ptr } %t14, 0
  store i32 %t16, ptr %l64
  %t17 = icmp ne i32 %t16, 0
  br i1 %t17, label %bb4, label %ok.18
ok.18:
  store ptr %t15, ptr %l63
  br label %bb3
bb3:
  %t19 = load ptr, ptr %l63, !tbaa !29
  store ptr %t19, ptr %l58, !tbaa !29
  br label %bb5
bb4:
  %t20 = load i32, ptr %l64, !tbaa !23
  %t21 = lshr i32 %t20, 16
  %t22 = and i32 %t20, 65535
  %t23 = icmp eq i32 %t21, 1
  %t24 = select i1 %t23, i32 1, i32 0
  %t25 = icmp eq i32 %t20, 0
  %t26 = shl i32 %t24, 16
  %t27 = or i32 %t26, %t22
  %t28 = select i1 %t25, i32 0, i32 %t27
  call void @__olang_scope_close(ptr %s0)
  store i32 %t28, ptr %rv
  br label %ret
bb5:
  %t30 = load ptr, ptr %l58, !tbaa !29
  store ptr %t30, ptr %l7, !tbaa !29
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 4, ptr @.d95 })
  br label %bb6
bb6:
  %t31 = load ptr, ptr %l7, !tbaa !29
  %t32 = load i1, ptr %l6, !tbaa !21
  call void @compiler_2finterp_2eAnalyze(ptr %t33, ptr %v2, ptr %v2, ptr %t31, i1 %t32)
  call void @llvm.memmove.p0.p0.i64(ptr %l68, ptr %t33, i64 568, i1 false)
  br label %bb7
bb7:
  %t36 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 568, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t36, ptr %l68, i64 568, i1 false)
  store ptr %t36, ptr %l8, !tbaa !29
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 5, ptr @.d96 })
  br label %bb8
bb8:
  %t38 = load i32, ptr %l2
  store i32 %t38, ptr %l70
  store i32 1, ptr %l72
  %t41 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fbuild_3aKind(ptr %l70, ptr %l72)
  store i1 %t41, ptr %l74
  br label %bb9
bb9:
  %t42 = load i1, ptr %l74, !tbaa !21
  br i1 %t42, label %bb10, label %bb11
bb10:
  %t43 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eCheckMain(ptr %v2, ptr %t43)
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb13
bb13:
  %t45 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t45, ptr %l76
  br label %bb14
bb14:
  %t46 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l76
  %t47 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t46, ptr %t47
  store ptr %t47, ptr %l9, !tbaa !29
  %t49 = load ptr, ptr %l5, !tbaa !29
  %t51 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v2, ptr %t49)
  store i64 %t51, ptr %l79
  br label %bb15
bb15:
  %t52 = load i64, ptr %l79, !tbaa !24
  %t53 = icmp eq i64 %t52, 0
  store i1 %t53, ptr %l10, !tbaa !21
  %t55 = load i1, ptr %l10, !tbaa !21
  br i1 %t55, label %bb16, label %bb17
bb16:
  %t57 = load ptr, ptr %l8, !tbaa !29
  %t59 = call i64 @compiler_2finterp_2eDecideValues(ptr %v2, ptr %t57)
  store i64 %t59, ptr %l83
  br label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb19
bb19:
  %t60 = load ptr, ptr %l8, !tbaa !29
  %t61 = load ptr, ptr %l9, !tbaa !29
  %t64 = call i64 @compiler_2finterp_2eDecideAsserts(ptr %v2, ptr %v2, ptr %t60, ptr %t61)
  store i64 %t64, ptr %l86
  br label %bb20
bb20:
  %t65 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2ector(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t65, ptr %l87
  br label %bb21
bb21:
  %t66 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l87
  %t67 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t66, ptr %t67
  store ptr %t67, ptr %l11, !tbaa !29
  %t69 = load i1, ptr %l10, !tbaa !21
  br i1 %t69, label %bb22, label %bb23
bb22:
  %t71 = load ptr, ptr %l8, !tbaa !29
  %t73 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2finterp_2eBake(ptr %v2, ptr %v2, ptr %t71)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t73, ptr %l91
  br label %bb24
bb23:
  br label %bb25
bb24:
  %t74 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l91
  %t75 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t74, ptr %t75
  store ptr %t75, ptr %l11, !tbaa !29
  br label %bb25
bb25:
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 8, ptr @.d97 })
  br label %bb26
bb26:
  %t77 = load ptr, ptr %l5, !tbaa !29
  %t79 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v2, ptr %t77)
  store i64 %t79, ptr %l94
  br label %bb27
bb27:
  %t80 = load i64, ptr %l94, !tbaa !24
  %t81 = icmp sgt i64 %t80, 0
  br i1 %t81, label %bb28, label %bb29
bb28:
  %t83 = load ptr, ptr %l5, !tbaa !29
  %t85 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHasFatal(ptr %v2, ptr %t83)
  store i1 %t85, ptr %l97
  br label %bb30
bb29:
  br label %bb35
bb30:
  %t86 = load i1, ptr %l97, !tbaa !21
  %t87 = xor i1 %t86, true
  br i1 %t87, label %bb31, label %bb32
bb31:
  %t89 = load ptr, ptr %l8, !tbaa !29
  %t90 = load ptr, ptr %l3, !tbaa !29
  %t93 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2folang_2eplacement(ptr %v2, ptr %v2, ptr %v2, ptr %t89, ptr %t90)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t93, ptr %l101
  br label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb35:
  %t95 = load ptr, ptr %l8, !tbaa !29
  %t97 = getelementptr %"compiler/check:Checker", ptr %t95, i32 0, i32 0
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t99 = load ptr, ptr %l8, !tbaa !29
  %t101 = getelementptr %"compiler/check:Checker", ptr %t99, i32 0, i32 4
  %t102 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t101
  %t105 = call %"compiler/lower:Lowerer" @compiler_2flower_3aLowerer_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %t98, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t102)
  store %"compiler/lower:Lowerer" %t105, ptr %l107
  br label %bb36
bb36:
  %t106 = load %"compiler/lower:Lowerer", ptr %l107
  %t107 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 96, i64 8)
  store %"compiler/lower:Lowerer" %t106, ptr %t107
  store ptr %t107, ptr %l12, !tbaa !29
  %t109 = load ptr, ptr %l12, !tbaa !29
  %t110 = load ptr, ptr %l9, !tbaa !29
  %t112 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t110
  %t115 = getelementptr %"compiler/lower:Lowerer", ptr %t109, i32 0, i32 6
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t112, ptr %t115
  %t116 = load ptr, ptr %l12, !tbaa !29
  store ptr %t116, ptr %l112, !tbaa !29
  %t117 = load ptr, ptr %l8, !tbaa !29
  %t118 = load ptr, ptr %l3, !tbaa !29
  %t121 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2folang_2eplacement(ptr %v2, ptr %v2, ptr %v2, ptr %t117, ptr %t118)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t121, ptr %l115
  br label %bb37
bb37:
  %t122 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l115
  %t123 = load ptr, ptr %l112, !tbaa !29
  %t124 = getelementptr %"compiler/lower:Lowerer", ptr %t123, i32 0, i32 2
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t122, ptr %t124
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 5, ptr @.d98 })
  br label %bb38
bb38:
  %t125 = load ptr, ptr %l5, !tbaa !29
  %t127 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v2, ptr %t125)
  store i64 %t127, ptr %l117
  br label %bb39
bb39:
  %t128 = load i64, ptr %l117, !tbaa !24
  %t129 = icmp sgt i64 %t128, 0
  br i1 %t129, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb41:
  br label %bb42
bb42:
  %t132 = load ptr, ptr %l8, !tbaa !29
  %t133 = load ptr, ptr %l12, !tbaa !29
  %t134 = load ptr, ptr %l5, !tbaa !29
  %t135 = load ptr, ptr %l3, !tbaa !29
  %t136 = load i32, ptr %l2
  %t137 = load ptr, ptr %l11, !tbaa !29
  %t144 = call ptr @compiler_2folang_2eemitter(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %t132, ptr %t133, ptr %t134, ptr %t135, i32 %t136, ptr %t137)
  store ptr %t144, ptr %l126
  br label %bb43
bb43:
  %t145 = load ptr, ptr %l126, !tbaa !29
  store ptr %t145, ptr %l13, !tbaa !29
  %t146 = icmp sge i64 0, 0
  br i1 %t146, label %bb44, label %bb45
bb44:
  %t148 = icmp sle i64 0, 576460752303423487
  br i1 %t148, label %bb46, label %bb47
bb45:
  call void @__olang_check_failed(ptr @.c99)
  unreachable
bb46:
  %t150 = mul i64 0, 16
  %t151 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t150)
  %t152 = insertvalue { i64, ptr } undef, i64 0, 0
  %t153 = insertvalue { i64, ptr } %t152, ptr %t151, 1
  store { i64, ptr } %t153, ptr %l14, !tbaa !27
  %t155 = load i32, ptr %l2
  store i32 %t155, ptr %l130
  store i32 0, ptr %l132
  %t158 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fbuild_3aKind(ptr %l130, ptr %l132)
  store i1 %t158, ptr %l134
  br label %bb48
bb47:
  call void @__olang_check_failed(ptr @.c99)
  unreachable
bb48:
  %t159 = load i1, ptr %l134, !tbaa !21
  %t160 = xor i1 %t159, true
  br i1 %t160, label %bb49, label %bb50
bb49:
  %t162 = load ptr, ptr %l7, !tbaa !29
  %t163 = load ptr, ptr %l3, !tbaa !29
  %t164 = load i1, ptr %l6, !tbaa !21
  %t168 = call { i64, ptr } @compiler_2folang_2emoduleKeys(ptr %v2, ptr %v2, ptr %t162, ptr %t163, i1 %t164)
  store { i64, ptr } %t168, ptr %l139
  br label %bb51
bb50:
  br label %bb53
bb51:
  %t169 = load { i64, ptr }, ptr %l139, !tbaa !27
  store { i64, ptr } %t169, ptr %l14, !tbaa !27
  %t170 = load ptr, ptr %l13, !tbaa !29
  store ptr %t170, ptr %l140, !tbaa !29
  %t171 = load ptr, ptr %l7, !tbaa !29
  %t172 = load ptr, ptr %l3, !tbaa !29
  %t173 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t177 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2folang_2ereusable(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %t171, ptr %t172, { i64, ptr } %t173)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t177, ptr %l144
  br label %bb52
bb52:
  %t178 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l144
  %t179 = load ptr, ptr %l140, !tbaa !29
  %t180 = getelementptr %"compiler/emit:Emitter", ptr %t179, i32 0, i32 58
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t178, ptr %t180
  br label %bb53
bb53:
  %t181 = load ptr, ptr %l13, !tbaa !29
  %t183 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2ecompiler_2femit_3aEmitter_2eObjects(ptr %v2, ptr %v3, ptr %t181)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t183, ptr %l146
  br label %bb54
bb54:
  %t184 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l146
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t184, ptr %l15
  %t185 = load ptr, ptr %l13, !tbaa !29
  %t187 = getelementptr %"compiler/emit:Emitter", ptr %t185, i32 0, i32 61
  %t188 = load i1, ptr %t187, !tbaa !21
  br i1 %t188, label %bb55, label %bb56
bb55:
  %t190 = load ptr, ptr %l8, !tbaa !29
  %t191 = load ptr, ptr %l12, !tbaa !29
  %t192 = load ptr, ptr %l5, !tbaa !29
  %t193 = load ptr, ptr %l3, !tbaa !29
  %t194 = load i32, ptr %l2
  %t195 = load ptr, ptr %l11, !tbaa !29
  %t202 = call ptr @compiler_2folang_2eemitter(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %t190, ptr %t191, ptr %t192, ptr %t193, i32 %t194, ptr %t195)
  store ptr %t202, ptr %l155
  br label %bb57
bb56:
  br label %bb59
bb57:
  %t203 = load ptr, ptr %l155, !tbaa !29
  store ptr %t203, ptr %l13, !tbaa !29
  %t204 = load ptr, ptr %l13, !tbaa !29
  %t206 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2ecompiler_2femit_3aEmitter_2eObjects(ptr %v2, ptr %v3, ptr %t204)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t206, ptr %l157
  br label %bb58
bb58:
  %t207 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l157
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t207, ptr %l15
  br label %bb59
bb59:
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 10, ptr @.d100 })
  br label %bb60
bb60:
  %t208 = load ptr, ptr %l13, !tbaa !29
  %t210 = getelementptr %"compiler/emit:Emitter", ptr %t208, i32 0, i32 8
  %t212 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v2, ptr %t210)
  store i64 %t212, ptr %l160
  br label %bb61
bb61:
  %t213 = load i64, ptr %l160, !tbaa !24
  %t214 = icmp sgt i64 %t213, 0
  br i1 %t214, label %bb62, label %bb63
bb62:
  store i1 true, ptr %l162, !tbaa !21
  br label %bb65
bb63:
  %t216 = load ptr, ptr %l12, !tbaa !29
  %t218 = getelementptr %"compiler/lower:Lowerer", ptr %t216, i32 0, i32 3
  %t220 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3aGap_3e_2eLen_3ccompiler_2flower_3aGap_3e(ptr %v2, ptr %t218)
  store i64 %t220, ptr %l165
  br label %bb64
bb64:
  %t221 = load i64, ptr %l165, !tbaa !24
  %t222 = icmp sgt i64 %t221, 0
  store i1 %t222, ptr %l162, !tbaa !21
  br label %bb65
bb65:
  %t224 = load i1, ptr %l162, !tbaa !21
  br i1 %t224, label %bb66, label %bb67
bb66:
  %t225 = load ptr, ptr %l13, !tbaa !29
  %t227 = getelementptr %"compiler/emit:Emitter", ptr %t225, i32 0, i32 8
  store ptr %t227, ptr %l16, !tbaa !29
  store i64 0, ptr %l17, !tbaa !24
  br label %bb68
bb67:
  br label %bb101
bb68:
  store %olang.scope zeroinitializer, ptr %s11
  %t229 = load ptr, ptr %l16, !tbaa !29
  %t230 = load i64, ptr %l17, !tbaa !24
  %t233 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v2, ptr %t229, i64 %t230)
  %t234 = extractvalue { i32, { i64, ptr } } %t233, 1
  %t235 = extractvalue { i32, { i64, ptr } } %t233, 0
  store i32 %t235, ptr %l173
  %t236 = icmp ne i32 %t235, 0
  br i1 %t236, label %bb70, label %ok.237
ok.237:
  store { i64, ptr } %t234, ptr %l172
  br label %bb69
bb69:
  %t238 = load { i64, ptr }, ptr %l172, !tbaa !27
  store { i64, ptr } %t238, ptr %l169, !tbaa !27
  br label %bb74
bb70:
  %t239 = load i32, ptr %l173, !tbaa !23
  %t240 = ashr i32 %t239, 16
  %t242 = icmp eq i32 %t240, 1
  br i1 %t242, label %bb71, label %bb72
bb71:
  br label %bb73
bb72:
  %t244 = load i32, ptr %l173, !tbaa !23
  %t245 = lshr i32 %t244, 16
  %t246 = and i32 %t244, 65535
  %t247 = icmp eq i32 %t245, 1
  %t248 = select i1 %t247, i32 0, i32 0
  %t249 = icmp eq i32 %t244, 0
  %t250 = shl i32 %t248, 16
  %t251 = or i32 %t250, %t246
  %t252 = select i1 %t249, i32 0, i32 %t251
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t252, ptr %rv
  br label %ret
bb73:
  call void @__olang_scope_close(ptr %s11)
  br label %bb83
bb74:
  %t254 = load { i64, ptr }, ptr %l169, !tbaa !27
  store { i64, ptr } %t254, ptr %l18, !tbaa !27
  %t255 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t257 = extractvalue { i64, ptr } %t255, 0
  store i64 %t257, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb75
bb75:
  store %olang.scope zeroinitializer, ptr %s12
  %t259 = load i64, ptr %l20, !tbaa !24
  %t260 = load i64, ptr %l19, !tbaa !24
  %t263 = icmp slt i64 %t259, %t260
  %t265 = xor i1 %t263, true
  br i1 %t265, label %bb76, label %bb77
bb76:
  call void @__olang_scope_close(ptr %s12)
  br label %bb81
bb77:
  br label %bb78
bb78:
  %t267 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t267, ptr %l183, !tbaa !27
  %t268 = load i64, ptr %l20, !tbaa !24
  %t270 = getelementptr { i64, ptr }, ptr %l183, i32 0, i32 1
  %t271 = load ptr, ptr %t270, !tbaa !27
  %t272 = getelementptr { i64, ptr }, ptr %t271, i64 %t268
  %t273 = load { i64, ptr }, ptr %t272, !tbaa !37
  %t276 = extractvalue { i64, ptr } { i64 17, ptr @.d101 }, 1
  %t277 = extractvalue { i64, ptr } { i64 17, ptr @.d101 }, 0
  %t279 = extractvalue { i64, ptr } %t273, 1
  %t280 = extractvalue { i64, ptr } %t273, 0
  %t281 = add i64 %t277, %t280
  %t282 = extractvalue { i64, ptr } { i64 4, ptr @.d102 }, 1
  %t283 = extractvalue { i64, ptr } { i64 4, ptr @.d102 }, 0
  %t284 = add i64 %t281, %t283
  %t285 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t284)
  call void @olang_textcopy(ptr %t285, ptr %t276, i64 %t277)
  %t286 = getelementptr i8, ptr %t285, i64 %t277
  call void @olang_textcopy(ptr %t286, ptr %t279, i64 %t280)
  %t287 = getelementptr i8, ptr %t286, i64 %t280
  call void @olang_textcopy(ptr %t287, ptr %t282, i64 %t283)
  %t288 = insertvalue { i64, ptr } undef, i64 %t284, 0
  %t289 = insertvalue { i64, ptr } %t288, ptr %t285, 1
  %t291 = extractvalue { i64, ptr } %t289, 0
  %t292 = extractvalue { i64, ptr } %t289, 1
  %t293 = mul i64 %t291, 1
  %t294 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t293)
  call void @llvm.memcpy.p0.p0.i64(ptr %t294, ptr %t292, i64 %t293, i1 false)
  %t295 = insertvalue { i64, ptr } undef, i64 %t291, 0
  %t296 = insertvalue { i64, ptr } %t295, ptr %t294, 1
  call void @compiler_2fbuild_2eUnbuildable(ptr %s12, { i64, ptr } %t296)
  br label %bb79
bb79:
  call void @__olang_scope_close(ptr %s12)
  br label %bb80
bb80:
  %t298 = load i64, ptr %l20, !tbaa !24
  %t300 = add i64 %t298, 1
  store i64 %t300, ptr %l20, !tbaa !24
  br label %bb75
bb81:
  %t302 = load i64, ptr %l17, !tbaa !24
  %t303 = load i64, ptr %l19, !tbaa !24
  %t306 = add i64 %t302, %t303
  store i64 %t306, ptr %l17, !tbaa !24
  call void @__olang_scope_close(ptr %s11)
  br label %bb82
bb82:
  br label %bb68
bb83:
  %t308 = load ptr, ptr %l12, !tbaa !29
  %t310 = getelementptr %"compiler/lower:Lowerer", ptr %t308, i32 0, i32 3
  store ptr %t310, ptr %l22, !tbaa !29
  store i64 0, ptr %l23, !tbaa !24
  br label %bb84
bb84:
  store %olang.scope zeroinitializer, ptr %s16
  %t312 = load ptr, ptr %l22, !tbaa !29
  %t313 = load i64, ptr %l23, !tbaa !24
  %t316 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3aGap_3e_2eRunFrom_3ccompiler_2flower_3aGap_3e(ptr %v2, ptr %t312, i64 %t313)
  %t317 = extractvalue { i32, { i64, ptr } } %t316, 1
  %t318 = extractvalue { i32, { i64, ptr } } %t316, 0
  store i32 %t318, ptr %l200
  %t319 = icmp ne i32 %t318, 0
  br i1 %t319, label %bb86, label %ok.320
ok.320:
  store { i64, ptr } %t317, ptr %l199
  br label %bb85
bb85:
  %t321 = load { i64, ptr }, ptr %l199, !tbaa !27
  store { i64, ptr } %t321, ptr %l196, !tbaa !27
  br label %bb90
bb86:
  %t322 = load i32, ptr %l200, !tbaa !23
  %t323 = ashr i32 %t322, 16
  %t325 = icmp eq i32 %t323, 1
  br i1 %t325, label %bb87, label %bb88
bb87:
  br label %bb89
bb88:
  %t327 = load i32, ptr %l200, !tbaa !23
  %t328 = lshr i32 %t327, 16
  %t329 = and i32 %t327, 65535
  %t330 = icmp eq i32 %t328, 1
  %t331 = select i1 %t330, i32 0, i32 0
  %t332 = icmp eq i32 %t327, 0
  %t333 = shl i32 %t331, 16
  %t334 = or i32 %t333, %t329
  %t335 = select i1 %t332, i32 0, i32 %t334
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t335, ptr %rv
  br label %ret
bb89:
  call void @__olang_scope_close(ptr %s16)
  br label %bb100
bb90:
  %t337 = load { i64, ptr }, ptr %l196, !tbaa !27
  store { i64, ptr } %t337, ptr %l24, !tbaa !27
  %t338 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t340 = extractvalue { i64, ptr } %t338, 0
  store i64 %t340, ptr %l25, !tbaa !24
  store i64 0, ptr %l26, !tbaa !24
  br label %bb91
bb91:
  store %olang.scope zeroinitializer, ptr %s17
  %t342 = load i64, ptr %l26, !tbaa !24
  %t343 = load i64, ptr %l25, !tbaa !24
  %t346 = icmp slt i64 %t342, %t343
  %t348 = xor i1 %t346, true
  br i1 %t348, label %bb92, label %bb93
bb92:
  call void @__olang_scope_close(ptr %s17)
  br label %bb98
bb93:
  br label %bb94
bb94:
  %t350 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t350, ptr %l210, !tbaa !27
  %t351 = load i64, ptr %l26, !tbaa !24
  %t353 = getelementptr { i64, ptr }, ptr %l210, i32 0, i32 1
  %t354 = load ptr, ptr %t353, !tbaa !27
  %t355 = getelementptr %"compiler/lower:Gap", ptr %t354, i64 %t351
  %t356 = load %"compiler/lower:Gap", ptr %t355
  store %"compiler/lower:Gap" %t356, ptr %l27
  %t358 = load ptr, ptr %l5, !tbaa !29
  %t359 = getelementptr %"compiler/lower:Gap", ptr %l27, i32 0, i32 0
  %t360 = load i64, ptr %t359, !tbaa !24
  %t361 = getelementptr %"compiler/lower:Gap", ptr %l27, i32 0, i32 1
  %t362 = getelementptr %"compiler/source:Span", ptr %t361, i32 0, i32 0
  %t363 = load i32, ptr %t362, !tbaa !23
  %t365 = sext i32 %t363 to i64
  %t369 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v2, ptr %s17, ptr %t358, i64 %t360, i64 %t365)
  store { i64, ptr } %t369, ptr %l217
  br label %bb95
bb95:
  %t370 = getelementptr %"compiler/lower:Gap", ptr %l27, i32 0, i32 2
  %t371 = load { i64, ptr }, ptr %t370, !tbaa !27
  %t372 = load { i64, ptr }, ptr %l217, !tbaa !27
  %t373 = extractvalue { i64, ptr } %t372, 1
  %t374 = extractvalue { i64, ptr } %t372, 0
  %t375 = extractvalue { i64, ptr } { i64 20, ptr @.d103 }, 1
  %t376 = extractvalue { i64, ptr } { i64 20, ptr @.d103 }, 0
  %t377 = add i64 %t374, %t376
  %t379 = extractvalue { i64, ptr } %t371, 1
  %t380 = extractvalue { i64, ptr } %t371, 0
  %t381 = add i64 %t377, %t380
  %t382 = extractvalue { i64, ptr } { i64 4, ptr @.d104 }, 1
  %t383 = extractvalue { i64, ptr } { i64 4, ptr @.d104 }, 0
  %t384 = add i64 %t381, %t383
  %t385 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t384)
  call void @olang_textcopy(ptr %t385, ptr %t373, i64 %t374)
  %t386 = getelementptr i8, ptr %t385, i64 %t374
  call void @olang_textcopy(ptr %t386, ptr %t375, i64 %t376)
  %t387 = getelementptr i8, ptr %t386, i64 %t376
  call void @olang_textcopy(ptr %t387, ptr %t379, i64 %t380)
  %t388 = getelementptr i8, ptr %t387, i64 %t380
  call void @olang_textcopy(ptr %t388, ptr %t382, i64 %t383)
  %t389 = insertvalue { i64, ptr } undef, i64 %t384, 0
  %t390 = insertvalue { i64, ptr } %t389, ptr %t385, 1
  %t392 = extractvalue { i64, ptr } %t390, 0
  %t393 = extractvalue { i64, ptr } %t390, 1
  %t394 = mul i64 %t392, 1
  %t395 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t394)
  call void @llvm.memcpy.p0.p0.i64(ptr %t395, ptr %t393, i64 %t394, i1 false)
  %t396 = insertvalue { i64, ptr } undef, i64 %t392, 0
  %t397 = insertvalue { i64, ptr } %t396, ptr %t395, 1
  call void @compiler_2fbuild_2eUnbuildable(ptr %s17, { i64, ptr } %t397)
  br label %bb96
bb96:
  call void @__olang_scope_close(ptr %s17)
  br label %bb97
bb97:
  %t399 = load i64, ptr %l26, !tbaa !24
  %t401 = add i64 %t399, 1
  store i64 %t401, ptr %l26, !tbaa !24
  br label %bb91
bb98:
  %t403 = load i64, ptr %l23, !tbaa !24
  %t404 = load i64, ptr %l25, !tbaa !24
  %t407 = add i64 %t403, %t404
  store i64 %t407, ptr %l23, !tbaa !24
  call void @__olang_scope_close(ptr %s16)
  br label %bb99
bb99:
  br label %bb84
bb100:
  call void @__olang_scope_close(ptr %s0)
  store i32 65537, ptr %rv
  br label %ret
bb101:
  %t410 = load ptr, ptr %l5, !tbaa !29
  %t412 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v2, ptr %t410)
  store i64 %t412, ptr %l228
  br label %bb102
bb102:
  %t413 = load i64, ptr %l228, !tbaa !24
  %t414 = icmp sgt i64 %t413, 0
  br i1 %t414, label %bb103, label %bb104
bb103:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb104:
  br label %bb105
bb105:
  %t417 = load ptr, ptr %l3, !tbaa !29
  %t419 = getelementptr %"compiler/build:Config", ptr %t417, i32 0, i32 2
  %t420 = load %"compiler/target:Target", ptr %t419
  store %"compiler/target:Target" %t420, ptr %l28
  store i1 false, ptr %l29, !tbaa !21
  %t422 = load ptr, ptr @__olang_prog_scope
  %t423 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t422)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t423, ptr %l233
  br label %bb106
bb106:
  %t424 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l233
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t424, ptr %l30
  store ptr %l15, ptr %l31, !tbaa !29
  store i64 0, ptr %l32, !tbaa !24
  br label %bb107
bb107:
  store %olang.scope zeroinitializer, ptr %s22
  %t426 = load ptr, ptr %l31, !tbaa !29
  %t427 = load i64, ptr %l32, !tbaa !24
  %t430 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aObject_3e_2eRunFrom_3ccompiler_2femit_3aObject_3e(ptr %v3, ptr %t426, i64 %t427)
  %t431 = extractvalue { i32, { i64, ptr } } %t430, 1
  %t432 = extractvalue { i32, { i64, ptr } } %t430, 0
  store i32 %t432, ptr %l239
  %t433 = icmp ne i32 %t432, 0
  br i1 %t433, label %bb109, label %ok.434
ok.434:
  store { i64, ptr } %t431, ptr %l238
  br label %bb108
bb108:
  %t435 = load { i64, ptr }, ptr %l238, !tbaa !27
  store { i64, ptr } %t435, ptr %l235, !tbaa !27
  br label %bb113
bb109:
  %t436 = load i32, ptr %l239, !tbaa !23
  %t437 = ashr i32 %t436, 16
  %t439 = icmp eq i32 %t437, 1
  br i1 %t439, label %bb110, label %bb111
bb110:
  br label %bb112
bb111:
  %t441 = load i32, ptr %l239, !tbaa !23
  %t442 = lshr i32 %t441, 16
  %t443 = and i32 %t441, 65535
  %t444 = icmp eq i32 %t442, 1
  %t445 = select i1 %t444, i32 0, i32 0
  %t446 = icmp eq i32 %t441, 0
  %t447 = shl i32 %t445, 16
  %t448 = or i32 %t447, %t443
  %t449 = select i1 %t446, i32 0, i32 %t448
  call void @__olang_scope_close(ptr %s22)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t449, ptr %rv
  br label %ret
bb112:
  call void @__olang_scope_close(ptr %s22)
  br label %bb190
bb113:
  %t451 = load { i64, ptr }, ptr %l235, !tbaa !27
  store { i64, ptr } %t451, ptr %l33, !tbaa !27
  %t452 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t454 = extractvalue { i64, ptr } %t452, 0
  store i64 %t454, ptr %l34, !tbaa !24
  store i64 0, ptr %l35, !tbaa !24
  br label %bb114
bb114:
  store %olang.scope zeroinitializer, ptr %s23
  %t456 = load i64, ptr %l35, !tbaa !24
  %t457 = load i64, ptr %l34, !tbaa !24
  %t460 = icmp slt i64 %t456, %t457
  %t462 = xor i1 %t460, true
  br i1 %t462, label %bb115, label %bb116
bb115:
  call void @__olang_scope_close(ptr %s23)
  br label %bb188
bb116:
  br label %bb117
bb117:
  %t464 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t464, ptr %l249, !tbaa !27
  %t465 = load i64, ptr %l35, !tbaa !24
  %t467 = getelementptr { i64, ptr }, ptr %l249, i32 0, i32 1
  %t468 = load ptr, ptr %t467, !tbaa !27
  %t469 = getelementptr %"compiler/emit:Object", ptr %t468, i64 %t465
  %t470 = load %"compiler/emit:Object", ptr %t469
  store %"compiler/emit:Object" %t470, ptr %l36
  %t472 = getelementptr %"compiler/emit:Object", ptr %l36, i32 0, i32 3
  %t473 = load i64, ptr %t472, !tbaa !24
  %t475 = icmp sge i64 %t473, 0
  br i1 %t475, label %bb118, label %bb119
bb118:
  store %olang.scope zeroinitializer, ptr %s24
  %t477 = load ptr, ptr %l13, !tbaa !29
  %t479 = getelementptr %"compiler/emit:Emitter", ptr %t477, i32 0, i32 58
  %t480 = getelementptr %"compiler/emit:Object", ptr %l36, i32 0, i32 3
  %t481 = load i64, ptr %t480, !tbaa !24
  %t484 = call %"compiler/emit:Reused" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aReused_3e_2eAt_3ccompiler_2femit_3aReused_3e(ptr %v2, ptr %v2, ptr %t479, i64 %t481)
  store %"compiler/emit:Reused" %t484, ptr %l257
  br label %bb120
bb119:
  br label %bb153
bb120:
  %t485 = load %"compiler/emit:Reused", ptr %l257
  store %"compiler/emit:Reused" %t485, ptr %l37
  %t486 = load ptr, ptr %l3, !tbaa !29
  store ptr %t486, ptr %l258, !tbaa !29
  %t487 = load ptr, ptr %l7, !tbaa !29
  %t489 = getelementptr %"compiler/load:Loader", ptr %t487, i32 0, i32 5
  %t490 = getelementptr %"compiler/emit:Reused", ptr %l37, i32 0, i32 0
  %t491 = load i64, ptr %t490, !tbaa !24
  %t494 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v2, ptr %v2, ptr %t489, i64 %t491)
  store ptr %t494, ptr %l262
  br label %bb121
bb121:
  %t495 = load ptr, ptr %l262, !tbaa !29
  %t497 = getelementptr %"compiler/load:Module", ptr %t495, i32 0, i32 2
  %t498 = load { i64, ptr }, ptr %t497, !tbaa !27
  %t499 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t499, ptr %l265, !tbaa !27
  %t500 = getelementptr %"compiler/emit:Reused", ptr %l37, i32 0, i32 0
  %t501 = load i64, ptr %t500, !tbaa !24
  %t503 = getelementptr { i64, ptr }, ptr %l265, i32 0, i32 1
  %t504 = load ptr, ptr %t503, !tbaa !27
  %t505 = getelementptr { i64, ptr }, ptr %t504, i64 %t501
  %t506 = load { i64, ptr }, ptr %t505, !tbaa !37
  %t507 = load ptr, ptr %l258, !tbaa !29
  %t510 = call { i64, ptr } @compiler_2folang_2erecordPath(ptr %v2, ptr %v2, ptr %v2, ptr %s24, ptr %t507, { i64, ptr } %t498, { i64, ptr } %t506)
  store { i64, ptr } %t510, ptr %l268
  br label %bb122
bb122:
  %t511 = load { i64, ptr }, ptr %l268, !tbaa !27
  store { i64, ptr } %t511, ptr %l38, !tbaa !27
  %t512 = getelementptr %"compiler/emit:Reused", ptr %l37, i32 0, i32 1
  store ptr %t512, ptr %l39, !tbaa !29
  store i64 0, ptr %l40, !tbaa !24
  store i64 0, ptr %l41, !tbaa !24
  br label %bb123
bb123:
  store %olang.scope zeroinitializer, ptr %s26
  %t514 = load ptr, ptr %l39, !tbaa !29
  %t515 = load i64, ptr %l40, !tbaa !24
  %t518 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v2, ptr %t514, i64 %t515)
  %t519 = extractvalue { i32, { i64, ptr } } %t518, 1
  %t520 = extractvalue { i32, { i64, ptr } } %t518, 0
  store i32 %t520, ptr %l274
  %t521 = icmp ne i32 %t520, 0
  br i1 %t521, label %bb125, label %ok.522
ok.522:
  store { i64, ptr } %t519, ptr %l273
  br label %bb124
bb124:
  %t523 = load { i64, ptr }, ptr %l273, !tbaa !27
  store { i64, ptr } %t523, ptr %l270, !tbaa !27
  br label %bb129
bb125:
  %t524 = load i32, ptr %l274, !tbaa !23
  %t525 = ashr i32 %t524, 16
  %t527 = icmp eq i32 %t525, 1
  br i1 %t527, label %bb126, label %bb127
bb126:
  br label %bb128
bb127:
  %t529 = load i32, ptr %l274, !tbaa !23
  %t530 = lshr i32 %t529, 16
  %t531 = and i32 %t529, 65535
  %t532 = icmp eq i32 %t530, 1
  %t533 = select i1 %t532, i32 0, i32 0
  %t534 = icmp eq i32 %t529, 0
  %t535 = shl i32 %t533, 16
  %t536 = or i32 %t535, %t531
  %t537 = select i1 %t534, i32 0, i32 %t536
  call void @__olang_scope_close(ptr %s26)
  call void @__olang_scope_close(ptr %s24)
  call void @__olang_scope_close(ptr %s23)
  call void @__olang_scope_close(ptr %s22)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t537, ptr %rv
  br label %ret
bb128:
  call void @__olang_scope_close(ptr %s26)
  br label %bb151
bb129:
  %t539 = load { i64, ptr }, ptr %l270, !tbaa !27
  store { i64, ptr } %t539, ptr %l42, !tbaa !27
  %t540 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t542 = extractvalue { i64, ptr } %t540, 0
  store i64 %t542, ptr %l43, !tbaa !24
  store i64 0, ptr %l44, !tbaa !24
  br label %bb130
bb130:
  store %olang.scope zeroinitializer, ptr %s27
  %t544 = load i64, ptr %l44, !tbaa !24
  %t545 = load i64, ptr %l43, !tbaa !24
  %t548 = icmp slt i64 %t544, %t545
  %t550 = xor i1 %t548, true
  br i1 %t550, label %bb131, label %bb132
bb131:
  call void @__olang_scope_close(ptr %s27)
  br label %bb149
bb132:
  br label %bb133
bb133:
  %t552 = load i64, ptr %l41, !tbaa !24
  store i64 %t552, ptr %l45, !tbaa !24
  %t554 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t554, ptr %l285, !tbaa !27
  %t555 = load i64, ptr %l44, !tbaa !24
  %t557 = getelementptr { i64, ptr }, ptr %l285, i32 0, i32 1
  %t558 = load ptr, ptr %t557, !tbaa !27
  %t559 = getelementptr { i64, ptr }, ptr %t558, i64 %t555
  %t560 = load { i64, ptr }, ptr %t559, !tbaa !37
  store { i64, ptr } %t560, ptr %l46, !tbaa !27
  %t562 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t563 = load i64, ptr %l45, !tbaa !24
  %t565 = extractvalue { i64, ptr } %t562, 1
  %t566 = extractvalue { i64, ptr } %t562, 0
  %t567 = extractvalue { i64, ptr } { i64 2, ptr @.d105 }, 1
  %t568 = extractvalue { i64, ptr } { i64 2, ptr @.d105 }, 0
  %t569 = add i64 %t566, %t568
  %t571 = call i64 @__olang_fmt_i64(ptr null, i64 %t563)
  %t572 = add i64 %t569, %t571
  %t573 = extractvalue { i64, ptr } { i64 3, ptr @.d106 }, 1
  %t574 = extractvalue { i64, ptr } { i64 3, ptr @.d106 }, 0
  %t575 = add i64 %t572, %t574
  %t576 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t575)
  call void @olang_textcopy(ptr %t576, ptr %t565, i64 %t566)
  %t577 = getelementptr i8, ptr %t576, i64 %t566
  call void @olang_textcopy(ptr %t577, ptr %t567, i64 %t568)
  %t578 = getelementptr i8, ptr %t577, i64 %t568
  %t579 = call i64 @__olang_fmt_i64(ptr %t578, i64 %t563)
  %t580 = getelementptr i8, ptr %t578, i64 %t571
  call void @olang_textcopy(ptr %t580, ptr %t573, i64 %t574)
  %t581 = insertvalue { i64, ptr } undef, i64 %t575, 0
  %t582 = insertvalue { i64, ptr } %t581, ptr %t576, 1
  %t584 = extractvalue { i64, ptr } %t582, 0
  %t585 = extractvalue { i64, ptr } %t582, 1
  %t586 = mul i64 %t584, 1
  %t587 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t586)
  call void @llvm.memcpy.p0.p0.i64(ptr %t587, ptr %t585, i64 %t586, i1 false)
  %t588 = insertvalue { i64, ptr } undef, i64 %t584, 0
  %t589 = insertvalue { i64, ptr } %t588, ptr %t587, 1
  %t591 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v3, ptr %v3, { i64, ptr } %t589)
  %t592 = extractvalue { i32, { i64, ptr } } %t591, 1
  %t593 = extractvalue { i32, { i64, ptr } } %t591, 0
  store i32 %t593, ptr %l294
  %t594 = icmp ne i32 %t593, 0
  br i1 %t594, label %bb135, label %ok.595
ok.595:
  store { i64, ptr } %t592, ptr %l293
  br label %bb134
bb134:
  %t596 = load { i64, ptr }, ptr %l293, !tbaa !27
  store { i64, ptr } %t596, ptr %l288, !tbaa !27
  br label %bb140
bb135:
  %t597 = load i32, ptr %l294, !tbaa !23
  %t598 = ashr i32 %t597, 16
  %t600 = icmp eq i32 %t598, 1
  br i1 %t600, label %bb136, label %bb137
bb136:
  br label %bb138
bb137:
  %t602 = load i32, ptr %l294, !tbaa !23
  %t603 = lshr i32 %t602, 16
  %t604 = and i32 %t602, 65535
  %t605 = icmp eq i32 %t603, 1
  %t606 = select i1 %t605, i32 0, i32 0
  %t607 = icmp eq i32 %t602, 0
  %t608 = shl i32 %t606, 16
  %t609 = or i32 %t608, %t604
  %t610 = select i1 %t607, i32 0, i32 %t609
  call void @__olang_scope_close(ptr %s27)
  call void @__olang_scope_close(ptr %s26)
  call void @__olang_scope_close(ptr %s24)
  call void @__olang_scope_close(ptr %s23)
  call void @__olang_scope_close(ptr %s22)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t610, ptr %rv
  br label %ret
bb138:
  store %olang.scope zeroinitializer, ptr %s29
  %t612 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t613 = extractvalue { i64, ptr } { i64 11, ptr @.d107 }, 1
  %t614 = extractvalue { i64, ptr } { i64 11, ptr @.d107 }, 0
  %t616 = extractvalue { i64, ptr } %t612, 1
  %t617 = extractvalue { i64, ptr } %t612, 0
  %t618 = add i64 %t614, %t617
  %t619 = extractvalue { i64, ptr } { i64 27, ptr @.d108 }, 1
  %t620 = extractvalue { i64, ptr } { i64 27, ptr @.d108 }, 0
  %t621 = add i64 %t618, %t620
  %t622 = call ptr @__olang_scope_alloc(ptr %s29, i64 %t621)
  call void @olang_textcopy(ptr %t622, ptr %t613, i64 %t614)
  %t623 = getelementptr i8, ptr %t622, i64 %t614
  call void @olang_textcopy(ptr %t623, ptr %t616, i64 %t617)
  %t624 = getelementptr i8, ptr %t623, i64 %t617
  call void @olang_textcopy(ptr %t624, ptr %t619, i64 %t620)
  %t625 = insertvalue { i64, ptr } undef, i64 %t621, 0
  %t626 = insertvalue { i64, ptr } %t625, ptr %t622, 1
  %t628 = extractvalue { i64, ptr } %t626, 0
  %t629 = extractvalue { i64, ptr } %t626, 1
  %t630 = mul i64 %t628, 1
  %t631 = call ptr @__olang_scope_alloc(ptr %s29, i64 %t630)
  call void @llvm.memcpy.p0.p0.i64(ptr %t631, ptr %t629, i64 %t630, i1 false)
  %t632 = insertvalue { i64, ptr } undef, i64 %t628, 0
  %t633 = insertvalue { i64, ptr } %t632, ptr %t631, 1
  call void @compiler_2fbuild_2eUnbuildable(ptr %s29, { i64, ptr } %t633)
  br label %bb139
bb139:
  call void @__olang_scope_close(ptr %s29)
  call void @__olang_scope_close(ptr %s27)
  call void @__olang_scope_close(ptr %s26)
  call void @__olang_scope_close(ptr %s24)
  call void @__olang_scope_close(ptr %s23)
  call void @__olang_scope_close(ptr %s22)
  call void @__olang_scope_close(ptr %s0)
  store i32 65537, ptr %rv
  br label %ret
bb140:
  %t636 = load { i64, ptr }, ptr %l288, !tbaa !27
  store { i64, ptr } %t636, ptr %l47, !tbaa !27
  %t637 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } { i64 16, ptr @.d109 }, ptr %l304, !tbaa !27
  %t640 = load { i64, ptr }, ptr %l304, !tbaa !27
  %t641 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v3, ptr %s27, { i64, ptr } %t637, { i64, ptr } %t640)
  store i1 %t641, ptr %l305
  br label %bb141
bb141:
  %t642 = load i1, ptr %l305, !tbaa !21
  br i1 %t642, label %bb142, label %bb143
bb142:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb144
bb143:
  br label %bb144
bb144:
  %t643 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t645 = extractvalue { i64, ptr } %t643, 1
  %t646 = extractvalue { i64, ptr } %t643, 0
  %t647 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t646)
  call void @olang_textcopy(ptr %t647, ptr %t645, i64 %t646)
  %t648 = insertvalue { i64, ptr } undef, i64 %t646, 0
  %t649 = insertvalue { i64, ptr } %t648, ptr %t647, 1
  %t651 = extractvalue { i64, ptr } %t649, 0
  %t652 = extractvalue { i64, ptr } %t649, 1
  %t653 = mul i64 %t651, 1
  %t654 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t653)
  call void @llvm.memcpy.p0.p0.i64(ptr %t654, ptr %t652, i64 %t653, i1 false)
  %t655 = insertvalue { i64, ptr } undef, i64 %t651, 0
  %t656 = insertvalue { i64, ptr } %t655, ptr %t654, 1
  %t657 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t661 = call %"compiler/build:Unit" @compiler_2fbuild_3aUnit_2ector(ptr %v3, ptr %v3, ptr %v3, { i64, ptr } %t656, i32 0, { i64, ptr } %t657)
  store %"compiler/build:Unit" %t661, ptr %l311
  br label %bb145
bb145:
  %t662 = load %"compiler/build:Unit", ptr %l311
  %t663 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 56, i64 8)
  store %"compiler/build:Unit" %t662, ptr %t663
  store ptr %t663, ptr %l48, !tbaa !29
  %t665 = load ptr, ptr %l48, !tbaa !29
  store ptr %t665, ptr %l313, !tbaa !29
  %t666 = getelementptr %"compiler/emit:Reused", ptr %l37, i32 0, i32 2
  %t667 = load i64, ptr %l45, !tbaa !24
  %t670 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v2, ptr %s27, ptr %t666, i64 %t667)
  store { i64, ptr } %t670, ptr %l316
  br label %bb146
bb146:
  %t671 = load { i64, ptr }, ptr %l316, !tbaa !27
  %t672 = extractvalue { i64, ptr } %t671, 1
  %t673 = extractvalue { i64, ptr } %t671, 0
  %t674 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t673)
  call void @olang_textcopy(ptr %t674, ptr %t672, i64 %t673)
  %t675 = insertvalue { i64, ptr } undef, i64 %t673, 0
  %t676 = insertvalue { i64, ptr } %t675, ptr %t674, 1
  %t678 = extractvalue { i64, ptr } %t676, 0
  %t679 = extractvalue { i64, ptr } %t676, 1
  %t680 = mul i64 %t678, 1
  %t681 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t680)
  call void @llvm.memcpy.p0.p0.i64(ptr %t681, ptr %t679, i64 %t680, i1 false)
  %t682 = insertvalue { i64, ptr } undef, i64 %t678, 0
  %t683 = insertvalue { i64, ptr } %t682, ptr %t681, 1
  %t685 = load ptr, ptr %l313, !tbaa !29
  %t686 = getelementptr %"compiler/build:Unit", ptr %t685, i32 0, i32 3
  store { i64, ptr } %t683, ptr %t686, !tbaa !27
  %t687 = load ptr, ptr %l4, !tbaa !29
  %t689 = getelementptr %"compiler/build:Program", ptr %t687, i32 0, i32 0
  %t690 = load ptr, ptr %l48, !tbaa !29
  %t692 = load %"compiler/build:Unit", ptr %t690
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2ePush_3ccompiler_2fbuild_3aUnit_3e(ptr %v3, ptr %v3, ptr %t689, %"compiler/build:Unit" %t692)
  br label %bb147
bb147:
  call void @__olang_scope_close(ptr %s27)
  br label %bb148
bb148:
  %t695 = load i64, ptr %l44, !tbaa !24
  %t697 = add i64 %t695, 1
  store i64 %t697, ptr %l44, !tbaa !24
  %t699 = load i64, ptr %l41, !tbaa !24
  %t701 = add i64 %t699, 1
  store i64 %t701, ptr %l41, !tbaa !24
  br label %bb130
bb149:
  %t703 = load i64, ptr %l40, !tbaa !24
  %t704 = load i64, ptr %l43, !tbaa !24
  %t707 = add i64 %t703, %t704
  store i64 %t707, ptr %l40, !tbaa !24
  call void @__olang_scope_close(ptr %s26)
  br label %bb150
bb150:
  br label %bb123
bb151:
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l30, { i64, ptr } { i64 0, ptr @.d110 })
  br label %bb152
bb152:
  call void @__olang_scope_close(ptr %s24)
  call void @__olang_scope_close(ptr %s23)
  br label %bb187
bb153:
  %t710 = getelementptr %"compiler/emit:Object", ptr %l36, i32 0, i32 2
  %t711 = load { i64, ptr }, ptr %t710, !tbaa !27
  store { i64, ptr } %t711, ptr %l49, !tbaa !27
  %t713 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } { i64 16, ptr @.d111 }, ptr %l334, !tbaa !27
  %t716 = load { i64, ptr }, ptr %l334, !tbaa !27
  %t717 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v3, ptr %s23, { i64, ptr } %t713, { i64, ptr } %t716)
  store i1 %t717, ptr %l335
  br label %bb154
bb154:
  %t718 = load i1, ptr %l335, !tbaa !21
  br i1 %t718, label %bb155, label %bb156
bb155:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb157
bb156:
  br label %bb157
bb157:
  %t719 = getelementptr %"compiler/emit:Object", ptr %l36, i32 0, i32 1
  %t720 = load i32, ptr %t719
  store i32 %t720, ptr %l50
  %t722 = load i32, ptr %l50
  %t724 = trunc i64 0 to i32
  %t725 = icmp eq i32 %t722, %t724
  br i1 %t725, label %bb158, label %bb159
bb158:
  br label %bb160
bb159:
  br label %bb161
bb160:
  store i32 0, ptr %l337
  br label %bb174
bb161:
  %t728 = load i32, ptr %l50
  %t730 = trunc i64 1 to i32
  %t731 = icmp eq i32 %t728, %t730
  br i1 %t731, label %bb162, label %bb163
bb162:
  br label %bb164
bb163:
  br label %bb165
bb164:
  store i32 1, ptr %l337
  br label %bb174
bb165:
  %t734 = load i32, ptr %l50
  %t736 = trunc i64 2 to i32
  %t737 = icmp eq i32 %t734, %t736
  br i1 %t737, label %bb166, label %bb167
bb166:
  br label %bb168
bb167:
  br label %bb169
bb168:
  store i32 2, ptr %l337
  br label %bb174
bb169:
  %t740 = load i32, ptr %l50
  %t742 = trunc i64 3 to i32
  %t743 = icmp eq i32 %t740, %t742
  br i1 %t743, label %bb170, label %bb171
bb170:
  br label %bb172
bb171:
  br label %bb173
bb172:
  store i32 3, ptr %l337
  br label %bb174
bb173:
  call void @__olang_check_failed(ptr @.c112)
  unreachable
bb174:
  %t746 = load i32, ptr %l337
  %t747 = getelementptr %"compiler/emit:Object", ptr %l36, i32 0, i32 0
  %t748 = load { i64, ptr }, ptr %t747, !tbaa !27
  %t750 = extractvalue { i64, ptr } %t748, 1
  %t751 = extractvalue { i64, ptr } %t748, 0
  %t752 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t751)
  call void @olang_textcopy(ptr %t752, ptr %t750, i64 %t751)
  %t753 = insertvalue { i64, ptr } undef, i64 %t751, 0
  %t754 = insertvalue { i64, ptr } %t753, ptr %t752, 1
  %t756 = extractvalue { i64, ptr } %t754, 0
  %t757 = extractvalue { i64, ptr } %t754, 1
  %t758 = mul i64 %t756, 1
  %t759 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t758)
  call void @llvm.memcpy.p0.p0.i64(ptr %t759, ptr %t757, i64 %t758, i1 false)
  %t760 = insertvalue { i64, ptr } undef, i64 %t756, 0
  %t761 = insertvalue { i64, ptr } %t760, ptr %t759, 1
  %t763 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t767 = call %"compiler/build:Unit" @compiler_2fbuild_3aUnit_2ector(ptr %v3, ptr %v3, ptr %v3, { i64, ptr } %t761, i32 %t746, { i64, ptr } %t763)
  store %"compiler/build:Unit" %t767, ptr %l355
  br label %bb175
bb175:
  %t768 = load %"compiler/build:Unit", ptr %l355
  %t769 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 56, i64 8)
  store %"compiler/build:Unit" %t768, ptr %t769
  store ptr %t769, ptr %l52, !tbaa !29
  %t771 = load i32, ptr %l2
  store i32 %t771, ptr %l357
  store i32 0, ptr %l359
  %t774 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fbuild_3aKind(ptr %l357, ptr %l359)
  store i1 %t774, ptr %l361
  br label %bb176
bb176:
  %t775 = load i1, ptr %l361, !tbaa !21
  %t776 = xor i1 %t775, true
  br i1 %t776, label %bb177, label %bb178
bb177:
  %t778 = getelementptr %"compiler/emit:Object", ptr %l36, i32 0, i32 1
  %t779 = load i32, ptr %t778
  store i32 %t779, ptr %l364
  store i32 0, ptr %l366
  %t782 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2femit_3aObjectKind(ptr %l364, ptr %l366)
  store i1 %t782, ptr %l368
  br label %bb179
bb178:
  store i1 false, ptr %l363, !tbaa !21
  br label %bb180
bb179:
  %t783 = load i1, ptr %l368, !tbaa !21
  store i1 %t783, ptr %l363, !tbaa !21
  br label %bb180
bb180:
  %t784 = load i1, ptr %l363, !tbaa !21
  br i1 %t784, label %bb181, label %bb182
bb181:
  %t785 = load ptr, ptr %l52, !tbaa !29
  store ptr %t785, ptr %l369, !tbaa !29
  %t786 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t788 = call { i64, ptr } @compiler_2fbuild_2eIrHash(ptr %v3, ptr %v3, { i64, ptr } %t786)
  store { i64, ptr } %t788, ptr %l371
  br label %bb183
bb182:
  br label %bb184
bb183:
  %t789 = load { i64, ptr }, ptr %l371, !tbaa !27
  %t790 = extractvalue { i64, ptr } %t789, 0
  %t791 = extractvalue { i64, ptr } %t789, 1
  %t792 = mul i64 %t790, 1
  %t793 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t792)
  call void @llvm.memcpy.p0.p0.i64(ptr %t793, ptr %t791, i64 %t792, i1 false)
  %t794 = insertvalue { i64, ptr } undef, i64 %t790, 0
  %t795 = insertvalue { i64, ptr } %t794, ptr %t793, 1
  %t797 = load ptr, ptr %l369, !tbaa !29
  %t798 = getelementptr %"compiler/build:Unit", ptr %t797, i32 0, i32 3
  store { i64, ptr } %t795, ptr %t798, !tbaa !27
  br label %bb184
bb184:
  %t799 = load ptr, ptr %l52, !tbaa !29
  %t801 = getelementptr %"compiler/build:Unit", ptr %t799, i32 0, i32 3
  %t802 = load { i64, ptr }, ptr %t801, !tbaa !27
  %t804 = extractvalue { i64, ptr } %t802, 1
  %t805 = extractvalue { i64, ptr } %t802, 0
  %t806 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t805)
  call void @olang_textcopy(ptr %t806, ptr %t804, i64 %t805)
  %t807 = insertvalue { i64, ptr } undef, i64 %t805, 0
  %t808 = insertvalue { i64, ptr } %t807, ptr %t806, 1
  %t810 = extractvalue { i64, ptr } %t808, 0
  %t811 = extractvalue { i64, ptr } %t808, 1
  %t812 = mul i64 %t810, 1
  %t813 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t812)
  call void @llvm.memcpy.p0.p0.i64(ptr %t813, ptr %t811, i64 %t812, i1 false)
  %t814 = insertvalue { i64, ptr } undef, i64 %t810, 0
  %t815 = insertvalue { i64, ptr } %t814, ptr %t813, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l30, { i64, ptr } %t815)
  br label %bb185
bb185:
  %t818 = load ptr, ptr %l4, !tbaa !29
  %t820 = getelementptr %"compiler/build:Program", ptr %t818, i32 0, i32 0
  %t821 = load ptr, ptr %l52, !tbaa !29
  %t823 = load %"compiler/build:Unit", ptr %t821
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2ePush_3ccompiler_2fbuild_3aUnit_3e(ptr %v3, ptr %v3, ptr %t820, %"compiler/build:Unit" %t823)
  br label %bb186
bb186:
  call void @__olang_scope_close(ptr %s23)
  br label %bb187
bb187:
  %t826 = load i64, ptr %l35, !tbaa !24
  %t828 = add i64 %t826, 1
  store i64 %t828, ptr %l35, !tbaa !24
  br label %bb114
bb188:
  %t830 = load i64, ptr %l32, !tbaa !24
  %t831 = load i64, ptr %l34, !tbaa !24
  %t834 = add i64 %t830, %t831
  store i64 %t834, ptr %l32, !tbaa !24
  call void @__olang_scope_close(ptr %s22)
  br label %bb189
bb189:
  br label %bb107
bb190:
  %t836 = load i32, ptr %l2
  store i32 %t836, ptr %l387
  store i32 0, ptr %l389
  %t839 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fbuild_3aKind(ptr %l387, ptr %l389)
  store i1 %t839, ptr %l391
  br label %bb191
bb191:
  %t840 = load i1, ptr %l391, !tbaa !21
  %t841 = xor i1 %t840, true
  br i1 %t841, label %bb192, label %bb193
bb192:
  %t843 = load ptr, ptr %l7, !tbaa !29
  %t844 = load ptr, ptr %l3, !tbaa !29
  %t845 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t846 = load ptr, ptr %l13, !tbaa !29
  %t848 = getelementptr %"compiler/emit:Emitter", ptr %t846, i32 0, i32 60
  call void @compiler_2folang_2ekeep(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v3, ptr %s0, ptr %t843, ptr %t844, { i64, ptr } %t845, ptr %t848, ptr %l15, ptr %l30)
  br label %bb194
bb193:
  br label %bb195
bb194:
  br label %bb195
bb195:
  %t855 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 16, ptr @.d113 })
  %t856 = extractvalue { i32, { i64, ptr } } %t855, 1
  %t857 = extractvalue { i32, { i64, ptr } } %t855, 0
  store i32 %t857, ptr %l402
  %t858 = icmp ne i32 %t857, 0
  br i1 %t858, label %bb197, label %ok.859
ok.859:
  store { i64, ptr } %t856, ptr %l401
  br label %bb196
bb196:
  %t860 = load { i64, ptr }, ptr %l401, !tbaa !27
  store { i64, ptr } %t860, ptr %l400, !tbaa !27
  br label %bb199
bb197:
  br label %bb198
bb198:
  store { i64, ptr } { i64 0, ptr @.d114 }, ptr %l403, !tbaa !27
  %t861 = load { i64, ptr }, ptr %l403, !tbaa !27
  %t863 = extractvalue { i64, ptr } %t861, 0
  %t864 = extractvalue { i64, ptr } %t861, 1
  %t865 = mul i64 %t863, 1
  %t866 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t865)
  call void @llvm.memcpy.p0.p0.i64(ptr %t866, ptr %t864, i64 %t865, i1 false)
  %t867 = insertvalue { i64, ptr } undef, i64 %t863, 0
  %t868 = insertvalue { i64, ptr } %t867, ptr %t866, 1
  store { i64, ptr } %t868, ptr %l400, !tbaa !27
  br label %bb199
bb199:
  %t870 = load { i64, ptr }, ptr %l400, !tbaa !27
  %t871 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t870, { i64, ptr } { i64 0, ptr @.d115 })
  store i1 %t871, ptr %l406
  br label %bb200
bb200:
  %t872 = load i1, ptr %l406, !tbaa !21
  %t873 = xor i1 %t872, true
  br i1 %t873, label %bb201, label %bb202
bb201:
  %t875 = load ptr, ptr %l13, !tbaa !29
  %t876 = load ptr, ptr %l4, !tbaa !29
  %t877 = load ptr, ptr %l8, !tbaa !29
  %t878 = load ptr, ptr %l12, !tbaa !29
  %t879 = load ptr, ptr %l5, !tbaa !29
  %t880 = load ptr, ptr %l3, !tbaa !29
  %t881 = load i32, ptr %l2
  %t882 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2folang_2echeckReuse(ptr %v2, ptr %v3, ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %t875, ptr %t876, ptr %t877, ptr %t878, ptr %t879, ptr %t880, i32 %t881, ptr %t882)
  br label %bb203
bb202:
  br label %bb204
bb203:
  br label %bb204
bb204:
  %t891 = load ptr, ptr %l4, !tbaa !29
  store ptr %t891, ptr %l416, !tbaa !29
  %t892 = getelementptr %"compiler/target:Target", ptr %l28, i32 0, i32 1
  %t893 = load { i64, ptr }, ptr %t892, !tbaa !27
  %t894 = getelementptr %"compiler/target:Target", ptr %l28, i32 0, i32 2
  %t895 = load { i64, ptr }, ptr %t894, !tbaa !27
  %t896 = getelementptr %"compiler/target:Target", ptr %l28, i32 0, i32 5
  %t897 = load { i64, ptr }, ptr %t896, !tbaa !27
  %t898 = load ptr, ptr %l3, !tbaa !29
  %t900 = getelementptr %"compiler/build:Config", ptr %t898, i32 0, i32 6
  %t901 = load i1, ptr %t900, !tbaa !21
  %t902 = load ptr, ptr %l3, !tbaa !29
  %t904 = getelementptr %"compiler/build:Config", ptr %t902, i32 0, i32 5
  %t905 = load i1, ptr %t904, !tbaa !21
  %t911 = call { i32, { i64, ptr } } @compiler_2fruntime_2eIr(ptr %v2, ptr %v2, ptr %v2, ptr %v3, { i64, ptr } %t893, { i64, ptr } %t895, { i64, ptr } %t897, i1 %t901, i1 %t905)
  %t912 = extractvalue { i32, { i64, ptr } } %t911, 1
  %t913 = extractvalue { i32, { i64, ptr } } %t911, 0
  store i32 %t913, ptr %l426
  %t914 = icmp ne i32 %t913, 0
  br i1 %t914, label %bb206, label %ok.915
ok.915:
  store { i64, ptr } %t912, ptr %l425
  br label %bb205
bb205:
  %t916 = load { i64, ptr }, ptr %l425, !tbaa !27
  store { i64, ptr } %t916, ptr %l417, !tbaa !27
  br label %bb210
bb206:
  %t917 = load i32, ptr %l426, !tbaa !23
  %t918 = ashr i32 %t917, 16
  %t920 = icmp eq i32 %t918, 1
  br i1 %t920, label %bb207, label %bb208
bb207:
  br label %bb209
bb208:
  %t922 = load i32, ptr %l426, !tbaa !23
  %t923 = lshr i32 %t922, 16
  %t924 = and i32 %t922, 65535
  %t925 = icmp eq i32 %t923, 1
  %t926 = select i1 %t925, i32 0, i32 0
  %t927 = icmp eq i32 %t922, 0
  %t928 = shl i32 %t926, 16
  %t929 = or i32 %t928, %t924
  %t930 = select i1 %t927, i32 0, i32 %t929
  call void @__olang_scope_close(ptr %s0)
  store i32 %t930, ptr %rv
  br label %ret
bb209:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb210:
  %t933 = load { i64, ptr }, ptr %l417, !tbaa !27
  %t934 = extractvalue { i64, ptr } %t933, 0
  %t935 = extractvalue { i64, ptr } %t933, 1
  %t936 = mul i64 %t934, 1
  %t937 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t936)
  call void @llvm.memcpy.p0.p0.i64(ptr %t937, ptr %t935, i64 %t936, i1 false)
  %t938 = insertvalue { i64, ptr } undef, i64 %t934, 0
  %t939 = insertvalue { i64, ptr } %t938, ptr %t937, 1
  %t941 = load ptr, ptr %l416, !tbaa !29
  %t942 = getelementptr %"compiler/build:Program", ptr %t941, i32 0, i32 1
  store { i64, ptr } %t939, ptr %t942, !tbaa !27
  %t943 = load i1, ptr %l29, !tbaa !21
  br i1 %t943, label %bb211, label %bb212
bb211:
  %t945 = load ptr, ptr %l4, !tbaa !29
  store ptr %t945, ptr %l433, !tbaa !29
  %t946 = getelementptr %"compiler/target:Target", ptr %l28, i32 0, i32 1
  %t947 = load { i64, ptr }, ptr %t946, !tbaa !27
  %t948 = getelementptr %"compiler/target:Target", ptr %l28, i32 0, i32 2
  %t949 = load { i64, ptr }, ptr %t948, !tbaa !27
  %t950 = getelementptr %"compiler/target:Target", ptr %l28, i32 0, i32 5
  %t951 = load { i64, ptr }, ptr %t950, !tbaa !27
  %t952 = load ptr, ptr %l3, !tbaa !29
  %t954 = getelementptr %"compiler/build:Config", ptr %t952, i32 0, i32 6
  %t955 = load i1, ptr %t954, !tbaa !21
  %t956 = load ptr, ptr %l3, !tbaa !29
  %t958 = getelementptr %"compiler/build:Config", ptr %t956, i32 0, i32 5
  %t959 = load i1, ptr %t958, !tbaa !21
  %t965 = call { i32, { i64, ptr } } @compiler_2fruntime_2eDyncallIr(ptr %v2, ptr %v2, ptr %v2, ptr %v3, { i64, ptr } %t947, { i64, ptr } %t949, { i64, ptr } %t951, i1 %t955, i1 %t959)
  %t966 = extractvalue { i32, { i64, ptr } } %t965, 1
  %t967 = extractvalue { i32, { i64, ptr } } %t965, 0
  store i32 %t967, ptr %l443
  %t968 = icmp ne i32 %t967, 0
  br i1 %t968, label %bb214, label %ok.969
ok.969:
  store { i64, ptr } %t966, ptr %l442
  br label %bb213
bb212:
  br label %bb219
bb213:
  %t970 = load { i64, ptr }, ptr %l442, !tbaa !27
  store { i64, ptr } %t970, ptr %l434, !tbaa !27
  br label %bb218
bb214:
  %t971 = load i32, ptr %l443, !tbaa !23
  %t972 = ashr i32 %t971, 16
  %t974 = icmp eq i32 %t972, 1
  br i1 %t974, label %bb215, label %bb216
bb215:
  br label %bb217
bb216:
  %t976 = load i32, ptr %l443, !tbaa !23
  %t977 = lshr i32 %t976, 16
  %t978 = and i32 %t976, 65535
  %t979 = icmp eq i32 %t977, 1
  %t980 = select i1 %t979, i32 0, i32 0
  %t981 = icmp eq i32 %t976, 0
  %t982 = shl i32 %t980, 16
  %t983 = or i32 %t982, %t978
  %t984 = select i1 %t981, i32 0, i32 %t983
  call void @__olang_scope_close(ptr %s0)
  store i32 %t984, ptr %rv
  br label %ret
bb217:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb218:
  %t987 = load { i64, ptr }, ptr %l434, !tbaa !27
  %t988 = extractvalue { i64, ptr } %t987, 0
  %t989 = extractvalue { i64, ptr } %t987, 1
  %t990 = mul i64 %t988, 1
  %t991 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t990)
  call void @llvm.memcpy.p0.p0.i64(ptr %t991, ptr %t989, i64 %t990, i1 false)
  %t992 = insertvalue { i64, ptr } undef, i64 %t988, 0
  %t993 = insertvalue { i64, ptr } %t992, ptr %t991, 1
  %t995 = load ptr, ptr %l433, !tbaa !29
  %t996 = getelementptr %"compiler/build:Program", ptr %t995, i32 0, i32 2
  store { i64, ptr } %t993, ptr %t996, !tbaa !27
  br label %bb219
bb219:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, i32 } @compiler_2folang_2ecompiler_2folang_3aPasses_2eInterpret(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l4 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca i32
  %l15 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca i32
  %l24 = alloca %"compiler/check:Checker"
  %l26 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l29 = alloca i64
  %l33 = alloca i64
  %l36 = alloca i64
  %l39 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l41 = alloca i64
  %l49 = alloca %"compiler/interp:Exec"
  %l63 = alloca { i64, ptr }
  %l76 = alloca i32
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca { i32, i32 }
  %t28 = alloca %"compiler/check:Checker", align 8
  %t73 = alloca %"compiler/interp:Exec", align 8
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t4 = load ptr, ptr %l4, !tbaa !29
  %t9 = call { i32, ptr } @compiler_2folang_2ecompiler_2folang_3aPasses_2eload(ptr %v0, ptr %v1, ptr %v3, ptr %a0, { i64, ptr } %a1, ptr %a3, ptr %t4)
  %t10 = extractvalue { i32, ptr } %t9, 1
  %t11 = extractvalue { i32, ptr } %t9, 0
  store i32 %t11, ptr %l21
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb2, label %ok.13
ok.13:
  store ptr %t10, ptr %l20
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l20, !tbaa !29
  store ptr %t14, ptr %l15, !tbaa !29
  br label %bb3
bb2:
  %t15 = load i32, ptr %l21, !tbaa !23
  %t16 = lshr i32 %t15, 16
  %t17 = and i32 %t15, 65535
  %t18 = icmp eq i32 %t16, 1
  %t19 = select i1 %t18, i32 1, i32 0
  %t20 = icmp eq i32 %t15, 0
  %t21 = shl i32 %t19, 16
  %t22 = or i32 %t21, %t17
  %t23 = select i1 %t20, i32 0, i32 %t22
  %t25 = insertvalue { i32, i32 } zeroinitializer, i32 %t23, 0
  store { i32, i32 } %t25, ptr %rv
  br label %ret
bb3:
  %t26 = load ptr, ptr %l15, !tbaa !29
  call void @compiler_2finterp_2eAnalyze(ptr %t28, ptr %v3, ptr %v3, ptr %t26, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l24, ptr %t28, i64 568, i1 false)
  br label %bb4
bb4:
  %t30 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 568, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %l24, i64 568, i1 false)
  store ptr %t30, ptr %l6, !tbaa !29
  %t32 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v3)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t32, ptr %l26
  br label %bb5
bb5:
  %t33 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l26
  %t34 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 8, i64 8)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t33, ptr %t34
  store ptr %t34, ptr %l7, !tbaa !29
  %t36 = load ptr, ptr %l4, !tbaa !29
  %t38 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v3, ptr %t36)
  store i64 %t38, ptr %l29
  br label %bb6
bb6:
  %t39 = load i64, ptr %l29, !tbaa !24
  %t40 = icmp eq i64 %t39, 0
  store i1 %t40, ptr %l8, !tbaa !21
  %t42 = load i1, ptr %l8, !tbaa !21
  br i1 %t42, label %bb7, label %bb8
bb7:
  %t44 = load ptr, ptr %l6, !tbaa !29
  %t46 = call i64 @compiler_2finterp_2eDecideValues(ptr %v3, ptr %t44)
  store i64 %t46, ptr %l33
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb10
bb10:
  %t47 = load ptr, ptr %l6, !tbaa !29
  %t48 = load ptr, ptr %l7, !tbaa !29
  %t51 = call i64 @compiler_2finterp_2eDecideAsserts(ptr %v3, ptr %v3, ptr %t47, ptr %t48)
  store i64 %t51, ptr %l36
  br label %bb11
bb11:
  %t52 = load i1, ptr %l8, !tbaa !21
  br i1 %t52, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t54 = load ptr, ptr %l6, !tbaa !29
  %t56 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2finterp_2eBake(ptr %v3, ptr %s2, ptr %t54)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t56, ptr %l39
  br label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb15:
  %t57 = load ptr, ptr %l4, !tbaa !29
  %t59 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v3, ptr %t57)
  store i64 %t59, ptr %l41
  br label %bb16
bb16:
  %t60 = load i64, ptr %l41, !tbaa !24
  %t61 = icmp sgt i64 %t60, 0
  br i1 %t61, label %bb17, label %bb18
bb17:
  %t64 = insertvalue { i32, i32 } zeroinitializer, i32 65536, 0
  store { i32, i32 } %t64, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t65 = load ptr, ptr %l6, !tbaa !29
  %t67 = getelementptr %"compiler/check:Checker", ptr %t65, i32 0, i32 0
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t69 = load ptr, ptr %l6, !tbaa !29
  %t71 = getelementptr %"compiler/check:Checker", ptr %t69, i32 0, i32 4
  %t72 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t71
  call void @compiler_2finterp_3aExec_2ector(ptr %t73, ptr %v3, ptr %v3, ptr %v3, ptr %t68, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t72, i32 1)
  call void @llvm.memmove.p0.p0.i64(ptr %l49, ptr %t73, i64 880, i1 false)
  br label %bb20
bb20:
  %t77 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 880, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t77, ptr %l49, i64 880, i1 false)
  store ptr %t77, ptr %l9, !tbaa !29
  %t79 = load ptr, ptr %l9, !tbaa !29
  %t80 = load ptr, ptr %l7, !tbaa !29
  %t82 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t80
  %t85 = getelementptr %"compiler/interp:Exec", ptr %t79, i32 0, i32 3
  %t86 = getelementptr %"compiler/lower:Lowerer", ptr %t85, i32 0, i32 6
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t82, ptr %t86
  %t87 = load ptr, ptr %l9, !tbaa !29
  %t89 = getelementptr %"compiler/interp:Exec", ptr %t87, i32 0, i32 3
  %t90 = getelementptr %"compiler/lower:Lowerer", ptr %t89, i32 0, i32 5
  store i1 true, ptr %t90, !tbaa !21
  %t91 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2finterp_2ecompiler_2finterp_3aExec_2ePlace(ptr %v3, ptr %t91)
  br label %bb21
bb21:
  store { i64, ptr } %a2, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t95 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t95, 0
  store i64 %t97, ptr %l12, !tbaa !24
  br label %bb22
bb22:
  store %olang.scope zeroinitializer, ptr %s5
  %t99 = load i64, ptr %l11, !tbaa !24
  %t100 = load i64, ptr %l12, !tbaa !24
  %t103 = icmp slt i64 %t99, %t100
  %t105 = xor i1 %t103, true
  br i1 %t105, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s5)
  br label %bb28
bb24:
  br label %bb25
bb25:
  %t107 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t107, ptr %l63, !tbaa !27
  %t108 = load i64, ptr %l11, !tbaa !24
  %t110 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr { i64, ptr }, ptr %t111, i64 %t108
  %t113 = load { i64, ptr }, ptr %t112, !tbaa !37
  %t115 = load ptr, ptr %l9, !tbaa !29
  %t117 = getelementptr %"compiler/interp:Exec", ptr %t115, i32 0, i32 4
  %t118 = getelementptr %"compiler/eval:Machine", ptr %t117, i32 0, i32 64
  %t121 = extractvalue { i64, ptr } %t113, 1
  %t122 = extractvalue { i64, ptr } %t113, 0
  %t123 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t122)
  call void @olang_textcopy(ptr %t123, ptr %t121, i64 %t122)
  %t124 = insertvalue { i64, ptr } undef, i64 %t122, 0
  %t125 = insertvalue { i64, ptr } %t124, ptr %t123, 1
  %t127 = extractvalue { i64, ptr } %t125, 0
  %t128 = extractvalue { i64, ptr } %t125, 1
  %t129 = mul i64 %t127, 1
  %t130 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t129)
  call void @llvm.memcpy.p0.p0.i64(ptr %t130, ptr %t128, i64 %t129, i1 false)
  %t131 = insertvalue { i64, ptr } undef, i64 %t127, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr %t130, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v3, ptr %v3, ptr %t118, { i64, ptr } %t132)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s5)
  br label %bb27
bb27:
  %t135 = load i64, ptr %l11, !tbaa !24
  %t137 = add i64 %t135, 1
  store i64 %t137, ptr %l11, !tbaa !24
  br label %bb22
bb28:
  %t139 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eInterpCrash, !tbaa !27
  %t140 = load ptr, ptr @__olang_prog_scope
  call void @std_2fos_2eOnCrash(ptr %t140, { i64, ptr } %t139)
  br label %bb29
bb29:
  %t142 = load ptr, ptr %l9, !tbaa !29
  %t143 = load ptr, ptr %l4, !tbaa !29
  %t146 = call i32 @compiler_2finterp_2ecompiler_2finterp_3aExec_2eRunMain(ptr %v3, ptr %v3, ptr %t142, ptr %t143)
  store i32 %t146, ptr %l76
  br label %bb30
bb30:
  %t147 = load i32, ptr %l76, !tbaa !23
  store i32 %t147, ptr %l14, !tbaa !23
  %t148 = load i32, ptr %l14, !tbaa !23
  %t150 = icmp eq i32 %t148, 134
  br i1 %t150, label %bb31, label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s8
  call void @std_2fos_2eOnCrash(ptr %s8, { i64, ptr } { i64 0, ptr @.d116 })
  br label %bb33
bb32:
  br label %bb35
bb33:
  call void @abort()
  unreachable
bb34:
  call void @__olang_check_failed(ptr @.c117)
  unreachable
bb35:
  %t152 = load i32, ptr %l14, !tbaa !23
  %t154 = insertvalue { i32, i32 } zeroinitializer, i32 %t152, 1
  store { i32, i32 } %t154, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i32 }, ptr %rv
  ret { i32, i32 } %rr
}

define dso_local { i32, ptr } @compiler_2folang_2ecompiler_2folang_3aPasses_2eload(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l16 = alloca %"compiler/fetch:Fetcher"
  %l18 = alloca %"compiler/source:Names"
  %l20 = alloca { i64, ptr }
  %l27 = alloca %"compiler/load:Loader"
  %l31 = alloca i64
  %l32 = alloca ptr
  %l35 = alloca i64
  %l37 = alloca i64
  %rv = alloca { i32, ptr }
  store { i64, ptr } %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = call { i64, ptr } @compiler_2fload_2eLockPath(ptr %v1, ptr %v2, { i64, ptr } %t1)
  store { i64, ptr } %t3, ptr %l8
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t4, 0
  %t6 = extractvalue { i64, ptr } %t4, 1
  %t7 = mul i64 %t5, 1
  %t8 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t7)
  call void @llvm.memcpy.p0.p0.i64(ptr %t8, ptr %t6, i64 %t7, i1 false)
  %t9 = insertvalue { i64, ptr } undef, i64 %t5, 0
  %t10 = insertvalue { i64, ptr } %t9, ptr %t8, 1
  store { i64, ptr } %t10, ptr %l9, !tbaa !27
  %t11 = call { i64, ptr } @compiler_2ffetch_2eCacheDir(ptr %v2)
  store { i64, ptr } %t11, ptr %l10
  br label %bb2
bb2:
  %t12 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 0
  %t14 = extractvalue { i64, ptr } %t12, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l11, !tbaa !27
  %t19 = call { i64, ptr } @compiler_2ffetch_2eGitBase(ptr %v2)
  store { i64, ptr } %t19, ptr %l12
  br label %bb3
bb3:
  %t20 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t20, 0
  %t22 = extractvalue { i64, ptr } %t20, 1
  %t23 = mul i64 %t21, 1
  %t24 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t23)
  call void @llvm.memcpy.p0.p0.i64(ptr %t24, ptr %t22, i64 %t23, i1 false)
  %t25 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t24, 1
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t29 = getelementptr %"compiler/build:Config", ptr %t27, i32 0, i32 7
  %t30 = load i1, ptr %t29, !tbaa !21
  %t31 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t35 = call %"compiler/fetch:Fetcher" @compiler_2ffetch_3aFetcher_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t31, { i64, ptr } %t32, { i64, ptr } %t26, i1 %t30, i1 false)
  store %"compiler/fetch:Fetcher" %t35, ptr %l16
  br label %bb4
bb4:
  %t36 = load %"compiler/fetch:Fetcher", ptr %l16
  %t37 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 88, i64 8)
  store %"compiler/fetch:Fetcher" %t36, ptr %t37
  store ptr %t37, ptr %l4, !tbaa !29
  %t39 = call %"compiler/source:Names" @compiler_2fsource_3aNames_2ector(ptr %v2)
  store %"compiler/source:Names" %t39, ptr %l18
  br label %bb5
bb5:
  %t40 = load %"compiler/source:Names", ptr %l18
  %t41 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store %"compiler/source:Names" %t40, ptr %t41
  store ptr %t41, ptr %l5, !tbaa !29
  %t43 = call { i64, ptr } @compiler_2fload_2eStdDir(ptr %v2)
  store { i64, ptr } %t43, ptr %l20
  br label %bb6
bb6:
  %t44 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t44, 0
  %t46 = extractvalue { i64, ptr } %t44, 1
  %t47 = mul i64 %t45, 1
  %t48 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t47)
  call void @llvm.memcpy.p0.p0.i64(ptr %t48, ptr %t46, i64 %t47, i1 false)
  %t49 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  %t51 = load ptr, ptr %l2, !tbaa !29
  %t53 = getelementptr %"compiler/build:Config", ptr %t51, i32 0, i32 3
  %t54 = load ptr, ptr %l4, !tbaa !29
  %t55 = load ptr, ptr %l5, !tbaa !29
  %t56 = load ptr, ptr %l3, !tbaa !29
  %t62 = call %"compiler/load:Loader" @compiler_2fload_3aLoader_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t50, ptr %t53, ptr %t54, ptr %t55, ptr %t56)
  store %"compiler/load:Loader" %t62, ptr %l27
  br label %bb7
bb7:
  %t63 = load %"compiler/load:Loader", ptr %l27
  %t64 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 104, i64 8)
  store %"compiler/load:Loader" %t63, ptr %t64
  store ptr %t64, ptr %l6, !tbaa !29
  %t66 = load ptr, ptr %l6, !tbaa !29
  %t67 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t70 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eLoad(ptr %v2, ptr %v1, ptr %t66, { i64, ptr } %t67)
  store i64 %t70, ptr %l31
  br label %bb8
bb8:
  store ptr %a0, ptr %l32, !tbaa !29
  %t72 = load ptr, ptr %l6, !tbaa !29
  %t74 = getelementptr %"compiler/load:Loader", ptr %t72, i32 0, i32 5
  %t76 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v2, ptr %t74)
  store i64 %t76, ptr %l35
  br label %bb9
bb9:
  %t77 = load i64, ptr %l35, !tbaa !24
  %t78 = load ptr, ptr %l32, !tbaa !29
  %t79 = getelementptr %"compiler/olang:Passes", ptr %t78, i32 0, i32 0
  store i64 %t77, ptr %t79, !tbaa !24
  %t80 = load ptr, ptr %l3, !tbaa !29
  %t82 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v2, ptr %t80)
  store i64 %t82, ptr %l37
  br label %bb10
bb10:
  %t83 = load i64, ptr %l37, !tbaa !24
  %t84 = icmp sgt i64 %t83, 0
  br i1 %t84, label %bb11, label %bb12
bb11:
  %t87 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t87, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t88 = load ptr, ptr %l6, !tbaa !29
  %t90 = insertvalue { i32, ptr } zeroinitializer, ptr %t88, 1
  store { i32, ptr } %t90, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i32 @compiler_2folang_2edrive(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"compiler/olang:Passes"
  %l2 = alloca %"compiler/olang:Passes"
  %l5 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"compiler/olang:Passes" @compiler_2folang_3aPasses_2ector(ptr %s0)
  store %"compiler/olang:Passes" %t1, ptr %l2
  br label %bb1
bb1:
  %t2 = load %"compiler/olang:Passes", ptr %l2
  store %"compiler/olang:Passes" %t2, ptr %l1
  %t6 = call i32 @compiler_2folang_2eRunWith_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %s0, { i64, ptr } %a0, ptr %l1)
  store i32 %t6, ptr %l5
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t7 = load i32, ptr %l5, !tbaa !23
  store i32 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local ptr @compiler_2folang_2eemitter(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, ptr %a3, i32 %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca i32
  %l10 = alloca i32
  %l12 = alloca i1
  %l20 = alloca %"compiler/emit:Emitter"
  %l27 = alloca ptr
  %l30 = alloca { i64, ptr }
  %l35 = alloca ptr
  %l36 = alloca i32
  %l38 = alloca i32
  %l40 = alloca i1
  %l55 = alloca ptr
  %l58 = alloca i1
  %rv = alloca ptr
  %t18 = alloca %"compiler/emit:Emitter", align 8
  store ptr %a0, ptr %l0
  store ptr %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l4
  store i32 %t1, ptr %l8
  store i32 2, ptr %l10
  %t4 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fbuild_3aKind(ptr %l8, ptr %l10)
  store i1 %t4, ptr %l12
  br label %bb1
bb1:
  %t5 = load i1, ptr %l12, !tbaa !21
  store i1 %t5, ptr %l6, !tbaa !21
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 0
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 0
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  call void @compiler_2femit_3aEmitter_2ector(ptr %t18, ptr %v0, ptr %v1, ptr %v2, ptr %v0, ptr %v3, ptr %t9, ptr %a1, ptr %a2, ptr %t17)
  call void @llvm.memmove.p0.p0.i64(ptr %l20, ptr %t18, i64 504, i1 false)
  br label %bb2
bb2:
  %t23 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 504, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t23, ptr %l20, i64 504, i1 false)
  store ptr %t23, ptr %l7, !tbaa !29
  %t25 = load ptr, ptr %l7, !tbaa !29
  %t26 = load i1, ptr %l6, !tbaa !21
  %t29 = getelementptr %"compiler/emit:Emitter", ptr %t25, i32 0, i32 4
  store i1 %t26, ptr %t29, !tbaa !21
  %t30 = load ptr, ptr %l7, !tbaa !29
  %t33 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a5
  %t36 = getelementptr %"compiler/emit:Emitter", ptr %t30, i32 0, i32 42
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t33, ptr %t36
  %t37 = load ptr, ptr %l7, !tbaa !29
  store ptr %t37, ptr %l27, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t40 = getelementptr %"compiler/build:Config", ptr %t38, i32 0, i32 5
  %t41 = load i1, ptr %t40, !tbaa !21
  br i1 %t41, label %bb3, label %bb4
bb3:
  store { i64, ptr } { i64 16, ptr @.d118 }, ptr %l30, !tbaa !27
  br label %bb5
bb4:
  store { i64, ptr } { i64 0, ptr @.d119 }, ptr %l30, !tbaa !27
  br label %bb5
bb5:
  %t43 = load ptr, ptr %l3, !tbaa !29
  %t45 = getelementptr %"compiler/build:Config", ptr %t43, i32 0, i32 2
  %t46 = getelementptr %"compiler/target:Target", ptr %t45, i32 0, i32 5
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t48, 1
  %t50 = extractvalue { i64, ptr } %t48, 0
  %t52 = extractvalue { i64, ptr } %t47, 1
  %t53 = extractvalue { i64, ptr } %t47, 0
  %t54 = add i64 %t50, %t53
  %t55 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t54)
  call void @olang_textcopy(ptr %t55, ptr %t49, i64 %t50)
  %t56 = getelementptr i8, ptr %t55, i64 %t50
  call void @olang_textcopy(ptr %t56, ptr %t52, i64 %t53)
  %t57 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t55, 1
  %t60 = extractvalue { i64, ptr } %t58, 0
  %t61 = extractvalue { i64, ptr } %t58, 1
  %t62 = mul i64 %t60, 1
  %t63 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t62)
  call void @llvm.memcpy.p0.p0.i64(ptr %t63, ptr %t61, i64 %t62, i1 false)
  %t64 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t63, 1
  %t67 = load ptr, ptr %l27, !tbaa !29
  %t68 = getelementptr %"compiler/emit:Emitter", ptr %t67, i32 0, i32 7
  store { i64, ptr } %t65, ptr %t68, !tbaa !27
  %t69 = load ptr, ptr %l7, !tbaa !29
  store ptr %t69, ptr %l35, !tbaa !29
  %t70 = load i32, ptr %l4
  store i32 %t70, ptr %l36
  store i32 0, ptr %l38
  %t73 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fbuild_3aKind(ptr %l36, ptr %l38)
  store i1 %t73, ptr %l40
  br label %bb6
bb6:
  %t74 = load i1, ptr %l40, !tbaa !21
  %t75 = load ptr, ptr %l35, !tbaa !29
  %t76 = getelementptr %"compiler/emit:Emitter", ptr %t75, i32 0, i32 37
  store i1 %t74, ptr %t76, !tbaa !21
  %t77 = load ptr, ptr %l7, !tbaa !29
  %t78 = load ptr, ptr %l3, !tbaa !29
  %t80 = getelementptr %"compiler/build:Config", ptr %t78, i32 0, i32 2
  %t81 = getelementptr %"compiler/target:Target", ptr %t80, i32 0, i32 1
  %t82 = load { i64, ptr }, ptr %t81, !tbaa !27
  %t85 = getelementptr %"compiler/emit:Emitter", ptr %t77, i32 0, i32 20
  store { i64, ptr } %t82, ptr %t85, !tbaa !27
  %t86 = load ptr, ptr %l7, !tbaa !29
  %t87 = load ptr, ptr %l3, !tbaa !29
  %t89 = getelementptr %"compiler/build:Config", ptr %t87, i32 0, i32 2
  %t90 = getelementptr %"compiler/target:Target", ptr %t89, i32 0, i32 2
  %t91 = load { i64, ptr }, ptr %t90, !tbaa !27
  %t94 = getelementptr %"compiler/emit:Emitter", ptr %t86, i32 0, i32 43
  store { i64, ptr } %t91, ptr %t94, !tbaa !27
  %t95 = load ptr, ptr %l7, !tbaa !29
  %t96 = load ptr, ptr %l3, !tbaa !29
  %t98 = getelementptr %"compiler/build:Config", ptr %t96, i32 0, i32 6
  %t99 = load i1, ptr %t98, !tbaa !21
  %t102 = getelementptr %"compiler/emit:Emitter", ptr %t95, i32 0, i32 44
  store i1 %t99, ptr %t102, !tbaa !21
  %t103 = load ptr, ptr %l7, !tbaa !29
  %t104 = load ptr, ptr %l3, !tbaa !29
  %t106 = getelementptr %"compiler/build:Config", ptr %t104, i32 0, i32 4
  %t107 = load i1, ptr %t106, !tbaa !21
  %t110 = getelementptr %"compiler/emit:Emitter", ptr %t103, i32 0, i32 5
  store i1 %t107, ptr %t110, !tbaa !21
  %t111 = load ptr, ptr %l7, !tbaa !29
  %t112 = load i1, ptr %l6, !tbaa !21
  %t115 = getelementptr %"compiler/emit:Emitter", ptr %t111, i32 0, i32 6
  store i1 %t112, ptr %t115, !tbaa !21
  %t116 = load ptr, ptr %l7, !tbaa !29
  store ptr %t116, ptr %l55, !tbaa !29
  %t117 = load ptr, ptr %l3, !tbaa !29
  %t119 = getelementptr %"compiler/build:Config", ptr %t117, i32 0, i32 4
  %t120 = load i1, ptr %t119, !tbaa !21
  br i1 %t120, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l58, !tbaa !21
  br label %bb9
bb8:
  %t122 = load ptr, ptr %l3, !tbaa !29
  %t124 = getelementptr %"compiler/build:Config", ptr %t122, i32 0, i32 5
  %t125 = load i1, ptr %t124, !tbaa !21
  store i1 %t125, ptr %l58, !tbaa !21
  br label %bb9
bb9:
  %t127 = load i1, ptr %l58, !tbaa !21
  %t128 = load ptr, ptr %l55, !tbaa !29
  %t129 = getelementptr %"compiler/emit:Emitter", ptr %t128, i32 0, i32 45
  store i1 %t127, ptr %t129, !tbaa !21
  %t130 = load ptr, ptr %l7, !tbaa !29
  %t131 = load i64, ptr @G_2ecompiler_2fbuild_2eThinFrom, !tbaa !24
  %t134 = getelementptr %"compiler/emit:Emitter", ptr %t130, i32 0, i32 38
  store i64 %t131, ptr %t134, !tbaa !24
  %t135 = load ptr, ptr %l7, !tbaa !29
  store ptr %t135, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2folang_2eendsWithOlang(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l4 = alloca i1
  %l6 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp sgt i64 %t3, 6
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t9 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %s0, { i64, ptr } %t7, { i64, ptr } { i64 6, ptr @.d120 })
  store i1 %t9, ptr %l6
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb4
bb3:
  %t10 = load i1, ptr %l6, !tbaa !21
  store i1 %t10, ptr %l4, !tbaa !21
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t11 = load i1, ptr %l4, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2folang_2eexplain(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %lp4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca { i64, [3 x i64] }
  %l16 = alloca %"compiler/msgs:Msg"
  %l17 = alloca i64
  %l19 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i32
  %l25 = alloca ptr
  %l26 = alloca { i64, [3 x i64] }
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca i64
  %l45 = alloca %"compiler/msgs:Msg"
  %l46 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  %t28 = alloca { i64, [3 x i64] }, align 8
  %t53 = alloca { i64, [3 x i64] }, align 8
  store { i64, ptr } %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i64, ptr } @compiler_2fdiag_2eSpecPath(ptr %s0)
  store { i64, ptr } %t1, ptr %l5
  br label %bb1
bb1:
  %t2 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t2, ptr %l2, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s0, { i64, ptr } %t3)
  %t6 = extractvalue { i32, { i64, ptr } } %t5, 1
  %t7 = extractvalue { i32, { i64, ptr } } %t5, 0
  store i32 %t7, ptr %l9
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb3, label %ok.9
ok.9:
  store { i64, ptr } %t6, ptr %l8
  br label %bb2
bb2:
  %t10 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t10, ptr %l6, !tbaa !27
  br label %bb9
bb3:
  %t11 = load i32, ptr %l9, !tbaa !23
  %t12 = ashr i32 %t11, 16
  %t14 = icmp eq i32 %t12, 1
  br i1 %t14, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load i32, ptr %l9, !tbaa !23
  %t17 = lshr i32 %t16, 16
  %t18 = and i32 %t16, 65535
  %t19 = icmp eq i32 %t17, 1
  %t20 = select i1 %t19, i32 0, i32 0
  %t21 = icmp eq i32 %t16, 0
  %t22 = shl i32 %t20, 16
  %t23 = or i32 %t22, %t18
  %t24 = select i1 %t21, i32 0, i32 %t23
  call void @__olang_scope_close(ptr %s0)
  %t26 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t24, 0
  store { i32, { i64, ptr } } %t26, ptr %rv
  br label %ret
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t27 = load ptr, ptr %l1, !tbaa !29
  store ptr %t27, ptr %l13, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t28
  %t29 = getelementptr { i64, [3 x i64] }, ptr %t28, i32 0, i32 0
  store i64 0, ptr %t29
  %t30 = load { i64, [3 x i64] }, ptr %t28
  store { i64, [3 x i64] } %t30, ptr %l14
  %t31 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t33 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoSpec(ptr %s0, ptr %s1, { i64, ptr } %t31)
  store %"compiler/msgs:Msg" %t33, ptr %l16
  br label %bb7
bb7:
  %t34 = load ptr, ptr %l13, !tbaa !29
  %t35 = load { i64, [3 x i64] }, ptr %l14
  %t36 = load %"compiler/msgs:Msg", ptr %l16
  %t37 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v1, ptr %s1, ptr %t34, { i64, [3 x i64] } %t35, %"compiler/msgs:Msg" %t36)
  store i64 %t37, ptr %l17
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t39 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t39, ptr %rv
  br label %ret
bb9:
  %t40 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t43 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t46 = call { i32, { i64, ptr } } @compiler_2fdiag_2eExplain(ptr %s0, ptr %v0, ptr %v2, { i64, ptr } %t40, { i64, ptr } %t43)
  %t47 = extractvalue { i32, { i64, ptr } } %t46, 1
  %t48 = extractvalue { i32, { i64, ptr } } %t46, 0
  store i32 %t48, ptr %l24
  %t49 = icmp ne i32 %t48, 0
  br i1 %t49, label %bb11, label %ok.50
ok.50:
  store { i64, ptr } %t47, ptr %l23
  br label %bb10
bb10:
  %t51 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t51, ptr %l19, !tbaa !27
  br label %bb28
bb11:
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t52 = load ptr, ptr %l1, !tbaa !29
  store ptr %t52, ptr %l25, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t53
  %t54 = getelementptr { i64, [3 x i64] }, ptr %t53, i32 0, i32 0
  store i64 0, ptr %t54
  %t55 = load { i64, [3 x i64] }, ptr %t53
  store { i64, [3 x i64] } %t55, ptr %l26
  %t56 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t56, ptr %l27, !tbaa !27
  %t57 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t57, 0
  store i64 %t58, ptr %l28, !tbaa !24
  %t59 = icmp sge i64 0, 0
  br i1 %t59, label %bb13, label %bb14
bb13:
  %t61 = icmp sle i64 0, 1
  br i1 %t61, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @.c121)
  unreachable
bb15:
  %t63 = load i64, ptr %l28, !tbaa !24
  %t64 = icmp sle i64 1, %t63
  br i1 %t64, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @.c121)
  unreachable
bb17:
  %t66 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !27
  %t68 = getelementptr i8, ptr %t67, i64 0
  %t69 = sub i64 1, 0
  %t70 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t68, 1
  %t73 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eToUpper(ptr %v0, ptr %s2, { i64, ptr } %t71)
  store { i64, ptr } %t73, ptr %l33
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @.c121)
  unreachable
bb19:
  %t74 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t74, ptr %l34, !tbaa !27
  %t75 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t75, 0
  store i64 %t78, ptr %l37, !tbaa !24
  %t79 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t79, 0
  store i64 %t80, ptr %l38, !tbaa !24
  %t81 = icmp sge i64 1, 0
  br i1 %t81, label %bb20, label %bb21
bb20:
  %t83 = load i64, ptr %l37, !tbaa !24
  %t84 = icmp sle i64 1, %t83
  br i1 %t84, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @.c121)
  unreachable
bb22:
  %t86 = load i64, ptr %l37, !tbaa !24
  %t87 = load i64, ptr %l38, !tbaa !24
  %t88 = icmp sle i64 %t86, %t87
  br i1 %t88, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @.c121)
  unreachable
bb24:
  %t90 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = load i64, ptr %l37, !tbaa !24
  %t93 = getelementptr i8, ptr %t91, i64 1
  %t94 = sub i64 %t92, 1
  %t95 = insertvalue { i64, ptr } undef, i64 %t94, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %t93, 1
  %t97 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t97, 1
  %t99 = extractvalue { i64, ptr } %t97, 0
  %t101 = extractvalue { i64, ptr } %t96, 1
  %t102 = extractvalue { i64, ptr } %t96, 0
  %t103 = add i64 %t99, %t102
  %t104 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t103)
  call void @olang_textcopy(ptr %t104, ptr %t98, i64 %t99)
  %t105 = getelementptr i8, ptr %t104, i64 %t99
  call void @olang_textcopy(ptr %t105, ptr %t101, i64 %t102)
  %t106 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t104, 1
  %t109 = extractvalue { i64, ptr } %t107, 0
  %t110 = extractvalue { i64, ptr } %t107, 1
  %t111 = mul i64 %t109, 1
  %t112 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t111)
  call void @llvm.memcpy.p0.p0.i64(ptr %t112, ptr %t110, i64 %t111, i1 false)
  %t113 = insertvalue { i64, ptr } undef, i64 %t109, 0
  %t114 = insertvalue { i64, ptr } %t113, ptr %t112, 1
  %t116 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoRule(ptr %s2, ptr %s2, { i64, ptr } %t114)
  store %"compiler/msgs:Msg" %t116, ptr %l45
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @.c121)
  unreachable
bb26:
  %t117 = load ptr, ptr %l25, !tbaa !29
  %t118 = load { i64, [3 x i64] }, ptr %l26
  %t119 = load %"compiler/msgs:Msg", ptr %l45
  %t120 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v1, ptr %s2, ptr %t117, { i64, [3 x i64] } %t118, %"compiler/msgs:Msg" %t119)
  store i64 %t120, ptr %l46
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t122 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t122, ptr %rv
  br label %ret
bb28:
  %t123 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t123, ptr %lp4
  %t124 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t125 = load ptr, ptr %lp4
  store { i64, ptr } %t124, ptr %t125, !tbaa !27
  %t126 = load ptr, ptr %lp4
  %t127 = load { i64, ptr }, ptr %t126, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t129 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t127, 1
  store { i32, { i64, ptr } } %t129, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i32 @compiler_2folang_2eformat(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l9 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/olang:CommandLine", ptr %t1, i32 0, i32 8
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 2, ptr @.d122 }, ptr %l3, !tbaa !27
  br label %bb3
bb2:
  store { i64, ptr } { i64 2, ptr @.d123 }, ptr %l3, !tbaa !27
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/olang:CommandLine", ptr %t6, i32 0, i32 1
  %t10 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hd4bdf3befe2f7a35847f168802c5df68(ptr %v0, ptr %v0, ptr %t8)
  store { i64, ptr } %t10, ptr %l6
  br label %bb4
bb4:
  %t11 = call { i64, ptr } @compiler_2fload_2eStdDir(ptr %s0)
  store { i64, ptr } %t11, ptr %l7
  br label %bb5
bb5:
  %t12 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 0
  %t14 = extractvalue { i64, ptr } %t12, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t19 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t20 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t22 = call i32 @compiler_2ffmt_2eFiles(ptr %s0, ptr %v0, ptr %s0, { i64, ptr } %t19, { i64, ptr } %t20, { i64, ptr } %t18)
  store i32 %t22, ptr %l9
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load i32, ptr %l9, !tbaa !23
  store i32 %t23, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2folang_2ehelp(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i1
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca %"std/prelude/text:StringBuilder"
  %l23 = alloca ptr
  %l24 = alloca { i64, ptr }
  %l34 = alloca i64
  %l37 = alloca i64
  %l55 = alloca ptr
  %l58 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l69 = alloca i64
  %l70 = alloca { i64, ptr }
  %l73 = alloca i1
  %l74 = alloca i64
  %l78 = alloca i64
  %l81 = alloca ptr
  %l84 = alloca %"compiler/msgs:Msg"
  %l85 = alloca i32
  %l99 = alloca i64
  %l102 = alloca i64
  %l122 = alloca i64
  %l130 = alloca { i64, ptr }
  %l133 = alloca i1
  %l135 = alloca { i64, ptr }
  %l139 = alloca ptr
  %l141 = alloca { i64, ptr }
  %l149 = alloca { i64, ptr }
  %l150 = alloca { i64, ptr }
  %l151 = alloca i64
  %l152 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l18
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l18
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/olang:CommandLine", ptr %t3, i32 0, i32 3
  %t6 = load i1, ptr %t5, !tbaa !21
  %t8 = xor i1 %t6, true
  br i1 %t8, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s1, ptr %l2, { i64, ptr } { i64 96, ptr @.d124 })
  br label %bb4
bb3:
  br label %bb23
bb4:
  store ptr %l2, ptr %l23, !tbaa !29
  %t11 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadEnd(ptr %s1, ptr %s1, { i64, ptr } { i64 10, ptr @.d125 }, i64 11, i8 32)
  store { i64, ptr } %t11, ptr %l24
  br label %bb5
bb5:
  %t12 = load i64, ptr @G_2ecompiler_2folang_2eRun, !tbaa !24
  %t14 = getelementptr [8 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eModeWhat, i64 0, i64 %t12
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !37
  %t16 = extractvalue { i64, ptr } { i64 2, ptr @.d126 }, 1
  %t17 = extractvalue { i64, ptr } { i64 2, ptr @.d126 }, 0
  %t18 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t18, 1
  %t20 = extractvalue { i64, ptr } %t18, 0
  %t21 = add i64 %t17, %t20
  %t22 = extractvalue { i64, ptr } { i64 1, ptr @.d127 }, 1
  %t23 = extractvalue { i64, ptr } { i64 1, ptr @.d127 }, 0
  %t24 = add i64 %t21, %t23
  %t26 = extractvalue { i64, ptr } %t15, 1
  %t27 = extractvalue { i64, ptr } %t15, 0
  %t28 = add i64 %t24, %t27
  %t29 = extractvalue { i64, ptr } { i64 1, ptr @.d128 }, 1
  %t30 = extractvalue { i64, ptr } { i64 1, ptr @.d128 }, 0
  %t31 = add i64 %t28, %t30
  %t32 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t31)
  call void @olang_textcopy(ptr %t32, ptr %t16, i64 %t17)
  %t33 = getelementptr i8, ptr %t32, i64 %t17
  call void @olang_textcopy(ptr %t33, ptr %t19, i64 %t20)
  %t34 = getelementptr i8, ptr %t33, i64 %t20
  call void @olang_textcopy(ptr %t34, ptr %t22, i64 %t23)
  %t35 = getelementptr i8, ptr %t34, i64 %t23
  call void @olang_textcopy(ptr %t35, ptr %t26, i64 %t27)
  %t36 = getelementptr i8, ptr %t35, i64 %t27
  call void @olang_textcopy(ptr %t36, ptr %t29, i64 %t30)
  %t37 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t32, 1
  %t40 = extractvalue { i64, ptr } %t38, 0
  %t41 = extractvalue { i64, ptr } %t38, 1
  %t42 = mul i64 %t40, 1
  %t43 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t42)
  call void @llvm.memcpy.p0.p0.i64(ptr %t43, ptr %t41, i64 %t42, i1 false)
  %t44 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  %t46 = load ptr, ptr %l23, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s1, ptr %t46, { i64, ptr } %t45)
  br label %bb6
bb6:
  store i64 1, ptr %l3, !tbaa !24
  %t48 = load [8 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eModeWords
  store i64 8, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t51 = load i64, ptr %l4, !tbaa !24
  %t52 = load i64, ptr %l3, !tbaa !24
  %t55 = icmp sgt i64 %t51, %t52
  br i1 %t55, label %bb7, label %bb8
bb7:
  %t57 = load i64, ptr %l5, !tbaa !24
  %t59 = icmp sgt i64 %t57, 0
  br i1 %t59, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb12
bb9:
  %t61 = load i64, ptr %l4, !tbaa !24
  %t62 = load i64, ptr %l3, !tbaa !24
  %t65 = sub i64 %t61, %t62
  %t66 = load i64, ptr %l5, !tbaa !24
  %t69 = add i64 %t65, %t66
  %t71 = sub i64 %t69, 1
  %t72 = load i64, ptr %l5, !tbaa !24
  %t75 = sdiv i64 %t71, %t72
  store i64 %t75, ptr %l37, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb11
bb11:
  %t77 = load i64, ptr %l37, !tbaa !24
  store i64 %t77, ptr %l34, !tbaa !24
  br label %bb12
bb12:
  %t78 = load i64, ptr %l34, !tbaa !24
  store i64 %t78, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s4
  %t79 = load i64, ptr %l7, !tbaa !24
  %t80 = load i64, ptr %l6, !tbaa !24
  %t83 = icmp slt i64 %t79, %t80
  %t85 = xor i1 %t83, true
  br i1 %t85, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s4)
  br label %bb20
bb15:
  br label %bb16
bb16:
  %t87 = load i64, ptr %l3, !tbaa !24
  %t88 = load i64, ptr %l7, !tbaa !24
  %t89 = load i64, ptr %l5, !tbaa !24
  %t92 = mul i64 %t88, %t89
  %t95 = add i64 %t87, %t92
  store i64 %t95, ptr %l8, !tbaa !24
  store ptr %l2, ptr %l55, !tbaa !29
  %t97 = load i64, ptr %l8, !tbaa !24
  %t99 = getelementptr [8 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eModeWords, i64 0, i64 %t97
  %t100 = load { i64, ptr }, ptr %t99, !tbaa !37
  %t101 = load ptr, ptr @__olang_prog_scope
  %t103 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadEnd(ptr %t101, ptr %s4, { i64, ptr } %t100, i64 11, i8 32)
  store { i64, ptr } %t103, ptr %l58
  br label %bb17
bb17:
  %t104 = load i64, ptr %l8, !tbaa !24
  %t106 = getelementptr [8 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eModeWhat, i64 0, i64 %t104
  %t107 = load { i64, ptr }, ptr %t106, !tbaa !37
  %t108 = extractvalue { i64, ptr } { i64 2, ptr @.d129 }, 1
  %t109 = extractvalue { i64, ptr } { i64 2, ptr @.d129 }, 0
  %t110 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t111 = extractvalue { i64, ptr } %t110, 1
  %t112 = extractvalue { i64, ptr } %t110, 0
  %t113 = add i64 %t109, %t112
  %t114 = extractvalue { i64, ptr } { i64 1, ptr @.d130 }, 1
  %t115 = extractvalue { i64, ptr } { i64 1, ptr @.d130 }, 0
  %t116 = add i64 %t113, %t115
  %t118 = extractvalue { i64, ptr } %t107, 1
  %t119 = extractvalue { i64, ptr } %t107, 0
  %t120 = add i64 %t116, %t119
  %t121 = extractvalue { i64, ptr } { i64 1, ptr @.d131 }, 1
  %t122 = extractvalue { i64, ptr } { i64 1, ptr @.d131 }, 0
  %t123 = add i64 %t120, %t122
  %t124 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t123)
  call void @olang_textcopy(ptr %t124, ptr %t108, i64 %t109)
  %t125 = getelementptr i8, ptr %t124, i64 %t109
  call void @olang_textcopy(ptr %t125, ptr %t111, i64 %t112)
  %t126 = getelementptr i8, ptr %t125, i64 %t112
  call void @olang_textcopy(ptr %t126, ptr %t114, i64 %t115)
  %t127 = getelementptr i8, ptr %t126, i64 %t115
  call void @olang_textcopy(ptr %t127, ptr %t118, i64 %t119)
  %t128 = getelementptr i8, ptr %t127, i64 %t119
  call void @olang_textcopy(ptr %t128, ptr %t121, i64 %t122)
  %t129 = insertvalue { i64, ptr } undef, i64 %t123, 0
  %t130 = insertvalue { i64, ptr } %t129, ptr %t124, 1
  %t132 = extractvalue { i64, ptr } %t130, 0
  %t133 = extractvalue { i64, ptr } %t130, 1
  %t134 = mul i64 %t132, 1
  %t135 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t134)
  call void @llvm.memcpy.p0.p0.i64(ptr %t135, ptr %t133, i64 %t134, i1 false)
  %t136 = insertvalue { i64, ptr } undef, i64 %t132, 0
  %t137 = insertvalue { i64, ptr } %t136, ptr %t135, 1
  %t138 = load ptr, ptr %l55, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %t138, { i64, ptr } %t137)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s4)
  br label %bb19
bb19:
  %t140 = load i64, ptr %l7, !tbaa !24
  %t142 = add i64 %t140, 1
  store i64 %t142, ptr %l7, !tbaa !24
  br label %bb13
bb20:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s1, ptr %l2, { i64, ptr } { i64 85, ptr @.d132 })
  br label %bb21
bb21:
  %t146 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l2)
  store { i64, ptr } %t146, ptr %l67
  br label %bb22
bb22:
  %t147 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t147, ptr %l68, !tbaa !27
  %t148 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t149 = extractvalue { i64, ptr } %t148, 0
  store i64 %t149, ptr %l69, !tbaa !24
  %t150 = load i64, ptr %l69, !tbaa !24
  %t151 = mul i64 %t150, 1
  %t152 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t151)
  %t153 = insertvalue { i64, ptr } undef, i64 %t150, 0
  %t154 = insertvalue { i64, ptr } %t153, ptr %t152, 1
  store { i64, ptr } %t154, ptr %l70, !tbaa !27
  %t155 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t156 = load ptr, ptr %t155, !tbaa !27
  %t157 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !27
  %t159 = load i64, ptr %l69, !tbaa !24
  %t160 = mul i64 %t159, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t156, ptr %t158, i64 %t160, i1 false)
  %t161 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t161, ptr %l68, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t162 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t163 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t162, 1
  store { i32, { i64, ptr } } %t163, ptr %rv
  br label %ret
bb23:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/olang:CommandLine", ptr %t164, i32 0, i32 2
  %t167 = load { i64, ptr }, ptr %t166, !tbaa !27
  %t169 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t167, { i64, ptr } { i64 3, ptr @.d133 })
  store i1 %t169, ptr %l73
  br label %bb24
bb24:
  %t170 = load i1, ptr %l73, !tbaa !21
  br i1 %t170, label %bb25, label %bb26
bb25:
  %t171 = load i64, ptr @G_2ecompiler_2folang_2eRun, !tbaa !24
  store i64 %t171, ptr %l74, !tbaa !24
  br label %bb28
bb26:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr %"compiler/olang:CommandLine", ptr %t173, i32 0, i32 2
  %t176 = load { i64, ptr }, ptr %t175, !tbaa !27
  %t178 = call i64 @compiler_2folang_2emodeNumber(ptr %v0, { i64, ptr } %t176)
  store i64 %t178, ptr %l78
  br label %bb27
bb27:
  %t179 = load i64, ptr %l78, !tbaa !24
  store i64 %t179, ptr %l74, !tbaa !24
  br label %bb28
bb28:
  %t180 = load i64, ptr %l74, !tbaa !24
  store i64 %t180, ptr %l9, !tbaa !24
  %t181 = load i64, ptr %l9, !tbaa !24
  %t183 = icmp slt i64 %t181, 0
  br i1 %t183, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s7
  store ptr %a1, ptr %l81, !tbaa !29
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t188 = getelementptr %"compiler/olang:CommandLine", ptr %t186, i32 0, i32 2
  %t189 = load { i64, ptr }, ptr %t188, !tbaa !27
  %t191 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotAMode(ptr %v0, ptr %s7, { i64, ptr } %t189)
  store %"compiler/msgs:Msg" %t191, ptr %l84
  br label %bb31
bb30:
  br label %bb35
bb31:
  %t192 = load ptr, ptr %l81, !tbaa !29
  %t193 = load %"compiler/msgs:Msg", ptr %l84
  %t194 = call i32 @compiler_2folang_2eusage(ptr %v1, ptr %s7, ptr %t192, %"compiler/msgs:Msg" %t193)
  store i32 %t194, ptr %l85
  %t195 = icmp ne i32 %t194, 0
  br i1 %t195, label %bb33, label %ok.196
ok.196:
  br label %bb32
bb32:
  br label %bb34
bb33:
  %t197 = load i32, ptr %l85, !tbaa !23
  %t198 = lshr i32 %t197, 16
  %t199 = and i32 %t197, 65535
  %t200 = icmp eq i32 %t198, 1
  %t201 = select i1 %t200, i32 1, i32 0
  %t202 = icmp eq i32 %t197, 0
  %t203 = shl i32 %t201, 16
  %t204 = or i32 %t203, %t199
  %t205 = select i1 %t202, i32 0, i32 %t204
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  %t207 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t205, 0
  store { i32, { i64, ptr } } %t207, ptr %rv
  br label %ret
bb34:
  call void @__olang_scope_close(ptr %s7)
  br label %bb35
bb35:
  %t208 = load i64, ptr %l9, !tbaa !24
  %t210 = getelementptr [8 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eModeUsage, i64 0, i64 %t208
  %t211 = load { i64, ptr }, ptr %t210, !tbaa !37
  %t212 = load i64, ptr %l9, !tbaa !24
  %t214 = getelementptr [8 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eModeWhat, i64 0, i64 %t212
  %t215 = load { i64, ptr }, ptr %t214, !tbaa !37
  %t216 = extractvalue { i64, ptr } { i64 7, ptr @.d134 }, 1
  %t217 = extractvalue { i64, ptr } { i64 7, ptr @.d134 }, 0
  %t219 = extractvalue { i64, ptr } %t211, 1
  %t220 = extractvalue { i64, ptr } %t211, 0
  %t221 = add i64 %t217, %t220
  %t222 = extractvalue { i64, ptr } { i64 1, ptr @.d135 }, 1
  %t223 = extractvalue { i64, ptr } { i64 1, ptr @.d135 }, 0
  %t224 = add i64 %t221, %t223
  %t226 = extractvalue { i64, ptr } %t215, 1
  %t227 = extractvalue { i64, ptr } %t215, 0
  %t228 = add i64 %t224, %t227
  %t229 = extractvalue { i64, ptr } { i64 1, ptr @.d136 }, 1
  %t230 = extractvalue { i64, ptr } { i64 1, ptr @.d136 }, 0
  %t231 = add i64 %t228, %t230
  %t232 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t231)
  call void @olang_textcopy(ptr %t232, ptr %t216, i64 %t217)
  %t233 = getelementptr i8, ptr %t232, i64 %t217
  call void @olang_textcopy(ptr %t233, ptr %t219, i64 %t220)
  %t234 = getelementptr i8, ptr %t233, i64 %t220
  call void @olang_textcopy(ptr %t234, ptr %t222, i64 %t223)
  %t235 = getelementptr i8, ptr %t234, i64 %t223
  call void @olang_textcopy(ptr %t235, ptr %t226, i64 %t227)
  %t236 = getelementptr i8, ptr %t235, i64 %t227
  call void @olang_textcopy(ptr %t236, ptr %t229, i64 %t230)
  %t237 = insertvalue { i64, ptr } undef, i64 %t231, 0
  %t238 = insertvalue { i64, ptr } %t237, ptr %t232, 1
  %t240 = extractvalue { i64, ptr } %t238, 0
  %t241 = extractvalue { i64, ptr } %t238, 1
  %t242 = mul i64 %t240, 1
  %t243 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t242)
  call void @llvm.memcpy.p0.p0.i64(ptr %t243, ptr %t241, i64 %t242, i1 false)
  %t244 = insertvalue { i64, ptr } undef, i64 %t240, 0
  %t245 = insertvalue { i64, ptr } %t244, ptr %t243, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } %t245)
  br label %bb36
bb36:
  store i1 false, ptr %l10, !tbaa !21
  store i64 0, ptr %l11, !tbaa !24
  %t248 = load [8 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eOptWords
  store i64 8, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t251 = load i64, ptr %l12, !tbaa !24
  %t252 = load i64, ptr %l11, !tbaa !24
  %t255 = icmp sgt i64 %t251, %t252
  br i1 %t255, label %bb37, label %bb38
bb37:
  %t257 = load i64, ptr %l13, !tbaa !24
  %t259 = icmp sgt i64 %t257, 0
  br i1 %t259, label %bb39, label %bb40
bb38:
  store i64 0, ptr %l99, !tbaa !24
  br label %bb42
bb39:
  %t261 = load i64, ptr %l12, !tbaa !24
  %t262 = load i64, ptr %l11, !tbaa !24
  %t265 = sub i64 %t261, %t262
  %t266 = load i64, ptr %l13, !tbaa !24
  %t269 = add i64 %t265, %t266
  %t271 = sub i64 %t269, 1
  %t272 = load i64, ptr %l13, !tbaa !24
  %t275 = sdiv i64 %t271, %t272
  store i64 %t275, ptr %l102, !tbaa !24
  br label %bb41
bb40:
  store i64 0, ptr %l102, !tbaa !24
  br label %bb41
bb41:
  %t277 = load i64, ptr %l102, !tbaa !24
  store i64 %t277, ptr %l99, !tbaa !24
  br label %bb42
bb42:
  %t278 = load i64, ptr %l99, !tbaa !24
  store i64 %t278, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb43
bb43:
  store %olang.scope zeroinitializer, ptr %s10
  %t279 = load i64, ptr %l15, !tbaa !24
  %t280 = load i64, ptr %l14, !tbaa !24
  %t283 = icmp slt i64 %t279, %t280
  %t285 = xor i1 %t283, true
  br i1 %t285, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s10)
  br label %bb61
bb45:
  br label %bb46
bb46:
  %t287 = load i64, ptr %l11, !tbaa !24
  %t288 = load i64, ptr %l15, !tbaa !24
  %t289 = load i64, ptr %l13, !tbaa !24
  %t292 = mul i64 %t288, %t289
  %t295 = add i64 %t287, %t292
  store i64 %t295, ptr %l16, !tbaa !24
  %t297 = load i64, ptr %l16, !tbaa !24
  %t299 = getelementptr [8 x i64], ptr @G_2ecompiler_2folang_2eOptModes, i64 0, i64 %t297
  %t300 = load i64, ptr %t299, !tbaa !34
  %t301 = load i64, ptr %l9, !tbaa !24
  store i64 %t301, ptr %l122, !tbaa !24
  %t303 = load i64, ptr %l122, !tbaa !24
  %t304 = load i64, ptr %l122, !tbaa !24
  %t305 = ashr i64 %t300, %t304
  %t307 = and i64 %t305, 1
  %t309 = icmp eq i64 %t307, 0
  br i1 %t309, label %bb47, label %bb48
bb47:
  call void @__olang_scope_close(ptr %s10)
  br label %bb60
bb48:
  br label %bb49
bb49:
  %t311 = load i1, ptr %l10, !tbaa !21
  %t313 = xor i1 %t311, true
  br i1 %t313, label %bb50, label %bb51
bb50:
  store %olang.scope zeroinitializer, ptr %s12
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s12, ptr %l2, { i64, ptr } { i64 10, ptr @.d137 })
  br label %bb52
bb51:
  br label %bb53
bb52:
  call void @__olang_scope_close(ptr %s12)
  br label %bb53
bb53:
  store i1 true, ptr %l10, !tbaa !21
  %t316 = load i64, ptr %l16, !tbaa !24
  %t318 = getelementptr [8 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eOptWords, i64 0, i64 %t316
  %t319 = load { i64, ptr }, ptr %t318, !tbaa !37
  store { i64, ptr } %t319, ptr %l130, !tbaa !27
  %t320 = load i64, ptr %l16, !tbaa !24
  %t322 = getelementptr [8 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eOptValues, i64 0, i64 %t320
  %t323 = load { i64, ptr }, ptr %t322, !tbaa !37
  %t324 = load ptr, ptr @__olang_prog_scope
  %t326 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t324, ptr %s10, { i64, ptr } %t323, { i64, ptr } { i64 0, ptr @.d138 })
  store i1 %t326, ptr %l133
  br label %bb54
bb54:
  %t327 = load i1, ptr %l133, !tbaa !21
  %t328 = xor i1 %t327, true
  br i1 %t328, label %bb55, label %bb56
bb55:
  store { i64, ptr } { i64 1, ptr @.d139 }, ptr %l135, !tbaa !27
  br label %bb57
bb56:
  store { i64, ptr } { i64 0, ptr @.d140 }, ptr %l135, !tbaa !27
  br label %bb57
bb57:
  %t330 = load i64, ptr %l16, !tbaa !24
  %t332 = getelementptr [8 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eOptValues, i64 0, i64 %t330
  %t333 = load { i64, ptr }, ptr %t332, !tbaa !37
  %t334 = load { i64, ptr }, ptr %l130, !tbaa !27
  %t335 = extractvalue { i64, ptr } %t334, 1
  %t336 = extractvalue { i64, ptr } %t334, 0
  %t337 = load { i64, ptr }, ptr %l135, !tbaa !27
  %t338 = extractvalue { i64, ptr } %t337, 1
  %t339 = extractvalue { i64, ptr } %t337, 0
  %t340 = add i64 %t336, %t339
  %t342 = extractvalue { i64, ptr } %t333, 1
  %t343 = extractvalue { i64, ptr } %t333, 0
  %t344 = add i64 %t340, %t343
  %t345 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t344)
  call void @olang_textcopy(ptr %t345, ptr %t335, i64 %t336)
  %t346 = getelementptr i8, ptr %t345, i64 %t336
  call void @olang_textcopy(ptr %t346, ptr %t338, i64 %t339)
  %t347 = getelementptr i8, ptr %t346, i64 %t339
  call void @olang_textcopy(ptr %t347, ptr %t342, i64 %t343)
  %t348 = insertvalue { i64, ptr } undef, i64 %t344, 0
  %t349 = insertvalue { i64, ptr } %t348, ptr %t345, 1
  store ptr %l2, ptr %l139, !tbaa !29
  %t353 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadEnd(ptr %s10, ptr %s10, { i64, ptr } %t349, i64 18, i8 32)
  store { i64, ptr } %t353, ptr %l141
  br label %bb58
bb58:
  %t354 = load i64, ptr %l16, !tbaa !24
  %t356 = getelementptr [8 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eOptWhat, i64 0, i64 %t354
  %t357 = load { i64, ptr }, ptr %t356, !tbaa !37
  %t358 = extractvalue { i64, ptr } { i64 2, ptr @.d141 }, 1
  %t359 = extractvalue { i64, ptr } { i64 2, ptr @.d141 }, 0
  %t360 = load { i64, ptr }, ptr %l141, !tbaa !27
  %t361 = extractvalue { i64, ptr } %t360, 1
  %t362 = extractvalue { i64, ptr } %t360, 0
  %t363 = add i64 %t359, %t362
  %t364 = extractvalue { i64, ptr } { i64 1, ptr @.d142 }, 1
  %t365 = extractvalue { i64, ptr } { i64 1, ptr @.d142 }, 0
  %t366 = add i64 %t363, %t365
  %t368 = extractvalue { i64, ptr } %t357, 1
  %t369 = extractvalue { i64, ptr } %t357, 0
  %t370 = add i64 %t366, %t369
  %t371 = extractvalue { i64, ptr } { i64 1, ptr @.d143 }, 1
  %t372 = extractvalue { i64, ptr } { i64 1, ptr @.d143 }, 0
  %t373 = add i64 %t370, %t372
  %t374 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t373)
  call void @olang_textcopy(ptr %t374, ptr %t358, i64 %t359)
  %t375 = getelementptr i8, ptr %t374, i64 %t359
  call void @olang_textcopy(ptr %t375, ptr %t361, i64 %t362)
  %t376 = getelementptr i8, ptr %t375, i64 %t362
  call void @olang_textcopy(ptr %t376, ptr %t364, i64 %t365)
  %t377 = getelementptr i8, ptr %t376, i64 %t365
  call void @olang_textcopy(ptr %t377, ptr %t368, i64 %t369)
  %t378 = getelementptr i8, ptr %t377, i64 %t369
  call void @olang_textcopy(ptr %t378, ptr %t371, i64 %t372)
  %t379 = insertvalue { i64, ptr } undef, i64 %t373, 0
  %t380 = insertvalue { i64, ptr } %t379, ptr %t374, 1
  %t382 = extractvalue { i64, ptr } %t380, 0
  %t383 = extractvalue { i64, ptr } %t380, 1
  %t384 = mul i64 %t382, 1
  %t385 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t384)
  call void @llvm.memcpy.p0.p0.i64(ptr %t385, ptr %t383, i64 %t384, i1 false)
  %t386 = insertvalue { i64, ptr } undef, i64 %t382, 0
  %t387 = insertvalue { i64, ptr } %t386, ptr %t385, 1
  %t388 = load ptr, ptr %l139, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s10, ptr %t388, { i64, ptr } %t387)
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s10)
  br label %bb60
bb60:
  %t390 = load i64, ptr %l15, !tbaa !24
  %t392 = add i64 %t390, 1
  store i64 %t392, ptr %l15, !tbaa !24
  br label %bb43
bb61:
  %t395 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l2)
  store { i64, ptr } %t395, ptr %l149
  br label %bb62
bb62:
  %t396 = load { i64, ptr }, ptr %l149, !tbaa !27
  store { i64, ptr } %t396, ptr %l150, !tbaa !27
  %t397 = load { i64, ptr }, ptr %l150, !tbaa !27
  %t398 = extractvalue { i64, ptr } %t397, 0
  store i64 %t398, ptr %l151, !tbaa !24
  %t399 = load i64, ptr %l151, !tbaa !24
  %t400 = mul i64 %t399, 1
  %t401 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t400)
  %t402 = insertvalue { i64, ptr } undef, i64 %t399, 0
  %t403 = insertvalue { i64, ptr } %t402, ptr %t401, 1
  store { i64, ptr } %t403, ptr %l152, !tbaa !27
  %t404 = getelementptr { i64, ptr }, ptr %l152, i32 0, i32 1
  %t405 = load ptr, ptr %t404, !tbaa !27
  %t406 = getelementptr { i64, ptr }, ptr %l150, i32 0, i32 1
  %t407 = load ptr, ptr %t406, !tbaa !27
  %t408 = load i64, ptr %l151, !tbaa !24
  %t409 = mul i64 %t408, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t405, ptr %t407, i64 %t409, i1 false)
  %t410 = load { i64, ptr }, ptr %l152, !tbaa !27
  store { i64, ptr } %t410, ptr %l150, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t411 = load { i64, ptr }, ptr %l150, !tbaa !27
  %t412 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t411, 1
  store { i32, { i64, ptr } } %t412, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local void @compiler_2folang_2ekeep(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, { i64, ptr } %a2, ptr %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca %"compiler/emit:Reused"
  %l13 = alloca { i64, ptr }
  %l14 = alloca %"std/prelude/text:StringBuilder"
  %l15 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca i1
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l30 = alloca i64
  %l36 = alloca i32
  %l39 = alloca i32
  %l41 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l45 = alloca i32
  %l54 = alloca { i64, ptr }
  %l61 = alloca i1
  %l62 = alloca { i64, ptr }
  %l65 = alloca i1
  %l66 = alloca ptr
  %l70 = alloca ptr
  %l73 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l77 = alloca %"std/prelude/text:StringBuilder"
  %l78 = alloca ptr
  %l79 = alloca i64
  %l81 = alloca { i64, ptr }
  %l84 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l86 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l90 = alloca i32
  %l99 = alloca { i64, ptr }
  %l104 = alloca i1
  %l117 = alloca i64
  %l121 = alloca i64
  %l124 = alloca i64
  %l145 = alloca { i64, ptr }
  %l151 = alloca %"compiler/emit:Object"
  %l154 = alloca i1
  %l156 = alloca ptr
  %l161 = alloca { i64, ptr }
  %l164 = alloca { i64, ptr }
  %l172 = alloca { i64, ptr }
  %l174 = alloca { i64, ptr }
  %l176 = alloca i1
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s16 = alloca %olang.scope
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t3 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aReused_3e_2eLen_3ccompiler_2femit_3aReused_3e(ptr %v3, ptr %t1)
  store i64 %t3, ptr %l30
  br label %bb1
bb1:
  %t4 = load i64, ptr %l30, !tbaa !24
  %t5 = icmp eq i64 %t4, 0
  br i1 %t5, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t9 = getelementptr %"compiler/build:Config", ptr %t7, i32 0, i32 0
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 1
  %t13 = extractvalue { i64, ptr } %t10, 0
  %t14 = extractvalue { i64, ptr } { i64 4, ptr @.d144 }, 1
  %t15 = extractvalue { i64, ptr } { i64 4, ptr @.d144 }, 0
  %t16 = add i64 %t13, %t15
  %t17 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t16)
  call void @olang_textcopy(ptr %t17, ptr %t12, i64 %t13)
  %t18 = getelementptr i8, ptr %t17, i64 %t13
  call void @olang_textcopy(ptr %t18, ptr %t14, i64 %t15)
  %t19 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t17, 1
  %t22 = extractvalue { i64, ptr } %t20, 0
  %t23 = extractvalue { i64, ptr } %t20, 1
  %t24 = mul i64 %t22, 1
  %t25 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  %t29 = call i32 @std_2fos_2eMkDirAll(ptr %s0, { i64, ptr } %t27)
  store i32 %t29, ptr %l36
  %t30 = icmp ne i32 %t29, 0
  br i1 %t30, label %bb6, label %ok.31
ok.31:
  br label %bb5
bb5:
  br label %bb10
bb6:
  %t32 = load i32, ptr %l36, !tbaa !23
  %t33 = ashr i32 %t32, 16
  %t35 = icmp eq i32 %t33, 1
  br i1 %t35, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @.c145)
  unreachable
bb9:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb10:
  %t37 = call i32 @compiler_2fbuild_2ePid()
  store i32 %t37, ptr %l39
  br label %bb11
bb11:
  %t38 = load i32, ptr %l39, !tbaa !23
  store i32 %t38, ptr %l6, !tbaa !23
  %t39 = load ptr, ptr %l3, !tbaa !29
  store ptr %t39, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s5
  %t41 = load ptr, ptr %l7, !tbaa !29
  %t42 = load i64, ptr %l8, !tbaa !24
  %t45 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aReused_3e_2eRunFrom_3ccompiler_2femit_3aReused_3e(ptr %v3, ptr %t41, i64 %t42)
  %t46 = extractvalue { i32, { i64, ptr } } %t45, 1
  %t47 = extractvalue { i32, { i64, ptr } } %t45, 0
  store i32 %t47, ptr %l45
  %t48 = icmp ne i32 %t47, 0
  br i1 %t48, label %bb14, label %ok.49
ok.49:
  store { i64, ptr } %t46, ptr %l44
  br label %bb13
bb13:
  %t50 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t50, ptr %l41, !tbaa !27
  br label %bb18
bb14:
  %t51 = load i32, ptr %l45, !tbaa !23
  %t52 = ashr i32 %t51, 16
  %t54 = icmp eq i32 %t52, 1
  br i1 %t54, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @.c146)
  unreachable
bb17:
  call void @__olang_scope_close(ptr %s5)
  br label %bb89
bb18:
  %t56 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t56, ptr %l9, !tbaa !27
  %t57 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t57, 0
  store i64 %t59, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb19
bb19:
  store %olang.scope zeroinitializer, ptr %s6
  %t61 = load i64, ptr %l11, !tbaa !24
  %t62 = load i64, ptr %l10, !tbaa !24
  %t65 = icmp slt i64 %t61, %t62
  %t67 = xor i1 %t65, true
  br i1 %t67, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s6)
  br label %bb87
bb21:
  br label %bb22
bb22:
  %t69 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t69, ptr %l54, !tbaa !27
  %t70 = load i64, ptr %l11, !tbaa !24
  %t72 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr %"compiler/emit:Reused", ptr %t73, i64 %t70
  %t75 = load %"compiler/emit:Reused", ptr %t74
  store %"compiler/emit:Reused" %t75, ptr %l12
  %t77 = getelementptr %"compiler/emit:Reused", ptr %l12, i32 0, i32 0
  %t78 = load i64, ptr %t77, !tbaa !24
  %t79 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t79, 0
  %t84 = icmp sge i64 %t78, %t81
  br i1 %t84, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l61, !tbaa !21
  br label %bb26
bb24:
  %t86 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t86, ptr %l62, !tbaa !27
  %t87 = getelementptr %"compiler/emit:Reused", ptr %l12, i32 0, i32 0
  %t88 = load i64, ptr %t87, !tbaa !24
  %t90 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr { i64, ptr }, ptr %t91, i64 %t88
  %t93 = load { i64, ptr }, ptr %t92, !tbaa !37
  %t95 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s6, { i64, ptr } %t93, { i64, ptr } { i64 0, ptr @.d147 })
  store i1 %t95, ptr %l65
  br label %bb25
bb25:
  %t96 = load i1, ptr %l65, !tbaa !21
  store i1 %t96, ptr %l61, !tbaa !21
  br label %bb26
bb26:
  %t97 = load i1, ptr %l61, !tbaa !21
  br i1 %t97, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s6)
  br label %bb86
bb28:
  br label %bb29
bb29:
  %t98 = load ptr, ptr %l1, !tbaa !29
  store ptr %t98, ptr %l66, !tbaa !29
  %t101 = getelementptr %"compiler/load:Loader", ptr %a0, i32 0, i32 5
  %t102 = getelementptr %"compiler/emit:Reused", ptr %l12, i32 0, i32 0
  %t103 = load i64, ptr %t102, !tbaa !24
  %t106 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t101, i64 %t103)
  store ptr %t106, ptr %l70
  br label %bb30
bb30:
  %t107 = load ptr, ptr %l70, !tbaa !29
  %t109 = getelementptr %"compiler/load:Module", ptr %t107, i32 0, i32 2
  %t110 = load { i64, ptr }, ptr %t109, !tbaa !27
  %t111 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t111, ptr %l73, !tbaa !27
  %t112 = getelementptr %"compiler/emit:Reused", ptr %l12, i32 0, i32 0
  %t113 = load i64, ptr %t112, !tbaa !24
  %t115 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = getelementptr { i64, ptr }, ptr %t116, i64 %t113
  %t118 = load { i64, ptr }, ptr %t117, !tbaa !37
  %t119 = load ptr, ptr %l66, !tbaa !29
  %t122 = call { i64, ptr } @compiler_2folang_2erecordPath(ptr %v1, ptr %v0, ptr %v2, ptr %s6, ptr %t119, { i64, ptr } %t110, { i64, ptr } %t118)
  store { i64, ptr } %t122, ptr %l76
  br label %bb31
bb31:
  %t123 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t123, ptr %l13, !tbaa !27
  %t124 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s6)
  store %"std/prelude/text:StringBuilder" %t124, ptr %l77
  br label %bb32
bb32:
  %t125 = load %"std/prelude/text:StringBuilder", ptr %l77
  store %"std/prelude/text:StringBuilder" %t125, ptr %l14
  store ptr %l14, ptr %l78, !tbaa !29
  %t126 = getelementptr %"compiler/emit:Reused", ptr %l12, i32 0, i32 3
  %t127 = load i64, ptr %t126, !tbaa !24
  store i64 %t127, ptr %l79, !tbaa !24
  %t128 = getelementptr %"compiler/emit:Reused", ptr %l12, i32 0, i32 4
  %t129 = load i1, ptr %t128, !tbaa !21
  br i1 %t129, label %bb33, label %bb34
bb33:
  store { i64, ptr } { i64 1, ptr @.d148 }, ptr %l81, !tbaa !27
  br label %bb35
bb34:
  store { i64, ptr } { i64 1, ptr @.d149 }, ptr %l81, !tbaa !27
  br label %bb35
bb35:
  %t131 = extractvalue { i64, ptr } { i64 25, ptr @.d150 }, 1
  %t132 = extractvalue { i64, ptr } { i64 25, ptr @.d150 }, 0
  %t133 = load i64, ptr %l79, !tbaa !24
  %t134 = call i64 @__olang_fmt_i64(ptr null, i64 %t133)
  %t135 = add i64 %t132, %t134
  %t136 = extractvalue { i64, ptr } { i64 7, ptr @.d151 }, 1
  %t137 = extractvalue { i64, ptr } { i64 7, ptr @.d151 }, 0
  %t138 = add i64 %t135, %t137
  %t139 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t139, 1
  %t141 = extractvalue { i64, ptr } %t139, 0
  %t142 = add i64 %t138, %t141
  %t143 = extractvalue { i64, ptr } { i64 1, ptr @.d152 }, 1
  %t144 = extractvalue { i64, ptr } { i64 1, ptr @.d152 }, 0
  %t145 = add i64 %t142, %t144
  %t146 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t145)
  call void @olang_textcopy(ptr %t146, ptr %t131, i64 %t132)
  %t147 = getelementptr i8, ptr %t146, i64 %t132
  %t148 = call i64 @__olang_fmt_i64(ptr %t147, i64 %t133)
  %t149 = getelementptr i8, ptr %t147, i64 %t134
  call void @olang_textcopy(ptr %t149, ptr %t136, i64 %t137)
  %t150 = getelementptr i8, ptr %t149, i64 %t137
  call void @olang_textcopy(ptr %t150, ptr %t140, i64 %t141)
  %t151 = getelementptr i8, ptr %t150, i64 %t141
  call void @olang_textcopy(ptr %t151, ptr %t143, i64 %t144)
  %t152 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t153 = insertvalue { i64, ptr } %t152, ptr %t146, 1
  %t155 = extractvalue { i64, ptr } %t153, 0
  %t156 = extractvalue { i64, ptr } %t153, 1
  %t157 = mul i64 %t155, 1
  %t158 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t157)
  call void @llvm.memcpy.p0.p0.i64(ptr %t158, ptr %t156, i64 %t157, i1 false)
  %t159 = insertvalue { i64, ptr } undef, i64 %t155, 0
  %t160 = insertvalue { i64, ptr } %t159, ptr %t158, 1
  %t161 = load ptr, ptr %l78, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s6, ptr %s6, ptr %t161, { i64, ptr } %t160)
  br label %bb36
bb36:
  %t163 = load ptr, ptr @__olang_prog_scope
  %t164 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %t163)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t164, ptr %l84
  br label %bb37
bb37:
  %t165 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l84
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t165, ptr %l15
  %t166 = getelementptr %"compiler/emit:Reused", ptr %l12, i32 0, i32 5
  store ptr %t166, ptr %l16, !tbaa !29
  store i64 0, ptr %l17, !tbaa !24
  br label %bb38
bb38:
  store %olang.scope zeroinitializer, ptr %s10
  %t168 = load ptr, ptr %l16, !tbaa !29
  %t169 = load i64, ptr %l17, !tbaa !24
  %t172 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v3, ptr %t168, i64 %t169)
  %t173 = extractvalue { i32, { i64, ptr } } %t172, 1
  %t174 = extractvalue { i32, { i64, ptr } } %t172, 0
  store i32 %t174, ptr %l90
  %t175 = icmp ne i32 %t174, 0
  br i1 %t175, label %bb40, label %ok.176
ok.176:
  store { i64, ptr } %t173, ptr %l89
  br label %bb39
bb39:
  %t177 = load { i64, ptr }, ptr %l89, !tbaa !27
  store { i64, ptr } %t177, ptr %l86, !tbaa !27
  br label %bb44
bb40:
  %t178 = load i32, ptr %l90, !tbaa !23
  %t179 = ashr i32 %t178, 16
  %t181 = icmp eq i32 %t179, 1
  br i1 %t181, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  call void @__olang_check_failed(ptr @.c153)
  unreachable
bb43:
  call void @__olang_scope_close(ptr %s10)
  br label %bb58
bb44:
  %t183 = load { i64, ptr }, ptr %l86, !tbaa !27
  store { i64, ptr } %t183, ptr %l18, !tbaa !27
  %t184 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t186 = extractvalue { i64, ptr } %t184, 0
  store i64 %t186, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb45
bb45:
  store %olang.scope zeroinitializer, ptr %s11
  %t188 = load i64, ptr %l20, !tbaa !24
  %t189 = load i64, ptr %l19, !tbaa !24
  %t192 = icmp slt i64 %t188, %t189
  %t194 = xor i1 %t192, true
  br i1 %t194, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s11)
  br label %bb56
bb47:
  br label %bb48
bb48:
  %t196 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t196, ptr %l99, !tbaa !27
  %t197 = load i64, ptr %l20, !tbaa !24
  %t199 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !27
  %t201 = getelementptr { i64, ptr }, ptr %t200, i64 %t197
  %t202 = load { i64, ptr }, ptr %t201, !tbaa !37
  store { i64, ptr } %t202, ptr %l21, !tbaa !27
  %t204 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t207 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %s6, ptr %v3, ptr %l15, { i64, ptr } %t204)
  store i1 %t207, ptr %l104
  br label %bb49
bb49:
  %t208 = load i1, ptr %l104, !tbaa !21
  br i1 %t208, label %bb50, label %bb51
bb50:
  call void @__olang_scope_close(ptr %s11)
  br label %bb55
bb51:
  br label %bb52
bb52:
  %t209 = load { i64, ptr }, ptr %l21, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H2b85ceff512af6e6ca26c554a1c16247(ptr %s6, ptr %v3, ptr %l15, { i64, ptr } %t209, i1 true)
  br label %bb53
bb53:
  %t212 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t213 = extractvalue { i64, ptr } { i64 5, ptr @.d154 }, 1
  %t214 = extractvalue { i64, ptr } { i64 5, ptr @.d154 }, 0
  %t216 = extractvalue { i64, ptr } %t212, 1
  %t217 = extractvalue { i64, ptr } %t212, 0
  %t218 = add i64 %t214, %t217
  %t219 = extractvalue { i64, ptr } { i64 1, ptr @.d155 }, 1
  %t220 = extractvalue { i64, ptr } { i64 1, ptr @.d155 }, 0
  %t221 = add i64 %t218, %t220
  %t222 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t221)
  call void @olang_textcopy(ptr %t222, ptr %t213, i64 %t214)
  %t223 = getelementptr i8, ptr %t222, i64 %t214
  call void @olang_textcopy(ptr %t223, ptr %t216, i64 %t217)
  %t224 = getelementptr i8, ptr %t223, i64 %t217
  call void @olang_textcopy(ptr %t224, ptr %t219, i64 %t220)
  %t225 = insertvalue { i64, ptr } undef, i64 %t221, 0
  %t226 = insertvalue { i64, ptr } %t225, ptr %t222, 1
  %t228 = extractvalue { i64, ptr } %t226, 0
  %t229 = extractvalue { i64, ptr } %t226, 1
  %t230 = mul i64 %t228, 1
  %t231 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t230)
  call void @llvm.memcpy.p0.p0.i64(ptr %t231, ptr %t229, i64 %t230, i1 false)
  %t232 = insertvalue { i64, ptr } undef, i64 %t228, 0
  %t233 = insertvalue { i64, ptr } %t232, ptr %t231, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s6, ptr %s11, ptr %l14, { i64, ptr } %t233)
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s11)
  br label %bb55
bb55:
  %t236 = load i64, ptr %l20, !tbaa !24
  %t238 = add i64 %t236, 1
  store i64 %t238, ptr %l20, !tbaa !24
  br label %bb45
bb56:
  %t240 = load i64, ptr %l17, !tbaa !24
  %t241 = load i64, ptr %l19, !tbaa !24
  %t244 = add i64 %t240, %t241
  store i64 %t244, ptr %l17, !tbaa !24
  call void @__olang_scope_close(ptr %s10)
  br label %bb57
bb57:
  br label %bb38
bb58:
  store i1 true, ptr %l22, !tbaa !21
  store i64 0, ptr %l23, !tbaa !24
  %t246 = getelementptr %"compiler/emit:Reused", ptr %l12, i32 0, i32 1
  %t248 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v3, ptr %t246)
  store i64 %t248, ptr %l117
  br label %bb59
bb59:
  %t249 = load i64, ptr %l117, !tbaa !24
  store i64 %t249, ptr %l24, !tbaa !24
  store i64 1, ptr %l25, !tbaa !24
  %t250 = load i64, ptr %l24, !tbaa !24
  %t251 = load i64, ptr %l23, !tbaa !24
  %t254 = icmp sgt i64 %t250, %t251
  br i1 %t254, label %bb60, label %bb61
bb60:
  %t256 = load i64, ptr %l25, !tbaa !24
  %t258 = icmp sgt i64 %t256, 0
  br i1 %t258, label %bb62, label %bb63
bb61:
  store i64 0, ptr %l121, !tbaa !24
  br label %bb65
bb62:
  %t260 = load i64, ptr %l24, !tbaa !24
  %t261 = load i64, ptr %l23, !tbaa !24
  %t264 = sub i64 %t260, %t261
  %t265 = load i64, ptr %l25, !tbaa !24
  %t268 = add i64 %t264, %t265
  %t270 = sub i64 %t268, 1
  %t271 = load i64, ptr %l25, !tbaa !24
  %t274 = sdiv i64 %t270, %t271
  store i64 %t274, ptr %l124, !tbaa !24
  br label %bb64
bb63:
  store i64 0, ptr %l124, !tbaa !24
  br label %bb64
bb64:
  %t276 = load i64, ptr %l124, !tbaa !24
  store i64 %t276, ptr %l121, !tbaa !24
  br label %bb65
bb65:
  %t277 = load i64, ptr %l121, !tbaa !24
  store i64 %t277, ptr %l26, !tbaa !24
  store i64 0, ptr %l27, !tbaa !24
  br label %bb66
bb66:
  store %olang.scope zeroinitializer, ptr %s16
  %t278 = load i64, ptr %l27, !tbaa !24
  %t279 = load i64, ptr %l26, !tbaa !24
  %t282 = icmp slt i64 %t278, %t279
  %t284 = xor i1 %t282, true
  br i1 %t284, label %bb67, label %bb68
bb67:
  call void @__olang_scope_close(ptr %s16)
  br label %bb79
bb68:
  br label %bb69
bb69:
  %t286 = load i64, ptr %l23, !tbaa !24
  %t287 = load i64, ptr %l27, !tbaa !24
  %t288 = load i64, ptr %l25, !tbaa !24
  %t291 = mul i64 %t287, %t288
  %t294 = add i64 %t286, %t291
  store i64 %t294, ptr %l28, !tbaa !24
  %t296 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t297 = load i64, ptr %l28, !tbaa !24
  %t299 = extractvalue { i64, ptr } %t296, 1
  %t300 = extractvalue { i64, ptr } %t296, 0
  %t301 = extractvalue { i64, ptr } { i64 2, ptr @.d156 }, 1
  %t302 = extractvalue { i64, ptr } { i64 2, ptr @.d156 }, 0
  %t303 = add i64 %t300, %t302
  %t305 = call i64 @__olang_fmt_i64(ptr null, i64 %t297)
  %t306 = add i64 %t303, %t305
  %t307 = extractvalue { i64, ptr } { i64 3, ptr @.d157 }, 1
  %t308 = extractvalue { i64, ptr } { i64 3, ptr @.d157 }, 0
  %t309 = add i64 %t306, %t308
  %t310 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t309)
  call void @olang_textcopy(ptr %t310, ptr %t299, i64 %t300)
  %t311 = getelementptr i8, ptr %t310, i64 %t300
  call void @olang_textcopy(ptr %t311, ptr %t301, i64 %t302)
  %t312 = getelementptr i8, ptr %t311, i64 %t302
  %t313 = call i64 @__olang_fmt_i64(ptr %t312, i64 %t297)
  %t314 = getelementptr i8, ptr %t312, i64 %t305
  call void @olang_textcopy(ptr %t314, ptr %t307, i64 %t308)
  %t315 = insertvalue { i64, ptr } undef, i64 %t309, 0
  %t316 = insertvalue { i64, ptr } %t315, ptr %t310, 1
  %t318 = extractvalue { i64, ptr } %t316, 0
  %t319 = extractvalue { i64, ptr } %t316, 1
  %t320 = mul i64 %t318, 1
  %t321 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t320)
  call void @llvm.memcpy.p0.p0.i64(ptr %t321, ptr %t319, i64 %t320, i1 false)
  %t322 = insertvalue { i64, ptr } undef, i64 %t318, 0
  %t323 = insertvalue { i64, ptr } %t322, ptr %t321, 1
  store { i64, ptr } %t323, ptr %l145, !tbaa !27
  %t326 = getelementptr %"compiler/emit:Reused", ptr %l12, i32 0, i32 6
  %t327 = load i64, ptr %t326, !tbaa !24
  %t328 = load i64, ptr %l28, !tbaa !24
  %t331 = add i64 %t327, %t328
  %t334 = call %"compiler/emit:Object" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aObject_3e_2eAt_3ccompiler_2femit_3aObject_3e(ptr %v4, ptr %v4, ptr %a4, i64 %t331)
  store %"compiler/emit:Object" %t334, ptr %l151
  br label %bb70
bb70:
  %t335 = getelementptr %"compiler/emit:Object", ptr %l151, i32 0, i32 2
  %t336 = load { i64, ptr }, ptr %t335, !tbaa !27
  %t337 = load i32, ptr %l6, !tbaa !23
  %t338 = load { i64, ptr }, ptr %l145, !tbaa !27
  %t341 = call i1 @compiler_2folang_2eputFile(ptr %s16, ptr %v4, { i64, ptr } %t338, { i64, ptr } %t336, i32 %t337)
  store i1 %t341, ptr %l154
  br label %bb71
bb71:
  %t342 = load i1, ptr %l154, !tbaa !21
  %t343 = xor i1 %t342, true
  br i1 %t343, label %bb72, label %bb73
bb72:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb74
bb73:
  br label %bb74
bb74:
  store ptr %l14, ptr %l156, !tbaa !29
  %t346 = getelementptr %"compiler/emit:Reused", ptr %l12, i32 0, i32 6
  %t347 = load i64, ptr %t346, !tbaa !24
  %t348 = load i64, ptr %l28, !tbaa !24
  %t351 = add i64 %t347, %t348
  %t354 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v5, ptr %s16, ptr %a5, i64 %t351)
  store { i64, ptr } %t354, ptr %l161
  br label %bb75
bb75:
  %t355 = getelementptr %"compiler/emit:Reused", ptr %l12, i32 0, i32 1
  %t356 = load i64, ptr %l28, !tbaa !24
  %t359 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v3, ptr %s16, ptr %t355, i64 %t356)
  store { i64, ptr } %t359, ptr %l164
  br label %bb76
bb76:
  %t360 = extractvalue { i64, ptr } { i64 5, ptr @.d158 }, 1
  %t361 = extractvalue { i64, ptr } { i64 5, ptr @.d158 }, 0
  %t362 = load { i64, ptr }, ptr %l161, !tbaa !27
  %t363 = extractvalue { i64, ptr } %t362, 1
  %t364 = extractvalue { i64, ptr } %t362, 0
  %t365 = add i64 %t361, %t364
  %t366 = extractvalue { i64, ptr } { i64 1, ptr @.d159 }, 1
  %t367 = extractvalue { i64, ptr } { i64 1, ptr @.d159 }, 0
  %t368 = add i64 %t365, %t367
  %t369 = load { i64, ptr }, ptr %l164, !tbaa !27
  %t370 = extractvalue { i64, ptr } %t369, 1
  %t371 = extractvalue { i64, ptr } %t369, 0
  %t372 = add i64 %t368, %t371
  %t373 = extractvalue { i64, ptr } { i64 1, ptr @.d160 }, 1
  %t374 = extractvalue { i64, ptr } { i64 1, ptr @.d160 }, 0
  %t375 = add i64 %t372, %t374
  %t376 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t375)
  call void @olang_textcopy(ptr %t376, ptr %t360, i64 %t361)
  %t377 = getelementptr i8, ptr %t376, i64 %t361
  call void @olang_textcopy(ptr %t377, ptr %t363, i64 %t364)
  %t378 = getelementptr i8, ptr %t377, i64 %t364
  call void @olang_textcopy(ptr %t378, ptr %t366, i64 %t367)
  %t379 = getelementptr i8, ptr %t378, i64 %t367
  call void @olang_textcopy(ptr %t379, ptr %t370, i64 %t371)
  %t380 = getelementptr i8, ptr %t379, i64 %t371
  call void @olang_textcopy(ptr %t380, ptr %t373, i64 %t374)
  %t381 = insertvalue { i64, ptr } undef, i64 %t375, 0
  %t382 = insertvalue { i64, ptr } %t381, ptr %t376, 1
  %t384 = extractvalue { i64, ptr } %t382, 0
  %t385 = extractvalue { i64, ptr } %t382, 1
  %t386 = mul i64 %t384, 1
  %t387 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t386)
  call void @llvm.memcpy.p0.p0.i64(ptr %t387, ptr %t385, i64 %t386, i1 false)
  %t388 = insertvalue { i64, ptr } undef, i64 %t384, 0
  %t389 = insertvalue { i64, ptr } %t388, ptr %t387, 1
  %t390 = load ptr, ptr %l156, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s6, ptr %s16, ptr %t390, { i64, ptr } %t389)
  br label %bb77
bb77:
  call void @__olang_scope_close(ptr %s16)
  br label %bb78
bb78:
  %t392 = load i64, ptr %l27, !tbaa !24
  %t394 = add i64 %t392, 1
  store i64 %t394, ptr %l27, !tbaa !24
  br label %bb66
bb79:
  %t396 = load i1, ptr %l22, !tbaa !21
  %t398 = xor i1 %t396, true
  br i1 %t398, label %bb80, label %bb81
bb80:
  call void @__olang_scope_close(ptr %s6)
  br label %bb86
bb81:
  br label %bb82
bb82:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s6, ptr %s6, ptr %l14, { i64, ptr } { i64 4, ptr @.d161 })
  br label %bb83
bb83:
  %t401 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t401, ptr %l172, !tbaa !27
  %t403 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s6, ptr %s6, ptr %l14)
  store { i64, ptr } %t403, ptr %l174
  br label %bb84
bb84:
  %t404 = load i32, ptr %l6, !tbaa !23
  %t405 = load { i64, ptr }, ptr %l172, !tbaa !27
  %t406 = load { i64, ptr }, ptr %l174, !tbaa !27
  %t408 = call i1 @compiler_2folang_2eputFile(ptr %s6, ptr %s6, { i64, ptr } %t405, { i64, ptr } %t406, i32 %t404)
  store i1 %t408, ptr %l176
  br label %bb85
bb85:
  call void @__olang_scope_close(ptr %s6)
  br label %bb86
bb86:
  %t409 = load i64, ptr %l11, !tbaa !24
  %t411 = add i64 %t409, 1
  store i64 %t411, ptr %l11, !tbaa !24
  br label %bb19
bb87:
  %t413 = load i64, ptr %l8, !tbaa !24
  %t414 = load i64, ptr %l10, !tbaa !24
  %t417 = add i64 %t413, %t414
  store i64 %t417, ptr %l8, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb88
bb88:
  br label %bb12
bb89:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2folang_2emain() #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l6 = alloca i32
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  call void @std_2fos_2eOnCrash(ptr %s0, { i64, ptr } { i64 97, ptr @.d162 })
  br label %bb1
bb1:
  %t1 = call { i64, ptr } @std_2fos_2eArgs(ptr %s0)
  store { i64, ptr } %t1, ptr %l1
  br label %bb2
bb2:
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t2, ptr %l0, !tbaa !27
  %t3 = call i1 @compiler_2folang_2eroomFor(i64 1073741824)
  store i1 %t3, ptr %l2
  br label %bb3
bb3:
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb4, label %bb5
bb4:
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t6 = getelementptr { { i64, ptr }, ptr }, ptr null, i32 1
  %t7 = ptrtoint ptr %t6 to i64
  %t8 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 %t7, i64 8)
  %t9 = getelementptr { { i64, ptr }, ptr }, ptr %t8, i32 0, i32 0
  store { i64, ptr } %t5, ptr %t9, !tbaa !28
  call void @__olang_scope_escape(ptr %s0)
  %t11 = getelementptr { { i64, ptr }, ptr }, ptr %t8, i32 0, i32 1
  store ptr %s0, ptr %t11, !tbaa !28
  %t12 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_163, 0
  %t13 = insertvalue { ptr, ptr } %t12, ptr %t8, 1
  %t15 = extractvalue { ptr, ptr } %t13, 0
  %t16 = extractvalue { ptr, ptr } %t13, 1
  call void @std_2fos_2eRunOnStack(ptr %s0, i64 1073741824, ptr %t15, ptr %t16)
  br label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb7
bb7:
  %t17 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t19 = call i32 @compiler_2folang_2edrive(ptr %s0, { i64, ptr } %t17)
  store i32 %t19, ptr %l6
  br label %bb8
bb8:
  %t20 = load i32, ptr %l6, !tbaa !23
  call void @std_2fos_2eExit(i32 %t20)
  unreachable
bb9:
  call void @__olang_check_failed(ptr @.c164)
  unreachable
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2folang_2emodeName(ptr %v0, i64 %a0) #0 {
entry:
  %l0 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store i64 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !24
  %t2 = load i64, ptr @G_2ecompiler_2folang_2eRun, !tbaa !24
  %t5 = icmp eq i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 14, ptr @.d165 }, ptr %l5, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t7, ptr %l4, !tbaa !27
  br label %bb3
bb2:
  %t9 = load i64, ptr %l0, !tbaa !24
  %t11 = getelementptr [8 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eModeWords, i64 0, i64 %t9
  %t12 = load { i64, ptr }, ptr %t11, !tbaa !37
  %t14 = extractvalue { i64, ptr } %t12, 1
  %t15 = extractvalue { i64, ptr } %t12, 0
  %t16 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t14, i64 %t15)
  %t17 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l4, !tbaa !27
  br label %bb3
bb3:
  %t20 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t20, 0
  store i64 %t21, ptr %l10, !tbaa !24
  %t22 = load i64, ptr %l10, !tbaa !24
  %t23 = mul i64 %t22, 1
  %t24 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t23)
  %t25 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t24, 1
  store { i64, ptr } %t26, ptr %l11, !tbaa !27
  %t27 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = load i64, ptr %l10, !tbaa !24
  %t32 = mul i64 %t31, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t28, ptr %t30, i64 %t32, i1 false)
  %t33 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t33, ptr %l4, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t34, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2folang_2emodeNumber(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l12 = alloca i64
  %l15 = alloca i64
  %l36 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store i64 1, ptr %l1, !tbaa !24
  %t1 = load [8 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eModeWords
  store i64 8, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t4 = load i64, ptr %l2, !tbaa !24
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = icmp sgt i64 %t4, %t5
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t12 = icmp sgt i64 %t10, 0
  br i1 %t12, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l12, !tbaa !24
  br label %bb6
bb3:
  %t14 = load i64, ptr %l2, !tbaa !24
  %t15 = load i64, ptr %l1, !tbaa !24
  %t18 = sub i64 %t14, %t15
  %t19 = load i64, ptr %l3, !tbaa !24
  %t22 = add i64 %t18, %t19
  %t24 = sub i64 %t22, 1
  %t25 = load i64, ptr %l3, !tbaa !24
  %t28 = sdiv i64 %t24, %t25
  store i64 %t28, ptr %l15, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb5
bb5:
  %t30 = load i64, ptr %l15, !tbaa !24
  store i64 %t30, ptr %l12, !tbaa !24
  br label %bb6
bb6:
  %t31 = load i64, ptr %l12, !tbaa !24
  store i64 %t31, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t32 = load i64, ptr %l5, !tbaa !24
  %t33 = load i64, ptr %l4, !tbaa !24
  %t36 = icmp slt i64 %t32, %t33
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb9:
  br label %bb10
bb10:
  %t40 = load i64, ptr %l1, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  %t42 = load i64, ptr %l3, !tbaa !24
  %t45 = mul i64 %t41, %t42
  %t48 = add i64 %t40, %t45
  store i64 %t48, ptr %l6, !tbaa !24
  %t50 = load i64, ptr %l6, !tbaa !24
  %t52 = getelementptr [8 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eModeWords, i64 0, i64 %t50
  %t53 = load { i64, ptr }, ptr %t52, !tbaa !37
  %t55 = load ptr, ptr @__olang_prog_scope
  %t58 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t55, ptr %v0, { i64, ptr } %t53, { i64, ptr } %a0)
  store i1 %t58, ptr %l36
  br label %bb11
bb11:
  %t59 = load i1, ptr %l36, !tbaa !21
  br i1 %t59, label %bb12, label %bb13
bb12:
  %t60 = load i64, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  store i64 %t60, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb15:
  %t62 = load i64, ptr %l5, !tbaa !24
  %t64 = add i64 %t62, 1
  store i64 %t64, ptr %l5, !tbaa !24
  br label %bb7
bb16:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2folang_2emodesOf(ptr %v0, i64 %a0) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca %"std/prelude/text:StringBuilder"
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l21 = alloca i64
  %l24 = alloca i64
  %l44 = alloca i64
  %l50 = alloca %"std/prelude/text:StringBuilder"
  %l56 = alloca i64
  %l59 = alloca i64
  %l78 = alloca i64
  %l86 = alloca ptr
  %l90 = alloca { i64, ptr }
  %l91 = alloca ptr
  %l93 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %l100 = alloca i64
  %l101 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store i64 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 0, ptr %l1, !tbaa !24
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load [8 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eModeWords
  store i64 8, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t4 = load i64, ptr %l3, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  %t8 = icmp sgt i64 %t4, %t5
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load i64, ptr %l4, !tbaa !24
  %t12 = icmp sgt i64 %t10, 0
  br i1 %t12, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb6
bb3:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l2, !tbaa !24
  %t18 = sub i64 %t14, %t15
  %t19 = load i64, ptr %l4, !tbaa !24
  %t22 = add i64 %t18, %t19
  %t24 = sub i64 %t22, 1
  %t25 = load i64, ptr %l4, !tbaa !24
  %t28 = sdiv i64 %t24, %t25
  store i64 %t28, ptr %l24, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb5
bb5:
  %t30 = load i64, ptr %l24, !tbaa !24
  store i64 %t30, ptr %l21, !tbaa !24
  br label %bb6
bb6:
  %t31 = load i64, ptr %l21, !tbaa !24
  store i64 %t31, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t32 = load i64, ptr %l6, !tbaa !24
  %t33 = load i64, ptr %l5, !tbaa !24
  %t36 = icmp slt i64 %t32, %t33
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb9:
  br label %bb10
bb10:
  %t40 = load i64, ptr %l2, !tbaa !24
  %t41 = load i64, ptr %l6, !tbaa !24
  %t42 = load i64, ptr %l4, !tbaa !24
  %t45 = mul i64 %t41, %t42
  %t48 = add i64 %t40, %t45
  %t50 = load i64, ptr %l1, !tbaa !24
  %t51 = load i64, ptr %l0, !tbaa !24
  store i64 %t48, ptr %l44, !tbaa !24
  %t54 = load i64, ptr %l44, !tbaa !24
  %t55 = load i64, ptr %l44, !tbaa !24
  %t56 = ashr i64 %t51, %t55
  %t58 = and i64 %t56, 1
  %t61 = add i64 %t50, %t58
  store i64 %t61, ptr %l1, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb11:
  %t63 = load i64, ptr %l6, !tbaa !24
  %t65 = add i64 %t63, 1
  store i64 %t65, ptr %l6, !tbaa !24
  br label %bb7
bb12:
  %t67 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t67, ptr %l50
  br label %bb13
bb13:
  %t68 = load %"std/prelude/text:StringBuilder", ptr %l50
  store %"std/prelude/text:StringBuilder" %t68, ptr %l8
  store i64 0, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  %t69 = load [8 x { i64, ptr }], ptr @G_2ecompiler_2folang_2eModeWords
  store i64 8, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t72 = load i64, ptr %l11, !tbaa !24
  %t73 = load i64, ptr %l10, !tbaa !24
  %t76 = icmp sgt i64 %t72, %t73
  br i1 %t76, label %bb14, label %bb15
bb14:
  %t78 = load i64, ptr %l12, !tbaa !24
  %t80 = icmp sgt i64 %t78, 0
  br i1 %t80, label %bb16, label %bb17
bb15:
  store i64 0, ptr %l56, !tbaa !24
  br label %bb19
bb16:
  %t82 = load i64, ptr %l11, !tbaa !24
  %t83 = load i64, ptr %l10, !tbaa !24
  %t86 = sub i64 %t82, %t83
  %t87 = load i64, ptr %l12, !tbaa !24
  %t90 = add i64 %t86, %t87
  %t92 = sub i64 %t90, 1
  %t93 = load i64, ptr %l12, !tbaa !24
  %t96 = sdiv i64 %t92, %t93
  store i64 %t96, ptr %l59, !tbaa !24
  br label %bb18
bb17:
  store i64 0, ptr %l59, !tbaa !24
  br label %bb18
bb18:
  %t98 = load i64, ptr %l59, !tbaa !24
  store i64 %t98, ptr %l56, !tbaa !24
  br label %bb19
bb19:
  %t99 = load i64, ptr %l56, !tbaa !24
  store i64 %t99, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s5
  %t100 = load i64, ptr %l14, !tbaa !24
  %t101 = load i64, ptr %l13, !tbaa !24
  %t104 = icmp slt i64 %t100, %t101
  %t106 = xor i1 %t104, true
  br i1 %t106, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s5)
  br label %bb37
bb22:
  br label %bb23
bb23:
  %t108 = load i64, ptr %l10, !tbaa !24
  %t109 = load i64, ptr %l14, !tbaa !24
  %t110 = load i64, ptr %l12, !tbaa !24
  %t113 = mul i64 %t109, %t110
  %t116 = add i64 %t108, %t113
  store i64 %t116, ptr %l15, !tbaa !24
  %t118 = load i64, ptr %l0, !tbaa !24
  %t119 = load i64, ptr %l15, !tbaa !24
  store i64 %t119, ptr %l78, !tbaa !24
  %t121 = load i64, ptr %l78, !tbaa !24
  %t122 = load i64, ptr %l78, !tbaa !24
  %t123 = ashr i64 %t118, %t122
  %t125 = and i64 %t123, 1
  %t127 = icmp eq i64 %t125, 0
  br i1 %t127, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s5)
  br label %bb36
bb25:
  br label %bb26
bb26:
  %t129 = load i64, ptr %l9, !tbaa !24
  %t131 = add i64 %t129, 1
  store i64 %t131, ptr %l9, !tbaa !24
  %t133 = load i64, ptr %l9, !tbaa !24
  %t135 = icmp sgt i64 %t133, 1
  br i1 %t135, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s7
  store ptr %l8, ptr %l86, !tbaa !29
  %t137 = load i64, ptr %l9, !tbaa !24
  %t138 = load i64, ptr %l1, !tbaa !24
  %t141 = icmp eq i64 %t137, %t138
  br i1 %t141, label %bb29, label %bb30
bb28:
  br label %bb33
bb29:
  store { i64, ptr } { i64 5, ptr @.d166 }, ptr %l90, !tbaa !27
  br label %bb31
bb30:
  store { i64, ptr } { i64 2, ptr @.d167 }, ptr %l90, !tbaa !27
  br label %bb31
bb31:
  %t143 = load ptr, ptr %l86, !tbaa !29
  %t144 = load { i64, ptr }, ptr %l90, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %t143, { i64, ptr } %t144)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s7)
  br label %bb33
bb33:
  store ptr %l8, ptr %l91, !tbaa !29
  %t145 = load i64, ptr %l15, !tbaa !24
  %t147 = call { i64, ptr } @compiler_2folang_2emodeName(ptr %s5, i64 %t145)
  store { i64, ptr } %t147, ptr %l93
  br label %bb34
bb34:
  %t148 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t149 = extractvalue { i64, ptr } %t148, 0
  %t150 = extractvalue { i64, ptr } %t148, 1
  %t151 = mul i64 %t149, 1
  %t152 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t151)
  call void @llvm.memcpy.p0.p0.i64(ptr %t152, ptr %t150, i64 %t151, i1 false)
  %t153 = insertvalue { i64, ptr } undef, i64 %t149, 0
  %t154 = insertvalue { i64, ptr } %t153, ptr %t152, 1
  %t155 = load ptr, ptr %l91, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %t155, { i64, ptr } %t154)
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s5)
  br label %bb36
bb36:
  %t157 = load i64, ptr %l14, !tbaa !24
  %t159 = add i64 %t157, 1
  store i64 %t159, ptr %l14, !tbaa !24
  br label %bb20
bb37:
  %t162 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v0, ptr %l8)
  store { i64, ptr } %t162, ptr %l98
  br label %bb38
bb38:
  %t163 = load { i64, ptr }, ptr %l98, !tbaa !27
  store { i64, ptr } %t163, ptr %l99, !tbaa !27
  %t164 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t165 = extractvalue { i64, ptr } %t164, 0
  store i64 %t165, ptr %l100, !tbaa !24
  %t166 = load i64, ptr %l100, !tbaa !24
  %t167 = mul i64 %t166, 1
  %t168 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t167)
  %t169 = insertvalue { i64, ptr } undef, i64 %t166, 0
  %t170 = insertvalue { i64, ptr } %t169, ptr %t168, 1
  store { i64, ptr } %t170, ptr %l101, !tbaa !27
  %t171 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t172 = load ptr, ptr %t171, !tbaa !27
  %t173 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t174 = load ptr, ptr %t173, !tbaa !27
  %t175 = load i64, ptr %l100, !tbaa !24
  %t176 = mul i64 %t175, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t172, ptr %t174, i64 %t176, i1 false)
  %t177 = load { i64, ptr }, ptr %l101, !tbaa !27
  store { i64, ptr } %t177, ptr %l99, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t178 = load { i64, ptr }, ptr %l99, !tbaa !27
  store { i64, ptr } %t178, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2folang_2emoduleKeys(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l25 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca i64
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca %"compiler/load:Import"
  %l39 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l40 = alloca ptr
  %l41 = alloca i64
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l56 = alloca { i64, ptr }
  %l58 = alloca i1
  %l60 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l67 = alloca ptr
  %l69 = alloca { i64, ptr }
  %l73 = alloca ptr
  %l79 = alloca i64
  %l87 = alloca i64
  %l90 = alloca i64
  %l110 = alloca ptr
  %l111 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l121 = alloca ptr
  %l125 = alloca { i64, ptr }
  %l130 = alloca { i64, ptr }
  %l133 = alloca i64
  %l135 = alloca { i64, ptr }
  %l143 = alloca i64
  %l146 = alloca i64
  %l168 = alloca i64
  %l171 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l172 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l179 = alloca i64
  %l182 = alloca i64
  %l202 = alloca ptr
  %l210 = alloca i64
  %l213 = alloca i64
  %l215 = alloca i64
  %l216 = alloca i32
  %l224 = alloca ptr
  %l227 = alloca { i64, ptr }
  %l230 = alloca { i64, ptr }
  %l231 = alloca i32
  %l240 = alloca { i64, ptr }
  %l245 = alloca i1
  %l258 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l265 = alloca { i64, ptr }
  %l268 = alloca { i64, ptr }
  %l269 = alloca i32
  %l278 = alloca { i64, ptr }
  %l281 = alloca ptr
  %l284 = alloca ptr
  %l296 = alloca { i64, ptr }
  %l297 = alloca i64
  %l299 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/load:Loader", ptr %t1, i32 0, i32 5
  %t4 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t3
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %l3
  %t7 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v0, ptr %l3)
  store i64 %t7, ptr %l49
  br label %bb1
bb1:
  %t8 = load i64, ptr %l49, !tbaa !24
  store i64 %t8, ptr %l4, !tbaa !24
  %t9 = load i64, ptr %l4, !tbaa !24
  store i64 %t9, ptr %l50, !tbaa !24
  %t10 = load i64, ptr %l50, !tbaa !24
  %t11 = icmp sge i64 %t10, 0
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l50, !tbaa !24
  %t14 = icmp sle i64 %t13, 576460752303423487
  br i1 %t14, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @.c168)
  unreachable
bb4:
  %t16 = load i64, ptr %l50, !tbaa !24
  %t17 = mul i64 %t16, 16
  %t18 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t17)
  %t19 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l5, !tbaa !27
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t26 = call { i64, ptr } @compiler_2folang_2ebuildInputs(ptr %v1, ptr %s0, ptr %t22, i1 %a2)
  store { i64, ptr } %t26, ptr %l56
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @.c168)
  unreachable
bb6:
  %t27 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t27, ptr %l6, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t30 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t28, { i64, ptr } { i64 0, ptr @.d169 })
  store i1 %t30, ptr %l58
  br label %bb7
bb7:
  %t31 = load i1, ptr %l58, !tbaa !21
  br i1 %t31, label %bb8, label %bb9
bb8:
  %t32 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t32, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t34 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t34, ptr %l60, !tbaa !27
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t37 = getelementptr %"compiler/build:Config", ptr %t35, i32 0, i32 4
  %t38 = load i1, ptr %t37, !tbaa !21
  br i1 %t38, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/load:Loader", ptr %t40, i32 0, i32 7
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %l3, i64 %t43)
  store ptr %t46, ptr %l67
  br label %bb13
bb12:
  store { i64, ptr } { i64 0, ptr @.d170 }, ptr %l63, !tbaa !27
  br label %bb15
bb13:
  %t47 = load ptr, ptr %l67, !tbaa !29
  %t49 = getelementptr %"compiler/load:Module", ptr %t47, i32 0, i32 2
  %t50 = load { i64, ptr }, ptr %t49, !tbaa !27
  store { i64, ptr } %t50, ptr %l69, !tbaa !27
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/load:Loader", ptr %t51, i32 0, i32 7
  %t54 = load i64, ptr %t53, !tbaa !24
  %t57 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %l3, i64 %t54)
  store ptr %t57, ptr %l73
  br label %bb14
bb14:
  %t58 = load ptr, ptr %l73, !tbaa !29
  %t60 = getelementptr %"compiler/load:Module", ptr %t58, i32 0, i32 0
  %t61 = load { i64, ptr }, ptr %t60, !tbaa !27
  %t62 = extractvalue { i64, ptr } { i64 6, ptr @.d171 }, 1
  %t63 = extractvalue { i64, ptr } { i64 6, ptr @.d171 }, 0
  %t64 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 1
  %t66 = extractvalue { i64, ptr } %t64, 0
  %t67 = add i64 %t63, %t66
  %t68 = extractvalue { i64, ptr } { i64 1, ptr @.d172 }, 1
  %t69 = extractvalue { i64, ptr } { i64 1, ptr @.d172 }, 0
  %t70 = add i64 %t67, %t69
  %t72 = extractvalue { i64, ptr } %t61, 1
  %t73 = extractvalue { i64, ptr } %t61, 0
  %t74 = add i64 %t70, %t73
  %t75 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t74)
  call void @olang_textcopy(ptr %t75, ptr %t62, i64 %t63)
  %t76 = getelementptr i8, ptr %t75, i64 %t63
  call void @olang_textcopy(ptr %t76, ptr %t65, i64 %t66)
  %t77 = getelementptr i8, ptr %t76, i64 %t66
  call void @olang_textcopy(ptr %t77, ptr %t68, i64 %t69)
  %t78 = getelementptr i8, ptr %t77, i64 %t69
  call void @olang_textcopy(ptr %t78, ptr %t72, i64 %t73)
  %t79 = insertvalue { i64, ptr } undef, i64 %t74, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t75, 1
  %t82 = extractvalue { i64, ptr } %t80, 0
  %t83 = extractvalue { i64, ptr } %t80, 1
  %t84 = mul i64 %t82, 1
  %t85 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t84)
  call void @llvm.memcpy.p0.p0.i64(ptr %t85, ptr %t83, i64 %t84, i1 false)
  %t86 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t87 = insertvalue { i64, ptr } %t86, ptr %t85, 1
  store { i64, ptr } %t87, ptr %l63, !tbaa !27
  br label %bb15
bb15:
  %t89 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t89, 1
  %t91 = extractvalue { i64, ptr } %t89, 0
  %t92 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t92, 1
  %t94 = extractvalue { i64, ptr } %t92, 0
  %t95 = add i64 %t91, %t94
  %t96 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t95)
  call void @olang_textcopy(ptr %t96, ptr %t90, i64 %t91)
  %t97 = getelementptr i8, ptr %t96, i64 %t91
  call void @olang_textcopy(ptr %t97, ptr %t93, i64 %t94)
  %t98 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t96, 1
  store { i64, ptr } %t99, ptr %l7, !tbaa !27
  %t101 = load i64, ptr %l4, !tbaa !24
  store i64 %t101, ptr %l79, !tbaa !24
  %t102 = load i64, ptr %l79, !tbaa !24
  %t103 = icmp sge i64 %t102, 0
  br i1 %t103, label %bb16, label %bb17
bb16:
  %t105 = load i64, ptr %l79, !tbaa !24
  %t106 = icmp sle i64 %t105, 576460752303423487
  br i1 %t106, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @.c173)
  unreachable
bb18:
  %t108 = load i64, ptr %l79, !tbaa !24
  %t109 = mul i64 %t108, 16
  %t110 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t109)
  %t111 = insertvalue { i64, ptr } undef, i64 %t108, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  store { i64, ptr } %t112, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t114 = load i64, ptr %l4, !tbaa !24
  store i64 %t114, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t116 = load i64, ptr %l10, !tbaa !24
  %t117 = load i64, ptr %l9, !tbaa !24
  %t120 = icmp sgt i64 %t116, %t117
  br i1 %t120, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @.c173)
  unreachable
bb20:
  %t122 = load i64, ptr %l11, !tbaa !24
  %t124 = icmp sgt i64 %t122, 0
  br i1 %t124, label %bb22, label %bb23
bb21:
  store i64 0, ptr %l87, !tbaa !24
  br label %bb25
bb22:
  %t126 = load i64, ptr %l10, !tbaa !24
  %t127 = load i64, ptr %l9, !tbaa !24
  %t130 = sub i64 %t126, %t127
  %t131 = load i64, ptr %l11, !tbaa !24
  %t134 = add i64 %t130, %t131
  %t136 = sub i64 %t134, 1
  %t137 = load i64, ptr %l11, !tbaa !24
  %t140 = sdiv i64 %t136, %t137
  store i64 %t140, ptr %l90, !tbaa !24
  br label %bb24
bb23:
  store i64 0, ptr %l90, !tbaa !24
  br label %bb24
bb24:
  %t142 = load i64, ptr %l90, !tbaa !24
  store i64 %t142, ptr %l87, !tbaa !24
  br label %bb25
bb25:
  %t143 = load i64, ptr %l87, !tbaa !24
  store i64 %t143, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb26
bb26:
  store %olang.scope zeroinitializer, ptr %s5
  %t144 = load i64, ptr %l13, !tbaa !24
  %t145 = load i64, ptr %l12, !tbaa !24
  %t148 = icmp slt i64 %t144, %t145
  %t150 = xor i1 %t148, true
  br i1 %t150, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s5)
  br label %bb41
bb28:
  br label %bb29
bb29:
  %t152 = load i64, ptr %l9, !tbaa !24
  %t153 = load i64, ptr %l13, !tbaa !24
  %t154 = load i64, ptr %l11, !tbaa !24
  %t157 = mul i64 %t153, %t154
  %t160 = add i64 %t152, %t157
  store i64 %t160, ptr %l14, !tbaa !24
  %t162 = load i64, ptr %l14, !tbaa !24
  %t165 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %l3, i64 %t162)
  store ptr %t165, ptr %l110
  br label %bb30
bb30:
  %t166 = load ptr, ptr %l110, !tbaa !29
  store ptr %t166, ptr %l15, !tbaa !29
  %t167 = load ptr, ptr @__olang_prog_scope
  %t168 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t167)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t168, ptr %l111
  br label %bb31
bb31:
  %t169 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l111
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t169, ptr %l16
  %t170 = load ptr, ptr %l15, !tbaa !29
  %t172 = getelementptr %"compiler/load:Module", ptr %t170, i32 0, i32 2
  %t173 = load { i64, ptr }, ptr %t172, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s5, ptr %v0, ptr %l16, { i64, ptr } %t173)
  br label %bb32
bb32:
  %t176 = load ptr, ptr %l15, !tbaa !29
  %t178 = getelementptr %"compiler/load:Module", ptr %t176, i32 0, i32 0
  %t179 = load { i64, ptr }, ptr %t178, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s5, ptr %v0, ptr %l16, { i64, ptr } %t179)
  br label %bb33
bb33:
  %t182 = load ptr, ptr %l15, !tbaa !29
  %t184 = getelementptr %"compiler/load:Module", ptr %t182, i32 0, i32 1
  %t185 = load { i64, ptr }, ptr %t184, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s5, ptr %v0, ptr %l16, { i64, ptr } %t185)
  br label %bb34
bb34:
  store ptr %l16, ptr %l121, !tbaa !29
  %t188 = load ptr, ptr %l15, !tbaa !29
  %t190 = getelementptr %"compiler/load:Module", ptr %t188, i32 0, i32 6
  %t191 = load ptr, ptr %t190, !tbaa !29
  %t193 = icmp ne ptr %t191, null
  br i1 %t193, label %bb35, label %bb36
bb35:
  %t195 = load ptr, ptr %l15, !tbaa !29
  %t197 = getelementptr %"compiler/load:Module", ptr %t195, i32 0, i32 6
  %t198 = load ptr, ptr %t197, !tbaa !29
  %t200 = getelementptr %"compiler/source:Source", ptr %t198, i32 0, i32 1
  %t201 = load { i64, ptr }, ptr %t200, !tbaa !27
  store { i64, ptr } %t201, ptr %l125, !tbaa !27
  br label %bb37
bb36:
  store { i64, ptr } { i64 0, ptr @.d174 }, ptr %l130, !tbaa !27
  %t204 = load { i64, ptr }, ptr %l130, !tbaa !27
  store { i64, ptr } %t204, ptr %l125, !tbaa !27
  br label %bb37
bb37:
  %t206 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t207 = extractvalue { i64, ptr } %t206, 0
  %t208 = extractvalue { i64, ptr } %t206, 1
  %t209 = mul i64 %t207, 1
  %t210 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t209)
  call void @llvm.memcpy.p0.p0.i64(ptr %t210, ptr %t208, i64 %t209, i1 false)
  %t211 = insertvalue { i64, ptr } undef, i64 %t207, 0
  %t212 = insertvalue { i64, ptr } %t211, ptr %t210, 1
  %t213 = load ptr, ptr %l121, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s5, ptr %s5, ptr %t213, { i64, ptr } %t212)
  br label %bb38
bb38:
  %t215 = load i64, ptr %l14, !tbaa !24
  store i64 %t215, ptr %l133, !tbaa !24
  %t217 = call { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %s5, ptr %s0, ptr %l16)
  store { i64, ptr } %t217, ptr %l135
  br label %bb39
bb39:
  %t218 = load { i64, ptr }, ptr %l135, !tbaa !27
  %t219 = extractvalue { i64, ptr } %t218, 0
  %t220 = extractvalue { i64, ptr } %t218, 1
  %t221 = mul i64 %t219, 1
  %t222 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t221)
  call void @llvm.memcpy.p0.p0.i64(ptr %t222, ptr %t220, i64 %t221, i1 false)
  %t223 = insertvalue { i64, ptr } undef, i64 %t219, 0
  %t224 = insertvalue { i64, ptr } %t223, ptr %t222, 1
  %t226 = load i64, ptr %l133, !tbaa !24
  %t227 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t228 = load ptr, ptr %t227, !tbaa !27
  %t229 = getelementptr { i64, ptr }, ptr %t228, i64 %t226
  store { i64, ptr } %t224, ptr %t229, !tbaa !37
  call void @__olang_scope_close(ptr %s5)
  br label %bb40
bb40:
  %t230 = load i64, ptr %l13, !tbaa !24
  %t232 = add i64 %t230, 1
  store i64 %t232, ptr %l13, !tbaa !24
  br label %bb26
bb41:
  store i64 0, ptr %l17, !tbaa !24
  %t234 = load i64, ptr %l4, !tbaa !24
  store i64 %t234, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t236 = load i64, ptr %l18, !tbaa !24
  %t237 = load i64, ptr %l17, !tbaa !24
  %t240 = icmp sgt i64 %t236, %t237
  br i1 %t240, label %bb42, label %bb43
bb42:
  %t242 = load i64, ptr %l19, !tbaa !24
  %t244 = icmp sgt i64 %t242, 0
  br i1 %t244, label %bb44, label %bb45
bb43:
  store i64 0, ptr %l143, !tbaa !24
  br label %bb47
bb44:
  %t246 = load i64, ptr %l18, !tbaa !24
  %t247 = load i64, ptr %l17, !tbaa !24
  %t250 = sub i64 %t246, %t247
  %t251 = load i64, ptr %l19, !tbaa !24
  %t254 = add i64 %t250, %t251
  %t256 = sub i64 %t254, 1
  %t257 = load i64, ptr %l19, !tbaa !24
  %t260 = sdiv i64 %t256, %t257
  store i64 %t260, ptr %l146, !tbaa !24
  br label %bb46
bb45:
  store i64 0, ptr %l146, !tbaa !24
  br label %bb46
bb46:
  %t262 = load i64, ptr %l146, !tbaa !24
  store i64 %t262, ptr %l143, !tbaa !24
  br label %bb47
bb47:
  %t263 = load i64, ptr %l143, !tbaa !24
  store i64 %t263, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb48
bb48:
  store %olang.scope zeroinitializer, ptr %s8
  %t264 = load i64, ptr %l21, !tbaa !24
  %t265 = load i64, ptr %l20, !tbaa !24
  %t268 = icmp slt i64 %t264, %t265
  %t270 = xor i1 %t268, true
  br i1 %t270, label %bb49, label %bb50
bb49:
  call void @__olang_scope_close(ptr %s8)
  br label %bb138
bb50:
  br label %bb51
bb51:
  %t272 = load i64, ptr %l17, !tbaa !24
  %t273 = load i64, ptr %l21, !tbaa !24
  %t274 = load i64, ptr %l19, !tbaa !24
  %t277 = mul i64 %t273, %t274
  %t280 = add i64 %t272, %t277
  store i64 %t280, ptr %l22, !tbaa !24
  %t282 = load i64, ptr %l22, !tbaa !24
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t285 = getelementptr %"compiler/load:Loader", ptr %t283, i32 0, i32 7
  %t286 = load i64, ptr %t285, !tbaa !24
  %t289 = icmp eq i64 %t282, %t286
  br i1 %t289, label %bb52, label %bb53
bb52:
  call void @__olang_scope_close(ptr %s8)
  br label %bb137
bb53:
  br label %bb54
bb54:
  %t291 = load i64, ptr %l4, !tbaa !24
  store i64 %t291, ptr %l168, !tbaa !24
  %t292 = load i64, ptr %l168, !tbaa !24
  %t293 = icmp sge i64 %t292, 0
  br i1 %t293, label %bb55, label %bb56
bb55:
  %t295 = load i64, ptr %l168, !tbaa !24
  %t296 = mul i64 %t295, 1
  %t297 = call ptr @__olang_scope_alloc_zeroed(ptr %s8, i64 %t296)
  %t298 = insertvalue { i64, ptr } undef, i64 %t295, 0
  %t299 = insertvalue { i64, ptr } %t298, ptr %t297, 1
  store { i64, ptr } %t299, ptr %l23, !tbaa !27
  %t301 = load ptr, ptr @__olang_prog_scope
  %t302 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t301)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t302, ptr %l171
  br label %bb57
bb56:
  call void @__olang_check_failed(ptr @.c175)
  unreachable
bb57:
  %t303 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l171
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t303, ptr %l24
  %t304 = load ptr, ptr @__olang_prog_scope
  %t305 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t304)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t305, ptr %l172
  br label %bb58
bb58:
  %t306 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l172
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t306, ptr %l25
  %t307 = load i64, ptr %l22, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s8, ptr %l25, i64 %t307)
  br label %bb59
bb59:
  store i64 0, ptr %l26, !tbaa !24
  %t310 = load i64, ptr %l4, !tbaa !24
  store i64 %t310, ptr %l27, !tbaa !24
  store i64 1, ptr %l28, !tbaa !24
  %t312 = load i64, ptr %l27, !tbaa !24
  %t313 = load i64, ptr %l26, !tbaa !24
  %t316 = icmp sgt i64 %t312, %t313
  br i1 %t316, label %bb60, label %bb61
bb60:
  %t318 = load i64, ptr %l28, !tbaa !24
  %t320 = icmp sgt i64 %t318, 0
  br i1 %t320, label %bb62, label %bb63
bb61:
  store i64 0, ptr %l179, !tbaa !24
  br label %bb65
bb62:
  %t322 = load i64, ptr %l27, !tbaa !24
  %t323 = load i64, ptr %l26, !tbaa !24
  %t326 = sub i64 %t322, %t323
  %t327 = load i64, ptr %l28, !tbaa !24
  %t330 = add i64 %t326, %t327
  %t332 = sub i64 %t330, 1
  %t333 = load i64, ptr %l28, !tbaa !24
  %t336 = sdiv i64 %t332, %t333
  store i64 %t336, ptr %l182, !tbaa !24
  br label %bb64
bb63:
  store i64 0, ptr %l182, !tbaa !24
  br label %bb64
bb64:
  %t338 = load i64, ptr %l182, !tbaa !24
  store i64 %t338, ptr %l179, !tbaa !24
  br label %bb65
bb65:
  %t339 = load i64, ptr %l179, !tbaa !24
  store i64 %t339, ptr %l29, !tbaa !24
  store i64 0, ptr %l30, !tbaa !24
  br label %bb66
bb66:
  store %olang.scope zeroinitializer, ptr %s11
  %t340 = load i64, ptr %l30, !tbaa !24
  %t341 = load i64, ptr %l29, !tbaa !24
  %t344 = icmp slt i64 %t340, %t341
  %t346 = xor i1 %t344, true
  br i1 %t346, label %bb67, label %bb68
bb67:
  call void @__olang_scope_close(ptr %s11)
  br label %bb76
bb68:
  br label %bb69
bb69:
  %t348 = load i64, ptr %l26, !tbaa !24
  %t349 = load i64, ptr %l30, !tbaa !24
  %t350 = load i64, ptr %l28, !tbaa !24
  %t353 = mul i64 %t349, %t350
  %t356 = add i64 %t348, %t353
  store i64 %t356, ptr %l31, !tbaa !24
  %t358 = load i64, ptr %l31, !tbaa !24
  %t361 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %l3, i64 %t358)
  store ptr %t361, ptr %l202
  br label %bb70
bb70:
  %t362 = load ptr, ptr %l202, !tbaa !29
  %t364 = getelementptr %"compiler/load:Module", ptr %t362, i32 0, i32 3
  %t365 = load i1, ptr %t364, !tbaa !21
  br i1 %t365, label %bb71, label %bb72
bb71:
  %t367 = load i64, ptr %l31, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s8, ptr %l25, i64 %t367)
  br label %bb73
bb72:
  br label %bb74
bb73:
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s11)
  br label %bb75
bb75:
  %t370 = load i64, ptr %l30, !tbaa !24
  %t372 = add i64 %t370, 1
  store i64 %t372, ptr %l30, !tbaa !24
  br label %bb66
bb76:
  br label %bb77
bb77:
  store %olang.scope zeroinitializer, ptr %s14
  %t375 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %s8, ptr %l25)
  store i64 %t375, ptr %l210
  br label %bb78
bb78:
  %t376 = load i64, ptr %l210, !tbaa !24
  %t377 = icmp sgt i64 %t376, 0
  %t379 = xor i1 %t377, true
  br i1 %t379, label %bb79, label %bb80
bb79:
  call void @__olang_scope_close(ptr %s14)
  br label %bb114
bb80:
  br label %bb81
bb81:
  %t382 = call { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %s8, ptr %l25)
  %t383 = extractvalue { i32, i64 } %t382, 1
  %t384 = extractvalue { i32, i64 } %t382, 0
  store i32 %t384, ptr %l216
  %t385 = icmp ne i32 %t384, 0
  br i1 %t385, label %bb83, label %ok.386
ok.386:
  store i64 %t383, ptr %l215
  br label %bb82
bb82:
  %t387 = load i64, ptr %l215, !tbaa !24
  store i64 %t387, ptr %l213, !tbaa !24
  br label %bb85
bb83:
  br label %bb84
bb84:
  call void @__olang_scope_close(ptr %s14)
  br label %bb114
bb85:
  %t388 = load i64, ptr %l213, !tbaa !24
  store i64 %t388, ptr %l32, !tbaa !24
  %t389 = load i64, ptr %l32, !tbaa !24
  %t391 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t392 = load ptr, ptr %t391, !tbaa !27
  %t393 = getelementptr i1, ptr %t392, i64 %t389
  %t394 = load i1, ptr %t393, !tbaa !31
  br i1 %t394, label %bb86, label %bb87
bb86:
  call void @__olang_scope_close(ptr %s14)
  br label %bb113
bb87:
  br label %bb88
bb88:
  %t396 = load i64, ptr %l32, !tbaa !24
  %t398 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t399 = load ptr, ptr %t398, !tbaa !27
  %t400 = getelementptr i1, ptr %t399, i64 %t396
  store i1 true, ptr %t400, !tbaa !31
  %t401 = load i64, ptr %l32, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s8, ptr %l24, i64 %t401)
  br label %bb89
bb89:
  %t404 = load i64, ptr %l32, !tbaa !24
  %t407 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %l3, i64 %t404)
  store ptr %t407, ptr %l224
  br label %bb90
bb90:
  %t408 = load ptr, ptr %l224, !tbaa !29
  %t410 = getelementptr %"compiler/load:Module", ptr %t408, i32 0, i32 10
  store ptr %t410, ptr %l33, !tbaa !29
  store i64 0, ptr %l34, !tbaa !24
  br label %bb91
bb91:
  store %olang.scope zeroinitializer, ptr %s18
  %t412 = load ptr, ptr %l33, !tbaa !29
  %t413 = load i64, ptr %l34, !tbaa !24
  %t416 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2eRunFrom_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %t412, i64 %t413)
  %t417 = extractvalue { i32, { i64, ptr } } %t416, 1
  %t418 = extractvalue { i32, { i64, ptr } } %t416, 0
  store i32 %t418, ptr %l231
  %t419 = icmp ne i32 %t418, 0
  br i1 %t419, label %bb93, label %ok.420
ok.420:
  store { i64, ptr } %t417, ptr %l230
  br label %bb92
bb92:
  %t421 = load { i64, ptr }, ptr %l230, !tbaa !27
  store { i64, ptr } %t421, ptr %l227, !tbaa !27
  br label %bb97
bb93:
  %t422 = load i32, ptr %l231, !tbaa !23
  %t423 = ashr i32 %t422, 16
  %t425 = icmp eq i32 %t423, 1
  br i1 %t425, label %bb94, label %bb95
bb94:
  br label %bb96
bb95:
  call void @__olang_check_failed(ptr @.c176)
  unreachable
bb96:
  call void @__olang_scope_close(ptr %s18)
  br label %bb112
bb97:
  %t427 = load { i64, ptr }, ptr %l227, !tbaa !27
  store { i64, ptr } %t427, ptr %l35, !tbaa !27
  %t428 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t430 = extractvalue { i64, ptr } %t428, 0
  store i64 %t430, ptr %l36, !tbaa !24
  store i64 0, ptr %l37, !tbaa !24
  br label %bb98
bb98:
  store %olang.scope zeroinitializer, ptr %s19
  %t432 = load i64, ptr %l37, !tbaa !24
  %t433 = load i64, ptr %l36, !tbaa !24
  %t436 = icmp slt i64 %t432, %t433
  %t438 = xor i1 %t436, true
  br i1 %t438, label %bb99, label %bb100
bb99:
  call void @__olang_scope_close(ptr %s19)
  br label %bb110
bb100:
  br label %bb101
bb101:
  %t440 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t440, ptr %l240, !tbaa !27
  %t441 = load i64, ptr %l37, !tbaa !24
  %t443 = getelementptr { i64, ptr }, ptr %l240, i32 0, i32 1
  %t444 = load ptr, ptr %t443, !tbaa !27
  %t445 = getelementptr %"compiler/load:Import", ptr %t444, i64 %t441
  %t446 = load %"compiler/load:Import", ptr %t445
  store %"compiler/load:Import" %t446, ptr %l38
  %t448 = getelementptr %"compiler/load:Import", ptr %l38, i32 0, i32 5
  %t449 = load i64, ptr %t448, !tbaa !24
  %t451 = icmp sge i64 %t449, 0
  br i1 %t451, label %bb102, label %bb103
bb102:
  %t453 = getelementptr %"compiler/load:Import", ptr %l38, i32 0, i32 5
  %t454 = load i64, ptr %t453, !tbaa !24
  %t456 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t457 = load ptr, ptr %t456, !tbaa !27
  %t458 = getelementptr i1, ptr %t457, i64 %t454
  %t459 = load i1, ptr %t458, !tbaa !31
  %t461 = xor i1 %t459, true
  store i1 %t461, ptr %l245, !tbaa !21
  br label %bb104
bb103:
  store i1 false, ptr %l245, !tbaa !21
  br label %bb104
bb104:
  %t463 = load i1, ptr %l245, !tbaa !21
  br i1 %t463, label %bb105, label %bb106
bb105:
  %t464 = getelementptr %"compiler/load:Import", ptr %l38, i32 0, i32 5
  %t465 = load i64, ptr %t464, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s8, ptr %l25, i64 %t465)
  br label %bb107
bb106:
  br label %bb108
bb107:
  br label %bb108
bb108:
  call void @__olang_scope_close(ptr %s19)
  br label %bb109
bb109:
  %t468 = load i64, ptr %l37, !tbaa !24
  %t470 = add i64 %t468, 1
  store i64 %t470, ptr %l37, !tbaa !24
  br label %bb98
bb110:
  %t472 = load i64, ptr %l34, !tbaa !24
  %t473 = load i64, ptr %l36, !tbaa !24
  %t476 = add i64 %t472, %t473
  store i64 %t476, ptr %l34, !tbaa !24
  call void @__olang_scope_close(ptr %s18)
  br label %bb111
bb111:
  br label %bb91
bb112:
  call void @__olang_scope_close(ptr %s14)
  br label %bb113
bb113:
  br label %bb77
bb114:
  %t478 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_177, 0
  %t479 = insertvalue { ptr, ptr } %t478, ptr null, 1
  %t482 = extractvalue { ptr, ptr } %t479, 0
  %t483 = extractvalue { ptr, ptr } %t479, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSort_3cI64_3e(ptr %s8, ptr %s8, ptr %l24, ptr %t482, ptr %t483)
  br label %bb115
bb115:
  %t484 = load ptr, ptr @__olang_prog_scope
  %t485 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t484)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t485, ptr %l258
  br label %bb116
bb116:
  %t486 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l258
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t486, ptr %l39
  %t487 = load { i64, ptr }, ptr %l7, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s8, ptr %s0, ptr %l39, { i64, ptr } %t487)
  br label %bb117
bb117:
  %t490 = load i64, ptr %l22, !tbaa !24
  %t492 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t493 = load ptr, ptr %t492, !tbaa !27
  %t494 = getelementptr { i64, ptr }, ptr %t493, i64 %t490
  %t495 = load { i64, ptr }, ptr %t494, !tbaa !37
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s8, ptr %s0, ptr %l39, { i64, ptr } %t495)
  br label %bb118
bb118:
  store ptr %l24, ptr %l40, !tbaa !29
  store i64 0, ptr %l41, !tbaa !24
  br label %bb119
bb119:
  store %olang.scope zeroinitializer, ptr %s23
  %t499 = load ptr, ptr %l40, !tbaa !29
  %t500 = load i64, ptr %l41, !tbaa !24
  %t503 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %s8, ptr %t499, i64 %t500)
  %t504 = extractvalue { i32, { i64, ptr } } %t503, 1
  %t505 = extractvalue { i32, { i64, ptr } } %t503, 0
  store i32 %t505, ptr %l269
  %t506 = icmp ne i32 %t505, 0
  br i1 %t506, label %bb121, label %ok.507
ok.507:
  store { i64, ptr } %t504, ptr %l268
  br label %bb120
bb120:
  %t508 = load { i64, ptr }, ptr %l268, !tbaa !27
  store { i64, ptr } %t508, ptr %l265, !tbaa !27
  br label %bb125
bb121:
  %t509 = load i32, ptr %l269, !tbaa !23
  %t510 = ashr i32 %t509, 16
  %t512 = icmp eq i32 %t510, 1
  br i1 %t512, label %bb122, label %bb123
bb122:
  br label %bb124
bb123:
  call void @__olang_check_failed(ptr @.c178)
  unreachable
bb124:
  call void @__olang_scope_close(ptr %s23)
  br label %bb135
bb125:
  %t514 = load { i64, ptr }, ptr %l265, !tbaa !27
  store { i64, ptr } %t514, ptr %l42, !tbaa !27
  %t515 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t517 = extractvalue { i64, ptr } %t515, 0
  store i64 %t517, ptr %l43, !tbaa !24
  store i64 0, ptr %l44, !tbaa !24
  br label %bb126
bb126:
  store %olang.scope zeroinitializer, ptr %s24
  %t519 = load i64, ptr %l44, !tbaa !24
  %t520 = load i64, ptr %l43, !tbaa !24
  %t523 = icmp slt i64 %t519, %t520
  %t525 = xor i1 %t523, true
  br i1 %t525, label %bb127, label %bb128
bb127:
  call void @__olang_scope_close(ptr %s24)
  br label %bb133
bb128:
  br label %bb129
bb129:
  %t527 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t527, ptr %l278, !tbaa !27
  %t528 = load i64, ptr %l44, !tbaa !24
  %t530 = getelementptr { i64, ptr }, ptr %l278, i32 0, i32 1
  %t531 = load ptr, ptr %t530, !tbaa !27
  %t532 = getelementptr i64, ptr %t531, i64 %t528
  %t533 = load i64, ptr %t532, !tbaa !34
  store i64 %t533, ptr %l45, !tbaa !24
  store ptr %l39, ptr %l281, !tbaa !29
  %t535 = load i64, ptr %l45, !tbaa !24
  %t538 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %l3, i64 %t535)
  store ptr %t538, ptr %l284
  br label %bb130
bb130:
  %t539 = load ptr, ptr %l284, !tbaa !29
  %t541 = getelementptr %"compiler/load:Module", ptr %t539, i32 0, i32 2
  %t542 = load { i64, ptr }, ptr %t541, !tbaa !27
  %t543 = load i64, ptr %l45, !tbaa !24
  %t545 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t546 = load ptr, ptr %t545, !tbaa !27
  %t547 = getelementptr { i64, ptr }, ptr %t546, i64 %t543
  %t548 = load { i64, ptr }, ptr %t547, !tbaa !37
  %t550 = extractvalue { i64, ptr } %t542, 1
  %t551 = extractvalue { i64, ptr } %t542, 0
  %t552 = extractvalue { i64, ptr } { i64 1, ptr @.d179 }, 1
  %t553 = extractvalue { i64, ptr } { i64 1, ptr @.d179 }, 0
  %t554 = add i64 %t551, %t553
  %t556 = extractvalue { i64, ptr } %t548, 1
  %t557 = extractvalue { i64, ptr } %t548, 0
  %t558 = add i64 %t554, %t557
  %t559 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t558)
  call void @olang_textcopy(ptr %t559, ptr %t550, i64 %t551)
  %t560 = getelementptr i8, ptr %t559, i64 %t551
  call void @olang_textcopy(ptr %t560, ptr %t552, i64 %t553)
  %t561 = getelementptr i8, ptr %t560, i64 %t553
  call void @olang_textcopy(ptr %t561, ptr %t556, i64 %t557)
  %t562 = insertvalue { i64, ptr } undef, i64 %t558, 0
  %t563 = insertvalue { i64, ptr } %t562, ptr %t559, 1
  %t565 = extractvalue { i64, ptr } %t563, 0
  %t566 = extractvalue { i64, ptr } %t563, 1
  %t567 = mul i64 %t565, 1
  %t568 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t567)
  call void @llvm.memcpy.p0.p0.i64(ptr %t568, ptr %t566, i64 %t567, i1 false)
  %t569 = insertvalue { i64, ptr } undef, i64 %t565, 0
  %t570 = insertvalue { i64, ptr } %t569, ptr %t568, 1
  %t571 = load ptr, ptr %l281, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s8, ptr %s8, ptr %t571, { i64, ptr } %t570)
  br label %bb131
bb131:
  call void @__olang_scope_close(ptr %s24)
  br label %bb132
bb132:
  %t573 = load i64, ptr %l44, !tbaa !24
  %t575 = add i64 %t573, 1
  store i64 %t575, ptr %l44, !tbaa !24
  br label %bb126
bb133:
  %t577 = load i64, ptr %l41, !tbaa !24
  %t578 = load i64, ptr %l43, !tbaa !24
  %t581 = add i64 %t577, %t578
  store i64 %t581, ptr %l41, !tbaa !24
  call void @__olang_scope_close(ptr %s23)
  br label %bb134
bb134:
  br label %bb119
bb135:
  %t583 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t583, ptr %l296, !tbaa !27
  %t584 = load i64, ptr %l22, !tbaa !24
  store i64 %t584, ptr %l297, !tbaa !24
  %t586 = call { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %s8, ptr %v1, ptr %l39)
  store { i64, ptr } %t586, ptr %l299
  br label %bb136
bb136:
  %t587 = load { i64, ptr }, ptr %l299, !tbaa !27
  %t588 = extractvalue { i64, ptr } %t587, 0
  %t589 = extractvalue { i64, ptr } %t587, 1
  %t590 = mul i64 %t588, 1
  %t591 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t590)
  call void @llvm.memcpy.p0.p0.i64(ptr %t591, ptr %t589, i64 %t590, i1 false)
  %t592 = insertvalue { i64, ptr } undef, i64 %t588, 0
  %t593 = insertvalue { i64, ptr } %t592, ptr %t591, 1
  %t595 = load i64, ptr %l297, !tbaa !24
  %t596 = getelementptr { i64, ptr }, ptr %l296, i32 0, i32 1
  %t597 = load ptr, ptr %t596, !tbaa !27
  %t598 = getelementptr { i64, ptr }, ptr %t597, i64 %t595
  store { i64, ptr } %t593, ptr %t598, !tbaa !37
  call void @__olang_scope_close(ptr %s8)
  br label %bb137
bb137:
  %t599 = load i64, ptr %l21, !tbaa !24
  %t601 = add i64 %t599, 1
  store i64 %t601, ptr %l21, !tbaa !24
  br label %bb48
bb138:
  %t603 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t603, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2folang_2eplacement(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l7 = alloca %"compiler/scope:Scoper"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %t9 = alloca %"compiler/scope:Scoper", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 4
  %t8 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t7
  call void @compiler_2fscope_3aScoper_2ector(ptr %t9, ptr %v0, ptr %v0, ptr %v1, ptr %t4, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t8)
  call void @llvm.memmove.p0.p0.i64(ptr %l7, ptr %t9, i64 992, i1 false)
  br label %bb1
bb1:
  %t12 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 992, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t12, ptr %l7, i64 992, i1 false)
  store ptr %t12, ptr %l2, !tbaa !29
  %t14 = load ptr, ptr %l2, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr { ptr, ptr }, ptr null, i32 1
  %t17 = ptrtoint ptr %t16 to i64
  %t18 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 %t17, i64 8)
  %t19 = getelementptr { ptr, ptr }, ptr %t18, i32 0, i32 0
  store ptr %t15, ptr %t19, !tbaa !28
  call void @__olang_scope_escape(ptr %v0)
  %t21 = getelementptr { ptr, ptr }, ptr %t18, i32 0, i32 1
  store ptr %v0, ptr %t21, !tbaa !28
  %t22 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_180, 0
  %t23 = insertvalue { ptr, ptr } %t22, ptr %t18, 1
  %t26 = getelementptr %"compiler/scope:Scoper", ptr %t14, i32 0, i32 4
  store { ptr, ptr } %t23, ptr %t26
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr { ptr, ptr }, ptr null, i32 1
  %t30 = ptrtoint ptr %t29 to i64
  %t31 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 %t30, i64 8)
  %t32 = getelementptr { ptr, ptr }, ptr %t31, i32 0, i32 0
  store ptr %t28, ptr %t32, !tbaa !28
  call void @__olang_scope_escape(ptr %v0)
  %t34 = getelementptr { ptr, ptr }, ptr %t31, i32 0, i32 1
  store ptr %v0, ptr %t34, !tbaa !28
  %t35 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_181, 0
  %t36 = insertvalue { ptr, ptr } %t35, ptr %t31, 1
  %t39 = getelementptr %"compiler/scope:Scoper", ptr %t27, i32 0, i32 5
  store { ptr, ptr } %t36, ptr %t39
  %t40 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eRun(ptr %v1, ptr %t40)
  br label %bb2
bb2:
  %t42 = load ptr, ptr %l2, !tbaa !29
  %t44 = getelementptr %"compiler/scope:Scoper", ptr %t42, i32 0, i32 2
  %t45 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t44
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t45, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local i1 @compiler_2folang_2eputFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1, i32 %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l10 = alloca i32
  %l16 = alloca i32
  %l20 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t1, 1
  %t5 = extractvalue { i64, ptr } %t1, 0
  %t6 = extractvalue { i64, ptr } { i64 1, ptr @.d182 }, 1
  %t7 = extractvalue { i64, ptr } { i64 1, ptr @.d182 }, 0
  %t8 = add i64 %t5, %t7
  %t10 = sext i32 %a2 to i64
  %t11 = call i64 @__olang_fmt_i64(ptr null, i64 %t10)
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 4, ptr @.d183 }, 1
  %t14 = extractvalue { i64, ptr } { i64 4, ptr @.d183 }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t4, i64 %t5)
  %t17 = getelementptr i8, ptr %t16, i64 %t5
  call void @olang_textcopy(ptr %t17, ptr %t6, i64 %t7)
  %t18 = getelementptr i8, ptr %t17, i64 %t7
  %t19 = call i64 @__olang_fmt_i64(ptr %t18, i64 %t10)
  %t20 = getelementptr i8, ptr %t18, i64 %t11
  call void @olang_textcopy(ptr %t20, ptr %t13, i64 %t14)
  %t21 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t16, 1
  store { i64, ptr } %t22, ptr %l3, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t29 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %v1, { i64, ptr } %t24, { i64, ptr } %a1)
  store i32 %t29, ptr %l10
  %t30 = icmp ne i32 %t29, 0
  br i1 %t30, label %bb2, label %ok.31
ok.31:
  br label %bb1
bb1:
  br label %bb6
bb2:
  %t32 = load i32, ptr %l10, !tbaa !23
  %t33 = ashr i32 %t32, 16
  %t35 = icmp eq i32 %t33, 1
  br i1 %t35, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @.c184)
  unreachable
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb6:
  %t38 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t42 = call i32 @std_2fos_2eRename(ptr %s0, ptr %v0, { i64, ptr } %t38, { i64, ptr } %t39)
  store i32 %t42, ptr %l16
  %t43 = icmp ne i32 %t42, 0
  br i1 %t43, label %bb8, label %ok.44
ok.44:
  br label %bb7
bb7:
  br label %bb18
bb8:
  %t45 = load i32, ptr %l16, !tbaa !23
  %t46 = ashr i32 %t45, 16
  %t48 = icmp eq i32 %t46, 1
  br i1 %t48, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @.c185)
  unreachable
bb11:
  %t50 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t52 = call i32 @std_2fos_2eRemove(ptr %s0, { i64, ptr } %t50)
  store i32 %t52, ptr %l20
  %t53 = icmp ne i32 %t52, 0
  br i1 %t53, label %bb13, label %ok.54
ok.54:
  br label %bb12
bb12:
  br label %bb17
bb13:
  %t55 = load i32, ptr %l20, !tbaa !23
  %t56 = ashr i32 %t55, 16
  %t58 = icmp eq i32 %t56, 1
  br i1 %t58, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @.c186)
  unreachable
bb16:
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb18:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2folang_2erecordPath(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/build:Config", ptr %a0, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l4, !tbaa !27
  %t7 = call { i64, ptr } @compiler_2fbuild_2eReadable(ptr %v1, ptr %s0, { i64, ptr } %a1)
  store { i64, ptr } %t7, ptr %l6
  br label %bb1
bb1:
  store { i64, ptr } %a2, ptr %l7, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t9, 0
  store i64 %t10, ptr %l8, !tbaa !24
  %t11 = icmp sge i64 0, 0
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = icmp sle i64 0, 20
  br i1 %t13, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @.c187)
  unreachable
bb4:
  %t15 = load i64, ptr %l8, !tbaa !24
  %t16 = icmp sle i64 20, %t15
  br i1 %t16, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @.c187)
  unreachable
bb6:
  %t18 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i8, ptr %t19, i64 0
  %t21 = sub i64 20, 0
  %t22 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t20, 1
  %t24 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t24, 1
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t27 = extractvalue { i64, ptr } { i64 5, ptr @.d188 }, 1
  %t28 = extractvalue { i64, ptr } { i64 5, ptr @.d188 }, 0
  %t29 = add i64 %t26, %t28
  %t30 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t30, 1
  %t32 = extractvalue { i64, ptr } %t30, 0
  %t33 = add i64 %t29, %t32
  %t34 = extractvalue { i64, ptr } { i64 1, ptr @.d189 }, 1
  %t35 = extractvalue { i64, ptr } { i64 1, ptr @.d189 }, 0
  %t36 = add i64 %t33, %t35
  %t38 = extractvalue { i64, ptr } %t23, 1
  %t39 = extractvalue { i64, ptr } %t23, 0
  %t40 = add i64 %t36, %t39
  %t41 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t40)
  call void @olang_textcopy(ptr %t41, ptr %t25, i64 %t26)
  %t42 = getelementptr i8, ptr %t41, i64 %t26
  call void @olang_textcopy(ptr %t42, ptr %t27, i64 %t28)
  %t43 = getelementptr i8, ptr %t42, i64 %t28
  call void @olang_textcopy(ptr %t43, ptr %t31, i64 %t32)
  %t44 = getelementptr i8, ptr %t43, i64 %t32
  call void @olang_textcopy(ptr %t44, ptr %t34, i64 %t35)
  %t45 = getelementptr i8, ptr %t44, i64 %t35
  call void @olang_textcopy(ptr %t45, ptr %t38, i64 %t39)
  %t46 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t41, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t47, ptr %rv
  br label %ret
bb7:
  call void @__olang_check_failed(ptr @.c187)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2folang_2ereusable(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %lp3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %lp12 = alloca ptr
  %l13 = alloca i1
  %l14 = alloca %"std/prelude/text:LineIter"
  %l15 = alloca { i64, ptr }
  %l16 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l22 = alloca i64
  %l25 = alloca i64
  %l43 = alloca { i64, ptr }
  %l46 = alloca i1
  %l47 = alloca ptr
  %l51 = alloca ptr
  %l54 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l61 = alloca i32
  %l65 = alloca %"compiler/emit:Reused"
  %l67 = alloca %"std/prelude/text:LineIter"
  %l68 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l71 = alloca i32
  %l75 = alloca i1
  %l77 = alloca i1
  %l78 = alloca i64
  %l79 = alloca { i64, ptr }
  %l82 = alloca i64
  %l83 = alloca i64
  %l87 = alloca { i64, ptr }
  %l88 = alloca i64
  %l89 = alloca i32
  %l90 = alloca i64
  %l91 = alloca i32
  %l93 = alloca i1
  %l94 = alloca { i64, ptr }
  %l97 = alloca i64
  %l98 = alloca i64
  %l103 = alloca i1
  %l105 = alloca i1
  %l106 = alloca ptr
  %l107 = alloca { i64, ptr }
  %l110 = alloca i64
  %l111 = alloca i64
  %l119 = alloca i1
  %l123 = alloca i1
  %l124 = alloca { i64, ptr }
  %l127 = alloca i1
  %l128 = alloca { i64, ptr }
  %l130 = alloca i64
  %l133 = alloca i1
  %l135 = alloca ptr
  %l136 = alloca { i64, ptr }
  %l137 = alloca i64
  %l144 = alloca ptr
  %l145 = alloca { i64, ptr }
  %l148 = alloca i64
  %l149 = alloca i64
  %l157 = alloca i1
  %l159 = alloca i64
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aReused_3e(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l16
  br label %bb1
bb1:
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 8, i64 8)
  store ptr %t3, ptr %lp3
  %t4 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l16
  %t5 = load ptr, ptr %lp3
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %t5
  store i64 0, ptr %l4, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t10 = load i64, ptr %l5, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp sgt i64 %t10, %t11
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load i64, ptr %l6, !tbaa !24
  %t18 = icmp sgt i64 %t16, 0
  br i1 %t18, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb7
bb4:
  %t20 = load i64, ptr %l5, !tbaa !24
  %t21 = load i64, ptr %l4, !tbaa !24
  %t24 = sub i64 %t20, %t21
  %t25 = load i64, ptr %l6, !tbaa !24
  %t28 = add i64 %t24, %t25
  %t30 = sub i64 %t28, 1
  %t31 = load i64, ptr %l6, !tbaa !24
  %t34 = sdiv i64 %t30, %t31
  store i64 %t34, ptr %l25, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb6
bb6:
  %t36 = load i64, ptr %l25, !tbaa !24
  store i64 %t36, ptr %l22, !tbaa !24
  br label %bb7
bb7:
  %t37 = load i64, ptr %l22, !tbaa !24
  store i64 %t37, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t38 = load i64, ptr %l8, !tbaa !24
  %t39 = load i64, ptr %l7, !tbaa !24
  %t42 = icmp slt i64 %t38, %t39
  %t44 = xor i1 %t42, true
  br i1 %t44, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb115
bb10:
  br label %bb11
bb11:
  %t46 = load i64, ptr %l4, !tbaa !24
  %t47 = load i64, ptr %l8, !tbaa !24
  %t48 = load i64, ptr %l6, !tbaa !24
  %t51 = mul i64 %t47, %t48
  %t54 = add i64 %t46, %t51
  store i64 %t54, ptr %l9, !tbaa !24
  %t56 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t56, ptr %l43, !tbaa !27
  %t57 = load i64, ptr %l9, !tbaa !24
  %t59 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr { i64, ptr }, ptr %t60, i64 %t57
  %t62 = load { i64, ptr }, ptr %t61, !tbaa !37
  %t64 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s2, { i64, ptr } %t62, { i64, ptr } { i64 0, ptr @.d190 })
  store i1 %t64, ptr %l46
  br label %bb12
bb12:
  %t65 = load i1, ptr %l46, !tbaa !21
  br i1 %t65, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb114
bb14:
  br label %bb15
bb15:
  store ptr %a1, ptr %l47, !tbaa !29
  %t69 = getelementptr %"compiler/load:Loader", ptr %a0, i32 0, i32 5
  %t70 = load i64, ptr %l9, !tbaa !24
  %t73 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t69, i64 %t70)
  store ptr %t73, ptr %l51
  br label %bb16
bb16:
  %t74 = load ptr, ptr %l51, !tbaa !29
  %t76 = getelementptr %"compiler/load:Module", ptr %t74, i32 0, i32 2
  %t77 = load { i64, ptr }, ptr %t76, !tbaa !27
  %t78 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t78, ptr %l54, !tbaa !27
  %t79 = load i64, ptr %l9, !tbaa !24
  %t81 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr { i64, ptr }, ptr %t82, i64 %t79
  %t84 = load { i64, ptr }, ptr %t83, !tbaa !37
  %t85 = load ptr, ptr %l47, !tbaa !29
  %t88 = call { i64, ptr } @compiler_2folang_2erecordPath(ptr %v1, ptr %v0, ptr %v2, ptr %s2, ptr %t85, { i64, ptr } %t77, { i64, ptr } %t84)
  store { i64, ptr } %t88, ptr %l57
  br label %bb17
bb17:
  %t89 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t89, ptr %l10, !tbaa !27
  %t90 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t92 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s2, ptr %s2, { i64, ptr } %t90)
  %t93 = extractvalue { i32, { i64, ptr } } %t92, 1
  %t94 = extractvalue { i32, { i64, ptr } } %t92, 0
  store i32 %t94, ptr %l61
  %t95 = icmp ne i32 %t94, 0
  br i1 %t95, label %bb19, label %ok.96
ok.96:
  store { i64, ptr } %t93, ptr %l60
  br label %bb18
bb18:
  %t97 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t97, ptr %l58, !tbaa !27
  br label %bb23
bb19:
  %t98 = load i32, ptr %l61, !tbaa !23
  %t99 = ashr i32 %t98, 16
  %t101 = icmp eq i32 %t99, 1
  br i1 %t101, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @.c191)
  unreachable
bb22:
  call void @__olang_scope_close(ptr %s2)
  br label %bb114
bb23:
  %t103 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t103, ptr %l11, !tbaa !27
  %t104 = load i64, ptr %l9, !tbaa !24
  %t106 = call %"compiler/emit:Reused" @compiler_2femit_3aReused_2ector(ptr %v3, i64 %t104)
  store %"compiler/emit:Reused" %t106, ptr %l65
  br label %bb24
bb24:
  %t107 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 56, i64 8)
  store ptr %t107, ptr %lp12
  %t108 = load %"compiler/emit:Reused", ptr %l65
  %t109 = load ptr, ptr %lp12
  store %"compiler/emit:Reused" %t108, ptr %t109
  store i1 false, ptr %l13, !tbaa !21
  %t110 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t112 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %s2, ptr %s2, { i64, ptr } %t110)
  store %"std/prelude/text:LineIter" %t112, ptr %l67
  br label %bb25
bb25:
  %t113 = load %"std/prelude/text:LineIter", ptr %l67
  store %"std/prelude/text:LineIter" %t113, ptr %l14
  br label %bb26
bb26:
  store %olang.scope zeroinitializer, ptr %s6
  %t115 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %s2, ptr %l14)
  %t116 = extractvalue { i32, { i64, ptr } } %t115, 1
  %t117 = extractvalue { i32, { i64, ptr } } %t115, 0
  store i32 %t117, ptr %l71
  %t118 = icmp ne i32 %t117, 0
  br i1 %t118, label %bb28, label %ok.119
ok.119:
  store { i64, ptr } %t116, ptr %l70
  br label %bb27
bb27:
  %t120 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t120, ptr %l68, !tbaa !27
  br label %bb32
bb28:
  %t121 = load i32, ptr %l71, !tbaa !23
  %t122 = ashr i32 %t121, 16
  %t124 = icmp eq i32 %t122, 1
  br i1 %t124, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  call void @__olang_check_failed(ptr @.c192)
  unreachable
bb31:
  call void @__olang_scope_close(ptr %s6)
  br label %bb105
bb32:
  %t126 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t126, ptr %l15, !tbaa !27
  %t127 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t129 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s6, { i64, ptr } %t127, { i64, ptr } { i64 3, ptr @.d193 })
  store i1 %t129, ptr %l75
  br label %bb33
bb33:
  %t130 = load i1, ptr %l75, !tbaa !21
  br i1 %t130, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb103
bb35:
  store %olang.scope zeroinitializer, ptr %s8
  %t131 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t133 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s2, ptr %s8, { i64, ptr } %t131, { i64, ptr } { i64 5, ptr @.d194 })
  store i1 %t133, ptr %l77
  br label %bb36
bb36:
  %t134 = load i1, ptr %l77, !tbaa !21
  br i1 %t134, label %bb37, label %bb38
bb37:
  store %olang.scope zeroinitializer, ptr %s9
  %t135 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t135, ptr %l79, !tbaa !27
  %t136 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t139 = extractvalue { i64, ptr } %t136, 0
  store i64 %t139, ptr %l82, !tbaa !24
  %t140 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t141 = extractvalue { i64, ptr } %t140, 0
  store i64 %t141, ptr %l83, !tbaa !24
  %t142 = icmp sge i64 5, 0
  br i1 %t142, label %bb39, label %bb40
bb38:
  store %olang.scope zeroinitializer, ptr %s10
  %t144 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t146 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s2, ptr %s10, { i64, ptr } %t144, { i64, ptr } { i64 6, ptr @.d195 })
  store i1 %t146, ptr %l93
  br label %bb51
bb39:
  %t147 = load i64, ptr %l82, !tbaa !24
  %t148 = icmp sle i64 5, %t147
  br i1 %t148, label %bb41, label %bb42
bb40:
  call void @__olang_check_failed(ptr @.c196)
  unreachable
bb41:
  %t150 = load i64, ptr %l82, !tbaa !24
  %t151 = load i64, ptr %l83, !tbaa !24
  %t152 = icmp sle i64 %t150, %t151
  br i1 %t152, label %bb43, label %bb44
bb42:
  call void @__olang_check_failed(ptr @.c196)
  unreachable
bb43:
  %t154 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !27
  %t156 = load i64, ptr %l82, !tbaa !24
  %t157 = getelementptr i8, ptr %t155, i64 5
  %t158 = sub i64 %t156, 5
  %t159 = insertvalue { i64, ptr } undef, i64 %t158, 0
  %t160 = insertvalue { i64, ptr } %t159, ptr %t157, 1
  store { i64, ptr } %t160, ptr %l87, !tbaa !27
  %t161 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s9, i64 10)
  %t162 = extractvalue { i32, i64 } %t161, 1
  %t163 = extractvalue { i32, i64 } %t161, 0
  store i32 %t163, ptr %l89
  %t164 = icmp ne i32 %t163, 0
  br i1 %t164, label %bb46, label %ok.165
ok.165:
  store i64 %t162, ptr %l88
  br label %bb45
bb44:
  call void @__olang_check_failed(ptr @.c196)
  unreachable
bb45:
  %t166 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t167 = load i64, ptr %l88, !tbaa !24
  %t168 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s2, { i64, ptr } %t166, i64 %t167)
  %t169 = extractvalue { i32, i64 } %t168, 1
  %t170 = extractvalue { i32, i64 } %t168, 0
  store i32 %t170, ptr %l91
  %t171 = icmp ne i32 %t170, 0
  br i1 %t171, label %bb49, label %ok.172
ok.172:
  store i64 %t169, ptr %l90
  br label %bb48
bb46:
  br label %bb47
bb47:
  store i64 0, ptr %l78, !tbaa !24
  br label %bb50
bb48:
  %t173 = load i64, ptr %l90, !tbaa !24
  store i64 %t173, ptr %l78, !tbaa !24
  br label %bb50
bb49:
  br label %bb47
bb50:
  %t174 = load i64, ptr %l78, !tbaa !24
  %t175 = load ptr, ptr %lp12
  %t176 = getelementptr %"compiler/emit:Reused", ptr %t175, i32 0, i32 3
  store i64 %t174, ptr %t176, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  br label %bb102
bb51:
  %t177 = load i1, ptr %l93, !tbaa !21
  br i1 %t177, label %bb52, label %bb53
bb52:
  store %olang.scope zeroinitializer, ptr %s11
  %t178 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t178, ptr %l94, !tbaa !27
  %t179 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t182 = extractvalue { i64, ptr } %t179, 0
  store i64 %t182, ptr %l97, !tbaa !24
  %t183 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t184 = extractvalue { i64, ptr } %t183, 0
  store i64 %t184, ptr %l98, !tbaa !24
  %t185 = icmp sge i64 6, 0
  br i1 %t185, label %bb54, label %bb55
bb53:
  store %olang.scope zeroinitializer, ptr %s12
  %t187 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t189 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s2, ptr %s12, { i64, ptr } %t187, { i64, ptr } { i64 5, ptr @.d197 })
  store i1 %t189, ptr %l105
  br label %bb61
bb54:
  %t190 = load i64, ptr %l97, !tbaa !24
  %t191 = icmp sle i64 6, %t190
  br i1 %t191, label %bb56, label %bb57
bb55:
  call void @__olang_check_failed(ptr @.c198)
  unreachable
bb56:
  %t193 = load i64, ptr %l97, !tbaa !24
  %t194 = load i64, ptr %l98, !tbaa !24
  %t195 = icmp sle i64 %t193, %t194
  br i1 %t195, label %bb58, label %bb59
bb57:
  call void @__olang_check_failed(ptr @.c198)
  unreachable
bb58:
  %t197 = getelementptr { i64, ptr }, ptr %l94, i32 0, i32 1
  %t198 = load ptr, ptr %t197, !tbaa !27
  %t199 = load i64, ptr %l97, !tbaa !24
  %t200 = getelementptr i8, ptr %t198, i64 6
  %t201 = sub i64 %t199, 6
  %t202 = insertvalue { i64, ptr } undef, i64 %t201, 0
  %t203 = insertvalue { i64, ptr } %t202, ptr %t200, 1
  %t205 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s11, { i64, ptr } %t203, { i64, ptr } { i64 1, ptr @.d199 })
  store i1 %t205, ptr %l103
  br label %bb60
bb59:
  call void @__olang_check_failed(ptr @.c198)
  unreachable
bb60:
  %t206 = load i1, ptr %l103, !tbaa !21
  %t207 = load ptr, ptr %lp12
  %t208 = getelementptr %"compiler/emit:Reused", ptr %t207, i32 0, i32 4
  store i1 %t206, ptr %t208, !tbaa !21
  call void @__olang_scope_close(ptr %s11)
  br label %bb101
bb61:
  %t209 = load i1, ptr %l105, !tbaa !21
  br i1 %t209, label %bb62, label %bb63
bb62:
  %t210 = load ptr, ptr %lp12
  %t211 = getelementptr %"compiler/emit:Reused", ptr %t210, i32 0, i32 5
  store ptr %t211, ptr %l106, !tbaa !29
  %t212 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t212, ptr %l107, !tbaa !27
  %t213 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t216 = extractvalue { i64, ptr } %t213, 0
  store i64 %t216, ptr %l110, !tbaa !24
  %t217 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t218 = extractvalue { i64, ptr } %t217, 0
  store i64 %t218, ptr %l111, !tbaa !24
  %t219 = icmp sge i64 5, 0
  br i1 %t219, label %bb64, label %bb65
bb63:
  store %olang.scope zeroinitializer, ptr %s15
  %t221 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t223 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s2, ptr %s15, { i64, ptr } %t221, { i64, ptr } { i64 5, ptr @.d200 })
  store i1 %t223, ptr %l119
  br label %bb71
bb64:
  %t224 = load i64, ptr %l110, !tbaa !24
  %t225 = icmp sle i64 5, %t224
  br i1 %t225, label %bb66, label %bb67
bb65:
  call void @__olang_check_failed(ptr @.c201)
  unreachable
bb66:
  %t227 = load i64, ptr %l110, !tbaa !24
  %t228 = load i64, ptr %l111, !tbaa !24
  %t229 = icmp sle i64 %t227, %t228
  br i1 %t229, label %bb68, label %bb69
bb67:
  call void @__olang_check_failed(ptr @.c201)
  unreachable
bb68:
  %t231 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t232 = load ptr, ptr %t231, !tbaa !27
  %t233 = load i64, ptr %l110, !tbaa !24
  %t234 = getelementptr i8, ptr %t232, i64 5
  %t235 = sub i64 %t233, 5
  %t236 = insertvalue { i64, ptr } undef, i64 %t235, 0
  %t237 = insertvalue { i64, ptr } %t236, ptr %t234, 1
  %t239 = extractvalue { i64, ptr } %t237, 1
  %t240 = extractvalue { i64, ptr } %t237, 0
  %t241 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t240)
  call void @olang_textcopy(ptr %t241, ptr %t239, i64 %t240)
  %t242 = insertvalue { i64, ptr } undef, i64 %t240, 0
  %t243 = insertvalue { i64, ptr } %t242, ptr %t241, 1
  %t245 = extractvalue { i64, ptr } %t243, 0
  %t246 = extractvalue { i64, ptr } %t243, 1
  %t247 = mul i64 %t245, 1
  %t248 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t247)
  call void @llvm.memcpy.p0.p0.i64(ptr %t248, ptr %t246, i64 %t247, i1 false)
  %t249 = insertvalue { i64, ptr } undef, i64 %t245, 0
  %t250 = insertvalue { i64, ptr } %t249, ptr %t248, 1
  %t251 = load ptr, ptr %l106, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v3, ptr %v3, ptr %t251, { i64, ptr } %t250)
  br label %bb70
bb69:
  call void @__olang_check_failed(ptr @.c201)
  unreachable
bb70:
  br label %bb100
bb71:
  %t253 = load i1, ptr %l119, !tbaa !21
  br i1 %t253, label %bb72, label %bb73
bb72:
  store %olang.scope zeroinitializer, ptr %s16
  %t254 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t256 = extractvalue { i64, ptr } %t254, 0
  %t258 = icmp slt i64 %t256, 71
  br i1 %t258, label %bb74, label %bb75
bb73:
  br label %bb99
bb74:
  store i1 true, ptr %l123, !tbaa !21
  br label %bb76
bb75:
  %t260 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t260, ptr %l124, !tbaa !27
  %t261 = getelementptr { i64, ptr }, ptr %l124, i32 0, i32 1
  %t262 = load ptr, ptr %t261, !tbaa !27
  %t263 = getelementptr i8, ptr %t262, i64 69
  %t264 = load i8, ptr %t263, !tbaa !32
  %t266 = icmp ne i8 %t264, 32
  store i1 %t266, ptr %l123, !tbaa !21
  br label %bb76
bb76:
  %t268 = load i1, ptr %l123, !tbaa !21
  br i1 %t268, label %bb77, label %bb78
bb77:
  store i1 true, ptr %l127, !tbaa !21
  br label %bb81
bb78:
  %t269 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t269, ptr %l128, !tbaa !27
  %t270 = load ptr, ptr %lp12
  %t271 = getelementptr %"compiler/emit:Reused", ptr %t270, i32 0, i32 1
  %t273 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v3, ptr %t271)
  store i64 %t273, ptr %l130
  br label %bb79
bb79:
  %t274 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t275 = extractvalue { i64, ptr } %t274, 1
  %t276 = extractvalue { i64, ptr } %t274, 0
  %t277 = extractvalue { i64, ptr } { i64 2, ptr @.d202 }, 1
  %t278 = extractvalue { i64, ptr } { i64 2, ptr @.d202 }, 0
  %t279 = add i64 %t276, %t278
  %t280 = load i64, ptr %l130, !tbaa !24
  %t281 = call i64 @__olang_fmt_i64(ptr null, i64 %t280)
  %t282 = add i64 %t279, %t281
  %t283 = extractvalue { i64, ptr } { i64 3, ptr @.d203 }, 1
  %t284 = extractvalue { i64, ptr } { i64 3, ptr @.d203 }, 0
  %t285 = add i64 %t282, %t284
  %t286 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t285)
  call void @olang_textcopy(ptr %t286, ptr %t275, i64 %t276)
  %t287 = getelementptr i8, ptr %t286, i64 %t276
  call void @olang_textcopy(ptr %t287, ptr %t277, i64 %t278)
  %t288 = getelementptr i8, ptr %t287, i64 %t278
  %t289 = call i64 @__olang_fmt_i64(ptr %t288, i64 %t280)
  %t290 = getelementptr i8, ptr %t288, i64 %t281
  call void @olang_textcopy(ptr %t290, ptr %t283, i64 %t284)
  %t291 = insertvalue { i64, ptr } undef, i64 %t285, 0
  %t292 = insertvalue { i64, ptr } %t291, ptr %t286, 1
  %t294 = extractvalue { i64, ptr } %t292, 0
  %t295 = extractvalue { i64, ptr } %t292, 1
  %t296 = mul i64 %t294, 1
  %t297 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t296)
  call void @llvm.memcpy.p0.p0.i64(ptr %t297, ptr %t295, i64 %t296, i1 false)
  %t298 = insertvalue { i64, ptr } undef, i64 %t294, 0
  %t299 = insertvalue { i64, ptr } %t298, ptr %t297, 1
  %t301 = call i1 @std_2fos_2eExists(ptr %s16, { i64, ptr } %t299)
  store i1 %t301, ptr %l133
  br label %bb80
bb80:
  %t302 = load i1, ptr %l133, !tbaa !21
  %t303 = xor i1 %t302, true
  store i1 %t303, ptr %l127, !tbaa !21
  br label %bb81
bb81:
  %t305 = load i1, ptr %l127, !tbaa !21
  br i1 %t305, label %bb82, label %bb83
bb82:
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s6)
  br label %bb105
bb83:
  br label %bb84
bb84:
  %t306 = load ptr, ptr %lp12
  %t307 = getelementptr %"compiler/emit:Reused", ptr %t306, i32 0, i32 2
  store ptr %t307, ptr %l135, !tbaa !29
  %t308 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t308, ptr %l136, !tbaa !27
  %t309 = load { i64, ptr }, ptr %l136, !tbaa !27
  %t310 = extractvalue { i64, ptr } %t309, 0
  store i64 %t310, ptr %l137, !tbaa !24
  %t311 = icmp sge i64 5, 0
  br i1 %t311, label %bb85, label %bb86
bb85:
  %t313 = icmp sle i64 5, 69
  br i1 %t313, label %bb87, label %bb88
bb86:
  call void @__olang_check_failed(ptr @.c204)
  unreachable
bb87:
  %t315 = load i64, ptr %l137, !tbaa !24
  %t316 = icmp sle i64 69, %t315
  br i1 %t316, label %bb89, label %bb90
bb88:
  call void @__olang_check_failed(ptr @.c204)
  unreachable
bb89:
  %t318 = getelementptr { i64, ptr }, ptr %l136, i32 0, i32 1
  %t319 = load ptr, ptr %t318, !tbaa !27
  %t320 = getelementptr i8, ptr %t319, i64 5
  %t321 = sub i64 69, 5
  %t322 = insertvalue { i64, ptr } undef, i64 %t321, 0
  %t323 = insertvalue { i64, ptr } %t322, ptr %t320, 1
  %t325 = extractvalue { i64, ptr } %t323, 1
  %t326 = extractvalue { i64, ptr } %t323, 0
  %t327 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t326)
  call void @olang_textcopy(ptr %t327, ptr %t325, i64 %t326)
  %t328 = insertvalue { i64, ptr } undef, i64 %t326, 0
  %t329 = insertvalue { i64, ptr } %t328, ptr %t327, 1
  %t331 = extractvalue { i64, ptr } %t329, 0
  %t332 = extractvalue { i64, ptr } %t329, 1
  %t333 = mul i64 %t331, 1
  %t334 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t333)
  call void @llvm.memcpy.p0.p0.i64(ptr %t334, ptr %t332, i64 %t333, i1 false)
  %t335 = insertvalue { i64, ptr } undef, i64 %t331, 0
  %t336 = insertvalue { i64, ptr } %t335, ptr %t334, 1
  %t337 = load ptr, ptr %l135, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v3, ptr %v3, ptr %t337, { i64, ptr } %t336)
  br label %bb91
bb90:
  call void @__olang_check_failed(ptr @.c204)
  unreachable
bb91:
  %t339 = load ptr, ptr %lp12
  %t340 = getelementptr %"compiler/emit:Reused", ptr %t339, i32 0, i32 1
  store ptr %t340, ptr %l144, !tbaa !29
  %t341 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t341, ptr %l145, !tbaa !27
  %t342 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t345 = extractvalue { i64, ptr } %t342, 0
  store i64 %t345, ptr %l148, !tbaa !24
  %t346 = load { i64, ptr }, ptr %l145, !tbaa !27
  %t347 = extractvalue { i64, ptr } %t346, 0
  store i64 %t347, ptr %l149, !tbaa !24
  %t348 = icmp sge i64 70, 0
  br i1 %t348, label %bb92, label %bb93
bb92:
  %t350 = load i64, ptr %l148, !tbaa !24
  %t351 = icmp sle i64 70, %t350
  br i1 %t351, label %bb94, label %bb95
bb93:
  call void @__olang_check_failed(ptr @.c205)
  unreachable
bb94:
  %t353 = load i64, ptr %l148, !tbaa !24
  %t354 = load i64, ptr %l149, !tbaa !24
  %t355 = icmp sle i64 %t353, %t354
  br i1 %t355, label %bb96, label %bb97
bb95:
  call void @__olang_check_failed(ptr @.c205)
  unreachable
bb96:
  %t357 = getelementptr { i64, ptr }, ptr %l145, i32 0, i32 1
  %t358 = load ptr, ptr %t357, !tbaa !27
  %t359 = load i64, ptr %l148, !tbaa !24
  %t360 = getelementptr i8, ptr %t358, i64 70
  %t361 = sub i64 %t359, 70
  %t362 = insertvalue { i64, ptr } undef, i64 %t361, 0
  %t363 = insertvalue { i64, ptr } %t362, ptr %t360, 1
  %t365 = extractvalue { i64, ptr } %t363, 1
  %t366 = extractvalue { i64, ptr } %t363, 0
  %t367 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t366)
  call void @olang_textcopy(ptr %t367, ptr %t365, i64 %t366)
  %t368 = insertvalue { i64, ptr } undef, i64 %t366, 0
  %t369 = insertvalue { i64, ptr } %t368, ptr %t367, 1
  %t371 = extractvalue { i64, ptr } %t369, 0
  %t372 = extractvalue { i64, ptr } %t369, 1
  %t373 = mul i64 %t371, 1
  %t374 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t373)
  call void @llvm.memcpy.p0.p0.i64(ptr %t374, ptr %t372, i64 %t373, i1 false)
  %t375 = insertvalue { i64, ptr } undef, i64 %t371, 0
  %t376 = insertvalue { i64, ptr } %t375, ptr %t374, 1
  %t377 = load ptr, ptr %l144, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v3, ptr %v3, ptr %t377, { i64, ptr } %t376)
  br label %bb98
bb97:
  call void @__olang_check_failed(ptr @.c205)
  unreachable
bb98:
  call void @__olang_scope_close(ptr %s16)
  br label %bb99
bb99:
  call void @__olang_scope_close(ptr %s15)
  br label %bb100
bb100:
  call void @__olang_scope_close(ptr %s12)
  br label %bb101
bb101:
  call void @__olang_scope_close(ptr %s10)
  br label %bb102
bb102:
  call void @__olang_scope_close(ptr %s8)
  br label %bb103
bb103:
  call void @__olang_scope_close(ptr %s6)
  br label %bb104
bb104:
  br label %bb26
bb105:
  %t379 = load i1, ptr %l13, !tbaa !21
  br i1 %t379, label %bb106, label %bb107
bb106:
  %t381 = load ptr, ptr %lp12
  %t382 = getelementptr %"compiler/emit:Reused", ptr %t381, i32 0, i32 1
  %t384 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v3, ptr %t382)
  store i64 %t384, ptr %l159
  br label %bb108
bb107:
  store i1 false, ptr %l157, !tbaa !21
  br label %bb109
bb108:
  %t385 = load i64, ptr %l159, !tbaa !24
  %t386 = icmp sgt i64 %t385, 0
  store i1 %t386, ptr %l157, !tbaa !21
  br label %bb109
bb109:
  %t388 = load i1, ptr %l157, !tbaa !21
  br i1 %t388, label %bb110, label %bb111
bb110:
  %t389 = load ptr, ptr %lp3
  %t390 = load ptr, ptr %lp12
  %t391 = load %"compiler/emit:Reused", ptr %t390
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aReused_3e_2ePush_3ccompiler_2femit_3aReused_3e(ptr %v3, ptr %v3, ptr %t389, %"compiler/emit:Reused" %t391)
  br label %bb112
bb111:
  br label %bb113
bb112:
  br label %bb113
bb113:
  call void @__olang_scope_close(ptr %s2)
  br label %bb114
bb114:
  %t394 = load i64, ptr %l8, !tbaa !24
  %t396 = add i64 %t394, 1
  store i64 %t396, ptr %l8, !tbaa !24
  br label %bb8
bb115:
  %t398 = load ptr, ptr %lp3
  %t399 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t398
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t399, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local i1 @compiler_2folang_2eroomFor(i64 %a0) #0 {
entry:
  %l1 = alloca [2 x i64]
  %l6 = alloca i32
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = insertvalue [2 x i64] undef, i64 0, 0
  %t2 = insertvalue [2 x i64] %t1, i64 0, 1
  store [2 x i64] %t2, ptr %l1
  %t5 = insertvalue { i64, ptr } undef, i64 2, 0
  %t6 = insertvalue { i64, ptr } %t5, ptr %l1, 1
  %t9 = extractvalue { i64, ptr } %t6, 1
  %t10 = extractvalue { i64, ptr } %t6, 0
  %t11 = call i32 @getrlimit(i32 9, ptr %t9)
  store i32 %t11, ptr %l6
  br label %bb1
bb1:
  %t12 = load i32, ptr %l6, !tbaa !23
  %t13 = icmp ne i32 %t12, 0
  br i1 %t13, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t16 = getelementptr [2 x i64], ptr %l1, i64 0, i64 0
  %t17 = load i64, ptr %t16, !tbaa !85
  %t22 = icmp ugt i64 %t17, %a0
  store i1 %t22, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2folang_2esaid(ptr %v0, ptr %a0) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l4 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v0, ptr %s0, ptr %a0)
  store { i64, ptr } %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t4, 0
  %t6 = extractvalue { i64, ptr } %t4, 1
  %t7 = mul i64 %t5, 1
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @llvm.memcpy.p0.p0.i64(ptr %t8, ptr %t6, i64 %t7, i1 false)
  %t9 = insertvalue { i64, ptr } undef, i64 %t5, 0
  %t10 = insertvalue { i64, ptr } %t9, ptr %t8, 1
  %t12 = call i32 @compiler_2folang_2ewrite(ptr %s0, { i64, ptr } %t10)
  store i32 %t12, ptr %l4
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2folang_2eusage(ptr %v0, ptr %v1, ptr %a0, %"compiler/msgs:Msg" %a1) #0 {
entry:
  %l5 = alloca i64
  %rv = alloca i32
  %t2 = alloca { i64, [3 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  store { i64, [3 x i64] } zeroinitializer, ptr %t2
  %t3 = getelementptr { i64, [3 x i64] }, ptr %t2, i32 0, i32 0
  store i64 0, ptr %t3
  %t4 = load { i64, [3 x i64] }, ptr %t2
  %t9 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %t4, %"compiler/msgs:Msg" %a1)
  store i64 %t9, ptr %l5
  br label %bb1
bb1:
  store i32 65536, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2folang_2ewrite(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l2 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i32 @std_2fio_2ePrint(ptr %v0, { i64, ptr } %a0)
  store i32 %t3, ptr %l2
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  br label %bb1
bb1:
  br label %bb6
bb2:
  %t6 = load i32, ptr %l2, !tbaa !23
  %t7 = ashr i32 %t6, 16
  %t9 = icmp eq i32 %t7, 1
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @.c206)
  unreachable
bb5:
  store i32 1, ptr %rv
  br label %ret
bb6:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"compiler/olang:CommandLine" @compiler_2folang_3aCommandLine_2ector(ptr %v0) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i1
  %l4 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l9 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l11 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/olang:CommandLine"
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l0, !tbaa !24
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l9
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l9
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l1
  store { i64, ptr } { i64 0, ptr @.d207 }, ptr %l2, !tbaa !27
  store i1 false, ptr %l3, !tbaa !21
  %t4 = load ptr, ptr @__olang_prog_scope
  %t5 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t4)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, ptr %l10
  br label %bb2
bb2:
  %t6 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t6, ptr %l4
  %t7 = load ptr, ptr @__olang_prog_scope
  %t8 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t7)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %l11
  br label %bb3
bb3:
  %t9 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  store { i64, ptr } { i64 6, ptr @.d208 }, ptr %l6, !tbaa !27
  store { i64, ptr } { i64 0, ptr @.d209 }, ptr %l7, !tbaa !27
  %t10 = load i64, ptr %l0, !tbaa !24
  %t11 = insertvalue %"compiler/olang:CommandLine" undef, i64 %t10, 0
  %t12 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l1
  %t13 = insertvalue %"compiler/olang:CommandLine" %t11, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, 1
  %t14 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t15 = insertvalue %"compiler/olang:CommandLine" %t13, { i64, ptr } %t14, 2
  %t16 = load i1, ptr %l3, !tbaa !21
  %t17 = insertvalue %"compiler/olang:CommandLine" %t15, i1 %t16, 3
  %t18 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l4
  %t19 = insertvalue %"compiler/olang:CommandLine" %t17, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t18, 4
  %t21 = insertvalue %"compiler/olang:CommandLine" %t19, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t9, 5
  %t22 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t23 = insertvalue %"compiler/olang:CommandLine" %t21, { i64, ptr } %t22, 6
  %t24 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t25 = insertvalue %"compiler/olang:CommandLine" %t23, { i64, ptr } %t24, 7
  %t27 = insertvalue %"compiler/olang:CommandLine" %t25, i1 false, 8
  store %"compiler/olang:CommandLine" %t27, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/olang:CommandLine", ptr %rv
  ret %"compiler/olang:CommandLine" %rr
}

define dso_local %"compiler/olang:Passes" @compiler_2folang_3aPasses_2ector(ptr %v0) #0 {
entry:
  %rv = alloca %"compiler/olang:Passes"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = insertvalue %"compiler/olang:Passes" undef, i64 0, 0
  store %"compiler/olang:Passes" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/olang:Passes", ptr %rv
  ret %"compiler/olang:Passes" %rr
}

define i32 @main(i32 %argc, ptr %argv) #0 {
entry:
  store i32 %argc, ptr @__olang_argc
  store ptr %argv, ptr @__olang_argv
  call void @__olang_thread_init()
  call void @compiler_2fbuild_2ePhaseAt_2einit()
  call void @std_2ffilepath_2elivePath_2einit()
  call void @compiler_2folang_2emain()
  ret i32 0
}

define dso_local void @olang_2einit_2ecompiler_2folang() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2folang_2eModeWords_2einit()
  br label %bb1
bb1:
  call void @compiler_2folang_2eRun_2einit()
  br label %bb2
bb2:
  call void @compiler_2folang_2eBuild_2einit()
  br label %bb3
bb3:
  call void @compiler_2folang_2eCompile_2einit()
  br label %bb4
bb4:
  call void @compiler_2folang_2eTest_2einit()
  br label %bb5
bb5:
  call void @compiler_2folang_2eInterp_2einit()
  br label %bb6
bb6:
  call void @compiler_2folang_2eFormat_2einit()
  br label %bb7
bb7:
  call void @compiler_2folang_2eExplain_2einit()
  br label %bb8
bb8:
  call void @compiler_2folang_2eHelp_2einit()
  br label %bb9
bb9:
  call void @compiler_2folang_2eModeUsage_2einit()
  br label %bb10
bb10:
  call void @compiler_2folang_2eModeWhat_2einit()
  br label %bb11
bb11:
  call void @compiler_2folang_2eOptWords_2einit()
  br label %bb12
bb12:
  call void @compiler_2folang_2eOptValues_2einit()
  br label %bb13
bb13:
  call void @compiler_2folang_2eOptModes_2einit()
  br label %bb14
bb14:
  call void @compiler_2folang_2eOptWhat_2einit()
  br label %bb15
bb15:
  br label %ret
ret:
  ret void
}

@.d0 = private constant [42 x i8] c"olang [OPTION...] FILE.olang [ARGUMENT...]"
@.d1 = private constant [34 x i8] c"olang build [OPTION...] FILE.olang"
@.d2 = private constant [36 x i8] c"olang compile [OPTION...] FILE.olang"
@.d3 = private constant [36 x i8] c"olang test [OPTION...] FILE.olang..."
@.d4 = private constant [52 x i8] c"olang interpret [OPTION...] FILE.olang [ARGUMENT...]"
@.d5 = private constant [38 x i8] c"olang format [OPTION...] FILE.olang..."
@.d6 = private constant [18 x i8] c"olang explain RULE"
@.d7 = private constant [17 x i8] c"olang help [MODE]"
@.d8 = private constant [106 x i8] c"builds the program FILE.olang is the root of, as build does, and runs it with the arguments after the file"
@.d9 = private constant [64 x i8] c"builds one program, FILE.olang its root module, into build/ (B3)"
@.d10 = private constant [54 x i8] c"compiles one module to an object, linking nothing (B2)"
@.d11 = private constant [62 x i8] c"runs each file's test blocks, each file built on its own (B3a)"
@.d12 = private constant [110 x i8] c"runs the program by compile-time evaluation instead of building it, the arguments after the file its own (B3e)"
@.d13 = private constant [46 x i8] c"rewrites each file in olang's one layout (B13)"
@.d14 = private constant [41 x i8] c"prints a rule of the specification (B11a)"
@.d15 = private constant [36 x i8] c"lists the modes, or a mode's options"
@.d16 = private constant [0 x i8] c""
@.d17 = private constant [5 x i8] c"build"
@.d18 = private constant [7 x i8] c"compile"
@.d19 = private constant [4 x i8] c"test"
@.d20 = private constant [9 x i8] c"interpret"
@.d21 = private constant [6 x i8] c"format"
@.d22 = private constant [7 x i8] c"explain"
@.d23 = private constant [4 x i8] c"help"
@.d24 = private constant [4 x i8] c"PATH"
@.d25 = private constant [0 x i8] c""
@.d26 = private constant [0 x i8] c""
@.d27 = private constant [0 x i8] c""
@.d28 = private constant [4 x i8] c"NAME"
@.d29 = private constant [10 x i8] c"Name=value"
@.d30 = private constant [0 x i8] c""
@.d31 = private constant [0 x i8] c""
@.d32 = private constant [49 x i8] c"writes the executable or the object to PATH (B3h)"
@.d33 = private constant [53 x i8] c"builds unoptimized, with debug information (B2c, B2e)"
@.d34 = private constant [40 x i8] c"builds with the data race detector (B2b)"
@.d35 = private constant [37 x i8] c"builds with the scope sanitizer (B2f)"
@.d36 = private constant [32 x i8] c"builds for another machine (B12)"
@.d37 = private constant [30 x i8] c"defines a build constant (B10)"
@.d38 = private constant [85 x i8] c"moves the remote repositories the build reaches to their refs' current commits (M23c)"
@.d39 = private constant [57 x i8] c"rewrites nothing: lists each file not in the layout (B13)"
@.d40 = private constant [7 x i8] c"-output"
@.d41 = private constant [6 x i8] c"-debug"
@.d42 = private constant [5 x i8] c"-race"
@.d43 = private constant [9 x i8] c"-sanitize"
@.d44 = private constant [7 x i8] c"-target"
@.d45 = private constant [7 x i8] c"-define"
@.d46 = private constant [7 x i8] c"-update"
@.d47 = private constant [6 x i8] c"-check"
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d48 = private constant [1 x i8] c"-"
@.d49 = private constant [1 x i8] c"-"
@__olang_prog_scope = external thread_local(initialexec) global ptr
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d50 = private constant [0 x i8] c""
@.d51 = private constant [0 x i8] c""
@.d52 = private constant [0 x i8] c""
@.d53 = private constant [14 x i8] c"/proc/self/exe"
@.d54 = private constant [0 x i8] c""
declare void @__olang_check_failed(ptr)
@.c55 = private unnamed_addr constant [52 x i8] c"compiler/olang.olang:493: reached unreachable code\0A\00"
@.d56 = private constant [0 x i8] c""
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d57 = private constant [0 x i8] c""
@.d58 = private constant [1 x i8] c" "
declare i64 @__olang_fmt_i64(ptr, i64)
@.d59 = private constant [1 x i8] c" "
@.d60 = private constant [1 x i8] c"\0A"
@.c61 = private unnamed_addr constant [5 x i8] c"true\00"
@.c62 = private unnamed_addr constant [6 x i8] c"false\00"
@.d63 = private constant [1 x i8] c" "
@.d64 = private constant [1 x i8] c" "
@.d65 = private constant [1 x i8] c" "
@.d66 = private constant [1 x i8] c"\0A"
@.d67 = private constant [1 x i8] c"\0A"
@.d68 = private constant [1 x i8] c"\0A"
@.d69 = private constant [1 x i8] c"\0A"
@.d70 = private constant [1 x i8] c"\0A"
@.d71 = private constant [1 x i8] c"\0A"
@.d72 = private constant [1 x i8] c"\0A"
@.d73 = private constant [8 x i8] c"TargetOs"
@.d74 = private constant [10 x i8] c"TargetArch"
@.d75 = private constant [9 x i8] c"TargetCpu"
@.d76 = private constant [16 x i8] c"TargetVectorBits"
@.d77 = private constant [12 x i8] c"TargetHasFma"
@.d78 = private constant [10 x i8] c"DebugBuild"
@.d79 = private constant [9 x i8] c"RaceBuild"
@.d80 = private constant [9 x i8] c"TestBuild"
@.d81 = private constant [1 x i8] c"/"
@.c82 = private unnamed_addr constant [53 x i8] c"compiler/olang.olang:236: slice bounds out of range\0A\00"
@.d83 = private constant [20 x i8] c"olang: reuse check: "
@.d84 = private constant [9 x i8] c" differs\0A"
@.c85 = private unnamed_addr constant [52 x i8] c"compiler/olang.olang:636: reached unreachable code\0A\00"
@.d86 = private constant [20 x i8] c"olang: reuse check: "
@.d87 = private constant [10 x i8] c" objects, "
@.d88 = private constant [16 x i8] c" written afresh\0A"
@.c89 = private unnamed_addr constant [52 x i8] c"compiler/olang.olang:641: reached unreachable code\0A\00"
@.c90 = private unnamed_addr constant [52 x i8] c"compiler/olang.olang:642: reached unreachable code\0A\00"
@.d91 = private constant [20 x i8] c"olang: reuse check: "
@.d92 = private constant [39 x i8] c" modules reused, every object the same\0A"
@.c93 = private unnamed_addr constant [52 x i8] c"compiler/olang.olang:644: reached unreachable code\0A\00"
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fbuild_3aKind(ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  %t5 = load i32, ptr %a1
  %t6 = sext i32 %t5 to i64
  %t9 = icmp eq i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb3
bb2:
  br label %bb3
bb3:
  %t11 = load i1, ptr %l2, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d94 = private constant [5 x i8] c"start"
@.d95 = private constant [4 x i8] c"load"
@.d96 = private constant [5 x i8] c"check"
@.d97 = private constant [8 x i8] c"evaluate"
@.d98 = private constant [5 x i8] c"scope"
@.c99 = private unnamed_addr constant [53 x i8] c"compiler/olang.olang:397: array length out of range\0A\00"
@.d100 = private constant [10 x i8] c"lower+emit"
@.d101 = private constant [17 x i8] c"it does not emit "
@.d102 = private constant [4 x i8] c" yet"
@.d103 = private constant [20 x i8] c": it does not lower "
@.d104 = private constant [4 x i8] c" yet"
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d105 = private constant [2 x i8] c".p"
@.d106 = private constant [3 x i8] c".ll"
@.d107 = private constant [11 x i8] c"its record "
@.d108 = private constant [27 x i8] c" was lost while it was read"
@.d109 = private constant [16 x i8] c"@__olang_dyncall"
@.d110 = private constant [0 x i8] c""
@.d111 = private constant [16 x i8] c"@__olang_dyncall"
@.c112 = private unnamed_addr constant [52 x i8] c"compiler/olang.olang:438: reached unreachable code\0A\00"
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2femit_3aObjectKind(ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  %t5 = load i32, ptr %a1
  %t6 = sext i32 %t5 to i64
  %t9 = icmp eq i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb3
bb2:
  br label %bb3
bb3:
  %t11 = load i1, ptr %l2, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d113 = private constant [16 x i8] c"OLANG_CHECKREUSE"
@.d114 = private constant [0 x i8] c""
@.d115 = private constant [0 x i8] c""
@.d116 = private constant [0 x i8] c""
declare void @abort() noreturn
@.c117 = private unnamed_addr constant [52 x i8] c"compiler/olang.olang:694: reached unreachable code\0A\00"
@.d118 = private constant [16 x i8] c"sanitize_thread "
@.d119 = private constant [0 x i8] c""
@.d120 = private constant [6 x i8] c".olang"
@.c121 = private unnamed_addr constant [53 x i8] c"compiler/olang.olang:297: slice bounds out of range\0A\00"
@.d122 = private constant [2 x i8] c"-l"
@.d123 = private constant [2 x i8] c"-f"
@.d124 = private constant [96 x i8] c"usage: olang MODE [OPTION...] FILE...   or   olang [OPTION...] FILE.olang [ARGUMENT...]\0A\0Amodes:\0A"
@.d125 = private constant [10 x i8] c"FILE.olang"
@.d126 = private constant [2 x i8] c"  "
@.d127 = private constant [1 x i8] c" "
@.d128 = private constant [1 x i8] c"\0A"
@.d129 = private constant [2 x i8] c"  "
@.d130 = private constant [1 x i8] c" "
@.d131 = private constant [1 x i8] c"\0A"
@.d132 = private constant [85 x i8] c"\0A'olang help MODE' lists a mode's options; 'olang help run' those of running a file.\0A"
@.d133 = private constant [3 x i8] c"run"
@.d134 = private constant [7 x i8] c"usage: "
@.d135 = private constant [1 x i8] c"\0A"
@.d136 = private constant [1 x i8] c"\0A"
@.d137 = private constant [10 x i8] c"\0Aoptions:\0A"
@.d138 = private constant [0 x i8] c""
@.d139 = private constant [1 x i8] c" "
@.d140 = private constant [0 x i8] c""
@.d141 = private constant [2 x i8] c"  "
@.d142 = private constant [1 x i8] c" "
@.d143 = private constant [1 x i8] c"\0A"
@.d144 = private constant [4 x i8] c"/rec"
@.c145 = private unnamed_addr constant [52 x i8] c"compiler/olang.olang:590: reached unreachable code\0A\00"
@.c146 = private unnamed_addr constant [52 x i8] c"compiler/olang.olang:592: reached unreachable code\0A\00"
@.d147 = private constant [0 x i8] c""
@.d148 = private constant [1 x i8] c"1"
@.d149 = private constant [1 x i8] c"0"
@.d150 = private constant [25 x i8] c"olang module record\0Asize "
@.d151 = private constant [7 x i8] c"\0Asplit "
@.d152 = private constant [1 x i8] c"\0A"
define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.c153 = private unnamed_addr constant [52 x i8] c"compiler/olang.olang:598: reached unreachable code\0A\00"
@.d154 = private constant [5 x i8] c"inst "
@.d155 = private constant [1 x i8] c"\0A"
@.d156 = private constant [2 x i8] c".p"
@.d157 = private constant [3 x i8] c".ll"
@.d158 = private constant [5 x i8] c"part "
@.d159 = private constant [1 x i8] c" "
@.d160 = private constant [1 x i8] c"\0A"
@.d161 = private constant [4 x i8] c"end\0A"
@.d162 = private constant [97 x i8] c"olang: internal compiler error: the compiler crashed - a bug in the compiler, not in the program\0A"
define available_externally void @__olang_scope_escape(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %un = icmp eq ptr %o, null
  br i1 %un, label %claim, label %done
claim:
  %me = load ptr, ptr @__olang_self
  store atomic ptr %me, ptr %op monotonic, align 8
  br label %done
done:
  ret void
}
define internal void @olang_lambda_163(ptr %env) #0 {
entry:
  %l2 = alloca i32
  %cp0 = getelementptr { { i64, ptr }, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load { i64, ptr }, ptr %cp0, !tbaa !28
  %vq0 = getelementptr { { i64, ptr }, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i32 @compiler_2folang_2edrive(ptr %vc0, { i64, ptr } %cv0)
  store i32 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i32, ptr %l2, !tbaa !23
  call void @std_2fos_2eExit(i32 %t4)
  unreachable
bb2:
  call void @__olang_check_failed(ptr @.c210)
  unreachable
ret:
  ret void
}

@.c164 = private unnamed_addr constant [51 x i8] c"compiler/olang.olang:41: reached unreachable code\0A\00"
@.d165 = private constant [14 x i8] c"running a file"
@.d166 = private constant [5 x i8] c" and "
@.d167 = private constant [2 x i8] c", "
@.c168 = private unnamed_addr constant [53 x i8] c"compiler/olang.olang:505: array length out of range\0A\00"
@.d169 = private constant [0 x i8] c""
@.d170 = private constant [0 x i8] c""
@.d171 = private constant [6 x i8] c"\0Aroot "
@.d172 = private constant [1 x i8] c" "
@.c173 = private unnamed_addr constant [53 x i8] c"compiler/olang.olang:511: array length out of range\0A\00"
@.d174 = private constant [0 x i8] c""
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.c175 = private unnamed_addr constant [53 x i8] c"compiler/olang.olang:523: array length out of range\0A\00"
@.c176 = private unnamed_addr constant [52 x i8] c"compiler/olang.olang:535: reached unreachable code\0A\00"
define internal i1 @olang_lambda_177(ptr %env, i64 %a0, i64 %a1) #0 {
entry:
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = icmp slt i64 %a0, %a1
  store i1 %t5, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.c178 = private unnamed_addr constant [52 x i8] c"compiler/olang.olang:543: reached unreachable code\0A\00"
@.d179 = private constant [1 x i8] c" "
define internal { i64, ptr } @olang_lambda_180(ptr %env, ptr %v0, i64 %a0) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  %cp0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  %vq0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eInstNote(ptr %vc0, ptr %v0, ptr %cv0, i64 %a0)
  store { i64, ptr } %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t6, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define internal { i64, ptr } @olang_lambda_181(ptr %env, ptr %v0, i32 %a0) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  %cp0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  %vq0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %vc0, ptr %v0, ptr %cv0, i32 %a0)
  store { i64, ptr } %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t6, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

@.d182 = private constant [1 x i8] c"."
@.d183 = private constant [4 x i8] c".tmp"
@.c184 = private unnamed_addr constant [52 x i8] c"compiler/olang.olang:617: reached unreachable code\0A\00"
@.c185 = private unnamed_addr constant [52 x i8] c"compiler/olang.olang:618: reached unreachable code\0A\00"
@.c186 = private unnamed_addr constant [52 x i8] c"compiler/olang.olang:619: reached unreachable code\0A\00"
@.c187 = private unnamed_addr constant [53 x i8] c"compiler/olang.olang:551: slice bounds out of range\0A\00"
@.d188 = private constant [5 x i8] c"/rec/"
@.d189 = private constant [1 x i8] c"."
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aReused_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2femit_3aReused_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d190 = private constant [0 x i8] c""
@.c191 = private unnamed_addr constant [52 x i8] c"compiler/olang.olang:560: reached unreachable code\0A\00"
@.c192 = private unnamed_addr constant [52 x i8] c"compiler/olang.olang:563: reached unreachable code\0A\00"
@.d193 = private constant [3 x i8] c"end"
@.d194 = private constant [5 x i8] c"size "
@.d195 = private constant [6 x i8] c"split "
@.c196 = private unnamed_addr constant [53 x i8] c"compiler/olang.olang:567: slice bounds out of range\0A\00"
@.d197 = private constant [5 x i8] c"inst "
@.c198 = private unnamed_addr constant [53 x i8] c"compiler/olang.olang:569: slice bounds out of range\0A\00"
@.d199 = private constant [1 x i8] c"1"
@.d200 = private constant [5 x i8] c"part "
@.c201 = private unnamed_addr constant [53 x i8] c"compiler/olang.olang:571: slice bounds out of range\0A\00"
@.d202 = private constant [2 x i8] c".p"
@.d203 = private constant [3 x i8] c".ll"
@.c204 = private unnamed_addr constant [53 x i8] c"compiler/olang.olang:575: slice bounds out of range\0A\00"
@.c205 = private unnamed_addr constant [53 x i8] c"compiler/olang.olang:576: slice bounds out of range\0A\00"
declare i32 @getrlimit(i32, ptr)
@.c206 = private unnamed_addr constant [52 x i8] c"compiler/olang.olang:340: reached unreachable code\0A\00"
@.d207 = private constant [0 x i8] c""
@.d208 = private constant [6 x i8] c"native"
@.d209 = private constant [0 x i8] c""
@__olang_argc = external global i32
@__olang_argv = external global ptr
declare void @__olang_thread_init()
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@__olang_self = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
@.c210 = private unnamed_addr constant [51 x i8] c"compiler/olang.olang:40: reached unreachable code\0A\00"
define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
declare ptr @__olang_scope_mine_slow(ptr) noinline
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eUsage(ptr %v0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotAMode(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownFlag(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eOptionNotForMode(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eOptionNeedsValue(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eDefine(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, ptr %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eExplainNeedsRule(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eHelpOneMode(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eModeFirst(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotASource(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eModeNeedsFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eModeOneFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2ftarget_2eFindClang(ptr %v0)
declare { i32, %"compiler/target:Target" } @compiler_2ftarget_2eResolve(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, ptr %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetForeignMode(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, %"std/os:FileInfo" } @std_2fos_2eStat(ptr %v0, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fos_2eCwd(ptr %v0)
declare { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eFingerprint(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2fload_2eStdDir(ptr %v0)
declare i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eHas(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefineBuiltin(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eBuiltins(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, i64 %a4, i64 %a5, i1 %a6, i1 %a7, i1 %a8)
declare i1 @std_2fos_2eIsDir(ptr %v0, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eOutputIsDir(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eOutputNoDir(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eLen_3cI64_2c_20I64_3e(ptr %v0, ptr %a0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2ecompiler_2femit_3aEmitter_2eObjects(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aObject_3e_2eLen_3ccompiler_2femit_3aObject_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2eLen_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %a0)
declare %"compiler/build:Unit" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2eAt_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/emit:Object" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aObject_3e_2eAt_3ccompiler_2femit_3aObject_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @std_2fio_2ePrintErr(ptr %v0, { i64, ptr } %a0)
declare void @std_2fos_2eExit(i32 %a0)
declare void @compiler_2fbuild_2ePhase(ptr %v0, { i64, ptr } %a0)
declare void @compiler_2finterp_2eAnalyze(ptr %out, ptr %v0, ptr %v1, ptr %a0, i1 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eCheckMain(ptr %v0, ptr %a0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v0, ptr %a0)
declare i64 @compiler_2finterp_2eDecideValues(ptr %v0, ptr %a0)
declare i64 @compiler_2finterp_2eDecideAsserts(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2finterp_2eBake(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHasFatal(ptr %v0, ptr %a0)
declare %"compiler/lower:Lowerer" @compiler_2flower_3aLowerer_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3aGap_3e_2eLen_3ccompiler_2flower_3aGap_3e(ptr %v0, ptr %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fbuild_2eUnbuildable(ptr %v0, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3aGap_3e_2eRunFrom_3ccompiler_2flower_3aGap_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aObject_3e_2eRunFrom_3ccompiler_2femit_3aObject_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/emit:Reused" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aReused_3e_2eAt_3ccompiler_2femit_3aReused_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/build:Unit" @compiler_2fbuild_3aUnit_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, i32 %a1, { i64, ptr } %a2)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2ePush_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/build:Unit" %a1)
declare { i64, ptr } @compiler_2fbuild_2eIrHash(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @compiler_2fruntime_2eIr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3, i1 %a4)
declare { i32, { i64, ptr } } @compiler_2fruntime_2eDyncallIr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3, i1 %a4)
declare void @compiler_2finterp_3aExec_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1, i32 %a2)
declare void @compiler_2finterp_2ecompiler_2finterp_3aExec_2ePlace(ptr %v0, ptr %a0)
@G_2ecompiler_2feval_2eInterpCrash = external constant <{ [8 x i8], ptr }>
declare void @std_2fos_2eOnCrash(ptr %v0, { i64, ptr } %a0)
declare i32 @compiler_2finterp_2ecompiler_2finterp_3aExec_2eRunMain(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fload_2eLockPath(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2ffetch_2eCacheDir(ptr %v0)
declare { i64, ptr } @compiler_2ffetch_2eGitBase(ptr %v0)
declare %"compiler/fetch:Fetcher" @compiler_2ffetch_3aFetcher_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3, i1 %a4)
declare %"compiler/source:Names" @compiler_2fsource_3aNames_2ector(ptr %v0)
declare %"compiler/load:Loader" @compiler_2fload_3aLoader_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4)
declare i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eLoad(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v0, ptr %a0)
declare i32 @compiler_2folang_2eRunWith_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1)
declare void @compiler_2femit_3aEmitter_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, ptr %a3)
@G_2ecompiler_2fbuild_2eThinFrom = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\80\00\00\00\00\00" }>, align 8
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fdiag_2eSpecPath(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoSpec(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare { i32, { i64, ptr } } @compiler_2fdiag_2eExplain(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eToUpper(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoRule(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hd4bdf3befe2f7a35847f168802c5df68(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2ffmt_2eFiles(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadEnd(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i8 %a2)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aReused_3e_2eLen_3ccompiler_2femit_3aReused_3e(ptr %v0, ptr %a0)
declare i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %a0)
declare i32 @compiler_2fbuild_2ePid()
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aReused_3e_2eRunFrom_3ccompiler_2femit_3aReused_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H2b85ceff512af6e6ca26c554a1c16247(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i1 %a2)
declare { i64, ptr } @std_2fos_2eArgs(ptr %v0)
declare void @std_2fos_2eRunOnStack(ptr %v0, i64 %a0, ptr %a1c, ptr %a1e)
declare { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2eRunFrom_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSort_3cI64_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1c, ptr %a1e)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fscope_3aScoper_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eRun(ptr %v0, ptr %a0)
declare i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @std_2fos_2eRename(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @std_2fos_2eRemove(ptr %v0, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fbuild_2eReadable(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/emit:Reused" @compiler_2femit_3aReused_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %a0)
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare i1 @std_2fos_2eExists(ptr %v0, { i64, ptr } %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aReused_3e_2ePush_3ccompiler_2femit_3aReused_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/emit:Reused" %a1)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v0, ptr %v1, ptr %a0)
declare i32 @std_2fio_2ePrint(ptr %v0, { i64, ptr } %a0)
declare void @compiler_2fbuild_2ePhaseAt_2einit()
declare void @std_2ffilepath_2elivePath_2einit()
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eInstNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2femit_3aReused_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
