; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/list:listState.9783095779ea18337775adeb6569839d" = type { { i64, ptr }, { i64, ptr }, i64, i64, { i64, ptr }, i64, i64, i64 }
define dso_local i64 @std_2flist_2estd_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2eLen_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %a0) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"std/list:listState.9783095779ea18337775adeb6569839d", ptr %t4, i32 0, i32 7
  %t7 = load i64, ptr %t6, !tbaa !24
  store i64 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i32, { i64, ptr } } @std_2flist_2estd_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2eRunFrom_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca ptr
  %l9 = alloca i1
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l26 = alloca ptr
  %l30 = alloca i64
  %l34 = alloca { i64, ptr }
  %rv = alloca { i32, { i64, ptr } }
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %l1, !tbaa !24
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = getelementptr %"std/list:listState.9783095779ea18337775adeb6569839d", ptr %t7, i32 0, i32 7
  %t10 = load i64, ptr %t9, !tbaa !24
  %t13 = icmp sge i64 %t6, %t10
  br i1 %t13, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb3
bb2:
  %t15 = load i64, ptr %l1, !tbaa !24
  %t17 = icmp slt i64 %t15, 0
  store i1 %t17, ptr %l9, !tbaa !21
  br label %bb3
bb3:
  %t19 = load i1, ptr %l9, !tbaa !21
  br i1 %t19, label %bb4, label %bb5
bb4:
  %t21 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t21, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t24 = getelementptr %"std/list:listState.9783095779ea18337775adeb6569839d", ptr %t22, i32 0, i32 2
  %t25 = load i64, ptr %t24, !tbaa !24
  %t27 = icmp eq i64 %t25, 1
  br i1 %t27, label %bb7, label %bb8
bb7:
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t31 = getelementptr %"std/list:listState.9783095779ea18337775adeb6569839d", ptr %t29, i32 0, i32 1
  %t32 = load { i64, ptr }, ptr %t31, !tbaa !27
  store { i64, ptr } %t32, ptr %l17, !tbaa !27
  %t33 = load i64, ptr %l1, !tbaa !24
  store i64 %t33, ptr %l18, !tbaa !24
  %t34 = load ptr, ptr %l2, !tbaa !29
  %t36 = getelementptr %"std/list:listState.9783095779ea18337775adeb6569839d", ptr %t34, i32 0, i32 5
  %t37 = load i64, ptr %t36, !tbaa !24
  store i64 %t37, ptr %l20, !tbaa !24
  %t38 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 0
  store i64 %t39, ptr %l21, !tbaa !24
  %t40 = load i64, ptr %l18, !tbaa !24
  %t41 = icmp sge i64 %t40, 0
  br i1 %t41, label %bb9, label %bb10
bb8:
  br label %bb15
bb9:
  %t43 = load i64, ptr %l18, !tbaa !24
  %t44 = load i64, ptr %l20, !tbaa !24
  %t45 = icmp sle i64 %t43, %t44
  br i1 %t45, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_90cea9619d71ae2c_fd926ce569d55010)
  unreachable
bb11:
  %t47 = load i64, ptr %l20, !tbaa !24
  %t48 = load i64, ptr %l21, !tbaa !24
  %t49 = icmp sle i64 %t47, %t48
  br i1 %t49, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_90cea9619d71ae2c_fd926ce569d55010)
  unreachable
bb13:
  %t51 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = load i64, ptr %l18, !tbaa !24
  %t54 = load i64, ptr %l20, !tbaa !24
  %t55 = getelementptr { i64, ptr }, ptr %t52, i64 %t53
  %t56 = sub i64 %t54, %t53
  %t57 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t55, 1
  %t60 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t58, 1
  store { i32, { i64, ptr } } %t60, ptr %rv
  br label %ret
bb14:
  call void @__olang_check_failed(ptr @olang_loc_90cea9619d71ae2c_fd926ce569d55010)
  unreachable
bb15:
  %t61 = load ptr, ptr %l2, !tbaa !29
  store ptr %t61, ptr %l26, !tbaa !29
  %t62 = load i64, ptr %l1, !tbaa !24
  %t63 = load i64, ptr @G_2estd_2flist_2efirstChunk, !tbaa !24
  %t66 = add i64 %t62, %t63
  %t68 = call i64 @std_2flist_2ehighBit(i64 %t66)
  store i64 %t68, ptr %l30
  br label %bb16
bb16:
  %t69 = load i64, ptr @G_2estd_2flist_2efirstChunkLog, !tbaa !24
  %t70 = load i64, ptr %l30, !tbaa !24
  %t72 = sub i64 %t70, %t69
  %t73 = load i64, ptr %l1, !tbaa !24
  %t74 = load ptr, ptr %l26, !tbaa !29
  %t77 = call { i64, ptr } @std_2flist_2estd_2flist_3alistState_3cstd_2fprelude_2ftext_3aString_26_3e_2erunIn_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %t74, i64 %t72, i64 %t73)
  store { i64, ptr } %t77, ptr %l34
  br label %bb17
bb17:
  %t78 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t79 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t78, 1
  store { i32, { i64, ptr } } %t79, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i64, ptr } @std_2flist_2estd_2flist_3alistState_3cstd_2fprelude_2ftext_3aString_26_3e_2echunk_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l7 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp eq i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"std/list:listState.9783095779ea18337775adeb6569839d", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/list:listState.9783095779ea18337775adeb6569839d", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  store { i64, ptr } %t13, ptr %l7, !tbaa !27
  %t14 = load i64, ptr %l1, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %t17, i64 %t14
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !37
  store { i64, ptr } %t19, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @std_2flist_2estd_2flist_3alistState_3cstd_2fprelude_2ftext_3aString_26_3e_2erunIn_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l16 = alloca i64
  %l18 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l34 = alloca i64
  %l36 = alloca i64
  %l39 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca i64
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/list:listState.9783095779ea18337775adeb6569839d", ptr %t2, i32 0, i32 2
  %t5 = load i64, ptr %t4, !tbaa !24
  %t7 = sub i64 %t5, 1
  %t10 = icmp eq i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i64, ptr %l1, !tbaa !24
  %t16 = call { i64, ptr } @std_2flist_2estd_2flist_3alistState_3cstd_2fprelude_2ftext_3aString_26_3e_2echunk_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %t12, i64 %t13)
  store { i64, ptr } %t16, ptr %l10
  br label %bb3
bb2:
  br label %bb10
bb3:
  %t17 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t17, ptr %l11, !tbaa !27
  %t18 = load i64, ptr %l2, !tbaa !24
  %t19 = load i64, ptr @G_2estd_2flist_2efirstChunk, !tbaa !24
  %t22 = add i64 %t18, %t19
  %t23 = load i64, ptr @G_2estd_2flist_2efirstChunk, !tbaa !24
  %t24 = load i64, ptr %l1, !tbaa !24
  store i64 %t24, ptr %l16, !tbaa !24
  %t26 = load i64, ptr %l16, !tbaa !24
  %t27 = load i64, ptr %l16, !tbaa !24
  %t28 = shl i64 %t23, %t27
  %t31 = sub i64 %t22, %t28
  store i64 %t31, ptr %l18, !tbaa !24
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"std/list:listState.9783095779ea18337775adeb6569839d", ptr %t32, i32 0, i32 5
  %t35 = load i64, ptr %t34, !tbaa !24
  store i64 %t35, ptr %l20, !tbaa !24
  %t36 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t36, 0
  store i64 %t37, ptr %l21, !tbaa !24
  %t38 = load i64, ptr %l18, !tbaa !24
  %t39 = icmp sge i64 %t38, 0
  br i1 %t39, label %bb4, label %bb5
bb4:
  %t41 = load i64, ptr %l18, !tbaa !24
  %t42 = load i64, ptr %l20, !tbaa !24
  %t43 = icmp sle i64 %t41, %t42
  br i1 %t43, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_35b3dd6bcc06cb0a_cb35cbb6c7218fee)
  unreachable
bb6:
  %t45 = load i64, ptr %l20, !tbaa !24
  %t46 = load i64, ptr %l21, !tbaa !24
  %t47 = icmp sle i64 %t45, %t46
  br i1 %t47, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_35b3dd6bcc06cb0a_cb35cbb6c7218fee)
  unreachable
bb8:
  %t49 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = load i64, ptr %l18, !tbaa !24
  %t52 = load i64, ptr %l20, !tbaa !24
  %t53 = getelementptr { i64, ptr }, ptr %t50, i64 %t51
  %t54 = sub i64 %t52, %t51
  %t55 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t53, 1
  store { i64, ptr } %t56, ptr %rv
  br label %ret
bb9:
  call void @__olang_check_failed(ptr @olang_loc_35b3dd6bcc06cb0a_cb35cbb6c7218fee)
  unreachable
bb10:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i64, ptr %l1, !tbaa !24
  %t62 = call { i64, ptr } @std_2flist_2estd_2flist_3alistState_3cstd_2fprelude_2ftext_3aString_26_3e_2echunk_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %t58, i64 %t59)
  store { i64, ptr } %t62, ptr %l28
  br label %bb11
bb11:
  %t63 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t63, ptr %l29, !tbaa !27
  %t64 = load i64, ptr %l2, !tbaa !24
  %t65 = load i64, ptr @G_2estd_2flist_2efirstChunk, !tbaa !24
  %t68 = add i64 %t64, %t65
  %t69 = load i64, ptr @G_2estd_2flist_2efirstChunk, !tbaa !24
  %t70 = load i64, ptr %l1, !tbaa !24
  store i64 %t70, ptr %l34, !tbaa !24
  %t72 = load i64, ptr %l34, !tbaa !24
  %t73 = load i64, ptr %l34, !tbaa !24
  %t74 = shl i64 %t69, %t73
  %t77 = sub i64 %t68, %t74
  store i64 %t77, ptr %l36, !tbaa !24
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load i64, ptr %l1, !tbaa !24
  %t82 = call { i64, ptr } @std_2flist_2estd_2flist_3alistState_3cstd_2fprelude_2ftext_3aString_26_3e_2echunk_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %t78, i64 %t79)
  store { i64, ptr } %t82, ptr %l39
  br label %bb12
bb12:
  %t83 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t83, 0
  store i64 %t86, ptr %l42, !tbaa !24
  %t87 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t87, 0
  store i64 %t88, ptr %l43, !tbaa !24
  %t89 = load i64, ptr %l36, !tbaa !24
  %t90 = icmp sge i64 %t89, 0
  br i1 %t90, label %bb13, label %bb14
bb13:
  %t92 = load i64, ptr %l36, !tbaa !24
  %t93 = load i64, ptr %l42, !tbaa !24
  %t94 = icmp sle i64 %t92, %t93
  br i1 %t94, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_15e36604d72a5de7_9f6d877cc1463deb)
  unreachable
bb15:
  %t96 = load i64, ptr %l42, !tbaa !24
  %t97 = load i64, ptr %l43, !tbaa !24
  %t98 = icmp sle i64 %t96, %t97
  br i1 %t98, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_15e36604d72a5de7_9f6d877cc1463deb)
  unreachable
bb17:
  %t100 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = load i64, ptr %l36, !tbaa !24
  %t103 = load i64, ptr %l42, !tbaa !24
  %t104 = getelementptr { i64, ptr }, ptr %t101, i64 %t102
  %t105 = sub i64 %t103, %t102
  %t106 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t104, 1
  store { i64, ptr } %t107, ptr %rv
  br label %ret
bb18:
  call void @__olang_check_failed(ptr @olang_loc_15e36604d72a5de7_9f6d877cc1463deb)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

declare void @__olang_check_failed(ptr) cold noreturn
@olang_loc_90cea9619d71ae2c_fd926ce569d55010 = external constant [0 x i8]
@G_2estd_2flist_2efirstChunk = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\08\00\00\00\00\00\00\00" }>, align 8
declare i64 @std_2flist_2ehighBit(i64 %a0)
@G_2estd_2flist_2efirstChunkLog = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@olang_loc_35b3dd6bcc06cb0a_cb35cbb6c7218fee = external constant [0 x i8]
@olang_loc_15e36604d72a5de7_9f6d877cc1463deb = external constant [0 x i8]

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
