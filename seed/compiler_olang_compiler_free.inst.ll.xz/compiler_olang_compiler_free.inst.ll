; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/list:listState.9783095779ea18337775adeb6569839d" = type { { i64, ptr }, { i64, ptr }, i64, i64, { i64, ptr }, i64, i64, i64 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/free:leaf" = type { { i64, ptr }, i64 }
%"compiler/free:letGo" = type { i64, i64, i64, %"compiler/source:Span", %"compiler/source:Span", i64, %"compiler/source:Span", i64, i1 }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/free:orCall" = type { i64, i64, i64, i64, i64, ptr, ptr }
%"compiler/free:orStore" = type { i64, i64, ptr, ptr }
%"compiler/free:reason" = type { i64, i64, %"compiler/source:Span", { i64, ptr } }
%"compiler/free:store" = type { i64, i64, i64, %"compiler/source:Span", i64, i64, i64, ptr, ptr }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" = type { { i64, ptr }, i64, ptr }
%"std/prelude/map:mapSlot.06e151a31bcf6a36b74a6345f34868d6" = type { %"std/prelude/map:MapEntry.7071498ebd14ce3832ebc61ca83442cc", ptr }
%"std/prelude/map:MapEntry.7071498ebd14ce3832ebc61ca83442cc" = type { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"std/prelude/map:mapSlot.ee271f0959124d335f4e22d467611f9d" = type { %"std/prelude/map:MapEntry.9ce8a46a5d367870e2478b0757bce708", ptr }
%"std/prelude/map:MapEntry.9ce8a46a5d367870e2478b0757bce708" = type { %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", i64 }
define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClone_3cI64_3e(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %lp1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l18 = alloca i64
  %l21 = alloca i64
  %l41 = alloca { i64, ptr }
  %l50 = alloca ptr
  %l53 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l55 = alloca i64
  %l56 = alloca i64
  %s2 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cU64_3e_2ector(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l10
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  %t4 = load ptr, ptr %lp1
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %t4
  %t7 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t8 = load ptr, ptr %t7, !tbaa !29
  store ptr %t8, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t10, i32 0, i32 2
  %t13 = load i64, ptr %t12, !tbaa !24
  store i64 %t13, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = icmp sgt i64 %t15, %t16
  br i1 %t19, label %bb2, label %bb3
bb2:
  %t21 = load i64, ptr %l5, !tbaa !24
  %t23 = icmp sgt i64 %t21, 0
  br i1 %t23, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb7
bb4:
  %t25 = load i64, ptr %l4, !tbaa !24
  %t26 = load i64, ptr %l3, !tbaa !24
  %t29 = sub i64 %t25, %t26
  %t30 = load i64, ptr %l5, !tbaa !24
  %t33 = add i64 %t29, %t30
  %t35 = sub i64 %t33, 1
  %t36 = load i64, ptr %l5, !tbaa !24
  %t39 = sdiv i64 %t35, %t36
  store i64 %t39, ptr %l21, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb6
bb6:
  %t41 = load i64, ptr %l21, !tbaa !24
  store i64 %t41, ptr %l18, !tbaa !24
  br label %bb7
bb7:
  %t42 = load i64, ptr %l18, !tbaa !24
  store i64 %t42, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t43 = load i64, ptr %l7, !tbaa !24
  %t44 = load i64, ptr %l6, !tbaa !24
  %t47 = icmp slt i64 %t43, %t44
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb10:
  br label %bb11
bb11:
  %t51 = load i64, ptr %l3, !tbaa !24
  %t52 = load i64, ptr %l7, !tbaa !24
  %t53 = load i64, ptr %l5, !tbaa !24
  %t56 = mul i64 %t52, %t53
  %t59 = add i64 %t51, %t56
  store i64 %t59, ptr %l8, !tbaa !24
  %t61 = load ptr, ptr %l2, !tbaa !29
  %t62 = load i64, ptr %l8, !tbaa !24
  %t65 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %t61, i64 %t62)
  store { i64, ptr } %t65, ptr %l41
  br label %bb12
bb12:
  %t66 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t66, 0
  store i64 %t67, ptr %l9, !tbaa !24
  %t69 = load i64, ptr %l8, !tbaa !24
  %t70 = load ptr, ptr %l2, !tbaa !29
  %t72 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t70, i32 0, i32 2
  %t73 = load i64, ptr %t72, !tbaa !24
  %t75 = sub i64 %t73, 1
  %t78 = icmp eq i64 %t69, %t75
  br i1 %t78, label %bb13, label %bb14
bb13:
  %t80 = load ptr, ptr %l2, !tbaa !29
  %t82 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t80, i32 0, i32 5
  %t83 = load i64, ptr %t82, !tbaa !24
  store i64 %t83, ptr %l9, !tbaa !24
  br label %bb15
bb14:
  br label %bb15
bb15:
  %t85 = load ptr, ptr %lp1
  store ptr %t85, ptr %l50, !tbaa !29
  %t86 = load ptr, ptr %l2, !tbaa !29
  %t87 = load i64, ptr %l8, !tbaa !24
  %t90 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %t86, i64 %t87)
  store { i64, ptr } %t90, ptr %l53
  br label %bb16
bb16:
  %t91 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t91, ptr %l54, !tbaa !27
  %t92 = load i64, ptr %l9, !tbaa !24
  store i64 %t92, ptr %l55, !tbaa !24
  %t93 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t93, 0
  store i64 %t94, ptr %l56, !tbaa !24
  %t95 = icmp sge i64 0, 0
  br i1 %t95, label %bb17, label %bb18
bb17:
  %t97 = load i64, ptr %l55, !tbaa !24
  %t98 = icmp sle i64 0, %t97
  br i1 %t98, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_97da9209e35673c4_9116cffe73ec24d0)
  unreachable
bb19:
  %t100 = load i64, ptr %l55, !tbaa !24
  %t101 = load i64, ptr %l56, !tbaa !24
  %t102 = icmp sle i64 %t100, %t101
  br i1 %t102, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_97da9209e35673c4_9116cffe73ec24d0)
  unreachable
bb21:
  %t104 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = load i64, ptr %l55, !tbaa !24
  %t107 = getelementptr i64, ptr %t105, i64 0
  %t108 = sub i64 %t106, 0
  %t109 = insertvalue { i64, ptr } undef, i64 %t108, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t107, 1
  %t111 = load ptr, ptr %l50, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePushAll_3cI64_3e(ptr %v1, ptr %v0, ptr %t111, { i64, ptr } %t110)
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_97da9209e35673c4_9116cffe73ec24d0)
  unreachable
bb23:
  call void @__olang_scope_close(ptr %s2)
  br label %bb24
bb24:
  %t113 = load i64, ptr %l7, !tbaa !24
  %t115 = add i64 %t113, 1
  store i64 %t115, ptr %l7, !tbaa !24
  br label %bb8
bb25:
  %t117 = load ptr, ptr %lp1
  %t118 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t117
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t118, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePushAll_3cI64_3e(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l32 = alloca i64
  %l35 = alloca i64
  %l54 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l64 = alloca ptr
  %l69 = alloca ptr
  %l85 = alloca { i64, ptr }
  %l108 = alloca i64
  %l111 = alloca i64
  %l130 = alloca { i64, ptr }
  %l135 = alloca { i64, ptr }
  %l142 = alloca ptr
  %l149 = alloca ptr
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  %t9 = load ptr, ptr %l2, !tbaa !29
  %t11 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t9, i32 0, i32 6
  %t12 = load i64, ptr %t11, !tbaa !24
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t15 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t13, i32 0, i32 5
  %t16 = load i64, ptr %t15, !tbaa !24
  %t19 = sub i64 %t12, %t16
  %t22 = icmp sle i64 %t8, %t19
  br i1 %t22, label %bb1, label %bb2
bb1:
  store i64 0, ptr %l3, !tbaa !24
  %t24 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  store i64 %t26, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t28 = load i64, ptr %l4, !tbaa !24
  %t29 = load i64, ptr %l3, !tbaa !24
  %t32 = icmp sgt i64 %t28, %t29
  br i1 %t32, label %bb3, label %bb4
bb2:
  br label %bb15
bb3:
  %t34 = load i64, ptr %l5, !tbaa !24
  %t36 = icmp sgt i64 %t34, 0
  br i1 %t36, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l32, !tbaa !24
  br label %bb8
bb5:
  %t38 = load i64, ptr %l4, !tbaa !24
  %t39 = load i64, ptr %l3, !tbaa !24
  %t42 = sub i64 %t38, %t39
  %t43 = load i64, ptr %l5, !tbaa !24
  %t46 = add i64 %t42, %t43
  %t48 = sub i64 %t46, 1
  %t49 = load i64, ptr %l5, !tbaa !24
  %t52 = sdiv i64 %t48, %t49
  store i64 %t52, ptr %l35, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l35, !tbaa !24
  br label %bb7
bb7:
  %t54 = load i64, ptr %l35, !tbaa !24
  store i64 %t54, ptr %l32, !tbaa !24
  br label %bb8
bb8:
  %t55 = load i64, ptr %l32, !tbaa !24
  store i64 %t55, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t56 = load i64, ptr %l7, !tbaa !24
  %t57 = load i64, ptr %l6, !tbaa !24
  %t60 = icmp slt i64 %t56, %t57
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb14
bb11:
  br label %bb12
bb12:
  %t64 = load i64, ptr %l3, !tbaa !24
  %t65 = load i64, ptr %l7, !tbaa !24
  %t66 = load i64, ptr %l5, !tbaa !24
  %t69 = mul i64 %t65, %t66
  %t72 = add i64 %t64, %t69
  store i64 %t72, ptr %l8, !tbaa !24
  %t74 = load ptr, ptr %l2, !tbaa !29
  %t76 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t74, i32 0, i32 4
  %t77 = load { i64, ptr }, ptr %t76, !tbaa !27
  store { i64, ptr } %t77, ptr %l54, !tbaa !27
  %t78 = load ptr, ptr %l2, !tbaa !29
  %t80 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t78, i32 0, i32 5
  %t81 = load i64, ptr %t80, !tbaa !24
  %t82 = load i64, ptr %l8, !tbaa !24
  %t85 = add i64 %t81, %t82
  %t86 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t86, ptr %l59, !tbaa !27
  %t87 = load i64, ptr %l8, !tbaa !24
  %t89 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !27
  %t91 = getelementptr i64, ptr %t90, i64 %t87
  %t92 = load i64, ptr %t91, !tbaa !34
  %t95 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = getelementptr i64, ptr %t96, i64 %t85
  store i64 %t92, ptr %t97, !tbaa !34
  call void @__olang_scope_close(ptr %s3)
  br label %bb13
bb13:
  %t98 = load i64, ptr %l7, !tbaa !24
  %t100 = add i64 %t98, 1
  store i64 %t100, ptr %l7, !tbaa !24
  br label %bb9
bb14:
  %t102 = load ptr, ptr %l2, !tbaa !29
  store ptr %t102, ptr %l64, !tbaa !29
  %t103 = load ptr, ptr %l64, !tbaa !29
  %t104 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t103, i32 0, i32 5
  %t105 = load i64, ptr %t104, !tbaa !24
  %t106 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t108 = extractvalue { i64, ptr } %t106, 0
  %t111 = add i64 %t105, %t108
  %t113 = load ptr, ptr %l64, !tbaa !29
  %t114 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t113, i32 0, i32 5
  store i64 %t111, ptr %t114, !tbaa !24
  %t115 = load ptr, ptr %l2, !tbaa !29
  store ptr %t115, ptr %l69, !tbaa !29
  %t116 = load ptr, ptr %l69, !tbaa !29
  %t117 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t116, i32 0, i32 7
  %t118 = load i64, ptr %t117, !tbaa !24
  %t119 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t119, 0
  %t124 = add i64 %t118, %t121
  %t126 = load ptr, ptr %l69, !tbaa !29
  %t127 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t126, i32 0, i32 7
  store i64 %t124, ptr %t127, !tbaa !24
  br label %ret
bb15:
  store i64 0, ptr %l9, !tbaa !24
  br label %bb16
bb16:
  store %olang.scope zeroinitializer, ptr %s5
  %t128 = load i64, ptr %l9, !tbaa !24
  %t129 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t129, 0
  %t134 = icmp slt i64 %t128, %t131
  %t136 = xor i1 %t134, true
  br i1 %t136, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s5)
  br label %bb40
bb18:
  br label %bb19
bb19:
  %t138 = load ptr, ptr %l2, !tbaa !29
  %t140 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t138, i32 0, i32 5
  %t141 = load i64, ptr %t140, !tbaa !24
  %t142 = load ptr, ptr %l2, !tbaa !29
  %t144 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t142, i32 0, i32 6
  %t145 = load i64, ptr %t144, !tbaa !24
  %t148 = icmp eq i64 %t141, %t145
  br i1 %t148, label %bb20, label %bb21
bb20:
  %t150 = load ptr, ptr %l2, !tbaa !29
  %t151 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t151, ptr %l85, !tbaa !27
  %t152 = load i64, ptr %l9, !tbaa !24
  %t154 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !27
  %t156 = getelementptr i64, ptr %t155, i64 %t152
  %t157 = load i64, ptr %t156, !tbaa !34
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cI64_3e_2egrow_3cI64_3e(ptr %v0, ptr %t150, i64 %t157)
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb23
bb23:
  %t160 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t162 = extractvalue { i64, ptr } %t160, 0
  %t163 = load i64, ptr %l9, !tbaa !24
  %t166 = sub i64 %t162, %t163
  store i64 %t166, ptr %l10, !tbaa !24
  %t168 = load ptr, ptr %l2, !tbaa !29
  %t170 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t168, i32 0, i32 6
  %t171 = load i64, ptr %t170, !tbaa !24
  %t172 = load ptr, ptr %l2, !tbaa !29
  %t174 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t172, i32 0, i32 5
  %t175 = load i64, ptr %t174, !tbaa !24
  %t178 = sub i64 %t171, %t175
  %t179 = load i64, ptr %l10, !tbaa !24
  %t182 = icmp slt i64 %t178, %t179
  br i1 %t182, label %bb24, label %bb25
bb24:
  %t184 = load ptr, ptr %l2, !tbaa !29
  %t186 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t184, i32 0, i32 6
  %t187 = load i64, ptr %t186, !tbaa !24
  %t188 = load ptr, ptr %l2, !tbaa !29
  %t190 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t188, i32 0, i32 5
  %t191 = load i64, ptr %t190, !tbaa !24
  %t194 = sub i64 %t187, %t191
  store i64 %t194, ptr %l10, !tbaa !24
  br label %bb26
bb25:
  br label %bb26
bb26:
  store i64 0, ptr %l11, !tbaa !24
  %t196 = load i64, ptr %l10, !tbaa !24
  store i64 %t196, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t198 = load i64, ptr %l12, !tbaa !24
  %t199 = load i64, ptr %l11, !tbaa !24
  %t202 = icmp sgt i64 %t198, %t199
  br i1 %t202, label %bb27, label %bb28
bb27:
  %t204 = load i64, ptr %l13, !tbaa !24
  %t206 = icmp sgt i64 %t204, 0
  br i1 %t206, label %bb29, label %bb30
bb28:
  store i64 0, ptr %l108, !tbaa !24
  br label %bb32
bb29:
  %t208 = load i64, ptr %l12, !tbaa !24
  %t209 = load i64, ptr %l11, !tbaa !24
  %t212 = sub i64 %t208, %t209
  %t213 = load i64, ptr %l13, !tbaa !24
  %t216 = add i64 %t212, %t213
  %t218 = sub i64 %t216, 1
  %t219 = load i64, ptr %l13, !tbaa !24
  %t222 = sdiv i64 %t218, %t219
  store i64 %t222, ptr %l111, !tbaa !24
  br label %bb31
bb30:
  store i64 0, ptr %l111, !tbaa !24
  br label %bb31
bb31:
  %t224 = load i64, ptr %l111, !tbaa !24
  store i64 %t224, ptr %l108, !tbaa !24
  br label %bb32
bb32:
  %t225 = load i64, ptr %l108, !tbaa !24
  store i64 %t225, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb33
bb33:
  store %olang.scope zeroinitializer, ptr %s9
  %t226 = load i64, ptr %l15, !tbaa !24
  %t227 = load i64, ptr %l14, !tbaa !24
  %t230 = icmp slt i64 %t226, %t227
  %t232 = xor i1 %t230, true
  br i1 %t232, label %bb34, label %bb35
bb34:
  call void @__olang_scope_close(ptr %s9)
  br label %bb38
bb35:
  br label %bb36
bb36:
  %t234 = load i64, ptr %l11, !tbaa !24
  %t235 = load i64, ptr %l15, !tbaa !24
  %t236 = load i64, ptr %l13, !tbaa !24
  %t239 = mul i64 %t235, %t236
  %t242 = add i64 %t234, %t239
  store i64 %t242, ptr %l16, !tbaa !24
  %t244 = load ptr, ptr %l2, !tbaa !29
  %t246 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t244, i32 0, i32 4
  %t247 = load { i64, ptr }, ptr %t246, !tbaa !27
  store { i64, ptr } %t247, ptr %l130, !tbaa !27
  %t248 = load ptr, ptr %l2, !tbaa !29
  %t250 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t248, i32 0, i32 5
  %t251 = load i64, ptr %t250, !tbaa !24
  %t252 = load i64, ptr %l16, !tbaa !24
  %t255 = add i64 %t251, %t252
  %t256 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t256, ptr %l135, !tbaa !27
  %t257 = load i64, ptr %l9, !tbaa !24
  %t258 = load i64, ptr %l16, !tbaa !24
  %t261 = add i64 %t257, %t258
  %t263 = getelementptr { i64, ptr }, ptr %l135, i32 0, i32 1
  %t264 = load ptr, ptr %t263, !tbaa !27
  %t265 = getelementptr i64, ptr %t264, i64 %t261
  %t266 = load i64, ptr %t265, !tbaa !34
  %t269 = getelementptr { i64, ptr }, ptr %l130, i32 0, i32 1
  %t270 = load ptr, ptr %t269, !tbaa !27
  %t271 = getelementptr i64, ptr %t270, i64 %t255
  store i64 %t266, ptr %t271, !tbaa !34
  call void @__olang_scope_close(ptr %s9)
  br label %bb37
bb37:
  %t272 = load i64, ptr %l15, !tbaa !24
  %t274 = add i64 %t272, 1
  store i64 %t274, ptr %l15, !tbaa !24
  br label %bb33
bb38:
  %t276 = load ptr, ptr %l2, !tbaa !29
  store ptr %t276, ptr %l142, !tbaa !29
  %t277 = load ptr, ptr %l142, !tbaa !29
  %t278 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t277, i32 0, i32 5
  %t279 = load i64, ptr %t278, !tbaa !24
  %t280 = load i64, ptr %l10, !tbaa !24
  %t283 = add i64 %t279, %t280
  %t285 = load ptr, ptr %l142, !tbaa !29
  %t286 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t285, i32 0, i32 5
  store i64 %t283, ptr %t286, !tbaa !24
  %t287 = load i64, ptr %l9, !tbaa !24
  %t288 = load i64, ptr %l10, !tbaa !24
  %t291 = add i64 %t287, %t288
  store i64 %t291, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb39
bb39:
  br label %bb16
bb40:
  %t293 = load ptr, ptr %l2, !tbaa !29
  store ptr %t293, ptr %l149, !tbaa !29
  %t294 = load ptr, ptr %l149, !tbaa !29
  %t295 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t294, i32 0, i32 7
  %t296 = load i64, ptr %t295, !tbaa !24
  %t297 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t299 = extractvalue { i64, ptr } %t297, 0
  %t302 = add i64 %t296, %t299
  %t304 = load ptr, ptr %l149, !tbaa !29
  %t305 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t304, i32 0, i32 7
  store i64 %t302, ptr %t305, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eStr_3cI64_3e(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l7 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i32
  %l21 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i32
  %l32 = alloca ptr
  %l34 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l51 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l53 = alloca i64
  %l54 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.builder
  %s5room = alloca [64 x i8], align 8
  %s7 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l6
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  store %olang.scope zeroinitializer, ptr %s1
  store ptr %l1, ptr %l7, !tbaa !29
  %t3 = icmp sge i64 0, 0
  br i1 %t3, label %bb2, label %bb3
bb2:
  %t5 = icmp sle i64 0, 1152921504606846975
  br i1 %t5, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @olang_loc_ef19d749dc52a486_37471d9cecf16352)
  unreachable
bb4:
  %t7 = mul i64 0, 8
  %t8 = call ptr @__olang_scope_alloc_zeroed(ptr %s1, i64 %t7)
  %t9 = insertvalue { i64, ptr } undef, i64 0, 0
  %t10 = insertvalue { i64, ptr } %t9, ptr %t8, 1
  %t12 = call { i64, ptr } @std_2fprelude_2flist_2etypeWritten_3cI64_3e(ptr %s1, ptr %s1, { i64, ptr } %t10)
  store { i64, ptr } %t12, ptr %l11
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_ef19d749dc52a486_37471d9cecf16352)
  unreachable
bb6:
  %t13 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d0, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d0, i32 0, i32 1) }, 0
  %t15 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t15, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = add i64 %t14, %t17
  %t19 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d1, i32 0, i32 1) }, 1
  %t20 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d1, i32 0, i32 1) }, 0
  %t21 = add i64 %t18, %t20
  %t22 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t21)
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = getelementptr i8, ptr %t23, i64 %t17
  call void @olang_textcopy(ptr %t24, ptr %t19, i64 %t20)
  %t25 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t22, 1
  %t28 = extractvalue { i64, ptr } %t26, 0
  %t29 = extractvalue { i64, ptr } %t26, 1
  %t30 = mul i64 %t28, 1
  %t31 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t30)
  call void @llvm.memcpy.p0.p0.i64(ptr %t31, ptr %t29, i64 %t30, i1 false)
  %t32 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t31, 1
  %t34 = load ptr, ptr %l7, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s1, ptr %t34, { i64, ptr } %t33)
  br label %bb7
bb7:
  store i64 0, ptr %l2, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t37 = load i64, ptr %l2, !tbaa !24
  %t40 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %a0, i64 %t37)
  %t41 = extractvalue { i32, { i64, ptr } } %t40, 1
  %t42 = extractvalue { i32, { i64, ptr } } %t40, 0
  store i32 %t42, ptr %l18
  %t43 = icmp ne i32 %t42, 0
  br i1 %t43, label %bb10, label %ok.44
ok.44:
  store { i64, ptr } %t41, ptr %l17
  br label %bb9
bb9:
  %t45 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t45, ptr %l14, !tbaa !27
  br label %bb14
bb10:
  %t46 = load i32, ptr %l18, !tbaa !23
  %t47 = ashr i32 %t46, 16
  %t49 = icmp eq i32 %t47, 1
  br i1 %t49, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_3d5c34784a3a630c_5481d669dd41710)
  unreachable
bb13:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s3)
  br label %bb32
bb14:
  %t51 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t51, ptr %l3, !tbaa !27
  %t52 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t52, ptr %l21, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s5
  store ptr %s5room, ptr %s5
  call void @olang_2eHelperKind_2eRender_2eArray_3cI64_3e_26(ptr %s5, ptr %l21, i64 0)
  br label %bb15
bb15:
  %t54 = load ptr, ptr %s5
  %t55 = getelementptr %olang.builder, ptr %s5, i32 0, i32 1
  %t56 = load i64, ptr %t55
  %t57 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t56)
  call void @olang_textcopy(ptr %t57, ptr %t54, i64 %t56)
  %t58 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t57, 1
  store { i64, ptr } %t59, ptr %l23, !tbaa !27
  %t60 = getelementptr %olang.builder, ptr %s5, i32 0, i32 3
  %t61 = load ptr, ptr %t60
  %t62 = icmp ne ptr %t61, null
  br i1 %t62, label %sbgrew.63, label %sbdone.64
sbgrew.63:
  call void @__olang_sb_done(ptr %s5)
  br label %sbdone.64
sbdone.64:
  %t65 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t65, ptr %l4, !tbaa !27
  %t66 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t69 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %s3, { i64, ptr } %t66, i8 91)
  %t70 = extractvalue { i32, i64 } %t69, 1
  %t71 = extractvalue { i32, i64 } %t69, 0
  store i32 %t71, ptr %l28
  %t72 = icmp ne i32 %t71, 0
  br i1 %t72, label %bb17, label %ok.73
ok.73:
  store i64 %t70, ptr %l27
  br label %bb16
bb16:
  %t74 = load i64, ptr %l27, !tbaa !24
  store i64 %t74, ptr %l24, !tbaa !24
  br label %bb19
bb17:
  br label %bb18
bb18:
  call void @__olang_ert_req_clear()
  call void @__olang_check_failed(ptr @olang_loc_6c49b9e941c04007_786277cabc133a4b)
  unreachable
bb19:
  %t75 = load i64, ptr %l24, !tbaa !24
  store i64 %t75, ptr %l5, !tbaa !24
  %t76 = load i64, ptr %l2, !tbaa !24
  %t78 = icmp sgt i64 %t76, 0
  br i1 %t78, label %bb20, label %bb21
bb20:
  store %olang.scope zeroinitializer, ptr %s7
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %l1, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d2, i32 0, i32 1) })
  br label %bb22
bb21:
  br label %bb23
bb22:
  call void @__olang_scope_close(ptr %s7)
  br label %bb23
bb23:
  store ptr %l1, ptr %l32, !tbaa !29
  %t81 = load i64, ptr %l5, !tbaa !24
  %t83 = add i64 %t81, 1
  store i64 %t83, ptr %l34, !tbaa !24
  %t84 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t84, 0
  %t88 = sub i64 %t86, 1
  store i64 %t88, ptr %l37, !tbaa !24
  %t89 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t89, 0
  store i64 %t90, ptr %l38, !tbaa !24
  %t91 = load i64, ptr %l34, !tbaa !24
  %t92 = icmp sge i64 %t91, 0
  br i1 %t92, label %bb24, label %bb25
bb24:
  %t94 = load i64, ptr %l34, !tbaa !24
  %t95 = load i64, ptr %l37, !tbaa !24
  %t96 = icmp sle i64 %t94, %t95
  br i1 %t96, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @olang_loc_d75327113fbd1725_35766f2a3cdb1669)
  unreachable
bb26:
  %t98 = load i64, ptr %l37, !tbaa !24
  %t99 = load i64, ptr %l38, !tbaa !24
  %t100 = icmp sle i64 %t98, %t99
  br i1 %t100, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_d75327113fbd1725_35766f2a3cdb1669)
  unreachable
bb28:
  %t102 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = load i64, ptr %l34, !tbaa !24
  %t105 = load i64, ptr %l37, !tbaa !24
  %t106 = getelementptr i8, ptr %t103, i64 %t104
  %t107 = sub i64 %t105, %t104
  %t108 = insertvalue { i64, ptr } undef, i64 %t107, 0
  %t109 = insertvalue { i64, ptr } %t108, ptr %t106, 1
  %t111 = extractvalue { i64, ptr } %t109, 1
  %t112 = extractvalue { i64, ptr } %t109, 0
  %t113 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t112)
  call void @olang_textcopy(ptr %t113, ptr %t111, i64 %t112)
  %t114 = insertvalue { i64, ptr } undef, i64 %t112, 0
  %t115 = insertvalue { i64, ptr } %t114, ptr %t113, 1
  %t117 = extractvalue { i64, ptr } %t115, 0
  %t118 = extractvalue { i64, ptr } %t115, 1
  %t119 = mul i64 %t117, 1
  %t120 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t119)
  call void @llvm.memcpy.p0.p0.i64(ptr %t120, ptr %t118, i64 %t119, i1 false)
  %t121 = insertvalue { i64, ptr } undef, i64 %t117, 0
  %t122 = insertvalue { i64, ptr } %t121, ptr %t120, 1
  %t123 = load ptr, ptr %l32, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %t123, { i64, ptr } %t122)
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_d75327113fbd1725_35766f2a3cdb1669)
  unreachable
bb30:
  %t125 = load i64, ptr %l2, !tbaa !24
  %t126 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t126, 0
  %t131 = add i64 %t125, %t128
  store i64 %t131, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb31
bb31:
  br label %bb8
bb32:
  call void @__olang_scope_close(ptr %s1)
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 93)
  br label %bb33
bb33:
  %t135 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t135, ptr %l51
  br label %bb34
bb34:
  %t136 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t136, ptr %l52, !tbaa !27
  %t137 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t137, 0
  store i64 %t138, ptr %l53, !tbaa !24
  %t139 = load i64, ptr %l53, !tbaa !24
  %t140 = mul i64 %t139, 1
  %t141 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t140)
  %t142 = insertvalue { i64, ptr } undef, i64 %t139, 0
  %t143 = insertvalue { i64, ptr } %t142, ptr %t141, 1
  store { i64, ptr } %t143, ptr %l54, !tbaa !27
  %t144 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !27
  %t146 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = load i64, ptr %l53, !tbaa !24
  %t149 = mul i64 %t148, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t145, ptr %t147, i64 %t149, i1 false)
  %t150 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t150, ptr %l52, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t151 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t151, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
  ret i64 %r
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aleaf_3e_2ePush_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:leaf" %a1) #0 {
entry:
  %l1 = alloca %"compiler/free:leaf"
  %l2 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l20 = alloca ptr
  store %"compiler/free:leaf" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t6, i32 0, i32 5
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t10, i32 0, i32 6
  %t13 = load i64, ptr %t12, !tbaa !24
  %t16 = icmp eq i64 %t9, %t13
  br i1 %t16, label %bb1, label %bb2
bb1:
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t19 = load %"compiler/free:leaf", ptr %l1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2ffree_3aleaf_3e_2egrow_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %v1, ptr %t18, %"compiler/free:leaf" %t19)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t24 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t22, i32 0, i32 4
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  store { i64, ptr } %t25, ptr %l13, !tbaa !27
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t28 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t26, i32 0, i32 5
  %t29 = load i64, ptr %t28, !tbaa !24
  %t30 = load %"compiler/free:leaf", ptr %l1
  %t33 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr %"compiler/free:leaf", ptr %t34, i64 %t29
  store %"compiler/free:leaf" %t30, ptr %t35
  %t36 = load ptr, ptr %l2, !tbaa !29
  store ptr %t36, ptr %l17, !tbaa !29
  %t37 = load ptr, ptr %l17, !tbaa !29
  %t38 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t37, i32 0, i32 5
  %t39 = load i64, ptr %t38, !tbaa !24
  %t41 = add i64 %t39, 1
  %t43 = load ptr, ptr %l17, !tbaa !29
  %t44 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t43, i32 0, i32 5
  store i64 %t41, ptr %t44, !tbaa !24
  %t45 = load ptr, ptr %l2, !tbaa !29
  store ptr %t45, ptr %l20, !tbaa !29
  %t46 = load ptr, ptr %l20, !tbaa !29
  %t47 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t46, i32 0, i32 7
  %t48 = load i64, ptr %t47, !tbaa !24
  %t50 = add i64 %t48, 1
  %t52 = load ptr, ptr %l20, !tbaa !29
  %t53 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t52, i32 0, i32 7
  store i64 %t50, ptr %t53, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/free:letGo" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aletGo_3e_2eAt_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l9 = alloca { i64, ptr }
  %l16 = alloca i64
  %l21 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l26 = alloca i64
  %rv = alloca %"compiler/free:letGo"
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t5 = icmp slt i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t7, i32 0, i32 0
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t10, i32 0, i32 1
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  store { i64, ptr } %t13, ptr %l9, !tbaa !27
  %t14 = load i64, ptr %l1, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr %"compiler/free:letGo", ptr %t17, i64 %t14
  %t19 = load %"compiler/free:letGo", ptr %t18
  store %"compiler/free:letGo" %t19, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t21 = load i64, ptr %l1, !tbaa !24
  %t22 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t25 = add i64 %t21, %t22
  store i64 %t25, ptr %l2, !tbaa !24
  %t27 = load i64, ptr %l2, !tbaa !24
  %t29 = call i64 @std_2fprelude_2flist_2ehighBit(i64 %t27)
  store i64 %t29, ptr %l16
  br label %bb4
bb4:
  %t30 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunkLog, !tbaa !24
  %t31 = load i64, ptr %l16, !tbaa !24
  %t33 = sub i64 %t31, %t30
  store i64 %t33, ptr %l3, !tbaa !24
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t35, i32 0, i32 0
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t38, i32 0, i32 0
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  store { i64, ptr } %t41, ptr %l21, !tbaa !27
  %t42 = load i64, ptr %l3, !tbaa !24
  %t44 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %t45, i64 %t42
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !37
  store { i64, ptr } %t47, ptr %l23, !tbaa !27
  %t48 = load i64, ptr %l2, !tbaa !24
  %t49 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t50 = load i64, ptr %l3, !tbaa !24
  store i64 %t50, ptr %l26, !tbaa !24
  %t52 = load i64, ptr %l26, !tbaa !24
  %t53 = load i64, ptr %l26, !tbaa !24
  %t54 = shl i64 %t49, %t53
  %t57 = sub i64 %t48, %t54
  %t59 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr %"compiler/free:letGo", ptr %t60, i64 %t57
  %t62 = load %"compiler/free:letGo", ptr %t61
  store %"compiler/free:letGo" %t62, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/free:letGo", ptr %rv
  ret %"compiler/free:letGo" %rr
}

define dso_local i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aletGo_3e_2eLen_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
  ret i64 %r
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aletGo_3e_2ePush_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %a0, %"compiler/free:letGo" %a1) #0 {
entry:
  %l1 = alloca %"compiler/free:letGo"
  %l2 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l20 = alloca ptr
  store %"compiler/free:letGo" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t6, i32 0, i32 5
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t10, i32 0, i32 6
  %t13 = load i64, ptr %t12, !tbaa !24
  %t16 = icmp eq i64 %t9, %t13
  br i1 %t16, label %bb1, label %bb2
bb1:
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t19 = load %"compiler/free:letGo", ptr %l1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2ffree_3aletGo_3e_2egrow_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t18, %"compiler/free:letGo" %t19)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t24 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t22, i32 0, i32 4
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  store { i64, ptr } %t25, ptr %l13, !tbaa !27
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t28 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t26, i32 0, i32 5
  %t29 = load i64, ptr %t28, !tbaa !24
  %t30 = load %"compiler/free:letGo", ptr %l1
  %t33 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr %"compiler/free:letGo", ptr %t34, i64 %t29
  store %"compiler/free:letGo" %t30, ptr %t35
  %t36 = load ptr, ptr %l2, !tbaa !29
  store ptr %t36, ptr %l17, !tbaa !29
  %t37 = load ptr, ptr %l17, !tbaa !29
  %t38 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t37, i32 0, i32 5
  %t39 = load i64, ptr %t38, !tbaa !24
  %t41 = add i64 %t39, 1
  %t43 = load ptr, ptr %l17, !tbaa !29
  %t44 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t43, i32 0, i32 5
  store i64 %t41, ptr %t44, !tbaa !24
  %t45 = load ptr, ptr %l2, !tbaa !29
  store ptr %t45, ptr %l20, !tbaa !29
  %t46 = load ptr, ptr %l20, !tbaa !29
  %t47 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t46, i32 0, i32 7
  %t48 = load i64, ptr %t47, !tbaa !24
  %t50 = add i64 %t48, 1
  %t52 = load ptr, ptr %l20, !tbaa !29
  %t53 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t52, i32 0, i32 7
  store i64 %t50, ptr %t53, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aletGo_3e_2eRunFrom_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca ptr
  %l9 = alloca i1
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l26 = alloca ptr
  %l30 = alloca i64
  %l34 = alloca { i64, ptr }
  %rv = alloca { i32, { i64, ptr } }
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %l1, !tbaa !24
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t7, i32 0, i32 7
  %t10 = load i64, ptr %t9, !tbaa !24
  %t13 = icmp sge i64 %t6, %t10
  br i1 %t13, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb3
bb2:
  %t15 = load i64, ptr %l1, !tbaa !24
  %t17 = icmp slt i64 %t15, 0
  store i1 %t17, ptr %l9, !tbaa !21
  br label %bb3
bb3:
  %t19 = load i1, ptr %l9, !tbaa !21
  br i1 %t19, label %bb4, label %bb5
bb4:
  %t21 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t21, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t24 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t22, i32 0, i32 2
  %t25 = load i64, ptr %t24, !tbaa !24
  %t27 = icmp eq i64 %t25, 1
  br i1 %t27, label %bb7, label %bb8
bb7:
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t31 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t29, i32 0, i32 1
  %t32 = load { i64, ptr }, ptr %t31, !tbaa !27
  store { i64, ptr } %t32, ptr %l17, !tbaa !27
  %t33 = load i64, ptr %l1, !tbaa !24
  store i64 %t33, ptr %l18, !tbaa !24
  %t34 = load ptr, ptr %l2, !tbaa !29
  %t36 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t34, i32 0, i32 5
  %t37 = load i64, ptr %t36, !tbaa !24
  store i64 %t37, ptr %l20, !tbaa !24
  %t38 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 0
  store i64 %t39, ptr %l21, !tbaa !24
  %t40 = load i64, ptr %l18, !tbaa !24
  %t41 = icmp sge i64 %t40, 0
  br i1 %t41, label %bb9, label %bb10
bb8:
  br label %bb15
bb9:
  %t43 = load i64, ptr %l18, !tbaa !24
  %t44 = load i64, ptr %l20, !tbaa !24
  %t45 = icmp sle i64 %t43, %t44
  br i1 %t45, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_7af0baad65f44e5a_80ef3d923098685e)
  unreachable
bb11:
  %t47 = load i64, ptr %l20, !tbaa !24
  %t48 = load i64, ptr %l21, !tbaa !24
  %t49 = icmp sle i64 %t47, %t48
  br i1 %t49, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_7af0baad65f44e5a_80ef3d923098685e)
  unreachable
bb13:
  %t51 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = load i64, ptr %l18, !tbaa !24
  %t54 = load i64, ptr %l20, !tbaa !24
  %t55 = getelementptr %"compiler/free:letGo", ptr %t52, i64 %t53
  %t56 = sub i64 %t54, %t53
  %t57 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t55, 1
  %t60 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t58, 1
  store { i32, { i64, ptr } } %t60, ptr %rv
  br label %ret
bb14:
  call void @__olang_check_failed(ptr @olang_loc_7af0baad65f44e5a_80ef3d923098685e)
  unreachable
bb15:
  %t61 = load ptr, ptr %l2, !tbaa !29
  store ptr %t61, ptr %l26, !tbaa !29
  %t62 = load i64, ptr %l1, !tbaa !24
  %t63 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t66 = add i64 %t62, %t63
  %t68 = call i64 @std_2fprelude_2flist_2ehighBit(i64 %t66)
  store i64 %t68, ptr %l30
  br label %bb16
bb16:
  %t69 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunkLog, !tbaa !24
  %t70 = load i64, ptr %l30, !tbaa !24
  %t72 = sub i64 %t70, %t69
  %t73 = load i64, ptr %l1, !tbaa !24
  %t74 = load ptr, ptr %l26, !tbaa !29
  %t77 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2ffree_3aletGo_3e_2er_H76ad5f902abd2054bc7fd667d4b8efa6(ptr %v0, ptr %t74, i64 %t72, i64 %t73)
  store { i64, ptr } %t77, ptr %l34
  br label %bb17
bb17:
  %t78 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t79 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t78, 1
  store { i32, { i64, ptr } } %t79, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aorCall_3e_2ePush_3ccompiler_2ffree_3aorCall_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:orCall" %a1) #0 {
entry:
  %l1 = alloca %"compiler/free:orCall"
  %l2 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l20 = alloca ptr
  store %"compiler/free:orCall" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t6, i32 0, i32 5
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t10, i32 0, i32 6
  %t13 = load i64, ptr %t12, !tbaa !24
  %t16 = icmp eq i64 %t9, %t13
  br i1 %t16, label %bb1, label %bb2
bb1:
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t19 = load %"compiler/free:orCall", ptr %l1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2ffree_3aorCall_3e_2e_He84395c27c957765e879862ae50cc281(ptr %v0, ptr %v1, ptr %t18, %"compiler/free:orCall" %t19)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t24 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t22, i32 0, i32 4
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  store { i64, ptr } %t25, ptr %l13, !tbaa !27
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t28 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t26, i32 0, i32 5
  %t29 = load i64, ptr %t28, !tbaa !24
  %t30 = load %"compiler/free:orCall", ptr %l1
  %t33 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr %"compiler/free:orCall", ptr %t34, i64 %t29
  store %"compiler/free:orCall" %t30, ptr %t35
  %t36 = load ptr, ptr %l2, !tbaa !29
  store ptr %t36, ptr %l17, !tbaa !29
  %t37 = load ptr, ptr %l17, !tbaa !29
  %t38 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t37, i32 0, i32 5
  %t39 = load i64, ptr %t38, !tbaa !24
  %t41 = add i64 %t39, 1
  %t43 = load ptr, ptr %l17, !tbaa !29
  %t44 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t43, i32 0, i32 5
  store i64 %t41, ptr %t44, !tbaa !24
  %t45 = load ptr, ptr %l2, !tbaa !29
  store ptr %t45, ptr %l20, !tbaa !29
  %t46 = load ptr, ptr %l20, !tbaa !29
  %t47 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t46, i32 0, i32 7
  %t48 = load i64, ptr %t47, !tbaa !24
  %t50 = add i64 %t48, 1
  %t52 = load ptr, ptr %l20, !tbaa !29
  %t53 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t52, i32 0, i32 7
  store i64 %t50, ptr %t53, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aorCall_3e_2eRunFrom_3ccompiler_2ffree_3aorCall_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca ptr
  %l9 = alloca i1
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l26 = alloca ptr
  %l30 = alloca i64
  %l34 = alloca { i64, ptr }
  %rv = alloca { i32, { i64, ptr } }
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %l1, !tbaa !24
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t7, i32 0, i32 7
  %t10 = load i64, ptr %t9, !tbaa !24
  %t13 = icmp sge i64 %t6, %t10
  br i1 %t13, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb3
bb2:
  %t15 = load i64, ptr %l1, !tbaa !24
  %t17 = icmp slt i64 %t15, 0
  store i1 %t17, ptr %l9, !tbaa !21
  br label %bb3
bb3:
  %t19 = load i1, ptr %l9, !tbaa !21
  br i1 %t19, label %bb4, label %bb5
bb4:
  %t21 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t21, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t24 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t22, i32 0, i32 2
  %t25 = load i64, ptr %t24, !tbaa !24
  %t27 = icmp eq i64 %t25, 1
  br i1 %t27, label %bb7, label %bb8
bb7:
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t31 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t29, i32 0, i32 1
  %t32 = load { i64, ptr }, ptr %t31, !tbaa !27
  store { i64, ptr } %t32, ptr %l17, !tbaa !27
  %t33 = load i64, ptr %l1, !tbaa !24
  store i64 %t33, ptr %l18, !tbaa !24
  %t34 = load ptr, ptr %l2, !tbaa !29
  %t36 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t34, i32 0, i32 5
  %t37 = load i64, ptr %t36, !tbaa !24
  store i64 %t37, ptr %l20, !tbaa !24
  %t38 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 0
  store i64 %t39, ptr %l21, !tbaa !24
  %t40 = load i64, ptr %l18, !tbaa !24
  %t41 = icmp sge i64 %t40, 0
  br i1 %t41, label %bb9, label %bb10
bb8:
  br label %bb15
bb9:
  %t43 = load i64, ptr %l18, !tbaa !24
  %t44 = load i64, ptr %l20, !tbaa !24
  %t45 = icmp sle i64 %t43, %t44
  br i1 %t45, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_d55d63494ae88548_7509700b8d0ed81c)
  unreachable
bb11:
  %t47 = load i64, ptr %l20, !tbaa !24
  %t48 = load i64, ptr %l21, !tbaa !24
  %t49 = icmp sle i64 %t47, %t48
  br i1 %t49, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_d55d63494ae88548_7509700b8d0ed81c)
  unreachable
bb13:
  %t51 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = load i64, ptr %l18, !tbaa !24
  %t54 = load i64, ptr %l20, !tbaa !24
  %t55 = getelementptr %"compiler/free:orCall", ptr %t52, i64 %t53
  %t56 = sub i64 %t54, %t53
  %t57 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t55, 1
  %t60 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t58, 1
  store { i32, { i64, ptr } } %t60, ptr %rv
  br label %ret
bb14:
  call void @__olang_check_failed(ptr @olang_loc_d55d63494ae88548_7509700b8d0ed81c)
  unreachable
bb15:
  %t61 = load ptr, ptr %l2, !tbaa !29
  store ptr %t61, ptr %l26, !tbaa !29
  %t62 = load i64, ptr %l1, !tbaa !24
  %t63 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t66 = add i64 %t62, %t63
  %t68 = call i64 @std_2fprelude_2flist_2ehighBit(i64 %t66)
  store i64 %t68, ptr %l30
  br label %bb16
bb16:
  %t69 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunkLog, !tbaa !24
  %t70 = load i64, ptr %l30, !tbaa !24
  %t72 = sub i64 %t70, %t69
  %t73 = load i64, ptr %l1, !tbaa !24
  %t74 = load ptr, ptr %l26, !tbaa !29
  %t77 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2ffree_3aorCall_3e_2e_H51465f9ba83496ba01ce3b4ae979cd5d(ptr %v0, ptr %t74, i64 %t72, i64 %t73)
  store { i64, ptr } %t77, ptr %l34
  br label %bb17
bb17:
  %t78 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t79 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t78, 1
  store { i32, { i64, ptr } } %t79, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aorStore_3e_2ePush_3ccompiler_2ffree_3aorStore_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:orStore" %a1) #0 {
entry:
  %l1 = alloca %"compiler/free:orStore"
  %l2 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l20 = alloca ptr
  store %"compiler/free:orStore" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t6, i32 0, i32 5
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t10, i32 0, i32 6
  %t13 = load i64, ptr %t12, !tbaa !24
  %t16 = icmp eq i64 %t9, %t13
  br i1 %t16, label %bb1, label %bb2
bb1:
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t19 = load %"compiler/free:orStore", ptr %l1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2ffree_3aorStore_3e_2_H99b9f06a4dd17c91592b7d2614416ed4(ptr %v0, ptr %v1, ptr %t18, %"compiler/free:orStore" %t19)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t24 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t22, i32 0, i32 4
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  store { i64, ptr } %t25, ptr %l13, !tbaa !27
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t28 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t26, i32 0, i32 5
  %t29 = load i64, ptr %t28, !tbaa !24
  %t30 = load %"compiler/free:orStore", ptr %l1
  %t33 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr %"compiler/free:orStore", ptr %t34, i64 %t29
  store %"compiler/free:orStore" %t30, ptr %t35
  %t36 = load ptr, ptr %l2, !tbaa !29
  store ptr %t36, ptr %l17, !tbaa !29
  %t37 = load ptr, ptr %l17, !tbaa !29
  %t38 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t37, i32 0, i32 5
  %t39 = load i64, ptr %t38, !tbaa !24
  %t41 = add i64 %t39, 1
  %t43 = load ptr, ptr %l17, !tbaa !29
  %t44 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t43, i32 0, i32 5
  store i64 %t41, ptr %t44, !tbaa !24
  %t45 = load ptr, ptr %l2, !tbaa !29
  store ptr %t45, ptr %l20, !tbaa !29
  %t46 = load ptr, ptr %l20, !tbaa !29
  %t47 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t46, i32 0, i32 7
  %t48 = load i64, ptr %t47, !tbaa !24
  %t50 = add i64 %t48, 1
  %t52 = load ptr, ptr %l20, !tbaa !29
  %t53 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t52, i32 0, i32 7
  store i64 %t50, ptr %t53, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aorStore_3e_2eRunF_Hfb62abbaadc4bc18a4ac1ddebfb1ceda(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca ptr
  %l9 = alloca i1
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l26 = alloca ptr
  %l30 = alloca i64
  %l34 = alloca { i64, ptr }
  %rv = alloca { i32, { i64, ptr } }
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %l1, !tbaa !24
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t7, i32 0, i32 7
  %t10 = load i64, ptr %t9, !tbaa !24
  %t13 = icmp sge i64 %t6, %t10
  br i1 %t13, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb3
bb2:
  %t15 = load i64, ptr %l1, !tbaa !24
  %t17 = icmp slt i64 %t15, 0
  store i1 %t17, ptr %l9, !tbaa !21
  br label %bb3
bb3:
  %t19 = load i1, ptr %l9, !tbaa !21
  br i1 %t19, label %bb4, label %bb5
bb4:
  %t21 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t21, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t24 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t22, i32 0, i32 2
  %t25 = load i64, ptr %t24, !tbaa !24
  %t27 = icmp eq i64 %t25, 1
  br i1 %t27, label %bb7, label %bb8
bb7:
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t31 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t29, i32 0, i32 1
  %t32 = load { i64, ptr }, ptr %t31, !tbaa !27
  store { i64, ptr } %t32, ptr %l17, !tbaa !27
  %t33 = load i64, ptr %l1, !tbaa !24
  store i64 %t33, ptr %l18, !tbaa !24
  %t34 = load ptr, ptr %l2, !tbaa !29
  %t36 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t34, i32 0, i32 5
  %t37 = load i64, ptr %t36, !tbaa !24
  store i64 %t37, ptr %l20, !tbaa !24
  %t38 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 0
  store i64 %t39, ptr %l21, !tbaa !24
  %t40 = load i64, ptr %l18, !tbaa !24
  %t41 = icmp sge i64 %t40, 0
  br i1 %t41, label %bb9, label %bb10
bb8:
  br label %bb15
bb9:
  %t43 = load i64, ptr %l18, !tbaa !24
  %t44 = load i64, ptr %l20, !tbaa !24
  %t45 = icmp sle i64 %t43, %t44
  br i1 %t45, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_3d1565619ec04221_d95d92e50b56128d)
  unreachable
bb11:
  %t47 = load i64, ptr %l20, !tbaa !24
  %t48 = load i64, ptr %l21, !tbaa !24
  %t49 = icmp sle i64 %t47, %t48
  br i1 %t49, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_3d1565619ec04221_d95d92e50b56128d)
  unreachable
bb13:
  %t51 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = load i64, ptr %l18, !tbaa !24
  %t54 = load i64, ptr %l20, !tbaa !24
  %t55 = getelementptr %"compiler/free:orStore", ptr %t52, i64 %t53
  %t56 = sub i64 %t54, %t53
  %t57 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t55, 1
  %t60 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t58, 1
  store { i32, { i64, ptr } } %t60, ptr %rv
  br label %ret
bb14:
  call void @__olang_check_failed(ptr @olang_loc_3d1565619ec04221_d95d92e50b56128d)
  unreachable
bb15:
  %t61 = load ptr, ptr %l2, !tbaa !29
  store ptr %t61, ptr %l26, !tbaa !29
  %t62 = load i64, ptr %l1, !tbaa !24
  %t63 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t66 = add i64 %t62, %t63
  %t68 = call i64 @std_2fprelude_2flist_2ehighBit(i64 %t66)
  store i64 %t68, ptr %l30
  br label %bb16
bb16:
  %t69 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunkLog, !tbaa !24
  %t70 = load i64, ptr %l30, !tbaa !24
  %t72 = sub i64 %t70, %t69
  %t73 = load i64, ptr %l1, !tbaa !24
  %t74 = load ptr, ptr %l26, !tbaa !29
  %t77 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2ffree_3aorStore_3e_2_H4cc6ae66f2a64482e77b08fe0c638376(ptr %v0, ptr %t74, i64 %t72, i64 %t73)
  store { i64, ptr } %t77, ptr %l34
  br label %bb17
bb17:
  %t78 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t79 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t78, 1
  store { i32, { i64, ptr } } %t79, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local %"compiler/free:reason" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3areason_3e_2eAt_3ccompiler_2ffree_3areason_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l9 = alloca { i64, ptr }
  %l16 = alloca i64
  %l21 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l26 = alloca i64
  %rv = alloca %"compiler/free:reason"
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t5 = icmp slt i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t7, i32 0, i32 0
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t10, i32 0, i32 1
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  store { i64, ptr } %t13, ptr %l9, !tbaa !27
  %t14 = load i64, ptr %l1, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr %"compiler/free:reason", ptr %t17, i64 %t14
  %t19 = load %"compiler/free:reason", ptr %t18
  store %"compiler/free:reason" %t19, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t21 = load i64, ptr %l1, !tbaa !24
  %t22 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t25 = add i64 %t21, %t22
  store i64 %t25, ptr %l2, !tbaa !24
  %t27 = load i64, ptr %l2, !tbaa !24
  %t29 = call i64 @std_2fprelude_2flist_2ehighBit(i64 %t27)
  store i64 %t29, ptr %l16
  br label %bb4
bb4:
  %t30 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunkLog, !tbaa !24
  %t31 = load i64, ptr %l16, !tbaa !24
  %t33 = sub i64 %t31, %t30
  store i64 %t33, ptr %l3, !tbaa !24
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t35, i32 0, i32 0
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t38, i32 0, i32 0
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  store { i64, ptr } %t41, ptr %l21, !tbaa !27
  %t42 = load i64, ptr %l3, !tbaa !24
  %t44 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %t45, i64 %t42
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !37
  store { i64, ptr } %t47, ptr %l23, !tbaa !27
  %t48 = load i64, ptr %l2, !tbaa !24
  %t49 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t50 = load i64, ptr %l3, !tbaa !24
  store i64 %t50, ptr %l26, !tbaa !24
  %t52 = load i64, ptr %l26, !tbaa !24
  %t53 = load i64, ptr %l26, !tbaa !24
  %t54 = shl i64 %t49, %t53
  %t57 = sub i64 %t48, %t54
  %t59 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr %"compiler/free:reason", ptr %t60, i64 %t57
  %t62 = load %"compiler/free:reason", ptr %t61
  store %"compiler/free:reason" %t62, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/free:reason", ptr %rv
  ret %"compiler/free:reason" %rr
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3areason_3e_2ePush_3ccompiler_2ffree_3areason_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:reason" %a1) #0 {
entry:
  %l1 = alloca %"compiler/free:reason"
  %l2 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l20 = alloca ptr
  store %"compiler/free:reason" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t6, i32 0, i32 5
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t10, i32 0, i32 6
  %t13 = load i64, ptr %t12, !tbaa !24
  %t16 = icmp eq i64 %t9, %t13
  br i1 %t16, label %bb1, label %bb2
bb1:
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t19 = load %"compiler/free:reason", ptr %l1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2ffree_3areason_3e_2e_H6cbe162faf313bd3502650ddb9f1912a(ptr %v0, ptr %v1, ptr %t18, %"compiler/free:reason" %t19)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t24 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t22, i32 0, i32 4
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  store { i64, ptr } %t25, ptr %l13, !tbaa !27
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t28 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t26, i32 0, i32 5
  %t29 = load i64, ptr %t28, !tbaa !24
  %t30 = load %"compiler/free:reason", ptr %l1
  %t33 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr %"compiler/free:reason", ptr %t34, i64 %t29
  store %"compiler/free:reason" %t30, ptr %t35
  %t36 = load ptr, ptr %l2, !tbaa !29
  store ptr %t36, ptr %l17, !tbaa !29
  %t37 = load ptr, ptr %l17, !tbaa !29
  %t38 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t37, i32 0, i32 5
  %t39 = load i64, ptr %t38, !tbaa !24
  %t41 = add i64 %t39, 1
  %t43 = load ptr, ptr %l17, !tbaa !29
  %t44 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t43, i32 0, i32 5
  store i64 %t41, ptr %t44, !tbaa !24
  %t45 = load ptr, ptr %l2, !tbaa !29
  store ptr %t45, ptr %l20, !tbaa !29
  %t46 = load ptr, ptr %l20, !tbaa !29
  %t47 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t46, i32 0, i32 7
  %t48 = load i64, ptr %t47, !tbaa !24
  %t50 = add i64 %t48, 1
  %t52 = load ptr, ptr %l20, !tbaa !29
  %t53 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t52, i32 0, i32 7
  store i64 %t50, ptr %t53, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3areason_3e_2eSetAt_3ccompiler_2ffree_3areason_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/free:reason" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/free:reason"
  %l3 = alloca i64
  %l4 = alloca i64
  %l10 = alloca { i64, ptr }
  %l17 = alloca i64
  %l22 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l27 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/free:reason" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t5 = icmp slt i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t7, i32 0, i32 0
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t10, i32 0, i32 1
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  store { i64, ptr } %t13, ptr %l10, !tbaa !27
  %t14 = load i64, ptr %l1, !tbaa !24
  %t15 = load %"compiler/free:reason", ptr %l2
  %t18 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr %"compiler/free:reason", ptr %t19, i64 %t14
  store %"compiler/free:reason" %t15, ptr %t20
  br label %ret
bb2:
  br label %bb3
bb3:
  %t21 = load i64, ptr %l1, !tbaa !24
  %t22 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t25 = add i64 %t21, %t22
  store i64 %t25, ptr %l3, !tbaa !24
  %t27 = load i64, ptr %l3, !tbaa !24
  %t29 = call i64 @std_2fprelude_2flist_2ehighBit(i64 %t27)
  store i64 %t29, ptr %l17
  br label %bb4
bb4:
  %t30 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunkLog, !tbaa !24
  %t31 = load i64, ptr %l17, !tbaa !24
  %t33 = sub i64 %t31, %t30
  store i64 %t33, ptr %l4, !tbaa !24
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t35, i32 0, i32 0
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t38, i32 0, i32 0
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  store { i64, ptr } %t41, ptr %l22, !tbaa !27
  %t42 = load i64, ptr %l4, !tbaa !24
  %t44 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %t45, i64 %t42
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !37
  store { i64, ptr } %t47, ptr %l24, !tbaa !27
  %t48 = load i64, ptr %l3, !tbaa !24
  %t49 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t50 = load i64, ptr %l4, !tbaa !24
  store i64 %t50, ptr %l27, !tbaa !24
  %t52 = load i64, ptr %l27, !tbaa !24
  %t53 = load i64, ptr %l27, !tbaa !24
  %t54 = shl i64 %t49, %t53
  %t57 = sub i64 %t48, %t54
  %t58 = load %"compiler/free:reason", ptr %l2
  %t61 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr %"compiler/free:reason", ptr %t62, i64 %t57
  store %"compiler/free:reason" %t58, ptr %t63
  br label %ret
ret:
  ret void
}

define dso_local i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3astore_3e_2eLen_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
  ret i64 %r
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3astore_3e_2ePush_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:store" %a1) #0 {
entry:
  %l1 = alloca %"compiler/free:store"
  %l2 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l20 = alloca ptr
  store %"compiler/free:store" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t6, i32 0, i32 5
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t10, i32 0, i32 6
  %t13 = load i64, ptr %t12, !tbaa !24
  %t16 = icmp eq i64 %t9, %t13
  br i1 %t16, label %bb1, label %bb2
bb1:
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t19 = load %"compiler/free:store", ptr %l1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2ffree_3astore_3e_2egrow_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v1, ptr %t18, %"compiler/free:store" %t19)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t24 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t22, i32 0, i32 4
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  store { i64, ptr } %t25, ptr %l13, !tbaa !27
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t28 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t26, i32 0, i32 5
  %t29 = load i64, ptr %t28, !tbaa !24
  %t30 = load %"compiler/free:store", ptr %l1
  %t33 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr %"compiler/free:store", ptr %t34, i64 %t29
  store %"compiler/free:store" %t30, ptr %t35
  %t36 = load ptr, ptr %l2, !tbaa !29
  store ptr %t36, ptr %l17, !tbaa !29
  %t37 = load ptr, ptr %l17, !tbaa !29
  %t38 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t37, i32 0, i32 5
  %t39 = load i64, ptr %t38, !tbaa !24
  %t41 = add i64 %t39, 1
  %t43 = load ptr, ptr %l17, !tbaa !29
  %t44 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t43, i32 0, i32 5
  store i64 %t41, ptr %t44, !tbaa !24
  %t45 = load ptr, ptr %l2, !tbaa !29
  store ptr %t45, ptr %l20, !tbaa !29
  %t46 = load ptr, ptr %l20, !tbaa !29
  %t47 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t46, i32 0, i32 7
  %t48 = load i64, ptr %t47, !tbaa !24
  %t50 = add i64 %t48, 1
  %t52 = load ptr, ptr %l20, !tbaa !29
  %t53 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t52, i32 0, i32 7
  store i64 %t50, ptr %t53, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3astore_3e_2eRunFrom_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca ptr
  %l9 = alloca i1
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l26 = alloca ptr
  %l30 = alloca i64
  %l34 = alloca { i64, ptr }
  %rv = alloca { i32, { i64, ptr } }
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %l1, !tbaa !24
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t7, i32 0, i32 7
  %t10 = load i64, ptr %t9, !tbaa !24
  %t13 = icmp sge i64 %t6, %t10
  br i1 %t13, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb3
bb2:
  %t15 = load i64, ptr %l1, !tbaa !24
  %t17 = icmp slt i64 %t15, 0
  store i1 %t17, ptr %l9, !tbaa !21
  br label %bb3
bb3:
  %t19 = load i1, ptr %l9, !tbaa !21
  br i1 %t19, label %bb4, label %bb5
bb4:
  %t21 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t21, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t24 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t22, i32 0, i32 2
  %t25 = load i64, ptr %t24, !tbaa !24
  %t27 = icmp eq i64 %t25, 1
  br i1 %t27, label %bb7, label %bb8
bb7:
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t31 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t29, i32 0, i32 1
  %t32 = load { i64, ptr }, ptr %t31, !tbaa !27
  store { i64, ptr } %t32, ptr %l17, !tbaa !27
  %t33 = load i64, ptr %l1, !tbaa !24
  store i64 %t33, ptr %l18, !tbaa !24
  %t34 = load ptr, ptr %l2, !tbaa !29
  %t36 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t34, i32 0, i32 5
  %t37 = load i64, ptr %t36, !tbaa !24
  store i64 %t37, ptr %l20, !tbaa !24
  %t38 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 0
  store i64 %t39, ptr %l21, !tbaa !24
  %t40 = load i64, ptr %l18, !tbaa !24
  %t41 = icmp sge i64 %t40, 0
  br i1 %t41, label %bb9, label %bb10
bb8:
  br label %bb15
bb9:
  %t43 = load i64, ptr %l18, !tbaa !24
  %t44 = load i64, ptr %l20, !tbaa !24
  %t45 = icmp sle i64 %t43, %t44
  br i1 %t45, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_e33b06e661fe66ae_242f485233980172)
  unreachable
bb11:
  %t47 = load i64, ptr %l20, !tbaa !24
  %t48 = load i64, ptr %l21, !tbaa !24
  %t49 = icmp sle i64 %t47, %t48
  br i1 %t49, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_e33b06e661fe66ae_242f485233980172)
  unreachable
bb13:
  %t51 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = load i64, ptr %l18, !tbaa !24
  %t54 = load i64, ptr %l20, !tbaa !24
  %t55 = getelementptr %"compiler/free:store", ptr %t52, i64 %t53
  %t56 = sub i64 %t54, %t53
  %t57 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t55, 1
  %t60 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t58, 1
  store { i32, { i64, ptr } } %t60, ptr %rv
  br label %ret
bb14:
  call void @__olang_check_failed(ptr @olang_loc_e33b06e661fe66ae_242f485233980172)
  unreachable
bb15:
  %t61 = load ptr, ptr %l2, !tbaa !29
  store ptr %t61, ptr %l26, !tbaa !29
  %t62 = load i64, ptr %l1, !tbaa !24
  %t63 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t66 = add i64 %t62, %t63
  %t68 = call i64 @std_2fprelude_2flist_2ehighBit(i64 %t66)
  store i64 %t68, ptr %l30
  br label %bb16
bb16:
  %t69 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunkLog, !tbaa !24
  %t70 = load i64, ptr %l30, !tbaa !24
  %t72 = sub i64 %t70, %t69
  %t73 = load i64, ptr %l1, !tbaa !24
  %t74 = load ptr, ptr %l26, !tbaa !29
  %t77 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2ffree_3astore_3e_2er_H8f5382166bb0516c64c843418d12825c(ptr %v0, ptr %t74, i64 %t72, i64 %t73)
  store { i64, ptr } %t77, ptr %l34
  br label %bb17
bb17:
  %t78 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t79 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t78, 1
  store { i32, { i64, ptr } } %t79, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H082aedcd3ddb8fe82d6ff12d18e6e8d5(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %r = tail call { i32, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H78ccce95e6ef2f62693281865bce11fb(ptr %v0, ptr %v1, ptr %a0)
  ret { i32, ptr } %r
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H2607a290a254b1368332c2620bcac78c(ptr %v0, ptr %a0) #0 {
entry:
  tail call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aDecl_26_3e_2eClear_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %a0)
  ret void
}

define dso_local ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H68b172a457d32a9e162e965ccea2aab6(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %r = tail call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
  ret ptr %r
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H80281abdeb8e6e8df4d34cf6bb2c83d9(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  tail call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcond_3aGlobal_26_3e_2ePu_H886a66ffa23940650f82c48d9485539c(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
  ret void
}

define dso_local ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H96e9eb9990b7b2982627078c49255e88(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %r = tail call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
  ret ptr %r
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_Hd29545d6ce80f0b71db83a570b969f39(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  tail call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aDecl_26_3e_2eTrunc_H4f6d6844736ef1cf1f5d4d22c2fa42e3(ptr %v0, ptr %a0, i64 %a1)
  ret void
}

define dso_local { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_Hd2f0d304a9aa6fbe6d847d83ccff30fa(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %r = tail call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcond_3aGlobal_26_3e_2eRu_Hdae492cbfddb0b6a70eec6865333e543(ptr %v0, ptr %a0, i64 %a1)
  ret { i32, { i64, ptr } } %r
}

define dso_local i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_He8628b0a6160e3784b3615fe3f392582(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
  ret i64 %r
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_Hf6bbcd606af6c869015b58a6b615b2ae(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  tail call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcond_3aGlobal_26_3e_2ePu_H886a66ffa23940650f82c48d9485539c(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
  ret void
}

define dso_local i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3cI64_3_H12039caf93b9d99069d4e03abd3c3b80(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
  ret i64 %r
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3cI64_3_H1bfd72835118c4a69ac66e4bcdbec3db(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l9 = alloca { i64, ptr }
  %l16 = alloca i64
  %l21 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l26 = alloca i64
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t5 = icmp slt i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t7, i32 0, i32 0
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t10, i32 0, i32 1
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  store { i64, ptr } %t13, ptr %l9, !tbaa !27
  %t14 = load i64, ptr %l1, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t17, i64 %t14
  %t19 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t18
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t19, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t21 = load i64, ptr %l1, !tbaa !24
  %t22 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t25 = add i64 %t21, %t22
  store i64 %t25, ptr %l2, !tbaa !24
  %t27 = load i64, ptr %l2, !tbaa !24
  %t29 = call i64 @std_2fprelude_2flist_2ehighBit(i64 %t27)
  store i64 %t29, ptr %l16
  br label %bb4
bb4:
  %t30 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunkLog, !tbaa !24
  %t31 = load i64, ptr %l16, !tbaa !24
  %t33 = sub i64 %t31, %t30
  store i64 %t33, ptr %l3, !tbaa !24
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t35, i32 0, i32 0
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t38, i32 0, i32 0
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  store { i64, ptr } %t41, ptr %l21, !tbaa !27
  %t42 = load i64, ptr %l3, !tbaa !24
  %t44 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %t45, i64 %t42
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !37
  store { i64, ptr } %t47, ptr %l23, !tbaa !27
  %t48 = load i64, ptr %l2, !tbaa !24
  %t49 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t50 = load i64, ptr %l3, !tbaa !24
  store i64 %t50, ptr %l26, !tbaa !24
  %t52 = load i64, ptr %l26, !tbaa !24
  %t53 = load i64, ptr %l26, !tbaa !24
  %t54 = shl i64 %t49, %t53
  %t57 = sub i64 %t48, %t54
  %t59 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t60, i64 %t57
  %t62 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t61
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t62, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3cI64_3_H514c3278d648f49337aafc4c9fcf3b34(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1) #0 {
entry:
  %l1 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l2 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l20 = alloca ptr
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t6, i32 0, i32 5
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t10, i32 0, i32 6
  %t13 = load i64, ptr %t12, !tbaa !24
  %t16 = icmp eq i64 %t9, %t13
  br i1 %t16, label %bb1, label %bb2
bb1:
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t19 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cstd_2fprelude_2flist_3aList_3c_H813f9a021eaad905003370f9e15e02df(ptr %v0, ptr %v1, ptr %t18, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t19)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t24 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t22, i32 0, i32 4
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  store { i64, ptr } %t25, ptr %l13, !tbaa !27
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t28 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t26, i32 0, i32 5
  %t29 = load i64, ptr %t28, !tbaa !24
  %t30 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l1
  %t33 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t34, i64 %t29
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t30, ptr %t35
  %t36 = load ptr, ptr %l2, !tbaa !29
  store ptr %t36, ptr %l17, !tbaa !29
  %t37 = load ptr, ptr %l17, !tbaa !29
  %t38 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t37, i32 0, i32 5
  %t39 = load i64, ptr %t38, !tbaa !24
  %t41 = add i64 %t39, 1
  %t43 = load ptr, ptr %l17, !tbaa !29
  %t44 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t43, i32 0, i32 5
  store i64 %t41, ptr %t44, !tbaa !24
  %t45 = load ptr, ptr %l2, !tbaa !29
  store ptr %t45, ptr %l20, !tbaa !29
  %t46 = load ptr, ptr %l20, !tbaa !29
  %t47 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t46, i32 0, i32 7
  %t48 = load i64, ptr %t47, !tbaa !24
  %t50 = add i64 %t48, 1
  %t52 = load ptr, ptr %l20, !tbaa !29
  %t53 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t52, i32 0, i32 7
  store i64 %t50, ptr %t53, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3cI64_3_Hfda32f46ad718b1ec245a2f2facf857a(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca ptr
  %l9 = alloca i1
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l26 = alloca ptr
  %l30 = alloca i64
  %l34 = alloca { i64, ptr }
  %rv = alloca { i32, { i64, ptr } }
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %l1, !tbaa !24
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t7, i32 0, i32 7
  %t10 = load i64, ptr %t9, !tbaa !24
  %t13 = icmp sge i64 %t6, %t10
  br i1 %t13, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb3
bb2:
  %t15 = load i64, ptr %l1, !tbaa !24
  %t17 = icmp slt i64 %t15, 0
  store i1 %t17, ptr %l9, !tbaa !21
  br label %bb3
bb3:
  %t19 = load i1, ptr %l9, !tbaa !21
  br i1 %t19, label %bb4, label %bb5
bb4:
  %t21 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t21, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t24 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t22, i32 0, i32 2
  %t25 = load i64, ptr %t24, !tbaa !24
  %t27 = icmp eq i64 %t25, 1
  br i1 %t27, label %bb7, label %bb8
bb7:
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t31 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t29, i32 0, i32 1
  %t32 = load { i64, ptr }, ptr %t31, !tbaa !27
  store { i64, ptr } %t32, ptr %l17, !tbaa !27
  %t33 = load i64, ptr %l1, !tbaa !24
  store i64 %t33, ptr %l18, !tbaa !24
  %t34 = load ptr, ptr %l2, !tbaa !29
  %t36 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t34, i32 0, i32 5
  %t37 = load i64, ptr %t36, !tbaa !24
  store i64 %t37, ptr %l20, !tbaa !24
  %t38 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 0
  store i64 %t39, ptr %l21, !tbaa !24
  %t40 = load i64, ptr %l18, !tbaa !24
  %t41 = icmp sge i64 %t40, 0
  br i1 %t41, label %bb9, label %bb10
bb8:
  br label %bb15
bb9:
  %t43 = load i64, ptr %l18, !tbaa !24
  %t44 = load i64, ptr %l20, !tbaa !24
  %t45 = icmp sle i64 %t43, %t44
  br i1 %t45, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_42938c78567cc42d_28e37a4065999d81)
  unreachable
bb11:
  %t47 = load i64, ptr %l20, !tbaa !24
  %t48 = load i64, ptr %l21, !tbaa !24
  %t49 = icmp sle i64 %t47, %t48
  br i1 %t49, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_42938c78567cc42d_28e37a4065999d81)
  unreachable
bb13:
  %t51 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = load i64, ptr %l18, !tbaa !24
  %t54 = load i64, ptr %l20, !tbaa !24
  %t55 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t52, i64 %t53
  %t56 = sub i64 %t54, %t53
  %t57 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t55, 1
  %t60 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t58, 1
  store { i32, { i64, ptr } } %t60, ptr %rv
  br label %ret
bb14:
  call void @__olang_check_failed(ptr @olang_loc_42938c78567cc42d_28e37a4065999d81)
  unreachable
bb15:
  %t61 = load ptr, ptr %l2, !tbaa !29
  store ptr %t61, ptr %l26, !tbaa !29
  %t62 = load i64, ptr %l1, !tbaa !24
  %t63 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t66 = add i64 %t62, %t63
  %t68 = call i64 @std_2fprelude_2flist_2ehighBit(i64 %t66)
  store i64 %t68, ptr %l30
  br label %bb16
bb16:
  %t69 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunkLog, !tbaa !24
  %t70 = load i64, ptr %l30, !tbaa !24
  %t72 = sub i64 %t70, %t69
  %t73 = load i64, ptr %l1, !tbaa !24
  %t74 = load ptr, ptr %l26, !tbaa !29
  %t77 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cstd_2fprelude_2flist_3aList_3c_Hd153ccd47b7407ea95231a0cf1039694(ptr %v0, ptr %t74, i64 %t72, i64 %t73)
  store { i64, ptr } %t77, ptr %l34
  br label %bb17
bb17:
  %t78 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t79 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t78, 1
  store { i32, { i64, ptr } } %t79, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2ffree_3aleaf_3e_2egrow_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:leaf" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/free:leaf"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l14 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca %"compiler/free:leaf"
  %l36 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l50 = alloca i64
  %l52 = alloca { i64, ptr }
  %l61 = alloca i64
  %l64 = alloca i64
  %l82 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l95 = alloca i64
  %l98 = alloca i64
  %l99 = alloca i64
  %l100 = alloca %"compiler/free:leaf"
  %l106 = alloca { i64, ptr }
  %l110 = alloca ptr
  %l113 = alloca ptr
  %s9 = alloca %olang.scope
  %t54 = alloca i64
  %t104 = alloca i64
  %t137 = alloca i64
  %t253 = alloca i64
  store ptr %a0, ptr %l0
  store %"compiler/free:leaf" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t1, i32 0, i32 2
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t5, i32 0, i32 3
  %t8 = load i64, ptr %t7, !tbaa !24
  %t11 = icmp slt i64 %t4, %t8
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l14, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t15, i32 0, i32 2
  %t18 = load i64, ptr %t17, !tbaa !24
  %t21 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %t14, i64 %t18)
  store { i64, ptr } %t21, ptr %l18
  br label %bb3
bb2:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t22, i32 0, i32 3
  %t25 = load i64, ptr %t24, !tbaa !24
  %t27 = icmp eq i64 %t25, 0
  br i1 %t27, label %bb4, label %bb5
bb3:
  %t29 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t30 = load ptr, ptr %l14, !tbaa !29
  %t31 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t30, i32 0, i32 4
  store { i64, ptr } %t29, ptr %t31, !tbaa !27
  br label %bb41
bb4:
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l22, !tbaa !29
  %t33 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  store i64 %t33, ptr %l23, !tbaa !24
  %t34 = load %"compiler/free:leaf", ptr %l1
  store %"compiler/free:leaf" %t34, ptr %l24
  %t35 = load i64, ptr %l23, !tbaa !24
  %t36 = icmp sge i64 %t35, 0
  br i1 %t36, label %bb6, label %bb7
bb5:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t38, i32 0, i32 0
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t45 = icmp eq i64 %t43, 0
  br i1 %t45, label %bb10, label %bb11
bb6:
  %t47 = load i64, ptr %l23, !tbaa !24
  %t48 = icmp sle i64 %t47, 384307168202282325
  br i1 %t48, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_67599e04f7a3aec5_5cba14342a35ebb9)
  unreachable
bb8:
  %t50 = load i64, ptr %l23, !tbaa !24
  %t51 = mul i64 %t50, 24
  %t52 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t51)
  %t53 = load %"compiler/free:leaf", ptr %l24
  store i64 0, ptr %t54
  br label %fill.55
fill.55:
  %t58 = load i64, ptr %t54
  %t59 = icmp slt i64 %t58, %t50
  br i1 %t59, label %fillb.56, label %filld.57
fillb.56:
  %t60 = getelementptr %"compiler/free:leaf", ptr %t52, i64 %t58
  store %"compiler/free:leaf" %t53, ptr %t60
  %t61 = add i64 %t58, 1
  store i64 %t61, ptr %t54
  br label %fill.55
filld.57:
  %t62 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t52, 1
  %t65 = load ptr, ptr %l22, !tbaa !29
  %t66 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t65, i32 0, i32 1
  store { i64, ptr } %t63, ptr %t66, !tbaa !27
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t68, i32 0, i32 1
  %t71 = load { i64, ptr }, ptr %t70, !tbaa !27
  %t74 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t67, i32 0, i32 4
  store { i64, ptr } %t71, ptr %t74, !tbaa !27
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t75, i32 0, i32 3
  store i64 1, ptr %t77, !tbaa !24
  br label %bb40
bb9:
  call void @__olang_check_failed(ptr @olang_loc_67599e04f7a3aec5_5cba14342a35ebb9)
  unreachable
bb10:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l36, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t79, i32 0, i32 1
  %t82 = load { i64, ptr }, ptr %t81, !tbaa !27
  store { i64, ptr } %t82, ptr %l38, !tbaa !27
  %t83 = icmp sge i64 4, 0
  br i1 %t83, label %bb12, label %bb13
bb11:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t85, i32 0, i32 3
  %t88 = load i64, ptr %t87, !tbaa !24
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t89, i32 0, i32 0
  %t92 = load { i64, ptr }, ptr %t91, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t92, 0
  %t97 = icmp eq i64 %t88, %t94
  br i1 %t97, label %bb16, label %bb17
bb12:
  %t99 = icmp sle i64 4, 576460752303423487
  br i1 %t99, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_f4a2a7f94f31dd58_5a3ff81dd1e2722c)
  unreachable
bb14:
  %t101 = mul i64 4, 16
  %t102 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t101)
  %t103 = load { i64, ptr }, ptr %l38, !tbaa !27
  store i64 0, ptr %t104
  br label %fill.105
fill.105:
  %t108 = load i64, ptr %t104
  %t109 = icmp slt i64 %t108, 4
  br i1 %t109, label %fillb.106, label %filld.107
fillb.106:
  %t110 = getelementptr { i64, ptr }, ptr %t102, i64 %t108
  store { i64, ptr } %t103, ptr %t110
  %t111 = add i64 %t108, 1
  store i64 %t111, ptr %t104
  br label %fill.105
filld.107:
  %t112 = insertvalue { i64, ptr } undef, i64 4, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t102, 1
  %t115 = load ptr, ptr %l36, !tbaa !29
  %t116 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t115, i32 0, i32 0
  store { i64, ptr } %t113, ptr %t116, !tbaa !27
  br label %bb35
bb15:
  call void @__olang_check_failed(ptr @olang_loc_f4a2a7f94f31dd58_5a3ff81dd1e2722c)
  unreachable
bb16:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t117, i32 0, i32 3
  %t120 = load i64, ptr %t119, !tbaa !24
  %t122 = mul i64 %t120, 2
  store i64 %t122, ptr %l50, !tbaa !24
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t123, i32 0, i32 1
  %t126 = load { i64, ptr }, ptr %t125, !tbaa !27
  store { i64, ptr } %t126, ptr %l52, !tbaa !27
  %t127 = load i64, ptr %l50, !tbaa !24
  %t128 = icmp sge i64 %t127, 0
  br i1 %t128, label %bb18, label %bb19
bb17:
  br label %bb34
bb18:
  %t130 = load i64, ptr %l50, !tbaa !24
  %t131 = icmp sle i64 %t130, 576460752303423487
  br i1 %t131, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_b66ad08785da183b_ab73eb0ba62b5c8f)
  unreachable
bb20:
  %t133 = load i64, ptr %l50, !tbaa !24
  %t134 = mul i64 %t133, 16
  %t135 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t134)
  %t136 = load { i64, ptr }, ptr %l52, !tbaa !27
  store i64 0, ptr %t137
  br label %fill.138
fill.138:
  %t141 = load i64, ptr %t137
  %t142 = icmp slt i64 %t141, %t133
  br i1 %t142, label %fillb.139, label %filld.140
fillb.139:
  %t143 = getelementptr { i64, ptr }, ptr %t135, i64 %t141
  store { i64, ptr } %t136, ptr %t143
  %t144 = add i64 %t141, 1
  store i64 %t144, ptr %t137
  br label %fill.138
filld.140:
  %t145 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t146 = insertvalue { i64, ptr } %t145, ptr %t135, 1
  store { i64, ptr } %t146, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t148, i32 0, i32 3
  %t151 = load i64, ptr %t150, !tbaa !24
  store i64 %t151, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t153 = load i64, ptr %l4, !tbaa !24
  %t154 = load i64, ptr %l3, !tbaa !24
  %t157 = icmp sgt i64 %t153, %t154
  br i1 %t157, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_b66ad08785da183b_ab73eb0ba62b5c8f)
  unreachable
bb22:
  %t159 = load i64, ptr %l5, !tbaa !24
  %t161 = icmp sgt i64 %t159, 0
  br i1 %t161, label %bb24, label %bb25
bb23:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb27
bb24:
  %t163 = load i64, ptr %l4, !tbaa !24
  %t164 = load i64, ptr %l3, !tbaa !24
  %t167 = sub i64 %t163, %t164
  %t168 = load i64, ptr %l5, !tbaa !24
  %t171 = add i64 %t167, %t168
  %t173 = sub i64 %t171, 1
  %t174 = load i64, ptr %l5, !tbaa !24
  %t177 = sdiv i64 %t173, %t174
  store i64 %t177, ptr %l64, !tbaa !24
  br label %bb26
bb25:
  store i64 0, ptr %l64, !tbaa !24
  br label %bb26
bb26:
  %t179 = load i64, ptr %l64, !tbaa !24
  store i64 %t179, ptr %l61, !tbaa !24
  br label %bb27
bb27:
  %t180 = load i64, ptr %l61, !tbaa !24
  store i64 %t180, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb28
bb28:
  store %olang.scope zeroinitializer, ptr %s9
  %t181 = load i64, ptr %l7, !tbaa !24
  %t182 = load i64, ptr %l6, !tbaa !24
  %t185 = icmp slt i64 %t181, %t182
  %t187 = xor i1 %t185, true
  br i1 %t187, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s9)
  br label %bb33
bb30:
  br label %bb31
bb31:
  %t189 = load i64, ptr %l3, !tbaa !24
  %t190 = load i64, ptr %l7, !tbaa !24
  %t191 = load i64, ptr %l5, !tbaa !24
  %t194 = mul i64 %t190, %t191
  %t197 = add i64 %t189, %t194
  store i64 %t197, ptr %l8, !tbaa !24
  %t199 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t199, ptr %l82, !tbaa !27
  %t200 = load i64, ptr %l8, !tbaa !24
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t203 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t201, i32 0, i32 0
  %t204 = load { i64, ptr }, ptr %t203, !tbaa !27
  store { i64, ptr } %t204, ptr %l85, !tbaa !27
  %t205 = load i64, ptr %l8, !tbaa !24
  %t207 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !27
  %t209 = getelementptr { i64, ptr }, ptr %t208, i64 %t205
  %t210 = load { i64, ptr }, ptr %t209, !tbaa !37
  %t213 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !27
  %t215 = getelementptr { i64, ptr }, ptr %t214, i64 %t200
  store { i64, ptr } %t210, ptr %t215, !tbaa !37
  call void @__olang_scope_close(ptr %s9)
  br label %bb32
bb32:
  %t216 = load i64, ptr %l7, !tbaa !24
  %t218 = add i64 %t216, 1
  store i64 %t218, ptr %l7, !tbaa !24
  br label %bb28
bb33:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t224 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t220, i32 0, i32 0
  store { i64, ptr } %t221, ptr %t224, !tbaa !27
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t227 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t225, i32 0, i32 0
  %t228 = load { i64, ptr }, ptr %t227, !tbaa !27
  store { i64, ptr } %t228, ptr %l93, !tbaa !27
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t229, i32 0, i32 3
  %t232 = load i64, ptr %t231, !tbaa !24
  store i64 %t232, ptr %l95, !tbaa !24
  %t233 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t236 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t234, i32 0, i32 3
  %t237 = load i64, ptr %t236, !tbaa !24
  store i64 %t237, ptr %l98, !tbaa !24
  %t239 = load i64, ptr %l98, !tbaa !24
  %t240 = load i64, ptr %l98, !tbaa !24
  %t241 = shl i64 %t233, %t240
  store i64 %t241, ptr %l99, !tbaa !24
  %t242 = load %"compiler/free:leaf", ptr %l1
  store %"compiler/free:leaf" %t242, ptr %l100
  %t243 = load i64, ptr %l99, !tbaa !24
  %t244 = icmp sge i64 %t243, 0
  br i1 %t244, label %bb36, label %bb37
bb36:
  %t246 = load i64, ptr %l99, !tbaa !24
  %t247 = icmp sle i64 %t246, 384307168202282325
  br i1 %t247, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_b919348cb7bcf4a6_9200da5e57d4033a)
  unreachable
bb38:
  %t249 = load i64, ptr %l99, !tbaa !24
  %t250 = mul i64 %t249, 24
  %t251 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t250)
  %t252 = load %"compiler/free:leaf", ptr %l100
  store i64 0, ptr %t253
  br label %fill.254
fill.254:
  %t257 = load i64, ptr %t253
  %t258 = icmp slt i64 %t257, %t249
  br i1 %t258, label %fillb.255, label %filld.256
fillb.255:
  %t259 = getelementptr %"compiler/free:leaf", ptr %t251, i64 %t257
  store %"compiler/free:leaf" %t252, ptr %t259
  %t260 = add i64 %t257, 1
  store i64 %t260, ptr %t253
  br label %fill.254
filld.256:
  %t261 = insertvalue { i64, ptr } undef, i64 %t249, 0
  %t262 = insertvalue { i64, ptr } %t261, ptr %t251, 1
  %t264 = load i64, ptr %l95, !tbaa !24
  %t265 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t266 = load ptr, ptr %t265, !tbaa !27
  %t267 = getelementptr { i64, ptr }, ptr %t266, i64 %t264
  store { i64, ptr } %t262, ptr %t267, !tbaa !37
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t271 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t269, i32 0, i32 0
  %t272 = load { i64, ptr }, ptr %t271, !tbaa !27
  store { i64, ptr } %t272, ptr %l106, !tbaa !27
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t273, i32 0, i32 3
  %t276 = load i64, ptr %t275, !tbaa !24
  %t278 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t279 = load ptr, ptr %t278, !tbaa !27
  %t280 = getelementptr { i64, ptr }, ptr %t279, i64 %t276
  %t281 = load { i64, ptr }, ptr %t280, !tbaa !37
  %t284 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t268, i32 0, i32 4
  store { i64, ptr } %t281, ptr %t284, !tbaa !27
  %t285 = load ptr, ptr %l0, !tbaa !29
  store ptr %t285, ptr %l110, !tbaa !29
  %t286 = load ptr, ptr %l110, !tbaa !29
  %t287 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t286, i32 0, i32 3
  %t288 = load i64, ptr %t287, !tbaa !24
  %t290 = add i64 %t288, 1
  %t292 = load ptr, ptr %l110, !tbaa !29
  %t293 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t292, i32 0, i32 3
  store i64 %t290, ptr %t293, !tbaa !24
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_b919348cb7bcf4a6_9200da5e57d4033a)
  unreachable
bb40:
  br label %bb41
bb41:
  %t294 = load ptr, ptr %l0, !tbaa !29
  store ptr %t294, ptr %l113, !tbaa !29
  %t295 = load ptr, ptr %l113, !tbaa !29
  %t296 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t295, i32 0, i32 2
  %t297 = load i64, ptr %t296, !tbaa !24
  %t299 = add i64 %t297, 1
  %t301 = load ptr, ptr %l113, !tbaa !29
  %t302 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t301, i32 0, i32 2
  store i64 %t299, ptr %t302, !tbaa !24
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t305 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t303, i32 0, i32 5
  store i64 0, ptr %t305, !tbaa !24
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t309 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t307, i32 0, i32 4
  %t310 = load { i64, ptr }, ptr %t309, !tbaa !27
  %t312 = extractvalue { i64, ptr } %t310, 0
  %t315 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t306, i32 0, i32 6
  store i64 %t312, ptr %t315, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2ffree_3aletGo_3e_2ec_Ha281cc64477ffd7d96d9ec8f005edd4d(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %r = tail call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %a0, i64 %a1)
  ret { i64, ptr } %r
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2ffree_3aletGo_3e_2egrow_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %a0, %"compiler/free:letGo" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/free:letGo"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l14 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca %"compiler/free:letGo"
  %l36 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l50 = alloca i64
  %l52 = alloca { i64, ptr }
  %l61 = alloca i64
  %l64 = alloca i64
  %l82 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l95 = alloca i64
  %l98 = alloca i64
  %l99 = alloca i64
  %l100 = alloca %"compiler/free:letGo"
  %l106 = alloca { i64, ptr }
  %l110 = alloca ptr
  %l113 = alloca ptr
  %s9 = alloca %olang.scope
  %t54 = alloca i64
  %t104 = alloca i64
  %t137 = alloca i64
  %t253 = alloca i64
  store ptr %a0, ptr %l0
  store %"compiler/free:letGo" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t1, i32 0, i32 2
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t5, i32 0, i32 3
  %t8 = load i64, ptr %t7, !tbaa !24
  %t11 = icmp slt i64 %t4, %t8
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l14, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t15, i32 0, i32 2
  %t18 = load i64, ptr %t17, !tbaa !24
  %t21 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %t14, i64 %t18)
  store { i64, ptr } %t21, ptr %l18
  br label %bb3
bb2:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t22, i32 0, i32 3
  %t25 = load i64, ptr %t24, !tbaa !24
  %t27 = icmp eq i64 %t25, 0
  br i1 %t27, label %bb4, label %bb5
bb3:
  %t29 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t30 = load ptr, ptr %l14, !tbaa !29
  %t31 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t30, i32 0, i32 4
  store { i64, ptr } %t29, ptr %t31, !tbaa !27
  br label %bb41
bb4:
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l22, !tbaa !29
  %t33 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  store i64 %t33, ptr %l23, !tbaa !24
  %t34 = load %"compiler/free:letGo", ptr %l1
  store %"compiler/free:letGo" %t34, ptr %l24
  %t35 = load i64, ptr %l23, !tbaa !24
  %t36 = icmp sge i64 %t35, 0
  br i1 %t36, label %bb6, label %bb7
bb5:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t38, i32 0, i32 0
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t45 = icmp eq i64 %t43, 0
  br i1 %t45, label %bb10, label %bb11
bb6:
  %t47 = load i64, ptr %l23, !tbaa !24
  %t48 = icmp sle i64 %t47, 128102389400760775
  br i1 %t48, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_9f445d6dced55c2d_a774a5de7d698f11)
  unreachable
bb8:
  %t50 = load i64, ptr %l23, !tbaa !24
  %t51 = mul i64 %t50, 72
  %t52 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t51)
  %t53 = load %"compiler/free:letGo", ptr %l24
  store i64 0, ptr %t54
  br label %fill.55
fill.55:
  %t58 = load i64, ptr %t54
  %t59 = icmp slt i64 %t58, %t50
  br i1 %t59, label %fillb.56, label %filld.57
fillb.56:
  %t60 = getelementptr %"compiler/free:letGo", ptr %t52, i64 %t58
  store %"compiler/free:letGo" %t53, ptr %t60
  %t61 = add i64 %t58, 1
  store i64 %t61, ptr %t54
  br label %fill.55
filld.57:
  %t62 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t52, 1
  %t65 = load ptr, ptr %l22, !tbaa !29
  %t66 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t65, i32 0, i32 1
  store { i64, ptr } %t63, ptr %t66, !tbaa !27
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t68, i32 0, i32 1
  %t71 = load { i64, ptr }, ptr %t70, !tbaa !27
  %t74 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t67, i32 0, i32 4
  store { i64, ptr } %t71, ptr %t74, !tbaa !27
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t75, i32 0, i32 3
  store i64 1, ptr %t77, !tbaa !24
  br label %bb40
bb9:
  call void @__olang_check_failed(ptr @olang_loc_9f445d6dced55c2d_a774a5de7d698f11)
  unreachable
bb10:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l36, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t79, i32 0, i32 1
  %t82 = load { i64, ptr }, ptr %t81, !tbaa !27
  store { i64, ptr } %t82, ptr %l38, !tbaa !27
  %t83 = icmp sge i64 4, 0
  br i1 %t83, label %bb12, label %bb13
bb11:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t85, i32 0, i32 3
  %t88 = load i64, ptr %t87, !tbaa !24
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t89, i32 0, i32 0
  %t92 = load { i64, ptr }, ptr %t91, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t92, 0
  %t97 = icmp eq i64 %t88, %t94
  br i1 %t97, label %bb16, label %bb17
bb12:
  %t99 = icmp sle i64 4, 576460752303423487
  br i1 %t99, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_3854bdcccb1b1500_94da6c1dc62a0e04)
  unreachable
bb14:
  %t101 = mul i64 4, 16
  %t102 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t101)
  %t103 = load { i64, ptr }, ptr %l38, !tbaa !27
  store i64 0, ptr %t104
  br label %fill.105
fill.105:
  %t108 = load i64, ptr %t104
  %t109 = icmp slt i64 %t108, 4
  br i1 %t109, label %fillb.106, label %filld.107
fillb.106:
  %t110 = getelementptr { i64, ptr }, ptr %t102, i64 %t108
  store { i64, ptr } %t103, ptr %t110
  %t111 = add i64 %t108, 1
  store i64 %t111, ptr %t104
  br label %fill.105
filld.107:
  %t112 = insertvalue { i64, ptr } undef, i64 4, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t102, 1
  %t115 = load ptr, ptr %l36, !tbaa !29
  %t116 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t115, i32 0, i32 0
  store { i64, ptr } %t113, ptr %t116, !tbaa !27
  br label %bb35
bb15:
  call void @__olang_check_failed(ptr @olang_loc_3854bdcccb1b1500_94da6c1dc62a0e04)
  unreachable
bb16:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t117, i32 0, i32 3
  %t120 = load i64, ptr %t119, !tbaa !24
  %t122 = mul i64 %t120, 2
  store i64 %t122, ptr %l50, !tbaa !24
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t123, i32 0, i32 1
  %t126 = load { i64, ptr }, ptr %t125, !tbaa !27
  store { i64, ptr } %t126, ptr %l52, !tbaa !27
  %t127 = load i64, ptr %l50, !tbaa !24
  %t128 = icmp sge i64 %t127, 0
  br i1 %t128, label %bb18, label %bb19
bb17:
  br label %bb34
bb18:
  %t130 = load i64, ptr %l50, !tbaa !24
  %t131 = icmp sle i64 %t130, 576460752303423487
  br i1 %t131, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_136e985c1376dea3_8fab4d7ad3efe0e7)
  unreachable
bb20:
  %t133 = load i64, ptr %l50, !tbaa !24
  %t134 = mul i64 %t133, 16
  %t135 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t134)
  %t136 = load { i64, ptr }, ptr %l52, !tbaa !27
  store i64 0, ptr %t137
  br label %fill.138
fill.138:
  %t141 = load i64, ptr %t137
  %t142 = icmp slt i64 %t141, %t133
  br i1 %t142, label %fillb.139, label %filld.140
fillb.139:
  %t143 = getelementptr { i64, ptr }, ptr %t135, i64 %t141
  store { i64, ptr } %t136, ptr %t143
  %t144 = add i64 %t141, 1
  store i64 %t144, ptr %t137
  br label %fill.138
filld.140:
  %t145 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t146 = insertvalue { i64, ptr } %t145, ptr %t135, 1
  store { i64, ptr } %t146, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t148, i32 0, i32 3
  %t151 = load i64, ptr %t150, !tbaa !24
  store i64 %t151, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t153 = load i64, ptr %l4, !tbaa !24
  %t154 = load i64, ptr %l3, !tbaa !24
  %t157 = icmp sgt i64 %t153, %t154
  br i1 %t157, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_136e985c1376dea3_8fab4d7ad3efe0e7)
  unreachable
bb22:
  %t159 = load i64, ptr %l5, !tbaa !24
  %t161 = icmp sgt i64 %t159, 0
  br i1 %t161, label %bb24, label %bb25
bb23:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb27
bb24:
  %t163 = load i64, ptr %l4, !tbaa !24
  %t164 = load i64, ptr %l3, !tbaa !24
  %t167 = sub i64 %t163, %t164
  %t168 = load i64, ptr %l5, !tbaa !24
  %t171 = add i64 %t167, %t168
  %t173 = sub i64 %t171, 1
  %t174 = load i64, ptr %l5, !tbaa !24
  %t177 = sdiv i64 %t173, %t174
  store i64 %t177, ptr %l64, !tbaa !24
  br label %bb26
bb25:
  store i64 0, ptr %l64, !tbaa !24
  br label %bb26
bb26:
  %t179 = load i64, ptr %l64, !tbaa !24
  store i64 %t179, ptr %l61, !tbaa !24
  br label %bb27
bb27:
  %t180 = load i64, ptr %l61, !tbaa !24
  store i64 %t180, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb28
bb28:
  store %olang.scope zeroinitializer, ptr %s9
  %t181 = load i64, ptr %l7, !tbaa !24
  %t182 = load i64, ptr %l6, !tbaa !24
  %t185 = icmp slt i64 %t181, %t182
  %t187 = xor i1 %t185, true
  br i1 %t187, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s9)
  br label %bb33
bb30:
  br label %bb31
bb31:
  %t189 = load i64, ptr %l3, !tbaa !24
  %t190 = load i64, ptr %l7, !tbaa !24
  %t191 = load i64, ptr %l5, !tbaa !24
  %t194 = mul i64 %t190, %t191
  %t197 = add i64 %t189, %t194
  store i64 %t197, ptr %l8, !tbaa !24
  %t199 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t199, ptr %l82, !tbaa !27
  %t200 = load i64, ptr %l8, !tbaa !24
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t203 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t201, i32 0, i32 0
  %t204 = load { i64, ptr }, ptr %t203, !tbaa !27
  store { i64, ptr } %t204, ptr %l85, !tbaa !27
  %t205 = load i64, ptr %l8, !tbaa !24
  %t207 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !27
  %t209 = getelementptr { i64, ptr }, ptr %t208, i64 %t205
  %t210 = load { i64, ptr }, ptr %t209, !tbaa !37
  %t213 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !27
  %t215 = getelementptr { i64, ptr }, ptr %t214, i64 %t200
  store { i64, ptr } %t210, ptr %t215, !tbaa !37
  call void @__olang_scope_close(ptr %s9)
  br label %bb32
bb32:
  %t216 = load i64, ptr %l7, !tbaa !24
  %t218 = add i64 %t216, 1
  store i64 %t218, ptr %l7, !tbaa !24
  br label %bb28
bb33:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t224 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t220, i32 0, i32 0
  store { i64, ptr } %t221, ptr %t224, !tbaa !27
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t227 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t225, i32 0, i32 0
  %t228 = load { i64, ptr }, ptr %t227, !tbaa !27
  store { i64, ptr } %t228, ptr %l93, !tbaa !27
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t229, i32 0, i32 3
  %t232 = load i64, ptr %t231, !tbaa !24
  store i64 %t232, ptr %l95, !tbaa !24
  %t233 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t236 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t234, i32 0, i32 3
  %t237 = load i64, ptr %t236, !tbaa !24
  store i64 %t237, ptr %l98, !tbaa !24
  %t239 = load i64, ptr %l98, !tbaa !24
  %t240 = load i64, ptr %l98, !tbaa !24
  %t241 = shl i64 %t233, %t240
  store i64 %t241, ptr %l99, !tbaa !24
  %t242 = load %"compiler/free:letGo", ptr %l1
  store %"compiler/free:letGo" %t242, ptr %l100
  %t243 = load i64, ptr %l99, !tbaa !24
  %t244 = icmp sge i64 %t243, 0
  br i1 %t244, label %bb36, label %bb37
bb36:
  %t246 = load i64, ptr %l99, !tbaa !24
  %t247 = icmp sle i64 %t246, 128102389400760775
  br i1 %t247, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_67ba5b1efcd4822e_37bf44bd9e6bacf2)
  unreachable
bb38:
  %t249 = load i64, ptr %l99, !tbaa !24
  %t250 = mul i64 %t249, 72
  %t251 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t250)
  %t252 = load %"compiler/free:letGo", ptr %l100
  store i64 0, ptr %t253
  br label %fill.254
fill.254:
  %t257 = load i64, ptr %t253
  %t258 = icmp slt i64 %t257, %t249
  br i1 %t258, label %fillb.255, label %filld.256
fillb.255:
  %t259 = getelementptr %"compiler/free:letGo", ptr %t251, i64 %t257
  store %"compiler/free:letGo" %t252, ptr %t259
  %t260 = add i64 %t257, 1
  store i64 %t260, ptr %t253
  br label %fill.254
filld.256:
  %t261 = insertvalue { i64, ptr } undef, i64 %t249, 0
  %t262 = insertvalue { i64, ptr } %t261, ptr %t251, 1
  %t264 = load i64, ptr %l95, !tbaa !24
  %t265 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t266 = load ptr, ptr %t265, !tbaa !27
  %t267 = getelementptr { i64, ptr }, ptr %t266, i64 %t264
  store { i64, ptr } %t262, ptr %t267, !tbaa !37
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t271 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t269, i32 0, i32 0
  %t272 = load { i64, ptr }, ptr %t271, !tbaa !27
  store { i64, ptr } %t272, ptr %l106, !tbaa !27
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t273, i32 0, i32 3
  %t276 = load i64, ptr %t275, !tbaa !24
  %t278 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t279 = load ptr, ptr %t278, !tbaa !27
  %t280 = getelementptr { i64, ptr }, ptr %t279, i64 %t276
  %t281 = load { i64, ptr }, ptr %t280, !tbaa !37
  %t284 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t268, i32 0, i32 4
  store { i64, ptr } %t281, ptr %t284, !tbaa !27
  %t285 = load ptr, ptr %l0, !tbaa !29
  store ptr %t285, ptr %l110, !tbaa !29
  %t286 = load ptr, ptr %l110, !tbaa !29
  %t287 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t286, i32 0, i32 3
  %t288 = load i64, ptr %t287, !tbaa !24
  %t290 = add i64 %t288, 1
  %t292 = load ptr, ptr %l110, !tbaa !29
  %t293 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t292, i32 0, i32 3
  store i64 %t290, ptr %t293, !tbaa !24
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_67ba5b1efcd4822e_37bf44bd9e6bacf2)
  unreachable
bb40:
  br label %bb41
bb41:
  %t294 = load ptr, ptr %l0, !tbaa !29
  store ptr %t294, ptr %l113, !tbaa !29
  %t295 = load ptr, ptr %l113, !tbaa !29
  %t296 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t295, i32 0, i32 2
  %t297 = load i64, ptr %t296, !tbaa !24
  %t299 = add i64 %t297, 1
  %t301 = load ptr, ptr %l113, !tbaa !29
  %t302 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t301, i32 0, i32 2
  store i64 %t299, ptr %t302, !tbaa !24
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t305 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t303, i32 0, i32 5
  store i64 0, ptr %t305, !tbaa !24
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t309 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t307, i32 0, i32 4
  %t310 = load { i64, ptr }, ptr %t309, !tbaa !27
  %t312 = extractvalue { i64, ptr } %t310, 0
  %t315 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t306, i32 0, i32 6
  store i64 %t312, ptr %t315, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2ffree_3aletGo_3e_2er_H76ad5f902abd2054bc7fd667d4b8efa6(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l16 = alloca i64
  %l18 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l34 = alloca i64
  %l36 = alloca i64
  %l39 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca i64
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t2, i32 0, i32 2
  %t5 = load i64, ptr %t4, !tbaa !24
  %t7 = sub i64 %t5, 1
  %t10 = icmp eq i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i64, ptr %l1, !tbaa !24
  %t16 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %t12, i64 %t13)
  store { i64, ptr } %t16, ptr %l10
  br label %bb3
bb2:
  br label %bb10
bb3:
  %t17 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t17, ptr %l11, !tbaa !27
  %t18 = load i64, ptr %l2, !tbaa !24
  %t19 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t22 = add i64 %t18, %t19
  %t23 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t24 = load i64, ptr %l1, !tbaa !24
  store i64 %t24, ptr %l16, !tbaa !24
  %t26 = load i64, ptr %l16, !tbaa !24
  %t27 = load i64, ptr %l16, !tbaa !24
  %t28 = shl i64 %t23, %t27
  %t31 = sub i64 %t22, %t28
  store i64 %t31, ptr %l18, !tbaa !24
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t32, i32 0, i32 5
  %t35 = load i64, ptr %t34, !tbaa !24
  store i64 %t35, ptr %l20, !tbaa !24
  %t36 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t36, 0
  store i64 %t37, ptr %l21, !tbaa !24
  %t38 = load i64, ptr %l18, !tbaa !24
  %t39 = icmp sge i64 %t38, 0
  br i1 %t39, label %bb4, label %bb5
bb4:
  %t41 = load i64, ptr %l18, !tbaa !24
  %t42 = load i64, ptr %l20, !tbaa !24
  %t43 = icmp sle i64 %t41, %t42
  br i1 %t43, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_53a792ee6df1ab26_8e40c0ccdcf288da)
  unreachable
bb6:
  %t45 = load i64, ptr %l20, !tbaa !24
  %t46 = load i64, ptr %l21, !tbaa !24
  %t47 = icmp sle i64 %t45, %t46
  br i1 %t47, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_53a792ee6df1ab26_8e40c0ccdcf288da)
  unreachable
bb8:
  %t49 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = load i64, ptr %l18, !tbaa !24
  %t52 = load i64, ptr %l20, !tbaa !24
  %t53 = getelementptr %"compiler/free:letGo", ptr %t50, i64 %t51
  %t54 = sub i64 %t52, %t51
  %t55 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t53, 1
  store { i64, ptr } %t56, ptr %rv
  br label %ret
bb9:
  call void @__olang_check_failed(ptr @olang_loc_53a792ee6df1ab26_8e40c0ccdcf288da)
  unreachable
bb10:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i64, ptr %l1, !tbaa !24
  %t62 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %t58, i64 %t59)
  store { i64, ptr } %t62, ptr %l28
  br label %bb11
bb11:
  %t63 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t63, ptr %l29, !tbaa !27
  %t64 = load i64, ptr %l2, !tbaa !24
  %t65 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t68 = add i64 %t64, %t65
  %t69 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t70 = load i64, ptr %l1, !tbaa !24
  store i64 %t70, ptr %l34, !tbaa !24
  %t72 = load i64, ptr %l34, !tbaa !24
  %t73 = load i64, ptr %l34, !tbaa !24
  %t74 = shl i64 %t69, %t73
  %t77 = sub i64 %t68, %t74
  store i64 %t77, ptr %l36, !tbaa !24
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load i64, ptr %l1, !tbaa !24
  %t82 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %t78, i64 %t79)
  store { i64, ptr } %t82, ptr %l39
  br label %bb12
bb12:
  %t83 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t83, 0
  store i64 %t86, ptr %l42, !tbaa !24
  %t87 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t87, 0
  store i64 %t88, ptr %l43, !tbaa !24
  %t89 = load i64, ptr %l36, !tbaa !24
  %t90 = icmp sge i64 %t89, 0
  br i1 %t90, label %bb13, label %bb14
bb13:
  %t92 = load i64, ptr %l36, !tbaa !24
  %t93 = load i64, ptr %l42, !tbaa !24
  %t94 = icmp sle i64 %t92, %t93
  br i1 %t94, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_3ea4ac2de0c14383_cd69c9201202aa37)
  unreachable
bb15:
  %t96 = load i64, ptr %l42, !tbaa !24
  %t97 = load i64, ptr %l43, !tbaa !24
  %t98 = icmp sle i64 %t96, %t97
  br i1 %t98, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_3ea4ac2de0c14383_cd69c9201202aa37)
  unreachable
bb17:
  %t100 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = load i64, ptr %l36, !tbaa !24
  %t103 = load i64, ptr %l42, !tbaa !24
  %t104 = getelementptr %"compiler/free:letGo", ptr %t101, i64 %t102
  %t105 = sub i64 %t103, %t102
  %t106 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t104, 1
  store { i64, ptr } %t107, ptr %rv
  br label %ret
bb18:
  call void @__olang_check_failed(ptr @olang_loc_3ea4ac2de0c14383_cd69c9201202aa37)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2ffree_3aorCall_3e_2e_H51465f9ba83496ba01ce3b4ae979cd5d(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l16 = alloca i64
  %l18 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l34 = alloca i64
  %l36 = alloca i64
  %l39 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca i64
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t2, i32 0, i32 2
  %t5 = load i64, ptr %t4, !tbaa !24
  %t7 = sub i64 %t5, 1
  %t10 = icmp eq i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i64, ptr %l1, !tbaa !24
  %t16 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %t12, i64 %t13)
  store { i64, ptr } %t16, ptr %l10
  br label %bb3
bb2:
  br label %bb10
bb3:
  %t17 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t17, ptr %l11, !tbaa !27
  %t18 = load i64, ptr %l2, !tbaa !24
  %t19 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t22 = add i64 %t18, %t19
  %t23 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t24 = load i64, ptr %l1, !tbaa !24
  store i64 %t24, ptr %l16, !tbaa !24
  %t26 = load i64, ptr %l16, !tbaa !24
  %t27 = load i64, ptr %l16, !tbaa !24
  %t28 = shl i64 %t23, %t27
  %t31 = sub i64 %t22, %t28
  store i64 %t31, ptr %l18, !tbaa !24
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t32, i32 0, i32 5
  %t35 = load i64, ptr %t34, !tbaa !24
  store i64 %t35, ptr %l20, !tbaa !24
  %t36 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t36, 0
  store i64 %t37, ptr %l21, !tbaa !24
  %t38 = load i64, ptr %l18, !tbaa !24
  %t39 = icmp sge i64 %t38, 0
  br i1 %t39, label %bb4, label %bb5
bb4:
  %t41 = load i64, ptr %l18, !tbaa !24
  %t42 = load i64, ptr %l20, !tbaa !24
  %t43 = icmp sle i64 %t41, %t42
  br i1 %t43, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_d320103722639438_3570df4ff90c2df4)
  unreachable
bb6:
  %t45 = load i64, ptr %l20, !tbaa !24
  %t46 = load i64, ptr %l21, !tbaa !24
  %t47 = icmp sle i64 %t45, %t46
  br i1 %t47, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_d320103722639438_3570df4ff90c2df4)
  unreachable
bb8:
  %t49 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = load i64, ptr %l18, !tbaa !24
  %t52 = load i64, ptr %l20, !tbaa !24
  %t53 = getelementptr %"compiler/free:orCall", ptr %t50, i64 %t51
  %t54 = sub i64 %t52, %t51
  %t55 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t53, 1
  store { i64, ptr } %t56, ptr %rv
  br label %ret
bb9:
  call void @__olang_check_failed(ptr @olang_loc_d320103722639438_3570df4ff90c2df4)
  unreachable
bb10:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i64, ptr %l1, !tbaa !24
  %t62 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %t58, i64 %t59)
  store { i64, ptr } %t62, ptr %l28
  br label %bb11
bb11:
  %t63 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t63, ptr %l29, !tbaa !27
  %t64 = load i64, ptr %l2, !tbaa !24
  %t65 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t68 = add i64 %t64, %t65
  %t69 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t70 = load i64, ptr %l1, !tbaa !24
  store i64 %t70, ptr %l34, !tbaa !24
  %t72 = load i64, ptr %l34, !tbaa !24
  %t73 = load i64, ptr %l34, !tbaa !24
  %t74 = shl i64 %t69, %t73
  %t77 = sub i64 %t68, %t74
  store i64 %t77, ptr %l36, !tbaa !24
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load i64, ptr %l1, !tbaa !24
  %t82 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %t78, i64 %t79)
  store { i64, ptr } %t82, ptr %l39
  br label %bb12
bb12:
  %t83 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t83, 0
  store i64 %t86, ptr %l42, !tbaa !24
  %t87 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t87, 0
  store i64 %t88, ptr %l43, !tbaa !24
  %t89 = load i64, ptr %l36, !tbaa !24
  %t90 = icmp sge i64 %t89, 0
  br i1 %t90, label %bb13, label %bb14
bb13:
  %t92 = load i64, ptr %l36, !tbaa !24
  %t93 = load i64, ptr %l42, !tbaa !24
  %t94 = icmp sle i64 %t92, %t93
  br i1 %t94, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_aafcd34cf883ea15_e42c9aaf31e4cbe1)
  unreachable
bb15:
  %t96 = load i64, ptr %l42, !tbaa !24
  %t97 = load i64, ptr %l43, !tbaa !24
  %t98 = icmp sle i64 %t96, %t97
  br i1 %t98, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_aafcd34cf883ea15_e42c9aaf31e4cbe1)
  unreachable
bb17:
  %t100 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = load i64, ptr %l36, !tbaa !24
  %t103 = load i64, ptr %l42, !tbaa !24
  %t104 = getelementptr %"compiler/free:orCall", ptr %t101, i64 %t102
  %t105 = sub i64 %t103, %t102
  %t106 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t104, 1
  store { i64, ptr } %t107, ptr %rv
  br label %ret
bb18:
  call void @__olang_check_failed(ptr @olang_loc_aafcd34cf883ea15_e42c9aaf31e4cbe1)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2ffree_3aorCall_3e_2e_H879793fe7db5e8bd2e95649ea41c44e3(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %r = tail call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %a0, i64 %a1)
  ret { i64, ptr } %r
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2ffree_3aorCall_3e_2e_He84395c27c957765e879862ae50cc281(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:orCall" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/free:orCall"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l14 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca %"compiler/free:orCall"
  %l36 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l50 = alloca i64
  %l52 = alloca { i64, ptr }
  %l61 = alloca i64
  %l64 = alloca i64
  %l82 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l95 = alloca i64
  %l98 = alloca i64
  %l99 = alloca i64
  %l100 = alloca %"compiler/free:orCall"
  %l106 = alloca { i64, ptr }
  %l110 = alloca ptr
  %l113 = alloca ptr
  %s9 = alloca %olang.scope
  %t54 = alloca i64
  %t104 = alloca i64
  %t137 = alloca i64
  %t253 = alloca i64
  store ptr %a0, ptr %l0
  store %"compiler/free:orCall" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t1, i32 0, i32 2
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t5, i32 0, i32 3
  %t8 = load i64, ptr %t7, !tbaa !24
  %t11 = icmp slt i64 %t4, %t8
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l14, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t15, i32 0, i32 2
  %t18 = load i64, ptr %t17, !tbaa !24
  %t21 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %t14, i64 %t18)
  store { i64, ptr } %t21, ptr %l18
  br label %bb3
bb2:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t22, i32 0, i32 3
  %t25 = load i64, ptr %t24, !tbaa !24
  %t27 = icmp eq i64 %t25, 0
  br i1 %t27, label %bb4, label %bb5
bb3:
  %t29 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t30 = load ptr, ptr %l14, !tbaa !29
  %t31 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t30, i32 0, i32 4
  store { i64, ptr } %t29, ptr %t31, !tbaa !27
  br label %bb41
bb4:
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l22, !tbaa !29
  %t33 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  store i64 %t33, ptr %l23, !tbaa !24
  %t34 = load %"compiler/free:orCall", ptr %l1
  store %"compiler/free:orCall" %t34, ptr %l24
  %t35 = load i64, ptr %l23, !tbaa !24
  %t36 = icmp sge i64 %t35, 0
  br i1 %t36, label %bb6, label %bb7
bb5:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t38, i32 0, i32 0
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t45 = icmp eq i64 %t43, 0
  br i1 %t45, label %bb10, label %bb11
bb6:
  %t47 = load i64, ptr %l23, !tbaa !24
  %t48 = icmp sle i64 %t47, 164703072086692425
  br i1 %t48, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_4ca4216b4c0999aa_9cce9557d52059ee)
  unreachable
bb8:
  %t50 = load i64, ptr %l23, !tbaa !24
  %t51 = mul i64 %t50, 56
  %t52 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t51)
  %t53 = load %"compiler/free:orCall", ptr %l24
  store i64 0, ptr %t54
  br label %fill.55
fill.55:
  %t58 = load i64, ptr %t54
  %t59 = icmp slt i64 %t58, %t50
  br i1 %t59, label %fillb.56, label %filld.57
fillb.56:
  %t60 = getelementptr %"compiler/free:orCall", ptr %t52, i64 %t58
  store %"compiler/free:orCall" %t53, ptr %t60
  %t61 = add i64 %t58, 1
  store i64 %t61, ptr %t54
  br label %fill.55
filld.57:
  %t62 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t52, 1
  %t65 = load ptr, ptr %l22, !tbaa !29
  %t66 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t65, i32 0, i32 1
  store { i64, ptr } %t63, ptr %t66, !tbaa !27
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t68, i32 0, i32 1
  %t71 = load { i64, ptr }, ptr %t70, !tbaa !27
  %t74 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t67, i32 0, i32 4
  store { i64, ptr } %t71, ptr %t74, !tbaa !27
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t75, i32 0, i32 3
  store i64 1, ptr %t77, !tbaa !24
  br label %bb40
bb9:
  call void @__olang_check_failed(ptr @olang_loc_4ca4216b4c0999aa_9cce9557d52059ee)
  unreachable
bb10:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l36, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t79, i32 0, i32 1
  %t82 = load { i64, ptr }, ptr %t81, !tbaa !27
  store { i64, ptr } %t82, ptr %l38, !tbaa !27
  %t83 = icmp sge i64 4, 0
  br i1 %t83, label %bb12, label %bb13
bb11:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t85, i32 0, i32 3
  %t88 = load i64, ptr %t87, !tbaa !24
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t89, i32 0, i32 0
  %t92 = load { i64, ptr }, ptr %t91, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t92, 0
  %t97 = icmp eq i64 %t88, %t94
  br i1 %t97, label %bb16, label %bb17
bb12:
  %t99 = icmp sle i64 4, 576460752303423487
  br i1 %t99, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_42b9cfb017d0cb7f_b98ba3c7b8f95963)
  unreachable
bb14:
  %t101 = mul i64 4, 16
  %t102 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t101)
  %t103 = load { i64, ptr }, ptr %l38, !tbaa !27
  store i64 0, ptr %t104
  br label %fill.105
fill.105:
  %t108 = load i64, ptr %t104
  %t109 = icmp slt i64 %t108, 4
  br i1 %t109, label %fillb.106, label %filld.107
fillb.106:
  %t110 = getelementptr { i64, ptr }, ptr %t102, i64 %t108
  store { i64, ptr } %t103, ptr %t110
  %t111 = add i64 %t108, 1
  store i64 %t111, ptr %t104
  br label %fill.105
filld.107:
  %t112 = insertvalue { i64, ptr } undef, i64 4, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t102, 1
  %t115 = load ptr, ptr %l36, !tbaa !29
  %t116 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t115, i32 0, i32 0
  store { i64, ptr } %t113, ptr %t116, !tbaa !27
  br label %bb35
bb15:
  call void @__olang_check_failed(ptr @olang_loc_42b9cfb017d0cb7f_b98ba3c7b8f95963)
  unreachable
bb16:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t117, i32 0, i32 3
  %t120 = load i64, ptr %t119, !tbaa !24
  %t122 = mul i64 %t120, 2
  store i64 %t122, ptr %l50, !tbaa !24
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t123, i32 0, i32 1
  %t126 = load { i64, ptr }, ptr %t125, !tbaa !27
  store { i64, ptr } %t126, ptr %l52, !tbaa !27
  %t127 = load i64, ptr %l50, !tbaa !24
  %t128 = icmp sge i64 %t127, 0
  br i1 %t128, label %bb18, label %bb19
bb17:
  br label %bb34
bb18:
  %t130 = load i64, ptr %l50, !tbaa !24
  %t131 = icmp sle i64 %t130, 576460752303423487
  br i1 %t131, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_777dd77f8cb4561c_ddd09332b6e89dc0)
  unreachable
bb20:
  %t133 = load i64, ptr %l50, !tbaa !24
  %t134 = mul i64 %t133, 16
  %t135 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t134)
  %t136 = load { i64, ptr }, ptr %l52, !tbaa !27
  store i64 0, ptr %t137
  br label %fill.138
fill.138:
  %t141 = load i64, ptr %t137
  %t142 = icmp slt i64 %t141, %t133
  br i1 %t142, label %fillb.139, label %filld.140
fillb.139:
  %t143 = getelementptr { i64, ptr }, ptr %t135, i64 %t141
  store { i64, ptr } %t136, ptr %t143
  %t144 = add i64 %t141, 1
  store i64 %t144, ptr %t137
  br label %fill.138
filld.140:
  %t145 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t146 = insertvalue { i64, ptr } %t145, ptr %t135, 1
  store { i64, ptr } %t146, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t148, i32 0, i32 3
  %t151 = load i64, ptr %t150, !tbaa !24
  store i64 %t151, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t153 = load i64, ptr %l4, !tbaa !24
  %t154 = load i64, ptr %l3, !tbaa !24
  %t157 = icmp sgt i64 %t153, %t154
  br i1 %t157, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_777dd77f8cb4561c_ddd09332b6e89dc0)
  unreachable
bb22:
  %t159 = load i64, ptr %l5, !tbaa !24
  %t161 = icmp sgt i64 %t159, 0
  br i1 %t161, label %bb24, label %bb25
bb23:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb27
bb24:
  %t163 = load i64, ptr %l4, !tbaa !24
  %t164 = load i64, ptr %l3, !tbaa !24
  %t167 = sub i64 %t163, %t164
  %t168 = load i64, ptr %l5, !tbaa !24
  %t171 = add i64 %t167, %t168
  %t173 = sub i64 %t171, 1
  %t174 = load i64, ptr %l5, !tbaa !24
  %t177 = sdiv i64 %t173, %t174
  store i64 %t177, ptr %l64, !tbaa !24
  br label %bb26
bb25:
  store i64 0, ptr %l64, !tbaa !24
  br label %bb26
bb26:
  %t179 = load i64, ptr %l64, !tbaa !24
  store i64 %t179, ptr %l61, !tbaa !24
  br label %bb27
bb27:
  %t180 = load i64, ptr %l61, !tbaa !24
  store i64 %t180, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb28
bb28:
  store %olang.scope zeroinitializer, ptr %s9
  %t181 = load i64, ptr %l7, !tbaa !24
  %t182 = load i64, ptr %l6, !tbaa !24
  %t185 = icmp slt i64 %t181, %t182
  %t187 = xor i1 %t185, true
  br i1 %t187, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s9)
  br label %bb33
bb30:
  br label %bb31
bb31:
  %t189 = load i64, ptr %l3, !tbaa !24
  %t190 = load i64, ptr %l7, !tbaa !24
  %t191 = load i64, ptr %l5, !tbaa !24
  %t194 = mul i64 %t190, %t191
  %t197 = add i64 %t189, %t194
  store i64 %t197, ptr %l8, !tbaa !24
  %t199 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t199, ptr %l82, !tbaa !27
  %t200 = load i64, ptr %l8, !tbaa !24
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t203 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t201, i32 0, i32 0
  %t204 = load { i64, ptr }, ptr %t203, !tbaa !27
  store { i64, ptr } %t204, ptr %l85, !tbaa !27
  %t205 = load i64, ptr %l8, !tbaa !24
  %t207 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !27
  %t209 = getelementptr { i64, ptr }, ptr %t208, i64 %t205
  %t210 = load { i64, ptr }, ptr %t209, !tbaa !37
  %t213 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !27
  %t215 = getelementptr { i64, ptr }, ptr %t214, i64 %t200
  store { i64, ptr } %t210, ptr %t215, !tbaa !37
  call void @__olang_scope_close(ptr %s9)
  br label %bb32
bb32:
  %t216 = load i64, ptr %l7, !tbaa !24
  %t218 = add i64 %t216, 1
  store i64 %t218, ptr %l7, !tbaa !24
  br label %bb28
bb33:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t224 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t220, i32 0, i32 0
  store { i64, ptr } %t221, ptr %t224, !tbaa !27
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t227 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t225, i32 0, i32 0
  %t228 = load { i64, ptr }, ptr %t227, !tbaa !27
  store { i64, ptr } %t228, ptr %l93, !tbaa !27
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t229, i32 0, i32 3
  %t232 = load i64, ptr %t231, !tbaa !24
  store i64 %t232, ptr %l95, !tbaa !24
  %t233 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t236 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t234, i32 0, i32 3
  %t237 = load i64, ptr %t236, !tbaa !24
  store i64 %t237, ptr %l98, !tbaa !24
  %t239 = load i64, ptr %l98, !tbaa !24
  %t240 = load i64, ptr %l98, !tbaa !24
  %t241 = shl i64 %t233, %t240
  store i64 %t241, ptr %l99, !tbaa !24
  %t242 = load %"compiler/free:orCall", ptr %l1
  store %"compiler/free:orCall" %t242, ptr %l100
  %t243 = load i64, ptr %l99, !tbaa !24
  %t244 = icmp sge i64 %t243, 0
  br i1 %t244, label %bb36, label %bb37
bb36:
  %t246 = load i64, ptr %l99, !tbaa !24
  %t247 = icmp sle i64 %t246, 164703072086692425
  br i1 %t247, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_fb36f36590ee87e9_8cf0e96e15ba02ed)
  unreachable
bb38:
  %t249 = load i64, ptr %l99, !tbaa !24
  %t250 = mul i64 %t249, 56
  %t251 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t250)
  %t252 = load %"compiler/free:orCall", ptr %l100
  store i64 0, ptr %t253
  br label %fill.254
fill.254:
  %t257 = load i64, ptr %t253
  %t258 = icmp slt i64 %t257, %t249
  br i1 %t258, label %fillb.255, label %filld.256
fillb.255:
  %t259 = getelementptr %"compiler/free:orCall", ptr %t251, i64 %t257
  store %"compiler/free:orCall" %t252, ptr %t259
  %t260 = add i64 %t257, 1
  store i64 %t260, ptr %t253
  br label %fill.254
filld.256:
  %t261 = insertvalue { i64, ptr } undef, i64 %t249, 0
  %t262 = insertvalue { i64, ptr } %t261, ptr %t251, 1
  %t264 = load i64, ptr %l95, !tbaa !24
  %t265 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t266 = load ptr, ptr %t265, !tbaa !27
  %t267 = getelementptr { i64, ptr }, ptr %t266, i64 %t264
  store { i64, ptr } %t262, ptr %t267, !tbaa !37
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t271 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t269, i32 0, i32 0
  %t272 = load { i64, ptr }, ptr %t271, !tbaa !27
  store { i64, ptr } %t272, ptr %l106, !tbaa !27
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t273, i32 0, i32 3
  %t276 = load i64, ptr %t275, !tbaa !24
  %t278 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t279 = load ptr, ptr %t278, !tbaa !27
  %t280 = getelementptr { i64, ptr }, ptr %t279, i64 %t276
  %t281 = load { i64, ptr }, ptr %t280, !tbaa !37
  %t284 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t268, i32 0, i32 4
  store { i64, ptr } %t281, ptr %t284, !tbaa !27
  %t285 = load ptr, ptr %l0, !tbaa !29
  store ptr %t285, ptr %l110, !tbaa !29
  %t286 = load ptr, ptr %l110, !tbaa !29
  %t287 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t286, i32 0, i32 3
  %t288 = load i64, ptr %t287, !tbaa !24
  %t290 = add i64 %t288, 1
  %t292 = load ptr, ptr %l110, !tbaa !29
  %t293 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t292, i32 0, i32 3
  store i64 %t290, ptr %t293, !tbaa !24
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_fb36f36590ee87e9_8cf0e96e15ba02ed)
  unreachable
bb40:
  br label %bb41
bb41:
  %t294 = load ptr, ptr %l0, !tbaa !29
  store ptr %t294, ptr %l113, !tbaa !29
  %t295 = load ptr, ptr %l113, !tbaa !29
  %t296 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t295, i32 0, i32 2
  %t297 = load i64, ptr %t296, !tbaa !24
  %t299 = add i64 %t297, 1
  %t301 = load ptr, ptr %l113, !tbaa !29
  %t302 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t301, i32 0, i32 2
  store i64 %t299, ptr %t302, !tbaa !24
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t305 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t303, i32 0, i32 5
  store i64 0, ptr %t305, !tbaa !24
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t309 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t307, i32 0, i32 4
  %t310 = load { i64, ptr }, ptr %t309, !tbaa !27
  %t312 = extractvalue { i64, ptr } %t310, 0
  %t315 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t306, i32 0, i32 6
  store i64 %t312, ptr %t315, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2ffree_3aorStore_3e_2_H4cc6ae66f2a64482e77b08fe0c638376(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l16 = alloca i64
  %l18 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l34 = alloca i64
  %l36 = alloca i64
  %l39 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca i64
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t2, i32 0, i32 2
  %t5 = load i64, ptr %t4, !tbaa !24
  %t7 = sub i64 %t5, 1
  %t10 = icmp eq i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i64, ptr %l1, !tbaa !24
  %t16 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %t12, i64 %t13)
  store { i64, ptr } %t16, ptr %l10
  br label %bb3
bb2:
  br label %bb10
bb3:
  %t17 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t17, ptr %l11, !tbaa !27
  %t18 = load i64, ptr %l2, !tbaa !24
  %t19 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t22 = add i64 %t18, %t19
  %t23 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t24 = load i64, ptr %l1, !tbaa !24
  store i64 %t24, ptr %l16, !tbaa !24
  %t26 = load i64, ptr %l16, !tbaa !24
  %t27 = load i64, ptr %l16, !tbaa !24
  %t28 = shl i64 %t23, %t27
  %t31 = sub i64 %t22, %t28
  store i64 %t31, ptr %l18, !tbaa !24
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t32, i32 0, i32 5
  %t35 = load i64, ptr %t34, !tbaa !24
  store i64 %t35, ptr %l20, !tbaa !24
  %t36 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t36, 0
  store i64 %t37, ptr %l21, !tbaa !24
  %t38 = load i64, ptr %l18, !tbaa !24
  %t39 = icmp sge i64 %t38, 0
  br i1 %t39, label %bb4, label %bb5
bb4:
  %t41 = load i64, ptr %l18, !tbaa !24
  %t42 = load i64, ptr %l20, !tbaa !24
  %t43 = icmp sle i64 %t41, %t42
  br i1 %t43, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_438c24ac7a213098_1e62abdbaf6bf5dc)
  unreachable
bb6:
  %t45 = load i64, ptr %l20, !tbaa !24
  %t46 = load i64, ptr %l21, !tbaa !24
  %t47 = icmp sle i64 %t45, %t46
  br i1 %t47, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_438c24ac7a213098_1e62abdbaf6bf5dc)
  unreachable
bb8:
  %t49 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = load i64, ptr %l18, !tbaa !24
  %t52 = load i64, ptr %l20, !tbaa !24
  %t53 = getelementptr %"compiler/free:orStore", ptr %t50, i64 %t51
  %t54 = sub i64 %t52, %t51
  %t55 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t53, 1
  store { i64, ptr } %t56, ptr %rv
  br label %ret
bb9:
  call void @__olang_check_failed(ptr @olang_loc_438c24ac7a213098_1e62abdbaf6bf5dc)
  unreachable
bb10:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i64, ptr %l1, !tbaa !24
  %t62 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %t58, i64 %t59)
  store { i64, ptr } %t62, ptr %l28
  br label %bb11
bb11:
  %t63 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t63, ptr %l29, !tbaa !27
  %t64 = load i64, ptr %l2, !tbaa !24
  %t65 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t68 = add i64 %t64, %t65
  %t69 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t70 = load i64, ptr %l1, !tbaa !24
  store i64 %t70, ptr %l34, !tbaa !24
  %t72 = load i64, ptr %l34, !tbaa !24
  %t73 = load i64, ptr %l34, !tbaa !24
  %t74 = shl i64 %t69, %t73
  %t77 = sub i64 %t68, %t74
  store i64 %t77, ptr %l36, !tbaa !24
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load i64, ptr %l1, !tbaa !24
  %t82 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %t78, i64 %t79)
  store { i64, ptr } %t82, ptr %l39
  br label %bb12
bb12:
  %t83 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t83, 0
  store i64 %t86, ptr %l42, !tbaa !24
  %t87 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t87, 0
  store i64 %t88, ptr %l43, !tbaa !24
  %t89 = load i64, ptr %l36, !tbaa !24
  %t90 = icmp sge i64 %t89, 0
  br i1 %t90, label %bb13, label %bb14
bb13:
  %t92 = load i64, ptr %l36, !tbaa !24
  %t93 = load i64, ptr %l42, !tbaa !24
  %t94 = icmp sle i64 %t92, %t93
  br i1 %t94, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_43b3ef88dc0147f5_9d0ff4f7cff70b49)
  unreachable
bb15:
  %t96 = load i64, ptr %l42, !tbaa !24
  %t97 = load i64, ptr %l43, !tbaa !24
  %t98 = icmp sle i64 %t96, %t97
  br i1 %t98, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_43b3ef88dc0147f5_9d0ff4f7cff70b49)
  unreachable
bb17:
  %t100 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = load i64, ptr %l36, !tbaa !24
  %t103 = load i64, ptr %l42, !tbaa !24
  %t104 = getelementptr %"compiler/free:orStore", ptr %t101, i64 %t102
  %t105 = sub i64 %t103, %t102
  %t106 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t104, 1
  store { i64, ptr } %t107, ptr %rv
  br label %ret
bb18:
  call void @__olang_check_failed(ptr @olang_loc_43b3ef88dc0147f5_9d0ff4f7cff70b49)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2ffree_3aorStore_3e_2_H68843c6d02a83d2b29363c0df320e643(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %r = tail call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %a0, i64 %a1)
  ret { i64, ptr } %r
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2ffree_3aorStore_3e_2_H99b9f06a4dd17c91592b7d2614416ed4(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:orStore" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/free:orStore"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l14 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca %"compiler/free:orStore"
  %l36 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l50 = alloca i64
  %l52 = alloca { i64, ptr }
  %l61 = alloca i64
  %l64 = alloca i64
  %l82 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l95 = alloca i64
  %l98 = alloca i64
  %l99 = alloca i64
  %l100 = alloca %"compiler/free:orStore"
  %l106 = alloca { i64, ptr }
  %l110 = alloca ptr
  %l113 = alloca ptr
  %s9 = alloca %olang.scope
  %t54 = alloca i64
  %t104 = alloca i64
  %t137 = alloca i64
  %t253 = alloca i64
  store ptr %a0, ptr %l0
  store %"compiler/free:orStore" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t1, i32 0, i32 2
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t5, i32 0, i32 3
  %t8 = load i64, ptr %t7, !tbaa !24
  %t11 = icmp slt i64 %t4, %t8
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l14, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t15, i32 0, i32 2
  %t18 = load i64, ptr %t17, !tbaa !24
  %t21 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %t14, i64 %t18)
  store { i64, ptr } %t21, ptr %l18
  br label %bb3
bb2:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t22, i32 0, i32 3
  %t25 = load i64, ptr %t24, !tbaa !24
  %t27 = icmp eq i64 %t25, 0
  br i1 %t27, label %bb4, label %bb5
bb3:
  %t29 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t30 = load ptr, ptr %l14, !tbaa !29
  %t31 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t30, i32 0, i32 4
  store { i64, ptr } %t29, ptr %t31, !tbaa !27
  br label %bb41
bb4:
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l22, !tbaa !29
  %t33 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  store i64 %t33, ptr %l23, !tbaa !24
  %t34 = load %"compiler/free:orStore", ptr %l1
  store %"compiler/free:orStore" %t34, ptr %l24
  %t35 = load i64, ptr %l23, !tbaa !24
  %t36 = icmp sge i64 %t35, 0
  br i1 %t36, label %bb6, label %bb7
bb5:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t38, i32 0, i32 0
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t45 = icmp eq i64 %t43, 0
  br i1 %t45, label %bb10, label %bb11
bb6:
  %t47 = load i64, ptr %l23, !tbaa !24
  %t48 = icmp sle i64 %t47, 288230376151711743
  br i1 %t48, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_b936876b76714920_e5b9e5dc02d16c54)
  unreachable
bb8:
  %t50 = load i64, ptr %l23, !tbaa !24
  %t51 = mul i64 %t50, 32
  %t52 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t51)
  %t53 = load %"compiler/free:orStore", ptr %l24
  store i64 0, ptr %t54
  br label %fill.55
fill.55:
  %t58 = load i64, ptr %t54
  %t59 = icmp slt i64 %t58, %t50
  br i1 %t59, label %fillb.56, label %filld.57
fillb.56:
  %t60 = getelementptr %"compiler/free:orStore", ptr %t52, i64 %t58
  store %"compiler/free:orStore" %t53, ptr %t60
  %t61 = add i64 %t58, 1
  store i64 %t61, ptr %t54
  br label %fill.55
filld.57:
  %t62 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t52, 1
  %t65 = load ptr, ptr %l22, !tbaa !29
  %t66 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t65, i32 0, i32 1
  store { i64, ptr } %t63, ptr %t66, !tbaa !27
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t68, i32 0, i32 1
  %t71 = load { i64, ptr }, ptr %t70, !tbaa !27
  %t74 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t67, i32 0, i32 4
  store { i64, ptr } %t71, ptr %t74, !tbaa !27
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t75, i32 0, i32 3
  store i64 1, ptr %t77, !tbaa !24
  br label %bb40
bb9:
  call void @__olang_check_failed(ptr @olang_loc_b936876b76714920_e5b9e5dc02d16c54)
  unreachable
bb10:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l36, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t79, i32 0, i32 1
  %t82 = load { i64, ptr }, ptr %t81, !tbaa !27
  store { i64, ptr } %t82, ptr %l38, !tbaa !27
  %t83 = icmp sge i64 4, 0
  br i1 %t83, label %bb12, label %bb13
bb11:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t85, i32 0, i32 3
  %t88 = load i64, ptr %t87, !tbaa !24
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t89, i32 0, i32 0
  %t92 = load { i64, ptr }, ptr %t91, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t92, 0
  %t97 = icmp eq i64 %t88, %t94
  br i1 %t97, label %bb16, label %bb17
bb12:
  %t99 = icmp sle i64 4, 576460752303423487
  br i1 %t99, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_7ec5df9de579214d_799f6344cb66a461)
  unreachable
bb14:
  %t101 = mul i64 4, 16
  %t102 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t101)
  %t103 = load { i64, ptr }, ptr %l38, !tbaa !27
  store i64 0, ptr %t104
  br label %fill.105
fill.105:
  %t108 = load i64, ptr %t104
  %t109 = icmp slt i64 %t108, 4
  br i1 %t109, label %fillb.106, label %filld.107
fillb.106:
  %t110 = getelementptr { i64, ptr }, ptr %t102, i64 %t108
  store { i64, ptr } %t103, ptr %t110
  %t111 = add i64 %t108, 1
  store i64 %t111, ptr %t104
  br label %fill.105
filld.107:
  %t112 = insertvalue { i64, ptr } undef, i64 4, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t102, 1
  %t115 = load ptr, ptr %l36, !tbaa !29
  %t116 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t115, i32 0, i32 0
  store { i64, ptr } %t113, ptr %t116, !tbaa !27
  br label %bb35
bb15:
  call void @__olang_check_failed(ptr @olang_loc_7ec5df9de579214d_799f6344cb66a461)
  unreachable
bb16:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t117, i32 0, i32 3
  %t120 = load i64, ptr %t119, !tbaa !24
  %t122 = mul i64 %t120, 2
  store i64 %t122, ptr %l50, !tbaa !24
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t123, i32 0, i32 1
  %t126 = load { i64, ptr }, ptr %t125, !tbaa !27
  store { i64, ptr } %t126, ptr %l52, !tbaa !27
  %t127 = load i64, ptr %l50, !tbaa !24
  %t128 = icmp sge i64 %t127, 0
  br i1 %t128, label %bb18, label %bb19
bb17:
  br label %bb34
bb18:
  %t130 = load i64, ptr %l50, !tbaa !24
  %t131 = icmp sle i64 %t130, 576460752303423487
  br i1 %t131, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_c66e2f20e524414e_21b74c07fe2d0f42)
  unreachable
bb20:
  %t133 = load i64, ptr %l50, !tbaa !24
  %t134 = mul i64 %t133, 16
  %t135 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t134)
  %t136 = load { i64, ptr }, ptr %l52, !tbaa !27
  store i64 0, ptr %t137
  br label %fill.138
fill.138:
  %t141 = load i64, ptr %t137
  %t142 = icmp slt i64 %t141, %t133
  br i1 %t142, label %fillb.139, label %filld.140
fillb.139:
  %t143 = getelementptr { i64, ptr }, ptr %t135, i64 %t141
  store { i64, ptr } %t136, ptr %t143
  %t144 = add i64 %t141, 1
  store i64 %t144, ptr %t137
  br label %fill.138
filld.140:
  %t145 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t146 = insertvalue { i64, ptr } %t145, ptr %t135, 1
  store { i64, ptr } %t146, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t148, i32 0, i32 3
  %t151 = load i64, ptr %t150, !tbaa !24
  store i64 %t151, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t153 = load i64, ptr %l4, !tbaa !24
  %t154 = load i64, ptr %l3, !tbaa !24
  %t157 = icmp sgt i64 %t153, %t154
  br i1 %t157, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_c66e2f20e524414e_21b74c07fe2d0f42)
  unreachable
bb22:
  %t159 = load i64, ptr %l5, !tbaa !24
  %t161 = icmp sgt i64 %t159, 0
  br i1 %t161, label %bb24, label %bb25
bb23:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb27
bb24:
  %t163 = load i64, ptr %l4, !tbaa !24
  %t164 = load i64, ptr %l3, !tbaa !24
  %t167 = sub i64 %t163, %t164
  %t168 = load i64, ptr %l5, !tbaa !24
  %t171 = add i64 %t167, %t168
  %t173 = sub i64 %t171, 1
  %t174 = load i64, ptr %l5, !tbaa !24
  %t177 = sdiv i64 %t173, %t174
  store i64 %t177, ptr %l64, !tbaa !24
  br label %bb26
bb25:
  store i64 0, ptr %l64, !tbaa !24
  br label %bb26
bb26:
  %t179 = load i64, ptr %l64, !tbaa !24
  store i64 %t179, ptr %l61, !tbaa !24
  br label %bb27
bb27:
  %t180 = load i64, ptr %l61, !tbaa !24
  store i64 %t180, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb28
bb28:
  store %olang.scope zeroinitializer, ptr %s9
  %t181 = load i64, ptr %l7, !tbaa !24
  %t182 = load i64, ptr %l6, !tbaa !24
  %t185 = icmp slt i64 %t181, %t182
  %t187 = xor i1 %t185, true
  br i1 %t187, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s9)
  br label %bb33
bb30:
  br label %bb31
bb31:
  %t189 = load i64, ptr %l3, !tbaa !24
  %t190 = load i64, ptr %l7, !tbaa !24
  %t191 = load i64, ptr %l5, !tbaa !24
  %t194 = mul i64 %t190, %t191
  %t197 = add i64 %t189, %t194
  store i64 %t197, ptr %l8, !tbaa !24
  %t199 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t199, ptr %l82, !tbaa !27
  %t200 = load i64, ptr %l8, !tbaa !24
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t203 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t201, i32 0, i32 0
  %t204 = load { i64, ptr }, ptr %t203, !tbaa !27
  store { i64, ptr } %t204, ptr %l85, !tbaa !27
  %t205 = load i64, ptr %l8, !tbaa !24
  %t207 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !27
  %t209 = getelementptr { i64, ptr }, ptr %t208, i64 %t205
  %t210 = load { i64, ptr }, ptr %t209, !tbaa !37
  %t213 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !27
  %t215 = getelementptr { i64, ptr }, ptr %t214, i64 %t200
  store { i64, ptr } %t210, ptr %t215, !tbaa !37
  call void @__olang_scope_close(ptr %s9)
  br label %bb32
bb32:
  %t216 = load i64, ptr %l7, !tbaa !24
  %t218 = add i64 %t216, 1
  store i64 %t218, ptr %l7, !tbaa !24
  br label %bb28
bb33:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t224 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t220, i32 0, i32 0
  store { i64, ptr } %t221, ptr %t224, !tbaa !27
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t227 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t225, i32 0, i32 0
  %t228 = load { i64, ptr }, ptr %t227, !tbaa !27
  store { i64, ptr } %t228, ptr %l93, !tbaa !27
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t229, i32 0, i32 3
  %t232 = load i64, ptr %t231, !tbaa !24
  store i64 %t232, ptr %l95, !tbaa !24
  %t233 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t236 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t234, i32 0, i32 3
  %t237 = load i64, ptr %t236, !tbaa !24
  store i64 %t237, ptr %l98, !tbaa !24
  %t239 = load i64, ptr %l98, !tbaa !24
  %t240 = load i64, ptr %l98, !tbaa !24
  %t241 = shl i64 %t233, %t240
  store i64 %t241, ptr %l99, !tbaa !24
  %t242 = load %"compiler/free:orStore", ptr %l1
  store %"compiler/free:orStore" %t242, ptr %l100
  %t243 = load i64, ptr %l99, !tbaa !24
  %t244 = icmp sge i64 %t243, 0
  br i1 %t244, label %bb36, label %bb37
bb36:
  %t246 = load i64, ptr %l99, !tbaa !24
  %t247 = icmp sle i64 %t246, 288230376151711743
  br i1 %t247, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_6d7dabb92c8ae543_19cf45691fa06f7)
  unreachable
bb38:
  %t249 = load i64, ptr %l99, !tbaa !24
  %t250 = mul i64 %t249, 32
  %t251 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t250)
  %t252 = load %"compiler/free:orStore", ptr %l100
  store i64 0, ptr %t253
  br label %fill.254
fill.254:
  %t257 = load i64, ptr %t253
  %t258 = icmp slt i64 %t257, %t249
  br i1 %t258, label %fillb.255, label %filld.256
fillb.255:
  %t259 = getelementptr %"compiler/free:orStore", ptr %t251, i64 %t257
  store %"compiler/free:orStore" %t252, ptr %t259
  %t260 = add i64 %t257, 1
  store i64 %t260, ptr %t253
  br label %fill.254
filld.256:
  %t261 = insertvalue { i64, ptr } undef, i64 %t249, 0
  %t262 = insertvalue { i64, ptr } %t261, ptr %t251, 1
  %t264 = load i64, ptr %l95, !tbaa !24
  %t265 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t266 = load ptr, ptr %t265, !tbaa !27
  %t267 = getelementptr { i64, ptr }, ptr %t266, i64 %t264
  store { i64, ptr } %t262, ptr %t267, !tbaa !37
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t271 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t269, i32 0, i32 0
  %t272 = load { i64, ptr }, ptr %t271, !tbaa !27
  store { i64, ptr } %t272, ptr %l106, !tbaa !27
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t273, i32 0, i32 3
  %t276 = load i64, ptr %t275, !tbaa !24
  %t278 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t279 = load ptr, ptr %t278, !tbaa !27
  %t280 = getelementptr { i64, ptr }, ptr %t279, i64 %t276
  %t281 = load { i64, ptr }, ptr %t280, !tbaa !37
  %t284 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t268, i32 0, i32 4
  store { i64, ptr } %t281, ptr %t284, !tbaa !27
  %t285 = load ptr, ptr %l0, !tbaa !29
  store ptr %t285, ptr %l110, !tbaa !29
  %t286 = load ptr, ptr %l110, !tbaa !29
  %t287 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t286, i32 0, i32 3
  %t288 = load i64, ptr %t287, !tbaa !24
  %t290 = add i64 %t288, 1
  %t292 = load ptr, ptr %l110, !tbaa !29
  %t293 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t292, i32 0, i32 3
  store i64 %t290, ptr %t293, !tbaa !24
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_6d7dabb92c8ae543_19cf45691fa06f7)
  unreachable
bb40:
  br label %bb41
bb41:
  %t294 = load ptr, ptr %l0, !tbaa !29
  store ptr %t294, ptr %l113, !tbaa !29
  %t295 = load ptr, ptr %l113, !tbaa !29
  %t296 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t295, i32 0, i32 2
  %t297 = load i64, ptr %t296, !tbaa !24
  %t299 = add i64 %t297, 1
  %t301 = load ptr, ptr %l113, !tbaa !29
  %t302 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t301, i32 0, i32 2
  store i64 %t299, ptr %t302, !tbaa !24
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t305 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t303, i32 0, i32 5
  store i64 0, ptr %t305, !tbaa !24
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t309 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t307, i32 0, i32 4
  %t310 = load { i64, ptr }, ptr %t309, !tbaa !27
  %t312 = extractvalue { i64, ptr } %t310, 0
  %t315 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t306, i32 0, i32 6
  store i64 %t312, ptr %t315, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2ffree_3areason_3e_2e_H6cbe162faf313bd3502650ddb9f1912a(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:reason" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/free:reason"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l14 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca %"compiler/free:reason"
  %l36 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l50 = alloca i64
  %l52 = alloca { i64, ptr }
  %l61 = alloca i64
  %l64 = alloca i64
  %l82 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l95 = alloca i64
  %l98 = alloca i64
  %l99 = alloca i64
  %l100 = alloca %"compiler/free:reason"
  %l106 = alloca { i64, ptr }
  %l110 = alloca ptr
  %l113 = alloca ptr
  %s9 = alloca %olang.scope
  %t54 = alloca i64
  %t104 = alloca i64
  %t137 = alloca i64
  %t253 = alloca i64
  store ptr %a0, ptr %l0
  store %"compiler/free:reason" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t1, i32 0, i32 2
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t5, i32 0, i32 3
  %t8 = load i64, ptr %t7, !tbaa !24
  %t11 = icmp slt i64 %t4, %t8
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l14, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t15, i32 0, i32 2
  %t18 = load i64, ptr %t17, !tbaa !24
  %t21 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %t14, i64 %t18)
  store { i64, ptr } %t21, ptr %l18
  br label %bb3
bb2:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t22, i32 0, i32 3
  %t25 = load i64, ptr %t24, !tbaa !24
  %t27 = icmp eq i64 %t25, 0
  br i1 %t27, label %bb4, label %bb5
bb3:
  %t29 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t30 = load ptr, ptr %l14, !tbaa !29
  %t31 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t30, i32 0, i32 4
  store { i64, ptr } %t29, ptr %t31, !tbaa !27
  br label %bb41
bb4:
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l22, !tbaa !29
  %t33 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  store i64 %t33, ptr %l23, !tbaa !24
  %t34 = load %"compiler/free:reason", ptr %l1
  store %"compiler/free:reason" %t34, ptr %l24
  %t35 = load i64, ptr %l23, !tbaa !24
  %t36 = icmp sge i64 %t35, 0
  br i1 %t36, label %bb6, label %bb7
bb5:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t38, i32 0, i32 0
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t45 = icmp eq i64 %t43, 0
  br i1 %t45, label %bb10, label %bb11
bb6:
  %t47 = load i64, ptr %l23, !tbaa !24
  %t48 = icmp sle i64 %t47, 230584300921369395
  br i1 %t48, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_429efc307926afcf_1f3df72c2a3e9ce3)
  unreachable
bb8:
  %t50 = load i64, ptr %l23, !tbaa !24
  %t51 = mul i64 %t50, 40
  %t52 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t51)
  %t53 = load %"compiler/free:reason", ptr %l24
  store i64 0, ptr %t54
  br label %fill.55
fill.55:
  %t58 = load i64, ptr %t54
  %t59 = icmp slt i64 %t58, %t50
  br i1 %t59, label %fillb.56, label %filld.57
fillb.56:
  %t60 = getelementptr %"compiler/free:reason", ptr %t52, i64 %t58
  store %"compiler/free:reason" %t53, ptr %t60
  %t61 = add i64 %t58, 1
  store i64 %t61, ptr %t54
  br label %fill.55
filld.57:
  %t62 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t52, 1
  %t65 = load ptr, ptr %l22, !tbaa !29
  %t66 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t65, i32 0, i32 1
  store { i64, ptr } %t63, ptr %t66, !tbaa !27
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t68, i32 0, i32 1
  %t71 = load { i64, ptr }, ptr %t70, !tbaa !27
  %t74 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t67, i32 0, i32 4
  store { i64, ptr } %t71, ptr %t74, !tbaa !27
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t75, i32 0, i32 3
  store i64 1, ptr %t77, !tbaa !24
  br label %bb40
bb9:
  call void @__olang_check_failed(ptr @olang_loc_429efc307926afcf_1f3df72c2a3e9ce3)
  unreachable
bb10:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l36, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t79, i32 0, i32 1
  %t82 = load { i64, ptr }, ptr %t81, !tbaa !27
  store { i64, ptr } %t82, ptr %l38, !tbaa !27
  %t83 = icmp sge i64 4, 0
  br i1 %t83, label %bb12, label %bb13
bb11:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t85, i32 0, i32 3
  %t88 = load i64, ptr %t87, !tbaa !24
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t89, i32 0, i32 0
  %t92 = load { i64, ptr }, ptr %t91, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t92, 0
  %t97 = icmp eq i64 %t88, %t94
  br i1 %t97, label %bb16, label %bb17
bb12:
  %t99 = icmp sle i64 4, 576460752303423487
  br i1 %t99, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_98a5072631ccd87a_280e8bc46659d6e)
  unreachable
bb14:
  %t101 = mul i64 4, 16
  %t102 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t101)
  %t103 = load { i64, ptr }, ptr %l38, !tbaa !27
  store i64 0, ptr %t104
  br label %fill.105
fill.105:
  %t108 = load i64, ptr %t104
  %t109 = icmp slt i64 %t108, 4
  br i1 %t109, label %fillb.106, label %filld.107
fillb.106:
  %t110 = getelementptr { i64, ptr }, ptr %t102, i64 %t108
  store { i64, ptr } %t103, ptr %t110
  %t111 = add i64 %t108, 1
  store i64 %t111, ptr %t104
  br label %fill.105
filld.107:
  %t112 = insertvalue { i64, ptr } undef, i64 4, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t102, 1
  %t115 = load ptr, ptr %l36, !tbaa !29
  %t116 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t115, i32 0, i32 0
  store { i64, ptr } %t113, ptr %t116, !tbaa !27
  br label %bb35
bb15:
  call void @__olang_check_failed(ptr @olang_loc_98a5072631ccd87a_280e8bc46659d6e)
  unreachable
bb16:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t117, i32 0, i32 3
  %t120 = load i64, ptr %t119, !tbaa !24
  %t122 = mul i64 %t120, 2
  store i64 %t122, ptr %l50, !tbaa !24
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t123, i32 0, i32 1
  %t126 = load { i64, ptr }, ptr %t125, !tbaa !27
  store { i64, ptr } %t126, ptr %l52, !tbaa !27
  %t127 = load i64, ptr %l50, !tbaa !24
  %t128 = icmp sge i64 %t127, 0
  br i1 %t128, label %bb18, label %bb19
bb17:
  br label %bb34
bb18:
  %t130 = load i64, ptr %l50, !tbaa !24
  %t131 = icmp sle i64 %t130, 576460752303423487
  br i1 %t131, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_53b4f4e5911227f9_f2a33cd286ff466d)
  unreachable
bb20:
  %t133 = load i64, ptr %l50, !tbaa !24
  %t134 = mul i64 %t133, 16
  %t135 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t134)
  %t136 = load { i64, ptr }, ptr %l52, !tbaa !27
  store i64 0, ptr %t137
  br label %fill.138
fill.138:
  %t141 = load i64, ptr %t137
  %t142 = icmp slt i64 %t141, %t133
  br i1 %t142, label %fillb.139, label %filld.140
fillb.139:
  %t143 = getelementptr { i64, ptr }, ptr %t135, i64 %t141
  store { i64, ptr } %t136, ptr %t143
  %t144 = add i64 %t141, 1
  store i64 %t144, ptr %t137
  br label %fill.138
filld.140:
  %t145 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t146 = insertvalue { i64, ptr } %t145, ptr %t135, 1
  store { i64, ptr } %t146, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t148, i32 0, i32 3
  %t151 = load i64, ptr %t150, !tbaa !24
  store i64 %t151, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t153 = load i64, ptr %l4, !tbaa !24
  %t154 = load i64, ptr %l3, !tbaa !24
  %t157 = icmp sgt i64 %t153, %t154
  br i1 %t157, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_53b4f4e5911227f9_f2a33cd286ff466d)
  unreachable
bb22:
  %t159 = load i64, ptr %l5, !tbaa !24
  %t161 = icmp sgt i64 %t159, 0
  br i1 %t161, label %bb24, label %bb25
bb23:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb27
bb24:
  %t163 = load i64, ptr %l4, !tbaa !24
  %t164 = load i64, ptr %l3, !tbaa !24
  %t167 = sub i64 %t163, %t164
  %t168 = load i64, ptr %l5, !tbaa !24
  %t171 = add i64 %t167, %t168
  %t173 = sub i64 %t171, 1
  %t174 = load i64, ptr %l5, !tbaa !24
  %t177 = sdiv i64 %t173, %t174
  store i64 %t177, ptr %l64, !tbaa !24
  br label %bb26
bb25:
  store i64 0, ptr %l64, !tbaa !24
  br label %bb26
bb26:
  %t179 = load i64, ptr %l64, !tbaa !24
  store i64 %t179, ptr %l61, !tbaa !24
  br label %bb27
bb27:
  %t180 = load i64, ptr %l61, !tbaa !24
  store i64 %t180, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb28
bb28:
  store %olang.scope zeroinitializer, ptr %s9
  %t181 = load i64, ptr %l7, !tbaa !24
  %t182 = load i64, ptr %l6, !tbaa !24
  %t185 = icmp slt i64 %t181, %t182
  %t187 = xor i1 %t185, true
  br i1 %t187, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s9)
  br label %bb33
bb30:
  br label %bb31
bb31:
  %t189 = load i64, ptr %l3, !tbaa !24
  %t190 = load i64, ptr %l7, !tbaa !24
  %t191 = load i64, ptr %l5, !tbaa !24
  %t194 = mul i64 %t190, %t191
  %t197 = add i64 %t189, %t194
  store i64 %t197, ptr %l8, !tbaa !24
  %t199 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t199, ptr %l82, !tbaa !27
  %t200 = load i64, ptr %l8, !tbaa !24
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t203 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t201, i32 0, i32 0
  %t204 = load { i64, ptr }, ptr %t203, !tbaa !27
  store { i64, ptr } %t204, ptr %l85, !tbaa !27
  %t205 = load i64, ptr %l8, !tbaa !24
  %t207 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !27
  %t209 = getelementptr { i64, ptr }, ptr %t208, i64 %t205
  %t210 = load { i64, ptr }, ptr %t209, !tbaa !37
  %t213 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !27
  %t215 = getelementptr { i64, ptr }, ptr %t214, i64 %t200
  store { i64, ptr } %t210, ptr %t215, !tbaa !37
  call void @__olang_scope_close(ptr %s9)
  br label %bb32
bb32:
  %t216 = load i64, ptr %l7, !tbaa !24
  %t218 = add i64 %t216, 1
  store i64 %t218, ptr %l7, !tbaa !24
  br label %bb28
bb33:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t224 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t220, i32 0, i32 0
  store { i64, ptr } %t221, ptr %t224, !tbaa !27
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t227 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t225, i32 0, i32 0
  %t228 = load { i64, ptr }, ptr %t227, !tbaa !27
  store { i64, ptr } %t228, ptr %l93, !tbaa !27
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t229, i32 0, i32 3
  %t232 = load i64, ptr %t231, !tbaa !24
  store i64 %t232, ptr %l95, !tbaa !24
  %t233 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t236 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t234, i32 0, i32 3
  %t237 = load i64, ptr %t236, !tbaa !24
  store i64 %t237, ptr %l98, !tbaa !24
  %t239 = load i64, ptr %l98, !tbaa !24
  %t240 = load i64, ptr %l98, !tbaa !24
  %t241 = shl i64 %t233, %t240
  store i64 %t241, ptr %l99, !tbaa !24
  %t242 = load %"compiler/free:reason", ptr %l1
  store %"compiler/free:reason" %t242, ptr %l100
  %t243 = load i64, ptr %l99, !tbaa !24
  %t244 = icmp sge i64 %t243, 0
  br i1 %t244, label %bb36, label %bb37
bb36:
  %t246 = load i64, ptr %l99, !tbaa !24
  %t247 = icmp sle i64 %t246, 230584300921369395
  br i1 %t247, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_3324af7e126e946c_4382e697282de140)
  unreachable
bb38:
  %t249 = load i64, ptr %l99, !tbaa !24
  %t250 = mul i64 %t249, 40
  %t251 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t250)
  %t252 = load %"compiler/free:reason", ptr %l100
  store i64 0, ptr %t253
  br label %fill.254
fill.254:
  %t257 = load i64, ptr %t253
  %t258 = icmp slt i64 %t257, %t249
  br i1 %t258, label %fillb.255, label %filld.256
fillb.255:
  %t259 = getelementptr %"compiler/free:reason", ptr %t251, i64 %t257
  store %"compiler/free:reason" %t252, ptr %t259
  %t260 = add i64 %t257, 1
  store i64 %t260, ptr %t253
  br label %fill.254
filld.256:
  %t261 = insertvalue { i64, ptr } undef, i64 %t249, 0
  %t262 = insertvalue { i64, ptr } %t261, ptr %t251, 1
  %t264 = load i64, ptr %l95, !tbaa !24
  %t265 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t266 = load ptr, ptr %t265, !tbaa !27
  %t267 = getelementptr { i64, ptr }, ptr %t266, i64 %t264
  store { i64, ptr } %t262, ptr %t267, !tbaa !37
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t271 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t269, i32 0, i32 0
  %t272 = load { i64, ptr }, ptr %t271, !tbaa !27
  store { i64, ptr } %t272, ptr %l106, !tbaa !27
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t273, i32 0, i32 3
  %t276 = load i64, ptr %t275, !tbaa !24
  %t278 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t279 = load ptr, ptr %t278, !tbaa !27
  %t280 = getelementptr { i64, ptr }, ptr %t279, i64 %t276
  %t281 = load { i64, ptr }, ptr %t280, !tbaa !37
  %t284 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t268, i32 0, i32 4
  store { i64, ptr } %t281, ptr %t284, !tbaa !27
  %t285 = load ptr, ptr %l0, !tbaa !29
  store ptr %t285, ptr %l110, !tbaa !29
  %t286 = load ptr, ptr %l110, !tbaa !29
  %t287 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t286, i32 0, i32 3
  %t288 = load i64, ptr %t287, !tbaa !24
  %t290 = add i64 %t288, 1
  %t292 = load ptr, ptr %l110, !tbaa !29
  %t293 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t292, i32 0, i32 3
  store i64 %t290, ptr %t293, !tbaa !24
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_3324af7e126e946c_4382e697282de140)
  unreachable
bb40:
  br label %bb41
bb41:
  %t294 = load ptr, ptr %l0, !tbaa !29
  store ptr %t294, ptr %l113, !tbaa !29
  %t295 = load ptr, ptr %l113, !tbaa !29
  %t296 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t295, i32 0, i32 2
  %t297 = load i64, ptr %t296, !tbaa !24
  %t299 = add i64 %t297, 1
  %t301 = load ptr, ptr %l113, !tbaa !29
  %t302 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t301, i32 0, i32 2
  store i64 %t299, ptr %t302, !tbaa !24
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t305 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t303, i32 0, i32 5
  store i64 0, ptr %t305, !tbaa !24
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t309 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t307, i32 0, i32 4
  %t310 = load { i64, ptr }, ptr %t309, !tbaa !27
  %t312 = extractvalue { i64, ptr } %t310, 0
  %t315 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t306, i32 0, i32 6
  store i64 %t312, ptr %t315, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2ffree_3areason_3e_2e_H89e89fe06e30771dfce2f242426e3874(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %r = tail call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %a0, i64 %a1)
  ret { i64, ptr } %r
}

define dso_local { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2ffree_3astore_3e_2ec_Hb4b9239c719992d58548306e87de23df(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %r = tail call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %a0, i64 %a1)
  ret { i64, ptr } %r
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2ffree_3astore_3e_2egrow_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:store" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/free:store"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l14 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca %"compiler/free:store"
  %l36 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l50 = alloca i64
  %l52 = alloca { i64, ptr }
  %l61 = alloca i64
  %l64 = alloca i64
  %l82 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l95 = alloca i64
  %l98 = alloca i64
  %l99 = alloca i64
  %l100 = alloca %"compiler/free:store"
  %l106 = alloca { i64, ptr }
  %l110 = alloca ptr
  %l113 = alloca ptr
  %s9 = alloca %olang.scope
  %t54 = alloca i64
  %t104 = alloca i64
  %t137 = alloca i64
  %t253 = alloca i64
  store ptr %a0, ptr %l0
  store %"compiler/free:store" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t1, i32 0, i32 2
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t5, i32 0, i32 3
  %t8 = load i64, ptr %t7, !tbaa !24
  %t11 = icmp slt i64 %t4, %t8
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l14, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t15, i32 0, i32 2
  %t18 = load i64, ptr %t17, !tbaa !24
  %t21 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %t14, i64 %t18)
  store { i64, ptr } %t21, ptr %l18
  br label %bb3
bb2:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t22, i32 0, i32 3
  %t25 = load i64, ptr %t24, !tbaa !24
  %t27 = icmp eq i64 %t25, 0
  br i1 %t27, label %bb4, label %bb5
bb3:
  %t29 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t30 = load ptr, ptr %l14, !tbaa !29
  %t31 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t30, i32 0, i32 4
  store { i64, ptr } %t29, ptr %t31, !tbaa !27
  br label %bb41
bb4:
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l22, !tbaa !29
  %t33 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  store i64 %t33, ptr %l23, !tbaa !24
  %t34 = load %"compiler/free:store", ptr %l1
  store %"compiler/free:store" %t34, ptr %l24
  %t35 = load i64, ptr %l23, !tbaa !24
  %t36 = icmp sge i64 %t35, 0
  br i1 %t36, label %bb6, label %bb7
bb5:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t38, i32 0, i32 0
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t45 = icmp eq i64 %t43, 0
  br i1 %t45, label %bb10, label %bb11
bb6:
  %t47 = load i64, ptr %l23, !tbaa !24
  %t48 = icmp sle i64 %t47, 128102389400760775
  br i1 %t48, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_b52d3a8395eabf75_5e0c174b8dea1469)
  unreachable
bb8:
  %t50 = load i64, ptr %l23, !tbaa !24
  %t51 = mul i64 %t50, 72
  %t52 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t51)
  %t53 = load %"compiler/free:store", ptr %l24
  store i64 0, ptr %t54
  br label %fill.55
fill.55:
  %t58 = load i64, ptr %t54
  %t59 = icmp slt i64 %t58, %t50
  br i1 %t59, label %fillb.56, label %filld.57
fillb.56:
  %t60 = getelementptr %"compiler/free:store", ptr %t52, i64 %t58
  store %"compiler/free:store" %t53, ptr %t60
  %t61 = add i64 %t58, 1
  store i64 %t61, ptr %t54
  br label %fill.55
filld.57:
  %t62 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t52, 1
  %t65 = load ptr, ptr %l22, !tbaa !29
  %t66 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t65, i32 0, i32 1
  store { i64, ptr } %t63, ptr %t66, !tbaa !27
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t68, i32 0, i32 1
  %t71 = load { i64, ptr }, ptr %t70, !tbaa !27
  %t74 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t67, i32 0, i32 4
  store { i64, ptr } %t71, ptr %t74, !tbaa !27
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t75, i32 0, i32 3
  store i64 1, ptr %t77, !tbaa !24
  br label %bb40
bb9:
  call void @__olang_check_failed(ptr @olang_loc_b52d3a8395eabf75_5e0c174b8dea1469)
  unreachable
bb10:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l36, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t79, i32 0, i32 1
  %t82 = load { i64, ptr }, ptr %t81, !tbaa !27
  store { i64, ptr } %t82, ptr %l38, !tbaa !27
  %t83 = icmp sge i64 4, 0
  br i1 %t83, label %bb12, label %bb13
bb11:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t85, i32 0, i32 3
  %t88 = load i64, ptr %t87, !tbaa !24
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t89, i32 0, i32 0
  %t92 = load { i64, ptr }, ptr %t91, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t92, 0
  %t97 = icmp eq i64 %t88, %t94
  br i1 %t97, label %bb16, label %bb17
bb12:
  %t99 = icmp sle i64 4, 576460752303423487
  br i1 %t99, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_d898010c7f057d08_da52fb6589afe29c)
  unreachable
bb14:
  %t101 = mul i64 4, 16
  %t102 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t101)
  %t103 = load { i64, ptr }, ptr %l38, !tbaa !27
  store i64 0, ptr %t104
  br label %fill.105
fill.105:
  %t108 = load i64, ptr %t104
  %t109 = icmp slt i64 %t108, 4
  br i1 %t109, label %fillb.106, label %filld.107
fillb.106:
  %t110 = getelementptr { i64, ptr }, ptr %t102, i64 %t108
  store { i64, ptr } %t103, ptr %t110
  %t111 = add i64 %t108, 1
  store i64 %t111, ptr %t104
  br label %fill.105
filld.107:
  %t112 = insertvalue { i64, ptr } undef, i64 4, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t102, 1
  %t115 = load ptr, ptr %l36, !tbaa !29
  %t116 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t115, i32 0, i32 0
  store { i64, ptr } %t113, ptr %t116, !tbaa !27
  br label %bb35
bb15:
  call void @__olang_check_failed(ptr @olang_loc_d898010c7f057d08_da52fb6589afe29c)
  unreachable
bb16:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t117, i32 0, i32 3
  %t120 = load i64, ptr %t119, !tbaa !24
  %t122 = mul i64 %t120, 2
  store i64 %t122, ptr %l50, !tbaa !24
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t123, i32 0, i32 1
  %t126 = load { i64, ptr }, ptr %t125, !tbaa !27
  store { i64, ptr } %t126, ptr %l52, !tbaa !27
  %t127 = load i64, ptr %l50, !tbaa !24
  %t128 = icmp sge i64 %t127, 0
  br i1 %t128, label %bb18, label %bb19
bb17:
  br label %bb34
bb18:
  %t130 = load i64, ptr %l50, !tbaa !24
  %t131 = icmp sle i64 %t130, 576460752303423487
  br i1 %t131, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_e0619033d37cb66b_a58ef39614cc57ff)
  unreachable
bb20:
  %t133 = load i64, ptr %l50, !tbaa !24
  %t134 = mul i64 %t133, 16
  %t135 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t134)
  %t136 = load { i64, ptr }, ptr %l52, !tbaa !27
  store i64 0, ptr %t137
  br label %fill.138
fill.138:
  %t141 = load i64, ptr %t137
  %t142 = icmp slt i64 %t141, %t133
  br i1 %t142, label %fillb.139, label %filld.140
fillb.139:
  %t143 = getelementptr { i64, ptr }, ptr %t135, i64 %t141
  store { i64, ptr } %t136, ptr %t143
  %t144 = add i64 %t141, 1
  store i64 %t144, ptr %t137
  br label %fill.138
filld.140:
  %t145 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t146 = insertvalue { i64, ptr } %t145, ptr %t135, 1
  store { i64, ptr } %t146, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t148, i32 0, i32 3
  %t151 = load i64, ptr %t150, !tbaa !24
  store i64 %t151, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t153 = load i64, ptr %l4, !tbaa !24
  %t154 = load i64, ptr %l3, !tbaa !24
  %t157 = icmp sgt i64 %t153, %t154
  br i1 %t157, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_e0619033d37cb66b_a58ef39614cc57ff)
  unreachable
bb22:
  %t159 = load i64, ptr %l5, !tbaa !24
  %t161 = icmp sgt i64 %t159, 0
  br i1 %t161, label %bb24, label %bb25
bb23:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb27
bb24:
  %t163 = load i64, ptr %l4, !tbaa !24
  %t164 = load i64, ptr %l3, !tbaa !24
  %t167 = sub i64 %t163, %t164
  %t168 = load i64, ptr %l5, !tbaa !24
  %t171 = add i64 %t167, %t168
  %t173 = sub i64 %t171, 1
  %t174 = load i64, ptr %l5, !tbaa !24
  %t177 = sdiv i64 %t173, %t174
  store i64 %t177, ptr %l64, !tbaa !24
  br label %bb26
bb25:
  store i64 0, ptr %l64, !tbaa !24
  br label %bb26
bb26:
  %t179 = load i64, ptr %l64, !tbaa !24
  store i64 %t179, ptr %l61, !tbaa !24
  br label %bb27
bb27:
  %t180 = load i64, ptr %l61, !tbaa !24
  store i64 %t180, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb28
bb28:
  store %olang.scope zeroinitializer, ptr %s9
  %t181 = load i64, ptr %l7, !tbaa !24
  %t182 = load i64, ptr %l6, !tbaa !24
  %t185 = icmp slt i64 %t181, %t182
  %t187 = xor i1 %t185, true
  br i1 %t187, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s9)
  br label %bb33
bb30:
  br label %bb31
bb31:
  %t189 = load i64, ptr %l3, !tbaa !24
  %t190 = load i64, ptr %l7, !tbaa !24
  %t191 = load i64, ptr %l5, !tbaa !24
  %t194 = mul i64 %t190, %t191
  %t197 = add i64 %t189, %t194
  store i64 %t197, ptr %l8, !tbaa !24
  %t199 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t199, ptr %l82, !tbaa !27
  %t200 = load i64, ptr %l8, !tbaa !24
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t203 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t201, i32 0, i32 0
  %t204 = load { i64, ptr }, ptr %t203, !tbaa !27
  store { i64, ptr } %t204, ptr %l85, !tbaa !27
  %t205 = load i64, ptr %l8, !tbaa !24
  %t207 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !27
  %t209 = getelementptr { i64, ptr }, ptr %t208, i64 %t205
  %t210 = load { i64, ptr }, ptr %t209, !tbaa !37
  %t213 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !27
  %t215 = getelementptr { i64, ptr }, ptr %t214, i64 %t200
  store { i64, ptr } %t210, ptr %t215, !tbaa !37
  call void @__olang_scope_close(ptr %s9)
  br label %bb32
bb32:
  %t216 = load i64, ptr %l7, !tbaa !24
  %t218 = add i64 %t216, 1
  store i64 %t218, ptr %l7, !tbaa !24
  br label %bb28
bb33:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t224 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t220, i32 0, i32 0
  store { i64, ptr } %t221, ptr %t224, !tbaa !27
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t227 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t225, i32 0, i32 0
  %t228 = load { i64, ptr }, ptr %t227, !tbaa !27
  store { i64, ptr } %t228, ptr %l93, !tbaa !27
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t229, i32 0, i32 3
  %t232 = load i64, ptr %t231, !tbaa !24
  store i64 %t232, ptr %l95, !tbaa !24
  %t233 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t236 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t234, i32 0, i32 3
  %t237 = load i64, ptr %t236, !tbaa !24
  store i64 %t237, ptr %l98, !tbaa !24
  %t239 = load i64, ptr %l98, !tbaa !24
  %t240 = load i64, ptr %l98, !tbaa !24
  %t241 = shl i64 %t233, %t240
  store i64 %t241, ptr %l99, !tbaa !24
  %t242 = load %"compiler/free:store", ptr %l1
  store %"compiler/free:store" %t242, ptr %l100
  %t243 = load i64, ptr %l99, !tbaa !24
  %t244 = icmp sge i64 %t243, 0
  br i1 %t244, label %bb36, label %bb37
bb36:
  %t246 = load i64, ptr %l99, !tbaa !24
  %t247 = icmp sle i64 %t246, 128102389400760775
  br i1 %t247, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_990c6a7262996156_af7945514905262a)
  unreachable
bb38:
  %t249 = load i64, ptr %l99, !tbaa !24
  %t250 = mul i64 %t249, 72
  %t251 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t250)
  %t252 = load %"compiler/free:store", ptr %l100
  store i64 0, ptr %t253
  br label %fill.254
fill.254:
  %t257 = load i64, ptr %t253
  %t258 = icmp slt i64 %t257, %t249
  br i1 %t258, label %fillb.255, label %filld.256
fillb.255:
  %t259 = getelementptr %"compiler/free:store", ptr %t251, i64 %t257
  store %"compiler/free:store" %t252, ptr %t259
  %t260 = add i64 %t257, 1
  store i64 %t260, ptr %t253
  br label %fill.254
filld.256:
  %t261 = insertvalue { i64, ptr } undef, i64 %t249, 0
  %t262 = insertvalue { i64, ptr } %t261, ptr %t251, 1
  %t264 = load i64, ptr %l95, !tbaa !24
  %t265 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t266 = load ptr, ptr %t265, !tbaa !27
  %t267 = getelementptr { i64, ptr }, ptr %t266, i64 %t264
  store { i64, ptr } %t262, ptr %t267, !tbaa !37
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t271 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t269, i32 0, i32 0
  %t272 = load { i64, ptr }, ptr %t271, !tbaa !27
  store { i64, ptr } %t272, ptr %l106, !tbaa !27
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t273, i32 0, i32 3
  %t276 = load i64, ptr %t275, !tbaa !24
  %t278 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t279 = load ptr, ptr %t278, !tbaa !27
  %t280 = getelementptr { i64, ptr }, ptr %t279, i64 %t276
  %t281 = load { i64, ptr }, ptr %t280, !tbaa !37
  %t284 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t268, i32 0, i32 4
  store { i64, ptr } %t281, ptr %t284, !tbaa !27
  %t285 = load ptr, ptr %l0, !tbaa !29
  store ptr %t285, ptr %l110, !tbaa !29
  %t286 = load ptr, ptr %l110, !tbaa !29
  %t287 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t286, i32 0, i32 3
  %t288 = load i64, ptr %t287, !tbaa !24
  %t290 = add i64 %t288, 1
  %t292 = load ptr, ptr %l110, !tbaa !29
  %t293 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t292, i32 0, i32 3
  store i64 %t290, ptr %t293, !tbaa !24
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_990c6a7262996156_af7945514905262a)
  unreachable
bb40:
  br label %bb41
bb41:
  %t294 = load ptr, ptr %l0, !tbaa !29
  store ptr %t294, ptr %l113, !tbaa !29
  %t295 = load ptr, ptr %l113, !tbaa !29
  %t296 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t295, i32 0, i32 2
  %t297 = load i64, ptr %t296, !tbaa !24
  %t299 = add i64 %t297, 1
  %t301 = load ptr, ptr %l113, !tbaa !29
  %t302 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t301, i32 0, i32 2
  store i64 %t299, ptr %t302, !tbaa !24
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t305 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t303, i32 0, i32 5
  store i64 0, ptr %t305, !tbaa !24
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t309 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t307, i32 0, i32 4
  %t310 = load { i64, ptr }, ptr %t309, !tbaa !27
  %t312 = extractvalue { i64, ptr } %t310, 0
  %t315 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t306, i32 0, i32 6
  store i64 %t312, ptr %t315, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2ffree_3astore_3e_2er_H8f5382166bb0516c64c843418d12825c(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l16 = alloca i64
  %l18 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l34 = alloca i64
  %l36 = alloca i64
  %l39 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca i64
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t2, i32 0, i32 2
  %t5 = load i64, ptr %t4, !tbaa !24
  %t7 = sub i64 %t5, 1
  %t10 = icmp eq i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i64, ptr %l1, !tbaa !24
  %t16 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %t12, i64 %t13)
  store { i64, ptr } %t16, ptr %l10
  br label %bb3
bb2:
  br label %bb10
bb3:
  %t17 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t17, ptr %l11, !tbaa !27
  %t18 = load i64, ptr %l2, !tbaa !24
  %t19 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t22 = add i64 %t18, %t19
  %t23 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t24 = load i64, ptr %l1, !tbaa !24
  store i64 %t24, ptr %l16, !tbaa !24
  %t26 = load i64, ptr %l16, !tbaa !24
  %t27 = load i64, ptr %l16, !tbaa !24
  %t28 = shl i64 %t23, %t27
  %t31 = sub i64 %t22, %t28
  store i64 %t31, ptr %l18, !tbaa !24
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t32, i32 0, i32 5
  %t35 = load i64, ptr %t34, !tbaa !24
  store i64 %t35, ptr %l20, !tbaa !24
  %t36 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t36, 0
  store i64 %t37, ptr %l21, !tbaa !24
  %t38 = load i64, ptr %l18, !tbaa !24
  %t39 = icmp sge i64 %t38, 0
  br i1 %t39, label %bb4, label %bb5
bb4:
  %t41 = load i64, ptr %l18, !tbaa !24
  %t42 = load i64, ptr %l20, !tbaa !24
  %t43 = icmp sle i64 %t41, %t42
  br i1 %t43, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_46c408dee3f11363_d26d32f12e5fd18f)
  unreachable
bb6:
  %t45 = load i64, ptr %l20, !tbaa !24
  %t46 = load i64, ptr %l21, !tbaa !24
  %t47 = icmp sle i64 %t45, %t46
  br i1 %t47, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_46c408dee3f11363_d26d32f12e5fd18f)
  unreachable
bb8:
  %t49 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = load i64, ptr %l18, !tbaa !24
  %t52 = load i64, ptr %l20, !tbaa !24
  %t53 = getelementptr %"compiler/free:store", ptr %t50, i64 %t51
  %t54 = sub i64 %t52, %t51
  %t55 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t53, 1
  store { i64, ptr } %t56, ptr %rv
  br label %ret
bb9:
  call void @__olang_check_failed(ptr @olang_loc_46c408dee3f11363_d26d32f12e5fd18f)
  unreachable
bb10:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i64, ptr %l1, !tbaa !24
  %t62 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %t58, i64 %t59)
  store { i64, ptr } %t62, ptr %l28
  br label %bb11
bb11:
  %t63 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t63, ptr %l29, !tbaa !27
  %t64 = load i64, ptr %l2, !tbaa !24
  %t65 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t68 = add i64 %t64, %t65
  %t69 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t70 = load i64, ptr %l1, !tbaa !24
  store i64 %t70, ptr %l34, !tbaa !24
  %t72 = load i64, ptr %l34, !tbaa !24
  %t73 = load i64, ptr %l34, !tbaa !24
  %t74 = shl i64 %t69, %t73
  %t77 = sub i64 %t68, %t74
  store i64 %t77, ptr %l36, !tbaa !24
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load i64, ptr %l1, !tbaa !24
  %t82 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %t78, i64 %t79)
  store { i64, ptr } %t82, ptr %l39
  br label %bb12
bb12:
  %t83 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t83, 0
  store i64 %t86, ptr %l42, !tbaa !24
  %t87 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t87, 0
  store i64 %t88, ptr %l43, !tbaa !24
  %t89 = load i64, ptr %l36, !tbaa !24
  %t90 = icmp sge i64 %t89, 0
  br i1 %t90, label %bb13, label %bb14
bb13:
  %t92 = load i64, ptr %l36, !tbaa !24
  %t93 = load i64, ptr %l42, !tbaa !24
  %t94 = icmp sle i64 %t92, %t93
  br i1 %t94, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_466c920e18c96886_c74c7dd2ac627792)
  unreachable
bb15:
  %t96 = load i64, ptr %l42, !tbaa !24
  %t97 = load i64, ptr %l43, !tbaa !24
  %t98 = icmp sle i64 %t96, %t97
  br i1 %t98, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_466c920e18c96886_c74c7dd2ac627792)
  unreachable
bb17:
  %t100 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = load i64, ptr %l36, !tbaa !24
  %t103 = load i64, ptr %l42, !tbaa !24
  %t104 = getelementptr %"compiler/free:store", ptr %t101, i64 %t102
  %t105 = sub i64 %t103, %t102
  %t106 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t104, 1
  store { i64, ptr } %t107, ptr %rv
  br label %ret
bb18:
  call void @__olang_check_failed(ptr @olang_loc_466c920e18c96886_c74c7dd2ac627792)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cmut_20std_2fprelude_2flist_3aL_H109db4260b96f7111c5f399a696451d9(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %r = tail call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %a0, i64 %a1)
  ret { i64, ptr } %r
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cmut_20std_2fprelude_2flist_3aL_H1374452f2665ef16934575a2867dd20b(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  tail call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2fast_3aDecl_26_3e_2e_H41acc6e44116d166ef90f4d71eec6f8c(ptr %v0, ptr %a0, i64 %a1)
  ret void
}

define dso_local { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cmut_20std_2fprelude_2flist_3aL_H2fc8c4aae389a7ad5d710f8f97391a1c(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %r = tail call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %a0, i64 %a1)
  ret { i64, ptr } %r
}

define dso_local { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cmut_20std_2fprelude_2flist_3aL_H614e1c63727470108a5948d37937b8ca(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %r = tail call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2fcond_3aGlobal_26_3e_H3a47d2b30dd068f82b18182b93098e2f(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
  ret { i64, ptr } %r
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cmut_20std_2fprelude_2flist_3aL_H84c5f1e695ee5f87d93f6062576ad25a(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  tail call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2fcond_3aGlobal_26_3e_He54124e4892c254df357a8103d0ba529(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
  ret void
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cmut_20std_2fprelude_2flist_3aL_H9921565811743c9f8745382c9bcc2238(ptr %v0, ptr %a0) #0 {
entry:
  tail call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cI64_3e_2edropLast_3cI64_3e(ptr %v0, ptr %a0)
  ret void
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cmut_20std_2fprelude_2flist_3aL_Hf31e8e8d688e9be9d404bddf808c9275(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  tail call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2fcond_3aGlobal_26_3e_He54124e4892c254df357a8103d0ba529(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
  ret void
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cstd_2fprelude_2flist_3aList_3c_H813f9a021eaad905003370f9e15e02df(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l14 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l36 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l50 = alloca i64
  %l52 = alloca { i64, ptr }
  %l61 = alloca i64
  %l64 = alloca i64
  %l82 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l95 = alloca i64
  %l98 = alloca i64
  %l99 = alloca i64
  %l100 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l106 = alloca { i64, ptr }
  %l110 = alloca ptr
  %l113 = alloca ptr
  %s9 = alloca %olang.scope
  %t54 = alloca i64
  %t104 = alloca i64
  %t137 = alloca i64
  %t253 = alloca i64
  store ptr %a0, ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t1, i32 0, i32 2
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t5, i32 0, i32 3
  %t8 = load i64, ptr %t7, !tbaa !24
  %t11 = icmp slt i64 %t4, %t8
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l14, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t15, i32 0, i32 2
  %t18 = load i64, ptr %t17, !tbaa !24
  %t21 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %t14, i64 %t18)
  store { i64, ptr } %t21, ptr %l18
  br label %bb3
bb2:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t22, i32 0, i32 3
  %t25 = load i64, ptr %t24, !tbaa !24
  %t27 = icmp eq i64 %t25, 0
  br i1 %t27, label %bb4, label %bb5
bb3:
  %t29 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t30 = load ptr, ptr %l14, !tbaa !29
  %t31 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t30, i32 0, i32 4
  store { i64, ptr } %t29, ptr %t31, !tbaa !27
  br label %bb41
bb4:
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l22, !tbaa !29
  %t33 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  store i64 %t33, ptr %l23, !tbaa !24
  %t34 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l1
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t34, ptr %l24
  %t35 = load i64, ptr %l23, !tbaa !24
  %t36 = icmp sge i64 %t35, 0
  br i1 %t36, label %bb6, label %bb7
bb5:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t38, i32 0, i32 0
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t45 = icmp eq i64 %t43, 0
  br i1 %t45, label %bb10, label %bb11
bb6:
  %t47 = load i64, ptr %l23, !tbaa !24
  %t48 = icmp sle i64 %t47, 1152921504606846975
  br i1 %t48, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_108e5757266db8ac_128972bb016af7b8)
  unreachable
bb8:
  %t50 = load i64, ptr %l23, !tbaa !24
  %t51 = mul i64 %t50, 8
  %t52 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t51)
  %t53 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l24
  store i64 0, ptr %t54
  br label %fill.55
fill.55:
  %t58 = load i64, ptr %t54
  %t59 = icmp slt i64 %t58, %t50
  br i1 %t59, label %fillb.56, label %filld.57
fillb.56:
  %t60 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t52, i64 %t58
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t53, ptr %t60
  %t61 = add i64 %t58, 1
  store i64 %t61, ptr %t54
  br label %fill.55
filld.57:
  %t62 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t52, 1
  %t65 = load ptr, ptr %l22, !tbaa !29
  %t66 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t65, i32 0, i32 1
  store { i64, ptr } %t63, ptr %t66, !tbaa !27
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t68, i32 0, i32 1
  %t71 = load { i64, ptr }, ptr %t70, !tbaa !27
  %t74 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t67, i32 0, i32 4
  store { i64, ptr } %t71, ptr %t74, !tbaa !27
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t75, i32 0, i32 3
  store i64 1, ptr %t77, !tbaa !24
  br label %bb40
bb9:
  call void @__olang_check_failed(ptr @olang_loc_108e5757266db8ac_128972bb016af7b8)
  unreachable
bb10:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l36, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t79, i32 0, i32 1
  %t82 = load { i64, ptr }, ptr %t81, !tbaa !27
  store { i64, ptr } %t82, ptr %l38, !tbaa !27
  %t83 = icmp sge i64 4, 0
  br i1 %t83, label %bb12, label %bb13
bb11:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t85, i32 0, i32 3
  %t88 = load i64, ptr %t87, !tbaa !24
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t89, i32 0, i32 0
  %t92 = load { i64, ptr }, ptr %t91, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t92, 0
  %t97 = icmp eq i64 %t88, %t94
  br i1 %t97, label %bb16, label %bb17
bb12:
  %t99 = icmp sle i64 4, 576460752303423487
  br i1 %t99, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_1308736d7ec13239_270fdc3ed266f225)
  unreachable
bb14:
  %t101 = mul i64 4, 16
  %t102 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t101)
  %t103 = load { i64, ptr }, ptr %l38, !tbaa !27
  store i64 0, ptr %t104
  br label %fill.105
fill.105:
  %t108 = load i64, ptr %t104
  %t109 = icmp slt i64 %t108, 4
  br i1 %t109, label %fillb.106, label %filld.107
fillb.106:
  %t110 = getelementptr { i64, ptr }, ptr %t102, i64 %t108
  store { i64, ptr } %t103, ptr %t110
  %t111 = add i64 %t108, 1
  store i64 %t111, ptr %t104
  br label %fill.105
filld.107:
  %t112 = insertvalue { i64, ptr } undef, i64 4, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t102, 1
  %t115 = load ptr, ptr %l36, !tbaa !29
  %t116 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t115, i32 0, i32 0
  store { i64, ptr } %t113, ptr %t116, !tbaa !27
  br label %bb35
bb15:
  call void @__olang_check_failed(ptr @olang_loc_1308736d7ec13239_270fdc3ed266f225)
  unreachable
bb16:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t117, i32 0, i32 3
  %t120 = load i64, ptr %t119, !tbaa !24
  %t122 = mul i64 %t120, 2
  store i64 %t122, ptr %l50, !tbaa !24
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t123, i32 0, i32 1
  %t126 = load { i64, ptr }, ptr %t125, !tbaa !27
  store { i64, ptr } %t126, ptr %l52, !tbaa !27
  %t127 = load i64, ptr %l50, !tbaa !24
  %t128 = icmp sge i64 %t127, 0
  br i1 %t128, label %bb18, label %bb19
bb17:
  br label %bb34
bb18:
  %t130 = load i64, ptr %l50, !tbaa !24
  %t131 = icmp sle i64 %t130, 576460752303423487
  br i1 %t131, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_484f3997ac5f49ba_a3a07b6315e3d006)
  unreachable
bb20:
  %t133 = load i64, ptr %l50, !tbaa !24
  %t134 = mul i64 %t133, 16
  %t135 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t134)
  %t136 = load { i64, ptr }, ptr %l52, !tbaa !27
  store i64 0, ptr %t137
  br label %fill.138
fill.138:
  %t141 = load i64, ptr %t137
  %t142 = icmp slt i64 %t141, %t133
  br i1 %t142, label %fillb.139, label %filld.140
fillb.139:
  %t143 = getelementptr { i64, ptr }, ptr %t135, i64 %t141
  store { i64, ptr } %t136, ptr %t143
  %t144 = add i64 %t141, 1
  store i64 %t144, ptr %t137
  br label %fill.138
filld.140:
  %t145 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t146 = insertvalue { i64, ptr } %t145, ptr %t135, 1
  store { i64, ptr } %t146, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t148, i32 0, i32 3
  %t151 = load i64, ptr %t150, !tbaa !24
  store i64 %t151, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t153 = load i64, ptr %l4, !tbaa !24
  %t154 = load i64, ptr %l3, !tbaa !24
  %t157 = icmp sgt i64 %t153, %t154
  br i1 %t157, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_484f3997ac5f49ba_a3a07b6315e3d006)
  unreachable
bb22:
  %t159 = load i64, ptr %l5, !tbaa !24
  %t161 = icmp sgt i64 %t159, 0
  br i1 %t161, label %bb24, label %bb25
bb23:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb27
bb24:
  %t163 = load i64, ptr %l4, !tbaa !24
  %t164 = load i64, ptr %l3, !tbaa !24
  %t167 = sub i64 %t163, %t164
  %t168 = load i64, ptr %l5, !tbaa !24
  %t171 = add i64 %t167, %t168
  %t173 = sub i64 %t171, 1
  %t174 = load i64, ptr %l5, !tbaa !24
  %t177 = sdiv i64 %t173, %t174
  store i64 %t177, ptr %l64, !tbaa !24
  br label %bb26
bb25:
  store i64 0, ptr %l64, !tbaa !24
  br label %bb26
bb26:
  %t179 = load i64, ptr %l64, !tbaa !24
  store i64 %t179, ptr %l61, !tbaa !24
  br label %bb27
bb27:
  %t180 = load i64, ptr %l61, !tbaa !24
  store i64 %t180, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb28
bb28:
  store %olang.scope zeroinitializer, ptr %s9
  %t181 = load i64, ptr %l7, !tbaa !24
  %t182 = load i64, ptr %l6, !tbaa !24
  %t185 = icmp slt i64 %t181, %t182
  %t187 = xor i1 %t185, true
  br i1 %t187, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s9)
  br label %bb33
bb30:
  br label %bb31
bb31:
  %t189 = load i64, ptr %l3, !tbaa !24
  %t190 = load i64, ptr %l7, !tbaa !24
  %t191 = load i64, ptr %l5, !tbaa !24
  %t194 = mul i64 %t190, %t191
  %t197 = add i64 %t189, %t194
  store i64 %t197, ptr %l8, !tbaa !24
  %t199 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t199, ptr %l82, !tbaa !27
  %t200 = load i64, ptr %l8, !tbaa !24
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t203 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t201, i32 0, i32 0
  %t204 = load { i64, ptr }, ptr %t203, !tbaa !27
  store { i64, ptr } %t204, ptr %l85, !tbaa !27
  %t205 = load i64, ptr %l8, !tbaa !24
  %t207 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !27
  %t209 = getelementptr { i64, ptr }, ptr %t208, i64 %t205
  %t210 = load { i64, ptr }, ptr %t209, !tbaa !37
  %t213 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !27
  %t215 = getelementptr { i64, ptr }, ptr %t214, i64 %t200
  store { i64, ptr } %t210, ptr %t215, !tbaa !37
  call void @__olang_scope_close(ptr %s9)
  br label %bb32
bb32:
  %t216 = load i64, ptr %l7, !tbaa !24
  %t218 = add i64 %t216, 1
  store i64 %t218, ptr %l7, !tbaa !24
  br label %bb28
bb33:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t224 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t220, i32 0, i32 0
  store { i64, ptr } %t221, ptr %t224, !tbaa !27
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t227 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t225, i32 0, i32 0
  %t228 = load { i64, ptr }, ptr %t227, !tbaa !27
  store { i64, ptr } %t228, ptr %l93, !tbaa !27
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t229, i32 0, i32 3
  %t232 = load i64, ptr %t231, !tbaa !24
  store i64 %t232, ptr %l95, !tbaa !24
  %t233 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t236 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t234, i32 0, i32 3
  %t237 = load i64, ptr %t236, !tbaa !24
  store i64 %t237, ptr %l98, !tbaa !24
  %t239 = load i64, ptr %l98, !tbaa !24
  %t240 = load i64, ptr %l98, !tbaa !24
  %t241 = shl i64 %t233, %t240
  store i64 %t241, ptr %l99, !tbaa !24
  %t242 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l1
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t242, ptr %l100
  %t243 = load i64, ptr %l99, !tbaa !24
  %t244 = icmp sge i64 %t243, 0
  br i1 %t244, label %bb36, label %bb37
bb36:
  %t246 = load i64, ptr %l99, !tbaa !24
  %t247 = icmp sle i64 %t246, 1152921504606846975
  br i1 %t247, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_61c24a44fab6a30f_efd075332c62999b)
  unreachable
bb38:
  %t249 = load i64, ptr %l99, !tbaa !24
  %t250 = mul i64 %t249, 8
  %t251 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t250)
  %t252 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l100
  store i64 0, ptr %t253
  br label %fill.254
fill.254:
  %t257 = load i64, ptr %t253
  %t258 = icmp slt i64 %t257, %t249
  br i1 %t258, label %fillb.255, label %filld.256
fillb.255:
  %t259 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t251, i64 %t257
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t252, ptr %t259
  %t260 = add i64 %t257, 1
  store i64 %t260, ptr %t253
  br label %fill.254
filld.256:
  %t261 = insertvalue { i64, ptr } undef, i64 %t249, 0
  %t262 = insertvalue { i64, ptr } %t261, ptr %t251, 1
  %t264 = load i64, ptr %l95, !tbaa !24
  %t265 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t266 = load ptr, ptr %t265, !tbaa !27
  %t267 = getelementptr { i64, ptr }, ptr %t266, i64 %t264
  store { i64, ptr } %t262, ptr %t267, !tbaa !37
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t271 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t269, i32 0, i32 0
  %t272 = load { i64, ptr }, ptr %t271, !tbaa !27
  store { i64, ptr } %t272, ptr %l106, !tbaa !27
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t273, i32 0, i32 3
  %t276 = load i64, ptr %t275, !tbaa !24
  %t278 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t279 = load ptr, ptr %t278, !tbaa !27
  %t280 = getelementptr { i64, ptr }, ptr %t279, i64 %t276
  %t281 = load { i64, ptr }, ptr %t280, !tbaa !37
  %t284 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t268, i32 0, i32 4
  store { i64, ptr } %t281, ptr %t284, !tbaa !27
  %t285 = load ptr, ptr %l0, !tbaa !29
  store ptr %t285, ptr %l110, !tbaa !29
  %t286 = load ptr, ptr %l110, !tbaa !29
  %t287 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t286, i32 0, i32 3
  %t288 = load i64, ptr %t287, !tbaa !24
  %t290 = add i64 %t288, 1
  %t292 = load ptr, ptr %l110, !tbaa !29
  %t293 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t292, i32 0, i32 3
  store i64 %t290, ptr %t293, !tbaa !24
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_61c24a44fab6a30f_efd075332c62999b)
  unreachable
bb40:
  br label %bb41
bb41:
  %t294 = load ptr, ptr %l0, !tbaa !29
  store ptr %t294, ptr %l113, !tbaa !29
  %t295 = load ptr, ptr %l113, !tbaa !29
  %t296 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t295, i32 0, i32 2
  %t297 = load i64, ptr %t296, !tbaa !24
  %t299 = add i64 %t297, 1
  %t301 = load ptr, ptr %l113, !tbaa !29
  %t302 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t301, i32 0, i32 2
  store i64 %t299, ptr %t302, !tbaa !24
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t305 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t303, i32 0, i32 5
  store i64 0, ptr %t305, !tbaa !24
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t309 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t307, i32 0, i32 4
  %t310 = load { i64, ptr }, ptr %t309, !tbaa !27
  %t312 = extractvalue { i64, ptr } %t310, 0
  %t315 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t306, i32 0, i32 6
  store i64 %t312, ptr %t315, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cstd_2fprelude_2flist_3aList_3c_Hcbfcd430d013c01db662622b29ca0251(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %r = tail call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %a0, i64 %a1)
  ret { i64, ptr } %r
}

define dso_local { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cstd_2fprelude_2flist_3aList_3c_Hd153ccd47b7407ea95231a0cf1039694(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l16 = alloca i64
  %l18 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l34 = alloca i64
  %l36 = alloca i64
  %l39 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca i64
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t2, i32 0, i32 2
  %t5 = load i64, ptr %t4, !tbaa !24
  %t7 = sub i64 %t5, 1
  %t10 = icmp eq i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i64, ptr %l1, !tbaa !24
  %t16 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %t12, i64 %t13)
  store { i64, ptr } %t16, ptr %l10
  br label %bb3
bb2:
  br label %bb10
bb3:
  %t17 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t17, ptr %l11, !tbaa !27
  %t18 = load i64, ptr %l2, !tbaa !24
  %t19 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t22 = add i64 %t18, %t19
  %t23 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t24 = load i64, ptr %l1, !tbaa !24
  store i64 %t24, ptr %l16, !tbaa !24
  %t26 = load i64, ptr %l16, !tbaa !24
  %t27 = load i64, ptr %l16, !tbaa !24
  %t28 = shl i64 %t23, %t27
  %t31 = sub i64 %t22, %t28
  store i64 %t31, ptr %l18, !tbaa !24
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t32, i32 0, i32 5
  %t35 = load i64, ptr %t34, !tbaa !24
  store i64 %t35, ptr %l20, !tbaa !24
  %t36 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t36, 0
  store i64 %t37, ptr %l21, !tbaa !24
  %t38 = load i64, ptr %l18, !tbaa !24
  %t39 = icmp sge i64 %t38, 0
  br i1 %t39, label %bb4, label %bb5
bb4:
  %t41 = load i64, ptr %l18, !tbaa !24
  %t42 = load i64, ptr %l20, !tbaa !24
  %t43 = icmp sle i64 %t41, %t42
  br i1 %t43, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_58225400e40d3852_8a3830025fc53636)
  unreachable
bb6:
  %t45 = load i64, ptr %l20, !tbaa !24
  %t46 = load i64, ptr %l21, !tbaa !24
  %t47 = icmp sle i64 %t45, %t46
  br i1 %t47, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_58225400e40d3852_8a3830025fc53636)
  unreachable
bb8:
  %t49 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = load i64, ptr %l18, !tbaa !24
  %t52 = load i64, ptr %l20, !tbaa !24
  %t53 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t50, i64 %t51
  %t54 = sub i64 %t52, %t51
  %t55 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t53, 1
  store { i64, ptr } %t56, ptr %rv
  br label %ret
bb9:
  call void @__olang_check_failed(ptr @olang_loc_58225400e40d3852_8a3830025fc53636)
  unreachable
bb10:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i64, ptr %l1, !tbaa !24
  %t62 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %t58, i64 %t59)
  store { i64, ptr } %t62, ptr %l28
  br label %bb11
bb11:
  %t63 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t63, ptr %l29, !tbaa !27
  %t64 = load i64, ptr %l2, !tbaa !24
  %t65 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t68 = add i64 %t64, %t65
  %t69 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t70 = load i64, ptr %l1, !tbaa !24
  store i64 %t70, ptr %l34, !tbaa !24
  %t72 = load i64, ptr %l34, !tbaa !24
  %t73 = load i64, ptr %l34, !tbaa !24
  %t74 = shl i64 %t69, %t73
  %t77 = sub i64 %t68, %t74
  store i64 %t77, ptr %l36, !tbaa !24
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load i64, ptr %l1, !tbaa !24
  %t82 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %t78, i64 %t79)
  store { i64, ptr } %t82, ptr %l39
  br label %bb12
bb12:
  %t83 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t83, 0
  store i64 %t86, ptr %l42, !tbaa !24
  %t87 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t87, 0
  store i64 %t88, ptr %l43, !tbaa !24
  %t89 = load i64, ptr %l36, !tbaa !24
  %t90 = icmp sge i64 %t89, 0
  br i1 %t90, label %bb13, label %bb14
bb13:
  %t92 = load i64, ptr %l36, !tbaa !24
  %t93 = load i64, ptr %l42, !tbaa !24
  %t94 = icmp sle i64 %t92, %t93
  br i1 %t94, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_d8bdf07c21a0a84f_8a49261db8489a93)
  unreachable
bb15:
  %t96 = load i64, ptr %l42, !tbaa !24
  %t97 = load i64, ptr %l43, !tbaa !24
  %t98 = icmp sle i64 %t96, %t97
  br i1 %t98, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_d8bdf07c21a0a84f_8a49261db8489a93)
  unreachable
bb17:
  %t100 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = load i64, ptr %l36, !tbaa !24
  %t103 = load i64, ptr %l42, !tbaa !24
  %t104 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t101, i64 %t102
  %t105 = sub i64 %t103, %t102
  %t106 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t104, 1
  store { i64, ptr } %t107, ptr %rv
  br label %ret
bb18:
  call void @__olang_check_failed(ptr @olang_loc_d8bdf07c21a0a84f_8a49261db8489a93)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @std_2fprelude_2flist_2etypeWritten_3cI64_3e(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l7 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t2, 0
  store i64 %t3, ptr %l3, !tbaa !24
  %t4 = icmp sge i64 0, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = icmp sle i64 0, 0
  br i1 %t6, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_724541474394e48a_9599c4eb52cbbbbe)
  unreachable
bb3:
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp sle i64 0, %t8
  br i1 %t9, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_724541474394e48a_9599c4eb52cbbbbe)
  unreachable
bb5:
  %t11 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !27
  %t13 = getelementptr i64, ptr %t12, i64 0
  store ptr %t13, ptr %l7
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  call void @olang_2eHelperKind_2eRender_2eArray_3cI64_2c_200_3e_26(ptr %s1, ptr %l7, i64 0)
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_724541474394e48a_9599c4eb52cbbbbe)
  unreachable
bb7:
  %t15 = load ptr, ptr %s1
  %t16 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t17 = load i64, ptr %t16
  %t18 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t17)
  call void @olang_textcopy(ptr %t18, ptr %t15, i64 %t17)
  %t19 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l9, !tbaa !27
  %t21 = getelementptr %olang.builder, ptr %s1, i32 0, i32 3
  %t22 = load ptr, ptr %t21
  %t23 = icmp ne ptr %t22, null
  br i1 %t23, label %sbgrew.24, label %sbdone.25
sbgrew.24:
  call void @__olang_sb_done(ptr %s1)
  br label %sbdone.25
sbdone.25:
  %t26 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t26, ptr %l1, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t31 = sub i64 %t29, 2
  store i64 %t31, ptr %l12, !tbaa !24
  %t32 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t32, 0
  store i64 %t33, ptr %l13, !tbaa !24
  %t34 = icmp sge i64 0, 0
  br i1 %t34, label %bb8, label %bb9
bb8:
  %t36 = load i64, ptr %l12, !tbaa !24
  %t37 = icmp sle i64 0, %t36
  br i1 %t37, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_5274c9e04eb87767_80927fe9d150cd3b)
  unreachable
bb10:
  %t39 = load i64, ptr %l12, !tbaa !24
  %t40 = load i64, ptr %l13, !tbaa !24
  %t41 = icmp sle i64 %t39, %t40
  br i1 %t41, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_5274c9e04eb87767_80927fe9d150cd3b)
  unreachable
bb12:
  %t43 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = load i64, ptr %l12, !tbaa !24
  %t46 = getelementptr i8, ptr %t44, i64 0
  %t47 = sub i64 %t45, 0
  %t48 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t46, 1
  %t51 = extractvalue { i64, ptr } %t49, 1
  %t52 = extractvalue { i64, ptr } %t49, 0
  %t53 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t52)
  call void @olang_textcopy(ptr %t53, ptr %t51, i64 %t52)
  %t54 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t53, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t55, ptr %rv
  br label %ret
bb13:
  call void @__olang_check_failed(ptr @olang_loc_5274c9e04eb87767_80927fe9d150cd3b)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ffree_3aleaf_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fgeneric_3aOrigin_3e_2ector(ptr %v0)
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ffree_3aletGo_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fdiag_3aItem_3e_2ector(ptr %v0)
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ffree_3aorCall_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2ector(ptr %v0)
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ffree_3aorStore_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fscope_3aGap_3e_2ector(ptr %v0)
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ffree_3areason_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fscope_3afnUse_3e_2ector(ptr %v0)
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ffree_3astore_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fdiag_3aItem_3e_2ector(ptr %v0)
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3cBool_3e_26_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cU64_3e_2ector(ptr %v0)
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3cI64_3e_26_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cU64_3e_2ector(ptr %v0)
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3cI64_3e_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cU64_3e_2ector(ptr %v0)
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" @std_2fprelude_2flist_3alistState_3ccompiler_2ffree_3aleaf_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" @std_2fprelude_2flist_3alistState_3ccompiler_2fgeneric_3aOrigin_3e_2ector(ptr %v0)
  ret %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %r
}

define dso_local %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" @std_2fprelude_2flist_3alistState_3ccompiler_2ffree_3aletGo_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" @std_2fprelude_2flist_3alistState_3ccompiler_2fdiag_3aItem_3e_2ector(ptr %v0)
  ret %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %r
}

define dso_local %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" @std_2fprelude_2flist_3alistState_3ccompiler_2ffree_3aorCall_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" @std_2fprelude_2flist_3alistState_3ccompiler_2fbuild_3aUnit_3e_2ector(ptr %v0)
  ret %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %r
}

define dso_local %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" @std_2fprelude_2flist_3alistState_3ccompiler_2ffree_3aorStore_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" @std_2fprelude_2flist_3alistState_3ccompiler_2fscope_3aGap_3e_2ector(ptr %v0)
  ret %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %r
}

define dso_local %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" @std_2fprelude_2flist_3alistState_3ccompiler_2ffree_3areason_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" @std_2fprelude_2flist_3alistState_3ccompiler_2fscope_3afnUse_3e_2ector(ptr %v0)
  ret %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %r
}

define dso_local %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" @std_2fprelude_2flist_3alistState_3ccompiler_2ffree_3astore_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" @std_2fprelude_2flist_3alistState_3ccompiler_2fdiag_3aItem_3e_2ector(ptr %v0)
  ret %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %r
}

define dso_local %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" @std_2fprelude_2flist_3alistState_3cmut_20std_2fprelude_2flist_3aList_3cBool_3e_26_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" @std_2fprelude_2flist_3alistState_3cU64_3e_2ector(ptr %v0)
  ret %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %r
}

define dso_local %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" @std_2fprelude_2flist_3alistState_3cmut_20std_2fprelude_2flist_3aList_3cI64_3e_26_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" @std_2fprelude_2flist_3alistState_3cU64_3e_2ector(ptr %v0)
  ret %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %r
}

define dso_local %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" @std_2fprelude_2flist_3alistState_3cstd_2fprelude_2flist_3aList_3cI64_3e_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" @std_2fprelude_2flist_3alistState_3cU64_3e_2ector(ptr %v0)
  ret %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %r
}

define dso_local i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_H1a2c153a44db96cb4cb83bb1fc8b3b35(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l10 = alloca i64
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t6, i32 0, i32 0
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  store { i64, ptr } %t9, ptr %l7, !tbaa !27
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t11 = load i32, ptr %l1, !tbaa !23
  %t14 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2fsource_3aNameId_2c_20B_Heab357d0b792d165805bc071c98cf6d1(ptr %v0, ptr %t10, i32 %t11)
  store i64 %t14, ptr %l10
  br label %bb1
bb1:
  %t15 = load i64, ptr %l10, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr ptr, ptr %t17, i64 %t15
  %t19 = load ptr, ptr %t18, !tbaa !39
  store ptr %t19, ptr %l3, !tbaa !29
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t23 = icmp eq ptr %t21, null
  %t25 = xor i1 %t23, true
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb4:
  br label %bb5
bb5:
  %t29 = load ptr, ptr %l3, !tbaa !29
  %t31 = getelementptr %"std/prelude/map:mapSlot.06e151a31bcf6a36b74a6345f34868d6", ptr %t29, i32 0, i32 0
  %t32 = getelementptr %"std/prelude/map:MapEntry.7071498ebd14ce3832ebc61ca83442cc", ptr %t31, i32 0, i32 0
  %t33 = load i32, ptr %t32, !tbaa !23
  %t34 = load i32, ptr %l1, !tbaa !23
  %t37 = icmp eq i32 %t33, %t34
  br i1 %t37, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb9
bb9:
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t42 = getelementptr %"std/prelude/map:mapSlot.06e151a31bcf6a36b74a6345f34868d6", ptr %t40, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !29
  store ptr %t43, ptr %l3, !tbaa !29
  br label %bb2
bb10:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_H56aba43bb329356750417c3998c5c01b(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l10 = alloca i64
  %s2 = alloca %olang.scope
  %rv = alloca { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t6, i32 0, i32 0
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  store { i64, ptr } %t9, ptr %l7, !tbaa !27
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t11 = load i32, ptr %l1, !tbaa !23
  %t14 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2fsource_3aNameId_2c_20B_Heab357d0b792d165805bc071c98cf6d1(ptr %v0, ptr %t10, i32 %t11)
  store i64 %t14, ptr %l10
  br label %bb1
bb1:
  %t15 = load i64, ptr %l10, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr ptr, ptr %t17, i64 %t15
  %t19 = load ptr, ptr %t18, !tbaa !39
  store ptr %t19, ptr %l3, !tbaa !29
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t23 = icmp eq ptr %t21, null
  %t25 = xor i1 %t23, true
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb4:
  br label %bb5
bb5:
  %t29 = load ptr, ptr %l3, !tbaa !29
  %t31 = getelementptr %"std/prelude/map:mapSlot.06e151a31bcf6a36b74a6345f34868d6", ptr %t29, i32 0, i32 0
  %t32 = getelementptr %"std/prelude/map:MapEntry.7071498ebd14ce3832ebc61ca83442cc", ptr %t31, i32 0, i32 0
  %t33 = load i32, ptr %t32, !tbaa !23
  %t34 = load i32, ptr %l1, !tbaa !23
  %t37 = icmp eq i32 %t33, %t34
  br i1 %t37, label %bb6, label %bb7
bb6:
  %t39 = load ptr, ptr %l3, !tbaa !29
  %t41 = getelementptr %"std/prelude/map:mapSlot.06e151a31bcf6a36b74a6345f34868d6", ptr %t39, i32 0, i32 0
  %t42 = getelementptr %"std/prelude/map:MapEntry.7071498ebd14ce3832ebc61ca83442cc", ptr %t41, i32 0, i32 1
  %t43 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t42
  call void @__olang_scope_close(ptr %s2)
  %t45 = insertvalue { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } zeroinitializer, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t43, 1
  store { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } %t45, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb9
bb9:
  %t46 = load ptr, ptr %l3, !tbaa !29
  %t48 = getelementptr %"std/prelude/map:mapSlot.06e151a31bcf6a36b74a6345f34868d6", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  store ptr %t49, ptr %l3, !tbaa !29
  br label %bb2
bb10:
  %t52 = insertvalue { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } zeroinitializer, i32 65536, 0
  store { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } %t52, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }, ptr %rv
  ret { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } %rr
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_H760b547a4a2e251e7cfb0c9b0280f392(ptr %v0, ptr %v1, ptr %a0, i32 %a1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a2) #0 {
entry:
  %l1 = alloca i32
  %l2 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca ptr
  %l10 = alloca i64
  %l12 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  store i32 %a1, ptr %l1
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2fsource_3aNameId_2c_20B_Heab357d0b792d165805bc071c98cf6d1(ptr %v0, ptr %t6, i32 %t7)
  store i64 %t10, ptr %l10
  br label %bb1
bb1:
  %t11 = load i64, ptr %l10, !tbaa !24
  store i64 %t11, ptr %l4, !tbaa !24
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t14 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  store { i64, ptr } %t15, ptr %l12, !tbaa !27
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l5, !tbaa !29
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t23 = load ptr, ptr %l5, !tbaa !29
  %t25 = icmp eq ptr %t23, null
  %t27 = xor i1 %t25, true
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb4:
  br label %bb5
bb5:
  %t31 = load ptr, ptr %l5, !tbaa !29
  %t33 = getelementptr %"std/prelude/map:mapSlot.06e151a31bcf6a36b74a6345f34868d6", ptr %t31, i32 0, i32 0
  %t34 = getelementptr %"std/prelude/map:MapEntry.7071498ebd14ce3832ebc61ca83442cc", ptr %t33, i32 0, i32 0
  %t35 = load i32, ptr %t34, !tbaa !23
  %t36 = load i32, ptr %l1, !tbaa !23
  %t39 = icmp eq i32 %t35, %t36
  br i1 %t39, label %bb6, label %bb7
bb6:
  %t41 = load ptr, ptr %l5, !tbaa !29
  %t42 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l2
  %t45 = getelementptr %"std/prelude/map:mapSlot.06e151a31bcf6a36b74a6345f34868d6", ptr %t41, i32 0, i32 0
  %t46 = getelementptr %"std/prelude/map:MapEntry.7071498ebd14ce3832ebc61ca83442cc", ptr %t45, i32 0, i32 1
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t42, ptr %t46
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb7:
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb9
bb9:
  %t47 = load ptr, ptr %l5, !tbaa !29
  %t49 = getelementptr %"std/prelude/map:mapSlot.06e151a31bcf6a36b74a6345f34868d6", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  store ptr %t50, ptr %l5, !tbaa !29
  br label %bb2
bb10:
  %t52 = load ptr, ptr %l3, !tbaa !29
  %t53 = load i64, ptr %l4, !tbaa !24
  %t54 = load i32, ptr %l1, !tbaa !23
  %t55 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l2
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2ftypes_3aTypeId_2c_20st_H65f70df4547f28cb83baa1be645b87f8(ptr %v0, ptr %v1, ptr %t52, i64 %t53, i32 %t54, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t55)
  br label %bb11
bb11:
  br label %ret
ret:
  ret void
}

define dso_local i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H874ab6ecb906549bc54547c0392d06e9(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1) #0 {
entry:
  %l1 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l10 = alloca i64
  %l17 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l19 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l21 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t6, i32 0, i32 0
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  store { i64, ptr } %t9, ptr %l7, !tbaa !27
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t11 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l1
  %t14 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fpair_3aPair_3cI64_2c_20I64__H25550a5aa964c9352053a58344d5fc74(ptr %v0, ptr %t10, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t11)
  store i64 %t14, ptr %l10
  br label %bb1
bb1:
  %t15 = load i64, ptr %l10, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr ptr, ptr %t17, i64 %t15
  %t19 = load ptr, ptr %t18, !tbaa !39
  store ptr %t19, ptr %l3, !tbaa !29
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t23 = icmp eq ptr %t21, null
  %t25 = xor i1 %t23, true
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t29 = load ptr, ptr %l3, !tbaa !29
  %t31 = getelementptr %"std/prelude/map:mapSlot.ee271f0959124d335f4e22d467611f9d", ptr %t29, i32 0, i32 0
  %t32 = getelementptr %"std/prelude/map:MapEntry.9ce8a46a5d367870e2478b0757bce708", ptr %t31, i32 0, i32 0
  %t33 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %t32
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t33, ptr %l17
  %t34 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l1
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t34, ptr %l19
  %t37 = call i1 @olang_2eHelperKind_2eEqual_2estd_2fpair_3aPair_3cI64_2c_20I64_3e(ptr %l17, ptr %l19)
  store i1 %t37, ptr %l21
  br label %bb6
bb6:
  %t38 = load i1, ptr %l21, !tbaa !21
  br i1 %t38, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t42 = getelementptr %"std/prelude/map:mapSlot.ee271f0959124d335f4e22d467611f9d", ptr %t40, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !29
  store ptr %t43, ptr %l3, !tbaa !29
  br label %bb2
bb11:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2ftypes_3aTypeId_2c_20st_H2bb88fc87e8631b70185bebe652d672a(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l13 = alloca ptr
  %l16 = alloca i64
  %l25 = alloca i64
  %l28 = alloca i64
  %l46 = alloca { i64, ptr }
  %l58 = alloca i64
  %l61 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l1, !tbaa !27
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l13, !tbaa !29
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t11 = mul i64 %t9, 2
  store i64 %t11, ptr %l16, !tbaa !24
  %t12 = load i64, ptr %l16, !tbaa !24
  %t13 = icmp sge i64 %t12, 0
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = load i64, ptr %l16, !tbaa !24
  %t16 = icmp sle i64 %t15, 1152921504606846975
  br i1 %t16, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_790c47242977d364_3b1b59ca50ef36e8)
  unreachable
bb3:
  %t18 = load i64, ptr %l16, !tbaa !24
  %t19 = mul i64 %t18, 8
  %t20 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t19)
  %t21 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t24 = load ptr, ptr %l13, !tbaa !29
  %t25 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t24, i32 0, i32 0
  store { i64, ptr } %t22, ptr %t25, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t26 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  store i64 %t28, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t30 = load i64, ptr %l3, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t34 = icmp sgt i64 %t30, %t31
  br i1 %t34, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_790c47242977d364_3b1b59ca50ef36e8)
  unreachable
bb5:
  %t36 = load i64, ptr %l4, !tbaa !24
  %t38 = icmp sgt i64 %t36, 0
  br i1 %t38, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb10
bb7:
  %t40 = load i64, ptr %l3, !tbaa !24
  %t41 = load i64, ptr %l2, !tbaa !24
  %t44 = sub i64 %t40, %t41
  %t45 = load i64, ptr %l4, !tbaa !24
  %t48 = add i64 %t44, %t45
  %t50 = sub i64 %t48, 1
  %t51 = load i64, ptr %l4, !tbaa !24
  %t54 = sdiv i64 %t50, %t51
  store i64 %t54, ptr %l28, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb9
bb9:
  %t56 = load i64, ptr %l28, !tbaa !24
  store i64 %t56, ptr %l25, !tbaa !24
  br label %bb10
bb10:
  %t57 = load i64, ptr %l25, !tbaa !24
  store i64 %t57, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t58 = load i64, ptr %l6, !tbaa !24
  %t59 = load i64, ptr %l5, !tbaa !24
  %t62 = icmp slt i64 %t58, %t59
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb23
bb13:
  br label %bb14
bb14:
  %t66 = load i64, ptr %l2, !tbaa !24
  %t67 = load i64, ptr %l6, !tbaa !24
  %t68 = load i64, ptr %l4, !tbaa !24
  %t71 = mul i64 %t67, %t68
  %t74 = add i64 %t66, %t71
  %t76 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t76, ptr %l46, !tbaa !27
  %t79 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr ptr, ptr %t80, i64 %t74
  %t82 = load ptr, ptr %t81, !tbaa !39
  store ptr %t82, ptr %l8, !tbaa !29
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t84 = load ptr, ptr %l8, !tbaa !29
  %t86 = icmp eq ptr %t84, null
  %t88 = xor i1 %t86, true
  %t90 = xor i1 %t88, true
  br i1 %t90, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb17:
  br label %bb18
bb18:
  %t92 = load ptr, ptr %l8, !tbaa !29
  %t94 = getelementptr %"std/prelude/map:mapSlot.06e151a31bcf6a36b74a6345f34868d6", ptr %t92, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !29
  store ptr %t95, ptr %l9, !tbaa !29
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load ptr, ptr %l8, !tbaa !29
  %t100 = getelementptr %"std/prelude/map:mapSlot.06e151a31bcf6a36b74a6345f34868d6", ptr %t98, i32 0, i32 0
  %t101 = getelementptr %"std/prelude/map:MapEntry.7071498ebd14ce3832ebc61ca83442cc", ptr %t100, i32 0, i32 0
  %t102 = load i32, ptr %t101, !tbaa !23
  %t105 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2fsource_3aNameId_2c_20B_Heab357d0b792d165805bc071c98cf6d1(ptr %v0, ptr %t97, i32 %t102)
  store i64 %t105, ptr %l58
  br label %bb19
bb19:
  %t106 = load i64, ptr %l58, !tbaa !24
  store i64 %t106, ptr %l10, !tbaa !24
  %t107 = load ptr, ptr %l8, !tbaa !29
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t108, i32 0, i32 0
  %t111 = load { i64, ptr }, ptr %t110, !tbaa !27
  store { i64, ptr } %t111, ptr %l61, !tbaa !27
  %t112 = load i64, ptr %l10, !tbaa !24
  %t114 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr ptr, ptr %t115, i64 %t112
  %t117 = load ptr, ptr %t116, !tbaa !39
  %t120 = getelementptr %"std/prelude/map:mapSlot.06e151a31bcf6a36b74a6345f34868d6", ptr %t107, i32 0, i32 1
  store ptr %t117, ptr %t120, !tbaa !29
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t121, i32 0, i32 0
  %t124 = load { i64, ptr }, ptr %t123, !tbaa !27
  store { i64, ptr } %t124, ptr %l65, !tbaa !27
  %t125 = load i64, ptr %l10, !tbaa !24
  %t126 = load ptr, ptr %l8, !tbaa !29
  %t130 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr ptr, ptr %t131, i64 %t125
  store ptr %t126, ptr %t132, !tbaa !39
  %t133 = load ptr, ptr %l9, !tbaa !29
  store ptr %t133, ptr %l8, !tbaa !29
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb20:
  br label %bb15
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb22:
  %t135 = load i64, ptr %l6, !tbaa !24
  %t137 = add i64 %t135, 1
  store i64 %t137, ptr %l6, !tbaa !24
  br label %bb11
bb23:
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2ftypes_3aTypeId_2c_20st_H65f70df4547f28cb83baa1be645b87f8(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l15 = alloca { i64, ptr }
  %l18 = alloca %"std/prelude/map:mapSlot.06e151a31bcf6a36b74a6345f34868d6"
  %l23 = alloca ptr
  %l26 = alloca %"std/prelude/map:MapEntry.7071498ebd14ce3832ebc61ca83442cc"
  %l29 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l37 = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t8 = icmp eq ptr %t6, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  store { i64, ptr } %t13, ptr %l10, !tbaa !27
  %t14 = load i64, ptr %l1, !tbaa !24
  store i64 %t14, ptr %l11, !tbaa !24
  %t15 = load i32, ptr %l2, !tbaa !23
  %t16 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l3
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t17, i32 0, i32 0
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  store { i64, ptr } %t20, ptr %l15, !tbaa !27
  %t21 = load i64, ptr %l1, !tbaa !24
  %t23 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr ptr, ptr %t24, i64 %t21
  %t26 = load ptr, ptr %t25, !tbaa !39
  %t30 = call %"std/prelude/map:mapSlot.06e151a31bcf6a36b74a6345f34868d6" @std_2fprelude_2fmap_3amapSlot_3ccompiler_2ftypes_3aTypeId_2c_20std_2fprelude_2flist_3aLi_H05b0d3297644b6dda914165439041987(ptr %v1, ptr %v0, ptr %v0, i32 %t15, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t16, ptr %t26)
  store %"std/prelude/map:mapSlot.06e151a31bcf6a36b74a6345f34868d6" %t30, ptr %l18
  br label %bb3
bb2:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %l4, !tbaa !29
  %t34 = getelementptr %"std/prelude/map:mapSlot.06e151a31bcf6a36b74a6345f34868d6", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t38 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t31, i32 0, i32 2
  store ptr %t35, ptr %t38, !tbaa !29
  %t39 = load ptr, ptr %l4, !tbaa !29
  store ptr %t39, ptr %l23, !tbaa !29
  %t40 = load i32, ptr %l2, !tbaa !23
  %t41 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l3
  %t44 = call %"std/prelude/map:MapEntry.7071498ebd14ce3832ebc61ca83442cc" @std_2fprelude_2fmap_3aMapEntry_3ccompiler_2ftypes_3aTypeId_2c_20std_2fprelude_2flist_3aL_H90cfc5fc6ad37ceff96ab281971dc260(ptr %v1, ptr %v0, i32 %t40, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t41)
  store %"std/prelude/map:MapEntry.7071498ebd14ce3832ebc61ca83442cc" %t44, ptr %l26
  br label %bb4
bb3:
  %t45 = load %"std/prelude/map:mapSlot.06e151a31bcf6a36b74a6345f34868d6", ptr %l18
  %t46 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"std/prelude/map:mapSlot.06e151a31bcf6a36b74a6345f34868d6" %t45, ptr %t46
  %t48 = load i64, ptr %l11, !tbaa !24
  %t49 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr ptr, ptr %t50, i64 %t48
  store ptr %t46, ptr %t51, !tbaa !39
  br label %bb5
bb4:
  %t52 = load %"std/prelude/map:MapEntry.7071498ebd14ce3832ebc61ca83442cc", ptr %l26
  %t53 = load ptr, ptr %l23, !tbaa !29
  %t54 = getelementptr %"std/prelude/map:mapSlot.06e151a31bcf6a36b74a6345f34868d6", ptr %t53, i32 0, i32 0
  store %"std/prelude/map:MapEntry.7071498ebd14ce3832ebc61ca83442cc" %t52, ptr %t54
  %t55 = load ptr, ptr %l4, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t56, i32 0, i32 0
  %t59 = load { i64, ptr }, ptr %t58, !tbaa !27
  store { i64, ptr } %t59, ptr %l29, !tbaa !27
  %t60 = load i64, ptr %l1, !tbaa !24
  %t62 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr ptr, ptr %t63, i64 %t60
  %t65 = load ptr, ptr %t64, !tbaa !39
  %t68 = getelementptr %"std/prelude/map:mapSlot.06e151a31bcf6a36b74a6345f34868d6", ptr %t55, i32 0, i32 1
  store ptr %t65, ptr %t68, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t69, i32 0, i32 0
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !27
  store { i64, ptr } %t72, ptr %l33, !tbaa !27
  %t73 = load i64, ptr %l1, !tbaa !24
  %t74 = load ptr, ptr %l4, !tbaa !29
  %t78 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = getelementptr ptr, ptr %t79, i64 %t73
  store ptr %t74, ptr %t80, !tbaa !39
  br label %bb5
bb5:
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l37, !tbaa !29
  %t82 = load ptr, ptr %l37, !tbaa !29
  %t83 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t82, i32 0, i32 1
  %t84 = load i64, ptr %t83, !tbaa !24
  %t86 = add i64 %t84, 1
  %t88 = load ptr, ptr %l37, !tbaa !29
  %t89 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t88, i32 0, i32 1
  store i64 %t86, ptr %t89, !tbaa !24
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t90, i32 0, i32 1
  %t93 = load i64, ptr %t92, !tbaa !24
  %t95 = mul i64 %t93, 4
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t96, i32 0, i32 0
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t99, 0
  %t103 = mul i64 %t101, 3
  %t106 = icmp sgt i64 %t95, %t103
  br i1 %t106, label %bb6, label %bb7
bb6:
  %t108 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2ftypes_3aTypeId_2c_20st_H2bb88fc87e8631b70185bebe652d672a(ptr %v0, ptr %t108)
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb9
bb9:
  br label %ret
ret:
  ret void
}

define dso_local i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2ftypes_3aTypeId_2c_20st_Hefa01f0d58afdeef300619e22b123f14(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2fsource_3aNameId_2c_20B_Heab357d0b792d165805bc071c98cf6d1(ptr %v0, ptr %a0, i32 %a1)
  ret i64 %r
}

define dso_local %"std/prelude/map:MapEntry.7071498ebd14ce3832ebc61ca83442cc" @std_2fprelude_2fmap_3aMapEntry_3ccompiler_2ftypes_3aTypeId_2c_20std_2fprelude_2flist_3aL_H90cfc5fc6ad37ceff96ab281971dc260(ptr %v0, ptr %v1, i32 %a0, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1) #0 {
entry:
  %rv = alloca %"std/prelude/map:MapEntry.7071498ebd14ce3832ebc61ca83442cc"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"std/prelude/map:MapEntry.7071498ebd14ce3832ebc61ca83442cc" undef, i32 %a0, 0
  %t8 = insertvalue %"std/prelude/map:MapEntry.7071498ebd14ce3832ebc61ca83442cc" %t6, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1, 1
  store %"std/prelude/map:MapEntry.7071498ebd14ce3832ebc61ca83442cc" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:MapEntry.7071498ebd14ce3832ebc61ca83442cc", ptr %rv
  ret %"std/prelude/map:MapEntry.7071498ebd14ce3832ebc61ca83442cc" %rr
}

define dso_local %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fprelude_2flist_3aList_3_He58e4962dcc04e091d86d67e580ecc4e(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/map:mapSlot.06e151a31bcf6a36b74a6345f34868d6" @std_2fprelude_2fmap_3amapSlot_3ccompiler_2ftypes_3aTypeId_2c_20std_2fprelude_2flist_3aLi_H05b0d3297644b6dda914165439041987(ptr %v0, ptr %v1, ptr %v2, i32 %a0, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1, ptr %a2) #0 {
entry:
  %l7 = alloca %"std/prelude/map:MapEntry.7071498ebd14ce3832ebc61ca83442cc"
  %rv = alloca %"std/prelude/map:mapSlot.06e151a31bcf6a36b74a6345f34868d6"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call %"std/prelude/map:MapEntry.7071498ebd14ce3832ebc61ca83442cc" @std_2fprelude_2fmap_3aMapEntry_3ccompiler_2ftypes_3aTypeId_2c_20std_2fprelude_2flist_3aL_H90cfc5fc6ad37ceff96ab281971dc260(ptr %v0, ptr %v2, i32 %a0, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1)
  store %"std/prelude/map:MapEntry.7071498ebd14ce3832ebc61ca83442cc" %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load %"std/prelude/map:MapEntry.7071498ebd14ce3832ebc61ca83442cc", ptr %l7
  %t10 = insertvalue %"std/prelude/map:mapSlot.06e151a31bcf6a36b74a6345f34868d6" undef, %"std/prelude/map:MapEntry.7071498ebd14ce3832ebc61ca83442cc" %t6, 0
  %t12 = insertvalue %"std/prelude/map:mapSlot.06e151a31bcf6a36b74a6345f34868d6" %t10, ptr %a2, 1
  store %"std/prelude/map:mapSlot.06e151a31bcf6a36b74a6345f34868d6" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:mapSlot.06e151a31bcf6a36b74a6345f34868d6", ptr %rv
  ret %"std/prelude/map:mapSlot.06e151a31bcf6a36b74a6345f34868d6" %rr
}

define dso_local %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" @std_2fprelude_2fmap_3amapState_3ccompiler_2ftypes_3aTypeId_2c_20std_2fprelude_2flist_3aL_He1f13e890d6c397c6ccc5970af9a28a3(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" @std_2fprelude_2fmap_3amapState_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)
  ret %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" %r
}

declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_check_failed(ptr)
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d0 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"List<" }>, align 8
@.d1 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c">[" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare void @__olang_ert_req_clear()
define linkonce_odr void @olang_2eHelperKind_2eRender_2eArray_3cI64_3e_26(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, ptr }, ptr %a0, !tbaa !27
  store { i64, ptr } %t2, ptr %l2, !tbaa !27
  br label %bb1
bb1:
  %t3 = load i64, ptr %l1, !tbaa !24
  %t4 = icmp sge i64 %t3, 8
  br i1 %t4, label %bb3, label %bb4
bb2:
  br label %ret
bb3:
  %t6 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t6, i64 %t7)
  br label %bb2
bb4:
  %t8 = load i64, ptr %l1, !tbaa !24
  %t9 = add i64 %t8, 1
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @olang_2eHelperKind_2eRender_2eArray_3cI64_3e(ptr %v0, { i64, ptr } %t10, i64 %t9)
  br label %bb5
bb5:
  br label %bb2
ret:
  ret void
}

declare void @__olang_sb_done(ptr)
@.d2 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define linkonce_odr void @olang_2eHelperKind_2eRender_2eArray_3cI64_2c_200_3e_26(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca ptr
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load ptr, ptr %a0
  store ptr %t2, ptr %l2
  br label %bb1
bb1:
  %t3 = load i64, ptr %l1, !tbaa !24
  %t4 = icmp sge i64 %t3, 8
  br i1 %t4, label %bb3, label %bb4
bb2:
  br label %ret
bb3:
  %t6 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t6, i64 %t7)
  br label %bb2
bb4:
  %t8 = load i64, ptr %l1, !tbaa !24
  %t9 = add i64 %t8, 1
  %t10 = load ptr, ptr %l2
  call void @olang_2eHelperKind_2eRender_2eArray_3cI64_2c_200_3e(ptr %v0, ptr %t10, i64 %t9)
  br label %bb5
bb5:
  br label %bb2
ret:
  ret void
}

define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2estd_2fpair_3aPair_3cI64_2c_20I64_3e(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %t1, i32 0, i32 0
  %t3 = load i64, ptr %t2, !tbaa !24
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %t4, i32 0, i32 0
  %t6 = load i64, ptr %t5, !tbaa !24
  %t9 = icmp eq i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb4
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %t11, i32 0, i32 1
  %t13 = load i64, ptr %t12, !tbaa !24
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %t14, i32 0, i32 1
  %t16 = load i64, ptr %t15, !tbaa !24
  %t19 = icmp eq i64 %t13, %t16
  br i1 %t19, label %bb3, label %bb1
bb3:
  br label %bb4
bb4:
  %t21 = load i1, ptr %l2, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@.d3 = private unnamed_addr constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"..." }>, align 8
declare void @__olang_sb_put(ptr, ptr, i64)
define linkonce_odr void @olang_2eHelperKind_2eRender_2eArray_3cI64_3e(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t2 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t1, i64 %t2)
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t3, 0
  store i64 %t4, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l3, !tbaa !24
  %t6 = load i64, ptr %l2, !tbaa !24
  %t7 = icmp slt i64 %t5, %t6
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = icmp eq i64 %t9, 0
  br i1 %t10, label %bb5, label %bb4
bb3:
  %t12 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t13 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t12, i64 %t13)
  br label %ret
bb4:
  %t14 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t14, i64 %t15)
  br label %bb5
bb5:
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = getelementptr i64, ptr %t18, i64 %t16
  %t20 = load i64, ptr %t19, !tbaa !34
  %t22 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t23 = call i64 @__olang_fmt_i64(ptr %t22, i64 %t20)
  call void @__olang_sb_add(ptr %v0, i64 %t23)
  %t24 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t24, 1
  store i64 %t25, ptr %l3, !tbaa !24
  br label %bb1
ret:
  ret void
}

define linkonce_odr void @olang_2eHelperKind_2eRender_2eArray_3cI64_2c_200_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t2 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t1, i64 %t2)
  %t3 = load ptr, ptr %l0
  %t4 = load [0 x i64], ptr %t3
  store i64 0, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l3, !tbaa !24
  %t6 = load i64, ptr %l2, !tbaa !24
  %t7 = icmp slt i64 %t5, %t6
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = icmp eq i64 %t9, 0
  br i1 %t10, label %bb5, label %bb4
bb3:
  %t12 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t13 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t12, i64 %t13)
  br label %ret
bb4:
  %t14 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t14, i64 %t15)
  br label %bb5
bb5:
  %t16 = load ptr, ptr %l0
  %t17 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr [0 x i64], ptr %t16, i64 0, i64 %t17
  %t19 = load i64, ptr %t18, !tbaa !34
  %t21 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t22 = call i64 @__olang_fmt_i64(ptr %t21, i64 %t19)
  call void @__olang_sb_add(ptr %v0, i64 %t22)
  %t23 = load i64, ptr %l3, !tbaa !24
  %t24 = add i64 %t23, 1
  store i64 %t24, ptr %l3, !tbaa !24
  br label %bb1
ret:
  ret void
}

@.d4 = private unnamed_addr constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"I64[" }>, align 8
@.d5 = private unnamed_addr constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"]" }>, align 8
@.d6 = private unnamed_addr constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
define available_externally ptr @__olang_sb_room(ptr %sb, i64 %need) alwaysinline {
entry:
  %lenp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 1
  %capp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 2
  %len = load i64, ptr %lenp
  %cap = load i64, ptr %capp
  %want = add i64 %len, %need
  %fits = icmp ule i64 %want, %cap
  br i1 %fits, label %ok, label %grow
ok:
  %data = load ptr, ptr %sb
  %p = getelementptr i8, ptr %data, i64 %len
  ret ptr %p
grow:
  %g = call ptr @__olang_sb_grow(ptr %sb, i64 %need)
  ret ptr %g
}
declare i64 @__olang_fmt_i64(ptr, i64)
declare void @__olang_sb_add(ptr, i64)
declare ptr @__olang_sb_grow(ptr, i64) noinline
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cU64_3e_2ector(ptr %v0)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_97da9209e35673c4_9116cffe73ec24d0 = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cI64_3e_2egrow_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
@olang_loc_ef19d749dc52a486_37471d9cecf16352 = external constant [0 x i8]
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_3d5c34784a3a630c_5481d669dd41710 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %a0, i8 %a1)
@olang_loc_6c49b9e941c04007_786277cabc133a4b = external constant [0 x i8]
@olang_loc_d75327113fbd1725_35766f2a3cdb1669 = external constant [0 x i8]
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
@G_2estd_2fprelude_2flist_2efirstChunk = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\08\00\00\00\00\00\00\00" }>, align 8
declare i64 @std_2fprelude_2flist_2ehighBit(i64 %a0)
@G_2estd_2fprelude_2flist_2efirstChunkLog = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@olang_loc_7af0baad65f44e5a_80ef3d923098685e = external constant [0 x i8]
@olang_loc_d55d63494ae88548_7509700b8d0ed81c = external constant [0 x i8]
@olang_loc_3d1565619ec04221_d95d92e50b56128d = external constant [0 x i8]
@olang_loc_e33b06e661fe66ae_242f485233980172 = external constant [0 x i8]
declare { i32, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H78ccce95e6ef2f62693281865bce11fb(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aDecl_26_3e_2eClear_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcond_3aGlobal_26_3e_2ePu_H886a66ffa23940650f82c48d9485539c(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aDecl_26_3e_2eTrunc_H4f6d6844736ef1cf1f5d4d22c2fa42e3(ptr %v0, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcond_3aGlobal_26_3e_2eRu_Hdae492cbfddb0b6a70eec6865333e543(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_42938c78567cc42d_28e37a4065999d81 = external constant [0 x i8]
@olang_loc_67599e04f7a3aec5_5cba14342a35ebb9 = external constant [0 x i8]
@olang_loc_f4a2a7f94f31dd58_5a3ff81dd1e2722c = external constant [0 x i8]
@olang_loc_b66ad08785da183b_ab73eb0ba62b5c8f = external constant [0 x i8]
@olang_loc_b919348cb7bcf4a6_9200da5e57d4033a = external constant [0 x i8]
@olang_loc_9f445d6dced55c2d_a774a5de7d698f11 = external constant [0 x i8]
@olang_loc_3854bdcccb1b1500_94da6c1dc62a0e04 = external constant [0 x i8]
@olang_loc_136e985c1376dea3_8fab4d7ad3efe0e7 = external constant [0 x i8]
@olang_loc_67ba5b1efcd4822e_37bf44bd9e6bacf2 = external constant [0 x i8]
@olang_loc_53a792ee6df1ab26_8e40c0ccdcf288da = external constant [0 x i8]
@olang_loc_3ea4ac2de0c14383_cd69c9201202aa37 = external constant [0 x i8]
@olang_loc_d320103722639438_3570df4ff90c2df4 = external constant [0 x i8]
@olang_loc_aafcd34cf883ea15_e42c9aaf31e4cbe1 = external constant [0 x i8]
@olang_loc_4ca4216b4c0999aa_9cce9557d52059ee = external constant [0 x i8]
@olang_loc_42b9cfb017d0cb7f_b98ba3c7b8f95963 = external constant [0 x i8]
@olang_loc_777dd77f8cb4561c_ddd09332b6e89dc0 = external constant [0 x i8]
@olang_loc_fb36f36590ee87e9_8cf0e96e15ba02ed = external constant [0 x i8]
@olang_loc_438c24ac7a213098_1e62abdbaf6bf5dc = external constant [0 x i8]
@olang_loc_43b3ef88dc0147f5_9d0ff4f7cff70b49 = external constant [0 x i8]
@olang_loc_b936876b76714920_e5b9e5dc02d16c54 = external constant [0 x i8]
@olang_loc_7ec5df9de579214d_799f6344cb66a461 = external constant [0 x i8]
@olang_loc_c66e2f20e524414e_21b74c07fe2d0f42 = external constant [0 x i8]
@olang_loc_6d7dabb92c8ae543_19cf45691fa06f7 = external constant [0 x i8]
@olang_loc_429efc307926afcf_1f3df72c2a3e9ce3 = external constant [0 x i8]
@olang_loc_98a5072631ccd87a_280e8bc46659d6e = external constant [0 x i8]
@olang_loc_53b4f4e5911227f9_f2a33cd286ff466d = external constant [0 x i8]
@olang_loc_3324af7e126e946c_4382e697282de140 = external constant [0 x i8]
@olang_loc_b52d3a8395eabf75_5e0c174b8dea1469 = external constant [0 x i8]
@olang_loc_d898010c7f057d08_da52fb6589afe29c = external constant [0 x i8]
@olang_loc_e0619033d37cb66b_a58ef39614cc57ff = external constant [0 x i8]
@olang_loc_990c6a7262996156_af7945514905262a = external constant [0 x i8]
@olang_loc_46c408dee3f11363_d26d32f12e5fd18f = external constant [0 x i8]
@olang_loc_466c920e18c96886_c74c7dd2ac627792 = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2fast_3aDecl_26_3e_2e_H41acc6e44116d166ef90f4d71eec6f8c(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2fcond_3aGlobal_26_3e_H3a47d2b30dd068f82b18182b93098e2f(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2fcond_3aGlobal_26_3e_He54124e4892c254df357a8103d0ba529(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cI64_3e_2edropLast_3cI64_3e(ptr %v0, ptr %a0)
@olang_loc_108e5757266db8ac_128972bb016af7b8 = external constant [0 x i8]
@olang_loc_1308736d7ec13239_270fdc3ed266f225 = external constant [0 x i8]
@olang_loc_484f3997ac5f49ba_a3a07b6315e3d006 = external constant [0 x i8]
@olang_loc_61c24a44fab6a30f_efd075332c62999b = external constant [0 x i8]
@olang_loc_58225400e40d3852_8a3830025fc53636 = external constant [0 x i8]
@olang_loc_d8bdf07c21a0a84f_8a49261db8489a93 = external constant [0 x i8]
@olang_loc_724541474394e48a_9599c4eb52cbbbbe = external constant [0 x i8]
@olang_loc_5274c9e04eb87767_80927fe9d150cd3b = external constant [0 x i8]
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fgeneric_3aOrigin_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fdiag_3aItem_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fscope_3aGap_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fscope_3afnUse_3e_2ector(ptr %v0)
declare %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" @std_2fprelude_2flist_3alistState_3ccompiler_2fgeneric_3aOrigin_3e_2ector(ptr %v0)
declare %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" @std_2fprelude_2flist_3alistState_3ccompiler_2fdiag_3aItem_3e_2ector(ptr %v0)
declare %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" @std_2fprelude_2flist_3alistState_3ccompiler_2fbuild_3aUnit_3e_2ector(ptr %v0)
declare %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" @std_2fprelude_2flist_3alistState_3ccompiler_2fscope_3aGap_3e_2ector(ptr %v0)
declare %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" @std_2fprelude_2flist_3alistState_3ccompiler_2fscope_3afnUse_3e_2ector(ptr %v0)
declare %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" @std_2fprelude_2flist_3alistState_3cU64_3e_2ector(ptr %v0)
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2fsource_3aNameId_2c_20B_Heab357d0b792d165805bc071c98cf6d1(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fpair_3aPair_3cI64_2c_20I64__H25550a5aa964c9352053a58344d5fc74(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
@olang_loc_790c47242977d364_3b1b59ca50ef36e8 = external constant [0 x i8]
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)
declare %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" @std_2fprelude_2fmap_3amapState_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
