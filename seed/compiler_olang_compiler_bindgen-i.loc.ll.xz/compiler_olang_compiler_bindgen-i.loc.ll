; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_1167ded7c8a97cd5_1872a41af681a5c1 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: array length out of range\0A\00"
@olang_loc_2cfc165aa8f9b3ca_fa9954f3de416366 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: array length out of range\0A\00"
@olang_loc_7a2e2f1234b288e4_1a1b87a4e865268 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: array length out of range\0A\00"
