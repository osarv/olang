; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_374470aac764457_99444c7926030803 = weak_odr constant [53 x i8] c"std/prelude/map.olang:88: slice bounds out of range\0A\00"
@olang_loc_3e3f5a6ec1798d82_a9dd7d52e13f3e26 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
@olang_loc_4b11700a6b124f66_2a9efc30191811da = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
@olang_loc_6b1663ba56f36acb_f34fa9b6e2e5de27 = weak_odr constant [53 x i8] c"std/prelude/map.olang:94: array length out of range\0A\00"
@olang_loc_6d55b948a70aaa9e_6340e40b5b901102 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
@olang_loc_a23e3ed7b92a6807_36817963509f403b = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
@olang_loc_a716dacd6a0848f6_d726765bf72c12ea = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
@olang_loc_ced6cefa56842b7d_9da3ba7e7a7fd31 = weak_odr constant [54 x i8] c"std/prelude/map.olang:105: array length out of range\0A\00"
@olang_loc_e66399634dcb6e7a_ae473339b3336fa6 = weak_odr constant [53 x i8] c"std/prelude/map.olang:85: slice bounds out of range\0A\00"
