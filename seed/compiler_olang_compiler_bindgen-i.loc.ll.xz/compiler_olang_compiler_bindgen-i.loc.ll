; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_16f179d043db9f58_d8440366ea2e2974 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
@olang_loc_23c8eb6b5132cbe2_3b0e5edcfcc030e6 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
@olang_loc_6ce37f05eb0c64d6_6f75a881c851175a = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
@olang_loc_86ccc3f61edf147c_3db766ccbc4ab418 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
@olang_loc_aa1bfceb250db2c5_f866254b67f13159 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:36: array length out of range\0A\00"
@olang_loc_b3c4295d5a3a1707_88e23a6a72a02653 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:36: array length out of range\0A\00"
@olang_loc_b509d27efc810532_83b2149f0073e7e = weak_odr constant [53 x i8] c"std/prelude/map.olang:84: array length out of range\0A\00"
@olang_loc_eb0847f457a345f5_fbf8f3f72a38a4d9 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
