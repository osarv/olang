; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
@G_2estd_2fprelude_2farray_2esortBlock = global i64 zeroinitializer
@G_2estd_2fprelude_2farray_2esortRun = global i64 zeroinitializer
define dso_local void @olang_2einit_2estd_2fprelude_2farray() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  call void @std_2fprelude_2farray_2esortRun_2einit()
  br label %bb1
bb1:
  call void @std_2fprelude_2farray_2esortBlock_2einit()
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2farray_2esortBlock_2einit() #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr @G_2estd_2fprelude_2farray_2esortRun
  store i64 %t1, ptr %l0
  %t2 = load i64, ptr %l0
  %t3 = shl i64 %t2, 9
  store i64 %t3, ptr %l1
  %t4 = load i64, ptr %l1
  store i64 %t4, ptr @G_2estd_2fprelude_2farray_2esortBlock
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2farray_2esortRun_2einit() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 24, ptr @G_2estd_2fprelude_2farray_2esortRun
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

declare void @__olang_scope_close(ptr)
attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
