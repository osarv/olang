; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba" = type { i64, %"compiler/source:Span" }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/eval:dkey" = type { i64, i32, i32, i32, i32, i64 }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" = type { { i64, ptr }, i64, ptr }
%"std/prelude/map:mapSlot.2b294a08895cef9a38135689ddc2ff4b" = type { %"std/prelude/map:MapEntry.ed812e0d562b6dfc0ada2d6105c5025d", ptr }
%"std/prelude/map:MapEntry.ed812e0d562b6dfc0ada2d6105c5025d" = type { %"compiler/eval:dkey", i64 }
%"compiler/eval:gkey" = type { i64, i32 }
%"std/prelude/map:mapSlot.ee9ec0b0cf3c88d460faed9ec3c15b49" = type { %"std/prelude/map:MapEntry.035e99ae244af91b94aafcb9668dfc7c", ptr }
%"std/prelude/map:MapEntry.035e99ae244af91b94aafcb9668dfc7c" = type { %"compiler/eval:gkey", i64 }
%"std/prelude/map:mapSlot.0dde5ffa1ef5aae0493dbeb7dc27c2c6" = type { %"std/prelude/map:MapEntry.706ff6be11be6fcfa446047bbb0c400e", ptr }
%"std/prelude/map:MapEntry.706ff6be11be6fcfa446047bbb0c400e" = type { i32, { i64, [2 x i64] } }
%"std/prelude/map:MapEntry.8d509622153b47f1a5f79c42c8367406" = type { i64, { i64, ptr } }
%"std/prelude/map:mapSlot.47b3cc80db0b342939bd1d482dd866ad" = type { %"std/prelude/map:MapEntry.8d509622153b47f1a5f79c42c8367406", ptr }
%"compiler/eval:Blob" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/eval:genRec" = type { i64, i64, %"compiler/eval:frame", i64, i64, i64 }
%"compiler/eval:frame" = type { i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i1, i1, i1, i64, i64, i1, i64, i32, i32 }
%"compiler/eval:global" = type { i64, i1, i64, i64, i64, i1, i1 }
%"compiler/eval:reg" = type { i64, i64, i64, i64, i64, i64, i64, i64 }
%"compiler/eval:scope" = type { i64, i1, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i1, i64, i64 }
%"compiler/eval:task" = type { i64, i64, i64, i64 }
%"compiler/mir:Call" = type { { i64, [7 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Place", i1, i32, i32, i32 }
%"compiler/mir:Range" = type { i32, i32 }
%"compiler/mir:Place" = type { { i64, [2 x i64] }, %"compiler/mir:Range" }
%"compiler/mir:Case" = type { i64, i32 }
%"compiler/mir:Fn" = type { { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i64 }
%"compiler/mir:Local" = type { i32, %"compiler/source:Span", i32, i32, { i64, [1 x i64] } }
%"compiler/mir:ScopeInfo" = type { i32, i32, i32, %"compiler/source:Span", i32 }
define dso_local %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba" @std_2fpair_3aPair_3cI64_2c_20compiler_2fsource_3aSpan_3e_2ector(ptr %v0, i64 %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %rv = alloca %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba" undef, i64 %a0, 0
  %t8 = insertvalue %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba" %t6, %"compiler/source:Span" %a1, 1
  store %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba", ptr %rv
  ret %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba" %rr
}

define dso_local { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Array_3ccompiler_2fmir_3aFnKe_H6a636ae5a18dc9bdacf7dd1692df3f31(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %r = tail call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
  ret { i32, { i64, ptr } } %r
}

define dso_local i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Array_3ccompiler_2fmir_3aFnKe_H6f34e373626f6b99bb5e62c0fd8bd7a4(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %r = tail call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_H86f724e2dc8b3b4d675d56b45c81e2ce(ptr %v0, ptr %a0, i64 %a1)
  ret i1 %r
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Array_3ccompiler_2fmir_3aFnKe_Hd8d89e440939766a34c786789c5d3b97(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  tail call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_Hc3dff1927e5c626a9d95abfdf4e9a462(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
  ret void
}

define dso_local { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2feval_3adkey_2c_20I64_3e_2eG_H537d495038c4cf6799e621bee696b05f(ptr %v0, ptr %a0, %"compiler/eval:dkey" %a1) #0 {
entry:
  %l1 = alloca %"compiler/eval:dkey"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l10 = alloca i64
  %l17 = alloca %"compiler/eval:dkey"
  %l19 = alloca %"compiler/eval:dkey"
  %l21 = alloca i1
  %rv = alloca { i32, i64 }
  store %"compiler/eval:dkey" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t6, i32 0, i32 0
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  store { i64, ptr } %t9, ptr %l7, !tbaa !27
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t11 = load %"compiler/eval:dkey", ptr %l1
  %t14 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2feval_3adkey_2c_20I64_3_Ha76b9910eb5ae3d1a0cb4a2d27badbbf(ptr %v0, ptr %t10, %"compiler/eval:dkey" %t11)
  store i64 %t14, ptr %l10
  br label %bb1
bb1:
  %t15 = load i64, ptr %l10, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr ptr, ptr %t17, i64 %t15
  %t19 = load ptr, ptr %t18, !tbaa !39
  store ptr %t19, ptr %l3, !tbaa !29
  br label %bb2
bb2:
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t23 = icmp eq ptr %t21, null
  %t25 = xor i1 %t23, true
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t29 = load ptr, ptr %l3, !tbaa !29
  %t31 = getelementptr %"std/prelude/map:mapSlot.2b294a08895cef9a38135689ddc2ff4b", ptr %t29, i32 0, i32 0
  %t32 = getelementptr %"std/prelude/map:MapEntry.ed812e0d562b6dfc0ada2d6105c5025d", ptr %t31, i32 0, i32 0
  %t33 = load %"compiler/eval:dkey", ptr %t32
  store %"compiler/eval:dkey" %t33, ptr %l17
  %t34 = load %"compiler/eval:dkey", ptr %l1
  store %"compiler/eval:dkey" %t34, ptr %l19
  %t37 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2feval_3adkey(ptr %l17, ptr %l19)
  store i1 %t37, ptr %l21
  br label %bb6
bb6:
  %t38 = load i1, ptr %l21, !tbaa !21
  br i1 %t38, label %bb7, label %bb8
bb7:
  %t39 = load ptr, ptr %l3, !tbaa !29
  %t41 = getelementptr %"std/prelude/map:mapSlot.2b294a08895cef9a38135689ddc2ff4b", ptr %t39, i32 0, i32 0
  %t42 = getelementptr %"std/prelude/map:MapEntry.ed812e0d562b6dfc0ada2d6105c5025d", ptr %t41, i32 0, i32 1
  %t43 = load i64, ptr %t42, !tbaa !24
  %t45 = insertvalue { i32, i64 } zeroinitializer, i64 %t43, 1
  store { i32, i64 } %t45, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t46 = load ptr, ptr %l3, !tbaa !29
  %t48 = getelementptr %"std/prelude/map:mapSlot.2b294a08895cef9a38135689ddc2ff4b", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  store ptr %t49, ptr %l3, !tbaa !29
  br label %bb2
bb11:
  %t52 = insertvalue { i32, i64 } zeroinitializer, i32 65536, 0
  store { i32, i64 } %t52, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2feval_3adkey_2c_20I64_3e_2eP_H91b95c77ac9fc5702101e9e6061f40cd(ptr %v0, ptr %a0, %"compiler/eval:dkey" %a1, i64 %a2) #0 {
entry:
  %l1 = alloca %"compiler/eval:dkey"
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca ptr
  %l10 = alloca i64
  %l12 = alloca { i64, ptr }
  %l20 = alloca %"compiler/eval:dkey"
  %l22 = alloca %"compiler/eval:dkey"
  %l24 = alloca i1
  store %"compiler/eval:dkey" %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t7 = load %"compiler/eval:dkey", ptr %l1
  %t10 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2feval_3adkey_2c_20I64_3_Ha76b9910eb5ae3d1a0cb4a2d27badbbf(ptr %v0, ptr %t6, %"compiler/eval:dkey" %t7)
  store i64 %t10, ptr %l10
  br label %bb1
bb1:
  %t11 = load i64, ptr %l10, !tbaa !24
  store i64 %t11, ptr %l4, !tbaa !24
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t14 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  store { i64, ptr } %t15, ptr %l12, !tbaa !27
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l5, !tbaa !29
  br label %bb2
bb2:
  %t23 = load ptr, ptr %l5, !tbaa !29
  %t25 = icmp eq ptr %t23, null
  %t27 = xor i1 %t25, true
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t31 = load ptr, ptr %l5, !tbaa !29
  %t33 = getelementptr %"std/prelude/map:mapSlot.2b294a08895cef9a38135689ddc2ff4b", ptr %t31, i32 0, i32 0
  %t34 = getelementptr %"std/prelude/map:MapEntry.ed812e0d562b6dfc0ada2d6105c5025d", ptr %t33, i32 0, i32 0
  %t35 = load %"compiler/eval:dkey", ptr %t34
  store %"compiler/eval:dkey" %t35, ptr %l20
  %t36 = load %"compiler/eval:dkey", ptr %l1
  store %"compiler/eval:dkey" %t36, ptr %l22
  %t39 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2feval_3adkey(ptr %l20, ptr %l22)
  store i1 %t39, ptr %l24
  br label %bb6
bb6:
  %t40 = load i1, ptr %l24, !tbaa !21
  br i1 %t40, label %bb7, label %bb8
bb7:
  %t41 = load ptr, ptr %l5, !tbaa !29
  %t42 = load i64, ptr %l2, !tbaa !24
  %t45 = getelementptr %"std/prelude/map:mapSlot.2b294a08895cef9a38135689ddc2ff4b", ptr %t41, i32 0, i32 0
  %t46 = getelementptr %"std/prelude/map:MapEntry.ed812e0d562b6dfc0ada2d6105c5025d", ptr %t45, i32 0, i32 1
  store i64 %t42, ptr %t46, !tbaa !24
  br label %ret
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t47 = load ptr, ptr %l5, !tbaa !29
  %t49 = getelementptr %"std/prelude/map:mapSlot.2b294a08895cef9a38135689ddc2ff4b", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  store ptr %t50, ptr %l5, !tbaa !29
  br label %bb2
bb11:
  %t52 = load ptr, ptr %l3, !tbaa !29
  %t53 = load i64, ptr %l4, !tbaa !24
  %t54 = load %"compiler/eval:dkey", ptr %l1
  %t55 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2feval_3adkey_2c_20I64_3_Hec9200682241ff25f3ca473d81814ba9(ptr %v0, ptr %t52, i64 %t53, %"compiler/eval:dkey" %t54, i64 %t55)
  br label %bb12
bb12:
  br label %ret
ret:
  ret void
}

define dso_local { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2feval_3agkey_2c_20I64_3e_2eG_H841bd46d30f67641fdfac3080f15aea1(ptr %v0, ptr %a0, %"compiler/eval:gkey" %a1) #0 {
entry:
  %l1 = alloca %"compiler/eval:gkey"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l10 = alloca i64
  %l17 = alloca %"compiler/eval:gkey"
  %l19 = alloca %"compiler/eval:gkey"
  %l21 = alloca i1
  %rv = alloca { i32, i64 }
  store %"compiler/eval:gkey" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t6, i32 0, i32 0
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  store { i64, ptr } %t9, ptr %l7, !tbaa !27
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t11 = load %"compiler/eval:gkey", ptr %l1
  %t14 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2feval_3agkey_2c_20I64_3_H841cf439ef0414fd917a12c49900f4d8(ptr %v0, ptr %t10, %"compiler/eval:gkey" %t11)
  store i64 %t14, ptr %l10
  br label %bb1
bb1:
  %t15 = load i64, ptr %l10, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr ptr, ptr %t17, i64 %t15
  %t19 = load ptr, ptr %t18, !tbaa !39
  store ptr %t19, ptr %l3, !tbaa !29
  br label %bb2
bb2:
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t23 = icmp eq ptr %t21, null
  %t25 = xor i1 %t23, true
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t29 = load ptr, ptr %l3, !tbaa !29
  %t31 = getelementptr %"std/prelude/map:mapSlot.ee9ec0b0cf3c88d460faed9ec3c15b49", ptr %t29, i32 0, i32 0
  %t32 = getelementptr %"std/prelude/map:MapEntry.035e99ae244af91b94aafcb9668dfc7c", ptr %t31, i32 0, i32 0
  %t33 = load %"compiler/eval:gkey", ptr %t32
  store %"compiler/eval:gkey" %t33, ptr %l17
  %t34 = load %"compiler/eval:gkey", ptr %l1
  store %"compiler/eval:gkey" %t34, ptr %l19
  %t37 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2feval_3agkey(ptr %l17, ptr %l19)
  store i1 %t37, ptr %l21
  br label %bb6
bb6:
  %t38 = load i1, ptr %l21, !tbaa !21
  br i1 %t38, label %bb7, label %bb8
bb7:
  %t39 = load ptr, ptr %l3, !tbaa !29
  %t41 = getelementptr %"std/prelude/map:mapSlot.ee9ec0b0cf3c88d460faed9ec3c15b49", ptr %t39, i32 0, i32 0
  %t42 = getelementptr %"std/prelude/map:MapEntry.035e99ae244af91b94aafcb9668dfc7c", ptr %t41, i32 0, i32 1
  %t43 = load i64, ptr %t42, !tbaa !24
  %t45 = insertvalue { i32, i64 } zeroinitializer, i64 %t43, 1
  store { i32, i64 } %t45, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t46 = load ptr, ptr %l3, !tbaa !29
  %t48 = getelementptr %"std/prelude/map:mapSlot.ee9ec0b0cf3c88d460faed9ec3c15b49", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  store ptr %t49, ptr %l3, !tbaa !29
  br label %bb2
bb11:
  %t52 = insertvalue { i32, i64 } zeroinitializer, i32 65536, 0
  store { i32, i64 } %t52, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2feval_3agkey_2c_20I64_3e_2eP_Hdbb1ec214f67f51e9ea8789b3bf075dc(ptr %v0, ptr %a0, %"compiler/eval:gkey" %a1, i64 %a2) #0 {
entry:
  %l1 = alloca %"compiler/eval:gkey"
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca ptr
  %l10 = alloca i64
  %l12 = alloca { i64, ptr }
  %l20 = alloca %"compiler/eval:gkey"
  %l22 = alloca %"compiler/eval:gkey"
  %l24 = alloca i1
  store %"compiler/eval:gkey" %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t7 = load %"compiler/eval:gkey", ptr %l1
  %t10 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2feval_3agkey_2c_20I64_3_H841cf439ef0414fd917a12c49900f4d8(ptr %v0, ptr %t6, %"compiler/eval:gkey" %t7)
  store i64 %t10, ptr %l10
  br label %bb1
bb1:
  %t11 = load i64, ptr %l10, !tbaa !24
  store i64 %t11, ptr %l4, !tbaa !24
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t14 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  store { i64, ptr } %t15, ptr %l12, !tbaa !27
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l5, !tbaa !29
  br label %bb2
bb2:
  %t23 = load ptr, ptr %l5, !tbaa !29
  %t25 = icmp eq ptr %t23, null
  %t27 = xor i1 %t25, true
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t31 = load ptr, ptr %l5, !tbaa !29
  %t33 = getelementptr %"std/prelude/map:mapSlot.ee9ec0b0cf3c88d460faed9ec3c15b49", ptr %t31, i32 0, i32 0
  %t34 = getelementptr %"std/prelude/map:MapEntry.035e99ae244af91b94aafcb9668dfc7c", ptr %t33, i32 0, i32 0
  %t35 = load %"compiler/eval:gkey", ptr %t34
  store %"compiler/eval:gkey" %t35, ptr %l20
  %t36 = load %"compiler/eval:gkey", ptr %l1
  store %"compiler/eval:gkey" %t36, ptr %l22
  %t39 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2feval_3agkey(ptr %l20, ptr %l22)
  store i1 %t39, ptr %l24
  br label %bb6
bb6:
  %t40 = load i1, ptr %l24, !tbaa !21
  br i1 %t40, label %bb7, label %bb8
bb7:
  %t41 = load ptr, ptr %l5, !tbaa !29
  %t42 = load i64, ptr %l2, !tbaa !24
  %t45 = getelementptr %"std/prelude/map:mapSlot.ee9ec0b0cf3c88d460faed9ec3c15b49", ptr %t41, i32 0, i32 0
  %t46 = getelementptr %"std/prelude/map:MapEntry.035e99ae244af91b94aafcb9668dfc7c", ptr %t45, i32 0, i32 1
  store i64 %t42, ptr %t46, !tbaa !24
  br label %ret
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t47 = load ptr, ptr %l5, !tbaa !29
  %t49 = getelementptr %"std/prelude/map:mapSlot.ee9ec0b0cf3c88d460faed9ec3c15b49", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  store ptr %t50, ptr %l5, !tbaa !29
  br label %bb2
bb11:
  %t52 = load ptr, ptr %l3, !tbaa !29
  %t53 = load i64, ptr %l4, !tbaa !24
  %t54 = load %"compiler/eval:gkey", ptr %l1
  %t55 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2feval_3agkey_2c_20I64_3_Hd9a0b7bbd66f10db800209721b39e2c0(ptr %v0, ptr %t52, i64 %t53, %"compiler/eval:gkey" %t54, i64 %t55)
  br label %bb12
bb12:
  br label %ret
ret:
  ret void
}

define dso_local { i32, { i64, [2 x i64] } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_Ha5986096190b27059e1b255ecbd90571(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l10 = alloca i64
  %rv = alloca { i32, { i64, [2 x i64] } }
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t6, i32 0, i32 0
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  store { i64, ptr } %t9, ptr %l7, !tbaa !27
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t11 = load i32, ptr %l1, !tbaa !23
  %t14 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2fsource_3aNameId_2c_20B_Heab357d0b792d165805bc071c98cf6d1(ptr %v0, ptr %t10, i32 %t11)
  store i64 %t14, ptr %l10
  br label %bb1
bb1:
  %t15 = load i64, ptr %l10, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr ptr, ptr %t17, i64 %t15
  %t19 = load ptr, ptr %t18, !tbaa !39
  store ptr %t19, ptr %l3, !tbaa !29
  br label %bb2
bb2:
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t23 = icmp eq ptr %t21, null
  %t25 = xor i1 %t23, true
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb3, label %bb4
bb3:
  br label %bb10
bb4:
  br label %bb5
bb5:
  %t29 = load ptr, ptr %l3, !tbaa !29
  %t31 = getelementptr %"std/prelude/map:mapSlot.0dde5ffa1ef5aae0493dbeb7dc27c2c6", ptr %t29, i32 0, i32 0
  %t32 = getelementptr %"std/prelude/map:MapEntry.706ff6be11be6fcfa446047bbb0c400e", ptr %t31, i32 0, i32 0
  %t33 = load i32, ptr %t32, !tbaa !23
  %t34 = load i32, ptr %l1, !tbaa !23
  %t37 = icmp eq i32 %t33, %t34
  br i1 %t37, label %bb6, label %bb7
bb6:
  %t39 = load ptr, ptr %l3, !tbaa !29
  %t41 = getelementptr %"std/prelude/map:mapSlot.0dde5ffa1ef5aae0493dbeb7dc27c2c6", ptr %t39, i32 0, i32 0
  %t42 = getelementptr %"std/prelude/map:MapEntry.706ff6be11be6fcfa446047bbb0c400e", ptr %t41, i32 0, i32 1
  %t43 = load { i64, [2 x i64] }, ptr %t42
  %t45 = insertvalue { i32, { i64, [2 x i64] } } zeroinitializer, { i64, [2 x i64] } %t43, 1
  store { i32, { i64, [2 x i64] } } %t45, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t46 = load ptr, ptr %l3, !tbaa !29
  %t48 = getelementptr %"std/prelude/map:mapSlot.0dde5ffa1ef5aae0493dbeb7dc27c2c6", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  store ptr %t49, ptr %l3, !tbaa !29
  br label %bb2
bb10:
  %t52 = insertvalue { i32, { i64, [2 x i64] } } zeroinitializer, i32 65536, 0
  store { i32, { i64, [2 x i64] } } %t52, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, [2 x i64] } }, ptr %rv
  ret { i32, { i64, [2 x i64] } } %rr
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_Haf69023555548e8239d9db5dde4c25f9(ptr %v0, ptr %a0, i32 %a1, { i64, [2 x i64] } %a2) #0 {
entry:
  %l1 = alloca i32
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca ptr
  %l10 = alloca i64
  %l12 = alloca { i64, ptr }
  store i32 %a1, ptr %l1
  store { i64, [2 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2fsource_3aNameId_2c_20B_Heab357d0b792d165805bc071c98cf6d1(ptr %v0, ptr %t6, i32 %t7)
  store i64 %t10, ptr %l10
  br label %bb1
bb1:
  %t11 = load i64, ptr %l10, !tbaa !24
  store i64 %t11, ptr %l4, !tbaa !24
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t14 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  store { i64, ptr } %t15, ptr %l12, !tbaa !27
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l5, !tbaa !29
  br label %bb2
bb2:
  %t23 = load ptr, ptr %l5, !tbaa !29
  %t25 = icmp eq ptr %t23, null
  %t27 = xor i1 %t25, true
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb3, label %bb4
bb3:
  br label %bb10
bb4:
  br label %bb5
bb5:
  %t31 = load ptr, ptr %l5, !tbaa !29
  %t33 = getelementptr %"std/prelude/map:mapSlot.0dde5ffa1ef5aae0493dbeb7dc27c2c6", ptr %t31, i32 0, i32 0
  %t34 = getelementptr %"std/prelude/map:MapEntry.706ff6be11be6fcfa446047bbb0c400e", ptr %t33, i32 0, i32 0
  %t35 = load i32, ptr %t34, !tbaa !23
  %t36 = load i32, ptr %l1, !tbaa !23
  %t39 = icmp eq i32 %t35, %t36
  br i1 %t39, label %bb6, label %bb7
bb6:
  %t41 = load ptr, ptr %l5, !tbaa !29
  %t42 = load { i64, [2 x i64] }, ptr %l2
  %t45 = getelementptr %"std/prelude/map:mapSlot.0dde5ffa1ef5aae0493dbeb7dc27c2c6", ptr %t41, i32 0, i32 0
  %t46 = getelementptr %"std/prelude/map:MapEntry.706ff6be11be6fcfa446047bbb0c400e", ptr %t45, i32 0, i32 1
  store { i64, [2 x i64] } %t42, ptr %t46
  br label %ret
bb7:
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t47 = load ptr, ptr %l5, !tbaa !29
  %t49 = getelementptr %"std/prelude/map:mapSlot.0dde5ffa1ef5aae0493dbeb7dc27c2c6", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  store ptr %t50, ptr %l5, !tbaa !29
  br label %bb2
bb10:
  %t52 = load ptr, ptr %l3, !tbaa !29
  %t53 = load i64, ptr %l4, !tbaa !24
  %t54 = load i32, ptr %l1, !tbaa !23
  %t55 = load { i64, [2 x i64] }, ptr %l2
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2ftypes_3aTypeId_2c_20co_H62ac5ba1336878a7eb48a137c2b4729a(ptr %v0, ptr %t52, i64 %t53, i32 %t54, { i64, [2 x i64] } %t55)
  br label %bb11
bb11:
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cI64_2c_20Array_3ccompiler_2fmir_3_H11fbc4bfdb46a56f60be4bc7497bd008(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, { i64, ptr } %a3) #0 {
entry:
  tail call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cI64_2c_20std_2fprelude_2ftext_3aS_Hbc76424a3315a39f193abd133425e79e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, { i64, ptr } %a3)
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cI64_2c_20Array_3ccompiler_2fmir_3_H4a133e229c838eb95883d01af3d74998(ptr %v0, ptr %a0) #0 {
entry:
  tail call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cI64_2c_20std_2fprelude_2ftext_3aS_H278e2bff38291605745e721886b12833(ptr %v0, ptr %a0)
  ret void
}

define dso_local i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cI64_2c_20Array_3ccompiler_2fmir_3_Hcf717ce4e812d6ed2868982a4066c0ba(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cI64_2c_20Bool_3e_2ebucketOf_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
  ret i64 %r
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2feval_3adkey_2c_20I64_3_H8c14b686068f73ddd3d1514a6d03efec(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l13 = alloca ptr
  %l16 = alloca i64
  %l25 = alloca i64
  %l28 = alloca i64
  %l46 = alloca { i64, ptr }
  %l58 = alloca i64
  %l61 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l1, !tbaa !27
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l13, !tbaa !29
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t11 = mul i64 %t9, 2
  store i64 %t11, ptr %l16, !tbaa !24
  %t12 = load i64, ptr %l16, !tbaa !24
  %t13 = icmp sge i64 %t12, 0
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = load i64, ptr %l16, !tbaa !24
  %t16 = icmp sle i64 %t15, 1152921504606846975
  br i1 %t16, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_c86e3c417e5597b_1f94290d51440aef)
  unreachable
bb3:
  %t18 = load i64, ptr %l16, !tbaa !24
  %t19 = mul i64 %t18, 8
  %t20 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t19)
  %t21 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t24 = load ptr, ptr %l13, !tbaa !29
  %t25 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t24, i32 0, i32 0
  store { i64, ptr } %t22, ptr %t25, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t26 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  store i64 %t28, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t30 = load i64, ptr %l3, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t34 = icmp sgt i64 %t30, %t31
  br i1 %t34, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_c86e3c417e5597b_1f94290d51440aef)
  unreachable
bb5:
  %t36 = load i64, ptr %l4, !tbaa !24
  %t38 = icmp sgt i64 %t36, 0
  br i1 %t38, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb10
bb7:
  %t40 = load i64, ptr %l3, !tbaa !24
  %t41 = load i64, ptr %l2, !tbaa !24
  %t44 = sub i64 %t40, %t41
  %t45 = load i64, ptr %l4, !tbaa !24
  %t48 = add i64 %t44, %t45
  %t50 = sub i64 %t48, 1
  %t51 = load i64, ptr %l4, !tbaa !24
  %t54 = sdiv i64 %t50, %t51
  store i64 %t54, ptr %l28, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb9
bb9:
  %t56 = load i64, ptr %l28, !tbaa !24
  store i64 %t56, ptr %l25, !tbaa !24
  br label %bb10
bb10:
  %t57 = load i64, ptr %l25, !tbaa !24
  store i64 %t57, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb11
bb11:
  %t58 = load i64, ptr %l6, !tbaa !24
  %t59 = load i64, ptr %l5, !tbaa !24
  %t62 = icmp slt i64 %t58, %t59
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb12, label %bb13
bb12:
  br label %bb23
bb13:
  br label %bb14
bb14:
  %t66 = load i64, ptr %l2, !tbaa !24
  %t67 = load i64, ptr %l6, !tbaa !24
  %t68 = load i64, ptr %l4, !tbaa !24
  %t71 = mul i64 %t67, %t68
  %t74 = add i64 %t66, %t71
  %t76 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t76, ptr %l46, !tbaa !27
  %t79 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr ptr, ptr %t80, i64 %t74
  %t82 = load ptr, ptr %t81, !tbaa !39
  store ptr %t82, ptr %l8, !tbaa !29
  br label %bb15
bb15:
  %t84 = load ptr, ptr %l8, !tbaa !29
  %t86 = icmp eq ptr %t84, null
  %t88 = xor i1 %t86, true
  %t90 = xor i1 %t88, true
  br i1 %t90, label %bb16, label %bb17
bb16:
  br label %bb21
bb17:
  br label %bb18
bb18:
  %t92 = load ptr, ptr %l8, !tbaa !29
  %t94 = getelementptr %"std/prelude/map:mapSlot.2b294a08895cef9a38135689ddc2ff4b", ptr %t92, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !29
  store ptr %t95, ptr %l9, !tbaa !29
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load ptr, ptr %l8, !tbaa !29
  %t100 = getelementptr %"std/prelude/map:mapSlot.2b294a08895cef9a38135689ddc2ff4b", ptr %t98, i32 0, i32 0
  %t101 = getelementptr %"std/prelude/map:MapEntry.ed812e0d562b6dfc0ada2d6105c5025d", ptr %t100, i32 0, i32 0
  %t102 = load %"compiler/eval:dkey", ptr %t101
  %t105 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2feval_3adkey_2c_20I64_3_Ha76b9910eb5ae3d1a0cb4a2d27badbbf(ptr %v0, ptr %t97, %"compiler/eval:dkey" %t102)
  store i64 %t105, ptr %l58
  br label %bb19
bb19:
  %t106 = load i64, ptr %l58, !tbaa !24
  store i64 %t106, ptr %l10, !tbaa !24
  %t107 = load ptr, ptr %l8, !tbaa !29
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t108, i32 0, i32 0
  %t111 = load { i64, ptr }, ptr %t110, !tbaa !27
  store { i64, ptr } %t111, ptr %l61, !tbaa !27
  %t112 = load i64, ptr %l10, !tbaa !24
  %t114 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr ptr, ptr %t115, i64 %t112
  %t117 = load ptr, ptr %t116, !tbaa !39
  %t120 = getelementptr %"std/prelude/map:mapSlot.2b294a08895cef9a38135689ddc2ff4b", ptr %t107, i32 0, i32 1
  store ptr %t117, ptr %t120, !tbaa !29
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t121, i32 0, i32 0
  %t124 = load { i64, ptr }, ptr %t123, !tbaa !27
  store { i64, ptr } %t124, ptr %l65, !tbaa !27
  %t125 = load i64, ptr %l10, !tbaa !24
  %t126 = load ptr, ptr %l8, !tbaa !29
  %t130 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr ptr, ptr %t131, i64 %t125
  store ptr %t126, ptr %t132, !tbaa !39
  %t133 = load ptr, ptr %l9, !tbaa !29
  store ptr %t133, ptr %l8, !tbaa !29
  br label %bb20
bb20:
  br label %bb15
bb21:
  br label %bb22
bb22:
  %t135 = load i64, ptr %l6, !tbaa !24
  %t137 = add i64 %t135, 1
  store i64 %t137, ptr %l6, !tbaa !24
  br label %bb11
bb23:
  br label %ret
ret:
  ret void
}

define dso_local i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2feval_3adkey_2c_20I64_3_Ha76b9910eb5ae3d1a0cb4a2d27badbbf(ptr %v0, ptr %a0, %"compiler/eval:dkey" %a1) #0 {
entry:
  %l2 = alloca %"compiler/eval:dkey"
  %l4 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store %"compiler/eval:dkey" %a1, ptr %l2
  %t3 = call i64 @olang_2eHelperKind_2eHash_2ecompiler_2feval_3adkey(ptr %l2)
  store i64 %t3, ptr %l4
  br label %bb1
bb1:
  %t6 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %a0, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t11 = sub i64 %t9, 1
  %t12 = load i64, ptr %l4, !tbaa !24
  %t14 = and i64 %t12, %t11
  store i64 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2feval_3adkey_2c_20I64_3_Hec9200682241ff25f3ca473d81814ba9(ptr %v0, ptr %a0, i64 %a1, %"compiler/eval:dkey" %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/eval:dkey"
  %l3 = alloca i64
  %l4 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l15 = alloca { i64, ptr }
  %l18 = alloca %"std/prelude/map:mapSlot.2b294a08895cef9a38135689ddc2ff4b"
  %l23 = alloca ptr
  %l26 = alloca %"std/prelude/map:MapEntry.ed812e0d562b6dfc0ada2d6105c5025d"
  %l29 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l37 = alloca ptr
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/eval:dkey" %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t8 = icmp eq ptr %t6, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  store { i64, ptr } %t13, ptr %l10, !tbaa !27
  %t14 = load i64, ptr %l1, !tbaa !24
  store i64 %t14, ptr %l11, !tbaa !24
  %t15 = load %"compiler/eval:dkey", ptr %l2
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t17, i32 0, i32 0
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  store { i64, ptr } %t20, ptr %l15, !tbaa !27
  %t21 = load i64, ptr %l1, !tbaa !24
  %t23 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr ptr, ptr %t24, i64 %t21
  %t26 = load ptr, ptr %t25, !tbaa !39
  %t30 = call %"std/prelude/map:mapSlot.2b294a08895cef9a38135689ddc2ff4b" @std_2fprelude_2fmap_3amapSlot_3ccompiler_2feval_3adkey_2c_20I64_3e_2ector(ptr %v0, ptr %v0, %"compiler/eval:dkey" %t15, i64 %t16, ptr %t26)
  store %"std/prelude/map:mapSlot.2b294a08895cef9a38135689ddc2ff4b" %t30, ptr %l18
  br label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %l4, !tbaa !29
  %t34 = getelementptr %"std/prelude/map:mapSlot.2b294a08895cef9a38135689ddc2ff4b", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t38 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t31, i32 0, i32 2
  store ptr %t35, ptr %t38, !tbaa !29
  %t39 = load ptr, ptr %l4, !tbaa !29
  store ptr %t39, ptr %l23, !tbaa !29
  %t40 = load %"compiler/eval:dkey", ptr %l2
  %t41 = load i64, ptr %l3, !tbaa !24
  %t44 = call %"std/prelude/map:MapEntry.ed812e0d562b6dfc0ada2d6105c5025d" @std_2fprelude_2fmap_3aMapEntry_3ccompiler_2feval_3adkey_2c_20I64_3e_2ector(ptr %s2, %"compiler/eval:dkey" %t40, i64 %t41)
  store %"std/prelude/map:MapEntry.ed812e0d562b6dfc0ada2d6105c5025d" %t44, ptr %l26
  br label %bb4
bb3:
  %t45 = load %"std/prelude/map:mapSlot.2b294a08895cef9a38135689ddc2ff4b", ptr %l18
  %t46 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store %"std/prelude/map:mapSlot.2b294a08895cef9a38135689ddc2ff4b" %t45, ptr %t46
  %t48 = load i64, ptr %l11, !tbaa !24
  %t49 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr ptr, ptr %t50, i64 %t48
  store ptr %t46, ptr %t51, !tbaa !39
  br label %bb5
bb4:
  %t52 = load %"std/prelude/map:MapEntry.ed812e0d562b6dfc0ada2d6105c5025d", ptr %l26
  %t53 = load ptr, ptr %l23, !tbaa !29
  %t54 = getelementptr %"std/prelude/map:mapSlot.2b294a08895cef9a38135689ddc2ff4b", ptr %t53, i32 0, i32 0
  store %"std/prelude/map:MapEntry.ed812e0d562b6dfc0ada2d6105c5025d" %t52, ptr %t54
  %t55 = load ptr, ptr %l4, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t56, i32 0, i32 0
  %t59 = load { i64, ptr }, ptr %t58, !tbaa !27
  store { i64, ptr } %t59, ptr %l29, !tbaa !27
  %t60 = load i64, ptr %l1, !tbaa !24
  %t62 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr ptr, ptr %t63, i64 %t60
  %t65 = load ptr, ptr %t64, !tbaa !39
  %t68 = getelementptr %"std/prelude/map:mapSlot.2b294a08895cef9a38135689ddc2ff4b", ptr %t55, i32 0, i32 1
  store ptr %t65, ptr %t68, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t69, i32 0, i32 0
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !27
  store { i64, ptr } %t72, ptr %l33, !tbaa !27
  %t73 = load i64, ptr %l1, !tbaa !24
  %t74 = load ptr, ptr %l4, !tbaa !29
  %t78 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = getelementptr ptr, ptr %t79, i64 %t73
  store ptr %t74, ptr %t80, !tbaa !39
  call void @__olang_scope_close(ptr %s2)
  br label %bb5
bb5:
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l37, !tbaa !29
  %t82 = load ptr, ptr %l37, !tbaa !29
  %t83 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t82, i32 0, i32 1
  %t84 = load i64, ptr %t83, !tbaa !24
  %t86 = add i64 %t84, 1
  %t88 = load ptr, ptr %l37, !tbaa !29
  %t89 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t88, i32 0, i32 1
  store i64 %t86, ptr %t89, !tbaa !24
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t90, i32 0, i32 1
  %t93 = load i64, ptr %t92, !tbaa !24
  %t95 = mul i64 %t93, 4
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t96, i32 0, i32 0
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t99, 0
  %t103 = mul i64 %t101, 3
  %t106 = icmp sgt i64 %t95, %t103
  br i1 %t106, label %bb6, label %bb7
bb6:
  %t108 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2feval_3adkey_2c_20I64_3_H8c14b686068f73ddd3d1514a6d03efec(ptr %v0, ptr %t108)
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb9
bb9:
  br label %ret
ret:
  ret void
}

define dso_local i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2feval_3agkey_2c_20I64_3_H841cf439ef0414fd917a12c49900f4d8(ptr %v0, ptr %a0, %"compiler/eval:gkey" %a1) #0 {
entry:
  %l2 = alloca %"compiler/eval:gkey"
  %l4 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store %"compiler/eval:gkey" %a1, ptr %l2
  %t3 = call i64 @olang_2eHelperKind_2eHash_2ecompiler_2feval_3agkey(ptr %l2)
  store i64 %t3, ptr %l4
  br label %bb1
bb1:
  %t6 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %a0, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t11 = sub i64 %t9, 1
  %t12 = load i64, ptr %l4, !tbaa !24
  %t14 = and i64 %t12, %t11
  store i64 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2feval_3agkey_2c_20I64_3_Hd9a0b7bbd66f10db800209721b39e2c0(ptr %v0, ptr %a0, i64 %a1, %"compiler/eval:gkey" %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/eval:gkey"
  %l3 = alloca i64
  %l4 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l15 = alloca { i64, ptr }
  %l18 = alloca %"std/prelude/map:mapSlot.ee9ec0b0cf3c88d460faed9ec3c15b49"
  %l23 = alloca ptr
  %l26 = alloca %"std/prelude/map:MapEntry.035e99ae244af91b94aafcb9668dfc7c"
  %l29 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l37 = alloca ptr
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/eval:gkey" %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t8 = icmp eq ptr %t6, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  store { i64, ptr } %t13, ptr %l10, !tbaa !27
  %t14 = load i64, ptr %l1, !tbaa !24
  store i64 %t14, ptr %l11, !tbaa !24
  %t15 = load %"compiler/eval:gkey", ptr %l2
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t17, i32 0, i32 0
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  store { i64, ptr } %t20, ptr %l15, !tbaa !27
  %t21 = load i64, ptr %l1, !tbaa !24
  %t23 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr ptr, ptr %t24, i64 %t21
  %t26 = load ptr, ptr %t25, !tbaa !39
  %t30 = call %"std/prelude/map:mapSlot.ee9ec0b0cf3c88d460faed9ec3c15b49" @std_2fprelude_2fmap_3amapSlot_3ccompiler_2feval_3agkey_2c_20I64_3e_2ector(ptr %v0, ptr %v0, %"compiler/eval:gkey" %t15, i64 %t16, ptr %t26)
  store %"std/prelude/map:mapSlot.ee9ec0b0cf3c88d460faed9ec3c15b49" %t30, ptr %l18
  br label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %l4, !tbaa !29
  %t34 = getelementptr %"std/prelude/map:mapSlot.ee9ec0b0cf3c88d460faed9ec3c15b49", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t38 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t31, i32 0, i32 2
  store ptr %t35, ptr %t38, !tbaa !29
  %t39 = load ptr, ptr %l4, !tbaa !29
  store ptr %t39, ptr %l23, !tbaa !29
  %t40 = load %"compiler/eval:gkey", ptr %l2
  %t41 = load i64, ptr %l3, !tbaa !24
  %t44 = call %"std/prelude/map:MapEntry.035e99ae244af91b94aafcb9668dfc7c" @std_2fprelude_2fmap_3aMapEntry_3ccompiler_2feval_3agkey_2c_20I64_3e_2ector(ptr %s2, %"compiler/eval:gkey" %t40, i64 %t41)
  store %"std/prelude/map:MapEntry.035e99ae244af91b94aafcb9668dfc7c" %t44, ptr %l26
  br label %bb4
bb3:
  %t45 = load %"std/prelude/map:mapSlot.ee9ec0b0cf3c88d460faed9ec3c15b49", ptr %l18
  %t46 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/map:mapSlot.ee9ec0b0cf3c88d460faed9ec3c15b49" %t45, ptr %t46
  %t48 = load i64, ptr %l11, !tbaa !24
  %t49 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr ptr, ptr %t50, i64 %t48
  store ptr %t46, ptr %t51, !tbaa !39
  br label %bb5
bb4:
  %t52 = load %"std/prelude/map:MapEntry.035e99ae244af91b94aafcb9668dfc7c", ptr %l26
  %t53 = load ptr, ptr %l23, !tbaa !29
  %t54 = getelementptr %"std/prelude/map:mapSlot.ee9ec0b0cf3c88d460faed9ec3c15b49", ptr %t53, i32 0, i32 0
  store %"std/prelude/map:MapEntry.035e99ae244af91b94aafcb9668dfc7c" %t52, ptr %t54
  %t55 = load ptr, ptr %l4, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t56, i32 0, i32 0
  %t59 = load { i64, ptr }, ptr %t58, !tbaa !27
  store { i64, ptr } %t59, ptr %l29, !tbaa !27
  %t60 = load i64, ptr %l1, !tbaa !24
  %t62 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr ptr, ptr %t63, i64 %t60
  %t65 = load ptr, ptr %t64, !tbaa !39
  %t68 = getelementptr %"std/prelude/map:mapSlot.ee9ec0b0cf3c88d460faed9ec3c15b49", ptr %t55, i32 0, i32 1
  store ptr %t65, ptr %t68, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t69, i32 0, i32 0
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !27
  store { i64, ptr } %t72, ptr %l33, !tbaa !27
  %t73 = load i64, ptr %l1, !tbaa !24
  %t74 = load ptr, ptr %l4, !tbaa !29
  %t78 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = getelementptr ptr, ptr %t79, i64 %t73
  store ptr %t74, ptr %t80, !tbaa !39
  call void @__olang_scope_close(ptr %s2)
  br label %bb5
bb5:
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l37, !tbaa !29
  %t82 = load ptr, ptr %l37, !tbaa !29
  %t83 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t82, i32 0, i32 1
  %t84 = load i64, ptr %t83, !tbaa !24
  %t86 = add i64 %t84, 1
  %t88 = load ptr, ptr %l37, !tbaa !29
  %t89 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t88, i32 0, i32 1
  store i64 %t86, ptr %t89, !tbaa !24
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t90, i32 0, i32 1
  %t93 = load i64, ptr %t92, !tbaa !24
  %t95 = mul i64 %t93, 4
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t96, i32 0, i32 0
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t99, 0
  %t103 = mul i64 %t101, 3
  %t106 = icmp sgt i64 %t95, %t103
  br i1 %t106, label %bb6, label %bb7
bb6:
  %t108 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2feval_3agkey_2c_20I64_3_Hdb018705ae914c9da2e7b37c8036492e(ptr %v0, ptr %t108)
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb9
bb9:
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2feval_3agkey_2c_20I64_3_Hdb018705ae914c9da2e7b37c8036492e(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l13 = alloca ptr
  %l16 = alloca i64
  %l25 = alloca i64
  %l28 = alloca i64
  %l46 = alloca { i64, ptr }
  %l58 = alloca i64
  %l61 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l1, !tbaa !27
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l13, !tbaa !29
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t11 = mul i64 %t9, 2
  store i64 %t11, ptr %l16, !tbaa !24
  %t12 = load i64, ptr %l16, !tbaa !24
  %t13 = icmp sge i64 %t12, 0
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = load i64, ptr %l16, !tbaa !24
  %t16 = icmp sle i64 %t15, 1152921504606846975
  br i1 %t16, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_1b0213f54aec9aef_9f01fc08d423d4eb)
  unreachable
bb3:
  %t18 = load i64, ptr %l16, !tbaa !24
  %t19 = mul i64 %t18, 8
  %t20 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t19)
  %t21 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t24 = load ptr, ptr %l13, !tbaa !29
  %t25 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t24, i32 0, i32 0
  store { i64, ptr } %t22, ptr %t25, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t26 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  store i64 %t28, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t30 = load i64, ptr %l3, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t34 = icmp sgt i64 %t30, %t31
  br i1 %t34, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_1b0213f54aec9aef_9f01fc08d423d4eb)
  unreachable
bb5:
  %t36 = load i64, ptr %l4, !tbaa !24
  %t38 = icmp sgt i64 %t36, 0
  br i1 %t38, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb10
bb7:
  %t40 = load i64, ptr %l3, !tbaa !24
  %t41 = load i64, ptr %l2, !tbaa !24
  %t44 = sub i64 %t40, %t41
  %t45 = load i64, ptr %l4, !tbaa !24
  %t48 = add i64 %t44, %t45
  %t50 = sub i64 %t48, 1
  %t51 = load i64, ptr %l4, !tbaa !24
  %t54 = sdiv i64 %t50, %t51
  store i64 %t54, ptr %l28, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb9
bb9:
  %t56 = load i64, ptr %l28, !tbaa !24
  store i64 %t56, ptr %l25, !tbaa !24
  br label %bb10
bb10:
  %t57 = load i64, ptr %l25, !tbaa !24
  store i64 %t57, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb11
bb11:
  %t58 = load i64, ptr %l6, !tbaa !24
  %t59 = load i64, ptr %l5, !tbaa !24
  %t62 = icmp slt i64 %t58, %t59
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb12, label %bb13
bb12:
  br label %bb23
bb13:
  br label %bb14
bb14:
  %t66 = load i64, ptr %l2, !tbaa !24
  %t67 = load i64, ptr %l6, !tbaa !24
  %t68 = load i64, ptr %l4, !tbaa !24
  %t71 = mul i64 %t67, %t68
  %t74 = add i64 %t66, %t71
  %t76 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t76, ptr %l46, !tbaa !27
  %t79 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr ptr, ptr %t80, i64 %t74
  %t82 = load ptr, ptr %t81, !tbaa !39
  store ptr %t82, ptr %l8, !tbaa !29
  br label %bb15
bb15:
  %t84 = load ptr, ptr %l8, !tbaa !29
  %t86 = icmp eq ptr %t84, null
  %t88 = xor i1 %t86, true
  %t90 = xor i1 %t88, true
  br i1 %t90, label %bb16, label %bb17
bb16:
  br label %bb21
bb17:
  br label %bb18
bb18:
  %t92 = load ptr, ptr %l8, !tbaa !29
  %t94 = getelementptr %"std/prelude/map:mapSlot.ee9ec0b0cf3c88d460faed9ec3c15b49", ptr %t92, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !29
  store ptr %t95, ptr %l9, !tbaa !29
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load ptr, ptr %l8, !tbaa !29
  %t100 = getelementptr %"std/prelude/map:mapSlot.ee9ec0b0cf3c88d460faed9ec3c15b49", ptr %t98, i32 0, i32 0
  %t101 = getelementptr %"std/prelude/map:MapEntry.035e99ae244af91b94aafcb9668dfc7c", ptr %t100, i32 0, i32 0
  %t102 = load %"compiler/eval:gkey", ptr %t101
  %t105 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2feval_3agkey_2c_20I64_3_H841cf439ef0414fd917a12c49900f4d8(ptr %v0, ptr %t97, %"compiler/eval:gkey" %t102)
  store i64 %t105, ptr %l58
  br label %bb19
bb19:
  %t106 = load i64, ptr %l58, !tbaa !24
  store i64 %t106, ptr %l10, !tbaa !24
  %t107 = load ptr, ptr %l8, !tbaa !29
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t108, i32 0, i32 0
  %t111 = load { i64, ptr }, ptr %t110, !tbaa !27
  store { i64, ptr } %t111, ptr %l61, !tbaa !27
  %t112 = load i64, ptr %l10, !tbaa !24
  %t114 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr ptr, ptr %t115, i64 %t112
  %t117 = load ptr, ptr %t116, !tbaa !39
  %t120 = getelementptr %"std/prelude/map:mapSlot.ee9ec0b0cf3c88d460faed9ec3c15b49", ptr %t107, i32 0, i32 1
  store ptr %t117, ptr %t120, !tbaa !29
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t121, i32 0, i32 0
  %t124 = load { i64, ptr }, ptr %t123, !tbaa !27
  store { i64, ptr } %t124, ptr %l65, !tbaa !27
  %t125 = load i64, ptr %l10, !tbaa !24
  %t126 = load ptr, ptr %l8, !tbaa !29
  %t130 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr ptr, ptr %t131, i64 %t125
  store ptr %t126, ptr %t132, !tbaa !39
  %t133 = load ptr, ptr %l9, !tbaa !29
  store ptr %t133, ptr %l8, !tbaa !29
  br label %bb20
bb20:
  br label %bb15
bb21:
  br label %bb22
bb22:
  %t135 = load i64, ptr %l6, !tbaa !24
  %t137 = add i64 %t135, 1
  store i64 %t137, ptr %l6, !tbaa !24
  br label %bb11
bb23:
  br label %ret
ret:
  ret void
}

define dso_local i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2ftypes_3aTypeId_2c_20co_H1b5d7d76646404e96f4ea040521e9a09(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2fsource_3aNameId_2c_20B_Heab357d0b792d165805bc071c98cf6d1(ptr %v0, ptr %a0, i32 %a1)
  ret i64 %r
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2ftypes_3aTypeId_2c_20co_H62ac5ba1336878a7eb48a137c2b4729a(ptr %v0, ptr %a0, i64 %a1, i32 %a2, { i64, [2 x i64] } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca { i64, [2 x i64] }
  %l4 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l15 = alloca { i64, ptr }
  %l18 = alloca %"std/prelude/map:mapSlot.0dde5ffa1ef5aae0493dbeb7dc27c2c6"
  %l23 = alloca ptr
  %l26 = alloca %"std/prelude/map:MapEntry.706ff6be11be6fcfa446047bbb0c400e"
  %l29 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l37 = alloca ptr
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store { i64, [2 x i64] } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t8 = icmp eq ptr %t6, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  store { i64, ptr } %t13, ptr %l10, !tbaa !27
  %t14 = load i64, ptr %l1, !tbaa !24
  store i64 %t14, ptr %l11, !tbaa !24
  %t15 = load i32, ptr %l2, !tbaa !23
  %t16 = load { i64, [2 x i64] }, ptr %l3
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t17, i32 0, i32 0
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  store { i64, ptr } %t20, ptr %l15, !tbaa !27
  %t21 = load i64, ptr %l1, !tbaa !24
  %t23 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr ptr, ptr %t24, i64 %t21
  %t26 = load ptr, ptr %t25, !tbaa !39
  %t30 = call %"std/prelude/map:mapSlot.0dde5ffa1ef5aae0493dbeb7dc27c2c6" @std_2fprelude_2fmap_3amapSlot_3ccompiler_2ftypes_3aTypeId_2c_20compiler_2fmir_3aFnKey_3e_2ector(ptr %v0, ptr %v0, i32 %t15, { i64, [2 x i64] } %t16, ptr %t26)
  store %"std/prelude/map:mapSlot.0dde5ffa1ef5aae0493dbeb7dc27c2c6" %t30, ptr %l18
  br label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %l4, !tbaa !29
  %t34 = getelementptr %"std/prelude/map:mapSlot.0dde5ffa1ef5aae0493dbeb7dc27c2c6", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t38 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t31, i32 0, i32 2
  store ptr %t35, ptr %t38, !tbaa !29
  %t39 = load ptr, ptr %l4, !tbaa !29
  store ptr %t39, ptr %l23, !tbaa !29
  %t40 = load i32, ptr %l2, !tbaa !23
  %t41 = load { i64, [2 x i64] }, ptr %l3
  %t44 = call %"std/prelude/map:MapEntry.706ff6be11be6fcfa446047bbb0c400e" @std_2fprelude_2fmap_3aMapEntry_3ccompiler_2ftypes_3aTypeId_2c_20compiler_2fmir_3aFnKey_3e_2ector(ptr %s2, i32 %t40, { i64, [2 x i64] } %t41)
  store %"std/prelude/map:MapEntry.706ff6be11be6fcfa446047bbb0c400e" %t44, ptr %l26
  br label %bb4
bb3:
  %t45 = load %"std/prelude/map:mapSlot.0dde5ffa1ef5aae0493dbeb7dc27c2c6", ptr %l18
  %t46 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store %"std/prelude/map:mapSlot.0dde5ffa1ef5aae0493dbeb7dc27c2c6" %t45, ptr %t46
  %t48 = load i64, ptr %l11, !tbaa !24
  %t49 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr ptr, ptr %t50, i64 %t48
  store ptr %t46, ptr %t51, !tbaa !39
  br label %bb5
bb4:
  %t52 = load %"std/prelude/map:MapEntry.706ff6be11be6fcfa446047bbb0c400e", ptr %l26
  %t53 = load ptr, ptr %l23, !tbaa !29
  %t54 = getelementptr %"std/prelude/map:mapSlot.0dde5ffa1ef5aae0493dbeb7dc27c2c6", ptr %t53, i32 0, i32 0
  store %"std/prelude/map:MapEntry.706ff6be11be6fcfa446047bbb0c400e" %t52, ptr %t54
  %t55 = load ptr, ptr %l4, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t56, i32 0, i32 0
  %t59 = load { i64, ptr }, ptr %t58, !tbaa !27
  store { i64, ptr } %t59, ptr %l29, !tbaa !27
  %t60 = load i64, ptr %l1, !tbaa !24
  %t62 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr ptr, ptr %t63, i64 %t60
  %t65 = load ptr, ptr %t64, !tbaa !39
  %t68 = getelementptr %"std/prelude/map:mapSlot.0dde5ffa1ef5aae0493dbeb7dc27c2c6", ptr %t55, i32 0, i32 1
  store ptr %t65, ptr %t68, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t69, i32 0, i32 0
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !27
  store { i64, ptr } %t72, ptr %l33, !tbaa !27
  %t73 = load i64, ptr %l1, !tbaa !24
  %t74 = load ptr, ptr %l4, !tbaa !29
  %t78 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = getelementptr ptr, ptr %t79, i64 %t73
  store ptr %t74, ptr %t80, !tbaa !39
  call void @__olang_scope_close(ptr %s2)
  br label %bb5
bb5:
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l37, !tbaa !29
  %t82 = load ptr, ptr %l37, !tbaa !29
  %t83 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t82, i32 0, i32 1
  %t84 = load i64, ptr %t83, !tbaa !24
  %t86 = add i64 %t84, 1
  %t88 = load ptr, ptr %l37, !tbaa !29
  %t89 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t88, i32 0, i32 1
  store i64 %t86, ptr %t89, !tbaa !24
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t90, i32 0, i32 1
  %t93 = load i64, ptr %t92, !tbaa !24
  %t95 = mul i64 %t93, 4
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t96, i32 0, i32 0
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t99, 0
  %t103 = mul i64 %t101, 3
  %t106 = icmp sgt i64 %t95, %t103
  br i1 %t106, label %bb6, label %bb7
bb6:
  %t108 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2ftypes_3aTypeId_2c_20co_H6c87738fde541cbd9194e4f000a647d4(ptr %v0, ptr %t108)
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb9
bb9:
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2ftypes_3aTypeId_2c_20co_H6c87738fde541cbd9194e4f000a647d4(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l13 = alloca ptr
  %l16 = alloca i64
  %l25 = alloca i64
  %l28 = alloca i64
  %l46 = alloca { i64, ptr }
  %l58 = alloca i64
  %l61 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l1, !tbaa !27
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l13, !tbaa !29
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t11 = mul i64 %t9, 2
  store i64 %t11, ptr %l16, !tbaa !24
  %t12 = load i64, ptr %l16, !tbaa !24
  %t13 = icmp sge i64 %t12, 0
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = load i64, ptr %l16, !tbaa !24
  %t16 = icmp sle i64 %t15, 1152921504606846975
  br i1 %t16, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_aeaae73888a93de2_57b628b04640c97e)
  unreachable
bb3:
  %t18 = load i64, ptr %l16, !tbaa !24
  %t19 = mul i64 %t18, 8
  %t20 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t19)
  %t21 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t24 = load ptr, ptr %l13, !tbaa !29
  %t25 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t24, i32 0, i32 0
  store { i64, ptr } %t22, ptr %t25, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t26 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  store i64 %t28, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t30 = load i64, ptr %l3, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t34 = icmp sgt i64 %t30, %t31
  br i1 %t34, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_aeaae73888a93de2_57b628b04640c97e)
  unreachable
bb5:
  %t36 = load i64, ptr %l4, !tbaa !24
  %t38 = icmp sgt i64 %t36, 0
  br i1 %t38, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb10
bb7:
  %t40 = load i64, ptr %l3, !tbaa !24
  %t41 = load i64, ptr %l2, !tbaa !24
  %t44 = sub i64 %t40, %t41
  %t45 = load i64, ptr %l4, !tbaa !24
  %t48 = add i64 %t44, %t45
  %t50 = sub i64 %t48, 1
  %t51 = load i64, ptr %l4, !tbaa !24
  %t54 = sdiv i64 %t50, %t51
  store i64 %t54, ptr %l28, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb9
bb9:
  %t56 = load i64, ptr %l28, !tbaa !24
  store i64 %t56, ptr %l25, !tbaa !24
  br label %bb10
bb10:
  %t57 = load i64, ptr %l25, !tbaa !24
  store i64 %t57, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb11
bb11:
  %t58 = load i64, ptr %l6, !tbaa !24
  %t59 = load i64, ptr %l5, !tbaa !24
  %t62 = icmp slt i64 %t58, %t59
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb12, label %bb13
bb12:
  br label %bb23
bb13:
  br label %bb14
bb14:
  %t66 = load i64, ptr %l2, !tbaa !24
  %t67 = load i64, ptr %l6, !tbaa !24
  %t68 = load i64, ptr %l4, !tbaa !24
  %t71 = mul i64 %t67, %t68
  %t74 = add i64 %t66, %t71
  %t76 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t76, ptr %l46, !tbaa !27
  %t79 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr ptr, ptr %t80, i64 %t74
  %t82 = load ptr, ptr %t81, !tbaa !39
  store ptr %t82, ptr %l8, !tbaa !29
  br label %bb15
bb15:
  %t84 = load ptr, ptr %l8, !tbaa !29
  %t86 = icmp eq ptr %t84, null
  %t88 = xor i1 %t86, true
  %t90 = xor i1 %t88, true
  br i1 %t90, label %bb16, label %bb17
bb16:
  br label %bb21
bb17:
  br label %bb18
bb18:
  %t92 = load ptr, ptr %l8, !tbaa !29
  %t94 = getelementptr %"std/prelude/map:mapSlot.0dde5ffa1ef5aae0493dbeb7dc27c2c6", ptr %t92, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !29
  store ptr %t95, ptr %l9, !tbaa !29
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load ptr, ptr %l8, !tbaa !29
  %t100 = getelementptr %"std/prelude/map:mapSlot.0dde5ffa1ef5aae0493dbeb7dc27c2c6", ptr %t98, i32 0, i32 0
  %t101 = getelementptr %"std/prelude/map:MapEntry.706ff6be11be6fcfa446047bbb0c400e", ptr %t100, i32 0, i32 0
  %t102 = load i32, ptr %t101, !tbaa !23
  %t105 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2fsource_3aNameId_2c_20B_Heab357d0b792d165805bc071c98cf6d1(ptr %v0, ptr %t97, i32 %t102)
  store i64 %t105, ptr %l58
  br label %bb19
bb19:
  %t106 = load i64, ptr %l58, !tbaa !24
  store i64 %t106, ptr %l10, !tbaa !24
  %t107 = load ptr, ptr %l8, !tbaa !29
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t108, i32 0, i32 0
  %t111 = load { i64, ptr }, ptr %t110, !tbaa !27
  store { i64, ptr } %t111, ptr %l61, !tbaa !27
  %t112 = load i64, ptr %l10, !tbaa !24
  %t114 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr ptr, ptr %t115, i64 %t112
  %t117 = load ptr, ptr %t116, !tbaa !39
  %t120 = getelementptr %"std/prelude/map:mapSlot.0dde5ffa1ef5aae0493dbeb7dc27c2c6", ptr %t107, i32 0, i32 1
  store ptr %t117, ptr %t120, !tbaa !29
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t121, i32 0, i32 0
  %t124 = load { i64, ptr }, ptr %t123, !tbaa !27
  store { i64, ptr } %t124, ptr %l65, !tbaa !27
  %t125 = load i64, ptr %l10, !tbaa !24
  %t126 = load ptr, ptr %l8, !tbaa !29
  %t130 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr ptr, ptr %t131, i64 %t125
  store ptr %t126, ptr %t132, !tbaa !39
  %t133 = load ptr, ptr %l9, !tbaa !29
  store ptr %t133, ptr %l8, !tbaa !29
  br label %bb20
bb20:
  br label %bb15
bb21:
  br label %bb22
bb22:
  %t135 = load i64, ptr %l6, !tbaa !24
  %t137 = add i64 %t135, 1
  store i64 %t137, ptr %l6, !tbaa !24
  br label %bb11
bb23:
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/map:MapEntry.8d509622153b47f1a5f79c42c8367406" @std_2fprelude_2fmap_3aMapEntry_3cI64_2c_20Array_3ccompiler_2fmir_3aFnKey_3e_26_3e_2ector(ptr %v0, ptr %v1, i64 %a0, { i64, ptr } %a1) #0 {
entry:
  %r = tail call %"std/prelude/map:MapEntry.8d509622153b47f1a5f79c42c8367406" @std_2fprelude_2fmap_3aMapEntry_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, ptr %v1, i64 %a0, { i64, ptr } %a1)
  ret %"std/prelude/map:MapEntry.8d509622153b47f1a5f79c42c8367406" %r
}

define dso_local %"std/prelude/map:MapEntry.ed812e0d562b6dfc0ada2d6105c5025d" @std_2fprelude_2fmap_3aMapEntry_3ccompiler_2feval_3adkey_2c_20I64_3e_2ector(ptr %v0, %"compiler/eval:dkey" %a0, i64 %a1) #0 {
entry:
  %rv = alloca %"std/prelude/map:MapEntry.ed812e0d562b6dfc0ada2d6105c5025d"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"std/prelude/map:MapEntry.ed812e0d562b6dfc0ada2d6105c5025d" undef, %"compiler/eval:dkey" %a0, 0
  %t8 = insertvalue %"std/prelude/map:MapEntry.ed812e0d562b6dfc0ada2d6105c5025d" %t6, i64 %a1, 1
  store %"std/prelude/map:MapEntry.ed812e0d562b6dfc0ada2d6105c5025d" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:MapEntry.ed812e0d562b6dfc0ada2d6105c5025d", ptr %rv
  ret %"std/prelude/map:MapEntry.ed812e0d562b6dfc0ada2d6105c5025d" %rr
}

define dso_local %"std/prelude/map:MapEntry.035e99ae244af91b94aafcb9668dfc7c" @std_2fprelude_2fmap_3aMapEntry_3ccompiler_2feval_3agkey_2c_20I64_3e_2ector(ptr %v0, %"compiler/eval:gkey" %a0, i64 %a1) #0 {
entry:
  %rv = alloca %"std/prelude/map:MapEntry.035e99ae244af91b94aafcb9668dfc7c"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"std/prelude/map:MapEntry.035e99ae244af91b94aafcb9668dfc7c" undef, %"compiler/eval:gkey" %a0, 0
  %t8 = insertvalue %"std/prelude/map:MapEntry.035e99ae244af91b94aafcb9668dfc7c" %t6, i64 %a1, 1
  store %"std/prelude/map:MapEntry.035e99ae244af91b94aafcb9668dfc7c" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:MapEntry.035e99ae244af91b94aafcb9668dfc7c", ptr %rv
  ret %"std/prelude/map:MapEntry.035e99ae244af91b94aafcb9668dfc7c" %rr
}

define dso_local %"std/prelude/map:MapEntry.706ff6be11be6fcfa446047bbb0c400e" @std_2fprelude_2fmap_3aMapEntry_3ccompiler_2ftypes_3aTypeId_2c_20compiler_2fmir_3aFnKey_3e_2ector(ptr %v0, i32 %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %rv = alloca %"std/prelude/map:MapEntry.706ff6be11be6fcfa446047bbb0c400e"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"std/prelude/map:MapEntry.706ff6be11be6fcfa446047bbb0c400e" undef, i32 %a0, 0
  %t8 = insertvalue %"std/prelude/map:MapEntry.706ff6be11be6fcfa446047bbb0c400e" %t6, { i64, [2 x i64] } %a1, 1
  store %"std/prelude/map:MapEntry.706ff6be11be6fcfa446047bbb0c400e" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:MapEntry.706ff6be11be6fcfa446047bbb0c400e", ptr %rv
  ret %"std/prelude/map:MapEntry.706ff6be11be6fcfa446047bbb0c400e" %rr
}

define dso_local %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Array_3ccompiler_2fmir_3aFnKey_3e_26_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2feval_3adkey_2c_20I64_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2feval_3agkey_2c_20I64_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compiler_2fmir_3aFnKey_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/map:mapSlot.47b3cc80db0b342939bd1d482dd866ad" @std_2fprelude_2fmap_3amapSlot_3cI64_2c_20Array_3ccompiler_2fmir_3aFnKey_3e_26_3e_2ector(ptr %v0, ptr %v1, ptr %v2, i64 %a0, { i64, ptr } %a1, ptr %a2) #0 {
entry:
  %r = tail call %"std/prelude/map:mapSlot.47b3cc80db0b342939bd1d482dd866ad" @std_2fprelude_2fmap_3amapSlot_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, ptr %v1, ptr %v2, i64 %a0, { i64, ptr } %a1, ptr %a2)
  ret %"std/prelude/map:mapSlot.47b3cc80db0b342939bd1d482dd866ad" %r
}

define dso_local %"std/prelude/map:mapSlot.2b294a08895cef9a38135689ddc2ff4b" @std_2fprelude_2fmap_3amapSlot_3ccompiler_2feval_3adkey_2c_20I64_3e_2ector(ptr %v0, ptr %v1, %"compiler/eval:dkey" %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l7 = alloca %"std/prelude/map:MapEntry.ed812e0d562b6dfc0ada2d6105c5025d"
  %rv = alloca %"std/prelude/map:mapSlot.2b294a08895cef9a38135689ddc2ff4b"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call %"std/prelude/map:MapEntry.ed812e0d562b6dfc0ada2d6105c5025d" @std_2fprelude_2fmap_3aMapEntry_3ccompiler_2feval_3adkey_2c_20I64_3e_2ector(ptr %v1, %"compiler/eval:dkey" %a0, i64 %a1)
  store %"std/prelude/map:MapEntry.ed812e0d562b6dfc0ada2d6105c5025d" %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load %"std/prelude/map:MapEntry.ed812e0d562b6dfc0ada2d6105c5025d", ptr %l7
  %t10 = insertvalue %"std/prelude/map:mapSlot.2b294a08895cef9a38135689ddc2ff4b" undef, %"std/prelude/map:MapEntry.ed812e0d562b6dfc0ada2d6105c5025d" %t6, 0
  %t12 = insertvalue %"std/prelude/map:mapSlot.2b294a08895cef9a38135689ddc2ff4b" %t10, ptr %a2, 1
  store %"std/prelude/map:mapSlot.2b294a08895cef9a38135689ddc2ff4b" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:mapSlot.2b294a08895cef9a38135689ddc2ff4b", ptr %rv
  ret %"std/prelude/map:mapSlot.2b294a08895cef9a38135689ddc2ff4b" %rr
}

define dso_local %"std/prelude/map:mapSlot.ee9ec0b0cf3c88d460faed9ec3c15b49" @std_2fprelude_2fmap_3amapSlot_3ccompiler_2feval_3agkey_2c_20I64_3e_2ector(ptr %v0, ptr %v1, %"compiler/eval:gkey" %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l7 = alloca %"std/prelude/map:MapEntry.035e99ae244af91b94aafcb9668dfc7c"
  %rv = alloca %"std/prelude/map:mapSlot.ee9ec0b0cf3c88d460faed9ec3c15b49"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call %"std/prelude/map:MapEntry.035e99ae244af91b94aafcb9668dfc7c" @std_2fprelude_2fmap_3aMapEntry_3ccompiler_2feval_3agkey_2c_20I64_3e_2ector(ptr %v1, %"compiler/eval:gkey" %a0, i64 %a1)
  store %"std/prelude/map:MapEntry.035e99ae244af91b94aafcb9668dfc7c" %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load %"std/prelude/map:MapEntry.035e99ae244af91b94aafcb9668dfc7c", ptr %l7
  %t10 = insertvalue %"std/prelude/map:mapSlot.ee9ec0b0cf3c88d460faed9ec3c15b49" undef, %"std/prelude/map:MapEntry.035e99ae244af91b94aafcb9668dfc7c" %t6, 0
  %t12 = insertvalue %"std/prelude/map:mapSlot.ee9ec0b0cf3c88d460faed9ec3c15b49" %t10, ptr %a2, 1
  store %"std/prelude/map:mapSlot.ee9ec0b0cf3c88d460faed9ec3c15b49" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:mapSlot.ee9ec0b0cf3c88d460faed9ec3c15b49", ptr %rv
  ret %"std/prelude/map:mapSlot.ee9ec0b0cf3c88d460faed9ec3c15b49" %rr
}

define dso_local %"std/prelude/map:mapSlot.0dde5ffa1ef5aae0493dbeb7dc27c2c6" @std_2fprelude_2fmap_3amapSlot_3ccompiler_2ftypes_3aTypeId_2c_20compiler_2fmir_3aFnKey_3e_2ector(ptr %v0, ptr %v1, i32 %a0, { i64, [2 x i64] } %a1, ptr %a2) #0 {
entry:
  %l7 = alloca %"std/prelude/map:MapEntry.706ff6be11be6fcfa446047bbb0c400e"
  %rv = alloca %"std/prelude/map:mapSlot.0dde5ffa1ef5aae0493dbeb7dc27c2c6"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call %"std/prelude/map:MapEntry.706ff6be11be6fcfa446047bbb0c400e" @std_2fprelude_2fmap_3aMapEntry_3ccompiler_2ftypes_3aTypeId_2c_20compiler_2fmir_3aFnKey_3e_2ector(ptr %v1, i32 %a0, { i64, [2 x i64] } %a1)
  store %"std/prelude/map:MapEntry.706ff6be11be6fcfa446047bbb0c400e" %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load %"std/prelude/map:MapEntry.706ff6be11be6fcfa446047bbb0c400e", ptr %l7
  %t10 = insertvalue %"std/prelude/map:mapSlot.0dde5ffa1ef5aae0493dbeb7dc27c2c6" undef, %"std/prelude/map:MapEntry.706ff6be11be6fcfa446047bbb0c400e" %t6, 0
  %t12 = insertvalue %"std/prelude/map:mapSlot.0dde5ffa1ef5aae0493dbeb7dc27c2c6" %t10, ptr %a2, 1
  store %"std/prelude/map:mapSlot.0dde5ffa1ef5aae0493dbeb7dc27c2c6" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:mapSlot.0dde5ffa1ef5aae0493dbeb7dc27c2c6", ptr %rv
  ret %"std/prelude/map:mapSlot.0dde5ffa1ef5aae0493dbeb7dc27c2c6" %rr
}

define dso_local %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" @std_2fprelude_2fmap_3amapState_3cI64_2c_20Array_3ccompiler_2fmir_3aFnKey_3e_26_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" @std_2fprelude_2fmap_3amapState_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)
  ret %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" %r
}

define dso_local %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" @std_2fprelude_2fmap_3amapState_3ccompiler_2feval_3adkey_2c_20I64_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" @std_2fprelude_2fmap_3amapState_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)
  ret %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" %r
}

define dso_local %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" @std_2fprelude_2fmap_3amapState_3ccompiler_2feval_3agkey_2c_20I64_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" @std_2fprelude_2fmap_3amapState_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)
  ret %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" %r
}

define dso_local %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" @std_2fprelude_2fmap_3amapState_3ccompiler_2ftypes_3aTypeId_2c_20compiler_2fmir_3aFnKey_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" @std_2fprelude_2fmap_3amapState_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)
  ret %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" %r
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aBlob_3e_2ePush_3ccompiler_2feval_3aBlob_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/eval:Blob" %a1) #0 {
entry:
  %l1 = alloca %"compiler/eval:Blob"
  %l2 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l21 = alloca ptr
  store %"compiler/eval:Blob" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t6, i32 0, i32 1
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t18 = icmp eq i64 %t9, %t15
  br i1 %t18, label %bb1, label %bb2
bb1:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 1
  %t24 = load i64, ptr %t23, !tbaa !24
  %t26 = add i64 %t24, 1
  %t27 = load %"compiler/eval:Blob", ptr %l1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2feval_3aBlob_3e_2eroom_3ccompiler_2feval_3aBlob_3e(ptr %v0, ptr %v1, ptr %t20, i64 %t26, %"compiler/eval:Blob" %t27)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t33 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t31, i32 0, i32 0
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  store { i64, ptr } %t34, ptr %l17, !tbaa !27
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t35, i32 0, i32 1
  %t38 = load i64, ptr %t37, !tbaa !24
  %t39 = load %"compiler/eval:Blob", ptr %l1
  %t42 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr %"compiler/eval:Blob", ptr %t43, i64 %t38
  store %"compiler/eval:Blob" %t39, ptr %t44
  %t45 = load ptr, ptr %l2, !tbaa !29
  store ptr %t45, ptr %l21, !tbaa !29
  %t46 = load ptr, ptr %l21, !tbaa !29
  %t47 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t46, i32 0, i32 1
  %t48 = load i64, ptr %t47, !tbaa !24
  %t50 = add i64 %t48, 1
  %t52 = load ptr, ptr %l21, !tbaa !29
  %t53 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t52, i32 0, i32 1
  store i64 %t50, ptr %t53, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aBlob_3e_2eSetAt_3ccompiler_2feval_3aBlob_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/eval:Blob" %a2) #0 {
entry:
  %l5 = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l5, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr %"compiler/eval:Blob", ptr %t13, i64 %a1
  store %"compiler/eval:Blob" %a2, ptr %t14
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3agenRec_3e_2eAt_3ccompiler_2feval_3agenRec_3e(ptr %out, ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %l6 = alloca %"compiler/eval:genRec"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l4, !tbaa !27
  %t10 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr %"compiler/eval:genRec", ptr %t11, i64 %a1
  call void @llvm.memmove.p0.p0.i64(ptr %l6, ptr %t12, i64 168, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l6, i64 168, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3agenRec_3e_2eLen_3ccompiler_2feval_3agenRec_3e(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
  ret i64 %r
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3agenRec_3e_2ePush_3ccompiler_2feval_3agenRec_3e(ptr %v0, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca %"compiler/eval:genRec"
  %l2 = alloca ptr
  %l15 = alloca %"compiler/eval:genRec"
  %l17 = alloca { i64, ptr }
  %l20 = alloca %"compiler/eval:genRec"
  %l21 = alloca ptr
  %t29 = alloca %"compiler/eval:genRec", align 8
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %a1, i64 168, i1 false)
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t6, i32 0, i32 1
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t18 = icmp eq i64 %t9, %t15
  br i1 %t18, label %bb1, label %bb2
bb1:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 1
  %t24 = load i64, ptr %t23, !tbaa !24
  %t26 = add i64 %t24, 1
  call void @llvm.memmove.p0.p0.i64(ptr %l15, ptr %l1, i64 168, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %t29, ptr %l15, i64 168, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2feval_3agenRec_3e_2eroom_3ccompiler_2feval_3agenRec_3e(ptr %v0, ptr %t20, i64 %t26, ptr %t29)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t30 = load ptr, ptr %l2, !tbaa !29
  %t32 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t30, i32 0, i32 0
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } %t33, ptr %l17, !tbaa !27
  %t34 = load ptr, ptr %l2, !tbaa !29
  %t36 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t34, i32 0, i32 1
  %t37 = load i64, ptr %t36, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l20, ptr %l1, i64 168, i1 false)
  %t39 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr %"compiler/eval:genRec", ptr %t40, i64 %t37
  call void @llvm.memmove.p0.p0.i64(ptr %t41, ptr %l20, i64 168, i1 false)
  %t42 = load ptr, ptr %l2, !tbaa !29
  store ptr %t42, ptr %l21, !tbaa !29
  %t43 = load ptr, ptr %l21, !tbaa !29
  %t44 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t43, i32 0, i32 1
  %t45 = load i64, ptr %t44, !tbaa !24
  %t47 = add i64 %t45, 1
  %t49 = load ptr, ptr %l21, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t49, i32 0, i32 1
  store i64 %t47, ptr %t50, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3agenRec_3e_2eSetAt_3ccompiler_2feval_3agenRec_3e(ptr %v0, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l2 = alloca %"compiler/eval:genRec"
  %l5 = alloca { i64, ptr }
  %l7 = alloca %"compiler/eval:genRec"
  call void @llvm.memmove.p0.p0.i64(ptr %l2, ptr %a2, i64 168, i1 false)
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l5, !tbaa !27
  call void @llvm.memmove.p0.p0.i64(ptr %l7, ptr %l2, i64 168, i1 false)
  %t10 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr %"compiler/eval:genRec", ptr %t11, i64 %a1
  call void @llvm.memmove.p0.p0.i64(ptr %t12, ptr %l7, i64 168, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/eval:global" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2eAt_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %rv = alloca %"compiler/eval:global"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l4, !tbaa !27
  %t10 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr %"compiler/eval:global", ptr %t11, i64 %a1
  %t13 = load %"compiler/eval:global", ptr %t12
  store %"compiler/eval:global" %t13, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/eval:global", ptr %rv
  ret %"compiler/eval:global" %rr
}

define dso_local i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2eLen_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
  ret i64 %r
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2ePush_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %a0, %"compiler/eval:global" %a1) #0 {
entry:
  %l1 = alloca %"compiler/eval:global"
  %l2 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l21 = alloca ptr
  store %"compiler/eval:global" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t6, i32 0, i32 1
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t18 = icmp eq i64 %t9, %t15
  br i1 %t18, label %bb1, label %bb2
bb1:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 1
  %t24 = load i64, ptr %t23, !tbaa !24
  %t26 = add i64 %t24, 1
  %t27 = load %"compiler/eval:global", ptr %l1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2feval_3aglobal_3e_2eroom_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %t20, i64 %t26, %"compiler/eval:global" %t27)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t33 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t31, i32 0, i32 0
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  store { i64, ptr } %t34, ptr %l17, !tbaa !27
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t35, i32 0, i32 1
  %t38 = load i64, ptr %t37, !tbaa !24
  %t39 = load %"compiler/eval:global", ptr %l1
  %t42 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr %"compiler/eval:global", ptr %t43, i64 %t38
  store %"compiler/eval:global" %t39, ptr %t44
  %t45 = load ptr, ptr %l2, !tbaa !29
  store ptr %t45, ptr %l21, !tbaa !29
  %t46 = load ptr, ptr %l21, !tbaa !29
  %t47 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t46, i32 0, i32 1
  %t48 = load i64, ptr %t47, !tbaa !24
  %t50 = add i64 %t48, 1
  %t52 = load ptr, ptr %l21, !tbaa !29
  %t53 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t52, i32 0, i32 1
  store i64 %t50, ptr %t53, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2eSetAt_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %a0, i64 %a1, %"compiler/eval:global" %a2) #0 {
entry:
  %l5 = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l5, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr %"compiler/eval:global", ptr %t13, i64 %a1
  store %"compiler/eval:global" %a2, ptr %t14
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/eval:reg" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3areg_3e_2eAt_3ccompiler_2feval_3areg_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %rv = alloca %"compiler/eval:reg"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l4, !tbaa !27
  %t10 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr %"compiler/eval:reg", ptr %t11, i64 %a1
  %t13 = load %"compiler/eval:reg", ptr %t12
  store %"compiler/eval:reg" %t13, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/eval:reg", ptr %rv
  ret %"compiler/eval:reg" %rr
}

define dso_local i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3areg_3e_2eLen_3ccompiler_2feval_3areg_3e(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
  ret i64 %r
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3areg_3e_2ePush_3ccompiler_2feval_3areg_3e(ptr %v0, ptr %a0, %"compiler/eval:reg" %a1) #0 {
entry:
  %l1 = alloca %"compiler/eval:reg"
  %l2 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l21 = alloca ptr
  store %"compiler/eval:reg" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t6, i32 0, i32 1
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t18 = icmp eq i64 %t9, %t15
  br i1 %t18, label %bb1, label %bb2
bb1:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 1
  %t24 = load i64, ptr %t23, !tbaa !24
  %t26 = add i64 %t24, 1
  %t27 = load %"compiler/eval:reg", ptr %l1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2feval_3areg_3e_2eroom_3ccompiler_2feval_3areg_3e(ptr %v0, ptr %t20, i64 %t26, %"compiler/eval:reg" %t27)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t33 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t31, i32 0, i32 0
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  store { i64, ptr } %t34, ptr %l17, !tbaa !27
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t35, i32 0, i32 1
  %t38 = load i64, ptr %t37, !tbaa !24
  %t39 = load %"compiler/eval:reg", ptr %l1
  %t42 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr %"compiler/eval:reg", ptr %t43, i64 %t38
  store %"compiler/eval:reg" %t39, ptr %t44
  %t45 = load ptr, ptr %l2, !tbaa !29
  store ptr %t45, ptr %l21, !tbaa !29
  %t46 = load ptr, ptr %l21, !tbaa !29
  %t47 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t46, i32 0, i32 1
  %t48 = load i64, ptr %t47, !tbaa !24
  %t50 = add i64 %t48, 1
  %t52 = load ptr, ptr %l21, !tbaa !29
  %t53 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t52, i32 0, i32 1
  store i64 %t50, ptr %t53, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3areg_3e_2eSetAt_3ccompiler_2feval_3areg_3e(ptr %v0, ptr %a0, i64 %a1, %"compiler/eval:reg" %a2) #0 {
entry:
  %l5 = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l5, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr %"compiler/eval:reg", ptr %t13, i64 %a1
  store %"compiler/eval:reg" %a2, ptr %t14
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %out, ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %l6 = alloca %"compiler/eval:scope"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l4, !tbaa !27
  %t10 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr %"compiler/eval:scope", ptr %t11, i64 %a1
  call void @llvm.memmove.p0.p0.i64(ptr %l6, ptr %t12, i64 136, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l6, i64 136, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eLen_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
  ret i64 %r
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2ePush_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca %"compiler/eval:scope"
  %l2 = alloca ptr
  %l15 = alloca %"compiler/eval:scope"
  %l17 = alloca { i64, ptr }
  %l20 = alloca %"compiler/eval:scope"
  %l21 = alloca ptr
  %t29 = alloca %"compiler/eval:scope", align 8
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %a1, i64 136, i1 false)
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t6, i32 0, i32 1
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t18 = icmp eq i64 %t9, %t15
  br i1 %t18, label %bb1, label %bb2
bb1:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 1
  %t24 = load i64, ptr %t23, !tbaa !24
  %t26 = add i64 %t24, 1
  call void @llvm.memmove.p0.p0.i64(ptr %l15, ptr %l1, i64 136, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %t29, ptr %l15, i64 136, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2feval_3ascope_3e_2eroom_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %t20, i64 %t26, ptr %t29)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t30 = load ptr, ptr %l2, !tbaa !29
  %t32 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t30, i32 0, i32 0
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } %t33, ptr %l17, !tbaa !27
  %t34 = load ptr, ptr %l2, !tbaa !29
  %t36 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t34, i32 0, i32 1
  %t37 = load i64, ptr %t36, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l20, ptr %l1, i64 136, i1 false)
  %t39 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr %"compiler/eval:scope", ptr %t40, i64 %t37
  call void @llvm.memmove.p0.p0.i64(ptr %t41, ptr %l20, i64 136, i1 false)
  %t42 = load ptr, ptr %l2, !tbaa !29
  store ptr %t42, ptr %l21, !tbaa !29
  %t43 = load ptr, ptr %l21, !tbaa !29
  %t44 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t43, i32 0, i32 1
  %t45 = load i64, ptr %t44, !tbaa !24
  %t47 = add i64 %t45, 1
  %t49 = load ptr, ptr %l21, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t49, i32 0, i32 1
  store i64 %t47, ptr %t50, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eSetAt_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l2 = alloca %"compiler/eval:scope"
  %l5 = alloca { i64, ptr }
  %l7 = alloca %"compiler/eval:scope"
  call void @llvm.memmove.p0.p0.i64(ptr %l2, ptr %a2, i64 136, i1 false)
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l5, !tbaa !27
  call void @llvm.memmove.p0.p0.i64(ptr %l7, ptr %l2, i64 136, i1 false)
  %t10 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr %"compiler/eval:scope", ptr %t11, i64 %a1
  call void @llvm.memmove.p0.p0.i64(ptr %t12, ptr %l7, i64 136, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/eval:task" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3atask_3e_2eAt_3ccompiler_2feval_3atask_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %rv = alloca %"compiler/eval:task"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l4, !tbaa !27
  %t10 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr %"compiler/eval:task", ptr %t11, i64 %a1
  %t13 = load %"compiler/eval:task", ptr %t12
  store %"compiler/eval:task" %t13, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/eval:task", ptr %rv
  ret %"compiler/eval:task" %rr
}

define dso_local i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3atask_3e_2eLen_3ccompiler_2feval_3atask_3e(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
  ret i64 %r
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3atask_3e_2ePush_3ccompiler_2feval_3atask_3e(ptr %v0, ptr %a0, %"compiler/eval:task" %a1) #0 {
entry:
  %l1 = alloca %"compiler/eval:task"
  %l2 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l21 = alloca ptr
  store %"compiler/eval:task" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t6, i32 0, i32 1
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t18 = icmp eq i64 %t9, %t15
  br i1 %t18, label %bb1, label %bb2
bb1:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 1
  %t24 = load i64, ptr %t23, !tbaa !24
  %t26 = add i64 %t24, 1
  %t27 = load %"compiler/eval:task", ptr %l1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2feval_3atask_3e_2eroom_3ccompiler_2feval_3atask_3e(ptr %v0, ptr %t20, i64 %t26, %"compiler/eval:task" %t27)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t33 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t31, i32 0, i32 0
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  store { i64, ptr } %t34, ptr %l17, !tbaa !27
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t35, i32 0, i32 1
  %t38 = load i64, ptr %t37, !tbaa !24
  %t39 = load %"compiler/eval:task", ptr %l1
  %t42 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr %"compiler/eval:task", ptr %t43, i64 %t38
  store %"compiler/eval:task" %t39, ptr %t44
  %t45 = load ptr, ptr %l2, !tbaa !29
  store ptr %t45, ptr %l21, !tbaa !29
  %t46 = load ptr, ptr %l21, !tbaa !29
  %t47 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t46, i32 0, i32 1
  %t48 = load i64, ptr %t47, !tbaa !24
  %t50 = add i64 %t48, 1
  %t52 = load ptr, ptr %l21, !tbaa !29
  %t53 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t52, i32 0, i32 1
  store i64 %t50, ptr %t53, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3atask_3e_2eSetAt_3ccompiler_2feval_3atask_3e(ptr %v0, ptr %a0, i64 %a1, %"compiler/eval:task" %a2) #0 {
entry:
  %l5 = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l5, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr %"compiler/eval:task", ptr %t13, i64 %a1
  store %"compiler/eval:task" %a2, ptr %t14
  br label %ret
ret:
  ret void
}

define dso_local i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2eHas_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %r = tail call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eHas_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i32 %a1)
  ret i1 %r
}

define dso_local { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eToArray_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l17 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca %"compiler/mir:Call"
  %l31 = alloca i64
  %l34 = alloca i64
  %l52 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  %t48 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t4, i32 0, i32 1
  %t7 = load i64, ptr %t6, !tbaa !24
  %t9 = icmp eq i64 %t7, 0
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = icmp sge i64 0, 0
  br i1 %t11, label %bb3, label %bb4
bb2:
  br label %bb7
bb3:
  %t13 = icmp sle i64 0, 72057594037927935
  br i1 %t13, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_a9a2c1aff025c9e9_b219f8625f9ea465)
  unreachable
bb5:
  %t15 = mul i64 0, 128
  %t16 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t15)
  %t17 = insertvalue { i64, ptr } undef, i64 0, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb6:
  call void @__olang_check_failed(ptr @olang_loc_a9a2c1aff025c9e9_b219f8625f9ea465)
  unreachable
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t20, i32 0, i32 0
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t23, i32 0, i32 1
  %t26 = load i64, ptr %t25, !tbaa !24
  store i64 %t26, ptr %l17, !tbaa !24
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t27, i32 0, i32 0
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t30, i32 0, i32 0
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } %t33, ptr %l20, !tbaa !27
  %t34 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr %"compiler/mir:Call", ptr %t35, i64 0
  %t37 = load %"compiler/mir:Call", ptr %t36
  store %"compiler/mir:Call" %t37, ptr %l21
  %t38 = load i64, ptr %l17, !tbaa !24
  %t39 = icmp sge i64 %t38, 0
  br i1 %t39, label %bb8, label %bb9
bb8:
  %t41 = load i64, ptr %l17, !tbaa !24
  %t42 = icmp sle i64 %t41, 72057594037927935
  br i1 %t42, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_25e9a5c9ebeb981c_fe6b680ddb4c23f8)
  unreachable
bb10:
  %t44 = load i64, ptr %l17, !tbaa !24
  %t45 = mul i64 %t44, 128
  %t46 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t45)
  %t47 = load %"compiler/mir:Call", ptr %l21
  store i64 0, ptr %t48
  br label %fill.49
fill.49:
  %t52 = load i64, ptr %t48
  %t53 = icmp slt i64 %t52, %t44
  br i1 %t53, label %fillb.50, label %filld.51
fillb.50:
  %t54 = getelementptr %"compiler/mir:Call", ptr %t46, i64 %t52
  store %"compiler/mir:Call" %t47, ptr %t54
  %t55 = add i64 %t52, 1
  store i64 %t55, ptr %t48
  br label %fill.49
filld.51:
  %t56 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t46, 1
  store { i64, ptr } %t57, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t59, i32 0, i32 0
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t62, i32 0, i32 1
  %t65 = load i64, ptr %t64, !tbaa !24
  store i64 %t65, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t67 = load i64, ptr %l3, !tbaa !24
  %t68 = load i64, ptr %l2, !tbaa !24
  %t71 = icmp sgt i64 %t67, %t68
  br i1 %t71, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_25e9a5c9ebeb981c_fe6b680ddb4c23f8)
  unreachable
bb12:
  %t73 = load i64, ptr %l4, !tbaa !24
  %t75 = icmp sgt i64 %t73, 0
  br i1 %t75, label %bb14, label %bb15
bb13:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb17
bb14:
  %t77 = load i64, ptr %l3, !tbaa !24
  %t78 = load i64, ptr %l2, !tbaa !24
  %t81 = sub i64 %t77, %t78
  %t82 = load i64, ptr %l4, !tbaa !24
  %t85 = add i64 %t81, %t82
  %t87 = sub i64 %t85, 1
  %t88 = load i64, ptr %l4, !tbaa !24
  %t91 = sdiv i64 %t87, %t88
  store i64 %t91, ptr %l34, !tbaa !24
  br label %bb16
bb15:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb16
bb16:
  %t93 = load i64, ptr %l34, !tbaa !24
  store i64 %t93, ptr %l31, !tbaa !24
  br label %bb17
bb17:
  %t94 = load i64, ptr %l31, !tbaa !24
  store i64 %t94, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb18
bb18:
  %t95 = load i64, ptr %l6, !tbaa !24
  %t96 = load i64, ptr %l5, !tbaa !24
  %t99 = icmp slt i64 %t95, %t96
  %t101 = xor i1 %t99, true
  br i1 %t101, label %bb19, label %bb20
bb19:
  br label %bb23
bb20:
  br label %bb21
bb21:
  %t103 = load i64, ptr %l2, !tbaa !24
  %t104 = load i64, ptr %l6, !tbaa !24
  %t105 = load i64, ptr %l4, !tbaa !24
  %t108 = mul i64 %t104, %t105
  %t111 = add i64 %t103, %t108
  store i64 %t111, ptr %l7, !tbaa !24
  %t113 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t113, ptr %l52, !tbaa !27
  %t114 = load i64, ptr %l7, !tbaa !24
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t115, i32 0, i32 0
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t120 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t118, i32 0, i32 0
  %t121 = load { i64, ptr }, ptr %t120, !tbaa !27
  store { i64, ptr } %t121, ptr %l56, !tbaa !27
  %t122 = load i64, ptr %l7, !tbaa !24
  %t124 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr %"compiler/mir:Call", ptr %t125, i64 %t122
  %t127 = load %"compiler/mir:Call", ptr %t126
  %t130 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr %"compiler/mir:Call", ptr %t131, i64 %t114
  store %"compiler/mir:Call" %t127, ptr %t132
  br label %bb22
bb22:
  %t133 = load i64, ptr %l6, !tbaa !24
  %t135 = add i64 %t133, 1
  store i64 %t135, ptr %l6, !tbaa !24
  br label %bb18
bb23:
  %t137 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t137, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCase_3e_2eToArray_3ccompiler_2fmir_3aCase_3e(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l17 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca %"compiler/mir:Case"
  %l31 = alloca i64
  %l34 = alloca i64
  %l52 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  %t48 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t4, i32 0, i32 1
  %t7 = load i64, ptr %t6, !tbaa !24
  %t9 = icmp eq i64 %t7, 0
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = icmp sge i64 0, 0
  br i1 %t11, label %bb3, label %bb4
bb2:
  br label %bb7
bb3:
  %t13 = icmp sle i64 0, 576460752303423487
  br i1 %t13, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_2a4a9afd1920f3f5_dc8fcefdcc7e7d21)
  unreachable
bb5:
  %t15 = mul i64 0, 16
  %t16 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t15)
  %t17 = insertvalue { i64, ptr } undef, i64 0, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb6:
  call void @__olang_check_failed(ptr @olang_loc_2a4a9afd1920f3f5_dc8fcefdcc7e7d21)
  unreachable
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t20, i32 0, i32 0
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t23, i32 0, i32 1
  %t26 = load i64, ptr %t25, !tbaa !24
  store i64 %t26, ptr %l17, !tbaa !24
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t27, i32 0, i32 0
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t30, i32 0, i32 0
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } %t33, ptr %l20, !tbaa !27
  %t34 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr %"compiler/mir:Case", ptr %t35, i64 0
  %t37 = load %"compiler/mir:Case", ptr %t36
  store %"compiler/mir:Case" %t37, ptr %l21
  %t38 = load i64, ptr %l17, !tbaa !24
  %t39 = icmp sge i64 %t38, 0
  br i1 %t39, label %bb8, label %bb9
bb8:
  %t41 = load i64, ptr %l17, !tbaa !24
  %t42 = icmp sle i64 %t41, 576460752303423487
  br i1 %t42, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_4db56186023bb188_997a37585b9ec014)
  unreachable
bb10:
  %t44 = load i64, ptr %l17, !tbaa !24
  %t45 = mul i64 %t44, 16
  %t46 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t45)
  %t47 = load %"compiler/mir:Case", ptr %l21
  store i64 0, ptr %t48
  br label %fill.49
fill.49:
  %t52 = load i64, ptr %t48
  %t53 = icmp slt i64 %t52, %t44
  br i1 %t53, label %fillb.50, label %filld.51
fillb.50:
  %t54 = getelementptr %"compiler/mir:Case", ptr %t46, i64 %t52
  store %"compiler/mir:Case" %t47, ptr %t54
  %t55 = add i64 %t52, 1
  store i64 %t55, ptr %t48
  br label %fill.49
filld.51:
  %t56 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t46, 1
  store { i64, ptr } %t57, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t59, i32 0, i32 0
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t62, i32 0, i32 1
  %t65 = load i64, ptr %t64, !tbaa !24
  store i64 %t65, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t67 = load i64, ptr %l3, !tbaa !24
  %t68 = load i64, ptr %l2, !tbaa !24
  %t71 = icmp sgt i64 %t67, %t68
  br i1 %t71, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_4db56186023bb188_997a37585b9ec014)
  unreachable
bb12:
  %t73 = load i64, ptr %l4, !tbaa !24
  %t75 = icmp sgt i64 %t73, 0
  br i1 %t75, label %bb14, label %bb15
bb13:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb17
bb14:
  %t77 = load i64, ptr %l3, !tbaa !24
  %t78 = load i64, ptr %l2, !tbaa !24
  %t81 = sub i64 %t77, %t78
  %t82 = load i64, ptr %l4, !tbaa !24
  %t85 = add i64 %t81, %t82
  %t87 = sub i64 %t85, 1
  %t88 = load i64, ptr %l4, !tbaa !24
  %t91 = sdiv i64 %t87, %t88
  store i64 %t91, ptr %l34, !tbaa !24
  br label %bb16
bb15:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb16
bb16:
  %t93 = load i64, ptr %l34, !tbaa !24
  store i64 %t93, ptr %l31, !tbaa !24
  br label %bb17
bb17:
  %t94 = load i64, ptr %l31, !tbaa !24
  store i64 %t94, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb18
bb18:
  %t95 = load i64, ptr %l6, !tbaa !24
  %t96 = load i64, ptr %l5, !tbaa !24
  %t99 = icmp slt i64 %t95, %t96
  %t101 = xor i1 %t99, true
  br i1 %t101, label %bb19, label %bb20
bb19:
  br label %bb23
bb20:
  br label %bb21
bb21:
  %t103 = load i64, ptr %l2, !tbaa !24
  %t104 = load i64, ptr %l6, !tbaa !24
  %t105 = load i64, ptr %l4, !tbaa !24
  %t108 = mul i64 %t104, %t105
  %t111 = add i64 %t103, %t108
  store i64 %t111, ptr %l7, !tbaa !24
  %t113 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t113, ptr %l52, !tbaa !27
  %t114 = load i64, ptr %l7, !tbaa !24
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t115, i32 0, i32 0
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t120 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t118, i32 0, i32 0
  %t121 = load { i64, ptr }, ptr %t120, !tbaa !27
  store { i64, ptr } %t121, ptr %l56, !tbaa !27
  %t122 = load i64, ptr %l7, !tbaa !24
  %t124 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr %"compiler/mir:Case", ptr %t125, i64 %t122
  %t127 = load %"compiler/mir:Case", ptr %t126
  %t130 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr %"compiler/mir:Case", ptr %t131, i64 %t114
  store %"compiler/mir:Case" %t127, ptr %t132
  br label %bb22
bb22:
  %t133 = load i64, ptr %l6, !tbaa !24
  %t135 = add i64 %t133, 1
  store i64 %t135, ptr %l6, !tbaa !24
  br label %bb18
bb23:
  %t137 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t137, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_3e_2eAt_3ccompiler_2fmir_3aFn_3e(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %l6 = alloca %"compiler/mir:Fn"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l4, !tbaa !27
  %t10 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr %"compiler/mir:Fn", ptr %t11, i64 %a1
  call void @llvm.memmove.p0.p0.i64(ptr %l6, ptr %t12, i64 232, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l6, i64 232, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_3e_2eLen_3ccompiler_2fmir_3aFn_3e(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
  ret i64 %r
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_3e_2ePush_3ccompiler_2fmir_3aFn_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca %"compiler/mir:Fn"
  %l2 = alloca ptr
  %l15 = alloca %"compiler/mir:Fn"
  %l17 = alloca { i64, ptr }
  %l20 = alloca %"compiler/mir:Fn"
  %l21 = alloca ptr
  %t29 = alloca %"compiler/mir:Fn", align 8
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %a1, i64 232, i1 false)
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t6, i32 0, i32 1
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t18 = icmp eq i64 %t9, %t15
  br i1 %t18, label %bb1, label %bb2
bb1:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 1
  %t24 = load i64, ptr %t23, !tbaa !24
  %t26 = add i64 %t24, 1
  call void @llvm.memmove.p0.p0.i64(ptr %l15, ptr %l1, i64 232, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %t29, ptr %l15, i64 232, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2fmir_3aFn_3e_2eroom_3ccompiler_2fmir_3aFn_3e(ptr %v0, ptr %v1, ptr %t20, i64 %t26, ptr %t29)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t30 = load ptr, ptr %l2, !tbaa !29
  %t32 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t30, i32 0, i32 0
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } %t33, ptr %l17, !tbaa !27
  %t34 = load ptr, ptr %l2, !tbaa !29
  %t36 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t34, i32 0, i32 1
  %t37 = load i64, ptr %t36, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l20, ptr %l1, i64 232, i1 false)
  %t39 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr %"compiler/mir:Fn", ptr %t40, i64 %t37
  call void @llvm.memmove.p0.p0.i64(ptr %t41, ptr %l20, i64 232, i1 false)
  %t42 = load ptr, ptr %l2, !tbaa !29
  store ptr %t42, ptr %l21, !tbaa !29
  %t43 = load ptr, ptr %l21, !tbaa !29
  %t44 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t43, i32 0, i32 1
  %t45 = load i64, ptr %t44, !tbaa !24
  %t47 = add i64 %t45, 1
  %t49 = load ptr, ptr %l21, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t49, i32 0, i32 1
  store i64 %t47, ptr %t50, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eToArray_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l17 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca %"compiler/mir:Local"
  %l31 = alloca i64
  %l34 = alloca i64
  %l52 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  %t48 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t4, i32 0, i32 1
  %t7 = load i64, ptr %t6, !tbaa !24
  %t9 = icmp eq i64 %t7, 0
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = icmp sge i64 0, 0
  br i1 %t11, label %bb3, label %bb4
bb2:
  br label %bb7
bb3:
  %t13 = icmp sle i64 0, 230584300921369395
  br i1 %t13, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_8a0f8702409a2f83_1bc382f02d0f4ff)
  unreachable
bb5:
  %t15 = mul i64 0, 40
  %t16 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t15)
  %t17 = insertvalue { i64, ptr } undef, i64 0, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb6:
  call void @__olang_check_failed(ptr @olang_loc_8a0f8702409a2f83_1bc382f02d0f4ff)
  unreachable
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t20, i32 0, i32 0
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t23, i32 0, i32 1
  %t26 = load i64, ptr %t25, !tbaa !24
  store i64 %t26, ptr %l17, !tbaa !24
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t27, i32 0, i32 0
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t30, i32 0, i32 0
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } %t33, ptr %l20, !tbaa !27
  %t34 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr %"compiler/mir:Local", ptr %t35, i64 0
  %t37 = load %"compiler/mir:Local", ptr %t36
  store %"compiler/mir:Local" %t37, ptr %l21
  %t38 = load i64, ptr %l17, !tbaa !24
  %t39 = icmp sge i64 %t38, 0
  br i1 %t39, label %bb8, label %bb9
bb8:
  %t41 = load i64, ptr %l17, !tbaa !24
  %t42 = icmp sle i64 %t41, 230584300921369395
  br i1 %t42, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_dee3d00730d4108e_ba689ea3709c32a)
  unreachable
bb10:
  %t44 = load i64, ptr %l17, !tbaa !24
  %t45 = mul i64 %t44, 40
  %t46 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t45)
  %t47 = load %"compiler/mir:Local", ptr %l21
  store i64 0, ptr %t48
  br label %fill.49
fill.49:
  %t52 = load i64, ptr %t48
  %t53 = icmp slt i64 %t52, %t44
  br i1 %t53, label %fillb.50, label %filld.51
fillb.50:
  %t54 = getelementptr %"compiler/mir:Local", ptr %t46, i64 %t52
  store %"compiler/mir:Local" %t47, ptr %t54
  %t55 = add i64 %t52, 1
  store i64 %t55, ptr %t48
  br label %fill.49
filld.51:
  %t56 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t46, 1
  store { i64, ptr } %t57, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t59, i32 0, i32 0
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t62, i32 0, i32 1
  %t65 = load i64, ptr %t64, !tbaa !24
  store i64 %t65, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t67 = load i64, ptr %l3, !tbaa !24
  %t68 = load i64, ptr %l2, !tbaa !24
  %t71 = icmp sgt i64 %t67, %t68
  br i1 %t71, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_dee3d00730d4108e_ba689ea3709c32a)
  unreachable
bb12:
  %t73 = load i64, ptr %l4, !tbaa !24
  %t75 = icmp sgt i64 %t73, 0
  br i1 %t75, label %bb14, label %bb15
bb13:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb17
bb14:
  %t77 = load i64, ptr %l3, !tbaa !24
  %t78 = load i64, ptr %l2, !tbaa !24
  %t81 = sub i64 %t77, %t78
  %t82 = load i64, ptr %l4, !tbaa !24
  %t85 = add i64 %t81, %t82
  %t87 = sub i64 %t85, 1
  %t88 = load i64, ptr %l4, !tbaa !24
  %t91 = sdiv i64 %t87, %t88
  store i64 %t91, ptr %l34, !tbaa !24
  br label %bb16
bb15:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb16
bb16:
  %t93 = load i64, ptr %l34, !tbaa !24
  store i64 %t93, ptr %l31, !tbaa !24
  br label %bb17
bb17:
  %t94 = load i64, ptr %l31, !tbaa !24
  store i64 %t94, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb18
bb18:
  %t95 = load i64, ptr %l6, !tbaa !24
  %t96 = load i64, ptr %l5, !tbaa !24
  %t99 = icmp slt i64 %t95, %t96
  %t101 = xor i1 %t99, true
  br i1 %t101, label %bb19, label %bb20
bb19:
  br label %bb23
bb20:
  br label %bb21
bb21:
  %t103 = load i64, ptr %l2, !tbaa !24
  %t104 = load i64, ptr %l6, !tbaa !24
  %t105 = load i64, ptr %l4, !tbaa !24
  %t108 = mul i64 %t104, %t105
  %t111 = add i64 %t103, %t108
  store i64 %t111, ptr %l7, !tbaa !24
  %t113 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t113, ptr %l52, !tbaa !27
  %t114 = load i64, ptr %l7, !tbaa !24
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t115, i32 0, i32 0
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t120 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t118, i32 0, i32 0
  %t121 = load { i64, ptr }, ptr %t120, !tbaa !27
  store { i64, ptr } %t121, ptr %l56, !tbaa !27
  %t122 = load i64, ptr %l7, !tbaa !24
  %t124 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr %"compiler/mir:Local", ptr %t125, i64 %t122
  %t127 = load %"compiler/mir:Local", ptr %t126
  %t130 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr %"compiler/mir:Local", ptr %t131, i64 %t114
  store %"compiler/mir:Local" %t127, ptr %t132
  br label %bb22
bb22:
  %t133 = load i64, ptr %l6, !tbaa !24
  %t135 = add i64 %t133, 1
  store i64 %t135, ptr %l6, !tbaa !24
  br label %bb18
bb23:
  %t137 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t137, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eToArra_H6fd2d5f022de1d6918789edb46830007(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l17 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca %"compiler/mir:ScopeInfo"
  %l31 = alloca i64
  %l34 = alloca i64
  %l52 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  %t48 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t4, i32 0, i32 1
  %t7 = load i64, ptr %t6, !tbaa !24
  %t9 = icmp eq i64 %t7, 0
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = icmp sge i64 0, 0
  br i1 %t11, label %bb3, label %bb4
bb2:
  br label %bb7
bb3:
  %t13 = icmp sle i64 0, 384307168202282325
  br i1 %t13, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_a6d1e1a34493fe12_f38c73d9643f1c0e)
  unreachable
bb5:
  %t15 = mul i64 0, 24
  %t16 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t15)
  %t17 = insertvalue { i64, ptr } undef, i64 0, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb6:
  call void @__olang_check_failed(ptr @olang_loc_a6d1e1a34493fe12_f38c73d9643f1c0e)
  unreachable
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t20, i32 0, i32 0
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t23, i32 0, i32 1
  %t26 = load i64, ptr %t25, !tbaa !24
  store i64 %t26, ptr %l17, !tbaa !24
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t27, i32 0, i32 0
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t30, i32 0, i32 0
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } %t33, ptr %l20, !tbaa !27
  %t34 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr %"compiler/mir:ScopeInfo", ptr %t35, i64 0
  %t37 = load %"compiler/mir:ScopeInfo", ptr %t36
  store %"compiler/mir:ScopeInfo" %t37, ptr %l21
  %t38 = load i64, ptr %l17, !tbaa !24
  %t39 = icmp sge i64 %t38, 0
  br i1 %t39, label %bb8, label %bb9
bb8:
  %t41 = load i64, ptr %l17, !tbaa !24
  %t42 = icmp sle i64 %t41, 384307168202282325
  br i1 %t42, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_79d50032057e0507_9eb82ad474053b03)
  unreachable
bb10:
  %t44 = load i64, ptr %l17, !tbaa !24
  %t45 = mul i64 %t44, 24
  %t46 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t45)
  %t47 = load %"compiler/mir:ScopeInfo", ptr %l21
  store i64 0, ptr %t48
  br label %fill.49
fill.49:
  %t52 = load i64, ptr %t48
  %t53 = icmp slt i64 %t52, %t44
  br i1 %t53, label %fillb.50, label %filld.51
fillb.50:
  %t54 = getelementptr %"compiler/mir:ScopeInfo", ptr %t46, i64 %t52
  store %"compiler/mir:ScopeInfo" %t47, ptr %t54
  %t55 = add i64 %t52, 1
  store i64 %t55, ptr %t48
  br label %fill.49
filld.51:
  %t56 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t46, 1
  store { i64, ptr } %t57, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t59, i32 0, i32 0
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t62, i32 0, i32 1
  %t65 = load i64, ptr %t64, !tbaa !24
  store i64 %t65, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t67 = load i64, ptr %l3, !tbaa !24
  %t68 = load i64, ptr %l2, !tbaa !24
  %t71 = icmp sgt i64 %t67, %t68
  br i1 %t71, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_79d50032057e0507_9eb82ad474053b03)
  unreachable
bb12:
  %t73 = load i64, ptr %l4, !tbaa !24
  %t75 = icmp sgt i64 %t73, 0
  br i1 %t75, label %bb14, label %bb15
bb13:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb17
bb14:
  %t77 = load i64, ptr %l3, !tbaa !24
  %t78 = load i64, ptr %l2, !tbaa !24
  %t81 = sub i64 %t77, %t78
  %t82 = load i64, ptr %l4, !tbaa !24
  %t85 = add i64 %t81, %t82
  %t87 = sub i64 %t85, 1
  %t88 = load i64, ptr %l4, !tbaa !24
  %t91 = sdiv i64 %t87, %t88
  store i64 %t91, ptr %l34, !tbaa !24
  br label %bb16
bb15:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb16
bb16:
  %t93 = load i64, ptr %l34, !tbaa !24
  store i64 %t93, ptr %l31, !tbaa !24
  br label %bb17
bb17:
  %t94 = load i64, ptr %l31, !tbaa !24
  store i64 %t94, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb18
bb18:
  %t95 = load i64, ptr %l6, !tbaa !24
  %t96 = load i64, ptr %l5, !tbaa !24
  %t99 = icmp slt i64 %t95, %t96
  %t101 = xor i1 %t99, true
  br i1 %t101, label %bb19, label %bb20
bb19:
  br label %bb23
bb20:
  br label %bb21
bb21:
  %t103 = load i64, ptr %l2, !tbaa !24
  %t104 = load i64, ptr %l6, !tbaa !24
  %t105 = load i64, ptr %l4, !tbaa !24
  %t108 = mul i64 %t104, %t105
  %t111 = add i64 %t103, %t108
  store i64 %t111, ptr %l7, !tbaa !24
  %t113 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t113, ptr %l52, !tbaa !27
  %t114 = load i64, ptr %l7, !tbaa !24
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t115, i32 0, i32 0
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t120 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t118, i32 0, i32 0
  %t121 = load { i64, ptr }, ptr %t120, !tbaa !27
  store { i64, ptr } %t121, ptr %l56, !tbaa !27
  %t122 = load i64, ptr %l7, !tbaa !24
  %t124 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr %"compiler/mir:ScopeInfo", ptr %t125, i64 %t122
  %t127 = load %"compiler/mir:ScopeInfo", ptr %t126
  %t130 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr %"compiler/mir:ScopeInfo", ptr %t131, i64 %t114
  store %"compiler/mir:ScopeInfo" %t127, ptr %t132
  br label %bb22
bb22:
  %t133 = load i64, ptr %l6, !tbaa !24
  %t135 = add i64 %t133, 1
  store i64 %t135, ptr %l6, !tbaa !24
  br label %bb18
bb23:
  %t137 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t137, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H1a77801a5ab3ea58cbf0ff15b43ff2de(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l4, !tbaa !27
  %t10 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba", ptr %t11, i64 %a1
  %t13 = load %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba", ptr %t12
  store %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba" %t13, ptr %rv
  br label %ret
ret:
  %rr = load %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba", ptr %rv
  ret %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba" %rr
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H2dfd829fbe4fa38977b46d00afbe1a06(ptr %v0, ptr %a0, %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba" %a1) #0 {
entry:
  %l1 = alloca %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba"
  %l2 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l21 = alloca ptr
  store %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t6, i32 0, i32 1
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t18 = icmp eq i64 %t9, %t15
  br i1 %t18, label %bb1, label %bb2
bb1:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 1
  %t24 = load i64, ptr %t23, !tbaa !24
  %t26 = add i64 %t24, 1
  %t27 = load %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba", ptr %l1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3cstd_2fpair_3aPair_3cI64_2c_20comp_Heeadfd6e9cedd063211d2349266ce026(ptr %v0, ptr %t20, i64 %t26, %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba" %t27)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t33 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t31, i32 0, i32 0
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  store { i64, ptr } %t34, ptr %l17, !tbaa !27
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t35, i32 0, i32 1
  %t38 = load i64, ptr %t37, !tbaa !24
  %t39 = load %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba", ptr %l1
  %t42 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba", ptr %t43, i64 %t38
  store %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba" %t39, ptr %t44
  %t45 = load ptr, ptr %l2, !tbaa !29
  store ptr %t45, ptr %l21, !tbaa !29
  %t46 = load ptr, ptr %l21, !tbaa !29
  %t47 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t46, i32 0, i32 1
  %t48 = load i64, ptr %t47, !tbaa !24
  %t50 = add i64 %t48, 1
  %t52 = load ptr, ptr %l21, !tbaa !29
  %t53 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t52, i32 0, i32 1
  store i64 %t50, ptr %t53, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H5ec116bb82f5a234bb19cb32db1efc81(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
  ret i64 %r
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2feval_3aBlob_3e_2eroom_3ccompiler_2feval_3aBlob_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/eval:Blob" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l21 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca i64
  %l40 = alloca %"compiler/eval:Blob"
  %l51 = alloca i64
  %l54 = alloca i64
  %l72 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %t71 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l21, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l21, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l21, !tbaa !24
  store i64 %t30, ptr %l3, !tbaa !24
  %t31 = load i64, ptr %l3, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l3, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l3, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l4, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l38, !tbaa !29
  %t59 = load i64, ptr %l3, !tbaa !24
  store i64 %t59, ptr %l39, !tbaa !24
  store %"compiler/eval:Blob" %a2, ptr %l40
  %t61 = load i64, ptr %l39, !tbaa !24
  %t62 = icmp sge i64 %t61, 0
  br i1 %t62, label %bb13, label %bb14
bb13:
  %t64 = load i64, ptr %l39, !tbaa !24
  %t65 = icmp sle i64 %t64, 115292150460684697
  br i1 %t65, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_8d3e4c03391d9d69_e18515306abca6f5)
  unreachable
bb15:
  %t67 = load i64, ptr %l39, !tbaa !24
  %t68 = mul i64 %t67, 80
  %t69 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t68)
  %t70 = load %"compiler/eval:Blob", ptr %l40
  store i64 0, ptr %t71
  br label %fill.72
fill.72:
  %t75 = load i64, ptr %t71
  %t76 = icmp slt i64 %t75, %t67
  br i1 %t76, label %fillb.73, label %filld.74
fillb.73:
  %t77 = getelementptr %"compiler/eval:Blob", ptr %t69, i64 %t75
  store %"compiler/eval:Blob" %t70, ptr %t77
  %t78 = add i64 %t75, 1
  store i64 %t78, ptr %t71
  br label %fill.72
filld.74:
  %t79 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t69, 1
  %t82 = load ptr, ptr %l38, !tbaa !29
  %t83 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t82, i32 0, i32 0
  store { i64, ptr } %t80, ptr %t83, !tbaa !27
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t84, i32 0, i32 0
  %t87 = load { i64, ptr }, ptr %t86, !tbaa !27
  store { i64, ptr } %t87, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t89, i32 0, i32 1
  %t92 = load i64, ptr %t91, !tbaa !24
  store i64 %t92, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t94 = load i64, ptr %l7, !tbaa !24
  %t95 = load i64, ptr %l6, !tbaa !24
  %t98 = icmp sgt i64 %t94, %t95
  br i1 %t98, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_8d3e4c03391d9d69_e18515306abca6f5)
  unreachable
bb17:
  %t100 = load i64, ptr %l8, !tbaa !24
  %t102 = icmp sgt i64 %t100, 0
  br i1 %t102, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb22
bb19:
  %t104 = load i64, ptr %l7, !tbaa !24
  %t105 = load i64, ptr %l6, !tbaa !24
  %t108 = sub i64 %t104, %t105
  %t109 = load i64, ptr %l8, !tbaa !24
  %t112 = add i64 %t108, %t109
  %t114 = sub i64 %t112, 1
  %t115 = load i64, ptr %l8, !tbaa !24
  %t118 = sdiv i64 %t114, %t115
  store i64 %t118, ptr %l54, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb21
bb21:
  %t120 = load i64, ptr %l54, !tbaa !24
  store i64 %t120, ptr %l51, !tbaa !24
  br label %bb22
bb22:
  %t121 = load i64, ptr %l51, !tbaa !24
  store i64 %t121, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb23
bb23:
  %t122 = load i64, ptr %l10, !tbaa !24
  %t123 = load i64, ptr %l9, !tbaa !24
  %t126 = icmp slt i64 %t122, %t123
  %t128 = xor i1 %t126, true
  br i1 %t128, label %bb24, label %bb25
bb24:
  br label %bb28
bb25:
  br label %bb26
bb26:
  %t130 = load i64, ptr %l6, !tbaa !24
  %t131 = load i64, ptr %l10, !tbaa !24
  %t132 = load i64, ptr %l8, !tbaa !24
  %t135 = mul i64 %t131, %t132
  %t138 = add i64 %t130, %t135
  store i64 %t138, ptr %l11, !tbaa !24
  %t140 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t140, ptr %l72, !tbaa !27
  %t141 = load i64, ptr %l11, !tbaa !24
  %t142 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t142, ptr %l74, !tbaa !27
  %t143 = load i64, ptr %l11, !tbaa !24
  %t145 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = getelementptr %"compiler/eval:Blob", ptr %t146, i64 %t143
  %t148 = load %"compiler/eval:Blob", ptr %t147
  %t151 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = getelementptr %"compiler/eval:Blob", ptr %t152, i64 %t141
  store %"compiler/eval:Blob" %t148, ptr %t153
  br label %bb27
bb27:
  %t154 = load i64, ptr %l10, !tbaa !24
  %t156 = add i64 %t154, 1
  store i64 %t156, ptr %l10, !tbaa !24
  br label %bb23
bb28:
  %t158 = load { i64, ptr }, ptr %l4, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2feval_3agenRec_3e_2eroom_3ccompiler_2feval_3agenRec_3e(ptr %v0, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/eval:genRec"
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l21 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca i64
  %l40 = alloca %"compiler/eval:genRec"
  %l51 = alloca i64
  %l54 = alloca i64
  %l72 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l76 = alloca %"compiler/eval:genRec"
  %t69 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  call void @llvm.memmove.p0.p0.i64(ptr %l2, ptr %a2, i64 168, i1 false)
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l21, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l21, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l21, !tbaa !24
  store i64 %t30, ptr %l3, !tbaa !24
  %t31 = load i64, ptr %l3, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l3, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l3, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l4, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l38, !tbaa !29
  %t59 = load i64, ptr %l3, !tbaa !24
  store i64 %t59, ptr %l39, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l40, ptr %l2, i64 168, i1 false)
  %t60 = load i64, ptr %l39, !tbaa !24
  %t61 = icmp sge i64 %t60, 0
  br i1 %t61, label %bb13, label %bb14
bb13:
  %t63 = load i64, ptr %l39, !tbaa !24
  %t64 = icmp sle i64 %t63, 54901024028897475
  br i1 %t64, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_cafc1179d98470af_ff4b2d5b532194fb)
  unreachable
bb15:
  %t66 = load i64, ptr %l39, !tbaa !24
  %t67 = mul i64 %t66, 168
  %t68 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t67)
  store i64 0, ptr %t69
  br label %fill.70
fill.70:
  %t73 = load i64, ptr %t69
  %t74 = icmp slt i64 %t73, %t66
  br i1 %t74, label %fillb.71, label %filld.72
fillb.71:
  %t75 = getelementptr %"compiler/eval:genRec", ptr %t68, i64 %t73
  call void @llvm.memmove.p0.p0.i64(ptr %t75, ptr %l40, i64 168, i1 false)
  %t76 = add i64 %t73, 1
  store i64 %t76, ptr %t69
  br label %fill.70
filld.72:
  %t77 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t68, 1
  %t80 = load ptr, ptr %l38, !tbaa !29
  %t81 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t80, i32 0, i32 0
  store { i64, ptr } %t78, ptr %t81, !tbaa !27
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t82, i32 0, i32 0
  %t85 = load { i64, ptr }, ptr %t84, !tbaa !27
  store { i64, ptr } %t85, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t87, i32 0, i32 1
  %t90 = load i64, ptr %t89, !tbaa !24
  store i64 %t90, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t92 = load i64, ptr %l7, !tbaa !24
  %t93 = load i64, ptr %l6, !tbaa !24
  %t96 = icmp sgt i64 %t92, %t93
  br i1 %t96, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_cafc1179d98470af_ff4b2d5b532194fb)
  unreachable
bb17:
  %t98 = load i64, ptr %l8, !tbaa !24
  %t100 = icmp sgt i64 %t98, 0
  br i1 %t100, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb22
bb19:
  %t102 = load i64, ptr %l7, !tbaa !24
  %t103 = load i64, ptr %l6, !tbaa !24
  %t106 = sub i64 %t102, %t103
  %t107 = load i64, ptr %l8, !tbaa !24
  %t110 = add i64 %t106, %t107
  %t112 = sub i64 %t110, 1
  %t113 = load i64, ptr %l8, !tbaa !24
  %t116 = sdiv i64 %t112, %t113
  store i64 %t116, ptr %l54, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb21
bb21:
  %t118 = load i64, ptr %l54, !tbaa !24
  store i64 %t118, ptr %l51, !tbaa !24
  br label %bb22
bb22:
  %t119 = load i64, ptr %l51, !tbaa !24
  store i64 %t119, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb23
bb23:
  %t120 = load i64, ptr %l10, !tbaa !24
  %t121 = load i64, ptr %l9, !tbaa !24
  %t124 = icmp slt i64 %t120, %t121
  %t126 = xor i1 %t124, true
  br i1 %t126, label %bb24, label %bb25
bb24:
  br label %bb28
bb25:
  br label %bb26
bb26:
  %t128 = load i64, ptr %l6, !tbaa !24
  %t129 = load i64, ptr %l10, !tbaa !24
  %t130 = load i64, ptr %l8, !tbaa !24
  %t133 = mul i64 %t129, %t130
  %t136 = add i64 %t128, %t133
  store i64 %t136, ptr %l11, !tbaa !24
  %t138 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t138, ptr %l72, !tbaa !27
  %t139 = load i64, ptr %l11, !tbaa !24
  %t140 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t140, ptr %l74, !tbaa !27
  %t141 = load i64, ptr %l11, !tbaa !24
  %t143 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !27
  %t145 = getelementptr %"compiler/eval:genRec", ptr %t144, i64 %t141
  call void @llvm.memmove.p0.p0.i64(ptr %l76, ptr %t145, i64 168, i1 false)
  %t147 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t148 = load ptr, ptr %t147, !tbaa !27
  %t149 = getelementptr %"compiler/eval:genRec", ptr %t148, i64 %t139
  call void @llvm.memmove.p0.p0.i64(ptr %t149, ptr %l76, i64 168, i1 false)
  br label %bb27
bb27:
  %t150 = load i64, ptr %l10, !tbaa !24
  %t152 = add i64 %t150, 1
  store i64 %t152, ptr %l10, !tbaa !24
  br label %bb23
bb28:
  %t154 = load { i64, ptr }, ptr %l4, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2feval_3aglobal_3e_2eroom_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %a0, i64 %a1, %"compiler/eval:global" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l21 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca i64
  %l40 = alloca %"compiler/eval:global"
  %l51 = alloca i64
  %l54 = alloca i64
  %l72 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %t71 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l21, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l21, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l21, !tbaa !24
  store i64 %t30, ptr %l3, !tbaa !24
  %t31 = load i64, ptr %l3, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l3, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l3, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l4, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l38, !tbaa !29
  %t59 = load i64, ptr %l3, !tbaa !24
  store i64 %t59, ptr %l39, !tbaa !24
  store %"compiler/eval:global" %a2, ptr %l40
  %t61 = load i64, ptr %l39, !tbaa !24
  %t62 = icmp sge i64 %t61, 0
  br i1 %t62, label %bb13, label %bb14
bb13:
  %t64 = load i64, ptr %l39, !tbaa !24
  %t65 = icmp sle i64 %t64, 192153584101141162
  br i1 %t65, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_be239a5bd3d67051_98f25215818627ed)
  unreachable
bb15:
  %t67 = load i64, ptr %l39, !tbaa !24
  %t68 = mul i64 %t67, 48
  %t69 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t68)
  %t70 = load %"compiler/eval:global", ptr %l40
  store i64 0, ptr %t71
  br label %fill.72
fill.72:
  %t75 = load i64, ptr %t71
  %t76 = icmp slt i64 %t75, %t67
  br i1 %t76, label %fillb.73, label %filld.74
fillb.73:
  %t77 = getelementptr %"compiler/eval:global", ptr %t69, i64 %t75
  store %"compiler/eval:global" %t70, ptr %t77
  %t78 = add i64 %t75, 1
  store i64 %t78, ptr %t71
  br label %fill.72
filld.74:
  %t79 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t69, 1
  %t82 = load ptr, ptr %l38, !tbaa !29
  %t83 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t82, i32 0, i32 0
  store { i64, ptr } %t80, ptr %t83, !tbaa !27
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t84, i32 0, i32 0
  %t87 = load { i64, ptr }, ptr %t86, !tbaa !27
  store { i64, ptr } %t87, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t89, i32 0, i32 1
  %t92 = load i64, ptr %t91, !tbaa !24
  store i64 %t92, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t94 = load i64, ptr %l7, !tbaa !24
  %t95 = load i64, ptr %l6, !tbaa !24
  %t98 = icmp sgt i64 %t94, %t95
  br i1 %t98, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_be239a5bd3d67051_98f25215818627ed)
  unreachable
bb17:
  %t100 = load i64, ptr %l8, !tbaa !24
  %t102 = icmp sgt i64 %t100, 0
  br i1 %t102, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb22
bb19:
  %t104 = load i64, ptr %l7, !tbaa !24
  %t105 = load i64, ptr %l6, !tbaa !24
  %t108 = sub i64 %t104, %t105
  %t109 = load i64, ptr %l8, !tbaa !24
  %t112 = add i64 %t108, %t109
  %t114 = sub i64 %t112, 1
  %t115 = load i64, ptr %l8, !tbaa !24
  %t118 = sdiv i64 %t114, %t115
  store i64 %t118, ptr %l54, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb21
bb21:
  %t120 = load i64, ptr %l54, !tbaa !24
  store i64 %t120, ptr %l51, !tbaa !24
  br label %bb22
bb22:
  %t121 = load i64, ptr %l51, !tbaa !24
  store i64 %t121, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb23
bb23:
  %t122 = load i64, ptr %l10, !tbaa !24
  %t123 = load i64, ptr %l9, !tbaa !24
  %t126 = icmp slt i64 %t122, %t123
  %t128 = xor i1 %t126, true
  br i1 %t128, label %bb24, label %bb25
bb24:
  br label %bb28
bb25:
  br label %bb26
bb26:
  %t130 = load i64, ptr %l6, !tbaa !24
  %t131 = load i64, ptr %l10, !tbaa !24
  %t132 = load i64, ptr %l8, !tbaa !24
  %t135 = mul i64 %t131, %t132
  %t138 = add i64 %t130, %t135
  store i64 %t138, ptr %l11, !tbaa !24
  %t140 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t140, ptr %l72, !tbaa !27
  %t141 = load i64, ptr %l11, !tbaa !24
  %t142 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t142, ptr %l74, !tbaa !27
  %t143 = load i64, ptr %l11, !tbaa !24
  %t145 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = getelementptr %"compiler/eval:global", ptr %t146, i64 %t143
  %t148 = load %"compiler/eval:global", ptr %t147
  %t151 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = getelementptr %"compiler/eval:global", ptr %t152, i64 %t141
  store %"compiler/eval:global" %t148, ptr %t153
  br label %bb27
bb27:
  %t154 = load i64, ptr %l10, !tbaa !24
  %t156 = add i64 %t154, 1
  store i64 %t156, ptr %l10, !tbaa !24
  br label %bb23
bb28:
  %t158 = load { i64, ptr }, ptr %l4, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2feval_3areg_3e_2eroom_3ccompiler_2feval_3areg_3e(ptr %v0, ptr %a0, i64 %a1, %"compiler/eval:reg" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l21 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca i64
  %l40 = alloca %"compiler/eval:reg"
  %l51 = alloca i64
  %l54 = alloca i64
  %l72 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %t71 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l21, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l21, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l21, !tbaa !24
  store i64 %t30, ptr %l3, !tbaa !24
  %t31 = load i64, ptr %l3, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l3, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l3, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l4, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l38, !tbaa !29
  %t59 = load i64, ptr %l3, !tbaa !24
  store i64 %t59, ptr %l39, !tbaa !24
  store %"compiler/eval:reg" %a2, ptr %l40
  %t61 = load i64, ptr %l39, !tbaa !24
  %t62 = icmp sge i64 %t61, 0
  br i1 %t62, label %bb13, label %bb14
bb13:
  %t64 = load i64, ptr %l39, !tbaa !24
  %t65 = icmp sle i64 %t64, 144115188075855871
  br i1 %t65, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_96e2a7e501496caf_9ddc065efece6e7b)
  unreachable
bb15:
  %t67 = load i64, ptr %l39, !tbaa !24
  %t68 = mul i64 %t67, 64
  %t69 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t68)
  %t70 = load %"compiler/eval:reg", ptr %l40
  store i64 0, ptr %t71
  br label %fill.72
fill.72:
  %t75 = load i64, ptr %t71
  %t76 = icmp slt i64 %t75, %t67
  br i1 %t76, label %fillb.73, label %filld.74
fillb.73:
  %t77 = getelementptr %"compiler/eval:reg", ptr %t69, i64 %t75
  store %"compiler/eval:reg" %t70, ptr %t77
  %t78 = add i64 %t75, 1
  store i64 %t78, ptr %t71
  br label %fill.72
filld.74:
  %t79 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t69, 1
  %t82 = load ptr, ptr %l38, !tbaa !29
  %t83 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t82, i32 0, i32 0
  store { i64, ptr } %t80, ptr %t83, !tbaa !27
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t84, i32 0, i32 0
  %t87 = load { i64, ptr }, ptr %t86, !tbaa !27
  store { i64, ptr } %t87, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t89, i32 0, i32 1
  %t92 = load i64, ptr %t91, !tbaa !24
  store i64 %t92, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t94 = load i64, ptr %l7, !tbaa !24
  %t95 = load i64, ptr %l6, !tbaa !24
  %t98 = icmp sgt i64 %t94, %t95
  br i1 %t98, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_96e2a7e501496caf_9ddc065efece6e7b)
  unreachable
bb17:
  %t100 = load i64, ptr %l8, !tbaa !24
  %t102 = icmp sgt i64 %t100, 0
  br i1 %t102, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb22
bb19:
  %t104 = load i64, ptr %l7, !tbaa !24
  %t105 = load i64, ptr %l6, !tbaa !24
  %t108 = sub i64 %t104, %t105
  %t109 = load i64, ptr %l8, !tbaa !24
  %t112 = add i64 %t108, %t109
  %t114 = sub i64 %t112, 1
  %t115 = load i64, ptr %l8, !tbaa !24
  %t118 = sdiv i64 %t114, %t115
  store i64 %t118, ptr %l54, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb21
bb21:
  %t120 = load i64, ptr %l54, !tbaa !24
  store i64 %t120, ptr %l51, !tbaa !24
  br label %bb22
bb22:
  %t121 = load i64, ptr %l51, !tbaa !24
  store i64 %t121, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb23
bb23:
  %t122 = load i64, ptr %l10, !tbaa !24
  %t123 = load i64, ptr %l9, !tbaa !24
  %t126 = icmp slt i64 %t122, %t123
  %t128 = xor i1 %t126, true
  br i1 %t128, label %bb24, label %bb25
bb24:
  br label %bb28
bb25:
  br label %bb26
bb26:
  %t130 = load i64, ptr %l6, !tbaa !24
  %t131 = load i64, ptr %l10, !tbaa !24
  %t132 = load i64, ptr %l8, !tbaa !24
  %t135 = mul i64 %t131, %t132
  %t138 = add i64 %t130, %t135
  store i64 %t138, ptr %l11, !tbaa !24
  %t140 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t140, ptr %l72, !tbaa !27
  %t141 = load i64, ptr %l11, !tbaa !24
  %t142 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t142, ptr %l74, !tbaa !27
  %t143 = load i64, ptr %l11, !tbaa !24
  %t145 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = getelementptr %"compiler/eval:reg", ptr %t146, i64 %t143
  %t148 = load %"compiler/eval:reg", ptr %t147
  %t151 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = getelementptr %"compiler/eval:reg", ptr %t152, i64 %t141
  store %"compiler/eval:reg" %t148, ptr %t153
  br label %bb27
bb27:
  %t154 = load i64, ptr %l10, !tbaa !24
  %t156 = add i64 %t154, 1
  store i64 %t156, ptr %l10, !tbaa !24
  br label %bb23
bb28:
  %t158 = load { i64, ptr }, ptr %l4, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2feval_3ascope_3e_2eroom_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/eval:scope"
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l21 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca i64
  %l40 = alloca %"compiler/eval:scope"
  %l51 = alloca i64
  %l54 = alloca i64
  %l72 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l76 = alloca %"compiler/eval:scope"
  %t69 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  call void @llvm.memmove.p0.p0.i64(ptr %l2, ptr %a2, i64 136, i1 false)
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l21, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l21, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l21, !tbaa !24
  store i64 %t30, ptr %l3, !tbaa !24
  %t31 = load i64, ptr %l3, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l3, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l3, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l4, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l38, !tbaa !29
  %t59 = load i64, ptr %l3, !tbaa !24
  store i64 %t59, ptr %l39, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l40, ptr %l2, i64 136, i1 false)
  %t60 = load i64, ptr %l39, !tbaa !24
  %t61 = icmp sge i64 %t60, 0
  br i1 %t61, label %bb13, label %bb14
bb13:
  %t63 = load i64, ptr %l39, !tbaa !24
  %t64 = icmp sle i64 %t63, 67818912035696880
  br i1 %t64, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_90e22ecdf487f4f3_638b220c7e5f1e6f)
  unreachable
bb15:
  %t66 = load i64, ptr %l39, !tbaa !24
  %t67 = mul i64 %t66, 136
  %t68 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t67)
  store i64 0, ptr %t69
  br label %fill.70
fill.70:
  %t73 = load i64, ptr %t69
  %t74 = icmp slt i64 %t73, %t66
  br i1 %t74, label %fillb.71, label %filld.72
fillb.71:
  %t75 = getelementptr %"compiler/eval:scope", ptr %t68, i64 %t73
  call void @llvm.memmove.p0.p0.i64(ptr %t75, ptr %l40, i64 136, i1 false)
  %t76 = add i64 %t73, 1
  store i64 %t76, ptr %t69
  br label %fill.70
filld.72:
  %t77 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t68, 1
  %t80 = load ptr, ptr %l38, !tbaa !29
  %t81 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t80, i32 0, i32 0
  store { i64, ptr } %t78, ptr %t81, !tbaa !27
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t82, i32 0, i32 0
  %t85 = load { i64, ptr }, ptr %t84, !tbaa !27
  store { i64, ptr } %t85, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t87, i32 0, i32 1
  %t90 = load i64, ptr %t89, !tbaa !24
  store i64 %t90, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t92 = load i64, ptr %l7, !tbaa !24
  %t93 = load i64, ptr %l6, !tbaa !24
  %t96 = icmp sgt i64 %t92, %t93
  br i1 %t96, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_90e22ecdf487f4f3_638b220c7e5f1e6f)
  unreachable
bb17:
  %t98 = load i64, ptr %l8, !tbaa !24
  %t100 = icmp sgt i64 %t98, 0
  br i1 %t100, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb22
bb19:
  %t102 = load i64, ptr %l7, !tbaa !24
  %t103 = load i64, ptr %l6, !tbaa !24
  %t106 = sub i64 %t102, %t103
  %t107 = load i64, ptr %l8, !tbaa !24
  %t110 = add i64 %t106, %t107
  %t112 = sub i64 %t110, 1
  %t113 = load i64, ptr %l8, !tbaa !24
  %t116 = sdiv i64 %t112, %t113
  store i64 %t116, ptr %l54, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb21
bb21:
  %t118 = load i64, ptr %l54, !tbaa !24
  store i64 %t118, ptr %l51, !tbaa !24
  br label %bb22
bb22:
  %t119 = load i64, ptr %l51, !tbaa !24
  store i64 %t119, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb23
bb23:
  %t120 = load i64, ptr %l10, !tbaa !24
  %t121 = load i64, ptr %l9, !tbaa !24
  %t124 = icmp slt i64 %t120, %t121
  %t126 = xor i1 %t124, true
  br i1 %t126, label %bb24, label %bb25
bb24:
  br label %bb28
bb25:
  br label %bb26
bb26:
  %t128 = load i64, ptr %l6, !tbaa !24
  %t129 = load i64, ptr %l10, !tbaa !24
  %t130 = load i64, ptr %l8, !tbaa !24
  %t133 = mul i64 %t129, %t130
  %t136 = add i64 %t128, %t133
  store i64 %t136, ptr %l11, !tbaa !24
  %t138 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t138, ptr %l72, !tbaa !27
  %t139 = load i64, ptr %l11, !tbaa !24
  %t140 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t140, ptr %l74, !tbaa !27
  %t141 = load i64, ptr %l11, !tbaa !24
  %t143 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !27
  %t145 = getelementptr %"compiler/eval:scope", ptr %t144, i64 %t141
  call void @llvm.memmove.p0.p0.i64(ptr %l76, ptr %t145, i64 136, i1 false)
  %t147 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t148 = load ptr, ptr %t147, !tbaa !27
  %t149 = getelementptr %"compiler/eval:scope", ptr %t148, i64 %t139
  call void @llvm.memmove.p0.p0.i64(ptr %t149, ptr %l76, i64 136, i1 false)
  br label %bb27
bb27:
  %t150 = load i64, ptr %l10, !tbaa !24
  %t152 = add i64 %t150, 1
  store i64 %t152, ptr %l10, !tbaa !24
  br label %bb23
bb28:
  %t154 = load { i64, ptr }, ptr %l4, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2feval_3atask_3e_2eroom_3ccompiler_2feval_3atask_3e(ptr %v0, ptr %a0, i64 %a1, %"compiler/eval:task" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l21 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca i64
  %l40 = alloca %"compiler/eval:task"
  %l51 = alloca i64
  %l54 = alloca i64
  %l72 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %t71 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l21, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l21, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l21, !tbaa !24
  store i64 %t30, ptr %l3, !tbaa !24
  %t31 = load i64, ptr %l3, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l3, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l3, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l4, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l38, !tbaa !29
  %t59 = load i64, ptr %l3, !tbaa !24
  store i64 %t59, ptr %l39, !tbaa !24
  store %"compiler/eval:task" %a2, ptr %l40
  %t61 = load i64, ptr %l39, !tbaa !24
  %t62 = icmp sge i64 %t61, 0
  br i1 %t62, label %bb13, label %bb14
bb13:
  %t64 = load i64, ptr %l39, !tbaa !24
  %t65 = icmp sle i64 %t64, 288230376151711743
  br i1 %t65, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_77c41571e394d1c5_a26b081ff08a1d01)
  unreachable
bb15:
  %t67 = load i64, ptr %l39, !tbaa !24
  %t68 = mul i64 %t67, 32
  %t69 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t68)
  %t70 = load %"compiler/eval:task", ptr %l40
  store i64 0, ptr %t71
  br label %fill.72
fill.72:
  %t75 = load i64, ptr %t71
  %t76 = icmp slt i64 %t75, %t67
  br i1 %t76, label %fillb.73, label %filld.74
fillb.73:
  %t77 = getelementptr %"compiler/eval:task", ptr %t69, i64 %t75
  store %"compiler/eval:task" %t70, ptr %t77
  %t78 = add i64 %t75, 1
  store i64 %t78, ptr %t71
  br label %fill.72
filld.74:
  %t79 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t69, 1
  %t82 = load ptr, ptr %l38, !tbaa !29
  %t83 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t82, i32 0, i32 0
  store { i64, ptr } %t80, ptr %t83, !tbaa !27
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t84, i32 0, i32 0
  %t87 = load { i64, ptr }, ptr %t86, !tbaa !27
  store { i64, ptr } %t87, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t89, i32 0, i32 1
  %t92 = load i64, ptr %t91, !tbaa !24
  store i64 %t92, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t94 = load i64, ptr %l7, !tbaa !24
  %t95 = load i64, ptr %l6, !tbaa !24
  %t98 = icmp sgt i64 %t94, %t95
  br i1 %t98, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_77c41571e394d1c5_a26b081ff08a1d01)
  unreachable
bb17:
  %t100 = load i64, ptr %l8, !tbaa !24
  %t102 = icmp sgt i64 %t100, 0
  br i1 %t102, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb22
bb19:
  %t104 = load i64, ptr %l7, !tbaa !24
  %t105 = load i64, ptr %l6, !tbaa !24
  %t108 = sub i64 %t104, %t105
  %t109 = load i64, ptr %l8, !tbaa !24
  %t112 = add i64 %t108, %t109
  %t114 = sub i64 %t112, 1
  %t115 = load i64, ptr %l8, !tbaa !24
  %t118 = sdiv i64 %t114, %t115
  store i64 %t118, ptr %l54, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb21
bb21:
  %t120 = load i64, ptr %l54, !tbaa !24
  store i64 %t120, ptr %l51, !tbaa !24
  br label %bb22
bb22:
  %t121 = load i64, ptr %l51, !tbaa !24
  store i64 %t121, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb23
bb23:
  %t122 = load i64, ptr %l10, !tbaa !24
  %t123 = load i64, ptr %l9, !tbaa !24
  %t126 = icmp slt i64 %t122, %t123
  %t128 = xor i1 %t126, true
  br i1 %t128, label %bb24, label %bb25
bb24:
  br label %bb28
bb25:
  br label %bb26
bb26:
  %t130 = load i64, ptr %l6, !tbaa !24
  %t131 = load i64, ptr %l10, !tbaa !24
  %t132 = load i64, ptr %l8, !tbaa !24
  %t135 = mul i64 %t131, %t132
  %t138 = add i64 %t130, %t135
  store i64 %t138, ptr %l11, !tbaa !24
  %t140 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t140, ptr %l72, !tbaa !27
  %t141 = load i64, ptr %l11, !tbaa !24
  %t142 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t142, ptr %l74, !tbaa !27
  %t143 = load i64, ptr %l11, !tbaa !24
  %t145 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = getelementptr %"compiler/eval:task", ptr %t146, i64 %t143
  %t148 = load %"compiler/eval:task", ptr %t147
  %t151 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = getelementptr %"compiler/eval:task", ptr %t152, i64 %t141
  store %"compiler/eval:task" %t148, ptr %t153
  br label %bb27
bb27:
  %t154 = load i64, ptr %l10, !tbaa !24
  %t156 = add i64 %t154, 1
  store i64 %t156, ptr %l10, !tbaa !24
  br label %bb23
bb28:
  %t158 = load { i64, ptr }, ptr %l4, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2fmir_3aFn_3e_2eroom_3ccompiler_2fmir_3aFn_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/mir:Fn"
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l21 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca i64
  %l40 = alloca %"compiler/mir:Fn"
  %l51 = alloca i64
  %l54 = alloca i64
  %l72 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l76 = alloca %"compiler/mir:Fn"
  %t69 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  call void @llvm.memmove.p0.p0.i64(ptr %l2, ptr %a2, i64 232, i1 false)
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l21, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l21, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l21, !tbaa !24
  store i64 %t30, ptr %l3, !tbaa !24
  %t31 = load i64, ptr %l3, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l3, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l3, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l4, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l38, !tbaa !29
  %t59 = load i64, ptr %l3, !tbaa !24
  store i64 %t59, ptr %l39, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l40, ptr %l2, i64 232, i1 false)
  %t60 = load i64, ptr %l39, !tbaa !24
  %t61 = icmp sge i64 %t60, 0
  br i1 %t61, label %bb13, label %bb14
bb13:
  %t63 = load i64, ptr %l39, !tbaa !24
  %t64 = icmp sle i64 %t63, 39755913951960240
  br i1 %t64, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_9a2d0205b5782b4f_6eed86a41e6bc3ab)
  unreachable
bb15:
  %t66 = load i64, ptr %l39, !tbaa !24
  %t67 = mul i64 %t66, 232
  %t68 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t67)
  store i64 0, ptr %t69
  br label %fill.70
fill.70:
  %t73 = load i64, ptr %t69
  %t74 = icmp slt i64 %t73, %t66
  br i1 %t74, label %fillb.71, label %filld.72
fillb.71:
  %t75 = getelementptr %"compiler/mir:Fn", ptr %t68, i64 %t73
  call void @llvm.memmove.p0.p0.i64(ptr %t75, ptr %l40, i64 232, i1 false)
  %t76 = add i64 %t73, 1
  store i64 %t76, ptr %t69
  br label %fill.70
filld.72:
  %t77 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t68, 1
  %t80 = load ptr, ptr %l38, !tbaa !29
  %t81 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t80, i32 0, i32 0
  store { i64, ptr } %t78, ptr %t81, !tbaa !27
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t82, i32 0, i32 0
  %t85 = load { i64, ptr }, ptr %t84, !tbaa !27
  store { i64, ptr } %t85, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t87, i32 0, i32 1
  %t90 = load i64, ptr %t89, !tbaa !24
  store i64 %t90, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t92 = load i64, ptr %l7, !tbaa !24
  %t93 = load i64, ptr %l6, !tbaa !24
  %t96 = icmp sgt i64 %t92, %t93
  br i1 %t96, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_9a2d0205b5782b4f_6eed86a41e6bc3ab)
  unreachable
bb17:
  %t98 = load i64, ptr %l8, !tbaa !24
  %t100 = icmp sgt i64 %t98, 0
  br i1 %t100, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb22
bb19:
  %t102 = load i64, ptr %l7, !tbaa !24
  %t103 = load i64, ptr %l6, !tbaa !24
  %t106 = sub i64 %t102, %t103
  %t107 = load i64, ptr %l8, !tbaa !24
  %t110 = add i64 %t106, %t107
  %t112 = sub i64 %t110, 1
  %t113 = load i64, ptr %l8, !tbaa !24
  %t116 = sdiv i64 %t112, %t113
  store i64 %t116, ptr %l54, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb21
bb21:
  %t118 = load i64, ptr %l54, !tbaa !24
  store i64 %t118, ptr %l51, !tbaa !24
  br label %bb22
bb22:
  %t119 = load i64, ptr %l51, !tbaa !24
  store i64 %t119, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb23
bb23:
  %t120 = load i64, ptr %l10, !tbaa !24
  %t121 = load i64, ptr %l9, !tbaa !24
  %t124 = icmp slt i64 %t120, %t121
  %t126 = xor i1 %t124, true
  br i1 %t126, label %bb24, label %bb25
bb24:
  br label %bb28
bb25:
  br label %bb26
bb26:
  %t128 = load i64, ptr %l6, !tbaa !24
  %t129 = load i64, ptr %l10, !tbaa !24
  %t130 = load i64, ptr %l8, !tbaa !24
  %t133 = mul i64 %t129, %t130
  %t136 = add i64 %t128, %t133
  store i64 %t136, ptr %l11, !tbaa !24
  %t138 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t138, ptr %l72, !tbaa !27
  %t139 = load i64, ptr %l11, !tbaa !24
  %t140 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t140, ptr %l74, !tbaa !27
  %t141 = load i64, ptr %l11, !tbaa !24
  %t143 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !27
  %t145 = getelementptr %"compiler/mir:Fn", ptr %t144, i64 %t141
  call void @llvm.memmove.p0.p0.i64(ptr %l76, ptr %t145, i64 232, i1 false)
  %t147 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t148 = load ptr, ptr %t147, !tbaa !27
  %t149 = getelementptr %"compiler/mir:Fn", ptr %t148, i64 %t139
  call void @llvm.memmove.p0.p0.i64(ptr %t149, ptr %l76, i64 232, i1 false)
  br label %bb27
bb27:
  %t150 = load i64, ptr %l10, !tbaa !24
  %t152 = add i64 %t150, 1
  store i64 %t152, ptr %l10, !tbaa !24
  br label %bb23
bb28:
  %t154 = load { i64, ptr }, ptr %l4, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3cstd_2fpair_3aPair_3cI64_2c_20comp_Heeadfd6e9cedd063211d2349266ce026(ptr %v0, ptr %a0, i64 %a1, %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l21 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca i64
  %l40 = alloca %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba"
  %l51 = alloca i64
  %l54 = alloca i64
  %l72 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %t71 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l21, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l21, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l21, !tbaa !24
  store i64 %t30, ptr %l3, !tbaa !24
  %t31 = load i64, ptr %l3, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l3, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l3, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l4, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l38, !tbaa !29
  %t59 = load i64, ptr %l3, !tbaa !24
  store i64 %t59, ptr %l39, !tbaa !24
  store %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba" %a2, ptr %l40
  %t61 = load i64, ptr %l39, !tbaa !24
  %t62 = icmp sge i64 %t61, 0
  br i1 %t62, label %bb13, label %bb14
bb13:
  %t64 = load i64, ptr %l39, !tbaa !24
  %t65 = icmp sle i64 %t64, 576460752303423487
  br i1 %t65, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_f86a0809d810f51b_b7bc0d1c42251c1f)
  unreachable
bb15:
  %t67 = load i64, ptr %l39, !tbaa !24
  %t68 = mul i64 %t67, 16
  %t69 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t68)
  %t70 = load %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba", ptr %l40
  store i64 0, ptr %t71
  br label %fill.72
fill.72:
  %t75 = load i64, ptr %t71
  %t76 = icmp slt i64 %t75, %t67
  br i1 %t76, label %fillb.73, label %filld.74
fillb.73:
  %t77 = getelementptr %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba", ptr %t69, i64 %t75
  store %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba" %t70, ptr %t77
  %t78 = add i64 %t75, 1
  store i64 %t78, ptr %t71
  br label %fill.72
filld.74:
  %t79 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t69, 1
  %t82 = load ptr, ptr %l38, !tbaa !29
  %t83 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t82, i32 0, i32 0
  store { i64, ptr } %t80, ptr %t83, !tbaa !27
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t84, i32 0, i32 0
  %t87 = load { i64, ptr }, ptr %t86, !tbaa !27
  store { i64, ptr } %t87, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t89, i32 0, i32 1
  %t92 = load i64, ptr %t91, !tbaa !24
  store i64 %t92, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t94 = load i64, ptr %l7, !tbaa !24
  %t95 = load i64, ptr %l6, !tbaa !24
  %t98 = icmp sgt i64 %t94, %t95
  br i1 %t98, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_f86a0809d810f51b_b7bc0d1c42251c1f)
  unreachable
bb17:
  %t100 = load i64, ptr %l8, !tbaa !24
  %t102 = icmp sgt i64 %t100, 0
  br i1 %t102, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb22
bb19:
  %t104 = load i64, ptr %l7, !tbaa !24
  %t105 = load i64, ptr %l6, !tbaa !24
  %t108 = sub i64 %t104, %t105
  %t109 = load i64, ptr %l8, !tbaa !24
  %t112 = add i64 %t108, %t109
  %t114 = sub i64 %t112, 1
  %t115 = load i64, ptr %l8, !tbaa !24
  %t118 = sdiv i64 %t114, %t115
  store i64 %t118, ptr %l54, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb21
bb21:
  %t120 = load i64, ptr %l54, !tbaa !24
  store i64 %t120, ptr %l51, !tbaa !24
  br label %bb22
bb22:
  %t121 = load i64, ptr %l51, !tbaa !24
  store i64 %t121, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb23
bb23:
  %t122 = load i64, ptr %l10, !tbaa !24
  %t123 = load i64, ptr %l9, !tbaa !24
  %t126 = icmp slt i64 %t122, %t123
  %t128 = xor i1 %t126, true
  br i1 %t128, label %bb24, label %bb25
bb24:
  br label %bb28
bb25:
  br label %bb26
bb26:
  %t130 = load i64, ptr %l6, !tbaa !24
  %t131 = load i64, ptr %l10, !tbaa !24
  %t132 = load i64, ptr %l8, !tbaa !24
  %t135 = mul i64 %t131, %t132
  %t138 = add i64 %t130, %t135
  store i64 %t138, ptr %l11, !tbaa !24
  %t140 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t140, ptr %l72, !tbaa !27
  %t141 = load i64, ptr %l11, !tbaa !24
  %t142 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t142, ptr %l74, !tbaa !27
  %t143 = load i64, ptr %l11, !tbaa !24
  %t145 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = getelementptr %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba", ptr %t146, i64 %t143
  %t148 = load %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba", ptr %t147
  %t151 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = getelementptr %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba", ptr %t152, i64 %t141
  store %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba" %t148, ptr %t153
  br label %bb27
bb27:
  %t154 = load i64, ptr %l10, !tbaa !24
  %t156 = add i64 %t154, 1
  store i64 %t156, ptr %l10, !tbaa !24
  br label %bb23
bb28:
  %t158 = load { i64, ptr }, ptr %l4, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aBlob_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aConstAsk_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2feval_3agenRec_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %l3 = alloca %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2feval_3agenRec_3e_2ector(ptr %v0, i64 %a0)
  store %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t5 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %t5
  %t8 = insertvalue %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" undef, ptr %t5, 0
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3aSaid_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2feval_3areg_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aContractAsk_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2feval_3atask_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aGap_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %l3 = alloca %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fmir_3aFn_3e_2ector(ptr %v0, i64 %a0)
  store %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t5 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %t5
  %t8 = insertvalue %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" undef, ptr %t5, 0
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler_2fsource_3aSpan_3e_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2feval_3aBlob_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fgeneric_3aConstAsk_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %r
}

define dso_local %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2feval_3agenRec_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %rv = alloca %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = icmp sge i64 0, 0
  br i1 %t1, label %bb1, label %bb2
bb1:
  %t3 = icmp sle i64 0, 54901024028897475
  br i1 %t3, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_9c71bec70403bcd3_93d6e20d21b9fd07)
  unreachable
bb3:
  %t5 = mul i64 0, 168
  %t6 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t5)
  %t7 = insertvalue { i64, ptr } undef, i64 0, 0
  %t8 = insertvalue { i64, ptr } %t7, ptr %t6, 1
  %t13 = insertvalue %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" undef, { i64, ptr } %t8, 0
  %t15 = insertvalue %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %t13, i64 0, 1
  %t17 = insertvalue %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %t15, i64 %a0, 2
  store %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %t17, ptr %rv
  br label %ret
bb4:
  call void @__olang_check_failed(ptr @olang_loc_9c71bec70403bcd3_93d6e20d21b9fd07)
  unreachable
ret:
  %rr = load %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2feval_3aglobal_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fdiag_3aSaid_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %r
}

define dso_local %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2feval_3areg_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fload_3aImport_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %r
}

define dso_local %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2feval_3ascope_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fcheck_3aContractAsk_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %r
}

define dso_local %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2feval_3atask_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fscope_3aGap_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %r
}

define dso_local %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fmir_3aFn_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %rv = alloca %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = icmp sge i64 0, 0
  br i1 %t1, label %bb1, label %bb2
bb1:
  %t3 = icmp sle i64 0, 39755913951960240
  br i1 %t3, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_136ccb8e95b23ba9_d27b970572ac08f5)
  unreachable
bb3:
  %t5 = mul i64 0, 232
  %t6 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t5)
  %t7 = insertvalue { i64, ptr } undef, i64 0, 0
  %t8 = insertvalue { i64, ptr } %t7, ptr %t6, 1
  %t13 = insertvalue %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" undef, { i64, ptr } %t8, 0
  %t15 = insertvalue %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %t13, i64 0, 1
  %t17 = insertvalue %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %t15, i64 %a0, 2
  store %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %t17, ptr %rv
  br label %ret
bb4:
  call void @__olang_check_failed(ptr @olang_loc_136ccb8e95b23ba9_d27b970572ac08f5)
  unreachable
ret:
  %rr = load %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3cstd_2fpair_3aPair_3cI64_2c_20compiler_2fsource_3aSpan_3e_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %r
}

define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2feval_3adkey(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = getelementptr %"compiler/eval:dkey", ptr %t1, i32 0, i32 0
  %t3 = load i64, ptr %t2, !tbaa !24
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"compiler/eval:dkey", ptr %t4, i32 0, i32 0
  %t6 = load i64, ptr %t5, !tbaa !24
  %t9 = icmp eq i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb8
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/eval:dkey", ptr %t11, i32 0, i32 1
  %t13 = load i32, ptr %t12, !tbaa !23
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"compiler/eval:dkey", ptr %t14, i32 0, i32 1
  %t16 = load i32, ptr %t15, !tbaa !23
  %t19 = icmp eq i32 %t13, %t16
  br i1 %t19, label %bb3, label %bb1
bb3:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/eval:dkey", ptr %t21, i32 0, i32 2
  %t23 = load i32, ptr %t22, !tbaa !23
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t25 = getelementptr %"compiler/eval:dkey", ptr %t24, i32 0, i32 2
  %t26 = load i32, ptr %t25, !tbaa !23
  %t29 = icmp eq i32 %t23, %t26
  br i1 %t29, label %bb4, label %bb1
bb4:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/eval:dkey", ptr %t31, i32 0, i32 3
  %t33 = load i32, ptr %t32, !tbaa !23
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t35 = getelementptr %"compiler/eval:dkey", ptr %t34, i32 0, i32 3
  %t36 = load i32, ptr %t35, !tbaa !23
  %t39 = icmp eq i32 %t33, %t36
  br i1 %t39, label %bb5, label %bb1
bb5:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/eval:dkey", ptr %t41, i32 0, i32 4
  %t43 = load i32, ptr %t42, !tbaa !23
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t45 = getelementptr %"compiler/eval:dkey", ptr %t44, i32 0, i32 4
  %t46 = load i32, ptr %t45, !tbaa !23
  %t49 = icmp eq i32 %t43, %t46
  br i1 %t49, label %bb6, label %bb1
bb6:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/eval:dkey", ptr %t51, i32 0, i32 5
  %t53 = load i64, ptr %t52, !tbaa !24
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t55 = getelementptr %"compiler/eval:dkey", ptr %t54, i32 0, i32 5
  %t56 = load i64, ptr %t55, !tbaa !24
  %t59 = icmp eq i64 %t53, %t56
  br i1 %t59, label %bb7, label %bb1
bb7:
  br label %bb8
bb8:
  %t61 = load i1, ptr %l2, !tbaa !21
  store i1 %t61, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2feval_3agkey(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = getelementptr %"compiler/eval:gkey", ptr %t1, i32 0, i32 0
  %t3 = load i64, ptr %t2, !tbaa !24
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"compiler/eval:gkey", ptr %t4, i32 0, i32 0
  %t6 = load i64, ptr %t5, !tbaa !24
  %t9 = icmp eq i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb4
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/eval:gkey", ptr %t11, i32 0, i32 1
  %t13 = load i32, ptr %t12, !tbaa !23
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"compiler/eval:gkey", ptr %t14, i32 0, i32 1
  %t16 = load i32, ptr %t15, !tbaa !23
  %t19 = icmp eq i32 %t13, %t16
  br i1 %t19, label %bb3, label %bb1
bb3:
  br label %bb4
bb4:
  %t21 = load i1, ptr %l2, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

declare void @__olang_check_failed(ptr)
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
define linkonce_odr i64 @olang_2eHelperKind_2eHash_2ecompiler_2feval_3adkey(ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l9 = alloca i64
  %l15 = alloca i64
  %l20 = alloca i64
  %l24 = alloca i64
  %l29 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = getelementptr %"compiler/eval:dkey", ptr %t1, i32 0, i32 0
  %t3 = load i64, ptr %t2, !tbaa !24
  %t5 = mul i64 %t3, -7046029254386353131
  store i64 %t5, ptr %l3, !tbaa !24
  %t6 = load i64, ptr %l3, !tbaa !24
  %t7 = ashr i64 %t6, 29
  %t8 = load i64, ptr %l3, !tbaa !24
  %t10 = xor i64 %t8, %t7
  %t11 = load i64, ptr %l1, !tbaa !24
  %t12 = mul i64 %t11, 1099511628211
  %t15 = add i64 %t12, %t10
  store i64 %t15, ptr %l1, !tbaa !24
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/eval:dkey", ptr %t16, i32 0, i32 1
  %t18 = load i32, ptr %t17, !tbaa !23
  %t20 = sext i32 %t18 to i64
  %t22 = mul i64 %t20, -7046029254386353131
  store i64 %t22, ptr %l9, !tbaa !24
  %t23 = load i64, ptr %l9, !tbaa !24
  %t24 = ashr i64 %t23, 29
  %t25 = load i64, ptr %l9, !tbaa !24
  %t27 = xor i64 %t25, %t24
  %t28 = load i64, ptr %l1, !tbaa !24
  %t29 = mul i64 %t28, 1099511628211
  %t32 = add i64 %t29, %t27
  store i64 %t32, ptr %l1, !tbaa !24
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/eval:dkey", ptr %t33, i32 0, i32 2
  %t35 = load i32, ptr %t34, !tbaa !23
  %t37 = sext i32 %t35 to i64
  %t39 = mul i64 %t37, -7046029254386353131
  store i64 %t39, ptr %l15, !tbaa !24
  %t40 = load i64, ptr %l15, !tbaa !24
  %t41 = ashr i64 %t40, 29
  %t42 = load i64, ptr %l15, !tbaa !24
  %t44 = xor i64 %t42, %t41
  %t45 = load i64, ptr %l1, !tbaa !24
  %t46 = mul i64 %t45, 1099511628211
  %t49 = add i64 %t46, %t44
  store i64 %t49, ptr %l1, !tbaa !24
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/eval:dkey", ptr %t50, i32 0, i32 3
  %t52 = load i32, ptr %t51, !tbaa !23
  %t54 = call i64 @std_2fprelude_2fhash_2eI32_2eHash(i32 %t52)
  store i64 %t54, ptr %l20
  br label %bb1
bb1:
  %t55 = load i64, ptr %l1, !tbaa !24
  %t56 = mul i64 %t55, 1099511628211
  %t58 = load i64, ptr %l20, !tbaa !24
  %t59 = add i64 %t56, %t58
  store i64 %t59, ptr %l1, !tbaa !24
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/eval:dkey", ptr %t60, i32 0, i32 4
  %t62 = load i32, ptr %t61, !tbaa !23
  %t64 = sext i32 %t62 to i64
  %t66 = mul i64 %t64, -7046029254386353131
  store i64 %t66, ptr %l24, !tbaa !24
  %t67 = load i64, ptr %l24, !tbaa !24
  %t68 = ashr i64 %t67, 29
  %t69 = load i64, ptr %l24, !tbaa !24
  %t71 = xor i64 %t69, %t68
  %t72 = load i64, ptr %l1, !tbaa !24
  %t73 = mul i64 %t72, 1099511628211
  %t76 = add i64 %t73, %t71
  store i64 %t76, ptr %l1, !tbaa !24
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/eval:dkey", ptr %t77, i32 0, i32 5
  %t79 = load i64, ptr %t78, !tbaa !24
  %t81 = mul i64 %t79, -7046029254386353131
  store i64 %t81, ptr %l29, !tbaa !24
  %t82 = load i64, ptr %l29, !tbaa !24
  %t83 = ashr i64 %t82, 29
  %t84 = load i64, ptr %l29, !tbaa !24
  %t86 = xor i64 %t84, %t83
  %t87 = load i64, ptr %l1, !tbaa !24
  %t88 = mul i64 %t87, 1099511628211
  %t91 = add i64 %t88, %t86
  store i64 %t91, ptr %l1, !tbaa !24
  %t92 = load i64, ptr %l1, !tbaa !24
  store i64 %t92, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define linkonce_odr i64 @olang_2eHelperKind_2eHash_2ecompiler_2feval_3agkey(ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l8 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = getelementptr %"compiler/eval:gkey", ptr %t1, i32 0, i32 0
  %t3 = load i64, ptr %t2, !tbaa !24
  %t5 = mul i64 %t3, -7046029254386353131
  store i64 %t5, ptr %l3, !tbaa !24
  %t6 = load i64, ptr %l3, !tbaa !24
  %t7 = ashr i64 %t6, 29
  %t8 = load i64, ptr %l3, !tbaa !24
  %t10 = xor i64 %t8, %t7
  %t11 = load i64, ptr %l1, !tbaa !24
  %t12 = mul i64 %t11, 1099511628211
  %t15 = add i64 %t12, %t10
  store i64 %t15, ptr %l1, !tbaa !24
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/eval:gkey", ptr %t16, i32 0, i32 1
  %t18 = load i32, ptr %t17, !tbaa !23
  %t20 = call i64 @std_2fprelude_2fhash_2eI32_2eHash(i32 %t18)
  store i64 %t20, ptr %l8
  br label %bb1
bb1:
  %t21 = load i64, ptr %l1, !tbaa !24
  %t22 = mul i64 %t21, 1099511628211
  %t24 = load i64, ptr %l8, !tbaa !24
  %t25 = add i64 %t22, %t24
  store i64 %t25, ptr %l1, !tbaa !24
  %t26 = load i64, ptr %l1, !tbaa !24
  store i64 %t26, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_H86f724e2dc8b3b4d675d56b45c81e2ce(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_Hc3dff1927e5c626a9d95abfdf4e9a462(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2fsource_3aNameId_2c_20B_Heab357d0b792d165805bc071c98cf6d1(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cI64_2c_20std_2fprelude_2ftext_3aS_Hbc76424a3315a39f193abd133425e79e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, { i64, ptr } %a3)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cI64_2c_20std_2fprelude_2ftext_3aS_H278e2bff38291605745e721886b12833(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cI64_2c_20Bool_3e_2ebucketOf_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_c86e3c417e5597b_1f94290d51440aef = external constant [0 x i8]
@olang_loc_1b0213f54aec9aef_9f01fc08d423d4eb = external constant [0 x i8]
@olang_loc_aeaae73888a93de2_57b628b04640c97e = external constant [0 x i8]
declare %"std/prelude/map:MapEntry.8d509622153b47f1a5f79c42c8367406" @std_2fprelude_2fmap_3aMapEntry_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, ptr %v1, i64 %a0, { i64, ptr } %a1)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)
declare %"std/prelude/map:mapSlot.47b3cc80db0b342939bd1d482dd866ad" @std_2fprelude_2fmap_3amapSlot_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, ptr %v1, ptr %v2, i64 %a0, { i64, ptr } %a1, ptr %a2)
declare %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" @std_2fprelude_2fmap_3amapState_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eHas_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_a9a2c1aff025c9e9_b219f8625f9ea465 = external constant [0 x i8]
@olang_loc_25e9a5c9ebeb981c_fe6b680ddb4c23f8 = external constant [0 x i8]
@olang_loc_2a4a9afd1920f3f5_dc8fcefdcc7e7d21 = external constant [0 x i8]
@olang_loc_4db56186023bb188_997a37585b9ec014 = external constant [0 x i8]
@olang_loc_8a0f8702409a2f83_1bc382f02d0f4ff = external constant [0 x i8]
@olang_loc_dee3d00730d4108e_ba689ea3709c32a = external constant [0 x i8]
@olang_loc_a6d1e1a34493fe12_f38c73d9643f1c0e = external constant [0 x i8]
@olang_loc_79d50032057e0507_9eb82ad474053b03 = external constant [0 x i8]
@olang_loc_8d3e4c03391d9d69_e18515306abca6f5 = external constant [0 x i8]
@olang_loc_cafc1179d98470af_ff4b2d5b532194fb = external constant [0 x i8]
@olang_loc_be239a5bd3d67051_98f25215818627ed = external constant [0 x i8]
@olang_loc_96e2a7e501496caf_9ddc065efece6e7b = external constant [0 x i8]
@olang_loc_90e22ecdf487f4f3_638b220c7e5f1e6f = external constant [0 x i8]
@olang_loc_77c41571e394d1c5_a26b081ff08a1d01 = external constant [0 x i8]
@olang_loc_9a2d0205b5782b4f_6eed86a41e6bc3ab = external constant [0 x i8]
@olang_loc_f86a0809d810f51b_b7bc0d1c42251c1f = external constant [0 x i8]
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aConstAsk_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3aSaid_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aContractAsk_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aGap_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fgeneric_3aConstAsk_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_9c71bec70403bcd3_93d6e20d21b9fd07 = external constant [0 x i8]
declare %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fdiag_3aSaid_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fload_3aImport_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fcheck_3aContractAsk_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fscope_3aGap_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_136ccb8e95b23ba9_d27b970572ac08f5 = external constant [0 x i8]
declare %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fhash_2eI32_2eHash(i32 %a0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
