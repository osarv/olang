; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, { i64, [2 x i64] }, i32, i1, i1 }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/check:frame" = type { i64, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/generic:Context", i32, i32, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i32, i64, i64, i64, i1, i64, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i64, i64, i64, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/source:Span", i64, i1 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/generic:Context" = type { i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i64, i64, i1, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, { i64, [3 x i64] }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i32, i64, %"compiler/source:Span", i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/source:Span", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i64, i64, i64, i64, i64, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/text:StringBuilder", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:ContractInfo" = type { { i64, ptr }, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/check:ctSource" = type { ptr, ptr, { i64, ptr }, i64, { i64, ptr } }
%"compiler/ast:ContractBlock" = type { %"compiler/source:Span", { i64, ptr } }
%"compiler/ast:TopIf" = type { ptr, ptr, ptr, ptr }
%"compiler/ast:TopBranch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr }
%"compiler/generic:Desc" = type { i64, i32, i64, i64 }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, { i64, ptr } }
%"compiler/check:b5aWalk" = type { i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1 }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32, i1 }
%"compiler/ast:Match" = type { %"compiler/source:Span", ptr, i1, { i64, ptr } }
%"compiler/ast:Case" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, ptr }
%"compiler/check:reflList" = type { i1, i32, i64, i64 }
%"compiler/check:litv" = type { i1, i1, i1, i64, double, i1, i1, i1, i128 }
%"compiler/generic:AnySlot" = type { i32, i32, i64, i64, i1, i32 }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr, { i64, ptr } }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [2 x i64] }, i1 }
%"std/pair:Pair.1eb2466213689e002f25e81e83536e78" = type { i64, ptr }
%"compiler/check:elemsShape" = type { { i64, ptr }, i64 }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"compiler/check:seqOf" = type { i32, i64, i64, i64 }
%"compiler/check:AssertAsk" = type { i64, i64, %"compiler/source:Span", %"compiler/source:Span", i64, i64, i1, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, [3 x i64] }, { i64, ptr } }
%"compiler/check:nullNarrow" = type { { i64, ptr }, i64, i1 }
%"compiler/check:narrowed" = type { i64, i64, i32, i64, i64, i1 }
%"compiler/check:errNarrow" = type { i32, i32, i64, i1 }
%"compiler/typed:Bind" = type { i32, ptr }
%"compiler/typed:Text" = type { { i64, ptr }, i32 }
%"compiler/ast:ForIn" = type { i32, i32, ptr, i1, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/check:unsetCand" = type { i64, i64, i64, i1, i64, %"compiler/source:Span", i32, i1 }
%"compiler/check:fixedInit" = type { ptr, i32 }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1, { i64, ptr }, i1 }
%"compiler/ast:CaseDecl" = type { %"compiler/source:Span", i32, { i64, ptr }, i1, ptr, { i64, ptr } }
%"compiler/check:factsMark" = type { i64, i64, i64 }
define dso_local i1 @compiler_2fcheck_2ebadSeparator(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l12 = alloca i64
  %l15 = alloca i64
  %l33 = alloca { i64, ptr }
  %l39 = alloca i1
  %l46 = alloca { i64, ptr }
  %l50 = alloca i1
  %l52 = alloca i1
  %l53 = alloca { i64, ptr }
  %l57 = alloca i1
  %l60 = alloca { i64, ptr }
  %l64 = alloca i1
  %l66 = alloca i1
  %l67 = alloca { i64, ptr }
  %l71 = alloca i1
  %l76 = alloca i1
  %l77 = alloca { i64, ptr }
  %l82 = alloca i1
  %l83 = alloca { i64, ptr }
  %l88 = alloca i1
  %l91 = alloca i1
  %l92 = alloca { i64, ptr }
  %l97 = alloca i1
  %l98 = alloca { i64, ptr }
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  %t6 = load i64, ptr %l1, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l3, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l12, !tbaa !24
  br label %bb6
bb3:
  %t15 = load i64, ptr %l2, !tbaa !24
  %t16 = load i64, ptr %l1, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l3, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l3, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l15, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb5
bb5:
  %t31 = load i64, ptr %l15, !tbaa !24
  store i64 %t31, ptr %l12, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l12, !tbaa !24
  store i64 %t32, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb7
bb7:
  %t33 = load i64, ptr %l5, !tbaa !24
  %t34 = load i64, ptr %l4, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  br label %bb55
bb9:
  br label %bb10
bb10:
  %t41 = load i64, ptr %l1, !tbaa !24
  %t42 = load i64, ptr %l5, !tbaa !24
  %t43 = load i64, ptr %l3, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l6, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t51, ptr %l33, !tbaa !27
  %t52 = load i64, ptr %l6, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr i8, ptr %t55, i64 %t52
  %t57 = load i8, ptr %t56, !tbaa !32
  %t59 = icmp ne i8 %t57, 95
  br i1 %t59, label %bb11, label %bb12
bb11:
  br label %bb54
bb12:
  br label %bb13
bb13:
  %t61 = load i64, ptr %l6, !tbaa !24
  %t63 = icmp eq i64 %t61, 0
  br i1 %t63, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb16
bb15:
  %t65 = load i64, ptr %l6, !tbaa !24
  %t67 = add i64 %t65, 1
  %t68 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t68, 0
  %t73 = icmp sge i64 %t67, %t70
  store i1 %t73, ptr %l39, !tbaa !21
  br label %bb16
bb16:
  %t75 = load i1, ptr %l39, !tbaa !21
  br i1 %t75, label %bb17, label %bb18
bb17:
  store i1 true, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t77 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t77, ptr %l46, !tbaa !27
  %t78 = load i64, ptr %l6, !tbaa !24
  %t80 = sub i64 %t78, 1
  %t82 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr i8, ptr %t83, i64 %t80
  %t85 = load i8, ptr %t84, !tbaa !32
  %t87 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t85)
  store i1 %t87, ptr %l50
  br label %bb20
bb20:
  %t88 = load i1, ptr %l50, !tbaa !21
  %t89 = xor i1 %t88, true
  br i1 %t89, label %bb21, label %bb22
bb21:
  %t91 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t91, ptr %l53, !tbaa !27
  %t92 = load i64, ptr %l6, !tbaa !24
  %t94 = sub i64 %t92, 1
  %t96 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = getelementptr i8, ptr %t97, i64 %t94
  %t99 = load i8, ptr %t98, !tbaa !32
  %t101 = call i1 @compiler_2fcheck_2eisHexDigit(i8 %t99)
  store i1 %t101, ptr %l57
  br label %bb23
bb22:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb24
bb23:
  %t102 = load i1, ptr %l57, !tbaa !21
  %t103 = xor i1 %t102, true
  store i1 %t103, ptr %l52, !tbaa !21
  br label %bb24
bb24:
  %t105 = load i1, ptr %l52, !tbaa !21
  br i1 %t105, label %bb25, label %bb26
bb25:
  store i1 true, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t107 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t107, ptr %l60, !tbaa !27
  %t108 = load i64, ptr %l6, !tbaa !24
  %t110 = add i64 %t108, 1
  %t112 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr i8, ptr %t113, i64 %t110
  %t115 = load i8, ptr %t114, !tbaa !32
  %t117 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t115)
  store i1 %t117, ptr %l64
  br label %bb28
bb28:
  %t118 = load i1, ptr %l64, !tbaa !21
  %t119 = xor i1 %t118, true
  br i1 %t119, label %bb29, label %bb30
bb29:
  %t121 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t121, ptr %l67, !tbaa !27
  %t122 = load i64, ptr %l6, !tbaa !24
  %t124 = add i64 %t122, 1
  %t126 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = getelementptr i8, ptr %t127, i64 %t124
  %t129 = load i8, ptr %t128, !tbaa !32
  %t131 = call i1 @compiler_2fcheck_2eisHexDigit(i8 %t129)
  store i1 %t131, ptr %l71
  br label %bb31
bb30:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb32
bb31:
  %t132 = load i1, ptr %l71, !tbaa !21
  %t133 = xor i1 %t132, true
  store i1 %t133, ptr %l66, !tbaa !21
  br label %bb32
bb32:
  %t135 = load i1, ptr %l66, !tbaa !21
  br i1 %t135, label %bb33, label %bb34
bb33:
  store i1 true, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  %t137 = load i64, ptr %l6, !tbaa !24
  %t139 = icmp sge i64 %t137, 2
  br i1 %t139, label %bb36, label %bb37
bb36:
  %t141 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t141, ptr %l77, !tbaa !27
  %t142 = load i64, ptr %l6, !tbaa !24
  %t144 = sub i64 %t142, 1
  %t146 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = getelementptr i8, ptr %t147, i64 %t144
  %t149 = load i8, ptr %t148, !tbaa !32
  %t151 = icmp eq i8 %t149, 120
  store i1 %t151, ptr %l76, !tbaa !21
  br label %bb38
bb37:
  store i1 false, ptr %l76, !tbaa !21
  br label %bb38
bb38:
  %t153 = load i1, ptr %l76, !tbaa !21
  br i1 %t153, label %bb39, label %bb40
bb39:
  %t154 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t154, ptr %l83, !tbaa !27
  %t155 = load i64, ptr %l6, !tbaa !24
  %t157 = sub i64 %t155, 2
  %t159 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !27
  %t161 = getelementptr i8, ptr %t160, i64 %t157
  %t162 = load i8, ptr %t161, !tbaa !32
  %t164 = icmp eq i8 %t162, 48
  store i1 %t164, ptr %l82, !tbaa !21
  br label %bb41
bb40:
  store i1 false, ptr %l82, !tbaa !21
  br label %bb41
bb41:
  %t166 = load i1, ptr %l82, !tbaa !21
  br i1 %t166, label %bb42, label %bb43
bb42:
  store i1 true, ptr %l88, !tbaa !21
  br label %bb50
bb43:
  %t167 = load i64, ptr %l6, !tbaa !24
  %t169 = icmp sge i64 %t167, 2
  br i1 %t169, label %bb44, label %bb45
bb44:
  %t171 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t171, ptr %l92, !tbaa !27
  %t172 = load i64, ptr %l6, !tbaa !24
  %t174 = sub i64 %t172, 1
  %t176 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = getelementptr i8, ptr %t177, i64 %t174
  %t179 = load i8, ptr %t178, !tbaa !32
  %t181 = icmp eq i8 %t179, 98
  store i1 %t181, ptr %l91, !tbaa !21
  br label %bb46
bb45:
  store i1 false, ptr %l91, !tbaa !21
  br label %bb46
bb46:
  %t183 = load i1, ptr %l91, !tbaa !21
  br i1 %t183, label %bb47, label %bb48
bb47:
  %t184 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t184, ptr %l98, !tbaa !27
  %t185 = load i64, ptr %l6, !tbaa !24
  %t187 = sub i64 %t185, 2
  %t189 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !27
  %t191 = getelementptr i8, ptr %t190, i64 %t187
  %t192 = load i8, ptr %t191, !tbaa !32
  %t194 = icmp eq i8 %t192, 48
  store i1 %t194, ptr %l97, !tbaa !21
  br label %bb49
bb48:
  store i1 false, ptr %l97, !tbaa !21
  br label %bb49
bb49:
  %t196 = load i1, ptr %l97, !tbaa !21
  store i1 %t196, ptr %l88, !tbaa !21
  br label %bb50
bb50:
  %t197 = load i1, ptr %l88, !tbaa !21
  br i1 %t197, label %bb51, label %bb52
bb51:
  store i1 true, ptr %rv
  br label %ret
bb52:
  br label %bb53
bb53:
  br label %bb54
bb54:
  %t199 = load i64, ptr %l5, !tbaa !24
  %t201 = add i64 %t199, 1
  store i64 %t201, ptr %l5, !tbaa !24
  br label %bb7
bb55:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2eclosedCall(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l22 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Call", ptr %t1, i32 0, i32 4
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/typed:Call", ptr %t6, i32 0, i32 2
  %t9 = load { i64, [2 x i64] }, ptr %t8
  %t11 = extractvalue { i64, [2 x i64] } %t9, 0
  %t12 = icmp eq i64 %t11, 0
  %t14 = xor i1 %t12, true
  store i1 %t14, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  %t16 = load i1, ptr %l4, !tbaa !21
  br i1 %t16, label %bb4, label %bb5
bb4:
  store i1 false, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/typed:Call", ptr %t18, i32 0, i32 0
  %t21 = load ptr, ptr %t20, !tbaa !29
  store ptr %t21, ptr %l1, !tbaa !29
  %t23 = load ptr, ptr %l1, !tbaa !29
  store ptr %t23, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t24 = load ptr, ptr %l12, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb7, label %bb8
bb7:
  %t27 = load ptr, ptr %l12, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 5}
  %t30 = icmp eq i64 %t28, 0
  store i1 %t30, ptr %l13, !tbaa !21
  br label %bb8
bb8:
  %t31 = load i1, ptr %l13, !tbaa !21
  br i1 %t31, label %bb9, label %bb10
bb9:
  br label %bb15
bb10:
  %t32 = load ptr, ptr %l1, !tbaa !29
  store ptr %t32, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t33 = load ptr, ptr %l16, !tbaa !29
  %t34 = icmp ne ptr %t33, null
  br i1 %t34, label %bb11, label %bb12
bb11:
  %t36 = load ptr, ptr %l16, !tbaa !29
  %t37 = load i64, ptr %t36, !range !{i64 0, i64 5}
  %t39 = icmp eq i64 %t37, 4
  store i1 %t39, ptr %l17, !tbaa !21
  br label %bb12
bb12:
  %t40 = load i1, ptr %l17, !tbaa !21
  br i1 %t40, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/typed:Call", ptr %t41, i32 0, i32 1
  %t44 = load { i64, ptr }, ptr %t43, !tbaa !27
  %t46 = call i1 @compiler_2fcheck_2eclosedAll(ptr %v0, { i64, ptr } %t44)
  store i1 %t46, ptr %l22
  br label %bb16
bb16:
  %t47 = load i1, ptr %l22, !tbaa !21
  store i1 %t47, ptr %rv
  br label %ret
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  store i1 false, ptr %rv
  br label %ret
bb21:
  call void @__olang_check_failed(ptr @olang_loc_317fdf139725c543_9c9e0109f99156f7)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eattrExpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %lp5 = alloca ptr
  %l8 = alloca ptr
  %l11 = alloca i64
  %l14 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l38 = alloca %"compiler/source:Span"
  %l41 = alloca i32
  %l43 = alloca ptr
  %l47 = alloca %"compiler/typed:Try"
  %rv = alloca ptr
  %t95 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l8
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l8, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t5, i32 0, i32 26
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l11
  br label %bb2
bb2:
  %t10 = load i64, ptr %l11, !tbaa !24
  store i64 %t10, ptr %l3, !tbaa !24
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t13 = getelementptr %"compiler/check:frame", ptr %t11, i32 0, i32 16
  %t14 = load i64, ptr %t13, !tbaa !24
  store i64 %t14, ptr %l4, !tbaa !24
  %t16 = load ptr, ptr %l2, !tbaa !29
  store ptr %t16, ptr %l14, !tbaa !29
  %t17 = load ptr, ptr %l14, !tbaa !29
  %t18 = getelementptr %"compiler/check:frame", ptr %t17, i32 0, i32 15
  %t19 = load i64, ptr %t18, !tbaa !24
  %t21 = add i64 %t19, 1
  %t23 = load ptr, ptr %l14, !tbaa !29
  %t24 = getelementptr %"compiler/check:frame", ptr %t23, i32 0, i32 15
  store i64 %t21, ptr %t24, !tbaa !24
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t28 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t32 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t25, ptr %t26, i32 %t28)
  store ptr %t32, ptr %l21
  br label %bb3
bb3:
  %t33 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store ptr %t33, ptr %lp5
  %t34 = load ptr, ptr %l21, !tbaa !29
  %t35 = load ptr, ptr %lp5
  store ptr %t34, ptr %t35, !tbaa !29
  %t36 = load ptr, ptr %l2, !tbaa !29
  store ptr %t36, ptr %l22, !tbaa !29
  %t37 = load ptr, ptr %l22, !tbaa !29
  %t38 = getelementptr %"compiler/check:frame", ptr %t37, i32 0, i32 15
  %t39 = load i64, ptr %t38, !tbaa !24
  %t41 = sub i64 %t39, 1
  %t43 = load ptr, ptr %l22, !tbaa !29
  %t44 = getelementptr %"compiler/check:frame", ptr %t43, i32 0, i32 15
  store i64 %t41, ptr %t44, !tbaa !24
  %t45 = load ptr, ptr %l2, !tbaa !29
  %t47 = getelementptr %"compiler/check:frame", ptr %t45, i32 0, i32 16
  %t48 = load i64, ptr %t47, !tbaa !24
  %t49 = load i64, ptr %l4, !tbaa !24
  %t52 = icmp ne i64 %t48, %t49
  %t54 = load ptr, ptr %l2, !tbaa !29
  %t55 = load i64, ptr %l4, !tbaa !24
  %t58 = getelementptr %"compiler/check:frame", ptr %t54, i32 0, i32 16
  store i64 %t55, ptr %t58, !tbaa !24
  %t61 = xor i1 %t52, true
  br i1 %t61, label %bb4, label %bb5
bb4:
  %t63 = load ptr, ptr %lp5
  %t64 = load ptr, ptr %t63, !tbaa !29
  store ptr %t64, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t66 = load ptr, ptr %l2, !tbaa !29
  %t68 = getelementptr %"compiler/check:frame", ptr %t66, i32 0, i32 26
  %t69 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eTruncate_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t68, i64 %t69)
  br label %bb7
bb7:
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t74 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t72)
  store %"compiler/source:Span" %t74, ptr %l38
  br label %bb8
bb8:
  %t75 = load ptr, ptr %lp5
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t79 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t76)
  store i32 %t79, ptr %l41
  br label %bb9
bb9:
  %t80 = load ptr, ptr %lp5
  %t81 = load ptr, ptr %t80, !tbaa !29
  store ptr %t81, ptr %l43, !tbaa !29
  %t83 = icmp sge i64 0, 0
  br i1 %t83, label %bb10, label %bb11
bb10:
  %t85 = icmp sle i64 0, 1152921504606846975
  br i1 %t85, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_ca088269e212954c_d643913a2551dac8)
  unreachable
bb12:
  %t87 = mul i64 0, 8
  %t88 = insertvalue { i64, ptr } undef, i64 0, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t90 = load ptr, ptr %l43, !tbaa !29
  %t92 = call %"compiler/typed:Try" @compiler_2ftyped_3aTry_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %t90, { i64, ptr } %t89, i1 true, i1 false, i1 true)
  store %"compiler/typed:Try" %t92, ptr %l47
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_ca088269e212954c_d643913a2551dac8)
  unreachable
bb14:
  %t93 = load %"compiler/typed:Try", ptr %l47
  %t94 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store %"compiler/typed:Try" %t93, ptr %t94
  store { i64, [5 x i64] } zeroinitializer, ptr %t95
  %t96 = getelementptr { i64, [5 x i64] }, ptr %t95, i32 0, i32 0
  store i64 14, ptr %t96
  %t97 = load %"compiler/source:Span", ptr %l38
  %t98 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t97, 0
  %t99 = load i32, ptr %l41, !tbaa !23
  %t100 = insertvalue { %"compiler/source:Span", i32, ptr } %t98, i32 %t99, 1
  %t102 = insertvalue { %"compiler/source:Span", i32, ptr } %t100, ptr %t94, 2
  %t103 = getelementptr { i64, [5 x i64] }, ptr %t95, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t102, ptr %t103
  %t104 = load { i64, [5 x i64] }, ptr %t95
  %t106 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t104, ptr %t106
  store ptr %t106, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aHoldsAny(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l14 = alloca { i64, ptr }
  %l21 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t15, ptr %l14, !tbaa !27
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i32, ptr %t19, i64 %t16
  %t21 = load i32, ptr %t20, !tbaa !33
  %t27 = add i64 %a2, 1
  %t31 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aHoldsFn(ptr %v0, ptr %a0, i32 %t21, i64 %t27)
  store i1 %t31, ptr %l21
  br label %bb5
bb5:
  %t32 = load i1, ptr %l21, !tbaa !21
  br i1 %t32, label %bb6, label %bb7
bb6:
  store i1 true, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t34 = load i64, ptr %l4, !tbaa !24
  %t36 = add i64 %t34, 1
  store i64 %t36, ptr %l4, !tbaa !24
  br label %bb1
bb10:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyErrors(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l8 = alloca ptr
  %l11 = alloca i1
  %l15 = alloca i1
  %l16 = alloca i32
  %l22 = alloca i32
  %l26 = alloca i64
  %l33 = alloca i64
  %l35 = alloca i32
  %l39 = alloca i32
  %l40 = alloca i32
  %l41 = alloca i1
  %l45 = alloca i1
  %l46 = alloca i32
  %l48 = alloca ptr
  %l49 = alloca i64
  %l54 = alloca { i64, ptr }
  %l56 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l59 = alloca i32
  %l61 = alloca ptr
  %l64 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l65 = alloca i32
  %l66 = alloca i32
  %l68 = alloca ptr
  %l69 = alloca i64
  %l74 = alloca { i64, ptr }
  %l76 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 14
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l8
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l8, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 2
  %t11 = load i32, ptr %t10, !tbaa !23
  store i32 %t11, ptr %l2, !tbaa !23
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 53
  %t16 = load i64, ptr %l1, !tbaa !24
  %t19 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eGet_3cI64_2c_20Bool_3e(ptr %v0, ptr %t15, i64 %t16)
  %t20 = extractvalue { i32, i1 } %t19, 1
  %t21 = extractvalue { i32, i1 } %t19, 0
  store i32 %t21, ptr %l16
  %t22 = icmp ne i32 %t21, 0
  br i1 %t22, label %bb3, label %ok.23, !prof !99
ok.23:
  store i1 %t20, ptr %l15
  br label %bb2
bb2:
  %t24 = load i1, ptr %l15, !tbaa !21
  store i1 %t24, ptr %l11, !tbaa !21
  br label %bb5
bb3:
  br label %bb4
bb4:
  call void @__olang_ert_req_clear()
  store i1 false, ptr %l11, !tbaa !21
  br label %bb5
bb5:
  %t25 = load i1, ptr %l11, !tbaa !21
  %t26 = xor i1 %t25, true
  br i1 %t26, label %bb6, label %bb7
bb6:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/generic:Program", ptr %t31, i32 0, i32 2
  %t34 = load i32, ptr %l2, !tbaa !23
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t33, i32 %t34)
  store i32 %t37, ptr %l22
  br label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t38 = load i32, ptr %l22, !tbaa !23
  store i32 %t38, ptr %rv
  br label %ret
bb9:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/check:Checker", ptr %t39, i32 0, i32 19
  %t42 = load i64, ptr %l1, !tbaa !24
  %t45 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t41, i64 %t42)
  store i64 %t45, ptr %l26
  br label %bb10
bb10:
  %t46 = load i64, ptr %l26, !tbaa !24
  %t47 = icmp eq i64 %t46, 0
  br i1 %t47, label %bb11, label %bb12
bb11:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckNow(ptr %v0, ptr %t49, i64 %t50)
  br label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb14
bb14:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/check:Checker", ptr %t53, i32 0, i32 19
  %t56 = load i64, ptr %l1, !tbaa !24
  %t59 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t55, i64 %t56)
  store i64 %t59, ptr %l33
  br label %bb15
bb15:
  %t60 = load i64, ptr %l33, !tbaa !24
  %t61 = icmp eq i64 %t60, 2
  br i1 %t61, label %bb16, label %bb17
bb16:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 54
  %t66 = load i64, ptr %l1, !tbaa !24
  %t69 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aListId_3e__H9cb5d99387f926677a92c13412f9a8b2(ptr %v0, ptr %t65, i64 %t66)
  %t70 = extractvalue { i32, i32 } %t69, 1
  %t71 = extractvalue { i32, i32 } %t69, 0
  store i32 %t71, ptr %l40
  %t72 = icmp ne i32 %t71, 0
  br i1 %t72, label %bb19, label %ok.73, !prof !99
ok.73:
  store i32 %t70, ptr %l39
  br label %bb18
bb17:
  br label %bb33
bb18:
  %t74 = load i32, ptr %l39, !tbaa !23
  store i32 %t74, ptr %l35, !tbaa !23
  br label %bb21
bb19:
  br label %bb20
bb20:
  call void @__olang_ert_req_clear()
  store i32 0, ptr %l35, !tbaa !23
  br label %bb21
bb21:
  %t75 = load i32, ptr %l35, !tbaa !23
  store i32 %t75, ptr %l3, !tbaa !23
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/check:Checker", ptr %t76, i32 0, i32 56
  %t79 = load i64, ptr %l1, !tbaa !24
  %t82 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eGet_3cI64_2c_20Bool_3e(ptr %v0, ptr %t78, i64 %t79)
  %t83 = extractvalue { i32, i1 } %t82, 1
  %t84 = extractvalue { i32, i1 } %t82, 0
  store i32 %t84, ptr %l46
  %t85 = icmp ne i32 %t84, 0
  br i1 %t85, label %bb23, label %ok.86, !prof !99
ok.86:
  store i1 %t83, ptr %l45
  br label %bb22
bb22:
  %t87 = load i1, ptr %l45, !tbaa !21
  store i1 %t87, ptr %l41, !tbaa !21
  br label %bb25
bb23:
  br label %bb24
bb24:
  call void @__olang_ert_req_clear()
  store i1 false, ptr %l41, !tbaa !21
  br label %bb25
bb25:
  %t88 = load i1, ptr %l41, !tbaa !21
  br i1 %t88, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s4
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/check:Checker", ptr %t89, i32 0, i32 55
  store ptr %t91, ptr %l48, !tbaa !29
  %t92 = load i64, ptr %l1, !tbaa !24
  store i64 %t92, ptr %l49, !tbaa !24
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/check:Checker", ptr %t93, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t98 = getelementptr %"compiler/generic:Program", ptr %t96, i32 0, i32 2
  %t99 = load i32, ptr %l3, !tbaa !23
  %t102 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s4, ptr %t98, i32 %t99)
  store { i64, ptr } %t102, ptr %l54
  br label %bb28
bb27:
  br label %bb32
bb28:
  %t103 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t103, 0
  %t105 = load i64, ptr %l49, !tbaa !24
  %t107 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s4, i64 %t105, i64 %t104)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t107, ptr %l56
  br label %bb29
bb29:
  %t108 = load ptr, ptr %l48, !tbaa !29
  %t109 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l56
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_H2474e1fc3c93452d7765e4ed18f29a03(ptr %v0, ptr %t108, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t109)
  br label %bb30
bb30:
  %t110 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunsettle(ptr %v0, ptr %t110)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s4)
  br label %bb32
bb32:
  %t112 = load i32, ptr %l3, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t112, ptr %rv
  br label %ret
bb33:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/check:Checker", ptr %t114, i32 0, i32 57
  store ptr %t116, ptr %l61, !tbaa !29
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load i64, ptr %l1, !tbaa !24
  %t121 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyKey(ptr %v0, ptr %t117, i64 %t118)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t121, ptr %l64
  br label %bb34
bb34:
  %t122 = load ptr, ptr %l61, !tbaa !29
  %t123 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l64
  %t124 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hf3bb75ba9d3f922b4d327e9d3c1adfb0(ptr %v0, ptr %t122, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t123)
  %t125 = extractvalue { i32, i32 } %t124, 1
  %t126 = extractvalue { i32, i32 } %t124, 0
  store i32 %t126, ptr %l66
  %t127 = icmp ne i32 %t126, 0
  br i1 %t127, label %bb36, label %ok.128, !prof !99
ok.128:
  store i32 %t125, ptr %l65
  br label %bb35
bb35:
  %t129 = load i32, ptr %l65, !tbaa !23
  store i32 %t129, ptr %l59, !tbaa !23
  br label %bb38
bb36:
  br label %bb37
bb37:
  call void @__olang_ert_req_clear()
  store i32 0, ptr %l59, !tbaa !23
  br label %bb38
bb38:
  %t130 = load i32, ptr %l59, !tbaa !23
  store i32 %t130, ptr %l4, !tbaa !23
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr %"compiler/check:Checker", ptr %t131, i32 0, i32 55
  store ptr %t133, ptr %l68, !tbaa !29
  %t134 = load i64, ptr %l1, !tbaa !24
  store i64 %t134, ptr %l69, !tbaa !24
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/check:Checker", ptr %t135, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !29
  %t140 = getelementptr %"compiler/generic:Program", ptr %t138, i32 0, i32 2
  %t141 = load i32, ptr %l4, !tbaa !23
  %t144 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t140, i32 %t141)
  store { i64, ptr } %t144, ptr %l74
  br label %bb39
bb39:
  %t145 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t146 = extractvalue { i64, ptr } %t145, 0
  %t147 = load i64, ptr %l69, !tbaa !24
  %t149 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t147, i64 %t146)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t149, ptr %l76
  br label %bb40
bb40:
  %t150 = load ptr, ptr %l68, !tbaa !29
  %t151 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l76
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_H2474e1fc3c93452d7765e4ed18f29a03(ptr %v0, ptr %t150, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t151)
  br label %bb41
bb41:
  %t152 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunsettle(ptr %v0, ptr %t152)
  br label %bb42
bb42:
  %t154 = load i32, ptr %l4, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t154, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecBorrow(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %lp5 = alloca ptr
  %l8 = alloca i32
  %l11 = alloca i1
  %l14 = alloca i1
  %l15 = alloca i1
  %l18 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca %"compiler/source:Span"
  %l24 = alloca { i64, ptr }
  %l26 = alloca %"compiler/msgs:Msg"
  %l27 = alloca i64
  %l30 = alloca ptr
  %l35 = alloca ptr
  %l38 = alloca i32
  %l39 = alloca i32
  %l43 = alloca ptr
  %l44 = alloca %"compiler/source:Span"
  %l47 = alloca { i64, ptr }
  %l49 = alloca %"compiler/msgs:Msg"
  %l50 = alloca i64
  %l54 = alloca i1
  %l58 = alloca %"compiler/source:Span"
  %l61 = alloca ptr
  %l62 = alloca i32
  %l65 = alloca i1
  %l66 = alloca i64
  %l68 = alloca i32
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca ptr
  %t138 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t1)
  store i32 %t4, ptr %l8
  br label %bb1
bb1:
  %t5 = load i32, ptr %l8, !tbaa !23
  store i32 %t5, ptr %l4, !tbaa !23
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr %l4, !tbaa !23
  %t10 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t6, i32 %t7)
  store i1 %t10, ptr %l11
  br label %bb2
bb2:
  %t11 = load i1, ptr %l11, !tbaa !21
  br i1 %t11, label %bb3, label %bb4
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i32, ptr %l2, !tbaa !23
  %t16 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewritable(ptr %v0, ptr %t12, i32 %t13)
  store i1 %t16, ptr %l14
  br label %bb5
bb4:
  br label %bb16
bb5:
  %t17 = load i1, ptr %l14, !tbaa !21
  br i1 %t17, label %bb6, label %bb7
bb6:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i32, ptr %l4, !tbaa !23
  %t22 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewritable(ptr %v0, ptr %t18, i32 %t19)
  store i1 %t22, ptr %l18
  br label %bb8
bb7:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb9
bb8:
  %t23 = load i1, ptr %l18, !tbaa !21
  %t24 = xor i1 %t23, true
  store i1 %t24, ptr %l15, !tbaa !21
  br label %bb9
bb9:
  %t26 = load i1, ptr %l15, !tbaa !21
  br i1 %t26, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l20, !tbaa !29
  %t28 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t28, ptr %l21
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load i32, ptr %l4, !tbaa !23
  %t33 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t29, i32 %t30)
  store { i64, ptr } %t33, ptr %l24
  br label %bb12
bb11:
  br label %bb15
bb12:
  %t34 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t34, 0
  %t36 = extractvalue { i64, ptr } %t34, 1
  %t37 = mul i64 %t35, 1
  %t38 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t37)
  call void @llvm.memcpy.p0.p0.i64(ptr %t38, ptr %t36, i64 %t37, i1 false)
  %t39 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  %t42 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCPointerReadOnly(ptr %s2, ptr %s2, { i64, ptr } %t40)
  store %"compiler/msgs:Msg" %t42, ptr %l26
  br label %bb13
bb13:
  %t43 = load ptr, ptr %l20, !tbaa !29
  %t44 = load %"compiler/source:Span", ptr %l21
  %t45 = load %"compiler/msgs:Msg", ptr %l26
  %t46 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t43, %"compiler/source:Span" %t44, %"compiler/msgs:Msg" %t45)
  store i64 %t46, ptr %l27
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb15:
  %t47 = load ptr, ptr %l1, !tbaa !29
  store ptr %t47, ptr %rv
  br label %ret
bb16:
  %t49 = load ptr, ptr %l1, !tbaa !29
  %t51 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v1, ptr %v2, ptr %t49)
  store ptr %t51, ptr %l30
  br label %bb17
bb17:
  %t52 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store ptr %t52, ptr %lp5
  %t53 = load ptr, ptr %l30, !tbaa !29
  %t54 = load ptr, ptr %lp5
  store ptr %t53, ptr %t54, !tbaa !29
  %t55 = load ptr, ptr %lp5
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = icmp eq ptr %t56, null
  br i1 %t58, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s3
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/check:Checker", ptr %t60, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = getelementptr %"compiler/generic:Program", ptr %t63, i32 0, i32 2
  store ptr %t65, ptr %l35, !tbaa !29
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load i32, ptr %l4, !tbaa !23
  %t70 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t66, i32 %t67)
  store i32 %t70, ptr %l38
  br label %bb20
bb19:
  br label %bb28
bb20:
  %t71 = load ptr, ptr %l35, !tbaa !29
  %t72 = load i32, ptr %l38, !tbaa !23
  %t73 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t71, i32 %t72)
  store i32 %t73, ptr %l39
  br label %bb21
bb21:
  %t74 = load i32, ptr %l39, !range !{i32 0, i32 33}
  %t76 = trunc i64 19 to i32
  %t77 = icmp eq i32 %t74, %t76
  br i1 %t77, label %bb22, label %bb23
bb22:
  %t79 = load ptr, ptr %l1, !tbaa !29
  call void @__olang_scope_close(ptr %s3)
  store ptr %t79, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l43, !tbaa !29
  %t82 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t82, ptr %l44
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load i32, ptr %l4, !tbaa !23
  %t87 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s3, ptr %t83, i32 %t84)
  store { i64, ptr } %t87, ptr %l47
  br label %bb25
bb25:
  %t88 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t89 = extractvalue { i64, ptr } %t88, 0
  %t90 = extractvalue { i64, ptr } %t88, 1
  %t91 = mul i64 %t89, 1
  %t92 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t91)
  call void @llvm.memcpy.p0.p0.i64(ptr %t92, ptr %t90, i64 %t91, i1 false)
  %t93 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t92, 1
  %t96 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCPointerTemporary(ptr %s3, ptr %s3, { i64, ptr } %t94)
  store %"compiler/msgs:Msg" %t96, ptr %l49
  br label %bb26
bb26:
  %t97 = load ptr, ptr %l43, !tbaa !29
  %t98 = load %"compiler/source:Span", ptr %l44
  %t99 = load %"compiler/msgs:Msg", ptr %l49
  %t100 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t97, %"compiler/source:Span" %t98, %"compiler/msgs:Msg" %t99)
  store i64 %t100, ptr %l50
  br label %bb27
bb27:
  %t101 = load ptr, ptr %l1, !tbaa !29
  call void @__olang_scope_close(ptr %s3)
  store ptr %t101, ptr %rv
  br label %ret
bb28:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load i32, ptr %l2, !tbaa !23
  %t107 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewritable(ptr %v0, ptr %t103, i32 %t104)
  store i1 %t107, ptr %l54
  br label %bb29
bb29:
  %t108 = load i1, ptr %l54, !tbaa !21
  br i1 %t108, label %bb30, label %bb31
bb30:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load ptr, ptr %lp5
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t112 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emustWrite(ptr %v0, ptr %v2, ptr %t109, ptr %t111, %"compiler/source:Span" %t112, i1 false)
  br label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb33
bb33:
  %t116 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t116, ptr %l58
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/check:Checker", ptr %t117, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !29
  %t122 = getelementptr %"compiler/generic:Program", ptr %t120, i32 0, i32 2
  store ptr %t122, ptr %l61, !tbaa !29
  %t123 = load i32, ptr %l4, !tbaa !23
  store i32 %t123, ptr %l62, !tbaa !23
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load i32, ptr %l2, !tbaa !23
  %t128 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewritable(ptr %v0, ptr %t124, i32 %t125)
  store i1 %t128, ptr %l65
  br label %bb34
bb34:
  %t129 = load i1, ptr %l65, !tbaa !21
  br i1 %t129, label %bb35, label %bb36
bb35:
  %t130 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  store i64 %t130, ptr %l66, !tbaa !24
  br label %bb37
bb36:
  store i64 0, ptr %l66, !tbaa !24
  br label %bb37
bb37:
  %t132 = load ptr, ptr %l61, !tbaa !29
  %t133 = load i32, ptr %l62, !tbaa !23
  %t134 = load i64, ptr %l66, !tbaa !24
  %t135 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t132, i32 %t133, i64 %t134)
  store i32 %t135, ptr %l68
  br label %bb38
bb38:
  %t136 = load ptr, ptr %lp5
  %t137 = load ptr, ptr %t136, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t138
  %t139 = getelementptr { i64, [5 x i64] }, ptr %t138, i32 0, i32 0
  store i64 3, ptr %t139
  %t140 = load %"compiler/source:Span", ptr %l58
  %t141 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t140, 0
  %t142 = load i32, ptr %l68, !tbaa !23
  %t143 = insertvalue { %"compiler/source:Span", i32, ptr } %t141, i32 %t142, 1
  %t145 = insertvalue { %"compiler/source:Span", i32, ptr } %t143, ptr %t137, 2
  %t146 = getelementptr { i64, [5 x i64] }, ptr %t138, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t145, ptr %t146
  %t147 = load { i64, [5 x i64] }, ptr %t138
  %t149 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t147, ptr %t149
  store ptr %t149, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecPointerArg(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i32 %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca %"compiler/source:Span"
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l22 = alloca i32
  %l26 = alloca i1
  %l33 = alloca i32
  %l36 = alloca i32
  %l39 = alloca i1
  %l42 = alloca i1
  %l49 = alloca i32
  %l52 = alloca i1
  %l55 = alloca i1
  %l60 = alloca ptr
  %l63 = alloca ptr
  %l66 = alloca i32
  %l67 = alloca i32
  %l72 = alloca i32
  %l75 = alloca i1
  %l78 = alloca i1
  %l83 = alloca i32
  %l84 = alloca i32
  %l88 = alloca i32
  %l90 = alloca i1
  %l91 = alloca i32
  %l95 = alloca i32
  %l102 = alloca i1
  %l103 = alloca i1
  %l104 = alloca ptr
  %l107 = alloca i32
  %l108 = alloca i1
  %l109 = alloca i1
  %l114 = alloca i32
  %l121 = alloca i32
  %l124 = alloca ptr
  %l125 = alloca i32
  %l128 = alloca i32
  %l129 = alloca i1
  %l130 = alloca i1
  %l131 = alloca ptr
  %l134 = alloca i32
  %l135 = alloca i1
  %l140 = alloca ptr
  %l144 = alloca i1
  %l145 = alloca i1
  %l148 = alloca i1
  %l149 = alloca i1
  %l150 = alloca ptr
  %l153 = alloca i32
  %l154 = alloca i1
  %l155 = alloca i1
  %l158 = alloca i1
  %s8 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  store %"compiler/source:Span" %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a1, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t2 = load ptr, ptr %l13, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l13, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 5}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l14, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l14, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_7362f3ae74bf0a7_8f389ee36c95dce3)
  unreachable
bb11:
  %t10 = load i1, ptr %l12, !tbaa !21
  %t13 = xor i1 %t10, true
  br i1 %t13, label %bb12, label %bb13
bb12:
  store ptr null, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t19 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t16)
  store i32 %t19, ptr %l22
  br label %bb15
bb15:
  %t20 = load i32, ptr %l22, !tbaa !23
  store i32 %t20, ptr %l6, !tbaa !23
  %t21 = load i32, ptr %l6, !tbaa !23
  %t22 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t25 = icmp eq i32 %t21, %t22
  br i1 %t25, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb18
bb17:
  %t27 = load i32, ptr %l6, !tbaa !23
  %t28 = load i32, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  %t31 = icmp eq i32 %t27, %t28
  store i1 %t31, ptr %l26, !tbaa !21
  br label %bb18
bb18:
  %t33 = load i1, ptr %l26, !tbaa !21
  br i1 %t33, label %bb19, label %bb20
bb19:
  store ptr null, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load i32, ptr %l6, !tbaa !23
  %t39 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t35, i32 %t36)
  store i32 %t39, ptr %l33
  br label %bb22
bb22:
  %t40 = load i32, ptr %l33, !tbaa !23
  store i32 %t40, ptr %l7, !tbaa !23
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i32, ptr %l7, !tbaa !23
  %t45 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t41, i32 %t42)
  store i32 %t45, ptr %l36
  br label %bb23
bb23:
  %t46 = load i32, ptr %l36, !tbaa !23
  store i32 %t46, ptr %l8, !tbaa !23
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load i32, ptr %l3, !tbaa !23
  %t51 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecVoidRef(ptr %v0, ptr %t47, i32 %t48)
  store i1 %t51, ptr %l39
  br label %bb24
bb24:
  %t52 = load i1, ptr %l39, !tbaa !21
  br i1 %t52, label %bb25, label %bb26
bb25:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load i32, ptr %l6, !tbaa !23
  %t57 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eforeignRef(ptr %v0, ptr %t53, i32 %t54)
  store i1 %t57, ptr %l42
  br label %bb27
bb26:
  br label %bb40
bb27:
  %t58 = load i1, ptr %l42, !tbaa !21
  br i1 %t58, label %bb28, label %bb29
bb28:
  %t59 = load ptr, ptr %l2, !tbaa !29
  store ptr %t59, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Program", ptr %t65, i32 0, i32 2
  %t68 = load i32, ptr %l8, !tbaa !23
  %t71 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t67, i32 %t68)
  store i32 %t71, ptr %l49
  br label %bb31
bb31:
  %t72 = load i32, ptr %l49, !range !{i32 0, i32 33}
  %t74 = trunc i64 19 to i32
  %t75 = icmp eq i32 %t72, %t74
  br i1 %t75, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l52, !tbaa !21
  br label %bb35
bb33:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load i32, ptr %l7, !tbaa !23
  %t81 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplainStruct(ptr %v0, ptr %t77, i32 %t78, i64 0)
  store i1 %t81, ptr %l55
  br label %bb34
bb34:
  %t82 = load i1, ptr %l55, !tbaa !21
  store i1 %t82, ptr %l52, !tbaa !21
  br label %bb35
bb35:
  %t83 = load i1, ptr %l52, !tbaa !21
  br i1 %t83, label %bb36, label %bb37
bb36:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load ptr, ptr %l2, !tbaa !29
  %t86 = load i32, ptr %l3, !tbaa !23
  %t87 = load %"compiler/source:Span", ptr %l4
  %t92 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecBorrow(ptr %v0, ptr %v2, ptr %v3, ptr %t84, ptr %t85, i32 %t86, %"compiler/source:Span" %t87)
  store ptr %t92, ptr %l60
  br label %bb38
bb37:
  br label %bb39
bb38:
  %t93 = load ptr, ptr %l60, !tbaa !29
  store ptr %t93, ptr %rv
  br label %ret
bb39:
  store ptr null, ptr %rv
  br label %ret
bb40:
  %t96 = load ptr, ptr %l0, !tbaa !29
  store ptr %t96, ptr %l63, !tbaa !29
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load i32, ptr %l3, !tbaa !23
  %t101 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t97, i32 %t98)
  store i32 %t101, ptr %l66
  br label %bb41
bb41:
  %t102 = load ptr, ptr %l63, !tbaa !29
  %t103 = load i32, ptr %l66, !tbaa !23
  %t104 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t102, i32 %t103)
  store i32 %t104, ptr %l67
  br label %bb42
bb42:
  %t105 = load i32, ptr %l67, !tbaa !23
  store i32 %t105, ptr %l9, !tbaa !23
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/check:Checker", ptr %t106, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t111 = getelementptr %"compiler/generic:Program", ptr %t109, i32 0, i32 2
  %t112 = load i32, ptr %l9, !tbaa !23
  %t115 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t111, i32 %t112)
  store i32 %t115, ptr %l72
  br label %bb43
bb43:
  %t116 = load i32, ptr %l72, !range !{i32 0, i32 33}
  %t118 = trunc i64 19 to i32
  %t119 = icmp eq i32 %t116, %t118
  br i1 %t119, label %bb44, label %bb45
bb44:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load i32, ptr %l6, !tbaa !23
  %t125 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisCStrRef(ptr %v0, ptr %t121, i32 %t122)
  store i1 %t125, ptr %l78
  br label %bb46
bb45:
  store i1 false, ptr %l75, !tbaa !21
  br label %bb47
bb46:
  %t126 = load i1, ptr %l78, !tbaa !21
  store i1 %t126, ptr %l75, !tbaa !21
  br label %bb47
bb47:
  %t127 = load i1, ptr %l75, !tbaa !21
  br i1 %t127, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s8
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/check:Checker", ptr %t128, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !29
  %t133 = getelementptr %"compiler/generic:Program", ptr %t131, i32 0, i32 2
  %t134 = load i32, ptr %l9, !tbaa !23
  %t137 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t133, i32 %t134)
  store i32 %t137, ptr %l83
  br label %bb50
bb49:
  br label %bb59
bb50:
  %t138 = load i32, ptr %l83, !tbaa !23
  store i32 %t138, ptr %l10, !tbaa !23
  %t139 = load i32, ptr %l10, !tbaa !23
  store i32 %t139, ptr %l84, !tbaa !23
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t142 = getelementptr %"compiler/check:Checker", ptr %t140, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !29
  %t145 = getelementptr %"compiler/generic:Program", ptr %t143, i32 0, i32 2
  %t147 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s8, ptr %t145, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store i32 %t147, ptr %l88
  br label %bb51
bb51:
  %t148 = load i32, ptr %l84, !tbaa !23
  %t149 = load i32, ptr %l88, !tbaa !23
  %t150 = icmp eq i32 %t148, %t149
  br i1 %t150, label %bb52, label %bb53
bb52:
  store i1 true, ptr %l90, !tbaa !21
  br label %bb55
bb53:
  %t152 = load i32, ptr %l10, !tbaa !23
  store i32 %t152, ptr %l91, !tbaa !23
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t155 = getelementptr %"compiler/check:Checker", ptr %t153, i32 0, i32 1
  %t156 = load ptr, ptr %t155, !tbaa !29
  %t158 = getelementptr %"compiler/generic:Program", ptr %t156, i32 0, i32 2
  %t160 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s8, ptr %t158, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store i32 %t160, ptr %l95
  br label %bb54
bb54:
  %t161 = load i32, ptr %l91, !tbaa !23
  %t162 = load i32, ptr %l95, !tbaa !23
  %t163 = icmp eq i32 %t161, %t162
  store i1 %t163, ptr %l90, !tbaa !21
  br label %bb55
bb55:
  %t165 = load i1, ptr %l90, !tbaa !21
  br i1 %t165, label %bb56, label %bb57
bb56:
  %t166 = load ptr, ptr %l2, !tbaa !29
  call void @__olang_scope_close(ptr %s8)
  store ptr %t166, ptr %rv
  br label %ret
bb57:
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s8)
  store ptr null, ptr %rv
  br label %ret
bb59:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load i32, ptr %l3, !tbaa !23
  %t174 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t170, i32 %t171)
  store i1 %t174, ptr %l102
  br label %bb60
bb60:
  %t175 = load i1, ptr %l102, !tbaa !21
  br i1 %t175, label %bb61, label %bb62
bb61:
  %t176 = load ptr, ptr %l0, !tbaa !29
  store ptr %t176, ptr %l104, !tbaa !29
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t178 = load i32, ptr %l3, !tbaa !23
  %t181 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t177, i32 %t178)
  store i32 %t181, ptr %l107
  br label %bb63
bb62:
  store i1 false, ptr %l103, !tbaa !21
  br label %bb65
bb63:
  %t182 = load ptr, ptr %l104, !tbaa !29
  %t183 = load i32, ptr %l107, !tbaa !23
  %t184 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecStruct(ptr %v0, ptr %t182, i32 %t183)
  store i1 %t184, ptr %l108
  br label %bb64
bb64:
  %t185 = load i1, ptr %l108, !tbaa !21
  store i1 %t185, ptr %l103, !tbaa !21
  br label %bb65
bb65:
  %t186 = load i1, ptr %l103, !tbaa !21
  br i1 %t186, label %bb66, label %bb67
bb66:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr %"compiler/check:Checker", ptr %t187, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !29
  %t192 = getelementptr %"compiler/generic:Program", ptr %t190, i32 0, i32 2
  %t193 = load i32, ptr %l8, !tbaa !23
  %t196 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t192, i32 %t193)
  store i32 %t196, ptr %l114
  br label %bb68
bb67:
  store i1 false, ptr %l109, !tbaa !21
  br label %bb69
bb68:
  %t197 = load i32, ptr %l114, !range !{i32 0, i32 33}
  %t199 = trunc i64 19 to i32
  %t200 = icmp eq i32 %t197, %t199
  store i1 %t200, ptr %l109, !tbaa !21
  br label %bb69
bb69:
  %t202 = load i1, ptr %l109, !tbaa !21
  br i1 %t202, label %bb70, label %bb71
bb70:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t205 = getelementptr %"compiler/check:Checker", ptr %t203, i32 0, i32 1
  %t206 = load ptr, ptr %t205, !tbaa !29
  %t208 = getelementptr %"compiler/generic:Program", ptr %t206, i32 0, i32 2
  %t209 = load i32, ptr %l8, !tbaa !23
  %t212 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t208, i32 %t209)
  store i32 %t212, ptr %l121
  br label %bb72
bb71:
  br label %bb84
bb72:
  %t213 = load i32, ptr %l121, !tbaa !23
  store i32 %t213, ptr %l11, !tbaa !23
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t216 = getelementptr %"compiler/check:Checker", ptr %t214, i32 0, i32 1
  %t217 = load ptr, ptr %t216, !tbaa !29
  %t219 = getelementptr %"compiler/generic:Program", ptr %t217, i32 0, i32 2
  store ptr %t219, ptr %l124, !tbaa !29
  %t220 = load i32, ptr %l11, !tbaa !23
  store i32 %t220, ptr %l125, !tbaa !23
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t222 = load i32, ptr %l3, !tbaa !23
  %t225 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t221, i32 %t222)
  store i32 %t225, ptr %l128
  br label %bb73
bb73:
  %t226 = load ptr, ptr %l124, !tbaa !29
  %t227 = load i32, ptr %l125, !tbaa !23
  %t228 = load i32, ptr %l128, !tbaa !23
  %t229 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t226, i32 %t227, i32 %t228)
  store i1 %t229, ptr %l129
  br label %bb74
bb74:
  %t230 = load i1, ptr %l129, !tbaa !21
  br i1 %t230, label %bb75, label %bb76
bb75:
  store i1 true, ptr %l130, !tbaa !21
  br label %bb79
bb76:
  %t231 = load ptr, ptr %l0, !tbaa !29
  store ptr %t231, ptr %l131, !tbaa !29
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t233 = load i32, ptr %l11, !tbaa !23
  %t236 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t232, i32 %t233)
  store i32 %t236, ptr %l134
  br label %bb77
bb77:
  %t237 = load ptr, ptr %l131, !tbaa !29
  %t238 = load i32, ptr %l134, !tbaa !23
  %t239 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecNumber(ptr %v0, ptr %t237, i32 %t238)
  store i1 %t239, ptr %l135
  br label %bb78
bb78:
  %t240 = load i1, ptr %l135, !tbaa !21
  store i1 %t240, ptr %l130, !tbaa !21
  br label %bb79
bb79:
  %t241 = load i1, ptr %l130, !tbaa !21
  br i1 %t241, label %bb80, label %bb81
bb80:
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t243 = load ptr, ptr %l2, !tbaa !29
  %t244 = load i32, ptr %l3, !tbaa !23
  %t245 = load %"compiler/source:Span", ptr %l4
  %t250 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecBorrow(ptr %v0, ptr %v2, ptr %v3, ptr %t242, ptr %t243, i32 %t244, %"compiler/source:Span" %t245)
  store ptr %t250, ptr %l140
  br label %bb82
bb81:
  br label %bb83
bb82:
  %t251 = load ptr, ptr %l140, !tbaa !29
  store ptr %t251, ptr %rv
  br label %ret
bb83:
  br label %bb84
bb84:
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t254 = load i32, ptr %l3, !tbaa !23
  %t257 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t253, i32 %t254)
  store i1 %t257, ptr %l144
  br label %bb85
bb85:
  %t258 = load i1, ptr %l144, !tbaa !21
  br i1 %t258, label %bb86, label %bb87
bb86:
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t260 = load i32, ptr %l6, !tbaa !23
  %t263 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecVoidRef(ptr %v0, ptr %t259, i32 %t260)
  store i1 %t263, ptr %l148
  br label %bb88
bb87:
  store i1 false, ptr %l145, !tbaa !21
  br label %bb89
bb88:
  %t264 = load i1, ptr %l148, !tbaa !21
  store i1 %t264, ptr %l145, !tbaa !21
  br label %bb89
bb89:
  %t265 = load i1, ptr %l145, !tbaa !21
  br i1 %t265, label %bb90, label %bb91
bb90:
  %t266 = load ptr, ptr %l0, !tbaa !29
  store ptr %t266, ptr %l150, !tbaa !29
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t268 = load i32, ptr %l3, !tbaa !23
  %t271 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t267, i32 %t268)
  store i32 %t271, ptr %l153
  br label %bb92
bb91:
  store i1 false, ptr %l149, !tbaa !21
  br label %bb98
bb92:
  %t272 = load ptr, ptr %l150, !tbaa !29
  %t273 = load i32, ptr %l153, !tbaa !23
  %t274 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecStruct(ptr %v0, ptr %t272, i32 %t273)
  store i1 %t274, ptr %l154
  br label %bb93
bb93:
  %t275 = load i1, ptr %l154, !tbaa !21
  br i1 %t275, label %bb94, label %bb95
bb94:
  store i1 true, ptr %l155, !tbaa !21
  br label %bb97
bb95:
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t277 = load i32, ptr %l3, !tbaa !23
  %t280 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eforeignRef(ptr %v0, ptr %t276, i32 %t277)
  store i1 %t280, ptr %l158
  br label %bb96
bb96:
  %t281 = load i1, ptr %l158, !tbaa !21
  store i1 %t281, ptr %l155, !tbaa !21
  br label %bb97
bb97:
  %t282 = load i1, ptr %l155, !tbaa !21
  store i1 %t282, ptr %l149, !tbaa !21
  br label %bb98
bb98:
  %t283 = load i1, ptr %l149, !tbaa !21
  br i1 %t283, label %bb99, label %bb100
bb99:
  %t284 = load ptr, ptr %l2, !tbaa !29
  store ptr %t284, ptr %rv
  br label %ret
bb100:
  br label %bb101
bb101:
  store ptr null, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecStruct(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %l8 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i32
  %l15 = alloca i1
  %l19 = alloca ptr
  %l22 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca i64
  %l29 = alloca ptr
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplainStruct(ptr %v0, ptr %t1, i32 %t2, i64 0)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load i32, ptr %l1, !tbaa !23
  %t12 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t8, i32 %t9)
  store i1 %t12, ptr %l8
  br label %bb5
bb5:
  %t13 = load i1, ptr %l8, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i32, ptr %l1, !tbaa !23
  %t18 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t14, i32 %t15)
  store i32 %t18, ptr %l12
  br label %bb8
bb7:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb9
bb8:
  %t19 = load i32, ptr %l12, !range !{i32 0, i32 6}
  %t21 = trunc i64 0 to i32
  %t22 = icmp eq i32 %t19, %t21
  store i1 %t22, ptr %l9, !tbaa !21
  br label %bb9
bb9:
  %t24 = load i1, ptr %l9, !tbaa !21
  br i1 %t24, label %bb10, label %bb11
bb10:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/check:Checker", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = getelementptr %"compiler/generic:Program", ptr %t28, i32 0, i32 0
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/load:Loader", ptr %t31, i32 0, i32 10
  store ptr %t33, ptr %l19, !tbaa !29
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/generic:Program", ptr %t37, i32 0, i32 2
  store ptr %t39, ptr %l22, !tbaa !29
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/check:Checker", ptr %t40, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = getelementptr %"compiler/generic:Program", ptr %t43, i32 0, i32 2
  %t46 = load i32, ptr %l1, !tbaa !23
  %t49 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t45, i32 %t46)
  store i32 %t49, ptr %l27
  br label %bb12
bb11:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb15
bb12:
  %t50 = load ptr, ptr %l22, !tbaa !29
  %t51 = load i32, ptr %l27, !tbaa !23
  %t52 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t50, i32 %t51)
  store i64 %t52, ptr %l28
  br label %bb13
bb13:
  %t53 = load ptr, ptr %l19, !tbaa !29
  %t54 = load i64, ptr %l28, !tbaa !24
  %t55 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t53, i64 %t54)
  store ptr %t55, ptr %l29
  br label %bb14
bb14:
  %t56 = load ptr, ptr %l29, !tbaa !29
  %t58 = getelementptr %"compiler/load:Module", ptr %t56, i32 0, i32 30
  %t59 = load i1, ptr %t58, !tbaa !21
  store i1 %t59, ptr %l15, !tbaa !21
  br label %bb15
bb15:
  %t61 = load i1, ptr %l15, !tbaa !21
  store i1 %t61, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalleeErrors(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i1
  %l14 = alloca i32
  %l19 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 5}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { i32 }, ptr %t12, i32 0, i32 0
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l3, !tbaa !23
  %t19 = sext i32 %t17 to i64
  %t22 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyErrors(ptr %v0, ptr %t16, i64 %t19)
  store i32 %t22, ptr %l14
  br label %bb6
bb6:
  %t23 = load i32, ptr %l14, !tbaa !23
  store i32 %t23, ptr %l4, !tbaa !23
  br label %bb13
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/generic:Program", ptr %t27, i32 0, i32 2
  %t33 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t29, i32 %a2)
  store i32 %t33, ptr %l19
  br label %bb11
bb11:
  %t34 = load i32, ptr %l19, !tbaa !23
  store i32 %t34, ptr %l4, !tbaa !23
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_27c62905650ee804_ddef4b1ccc198ce0)
  unreachable
bb13:
  %t35 = load i32, ptr %l4, !tbaa !23
  store i32 %t35, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaught(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca ptr
  %l16 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l24 = alloca i64
  %l28 = alloca i64
  %l31 = alloca i64
  %l52 = alloca i32
  %l61 = alloca i32
  %l75 = alloca i64
  %l77 = alloca i64
  %l82 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l19
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l19, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l20
  br label %bb2
bb2:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %l6
  %t7 = load i64, ptr %l1, !tbaa !24
  store i64 %t7, ptr %l7, !tbaa !24
  %t9 = load ptr, ptr %l4, !tbaa !29
  %t11 = getelementptr %"compiler/check:frame", ptr %t9, i32 0, i32 26
  %t13 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t11)
  store i64 %t13, ptr %l24
  br label %bb3
bb3:
  %t14 = load i64, ptr %l24, !tbaa !24
  store i64 %t14, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t15 = load i64, ptr %l8, !tbaa !24
  %t16 = load i64, ptr %l7, !tbaa !24
  %t19 = icmp sgt i64 %t15, %t16
  br i1 %t19, label %bb4, label %bb5
bb4:
  %t21 = load i64, ptr %l9, !tbaa !24
  %t23 = icmp sgt i64 %t21, 0
  br i1 %t23, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb9
bb6:
  %t25 = load i64, ptr %l8, !tbaa !24
  %t26 = load i64, ptr %l7, !tbaa !24
  %t29 = sub i64 %t25, %t26
  %t30 = load i64, ptr %l9, !tbaa !24
  %t33 = add i64 %t29, %t30
  %t35 = sub i64 %t33, 1
  %t36 = load i64, ptr %l9, !tbaa !24
  %t39 = sdiv i64 %t35, %t36
  store i64 %t39, ptr %l31, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb8
bb8:
  %t41 = load i64, ptr %l31, !tbaa !24
  store i64 %t41, ptr %l28, !tbaa !24
  br label %bb9
bb9:
  %t42 = load i64, ptr %l28, !tbaa !24
  store i64 %t42, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb10
bb10:
  %t43 = load i64, ptr %l11, !tbaa !24
  %t44 = load i64, ptr %l10, !tbaa !24
  %t47 = icmp slt i64 %t43, %t44
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb11, label %bb12
bb11:
  br label %bb25
bb12:
  br label %bb13
bb13:
  %t51 = load i64, ptr %l7, !tbaa !24
  %t52 = load i64, ptr %l11, !tbaa !24
  %t53 = load i64, ptr %l9, !tbaa !24
  %t56 = mul i64 %t52, %t53
  %t59 = add i64 %t51, %t56
  store i64 %t59, ptr %l12, !tbaa !24
  %t61 = load ptr, ptr %l4, !tbaa !29
  %t63 = getelementptr %"compiler/check:frame", ptr %t61, i32 0, i32 26
  %t64 = load i64, ptr %l12, !tbaa !24
  %t67 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t63, i64 %t64)
  store i32 %t67, ptr %l52
  br label %bb14
bb14:
  %t68 = load i32, ptr %l52, !tbaa !23
  store i32 %t68, ptr %l13, !tbaa !23
  %t69 = load i64, ptr %l12, !tbaa !24
  %t73 = icmp sge i64 %t69, %a2
  br i1 %t73, label %bb15, label %bb16
bb15:
  %t75 = load i32, ptr %l13, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l6, i32 %t75)
  br label %bb17
bb16:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load i32, ptr %l13, !tbaa !23
  %t84 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleft(ptr %v0, ptr %v1, ptr %t78, i32 %t79, ptr %a3)
  store i32 %t84, ptr %l61
  br label %bb18
bb17:
  br label %bb23
bb18:
  %t85 = load i32, ptr %l61, !tbaa !23
  store i32 %t85, ptr %l14, !tbaa !23
  %t86 = load i32, ptr %l14, !tbaa !23
  %t87 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t90 = icmp ne i32 %t86, %t87
  br i1 %t90, label %bb19, label %bb20
bb19:
  %t92 = load i32, ptr %l14, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l6, i32 %t92)
  br label %bb21
bb20:
  br label %bb22
bb21:
  %t95 = load i64, ptr %l5, !tbaa !24
  %t97 = add i64 %t95, 1
  store i64 %t97, ptr %l5, !tbaa !24
  br label %bb22
bb22:
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t99 = load i64, ptr %l11, !tbaa !24
  %t101 = add i64 %t99, 1
  store i64 %t101, ptr %l11, !tbaa !24
  br label %bb10
bb25:
  %t103 = load ptr, ptr %l4, !tbaa !29
  %t105 = getelementptr %"compiler/check:frame", ptr %t103, i32 0, i32 26
  %t106 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eTruncate_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t105, i64 %t106)
  br label %bb26
bb26:
  store ptr %l6, ptr %l15, !tbaa !29
  store i64 0, ptr %l16, !tbaa !24
  br label %bb27
bb27:
  %t110 = load i64, ptr %l16, !tbaa !24
  store i64 %t110, ptr %l75, !tbaa !24
  %t111 = load ptr, ptr %l15, !tbaa !29
  %t113 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t111)
  store i64 %t113, ptr %l77
  br label %bb28
bb28:
  %t114 = load i64, ptr %l75, !tbaa !24
  %t115 = load i64, ptr %l77, !tbaa !24
  %t116 = icmp slt i64 %t114, %t115
  %t118 = xor i1 %t116, true
  br i1 %t118, label %bb29, label %bb30
bb29:
  br label %bb35
bb30:
  br label %bb31
bb31:
  %t120 = load ptr, ptr %l15, !tbaa !29
  %t121 = load i64, ptr %l16, !tbaa !24
  %t124 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t120, i64 %t121)
  store i32 %t124, ptr %l82
  br label %bb32
bb32:
  %t125 = load i32, ptr %l82, !tbaa !23
  %t126 = load ptr, ptr %l4, !tbaa !29
  %t128 = getelementptr %"compiler/check:frame", ptr %t126, i32 0, i32 26
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t128, i32 %t125)
  br label %bb33
bb33:
  br label %bb34
bb34:
  %t132 = load i64, ptr %l16, !tbaa !24
  %t134 = add i64 %t132, 1
  store i64 %t134, ptr %l16, !tbaa !24
  br label %bb27
bb35:
  %t136 = load i64, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t136, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econtractChecked(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca %"compiler/source:Span"
  %l12 = alloca i1
  %l16 = alloca i1
  %l17 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca i32
  %l25 = alloca i64
  %l27 = alloca i64
  %l32 = alloca i64
  %l34 = alloca i1
  %l38 = alloca i1
  %l45 = alloca ptr
  %l61 = alloca i1
  %l65 = alloca i1
  %l69 = alloca i1
  %l72 = alloca i1
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 106
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t3, i64 %t4)
  store i1 %t7, ptr %l12
  br label %bb1
bb1:
  %t8 = load i1, ptr %l12, !tbaa !21
  %t9 = xor i1 %t8, true
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i64, ptr %l1, !tbaa !24
  %t15 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehasContract(ptr %v0, ptr %t11, i64 %t12)
  store i1 %t15, ptr %l16
  br label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 105
  %t19 = load i64, ptr %l1, !tbaa !24
  %t22 = call { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aContractIn_H383d843b0981793a095b02d794e40659(ptr %v0, ptr %v0, ptr %t18, i64 %t19)
  %t23 = extractvalue { i32, ptr } %t22, 1
  %t24 = extractvalue { i32, ptr } %t22, 0
  store i32 %t24, ptr %l22
  %t25 = icmp ne i32 %t24, 0
  br i1 %t25, label %bb7, label %ok.26, !prof !99
ok.26:
  store ptr %t23, ptr %l21
  br label %bb6
bb6:
  %t27 = load ptr, ptr %l21, !tbaa !29
  store ptr %t27, ptr %l17, !tbaa !29
  br label %bb9
bb7:
  br label %bb8
bb8:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb9:
  %t28 = load ptr, ptr %l17, !tbaa !29
  store ptr %t28, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t31 = getelementptr %"compiler/typed:ContractInfo", ptr %t29, i32 0, i32 2
  store ptr %t31, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb10
bb10:
  %t33 = load i64, ptr %l5, !tbaa !24
  store i64 %t33, ptr %l25, !tbaa !24
  %t34 = load ptr, ptr %l4, !tbaa !29
  %t36 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t34)
  store i64 %t36, ptr %l27
  br label %bb11
bb11:
  %t37 = load i64, ptr %l25, !tbaa !24
  %t38 = load i64, ptr %l27, !tbaa !24
  %t39 = icmp slt i64 %t37, %t38
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb12, label %bb13
bb12:
  br label %bb21
bb13:
  br label %bb14
bb14:
  %t43 = load ptr, ptr %l4, !tbaa !29
  %t44 = load i64, ptr %l5, !tbaa !24
  %t47 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t43, i64 %t44)
  store i64 %t47, ptr %l32
  br label %bb15
bb15:
  %t48 = load i64, ptr %l32, !tbaa !24
  store i64 %t48, ptr %l6, !tbaa !24
  %t49 = load i1, ptr %l3, !tbaa !21
  br i1 %t49, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb19
bb17:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/check:Checker", ptr %t51, i32 0, i32 117
  %t54 = load i64, ptr %l6, !tbaa !24
  %t57 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t53, i64 %t54)
  store i1 %t57, ptr %l38
  br label %bb18
bb18:
  %t58 = load i1, ptr %l38, !tbaa !21
  store i1 %t58, ptr %l34, !tbaa !21
  br label %bb19
bb19:
  %t59 = load i1, ptr %l34, !tbaa !21
  store i1 %t59, ptr %l3, !tbaa !21
  br label %bb20
bb20:
  %t60 = load i64, ptr %l5, !tbaa !24
  %t62 = add i64 %t60, 1
  store i64 %t62, ptr %l5, !tbaa !24
  br label %bb10
bb21:
  %t64 = load i1, ptr %l3, !tbaa !21
  %t66 = xor i1 %t64, true
  br i1 %t66, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb23:
  br label %bb24
bb24:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i64, ptr %l1, !tbaa !24
  %t72 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectSourceOf(ptr %v0, ptr %s0, ptr %t68, i64 %t69)
  store ptr %t72, ptr %l45
  br label %bb25
bb25:
  %t73 = load ptr, ptr %l45, !tbaa !29
  store ptr %t73, ptr %l7, !tbaa !29
  %t74 = load ptr, ptr %l7, !tbaa !29
  %t76 = icmp eq ptr %t74, null
  br i1 %t76, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb27:
  br label %bb28
bb28:
  %t78 = load ptr, ptr %l7, !tbaa !29
  %t80 = getelementptr %"compiler/check:ctSource", ptr %t78, i32 0, i32 0
  %t81 = load ptr, ptr %t80, !tbaa !29
  %t83 = getelementptr %"compiler/ast:ContractBlock", ptr %t81, i32 0, i32 0
  %t84 = load %"compiler/source:Span", ptr %t83
  store %"compiler/source:Span" %t84, ptr %l8
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/check:Checker", ptr %t86, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t91 = getelementptr %"compiler/generic:Program", ptr %t89, i32 0, i32 0
  %t92 = load ptr, ptr %t91, !tbaa !29
  %t94 = getelementptr %"compiler/load:Loader", ptr %t92, i32 0, i32 4
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t96 = load ptr, ptr %l2, !tbaa !29
  %t98 = getelementptr %"compiler/typed:ContractInfo", ptr %t96, i32 0, i32 1
  %t99 = load i64, ptr %t98, !tbaa !24
  %t100 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 0
  %t101 = load i32, ptr %t100, !tbaa !23
  %t103 = sext i32 %t101 to i64
  %t104 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 1
  %t105 = load i32, ptr %t104, !tbaa !23
  %t107 = sext i32 %t105 to i64
  %t112 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorWithin(ptr %v0, ptr %t95, i64 %t99, i64 %t103, i64 %t107, i64 0)
  store i1 %t112, ptr %l61
  br label %bb29
bb29:
  %t113 = load i1, ptr %l61, !tbaa !21
  br i1 %t113, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb31:
  br label %bb32
bb32:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/check:Checker", ptr %t114, i32 0, i32 106
  %t117 = load i64, ptr %l1, !tbaa !24
  %t120 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eRemove_3cI64_2c_20Bool_3e(ptr %v0, ptr %t116, i64 %t117)
  store i1 %t120, ptr %l65
  br label %bb33
bb33:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/check:Checker", ptr %t121, i32 0, i32 105
  %t124 = load i64, ptr %l1, !tbaa !24
  %t127 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aContractIn_H044304b59760c17b661e6227d2ca1ac9(ptr %v0, ptr %t123, i64 %t124)
  store i1 %t127, ptr %l69
  br label %bb34
bb34:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load i64, ptr %l1, !tbaa !24
  %t132 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehasContract(ptr %v0, ptr %t128, i64 %t129)
  store i1 %t132, ptr %l72
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclsIf(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l8 = alloca i1
  %l13 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca i64
  %l36 = alloca ptr
  %l37 = alloca i64
  %l50 = alloca i1
  %l55 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t2 = load i64, ptr %l4, !tbaa !24
  %t5 = icmp eq i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = getelementptr %"compiler/ast:TopIf", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = icmp eq ptr %t10, null
  %t14 = xor i1 %t12, true
  store i1 %t14, ptr %l8, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb3
bb3:
  %t16 = load i1, ptr %l8, !tbaa !21
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t19 = getelementptr %"compiler/ast:TopIf", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = icmp eq ptr %t20, null
  br i1 %t22, label %bb6, label %bb7
bb5:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb9
bb6:
  call void @__olang_check_failed(ptr @olang_loc_cd06913e2f5eb0d4_3977f9e98d534b08)
  unreachable
bb7:
  br label %bb8
bb8:
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t26 = getelementptr %"compiler/ast:TopIf", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t30 = getelementptr %"compiler/ast:TopBranch", ptr %t27, i32 0, i32 1
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t35 = icmp sgt i64 %t33, 0
  store i1 %t35, ptr %l13, !tbaa !21
  br label %bb9
bb9:
  %t37 = load i1, ptr %l13, !tbaa !21
  br i1 %t37, label %bb10, label %bb11
bb10:
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l23, !tbaa !29
  %t39 = load i64, ptr %l1, !tbaa !24
  store i64 %t39, ptr %l24, !tbaa !24
  %t40 = load ptr, ptr %l2, !tbaa !29
  %t42 = getelementptr %"compiler/ast:TopIf", ptr %t40, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = icmp eq ptr %t43, null
  br i1 %t45, label %bb12, label %bb13
bb11:
  br label %bb16
bb12:
  call void @__olang_check_failed(ptr @olang_loc_cd06913e2f5eb0d4_3977f9e98d534b08)
  unreachable
bb13:
  br label %bb14
bb14:
  %t47 = load ptr, ptr %l2, !tbaa !29
  %t49 = getelementptr %"compiler/ast:TopIf", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t53 = getelementptr %"compiler/ast:TopBranch", ptr %t50, i32 0, i32 1
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !27
  %t55 = load ptr, ptr %l23, !tbaa !29
  %t56 = load i64, ptr %l24, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edecls(ptr %v0, ptr %v1, ptr %t55, i64 %t56, { i64, ptr } %t54)
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t58 = load ptr, ptr %l2, !tbaa !29
  %t60 = getelementptr %"compiler/ast:TopIf", ptr %t58, i32 0, i32 2
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = icmp eq ptr %t61, null
  %t65 = xor i1 %t63, true
  br i1 %t65, label %bb17, label %bb18
bb17:
  %t67 = load ptr, ptr %l0, !tbaa !29
  store ptr %t67, ptr %l36, !tbaa !29
  %t68 = load i64, ptr %l1, !tbaa !24
  store i64 %t68, ptr %l37, !tbaa !24
  %t69 = load ptr, ptr %l2, !tbaa !29
  %t71 = getelementptr %"compiler/ast:TopIf", ptr %t69, i32 0, i32 2
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t74 = icmp eq ptr %t72, null
  br i1 %t74, label %bb19, label %bb20
bb18:
  br label %bb23
bb19:
  call void @__olang_check_failed(ptr @olang_loc_40b85daad0e541e3_3cdd9f152c967927)
  unreachable
bb20:
  br label %bb21
bb21:
  %t76 = load ptr, ptr %l2, !tbaa !29
  %t78 = getelementptr %"compiler/ast:TopIf", ptr %t76, i32 0, i32 2
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t80 = load i64, ptr %l3, !tbaa !24
  %t81 = load i64, ptr %l4, !tbaa !24
  %t83 = add i64 %t81, 1
  %t84 = load ptr, ptr %l36, !tbaa !29
  %t85 = load i64, ptr %l37, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclsIf(ptr %v0, ptr %v1, ptr %t84, i64 %t85, ptr %t79, i64 %t80, i64 %t83)
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t89 = load ptr, ptr %l2, !tbaa !29
  %t91 = getelementptr %"compiler/ast:TopIf", ptr %t89, i32 0, i32 3
  %t92 = load ptr, ptr %t91, !tbaa !29
  %t94 = icmp eq ptr %t92, null
  %t96 = xor i1 %t94, true
  br i1 %t96, label %bb24, label %bb25
bb24:
  %t98 = load i64, ptr %l3, !tbaa !24
  %t99 = load i64, ptr %l4, !tbaa !24
  %t101 = add i64 %t99, 1
  %t104 = icmp eq i64 %t98, %t101
  store i1 %t104, ptr %l50, !tbaa !21
  br label %bb26
bb25:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb26
bb26:
  %t106 = load i1, ptr %l50, !tbaa !21
  br i1 %t106, label %bb27, label %bb28
bb27:
  %t107 = load ptr, ptr %l2, !tbaa !29
  %t109 = getelementptr %"compiler/ast:TopIf", ptr %t107, i32 0, i32 3
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = icmp eq ptr %t110, null
  br i1 %t112, label %bb29, label %bb30
bb28:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb32
bb29:
  call void @__olang_check_failed(ptr @olang_loc_17f9884e4c50a862_1761fccd5f6f3c76)
  unreachable
bb30:
  br label %bb31
bb31:
  %t114 = load ptr, ptr %l2, !tbaa !29
  %t116 = getelementptr %"compiler/ast:TopIf", ptr %t114, i32 0, i32 3
  %t117 = load ptr, ptr %t116, !tbaa !29
  %t120 = getelementptr %"compiler/ast:TopBranch", ptr %t117, i32 0, i32 1
  %t121 = load { i64, ptr }, ptr %t120, !tbaa !27
  %t123 = extractvalue { i64, ptr } %t121, 0
  %t125 = icmp sgt i64 %t123, 0
  store i1 %t125, ptr %l55, !tbaa !21
  br label %bb32
bb32:
  %t127 = load i1, ptr %l55, !tbaa !21
  br i1 %t127, label %bb33, label %bb34
bb33:
  %t128 = load ptr, ptr %l0, !tbaa !29
  store ptr %t128, ptr %l65, !tbaa !29
  %t129 = load i64, ptr %l1, !tbaa !24
  store i64 %t129, ptr %l66, !tbaa !24
  %t130 = load ptr, ptr %l2, !tbaa !29
  %t132 = getelementptr %"compiler/ast:TopIf", ptr %t130, i32 0, i32 3
  %t133 = load ptr, ptr %t132, !tbaa !29
  %t135 = icmp eq ptr %t133, null
  br i1 %t135, label %bb35, label %bb36
bb34:
  br label %bb39
bb35:
  call void @__olang_check_failed(ptr @olang_loc_17f9884e4c50a862_1761fccd5f6f3c76)
  unreachable
bb36:
  br label %bb37
bb37:
  %t137 = load ptr, ptr %l2, !tbaa !29
  %t139 = getelementptr %"compiler/ast:TopIf", ptr %t137, i32 0, i32 3
  %t140 = load ptr, ptr %t139, !tbaa !29
  %t143 = getelementptr %"compiler/ast:TopBranch", ptr %t140, i32 0, i32 1
  %t144 = load { i64, ptr }, ptr %t143, !tbaa !27
  %t145 = load ptr, ptr %l65, !tbaa !29
  %t146 = load i64, ptr %l66, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edecls(ptr %v0, ptr %v1, ptr %t145, i64 %t146, { i64, ptr } %t144)
  br label %bb38
bb38:
  br label %bb39
bb39:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edestructs(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i32
  %l12 = alloca i1
  %l13 = alloca i1
  %l18 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l5, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t11 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t7, i32 %a1)
  store i32 %t11, ptr %l8
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l5, !tbaa !29
  %t13 = load i32, ptr %l8, !tbaa !23
  %t14 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t14, ptr %l9
  br label %bb2
bb2:
  %t15 = load i32, ptr %l9, !tbaa !23
  store i32 %t15, ptr %l2, !tbaa !23
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l2, !tbaa !23
  %t20 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %t16, i32 %t17)
  store i1 %t20, ptr %l12
  br label %bb3
bb3:
  %t21 = load i1, ptr %l12, !tbaa !21
  br i1 %t21, label %bb4, label %bb5
bb4:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 2
  %t28 = load i32, ptr %l2, !tbaa !23
  %t31 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %t27, i32 %t28)
  store i1 %t31, ptr %l18
  br label %bb6
bb5:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb7
bb6:
  %t32 = load i1, ptr %l18, !tbaa !21
  store i1 %t32, ptr %l13, !tbaa !21
  br label %bb7
bb7:
  %t33 = load i1, ptr %l13, !tbaa !21
  store i1 %t33, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropTaken(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i64
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l12 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca i64
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca i64
  %l23 = alloca i64
  %l26 = alloca i64
  %l46 = alloca i32
  %l50 = alloca i32
  %l61 = alloca i64
  %l63 = alloca i64
  %l68 = alloca i32
  %s0 = alloca %olang.scope
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l16
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l4
  %t3 = load i64, ptr %l2, !tbaa !24
  store i64 %t3, ptr %l5, !tbaa !24
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t5)
  store i64 %t7, ptr %l19
  br label %bb2
bb2:
  %t8 = load i64, ptr %l19, !tbaa !24
  store i64 %t8, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t9 = load i64, ptr %l6, !tbaa !24
  %t10 = load i64, ptr %l5, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load i64, ptr %l7, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb8
bb5:
  %t19 = load i64, ptr %l6, !tbaa !24
  %t20 = load i64, ptr %l5, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l7, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l7, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l26, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb7
bb7:
  %t35 = load i64, ptr %l26, !tbaa !24
  store i64 %t35, ptr %l23, !tbaa !24
  br label %bb8
bb8:
  %t36 = load i64, ptr %l23, !tbaa !24
  store i64 %t36, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb9
bb9:
  %t37 = load i64, ptr %l9, !tbaa !24
  %t38 = load i64, ptr %l8, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb10, label %bb11
bb10:
  br label %bb20
bb11:
  br label %bb12
bb12:
  %t45 = load i64, ptr %l5, !tbaa !24
  %t46 = load i64, ptr %l9, !tbaa !24
  %t47 = load i64, ptr %l7, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t59 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t55, i64 %t53)
  store i32 %t59, ptr %l46
  br label %bb13
bb13:
  %t60 = load i32, ptr %l46, !tbaa !23
  %t67 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleft(ptr %v0, ptr %v2, ptr %a0, i32 %t60, ptr %a3)
  store i32 %t67, ptr %l50
  br label %bb14
bb14:
  %t68 = load i32, ptr %l50, !tbaa !23
  store i32 %t68, ptr %l12, !tbaa !23
  %t69 = load i32, ptr %l12, !tbaa !23
  %t70 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t73 = icmp ne i32 %t69, %t70
  br i1 %t73, label %bb15, label %bb16
bb15:
  %t75 = load i32, ptr %l12, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l4, i32 %t75)
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t78 = load i64, ptr %l9, !tbaa !24
  %t80 = add i64 %t78, 1
  store i64 %t80, ptr %l9, !tbaa !24
  br label %bb9
bb20:
  %t82 = load ptr, ptr %l1, !tbaa !29
  %t83 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eTruncate_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t82, i64 %t83)
  br label %bb21
bb21:
  store ptr %l4, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb22
bb22:
  %t87 = load i64, ptr %l14, !tbaa !24
  store i64 %t87, ptr %l61, !tbaa !24
  %t88 = load ptr, ptr %l13, !tbaa !29
  %t90 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t88)
  store i64 %t90, ptr %l63
  br label %bb23
bb23:
  %t91 = load i64, ptr %l61, !tbaa !24
  %t92 = load i64, ptr %l63, !tbaa !24
  %t93 = icmp slt i64 %t91, %t92
  %t95 = xor i1 %t93, true
  br i1 %t95, label %bb24, label %bb25
bb24:
  br label %bb30
bb25:
  br label %bb26
bb26:
  %t97 = load ptr, ptr %l13, !tbaa !29
  %t98 = load i64, ptr %l14, !tbaa !24
  %t101 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t97, i64 %t98)
  store i32 %t101, ptr %l68
  br label %bb27
bb27:
  %t102 = load i32, ptr %l68, !tbaa !23
  %t103 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t103, i32 %t102)
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t107 = load i64, ptr %l14, !tbaa !24
  %t109 = add i64 %t107, 1
  store i64 %t109, ptr %l14, !tbaa !24
  br label %bb22
bb30:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eequality(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca ptr
  %lp8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %lp20 = alloca ptr
  %lp21 = alloca ptr
  %lp22 = alloca ptr
  %lp23 = alloca ptr
  %lp24 = alloca ptr
  %lp25 = alloca ptr
  %lp26 = alloca ptr
  %lp27 = alloca ptr
  %lp28 = alloca ptr
  %lp29 = alloca ptr
  %lp30 = alloca ptr
  %l31 = alloca i32
  %lp32 = alloca ptr
  %lp33 = alloca ptr
  %l34 = alloca i64
  %lp35 = alloca ptr
  %l38 = alloca i32
  %l41 = alloca i32
  %l45 = alloca i1
  %l52 = alloca ptr
  %l55 = alloca ptr
  %l58 = alloca i32
  %l59 = alloca i1
  %l60 = alloca i1
  %l63 = alloca ptr
  %l66 = alloca i32
  %l67 = alloca i32
  %l70 = alloca ptr
  %l71 = alloca %"compiler/source:Span"
  %l74 = alloca i32
  %l75 = alloca ptr
  %l76 = alloca ptr
  %l77 = alloca %"compiler/source:Span"
  %l78 = alloca i32
  %l81 = alloca i32
  %l87 = alloca ptr
  %l93 = alloca ptr
  %l96 = alloca i32
  %l99 = alloca i32
  %l105 = alloca i1
  %l110 = alloca i1
  %l111 = alloca ptr
  %l112 = alloca ptr
  %l115 = alloca i1
  %l116 = alloca i1
  %l119 = alloca i1
  %l120 = alloca i32
  %l126 = alloca i32
  %l129 = alloca ptr
  %l132 = alloca i32
  %l137 = alloca i1
  %l138 = alloca ptr
  %l139 = alloca ptr
  %l142 = alloca i1
  %l143 = alloca i1
  %l146 = alloca i1
  %l147 = alloca i32
  %l153 = alloca i32
  %l156 = alloca ptr
  %l159 = alloca i32
  %l165 = alloca i32
  %l168 = alloca i1
  %l173 = alloca i32
  %l176 = alloca i1
  %l179 = alloca ptr
  %l184 = alloca i32
  %l189 = alloca i32
  %l190 = alloca i1
  %l193 = alloca ptr
  %l198 = alloca i32
  %l199 = alloca i32
  %l200 = alloca ptr
  %l201 = alloca ptr
  %l204 = alloca i1
  %l205 = alloca i1
  %l208 = alloca i1
  %l209 = alloca i32
  %l215 = alloca i32
  %l218 = alloca ptr
  %l219 = alloca ptr
  %l220 = alloca ptr
  %l223 = alloca i1
  %l224 = alloca i1
  %l227 = alloca i1
  %l228 = alloca i32
  %l234 = alloca i32
  %l237 = alloca ptr
  %l240 = alloca i32
  %l243 = alloca i32
  %l250 = alloca ptr
  %l251 = alloca %"compiler/source:Span"
  %l254 = alloca { i64, ptr }
  %l255 = alloca { i64, ptr }
  %l258 = alloca { i64, ptr }
  %l260 = alloca %"compiler/msgs:Msg"
  %l261 = alloca i64
  %l265 = alloca ptr
  %l268 = alloca i64
  %l274 = alloca ptr
  %l275 = alloca ptr
  %l279 = alloca %"compiler/source:Span"
  %l283 = alloca { i64, [3 x i64] }
  %l286 = alloca { i64, ptr }
  %l288 = alloca %"compiler/msgs:Msg"
  %l289 = alloca i64
  %l293 = alloca ptr
  %l296 = alloca i1
  %l299 = alloca i1
  %l300 = alloca i1
  %l303 = alloca i1
  %l304 = alloca i1
  %l309 = alloca i1
  %l310 = alloca i1
  %l315 = alloca i1
  %l318 = alloca i64
  %l324 = alloca i64
  %l339 = alloca i64
  %l349 = alloca ptr
  %l350 = alloca %"compiler/source:Span"
  %l351 = alloca i32
  %l352 = alloca i32
  %l356 = alloca ptr
  %l360 = alloca ptr
  %l362 = alloca ptr
  %l363 = alloca ptr
  %l364 = alloca %"compiler/source:Span"
  %l365 = alloca i32
  %l366 = alloca i32
  %l370 = alloca ptr
  %l374 = alloca ptr
  %l376 = alloca ptr
  %l377 = alloca ptr
  %l378 = alloca %"compiler/source:Span"
  %l379 = alloca i32
  %l380 = alloca i32
  %l384 = alloca ptr
  %l388 = alloca ptr
  %l390 = alloca ptr
  %l391 = alloca ptr
  %l392 = alloca %"compiler/source:Span"
  %l393 = alloca %"compiler/source:Span"
  %l398 = alloca i32
  %l404 = alloca ptr
  %l405 = alloca ptr
  %l406 = alloca %"compiler/source:Span"
  %l407 = alloca %"compiler/source:Span"
  %l412 = alloca i32
  %l418 = alloca ptr
  %l419 = alloca ptr
  %l420 = alloca %"compiler/source:Span"
  %l421 = alloca %"compiler/source:Span"
  %l422 = alloca i64
  %l424 = alloca ptr
  %l427 = alloca { i64, ptr }
  %l430 = alloca { i64, ptr }
  %l434 = alloca ptr
  %l435 = alloca %"compiler/source:Span"
  %l436 = alloca i32
  %l437 = alloca ptr
  %l441 = alloca ptr
  %l444 = alloca %"compiler/typed:Cond"
  %l447 = alloca %"compiler/source:Span"
  %l448 = alloca i32
  %l452 = alloca { i64, ptr }
  %l453 = alloca %"compiler/source:Span"
  %l454 = alloca i32
  %l459 = alloca %"compiler/typed:Cond"
  %l463 = alloca %"compiler/typed:Seq"
  %l468 = alloca ptr
  %l472 = alloca ptr
  %l476 = alloca ptr
  %l477 = alloca %"compiler/source:Span"
  %l478 = alloca %"compiler/source:Span"
  %l479 = alloca i64
  %l481 = alloca ptr
  %l484 = alloca { i64, ptr }
  %l487 = alloca { i64, ptr }
  %l491 = alloca ptr
  %l494 = alloca ptr
  %l498 = alloca ptr
  %l502 = alloca i1
  %l503 = alloca i1
  %l506 = alloca i1
  %l507 = alloca i1
  %l510 = alloca i1
  %l511 = alloca i1
  %l514 = alloca i1
  %l515 = alloca i1
  %l520 = alloca i32
  %l530 = alloca ptr
  %l533 = alloca ptr
  %l537 = alloca ptr
  %l541 = alloca i1
  %l547 = alloca ptr
  %l555 = alloca ptr
  %l558 = alloca ptr
  %l562 = alloca ptr
  %l566 = alloca i1
  %l567 = alloca i1
  %l570 = alloca i1
  %l571 = alloca i32
  %l577 = alloca i32
  %l581 = alloca i1
  %l582 = alloca i1
  %l585 = alloca i1
  %l586 = alloca i1
  %l591 = alloca i1
  %l592 = alloca i1
  %l597 = alloca i1
  %l602 = alloca i32
  %l607 = alloca ptr
  %l612 = alloca ptr
  %l615 = alloca i64
  %l622 = alloca ptr
  %l623 = alloca %"compiler/source:Span"
  %l624 = alloca i32
  %l628 = alloca ptr
  %l632 = alloca { i64, ptr }
  %l633 = alloca ptr
  %l636 = alloca ptr
  %l640 = alloca ptr
  %s1 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %rv = alloca ptr
  %t581 = alloca { i64, [2 x i64] }, align 8
  %t600 = alloca { i64, [3 x i64] }, align 8
  %t617 = alloca { i64, [2 x i64] }, align 8
  %t636 = alloca { i64, [3 x i64] }, align 8
  %t751 = alloca { i64, [4 x i64] }, align 8
  %t787 = alloca { i64, [4 x i64] }, align 8
  %t865 = alloca { i64, [5 x i64] }, align 8
  %t901 = alloca { i64, [5 x i64] }, align 8
  %t918 = alloca { i64, [5 x i64] }, align 8
  %t1263 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t1)
  store i32 %t4, ptr %l38
  br label %bb1
bb1:
  %t5 = load i32, ptr %l38, !tbaa !23
  store i32 %t5, ptr %l5, !tbaa !23
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t9 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t6)
  store i32 %t9, ptr %l41
  br label %bb2
bb2:
  %t10 = load i32, ptr %l41, !tbaa !23
  store i32 %t10, ptr %l6, !tbaa !23
  %t11 = load i32, ptr %l5, !tbaa !23
  %t12 = load i32, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  %t15 = icmp eq i32 %t11, %t12
  br i1 %t15, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l45, !tbaa !21
  br label %bb5
bb4:
  %t17 = load i32, ptr %l6, !tbaa !23
  %t18 = load i32, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  %t21 = icmp eq i32 %t17, %t18
  store i1 %t21, ptr %l45, !tbaa !21
  br label %bb5
bb5:
  %t23 = load i1, ptr %l45, !tbaa !21
  br i1 %t23, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t24 = load i32, ptr %l5, !tbaa !23
  %t25 = load i32, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  %t28 = icmp ne i32 %t24, %t25
  br i1 %t28, label %bb8, label %bb9
bb7:
  br label %bb29
bb8:
  %t30 = load ptr, ptr %l3, !tbaa !29
  store ptr %t30, ptr %l52, !tbaa !29
  br label %bb10
bb9:
  %t32 = load ptr, ptr %l4, !tbaa !29
  store ptr %t32, ptr %l52, !tbaa !29
  br label %bb10
bb10:
  %t34 = load ptr, ptr %l52, !tbaa !29
  store ptr %t34, ptr %l7, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l55, !tbaa !29
  %t36 = load ptr, ptr %l7, !tbaa !29
  %t38 = load ptr, ptr @__olang_prog_scope
  %t40 = call i32 @compiler_2fcheck_2etypeOf(ptr %t38, ptr %t36)
  store i32 %t40, ptr %l58
  br label %bb11
bb11:
  %t41 = load ptr, ptr %l55, !tbaa !29
  %t42 = load i32, ptr %l58, !tbaa !23
  %t43 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t41, i32 %t42)
  store i1 %t43, ptr %l59
  br label %bb12
bb12:
  %t44 = load i1, ptr %l59, !tbaa !21
  br i1 %t44, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb17
bb14:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/check:Checker", ptr %t45, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t50 = getelementptr %"compiler/generic:Program", ptr %t48, i32 0, i32 2
  store ptr %t50, ptr %l63, !tbaa !29
  %t51 = load ptr, ptr %l7, !tbaa !29
  %t53 = load ptr, ptr @__olang_prog_scope
  %t55 = call i32 @compiler_2fcheck_2etypeOf(ptr %t53, ptr %t51)
  store i32 %t55, ptr %l66
  br label %bb15
bb15:
  %t56 = load ptr, ptr %l63, !tbaa !29
  %t57 = load i32, ptr %l66, !tbaa !23
  %t58 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t56, i32 %t57)
  store i32 %t58, ptr %l67
  br label %bb16
bb16:
  %t59 = load i32, ptr %l67, !range !{i32 0, i32 33}
  %t61 = trunc i64 21 to i32
  %t62 = icmp eq i32 %t59, %t61
  store i1 %t62, ptr %l60, !tbaa !21
  br label %bb17
bb17:
  %t64 = load i1, ptr %l60, !tbaa !21
  br i1 %t64, label %bb18, label %bb19
bb18:
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l70, !tbaa !29
  %t66 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t66, ptr %l71
  %t67 = load ptr, ptr %l7, !tbaa !29
  %t69 = load ptr, ptr @__olang_prog_scope
  %t71 = call i32 @compiler_2fcheck_2etypeOf(ptr %t69, ptr %t67)
  store i32 %t71, ptr %l74
  br label %bb20
bb19:
  br label %bb26
bb20:
  %t72 = load ptr, ptr %l70, !tbaa !29
  %t73 = load %"compiler/source:Span", ptr %l71
  %t74 = load i32, ptr %l74, !tbaa !23
  %t75 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t72, %"compiler/source:Span" %t73, i32 %t74, i64 0)
  store ptr %t75, ptr %l75
  br label %bb21
bb21:
  %t76 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 8, i64 8)
  store ptr %t76, ptr %lp8
  %t77 = load ptr, ptr %l75, !tbaa !29
  %t78 = load ptr, ptr %lp8
  store ptr %t77, ptr %t78, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  store ptr %t79, ptr %l76, !tbaa !29
  %t80 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t80, ptr %l77
  %t81 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t81, ptr %l78, !tbaa !23
  %t82 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t84 = trunc i64 78 to i32
  %t85 = icmp eq i32 %t82, %t84
  br i1 %t85, label %bb22, label %bb23
bb22:
  store i32 19, ptr %l81
  br label %bb24
bb23:
  store i32 14, ptr %l81
  br label %bb24
bb24:
  %t89 = load ptr, ptr %l7, !tbaa !29
  %t90 = load ptr, ptr %lp8
  %t91 = load ptr, ptr %t90, !tbaa !29
  %t93 = load ptr, ptr @__olang_prog_scope
  %t94 = load ptr, ptr %l76, !tbaa !29
  %t95 = load %"compiler/source:Span", ptr %l77
  %t96 = load i32, ptr %l78, !tbaa !23
  %t97 = load i32, ptr %l81, !range !{i32 0, i32 43}
  %t100 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t93, ptr %v3, ptr %v3, ptr %t94, %"compiler/source:Span" %t95, i32 %t96, i32 %t97, ptr %t89, ptr %t91)
  store ptr %t100, ptr %l87
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s1)
  %t101 = load ptr, ptr %l87, !tbaa !29
  store ptr %t101, ptr %rv
  br label %ret
bb26:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s1, ptr %t102, %"compiler/source:Span" %t103, { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d2, i32 0, i32 1) })
  br label %bb27
bb27:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load %"compiler/source:Span", ptr %l1
  %t108 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t112 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t106, %"compiler/source:Span" %t107, i32 %t108, i64 0)
  store ptr %t112, ptr %l93
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s1)
  %t113 = load ptr, ptr %l93, !tbaa !29
  store ptr %t113, ptr %rv
  br label %ret
bb29:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load i32, ptr %l5, !tbaa !23
  %t118 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t114, i32 %t115)
  store i32 %t118, ptr %l96
  br label %bb30
bb30:
  %t119 = load i32, ptr %l96, !tbaa !23
  store i32 %t119, ptr %l9, !tbaa !23
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load i32, ptr %l6, !tbaa !23
  %t124 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t120, i32 %t121)
  store i32 %t124, ptr %l99
  br label %bb31
bb31:
  %t125 = load i32, ptr %l99, !tbaa !23
  store i32 %t125, ptr %l10, !tbaa !23
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/check:Checker", ptr %t126, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t131 = getelementptr %"compiler/generic:Program", ptr %t129, i32 0, i32 2
  %t132 = load i32, ptr %l9, !tbaa !23
  %t133 = load i32, ptr %l10, !tbaa !23
  %t137 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t131, i32 %t132, i32 %t133)
  store i1 %t137, ptr %l105
  br label %bb32
bb32:
  %t138 = load i1, ptr %l105, !tbaa !21
  %t139 = xor i1 %t138, true
  br i1 %t139, label %bb33, label %bb34
bb33:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = load i32, ptr %l9, !tbaa !23
  %t143 = load i32, ptr %l10, !tbaa !23
  %t147 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eflowsInto(ptr %v0, ptr %t141, i32 %t142, i32 %t143)
  store i1 %t147, ptr %l110
  br label %bb35
bb34:
  br label %bb108
bb35:
  %t148 = load i1, ptr %l110, !tbaa !21
  br i1 %t148, label %bb36, label %bb37
bb36:
  %t149 = load ptr, ptr %l0, !tbaa !29
  store ptr %t149, ptr %l111, !tbaa !29
  %t150 = load ptr, ptr %l3, !tbaa !29
  store ptr %t150, ptr %l112, !tbaa !29
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load i32, ptr %l5, !tbaa !23
  %t155 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t151, i32 %t152)
  store i1 %t155, ptr %l115
  br label %bb38
bb37:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load i32, ptr %l10, !tbaa !23
  %t158 = load i32, ptr %l9, !tbaa !23
  %t162 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eflowsInto(ptr %v0, ptr %t156, i32 %t157, i32 %t158)
  store i1 %t162, ptr %l137
  br label %bb49
bb38:
  %t163 = load i1, ptr %l115, !tbaa !21
  br i1 %t163, label %bb39, label %bb40
bb39:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = load i32, ptr %l6, !tbaa !23
  %t168 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t164, i32 %t165)
  store i1 %t168, ptr %l119
  br label %bb41
bb40:
  store i1 false, ptr %l116, !tbaa !21
  br label %bb42
bb41:
  %t169 = load i1, ptr %l119, !tbaa !21
  store i1 %t169, ptr %l116, !tbaa !21
  br label %bb42
bb42:
  %t170 = load i1, ptr %l116, !tbaa !21
  br i1 %t170, label %bb43, label %bb44
bb43:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t173 = getelementptr %"compiler/check:Checker", ptr %t171, i32 0, i32 1
  %t174 = load ptr, ptr %t173, !tbaa !29
  %t176 = getelementptr %"compiler/generic:Program", ptr %t174, i32 0, i32 2
  %t177 = load i32, ptr %l10, !tbaa !23
  %t178 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t182 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t176, i32 %t177, i64 %t178)
  store i32 %t182, ptr %l126
  br label %bb45
bb44:
  %t183 = load i32, ptr %l10, !tbaa !23
  store i32 %t183, ptr %l120, !tbaa !23
  br label %bb46
bb45:
  %t185 = load i32, ptr %l126, !tbaa !23
  store i32 %t185, ptr %l120, !tbaa !23
  br label %bb46
bb46:
  %t186 = load %"compiler/source:Span", ptr %l1
  %t187 = load ptr, ptr %l111, !tbaa !29
  %t188 = load ptr, ptr %l112, !tbaa !29
  %t189 = load i32, ptr %l120, !tbaa !23
  %t191 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v1, ptr %v1, ptr %t187, ptr %t188, i32 %t189, %"compiler/source:Span" %t186)
  store ptr %t191, ptr %l129
  br label %bb47
bb47:
  %t192 = load ptr, ptr %l129, !tbaa !29
  store ptr %t192, ptr %l3, !tbaa !29
  %t193 = load ptr, ptr %l3, !tbaa !29
  %t196 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t193)
  store i32 %t196, ptr %l132
  br label %bb48
bb48:
  %t197 = load i32, ptr %l132, !tbaa !23
  store i32 %t197, ptr %l5, !tbaa !23
  %t198 = load i32, ptr %l10, !tbaa !23
  store i32 %t198, ptr %l9, !tbaa !23
  br label %bb107
bb49:
  %t200 = load i1, ptr %l137, !tbaa !21
  br i1 %t200, label %bb50, label %bb51
bb50:
  %t201 = load ptr, ptr %l0, !tbaa !29
  store ptr %t201, ptr %l138, !tbaa !29
  %t202 = load ptr, ptr %l4, !tbaa !29
  store ptr %t202, ptr %l139, !tbaa !29
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load i32, ptr %l5, !tbaa !23
  %t207 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t203, i32 %t204)
  store i1 %t207, ptr %l142
  br label %bb52
bb51:
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/check:Checker", ptr %t208, i32 0, i32 1
  %t211 = load ptr, ptr %t210, !tbaa !29
  %t213 = getelementptr %"compiler/generic:Program", ptr %t211, i32 0, i32 2
  %t214 = load i32, ptr %l9, !tbaa !23
  %t217 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t213, i32 %t214)
  store i32 %t217, ptr %l165
  br label %bb63
bb52:
  %t218 = load i1, ptr %l142, !tbaa !21
  br i1 %t218, label %bb53, label %bb54
bb53:
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t220 = load i32, ptr %l6, !tbaa !23
  %t223 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t219, i32 %t220)
  store i1 %t223, ptr %l146
  br label %bb55
bb54:
  store i1 false, ptr %l143, !tbaa !21
  br label %bb56
bb55:
  %t224 = load i1, ptr %l146, !tbaa !21
  store i1 %t224, ptr %l143, !tbaa !21
  br label %bb56
bb56:
  %t225 = load i1, ptr %l143, !tbaa !21
  br i1 %t225, label %bb57, label %bb58
bb57:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr %"compiler/check:Checker", ptr %t226, i32 0, i32 1
  %t229 = load ptr, ptr %t228, !tbaa !29
  %t231 = getelementptr %"compiler/generic:Program", ptr %t229, i32 0, i32 2
  %t232 = load i32, ptr %l9, !tbaa !23
  %t233 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t237 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t231, i32 %t232, i64 %t233)
  store i32 %t237, ptr %l153
  br label %bb59
bb58:
  %t238 = load i32, ptr %l9, !tbaa !23
  store i32 %t238, ptr %l147, !tbaa !23
  br label %bb60
bb59:
  %t240 = load i32, ptr %l153, !tbaa !23
  store i32 %t240, ptr %l147, !tbaa !23
  br label %bb60
bb60:
  %t241 = load %"compiler/source:Span", ptr %l1
  %t242 = load ptr, ptr %l138, !tbaa !29
  %t243 = load ptr, ptr %l139, !tbaa !29
  %t244 = load i32, ptr %l147, !tbaa !23
  %t246 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v2, ptr %v2, ptr %t242, ptr %t243, i32 %t244, %"compiler/source:Span" %t241)
  store ptr %t246, ptr %l156
  br label %bb61
bb61:
  %t247 = load ptr, ptr %l156, !tbaa !29
  store ptr %t247, ptr %l4, !tbaa !29
  %t248 = load ptr, ptr %l4, !tbaa !29
  %t251 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t248)
  store i32 %t251, ptr %l159
  br label %bb62
bb62:
  %t252 = load i32, ptr %l159, !tbaa !23
  store i32 %t252, ptr %l6, !tbaa !23
  %t253 = load i32, ptr %l9, !tbaa !23
  store i32 %t253, ptr %l10, !tbaa !23
  br label %bb106
bb63:
  %t255 = load i32, ptr %l165, !range !{i32 0, i32 33}
  %t257 = trunc i64 19 to i32
  %t258 = icmp eq i32 %t255, %t257
  br i1 %t258, label %bb64, label %bb65
bb64:
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t262 = getelementptr %"compiler/check:Checker", ptr %t260, i32 0, i32 1
  %t263 = load ptr, ptr %t262, !tbaa !29
  %t265 = getelementptr %"compiler/generic:Program", ptr %t263, i32 0, i32 2
  %t266 = load i32, ptr %l10, !tbaa !23
  %t269 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t265, i32 %t266)
  store i32 %t269, ptr %l173
  br label %bb66
bb65:
  store i1 false, ptr %l168, !tbaa !21
  br label %bb67
bb66:
  %t270 = load i32, ptr %l173, !range !{i32 0, i32 33}
  %t272 = trunc i64 19 to i32
  %t273 = icmp eq i32 %t270, %t272
  store i1 %t273, ptr %l168, !tbaa !21
  br label %bb67
bb67:
  %t275 = load i1, ptr %l168, !tbaa !21
  br i1 %t275, label %bb68, label %bb69
bb68:
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t278 = getelementptr %"compiler/check:Checker", ptr %t276, i32 0, i32 1
  %t279 = load ptr, ptr %t278, !tbaa !29
  %t281 = getelementptr %"compiler/generic:Program", ptr %t279, i32 0, i32 2
  store ptr %t281, ptr %l179, !tbaa !29
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t284 = getelementptr %"compiler/check:Checker", ptr %t282, i32 0, i32 1
  %t285 = load ptr, ptr %t284, !tbaa !29
  %t287 = getelementptr %"compiler/generic:Program", ptr %t285, i32 0, i32 2
  %t288 = load i32, ptr %l9, !tbaa !23
  %t291 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t287, i32 %t288)
  store i32 %t291, ptr %l184
  br label %bb70
bb69:
  store i1 false, ptr %l176, !tbaa !21
  br label %bb73
bb70:
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t294 = getelementptr %"compiler/check:Checker", ptr %t292, i32 0, i32 1
  %t295 = load ptr, ptr %t294, !tbaa !29
  %t297 = getelementptr %"compiler/generic:Program", ptr %t295, i32 0, i32 2
  %t298 = load i32, ptr %l10, !tbaa !23
  %t301 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t297, i32 %t298)
  store i32 %t301, ptr %l189
  br label %bb71
bb71:
  %t302 = load ptr, ptr %l179, !tbaa !29
  %t303 = load i32, ptr %l184, !tbaa !23
  %t304 = load i32, ptr %l189, !tbaa !23
  %t305 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t302, i32 %t303, i32 %t304)
  store i1 %t305, ptr %l190
  br label %bb72
bb72:
  %t306 = load i1, ptr %l190, !tbaa !21
  store i1 %t306, ptr %l176, !tbaa !21
  br label %bb73
bb73:
  %t307 = load i1, ptr %l176, !tbaa !21
  br i1 %t307, label %bb74, label %bb75
bb74:
  %t308 = load ptr, ptr %l0, !tbaa !29
  %t310 = getelementptr %"compiler/check:Checker", ptr %t308, i32 0, i32 1
  %t311 = load ptr, ptr %t310, !tbaa !29
  %t313 = getelementptr %"compiler/generic:Program", ptr %t311, i32 0, i32 2
  store ptr %t313, ptr %l193, !tbaa !29
  %t314 = load ptr, ptr %l0, !tbaa !29
  %t316 = getelementptr %"compiler/check:Checker", ptr %t314, i32 0, i32 1
  %t317 = load ptr, ptr %t316, !tbaa !29
  %t319 = getelementptr %"compiler/generic:Program", ptr %t317, i32 0, i32 2
  %t320 = load i32, ptr %l9, !tbaa !23
  %t323 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t319, i32 %t320)
  store i32 %t323, ptr %l198
  br label %bb76
bb75:
  store %olang.scope zeroinitializer, ptr %s9
  %t324 = load ptr, ptr %l0, !tbaa !29
  store ptr %t324, ptr %l250, !tbaa !29
  %t325 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t325, ptr %l251
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t327 = load i32, ptr %l9, !tbaa !23
  %t330 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s9, ptr %t326, i32 %t327)
  store { i64, ptr } %t330, ptr %l254
  br label %bb100
bb76:
  %t331 = load ptr, ptr %l193, !tbaa !29
  %t332 = load i32, ptr %l198, !tbaa !23
  %t333 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t331, i32 %t332, i32 0)
  store i32 %t333, ptr %l199
  br label %bb77
bb77:
  %t334 = load i32, ptr %l199, !tbaa !23
  store i32 %t334, ptr %l11, !tbaa !23
  %t335 = load ptr, ptr %l0, !tbaa !29
  store ptr %t335, ptr %l200, !tbaa !29
  %t336 = load ptr, ptr %l3, !tbaa !29
  store ptr %t336, ptr %l201, !tbaa !29
  %t337 = load ptr, ptr %l0, !tbaa !29
  %t338 = load i32, ptr %l5, !tbaa !23
  %t341 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t337, i32 %t338)
  store i1 %t341, ptr %l204
  br label %bb78
bb78:
  %t342 = load i1, ptr %l204, !tbaa !21
  br i1 %t342, label %bb79, label %bb80
bb79:
  %t343 = load ptr, ptr %l0, !tbaa !29
  %t344 = load i32, ptr %l6, !tbaa !23
  %t347 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t343, i32 %t344)
  store i1 %t347, ptr %l208
  br label %bb81
bb80:
  store i1 false, ptr %l205, !tbaa !21
  br label %bb82
bb81:
  %t348 = load i1, ptr %l208, !tbaa !21
  store i1 %t348, ptr %l205, !tbaa !21
  br label %bb82
bb82:
  %t349 = load i1, ptr %l205, !tbaa !21
  br i1 %t349, label %bb83, label %bb84
bb83:
  %t350 = load ptr, ptr %l0, !tbaa !29
  %t352 = getelementptr %"compiler/check:Checker", ptr %t350, i32 0, i32 1
  %t353 = load ptr, ptr %t352, !tbaa !29
  %t355 = getelementptr %"compiler/generic:Program", ptr %t353, i32 0, i32 2
  %t356 = load i32, ptr %l11, !tbaa !23
  %t357 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t361 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t355, i32 %t356, i64 %t357)
  store i32 %t361, ptr %l215
  br label %bb85
bb84:
  %t362 = load i32, ptr %l11, !tbaa !23
  store i32 %t362, ptr %l209, !tbaa !23
  br label %bb86
bb85:
  %t364 = load i32, ptr %l215, !tbaa !23
  store i32 %t364, ptr %l209, !tbaa !23
  br label %bb86
bb86:
  %t365 = load %"compiler/source:Span", ptr %l1
  %t366 = load ptr, ptr %l200, !tbaa !29
  %t367 = load ptr, ptr %l201, !tbaa !29
  %t368 = load i32, ptr %l209, !tbaa !23
  %t370 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v1, ptr %v1, ptr %t366, ptr %t367, i32 %t368, %"compiler/source:Span" %t365)
  store ptr %t370, ptr %l218
  br label %bb87
bb87:
  %t371 = load ptr, ptr %l218, !tbaa !29
  store ptr %t371, ptr %l3, !tbaa !29
  %t372 = load ptr, ptr %l0, !tbaa !29
  store ptr %t372, ptr %l219, !tbaa !29
  %t373 = load ptr, ptr %l4, !tbaa !29
  store ptr %t373, ptr %l220, !tbaa !29
  %t374 = load ptr, ptr %l0, !tbaa !29
  %t375 = load i32, ptr %l5, !tbaa !23
  %t378 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t374, i32 %t375)
  store i1 %t378, ptr %l223
  br label %bb88
bb88:
  %t379 = load i1, ptr %l223, !tbaa !21
  br i1 %t379, label %bb89, label %bb90
bb89:
  %t380 = load ptr, ptr %l0, !tbaa !29
  %t381 = load i32, ptr %l6, !tbaa !23
  %t384 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t380, i32 %t381)
  store i1 %t384, ptr %l227
  br label %bb91
bb90:
  store i1 false, ptr %l224, !tbaa !21
  br label %bb92
bb91:
  %t385 = load i1, ptr %l227, !tbaa !21
  store i1 %t385, ptr %l224, !tbaa !21
  br label %bb92
bb92:
  %t386 = load i1, ptr %l224, !tbaa !21
  br i1 %t386, label %bb93, label %bb94
bb93:
  %t387 = load ptr, ptr %l0, !tbaa !29
  %t389 = getelementptr %"compiler/check:Checker", ptr %t387, i32 0, i32 1
  %t390 = load ptr, ptr %t389, !tbaa !29
  %t392 = getelementptr %"compiler/generic:Program", ptr %t390, i32 0, i32 2
  %t393 = load i32, ptr %l11, !tbaa !23
  %t394 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t398 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t392, i32 %t393, i64 %t394)
  store i32 %t398, ptr %l234
  br label %bb95
bb94:
  %t399 = load i32, ptr %l11, !tbaa !23
  store i32 %t399, ptr %l228, !tbaa !23
  br label %bb96
bb95:
  %t401 = load i32, ptr %l234, !tbaa !23
  store i32 %t401, ptr %l228, !tbaa !23
  br label %bb96
bb96:
  %t402 = load %"compiler/source:Span", ptr %l1
  %t403 = load ptr, ptr %l219, !tbaa !29
  %t404 = load ptr, ptr %l220, !tbaa !29
  %t405 = load i32, ptr %l228, !tbaa !23
  %t407 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v2, ptr %v2, ptr %t403, ptr %t404, i32 %t405, %"compiler/source:Span" %t402)
  store ptr %t407, ptr %l237
  br label %bb97
bb97:
  %t408 = load ptr, ptr %l237, !tbaa !29
  store ptr %t408, ptr %l4, !tbaa !29
  %t409 = load ptr, ptr %l3, !tbaa !29
  %t412 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t409)
  store i32 %t412, ptr %l240
  br label %bb98
bb98:
  %t413 = load i32, ptr %l240, !tbaa !23
  store i32 %t413, ptr %l12, !tbaa !23
  %t414 = load ptr, ptr %l4, !tbaa !29
  %t417 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t414)
  store i32 %t417, ptr %l243
  br label %bb99
bb99:
  %t418 = load i32, ptr %l243, !tbaa !23
  %t419 = load i32, ptr %l12, !tbaa !23
  store i32 %t419, ptr %l5, !tbaa !23
  store i32 %t418, ptr %l6, !tbaa !23
  %t423 = load i32, ptr %l11, !tbaa !23
  %t425 = load i32, ptr %l11, !tbaa !23
  store i32 %t423, ptr %l9, !tbaa !23
  store i32 %t425, ptr %l10, !tbaa !23
  br label %bb105
bb100:
  %t431 = load { i64, ptr }, ptr %l254, !tbaa !27
  %t432 = extractvalue { i64, ptr } %t431, 0
  %t433 = extractvalue { i64, ptr } %t431, 1
  %t434 = mul i64 %t432, 1
  %t435 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t434)
  call void @llvm.memcpy.p0.p0.i64(ptr %t435, ptr %t433, i64 %t434, i1 false)
  %t436 = insertvalue { i64, ptr } undef, i64 %t432, 0
  %t437 = insertvalue { i64, ptr } %t436, ptr %t435, 1
  store { i64, ptr } %t437, ptr %l255, !tbaa !27
  %t438 = load ptr, ptr %l0, !tbaa !29
  %t439 = load i32, ptr %l10, !tbaa !23
  %t442 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s9, ptr %t438, i32 %t439)
  store { i64, ptr } %t442, ptr %l258
  br label %bb101
bb101:
  %t443 = load { i64, ptr }, ptr %l258, !tbaa !27
  %t444 = extractvalue { i64, ptr } %t443, 0
  %t445 = extractvalue { i64, ptr } %t443, 1
  %t446 = mul i64 %t444, 1
  %t447 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t446)
  call void @llvm.memcpy.p0.p0.i64(ptr %t447, ptr %t445, i64 %t446, i1 false)
  %t448 = insertvalue { i64, ptr } undef, i64 %t444, 0
  %t449 = insertvalue { i64, ptr } %t448, ptr %t447, 1
  %t450 = load { i64, ptr }, ptr %l255, !tbaa !27
  %t452 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeMismatch(ptr %s9, ptr %s9, ptr %s9, { i64, ptr } %t450, { i64, ptr } %t449)
  store %"compiler/msgs:Msg" %t452, ptr %l260
  br label %bb102
bb102:
  %t453 = load ptr, ptr %l250, !tbaa !29
  %t454 = load %"compiler/source:Span", ptr %l251
  %t455 = load %"compiler/msgs:Msg", ptr %l260
  %t456 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s9, ptr %t453, %"compiler/source:Span" %t454, %"compiler/msgs:Msg" %t455)
  store i64 %t456, ptr %l261
  br label %bb103
bb103:
  %t457 = load ptr, ptr %l0, !tbaa !29
  %t458 = load %"compiler/source:Span", ptr %l1
  %t459 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t463 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t457, %"compiler/source:Span" %t458, i32 %t459, i64 0)
  store ptr %t463, ptr %l265
  br label %bb104
bb104:
  call void @__olang_scope_close(ptr %s9)
  %t464 = load ptr, ptr %l265, !tbaa !29
  store ptr %t464, ptr %rv
  br label %ret
bb105:
  br label %bb106
bb106:
  br label %bb107
bb107:
  br label %bb108
bb108:
  %t465 = load ptr, ptr %l0, !tbaa !29
  %t466 = load i32, ptr %l9, !tbaa !23
  %t469 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeqMethod(ptr %v0, ptr %t465, i32 %t466)
  store i64 %t469, ptr %l268
  br label %bb109
bb109:
  %t470 = load i64, ptr %l268, !tbaa !24
  store i64 %t470, ptr %l16, !tbaa !24
  %t471 = load i64, ptr %l16, !tbaa !24
  %t473 = icmp eq i64 %t471, -2
  br i1 %t473, label %bb110, label %bb111
bb110:
  store %olang.scope zeroinitializer, ptr %s10
  %t475 = load ptr, ptr %l0, !tbaa !29
  %t477 = getelementptr %"compiler/check:Checker", ptr %t475, i32 0, i32 1
  %t478 = load ptr, ptr %t477, !tbaa !29
  %t480 = getelementptr %"compiler/generic:Program", ptr %t478, i32 0, i32 0
  %t481 = load ptr, ptr %t480, !tbaa !29
  %t483 = getelementptr %"compiler/load:Loader", ptr %t481, i32 0, i32 4
  %t484 = load ptr, ptr %t483, !tbaa !29
  store ptr %t484, ptr %l274, !tbaa !29
  %t485 = load ptr, ptr %l0, !tbaa !29
  store ptr %t485, ptr %l275, !tbaa !29
  %t486 = load ptr, ptr %l0, !tbaa !29
  %t488 = getelementptr %"compiler/check:Checker", ptr %t486, i32 0, i32 44
  %t489 = getelementptr %"compiler/source:Span", ptr %t488, i32 0, i32 0
  %t490 = load i32, ptr %t489, !tbaa !23
  %t492 = icmp sge i32 %t490, 0
  br i1 %t492, label %bb112, label %bb113
bb111:
  br label %bb120
bb112:
  %t494 = load ptr, ptr %l0, !tbaa !29
  %t496 = getelementptr %"compiler/check:Checker", ptr %t494, i32 0, i32 44
  %t497 = load %"compiler/source:Span", ptr %t496
  store %"compiler/source:Span" %t497, ptr %l279
  br label %bb114
bb113:
  %t499 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t499, ptr %l279
  br label %bb114
bb114:
  %t501 = load ptr, ptr %l275, !tbaa !29
  %t502 = load %"compiler/source:Span", ptr %l279
  %t503 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t501, %"compiler/source:Span" %t502)
  store { i64, [3 x i64] } %t503, ptr %l283
  br label %bb115
bb115:
  %t504 = load ptr, ptr %l0, !tbaa !29
  %t505 = load i32, ptr %l9, !tbaa !23
  %t508 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s10, ptr %t504, i32 %t505)
  store { i64, ptr } %t508, ptr %l286
  br label %bb116
bb116:
  %t509 = load { i64, ptr }, ptr %l286, !tbaa !27
  %t510 = extractvalue { i64, ptr } %t509, 0
  %t511 = extractvalue { i64, ptr } %t509, 1
  %t512 = mul i64 %t510, 1
  %t513 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t512)
  call void @llvm.memcpy.p0.p0.i64(ptr %t513, ptr %t511, i64 %t512, i1 false)
  %t514 = insertvalue { i64, ptr } undef, i64 %t510, 0
  %t515 = insertvalue { i64, ptr } %t514, ptr %t513, 1
  %t517 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eProtocolPrivate(ptr %s10, ptr %s10, ptr %s10, ptr %s10, ptr %s10, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d3, i32 0, i32 1) }, { i64, ptr } %t515, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d4, i32 0, i32 1) }, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d5, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t517, ptr %l288
  br label %bb117
bb117:
  %t518 = load ptr, ptr %l274, !tbaa !29
  %t519 = load { i64, [3 x i64] }, ptr %l283
  %t520 = load %"compiler/msgs:Msg", ptr %l288
  %t521 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorOncePerLine(ptr %v0, ptr %s10, ptr %t518, { i64, [3 x i64] } %t519, %"compiler/msgs:Msg" %t520)
  store i64 %t521, ptr %l289
  br label %bb118
bb118:
  %t522 = load ptr, ptr %l0, !tbaa !29
  %t523 = load %"compiler/source:Span", ptr %l1
  %t524 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t528 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t522, %"compiler/source:Span" %t523, i32 %t524, i64 0)
  store ptr %t528, ptr %l293
  br label %bb119
bb119:
  call void @__olang_scope_close(ptr %s10)
  %t529 = load ptr, ptr %l293, !tbaa !29
  store ptr %t529, ptr %rv
  br label %ret
bb120:
  %t530 = load i64, ptr %l16, !tbaa !24
  %t532 = icmp sge i64 %t530, 0
  br i1 %t532, label %bb121, label %bb122
bb121:
  %t534 = load ptr, ptr %l0, !tbaa !29
  %t535 = load i32, ptr %l5, !tbaa !23
  %t538 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t534, i32 %t535)
  store i1 %t538, ptr %l299
  br label %bb123
bb122:
  store i1 false, ptr %l296, !tbaa !21
  br label %bb124
bb123:
  %t539 = load i1, ptr %l299, !tbaa !21
  store i1 %t539, ptr %l296, !tbaa !21
  br label %bb124
bb124:
  %t540 = load i1, ptr %l296, !tbaa !21
  br i1 %t540, label %bb125, label %bb126
bb125:
  %t541 = load ptr, ptr %l0, !tbaa !29
  %t542 = load i32, ptr %l6, !tbaa !23
  %t545 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t541, i32 %t542)
  store i1 %t545, ptr %l303
  br label %bb127
bb126:
  store i1 false, ptr %l300, !tbaa !21
  br label %bb128
bb127:
  %t546 = load i1, ptr %l303, !tbaa !21
  store i1 %t546, ptr %l300, !tbaa !21
  br label %bb128
bb128:
  %t547 = load i1, ptr %l300, !tbaa !21
  br i1 %t547, label %bb129, label %bb130
bb129:
  %t548 = load ptr, ptr %l0, !tbaa !29
  %t550 = getelementptr %"compiler/check:Checker", ptr %t548, i32 0, i32 1
  %t551 = load ptr, ptr %t550, !tbaa !29
  %t553 = getelementptr %"compiler/generic:Program", ptr %t551, i32 0, i32 2
  %t554 = load i32, ptr %l5, !tbaa !23
  %t557 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t553, i32 %t554)
  store i1 %t557, ptr %l309
  br label %bb131
bb130:
  store i1 false, ptr %l304, !tbaa !21
  br label %bb136
bb131:
  %t558 = load i1, ptr %l309, !tbaa !21
  br i1 %t558, label %bb132, label %bb133
bb132:
  store i1 true, ptr %l310, !tbaa !21
  br label %bb135
bb133:
  %t559 = load ptr, ptr %l0, !tbaa !29
  %t561 = getelementptr %"compiler/check:Checker", ptr %t559, i32 0, i32 1
  %t562 = load ptr, ptr %t561, !tbaa !29
  %t564 = getelementptr %"compiler/generic:Program", ptr %t562, i32 0, i32 2
  %t565 = load i32, ptr %l6, !tbaa !23
  %t568 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t564, i32 %t565)
  store i1 %t568, ptr %l315
  br label %bb134
bb134:
  %t569 = load i1, ptr %l315, !tbaa !21
  store i1 %t569, ptr %l310, !tbaa !21
  br label %bb135
bb135:
  %t570 = load i1, ptr %l310, !tbaa !21
  store i1 %t570, ptr %l304, !tbaa !21
  br label %bb136
bb136:
  %t571 = load i1, ptr %l304, !tbaa !21
  br i1 %t571, label %bb137, label %bb138
bb137:
  %t572 = load ptr, ptr %l0, !tbaa !29
  %t574 = getelementptr %"compiler/check:Checker", ptr %t572, i32 0, i32 37
  %t576 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t574)
  store i64 %t576, ptr %l318
  br label %bb139
bb138:
  br label %bb176
bb139:
  %t577 = load i64, ptr %l318, !tbaa !24
  store i64 %t577, ptr %l17, !tbaa !24
  %t578 = load ptr, ptr %l0, !tbaa !29
  %t579 = load %"compiler/source:Span", ptr %l1
  %t580 = load i32, ptr %l5, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t581
  %t582 = getelementptr { i64, [2 x i64] }, ptr %t581, i32 0, i32 0
  store i64 5, ptr %t582
  %t583 = load { i64, [2 x i64] }, ptr %t581
  %t589 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t578, i32 0, %"compiler/source:Span" %t579, i32 %t580, i32 1, { i64, [2 x i64] } %t583)
  store i64 %t589, ptr %l324
  br label %bb140
bb140:
  %t590 = load i64, ptr %l324, !tbaa !24
  store i64 %t590, ptr %l18, !tbaa !24
  %t591 = load ptr, ptr %l0, !tbaa !29
  %t593 = getelementptr %"compiler/check:Checker", ptr %t591, i32 0, i32 37
  %t594 = load %"compiler/source:Span", ptr %l1
  %t595 = load i64, ptr %l18, !tbaa !24
  %t597 = trunc i64 %t595 to i32
  %t599 = load ptr, ptr %l3, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t600
  %t601 = getelementptr { i64, [3 x i64] }, ptr %t600, i32 0, i32 0
  store i64 0, ptr %t601
  %t603 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t594, 0
  %t605 = insertvalue { %"compiler/source:Span", i32, ptr } %t603, i32 %t597, 1
  %t607 = insertvalue { %"compiler/source:Span", i32, ptr } %t605, ptr %t599, 2
  %t608 = getelementptr { i64, [3 x i64] }, ptr %t600, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t607, ptr %t608
  %t609 = load { i64, [3 x i64] }, ptr %t600
  %t611 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t609, ptr %t611
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t593, ptr %t611)
  br label %bb141
bb141:
  %t614 = load ptr, ptr %l0, !tbaa !29
  %t615 = load %"compiler/source:Span", ptr %l1
  %t616 = load i32, ptr %l6, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t617
  %t618 = getelementptr { i64, [2 x i64] }, ptr %t617, i32 0, i32 0
  store i64 5, ptr %t618
  %t619 = load { i64, [2 x i64] }, ptr %t617
  %t625 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t614, i32 0, %"compiler/source:Span" %t615, i32 %t616, i32 1, { i64, [2 x i64] } %t619)
  store i64 %t625, ptr %l339
  br label %bb142
bb142:
  %t626 = load i64, ptr %l339, !tbaa !24
  store i64 %t626, ptr %l19, !tbaa !24
  %t627 = load ptr, ptr %l0, !tbaa !29
  %t629 = getelementptr %"compiler/check:Checker", ptr %t627, i32 0, i32 37
  %t630 = load %"compiler/source:Span", ptr %l1
  %t631 = load i64, ptr %l19, !tbaa !24
  %t633 = trunc i64 %t631 to i32
  %t635 = load ptr, ptr %l4, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t636
  %t637 = getelementptr { i64, [3 x i64] }, ptr %t636, i32 0, i32 0
  store i64 0, ptr %t637
  %t639 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t630, 0
  %t641 = insertvalue { %"compiler/source:Span", i32, ptr } %t639, i32 %t633, 1
  %t643 = insertvalue { %"compiler/source:Span", i32, ptr } %t641, ptr %t635, 2
  %t644 = getelementptr { i64, [3 x i64] }, ptr %t636, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t643, ptr %t644
  %t645 = load { i64, [3 x i64] }, ptr %t636
  %t647 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t645, ptr %t647
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t629, ptr %t647)
  br label %bb143
bb143:
  %t650 = load ptr, ptr %l0, !tbaa !29
  store ptr %t650, ptr %l349, !tbaa !29
  %t651 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t651, ptr %l350
  %t652 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t652, ptr %l351, !tbaa !23
  store i32 19, ptr %l352
  %t653 = load ptr, ptr %l0, !tbaa !29
  %t654 = load %"compiler/source:Span", ptr %l1
  %t655 = load i64, ptr %l18, !tbaa !24
  %t659 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t653, %"compiler/source:Span" %t654, i64 %t655)
  store ptr %t659, ptr %l356
  br label %bb144
bb144:
  %t660 = load ptr, ptr %l0, !tbaa !29
  %t661 = load %"compiler/source:Span", ptr %l1
  %t662 = load i32, ptr %l5, !tbaa !23
  %t666 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t660, %"compiler/source:Span" %t661, i32 %t662, i64 0)
  store ptr %t666, ptr %l360
  br label %bb145
bb145:
  %t667 = load ptr, ptr %l360, !tbaa !29
  %t668 = load ptr, ptr %l349, !tbaa !29
  %t669 = load %"compiler/source:Span", ptr %l350
  %t670 = load i32, ptr %l351, !tbaa !23
  %t671 = load i32, ptr %l352, !range !{i32 0, i32 43}
  %t672 = load ptr, ptr %l356, !tbaa !29
  %t674 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v0, ptr %v0, ptr %v3, ptr %t668, %"compiler/source:Span" %t669, i32 %t670, i32 %t671, ptr %t672, ptr %t667)
  store ptr %t674, ptr %l362
  br label %bb146
bb146:
  %t675 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 8, i64 8)
  store ptr %t675, ptr %lp20
  %t676 = load ptr, ptr %l362, !tbaa !29
  %t677 = load ptr, ptr %lp20
  store ptr %t676, ptr %t677, !tbaa !29
  %t678 = load ptr, ptr %l0, !tbaa !29
  store ptr %t678, ptr %l363, !tbaa !29
  %t679 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t679, ptr %l364
  %t680 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t680, ptr %l365, !tbaa !23
  store i32 19, ptr %l366
  %t681 = load ptr, ptr %l0, !tbaa !29
  %t682 = load %"compiler/source:Span", ptr %l1
  %t683 = load i64, ptr %l19, !tbaa !24
  %t687 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t681, %"compiler/source:Span" %t682, i64 %t683)
  store ptr %t687, ptr %l370
  br label %bb147
bb147:
  %t688 = load ptr, ptr %l0, !tbaa !29
  %t689 = load %"compiler/source:Span", ptr %l1
  %t690 = load i32, ptr %l6, !tbaa !23
  %t694 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t688, %"compiler/source:Span" %t689, i32 %t690, i64 0)
  store ptr %t694, ptr %l374
  br label %bb148
bb148:
  %t695 = load ptr, ptr %l374, !tbaa !29
  %t696 = load ptr, ptr %l363, !tbaa !29
  %t697 = load %"compiler/source:Span", ptr %l364
  %t698 = load i32, ptr %l365, !tbaa !23
  %t699 = load i32, ptr %l366, !range !{i32 0, i32 43}
  %t700 = load ptr, ptr %l370, !tbaa !29
  %t702 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v0, ptr %v0, ptr %v3, ptr %t696, %"compiler/source:Span" %t697, i32 %t698, i32 %t699, ptr %t700, ptr %t695)
  store ptr %t702, ptr %l376
  br label %bb149
bb149:
  %t703 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 8, i64 8)
  store ptr %t703, ptr %lp21
  %t704 = load ptr, ptr %l376, !tbaa !29
  %t705 = load ptr, ptr %lp21
  store ptr %t704, ptr %t705, !tbaa !29
  %t706 = load ptr, ptr %l0, !tbaa !29
  store ptr %t706, ptr %l377, !tbaa !29
  %t707 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t707, ptr %l378
  %t708 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t708, ptr %l379, !tbaa !23
  store i32 19, ptr %l380
  %t709 = load ptr, ptr %l0, !tbaa !29
  %t710 = load %"compiler/source:Span", ptr %l1
  %t711 = load i64, ptr %l19, !tbaa !24
  %t715 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t709, %"compiler/source:Span" %t710, i64 %t711)
  store ptr %t715, ptr %l384
  br label %bb150
bb150:
  %t716 = load ptr, ptr %l0, !tbaa !29
  %t717 = load %"compiler/source:Span", ptr %l1
  %t718 = load i32, ptr %l6, !tbaa !23
  %t722 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t716, %"compiler/source:Span" %t717, i32 %t718, i64 0)
  store ptr %t722, ptr %l388
  br label %bb151
bb151:
  %t723 = load ptr, ptr %l388, !tbaa !29
  %t724 = load ptr, ptr %l377, !tbaa !29
  %t725 = load %"compiler/source:Span", ptr %l378
  %t726 = load i32, ptr %l379, !tbaa !23
  %t727 = load i32, ptr %l380, !range !{i32 0, i32 43}
  %t728 = load ptr, ptr %l384, !tbaa !29
  %t730 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v0, ptr %v0, ptr %v3, ptr %t724, %"compiler/source:Span" %t725, i32 %t726, i32 %t727, ptr %t728, ptr %t723)
  store ptr %t730, ptr %l390
  br label %bb152
bb152:
  %t731 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 8, i64 8)
  store ptr %t731, ptr %lp22
  %t732 = load ptr, ptr %l390, !tbaa !29
  %t733 = load ptr, ptr %lp22
  store ptr %t732, ptr %t733, !tbaa !29
  %t734 = load ptr, ptr %l0, !tbaa !29
  store ptr %t734, ptr %l391, !tbaa !29
  %t735 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t735, ptr %l392
  %t736 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t736, ptr %l393
  %t737 = load ptr, ptr %l0, !tbaa !29
  %t739 = getelementptr %"compiler/check:Checker", ptr %t737, i32 0, i32 1
  %t740 = load ptr, ptr %t739, !tbaa !29
  %t742 = getelementptr %"compiler/generic:Program", ptr %t740, i32 0, i32 2
  %t743 = load i32, ptr %l5, !tbaa !23
  %t746 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNonNull(ptr %v0, ptr %t742, i32 %t743)
  store i32 %t746, ptr %l398
  br label %bb153
bb153:
  %t747 = load i64, ptr %l18, !tbaa !24
  %t749 = trunc i64 %t747 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t751
  %t752 = getelementptr { i64, [4 x i64] }, ptr %t751, i32 0, i32 0
  store i64 0, ptr %t752
  %t753 = load %"compiler/source:Span", ptr %l393
  %t754 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t753, 0
  %t755 = load i32, ptr %l398, !tbaa !23
  %t756 = insertvalue { %"compiler/source:Span", i32, i32 } %t754, i32 %t755, 1
  %t758 = insertvalue { %"compiler/source:Span", i32, i32 } %t756, i32 %t749, 2
  %t759 = getelementptr { i64, [4 x i64] }, ptr %t751, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t758, ptr %t759
  %t760 = load { i64, [4 x i64] }, ptr %t751
  %t762 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 40, i64 8)
  store { i64, [4 x i64] } %t760, ptr %t762
  %t763 = load ptr, ptr %l391, !tbaa !29
  %t764 = load %"compiler/source:Span", ptr %l392
  %t766 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v3, ptr %v3, ptr %t763, %"compiler/source:Span" %t764, ptr %t762)
  store ptr %t766, ptr %l404
  br label %bb154
bb154:
  %t767 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 8, i64 8)
  store ptr %t767, ptr %lp23
  %t768 = load ptr, ptr %l404, !tbaa !29
  %t769 = load ptr, ptr %lp23
  store ptr %t768, ptr %t769, !tbaa !29
  %t770 = load ptr, ptr %l0, !tbaa !29
  store ptr %t770, ptr %l405, !tbaa !29
  %t771 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t771, ptr %l406
  %t772 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t772, ptr %l407
  %t773 = load ptr, ptr %l0, !tbaa !29
  %t775 = getelementptr %"compiler/check:Checker", ptr %t773, i32 0, i32 1
  %t776 = load ptr, ptr %t775, !tbaa !29
  %t778 = getelementptr %"compiler/generic:Program", ptr %t776, i32 0, i32 2
  %t779 = load i32, ptr %l6, !tbaa !23
  %t782 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNonNull(ptr %v0, ptr %t778, i32 %t779)
  store i32 %t782, ptr %l412
  br label %bb155
bb155:
  %t783 = load i64, ptr %l19, !tbaa !24
  %t785 = trunc i64 %t783 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t787
  %t788 = getelementptr { i64, [4 x i64] }, ptr %t787, i32 0, i32 0
  store i64 0, ptr %t788
  %t789 = load %"compiler/source:Span", ptr %l407
  %t790 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t789, 0
  %t791 = load i32, ptr %l412, !tbaa !23
  %t792 = insertvalue { %"compiler/source:Span", i32, i32 } %t790, i32 %t791, 1
  %t794 = insertvalue { %"compiler/source:Span", i32, i32 } %t792, i32 %t785, 2
  %t795 = getelementptr { i64, [4 x i64] }, ptr %t787, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t794, ptr %t795
  %t796 = load { i64, [4 x i64] }, ptr %t787
  %t798 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 40, i64 8)
  store { i64, [4 x i64] } %t796, ptr %t798
  %t799 = load ptr, ptr %l405, !tbaa !29
  %t800 = load %"compiler/source:Span", ptr %l406
  %t802 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v3, ptr %v3, ptr %t799, %"compiler/source:Span" %t800, ptr %t798)
  store ptr %t802, ptr %l418
  br label %bb156
bb156:
  %t803 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 8, i64 8)
  store ptr %t803, ptr %lp24
  %t804 = load ptr, ptr %l418, !tbaa !29
  %t805 = load ptr, ptr %lp24
  store ptr %t804, ptr %t805, !tbaa !29
  %t806 = load ptr, ptr %l0, !tbaa !29
  store ptr %t806, ptr %l419, !tbaa !29
  %t807 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t807, ptr %l420
  %t808 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t808, ptr %l421
  %t809 = load i64, ptr %l16, !tbaa !24
  store i64 %t809, ptr %l422, !tbaa !24
  %t810 = load ptr, ptr %lp23
  %t811 = load ptr, ptr %t810, !tbaa !29
  store ptr %t811, ptr %l424, !tbaa !29
  %t813 = icmp sge i64 0, 0
  br i1 %t813, label %bb157, label %bb158
bb157:
  %t815 = icmp sle i64 0, 1152921504606846975
  br i1 %t815, label %bb159, label %bb160
bb158:
  call void @__olang_check_failed(ptr @olang_loc_1c2cb6c96b4eaee8_c1b953befa7e1dc)
  unreachable
bb159:
  %t817 = mul i64 0, 8
  %t818 = insertvalue { i64, ptr } undef, i64 0, 0
  %t819 = insertvalue { i64, ptr } %t818, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t819, ptr %l427, !tbaa !27
  %t820 = load ptr, ptr %l0, !tbaa !29
  %t821 = load ptr, ptr %lp24
  %t822 = load ptr, ptr %t821, !tbaa !29
  %t825 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %v3, ptr %v0, ptr %t820, ptr %t822)
  store { i64, ptr } %t825, ptr %l430
  br label %bb161
bb160:
  call void @__olang_check_failed(ptr @olang_loc_1c2cb6c96b4eaee8_c1b953befa7e1dc)
  unreachable
bb161:
  %t826 = icmp sge i64 0, 0
  br i1 %t826, label %bb162, label %bb163
bb162:
  %t828 = icmp sle i64 0, 2305843009213693951
  br i1 %t828, label %bb164, label %bb165
bb163:
  call void @__olang_check_failed(ptr @olang_loc_7ec9c6dbabf95ed5_e8695782fec42ca9)
  unreachable
bb164:
  %t830 = mul i64 0, 4
  %t831 = insertvalue { i64, ptr } undef, i64 0, 0
  %t832 = insertvalue { i64, ptr } %t831, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t833 = load ptr, ptr %l419, !tbaa !29
  %t834 = load %"compiler/source:Span", ptr %l420
  %t835 = load %"compiler/source:Span", ptr %l421
  %t836 = load i64, ptr %l422, !tbaa !24
  %t837 = load ptr, ptr %l424, !tbaa !29
  %t838 = load { i64, ptr }, ptr %l427, !tbaa !27
  %t839 = load { i64, ptr }, ptr %l430, !tbaa !27
  %t841 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v3, ptr %v0, ptr %v0, ptr %v3, ptr %v3, ptr %t833, %"compiler/source:Span" %t834, %"compiler/source:Span" %t835, i64 %t836, ptr %t837, { i64, ptr } %t838, { i64, ptr } %t839, { i64, ptr } %t832)
  store ptr %t841, ptr %l434
  br label %bb166
bb165:
  call void @__olang_check_failed(ptr @olang_loc_7ec9c6dbabf95ed5_e8695782fec42ca9)
  unreachable
bb166:
  %t842 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 8, i64 8)
  store ptr %t842, ptr %lp25
  %t843 = load ptr, ptr %l434, !tbaa !29
  %t844 = load ptr, ptr %lp25
  store ptr %t843, ptr %t844, !tbaa !29
  %t845 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t845, ptr %l435
  %t846 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t846, ptr %l436, !tbaa !23
  %t847 = load ptr, ptr %lp22
  %t848 = load ptr, ptr %t847, !tbaa !29
  store ptr %t848, ptr %l437, !tbaa !29
  %t849 = load ptr, ptr %l0, !tbaa !29
  %t850 = load %"compiler/source:Span", ptr %l1
  %t851 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t855 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t849, %"compiler/source:Span" %t850, i32 %t851, i64 0)
  store ptr %t855, ptr %l441
  br label %bb167
bb167:
  %t856 = load ptr, ptr %l441, !tbaa !29
  %t857 = load ptr, ptr %lp25
  %t858 = load ptr, ptr %t857, !tbaa !29
  %t859 = load ptr, ptr %l437, !tbaa !29
  %t862 = call %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v3, ptr %v3, ptr %v3, ptr %v3, ptr %t859, ptr %t856, ptr %t858)
  store %"compiler/typed:Cond" %t862, ptr %l444
  br label %bb168
bb168:
  %t863 = load %"compiler/typed:Cond", ptr %l444
  %t864 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 24, i64 8)
  store %"compiler/typed:Cond" %t863, ptr %t864
  store { i64, [5 x i64] } zeroinitializer, ptr %t865
  %t866 = getelementptr { i64, [5 x i64] }, ptr %t865, i32 0, i32 0
  store i64 11, ptr %t866
  %t867 = load %"compiler/source:Span", ptr %l435
  %t868 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t867, 0
  %t869 = load i32, ptr %l436, !tbaa !23
  %t870 = insertvalue { %"compiler/source:Span", i32, ptr } %t868, i32 %t869, 1
  %t872 = insertvalue { %"compiler/source:Span", i32, ptr } %t870, ptr %t864, 2
  %t873 = getelementptr { i64, [5 x i64] }, ptr %t865, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t872, ptr %t873
  %t874 = load { i64, [5 x i64] }, ptr %t865
  %t875 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 48, i64 8)
  store ptr %t875, ptr %lp26
  %t877 = load ptr, ptr %lp26
  store { i64, [5 x i64] } %t874, ptr %t877
  %t878 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t878, ptr %l447
  %t879 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t879, ptr %l448, !tbaa !23
  %t880 = load ptr, ptr %l0, !tbaa !29
  %t882 = getelementptr %"compiler/check:Checker", ptr %t880, i32 0, i32 37
  %t883 = load i64, ptr %l17, !tbaa !24
  %t886 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t882, i64 %t883)
  store { i64, ptr } %t886, ptr %l452
  br label %bb169
bb169:
  %t887 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t887, ptr %l453
  %t888 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t888, ptr %l454, !tbaa !23
  %t889 = load ptr, ptr %lp20
  %t890 = load ptr, ptr %t889, !tbaa !29
  %t891 = load ptr, ptr %lp21
  %t892 = load ptr, ptr %t891, !tbaa !29
  %t894 = load ptr, ptr %lp26
  %t898 = call %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v3, ptr %v3, ptr %v3, ptr %v3, ptr %t890, ptr %t892, ptr %t894)
  store %"compiler/typed:Cond" %t898, ptr %l459
  br label %bb170
bb170:
  %t899 = load %"compiler/typed:Cond", ptr %l459
  %t900 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 24, i64 8)
  store %"compiler/typed:Cond" %t899, ptr %t900
  store { i64, [5 x i64] } zeroinitializer, ptr %t901
  %t902 = getelementptr { i64, [5 x i64] }, ptr %t901, i32 0, i32 0
  store i64 11, ptr %t902
  %t903 = load %"compiler/source:Span", ptr %l453
  %t904 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t903, 0
  %t905 = load i32, ptr %l454, !tbaa !23
  %t906 = insertvalue { %"compiler/source:Span", i32, ptr } %t904, i32 %t905, 1
  %t908 = insertvalue { %"compiler/source:Span", i32, ptr } %t906, ptr %t900, 2
  %t909 = getelementptr { i64, [5 x i64] }, ptr %t901, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t908, ptr %t909
  %t910 = load { i64, [5 x i64] }, ptr %t901
  %t912 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 48, i64 8)
  store { i64, [5 x i64] } %t910, ptr %t912
  %t913 = load { i64, ptr }, ptr %l452, !tbaa !27
  %t915 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v3, ptr %v3, { i64, ptr } %t913, ptr %t912)
  store %"compiler/typed:Seq" %t915, ptr %l463
  br label %bb171
bb171:
  %t916 = load %"compiler/typed:Seq", ptr %l463
  %t917 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 24, i64 8)
  store %"compiler/typed:Seq" %t916, ptr %t917
  store { i64, [5 x i64] } zeroinitializer, ptr %t918
  %t919 = getelementptr { i64, [5 x i64] }, ptr %t918, i32 0, i32 0
  store i64 12, ptr %t919
  %t920 = load %"compiler/source:Span", ptr %l447
  %t921 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t920, 0
  %t922 = load i32, ptr %l448, !tbaa !23
  %t923 = insertvalue { %"compiler/source:Span", i32, ptr } %t921, i32 %t922, 1
  %t925 = insertvalue { %"compiler/source:Span", i32, ptr } %t923, ptr %t917, 2
  %t926 = getelementptr { i64, [5 x i64] }, ptr %t918, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t925, ptr %t926
  %t927 = load { i64, [5 x i64] }, ptr %t918
  %t928 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 48, i64 8)
  store ptr %t928, ptr %lp27
  %t930 = load ptr, ptr %lp27
  store { i64, [5 x i64] } %t927, ptr %t930
  %t931 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t933 = trunc i64 79 to i32
  %t934 = icmp eq i32 %t931, %t933
  br i1 %t934, label %bb172, label %bb173
bb172:
  %t936 = load ptr, ptr %l0, !tbaa !29
  %t937 = load %"compiler/source:Span", ptr %l1
  %t938 = load ptr, ptr %lp27
  %t942 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %v3, ptr %v3, ptr %t936, %"compiler/source:Span" %t937, ptr %t938)
  store ptr %t942, ptr %l472
  br label %bb174
bb173:
  %t943 = load ptr, ptr %lp27
  store ptr %t943, ptr %l468, !tbaa !29
  br label %bb175
bb174:
  %t945 = load ptr, ptr %l472, !tbaa !29
  store ptr %t945, ptr %l468, !tbaa !29
  br label %bb175
bb175:
  %t946 = load ptr, ptr %l468, !tbaa !29
  store ptr %t946, ptr %rv
  br label %ret
bb176:
  %t947 = load i64, ptr %l16, !tbaa !24
  %t949 = icmp sge i64 %t947, 0
  br i1 %t949, label %bb177, label %bb178
bb177:
  %t951 = load ptr, ptr %l0, !tbaa !29
  store ptr %t951, ptr %l476, !tbaa !29
  %t952 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t952, ptr %l477
  %t953 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t953, ptr %l478
  %t954 = load i64, ptr %l16, !tbaa !24
  store i64 %t954, ptr %l479, !tbaa !24
  %t955 = load ptr, ptr %l3, !tbaa !29
  store ptr %t955, ptr %l481, !tbaa !29
  %t957 = icmp sge i64 0, 0
  br i1 %t957, label %bb179, label %bb180
bb178:
  br label %bb193
bb179:
  %t959 = icmp sle i64 0, 1152921504606846975
  br i1 %t959, label %bb181, label %bb182
bb180:
  call void @__olang_check_failed(ptr @olang_loc_bc0d2701821819b6_446831e810be806a)
  unreachable
bb181:
  %t961 = mul i64 0, 8
  %t962 = insertvalue { i64, ptr } undef, i64 0, 0
  %t963 = insertvalue { i64, ptr } %t962, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t963, ptr %l484, !tbaa !27
  %t964 = load ptr, ptr %l0, !tbaa !29
  %t965 = load ptr, ptr %l4, !tbaa !29
  %t968 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %v2, ptr %v0, ptr %t964, ptr %t965)
  store { i64, ptr } %t968, ptr %l487
  br label %bb183
bb182:
  call void @__olang_check_failed(ptr @olang_loc_bc0d2701821819b6_446831e810be806a)
  unreachable
bb183:
  %t969 = icmp sge i64 0, 0
  br i1 %t969, label %bb184, label %bb185
bb184:
  %t971 = icmp sle i64 0, 2305843009213693951
  br i1 %t971, label %bb186, label %bb187
bb185:
  call void @__olang_check_failed(ptr @olang_loc_7ec9c6dbabf95ed5_e8695782fec42ca9)
  unreachable
bb186:
  %t973 = mul i64 0, 4
  %t974 = insertvalue { i64, ptr } undef, i64 0, 0
  %t975 = insertvalue { i64, ptr } %t974, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t976 = load ptr, ptr %l476, !tbaa !29
  %t977 = load %"compiler/source:Span", ptr %l477
  %t978 = load %"compiler/source:Span", ptr %l478
  %t979 = load i64, ptr %l479, !tbaa !24
  %t980 = load ptr, ptr %l481, !tbaa !29
  %t981 = load { i64, ptr }, ptr %l484, !tbaa !27
  %t982 = load { i64, ptr }, ptr %l487, !tbaa !27
  %t984 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v1, ptr %v0, ptr %v0, ptr %v3, ptr %v3, ptr %t976, %"compiler/source:Span" %t977, %"compiler/source:Span" %t978, i64 %t979, ptr %t980, { i64, ptr } %t981, { i64, ptr } %t982, { i64, ptr } %t975)
  store ptr %t984, ptr %l491
  br label %bb188
bb187:
  call void @__olang_check_failed(ptr @olang_loc_7ec9c6dbabf95ed5_e8695782fec42ca9)
  unreachable
bb188:
  %t985 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 8, i64 8)
  store ptr %t985, ptr %lp28
  %t986 = load ptr, ptr %l491, !tbaa !29
  %t987 = load ptr, ptr %lp28
  store ptr %t986, ptr %t987, !tbaa !29
  %t988 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t990 = trunc i64 79 to i32
  %t991 = icmp eq i32 %t988, %t990
  br i1 %t991, label %bb189, label %bb190
bb189:
  %t993 = load ptr, ptr %l0, !tbaa !29
  %t994 = load %"compiler/source:Span", ptr %l1
  %t995 = load ptr, ptr %lp28
  %t996 = load ptr, ptr %t995, !tbaa !29
  %t1000 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %v3, ptr %v3, ptr %t993, %"compiler/source:Span" %t994, ptr %t996)
  store ptr %t1000, ptr %l498
  br label %bb191
bb190:
  %t1001 = load ptr, ptr %lp28
  %t1002 = load ptr, ptr %t1001, !tbaa !29
  store ptr %t1002, ptr %l494, !tbaa !29
  br label %bb192
bb191:
  %t1004 = load ptr, ptr %l498, !tbaa !29
  store ptr %t1004, ptr %l494, !tbaa !29
  br label %bb192
bb192:
  %t1005 = load ptr, ptr %l494, !tbaa !29
  store ptr %t1005, ptr %rv
  br label %ret
bb193:
  %t1006 = load ptr, ptr %l0, !tbaa !29
  %t1007 = load i32, ptr %l5, !tbaa !23
  %t1010 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t1006, i32 %t1007)
  store i1 %t1010, ptr %l502
  br label %bb194
bb194:
  %t1011 = load i1, ptr %l502, !tbaa !21
  br i1 %t1011, label %bb195, label %bb196
bb195:
  %t1012 = load ptr, ptr %l0, !tbaa !29
  %t1013 = load i32, ptr %l6, !tbaa !23
  %t1016 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t1012, i32 %t1013)
  store i1 %t1016, ptr %l506
  br label %bb197
bb196:
  store i1 false, ptr %l503, !tbaa !21
  br label %bb198
bb197:
  %t1017 = load i1, ptr %l506, !tbaa !21
  store i1 %t1017, ptr %l503, !tbaa !21
  br label %bb198
bb198:
  %t1018 = load i1, ptr %l503, !tbaa !21
  br i1 %t1018, label %bb199, label %bb200
bb199:
  %t1019 = load ptr, ptr %l0, !tbaa !29
  %t1020 = load i32, ptr %l9, !tbaa !23
  %t1023 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %t1019, i32 %t1020)
  store i1 %t1023, ptr %l510
  br label %bb201
bb200:
  store i1 false, ptr %l507, !tbaa !21
  br label %bb210
bb201:
  %t1024 = load i1, ptr %l510, !tbaa !21
  br i1 %t1024, label %bb202, label %bb203
bb202:
  store i1 true, ptr %l511, !tbaa !21
  br label %bb205
bb203:
  %t1025 = load ptr, ptr %l0, !tbaa !29
  %t1026 = load i32, ptr %l9, !tbaa !23
  %t1029 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t1025, i32 %t1026)
  store i1 %t1029, ptr %l514
  br label %bb204
bb204:
  %t1030 = load i1, ptr %l514, !tbaa !21
  store i1 %t1030, ptr %l511, !tbaa !21
  br label %bb205
bb205:
  %t1031 = load i1, ptr %l511, !tbaa !21
  br i1 %t1031, label %bb206, label %bb207
bb206:
  store i1 true, ptr %l515, !tbaa !21
  br label %bb209
bb207:
  %t1032 = load ptr, ptr %l0, !tbaa !29
  %t1034 = getelementptr %"compiler/check:Checker", ptr %t1032, i32 0, i32 1
  %t1035 = load ptr, ptr %t1034, !tbaa !29
  %t1037 = getelementptr %"compiler/generic:Program", ptr %t1035, i32 0, i32 2
  %t1038 = load i32, ptr %l9, !tbaa !23
  %t1041 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1037, i32 %t1038)
  store i32 %t1041, ptr %l520
  br label %bb208
bb208:
  %t1042 = load i32, ptr %l520, !range !{i32 0, i32 33}
  %t1044 = trunc i64 29 to i32
  %t1045 = icmp eq i32 %t1042, %t1044
  store i1 %t1045, ptr %l515, !tbaa !21
  br label %bb209
bb209:
  %t1047 = load i1, ptr %l515, !tbaa !21
  store i1 %t1047, ptr %l507, !tbaa !21
  br label %bb210
bb210:
  %t1048 = load i1, ptr %l507, !tbaa !21
  br i1 %t1048, label %bb211, label %bb212
bb211:
  %t1049 = load ptr, ptr %l0, !tbaa !29
  %t1050 = load %"compiler/source:Span", ptr %l1
  %t1051 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t1052 = load ptr, ptr %l3, !tbaa !29
  %t1053 = load ptr, ptr %l4, !tbaa !29
  %t1061 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t1049, %"compiler/source:Span" %t1050, i32 %t1051, i32 19, ptr %t1052, ptr %t1053)
  store ptr %t1061, ptr %l530
  br label %bb213
bb212:
  br label %bb218
bb213:
  %t1062 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 8, i64 8)
  store ptr %t1062, ptr %lp29
  %t1063 = load ptr, ptr %l530, !tbaa !29
  %t1064 = load ptr, ptr %lp29
  store ptr %t1063, ptr %t1064, !tbaa !29
  %t1065 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t1067 = trunc i64 79 to i32
  %t1068 = icmp eq i32 %t1065, %t1067
  br i1 %t1068, label %bb214, label %bb215
bb214:
  %t1070 = load ptr, ptr %l0, !tbaa !29
  %t1071 = load %"compiler/source:Span", ptr %l1
  %t1072 = load ptr, ptr %lp29
  %t1073 = load ptr, ptr %t1072, !tbaa !29
  %t1077 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %v3, ptr %v3, ptr %t1070, %"compiler/source:Span" %t1071, ptr %t1073)
  store ptr %t1077, ptr %l537
  br label %bb216
bb215:
  %t1078 = load ptr, ptr %lp29
  %t1079 = load ptr, ptr %t1078, !tbaa !29
  store ptr %t1079, ptr %l533, !tbaa !29
  br label %bb217
bb216:
  %t1081 = load ptr, ptr %l537, !tbaa !29
  store ptr %t1081, ptr %l533, !tbaa !29
  br label %bb217
bb217:
  %t1082 = load ptr, ptr %l533, !tbaa !29
  store ptr %t1082, ptr %rv
  br label %ret
bb218:
  %t1083 = load ptr, ptr %l0, !tbaa !29
  %t1084 = load i32, ptr %l9, !tbaa !23
  %t1087 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epartsHaveEq(ptr %v0, ptr %t1083, i32 %t1084, i64 0)
  store i1 %t1087, ptr %l541
  br label %bb219
bb219:
  %t1088 = load i1, ptr %l541, !tbaa !21
  br i1 %t1088, label %bb220, label %bb221
bb220:
  %t1089 = load ptr, ptr %l0, !tbaa !29
  %t1090 = load %"compiler/source:Span", ptr %l1
  %t1091 = load ptr, ptr %l3, !tbaa !29
  %t1092 = load ptr, ptr %l4, !tbaa !29
  %t1093 = load i32, ptr %l9, !tbaa !23
  %t1099 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epartsEqual(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t1089, %"compiler/source:Span" %t1090, ptr %t1091, ptr %t1092, i32 %t1093)
  store ptr %t1099, ptr %l547
  br label %bb222
bb221:
  br label %bb232
bb222:
  %t1100 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 8, i64 8)
  store ptr %t1100, ptr %lp30
  %t1101 = load ptr, ptr %l547, !tbaa !29
  %t1102 = load ptr, ptr %lp30
  store ptr %t1101, ptr %t1102, !tbaa !29
  %t1103 = load ptr, ptr %lp30
  %t1104 = load ptr, ptr %t1103, !tbaa !29
  %t1106 = icmp eq ptr %t1104, null
  br i1 %t1106, label %bb223, label %bb224
bb223:
  store %olang.scope zeroinitializer, ptr %s15
  %t1108 = load ptr, ptr %l0, !tbaa !29
  %t1109 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s15, ptr %t1108, %"compiler/source:Span" %t1109, { i64, ptr } { i64 54, ptr getelementptr inbounds (<{ i64, [54 x i8] }>, ptr @.d6, i32 0, i32 1) })
  br label %bb225
bb224:
  br label %bb227
bb225:
  %t1112 = load ptr, ptr %l0, !tbaa !29
  %t1113 = load %"compiler/source:Span", ptr %l1
  %t1114 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t1118 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t1112, %"compiler/source:Span" %t1113, i32 %t1114, i64 0)
  store ptr %t1118, ptr %l555
  br label %bb226
bb226:
  call void @__olang_scope_close(ptr %s15)
  %t1119 = load ptr, ptr %l555, !tbaa !29
  store ptr %t1119, ptr %rv
  br label %ret
bb227:
  %t1120 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t1122 = trunc i64 79 to i32
  %t1123 = icmp eq i32 %t1120, %t1122
  br i1 %t1123, label %bb228, label %bb229
bb228:
  %t1125 = load ptr, ptr %l0, !tbaa !29
  %t1126 = load %"compiler/source:Span", ptr %l1
  %t1127 = load ptr, ptr %lp30
  %t1128 = load ptr, ptr %t1127, !tbaa !29
  %t1132 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %v3, ptr %v3, ptr %t1125, %"compiler/source:Span" %t1126, ptr %t1128)
  store ptr %t1132, ptr %l562
  br label %bb230
bb229:
  %t1133 = load ptr, ptr %lp30
  %t1134 = load ptr, ptr %t1133, !tbaa !29
  store ptr %t1134, ptr %l558, !tbaa !29
  br label %bb231
bb230:
  %t1136 = load ptr, ptr %l562, !tbaa !29
  store ptr %t1136, ptr %l558, !tbaa !29
  br label %bb231
bb231:
  %t1137 = load ptr, ptr %l558, !tbaa !29
  store ptr %t1137, ptr %rv
  br label %ret
bb232:
  %t1138 = load ptr, ptr %l0, !tbaa !29
  %t1139 = load i32, ptr %l5, !tbaa !23
  %t1142 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t1138, i32 %t1139)
  store i1 %t1142, ptr %l566
  br label %bb233
bb233:
  %t1143 = load i1, ptr %l566, !tbaa !21
  br i1 %t1143, label %bb234, label %bb235
bb234:
  %t1144 = load ptr, ptr %l0, !tbaa !29
  %t1145 = load i32, ptr %l6, !tbaa !23
  %t1148 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t1144, i32 %t1145)
  store i1 %t1148, ptr %l570
  br label %bb236
bb235:
  store i1 false, ptr %l567, !tbaa !21
  br label %bb237
bb236:
  %t1149 = load i1, ptr %l570, !tbaa !21
  store i1 %t1149, ptr %l567, !tbaa !21
  br label %bb237
bb237:
  %t1150 = load i1, ptr %l567, !tbaa !21
  br i1 %t1150, label %bb238, label %bb239
bb238:
  %t1151 = load ptr, ptr %l0, !tbaa !29
  %t1153 = getelementptr %"compiler/check:Checker", ptr %t1151, i32 0, i32 1
  %t1154 = load ptr, ptr %t1153, !tbaa !29
  %t1156 = getelementptr %"compiler/generic:Program", ptr %t1154, i32 0, i32 2
  %t1157 = load i32, ptr %l9, !tbaa !23
  %t1158 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t1162 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t1156, i32 %t1157, i64 %t1158)
  store i32 %t1162, ptr %l577
  br label %bb240
bb239:
  %t1163 = load i32, ptr %l9, !tbaa !23
  store i32 %t1163, ptr %l571, !tbaa !23
  br label %bb241
bb240:
  %t1165 = load i32, ptr %l577, !tbaa !23
  store i32 %t1165, ptr %l571, !tbaa !23
  br label %bb241
bb241:
  %t1166 = load i32, ptr %l571, !tbaa !23
  store i32 %t1166, ptr %l31, !tbaa !23
  %t1167 = load ptr, ptr %l0, !tbaa !29
  %t1168 = load i32, ptr %l5, !tbaa !23
  %t1171 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t1167, i32 %t1168)
  store i1 %t1171, ptr %l581
  br label %bb242
bb242:
  %t1172 = load i1, ptr %l581, !tbaa !21
  br i1 %t1172, label %bb243, label %bb244
bb243:
  %t1173 = load ptr, ptr %l0, !tbaa !29
  %t1174 = load i32, ptr %l6, !tbaa !23
  %t1177 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t1173, i32 %t1174)
  store i1 %t1177, ptr %l585
  br label %bb245
bb244:
  store i1 false, ptr %l582, !tbaa !21
  br label %bb246
bb245:
  %t1178 = load i1, ptr %l585, !tbaa !21
  store i1 %t1178, ptr %l582, !tbaa !21
  br label %bb246
bb246:
  %t1179 = load i1, ptr %l582, !tbaa !21
  br i1 %t1179, label %bb247, label %bb248
bb247:
  %t1180 = load ptr, ptr %l0, !tbaa !29
  %t1182 = getelementptr %"compiler/check:Checker", ptr %t1180, i32 0, i32 1
  %t1183 = load ptr, ptr %t1182, !tbaa !29
  %t1185 = getelementptr %"compiler/generic:Program", ptr %t1183, i32 0, i32 2
  %t1186 = load i32, ptr %l5, !tbaa !23
  %t1189 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t1185, i32 %t1186)
  store i1 %t1189, ptr %l591
  br label %bb249
bb248:
  store i1 false, ptr %l586, !tbaa !21
  br label %bb254
bb249:
  %t1190 = load i1, ptr %l591, !tbaa !21
  br i1 %t1190, label %bb250, label %bb251
bb250:
  store i1 true, ptr %l592, !tbaa !21
  br label %bb253
bb251:
  %t1191 = load ptr, ptr %l0, !tbaa !29
  %t1193 = getelementptr %"compiler/check:Checker", ptr %t1191, i32 0, i32 1
  %t1194 = load ptr, ptr %t1193, !tbaa !29
  %t1196 = getelementptr %"compiler/generic:Program", ptr %t1194, i32 0, i32 2
  %t1197 = load i32, ptr %l6, !tbaa !23
  %t1200 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t1196, i32 %t1197)
  store i1 %t1200, ptr %l597
  br label %bb252
bb252:
  %t1201 = load i1, ptr %l597, !tbaa !21
  store i1 %t1201, ptr %l592, !tbaa !21
  br label %bb253
bb253:
  %t1202 = load i1, ptr %l592, !tbaa !21
  store i1 %t1202, ptr %l586, !tbaa !21
  br label %bb254
bb254:
  %t1203 = load i1, ptr %l586, !tbaa !21
  br i1 %t1203, label %bb255, label %bb256
bb255:
  %t1204 = load ptr, ptr %l0, !tbaa !29
  %t1206 = getelementptr %"compiler/check:Checker", ptr %t1204, i32 0, i32 1
  %t1207 = load ptr, ptr %t1206, !tbaa !29
  %t1209 = getelementptr %"compiler/generic:Program", ptr %t1207, i32 0, i32 2
  %t1210 = load i32, ptr %l31, !tbaa !23
  %t1213 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %t1209, i32 %t1210)
  store i32 %t1213, ptr %l602
  br label %bb257
bb256:
  br label %bb258
bb257:
  %t1214 = load i32, ptr %l602, !tbaa !23
  store i32 %t1214, ptr %l31, !tbaa !23
  br label %bb258
bb258:
  %t1215 = load ptr, ptr %l0, !tbaa !29
  %t1216 = load ptr, ptr %l3, !tbaa !29
  %t1217 = load i32, ptr %l31, !tbaa !23
  %t1218 = load %"compiler/source:Span", ptr %l1
  %t1223 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v1, ptr %v3, ptr %t1215, ptr %t1216, i32 %t1217, %"compiler/source:Span" %t1218)
  store ptr %t1223, ptr %l607
  br label %bb259
bb259:
  %t1224 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 8, i64 8)
  store ptr %t1224, ptr %lp32
  %t1225 = load ptr, ptr %l607, !tbaa !29
  %t1226 = load ptr, ptr %lp32
  store ptr %t1225, ptr %t1226, !tbaa !29
  %t1227 = load ptr, ptr %l0, !tbaa !29
  %t1228 = load ptr, ptr %l4, !tbaa !29
  %t1229 = load i32, ptr %l31, !tbaa !23
  %t1230 = load %"compiler/source:Span", ptr %l1
  %t1235 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v2, ptr %v3, ptr %t1227, ptr %t1228, i32 %t1229, %"compiler/source:Span" %t1230)
  store ptr %t1235, ptr %l612
  br label %bb260
bb260:
  %t1236 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 8, i64 8)
  store ptr %t1236, ptr %lp33
  %t1237 = load ptr, ptr %l612, !tbaa !29
  %t1238 = load ptr, ptr %lp33
  store ptr %t1237, ptr %t1238, !tbaa !29
  %t1239 = load ptr, ptr %l0, !tbaa !29
  %t1241 = getelementptr %"compiler/check:Checker", ptr %t1239, i32 0, i32 36
  %t1243 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t1241)
  store i64 %t1243, ptr %l615
  br label %bb261
bb261:
  %t1244 = load i64, ptr %l615, !tbaa !24
  store i64 %t1244, ptr %l34, !tbaa !24
  %t1245 = load ptr, ptr %l0, !tbaa !29
  %t1247 = getelementptr %"compiler/check:Checker", ptr %t1245, i32 0, i32 36
  %t1248 = load ptr, ptr %lp32
  %t1249 = load ptr, ptr %t1248, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v3, ptr %t1247, ptr %t1249)
  br label %bb262
bb262:
  %t1252 = load ptr, ptr %l0, !tbaa !29
  %t1254 = getelementptr %"compiler/check:Checker", ptr %t1252, i32 0, i32 36
  %t1255 = load ptr, ptr %lp33
  %t1256 = load ptr, ptr %t1255, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v3, ptr %t1254, ptr %t1256)
  br label %bb263
bb263:
  %t1259 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1259, ptr %l622, !tbaa !29
  %t1260 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1260, ptr %l623
  %t1261 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t1261, ptr %l624, !tbaa !23
  %t1262 = load i32, ptr %l31, !tbaa !23
  store { i64, [3 x i64] } zeroinitializer, ptr %t1263
  %t1264 = getelementptr { i64, [3 x i64] }, ptr %t1263, i32 0, i32 0
  store i64 4, ptr %t1264
  %t1266 = insertvalue { i32, i32 } undef, i32 0, 0
  %t1268 = insertvalue { i32, i32 } %t1266, i32 %t1262, 1
  %t1269 = getelementptr { i64, [3 x i64] }, ptr %t1263, i32 0, i32 1
  store { i32, i32 } %t1268, ptr %t1269
  %t1270 = load { i64, [3 x i64] }, ptr %t1263
  %t1272 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 32, i64 8)
  store { i64, [3 x i64] } %t1270, ptr %t1272
  store ptr %t1272, ptr %l628, !tbaa !29
  %t1273 = load ptr, ptr %l0, !tbaa !29
  %t1275 = getelementptr %"compiler/check:Checker", ptr %t1273, i32 0, i32 36
  %t1276 = load i64, ptr %l34, !tbaa !24
  %t1279 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t1275, i64 %t1276)
  store { i64, ptr } %t1279, ptr %l632
  br label %bb264
bb264:
  %t1280 = load ptr, ptr %l622, !tbaa !29
  %t1281 = load %"compiler/source:Span", ptr %l623
  %t1282 = load i32, ptr %l624, !tbaa !23
  %t1283 = load ptr, ptr %l628, !tbaa !29
  %t1284 = load { i64, ptr }, ptr %l632, !tbaa !27
  %t1285 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallOf(ptr %v0, ptr %v3, ptr %v0, ptr %v3, ptr %t1280, %"compiler/source:Span" %t1281, i32 %t1282, ptr %t1283, { i64, ptr } %t1284)
  store ptr %t1285, ptr %l633
  br label %bb265
bb265:
  %t1286 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 8, i64 8)
  store ptr %t1286, ptr %lp35
  %t1287 = load ptr, ptr %l633, !tbaa !29
  %t1288 = load ptr, ptr %lp35
  store ptr %t1287, ptr %t1288, !tbaa !29
  %t1289 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t1291 = trunc i64 79 to i32
  %t1292 = icmp eq i32 %t1289, %t1291
  br i1 %t1292, label %bb266, label %bb267
bb266:
  %t1294 = load ptr, ptr %l0, !tbaa !29
  %t1295 = load %"compiler/source:Span", ptr %l1
  %t1296 = load ptr, ptr %lp35
  %t1297 = load ptr, ptr %t1296, !tbaa !29
  %t1301 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %v3, ptr %v3, ptr %t1294, %"compiler/source:Span" %t1295, ptr %t1297)
  store ptr %t1301, ptr %l640
  br label %bb268
bb267:
  %t1302 = load ptr, ptr %lp35
  %t1303 = load ptr, ptr %t1302, !tbaa !29
  store ptr %t1303, ptr %l636, !tbaa !29
  br label %bb269
bb268:
  %t1305 = load ptr, ptr %l640, !tbaa !29
  store ptr %t1305, ptr %l636, !tbaa !29
  br label %bb269
bb269:
  %t1306 = load ptr, ptr %l636, !tbaa !29
  store ptr %t1306, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrsText(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l14 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca %"std/prelude/text:StringBuilder"
  %l28 = alloca i64
  %l31 = alloca i64
  %l52 = alloca ptr
  %l54 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l64 = alloca i64
  %l65 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t6, i32 %a1)
  store { i64, ptr } %t10, ptr %l14
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t11, ptr %l2, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t16 = icmp eq i64 %t14, 0
  br i1 %t16, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d7, i32 0, i32 1) }, ptr %l18, !tbaa !27
  %t18 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t18, ptr %l19, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t19, 0
  store i64 %t20, ptr %l20, !tbaa !24
  %t21 = load i64, ptr %l20, !tbaa !24
  %t22 = mul i64 %t21, 1
  %t23 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t22)
  %t24 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  store { i64, ptr } %t25, ptr %l21, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = load i64, ptr %l20, !tbaa !24
  %t31 = mul i64 %t30, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t27, ptr %t29, i64 %t31, i1 false)
  %t32 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t32, ptr %l19, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t33 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t33, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t34 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t34, ptr %l22
  br label %bb5
bb5:
  %t35 = load %"std/prelude/text:StringBuilder", ptr %l22
  store %"std/prelude/text:StringBuilder" %t35, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  %t36 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t36, 0
  store i64 %t38, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t40 = load i64, ptr %l5, !tbaa !24
  %t41 = load i64, ptr %l4, !tbaa !24
  %t44 = icmp sgt i64 %t40, %t41
  br i1 %t44, label %bb6, label %bb7
bb6:
  %t46 = load i64, ptr %l6, !tbaa !24
  %t48 = icmp sgt i64 %t46, 0
  br i1 %t48, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb11
bb8:
  %t50 = load i64, ptr %l5, !tbaa !24
  %t51 = load i64, ptr %l4, !tbaa !24
  %t54 = sub i64 %t50, %t51
  %t55 = load i64, ptr %l6, !tbaa !24
  %t58 = add i64 %t54, %t55
  %t60 = sub i64 %t58, 1
  %t61 = load i64, ptr %l6, !tbaa !24
  %t64 = sdiv i64 %t60, %t61
  store i64 %t64, ptr %l31, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb10
bb10:
  %t66 = load i64, ptr %l31, !tbaa !24
  store i64 %t66, ptr %l28, !tbaa !24
  br label %bb11
bb11:
  %t67 = load i64, ptr %l28, !tbaa !24
  store i64 %t67, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t68 = load i64, ptr %l8, !tbaa !24
  %t69 = load i64, ptr %l7, !tbaa !24
  %t72 = icmp slt i64 %t68, %t69
  %t74 = xor i1 %t72, true
  br i1 %t74, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb14:
  br label %bb15
bb15:
  %t76 = load i64, ptr %l4, !tbaa !24
  %t77 = load i64, ptr %l8, !tbaa !24
  %t78 = load i64, ptr %l6, !tbaa !24
  %t81 = mul i64 %t77, %t78
  %t84 = add i64 %t76, %t81
  store i64 %t84, ptr %l9, !tbaa !24
  %t86 = load i64, ptr %l9, !tbaa !24
  %t88 = icmp sgt i64 %t86, 0
  br i1 %t88, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s4
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %l3, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d8, i32 0, i32 1) })
  br label %bb18
bb17:
  br label %bb19
bb18:
  call void @__olang_scope_close(ptr %s4)
  br label %bb19
bb19:
  store ptr %l3, ptr %l52, !tbaa !29
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t92, ptr %l54, !tbaa !27
  %t93 = load i64, ptr %l9, !tbaa !24
  %t95 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = getelementptr i32, ptr %t96, i64 %t93
  %t98 = load i32, ptr %t97, !tbaa !33
  %t101 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s3, ptr %t91, i32 %t98)
  store { i64, ptr } %t101, ptr %l57
  br label %bb20
bb20:
  %t102 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t102, 0
  %t104 = extractvalue { i64, ptr } %t102, 1
  %t105 = mul i64 %t103, 1
  %t106 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t105)
  call void @llvm.memcpy.p0.p0.i64(ptr %t106, ptr %t104, i64 %t105, i1 false)
  %t107 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t106, 1
  %t109 = load ptr, ptr %l52, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %t109, { i64, ptr } %t108)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s3)
  br label %bb22
bb22:
  %t111 = load i64, ptr %l8, !tbaa !24
  %t113 = add i64 %t111, 1
  store i64 %t113, ptr %l8, !tbaa !24
  br label %bb12
bb23:
  %t116 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l3)
  store { i64, ptr } %t116, ptr %l62
  br label %bb24
bb24:
  %t117 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t117, ptr %l63, !tbaa !27
  %t118 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t118, 0
  store i64 %t119, ptr %l64, !tbaa !24
  %t120 = load i64, ptr %l64, !tbaa !24
  %t121 = mul i64 %t120, 1
  %t122 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t121)
  %t123 = insertvalue { i64, ptr } undef, i64 %t120, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr %t122, 1
  store { i64, ptr } %t124, ptr %l65, !tbaa !27
  %t125 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !27
  %t127 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t128 = load ptr, ptr %t127, !tbaa !27
  %t129 = load i64, ptr %l64, !tbaa !24
  %t130 = mul i64 %t129, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t126, ptr %t128, i64 %t130, i1 false)
  %t131 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t131, ptr %l63, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t132 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t132, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexportParam(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l6 = alloca i1
  %l10 = alloca i1
  %l17 = alloca i32
  %l20 = alloca i1
  %l24 = alloca i32
  %l29 = alloca i32
  %l32 = alloca i1
  %l33 = alloca ptr
  %l38 = alloca i32
  %l39 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternValue(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i1, ptr %l6, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load i32, ptr %l1, !tbaa !23
  %t12 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t8, i32 %t9)
  store i1 %t12, ptr %l10
  br label %bb5
bb5:
  %t13 = load i1, ptr %l10, !tbaa !21
  %t14 = xor i1 %t13, true
  br i1 %t14, label %bb6, label %bb7
bb6:
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/check:Checker", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = getelementptr %"compiler/generic:Program", ptr %t20, i32 0, i32 2
  %t23 = load i32, ptr %l1, !tbaa !23
  %t26 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t22, i32 %t23)
  store i32 %t26, ptr %l17
  br label %bb9
bb9:
  %t27 = load i32, ptr %l17, !tbaa !23
  store i32 %t27, ptr %l2, !tbaa !23
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l2, !tbaa !23
  %t32 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplainStruct(ptr %v0, ptr %t28, i32 %t29, i64 0)
  store i1 %t32, ptr %l20
  br label %bb10
bb10:
  %t33 = load i1, ptr %l20, !tbaa !21
  br i1 %t33, label %bb11, label %bb12
bb11:
  store i1 true, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load i32, ptr %l2, !tbaa !23
  %t39 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t35, i32 %t36)
  store i32 %t39, ptr %l24
  br label %bb14
bb14:
  %t40 = load i32, ptr %l24, !tbaa !23
  store i32 %t40, ptr %l3, !tbaa !23
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/check:Checker", ptr %t41, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = getelementptr %"compiler/generic:Program", ptr %t44, i32 0, i32 2
  %t47 = load i32, ptr %l3, !tbaa !23
  %t50 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t46, i32 %t47)
  store i32 %t50, ptr %l29
  br label %bb15
bb15:
  %t51 = load i32, ptr %l29, !range !{i32 0, i32 33}
  %t53 = trunc i64 19 to i32
  %t54 = icmp eq i32 %t51, %t53
  br i1 %t54, label %bb16, label %bb17
bb16:
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l33, !tbaa !29
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = getelementptr %"compiler/generic:Program", ptr %t60, i32 0, i32 2
  %t63 = load i32, ptr %l3, !tbaa !23
  %t66 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t62, i32 %t63)
  store i32 %t66, ptr %l38
  br label %bb18
bb17:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb20
bb18:
  %t67 = load ptr, ptr %l33, !tbaa !29
  %t68 = load i32, ptr %l38, !tbaa !23
  %t69 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternValue(ptr %v0, ptr %t67, i32 %t68)
  store i1 %t69, ptr %l39
  br label %bb19
bb19:
  %t70 = load i1, ptr %l39, !tbaa !21
  store i1 %t70, ptr %l32, !tbaa !21
  br label %bb20
bb20:
  %t71 = load i1, ptr %l32, !tbaa !21
  store i1 %t71, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %lp3 = alloca ptr
  %lp4 = alloca ptr
  %l9 = alloca ptr
  %l18 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca i32
  %l28 = alloca %"compiler/source:Span"
  %l29 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = load i32, ptr %l2, !tbaa !23
  %t8 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitCtor(ptr %v0, ptr %v1, ptr %v2, ptr %t1, ptr %t2, i32 %t4)
  store ptr %t8, ptr %l9
  br label %bb1
bb1:
  %t9 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store ptr %t9, ptr %lp3
  %t10 = load ptr, ptr %l9, !tbaa !29
  %t11 = load ptr, ptr %lp3
  store ptr %t10, ptr %t11, !tbaa !29
  %t12 = load ptr, ptr %lp3
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = icmp eq ptr %t13, null
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb2, label %bb3
bb2:
  %t19 = load ptr, ptr %lp3
  %t20 = load ptr, ptr %t19, !tbaa !29
  store ptr %t20, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load ptr, ptr %l1, !tbaa !29
  %t25 = load i32, ptr %l2, !tbaa !23
  %t29 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t22, ptr %t23, i32 %t25)
  store ptr %t29, ptr %l18
  br label %bb5
bb5:
  %t30 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store ptr %t30, ptr %lp4
  %t31 = load ptr, ptr %l18, !tbaa !29
  %t32 = load ptr, ptr %lp4
  store ptr %t31, ptr %t32, !tbaa !29
  %t33 = load i32, ptr %l2, !tbaa !23
  %t34 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t37 = icmp eq i32 %t33, %t34
  br i1 %t37, label %bb6, label %bb7
bb6:
  %t39 = load ptr, ptr %lp4
  %t40 = load ptr, ptr %t39, !tbaa !29
  store ptr %t40, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t42 = load ptr, ptr %l0, !tbaa !29
  store ptr %t42, ptr %l23, !tbaa !29
  %t43 = load ptr, ptr %lp4
  %t44 = load ptr, ptr %t43, !tbaa !29
  store ptr %t44, ptr %l24, !tbaa !29
  %t45 = load i32, ptr %l2, !tbaa !23
  store i32 %t45, ptr %l25, !tbaa !23
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load ptr, ptr %l1, !tbaa !29
  %t50 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargSpan(ptr %v0, ptr %v1, ptr %t46, ptr %t47)
  store %"compiler/source:Span" %t50, ptr %l28
  br label %bb9
bb9:
  %t51 = load ptr, ptr %l23, !tbaa !29
  %t52 = load ptr, ptr %l24, !tbaa !29
  %t53 = load i32, ptr %l25, !tbaa !23
  %t54 = load %"compiler/source:Span", ptr %l28
  %t55 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v2, ptr %v2, ptr %t51, ptr %t52, i32 %t53, %"compiler/source:Span" %t54)
  store ptr %t55, ptr %l29
  br label %bb10
bb10:
  %t56 = load ptr, ptr %l29, !tbaa !29
  store ptr %t56, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactInst(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca i32
  %l12 = alloca { i64, ptr }
  %l13 = alloca i32
  %l15 = alloca i64
  %l19 = alloca i64
  %l24 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca i1
  %l37 = alloca { i64, ptr }
  %l39 = alloca i64
  %l43 = alloca i64
  %l53 = alloca { i64, ptr }
  %l63 = alloca ptr
  %l64 = alloca i64
  %l69 = alloca i32
  %l70 = alloca i64
  %l73 = alloca i32
  %l76 = alloca i1
  %l80 = alloca %"compiler/generic:Desc"
  %l87 = alloca ptr
  %l90 = alloca ptr
  %l94 = alloca %"compiler/generic:Desc"
  %l96 = alloca i32
  %l97 = alloca { i64, ptr }
  %l101 = alloca i1
  %l105 = alloca ptr
  %l111 = alloca { i64, ptr }
  %l113 = alloca i32
  %l116 = alloca i1
  %l118 = alloca i1
  %l121 = alloca ptr
  %l126 = alloca i32
  %l127 = alloca { i64, ptr }
  %l128 = alloca i64
  %l132 = alloca i64
  %l136 = alloca ptr
  %l137 = alloca i64
  %l142 = alloca i32
  %l143 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t1)
  store i64 %t3, ptr %l15
  br label %bb1
bb1:
  %t4 = load i64, ptr %l15, !tbaa !24
  store i64 %t4, ptr %l3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t9 = load i64, ptr %l3, !tbaa !24
  %t12 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t8, i64 %t9)
  store i64 %t12, ptr %l19
  br label %bb2
bb2:
  %t13 = load i64, ptr %l19, !tbaa !24
  %t14 = icmp eq i64 %t13, 0
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %t19, i64 %t20, i32 0)
  store i64 %t23, ptr %l24
  br label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t24 = load i64, ptr %l24, !tbaa !24
  store i64 %t24, ptr %rv
  br label %ret
bb6:
  %t25 = load ptr, ptr %l1, !tbaa !29
  store ptr %t25, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t26 = load ptr, ptr %l25, !tbaa !29
  %t27 = icmp ne ptr %t26, null
  br i1 %t27, label %bb7, label %bb8
bb7:
  %t29 = load ptr, ptr %l25, !tbaa !29
  %t30 = load i64, ptr %t29, !range !{i64 0, i64 30}
  %t32 = icmp eq i64 %t30, 13
  store i1 %t32, ptr %l26, !tbaa !21
  br label %bb8
bb8:
  %t33 = load i1, ptr %l26, !tbaa !21
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr { i64, [4 x i64] }, ptr %t34, i32 0, i32 1
  %t37 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t36, i32 0, i32 0
  %t38 = load %"compiler/source:Span", ptr %t37
  store %"compiler/source:Span" %t38, ptr %l4
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr { i64, [4 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t42, i32 0, i32 2
  %t44 = load { i64, ptr }, ptr %t43
  store { i64, ptr } %t44, ptr %l5, !tbaa !27
  br label %bb11
bb10:
  br label %bb28
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load i64, ptr %l2, !tbaa !24
  %t48 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t49 = load %"compiler/source:Span", ptr %l4
  %t54 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexplicitArgs(ptr %v0, ptr %v1, ptr %s2, ptr %t46, i64 %t47, { i64, ptr } %t48, %"compiler/source:Span" %t49)
  store { i64, ptr } %t54, ptr %l37
  br label %bb12
bb12:
  %t55 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t55, ptr %l6, !tbaa !27
  %t56 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t56, 0
  store i64 %t58, ptr %l39, !tbaa !24
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t63 = load i64, ptr %l3, !tbaa !24
  %t66 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t62, i64 %t63)
  store i64 %t66, ptr %l43
  br label %bb13
bb13:
  %t67 = load i64, ptr %l39, !tbaa !24
  %t68 = load i64, ptr %l43, !tbaa !24
  %t69 = icmp ne i64 %t67, %t68
  br i1 %t69, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t72 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t72, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t74 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t74, 0
  store i64 %t76, ptr %l9, !tbaa !24
  br label %bb17
bb17:
  %t78 = load i64, ptr %l8, !tbaa !24
  %t79 = load i64, ptr %l9, !tbaa !24
  %t82 = icmp slt i64 %t78, %t79
  %t84 = xor i1 %t82, true
  br i1 %t84, label %bb18, label %bb19
bb18:
  br label %bb25
bb19:
  br label %bb20
bb20:
  %t86 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t86, ptr %l53, !tbaa !27
  %t87 = load i64, ptr %l8, !tbaa !24
  %t89 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !27
  %t91 = getelementptr i32, ptr %t90, i64 %t87
  %t92 = load i32, ptr %t91, !tbaa !33
  %t95 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t98 = icmp eq i32 %t92, %t95
  br i1 %t98, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t101 = load i64, ptr %l8, !tbaa !24
  %t103 = add i64 %t101, 1
  store i64 %t103, ptr %l8, !tbaa !24
  br label %bb17
bb25:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/check:Checker", ptr %t105, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !29
  store ptr %t108, ptr %l63, !tbaa !29
  %t109 = load i64, ptr %l2, !tbaa !24
  store i64 %t109, ptr %l64, !tbaa !24
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/check:Checker", ptr %t110, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t115 = getelementptr %"compiler/generic:Program", ptr %t113, i32 0, i32 2
  %t116 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t119 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s2, ptr %t115, { i64, ptr } %t116)
  store i32 %t119, ptr %l69
  br label %bb26
bb26:
  %t120 = load ptr, ptr %l63, !tbaa !29
  %t121 = load i64, ptr %l64, !tbaa !24
  %t122 = load i32, ptr %l69, !tbaa !23
  %t123 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %t120, i64 %t121, i32 %t122)
  store i64 %t123, ptr %l70
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t124 = load i64, ptr %l70, !tbaa !24
  store i64 %t124, ptr %rv
  br label %ret
bb28:
  br i1 true, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_c361d907896d08d5_2eb86c98dc279551)
  unreachable
bb33:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load ptr, ptr %l1, !tbaa !29
  %t129 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescTypeOf(ptr %v0, ptr %v1, ptr %t125, ptr %t126)
  store i32 %t129, ptr %l73
  br label %bb34
bb34:
  %t130 = load i32, ptr %l73, !tbaa !23
  store i32 %t130, ptr %l11, !tbaa !23
  %t131 = load i32, ptr %l11, !tbaa !23
  %t133 = icmp slt i32 %t131, 0
  br i1 %t133, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l76, !tbaa !21
  br label %bb38
bb36:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/check:Checker", ptr %t135, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !29
  %t139 = load i32, ptr %l11, !tbaa !23
  %t142 = call %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %t138, i32 %t139)
  store %"compiler/generic:Desc" %t142, ptr %l80
  br label %bb37
bb37:
  %t143 = getelementptr %"compiler/generic:Desc", ptr %l80, i32 0, i32 0
  %t144 = load i64, ptr %t143, !tbaa !24
  %t145 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescFunc, !tbaa !24
  %t148 = icmp ne i64 %t144, %t145
  store i1 %t148, ptr %l76, !tbaa !21
  br label %bb38
bb38:
  %t150 = load i1, ptr %l76, !tbaa !21
  br i1 %t150, label %bb39, label %bb40
bb39:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb40:
  br label %bb41
bb41:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/check:Checker", ptr %t152, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !29
  %t157 = getelementptr %"compiler/generic:Program", ptr %t155, i32 0, i32 2
  store ptr %t157, ptr %l87, !tbaa !29
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/check:Checker", ptr %t158, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !29
  %t163 = getelementptr %"compiler/generic:Program", ptr %t161, i32 0, i32 2
  store ptr %t163, ptr %l90, !tbaa !29
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/check:Checker", ptr %t164, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !29
  %t168 = load i32, ptr %l11, !tbaa !23
  %t171 = call %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %t167, i32 %t168)
  store %"compiler/generic:Desc" %t171, ptr %l94
  br label %bb42
bb42:
  %t172 = getelementptr %"compiler/generic:Desc", ptr %l94, i32 0, i32 1
  %t173 = load i32, ptr %t172, !tbaa !23
  %t174 = load ptr, ptr %l90, !tbaa !29
  %t176 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t174, i32 %t173)
  store i32 %t176, ptr %l96
  br label %bb43
bb43:
  %t177 = load ptr, ptr %l87, !tbaa !29
  %t178 = load i32, ptr %l96, !tbaa !23
  %t179 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t177, i32 %t178)
  store { i64, ptr } %t179, ptr %l97
  br label %bb44
bb44:
  %t180 = load { i64, ptr }, ptr %l97, !tbaa !27
  store { i64, ptr } %t180, ptr %l12, !tbaa !27
  %t181 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t183 = extractvalue { i64, ptr } %t181, 0
  %t185 = icmp eq i64 %t183, 0
  br i1 %t185, label %bb45, label %bb46
bb45:
  store i1 true, ptr %l101, !tbaa !21
  br label %bb48
bb46:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr %"compiler/check:Checker", ptr %t187, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !29
  %t191 = load i64, ptr %l2, !tbaa !24
  %t194 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t190, i64 %t191)
  store ptr %t194, ptr %l105
  br label %bb47
bb47:
  %t195 = load ptr, ptr %l105, !tbaa !29
  %t197 = getelementptr %"compiler/ast:Func", ptr %t195, i32 0, i32 1
  %t198 = load ptr, ptr %t197, !tbaa !29
  %t200 = icmp eq ptr %t198, null
  store i1 %t200, ptr %l101, !tbaa !21
  br label %bb48
bb48:
  %t202 = load i1, ptr %l101, !tbaa !21
  br i1 %t202, label %bb49, label %bb50
bb49:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb50:
  br label %bb51
bb51:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t205 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t205, ptr %l111, !tbaa !27
  %t206 = getelementptr { i64, ptr }, ptr %l111, i32 0, i32 1
  %t207 = load ptr, ptr %t206, !tbaa !27
  %t208 = getelementptr i32, ptr %t207, i64 0
  %t209 = load i32, ptr %t208, !tbaa !33
  %t212 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t204, i32 %t209)
  store i32 %t212, ptr %l113
  br label %bb52
bb52:
  %t213 = load i32, ptr %l113, !tbaa !23
  store i32 %t213, ptr %l13, !tbaa !23
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t215 = load i32, ptr %l13, !tbaa !23
  %t218 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t214, i32 %t215)
  store i1 %t218, ptr %l116
  br label %bb53
bb53:
  %t219 = load i1, ptr %l116, !tbaa !21
  %t220 = xor i1 %t219, true
  br i1 %t220, label %bb54, label %bb55
bb54:
  store i1 true, ptr %l118, !tbaa !21
  br label %bb59
bb55:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/check:Checker", ptr %t222, i32 0, i32 1
  %t225 = load ptr, ptr %t224, !tbaa !29
  %t227 = getelementptr %"compiler/generic:Program", ptr %t225, i32 0, i32 2
  store ptr %t227, ptr %l121, !tbaa !29
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t230 = getelementptr %"compiler/check:Checker", ptr %t228, i32 0, i32 1
  %t231 = load ptr, ptr %t230, !tbaa !29
  %t233 = getelementptr %"compiler/generic:Program", ptr %t231, i32 0, i32 2
  %t234 = load i32, ptr %l13, !tbaa !23
  %t237 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t233, i32 %t234)
  store i32 %t237, ptr %l126
  br label %bb56
bb56:
  %t238 = load ptr, ptr %l121, !tbaa !29
  %t239 = load i32, ptr %l126, !tbaa !23
  %t240 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t238, i32 %t239)
  store { i64, ptr } %t240, ptr %l127
  br label %bb57
bb57:
  %t241 = load { i64, ptr }, ptr %l127, !tbaa !27
  %t242 = extractvalue { i64, ptr } %t241, 0
  store i64 %t242, ptr %l128, !tbaa !24
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t245 = getelementptr %"compiler/check:Checker", ptr %t243, i32 0, i32 1
  %t246 = load ptr, ptr %t245, !tbaa !29
  %t247 = load i64, ptr %l3, !tbaa !24
  %t250 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t246, i64 %t247)
  store i64 %t250, ptr %l132
  br label %bb58
bb58:
  %t251 = load i64, ptr %l128, !tbaa !24
  %t252 = load i64, ptr %l132, !tbaa !24
  %t253 = icmp ne i64 %t251, %t252
  store i1 %t253, ptr %l118, !tbaa !21
  br label %bb59
bb59:
  %t255 = load i1, ptr %l118, !tbaa !21
  br i1 %t255, label %bb60, label %bb61
bb60:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb61:
  br label %bb62
bb62:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t259 = getelementptr %"compiler/check:Checker", ptr %t257, i32 0, i32 1
  %t260 = load ptr, ptr %t259, !tbaa !29
  store ptr %t260, ptr %l136, !tbaa !29
  %t261 = load i64, ptr %l2, !tbaa !24
  store i64 %t261, ptr %l137, !tbaa !24
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t264 = getelementptr %"compiler/check:Checker", ptr %t262, i32 0, i32 1
  %t265 = load ptr, ptr %t264, !tbaa !29
  %t267 = getelementptr %"compiler/generic:Program", ptr %t265, i32 0, i32 2
  %t268 = load i32, ptr %l13, !tbaa !23
  %t271 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t267, i32 %t268)
  store i32 %t271, ptr %l142
  br label %bb63
bb63:
  %t272 = load ptr, ptr %l136, !tbaa !29
  %t273 = load i64, ptr %l137, !tbaa !24
  %t274 = load i32, ptr %l142, !tbaa !23
  %t275 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %t272, i64 %t273, i32 %t274)
  store i64 %t275, ptr %l143
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s0)
  %t276 = load i64, ptr %l143, !tbaa !24
  store i64 %t276, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalDeps(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %lp3 = alloca ptr
  %l4 = alloca i64
  %l6 = alloca %"compiler/check:b5aWalk"
  %l11 = alloca i1
  %l12 = alloca i64
  %l14 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l21 = alloca i64
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %t2 = alloca %"compiler/check:b5aWalk", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2fcheck_3ab5aWalk_2ector(ptr %t2, ptr %v1, i64 %a1)
  call void @llvm.memmove.p0.p0.i64(ptr %l6, ptr %t2, i64 296, i1 false)
  br label %bb1
bb1:
  %t4 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 296, i64 8)
  store ptr %t4, ptr %lp3
  %t5 = load ptr, ptr %lp3
  call void @llvm.memmove.p0.p0.i64(ptr %t5, ptr %l6, i64 296, i1 false)
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load ptr, ptr %lp3
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aInit(ptr %v0, ptr %v1, ptr %t6, ptr %t7, i64 %a2)
  br label %bb2
bb2:
  store i64 0, ptr %l4, !tbaa !24
  br label %bb3
bb3:
  %t12 = load ptr, ptr %lp3
  %t13 = getelementptr %"compiler/check:b5aWalk", ptr %t12, i32 0, i32 7
  %t14 = load i1, ptr %t13, !tbaa !21
  br i1 %t14, label %bb4, label %bb5
bb4:
  %t16 = load i64, ptr %l4, !tbaa !24
  store i64 %t16, ptr %l12, !tbaa !24
  %t17 = load ptr, ptr %lp3
  %t18 = getelementptr %"compiler/check:b5aWalk", ptr %t17, i32 0, i32 2
  %t20 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t18)
  store i64 %t20, ptr %l14
  br label %bb6
bb5:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb7
bb6:
  %t21 = load i64, ptr %l12, !tbaa !24
  %t22 = load i64, ptr %l14, !tbaa !24
  %t23 = icmp slt i64 %t21, %t22
  store i1 %t23, ptr %l11, !tbaa !21
  br label %bb7
bb7:
  %t25 = load i1, ptr %l11, !tbaa !21
  %t26 = xor i1 %t25, true
  br i1 %t26, label %bb8, label %bb9
bb8:
  br label %bb14
bb9:
  br label %bb10
bb10:
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l17, !tbaa !29
  %t29 = load ptr, ptr %lp3
  store ptr %t29, ptr %l18, !tbaa !29
  %t30 = load ptr, ptr %lp3
  %t31 = getelementptr %"compiler/check:b5aWalk", ptr %t30, i32 0, i32 2
  %t32 = load i64, ptr %l4, !tbaa !24
  %t35 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t31, i64 %t32)
  store i64 %t35, ptr %l21
  br label %bb11
bb11:
  %t36 = load ptr, ptr %l17, !tbaa !29
  %t37 = load ptr, ptr %l18, !tbaa !29
  %t38 = load i64, ptr %l21, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aFn(ptr %v0, ptr %v1, ptr %t36, ptr %t37, i64 %t38)
  br label %bb12
bb12:
  %t39 = load i64, ptr %l4, !tbaa !24
  %t41 = add i64 %t39, 1
  store i64 %t41, ptr %l4, !tbaa !24
  br label %bb13
bb13:
  br label %bb3
bb14:
  %t43 = load ptr, ptr %lp3
  %t44 = getelementptr %"compiler/check:b5aWalk", ptr %t43, i32 0, i32 3
  %t45 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t44
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t45, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eheldArray(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca %"compiler/source:Span"
  %l18 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca i1
  %l29 = alloca i1
  %l43 = alloca { i64, ptr }
  %l47 = alloca i1
  %l48 = alloca i1
  %l50 = alloca i1
  %l58 = alloca i64
  %l62 = alloca i64
  %l65 = alloca i64
  %l86 = alloca ptr
  %l88 = alloca i1
  %l90 = alloca i1
  %l91 = alloca ptr
  %l93 = alloca %"compiler/source:Span"
  %l96 = alloca i32
  %l97 = alloca i64
  %l99 = alloca ptr
  %l101 = alloca %"compiler/source:Span"
  %l109 = alloca ptr
  %l110 = alloca i64
  %l111 = alloca ptr
  %l113 = alloca %"compiler/source:Span"
  %l115 = alloca ptr
  %l119 = alloca %"compiler/source:Span"
  %l120 = alloca ptr
  %l121 = alloca %"compiler/source:Span"
  %l124 = alloca i32
  %l125 = alloca i64
  %l138 = alloca ptr
  %rv = alloca ptr
  %t173 = alloca { i64, [3 x i64] }, align 8
  %t231 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l3, !tbaa !21
  %t1 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t2 = load ptr, ptr %l19, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l19, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 7
  store i1 %t8, ptr %l20, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l20, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l4, !tbaa !29
  br label %bb5
bb4:
  br label %bb26
bb5:
  %t16 = load ptr, ptr %l4, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Make", ptr %t16, i32 0, i32 0
  %t19 = load i32, ptr %t18, !range !{i32 0, i32 5}
  %t21 = trunc i64 2 to i32
  %t22 = icmp eq i32 %t19, %t21
  %t24 = xor i1 %t22, true
  br i1 %t24, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb8
bb7:
  %t26 = load ptr, ptr %l4, !tbaa !29
  %t28 = getelementptr %"compiler/typed:Make", ptr %t26, i32 0, i32 2
  %t29 = load { i64, ptr }, ptr %t28, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t29, 0
  %t33 = icmp eq i64 %t31, 0
  store i1 %t33, ptr %l29, !tbaa !21
  br label %bb8
bb8:
  %t35 = load i1, ptr %l29, !tbaa !21
  br i1 %t35, label %bb9, label %bb10
bb9:
  %t36 = load ptr, ptr %l2, !tbaa !29
  store ptr %t36, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t38 = load ptr, ptr %l4, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Make", ptr %t38, i32 0, i32 2
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  store { i64, ptr } %t41, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t43 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 0
  store i64 %t45, ptr %l7, !tbaa !24
  br label %bb12
bb12:
  %t47 = load i64, ptr %l6, !tbaa !24
  %t48 = load i64, ptr %l7, !tbaa !24
  %t51 = icmp slt i64 %t47, %t48
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb13, label %bb14
bb13:
  br label %bb25
bb14:
  br label %bb15
bb15:
  %t55 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t55, ptr %l43, !tbaa !27
  %t56 = load i64, ptr %l6, !tbaa !24
  %t58 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr ptr, ptr %t59, i64 %t56
  %t61 = load ptr, ptr %t60, !tbaa !39
  store ptr %t61, ptr %l8, !tbaa !29
  %t63 = load ptr, ptr %l8, !tbaa !29
  %t65 = call i1 @compiler_2fcheck_2epureRead(ptr %v1, ptr %t63)
  store i1 %t65, ptr %l47
  br label %bb16
bb16:
  %t66 = load i1, ptr %l47, !tbaa !21
  br i1 %t66, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb20
bb18:
  %t67 = load ptr, ptr %l8, !tbaa !29
  %t69 = call i1 @compiler_2fcheck_2eisLit(ptr %v1, ptr %t67)
  store i1 %t69, ptr %l50
  br label %bb19
bb19:
  %t70 = load i1, ptr %l50, !tbaa !21
  store i1 %t70, ptr %l48, !tbaa !21
  br label %bb20
bb20:
  %t71 = load i1, ptr %l48, !tbaa !21
  %t72 = xor i1 %t71, true
  br i1 %t72, label %bb21, label %bb22
bb21:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb23
bb22:
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t74 = load i64, ptr %l6, !tbaa !24
  %t76 = add i64 %t74, 1
  store i64 %t76, ptr %l6, !tbaa !24
  br label %bb12
bb25:
  br label %bb31
bb26:
  br i1 true, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  %t78 = load ptr, ptr %l2, !tbaa !29
  store ptr %t78, ptr %rv
  br label %ret
bb30:
  call void @__olang_check_failed(ptr @olang_loc_317381e6e3d2ca51_b8977c113f1a9cfd)
  unreachable
bb31:
  store i64 %a1, ptr %l9, !tbaa !24
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/check:Checker", ptr %t82, i32 0, i32 36
  %t86 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t84)
  store i64 %t86, ptr %l58
  br label %bb32
bb32:
  %t87 = load i64, ptr %l58, !tbaa !24
  store i64 %t87, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t88 = load i64, ptr %l10, !tbaa !24
  %t89 = load i64, ptr %l9, !tbaa !24
  %t92 = icmp sgt i64 %t88, %t89
  br i1 %t92, label %bb33, label %bb34
bb33:
  %t94 = load i64, ptr %l11, !tbaa !24
  %t96 = icmp sgt i64 %t94, 0
  br i1 %t96, label %bb35, label %bb36
bb34:
  store i64 0, ptr %l62, !tbaa !24
  br label %bb38
bb35:
  %t98 = load i64, ptr %l10, !tbaa !24
  %t99 = load i64, ptr %l9, !tbaa !24
  %t102 = sub i64 %t98, %t99
  %t103 = load i64, ptr %l11, !tbaa !24
  %t106 = add i64 %t102, %t103
  %t108 = sub i64 %t106, 1
  %t109 = load i64, ptr %l11, !tbaa !24
  %t112 = sdiv i64 %t108, %t109
  store i64 %t112, ptr %l65, !tbaa !24
  br label %bb37
bb36:
  store i64 0, ptr %l65, !tbaa !24
  br label %bb37
bb37:
  %t114 = load i64, ptr %l65, !tbaa !24
  store i64 %t114, ptr %l62, !tbaa !24
  br label %bb38
bb38:
  %t115 = load i64, ptr %l62, !tbaa !24
  store i64 %t115, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb39
bb39:
  %t116 = load i64, ptr %l13, !tbaa !24
  %t117 = load i64, ptr %l12, !tbaa !24
  %t120 = icmp slt i64 %t116, %t117
  %t122 = xor i1 %t120, true
  br i1 %t122, label %bb40, label %bb41
bb40:
  br label %bb60
bb41:
  br label %bb42
bb42:
  %t124 = load i64, ptr %l9, !tbaa !24
  %t125 = load i64, ptr %l13, !tbaa !24
  %t126 = load i64, ptr %l11, !tbaa !24
  %t129 = mul i64 %t125, %t126
  %t132 = add i64 %t124, %t129
  store i64 %t132, ptr %l14, !tbaa !24
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/check:Checker", ptr %t134, i32 0, i32 36
  %t137 = load i64, ptr %l14, !tbaa !24
  %t140 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t136, i64 %t137)
  store ptr %t140, ptr %l86
  br label %bb43
bb43:
  %t141 = load ptr, ptr %l86, !tbaa !29
  store ptr %t141, ptr %l15, !tbaa !29
  %t142 = load i1, ptr %l3, !tbaa !21
  br i1 %t142, label %bb44, label %bb45
bb44:
  store i1 true, ptr %l88, !tbaa !21
  br label %bb47
bb45:
  %t144 = load ptr, ptr %l15, !tbaa !29
  %t146 = call i1 @compiler_2fcheck_2eisLit(ptr %v0, ptr %t144)
  store i1 %t146, ptr %l90
  br label %bb46
bb46:
  %t147 = load i1, ptr %l90, !tbaa !21
  store i1 %t147, ptr %l88, !tbaa !21
  br label %bb47
bb47:
  %t148 = load i1, ptr %l88, !tbaa !21
  br i1 %t148, label %bb48, label %bb49
bb48:
  br label %bb59
bb49:
  br label %bb50
bb50:
  %t149 = load ptr, ptr %l0, !tbaa !29
  store ptr %t149, ptr %l91, !tbaa !29
  %t150 = load ptr, ptr %l15, !tbaa !29
  %t152 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %t150)
  store %"compiler/source:Span" %t152, ptr %l93
  br label %bb51
bb51:
  %t153 = load ptr, ptr %l15, !tbaa !29
  %t156 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t153)
  store i32 %t156, ptr %l96
  br label %bb52
bb52:
  %t157 = load ptr, ptr %l91, !tbaa !29
  %t158 = load %"compiler/source:Span", ptr %l93
  %t159 = load i32, ptr %l96, !tbaa !23
  %t160 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t157, %"compiler/source:Span" %t158, i32 %t159)
  store i64 %t160, ptr %l97
  br label %bb53
bb53:
  %t161 = load i64, ptr %l97, !tbaa !24
  store i64 %t161, ptr %l16, !tbaa !24
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr %"compiler/check:Checker", ptr %t162, i32 0, i32 37
  store ptr %t164, ptr %l99, !tbaa !29
  %t165 = load ptr, ptr %l15, !tbaa !29
  %t167 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %t165)
  store %"compiler/source:Span" %t167, ptr %l101
  br label %bb54
bb54:
  %t168 = load i64, ptr %l16, !tbaa !24
  %t170 = trunc i64 %t168 to i32
  %t172 = load ptr, ptr %l15, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t173
  %t174 = getelementptr { i64, [3 x i64] }, ptr %t173, i32 0, i32 0
  store i64 0, ptr %t174
  %t175 = load %"compiler/source:Span", ptr %l101
  %t176 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t175, 0
  %t178 = insertvalue { %"compiler/source:Span", i32, ptr } %t176, i32 %t170, 1
  %t180 = insertvalue { %"compiler/source:Span", i32, ptr } %t178, ptr %t172, 2
  %t181 = getelementptr { i64, [3 x i64] }, ptr %t173, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t180, ptr %t181
  %t182 = load { i64, [3 x i64] }, ptr %t173
  %t184 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t182, ptr %t184
  %t185 = load ptr, ptr %l99, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t185, ptr %t184)
  br label %bb55
bb55:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr %"compiler/check:Checker", ptr %t187, i32 0, i32 36
  store ptr %t189, ptr %l109, !tbaa !29
  %t190 = load i64, ptr %l14, !tbaa !24
  store i64 %t190, ptr %l110, !tbaa !24
  %t191 = load ptr, ptr %l0, !tbaa !29
  store ptr %t191, ptr %l111, !tbaa !29
  %t192 = load ptr, ptr %l15, !tbaa !29
  %t194 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %t192)
  store %"compiler/source:Span" %t194, ptr %l113
  br label %bb56
bb56:
  %t195 = load i64, ptr %l16, !tbaa !24
  %t196 = load ptr, ptr %l111, !tbaa !29
  %t197 = load %"compiler/source:Span", ptr %l113
  %t199 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t196, %"compiler/source:Span" %t197, i64 %t195)
  store ptr %t199, ptr %l115
  br label %bb57
bb57:
  %t200 = load ptr, ptr %l109, !tbaa !29
  %t201 = load i64, ptr %l110, !tbaa !24
  %t202 = load ptr, ptr %l115, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eSetAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t200, i64 %t201, ptr %t202)
  br label %bb58
bb58:
  br label %bb59
bb59:
  %t203 = load i64, ptr %l13, !tbaa !24
  %t205 = add i64 %t203, 1
  store i64 %t205, ptr %l13, !tbaa !24
  br label %bb39
bb60:
  %t207 = load ptr, ptr %l2, !tbaa !29
  %t209 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t207)
  store %"compiler/source:Span" %t209, ptr %l119
  br label %bb61
bb61:
  %t210 = load %"compiler/source:Span", ptr %l119
  store %"compiler/source:Span" %t210, ptr %l17
  %t211 = load ptr, ptr %l0, !tbaa !29
  store ptr %t211, ptr %l120, !tbaa !29
  %t212 = load %"compiler/source:Span", ptr %l17
  store %"compiler/source:Span" %t212, ptr %l121
  %t213 = load ptr, ptr %l2, !tbaa !29
  %t216 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t213)
  store i32 %t216, ptr %l124
  br label %bb62
bb62:
  %t217 = load ptr, ptr %l120, !tbaa !29
  %t218 = load %"compiler/source:Span", ptr %l121
  %t219 = load i32, ptr %l124, !tbaa !23
  %t220 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t217, %"compiler/source:Span" %t218, i32 %t219)
  store i64 %t220, ptr %l125
  br label %bb63
bb63:
  %t221 = load i64, ptr %l125, !tbaa !24
  store i64 %t221, ptr %l18, !tbaa !24
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/check:Checker", ptr %t222, i32 0, i32 37
  %t225 = load %"compiler/source:Span", ptr %l17
  %t226 = load i64, ptr %l18, !tbaa !24
  %t228 = trunc i64 %t226 to i32
  %t230 = load ptr, ptr %l2, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t231
  %t232 = getelementptr { i64, [3 x i64] }, ptr %t231, i32 0, i32 0
  store i64 0, ptr %t232
  %t234 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t225, 0
  %t236 = insertvalue { %"compiler/source:Span", i32, ptr } %t234, i32 %t228, 1
  %t238 = insertvalue { %"compiler/source:Span", i32, ptr } %t236, ptr %t230, 2
  %t239 = getelementptr { i64, [3 x i64] }, ptr %t231, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t238, ptr %t239
  %t240 = load { i64, [3 x i64] }, ptr %t231
  %t242 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t240, ptr %t242
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t224, ptr %t242)
  br label %bb64
bb64:
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t246 = load %"compiler/source:Span", ptr %l17
  %t247 = load i64, ptr %l18, !tbaa !24
  %t251 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v2, ptr %t245, %"compiler/source:Span" %t246, i64 %t247)
  store ptr %t251, ptr %l138
  br label %bb65
bb65:
  %t252 = load ptr, ptr %l138, !tbaa !29
  store ptr %t252, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2) #0 {
entry:
  %l8 = alloca i64
  %rv = alloca i64
  %t4 = alloca { i64, [2 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  store { i64, [2 x i64] } zeroinitializer, ptr %t4
  %t5 = getelementptr { i64, [2 x i64] }, ptr %t4, i32 0, i32 0
  store i64 0, ptr %t5
  %t6 = load { i64, [2 x i64] }, ptr %t4
  %t12 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %a0, i32 0, %"compiler/source:Span" %a1, i32 %a2, i32 3, { i64, [2 x i64] } %t6)
  store i64 %t12, ptr %l8
  br label %bb1
bb1:
  %t13 = load i64, ptr %l8, !tbaa !24
  store i64 %t13, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i1
  %l15 = alloca i1
  %l16 = alloca i64
  %l17 = alloca i64
  %l20 = alloca i64
  %l23 = alloca i1
  %l26 = alloca i32
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t18, i32 0, i32 2
  %t20 = load i64, ptr %t19
  store i64 %t20, ptr %l3, !tbaa !24
  br label %bb5
bb4:
  br label %bb17
bb5:
  %t22 = load i64, ptr %l3, !tbaa !24
  %t23 = load i64, ptr @G_2ecompiler_2fcheck_2eLaneMagic, !tbaa !24
  %t26 = icmp sge i64 %t22, %t23
  br i1 %t26, label %bb6, label %bb7
bb6:
  %t28 = load i64, ptr %l3, !tbaa !24
  store i64 %t28, ptr %l16, !tbaa !24
  %t29 = load i64, ptr @G_2ecompiler_2fcheck_2eLaneMagic, !tbaa !24
  store i64 %t29, ptr %l17, !tbaa !24
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/check:Checker", ptr %t30, i32 0, i32 39
  %t34 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eLen_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %t32)
  store i64 %t34, ptr %l20
  br label %bb8
bb7:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb9
bb8:
  %t35 = load i64, ptr %l17, !tbaa !24
  %t36 = load i64, ptr %l20, !tbaa !24
  %t37 = add i64 %t35, %t36
  %t38 = load i64, ptr %l16, !tbaa !24
  %t40 = icmp slt i64 %t38, %t37
  store i1 %t40, ptr %l15, !tbaa !21
  br label %bb9
bb9:
  %t42 = load i1, ptr %l15, !tbaa !21
  br i1 %t42, label %bb10, label %bb11
bb10:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load i32, ptr %l2, !tbaa !23
  %t47 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t43, i32 %t44)
  store i32 %t47, ptr %l26
  br label %bb12
bb11:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb13
bb12:
  %t48 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t49 = load i32, ptr %l26, !tbaa !23
  %t51 = icmp ne i32 %t49, %t48
  store i1 %t51, ptr %l23, !tbaa !21
  br label %bb13
bb13:
  %t53 = load i1, ptr %l23, !tbaa !21
  br i1 %t53, label %bb14, label %bb15
bb14:
  %t54 = load i64, ptr %l3, !tbaa !24
  %t55 = load i64, ptr @G_2ecompiler_2fcheck_2eLaneMagic, !tbaa !24
  %t58 = sub i64 %t54, %t55
  store i64 %t58, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  store i64 -1, ptr %rv
  br label %ret
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  store i64 -1, ptr %rv
  br label %ret
bb21:
  call void @__olang_check_failed(ptr @olang_loc_e09b0660792e8b62_512dd44834885876)
  unreachable
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elenMatch(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca i32
  %l22 = alloca i1
  %l26 = alloca ptr
  %l28 = alloca ptr
  %l30 = alloca ptr
  %l32 = alloca ptr
  %l34 = alloca i32
  %l35 = alloca i32
  %l40 = alloca i32
  %l51 = alloca i64
  %l54 = alloca i64
  %l73 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l93 = alloca i1
  %l97 = alloca ptr
  %l98 = alloca i1
  %l103 = alloca ptr
  %l104 = alloca i1
  %l113 = alloca ptr
  %l115 = alloca ptr
  %l117 = alloca ptr
  %l120 = alloca ptr
  %l122 = alloca i32
  %l123 = alloca i32
  %l128 = alloca i32
  %l135 = alloca i1
  %l140 = alloca i64
  %l145 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/ast:Match", ptr %t2, i32 0, i32 1
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t9 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadsConst(ptr %v0, ptr %v1, ptr %t1, ptr %t5)
  store i1 %t9, ptr %l22
  br label %bb1
bb1:
  %t10 = load i1, ptr %l22, !tbaa !21
  %t11 = xor i1 %t10, true
  br i1 %t11, label %bb2, label %bb3
bb2:
  store i64 -2, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  store ptr %t17, ptr %l26, !tbaa !29
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t18)
  store ptr %t20, ptr %l28
  br label %bb5
bb5:
  %t21 = load ptr, ptr %l28, !tbaa !29
  %t23 = getelementptr %"compiler/check:frame", ptr %t21, i32 0, i32 4
  store ptr %t23, ptr %l30, !tbaa !29
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr %"compiler/ast:Match", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  store ptr %t27, ptr %l32, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t28)
  store i32 %t30, ptr %l34
  br label %bb6
bb6:
  %t31 = load ptr, ptr %l26, !tbaa !29
  %t32 = load ptr, ptr %l30, !tbaa !29
  %t33 = load ptr, ptr %l32, !tbaa !29
  %t34 = load i32, ptr %l34, !tbaa !23
  %t35 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFoldKnown(ptr %v0, ptr %v0, ptr %v1, ptr %t31, ptr %t32, ptr %t33, i32 %t34)
  store i32 %t35, ptr %l35
  br label %bb7
bb7:
  %t36 = load i32, ptr %l35, !tbaa !23
  store i32 %t36, ptr %l2, !tbaa !23
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/check:Checker", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = getelementptr %"compiler/generic:Program", ptr %t40, i32 0, i32 2
  %t43 = load i32, ptr %l2, !tbaa !23
  %t46 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t42, i32 %t43)
  store i32 %t46, ptr %l40
  br label %bb8
bb8:
  %t47 = load i32, ptr %l40, !range !{i32 0, i32 33}
  %t49 = trunc i64 26 to i32
  %t50 = icmp eq i32 %t47, %t49
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb9, label %bb10
bb9:
  store i64 -2, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  store i64 -1, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t57 = getelementptr %"compiler/ast:Match", ptr %t55, i32 0, i32 3
  %t58 = load { i64, ptr }, ptr %t57, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t58, 0
  store i64 %t60, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t62 = load i64, ptr %l5, !tbaa !24
  %t63 = load i64, ptr %l4, !tbaa !24
  %t66 = icmp sgt i64 %t62, %t63
  br i1 %t66, label %bb12, label %bb13
bb12:
  %t68 = load i64, ptr %l6, !tbaa !24
  %t70 = icmp sgt i64 %t68, 0
  br i1 %t70, label %bb14, label %bb15
bb13:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb17
bb14:
  %t72 = load i64, ptr %l5, !tbaa !24
  %t73 = load i64, ptr %l4, !tbaa !24
  %t76 = sub i64 %t72, %t73
  %t77 = load i64, ptr %l6, !tbaa !24
  %t80 = add i64 %t76, %t77
  %t82 = sub i64 %t80, 1
  %t83 = load i64, ptr %l6, !tbaa !24
  %t86 = sdiv i64 %t82, %t83
  store i64 %t86, ptr %l54, !tbaa !24
  br label %bb16
bb15:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb16
bb16:
  %t88 = load i64, ptr %l54, !tbaa !24
  store i64 %t88, ptr %l51, !tbaa !24
  br label %bb17
bb17:
  %t89 = load i64, ptr %l51, !tbaa !24
  store i64 %t89, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb18
bb18:
  %t90 = load i64, ptr %l8, !tbaa !24
  %t91 = load i64, ptr %l7, !tbaa !24
  %t94 = icmp slt i64 %t90, %t91
  %t96 = xor i1 %t94, true
  br i1 %t96, label %bb19, label %bb20
bb19:
  br label %bb72
bb20:
  br label %bb21
bb21:
  %t98 = load i64, ptr %l4, !tbaa !24
  %t99 = load i64, ptr %l8, !tbaa !24
  %t100 = load i64, ptr %l6, !tbaa !24
  %t103 = mul i64 %t99, %t100
  %t106 = add i64 %t98, %t103
  store i64 %t106, ptr %l9, !tbaa !24
  %t108 = load ptr, ptr %l1, !tbaa !29
  %t110 = getelementptr %"compiler/ast:Match", ptr %t108, i32 0, i32 3
  %t111 = load { i64, ptr }, ptr %t110, !tbaa !27
  store { i64, ptr } %t111, ptr %l73, !tbaa !27
  %t112 = load i64, ptr %l9, !tbaa !24
  %t114 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr ptr, ptr %t115, i64 %t112
  %t117 = load ptr, ptr %t116, !tbaa !39
  store ptr %t117, ptr %l10, !tbaa !29
  %t119 = load ptr, ptr %l10, !tbaa !29
  %t121 = getelementptr %"compiler/ast:Case", ptr %t119, i32 0, i32 3
  %t122 = load ptr, ptr %t121, !tbaa !29
  %t124 = icmp eq ptr %t122, null
  %t126 = xor i1 %t124, true
  br i1 %t126, label %bb22, label %bb23
bb22:
  store i64 -2, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  %t129 = load ptr, ptr %l10, !tbaa !29
  %t131 = getelementptr %"compiler/ast:Case", ptr %t129, i32 0, i32 1
  %t132 = load { i64, ptr }, ptr %t131, !tbaa !27
  store { i64, ptr } %t132, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t134 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t134, 0
  store i64 %t136, ptr %l13, !tbaa !24
  br label %bb25
bb25:
  %t138 = load i64, ptr %l12, !tbaa !24
  %t139 = load i64, ptr %l13, !tbaa !24
  %t142 = icmp slt i64 %t138, %t139
  %t144 = xor i1 %t142, true
  br i1 %t144, label %bb26, label %bb27
bb26:
  br label %bb70
bb27:
  br label %bb28
bb28:
  %t146 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t146, ptr %l89, !tbaa !27
  %t147 = load i64, ptr %l12, !tbaa !24
  %t149 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !27
  %t151 = getelementptr ptr, ptr %t150, i64 %t147
  %t152 = load ptr, ptr %t151, !tbaa !39
  store ptr %t152, ptr %l14, !tbaa !29
  %t154 = load ptr, ptr %l14, !tbaa !29
  %t156 = call i1 @compiler_2fcheck_2eisWild(ptr %v1, ptr %t154)
  store i1 %t156, ptr %l93
  br label %bb29
bb29:
  %t157 = load i1, ptr %l93, !tbaa !21
  br i1 %t157, label %bb30, label %bb31
bb30:
  %t158 = load i64, ptr %l3, !tbaa !24
  %t160 = icmp slt i64 %t158, 0
  br i1 %t160, label %bb32, label %bb33
bb31:
  br label %bb35
bb32:
  %t162 = load i64, ptr %l9, !tbaa !24
  store i64 %t162, ptr %l3, !tbaa !24
  br label %bb34
bb33:
  br label %bb34
bb34:
  br label %bb69
bb35:
  store ptr null, ptr %l15, !tbaa !29
  %t164 = load ptr, ptr %l14, !tbaa !29
  store ptr %t164, ptr %l97, !tbaa !29
  store i1 false, ptr %l98, !tbaa !21
  %t165 = load ptr, ptr %l97, !tbaa !29
  %t166 = icmp ne ptr %t165, null
  br i1 %t166, label %bb36, label %bb37
bb36:
  %t168 = load ptr, ptr %l97, !tbaa !29
  %t169 = load i64, ptr %t168, !range !{i64 0, i64 8}
  %t171 = icmp eq i64 %t169, 4
  store i1 %t171, ptr %l98, !tbaa !21
  br label %bb37
bb37:
  %t172 = load i1, ptr %l98, !tbaa !21
  br i1 %t172, label %bb38, label %bb39
bb38:
  %t173 = load ptr, ptr %l14, !tbaa !29
  %t175 = getelementptr { i64, [4 x i64] }, ptr %t173, i32 0, i32 1
  %t176 = getelementptr { %"compiler/source:Span", ptr }, ptr %t175, i32 0, i32 1
  %t177 = load ptr, ptr %t176
  store ptr %t177, ptr %l16, !tbaa !29
  br label %bb44
bb39:
  %t179 = load ptr, ptr %l14, !tbaa !29
  store ptr %t179, ptr %l103, !tbaa !29
  store i1 false, ptr %l104, !tbaa !21
  %t180 = load ptr, ptr %l103, !tbaa !29
  %t181 = icmp ne ptr %t180, null
  br i1 %t181, label %bb40, label %bb41
bb40:
  %t183 = load ptr, ptr %l103, !tbaa !29
  %t184 = load i64, ptr %t183, !range !{i64 0, i64 8}
  %t186 = icmp eq i64 %t184, 1
  store i1 %t186, ptr %l104, !tbaa !21
  br label %bb41
bb41:
  %t187 = load i1, ptr %l104, !tbaa !21
  br i1 %t187, label %bb42, label %bb43
bb42:
  %t188 = load ptr, ptr %l14, !tbaa !29
  %t190 = getelementptr { i64, [4 x i64] }, ptr %t188, i32 0, i32 1
  %t191 = getelementptr { %"compiler/source:Span", ptr }, ptr %t190, i32 0, i32 1
  %t192 = load ptr, ptr %t191
  store ptr %t192, ptr %l16, !tbaa !29
  br label %bb44
bb43:
  br label %bb45
bb44:
  %t194 = load ptr, ptr %l16, !tbaa !29
  store ptr %t194, ptr %l15, !tbaa !29
  br label %bb50
bb45:
  br i1 true, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  store i64 -2, ptr %rv
  br label %ret
bb49:
  call void @__olang_check_failed(ptr @olang_loc_660a686bd581f793_38ac5a37531336d7)
  unreachable
bb50:
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t200 = getelementptr %"compiler/check:Checker", ptr %t198, i32 0, i32 1
  %t201 = load ptr, ptr %t200, !tbaa !29
  store ptr %t201, ptr %l113, !tbaa !29
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t204 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t202)
  store ptr %t204, ptr %l115
  br label %bb51
bb51:
  %t205 = load ptr, ptr %l115, !tbaa !29
  %t207 = getelementptr %"compiler/check:frame", ptr %t205, i32 0, i32 4
  store ptr %t207, ptr %l117, !tbaa !29
  %t208 = load ptr, ptr %l15, !tbaa !29
  %t210 = icmp eq ptr %t208, null
  br i1 %t210, label %bb52, label %bb53
bb52:
  call void @__olang_check_failed(ptr @olang_loc_21b1f67e4c6ce46b_15219dc677df2bef)
  unreachable
bb53:
  br label %bb54
bb54:
  %t212 = load ptr, ptr %l15, !tbaa !29
  store ptr %t212, ptr %l120, !tbaa !29
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t215 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t213)
  store i32 %t215, ptr %l122
  br label %bb55
bb55:
  %t216 = load ptr, ptr %l113, !tbaa !29
  %t217 = load ptr, ptr %l117, !tbaa !29
  %t218 = load ptr, ptr %l120, !tbaa !29
  %t219 = load i32, ptr %l122, !tbaa !23
  %t220 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFoldKnown(ptr %v0, ptr %v0, ptr %v1, ptr %t216, ptr %t217, ptr %t218, i32 %t219)
  store i32 %t220, ptr %l123
  br label %bb56
bb56:
  %t221 = load i32, ptr %l123, !tbaa !23
  store i32 %t221, ptr %l17, !tbaa !23
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/check:Checker", ptr %t222, i32 0, i32 1
  %t225 = load ptr, ptr %t224, !tbaa !29
  %t227 = getelementptr %"compiler/generic:Program", ptr %t225, i32 0, i32 2
  %t228 = load i32, ptr %l17, !tbaa !23
  %t231 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t227, i32 %t228)
  store i32 %t231, ptr %l128
  br label %bb57
bb57:
  %t232 = load i32, ptr %l128, !range !{i32 0, i32 33}
  %t234 = trunc i64 26 to i32
  %t235 = icmp eq i32 %t232, %t234
  %t237 = xor i1 %t235, true
  br i1 %t237, label %bb58, label %bb59
bb58:
  store i64 -2, ptr %rv
  br label %ret
bb59:
  br label %bb60
bb60:
  %t240 = load i64, ptr %l3, !tbaa !24
  %t242 = icmp slt i64 %t240, 0
  br i1 %t242, label %bb61, label %bb62
bb61:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t246 = getelementptr %"compiler/check:Checker", ptr %t244, i32 0, i32 1
  %t247 = load ptr, ptr %t246, !tbaa !29
  %t249 = getelementptr %"compiler/generic:Program", ptr %t247, i32 0, i32 2
  %t250 = load i32, ptr %l17, !tbaa !23
  %t253 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t249, i32 %t250)
  store i64 %t253, ptr %l140
  br label %bb63
bb62:
  store i1 false, ptr %l135, !tbaa !21
  br label %bb65
bb63:
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t256 = getelementptr %"compiler/check:Checker", ptr %t254, i32 0, i32 1
  %t257 = load ptr, ptr %t256, !tbaa !29
  %t259 = getelementptr %"compiler/generic:Program", ptr %t257, i32 0, i32 2
  %t260 = load i32, ptr %l2, !tbaa !23
  %t263 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t259, i32 %t260)
  store i64 %t263, ptr %l145
  br label %bb64
bb64:
  %t264 = load i64, ptr %l140, !tbaa !24
  %t265 = load i64, ptr %l145, !tbaa !24
  %t266 = icmp eq i64 %t264, %t265
  store i1 %t266, ptr %l135, !tbaa !21
  br label %bb65
bb65:
  %t268 = load i1, ptr %l135, !tbaa !21
  br i1 %t268, label %bb66, label %bb67
bb66:
  %t269 = load i64, ptr %l9, !tbaa !24
  store i64 %t269, ptr %l3, !tbaa !24
  br label %bb68
bb67:
  br label %bb68
bb68:
  br label %bb69
bb69:
  %t271 = load i64, ptr %l12, !tbaa !24
  %t273 = add i64 %t271, 1
  store i64 %t273, ptr %l12, !tbaa !24
  br label %bb25
bb70:
  br label %bb71
bb71:
  %t275 = load i64, ptr %l8, !tbaa !24
  %t277 = add i64 %t275, 1
  store i64 %t277, ptr %l8, !tbaa !24
  br label %bb18
bb72:
  %t279 = load i64, ptr %l3, !tbaa !24
  store i64 %t279, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/check:reflList" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca %"compiler/generic:Desc"
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i1
  %l20 = alloca { i64, ptr }
  %l21 = alloca i1
  %l24 = alloca i64
  %l27 = alloca i1
  %l31 = alloca i1
  %l36 = alloca %"compiler/check:reflList"
  %l37 = alloca %"compiler/check:reflList"
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l44 = alloca %"compiler/check:reflList"
  %l47 = alloca i32
  %l53 = alloca %"compiler/generic:Desc"
  %l57 = alloca i1
  %l64 = alloca %"compiler/check:reflList"
  %l68 = alloca i1
  %l74 = alloca %"compiler/check:reflList"
  %l78 = alloca i1
  %l84 = alloca %"compiler/check:reflList"
  %l85 = alloca %"compiler/check:reflList"
  %l88 = alloca i32
  %l91 = alloca %"compiler/check:reflList"
  %l94 = alloca i1
  %l95 = alloca i1
  %l98 = alloca i1
  %l100 = alloca i1
  %l104 = alloca i1
  %l105 = alloca %"compiler/check:reflList"
  %l108 = alloca %"compiler/check:reflList"
  %l109 = alloca ptr
  %l110 = alloca i1
  %l117 = alloca %"compiler/check:reflList"
  %l118 = alloca %"compiler/check:reflList"
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca %"compiler/check:reflList"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t2 = load ptr, ptr %l10, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l10, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 14
  store i1 %t8, ptr %l11, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l11, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t18, i32 0, i32 2
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb73
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i32, ptr %l3, !tbaa !23
  %t26 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t22, i32 %t23)
  store { i64, ptr } %t26, ptr %l20
  br label %bb6
bb6:
  %t27 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t28 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t27, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d9, i32 0, i32 1) })
  store i1 %t28, ptr %l21
  br label %bb7
bb7:
  %t29 = load i1, ptr %l21, !tbaa !21
  br i1 %t29, label %bb8, label %bb9
bb8:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t34 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ealiasModule(ptr %v0, ptr %v1, ptr %t30, ptr %t31)
  store i64 %t34, ptr %l24
  br label %bb10
bb9:
  br label %bb20
bb10:
  %t35 = load i64, ptr %l24, !tbaa !24
  store i64 %t35, ptr %l4, !tbaa !24
  %t36 = load i64, ptr %l4, !tbaa !24
  %t38 = icmp sge i64 %t36, 0
  br i1 %t38, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i64, ptr %l4, !tbaa !24
  %t42 = load i32, ptr %l3, !tbaa !23
  %t46 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclaresName(ptr %v0, ptr %t40, i64 %t41, i32 %t42)
  store i1 %t46, ptr %l31
  br label %bb13
bb12:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb14
bb13:
  %t47 = load i1, ptr %l31, !tbaa !21
  %t48 = xor i1 %t47, true
  store i1 %t48, ptr %l27, !tbaa !21
  br label %bb14
bb14:
  %t50 = load i1, ptr %l27, !tbaa !21
  br i1 %t50, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t51 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t52 = load i64, ptr @G_2ecompiler_2fgeneric_2eListFunctions, !tbaa !24
  %t53 = load i64, ptr %l4, !tbaa !24
  %t57 = call %"compiler/check:reflList" @compiler_2fcheck_3areflList_2ector(ptr %s3, i1 true, i32 %t51, i64 %t52, i64 %t53)
  store %"compiler/check:reflList" %t57, ptr %l36
  br label %bb17
bb16:
  br label %bb18
bb17:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s1)
  %t58 = load %"compiler/check:reflList", ptr %l36
  store %"compiler/check:reflList" %t58, ptr %rv
  br label %ret
bb18:
  %t59 = call %"compiler/check:reflList" @compiler_2fcheck_2enoList()
  store %"compiler/check:reflList" %t59, ptr %l37
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s1)
  %t60 = load %"compiler/check:reflList", ptr %l37
  store %"compiler/check:reflList" %t60, ptr %rv
  br label %ret
bb20:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load i32, ptr %l3, !tbaa !23
  %t65 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t61, i32 %t62)
  store { i64, ptr } %t65, ptr %l40
  br label %bb21
bb21:
  %t66 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t67 = call i64 @compiler_2fcheck_2elistIndex(ptr %v0, { i64, ptr } %t66)
  store i64 %t67, ptr %l41
  br label %bb22
bb22:
  %t68 = load i64, ptr %l41, !tbaa !24
  store i64 %t68, ptr %l5, !tbaa !24
  %t69 = load i64, ptr %l5, !tbaa !24
  %t71 = icmp slt i64 %t69, 0
  br i1 %t71, label %bb23, label %bb24
bb23:
  %t73 = call %"compiler/check:reflList" @compiler_2fcheck_2enoList()
  store %"compiler/check:reflList" %t73, ptr %l44
  br label %bb25
bb24:
  br label %bb26
bb25:
  call void @__olang_scope_close(ptr %s1)
  %t74 = load %"compiler/check:reflList", ptr %l44
  store %"compiler/check:reflList" %t74, ptr %rv
  br label %ret
bb26:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load ptr, ptr %l2, !tbaa !29
  %t79 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescTypeOf(ptr %v0, ptr %v1, ptr %t75, ptr %t76)
  store i32 %t79, ptr %l47
  br label %bb27
bb27:
  %t80 = load i32, ptr %l47, !tbaa !23
  store i32 %t80, ptr %l6, !tbaa !23
  %t81 = load i32, ptr %l6, !tbaa !23
  %t83 = icmp sge i32 %t81, 0
  br i1 %t83, label %bb28, label %bb29
bb28:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/check:Checker", ptr %t85, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t89 = load i32, ptr %l6, !tbaa !23
  %t92 = call %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %t88, i32 %t89)
  store %"compiler/generic:Desc" %t92, ptr %l53
  br label %bb30
bb29:
  br label %bb53
bb30:
  %t93 = load %"compiler/generic:Desc", ptr %l53
  store %"compiler/generic:Desc" %t93, ptr %l7
  %t94 = getelementptr %"compiler/generic:Desc", ptr %l7, i32 0, i32 0
  %t95 = load i64, ptr %t94, !tbaa !24
  %t96 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescCase, !tbaa !24
  %t99 = icmp eq i64 %t95, %t96
  br i1 %t99, label %bb31, label %bb32
bb31:
  %t101 = load i64, ptr %l5, !tbaa !24
  %t102 = load i64, ptr @G_2ecompiler_2fgeneric_2eListFields, !tbaa !24
  %t105 = icmp eq i64 %t101, %t102
  store i1 %t105, ptr %l57, !tbaa !21
  br label %bb33
bb32:
  store i1 false, ptr %l57, !tbaa !21
  br label %bb33
bb33:
  %t107 = load i1, ptr %l57, !tbaa !21
  br i1 %t107, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s6
  %t108 = getelementptr %"compiler/generic:Desc", ptr %l7, i32 0, i32 1
  %t109 = load i32, ptr %t108, !tbaa !23
  %t110 = load i64, ptr %l5, !tbaa !24
  %t111 = getelementptr %"compiler/generic:Desc", ptr %l7, i32 0, i32 2
  %t112 = load i64, ptr %t111, !tbaa !24
  %t116 = call %"compiler/check:reflList" @compiler_2fcheck_3areflList_2ector(ptr %s6, i1 true, i32 %t109, i64 %t110, i64 %t112)
  store %"compiler/check:reflList" %t116, ptr %l64
  br label %bb36
bb35:
  br label %bb37
bb36:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s1)
  %t117 = load %"compiler/check:reflList", ptr %l64
  store %"compiler/check:reflList" %t117, ptr %rv
  br label %ret
bb37:
  %t118 = getelementptr %"compiler/generic:Desc", ptr %l7, i32 0, i32 0
  %t119 = load i64, ptr %t118, !tbaa !24
  %t120 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescFunc, !tbaa !24
  %t123 = icmp eq i64 %t119, %t120
  br i1 %t123, label %bb38, label %bb39
bb38:
  %t125 = load i64, ptr %l5, !tbaa !24
  %t126 = load i64, ptr @G_2ecompiler_2fgeneric_2eListParams, !tbaa !24
  %t129 = icmp eq i64 %t125, %t126
  store i1 %t129, ptr %l68, !tbaa !21
  br label %bb40
bb39:
  store i1 false, ptr %l68, !tbaa !21
  br label %bb40
bb40:
  %t131 = load i1, ptr %l68, !tbaa !21
  br i1 %t131, label %bb41, label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s7
  %t132 = load i32, ptr %l6, !tbaa !23
  %t133 = load i64, ptr %l5, !tbaa !24
  %t136 = call %"compiler/check:reflList" @compiler_2fcheck_3areflList_2ector(ptr %s7, i1 true, i32 %t132, i64 %t133, i64 -1)
  store %"compiler/check:reflList" %t136, ptr %l74
  br label %bb43
bb42:
  br label %bb44
bb43:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s1)
  %t137 = load %"compiler/check:reflList", ptr %l74
  store %"compiler/check:reflList" %t137, ptr %rv
  br label %ret
bb44:
  %t138 = getelementptr %"compiler/generic:Desc", ptr %l7, i32 0, i32 0
  %t139 = load i64, ptr %t138, !tbaa !24
  %t140 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescFunc, !tbaa !24
  %t143 = icmp eq i64 %t139, %t140
  br i1 %t143, label %bb45, label %bb46
bb45:
  %t145 = load i64, ptr %l5, !tbaa !24
  %t146 = load i64, ptr @G_2ecompiler_2fgeneric_2eListResults, !tbaa !24
  %t149 = icmp eq i64 %t145, %t146
  store i1 %t149, ptr %l78, !tbaa !21
  br label %bb47
bb46:
  store i1 false, ptr %l78, !tbaa !21
  br label %bb47
bb47:
  %t151 = load i1, ptr %l78, !tbaa !21
  br i1 %t151, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s8
  %t152 = getelementptr %"compiler/generic:Desc", ptr %l7, i32 0, i32 1
  %t153 = load i32, ptr %t152, !tbaa !23
  %t154 = load i64, ptr %l5, !tbaa !24
  %t157 = call %"compiler/check:reflList" @compiler_2fcheck_3areflList_2ector(ptr %s8, i1 true, i32 %t153, i64 %t154, i64 -1)
  store %"compiler/check:reflList" %t157, ptr %l84
  br label %bb50
bb49:
  br label %bb51
bb50:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s1)
  %t158 = load %"compiler/check:reflList", ptr %l84
  store %"compiler/check:reflList" %t158, ptr %rv
  br label %ret
bb51:
  %t159 = call %"compiler/check:reflList" @compiler_2fcheck_2enoList()
  store %"compiler/check:reflList" %t159, ptr %l85
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s1)
  %t160 = load %"compiler/check:reflList", ptr %l85
  store %"compiler/check:reflList" %t160, ptr %rv
  br label %ret
bb53:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load ptr, ptr %l2, !tbaa !29
  %t165 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflType(ptr %v0, ptr %v1, ptr %t161, ptr %t162)
  store i32 %t165, ptr %l88
  br label %bb54
bb54:
  %t166 = load i32, ptr %l88, !tbaa !23
  store i32 %t166, ptr %l8, !tbaa !23
  %t167 = load i32, ptr %l8, !tbaa !23
  %t169 = icmp slt i32 %t167, 0
  br i1 %t169, label %bb55, label %bb56
bb55:
  %t171 = call %"compiler/check:reflList" @compiler_2fcheck_2enoList()
  store %"compiler/check:reflList" %t171, ptr %l91
  br label %bb57
bb56:
  br label %bb58
bb57:
  call void @__olang_scope_close(ptr %s1)
  %t172 = load %"compiler/check:reflList", ptr %l91
  store %"compiler/check:reflList" %t172, ptr %rv
  br label %ret
bb58:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load i32, ptr %l8, !tbaa !23
  %t177 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t173, i32 %t174)
  store i1 %t177, ptr %l94
  br label %bb59
bb59:
  %t178 = load i1, ptr %l94, !tbaa !21
  br i1 %t178, label %bb60, label %bb61
bb60:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = load ptr, ptr %l2, !tbaa !29
  %t183 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eviaTypeVar(ptr %v0, ptr %v1, ptr %t179, ptr %t180)
  store i1 %t183, ptr %l98
  br label %bb62
bb61:
  store i1 false, ptr %l95, !tbaa !21
  br label %bb63
bb62:
  %t184 = load i1, ptr %l98, !tbaa !21
  %t185 = xor i1 %t184, true
  store i1 %t185, ptr %l95, !tbaa !21
  br label %bb63
bb63:
  %t187 = load i1, ptr %l95, !tbaa !21
  br i1 %t187, label %bb64, label %bb65
bb64:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t189 = load i32, ptr %l8, !tbaa !23
  %t190 = load i32, ptr %l3, !tbaa !23
  %t194 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehasCase(ptr %v0, ptr %t188, i32 %t189, i32 %t190)
  store i1 %t194, ptr %l104
  br label %bb66
bb65:
  store i1 false, ptr %l100, !tbaa !21
  br label %bb67
bb66:
  %t195 = load i1, ptr %l104, !tbaa !21
  store i1 %t195, ptr %l100, !tbaa !21
  br label %bb67
bb67:
  %t196 = load i1, ptr %l100, !tbaa !21
  br i1 %t196, label %bb68, label %bb69
bb68:
  %t197 = call %"compiler/check:reflList" @compiler_2fcheck_2enoList()
  store %"compiler/check:reflList" %t197, ptr %l105
  br label %bb70
bb69:
  br label %bb71
bb70:
  call void @__olang_scope_close(ptr %s1)
  %t198 = load %"compiler/check:reflList", ptr %l105
  store %"compiler/check:reflList" %t198, ptr %rv
  br label %ret
bb71:
  %t199 = load i32, ptr %l8, !tbaa !23
  %t200 = load i64, ptr %l5, !tbaa !24
  %t203 = call %"compiler/check:reflList" @compiler_2fcheck_3areflList_2ector(ptr %s1, i1 true, i32 %t199, i64 %t200, i64 -1)
  store %"compiler/check:reflList" %t203, ptr %l108
  br label %bb72
bb72:
  call void @__olang_scope_close(ptr %s1)
  %t204 = load %"compiler/check:reflList", ptr %l108
  store %"compiler/check:reflList" %t204, ptr %rv
  br label %ret
bb73:
  %t205 = load ptr, ptr %l1, !tbaa !29
  store ptr %t205, ptr %l109, !tbaa !29
  store i1 false, ptr %l110, !tbaa !21
  %t206 = load ptr, ptr %l109, !tbaa !29
  %t207 = icmp ne ptr %t206, null
  br i1 %t207, label %bb74, label %bb75
bb74:
  %t209 = load ptr, ptr %l109, !tbaa !29
  %t210 = load i64, ptr %t209, !range !{i64 0, i64 30}
  %t212 = icmp eq i64 %t210, 2
  store i1 %t212, ptr %l110, !tbaa !21
  br label %bb75
bb75:
  %t213 = load i1, ptr %l110, !tbaa !21
  br i1 %t213, label %bb76, label %bb77
bb76:
  %t214 = load ptr, ptr %l1, !tbaa !29
  %t216 = getelementptr { i64, [4 x i64] }, ptr %t214, i32 0, i32 1
  %t217 = getelementptr { %"compiler/source:Span", ptr }, ptr %t216, i32 0, i32 1
  %t218 = load ptr, ptr %t217
  store ptr %t218, ptr %l9, !tbaa !29
  br label %bb78
bb77:
  br label %bb80
bb78:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load ptr, ptr %l9, !tbaa !29
  %t224 = call %"compiler/check:reflList" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistOf(ptr %v0, ptr %v1, ptr %t220, ptr %t221)
  store %"compiler/check:reflList" %t224, ptr %l117
  br label %bb79
bb79:
  %t225 = load %"compiler/check:reflList", ptr %l117
  store %"compiler/check:reflList" %t225, ptr %rv
  br label %ret
bb80:
  br i1 true, label %bb81, label %bb82
bb81:
  br label %bb83
bb82:
  br label %bb85
bb83:
  %t226 = call %"compiler/check:reflList" @compiler_2fcheck_2enoList()
  store %"compiler/check:reflList" %t226, ptr %l118
  br label %bb84
bb84:
  %t227 = load %"compiler/check:reflList", ptr %l118
  store %"compiler/check:reflList" %t227, ptr %rv
  br label %ret
bb85:
  call void @__olang_check_failed(ptr @olang_loc_7b7c458ad09559c8_7a5ff3a2c3d540e4)
  unreachable
ret:
  %rr = load %"compiler/check:reflList", ptr %rv
  ret %"compiler/check:reflList" %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitArray(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l24 = alloca i32
  %l26 = alloca ptr
  %l27 = alloca i1
  %l34 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca i1
  %l45 = alloca i1
  %l46 = alloca i1
  %l49 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca i1
  %l64 = alloca { i64, ptr }
  %l70 = alloca i1
  %l71 = alloca ptr
  %l77 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t2 = load ptr, ptr %l11, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l11, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 17
  store i1 %t8, ptr %l12, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l12, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %rv
  br label %ret
bb6:
  %t11 = load ptr, ptr %l1, !tbaa !29
  store ptr %t11, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t12 = load ptr, ptr %l16, !tbaa !29
  %t13 = icmp ne ptr %t12, null
  br i1 %t13, label %bb7, label %bb8
bb7:
  %t15 = load ptr, ptr %l16, !tbaa !29
  %t16 = load i64, ptr %t15, !range !{i64 0, i64 30}
  %t18 = icmp eq i64 %t16, 15
  store i1 %t18, ptr %l17, !tbaa !21
  br label %bb8
bb8:
  %t19 = load i1, ptr %l17, !tbaa !21
  br i1 %t19, label %bb9, label %bb10
bb9:
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr { i64, [4 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t22, i32 0, i32 1
  %t24 = load ptr, ptr %t23
  store ptr %t24, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t30 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %t26, ptr %t27)
  store i32 %t30, ptr %l24
  br label %bb12
bb12:
  %t31 = load i32, ptr %l24, !tbaa !23
  %t32 = icmp sge i32 %t31, 0
  store i1 %t32, ptr %rv
  br label %ret
bb13:
  %t34 = load ptr, ptr %l1, !tbaa !29
  store ptr %t34, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t35 = load ptr, ptr %l26, !tbaa !29
  %t36 = icmp ne ptr %t35, null
  br i1 %t36, label %bb14, label %bb15
bb14:
  %t38 = load ptr, ptr %l26, !tbaa !29
  %t39 = load i64, ptr %t38, !range !{i64 0, i64 30}
  %t41 = icmp eq i64 %t39, 2
  store i1 %t41, ptr %l27, !tbaa !21
  br label %bb15
bb15:
  %t42 = load i1, ptr %l27, !tbaa !21
  br i1 %t42, label %bb16, label %bb17
bb16:
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = getelementptr { i64, [4 x i64] }, ptr %t43, i32 0, i32 1
  %t46 = getelementptr { %"compiler/source:Span", ptr }, ptr %t45, i32 0, i32 1
  %t47 = load ptr, ptr %t46
  store ptr %t47, ptr %l3, !tbaa !29
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load ptr, ptr %l3, !tbaa !29
  %t53 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitArray(ptr %v0, ptr %v1, ptr %t49, ptr %t50)
  store i1 %t53, ptr %l34
  br label %bb19
bb19:
  %t54 = load i1, ptr %l34, !tbaa !21
  store i1 %t54, ptr %rv
  br label %ret
bb20:
  %t55 = load ptr, ptr %l1, !tbaa !29
  store ptr %t55, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t56 = load ptr, ptr %l35, !tbaa !29
  %t57 = icmp ne ptr %t56, null
  br i1 %t57, label %bb21, label %bb22
bb21:
  %t59 = load ptr, ptr %l35, !tbaa !29
  %t60 = load i64, ptr %t59, !range !{i64 0, i64 30}
  %t62 = icmp eq i64 %t60, 8
  store i1 %t62, ptr %l36, !tbaa !21
  br label %bb22
bb22:
  %t63 = load i1, ptr %l36, !tbaa !21
  br i1 %t63, label %bb23, label %bb24
bb23:
  %t64 = load ptr, ptr %l1, !tbaa !29
  %t66 = getelementptr { i64, [4 x i64] }, ptr %t64, i32 0, i32 1
  %t67 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t66, i32 0, i32 1
  %t68 = load ptr, ptr %t67
  store ptr %t68, ptr %l4, !tbaa !29
  %t70 = load ptr, ptr %l1, !tbaa !29
  %t72 = getelementptr { i64, [4 x i64] }, ptr %t70, i32 0, i32 1
  %t73 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t72, i32 0, i32 3
  %t74 = load ptr, ptr %t73
  store ptr %t74, ptr %l5, !tbaa !29
  br label %bb25
bb24:
  br label %bb31
bb25:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load ptr, ptr %l4, !tbaa !29
  %t80 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitArray(ptr %v0, ptr %v1, ptr %t76, ptr %t77)
  store i1 %t80, ptr %l45
  br label %bb26
bb26:
  %t81 = load i1, ptr %l45, !tbaa !21
  br i1 %t81, label %bb27, label %bb28
bb27:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load ptr, ptr %l5, !tbaa !29
  %t86 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitArray(ptr %v0, ptr %v1, ptr %t82, ptr %t83)
  store i1 %t86, ptr %l49
  br label %bb29
bb28:
  store i1 false, ptr %l46, !tbaa !21
  br label %bb30
bb29:
  %t87 = load i1, ptr %l49, !tbaa !21
  store i1 %t87, ptr %l46, !tbaa !21
  br label %bb30
bb30:
  %t88 = load i1, ptr %l46, !tbaa !21
  store i1 %t88, ptr %rv
  br label %ret
bb31:
  %t89 = load ptr, ptr %l1, !tbaa !29
  store ptr %t89, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t90 = load ptr, ptr %l50, !tbaa !29
  %t91 = icmp ne ptr %t90, null
  br i1 %t91, label %bb32, label %bb33
bb32:
  %t93 = load ptr, ptr %l50, !tbaa !29
  %t94 = load i64, ptr %t93, !range !{i64 0, i64 30}
  %t96 = icmp eq i64 %t94, 23
  store i1 %t96, ptr %l51, !tbaa !21
  br label %bb33
bb33:
  %t97 = load i1, ptr %l51, !tbaa !21
  br i1 %t97, label %bb34, label %bb35
bb34:
  %t98 = load ptr, ptr %l1, !tbaa !29
  %t100 = getelementptr { i64, [4 x i64] }, ptr %t98, i32 0, i32 1
  %t101 = getelementptr { %"compiler/source:Span", ptr }, ptr %t100, i32 0, i32 1
  %t102 = load ptr, ptr %t101
  store ptr %t102, ptr %l6, !tbaa !29
  br label %bb36
bb35:
  br label %bb53
bb36:
  %t104 = load ptr, ptr %l6, !tbaa !29
  %t106 = getelementptr %"compiler/ast:Match", ptr %t104, i32 0, i32 3
  %t107 = load { i64, ptr }, ptr %t106, !tbaa !27
  store { i64, ptr } %t107, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t109 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t111 = extractvalue { i64, ptr } %t109, 0
  store i64 %t111, ptr %l9, !tbaa !24
  br label %bb37
bb37:
  %t113 = load i64, ptr %l8, !tbaa !24
  %t114 = load i64, ptr %l9, !tbaa !24
  %t117 = icmp slt i64 %t113, %t114
  %t119 = xor i1 %t117, true
  br i1 %t119, label %bb38, label %bb39
bb38:
  br label %bb52
bb39:
  br label %bb40
bb40:
  %t121 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t121, ptr %l64, !tbaa !27
  %t122 = load i64, ptr %l8, !tbaa !24
  %t124 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr ptr, ptr %t125, i64 %t122
  %t127 = load ptr, ptr %t126, !tbaa !39
  store ptr %t127, ptr %l10, !tbaa !29
  %t129 = load ptr, ptr %l10, !tbaa !29
  %t131 = getelementptr %"compiler/ast:Case", ptr %t129, i32 0, i32 5
  %t132 = load ptr, ptr %t131, !tbaa !29
  %t134 = icmp eq ptr %t132, null
  br i1 %t134, label %bb41, label %bb42
bb41:
  store i1 true, ptr %l70, !tbaa !21
  br label %bb47
bb42:
  %t136 = load ptr, ptr %l0, !tbaa !29
  store ptr %t136, ptr %l71, !tbaa !29
  %t137 = load ptr, ptr %l10, !tbaa !29
  %t139 = getelementptr %"compiler/ast:Case", ptr %t137, i32 0, i32 5
  %t140 = load ptr, ptr %t139, !tbaa !29
  %t142 = icmp eq ptr %t140, null
  br i1 %t142, label %bb43, label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_ddeebe9155436d6a_19ee353760b572b6)
  unreachable
bb44:
  br label %bb45
bb45:
  %t144 = load ptr, ptr %l10, !tbaa !29
  %t146 = getelementptr %"compiler/ast:Case", ptr %t144, i32 0, i32 5
  %t147 = load ptr, ptr %t146, !tbaa !29
  %t148 = load ptr, ptr %l71, !tbaa !29
  %t150 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitArray(ptr %v0, ptr %v1, ptr %t148, ptr %t147)
  store i1 %t150, ptr %l77
  br label %bb46
bb46:
  %t151 = load i1, ptr %l77, !tbaa !21
  %t152 = xor i1 %t151, true
  store i1 %t152, ptr %l70, !tbaa !21
  br label %bb47
bb47:
  %t154 = load i1, ptr %l70, !tbaa !21
  br i1 %t154, label %bb48, label %bb49
bb48:
  store i1 false, ptr %rv
  br label %ret
bb49:
  br label %bb50
bb50:
  br label %bb51
bb51:
  %t156 = load i64, ptr %l8, !tbaa !24
  %t158 = add i64 %t156, 1
  store i64 %t158, ptr %l8, !tbaa !24
  br label %bb37
bb52:
  %t160 = load ptr, ptr %l6, !tbaa !29
  %t162 = getelementptr %"compiler/ast:Match", ptr %t160, i32 0, i32 3
  %t163 = load { i64, ptr }, ptr %t162, !tbaa !27
  %t165 = extractvalue { i64, ptr } %t163, 0
  %t167 = icmp sgt i64 %t165, 0
  store i1 %t167, ptr %rv
  br label %ret
bb53:
  br i1 true, label %bb54, label %bb55
bb54:
  br label %bb56
bb55:
  br label %bb57
bb56:
  store i1 false, ptr %rv
  br label %ret
bb57:
  call void @__olang_check_failed(ptr @olang_loc_7406e676cee1d8f8_b07044052169e244)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFloat(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/check:litv"
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l9 = alloca %"compiler/check:litv"
  %l12 = alloca ptr
  %l13 = alloca i1
  %l20 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i1
  %l31 = alloca i1
  %l32 = alloca i1
  %l35 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t6 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store %"compiler/check:litv" %t6, ptr %l9
  br label %bb1
bb1:
  %t7 = load %"compiler/check:litv", ptr %l9
  store %"compiler/check:litv" %t7, ptr %l2
  %t8 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 0
  %t9 = load i1, ptr %t8, !tbaa !21
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 1
  %t12 = load i1, ptr %t11, !tbaa !21
  store i1 %t12, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l1, !tbaa !29
  store ptr %t14, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t15 = load ptr, ptr %l12, !tbaa !29
  %t16 = icmp ne ptr %t15, null
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t18 = load ptr, ptr %l12, !tbaa !29
  %t19 = load i64, ptr %t18, !range !{i64 0, i64 30}
  %t21 = icmp eq i64 %t19, 2
  store i1 %t21, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t22 = load i1, ptr %l13, !tbaa !21
  br i1 %t22, label %bb7, label %bb8
bb7:
  %t23 = load ptr, ptr %l1, !tbaa !29
  %t25 = getelementptr { i64, [4 x i64] }, ptr %t23, i32 0, i32 1
  %t26 = getelementptr { %"compiler/source:Span", ptr }, ptr %t25, i32 0, i32 1
  %t27 = load ptr, ptr %t26
  store ptr %t27, ptr %l3, !tbaa !29
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load ptr, ptr %l3, !tbaa !29
  %t33 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFloat(ptr %v0, ptr %v1, ptr %t29, ptr %t30)
  store i1 %t33, ptr %l20
  br label %bb10
bb10:
  %t34 = load i1, ptr %l20, !tbaa !21
  store i1 %t34, ptr %rv
  br label %ret
bb11:
  %t35 = load ptr, ptr %l1, !tbaa !29
  store ptr %t35, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t36 = load ptr, ptr %l21, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb12, label %bb13
bb12:
  %t39 = load ptr, ptr %l21, !tbaa !29
  %t40 = load i64, ptr %t39, !range !{i64 0, i64 30}
  %t42 = icmp eq i64 %t40, 8
  store i1 %t42, ptr %l22, !tbaa !21
  br label %bb13
bb13:
  %t43 = load i1, ptr %l22, !tbaa !21
  br i1 %t43, label %bb14, label %bb15
bb14:
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t46 = getelementptr { i64, [4 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t46, i32 0, i32 1
  %t48 = load ptr, ptr %t47
  store ptr %t48, ptr %l4, !tbaa !29
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t52 = getelementptr { i64, [4 x i64] }, ptr %t50, i32 0, i32 1
  %t53 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t52, i32 0, i32 3
  %t54 = load ptr, ptr %t53
  store ptr %t54, ptr %l5, !tbaa !29
  br label %bb16
bb15:
  br label %bb22
bb16:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load ptr, ptr %l4, !tbaa !29
  %t60 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFloat(ptr %v0, ptr %v1, ptr %t56, ptr %t57)
  store i1 %t60, ptr %l31
  br label %bb17
bb17:
  %t61 = load i1, ptr %l31, !tbaa !21
  br i1 %t61, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb21
bb19:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load ptr, ptr %l5, !tbaa !29
  %t66 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFloat(ptr %v0, ptr %v1, ptr %t62, ptr %t63)
  store i1 %t66, ptr %l35
  br label %bb20
bb20:
  %t67 = load i1, ptr %l35, !tbaa !21
  store i1 %t67, ptr %l32, !tbaa !21
  br label %bb21
bb21:
  %t68 = load i1, ptr %l32, !tbaa !21
  store i1 %t68, ptr %rv
  br label %ret
bb22:
  br i1 true, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  store i1 false, ptr %rv
  br label %ret
bb26:
  call void @__olang_check_failed(ptr @olang_loc_742d7ba0854a02e0_30f006efbe908ac)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eloopCall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, ptr %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i64
  %lp8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca %"compiler/generic:AnySlot"
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca i64
  %l26 = alloca ptr
  %l29 = alloca i32
  %l32 = alloca i64
  %l33 = alloca ptr
  %l41 = alloca ptr
  %l44 = alloca i32
  %l45 = alloca i32
  %l49 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l59 = alloca ptr
  %l60 = alloca %"compiler/source:Span"
  %l61 = alloca %"compiler/source:Span"
  %l62 = alloca i32
  %l68 = alloca ptr
  %l70 = alloca ptr
  %l75 = alloca ptr
  %l77 = alloca ptr
  %l78 = alloca %"compiler/source:Span"
  %l79 = alloca %"compiler/source:Span"
  %l80 = alloca i64
  %l82 = alloca ptr
  %l85 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l90 = alloca ptr
  %l92 = alloca ptr
  %l100 = alloca { i64, ptr }
  %l107 = alloca { i64, ptr }
  %l114 = alloca i32
  %l117 = alloca ptr
  %l122 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l126 = alloca i64
  %l130 = alloca i64
  %l133 = alloca i64
  %l153 = alloca ptr
  %l157 = alloca i32
  %l158 = alloca i32
  %l161 = alloca ptr
  %l165 = alloca i32
  %l172 = alloca i64
  %l174 = alloca i64
  %l179 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  %t97 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i64 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l26
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l26, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %s0, ptr %s0, ptr %t8, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d10, i32 0, i32 1) }, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d11, i32 0, i32 1) })
  store i32 %t10, ptr %l29
  br label %bb2
bb2:
  %t11 = load i32, ptr %l29, !tbaa !23
  store i32 %t11, ptr %l6, !tbaa !23
  %t12 = load ptr, ptr %l5, !tbaa !29
  %t14 = getelementptr %"compiler/check:frame", ptr %t12, i32 0, i32 26
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t14)
  store i64 %t16, ptr %l32
  br label %bb3
bb3:
  %t17 = load i64, ptr %l32, !tbaa !24
  store i64 %t17, ptr %l7, !tbaa !24
  %t18 = load ptr, ptr %l5, !tbaa !29
  store ptr %t18, ptr %l33, !tbaa !29
  %t19 = load ptr, ptr %l33, !tbaa !29
  %t20 = getelementptr %"compiler/check:frame", ptr %t19, i32 0, i32 15
  %t21 = load i64, ptr %t20, !tbaa !24
  %t23 = add i64 %t21, 1
  %t25 = load ptr, ptr %l33, !tbaa !29
  %t26 = getelementptr %"compiler/check:frame", ptr %t25, i32 0, i32 15
  store i64 %t23, ptr %t26, !tbaa !24
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/check:Checker", ptr %t27, i32 0, i32 41
  store i32 0, ptr %t29, !tbaa !23
  %t30 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 8, i64 8)
  store ptr %t30, ptr %lp8
  %t31 = load ptr, ptr %lp8
  store ptr null, ptr %t31, !tbaa !29
  %t32 = load i64, ptr %l2, !tbaa !24
  %t34 = icmp slt i64 %t32, -1
  br i1 %t34, label %bb4, label %bb5
bb4:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/check:Checker", ptr %t36, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t41 = getelementptr %"compiler/generic:Program", ptr %t39, i32 0, i32 2
  store ptr %t41, ptr %l41, !tbaa !29
  %t42 = load ptr, ptr %l3, !tbaa !29
  %t45 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t42)
  store i32 %t45, ptr %l44
  br label %bb6
bb5:
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l77, !tbaa !29
  %t47 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t47, ptr %l78
  %t48 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t48, ptr %l79
  %t49 = load i64, ptr %l2, !tbaa !24
  store i64 %t49, ptr %l80, !tbaa !24
  %t50 = load ptr, ptr %l3, !tbaa !29
  store ptr %t50, ptr %l82, !tbaa !29
  %t52 = icmp sge i64 0, 0
  br i1 %t52, label %bb15, label %bb16
bb6:
  %t54 = load ptr, ptr %l41, !tbaa !29
  %t55 = load i32, ptr %l44, !tbaa !23
  %t56 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %t54, i32 %t55)
  store i32 %t56, ptr %l45
  br label %bb7
bb7:
  %t57 = load i32, ptr %l45, !tbaa !23
  store i32 %t57, ptr %l9, !tbaa !23
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/check:Checker", ptr %t58, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t62 = load i32, ptr %l9, !tbaa !23
  %t65 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %v0, ptr %t61, i32 %t62)
  store { i64, ptr } %t65, ptr %l49
  br label %bb8
bb8:
  %t66 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t66, ptr %l50, !tbaa !27
  %t67 = load i64, ptr %l2, !tbaa !24
  %t69 = sub i64 -2, %t67
  %t71 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr %"compiler/generic:AnySlot", ptr %t72, i64 %t69
  %t74 = load %"compiler/generic:AnySlot", ptr %t73
  store %"compiler/generic:AnySlot" %t74, ptr %l10
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load i32, ptr %l9, !tbaa !23
  %t78 = load i64, ptr %l2, !tbaa !24
  %t80 = sub i64 -2, %t78
  %t81 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eslotCall(ptr %v0, ptr %t76, i32 %t77, i64 %t80, %"compiler/source:Span" %t81)
  br label %bb9
bb9:
  %t86 = load ptr, ptr %l0, !tbaa !29
  store ptr %t86, ptr %l59, !tbaa !29
  %t87 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t87, ptr %l60
  %t88 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t88, ptr %l61
  %t89 = getelementptr %"compiler/generic:AnySlot", ptr %l10, i32 0, i32 5
  %t90 = load i32, ptr %t89, !tbaa !23
  store i32 %t90, ptr %l62, !tbaa !23
  %t91 = load i32, ptr %l9, !tbaa !23
  %t92 = load i64, ptr %l2, !tbaa !24
  %t94 = sub i64 -2, %t92
  %t95 = getelementptr %"compiler/generic:AnySlot", ptr %l10, i32 0, i32 5
  %t96 = load i32, ptr %t95, !tbaa !23
  store { i64, [3 x i64] } zeroinitializer, ptr %t97
  %t98 = getelementptr { i64, [3 x i64] }, ptr %t97, i32 0, i32 0
  store i64 3, ptr %t98
  %t100 = insertvalue { i32, i64, i32 } undef, i32 %t91, 0
  %t102 = insertvalue { i32, i64, i32 } %t100, i64 %t94, 1
  %t104 = insertvalue { i32, i64, i32 } %t102, i32 %t96, 2
  %t105 = getelementptr { i64, [3 x i64] }, ptr %t97, i32 0, i32 1
  store { i32, i64, i32 } %t104, ptr %t105
  %t106 = load { i64, [3 x i64] }, ptr %t97
  %t108 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 32, i64 8)
  store { i64, [3 x i64] } %t106, ptr %t108
  store ptr %t108, ptr %l68, !tbaa !29
  %t109 = load ptr, ptr %l3, !tbaa !29
  store ptr %t109, ptr %l70, !tbaa !29
  %t111 = icmp sge i64 0, 0
  br i1 %t111, label %bb10, label %bb11
bb10:
  %t113 = icmp sle i64 0, 1152921504606846975
  br i1 %t113, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_652199a1d15cfac6_f2a0b86627c88902)
  unreachable
bb12:
  %t115 = mul i64 0, 8
  %t116 = insertvalue { i64, ptr } undef, i64 0, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t118 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t119 = load ptr, ptr %l59, !tbaa !29
  %t120 = load %"compiler/source:Span", ptr %l60
  %t121 = load %"compiler/source:Span", ptr %l61
  %t122 = load i32, ptr %l62, !tbaa !23
  %t123 = load ptr, ptr %l68, !tbaa !29
  %t124 = load ptr, ptr %l70, !tbaa !29
  %t127 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallBody(ptr %v0, ptr %v3, ptr %v1, ptr %v0, ptr %v2, ptr %v3, ptr %t119, %"compiler/source:Span" %t120, %"compiler/source:Span" %t121, i32 %t122, ptr %t123, i64 -1, ptr %t124, { i64, ptr } %t117, { i64, ptr } %t118)
  store ptr %t127, ptr %l75
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_652199a1d15cfac6_f2a0b86627c88902)
  unreachable
bb14:
  %t128 = load ptr, ptr %l75, !tbaa !29
  %t130 = load ptr, ptr %lp8
  store ptr %t128, ptr %t130, !tbaa !29
  br label %bb24
bb15:
  %t131 = icmp sle i64 0, 1152921504606846975
  br i1 %t131, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_7509e56452997e5b_fb360af196d85db7)
  unreachable
bb17:
  %t133 = mul i64 0, 8
  %t134 = insertvalue { i64, ptr } undef, i64 0, 0
  %t135 = insertvalue { i64, ptr } %t134, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t135, ptr %l85, !tbaa !27
  %t136 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t136, ptr %l86, !tbaa !27
  %t137 = icmp sge i64 0, 0
  br i1 %t137, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_7509e56452997e5b_fb360af196d85db7)
  unreachable
bb19:
  %t139 = icmp sle i64 0, 2305843009213693951
  br i1 %t139, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_ff81ff8210117a78_6f7a62fdc976c914)
  unreachable
bb21:
  %t141 = mul i64 0, 4
  %t142 = insertvalue { i64, ptr } undef, i64 0, 0
  %t143 = insertvalue { i64, ptr } %t142, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t144 = load ptr, ptr %l77, !tbaa !29
  %t145 = load %"compiler/source:Span", ptr %l78
  %t146 = load %"compiler/source:Span", ptr %l79
  %t147 = load i64, ptr %l80, !tbaa !24
  %t148 = load ptr, ptr %l82, !tbaa !29
  %t149 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t150 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t152 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v1, ptr %v0, ptr %v2, ptr %v3, ptr %v3, ptr %t144, %"compiler/source:Span" %t145, %"compiler/source:Span" %t146, i64 %t147, ptr %t148, { i64, ptr } %t149, { i64, ptr } %t150, { i64, ptr } %t143)
  store ptr %t152, ptr %l90
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_ff81ff8210117a78_6f7a62fdc976c914)
  unreachable
bb23:
  %t153 = load ptr, ptr %l90, !tbaa !29
  %t155 = load ptr, ptr %lp8
  store ptr %t153, ptr %t155, !tbaa !29
  br label %bb24
bb24:
  %t156 = load ptr, ptr %l5, !tbaa !29
  store ptr %t156, ptr %l92, !tbaa !29
  %t157 = load ptr, ptr %l92, !tbaa !29
  %t158 = getelementptr %"compiler/check:frame", ptr %t157, i32 0, i32 15
  %t159 = load i64, ptr %t158, !tbaa !24
  %t161 = sub i64 %t159, 1
  %t163 = load ptr, ptr %l92, !tbaa !29
  %t164 = getelementptr %"compiler/check:frame", ptr %t163, i32 0, i32 15
  store i64 %t161, ptr %t164, !tbaa !24
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/check:Checker", ptr %t165, i32 0, i32 1
  %t168 = load ptr, ptr %t167, !tbaa !29
  %t170 = getelementptr %"compiler/generic:Program", ptr %t168, i32 0, i32 2
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t173 = getelementptr %"compiler/check:Checker", ptr %t171, i32 0, i32 41
  %t174 = load i32, ptr %t173, !tbaa !23
  %t177 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t170, i32 %t174)
  store { i64, ptr } %t177, ptr %l100
  br label %bb25
bb25:
  %t178 = load { i64, ptr }, ptr %l100, !tbaa !27
  store { i64, ptr } %t178, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t179 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t181 = extractvalue { i64, ptr } %t179, 0
  store i64 %t181, ptr %l13, !tbaa !24
  br label %bb26
bb26:
  %t183 = load i64, ptr %l12, !tbaa !24
  %t184 = load i64, ptr %l13, !tbaa !24
  %t187 = icmp slt i64 %t183, %t184
  %t189 = xor i1 %t187, true
  br i1 %t189, label %bb27, label %bb28
bb27:
  br label %bb35
bb28:
  br label %bb29
bb29:
  %t191 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t191, ptr %l107, !tbaa !27
  %t192 = load i64, ptr %l12, !tbaa !24
  %t194 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t195 = load ptr, ptr %t194, !tbaa !27
  %t196 = getelementptr i32, ptr %t195, i64 %t192
  %t197 = load i32, ptr %t196, !tbaa !33
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t201 = getelementptr %"compiler/check:Checker", ptr %t199, i32 0, i32 1
  %t202 = load ptr, ptr %t201, !tbaa !29
  %t204 = getelementptr %"compiler/generic:Program", ptr %t202, i32 0, i32 2
  %t208 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t204, i32 %t197)
  store i32 %t208, ptr %l114
  br label %bb30
bb30:
  %t209 = load i32, ptr %l6, !tbaa !23
  %t210 = load i32, ptr %l114, !tbaa !23
  %t212 = icmp ne i32 %t210, %t209
  br i1 %t212, label %bb31, label %bb32
bb31:
  %t214 = load ptr, ptr %l5, !tbaa !29
  store ptr %t214, ptr %l117, !tbaa !29
  %t215 = load ptr, ptr %l117, !tbaa !29
  %t216 = getelementptr %"compiler/check:frame", ptr %t215, i32 0, i32 17
  %t217 = load i64, ptr %t216, !tbaa !24
  %t219 = add i64 %t217, 1
  %t221 = load ptr, ptr %l117, !tbaa !29
  %t222 = getelementptr %"compiler/check:frame", ptr %t221, i32 0, i32 17
  store i64 %t219, ptr %t222, !tbaa !24
  br label %bb33
bb32:
  br label %bb33
bb33:
  br label %bb34
bb34:
  %t223 = load i64, ptr %l12, !tbaa !24
  %t225 = add i64 %t223, 1
  store i64 %t225, ptr %l12, !tbaa !24
  br label %bb26
bb35:
  %t227 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t227, ptr %l122
  br label %bb36
bb36:
  %t228 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l122
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t228, ptr %l15
  %t229 = load i64, ptr %l7, !tbaa !24
  store i64 %t229, ptr %l16, !tbaa !24
  %t231 = load ptr, ptr %l5, !tbaa !29
  %t233 = getelementptr %"compiler/check:frame", ptr %t231, i32 0, i32 26
  %t235 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t233)
  store i64 %t235, ptr %l126
  br label %bb37
bb37:
  %t236 = load i64, ptr %l126, !tbaa !24
  store i64 %t236, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t237 = load i64, ptr %l17, !tbaa !24
  %t238 = load i64, ptr %l16, !tbaa !24
  %t241 = icmp sgt i64 %t237, %t238
  br i1 %t241, label %bb38, label %bb39
bb38:
  %t243 = load i64, ptr %l18, !tbaa !24
  %t245 = icmp sgt i64 %t243, 0
  br i1 %t245, label %bb40, label %bb41
bb39:
  store i64 0, ptr %l130, !tbaa !24
  br label %bb43
bb40:
  %t247 = load i64, ptr %l17, !tbaa !24
  %t248 = load i64, ptr %l16, !tbaa !24
  %t251 = sub i64 %t247, %t248
  %t252 = load i64, ptr %l18, !tbaa !24
  %t255 = add i64 %t251, %t252
  %t257 = sub i64 %t255, 1
  %t258 = load i64, ptr %l18, !tbaa !24
  %t261 = sdiv i64 %t257, %t258
  store i64 %t261, ptr %l133, !tbaa !24
  br label %bb42
bb41:
  store i64 0, ptr %l133, !tbaa !24
  br label %bb42
bb42:
  %t263 = load i64, ptr %l133, !tbaa !24
  store i64 %t263, ptr %l130, !tbaa !24
  br label %bb43
bb43:
  %t264 = load i64, ptr %l130, !tbaa !24
  store i64 %t264, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb44
bb44:
  %t265 = load i64, ptr %l20, !tbaa !24
  %t266 = load i64, ptr %l19, !tbaa !24
  %t269 = icmp slt i64 %t265, %t266
  %t271 = xor i1 %t269, true
  br i1 %t271, label %bb45, label %bb46
bb45:
  br label %bb56
bb46:
  br label %bb47
bb47:
  %t273 = load i64, ptr %l16, !tbaa !24
  %t274 = load i64, ptr %l20, !tbaa !24
  %t275 = load i64, ptr %l18, !tbaa !24
  %t278 = mul i64 %t274, %t275
  %t281 = add i64 %t273, %t278
  store i64 %t281, ptr %l21, !tbaa !24
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t285 = getelementptr %"compiler/check:Checker", ptr %t283, i32 0, i32 1
  %t286 = load ptr, ptr %t285, !tbaa !29
  %t288 = getelementptr %"compiler/generic:Program", ptr %t286, i32 0, i32 2
  store ptr %t288, ptr %l153, !tbaa !29
  %t289 = load ptr, ptr %l5, !tbaa !29
  %t291 = getelementptr %"compiler/check:frame", ptr %t289, i32 0, i32 26
  %t292 = load i64, ptr %l21, !tbaa !24
  %t295 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t291, i64 %t292)
  store i32 %t295, ptr %l157
  br label %bb48
bb48:
  %t296 = load ptr, ptr %l153, !tbaa !29
  %t297 = load i32, ptr %l157, !tbaa !23
  %t298 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t296, i32 %t297)
  store i32 %t298, ptr %l158
  br label %bb49
bb49:
  %t299 = load i32, ptr %l6, !tbaa !23
  %t300 = load i32, ptr %l158, !tbaa !23
  %t302 = icmp ne i32 %t300, %t299
  br i1 %t302, label %bb50, label %bb51
bb50:
  store ptr %l15, ptr %l161, !tbaa !29
  %t304 = load ptr, ptr %l5, !tbaa !29
  %t306 = getelementptr %"compiler/check:frame", ptr %t304, i32 0, i32 26
  %t307 = load i64, ptr %l21, !tbaa !24
  %t310 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t306, i64 %t307)
  store i32 %t310, ptr %l165
  br label %bb52
bb51:
  br label %bb54
bb52:
  %t311 = load ptr, ptr %l161, !tbaa !29
  %t312 = load i32, ptr %l165, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t311, i32 %t312)
  br label %bb53
bb53:
  br label %bb54
bb54:
  br label %bb55
bb55:
  %t313 = load i64, ptr %l20, !tbaa !24
  %t315 = add i64 %t313, 1
  store i64 %t315, ptr %l20, !tbaa !24
  br label %bb44
bb56:
  %t317 = load ptr, ptr %l5, !tbaa !29
  %t319 = getelementptr %"compiler/check:frame", ptr %t317, i32 0, i32 26
  %t320 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eTruncate_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t319, i64 %t320)
  br label %bb57
bb57:
  store ptr %l15, ptr %l22, !tbaa !29
  store i64 0, ptr %l23, !tbaa !24
  br label %bb58
bb58:
  %t324 = load i64, ptr %l23, !tbaa !24
  store i64 %t324, ptr %l172, !tbaa !24
  %t325 = load ptr, ptr %l22, !tbaa !29
  %t327 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t325)
  store i64 %t327, ptr %l174
  br label %bb59
bb59:
  %t328 = load i64, ptr %l172, !tbaa !24
  %t329 = load i64, ptr %l174, !tbaa !24
  %t330 = icmp slt i64 %t328, %t329
  %t332 = xor i1 %t330, true
  br i1 %t332, label %bb60, label %bb61
bb60:
  br label %bb66
bb61:
  br label %bb62
bb62:
  %t334 = load ptr, ptr %l22, !tbaa !29
  %t335 = load i64, ptr %l23, !tbaa !24
  %t338 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t334, i64 %t335)
  store i32 %t338, ptr %l179
  br label %bb63
bb63:
  %t339 = load i32, ptr %l179, !tbaa !23
  %t340 = load ptr, ptr %l5, !tbaa !29
  %t342 = getelementptr %"compiler/check:frame", ptr %t340, i32 0, i32 26
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t342, i32 %t339)
  br label %bb64
bb64:
  br label %bb65
bb65:
  %t346 = load i64, ptr %l23, !tbaa !24
  %t348 = add i64 %t346, 1
  store i64 %t348, ptr %l23, !tbaa !24
  br label %bb58
bb66:
  %t350 = load ptr, ptr %lp8
  %t351 = load ptr, ptr %t350, !tbaa !29
  %t353 = icmp eq ptr %t351, null
  br i1 %t353, label %bb67, label %bb68
bb67:
  call void @__olang_check_failed(ptr @olang_loc_77a5603a1298311f_4bb819fe8c7bb9e3)
  unreachable
bb68:
  br label %bb69
bb69:
  %t355 = load ptr, ptr %lp8
  %t356 = load ptr, ptr %t355, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t356, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emsgOwner(ptr %v0, ptr %v1, ptr %a0, i1 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  br i1 %a1, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d12, i32 0, i32 1) }, ptr %l3, !tbaa !27
  br label %bb3
bb2:
  store { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d13, i32 0, i32 1) }, ptr %l3, !tbaa !27
  br label %bb3
bb3:
  %t3 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t3, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoteAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, %"compiler/msgs:Msg" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l15 = alloca ptr
  %l19 = alloca i64
  %l25 = alloca ptr
  %l36 = alloca { i64, ptr }
  %l41 = alloca i64
  %l53 = alloca i64
  %l54 = alloca { i64, ptr }
  %l55 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i32
  %l69 = alloca i64
  %l79 = alloca ptr
  %l80 = alloca i64
  %l86 = alloca ptr
  %t188 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l2, !tbaa !24
  %t8 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t4, i64 %t5)
  store ptr %t8, ptr %l15
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l15, !tbaa !29
  store ptr %t9, ptr %l4, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t14 = load i64, ptr %l2, !tbaa !24
  %t17 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t13, i64 %t14)
  store i64 %t17, ptr %l19
  br label %bb2
bb2:
  %t18 = load i64, ptr %l19, !tbaa !24
  store i64 %t18, ptr %l5, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr %"compiler/generic:Program", ptr %t22, i32 0, i32 0
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/load:Loader", ptr %t25, i32 0, i32 10
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t27, i64 %t28)
  store ptr %t31, ptr %l25
  br label %bb3
bb3:
  %t32 = load ptr, ptr %l25, !tbaa !29
  %t34 = getelementptr %"compiler/load:Module", ptr %t32, i32 0, i32 6
  %t35 = load ptr, ptr %t34, !tbaa !29
  store ptr %t35, ptr %l6, !tbaa !29
  %t37 = load ptr, ptr %l6, !tbaa !29
  %t39 = icmp eq ptr %t37, null
  br i1 %t39, label %bb4, label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_f66b04275832bdf5_49261566e6ebbc09)
  unreachable
bb5:
  br label %bb6
bb6:
  %t41 = load ptr, ptr %l6, !tbaa !29
  %t44 = getelementptr %"compiler/source:Source", ptr %t41, i32 0, i32 1
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !27
  store { i64, ptr } %t45, ptr %l7, !tbaa !27
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load ptr, ptr %l4, !tbaa !29
  %t50 = getelementptr %"compiler/ast:Func", ptr %t48, i32 0, i32 2
  %t51 = load i32, ptr %t50, !tbaa !23
  %t54 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t47, i32 %t51)
  store { i64, ptr } %t54, ptr %l36
  br label %bb7
bb7:
  %t55 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t55, ptr %l8, !tbaa !27
  %t56 = load ptr, ptr %l4, !tbaa !29
  %t58 = getelementptr %"compiler/ast:Func", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = icmp eq ptr %t59, null
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb8, label %bb9
bb8:
  %t65 = load ptr, ptr %l4, !tbaa !29
  %t67 = getelementptr %"compiler/ast:Func", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t70 = icmp eq ptr %t68, null
  br i1 %t70, label %bb10, label %bb11
bb9:
  %t72 = load ptr, ptr %l4, !tbaa !29
  %t74 = getelementptr %"compiler/ast:Func", ptr %t72, i32 0, i32 0
  %t75 = getelementptr %"compiler/source:Span", ptr %t74, i32 0, i32 0
  %t76 = load i32, ptr %t75, !tbaa !23
  %t78 = sext i32 %t76 to i64
  store i64 %t78, ptr %l41, !tbaa !24
  br label %bb13
bb10:
  call void @__olang_check_failed(ptr @olang_loc_959932aa8b846e4e_2c1999e37dfb1a2)
  unreachable
bb11:
  br label %bb12
bb12:
  %t80 = load ptr, ptr %l4, !tbaa !29
  %t82 = getelementptr %"compiler/ast:Func", ptr %t80, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t86 = getelementptr %"compiler/ast:Param", ptr %t83, i32 0, i32 0
  %t87 = getelementptr %"compiler/source:Span", ptr %t86, i32 0, i32 1
  %t88 = load i32, ptr %t87, !tbaa !23
  %t90 = sext i32 %t88 to i64
  store i64 %t90, ptr %l41, !tbaa !24
  br label %bb13
bb13:
  %t92 = load i64, ptr %l41, !tbaa !24
  store i64 %t92, ptr %l9, !tbaa !24
  %t93 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t93, ptr %l54, !tbaa !27
  %t94 = load i64, ptr %l9, !tbaa !24
  store i64 %t94, ptr %l55, !tbaa !24
  %t95 = load ptr, ptr %l4, !tbaa !29
  %t97 = getelementptr %"compiler/ast:Func", ptr %t95, i32 0, i32 0
  %t98 = getelementptr %"compiler/source:Span", ptr %t97, i32 0, i32 1
  %t99 = load i32, ptr %t98, !tbaa !23
  %t101 = sext i32 %t99 to i64
  store i64 %t101, ptr %l58, !tbaa !24
  %t102 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t102, 0
  store i64 %t103, ptr %l59, !tbaa !24
  %t104 = load i64, ptr %l55, !tbaa !24
  %t105 = icmp sge i64 %t104, 0
  br i1 %t105, label %bb14, label %bb15
bb14:
  %t107 = load i64, ptr %l55, !tbaa !24
  %t108 = load i64, ptr %l58, !tbaa !24
  %t109 = icmp sle i64 %t107, %t108
  br i1 %t109, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_f94ac378888081c5_5f597351c4418bf9)
  unreachable
bb16:
  %t111 = load i64, ptr %l58, !tbaa !24
  %t112 = load i64, ptr %l59, !tbaa !24
  %t113 = icmp sle i64 %t111, %t112
  br i1 %t113, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_f94ac378888081c5_5f597351c4418bf9)
  unreachable
bb18:
  %t115 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = load i64, ptr %l55, !tbaa !24
  %t118 = load i64, ptr %l58, !tbaa !24
  %t119 = getelementptr i8, ptr %t116, i64 %t117
  %t120 = sub i64 %t118, %t117
  %t121 = insertvalue { i64, ptr } undef, i64 %t120, 0
  %t122 = insertvalue { i64, ptr } %t121, ptr %t119, 1
  %t123 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t126 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v0, { i64, ptr } %t122, { i64, ptr } %t123)
  %t127 = extractvalue { i32, i64 } %t126, 1
  %t128 = extractvalue { i32, i64 } %t126, 0
  store i32 %t128, ptr %l66
  %t129 = icmp ne i32 %t128, 0
  br i1 %t129, label %bb21, label %ok.130, !prof !99
ok.130:
  store i64 %t127, ptr %l65
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_f94ac378888081c5_5f597351c4418bf9)
  unreachable
bb20:
  %t131 = load i64, ptr %l65, !tbaa !24
  store i64 %t131, ptr %l53, !tbaa !24
  br label %bb23
bb21:
  br label %bb22
bb22:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l53, !tbaa !24
  br label %bb23
bb23:
  %t132 = load i64, ptr %l53, !tbaa !24
  store i64 %t132, ptr %l10, !tbaa !24
  %t133 = load i64, ptr %l10, !tbaa !24
  %t135 = icmp slt i64 %t133, 0
  br i1 %t135, label %bb24, label %bb25
bb24:
  %t137 = load ptr, ptr %l4, !tbaa !29
  %t139 = getelementptr %"compiler/ast:Func", ptr %t137, i32 0, i32 0
  %t140 = getelementptr %"compiler/source:Span", ptr %t139, i32 0, i32 0
  %t141 = load i32, ptr %t140, !tbaa !23
  %t143 = sext i32 %t141 to i64
  store i64 %t143, ptr %l69, !tbaa !24
  br label %bb26
bb25:
  %t145 = load i64, ptr %l9, !tbaa !24
  %t146 = load i64, ptr %l10, !tbaa !24
  %t149 = add i64 %t145, %t146
  store i64 %t149, ptr %l69, !tbaa !24
  br label %bb26
bb26:
  %t151 = load i64, ptr %l69, !tbaa !24
  store i64 %t151, ptr %l11, !tbaa !24
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/check:Checker", ptr %t152, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !29
  %t157 = getelementptr %"compiler/generic:Program", ptr %t155, i32 0, i32 0
  %t158 = load ptr, ptr %t157, !tbaa !29
  %t160 = getelementptr %"compiler/load:Loader", ptr %t158, i32 0, i32 4
  %t161 = load ptr, ptr %t160, !tbaa !29
  store ptr %t161, ptr %l79, !tbaa !29
  store i64 %a1, ptr %l80, !tbaa !24
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t165 = getelementptr %"compiler/check:Checker", ptr %t163, i32 0, i32 1
  %t166 = load ptr, ptr %t165, !tbaa !29
  %t168 = getelementptr %"compiler/generic:Program", ptr %t166, i32 0, i32 0
  %t169 = load ptr, ptr %t168, !tbaa !29
  %t171 = getelementptr %"compiler/load:Loader", ptr %t169, i32 0, i32 10
  %t172 = load i64, ptr %l5, !tbaa !24
  %t175 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t171, i64 %t172)
  store ptr %t175, ptr %l86
  br label %bb27
bb27:
  %t176 = load ptr, ptr %l86, !tbaa !29
  %t178 = getelementptr %"compiler/load:Module", ptr %t176, i32 0, i32 4
  %t179 = load i64, ptr %t178, !tbaa !24
  %t180 = load i64, ptr %l11, !tbaa !24
  %t181 = load i64, ptr %l11, !tbaa !24
  %t182 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t184 = extractvalue { i64, ptr } %t182, 0
  %t187 = add i64 %t181, %t184
  store { i64, [3 x i64] } zeroinitializer, ptr %t188
  %t189 = getelementptr { i64, [3 x i64] }, ptr %t188, i32 0, i32 0
  store i64 3, ptr %t189
  %t191 = insertvalue { i64, i64, i64 } undef, i64 %t179, 0
  %t193 = insertvalue { i64, i64, i64 } %t191, i64 %t180, 1
  %t195 = insertvalue { i64, i64, i64 } %t193, i64 %t187, 2
  %t196 = getelementptr { i64, [3 x i64] }, ptr %t188, i32 0, i32 1
  store { i64, i64, i64 } %t195, ptr %t196
  %t197 = load { i64, [3 x i64] }, ptr %t188
  %t199 = load ptr, ptr %l79, !tbaa !29
  %t200 = load i64, ptr %l80, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %v1, ptr %t199, i64 %t200, { i64, [3 x i64] } %t197, %"compiler/msgs:Msg" %a3)
  br label %bb28
bb28:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoteRo(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca %"compiler/typed:Local"
  %l5 = alloca i32
  %l6 = alloca { i64, [3 x i64] }
  %l9 = alloca i64
  %l13 = alloca ptr
  %l17 = alloca %"compiler/typed:Local"
  %l20 = alloca i32
  %l22 = alloca ptr
  %l25 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l26 = alloca i32
  %l27 = alloca i32
  %l30 = alloca { i64, [3 x i64] }
  %l33 = alloca i1
  %l35 = alloca ptr
  %l38 = alloca i32
  %l43 = alloca i32
  %l44 = alloca i64
  %l49 = alloca ptr
  %l50 = alloca i64
  %l51 = alloca { i64, [3 x i64] }
  %l54 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l64 = alloca %"compiler/msgs:Msg"
  %l68 = alloca ptr
  %l69 = alloca i64
  %l70 = alloca { i64, [3 x i64] }
  %l73 = alloca { i64, ptr }
  %l74 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRoot(ptr %v0, ptr %v1, ptr %t1, ptr %a2)
  store i64 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i64, ptr %l9, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp slt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t11)
  store ptr %t13, ptr %l13
  br label %bb5
bb5:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t16 = trunc i64 %t14 to i32
  %t18 = load ptr, ptr %l13, !tbaa !29
  %t20 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t18, i32 %t16)
  store %"compiler/typed:Local" %t20, ptr %l17
  br label %bb6
bb6:
  %t21 = load %"compiler/typed:Local", ptr %l17
  store %"compiler/typed:Local" %t21, ptr %l4
  %t22 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 0
  %t23 = load i32, ptr %t22, !tbaa !23
  %t25 = icmp eq i32 %t23, 0
  br i1 %t25, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb8:
  br label %bb9
bb9:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/check:Checker", ptr %t27, i32 0, i32 66
  store ptr %t29, ptr %l22, !tbaa !29
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load i64, ptr %l3, !tbaa !24
  %t34 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKey(ptr %v0, ptr %t30, i64 %t31)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t34, ptr %l25
  br label %bb10
bb10:
  %t35 = load ptr, ptr %l22, !tbaa !29
  %t36 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l25
  %t37 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hc59daade663458096c0c7696954afd54(ptr %v0, ptr %t35, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t36)
  %t38 = extractvalue { i32, i32 } %t37, 1
  %t39 = extractvalue { i32, i32 } %t37, 0
  store i32 %t39, ptr %l27
  %t40 = icmp ne i32 %t39, 0
  br i1 %t40, label %bb12, label %ok.41, !prof !99
ok.41:
  store i32 %t38, ptr %l26
  br label %bb11
bb11:
  %t42 = load i32, ptr %l26, !tbaa !23
  store i32 %t42, ptr %l20, !tbaa !23
  br label %bb14
bb12:
  br label %bb13
bb13:
  call void @__olang_ert_req_clear()
  store i32 0, ptr %l20, !tbaa !23
  br label %bb14
bb14:
  %t43 = load i32, ptr %l20, !tbaa !23
  store i32 %t43, ptr %l5, !tbaa !23
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 1
  %t46 = load %"compiler/source:Span", ptr %t45
  %t49 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t44, %"compiler/source:Span" %t46)
  store { i64, [3 x i64] } %t49, ptr %l30
  br label %bb15
bb15:
  %t50 = load { i64, [3 x i64] }, ptr %l30
  store { i64, [3 x i64] } %t50, ptr %l6
  %t51 = load i32, ptr %l5, !tbaa !23
  %t53 = icmp ne i32 %t51, 0
  br i1 %t53, label %bb16, label %bb17
bb16:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/check:Checker", ptr %t55, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !29
  store ptr %t58, ptr %l35, !tbaa !29
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 2
  %t61 = load i32, ptr %t60, !tbaa !23
  %t64 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t59, i32 %t61)
  store i32 %t64, ptr %l38
  br label %bb18
bb17:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb21
bb18:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/check:Checker", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t70 = getelementptr %"compiler/generic:Program", ptr %t68, i32 0, i32 0
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = getelementptr %"compiler/load:Loader", ptr %t71, i32 0, i32 3
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t76 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s0, ptr %t74, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d14, i32 0, i32 1) })
  store i32 %t76, ptr %l43
  br label %bb19
bb19:
  %t77 = load ptr, ptr %l35, !tbaa !29
  %t78 = load i32, ptr %l38, !tbaa !23
  %t79 = load i32, ptr %l43, !tbaa !23
  %t80 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t77, i32 %t78, i32 %t79)
  store i64 %t80, ptr %l44
  br label %bb20
bb20:
  %t81 = load i64, ptr %l44, !tbaa !24
  %t82 = icmp sge i64 %t81, 0
  store i1 %t82, ptr %l33, !tbaa !21
  br label %bb21
bb21:
  %t84 = load i1, ptr %l33, !tbaa !21
  br i1 %t84, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s3
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/check:Checker", ptr %t85, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t90 = getelementptr %"compiler/generic:Program", ptr %t88, i32 0, i32 0
  %t91 = load ptr, ptr %t90, !tbaa !29
  %t93 = getelementptr %"compiler/load:Loader", ptr %t91, i32 0, i32 4
  %t94 = load ptr, ptr %t93, !tbaa !29
  store ptr %t94, ptr %l49, !tbaa !29
  %t95 = load i64, ptr %l1, !tbaa !24
  store i64 %t95, ptr %l50, !tbaa !24
  %t96 = load { i64, [3 x i64] }, ptr %l6
  store { i64, [3 x i64] } %t96, ptr %l51
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 0
  %t99 = load i32, ptr %t98, !tbaa !23
  %t102 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t97, i32 %t99)
  store { i64, ptr } %t102, ptr %l54
  br label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s4
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/check:Checker", ptr %t103, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t108 = getelementptr %"compiler/generic:Program", ptr %t106, i32 0, i32 0
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t111 = getelementptr %"compiler/load:Loader", ptr %t109, i32 0, i32 4
  %t112 = load ptr, ptr %t111, !tbaa !29
  store ptr %t112, ptr %l68, !tbaa !29
  %t113 = load i64, ptr %l1, !tbaa !24
  store i64 %t113, ptr %l69, !tbaa !24
  %t114 = load { i64, [3 x i64] }, ptr %l6
  store { i64, [3 x i64] } %t114, ptr %l70
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 0
  %t117 = load i32, ptr %t116, !tbaa !23
  %t120 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t115, i32 %t117)
  store { i64, ptr } %t120, ptr %l73
  br label %bb30
bb24:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load i32, ptr %l5, !tbaa !23
  %t125 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t121, i32 %t122)
  store { i64, ptr } %t125, ptr %l57
  br label %bb25
bb25:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 0
  %t128 = load i32, ptr %t127, !tbaa !23
  %t131 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t126, i32 %t128)
  store { i64, ptr } %t131, ptr %l60
  br label %bb26
bb26:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load i32, ptr %l5, !tbaa !23
  %t136 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t132, i32 %t133)
  store { i64, ptr } %t136, ptr %l63
  br label %bb27
bb27:
  %t137 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t138 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t139 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t140 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t141 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteReadOnlyCopyOf(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %s3, { i64, ptr } %t137, { i64, ptr } %t138, { i64, ptr } %t139, { i64, ptr } %t140)
  store %"compiler/msgs:Msg" %t141, ptr %l64
  br label %bb28
bb28:
  %t142 = load ptr, ptr %l49, !tbaa !29
  %t143 = load i64, ptr %l50, !tbaa !24
  %t144 = load { i64, [3 x i64] }, ptr %l51
  %t145 = load %"compiler/msgs:Msg", ptr %l64
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s3, ptr %t142, i64 %t143, { i64, [3 x i64] } %t144, %"compiler/msgs:Msg" %t145)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s3)
  br label %bb33
bb30:
  %t146 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t147 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteReadOnlyCopy(ptr %v0, ptr %s4, { i64, ptr } %t146)
  store %"compiler/msgs:Msg" %t147, ptr %l74
  br label %bb31
bb31:
  %t148 = load ptr, ptr %l68, !tbaa !29
  %t149 = load i64, ptr %l69, !tbaa !24
  %t150 = load { i64, [3 x i64] }, ptr %l70
  %t151 = load %"compiler/msgs:Msg", ptr %l74
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s4, ptr %t148, i64 %t149, { i64, [3 x i64] } %t150, %"compiler/msgs:Msg" %t151)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s4)
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullRead(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l5 = alloca i32
  %l10 = alloca i1
  %l13 = alloca %"compiler/source:Span"
  %l14 = alloca ptr
  %l15 = alloca %"compiler/source:Span"
  %l18 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l28 = alloca %"compiler/msgs:Msg"
  %l29 = alloca i64
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t1)
  store i32 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i32, ptr %l5, !tbaa !23
  store i32 %t4, ptr %l2, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = getelementptr %"compiler/generic:Program", ptr %t8, i32 0, i32 2
  %t11 = load i32, ptr %l2, !tbaa !23
  %t14 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t10, i32 %t11)
  store i1 %t14, ptr %l10
  br label %bb2
bb2:
  %t15 = load i1, ptr %l10, !tbaa !21
  %t16 = xor i1 %t15, true
  br i1 %t16, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb4:
  br label %bb5
bb5:
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v1, ptr %t18)
  store %"compiler/source:Span" %t20, ptr %l13
  br label %bb6
bb6:
  %t21 = load %"compiler/source:Span", ptr %l13
  store %"compiler/source:Span" %t21, ptr %l3
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l14, !tbaa !29
  %t23 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t23, ptr %l15
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load %"compiler/source:Span", ptr %l3
  %t28 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t24, %"compiler/source:Span" %t25)
  store { i64, ptr } %t28, ptr %l18
  br label %bb7
bb7:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load i32, ptr %l2, !tbaa !23
  %t33 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t29, i32 %t30)
  store { i64, ptr } %t33, ptr %l21
  br label %bb8
bb8:
  %t34 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t34, 0
  %t36 = extractvalue { i64, ptr } %t34, 1
  %t37 = mul i64 %t35, 1
  %t38 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t37)
  call void @llvm.memcpy.p0.p0.i64(ptr %t38, ptr %t36, i64 %t37, i1 false)
  %t39 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  store { i64, ptr } %t40, ptr %l22, !tbaa !27
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load %"compiler/source:Span", ptr %l3
  %t45 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t41, %"compiler/source:Span" %t42)
  store { i64, ptr } %t45, ptr %l25
  br label %bb9
bb9:
  %t46 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t47 = call { i64, ptr } @compiler_2fcheck_2ebangOf(ptr %v0, ptr %s0, { i64, ptr } %t46)
  store { i64, ptr } %t47, ptr %l26
  br label %bb10
bb10:
  %t48 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t48, 0
  %t50 = extractvalue { i64, ptr } %t48, 1
  %t51 = mul i64 %t49, 1
  %t52 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t51)
  call void @llvm.memcpy.p0.p0.i64(ptr %t52, ptr %t50, i64 %t51, i1 false)
  %t53 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t52, 1
  %t55 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t56 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t58 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadMaybeNull(ptr %v0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t55, { i64, ptr } %t56, { i64, ptr } %t54)
  store %"compiler/msgs:Msg" %t58, ptr %l28
  br label %bb11
bb11:
  %t59 = load ptr, ptr %l14, !tbaa !29
  %t60 = load %"compiler/source:Span", ptr %l15
  %t61 = load %"compiler/msgs:Msg", ptr %l28
  %t62 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s0, ptr %t59, %"compiler/source:Span" %t60, %"compiler/msgs:Msg" %t61)
  store i64 %t62, ptr %l29
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eownCopy(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i64
  %l5 = alloca i1
  %l9 = alloca %"compiler/source:Span"
  %l12 = alloca i64
  %l16 = alloca %"compiler/source:Span"
  %l19 = alloca i32
  %l20 = alloca i32
  %l24 = alloca { i64, ptr }
  %l28 = alloca i32
  %l30 = alloca %"compiler/typed:Make"
  %rv = alloca ptr
  %t50 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call i1 @compiler_2fcheck_2eexistingValue(ptr %v1, ptr %t1)
  store i1 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i1, ptr %l5, !tbaa !21
  %t5 = xor i1 %t4, true
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t7 = load ptr, ptr %l1, !tbaa !29
  store ptr %t7, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t9)
  store %"compiler/source:Span" %t11, ptr %l9
  br label %bb5
bb5:
  %t12 = load %"compiler/source:Span", ptr %l9
  store %"compiler/source:Span" %t12, ptr %l2
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 36
  %t17 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t15)
  store i64 %t17, ptr %l12
  br label %bb6
bb6:
  %t18 = load i64, ptr %l12, !tbaa !24
  store i64 %t18, ptr %l3, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 36
  %t22 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %t21, ptr %t22)
  br label %bb7
bb7:
  %t25 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t25, ptr %l16
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t29 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t26)
  store i32 %t29, ptr %l19
  br label %bb8
bb8:
  store i32 4, ptr %l20
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/check:Checker", ptr %t30, i32 0, i32 36
  %t33 = load i64, ptr %l3, !tbaa !24
  %t36 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t32, i64 %t33)
  store { i64, ptr } %t36, ptr %l24
  br label %bb9
bb9:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load %"compiler/source:Span", ptr %l2
  %t42 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t37, i32 1, %"compiler/source:Span" %t38)
  store i32 %t42, ptr %l28
  br label %bb10
bb10:
  %t43 = load i32, ptr %l20, !range !{i32 0, i32 5}
  %t44 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t45 = load i32, ptr %l28, !tbaa !23
  %t47 = call %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v2, ptr %v2, i32 %t43, i64 0, { i64, ptr } %t44, ptr null, i32 %t45, i32 0, i1 false)
  store %"compiler/typed:Make" %t47, ptr %l30
  br label %bb11
bb11:
  %t48 = load %"compiler/typed:Make", ptr %l30
  %t49 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 56, i64 8)
  store %"compiler/typed:Make" %t48, ptr %t49
  store { i64, [5 x i64] } zeroinitializer, ptr %t50
  %t51 = getelementptr { i64, [5 x i64] }, ptr %t50, i32 0, i32 0
  store i64 7, ptr %t51
  %t52 = load %"compiler/source:Span", ptr %l16
  %t53 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t52, 0
  %t54 = load i32, ptr %l19, !tbaa !23
  %t55 = insertvalue { %"compiler/source:Span", i32, ptr } %t53, i32 %t54, 1
  %t57 = insertvalue { %"compiler/source:Span", i32, ptr } %t55, ptr %t49, 2
  %t58 = getelementptr { i64, [5 x i64] }, ptr %t50, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t57, ptr %t58
  %t59 = load { i64, [5 x i64] }, ptr %t50
  %t61 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t59, ptr %t61
  store ptr %t61, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamIndex(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/typed:Local"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca ptr
  %l15 = alloca %"compiler/typed:Local"
  %l19 = alloca i1
  %l22 = alloca i1
  %l23 = alloca i1
  %l26 = alloca i1
  %l30 = alloca ptr
  %l32 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l34 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l36 = alloca i64
  %l40 = alloca i64
  %l43 = alloca i64
  %l63 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l11
  br label %bb1
bb1:
  %t4 = load i64, ptr %l1, !tbaa !24
  %t6 = trunc i64 %t4 to i32
  %t8 = load ptr, ptr %l11, !tbaa !29
  %t10 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t8, i32 %t6)
  store %"compiler/typed:Local" %t10, ptr %l15
  br label %bb2
bb2:
  %t11 = load %"compiler/typed:Local", ptr %l15
  store %"compiler/typed:Local" %t11, ptr %l2
  %t12 = getelementptr %"compiler/typed:Local", ptr %l2, i32 0, i32 4
  %t13 = load i32, ptr %t12, !range !{i32 0, i32 7}
  %t15 = trunc i64 0 to i32
  %t16 = icmp eq i32 %t13, %t15
  %t18 = xor i1 %t16, true
  br i1 %t18, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb6
bb4:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/typed:Local", ptr %l2, i32 0, i32 2
  %t22 = load i32, ptr %t21, !tbaa !23
  %t25 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t20, i32 %t22)
  store i1 %t25, ptr %l22
  br label %bb5
bb5:
  %t26 = load i1, ptr %l22, !tbaa !21
  store i1 %t26, ptr %l19, !tbaa !21
  br label %bb6
bb6:
  %t27 = load i1, ptr %l19, !tbaa !21
  br i1 %t27, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb10
bb8:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/typed:Local", ptr %l2, i32 0, i32 2
  %t30 = load i32, ptr %t29, !tbaa !23
  %t33 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritable(ptr %v0, ptr %t28, i32 %t30)
  store i1 %t33, ptr %l26
  br label %bb9
bb9:
  %t34 = load i1, ptr %l26, !tbaa !21
  %t35 = xor i1 %t34, true
  store i1 %t35, ptr %l23, !tbaa !21
  br label %bb10
bb10:
  %t37 = load i1, ptr %l23, !tbaa !21
  br i1 %t37, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t39)
  store ptr %t41, ptr %l30
  br label %bb14
bb14:
  %t42 = load ptr, ptr %l30, !tbaa !29
  %t44 = getelementptr %"compiler/typed:Body", ptr %t42, i32 0, i32 5
  %t45 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t44
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t45, ptr %l32
  %t47 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e(ptr %s0, ptr %l32)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t47, ptr %l34
  br label %bb15
bb15:
  %t48 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l34
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t48, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  %t50 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %s0, ptr %l3)
  store i64 %t50, ptr %l36
  br label %bb16
bb16:
  %t51 = load i64, ptr %l36, !tbaa !24
  store i64 %t51, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t52 = load i64, ptr %l5, !tbaa !24
  %t53 = load i64, ptr %l4, !tbaa !24
  %t56 = icmp sgt i64 %t52, %t53
  br i1 %t56, label %bb17, label %bb18
bb17:
  %t58 = load i64, ptr %l6, !tbaa !24
  %t60 = icmp sgt i64 %t58, 0
  br i1 %t60, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l40, !tbaa !24
  br label %bb22
bb19:
  %t62 = load i64, ptr %l5, !tbaa !24
  %t63 = load i64, ptr %l4, !tbaa !24
  %t66 = sub i64 %t62, %t63
  %t67 = load i64, ptr %l6, !tbaa !24
  %t70 = add i64 %t66, %t67
  %t72 = sub i64 %t70, 1
  %t73 = load i64, ptr %l6, !tbaa !24
  %t76 = sdiv i64 %t72, %t73
  store i64 %t76, ptr %l43, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l43, !tbaa !24
  br label %bb21
bb21:
  %t78 = load i64, ptr %l43, !tbaa !24
  store i64 %t78, ptr %l40, !tbaa !24
  br label %bb22
bb22:
  %t79 = load i64, ptr %l40, !tbaa !24
  store i64 %t79, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb23
bb23:
  %t80 = load i64, ptr %l8, !tbaa !24
  %t81 = load i64, ptr %l7, !tbaa !24
  %t84 = icmp slt i64 %t80, %t81
  %t86 = xor i1 %t84, true
  br i1 %t86, label %bb24, label %bb25
bb24:
  br label %bb32
bb25:
  br label %bb26
bb26:
  %t88 = load i64, ptr %l4, !tbaa !24
  %t89 = load i64, ptr %l8, !tbaa !24
  %t90 = load i64, ptr %l6, !tbaa !24
  %t93 = mul i64 %t89, %t90
  %t96 = add i64 %t88, %t93
  store i64 %t96, ptr %l9, !tbaa !24
  %t98 = load i64, ptr %l9, !tbaa !24
  %t101 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %s0, ptr %l3, i64 %t98)
  store i32 %t101, ptr %l63
  br label %bb27
bb27:
  %t102 = load i32, ptr %l63, !tbaa !23
  %t103 = sext i32 %t102 to i64
  %t104 = load i64, ptr %l1, !tbaa !24
  %t107 = icmp eq i64 %t103, %t104
  br i1 %t107, label %bb28, label %bb29
bb28:
  %t109 = load i64, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t109, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t111 = load i64, ptr %l8, !tbaa !24
  %t113 = add i64 %t111, 1
  store i64 %t113, ptr %l8, !tbaa !24
  br label %bb23
bb32:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eputTarget(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i1 %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca i32
  %l9 = alloca ptr
  %l11 = alloca %"compiler/source:Span"
  %l13 = alloca ptr
  %l14 = alloca i1
  %l23 = alloca { i64, ptr }
  %l24 = alloca i1
  %l26 = alloca ptr
  %l30 = alloca i1
  %l31 = alloca i1
  %l34 = alloca i32
  %l39 = alloca i32
  %l42 = alloca ptr
  %l45 = alloca i32
  %l46 = alloca i32
  %l49 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca i32
  %l56 = alloca i32
  %l57 = alloca i1
  %l63 = alloca ptr
  %l70 = alloca i64
  %l79 = alloca ptr
  %l80 = alloca %"compiler/source:Span"
  %l81 = alloca %"compiler/msgs:Msg"
  %l82 = alloca i64
  %l85 = alloca ptr
  %l88 = alloca ptr
  %l89 = alloca %"compiler/source:Span"
  %l90 = alloca ptr
  %l91 = alloca ptr
  %l92 = alloca ptr
  %l94 = alloca i32
  %l96 = alloca ptr
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %t116 = alloca { i64, [2 x i64] }, align 8
  %t134 = alloca { i64, [3 x i64] }, align 8
  %t179 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t1)
  store %"compiler/source:Span" %t3, ptr %l11
  br label %bb1
bb1:
  %t4 = load %"compiler/source:Span", ptr %l11
  store %"compiler/source:Span" %t4, ptr %l5
  br i1 %a2, label %bb2, label %bb3
bb2:
  %t7 = load ptr, ptr %l1, !tbaa !29
  store ptr %t7, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t8 = load ptr, ptr %l13, !tbaa !29
  %t9 = icmp ne ptr %t8, null
  br i1 %t9, label %bb4, label %bb5
bb3:
  br label %bb45
bb4:
  %t11 = load ptr, ptr %l13, !tbaa !29
  %t12 = load i64, ptr %t11, !range !{i64 0, i64 30}
  %t14 = icmp eq i64 %t12, 0
  store i1 %t14, ptr %l14, !tbaa !21
  br label %bb5
bb5:
  %t15 = load i1, ptr %l14, !tbaa !21
  br i1 %t15, label %bb6, label %bb7
bb6:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32 }, ptr %t18, i32 0, i32 0
  %t20 = load %"compiler/source:Span", ptr %t19
  store %"compiler/source:Span" %t20, ptr %l6
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [4 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", i32 }, ptr %t24, i32 0, i32 1
  %t26 = load i32, ptr %t25
  store i32 %t26, ptr %l7, !tbaa !23
  br label %bb8
bb7:
  br label %bb37
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l7, !tbaa !23
  %t32 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t28, i32 %t29)
  store { i64, ptr } %t32, ptr %l23
  br label %bb9
bb9:
  %t33 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t34 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t33, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) })
  store i1 %t34, ptr %l24
  br label %bb10
bb10:
  %t35 = load i1, ptr %l24, !tbaa !21
  br i1 %t35, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb12:
  br label %bb13
bb13:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t36)
  store ptr %t38, ptr %l26
  br label %bb14
bb14:
  %t39 = load ptr, ptr %l26, !tbaa !29
  %t41 = getelementptr %"compiler/check:frame", ptr %t39, i32 0, i32 41
  %t42 = load i32, ptr %l7, !tbaa !23
  %t45 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %t41, i32 %t42)
  store i1 %t45, ptr %l30
  br label %bb15
bb15:
  %t46 = load i1, ptr %l30, !tbaa !21
  br i1 %t46, label %bb16, label %bb17
bb16:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load i32, ptr %l4, !tbaa !23
  %t51 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunLength(ptr %v0, ptr %t47, i32 %t48)
  store i32 %t51, ptr %l34
  br label %bb18
bb17:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb19
bb18:
  %t52 = load i32, ptr %l4, !tbaa !23
  %t53 = load i32, ptr %l34, !tbaa !23
  %t55 = icmp ne i32 %t53, %t52
  store i1 %t55, ptr %l31, !tbaa !21
  br label %bb19
bb19:
  %t57 = load i1, ptr %l31, !tbaa !21
  br i1 %t57, label %bb20, label %bb21
bb20:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i32, ptr %l4, !tbaa !23
  %t62 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunLength(ptr %v0, ptr %t58, i32 %t59)
  store i32 %t62, ptr %l39
  br label %bb22
bb21:
  br label %bb23
bb22:
  %t63 = load i32, ptr %l39, !tbaa !23
  store i32 %t63, ptr %l4, !tbaa !23
  br label %bb23
bb23:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/check:Checker", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = getelementptr %"compiler/generic:Program", ptr %t67, i32 0, i32 2
  store ptr %t69, ptr %l42, !tbaa !29
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load i32, ptr %l4, !tbaa !23
  %t74 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t70, i32 %t71)
  store i32 %t74, ptr %l45
  br label %bb24
bb24:
  %t75 = load ptr, ptr %l42, !tbaa !29
  %t76 = load i32, ptr %l45, !tbaa !23
  %t77 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t75, i32 %t76)
  store i32 %t77, ptr %l46
  br label %bb25
bb25:
  %t78 = load i32, ptr %l46, !range !{i32 0, i32 33}
  %t80 = trunc i64 19 to i32
  %t81 = icmp eq i32 %t78, %t80
  br i1 %t81, label %bb26, label %bb27
bb26:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/check:Checker", ptr %t83, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = getelementptr %"compiler/generic:Program", ptr %t86, i32 0, i32 2
  store ptr %t88, ptr %l52, !tbaa !29
  %t89 = load i32, ptr %l4, !tbaa !23
  store i32 %t89, ptr %l53, !tbaa !23
  %t90 = load ptr, ptr %l3, !tbaa !29
  %t93 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t90)
  store i32 %t93, ptr %l56
  br label %bb28
bb27:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb30
bb28:
  %t94 = load ptr, ptr %l52, !tbaa !29
  %t95 = load i32, ptr %l53, !tbaa !23
  %t96 = load i32, ptr %l56, !tbaa !23
  %t97 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t94, i32 %t95, i32 %t96)
  store i1 %t97, ptr %l57
  br label %bb29
bb29:
  %t98 = load i1, ptr %l57, !tbaa !21
  %t99 = xor i1 %t98, true
  store i1 %t99, ptr %l49, !tbaa !21
  br label %bb30
bb30:
  %t101 = load i1, ptr %l49, !tbaa !21
  br i1 %t101, label %bb31, label %bb32
bb31:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load ptr, ptr %l3, !tbaa !29
  %t104 = load i32, ptr %l4, !tbaa !23
  %t105 = load %"compiler/source:Span", ptr %l6
  %t110 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v2, ptr %v2, ptr %t102, ptr %t103, i32 %t104, %"compiler/source:Span" %t105)
  store ptr %t110, ptr %l63
  br label %bb33
bb32:
  br label %bb34
bb33:
  %t111 = load ptr, ptr %l63, !tbaa !29
  store ptr %t111, ptr %l3, !tbaa !29
  br label %bb34
bb34:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load i32, ptr %l7, !tbaa !23
  %t114 = load %"compiler/source:Span", ptr %l6
  %t115 = load i32, ptr %l4, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t116
  %t117 = getelementptr { i64, [2 x i64] }, ptr %t116, i32 0, i32 0
  store i64 5, ptr %t117
  %t118 = load { i64, [2 x i64] }, ptr %t116
  %t125 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t112, i32 %t113, %"compiler/source:Span" %t114, i32 %t115, i32 1, { i64, [2 x i64] } %t118)
  store i64 %t125, ptr %l70
  br label %bb35
bb35:
  %t126 = load i64, ptr %l70, !tbaa !24
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load %"compiler/source:Span", ptr %l6
  %t131 = trunc i64 %t126 to i32
  %t133 = load ptr, ptr %l3, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t134
  %t135 = getelementptr { i64, [3 x i64] }, ptr %t134, i32 0, i32 0
  store i64 0, ptr %t135
  %t137 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t128, 0
  %t139 = insertvalue { %"compiler/source:Span", i32, ptr } %t137, i32 %t131, 1
  %t141 = insertvalue { %"compiler/source:Span", i32, ptr } %t139, ptr %t133, 2
  %t142 = getelementptr { i64, [3 x i64] }, ptr %t134, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t141, ptr %t142
  %t143 = load { i64, [3 x i64] }, ptr %t134
  %t145 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t143, ptr %t145
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t127, ptr %t145)
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s2)
  br label %bb44
bb37:
  br i1 true, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb43
bb40:
  store %olang.scope zeroinitializer, ptr %s6
  %t148 = load ptr, ptr %l0, !tbaa !29
  store ptr %t148, ptr %l79, !tbaa !29
  %t149 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t149, ptr %l80
  %t150 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestructNotName(ptr %s6)
  store %"compiler/msgs:Msg" %t150, ptr %l81
  br label %bb41
bb41:
  %t151 = load ptr, ptr %l79, !tbaa !29
  %t152 = load %"compiler/source:Span", ptr %l80
  %t153 = load %"compiler/msgs:Msg", ptr %l81
  %t154 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s6, ptr %t151, %"compiler/source:Span" %t152, %"compiler/msgs:Msg" %t153)
  store i64 %t154, ptr %l82
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s6)
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_fb06dcd16342dc9_94e70e479081575d)
  unreachable
bb44:
  br label %ret
bb45:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load ptr, ptr %l1, !tbaa !29
  %t159 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ediscardOr(ptr %v0, ptr %v1, ptr %v0, ptr %t155, ptr %t156)
  store ptr %t159, ptr %l85
  br label %bb46
bb46:
  %t160 = load ptr, ptr %l85, !tbaa !29
  store ptr %t160, ptr %l9, !tbaa !29
  %t161 = load ptr, ptr %l9, !tbaa !29
  %t163 = icmp eq ptr %t161, null
  br i1 %t163, label %bb47, label %bb48
bb47:
  br label %ret
bb48:
  br label %bb49
bb49:
  %t165 = load ptr, ptr %l0, !tbaa !29
  store ptr %t165, ptr %l88, !tbaa !29
  %t166 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t166, ptr %l89
  %t167 = load ptr, ptr %l9, !tbaa !29
  store ptr %t167, ptr %l90, !tbaa !29
  %t168 = load ptr, ptr %l0, !tbaa !29
  store ptr %t168, ptr %l91, !tbaa !29
  %t169 = load ptr, ptr %l3, !tbaa !29
  store ptr %t169, ptr %l92, !tbaa !29
  %t170 = load ptr, ptr %l9, !tbaa !29
  %t172 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %t170)
  store i32 %t172, ptr %l94
  br label %bb50
bb50:
  %t173 = load %"compiler/source:Span", ptr %l5
  %t174 = load ptr, ptr %l91, !tbaa !29
  %t175 = load ptr, ptr %l92, !tbaa !29
  %t176 = load i32, ptr %l94, !tbaa !23
  %t178 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v2, ptr %v0, ptr %t174, ptr %t175, i32 %t176, %"compiler/source:Span" %t173)
  store ptr %t178, ptr %l96
  br label %bb51
bb51:
  store { i64, [3 x i64] } zeroinitializer, ptr %t179
  %t180 = getelementptr { i64, [3 x i64] }, ptr %t179, i32 0, i32 0
  store i64 1, ptr %t180
  %t181 = load %"compiler/source:Span", ptr %l89
  %t182 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t181, 0
  %t183 = load ptr, ptr %l90, !tbaa !29
  %t184 = insertvalue { %"compiler/source:Span", ptr, ptr } %t182, ptr %t183, 1
  %t185 = load ptr, ptr %l96, !tbaa !29
  %t186 = insertvalue { %"compiler/source:Span", ptr, ptr } %t184, ptr %t185, 2
  %t187 = getelementptr { i64, [3 x i64] }, ptr %t179, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t186, ptr %t187
  %t188 = load { i64, [3 x i64] }, ptr %t179
  %t190 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t188, ptr %t190
  %t191 = load ptr, ptr %l88, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t191, ptr %t190)
  br label %bb52
bb52:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereachesTrait(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l14 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l29 = alloca i32
  %l37 = alloca i32
  %l46 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t3 = icmp sgt i64 %t1, 32
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t13 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtended(ptr %v0, ptr %s2, ptr %t9, i32 %a2)
  store { i64, ptr } %t13, ptr %l14
  br label %bb4
bb4:
  %t14 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t14, 0
  %t16 = extractvalue { i64, ptr } %t14, 1
  %t17 = mul i64 %t15, 4
  %t18 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t16, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t22 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t22, 0
  store i64 %t24, ptr %l6, !tbaa !24
  br label %bb5
bb5:
  %t26 = load i64, ptr %l5, !tbaa !24
  %t27 = load i64, ptr %l6, !tbaa !24
  %t30 = icmp slt i64 %t26, %t27
  %t32 = xor i1 %t30, true
  br i1 %t32, label %bb6, label %bb7
bb6:
  br label %bb22
bb7:
  br label %bb8
bb8:
  %t34 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t34, ptr %l22, !tbaa !27
  %t35 = load i64, ptr %l5, !tbaa !24
  %t37 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = getelementptr i32, ptr %t38, i64 %t35
  %t40 = load i32, ptr %t39, !tbaa !33
  store i32 %t40, ptr %l7, !tbaa !23
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/check:Checker", ptr %t42, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t47 = getelementptr %"compiler/generic:Program", ptr %t45, i32 0, i32 2
  %t48 = load i32, ptr %l7, !tbaa !23
  %t51 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t47, i32 %t48)
  store i32 %t51, ptr %l29
  br label %bb9
bb9:
  %t52 = load i32, ptr %l29, !range !{i32 0, i32 33}
  %t54 = trunc i64 18 to i32
  %t55 = icmp eq i32 %t52, %t54
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb10, label %bb11
bb10:
  br label %bb21
bb11:
  br label %bb12
bb12:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Program", ptr %t62, i32 0, i32 2
  %t65 = load i32, ptr %l7, !tbaa !23
  %t68 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t64, i32 %t65)
  store i32 %t68, ptr %l37
  br label %bb13
bb13:
  %t69 = load i32, ptr %l1, !tbaa !23
  %t70 = load i32, ptr %l37, !tbaa !23
  %t72 = icmp eq i32 %t70, %t69
  br i1 %t72, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load i32, ptr %l1, !tbaa !23
  %t77 = load i32, ptr %l7, !tbaa !23
  %t78 = load i64, ptr %l3, !tbaa !24
  %t80 = add i64 %t78, 1
  %t85 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereachesTrait(ptr %v0, ptr %t75, i32 %t76, i32 %t77, i64 %t80)
  store i1 %t85, ptr %l46
  br label %bb17
bb17:
  %t86 = load i1, ptr %l46, !tbaa !21
  br i1 %t86, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t88 = load i64, ptr %l5, !tbaa !24
  %t90 = add i64 %t88, 1
  store i64 %t90, ptr %l5, !tbaa !24
  br label %bb5
bb22:
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflTextOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %lp6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i1
  %l23 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca { i64, ptr }
  %l28 = alloca ptr
  %l29 = alloca i1
  %l34 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l38 = alloca i32
  %l40 = alloca ptr
  %l41 = alloca i1
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l49 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l65 = alloca i32
  %l67 = alloca { i64, ptr }
  %l69 = alloca i64
  %s6 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t2 = load ptr, ptr %l11, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l11, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l12, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l12, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32 }, ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19, !range !{i32 0, i32 98}
  store i32 %t20, ptr %l3
  br label %bb5
bb4:
  br label %bb10
bb5:
  %t22 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t24 = trunc i64 5 to i32
  %t25 = icmp eq i32 %t22, %t24
  br i1 %t25, label %bb6, label %bb7
bb6:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load %"compiler/source:Span", ptr %l2
  %t31 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estrBytes(ptr %v0, ptr %v2, ptr %t27, %"compiler/source:Span" %t28)
  store { i64, ptr } %t31, ptr %l23
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t32 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t32, ptr %l25, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t34, 0
  store i64 %t35, ptr %l26, !tbaa !24
  %t36 = load i64, ptr %l26, !tbaa !24
  %t37 = mul i64 %t36, 1
  %t38 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t37)
  %t39 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  store { i64, ptr } %t40, ptr %l27, !tbaa !27
  %t41 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = load i64, ptr %l26, !tbaa !24
  %t46 = mul i64 %t45, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t42, ptr %t44, i64 %t46, i1 false)
  %t47 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t47, ptr %l25, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t49 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t48, 1
  store { i32, { i64, ptr } } %t49, ptr %rv
  br label %ret
bb9:
  br label %bb42
bb10:
  %t50 = load ptr, ptr %l1, !tbaa !29
  store ptr %t50, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t51 = load ptr, ptr %l28, !tbaa !29
  %t52 = icmp ne ptr %t51, null
  br i1 %t52, label %bb11, label %bb12
bb11:
  %t54 = load ptr, ptr %l28, !tbaa !29
  %t55 = load i64, ptr %t54, !range !{i64 0, i64 30}
  %t57 = icmp eq i64 %t55, 2
  store i1 %t57, ptr %l29, !tbaa !21
  br label %bb12
bb12:
  %t58 = load i1, ptr %l29, !tbaa !21
  br i1 %t58, label %bb13, label %bb14
bb13:
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr { i64, [4 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { %"compiler/source:Span", ptr }, ptr %t61, i32 0, i32 1
  %t63 = load ptr, ptr %t62
  store ptr %t63, ptr %l4, !tbaa !29
  br label %bb15
bb14:
  br label %bb19
bb15:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load ptr, ptr %l4, !tbaa !29
  %t69 = call { i32, { i64, ptr } } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflTextOf(ptr %v0, ptr %v1, ptr %v2, ptr %t65, ptr %t66)
  %t70 = extractvalue { i32, { i64, ptr } } %t69, 1
  %t71 = extractvalue { i32, { i64, ptr } } %t69, 0
  store i32 %t71, ptr %l38
  %t72 = icmp ne i32 %t71, 0
  br i1 %t72, label %bb17, label %ok.73, !prof !99
ok.73:
  store { i64, ptr } %t70, ptr %l37
  br label %bb16
bb16:
  %t74 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t74, ptr %l34, !tbaa !27
  br label %bb18
bb17:
  %t75 = load i32, ptr %l38, !tbaa !23
  %t76 = lshr i32 %t75, 16
  %t77 = and i32 %t75, 65535
  %t78 = icmp eq i32 %t76, 1
  %t79 = select i1 %t78, i32 1, i32 0
  %t80 = icmp eq i32 %t75, 0
  %t81 = shl i32 %t79, 16
  %t82 = or i32 %t81, %t77
  %t83 = select i1 %t80, i32 0, i32 %t82
  %t85 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t83, 0
  store { i32, { i64, ptr } } %t85, ptr %rv
  br label %ret
bb18:
  %t86 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t87 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t86, 1
  store { i32, { i64, ptr } } %t87, ptr %rv
  br label %ret
bb19:
  %t88 = load ptr, ptr %l1, !tbaa !29
  store ptr %t88, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t89 = load ptr, ptr %l40, !tbaa !29
  %t90 = icmp ne ptr %t89, null
  br i1 %t90, label %bb20, label %bb21
bb20:
  %t92 = load ptr, ptr %l40, !tbaa !29
  %t93 = load i64, ptr %t92, !range !{i64 0, i64 30}
  %t95 = icmp eq i64 %t93, 20
  store i1 %t95, ptr %l41, !tbaa !21
  br label %bb21
bb21:
  %t96 = load i1, ptr %l41, !tbaa !21
  br i1 %t96, label %bb22, label %bb23
bb22:
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t99 = getelementptr { i64, [4 x i64] }, ptr %t97, i32 0, i32 1
  %t100 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t99, i32 0, i32 1
  %t101 = load { i64, ptr }, ptr %t100
  store { i64, ptr } %t101, ptr %l5, !tbaa !27
  br label %bb24
bb23:
  br label %bb37
bb24:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d16, i32 0, i32 1) }, ptr %l46, !tbaa !27
  %t103 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t103, ptr %l47, !tbaa !27
  %t104 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t104, 0
  store i64 %t105, ptr %l48, !tbaa !24
  %t106 = load i64, ptr %l48, !tbaa !24
  %t107 = mul i64 %t106, 1
  %t108 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t107)
  %t109 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t108, 1
  store { i64, ptr } %t110, ptr %l49, !tbaa !27
  %t111 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = load i64, ptr %l48, !tbaa !24
  %t116 = mul i64 %t115, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t112, ptr %t114, i64 %t116, i1 false)
  %t117 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t117, ptr %lp6
  %t118 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t119 = load ptr, ptr %lp6
  store { i64, ptr } %t118, ptr %t119, !tbaa !27
  %t120 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t120, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t122 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t122, 0
  store i64 %t124, ptr %l9, !tbaa !24
  br label %bb25
bb25:
  store %olang.scope zeroinitializer, ptr %s6
  %t126 = load i64, ptr %l8, !tbaa !24
  %t127 = load i64, ptr %l9, !tbaa !24
  %t130 = icmp slt i64 %t126, %t127
  %t132 = xor i1 %t130, true
  br i1 %t132, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s6)
  br label %bb36
bb27:
  br label %bb28
bb28:
  %t134 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t134, ptr %l57, !tbaa !27
  %t135 = load i64, ptr %l8, !tbaa !24
  %t137 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr ptr, ptr %t138, i64 %t135
  %t140 = load ptr, ptr %t139, !tbaa !39
  %t142 = load ptr, ptr %lp6
  %t143 = load { i64, ptr }, ptr %t142, !tbaa !27
  store { i64, ptr } %t143, ptr %l60, !tbaa !27
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t148 = call { i32, { i64, ptr } } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflPiece(ptr %v0, ptr %v1, ptr %s6, ptr %t144, ptr %t140)
  %t149 = extractvalue { i32, { i64, ptr } } %t148, 1
  %t150 = extractvalue { i32, { i64, ptr } } %t148, 0
  store i32 %t150, ptr %l65
  %t151 = icmp ne i32 %t150, 0
  br i1 %t151, label %bb30, label %ok.152, !prof !99
ok.152:
  store { i64, ptr } %t149, ptr %l64
  br label %bb29
bb29:
  %t153 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t153, ptr %l61, !tbaa !27
  br label %bb31
bb30:
  %t154 = load i32, ptr %l65, !tbaa !23
  %t155 = lshr i32 %t154, 16
  %t156 = and i32 %t154, 65535
  %t157 = icmp eq i32 %t155, 1
  %t158 = select i1 %t157, i32 1, i32 0
  %t159 = icmp eq i32 %t154, 0
  %t160 = shl i32 %t158, 16
  %t161 = or i32 %t160, %t156
  %t162 = select i1 %t159, i32 0, i32 %t161
  call void @__olang_scope_close(ptr %s6)
  %t164 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t162, 0
  store { i32, { i64, ptr } } %t164, ptr %rv
  br label %ret
bb31:
  %t165 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t166 = extractvalue { i64, ptr } %t165, 1
  %t167 = extractvalue { i64, ptr } %t165, 0
  %t168 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t168, 1
  %t170 = extractvalue { i64, ptr } %t168, 0
  %t171 = add i64 %t167, %t170
  %t172 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t171)
  call void @olang_textcopy(ptr %t172, ptr %t166, i64 %t167)
  %t173 = getelementptr i8, ptr %t172, i64 %t167
  call void @olang_textcopy(ptr %t173, ptr %t169, i64 %t170)
  %t174 = insertvalue { i64, ptr } undef, i64 %t171, 0
  %t175 = insertvalue { i64, ptr } %t174, ptr %t172, 1
  store { i64, ptr } %t175, ptr %l67, !tbaa !27
  %t176 = load ptr, ptr %lp6
  %t177 = load { i64, ptr }, ptr %t176, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t177, 0
  %t179 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t180 = extractvalue { i64, ptr } %t179, 0
  store i64 %t180, ptr %l69, !tbaa !24
  %t182 = load i64, ptr %l69, !tbaa !24
  %t183 = icmp eq i64 %t178, %t182
  br i1 %t183, label %bb32, label %bb33
bb32:
  %t185 = load ptr, ptr %lp6
  %t186 = getelementptr { i64, ptr }, ptr %t185, i32 0, i32 1
  %t187 = load ptr, ptr %t186, !tbaa !27
  %t188 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t189 = load ptr, ptr %t188, !tbaa !27
  %t190 = load i64, ptr %l69, !tbaa !24
  %t191 = mul i64 %t190, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t187, ptr %t189, i64 %t191, i1 false)
  br label %bb34
bb33:
  %t192 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t193 = load ptr, ptr %lp6
  store { i64, ptr } %t192, ptr %t193, !tbaa !27
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s6)
  br label %bb35
bb35:
  %t194 = load i64, ptr %l8, !tbaa !24
  %t196 = add i64 %t194, 1
  store i64 %t196, ptr %l8, !tbaa !24
  br label %bb25
bb36:
  %t198 = load ptr, ptr %lp6
  %t199 = load { i64, ptr }, ptr %t198, !tbaa !27
  %t201 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t199, 1
  store { i32, { i64, ptr } } %t201, ptr %rv
  br label %ret
bb37:
  br i1 true, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_3ff8b815b8f08888_72cba32f0bfc98b4)
  unreachable
bb42:
  %t203 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t203, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erenderPiece(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %lp3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca { i64, [2 x i64] }
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %lp9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %lp16 = alloca ptr
  %l17 = alloca i32
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca i1
  %l38 = alloca ptr
  %l48 = alloca { i64, ptr }
  %l50 = alloca i64
  %l58 = alloca i64
  %l61 = alloca i64
  %l89 = alloca ptr
  %l92 = alloca i32
  %l96 = alloca i1
  %l101 = alloca i32
  %l104 = alloca i1
  %l109 = alloca i32
  %l112 = alloca %"compiler/source:Span"
  %l118 = alloca i32
  %l127 = alloca i1
  %l132 = alloca i1
  %l135 = alloca ptr
  %s3 = alloca %olang.scope
  %rv = alloca ptr
  %t160 = alloca { i64, [2 x i64] }, align 8
  %t237 = alloca { i64, [5 x i64] }, align 8
  %t249 = alloca { i64, [2 x i64] }, align 8
  %t283 = alloca { i64, [2 x i64] }, align 8
  %t294 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t7 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erendered(ptr %v0, ptr %v1, ptr %v2, ptr %t1, %"compiler/source:Span" %a1, ptr %a2)
  store ptr %t7, ptr %l21
  br label %bb1
bb1:
  %t8 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store ptr %t8, ptr %lp3
  %t9 = load ptr, ptr %l21, !tbaa !29
  %t10 = load ptr, ptr %lp3
  store ptr %t9, ptr %t10, !tbaa !29
  %t11 = load ptr, ptr %lp3
  %t12 = load ptr, ptr %t11, !tbaa !29
  store ptr %t12, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t13 = load ptr, ptr %l22, !tbaa !29
  %t14 = icmp ne ptr %t13, null
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load ptr, ptr %l22, !tbaa !29
  %t17 = load i64, ptr %t16, !range !{i64 0, i64 18}
  %t19 = icmp eq i64 %t17, 15
  store i1 %t19, ptr %l23, !tbaa !21
  br label %bb3
bb3:
  %t20 = load i1, ptr %l23, !tbaa !21
  br i1 %t20, label %bb4, label %bb5
bb4:
  %t21 = load ptr, ptr %lp3
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr { i64, [5 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t24, i32 0, i32 2
  %t26 = load ptr, ptr %t25
  store ptr %t26, ptr %l4, !tbaa !29
  br label %bb6
bb5:
  br label %bb43
bb6:
  %t28 = load ptr, ptr %l4, !tbaa !29
  store ptr %t28, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t29 = load ptr, ptr %l28, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb7, label %bb8
bb7:
  %t32 = load ptr, ptr %l28, !tbaa !29
  %t33 = load i64, ptr %t32, !range !{i64 0, i64 3}
  %t35 = icmp eq i64 %t33, 0
  store i1 %t35, ptr %l29, !tbaa !21
  br label %bb8
bb8:
  %t36 = load i1, ptr %l29, !tbaa !21
  br i1 %t36, label %bb9, label %bb10
bb9:
  %t37 = load ptr, ptr %l4, !tbaa !29
  %t39 = getelementptr { i64, [4 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { i32 }, ptr %t39, i32 0, i32 0
  %t41 = load i32, ptr %t40
  store i32 %t41, ptr %l5, !tbaa !23
  br label %bb11
bb10:
  br label %bb37
bb11:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 14
  %t46 = load i32, ptr %l5, !tbaa !23
  %t48 = sext i32 %t46 to i64
  %t51 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t45, i64 %t48)
  store ptr %t51, ptr %l38
  br label %bb12
bb12:
  %t52 = load ptr, ptr %l38, !tbaa !29
  %t54 = getelementptr %"compiler/typed:Body", ptr %t52, i32 0, i32 1
  %t55 = load { i64, [2 x i64] }, ptr %t54
  store { i64, [2 x i64] } %t55, ptr %l6
  %t57 = load { i64, [2 x i64] }, ptr %l6
  %t59 = extractvalue { i64, [2 x i64] } %t57, 0
  %t60 = icmp eq i64 %t59, 0
  br i1 %t60, label %bb13, label %bb14
bb13:
  %t62 = getelementptr { i64, [2 x i64] }, ptr %l6, i32 0, i32 1
  %t63 = getelementptr { i64 }, ptr %t62, i32 0, i32 0
  %t64 = load i64, ptr %t63
  store i64 %t64, ptr %l7, !tbaa !24
  br label %bb15
bb14:
  br label %bb31
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load i64, ptr %l7, !tbaa !24
  %t68 = load i32, ptr %l5, !tbaa !23
  %t70 = sext i32 %t68 to i64
  %t74 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esigText(ptr %v0, ptr %s3, ptr %t66, i64 %t67, i64 %t70)
  store { i64, ptr } %t74, ptr %l48
  br label %bb16
bb16:
  %t75 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t75, ptr %l8, !tbaa !27
  %t76 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t76, 0
  store i64 %t78, ptr %l50, !tbaa !24
  %t79 = load i64, ptr %l50, !tbaa !24
  %t80 = icmp sge i64 %t79, 0
  br i1 %t80, label %bb17, label %bb18
bb17:
  %t82 = load i64, ptr %l50, !tbaa !24
  %t83 = mul i64 %t82, 1
  %t84 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t83)
  %t85 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t84, 1
  %t87 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t87, ptr %lp9
  %t89 = load ptr, ptr %lp9
  store { i64, ptr } %t86, ptr %t89, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t90 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t90, 0
  store i64 %t92, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t94 = load i64, ptr %l11, !tbaa !24
  %t95 = load i64, ptr %l10, !tbaa !24
  %t98 = icmp sgt i64 %t94, %t95
  br i1 %t98, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_db1f2ae5e4bef7a4_1fc823cb35fb1540)
  unreachable
bb19:
  %t100 = load i64, ptr %l12, !tbaa !24
  %t102 = icmp sgt i64 %t100, 0
  br i1 %t102, label %bb21, label %bb22
bb20:
  store i64 0, ptr %l58, !tbaa !24
  br label %bb24
bb21:
  %t104 = load i64, ptr %l11, !tbaa !24
  %t105 = load i64, ptr %l10, !tbaa !24
  %t108 = sub i64 %t104, %t105
  %t109 = load i64, ptr %l12, !tbaa !24
  %t112 = add i64 %t108, %t109
  %t114 = sub i64 %t112, 1
  %t115 = load i64, ptr %l12, !tbaa !24
  %t118 = sdiv i64 %t114, %t115
  store i64 %t118, ptr %l61, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb23
bb23:
  %t120 = load i64, ptr %l61, !tbaa !24
  store i64 %t120, ptr %l58, !tbaa !24
  br label %bb24
bb24:
  %t121 = load i64, ptr %l58, !tbaa !24
  store i64 %t121, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb25
bb25:
  %t122 = load i64, ptr %l14, !tbaa !24
  %t123 = load i64, ptr %l13, !tbaa !24
  %t126 = icmp slt i64 %t122, %t123
  %t128 = xor i1 %t126, true
  br i1 %t128, label %bb26, label %bb27
bb26:
  br label %bb30
bb27:
  br label %bb28
bb28:
  %t130 = load i64, ptr %l10, !tbaa !24
  %t131 = load i64, ptr %l14, !tbaa !24
  %t132 = load i64, ptr %l12, !tbaa !24
  %t135 = mul i64 %t131, %t132
  %t138 = add i64 %t130, %t135
  store i64 %t138, ptr %l15, !tbaa !24
  %t140 = load i64, ptr %l15, !tbaa !24
  %t141 = load i64, ptr %l15, !tbaa !24
  %t143 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !27
  %t145 = getelementptr i8, ptr %t144, i64 %t141
  %t146 = load i8, ptr %t145, !tbaa !32
  %t149 = load ptr, ptr %lp9
  %t151 = getelementptr { i64, ptr }, ptr %t149, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = getelementptr i8, ptr %t152, i64 %t140
  store i8 %t146, ptr %t153, !tbaa !32
  br label %bb29
bb29:
  %t154 = load i64, ptr %l14, !tbaa !24
  %t156 = add i64 %t154, 1
  store i64 %t156, ptr %l14, !tbaa !24
  br label %bb25
bb30:
  %t158 = load ptr, ptr %lp9
  %t159 = load { i64, ptr }, ptr %t158, !tbaa !27
  store { i64, [2 x i64] } zeroinitializer, ptr %t160
  %t161 = getelementptr { i64, [2 x i64] }, ptr %t160, i32 0, i32 0
  store i64 0, ptr %t161
  %t163 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t159, 0
  %t164 = getelementptr { i64, [2 x i64] }, ptr %t160, i32 0, i32 1
  store { { i64, ptr } } %t163, ptr %t164
  %t165 = load { i64, [2 x i64] }, ptr %t160
  %t167 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 24, i64 8)
  store { i64, [2 x i64] } %t165, ptr %t167
  call void @__olang_scope_close(ptr %s3)
  store ptr %t167, ptr %rv
  br label %ret
bb31:
  br i1 true, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_404270212748a64a_94da604f2263273e)
  unreachable
bb36:
  br label %bb42
bb37:
  br i1 true, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_e2c214b199db46e1_ccde8582cd2310f5)
  unreachable
bb42:
  br label %bb48
bb43:
  br i1 true, label %bb44, label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  call void @__olang_check_failed(ptr @olang_loc_2d29d2076870b150_9b91c954cc3aa504)
  unreachable
bb48:
  %t169 = load ptr, ptr %lp3
  %t170 = load ptr, ptr %t169, !tbaa !29
  %t172 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v2, ptr %v2, ptr %t170)
  store ptr %t172, ptr %l89
  br label %bb49
bb49:
  %t173 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store ptr %t173, ptr %lp16
  %t174 = load ptr, ptr %l89, !tbaa !29
  %t175 = load ptr, ptr %lp16
  store ptr %t174, ptr %t175, !tbaa !29
  %t176 = load ptr, ptr %lp3
  %t177 = load ptr, ptr %t176, !tbaa !29
  %t180 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t177)
  store i32 %t180, ptr %l92
  br label %bb50
bb50:
  %t181 = load i32, ptr %l92, !tbaa !23
  store i32 %t181, ptr %l17, !tbaa !23
  %t182 = load ptr, ptr %lp16
  %t183 = load ptr, ptr %t182, !tbaa !29
  %t185 = icmp eq ptr %t183, null
  %t187 = xor i1 %t185, true
  br i1 %t187, label %bb51, label %bb52
bb51:
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"compiler/check:Checker", ptr %t189, i32 0, i32 1
  %t192 = load ptr, ptr %t191, !tbaa !29
  %t194 = getelementptr %"compiler/generic:Program", ptr %t192, i32 0, i32 2
  %t195 = load i32, ptr %l17, !tbaa !23
  %t198 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t194, i32 %t195)
  store i32 %t198, ptr %l101
  br label %bb53
bb52:
  store i1 false, ptr %l96, !tbaa !21
  br label %bb54
bb53:
  %t199 = load i32, ptr %l101, !range !{i32 0, i32 33}
  %t201 = trunc i64 19 to i32
  %t202 = icmp eq i32 %t199, %t201
  store i1 %t202, ptr %l96, !tbaa !21
  br label %bb54
bb54:
  %t204 = load i1, ptr %l96, !tbaa !21
  br i1 %t204, label %bb55, label %bb56
bb55:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr %"compiler/check:Checker", ptr %t205, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !29
  %t210 = getelementptr %"compiler/generic:Program", ptr %t208, i32 0, i32 2
  %t211 = load i32, ptr %l17, !tbaa !23
  %t214 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t210, i32 %t211)
  store i32 %t214, ptr %l109
  br label %bb57
bb56:
  store i1 false, ptr %l104, !tbaa !21
  br label %bb58
bb57:
  %t215 = load i32, ptr %l109, !tbaa !23
  %t216 = icmp ne i32 %t215, 0
  store i1 %t216, ptr %l104, !tbaa !21
  br label %bb58
bb58:
  %t218 = load i1, ptr %l104, !tbaa !21
  br i1 %t218, label %bb59, label %bb60
bb59:
  %t219 = load ptr, ptr %lp3
  %t220 = load ptr, ptr %t219, !tbaa !29
  %t222 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v2, ptr %t220)
  store %"compiler/source:Span" %t222, ptr %l112
  br label %bb61
bb60:
  br label %bb63
bb61:
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t225 = getelementptr %"compiler/check:Checker", ptr %t223, i32 0, i32 1
  %t226 = load ptr, ptr %t225, !tbaa !29
  %t228 = getelementptr %"compiler/generic:Program", ptr %t226, i32 0, i32 2
  %t229 = load i32, ptr %l17, !tbaa !23
  %t230 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t234 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t228, i32 %t229, i64 %t230)
  store i32 %t234, ptr %l118
  br label %bb62
bb62:
  %t235 = load ptr, ptr %lp16
  %t236 = load ptr, ptr %t235, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t237
  %t238 = getelementptr { i64, [5 x i64] }, ptr %t237, i32 0, i32 0
  store i64 3, ptr %t238
  %t239 = load %"compiler/source:Span", ptr %l112
  %t240 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t239, 0
  %t241 = load i32, ptr %l118, !tbaa !23
  %t242 = insertvalue { %"compiler/source:Span", i32, ptr } %t240, i32 %t241, 1
  %t244 = insertvalue { %"compiler/source:Span", i32, ptr } %t242, ptr %t236, 2
  %t245 = getelementptr { i64, [5 x i64] }, ptr %t237, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t244, ptr %t245
  %t246 = load { i64, [5 x i64] }, ptr %t237
  %t248 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t246, ptr %t248
  store { i64, [2 x i64] } zeroinitializer, ptr %t249
  %t250 = getelementptr { i64, [2 x i64] }, ptr %t249, i32 0, i32 0
  store i64 1, ptr %t250
  %t252 = insertvalue { ptr } undef, ptr %t248, 0
  %t253 = getelementptr { i64, [2 x i64] }, ptr %t249, i32 0, i32 1
  store { ptr } %t252, ptr %t253
  %t254 = load { i64, [2 x i64] }, ptr %t249
  %t256 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 24, i64 8)
  store { i64, [2 x i64] } %t254, ptr %t256
  store ptr %t256, ptr %rv
  br label %ret
bb63:
  %t258 = load ptr, ptr %lp16
  %t259 = load ptr, ptr %t258, !tbaa !29
  %t261 = icmp eq ptr %t259, null
  %t263 = xor i1 %t261, true
  br i1 %t263, label %bb64, label %bb65
bb64:
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t267 = getelementptr %"compiler/check:Checker", ptr %t265, i32 0, i32 1
  %t268 = load ptr, ptr %t267, !tbaa !29
  %t270 = getelementptr %"compiler/generic:Program", ptr %t268, i32 0, i32 2
  %t271 = load i32, ptr %l17, !tbaa !23
  %t274 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnsParts(ptr %v0, ptr %t270, i32 %t271)
  store i1 %t274, ptr %l132
  br label %bb66
bb65:
  store i1 false, ptr %l127, !tbaa !21
  br label %bb67
bb66:
  %t275 = load i1, ptr %l132, !tbaa !21
  store i1 %t275, ptr %l127, !tbaa !21
  br label %bb67
bb67:
  %t276 = load i1, ptr %l127, !tbaa !21
  br i1 %t276, label %bb68, label %bb69
bb68:
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t278 = load ptr, ptr %lp3
  %t279 = load ptr, ptr %t278, !tbaa !29
  %t282 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eownCopy(ptr %v0, ptr %v2, ptr %v2, ptr %t277, ptr %t279)
  store ptr %t282, ptr %l135
  br label %bb70
bb69:
  br label %bb71
bb70:
  store { i64, [2 x i64] } zeroinitializer, ptr %t283
  %t284 = getelementptr { i64, [2 x i64] }, ptr %t283, i32 0, i32 0
  store i64 1, ptr %t284
  %t285 = load ptr, ptr %l135, !tbaa !29
  %t286 = insertvalue { ptr } undef, ptr %t285, 0
  %t287 = getelementptr { i64, [2 x i64] }, ptr %t283, i32 0, i32 1
  store { ptr } %t286, ptr %t287
  %t288 = load { i64, [2 x i64] }, ptr %t283
  %t290 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 24, i64 8)
  store { i64, [2 x i64] } %t288, ptr %t290
  store ptr %t290, ptr %rv
  br label %ret
bb71:
  %t292 = load ptr, ptr %lp3
  %t293 = load ptr, ptr %t292, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t294
  %t295 = getelementptr { i64, [2 x i64] }, ptr %t294, i32 0, i32 0
  store i64 1, ptr %t295
  %t297 = insertvalue { ptr } undef, ptr %t293, 0
  %t298 = getelementptr { i64, [2 x i64] }, ptr %t294, i32 0, i32 1
  store { ptr } %t297, ptr %t298
  %t299 = load { i64, [2 x i64] }, ptr %t294
  %t301 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 24, i64 8)
  store { i64, [2 x i64] } %t299, ptr %t301
  store ptr %t301, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCallRef(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l5 = alloca i64
  %l8 = alloca i1
  %l14 = alloca i1
  %l17 = alloca { i64, ptr }
  %l21 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroBorrowedFrom(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sge i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load i64, ptr %l2, !tbaa !24
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Call", ptr %t12, i32 0, i32 1
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t20 = icmp slt i64 %t11, %t17
  store i1 %t20, ptr %l8, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb4
bb4:
  %t22 = load i1, ptr %l8, !tbaa !21
  br i1 %t22, label %bb5, label %bb6
bb5:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Call", ptr %t24, i32 0, i32 1
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  store { i64, ptr } %t27, ptr %l17, !tbaa !27
  %t28 = load i64, ptr %l2, !tbaa !24
  %t30 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr ptr, ptr %t31, i64 %t28
  %t33 = load ptr, ptr %t32, !tbaa !39
  %t37 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRef(ptr %v0, ptr %v1, ptr %t23, ptr %t33)
  store i1 %t37, ptr %l21
  br label %bb7
bb6:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb8
bb7:
  %t38 = load i1, ptr %l21, !tbaa !21
  store i1 %t38, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t39 = load i1, ptr %l14, !tbaa !21
  store i1 %t39, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRefResult(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca ptr
  %l7 = alloca ptr
  %l10 = alloca i1
  %l13 = alloca ptr
  %l15 = alloca ptr
  %l19 = alloca %"std/pair:Pair.1eb2466213689e002f25e81e83536e78"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb5
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t6)
  store ptr %t8, ptr %l7
  br label %bb3
bb3:
  %t9 = load ptr, ptr %l7, !tbaa !29
  %t11 = getelementptr %"compiler/check:frame", ptr %t9, i32 0, i32 0
  %t12 = load i64, ptr %t11, !tbaa !24
  %t13 = load ptr, ptr %l5, !tbaa !29
  %t15 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceBody(ptr %v0, ptr %t13, i64 %t12)
  store i1 %t15, ptr %l10
  br label %bb4
bb4:
  %t16 = load i1, ptr %l10, !tbaa !21
  %t17 = xor i1 %t16, true
  store i1 %t17, ptr %l4, !tbaa !21
  br label %bb5
bb5:
  %t19 = load i1, ptr %l4, !tbaa !21
  br i1 %t19, label %bb6, label %bb7
bb6:
  br label %ret
bb7:
  br label %bb8
bb8:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 75
  store ptr %t22, ptr %l13, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t23)
  store ptr %t25, ptr %l15
  br label %bb9
bb9:
  %t26 = load ptr, ptr %l15, !tbaa !29
  %t28 = getelementptr %"compiler/check:frame", ptr %t26, i32 0, i32 0
  %t29 = load i64, ptr %t28, !tbaa !24
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t33 = call %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" @std_2fpair_3aPair_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_2ector(ptr %v1, ptr %v0, i64 %t29, ptr %t30)
  store %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" %t33, ptr %l19
  br label %bb10
bb10:
  %t34 = load ptr, ptr %l13, !tbaa !29
  %t35 = load %"std/pair:Pair.1eb2466213689e002f25e81e83536e78", ptr %l19
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H316d0dfdbceeb7b188a6719f0ad8fbbe(ptr %v0, ptr %v0, ptr %t34, %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" %t35)
  br label %bb11
bb11:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroSettleResults(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca %"std/pair:Pair.1eb2466213689e002f25e81e83536e78"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca ptr
  %l7 = alloca i64
  %l11 = alloca i64
  %l13 = alloca i64
  %l18 = alloca %"std/pair:Pair.1eb2466213689e002f25e81e83536e78"
  %l22 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l28 = alloca i64
  %l30 = alloca i64
  %l35 = alloca i64
  %l37 = alloca ptr
  %l40 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 75
  store ptr %t3, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load i64, ptr %l3, !tbaa !24
  store i64 %t5, ptr %l11, !tbaa !24
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H48754b4fa56ee3a8c3b855086bca91dc(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l13
  br label %bb2
bb2:
  %t9 = load i64, ptr %l11, !tbaa !24
  %t10 = load i64, ptr %l13, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb23
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = call %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H015c7298d54f1d140374736283ef15ae(ptr %v0, ptr %v0, ptr %t15, i64 %t16)
  store %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" %t19, ptr %l18
  br label %bb6
bb6:
  %t20 = load %"std/pair:Pair.1eb2466213689e002f25e81e83536e78", ptr %l18
  store %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" %t20, ptr %l4
  %t21 = getelementptr %"std/pair:Pair.1eb2466213689e002f25e81e83536e78", ptr %l4, i32 0, i32 0
  %t22 = load i64, ptr %t21, !tbaa !24
  %t23 = load i64, ptr %l1, !tbaa !24
  %t26 = icmp ne i64 %t22, %t23
  br i1 %t26, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb8:
  br label %bb9
bb9:
  %t28 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t28, ptr %l22
  br label %bb10
bb10:
  %t29 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l22
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t29, ptr %l5
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load i64, ptr %l1, !tbaa !24
  %t32 = getelementptr %"std/pair:Pair.1eb2466213689e002f25e81e83536e78", ptr %l4, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroDeep(ptr %v0, ptr %v0, ptr %s2, ptr %t30, i64 %t31, ptr %t33, ptr %l5)
  br label %bb11
bb11:
  store ptr %l5, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s5
  %t39 = load i64, ptr %l7, !tbaa !24
  store i64 %t39, ptr %l28, !tbaa !24
  %t40 = load ptr, ptr %l6, !tbaa !29
  %t42 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s2, ptr %t40)
  store i64 %t42, ptr %l30
  br label %bb13
bb13:
  %t43 = load i64, ptr %l28, !tbaa !24
  %t44 = load i64, ptr %l30, !tbaa !24
  %t45 = icmp slt i64 %t43, %t44
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s5)
  br label %bb21
bb15:
  br label %bb16
bb16:
  %t49 = load ptr, ptr %l6, !tbaa !29
  %t50 = load i64, ptr %l7, !tbaa !24
  %t53 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s2, ptr %t49, i64 %t50)
  store i64 %t53, ptr %l35
  br label %bb17
bb17:
  %t54 = load i64, ptr %l35, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/check:Checker", ptr %t55, i32 0, i32 74
  store ptr %t57, ptr %l37, !tbaa !29
  %t58 = load i64, ptr %l1, !tbaa !24
  %t62 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s5, i64 %t58, i64 %t54)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t62, ptr %l40
  br label %bb18
bb18:
  %t63 = load ptr, ptr %l37, !tbaa !29
  %t64 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l40
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t63, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t64, i1 true)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s5)
  br label %bb20
bb20:
  %t65 = load i64, ptr %l7, !tbaa !24
  %t67 = add i64 %t65, 1
  store i64 %t67, ptr %l7, !tbaa !24
  br label %bb12
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb22:
  %t69 = load i64, ptr %l3, !tbaa !24
  %t71 = add i64 %t69, 1
  store i64 %t71, ptr %l3, !tbaa !24
  br label %bb1
bb23:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i64
  %l17 = alloca i1
  %l20 = alloca ptr
  %l23 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca i32
  %l29 = alloca { i64, ptr }
  %l36 = alloca ptr
  %l37 = alloca i32
  %l41 = alloca ptr
  %l43 = alloca { i64, ptr }
  %l45 = alloca i32
  %l46 = alloca i64
  %l49 = alloca i1
  %l52 = alloca ptr
  %l55 = alloca ptr
  %l59 = alloca i32
  %l60 = alloca i32
  %l61 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l6, !tbaa !29
  %t5 = load i32, ptr %l1, !tbaa !23
  store i32 %t5, ptr %l7, !tbaa !23
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 0
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/load:Loader", ptr %t12, i32 0, i32 3
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t16 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t19 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %t15, { i64, ptr } %t16)
  store i32 %t19, ptr %l13
  br label %bb1
bb1:
  %t20 = load ptr, ptr %l6, !tbaa !29
  %t21 = load i32, ptr %l7, !tbaa !23
  %t22 = load i32, ptr %l13, !tbaa !23
  %t23 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t20, i32 %t21, i32 %t22)
  store i64 %t23, ptr %l14
  br label %bb2
bb2:
  %t24 = load i64, ptr %l14, !tbaa !24
  store i64 %t24, ptr %l4, !tbaa !24
  %t25 = load i64, ptr %l4, !tbaa !24
  %t27 = icmp sge i64 %t25, 0
  br i1 %t27, label %bb3, label %bb4
bb3:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 2
  store ptr %t34, ptr %l20, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/check:Checker", ptr %t35, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = getelementptr %"compiler/generic:Program", ptr %t38, i32 0, i32 2
  store ptr %t40, ptr %l23, !tbaa !29
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/check:Checker", ptr %t41, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t45 = load i64, ptr %l4, !tbaa !24
  %t48 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t44, i64 %t45)
  store i32 %t48, ptr %l27
  br label %bb5
bb4:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb8
bb5:
  %t49 = load ptr, ptr %l23, !tbaa !29
  %t50 = load i32, ptr %l27, !tbaa !23
  %t51 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t49, i32 %t50)
  store i32 %t51, ptr %l28
  br label %bb6
bb6:
  %t52 = load ptr, ptr %l20, !tbaa !29
  %t53 = load i32, ptr %l28, !tbaa !23
  %t54 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t52, i32 %t53)
  store { i64, ptr } %t54, ptr %l29
  br label %bb7
bb7:
  %t55 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t55, 0
  %t57 = load i64, ptr %l3, !tbaa !24
  %t59 = add i64 %t57, 1
  %t62 = icmp eq i64 %t56, %t59
  store i1 %t62, ptr %l17, !tbaa !21
  br label %bb8
bb8:
  %t64 = load i1, ptr %l17, !tbaa !21
  br i1 %t64, label %bb9, label %bb10
bb9:
  %t65 = load i64, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t65, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/check:Checker", ptr %t67, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !29
  store ptr %t70, ptr %l36, !tbaa !29
  %t71 = load i32, ptr %l1, !tbaa !23
  store i32 %t71, ptr %l37, !tbaa !23
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/check:Checker", ptr %t72, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !29
  %t77 = getelementptr %"compiler/generic:Program", ptr %t75, i32 0, i32 0
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t80 = getelementptr %"compiler/load:Loader", ptr %t78, i32 0, i32 3
  %t81 = load ptr, ptr %t80, !tbaa !29
  store ptr %t81, ptr %l41, !tbaa !29
  %t82 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t84 = call { i64, ptr } @compiler_2fcheck_2elowerFirst(ptr %v1, ptr %s0, { i64, ptr } %t82)
  store { i64, ptr } %t84, ptr %l43
  br label %bb12
bb12:
  %t85 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t85, 0
  %t87 = extractvalue { i64, ptr } %t85, 1
  %t88 = mul i64 %t86, 1
  %t89 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t88)
  call void @llvm.memcpy.p0.p0.i64(ptr %t89, ptr %t87, i64 %t88, i1 false)
  %t90 = insertvalue { i64, ptr } undef, i64 %t86, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t89, 1
  %t92 = load ptr, ptr %l41, !tbaa !29
  %t94 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s0, ptr %t92, { i64, ptr } %t91)
  store i32 %t94, ptr %l45
  br label %bb13
bb13:
  %t95 = load ptr, ptr %l36, !tbaa !29
  %t96 = load i32, ptr %l37, !tbaa !23
  %t97 = load i32, ptr %l45, !tbaa !23
  %t98 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t95, i32 %t96, i32 %t97)
  store i64 %t98, ptr %l46
  br label %bb14
bb14:
  %t99 = load i64, ptr %l46, !tbaa !24
  store i64 %t99, ptr %l4, !tbaa !24
  %t100 = load i64, ptr %l4, !tbaa !24
  %t102 = icmp sge i64 %t100, 0
  br i1 %t102, label %bb15, label %bb16
bb15:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/check:Checker", ptr %t104, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !29
  %t109 = getelementptr %"compiler/generic:Program", ptr %t107, i32 0, i32 2
  store ptr %t109, ptr %l52, !tbaa !29
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/check:Checker", ptr %t110, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t115 = getelementptr %"compiler/generic:Program", ptr %t113, i32 0, i32 2
  store ptr %t115, ptr %l55, !tbaa !29
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/check:Checker", ptr %t116, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !29
  %t120 = load i64, ptr %l4, !tbaa !24
  %t123 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t119, i64 %t120)
  store i32 %t123, ptr %l59
  br label %bb17
bb16:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb20
bb17:
  %t124 = load ptr, ptr %l55, !tbaa !29
  %t125 = load i32, ptr %l59, !tbaa !23
  %t126 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t124, i32 %t125)
  store i32 %t126, ptr %l60
  br label %bb18
bb18:
  %t127 = load ptr, ptr %l52, !tbaa !29
  %t128 = load i32, ptr %l60, !tbaa !23
  %t129 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t127, i32 %t128)
  store { i64, ptr } %t129, ptr %l61
  br label %bb19
bb19:
  %t130 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t130, 0
  %t132 = load i64, ptr %l3, !tbaa !24
  %t134 = add i64 %t132, 1
  %t137 = icmp eq i64 %t131, %t134
  store i1 %t137, ptr %l49, !tbaa !21
  br label %bb20
bb20:
  %t139 = load i1, ptr %l49, !tbaa !21
  br i1 %t139, label %bb21, label %bb22
bb21:
  %t140 = load i64, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t140, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eseqColumn(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i64
  %l13 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l17 = alloca ptr
  %s2 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a1, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t3 = load i64, ptr %l3, !tbaa !24
  store i64 %t3, ptr %l6, !tbaa !24
  %t4 = load ptr, ptr %l2, !tbaa !29
  %t6 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_H06f4ae43b564aa38800728c5b9a6edfe(ptr %v1, ptr %t4)
  store i64 %t6, ptr %l8
  br label %bb2
bb2:
  %t7 = load i64, ptr %l6, !tbaa !24
  %t8 = load i64, ptr %l8, !tbaa !24
  %t9 = icmp slt i64 %t7, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb4:
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t14 = load i64, ptr %l3, !tbaa !24
  %t17 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_Hb04d670045d084ea2498d9030c4fbba9(ptr %v1, ptr %v1, ptr %t13, i64 %t14)
  store { i64, ptr } %t17, ptr %l13
  br label %bb6
bb6:
  %t18 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t18, ptr %l15, !tbaa !27
  %t21 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 0
  %t24 = load ptr, ptr %t23, !tbaa !39
  %t27 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshapeOf(ptr %v0, ptr %v1, ptr %s2, ptr %a0, ptr %t24)
  store ptr %t27, ptr %l17
  br label %bb7
bb7:
  %t28 = load ptr, ptr %l17, !tbaa !29
  %t30 = getelementptr %"compiler/check:elemsShape", ptr %t28, i32 0, i32 1
  %t31 = load i64, ptr %t30, !tbaa !24
  %t33 = icmp sge i64 %t31, -1
  br i1 %t33, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb11:
  %t36 = load i64, ptr %l3, !tbaa !24
  %t38 = add i64 %t36, 1
  store i64 %t38, ptr %l3, !tbaa !24
  br label %bb1
bb12:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eseqOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l7 = alloca i64
  %l11 = alloca %"compiler/source:Span"
  %l12 = alloca i32
  %l16 = alloca { i64, ptr }
  %l19 = alloca %"compiler/typed:Seq"
  %rv = alloca ptr
  %t29 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 37
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load i64, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l7, !tbaa !24
  %t9 = icmp eq i64 %t7, %t6
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l4, !tbaa !29
  store ptr %t11, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  store %"compiler/source:Span" %a1, ptr %l11
  store i32 %a2, ptr %l12, !tbaa !23
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/check:Checker", ptr %t15, i32 0, i32 37
  %t18 = load i64, ptr %l3, !tbaa !24
  %t21 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t17, i64 %t18)
  store { i64, ptr } %t21, ptr %l16
  br label %bb5
bb5:
  %t22 = load ptr, ptr %l4, !tbaa !29
  %t24 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t26 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %t24, ptr %t22)
  store %"compiler/typed:Seq" %t26, ptr %l19
  br label %bb6
bb6:
  %t27 = load %"compiler/typed:Seq", ptr %l19
  %t28 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 24, i64 8)
  store %"compiler/typed:Seq" %t27, ptr %t28
  store { i64, [5 x i64] } zeroinitializer, ptr %t29
  %t30 = getelementptr { i64, [5 x i64] }, ptr %t29, i32 0, i32 0
  store i64 12, ptr %t30
  %t31 = load %"compiler/source:Span", ptr %l11
  %t32 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t31, 0
  %t33 = load i32, ptr %l12, !tbaa !23
  %t34 = insertvalue { %"compiler/source:Span", i32, ptr } %t32, i32 %t33, 1
  %t36 = insertvalue { %"compiler/source:Span", i32, ptr } %t34, ptr %t28, 2
  %t37 = getelementptr { i64, [5 x i64] }, ptr %t29, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t36, ptr %t37
  %t38 = load { i64, [5 x i64] }, ptr %t29
  %t40 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t38, ptr %t40
  store ptr %t40, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eseqSlice(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca i64
  %l15 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca %"compiler/source:Span"
  %l24 = alloca %"compiler/source:Span"
  %l26 = alloca i64
  %l30 = alloca ptr
  %l31 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l42 = alloca ptr
  %l44 = alloca i32
  %l47 = alloca i1
  %l48 = alloca i64
  %l53 = alloca i1
  %l54 = alloca i32
  %l61 = alloca i32
  %l62 = alloca %"compiler/source:Span"
  %l68 = alloca i32
  %l73 = alloca %"compiler/typed:Slice"
  %rv = alloca ptr
  %t133 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t3 = getelementptr %"compiler/check:seqOf", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp sge i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/check:Checker", ptr %t8, i32 0, i32 36
  %t12 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t10)
  store i64 %t12, ptr %l15
  br label %bb3
bb2:
  br label %bb17
bb3:
  %t13 = load i64, ptr %l15, !tbaa !24
  store i64 %t13, ptr %l6, !tbaa !24
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 36
  %t17 = load ptr, ptr %l4, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v3, ptr %t16, ptr %t17)
  br label %bb4
bb4:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 36
  %t23 = load ptr, ptr %l5, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v4, ptr %t22, ptr %t23)
  br label %bb5
bb5:
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l22, !tbaa !29
  %t27 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t27, ptr %l23
  %t28 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t28, ptr %l24
  %t29 = load ptr, ptr %l3, !tbaa !29
  %t31 = getelementptr %"compiler/check:seqOf", ptr %t29, i32 0, i32 3
  %t32 = load i64, ptr %t31, !tbaa !24
  store i64 %t32, ptr %l26, !tbaa !24
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load %"compiler/source:Span", ptr %l1
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t39 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v1, ptr %v0, ptr %t33, %"compiler/source:Span" %t34, ptr %t35)
  store ptr %t39, ptr %l30
  br label %bb6
bb6:
  %t40 = load ptr, ptr %l30, !tbaa !29
  store ptr %t40, ptr %l31, !tbaa !29
  %t41 = icmp sge i64 0, 0
  br i1 %t41, label %bb7, label %bb8
bb7:
  %t43 = icmp sle i64 0, 1152921504606846975
  br i1 %t43, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_b8e2733ff2674fd_52419f97eade6699)
  unreachable
bb9:
  %t45 = mul i64 0, 8
  %t46 = insertvalue { i64, ptr } undef, i64 0, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t47, ptr %l34, !tbaa !27
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/check:Checker", ptr %t48, i32 0, i32 36
  %t51 = load i64, ptr %l6, !tbaa !24
  %t54 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t50, i64 %t51)
  store { i64, ptr } %t54, ptr %l38
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_b8e2733ff2674fd_52419f97eade6699)
  unreachable
bb11:
  %t55 = icmp sge i64 0, 0
  br i1 %t55, label %bb12, label %bb13
bb12:
  %t57 = icmp sle i64 0, 2305843009213693951
  br i1 %t57, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_4fb1ec40319fc7d0_191a57ffdbf9a78c)
  unreachable
bb14:
  %t59 = mul i64 0, 4
  %t60 = insertvalue { i64, ptr } undef, i64 0, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t62 = load ptr, ptr %l22, !tbaa !29
  %t63 = load %"compiler/source:Span", ptr %l23
  %t64 = load %"compiler/source:Span", ptr %l24
  %t65 = load i64, ptr %l26, !tbaa !24
  %t66 = load ptr, ptr %l31, !tbaa !29
  %t67 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t68 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t70 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v5, ptr %v5, ptr %t62, %"compiler/source:Span" %t63, %"compiler/source:Span" %t64, i64 %t65, ptr %t66, { i64, ptr } %t67, { i64, ptr } %t68, { i64, ptr } %t61)
  store ptr %t70, ptr %l42
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_4fb1ec40319fc7d0_191a57ffdbf9a78c)
  unreachable
bb16:
  %t71 = load ptr, ptr %l42, !tbaa !29
  store ptr %t71, ptr %rv
  br label %ret
bb17:
  %t72 = load ptr, ptr %l2, !tbaa !29
  %t74 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t72)
  store i32 %t74, ptr %l44
  br label %bb18
bb18:
  %t75 = load i32, ptr %l44, !tbaa !23
  store i32 %t75, ptr %l7, !tbaa !23
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load ptr, ptr %l2, !tbaa !29
  %t80 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eslicedWritable(ptr %v0, ptr %v1, ptr %t76, ptr %t77)
  store i1 %t80, ptr %l47
  br label %bb19
bb19:
  %t81 = load i1, ptr %l47, !tbaa !21
  br i1 %t81, label %bb20, label %bb21
bb20:
  %t82 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  store i64 %t82, ptr %l48, !tbaa !24
  br label %bb22
bb21:
  %t84 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  store i64 %t84, ptr %l48, !tbaa !24
  br label %bb22
bb22:
  %t86 = load i64, ptr %l48, !tbaa !24
  store i64 %t86, ptr %l8, !tbaa !24
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load i32, ptr %l7, !tbaa !23
  %t91 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t87, i32 %t88)
  store i1 %t91, ptr %l53
  br label %bb23
bb23:
  %t92 = load i1, ptr %l53, !tbaa !21
  br i1 %t92, label %bb24, label %bb25
bb24:
  %t93 = load i32, ptr %l7, !tbaa !23
  store i32 %t93, ptr %l54, !tbaa !23
  br label %bb27
bb25:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/check:Checker", ptr %t95, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t100 = getelementptr %"compiler/generic:Program", ptr %t98, i32 0, i32 2
  %t101 = load ptr, ptr %l3, !tbaa !29
  %t103 = getelementptr %"compiler/check:seqOf", ptr %t101, i32 0, i32 0
  %t104 = load i32, ptr %t103, !tbaa !23
  %t107 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t100, i32 %t104, i32 0)
  store i32 %t107, ptr %l61
  br label %bb26
bb26:
  %t108 = load i32, ptr %l61, !tbaa !23
  store i32 %t108, ptr %l54, !tbaa !23
  br label %bb27
bb27:
  %t109 = load i32, ptr %l54, !tbaa !23
  %t110 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t110, ptr %l62
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/check:Checker", ptr %t111, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t116 = getelementptr %"compiler/generic:Program", ptr %t114, i32 0, i32 2
  %t118 = load i64, ptr %l8, !tbaa !24
  %t122 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t116, i32 %t109, i64 %t118)
  store i32 %t122, ptr %l68
  br label %bb28
bb28:
  %t123 = load ptr, ptr %l2, !tbaa !29
  %t124 = load ptr, ptr %l4, !tbaa !29
  %t125 = load ptr, ptr %l5, !tbaa !29
  %t130 = call %"compiler/typed:Slice" @compiler_2ftyped_3aSlice_2ector(ptr %v1, ptr %v3, ptr %v4, ptr %v5, ptr %t123, ptr %t124, ptr %t125, i32 0)
  store %"compiler/typed:Slice" %t130, ptr %l73
  br label %bb29
bb29:
  %t131 = load %"compiler/typed:Slice", ptr %l73
  %t132 = call ptr @__olang_scope_alloc_a(ptr %v5, i64 32, i64 8)
  store %"compiler/typed:Slice" %t131, ptr %t132
  store { i64, [5 x i64] } zeroinitializer, ptr %t133
  %t134 = getelementptr { i64, [5 x i64] }, ptr %t133, i32 0, i32 0
  store i64 10, ptr %t134
  %t135 = load %"compiler/source:Span", ptr %l62
  %t136 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t135, 0
  %t137 = load i32, ptr %l68, !tbaa !23
  %t138 = insertvalue { %"compiler/source:Span", i32, ptr } %t136, i32 %t137, 1
  %t140 = insertvalue { %"compiler/source:Span", i32, ptr } %t138, ptr %t132, 2
  %t141 = getelementptr { i64, [5 x i64] }, ptr %t133, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t140, ptr %t141
  %t142 = load { i64, [5 x i64] }, ptr %t133
  %t144 = call ptr @__olang_scope_alloc_a(ptr %v5, i64 48, i64 8)
  store { i64, [5 x i64] } %t142, ptr %t144
  store ptr %t144, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esliceOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, ptr %a4, i32 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %l16 = alloca i64
  %l17 = alloca i64
  %lp18 = alloca ptr
  %lp19 = alloca ptr
  %l20 = alloca i64
  %lp21 = alloca ptr
  %lp22 = alloca ptr
  %l26 = alloca i32
  %l29 = alloca i1
  %l30 = alloca i64
  %l36 = alloca i64
  %l39 = alloca i64
  %l59 = alloca i1
  %l67 = alloca i64
  %l70 = alloca %"compiler/source:Span"
  %l75 = alloca i32
  %l79 = alloca ptr
  %l86 = alloca i32
  %l91 = alloca i32
  %l100 = alloca ptr
  %l103 = alloca i1
  %l105 = alloca ptr
  %l106 = alloca %"compiler/source:Span"
  %l109 = alloca { i64, ptr }
  %l111 = alloca %"compiler/msgs:Msg"
  %l112 = alloca i64
  %l115 = alloca ptr
  %l118 = alloca i64
  %l124 = alloca i1
  %l126 = alloca ptr
  %l127 = alloca %"compiler/source:Span"
  %l128 = alloca i32
  %l131 = alloca { i64, ptr }
  %l133 = alloca %"compiler/msgs:Msg"
  %l134 = alloca i64
  %l137 = alloca ptr
  %l140 = alloca i64
  %l143 = alloca i1
  %l150 = alloca ptr
  %l153 = alloca ptr
  %l154 = alloca ptr
  %l155 = alloca %"compiler/source:Span"
  %l157 = alloca i32
  %l158 = alloca ptr
  %l159 = alloca ptr
  %l160 = alloca ptr
  %l161 = alloca ptr
  %l163 = alloca i32
  %l164 = alloca ptr
  %l166 = alloca %"compiler/source:Span"
  %l167 = alloca ptr
  %l170 = alloca ptr
  %l171 = alloca %"compiler/source:Span"
  %l172 = alloca %"compiler/source:Span"
  %l173 = alloca i64
  %l177 = alloca ptr
  %l178 = alloca ptr
  %l181 = alloca { i64, ptr }
  %l184 = alloca { i64, ptr }
  %l188 = alloca ptr
  %l190 = alloca ptr
  %l191 = alloca ptr
  %l192 = alloca ptr
  %l194 = alloca i32
  %l195 = alloca ptr
  %l197 = alloca %"compiler/source:Span"
  %l198 = alloca ptr
  %l202 = alloca i64
  %l207 = alloca ptr
  %l211 = alloca ptr
  %l212 = alloca %"compiler/source:Span"
  %l213 = alloca %"compiler/source:Span"
  %l214 = alloca i64
  %l218 = alloca ptr
  %l219 = alloca ptr
  %l222 = alloca { i64, ptr }
  %l226 = alloca { i64, ptr }
  %l230 = alloca ptr
  %l233 = alloca ptr
  %l234 = alloca %"compiler/source:Span"
  %l236 = alloca i32
  %l237 = alloca ptr
  %l239 = alloca ptr
  %l240 = alloca ptr
  %l242 = alloca i32
  %l243 = alloca ptr
  %l247 = alloca ptr
  %l248 = alloca %"compiler/source:Span"
  %l250 = alloca i32
  %l251 = alloca i32
  %l252 = alloca %"compiler/source:Span"
  %l258 = alloca i32
  %l262 = alloca ptr
  %l264 = alloca ptr
  %l265 = alloca ptr
  %l267 = alloca i32
  %l268 = alloca ptr
  %l272 = alloca i1
  %l273 = alloca i32
  %l277 = alloca ptr
  %l282 = alloca i32
  %l285 = alloca i32
  %l290 = alloca i32
  %l291 = alloca i32
  %l292 = alloca %"compiler/source:Span"
  %l298 = alloca i32
  %l299 = alloca ptr
  %l302 = alloca ptr
  %l307 = alloca %"compiler/typed:Slice"
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca ptr
  %t109 = alloca { i64, [4 x i64] }, align 8
  %t502 = alloca { i64, [5 x i64] }, align 8
  %t611 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  store i32 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  %t3 = load ptr, ptr %l6, !tbaa !29
  %t5 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t3)
  store i32 %t5, ptr %l26
  br label %bb1
bb1:
  %t6 = load i32, ptr %l26, !tbaa !23
  store i32 %t6, ptr %l7, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load ptr, ptr %l2, !tbaa !29
  %t11 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eslicedWritable(ptr %v0, ptr %v1, ptr %t7, ptr %t8)
  store i1 %t11, ptr %l29
  br label %bb2
bb2:
  %t12 = load i1, ptr %l29, !tbaa !21
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t13 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  store i64 %t13, ptr %l30, !tbaa !24
  br label %bb5
bb4:
  %t15 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  store i64 %t15, ptr %l30, !tbaa !24
  br label %bb5
bb5:
  %t17 = load i64, ptr %l30, !tbaa !24
  store i64 %t17, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  store i64 4, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t18 = load i64, ptr %l10, !tbaa !24
  %t19 = load i64, ptr %l9, !tbaa !24
  %t22 = icmp sgt i64 %t18, %t19
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t24 = load i64, ptr %l11, !tbaa !24
  %t26 = icmp sgt i64 %t24, 0
  br i1 %t26, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l36, !tbaa !24
  br label %bb11
bb8:
  %t28 = load i64, ptr %l10, !tbaa !24
  %t29 = load i64, ptr %l9, !tbaa !24
  %t32 = sub i64 %t28, %t29
  %t33 = load i64, ptr %l11, !tbaa !24
  %t36 = add i64 %t32, %t33
  %t38 = sub i64 %t36, 1
  %t39 = load i64, ptr %l11, !tbaa !24
  %t42 = sdiv i64 %t38, %t39
  store i64 %t42, ptr %l39, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l39, !tbaa !24
  br label %bb10
bb10:
  %t44 = load i64, ptr %l39, !tbaa !24
  store i64 %t44, ptr %l36, !tbaa !24
  br label %bb11
bb11:
  %t45 = load i64, ptr %l36, !tbaa !24
  store i64 %t45, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb12
bb12:
  %t46 = load i64, ptr %l13, !tbaa !24
  %t47 = load i64, ptr %l12, !tbaa !24
  %t50 = icmp slt i64 %t46, %t47
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb13, label %bb14
bb13:
  br label %bb26
bb14:
  br label %bb15
bb15:
  %t54 = load i64, ptr %l9, !tbaa !24
  %t55 = load i64, ptr %l13, !tbaa !24
  %t56 = load i64, ptr %l11, !tbaa !24
  %t59 = mul i64 %t55, %t56
  %t62 = add i64 %t54, %t59
  store i64 %t62, ptr %l14, !tbaa !24
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load i32, ptr %l7, !tbaa !23
  %t68 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t64, i32 %t65)
  store i1 %t68, ptr %l59
  br label %bb16
bb16:
  %t69 = load i1, ptr %l59, !tbaa !21
  %t70 = xor i1 %t69, true
  br i1 %t70, label %bb17, label %bb18
bb17:
  br label %bb26
bb18:
  br label %bb19
bb19:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullRead(ptr %v0, ptr %v1, ptr %t72, ptr %t73)
  br label %bb20
bb20:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/check:Checker", ptr %t76, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t81 = getelementptr %"compiler/generic:Program", ptr %t79, i32 0, i32 2
  %t82 = load i32, ptr %l7, !tbaa !23
  %t85 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t81, i32 %t82)
  store i64 %t85, ptr %l67
  br label %bb21
bb21:
  %t86 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t87 = load i64, ptr %l67, !tbaa !24
  %t89 = and i64 %t87, %t86
  store i64 %t89, ptr %l8, !tbaa !24
  %t91 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t91, ptr %l70
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/check:Checker", ptr %t92, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t97 = getelementptr %"compiler/generic:Program", ptr %t95, i32 0, i32 2
  %t98 = load i32, ptr %l7, !tbaa !23
  %t101 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t97, i32 %t98)
  store i32 %t101, ptr %l75
  br label %bb22
bb22:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load %"compiler/source:Span", ptr %l1
  %t104 = load ptr, ptr %l6, !tbaa !29
  %t108 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v1, ptr %v1, ptr %t102, %"compiler/source:Span" %t103, ptr %t104)
  store ptr %t108, ptr %l79
  br label %bb23
bb23:
  store { i64, [4 x i64] } zeroinitializer, ptr %t109
  %t110 = getelementptr { i64, [4 x i64] }, ptr %t109, i32 0, i32 0
  store i64 2, ptr %t110
  %t111 = load %"compiler/source:Span", ptr %l70
  %t112 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t111, 0
  %t113 = load i32, ptr %l75, !tbaa !23
  %t114 = insertvalue { %"compiler/source:Span", i32, ptr } %t112, i32 %t113, 1
  %t115 = load ptr, ptr %l79, !tbaa !29
  %t116 = insertvalue { %"compiler/source:Span", i32, ptr } %t114, ptr %t115, 2
  %t117 = getelementptr { i64, [4 x i64] }, ptr %t109, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t116, ptr %t117
  %t118 = load { i64, [4 x i64] }, ptr %t109
  %t120 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t118, ptr %t120
  store ptr %t120, ptr %l6, !tbaa !29
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/check:Checker", ptr %t122, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !29
  %t127 = getelementptr %"compiler/generic:Program", ptr %t125, i32 0, i32 2
  %t128 = load i32, ptr %l7, !tbaa !23
  %t131 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t127, i32 %t128)
  store i32 %t131, ptr %l86
  br label %bb24
bb24:
  %t132 = load i32, ptr %l86, !tbaa !23
  store i32 %t132, ptr %l7, !tbaa !23
  br label %bb25
bb25:
  %t133 = load i64, ptr %l13, !tbaa !24
  %t135 = add i64 %t133, 1
  store i64 %t135, ptr %l13, !tbaa !24
  br label %bb12
bb26:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load i32, ptr %l7, !tbaa !23
  %t141 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t137, i32 %t138)
  store i32 %t141, ptr %l91
  br label %bb27
bb27:
  %t142 = load i32, ptr %l91, !tbaa !23
  store i32 %t142, ptr %l15, !tbaa !23
  %t143 = load i32, ptr %l15, !tbaa !23
  %t144 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t147 = icmp eq i32 %t143, %t144
  br i1 %t147, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s5
  %t149 = load i32, ptr %l7, !tbaa !23
  %t150 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t153 = icmp eq i32 %t149, %t150
  br i1 %t153, label %bb30, label %bb31
bb29:
  br label %bb110
bb30:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load %"compiler/source:Span", ptr %l1
  %t159 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t155, %"compiler/source:Span" %t156)
  store ptr %t159, ptr %l100
  br label %bb32
bb31:
  br label %bb33
bb32:
  call void @__olang_scope_close(ptr %s5)
  %t160 = load ptr, ptr %l100, !tbaa !29
  store ptr %t160, ptr %rv
  br label %ret
bb33:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load i32, ptr %l7, !tbaa !23
  %t165 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t161, i32 %t162)
  store i1 %t165, ptr %l103
  br label %bb34
bb34:
  %t166 = load i1, ptr %l103, !tbaa !21
  %t167 = xor i1 %t166, true
  br i1 %t167, label %bb35, label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s7
  %t169 = load ptr, ptr %l0, !tbaa !29
  store ptr %t169, ptr %l105, !tbaa !29
  %t170 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t170, ptr %l106
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load i32, ptr %l7, !tbaa !23
  %t175 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s7, ptr %t171, i32 %t172)
  store { i64, ptr } %t175, ptr %l109
  br label %bb37
bb36:
  br label %bb41
bb37:
  %t176 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t177 = extractvalue { i64, ptr } %t176, 0
  %t178 = extractvalue { i64, ptr } %t176, 1
  %t179 = mul i64 %t177, 1
  %t180 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t179)
  call void @llvm.memcpy.p0.p0.i64(ptr %t180, ptr %t178, i64 %t179, i1 false)
  %t181 = insertvalue { i64, ptr } undef, i64 %t177, 0
  %t182 = insertvalue { i64, ptr } %t181, ptr %t180, 1
  %t184 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotIndexable(ptr %s7, ptr %s7, { i64, ptr } %t182)
  store %"compiler/msgs:Msg" %t184, ptr %l111
  br label %bb38
bb38:
  %t185 = load ptr, ptr %l105, !tbaa !29
  %t186 = load %"compiler/source:Span", ptr %l106
  %t187 = load %"compiler/msgs:Msg", ptr %l111
  %t188 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s7, ptr %t185, %"compiler/source:Span" %t186, %"compiler/msgs:Msg" %t187)
  store i64 %t188, ptr %l112
  br label %bb39
bb39:
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t190 = load %"compiler/source:Span", ptr %l1
  %t193 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t189, %"compiler/source:Span" %t190)
  store ptr %t193, ptr %l115
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s5)
  %t194 = load ptr, ptr %l115, !tbaa !29
  store ptr %t194, ptr %rv
  br label %ret
bb41:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t196 = load i32, ptr %l7, !tbaa !23
  %t199 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s5, ptr %t195, i32 %t196, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d17, i32 0, i32 1) }, i64 2)
  store i64 %t199, ptr %l118
  br label %bb42
bb42:
  %t200 = load i64, ptr %l118, !tbaa !24
  store i64 %t200, ptr %l16, !tbaa !24
  %t201 = load i64, ptr %l16, !tbaa !24
  %t203 = icmp slt i64 %t201, 0
  br i1 %t203, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s8
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t206 = load i32, ptr %l7, !tbaa !23
  %t207 = load %"compiler/source:Span", ptr %l1
  %t211 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %s8, ptr %s8, ptr %t205, i32 %t206, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d18, i32 0, i32 1) }, %"compiler/source:Span" %t207, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d19, i32 0, i32 1) }, i64 2, i1 false)
  store i1 %t211, ptr %l124
  br label %bb45
bb44:
  br label %bb53
bb45:
  %t212 = load i1, ptr %l124, !tbaa !21
  %t213 = xor i1 %t212, true
  br i1 %t213, label %bb46, label %bb47
bb46:
  store %olang.scope zeroinitializer, ptr %s9
  %t215 = load ptr, ptr %l0, !tbaa !29
  store ptr %t215, ptr %l126, !tbaa !29
  %t216 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t216, ptr %l127
  %t217 = load i32, ptr %l7, !tbaa !23
  store i32 %t217, ptr %l128, !tbaa !23
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t219 = load i32, ptr %l7, !tbaa !23
  %t222 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s9, ptr %t218, i32 %t219)
  store { i64, ptr } %t222, ptr %l131
  br label %bb48
bb47:
  br label %bb51
bb48:
  %t223 = load { i64, ptr }, ptr %l131, !tbaa !27
  %t224 = extractvalue { i64, ptr } %t223, 0
  %t225 = extractvalue { i64, ptr } %t223, 1
  %t226 = mul i64 %t224, 1
  %t227 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t226)
  call void @llvm.memcpy.p0.p0.i64(ptr %t227, ptr %t225, i64 %t226, i1 false)
  %t228 = insertvalue { i64, ptr } undef, i64 %t224, 0
  %t229 = insertvalue { i64, ptr } %t228, ptr %t227, 1
  %t231 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotIndexable(ptr %s9, ptr %s9, { i64, ptr } %t229)
  store %"compiler/msgs:Msg" %t231, ptr %l133
  br label %bb49
bb49:
  %t232 = load ptr, ptr %l126, !tbaa !29
  %t233 = load %"compiler/source:Span", ptr %l127
  %t234 = load i32, ptr %l128, !tbaa !23
  %t235 = load %"compiler/msgs:Msg", ptr %l133
  %t236 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneedErr(ptr %v0, ptr %s9, ptr %s9, ptr %t232, %"compiler/source:Span" %t233, i32 %t234, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d20, i32 0, i32 1) }, %"compiler/msgs:Msg" %t235)
  store i64 %t236, ptr %l134
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s9)
  br label %bb51
bb51:
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t238 = load %"compiler/source:Span", ptr %l1
  %t241 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t237, %"compiler/source:Span" %t238)
  store ptr %t241, ptr %l137
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s5)
  %t242 = load ptr, ptr %l137, !tbaa !29
  store ptr %t242, ptr %rv
  br label %ret
bb53:
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t244 = load i32, ptr %l7, !tbaa !23
  %t247 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s5, ptr %t243, i32 %t244, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d21, i32 0, i32 1) }, i64 0)
  store i64 %t247, ptr %l140
  br label %bb54
bb54:
  %t248 = load i64, ptr %l140, !tbaa !24
  store i64 %t248, ptr %l17, !tbaa !24
  %t249 = load ptr, ptr %l4, !tbaa !29
  %t251 = icmp eq ptr %t249, null
  br i1 %t251, label %bb55, label %bb56
bb55:
  %t253 = load i64, ptr %l17, !tbaa !24
  %t255 = icmp slt i64 %t253, 0
  store i1 %t255, ptr %l143, !tbaa !21
  br label %bb57
bb56:
  store i1 false, ptr %l143, !tbaa !21
  br label %bb57
bb57:
  %t257 = load i1, ptr %l143, !tbaa !21
  br i1 %t257, label %bb58, label %bb59
bb58:
  store %olang.scope zeroinitializer, ptr %s10
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t259 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s10, ptr %t258, %"compiler/source:Span" %t259, { i64, ptr } { i64 47, ptr getelementptr inbounds (<{ i64, [47 x i8] }>, ptr @.d22, i32 0, i32 1) })
  br label %bb60
bb59:
  br label %bb62
bb60:
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t263 = load %"compiler/source:Span", ptr %l1
  %t266 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t262, %"compiler/source:Span" %t263)
  store ptr %t266, ptr %l150
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s5)
  %t267 = load ptr, ptr %l150, !tbaa !29
  store ptr %t267, ptr %rv
  br label %ret
bb62:
  %t268 = load ptr, ptr %l3, !tbaa !29
  %t270 = icmp eq ptr %t268, null
  br i1 %t270, label %bb63, label %bb64
bb63:
  %t272 = load ptr, ptr %l0, !tbaa !29
  store ptr %t272, ptr %l154, !tbaa !29
  %t273 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t273, ptr %l155
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t276 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t274)
  store i32 %t276, ptr %l157
  br label %bb65
bb64:
  %t277 = load ptr, ptr %l0, !tbaa !29
  store ptr %t277, ptr %l159, !tbaa !29
  %t278 = load ptr, ptr %l0, !tbaa !29
  store ptr %t278, ptr %l160, !tbaa !29
  %t279 = load ptr, ptr %l3, !tbaa !29
  store ptr %t279, ptr %l161, !tbaa !29
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t282 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t280)
  store i32 %t282, ptr %l163
  br label %bb67
bb65:
  %t283 = load ptr, ptr %l154, !tbaa !29
  %t284 = load %"compiler/source:Span", ptr %l155
  %t285 = load i32, ptr %l157, !tbaa !23
  %t286 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v4, ptr %t283, %"compiler/source:Span" %t284, i32 %t285, i64 0)
  store ptr %t286, ptr %l158
  br label %bb66
bb66:
  %t287 = load ptr, ptr %l158, !tbaa !29
  store ptr %t287, ptr %l153, !tbaa !29
  br label %bb71
bb67:
  %t288 = load ptr, ptr %l160, !tbaa !29
  %t289 = load ptr, ptr %l161, !tbaa !29
  %t290 = load i32, ptr %l163, !tbaa !23
  %t291 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v2, ptr %v0, ptr %t288, ptr %t289, i32 %t290)
  store ptr %t291, ptr %l164
  br label %bb68
bb68:
  %t292 = load ptr, ptr %l3, !tbaa !29
  %t294 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t292)
  store %"compiler/source:Span" %t294, ptr %l166
  br label %bb69
bb69:
  %t295 = load ptr, ptr %l159, !tbaa !29
  %t296 = load ptr, ptr %l164, !tbaa !29
  %t297 = load %"compiler/source:Span", ptr %l166
  %t298 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v0, ptr %v4, ptr %t295, ptr %t296, %"compiler/source:Span" %t297)
  store ptr %t298, ptr %l167
  br label %bb70
bb70:
  %t299 = load ptr, ptr %l167, !tbaa !29
  store ptr %t299, ptr %l153, !tbaa !29
  br label %bb71
bb71:
  %t300 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 8, i64 8)
  store ptr %t300, ptr %lp18
  %t301 = load ptr, ptr %l153, !tbaa !29
  %t302 = load ptr, ptr %lp18
  store ptr %t301, ptr %t302, !tbaa !29
  %t303 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 8, i64 8)
  store ptr %t303, ptr %lp19
  %t304 = load ptr, ptr %lp19
  store ptr null, ptr %t304, !tbaa !29
  %t305 = load ptr, ptr %l4, !tbaa !29
  %t307 = icmp eq ptr %t305, null
  br i1 %t307, label %bb72, label %bb73
bb72:
  %t309 = load ptr, ptr %l0, !tbaa !29
  store ptr %t309, ptr %l170, !tbaa !29
  %t310 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t310, ptr %l171
  %t311 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t311, ptr %l172
  %t312 = load i64, ptr %l17, !tbaa !24
  store i64 %t312, ptr %l173, !tbaa !24
  %t313 = load ptr, ptr %l0, !tbaa !29
  %t314 = load %"compiler/source:Span", ptr %l1
  %t315 = load ptr, ptr %l6, !tbaa !29
  %t319 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v1, ptr %v0, ptr %t313, %"compiler/source:Span" %t314, ptr %t315)
  store ptr %t319, ptr %l177
  br label %bb74
bb73:
  %t320 = load ptr, ptr %l0, !tbaa !29
  store ptr %t320, ptr %l190, !tbaa !29
  %t321 = load ptr, ptr %l0, !tbaa !29
  store ptr %t321, ptr %l191, !tbaa !29
  %t322 = load ptr, ptr %l4, !tbaa !29
  store ptr %t322, ptr %l192, !tbaa !29
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t325 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t323)
  store i32 %t325, ptr %l194
  br label %bb88
bb74:
  %t326 = load ptr, ptr %l177, !tbaa !29
  store ptr %t326, ptr %l178, !tbaa !29
  %t327 = icmp sge i64 0, 0
  br i1 %t327, label %bb75, label %bb76
bb75:
  %t329 = icmp sle i64 0, 1152921504606846975
  br i1 %t329, label %bb77, label %bb78
bb76:
  call void @__olang_check_failed(ptr @olang_loc_5aa0e1f55b10e6f_53045464d54dc2fb)
  unreachable
bb77:
  %t331 = mul i64 0, 8
  %t332 = insertvalue { i64, ptr } undef, i64 0, 0
  %t333 = insertvalue { i64, ptr } %t332, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t333, ptr %l181, !tbaa !27
  %t334 = icmp sge i64 0, 0
  br i1 %t334, label %bb79, label %bb80
bb78:
  call void @__olang_check_failed(ptr @olang_loc_5aa0e1f55b10e6f_53045464d54dc2fb)
  unreachable
bb79:
  %t336 = icmp sle i64 0, 1152921504606846975
  br i1 %t336, label %bb81, label %bb82
bb80:
  call void @__olang_check_failed(ptr @olang_loc_5aa0e1f55b10e6f_53045464d54dc2fb)
  unreachable
bb81:
  %t338 = mul i64 0, 8
  %t339 = insertvalue { i64, ptr } undef, i64 0, 0
  %t340 = insertvalue { i64, ptr } %t339, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t340, ptr %l184, !tbaa !27
  %t341 = icmp sge i64 0, 0
  br i1 %t341, label %bb83, label %bb84
bb82:
  call void @__olang_check_failed(ptr @olang_loc_5aa0e1f55b10e6f_53045464d54dc2fb)
  unreachable
bb83:
  %t343 = icmp sle i64 0, 2305843009213693951
  br i1 %t343, label %bb85, label %bb86
bb84:
  call void @__olang_check_failed(ptr @olang_loc_e4f33d7277813d9a_8adeed4fca551266)
  unreachable
bb85:
  %t345 = mul i64 0, 4
  %t346 = insertvalue { i64, ptr } undef, i64 0, 0
  %t347 = insertvalue { i64, ptr } %t346, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t348 = load ptr, ptr %l170, !tbaa !29
  %t349 = load %"compiler/source:Span", ptr %l171
  %t350 = load %"compiler/source:Span", ptr %l172
  %t351 = load i64, ptr %l173, !tbaa !24
  %t352 = load ptr, ptr %l178, !tbaa !29
  %t353 = load { i64, ptr }, ptr %l181, !tbaa !27
  %t354 = load { i64, ptr }, ptr %l184, !tbaa !27
  %t356 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v4, ptr %v4, ptr %t348, %"compiler/source:Span" %t349, %"compiler/source:Span" %t350, i64 %t351, ptr %t352, { i64, ptr } %t353, { i64, ptr } %t354, { i64, ptr } %t347)
  store ptr %t356, ptr %l188
  br label %bb87
bb86:
  call void @__olang_check_failed(ptr @olang_loc_e4f33d7277813d9a_8adeed4fca551266)
  unreachable
bb87:
  %t357 = load ptr, ptr %l188, !tbaa !29
  %t359 = load ptr, ptr %lp19
  store ptr %t357, ptr %t359, !tbaa !29
  br label %bb92
bb88:
  %t360 = load ptr, ptr %l191, !tbaa !29
  %t361 = load ptr, ptr %l192, !tbaa !29
  %t362 = load i32, ptr %l194, !tbaa !23
  %t363 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v3, ptr %v0, ptr %t360, ptr %t361, i32 %t362)
  store ptr %t363, ptr %l195
  br label %bb89
bb89:
  %t364 = load ptr, ptr %l4, !tbaa !29
  %t366 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v3, ptr %t364)
  store %"compiler/source:Span" %t366, ptr %l197
  br label %bb90
bb90:
  %t367 = load ptr, ptr %l190, !tbaa !29
  %t368 = load ptr, ptr %l195, !tbaa !29
  %t369 = load %"compiler/source:Span", ptr %l197
  %t370 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v0, ptr %v4, ptr %t367, ptr %t368, %"compiler/source:Span" %t369)
  store ptr %t370, ptr %l198
  br label %bb91
bb91:
  %t371 = load ptr, ptr %l198, !tbaa !29
  %t373 = load ptr, ptr %lp19
  store ptr %t371, ptr %t373, !tbaa !29
  br label %bb92
bb92:
  %t374 = load ptr, ptr %l0, !tbaa !29
  %t376 = getelementptr %"compiler/check:Checker", ptr %t374, i32 0, i32 36
  %t378 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t376)
  store i64 %t378, ptr %l202
  br label %bb93
bb93:
  %t379 = load i64, ptr %l202, !tbaa !24
  store i64 %t379, ptr %l20, !tbaa !24
  %t380 = load ptr, ptr %l0, !tbaa !29
  %t382 = getelementptr %"compiler/check:Checker", ptr %t380, i32 0, i32 36
  %t383 = load ptr, ptr %lp18
  %t384 = load ptr, ptr %t383, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v4, ptr %t382, ptr %t384)
  br label %bb94
bb94:
  %t387 = load ptr, ptr %l0, !tbaa !29
  %t389 = getelementptr %"compiler/check:Checker", ptr %t387, i32 0, i32 36
  store ptr %t389, ptr %l207, !tbaa !29
  %t390 = load ptr, ptr %lp19
  %t391 = load ptr, ptr %t390, !tbaa !29
  %t393 = icmp eq ptr %t391, null
  br i1 %t393, label %bb95, label %bb96
bb95:
  call void @__olang_check_failed(ptr @olang_loc_b203c9fbf4c249fb_735051f472c86bf)
  unreachable
bb96:
  br label %bb97
bb97:
  %t395 = load ptr, ptr %lp19
  %t396 = load ptr, ptr %t395, !tbaa !29
  %t397 = load ptr, ptr %l207, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v4, ptr %t397, ptr %t396)
  br label %bb98
bb98:
  %t399 = load ptr, ptr %l0, !tbaa !29
  store ptr %t399, ptr %l211, !tbaa !29
  %t400 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t400, ptr %l212
  %t401 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t401, ptr %l213
  %t402 = load i64, ptr %l16, !tbaa !24
  store i64 %t402, ptr %l214, !tbaa !24
  %t403 = load ptr, ptr %l0, !tbaa !29
  %t404 = load %"compiler/source:Span", ptr %l1
  %t405 = load ptr, ptr %l6, !tbaa !29
  %t409 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v1, ptr %v0, ptr %t403, %"compiler/source:Span" %t404, ptr %t405)
  store ptr %t409, ptr %l218
  br label %bb99
bb99:
  %t410 = load ptr, ptr %l218, !tbaa !29
  store ptr %t410, ptr %l219, !tbaa !29
  %t411 = icmp sge i64 0, 0
  br i1 %t411, label %bb100, label %bb101
bb100:
  %t413 = icmp sle i64 0, 1152921504606846975
  br i1 %t413, label %bb102, label %bb103
bb101:
  call void @__olang_check_failed(ptr @olang_loc_85a2f2931038d80c_e5a946dd8e187d18)
  unreachable
bb102:
  %t415 = mul i64 0, 8
  %t416 = insertvalue { i64, ptr } undef, i64 0, 0
  %t417 = insertvalue { i64, ptr } %t416, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t417, ptr %l222, !tbaa !27
  %t418 = load ptr, ptr %l0, !tbaa !29
  %t420 = getelementptr %"compiler/check:Checker", ptr %t418, i32 0, i32 36
  %t421 = load i64, ptr %l20, !tbaa !24
  %t424 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t420, i64 %t421)
  store { i64, ptr } %t424, ptr %l226
  br label %bb104
bb103:
  call void @__olang_check_failed(ptr @olang_loc_85a2f2931038d80c_e5a946dd8e187d18)
  unreachable
bb104:
  %t425 = icmp sge i64 0, 0
  br i1 %t425, label %bb105, label %bb106
bb105:
  %t427 = icmp sle i64 0, 2305843009213693951
  br i1 %t427, label %bb107, label %bb108
bb106:
  call void @__olang_check_failed(ptr @olang_loc_e4f33d7277813d9a_8adeed4fca551266)
  unreachable
bb107:
  %t429 = mul i64 0, 4
  %t430 = insertvalue { i64, ptr } undef, i64 0, 0
  %t431 = insertvalue { i64, ptr } %t430, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t432 = load ptr, ptr %l211, !tbaa !29
  %t433 = load %"compiler/source:Span", ptr %l212
  %t434 = load %"compiler/source:Span", ptr %l213
  %t435 = load i64, ptr %l214, !tbaa !24
  %t436 = load ptr, ptr %l219, !tbaa !29
  %t437 = load { i64, ptr }, ptr %l222, !tbaa !27
  %t438 = load { i64, ptr }, ptr %l226, !tbaa !27
  %t440 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v4, ptr %v4, ptr %t432, %"compiler/source:Span" %t433, %"compiler/source:Span" %t434, i64 %t435, ptr %t436, { i64, ptr } %t437, { i64, ptr } %t438, { i64, ptr } %t431)
  store ptr %t440, ptr %l230
  br label %bb109
bb108:
  call void @__olang_check_failed(ptr @olang_loc_e4f33d7277813d9a_8adeed4fca551266)
  unreachable
bb109:
  call void @__olang_scope_close(ptr %s5)
  %t441 = load ptr, ptr %l230, !tbaa !29
  store ptr %t441, ptr %rv
  br label %ret
bb110:
  %t442 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 8, i64 8)
  store ptr %t442, ptr %lp21
  %t443 = load ptr, ptr %lp21
  store ptr null, ptr %t443, !tbaa !29
  %t444 = load ptr, ptr %l3, !tbaa !29
  %t446 = icmp eq ptr %t444, null
  br i1 %t446, label %bb111, label %bb112
bb111:
  %t448 = load ptr, ptr %l0, !tbaa !29
  store ptr %t448, ptr %l233, !tbaa !29
  %t449 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t449, ptr %l234
  %t450 = load ptr, ptr %l0, !tbaa !29
  %t452 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t450)
  store i32 %t452, ptr %l236
  br label %bb113
bb112:
  %t453 = load ptr, ptr %l0, !tbaa !29
  store ptr %t453, ptr %l239, !tbaa !29
  %t454 = load ptr, ptr %l3, !tbaa !29
  store ptr %t454, ptr %l240, !tbaa !29
  %t455 = load ptr, ptr %l0, !tbaa !29
  %t457 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t455)
  store i32 %t457, ptr %l242
  br label %bb115
bb113:
  %t458 = load ptr, ptr %l233, !tbaa !29
  %t459 = load %"compiler/source:Span", ptr %l234
  %t460 = load i32, ptr %l236, !tbaa !23
  %t461 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v4, ptr %t458, %"compiler/source:Span" %t459, i32 %t460, i64 0)
  store ptr %t461, ptr %l237
  br label %bb114
bb114:
  %t462 = load ptr, ptr %l237, !tbaa !29
  %t464 = load ptr, ptr %lp21
  store ptr %t462, ptr %t464, !tbaa !29
  br label %bb117
bb115:
  %t465 = load ptr, ptr %l239, !tbaa !29
  %t466 = load ptr, ptr %l240, !tbaa !29
  %t467 = load i32, ptr %l242, !tbaa !23
  %t468 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v2, ptr %v4, ptr %t465, ptr %t466, i32 %t467)
  store ptr %t468, ptr %l243
  br label %bb116
bb116:
  %t469 = load ptr, ptr %l243, !tbaa !29
  %t471 = load ptr, ptr %lp21
  store ptr %t469, ptr %t471, !tbaa !29
  br label %bb117
bb117:
  %t472 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 8, i64 8)
  store ptr %t472, ptr %lp22
  %t473 = load ptr, ptr %lp22
  store ptr null, ptr %t473, !tbaa !29
  %t474 = load ptr, ptr %l4, !tbaa !29
  %t476 = icmp eq ptr %t474, null
  br i1 %t476, label %bb118, label %bb119
bb118:
  %t478 = load ptr, ptr %l0, !tbaa !29
  store ptr %t478, ptr %l247, !tbaa !29
  %t479 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t479, ptr %l248
  %t480 = load ptr, ptr %l0, !tbaa !29
  %t482 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t480)
  store i32 %t482, ptr %l250
  br label %bb120
bb119:
  %t483 = load ptr, ptr %l0, !tbaa !29
  store ptr %t483, ptr %l264, !tbaa !29
  %t484 = load ptr, ptr %l4, !tbaa !29
  store ptr %t484, ptr %l265, !tbaa !29
  %t485 = load ptr, ptr %l0, !tbaa !29
  %t487 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t485)
  store i32 %t487, ptr %l267
  br label %bb123
bb120:
  store i32 22, ptr %l251
  %t488 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t488, ptr %l252
  %t489 = load ptr, ptr %l0, !tbaa !29
  %t491 = getelementptr %"compiler/check:Checker", ptr %t489, i32 0, i32 1
  %t492 = load ptr, ptr %t491, !tbaa !29
  %t494 = getelementptr %"compiler/generic:Program", ptr %t492, i32 0, i32 2
  %t495 = load i32, ptr %l7, !tbaa !23
  %t496 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t500 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t494, i32 %t495, i64 %t496)
  store i32 %t500, ptr %l258
  br label %bb121
bb121:
  %t501 = load ptr, ptr %l6, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t502
  %t503 = getelementptr { i64, [5 x i64] }, ptr %t502, i32 0, i32 0
  store i64 3, ptr %t503
  %t504 = load %"compiler/source:Span", ptr %l252
  %t505 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t504, 0
  %t506 = load i32, ptr %l258, !tbaa !23
  %t507 = insertvalue { %"compiler/source:Span", i32, ptr } %t505, i32 %t506, 1
  %t509 = insertvalue { %"compiler/source:Span", i32, ptr } %t507, ptr %t501, 2
  %t510 = getelementptr { i64, [5 x i64] }, ptr %t502, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t509, ptr %t510
  %t511 = load { i64, [5 x i64] }, ptr %t502
  %t513 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t511, ptr %t513
  %t514 = load ptr, ptr %l247, !tbaa !29
  %t515 = load %"compiler/source:Span", ptr %l248
  %t516 = load i32, ptr %l250, !tbaa !23
  %t517 = load i32, ptr %l251, !range !{i32 0, i32 43}
  %t519 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v0, ptr %v0, ptr %v4, ptr %t514, %"compiler/source:Span" %t515, i32 %t516, i32 %t517, ptr %t513, ptr null)
  store ptr %t519, ptr %l262
  br label %bb122
bb122:
  %t520 = load ptr, ptr %l262, !tbaa !29
  %t522 = load ptr, ptr %lp22
  store ptr %t520, ptr %t522, !tbaa !29
  br label %bb125
bb123:
  %t523 = load ptr, ptr %l264, !tbaa !29
  %t524 = load ptr, ptr %l265, !tbaa !29
  %t525 = load i32, ptr %l267, !tbaa !23
  %t526 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v3, ptr %v4, ptr %t523, ptr %t524, i32 %t525)
  store ptr %t526, ptr %l268
  br label %bb124
bb124:
  %t527 = load ptr, ptr %l268, !tbaa !29
  %t529 = load ptr, ptr %lp22
  store ptr %t527, ptr %t529, !tbaa !29
  br label %bb125
bb125:
  %t530 = load ptr, ptr %l0, !tbaa !29
  %t531 = load i32, ptr %l7, !tbaa !23
  %t534 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t530, i32 %t531)
  store i1 %t534, ptr %l272
  br label %bb126
bb126:
  %t535 = load i1, ptr %l272, !tbaa !21
  br i1 %t535, label %bb127, label %bb128
bb127:
  %t536 = load i32, ptr %l7, !tbaa !23
  store i32 %t536, ptr %l273, !tbaa !23
  br label %bb135
bb128:
  %t538 = load ptr, ptr %l0, !tbaa !29
  %t540 = getelementptr %"compiler/check:Checker", ptr %t538, i32 0, i32 1
  %t541 = load ptr, ptr %t540, !tbaa !29
  %t543 = getelementptr %"compiler/generic:Program", ptr %t541, i32 0, i32 2
  store ptr %t543, ptr %l277, !tbaa !29
  %t544 = load ptr, ptr %l0, !tbaa !29
  %t546 = getelementptr %"compiler/check:Checker", ptr %t544, i32 0, i32 1
  %t547 = load ptr, ptr %t546, !tbaa !29
  %t549 = getelementptr %"compiler/generic:Program", ptr %t547, i32 0, i32 2
  %t550 = load i32, ptr %l15, !tbaa !23
  %t553 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t549, i32 %t550)
  store i32 %t553, ptr %l282
  br label %bb129
bb129:
  %t554 = load i32, ptr %l5, !range !{i32 0, i32 3}
  %t556 = trunc i64 1 to i32
  %t557 = icmp eq i32 %t554, %t556
  br i1 %t557, label %bb130, label %bb131
bb130:
  %t559 = load ptr, ptr %l0, !tbaa !29
  %t560 = load i32, ptr %l15, !tbaa !23
  %t561 = load ptr, ptr %l3, !tbaa !29
  %t562 = load ptr, ptr %l4, !tbaa !29
  %t567 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esliceLength(ptr %v0, ptr %v2, ptr %v3, ptr %t559, i32 %t560, ptr %t561, ptr %t562)
  store i32 %t567, ptr %l290
  br label %bb132
bb131:
  store i32 0, ptr %l285, !tbaa !23
  br label %bb133
bb132:
  %t568 = load i32, ptr %l290, !tbaa !23
  store i32 %t568, ptr %l285, !tbaa !23
  br label %bb133
bb133:
  %t569 = load ptr, ptr %l277, !tbaa !29
  %t570 = load i32, ptr %l282, !tbaa !23
  %t571 = load i32, ptr %l285, !tbaa !23
  %t572 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t569, i32 %t570, i32 %t571)
  store i32 %t572, ptr %l291
  br label %bb134
bb134:
  %t573 = load i32, ptr %l291, !tbaa !23
  store i32 %t573, ptr %l273, !tbaa !23
  br label %bb135
bb135:
  %t574 = load i32, ptr %l273, !tbaa !23
  %t575 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t575, ptr %l292
  %t576 = load ptr, ptr %l0, !tbaa !29
  %t578 = getelementptr %"compiler/check:Checker", ptr %t576, i32 0, i32 1
  %t579 = load ptr, ptr %t578, !tbaa !29
  %t581 = getelementptr %"compiler/generic:Program", ptr %t579, i32 0, i32 2
  %t583 = load i64, ptr %l8, !tbaa !24
  %t587 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t581, i32 %t574, i64 %t583)
  store i32 %t587, ptr %l298
  br label %bb136
bb136:
  %t588 = load ptr, ptr %l6, !tbaa !29
  store ptr %t588, ptr %l299, !tbaa !29
  %t589 = load ptr, ptr %lp21
  %t590 = load ptr, ptr %t589, !tbaa !29
  %t592 = icmp eq ptr %t590, null
  br i1 %t592, label %bb137, label %bb138
bb137:
  call void @__olang_check_failed(ptr @olang_loc_2f1aad6b95023edd_c82f5ce971f0d619)
  unreachable
bb138:
  br label %bb139
bb139:
  %t594 = load ptr, ptr %lp21
  %t595 = load ptr, ptr %t594, !tbaa !29
  store ptr %t595, ptr %l302, !tbaa !29
  %t596 = load ptr, ptr %lp22
  %t597 = load ptr, ptr %t596, !tbaa !29
  %t599 = icmp eq ptr %t597, null
  br i1 %t599, label %bb140, label %bb141
bb140:
  call void @__olang_check_failed(ptr @olang_loc_2f1aad6b95023edd_c82f5ce971f0d619)
  unreachable
bb141:
  br label %bb142
bb142:
  %t601 = load ptr, ptr %lp22
  %t602 = load ptr, ptr %t601, !tbaa !29
  %t603 = load i32, ptr %l5, !range !{i32 0, i32 3}
  %t604 = load ptr, ptr %l299, !tbaa !29
  %t605 = load ptr, ptr %l302, !tbaa !29
  %t608 = call %"compiler/typed:Slice" @compiler_2ftyped_3aSlice_2ector(ptr %v1, ptr %v4, ptr %v4, ptr %v4, ptr %t604, ptr %t605, ptr %t602, i32 %t603)
  store %"compiler/typed:Slice" %t608, ptr %l307
  br label %bb143
bb143:
  %t609 = load %"compiler/typed:Slice", ptr %l307
  %t610 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 32, i64 8)
  store %"compiler/typed:Slice" %t609, ptr %t610
  store { i64, [5 x i64] } zeroinitializer, ptr %t611
  %t612 = getelementptr { i64, [5 x i64] }, ptr %t611, i32 0, i32 0
  store i64 10, ptr %t612
  %t613 = load %"compiler/source:Span", ptr %l292
  %t614 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t613, 0
  %t615 = load i32, ptr %l298, !tbaa !23
  %t616 = insertvalue { %"compiler/source:Span", i32, ptr } %t614, i32 %t615, 1
  %t618 = insertvalue { %"compiler/source:Span", i32, ptr } %t616, ptr %t610, 2
  %t619 = getelementptr { i64, [5 x i64] }, ptr %t611, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t618, ptr %t619
  %t620 = load { i64, [5 x i64] }, ptr %t611
  %t622 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 48, i64 8)
  store { i64, [5 x i64] } %t620, ptr %t622
  store ptr %t622, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l9 = alloca ptr
  %l12 = alloca ptr
  %l22 = alloca i1
  %l28 = alloca i1
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l35 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 10
  store ptr %t9, ptr %l7, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t10)
  store ptr %t12, ptr %l9
  br label %bb1
bb1:
  %t13 = load ptr, ptr %l9, !tbaa !29
  %t15 = getelementptr %"compiler/check:frame", ptr %t13, i32 0, i32 1
  %t16 = load i64, ptr %t15, !tbaa !24
  %t17 = load ptr, ptr %l7, !tbaa !29
  %t19 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t17, i64 %t16)
  store ptr %t19, ptr %l12
  br label %bb2
bb2:
  %t20 = load ptr, ptr %l12, !tbaa !29
  %t22 = getelementptr %"compiler/load:Module", ptr %t20, i32 0, i32 6
  %t23 = load ptr, ptr %t22, !tbaa !29
  store ptr %t23, ptr %l2, !tbaa !29
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t27 = icmp eq ptr %t25, null
  br i1 %t27, label %bb3, label %bb4
bb3:
  call void @__olang_check_failed(ptr @olang_loc_7151da8c7014d0c8_6aa5246f01d956ac)
  unreachable
bb4:
  br label %bb5
bb5:
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t32 = getelementptr %"compiler/source:Source", ptr %t29, i32 0, i32 1
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } %t33, ptr %l3, !tbaa !27
  %t35 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t36 = load i32, ptr %t35, !tbaa !23
  %t38 = icmp slt i32 %t36, 0
  br i1 %t38, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb8
bb7:
  %t40 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t41 = load i32, ptr %t40, !tbaa !23
  %t42 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t46 = trunc i64 %t44 to i32
  %t49 = icmp sgt i32 %t41, %t46
  store i1 %t49, ptr %l22, !tbaa !21
  br label %bb8
bb8:
  %t51 = load i1, ptr %l22, !tbaa !21
  br i1 %t51, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb11
bb10:
  %t52 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t53 = load i32, ptr %t52, !tbaa !23
  %t54 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t55 = load i32, ptr %t54, !tbaa !23
  %t58 = icmp sgt i32 %t53, %t55
  store i1 %t58, ptr %l28, !tbaa !21
  br label %bb11
bb11:
  %t60 = load i1, ptr %l28, !tbaa !21
  br i1 %t60, label %bb12, label %bb13
bb12:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d23, i32 0, i32 1) }, ptr %l32, !tbaa !27
  %t61 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t61, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t62 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t62, ptr %l33, !tbaa !27
  %t63 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t64 = load i32, ptr %t63, !tbaa !23
  %t66 = sext i32 %t64 to i64
  store i64 %t66, ptr %l35, !tbaa !24
  %t67 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t68 = load i32, ptr %t67, !tbaa !23
  %t70 = sext i32 %t68 to i64
  store i64 %t70, ptr %l37, !tbaa !24
  %t71 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t71, 0
  store i64 %t72, ptr %l38, !tbaa !24
  %t73 = load i64, ptr %l35, !tbaa !24
  %t74 = icmp sge i64 %t73, 0
  br i1 %t74, label %bb15, label %bb16
bb15:
  %t76 = load i64, ptr %l35, !tbaa !24
  %t77 = load i64, ptr %l37, !tbaa !24
  %t78 = icmp sle i64 %t76, %t77
  br i1 %t78, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_16d25af731eb828d_f9df92790de43871)
  unreachable
bb17:
  %t80 = load i64, ptr %l37, !tbaa !24
  %t81 = load i64, ptr %l38, !tbaa !24
  %t82 = icmp sle i64 %t80, %t81
  br i1 %t82, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_16d25af731eb828d_f9df92790de43871)
  unreachable
bb19:
  %t84 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !27
  %t86 = load i64, ptr %l35, !tbaa !24
  %t87 = load i64, ptr %l37, !tbaa !24
  %t88 = getelementptr i8, ptr %t85, i64 %t86
  %t89 = sub i64 %t87, %t86
  %t90 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t88, 1
  store { i64, ptr } %t91, ptr %rv
  br label %ret
bb20:
  call void @__olang_check_failed(ptr @olang_loc_16d25af731eb828d_f9df92790de43871)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca ptr
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca %"compiler/source:Span"
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca %"compiler/source:Span"
  %l16 = alloca ptr
  %l17 = alloca %"compiler/source:Span"
  %l18 = alloca { i64, ptr }
  %l19 = alloca %"compiler/source:Span"
  %l20 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l22 = alloca %"compiler/source:Span"
  %l23 = alloca ptr
  %l24 = alloca %"compiler/source:Span"
  %l25 = alloca ptr
  %l26 = alloca %"compiler/source:Span"
  %l27 = alloca { i64, ptr }
  %l28 = alloca ptr
  %l29 = alloca %"compiler/source:Span"
  %l30 = alloca { i64, ptr }
  %l31 = alloca %"compiler/source:Span"
  %l32 = alloca ptr
  %l33 = alloca %"compiler/source:Span"
  %l34 = alloca ptr
  %l35 = alloca %"compiler/source:Span"
  %l36 = alloca ptr
  %l37 = alloca %"compiler/source:Span"
  %l38 = alloca i32
  %l39 = alloca ptr
  %l40 = alloca %"compiler/source:Span"
  %l41 = alloca ptr
  %l42 = alloca %"compiler/source:Span"
  %l43 = alloca ptr
  %l44 = alloca ptr
  %l45 = alloca i64
  %l46 = alloca ptr
  %l48 = alloca ptr
  %l49 = alloca i64
  %l50 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l51 = alloca ptr
  %l52 = alloca i64
  %l54 = alloca i64
  %l55 = alloca { i64, ptr }
  %l56 = alloca i1
  %l57 = alloca { i64, ptr }
  %l58 = alloca ptr
  %l59 = alloca i64
  %l61 = alloca { { i64, [3 x i64] }, { i64, ptr } }
  %l62 = alloca { i64, [3 x i64] }
  %l63 = alloca { i64, ptr }
  %l64 = alloca i1
  %l65 = alloca %"compiler/source:Span"
  %l66 = alloca ptr
  %l67 = alloca %"compiler/source:Span"
  %l68 = alloca ptr
  %l69 = alloca i1
  %l70 = alloca %"compiler/source:Span"
  %l71 = alloca { i64, ptr }
  %l72 = alloca %"compiler/source:Span"
  %l73 = alloca ptr
  %l74 = alloca %"compiler/source:Span"
  %l75 = alloca { i64, ptr }
  %l76 = alloca ptr
  %l79 = alloca ptr
  %l80 = alloca i1
  %l90 = alloca ptr
  %l91 = alloca i1
  %l101 = alloca ptr
  %l102 = alloca i1
  %l112 = alloca ptr
  %l113 = alloca i1
  %l129 = alloca ptr
  %l130 = alloca i1
  %l143 = alloca ptr
  %l144 = alloca i1
  %l154 = alloca ptr
  %l155 = alloca i1
  %l165 = alloca ptr
  %l166 = alloca i1
  %l180 = alloca ptr
  %l181 = alloca i1
  %l191 = alloca ptr
  %l192 = alloca i1
  %l202 = alloca ptr
  %l203 = alloca i1
  %l216 = alloca ptr
  %l217 = alloca i1
  %l227 = alloca ptr
  %l228 = alloca i1
  %l238 = alloca ptr
  %l239 = alloca i1
  %l249 = alloca ptr
  %l250 = alloca i1
  %l260 = alloca ptr
  %l261 = alloca i1
  %l274 = alloca ptr
  %l275 = alloca i1
  %l283 = alloca ptr
  %l290 = alloca ptr
  %l291 = alloca i1
  %l303 = alloca i64
  %l308 = alloca ptr
  %l311 = alloca ptr
  %l313 = alloca %"compiler/source:Span"
  %l319 = alloca ptr
  %l326 = alloca ptr
  %l327 = alloca ptr
  %l329 = alloca ptr
  %l333 = alloca ptr
  %l336 = alloca i1
  %l340 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l348 = alloca i64
  %l352 = alloca i64
  %l354 = alloca i64
  %l359 = alloca i64
  %l364 = alloca { i64, ptr }
  %l365 = alloca { i64, ptr }
  %l366 = alloca i64
  %l367 = alloca { i64, ptr }
  %l368 = alloca { i64, ptr }
  %l369 = alloca { i64, ptr }
  %l370 = alloca i64
  %l371 = alloca { i64, ptr }
  %l374 = alloca i1
  %l377 = alloca i1
  %l381 = alloca { i64, ptr }
  %l384 = alloca { i64, ptr }
  %l385 = alloca i32
  %l387 = alloca i1
  %l388 = alloca { i64, ptr }
  %l391 = alloca i64
  %l393 = alloca i64
  %l394 = alloca { i64, ptr }
  %l398 = alloca ptr
  %l400 = alloca i64
  %l401 = alloca ptr
  %l404 = alloca ptr
  %l406 = alloca i32
  %l408 = alloca i32
  %l409 = alloca i64
  %l413 = alloca i64
  %l415 = alloca i64
  %l420 = alloca i64
  %l425 = alloca ptr
  %l427 = alloca %"compiler/source:Span"
  %l428 = alloca { i64, ptr }
  %l429 = alloca { i64, ptr }
  %l431 = alloca i64
  %l433 = alloca i64
  %l434 = alloca { i64, ptr }
  %l437 = alloca i1
  %l444 = alloca { { i64, [3 x i64] }, { i64, ptr } }
  %l446 = alloca { i64, ptr }
  %l447 = alloca i64
  %l448 = alloca { i64, ptr }
  %l455 = alloca ptr
  %l458 = alloca i1
  %l462 = alloca i1
  %l464 = alloca i1
  %l467 = alloca i1
  %l469 = alloca i1
  %l473 = alloca i1
  %l476 = alloca { i64, ptr }
  %l477 = alloca { i64, ptr }
  %l479 = alloca i64
  %l481 = alloca i64
  %l482 = alloca { i64, ptr }
  %l484 = alloca ptr
  %l486 = alloca i64
  %l488 = alloca i64
  %l489 = alloca %"compiler/source:Span"
  %l492 = alloca %"compiler/source:Span"
  %l493 = alloca i64
  %l494 = alloca i64
  %l496 = alloca { i64, ptr }
  %l508 = alloca %"compiler/check:AssertAsk"
  %l509 = alloca ptr
  %l510 = alloca i1
  %l520 = alloca ptr
  %l521 = alloca i1
  %l534 = alloca ptr
  %l535 = alloca i1
  %l542 = alloca ptr
  %l543 = alloca %"compiler/source:Span"
  %l548 = alloca ptr
  %l551 = alloca ptr
  %l552 = alloca i1
  %l562 = alloca ptr
  %l563 = alloca i1
  %l576 = alloca ptr
  %l578 = alloca %"compiler/source:Span"
  %s21 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s42 = alloca %olang.scope
  %t575 = alloca { i64, [5 x i64] }, align 8
  %t598 = alloca { i64, [3 x i64] }, align 8
  %t1068 = alloca %"compiler/check:AssertAsk", align 8
  %t1082 = alloca %"compiler/check:AssertAsk", align 8
  %t1176 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l79, !tbaa !29
  store i1 false, ptr %l80, !tbaa !21
  %t6 = load ptr, ptr %l79, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l79, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 22}
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l80, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l80, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [4 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", ptr }, ptr %t16, i32 0, i32 0
  %t18 = load %"compiler/source:Span", ptr %t17
  store %"compiler/source:Span" %t18, ptr %l2
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr { i64, [4 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", ptr }, ptr %t22, i32 0, i32 1
  %t24 = load ptr, ptr %t23
  store ptr %t24, ptr %l3, !tbaa !29
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load %"compiler/source:Span", ptr %l2
  %t28 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprStmt(ptr %v0, ptr %v1, ptr %t26, %"compiler/source:Span" %t27, ptr %t28)
  br label %bb9
bb9:
  br label %bb276
bb10:
  %t32 = load ptr, ptr %l1, !tbaa !29
  store ptr %t32, ptr %l90, !tbaa !29
  store i1 false, ptr %l91, !tbaa !21
  %t33 = load ptr, ptr %l90, !tbaa !29
  %t34 = icmp ne ptr %t33, null
  br i1 %t34, label %bb11, label %bb12
bb11:
  %t36 = load ptr, ptr %l90, !tbaa !29
  %t37 = load i64, ptr %t36, !range !{i64 0, i64 22}
  %t39 = icmp eq i64 %t37, 1
  store i1 %t39, ptr %l91, !tbaa !21
  br label %bb12
bb12:
  %t40 = load i1, ptr %l91, !tbaa !21
  br i1 %t40, label %bb13, label %bb14
bb13:
  %t41 = load ptr, ptr %l1, !tbaa !29
  %t43 = getelementptr { i64, [4 x i64] }, ptr %t41, i32 0, i32 1
  %t44 = getelementptr { %"compiler/source:Span", ptr }, ptr %t43, i32 0, i32 0
  %t45 = load %"compiler/source:Span", ptr %t44
  store %"compiler/source:Span" %t45, ptr %l4
  %t47 = load ptr, ptr %l1, !tbaa !29
  %t49 = getelementptr { i64, [4 x i64] }, ptr %t47, i32 0, i32 1
  %t50 = getelementptr { %"compiler/source:Span", ptr }, ptr %t49, i32 0, i32 1
  %t51 = load ptr, ptr %t50
  store ptr %t51, ptr %l5, !tbaa !29
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load %"compiler/source:Span", ptr %l4
  %t55 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evarDecl(ptr %v0, ptr %v1, ptr %t53, %"compiler/source:Span" %t54, ptr %t55)
  br label %bb16
bb16:
  br label %bb276
bb17:
  %t59 = load ptr, ptr %l1, !tbaa !29
  store ptr %t59, ptr %l101, !tbaa !29
  store i1 false, ptr %l102, !tbaa !21
  %t60 = load ptr, ptr %l101, !tbaa !29
  %t61 = icmp ne ptr %t60, null
  br i1 %t61, label %bb18, label %bb19
bb18:
  %t63 = load ptr, ptr %l101, !tbaa !29
  %t64 = load i64, ptr %t63, !range !{i64 0, i64 22}
  %t66 = icmp eq i64 %t64, 2
  store i1 %t66, ptr %l102, !tbaa !21
  br label %bb19
bb19:
  %t67 = load i1, ptr %l102, !tbaa !21
  br i1 %t67, label %bb20, label %bb21
bb20:
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t70 = getelementptr { i64, [4 x i64] }, ptr %t68, i32 0, i32 1
  %t71 = getelementptr { %"compiler/source:Span", ptr }, ptr %t70, i32 0, i32 0
  %t72 = load %"compiler/source:Span", ptr %t71
  store %"compiler/source:Span" %t72, ptr %l6
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr { i64, [4 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", ptr }, ptr %t76, i32 0, i32 1
  %t78 = load ptr, ptr %t77
  store ptr %t78, ptr %l7, !tbaa !29
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load %"compiler/source:Span", ptr %l6
  %t82 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emulti(ptr %v0, ptr %v1, ptr %t80, %"compiler/source:Span" %t81, ptr %t82)
  br label %bb23
bb23:
  br label %bb276
bb24:
  %t86 = load ptr, ptr %l1, !tbaa !29
  store ptr %t86, ptr %l112, !tbaa !29
  store i1 false, ptr %l113, !tbaa !21
  %t87 = load ptr, ptr %l112, !tbaa !29
  %t88 = icmp ne ptr %t87, null
  br i1 %t88, label %bb25, label %bb26
bb25:
  %t90 = load ptr, ptr %l112, !tbaa !29
  %t91 = load i64, ptr %t90, !range !{i64 0, i64 22}
  %t93 = icmp eq i64 %t91, 3
  store i1 %t93, ptr %l113, !tbaa !21
  br label %bb26
bb26:
  %t94 = load i1, ptr %l113, !tbaa !21
  br i1 %t94, label %bb27, label %bb28
bb27:
  %t95 = load ptr, ptr %l1, !tbaa !29
  %t97 = getelementptr { i64, [4 x i64] }, ptr %t95, i32 0, i32 1
  %t98 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t97, i32 0, i32 0
  %t99 = load %"compiler/source:Span", ptr %t98
  store %"compiler/source:Span" %t99, ptr %l8
  %t101 = load ptr, ptr %l1, !tbaa !29
  %t103 = getelementptr { i64, [4 x i64] }, ptr %t101, i32 0, i32 1
  %t104 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t103, i32 0, i32 1
  %t105 = load i32, ptr %t104, !range !{i32 0, i32 98}
  store i32 %t105, ptr %l9
  %t107 = load ptr, ptr %l1, !tbaa !29
  %t109 = getelementptr { i64, [4 x i64] }, ptr %t107, i32 0, i32 1
  %t110 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t109, i32 0, i32 2
  %t111 = load ptr, ptr %t110
  store ptr %t111, ptr %l10, !tbaa !29
  %t113 = load ptr, ptr %l1, !tbaa !29
  %t115 = getelementptr { i64, [4 x i64] }, ptr %t113, i32 0, i32 1
  %t116 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t115, i32 0, i32 3
  %t117 = load ptr, ptr %t116
  store ptr %t117, ptr %l11, !tbaa !29
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t120 = load %"compiler/source:Span", ptr %l8
  %t121 = load i32, ptr %l9, !range !{i32 0, i32 98}
  %t122 = load ptr, ptr %l10, !tbaa !29
  %t123 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eassign(ptr %v0, ptr %v1, ptr %v1, ptr %t119, %"compiler/source:Span" %t120, i32 %t121, ptr %t122, ptr %t123)
  br label %bb30
bb30:
  br label %bb276
bb31:
  %t129 = load ptr, ptr %l1, !tbaa !29
  store ptr %t129, ptr %l129, !tbaa !29
  store i1 false, ptr %l130, !tbaa !21
  %t130 = load ptr, ptr %l129, !tbaa !29
  %t131 = icmp ne ptr %t130, null
  br i1 %t131, label %bb32, label %bb33
bb32:
  %t133 = load ptr, ptr %l129, !tbaa !29
  %t134 = load i64, ptr %t133, !range !{i64 0, i64 22}
  %t136 = icmp eq i64 %t134, 4
  store i1 %t136, ptr %l130, !tbaa !21
  br label %bb33
bb33:
  %t137 = load i1, ptr %l130, !tbaa !21
  br i1 %t137, label %bb34, label %bb35
bb34:
  %t138 = load ptr, ptr %l1, !tbaa !29
  %t140 = getelementptr { i64, [4 x i64] }, ptr %t138, i32 0, i32 1
  %t141 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t140, i32 0, i32 0
  %t142 = load %"compiler/source:Span", ptr %t141
  store %"compiler/source:Span" %t142, ptr %l12
  %t144 = load ptr, ptr %l1, !tbaa !29
  %t146 = getelementptr { i64, [4 x i64] }, ptr %t144, i32 0, i32 1
  %t147 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t146, i32 0, i32 1
  %t148 = load ptr, ptr %t147
  store ptr %t148, ptr %l13, !tbaa !29
  %t150 = load ptr, ptr %l1, !tbaa !29
  %t152 = getelementptr { i64, [4 x i64] }, ptr %t150, i32 0, i32 1
  %t153 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t152, i32 0, i32 2
  %t154 = load { i64, ptr }, ptr %t153
  store { i64, ptr } %t154, ptr %l14, !tbaa !27
  br label %bb36
bb35:
  br label %bb38
bb36:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load %"compiler/source:Span", ptr %l12
  %t158 = load ptr, ptr %l13, !tbaa !29
  %t159 = load { i64, ptr }, ptr %l14, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etryStore(ptr %v0, ptr %v1, ptr %v1, ptr %t156, %"compiler/source:Span" %t157, ptr %t158, { i64, ptr } %t159)
  br label %bb37
bb37:
  br label %bb276
bb38:
  %t164 = load ptr, ptr %l1, !tbaa !29
  store ptr %t164, ptr %l143, !tbaa !29
  store i1 false, ptr %l144, !tbaa !21
  %t165 = load ptr, ptr %l143, !tbaa !29
  %t166 = icmp ne ptr %t165, null
  br i1 %t166, label %bb39, label %bb40
bb39:
  %t168 = load ptr, ptr %l143, !tbaa !29
  %t169 = load i64, ptr %t168, !range !{i64 0, i64 22}
  %t171 = icmp eq i64 %t169, 5
  store i1 %t171, ptr %l144, !tbaa !21
  br label %bb40
bb40:
  %t172 = load i1, ptr %l144, !tbaa !21
  br i1 %t172, label %bb41, label %bb42
bb41:
  %t173 = load ptr, ptr %l1, !tbaa !29
  %t175 = getelementptr { i64, [4 x i64] }, ptr %t173, i32 0, i32 1
  %t176 = getelementptr { %"compiler/source:Span", ptr }, ptr %t175, i32 0, i32 0
  %t177 = load %"compiler/source:Span", ptr %t176
  store %"compiler/source:Span" %t177, ptr %l15
  %t179 = load ptr, ptr %l1, !tbaa !29
  %t181 = getelementptr { i64, [4 x i64] }, ptr %t179, i32 0, i32 1
  %t182 = getelementptr { %"compiler/source:Span", ptr }, ptr %t181, i32 0, i32 1
  %t183 = load ptr, ptr %t182
  store ptr %t183, ptr %l16, !tbaa !29
  br label %bb43
bb42:
  br label %bb45
bb43:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t186 = load %"compiler/source:Span", ptr %l15
  %t187 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eifStmt(ptr %v0, ptr %v1, ptr %t185, %"compiler/source:Span" %t186, ptr %t187)
  br label %bb44
bb44:
  br label %bb276
bb45:
  %t191 = load ptr, ptr %l1, !tbaa !29
  store ptr %t191, ptr %l154, !tbaa !29
  store i1 false, ptr %l155, !tbaa !21
  %t192 = load ptr, ptr %l154, !tbaa !29
  %t193 = icmp ne ptr %t192, null
  br i1 %t193, label %bb46, label %bb47
bb46:
  %t195 = load ptr, ptr %l154, !tbaa !29
  %t196 = load i64, ptr %t195, !range !{i64 0, i64 22}
  %t198 = icmp eq i64 %t196, 6
  store i1 %t198, ptr %l155, !tbaa !21
  br label %bb47
bb47:
  %t199 = load i1, ptr %l155, !tbaa !21
  br i1 %t199, label %bb48, label %bb49
bb48:
  %t200 = load ptr, ptr %l1, !tbaa !29
  %t202 = getelementptr { i64, [4 x i64] }, ptr %t200, i32 0, i32 1
  %t203 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t202, i32 0, i32 0
  %t204 = load %"compiler/source:Span", ptr %t203
  store %"compiler/source:Span" %t204, ptr %l17
  %t206 = load ptr, ptr %l1, !tbaa !29
  %t208 = getelementptr { i64, [4 x i64] }, ptr %t206, i32 0, i32 1
  %t209 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t208, i32 0, i32 1
  %t210 = load { i64, ptr }, ptr %t209
  store { i64, ptr } %t210, ptr %l18, !tbaa !27
  br label %bb50
bb49:
  br label %bb52
bb50:
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t213 = load %"compiler/source:Span", ptr %l17
  %t214 = load { i64, ptr }, ptr %l18, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eloop(ptr %v0, ptr %v0, ptr %v1, ptr %v0, ptr %t212, %"compiler/source:Span" %t213, ptr null, { i64, ptr } %t214, ptr null)
  br label %bb51
bb51:
  br label %bb276
bb52:
  %t218 = load ptr, ptr %l1, !tbaa !29
  store ptr %t218, ptr %l165, !tbaa !29
  store i1 false, ptr %l166, !tbaa !21
  %t219 = load ptr, ptr %l165, !tbaa !29
  %t220 = icmp ne ptr %t219, null
  br i1 %t220, label %bb53, label %bb54
bb53:
  %t222 = load ptr, ptr %l165, !tbaa !29
  %t223 = load i64, ptr %t222, !range !{i64 0, i64 22}
  %t225 = icmp eq i64 %t223, 7
  store i1 %t225, ptr %l166, !tbaa !21
  br label %bb54
bb54:
  %t226 = load i1, ptr %l166, !tbaa !21
  br i1 %t226, label %bb55, label %bb56
bb55:
  %t227 = load ptr, ptr %l1, !tbaa !29
  %t229 = getelementptr { i64, [4 x i64] }, ptr %t227, i32 0, i32 1
  %t230 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t229, i32 0, i32 0
  %t231 = load %"compiler/source:Span", ptr %t230
  store %"compiler/source:Span" %t231, ptr %l19
  %t233 = load ptr, ptr %l1, !tbaa !29
  %t235 = getelementptr { i64, [4 x i64] }, ptr %t233, i32 0, i32 1
  %t236 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t235, i32 0, i32 1
  %t237 = load ptr, ptr %t236
  store ptr %t237, ptr %l20, !tbaa !29
  %t239 = load ptr, ptr %l1, !tbaa !29
  %t241 = getelementptr { i64, [4 x i64] }, ptr %t239, i32 0, i32 1
  %t242 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t241, i32 0, i32 2
  %t243 = load { i64, ptr }, ptr %t242
  store { i64, ptr } %t243, ptr %l21, !tbaa !27
  br label %bb57
bb56:
  br label %bb59
bb57:
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t246 = load %"compiler/source:Span", ptr %l19
  %t247 = load ptr, ptr %l20, !tbaa !29
  %t249 = load { i64, ptr }, ptr %l21, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eloop(ptr %v0, ptr %v1, ptr %v1, ptr %v0, ptr %t245, %"compiler/source:Span" %t246, ptr %t247, { i64, ptr } %t249, ptr null)
  br label %bb58
bb58:
  br label %bb276
bb59:
  %t254 = load ptr, ptr %l1, !tbaa !29
  store ptr %t254, ptr %l180, !tbaa !29
  store i1 false, ptr %l181, !tbaa !21
  %t255 = load ptr, ptr %l180, !tbaa !29
  %t256 = icmp ne ptr %t255, null
  br i1 %t256, label %bb60, label %bb61
bb60:
  %t258 = load ptr, ptr %l180, !tbaa !29
  %t259 = load i64, ptr %t258, !range !{i64 0, i64 22}
  %t261 = icmp eq i64 %t259, 8
  store i1 %t261, ptr %l181, !tbaa !21
  br label %bb61
bb61:
  %t262 = load i1, ptr %l181, !tbaa !21
  br i1 %t262, label %bb62, label %bb63
bb62:
  %t263 = load ptr, ptr %l1, !tbaa !29
  %t265 = getelementptr { i64, [4 x i64] }, ptr %t263, i32 0, i32 1
  %t266 = getelementptr { %"compiler/source:Span", ptr }, ptr %t265, i32 0, i32 0
  %t267 = load %"compiler/source:Span", ptr %t266
  store %"compiler/source:Span" %t267, ptr %l22
  %t269 = load ptr, ptr %l1, !tbaa !29
  %t271 = getelementptr { i64, [4 x i64] }, ptr %t269, i32 0, i32 1
  %t272 = getelementptr { %"compiler/source:Span", ptr }, ptr %t271, i32 0, i32 1
  %t273 = load ptr, ptr %t272
  store ptr %t273, ptr %l23, !tbaa !29
  br label %bb64
bb63:
  br label %bb66
bb64:
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t276 = load %"compiler/source:Span", ptr %l22
  %t277 = load ptr, ptr %l23, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efor3(ptr %v0, ptr %v1, ptr %t275, %"compiler/source:Span" %t276, ptr %t277)
  br label %bb65
bb65:
  br label %bb276
bb66:
  %t281 = load ptr, ptr %l1, !tbaa !29
  store ptr %t281, ptr %l191, !tbaa !29
  store i1 false, ptr %l192, !tbaa !21
  %t282 = load ptr, ptr %l191, !tbaa !29
  %t283 = icmp ne ptr %t282, null
  br i1 %t283, label %bb67, label %bb68
bb67:
  %t285 = load ptr, ptr %l191, !tbaa !29
  %t286 = load i64, ptr %t285, !range !{i64 0, i64 22}
  %t288 = icmp eq i64 %t286, 9
  store i1 %t288, ptr %l192, !tbaa !21
  br label %bb68
bb68:
  %t289 = load i1, ptr %l192, !tbaa !21
  br i1 %t289, label %bb69, label %bb70
bb69:
  %t290 = load ptr, ptr %l1, !tbaa !29
  %t292 = getelementptr { i64, [4 x i64] }, ptr %t290, i32 0, i32 1
  %t293 = getelementptr { %"compiler/source:Span", ptr }, ptr %t292, i32 0, i32 0
  %t294 = load %"compiler/source:Span", ptr %t293
  store %"compiler/source:Span" %t294, ptr %l24
  %t296 = load ptr, ptr %l1, !tbaa !29
  %t298 = getelementptr { i64, [4 x i64] }, ptr %t296, i32 0, i32 1
  %t299 = getelementptr { %"compiler/source:Span", ptr }, ptr %t298, i32 0, i32 1
  %t300 = load ptr, ptr %t299
  store ptr %t300, ptr %l25, !tbaa !29
  br label %bb71
bb70:
  br label %bb73
bb71:
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t303 = load %"compiler/source:Span", ptr %l24
  %t304 = load ptr, ptr %l25, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eforIn(ptr %v0, ptr %v1, ptr %t302, %"compiler/source:Span" %t303, ptr %t304)
  br label %bb72
bb72:
  br label %bb276
bb73:
  %t308 = load ptr, ptr %l1, !tbaa !29
  store ptr %t308, ptr %l202, !tbaa !29
  store i1 false, ptr %l203, !tbaa !21
  %t309 = load ptr, ptr %l202, !tbaa !29
  %t310 = icmp ne ptr %t309, null
  br i1 %t310, label %bb74, label %bb75
bb74:
  %t312 = load ptr, ptr %l202, !tbaa !29
  %t313 = load i64, ptr %t312, !range !{i64 0, i64 22}
  %t315 = icmp eq i64 %t313, 10
  store i1 %t315, ptr %l203, !tbaa !21
  br label %bb75
bb75:
  %t316 = load i1, ptr %l203, !tbaa !21
  br i1 %t316, label %bb76, label %bb77
bb76:
  %t317 = load ptr, ptr %l1, !tbaa !29
  %t319 = getelementptr { i64, [4 x i64] }, ptr %t317, i32 0, i32 1
  %t320 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t319, i32 0, i32 0
  %t321 = load %"compiler/source:Span", ptr %t320
  store %"compiler/source:Span" %t321, ptr %l26
  %t323 = load ptr, ptr %l1, !tbaa !29
  %t325 = getelementptr { i64, [4 x i64] }, ptr %t323, i32 0, i32 1
  %t326 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t325, i32 0, i32 1
  %t327 = load { i64, ptr }, ptr %t326
  store { i64, ptr } %t327, ptr %l27, !tbaa !27
  %t329 = load ptr, ptr %l1, !tbaa !29
  %t331 = getelementptr { i64, [4 x i64] }, ptr %t329, i32 0, i32 1
  %t332 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t331, i32 0, i32 2
  %t333 = load ptr, ptr %t332
  store ptr %t333, ptr %l28, !tbaa !29
  br label %bb78
bb77:
  br label %bb80
bb78:
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t336 = load %"compiler/source:Span", ptr %l26
  %t337 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t338 = load ptr, ptr %l28, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edoFor(ptr %v0, ptr %v1, ptr %v1, ptr %t335, %"compiler/source:Span" %t336, { i64, ptr } %t337, ptr %t338)
  br label %bb79
bb79:
  br label %bb276
bb80:
  %t343 = load ptr, ptr %l1, !tbaa !29
  store ptr %t343, ptr %l216, !tbaa !29
  store i1 false, ptr %l217, !tbaa !21
  %t344 = load ptr, ptr %l216, !tbaa !29
  %t345 = icmp ne ptr %t344, null
  br i1 %t345, label %bb81, label %bb82
bb81:
  %t347 = load ptr, ptr %l216, !tbaa !29
  %t348 = load i64, ptr %t347, !range !{i64 0, i64 22}
  %t350 = icmp eq i64 %t348, 12
  store i1 %t350, ptr %l217, !tbaa !21
  br label %bb82
bb82:
  %t351 = load i1, ptr %l217, !tbaa !21
  br i1 %t351, label %bb83, label %bb84
bb83:
  %t352 = load ptr, ptr %l1, !tbaa !29
  %t354 = getelementptr { i64, [4 x i64] }, ptr %t352, i32 0, i32 1
  %t355 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t354, i32 0, i32 0
  %t356 = load %"compiler/source:Span", ptr %t355
  store %"compiler/source:Span" %t356, ptr %l29
  %t358 = load ptr, ptr %l1, !tbaa !29
  %t360 = getelementptr { i64, [4 x i64] }, ptr %t358, i32 0, i32 1
  %t361 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t360, i32 0, i32 1
  %t362 = load { i64, ptr }, ptr %t361
  store { i64, ptr } %t362, ptr %l30, !tbaa !27
  br label %bb85
bb84:
  br label %bb87
bb85:
  %t364 = load ptr, ptr %l0, !tbaa !29
  %t365 = load %"compiler/source:Span", ptr %l29
  %t366 = load { i64, ptr }, ptr %l30, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereturnStmt(ptr %v0, ptr %v1, ptr %t364, %"compiler/source:Span" %t365, { i64, ptr } %t366)
  br label %bb86
bb86:
  br label %bb276
bb87:
  %t370 = load ptr, ptr %l1, !tbaa !29
  store ptr %t370, ptr %l227, !tbaa !29
  store i1 false, ptr %l228, !tbaa !21
  %t371 = load ptr, ptr %l227, !tbaa !29
  %t372 = icmp ne ptr %t371, null
  br i1 %t372, label %bb88, label %bb89
bb88:
  %t374 = load ptr, ptr %l227, !tbaa !29
  %t375 = load i64, ptr %t374, !range !{i64 0, i64 22}
  %t377 = icmp eq i64 %t375, 15
  store i1 %t377, ptr %l228, !tbaa !21
  br label %bb89
bb89:
  %t378 = load i1, ptr %l228, !tbaa !21
  br i1 %t378, label %bb90, label %bb91
bb90:
  %t379 = load ptr, ptr %l1, !tbaa !29
  %t381 = getelementptr { i64, [4 x i64] }, ptr %t379, i32 0, i32 1
  %t382 = getelementptr { %"compiler/source:Span", ptr }, ptr %t381, i32 0, i32 0
  %t383 = load %"compiler/source:Span", ptr %t382
  store %"compiler/source:Span" %t383, ptr %l31
  %t385 = load ptr, ptr %l1, !tbaa !29
  %t387 = getelementptr { i64, [4 x i64] }, ptr %t385, i32 0, i32 1
  %t388 = getelementptr { %"compiler/source:Span", ptr }, ptr %t387, i32 0, i32 1
  %t389 = load ptr, ptr %t388
  store ptr %t389, ptr %l32, !tbaa !29
  br label %bb92
bb91:
  br label %bb94
bb92:
  %t391 = load ptr, ptr %l0, !tbaa !29
  %t392 = load %"compiler/source:Span", ptr %l31
  %t393 = load ptr, ptr %l32, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebecomeStmt(ptr %v0, ptr %v1, ptr %t391, %"compiler/source:Span" %t392, ptr %t393)
  br label %bb93
bb93:
  br label %bb276
bb94:
  %t397 = load ptr, ptr %l1, !tbaa !29
  store ptr %t397, ptr %l238, !tbaa !29
  store i1 false, ptr %l239, !tbaa !21
  %t398 = load ptr, ptr %l238, !tbaa !29
  %t399 = icmp ne ptr %t398, null
  br i1 %t399, label %bb95, label %bb96
bb95:
  %t401 = load ptr, ptr %l238, !tbaa !29
  %t402 = load i64, ptr %t401, !range !{i64 0, i64 22}
  %t404 = icmp eq i64 %t402, 21
  store i1 %t404, ptr %l239, !tbaa !21
  br label %bb96
bb96:
  %t405 = load i1, ptr %l239, !tbaa !21
  br i1 %t405, label %bb97, label %bb98
bb97:
  %t406 = load ptr, ptr %l1, !tbaa !29
  %t408 = getelementptr { i64, [4 x i64] }, ptr %t406, i32 0, i32 1
  %t409 = getelementptr { %"compiler/source:Span", ptr }, ptr %t408, i32 0, i32 0
  %t410 = load %"compiler/source:Span", ptr %t409
  store %"compiler/source:Span" %t410, ptr %l33
  %t412 = load ptr, ptr %l1, !tbaa !29
  %t414 = getelementptr { i64, [4 x i64] }, ptr %t412, i32 0, i32 1
  %t415 = getelementptr { %"compiler/source:Span", ptr }, ptr %t414, i32 0, i32 1
  %t416 = load ptr, ptr %t415
  store ptr %t416, ptr %l34, !tbaa !29
  br label %bb99
bb98:
  br label %bb101
bb99:
  %t418 = load ptr, ptr %l0, !tbaa !29
  %t419 = load %"compiler/source:Span", ptr %l33
  %t420 = load ptr, ptr %l34, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eyieldStmt(ptr %v0, ptr %v1, ptr %t418, %"compiler/source:Span" %t419, ptr %t420)
  br label %bb100
bb100:
  br label %bb276
bb101:
  %t424 = load ptr, ptr %l1, !tbaa !29
  store ptr %t424, ptr %l249, !tbaa !29
  store i1 false, ptr %l250, !tbaa !21
  %t425 = load ptr, ptr %l249, !tbaa !29
  %t426 = icmp ne ptr %t425, null
  br i1 %t426, label %bb102, label %bb103
bb102:
  %t428 = load ptr, ptr %l249, !tbaa !29
  %t429 = load i64, ptr %t428, !range !{i64 0, i64 22}
  %t431 = icmp eq i64 %t429, 11
  store i1 %t431, ptr %l250, !tbaa !21
  br label %bb103
bb103:
  %t432 = load i1, ptr %l250, !tbaa !21
  br i1 %t432, label %bb104, label %bb105
bb104:
  %t433 = load ptr, ptr %l1, !tbaa !29
  %t435 = getelementptr { i64, [4 x i64] }, ptr %t433, i32 0, i32 1
  %t436 = getelementptr { %"compiler/source:Span", ptr }, ptr %t435, i32 0, i32 0
  %t437 = load %"compiler/source:Span", ptr %t436
  store %"compiler/source:Span" %t437, ptr %l35
  %t439 = load ptr, ptr %l1, !tbaa !29
  %t441 = getelementptr { i64, [4 x i64] }, ptr %t439, i32 0, i32 1
  %t442 = getelementptr { %"compiler/source:Span", ptr }, ptr %t441, i32 0, i32 1
  %t443 = load ptr, ptr %t442
  store ptr %t443, ptr %l36, !tbaa !29
  br label %bb106
bb105:
  br label %bb108
bb106:
  %t445 = load ptr, ptr %l0, !tbaa !29
  %t446 = load %"compiler/source:Span", ptr %l35
  %t447 = load ptr, ptr %l36, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ematchStmt(ptr %v0, ptr %v1, ptr %t445, %"compiler/source:Span" %t446, ptr %t447)
  br label %bb107
bb107:
  br label %bb276
bb108:
  %t451 = load ptr, ptr %l1, !tbaa !29
  store ptr %t451, ptr %l260, !tbaa !29
  store i1 false, ptr %l261, !tbaa !21
  %t452 = load ptr, ptr %l260, !tbaa !29
  %t453 = icmp ne ptr %t452, null
  br i1 %t453, label %bb109, label %bb110
bb109:
  %t455 = load ptr, ptr %l260, !tbaa !29
  %t456 = load i64, ptr %t455, !range !{i64 0, i64 22}
  %t458 = icmp eq i64 %t456, 13
  store i1 %t458, ptr %l261, !tbaa !21
  br label %bb110
bb110:
  %t459 = load i1, ptr %l261, !tbaa !21
  br i1 %t459, label %bb111, label %bb112
bb111:
  %t460 = load ptr, ptr %l1, !tbaa !29
  %t462 = getelementptr { i64, [4 x i64] }, ptr %t460, i32 0, i32 1
  %t463 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t462, i32 0, i32 0
  %t464 = load %"compiler/source:Span", ptr %t463
  store %"compiler/source:Span" %t464, ptr %l37
  %t466 = load ptr, ptr %l1, !tbaa !29
  %t468 = getelementptr { i64, [4 x i64] }, ptr %t466, i32 0, i32 1
  %t469 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t468, i32 0, i32 1
  %t470 = load i32, ptr %t469, !range !{i32 0, i32 98}
  store i32 %t470, ptr %l38
  %t472 = load ptr, ptr %l1, !tbaa !29
  %t474 = getelementptr { i64, [4 x i64] }, ptr %t472, i32 0, i32 1
  %t475 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t474, i32 0, i32 2
  %t476 = load ptr, ptr %t475
  store ptr %t476, ptr %l39, !tbaa !29
  br label %bb113
bb112:
  br label %bb115
bb113:
  %t478 = load ptr, ptr %l0, !tbaa !29
  %t479 = load %"compiler/source:Span", ptr %l37
  %t480 = load i32, ptr %l38, !range !{i32 0, i32 98}
  %t481 = load ptr, ptr %l39, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ejump(ptr %v0, ptr %v1, ptr %t478, %"compiler/source:Span" %t479, i32 %t480, ptr %t481)
  br label %bb114
bb114:
  br label %bb276
bb115:
  %t486 = load ptr, ptr %l1, !tbaa !29
  store ptr %t486, ptr %l274, !tbaa !29
  store i1 false, ptr %l275, !tbaa !21
  %t487 = load ptr, ptr %l274, !tbaa !29
  %t488 = icmp ne ptr %t487, null
  br i1 %t488, label %bb116, label %bb117
bb116:
  %t490 = load ptr, ptr %l274, !tbaa !29
  %t491 = load i64, ptr %t490, !range !{i64 0, i64 22}
  %t493 = icmp eq i64 %t491, 14
  store i1 %t493, ptr %l275, !tbaa !21
  br label %bb117
bb117:
  %t494 = load i1, ptr %l275, !tbaa !21
  br i1 %t494, label %bb118, label %bb119
bb118:
  %t495 = load ptr, ptr %l1, !tbaa !29
  %t497 = getelementptr { i64, [4 x i64] }, ptr %t495, i32 0, i32 1
  %t498 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t497, i32 0, i32 0
  %t499 = load %"compiler/source:Span", ptr %t498
  store %"compiler/source:Span" %t499, ptr %l40
  %t501 = load ptr, ptr %l1, !tbaa !29
  %t503 = getelementptr { i64, [4 x i64] }, ptr %t501, i32 0, i32 1
  %t504 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t503, i32 0, i32 1
  %t505 = load ptr, ptr %t504
  store ptr %t505, ptr %l41, !tbaa !29
  br label %bb120
bb119:
  br label %bb125
bb120:
  %t507 = load ptr, ptr %l0, !tbaa !29
  %t509 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t507)
  store ptr %t509, ptr %l283
  br label %bb121
bb121:
  %t510 = load ptr, ptr %l283, !tbaa !29
  %t512 = getelementptr %"compiler/check:frame", ptr %t510, i32 0, i32 51
  %t513 = load i64, ptr %t512, !tbaa !24
  %t515 = icmp ne i64 %t513, 0
  br i1 %t515, label %bb122, label %bb123
bb122:
  %t517 = load ptr, ptr %l0, !tbaa !29
  %t518 = load %"compiler/source:Span", ptr %l40
  %t519 = load ptr, ptr %l41, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectCond(ptr %v0, ptr %v1, ptr %t517, %"compiler/source:Span" %t518, ptr %t519)
  br label %bb124
bb123:
  br label %bb125
bb124:
  br label %bb276
bb125:
  %t523 = load ptr, ptr %l1, !tbaa !29
  store ptr %t523, ptr %l290, !tbaa !29
  store i1 false, ptr %l291, !tbaa !21
  %t524 = load ptr, ptr %l290, !tbaa !29
  %t525 = icmp ne ptr %t524, null
  br i1 %t525, label %bb126, label %bb127
bb126:
  %t527 = load ptr, ptr %l290, !tbaa !29
  %t528 = load i64, ptr %t527, !range !{i64 0, i64 22}
  %t530 = icmp eq i64 %t528, 14
  store i1 %t530, ptr %l291, !tbaa !21
  br label %bb127
bb127:
  %t531 = load i1, ptr %l291, !tbaa !21
  br i1 %t531, label %bb128, label %bb129
bb128:
  %t532 = load ptr, ptr %l1, !tbaa !29
  %t534 = getelementptr { i64, [4 x i64] }, ptr %t532, i32 0, i32 1
  %t535 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t534, i32 0, i32 0
  %t536 = load %"compiler/source:Span", ptr %t535
  store %"compiler/source:Span" %t536, ptr %l42
  %t538 = load ptr, ptr %l1, !tbaa !29
  %t540 = getelementptr { i64, [4 x i64] }, ptr %t538, i32 0, i32 1
  %t541 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t540, i32 0, i32 1
  %t542 = load ptr, ptr %t541
  store ptr %t542, ptr %l43, !tbaa !29
  %t544 = load ptr, ptr %l1, !tbaa !29
  %t546 = getelementptr { i64, [4 x i64] }, ptr %t544, i32 0, i32 1
  %t547 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t546, i32 0, i32 2
  %t548 = load ptr, ptr %t547
  store ptr %t548, ptr %l44, !tbaa !29
  br label %bb130
bb129:
  br label %bb233
bb130:
  %t550 = load ptr, ptr %l0, !tbaa !29
  %t551 = load ptr, ptr %l43, !tbaa !29
  %t555 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflDecide(ptr %v0, ptr %v1, ptr %t550, ptr %t551)
  store i64 %t555, ptr %l303
  br label %bb131
bb131:
  %t556 = load i64, ptr %l303, !tbaa !24
  store i64 %t556, ptr %l45, !tbaa !24
  %t557 = load i64, ptr %l45, !tbaa !24
  %t559 = icmp eq i64 %t557, 1
  br i1 %t559, label %bb132, label %bb133
bb132:
  br label %ret
bb133:
  br label %bb134
bb134:
  %t561 = load i64, ptr %l45, !tbaa !24
  %t563 = icmp slt i64 %t561, 0
  br i1 %t563, label %bb135, label %bb136
bb135:
  %t565 = load ptr, ptr %l0, !tbaa !29
  %t566 = load ptr, ptr %l43, !tbaa !29
  %t569 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econd1(ptr %v0, ptr %v1, ptr %v0, ptr %t565, ptr %t566)
  store ptr %t569, ptr %l311
  br label %bb137
bb136:
  %t570 = load ptr, ptr %l43, !tbaa !29
  %t572 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t570)
  store %"compiler/source:Span" %t572, ptr %l313
  br label %bb138
bb137:
  %t573 = load ptr, ptr %l311, !tbaa !29
  store ptr %t573, ptr %l308, !tbaa !29
  br label %bb139
bb138:
  %t574 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store { i64, [5 x i64] } zeroinitializer, ptr %t575
  %t576 = getelementptr { i64, [5 x i64] }, ptr %t575, i32 0, i32 0
  store i64 0, ptr %t576
  %t577 = load %"compiler/source:Span", ptr %l313
  %t578 = insertvalue { %"compiler/source:Span", i32, i64 } undef, %"compiler/source:Span" %t577, 0
  %t580 = insertvalue { %"compiler/source:Span", i32, i64 } %t578, i32 %t574, 1
  %t581 = insertvalue { %"compiler/source:Span", i32, i64 } %t580, i64 0, 2
  %t582 = getelementptr { i64, [5 x i64] }, ptr %t575, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64 } %t581, ptr %t582
  %t583 = load { i64, [5 x i64] }, ptr %t575
  %t585 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t583, ptr %t585
  store ptr %t585, ptr %l308, !tbaa !29
  br label %bb139
bb139:
  %t587 = load ptr, ptr %l308, !tbaa !29
  store ptr %t587, ptr %l46, !tbaa !29
  %t588 = load ptr, ptr %l0, !tbaa !29
  %t589 = load ptr, ptr %l44, !tbaa !29
  %t592 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emessage(ptr %v0, ptr %v1, ptr %v0, ptr %t588, ptr %t589, i1 false)
  store ptr %t592, ptr %l319
  br label %bb140
bb140:
  %t593 = load ptr, ptr %l319, !tbaa !29
  %t594 = load ptr, ptr %l0, !tbaa !29
  %t595 = load %"compiler/source:Span", ptr %l42
  %t596 = load ptr, ptr %l46, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t598
  %t599 = getelementptr { i64, [3 x i64] }, ptr %t598, i32 0, i32 0
  store i64 10, ptr %t599
  %t601 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t595, 0
  %t603 = insertvalue { %"compiler/source:Span", ptr, ptr } %t601, ptr %t596, 1
  %t605 = insertvalue { %"compiler/source:Span", ptr, ptr } %t603, ptr %t593, 2
  %t606 = getelementptr { i64, [3 x i64] }, ptr %t598, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t605, ptr %t606
  %t607 = load { i64, [3 x i64] }, ptr %t598
  %t609 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t607, ptr %t609
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t594, ptr %t609)
  br label %bb141
bb141:
  %t612 = load ptr, ptr %l0, !tbaa !29
  store ptr %t612, ptr %l326, !tbaa !29
  %t613 = load ptr, ptr %l43, !tbaa !29
  store ptr %t613, ptr %l327, !tbaa !29
  %t614 = load ptr, ptr %l0, !tbaa !29
  %t616 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t614)
  store ptr %t616, ptr %l329
  br label %bb142
bb142:
  %t617 = load ptr, ptr %l329, !tbaa !29
  %t619 = getelementptr %"compiler/check:frame", ptr %t617, i32 0, i32 7
  %t620 = load i64, ptr %t619, !tbaa !24
  %t621 = load ptr, ptr %l326, !tbaa !29
  %t622 = load ptr, ptr %l327, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushFacts(ptr %v0, ptr %v1, ptr %t621, ptr %t622, i1 true, i64 %t620)
  br label %bb143
bb143:
  %t624 = load ptr, ptr %l0, !tbaa !29
  %t626 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t624)
  store ptr %t626, ptr %l333
  br label %bb144
bb144:
  %t627 = load ptr, ptr %l333, !tbaa !29
  store ptr %t627, ptr %l48, !tbaa !29
  %t628 = load ptr, ptr %l0, !tbaa !29
  %t630 = getelementptr %"compiler/check:Checker", ptr %t628, i32 0, i32 2
  %t631 = load i1, ptr %t630, !tbaa !21
  br i1 %t631, label %bb145, label %bb146
bb145:
  store i1 true, ptr %l336, !tbaa !21
  br label %bb147
bb146:
  %t633 = load ptr, ptr %l48, !tbaa !29
  %t635 = getelementptr %"compiler/check:frame", ptr %t633, i32 0, i32 12
  %t636 = load i1, ptr %t635, !tbaa !21
  %t638 = xor i1 %t636, true
  store i1 %t638, ptr %l336, !tbaa !21
  br label %bb147
bb147:
  %t640 = load i1, ptr %l336, !tbaa !21
  br i1 %t640, label %bb148, label %bb149
bb148:
  store %olang.scope zeroinitializer, ptr %s21
  store i64 -1, ptr %l49, !tbaa !24
  %t641 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s21, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t641, ptr %l340
  br label %bb150
bb149:
  br label %bb232
bb150:
  %t642 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l340
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t642, ptr %l50
  %t643 = load i64, ptr %l45, !tbaa !24
  %t645 = icmp slt i64 %t643, 0
  br i1 %t645, label %bb151, label %bb152
bb151:
  %t647 = load ptr, ptr %l0, !tbaa !29
  %t649 = getelementptr %"compiler/check:Checker", ptr %t647, i32 0, i32 111
  store i1 true, ptr %t649, !tbaa !21
  %t650 = load ptr, ptr %l0, !tbaa !29
  %t651 = load ptr, ptr %l48, !tbaa !29
  %t653 = getelementptr %"compiler/check:frame", ptr %t651, i32 0, i32 1
  %t654 = load i64, ptr %t653, !tbaa !24
  %t655 = load ptr, ptr %l43, !tbaa !29
  %t659 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eCondBody(ptr %v0, ptr %v1, ptr %t650, i64 %t654, ptr %t655)
  store i64 %t659, ptr %l348
  br label %bb153
bb152:
  br label %bb163
bb153:
  %t660 = load i64, ptr %l348, !tbaa !24
  store i64 %t660, ptr %l49, !tbaa !24
  %t661 = load ptr, ptr %l0, !tbaa !29
  %t663 = getelementptr %"compiler/check:Checker", ptr %t661, i32 0, i32 111
  store i1 false, ptr %t663, !tbaa !21
  %t664 = load ptr, ptr %l0, !tbaa !29
  %t666 = getelementptr %"compiler/check:Checker", ptr %t664, i32 0, i32 120
  store ptr %t666, ptr %l51, !tbaa !29
  store i64 0, ptr %l52, !tbaa !24
  br label %bb154
bb154:
  %t668 = load i64, ptr %l52, !tbaa !24
  store i64 %t668, ptr %l352, !tbaa !24
  %t669 = load ptr, ptr %l51, !tbaa !29
  %t671 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t669)
  store i64 %t671, ptr %l354
  br label %bb155
bb155:
  %t672 = load i64, ptr %l352, !tbaa !24
  %t673 = load i64, ptr %l354, !tbaa !24
  %t674 = icmp slt i64 %t672, %t673
  %t676 = xor i1 %t674, true
  br i1 %t676, label %bb156, label %bb157
bb156:
  br label %bb162
bb157:
  br label %bb158
bb158:
  %t678 = load ptr, ptr %l51, !tbaa !29
  %t679 = load i64, ptr %l52, !tbaa !24
  %t682 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t678, i64 %t679)
  store i64 %t682, ptr %l359
  br label %bb159
bb159:
  %t683 = load i64, ptr %l359, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s21, ptr %l50, i64 %t683)
  br label %bb160
bb160:
  br label %bb161
bb161:
  %t687 = load i64, ptr %l52, !tbaa !24
  %t689 = add i64 %t687, 1
  store i64 %t689, ptr %l52, !tbaa !24
  br label %bb154
bb162:
  br label %bb163
bb163:
  store i64 -1, ptr %l54, !tbaa !24
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d24, i32 0, i32 1) }, ptr %l364, !tbaa !27
  %t691 = load { i64, ptr }, ptr %l364, !tbaa !27
  store { i64, ptr } %t691, ptr %l365, !tbaa !27
  %t692 = load { i64, ptr }, ptr %l365, !tbaa !27
  %t693 = extractvalue { i64, ptr } %t692, 0
  store i64 %t693, ptr %l366, !tbaa !24
  %t694 = load i64, ptr %l366, !tbaa !24
  %t695 = mul i64 %t694, 1
  %t696 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t695)
  %t697 = insertvalue { i64, ptr } undef, i64 %t694, 0
  %t698 = insertvalue { i64, ptr } %t697, ptr %t696, 1
  store { i64, ptr } %t698, ptr %l367, !tbaa !27
  %t699 = getelementptr { i64, ptr }, ptr %l367, i32 0, i32 1
  %t700 = load ptr, ptr %t699, !tbaa !27
  %t701 = getelementptr { i64, ptr }, ptr %l365, i32 0, i32 1
  %t702 = load ptr, ptr %t701, !tbaa !27
  %t703 = load i64, ptr %l366, !tbaa !24
  %t704 = mul i64 %t703, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t700, ptr %t702, i64 %t704, i1 false)
  %t705 = load { i64, ptr }, ptr %l367, !tbaa !27
  store { i64, ptr } %t705, ptr %l55, !tbaa !27
  store i1 false, ptr %l56, !tbaa !21
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d25, i32 0, i32 1) }, ptr %l368, !tbaa !27
  %t706 = load { i64, ptr }, ptr %l368, !tbaa !27
  store { i64, ptr } %t706, ptr %l369, !tbaa !27
  %t707 = load { i64, ptr }, ptr %l369, !tbaa !27
  %t708 = extractvalue { i64, ptr } %t707, 0
  store i64 %t708, ptr %l370, !tbaa !24
  %t709 = load i64, ptr %l370, !tbaa !24
  %t710 = mul i64 %t709, 1
  %t711 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t710)
  %t712 = insertvalue { i64, ptr } undef, i64 %t709, 0
  %t713 = insertvalue { i64, ptr } %t712, ptr %t711, 1
  store { i64, ptr } %t713, ptr %l371, !tbaa !27
  %t714 = getelementptr { i64, ptr }, ptr %l371, i32 0, i32 1
  %t715 = load ptr, ptr %t714, !tbaa !27
  %t716 = getelementptr { i64, ptr }, ptr %l369, i32 0, i32 1
  %t717 = load ptr, ptr %t716, !tbaa !27
  %t718 = load i64, ptr %l370, !tbaa !24
  %t719 = mul i64 %t718, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t715, ptr %t717, i64 %t719, i1 false)
  %t720 = load { i64, ptr }, ptr %l371, !tbaa !27
  store { i64, ptr } %t720, ptr %l57, !tbaa !27
  %t721 = load i64, ptr %l49, !tbaa !24
  %t723 = icmp sge i64 %t721, 0
  br i1 %t723, label %bb164, label %bb165
bb164:
  store i1 true, ptr %l374, !tbaa !21
  br label %bb166
bb165:
  %t725 = load i64, ptr %l45, !tbaa !24
  %t727 = icmp eq i64 %t725, 0
  store i1 %t727, ptr %l374, !tbaa !21
  br label %bb166
bb166:
  %t729 = load i1, ptr %l374, !tbaa !21
  br i1 %t729, label %bb167, label %bb168
bb167:
  %t730 = load ptr, ptr %l44, !tbaa !29
  %t732 = icmp eq ptr %t730, null
  %t734 = xor i1 %t732, true
  store i1 %t734, ptr %l377, !tbaa !21
  br label %bb169
bb168:
  store i1 false, ptr %l377, !tbaa !21
  br label %bb169
bb169:
  %t736 = load i1, ptr %l377, !tbaa !21
  br i1 %t736, label %bb170, label %bb171
bb170:
  store i1 true, ptr %l56, !tbaa !21
  %t737 = load ptr, ptr %l0, !tbaa !29
  %t738 = load ptr, ptr %l44, !tbaa !29
  %t741 = call { i32, { i64, ptr } } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflText(ptr %v0, ptr %v1, ptr %s21, ptr %t737, ptr %t738)
  %t742 = extractvalue { i32, { i64, ptr } } %t741, 1
  %t743 = extractvalue { i32, { i64, ptr } } %t741, 0
  store i32 %t743, ptr %l385
  %t744 = icmp ne i32 %t743, 0
  br i1 %t744, label %bb173, label %ok.745, !prof !99
ok.745:
  store { i64, ptr } %t742, ptr %l384
  br label %bb172
bb171:
  br label %bb199
bb172:
  %t746 = load { i64, ptr }, ptr %l384, !tbaa !27
  store { i64, ptr } %t746, ptr %l381, !tbaa !27
  br label %bb175
bb173:
  %t747 = load i32, ptr %l385, !tbaa !23
  %t748 = ashr i32 %t747, 16
  %t750 = icmp eq i32 %t748, 1
  store i1 %t750, ptr %l387, !tbaa !21
  br label %bb174
bb174:
  call void @__olang_ert_req_clear()
  store i1 false, ptr %l56, !tbaa !21
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d26, i32 0, i32 1) }, ptr %l388, !tbaa !27
  %t751 = load { i64, ptr }, ptr %l388, !tbaa !27
  store { i64, ptr } %t751, ptr %l381, !tbaa !27
  br label %bb175
bb175:
  %t753 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t754 = extractvalue { i64, ptr } %t753, 0
  %t755 = load { i64, ptr }, ptr %l381, !tbaa !27
  %t756 = extractvalue { i64, ptr } %t755, 0
  store i64 %t756, ptr %l391, !tbaa !24
  %t758 = load i64, ptr %l391, !tbaa !24
  %t759 = icmp eq i64 %t754, %t758
  br i1 %t759, label %bb176, label %bb177
bb176:
  %t761 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t762 = load ptr, ptr %t761, !tbaa !27
  %t763 = getelementptr { i64, ptr }, ptr %l381, i32 0, i32 1
  %t764 = load ptr, ptr %t763, !tbaa !27
  %t765 = load i64, ptr %l391, !tbaa !24
  %t766 = mul i64 %t765, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t762, ptr %t764, i64 %t766, i1 false)
  br label %bb178
bb177:
  %t767 = load { i64, ptr }, ptr %l381, !tbaa !27
  %t768 = extractvalue { i64, ptr } %t767, 0
  store i64 %t768, ptr %l393, !tbaa !24
  %t769 = load i64, ptr %l393, !tbaa !24
  %t770 = mul i64 %t769, 1
  %t771 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t770)
  %t772 = insertvalue { i64, ptr } undef, i64 %t769, 0
  %t773 = insertvalue { i64, ptr } %t772, ptr %t771, 1
  store { i64, ptr } %t773, ptr %l394, !tbaa !27
  %t774 = getelementptr { i64, ptr }, ptr %l394, i32 0, i32 1
  %t775 = load ptr, ptr %t774, !tbaa !27
  %t776 = getelementptr { i64, ptr }, ptr %l381, i32 0, i32 1
  %t777 = load ptr, ptr %t776, !tbaa !27
  %t778 = load i64, ptr %l393, !tbaa !24
  %t779 = mul i64 %t778, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t775, ptr %t777, i64 %t779, i1 false)
  %t780 = load { i64, ptr }, ptr %l394, !tbaa !27
  store { i64, ptr } %t780, ptr %l55, !tbaa !27
  br label %bb178
bb178:
  %t781 = load i1, ptr %l56, !tbaa !21
  %t783 = xor i1 %t781, true
  br i1 %t783, label %bb179, label %bb180
bb179:
  store %olang.scope zeroinitializer, ptr %s28
  %t785 = load ptr, ptr %l0, !tbaa !29
  %t787 = getelementptr %"compiler/check:Checker", ptr %t785, i32 0, i32 111
  store i1 true, ptr %t787, !tbaa !21
  %t788 = load ptr, ptr %l0, !tbaa !29
  store ptr %t788, ptr %l398, !tbaa !29
  %t789 = load ptr, ptr %l48, !tbaa !29
  %t791 = getelementptr %"compiler/check:frame", ptr %t789, i32 0, i32 1
  %t792 = load i64, ptr %t791, !tbaa !24
  store i64 %t792, ptr %l400, !tbaa !24
  %t793 = load ptr, ptr %l44, !tbaa !29
  store ptr %t793, ptr %l401, !tbaa !29
  %t794 = load ptr, ptr %l0, !tbaa !29
  %t796 = getelementptr %"compiler/check:Checker", ptr %t794, i32 0, i32 1
  %t797 = load ptr, ptr %t796, !tbaa !29
  %t799 = getelementptr %"compiler/generic:Program", ptr %t797, i32 0, i32 2
  store ptr %t799, ptr %l404, !tbaa !29
  %t800 = load ptr, ptr %l0, !tbaa !29
  %t802 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t800)
  store i32 %t802, ptr %l406
  br label %bb181
bb180:
  br label %bb198
bb181:
  %t803 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t804 = load ptr, ptr %l404, !tbaa !29
  %t805 = load i32, ptr %l406, !tbaa !23
  %t807 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t804, i32 %t805, i64 %t803)
  store i32 %t807, ptr %l408
  br label %bb182
bb182:
  %t808 = load ptr, ptr %l398, !tbaa !29
  %t809 = load i64, ptr %l400, !tbaa !24
  %t810 = load ptr, ptr %l401, !tbaa !29
  %t811 = load i32, ptr %l408, !tbaa !23
  %t812 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eExprBody(ptr %v0, ptr %v1, ptr %t808, i64 %t809, ptr %t810, i32 %t811)
  store i64 %t812, ptr %l409
  br label %bb183
bb183:
  %t813 = load i64, ptr %l409, !tbaa !24
  store i64 %t813, ptr %l54, !tbaa !24
  %t814 = load ptr, ptr %l0, !tbaa !29
  %t816 = getelementptr %"compiler/check:Checker", ptr %t814, i32 0, i32 111
  store i1 false, ptr %t816, !tbaa !21
  %t817 = load ptr, ptr %l0, !tbaa !29
  %t819 = getelementptr %"compiler/check:Checker", ptr %t817, i32 0, i32 120
  store ptr %t819, ptr %l58, !tbaa !29
  store i64 0, ptr %l59, !tbaa !24
  br label %bb184
bb184:
  %t821 = load i64, ptr %l59, !tbaa !24
  store i64 %t821, ptr %l413, !tbaa !24
  %t822 = load ptr, ptr %l58, !tbaa !29
  %t824 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t822)
  store i64 %t824, ptr %l415
  br label %bb185
bb185:
  %t825 = load i64, ptr %l413, !tbaa !24
  %t826 = load i64, ptr %l415, !tbaa !24
  %t827 = icmp slt i64 %t825, %t826
  %t829 = xor i1 %t827, true
  br i1 %t829, label %bb186, label %bb187
bb186:
  br label %bb192
bb187:
  br label %bb188
bb188:
  %t831 = load ptr, ptr %l58, !tbaa !29
  %t832 = load i64, ptr %l59, !tbaa !24
  %t835 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t831, i64 %t832)
  store i64 %t835, ptr %l420
  br label %bb189
bb189:
  %t836 = load i64, ptr %l420, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s21, ptr %l50, i64 %t836)
  br label %bb190
bb190:
  br label %bb191
bb191:
  %t840 = load i64, ptr %l59, !tbaa !24
  %t842 = add i64 %t840, 1
  store i64 %t842, ptr %l59, !tbaa !24
  br label %bb184
bb192:
  %t844 = load ptr, ptr %l0, !tbaa !29
  store ptr %t844, ptr %l425, !tbaa !29
  %t845 = load ptr, ptr %l44, !tbaa !29
  %t847 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t845)
  store %"compiler/source:Span" %t847, ptr %l427
  br label %bb193
bb193:
  %t848 = load ptr, ptr %l425, !tbaa !29
  %t849 = load %"compiler/source:Span", ptr %l427
  %t850 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %s28, ptr %t848, %"compiler/source:Span" %t849)
  store { i64, ptr } %t850, ptr %l428
  br label %bb194
bb194:
  %t851 = load { i64, ptr }, ptr %l428, !tbaa !27
  store { i64, ptr } %t851, ptr %l429, !tbaa !27
  %t852 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t853 = extractvalue { i64, ptr } %t852, 0
  %t854 = load { i64, ptr }, ptr %l429, !tbaa !27
  %t855 = extractvalue { i64, ptr } %t854, 0
  store i64 %t855, ptr %l431, !tbaa !24
  %t857 = load i64, ptr %l431, !tbaa !24
  %t858 = icmp eq i64 %t853, %t857
  br i1 %t858, label %bb195, label %bb196
bb195:
  %t860 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t861 = load ptr, ptr %t860, !tbaa !27
  %t862 = getelementptr { i64, ptr }, ptr %l429, i32 0, i32 1
  %t863 = load ptr, ptr %t862, !tbaa !27
  %t864 = load i64, ptr %l431, !tbaa !24
  %t865 = mul i64 %t864, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t861, ptr %t863, i64 %t865, i1 false)
  br label %bb197
bb196:
  %t866 = load { i64, ptr }, ptr %l429, !tbaa !27
  %t867 = extractvalue { i64, ptr } %t866, 0
  store i64 %t867, ptr %l433, !tbaa !24
  %t868 = load i64, ptr %l433, !tbaa !24
  %t869 = mul i64 %t868, 1
  %t870 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t869)
  %t871 = insertvalue { i64, ptr } undef, i64 %t868, 0
  %t872 = insertvalue { i64, ptr } %t871, ptr %t870, 1
  store { i64, ptr } %t872, ptr %l434, !tbaa !27
  %t873 = getelementptr { i64, ptr }, ptr %l434, i32 0, i32 1
  %t874 = load ptr, ptr %t873, !tbaa !27
  %t875 = getelementptr { i64, ptr }, ptr %l429, i32 0, i32 1
  %t876 = load ptr, ptr %t875, !tbaa !27
  %t877 = load i64, ptr %l433, !tbaa !24
  %t878 = mul i64 %t877, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t874, ptr %t876, i64 %t878, i1 false)
  %t879 = load { i64, ptr }, ptr %l434, !tbaa !27
  store { i64, ptr } %t879, ptr %l57, !tbaa !27
  br label %bb197
bb197:
  call void @__olang_scope_close(ptr %s28)
  br label %bb198
bb198:
  br label %bb199
bb199:
  %t880 = load i64, ptr %l49, !tbaa !24
  %t882 = icmp sge i64 %t880, 0
  br i1 %t882, label %bb200, label %bb201
bb200:
  store i1 true, ptr %l437, !tbaa !21
  br label %bb202
bb201:
  %t884 = load i64, ptr %l45, !tbaa !24
  %t886 = icmp eq i64 %t884, 0
  store i1 %t886, ptr %l437, !tbaa !21
  br label %bb202
bb202:
  %t888 = load i1, ptr %l437, !tbaa !21
  br i1 %t888, label %bb203, label %bb204
bb203:
  store %olang.scope zeroinitializer, ptr %s32
  %t889 = load ptr, ptr %l0, !tbaa !29
  %t891 = getelementptr %"compiler/check:Checker", ptr %t889, i32 0, i32 1
  %t892 = load ptr, ptr %t891, !tbaa !29
  %t894 = getelementptr %"compiler/generic:Program", ptr %t892, i32 0, i32 0
  %t895 = load ptr, ptr %t894, !tbaa !29
  %t897 = getelementptr %"compiler/load:Loader", ptr %t895, i32 0, i32 4
  %t898 = load ptr, ptr %t897, !tbaa !29
  %t900 = call { { i64, [3 x i64] }, { i64, ptr } } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eTopContext(ptr %v0, ptr %s32, ptr %t898)
  store { { i64, [3 x i64] }, { i64, ptr } } %t900, ptr %l444
  br label %bb205
bb204:
  br label %bb231
bb205:
  %t901 = load { { i64, [3 x i64] }, { i64, ptr } }, ptr %l444
  store { { i64, [3 x i64] }, { i64, ptr } } %t901, ptr %l61
  %t902 = getelementptr { { i64, [3 x i64] }, { i64, ptr } }, ptr %l61, i32 0, i32 0
  %t903 = load { i64, [3 x i64] }, ptr %t902
  store { i64, [3 x i64] } %t903, ptr %l62
  %t905 = getelementptr { { i64, [3 x i64] }, { i64, ptr } }, ptr %l61, i32 0, i32 1
  %t906 = load { i64, ptr }, ptr %t905, !tbaa !27
  store { i64, ptr } %t906, ptr %l446, !tbaa !27
  %t907 = load { i64, ptr }, ptr %l446, !tbaa !27
  %t908 = extractvalue { i64, ptr } %t907, 0
  store i64 %t908, ptr %l447, !tbaa !24
  %t909 = load i64, ptr %l447, !tbaa !24
  %t910 = mul i64 %t909, 1
  %t911 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t910)
  %t912 = insertvalue { i64, ptr } undef, i64 %t909, 0
  %t913 = insertvalue { i64, ptr } %t912, ptr %t911, 1
  store { i64, ptr } %t913, ptr %l448, !tbaa !27
  %t914 = getelementptr { i64, ptr }, ptr %l448, i32 0, i32 1
  %t915 = load ptr, ptr %t914, !tbaa !27
  %t916 = getelementptr { i64, ptr }, ptr %l446, i32 0, i32 1
  %t917 = load ptr, ptr %t916, !tbaa !27
  %t918 = load i64, ptr %l447, !tbaa !24
  %t919 = mul i64 %t918, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t915, ptr %t917, i64 %t919, i1 false)
  %t920 = load { i64, ptr }, ptr %l448, !tbaa !27
  store { i64, ptr } %t920, ptr %l63, !tbaa !27
  %t921 = load ptr, ptr %l0, !tbaa !29
  %t923 = getelementptr %"compiler/check:Checker", ptr %t921, i32 0, i32 1
  %t924 = load ptr, ptr %t923, !tbaa !29
  %t926 = getelementptr %"compiler/generic:Program", ptr %t924, i32 0, i32 0
  %t927 = load ptr, ptr %t926, !tbaa !29
  %t929 = getelementptr %"compiler/load:Loader", ptr %t927, i32 0, i32 10
  %t930 = load ptr, ptr %l48, !tbaa !29
  %t932 = getelementptr %"compiler/check:frame", ptr %t930, i32 0, i32 1
  %t933 = load i64, ptr %t932, !tbaa !24
  %t936 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t929, i64 %t933)
  store ptr %t936, ptr %l455
  br label %bb206
bb206:
  %t937 = load ptr, ptr %l455, !tbaa !29
  %t939 = getelementptr %"compiler/load:Module", ptr %t937, i32 0, i32 2
  %t940 = load { i64, ptr }, ptr %t939, !tbaa !27
  %t942 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s32, { i64, ptr } %t940, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d27, i32 0, i32 1) })
  store i1 %t942, ptr %l458
  br label %bb207
bb207:
  %t943 = load i1, ptr %l458, !tbaa !21
  store i1 %t943, ptr %l64, !tbaa !21
  %t944 = load ptr, ptr %l0, !tbaa !29
  %t945 = load ptr, ptr %l43, !tbaa !29
  %t949 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadsConst(ptr %v0, ptr %v1, ptr %t944, ptr %t945)
  store i1 %t949, ptr %l462
  br label %bb208
bb208:
  %t950 = load i1, ptr %l462, !tbaa !21
  %t951 = xor i1 %t950, true
  br i1 %t951, label %bb209, label %bb210
bb209:
  %t953 = load i64, ptr %l45, !tbaa !24
  %t955 = icmp slt i64 %t953, 0
  store i1 %t955, ptr %l464, !tbaa !21
  br label %bb211
bb210:
  store i1 false, ptr %l464, !tbaa !21
  br label %bb211
bb211:
  %t957 = load i1, ptr %l464, !tbaa !21
  br i1 %t957, label %bb212, label %bb213
bb212:
  %t958 = load i1, ptr %l56, !tbaa !21
  br i1 %t958, label %bb214, label %bb215
bb213:
  store i1 false, ptr %l467, !tbaa !21
  br label %bb217
bb214:
  %t960 = load ptr, ptr %l0, !tbaa !29
  %t962 = getelementptr %"compiler/check:Checker", ptr %t960, i32 0, i32 126
  %t963 = load i1, ptr %t962, !tbaa !21
  store i1 %t963, ptr %l469, !tbaa !21
  br label %bb216
bb215:
  store i1 false, ptr %l469, !tbaa !21
  br label %bb216
bb216:
  %t965 = load i1, ptr %l469, !tbaa !21
  %t966 = xor i1 %t965, true
  store i1 %t966, ptr %l467, !tbaa !21
  br label %bb217
bb217:
  %t968 = load i1, ptr %l467, !tbaa !21
  br i1 %t968, label %bb218, label %bb219
bb218:
  %t969 = load i1, ptr %l64, !tbaa !21
  %t971 = xor i1 %t969, true
  store i1 %t971, ptr %l473, !tbaa !21
  br label %bb220
bb219:
  store i1 false, ptr %l473, !tbaa !21
  br label %bb220
bb220:
  %t973 = load i1, ptr %l473, !tbaa !21
  br i1 %t973, label %bb221, label %bb222
bb221:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d28, i32 0, i32 1) }, ptr %l476, !tbaa !27
  %t974 = load { i64, ptr }, ptr %l476, !tbaa !27
  store { i64, ptr } %t974, ptr %l477, !tbaa !27
  %t975 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t976 = extractvalue { i64, ptr } %t975, 0
  %t977 = load { i64, ptr }, ptr %l477, !tbaa !27
  %t978 = extractvalue { i64, ptr } %t977, 0
  store i64 %t978, ptr %l479, !tbaa !24
  %t980 = load i64, ptr %l479, !tbaa !24
  %t981 = icmp eq i64 %t976, %t980
  br i1 %t981, label %bb223, label %bb224
bb222:
  br label %bb226
bb223:
  %t983 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t984 = load ptr, ptr %t983, !tbaa !27
  %t985 = getelementptr { i64, ptr }, ptr %l477, i32 0, i32 1
  %t986 = load ptr, ptr %t985, !tbaa !27
  %t987 = load i64, ptr %l479, !tbaa !24
  %t988 = mul i64 %t987, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t984, ptr %t986, i64 %t988, i1 false)
  br label %bb225
bb224:
  %t989 = load { i64, ptr }, ptr %l477, !tbaa !27
  %t990 = extractvalue { i64, ptr } %t989, 0
  store i64 %t990, ptr %l481, !tbaa !24
  %t991 = load i64, ptr %l481, !tbaa !24
  %t992 = mul i64 %t991, 1
  %t993 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t992)
  %t994 = insertvalue { i64, ptr } undef, i64 %t991, 0
  %t995 = insertvalue { i64, ptr } %t994, ptr %t993, 1
  store { i64, ptr } %t995, ptr %l482, !tbaa !27
  %t996 = getelementptr { i64, ptr }, ptr %l482, i32 0, i32 1
  %t997 = load ptr, ptr %t996, !tbaa !27
  %t998 = getelementptr { i64, ptr }, ptr %l477, i32 0, i32 1
  %t999 = load ptr, ptr %t998, !tbaa !27
  %t1000 = load i64, ptr %l481, !tbaa !24
  %t1001 = mul i64 %t1000, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t997, ptr %t999, i64 %t1001, i1 false)
  %t1002 = load { i64, ptr }, ptr %l482, !tbaa !27
  store { i64, ptr } %t1002, ptr %l63, !tbaa !27
  br label %bb225
bb225:
  br label %bb226
bb226:
  %t1003 = load ptr, ptr %l0, !tbaa !29
  %t1005 = getelementptr %"compiler/check:Checker", ptr %t1003, i32 0, i32 87
  store ptr %t1005, ptr %l484, !tbaa !29
  %t1006 = load ptr, ptr %l48, !tbaa !29
  %t1008 = getelementptr %"compiler/check:frame", ptr %t1006, i32 0, i32 0
  %t1009 = load i64, ptr %t1008, !tbaa !24
  store i64 %t1009, ptr %l486, !tbaa !24
  %t1010 = load ptr, ptr %l48, !tbaa !29
  %t1012 = getelementptr %"compiler/check:frame", ptr %t1010, i32 0, i32 2
  %t1013 = load i64, ptr %t1012, !tbaa !24
  store i64 %t1013, ptr %l488, !tbaa !24
  %t1014 = load %"compiler/source:Span", ptr %l42
  store %"compiler/source:Span" %t1014, ptr %l489
  %t1015 = load ptr, ptr %l0, !tbaa !29
  %t1016 = load ptr, ptr %l43, !tbaa !29
  %t1019 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperatorOf(ptr %v0, ptr %v1, ptr %t1015, ptr %t1016)
  store %"compiler/source:Span" %t1019, ptr %l492
  br label %bb227
bb227:
  %t1020 = load i64, ptr %l49, !tbaa !24
  store i64 %t1020, ptr %l493, !tbaa !24
  %t1021 = load i64, ptr %l54, !tbaa !24
  store i64 %t1021, ptr %l494, !tbaa !24
  %t1023 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %s21, ptr %v0, ptr %l50)
  store { i64, ptr } %t1023, ptr %l496
  br label %bb228
bb228:
  %t1024 = load { i64, [3 x i64] }, ptr %l62
  %t1025 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t1027 = extractvalue { i64, ptr } %t1025, 1
  %t1028 = extractvalue { i64, ptr } %t1025, 0
  %t1029 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t1028)
  call void @olang_textcopy(ptr %t1029, ptr %t1027, i64 %t1028)
  %t1030 = insertvalue { i64, ptr } undef, i64 %t1028, 0
  %t1031 = insertvalue { i64, ptr } %t1030, ptr %t1029, 1
  %t1033 = extractvalue { i64, ptr } %t1031, 0
  %t1034 = extractvalue { i64, ptr } %t1031, 1
  %t1035 = mul i64 %t1033, 1
  %t1036 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t1035)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1036, ptr %t1034, i64 %t1035, i1 false)
  %t1037 = insertvalue { i64, ptr } undef, i64 %t1033, 0
  %t1038 = insertvalue { i64, ptr } %t1037, ptr %t1036, 1
  %t1039 = load i1, ptr %l56, !tbaa !21
  %t1040 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t1042 = extractvalue { i64, ptr } %t1040, 1
  %t1043 = extractvalue { i64, ptr } %t1040, 0
  %t1044 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t1043)
  call void @olang_textcopy(ptr %t1044, ptr %t1042, i64 %t1043)
  %t1045 = insertvalue { i64, ptr } undef, i64 %t1043, 0
  %t1046 = insertvalue { i64, ptr } %t1045, ptr %t1044, 1
  %t1048 = extractvalue { i64, ptr } %t1046, 0
  %t1049 = extractvalue { i64, ptr } %t1046, 1
  %t1050 = mul i64 %t1048, 1
  %t1051 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t1050)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1051, ptr %t1049, i64 %t1050, i1 false)
  %t1052 = insertvalue { i64, ptr } undef, i64 %t1048, 0
  %t1053 = insertvalue { i64, ptr } %t1052, ptr %t1051, 1
  %t1054 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t1056 = extractvalue { i64, ptr } %t1054, 1
  %t1057 = extractvalue { i64, ptr } %t1054, 0
  %t1058 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t1057)
  call void @olang_textcopy(ptr %t1058, ptr %t1056, i64 %t1057)
  %t1059 = insertvalue { i64, ptr } undef, i64 %t1057, 0
  %t1060 = insertvalue { i64, ptr } %t1059, ptr %t1058, 1
  %t1062 = extractvalue { i64, ptr } %t1060, 0
  %t1063 = extractvalue { i64, ptr } %t1060, 1
  %t1064 = mul i64 %t1062, 1
  %t1065 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t1064)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1065, ptr %t1063, i64 %t1064, i1 false)
  %t1066 = insertvalue { i64, ptr } undef, i64 %t1062, 0
  %t1067 = insertvalue { i64, ptr } %t1066, ptr %t1065, 1
  %t1069 = load i64, ptr %l486, !tbaa !24
  %t1070 = load i64, ptr %l488, !tbaa !24
  %t1071 = load %"compiler/source:Span", ptr %l489
  %t1072 = load %"compiler/source:Span", ptr %l492
  %t1073 = load i64, ptr %l493, !tbaa !24
  %t1074 = load i64, ptr %l494, !tbaa !24
  %t1075 = load { i64, ptr }, ptr %l496, !tbaa !27
  call void @compiler_2fcheck_3aAssertAsk_2ector(ptr %t1068, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, i64 %t1069, i64 %t1070, %"compiler/source:Span" %t1071, %"compiler/source:Span" %t1072, i64 %t1073, i64 %t1074, { i64, ptr } %t1075, { i64, [3 x i64] } %t1024, { i64, ptr } %t1038, i1 %t1039, { i64, ptr } %t1053, { i64, ptr } %t1067)
  call void @llvm.memmove.p0.p0.i64(ptr %l508, ptr %t1068, i64 152, i1 false)
  br label %bb229
bb229:
  %t1081 = load ptr, ptr %l484, !tbaa !29
  call void @llvm.memmove.p0.p0.i64(ptr %t1082, ptr %l508, i64 152, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAssertAsk_3e_2ePush_Hbdaad063a73077b3b5842d615b8c1d82(ptr %v0, ptr %v0, ptr %t1081, ptr %t1082)
  br label %bb230
bb230:
  call void @__olang_scope_close(ptr %s32)
  br label %bb231
bb231:
  call void @__olang_scope_close(ptr %s21)
  br label %bb232
bb232:
  br label %bb276
bb233:
  %t1083 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1083, ptr %l509, !tbaa !29
  store i1 false, ptr %l510, !tbaa !21
  %t1084 = load ptr, ptr %l509, !tbaa !29
  %t1085 = icmp ne ptr %t1084, null
  br i1 %t1085, label %bb234, label %bb235
bb234:
  %t1087 = load ptr, ptr %l509, !tbaa !29
  %t1088 = load i64, ptr %t1087, !range !{i64 0, i64 22}
  %t1090 = icmp eq i64 %t1088, 16
  store i1 %t1090, ptr %l510, !tbaa !21
  br label %bb235
bb235:
  %t1091 = load i1, ptr %l510, !tbaa !21
  br i1 %t1091, label %bb236, label %bb237
bb236:
  %t1092 = load ptr, ptr %l1, !tbaa !29
  %t1094 = getelementptr { i64, [4 x i64] }, ptr %t1092, i32 0, i32 1
  %t1095 = getelementptr { %"compiler/source:Span", ptr }, ptr %t1094, i32 0, i32 0
  %t1096 = load %"compiler/source:Span", ptr %t1095
  store %"compiler/source:Span" %t1096, ptr %l65
  %t1098 = load ptr, ptr %l1, !tbaa !29
  %t1100 = getelementptr { i64, [4 x i64] }, ptr %t1098, i32 0, i32 1
  %t1101 = getelementptr { %"compiler/source:Span", ptr }, ptr %t1100, i32 0, i32 1
  %t1102 = load ptr, ptr %t1101
  store ptr %t1102, ptr %l66, !tbaa !29
  br label %bb238
bb237:
  br label %bb240
bb238:
  %t1104 = load ptr, ptr %l0, !tbaa !29
  %t1105 = load %"compiler/source:Span", ptr %l65
  %t1106 = load ptr, ptr %l66, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eraise(ptr %v0, ptr %v1, ptr %t1104, %"compiler/source:Span" %t1105, ptr %t1106)
  br label %bb239
bb239:
  br label %bb276
bb240:
  %t1110 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1110, ptr %l520, !tbaa !29
  store i1 false, ptr %l521, !tbaa !21
  %t1111 = load ptr, ptr %l520, !tbaa !29
  %t1112 = icmp ne ptr %t1111, null
  br i1 %t1112, label %bb241, label %bb242
bb241:
  %t1114 = load ptr, ptr %l520, !tbaa !29
  %t1115 = load i64, ptr %t1114, !range !{i64 0, i64 22}
  %t1117 = icmp eq i64 %t1115, 19
  store i1 %t1117, ptr %l521, !tbaa !21
  br label %bb242
bb242:
  %t1118 = load i1, ptr %l521, !tbaa !21
  br i1 %t1118, label %bb243, label %bb244
bb243:
  %t1119 = load ptr, ptr %l1, !tbaa !29
  %t1121 = getelementptr { i64, [4 x i64] }, ptr %t1119, i32 0, i32 1
  %t1122 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t1121, i32 0, i32 0
  %t1123 = load %"compiler/source:Span", ptr %t1122
  store %"compiler/source:Span" %t1123, ptr %l67
  %t1125 = load ptr, ptr %l1, !tbaa !29
  %t1127 = getelementptr { i64, [4 x i64] }, ptr %t1125, i32 0, i32 1
  %t1128 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t1127, i32 0, i32 1
  %t1129 = load ptr, ptr %t1128
  store ptr %t1129, ptr %l68, !tbaa !29
  %t1131 = load ptr, ptr %l1, !tbaa !29
  %t1133 = getelementptr { i64, [4 x i64] }, ptr %t1131, i32 0, i32 1
  %t1134 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t1133, i32 0, i32 2
  %t1135 = load i1, ptr %t1134
  store i1 %t1135, ptr %l69, !tbaa !21
  br label %bb245
bb244:
  br label %bb247
bb245:
  %t1137 = load ptr, ptr %l0, !tbaa !29
  %t1138 = load %"compiler/source:Span", ptr %l67
  %t1139 = load ptr, ptr %l68, !tbaa !29
  %t1140 = load i1, ptr %l69, !tbaa !21
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeferStmt(ptr %v0, ptr %v1, ptr %t1137, %"compiler/source:Span" %t1138, ptr %t1139, i1 %t1140)
  br label %bb246
bb246:
  br label %bb276
bb247:
  %t1145 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1145, ptr %l534, !tbaa !29
  store i1 false, ptr %l535, !tbaa !21
  %t1146 = load ptr, ptr %l534, !tbaa !29
  %t1147 = icmp ne ptr %t1146, null
  br i1 %t1147, label %bb248, label %bb249
bb248:
  %t1149 = load ptr, ptr %l534, !tbaa !29
  %t1150 = load i64, ptr %t1149, !range !{i64 0, i64 22}
  %t1152 = icmp eq i64 %t1150, 20
  store i1 %t1152, ptr %l535, !tbaa !21
  br label %bb249
bb249:
  %t1153 = load i1, ptr %l535, !tbaa !21
  br i1 %t1153, label %bb250, label %bb251
bb250:
  %t1154 = load ptr, ptr %l1, !tbaa !29
  %t1156 = getelementptr { i64, [4 x i64] }, ptr %t1154, i32 0, i32 1
  %t1157 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t1156, i32 0, i32 0
  %t1158 = load %"compiler/source:Span", ptr %t1157
  store %"compiler/source:Span" %t1158, ptr %l70
  %t1160 = load ptr, ptr %l1, !tbaa !29
  %t1162 = getelementptr { i64, [4 x i64] }, ptr %t1160, i32 0, i32 1
  %t1163 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t1162, i32 0, i32 1
  %t1164 = load { i64, ptr }, ptr %t1163
  store { i64, ptr } %t1164, ptr %l71, !tbaa !27
  br label %bb252
bb251:
  br label %bb255
bb252:
  %t1166 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1166, ptr %l542, !tbaa !29
  %t1167 = load %"compiler/source:Span", ptr %l70
  store %"compiler/source:Span" %t1167, ptr %l543
  %t1168 = load ptr, ptr %l0, !tbaa !29
  %t1169 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t1170 = load %"compiler/source:Span", ptr %l70
  %t1175 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eblockOf(ptr %v0, ptr %v1, ptr %v0, ptr %t1168, { i64, ptr } %t1169, i32 1, %"compiler/source:Span" %t1170)
  store ptr %t1175, ptr %l548
  br label %bb253
bb253:
  store { i64, [3 x i64] } zeroinitializer, ptr %t1176
  %t1177 = getelementptr { i64, [3 x i64] }, ptr %t1176, i32 0, i32 0
  store i64 11, ptr %t1177
  %t1178 = load %"compiler/source:Span", ptr %l543
  %t1179 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t1178, 0
  %t1180 = load ptr, ptr %l548, !tbaa !29
  %t1181 = insertvalue { %"compiler/source:Span", ptr } %t1179, ptr %t1180, 1
  %t1182 = getelementptr { i64, [3 x i64] }, ptr %t1176, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t1181, ptr %t1182
  %t1183 = load { i64, [3 x i64] }, ptr %t1176
  %t1185 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t1183, ptr %t1185
  %t1186 = load ptr, ptr %l542, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t1186, ptr %t1185)
  br label %bb254
bb254:
  br label %bb276
bb255:
  %t1188 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1188, ptr %l551, !tbaa !29
  store i1 false, ptr %l552, !tbaa !21
  %t1189 = load ptr, ptr %l551, !tbaa !29
  %t1190 = icmp ne ptr %t1189, null
  br i1 %t1190, label %bb256, label %bb257
bb256:
  %t1192 = load ptr, ptr %l551, !tbaa !29
  %t1193 = load i64, ptr %t1192, !range !{i64 0, i64 22}
  %t1195 = icmp eq i64 %t1193, 18
  store i1 %t1195, ptr %l552, !tbaa !21
  br label %bb257
bb257:
  %t1196 = load i1, ptr %l552, !tbaa !21
  br i1 %t1196, label %bb258, label %bb259
bb258:
  %t1197 = load ptr, ptr %l1, !tbaa !29
  %t1199 = getelementptr { i64, [4 x i64] }, ptr %t1197, i32 0, i32 1
  %t1200 = getelementptr { %"compiler/source:Span", ptr }, ptr %t1199, i32 0, i32 0
  %t1201 = load %"compiler/source:Span", ptr %t1200
  store %"compiler/source:Span" %t1201, ptr %l72
  %t1203 = load ptr, ptr %l1, !tbaa !29
  %t1205 = getelementptr { i64, [4 x i64] }, ptr %t1203, i32 0, i32 1
  %t1206 = getelementptr { %"compiler/source:Span", ptr }, ptr %t1205, i32 0, i32 1
  %t1207 = load ptr, ptr %t1206
  store ptr %t1207, ptr %l73, !tbaa !29
  br label %bb260
bb259:
  br label %bb262
bb260:
  %t1209 = load ptr, ptr %l0, !tbaa !29
  %t1210 = load %"compiler/source:Span", ptr %l72
  %t1211 = load ptr, ptr %l73, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ejoinStmt(ptr %v0, ptr %v1, ptr %t1209, %"compiler/source:Span" %t1210, ptr %t1211)
  br label %bb261
bb261:
  br label %bb276
bb262:
  %t1215 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1215, ptr %l562, !tbaa !29
  store i1 false, ptr %l563, !tbaa !21
  %t1216 = load ptr, ptr %l562, !tbaa !29
  %t1217 = icmp ne ptr %t1216, null
  br i1 %t1217, label %bb263, label %bb264
bb263:
  %t1219 = load ptr, ptr %l562, !tbaa !29
  %t1220 = load i64, ptr %t1219, !range !{i64 0, i64 22}
  %t1222 = icmp eq i64 %t1220, 17
  store i1 %t1222, ptr %l563, !tbaa !21
  br label %bb264
bb264:
  %t1223 = load i1, ptr %l563, !tbaa !21
  br i1 %t1223, label %bb265, label %bb266
bb265:
  %t1224 = load ptr, ptr %l1, !tbaa !29
  %t1226 = getelementptr { i64, [4 x i64] }, ptr %t1224, i32 0, i32 1
  %t1227 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t1226, i32 0, i32 0
  %t1228 = load %"compiler/source:Span", ptr %t1227
  store %"compiler/source:Span" %t1228, ptr %l74
  %t1230 = load ptr, ptr %l1, !tbaa !29
  %t1232 = getelementptr { i64, [4 x i64] }, ptr %t1230, i32 0, i32 1
  %t1233 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t1232, i32 0, i32 1
  %t1234 = load { i64, ptr }, ptr %t1233
  store { i64, ptr } %t1234, ptr %l75, !tbaa !27
  %t1236 = load ptr, ptr %l1, !tbaa !29
  %t1238 = getelementptr { i64, [4 x i64] }, ptr %t1236, i32 0, i32 1
  %t1239 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t1238, i32 0, i32 2
  %t1240 = load ptr, ptr %t1239
  store ptr %t1240, ptr %l76, !tbaa !29
  br label %bb267
bb266:
  br label %bb269
bb267:
  %t1242 = load ptr, ptr %l0, !tbaa !29
  %t1243 = load %"compiler/source:Span", ptr %l74
  %t1244 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t1245 = load ptr, ptr %l76, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espawnStmt(ptr %v0, ptr %v1, ptr %v1, ptr %t1242, %"compiler/source:Span" %t1243, { i64, ptr } %t1244, ptr %t1245)
  br label %bb268
bb268:
  br label %bb276
bb269:
  br i1 true, label %bb270, label %bb271
bb270:
  br label %bb272
bb271:
  br label %bb275
bb272:
  store %olang.scope zeroinitializer, ptr %s42
  %t1250 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1250, ptr %l576, !tbaa !29
  %t1251 = load ptr, ptr %l1, !tbaa !29
  %t1253 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v1, ptr %t1251)
  store %"compiler/source:Span" %t1253, ptr %l578
  br label %bb273
bb273:
  %t1254 = load ptr, ptr %l576, !tbaa !29
  %t1255 = load %"compiler/source:Span", ptr %l578
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s42, ptr %t1254, %"compiler/source:Span" %t1255, { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d29, i32 0, i32 1) })
  br label %bb274
bb274:
  call void @__olang_scope_close(ptr %s42)
  br label %bb276
bb275:
  call void @__olang_check_failed(ptr @olang_loc_97a078c1fd6401ad_6b439c1864d584b1)
  unreachable
bb276:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmtsOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca %"compiler/check:nullNarrow"
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca %"compiler/check:narrowed"
  %l27 = alloca [1 x i32]
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca %"compiler/check:errNarrow"
  %l35 = alloca ptr
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca i64
  %l49 = alloca ptr
  %l59 = alloca i64
  %l62 = alloca i64
  %l85 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l88 = alloca i64
  %l92 = alloca i64
  %l95 = alloca i64
  %l116 = alloca %"compiler/check:nullNarrow"
  %l118 = alloca i1
  %l119 = alloca { i64, ptr }
  %l124 = alloca i1
  %l126 = alloca { i64, ptr }
  %l130 = alloca i1
  %l134 = alloca ptr
  %l135 = alloca i64
  %l138 = alloca %"compiler/check:nullNarrow"
  %l141 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l144 = alloca i64
  %l148 = alloca i64
  %l151 = alloca i64
  %l172 = alloca %"compiler/check:narrowed"
  %l175 = alloca ptr
  %l179 = alloca %"compiler/typed:Local"
  %l182 = alloca { i64, ptr }
  %l188 = alloca i1
  %l190 = alloca { i64, ptr }
  %l195 = alloca i1
  %l199 = alloca ptr
  %l200 = alloca i64
  %l202 = alloca %"compiler/check:narrowed"
  %l207 = alloca i64
  %l211 = alloca i64
  %l214 = alloca i64
  %l235 = alloca %"compiler/check:errNarrow"
  %l238 = alloca i1
  %l239 = alloca { i64, ptr }
  %l242 = alloca ptr
  %l243 = alloca i32
  %l247 = alloca i1
  %l249 = alloca ptr
  %l250 = alloca i64
  %l254 = alloca %"compiler/check:errNarrow"
  %l257 = alloca ptr
  %l263 = alloca { i64, ptr }
  %l271 = alloca i64
  %l273 = alloca i64
  %l278 = alloca i64
  %l279 = alloca i64
  %l282 = alloca i64
  %l285 = alloca ptr
  %l286 = alloca i64
  %l290 = alloca %"compiler/check:nullNarrow"
  %l291 = alloca { i64, ptr }
  %l295 = alloca %"compiler/check:nullNarrow"
  %l297 = alloca %"compiler/check:nullNarrow"
  %l301 = alloca i64
  %l303 = alloca i64
  %l308 = alloca i64
  %l309 = alloca i64
  %l312 = alloca i64
  %l315 = alloca ptr
  %l316 = alloca i64
  %l320 = alloca %"compiler/check:narrowed"
  %l321 = alloca %"compiler/check:narrowed"
  %l328 = alloca i1
  %l334 = alloca ptr
  %l340 = alloca { i64, ptr }
  %l341 = alloca i64
  %l346 = alloca { i64, ptr }
  %l354 = alloca %"compiler/check:nullNarrow"
  %l355 = alloca ptr
  %s3 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %t410 = alloca i64
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t7)
  store ptr %t9, ptr %l49
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l49, !tbaa !29
  store ptr %t10, ptr %l2, !tbaa !29
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t13 = getelementptr %"compiler/check:frame", ptr %t11, i32 0, i32 49
  %t14 = load { i64, ptr }, ptr %t13, !tbaa !27
  store { i64, ptr } %t14, ptr %l3, !tbaa !27
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = getelementptr %"compiler/check:frame", ptr %t16, i32 0, i32 50
  %t19 = load i64, ptr %t18, !tbaa !24
  store i64 %t19, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  %t21 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t25 = load i64, ptr %l6, !tbaa !24
  %t26 = load i64, ptr %l5, !tbaa !24
  %t29 = icmp sgt i64 %t25, %t26
  br i1 %t29, label %bb5, label %bb6
bb5:
  %t31 = load i64, ptr %l7, !tbaa !24
  %t33 = icmp sgt i64 %t31, 0
  br i1 %t33, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l59, !tbaa !24
  br label %bb10
bb7:
  %t35 = load i64, ptr %l6, !tbaa !24
  %t36 = load i64, ptr %l5, !tbaa !24
  %t39 = sub i64 %t35, %t36
  %t40 = load i64, ptr %l7, !tbaa !24
  %t43 = add i64 %t39, %t40
  %t45 = sub i64 %t43, 1
  %t46 = load i64, ptr %l7, !tbaa !24
  %t49 = sdiv i64 %t45, %t46
  store i64 %t49, ptr %l62, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l62, !tbaa !24
  br label %bb9
bb9:
  %t51 = load i64, ptr %l62, !tbaa !24
  store i64 %t51, ptr %l59, !tbaa !24
  br label %bb10
bb10:
  %t52 = load i64, ptr %l59, !tbaa !24
  store i64 %t52, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t53 = load i64, ptr %l9, !tbaa !24
  %t54 = load i64, ptr %l8, !tbaa !24
  %t57 = icmp slt i64 %t53, %t54
  %t59 = xor i1 %t57, true
  br i1 %t59, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb160
bb13:
  br label %bb14
bb14:
  %t61 = load i64, ptr %l5, !tbaa !24
  %t62 = load i64, ptr %l9, !tbaa !24
  %t63 = load i64, ptr %l7, !tbaa !24
  %t66 = mul i64 %t62, %t63
  %t69 = add i64 %t61, %t66
  store i64 %t69, ptr %l10, !tbaa !24
  %t71 = load ptr, ptr %l2, !tbaa !29
  %t72 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t75 = getelementptr %"compiler/check:frame", ptr %t71, i32 0, i32 49
  store { i64, ptr } %t72, ptr %t75, !tbaa !27
  %t76 = load ptr, ptr %l2, !tbaa !29
  %t77 = load i64, ptr %l10, !tbaa !24
  %t79 = add i64 %t77, 1
  %t82 = getelementptr %"compiler/check:frame", ptr %t76, i32 0, i32 50
  store i64 %t79, ptr %t82, !tbaa !24
  %t83 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t83, ptr %l85
  br label %bb15
bb15:
  %t84 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l85
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t84, ptr %l11
  store i64 0, ptr %l12, !tbaa !24
  %t85 = load ptr, ptr %l2, !tbaa !29
  %t87 = getelementptr %"compiler/check:frame", ptr %t85, i32 0, i32 48
  %t89 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eLen_H4b13e48b0a317e727dbe35330ad8712a(ptr %v0, ptr %t87)
  store i64 %t89, ptr %l88
  br label %bb16
bb16:
  %t90 = load i64, ptr %l88, !tbaa !24
  store i64 %t90, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t91 = load i64, ptr %l13, !tbaa !24
  %t92 = load i64, ptr %l12, !tbaa !24
  %t95 = icmp sgt i64 %t91, %t92
  br i1 %t95, label %bb17, label %bb18
bb17:
  %t97 = load i64, ptr %l14, !tbaa !24
  %t99 = icmp sgt i64 %t97, 0
  br i1 %t99, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l92, !tbaa !24
  br label %bb22
bb19:
  %t101 = load i64, ptr %l13, !tbaa !24
  %t102 = load i64, ptr %l12, !tbaa !24
  %t105 = sub i64 %t101, %t102
  %t106 = load i64, ptr %l14, !tbaa !24
  %t109 = add i64 %t105, %t106
  %t111 = sub i64 %t109, 1
  %t112 = load i64, ptr %l14, !tbaa !24
  %t115 = sdiv i64 %t111, %t112
  store i64 %t115, ptr %l95, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l95, !tbaa !24
  br label %bb21
bb21:
  %t117 = load i64, ptr %l95, !tbaa !24
  store i64 %t117, ptr %l92, !tbaa !24
  br label %bb22
bb22:
  %t118 = load i64, ptr %l92, !tbaa !24
  store i64 %t118, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb23
bb23:
  %t119 = load i64, ptr %l16, !tbaa !24
  %t120 = load i64, ptr %l15, !tbaa !24
  %t123 = icmp slt i64 %t119, %t120
  %t125 = xor i1 %t123, true
  br i1 %t125, label %bb24, label %bb25
bb24:
  br label %bb43
bb25:
  br label %bb26
bb26:
  %t127 = load i64, ptr %l12, !tbaa !24
  %t128 = load i64, ptr %l16, !tbaa !24
  %t129 = load i64, ptr %l14, !tbaa !24
  %t132 = mul i64 %t128, %t129
  %t135 = add i64 %t127, %t132
  store i64 %t135, ptr %l17, !tbaa !24
  %t137 = load ptr, ptr %l2, !tbaa !29
  %t139 = getelementptr %"compiler/check:frame", ptr %t137, i32 0, i32 48
  %t140 = load i64, ptr %l17, !tbaa !24
  %t143 = call %"compiler/check:nullNarrow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eAt__H22e551fb00043bde3f1f8b2c6007f7cb(ptr %v0, ptr %v0, ptr %t139, i64 %t140)
  store %"compiler/check:nullNarrow" %t143, ptr %l116
  br label %bb27
bb27:
  %t144 = load %"compiler/check:nullNarrow", ptr %l116
  store %"compiler/check:nullNarrow" %t144, ptr %l18
  %t145 = getelementptr %"compiler/check:nullNarrow", ptr %l18, i32 0, i32 2
  %t146 = load i1, ptr %t145, !tbaa !21
  br i1 %t146, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l118, !tbaa !21
  br label %bb31
bb29:
  %t148 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t148, ptr %l119, !tbaa !27
  %t149 = load i64, ptr %l10, !tbaa !24
  %t151 = getelementptr { i64, ptr }, ptr %l119, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = getelementptr ptr, ptr %t152, i64 %t149
  %t154 = load ptr, ptr %t153, !tbaa !39
  %t156 = getelementptr %"compiler/check:nullNarrow", ptr %l18, i32 0, i32 0
  %t157 = load { i64, ptr }, ptr %t156, !tbaa !27
  %t160 = call i1 @compiler_2fcheck_2estmtAssigns(ptr %v1, ptr %v0, ptr %t154, { i64, ptr } %t157)
  store i1 %t160, ptr %l124
  br label %bb30
bb30:
  %t161 = load i1, ptr %l124, !tbaa !21
  %t162 = xor i1 %t161, true
  store i1 %t162, ptr %l118, !tbaa !21
  br label %bb31
bb31:
  %t164 = load i1, ptr %l118, !tbaa !21
  br i1 %t164, label %bb32, label %bb33
bb32:
  br label %bb42
bb33:
  br label %bb34
bb34:
  %t165 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t165, ptr %l126, !tbaa !27
  %t166 = load i64, ptr %l10, !tbaa !24
  %t168 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !27
  %t170 = getelementptr ptr, ptr %t169, i64 %t166
  %t171 = load ptr, ptr %t170, !tbaa !39
  %t172 = getelementptr %"compiler/check:nullNarrow", ptr %l18, i32 0, i32 0
  %t173 = load { i64, ptr }, ptr %t172, !tbaa !27
  %t176 = call i1 @compiler_2fcheck_2eassignsWhole(ptr %v1, ptr %v0, ptr %t171, { i64, ptr } %t173)
  store i1 %t176, ptr %l130
  br label %bb35
bb35:
  %t177 = load i1, ptr %l130, !tbaa !21
  br i1 %t177, label %bb36, label %bb37
bb36:
  %t178 = load i64, ptr %l17, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s3, ptr %l11, i64 %t178)
  br label %bb38
bb37:
  %t181 = load ptr, ptr %l2, !tbaa !29
  %t183 = getelementptr %"compiler/check:frame", ptr %t181, i32 0, i32 48
  store ptr %t183, ptr %l134, !tbaa !29
  %t184 = load i64, ptr %l17, !tbaa !24
  store i64 %t184, ptr %l135, !tbaa !24
  %t185 = getelementptr %"compiler/check:nullNarrow", ptr %l18, i32 0, i32 0
  %t186 = load { i64, ptr }, ptr %t185, !tbaa !27
  %t187 = getelementptr %"compiler/check:nullNarrow", ptr %l18, i32 0, i32 1
  %t188 = load i64, ptr %t187, !tbaa !24
  %t191 = call %"compiler/check:nullNarrow" @compiler_2fcheck_3anullNarrow_2ector(ptr %v0, ptr %v0, { i64, ptr } %t186, i64 %t188, i1 true)
  store %"compiler/check:nullNarrow" %t191, ptr %l138
  br label %bb39
bb38:
  br label %bb41
bb39:
  %t192 = load ptr, ptr %l134, !tbaa !29
  %t193 = load i64, ptr %l135, !tbaa !24
  %t194 = load %"compiler/check:nullNarrow", ptr %l138
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eSet_H93968e49180de2bc6256fae5bb61b442(ptr %v0, ptr %v0, ptr %t192, i64 %t193, %"compiler/check:nullNarrow" %t194)
  br label %bb40
bb40:
  br label %bb41
bb41:
  br label %bb42
bb42:
  %t195 = load i64, ptr %l16, !tbaa !24
  %t197 = add i64 %t195, 1
  store i64 %t197, ptr %l16, !tbaa !24
  br label %bb23
bb43:
  %t199 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t199, ptr %l141
  br label %bb44
bb44:
  %t200 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l141
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t200, ptr %l19
  store i64 0, ptr %l20, !tbaa !24
  %t201 = load ptr, ptr %l2, !tbaa !29
  %t203 = getelementptr %"compiler/check:frame", ptr %t201, i32 0, i32 44
  %t205 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eLen_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %t203)
  store i64 %t205, ptr %l144
  br label %bb45
bb45:
  %t206 = load i64, ptr %l144, !tbaa !24
  store i64 %t206, ptr %l21, !tbaa !24
  store i64 1, ptr %l22, !tbaa !24
  %t207 = load i64, ptr %l21, !tbaa !24
  %t208 = load i64, ptr %l20, !tbaa !24
  %t211 = icmp sgt i64 %t207, %t208
  br i1 %t211, label %bb46, label %bb47
bb46:
  %t213 = load i64, ptr %l22, !tbaa !24
  %t215 = icmp sgt i64 %t213, 0
  br i1 %t215, label %bb48, label %bb49
bb47:
  store i64 0, ptr %l148, !tbaa !24
  br label %bb51
bb48:
  %t217 = load i64, ptr %l21, !tbaa !24
  %t218 = load i64, ptr %l20, !tbaa !24
  %t221 = sub i64 %t217, %t218
  %t222 = load i64, ptr %l22, !tbaa !24
  %t225 = add i64 %t221, %t222
  %t227 = sub i64 %t225, 1
  %t228 = load i64, ptr %l22, !tbaa !24
  %t231 = sdiv i64 %t227, %t228
  store i64 %t231, ptr %l151, !tbaa !24
  br label %bb50
bb49:
  store i64 0, ptr %l151, !tbaa !24
  br label %bb50
bb50:
  %t233 = load i64, ptr %l151, !tbaa !24
  store i64 %t233, ptr %l148, !tbaa !24
  br label %bb51
bb51:
  %t234 = load i64, ptr %l148, !tbaa !24
  store i64 %t234, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb52
bb52:
  store %olang.scope zeroinitializer, ptr %s11
  %t235 = load i64, ptr %l24, !tbaa !24
  %t236 = load i64, ptr %l23, !tbaa !24
  %t239 = icmp slt i64 %t235, %t236
  %t241 = xor i1 %t239, true
  br i1 %t241, label %bb53, label %bb54
bb53:
  call void @__olang_scope_close(ptr %s11)
  br label %bb74
bb54:
  br label %bb55
bb55:
  %t243 = load i64, ptr %l20, !tbaa !24
  %t244 = load i64, ptr %l24, !tbaa !24
  %t245 = load i64, ptr %l22, !tbaa !24
  %t248 = mul i64 %t244, %t245
  %t251 = add i64 %t243, %t248
  store i64 %t251, ptr %l25, !tbaa !24
  %t253 = load ptr, ptr %l2, !tbaa !29
  %t255 = getelementptr %"compiler/check:frame", ptr %t253, i32 0, i32 44
  %t256 = load i64, ptr %l25, !tbaa !24
  %t259 = call %"compiler/check:narrowed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eAt_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %t255, i64 %t256)
  store %"compiler/check:narrowed" %t259, ptr %l172
  br label %bb56
bb56:
  %t260 = load %"compiler/check:narrowed", ptr %l172
  store %"compiler/check:narrowed" %t260, ptr %l26
  %t261 = getelementptr %"compiler/check:narrowed", ptr %l26, i32 0, i32 5
  %t262 = load i1, ptr %t261, !tbaa !21
  br i1 %t262, label %bb57, label %bb58
bb57:
  call void @__olang_scope_close(ptr %s11)
  br label %bb73
bb58:
  br label %bb59
bb59:
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t266 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t264)
  store ptr %t266, ptr %l175
  br label %bb60
bb60:
  %t267 = load ptr, ptr %l175, !tbaa !29
  %t269 = getelementptr %"compiler/typed:Body", ptr %t267, i32 0, i32 7
  %t270 = getelementptr %"compiler/check:narrowed", ptr %l26, i32 0, i32 0
  %t271 = load i64, ptr %t270, !tbaa !24
  %t274 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t269, i64 %t271)
  store %"compiler/typed:Local" %t274, ptr %l179
  br label %bb61
bb61:
  %t275 = getelementptr %"compiler/typed:Local", ptr %l179, i32 0, i32 0
  %t276 = load i32, ptr %t275, !tbaa !23
  %t278 = insertvalue [1 x i32] undef, i32 %t276, 0
  store [1 x i32] %t278, ptr %l27
  %t280 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t280, ptr %l182, !tbaa !27
  %t281 = load i64, ptr %l10, !tbaa !24
  %t283 = getelementptr { i64, ptr }, ptr %l182, i32 0, i32 1
  %t284 = load ptr, ptr %t283, !tbaa !27
  %t285 = getelementptr ptr, ptr %t284, i64 %t281
  %t286 = load ptr, ptr %t285, !tbaa !39
  %t289 = insertvalue { i64, ptr } undef, i64 1, 0
  %t290 = insertvalue { i64, ptr } %t289, ptr %l27, 1
  %t293 = call i1 @compiler_2fcheck_2estmtAssigns(ptr %v1, ptr %s11, ptr %t286, { i64, ptr } %t290)
  store i1 %t293, ptr %l188
  br label %bb62
bb62:
  %t294 = load i1, ptr %l188, !tbaa !21
  %t295 = xor i1 %t294, true
  br i1 %t295, label %bb63, label %bb64
bb63:
  call void @__olang_scope_close(ptr %s11)
  br label %bb73
bb64:
  br label %bb65
bb65:
  %t297 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t297, ptr %l190, !tbaa !27
  %t298 = load i64, ptr %l10, !tbaa !24
  %t300 = getelementptr { i64, ptr }, ptr %l190, i32 0, i32 1
  %t301 = load ptr, ptr %t300, !tbaa !27
  %t302 = getelementptr ptr, ptr %t301, i64 %t298
  %t303 = load ptr, ptr %t302, !tbaa !39
  %t305 = insertvalue { i64, ptr } undef, i64 1, 0
  %t306 = insertvalue { i64, ptr } %t305, ptr %l27, 1
  %t309 = call i1 @compiler_2fcheck_2eassignsWhole(ptr %v1, ptr %s11, ptr %t303, { i64, ptr } %t306)
  store i1 %t309, ptr %l195
  br label %bb66
bb66:
  %t310 = load i1, ptr %l195, !tbaa !21
  br i1 %t310, label %bb67, label %bb68
bb67:
  %t311 = load i64, ptr %l25, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s3, ptr %l19, i64 %t311)
  br label %bb69
bb68:
  %t314 = load ptr, ptr %l2, !tbaa !29
  %t316 = getelementptr %"compiler/check:frame", ptr %t314, i32 0, i32 44
  store ptr %t316, ptr %l199, !tbaa !29
  %t317 = load i64, ptr %l25, !tbaa !24
  store i64 %t317, ptr %l200, !tbaa !24
  %t318 = load %"compiler/check:narrowed", ptr %l26
  %t320 = call %"compiler/check:narrowed" @compiler_2fcheck_2ecompiler_2fcheck_3anarrowed_2eKilled(%"compiler/check:narrowed" %t318)
  store %"compiler/check:narrowed" %t320, ptr %l202
  br label %bb70
bb69:
  br label %bb72
bb70:
  %t321 = load ptr, ptr %l199, !tbaa !29
  %t322 = load i64, ptr %l200, !tbaa !24
  %t323 = load %"compiler/check:narrowed", ptr %l202
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eSetAt_Hd90ea4a0afde5538aa0fe5c36a170321(ptr %v0, ptr %t321, i64 %t322, %"compiler/check:narrowed" %t323)
  br label %bb71
bb71:
  br label %bb72
bb72:
  call void @__olang_scope_close(ptr %s11)
  br label %bb73
bb73:
  %t324 = load i64, ptr %l24, !tbaa !24
  %t326 = add i64 %t324, 1
  store i64 %t326, ptr %l24, !tbaa !24
  br label %bb52
bb74:
  store i64 0, ptr %l28, !tbaa !24
  %t328 = load ptr, ptr %l2, !tbaa !29
  %t330 = getelementptr %"compiler/check:frame", ptr %t328, i32 0, i32 57
  %t332 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eLen__H3cdfcddd9c493bd8bcefc7b766e0438b(ptr %v0, ptr %t330)
  store i64 %t332, ptr %l207
  br label %bb75
bb75:
  %t333 = load i64, ptr %l207, !tbaa !24
  store i64 %t333, ptr %l29, !tbaa !24
  store i64 1, ptr %l30, !tbaa !24
  %t334 = load i64, ptr %l29, !tbaa !24
  %t335 = load i64, ptr %l28, !tbaa !24
  %t338 = icmp sgt i64 %t334, %t335
  br i1 %t338, label %bb76, label %bb77
bb76:
  %t340 = load i64, ptr %l30, !tbaa !24
  %t342 = icmp sgt i64 %t340, 0
  br i1 %t342, label %bb78, label %bb79
bb77:
  store i64 0, ptr %l211, !tbaa !24
  br label %bb81
bb78:
  %t344 = load i64, ptr %l29, !tbaa !24
  %t345 = load i64, ptr %l28, !tbaa !24
  %t348 = sub i64 %t344, %t345
  %t349 = load i64, ptr %l30, !tbaa !24
  %t352 = add i64 %t348, %t349
  %t354 = sub i64 %t352, 1
  %t355 = load i64, ptr %l30, !tbaa !24
  %t358 = sdiv i64 %t354, %t355
  store i64 %t358, ptr %l214, !tbaa !24
  br label %bb80
bb79:
  store i64 0, ptr %l214, !tbaa !24
  br label %bb80
bb80:
  %t360 = load i64, ptr %l214, !tbaa !24
  store i64 %t360, ptr %l211, !tbaa !24
  br label %bb81
bb81:
  %t361 = load i64, ptr %l211, !tbaa !24
  store i64 %t361, ptr %l31, !tbaa !24
  store i64 0, ptr %l32, !tbaa !24
  br label %bb82
bb82:
  store %olang.scope zeroinitializer, ptr %s18
  %t362 = load i64, ptr %l32, !tbaa !24
  %t363 = load i64, ptr %l31, !tbaa !24
  %t366 = icmp slt i64 %t362, %t363
  %t368 = xor i1 %t366, true
  br i1 %t368, label %bb83, label %bb84
bb83:
  call void @__olang_scope_close(ptr %s18)
  br label %bb101
bb84:
  br label %bb85
bb85:
  %t370 = load i64, ptr %l28, !tbaa !24
  %t371 = load i64, ptr %l32, !tbaa !24
  %t372 = load i64, ptr %l30, !tbaa !24
  %t375 = mul i64 %t371, %t372
  %t378 = add i64 %t370, %t375
  store i64 %t378, ptr %l33, !tbaa !24
  %t380 = load ptr, ptr %l2, !tbaa !29
  %t382 = getelementptr %"compiler/check:frame", ptr %t380, i32 0, i32 57
  %t383 = load i64, ptr %l33, !tbaa !24
  %t386 = call %"compiler/check:errNarrow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eAt_3ccompiler_2fcheck_3aerrNarrow_3e(ptr %v0, ptr %t382, i64 %t383)
  store %"compiler/check:errNarrow" %t386, ptr %l235
  br label %bb86
bb86:
  %t387 = load %"compiler/check:errNarrow", ptr %l235
  store %"compiler/check:errNarrow" %t387, ptr %l34
  %t388 = getelementptr %"compiler/check:errNarrow", ptr %l34, i32 0, i32 3
  %t389 = load i1, ptr %t388, !tbaa !21
  %t391 = xor i1 %t389, true
  br i1 %t391, label %bb87, label %bb88
bb87:
  %t393 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t393, ptr %l239, !tbaa !27
  %t394 = load i64, ptr %l10, !tbaa !24
  %t396 = getelementptr { i64, ptr }, ptr %l239, i32 0, i32 1
  %t397 = load ptr, ptr %t396, !tbaa !27
  %t398 = getelementptr ptr, ptr %t397, i64 %t394
  %t399 = load ptr, ptr %t398, !tbaa !39
  store ptr %t399, ptr %l242, !tbaa !29
  %t401 = getelementptr %"compiler/check:errNarrow", ptr %l34, i32 0, i32 0
  %t402 = load i32, ptr %t401, !tbaa !23
  store i32 %t402, ptr %l243, !tbaa !23
  %t403 = icmp sge i64 1, 0
  br i1 %t403, label %bb89, label %bb90
bb88:
  store i1 false, ptr %l238, !tbaa !21
  br label %bb94
bb89:
  %t405 = icmp sle i64 1, 2305843009213693951
  br i1 %t405, label %bb91, label %bb92
bb90:
  call void @__olang_check_failed(ptr @olang_loc_f0430e4b284237b0_c6243626a46be64)
  unreachable
bb91:
  %t407 = mul i64 1, 4
  %t408 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t407)
  %t409 = load i32, ptr %l243, !tbaa !23
  store i64 0, ptr %t410
  br label %fill.411
fill.411:
  %t414 = load i64, ptr %t410
  %t415 = icmp slt i64 %t414, 1
  br i1 %t415, label %fillb.412, label %filld.413
fillb.412:
  %t416 = getelementptr i32, ptr %t408, i64 %t414
  store i32 %t409, ptr %t416
  %t417 = add i64 %t414, 1
  store i64 %t417, ptr %t410
  br label %fill.411
filld.413:
  %t418 = insertvalue { i64, ptr } undef, i64 1, 0
  %t419 = insertvalue { i64, ptr } %t418, ptr %t408, 1
  %t420 = load ptr, ptr %l242, !tbaa !29
  %t422 = call i1 @compiler_2fcheck_2estmtAssigns(ptr %v1, ptr %s18, ptr %t420, { i64, ptr } %t419)
  store i1 %t422, ptr %l247
  br label %bb93
bb92:
  call void @__olang_check_failed(ptr @olang_loc_f0430e4b284237b0_c6243626a46be64)
  unreachable
bb93:
  %t423 = load i1, ptr %l247, !tbaa !21
  store i1 %t423, ptr %l238, !tbaa !21
  br label %bb94
bb94:
  %t424 = load i1, ptr %l238, !tbaa !21
  br i1 %t424, label %bb95, label %bb96
bb95:
  store %olang.scope zeroinitializer, ptr %s19
  %t425 = load ptr, ptr %l2, !tbaa !29
  %t427 = getelementptr %"compiler/check:frame", ptr %t425, i32 0, i32 57
  store ptr %t427, ptr %l249, !tbaa !29
  %t428 = load i64, ptr %l33, !tbaa !24
  store i64 %t428, ptr %l250, !tbaa !24
  %t429 = getelementptr %"compiler/check:errNarrow", ptr %l34, i32 0, i32 0
  %t430 = load i32, ptr %t429, !tbaa !23
  %t431 = getelementptr %"compiler/check:errNarrow", ptr %l34, i32 0, i32 1
  %t432 = load i32, ptr %t431, !tbaa !23
  %t433 = getelementptr %"compiler/check:errNarrow", ptr %l34, i32 0, i32 2
  %t434 = load i64, ptr %t433, !tbaa !24
  %t438 = call %"compiler/check:errNarrow" @compiler_2fcheck_3aerrNarrow_2ector(ptr %s19, i32 %t430, i32 %t432, i64 %t434, i1 true)
  store %"compiler/check:errNarrow" %t438, ptr %l254
  br label %bb97
bb96:
  br label %bb99
bb97:
  %t439 = load ptr, ptr %l249, !tbaa !29
  %t440 = load i64, ptr %l250, !tbaa !24
  %t441 = load %"compiler/check:errNarrow", ptr %l254
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eSetA_H34a7475a189e9b126454728216b32261(ptr %v0, ptr %t439, i64 %t440, %"compiler/check:errNarrow" %t441)
  br label %bb98
bb98:
  call void @__olang_scope_close(ptr %s19)
  br label %bb99
bb99:
  call void @__olang_scope_close(ptr %s18)
  br label %bb100
bb100:
  %t442 = load i64, ptr %l32, !tbaa !24
  %t444 = add i64 %t442, 1
  store i64 %t444, ptr %l32, !tbaa !24
  br label %bb82
bb101:
  %t446 = load ptr, ptr %l2, !tbaa !29
  store ptr %t446, ptr %l257, !tbaa !29
  %t447 = icmp sge i64 0, 0
  br i1 %t447, label %bb102, label %bb103
bb102:
  %t449 = icmp sle i64 0, 2305843009213693951
  br i1 %t449, label %bb104, label %bb105
bb103:
  call void @__olang_check_failed(ptr @olang_loc_28ca8569d2f90b5d_c88a44871853971)
  unreachable
bb104:
  %t451 = mul i64 0, 4
  %t452 = insertvalue { i64, ptr } undef, i64 0, 0
  %t453 = insertvalue { i64, ptr } %t452, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t455 = load ptr, ptr %l257, !tbaa !29
  %t456 = getelementptr %"compiler/check:frame", ptr %t455, i32 0, i32 46
  store { i64, ptr } %t453, ptr %t456, !tbaa !27
  %t457 = load ptr, ptr %l2, !tbaa !29
  %t459 = getelementptr %"compiler/check:frame", ptr %t457, i32 0, i32 47
  store i1 false, ptr %t459, !tbaa !21
  %t460 = load ptr, ptr %l0, !tbaa !29
  %t461 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t461, ptr %l263, !tbaa !27
  %t462 = load i64, ptr %l10, !tbaa !24
  %t464 = getelementptr { i64, ptr }, ptr %l263, i32 0, i32 1
  %t465 = load ptr, ptr %t464, !tbaa !27
  %t466 = getelementptr ptr, ptr %t465, i64 %t462
  %t467 = load ptr, ptr %t466, !tbaa !39
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmt(ptr %v0, ptr %v1, ptr %t460, ptr %t467)
  br label %bb106
bb105:
  call void @__olang_check_failed(ptr @olang_loc_28ca8569d2f90b5d_c88a44871853971)
  unreachable
bb106:
  %t471 = load ptr, ptr %l2, !tbaa !29
  %t473 = getelementptr %"compiler/check:frame", ptr %t471, i32 0, i32 47
  %t474 = load i1, ptr %t473, !tbaa !21
  br i1 %t474, label %bb107, label %bb108
bb107:
  %t476 = load ptr, ptr %l2, !tbaa !29
  %t478 = getelementptr %"compiler/check:frame", ptr %t476, i32 0, i32 47
  store i1 false, ptr %t478, !tbaa !21
  call void @__olang_scope_close(ptr %s3)
  br label %bb160
bb108:
  br label %bb109
bb109:
  store ptr %l11, ptr %l35, !tbaa !29
  store i64 0, ptr %l36, !tbaa !24
  br label %bb110
bb110:
  %t480 = load i64, ptr %l36, !tbaa !24
  store i64 %t480, ptr %l271, !tbaa !24
  %t481 = load ptr, ptr %l35, !tbaa !29
  %t483 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s3, ptr %t481)
  store i64 %t483, ptr %l273
  br label %bb111
bb111:
  %t484 = load i64, ptr %l271, !tbaa !24
  %t485 = load i64, ptr %l273, !tbaa !24
  %t486 = icmp slt i64 %t484, %t485
  %t488 = xor i1 %t486, true
  br i1 %t488, label %bb112, label %bb113
bb112:
  br label %bb125
bb113:
  br label %bb114
bb114:
  %t490 = load ptr, ptr %l35, !tbaa !29
  %t491 = load i64, ptr %l36, !tbaa !24
  %t494 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s3, ptr %t490, i64 %t491)
  store i64 %t494, ptr %l278
  br label %bb115
bb115:
  %t495 = load i64, ptr %l278, !tbaa !24
  store i64 %t495, ptr %l37, !tbaa !24
  %t496 = load i64, ptr %l37, !tbaa !24
  store i64 %t496, ptr %l279, !tbaa !24
  %t497 = load ptr, ptr %l2, !tbaa !29
  %t499 = getelementptr %"compiler/check:frame", ptr %t497, i32 0, i32 48
  %t501 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eLen_H4b13e48b0a317e727dbe35330ad8712a(ptr %v0, ptr %t499)
  store i64 %t501, ptr %l282
  br label %bb116
bb116:
  %t502 = load i64, ptr %l279, !tbaa !24
  %t503 = load i64, ptr %l282, !tbaa !24
  %t504 = icmp slt i64 %t502, %t503
  br i1 %t504, label %bb117, label %bb118
bb117:
  store %olang.scope zeroinitializer, ptr %s24
  %t506 = load ptr, ptr %l2, !tbaa !29
  %t508 = getelementptr %"compiler/check:frame", ptr %t506, i32 0, i32 48
  store ptr %t508, ptr %l285, !tbaa !29
  %t509 = load i64, ptr %l37, !tbaa !24
  store i64 %t509, ptr %l286, !tbaa !24
  %t510 = load ptr, ptr %l2, !tbaa !29
  %t512 = getelementptr %"compiler/check:frame", ptr %t510, i32 0, i32 48
  %t513 = load i64, ptr %l37, !tbaa !24
  %t516 = call %"compiler/check:nullNarrow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eAt__H22e551fb00043bde3f1f8b2c6007f7cb(ptr %v0, ptr %v0, ptr %t512, i64 %t513)
  store %"compiler/check:nullNarrow" %t516, ptr %l290
  br label %bb119
bb118:
  br label %bb123
bb119:
  %t517 = getelementptr %"compiler/check:nullNarrow", ptr %l290, i32 0, i32 0
  %t518 = load { i64, ptr }, ptr %t517, !tbaa !27
  store { i64, ptr } %t518, ptr %l291, !tbaa !27
  %t519 = load ptr, ptr %l2, !tbaa !29
  %t521 = getelementptr %"compiler/check:frame", ptr %t519, i32 0, i32 48
  %t522 = load i64, ptr %l37, !tbaa !24
  %t525 = call %"compiler/check:nullNarrow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eAt__H22e551fb00043bde3f1f8b2c6007f7cb(ptr %v0, ptr %s24, ptr %t521, i64 %t522)
  store %"compiler/check:nullNarrow" %t525, ptr %l295
  br label %bb120
bb120:
  %t526 = getelementptr %"compiler/check:nullNarrow", ptr %l295, i32 0, i32 1
  %t527 = load i64, ptr %t526, !tbaa !24
  %t528 = load { i64, ptr }, ptr %l291, !tbaa !27
  %t530 = call %"compiler/check:nullNarrow" @compiler_2fcheck_3anullNarrow_2ector(ptr %v0, ptr %v0, { i64, ptr } %t528, i64 %t527, i1 true)
  store %"compiler/check:nullNarrow" %t530, ptr %l297
  br label %bb121
bb121:
  %t531 = load ptr, ptr %l285, !tbaa !29
  %t532 = load i64, ptr %l286, !tbaa !24
  %t533 = load %"compiler/check:nullNarrow", ptr %l297
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eSet_H93968e49180de2bc6256fae5bb61b442(ptr %v0, ptr %v0, ptr %t531, i64 %t532, %"compiler/check:nullNarrow" %t533)
  br label %bb122
bb122:
  call void @__olang_scope_close(ptr %s24)
  br label %bb123
bb123:
  br label %bb124
bb124:
  %t534 = load i64, ptr %l36, !tbaa !24
  %t536 = add i64 %t534, 1
  store i64 %t536, ptr %l36, !tbaa !24
  br label %bb110
bb125:
  store ptr %l19, ptr %l38, !tbaa !29
  store i64 0, ptr %l39, !tbaa !24
  br label %bb126
bb126:
  %t539 = load i64, ptr %l39, !tbaa !24
  store i64 %t539, ptr %l301, !tbaa !24
  %t540 = load ptr, ptr %l38, !tbaa !29
  %t542 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s3, ptr %t540)
  store i64 %t542, ptr %l303
  br label %bb127
bb127:
  %t543 = load i64, ptr %l301, !tbaa !24
  %t544 = load i64, ptr %l303, !tbaa !24
  %t545 = icmp slt i64 %t543, %t544
  %t547 = xor i1 %t545, true
  br i1 %t547, label %bb128, label %bb129
bb128:
  br label %bb140
bb129:
  br label %bb130
bb130:
  %t549 = load ptr, ptr %l38, !tbaa !29
  %t550 = load i64, ptr %l39, !tbaa !24
  %t553 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s3, ptr %t549, i64 %t550)
  store i64 %t553, ptr %l308
  br label %bb131
bb131:
  %t554 = load i64, ptr %l308, !tbaa !24
  store i64 %t554, ptr %l40, !tbaa !24
  %t555 = load i64, ptr %l40, !tbaa !24
  store i64 %t555, ptr %l309, !tbaa !24
  %t556 = load ptr, ptr %l2, !tbaa !29
  %t558 = getelementptr %"compiler/check:frame", ptr %t556, i32 0, i32 44
  %t560 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eLen_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %t558)
  store i64 %t560, ptr %l312
  br label %bb132
bb132:
  %t561 = load i64, ptr %l309, !tbaa !24
  %t562 = load i64, ptr %l312, !tbaa !24
  %t563 = icmp slt i64 %t561, %t562
  br i1 %t563, label %bb133, label %bb134
bb133:
  %t565 = load ptr, ptr %l2, !tbaa !29
  %t567 = getelementptr %"compiler/check:frame", ptr %t565, i32 0, i32 44
  store ptr %t567, ptr %l315, !tbaa !29
  %t568 = load i64, ptr %l40, !tbaa !24
  store i64 %t568, ptr %l316, !tbaa !24
  %t569 = load ptr, ptr %l2, !tbaa !29
  %t571 = getelementptr %"compiler/check:frame", ptr %t569, i32 0, i32 44
  %t572 = load i64, ptr %l40, !tbaa !24
  %t575 = call %"compiler/check:narrowed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eAt_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %t571, i64 %t572)
  store %"compiler/check:narrowed" %t575, ptr %l320
  br label %bb135
bb134:
  br label %bb138
bb135:
  %t576 = load %"compiler/check:narrowed", ptr %l320
  %t577 = call %"compiler/check:narrowed" @compiler_2fcheck_2ecompiler_2fcheck_3anarrowed_2eKilled(%"compiler/check:narrowed" %t576)
  store %"compiler/check:narrowed" %t577, ptr %l321
  br label %bb136
bb136:
  %t578 = load ptr, ptr %l315, !tbaa !29
  %t579 = load i64, ptr %l316, !tbaa !24
  %t580 = load %"compiler/check:narrowed", ptr %l321
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eSetAt_Hd90ea4a0afde5538aa0fe5c36a170321(ptr %v0, ptr %t578, i64 %t579, %"compiler/check:narrowed" %t580)
  br label %bb137
bb137:
  br label %bb138
bb138:
  br label %bb139
bb139:
  %t581 = load i64, ptr %l39, !tbaa !24
  %t583 = add i64 %t581, 1
  store i64 %t583, ptr %l39, !tbaa !24
  br label %bb126
bb140:
  %t585 = load ptr, ptr %l2, !tbaa !29
  %t587 = getelementptr %"compiler/check:frame", ptr %t585, i32 0, i32 46
  %t588 = load { i64, ptr }, ptr %t587, !tbaa !27
  %t590 = extractvalue { i64, ptr } %t588, 0
  %t592 = icmp sgt i64 %t590, 0
  br i1 %t592, label %bb141, label %bb142
bb141:
  %t594 = load ptr, ptr %l2, !tbaa !29
  %t596 = getelementptr %"compiler/check:frame", ptr %t594, i32 0, i32 46
  %t597 = load { i64, ptr }, ptr %t596, !tbaa !27
  %t599 = extractvalue { i64, ptr } %t597, 0
  %t601 = icmp eq i64 %t599, 1
  store i1 %t601, ptr %l328, !tbaa !21
  br label %bb143
bb142:
  store i1 false, ptr %l328, !tbaa !21
  br label %bb143
bb143:
  %t603 = load i1, ptr %l328, !tbaa !21
  br i1 %t603, label %bb144, label %bb145
bb144:
  %t604 = load ptr, ptr %l2, !tbaa !29
  %t606 = getelementptr %"compiler/check:frame", ptr %t604, i32 0, i32 48
  store ptr %t606, ptr %l334, !tbaa !29
  %t607 = load ptr, ptr %l2, !tbaa !29
  %t609 = getelementptr %"compiler/check:frame", ptr %t607, i32 0, i32 46
  %t610 = load { i64, ptr }, ptr %t609, !tbaa !27
  store { i64, ptr } %t610, ptr %l41, !tbaa !27
  store i64 0, ptr %l42, !tbaa !24
  %t612 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t614 = extractvalue { i64, ptr } %t612, 0
  store i64 %t614, ptr %l43, !tbaa !24
  %t616 = load i64, ptr %l43, !tbaa !24
  %t618 = mul i64 %t616, 4
  %t619 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t618)
  %t620 = insertvalue { i64, ptr } undef, i64 %t616, 0
  %t621 = insertvalue { i64, ptr } %t620, ptr %t619, 1
  store { i64, ptr } %t621, ptr %l340, !tbaa !27
  store i64 0, ptr %l341, !tbaa !24
  br label %bb146
bb145:
  br label %bb158
bb146:
  %t622 = load i64, ptr %l42, !tbaa !24
  %t623 = load i64, ptr %l43, !tbaa !24
  %t626 = icmp slt i64 %t622, %t623
  %t628 = xor i1 %t626, true
  br i1 %t628, label %bb147, label %bb148
bb147:
  br label %bb151
bb148:
  br label %bb149
bb149:
  %t630 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t630, ptr %l346, !tbaa !27
  %t631 = load i64, ptr %l42, !tbaa !24
  %t633 = getelementptr { i64, ptr }, ptr %l346, i32 0, i32 1
  %t634 = load ptr, ptr %t633, !tbaa !27
  %t635 = getelementptr i32, ptr %t634, i64 %t631
  %t636 = load i32, ptr %t635, !tbaa !33
  %t640 = load i64, ptr %l341, !tbaa !24
  %t641 = getelementptr { i64, ptr }, ptr %l340, i32 0, i32 1
  %t642 = load ptr, ptr %t641, !tbaa !27
  %t643 = getelementptr i32, ptr %t642, i64 %t640
  store i32 %t636, ptr %t643, !tbaa !33
  %t644 = load i64, ptr %l341, !tbaa !24
  %t645 = add i64 %t644, 1
  store i64 %t645, ptr %l341, !tbaa !24
  br label %bb150
bb150:
  %t646 = load i64, ptr %l42, !tbaa !24
  %t648 = add i64 %t646, 1
  store i64 %t648, ptr %l42, !tbaa !24
  br label %bb146
bb151:
  %t650 = load ptr, ptr %l2, !tbaa !29
  %t652 = getelementptr %"compiler/check:frame", ptr %t650, i32 0, i32 7
  %t653 = load i64, ptr %t652, !tbaa !24
  %t654 = load { i64, ptr }, ptr %l340, !tbaa !27
  %t656 = call %"compiler/check:nullNarrow" @compiler_2fcheck_3anullNarrow_2ector(ptr %v0, ptr %v0, { i64, ptr } %t654, i64 %t653, i1 false)
  store %"compiler/check:nullNarrow" %t656, ptr %l354
  br label %bb152
bb152:
  %t657 = load ptr, ptr %l334, !tbaa !29
  %t658 = load %"compiler/check:nullNarrow", ptr %l354
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2ePus_H6cb9d90d121a5c1d081cb085b656665f(ptr %v0, ptr %v0, ptr %t657, %"compiler/check:nullNarrow" %t658)
  br label %bb153
bb153:
  %t659 = load ptr, ptr %l2, !tbaa !29
  store ptr %t659, ptr %l355, !tbaa !29
  %t660 = icmp sge i64 0, 0
  br i1 %t660, label %bb154, label %bb155
bb154:
  %t662 = icmp sle i64 0, 2305843009213693951
  br i1 %t662, label %bb156, label %bb157
bb155:
  call void @__olang_check_failed(ptr @olang_loc_8296d6abcbfdbd1e_e4e071066943c4d2)
  unreachable
bb156:
  %t664 = mul i64 0, 4
  %t665 = insertvalue { i64, ptr } undef, i64 0, 0
  %t666 = insertvalue { i64, ptr } %t665, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t668 = load ptr, ptr %l355, !tbaa !29
  %t669 = getelementptr %"compiler/check:frame", ptr %t668, i32 0, i32 46
  store { i64, ptr } %t666, ptr %t669, !tbaa !27
  br label %bb158
bb157:
  call void @__olang_check_failed(ptr @olang_loc_8296d6abcbfdbd1e_e4e071066943c4d2)
  unreachable
bb158:
  call void @__olang_scope_close(ptr %s3)
  br label %bb159
bb159:
  %t670 = load i64, ptr %l9, !tbaa !24
  %t672 = add i64 %t670, 1
  store i64 %t672, ptr %l9, !tbaa !24
  br label %bb11
bb160:
  %t674 = load ptr, ptr %l2, !tbaa !29
  %t675 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t678 = getelementptr %"compiler/check:frame", ptr %t674, i32 0, i32 49
  store { i64, ptr } %t675, ptr %t678, !tbaa !27
  %t679 = load ptr, ptr %l2, !tbaa !29
  %t680 = load i64, ptr %l4, !tbaa !24
  %t683 = getelementptr %"compiler/check:frame", ptr %t679, i32 0, i32 50
  store i64 %t680, ptr %t683, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estrBytes(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
  store { i64, ptr } %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t7 = call { i64, ptr } @compiler_2fscan_2eLiteralBytes(ptr %v0, ptr %v1, { i64, ptr } %t6)
  store { i64, ptr } %t7, ptr %l5
  br label %bb2
bb2:
  %t8 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 0
  %t10 = extractvalue { i64, ptr } %t8, 1
  %t11 = mul i64 %t9, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t10, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estrReceivers(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, [2 x i64] }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l22 = alloca i64
  %l26 = alloca i64
  %l29 = alloca i64
  %l50 = alloca i64
  %l52 = alloca i1
  %l54 = alloca ptr
  %l56 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l57 = alloca i1
  %l62 = alloca ptr
  %l71 = alloca i64
  %l75 = alloca ptr
  %l79 = alloca { i64, ptr }
  %l83 = alloca i1
  %l85 = alloca i1
  %l87 = alloca i1
  %l89 = alloca i1
  %l91 = alloca i1
  %l94 = alloca i1
  %l100 = alloca i64
  %l106 = alloca ptr
  %l122 = alloca i64
  %l123 = alloca { i64, ptr }
  %l124 = alloca i64
  %l127 = alloca i64
  %l128 = alloca i64
  %l134 = alloca i64
  %l135 = alloca i32
  %l138 = alloca i64
  %l148 = alloca ptr
  %l154 = alloca ptr
  %l162 = alloca { i64, [3 x i64] }
  %l163 = alloca %"compiler/msgs:Msg"
  %l164 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %t306 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l19
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l19
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l1
  store i64 0, ptr %l2, !tbaa !24
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/check:Checker", ptr %t3, i32 0, i32 14
  %t7 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t5)
  store i64 %t7, ptr %l22
  br label %bb2
bb2:
  %t8 = load i64, ptr %l22, !tbaa !24
  store i64 %t8, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb8
bb5:
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l4, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l29, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb7
bb7:
  %t35 = load i64, ptr %l29, !tbaa !24
  store i64 %t35, ptr %l26, !tbaa !24
  br label %bb8
bb8:
  %t36 = load i64, ptr %l26, !tbaa !24
  store i64 %t36, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t37 = load i64, ptr %l6, !tbaa !24
  %t38 = load i64, ptr %l5, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb76
bb11:
  br label %bb12
bb12:
  %t45 = load i64, ptr %l2, !tbaa !24
  %t46 = load i64, ptr %l6, !tbaa !24
  %t47 = load i64, ptr %l4, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  store i64 %t53, ptr %l7, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/check:Checker", ptr %t55, i32 0, i32 19
  %t58 = load i64, ptr %l7, !tbaa !24
  %t61 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t57, i64 %t58)
  store i64 %t61, ptr %l50
  br label %bb13
bb13:
  %t62 = load i64, ptr %l50, !tbaa !24
  %t63 = icmp ne i64 %t62, 2
  br i1 %t63, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l52, !tbaa !21
  br label %bb18
bb15:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/check:Checker", ptr %t65, i32 0, i32 69
  store ptr %t67, ptr %l54, !tbaa !29
  %t68 = load i64, ptr %l7, !tbaa !24
  %t70 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s2, i64 %t68, i64 0)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t70, ptr %l56
  br label %bb16
bb16:
  %t71 = load ptr, ptr %l54, !tbaa !29
  %t72 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l56
  %t73 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t71, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t72)
  store i1 %t73, ptr %l57
  br label %bb17
bb17:
  %t74 = load i1, ptr %l57, !tbaa !21
  %t75 = xor i1 %t74, true
  store i1 %t75, ptr %l52, !tbaa !21
  br label %bb18
bb18:
  %t77 = load i1, ptr %l52, !tbaa !21
  br i1 %t77, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s2)
  br label %bb75
bb20:
  br label %bb21
bb21:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/check:Checker", ptr %t78, i32 0, i32 14
  %t81 = load i64, ptr %l7, !tbaa !24
  %t84 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t80, i64 %t81)
  store ptr %t84, ptr %l62
  br label %bb22
bb22:
  %t85 = load ptr, ptr %l62, !tbaa !29
  %t87 = getelementptr %"compiler/typed:Body", ptr %t85, i32 0, i32 1
  %t88 = load { i64, [2 x i64] }, ptr %t87
  store { i64, [2 x i64] } %t88, ptr %l8
  %t90 = load { i64, [2 x i64] }, ptr %l8
  %t92 = extractvalue { i64, [2 x i64] } %t90, 0
  %t93 = icmp eq i64 %t92, 0
  br i1 %t93, label %bb23, label %bb24
bb23:
  %t95 = getelementptr { i64, [2 x i64] }, ptr %l8, i32 0, i32 1
  %t96 = getelementptr { i64 }, ptr %t95, i32 0, i32 0
  %t97 = load i64, ptr %t96
  store i64 %t97, ptr %l9, !tbaa !24
  br label %bb25
bb24:
  br label %bb69
bb25:
  store %olang.scope zeroinitializer, ptr %s4
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/check:Checker", ptr %t99, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t103 = load i64, ptr %l9, !tbaa !24
  %t106 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t102, i64 %t103)
  store i64 %t106, ptr %l71
  br label %bb26
bb26:
  %t107 = load i64, ptr %l71, !tbaa !24
  store i64 %t107, ptr %l10, !tbaa !24
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/check:Checker", ptr %t108, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t112 = load i64, ptr %l10, !tbaa !24
  %t115 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t111, i64 %t112)
  store ptr %t115, ptr %l75
  br label %bb27
bb27:
  %t116 = load ptr, ptr %l75, !tbaa !29
  store ptr %t116, ptr %l11, !tbaa !29
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load ptr, ptr %l11, !tbaa !29
  %t120 = getelementptr %"compiler/ast:Func", ptr %t118, i32 0, i32 2
  %t121 = load i32, ptr %t120, !tbaa !23
  %t124 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t117, i32 %t121)
  store { i64, ptr } %t124, ptr %l79
  br label %bb28
bb28:
  %t125 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t125, ptr %l12, !tbaa !27
  %t126 = load ptr, ptr %l11, !tbaa !29
  %t128 = getelementptr %"compiler/ast:Func", ptr %t126, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t131 = icmp eq ptr %t129, null
  br i1 %t131, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l83, !tbaa !21
  br label %bb36
bb30:
  %t133 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t135 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s4, { i64, ptr } %t133, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d30, i32 0, i32 1) })
  store i1 %t135, ptr %l85
  br label %bb31
bb31:
  %t136 = load i1, ptr %l85, !tbaa !21
  %t137 = xor i1 %t136, true
  br i1 %t137, label %bb32, label %bb33
bb32:
  %t139 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t141 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s4, { i64, ptr } %t139, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d31, i32 0, i32 1) })
  store i1 %t141, ptr %l89
  br label %bb34
bb33:
  store i1 false, ptr %l87, !tbaa !21
  br label %bb35
bb34:
  %t142 = load i1, ptr %l89, !tbaa !21
  %t143 = xor i1 %t142, true
  store i1 %t143, ptr %l87, !tbaa !21
  br label %bb35
bb35:
  %t145 = load i1, ptr %l87, !tbaa !21
  store i1 %t145, ptr %l83, !tbaa !21
  br label %bb36
bb36:
  %t146 = load i1, ptr %l83, !tbaa !21
  br i1 %t146, label %bb37, label %bb38
bb37:
  store i1 true, ptr %l91, !tbaa !21
  br label %bb40
bb38:
  %t147 = load i64, ptr %l10, !tbaa !24
  %t150 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %s0, ptr %l1, i64 %t147)
  store i1 %t150, ptr %l94
  br label %bb39
bb39:
  %t151 = load i1, ptr %l94, !tbaa !21
  store i1 %t151, ptr %l91, !tbaa !21
  br label %bb40
bb40:
  %t152 = load i1, ptr %l91, !tbaa !21
  br i1 %t152, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  br label %bb75
bb42:
  br label %bb43
bb43:
  %t153 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %s0, ptr %l1, i64 %t153, i1 true)
  br label %bb44
bb44:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = getelementptr %"compiler/check:Checker", ptr %t156, i32 0, i32 1
  %t159 = load ptr, ptr %t158, !tbaa !29
  %t160 = load i64, ptr %l10, !tbaa !24
  %t163 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t159, i64 %t160)
  store i64 %t163, ptr %l100
  br label %bb45
bb45:
  %t164 = load i64, ptr %l100, !tbaa !24
  store i64 %t164, ptr %l13, !tbaa !24
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/check:Checker", ptr %t165, i32 0, i32 1
  %t168 = load ptr, ptr %t167, !tbaa !29
  %t170 = getelementptr %"compiler/generic:Program", ptr %t168, i32 0, i32 0
  %t171 = load ptr, ptr %t170, !tbaa !29
  %t173 = getelementptr %"compiler/load:Loader", ptr %t171, i32 0, i32 10
  %t174 = load i64, ptr %l13, !tbaa !24
  %t177 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t173, i64 %t174)
  store ptr %t177, ptr %l106
  br label %bb46
bb46:
  %t178 = load ptr, ptr %l106, !tbaa !29
  %t180 = getelementptr %"compiler/load:Module", ptr %t178, i32 0, i32 6
  %t181 = load ptr, ptr %t180, !tbaa !29
  store ptr %t181, ptr %l14, !tbaa !29
  %t183 = load ptr, ptr %l14, !tbaa !29
  %t185 = icmp eq ptr %t183, null
  br i1 %t185, label %bb47, label %bb48
bb47:
  call void @__olang_check_failed(ptr @olang_loc_7cf0066f219391e3_f59e2f38f1229917)
  unreachable
bb48:
  br label %bb49
bb49:
  %t187 = load ptr, ptr %l14, !tbaa !29
  %t190 = getelementptr %"compiler/source:Source", ptr %t187, i32 0, i32 1
  %t191 = load { i64, ptr }, ptr %t190, !tbaa !27
  store { i64, ptr } %t191, ptr %l15, !tbaa !27
  %t193 = load ptr, ptr %l11, !tbaa !29
  %t195 = getelementptr %"compiler/ast:Func", ptr %t193, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !29
  %t198 = icmp eq ptr %t196, null
  br i1 %t198, label %bb50, label %bb51
bb50:
  call void @__olang_check_failed(ptr @olang_loc_93e3a02800d00d4_2c47855b6b12ccf8)
  unreachable
bb51:
  br label %bb52
bb52:
  %t200 = load ptr, ptr %l11, !tbaa !29
  %t202 = getelementptr %"compiler/ast:Func", ptr %t200, i32 0, i32 1
  %t203 = load ptr, ptr %t202, !tbaa !29
  %t206 = getelementptr %"compiler/ast:Param", ptr %t203, i32 0, i32 0
  %t207 = getelementptr %"compiler/source:Span", ptr %t206, i32 0, i32 1
  %t208 = load i32, ptr %t207, !tbaa !23
  %t210 = sext i32 %t208 to i64
  store i64 %t210, ptr %l16, !tbaa !24
  %t212 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t212, ptr %l123, !tbaa !27
  %t213 = load i64, ptr %l16, !tbaa !24
  store i64 %t213, ptr %l124, !tbaa !24
  %t214 = load ptr, ptr %l11, !tbaa !29
  %t216 = getelementptr %"compiler/ast:Func", ptr %t214, i32 0, i32 0
  %t217 = getelementptr %"compiler/source:Span", ptr %t216, i32 0, i32 1
  %t218 = load i32, ptr %t217, !tbaa !23
  %t220 = sext i32 %t218 to i64
  store i64 %t220, ptr %l127, !tbaa !24
  %t221 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t222 = extractvalue { i64, ptr } %t221, 0
  store i64 %t222, ptr %l128, !tbaa !24
  %t223 = load i64, ptr %l124, !tbaa !24
  %t224 = icmp sge i64 %t223, 0
  br i1 %t224, label %bb53, label %bb54
bb53:
  %t226 = load i64, ptr %l124, !tbaa !24
  %t227 = load i64, ptr %l127, !tbaa !24
  %t228 = icmp sle i64 %t226, %t227
  br i1 %t228, label %bb55, label %bb56
bb54:
  call void @__olang_check_failed(ptr @olang_loc_ead499c86a25c3f7_b1128c547d2ccfbb)
  unreachable
bb55:
  %t230 = load i64, ptr %l127, !tbaa !24
  %t231 = load i64, ptr %l128, !tbaa !24
  %t232 = icmp sle i64 %t230, %t231
  br i1 %t232, label %bb57, label %bb58
bb56:
  call void @__olang_check_failed(ptr @olang_loc_ead499c86a25c3f7_b1128c547d2ccfbb)
  unreachable
bb57:
  %t234 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !27
  %t236 = load i64, ptr %l124, !tbaa !24
  %t237 = load i64, ptr %l127, !tbaa !24
  %t238 = getelementptr i8, ptr %t235, i64 %t236
  %t239 = sub i64 %t237, %t236
  %t240 = insertvalue { i64, ptr } undef, i64 %t239, 0
  %t241 = insertvalue { i64, ptr } %t240, ptr %t238, 1
  %t242 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t245 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v0, { i64, ptr } %t241, { i64, ptr } %t242)
  %t246 = extractvalue { i32, i64 } %t245, 1
  %t247 = extractvalue { i32, i64 } %t245, 0
  store i32 %t247, ptr %l135
  %t248 = icmp ne i32 %t247, 0
  br i1 %t248, label %bb60, label %ok.249, !prof !99
ok.249:
  store i64 %t246, ptr %l134
  br label %bb59
bb58:
  call void @__olang_check_failed(ptr @olang_loc_ead499c86a25c3f7_b1128c547d2ccfbb)
  unreachable
bb59:
  %t250 = load i64, ptr %l134, !tbaa !24
  store i64 %t250, ptr %l122, !tbaa !24
  br label %bb62
bb60:
  br label %bb61
bb61:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l122, !tbaa !24
  br label %bb62
bb62:
  %t251 = load i64, ptr %l122, !tbaa !24
  store i64 %t251, ptr %l17, !tbaa !24
  %t252 = load i64, ptr %l17, !tbaa !24
  %t254 = icmp slt i64 %t252, 0
  br i1 %t254, label %bb63, label %bb64
bb63:
  %t256 = load ptr, ptr %l11, !tbaa !29
  %t258 = getelementptr %"compiler/ast:Func", ptr %t256, i32 0, i32 0
  %t259 = getelementptr %"compiler/source:Span", ptr %t258, i32 0, i32 0
  %t260 = load i32, ptr %t259, !tbaa !23
  %t262 = sext i32 %t260 to i64
  store i64 %t262, ptr %l138, !tbaa !24
  br label %bb65
bb64:
  %t264 = load i64, ptr %l16, !tbaa !24
  %t265 = load i64, ptr %l17, !tbaa !24
  %t268 = add i64 %t264, %t265
  store i64 %t268, ptr %l138, !tbaa !24
  br label %bb65
bb65:
  %t270 = load i64, ptr %l138, !tbaa !24
  store i64 %t270, ptr %l18, !tbaa !24
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t273 = getelementptr %"compiler/check:Checker", ptr %t271, i32 0, i32 1
  %t274 = load ptr, ptr %t273, !tbaa !29
  %t276 = getelementptr %"compiler/generic:Program", ptr %t274, i32 0, i32 0
  %t277 = load ptr, ptr %t276, !tbaa !29
  %t279 = getelementptr %"compiler/load:Loader", ptr %t277, i32 0, i32 4
  %t280 = load ptr, ptr %t279, !tbaa !29
  store ptr %t280, ptr %l148, !tbaa !29
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t283 = getelementptr %"compiler/check:Checker", ptr %t281, i32 0, i32 1
  %t284 = load ptr, ptr %t283, !tbaa !29
  %t286 = getelementptr %"compiler/generic:Program", ptr %t284, i32 0, i32 0
  %t287 = load ptr, ptr %t286, !tbaa !29
  %t289 = getelementptr %"compiler/load:Loader", ptr %t287, i32 0, i32 10
  %t290 = load i64, ptr %l13, !tbaa !24
  %t293 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t289, i64 %t290)
  store ptr %t293, ptr %l154
  br label %bb66
bb66:
  %t294 = load ptr, ptr %l154, !tbaa !29
  %t296 = getelementptr %"compiler/load:Module", ptr %t294, i32 0, i32 4
  %t297 = load i64, ptr %t296, !tbaa !24
  %t298 = load i64, ptr %l18, !tbaa !24
  %t299 = load i64, ptr %l18, !tbaa !24
  %t300 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t302 = extractvalue { i64, ptr } %t300, 0
  %t305 = add i64 %t299, %t302
  store { i64, [3 x i64] } zeroinitializer, ptr %t306
  %t307 = getelementptr { i64, [3 x i64] }, ptr %t306, i32 0, i32 0
  store i64 3, ptr %t307
  %t309 = insertvalue { i64, i64, i64 } undef, i64 %t297, 0
  %t311 = insertvalue { i64, i64, i64 } %t309, i64 %t298, 1
  %t313 = insertvalue { i64, i64, i64 } %t311, i64 %t305, 2
  %t314 = getelementptr { i64, [3 x i64] }, ptr %t306, i32 0, i32 1
  store { i64, i64, i64 } %t313, ptr %t314
  %t315 = load { i64, [3 x i64] }, ptr %t306
  store { i64, [3 x i64] } %t315, ptr %l162
  %t316 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eStrReceiverWritable(ptr %s4)
  store %"compiler/msgs:Msg" %t316, ptr %l163
  br label %bb67
bb67:
  %t317 = load ptr, ptr %l148, !tbaa !29
  %t318 = load { i64, [3 x i64] }, ptr %l162
  %t319 = load %"compiler/msgs:Msg", ptr %l163
  %t320 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s4, ptr %t317, { i64, [3 x i64] } %t318, %"compiler/msgs:Msg" %t319)
  store i64 %t320, ptr %l164
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s4)
  br label %bb74
bb69:
  br i1 true, label %bb70, label %bb71
bb70:
  br label %bb72
bb71:
  br label %bb73
bb72:
  br label %bb74
bb73:
  call void @__olang_check_failed(ptr @olang_loc_4caebcac4cec7311_26f3d9a9847d99e5)
  unreachable
bb74:
  call void @__olang_scope_close(ptr %s2)
  br label %bb75
bb75:
  %t321 = load i64, ptr %l6, !tbaa !24
  %t323 = add i64 %t321, 1
  store i64 %t323, ptr %l6, !tbaa !24
  br label %bb9
bb76:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextConst(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2, i32 %a3) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %lp4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i64
  %l20 = alloca i64
  %l23 = alloca i64
  %l42 = alloca { i64, ptr }
  %l48 = alloca %"compiler/source:Span"
  %l49 = alloca i32
  %l51 = alloca ptr
  %rv = alloca ptr
  %t95 = alloca { i64, [2 x i64] }, align 8
  %t103 = alloca { i64, [5 x i64] }, align 8
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l12, !tbaa !24
  %t4 = load i64, ptr %l12, !tbaa !24
  %t5 = icmp sge i64 %t4, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l12, !tbaa !24
  %t8 = mul i64 %t7, 1
  %t9 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  %t12 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t12, ptr %lp4
  %t14 = load ptr, ptr %lp4
  store { i64, ptr } %t11, ptr %t14, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  store i64 %t17, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t19 = load i64, ptr %l6, !tbaa !24
  %t20 = load i64, ptr %l5, !tbaa !24
  %t23 = icmp sgt i64 %t19, %t20
  br i1 %t23, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_35044444f92db59c_e1f3123be845f968)
  unreachable
bb3:
  %t25 = load i64, ptr %l7, !tbaa !24
  %t27 = icmp sgt i64 %t25, 0
  br i1 %t27, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb8
bb5:
  %t29 = load i64, ptr %l6, !tbaa !24
  %t30 = load i64, ptr %l5, !tbaa !24
  %t33 = sub i64 %t29, %t30
  %t34 = load i64, ptr %l7, !tbaa !24
  %t37 = add i64 %t33, %t34
  %t39 = sub i64 %t37, 1
  %t40 = load i64, ptr %l7, !tbaa !24
  %t43 = sdiv i64 %t39, %t40
  store i64 %t43, ptr %l23, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb7
bb7:
  %t45 = load i64, ptr %l23, !tbaa !24
  store i64 %t45, ptr %l20, !tbaa !24
  br label %bb8
bb8:
  %t46 = load i64, ptr %l20, !tbaa !24
  store i64 %t46, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb9
bb9:
  %t47 = load i64, ptr %l9, !tbaa !24
  %t48 = load i64, ptr %l8, !tbaa !24
  %t51 = icmp slt i64 %t47, %t48
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb10, label %bb11
bb10:
  br label %bb14
bb11:
  br label %bb12
bb12:
  %t55 = load i64, ptr %l5, !tbaa !24
  %t56 = load i64, ptr %l9, !tbaa !24
  %t57 = load i64, ptr %l7, !tbaa !24
  %t60 = mul i64 %t56, %t57
  %t63 = add i64 %t55, %t60
  store i64 %t63, ptr %l10, !tbaa !24
  %t65 = load i64, ptr %l10, !tbaa !24
  %t66 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t66, ptr %l42, !tbaa !27
  %t67 = load i64, ptr %l10, !tbaa !24
  %t69 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr i8, ptr %t70, i64 %t67
  %t72 = load i8, ptr %t71, !tbaa !32
  %t75 = load ptr, ptr %lp4
  %t77 = getelementptr { i64, ptr }, ptr %t75, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr i8, ptr %t78, i64 %t65
  store i8 %t72, ptr %t79, !tbaa !32
  br label %bb13
bb13:
  %t80 = load i64, ptr %l9, !tbaa !24
  %t82 = add i64 %t80, 1
  store i64 %t82, ptr %l9, !tbaa !24
  br label %bb9
bb14:
  store %"compiler/source:Span" %a1, ptr %l48
  store i32 %a3, ptr %l49, !tbaa !23
  %t88 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %a0)
  store ptr %t88, ptr %l51
  br label %bb15
bb15:
  %t89 = load ptr, ptr %l51, !tbaa !29
  %t91 = getelementptr %"compiler/check:frame", ptr %t89, i32 0, i32 2
  %t92 = load i64, ptr %t91, !tbaa !24
  %t93 = load ptr, ptr %lp4
  %t94 = load { i64, ptr }, ptr %t93, !tbaa !27
  store { i64, [2 x i64] } zeroinitializer, ptr %t95
  %t96 = getelementptr { i64, [2 x i64] }, ptr %t95, i32 0, i32 0
  store i64 1, ptr %t96
  %t98 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t94, 0
  %t99 = getelementptr { i64, [2 x i64] }, ptr %t95, i32 0, i32 1
  store { { i64, ptr } } %t98, ptr %t99
  %t100 = load { i64, [2 x i64] }, ptr %t95
  %t102 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 24, i64 8)
  store { i64, [2 x i64] } %t100, ptr %t102
  store { i64, [5 x i64] } zeroinitializer, ptr %t103
  %t104 = getelementptr { i64, [5 x i64] }, ptr %t103, i32 0, i32 0
  store i64 1, ptr %t104
  %t105 = load %"compiler/source:Span", ptr %l48
  %t106 = insertvalue { %"compiler/source:Span", i32, i64, ptr } undef, %"compiler/source:Span" %t105, 0
  %t107 = load i32, ptr %l49, !tbaa !23
  %t108 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t106, i32 %t107, 1
  %t110 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t108, i64 %t92, 2
  %t112 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t110, ptr %t102, 3
  %t113 = getelementptr { i64, [5 x i64] }, ptr %t103, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64, ptr } %t112, ptr %t113
  %t114 = load { i64, [5 x i64] }, ptr %t103
  %t116 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t114, ptr %t116
  store ptr %t116, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %a0, i32 %a1)
  store { i64, ptr } %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t7 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %t6)
  store { i64, ptr } %t7, ptr %l5
  br label %bb2
bb2:
  %t8 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t8, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeCase(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3, %"compiler/source:Span" %a4, ptr %a5, i32 %a6, ptr %a7) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i32
  %l8 = alloca i32
  %lp9 = alloca ptr
  %lp10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i64
  %l19 = alloca ptr
  %l24 = alloca i32
  %l31 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca %"compiler/source:Span"
  %l38 = alloca i32
  %l39 = alloca i32
  %l40 = alloca ptr
  %l44 = alloca ptr
  %l46 = alloca ptr
  %l49 = alloca { i64, ptr }
  %l50 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca %"compiler/source:Span"
  %l57 = alloca ptr
  %l60 = alloca ptr
  %l61 = alloca ptr
  %l62 = alloca i32
  %l63 = alloca %"compiler/source:Span"
  %l66 = alloca i32
  %l69 = alloca i64
  %l73 = alloca ptr
  %l78 = alloca %"compiler/typed:Bind"
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  %t106 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a3, ptr %l3
  store ptr %a5, ptr %l5
  store i32 %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l6, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load %"compiler/source:Span", ptr %l1
  %t9 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t13 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v4, ptr %t7, %"compiler/source:Span" %t8, i32 %t9, i64 0)
  store ptr %t13, ptr %l19
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t14 = load ptr, ptr %l19, !tbaa !29
  store ptr %t14, ptr %rv
  br label %ret
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load %"compiler/source:Span", ptr %l1
  %t17 = load i32, ptr %l6, !tbaa !23
  %t23 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyCaseType(ptr %v0, ptr %v1, ptr %t15, %"compiler/source:Span" %t16, i32 %t17, ptr %a2)
  store i32 %t23, ptr %l24
  br label %bb5
bb5:
  %t24 = load i32, ptr %l24, !tbaa !23
  store i32 %t24, ptr %l8, !tbaa !23
  %t25 = load i32, ptr %l8, !tbaa !23
  %t26 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t29 = icmp eq i32 %t25, %t26
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load %"compiler/source:Span", ptr %l1
  %t33 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t37 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v4, ptr %t31, %"compiler/source:Span" %t32, i32 %t33, i64 0)
  store ptr %t37, ptr %l31
  br label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t38 = load ptr, ptr %l31, !tbaa !29
  store ptr %t38, ptr %rv
  br label %ret
bb9:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load %"compiler/source:Span", ptr %l1
  %t41 = load ptr, ptr %l5, !tbaa !29
  %t45 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v2, ptr %v4, ptr %t39, %"compiler/source:Span" %t40, ptr %t41)
  store ptr %t45, ptr %l35
  br label %bb10
bb10:
  %t46 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 8, i64 8)
  store ptr %t46, ptr %lp9
  %t47 = load ptr, ptr %l35, !tbaa !29
  %t48 = load ptr, ptr %lp9
  store ptr %t47, ptr %t48, !tbaa !29
  %t49 = load ptr, ptr %l0, !tbaa !29
  store ptr %t49, ptr %l36, !tbaa !29
  %t50 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t50, ptr %l37
  %t51 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t51, ptr %l38, !tbaa !23
  store i32 42, ptr %l39
  %t52 = load ptr, ptr %lp9
  %t53 = load ptr, ptr %t52, !tbaa !29
  store ptr %t53, ptr %l40, !tbaa !29
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load %"compiler/source:Span", ptr %l1
  %t56 = load i32, ptr %l8, !tbaa !23
  %t60 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t54, %"compiler/source:Span" %t55, i32 %t56, i64 0)
  store ptr %t60, ptr %l44
  br label %bb11
bb11:
  %t61 = load ptr, ptr %l44, !tbaa !29
  %t62 = load ptr, ptr %l36, !tbaa !29
  %t63 = load %"compiler/source:Span", ptr %l37
  %t64 = load i32, ptr %l38, !tbaa !23
  %t65 = load i32, ptr %l39, !range !{i32 0, i32 43}
  %t66 = load ptr, ptr %l40, !tbaa !29
  %t68 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v4, ptr %v0, ptr %v4, ptr %t62, %"compiler/source:Span" %t63, i32 %t64, i32 %t65, ptr %t66, ptr %t61)
  store ptr %t68, ptr %l46
  br label %bb12
bb12:
  %t69 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 8, i64 8)
  store ptr %t69, ptr %lp10
  %t70 = load ptr, ptr %l46, !tbaa !29
  %t71 = load ptr, ptr %lp10
  store ptr %t70, ptr %t71, !tbaa !29
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load i32, ptr %l3, !tbaa !23
  %t76 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t72, i32 %t73)
  store { i64, ptr } %t76, ptr %l49
  br label %bb13
bb13:
  %t77 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t78 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t77, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) })
  store i1 %t78, ptr %l50
  br label %bb14
bb14:
  %t79 = load i1, ptr %l50, !tbaa !21
  %t80 = xor i1 %t79, true
  br i1 %t80, label %bb15, label %bb16
bb15:
  %t82 = load ptr, ptr %l0, !tbaa !29
  store ptr %t82, ptr %l52, !tbaa !29
  %t83 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t83, ptr %l53
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load %"compiler/source:Span", ptr %l1
  %t86 = load ptr, ptr %l5, !tbaa !29
  %t90 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v2, ptr %v2, ptr %t84, %"compiler/source:Span" %t85, ptr %t86)
  store ptr %t90, ptr %l57
  br label %bb17
bb16:
  br label %bb24
bb17:
  %t91 = load i32, ptr %l8, !tbaa !23
  %t92 = load ptr, ptr %l52, !tbaa !29
  %t93 = load %"compiler/source:Span", ptr %l53
  %t94 = load ptr, ptr %l57, !tbaa !29
  %t97 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyInstance(ptr %v0, ptr %v2, ptr %v0, ptr %t92, %"compiler/source:Span" %t93, ptr %t94, i32 %t91, i32 0)
  store ptr %t97, ptr %l60
  br label %bb18
bb18:
  %t98 = load ptr, ptr %l60, !tbaa !29
  store ptr %t98, ptr %l11, !tbaa !29
  %t99 = load ptr, ptr %l0, !tbaa !29
  store ptr %t99, ptr %l61, !tbaa !29
  %t100 = load i32, ptr %l3, !tbaa !23
  store i32 %t100, ptr %l62, !tbaa !23
  store %"compiler/source:Span" %a4, ptr %l63
  %t102 = load ptr, ptr %l11, !tbaa !29
  %t105 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t102)
  store i32 %t105, ptr %l66
  br label %bb19
bb19:
  store { i64, [2 x i64] } zeroinitializer, ptr %t106
  %t107 = getelementptr { i64, [2 x i64] }, ptr %t106, i32 0, i32 0
  store i64 5, ptr %t107
  %t108 = load { i64, [2 x i64] }, ptr %t106
  %t109 = load ptr, ptr %l61, !tbaa !29
  %t110 = load i32, ptr %l62, !tbaa !23
  %t111 = load %"compiler/source:Span", ptr %l63
  %t112 = load i32, ptr %l66, !tbaa !23
  %t115 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t109, i32 %t110, %"compiler/source:Span" %t111, i32 %t112, i32 4, { i64, [2 x i64] } %t108)
  store i64 %t115, ptr %l69
  br label %bb20
bb20:
  %t116 = load i64, ptr %l69, !tbaa !24
  store i64 %t116, ptr %l12, !tbaa !24
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load i64, ptr %l12, !tbaa !24
  %t119 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLet(ptr %v0, ptr %v0, ptr %t117, i64 %t118, ptr %t119)
  br label %bb21
bb21:
  store ptr %a7, ptr %l73, !tbaa !29
  %t124 = load i64, ptr %l12, !tbaa !24
  %t126 = trunc i64 %t124 to i32
  %t128 = load ptr, ptr %l11, !tbaa !29
  %t131 = call %"compiler/typed:Bind" @compiler_2ftyped_3aBind_2ector(ptr %v0, ptr %v3, i32 %t126, ptr %t128)
  store %"compiler/typed:Bind" %t131, ptr %l78
  br label %bb22
bb22:
  %t132 = load %"compiler/typed:Bind", ptr %l78
  %t133 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 16, i64 8)
  store %"compiler/typed:Bind" %t132, ptr %t133
  %t134 = load ptr, ptr %l73, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBind_26_3e_2ePush_3ccompiler_2ftyped_3aBind_26_3e(ptr %v3, ptr %v3, ptr %t134, ptr %t133)
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t136 = load ptr, ptr %lp10
  %t137 = load ptr, ptr %t136, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t137, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeKindType(ptr %v0, ptr %a0) #0 {
entry:
  %l3 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %s0, ptr %s0, ptr %t4, { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d33, i32 0, i32 1) }, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d34, i32 0, i32 1) })
  store i32 %t6, ptr %l3
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t7 = load i32, ptr %l3, !tbaa !23
  store i32 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunary(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i32
  %lp5 = alloca ptr
  %lp6 = alloca ptr
  %lp7 = alloca ptr
  %l13 = alloca ptr
  %l21 = alloca ptr
  %l30 = alloca ptr
  %l33 = alloca i64
  %l35 = alloca i1
  %l36 = alloca ptr
  %l39 = alloca i32
  %l40 = alloca i1
  %l45 = alloca ptr
  %l49 = alloca i32
  %l52 = alloca i1
  %l55 = alloca i32
  %l58 = alloca ptr
  %l60 = alloca %"compiler/source:Span"
  %l61 = alloca ptr
  %l64 = alloca i32
  %l65 = alloca { i64, ptr }
  %l67 = alloca %"compiler/msgs:Msg"
  %l68 = alloca i64
  %l72 = alloca ptr
  %l76 = alloca i1
  %l80 = alloca ptr
  %l85 = alloca ptr
  %l87 = alloca %"compiler/source:Span"
  %l88 = alloca ptr
  %l91 = alloca i64
  %l93 = alloca i1
  %l94 = alloca ptr
  %l97 = alloca i32
  %l98 = alloca i1
  %l103 = alloca ptr
  %l109 = alloca ptr
  %l113 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l114 = alloca ptr
  %l118 = alloca ptr
  %l119 = alloca %"compiler/source:Span"
  %l121 = alloca i32
  %l123 = alloca { i64, ptr }
  %l127 = alloca i32
  %l128 = alloca %"compiler/typed:Text"
  %l136 = alloca ptr
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca ptr
  %t253 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t3 = trunc i64 18 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load %"compiler/source:Span", ptr %l1
  %t8 = load ptr, ptr %l3, !tbaa !29
  %t12 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eembed(ptr %v0, ptr %v1, ptr %v2, ptr %t6, %"compiler/source:Span" %t7, ptr %t8)
  store ptr %t12, ptr %l13
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t13 = load ptr, ptr %l13, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t13, ptr %rv
  br label %ret
bb4:
  %t15 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t17 = trunc i64 51 to i32
  %t18 = icmp eq i32 %t15, %t17
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load %"compiler/source:Span", ptr %l1
  %t22 = load ptr, ptr %l3, !tbaa !29
  %t23 = load i32, ptr %l4, !tbaa !23
  %t28 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecomptime(ptr %v0, ptr %v1, ptr %v2, ptr %t20, %"compiler/source:Span" %t21, ptr %t22, i32 %t23)
  store ptr %t28, ptr %l21
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t29 = load ptr, ptr %l21, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t29, ptr %rv
  br label %ret
bb8:
  %t31 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t33 = trunc i64 48 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/check:Checker", ptr %t36, i32 0, i32 40
  store i1 true, ptr %t38, !tbaa !21
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t42 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t46 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t39, ptr %t40, i32 %t42)
  store ptr %t46, ptr %l30
  br label %bb11
bb10:
  br label %bb36
bb11:
  %t47 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store ptr %t47, ptr %lp5
  %t48 = load ptr, ptr %l30, !tbaa !29
  %t49 = load ptr, ptr %lp5
  store ptr %t48, ptr %t49, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load ptr, ptr %lp5
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t55 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneOf(ptr %v0, ptr %v2, ptr %t50, ptr %t52)
  store i64 %t55, ptr %l33
  br label %bb12
bb12:
  %t56 = load i64, ptr %l33, !tbaa !24
  %t57 = icmp sge i64 %t56, 0
  br i1 %t57, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb17
bb14:
  %t59 = load ptr, ptr %l0, !tbaa !29
  store ptr %t59, ptr %l36, !tbaa !29
  %t60 = load ptr, ptr %lp5
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t64 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t61)
  store i32 %t64, ptr %l39
  br label %bb15
bb15:
  %t65 = load ptr, ptr %l36, !tbaa !29
  %t66 = load i32, ptr %l39, !tbaa !23
  %t67 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArray(ptr %v0, ptr %t65, i32 %t66)
  store i1 %t67, ptr %l40
  br label %bb16
bb16:
  %t68 = load i1, ptr %l40, !tbaa !21
  store i1 %t68, ptr %l35, !tbaa !21
  br label %bb17
bb17:
  %t69 = load i1, ptr %l35, !tbaa !21
  br i1 %t69, label %bb18, label %bb19
bb18:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load %"compiler/source:Span", ptr %l1
  %t72 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t73 = load ptr, ptr %lp5
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t79 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneUnary(ptr %v0, ptr %v2, ptr %v2, ptr %t70, %"compiler/source:Span" %t71, i32 %t72, ptr %t74)
  store ptr %t79, ptr %l45
  br label %bb20
bb19:
  br label %bb21
bb20:
  %t80 = load ptr, ptr %l45, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t80, ptr %rv
  br label %ret
bb21:
  %t82 = load ptr, ptr %lp5
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t86 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t83)
  store i32 %t86, ptr %l49
  br label %bb22
bb22:
  %t87 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t88 = load i32, ptr %l49, !tbaa !23
  %t90 = icmp ne i32 %t88, %t87
  br i1 %t90, label %bb23, label %bb24
bb23:
  %t92 = load ptr, ptr %lp5
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t96 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t93)
  store i32 %t96, ptr %l55
  br label %bb25
bb24:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb26
bb25:
  %t97 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t98 = load i32, ptr %l55, !tbaa !23
  %t100 = icmp ne i32 %t98, %t97
  store i1 %t100, ptr %l52, !tbaa !21
  br label %bb26
bb26:
  %t102 = load i1, ptr %l52, !tbaa !21
  br i1 %t102, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s5
  %t103 = load ptr, ptr %l0, !tbaa !29
  store ptr %t103, ptr %l58, !tbaa !29
  %t104 = load ptr, ptr %l3, !tbaa !29
  %t106 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t104)
  store %"compiler/source:Span" %t106, ptr %l60
  br label %bb29
bb28:
  br label %bb34
bb29:
  %t107 = load ptr, ptr %l0, !tbaa !29
  store ptr %t107, ptr %l61, !tbaa !29
  %t108 = load ptr, ptr %lp5
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t112 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t109)
  store i32 %t112, ptr %l64
  br label %bb30
bb30:
  %t113 = load ptr, ptr %l61, !tbaa !29
  %t114 = load i32, ptr %l64, !tbaa !23
  %t115 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s5, ptr %t113, i32 %t114)
  store { i64, ptr } %t115, ptr %l65
  br label %bb31
bb31:
  %t116 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t117 = extractvalue { i64, ptr } %t116, 0
  %t118 = extractvalue { i64, ptr } %t116, 1
  %t119 = mul i64 %t117, 1
  %t120 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t119)
  call void @llvm.memcpy.p0.p0.i64(ptr %t120, ptr %t118, i64 %t119, i1 false)
  %t121 = insertvalue { i64, ptr } undef, i64 %t117, 0
  %t122 = insertvalue { i64, ptr } %t121, ptr %t120, 1
  %t124 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eOperandNotBool(ptr %s5, ptr %s5, ptr %s5, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d35, i32 0, i32 1) }, { i64, ptr } %t122)
  store %"compiler/msgs:Msg" %t124, ptr %l67
  br label %bb32
bb32:
  %t125 = load ptr, ptr %l58, !tbaa !29
  %t126 = load %"compiler/source:Span", ptr %l60
  %t127 = load %"compiler/msgs:Msg", ptr %l67
  %t128 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t125, %"compiler/source:Span" %t126, %"compiler/msgs:Msg" %t127)
  store i64 %t128, ptr %l68
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s5)
  br label %bb34
bb34:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = load %"compiler/source:Span", ptr %l1
  %t131 = load ptr, ptr %lp5
  %t132 = load ptr, ptr %t131, !tbaa !29
  %t136 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %v2, ptr %v2, ptr %t129, %"compiler/source:Span" %t130, ptr %t132)
  store ptr %t136, ptr %l72
  br label %bb35
bb35:
  %t137 = load ptr, ptr %l72, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t137, ptr %rv
  br label %ret
bb36:
  %t139 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t141 = trunc i64 53 to i32
  %t142 = icmp eq i32 %t139, %t141
  br i1 %t142, label %bb37, label %bb38
bb37:
  store i1 true, ptr %l76, !tbaa !21
  br label %bb39
bb38:
  %t144 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t146 = trunc i64 88 to i32
  %t147 = icmp eq i32 %t144, %t146
  store i1 %t147, ptr %l76, !tbaa !21
  br label %bb39
bb39:
  %t149 = load i1, ptr %l76, !tbaa !21
  br i1 %t149, label %bb40, label %bb41
bb40:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/check:Checker", ptr %t150, i32 0, i32 40
  store i1 true, ptr %t152, !tbaa !21
  %t153 = load ptr, ptr %l0, !tbaa !29
  store ptr %t153, ptr %l80, !tbaa !29
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t155 = load ptr, ptr %l3, !tbaa !29
  %t157 = load i32, ptr %l4, !tbaa !23
  %t161 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v0, ptr %t154, ptr %t155, i32 %t157)
  store ptr %t161, ptr %l85
  br label %bb42
bb41:
  br label %bb56
bb42:
  %t162 = load ptr, ptr %l3, !tbaa !29
  %t164 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t162)
  store %"compiler/source:Span" %t164, ptr %l87
  br label %bb43
bb43:
  %t165 = load ptr, ptr %l80, !tbaa !29
  %t166 = load ptr, ptr %l85, !tbaa !29
  %t167 = load %"compiler/source:Span", ptr %l87
  %t168 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v0, ptr %v2, ptr %t165, ptr %t166, %"compiler/source:Span" %t167)
  store ptr %t168, ptr %l88
  br label %bb44
bb44:
  %t169 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store ptr %t169, ptr %lp6
  %t170 = load ptr, ptr %l88, !tbaa !29
  %t171 = load ptr, ptr %lp6
  store ptr %t170, ptr %t171, !tbaa !29
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t173 = load ptr, ptr %lp6
  %t174 = load ptr, ptr %t173, !tbaa !29
  %t177 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneOf(ptr %v0, ptr %v2, ptr %t172, ptr %t174)
  store i64 %t177, ptr %l91
  br label %bb45
bb45:
  %t178 = load i64, ptr %l91, !tbaa !24
  %t179 = icmp sge i64 %t178, 0
  br i1 %t179, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l93, !tbaa !21
  br label %bb50
bb47:
  %t181 = load ptr, ptr %l0, !tbaa !29
  store ptr %t181, ptr %l94, !tbaa !29
  %t182 = load ptr, ptr %lp6
  %t183 = load ptr, ptr %t182, !tbaa !29
  %t186 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t183)
  store i32 %t186, ptr %l97
  br label %bb48
bb48:
  %t187 = load ptr, ptr %l94, !tbaa !29
  %t188 = load i32, ptr %l97, !tbaa !23
  %t189 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArray(ptr %v0, ptr %t187, i32 %t188)
  store i1 %t189, ptr %l98
  br label %bb49
bb49:
  %t190 = load i1, ptr %l98, !tbaa !21
  store i1 %t190, ptr %l93, !tbaa !21
  br label %bb50
bb50:
  %t191 = load i1, ptr %l93, !tbaa !21
  br i1 %t191, label %bb51, label %bb52
bb51:
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t193 = load %"compiler/source:Span", ptr %l1
  %t194 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t195 = load ptr, ptr %lp6
  %t196 = load ptr, ptr %t195, !tbaa !29
  %t201 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneUnary(ptr %v0, ptr %v2, ptr %v2, ptr %t192, %"compiler/source:Span" %t193, i32 %t194, ptr %t196)
  store ptr %t201, ptr %l103
  br label %bb53
bb52:
  br label %bb54
bb53:
  %t202 = load ptr, ptr %l103, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t202, ptr %rv
  br label %ret
bb54:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t205 = load %"compiler/source:Span", ptr %l1
  %t206 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t207 = load ptr, ptr %lp6
  %t208 = load ptr, ptr %t207, !tbaa !29
  %t213 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunaryOn(ptr %v0, ptr %v2, ptr %v2, ptr %t204, %"compiler/source:Span" %t205, i32 %t206, ptr %t208)
  store ptr %t213, ptr %l109
  br label %bb55
bb55:
  %t214 = load ptr, ptr %l109, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t214, ptr %rv
  br label %ret
bb56:
  %t216 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t218 = trunc i64 89 to i32
  %t219 = icmp eq i32 %t216, %t218
  br i1 %t219, label %bb57, label %bb58
bb57:
  %t221 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPiece_26_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t221, ptr %l113
  br label %bb59
bb58:
  br label %bb66
bb59:
  %t222 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t222, ptr %lp7
  %t223 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l113
  %t224 = load ptr, ptr %lp7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t223, ptr %t224
  %t225 = load ptr, ptr %lp7
  store ptr %t225, ptr %l114, !tbaa !29
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t227 = load %"compiler/source:Span", ptr %l1
  %t228 = load ptr, ptr %l3, !tbaa !29
  %t232 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erenderPiece(ptr %v0, ptr %v1, ptr %v0, ptr %t226, %"compiler/source:Span" %t227, ptr %t228)
  store ptr %t232, ptr %l118
  br label %bb60
bb60:
  %t233 = load ptr, ptr %l114, !tbaa !29
  %t234 = load ptr, ptr %l118, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPiece_26_3e_2ePush_3ccompiler_2ftyped_3aPiece_26_3e(ptr %v2, ptr %v0, ptr %t233, ptr %t234)
  br label %bb61
bb61:
  %t235 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t235, ptr %l119
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t238 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t236)
  store i32 %t238, ptr %l121
  br label %bb62
bb62:
  %t239 = load ptr, ptr %lp7
  %t241 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPiece_26_3e_2eToArr_H1b89f7fcc263bba924ca04e7c3aa48c7(ptr %v2, ptr %v2, ptr %t239)
  store { i64, ptr } %t241, ptr %l123
  br label %bb63
bb63:
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t243 = load %"compiler/source:Span", ptr %l1
  %t247 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t242, i32 4, %"compiler/source:Span" %t243)
  store i32 %t247, ptr %l127
  br label %bb64
bb64:
  %t248 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t249 = load i32, ptr %l127, !tbaa !23
  %t250 = call %"compiler/typed:Text" @compiler_2ftyped_3aText_2ector(ptr %v2, ptr %v2, { i64, ptr } %t248, i32 %t249)
  store %"compiler/typed:Text" %t250, ptr %l128
  br label %bb65
bb65:
  %t251 = load %"compiler/typed:Text", ptr %l128
  %t252 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 24, i64 8)
  store %"compiler/typed:Text" %t251, ptr %t252
  store { i64, [5 x i64] } zeroinitializer, ptr %t253
  %t254 = getelementptr { i64, [5 x i64] }, ptr %t253, i32 0, i32 0
  store i64 16, ptr %t254
  %t255 = load %"compiler/source:Span", ptr %l119
  %t256 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t255, 0
  %t257 = load i32, ptr %l121, !tbaa !23
  %t258 = insertvalue { %"compiler/source:Span", i32, ptr } %t256, i32 %t257, 1
  %t260 = insertvalue { %"compiler/source:Span", i32, ptr } %t258, ptr %t252, 2
  %t261 = getelementptr { i64, [5 x i64] }, ptr %t253, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t260, ptr %t261
  %t262 = load { i64, [5 x i64] }, ptr %t253
  %t264 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t262, ptr %t264
  call void @__olang_scope_close(ptr %s0)
  store ptr %t264, ptr %rv
  br label %ret
bb66:
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t267 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s0, ptr %t266, %"compiler/source:Span" %t267, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d36, i32 0, i32 1) })
  br label %bb67
bb67:
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t271 = load %"compiler/source:Span", ptr %l1
  %t274 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t270, %"compiler/source:Span" %t271)
  store ptr %t274, ptr %l136
  br label %bb68
bb68:
  %t275 = load ptr, ptr %l136, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t275, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunaryOn(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l10 = alloca i32
  %l15 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca i1
  %l20 = alloca i1
  %l23 = alloca i1
  %l24 = alloca i1
  %l28 = alloca i1
  %l32 = alloca { i64, ptr }
  %l33 = alloca ptr
  %l36 = alloca i32
  %l37 = alloca { i64, ptr }
  %l38 = alloca %"compiler/source:Span"
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l43 = alloca i64
  %l46 = alloca ptr
  %l47 = alloca ptr
  %l51 = alloca ptr
  %l54 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l56 = alloca %"compiler/source:Span"
  %l57 = alloca %"compiler/source:Span"
  %l58 = alloca i64
  %l60 = alloca ptr
  %l63 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l70 = alloca ptr
  %l71 = alloca ptr
  %l74 = alloca i32
  %l75 = alloca { i64, ptr }
  %l76 = alloca %"compiler/source:Span"
  %l78 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l81 = alloca i1
  %l84 = alloca ptr
  %l87 = alloca i1
  %l88 = alloca ptr
  %l89 = alloca %"compiler/source:Span"
  %l92 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l101 = alloca %"compiler/msgs:Msg"
  %l102 = alloca i64
  %l105 = alloca ptr
  %l110 = alloca i1
  %l112 = alloca ptr
  %l113 = alloca %"compiler/source:Span"
  %l114 = alloca i32
  %l117 = alloca { i64, ptr }
  %l119 = alloca %"compiler/msgs:Msg"
  %l120 = alloca i64
  %l123 = alloca ptr
  %l126 = alloca i64
  %l130 = alloca %"compiler/source:Span"
  %l131 = alloca i32
  %l132 = alloca i32
  %l133 = alloca i32
  %l137 = alloca { i64, ptr }
  %l142 = alloca i1
  %l144 = alloca ptr
  %l145 = alloca %"compiler/source:Span"
  %l148 = alloca { i64, ptr }
  %l150 = alloca %"compiler/msgs:Msg"
  %l151 = alloca i64
  %l154 = alloca ptr
  %l160 = alloca ptr
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca ptr
  %t302 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t1)
  store i32 %t4, ptr %l10
  br label %bb1
bb1:
  %t5 = load i32, ptr %l10, !tbaa !23
  store i32 %t5, ptr %l4, !tbaa !23
  %t6 = load i32, ptr %l4, !tbaa !23
  %t7 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t10 = icmp eq i32 %t6, %t7
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %l3, !tbaa !29
  store ptr %t12, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l15, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l4, !tbaa !23
  %t19 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t15, i32 %t16)
  store i32 %t19, ptr %l18
  br label %bb5
bb5:
  %t20 = load ptr, ptr %l15, !tbaa !29
  %t21 = load i32, ptr %l18, !tbaa !23
  %t22 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t20, i32 %t21)
  store i1 %t22, ptr %l19
  br label %bb6
bb6:
  %t23 = load i1, ptr %l19, !tbaa !21
  br i1 %t23, label %bb7, label %bb8
bb7:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load i32, ptr %l4, !tbaa !23
  %t28 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t24, i32 %t25)
  store i1 %t28, ptr %l23
  br label %bb9
bb8:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb14
bb9:
  %t29 = load i1, ptr %l23, !tbaa !21
  br i1 %t29, label %bb10, label %bb11
bb10:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/check:Checker", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t34 = load i32, ptr %l4, !tbaa !23
  %t37 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %t33, i32 %t34)
  store i1 %t37, ptr %l28
  br label %bb12
bb11:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb13
bb12:
  %t38 = load i1, ptr %l28, !tbaa !21
  store i1 %t38, ptr %l24, !tbaa !21
  br label %bb13
bb13:
  %t39 = load i1, ptr %l24, !tbaa !21
  %t40 = xor i1 %t39, true
  store i1 %t40, ptr %l20, !tbaa !21
  br label %bb14
bb14:
  %t42 = load i1, ptr %l20, !tbaa !21
  br i1 %t42, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  %t43 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t45 = trunc i64 53 to i32
  %t46 = icmp eq i32 %t43, %t45
  br i1 %t46, label %bb17, label %bb18
bb16:
  br label %bb60
bb17:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d37, i32 0, i32 1) }, ptr %l32, !tbaa !27
  br label %bb19
bb18:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d38, i32 0, i32 1) }, ptr %l32, !tbaa !27
  br label %bb19
bb19:
  %t48 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t48, ptr %l5, !tbaa !27
  %t49 = load ptr, ptr %l0, !tbaa !29
  store ptr %t49, ptr %l33, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load i32, ptr %l4, !tbaa !23
  %t54 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t50, i32 %t51)
  store i32 %t54, ptr %l36
  br label %bb20
bb20:
  %t55 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t55, ptr %l37, !tbaa !27
  %t56 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t56, ptr %l38
  %t57 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t59 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s2, i32 %t57)
  store { i64, ptr } %t59, ptr %l40
  br label %bb21
bb21:
  %t60 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t61 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s2, ptr %s2, { i64, ptr } %t60)
  store { i64, ptr } %t61, ptr %l41
  br label %bb22
bb22:
  %t62 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t62, 0
  %t64 = extractvalue { i64, ptr } %t62, 1
  %t65 = mul i64 %t63, 1
  %t66 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t65)
  call void @llvm.memcpy.p0.p0.i64(ptr %t66, ptr %t64, i64 %t65, i1 false)
  %t67 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t66, 1
  %t69 = load ptr, ptr @__olang_prog_scope
  %t70 = load ptr, ptr %l33, !tbaa !29
  %t71 = load i32, ptr %l36, !tbaa !23
  %t72 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t73 = load %"compiler/source:Span", ptr %l38
  %t75 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleUse(ptr %v0, ptr %t69, ptr %s2, ptr %t70, i32 %t71, { i64, ptr } %t72, i64 0, %"compiler/source:Span" %t73, { i64, ptr } %t68)
  store i64 %t75, ptr %l43
  br label %bb23
bb23:
  %t76 = load i64, ptr %l43, !tbaa !24
  store i64 %t76, ptr %l6, !tbaa !24
  %t77 = load i64, ptr %l6, !tbaa !24
  %t79 = icmp sge i64 %t77, 0
  br i1 %t79, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s3
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l46, !tbaa !29
  %t82 = load ptr, ptr %l0, !tbaa !29
  store ptr %t82, ptr %l47, !tbaa !29
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/check:Checker", ptr %t83, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t87 = load i64, ptr %l6, !tbaa !24
  %t90 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s3, ptr %t86, i64 %t87)
  store ptr %t90, ptr %l51
  br label %bb26
bb25:
  br label %bb41
bb26:
  %t91 = load ptr, ptr %l51, !tbaa !29
  %t93 = getelementptr %"compiler/ast:Func", ptr %t91, i32 0, i32 2
  %t94 = load i32, ptr %t93, !tbaa !23
  %t95 = load ptr, ptr %l47, !tbaa !29
  %t97 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t95, i32 %t94)
  store { i64, ptr } %t97, ptr %l54
  br label %bb27
bb27:
  %t98 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t99 = load ptr, ptr %l46, !tbaa !29
  %t100 = getelementptr %"compiler/check:Checker", ptr %t99, i32 0, i32 49
  store { i64, ptr } %t98, ptr %t100, !tbaa !27
  %t101 = load ptr, ptr %l0, !tbaa !29
  store ptr %t101, ptr %l55, !tbaa !29
  %t102 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t102, ptr %l56
  %t103 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t103, ptr %l57
  %t104 = load i64, ptr %l6, !tbaa !24
  store i64 %t104, ptr %l58, !tbaa !24
  %t105 = load ptr, ptr %l3, !tbaa !29
  store ptr %t105, ptr %l60, !tbaa !29
  %t107 = icmp sge i64 0, 0
  br i1 %t107, label %bb28, label %bb29
bb28:
  %t109 = icmp sle i64 0, 1152921504606846975
  br i1 %t109, label %bb30, label %bb31
bb29:
  call void @__olang_check_failed(ptr @olang_loc_e153c6abdfe6ecb0_f26e63b1d3597a0c)
  unreachable
bb30:
  %t111 = mul i64 0, 8
  %t112 = insertvalue { i64, ptr } undef, i64 0, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t113, ptr %l63, !tbaa !27
  %t114 = icmp sge i64 0, 0
  br i1 %t114, label %bb32, label %bb33
bb31:
  call void @__olang_check_failed(ptr @olang_loc_e153c6abdfe6ecb0_f26e63b1d3597a0c)
  unreachable
bb32:
  %t116 = icmp sle i64 0, 1152921504606846975
  br i1 %t116, label %bb34, label %bb35
bb33:
  call void @__olang_check_failed(ptr @olang_loc_e153c6abdfe6ecb0_f26e63b1d3597a0c)
  unreachable
bb34:
  %t118 = mul i64 0, 8
  %t119 = insertvalue { i64, ptr } undef, i64 0, 0
  %t120 = insertvalue { i64, ptr } %t119, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t120, ptr %l66, !tbaa !27
  %t121 = icmp sge i64 0, 0
  br i1 %t121, label %bb36, label %bb37
bb35:
  call void @__olang_check_failed(ptr @olang_loc_e153c6abdfe6ecb0_f26e63b1d3597a0c)
  unreachable
bb36:
  %t123 = icmp sle i64 0, 2305843009213693951
  br i1 %t123, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_19db3dca8a9dc05d_2b95ab49e23e3919)
  unreachable
bb38:
  %t125 = mul i64 0, 4
  %t126 = insertvalue { i64, ptr } undef, i64 0, 0
  %t127 = insertvalue { i64, ptr } %t126, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t128 = load ptr, ptr %l55, !tbaa !29
  %t129 = load %"compiler/source:Span", ptr %l56
  %t130 = load %"compiler/source:Span", ptr %l57
  %t131 = load i64, ptr %l58, !tbaa !24
  %t132 = load ptr, ptr %l60, !tbaa !29
  %t133 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t134 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t136 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v1, ptr %v0, ptr %v0, ptr %v2, ptr %v2, ptr %t128, %"compiler/source:Span" %t129, %"compiler/source:Span" %t130, i64 %t131, ptr %t132, { i64, ptr } %t133, { i64, ptr } %t134, { i64, ptr } %t127)
  store ptr %t136, ptr %l70
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_19db3dca8a9dc05d_2b95ab49e23e3919)
  unreachable
bb40:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  %t137 = load ptr, ptr %l70, !tbaa !29
  store ptr %t137, ptr %rv
  br label %ret
bb41:
  %t138 = load ptr, ptr %l0, !tbaa !29
  store ptr %t138, ptr %l71, !tbaa !29
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load i32, ptr %l4, !tbaa !23
  %t143 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t139, i32 %t140)
  store i32 %t143, ptr %l74
  br label %bb42
bb42:
  %t144 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t144, ptr %l75, !tbaa !27
  %t145 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t145, ptr %l76
  %t146 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t148 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s2, i32 %t146)
  store { i64, ptr } %t148, ptr %l78
  br label %bb43
bb43:
  %t149 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t150 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s2, ptr %s2, { i64, ptr } %t149)
  store { i64, ptr } %t150, ptr %l79
  br label %bb44
bb44:
  %t151 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t152 = extractvalue { i64, ptr } %t151, 0
  %t153 = extractvalue { i64, ptr } %t151, 1
  %t154 = mul i64 %t152, 1
  %t155 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t154)
  call void @llvm.memcpy.p0.p0.i64(ptr %t155, ptr %t153, i64 %t154, i1 false)
  %t156 = insertvalue { i64, ptr } undef, i64 %t152, 0
  %t157 = insertvalue { i64, ptr } %t156, ptr %t155, 1
  %t158 = load ptr, ptr @__olang_prog_scope
  %t159 = load ptr, ptr %l71, !tbaa !29
  %t160 = load i32, ptr %l74, !tbaa !23
  %t161 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t162 = load %"compiler/source:Span", ptr %l76
  %t164 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %t158, ptr %s2, ptr %t159, i32 %t160, { i64, ptr } %t161, %"compiler/source:Span" %t162, { i64, ptr } %t157, i64 0, i1 false)
  store i1 %t164, ptr %l81
  br label %bb45
bb45:
  %t165 = load i1, ptr %l81, !tbaa !21
  br i1 %t165, label %bb46, label %bb47
bb46:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load %"compiler/source:Span", ptr %l1
  %t170 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t166, %"compiler/source:Span" %t167)
  store ptr %t170, ptr %l84
  br label %bb48
bb47:
  br label %bb49
bb48:
  call void @__olang_scope_close(ptr %s2)
  %t171 = load ptr, ptr %l84, !tbaa !29
  store ptr %t171, ptr %rv
  br label %ret
bb49:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t173 = load i32, ptr %l4, !tbaa !23
  %t176 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t172, i32 %t173)
  store i1 %t176, ptr %l87
  br label %bb50
bb50:
  %t177 = load i1, ptr %l87, !tbaa !21
  br i1 %t177, label %bb51, label %bb52
bb51:
  store %olang.scope zeroinitializer, ptr %s5
  %t178 = load ptr, ptr %l0, !tbaa !29
  store ptr %t178, ptr %l88, !tbaa !29
  %t179 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t179, ptr %l89
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t181 = load i32, ptr %l4, !tbaa !23
  %t184 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s5, ptr %t180, i32 %t181)
  store { i64, ptr } %t184, ptr %l92
  br label %bb53
bb52:
  br label %bb59
bb53:
  %t185 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t186 = extractvalue { i64, ptr } %t185, 0
  %t187 = extractvalue { i64, ptr } %t185, 1
  %t188 = mul i64 %t186, 1
  %t189 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t188)
  call void @llvm.memcpy.p0.p0.i64(ptr %t189, ptr %t187, i64 %t188, i1 false)
  %t190 = insertvalue { i64, ptr } undef, i64 %t186, 0
  %t191 = insertvalue { i64, ptr } %t190, ptr %t189, 1
  store { i64, ptr } %t191, ptr %l93, !tbaa !27
  %t192 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t194 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s5, i32 %t192)
  store { i64, ptr } %t194, ptr %l95
  br label %bb54
bb54:
  %t195 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t196 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s5, ptr %s5, { i64, ptr } %t195)
  store { i64, ptr } %t196, ptr %l96
  br label %bb55
bb55:
  %t197 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t198 = extractvalue { i64, ptr } %t197, 0
  %t199 = extractvalue { i64, ptr } %t197, 1
  %t200 = mul i64 %t198, 1
  %t201 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t200)
  call void @llvm.memcpy.p0.p0.i64(ptr %t201, ptr %t199, i64 %t200, i1 false)
  %t202 = insertvalue { i64, ptr } undef, i64 %t198, 0
  %t203 = insertvalue { i64, ptr } %t202, ptr %t201, 1
  %t204 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t205 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d39, i32 0, i32 1) }, 1
  %t206 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d39, i32 0, i32 1) }, 0
  %t208 = extractvalue { i64, ptr } %t204, 1
  %t209 = extractvalue { i64, ptr } %t204, 0
  %t210 = add i64 %t206, %t209
  %t211 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d39, i32 0, i32 1) }, 1
  %t212 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d39, i32 0, i32 1) }, 0
  %t213 = add i64 %t210, %t212
  %t214 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t213)
  call void @olang_textcopy(ptr %t214, ptr %t205, i64 %t206)
  %t215 = getelementptr i8, ptr %t214, i64 %t206
  call void @olang_textcopy(ptr %t215, ptr %t208, i64 %t209)
  %t216 = getelementptr i8, ptr %t215, i64 %t209
  call void @olang_textcopy(ptr %t216, ptr %t211, i64 %t212)
  %t217 = insertvalue { i64, ptr } undef, i64 %t213, 0
  %t218 = insertvalue { i64, ptr } %t217, ptr %t214, 1
  %t220 = extractvalue { i64, ptr } %t218, 0
  %t221 = extractvalue { i64, ptr } %t218, 1
  %t222 = mul i64 %t220, 1
  %t223 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t222)
  call void @llvm.memcpy.p0.p0.i64(ptr %t223, ptr %t221, i64 %t222, i1 false)
  %t224 = insertvalue { i64, ptr } undef, i64 %t220, 0
  %t225 = insertvalue { i64, ptr } %t224, ptr %t223, 1
  %t226 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t229 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotExtendedOp(ptr %s5, ptr %s5, ptr %s5, ptr %s5, { i64, ptr } %t226, { i64, ptr } %t203, { i64, ptr } %t225)
  store %"compiler/msgs:Msg" %t229, ptr %l101
  br label %bb56
bb56:
  %t230 = load ptr, ptr %l88, !tbaa !29
  %t231 = load %"compiler/source:Span", ptr %l89
  %t232 = load %"compiler/msgs:Msg", ptr %l101
  %t233 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t230, %"compiler/source:Span" %t231, %"compiler/msgs:Msg" %t232)
  store i64 %t233, ptr %l102
  br label %bb57
bb57:
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = load %"compiler/source:Span", ptr %l1
  %t238 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t234, %"compiler/source:Span" %t235)
  store ptr %t238, ptr %l105
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s2)
  %t239 = load ptr, ptr %l105, !tbaa !29
  store ptr %t239, ptr %rv
  br label %ret
bb59:
  call void @__olang_scope_close(ptr %s2)
  br label %bb60
bb60:
  %t240 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t242 = trunc i64 53 to i32
  %t243 = icmp eq i32 %t240, %t242
  br i1 %t243, label %bb61, label %bb62
bb61:
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t246 = load i32, ptr %l4, !tbaa !23
  %t249 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t245, i32 %t246)
  store i1 %t249, ptr %l110
  br label %bb63
bb62:
  br label %bb74
bb63:
  %t250 = load i1, ptr %l110, !tbaa !21
  %t251 = xor i1 %t250, true
  br i1 %t251, label %bb64, label %bb65
bb64:
  store %olang.scope zeroinitializer, ptr %s8
  %t253 = load ptr, ptr %l0, !tbaa !29
  store ptr %t253, ptr %l112, !tbaa !29
  %t254 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t254, ptr %l113
  %t255 = load i32, ptr %l4, !tbaa !23
  store i32 %t255, ptr %l114, !tbaa !23
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t257 = load i32, ptr %l4, !tbaa !23
  %t260 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s8, ptr %t256, i32 %t257)
  store { i64, ptr } %t260, ptr %l117
  br label %bb66
bb65:
  br label %bb70
bb66:
  %t261 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t262 = extractvalue { i64, ptr } %t261, 0
  %t263 = extractvalue { i64, ptr } %t261, 1
  %t264 = mul i64 %t262, 1
  %t265 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t264)
  call void @llvm.memcpy.p0.p0.i64(ptr %t265, ptr %t263, i64 %t264, i1 false)
  %t266 = insertvalue { i64, ptr } undef, i64 %t262, 0
  %t267 = insertvalue { i64, ptr } %t266, ptr %t265, 1
  %t269 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eOperandNotNumber(ptr %s8, ptr %s8, ptr %s8, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d40, i32 0, i32 1) }, { i64, ptr } %t267)
  store %"compiler/msgs:Msg" %t269, ptr %l119
  br label %bb67
bb67:
  %t270 = load ptr, ptr %l112, !tbaa !29
  %t271 = load %"compiler/source:Span", ptr %l113
  %t272 = load i32, ptr %l114, !tbaa !23
  %t273 = load %"compiler/msgs:Msg", ptr %l119
  %t274 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneedErr(ptr %v0, ptr %s8, ptr %s8, ptr %t270, %"compiler/source:Span" %t271, i32 %t272, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d41, i32 0, i32 1) }, %"compiler/msgs:Msg" %t273)
  store i64 %t274, ptr %l120
  br label %bb68
bb68:
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t276 = load %"compiler/source:Span", ptr %l1
  %t279 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t275, %"compiler/source:Span" %t276)
  store ptr %t279, ptr %l123
  br label %bb69
bb69:
  call void @__olang_scope_close(ptr %s8)
  %t280 = load ptr, ptr %l123, !tbaa !29
  store ptr %t280, ptr %rv
  br label %ret
bb70:
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t283 = getelementptr %"compiler/check:Checker", ptr %t281, i32 0, i32 36
  %t285 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t283)
  store i64 %t285, ptr %l126
  br label %bb71
bb71:
  %t286 = load i64, ptr %l126, !tbaa !24
  store i64 %t286, ptr %l7, !tbaa !24
  %t287 = load ptr, ptr %l0, !tbaa !29
  %t289 = getelementptr %"compiler/check:Checker", ptr %t287, i32 0, i32 36
  %t290 = load ptr, ptr %l3, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %t289, ptr %t290)
  br label %bb72
bb72:
  %t293 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t293, ptr %l130
  %t294 = load i32, ptr %l4, !tbaa !23
  store i32 %t294, ptr %l131, !tbaa !23
  store i32 0, ptr %l132
  store i32 0, ptr %l133
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t297 = getelementptr %"compiler/check:Checker", ptr %t295, i32 0, i32 36
  %t298 = load i64, ptr %l7, !tbaa !24
  %t301 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v2, ptr %t297, i64 %t298)
  store { i64, ptr } %t301, ptr %l137
  br label %bb73
bb73:
  store { i64, [5 x i64] } zeroinitializer, ptr %t302
  %t303 = getelementptr { i64, [5 x i64] }, ptr %t302, i32 0, i32 0
  store i64 9, ptr %t303
  %t304 = load %"compiler/source:Span", ptr %l130
  %t305 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } undef, %"compiler/source:Span" %t304, 0
  %t306 = load i32, ptr %l131, !tbaa !23
  %t307 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t305, i32 %t306, 1
  %t308 = load i32, ptr %l132, !range !{i32 0, i32 43}
  %t309 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t307, i32 %t308, 2
  %t310 = load i32, ptr %l133, !range !{i32 0, i32 3}
  %t311 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t309, i32 %t310, 3
  %t312 = load { i64, ptr }, ptr %l137, !tbaa !27
  %t313 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t311, { i64, ptr } %t312, 4
  %t314 = getelementptr { i64, [5 x i64] }, ptr %t302, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t313, ptr %t314
  %t315 = load { i64, [5 x i64] }, ptr %t302
  %t317 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t315, ptr %t317
  store ptr %t317, ptr %rv
  br label %ret
bb74:
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t320 = load i32, ptr %l4, !tbaa !23
  %t323 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisInt(ptr %v0, ptr %t319, i32 %t320)
  store i1 %t323, ptr %l142
  br label %bb75
bb75:
  %t324 = load i1, ptr %l142, !tbaa !21
  %t325 = xor i1 %t324, true
  br i1 %t325, label %bb76, label %bb77
bb76:
  store %olang.scope zeroinitializer, ptr %s9
  %t327 = load ptr, ptr %l0, !tbaa !29
  store ptr %t327, ptr %l144, !tbaa !29
  %t328 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t328, ptr %l145
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t330 = load i32, ptr %l4, !tbaa !23
  %t333 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s9, ptr %t329, i32 %t330)
  store { i64, ptr } %t333, ptr %l148
  br label %bb78
bb77:
  br label %bb82
bb78:
  %t334 = load { i64, ptr }, ptr %l148, !tbaa !27
  %t335 = extractvalue { i64, ptr } %t334, 0
  %t336 = extractvalue { i64, ptr } %t334, 1
  %t337 = mul i64 %t335, 1
  %t338 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t337)
  call void @llvm.memcpy.p0.p0.i64(ptr %t338, ptr %t336, i64 %t337, i1 false)
  %t339 = insertvalue { i64, ptr } undef, i64 %t335, 0
  %t340 = insertvalue { i64, ptr } %t339, ptr %t338, 1
  %t342 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eOperandNotInt(ptr %s9, ptr %s9, ptr %s9, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d42, i32 0, i32 1) }, { i64, ptr } %t340)
  store %"compiler/msgs:Msg" %t342, ptr %l150
  br label %bb79
bb79:
  %t343 = load ptr, ptr %l144, !tbaa !29
  %t344 = load %"compiler/source:Span", ptr %l145
  %t345 = load %"compiler/msgs:Msg", ptr %l150
  %t346 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s9, ptr %t343, %"compiler/source:Span" %t344, %"compiler/msgs:Msg" %t345)
  store i64 %t346, ptr %l151
  br label %bb80
bb80:
  %t347 = load ptr, ptr %l0, !tbaa !29
  %t348 = load %"compiler/source:Span", ptr %l1
  %t351 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t347, %"compiler/source:Span" %t348)
  store ptr %t351, ptr %l154
  br label %bb81
bb81:
  call void @__olang_scope_close(ptr %s9)
  %t352 = load ptr, ptr %l154, !tbaa !29
  store ptr %t352, ptr %rv
  br label %ret
bb82:
  %t353 = load ptr, ptr %l0, !tbaa !29
  %t354 = load %"compiler/source:Span", ptr %l1
  %t355 = load i32, ptr %l4, !tbaa !23
  %t356 = load ptr, ptr %l3, !tbaa !29
  %t362 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v1, ptr %v0, ptr %v2, ptr %t353, %"compiler/source:Span" %t354, i32 %t355, i32 1, ptr %t356, ptr null)
  store ptr %t362, ptr %l160
  br label %bb83
bb83:
  %t363 = load ptr, ptr %l160, !tbaa !29
  store ptr %t363, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrollConsts(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, { i64, ptr } %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca { i64, i64, i64 }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca { i64, i64, i64 }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i32
  %l22 = alloca i32
  %l23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca { i64, i64, i64 }
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l33 = alloca i64
  %l37 = alloca { i64, i64, i64 }
  %l42 = alloca ptr
  %l47 = alloca ptr
  %l58 = alloca i64
  %l61 = alloca i64
  %l81 = alloca i64
  %l85 = alloca { i64, i64, i64 }
  %l90 = alloca ptr
  %l95 = alloca ptr
  %l101 = alloca ptr
  %l103 = alloca i32
  %l108 = alloca { i64, ptr }
  %l111 = alloca i32
  %l112 = alloca i32
  %l113 = alloca ptr
  %l115 = alloca i32
  %l118 = alloca ptr
  %l120 = alloca i32
  %l122 = alloca i32
  %l123 = alloca i32
  %l147 = alloca i64
  %l149 = alloca ptr
  %l152 = alloca i64
  %l153 = alloca i32
  %l159 = alloca ptr
  %l162 = alloca i64
  %l166 = alloca { i64, i64, i64 }
  %l183 = alloca ptr
  %l201 = alloca i64
  %l203 = alloca ptr
  %l206 = alloca i64
  %l207 = alloca i32
  %l213 = alloca ptr
  %t229 = alloca { i64, [3 x i64] }, align 8
  %t296 = alloca { i64, [3 x i64] }, align 8
  %t327 = alloca { i64, [3 x i64] }, align 8
  %t351 = alloca { i64, [3 x i64] }, align 8
  %t393 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 37
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l33
  br label %bb1
bb1:
  %t6 = load i64, ptr %l33, !tbaa !24
  store i64 %t6, ptr %l5, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load %"compiler/source:Span", ptr %l1
  %t12 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t7, i32 2, %"compiler/source:Span" %t8)
  store { i64, i64, i64 } %t12, ptr %l37
  br label %bb2
bb2:
  %t13 = load { i64, i64, i64 }, ptr %l37
  store { i64, i64, i64 } %t13, ptr %l6
  %t14 = getelementptr { i64, i64, i64 }, ptr %l6, i32 0, i32 0
  %t15 = load i64, ptr %t14, !tbaa !24
  store i64 %t15, ptr %l7, !tbaa !24
  %t17 = getelementptr { i64, i64, i64 }, ptr %l6, i32 0, i32 1
  %t18 = load i64, ptr %t17, !tbaa !24
  store i64 %t18, ptr %l8, !tbaa !24
  %t20 = getelementptr { i64, i64, i64 }, ptr %l6, i32 0, i32 2
  %t21 = load i64, ptr %t20, !tbaa !24
  store i64 %t21, ptr %l9, !tbaa !24
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t23)
  store ptr %t25, ptr %l42
  br label %bb3
bb3:
  %t26 = load ptr, ptr %l42, !tbaa !29
  %t28 = getelementptr %"compiler/check:frame", ptr %t26, i32 0, i32 11
  %t29 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t28, i64 %t29)
  br label %bb4
bb4:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t32)
  store ptr %t34, ptr %l47
  br label %bb5
bb5:
  %t35 = load ptr, ptr %l47, !tbaa !29
  %t37 = getelementptr %"compiler/typed:Body", ptr %t35, i32 0, i32 19
  %t38 = load i64, ptr %l7, !tbaa !24
  %t40 = trunc i64 %t38 to i32
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePush_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t37, i32 %t40)
  br label %bb6
bb6:
  store i64 0, ptr %l10, !tbaa !24
  %t44 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 0
  store i64 %t46, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t48 = load i64, ptr %l11, !tbaa !24
  %t49 = load i64, ptr %l10, !tbaa !24
  %t52 = icmp sgt i64 %t48, %t49
  br i1 %t52, label %bb7, label %bb8
bb7:
  %t54 = load i64, ptr %l12, !tbaa !24
  %t56 = icmp sgt i64 %t54, 0
  br i1 %t56, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l58, !tbaa !24
  br label %bb12
bb9:
  %t58 = load i64, ptr %l11, !tbaa !24
  %t59 = load i64, ptr %l10, !tbaa !24
  %t62 = sub i64 %t58, %t59
  %t63 = load i64, ptr %l12, !tbaa !24
  %t66 = add i64 %t62, %t63
  %t68 = sub i64 %t66, 1
  %t69 = load i64, ptr %l12, !tbaa !24
  %t72 = sdiv i64 %t68, %t69
  store i64 %t72, ptr %l61, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb11
bb11:
  %t74 = load i64, ptr %l61, !tbaa !24
  store i64 %t74, ptr %l58, !tbaa !24
  br label %bb12
bb12:
  %t75 = load i64, ptr %l58, !tbaa !24
  store i64 %t75, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb13
bb13:
  %t76 = load i64, ptr %l14, !tbaa !24
  %t77 = load i64, ptr %l13, !tbaa !24
  %t80 = icmp slt i64 %t76, %t77
  %t82 = xor i1 %t80, true
  br i1 %t82, label %bb14, label %bb15
bb14:
  br label %bb47
bb15:
  br label %bb16
bb16:
  %t84 = load i64, ptr %l10, !tbaa !24
  %t85 = load i64, ptr %l14, !tbaa !24
  %t86 = load i64, ptr %l12, !tbaa !24
  %t89 = mul i64 %t85, %t86
  %t92 = add i64 %t84, %t89
  store i64 %t92, ptr %l15, !tbaa !24
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/check:Checker", ptr %t94, i32 0, i32 37
  %t98 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t96)
  store i64 %t98, ptr %l81
  br label %bb17
bb17:
  %t99 = load i64, ptr %l81, !tbaa !24
  store i64 %t99, ptr %l16, !tbaa !24
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load %"compiler/source:Span", ptr %l1
  %t105 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t100, i32 2, %"compiler/source:Span" %t101)
  store { i64, i64, i64 } %t105, ptr %l85
  br label %bb18
bb18:
  %t106 = load { i64, i64, i64 }, ptr %l85
  store { i64, i64, i64 } %t106, ptr %l17
  %t107 = getelementptr { i64, i64, i64 }, ptr %l17, i32 0, i32 0
  %t108 = load i64, ptr %t107, !tbaa !24
  store i64 %t108, ptr %l18, !tbaa !24
  %t110 = getelementptr { i64, i64, i64 }, ptr %l17, i32 0, i32 1
  %t111 = load i64, ptr %t110, !tbaa !24
  store i64 %t111, ptr %l19, !tbaa !24
  %t113 = getelementptr { i64, i64, i64 }, ptr %l17, i32 0, i32 2
  %t114 = load i64, ptr %t113, !tbaa !24
  store i64 %t114, ptr %l20, !tbaa !24
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t116)
  store ptr %t118, ptr %l90
  br label %bb19
bb19:
  %t119 = load ptr, ptr %l90, !tbaa !29
  %t121 = getelementptr %"compiler/check:frame", ptr %t119, i32 0, i32 10
  %t122 = load i64, ptr %l18, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t121, i64 %t122)
  br label %bb20
bb20:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t125)
  store ptr %t127, ptr %l95
  br label %bb21
bb21:
  %t128 = load ptr, ptr %l95, !tbaa !29
  %t130 = getelementptr %"compiler/typed:Body", ptr %t128, i32 0, i32 19
  %t131 = load i64, ptr %l18, !tbaa !24
  %t133 = trunc i64 %t131 to i32
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePush_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t130, i32 %t133)
  br label %bb22
bb22:
  %t137 = load ptr, ptr %l0, !tbaa !29
  store ptr %t137, ptr %l101, !tbaa !29
  %t138 = load ptr, ptr %l2, !tbaa !29
  %t140 = getelementptr %"compiler/ast:ForIn", ptr %t138, i32 0, i32 1
  %t141 = load i32, ptr %t140, !tbaa !23
  store i32 %t141, ptr %l103, !tbaa !23
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = getelementptr %"compiler/check:Checker", ptr %t142, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !29
  %t147 = getelementptr %"compiler/generic:Program", ptr %t145, i32 0, i32 2
  %t149 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t149, ptr %l108, !tbaa !27
  %t150 = load i64, ptr %l15, !tbaa !24
  %t152 = getelementptr { i64, ptr }, ptr %l108, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = getelementptr i64, ptr %t153, i64 %t150
  %t155 = load i64, ptr %t154, !tbaa !34
  %t159 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %t147, i32 %a4, i64 %t155)
  store i32 %t159, ptr %l111
  br label %bb23
bb23:
  %t160 = load ptr, ptr %l101, !tbaa !29
  %t161 = load i32, ptr %l103, !tbaa !23
  %t162 = load i32, ptr %l111, !tbaa !23
  %t163 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrollBind(ptr %v0, ptr %t160, i32 %t161, i32 %t162)
  store i32 %t163, ptr %l112
  br label %bb24
bb24:
  %t164 = load i32, ptr %l112, !tbaa !23
  store i32 %t164, ptr %l21, !tbaa !23
  %t165 = load ptr, ptr %l0, !tbaa !29
  store ptr %t165, ptr %l113, !tbaa !29
  %t166 = load ptr, ptr %l2, !tbaa !29
  %t168 = getelementptr %"compiler/ast:ForIn", ptr %t166, i32 0, i32 0
  %t169 = load i32, ptr %t168, !tbaa !23
  store i32 %t169, ptr %l115, !tbaa !23
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/check:Checker", ptr %t170, i32 0, i32 1
  %t173 = load ptr, ptr %t172, !tbaa !29
  %t175 = getelementptr %"compiler/generic:Program", ptr %t173, i32 0, i32 2
  store ptr %t175, ptr %l118, !tbaa !29
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t176)
  store i32 %t178, ptr %l120
  br label %bb25
bb25:
  %t179 = load i64, ptr %l15, !tbaa !24
  %t180 = load ptr, ptr %l118, !tbaa !29
  %t181 = load i32, ptr %l120, !tbaa !23
  %t183 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %t180, i32 %t181, i64 %t179)
  store i32 %t183, ptr %l122
  br label %bb26
bb26:
  %t184 = load ptr, ptr %l113, !tbaa !29
  %t185 = load i32, ptr %l115, !tbaa !23
  %t186 = load i32, ptr %l122, !tbaa !23
  %t187 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrollBind(ptr %v0, ptr %t184, i32 %t185, i32 %t186)
  store i32 %t187, ptr %l123
  br label %bb27
bb27:
  %t188 = load i32, ptr %l123, !tbaa !23
  store i32 %t188, ptr %l22, !tbaa !23
  %t189 = load ptr, ptr %l2, !tbaa !29
  %t191 = getelementptr %"compiler/ast:ForIn", ptr %t189, i32 0, i32 4
  %t192 = load { i64, ptr }, ptr %t191, !tbaa !27
  %t194 = extractvalue { i64, ptr } %t192, 0
  %t196 = icmp sgt i64 %t194, 0
  br i1 %t196, label %bb28, label %bb29
bb28:
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t199 = load ptr, ptr %l2, !tbaa !29
  %t201 = getelementptr %"compiler/ast:ForIn", ptr %t199, i32 0, i32 4
  %t202 = load { i64, ptr }, ptr %t201, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmtsOf(ptr %v0, ptr %v1, ptr %t198, { i64, ptr } %t202)
  br label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb31
bb31:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t206 = load ptr, ptr %l2, !tbaa !29
  %t208 = getelementptr %"compiler/ast:ForIn", ptr %t206, i32 0, i32 0
  %t209 = load i32, ptr %t208, !tbaa !23
  %t210 = load i32, ptr %l22, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrollUnbind(ptr %v0, ptr %t205, i32 %t209, i32 %t210)
  br label %bb32
bb32:
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t215 = load ptr, ptr %l2, !tbaa !29
  %t217 = getelementptr %"compiler/ast:ForIn", ptr %t215, i32 0, i32 1
  %t218 = load i32, ptr %t217, !tbaa !23
  %t219 = load i32, ptr %l21, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrollUnbind(ptr %v0, ptr %t214, i32 %t218, i32 %t219)
  br label %bb33
bb33:
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t224 = load %"compiler/source:Span", ptr %l1
  %t225 = load i64, ptr %l18, !tbaa !24
  %t227 = trunc i64 %t225 to i32
  store { i64, [3 x i64] } zeroinitializer, ptr %t229
  %t230 = getelementptr { i64, [3 x i64] }, ptr %t229, i32 0, i32 0
  store i64 5, ptr %t230
  %t232 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t224, 0
  %t234 = insertvalue { %"compiler/source:Span", i32, i32 } %t232, i32 0, 1
  %t236 = insertvalue { %"compiler/source:Span", i32, i32 } %t234, i32 %t227, 2
  %t237 = getelementptr { i64, [3 x i64] }, ptr %t229, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t236, ptr %t237
  %t238 = load { i64, [3 x i64] }, ptr %t229
  %t240 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t238, ptr %t240
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t223, ptr %t240)
  br label %bb34
bb34:
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t245 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t243)
  store ptr %t245, ptr %l149
  br label %bb35
bb35:
  %t246 = load ptr, ptr %l149, !tbaa !29
  %t248 = getelementptr %"compiler/check:frame", ptr %t246, i32 0, i32 10
  %t250 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t248)
  %t251 = extractvalue { i32, i64 } %t250, 1
  %t252 = extractvalue { i32, i64 } %t250, 0
  store i32 %t252, ptr %l153
  %t253 = icmp ne i32 %t252, 0
  br i1 %t253, label %bb37, label %ok.254, !prof !99
ok.254:
  store i64 %t251, ptr %l152
  br label %bb36
bb36:
  %t255 = load i64, ptr %l152, !tbaa !24
  store i64 %t255, ptr %l147, !tbaa !24
  br label %bb39
bb37:
  br label %bb38
bb38:
  call void @__olang_ert_req_clear()
  br label %bb39
bb39:
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t257 = load i64, ptr %l18, !tbaa !24
  %t258 = load i64, ptr %l19, !tbaa !24
  %t259 = load i64, ptr %l20, !tbaa !24
  %t260 = load i64, ptr %l16, !tbaa !24
  %t266 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v0, ptr %t256, i64 %t257, i64 %t258, i64 %t259, i64 %t260)
  store ptr %t266, ptr %l159
  br label %bb40
bb40:
  %t267 = load ptr, ptr %l159, !tbaa !29
  store ptr %t267, ptr %l23, !tbaa !29
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t270 = getelementptr %"compiler/check:Checker", ptr %t268, i32 0, i32 37
  %t272 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t270)
  store i64 %t272, ptr %l162
  br label %bb41
bb41:
  %t273 = load i64, ptr %l162, !tbaa !24
  store i64 %t273, ptr %l24, !tbaa !24
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t275 = load %"compiler/source:Span", ptr %l1
  %t279 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t274, i32 3, %"compiler/source:Span" %t275)
  store { i64, i64, i64 } %t279, ptr %l166
  br label %bb42
bb42:
  %t280 = load { i64, i64, i64 }, ptr %l166
  store { i64, i64, i64 } %t280, ptr %l25
  %t281 = getelementptr { i64, i64, i64 }, ptr %l25, i32 0, i32 0
  %t282 = load i64, ptr %t281, !tbaa !24
  store i64 %t282, ptr %l26, !tbaa !24
  %t284 = getelementptr { i64, i64, i64 }, ptr %l25, i32 0, i32 1
  %t285 = load i64, ptr %t284, !tbaa !24
  store i64 %t285, ptr %l27, !tbaa !24
  %t287 = getelementptr { i64, i64, i64 }, ptr %l25, i32 0, i32 2
  %t288 = load i64, ptr %t287, !tbaa !24
  store i64 %t288, ptr %l28, !tbaa !24
  %t290 = load ptr, ptr %l0, !tbaa !29
  %t291 = load %"compiler/source:Span", ptr %l1
  %t292 = load i64, ptr %l18, !tbaa !24
  %t294 = trunc i64 %t292 to i32
  store { i64, [3 x i64] } zeroinitializer, ptr %t296
  %t297 = getelementptr { i64, [3 x i64] }, ptr %t296, i32 0, i32 0
  store i64 5, ptr %t297
  %t299 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t291, 0
  %t301 = insertvalue { %"compiler/source:Span", i32, i32 } %t299, i32 0, 1
  %t303 = insertvalue { %"compiler/source:Span", i32, i32 } %t301, i32 %t294, 2
  %t304 = getelementptr { i64, [3 x i64] }, ptr %t296, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t303, ptr %t304
  %t305 = load { i64, [3 x i64] }, ptr %t296
  %t307 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t305, ptr %t307
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t290, ptr %t307)
  br label %bb43
bb43:
  %t310 = load ptr, ptr %l0, !tbaa !29
  %t311 = load i64, ptr %l26, !tbaa !24
  %t312 = load i64, ptr %l27, !tbaa !24
  %t313 = load i64, ptr %l28, !tbaa !24
  %t314 = load i64, ptr %l24, !tbaa !24
  %t320 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v0, ptr %t310, i64 %t311, i64 %t312, i64 %t313, i64 %t314)
  store ptr %t320, ptr %l183
  br label %bb44
bb44:
  %t321 = load ptr, ptr %l183, !tbaa !29
  %t322 = load ptr, ptr %l0, !tbaa !29
  %t323 = load %"compiler/source:Span", ptr %l1
  %t324 = load ptr, ptr %l23, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t327
  %t328 = getelementptr { i64, [3 x i64] }, ptr %t327, i32 0, i32 0
  store i64 4, ptr %t328
  %t330 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t323, 0
  %t332 = insertvalue { %"compiler/source:Span", ptr, ptr } %t330, ptr %t324, 1
  %t334 = insertvalue { %"compiler/source:Span", ptr, ptr } %t332, ptr %t321, 2
  %t335 = getelementptr { i64, [3 x i64] }, ptr %t327, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t334, ptr %t335
  %t336 = load { i64, [3 x i64] }, ptr %t327
  %t338 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t336, ptr %t338
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t322, ptr %t338)
  br label %bb45
bb45:
  br label %bb46
bb46:
  %t341 = load i64, ptr %l14, !tbaa !24
  %t343 = add i64 %t341, 1
  store i64 %t343, ptr %l14, !tbaa !24
  br label %bb13
bb47:
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t346 = load %"compiler/source:Span", ptr %l1
  %t347 = load i64, ptr %l7, !tbaa !24
  %t349 = trunc i64 %t347 to i32
  store { i64, [3 x i64] } zeroinitializer, ptr %t351
  %t352 = getelementptr { i64, [3 x i64] }, ptr %t351, i32 0, i32 0
  store i64 5, ptr %t352
  %t354 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t346, 0
  %t356 = insertvalue { %"compiler/source:Span", i32, i32 } %t354, i32 0, 1
  %t358 = insertvalue { %"compiler/source:Span", i32, i32 } %t356, i32 %t349, 2
  %t359 = getelementptr { i64, [3 x i64] }, ptr %t351, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t358, ptr %t359
  %t360 = load { i64, [3 x i64] }, ptr %t351
  %t362 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t360, ptr %t362
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t345, ptr %t362)
  br label %bb48
bb48:
  %t365 = load ptr, ptr %l0, !tbaa !29
  %t367 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t365)
  store ptr %t367, ptr %l203
  br label %bb49
bb49:
  %t368 = load ptr, ptr %l203, !tbaa !29
  %t370 = getelementptr %"compiler/check:frame", ptr %t368, i32 0, i32 11
  %t372 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t370)
  %t373 = extractvalue { i32, i64 } %t372, 1
  %t374 = extractvalue { i32, i64 } %t372, 0
  store i32 %t374, ptr %l207
  %t375 = icmp ne i32 %t374, 0
  br i1 %t375, label %bb51, label %ok.376, !prof !99
ok.376:
  store i64 %t373, ptr %l206
  br label %bb50
bb50:
  %t377 = load i64, ptr %l206, !tbaa !24
  store i64 %t377, ptr %l201, !tbaa !24
  br label %bb53
bb51:
  br label %bb52
bb52:
  call void @__olang_ert_req_clear()
  br label %bb53
bb53:
  %t378 = load ptr, ptr %l0, !tbaa !29
  %t379 = load i64, ptr %l7, !tbaa !24
  %t380 = load i64, ptr %l8, !tbaa !24
  %t381 = load i64, ptr %l9, !tbaa !24
  %t382 = load i64, ptr %l5, !tbaa !24
  %t388 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v0, ptr %t378, i64 %t379, i64 %t380, i64 %t381, i64 %t382)
  store ptr %t388, ptr %l213
  br label %bb54
bb54:
  %t389 = load ptr, ptr %l213, !tbaa !29
  %t390 = load ptr, ptr %l0, !tbaa !29
  %t391 = load %"compiler/source:Span", ptr %l1
  store { i64, [3 x i64] } zeroinitializer, ptr %t393
  %t394 = getelementptr { i64, [3 x i64] }, ptr %t393, i32 0, i32 0
  store i64 4, ptr %t394
  %t396 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t391, 0
  %t398 = insertvalue { %"compiler/source:Span", ptr, ptr } %t396, ptr %t389, 1
  %t399 = insertvalue { %"compiler/source:Span", ptr, ptr } %t398, ptr null, 2
  %t400 = getelementptr { i64, [3 x i64] }, ptr %t393, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t399, ptr %t400
  %t401 = load { i64, [3 x i64] }, ptr %t393
  %t403 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t401, ptr %t403
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t390, ptr %t403)
  br label %bb55
bb55:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrollElem(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l8 = alloca ptr
  %l12 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca i32
  %l24 = alloca ptr
  %l26 = alloca %"compiler/source:Span"
  %l29 = alloca { i64, ptr }
  %l31 = alloca %"compiler/msgs:Msg"
  %l32 = alloca i64
  %l38 = alloca i32
  %l41 = alloca i1
  %l43 = alloca ptr
  %l45 = alloca %"compiler/source:Span"
  %l48 = alloca { i64, ptr }
  %l50 = alloca %"compiler/msgs:Msg"
  %l51 = alloca i64
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l8, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 14
  %t13 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t9, i64 %a2)
  store ptr %t13, ptr %l12
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l12, !tbaa !29
  %t16 = getelementptr %"compiler/typed:Body", ptr %t14, i32 0, i32 2
  %t17 = load i32, ptr %t16, !tbaa !23
  %t18 = load ptr, ptr %l8, !tbaa !29
  %t20 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t18, i32 %t17)
  store i32 %t20, ptr %l15
  br label %bb2
bb2:
  %t21 = load i32, ptr %l15, !tbaa !23
  store i32 %t21, ptr %l3, !tbaa !23
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l16, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i32, ptr %l3, !tbaa !23
  %t27 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t27, ptr %l19
  br label %bb3
bb3:
  %t28 = load ptr, ptr %l16, !tbaa !29
  %t29 = load i32, ptr %l19, !tbaa !23
  %t30 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t28, i32 %t29)
  store i32 %t30, ptr %l20
  br label %bb4
bb4:
  %t31 = load i32, ptr %l20, !tbaa !23
  store i32 %t31, ptr %l4, !tbaa !23
  %t32 = load i32, ptr %l4, !tbaa !23
  %t33 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t36 = icmp eq i32 %t32, %t33
  br i1 %t36, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l24, !tbaa !29
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t39)
  store %"compiler/source:Span" %t41, ptr %l26
  br label %bb7
bb6:
  br label %bb11
bb7:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load i32, ptr %l3, !tbaa !23
  %t46 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t42, i32 %t43)
  store { i64, ptr } %t46, ptr %l29
  br label %bb8
bb8:
  %t47 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t47, 0
  %t49 = extractvalue { i64, ptr } %t47, 1
  %t50 = mul i64 %t48, 1
  %t51 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t50)
  call void @llvm.memcpy.p0.p0.i64(ptr %t51, ptr %t49, i64 %t50, i1 false)
  %t52 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t51, 1
  %t55 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eComptimeForSource(ptr %s1, ptr %s1, { i64, ptr } %t53)
  store %"compiler/msgs:Msg" %t55, ptr %l31
  br label %bb9
bb9:
  %t56 = load ptr, ptr %l24, !tbaa !29
  %t57 = load %"compiler/source:Span", ptr %l26
  %t58 = load %"compiler/msgs:Msg", ptr %l31
  %t59 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t56, %"compiler/source:Span" %t57, %"compiler/msgs:Msg" %t58)
  store i64 %t59, ptr %l32
  br label %bb10
bb10:
  %t60 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  store i32 %t60, ptr %rv
  br label %ret
bb11:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Program", ptr %t65, i32 0, i32 2
  %t68 = load i32, ptr %l4, !tbaa !23
  %t71 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t67, i32 %t68)
  store i32 %t71, ptr %l38
  br label %bb12
bb12:
  %t72 = load i32, ptr %l38, !tbaa !23
  store i32 %t72, ptr %l5, !tbaa !23
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load i32, ptr %l5, !tbaa !23
  %t77 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrollable(ptr %v0, ptr %t73, i32 %t74)
  store i1 %t77, ptr %l41
  br label %bb13
bb13:
  %t78 = load i1, ptr %l41, !tbaa !21
  %t79 = xor i1 %t78, true
  br i1 %t79, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s2
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l43, !tbaa !29
  %t82 = load ptr, ptr %l1, !tbaa !29
  %t84 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t82)
  store %"compiler/source:Span" %t84, ptr %l45
  br label %bb16
bb15:
  br label %bb20
bb16:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load i32, ptr %l5, !tbaa !23
  %t89 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t85, i32 %t86)
  store { i64, ptr } %t89, ptr %l48
  br label %bb17
bb17:
  %t90 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t90, 0
  %t92 = extractvalue { i64, ptr } %t90, 1
  %t93 = mul i64 %t91, 1
  %t94 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t93)
  call void @llvm.memcpy.p0.p0.i64(ptr %t94, ptr %t92, i64 %t93, i1 false)
  %t95 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %t94, 1
  %t98 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eComptimeForElem(ptr %s2, ptr %s2, { i64, ptr } %t96)
  store %"compiler/msgs:Msg" %t98, ptr %l50
  br label %bb18
bb18:
  %t99 = load ptr, ptr %l43, !tbaa !29
  %t100 = load %"compiler/source:Span", ptr %l45
  %t101 = load %"compiler/msgs:Msg", ptr %l50
  %t102 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t99, %"compiler/source:Span" %t100, %"compiler/msgs:Msg" %t101)
  store i64 %t102, ptr %l51
  br label %bb19
bb19:
  %t103 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  store i32 %t103, ptr %rv
  br label %ret
bb20:
  %t105 = load i32, ptr %l5, !tbaa !23
  store i32 %t105, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evarDecl(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca i64
  %l12 = alloca i32
  %l13 = alloca { i64, [2 x i64] }
  %l14 = alloca %"compiler/source:Span"
  %l15 = alloca %"compiler/source:Span"
  %l16 = alloca i32
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca %"compiler/source:Span"
  %l24 = alloca i64
  %l26 = alloca i32
  %l27 = alloca ptr
  %l28 = alloca %"compiler/check:unsetCand"
  %l29 = alloca i1
  %l30 = alloca i32
  %l31 = alloca i32
  %l32 = alloca { i64, [3 x i64] }
  %l34 = alloca %"compiler/source:Span"
  %l35 = alloca { i64, [3 x i64] }
  %l36 = alloca ptr
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i1
  %l40 = alloca i64
  %l41 = alloca i1
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i1
  %l48 = alloca i1
  %l52 = alloca i1
  %l57 = alloca i1
  %l67 = alloca i64
  %l70 = alloca i64
  %l90 = alloca { i64, ptr }
  %l93 = alloca i64
  %l98 = alloca { i64, ptr }
  %l102 = alloca { i64, ptr }
  %l105 = alloca ptr
  %l106 = alloca %"compiler/source:Span"
  %l109 = alloca i32
  %l110 = alloca i32
  %l112 = alloca ptr
  %l116 = alloca %"compiler/typed:Local"
  %l118 = alloca i64
  %l119 = alloca ptr
  %l120 = alloca %"compiler/source:Span"
  %l123 = alloca i32
  %l129 = alloca ptr
  %l130 = alloca %"compiler/source:Span"
  %l133 = alloca i32
  %l137 = alloca ptr
  %l141 = alloca ptr
  %l153 = alloca i1
  %l172 = alloca i32
  %l176 = alloca { i64, [2 x i64] }
  %l179 = alloca i1
  %l183 = alloca ptr
  %l190 = alloca %"compiler/source:Span"
  %l193 = alloca ptr
  %l194 = alloca %"compiler/source:Span"
  %l195 = alloca %"compiler/msgs:Msg"
  %l196 = alloca i64
  %l200 = alloca ptr
  %l207 = alloca %"compiler/source:Span"
  %l210 = alloca ptr
  %l211 = alloca %"compiler/source:Span"
  %l214 = alloca %"compiler/msgs:Msg"
  %l217 = alloca { i64, ptr }
  %l219 = alloca %"compiler/msgs:Msg"
  %l222 = alloca { i64, ptr }
  %l224 = alloca %"compiler/msgs:Msg"
  %l225 = alloca i64
  %l228 = alloca i32
  %l237 = alloca i64
  %l240 = alloca i64
  %l259 = alloca { i64, ptr }
  %l266 = alloca { i64, ptr }
  %l269 = alloca i64
  %l272 = alloca i1
  %l274 = alloca ptr
  %l278 = alloca %"compiler/typed:Local"
  %l281 = alloca ptr
  %l282 = alloca %"compiler/source:Span"
  %l285 = alloca { i64, ptr }
  %l288 = alloca { i64, ptr }
  %l290 = alloca %"compiler/msgs:Msg"
  %l291 = alloca i64
  %l295 = alloca ptr
  %l296 = alloca i64
  %l297 = alloca ptr
  %l299 = alloca ptr
  %l303 = alloca %"compiler/typed:Local"
  %l305 = alloca { i64, [3 x i64] }
  %l308 = alloca { i64, ptr }
  %l311 = alloca { i64, ptr }
  %l313 = alloca %"compiler/msgs:Msg"
  %l317 = alloca %"compiler/check:unsetCand"
  %l319 = alloca ptr
  %l323 = alloca { i64, ptr }
  %l326 = alloca i1
  %l331 = alloca ptr
  %l333 = alloca ptr
  %l336 = alloca i64
  %l337 = alloca i32
  %l342 = alloca i32
  %l345 = alloca i1
  %l350 = alloca i32
  %l355 = alloca i1
  %l360 = alloca i1
  %l364 = alloca i1
  %l371 = alloca ptr
  %l373 = alloca ptr
  %l378 = alloca { i64, ptr }
  %l382 = alloca i32
  %l385 = alloca i1
  %l391 = alloca i1
  %l395 = alloca i1
  %l400 = alloca i1
  %l404 = alloca i1
  %l409 = alloca i32
  %l412 = alloca i1
  %l413 = alloca ptr
  %l418 = alloca i32
  %l419 = alloca i1
  %l422 = alloca { i64, ptr }
  %l427 = alloca ptr
  %l430 = alloca ptr
  %l432 = alloca i32
  %l434 = alloca i1
  %l435 = alloca i1
  %l438 = alloca ptr
  %l440 = alloca i32
  %l441 = alloca i32
  %l445 = alloca i32
  %l446 = alloca ptr
  %l449 = alloca ptr
  %l450 = alloca i32
  %l452 = alloca { i64, ptr }
  %l455 = alloca %"compiler/source:Span"
  %l456 = alloca ptr
  %l469 = alloca i1
  %l473 = alloca ptr
  %l474 = alloca ptr
  %l480 = alloca { i64, [3 x i64] }
  %l484 = alloca i1
  %l489 = alloca i1
  %l492 = alloca { i64, ptr }
  %l496 = alloca { i64, ptr }
  %l499 = alloca i1
  %l504 = alloca { i64, ptr }
  %l508 = alloca ptr
  %l516 = alloca i1
  %l519 = alloca ptr
  %l521 = alloca { i64, ptr }
  %l523 = alloca ptr
  %l528 = alloca i32
  %l531 = alloca i1
  %l536 = alloca ptr
  %l543 = alloca %"compiler/source:Span"
  %l546 = alloca ptr
  %l547 = alloca %"compiler/source:Span"
  %l550 = alloca { i64, ptr }
  %l552 = alloca %"compiler/msgs:Msg"
  %l553 = alloca i64
  %l556 = alloca ptr
  %l559 = alloca i32
  %l560 = alloca i32
  %l563 = alloca i1
  %l566 = alloca ptr
  %l567 = alloca i32
  %l569 = alloca i32
  %l570 = alloca i1
  %l572 = alloca ptr
  %l575 = alloca ptr
  %l576 = alloca i32
  %l578 = alloca { i64, ptr }
  %l581 = alloca %"compiler/source:Span"
  %l582 = alloca ptr
  %l586 = alloca ptr
  %l587 = alloca ptr
  %l593 = alloca { i64, [3 x i64] }
  %l599 = alloca i64
  %l601 = alloca i64
  %l605 = alloca ptr
  %l609 = alloca i64
  %l616 = alloca ptr
  %l622 = alloca i64
  %l629 = alloca i64
  %l633 = alloca ptr
  %l643 = alloca %"compiler/check:unsetCand"
  %l644 = alloca i32
  %l646 = alloca i32
  %l648 = alloca i1
  %l649 = alloca ptr
  %l651 = alloca i32
  %l652 = alloca i1
  %l653 = alloca ptr
  %l654 = alloca %"compiler/source:Span"
  %l655 = alloca %"compiler/source:Span"
  %l656 = alloca i32
  %l662 = alloca ptr
  %l669 = alloca i1
  %l673 = alloca i1
  %l677 = alloca i1
  %l680 = alloca i1
  %l681 = alloca i1
  %l686 = alloca i64
  %l690 = alloca i1
  %l693 = alloca ptr
  %l696 = alloca i32
  %l697 = alloca i32
  %l701 = alloca i1
  %l704 = alloca i1
  %l707 = alloca ptr
  %l712 = alloca i32
  %l717 = alloca i64
  %l721 = alloca i32
  %l727 = alloca i1
  %l730 = alloca i1
  %l733 = alloca i1
  %l735 = alloca ptr
  %l736 = alloca ptr
  %l738 = alloca { i64, ptr }
  %l741 = alloca %"compiler/source:Span"
  %l743 = alloca i1
  %l746 = alloca { i64, ptr }
  %l753 = alloca i64
  %l759 = alloca i1
  %l763 = alloca i1
  %l768 = alloca i1
  %l771 = alloca ptr
  %l776 = alloca i32
  %l777 = alloca i32
  %l780 = alloca i1
  %l783 = alloca ptr
  %l788 = alloca i32
  %l789 = alloca i32
  %l791 = alloca i1
  %l794 = alloca i1
  %l797 = alloca ptr
  %l801 = alloca ptr
  %l807 = alloca ptr
  %l816 = alloca %"compiler/check:unsetCand"
  %l821 = alloca i1
  %l826 = alloca ptr
  %l828 = alloca ptr
  %l829 = alloca i64
  %l830 = alloca ptr
  %l836 = alloca { i64, [3 x i64] }
  %l838 = alloca ptr
  %l839 = alloca i64
  %l844 = alloca i1
  %l848 = alloca i1
  %l851 = alloca i1
  %l852 = alloca i1
  %l855 = alloca { i64, ptr }
  %l858 = alloca i1
  %l860 = alloca ptr
  %l862 = alloca ptr
  %l866 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l870 = alloca i1
  %l876 = alloca i1
  %l879 = alloca i1
  %l881 = alloca ptr
  %l883 = alloca ptr
  %l887 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l889 = alloca { i64, ptr }
  %l893 = alloca %"compiler/check:fixedInit"
  %l899 = alloca i1
  %l902 = alloca i1
  %l904 = alloca i1
  %l909 = alloca i1
  %l910 = alloca i1
  %l914 = alloca i1
  %l916 = alloca ptr
  %l920 = alloca ptr
  %l922 = alloca ptr
  %l923 = alloca %"compiler/source:Span"
  %l926 = alloca i32
  %l935 = alloca ptr
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s38 = alloca %olang.scope
  %s41 = alloca %olang.scope
  %s42 = alloca %olang.scope
  %t165 = alloca { i64, [4 x i64] }, align 8
  %t192 = alloca { i64, [3 x i64] }, align 8
  %t254 = alloca { i64, [2 x i64] }, align 8
  %t1329 = alloca { i64, [4 x i64] }, align 8
  %t1894 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:VarDecl", ptr %t1, i32 0, i32 5
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"compiler/ast:VarDecl", ptr %t6, i32 0, i32 2
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = icmp eq ptr %t9, null
  store i1 %t11, ptr %l48, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l48, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  %t14 = load ptr, ptr %l2, !tbaa !29
  %t16 = getelementptr %"compiler/ast:VarDecl", ptr %t14, i32 0, i32 3
  %t17 = load { i64, ptr }, ptr %t16, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t21 = icmp eq i64 %t19, 0
  store i1 %t21, ptr %l52, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb6
bb6:
  %t23 = load i1, ptr %l52, !tbaa !21
  br i1 %t23, label %bb7, label %bb8
bb7:
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t26 = getelementptr %"compiler/ast:VarDecl", ptr %t24, i32 0, i32 4
  %t27 = load i1, ptr %t26, !tbaa !21
  %t29 = xor i1 %t27, true
  store i1 %t29, ptr %l57, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l57, !tbaa !21
  br label %bb9
bb9:
  %t31 = load i1, ptr %l57, !tbaa !21
  br i1 %t31, label %bb10, label %bb11
bb10:
  store i64 0, ptr %l3, !tbaa !24
  %t32 = load ptr, ptr %l2, !tbaa !29
  %t34 = getelementptr %"compiler/ast:VarDecl", ptr %t32, i32 0, i32 0
  %t35 = load { i64, ptr }, ptr %t34, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  store i64 %t37, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t39 = load i64, ptr %l4, !tbaa !24
  %t40 = load i64, ptr %l3, !tbaa !24
  %t43 = icmp sgt i64 %t39, %t40
  br i1 %t43, label %bb12, label %bb13
bb11:
  br label %bb39
bb12:
  %t45 = load i64, ptr %l5, !tbaa !24
  %t47 = icmp sgt i64 %t45, 0
  br i1 %t47, label %bb14, label %bb15
bb13:
  store i64 0, ptr %l67, !tbaa !24
  br label %bb17
bb14:
  %t49 = load i64, ptr %l4, !tbaa !24
  %t50 = load i64, ptr %l3, !tbaa !24
  %t53 = sub i64 %t49, %t50
  %t54 = load i64, ptr %l5, !tbaa !24
  %t57 = add i64 %t53, %t54
  %t59 = sub i64 %t57, 1
  %t60 = load i64, ptr %l5, !tbaa !24
  %t63 = sdiv i64 %t59, %t60
  store i64 %t63, ptr %l70, !tbaa !24
  br label %bb16
bb15:
  store i64 0, ptr %l70, !tbaa !24
  br label %bb16
bb16:
  %t65 = load i64, ptr %l70, !tbaa !24
  store i64 %t65, ptr %l67, !tbaa !24
  br label %bb17
bb17:
  %t66 = load i64, ptr %l67, !tbaa !24
  store i64 %t66, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb18
bb18:
  store %olang.scope zeroinitializer, ptr %s3
  %t67 = load i64, ptr %l7, !tbaa !24
  %t68 = load i64, ptr %l6, !tbaa !24
  %t71 = icmp slt i64 %t67, %t68
  %t73 = xor i1 %t71, true
  br i1 %t73, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s3)
  br label %bb38
bb20:
  br label %bb21
bb21:
  %t75 = load i64, ptr %l3, !tbaa !24
  %t76 = load i64, ptr %l7, !tbaa !24
  %t77 = load i64, ptr %l5, !tbaa !24
  %t80 = mul i64 %t76, %t77
  %t83 = add i64 %t75, %t80
  store i64 %t83, ptr %l8, !tbaa !24
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load ptr, ptr %l2, !tbaa !29
  %t88 = getelementptr %"compiler/ast:VarDecl", ptr %t86, i32 0, i32 0
  %t89 = load { i64, ptr }, ptr %t88, !tbaa !27
  store { i64, ptr } %t89, ptr %l90, !tbaa !27
  %t90 = load i64, ptr %l8, !tbaa !24
  %t92 = getelementptr { i64, ptr }, ptr %l90, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = getelementptr i32, ptr %t93, i64 %t90
  %t95 = load i32, ptr %t94, !tbaa !33
  %t98 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %t85, i32 %t95)
  store i64 %t98, ptr %l93
  br label %bb22
bb22:
  %t99 = load i64, ptr %l93, !tbaa !24
  store i64 %t99, ptr %l9, !tbaa !24
  %t100 = load i64, ptr %l9, !tbaa !24
  %t102 = icmp slt i64 %t100, 0
  br i1 %t102, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s4
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load ptr, ptr %l2, !tbaa !29
  %t107 = getelementptr %"compiler/ast:VarDecl", ptr %t105, i32 0, i32 1
  %t108 = load { i64, ptr }, ptr %t107, !tbaa !27
  store { i64, ptr } %t108, ptr %l98, !tbaa !27
  %t109 = load i64, ptr %l8, !tbaa !24
  %t111 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr %"compiler/source:Span", ptr %t112, i64 %t109
  %t114 = load %"compiler/source:Span", ptr %t113
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s4, ptr %t104, %"compiler/source:Span" %t114, { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d43, i32 0, i32 1) })
  br label %bb25
bb24:
  br label %bb26
bb25:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  br label %bb37
bb26:
  %t117 = load ptr, ptr %l2, !tbaa !29
  %t119 = getelementptr %"compiler/ast:VarDecl", ptr %t117, i32 0, i32 1
  %t120 = load { i64, ptr }, ptr %t119, !tbaa !27
  store { i64, ptr } %t120, ptr %l102, !tbaa !27
  %t121 = load i64, ptr %l8, !tbaa !24
  %t123 = getelementptr { i64, ptr }, ptr %l102, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !27
  %t125 = getelementptr %"compiler/source:Span", ptr %t124, i64 %t121
  %t126 = load %"compiler/source:Span", ptr %t125
  store %"compiler/source:Span" %t126, ptr %l10
  %t128 = load ptr, ptr %l0, !tbaa !29
  store ptr %t128, ptr %l105, !tbaa !29
  %t129 = load %"compiler/source:Span", ptr %l10
  store %"compiler/source:Span" %t129, ptr %l106
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t131 = load i64, ptr %l9, !tbaa !24
  %t134 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t130, i64 %t131)
  store i32 %t134, ptr %l109
  br label %bb27
bb27:
  store i32 6, ptr %l110
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t135)
  store ptr %t137, ptr %l112
  br label %bb28
bb28:
  %t138 = load ptr, ptr %l112, !tbaa !29
  %t140 = getelementptr %"compiler/typed:Body", ptr %t138, i32 0, i32 7
  %t141 = load i64, ptr %l9, !tbaa !24
  %t144 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t140, i64 %t141)
  store %"compiler/typed:Local" %t144, ptr %l116
  br label %bb29
bb29:
  %t145 = getelementptr %"compiler/typed:Local", ptr %l116, i32 0, i32 5
  %t146 = load { i64, [2 x i64] }, ptr %t145
  %t147 = load ptr, ptr %l105, !tbaa !29
  %t148 = load %"compiler/source:Span", ptr %l106
  %t149 = load i32, ptr %l109, !tbaa !23
  %t150 = load i32, ptr %l110, !range !{i32 0, i32 7}
  %t152 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t147, i32 0, %"compiler/source:Span" %t148, i32 %t149, i32 %t150, { i64, [2 x i64] } %t146)
  store i64 %t152, ptr %l118
  br label %bb30
bb30:
  %t153 = load i64, ptr %l118, !tbaa !24
  store i64 %t153, ptr %l11, !tbaa !24
  %t154 = load ptr, ptr %l0, !tbaa !29
  store ptr %t154, ptr %l119, !tbaa !29
  %t155 = load %"compiler/source:Span", ptr %l10
  store %"compiler/source:Span" %t155, ptr %l120
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load i64, ptr %l9, !tbaa !24
  %t160 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t156, i64 %t157)
  store i32 %t160, ptr %l123
  br label %bb31
bb31:
  %t161 = load i64, ptr %l9, !tbaa !24
  %t163 = trunc i64 %t161 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t165
  %t166 = getelementptr { i64, [4 x i64] }, ptr %t165, i32 0, i32 0
  store i64 0, ptr %t166
  %t167 = load %"compiler/source:Span", ptr %l120
  %t168 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t167, 0
  %t169 = load i32, ptr %l123, !tbaa !23
  %t170 = insertvalue { %"compiler/source:Span", i32, i32 } %t168, i32 %t169, 1
  %t172 = insertvalue { %"compiler/source:Span", i32, i32 } %t170, i32 %t163, 2
  %t173 = getelementptr { i64, [4 x i64] }, ptr %t165, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t172, ptr %t173
  %t174 = load { i64, [4 x i64] }, ptr %t165
  %t176 = call ptr @__olang_scope_alloc_a(ptr %s3, i64 40, i64 8)
  store { i64, [4 x i64] } %t174, ptr %t176
  %t177 = load ptr, ptr %l119, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroNeed(ptr %v0, ptr %s3, ptr %t177, ptr %t176)
  br label %bb32
bb32:
  %t179 = load ptr, ptr %l0, !tbaa !29
  store ptr %t179, ptr %l129, !tbaa !29
  %t180 = load %"compiler/source:Span", ptr %l10
  store %"compiler/source:Span" %t180, ptr %l130
  %t181 = load i64, ptr %l11, !tbaa !24
  %t183 = trunc i64 %t181 to i32
  store i32 %t183, ptr %l133, !tbaa !23
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t186 = load %"compiler/source:Span", ptr %l10
  %t187 = load i64, ptr %l9, !tbaa !24
  %t191 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t185, %"compiler/source:Span" %t186, i64 %t187)
  store ptr %t191, ptr %l137
  br label %bb33
bb33:
  store { i64, [3 x i64] } zeroinitializer, ptr %t192
  %t193 = getelementptr { i64, [3 x i64] }, ptr %t192, i32 0, i32 0
  store i64 0, ptr %t193
  %t194 = load %"compiler/source:Span", ptr %l130
  %t195 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t194, 0
  %t196 = load i32, ptr %l133, !tbaa !23
  %t197 = insertvalue { %"compiler/source:Span", i32, ptr } %t195, i32 %t196, 1
  %t198 = load ptr, ptr %l137, !tbaa !29
  %t199 = insertvalue { %"compiler/source:Span", i32, ptr } %t197, ptr %t198, 2
  %t200 = getelementptr { i64, [3 x i64] }, ptr %t192, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t199, ptr %t200
  %t201 = load { i64, [3 x i64] }, ptr %t192
  %t203 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t201, ptr %t203
  %t204 = load ptr, ptr %l129, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t204, ptr %t203)
  br label %bb34
bb34:
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t208 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t206)
  store ptr %t208, ptr %l141
  br label %bb35
bb35:
  %t209 = load ptr, ptr %l141, !tbaa !29
  %t211 = getelementptr %"compiler/typed:Body", ptr %t209, i32 0, i32 10
  %t212 = load i64, ptr %l11, !tbaa !24
  %t214 = trunc i64 %t212 to i32
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2ePush_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t211, i32 %t214)
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s3)
  br label %bb37
bb37:
  %t218 = load i64, ptr %l7, !tbaa !24
  %t220 = add i64 %t218, 1
  store i64 %t220, ptr %l7, !tbaa !24
  br label %bb18
bb38:
  br label %ret
bb39:
  %t222 = load ptr, ptr %l2, !tbaa !29
  %t224 = getelementptr %"compiler/ast:VarDecl", ptr %t222, i32 0, i32 3
  %t225 = load { i64, ptr }, ptr %t224, !tbaa !27
  %t227 = extractvalue { i64, ptr } %t225, 0
  %t229 = icmp ne i64 %t227, 0
  br i1 %t229, label %bb40, label %bb41
bb40:
  %t231 = load ptr, ptr %l2, !tbaa !29
  %t233 = getelementptr %"compiler/ast:VarDecl", ptr %t231, i32 0, i32 3
  %t234 = load { i64, ptr }, ptr %t233, !tbaa !27
  %t236 = extractvalue { i64, ptr } %t234, 0
  %t237 = load ptr, ptr %l2, !tbaa !29
  %t239 = getelementptr %"compiler/ast:VarDecl", ptr %t237, i32 0, i32 0
  %t240 = load { i64, ptr }, ptr %t239, !tbaa !27
  %t242 = extractvalue { i64, ptr } %t240, 0
  %t245 = icmp ne i64 %t236, %t242
  store i1 %t245, ptr %l153, !tbaa !21
  br label %bb42
bb41:
  store i1 false, ptr %l153, !tbaa !21
  br label %bb42
bb42:
  %t247 = load i1, ptr %l153, !tbaa !21
  br i1 %t247, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s6
  %t248 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s6, ptr %t248, %"compiler/source:Span" %a1, { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d44, i32 0, i32 1) })
  br label %bb45
bb44:
  br label %bb46
bb45:
  call void @__olang_scope_close(ptr %s6)
  br label %ret
bb46:
  %t252 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t252, ptr %l12, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t254
  %t255 = getelementptr { i64, [2 x i64] }, ptr %t254, i32 0, i32 0
  store i64 5, ptr %t255
  %t256 = load { i64, [2 x i64] }, ptr %t254
  store { i64, [2 x i64] } %t256, ptr %l13
  %t258 = load ptr, ptr %l2, !tbaa !29
  %t260 = getelementptr %"compiler/ast:VarDecl", ptr %t258, i32 0, i32 2
  %t261 = load ptr, ptr %t260, !tbaa !29
  %t263 = icmp eq ptr %t261, null
  %t265 = xor i1 %t263, true
  br i1 %t265, label %bb47, label %bb48
bb47:
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t268 = load ptr, ptr %l2, !tbaa !29
  %t270 = getelementptr %"compiler/ast:VarDecl", ptr %t268, i32 0, i32 2
  %t271 = load ptr, ptr %t270, !tbaa !29
  %t274 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %t267, ptr %t271)
  store i32 %t274, ptr %l172
  br label %bb49
bb48:
  br label %bb84
bb49:
  %t275 = load i32, ptr %l172, !tbaa !23
  store i32 %t275, ptr %l12, !tbaa !23
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t277 = load ptr, ptr %l2, !tbaa !29
  %t279 = getelementptr %"compiler/ast:VarDecl", ptr %t277, i32 0, i32 2
  %t280 = load ptr, ptr %t279, !tbaa !29
  %t283 = call { i64, [2 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emarkOf(ptr %v0, ptr %v1, ptr %t276, ptr %t280)
  store { i64, [2 x i64] } %t283, ptr %l176
  br label %bb50
bb50:
  %t284 = load { i64, [2 x i64] }, ptr %l176
  store { i64, [2 x i64] } %t284, ptr %l13
  %t285 = load ptr, ptr %l2, !tbaa !29
  %t287 = getelementptr %"compiler/ast:VarDecl", ptr %t285, i32 0, i32 4
  %t288 = load i1, ptr %t287, !tbaa !21
  br i1 %t288, label %bb51, label %bb52
bb51:
  %t290 = load ptr, ptr %l2, !tbaa !29
  %t292 = getelementptr %"compiler/ast:VarDecl", ptr %t290, i32 0, i32 5
  %t293 = load i1, ptr %t292, !tbaa !21
  %t295 = xor i1 %t293, true
  store i1 %t295, ptr %l179, !tbaa !21
  br label %bb53
bb52:
  store i1 false, ptr %l179, !tbaa !21
  br label %bb53
bb53:
  %t297 = load i1, ptr %l179, !tbaa !21
  br i1 %t297, label %bb54, label %bb55
bb54:
  %t298 = load ptr, ptr %l0, !tbaa !29
  store ptr %t298, ptr %l183, !tbaa !29
  %t299 = load ptr, ptr %l2, !tbaa !29
  %t301 = getelementptr %"compiler/ast:VarDecl", ptr %t299, i32 0, i32 2
  %t302 = load ptr, ptr %t301, !tbaa !29
  %t304 = icmp eq ptr %t302, null
  br i1 %t304, label %bb56, label %bb57
bb55:
  %t306 = load ptr, ptr %l2, !tbaa !29
  %t308 = getelementptr %"compiler/ast:VarDecl", ptr %t306, i32 0, i32 4
  %t309 = load i1, ptr %t308, !tbaa !21
  %t311 = xor i1 %t309, true
  br i1 %t311, label %bb65, label %bb66
bb56:
  call void @__olang_check_failed(ptr @olang_loc_31b59b203b4a4e3f_1cfff4f24a22d803)
  unreachable
bb57:
  br label %bb58
bb58:
  %t313 = load ptr, ptr %l2, !tbaa !29
  %t315 = getelementptr %"compiler/ast:VarDecl", ptr %t313, i32 0, i32 2
  %t316 = load ptr, ptr %t315, !tbaa !29
  %t317 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t318 = load ptr, ptr %l183, !tbaa !29
  %t321 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emutBefore(ptr %v0, ptr %v1, ptr %t318, ptr %t316, i32 %t317)
  store %"compiler/source:Span" %t321, ptr %l190
  br label %bb59
bb59:
  %t322 = load %"compiler/source:Span", ptr %l190
  store %"compiler/source:Span" %t322, ptr %l14
  %t323 = getelementptr %"compiler/source:Span", ptr %l14, i32 0, i32 0
  %t324 = load i32, ptr %t323, !tbaa !23
  %t326 = icmp sge i32 %t324, 0
  br i1 %t326, label %bb60, label %bb61
bb60:
  store %olang.scope zeroinitializer, ptr %s9
  %t328 = load ptr, ptr %l0, !tbaa !29
  store ptr %t328, ptr %l193, !tbaa !29
  %t329 = load %"compiler/source:Span", ptr %l14
  store %"compiler/source:Span" %t329, ptr %l194
  %t330 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eMutOnInferredLocal(ptr %s9)
  store %"compiler/msgs:Msg" %t330, ptr %l195
  br label %bb62
bb61:
  br label %bb64
bb62:
  %t331 = load ptr, ptr %l193, !tbaa !29
  %t332 = load %"compiler/source:Span", ptr %l194
  %t333 = load %"compiler/msgs:Msg", ptr %l195
  %t334 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s9, ptr %t331, %"compiler/source:Span" %t332, %"compiler/msgs:Msg" %t333)
  store i64 %t334, ptr %l196
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s9)
  br label %bb64
bb64:
  br label %bb83
bb65:
  %t335 = load ptr, ptr %l0, !tbaa !29
  store ptr %t335, ptr %l200, !tbaa !29
  %t336 = load ptr, ptr %l2, !tbaa !29
  %t338 = getelementptr %"compiler/ast:VarDecl", ptr %t336, i32 0, i32 2
  %t339 = load ptr, ptr %t338, !tbaa !29
  %t341 = icmp eq ptr %t339, null
  br i1 %t341, label %bb67, label %bb68
bb66:
  br label %bb82
bb67:
  call void @__olang_check_failed(ptr @olang_loc_35f48b5c7c141c20_d3954a821088874)
  unreachable
bb68:
  br label %bb69
bb69:
  %t343 = load ptr, ptr %l2, !tbaa !29
  %t345 = getelementptr %"compiler/ast:VarDecl", ptr %t343, i32 0, i32 2
  %t346 = load ptr, ptr %t345, !tbaa !29
  %t347 = load i32, ptr %l12, !tbaa !23
  %t348 = load ptr, ptr %l200, !tbaa !29
  %t351 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emutBefore(ptr %v0, ptr %v1, ptr %t348, ptr %t346, i32 %t347)
  store %"compiler/source:Span" %t351, ptr %l207
  br label %bb70
bb70:
  %t352 = load %"compiler/source:Span", ptr %l207
  store %"compiler/source:Span" %t352, ptr %l15
  %t353 = getelementptr %"compiler/source:Span", ptr %l15, i32 0, i32 0
  %t354 = load i32, ptr %t353, !tbaa !23
  %t356 = icmp sge i32 %t354, 0
  br i1 %t356, label %bb71, label %bb72
bb71:
  store %olang.scope zeroinitializer, ptr %s12
  %t358 = load ptr, ptr %l0, !tbaa !29
  store ptr %t358, ptr %l210, !tbaa !29
  %t359 = load %"compiler/source:Span", ptr %l15
  store %"compiler/source:Span" %t359, ptr %l211
  %t360 = load ptr, ptr %l2, !tbaa !29
  %t362 = getelementptr %"compiler/ast:VarDecl", ptr %t360, i32 0, i32 5
  %t363 = load i1, ptr %t362, !tbaa !21
  br i1 %t363, label %bb73, label %bb74
bb72:
  br label %bb81
bb73:
  %t365 = load ptr, ptr %l0, !tbaa !29
  %t366 = load i32, ptr %l12, !tbaa !23
  %t369 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s12, ptr %t365, i32 %t366)
  store { i64, ptr } %t369, ptr %l217
  br label %bb75
bb74:
  %t370 = load ptr, ptr %l0, !tbaa !29
  %t371 = load i32, ptr %l12, !tbaa !23
  %t374 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s12, ptr %t370, i32 %t371)
  store { i64, ptr } %t374, ptr %l222
  br label %bb77
bb75:
  %t375 = load { i64, ptr }, ptr %l217, !tbaa !27
  %t376 = extractvalue { i64, ptr } %t375, 0
  %t377 = extractvalue { i64, ptr } %t375, 1
  %t378 = mul i64 %t376, 1
  %t379 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t378)
  call void @llvm.memcpy.p0.p0.i64(ptr %t379, ptr %t377, i64 %t378, i1 false)
  %t380 = insertvalue { i64, ptr } undef, i64 %t376, 0
  %t381 = insertvalue { i64, ptr } %t380, ptr %t379, 1
  %t383 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eMutOnValueField(ptr %s12, ptr %s12, { i64, ptr } %t381)
  store %"compiler/msgs:Msg" %t383, ptr %l219
  br label %bb76
bb76:
  %t384 = load %"compiler/msgs:Msg", ptr %l219
  store %"compiler/msgs:Msg" %t384, ptr %l214
  br label %bb79
bb77:
  %t385 = load { i64, ptr }, ptr %l222, !tbaa !27
  %t386 = extractvalue { i64, ptr } %t385, 0
  %t387 = extractvalue { i64, ptr } %t385, 1
  %t388 = mul i64 %t386, 1
  %t389 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t388)
  call void @llvm.memcpy.p0.p0.i64(ptr %t389, ptr %t387, i64 %t388, i1 false)
  %t390 = insertvalue { i64, ptr } undef, i64 %t386, 0
  %t391 = insertvalue { i64, ptr } %t390, ptr %t389, 1
  %t393 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eMutOnLocal(ptr %s12, ptr %s12, { i64, ptr } %t391)
  store %"compiler/msgs:Msg" %t393, ptr %l224
  br label %bb78
bb78:
  %t394 = load %"compiler/msgs:Msg", ptr %l224
  store %"compiler/msgs:Msg" %t394, ptr %l214
  br label %bb79
bb79:
  %t395 = load ptr, ptr %l210, !tbaa !29
  %t396 = load %"compiler/source:Span", ptr %l211
  %t397 = load %"compiler/msgs:Msg", ptr %l214
  %t398 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s12, ptr %t395, %"compiler/source:Span" %t396, %"compiler/msgs:Msg" %t397)
  store i64 %t398, ptr %l225
  br label %bb80
bb80:
  call void @__olang_scope_close(ptr %s12)
  br label %bb81
bb81:
  br label %bb82
bb82:
  br label %bb83
bb83:
  br label %bb84
bb84:
  %t399 = load ptr, ptr %l2, !tbaa !29
  %t401 = getelementptr %"compiler/ast:VarDecl", ptr %t399, i32 0, i32 5
  %t402 = load i1, ptr %t401, !tbaa !21
  br i1 %t402, label %bb85, label %bb86
bb85:
  store i32 6, ptr %l228
  br label %bb87
bb86:
  store i32 1, ptr %l228
  br label %bb87
bb87:
  %t406 = load i32, ptr %l228, !range !{i32 0, i32 7}
  store i32 %t406, ptr %l16
  store i64 0, ptr %l17, !tbaa !24
  %t407 = load ptr, ptr %l2, !tbaa !29
  %t409 = getelementptr %"compiler/ast:VarDecl", ptr %t407, i32 0, i32 0
  %t410 = load { i64, ptr }, ptr %t409, !tbaa !27
  %t412 = extractvalue { i64, ptr } %t410, 0
  store i64 %t412, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t414 = load i64, ptr %l18, !tbaa !24
  %t415 = load i64, ptr %l17, !tbaa !24
  %t418 = icmp sgt i64 %t414, %t415
  br i1 %t418, label %bb88, label %bb89
bb88:
  %t420 = load i64, ptr %l19, !tbaa !24
  %t422 = icmp sgt i64 %t420, 0
  br i1 %t422, label %bb90, label %bb91
bb89:
  store i64 0, ptr %l237, !tbaa !24
  br label %bb93
bb90:
  %t424 = load i64, ptr %l18, !tbaa !24
  %t425 = load i64, ptr %l17, !tbaa !24
  %t428 = sub i64 %t424, %t425
  %t429 = load i64, ptr %l19, !tbaa !24
  %t432 = add i64 %t428, %t429
  %t434 = sub i64 %t432, 1
  %t435 = load i64, ptr %l19, !tbaa !24
  %t438 = sdiv i64 %t434, %t435
  store i64 %t438, ptr %l240, !tbaa !24
  br label %bb92
bb91:
  store i64 0, ptr %l240, !tbaa !24
  br label %bb92
bb92:
  %t440 = load i64, ptr %l240, !tbaa !24
  store i64 %t440, ptr %l237, !tbaa !24
  br label %bb93
bb93:
  %t441 = load i64, ptr %l237, !tbaa !24
  store i64 %t441, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb94
bb94:
  store %olang.scope zeroinitializer, ptr %s14
  %t442 = load i64, ptr %l21, !tbaa !24
  %t443 = load i64, ptr %l20, !tbaa !24
  %t446 = icmp slt i64 %t442, %t443
  %t448 = xor i1 %t446, true
  br i1 %t448, label %bb95, label %bb96
bb95:
  call void @__olang_scope_close(ptr %s14)
  br label %bb441
bb96:
  br label %bb97
bb97:
  %t450 = load i64, ptr %l17, !tbaa !24
  %t451 = load i64, ptr %l21, !tbaa !24
  %t452 = load i64, ptr %l19, !tbaa !24
  %t455 = mul i64 %t451, %t452
  %t458 = add i64 %t450, %t455
  store i64 %t458, ptr %l22, !tbaa !24
  %t460 = load ptr, ptr %l2, !tbaa !29
  %t462 = getelementptr %"compiler/ast:VarDecl", ptr %t460, i32 0, i32 1
  %t463 = load { i64, ptr }, ptr %t462, !tbaa !27
  store { i64, ptr } %t463, ptr %l259, !tbaa !27
  %t464 = load i64, ptr %l22, !tbaa !24
  %t466 = getelementptr { i64, ptr }, ptr %l259, i32 0, i32 1
  %t467 = load ptr, ptr %t466, !tbaa !27
  %t468 = getelementptr %"compiler/source:Span", ptr %t467, i64 %t464
  %t469 = load %"compiler/source:Span", ptr %t468
  store %"compiler/source:Span" %t469, ptr %l23
  %t471 = load ptr, ptr %l2, !tbaa !29
  %t473 = getelementptr %"compiler/ast:VarDecl", ptr %t471, i32 0, i32 5
  %t474 = load i1, ptr %t473, !tbaa !21
  br i1 %t474, label %bb98, label %bb99
bb98:
  %t476 = load ptr, ptr %l0, !tbaa !29
  %t477 = load ptr, ptr %l2, !tbaa !29
  %t479 = getelementptr %"compiler/ast:VarDecl", ptr %t477, i32 0, i32 0
  %t480 = load { i64, ptr }, ptr %t479, !tbaa !27
  store { i64, ptr } %t480, ptr %l266, !tbaa !27
  %t481 = load i64, ptr %l22, !tbaa !24
  %t483 = getelementptr { i64, ptr }, ptr %l266, i32 0, i32 1
  %t484 = load ptr, ptr %t483, !tbaa !27
  %t485 = getelementptr i32, ptr %t484, i64 %t481
  %t486 = load i32, ptr %t485, !tbaa !33
  %t489 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %t476, i32 %t486)
  store i64 %t489, ptr %l269
  br label %bb100
bb99:
  br label %bb118
bb100:
  %t490 = load i64, ptr %l269, !tbaa !24
  store i64 %t490, ptr %l24, !tbaa !24
  %t491 = load i64, ptr %l24, !tbaa !24
  %t493 = icmp sge i64 %t491, 0
  br i1 %t493, label %bb101, label %bb102
bb101:
  %t495 = load ptr, ptr %l0, !tbaa !29
  %t497 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t495)
  store ptr %t497, ptr %l274
  br label %bb103
bb102:
  store i1 false, ptr %l272, !tbaa !21
  br label %bb105
bb103:
  %t498 = load ptr, ptr %l274, !tbaa !29
  %t500 = getelementptr %"compiler/typed:Body", ptr %t498, i32 0, i32 7
  %t501 = load i64, ptr %l24, !tbaa !24
  %t504 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t500, i64 %t501)
  store %"compiler/typed:Local" %t504, ptr %l278
  br label %bb104
bb104:
  %t505 = getelementptr %"compiler/typed:Local", ptr %l278, i32 0, i32 4
  %t506 = load i32, ptr %t505, !range !{i32 0, i32 7}
  %t508 = trunc i64 0 to i32
  %t509 = icmp eq i32 %t506, %t508
  store i1 %t509, ptr %l272, !tbaa !21
  br label %bb105
bb105:
  %t511 = load i1, ptr %l272, !tbaa !21
  br i1 %t511, label %bb106, label %bb107
bb106:
  store %olang.scope zeroinitializer, ptr %s16
  %t512 = load ptr, ptr %l0, !tbaa !29
  store ptr %t512, ptr %l281, !tbaa !29
  %t513 = load %"compiler/source:Span", ptr %l23
  store %"compiler/source:Span" %t513, ptr %l282
  %t514 = load ptr, ptr %l0, !tbaa !29
  %t515 = load ptr, ptr %l2, !tbaa !29
  %t517 = getelementptr %"compiler/ast:VarDecl", ptr %t515, i32 0, i32 0
  %t518 = load { i64, ptr }, ptr %t517, !tbaa !27
  store { i64, ptr } %t518, ptr %l285, !tbaa !27
  %t519 = load i64, ptr %l22, !tbaa !24
  %t521 = getelementptr { i64, ptr }, ptr %l285, i32 0, i32 1
  %t522 = load ptr, ptr %t521, !tbaa !27
  %t523 = getelementptr i32, ptr %t522, i64 %t519
  %t524 = load i32, ptr %t523, !tbaa !33
  %t527 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s16, ptr %t514, i32 %t524)
  store { i64, ptr } %t527, ptr %l288
  br label %bb108
bb107:
  br label %bb117
bb108:
  %t528 = load { i64, ptr }, ptr %l288, !tbaa !27
  %t529 = extractvalue { i64, ptr } %t528, 0
  %t530 = extractvalue { i64, ptr } %t528, 1
  %t531 = mul i64 %t529, 1
  %t532 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t531)
  call void @llvm.memcpy.p0.p0.i64(ptr %t532, ptr %t530, i64 %t531, i1 false)
  %t533 = insertvalue { i64, ptr } undef, i64 %t529, 0
  %t534 = insertvalue { i64, ptr } %t533, ptr %t532, 1
  %t536 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eFieldHasParamName(ptr %s16, ptr %s16, { i64, ptr } %t534)
  store %"compiler/msgs:Msg" %t536, ptr %l290
  br label %bb109
bb109:
  %t537 = load ptr, ptr %l281, !tbaa !29
  %t538 = load %"compiler/source:Span", ptr %l282
  %t539 = load %"compiler/msgs:Msg", ptr %l290
  %t540 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s16, ptr %t537, %"compiler/source:Span" %t538, %"compiler/msgs:Msg" %t539)
  store i64 %t540, ptr %l291
  br label %bb110
bb110:
  %t541 = load i64, ptr %l291, !tbaa !24
  %t542 = load ptr, ptr %l0, !tbaa !29
  %t544 = getelementptr %"compiler/check:Checker", ptr %t542, i32 0, i32 1
  %t545 = load ptr, ptr %t544, !tbaa !29
  %t547 = getelementptr %"compiler/generic:Program", ptr %t545, i32 0, i32 0
  %t548 = load ptr, ptr %t547, !tbaa !29
  %t550 = getelementptr %"compiler/load:Loader", ptr %t548, i32 0, i32 4
  %t551 = load ptr, ptr %t550, !tbaa !29
  store ptr %t551, ptr %l295, !tbaa !29
  store i64 %t541, ptr %l296, !tbaa !24
  %t553 = load ptr, ptr %l0, !tbaa !29
  store ptr %t553, ptr %l297, !tbaa !29
  %t554 = load ptr, ptr %l0, !tbaa !29
  %t556 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t554)
  store ptr %t556, ptr %l299
  br label %bb111
bb111:
  %t557 = load ptr, ptr %l299, !tbaa !29
  %t559 = getelementptr %"compiler/typed:Body", ptr %t557, i32 0, i32 7
  %t560 = load i64, ptr %l24, !tbaa !24
  %t563 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t559, i64 %t560)
  store %"compiler/typed:Local" %t563, ptr %l303
  br label %bb112
bb112:
  %t564 = getelementptr %"compiler/typed:Local", ptr %l303, i32 0, i32 1
  %t565 = load %"compiler/source:Span", ptr %t564
  %t566 = load ptr, ptr %l297, !tbaa !29
  %t568 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t566, %"compiler/source:Span" %t565)
  store { i64, [3 x i64] } %t568, ptr %l305
  br label %bb113
bb113:
  %t569 = load ptr, ptr %l0, !tbaa !29
  %t570 = load ptr, ptr %l2, !tbaa !29
  %t572 = getelementptr %"compiler/ast:VarDecl", ptr %t570, i32 0, i32 0
  %t573 = load { i64, ptr }, ptr %t572, !tbaa !27
  store { i64, ptr } %t573, ptr %l308, !tbaa !27
  %t574 = load i64, ptr %l22, !tbaa !24
  %t576 = getelementptr { i64, ptr }, ptr %l308, i32 0, i32 1
  %t577 = load ptr, ptr %t576, !tbaa !27
  %t578 = getelementptr i32, ptr %t577, i64 %t574
  %t579 = load i32, ptr %t578, !tbaa !33
  %t582 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s16, ptr %t569, i32 %t579)
  store { i64, ptr } %t582, ptr %l311
  br label %bb114
bb114:
  %t583 = load { i64, ptr }, ptr %l311, !tbaa !27
  %t584 = extractvalue { i64, ptr } %t583, 0
  %t585 = extractvalue { i64, ptr } %t583, 1
  %t586 = mul i64 %t584, 1
  %t587 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t586)
  call void @llvm.memcpy.p0.p0.i64(ptr %t587, ptr %t585, i64 %t586, i1 false)
  %t588 = insertvalue { i64, ptr } undef, i64 %t584, 0
  %t589 = insertvalue { i64, ptr } %t588, ptr %t587, 1
  %t591 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteDeclaredHere(ptr %s16, ptr %s16, { i64, ptr } %t589)
  store %"compiler/msgs:Msg" %t591, ptr %l313
  br label %bb115
bb115:
  %t592 = load ptr, ptr %l295, !tbaa !29
  %t593 = load i64, ptr %l296, !tbaa !24
  %t594 = load { i64, [3 x i64] }, ptr %l305
  %t595 = load %"compiler/msgs:Msg", ptr %l313
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s16, ptr %t592, i64 %t593, { i64, [3 x i64] } %t594, %"compiler/msgs:Msg" %t595)
  br label %bb116
bb116:
  call void @__olang_scope_close(ptr %s16)
  br label %bb117
bb117:
  br label %bb118
bb118:
  %t596 = load i32, ptr %l12, !tbaa !23
  store i32 %t596, ptr %l26, !tbaa !23
  store ptr null, ptr %l27, !tbaa !29
  %t598 = load %"compiler/source:Span", ptr %l23
  %t599 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t602 = call %"compiler/check:unsetCand" @compiler_2fcheck_3aunsetCand_2ector(ptr %s14, i64 -1, i64 -1, i64 -1, i1 false, i64 -1, %"compiler/source:Span" %t598, i32 %t599, i1 false)
  store %"compiler/check:unsetCand" %t602, ptr %l317
  br label %bb119
bb119:
  %t603 = load %"compiler/check:unsetCand", ptr %l317
  store %"compiler/check:unsetCand" %t603, ptr %l28
  %t604 = load ptr, ptr %l0, !tbaa !29
  %t606 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t604)
  store ptr %t606, ptr %l319
  br label %bb120
bb120:
  %t607 = load ptr, ptr %l319, !tbaa !29
  %t609 = getelementptr %"compiler/check:frame", ptr %t607, i32 0, i32 41
  %t610 = load ptr, ptr %l2, !tbaa !29
  %t612 = getelementptr %"compiler/ast:VarDecl", ptr %t610, i32 0, i32 0
  %t613 = load { i64, ptr }, ptr %t612, !tbaa !27
  store { i64, ptr } %t613, ptr %l323, !tbaa !27
  %t614 = load i64, ptr %l22, !tbaa !24
  %t616 = getelementptr { i64, ptr }, ptr %l323, i32 0, i32 1
  %t617 = load ptr, ptr %t616, !tbaa !27
  %t618 = getelementptr i32, ptr %t617, i64 %t614
  %t619 = load i32, ptr %t618, !tbaa !33
  %t622 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %t609, i32 %t619)
  store i1 %t622, ptr %l326
  br label %bb121
bb121:
  %t623 = load i1, ptr %l326, !tbaa !21
  %t624 = xor i1 %t623, true
  store i1 %t624, ptr %l29, !tbaa !21
  %t626 = load i32, ptr %l12, !tbaa !23
  store i32 %t626, ptr %l30, !tbaa !23
  %t628 = load ptr, ptr %l2, !tbaa !29
  %t630 = getelementptr %"compiler/ast:VarDecl", ptr %t628, i32 0, i32 5
  %t631 = load i1, ptr %t630, !tbaa !21
  br i1 %t631, label %bb122, label %bb123
bb122:
  store i1 true, ptr %l29, !tbaa !21
  %t633 = load ptr, ptr %l0, !tbaa !29
  store ptr %t633, ptr %l331, !tbaa !29
  %t634 = load ptr, ptr %l0, !tbaa !29
  %t636 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t634)
  store ptr %t636, ptr %l333
  br label %bb124
bb123:
  %t637 = load i1, ptr %l29, !tbaa !21
  br i1 %t637, label %bb135, label %bb136
bb124:
  %t639 = load ptr, ptr %l333, !tbaa !29
  %t641 = getelementptr %"compiler/typed:Body", ptr %t639, i32 0, i32 10
  %t643 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t641)
  store i64 %t643, ptr %l336
  br label %bb125
bb125:
  %t644 = load ptr, ptr %l331, !tbaa !29
  %t645 = load i64, ptr %l336, !tbaa !24
  %t646 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efieldTypeAt(ptr %v0, ptr %t644, i64 %t645)
  store i32 %t646, ptr %l337
  br label %bb126
bb126:
  %t647 = load i32, ptr %l337, !tbaa !23
  store i32 %t647, ptr %l31, !tbaa !23
  %t648 = load ptr, ptr %l0, !tbaa !29
  %t650 = getelementptr %"compiler/check:Checker", ptr %t648, i32 0, i32 1
  %t651 = load ptr, ptr %t650, !tbaa !29
  %t653 = getelementptr %"compiler/generic:Program", ptr %t651, i32 0, i32 2
  %t654 = load i32, ptr %l31, !tbaa !23
  %t657 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t653, i32 %t654)
  store i32 %t657, ptr %l342
  br label %bb127
bb127:
  %t658 = load i32, ptr %l342, !range !{i32 0, i32 33}
  %t660 = trunc i64 19 to i32
  %t661 = icmp eq i32 %t658, %t660
  br i1 %t661, label %bb128, label %bb129
bb128:
  %t663 = load ptr, ptr %l0, !tbaa !29
  %t665 = getelementptr %"compiler/check:Checker", ptr %t663, i32 0, i32 1
  %t666 = load ptr, ptr %t665, !tbaa !29
  %t668 = getelementptr %"compiler/generic:Program", ptr %t666, i32 0, i32 2
  %t669 = load i32, ptr %l31, !tbaa !23
  %t672 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t668, i32 %t669)
  store i32 %t672, ptr %l350
  br label %bb130
bb129:
  store i1 false, ptr %l345, !tbaa !21
  br label %bb131
bb130:
  %t673 = load i32, ptr %l350, !tbaa !23
  %t674 = icmp ne i32 %t673, 0
  store i1 %t674, ptr %l345, !tbaa !21
  br label %bb131
bb131:
  %t676 = load i1, ptr %l345, !tbaa !21
  br i1 %t676, label %bb132, label %bb133
bb132:
  %t677 = load i32, ptr %l31, !tbaa !23
  store i32 %t677, ptr %l30, !tbaa !23
  %t679 = load i32, ptr %l31, !tbaa !23
  store i32 %t679, ptr %l26, !tbaa !23
  br label %bb134
bb133:
  br label %bb134
bb134:
  br label %bb149
bb135:
  %t681 = load ptr, ptr %l2, !tbaa !29
  %t683 = getelementptr %"compiler/ast:VarDecl", ptr %t681, i32 0, i32 2
  %t684 = load ptr, ptr %t683, !tbaa !29
  %t686 = icmp eq ptr %t684, null
  %t688 = xor i1 %t686, true
  store i1 %t688, ptr %l355, !tbaa !21
  br label %bb137
bb136:
  store i1 false, ptr %l355, !tbaa !21
  br label %bb137
bb137:
  %t690 = load i1, ptr %l355, !tbaa !21
  br i1 %t690, label %bb138, label %bb139
bb138:
  %t691 = load ptr, ptr %l2, !tbaa !29
  %t693 = getelementptr %"compiler/ast:VarDecl", ptr %t691, i32 0, i32 4
  %t694 = load i1, ptr %t693, !tbaa !21
  %t696 = xor i1 %t694, true
  store i1 %t696, ptr %l360, !tbaa !21
  br label %bb140
bb139:
  store i1 false, ptr %l360, !tbaa !21
  br label %bb140
bb140:
  %t698 = load i1, ptr %l360, !tbaa !21
  br i1 %t698, label %bb141, label %bb142
bb141:
  %t699 = load i64, ptr %l22, !tbaa !24
  %t700 = load ptr, ptr %l2, !tbaa !29
  %t702 = getelementptr %"compiler/ast:VarDecl", ptr %t700, i32 0, i32 3
  %t703 = load { i64, ptr }, ptr %t702, !tbaa !27
  %t705 = extractvalue { i64, ptr } %t703, 0
  %t708 = icmp slt i64 %t699, %t705
  store i1 %t708, ptr %l364, !tbaa !21
  br label %bb143
bb142:
  store i1 false, ptr %l364, !tbaa !21
  br label %bb143
bb143:
  %t710 = load i1, ptr %l364, !tbaa !21
  br i1 %t710, label %bb144, label %bb145
bb144:
  %t711 = load ptr, ptr %l0, !tbaa !29
  %t713 = getelementptr %"compiler/check:Checker", ptr %t711, i32 0, i32 1
  %t714 = load ptr, ptr %t713, !tbaa !29
  store ptr %t714, ptr %l371, !tbaa !29
  %t715 = load ptr, ptr %l0, !tbaa !29
  %t717 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t715)
  store ptr %t717, ptr %l373
  br label %bb146
bb145:
  br label %bb148
bb146:
  %t718 = load ptr, ptr %l373, !tbaa !29
  %t720 = getelementptr %"compiler/check:frame", ptr %t718, i32 0, i32 4
  %t721 = load i32, ptr %l12, !tbaa !23
  %t722 = load ptr, ptr %l2, !tbaa !29
  %t724 = getelementptr %"compiler/ast:VarDecl", ptr %t722, i32 0, i32 3
  %t725 = load { i64, ptr }, ptr %t724, !tbaa !27
  store { i64, ptr } %t725, ptr %l378, !tbaa !27
  %t726 = load i64, ptr %l22, !tbaa !24
  %t728 = getelementptr { i64, ptr }, ptr %l378, i32 0, i32 1
  %t729 = load ptr, ptr %t728, !tbaa !27
  %t730 = getelementptr ptr, ptr %t729, i64 %t726
  %t731 = load ptr, ptr %t730, !tbaa !39
  %t733 = load ptr, ptr %l371, !tbaa !29
  %t737 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eStorageOf(ptr %v0, ptr %v0, ptr %v1, ptr %t733, ptr %t720, i32 %t721, ptr %t731)
  store i32 %t737, ptr %l382
  br label %bb147
bb147:
  %t738 = load i32, ptr %l382, !tbaa !23
  store i32 %t738, ptr %l30, !tbaa !23
  %t739 = load i32, ptr %l30, !tbaa !23
  store i32 %t739, ptr %l26, !tbaa !23
  br label %bb148
bb148:
  br label %bb149
bb149:
  %t741 = load i1, ptr %l29, !tbaa !21
  br i1 %t741, label %bb150, label %bb151
bb150:
  %t743 = load i64, ptr %l22, !tbaa !24
  %t744 = load ptr, ptr %l2, !tbaa !29
  %t746 = getelementptr %"compiler/ast:VarDecl", ptr %t744, i32 0, i32 3
  %t747 = load { i64, ptr }, ptr %t746, !tbaa !27
  %t749 = extractvalue { i64, ptr } %t747, 0
  %t752 = icmp slt i64 %t743, %t749
  store i1 %t752, ptr %l385, !tbaa !21
  br label %bb152
bb151:
  store i1 false, ptr %l385, !tbaa !21
  br label %bb152
bb152:
  %t754 = load i1, ptr %l385, !tbaa !21
  br i1 %t754, label %bb153, label %bb154
bb153:
  %t755 = load ptr, ptr %l2, !tbaa !29
  %t757 = getelementptr %"compiler/ast:VarDecl", ptr %t755, i32 0, i32 5
  %t758 = load i1, ptr %t757, !tbaa !21
  %t760 = xor i1 %t758, true
  store i1 %t760, ptr %l391, !tbaa !21
  br label %bb155
bb154:
  store i1 false, ptr %l391, !tbaa !21
  br label %bb155
bb155:
  %t762 = load i1, ptr %l391, !tbaa !21
  br i1 %t762, label %bb156, label %bb157
bb156:
  %t763 = load ptr, ptr %l2, !tbaa !29
  %t765 = getelementptr %"compiler/ast:VarDecl", ptr %t763, i32 0, i32 2
  %t766 = load ptr, ptr %t765, !tbaa !29
  %t768 = icmp eq ptr %t766, null
  %t770 = xor i1 %t768, true
  store i1 %t770, ptr %l395, !tbaa !21
  br label %bb158
bb157:
  store i1 false, ptr %l395, !tbaa !21
  br label %bb158
bb158:
  %t772 = load i1, ptr %l395, !tbaa !21
  br i1 %t772, label %bb159, label %bb160
bb159:
  %t773 = load ptr, ptr %l2, !tbaa !29
  %t775 = getelementptr %"compiler/ast:VarDecl", ptr %t773, i32 0, i32 4
  %t776 = load i1, ptr %t775, !tbaa !21
  %t778 = xor i1 %t776, true
  store i1 %t778, ptr %l400, !tbaa !21
  br label %bb161
bb160:
  store i1 false, ptr %l400, !tbaa !21
  br label %bb161
bb161:
  %t780 = load i1, ptr %l400, !tbaa !21
  br i1 %t780, label %bb162, label %bb163
bb162:
  %t781 = load ptr, ptr %l0, !tbaa !29
  %t783 = getelementptr %"compiler/check:Checker", ptr %t781, i32 0, i32 1
  %t784 = load ptr, ptr %t783, !tbaa !29
  %t786 = getelementptr %"compiler/generic:Program", ptr %t784, i32 0, i32 2
  %t787 = load i32, ptr %l30, !tbaa !23
  %t790 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t786, i32 %t787)
  store i32 %t790, ptr %l409
  br label %bb164
bb163:
  store i1 false, ptr %l404, !tbaa !21
  br label %bb165
bb164:
  %t791 = load i32, ptr %l409, !range !{i32 0, i32 33}
  %t793 = trunc i64 19 to i32
  %t794 = icmp eq i32 %t791, %t793
  store i1 %t794, ptr %l404, !tbaa !21
  br label %bb165
bb165:
  %t796 = load i1, ptr %l404, !tbaa !21
  br i1 %t796, label %bb166, label %bb167
bb166:
  %t797 = load ptr, ptr %l0, !tbaa !29
  store ptr %t797, ptr %l413, !tbaa !29
  %t798 = load ptr, ptr %l0, !tbaa !29
  %t800 = getelementptr %"compiler/check:Checker", ptr %t798, i32 0, i32 1
  %t801 = load ptr, ptr %t800, !tbaa !29
  %t803 = getelementptr %"compiler/generic:Program", ptr %t801, i32 0, i32 2
  %t804 = load i32, ptr %l30, !tbaa !23
  %t807 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t803, i32 %t804)
  store i32 %t807, ptr %l418
  br label %bb168
bb167:
  store i1 false, ptr %l412, !tbaa !21
  br label %bb170
bb168:
  %t808 = load ptr, ptr %l413, !tbaa !29
  %t809 = load i32, ptr %l418, !tbaa !23
  %t810 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunArrayValue(ptr %v0, ptr %t808, i32 %t809)
  store i1 %t810, ptr %l419
  br label %bb169
bb169:
  %t811 = load i1, ptr %l419, !tbaa !21
  store i1 %t811, ptr %l412, !tbaa !21
  br label %bb170
bb170:
  %t812 = load i1, ptr %l412, !tbaa !21
  br i1 %t812, label %bb171, label %bb172
bb171:
  %t813 = load ptr, ptr %l0, !tbaa !29
  %t814 = load ptr, ptr %l2, !tbaa !29
  %t816 = getelementptr %"compiler/ast:VarDecl", ptr %t814, i32 0, i32 3
  %t817 = load { i64, ptr }, ptr %t816, !tbaa !27
  store { i64, ptr } %t817, ptr %l422, !tbaa !27
  %t818 = load i64, ptr %l22, !tbaa !24
  %t820 = getelementptr { i64, ptr }, ptr %l422, i32 0, i32 1
  %t821 = load ptr, ptr %t820, !tbaa !27
  %t822 = getelementptr ptr, ptr %t821, i64 %t818
  %t823 = load ptr, ptr %t822, !tbaa !39
  %t825 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t829 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v0, ptr %t813, ptr %t823, i32 %t825)
  store ptr %t829, ptr %l427
  br label %bb173
bb172:
  %t830 = load i64, ptr %l22, !tbaa !24
  %t831 = load ptr, ptr %l2, !tbaa !29
  %t833 = getelementptr %"compiler/ast:VarDecl", ptr %t831, i32 0, i32 3
  %t834 = load { i64, ptr }, ptr %t833, !tbaa !27
  %t836 = extractvalue { i64, ptr } %t834, 0
  %t839 = icmp slt i64 %t830, %t836
  br i1 %t839, label %bb190, label %bb191
bb173:
  %t841 = load ptr, ptr %l427, !tbaa !29
  store ptr %t841, ptr %l27, !tbaa !29
  %t843 = load ptr, ptr %l0, !tbaa !29
  %t845 = getelementptr %"compiler/check:Checker", ptr %t843, i32 0, i32 1
  %t846 = load ptr, ptr %t845, !tbaa !29
  store ptr %t846, ptr %l430, !tbaa !29
  %t847 = load ptr, ptr %l27, !tbaa !29
  %t849 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t847)
  store i32 %t849, ptr %l432
  br label %bb174
bb174:
  %t850 = load i32, ptr %l30, !tbaa !23
  %t851 = load ptr, ptr %l430, !tbaa !29
  %t852 = load i32, ptr %l432, !tbaa !23
  %t854 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLengthsOnly(ptr %v0, ptr %t851, i32 %t852, i32 %t850)
  store i1 %t854, ptr %l434
  br label %bb175
bb175:
  %t855 = load i1, ptr %l434, !tbaa !21
  br i1 %t855, label %bb176, label %bb177
bb176:
  %t856 = load ptr, ptr %l0, !tbaa !29
  %t858 = getelementptr %"compiler/check:Checker", ptr %t856, i32 0, i32 1
  %t859 = load ptr, ptr %t858, !tbaa !29
  %t861 = getelementptr %"compiler/generic:Program", ptr %t859, i32 0, i32 2
  store ptr %t861, ptr %l438, !tbaa !29
  %t862 = load ptr, ptr %l27, !tbaa !29
  %t864 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t862)
  store i32 %t864, ptr %l440
  br label %bb178
bb177:
  store i1 false, ptr %l435, !tbaa !21
  br label %bb180
bb178:
  %t865 = load ptr, ptr %l438, !tbaa !29
  %t866 = load i32, ptr %l440, !tbaa !23
  %t867 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t865, i32 %t866)
  store i32 %t867, ptr %l441
  br label %bb179
bb179:
  %t868 = load i32, ptr %l441, !range !{i32 0, i32 33}
  %t870 = trunc i64 19 to i32
  %t871 = icmp eq i32 %t868, %t870
  store i1 %t871, ptr %l435, !tbaa !21
  br label %bb180
bb180:
  %t873 = load i1, ptr %l435, !tbaa !21
  br i1 %t873, label %bb181, label %bb182
bb181:
  %t874 = load ptr, ptr %l27, !tbaa !29
  %t876 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t874)
  store i32 %t876, ptr %l445
  br label %bb183
bb182:
  %t877 = load ptr, ptr %l0, !tbaa !29
  store ptr %t877, ptr %l446, !tbaa !29
  %t878 = load ptr, ptr %l27, !tbaa !29
  %t880 = icmp eq ptr %t878, null
  br i1 %t880, label %bb184, label %bb185
bb183:
  %t882 = load i32, ptr %l445, !tbaa !23
  store i32 %t882, ptr %l26, !tbaa !23
  br label %bb189
bb184:
  call void @__olang_check_failed(ptr @olang_loc_458efae6ce1c735_ac6225d3d907fb69)
  unreachable
bb185:
  br label %bb186
bb186:
  %t883 = load ptr, ptr %l27, !tbaa !29
  store ptr %t883, ptr %l449, !tbaa !29
  %t884 = load i32, ptr %l30, !tbaa !23
  store i32 %t884, ptr %l450, !tbaa !23
  %t885 = load ptr, ptr %l2, !tbaa !29
  %t887 = getelementptr %"compiler/ast:VarDecl", ptr %t885, i32 0, i32 3
  %t888 = load { i64, ptr }, ptr %t887, !tbaa !27
  store { i64, ptr } %t888, ptr %l452, !tbaa !27
  %t889 = load i64, ptr %l22, !tbaa !24
  %t891 = getelementptr { i64, ptr }, ptr %l452, i32 0, i32 1
  %t892 = load ptr, ptr %t891, !tbaa !27
  %t893 = getelementptr ptr, ptr %t892, i64 %t889
  %t894 = load ptr, ptr %t893, !tbaa !39
  %t896 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t894)
  store %"compiler/source:Span" %t896, ptr %l455
  br label %bb187
bb187:
  %t897 = load ptr, ptr %l446, !tbaa !29
  %t898 = load ptr, ptr %l449, !tbaa !29
  %t899 = load i32, ptr %l450, !tbaa !23
  %t900 = load %"compiler/source:Span", ptr %l455
  %t901 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v0, ptr %v0, ptr %t897, ptr %t898, i32 %t899, %"compiler/source:Span" %t900)
  store ptr %t901, ptr %l456
  br label %bb188
bb188:
  %t902 = load ptr, ptr %l456, !tbaa !29
  store ptr %t902, ptr %l27, !tbaa !29
  br label %bb189
bb189:
  br label %bb273
bb190:
  %t904 = load ptr, ptr %l0, !tbaa !29
  %t906 = getelementptr %"compiler/check:Checker", ptr %t904, i32 0, i32 13
  %t907 = load { i64, [3 x i64] }, ptr %t906
  store { i64, [3 x i64] } %t907, ptr %l32
  %t909 = load ptr, ptr %l2, !tbaa !29
  %t911 = getelementptr %"compiler/ast:VarDecl", ptr %t909, i32 0, i32 2
  %t912 = load ptr, ptr %t911, !tbaa !29
  %t914 = icmp eq ptr %t912, null
  %t916 = xor i1 %t914, true
  br i1 %t916, label %bb192, label %bb193
bb191:
  store %olang.scope zeroinitializer, ptr %s31
  %t918 = load ptr, ptr %l0, !tbaa !29
  %t920 = getelementptr %"compiler/check:Checker", ptr %t918, i32 0, i32 13
  %t921 = load { i64, [3 x i64] }, ptr %t920
  store { i64, [3 x i64] } %t921, ptr %l35
  %t923 = load ptr, ptr %l0, !tbaa !29
  store ptr %t923, ptr %l586, !tbaa !29
  %t924 = load ptr, ptr %l0, !tbaa !29
  store ptr %t924, ptr %l587, !tbaa !29
  %t925 = load ptr, ptr %l2, !tbaa !29
  %t927 = getelementptr %"compiler/ast:VarDecl", ptr %t925, i32 0, i32 2
  %t928 = load ptr, ptr %t927, !tbaa !29
  %t930 = icmp eq ptr %t928, null
  br i1 %t930, label %bb251, label %bb252
bb192:
  %t932 = load ptr, ptr %l2, !tbaa !29
  %t934 = getelementptr %"compiler/ast:VarDecl", ptr %t932, i32 0, i32 4
  %t935 = load i1, ptr %t934, !tbaa !21
  %t937 = xor i1 %t935, true
  store i1 %t937, ptr %l469, !tbaa !21
  br label %bb194
bb193:
  store i1 false, ptr %l469, !tbaa !21
  br label %bb194
bb194:
  %t939 = load i1, ptr %l469, !tbaa !21
  br i1 %t939, label %bb195, label %bb196
bb195:
  %t940 = load ptr, ptr %l0, !tbaa !29
  store ptr %t940, ptr %l473, !tbaa !29
  %t941 = load ptr, ptr %l0, !tbaa !29
  store ptr %t941, ptr %l474, !tbaa !29
  %t942 = load ptr, ptr %l2, !tbaa !29
  %t944 = getelementptr %"compiler/ast:VarDecl", ptr %t942, i32 0, i32 2
  %t945 = load ptr, ptr %t944, !tbaa !29
  %t947 = icmp eq ptr %t945, null
  br i1 %t947, label %bb197, label %bb198
bb196:
  br label %bb201
bb197:
  call void @__olang_check_failed(ptr @olang_loc_f3c73b72e55a8b8e_5460cc7526c67482)
  unreachable
bb198:
  br label %bb199
bb199:
  %t949 = load ptr, ptr %l2, !tbaa !29
  %t951 = getelementptr %"compiler/ast:VarDecl", ptr %t949, i32 0, i32 2
  %t952 = load ptr, ptr %t951, !tbaa !29
  %t953 = load ptr, ptr %l474, !tbaa !29
  %t955 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeWrittenAt(ptr %v0, ptr %v1, ptr %t953, ptr %t952)
  store { i64, [3 x i64] } %t955, ptr %l480
  br label %bb200
bb200:
  %t956 = load { i64, [3 x i64] }, ptr %l480
  %t957 = load ptr, ptr %l473, !tbaa !29
  %t958 = getelementptr %"compiler/check:Checker", ptr %t957, i32 0, i32 13
  store { i64, [3 x i64] } %t956, ptr %t958
  br label %bb201
bb201:
  %t959 = load ptr, ptr %l2, !tbaa !29
  %t961 = getelementptr %"compiler/ast:VarDecl", ptr %t959, i32 0, i32 5
  %t962 = load i1, ptr %t961, !tbaa !21
  %t964 = xor i1 %t962, true
  br i1 %t964, label %bb202, label %bb203
bb202:
  %t966 = load ptr, ptr %l2, !tbaa !29
  %t968 = getelementptr %"compiler/ast:VarDecl", ptr %t966, i32 0, i32 0
  %t969 = load { i64, ptr }, ptr %t968, !tbaa !27
  %t971 = extractvalue { i64, ptr } %t969, 0
  %t973 = icmp eq i64 %t971, 1
  store i1 %t973, ptr %l484, !tbaa !21
  br label %bb204
bb203:
  store i1 false, ptr %l484, !tbaa !21
  br label %bb204
bb204:
  %t975 = load i1, ptr %l484, !tbaa !21
  br i1 %t975, label %bb205, label %bb206
bb205:
  %t976 = load ptr, ptr %l0, !tbaa !29
  %t977 = load ptr, ptr %l2, !tbaa !29
  %t979 = getelementptr %"compiler/ast:VarDecl", ptr %t977, i32 0, i32 0
  %t980 = load { i64, ptr }, ptr %t979, !tbaa !27
  store { i64, ptr } %t980, ptr %l492, !tbaa !27
  %t981 = load i64, ptr %l22, !tbaa !24
  %t983 = getelementptr { i64, ptr }, ptr %l492, i32 0, i32 1
  %t984 = load ptr, ptr %t983, !tbaa !27
  %t985 = getelementptr i32, ptr %t984, i64 %t981
  %t986 = load i32, ptr %t985, !tbaa !33
  %t987 = load ptr, ptr %l2, !tbaa !29
  %t989 = getelementptr %"compiler/ast:VarDecl", ptr %t987, i32 0, i32 3
  %t990 = load { i64, ptr }, ptr %t989, !tbaa !27
  store { i64, ptr } %t990, ptr %l496, !tbaa !27
  %t991 = load i64, ptr %l22, !tbaa !24
  %t993 = getelementptr { i64, ptr }, ptr %l496, i32 0, i32 1
  %t994 = load ptr, ptr %t993, !tbaa !27
  %t995 = getelementptr ptr, ptr %t994, i64 %t991
  %t996 = load ptr, ptr %t995, !tbaa !39
  %t1000 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efilledNext(ptr %v0, ptr %v1, ptr %t976, i32 %t986, ptr %t996)
  store i1 %t1000, ptr %l499
  br label %bb207
bb206:
  store i1 false, ptr %l489, !tbaa !21
  br label %bb208
bb207:
  %t1001 = load i1, ptr %l499, !tbaa !21
  store i1 %t1001, ptr %l489, !tbaa !21
  br label %bb208
bb208:
  %t1002 = load i1, ptr %l489, !tbaa !21
  %t1003 = load ptr, ptr %l0, !tbaa !29
  %t1007 = getelementptr %"compiler/check:Checker", ptr %t1003, i32 0, i32 104
  store i1 %t1002, ptr %t1007, !tbaa !21
  %t1008 = load ptr, ptr %l0, !tbaa !29
  %t1009 = load ptr, ptr %l2, !tbaa !29
  %t1011 = getelementptr %"compiler/ast:VarDecl", ptr %t1009, i32 0, i32 3
  %t1012 = load { i64, ptr }, ptr %t1011, !tbaa !27
  store { i64, ptr } %t1012, ptr %l504, !tbaa !27
  %t1013 = load i64, ptr %l22, !tbaa !24
  %t1015 = getelementptr { i64, ptr }, ptr %l504, i32 0, i32 1
  %t1016 = load ptr, ptr %t1015, !tbaa !27
  %t1017 = getelementptr ptr, ptr %t1016, i64 %t1013
  %t1018 = load ptr, ptr %t1017, !tbaa !39
  %t1019 = load i32, ptr %l30, !tbaa !23
  %t1023 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %v0, ptr %t1008, ptr %t1018, i32 %t1019)
  store ptr %t1023, ptr %l508
  br label %bb209
bb209:
  %t1024 = load ptr, ptr %l508, !tbaa !29
  store ptr %t1024, ptr %l27, !tbaa !29
  %t1026 = load ptr, ptr %l0, !tbaa !29
  %t1028 = getelementptr %"compiler/check:Checker", ptr %t1026, i32 0, i32 104
  store i1 false, ptr %t1028, !tbaa !21
  %t1029 = load ptr, ptr %l0, !tbaa !29
  %t1030 = load { i64, [3 x i64] }, ptr %l32
  %t1033 = getelementptr %"compiler/check:Checker", ptr %t1029, i32 0, i32 13
  store { i64, [3 x i64] } %t1030, ptr %t1033
  %t1034 = load ptr, ptr %l2, !tbaa !29
  %t1036 = getelementptr %"compiler/ast:VarDecl", ptr %t1034, i32 0, i32 2
  %t1037 = load ptr, ptr %t1036, !tbaa !29
  %t1039 = icmp eq ptr %t1037, null
  br i1 %t1039, label %bb210, label %bb211
bb210:
  store i1 true, ptr %l516, !tbaa !21
  br label %bb212
bb211:
  %t1041 = load ptr, ptr %l2, !tbaa !29
  %t1043 = getelementptr %"compiler/ast:VarDecl", ptr %t1041, i32 0, i32 4
  %t1044 = load i1, ptr %t1043, !tbaa !21
  store i1 %t1044, ptr %l516, !tbaa !21
  br label %bb212
bb212:
  %t1046 = load i1, ptr %l516, !tbaa !21
  br i1 %t1046, label %bb213, label %bb214
bb213:
  %t1047 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1047, ptr %l519, !tbaa !29
  %t1048 = load ptr, ptr %l2, !tbaa !29
  %t1050 = getelementptr %"compiler/ast:VarDecl", ptr %t1048, i32 0, i32 3
  %t1051 = load { i64, ptr }, ptr %t1050, !tbaa !27
  store { i64, ptr } %t1051, ptr %l521, !tbaa !27
  %t1052 = load i64, ptr %l22, !tbaa !24
  %t1054 = getelementptr { i64, ptr }, ptr %l521, i32 0, i32 1
  %t1055 = load ptr, ptr %t1054, !tbaa !27
  %t1056 = getelementptr ptr, ptr %t1055, i64 %t1052
  %t1057 = load ptr, ptr %t1056, !tbaa !39
  store ptr %t1057, ptr %l523, !tbaa !29
  %t1058 = load ptr, ptr %l27, !tbaa !29
  %t1060 = icmp eq ptr %t1058, null
  br i1 %t1060, label %bb215, label %bb216
bb214:
  br label %bb250
bb215:
  call void @__olang_check_failed(ptr @olang_loc_de90e7498c4216b3_b17be322d1a772cf)
  unreachable
bb216:
  br label %bb217
bb217:
  %t1062 = load ptr, ptr %l27, !tbaa !29
  %t1063 = load i1, ptr %l29, !tbaa !21
  %t1064 = load ptr, ptr %l519, !tbaa !29
  %t1065 = load ptr, ptr %l523, !tbaa !29
  %t1068 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einferred(ptr %v0, ptr %v1, ptr %v0, ptr %t1064, ptr %t1065, ptr %t1062, i1 %t1063)
  store i32 %t1068, ptr %l528
  br label %bb218
bb218:
  %t1069 = load i32, ptr %l528, !tbaa !23
  store i32 %t1069, ptr %l26, !tbaa !23
  %t1070 = load ptr, ptr %l2, !tbaa !29
  %t1072 = getelementptr %"compiler/ast:VarDecl", ptr %t1070, i32 0, i32 5
  %t1073 = load i1, ptr %t1072, !tbaa !21
  br i1 %t1073, label %bb219, label %bb220
bb219:
  %t1075 = load ptr, ptr %l2, !tbaa !29
  %t1077 = getelementptr %"compiler/ast:VarDecl", ptr %t1075, i32 0, i32 2
  %t1078 = load ptr, ptr %t1077, !tbaa !29
  %t1080 = icmp eq ptr %t1078, null
  %t1082 = xor i1 %t1080, true
  store i1 %t1082, ptr %l531, !tbaa !21
  br label %bb221
bb220:
  store i1 false, ptr %l531, !tbaa !21
  br label %bb221
bb221:
  %t1084 = load i1, ptr %l531, !tbaa !21
  br i1 %t1084, label %bb222, label %bb223
bb222:
  %t1085 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1085, ptr %l536, !tbaa !29
  %t1086 = load ptr, ptr %l2, !tbaa !29
  %t1088 = getelementptr %"compiler/ast:VarDecl", ptr %t1086, i32 0, i32 2
  %t1089 = load ptr, ptr %t1088, !tbaa !29
  %t1091 = icmp eq ptr %t1089, null
  br i1 %t1091, label %bb224, label %bb225
bb223:
  br label %bb234
bb224:
  call void @__olang_check_failed(ptr @olang_loc_36f1ca435b2ee6e4_790f65bce77245f0)
  unreachable
bb225:
  br label %bb226
bb226:
  %t1093 = load ptr, ptr %l2, !tbaa !29
  %t1095 = getelementptr %"compiler/ast:VarDecl", ptr %t1093, i32 0, i32 2
  %t1096 = load ptr, ptr %t1095, !tbaa !29
  %t1097 = load i32, ptr %l26, !tbaa !23
  %t1098 = load ptr, ptr %l536, !tbaa !29
  %t1101 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emutBefore(ptr %v0, ptr %v1, ptr %t1098, ptr %t1096, i32 %t1097)
  store %"compiler/source:Span" %t1101, ptr %l543
  br label %bb227
bb227:
  %t1102 = load %"compiler/source:Span", ptr %l543
  store %"compiler/source:Span" %t1102, ptr %l34
  %t1103 = getelementptr %"compiler/source:Span", ptr %l34, i32 0, i32 0
  %t1104 = load i32, ptr %t1103, !tbaa !23
  %t1106 = icmp sge i32 %t1104, 0
  br i1 %t1106, label %bb228, label %bb229
bb228:
  store %olang.scope zeroinitializer, ptr %s29
  %t1108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1108, ptr %l546, !tbaa !29
  %t1109 = load %"compiler/source:Span", ptr %l34
  store %"compiler/source:Span" %t1109, ptr %l547
  %t1110 = load ptr, ptr %l0, !tbaa !29
  %t1111 = load i32, ptr %l26, !tbaa !23
  %t1114 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s29, ptr %t1110, i32 %t1111)
  store { i64, ptr } %t1114, ptr %l550
  br label %bb230
bb229:
  br label %bb233
bb230:
  %t1115 = load { i64, ptr }, ptr %l550, !tbaa !27
  %t1116 = extractvalue { i64, ptr } %t1115, 0
  %t1117 = extractvalue { i64, ptr } %t1115, 1
  %t1118 = mul i64 %t1116, 1
  %t1119 = call ptr @__olang_scope_alloc(ptr %s29, i64 %t1118)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1119, ptr %t1117, i64 %t1118, i1 false)
  %t1120 = insertvalue { i64, ptr } undef, i64 %t1116, 0
  %t1121 = insertvalue { i64, ptr } %t1120, ptr %t1119, 1
  %t1123 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eMutOnValueField(ptr %s29, ptr %s29, { i64, ptr } %t1121)
  store %"compiler/msgs:Msg" %t1123, ptr %l552
  br label %bb231
bb231:
  %t1124 = load ptr, ptr %l546, !tbaa !29
  %t1125 = load %"compiler/source:Span", ptr %l547
  %t1126 = load %"compiler/msgs:Msg", ptr %l552
  %t1127 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s29, ptr %t1124, %"compiler/source:Span" %t1125, %"compiler/msgs:Msg" %t1126)
  store i64 %t1127, ptr %l553
  br label %bb232
bb232:
  call void @__olang_scope_close(ptr %s29)
  br label %bb233
bb233:
  br label %bb234
bb234:
  %t1128 = load ptr, ptr %l0, !tbaa !29
  %t1130 = getelementptr %"compiler/check:Checker", ptr %t1128, i32 0, i32 1
  %t1131 = load ptr, ptr %t1130, !tbaa !29
  %t1133 = getelementptr %"compiler/generic:Program", ptr %t1131, i32 0, i32 2
  store ptr %t1133, ptr %l556, !tbaa !29
  %t1134 = load ptr, ptr %l0, !tbaa !29
  %t1135 = load i32, ptr %l26, !tbaa !23
  %t1138 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t1134, i32 %t1135)
  store i32 %t1138, ptr %l559
  br label %bb235
bb235:
  %t1139 = load ptr, ptr %l556, !tbaa !29
  %t1140 = load i32, ptr %l559, !tbaa !23
  %t1141 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1139, i32 %t1140)
  store i32 %t1141, ptr %l560
  br label %bb236
bb236:
  %t1142 = load i32, ptr %l560, !range !{i32 0, i32 33}
  %t1144 = trunc i64 19 to i32
  %t1145 = icmp eq i32 %t1142, %t1144
  br i1 %t1145, label %bb237, label %bb238
bb237:
  %t1147 = load ptr, ptr %l0, !tbaa !29
  %t1149 = getelementptr %"compiler/check:Checker", ptr %t1147, i32 0, i32 1
  %t1150 = load ptr, ptr %t1149, !tbaa !29
  %t1152 = getelementptr %"compiler/generic:Program", ptr %t1150, i32 0, i32 2
  store ptr %t1152, ptr %l566, !tbaa !29
  %t1153 = load i32, ptr %l26, !tbaa !23
  store i32 %t1153, ptr %l567, !tbaa !23
  %t1154 = load ptr, ptr %l27, !tbaa !29
  %t1156 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t1154)
  store i32 %t1156, ptr %l569
  br label %bb239
bb238:
  store i1 false, ptr %l563, !tbaa !21
  br label %bb241
bb239:
  %t1157 = load ptr, ptr %l566, !tbaa !29
  %t1158 = load i32, ptr %l567, !tbaa !23
  %t1159 = load i32, ptr %l569, !tbaa !23
  %t1160 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t1157, i32 %t1158, i32 %t1159)
  store i1 %t1160, ptr %l570
  br label %bb240
bb240:
  %t1161 = load i1, ptr %l570, !tbaa !21
  %t1162 = xor i1 %t1161, true
  store i1 %t1162, ptr %l563, !tbaa !21
  br label %bb241
bb241:
  %t1164 = load i1, ptr %l563, !tbaa !21
  br i1 %t1164, label %bb242, label %bb243
bb242:
  %t1165 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1165, ptr %l572, !tbaa !29
  %t1166 = load ptr, ptr %l27, !tbaa !29
  %t1168 = icmp eq ptr %t1166, null
  br i1 %t1168, label %bb244, label %bb245
bb243:
  br label %bb249
bb244:
  call void @__olang_check_failed(ptr @olang_loc_f2aff2ea660e9d99_96029929a029dd45)
  unreachable
bb245:
  br label %bb246
bb246:
  %t1170 = load ptr, ptr %l27, !tbaa !29
  store ptr %t1170, ptr %l575, !tbaa !29
  %t1171 = load i32, ptr %l26, !tbaa !23
  store i32 %t1171, ptr %l576, !tbaa !23
  %t1172 = load ptr, ptr %l2, !tbaa !29
  %t1174 = getelementptr %"compiler/ast:VarDecl", ptr %t1172, i32 0, i32 3
  %t1175 = load { i64, ptr }, ptr %t1174, !tbaa !27
  store { i64, ptr } %t1175, ptr %l578, !tbaa !27
  %t1176 = load i64, ptr %l22, !tbaa !24
  %t1178 = getelementptr { i64, ptr }, ptr %l578, i32 0, i32 1
  %t1179 = load ptr, ptr %t1178, !tbaa !27
  %t1180 = getelementptr ptr, ptr %t1179, i64 %t1176
  %t1181 = load ptr, ptr %t1180, !tbaa !39
  %t1183 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t1181)
  store %"compiler/source:Span" %t1183, ptr %l581
  br label %bb247
bb247:
  %t1184 = load ptr, ptr %l572, !tbaa !29
  %t1185 = load ptr, ptr %l575, !tbaa !29
  %t1186 = load i32, ptr %l576, !tbaa !23
  %t1187 = load %"compiler/source:Span", ptr %l581
  %t1188 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v0, ptr %v0, ptr %t1184, ptr %t1185, i32 %t1186, %"compiler/source:Span" %t1187)
  store ptr %t1188, ptr %l582
  br label %bb248
bb248:
  %t1189 = load ptr, ptr %l582, !tbaa !29
  store ptr %t1189, ptr %l27, !tbaa !29
  br label %bb249
bb249:
  br label %bb250
bb250:
  br label %bb272
bb251:
  call void @__olang_check_failed(ptr @olang_loc_91617ece661d0672_429c03ea7d9d989e)
  unreachable
bb252:
  br label %bb253
bb253:
  %t1191 = load ptr, ptr %l2, !tbaa !29
  %t1193 = getelementptr %"compiler/ast:VarDecl", ptr %t1191, i32 0, i32 2
  %t1194 = load ptr, ptr %t1193, !tbaa !29
  %t1195 = load ptr, ptr %l587, !tbaa !29
  %t1197 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeWrittenAt(ptr %v0, ptr %v1, ptr %t1195, ptr %t1194)
  store { i64, [3 x i64] } %t1197, ptr %l593
  br label %bb254
bb254:
  %t1198 = load { i64, [3 x i64] }, ptr %l593
  %t1199 = load ptr, ptr %l586, !tbaa !29
  %t1200 = getelementptr %"compiler/check:Checker", ptr %t1199, i32 0, i32 13
  store { i64, [3 x i64] } %t1198, ptr %t1200
  %t1201 = load ptr, ptr %l0, !tbaa !29
  %t1203 = getelementptr %"compiler/check:Checker", ptr %t1201, i32 0, i32 1
  %t1204 = load ptr, ptr %t1203, !tbaa !29
  %t1206 = getelementptr %"compiler/generic:Program", ptr %t1204, i32 0, i32 0
  %t1207 = load ptr, ptr %t1206, !tbaa !29
  %t1209 = getelementptr %"compiler/load:Loader", ptr %t1207, i32 0, i32 4
  %t1210 = load ptr, ptr %t1209, !tbaa !29
  store ptr %t1210, ptr %l36, !tbaa !29
  %t1212 = load ptr, ptr %l36, !tbaa !29
  %t1214 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHold(ptr %v0, ptr %t1212)
  store i64 %t1214, ptr %l599
  br label %bb255
bb255:
  %t1215 = load i64, ptr %l599, !tbaa !24
  store i64 %t1215, ptr %l37, !tbaa !24
  %t1216 = load ptr, ptr %l36, !tbaa !29
  %t1218 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t1216)
  store i64 %t1218, ptr %l601
  br label %bb256
bb256:
  %t1219 = load i64, ptr %l601, !tbaa !24
  store i64 %t1219, ptr %l38, !tbaa !24
  %t1220 = load ptr, ptr %l0, !tbaa !29
  %t1221 = load %"compiler/source:Span", ptr %l23
  %t1222 = load i32, ptr %l26, !tbaa !23
  %t1226 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezero(ptr %v0, ptr %v0, ptr %t1220, %"compiler/source:Span" %t1221, i32 %t1222)
  store ptr %t1226, ptr %l605
  br label %bb257
bb257:
  %t1227 = load ptr, ptr %l605, !tbaa !29
  store ptr %t1227, ptr %l27, !tbaa !29
  %t1229 = load ptr, ptr %l36, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %t1229)
  br label %bb258
bb258:
  %t1231 = load ptr, ptr %l36, !tbaa !29
  %t1233 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t1231)
  store i64 %t1233, ptr %l609
  br label %bb259
bb259:
  %t1234 = load i64, ptr %l38, !tbaa !24
  %t1235 = load i64, ptr %l609, !tbaa !24
  %t1237 = icmp sgt i64 %t1235, %t1234
  store i1 %t1237, ptr %l39, !tbaa !21
  %t1239 = load i1, ptr %l39, !tbaa !21
  br i1 %t1239, label %bb260, label %bb261
bb260:
  %t1241 = load ptr, ptr %l0, !tbaa !29
  %t1242 = load %"compiler/source:Span", ptr %l23
  %t1243 = load i32, ptr %l26, !tbaa !23
  %t1247 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t1241, %"compiler/source:Span" %t1242, i32 %t1243, i64 0)
  store ptr %t1247, ptr %l616
  br label %bb262
bb261:
  br label %bb263
bb262:
  %t1248 = load ptr, ptr %l616, !tbaa !29
  store ptr %t1248, ptr %l27, !tbaa !29
  br label %bb263
bb263:
  %t1250 = load ptr, ptr %l0, !tbaa !29
  %t1251 = load { i64, [3 x i64] }, ptr %l35
  %t1254 = getelementptr %"compiler/check:Checker", ptr %t1250, i32 0, i32 13
  store { i64, [3 x i64] } %t1251, ptr %t1254
  %t1255 = load ptr, ptr %l0, !tbaa !29
  %t1257 = getelementptr %"compiler/check:Checker", ptr %t1255, i32 0, i32 90
  %t1259 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aValueAsk_3e_2eLen_3ccompiler_2fcheck_3aValueAsk_3e(ptr %v0, ptr %t1257)
  store i64 %t1259, ptr %l622
  br label %bb264
bb264:
  %t1260 = load i64, ptr %l622, !tbaa !24
  store i64 %t1260, ptr %l40, !tbaa !24
  %t1261 = load ptr, ptr %l0, !tbaa !29
  %t1262 = load %"compiler/source:Span", ptr %l23
  %t1263 = load i32, ptr %l26, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2easkValue(ptr %v0, ptr %v0, ptr %t1261, i32 1, %"compiler/source:Span" %t1262, i32 %t1263, ptr null)
  br label %bb265
bb265:
  %t1268 = load ptr, ptr %l0, !tbaa !29
  %t1270 = getelementptr %"compiler/check:Checker", ptr %t1268, i32 0, i32 90
  %t1272 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aValueAsk_3e_2eLen_3ccompiler_2fcheck_3aValueAsk_3e(ptr %v0, ptr %t1270)
  store i64 %t1272, ptr %l629
  br label %bb266
bb266:
  %t1273 = load i64, ptr %l40, !tbaa !24
  %t1274 = load i64, ptr %l629, !tbaa !24
  %t1276 = icmp eq i64 %t1274, %t1273
  br i1 %t1276, label %bb267, label %bb268
bb267:
  store i64 -1, ptr %l40, !tbaa !24
  br label %bb269
bb268:
  br label %bb269
bb269:
  %t1278 = load ptr, ptr %l0, !tbaa !29
  %t1280 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1278)
  store ptr %t1280, ptr %l633
  br label %bb270
bb270:
  %t1281 = load ptr, ptr %l633, !tbaa !29
  %t1283 = getelementptr %"compiler/check:frame", ptr %t1281, i32 0, i32 0
  %t1284 = load i64, ptr %t1283, !tbaa !24
  %t1285 = load i64, ptr %l37, !tbaa !24
  %t1286 = load i1, ptr %l39, !tbaa !21
  %t1287 = load i64, ptr %l40, !tbaa !24
  %t1288 = load %"compiler/source:Span", ptr %l23
  %t1289 = load i32, ptr %l26, !tbaa !23
  %t1290 = load ptr, ptr %l2, !tbaa !29
  %t1292 = getelementptr %"compiler/ast:VarDecl", ptr %t1290, i32 0, i32 5
  %t1293 = load i1, ptr %t1292, !tbaa !21
  %t1301 = call %"compiler/check:unsetCand" @compiler_2fcheck_3aunsetCand_2ector(ptr %s31, i64 %t1284, i64 -1, i64 %t1285, i1 %t1286, i64 %t1287, %"compiler/source:Span" %t1288, i32 %t1289, i1 %t1293)
  store %"compiler/check:unsetCand" %t1301, ptr %l643
  br label %bb271
bb271:
  %t1302 = load %"compiler/check:unsetCand", ptr %l643
  store %"compiler/check:unsetCand" %t1302, ptr %l28
  call void @__olang_scope_close(ptr %s31)
  br label %bb272
bb272:
  br label %bb273
bb273:
  %t1303 = load i32, ptr %l26, !tbaa !23
  store i32 %t1303, ptr %l644, !tbaa !23
  %t1304 = load ptr, ptr %l0, !tbaa !29
  %t1306 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t1304)
  store i32 %t1306, ptr %l646
  br label %bb274
bb274:
  %t1307 = load i32, ptr %l644, !tbaa !23
  %t1308 = load i32, ptr %l646, !tbaa !23
  %t1309 = icmp eq i32 %t1307, %t1308
  br i1 %t1309, label %bb275, label %bb276
bb275:
  %t1311 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1311, ptr %l649, !tbaa !29
  %t1312 = load ptr, ptr %l27, !tbaa !29
  %t1314 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t1312)
  store i32 %t1314, ptr %l651
  br label %bb277
bb276:
  store i1 false, ptr %l648, !tbaa !21
  br label %bb279
bb277:
  %t1315 = load ptr, ptr %l649, !tbaa !29
  %t1316 = load i32, ptr %l651, !tbaa !23
  %t1317 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t1315, i32 %t1316)
  store i1 %t1317, ptr %l652
  br label %bb278
bb278:
  %t1318 = load i1, ptr %l652, !tbaa !21
  store i1 %t1318, ptr %l648, !tbaa !21
  br label %bb279
bb279:
  %t1319 = load i1, ptr %l648, !tbaa !21
  br i1 %t1319, label %bb280, label %bb281
bb280:
  %t1320 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1320, ptr %l653, !tbaa !29
  %t1321 = load %"compiler/source:Span", ptr %l23
  store %"compiler/source:Span" %t1321, ptr %l654
  %t1322 = load %"compiler/source:Span", ptr %l23
  store %"compiler/source:Span" %t1322, ptr %l655
  %t1323 = load i32, ptr %l26, !tbaa !23
  store i32 %t1323, ptr %l656, !tbaa !23
  %t1324 = load ptr, ptr %l27, !tbaa !29
  %t1326 = icmp eq ptr %t1324, null
  br i1 %t1326, label %bb282, label %bb283
bb281:
  br label %bb286
bb282:
  call void @__olang_check_failed(ptr @olang_loc_60b97769ab73fcb7_dac12c977cbf3c9b)
  unreachable
bb283:
  br label %bb284
bb284:
  %t1328 = load ptr, ptr %l27, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t1329
  %t1330 = getelementptr { i64, [4 x i64] }, ptr %t1329, i32 0, i32 0
  store i64 2, ptr %t1330
  %t1331 = load %"compiler/source:Span", ptr %l655
  %t1332 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t1331, 0
  %t1333 = load i32, ptr %l656, !tbaa !23
  %t1334 = insertvalue { %"compiler/source:Span", i32, ptr } %t1332, i32 %t1333, 1
  %t1336 = insertvalue { %"compiler/source:Span", i32, ptr } %t1334, ptr %t1328, 2
  %t1337 = getelementptr { i64, [4 x i64] }, ptr %t1329, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t1336, ptr %t1337
  %t1338 = load { i64, [4 x i64] }, ptr %t1329
  %t1340 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t1338, ptr %t1340
  %t1341 = load ptr, ptr %l653, !tbaa !29
  %t1342 = load %"compiler/source:Span", ptr %l654
  %t1344 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v0, ptr %v0, ptr %t1341, %"compiler/source:Span" %t1342, ptr %t1340)
  store ptr %t1344, ptr %l662
  br label %bb285
bb285:
  %t1345 = load ptr, ptr %l662, !tbaa !29
  store ptr %t1345, ptr %l27, !tbaa !29
  br label %bb286
bb286:
  %t1347 = load i64, ptr %l22, !tbaa !24
  %t1348 = load ptr, ptr %l2, !tbaa !29
  %t1350 = getelementptr %"compiler/ast:VarDecl", ptr %t1348, i32 0, i32 3
  %t1351 = load { i64, ptr }, ptr %t1350, !tbaa !27
  %t1353 = extractvalue { i64, ptr } %t1351, 0
  %t1356 = icmp slt i64 %t1347, %t1353
  br i1 %t1356, label %bb287, label %bb288
bb287:
  %t1358 = load ptr, ptr %l2, !tbaa !29
  %t1360 = getelementptr %"compiler/ast:VarDecl", ptr %t1358, i32 0, i32 2
  %t1361 = load ptr, ptr %t1360, !tbaa !29
  %t1363 = icmp eq ptr %t1361, null
  br i1 %t1363, label %bb289, label %bb290
bb288:
  store i1 false, ptr %l669, !tbaa !21
  br label %bb292
bb289:
  store i1 true, ptr %l673, !tbaa !21
  br label %bb291
bb290:
  %t1365 = load ptr, ptr %l2, !tbaa !29
  %t1367 = getelementptr %"compiler/ast:VarDecl", ptr %t1365, i32 0, i32 4
  %t1368 = load i1, ptr %t1367, !tbaa !21
  store i1 %t1368, ptr %l673, !tbaa !21
  br label %bb291
bb291:
  %t1370 = load i1, ptr %l673, !tbaa !21
  store i1 %t1370, ptr %l669, !tbaa !21
  br label %bb292
bb292:
  %t1371 = load i1, ptr %l669, !tbaa !21
  store i1 %t1371, ptr %l41, !tbaa !21
  %t1372 = load i1, ptr %l41, !tbaa !21
  br i1 %t1372, label %bb293, label %bb294
bb293:
  %t1374 = load ptr, ptr %l0, !tbaa !29
  %t1375 = load i32, ptr %l26, !tbaa !23
  %t1378 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t1374, i32 %t1375)
  store i1 %t1378, ptr %l680
  br label %bb295
bb294:
  store i1 false, ptr %l677, !tbaa !21
  br label %bb296
bb295:
  %t1379 = load i1, ptr %l680, !tbaa !21
  store i1 %t1379, ptr %l677, !tbaa !21
  br label %bb296
bb296:
  %t1380 = load i1, ptr %l677, !tbaa !21
  br i1 %t1380, label %bb297, label %bb298
bb297:
  %t1381 = load ptr, ptr %l0, !tbaa !29
  %t1383 = getelementptr %"compiler/check:Checker", ptr %t1381, i32 0, i32 1
  %t1384 = load ptr, ptr %t1383, !tbaa !29
  %t1386 = getelementptr %"compiler/generic:Program", ptr %t1384, i32 0, i32 2
  %t1387 = load i32, ptr %l26, !tbaa !23
  %t1390 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t1386, i32 %t1387)
  store i64 %t1390, ptr %l686
  br label %bb299
bb298:
  store i1 false, ptr %l681, !tbaa !21
  br label %bb300
bb299:
  %t1391 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t1392 = load i64, ptr %l686, !tbaa !24
  %t1394 = and i64 %t1392, %t1391
  %t1396 = icmp ne i64 %t1394, 0
  store i1 %t1396, ptr %l681, !tbaa !21
  br label %bb300
bb300:
  %t1398 = load i1, ptr %l681, !tbaa !21
  br i1 %t1398, label %bb301, label %bb302
bb301:
  %t1399 = load ptr, ptr %l0, !tbaa !29
  %t1401 = getelementptr %"compiler/check:Checker", ptr %t1399, i32 0, i32 1
  %t1402 = load ptr, ptr %t1401, !tbaa !29
  %t1404 = getelementptr %"compiler/generic:Program", ptr %t1402, i32 0, i32 2
  store ptr %t1404, ptr %l693, !tbaa !29
  %t1405 = load ptr, ptr %l0, !tbaa !29
  %t1406 = load i32, ptr %l26, !tbaa !23
  %t1409 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t1405, i32 %t1406)
  store i32 %t1409, ptr %l696
  br label %bb303
bb302:
  store i1 false, ptr %l690, !tbaa !21
  br label %bb305
bb303:
  %t1410 = load ptr, ptr %l693, !tbaa !29
  %t1411 = load i32, ptr %l696, !tbaa !23
  %t1412 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1410, i32 %t1411)
  store i32 %t1412, ptr %l697
  br label %bb304
bb304:
  %t1413 = load i32, ptr %l697, !range !{i32 0, i32 33}
  %t1415 = trunc i64 21 to i32
  %t1416 = icmp eq i32 %t1413, %t1415
  %t1418 = xor i1 %t1416, true
  store i1 %t1418, ptr %l690, !tbaa !21
  br label %bb305
bb305:
  %t1420 = load i1, ptr %l690, !tbaa !21
  br i1 %t1420, label %bb306, label %bb307
bb306:
  %t1421 = load ptr, ptr %l0, !tbaa !29
  %t1422 = load ptr, ptr %l27, !tbaa !29
  %t1425 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRef(ptr %v0, ptr %v0, ptr %t1421, ptr %t1422)
  store i1 %t1425, ptr %l704
  br label %bb308
bb307:
  store i1 false, ptr %l701, !tbaa !21
  br label %bb309
bb308:
  %t1426 = load i1, ptr %l704, !tbaa !21
  store i1 %t1426, ptr %l701, !tbaa !21
  br label %bb309
bb309:
  %t1427 = load i1, ptr %l701, !tbaa !21
  br i1 %t1427, label %bb310, label %bb311
bb310:
  %t1428 = load ptr, ptr %l0, !tbaa !29
  %t1430 = getelementptr %"compiler/check:Checker", ptr %t1428, i32 0, i32 1
  %t1431 = load ptr, ptr %t1430, !tbaa !29
  %t1433 = getelementptr %"compiler/generic:Program", ptr %t1431, i32 0, i32 2
  store ptr %t1433, ptr %l707, !tbaa !29
  %t1434 = load ptr, ptr %l0, !tbaa !29
  %t1436 = getelementptr %"compiler/check:Checker", ptr %t1434, i32 0, i32 1
  %t1437 = load ptr, ptr %t1436, !tbaa !29
  %t1439 = getelementptr %"compiler/generic:Program", ptr %t1437, i32 0, i32 2
  %t1440 = load i32, ptr %l26, !tbaa !23
  %t1443 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t1439, i32 %t1440)
  store i32 %t1443, ptr %l712
  br label %bb312
bb311:
  br label %bb315
bb312:
  %t1444 = load ptr, ptr %l0, !tbaa !29
  %t1446 = getelementptr %"compiler/check:Checker", ptr %t1444, i32 0, i32 1
  %t1447 = load ptr, ptr %t1446, !tbaa !29
  %t1449 = getelementptr %"compiler/generic:Program", ptr %t1447, i32 0, i32 2
  %t1450 = load i32, ptr %l26, !tbaa !23
  %t1453 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t1449, i32 %t1450)
  store i64 %t1453, ptr %l717
  br label %bb313
bb313:
  %t1454 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t1456 = xor i64 %t1454, -1
  %t1457 = load i64, ptr %l717, !tbaa !24
  %t1459 = and i64 %t1457, %t1456
  %t1460 = load ptr, ptr %l707, !tbaa !29
  %t1461 = load i32, ptr %l712, !tbaa !23
  %t1463 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t1460, i32 %t1461, i64 %t1459)
  store i32 %t1463, ptr %l721
  br label %bb314
bb314:
  %t1464 = load i32, ptr %l721, !tbaa !23
  store i32 %t1464, ptr %l26, !tbaa !23
  br label %bb315
bb315:
  %t1465 = load i64, ptr %l22, !tbaa !24
  %t1466 = load ptr, ptr %l2, !tbaa !29
  %t1468 = getelementptr %"compiler/ast:VarDecl", ptr %t1466, i32 0, i32 3
  %t1469 = load { i64, ptr }, ptr %t1468, !tbaa !27
  %t1471 = extractvalue { i64, ptr } %t1469, 0
  %t1474 = icmp slt i64 %t1465, %t1471
  br i1 %t1474, label %bb316, label %bb317
bb316:
  %t1476 = load i1, ptr %l41, !tbaa !21
  %t1478 = xor i1 %t1476, true
  store i1 %t1478, ptr %l727, !tbaa !21
  br label %bb318
bb317:
  store i1 false, ptr %l727, !tbaa !21
  br label %bb318
bb318:
  %t1480 = load i1, ptr %l727, !tbaa !21
  br i1 %t1480, label %bb319, label %bb320
bb319:
  %t1481 = load ptr, ptr %l0, !tbaa !29
  %t1482 = load i32, ptr %l26, !tbaa !23
  %t1485 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t1481, i32 %t1482)
  store i1 %t1485, ptr %l733
  br label %bb321
bb320:
  store i1 false, ptr %l730, !tbaa !21
  br label %bb322
bb321:
  %t1486 = load i1, ptr %l733, !tbaa !21
  %t1487 = xor i1 %t1486, true
  store i1 %t1487, ptr %l730, !tbaa !21
  br label %bb322
bb322:
  %t1489 = load i1, ptr %l730, !tbaa !21
  br i1 %t1489, label %bb323, label %bb324
bb323:
  %t1490 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1490, ptr %l735, !tbaa !29
  %t1491 = load ptr, ptr %l27, !tbaa !29
  store ptr %t1491, ptr %l736, !tbaa !29
  %t1492 = load ptr, ptr %l2, !tbaa !29
  %t1494 = getelementptr %"compiler/ast:VarDecl", ptr %t1492, i32 0, i32 3
  %t1495 = load { i64, ptr }, ptr %t1494, !tbaa !27
  store { i64, ptr } %t1495, ptr %l738, !tbaa !27
  %t1496 = load i64, ptr %l22, !tbaa !24
  %t1498 = getelementptr { i64, ptr }, ptr %l738, i32 0, i32 1
  %t1499 = load ptr, ptr %t1498, !tbaa !27
  %t1500 = getelementptr ptr, ptr %t1499, i64 %t1496
  %t1501 = load ptr, ptr %t1500, !tbaa !39
  %t1503 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t1501)
  store %"compiler/source:Span" %t1503, ptr %l741
  br label %bb325
bb324:
  br label %bb327
bb325:
  %t1504 = load i64, ptr @G_2ecompiler_2fcheck_2eRoDecl, !tbaa !24
  %t1505 = load ptr, ptr %l735, !tbaa !29
  %t1506 = load ptr, ptr %l736, !tbaa !29
  %t1507 = load %"compiler/source:Span", ptr %l741
  %t1509 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroStore(ptr %v0, ptr %v0, ptr %t1505, ptr %t1506, %"compiler/source:Span" %t1507, i64 %t1504)
  store i1 %t1509, ptr %l743
  br label %bb326
bb326:
  br label %bb327
bb327:
  %t1510 = load ptr, ptr %l0, !tbaa !29
  %t1511 = load ptr, ptr %l2, !tbaa !29
  %t1513 = getelementptr %"compiler/ast:VarDecl", ptr %t1511, i32 0, i32 0
  %t1514 = load { i64, ptr }, ptr %t1513, !tbaa !27
  store { i64, ptr } %t1514, ptr %l746, !tbaa !27
  %t1515 = load i64, ptr %l22, !tbaa !24
  %t1517 = getelementptr { i64, ptr }, ptr %l746, i32 0, i32 1
  %t1518 = load ptr, ptr %t1517, !tbaa !27
  %t1519 = getelementptr i32, ptr %t1518, i64 %t1515
  %t1520 = load i32, ptr %t1519, !tbaa !33
  %t1521 = load %"compiler/source:Span", ptr %l23
  %t1522 = load i32, ptr %l26, !tbaa !23
  %t1523 = load i32, ptr %l16, !range !{i32 0, i32 7}
  %t1524 = load { i64, [2 x i64] }, ptr %l13
  %t1531 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t1510, i32 %t1520, %"compiler/source:Span" %t1521, i32 %t1522, i32 %t1523, { i64, [2 x i64] } %t1524)
  store i64 %t1531, ptr %l753
  br label %bb328
bb328:
  %t1532 = load i64, ptr %l753, !tbaa !24
  store i64 %t1532, ptr %l42, !tbaa !24
  %t1533 = load i64, ptr %l22, !tbaa !24
  %t1534 = load ptr, ptr %l2, !tbaa !29
  %t1536 = getelementptr %"compiler/ast:VarDecl", ptr %t1534, i32 0, i32 3
  %t1537 = load { i64, ptr }, ptr %t1536, !tbaa !27
  %t1539 = extractvalue { i64, ptr } %t1537, 0
  %t1542 = icmp slt i64 %t1533, %t1539
  br i1 %t1542, label %bb329, label %bb330
bb329:
  %t1544 = load ptr, ptr %l2, !tbaa !29
  %t1546 = getelementptr %"compiler/ast:VarDecl", ptr %t1544, i32 0, i32 5
  %t1547 = load i1, ptr %t1546, !tbaa !21
  %t1549 = xor i1 %t1547, true
  store i1 %t1549, ptr %l759, !tbaa !21
  br label %bb331
bb330:
  store i1 false, ptr %l759, !tbaa !21
  br label %bb331
bb331:
  %t1551 = load i1, ptr %l759, !tbaa !21
  br i1 %t1551, label %bb332, label %bb333
bb332:
  %t1552 = load ptr, ptr %l2, !tbaa !29
  %t1554 = getelementptr %"compiler/ast:VarDecl", ptr %t1552, i32 0, i32 0
  %t1555 = load { i64, ptr }, ptr %t1554, !tbaa !27
  %t1557 = extractvalue { i64, ptr } %t1555, 0
  %t1559 = icmp eq i64 %t1557, 1
  store i1 %t1559, ptr %l763, !tbaa !21
  br label %bb334
bb333:
  store i1 false, ptr %l763, !tbaa !21
  br label %bb334
bb334:
  %t1561 = load i1, ptr %l763, !tbaa !21
  br i1 %t1561, label %bb335, label %bb336
bb335:
  %t1562 = load ptr, ptr %l0, !tbaa !29
  %t1564 = getelementptr %"compiler/check:Checker", ptr %t1562, i32 0, i32 1
  %t1565 = load ptr, ptr %t1564, !tbaa !29
  %t1567 = getelementptr %"compiler/generic:Program", ptr %t1565, i32 0, i32 2
  store ptr %t1567, ptr %l771, !tbaa !29
  %t1568 = load ptr, ptr %l0, !tbaa !29
  %t1570 = getelementptr %"compiler/check:Checker", ptr %t1568, i32 0, i32 1
  %t1571 = load ptr, ptr %t1570, !tbaa !29
  %t1573 = getelementptr %"compiler/generic:Program", ptr %t1571, i32 0, i32 2
  %t1574 = load i32, ptr %l26, !tbaa !23
  %t1577 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t1573, i32 %t1574)
  store i32 %t1577, ptr %l776
  br label %bb337
bb336:
  store i1 false, ptr %l768, !tbaa !21
  br label %bb339
bb337:
  %t1578 = load ptr, ptr %l771, !tbaa !29
  %t1579 = load i32, ptr %l776, !tbaa !23
  %t1580 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1578, i32 %t1579)
  store i32 %t1580, ptr %l777
  br label %bb338
bb338:
  %t1581 = load i32, ptr %l777, !range !{i32 0, i32 33}
  %t1583 = trunc i64 19 to i32
  %t1584 = icmp eq i32 %t1581, %t1583
  store i1 %t1584, ptr %l768, !tbaa !21
  br label %bb339
bb339:
  %t1586 = load i1, ptr %l768, !tbaa !21
  br i1 %t1586, label %bb340, label %bb341
bb340:
  %t1587 = load ptr, ptr %l0, !tbaa !29
  %t1589 = getelementptr %"compiler/check:Checker", ptr %t1587, i32 0, i32 1
  %t1590 = load ptr, ptr %t1589, !tbaa !29
  %t1592 = getelementptr %"compiler/generic:Program", ptr %t1590, i32 0, i32 2
  store ptr %t1592, ptr %l783, !tbaa !29
  %t1593 = load ptr, ptr %l0, !tbaa !29
  %t1595 = getelementptr %"compiler/check:Checker", ptr %t1593, i32 0, i32 1
  %t1596 = load ptr, ptr %t1595, !tbaa !29
  %t1598 = getelementptr %"compiler/generic:Program", ptr %t1596, i32 0, i32 2
  %t1599 = load i32, ptr %l26, !tbaa !23
  %t1602 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t1598, i32 %t1599)
  store i32 %t1602, ptr %l788
  br label %bb342
bb341:
  store i1 false, ptr %l780, !tbaa !21
  br label %bb344
bb342:
  %t1603 = load ptr, ptr %l783, !tbaa !29
  %t1604 = load i32, ptr %l788, !tbaa !23
  %t1605 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t1603, i32 %t1604)
  store i32 %t1605, ptr %l789
  br label %bb343
bb343:
  %t1606 = load i32, ptr %l789, !tbaa !23
  %t1607 = icmp ne i32 %t1606, 0
  store i1 %t1607, ptr %l780, !tbaa !21
  br label %bb344
bb344:
  %t1609 = load i1, ptr %l780, !tbaa !21
  br i1 %t1609, label %bb345, label %bb346
bb345:
  %t1610 = load ptr, ptr %l0, !tbaa !29
  %t1611 = load ptr, ptr %l27, !tbaa !29
  %t1614 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoClearMade(ptr %v0, ptr %v0, ptr %t1610, ptr %t1611)
  store i1 %t1614, ptr %l794
  br label %bb347
bb346:
  store i1 false, ptr %l791, !tbaa !21
  br label %bb348
bb347:
  %t1615 = load i1, ptr %l794, !tbaa !21
  store i1 %t1615, ptr %l791, !tbaa !21
  br label %bb348
bb348:
  %t1616 = load i1, ptr %l791, !tbaa !21
  br i1 %t1616, label %bb349, label %bb350
bb349:
  %t1617 = load i64, ptr %l42, !tbaa !24
  store i64 %t1617, ptr %l43, !tbaa !24
  store i1 true, ptr %l44, !tbaa !21
  %t1619 = load ptr, ptr %l0, !tbaa !29
  %t1621 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t1619)
  store ptr %t1621, ptr %l797
  br label %bb351
bb350:
  br label %bb353
bb351:
  %t1622 = load ptr, ptr %l797, !tbaa !29
  %t1624 = getelementptr %"compiler/typed:Body", ptr %t1622, i32 0, i32 7
  %t1625 = load i64, ptr %l43, !tbaa !24
  %t1628 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eRefMut_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %v0, ptr %t1624, i64 %t1625)
  store ptr %t1628, ptr %l801
  br label %bb352
bb352:
  %t1629 = load ptr, ptr %l801, !tbaa !29
  %t1631 = load i1, ptr %l44, !tbaa !21
  %t1634 = getelementptr %"compiler/typed:Local", ptr %t1629, i32 0, i32 6
  store i1 %t1631, ptr %t1634, !tbaa !21
  br label %bb353
bb353:
  %t1635 = getelementptr %"compiler/check:unsetCand", ptr %l28, i32 0, i32 2
  %t1636 = load i64, ptr %t1635, !tbaa !24
  %t1638 = icmp sge i64 %t1636, 0
  br i1 %t1638, label %bb354, label %bb355
bb354:
  store %olang.scope zeroinitializer, ptr %s38
  %t1640 = load ptr, ptr %l0, !tbaa !29
  %t1642 = getelementptr %"compiler/check:Checker", ptr %t1640, i32 0, i32 91
  store ptr %t1642, ptr %l807, !tbaa !29
  %t1643 = getelementptr %"compiler/check:unsetCand", ptr %l28, i32 0, i32 0
  %t1644 = load i64, ptr %t1643, !tbaa !24
  %t1645 = load i64, ptr %l42, !tbaa !24
  %t1646 = getelementptr %"compiler/check:unsetCand", ptr %l28, i32 0, i32 2
  %t1647 = load i64, ptr %t1646, !tbaa !24
  %t1648 = getelementptr %"compiler/check:unsetCand", ptr %l28, i32 0, i32 3
  %t1649 = load i1, ptr %t1648, !tbaa !21
  %t1650 = getelementptr %"compiler/check:unsetCand", ptr %l28, i32 0, i32 4
  %t1651 = load i64, ptr %t1650, !tbaa !24
  %t1652 = getelementptr %"compiler/check:unsetCand", ptr %l28, i32 0, i32 5
  %t1653 = load %"compiler/source:Span", ptr %t1652
  %t1654 = getelementptr %"compiler/check:unsetCand", ptr %l28, i32 0, i32 6
  %t1655 = load i32, ptr %t1654, !tbaa !23
  %t1656 = getelementptr %"compiler/check:unsetCand", ptr %l28, i32 0, i32 7
  %t1657 = load i1, ptr %t1656, !tbaa !21
  %t1666 = call %"compiler/check:unsetCand" @compiler_2fcheck_3aunsetCand_2ector(ptr %s38, i64 %t1644, i64 %t1645, i64 %t1647, i1 %t1649, i64 %t1651, %"compiler/source:Span" %t1653, i32 %t1655, i1 %t1657)
  store %"compiler/check:unsetCand" %t1666, ptr %l816
  br label %bb356
bb355:
  br label %bb358
bb356:
  %t1667 = load ptr, ptr %l807, !tbaa !29
  %t1668 = load %"compiler/check:unsetCand", ptr %l816
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aunsetCand_3e_2ePush_Hd5bae6439baa110b1f2b8b5b7cdda5ce(ptr %v0, ptr %t1667, %"compiler/check:unsetCand" %t1668)
  br label %bb357
bb357:
  call void @__olang_scope_close(ptr %s38)
  br label %bb358
bb358:
  %t1669 = load ptr, ptr %l2, !tbaa !29
  %t1671 = getelementptr %"compiler/ast:VarDecl", ptr %t1669, i32 0, i32 2
  %t1672 = load ptr, ptr %t1671, !tbaa !29
  %t1674 = icmp eq ptr %t1672, null
  %t1676 = xor i1 %t1674, true
  br i1 %t1676, label %bb359, label %bb360
bb359:
  %t1678 = load ptr, ptr %l2, !tbaa !29
  %t1680 = getelementptr %"compiler/ast:VarDecl", ptr %t1678, i32 0, i32 4
  %t1681 = load i1, ptr %t1680, !tbaa !21
  %t1683 = xor i1 %t1681, true
  store i1 %t1683, ptr %l821, !tbaa !21
  br label %bb361
bb360:
  store i1 false, ptr %l821, !tbaa !21
  br label %bb361
bb361:
  %t1685 = load i1, ptr %l821, !tbaa !21
  br i1 %t1685, label %bb362, label %bb363
bb362:
  %t1686 = load ptr, ptr %l0, !tbaa !29
  %t1688 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1686)
  store ptr %t1688, ptr %l826
  br label %bb364
bb363:
  br label %bb370
bb364:
  %t1689 = load ptr, ptr %l826, !tbaa !29
  %t1691 = getelementptr %"compiler/check:frame", ptr %t1689, i32 0, i32 3
  store ptr %t1691, ptr %l828, !tbaa !29
  %t1692 = load i64, ptr %l42, !tbaa !24
  store i64 %t1692, ptr %l829, !tbaa !24
  %t1693 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1693, ptr %l830, !tbaa !29
  %t1694 = load ptr, ptr %l2, !tbaa !29
  %t1696 = getelementptr %"compiler/ast:VarDecl", ptr %t1694, i32 0, i32 2
  %t1697 = load ptr, ptr %t1696, !tbaa !29
  %t1699 = icmp eq ptr %t1697, null
  br i1 %t1699, label %bb365, label %bb366
bb365:
  call void @__olang_check_failed(ptr @olang_loc_456a500fefc58a98_a2eaf47e24a406ac)
  unreachable
bb366:
  br label %bb367
bb367:
  %t1701 = load ptr, ptr %l2, !tbaa !29
  %t1703 = getelementptr %"compiler/ast:VarDecl", ptr %t1701, i32 0, i32 2
  %t1704 = load ptr, ptr %t1703, !tbaa !29
  %t1705 = load ptr, ptr %l830, !tbaa !29
  %t1707 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeWrittenAt(ptr %v0, ptr %v1, ptr %t1705, ptr %t1704)
  store { i64, [3 x i64] } %t1707, ptr %l836
  br label %bb368
bb368:
  %t1708 = load ptr, ptr %l828, !tbaa !29
  %t1709 = load i64, ptr %l829, !tbaa !24
  %t1710 = load { i64, [3 x i64] }, ptr %l836
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fdiag_3aWhere_3e_2e_Hc07a7e56a24d8f1225398db99ea19a4b(ptr %v0, ptr %t1708, i64 %t1709, { i64, [3 x i64] } %t1710)
  br label %bb369
bb369:
  br label %bb370
bb370:
  %t1711 = load i1, ptr %l41, !tbaa !21
  br i1 %t1711, label %bb371, label %bb372
bb371:
  %t1713 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1713, ptr %l838, !tbaa !29
  %t1714 = load i64, ptr %l42, !tbaa !24
  store i64 %t1714, ptr %l839, !tbaa !24
  %t1715 = load ptr, ptr %l27, !tbaa !29
  %t1717 = icmp eq ptr %t1715, null
  br i1 %t1717, label %bb373, label %bb374
bb372:
  br label %bb377
bb373:
  call void @__olang_check_failed(ptr @olang_loc_3b566e89984acdce_dde06b5f9a89c81a)
  unreachable
bb374:
  br label %bb375
bb375:
  %t1719 = load ptr, ptr %l27, !tbaa !29
  %t1720 = load ptr, ptr %l838, !tbaa !29
  %t1721 = load i64, ptr %l839, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLet(ptr %v0, ptr %v0, ptr %t1720, i64 %t1721, ptr %t1719)
  br label %bb376
bb376:
  br label %bb377
bb377:
  %t1723 = load i1, ptr %l41, !tbaa !21
  br i1 %t1723, label %bb378, label %bb379
bb378:
  %t1725 = load ptr, ptr %l2, !tbaa !29
  %t1727 = getelementptr %"compiler/ast:VarDecl", ptr %t1725, i32 0, i32 5
  %t1728 = load i1, ptr %t1727, !tbaa !21
  %t1730 = xor i1 %t1728, true
  store i1 %t1730, ptr %l844, !tbaa !21
  br label %bb380
bb379:
  store i1 false, ptr %l844, !tbaa !21
  br label %bb380
bb380:
  %t1732 = load i1, ptr %l844, !tbaa !21
  br i1 %t1732, label %bb381, label %bb382
bb381:
  %t1733 = load ptr, ptr %l0, !tbaa !29
  %t1734 = load i32, ptr %l26, !tbaa !23
  %t1737 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t1733, i32 %t1734)
  store i1 %t1737, ptr %l851
  br label %bb383
bb382:
  store i1 false, ptr %l848, !tbaa !21
  br label %bb384
bb383:
  %t1738 = load i1, ptr %l851, !tbaa !21
  store i1 %t1738, ptr %l848, !tbaa !21
  br label %bb384
bb384:
  %t1739 = load i1, ptr %l848, !tbaa !21
  br i1 %t1739, label %bb385, label %bb386
bb385:
  %t1740 = load ptr, ptr %l0, !tbaa !29
  %t1741 = load ptr, ptr %l2, !tbaa !29
  %t1743 = getelementptr %"compiler/ast:VarDecl", ptr %t1741, i32 0, i32 3
  %t1744 = load { i64, ptr }, ptr %t1743, !tbaa !27
  store { i64, ptr } %t1744, ptr %l855, !tbaa !27
  %t1745 = load i64, ptr %l22, !tbaa !24
  %t1747 = getelementptr { i64, ptr }, ptr %l855, i32 0, i32 1
  %t1748 = load ptr, ptr %t1747, !tbaa !27
  %t1749 = getelementptr ptr, ptr %t1748, i64 %t1745
  %t1750 = load ptr, ptr %t1749, !tbaa !39
  %t1753 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %t1740, ptr %t1750)
  store i1 %t1753, ptr %l858
  br label %bb387
bb386:
  store i1 false, ptr %l852, !tbaa !21
  br label %bb388
bb387:
  %t1754 = load i1, ptr %l858, !tbaa !21
  store i1 %t1754, ptr %l852, !tbaa !21
  br label %bb388
bb388:
  %t1755 = load i1, ptr %l852, !tbaa !21
  br i1 %t1755, label %bb389, label %bb390
bb389:
  store %olang.scope zeroinitializer, ptr %s41
  %t1756 = load ptr, ptr %l0, !tbaa !29
  %t1758 = getelementptr %"compiler/check:Checker", ptr %t1756, i32 0, i32 31
  store ptr %t1758, ptr %l860, !tbaa !29
  %t1759 = load ptr, ptr %l0, !tbaa !29
  %t1761 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1759)
  store ptr %t1761, ptr %l862
  br label %bb391
bb390:
  br label %bb394
bb391:
  %t1762 = load ptr, ptr %l862, !tbaa !29
  %t1764 = getelementptr %"compiler/check:frame", ptr %t1762, i32 0, i32 0
  %t1765 = load i64, ptr %t1764, !tbaa !24
  %t1766 = load i64, ptr %l42, !tbaa !24
  %t1769 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s41, i64 %t1765, i64 %t1766)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t1769, ptr %l866
  br label %bb392
bb392:
  %t1770 = load ptr, ptr %l860, !tbaa !29
  %t1771 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l866
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t1770, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t1771, i1 true)
  br label %bb393
bb393:
  call void @__olang_scope_close(ptr %s41)
  br label %bb394
bb394:
  %t1772 = load ptr, ptr %l2, !tbaa !29
  %t1774 = getelementptr %"compiler/ast:VarDecl", ptr %t1772, i32 0, i32 5
  %t1775 = load i1, ptr %t1774, !tbaa !21
  %t1777 = xor i1 %t1775, true
  br i1 %t1777, label %bb395, label %bb396
bb395:
  %t1779 = load i64, ptr %l22, !tbaa !24
  %t1780 = load ptr, ptr %l2, !tbaa !29
  %t1782 = getelementptr %"compiler/ast:VarDecl", ptr %t1780, i32 0, i32 3
  %t1783 = load { i64, ptr }, ptr %t1782, !tbaa !27
  %t1785 = extractvalue { i64, ptr } %t1783, 0
  %t1788 = icmp slt i64 %t1779, %t1785
  store i1 %t1788, ptr %l870, !tbaa !21
  br label %bb397
bb396:
  store i1 false, ptr %l870, !tbaa !21
  br label %bb397
bb397:
  %t1790 = load i1, ptr %l870, !tbaa !21
  br i1 %t1790, label %bb398, label %bb399
bb398:
  %t1791 = load ptr, ptr %l0, !tbaa !29
  %t1792 = load i32, ptr %l26, !tbaa !23
  %t1795 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplainScalar(ptr %v0, ptr %t1791, i32 %t1792)
  store i1 %t1795, ptr %l879
  br label %bb400
bb399:
  store i1 false, ptr %l876, !tbaa !21
  br label %bb401
bb400:
  %t1796 = load i1, ptr %l879, !tbaa !21
  store i1 %t1796, ptr %l876, !tbaa !21
  br label %bb401
bb401:
  %t1797 = load i1, ptr %l876, !tbaa !21
  br i1 %t1797, label %bb402, label %bb403
bb402:
  store %olang.scope zeroinitializer, ptr %s42
  %t1798 = load ptr, ptr %l0, !tbaa !29
  %t1800 = getelementptr %"compiler/check:Checker", ptr %t1798, i32 0, i32 118
  store ptr %t1800, ptr %l881, !tbaa !29
  %t1801 = load ptr, ptr %l0, !tbaa !29
  %t1803 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1801)
  store ptr %t1803, ptr %l883
  br label %bb404
bb403:
  br label %bb408
bb404:
  %t1804 = load ptr, ptr %l883, !tbaa !29
  %t1806 = getelementptr %"compiler/check:frame", ptr %t1804, i32 0, i32 0
  %t1807 = load i64, ptr %t1806, !tbaa !24
  %t1808 = load i64, ptr %l42, !tbaa !24
  %t1811 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s42, i64 %t1807, i64 %t1808)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t1811, ptr %l887
  br label %bb405
bb405:
  %t1812 = load ptr, ptr %l2, !tbaa !29
  %t1814 = getelementptr %"compiler/ast:VarDecl", ptr %t1812, i32 0, i32 3
  %t1815 = load { i64, ptr }, ptr %t1814, !tbaa !27
  store { i64, ptr } %t1815, ptr %l889, !tbaa !27
  %t1816 = load i64, ptr %l22, !tbaa !24
  %t1818 = getelementptr { i64, ptr }, ptr %l889, i32 0, i32 1
  %t1819 = load ptr, ptr %t1818, !tbaa !27
  %t1820 = getelementptr ptr, ptr %t1819, i64 %t1816
  %t1821 = load ptr, ptr %t1820, !tbaa !39
  %t1822 = load i32, ptr %l26, !tbaa !23
  %t1825 = call %"compiler/check:fixedInit" @compiler_2fcheck_3afixedInit_2ector(ptr %v1, ptr %v0, ptr %t1821, i32 %t1822)
  store %"compiler/check:fixedInit" %t1825, ptr %l893
  br label %bb406
bb406:
  %t1826 = load ptr, ptr %l881, !tbaa !29
  %t1827 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l887
  %t1828 = load %"compiler/check:fixedInit", ptr %l893
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5daf2b89f219287cc2404f0b0e96c809(ptr %v0, ptr %v0, ptr %t1826, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t1827, %"compiler/check:fixedInit" %t1828)
  br label %bb407
bb407:
  call void @__olang_scope_close(ptr %s42)
  br label %bb408
bb408:
  %t1829 = load i64, ptr %l22, !tbaa !24
  %t1830 = load ptr, ptr %l2, !tbaa !29
  %t1832 = getelementptr %"compiler/ast:VarDecl", ptr %t1830, i32 0, i32 3
  %t1833 = load { i64, ptr }, ptr %t1832, !tbaa !27
  %t1835 = extractvalue { i64, ptr } %t1833, 0
  %t1838 = icmp slt i64 %t1829, %t1835
  br i1 %t1838, label %bb409, label %bb410
bb409:
  %t1840 = load ptr, ptr %l0, !tbaa !29
  %t1841 = load i32, ptr %l26, !tbaa !23
  %t1844 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t1840, i32 %t1841)
  store i1 %t1844, ptr %l902
  br label %bb411
bb410:
  store i1 false, ptr %l899, !tbaa !21
  br label %bb412
bb411:
  %t1845 = load i1, ptr %l902, !tbaa !21
  %t1846 = xor i1 %t1845, true
  store i1 %t1846, ptr %l899, !tbaa !21
  br label %bb412
bb412:
  %t1848 = load i1, ptr %l899, !tbaa !21
  br i1 %t1848, label %bb413, label %bb414
bb413:
  %t1849 = load ptr, ptr %l0, !tbaa !29
  %t1851 = getelementptr %"compiler/check:Checker", ptr %t1849, i32 0, i32 1
  %t1852 = load ptr, ptr %t1851, !tbaa !29
  %t1854 = getelementptr %"compiler/generic:Program", ptr %t1852, i32 0, i32 2
  %t1855 = load i32, ptr %l26, !tbaa !23
  %t1858 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnsParts(ptr %v0, ptr %t1854, i32 %t1855)
  store i1 %t1858, ptr %l909
  br label %bb415
bb414:
  store i1 false, ptr %l904, !tbaa !21
  br label %bb416
bb415:
  %t1859 = load i1, ptr %l909, !tbaa !21
  store i1 %t1859, ptr %l904, !tbaa !21
  br label %bb416
bb416:
  %t1860 = load i1, ptr %l904, !tbaa !21
  br i1 %t1860, label %bb417, label %bb418
bb417:
  %t1861 = load ptr, ptr %l27, !tbaa !29
  %t1863 = icmp eq ptr %t1861, null
  br i1 %t1863, label %bb419, label %bb420
bb418:
  store i1 false, ptr %l910, !tbaa !21
  br label %bb423
bb419:
  call void @__olang_check_failed(ptr @olang_loc_9c28400664f91d75_969ef375bde61da1)
  unreachable
bb420:
  br label %bb421
bb421:
  %t1865 = load ptr, ptr %l27, !tbaa !29
  %t1867 = call i1 @compiler_2fcheck_2escopedValue(ptr %v0, ptr %t1865)
  store i1 %t1867, ptr %l914
  br label %bb422
bb422:
  %t1868 = load i1, ptr %l914, !tbaa !21
  %t1869 = xor i1 %t1868, true
  store i1 %t1869, ptr %l910, !tbaa !21
  br label %bb423
bb423:
  %t1871 = load i1, ptr %l910, !tbaa !21
  br i1 %t1871, label %bb424, label %bb425
bb424:
  %t1872 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1872, ptr %l916, !tbaa !29
  %t1873 = load ptr, ptr %l27, !tbaa !29
  %t1875 = icmp eq ptr %t1873, null
  br i1 %t1875, label %bb426, label %bb427
bb425:
  br label %bb430
bb426:
  call void @__olang_check_failed(ptr @olang_loc_9c28400664f91d75_969ef375bde61da1)
  unreachable
bb427:
  br label %bb428
bb428:
  %t1877 = load ptr, ptr %l27, !tbaa !29
  %t1878 = load ptr, ptr %l916, !tbaa !29
  %t1880 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eownCopy(ptr %v0, ptr %v0, ptr %v0, ptr %t1878, ptr %t1877)
  store ptr %t1880, ptr %l920
  br label %bb429
bb429:
  %t1881 = load ptr, ptr %l920, !tbaa !29
  store ptr %t1881, ptr %l27, !tbaa !29
  br label %bb430
bb430:
  %t1883 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1883, ptr %l922, !tbaa !29
  %t1884 = load %"compiler/source:Span", ptr %l23
  store %"compiler/source:Span" %t1884, ptr %l923
  %t1885 = load i64, ptr %l42, !tbaa !24
  %t1887 = trunc i64 %t1885 to i32
  store i32 %t1887, ptr %l926, !tbaa !23
  %t1889 = load ptr, ptr %l27, !tbaa !29
  %t1891 = icmp eq ptr %t1889, null
  br i1 %t1891, label %bb431, label %bb432
bb431:
  call void @__olang_check_failed(ptr @olang_loc_982a334cfac79560_875fefac8daf1dec)
  unreachable
bb432:
  br label %bb433
bb433:
  %t1893 = load ptr, ptr %l27, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t1894
  %t1895 = getelementptr { i64, [3 x i64] }, ptr %t1894, i32 0, i32 0
  store i64 0, ptr %t1895
  %t1896 = load %"compiler/source:Span", ptr %l923
  %t1897 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t1896, 0
  %t1898 = load i32, ptr %l926, !tbaa !23
  %t1899 = insertvalue { %"compiler/source:Span", i32, ptr } %t1897, i32 %t1898, 1
  %t1901 = insertvalue { %"compiler/source:Span", i32, ptr } %t1899, ptr %t1893, 2
  %t1902 = getelementptr { i64, [3 x i64] }, ptr %t1894, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t1901, ptr %t1902
  %t1903 = load { i64, [3 x i64] }, ptr %t1894
  %t1905 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t1903, ptr %t1905
  %t1906 = load ptr, ptr %l922, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t1906, ptr %t1905)
  br label %bb434
bb434:
  %t1908 = load ptr, ptr %l2, !tbaa !29
  %t1910 = getelementptr %"compiler/ast:VarDecl", ptr %t1908, i32 0, i32 5
  %t1911 = load i1, ptr %t1910, !tbaa !21
  br i1 %t1911, label %bb435, label %bb436
bb435:
  %t1913 = load ptr, ptr %l0, !tbaa !29
  %t1915 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t1913)
  store ptr %t1915, ptr %l935
  br label %bb437
bb436:
  br label %bb439
bb437:
  %t1916 = load ptr, ptr %l935, !tbaa !29
  %t1918 = getelementptr %"compiler/typed:Body", ptr %t1916, i32 0, i32 10
  %t1919 = load i64, ptr %l42, !tbaa !24
  %t1921 = trunc i64 %t1919 to i32
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2ePush_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t1918, i32 %t1921)
  br label %bb438
bb438:
  br label %bb439
bb439:
  call void @__olang_scope_close(ptr %s14)
  br label %bb440
bb440:
  %t1925 = load i64, ptr %l21, !tbaa !24
  %t1927 = add i64 %t1925, 1
  store i64 %t1927, ptr %l21, !tbaa !24
  br label %bb94
bb441:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalk(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca i1
  %l44 = alloca ptr
  %l48 = alloca ptr
  %l49 = alloca ptr
  %l57 = alloca ptr
  %l61 = alloca ptr
  %l62 = alloca ptr
  %l67 = alloca i32
  %l74 = alloca i32
  %l80 = alloca i1
  %l81 = alloca i32
  %l88 = alloca i32
  %l92 = alloca i64
  %l94 = alloca ptr
  %l97 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l100 = alloca i1
  %l101 = alloca i1
  %l105 = alloca i1
  %l106 = alloca ptr
  %l108 = alloca ptr
  %l109 = alloca i1
  %l110 = alloca ptr
  %l111 = alloca ptr
  %l112 = alloca i32
  %l115 = alloca %"compiler/source:Span"
  %l116 = alloca ptr
  %l129 = alloca ptr
  %l130 = alloca %"compiler/source:Span"
  %l132 = alloca i32
  %l133 = alloca i64
  %l134 = alloca ptr
  %l135 = alloca %"compiler/source:Span"
  %l138 = alloca i32
  %l139 = alloca ptr
  %l140 = alloca %"compiler/source:Span"
  %l142 = alloca i32
  %l143 = alloca ptr
  %l146 = alloca ptr
  %l147 = alloca %"compiler/source:Span"
  %l149 = alloca i32
  %l150 = alloca i64
  %l151 = alloca ptr
  %l152 = alloca %"compiler/source:Span"
  %l155 = alloca i32
  %l156 = alloca ptr
  %l157 = alloca %"compiler/source:Span"
  %l159 = alloca i32
  %l160 = alloca i32
  %l164 = alloca ptr
  %l165 = alloca ptr
  %l171 = alloca i1
  %l176 = alloca i32
  %l178 = alloca i1
  %l181 = alloca ptr
  %l186 = alloca i32
  %l187 = alloca i32
  %l190 = alloca ptr
  %l193 = alloca ptr
  %l198 = alloca i32
  %l199 = alloca i64
  %l212 = alloca ptr
  %l221 = alloca i32
  %l226 = alloca i32
  %l230 = alloca ptr
  %l235 = alloca i32
  %l236 = alloca { i64, ptr }
  %l242 = alloca i64
  %l245 = alloca i64
  %l264 = alloca { i64, ptr }
  %l267 = alloca { i64, ptr }
  %l268 = alloca i1
  %l269 = alloca i1
  %l272 = alloca ptr
  %l276 = alloca { i64, ptr }
  %l279 = alloca i32
  %l280 = alloca { i64, ptr }
  %l294 = alloca ptr
  %l297 = alloca %"compiler/source:Span"
  %l300 = alloca { i64, ptr }
  %l302 = alloca %"compiler/msgs:Msg"
  %l303 = alloca i64
  %l308 = alloca i64
  %l312 = alloca i64
  %l315 = alloca i1
  %l318 = alloca i1
  %l322 = alloca i1
  %l346 = alloca i64
  %l349 = alloca ptr
  %l350 = alloca %"compiler/source:Span"
  %l353 = alloca %"compiler/source:Span"
  %l354 = alloca i64
  %l356 = alloca ptr
  %l359 = alloca { i64, ptr }
  %l362 = alloca { i64, ptr }
  %l366 = alloca ptr
  %l367 = alloca ptr
  %l368 = alloca ptr
  %l371 = alloca i32
  %l372 = alloca i32
  %l373 = alloca i64
  %l376 = alloca ptr
  %l379 = alloca %"compiler/source:Span"
  %l392 = alloca i64
  %l395 = alloca i64
  %l398 = alloca i1
  %l401 = alloca ptr
  %l404 = alloca ptr
  %l408 = alloca i32
  %l409 = alloca i32
  %l410 = alloca { i64, ptr }
  %l414 = alloca ptr
  %l415 = alloca ptr
  %l420 = alloca i1
  %l435 = alloca i1
  %l437 = alloca ptr
  %l440 = alloca %"compiler/source:Span"
  %l441 = alloca i32
  %l444 = alloca { i64, ptr }
  %l446 = alloca %"compiler/msgs:Msg"
  %l447 = alloca i64
  %s0 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %rv = alloca ptr
  %t196 = alloca { i64, [3 x i64] }, align 8
  %t235 = alloca { i64, [3 x i64] }, align 8
  %t283 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:ForIn", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l5, !tbaa !29
  store ptr %t6, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t7 = load ptr, ptr %l32, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l32, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 30}
  %t13 = icmp eq i64 %t11, 24
  store i1 %t13, ptr %l33, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l33, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l5, !tbaa !29
  %t17 = getelementptr { i64, [4 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t17, i32 0, i32 1
  %t19 = load { i64, ptr }, ptr %t18
  store { i64, ptr } %t19, ptr %l6, !tbaa !27
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load %"compiler/source:Span", ptr %l1
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t24 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t25 = load ptr, ptr %l3, !tbaa !29
  %t26 = load i32, ptr %l4, !tbaa !23
  %t33 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eforRange(ptr %v0, ptr %v1, ptr %v1, ptr %v2, ptr %v3, ptr %t21, %"compiler/source:Span" %t22, ptr %t23, { i64, ptr } %t24, ptr %t25, i32 %t26)
  store ptr %t33, ptr %l44
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t34 = load ptr, ptr %l44, !tbaa !29
  store ptr %t34, ptr %rv
  br label %ret
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_1c0ab263f2e4f7dc_3e069dbdc7ae0b68)
  unreachable
bb12:
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr %"compiler/ast:ForIn", ptr %t35, i32 0, i32 3
  %t38 = load i1, ptr %t37, !tbaa !21
  br i1 %t38, label %bb13, label %bb14
bb13:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t40)
  store ptr %t42, ptr %l48
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t43 = load ptr, ptr %l48, !tbaa !29
  store ptr %t43, ptr %l49, !tbaa !29
  %t44 = load ptr, ptr %l49, !tbaa !29
  %t45 = getelementptr %"compiler/check:frame", ptr %t44, i32 0, i32 15
  %t46 = load i64, ptr %t45, !tbaa !24
  %t48 = add i64 %t46, 1
  %t50 = load ptr, ptr %l49, !tbaa !29
  %t51 = getelementptr %"compiler/check:frame", ptr %t50, i32 0, i32 15
  store i64 %t48, ptr %t51, !tbaa !24
  br label %bb16
bb16:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l2, !tbaa !29
  %t55 = getelementptr %"compiler/ast:ForIn", ptr %t53, i32 0, i32 2
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t62 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v0, ptr %t52, ptr %t56, i32 %t58)
  store ptr %t62, ptr %l57
  br label %bb17
bb17:
  %t63 = load ptr, ptr %l57, !tbaa !29
  store ptr %t63, ptr %l7, !tbaa !29
  %t64 = load ptr, ptr %l2, !tbaa !29
  %t66 = getelementptr %"compiler/ast:ForIn", ptr %t64, i32 0, i32 3
  %t67 = load i1, ptr %t66, !tbaa !21
  br i1 %t67, label %bb18, label %bb19
bb18:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t69)
  store ptr %t71, ptr %l61
  br label %bb20
bb19:
  br label %bb21
bb20:
  %t72 = load ptr, ptr %l61, !tbaa !29
  store ptr %t72, ptr %l62, !tbaa !29
  %t73 = load ptr, ptr %l62, !tbaa !29
  %t74 = getelementptr %"compiler/check:frame", ptr %t73, i32 0, i32 15
  %t75 = load i64, ptr %t74, !tbaa !24
  %t77 = sub i64 %t75, 1
  %t79 = load ptr, ptr %l62, !tbaa !29
  %t80 = getelementptr %"compiler/check:frame", ptr %t79, i32 0, i32 15
  store i64 %t77, ptr %t80, !tbaa !24
  br label %bb21
bb21:
  %t81 = load ptr, ptr %l7, !tbaa !29
  %t84 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t81)
  store i32 %t84, ptr %l67
  br label %bb22
bb22:
  %t85 = load i32, ptr %l67, !tbaa !23
  store i32 %t85, ptr %l8, !tbaa !23
  %t86 = load i32, ptr %l8, !tbaa !23
  %t87 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t90 = icmp eq i32 %t86, %t87
  br i1 %t90, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load i32, ptr %l8, !tbaa !23
  %t97 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t93, i32 %t94)
  store i32 %t97, ptr %l74
  br label %bb26
bb26:
  %t98 = load i32, ptr %l74, !tbaa !23
  store i32 %t98, ptr %l9, !tbaa !23
  %t99 = load i32, ptr %l9, !tbaa !23
  %t100 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t103 = icmp ne i32 %t99, %t100
  br i1 %t103, label %bb27, label %bb28
bb27:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load i32, ptr %l8, !tbaa !23
  %t109 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t105, i32 %t106)
  store i1 %t109, ptr %l80
  br label %bb29
bb28:
  br label %bb75
bb29:
  %t110 = load i1, ptr %l80, !tbaa !21
  br i1 %t110, label %bb30, label %bb31
bb30:
  %t111 = load i32, ptr %l8, !tbaa !23
  store i32 %t111, ptr %l81, !tbaa !23
  br label %bb33
bb31:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/check:Checker", ptr %t113, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !29
  %t118 = getelementptr %"compiler/generic:Program", ptr %t116, i32 0, i32 2
  %t119 = load i32, ptr %l8, !tbaa !23
  %t120 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t124 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t118, i32 %t119, i64 %t120)
  store i32 %t124, ptr %l88
  br label %bb32
bb32:
  %t125 = load i32, ptr %l88, !tbaa !23
  store i32 %t125, ptr %l81, !tbaa !23
  br label %bb33
bb33:
  %t126 = load i32, ptr %l81, !tbaa !23
  store i32 %t126, ptr %l10, !tbaa !23
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load %"compiler/source:Span", ptr %l1
  %t129 = load i32, ptr %l10, !tbaa !23
  %t133 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t127, %"compiler/source:Span" %t128, i32 %t129)
  store i64 %t133, ptr %l92
  br label %bb34
bb34:
  %t134 = load i64, ptr %l92, !tbaa !24
  store i64 %t134, ptr %l11, !tbaa !24
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/check:Checker", ptr %t135, i32 0, i32 67
  store ptr %t137, ptr %l94, !tbaa !29
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t139 = load i64, ptr %l11, !tbaa !24
  %t142 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKey(ptr %v0, ptr %t138, i64 %t139)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t142, ptr %l97
  br label %bb35
bb35:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load i32, ptr %l8, !tbaa !23
  %t147 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t143, i32 %t144)
  store i1 %t147, ptr %l100
  br label %bb36
bb36:
  %t148 = load i1, ptr %l100, !tbaa !21
  br i1 %t148, label %bb37, label %bb38
bb37:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load ptr, ptr %l7, !tbaa !29
  %t154 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRef(ptr %v0, ptr %v0, ptr %t149, ptr %t150)
  store i1 %t154, ptr %l105
  br label %bb39
bb38:
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l106, !tbaa !29
  %t156 = load ptr, ptr %l7, !tbaa !29
  %t158 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %v0, ptr %t156)
  store ptr %t158, ptr %l108
  br label %bb40
bb39:
  %t159 = load i1, ptr %l105, !tbaa !21
  store i1 %t159, ptr %l101, !tbaa !21
  br label %bb42
bb40:
  %t160 = load ptr, ptr %l106, !tbaa !29
  %t161 = load ptr, ptr %l108, !tbaa !29
  %t162 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroPlace(ptr %v0, ptr %v0, ptr %t160, ptr %t161)
  store i1 %t162, ptr %l109
  br label %bb41
bb41:
  %t163 = load i1, ptr %l109, !tbaa !21
  store i1 %t163, ptr %l101, !tbaa !21
  br label %bb42
bb42:
  %t164 = load ptr, ptr %l94, !tbaa !29
  %t165 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l97
  %t166 = load i1, ptr %l101, !tbaa !21
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t164, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t165, i1 %t166)
  br label %bb43
bb43:
  %t167 = load ptr, ptr %l0, !tbaa !29
  store ptr %t167, ptr %l110, !tbaa !29
  %t168 = load ptr, ptr %l7, !tbaa !29
  store ptr %t168, ptr %l111, !tbaa !29
  %t169 = load i32, ptr %l10, !tbaa !23
  store i32 %t169, ptr %l112, !tbaa !23
  %t170 = load ptr, ptr %l2, !tbaa !29
  %t172 = getelementptr %"compiler/ast:ForIn", ptr %t170, i32 0, i32 2
  %t173 = load ptr, ptr %t172, !tbaa !29
  %t175 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t173)
  store %"compiler/source:Span" %t175, ptr %l115
  br label %bb44
bb44:
  %t176 = load ptr, ptr %l110, !tbaa !29
  %t177 = load ptr, ptr %l111, !tbaa !29
  %t178 = load i32, ptr %l112, !tbaa !23
  %t179 = load %"compiler/source:Span", ptr %l115
  %t180 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v0, ptr %v0, ptr %t176, ptr %t177, i32 %t178, %"compiler/source:Span" %t179)
  store ptr %t180, ptr %l116
  br label %bb45
bb45:
  %t181 = load ptr, ptr %l116, !tbaa !29
  store ptr %t181, ptr %l12, !tbaa !29
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t183 = load i64, ptr %l11, !tbaa !24
  %t184 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroTrack(ptr %v0, ptr %v0, ptr %t182, i64 %t183, ptr %t184)
  br label %bb46
bb46:
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t190 = load %"compiler/source:Span", ptr %l1
  %t191 = load i64, ptr %l11, !tbaa !24
  %t193 = trunc i64 %t191 to i32
  %t195 = load ptr, ptr %l12, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t196
  %t197 = getelementptr { i64, [3 x i64] }, ptr %t196, i32 0, i32 0
  store i64 0, ptr %t197
  %t199 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t190, 0
  %t201 = insertvalue { %"compiler/source:Span", i32, ptr } %t199, i32 %t193, 1
  %t203 = insertvalue { %"compiler/source:Span", i32, ptr } %t201, ptr %t195, 2
  %t204 = getelementptr { i64, [3 x i64] }, ptr %t196, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t203, ptr %t204
  %t205 = load { i64, [3 x i64] }, ptr %t196
  %t207 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t205, ptr %t207
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t189, ptr %t207)
  br label %bb47
bb47:
  %t210 = load ptr, ptr %l0, !tbaa !29
  store ptr %t210, ptr %l129, !tbaa !29
  %t211 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t211, ptr %l130
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t212)
  store i32 %t214, ptr %l132
  br label %bb48
bb48:
  %t215 = load ptr, ptr %l129, !tbaa !29
  %t216 = load %"compiler/source:Span", ptr %l130
  %t217 = load i32, ptr %l132, !tbaa !23
  %t218 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t215, %"compiler/source:Span" %t216, i32 %t217)
  store i64 %t218, ptr %l133
  br label %bb49
bb49:
  %t219 = load i64, ptr %l133, !tbaa !24
  store i64 %t219, ptr %l13, !tbaa !24
  %t220 = load ptr, ptr %l0, !tbaa !29
  store ptr %t220, ptr %l134, !tbaa !29
  %t221 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t221, ptr %l135
  %t222 = load i64, ptr %l13, !tbaa !24
  %t224 = trunc i64 %t222 to i32
  store i32 %t224, ptr %l138, !tbaa !23
  %t226 = load ptr, ptr %l0, !tbaa !29
  store ptr %t226, ptr %l139, !tbaa !29
  %t227 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t227, ptr %l140
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t230 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t228)
  store i32 %t230, ptr %l142
  br label %bb50
bb50:
  %t231 = load ptr, ptr %l139, !tbaa !29
  %t232 = load %"compiler/source:Span", ptr %l140
  %t233 = load i32, ptr %l142, !tbaa !23
  %t234 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t231, %"compiler/source:Span" %t232, i32 %t233, i64 0)
  store ptr %t234, ptr %l143
  br label %bb51
bb51:
  store { i64, [3 x i64] } zeroinitializer, ptr %t235
  %t236 = getelementptr { i64, [3 x i64] }, ptr %t235, i32 0, i32 0
  store i64 0, ptr %t236
  %t237 = load %"compiler/source:Span", ptr %l135
  %t238 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t237, 0
  %t239 = load i32, ptr %l138, !tbaa !23
  %t240 = insertvalue { %"compiler/source:Span", i32, ptr } %t238, i32 %t239, 1
  %t241 = load ptr, ptr %l143, !tbaa !29
  %t242 = insertvalue { %"compiler/source:Span", i32, ptr } %t240, ptr %t241, 2
  %t243 = getelementptr { i64, [3 x i64] }, ptr %t235, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t242, ptr %t243
  %t244 = load { i64, [3 x i64] }, ptr %t235
  %t246 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t244, ptr %t246
  %t247 = load ptr, ptr %l134, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t247, ptr %t246)
  br label %bb52
bb52:
  %t249 = load ptr, ptr %l0, !tbaa !29
  store ptr %t249, ptr %l146, !tbaa !29
  %t250 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t250, ptr %l147
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t253 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t251)
  store i32 %t253, ptr %l149
  br label %bb53
bb53:
  %t254 = load ptr, ptr %l146, !tbaa !29
  %t255 = load %"compiler/source:Span", ptr %l147
  %t256 = load i32, ptr %l149, !tbaa !23
  %t257 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t254, %"compiler/source:Span" %t255, i32 %t256)
  store i64 %t257, ptr %l150
  br label %bb54
bb54:
  %t258 = load i64, ptr %l150, !tbaa !24
  store i64 %t258, ptr %l14, !tbaa !24
  %t259 = load ptr, ptr %l0, !tbaa !29
  store ptr %t259, ptr %l151, !tbaa !29
  %t260 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t260, ptr %l152
  %t261 = load i64, ptr %l14, !tbaa !24
  %t263 = trunc i64 %t261 to i32
  store i32 %t263, ptr %l155, !tbaa !23
  %t265 = load ptr, ptr %l0, !tbaa !29
  store ptr %t265, ptr %l156, !tbaa !29
  %t266 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t266, ptr %l157
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t269 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t267)
  store i32 %t269, ptr %l159
  br label %bb55
bb55:
  store i32 22, ptr %l160
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t271 = load %"compiler/source:Span", ptr %l1
  %t272 = load i64, ptr %l11, !tbaa !24
  %t276 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t270, %"compiler/source:Span" %t271, i64 %t272)
  store ptr %t276, ptr %l164
  br label %bb56
bb56:
  %t277 = load ptr, ptr %l156, !tbaa !29
  %t278 = load %"compiler/source:Span", ptr %l157
  %t279 = load i32, ptr %l159, !tbaa !23
  %t280 = load i32, ptr %l160, !range !{i32 0, i32 43}
  %t281 = load ptr, ptr %l164, !tbaa !29
  %t282 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t277, %"compiler/source:Span" %t278, i32 %t279, i32 %t280, ptr %t281, ptr null)
  store ptr %t282, ptr %l165
  br label %bb57
bb57:
  store { i64, [3 x i64] } zeroinitializer, ptr %t283
  %t284 = getelementptr { i64, [3 x i64] }, ptr %t283, i32 0, i32 0
  store i64 0, ptr %t284
  %t285 = load %"compiler/source:Span", ptr %l152
  %t286 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t285, 0
  %t287 = load i32, ptr %l155, !tbaa !23
  %t288 = insertvalue { %"compiler/source:Span", i32, ptr } %t286, i32 %t287, 1
  %t289 = load ptr, ptr %l165, !tbaa !29
  %t290 = insertvalue { %"compiler/source:Span", i32, ptr } %t288, ptr %t289, 2
  %t291 = getelementptr { i64, [3 x i64] }, ptr %t283, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t290, ptr %t291
  %t292 = load { i64, [3 x i64] }, ptr %t283
  %t294 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t292, ptr %t294
  %t295 = load ptr, ptr %l151, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t295, ptr %t294)
  br label %bb58
bb58:
  %t297 = load ptr, ptr %l3, !tbaa !29
  %t299 = icmp eq ptr %t297, null
  %t301 = xor i1 %t299, true
  br i1 %t301, label %bb59, label %bb60
bb59:
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t305 = getelementptr %"compiler/check:Checker", ptr %t303, i32 0, i32 1
  %t306 = load ptr, ptr %t305, !tbaa !29
  %t308 = getelementptr %"compiler/generic:Program", ptr %t306, i32 0, i32 2
  %t309 = load i32, ptr %l9, !tbaa !23
  %t312 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t308, i32 %t309)
  store i32 %t312, ptr %l176
  br label %bb61
bb60:
  store i1 false, ptr %l171, !tbaa !21
  br label %bb62
bb61:
  %t313 = load i32, ptr %l176, !tbaa !23
  %t314 = icmp ne i32 %t313, 0
  store i1 %t314, ptr %l171, !tbaa !21
  br label %bb62
bb62:
  %t316 = load i1, ptr %l171, !tbaa !21
  br i1 %t316, label %bb63, label %bb64
bb63:
  %t317 = load ptr, ptr %l0, !tbaa !29
  %t319 = getelementptr %"compiler/check:Checker", ptr %t317, i32 0, i32 1
  %t320 = load ptr, ptr %t319, !tbaa !29
  %t322 = getelementptr %"compiler/generic:Program", ptr %t320, i32 0, i32 2
  store ptr %t322, ptr %l181, !tbaa !29
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t325 = getelementptr %"compiler/check:Checker", ptr %t323, i32 0, i32 1
  %t326 = load ptr, ptr %t325, !tbaa !29
  %t328 = getelementptr %"compiler/generic:Program", ptr %t326, i32 0, i32 2
  %t329 = load i32, ptr %l9, !tbaa !23
  %t332 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t328, i32 %t329)
  store i32 %t332, ptr %l186
  br label %bb65
bb64:
  store i1 false, ptr %l178, !tbaa !21
  br label %bb67
bb65:
  %t333 = load ptr, ptr %l181, !tbaa !29
  %t334 = load i32, ptr %l186, !tbaa !23
  %t335 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t333, i32 %t334)
  store i32 %t335, ptr %l187
  br label %bb66
bb66:
  %t336 = load i32, ptr %l187, !range !{i32 0, i32 33}
  %t338 = trunc i64 26 to i32
  %t339 = icmp eq i32 %t336, %t338
  store i1 %t339, ptr %l178, !tbaa !21
  br label %bb67
bb67:
  %t341 = load i1, ptr %l178, !tbaa !21
  br i1 %t341, label %bb68, label %bb69
bb68:
  %t342 = load ptr, ptr %l0, !tbaa !29
  store ptr %t342, ptr %l190, !tbaa !29
  %t343 = load ptr, ptr %l0, !tbaa !29
  %t345 = getelementptr %"compiler/check:Checker", ptr %t343, i32 0, i32 1
  %t346 = load ptr, ptr %t345, !tbaa !29
  %t348 = getelementptr %"compiler/generic:Program", ptr %t346, i32 0, i32 2
  store ptr %t348, ptr %l193, !tbaa !29
  %t349 = load ptr, ptr %l0, !tbaa !29
  %t351 = getelementptr %"compiler/check:Checker", ptr %t349, i32 0, i32 1
  %t352 = load ptr, ptr %t351, !tbaa !29
  %t354 = getelementptr %"compiler/generic:Program", ptr %t352, i32 0, i32 2
  %t355 = load i32, ptr %l9, !tbaa !23
  %t358 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t354, i32 %t355)
  store i32 %t358, ptr %l198
  br label %bb70
bb69:
  br label %bb72
bb70:
  %t359 = load ptr, ptr %l193, !tbaa !29
  %t360 = load i32, ptr %l198, !tbaa !23
  %t361 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t359, i32 %t360)
  store i64 %t361, ptr %l199
  br label %bb71
bb71:
  %t362 = load i64, ptr %l199, !tbaa !24
  %t363 = load ptr, ptr %l190, !tbaa !29
  %t364 = getelementptr %"compiler/check:Checker", ptr %t363, i32 0, i32 103
  store i64 %t362, ptr %t364, !tbaa !24
  br label %bb72
bb72:
  %t365 = load ptr, ptr %l0, !tbaa !29
  %t366 = load %"compiler/source:Span", ptr %l1
  %t367 = load ptr, ptr %l2, !tbaa !29
  %t368 = load i64, ptr %l13, !tbaa !24
  %t369 = load i64, ptr %l14, !tbaa !24
  %t370 = load i64, ptr %l11, !tbaa !24
  %t371 = load i32, ptr %l9, !tbaa !23
  %t372 = load ptr, ptr %l3, !tbaa !29
  %t373 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecounted(ptr %v0, ptr %v1, ptr %v2, ptr %t365, %"compiler/source:Span" %t366, ptr %t367, i64 %t368, i64 %t369, i64 %t370, i32 %t371, i64 -1, i64 -1, ptr %t372, i32 %t373)
  br label %bb73
bb73:
  %t383 = load ptr, ptr %l0, !tbaa !29
  %t384 = load %"compiler/source:Span", ptr %l1
  %t385 = load i64, ptr %l14, !tbaa !24
  %t389 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v3, ptr %t383, %"compiler/source:Span" %t384, i64 %t385)
  store ptr %t389, ptr %l212
  br label %bb74
bb74:
  %t390 = load ptr, ptr %l212, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t390, ptr %rv
  br label %ret
bb75:
  %t392 = load ptr, ptr %l3, !tbaa !29
  %t394 = icmp eq ptr %t392, null
  %t396 = xor i1 %t394, true
  br i1 %t396, label %bb76, label %bb77
bb76:
  %t398 = load ptr, ptr %l0, !tbaa !29
  %t399 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecomprOpen(ptr %v0, ptr %t398, %"compiler/source:Span" %t399)
  br label %bb78
bb77:
  br label %bb79
bb78:
  br label %bb79
bb79:
  %t402 = load ptr, ptr %l0, !tbaa !29
  %t403 = load i32, ptr %l8, !tbaa !23
  %t406 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t402, i32 %t403)
  store i32 %t406, ptr %l221
  br label %bb80
bb80:
  %t407 = load i32, ptr %l221, !tbaa !23
  store i32 %t407, ptr %l15, !tbaa !23
  %t408 = load ptr, ptr %l0, !tbaa !29
  %t410 = getelementptr %"compiler/check:Checker", ptr %t408, i32 0, i32 1
  %t411 = load ptr, ptr %t410, !tbaa !29
  %t413 = getelementptr %"compiler/generic:Program", ptr %t411, i32 0, i32 2
  %t414 = load i32, ptr %l15, !tbaa !23
  %t417 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t413, i32 %t414)
  store i32 %t417, ptr %l226
  br label %bb81
bb81:
  %t418 = load i32, ptr %l226, !range !{i32 0, i32 33}
  %t420 = trunc i64 29 to i32
  %t421 = icmp eq i32 %t418, %t420
  br i1 %t421, label %bb82, label %bb83
bb82:
  store %olang.scope zeroinitializer, ptr %s9
  %t423 = load ptr, ptr %l0, !tbaa !29
  %t425 = getelementptr %"compiler/check:Checker", ptr %t423, i32 0, i32 1
  %t426 = load ptr, ptr %t425, !tbaa !29
  store ptr %t426, ptr %l230, !tbaa !29
  %t427 = load ptr, ptr %l0, !tbaa !29
  %t429 = getelementptr %"compiler/check:Checker", ptr %t427, i32 0, i32 1
  %t430 = load ptr, ptr %t429, !tbaa !29
  %t432 = getelementptr %"compiler/generic:Program", ptr %t430, i32 0, i32 2
  %t433 = load i32, ptr %l15, !tbaa !23
  %t436 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %t432, i32 %t433)
  store i32 %t436, ptr %l235
  br label %bb84
bb83:
  br label %bb113
bb84:
  %t437 = load ptr, ptr %l230, !tbaa !29
  %t438 = load i32, ptr %l235, !tbaa !23
  %t439 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %v0, ptr %t437, i32 %t438)
  store { i64, ptr } %t439, ptr %l236
  br label %bb85
bb85:
  %t440 = load { i64, ptr }, ptr %l236, !tbaa !27
  store { i64, ptr } %t440, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t441 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t443 = extractvalue { i64, ptr } %t441, 0
  store i64 %t443, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t445 = load i64, ptr %l18, !tbaa !24
  %t446 = load i64, ptr %l17, !tbaa !24
  %t449 = icmp sgt i64 %t445, %t446
  br i1 %t449, label %bb86, label %bb87
bb86:
  %t451 = load i64, ptr %l19, !tbaa !24
  %t453 = icmp sgt i64 %t451, 0
  br i1 %t453, label %bb88, label %bb89
bb87:
  store i64 0, ptr %l242, !tbaa !24
  br label %bb91
bb88:
  %t455 = load i64, ptr %l18, !tbaa !24
  %t456 = load i64, ptr %l17, !tbaa !24
  %t459 = sub i64 %t455, %t456
  %t460 = load i64, ptr %l19, !tbaa !24
  %t463 = add i64 %t459, %t460
  %t465 = sub i64 %t463, 1
  %t466 = load i64, ptr %l19, !tbaa !24
  %t469 = sdiv i64 %t465, %t466
  store i64 %t469, ptr %l245, !tbaa !24
  br label %bb90
bb89:
  store i64 0, ptr %l245, !tbaa !24
  br label %bb90
bb90:
  %t471 = load i64, ptr %l245, !tbaa !24
  store i64 %t471, ptr %l242, !tbaa !24
  br label %bb91
bb91:
  %t472 = load i64, ptr %l242, !tbaa !24
  store i64 %t472, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb92
bb92:
  store %olang.scope zeroinitializer, ptr %s11
  %t473 = load i64, ptr %l21, !tbaa !24
  %t474 = load i64, ptr %l20, !tbaa !24
  %t477 = icmp slt i64 %t473, %t474
  %t479 = xor i1 %t477, true
  br i1 %t479, label %bb93, label %bb94
bb93:
  call void @__olang_scope_close(ptr %s11)
  br label %bb108
bb94:
  br label %bb95
bb95:
  %t481 = load i64, ptr %l17, !tbaa !24
  %t482 = load i64, ptr %l21, !tbaa !24
  %t483 = load i64, ptr %l19, !tbaa !24
  %t486 = mul i64 %t482, %t483
  %t489 = add i64 %t481, %t486
  store i64 %t489, ptr %l22, !tbaa !24
  %t491 = load ptr, ptr %l0, !tbaa !29
  %t492 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t492, ptr %l264, !tbaa !27
  %t493 = load i64, ptr %l22, !tbaa !24
  %t495 = getelementptr { i64, ptr }, ptr %l264, i32 0, i32 1
  %t496 = load ptr, ptr %t495, !tbaa !27
  %t497 = getelementptr %"compiler/generic:AnySlot", ptr %t496, i64 %t493
  %t498 = getelementptr %"compiler/generic:AnySlot", ptr %t497, i32 0, i32 0
  %t499 = load i32, ptr %t498, !tbaa !23
  %t502 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t491, i32 %t499)
  store { i64, ptr } %t502, ptr %l267
  br label %bb96
bb96:
  %t503 = load { i64, ptr }, ptr %l267, !tbaa !27
  %t504 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s11, { i64, ptr } %t503, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d45, i32 0, i32 1) })
  store i1 %t504, ptr %l268
  br label %bb97
bb97:
  %t505 = load i1, ptr %l268, !tbaa !21
  br i1 %t505, label %bb98, label %bb99
bb98:
  %t506 = load ptr, ptr %l0, !tbaa !29
  %t508 = getelementptr %"compiler/check:Checker", ptr %t506, i32 0, i32 1
  %t509 = load ptr, ptr %t508, !tbaa !29
  %t511 = getelementptr %"compiler/generic:Program", ptr %t509, i32 0, i32 2
  store ptr %t511, ptr %l272, !tbaa !29
  %t512 = load ptr, ptr %l0, !tbaa !29
  %t514 = getelementptr %"compiler/check:Checker", ptr %t512, i32 0, i32 1
  %t515 = load ptr, ptr %t514, !tbaa !29
  %t517 = getelementptr %"compiler/generic:Program", ptr %t515, i32 0, i32 2
  %t518 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t518, ptr %l276, !tbaa !27
  %t519 = load i64, ptr %l22, !tbaa !24
  %t521 = getelementptr { i64, ptr }, ptr %l276, i32 0, i32 1
  %t522 = load ptr, ptr %t521, !tbaa !27
  %t523 = getelementptr %"compiler/generic:AnySlot", ptr %t522, i64 %t519
  %t524 = getelementptr %"compiler/generic:AnySlot", ptr %t523, i32 0, i32 5
  %t525 = load i32, ptr %t524, !tbaa !23
  %t528 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t517, i32 %t525)
  store i32 %t528, ptr %l279
  br label %bb100
bb99:
  store i1 false, ptr %l269, !tbaa !21
  br label %bb102
bb100:
  %t529 = load ptr, ptr %l272, !tbaa !29
  %t530 = load i32, ptr %l279, !tbaa !23
  %t531 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s11, ptr %t529, i32 %t530)
  store { i64, ptr } %t531, ptr %l280
  br label %bb101
bb101:
  %t532 = load { i64, ptr }, ptr %l280, !tbaa !27
  %t533 = extractvalue { i64, ptr } %t532, 0
  %t535 = icmp eq i64 %t533, 1
  store i1 %t535, ptr %l269, !tbaa !21
  br label %bb102
bb102:
  %t537 = load i1, ptr %l269, !tbaa !21
  br i1 %t537, label %bb103, label %bb104
bb103:
  %t538 = load ptr, ptr %l0, !tbaa !29
  %t539 = load %"compiler/source:Span", ptr %l1
  %t540 = load ptr, ptr %l2, !tbaa !29
  %t541 = load ptr, ptr %l7, !tbaa !29
  %t542 = load i64, ptr %l22, !tbaa !24
  %t544 = sub i64 -2, %t542
  %t545 = load ptr, ptr %l3, !tbaa !29
  %t546 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkIter(ptr %v0, ptr %v1, ptr %v0, ptr %v2, ptr %t538, %"compiler/source:Span" %t539, ptr %t540, ptr %t541, i64 %t544, ptr %t545, i32 %t546)
  br label %bb105
bb104:
  br label %bb106
bb105:
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb106:
  call void @__olang_scope_close(ptr %s11)
  br label %bb107
bb107:
  %t555 = load i64, ptr %l21, !tbaa !24
  %t557 = add i64 %t555, 1
  store i64 %t557, ptr %l21, !tbaa !24
  br label %bb92
bb108:
  %t559 = load ptr, ptr %l0, !tbaa !29
  store ptr %t559, ptr %l294, !tbaa !29
  %t560 = load ptr, ptr %l2, !tbaa !29
  %t562 = getelementptr %"compiler/ast:ForIn", ptr %t560, i32 0, i32 2
  %t563 = load ptr, ptr %t562, !tbaa !29
  %t565 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t563)
  store %"compiler/source:Span" %t565, ptr %l297
  br label %bb109
bb109:
  %t566 = load ptr, ptr %l0, !tbaa !29
  %t567 = load i32, ptr %l8, !tbaa !23
  %t570 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s9, ptr %t566, i32 %t567)
  store { i64, ptr } %t570, ptr %l300
  br label %bb110
bb110:
  %t571 = load { i64, ptr }, ptr %l300, !tbaa !27
  %t572 = extractvalue { i64, ptr } %t571, 0
  %t573 = extractvalue { i64, ptr } %t571, 1
  %t574 = mul i64 %t572, 1
  %t575 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t574)
  call void @llvm.memcpy.p0.p0.i64(ptr %t575, ptr %t573, i64 %t574, i1 false)
  %t576 = insertvalue { i64, ptr } undef, i64 %t572, 0
  %t577 = insertvalue { i64, ptr } %t576, ptr %t575, 1
  %t579 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotIterable(ptr %s9, ptr %s9, { i64, ptr } %t577)
  store %"compiler/msgs:Msg" %t579, ptr %l302
  br label %bb111
bb111:
  %t580 = load ptr, ptr %l294, !tbaa !29
  %t581 = load %"compiler/source:Span", ptr %l297
  %t582 = load %"compiler/msgs:Msg", ptr %l302
  %t583 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s9, ptr %t580, %"compiler/source:Span" %t581, %"compiler/msgs:Msg" %t582)
  store i64 %t583, ptr %l303
  br label %bb112
bb112:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb113:
  %t585 = load ptr, ptr %l0, !tbaa !29
  %t586 = load i32, ptr %l15, !tbaa !23
  %t587 = load %"compiler/source:Span", ptr %l1
  %t591 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleUse(ptr %v0, ptr %s0, ptr %s0, ptr %t585, i32 %t586, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d46, i32 0, i32 1) }, i64 1, %"compiler/source:Span" %t587, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d47, i32 0, i32 1) })
  store i64 %t591, ptr %l308
  br label %bb114
bb114:
  %t592 = load i64, ptr %l308, !tbaa !24
  store i64 %t592, ptr %l23, !tbaa !24
  %t593 = load ptr, ptr %l0, !tbaa !29
  %t594 = load i32, ptr %l15, !tbaa !23
  %t595 = load %"compiler/source:Span", ptr %l1
  %t599 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleUse(ptr %v0, ptr %s0, ptr %s0, ptr %t593, i32 %t594, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d48, i32 0, i32 1) }, i64 0, %"compiler/source:Span" %t595, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d49, i32 0, i32 1) })
  store i64 %t599, ptr %l312
  br label %bb115
bb115:
  %t600 = load i64, ptr %l312, !tbaa !24
  store i64 %t600, ptr %l24, !tbaa !24
  %t601 = load i64, ptr %l24, !tbaa !24
  %t603 = icmp sge i64 %t601, 0
  br i1 %t603, label %bb116, label %bb117
bb116:
  %t605 = load ptr, ptr %l0, !tbaa !29
  %t606 = load i64, ptr %l24, !tbaa !24
  %t609 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eiterShaped(ptr %v0, ptr %t605, i64 %t606)
  store i1 %t609, ptr %l318
  br label %bb118
bb117:
  store i1 false, ptr %l315, !tbaa !21
  br label %bb119
bb118:
  %t610 = load i1, ptr %l318, !tbaa !21
  %t611 = xor i1 %t610, true
  store i1 %t611, ptr %l315, !tbaa !21
  br label %bb119
bb119:
  %t613 = load i1, ptr %l315, !tbaa !21
  br i1 %t613, label %bb120, label %bb121
bb120:
  store i64 -1, ptr %l24, !tbaa !24
  br label %bb122
bb121:
  br label %bb122
bb122:
  %t614 = load i64, ptr %l23, !tbaa !24
  %t616 = icmp sge i64 %t614, 0
  br i1 %t616, label %bb123, label %bb124
bb123:
  %t618 = load i64, ptr %l24, !tbaa !24
  %t620 = icmp slt i64 %t618, 0
  store i1 %t620, ptr %l322, !tbaa !21
  br label %bb125
bb124:
  store i1 false, ptr %l322, !tbaa !21
  br label %bb125
bb125:
  %t622 = load i1, ptr %l322, !tbaa !21
  br i1 %t622, label %bb126, label %bb127
bb126:
  %t623 = load ptr, ptr %l0, !tbaa !29
  %t624 = load %"compiler/source:Span", ptr %l1
  %t625 = load ptr, ptr %l2, !tbaa !29
  %t626 = load ptr, ptr %l7, !tbaa !29
  %t627 = load i64, ptr %l23, !tbaa !24
  %t628 = load ptr, ptr %l3, !tbaa !29
  %t629 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkRuns(ptr %v0, ptr %v1, ptr %v0, ptr %v2, ptr %t623, %"compiler/source:Span" %t624, ptr %t625, ptr %t626, i64 %t627, ptr %t628, i32 %t629)
  br label %bb128
bb127:
  br label %bb129
bb128:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb129:
  %t638 = load i64, ptr %l24, !tbaa !24
  %t640 = icmp sge i64 %t638, 0
  br i1 %t640, label %bb130, label %bb131
bb130:
  %t642 = load ptr, ptr %l0, !tbaa !29
  %t643 = load %"compiler/source:Span", ptr %l1
  %t644 = load ptr, ptr %l2, !tbaa !29
  %t645 = load ptr, ptr %l7, !tbaa !29
  %t646 = load i64, ptr %l24, !tbaa !24
  %t647 = load ptr, ptr %l3, !tbaa !29
  %t648 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkIter(ptr %v0, ptr %v1, ptr %v0, ptr %v2, ptr %t642, %"compiler/source:Span" %t643, ptr %t644, ptr %t645, i64 %t646, ptr %t647, i32 %t648)
  br label %bb132
bb131:
  br label %bb133
bb132:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb133:
  %t657 = load ptr, ptr %l0, !tbaa !29
  %t658 = load i32, ptr %l15, !tbaa !23
  %t659 = load %"compiler/source:Span", ptr %l1
  %t663 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleUse(ptr %v0, ptr %s0, ptr %s0, ptr %t657, i32 %t658, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d50, i32 0, i32 1) }, i64 0, %"compiler/source:Span" %t659, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d51, i32 0, i32 1) })
  store i64 %t663, ptr %l346
  br label %bb134
bb134:
  %t664 = load i64, ptr %l346, !tbaa !24
  store i64 %t664, ptr %l25, !tbaa !24
  %t665 = load i64, ptr %l25, !tbaa !24
  %t667 = icmp sge i64 %t665, 0
  br i1 %t667, label %bb135, label %bb136
bb135:
  store %olang.scope zeroinitializer, ptr %s17
  %t669 = load ptr, ptr %l0, !tbaa !29
  store ptr %t669, ptr %l349, !tbaa !29
  %t670 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t670, ptr %l350
  %t671 = load ptr, ptr %l2, !tbaa !29
  %t673 = getelementptr %"compiler/ast:ForIn", ptr %t671, i32 0, i32 2
  %t674 = load ptr, ptr %t673, !tbaa !29
  %t676 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t674)
  store %"compiler/source:Span" %t676, ptr %l353
  br label %bb137
bb136:
  br label %bb160
bb137:
  %t677 = load i64, ptr %l25, !tbaa !24
  store i64 %t677, ptr %l354, !tbaa !24
  %t678 = load ptr, ptr %l7, !tbaa !29
  store ptr %t678, ptr %l356, !tbaa !29
  %t680 = icmp sge i64 0, 0
  br i1 %t680, label %bb138, label %bb139
bb138:
  %t682 = icmp sle i64 0, 1152921504606846975
  br i1 %t682, label %bb140, label %bb141
bb139:
  call void @__olang_check_failed(ptr @olang_loc_139af6e2a2dcda96_1438f6a9e620193a)
  unreachable
bb140:
  %t684 = mul i64 0, 8
  %t685 = insertvalue { i64, ptr } undef, i64 0, 0
  %t686 = insertvalue { i64, ptr } %t685, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t686, ptr %l359, !tbaa !27
  %t687 = icmp sge i64 0, 0
  br i1 %t687, label %bb142, label %bb143
bb141:
  call void @__olang_check_failed(ptr @olang_loc_139af6e2a2dcda96_1438f6a9e620193a)
  unreachable
bb142:
  %t689 = icmp sle i64 0, 1152921504606846975
  br i1 %t689, label %bb144, label %bb145
bb143:
  call void @__olang_check_failed(ptr @olang_loc_139af6e2a2dcda96_1438f6a9e620193a)
  unreachable
bb144:
  %t691 = mul i64 0, 8
  %t692 = insertvalue { i64, ptr } undef, i64 0, 0
  %t693 = insertvalue { i64, ptr } %t692, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t693, ptr %l362, !tbaa !27
  %t694 = icmp sge i64 0, 0
  br i1 %t694, label %bb146, label %bb147
bb145:
  call void @__olang_check_failed(ptr @olang_loc_139af6e2a2dcda96_1438f6a9e620193a)
  unreachable
bb146:
  %t696 = icmp sle i64 0, 2305843009213693951
  br i1 %t696, label %bb148, label %bb149
bb147:
  call void @__olang_check_failed(ptr @olang_loc_a734531b29123b5_def2307fb88201b9)
  unreachable
bb148:
  %t698 = mul i64 0, 4
  %t699 = insertvalue { i64, ptr } undef, i64 0, 0
  %t700 = insertvalue { i64, ptr } %t699, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t701 = load ptr, ptr %l349, !tbaa !29
  %t702 = load %"compiler/source:Span", ptr %l350
  %t703 = load %"compiler/source:Span", ptr %l353
  %t704 = load i64, ptr %l354, !tbaa !24
  %t705 = load ptr, ptr %l356, !tbaa !29
  %t706 = load { i64, ptr }, ptr %l359, !tbaa !27
  %t707 = load { i64, ptr }, ptr %l362, !tbaa !27
  %t709 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t701, %"compiler/source:Span" %t702, %"compiler/source:Span" %t703, i64 %t704, ptr %t705, { i64, ptr } %t706, { i64, ptr } %t707, { i64, ptr } %t700)
  store ptr %t709, ptr %l366
  br label %bb150
bb149:
  call void @__olang_check_failed(ptr @olang_loc_a734531b29123b5_def2307fb88201b9)
  unreachable
bb150:
  %t710 = load ptr, ptr %l366, !tbaa !29
  store ptr %t710, ptr %l26, !tbaa !29
  %t711 = load ptr, ptr %l0, !tbaa !29
  store ptr %t711, ptr %l367, !tbaa !29
  %t712 = load ptr, ptr %l0, !tbaa !29
  store ptr %t712, ptr %l368, !tbaa !29
  %t713 = load ptr, ptr %l26, !tbaa !29
  %t716 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t713)
  store i32 %t716, ptr %l371
  br label %bb151
bb151:
  %t717 = load ptr, ptr %l368, !tbaa !29
  %t718 = load i32, ptr %l371, !tbaa !23
  %t719 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t717, i32 %t718)
  store i32 %t719, ptr %l372
  br label %bb152
bb152:
  %t720 = load ptr, ptr %l367, !tbaa !29
  %t721 = load i32, ptr %l372, !tbaa !23
  %t722 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s17, ptr %t720, i32 %t721, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d52, i32 0, i32 1) }, i64 0)
  store i64 %t722, ptr %l373
  br label %bb153
bb153:
  %t723 = load i64, ptr %l373, !tbaa !24
  store i64 %t723, ptr %l27, !tbaa !24
  %t724 = load i64, ptr %l27, !tbaa !24
  %t726 = icmp slt i64 %t724, 0
  br i1 %t726, label %bb154, label %bb155
bb154:
  store %olang.scope zeroinitializer, ptr %s18
  %t728 = load ptr, ptr %l0, !tbaa !29
  store ptr %t728, ptr %l376, !tbaa !29
  %t729 = load ptr, ptr %l2, !tbaa !29
  %t731 = getelementptr %"compiler/ast:ForIn", ptr %t729, i32 0, i32 2
  %t732 = load ptr, ptr %t731, !tbaa !29
  %t734 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t732)
  store %"compiler/source:Span" %t734, ptr %l379
  br label %bb156
bb155:
  br label %bb158
bb156:
  %t735 = load ptr, ptr %l376, !tbaa !29
  %t736 = load %"compiler/source:Span", ptr %l379
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s18, ptr %t735, %"compiler/source:Span" %t736, { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d53, i32 0, i32 1) })
  br label %bb157
bb157:
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb158:
  %t738 = load ptr, ptr %l0, !tbaa !29
  %t739 = load %"compiler/source:Span", ptr %l1
  %t740 = load ptr, ptr %l2, !tbaa !29
  %t741 = load ptr, ptr %l26, !tbaa !29
  %t742 = load i64, ptr %l27, !tbaa !24
  %t743 = load ptr, ptr %l3, !tbaa !29
  %t744 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkIter(ptr %v0, ptr %v1, ptr %v0, ptr %v2, ptr %t738, %"compiler/source:Span" %t739, ptr %t740, ptr %t741, i64 %t742, ptr %t743, i32 %t744)
  br label %bb159
bb159:
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb160:
  %t753 = load ptr, ptr %l0, !tbaa !29
  %t754 = load i32, ptr %l15, !tbaa !23
  %t755 = load %"compiler/source:Span", ptr %l1
  %t759 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleUse(ptr %v0, ptr %s0, ptr %s0, ptr %t753, i32 %t754, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d54, i32 0, i32 1) }, i64 1, %"compiler/source:Span" %t755, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d55, i32 0, i32 1) })
  store i64 %t759, ptr %l392
  br label %bb161
bb161:
  %t760 = load i64, ptr %l392, !tbaa !24
  store i64 %t760, ptr %l28, !tbaa !24
  %t761 = load ptr, ptr %l0, !tbaa !29
  %t762 = load i32, ptr %l15, !tbaa !23
  %t765 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s0, ptr %t761, i32 %t762, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d56, i32 0, i32 1) }, i64 0)
  store i64 %t765, ptr %l395
  br label %bb162
bb162:
  %t766 = load i64, ptr %l395, !tbaa !24
  store i64 %t766, ptr %l29, !tbaa !24
  %t767 = load i64, ptr %l28, !tbaa !24
  %t769 = icmp sge i64 %t767, 0
  br i1 %t769, label %bb163, label %bb164
bb163:
  %t771 = load ptr, ptr %l0, !tbaa !29
  %t773 = getelementptr %"compiler/check:Checker", ptr %t771, i32 0, i32 1
  %t774 = load ptr, ptr %t773, !tbaa !29
  %t776 = getelementptr %"compiler/generic:Program", ptr %t774, i32 0, i32 2
  store ptr %t776, ptr %l401, !tbaa !29
  %t777 = load ptr, ptr %l0, !tbaa !29
  %t779 = getelementptr %"compiler/check:Checker", ptr %t777, i32 0, i32 1
  %t780 = load ptr, ptr %t779, !tbaa !29
  %t782 = getelementptr %"compiler/generic:Program", ptr %t780, i32 0, i32 2
  store ptr %t782, ptr %l404, !tbaa !29
  %t783 = load ptr, ptr %l0, !tbaa !29
  %t785 = getelementptr %"compiler/check:Checker", ptr %t783, i32 0, i32 1
  %t786 = load ptr, ptr %t785, !tbaa !29
  %t787 = load i64, ptr %l28, !tbaa !24
  %t790 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t786, i64 %t787)
  store i32 %t790, ptr %l408
  br label %bb165
bb164:
  store i1 false, ptr %l398, !tbaa !21
  br label %bb168
bb165:
  %t791 = load ptr, ptr %l404, !tbaa !29
  %t792 = load i32, ptr %l408, !tbaa !23
  %t793 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t791, i32 %t792)
  store i32 %t793, ptr %l409
  br label %bb166
bb166:
  %t794 = load ptr, ptr %l401, !tbaa !29
  %t795 = load i32, ptr %l409, !tbaa !23
  %t796 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t794, i32 %t795)
  store { i64, ptr } %t796, ptr %l410
  br label %bb167
bb167:
  %t797 = load { i64, ptr }, ptr %l410, !tbaa !27
  %t798 = extractvalue { i64, ptr } %t797, 0
  %t800 = icmp sgt i64 %t798, 0
  store i1 %t800, ptr %l398, !tbaa !21
  br label %bb168
bb168:
  %t802 = load i1, ptr %l398, !tbaa !21
  br i1 %t802, label %bb169, label %bb170
bb169:
  %t803 = load ptr, ptr %l0, !tbaa !29
  %t805 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t803)
  store ptr %t805, ptr %l414
  br label %bb171
bb170:
  br label %bb172
bb171:
  %t806 = load ptr, ptr %l414, !tbaa !29
  store ptr %t806, ptr %l415, !tbaa !29
  %t807 = load ptr, ptr %l415, !tbaa !29
  %t808 = getelementptr %"compiler/check:frame", ptr %t807, i32 0, i32 17
  %t809 = load i64, ptr %t808, !tbaa !24
  %t811 = add i64 %t809, 1
  %t813 = load ptr, ptr %l415, !tbaa !29
  %t814 = getelementptr %"compiler/check:frame", ptr %t813, i32 0, i32 17
  store i64 %t811, ptr %t814, !tbaa !24
  br label %bb172
bb172:
  %t815 = load i64, ptr %l28, !tbaa !24
  %t817 = icmp sge i64 %t815, 0
  br i1 %t817, label %bb173, label %bb174
bb173:
  %t819 = load i64, ptr %l29, !tbaa !24
  %t821 = icmp sge i64 %t819, 0
  store i1 %t821, ptr %l420, !tbaa !21
  br label %bb175
bb174:
  store i1 false, ptr %l420, !tbaa !21
  br label %bb175
bb175:
  %t823 = load i1, ptr %l420, !tbaa !21
  br i1 %t823, label %bb176, label %bb177
bb176:
  %t824 = load ptr, ptr %l0, !tbaa !29
  %t825 = load %"compiler/source:Span", ptr %l1
  %t826 = load ptr, ptr %l2, !tbaa !29
  %t827 = load ptr, ptr %l7, !tbaa !29
  %t828 = load i64, ptr %l28, !tbaa !24
  %t829 = load i64, ptr %l29, !tbaa !24
  %t830 = load ptr, ptr %l3, !tbaa !29
  %t831 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkIndexed(ptr %v0, ptr %v1, ptr %v0, ptr %v2, ptr %t824, %"compiler/source:Span" %t825, ptr %t826, ptr %t827, i64 %t828, i64 %t829, ptr %t830, i32 %t831)
  br label %bb178
bb177:
  br label %bb179
bb178:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb179:
  %t841 = load ptr, ptr %l0, !tbaa !29
  %t842 = load i32, ptr %l15, !tbaa !23
  %t843 = load %"compiler/source:Span", ptr %l1
  %t847 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %s0, ptr %s0, ptr %t841, i32 %t842, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d57, i32 0, i32 1) }, %"compiler/source:Span" %t843, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d58, i32 0, i32 1) }, i64 0, i1 false)
  store i1 %t847, ptr %l435
  br label %bb180
bb180:
  %t848 = load i1, ptr %l435, !tbaa !21
  br i1 %t848, label %bb181, label %bb182
bb181:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb182:
  br label %bb183
bb183:
  %t850 = load ptr, ptr %l0, !tbaa !29
  store ptr %t850, ptr %l437, !tbaa !29
  %t851 = load ptr, ptr %l2, !tbaa !29
  %t853 = getelementptr %"compiler/ast:ForIn", ptr %t851, i32 0, i32 2
  %t854 = load ptr, ptr %t853, !tbaa !29
  %t856 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t854)
  store %"compiler/source:Span" %t856, ptr %l440
  br label %bb184
bb184:
  %t857 = load i32, ptr %l8, !tbaa !23
  store i32 %t857, ptr %l441, !tbaa !23
  %t858 = load ptr, ptr %l0, !tbaa !29
  %t859 = load i32, ptr %l8, !tbaa !23
  %t862 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t858, i32 %t859)
  store { i64, ptr } %t862, ptr %l444
  br label %bb185
bb185:
  %t863 = load { i64, ptr }, ptr %l444, !tbaa !27
  %t864 = extractvalue { i64, ptr } %t863, 0
  %t865 = extractvalue { i64, ptr } %t863, 1
  %t866 = mul i64 %t864, 1
  %t867 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t866)
  call void @llvm.memcpy.p0.p0.i64(ptr %t867, ptr %t865, i64 %t866, i1 false)
  %t868 = insertvalue { i64, ptr } undef, i64 %t864, 0
  %t869 = insertvalue { i64, ptr } %t868, ptr %t867, 1
  %t871 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotIterable(ptr %s0, ptr %s0, { i64, ptr } %t869)
  store %"compiler/msgs:Msg" %t871, ptr %l446
  br label %bb186
bb186:
  %t872 = load ptr, ptr %l437, !tbaa !29
  %t873 = load %"compiler/source:Span", ptr %l440
  %t874 = load i32, ptr %l441, !tbaa !23
  %t875 = load %"compiler/msgs:Msg", ptr %l446
  %t876 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneedErr(ptr %v0, ptr %s0, ptr %s0, ptr %t872, %"compiler/source:Span" %t873, i32 %t874, { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d59, i32 0, i32 1) }, %"compiler/msgs:Msg" %t875)
  store i64 %t876, ptr %l447
  br label %bb187
bb187:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewholeNarrowed(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"compiler/check:narrowed"
  %l10 = alloca ptr
  %l12 = alloca ptr
  %l15 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l41 = alloca ptr
  %l44 = alloca i64
  %l48 = alloca %"compiler/check:narrowed"
  %l52 = alloca i1
  %l55 = alloca ptr
  %l60 = alloca i32
  %l61 = alloca ptr
  %l63 = alloca ptr
  %l66 = alloca i1
  %l74 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l12
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l12, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t5, i32 0, i32 44
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eLen_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l15
  br label %bb2
bb2:
  %t10 = load i64, ptr %l15, !tbaa !24
  store i64 %t10, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t12 = load i64, ptr %l3, !tbaa !24
  %t15 = icmp sgt i64 %t11, %t12
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = load i64, ptr %l5, !tbaa !24
  %t19 = icmp sgt i64 %t17, 0
  br i1 %t19, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb8
bb5:
  %t21 = load i64, ptr %l4, !tbaa !24
  %t22 = load i64, ptr %l3, !tbaa !24
  %t25 = sub i64 %t21, %t22
  %t26 = load i64, ptr %l5, !tbaa !24
  %t29 = add i64 %t25, %t26
  %t31 = sub i64 %t29, 1
  %t32 = load i64, ptr %l5, !tbaa !24
  %t35 = sdiv i64 %t31, %t32
  store i64 %t35, ptr %l22, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb7
bb7:
  %t37 = load i64, ptr %l22, !tbaa !24
  store i64 %t37, ptr %l19, !tbaa !24
  br label %bb8
bb8:
  %t38 = load i64, ptr %l19, !tbaa !24
  store i64 %t38, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb9
bb9:
  %t39 = load i64, ptr %l7, !tbaa !24
  %t40 = load i64, ptr %l6, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb10, label %bb11
bb10:
  br label %bb32
bb11:
  br label %bb12
bb12:
  %t47 = load i64, ptr %l3, !tbaa !24
  %t48 = load i64, ptr %l7, !tbaa !24
  %t49 = load i64, ptr %l5, !tbaa !24
  %t52 = mul i64 %t48, %t49
  %t55 = add i64 %t47, %t52
  store i64 %t55, ptr %l8, !tbaa !24
  %t57 = load ptr, ptr %l2, !tbaa !29
  %t59 = getelementptr %"compiler/check:frame", ptr %t57, i32 0, i32 44
  store ptr %t59, ptr %l41, !tbaa !29
  %t60 = load ptr, ptr %l2, !tbaa !29
  %t62 = getelementptr %"compiler/check:frame", ptr %t60, i32 0, i32 44
  %t64 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eLen_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %t62)
  store i64 %t64, ptr %l44
  br label %bb13
bb13:
  %t65 = load i64, ptr %l44, !tbaa !24
  %t66 = sub i64 %t65, 1
  %t67 = load i64, ptr %l8, !tbaa !24
  %t70 = sub i64 %t66, %t67
  %t71 = load ptr, ptr %l41, !tbaa !29
  %t73 = call %"compiler/check:narrowed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eAt_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %t71, i64 %t70)
  store %"compiler/check:narrowed" %t73, ptr %l48
  br label %bb14
bb14:
  %t74 = load %"compiler/check:narrowed", ptr %l48
  store %"compiler/check:narrowed" %t74, ptr %l9
  %t75 = getelementptr %"compiler/check:narrowed", ptr %l9, i32 0, i32 0
  %t76 = load i64, ptr %t75, !tbaa !24
  %t80 = icmp ne i64 %t76, %a1
  br i1 %t80, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l52, !tbaa !21
  br label %bb17
bb16:
  %t82 = getelementptr %"compiler/check:narrowed", ptr %l9, i32 0, i32 5
  %t83 = load i1, ptr %t82, !tbaa !21
  store i1 %t83, ptr %l52, !tbaa !21
  br label %bb17
bb17:
  %t85 = load i1, ptr %l52, !tbaa !21
  br i1 %t85, label %bb18, label %bb19
bb18:
  br label %bb31
bb19:
  br label %bb20
bb20:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/check:Checker", ptr %t86, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !29
  store ptr %t89, ptr %l55, !tbaa !29
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/check:Checker", ptr %t90, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t95 = getelementptr %"compiler/generic:Program", ptr %t93, i32 0, i32 2
  %t96 = getelementptr %"compiler/check:narrowed", ptr %l9, i32 0, i32 2
  %t97 = load i32, ptr %t96, !tbaa !23
  %t100 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t95, i32 %t97)
  store i32 %t100, ptr %l60
  br label %bb21
bb21:
  %t101 = load ptr, ptr %l55, !tbaa !29
  %t102 = load i32, ptr %l60, !tbaa !23
  %t103 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v0, ptr %t101, i32 %t102)
  store ptr %t103, ptr %l61
  br label %bb22
bb22:
  %t104 = getelementptr %"compiler/check:narrowed", ptr %l9, i32 0, i32 1
  %t105 = load i64, ptr %t104, !tbaa !24
  %t106 = load ptr, ptr %l61, !tbaa !29
  %t108 = call ptr @compiler_2fcheck_2ecaseDecl(ptr %v0, ptr %v0, ptr %t106, i64 %t105)
  store ptr %t108, ptr %l63
  br label %bb23
bb23:
  %t109 = load ptr, ptr %l63, !tbaa !29
  store ptr %t109, ptr %l10, !tbaa !29
  %t110 = load ptr, ptr %l10, !tbaa !29
  %t112 = icmp eq ptr %t110, null
  br i1 %t112, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l66, !tbaa !21
  br label %bb26
bb25:
  %t114 = load ptr, ptr %l10, !tbaa !29
  %t116 = getelementptr %"compiler/ast:CaseDecl", ptr %t114, i32 0, i32 3
  %t117 = load i1, ptr %t116, !tbaa !21
  %t119 = xor i1 %t117, true
  store i1 %t119, ptr %l66, !tbaa !21
  br label %bb26
bb26:
  %t121 = load i1, ptr %l66, !tbaa !21
  br i1 %t121, label %bb27, label %bb28
bb27:
  store i64 -1, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  %t123 = load ptr, ptr %l2, !tbaa !29
  %t125 = getelementptr %"compiler/check:frame", ptr %t123, i32 0, i32 45
  %t126 = getelementptr %"compiler/check:narrowed", ptr %l9, i32 0, i32 3
  %t127 = load i64, ptr %t126, !tbaa !24
  %t130 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t125, i64 %t127)
  store i64 %t130, ptr %l74
  br label %bb30
bb30:
  %t131 = load i64, ptr %l74, !tbaa !24
  store i64 %t131, ptr %rv
  br label %ret
bb31:
  %t132 = load i64, ptr %l7, !tbaa !24
  %t134 = add i64 %t132, 1
  store i64 %t134, ptr %l7, !tbaa !24
  br label %bb9
bb32:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewriteBackNoNumber(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, ptr %a4, %"compiler/source:Span" %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i1
  %l7 = alloca { i64, ptr }
  %l8 = alloca i32
  %l9 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l20 = alloca i1
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l28 = alloca i64
  %l30 = alloca i64
  %l31 = alloca { i64, ptr }
  %l35 = alloca i64
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l44 = alloca i64
  %l46 = alloca i64
  %l47 = alloca { i64, ptr }
  %l51 = alloca i64
  %l53 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l56 = alloca i64
  %l58 = alloca i64
  %l59 = alloca { i64, ptr }
  %l61 = alloca i1
  %l62 = alloca ptr
  %l63 = alloca %"compiler/source:Span"
  %l66 = alloca { i64, ptr }
  %l68 = alloca %"compiler/msgs:Msg"
  %l69 = alloca i64
  %l71 = alloca i32
  %l74 = alloca i1
  %l75 = alloca i1
  %l76 = alloca ptr
  %l77 = alloca i32
  %l79 = alloca { i64, ptr }
  %l80 = alloca i64
  %l83 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l86 = alloca i64
  %l88 = alloca i64
  %l89 = alloca { i64, ptr }
  %l94 = alloca ptr
  %l97 = alloca i32
  %l100 = alloca i1
  %l101 = alloca ptr
  %l102 = alloca %"compiler/source:Span"
  %l103 = alloca %"compiler/source:Span"
  %l104 = alloca i32
  %l111 = alloca ptr
  %l113 = alloca ptr
  %l117 = alloca ptr
  %l118 = alloca %"compiler/source:Span"
  %l121 = alloca { i64, ptr }
  %l126 = alloca %"compiler/msgs:Msg"
  %l127 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %t253 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i32 %a3, ptr %l3
  store ptr %a4, ptr %l4
  store %"compiler/source:Span" %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t3 = trunc i64 65 to i32
  %t4 = icmp eq i32 %t1, %t3
  store i1 %t4, ptr %l6, !tbaa !21
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d60, i32 0, i32 1) }, ptr %l12, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t6, ptr %l13, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t7, 0
  store i64 %t8, ptr %l14, !tbaa !24
  %t9 = load i64, ptr %l14, !tbaa !24
  %t10 = mul i64 %t9, 1
  %t11 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t10)
  %t12 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  store { i64, ptr } %t13, ptr %l15, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = load i64, ptr %l14, !tbaa !24
  %t19 = mul i64 %t18, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t15, ptr %t17, i64 %t19, i1 false)
  %t20 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t20, ptr %l7, !tbaa !27
  %t21 = load ptr, ptr %l4, !tbaa !29
  %t23 = icmp eq ptr %t21, null
  br i1 %t23, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i32, ptr %l3, !tbaa !23
  %t29 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t25, i32 %t26)
  store i1 %t29, ptr %l20
  br label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s6
  %t30 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t32 = call i32 @compiler_2fcheck_2ecompoundOp(i32 %t30)
  store i32 %t32, ptr %l71
  br label %bb37
bb3:
  %t33 = load i1, ptr %l20, !tbaa !21
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t34 = load i1, ptr %l6, !tbaa !21
  br i1 %t34, label %bb6, label %bb7
bb5:
  br label %bb29
bb6:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d61, i32 0, i32 1) }, ptr %l23, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t36, ptr %l22, !tbaa !27
  br label %bb8
bb7:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d62, i32 0, i32 1) }, ptr %l25, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t38, ptr %l22, !tbaa !27
  br label %bb8
bb8:
  %t40 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 0
  %t42 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 0
  store i64 %t43, ptr %l28, !tbaa !24
  %t45 = load i64, ptr %l28, !tbaa !24
  %t46 = icmp eq i64 %t41, %t45
  br i1 %t46, label %bb9, label %bb10
bb9:
  %t48 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = load i64, ptr %l28, !tbaa !24
  %t53 = mul i64 %t52, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t49, ptr %t51, i64 %t53, i1 false)
  br label %bb11
bb10:
  %t54 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t54, 0
  store i64 %t55, ptr %l30, !tbaa !24
  %t56 = load i64, ptr %l30, !tbaa !24
  %t57 = mul i64 %t56, 1
  %t58 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t57)
  %t59 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t58, 1
  store { i64, ptr } %t60, ptr %l31, !tbaa !27
  %t61 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = load i64, ptr %l30, !tbaa !24
  %t66 = mul i64 %t65, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t62, ptr %t64, i64 %t66, i1 false)
  %t67 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t67, ptr %l7, !tbaa !27
  br label %bb11
bb11:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i32, ptr %l3, !tbaa !23
  %t70 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t74 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s0, ptr %t68, i32 %t69, { i64, ptr } %t70, i64 0)
  store i64 %t74, ptr %l35
  br label %bb12
bb12:
  %t75 = load i64, ptr %l35, !tbaa !24
  %t76 = icmp slt i64 %t75, 0
  br i1 %t76, label %bb13, label %bb14
bb13:
  %t78 = load i1, ptr %l6, !tbaa !21
  br i1 %t78, label %bb15, label %bb16
bb14:
  br label %bb28
bb15:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d63, i32 0, i32 1) }, ptr %l39, !tbaa !27
  %t80 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t80, ptr %l38, !tbaa !27
  br label %bb17
bb16:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d64, i32 0, i32 1) }, ptr %l41, !tbaa !27
  %t82 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t82, ptr %l38, !tbaa !27
  br label %bb17
bb17:
  %t84 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t84, 0
  %t86 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t86, 0
  store i64 %t87, ptr %l44, !tbaa !24
  %t89 = load i64, ptr %l44, !tbaa !24
  %t90 = icmp eq i64 %t85, %t89
  br i1 %t90, label %bb18, label %bb19
bb18:
  %t92 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = load i64, ptr %l44, !tbaa !24
  %t97 = mul i64 %t96, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t93, ptr %t95, i64 %t97, i1 false)
  br label %bb20
bb19:
  %t98 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t98, 0
  store i64 %t99, ptr %l46, !tbaa !24
  %t100 = load i64, ptr %l46, !tbaa !24
  %t101 = mul i64 %t100, 1
  %t102 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t101)
  %t103 = insertvalue { i64, ptr } undef, i64 %t100, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t102, 1
  store { i64, ptr } %t104, ptr %l47, !tbaa !27
  %t105 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !27
  %t107 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = load i64, ptr %l46, !tbaa !24
  %t110 = mul i64 %t109, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t106, ptr %t108, i64 %t110, i1 false)
  %t111 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t111, ptr %l7, !tbaa !27
  br label %bb20
bb20:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load i32, ptr %l3, !tbaa !23
  %t114 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t118 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s0, ptr %t112, i32 %t113, { i64, ptr } %t114, i64 1)
  store i64 %t118, ptr %l51
  br label %bb21
bb21:
  %t119 = load i64, ptr %l51, !tbaa !24
  %t120 = icmp slt i64 %t119, 0
  br i1 %t120, label %bb22, label %bb23
bb22:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d65, i32 0, i32 1) }, ptr %l53, !tbaa !27
  %t122 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t122, ptr %l54, !tbaa !27
  %t123 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t123, 0
  %t125 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t125, 0
  store i64 %t126, ptr %l56, !tbaa !24
  %t128 = load i64, ptr %l56, !tbaa !24
  %t129 = icmp eq i64 %t124, %t128
  br i1 %t129, label %bb24, label %bb25
bb23:
  br label %bb27
bb24:
  %t131 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !27
  %t135 = load i64, ptr %l56, !tbaa !24
  %t136 = mul i64 %t135, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t132, ptr %t134, i64 %t136, i1 false)
  br label %bb26
bb25:
  %t137 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t137, 0
  store i64 %t138, ptr %l58, !tbaa !24
  %t139 = load i64, ptr %l58, !tbaa !24
  %t140 = mul i64 %t139, 1
  %t141 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t140)
  %t142 = insertvalue { i64, ptr } undef, i64 %t139, 0
  %t143 = insertvalue { i64, ptr } %t142, ptr %t141, 1
  store { i64, ptr } %t143, ptr %l59, !tbaa !27
  %t144 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !27
  %t146 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = load i64, ptr %l58, !tbaa !24
  %t149 = mul i64 %t148, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t145, ptr %t147, i64 %t149, i1 false)
  %t150 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t150, ptr %l7, !tbaa !27
  br label %bb26
bb26:
  br label %bb27
bb27:
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t151 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t153 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s1, { i64, ptr } %t151, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d66, i32 0, i32 1) })
  store i1 %t153, ptr %l61
  br label %bb30
bb30:
  %t154 = load i1, ptr %l61, !tbaa !21
  br i1 %t154, label %bb31, label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s5
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l62, !tbaa !29
  %t156 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t156, ptr %l63
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load i32, ptr %l3, !tbaa !23
  %t161 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s5, ptr %t157, i32 %t158)
  store { i64, ptr } %t161, ptr %l66
  br label %bb33
bb32:
  br label %bb36
bb33:
  %t162 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t163 = extractvalue { i64, ptr } %t162, 0
  %t164 = extractvalue { i64, ptr } %t162, 1
  %t165 = mul i64 %t163, 1
  %t166 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t165)
  call void @llvm.memcpy.p0.p0.i64(ptr %t166, ptr %t164, i64 %t165, i1 false)
  %t167 = insertvalue { i64, ptr } undef, i64 %t163, 0
  %t168 = insertvalue { i64, ptr } %t167, ptr %t166, 1
  %t170 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eStepNotNumber(ptr %s5, ptr %s5, { i64, ptr } %t168)
  store %"compiler/msgs:Msg" %t170, ptr %l68
  br label %bb34
bb34:
  %t171 = load ptr, ptr %l62, !tbaa !29
  %t172 = load %"compiler/source:Span", ptr %l63
  %t173 = load %"compiler/msgs:Msg", ptr %l68
  %t174 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t171, %"compiler/source:Span" %t172, %"compiler/msgs:Msg" %t173)
  store i64 %t174, ptr %l69
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb36:
  call void @__olang_scope_close(ptr %s1)
  br label %bb62
bb37:
  %t175 = load i32, ptr %l71, !range !{i32 0, i32 98}
  store i32 %t175, ptr %l8
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load i32, ptr %l3, !tbaa !23
  %t180 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t176, i32 %t177)
  store i1 %t180, ptr %l74
  br label %bb38
bb38:
  %t181 = load i1, ptr %l74, !tbaa !21
  br i1 %t181, label %bb39, label %bb40
bb39:
  %t182 = load ptr, ptr %l0, !tbaa !29
  store ptr %t182, ptr %l76, !tbaa !29
  %t183 = load i32, ptr %l3, !tbaa !23
  store i32 %t183, ptr %l77, !tbaa !23
  %t184 = load i32, ptr %l8, !range !{i32 0, i32 98}
  %t186 = call { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %s6, i32 %t184)
  store { i64, ptr } %t186, ptr %l79
  br label %bb41
bb40:
  store i1 false, ptr %l75, !tbaa !21
  br label %bb43
bb41:
  %t187 = load ptr, ptr %l76, !tbaa !29
  %t188 = load i32, ptr %l77, !tbaa !23
  %t189 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t190 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s6, ptr %t187, i32 %t188, { i64, ptr } %t189, i64 1)
  store i64 %t190, ptr %l80
  br label %bb42
bb42:
  %t191 = load i64, ptr %l80, !tbaa !24
  %t192 = icmp sge i64 %t191, 0
  store i1 %t192, ptr %l75, !tbaa !21
  br label %bb43
bb43:
  %t194 = load i1, ptr %l75, !tbaa !21
  br i1 %t194, label %bb44, label %bb45
bb44:
  %t195 = load i32, ptr %l8, !range !{i32 0, i32 98}
  %t197 = call { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %s0, i32 %t195)
  store { i64, ptr } %t197, ptr %l83
  br label %bb46
bb45:
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t199 = load ptr, ptr %l4, !tbaa !29
  %t201 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t205 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v0, ptr %t198, ptr %t199, i32 %t201)
  store ptr %t205, ptr %l94
  br label %bb50
bb46:
  %t206 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t206, ptr %l84, !tbaa !27
  %t207 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t208 = extractvalue { i64, ptr } %t207, 0
  %t209 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t210 = extractvalue { i64, ptr } %t209, 0
  store i64 %t210, ptr %l86, !tbaa !24
  %t212 = load i64, ptr %l86, !tbaa !24
  %t213 = icmp eq i64 %t208, %t212
  br i1 %t213, label %bb47, label %bb48
bb47:
  %t215 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t216 = load ptr, ptr %t215, !tbaa !27
  %t217 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t218 = load ptr, ptr %t217, !tbaa !27
  %t219 = load i64, ptr %l86, !tbaa !24
  %t220 = mul i64 %t219, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t216, ptr %t218, i64 %t220, i1 false)
  br label %bb49
bb48:
  %t221 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t222 = extractvalue { i64, ptr } %t221, 0
  store i64 %t222, ptr %l88, !tbaa !24
  %t223 = load i64, ptr %l88, !tbaa !24
  %t224 = mul i64 %t223, 1
  %t225 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t224)
  %t226 = insertvalue { i64, ptr } undef, i64 %t223, 0
  %t227 = insertvalue { i64, ptr } %t226, ptr %t225, 1
  store { i64, ptr } %t227, ptr %l89, !tbaa !27
  %t228 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t229 = load ptr, ptr %t228, !tbaa !27
  %t230 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t231 = load ptr, ptr %t230, !tbaa !27
  %t232 = load i64, ptr %l88, !tbaa !24
  %t233 = mul i64 %t232, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t229, ptr %t231, i64 %t233, i1 false)
  %t234 = load { i64, ptr }, ptr %l89, !tbaa !27
  store { i64, ptr } %t234, ptr %l7, !tbaa !27
  br label %bb49
bb49:
  br label %bb61
bb50:
  %t235 = load ptr, ptr %l94, !tbaa !29
  store ptr %t235, ptr %l9, !tbaa !29
  %t236 = load ptr, ptr %l9, !tbaa !29
  %t239 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t236)
  store i32 %t239, ptr %l97
  br label %bb51
bb51:
  %t240 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t241 = load i32, ptr %l97, !tbaa !23
  %t243 = icmp ne i32 %t241, %t240
  br i1 %t243, label %bb52, label %bb53
bb52:
  %t245 = load ptr, ptr %l0, !tbaa !29
  store ptr %t245, ptr %l101, !tbaa !29
  %t246 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t246, ptr %l102
  %t247 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t247, ptr %l103
  %t248 = load i32, ptr %l8, !range !{i32 0, i32 98}
  store i32 %t248, ptr %l104
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t250 = load %"compiler/source:Span", ptr %l1
  %t251 = load %"compiler/source:Span", ptr %l1
  %t252 = load i32, ptr %l3, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t253
  %t254 = getelementptr { i64, [4 x i64] }, ptr %t253, i32 0, i32 0
  store i64 7, ptr %t254
  %t256 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t251, 0
  %t258 = insertvalue { %"compiler/source:Span", i32 } %t256, i32 %t252, 1
  %t259 = getelementptr { i64, [4 x i64] }, ptr %t253, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t258, ptr %t259
  %t260 = load { i64, [4 x i64] }, ptr %t253
  %t262 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t260, ptr %t262
  %t266 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v0, ptr %v0, ptr %t249, %"compiler/source:Span" %t250, ptr %t262)
  store ptr %t266, ptr %l111
  br label %bb54
bb53:
  store i1 false, ptr %l100, !tbaa !21
  br label %bb56
bb54:
  %t267 = load ptr, ptr %l9, !tbaa !29
  %t268 = load ptr, ptr %l101, !tbaa !29
  %t269 = load %"compiler/source:Span", ptr %l102
  %t270 = load %"compiler/source:Span", ptr %l103
  %t271 = load i32, ptr %l104, !range !{i32 0, i32 98}
  %t272 = load ptr, ptr %l111, !tbaa !29
  %t274 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperatorCall(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t268, %"compiler/source:Span" %t269, %"compiler/source:Span" %t270, i32 %t271, ptr %t272, ptr %t267)
  store ptr %t274, ptr %l113
  br label %bb55
bb55:
  %t275 = load ptr, ptr %l113, !tbaa !29
  %t276 = icmp eq ptr %t275, null
  store i1 %t276, ptr %l100, !tbaa !21
  br label %bb56
bb56:
  %t278 = load i1, ptr %l100, !tbaa !21
  br i1 %t278, label %bb57, label %bb58
bb57:
  store %olang.scope zeroinitializer, ptr %s9
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t280 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s9, ptr %t279, %"compiler/source:Span" %t280, { i64, ptr } { i64 58, ptr getelementptr inbounds (<{ i64, [58 x i8] }>, ptr @.d67, i32 0, i32 1) })
  br label %bb59
bb58:
  br label %bb60
bb59:
  call void @__olang_scope_close(ptr %s9)
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb61:
  call void @__olang_scope_close(ptr %s6)
  br label %bb62
bb62:
  %t283 = load ptr, ptr %l0, !tbaa !29
  store ptr %t283, ptr %l117, !tbaa !29
  %t284 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t284, ptr %l118
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t286 = load i32, ptr %l3, !tbaa !23
  %t289 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t285, i32 %t286)
  store { i64, ptr } %t289, ptr %l121
  br label %bb63
bb63:
  %t290 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t291 = extractvalue { i64, ptr } %t290, 0
  %t292 = extractvalue { i64, ptr } %t290, 1
  %t293 = mul i64 %t291, 1
  %t294 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t293)
  call void @llvm.memcpy.p0.p0.i64(ptr %t294, ptr %t292, i64 %t293, i1 false)
  %t295 = insertvalue { i64, ptr } undef, i64 %t291, 0
  %t296 = insertvalue { i64, ptr } %t295, ptr %t294, 1
  %t297 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t298 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d68, i32 0, i32 1) }, 1
  %t299 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d68, i32 0, i32 1) }, 0
  %t301 = extractvalue { i64, ptr } %t297, 1
  %t302 = extractvalue { i64, ptr } %t297, 0
  %t303 = add i64 %t299, %t302
  %t304 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d68, i32 0, i32 1) }, 1
  %t305 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d68, i32 0, i32 1) }, 0
  %t306 = add i64 %t303, %t305
  %t307 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t306)
  call void @olang_textcopy(ptr %t307, ptr %t298, i64 %t299)
  %t308 = getelementptr i8, ptr %t307, i64 %t299
  call void @olang_textcopy(ptr %t308, ptr %t301, i64 %t302)
  %t309 = getelementptr i8, ptr %t308, i64 %t302
  call void @olang_textcopy(ptr %t309, ptr %t304, i64 %t305)
  %t310 = insertvalue { i64, ptr } undef, i64 %t306, 0
  %t311 = insertvalue { i64, ptr } %t310, ptr %t307, 1
  %t313 = extractvalue { i64, ptr } %t311, 0
  %t314 = extractvalue { i64, ptr } %t311, 1
  %t315 = mul i64 %t313, 1
  %t316 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t315)
  call void @llvm.memcpy.p0.p0.i64(ptr %t316, ptr %t314, i64 %t315, i1 false)
  %t317 = insertvalue { i64, ptr } undef, i64 %t313, 0
  %t318 = insertvalue { i64, ptr } %t317, ptr %t316, 1
  %t321 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eWriteThroughAtOperator(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t296, { i64, ptr } %t318)
  store %"compiler/msgs:Msg" %t321, ptr %l126
  br label %bb64
bb64:
  %t322 = load ptr, ptr %l117, !tbaa !29
  %t323 = load %"compiler/source:Span", ptr %l118
  %t324 = load %"compiler/msgs:Msg", ptr %l126
  %t325 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s0, ptr %t322, %"compiler/source:Span" %t323, %"compiler/msgs:Msg" %t324)
  store i64 %t325, ptr %l127
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2ecompoundOp(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i32
  %rv = alloca i32
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t3 = trunc i64 65 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store i32 52, ptr %l1
  br label %bb49
bb4:
  %t7 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t9 = trunc i64 66 to i32
  %t10 = icmp eq i32 %t7, %t9
  br i1 %t10, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i32 53, ptr %l1
  br label %bb49
bb8:
  %t13 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t15 = trunc i64 67 to i32
  %t16 = icmp eq i32 %t13, %t15
  br i1 %t16, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i32 54, ptr %l1
  br label %bb49
bb12:
  %t19 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t21 = trunc i64 68 to i32
  %t22 = icmp eq i32 %t19, %t21
  br i1 %t22, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store i32 55, ptr %l1
  br label %bb49
bb16:
  %t25 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t27 = trunc i64 69 to i32
  %t28 = icmp eq i32 %t25, %t27
  br i1 %t28, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i32 56, ptr %l1
  br label %bb49
bb20:
  %t31 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t33 = trunc i64 70 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store i32 57, ptr %l1
  br label %bb49
bb24:
  %t37 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t39 = trunc i64 71 to i32
  %t40 = icmp eq i32 %t37, %t39
  br i1 %t40, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  store i32 90, ptr %l1
  br label %bb49
bb28:
  %t43 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t45 = trunc i64 72 to i32
  %t46 = icmp eq i32 %t43, %t45
  br i1 %t46, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store i32 91, ptr %l1
  br label %bb49
bb32:
  %t49 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t51 = trunc i64 73 to i32
  %t52 = icmp eq i32 %t49, %t51
  br i1 %t52, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  store i32 85, ptr %l1
  br label %bb49
bb36:
  %t55 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t57 = trunc i64 74 to i32
  %t58 = icmp eq i32 %t55, %t57
  br i1 %t58, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  store i32 86, ptr %l1
  br label %bb49
bb40:
  %t61 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t63 = trunc i64 75 to i32
  %t64 = icmp eq i32 %t61, %t63
  br i1 %t64, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  store i32 87, ptr %l1
  br label %bb49
bb44:
  br i1 true, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  store i32 0, ptr %l1
  br label %bb49
bb48:
  call void @__olang_check_failed(ptr @olang_loc_20f9f67d26588f89_c77aed4cf9eaedd5)
  unreachable
bb49:
  %t68 = load i32, ptr %l1, !range !{i32 0, i32 98}
  store i32 %t68, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fcheck_2edirectSet(ptr %v0, { i64, ptr } %a0, i32 %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l18 = alloca i1
  %l24 = alloca i32
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb21
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l5, !tbaa !29
  %t23 = load ptr, ptr %l5, !tbaa !29
  store ptr %t23, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t24 = load ptr, ptr %l17, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb5, label %bb6
bb5:
  %t27 = load ptr, ptr %l17, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 11}
  %t30 = icmp eq i64 %t28, 8
  store i1 %t30, ptr %l18, !tbaa !21
  br label %bb6
bb6:
  %t31 = load i1, ptr %l18, !tbaa !21
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t32 = load ptr, ptr %l5, !tbaa !29
  %t34 = getelementptr { i64, [6 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t34, i32 0, i32 1
  %t36 = load ptr, ptr %t35
  store ptr %t36, ptr %l6, !tbaa !29
  br label %bb9
bb8:
  br label %bb14
bb9:
  %t38 = load ptr, ptr %l6, !tbaa !29
  %t40 = call i32 @compiler_2fcheck_2esetName(ptr %v0, ptr %t38)
  store i32 %t40, ptr %l24
  br label %bb10
bb10:
  %t42 = load i32, ptr %l24, !tbaa !23
  %t44 = icmp eq i32 %t42, %a1
  br i1 %t44, label %bb11, label %bb12
bb11:
  store i1 true, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  br label %bb19
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_19f4e92ae3000dc_edc59080f5379130)
  unreachable
bb19:
  br label %bb20
bb20:
  %t47 = load i64, ptr %l3, !tbaa !24
  %t49 = add i64 %t47, 1
  store i64 %t49, ptr %l3, !tbaa !24
  br label %bb1
bb21:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ehandleCall(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca i1
  %l24 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca ptr
  %l32 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca ptr
  %l40 = alloca i1
  %l49 = alloca i1
  %l54 = alloca ptr
  %l60 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l5, !tbaa !29
  br label %bb47
bb6:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t20 = load ptr, ptr %l14, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t23 = load ptr, ptr %l14, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 18}
  %t26 = icmp eq i64 %t24, 14
  store i1 %t26, ptr %l15, !tbaa !21
  br label %bb8
bb8:
  %t27 = load i1, ptr %l15, !tbaa !21
  br i1 %t27, label %bb9, label %bb10
bb9:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr { i64, [5 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t30, i32 0, i32 2
  %t32 = load ptr, ptr %t31
  store ptr %t32, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  br label %bb19
bb11:
  %t34 = load ptr, ptr %l2, !tbaa !29
  %t36 = getelementptr %"compiler/typed:Try", ptr %t34, i32 0, i32 0
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = icmp eq ptr %t37, null
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb12, label %bb13
bb12:
  %t43 = load ptr, ptr %l2, !tbaa !29
  %t45 = getelementptr %"compiler/typed:Try", ptr %t43, i32 0, i32 0
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = icmp eq ptr %t46, null
  br i1 %t48, label %bb14, label %bb15
bb13:
  store ptr null, ptr %l24, !tbaa !29
  br label %bb18
bb14:
  call void @__olang_check_failed(ptr @olang_loc_9272b3113db2835a_2a2a8b0a39f9db7e)
  unreachable
bb15:
  br label %bb16
bb16:
  %t50 = load ptr, ptr %l2, !tbaa !29
  %t52 = getelementptr %"compiler/typed:Try", ptr %t50, i32 0, i32 0
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = call ptr @compiler_2fcheck_2ehandleCall(ptr %v0, ptr %v1, ptr %t53)
  store ptr %t55, ptr %l30
  br label %bb17
bb17:
  %t56 = load ptr, ptr %l30, !tbaa !29
  store ptr %t56, ptr %l24, !tbaa !29
  br label %bb18
bb18:
  %t57 = load ptr, ptr %l24, !tbaa !29
  store ptr %t57, ptr %l5, !tbaa !29
  br label %bb47
bb19:
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t59 = load ptr, ptr %l31, !tbaa !29
  %t60 = icmp ne ptr %t59, null
  br i1 %t60, label %bb20, label %bb21
bb20:
  %t62 = load ptr, ptr %l31, !tbaa !29
  %t63 = load i64, ptr %t62, !range !{i64 0, i64 18}
  %t65 = icmp eq i64 %t63, 17
  store i1 %t65, ptr %l32, !tbaa !21
  br label %bb21
bb21:
  %t66 = load i1, ptr %l32, !tbaa !21
  br i1 %t66, label %bb22, label %bb23
bb22:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr { i64, [5 x i64] }, ptr %t67, i32 0, i32 1
  %t70 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t69, i32 0, i32 2
  %t71 = load ptr, ptr %t70
  store ptr %t71, ptr %l3, !tbaa !29
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t73 = load ptr, ptr %l3, !tbaa !29
  %t75 = call ptr @compiler_2fcheck_2ehandleCall(ptr %v0, ptr %v1, ptr %t73)
  store ptr %t75, ptr %l38
  br label %bb25
bb25:
  %t76 = load ptr, ptr %l38, !tbaa !29
  store ptr %t76, ptr %l5, !tbaa !29
  br label %bb47
bb26:
  %t77 = load ptr, ptr %l0, !tbaa !29
  store ptr %t77, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t78 = load ptr, ptr %l39, !tbaa !29
  %t79 = icmp ne ptr %t78, null
  br i1 %t79, label %bb27, label %bb28
bb27:
  %t81 = load ptr, ptr %l39, !tbaa !29
  %t82 = load i64, ptr %t81, !range !{i64 0, i64 18}
  %t84 = icmp eq i64 %t82, 12
  store i1 %t84, ptr %l40, !tbaa !21
  br label %bb28
bb28:
  %t85 = load i1, ptr %l40, !tbaa !21
  br i1 %t85, label %bb29, label %bb30
bb29:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr { i64, [5 x i64] }, ptr %t86, i32 0, i32 1
  %t89 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t88, i32 0, i32 2
  %t90 = load ptr, ptr %t89
  store ptr %t90, ptr %l4, !tbaa !29
  br label %bb31
bb30:
  br label %bb42
bb31:
  %t92 = load ptr, ptr %l4, !tbaa !29
  %t94 = getelementptr %"compiler/typed:Seq", ptr %t92, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t97 = icmp eq ptr %t95, null
  %t99 = xor i1 %t97, true
  br i1 %t99, label %bb32, label %bb33
bb32:
  %t101 = load ptr, ptr %l4, !tbaa !29
  %t103 = getelementptr %"compiler/typed:Seq", ptr %t101, i32 0, i32 0
  %t104 = load { i64, ptr }, ptr %t103, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t104, 0
  %t108 = icmp eq i64 %t106, 0
  store i1 %t108, ptr %l49, !tbaa !21
  br label %bb34
bb33:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb34
bb34:
  %t110 = load i1, ptr %l49, !tbaa !21
  br i1 %t110, label %bb35, label %bb36
bb35:
  %t111 = load ptr, ptr %l4, !tbaa !29
  %t113 = getelementptr %"compiler/typed:Seq", ptr %t111, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t116 = icmp eq ptr %t114, null
  br i1 %t116, label %bb37, label %bb38
bb36:
  store ptr null, ptr %l54, !tbaa !29
  br label %bb41
bb37:
  call void @__olang_check_failed(ptr @olang_loc_e85625530f05a4e1_e8094ee11349b825)
  unreachable
bb38:
  br label %bb39
bb39:
  %t118 = load ptr, ptr %l4, !tbaa !29
  %t120 = getelementptr %"compiler/typed:Seq", ptr %t118, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !29
  %t123 = call ptr @compiler_2fcheck_2ehandleCall(ptr %v0, ptr %v1, ptr %t121)
  store ptr %t123, ptr %l60
  br label %bb40
bb40:
  %t124 = load ptr, ptr %l60, !tbaa !29
  store ptr %t124, ptr %l54, !tbaa !29
  br label %bb41
bb41:
  %t125 = load ptr, ptr %l54, !tbaa !29
  store ptr %t125, ptr %l5, !tbaa !29
  br label %bb47
bb42:
  br i1 true, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  store ptr null, ptr %l5, !tbaa !29
  br label %bb47
bb46:
  call void @__olang_check_failed(ptr @olang_loc_fd7989cc94cf1ac3_95016419ffbfbd17)
  unreachable
bb47:
  %t126 = load ptr, ptr %l5, !tbaa !29
  store ptr %t126, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2fcheck_2ehandleRef(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i1
  %l23 = alloca i64
  %l25 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca i1
  %l35 = alloca i64
  %l37 = alloca ptr
  %l41 = alloca i64
  %l43 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = call i64 @compiler_2fcheck_2ehandleRoot(ptr %v0, ptr %t16)
  store i64 %t18, ptr %l12
  br label %bb6
bb6:
  %t19 = load i64, ptr %l12, !tbaa !24
  store i64 %t19, ptr %rv
  br label %ret
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t21 = load ptr, ptr %l13, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l13, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 18}
  %t27 = icmp eq i64 %t25, 6
  store i1 %t27, ptr %l14, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l14, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr { i64, [5 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t31, i32 0, i32 2
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l2, !tbaa !29
  br label %bb12
bb11:
  br label %bb17
bb12:
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr %"compiler/typed:Call", ptr %t35, i32 0, i32 1
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t38, 0
  %t42 = icmp sgt i64 %t40, 0
  br i1 %t42, label %bb13, label %bb14
bb13:
  %t44 = load ptr, ptr %l2, !tbaa !29
  %t46 = getelementptr %"compiler/typed:Call", ptr %t44, i32 0, i32 1
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !27
  store { i64, ptr } %t47, ptr %l25, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = getelementptr ptr, ptr %t49, i64 0
  %t51 = load ptr, ptr %t50, !tbaa !39
  %t53 = call i64 @compiler_2fcheck_2ehandleRef(ptr %v0, ptr %t51)
  store i64 %t53, ptr %l27
  br label %bb15
bb14:
  store i64 -1, ptr %l23, !tbaa !24
  br label %bb16
bb15:
  %t54 = load i64, ptr %l27, !tbaa !24
  store i64 %t54, ptr %l23, !tbaa !24
  br label %bb16
bb16:
  %t55 = load i64, ptr %l23, !tbaa !24
  store i64 %t55, ptr %rv
  br label %ret
bb17:
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t57 = load ptr, ptr %l28, !tbaa !29
  %t58 = icmp ne ptr %t57, null
  br i1 %t58, label %bb18, label %bb19
bb18:
  %t60 = load ptr, ptr %l28, !tbaa !29
  %t61 = load i64, ptr %t60, !range !{i64 0, i64 18}
  %t63 = icmp eq i64 %t61, 17
  store i1 %t63, ptr %l29, !tbaa !21
  br label %bb19
bb19:
  %t64 = load i1, ptr %l29, !tbaa !21
  br i1 %t64, label %bb20, label %bb21
bb20:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr { i64, [5 x i64] }, ptr %t65, i32 0, i32 1
  %t68 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t67, i32 0, i32 2
  %t69 = load ptr, ptr %t68
  store ptr %t69, ptr %l3, !tbaa !29
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t71 = load ptr, ptr %l3, !tbaa !29
  %t73 = call i64 @compiler_2fcheck_2ehandleRef(ptr %v0, ptr %t71)
  store i64 %t73, ptr %l35
  br label %bb23
bb23:
  %t74 = load i64, ptr %l35, !tbaa !24
  store i64 %t74, ptr %rv
  br label %ret
bb24:
  br i1 true, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_cf73afff9a9afd3c_75ef637926e6ccb8)
  unreachable
bb29:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %v0, ptr %t75)
  store ptr %t77, ptr %l37
  br label %bb30
bb30:
  %t78 = load ptr, ptr %l37, !tbaa !29
  store ptr %t78, ptr %l4, !tbaa !29
  %t79 = load ptr, ptr %l4, !tbaa !29
  %t81 = icmp eq ptr %t79, null
  %t83 = xor i1 %t81, true
  br i1 %t83, label %bb31, label %bb32
bb31:
  %t85 = load ptr, ptr %l4, !tbaa !29
  %t87 = call i64 @compiler_2fcheck_2ehandleRoot(ptr %v0, ptr %t85)
  store i64 %t87, ptr %l43
  br label %bb33
bb32:
  store i64 -1, ptr %l41, !tbaa !24
  br label %bb34
bb33:
  %t88 = load i64, ptr %l43, !tbaa !24
  store i64 %t88, ptr %l41, !tbaa !24
  br label %bb34
bb34:
  %t89 = load i64, ptr %l41, !tbaa !24
  store i64 %t89, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2eintOnly(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l3 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %l15 = alloca i1
  %rv = alloca i1
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t3 = trunc i64 85 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  %t6 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t8 = trunc i64 86 to i32
  %t9 = icmp eq i32 %t6, %t8
  store i1 %t9, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l3, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb6
bb5:
  %t12 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t14 = trunc i64 87 to i32
  %t15 = icmp eq i32 %t12, %t14
  store i1 %t15, ptr %l6, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l6, !tbaa !21
  br i1 %t17, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb9
bb8:
  %t18 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t20 = trunc i64 57 to i32
  %t21 = icmp eq i32 %t18, %t20
  store i1 %t21, ptr %l9, !tbaa !21
  br label %bb9
bb9:
  %t23 = load i1, ptr %l9, !tbaa !21
  br i1 %t23, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb12
bb11:
  %t24 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t26 = trunc i64 90 to i32
  %t27 = icmp eq i32 %t24, %t26
  store i1 %t27, ptr %l12, !tbaa !21
  br label %bb12
bb12:
  %t29 = load i1, ptr %l12, !tbaa !21
  br i1 %t29, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb15
bb14:
  %t30 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t32 = trunc i64 91 to i32
  %t33 = icmp eq i32 %t30, %t32
  store i1 %t33, ptr %l15, !tbaa !21
  br label %bb15
bb15:
  %t35 = load i1, ptr %l15, !tbaa !21
  store i1 %t35, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2eisTrue(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i1
  %l14 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l1, !tbaa !23
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t18, i32 0, i32 2
  %t20 = load i64, ptr %t19
  store i64 %t20, ptr %l2, !tbaa !24
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t22 = load i32, ptr %l1, !tbaa !23
  %t23 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t26 = icmp eq i32 %t22, %t23
  br i1 %t26, label %bb6, label %bb7
bb6:
  %t28 = load i64, ptr %l2, !tbaa !24
  %t30 = icmp eq i64 %t28, 1
  store i1 %t30, ptr %l14, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t32 = load i1, ptr %l14, !tbaa !21
  store i1 %t32, ptr %rv
  br label %ret
bb9:
  br i1 true, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  store i1 false, ptr %rv
  br label %ret
bb13:
  call void @__olang_check_failed(ptr @olang_loc_a08a248bd178667f_2aaba0f11d7155db)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2eisWild(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l1, !tbaa !29
  store i1 false, ptr %l2, !tbaa !21
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l2, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l2, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %rv
  br label %ret
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 false, ptr %rv
  br label %ret
bb10:
  call void @__olang_check_failed(ptr @olang_loc_4777492a424db66f_87dc2d494f6ca16b)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %rv
  br label %ret
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store ptr null, ptr %rv
  br label %ret
bb10:
  call void @__olang_check_failed(ptr @olang_loc_8d3b159055c7af2c_5997e8ea93888888)
  unreachable
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_3ab5aWalk_2ector(ptr %out, ptr %v0, i64 %a0) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l10 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l14 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l15 = alloca %"compiler/check:b5aWalk"
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a0, ptr %l1, !tbaa !24
  %t3 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l10
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t4, ptr %l2
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l11
  br label %bb2
bb2:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %l3
  %t7 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %l12
  br label %bb3
bb3:
  %t8 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %l4
  %t9 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t9, ptr %l13
  br label %bb4
bb4:
  %t10 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l13
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t10, ptr %l5
  %t11 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t11, ptr %l14
  br label %bb5
bb5:
  %t12 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l14
  %t13 = getelementptr %"compiler/check:b5aWalk", ptr %l15, i32 0, i32 0
  %t14 = load i64, ptr %l1, !tbaa !24
  store i64 %t14, ptr %t13, !tbaa !24
  %t15 = getelementptr %"compiler/check:b5aWalk", ptr %l15, i32 0, i32 1
  %t16 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l2
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t16, ptr %t15
  %t17 = getelementptr %"compiler/check:b5aWalk", ptr %l15, i32 0, i32 2
  %t18 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %t17
  %t19 = getelementptr %"compiler/check:b5aWalk", ptr %l15, i32 0, i32 3
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %t19
  %t21 = getelementptr %"compiler/check:b5aWalk", ptr %l15, i32 0, i32 4
  %t22 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l5
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t22, ptr %t21
  %t23 = getelementptr %"compiler/check:b5aWalk", ptr %l15, i32 0, i32 5
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t12, ptr %t23
  %t25 = getelementptr %"compiler/check:b5aWalk", ptr %l15, i32 0, i32 6
  store i1 false, ptr %t25, !tbaa !21
  %t27 = getelementptr %"compiler/check:b5aWalk", ptr %l15, i32 0, i32 7
  store i1 false, ptr %t27, !tbaa !21
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l15, i64 296, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/check:factsMark" @compiler_2fcheck_3afactsMark_2ector(ptr %v0, i64 %a0, i64 %a1, i64 %a2) #0 {
entry:
  %rv = alloca %"compiler/check:factsMark"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/check:factsMark" undef, i64 %a0, 0
  %t10 = insertvalue %"compiler/check:factsMark" %t8, i64 %a1, 1
  %t12 = insertvalue %"compiler/check:factsMark" %t10, i64 %a2, 2
  store %"compiler/check:factsMark" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:factsMark", ptr %rv
  ret %"compiler/check:factsMark" %rr
}

declare void @__olang_check_failed(ptr) cold noreturn
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@__olang_empty_array = external constant [16 x i64]
declare void @__olang_ert_req_clear()
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d0 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"U8" }>, align 8
@.d1 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"I8" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d2 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"'==' between null and a value" }>, align 8
@.d3 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"'=='" }>, align 8
@.d4 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"eq" }>, align 8
@.d5 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"Eq" }>, align 8
@.d6 = private constant <{ i64, [54 x i8] }> <{ i64 0, [54 x i8] c"'==' on an array or enum whose parts declare Eq (E10a)" }>, align 8
@.d7 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"nothing" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d8 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d9 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"Functions" }>, align 8
@.d10 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"std/prelude/iterator" }>, align 8
@.d11 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"Exhausted" }>, align 8
@.d12 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"an unreachable's" }>, align 8
@.d13 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"an assert's" }>, align 8
@.d14 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Clone" }>, align 8
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 4
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@.d15 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d16 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d17 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Slice" }>, align 8
@.d18 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Slice" }>, align 8
@.d19 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"'x[lo:hi]'" }>, align 8
@.d20 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"Slice ('x[lo:hi]')" }>, align 8
@.d21 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Len" }>, align 8
@.d22 = private constant <{ i64, [47 x i8] }> <{ i64 0, [47 x i8] c"a slice with no end of a type with no Len (E31)" }>, align 8
@.d23 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d24 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d25 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d26 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d27 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"std/" }>, align 8
@.d28 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d29 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"a statement of this kind" }>, align 8
@.d30 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Str" }>, align 8
@.d31 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"str" }>, align 8
@.d32 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d33 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"std/prelude/reflect" }>, align 8
@.d34 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"TypeKind" }>, align 8
@.d35 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"'not'" }>, align 8
@.d36 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"this prefix operator" }>, align 8
@.d37 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Neg" }>, align 8
@.d38 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"BitNot" }>, align 8
@.d39 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d40 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"'-'" }>, align 8
@.d41 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"Neg ('-')" }>, align 8
@.d42 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"'~'" }>, align 8
@.d43 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"a pun naming no parameter (C4)" }>, align 8
@.d44 = private constant <{ i64, [51 x i8] }> <{ i64 0, [51 x i8] c"a declaration of several names from one value (D8c)" }>, align 8
@.d45 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Next" }>, align 8
@.d46 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"RunFrom" }>, align 8
@.d47 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"'for'" }>, align 8
@.d48 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Next" }>, align 8
@.d49 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"'for'" }>, align 8
@.d50 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Iter" }>, align 8
@.d51 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"'for'" }>, align 8
@.d52 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Next" }>, align 8
@.d53 = private constant <{ i64, [43 x i8] }> <{ i64 0, [43 x i8] c"an Iter() whose result is no iterator (S9c)" }>, align 8
@.d54 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"At" }>, align 8
@.d55 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"'for'" }>, align 8
@.d56 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Len" }>, align 8
@.d57 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Next" }>, align 8
@.d58 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"'for ... in'" }>, align 8
@.d59 = private constant <{ i64, [48 x i8] }> <{ i64 0, [48 x i8] c"a walk ('for ... in': Next, Iter, or At and Len)" }>, align 8
@.d60 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d61 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Inc" }>, align 8
@.d62 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Dec" }>, align 8
@.d63 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Plus" }>, align 8
@.d64 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Minus" }>, align 8
@.d65 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d66 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d67 = private constant <{ i64, [58 x i8] }> <{ i64 0, [58 x i8] c"a compound assignment to what has no operator method (E31)" }>, align 8
@.d68 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
declare i1 @compiler_2fcheck_2eisHexDigit(i8 %a0)
declare i1 @compiler_2fcheck_2eclosedAll(ptr %v0, { i64, ptr } %a0)
@olang_loc_317fdf139725c543_9c9e0109f99156f7 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eTruncate_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %a0)
@olang_loc_ca088269e212954c_d643913a2551dac8 = external constant [0 x i8]
declare %"compiler/typed:Try" @compiler_2ftyped_3aTry_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i1 %a2, i1 %a3, i1 %a4)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aHoldsFn(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eGet_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckNow(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aListId_3e__H9cb5d99387f926677a92c13412f9a8b2(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_H2474e1fc3c93452d7765e4ed18f29a03(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunsettle(ptr %v0, ptr %a0)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyKey(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hf3bb75ba9d3f922b4d327e9d3c1adfb0(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewritable(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCPointerReadOnly(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/msgs:Msg" %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCPointerTemporary(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emustWrite(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i1 %a3)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_7362f3ae74bf0a7_8f389ee36c95dce3 = external constant [0 x i8]
@G_2ecompiler_2ftypes_2eNullT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\0F\00\00\00" }>, align 8
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecVoidRef(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eforeignRef(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplainStruct(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisCStrRef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecNumber(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_27c62905650ee804_ddef4b1ccc198ce0 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0, i64 %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleft(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehasContract(ptr %v0, ptr %a0, i64 %a1)
declare { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aContractIn_H383d843b0981793a095b02d794e40659(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectSourceOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorWithin(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eRemove_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aContractIn_H044304b59760c17b661e6227d2ca1ac9(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_cd06913e2f5eb0d4_3977f9e98d534b08 = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edecls(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
@olang_loc_40b85daad0e541e3_3cdd9f152c967927 = external constant [0 x i8]
@olang_loc_17f9884e4c50a862_1761fccd5f6f3c76 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, ptr %a4, ptr %a5)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eflowsInto(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@G_2ecompiler_2ftypes_2eReadOnly = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeMismatch(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeqMethod(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eProtocolPrivate(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorOncePerLine(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, i32 %a4, { i64, [2 x i64] } %a5)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNonNull(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
@olang_loc_1c2cb6c96b4eaee8_c1b953befa7e1dc = external constant [0 x i8]
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
@olang_loc_7ec9c6dbabf95ed5_e8695782fec42ca9 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3, ptr %a4, { i64, ptr } %a5, { i64, ptr } %a6, { i64, ptr } %a7)
declare %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
@olang_loc_bc0d2701821819b6_446831e810be806a = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epartsHaveEq(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epartsEqual(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i32 %a4)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, { i64, ptr } %a4)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternValue(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitCtor(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2fgeneric_2eFnOwner(i64 %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexplicitArgs(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2, %"compiler/source:Span" %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_c361d907896d08d5_2eb86c98dc279551 = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescTypeOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2fgeneric_2eDescFunc = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aInit(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aFn(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare i1 @compiler_2fcheck_2epureRead(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2eisLit(ptr %v0, ptr %a0)
@olang_loc_317381e6e3d2ca51_b8977c113f1a9cfd = external constant [0 x i8]
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eSetAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
@G_2ecompiler_2fcheck_2eLaneMagic = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\01\00\00" }>, align 8
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eLen_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_e09b0660792e8b62_512dd44834885876 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadsConst(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFoldKnown(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i32 %a3)
@olang_loc_660a686bd581f793_38ac5a37531336d7 = external constant [0 x i8]
@olang_loc_21b1f67e4c6ce46b_15219dc677df2bef = external constant [0 x i8]
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ealiasModule(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclaresName(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eListFunctions = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/check:reflList" @compiler_2fcheck_3areflList_2ector(ptr %v0, i1 %a0, i32 %a1, i64 %a2, i64 %a3)
declare %"compiler/check:reflList" @compiler_2fcheck_2enoList()
declare i64 @compiler_2fcheck_2elistIndex(ptr %v0, { i64, ptr } %a0)
@G_2ecompiler_2fgeneric_2eDescCase = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eListFields = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eListParams = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eListResults = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflType(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eviaTypeVar(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehasCase(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@olang_loc_7b7c458ad09559c8_7a5ff3a2c3d540e4 = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_ddeebe9155436d6a_19ee353760b572b6 = external constant [0 x i8]
@olang_loc_7406e676cee1d8f8_b07044052169e244 = external constant [0 x i8]
declare %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_742d7ba0854a02e0_30f006efbe908ac = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eslotCall(ptr %v0, ptr %a0, i32 %a1, i64 %a2, %"compiler/source:Span" %a3)
@olang_loc_652199a1d15cfac6_f2a0b86627c88902 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallBody(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, i64 %a5, ptr %a6, { i64, ptr } %a7, { i64, ptr } %a8)
@olang_loc_7509e56452997e5b_fb360af196d85db7 = external constant [0 x i8]
@olang_loc_ff81ff8210117a78_6f7a62fdc976c914 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_77a5603a1298311f_4bb819fe8c7bb9e3 = external constant [0 x i8]
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_f66b04275832bdf5_49261566e6ebbc09 = external constant [0 x i8]
@olang_loc_959932aa8b846e4e_2c1999e37dfb1a2 = external constant [0 x i8]
@olang_loc_f94ac378888081c5_5f597351c4418bf9 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, [3 x i64] } %a2, %"compiler/msgs:Msg" %a3)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %a0, i32 %a1)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKey(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hc59daade663458096c0c7696954afd54(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteReadOnlyCopyOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteReadOnlyCopy(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fcheck_2ebangOf(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadMaybeNull(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i1 @compiler_2fcheck_2eexistingValue(ptr %v0, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, i64 %a1, { i64, ptr } %a2, ptr %a3, i32 %a4, i32 %a5, i1 %a6)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritable(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunLength(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestructNotName(ptr %v0)
@olang_loc_fb06dcd16342dc9_94e70e479081575d = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ediscardOr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtended(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i32, { i64, ptr } } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflPiece(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
@olang_loc_3ff8b815b8f08888_72cba32f0bfc98b4 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erendered(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esigText(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2)
@olang_loc_db1f2ae5e4bef7a4_1fc823cb35fb1540 = external constant [0 x i8]
@olang_loc_404270212748a64a_94da604f2263273e = external constant [0 x i8]
@olang_loc_e2c214b199db46e1_ccde8582cd2310f5 = external constant [0 x i8]
@olang_loc_2d29d2076870b150_9b91c954cc3aa504 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnsParts(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroBorrowedFrom(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRef(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceBody(ptr %v0, ptr %a0, i64 %a1)
declare %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" @std_2fpair_3aPair_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0, ptr %v1, i64 %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H316d0dfdbceeb7b188a6719f0ad8fbbe(ptr %v0, ptr %v1, ptr %a0, %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H48754b4fa56ee3a8c3b855086bca91dc(ptr %v0, ptr %a0)
declare %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H015c7298d54f1d140374736283ef15ae(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroDeep(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, ptr %a3)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i1 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fcheck_2elowerFirst(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_H06f4ae43b564aa38800728c5b9a6edfe(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_Hb04d670045d084ea2498d9030c4fbba9(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshapeOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
@olang_loc_b8e2733ff2674fd_52419f97eade6699 = external constant [0 x i8]
@olang_loc_4fb1ec40319fc7d0_191a57ffdbf9a78c = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eslicedWritable(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/typed:Slice" @compiler_2ftyped_3aSlice_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i32 %a3)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotIndexable(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, %"compiler/source:Span" %a3, { i64, ptr } %a4, i64 %a5, i1 %a6)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneedErr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, { i64, ptr } %a3, %"compiler/msgs:Msg" %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/source:Span" %a2)
@olang_loc_5aa0e1f55b10e6f_53045464d54dc2fb = external constant [0 x i8]
@olang_loc_e4f33d7277813d9a_8adeed4fca551266 = external constant [0 x i8]
@olang_loc_b203c9fbf4c249fb_735051f472c86bf = external constant [0 x i8]
@olang_loc_85a2f2931038d80c_e5a946dd8e187d18 = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esliceLength(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2, ptr %a3)
@olang_loc_2f1aad6b95023edd_c82f5ce971f0d619 = external constant [0 x i8]
@olang_loc_7151da8c7014d0c8_6aa5246f01d956ac = external constant [0 x i8]
@olang_loc_16d25af731eb828d_f9df92790de43871 = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprStmt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emulti(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eassign(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, ptr %a4)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etryStore(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, { i64, ptr } %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eifStmt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eloop(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, { i64, ptr } %a3, ptr %a4)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efor3(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eforIn(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edoFor(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2, ptr %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereturnStmt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebecomeStmt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eyieldStmt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ematchStmt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ejump(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectCond(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflDecide(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econd1(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emessage(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i1 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushFacts(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2, i64 %a3)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eCondBody(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflText(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eExprBody(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i32 %a3)
declare { { i64, [3 x i64] }, { i64, ptr } } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eTopContext(ptr %v0, ptr %v1, ptr %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperatorOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2fcheck_3aAssertAsk_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, i64 %a0, i64 %a1, %"compiler/source:Span" %a2, %"compiler/source:Span" %a3, i64 %a4, i64 %a5, { i64, ptr } %a6, { i64, [3 x i64] } %a7, { i64, ptr } %a8, i1 %a9, { i64, ptr } %a10, { i64, ptr } %a11)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAssertAsk_3e_2ePush_Hbdaad063a73077b3b5842d615b8c1d82(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eraise(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeferStmt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i1 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eblockOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2, %"compiler/source:Span" %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ejoinStmt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espawnStmt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2, ptr %a3)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v0, ptr %a0)
@olang_loc_97a078c1fd6401ad_6b439c1864d584b1 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eLen_H4b13e48b0a317e727dbe35330ad8712a(ptr %v0, ptr %a0)
declare %"compiler/check:nullNarrow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eAt__H22e551fb00043bde3f1f8b2c6007f7cb(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2estmtAssigns(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2eassignsWhole(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/check:nullNarrow" @compiler_2fcheck_3anullNarrow_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i1 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eSet_H93968e49180de2bc6256fae5bb61b442(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/check:nullNarrow" %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eLen_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %a0)
declare %"compiler/check:narrowed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eAt_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/check:narrowed" @compiler_2fcheck_2ecompiler_2fcheck_3anarrowed_2eKilled(%"compiler/check:narrowed" %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eSetAt_Hd90ea4a0afde5538aa0fe5c36a170321(ptr %v0, ptr %a0, i64 %a1, %"compiler/check:narrowed" %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eLen__H3cdfcddd9c493bd8bcefc7b766e0438b(ptr %v0, ptr %a0)
declare %"compiler/check:errNarrow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eAt_3ccompiler_2fcheck_3aerrNarrow_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_f0430e4b284237b0_c6243626a46be64 = external constant [0 x i8]
declare %"compiler/check:errNarrow" @compiler_2fcheck_3aerrNarrow_2ector(ptr %v0, i32 %a0, i32 %a1, i64 %a2, i1 %a3)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eSetA_H34a7475a189e9b126454728216b32261(ptr %v0, ptr %a0, i64 %a1, %"compiler/check:errNarrow" %a2)
@olang_loc_28ca8569d2f90b5d_c88a44871853971 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2ePus_H6cb9d90d121a5c1d081cb085b656665f(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:nullNarrow" %a1)
@olang_loc_8296d6abcbfdbd1e_e4e071066943c4d2 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fscan_2eLiteralBytes(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
@olang_loc_7cf0066f219391e3_f59e2f38f1229917 = external constant [0 x i8]
@olang_loc_93e3a02800d00d4_2c47855b6b12ccf8 = external constant [0 x i8]
@olang_loc_ead499c86a25c3f7_b1128c547d2ccfbb = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eStrReceiverWritable(ptr %v0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
@olang_loc_4caebcac4cec7311_26f3d9a9847d99e5 = external constant [0 x i8]
@olang_loc_35044444f92db59c_e1f3123be845f968 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyCaseType(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyInstance(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3, i32 %a4)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLet(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare %"compiler/typed:Bind" @compiler_2ftyped_3aBind_2ector(ptr %v0, ptr %v1, i32 %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBind_26_3e_2ePush_3ccompiler_2ftyped_3aBind_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eembed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecomptime(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArray(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneUnary(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eOperandNotBool(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPiece_26_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPiece_26_3e_2ePush_3ccompiler_2ftyped_3aPiece_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPiece_26_3e_2eToArr_H1b89f7fcc263bba924ca04e7c3aa48c7(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/typed:Text" @compiler_2ftyped_3aText_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %v0, i32 %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleUse(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, i64 %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5)
@olang_loc_e153c6abdfe6ecb0_f26e63b1d3597a0c = external constant [0 x i8]
@olang_loc_19db3dca8a9dc05d_2b95ab49e23e3919 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotExtendedOp(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eOperandNotNumber(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisInt(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eOperandNotInt(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePush_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrollBind(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrollUnbind(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eComptimeForSource(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrollable(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eComptimeForElem(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroNeed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2ePush_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, [2 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emarkOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_31b59b203b4a4e3f_1cfff4f24a22d803 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emutBefore(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eMutOnInferredLocal(ptr %v0)
@olang_loc_35f48b5c7c141c20_d3954a821088874 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eMutOnValueField(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eMutOnLocal(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eFieldHasParamName(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteDeclaredHere(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/check:unsetCand" @compiler_2fcheck_3aunsetCand_2ector(ptr %v0, i64 %a0, i64 %a1, i64 %a2, i1 %a3, i64 %a4, %"compiler/source:Span" %a5, i32 %a6, i1 %a7)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efieldTypeAt(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eStorageOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, ptr %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunArrayValue(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLengthsOnly(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@olang_loc_458efae6ce1c735_ac6225d3d907fb69 = external constant [0 x i8]
@olang_loc_f3c73b72e55a8b8e_5460cc7526c67482 = external constant [0 x i8]
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeWrittenAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efilledNext(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
@olang_loc_de90e7498c4216b3_b17be322d1a772cf = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einferred(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i1 %a3)
@olang_loc_36f1ca435b2ee6e4_790f65bce77245f0 = external constant [0 x i8]
@olang_loc_f2aff2ea660e9d99_96029929a029dd45 = external constant [0 x i8]
@olang_loc_91617ece661d0672_429c03ea7d9d989e = external constant [0 x i8]
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHold(ptr %v0, ptr %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezero(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aValueAsk_3e_2eLen_3ccompiler_2fcheck_3aValueAsk_3e(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2easkValue(ptr %v0, ptr %v1, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4)
@olang_loc_60b97769ab73fcb7_dac12c977cbf3c9b = external constant [0 x i8]
@G_2ecompiler_2fcheck_2eRoDecl = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroStore(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i64 %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoClearMade(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eRefMut_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aunsetCand_3e_2ePush_Hd5bae6439baa110b1f2b8b5b7cdda5ce(ptr %v0, ptr %a0, %"compiler/check:unsetCand" %a1)
@olang_loc_456a500fefc58a98_a2eaf47e24a406ac = external constant [0 x i8]
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fdiag_3aWhere_3e_2e_Hc07a7e56a24d8f1225398db99ea19a4b(ptr %v0, ptr %a0, i64 %a1, { i64, [3 x i64] } %a2)
@olang_loc_3b566e89984acdce_dde06b5f9a89c81a = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplainScalar(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/check:fixedInit" @compiler_2fcheck_3afixedInit_2ector(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5daf2b89f219287cc2404f0b0e96c809(ptr %v0, ptr %v1, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, %"compiler/check:fixedInit" %a2)
@olang_loc_9c28400664f91d75_969ef375bde61da1 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2escopedValue(ptr %v0, ptr %a0)
@olang_loc_982a334cfac79560_875fefac8daf1dec = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eforRange(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, { i64, ptr } %a3, ptr %a4, i32 %a5)
@olang_loc_1c0ab263f2e4f7dc_3e069dbdc7ae0b68 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroTrack(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecounted(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3, i64 %a4, i64 %a5, i32 %a6, i64 %a7, i64 %a8, ptr %a9, i32 %a10)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecomprOpen(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkIter(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i64 %a4, ptr %a5, i32 %a6)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotIterable(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eiterShaped(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkRuns(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i64 %a4, ptr %a5, i32 %a6)
@olang_loc_139af6e2a2dcda96_1438f6a9e620193a = external constant [0 x i8]
@olang_loc_a734531b29123b5_def2307fb88201b9 = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkIndexed(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i64 %a4, i64 %a5, ptr %a6, i32 %a7)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecaseDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eStepNotNumber(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %v0, i32 %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperatorCall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, ptr %a5)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eWriteThroughAtOperator(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_20f9f67d26588f89_c77aed4cf9eaedd5 = external constant [0 x i8]
declare i32 @compiler_2fcheck_2esetName(ptr %v0, ptr %a0)
@olang_loc_19f4e92ae3000dc_edc59080f5379130 = external constant [0 x i8]
@olang_loc_9272b3113db2835a_2a2a8b0a39f9db7e = external constant [0 x i8]
@olang_loc_e85625530f05a4e1_e8094ee11349b825 = external constant [0 x i8]
@olang_loc_fd7989cc94cf1ac3_95016419ffbfbd17 = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ehandleRoot(ptr %v0, ptr %a0)
@olang_loc_cf73afff9a9afd3c_75ef637926e6ccb8 = external constant [0 x i8]
@olang_loc_a08a248bd178667f_2aaba0f11d7155db = external constant [0 x i8]
@olang_loc_4777492a424db66f_87dc2d494f6ca16b = external constant [0 x i8]
@olang_loc_8d3b159055c7af2c_5997e8ea93888888 = external constant [0 x i8]
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
