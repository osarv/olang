; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64 }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, i32, i1, i1 }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [1 x i64] }, i1, i1 }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/diagmsg:Msg" = type { i32, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/typed:Bind" = type { i32, ptr }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i64, i64, i1, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, i64, i32, i1, { i64, [3 x i64] }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i32, i64, %"compiler/source:Span", i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/source:Span", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/check:knownRange", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, %"compiler/source:Span", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i1, i64, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i64, i64, i64, i64, i64, i64, i1, i1, i1, i32, i64, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/diag:Taken", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/text:StringBuilder", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/check:knownRange" = type { i64, i64, i64 }
%"compiler/diag:Taken" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"compiler/facts:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/facts:Table" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64 }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64, i32 }
%"compiler/generic:AnySlot" = type { i32, i32, i64, i64, i1, i32, i32 }
%"compiler/check:frame" = type { i64, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/generic:Context", i32, i32, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i32, i64, i64, i64, i1, i64, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i64, i64, i64, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i64, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/source:Span", i64, i1 }
%"compiler/generic:Context" = type { i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/generic:AnyTable" = type { i32, i32, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/ast:Branch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/cond:Value" = type { i32, i64, double, i64, i64, i1, i1 }
%"compiler/cond:Consts" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32, i1 }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr, { i64, ptr }, i32, i1, ptr, i32 }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr, { i64, ptr } }
%"compiler/check:litv" = type { i1, i1, i1, i64, double, i1, i1, i1, i128 }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr, i1 }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/check:weakPlace" = type { { i64, [3 x i64] }, { i64, ptr }, i64 }
%"compiler/check:ownerAt" = type { i32, i1 }
%"compiler/check:laneNode" = type { i64, i32, %"compiler/source:Span", %"compiler/source:Span", i64, i64, i64, ptr, i32, i64, i32 }
%"compiler/check:laneVals" = type { i64, i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/msgs:Nearest" = type { { i64, ptr }, { i64, ptr }, i64 }
%"compiler/check:narrowed" = type { i64, i64, i32, i64, i64, { i64, ptr }, i64, i1, i64 }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/generic:Desc" = type { i64, i32, i64, i64 }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, { i64, ptr }, ptr, i32 }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, i1, i1, { i64, ptr } }
%"compiler/check:payloadItem" = type { i32, ptr }
%"compiler/check:rangeIndex" = type { i64, %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i64, i64 }
%"compiler/diag:Diagnostics" = type { i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, [3 x i64] }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/generic:Binding" = type { i64, i64, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/ast:Match" = type { %"compiler/source:Span", ptr, i1, { i64, ptr } }
%"compiler/check:typeCase" = type { i1, i1, i32, i64, i64, i1 }
%"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa" = type { i32, i32 }
%"compiler/ast:CaseDecl" = type { %"compiler/source:Span", i32, { i64, ptr }, i1, ptr, { i64, ptr } }
%"compiler/typed:Match" = type { { i64, ptr }, { i64, ptr }, ptr, i1 }
%"compiler/typed:Arm" = type { %"compiler/source:Span", { i64, ptr }, ptr, ptr, ptr }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1, { i64, ptr }, i1 }
%"compiler/ast:Multi" = type { { i64, ptr }, i1, { i64, ptr } }
%"compiler/ast:For3" = type { ptr, ptr, ptr, { i64, ptr } }
%"compiler/ast:ForIn" = type { i32, i32, ptr, i1, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/ast:JoinS" = type { i1, { i64, ptr }, { i64, ptr } }
%"compiler/ast:Catch" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i32, %"compiler/source:Span" }
%"compiler/check:tailAsk" = type { i64, i64, %"compiler/source:Span", i64 }
define dso_local i1 @compiler_2fcheck_2eclosedCall(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca i1
  %l17 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Call", ptr %t1, i32 0, i32 3
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/typed:Call", ptr %t7, i32 0, i32 0
  %t10 = load ptr, ptr %t9, !tbaa !29
  store ptr %t10, ptr %l1, !tbaa !29
  %t12 = load ptr, ptr %l1, !tbaa !29
  store ptr %t12, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t13 = load ptr, ptr %l7, !tbaa !29
  %t14 = icmp ne ptr %t13, null
  br i1 %t14, label %bb4, label %bb5
bb4:
  %t16 = load ptr, ptr %l7, !tbaa !29
  %t17 = load i64, ptr %t16, !range !{i64 0, i64 5}
  %t19 = icmp eq i64 %t17, 0
  store i1 %t19, ptr %l8, !tbaa !21
  br label %bb5
bb5:
  %t20 = load i1, ptr %l8, !tbaa !21
  br i1 %t20, label %bb6, label %bb7
bb6:
  br label %bb12
bb7:
  %t21 = load ptr, ptr %l1, !tbaa !29
  store ptr %t21, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t22 = load ptr, ptr %l11, !tbaa !29
  %t23 = icmp ne ptr %t22, null
  br i1 %t23, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l11, !tbaa !29
  %t26 = load i64, ptr %t25, !range !{i64 0, i64 5}
  %t28 = icmp eq i64 %t26, 4
  store i1 %t28, ptr %l12, !tbaa !21
  br label %bb9
bb9:
  %t29 = load i1, ptr %l12, !tbaa !21
  br i1 %t29, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/typed:Call", ptr %t30, i32 0, i32 1
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  %t35 = call i1 @compiler_2fcheck_2eclosedAll(ptr %v0, { i64, ptr } %t33)
  store i1 %t35, ptr %l17
  br label %bb13
bb13:
  %t36 = load i1, ptr %l17, !tbaa !21
  store i1 %t36, ptr %rv
  br label %ret
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i1 false, ptr %rv
  br label %ret
bb18:
  call void @__olang_check_failed(ptr @olang_loc_317fdf139725c543_9c9e0109f99156f7)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ealtNames(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i64 %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca i32
  %l23 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca i64
  %l27 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l29 = alloca i64
  %l31 = alloca i64
  %l36 = alloca ptr
  %l37 = alloca ptr
  %l39 = alloca ptr
  %l42 = alloca %"compiler/typed:Local"
  %l49 = alloca i64
  %l51 = alloca i64
  %l56 = alloca i32
  %l62 = alloca i64
  %l64 = alloca i64
  %l69 = alloca ptr
  %l71 = alloca ptr
  %l74 = alloca %"compiler/typed:Local"
  %l77 = alloca i64
  %l79 = alloca i64
  %l84 = alloca i32
  %l92 = alloca ptr
  %l94 = alloca ptr
  %l97 = alloca %"compiler/typed:Local"
  %l98 = alloca %"compiler/source:Span"
  %l99 = alloca %"compiler/diagmsg:Msg"
  %l100 = alloca i64
  %l104 = alloca i64
  %l106 = alloca i64
  %l111 = alloca i32
  %l113 = alloca i64
  %l115 = alloca i64
  %l120 = alloca i32
  %l128 = alloca ptr
  %l130 = alloca %"compiler/source:Span"
  %l131 = alloca %"compiler/diagmsg:Msg"
  %l132 = alloca i64
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l27
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l27
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l5
  %t3 = load ptr, ptr %l1, !tbaa !29
  store ptr %t3, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb2
bb2:
  %t5 = load i64, ptr %l7, !tbaa !24
  store i64 %t5, ptr %l29, !tbaa !24
  %t6 = load ptr, ptr %l6, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBind_26_3e_2eLen_3ccompiler_2ftyped_3aBind_26_3e(ptr %v1, ptr %t6)
  store i64 %t8, ptr %l31
  br label %bb3
bb3:
  %t9 = load i64, ptr %l29, !tbaa !24
  %t10 = load i64, ptr %l31, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb4, label %bb5
bb4:
  br label %bb12
bb5:
  br label %bb6
bb6:
  %t15 = load ptr, ptr %l6, !tbaa !29
  %t16 = load i64, ptr %l7, !tbaa !24
  %t19 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBind_26_3e_2eAt_3ccompiler_2ftyped_3aBind_26_3e(ptr %v1, ptr %v1, ptr %t15, i64 %t16)
  store ptr %t19, ptr %l36
  br label %bb7
bb7:
  %t20 = load ptr, ptr %l36, !tbaa !29
  store ptr %t20, ptr %l8, !tbaa !29
  store ptr %l5, ptr %l37, !tbaa !29
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t21)
  store ptr %t23, ptr %l39
  br label %bb8
bb8:
  %t24 = load ptr, ptr %l8, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Bind", ptr %t24, i32 0, i32 0
  %t27 = load i32, ptr %t26, !tbaa !23
  %t28 = load ptr, ptr %l39, !tbaa !29
  %t30 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t28, i32 %t27)
  store %"compiler/typed:Local" %t30, ptr %l42
  br label %bb9
bb9:
  %t31 = getelementptr %"compiler/typed:Local", ptr %l42, i32 0, i32 0
  %t32 = load i32, ptr %t31, !tbaa !23
  %t33 = load ptr, ptr %l37, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %t33, i32 %t32)
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t35 = load i64, ptr %l7, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l7, !tbaa !24
  br label %bb2
bb12:
  %t41 = icmp eq i64 %a3, 0
  br i1 %t41, label %bb13, label %bb14
bb13:
  store ptr %l5, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb15
bb14:
  br label %bb24
bb15:
  %t44 = load i64, ptr %l10, !tbaa !24
  store i64 %t44, ptr %l49, !tbaa !24
  %t45 = load ptr, ptr %l9, !tbaa !29
  %t47 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %t45)
  store i64 %t47, ptr %l51
  br label %bb16
bb16:
  %t48 = load i64, ptr %l49, !tbaa !24
  %t49 = load i64, ptr %l51, !tbaa !24
  %t50 = icmp slt i64 %t48, %t49
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb17, label %bb18
bb17:
  br label %bb23
bb18:
  br label %bb19
bb19:
  %t54 = load ptr, ptr %l9, !tbaa !29
  %t55 = load i64, ptr %l10, !tbaa !24
  %t58 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %t54, i64 %t55)
  store i32 %t58, ptr %l56
  br label %bb20
bb20:
  %t59 = load i32, ptr %l56, !tbaa !23
  %t60 = load ptr, ptr %l2, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v2, ptr %t60, i32 %t59)
  br label %bb21
bb21:
  br label %bb22
bb22:
  %t64 = load i64, ptr %l10, !tbaa !24
  %t66 = add i64 %t64, 1
  store i64 %t66, ptr %l10, !tbaa !24
  br label %bb15
bb23:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb24:
  %t68 = load ptr, ptr %l1, !tbaa !29
  store ptr %t68, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  br label %bb25
bb25:
  %t70 = load i64, ptr %l13, !tbaa !24
  store i64 %t70, ptr %l62, !tbaa !24
  %t71 = load ptr, ptr %l12, !tbaa !29
  %t73 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBind_26_3e_2eLen_3ccompiler_2ftyped_3aBind_26_3e(ptr %v1, ptr %t71)
  store i64 %t73, ptr %l64
  br label %bb26
bb26:
  %t74 = load i64, ptr %l62, !tbaa !24
  %t75 = load i64, ptr %l64, !tbaa !24
  %t76 = icmp slt i64 %t74, %t75
  %t78 = xor i1 %t76, true
  br i1 %t78, label %bb27, label %bb28
bb27:
  br label %bb52
bb28:
  br label %bb29
bb29:
  %t80 = load ptr, ptr %l12, !tbaa !29
  %t81 = load i64, ptr %l13, !tbaa !24
  %t84 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBind_26_3e_2eAt_3ccompiler_2ftyped_3aBind_26_3e(ptr %v1, ptr %v1, ptr %t80, i64 %t81)
  store ptr %t84, ptr %l69
  br label %bb30
bb30:
  %t85 = load ptr, ptr %l69, !tbaa !29
  store ptr %t85, ptr %l14, !tbaa !29
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t86)
  store ptr %t88, ptr %l71
  br label %bb31
bb31:
  %t89 = load ptr, ptr %l14, !tbaa !29
  %t91 = getelementptr %"compiler/typed:Bind", ptr %t89, i32 0, i32 0
  %t92 = load i32, ptr %t91, !tbaa !23
  %t93 = load ptr, ptr %l71, !tbaa !29
  %t95 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t93, i32 %t92)
  store %"compiler/typed:Local" %t95, ptr %l74
  br label %bb32
bb32:
  %t96 = getelementptr %"compiler/typed:Local", ptr %l74, i32 0, i32 0
  %t97 = load i32, ptr %t96, !tbaa !23
  store i32 %t97, ptr %l15, !tbaa !23
  store i1 false, ptr %l16, !tbaa !21
  %t99 = load ptr, ptr %l2, !tbaa !29
  store ptr %t99, ptr %l17, !tbaa !29
  store i64 0, ptr %l18, !tbaa !24
  br label %bb33
bb33:
  %t101 = load i64, ptr %l18, !tbaa !24
  store i64 %t101, ptr %l77, !tbaa !24
  %t102 = load ptr, ptr %l17, !tbaa !29
  %t104 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v2, ptr %t102)
  store i64 %t104, ptr %l79
  br label %bb34
bb34:
  %t105 = load i64, ptr %l77, !tbaa !24
  %t106 = load i64, ptr %l79, !tbaa !24
  %t107 = icmp slt i64 %t105, %t106
  %t109 = xor i1 %t107, true
  br i1 %t109, label %bb35, label %bb36
bb35:
  br label %bb43
bb36:
  br label %bb37
bb37:
  %t111 = load ptr, ptr %l17, !tbaa !29
  %t112 = load i64, ptr %l18, !tbaa !24
  %t115 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %v2, ptr %t111, i64 %t112)
  store i32 %t115, ptr %l84
  br label %bb38
bb38:
  %t116 = load i32, ptr %l84, !tbaa !23
  %t118 = load i32, ptr %l15, !tbaa !23
  %t121 = icmp eq i32 %t116, %t118
  br i1 %t121, label %bb39, label %bb40
bb39:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb41
bb40:
  br label %bb41
bb41:
  br label %bb42
bb42:
  %t123 = load i64, ptr %l18, !tbaa !24
  %t125 = add i64 %t123, 1
  store i64 %t125, ptr %l18, !tbaa !24
  br label %bb33
bb43:
  %t127 = load i1, ptr %l16, !tbaa !21
  %t129 = xor i1 %t127, true
  br i1 %t129, label %bb44, label %bb45
bb44:
  %t131 = load ptr, ptr %l0, !tbaa !29
  store ptr %t131, ptr %l92, !tbaa !29
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t132)
  store ptr %t134, ptr %l94
  br label %bb46
bb45:
  br label %bb50
bb46:
  %t135 = load ptr, ptr %l14, !tbaa !29
  %t137 = getelementptr %"compiler/typed:Bind", ptr %t135, i32 0, i32 0
  %t138 = load i32, ptr %t137, !tbaa !23
  %t139 = load ptr, ptr %l94, !tbaa !29
  %t141 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t139, i32 %t138)
  store %"compiler/typed:Local" %t141, ptr %l97
  br label %bb47
bb47:
  %t142 = getelementptr %"compiler/typed:Local", ptr %l97, i32 0, i32 1
  %t143 = load %"compiler/source:Span", ptr %t142
  store %"compiler/source:Span" %t143, ptr %l98
  %t144 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAltBindsOtherNames(ptr %v0)
  store %"compiler/diagmsg:Msg" %t144, ptr %l99
  br label %bb48
bb48:
  %t145 = load ptr, ptr %l92, !tbaa !29
  %t146 = load %"compiler/source:Span", ptr %l98
  %t147 = load %"compiler/diagmsg:Msg", ptr %l99
  %t148 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t145, %"compiler/source:Span" %t146, %"compiler/diagmsg:Msg" %t147)
  store i64 %t148, ptr %l100
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb50:
  br label %bb51
bb51:
  %t149 = load i64, ptr %l13, !tbaa !24
  %t151 = add i64 %t149, 1
  store i64 %t151, ptr %l13, !tbaa !24
  br label %bb25
bb52:
  %t153 = load ptr, ptr %l2, !tbaa !29
  store ptr %t153, ptr %l20, !tbaa !29
  store i64 0, ptr %l21, !tbaa !24
  br label %bb53
bb53:
  %t155 = load i64, ptr %l21, !tbaa !24
  store i64 %t155, ptr %l104, !tbaa !24
  %t156 = load ptr, ptr %l20, !tbaa !29
  %t158 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v2, ptr %t156)
  store i64 %t158, ptr %l106
  br label %bb54
bb54:
  %t159 = load i64, ptr %l104, !tbaa !24
  %t160 = load i64, ptr %l106, !tbaa !24
  %t161 = icmp slt i64 %t159, %t160
  %t163 = xor i1 %t161, true
  br i1 %t163, label %bb55, label %bb56
bb55:
  br label %bb77
bb56:
  br label %bb57
bb57:
  %t165 = load ptr, ptr %l20, !tbaa !29
  %t166 = load i64, ptr %l21, !tbaa !24
  %t169 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %v2, ptr %t165, i64 %t166)
  store i32 %t169, ptr %l111
  br label %bb58
bb58:
  %t170 = load i32, ptr %l111, !tbaa !23
  store i32 %t170, ptr %l22, !tbaa !23
  store i1 false, ptr %l23, !tbaa !21
  store ptr %l5, ptr %l24, !tbaa !29
  store i64 0, ptr %l25, !tbaa !24
  br label %bb59
bb59:
  %t172 = load i64, ptr %l25, !tbaa !24
  store i64 %t172, ptr %l113, !tbaa !24
  %t173 = load ptr, ptr %l24, !tbaa !29
  %t175 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %t173)
  store i64 %t175, ptr %l115
  br label %bb60
bb60:
  %t176 = load i64, ptr %l113, !tbaa !24
  %t177 = load i64, ptr %l115, !tbaa !24
  %t178 = icmp slt i64 %t176, %t177
  %t180 = xor i1 %t178, true
  br i1 %t180, label %bb61, label %bb62
bb61:
  br label %bb69
bb62:
  br label %bb63
bb63:
  %t182 = load ptr, ptr %l24, !tbaa !29
  %t183 = load i64, ptr %l25, !tbaa !24
  %t186 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %t182, i64 %t183)
  store i32 %t186, ptr %l120
  br label %bb64
bb64:
  %t187 = load i32, ptr %l120, !tbaa !23
  %t189 = load i32, ptr %l22, !tbaa !23
  %t192 = icmp eq i32 %t187, %t189
  br i1 %t192, label %bb65, label %bb66
bb65:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb67
bb66:
  br label %bb67
bb67:
  br label %bb68
bb68:
  %t194 = load i64, ptr %l25, !tbaa !24
  %t196 = add i64 %t194, 1
  store i64 %t196, ptr %l25, !tbaa !24
  br label %bb59
bb69:
  %t198 = load i1, ptr %l23, !tbaa !21
  %t200 = xor i1 %t198, true
  br i1 %t200, label %bb70, label %bb71
bb70:
  %t202 = load ptr, ptr %l0, !tbaa !29
  store ptr %t202, ptr %l128, !tbaa !29
  %t205 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v3, ptr %a4)
  store %"compiler/source:Span" %t205, ptr %l130
  br label %bb72
bb71:
  br label %bb75
bb72:
  %t206 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAltBindsOtherNames(ptr %v0)
  store %"compiler/diagmsg:Msg" %t206, ptr %l131
  br label %bb73
bb73:
  %t207 = load ptr, ptr %l128, !tbaa !29
  %t208 = load %"compiler/source:Span", ptr %l130
  %t209 = load %"compiler/diagmsg:Msg", ptr %l131
  %t210 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t207, %"compiler/source:Span" %t208, %"compiler/diagmsg:Msg" %t209)
  store i64 %t210, ptr %l132
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb75:
  br label %bb76
bb76:
  %t211 = load i64, ptr %l21, !tbaa !24
  %t213 = add i64 %t211, 1
  store i64 %t213, ptr %l21, !tbaa !24
  br label %bb53
bb77:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyHandle(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l11 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l23 = alloca i1
  %l26 = alloca i1
  %l28 = alloca i1
  %l33 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t6, i32 %a1)
  store { i64, ptr } %t10, ptr %l11
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t11, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  store i64 %t14, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t16 = load i64, ptr %l4, !tbaa !24
  %t17 = load i64, ptr %l5, !tbaa !24
  %t20 = icmp slt i64 %t16, %t17
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb3, label %bb4
bb3:
  br label %bb18
bb4:
  br label %bb5
bb5:
  %t24 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t24, ptr %l18, !tbaa !27
  %t25 = load i64, ptr %l4, !tbaa !24
  %t27 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i32, ptr %t28, i64 %t25
  %t30 = load i32, ptr %t29, !tbaa !33
  store i32 %t30, ptr %l6, !tbaa !23
  %t32 = load i32, ptr %l6, !tbaa !23
  %t34 = icmp ne i32 %t32, 0
  br i1 %t34, label %bb6, label %bb7
bb6:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load i32, ptr %l6, !tbaa !23
  %t40 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t36, i32 %t37)
  store i1 %t40, ptr %l26
  br label %bb8
bb7:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb9
bb8:
  %t41 = load i1, ptr %l26, !tbaa !21
  %t42 = xor i1 %t41, true
  store i1 %t42, ptr %l23, !tbaa !21
  br label %bb9
bb9:
  %t44 = load i1, ptr %l23, !tbaa !21
  br i1 %t44, label %bb10, label %bb11
bb10:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load i32, ptr %l6, !tbaa !23
  %t49 = add i64 %a2, 1
  %t53 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsHandle(ptr %v0, ptr %t45, i32 %t46, i64 %t49)
  store i1 %t53, ptr %l33
  br label %bb12
bb11:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb13
bb12:
  %t54 = load i1, ptr %l33, !tbaa !21
  store i1 %t54, ptr %l28, !tbaa !21
  br label %bb13
bb13:
  %t55 = load i1, ptr %l28, !tbaa !21
  br i1 %t55, label %bb14, label %bb15
bb14:
  store i1 true, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t57 = load i64, ptr %l4, !tbaa !24
  %t59 = add i64 %t57, 1
  store i64 %t59, ptr %l4, !tbaa !24
  br label %bb2
bb18:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyTable(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca %"compiler/generic:AnySlot"
  %l15 = alloca i64
  %l16 = alloca i32
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca %"compiler/generic:AnySlot"
  %l30 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l35 = alloca i64
  %l41 = alloca i1
  %l42 = alloca i64
  %l45 = alloca ptr
  %l46 = alloca i32
  %l47 = alloca i32
  %l49 = alloca ptr
  %l53 = alloca i64
  %l57 = alloca { i64, ptr }
  %l59 = alloca ptr
  %l64 = alloca i32
  %l65 = alloca i32
  %l71 = alloca i64
  %l74 = alloca i64
  %l92 = alloca { i64, ptr }
  %l99 = alloca i64
  %l107 = alloca i32
  %l109 = alloca ptr
  %l111 = alloca i64
  %l112 = alloca i64
  %l117 = alloca i32
  %l124 = alloca i32
  %l128 = alloca i1
  %l132 = alloca i1
  %l134 = alloca ptr
  %l135 = alloca %"compiler/source:Span"
  %l138 = alloca { i64, ptr }
  %l139 = alloca { i64, ptr }
  %l142 = alloca { i64, ptr }
  %l143 = alloca { i64, ptr }
  %l146 = alloca { i64, ptr }
  %l148 = alloca %"compiler/diagmsg:Msg"
  %l149 = alloca i64
  %l152 = alloca ptr
  %l153 = alloca i64
  %l154 = alloca i64
  %l157 = alloca { i64, ptr }
  %l159 = alloca %"compiler/diagmsg:Msg"
  %l170 = alloca ptr
  %l172 = alloca ptr
  %l180 = alloca i64
  %l183 = alloca i64
  %l201 = alloca { i64, ptr }
  %l206 = alloca ptr
  %l211 = alloca i32
  %l212 = alloca { i64, ptr }
  %l216 = alloca { i64, ptr }
  %l218 = alloca i64
  %l221 = alloca ptr
  %l222 = alloca i32
  %l228 = alloca i32
  %l229 = alloca i32
  %l231 = alloca ptr
  %l239 = alloca i64
  %l242 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %s0 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca i64
  %t446 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i32, ptr %l1, !tbaa !23
  %t6 = load i32, ptr %l2, !tbaa !23
  %t10 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnyTableOf(ptr %v0, ptr %t4, i32 %t5, i32 %t6)
  store i64 %t10, ptr %l35
  br label %bb1
bb1:
  %t11 = load i64, ptr %l35, !tbaa !24
  store i64 %t11, ptr %l4, !tbaa !24
  %t12 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp sge i64 %t12, 0
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 163
  %t19 = load i64, ptr %l4, !tbaa !24
  %t22 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t18, i64 %t19)
  store i1 %t22, ptr %l41
  br label %bb4
bb3:
  br label %bb8
bb4:
  %t23 = load i1, ptr %l41, !tbaa !21
  br i1 %t23, label %bb5, label %bb6
bb5:
  store i64 -1, ptr %l42, !tbaa !24
  br label %bb7
bb6:
  %t24 = load i64, ptr %l4, !tbaa !24
  store i64 %t24, ptr %l42, !tbaa !24
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t26 = load i64, ptr %l42, !tbaa !24
  store i64 %t26, ptr %rv
  br label %ret
bb8:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/check:Checker", ptr %t27, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !29
  store ptr %t30, ptr %l45, !tbaa !29
  %t31 = load i32, ptr %l1, !tbaa !23
  store i32 %t31, ptr %l46, !tbaa !23
  %t32 = load i32, ptr %l2, !tbaa !23
  store i32 %t32, ptr %l47, !tbaa !23
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t33)
  store ptr %t35, ptr %l49
  br label %bb9
bb9:
  %t36 = load ptr, ptr %l49, !tbaa !29
  %t38 = getelementptr %"compiler/check:frame", ptr %t36, i32 0, i32 2
  %t39 = load i64, ptr %t38, !tbaa !24
  %t40 = load %"compiler/source:Span", ptr %l3
  %t41 = load ptr, ptr %l45, !tbaa !29
  %t42 = load i32, ptr %l46, !tbaa !23
  %t43 = load i32, ptr %l47, !tbaa !23
  %t46 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eNewAnyTable(ptr %v0, ptr %t41, i32 %t42, i32 %t43, i64 %t39, %"compiler/source:Span" %t40)
  store i64 %t46, ptr %l53
  br label %bb10
bb10:
  %t47 = load i64, ptr %l53, !tbaa !24
  store i64 %t47, ptr %l5, !tbaa !24
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/check:Checker", ptr %t48, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t52 = load i32, ptr %l2, !tbaa !23
  %t55 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %v0, ptr %t51, i32 %t52)
  store { i64, ptr } %t55, ptr %l57
  br label %bb11
bb11:
  %t56 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t56, ptr %l6, !tbaa !27
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  store ptr %t60, ptr %l59, !tbaa !29
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/check:Checker", ptr %t61, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t66 = getelementptr %"compiler/generic:Program", ptr %t64, i32 0, i32 2
  %t67 = load i32, ptr %l1, !tbaa !23
  %t70 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t66, i32 %t67)
  store i32 %t70, ptr %l64
  br label %bb12
bb12:
  %t71 = load ptr, ptr %l59, !tbaa !29
  %t72 = load i32, ptr %l64, !tbaa !23
  %t73 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnyStored(ptr %v0, ptr %t71, i32 %t72)
  store i32 %t73, ptr %l65
  br label %bb13
bb13:
  %t74 = load i32, ptr %l65, !tbaa !23
  store i32 %t74, ptr %l7, !tbaa !23
  store i64 0, ptr %l8, !tbaa !24
  %t75 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t75, 0
  store i64 %t77, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t79 = load i64, ptr %l9, !tbaa !24
  %t80 = load i64, ptr %l8, !tbaa !24
  %t83 = icmp sgt i64 %t79, %t80
  br i1 %t83, label %bb14, label %bb15
bb14:
  %t85 = load i64, ptr %l10, !tbaa !24
  %t87 = icmp sgt i64 %t85, 0
  br i1 %t87, label %bb16, label %bb17
bb15:
  store i64 0, ptr %l71, !tbaa !24
  br label %bb19
bb16:
  %t89 = load i64, ptr %l9, !tbaa !24
  %t90 = load i64, ptr %l8, !tbaa !24
  %t93 = sub i64 %t89, %t90
  %t94 = load i64, ptr %l10, !tbaa !24
  %t97 = add i64 %t93, %t94
  %t99 = sub i64 %t97, 1
  %t100 = load i64, ptr %l10, !tbaa !24
  %t103 = sdiv i64 %t99, %t100
  store i64 %t103, ptr %l74, !tbaa !24
  br label %bb18
bb17:
  store i64 0, ptr %l74, !tbaa !24
  br label %bb18
bb18:
  %t105 = load i64, ptr %l74, !tbaa !24
  store i64 %t105, ptr %l71, !tbaa !24
  br label %bb19
bb19:
  %t106 = load i64, ptr %l71, !tbaa !24
  store i64 %t106, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb20
bb20:
  %t107 = load i64, ptr %l12, !tbaa !24
  %t108 = load i64, ptr %l11, !tbaa !24
  %t111 = icmp slt i64 %t107, %t108
  %t113 = xor i1 %t111, true
  br i1 %t113, label %bb21, label %bb22
bb21:
  br label %bb59
bb22:
  br label %bb23
bb23:
  %t115 = load i64, ptr %l8, !tbaa !24
  %t116 = load i64, ptr %l12, !tbaa !24
  %t117 = load i64, ptr %l10, !tbaa !24
  %t120 = mul i64 %t116, %t117
  %t123 = add i64 %t115, %t120
  %t125 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t125, ptr %l92, !tbaa !27
  %t128 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = getelementptr %"compiler/generic:AnySlot", ptr %t129, i64 %t123
  %t131 = load %"compiler/generic:AnySlot", ptr %t130
  store %"compiler/generic:AnySlot" %t131, ptr %l14
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/check:Checker", ptr %t133, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !29
  %t137 = load i32, ptr %l1, !tbaa !23
  %t138 = getelementptr %"compiler/generic:AnySlot", ptr %l14, i32 0, i32 0
  %t139 = load i32, ptr %t138, !tbaa !23
  %t143 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t136, i32 %t137, i32 %t139)
  store i64 %t143, ptr %l99
  br label %bb24
bb24:
  %t144 = load i64, ptr %l99, !tbaa !24
  store i64 %t144, ptr %l15, !tbaa !24
  %t145 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t145, ptr %l16, !tbaa !23
  %t147 = load i64, ptr %l15, !tbaa !24
  %t149 = icmp sge i64 %t147, 0
  br i1 %t149, label %bb25, label %bb26
bb25:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = getelementptr %"compiler/check:Checker", ptr %t151, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !29
  %t155 = load i64, ptr %l15, !tbaa !24
  %t156 = load i32, ptr %l1, !tbaa !23
  %t160 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodSig(ptr %v0, ptr %t154, i64 %t155, i32 %t156)
  store i32 %t160, ptr %l107
  br label %bb27
bb26:
  %t161 = getelementptr %"compiler/generic:AnySlot", ptr %l14, i32 0, i32 3
  %t162 = load i64, ptr %t161, !tbaa !24
  %t164 = icmp sge i64 %t162, 0
  br i1 %t164, label %bb34, label %bb35
bb27:
  %t166 = load i32, ptr %l107, !tbaa !23
  store i32 %t166, ptr %l16, !tbaa !23
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/check:Checker", ptr %t167, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !29
  store ptr %t170, ptr %l109, !tbaa !29
  %t171 = load i64, ptr %l15, !tbaa !24
  %t173 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t171)
  store i64 %t173, ptr %l111
  br label %bb28
bb28:
  %t174 = load ptr, ptr %l109, !tbaa !29
  %t175 = load i64, ptr %l111, !tbaa !24
  %t176 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t174, i64 %t175)
  store i64 %t176, ptr %l112
  br label %bb29
bb29:
  %t177 = load i64, ptr %l112, !tbaa !24
  %t178 = icmp sgt i64 %t177, 0
  br i1 %t178, label %bb30, label %bb31
bb30:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t181 = load i64, ptr %l15, !tbaa !24
  %t182 = load i32, ptr %l1, !tbaa !23
  %t186 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eimplSig(ptr %v0, ptr %t180, i64 %t181, i32 %t182)
  store i32 %t186, ptr %l117
  br label %bb32
bb31:
  br label %bb33
bb32:
  %t187 = load i32, ptr %l117, !tbaa !23
  store i32 %t187, ptr %l16, !tbaa !23
  br label %bb33
bb33:
  br label %bb38
bb34:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t190 = getelementptr %"compiler/check:Checker", ptr %t188, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !29
  %t192 = getelementptr %"compiler/generic:AnySlot", ptr %l14, i32 0, i32 3
  %t193 = load i64, ptr %t192, !tbaa !24
  %t194 = load i32, ptr %l1, !tbaa !23
  %t198 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDefaultAt(ptr %v0, ptr %t191, i64 %t193, i32 %t194)
  store i32 %t198, ptr %l124
  br label %bb36
bb35:
  br label %bb37
bb36:
  %t199 = load i32, ptr %l124, !tbaa !23
  store i32 %t199, ptr %l16, !tbaa !23
  br label %bb37
bb37:
  br label %bb38
bb38:
  %t200 = load i32, ptr %l16, !tbaa !23
  %t201 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t204 = icmp ne i32 %t200, %t201
  br i1 %t204, label %bb39, label %bb40
bb39:
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t207 = load i32, ptr %l16, !tbaa !23
  %t208 = getelementptr %"compiler/generic:AnySlot", ptr %l14, i32 0, i32 5
  %t209 = load i32, ptr %t208, !tbaa !23
  %t213 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyScopesAgree(ptr %v0, ptr %t206, i32 %t207, i32 %t209)
  store i1 %t213, ptr %l132
  br label %bb41
bb40:
  store i1 false, ptr %l128, !tbaa !21
  br label %bb42
bb41:
  %t214 = load i1, ptr %l132, !tbaa !21
  %t215 = xor i1 %t214, true
  store i1 %t215, ptr %l128, !tbaa !21
  br label %bb42
bb42:
  %t217 = load i1, ptr %l128, !tbaa !21
  br i1 %t217, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s8
  %t218 = load ptr, ptr %l0, !tbaa !29
  store ptr %t218, ptr %l134, !tbaa !29
  %t219 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t219, ptr %l135
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load i32, ptr %l1, !tbaa !23
  %t224 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s8, ptr %t220, i32 %t221)
  store { i64, ptr } %t224, ptr %l138
  br label %bb45
bb44:
  br label %bb57
bb45:
  %t225 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t226 = extractvalue { i64, ptr } %t225, 0
  %t227 = extractvalue { i64, ptr } %t225, 1
  %t228 = mul i64 %t226, 1
  %t229 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t228)
  call void @llvm.memcpy.p0.p0.i64(ptr %t229, ptr %t227, i64 %t228, i1 false)
  %t230 = insertvalue { i64, ptr } undef, i64 %t226, 0
  %t231 = insertvalue { i64, ptr } %t230, ptr %t229, 1
  store { i64, ptr } %t231, ptr %l139, !tbaa !27
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t233 = getelementptr %"compiler/generic:AnySlot", ptr %l14, i32 0, i32 0
  %t234 = load i32, ptr %t233, !tbaa !23
  %t237 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s8, ptr %t232, i32 %t234)
  store { i64, ptr } %t237, ptr %l142
  br label %bb46
bb46:
  %t238 = load { i64, ptr }, ptr %l142, !tbaa !27
  %t239 = extractvalue { i64, ptr } %t238, 0
  %t240 = extractvalue { i64, ptr } %t238, 1
  %t241 = mul i64 %t239, 1
  %t242 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t241)
  call void @llvm.memcpy.p0.p0.i64(ptr %t242, ptr %t240, i64 %t241, i1 false)
  %t243 = insertvalue { i64, ptr } undef, i64 %t239, 0
  %t244 = insertvalue { i64, ptr } %t243, ptr %t242, 1
  store { i64, ptr } %t244, ptr %l143, !tbaa !27
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t246 = load i32, ptr %l2, !tbaa !23
  %t249 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s8, ptr %t245, i32 %t246)
  store { i64, ptr } %t249, ptr %l146
  br label %bb47
bb47:
  %t250 = load { i64, ptr }, ptr %l146, !tbaa !27
  %t251 = extractvalue { i64, ptr } %t250, 0
  %t252 = extractvalue { i64, ptr } %t250, 1
  %t253 = mul i64 %t251, 1
  %t254 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t253)
  call void @llvm.memcpy.p0.p0.i64(ptr %t254, ptr %t252, i64 %t253, i1 false)
  %t255 = insertvalue { i64, ptr } undef, i64 %t251, 0
  %t256 = insertvalue { i64, ptr } %t255, ptr %t254, 1
  %t257 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t258 = load { i64, ptr }, ptr %l143, !tbaa !27
  %t260 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAnyMethodScopes(ptr %s8, ptr %s8, ptr %s8, ptr %v0, { i64, ptr } %t257, { i64, ptr } %t258, { i64, ptr } %t256)
  store %"compiler/diagmsg:Msg" %t260, ptr %l148
  br label %bb48
bb48:
  %t261 = load ptr, ptr %l134, !tbaa !29
  %t262 = load %"compiler/source:Span", ptr %l135
  %t263 = load %"compiler/diagmsg:Msg", ptr %l148
  %t264 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t261, %"compiler/source:Span" %t262, %"compiler/diagmsg:Msg" %t263)
  store i64 %t264, ptr %l149
  br label %bb49
bb49:
  %t265 = load i64, ptr %l149, !tbaa !24
  store i64 %t265, ptr %l17, !tbaa !24
  %t266 = load i64, ptr %l15, !tbaa !24
  %t268 = icmp sge i64 %t266, 0
  br i1 %t268, label %bb50, label %bb51
bb50:
  store %olang.scope zeroinitializer, ptr %s9
  %t270 = load ptr, ptr %l0, !tbaa !29
  store ptr %t270, ptr %l152, !tbaa !29
  %t271 = load i64, ptr %l17, !tbaa !24
  store i64 %t271, ptr %l153, !tbaa !24
  %t272 = load i64, ptr %l15, !tbaa !24
  store i64 %t272, ptr %l154, !tbaa !24
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t274 = getelementptr %"compiler/generic:AnySlot", ptr %l14, i32 0, i32 0
  %t275 = load i32, ptr %t274, !tbaa !23
  %t278 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s9, ptr %t273, i32 %t275)
  store { i64, ptr } %t278, ptr %l157
  br label %bb52
bb51:
  br label %bb55
bb52:
  %t279 = load { i64, ptr }, ptr %l157, !tbaa !27
  %t280 = extractvalue { i64, ptr } %t279, 0
  %t281 = extractvalue { i64, ptr } %t279, 1
  %t282 = mul i64 %t280, 1
  %t283 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t282)
  call void @llvm.memcpy.p0.p0.i64(ptr %t283, ptr %t281, i64 %t282, i1 false)
  %t284 = insertvalue { i64, ptr } undef, i64 %t280, 0
  %t285 = insertvalue { i64, ptr } %t284, ptr %t283, 1
  %t287 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteAnyMethod(ptr %s9, ptr %v0, { i64, ptr } %t285)
  store %"compiler/diagmsg:Msg" %t287, ptr %l159
  br label %bb53
bb53:
  %t288 = load ptr, ptr %l152, !tbaa !29
  %t289 = load i64, ptr %l153, !tbaa !24
  %t290 = load i64, ptr %l154, !tbaa !24
  %t291 = load %"compiler/diagmsg:Msg", ptr %l159
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoteAt(ptr %v0, ptr %v0, ptr %t288, i64 %t289, i64 %t290, %"compiler/diagmsg:Msg" %t291)
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s9)
  br label %bb55
bb55:
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t294 = getelementptr %"compiler/check:Checker", ptr %t292, i32 0, i32 163
  %t295 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t294, i64 %t295, i1 true)
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb57:
  br label %bb58
bb58:
  %t299 = load i64, ptr %l12, !tbaa !24
  %t301 = add i64 %t299, 1
  store i64 %t301, ptr %l12, !tbaa !24
  br label %bb20
bb59:
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t305 = getelementptr %"compiler/check:Checker", ptr %t303, i32 0, i32 1
  %t306 = load ptr, ptr %t305, !tbaa !29
  %t308 = getelementptr %"compiler/generic:Program", ptr %t306, i32 0, i32 68
  %t309 = load i64, ptr %l5, !tbaa !24
  %t312 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnyTable_3e_2eRef_H0986089bcad3c266fbd2f46fa03b07d1(ptr %v0, ptr %v0, ptr %t308, i64 %t309)
  store ptr %t312, ptr %l170
  br label %bb60
bb60:
  %t313 = load ptr, ptr %l170, !tbaa !29
  store ptr %t313, ptr %l18, !tbaa !29
  %t314 = load ptr, ptr %l0, !tbaa !29
  %t316 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t314)
  store ptr %t316, ptr %l172
  br label %bb61
bb61:
  %t317 = load ptr, ptr %l172, !tbaa !29
  %t319 = getelementptr %"compiler/check:frame", ptr %t317, i32 0, i32 1
  %t320 = load i64, ptr %t319, !tbaa !24
  store i64 %t320, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  %t322 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t324 = extractvalue { i64, ptr } %t322, 0
  store i64 %t324, ptr %l21, !tbaa !24
  store i64 1, ptr %l22, !tbaa !24
  %t326 = load i64, ptr %l21, !tbaa !24
  %t327 = load i64, ptr %l20, !tbaa !24
  %t330 = icmp sgt i64 %t326, %t327
  br i1 %t330, label %bb62, label %bb63
bb62:
  %t332 = load i64, ptr %l22, !tbaa !24
  %t334 = icmp sgt i64 %t332, 0
  br i1 %t334, label %bb64, label %bb65
bb63:
  store i64 0, ptr %l180, !tbaa !24
  br label %bb67
bb64:
  %t336 = load i64, ptr %l21, !tbaa !24
  %t337 = load i64, ptr %l20, !tbaa !24
  %t340 = sub i64 %t336, %t337
  %t341 = load i64, ptr %l22, !tbaa !24
  %t344 = add i64 %t340, %t341
  %t346 = sub i64 %t344, 1
  %t347 = load i64, ptr %l22, !tbaa !24
  %t350 = sdiv i64 %t346, %t347
  store i64 %t350, ptr %l183, !tbaa !24
  br label %bb66
bb65:
  store i64 0, ptr %l183, !tbaa !24
  br label %bb66
bb66:
  %t352 = load i64, ptr %l183, !tbaa !24
  store i64 %t352, ptr %l180, !tbaa !24
  br label %bb67
bb67:
  %t353 = load i64, ptr %l180, !tbaa !24
  store i64 %t353, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb68
bb68:
  %t354 = load i64, ptr %l24, !tbaa !24
  %t355 = load i64, ptr %l23, !tbaa !24
  %t358 = icmp slt i64 %t354, %t355
  %t360 = xor i1 %t358, true
  br i1 %t360, label %bb69, label %bb70
bb69:
  br label %bb80
bb70:
  br label %bb71
bb71:
  %t362 = load i64, ptr %l20, !tbaa !24
  %t363 = load i64, ptr %l24, !tbaa !24
  %t364 = load i64, ptr %l22, !tbaa !24
  %t367 = mul i64 %t363, %t364
  %t370 = add i64 %t362, %t367
  store i64 %t370, ptr %l25, !tbaa !24
  %t372 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t372, ptr %l201, !tbaa !27
  %t373 = load i64, ptr %l25, !tbaa !24
  %t375 = getelementptr { i64, ptr }, ptr %l201, i32 0, i32 1
  %t376 = load ptr, ptr %t375, !tbaa !27
  %t377 = getelementptr %"compiler/generic:AnySlot", ptr %t376, i64 %t373
  %t378 = load %"compiler/generic:AnySlot", ptr %t377
  store %"compiler/generic:AnySlot" %t378, ptr %l26
  %t380 = load ptr, ptr %l0, !tbaa !29
  %t382 = getelementptr %"compiler/check:Checker", ptr %t380, i32 0, i32 1
  %t383 = load ptr, ptr %t382, !tbaa !29
  %t385 = getelementptr %"compiler/generic:Program", ptr %t383, i32 0, i32 2
  store ptr %t385, ptr %l206, !tbaa !29
  %t386 = load ptr, ptr %l0, !tbaa !29
  %t388 = getelementptr %"compiler/check:Checker", ptr %t386, i32 0, i32 1
  %t389 = load ptr, ptr %t388, !tbaa !29
  %t391 = getelementptr %"compiler/generic:Program", ptr %t389, i32 0, i32 2
  %t392 = getelementptr %"compiler/generic:AnySlot", ptr %l26, i32 0, i32 5
  %t393 = load i32, ptr %t392, !tbaa !23
  %t396 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t391, i32 %t393)
  store i32 %t396, ptr %l211
  br label %bb72
bb72:
  %t397 = load ptr, ptr %l206, !tbaa !29
  %t398 = load i32, ptr %l211, !tbaa !23
  %t399 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t397, i32 %t398)
  store { i64, ptr } %t399, ptr %l212
  br label %bb73
bb73:
  %t400 = load { i64, ptr }, ptr %l212, !tbaa !27
  %t401 = load ptr, ptr %l0, !tbaa !29
  %t403 = getelementptr %"compiler/check:Checker", ptr %t401, i32 0, i32 1
  %t404 = load ptr, ptr %t403, !tbaa !29
  %t406 = getelementptr %"compiler/generic:Program", ptr %t404, i32 0, i32 2
  store { i64, ptr } %t400, ptr %l216, !tbaa !27
  %t408 = getelementptr { i64, ptr }, ptr %l216, i32 0, i32 1
  %t409 = load ptr, ptr %t408, !tbaa !27
  %t410 = getelementptr i32, ptr %t409, i64 0
  %t411 = load i32, ptr %t410, !tbaa !33
  %t414 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t406, i32 %t411)
  store i64 %t414, ptr %l218
  br label %bb74
bb74:
  %t415 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t416 = load i64, ptr %l218, !tbaa !24
  %t418 = and i64 %t416, %t415
  %t420 = load ptr, ptr %l0, !tbaa !29
  store ptr %t420, ptr %l221, !tbaa !29
  %t421 = getelementptr %"compiler/generic:AnySlot", ptr %l26, i32 0, i32 5
  %t422 = load i32, ptr %t421, !tbaa !23
  store i32 %t422, ptr %l222, !tbaa !23
  %t423 = load ptr, ptr %l0, !tbaa !29
  %t425 = getelementptr %"compiler/check:Checker", ptr %t423, i32 0, i32 1
  %t426 = load ptr, ptr %t425, !tbaa !29
  %t428 = getelementptr %"compiler/generic:Program", ptr %t426, i32 0, i32 2
  %t429 = load i32, ptr %l7, !tbaa !23
  %t434 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t428, i32 %t429, i64 %t418)
  store i32 %t434, ptr %l228
  br label %bb75
bb75:
  %t435 = load ptr, ptr %l221, !tbaa !29
  %t436 = load i32, ptr %l222, !tbaa !23
  %t437 = load i32, ptr %l228, !tbaa !23
  %t438 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erecvReplaced(ptr %v0, ptr %t435, i32 %t436, i32 %t437)
  store i32 %t438, ptr %l229
  br label %bb76
bb76:
  %t439 = load i32, ptr %l229, !tbaa !23
  %t440 = load ptr, ptr %l18, !tbaa !29
  %t442 = getelementptr %"compiler/generic:AnyTable", ptr %t440, i32 0, i32 5
  store ptr %t442, ptr %l231, !tbaa !29
  %t443 = load ptr, ptr %l0, !tbaa !29
  %t444 = load i64, ptr %l5, !tbaa !24
  %t445 = load i64, ptr %l25, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t446
  %t447 = getelementptr { i64, [2 x i64] }, ptr %t446, i32 0, i32 0
  store i64 9, ptr %t447
  %t449 = insertvalue { i64, i64 } undef, i64 %t444, 0
  %t451 = insertvalue { i64, i64 } %t449, i64 %t445, 1
  %t452 = getelementptr { i64, [2 x i64] }, ptr %t446, i32 0, i32 1
  store { i64, i64 } %t451, ptr %t452
  %t453 = load { i64, [2 x i64] }, ptr %t446
  %t455 = load i64, ptr %l19, !tbaa !24
  %t456 = load %"compiler/source:Span", ptr %l3
  %t462 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %t443, { i64, [2 x i64] } %t453, i32 %t439, i64 %t455, %"compiler/source:Span" %t456)
  store i64 %t462, ptr %l239
  br label %bb77
bb77:
  %t463 = load ptr, ptr %l231, !tbaa !29
  %t464 = load i64, ptr %l239, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t463, i64 %t464)
  br label %bb78
bb78:
  br label %bb79
bb79:
  %t465 = load i64, ptr %l24, !tbaa !24
  %t467 = add i64 %t465, 1
  store i64 %t467, ptr %l24, !tbaa !24
  br label %bb68
bb80:
  %t469 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_2ector(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t469, ptr %l242
  br label %bb81
bb81:
  %t470 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l242
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t470, ptr %l30
  %t471 = load ptr, ptr %l0, !tbaa !29
  %t472 = load i32, ptr %l1, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewantStr(ptr %v0, ptr %s0, ptr %t471, i32 %t472, ptr %l30, i64 0)
  br label %bb82
bb82:
  %t476 = load i64, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t476, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eassignAt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca i64
  %l11 = alloca %"compiler/source:Span"
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i1
  %l29 = alloca i32
  %l34 = alloca ptr
  %l38 = alloca ptr
  %l40 = alloca i32
  %l41 = alloca i32
  %l45 = alloca i1
  %l48 = alloca i32
  %l61 = alloca i64
  %l64 = alloca ptr
  %l66 = alloca %"compiler/source:Span"
  %l67 = alloca %"compiler/source:Span"
  %l71 = alloca i1
  %l73 = alloca ptr
  %l74 = alloca %"compiler/source:Span"
  %l75 = alloca ptr
  %l77 = alloca i32
  %l78 = alloca { i64, ptr }
  %l80 = alloca %"compiler/diagmsg:Msg"
  %l81 = alloca i64
  %l85 = alloca i64
  %l87 = alloca ptr
  %l88 = alloca %"compiler/source:Span"
  %l89 = alloca i32
  %l90 = alloca ptr
  %l92 = alloca ptr
  %l93 = alloca ptr
  %l95 = alloca %"compiler/source:Span"
  %l96 = alloca %"compiler/source:Span"
  %l99 = alloca i1
  %l100 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l109 = alloca { i64, ptr }
  %l118 = alloca ptr
  %l119 = alloca %"compiler/source:Span"
  %l120 = alloca ptr
  %l121 = alloca %"compiler/source:Span"
  %l122 = alloca %"compiler/source:Span"
  %l123 = alloca i64
  %l127 = alloca ptr
  %l128 = alloca ptr
  %l130 = alloca { i64, ptr }
  %l133 = alloca { i64, ptr }
  %l137 = alloca ptr
  %s1 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca i1
  %t250 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l3, !tbaa !29
  store ptr %t1, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t2 = load ptr, ptr %l17, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l17, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 28}
  %t8 = icmp eq i64 %t6, 13
  store i1 %t8, ptr %l18, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l18, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l5
  %t16 = load ptr, ptr %l3, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t18, i32 0, i32 1
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l6, !tbaa !29
  %t22 = load ptr, ptr %l3, !tbaa !29
  %t24 = getelementptr { i64, [4 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t24, i32 0, i32 2
  %t26 = load { i64, ptr }, ptr %t25
  store { i64, ptr } %t26, ptr %l7, !tbaa !27
  br label %bb5
bb4:
  br label %bb68
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load ptr, ptr %l6, !tbaa !29
  %t32 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %t28, ptr %t29)
  store i32 %t32, ptr %l29
  br label %bb6
bb6:
  %t33 = load i32, ptr %l29, !tbaa !23
  %t34 = icmp sge i32 %t33, 0
  br i1 %t34, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l6, !tbaa !29
  %t41 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplace(ptr %v0, ptr %v1, ptr %v0, ptr %t37, ptr %t38)
  store ptr %t41, ptr %l34
  br label %bb10
bb10:
  %t42 = load ptr, ptr %l34, !tbaa !29
  store ptr %t42, ptr %l8, !tbaa !29
  %t43 = load ptr, ptr %l8, !tbaa !29
  %t45 = icmp eq ptr %t43, null
  br i1 %t45, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l38, !tbaa !29
  %t49 = load ptr, ptr %l8, !tbaa !29
  %t51 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %t49)
  store i32 %t51, ptr %l40
  br label %bb14
bb14:
  %t52 = load ptr, ptr %l38, !tbaa !29
  %t53 = load i32, ptr %l40, !tbaa !23
  %t54 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t52, i32 %t53)
  store i32 %t54, ptr %l41
  br label %bb15
bb15:
  %t55 = load i32, ptr %l41, !tbaa !23
  store i32 %t55, ptr %l9, !tbaa !23
  %t56 = load i32, ptr %l9, !tbaa !23
  %t57 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t60 = icmp eq i32 %t56, %t57
  br i1 %t60, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l45, !tbaa !21
  br label %bb19
bb17:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load i32, ptr %l9, !tbaa !23
  %t66 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t62, i32 %t63)
  store i32 %t66, ptr %l48
  br label %bb18
bb18:
  %t67 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t68 = load i32, ptr %l48, !tbaa !23
  %t70 = icmp ne i32 %t68, %t67
  store i1 %t70, ptr %l45, !tbaa !21
  br label %bb19
bb19:
  %t72 = load i1, ptr %l45, !tbaa !21
  br i1 %t72, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t74 = load i32, ptr %l2, !range !{i32 0, i32 113}
  %t76 = trunc i64 77 to i32
  %t77 = icmp eq i32 %t74, %t76
  %t79 = xor i1 %t77, true
  br i1 %t79, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load i32, ptr %l9, !tbaa !23
  %t84 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t84, 0
  %t88 = add i64 %t86, 1
  %t92 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s1, ptr %t82, i32 %t83, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d0, i32 0, i32 1) }, i64 %t88)
  store i64 %t92, ptr %l61
  br label %bb26
bb26:
  %t93 = load i64, ptr %l61, !tbaa !24
  store i64 %t93, ptr %l10, !tbaa !24
  %t94 = load i64, ptr %l10, !tbaa !24
  %t96 = icmp slt i64 %t94, 0
  br i1 %t96, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s6
  %t98 = load ptr, ptr %l0, !tbaa !29
  store ptr %t98, ptr %l64, !tbaa !29
  %t99 = load ptr, ptr %l3, !tbaa !29
  %t101 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t99)
  store %"compiler/source:Span" %t101, ptr %l66
  br label %bb29
bb28:
  br label %bb39
bb29:
  %t102 = load ptr, ptr %l64, !tbaa !29
  %t103 = load %"compiler/source:Span", ptr %l66
  %t104 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopAfter(ptr %v0, ptr %t102, %"compiler/source:Span" %t103, i64 1)
  store %"compiler/source:Span" %t104, ptr %l67
  br label %bb30
bb30:
  %t105 = load %"compiler/source:Span", ptr %l67
  store %"compiler/source:Span" %t105, ptr %l11
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load i32, ptr %l9, !tbaa !23
  %t108 = load %"compiler/source:Span", ptr %l11
  %t112 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %s6, ptr %s6, ptr %t106, i32 %t107, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d1, i32 0, i32 1) }, %"compiler/source:Span" %t108, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d2, i32 0, i32 1) }, i64 2, i1 true)
  store i1 %t112, ptr %l71
  br label %bb31
bb31:
  %t113 = load i1, ptr %l71, !tbaa !21
  %t114 = xor i1 %t113, true
  br i1 %t114, label %bb32, label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s7
  %t116 = load ptr, ptr %l0, !tbaa !29
  store ptr %t116, ptr %l73, !tbaa !29
  %t117 = load %"compiler/source:Span", ptr %l11
  store %"compiler/source:Span" %t117, ptr %l74
  %t118 = load ptr, ptr %l0, !tbaa !29
  store ptr %t118, ptr %l75, !tbaa !29
  %t119 = load ptr, ptr %l8, !tbaa !29
  %t121 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %t119)
  store i32 %t121, ptr %l77
  br label %bb34
bb33:
  br label %bb38
bb34:
  %t122 = load ptr, ptr %l75, !tbaa !29
  %t123 = load i32, ptr %l77, !tbaa !23
  %t124 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s7, ptr %t122, i32 %t123)
  store { i64, ptr } %t124, ptr %l78
  br label %bb35
bb35:
  %t125 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t125, 0
  %t127 = extractvalue { i64, ptr } %t125, 1
  %t128 = mul i64 %t126, 1
  %t129 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t128)
  call void @llvm.memcpy.p0.p0.i64(ptr %t129, ptr %t127, i64 %t128, i1 false)
  %t130 = insertvalue { i64, ptr } undef, i64 %t126, 0
  %t131 = insertvalue { i64, ptr } %t130, ptr %t129, 1
  %t133 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eSetatUndeclared(ptr %s7, ptr %v0, { i64, ptr } %t131)
  store %"compiler/diagmsg:Msg" %t133, ptr %l80
  br label %bb36
bb36:
  %t134 = load ptr, ptr %l73, !tbaa !29
  %t135 = load %"compiler/source:Span", ptr %l74
  %t136 = load %"compiler/diagmsg:Msg", ptr %l80
  %t137 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t134, %"compiler/source:Span" %t135, %"compiler/diagmsg:Msg" %t136)
  store i64 %t137, ptr %l81
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s7)
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s1)
  store i1 true, ptr %rv
  br label %ret
bb39:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load ptr, ptr %l8, !tbaa !29
  %t143 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalueTemp(ptr %v0, ptr %v0, ptr %t139, ptr %t140)
  store i64 %t143, ptr %l85
  br label %bb40
bb40:
  %t144 = load i64, ptr %l85, !tbaa !24
  %t145 = icmp sge i64 %t144, 0
  br i1 %t145, label %bb41, label %bb42
bb41:
  %t147 = load ptr, ptr %l0, !tbaa !29
  store ptr %t147, ptr %l87, !tbaa !29
  %t148 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t148, ptr %l88
  %t149 = load i32, ptr %l2, !range !{i32 0, i32 113}
  store i32 %t149, ptr %l89
  %t150 = load ptr, ptr %l8, !tbaa !29
  store ptr %t150, ptr %l90, !tbaa !29
  %t151 = load ptr, ptr %l4, !tbaa !29
  store ptr %t151, ptr %l92, !tbaa !29
  %t153 = load ptr, ptr %l0, !tbaa !29
  store ptr %t153, ptr %l93, !tbaa !29
  %t154 = load ptr, ptr %l3, !tbaa !29
  %t156 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t154)
  store %"compiler/source:Span" %t156, ptr %l95
  br label %bb43
bb42:
  br label %bb46
bb43:
  %t157 = load ptr, ptr %l93, !tbaa !29
  %t158 = load %"compiler/source:Span", ptr %l95
  %t159 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopAfter(ptr %v0, ptr %t157, %"compiler/source:Span" %t158, i64 1)
  store %"compiler/source:Span" %t159, ptr %l96
  br label %bb44
bb44:
  %t160 = load i64, ptr %l10, !tbaa !24
  %t161 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t162 = load ptr, ptr %l87, !tbaa !29
  %t163 = load %"compiler/source:Span", ptr %l88
  %t164 = load i32, ptr %l89, !range !{i32 0, i32 113}
  %t165 = load ptr, ptr %l90, !tbaa !29
  %t166 = load ptr, ptr %l92, !tbaa !29
  %t167 = load %"compiler/source:Span", ptr %l96
  %t170 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewriteBack(ptr %v0, ptr %v0, ptr %v2, ptr %v1, ptr %t162, %"compiler/source:Span" %t163, i32 %t164, ptr %t165, ptr %t166, %"compiler/source:Span" %t167, i64 %t160, { i64, ptr } %t161)
  store i1 %t170, ptr %l99
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s1)
  %t171 = load i1, ptr %l99, !tbaa !21
  store i1 %t171, ptr %rv
  br label %ret
bb46:
  %t172 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t172, ptr %l100
  br label %bb47
bb47:
  %t173 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l100
  %t174 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t173, ptr %t174
  store ptr %t174, ptr %l12, !tbaa !29
  %t176 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t176, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t178 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t180 = extractvalue { i64, ptr } %t178, 0
  store i64 %t180, ptr %l15, !tbaa !24
  br label %bb48
bb48:
  %t182 = load i64, ptr %l14, !tbaa !24
  %t183 = load i64, ptr %l15, !tbaa !24
  %t186 = icmp slt i64 %t182, %t183
  %t188 = xor i1 %t186, true
  br i1 %t188, label %bb49, label %bb50
bb49:
  br label %bb54
bb50:
  br label %bb51
bb51:
  %t190 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t190, ptr %l109, !tbaa !27
  %t191 = load i64, ptr %l14, !tbaa !24
  %t193 = getelementptr { i64, ptr }, ptr %l109, i32 0, i32 1
  %t194 = load ptr, ptr %t193, !tbaa !27
  %t195 = getelementptr ptr, ptr %t194, i64 %t191
  %t196 = load ptr, ptr %t195, !tbaa !39
  %t198 = load ptr, ptr %l12, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %t198, ptr %t196)
  br label %bb52
bb52:
  br label %bb53
bb53:
  %t202 = load i64, ptr %l14, !tbaa !24
  %t204 = add i64 %t202, 1
  store i64 %t204, ptr %l14, !tbaa !24
  br label %bb48
bb54:
  %t206 = load ptr, ptr %l12, !tbaa !29
  %t207 = load ptr, ptr %l4, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v2, ptr %t206, ptr %t207)
  br label %bb55
bb55:
  %t210 = load ptr, ptr %l0, !tbaa !29
  store ptr %t210, ptr %l118, !tbaa !29
  %t211 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t211, ptr %l119
  %t212 = load ptr, ptr %l0, !tbaa !29
  store ptr %t212, ptr %l120, !tbaa !29
  %t213 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t213, ptr %l121
  %t214 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t214, ptr %l122
  %t215 = load i64, ptr %l10, !tbaa !24
  store i64 %t215, ptr %l123, !tbaa !24
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t217 = load %"compiler/source:Span", ptr %l5
  %t218 = load ptr, ptr %l8, !tbaa !29
  %t222 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v0, ptr %v0, ptr %t216, %"compiler/source:Span" %t217, ptr %t218)
  store ptr %t222, ptr %l127
  br label %bb56
bb56:
  %t223 = load ptr, ptr %l127, !tbaa !29
  store ptr %t223, ptr %l128, !tbaa !29
  %t224 = load ptr, ptr %l12, !tbaa !29
  %t226 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eToArray_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t224)
  store { i64, ptr } %t226, ptr %l130
  br label %bb57
bb57:
  %t227 = icmp sge i64 0, 0
  br i1 %t227, label %bb58, label %bb59
bb58:
  %t229 = icmp sle i64 0, 1152921504606846975
  br i1 %t229, label %bb60, label %bb61
bb59:
  call void @__olang_check_failed(ptr @olang_loc_481df18796619d00_e450b1e3b67cd36c)
  unreachable
bb60:
  %t231 = mul i64 0, 8
  %t232 = insertvalue { i64, ptr } undef, i64 0, 0
  %t233 = insertvalue { i64, ptr } %t232, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t233, ptr %l133, !tbaa !27
  %t234 = icmp sge i64 0, 0
  br i1 %t234, label %bb62, label %bb63
bb61:
  call void @__olang_check_failed(ptr @olang_loc_481df18796619d00_e450b1e3b67cd36c)
  unreachable
bb62:
  %t236 = icmp sle i64 0, 2305843009213693951
  br i1 %t236, label %bb64, label %bb65
bb63:
  call void @__olang_check_failed(ptr @olang_loc_af0d91289a1be42d_4e0f74b352066f9)
  unreachable
bb64:
  %t238 = mul i64 0, 4
  %t239 = insertvalue { i64, ptr } undef, i64 0, 0
  %t240 = insertvalue { i64, ptr } %t239, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t241 = load ptr, ptr %l120, !tbaa !29
  %t242 = load %"compiler/source:Span", ptr %l121
  %t243 = load %"compiler/source:Span", ptr %l122
  %t244 = load i64, ptr %l123, !tbaa !24
  %t245 = load ptr, ptr %l128, !tbaa !29
  %t246 = load { i64, ptr }, ptr %l130, !tbaa !27
  %t247 = load { i64, ptr }, ptr %l133, !tbaa !27
  %t249 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t241, %"compiler/source:Span" %t242, %"compiler/source:Span" %t243, i64 %t244, ptr %t245, { i64, ptr } %t246, { i64, ptr } %t247, { i64, ptr } %t240)
  store ptr %t249, ptr %l137
  br label %bb66
bb65:
  call void @__olang_check_failed(ptr @olang_loc_af0d91289a1be42d_4e0f74b352066f9)
  unreachable
bb66:
  store { i64, [3 x i64] } zeroinitializer, ptr %t250
  %t251 = getelementptr { i64, [3 x i64] }, ptr %t250, i32 0, i32 0
  store i64 2, ptr %t251
  %t252 = load %"compiler/source:Span", ptr %l119
  %t253 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t252, 0
  %t254 = load ptr, ptr %l137, !tbaa !29
  %t255 = insertvalue { %"compiler/source:Span", ptr } %t253, ptr %t254, 1
  %t256 = getelementptr { i64, [3 x i64] }, ptr %t250, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t255, ptr %t256
  %t257 = load { i64, [3 x i64] }, ptr %t250
  %t259 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t257, ptr %t259
  %t260 = load ptr, ptr %l118, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t260, ptr %t259)
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s1)
  store i1 true, ptr %rv
  br label %ret
bb68:
  br i1 true, label %bb69, label %bb70
bb69:
  br label %bb71
bb70:
  br label %bb72
bb71:
  store i1 false, ptr %rv
  br label %ret
bb72:
  call void @__olang_check_failed(ptr @olang_loc_490471cc9535e935_aa1636ccadcd0f9)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aBlock(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l17 = alloca { i64, ptr }
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Block", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l5, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l4, !tbaa !24
  %t15 = load i64, ptr %l5, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb10
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t22, ptr %l17, !tbaa !27
  %t23 = load i64, ptr %l4, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aStmt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %t28)
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t37 = load i64, ptr %l4, !tbaa !24
  %t39 = add i64 %t37, 1
  store i64 %t39, ptr %l4, !tbaa !24
  br label %bb4
bb10:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebranchBlock(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l18 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Branch", ptr %t1, i32 0, i32 2
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp sge i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/check:Checker", ptr %t8, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/generic:Program", ptr %t11, i32 0, i32 0
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/load:Loader", ptr %t14, i32 0, i32 4
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr %"compiler/ast:Branch", ptr %t18, i32 0, i32 2
  %t21 = load i64, ptr %t20, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eReopen(ptr %v0, ptr %t17, i64 %t21)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr %"compiler/ast:Branch", ptr %t25, i32 0, i32 1
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr %"compiler/ast:Branch", ptr %t29, i32 0, i32 0
  %t32 = load %"compiler/source:Span", ptr %t31
  %t37 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eblockOf(ptr %v0, ptr %v1, ptr %v2, ptr %t24, { i64, ptr } %t28, i32 1, %"compiler/source:Span" %t32)
  store ptr %t37, ptr %l18
  br label %bb5
bb5:
  %t38 = load ptr, ptr %l18, !tbaa !29
  store ptr %t38, ptr %l2, !tbaa !29
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr %"compiler/ast:Branch", ptr %t39, i32 0, i32 2
  %t42 = load i64, ptr %t41, !tbaa !24
  %t44 = icmp sge i64 %t42, 0
  br i1 %t44, label %bb6, label %bb7
bb6:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/check:Checker", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = getelementptr %"compiler/generic:Program", ptr %t49, i32 0, i32 0
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = getelementptr %"compiler/load:Loader", ptr %t52, i32 0, i32 4
  %t55 = load ptr, ptr %t54, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %t55)
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t57 = load ptr, ptr %l2, !tbaa !29
  store ptr %t57, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuildConst(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca %"compiler/cond:Value"
  %l4 = alloca i1
  %l5 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l9 = alloca ptr
  %l12 = alloca %"compiler/cond:Value"
  %l16 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l20 = alloca %"compiler/cond:Value"
  %l21 = alloca i32
  %l26 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca %"compiler/source:Span"
  %l32 = alloca i32
  %l35 = alloca i64
  %l36 = alloca ptr
  %l39 = alloca ptr
  %l40 = alloca %"compiler/source:Span"
  %l42 = alloca i32
  %l46 = alloca i32
  %l48 = alloca i32
  %l50 = alloca ptr
  %l53 = alloca ptr
  %l54 = alloca %"compiler/source:Span"
  %l58 = alloca i32
  %l62 = alloca ptr
  %l71 = alloca { i64, ptr }
  %l72 = alloca %"compiler/source:Span"
  %l75 = alloca ptr
  %l77 = alloca i32
  %l79 = alloca i32
  %l81 = alloca ptr
  %l94 = alloca ptr
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca ptr
  %t176 = alloca { i64, [2 x i64] }, align 8
  %t184 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 161
  store ptr %t3, ptr %l7, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t4)
  store ptr %t6, ptr %l9
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l9, !tbaa !29
  %t9 = getelementptr %"compiler/check:frame", ptr %t7, i32 0, i32 0
  %t10 = load i64, ptr %t9, !tbaa !24
  %t11 = load ptr, ptr %l7, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t11, i64 %t10, i1 true)
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 0
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/load:Loader", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  store ptr %t22, ptr %l16, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t27 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t23, i32 %a2)
  store { i64, ptr } %t27, ptr %l19
  br label %bb3
bb3:
  %t28 = load ptr, ptr %l16, !tbaa !29
  %t29 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t30 = call { i32, %"compiler/cond:Value" } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eValueOf(ptr %v0, ptr %v0, ptr %t28, { i64, ptr } %t29)
  %t31 = extractvalue { i32, %"compiler/cond:Value" } %t30, 1
  %t32 = extractvalue { i32, %"compiler/cond:Value" } %t30, 0
  store i32 %t32, ptr %l21
  %t33 = icmp ne i32 %t32, 0
  br i1 %t33, label %bb5, label %ok.34, !prof !99
ok.34:
  store %"compiler/cond:Value" %t31, ptr %l20
  br label %bb4
bb4:
  %t35 = load %"compiler/cond:Value", ptr %l20
  store %"compiler/cond:Value" %t35, ptr %l12
  br label %bb9
bb5:
  br label %bb6
bb6:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %v0, ptr %t36, %"compiler/source:Span" %t37, { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d3, i32 0, i32 1) })
  br label %bb7
bb7:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load %"compiler/source:Span", ptr %l1
  %t44 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %t40, %"compiler/source:Span" %t41)
  store ptr %t44, ptr %l26
  br label %bb8
bb8:
  %t45 = load ptr, ptr %l26, !tbaa !29
  store ptr %t45, ptr %rv
  br label %ret
bb9:
  %t46 = load %"compiler/cond:Value", ptr %l12
  store %"compiler/cond:Value" %t46, ptr %l3
  %t47 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 6
  %t48 = load i1, ptr %t47, !tbaa !21
  store i1 %t48, ptr %l4, !tbaa !21
  %t50 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 0
  %t51 = load i32, ptr %t50, !range !{i32 0, i32 5}
  %t53 = trunc i64 1 to i32
  %t54 = icmp eq i32 %t51, %t53
  br i1 %t54, label %bb10, label %bb11
bb10:
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l30, !tbaa !29
  %t57 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t57, ptr %l31
  %t58 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t58, ptr %l32, !tbaa !23
  %t59 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 1
  %t60 = load i64, ptr %t59, !tbaa !24
  %t62 = icmp ne i64 %t60, 0
  br i1 %t62, label %bb12, label %bb13
bb11:
  br label %bb16
bb12:
  store i64 1, ptr %l35, !tbaa !24
  br label %bb14
bb13:
  store i64 0, ptr %l35, !tbaa !24
  br label %bb14
bb14:
  %t64 = load ptr, ptr %l30, !tbaa !29
  %t65 = load %"compiler/source:Span", ptr %l31
  %t66 = load i32, ptr %l32, !tbaa !23
  %t67 = load i64, ptr %l35, !tbaa !24
  %t68 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v1, ptr %t64, %"compiler/source:Span" %t65, i32 %t66, i64 %t67)
  store ptr %t68, ptr %l36
  br label %bb15
bb15:
  %t69 = load ptr, ptr %l36, !tbaa !29
  store ptr %t69, ptr %rv
  br label %ret
bb16:
  %t70 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 0
  %t71 = load i32, ptr %t70, !range !{i32 0, i32 5}
  %t73 = trunc i64 2 to i32
  %t74 = icmp eq i32 %t71, %t73
  br i1 %t74, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s3
  %t76 = load ptr, ptr %l0, !tbaa !29
  store ptr %t76, ptr %l39, !tbaa !29
  %t77 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t77, ptr %l40
  %t78 = load i1, ptr %l4, !tbaa !21
  br i1 %t78, label %bb19, label %bb20
bb18:
  br label %bb25
bb19:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/check:Checker", ptr %t80, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t85 = getelementptr %"compiler/generic:Program", ptr %t83, i32 0, i32 2
  %t87 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s3, ptr %t85, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d4, i32 0, i32 1) })
  store i32 %t87, ptr %l46
  br label %bb21
bb20:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t88)
  store i32 %t90, ptr %l48
  br label %bb22
bb21:
  %t91 = load i32, ptr %l46, !tbaa !23
  store i32 %t91, ptr %l42, !tbaa !23
  br label %bb23
bb22:
  %t92 = load i32, ptr %l48, !tbaa !23
  store i32 %t92, ptr %l42, !tbaa !23
  br label %bb23
bb23:
  %t93 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 1
  %t94 = load i64, ptr %t93, !tbaa !24
  %t95 = load ptr, ptr %l39, !tbaa !29
  %t96 = load %"compiler/source:Span", ptr %l40
  %t97 = load i32, ptr %l42, !tbaa !23
  %t99 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v1, ptr %t95, %"compiler/source:Span" %t96, i32 %t97, i64 %t94)
  store ptr %t99, ptr %l50
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s3)
  %t100 = load ptr, ptr %l50, !tbaa !29
  store ptr %t100, ptr %rv
  br label %ret
bb25:
  %t101 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 0
  %t102 = load i32, ptr %t101, !range !{i32 0, i32 5}
  %t104 = trunc i64 3 to i32
  %t105 = icmp eq i32 %t102, %t104
  br i1 %t105, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s4
  %t107 = load ptr, ptr %l0, !tbaa !29
  store ptr %t107, ptr %l53, !tbaa !29
  %t108 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t108, ptr %l54
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/check:Checker", ptr %t109, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t114 = getelementptr %"compiler/generic:Program", ptr %t112, i32 0, i32 2
  %t116 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s4, ptr %t114, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d5, i32 0, i32 1) })
  store i32 %t116, ptr %l58
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t117 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 2
  %t118 = load double, ptr %t117, !tbaa !26
  %t120 = bitcast double %t118 to i64
  %t122 = load ptr, ptr %l53, !tbaa !29
  %t123 = load %"compiler/source:Span", ptr %l54
  %t124 = load i32, ptr %l58, !tbaa !23
  %t126 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v1, ptr %t122, %"compiler/source:Span" %t123, i32 %t124, i64 %t120)
  store ptr %t126, ptr %l62
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s4)
  %t127 = load ptr, ptr %l62, !tbaa !29
  store ptr %t127, ptr %rv
  br label %ret
bb30:
  %t128 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 0
  %t129 = load i32, ptr %t128, !range !{i32 0, i32 5}
  %t131 = trunc i64 4 to i32
  %t132 = icmp eq i32 %t129, %t131
  br i1 %t132, label %bb31, label %bb32
bb31:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/check:Checker", ptr %t134, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !29
  %t139 = getelementptr %"compiler/generic:Program", ptr %t137, i32 0, i32 0
  %t140 = load ptr, ptr %t139, !tbaa !29
  %t142 = getelementptr %"compiler/load:Loader", ptr %t140, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !29
  %t145 = getelementptr %"compiler/cond:Consts", ptr %t143, i32 0, i32 6
  %t146 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 3
  %t147 = load i64, ptr %t146, !tbaa !24
  %t150 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %t145, i64 %t147)
  store { i64, ptr } %t150, ptr %l71
  br label %bb33
bb32:
  br label %bb37
bb33:
  %t151 = load { i64, ptr }, ptr %l71, !tbaa !27
  store { i64, ptr } %t151, ptr %l5, !tbaa !27
  %t152 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t152, ptr %l72
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t155 = getelementptr %"compiler/check:Checker", ptr %t153, i32 0, i32 1
  %t156 = load ptr, ptr %t155, !tbaa !29
  %t158 = getelementptr %"compiler/generic:Program", ptr %t156, i32 0, i32 2
  store ptr %t158, ptr %l75, !tbaa !29
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t159)
  store i32 %t161, ptr %l77
  br label %bb34
bb34:
  %t162 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t163 = load ptr, ptr %l75, !tbaa !29
  %t164 = load i32, ptr %l77, !tbaa !23
  %t166 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t163, i32 %t164, i64 %t162)
  store i32 %t166, ptr %l79
  br label %bb35
bb35:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t167)
  store ptr %t169, ptr %l81
  br label %bb36
bb36:
  %t170 = load ptr, ptr %l81, !tbaa !29
  %t172 = getelementptr %"compiler/check:frame", ptr %t170, i32 0, i32 2
  %t173 = load i64, ptr %t172, !tbaa !24
  %t174 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, [2 x i64] } zeroinitializer, ptr %t176
  %t177 = getelementptr { i64, [2 x i64] }, ptr %t176, i32 0, i32 0
  store i64 1, ptr %t177
  %t179 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t174, 0
  %t180 = getelementptr { i64, [2 x i64] }, ptr %t176, i32 0, i32 1
  store { { i64, ptr } } %t179, ptr %t180
  %t181 = load { i64, [2 x i64] }, ptr %t176
  %t183 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 24, i64 8)
  store { i64, [2 x i64] } %t181, ptr %t183
  store { i64, [5 x i64] } zeroinitializer, ptr %t184
  %t185 = getelementptr { i64, [5 x i64] }, ptr %t184, i32 0, i32 0
  store i64 1, ptr %t185
  %t186 = load %"compiler/source:Span", ptr %l72
  %t187 = insertvalue { %"compiler/source:Span", i32, i64, ptr } undef, %"compiler/source:Span" %t186, 0
  %t188 = load i32, ptr %l79, !tbaa !23
  %t189 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t187, i32 %t188, 1
  %t191 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t189, i64 %t173, 2
  %t193 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t191, ptr %t183, 3
  %t194 = getelementptr { i64, [5 x i64] }, ptr %t184, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64, ptr } %t193, ptr %t194
  %t195 = load { i64, [5 x i64] }, ptr %t184
  %t197 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store { i64, [5 x i64] } %t195, ptr %t197
  store ptr %t197, ptr %rv
  br label %ret
bb37:
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t200 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %v0, ptr %t199, %"compiler/source:Span" %t200, { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d6, i32 0, i32 1) })
  br label %bb38
bb38:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load %"compiler/source:Span", ptr %l1
  %t207 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %t203, %"compiler/source:Span" %t204)
  store ptr %t207, ptr %l94
  br label %bb39
bb39:
  %t208 = load ptr, ptr %l94, !tbaa !29
  store ptr %t208, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca i32
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l17 = alloca i32
  %l18 = alloca %"compiler/typed:Call"
  %rv = alloca ptr
  %t28 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l3, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 5}
  %t8 = icmp eq i64 %t6, 4
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb12
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t10 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalledNow(ptr %v0, ptr %t10)
  br label %bb10
bb10:
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_af34769fdf26b030_eb833745f3a45efc)
  unreachable
bb12:
  %t12 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t12, ptr %l10
  store i32 %a2, ptr %l11, !tbaa !23
  %t14 = load ptr, ptr %l3, !tbaa !29
  store ptr %t14, ptr %l12, !tbaa !29
  store { i64, ptr } %a4, ptr %l13, !tbaa !27
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load %"compiler/source:Span", ptr %l1
  %t21 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t16, i32 0, %"compiler/source:Span" %t17)
  store i32 %t21, ptr %l17
  br label %bb13
bb13:
  %t22 = load ptr, ptr %l12, !tbaa !29
  %t23 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t24 = load i32, ptr %l17, !tbaa !23
  %t25 = call %"compiler/typed:Call" @compiler_2ftyped_3aCall_2ector(ptr %v1, ptr %v2, ptr %v3, ptr %t22, { i64, ptr } %t23, i32 %t24, i1 false, i1 false)
  store %"compiler/typed:Call" %t25, ptr %l18
  br label %bb14
bb14:
  %t26 = load %"compiler/typed:Call", ptr %l18
  %t27 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 32, i64 8)
  store %"compiler/typed:Call" %t26, ptr %t27
  store { i64, [5 x i64] } zeroinitializer, ptr %t28
  %t29 = getelementptr { i64, [5 x i64] }, ptr %t28, i32 0, i32 0
  store i64 6, ptr %t29
  %t30 = load %"compiler/source:Span", ptr %l10
  %t31 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t30, 0
  %t32 = load i32, ptr %l11, !tbaa !23
  %t33 = insertvalue { %"compiler/source:Span", i32, ptr } %t31, i32 %t32, 1
  %t35 = insertvalue { %"compiler/source:Span", i32, ptr } %t33, ptr %t27, 2
  %t36 = getelementptr { i64, [5 x i64] }, ptr %t28, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t35, ptr %t36
  %t37 = load { i64, [5 x i64] }, ptr %t28
  %t39 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 48, i64 8)
  store { i64, [5 x i64] } %t37, ptr %t39
  store ptr %t39, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecolumnsFields(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca ptr
  %lp17 = alloca ptr
  %l18 = alloca i64
  %l22 = alloca i32
  %l24 = alloca ptr
  %l26 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l28 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l30 = alloca i64
  %l32 = alloca i1
  %l35 = alloca i1
  %l37 = alloca i1
  %l41 = alloca i1
  %l44 = alloca i32
  %l47 = alloca i32
  %l50 = alloca ptr
  %l52 = alloca i32
  %l53 = alloca %"compiler/typed:Local"
  %l57 = alloca ptr
  %l62 = alloca i32
  %l63 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l70 = alloca ptr
  %l75 = alloca i32
  %l76 = alloca { i64, ptr }
  %l81 = alloca i64
  %l84 = alloca i64
  %l88 = alloca i64
  %l91 = alloca i64
  %l109 = alloca ptr
  %l110 = alloca %"compiler/source:Span"
  %l111 = alloca %"compiler/source:Span"
  %l112 = alloca { i64, ptr }
  %l114 = alloca i32
  %l115 = alloca %"compiler/source:Span"
  %l118 = alloca i32
  %l127 = alloca ptr
  %l129 = alloca { i64, ptr }
  %l132 = alloca i1
  %l139 = alloca i1
  %l140 = alloca %"compiler/source:Span"
  %l141 = alloca { i64, ptr }
  %l143 = alloca i32
  %l144 = alloca i32
  %l147 = alloca { i64, ptr }
  %l151 = alloca ptr
  %l152 = alloca ptr
  %l156 = alloca i32
  %l158 = alloca %"compiler/typed:Make"
  %l165 = alloca { i64, ptr }
  %l170 = alloca i64
  %l180 = alloca ptr
  %s0 = alloca %olang.scope
  %t198 = alloca { i64, [4 x i64] }, align 8
  %t211 = alloca { i64, [4 x i64] }, align 8
  %t289 = alloca { i64, [5 x i64] }, align 8
  %t317 = alloca { i64, [1 x i64] }, align 8
  %t335 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i32, ptr %l1, !tbaa !23
  %t8 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eColumnsRow(ptr %v0, ptr %t4, i32 %t5)
  store i32 %t8, ptr %l22
  br label %bb1
bb1:
  %t9 = load i32, ptr %l22, !tbaa !23
  store i32 %t9, ptr %l2, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t10)
  store ptr %t12, ptr %l24
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l24, !tbaa !29
  %t15 = getelementptr %"compiler/typed:Body", ptr %t13, i32 0, i32 5
  %t16 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t16, ptr %l26
  %t18 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e(ptr %s0, ptr %l26)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %l28
  br label %bb3
bb3:
  %t19 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l28
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l3
  %t21 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %s0, ptr %l3)
  store i64 %t21, ptr %l30
  br label %bb4
bb4:
  %t22 = load i64, ptr %l30, !tbaa !24
  %t23 = icmp slt i64 %t22, 2
  br i1 %t23, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb8
bb6:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i32, ptr %l2, !tbaa !23
  %t29 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %t25, i32 %t26)
  store i1 %t29, ptr %l35
  br label %bb7
bb7:
  %t30 = load i1, ptr %l35, !tbaa !21
  %t31 = xor i1 %t30, true
  store i1 %t31, ptr %l32, !tbaa !21
  br label %bb8
bb8:
  %t33 = load i1, ptr %l32, !tbaa !21
  br i1 %t33, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb12
bb10:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t38 = load i32, ptr %l2, !tbaa !23
  %t41 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t37, i32 %t38)
  store i1 %t41, ptr %l41
  br label %bb11
bb11:
  %t42 = load i1, ptr %l41, !tbaa !21
  %t43 = xor i1 %t42, true
  store i1 %t43, ptr %l37, !tbaa !21
  br label %bb12
bb12:
  %t45 = load i1, ptr %l37, !tbaa !21
  br i1 %t45, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb14:
  br label %bb15
bb15:
  %t47 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %s0, ptr %l3, i64 0)
  store i32 %t47, ptr %l44
  br label %bb16
bb16:
  %t48 = load i32, ptr %l44, !tbaa !23
  %t49 = sext i32 %t48 to i64
  store i64 %t49, ptr %l4, !tbaa !24
  %t52 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %s0, ptr %l3, i64 1)
  store i32 %t52, ptr %l47
  br label %bb17
bb17:
  %t53 = load i32, ptr %l47, !tbaa !23
  %t54 = sext i32 %t53 to i64
  store i64 %t54, ptr %l5, !tbaa !24
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t56)
  store ptr %t58, ptr %l50
  br label %bb18
bb18:
  %t60 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %s0, ptr %l3, i64 0)
  store i32 %t60, ptr %l52
  br label %bb19
bb19:
  %t61 = load ptr, ptr %l50, !tbaa !29
  %t62 = load i32, ptr %l52, !tbaa !23
  %t63 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t61, i32 %t62)
  store %"compiler/typed:Local" %t63, ptr %l53
  br label %bb20
bb20:
  %t64 = getelementptr %"compiler/typed:Local", ptr %l53, i32 0, i32 1
  %t65 = load %"compiler/source:Span", ptr %t64
  store %"compiler/source:Span" %t65, ptr %l6
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/check:Checker", ptr %t67, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t72 = getelementptr %"compiler/generic:Program", ptr %t70, i32 0, i32 2
  store ptr %t72, ptr %l57, !tbaa !29
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/check:Checker", ptr %t73, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t78 = getelementptr %"compiler/generic:Program", ptr %t76, i32 0, i32 2
  %t79 = load i32, ptr %l1, !tbaa !23
  %t82 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t78, i32 %t79)
  store i32 %t82, ptr %l62
  br label %bb21
bb21:
  %t83 = load ptr, ptr %l57, !tbaa !29
  %t84 = load i32, ptr %l62, !tbaa !23
  %t85 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t83, i32 %t84)
  store { i64, ptr } %t85, ptr %l63
  br label %bb22
bb22:
  %t86 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t86, ptr %l7, !tbaa !27
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/check:Checker", ptr %t87, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !29
  %t91 = load i32, ptr %l1, !tbaa !23
  %t94 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFieldNames(ptr %v0, ptr %s0, ptr %t90, i32 %t91)
  store { i64, ptr } %t94, ptr %l67
  br label %bb23
bb23:
  %t95 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t95, ptr %l8, !tbaa !27
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/check:Checker", ptr %t96, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t101 = getelementptr %"compiler/generic:Program", ptr %t99, i32 0, i32 2
  store ptr %t101, ptr %l70, !tbaa !29
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/check:Checker", ptr %t102, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t107 = getelementptr %"compiler/generic:Program", ptr %t105, i32 0, i32 2
  %t108 = load i32, ptr %l2, !tbaa !23
  %t111 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t107, i32 %t108)
  store i32 %t111, ptr %l75
  br label %bb24
bb24:
  %t112 = load ptr, ptr %l70, !tbaa !29
  %t113 = load i32, ptr %l75, !tbaa !23
  %t114 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t112, i32 %t113)
  store { i64, ptr } %t114, ptr %l76
  br label %bb25
bb25:
  %t115 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t115, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t116 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t118 = extractvalue { i64, ptr } %t116, 0
  %t119 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t119, 0
  %t124 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t118, i64 %t121)
  store i64 %t124, ptr %l81
  br label %bb26
bb26:
  %t125 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t127 = extractvalue { i64, ptr } %t125, 0
  %t128 = load i64, ptr %l81, !tbaa !24
  %t130 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t128, i64 %t127)
  store i64 %t130, ptr %l84
  br label %bb27
bb27:
  %t131 = load i64, ptr %l84, !tbaa !24
  store i64 %t131, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t132 = load i64, ptr %l11, !tbaa !24
  %t133 = load i64, ptr %l10, !tbaa !24
  %t136 = icmp sgt i64 %t132, %t133
  br i1 %t136, label %bb28, label %bb29
bb28:
  %t138 = load i64, ptr %l12, !tbaa !24
  %t140 = icmp sgt i64 %t138, 0
  br i1 %t140, label %bb30, label %bb31
bb29:
  store i64 0, ptr %l88, !tbaa !24
  br label %bb33
bb30:
  %t142 = load i64, ptr %l11, !tbaa !24
  %t143 = load i64, ptr %l10, !tbaa !24
  %t146 = sub i64 %t142, %t143
  %t147 = load i64, ptr %l12, !tbaa !24
  %t150 = add i64 %t146, %t147
  %t152 = sub i64 %t150, 1
  %t153 = load i64, ptr %l12, !tbaa !24
  %t156 = sdiv i64 %t152, %t153
  store i64 %t156, ptr %l91, !tbaa !24
  br label %bb32
bb31:
  store i64 0, ptr %l91, !tbaa !24
  br label %bb32
bb32:
  %t158 = load i64, ptr %l91, !tbaa !24
  store i64 %t158, ptr %l88, !tbaa !24
  br label %bb33
bb33:
  %t159 = load i64, ptr %l88, !tbaa !24
  store i64 %t159, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb34
bb34:
  %t160 = load i64, ptr %l14, !tbaa !24
  %t161 = load i64, ptr %l13, !tbaa !24
  %t164 = icmp slt i64 %t160, %t161
  %t166 = xor i1 %t164, true
  br i1 %t166, label %bb35, label %bb36
bb35:
  br label %bb55
bb36:
  br label %bb37
bb37:
  %t168 = load i64, ptr %l10, !tbaa !24
  %t169 = load i64, ptr %l14, !tbaa !24
  %t170 = load i64, ptr %l12, !tbaa !24
  %t173 = mul i64 %t169, %t170
  %t176 = add i64 %t168, %t173
  store i64 %t176, ptr %l15, !tbaa !24
  %t178 = load ptr, ptr %l0, !tbaa !29
  store ptr %t178, ptr %l109, !tbaa !29
  %t179 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t179, ptr %l110
  %t180 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t180, ptr %l111
  %t181 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t181, ptr %l112, !tbaa !27
  %t182 = load i64, ptr %l15, !tbaa !24
  %t184 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t185 = load ptr, ptr %t184, !tbaa !27
  %t186 = getelementptr i32, ptr %t185, i64 %t182
  %t187 = load i32, ptr %t186, !tbaa !33
  store i32 %t187, ptr %l114, !tbaa !23
  %t188 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t188, ptr %l115
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t190 = load i64, ptr %l5, !tbaa !24
  %t193 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t189, i64 %t190)
  store i32 %t193, ptr %l118
  br label %bb38
bb38:
  %t194 = load i64, ptr %l5, !tbaa !24
  %t196 = trunc i64 %t194 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t198
  %t199 = getelementptr { i64, [4 x i64] }, ptr %t198, i32 0, i32 0
  store i64 0, ptr %t199
  %t200 = load %"compiler/source:Span", ptr %l115
  %t201 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t200, 0
  %t202 = load i32, ptr %l118, !tbaa !23
  %t203 = insertvalue { %"compiler/source:Span", i32, i32 } %t201, i32 %t202, 1
  %t205 = insertvalue { %"compiler/source:Span", i32, i32 } %t203, i32 %t196, 2
  %t206 = getelementptr { i64, [4 x i64] }, ptr %t198, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t205, ptr %t206
  %t207 = load { i64, [4 x i64] }, ptr %t198
  %t209 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t207, ptr %t209
  %t210 = load i64, ptr %l15, !tbaa !24
  store { i64, [4 x i64] } zeroinitializer, ptr %t211
  %t212 = getelementptr { i64, [4 x i64] }, ptr %t211, i32 0, i32 0
  store i64 3, ptr %t212
  %t213 = load %"compiler/source:Span", ptr %l111
  %t214 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } undef, %"compiler/source:Span" %t213, 0
  %t215 = load i32, ptr %l114, !tbaa !23
  %t216 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t214, i32 %t215, 1
  %t218 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t216, ptr %t209, 2
  %t220 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t218, i64 %t210, 3
  %t221 = getelementptr { i64, [4 x i64] }, ptr %t211, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i64 } %t220, ptr %t221
  %t222 = load { i64, [4 x i64] }, ptr %t211
  %t224 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t222, ptr %t224
  %t225 = load ptr, ptr %l109, !tbaa !29
  %t226 = load %"compiler/source:Span", ptr %l110
  %t228 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v0, ptr %v0, ptr %t225, %"compiler/source:Span" %t226, ptr %t224)
  store ptr %t228, ptr %l127
  br label %bb39
bb39:
  %t229 = load ptr, ptr %l127, !tbaa !29
  store ptr %t229, ptr %l16, !tbaa !29
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t231, ptr %l129, !tbaa !27
  %t232 = load i64, ptr %l15, !tbaa !24
  %t234 = getelementptr { i64, ptr }, ptr %l129, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !27
  %t236 = getelementptr i32, ptr %t235, i64 %t232
  %t237 = load i32, ptr %t236, !tbaa !33
  %t240 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t230, i32 %t237)
  store i1 %t240, ptr %l132
  br label %bb40
bb40:
  %t241 = load i1, ptr %l132, !tbaa !21
  %t242 = xor i1 %t241, true
  br i1 %t242, label %bb41, label %bb42
bb41:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t245 = load ptr, ptr %l16, !tbaa !29
  %t247 = load %"compiler/source:Span", ptr %l6
  %t248 = load i64, ptr @G_2ecompiler_2fcheck_2eRoStored, !tbaa !24
  %t253 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroStore(ptr %v0, ptr %v0, ptr %t244, ptr %t245, %"compiler/source:Span" %t247, i64 %t248)
  store i1 %t253, ptr %l139
  br label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb44
bb44:
  %t254 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t254, ptr %l140
  %t255 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t255, ptr %l141, !tbaa !27
  %t256 = load i64, ptr %l15, !tbaa !24
  %t258 = getelementptr { i64, ptr }, ptr %l141, i32 0, i32 1
  %t259 = load ptr, ptr %t258, !tbaa !27
  %t260 = getelementptr i32, ptr %t259, i64 %t256
  %t261 = load i32, ptr %t260, !tbaa !33
  store i32 %t261, ptr %l143, !tbaa !23
  store i32 3, ptr %l144
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t263 = load ptr, ptr %l16, !tbaa !29
  %t266 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %v0, ptr %v0, ptr %t262, ptr %t263)
  store { i64, ptr } %t266, ptr %l147
  br label %bb45
bb45:
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t268 = load %"compiler/source:Span", ptr %l6
  %t269 = load i64, ptr %l4, !tbaa !24
  %t273 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t267, %"compiler/source:Span" %t268, i64 %t269)
  store ptr %t273, ptr %l151
  br label %bb46
bb46:
  %t274 = load ptr, ptr %l151, !tbaa !29
  store ptr %t274, ptr %l152, !tbaa !29
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t276 = load %"compiler/source:Span", ptr %l6
  %t280 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t275, i32 1, %"compiler/source:Span" %t276)
  store i32 %t280, ptr %l156
  br label %bb47
bb47:
  %t281 = load i32, ptr %l144, !range !{i32 0, i32 5}
  %t282 = load { i64, ptr }, ptr %l147, !tbaa !27
  %t283 = load ptr, ptr %l152, !tbaa !29
  %t284 = load i32, ptr %l156, !tbaa !23
  %t286 = call %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t281, i64 0, { i64, ptr } %t282, ptr %t283, i32 %t284, i32 1, i1 false)
  store %"compiler/typed:Make" %t286, ptr %l158
  br label %bb48
bb48:
  %t287 = load %"compiler/typed:Make", ptr %l158
  %t288 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store %"compiler/typed:Make" %t287, ptr %t288
  store { i64, [5 x i64] } zeroinitializer, ptr %t289
  %t290 = getelementptr { i64, [5 x i64] }, ptr %t289, i32 0, i32 0
  store i64 7, ptr %t290
  %t291 = load %"compiler/source:Span", ptr %l140
  %t292 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t291, 0
  %t293 = load i32, ptr %l143, !tbaa !23
  %t294 = insertvalue { %"compiler/source:Span", i32, ptr } %t292, i32 %t293, 1
  %t296 = insertvalue { %"compiler/source:Span", i32, ptr } %t294, ptr %t288, 2
  %t297 = getelementptr { i64, [5 x i64] }, ptr %t289, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t296, ptr %t297
  %t298 = load { i64, [5 x i64] }, ptr %t289
  %t299 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store ptr %t299, ptr %lp17
  %t301 = load ptr, ptr %lp17
  store { i64, [5 x i64] } %t298, ptr %t301
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t303 = load i64, ptr %l15, !tbaa !24
  %t305 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t306 = load ptr, ptr %t305, !tbaa !27
  %t307 = getelementptr i32, ptr %t306, i64 %t303
  %t308 = load i32, ptr %t307, !tbaa !33
  %t309 = load %"compiler/source:Span", ptr %l6
  %t310 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t310, ptr %l165, !tbaa !27
  %t311 = load i64, ptr %l15, !tbaa !24
  %t313 = getelementptr { i64, ptr }, ptr %l165, i32 0, i32 1
  %t314 = load ptr, ptr %t313, !tbaa !27
  %t315 = getelementptr i32, ptr %t314, i64 %t311
  %t316 = load i32, ptr %t315, !tbaa !33
  store { i64, [1 x i64] } zeroinitializer, ptr %t317
  %t318 = getelementptr { i64, [1 x i64] }, ptr %t317, i32 0, i32 0
  store i64 4, ptr %t318
  %t319 = load { i64, [1 x i64] }, ptr %t317
  %t326 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t302, i32 %t308, %"compiler/source:Span" %t309, i32 %t316, i32 6, { i64, [1 x i64] } %t319)
  store i64 %t326, ptr %l170
  br label %bb49
bb49:
  %t327 = load i64, ptr %l170, !tbaa !24
  store i64 %t327, ptr %l18, !tbaa !24
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t329 = load %"compiler/source:Span", ptr %l6
  %t330 = load i64, ptr %l18, !tbaa !24
  %t332 = trunc i64 %t330 to i32
  %t334 = load ptr, ptr %lp17
  store { i64, [3 x i64] } zeroinitializer, ptr %t335
  %t336 = getelementptr { i64, [3 x i64] }, ptr %t335, i32 0, i32 0
  store i64 0, ptr %t336
  %t338 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t329, 0
  %t340 = insertvalue { %"compiler/source:Span", i32, ptr } %t338, i32 %t332, 1
  %t342 = insertvalue { %"compiler/source:Span", i32, ptr } %t340, ptr %t334, 2
  %t343 = getelementptr { i64, [3 x i64] }, ptr %t335, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t342, ptr %t343
  %t344 = load { i64, [3 x i64] }, ptr %t335
  %t346 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t344, ptr %t346
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t328, ptr %t346)
  br label %bb50
bb50:
  %t349 = load ptr, ptr %l0, !tbaa !29
  %t351 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t349)
  store ptr %t351, ptr %l180
  br label %bb51
bb51:
  %t352 = load ptr, ptr %l180, !tbaa !29
  %t354 = getelementptr %"compiler/typed:Body", ptr %t352, i32 0, i32 10
  %t355 = load i64, ptr %l18, !tbaa !24
  %t357 = trunc i64 %t355 to i32
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2ePush_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t354, i32 %t357)
  br label %bb52
bb52:
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t362 = load i64, ptr %l18, !tbaa !24
  %t363 = load %"compiler/source:Span", ptr %l6
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropOnExit(ptr %v0, ptr %t361, i64 %t362, %"compiler/source:Span" %t363, i1 true)
  br label %bb53
bb53:
  br label %bb54
bb54:
  %t367 = load i64, ptr %l14, !tbaa !24
  %t369 = add i64 %t367, 1
  store i64 %t369, ptr %l14, !tbaa !24
  br label %bb34
bb55:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econstCond(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l7 = alloca i64
  %l14 = alloca i1
  %l18 = alloca ptr
  %l20 = alloca ptr
  %l25 = alloca i32
  %l30 = alloca i32
  %l39 = alloca i64
  %l41 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t6 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflDecide(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i64 %t6, ptr %l7
  br label %bb1
bb1:
  %t7 = load i64, ptr %l7, !tbaa !24
  store i64 %t7, ptr %l2, !tbaa !24
  %t8 = load i64, ptr %l2, !tbaa !24
  %t10 = icmp sge i64 %t8, 0
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i64, ptr %l2, !tbaa !24
  store i64 %t12, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t19 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadsConst(ptr %v0, ptr %v1, ptr %t14, ptr %t15)
  store i1 %t19, ptr %l14
  br label %bb5
bb5:
  %t20 = load i1, ptr %l14, !tbaa !21
  %t21 = xor i1 %t20, true
  br i1 %t21, label %bb6, label %bb7
bb6:
  store i64 -1, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  store ptr %t27, ptr %l18, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t28)
  store ptr %t30, ptr %l20
  br label %bb9
bb9:
  %t31 = load ptr, ptr %l20, !tbaa !29
  %t33 = getelementptr %"compiler/check:frame", ptr %t31, i32 0, i32 4
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t35 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t36 = load ptr, ptr %l18, !tbaa !29
  %t40 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFoldKnown(ptr %v0, ptr %v0, ptr %v1, ptr %t36, ptr %t33, ptr %t34, i32 %t35)
  store i32 %t40, ptr %l25
  br label %bb10
bb10:
  %t41 = load i32, ptr %l25, !tbaa !23
  store i32 %t41, ptr %l3, !tbaa !23
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/check:Checker", ptr %t42, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t47 = getelementptr %"compiler/generic:Program", ptr %t45, i32 0, i32 2
  %t48 = load i32, ptr %l3, !tbaa !23
  %t51 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t47, i32 %t48)
  store i32 %t51, ptr %l30
  br label %bb11
bb11:
  %t52 = load i32, ptr %l30, !range !{i32 0, i32 33}
  %t54 = trunc i64 26 to i32
  %t55 = icmp eq i32 %t52, %t54
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb12, label %bb13
bb12:
  store i64 -1, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/check:Checker", ptr %t60, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = getelementptr %"compiler/generic:Program", ptr %t63, i32 0, i32 2
  %t66 = load i32, ptr %l3, !tbaa !23
  %t69 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t65, i32 %t66)
  store i64 %t69, ptr %l39
  br label %bb15
bb15:
  %t70 = load i64, ptr %l39, !tbaa !24
  %t71 = icmp ne i64 %t70, 0
  br i1 %t71, label %bb16, label %bb17
bb16:
  store i64 1, ptr %l41, !tbaa !24
  br label %bb18
bb17:
  store i64 0, ptr %l41, !tbaa !24
  br label %bb18
bb18:
  %t73 = load i64, ptr %l41, !tbaa !24
  store i64 %t73, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorBodies(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca i1
  %l29 = alloca { i64, ptr }
  %l37 = alloca ptr
  %l38 = alloca i1
  %l45 = alloca ptr
  %l46 = alloca i1
  %l62 = alloca { i64, ptr }
  %l70 = alloca ptr
  %l71 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t2 = load ptr, ptr %l16, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l16, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 9
  store i1 %t8, ptr %l17, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l17, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t12, i32 0, i32 4
  %t14 = load { i64, ptr }, ptr %t13
  store { i64, ptr } %t14, ptr %l3, !tbaa !27
  br label %bb5
bb4:
  br label %bb13
bb5:
  %t16 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t16, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t18, 0
  store i64 %t20, ptr %l6, !tbaa !24
  br label %bb6
bb6:
  %t22 = load i64, ptr %l5, !tbaa !24
  %t23 = load i64, ptr %l6, !tbaa !24
  %t26 = icmp slt i64 %t22, %t23
  %t28 = xor i1 %t26, true
  br i1 %t28, label %bb7, label %bb8
bb7:
  br label %bb12
bb8:
  br label %bb9
bb9:
  %t30 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t30, ptr %l29, !tbaa !27
  %t31 = load i64, ptr %l5, !tbaa !24
  %t33 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr ptr, ptr %t34, i64 %t31
  %t36 = load ptr, ptr %t35, !tbaa !39
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorBodies(ptr %v0, ptr %v1, ptr %v2, ptr %t38, ptr %t36, ptr %t40)
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t44 = load i64, ptr %l5, !tbaa !24
  %t46 = add i64 %t44, 1
  store i64 %t46, ptr %l5, !tbaa !24
  br label %bb6
bb12:
  br label %bb50
bb13:
  %t48 = load ptr, ptr %l1, !tbaa !29
  store ptr %t48, ptr %l37, !tbaa !29
  store i1 false, ptr %l38, !tbaa !21
  %t49 = load ptr, ptr %l37, !tbaa !29
  %t50 = icmp ne ptr %t49, null
  br i1 %t50, label %bb14, label %bb15
bb14:
  %t52 = load ptr, ptr %l37, !tbaa !29
  %t53 = load i64, ptr %t52, !range !{i64 0, i64 18}
  %t55 = icmp eq i64 %t53, 6
  store i1 %t55, ptr %l38, !tbaa !21
  br label %bb15
bb15:
  %t56 = load i1, ptr %l38, !tbaa !21
  br i1 %t56, label %bb16, label %bb17
bb16:
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr { i64, [5 x i64] }, ptr %t57, i32 0, i32 1
  %t60 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t59, i32 0, i32 2
  %t61 = load ptr, ptr %t60
  store ptr %t61, ptr %l8, !tbaa !29
  br label %bb18
bb17:
  br label %bb38
bb18:
  %t63 = load ptr, ptr %l8, !tbaa !29
  %t65 = getelementptr %"compiler/typed:Call", ptr %t63, i32 0, i32 0
  %t66 = load ptr, ptr %t65, !tbaa !29
  store ptr %t66, ptr %l9, !tbaa !29
  %t68 = load ptr, ptr %l9, !tbaa !29
  store ptr %t68, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t69 = load ptr, ptr %l45, !tbaa !29
  %t70 = icmp ne ptr %t69, null
  br i1 %t70, label %bb19, label %bb20
bb19:
  %t72 = load ptr, ptr %l45, !tbaa !29
  %t73 = load i64, ptr %t72, !range !{i64 0, i64 5}
  %t75 = icmp eq i64 %t73, 0
  store i1 %t75, ptr %l46, !tbaa !21
  br label %bb20
bb20:
  %t76 = load i1, ptr %l46, !tbaa !21
  br i1 %t76, label %bb21, label %bb22
bb21:
  %t77 = load ptr, ptr %l9, !tbaa !29
  %t79 = getelementptr { i64, [3 x i64] }, ptr %t77, i32 0, i32 1
  %t80 = getelementptr { i32 }, ptr %t79, i32 0, i32 0
  %t81 = load i32, ptr %t80
  store i32 %t81, ptr %l10, !tbaa !23
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t83 = load ptr, ptr %l2, !tbaa !29
  %t84 = load i32, ptr %l10, !tbaa !23
  %t86 = sext i32 %t84 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t83, i64 %t86)
  br label %bb24
bb24:
  br label %bb30
bb25:
  br i1 true, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_1e68dbdbde35cba9_f30fa4c89b16ec2d)
  unreachable
bb30:
  %t89 = load ptr, ptr %l8, !tbaa !29
  %t91 = getelementptr %"compiler/typed:Call", ptr %t89, i32 0, i32 1
  %t92 = load { i64, ptr }, ptr %t91, !tbaa !27
  store { i64, ptr } %t92, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t94 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t96 = extractvalue { i64, ptr } %t94, 0
  store i64 %t96, ptr %l13, !tbaa !24
  br label %bb31
bb31:
  %t98 = load i64, ptr %l12, !tbaa !24
  %t99 = load i64, ptr %l13, !tbaa !24
  %t102 = icmp slt i64 %t98, %t99
  %t104 = xor i1 %t102, true
  br i1 %t104, label %bb32, label %bb33
bb32:
  br label %bb37
bb33:
  br label %bb34
bb34:
  %t106 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t106, ptr %l62, !tbaa !27
  %t107 = load i64, ptr %l12, !tbaa !24
  %t109 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = getelementptr ptr, ptr %t110, i64 %t107
  %t112 = load ptr, ptr %t111, !tbaa !39
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorBodies(ptr %v0, ptr %v1, ptr %v2, ptr %t114, ptr %t112, ptr %t116)
  br label %bb35
bb35:
  br label %bb36
bb36:
  %t120 = load i64, ptr %l12, !tbaa !24
  %t122 = add i64 %t120, 1
  store i64 %t122, ptr %l12, !tbaa !24
  br label %bb31
bb37:
  br label %bb50
bb38:
  %t124 = load ptr, ptr %l1, !tbaa !29
  store ptr %t124, ptr %l70, !tbaa !29
  store i1 false, ptr %l71, !tbaa !21
  %t125 = load ptr, ptr %l70, !tbaa !29
  %t126 = icmp ne ptr %t125, null
  br i1 %t126, label %bb39, label %bb40
bb39:
  %t128 = load ptr, ptr %l70, !tbaa !29
  %t129 = load i64, ptr %t128, !range !{i64 0, i64 18}
  %t131 = icmp eq i64 %t129, 17
  store i1 %t131, ptr %l71, !tbaa !21
  br label %bb40
bb40:
  %t132 = load i1, ptr %l71, !tbaa !21
  br i1 %t132, label %bb41, label %bb42
bb41:
  %t133 = load ptr, ptr %l1, !tbaa !29
  %t135 = getelementptr { i64, [5 x i64] }, ptr %t133, i32 0, i32 1
  %t136 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t135, i32 0, i32 2
  %t137 = load ptr, ptr %t136
  store ptr %t137, ptr %l15, !tbaa !29
  br label %bb43
bb42:
  br label %bb45
bb43:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load ptr, ptr %l15, !tbaa !29
  %t141 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorBodies(ptr %v0, ptr %v1, ptr %v2, ptr %t139, ptr %t140, ptr %t141)
  br label %bb44
bb44:
  br label %bb50
bb45:
  br i1 true, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb50
bb49:
  call void @__olang_check_failed(ptr @olang_loc_af264802bedcf8d8_5deeb41ed3d90c7c)
  unreachable
bb50:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorDefault(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i64
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca i64
  %l27 = alloca ptr
  %l29 = alloca ptr
  %l34 = alloca i32
  %l35 = alloca ptr
  %l42 = alloca i1
  %l49 = alloca ptr
  %l50 = alloca i1
  %l60 = alloca i1
  %l65 = alloca i1
  %l66 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l93 = alloca ptr
  %l94 = alloca %"compiler/source:Span"
  %l95 = alloca i64
  %l98 = alloca { i64, ptr }
  %l100 = alloca %"compiler/diagmsg:Msg"
  %l101 = alloca i64
  %l102 = alloca ptr
  %l103 = alloca %"compiler/source:Span"
  %l108 = alloca %"compiler/diagmsg:Msg"
  %l109 = alloca i64
  %l112 = alloca ptr
  %l115 = alloca ptr
  %l120 = alloca i32
  %l121 = alloca i64
  %l123 = alloca ptr
  %l127 = alloca ptr
  %l133 = alloca ptr
  %l134 = alloca ptr
  %l135 = alloca i64
  %l140 = alloca %"compiler/generic:Context"
  %l142 = alloca %"compiler/generic:Context"
  %l147 = alloca ptr
  %l148 = alloca { i64, ptr }
  %l154 = alloca ptr
  %l157 = alloca ptr
  %l159 = alloca ptr
  %s9 = alloca %olang.scope
  %rv = alloca ptr
  %t249 = alloca %"compiler/generic:Context", align 8
  %t416 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 28
  %t4 = load i32, ptr %t3, !tbaa !23
  store i32 %t4, ptr %l4, !tbaa !23
  %t6 = load i32, ptr %l4, !tbaa !23
  %t7 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t10 = icmp ne i32 %t6, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  store ptr %t15, ptr %l29, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 2
  %t22 = load i32, ptr %l4, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l34
  br label %bb3
bb2:
  store ptr null, ptr %l27, !tbaa !29
  br label %bb5
bb3:
  %t26 = load ptr, ptr %l29, !tbaa !29
  %t27 = load i32, ptr %l34, !tbaa !23
  %t28 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v0, ptr %t26, i32 %t27)
  store ptr %t28, ptr %l35
  br label %bb4
bb4:
  %t29 = load ptr, ptr %l35, !tbaa !29
  store ptr %t29, ptr %l27, !tbaa !29
  br label %bb5
bb5:
  %t30 = load ptr, ptr %l27, !tbaa !29
  store ptr %t30, ptr %l5, !tbaa !29
  %t31 = icmp sge i64 0, 0
  br i1 %t31, label %bb6, label %bb7
bb6:
  %t33 = icmp sle i64 0, 1152921504606846975
  br i1 %t33, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_bc2b949bbef92b23_ac5d28fb0edf1ff)
  unreachable
bb8:
  %t35 = mul i64 0, 8
  %t36 = insertvalue { i64, ptr } undef, i64 0, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t37, ptr %l6, !tbaa !27
  %t39 = load ptr, ptr %l5, !tbaa !29
  %t41 = icmp eq ptr %t39, null
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_bc2b949bbef92b23_ac5d28fb0edf1ff)
  unreachable
bb10:
  %t45 = load ptr, ptr %l5, !tbaa !29
  %t47 = getelementptr %"compiler/ast:TypeDecl", ptr %t45, i32 0, i32 3
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t50 = icmp eq ptr %t48, null
  %t52 = xor i1 %t50, true
  store i1 %t52, ptr %l42, !tbaa !21
  br label %bb12
bb11:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb12
bb12:
  %t54 = load i1, ptr %l42, !tbaa !21
  br i1 %t54, label %bb13, label %bb14
bb13:
  %t55 = load ptr, ptr %l5, !tbaa !29
  %t57 = getelementptr %"compiler/ast:TypeDecl", ptr %t55, i32 0, i32 3
  %t58 = load ptr, ptr %t57, !tbaa !29
  store ptr %t58, ptr %l7, !tbaa !29
  %t60 = load ptr, ptr %l7, !tbaa !29
  store ptr %t60, ptr %l49, !tbaa !29
  store i1 false, ptr %l50, !tbaa !21
  %t61 = load ptr, ptr %l49, !tbaa !29
  %t62 = icmp ne ptr %t61, null
  br i1 %t62, label %bb15, label %bb16
bb14:
  br label %bb26
bb15:
  %t64 = load ptr, ptr %l49, !tbaa !29
  %t65 = load i64, ptr %t64, !range !{i64 0, i64 5}
  %t67 = icmp eq i64 %t65, 0
  store i1 %t67, ptr %l50, !tbaa !21
  br label %bb16
bb16:
  %t68 = load i1, ptr %l50, !tbaa !21
  br i1 %t68, label %bb17, label %bb18
bb17:
  %t69 = load ptr, ptr %l7, !tbaa !29
  %t71 = getelementptr { i64, [6 x i64] }, ptr %t69, i32 0, i32 1
  %t72 = getelementptr { ptr }, ptr %t71, i32 0, i32 0
  %t73 = load ptr, ptr %t72
  store ptr %t73, ptr %l8, !tbaa !29
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t75 = load ptr, ptr %l8, !tbaa !29
  %t77 = getelementptr %"compiler/ast:StructBody", ptr %t75, i32 0, i32 0
  %t78 = load { i64, ptr }, ptr %t77, !tbaa !27
  store { i64, ptr } %t78, ptr %l6, !tbaa !27
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_fc391d98a693d1b5_39c844f8cb4c6229)
  unreachable
bb25:
  br label %bb26
bb26:
  %t80 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t80, 0
  %t84 = icmp eq i64 %t82, 0
  br i1 %t84, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb29
bb28:
  %t86 = load i64, ptr %l2, !tbaa !24
  %t87 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t89 = extractvalue { i64, ptr } %t87, 0
  %t92 = icmp sge i64 %t86, %t89
  store i1 %t92, ptr %l60, !tbaa !21
  br label %bb29
bb29:
  %t94 = load i1, ptr %l60, !tbaa !21
  br i1 %t94, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l65, !tbaa !21
  br label %bb32
bb31:
  %t95 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t95, ptr %l66, !tbaa !27
  %t96 = load i64, ptr %l2, !tbaa !24
  %t98 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr ptr, ptr %t99, i64 %t96
  %t101 = load ptr, ptr %t100, !tbaa !39
  %t103 = getelementptr %"compiler/ast:Param", ptr %t101, i32 0, i32 3
  %t104 = load ptr, ptr %t103, !tbaa !29
  %t106 = icmp eq ptr %t104, null
  store i1 %t106, ptr %l65, !tbaa !21
  br label %bb32
bb32:
  %t108 = load i1, ptr %l65, !tbaa !21
  br i1 %t108, label %bb33, label %bb34
bb33:
  store i64 0, ptr %l9, !tbaa !24
  %t109 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t109, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t111 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t111, 0
  store i64 %t113, ptr %l12, !tbaa !24
  br label %bb35
bb34:
  br label %bb55
bb35:
  %t115 = load i64, ptr %l11, !tbaa !24
  %t116 = load i64, ptr %l12, !tbaa !24
  %t119 = icmp slt i64 %t115, %t116
  %t121 = xor i1 %t119, true
  br i1 %t121, label %bb36, label %bb37
bb36:
  br label %bb43
bb37:
  br label %bb38
bb38:
  %t123 = load i64, ptr %l11, !tbaa !24
  store i64 %t123, ptr %l13, !tbaa !24
  %t125 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t125, ptr %l79, !tbaa !27
  %t126 = load i64, ptr %l11, !tbaa !24
  %t128 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = getelementptr ptr, ptr %t129, i64 %t126
  %t131 = load ptr, ptr %t130, !tbaa !39
  %t135 = getelementptr %"compiler/ast:Param", ptr %t131, i32 0, i32 3
  %t136 = load ptr, ptr %t135, !tbaa !29
  %t138 = icmp eq ptr %t136, null
  br i1 %t138, label %bb39, label %bb40
bb39:
  %t140 = load i64, ptr %l13, !tbaa !24
  %t142 = add i64 %t140, 1
  store i64 %t142, ptr %l9, !tbaa !24
  br label %bb41
bb40:
  br label %bb41
bb41:
  br label %bb42
bb42:
  %t144 = load i64, ptr %l11, !tbaa !24
  %t146 = add i64 %t144, 1
  store i64 %t146, ptr %l11, !tbaa !24
  br label %bb35
bb43:
  %t148 = load i64, ptr %l9, !tbaa !24
  %t149 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t151 = extractvalue { i64, ptr } %t149, 0
  %t154 = icmp eq i64 %t148, %t151
  br i1 %t154, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s9
  %t156 = load ptr, ptr %l0, !tbaa !29
  store ptr %t156, ptr %l93, !tbaa !29
  %t157 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t157, ptr %l94
  %t158 = load i64, ptr %l9, !tbaa !24
  store i64 %t158, ptr %l95, !tbaa !24
  %t159 = load i64, ptr %l9, !tbaa !24
  %t161 = icmp eq i64 %t159, 1
  br i1 %t161, label %bb46, label %bb47
bb45:
  %t163 = load ptr, ptr %l0, !tbaa !29
  store ptr %t163, ptr %l102, !tbaa !29
  %t164 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t164, ptr %l103
  %t165 = load i64, ptr %l9, !tbaa !24
  %t166 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t168 = extractvalue { i64, ptr } %t166, 0
  %t169 = load i64, ptr %l2, !tbaa !24
  %t173 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eArgCountRange(ptr %v0, i64 %t165, i64 %t168, i64 %t169)
  store %"compiler/diagmsg:Msg" %t173, ptr %l108
  br label %bb51
bb46:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d7, i32 0, i32 1) }, ptr %l98, !tbaa !27
  br label %bb48
bb47:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, ptr %l98, !tbaa !27
  br label %bb48
bb48:
  %t174 = load i64, ptr %l2, !tbaa !24
  %t175 = load i64, ptr %l95, !tbaa !24
  %t176 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t178 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eArgCount(ptr %s9, ptr %v0, i64 %t175, { i64, ptr } %t176, i64 %t174)
  store %"compiler/diagmsg:Msg" %t178, ptr %l100
  br label %bb49
bb49:
  %t179 = load ptr, ptr %l93, !tbaa !29
  %t180 = load %"compiler/source:Span", ptr %l94
  %t181 = load %"compiler/diagmsg:Msg", ptr %l100
  %t182 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t179, %"compiler/source:Span" %t180, %"compiler/diagmsg:Msg" %t181)
  store i64 %t182, ptr %l101
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s9)
  br label %bb53
bb51:
  %t183 = load ptr, ptr %l102, !tbaa !29
  %t184 = load %"compiler/source:Span", ptr %l103
  %t185 = load %"compiler/diagmsg:Msg", ptr %l108
  %t186 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t183, %"compiler/source:Span" %t184, %"compiler/diagmsg:Msg" %t185)
  store i64 %t186, ptr %l109
  br label %bb52
bb52:
  br label %bb53
bb53:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t188 = load %"compiler/source:Span", ptr %l1
  %t191 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %t187, %"compiler/source:Span" %t188)
  store ptr %t191, ptr %l112
  br label %bb54
bb54:
  %t192 = load ptr, ptr %l112, !tbaa !29
  store ptr %t192, ptr %rv
  br label %ret
bb55:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t195 = getelementptr %"compiler/check:Checker", ptr %t193, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !29
  %t198 = getelementptr %"compiler/generic:Program", ptr %t196, i32 0, i32 2
  store ptr %t198, ptr %l115, !tbaa !29
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t201 = getelementptr %"compiler/check:Checker", ptr %t199, i32 0, i32 1
  %t202 = load ptr, ptr %t201, !tbaa !29
  %t204 = getelementptr %"compiler/generic:Program", ptr %t202, i32 0, i32 2
  %t205 = load i32, ptr %l4, !tbaa !23
  %t208 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t204, i32 %t205)
  store i32 %t208, ptr %l120
  br label %bb56
bb56:
  %t209 = load ptr, ptr %l115, !tbaa !29
  %t210 = load i32, ptr %l120, !tbaa !23
  %t211 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t209, i32 %t210)
  store i64 %t211, ptr %l121
  br label %bb57
bb57:
  %t212 = load i64, ptr %l121, !tbaa !24
  store i64 %t212, ptr %l15, !tbaa !24
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t215 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t213)
  store ptr %t215, ptr %l123
  br label %bb58
bb58:
  %t216 = load ptr, ptr %l123, !tbaa !29
  %t218 = getelementptr %"compiler/check:frame", ptr %t216, i32 0, i32 2
  %t219 = load i64, ptr %t218, !tbaa !24
  store i64 %t219, ptr %l16, !tbaa !24
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t223 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t221)
  store ptr %t223, ptr %l127
  br label %bb59
bb59:
  %t224 = load ptr, ptr %l127, !tbaa !29
  store ptr %t224, ptr %l17, !tbaa !29
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t226 = load ptr, ptr %l17, !tbaa !29
  %t228 = getelementptr %"compiler/check:frame", ptr %t226, i32 0, i32 0
  %t229 = load i64, ptr %t228, !tbaa !24
  %t230 = load i64, ptr %l15, !tbaa !24
  %t231 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t236 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v0, ptr %t225, i64 %t229, i64 %t230, i32 %t231, i32 0)
  store ptr %t236, ptr %l133
  br label %bb60
bb60:
  %t237 = load ptr, ptr %l133, !tbaa !29
  store ptr %t237, ptr %l18, !tbaa !29
  %t238 = load ptr, ptr %l18, !tbaa !29
  store ptr %t238, ptr %l134, !tbaa !29
  %t239 = ptrtoint ptr %v0 to i64
  store i64 %t239, ptr %l135, !tbaa !24
  %t240 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aframe_2e4
  br i1 %t240, label %bb61, label %bb62
bb61:
  %t242 = call ptr @__olang_region_make(ptr %v0)
  %t243 = ptrtoint ptr %t242 to i64
  store i64 %t243, ptr %l135, !tbaa !24
  br label %bb62
bb62:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t246 = getelementptr %"compiler/check:Checker", ptr %t244, i32 0, i32 1
  %t247 = load ptr, ptr %t246, !tbaa !29
  %t248 = load i32, ptr %l4, !tbaa !23
  %t250 = load i64, ptr %l135
  %t251 = inttoptr i64 %t250 to ptr
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceContext(ptr %t249, ptr %v0, ptr %t251, ptr %t247, i32 %t248)
  call void @llvm.memmove.p0.p0.i64(ptr %l140, ptr %t249, i64 160, i1 false)
  br label %bb63
bb63:
  %t254 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aframe_2e4
  br i1 %t254, label %bb64, label %bb65
bb64:
  %t256 = load i64, ptr %l135
  %t257 = inttoptr i64 %t256 to ptr
  %t258 = getelementptr %"compiler/generic:Context", ptr %l140, i32 0, i32 3
  %t259 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t258, i32 0, i32 2
  %t260 = load { i64, ptr }, ptr %t259
  %t261 = extractvalue { i64, ptr } %t260, 1
  %t262 = call ptr @__olang_region_or(ptr %t261, ptr null)
  %t263 = call ptr @__olang_region_home(ptr %t262)
  %t264 = icmp ne ptr %t263, null
  %t265 = select i1 %t264, ptr %t263, ptr null
  %t266 = getelementptr %"compiler/generic:Context", ptr %l140, i32 0, i32 3
  %t267 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t266, i32 0, i32 1
  %t268 = load { i64, ptr }, ptr %t267
  %t269 = extractvalue { i64, ptr } %t268, 1
  %t270 = call ptr @__olang_region_or(ptr %t269, ptr null)
  %t271 = call ptr @__olang_region_home(ptr %t270)
  %t272 = icmp ne ptr %t271, null
  %t273 = select i1 %t272, ptr %t271, ptr %t265
  %t274 = getelementptr %"compiler/generic:Context", ptr %l140, i32 0, i32 3
  %t275 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t274, i32 0, i32 0
  %t276 = load { i64, ptr }, ptr %t275
  %t277 = extractvalue { i64, ptr } %t276, 1
  %t278 = call ptr @__olang_region_or(ptr %t277, ptr null)
  %t279 = call ptr @__olang_region_home(ptr %t278)
  %t280 = icmp ne ptr %t279, null
  %t281 = select i1 %t280, ptr %t279, ptr %t273
  %t282 = getelementptr %"compiler/generic:Context", ptr %l140, i32 0, i32 2
  %t283 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t282, i32 0, i32 2
  %t284 = load { i64, ptr }, ptr %t283
  %t285 = extractvalue { i64, ptr } %t284, 1
  %t286 = call ptr @__olang_region_or(ptr %t285, ptr null)
  %t287 = call ptr @__olang_region_home(ptr %t286)
  %t288 = icmp ne ptr %t287, null
  %t289 = select i1 %t288, ptr %t287, ptr %t281
  %t290 = getelementptr %"compiler/generic:Context", ptr %l140, i32 0, i32 2
  %t291 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t290, i32 0, i32 1
  %t292 = load { i64, ptr }, ptr %t291
  %t293 = extractvalue { i64, ptr } %t292, 1
  %t294 = call ptr @__olang_region_or(ptr %t293, ptr null)
  %t295 = call ptr @__olang_region_home(ptr %t294)
  %t296 = icmp ne ptr %t295, null
  %t297 = select i1 %t296, ptr %t295, ptr %t289
  %t298 = getelementptr %"compiler/generic:Context", ptr %l140, i32 0, i32 2
  %t299 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t298, i32 0, i32 0
  %t300 = load { i64, ptr }, ptr %t299
  %t301 = extractvalue { i64, ptr } %t300, 1
  %t302 = call ptr @__olang_region_or(ptr %t301, ptr null)
  %t303 = call ptr @__olang_region_home(ptr %t302)
  %t304 = icmp ne ptr %t303, null
  %t305 = select i1 %t304, ptr %t303, ptr %t297
  %t306 = icmp eq ptr %t305, %t257
  call void @__olang_region_settle(ptr %t257, i1 %t306)
  br label %bb65
bb65:
  %t307 = load ptr, ptr %l134, !tbaa !29
  %t308 = getelementptr %"compiler/check:frame", ptr %t307, i32 0, i32 4
  call void @llvm.memmove.p0.p0.i64(ptr %l142, ptr %t308, i64 160, i1 false)
  %t309 = load ptr, ptr %l134, !tbaa !29
  %t310 = getelementptr %"compiler/check:frame", ptr %t309, i32 0, i32 4
  call void @llvm.memmove.p0.p0.i64(ptr %t310, ptr %l140, i64 160, i1 false)
  %t311 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aframe_2e4
  br i1 %t311, label %bb66, label %bb67
bb66:
  %t313 = getelementptr %"compiler/generic:Context", ptr %l142, i32 0, i32 3
  %t314 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t313, i32 0, i32 2
  %t315 = load { i64, ptr }, ptr %t314
  %t316 = extractvalue { i64, ptr } %t315, 1
  %t317 = call ptr @__olang_region_or(ptr %t316, ptr null)
  %t318 = call ptr @__olang_region_home(ptr %t317)
  %t319 = icmp ne ptr %t318, null
  %t320 = select i1 %t319, ptr %t318, ptr null
  %t321 = getelementptr %"compiler/generic:Context", ptr %l142, i32 0, i32 3
  %t322 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t321, i32 0, i32 1
  %t323 = load { i64, ptr }, ptr %t322
  %t324 = extractvalue { i64, ptr } %t323, 1
  %t325 = call ptr @__olang_region_or(ptr %t324, ptr null)
  %t326 = call ptr @__olang_region_home(ptr %t325)
  %t327 = icmp ne ptr %t326, null
  %t328 = select i1 %t327, ptr %t326, ptr %t320
  %t329 = getelementptr %"compiler/generic:Context", ptr %l142, i32 0, i32 3
  %t330 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t329, i32 0, i32 0
  %t331 = load { i64, ptr }, ptr %t330
  %t332 = extractvalue { i64, ptr } %t331, 1
  %t333 = call ptr @__olang_region_or(ptr %t332, ptr null)
  %t334 = call ptr @__olang_region_home(ptr %t333)
  %t335 = icmp ne ptr %t334, null
  %t336 = select i1 %t335, ptr %t334, ptr %t328
  %t337 = getelementptr %"compiler/generic:Context", ptr %l142, i32 0, i32 2
  %t338 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t337, i32 0, i32 2
  %t339 = load { i64, ptr }, ptr %t338
  %t340 = extractvalue { i64, ptr } %t339, 1
  %t341 = call ptr @__olang_region_or(ptr %t340, ptr null)
  %t342 = call ptr @__olang_region_home(ptr %t341)
  %t343 = icmp ne ptr %t342, null
  %t344 = select i1 %t343, ptr %t342, ptr %t336
  %t345 = getelementptr %"compiler/generic:Context", ptr %l142, i32 0, i32 2
  %t346 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t345, i32 0, i32 1
  %t347 = load { i64, ptr }, ptr %t346
  %t348 = extractvalue { i64, ptr } %t347, 1
  %t349 = call ptr @__olang_region_or(ptr %t348, ptr null)
  %t350 = call ptr @__olang_region_home(ptr %t349)
  %t351 = icmp ne ptr %t350, null
  %t352 = select i1 %t351, ptr %t350, ptr %t344
  %t353 = getelementptr %"compiler/generic:Context", ptr %l142, i32 0, i32 2
  %t354 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t353, i32 0, i32 0
  %t355 = load { i64, ptr }, ptr %t354
  %t356 = extractvalue { i64, ptr } %t355, 1
  %t357 = call ptr @__olang_region_or(ptr %t356, ptr null)
  %t358 = call ptr @__olang_region_home(ptr %t357)
  %t359 = icmp ne ptr %t358, null
  %t360 = select i1 %t359, ptr %t358, ptr %t352
  call void @__olang_region_drop(ptr %t360)
  store %"compiler/generic:Context" zeroinitializer, ptr %l142
  br label %bb67
bb67:
  %t361 = load ptr, ptr %l18, !tbaa !29
  %t362 = load ptr, ptr %l17, !tbaa !29
  %t364 = getelementptr %"compiler/check:frame", ptr %t362, i32 0, i32 7
  %t365 = load i64, ptr %t364, !tbaa !24
  %t368 = getelementptr %"compiler/check:frame", ptr %t361, i32 0, i32 7
  store i64 %t365, ptr %t368, !tbaa !24
  %t369 = load ptr, ptr %l0, !tbaa !29
  store ptr %t369, ptr %l147, !tbaa !29
  %t370 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t370, ptr %l148, !tbaa !27
  %t371 = load i64, ptr %l2, !tbaa !24
  %t373 = getelementptr { i64, ptr }, ptr %l148, i32 0, i32 1
  %t374 = load ptr, ptr %t373, !tbaa !27
  %t375 = getelementptr ptr, ptr %t374, i64 %t371
  %t376 = load ptr, ptr %t375, !tbaa !39
  %t378 = getelementptr %"compiler/ast:Param", ptr %t376, i32 0, i32 3
  %t379 = load ptr, ptr %t378, !tbaa !29
  store ptr %t379, ptr %l19, !tbaa !29
  %t381 = load ptr, ptr %l19, !tbaa !29
  %t383 = icmp eq ptr %t381, null
  br i1 %t383, label %bb68, label %bb69
bb68:
  call void @__olang_check_failed(ptr @olang_loc_ff2084232290eae7_203579eb66e705cb)
  unreachable
bb69:
  br label %bb70
bb70:
  %t385 = load ptr, ptr %l19, !tbaa !29
  store ptr %t385, ptr %l154, !tbaa !29
  %t387 = load ptr, ptr %l154, !tbaa !29
  %t388 = call ptr @__olang_scope_of(ptr %t387, ptr null)
  %t389 = ptrtoint ptr %t388 to i64
  %t391 = inttoptr i64 %t389 to ptr
  %t392 = load ptr, ptr %l147, !tbaa !29
  %t393 = load ptr, ptr %l154, !tbaa !29
  %t395 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %t391, ptr %v1, ptr %t392, ptr %t393, i32 %a3)
  store ptr %t395, ptr %l157
  br label %bb71
bb71:
  %t396 = load ptr, ptr %l157, !tbaa !29
  store ptr %t396, ptr %l20, !tbaa !29
  %t397 = load ptr, ptr %l0, !tbaa !29
  %t399 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t397)
  store ptr %t399, ptr %l159
  br label %bb72
bb72:
  %t400 = load ptr, ptr %l159, !tbaa !29
  %t402 = getelementptr %"compiler/check:frame", ptr %t400, i32 0, i32 2
  %t403 = load i64, ptr %t402, !tbaa !24
  store i64 %t403, ptr %l21, !tbaa !24
  %t405 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t405)
  br label %bb73
bb73:
  %t407 = load i64, ptr %l21, !tbaa !24
  %t408 = load i64, ptr %l16, !tbaa !24
  %t411 = icmp ne i64 %t407, %t408
  br i1 %t411, label %bb74, label %bb75
bb74:
  %t413 = load %"compiler/source:Span", ptr %l1
  %t414 = load i64, ptr %l21, !tbaa !24
  %t415 = load ptr, ptr %l20, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t416
  %t417 = getelementptr { i64, [5 x i64] }, ptr %t416, i32 0, i32 0
  store i64 17, ptr %t417
  %t419 = insertvalue { %"compiler/source:Span", i64, ptr } undef, %"compiler/source:Span" %t413, 0
  %t421 = insertvalue { %"compiler/source:Span", i64, ptr } %t419, i64 %t414, 1
  %t423 = insertvalue { %"compiler/source:Span", i64, ptr } %t421, ptr %t415, 2
  %t424 = getelementptr { i64, [5 x i64] }, ptr %t416, i32 0, i32 1
  store { %"compiler/source:Span", i64, ptr } %t423, ptr %t424
  %t425 = load { i64, [5 x i64] }, ptr %t416
  %t427 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store { i64, [5 x i64] } %t425, ptr %t427
  store ptr %t427, ptr %rv
  br label %ret
bb75:
  br label %bb76
bb76:
  %t429 = load ptr, ptr %l20, !tbaa !29
  store ptr %t429, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorViewKey(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i32
  %l4 = alloca i32
  %l7 = alloca i64
  %l14 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Body", ptr %a1, i32 0, i32 1
  %t4 = load { i64, [2 x i64] }, ptr %t3
  store { i64, [2 x i64] } %t4, ptr %l2
  %t6 = load { i64, [2 x i64] }, ptr %l2
  %t8 = extractvalue { i64, [2 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 1
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t12 = getelementptr { i32, i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  store i32 %t13, ptr %l3, !tbaa !23
  %t15 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t16 = getelementptr { i32, i32 }, ptr %t15, i32 0, i32 1
  %t17 = load i32, ptr %t16
  store i32 %t17, ptr %l4, !tbaa !23
  br label %bb3
bb2:
  br label %bb7
bb3:
  %t19 = load i32, ptr %l4, !tbaa !23
  %t21 = icmp eq i32 %t19, 0
  br i1 %t21, label %bb4, label %bb5
bb4:
  %t23 = load i32, ptr %l3, !tbaa !23
  %t25 = sext i32 %t23 to i64
  store i64 %t25, ptr %l14, !tbaa !24
  br label %bb6
bb5:
  store i64 -1, ptr %l14, !tbaa !24
  br label %bb6
bb6:
  %t27 = load i64, ptr %l14, !tbaa !24
  store i64 %t27, ptr %l7, !tbaa !24
  br label %bb12
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i64 -1, ptr %l7, !tbaa !24
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_7351608f8313d577_54e294ea81fa84bb)
  unreachable
bb12:
  %t28 = load i64, ptr %l7, !tbaa !24
  store i64 %t28, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclareUnknown(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i1
  %l18 = alloca { i64, ptr }
  %l19 = alloca i1
  %l27 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca %"compiler/source:Span"
  %l32 = alloca i32
  %l35 = alloca ptr
  %s2 = alloca %olang.scope
  %t40 = alloca { i64, [1 x i64] }, align 8
  %t62 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = xor i1 %a2, true
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t6 = load ptr, ptr %l8, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l8, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 28}
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l9, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l9, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [4 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32 }, ptr %t16, i32 0, i32 0
  %t18 = load %"compiler/source:Span", ptr %t17
  store %"compiler/source:Span" %t18, ptr %l3
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr { i64, [4 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", i32 }, ptr %t22, i32 0, i32 1
  %t24 = load i32, ptr %t23
  store i32 %t24, ptr %l4, !tbaa !23
  br label %bb8
bb7:
  br label %bb17
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load i32, ptr %l4, !tbaa !23
  %t30 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t26, i32 %t27)
  store { i64, ptr } %t30, ptr %l18
  br label %bb9
bb9:
  %t31 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t32 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t31, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d9, i32 0, i32 1) })
  store i1 %t32, ptr %l19
  br label %bb10
bb10:
  %t33 = load i1, ptr %l19, !tbaa !21
  %t34 = xor i1 %t33, true
  br i1 %t34, label %bb11, label %bb12
bb11:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load i32, ptr %l4, !tbaa !23
  %t38 = load %"compiler/source:Span", ptr %l3
  %t39 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t40
  %t41 = getelementptr { i64, [1 x i64] }, ptr %t40, i32 0, i32 0
  store i64 4, ptr %t41
  %t42 = load { i64, [1 x i64] }, ptr %t40
  %t49 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t36, i32 %t37, %"compiler/source:Span" %t38, i32 %t39, i32 1, { i64, [1 x i64] } %t42)
  store i64 %t49, ptr %l27
  br label %bb13
bb12:
  br label %bb16
bb13:
  %t50 = load i64, ptr %l27, !tbaa !24
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l28, !tbaa !29
  %t52 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t52, ptr %l29
  %t55 = trunc i64 %t50 to i32
  store i32 %t55, ptr %l32, !tbaa !23
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load %"compiler/source:Span", ptr %l3
  %t61 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v0, ptr %t57, %"compiler/source:Span" %t58)
  store ptr %t61, ptr %l35
  br label %bb14
bb14:
  store { i64, [3 x i64] } zeroinitializer, ptr %t62
  %t63 = getelementptr { i64, [3 x i64] }, ptr %t62, i32 0, i32 0
  store i64 0, ptr %t63
  %t64 = load %"compiler/source:Span", ptr %l29
  %t65 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t64, 0
  %t66 = load i32, ptr %l32, !tbaa !23
  %t67 = insertvalue { %"compiler/source:Span", i32, ptr } %t65, i32 %t66, 1
  %t68 = load ptr, ptr %l35, !tbaa !29
  %t69 = insertvalue { %"compiler/source:Span", i32, ptr } %t67, ptr %t68, 2
  %t70 = getelementptr { i64, [3 x i64] }, ptr %t62, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t69, ptr %t70
  %t71 = load { i64, [3 x i64] }, ptr %t62
  %t73 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t71, ptr %t73
  %t74 = load ptr, ptr %l28, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t74, ptr %t73)
  br label %bb15
bb15:
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_7e44f5428cde099f_6973e730479eef7b)
  unreachable
bb22:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefineValue(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca %"compiler/cond:Value"
  %l5 = alloca i1
  %l6 = alloca i32
  %l7 = alloca %"compiler/cond:Value"
  %l11 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca %"compiler/cond:Value"
  %l16 = alloca i32
  %l21 = alloca i32
  %l24 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca %"compiler/source:Span"
  %l30 = alloca i32
  %l33 = alloca i64
  %l34 = alloca ptr
  %l38 = alloca i1
  %l43 = alloca i1
  %l48 = alloca ptr
  %l52 = alloca i1
  %l57 = alloca i1
  %l58 = alloca ptr
  %l59 = alloca %"compiler/source:Span"
  %l60 = alloca i32
  %l61 = alloca i32
  %l64 = alloca %"compiler/check:litv"
  %l65 = alloca i64
  %l66 = alloca ptr
  %l70 = alloca i1
  %l75 = alloca i1
  %l76 = alloca ptr
  %l77 = alloca %"compiler/source:Span"
  %l78 = alloca i32
  %l81 = alloca i64
  %l82 = alloca ptr
  %l86 = alloca i1
  %l87 = alloca i32
  %l89 = alloca i32
  %l94 = alloca ptr
  %s4 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  store ptr %t10, ptr %l11, !tbaa !29
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr %l2, !tbaa !23
  %t15 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t11, i32 %t12)
  store { i64, ptr } %t15, ptr %l14
  br label %bb1
bb1:
  %t16 = load ptr, ptr %l11, !tbaa !29
  %t17 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t18 = call { i32, %"compiler/cond:Value" } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eValueOf(ptr %v0, ptr %v0, ptr %t16, { i64, ptr } %t17)
  %t19 = extractvalue { i32, %"compiler/cond:Value" } %t18, 1
  %t20 = extractvalue { i32, %"compiler/cond:Value" } %t18, 0
  store i32 %t20, ptr %l16
  %t21 = icmp ne i32 %t20, 0
  br i1 %t21, label %bb3, label %ok.22, !prof !99
ok.22:
  store %"compiler/cond:Value" %t19, ptr %l15
  br label %bb2
bb2:
  %t23 = load %"compiler/cond:Value", ptr %l15
  store %"compiler/cond:Value" %t23, ptr %l7
  br label %bb5
bb3:
  br label %bb4
bb4:
  store ptr null, ptr %rv
  br label %ret
bb5:
  %t25 = load %"compiler/cond:Value", ptr %l7
  store %"compiler/cond:Value" %t25, ptr %l4
  %t26 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 6
  %t27 = load i1, ptr %t26, !tbaa !21
  store i1 %t27, ptr %l5, !tbaa !21
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load i32, ptr %l3, !tbaa !23
  %t33 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t29, i32 %t30)
  store i32 %t33, ptr %l21
  br label %bb6
bb6:
  %t34 = load i32, ptr %l21, !tbaa !23
  store i32 %t34, ptr %l6, !tbaa !23
  %t35 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 0
  %t36 = load i32, ptr %t35, !range !{i32 0, i32 5}
  %t38 = trunc i64 1 to i32
  %t39 = icmp eq i32 %t36, %t38
  br i1 %t39, label %bb7, label %bb8
bb7:
  %t41 = load i32, ptr %l6, !tbaa !23
  %t42 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t45 = icmp eq i32 %t41, %t42
  store i1 %t45, ptr %l24, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb9
bb9:
  %t47 = load i1, ptr %l24, !tbaa !21
  br i1 %t47, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l28, !tbaa !29
  %t49 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t49, ptr %l29
  %t50 = load i32, ptr %l3, !tbaa !23
  store i32 %t50, ptr %l30, !tbaa !23
  %t51 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 1
  %t52 = load i64, ptr %t51, !tbaa !24
  %t54 = icmp ne i64 %t52, 0
  br i1 %t54, label %bb12, label %bb13
bb11:
  br label %bb16
bb12:
  store i64 1, ptr %l33, !tbaa !24
  br label %bb14
bb13:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb14
bb14:
  %t56 = load ptr, ptr %l28, !tbaa !29
  %t57 = load %"compiler/source:Span", ptr %l29
  %t58 = load i32, ptr %l30, !tbaa !23
  %t59 = load i64, ptr %l33, !tbaa !24
  %t60 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v1, ptr %t56, %"compiler/source:Span" %t57, i32 %t58, i64 %t59)
  store ptr %t60, ptr %l34
  br label %bb15
bb15:
  %t61 = load ptr, ptr %l34, !tbaa !29
  store ptr %t61, ptr %rv
  br label %ret
bb16:
  %t63 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 0
  %t64 = load i32, ptr %t63, !range !{i32 0, i32 5}
  %t66 = trunc i64 2 to i32
  %t67 = icmp eq i32 %t64, %t66
  br i1 %t67, label %bb17, label %bb18
bb17:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/check:Checker", ptr %t69, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t74 = getelementptr %"compiler/generic:Program", ptr %t72, i32 0, i32 2
  %t75 = load i32, ptr %l6, !tbaa !23
  %t78 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t74, i32 %t75)
  store i1 %t78, ptr %l43
  br label %bb19
bb18:
  store i1 false, ptr %l38, !tbaa !21
  br label %bb20
bb19:
  %t79 = load i1, ptr %l43, !tbaa !21
  store i1 %t79, ptr %l38, !tbaa !21
  br label %bb20
bb20:
  %t80 = load i1, ptr %l38, !tbaa !21
  br i1 %t80, label %bb21, label %bb22
bb21:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load %"compiler/source:Span", ptr %l1
  %t83 = load i32, ptr %l3, !tbaa !23
  %t84 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 1
  %t85 = load i64, ptr %t84, !tbaa !24
  %t90 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v1, ptr %t81, %"compiler/source:Span" %t82, i32 %t83, i64 %t85)
  store ptr %t90, ptr %l48
  br label %bb23
bb22:
  br label %bb24
bb23:
  %t91 = load ptr, ptr %l48, !tbaa !29
  store ptr %t91, ptr %rv
  br label %ret
bb24:
  %t93 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 0
  %t94 = load i32, ptr %t93, !range !{i32 0, i32 5}
  %t96 = trunc i64 2 to i32
  %t97 = icmp eq i32 %t94, %t96
  br i1 %t97, label %bb25, label %bb26
bb25:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/check:Checker", ptr %t99, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t104 = getelementptr %"compiler/generic:Program", ptr %t102, i32 0, i32 2
  %t105 = load i32, ptr %l6, !tbaa !23
  %t108 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t104, i32 %t105)
  store i1 %t108, ptr %l57
  br label %bb27
bb26:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb28
bb27:
  %t109 = load i1, ptr %l57, !tbaa !21
  store i1 %t109, ptr %l52, !tbaa !21
  br label %bb28
bb28:
  %t110 = load i1, ptr %l52, !tbaa !21
  br i1 %t110, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s4
  %t111 = load ptr, ptr %l0, !tbaa !29
  store ptr %t111, ptr %l58, !tbaa !29
  %t112 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t112, ptr %l59
  %t113 = load i32, ptr %l3, !tbaa !23
  store i32 %t113, ptr %l60, !tbaa !23
  %t114 = load i32, ptr %l6, !tbaa !23
  store i32 %t114, ptr %l61, !tbaa !23
  %t115 = load i1, ptr %l5, !tbaa !21
  %t116 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 1
  %t117 = load i64, ptr %t116, !tbaa !24
  %t120 = call %"compiler/check:litv" @compiler_2fcheck_3alitv_2ector(ptr %s4, i1 true, i1 false, i1 %t115, i64 %t117, double 0x0000000000000000)
  store %"compiler/check:litv" %t120, ptr %l64
  br label %bb31
bb30:
  br label %bb34
bb31:
  %t121 = load i32, ptr %l61, !tbaa !23
  %t122 = load %"compiler/check:litv", ptr %l64
  %t123 = call i64 @compiler_2fcheck_2eintFloatBits(i32 %t121, %"compiler/check:litv" %t122)
  store i64 %t123, ptr %l65
  br label %bb32
bb32:
  %t124 = load ptr, ptr %l58, !tbaa !29
  %t125 = load %"compiler/source:Span", ptr %l59
  %t126 = load i32, ptr %l60, !tbaa !23
  %t127 = load i64, ptr %l65, !tbaa !24
  %t128 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v1, ptr %t124, %"compiler/source:Span" %t125, i32 %t126, i64 %t127)
  store ptr %t128, ptr %l66
  br label %bb33
bb33:
  %t129 = load ptr, ptr %l66, !tbaa !29
  call void @__olang_scope_close(ptr %s4)
  store ptr %t129, ptr %rv
  br label %ret
bb34:
  %t131 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 0
  %t132 = load i32, ptr %t131, !range !{i32 0, i32 5}
  %t134 = trunc i64 3 to i32
  %t135 = icmp eq i32 %t132, %t134
  br i1 %t135, label %bb35, label %bb36
bb35:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"compiler/check:Checker", ptr %t137, i32 0, i32 1
  %t140 = load ptr, ptr %t139, !tbaa !29
  %t142 = getelementptr %"compiler/generic:Program", ptr %t140, i32 0, i32 2
  %t143 = load i32, ptr %l6, !tbaa !23
  %t146 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t142, i32 %t143)
  store i1 %t146, ptr %l75
  br label %bb37
bb36:
  store i1 false, ptr %l70, !tbaa !21
  br label %bb38
bb37:
  %t147 = load i1, ptr %l75, !tbaa !21
  store i1 %t147, ptr %l70, !tbaa !21
  br label %bb38
bb38:
  %t148 = load i1, ptr %l70, !tbaa !21
  br i1 %t148, label %bb39, label %bb40
bb39:
  %t149 = load ptr, ptr %l0, !tbaa !29
  store ptr %t149, ptr %l76, !tbaa !29
  %t150 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t150, ptr %l77
  %t151 = load i32, ptr %l3, !tbaa !23
  store i32 %t151, ptr %l78, !tbaa !23
  %t152 = load i32, ptr %l6, !tbaa !23
  %t153 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 2
  %t154 = load double, ptr %t153, !tbaa !26
  %t157 = call i64 @compiler_2fcheck_2efloatBits(i32 %t152, double %t154)
  store i64 %t157, ptr %l81
  br label %bb41
bb40:
  br label %bb43
bb41:
  %t158 = load ptr, ptr %l76, !tbaa !29
  %t159 = load %"compiler/source:Span", ptr %l77
  %t160 = load i32, ptr %l78, !tbaa !23
  %t161 = load i64, ptr %l81, !tbaa !24
  %t162 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v1, ptr %t158, %"compiler/source:Span" %t159, i32 %t160, i64 %t161)
  store ptr %t162, ptr %l82
  br label %bb42
bb42:
  %t163 = load ptr, ptr %l82, !tbaa !29
  store ptr %t163, ptr %rv
  br label %ret
bb43:
  %t165 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 0
  %t166 = load i32, ptr %t165, !range !{i32 0, i32 5}
  %t168 = trunc i64 4 to i32
  %t169 = icmp eq i32 %t166, %t168
  br i1 %t169, label %bb44, label %bb45
bb44:
  %t171 = load i32, ptr %l3, !tbaa !23
  store i32 %t171, ptr %l87, !tbaa !23
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t174 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t172)
  store i32 %t174, ptr %l89
  br label %bb46
bb45:
  store i1 false, ptr %l86, !tbaa !21
  br label %bb47
bb46:
  %t175 = load i32, ptr %l87, !tbaa !23
  %t176 = load i32, ptr %l89, !tbaa !23
  %t177 = icmp eq i32 %t175, %t176
  store i1 %t177, ptr %l86, !tbaa !21
  br label %bb47
bb47:
  %t179 = load i1, ptr %l86, !tbaa !21
  br i1 %t179, label %bb48, label %bb49
bb48:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t181 = load %"compiler/source:Span", ptr %l1
  %t182 = load i32, ptr %l2, !tbaa !23
  %t186 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuildConst(ptr %v0, ptr %v1, ptr %t180, %"compiler/source:Span" %t181, i32 %t182)
  store ptr %t186, ptr %l94
  br label %bb50
bb49:
  br label %bb51
bb50:
  %t187 = load ptr, ptr %l94, !tbaa !29
  store ptr %t187, ptr %rv
  br label %ret
bb51:
  store ptr null, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edestructs(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i32
  %l12 = alloca i1
  %l13 = alloca i1
  %l18 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l5, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t11 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t7, i32 %a1)
  store i32 %t11, ptr %l8
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l5, !tbaa !29
  %t13 = load i32, ptr %l8, !tbaa !23
  %t14 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t14, ptr %l9
  br label %bb2
bb2:
  %t15 = load i32, ptr %l9, !tbaa !23
  store i32 %t15, ptr %l2, !tbaa !23
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l2, !tbaa !23
  %t20 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %t16, i32 %t17)
  store i1 %t20, ptr %l12
  br label %bb3
bb3:
  %t21 = load i1, ptr %l12, !tbaa !21
  br i1 %t21, label %bb4, label %bb5
bb4:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 2
  %t28 = load i32, ptr %l2, !tbaa !23
  %t31 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %t27, i32 %t28)
  store i1 %t31, ptr %l18
  br label %bb6
bb5:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb7
bb6:
  %t32 = load i1, ptr %l18, !tbaa !21
  store i1 %t32, ptr %l13, !tbaa !21
  br label %bb7
bb7:
  %t33 = load i1, ptr %l13, !tbaa !21
  store i1 %t33, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ediscardOr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i1
  %l12 = alloca { i64, ptr }
  %l13 = alloca i1
  %l18 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l25 = alloca %"compiler/source:Span"
  %s1 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 28}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb11
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l2, !tbaa !23
  %t20 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t16, i32 %t17)
  store { i64, ptr } %t20, ptr %l12
  br label %bb6
bb6:
  %t21 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t22 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t21, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d10, i32 0, i32 1) })
  store i1 %t22, ptr %l13
  br label %bb7
bb7:
  %t23 = load i1, ptr %l13, !tbaa !21
  br i1 %t23, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s1)
  store ptr null, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s1)
  br label %bb16
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_eaffdf15d9c064d4_e1a7ee300abdca20)
  unreachable
bb16:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/check:Checker", ptr %t25, i32 0, i32 11
  store i1 true, ptr %t27, !tbaa !21
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t32 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplace(ptr %v0, ptr %v1, ptr %v2, ptr %t28, ptr %t29)
  store ptr %t32, ptr %l18
  br label %bb17
bb17:
  %t33 = load ptr, ptr %l18, !tbaa !29
  store ptr %t33, ptr %l3, !tbaa !29
  %t34 = load ptr, ptr %l3, !tbaa !29
  %t36 = icmp eq ptr %t34, null
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb18, label %bb19
bb18:
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l22, !tbaa !29
  %t41 = load ptr, ptr %l3, !tbaa !29
  store ptr %t41, ptr %l23, !tbaa !29
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t44 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t42)
  store %"compiler/source:Span" %t44, ptr %l25
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t45 = load ptr, ptr %l22, !tbaa !29
  %t46 = load ptr, ptr %l23, !tbaa !29
  %t47 = load %"compiler/source:Span", ptr %l25
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotCapture(ptr %v0, ptr %v2, ptr %t45, ptr %t46, %"compiler/source:Span" %t47)
  br label %bb21
bb21:
  br label %bb22
bb22:
  %t48 = load ptr, ptr %l3, !tbaa !29
  store ptr %t48, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeqShaped(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l9 = alloca ptr
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca { i64, ptr }
  %l19 = alloca i1
  %l22 = alloca ptr
  %l24 = alloca { i64, ptr }
  %l26 = alloca i32
  %l27 = alloca i32
  %l30 = alloca i1
  %l33 = alloca ptr
  %l36 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l40 = alloca i32
  %l41 = alloca i32
  %l46 = alloca i32
  %l47 = alloca i1
  %l48 = alloca i1
  %l51 = alloca ptr
  %l53 = alloca { i64, ptr }
  %l55 = alloca i32
  %l56 = alloca i32
  %l61 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l6, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  store ptr %t12, ptr %l9, !tbaa !29
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t20 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t16, i64 %a2)
  store i32 %t20, ptr %l13
  br label %bb1
bb1:
  %t21 = load ptr, ptr %l9, !tbaa !29
  %t22 = load i32, ptr %l13, !tbaa !23
  %t23 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t23, ptr %l14
  br label %bb2
bb2:
  %t24 = load ptr, ptr %l6, !tbaa !29
  %t25 = load i32, ptr %l14, !tbaa !23
  %t26 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t24, i32 %t25)
  store { i64, ptr } %t26, ptr %l15
  br label %bb3
bb3:
  %t27 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t27, ptr %l3, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  %t32 = icmp eq i64 %t30, 2
  br i1 %t32, label %bb4, label %bb5
bb4:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/generic:Program", ptr %t37, i32 0, i32 2
  store ptr %t39, ptr %l22, !tbaa !29
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t41, ptr %l24, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr i32, ptr %t43, i64 1
  %t45 = load i32, ptr %t44, !tbaa !33
  %t48 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t40, i32 %t45)
  store i32 %t48, ptr %l26
  br label %bb6
bb5:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb21
bb6:
  %t49 = load ptr, ptr %l22, !tbaa !29
  %t50 = load i32, ptr %l26, !tbaa !23
  %t51 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t49, i32 %t50)
  store i32 %t51, ptr %l27
  br label %bb7
bb7:
  %t52 = load i32, ptr %l27, !range !{i32 0, i32 33}
  %t54 = trunc i64 25 to i32
  %t55 = icmp eq i32 %t52, %t54
  br i1 %t55, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb14
bb9:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = getelementptr %"compiler/generic:Program", ptr %t60, i32 0, i32 2
  store ptr %t62, ptr %l33, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = getelementptr %"compiler/generic:Program", ptr %t66, i32 0, i32 2
  store ptr %t68, ptr %l36, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t70, ptr %l38, !tbaa !27
  %t71 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr i32, ptr %t72, i64 1
  %t74 = load i32, ptr %t73, !tbaa !33
  %t77 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t69, i32 %t74)
  store i32 %t77, ptr %l40
  br label %bb10
bb10:
  %t78 = load ptr, ptr %l36, !tbaa !29
  %t79 = load i32, ptr %l40, !tbaa !23
  %t80 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t78, i32 %t79)
  store i32 %t80, ptr %l41
  br label %bb11
bb11:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/check:Checker", ptr %t81, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t86 = getelementptr %"compiler/generic:Program", ptr %t84, i32 0, i32 2
  %t87 = load i32, ptr %l1, !tbaa !23
  %t90 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t86, i32 %t87)
  store i32 %t90, ptr %l46
  br label %bb12
bb12:
  %t91 = load ptr, ptr %l33, !tbaa !29
  %t92 = load i32, ptr %l41, !tbaa !23
  %t93 = load i32, ptr %l46, !tbaa !23
  %t94 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t91, i32 %t92, i32 %t93)
  store i1 %t94, ptr %l47
  br label %bb13
bb13:
  %t95 = load i1, ptr %l47, !tbaa !21
  store i1 %t95, ptr %l30, !tbaa !21
  br label %bb14
bb14:
  %t96 = load i1, ptr %l30, !tbaa !21
  br i1 %t96, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb20
bb16:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/check:Checker", ptr %t97, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = getelementptr %"compiler/generic:Program", ptr %t100, i32 0, i32 2
  store ptr %t102, ptr %l51, !tbaa !29
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t104, ptr %l53, !tbaa !27
  %t105 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !27
  %t107 = getelementptr i32, ptr %t106, i64 1
  %t108 = load i32, ptr %t107, !tbaa !33
  %t111 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t103, i32 %t108)
  store i32 %t111, ptr %l55
  br label %bb17
bb17:
  %t112 = load ptr, ptr %l51, !tbaa !29
  %t113 = load i32, ptr %l55, !tbaa !23
  %t114 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t112, i32 %t113)
  store i32 %t114, ptr %l56
  br label %bb18
bb18:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/check:Checker", ptr %t115, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t120 = getelementptr %"compiler/generic:Program", ptr %t118, i32 0, i32 2
  %t121 = load i32, ptr %l1, !tbaa !23
  %t124 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t120, i32 %t121)
  store i32 %t124, ptr %l61
  br label %bb19
bb19:
  %t125 = load i32, ptr %l56, !tbaa !23
  %t126 = load i32, ptr %l61, !tbaa !23
  %t127 = icmp eq i32 %t125, %t126
  store i1 %t127, ptr %l48, !tbaa !21
  br label %bb20
bb20:
  %t129 = load i1, ptr %l48, !tbaa !21
  store i1 %t129, ptr %l19, !tbaa !21
  br label %bb21
bb21:
  %t130 = load i1, ptr %l19, !tbaa !21
  store i1 %t130, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrsCover(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l11 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l24 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t6, i32 %a2)
  store { i64, ptr } %t10, ptr %l11
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t11, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  store i64 %t14, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t16 = load i64, ptr %l4, !tbaa !24
  %t17 = load i64, ptr %l5, !tbaa !24
  %t20 = icmp slt i64 %t16, %t17
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t24 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t24, ptr %l18, !tbaa !27
  %t25 = load i64, ptr %l4, !tbaa !24
  %t27 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i32, ptr %t28, i64 %t25
  %t30 = load i32, ptr %t29, !tbaa !33
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t38 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euncovered(ptr %v0, ptr %t32, i32 %a1, i32 %t30)
  store i32 %t38, ptr %l24
  br label %bb6
bb6:
  %t39 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t40 = load i32, ptr %l24, !tbaa !23
  %t42 = icmp ne i32 %t40, %t39
  br i1 %t42, label %bb7, label %bb8
bb7:
  store i1 false, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t45 = load i64, ptr %l4, !tbaa !24
  %t47 = add i64 %t45, 1
  store i64 %t47, ptr %l4, !tbaa !24
  br label %bb2
bb11:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efitsTest(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i64
  %lp6 = alloca ptr
  %l7 = alloca i64
  %lp8 = alloca ptr
  %l9 = alloca i64
  %lp10 = alloca ptr
  %l13 = alloca i32
  %l16 = alloca i32
  %l19 = alloca i32
  %l21 = alloca i1
  %l25 = alloca { i64, ptr }
  %l31 = alloca ptr
  %l34 = alloca i64
  %l38 = alloca %"compiler/source:Span"
  %l39 = alloca i32
  %l40 = alloca i32
  %l41 = alloca i32
  %l45 = alloca { i64, ptr }
  %l49 = alloca i64
  %l56 = alloca %"compiler/source:Span"
  %l57 = alloca i32
  %l61 = alloca { i64, ptr }
  %l65 = alloca ptr
  %l67 = alloca %"compiler/typed:Seq"
  %l72 = alloca i64
  %l74 = alloca ptr
  %l78 = alloca ptr
  %l79 = alloca %"compiler/source:Span"
  %l80 = alloca i64
  %l84 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %l89 = alloca %"compiler/typed:Clause"
  %l90 = alloca %"compiler/source:Span"
  %l91 = alloca i32
  %l94 = alloca { i64, ptr }
  %l95 = alloca %"compiler/typed:Try"
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  %t62 = alloca { i64, [5 x i64] }, align 8
  %t90 = alloca { i64, [3 x i64] }, align 8
  %t124 = alloca { i64, [5 x i64] }, align 8
  %t201 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t1)
  store i32 %t4, ptr %l13
  br label %bb1
bb1:
  %t5 = load i32, ptr %l13, !tbaa !23
  store i32 %t5, ptr %l4, !tbaa !23
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr %l4, !tbaa !23
  %t10 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l16
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr %l3, !tbaa !23
  %t15 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t11, i32 %t12)
  store i32 %t15, ptr %l19
  br label %bb3
bb3:
  %t16 = load i32, ptr %l16, !tbaa !23
  %t17 = load i32, ptr %l19, !tbaa !23
  %t18 = icmp eq i32 %t16, %t17
  br i1 %t18, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb7
bb5:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i32, ptr %l4, !tbaa !23
  %t22 = load i32, ptr %l3, !tbaa !23
  %t26 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvWords(ptr %v0, ptr %s0, ptr %t20, i32 %t21, i32 %t22)
  store { i64, ptr } %t26, ptr %l25
  br label %bb6
bb6:
  %t27 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t27, 0
  %t30 = icmp eq i64 %t28, 0
  store i1 %t30, ptr %l21, !tbaa !21
  br label %bb7
bb7:
  %t32 = load i1, ptr %l21, !tbaa !21
  br i1 %t32, label %bb8, label %bb9
bb8:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load %"compiler/source:Span", ptr %l1
  %t35 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t39 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v2, ptr %t33, %"compiler/source:Span" %t34, i32 %t35, i64 1)
  store ptr %t39, ptr %l31
  br label %bb10
bb9:
  br label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t40 = load ptr, ptr %l31, !tbaa !29
  store ptr %t40, ptr %rv
  br label %ret
bb11:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/check:Checker", ptr %t41, i32 0, i32 44
  %t45 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t43)
  store i64 %t45, ptr %l34
  br label %bb12
bb12:
  %t46 = load i64, ptr %l34, !tbaa !24
  store i64 %t46, ptr %l5, !tbaa !24
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/check:Checker", ptr %t47, i32 0, i32 44
  %t50 = load ptr, ptr %l2, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %t49, ptr %t50)
  br label %bb13
bb13:
  %t53 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t53, ptr %l38
  %t54 = load i32, ptr %l3, !tbaa !23
  store i32 %t54, ptr %l39, !tbaa !23
  store i32 20, ptr %l40
  store i32 2, ptr %l41
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/check:Checker", ptr %t55, i32 0, i32 44
  %t58 = load i64, ptr %l5, !tbaa !24
  %t61 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v2, ptr %t57, i64 %t58)
  store { i64, ptr } %t61, ptr %l45
  br label %bb14
bb14:
  store { i64, [5 x i64] } zeroinitializer, ptr %t62
  %t63 = getelementptr { i64, [5 x i64] }, ptr %t62, i32 0, i32 0
  store i64 9, ptr %t63
  %t64 = load %"compiler/source:Span", ptr %l38
  %t65 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } undef, %"compiler/source:Span" %t64, 0
  %t66 = load i32, ptr %l39, !tbaa !23
  %t67 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t65, i32 %t66, 1
  %t68 = load i32, ptr %l40, !range !{i32 0, i32 52}
  %t69 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t67, i32 %t68, 2
  %t70 = load i32, ptr %l41, !range !{i32 0, i32 4}
  %t71 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t69, i32 %t70, 3
  %t72 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t73 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t71, { i64, ptr } %t72, 4
  %t74 = getelementptr { i64, [5 x i64] }, ptr %t62, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t73, ptr %t74
  %t75 = load { i64, [5 x i64] }, ptr %t62
  %t76 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store ptr %t76, ptr %lp6
  %t78 = load ptr, ptr %lp6
  store { i64, [5 x i64] } %t75, ptr %t78
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/check:Checker", ptr %t79, i32 0, i32 45
  %t83 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t81)
  store i64 %t83, ptr %l49
  br label %bb15
bb15:
  %t84 = load i64, ptr %l49, !tbaa !24
  store i64 %t84, ptr %l7, !tbaa !24
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/check:Checker", ptr %t85, i32 0, i32 45
  %t88 = load %"compiler/source:Span", ptr %l1
  %t89 = load ptr, ptr %lp6
  store { i64, [3 x i64] } zeroinitializer, ptr %t90
  %t91 = getelementptr { i64, [3 x i64] }, ptr %t90, i32 0, i32 0
  store i64 2, ptr %t91
  %t93 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t88, 0
  %t95 = insertvalue { %"compiler/source:Span", ptr } %t93, ptr %t89, 1
  %t96 = getelementptr { i64, [3 x i64] }, ptr %t90, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t95, ptr %t96
  %t97 = load { i64, [3 x i64] }, ptr %t90
  %t99 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t97, ptr %t99
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t87, ptr %t99)
  br label %bb16
bb16:
  %t102 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t102, ptr %l56
  %t103 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t103, ptr %l57, !tbaa !23
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/check:Checker", ptr %t104, i32 0, i32 45
  %t107 = load i64, ptr %l7, !tbaa !24
  %t110 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t106, i64 %t107)
  store { i64, ptr } %t110, ptr %l61
  br label %bb17
bb17:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = load %"compiler/source:Span", ptr %l1
  %t113 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t117 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v2, ptr %t111, %"compiler/source:Span" %t112, i32 %t113, i64 1)
  store ptr %t117, ptr %l65
  br label %bb18
bb18:
  %t118 = load ptr, ptr %l65, !tbaa !29
  %t119 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t121 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v2, ptr %v2, { i64, ptr } %t119, ptr %t118, i1 false)
  store %"compiler/typed:Seq" %t121, ptr %l67
  br label %bb19
bb19:
  %t122 = load %"compiler/typed:Seq", ptr %l67
  %t123 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store %"compiler/typed:Seq" %t122, ptr %t123
  store { i64, [5 x i64] } zeroinitializer, ptr %t124
  %t125 = getelementptr { i64, [5 x i64] }, ptr %t124, i32 0, i32 0
  store i64 12, ptr %t125
  %t126 = load %"compiler/source:Span", ptr %l56
  %t127 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t126, 0
  %t128 = load i32, ptr %l57, !tbaa !23
  %t129 = insertvalue { %"compiler/source:Span", i32, ptr } %t127, i32 %t128, 1
  %t131 = insertvalue { %"compiler/source:Span", i32, ptr } %t129, ptr %t123, 2
  %t132 = getelementptr { i64, [5 x i64] }, ptr %t124, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t131, ptr %t132
  %t133 = load { i64, [5 x i64] }, ptr %t124
  %t134 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store ptr %t134, ptr %lp8
  %t136 = load ptr, ptr %lp8
  store { i64, [5 x i64] } %t133, ptr %t136
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"compiler/check:Checker", ptr %t137, i32 0, i32 44
  %t141 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t139)
  store i64 %t141, ptr %l72
  br label %bb20
bb20:
  %t142 = load i64, ptr %l72, !tbaa !24
  store i64 %t142, ptr %l9, !tbaa !24
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/check:Checker", ptr %t143, i32 0, i32 44
  store ptr %t145, ptr %l74, !tbaa !29
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load %"compiler/source:Span", ptr %l1
  %t148 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t152 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t146, %"compiler/source:Span" %t147, i32 %t148, i64 0)
  store ptr %t152, ptr %l78
  br label %bb21
bb21:
  %t153 = load ptr, ptr %l74, !tbaa !29
  %t154 = load ptr, ptr %l78, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t153, ptr %t154)
  br label %bb22
bb22:
  %t155 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t155, ptr %l79
  %t156 = ptrtoint ptr %v2 to i64
  store i64 %t156, ptr %l80, !tbaa !24
  %t157 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aClause_2e1
  br i1 %t157, label %bb23, label %bb24
bb23:
  %t159 = call ptr @__olang_region_make(ptr %v2)
  %t160 = ptrtoint ptr %t159 to i64
  store i64 %t160, ptr %l80, !tbaa !24
  br label %bb24
bb24:
  %t161 = icmp sge i64 0, 0
  br i1 %t161, label %bb25, label %bb26
bb25:
  %t163 = icmp sle i64 0, 576460752303423487
  br i1 %t163, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_ce45aa27b33b13c4_efb6d2bad65aad00)
  unreachable
bb27:
  %t165 = mul i64 0, 16
  %t166 = load i64, ptr %l80
  %t167 = inttoptr i64 %t166 to ptr
  %t168 = insertvalue { i64, ptr } undef, i64 0, 0
  %t169 = insertvalue { i64, ptr } %t168, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t169, ptr %l84, !tbaa !27
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/check:Checker", ptr %t170, i32 0, i32 44
  %t173 = load i64, ptr %l9, !tbaa !24
  %t176 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t172, i64 %t173)
  store { i64, ptr } %t176, ptr %l88
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_ce45aa27b33b13c4_efb6d2bad65aad00)
  unreachable
bb29:
  %t177 = load %"compiler/source:Span", ptr %l79
  %t178 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t179 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t180 = call %"compiler/typed:Clause" @compiler_2ftyped_3aClause_2ector(ptr %v2, ptr %v2, ptr %v0, ptr %v2, %"compiler/source:Span" %t177, { i64, ptr } %t178, i1 true, ptr null, { i64, ptr } %t179, i64 -1, i32 0)
  store %"compiler/typed:Clause" %t180, ptr %l89
  br label %bb30
bb30:
  %t181 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 72, i64 8)
  store ptr %t181, ptr %lp10
  %t182 = load %"compiler/typed:Clause", ptr %l89
  %t183 = load ptr, ptr %lp10
  store %"compiler/typed:Clause" %t182, ptr %t183
  %t184 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t184, ptr %l90
  %t185 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t185, ptr %l91, !tbaa !23
  %t186 = load ptr, ptr %lp8
  %t187 = load ptr, ptr %lp10
  %t188 = mul i64 1, 8
  %t189 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t188)
  %t190 = insertvalue { i64, ptr } undef, i64 1, 0
  %t191 = insertvalue { i64, ptr } %t190, ptr %t189, 1
  store { i64, ptr } %t191, ptr %l94, !tbaa !27
  %t193 = getelementptr { i64, ptr }, ptr %l94, i32 0, i32 1
  %t194 = load ptr, ptr %t193, !tbaa !27
  %t195 = getelementptr ptr, ptr %t194, i64 0
  store ptr %t187, ptr %t195, !tbaa !39
  %t197 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t198 = call %"compiler/typed:Try" @compiler_2ftyped_3aTry_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %t186, { i64, ptr } %t197, i1 false, i1 false, i1 true)
  store %"compiler/typed:Try" %t198, ptr %l95
  br label %bb31
bb31:
  %t199 = load %"compiler/typed:Try", ptr %l95
  %t200 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store %"compiler/typed:Try" %t199, ptr %t200
  store { i64, [5 x i64] } zeroinitializer, ptr %t201
  %t202 = getelementptr { i64, [5 x i64] }, ptr %t201, i32 0, i32 0
  store i64 14, ptr %t202
  %t203 = load %"compiler/source:Span", ptr %l90
  %t204 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t203, 0
  %t205 = load i32, ptr %l91, !tbaa !23
  %t206 = insertvalue { %"compiler/source:Span", i32, ptr } %t204, i32 %t205, 1
  %t208 = insertvalue { %"compiler/source:Span", i32, ptr } %t206, ptr %t200, 2
  %t209 = getelementptr { i64, [5 x i64] }, ptr %t201, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t208, ptr %t209
  %t210 = load { i64, [5 x i64] }, ptr %t201
  %t212 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t210, ptr %t212
  call void @__olang_scope_close(ptr %s0)
  store ptr %t212, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenMarks(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, { i64, ptr } %a3, i64 %a4, i64 %a5, i1 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca i1
  %l9 = alloca i32
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca ptr
  %l13 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca i1
  %l24 = alloca ptr
  %l30 = alloca i32
  %l31 = alloca i32
  %l38 = alloca i1
  %l39 = alloca i1
  %l42 = alloca i1
  %l48 = alloca i32
  %l59 = alloca i1
  %l62 = alloca ptr
  %l63 = alloca i64
  %l64 = alloca ptr
  %l67 = alloca %"compiler/source:Span"
  %l68 = alloca { i64, [3 x i64] }
  %l69 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l75 = alloca i32
  %l76 = alloca i64
  %l77 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %l80 = alloca i64
  %l81 = alloca { i64, ptr }
  %l85 = alloca i1
  %l89 = alloca ptr
  %l90 = alloca i64
  %l92 = alloca i1
  %l93 = alloca { i64, ptr }
  %l100 = alloca i1
  %l111 = alloca ptr
  %l112 = alloca ptr
  %l115 = alloca %"compiler/source:Span"
  %l116 = alloca { i64, [3 x i64] }
  %l120 = alloca %"compiler/check:weakPlace"
  %l122 = alloca %"compiler/check:weakPlace"
  %l123 = alloca ptr
  %l124 = alloca i1
  %l136 = alloca ptr
  %l137 = alloca i1
  %l145 = alloca i32
  %l148 = alloca i1
  %l149 = alloca i1
  %l152 = alloca i1
  %l153 = alloca ptr
  %l158 = alloca i32
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store i64 %a4, ptr %l4
  store i64 %a5, ptr %l5
  store i1 %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l2, !tbaa !29
  store ptr %t5, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t6 = load ptr, ptr %l16, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l16, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 8}
  %t12 = icmp eq i64 %t10, 3
  store i1 %t12, ptr %l17, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l17, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l2, !tbaa !29
  %t16 = getelementptr { i64, [5 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t16, i32 0, i32 1
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l7, !tbaa !29
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t22 = getelementptr { i64, [5 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t22, i32 0, i32 3
  %t24 = load i1, ptr %t23
  store i1 %t24, ptr %l8, !tbaa !21
  br label %bb8
bb7:
  br label %bb60
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l24, !tbaa !29
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/check:Checker", ptr %t27, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t32 = load ptr, ptr %l7, !tbaa !29
  %t37 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v1, ptr %v2, ptr %t30, ptr %t31, ptr %t32)
  store i32 %t37, ptr %l30
  br label %bb9
bb9:
  %t38 = load ptr, ptr %l24, !tbaa !29
  %t39 = load i32, ptr %l30, !tbaa !23
  %t40 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t40, ptr %l31
  br label %bb10
bb10:
  %t41 = load i32, ptr %l31, !tbaa !23
  store i32 %t41, ptr %l9, !tbaa !23
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t44 = load ptr, ptr %l7, !tbaa !29
  %t45 = load { i64, ptr }, ptr %l3, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenArgs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t42, ptr %t43, ptr %t44, { i64, ptr } %t45)
  br label %bb11
bb11:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load i32, ptr %l9, !tbaa !23
  %t54 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %t50, i32 %t51)
  store i1 %t54, ptr %l38
  br label %bb12
bb12:
  %t55 = load i1, ptr %l38, !tbaa !21
  br i1 %t55, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb16
bb14:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load i32, ptr %l9, !tbaa !23
  %t60 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t56, i32 %t57)
  store i1 %t60, ptr %l42
  br label %bb15
bb15:
  %t61 = load i1, ptr %l42, !tbaa !21
  store i1 %t61, ptr %l39, !tbaa !21
  br label %bb16
bb16:
  %t62 = load i1, ptr %l39, !tbaa !21
  %t63 = xor i1 %t62, true
  br i1 %t63, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb18:
  br label %bb19
bb19:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/check:Checker", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t70 = getelementptr %"compiler/generic:Program", ptr %t68, i32 0, i32 2
  %t71 = load i32, ptr %l9, !tbaa !23
  %t74 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t70, i32 %t71)
  store i32 %t74, ptr %l48
  br label %bb20
bb20:
  %t75 = load i32, ptr %l48, !tbaa !23
  %t76 = sext i32 %t75 to i64
  store i64 %t76, ptr %l10, !tbaa !24
  %t78 = load i1, ptr %l8, !tbaa !21
  %t80 = xor i1 %t78, true
  br i1 %t80, label %bb21, label %bb22
bb21:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load i64, ptr %l10, !tbaa !24
  %t84 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t85 = load i1, ptr %l6, !tbaa !21
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenHolds(ptr %v0, ptr %v3, ptr %t82, i64 %t83, { i64, ptr } %t84, i1 %t85)
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb24:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/check:Checker", ptr %t90, i32 0, i32 109
  %t93 = load i64, ptr %l10, !tbaa !24
  %t96 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fdiag_3aWhere_3e_2e_Had7920a3eff3220b2e12299d961f9124(ptr %v0, ptr %t92, i64 %t93)
  store i1 %t96, ptr %l59
  br label %bb25
bb25:
  %t97 = load i1, ptr %l59, !tbaa !21
  %t98 = xor i1 %t97, true
  br i1 %t98, label %bb26, label %bb27
bb26:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/check:Checker", ptr %t100, i32 0, i32 109
  store ptr %t102, ptr %l62, !tbaa !29
  %t103 = load i64, ptr %l10, !tbaa !24
  store i64 %t103, ptr %l63, !tbaa !24
  %t104 = load ptr, ptr %l0, !tbaa !29
  store ptr %t104, ptr %l64, !tbaa !29
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load ptr, ptr %l2, !tbaa !29
  %t109 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eweakWord(ptr %v0, ptr %v2, ptr %t105, ptr %t106)
  store %"compiler/source:Span" %t109, ptr %l67
  br label %bb28
bb27:
  br label %bb31
bb28:
  %t110 = load ptr, ptr %l64, !tbaa !29
  %t111 = load %"compiler/source:Span", ptr %l67
  %t112 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t110, %"compiler/source:Span" %t111)
  store { i64, [3 x i64] } %t112, ptr %l68
  br label %bb29
bb29:
  %t113 = load ptr, ptr %l62, !tbaa !29
  %t114 = load i64, ptr %l63, !tbaa !24
  %t115 = load { i64, [3 x i64] }, ptr %l68
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fdiag_3aWhere_3e_2e_Hc07a7e56a24d8f1225398db99ea19a4b(ptr %v0, ptr %t113, i64 %t114, { i64, [3 x i64] } %t115)
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/check:Checker", ptr %t116, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !29
  %t121 = getelementptr %"compiler/generic:Program", ptr %t119, i32 0, i32 5
  %t122 = load i64, ptr %l10, !tbaa !24
  %t125 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_H243102d099229a8f815a09f79cb8b122(ptr %v0, ptr %s2, ptr %t121, i64 %t122)
  %t126 = extractvalue { i32, { i64, ptr } } %t125, 1
  %t127 = extractvalue { i32, { i64, ptr } } %t125, 0
  store i32 %t127, ptr %l75
  %t128 = icmp ne i32 %t127, 0
  br i1 %t128, label %bb33, label %ok.129, !prof !99
ok.129:
  store { i64, ptr } %t126, ptr %l74
  br label %bb32
bb32:
  %t130 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t130, 0
  store i64 %t131, ptr %l76, !tbaa !24
  %t132 = load i64, ptr %l76, !tbaa !24
  %t133 = mul i64 %t132, 1
  %t134 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t133)
  %t135 = insertvalue { i64, ptr } undef, i64 %t132, 0
  %t136 = insertvalue { i64, ptr } %t135, ptr %t134, 1
  store { i64, ptr } %t136, ptr %l77, !tbaa !27
  %t137 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t140 = load ptr, ptr %t139, !tbaa !27
  %t141 = load i64, ptr %l76, !tbaa !24
  %t142 = mul i64 %t141, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t138, ptr %t140, i64 %t142, i1 false)
  %t143 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t143, ptr %l69, !tbaa !27
  br label %bb35
bb33:
  br label %bb34
bb34:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d11, i32 0, i32 1) }, ptr %l78, !tbaa !27
  %t144 = load { i64, ptr }, ptr %l78, !tbaa !27
  store { i64, ptr } %t144, ptr %l69, !tbaa !27
  br label %bb35
bb35:
  %t146 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t147 = extractvalue { i64, ptr } %t146, 0
  store i64 %t147, ptr %l80, !tbaa !24
  %t148 = load i64, ptr %l80, !tbaa !24
  %t149 = mul i64 %t148, 1
  %t150 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t149)
  %t151 = insertvalue { i64, ptr } undef, i64 %t148, 0
  %t152 = insertvalue { i64, ptr } %t151, ptr %t150, 1
  store { i64, ptr } %t152, ptr %l81, !tbaa !27
  %t153 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !27
  %t155 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t156 = load ptr, ptr %t155, !tbaa !27
  %t157 = load i64, ptr %l80, !tbaa !24
  %t158 = mul i64 %t157, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t154, ptr %t156, i64 %t158, i1 false)
  %t159 = load { i64, ptr }, ptr %l81, !tbaa !27
  store { i64, ptr } %t159, ptr %l11, !tbaa !27
  %t160 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t161 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t165 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %s2, ptr %v3, { i64, ptr } %t160, { i64, ptr } %t161)
  store i1 %t165, ptr %l85
  br label %bb36
bb36:
  %t166 = load i1, ptr %l85, !tbaa !21
  %t167 = xor i1 %t166, true
  br i1 %t167, label %bb37, label %bb38
bb37:
  store %olang.scope zeroinitializer, ptr %s6
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/check:Checker", ptr %t169, i32 0, i32 1
  %t172 = load ptr, ptr %t171, !tbaa !29
  %t174 = getelementptr %"compiler/generic:Program", ptr %t172, i32 0, i32 5
  store ptr %t174, ptr %l89, !tbaa !29
  %t175 = load i64, ptr %l10, !tbaa !24
  store i64 %t175, ptr %l90, !tbaa !24
  %t176 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t178 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s6, { i64, ptr } %t176, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d12, i32 0, i32 1) })
  store i1 %t178, ptr %l92
  br label %bb39
bb38:
  br label %bb44
bb39:
  %t179 = load i1, ptr %l92, !tbaa !21
  br i1 %t179, label %bb40, label %bb41
bb40:
  %t180 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t180, ptr %l93, !tbaa !27
  br label %bb42
bb41:
  %t183 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t184 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t186 = extractvalue { i64, ptr } %t183, 1
  %t187 = extractvalue { i64, ptr } %t183, 0
  %t188 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t189 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t190 = add i64 %t187, %t189
  %t192 = extractvalue { i64, ptr } %t184, 1
  %t193 = extractvalue { i64, ptr } %t184, 0
  %t194 = add i64 %t190, %t193
  %t195 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t194)
  call void @olang_textcopy(ptr %t195, ptr %t186, i64 %t187)
  %t196 = getelementptr i8, ptr %t195, i64 %t187
  call void @olang_textcopy(ptr %t196, ptr %t188, i64 %t189)
  %t197 = getelementptr i8, ptr %t196, i64 %t189
  call void @olang_textcopy(ptr %t197, ptr %t192, i64 %t193)
  %t198 = insertvalue { i64, ptr } undef, i64 %t194, 0
  %t199 = insertvalue { i64, ptr } %t198, ptr %t195, 1
  store { i64, ptr } %t199, ptr %l93, !tbaa !27
  br label %bb42
bb42:
  %t201 = load ptr, ptr %l89, !tbaa !29
  %t202 = load i64, ptr %l90, !tbaa !24
  %t203 = load { i64, ptr }, ptr %l93, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_H7dde68908c71339667eba96ae7e6565c(ptr %v0, ptr %t201, i64 %t202, { i64, ptr } %t203)
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s6)
  br label %bb44
bb44:
  %t204 = load i1, ptr %l6, !tbaa !21
  br i1 %t204, label %bb45, label %bb46
bb45:
  %t206 = load i64, ptr %l4, !tbaa !24
  %t208 = icmp sge i64 %t206, 0
  store i1 %t208, ptr %l100, !tbaa !21
  br label %bb47
bb46:
  store i1 false, ptr %l100, !tbaa !21
  br label %bb47
bb47:
  %t210 = load i1, ptr %l100, !tbaa !21
  br i1 %t210, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s8
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr %"compiler/check:Checker", ptr %t211, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !29
  %t216 = getelementptr %"compiler/generic:Program", ptr %t214, i32 0, i32 7
  %t217 = load i64, ptr %l4, !tbaa !24
  %t218 = load i64, ptr %l5, !tbaa !24
  %t220 = call i64 @__olang_fmt_i64(ptr null, i64 %t217)
  %t221 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t222 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t223 = add i64 %t220, %t222
  %t225 = call i64 @__olang_fmt_i64(ptr null, i64 %t218)
  %t226 = add i64 %t223, %t225
  %t227 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t226)
  %t228 = call i64 @__olang_fmt_i64(ptr %t227, i64 %t217)
  %t229 = getelementptr i8, ptr %t227, i64 %t220
  call void @olang_textcopy(ptr %t229, ptr %t221, i64 %t222)
  %t230 = getelementptr i8, ptr %t229, i64 %t222
  %t231 = call i64 @__olang_fmt_i64(ptr %t230, i64 %t218)
  %t232 = insertvalue { i64, ptr } undef, i64 %t226, 0
  %t233 = insertvalue { i64, ptr } %t232, ptr %t227, 1
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20Boo_H6b1fa5c8028973ecd947936aac3caef3(ptr %v0, ptr %t216, { i64, ptr } %t233, i1 true)
  br label %bb50
bb49:
  br label %bb51
bb50:
  call void @__olang_scope_close(ptr %s8)
  br label %bb51
bb51:
  %t236 = load i1, ptr %l6, !tbaa !21
  br i1 %t236, label %bb52, label %bb53
bb52:
  store %olang.scope zeroinitializer, ptr %s10
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t240 = getelementptr %"compiler/check:Checker", ptr %t238, i32 0, i32 111
  store ptr %t240, ptr %l111, !tbaa !29
  %t241 = load ptr, ptr %l0, !tbaa !29
  store ptr %t241, ptr %l112, !tbaa !29
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t243 = load ptr, ptr %l2, !tbaa !29
  %t246 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eweakWord(ptr %v0, ptr %v2, ptr %t242, ptr %t243)
  store %"compiler/source:Span" %t246, ptr %l115
  br label %bb54
bb53:
  br label %bb59
bb54:
  %t247 = load ptr, ptr %l112, !tbaa !29
  %t248 = load %"compiler/source:Span", ptr %l115
  %t249 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t247, %"compiler/source:Span" %t248)
  store { i64, [3 x i64] } %t249, ptr %l116
  br label %bb55
bb55:
  %t250 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t252 = load i64, ptr %l10, !tbaa !24
  %t253 = load { i64, [3 x i64] }, ptr %l116
  %t256 = call %"compiler/check:weakPlace" @compiler_2fcheck_3aweakPlace_2ector(ptr %s10, { i64, [3 x i64] } %t253, { i64, ptr } %t250, i64 %t252)
  store %"compiler/check:weakPlace" %t256, ptr %l120
  br label %bb56
bb56:
  %t258 = call %"compiler/check:weakPlace" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fcheck_3aweakPlace(ptr %s10, ptr %l120)
  store %"compiler/check:weakPlace" %t258, ptr %l122
  br label %bb57
bb57:
  %t259 = load ptr, ptr %l111, !tbaa !29
  %t260 = load %"compiler/check:weakPlace", ptr %l122
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aweakPlace_3e_2ePush_H297ef57e7eecfa1bdb33767a82738378(ptr %v0, ptr %s10, ptr %t259, %"compiler/check:weakPlace" %t260)
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s10)
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s2)
  br label %bb90
bb60:
  %t261 = load ptr, ptr %l2, !tbaa !29
  store ptr %t261, ptr %l123, !tbaa !29
  store i1 false, ptr %l124, !tbaa !21
  %t262 = load ptr, ptr %l123, !tbaa !29
  %t263 = icmp ne ptr %t262, null
  br i1 %t263, label %bb61, label %bb62
bb61:
  %t265 = load ptr, ptr %l123, !tbaa !29
  %t266 = load i64, ptr %t265, !range !{i64 0, i64 8}
  %t268 = icmp eq i64 %t266, 4
  store i1 %t268, ptr %l124, !tbaa !21
  br label %bb62
bb62:
  %t269 = load i1, ptr %l124, !tbaa !21
  br i1 %t269, label %bb63, label %bb64
bb63:
  %t270 = load ptr, ptr %l2, !tbaa !29
  %t272 = getelementptr { i64, [5 x i64] }, ptr %t270, i32 0, i32 1
  %t273 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t272, i32 0, i32 1
  %t274 = load ptr, ptr %t273
  store ptr %t274, ptr %l12, !tbaa !29
  br label %bb65
bb64:
  br label %bb67
bb65:
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t277 = load ptr, ptr %l1, !tbaa !29
  %t278 = load ptr, ptr %l12, !tbaa !29
  %t279 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t280 = load i64, ptr %l4, !tbaa !24
  %t281 = load i64, ptr %l5, !tbaa !24
  %t282 = load i1, ptr %l6, !tbaa !21
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenMarks(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t276, ptr %t277, ptr %t278, { i64, ptr } %t279, i64 %t280, i64 %t281, i1 %t282)
  br label %bb66
bb66:
  br label %bb90
bb67:
  %t290 = load ptr, ptr %l2, !tbaa !29
  store ptr %t290, ptr %l136, !tbaa !29
  store i1 false, ptr %l137, !tbaa !21
  %t291 = load ptr, ptr %l136, !tbaa !29
  %t292 = icmp ne ptr %t291, null
  br i1 %t292, label %bb68, label %bb69
bb68:
  %t294 = load ptr, ptr %l136, !tbaa !29
  %t295 = load i64, ptr %t294, !range !{i64 0, i64 8}
  %t297 = icmp eq i64 %t295, 0
  store i1 %t297, ptr %l137, !tbaa !21
  br label %bb69
bb69:
  %t298 = load i1, ptr %l137, !tbaa !21
  br i1 %t298, label %bb70, label %bb71
bb70:
  br label %bb72
bb71:
  br label %bb85
bb72:
  %t299 = load ptr, ptr %l0, !tbaa !29
  %t301 = getelementptr %"compiler/check:Checker", ptr %t299, i32 0, i32 1
  %t302 = load ptr, ptr %t301, !tbaa !29
  %t303 = load ptr, ptr %l1, !tbaa !29
  %t304 = load ptr, ptr %l2, !tbaa !29
  %t309 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v1, ptr %v2, ptr %t302, ptr %t303, ptr %t304)
  store i32 %t309, ptr %l145
  br label %bb73
bb73:
  %t310 = load i32, ptr %l145, !tbaa !23
  store i32 %t310, ptr %l13, !tbaa !23
  %t311 = load ptr, ptr %l0, !tbaa !29
  %t312 = load i32, ptr %l13, !tbaa !23
  %t315 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %t311, i32 %t312)
  store i1 %t315, ptr %l148
  br label %bb74
bb74:
  %t316 = load i1, ptr %l148, !tbaa !21
  br i1 %t316, label %bb75, label %bb76
bb75:
  store i1 true, ptr %l149, !tbaa !21
  br label %bb78
bb76:
  %t317 = load ptr, ptr %l0, !tbaa !29
  %t318 = load i32, ptr %l13, !tbaa !23
  %t321 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t317, i32 %t318)
  store i1 %t321, ptr %l152
  br label %bb77
bb77:
  %t322 = load i1, ptr %l152, !tbaa !21
  store i1 %t322, ptr %l149, !tbaa !21
  br label %bb78
bb78:
  %t323 = load i1, ptr %l149, !tbaa !21
  br i1 %t323, label %bb79, label %bb80
bb79:
  %t324 = load ptr, ptr %l0, !tbaa !29
  store ptr %t324, ptr %l153, !tbaa !29
  %t325 = load ptr, ptr %l0, !tbaa !29
  %t327 = getelementptr %"compiler/check:Checker", ptr %t325, i32 0, i32 1
  %t328 = load ptr, ptr %t327, !tbaa !29
  %t330 = getelementptr %"compiler/generic:Program", ptr %t328, i32 0, i32 2
  %t331 = load i32, ptr %l13, !tbaa !23
  %t334 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t330, i32 %t331)
  store i32 %t334, ptr %l158
  br label %bb81
bb80:
  br label %bb83
bb81:
  %t335 = load i32, ptr %l158, !tbaa !23
  %t336 = sext i32 %t335 to i64
  %t337 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t338 = load i1, ptr %l6, !tbaa !21
  %t339 = load ptr, ptr %l153, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenHolds(ptr %v0, ptr %v3, ptr %t339, i64 %t336, { i64, ptr } %t337, i1 %t338)
  br label %bb82
bb82:
  br label %bb83
bb83:
  %t343 = load ptr, ptr %l0, !tbaa !29
  %t344 = load ptr, ptr %l1, !tbaa !29
  %t345 = load ptr, ptr %l2, !tbaa !29
  %t346 = load { i64, ptr }, ptr %l3, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenArgs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t343, ptr %t344, ptr %t345, { i64, ptr } %t346)
  br label %bb84
bb84:
  br label %bb90
bb85:
  br i1 true, label %bb86, label %bb87
bb86:
  br label %bb88
bb87:
  br label %bb89
bb88:
  br label %bb90
bb89:
  call void @__olang_check_failed(ptr @olang_loc_99b065cd1779adaf_71b4842056cbdbfb)
  unreachable
bb90:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsSelf(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca i32
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i32
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca i32
  %l23 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l27 = alloca i64
  %l30 = alloca i64
  %l50 = alloca i1
  %l52 = alloca i1
  %l55 = alloca i32
  %l64 = alloca i32
  %l69 = alloca i64
  %l71 = alloca i64
  %l76 = alloca i32
  %l80 = alloca i64
  %l84 = alloca i64
  %l86 = alloca i1
  %l101 = alloca i1
  %l108 = alloca i32
  %l113 = alloca i32
  %l118 = alloca ptr
  %l123 = alloca i32
  %l124 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l16, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/check:Checker", ptr %t2, i32 0, i32 1
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t7 = getelementptr %"compiler/generic:Program", ptr %t5, i32 0, i32 2
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t7, i32 %a2)
  store i32 %t11, ptr %l21
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l16, !tbaa !29
  %t13 = load i32, ptr %l21, !tbaa !23
  %t14 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t14, ptr %l22
  br label %bb2
bb2:
  %t15 = load i32, ptr %l22, !tbaa !23
  store i32 %t15, ptr %l3, !tbaa !23
  %t16 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aDeclId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t16, ptr %l23
  br label %bb3
bb3:
  %t17 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t17, ptr %l4
  store i64 0, ptr %l5, !tbaa !24
  store i64 16, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t18 = load i64, ptr %l6, !tbaa !24
  %t19 = load i64, ptr %l5, !tbaa !24
  %t22 = icmp sgt i64 %t18, %t19
  br i1 %t22, label %bb4, label %bb5
bb4:
  %t24 = load i64, ptr %l7, !tbaa !24
  %t26 = icmp sgt i64 %t24, 0
  br i1 %t26, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb9
bb6:
  %t28 = load i64, ptr %l6, !tbaa !24
  %t29 = load i64, ptr %l5, !tbaa !24
  %t32 = sub i64 %t28, %t29
  %t33 = load i64, ptr %l7, !tbaa !24
  %t36 = add i64 %t32, %t33
  %t38 = sub i64 %t36, 1
  %t39 = load i64, ptr %l7, !tbaa !24
  %t42 = sdiv i64 %t38, %t39
  store i64 %t42, ptr %l30, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb8
bb8:
  %t44 = load i64, ptr %l30, !tbaa !24
  store i64 %t44, ptr %l27, !tbaa !24
  br label %bb9
bb9:
  %t45 = load i64, ptr %l27, !tbaa !24
  store i64 %t45, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb10
bb10:
  %t46 = load i64, ptr %l9, !tbaa !24
  %t47 = load i64, ptr %l8, !tbaa !24
  %t50 = icmp slt i64 %t46, %t47
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb11, label %bb12
bb11:
  br label %bb55
bb12:
  br label %bb13
bb13:
  %t54 = load i64, ptr %l5, !tbaa !24
  %t55 = load i64, ptr %l9, !tbaa !24
  %t56 = load i64, ptr %l7, !tbaa !24
  %t59 = mul i64 %t55, %t56
  %t62 = add i64 %t54, %t59
  store i64 %t62, ptr %l10, !tbaa !24
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load i32, ptr %l3, !tbaa !23
  %t68 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t64, i32 %t65)
  store i1 %t68, ptr %l50
  br label %bb14
bb14:
  %t69 = load i1, ptr %l50, !tbaa !21
  %t70 = xor i1 %t69, true
  br i1 %t70, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l52, !tbaa !21
  br label %bb18
bb16:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load i32, ptr %l3, !tbaa !23
  %t76 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t72, i32 %t73)
  store i32 %t76, ptr %l55
  br label %bb17
bb17:
  %t77 = load i32, ptr %l55, !range !{i32 0, i32 6}
  %t79 = trunc i64 4 to i32
  %t80 = icmp eq i32 %t77, %t79
  %t82 = xor i1 %t80, true
  store i1 %t82, ptr %l52, !tbaa !21
  br label %bb18
bb18:
  %t84 = load i1, ptr %l52, !tbaa !21
  br i1 %t84, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/check:Checker", ptr %t86, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t91 = getelementptr %"compiler/generic:Program", ptr %t89, i32 0, i32 2
  %t92 = load i32, ptr %l3, !tbaa !23
  %t95 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t91, i32 %t92)
  store i32 %t95, ptr %l64
  br label %bb22
bb22:
  %t96 = load i32, ptr %l64, !tbaa !23
  store i32 %t96, ptr %l11, !tbaa !23
  %t97 = load i32, ptr %l11, !tbaa !23
  %t98 = load i32, ptr %l1, !tbaa !23
  %t101 = icmp eq i32 %t97, %t98
  br i1 %t101, label %bb23, label %bb24
bb23:
  store ptr %l4, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  br label %bb25
bb24:
  br label %bb41
bb25:
  %t104 = load i64, ptr %l13, !tbaa !24
  store i64 %t104, ptr %l69, !tbaa !24
  %t105 = load ptr, ptr %l12, !tbaa !29
  %t107 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aDeclId_3e_2eLen_3ccompiler_2ftypes_3aDeclId_3e(ptr %s0, ptr %t105)
  store i64 %t107, ptr %l71
  br label %bb26
bb26:
  %t108 = load i64, ptr %l69, !tbaa !24
  %t109 = load i64, ptr %l71, !tbaa !24
  %t110 = icmp slt i64 %t108, %t109
  %t112 = xor i1 %t110, true
  br i1 %t112, label %bb27, label %bb28
bb27:
  br label %bb40
bb28:
  br label %bb29
bb29:
  %t114 = load ptr, ptr %l12, !tbaa !29
  %t115 = load i64, ptr %l13, !tbaa !24
  %t118 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aDeclId_3e_2eAt_3ccompiler_2ftypes_3aDeclId_3e(ptr %s0, ptr %t114, i64 %t115)
  store i32 %t118, ptr %l76
  br label %bb30
bb30:
  %t119 = load i32, ptr %l76, !tbaa !23
  store i32 %t119, ptr %l14, !tbaa !23
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/check:Checker", ptr %t120, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !29
  %t124 = load i32, ptr %l14, !tbaa !23
  %t127 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %t123, i32 %t124)
  store i64 %t127, ptr %l80
  br label %bb31
bb31:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/check:Checker", ptr %t128, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !29
  %t132 = load i32, ptr %l1, !tbaa !23
  %t135 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %t131, i32 %t132)
  store i64 %t135, ptr %l84
  br label %bb32
bb32:
  %t136 = load i64, ptr %l80, !tbaa !24
  %t137 = load i64, ptr %l84, !tbaa !24
  %t138 = icmp eq i64 %t136, %t137
  br i1 %t138, label %bb33, label %bb34
bb33:
  %t140 = load i32, ptr %l14, !tbaa !23
  %t142 = sext i32 %t140 to i64
  %t143 = load i32, ptr %l1, !tbaa !23
  %t145 = sext i32 %t143 to i64
  %t148 = icmp sgt i64 %t142, %t145
  store i1 %t148, ptr %l86, !tbaa !21
  br label %bb35
bb34:
  store i1 false, ptr %l86, !tbaa !21
  br label %bb35
bb35:
  %t150 = load i1, ptr %l86, !tbaa !21
  br i1 %t150, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb37:
  br label %bb38
bb38:
  br label %bb39
bb39:
  %t152 = load i64, ptr %l13, !tbaa !24
  %t154 = add i64 %t152, 1
  store i64 %t154, ptr %l13, !tbaa !24
  br label %bb25
bb40:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb41:
  %t157 = load i32, ptr %l11, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aDeclId_3e_2ePush_3ccompiler_2ftypes_3aDeclId_3e(ptr %s0, ptr %l4, i32 %t157)
  br label %bb42
bb42:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/check:Checker", ptr %t160, i32 0, i32 1
  %t163 = load ptr, ptr %t162, !tbaa !29
  %t164 = load i32, ptr %l3, !tbaa !23
  %t167 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t163, i32 %t164)
  store i1 %t167, ptr %l101
  br label %bb43
bb43:
  %t168 = load i1, ptr %l101, !tbaa !21
  %t169 = xor i1 %t168, true
  br i1 %t169, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb45:
  br label %bb46
bb46:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t174 = getelementptr %"compiler/check:Checker", ptr %t172, i32 0, i32 1
  %t175 = load ptr, ptr %t174, !tbaa !29
  %t177 = getelementptr %"compiler/generic:Program", ptr %t175, i32 0, i32 2
  %t178 = load i32, ptr %l3, !tbaa !23
  %t181 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t177, i32 %t178)
  store i32 %t181, ptr %l108
  br label %bb47
bb47:
  %t182 = load i32, ptr %l108, !tbaa !23
  store i32 %t182, ptr %l15, !tbaa !23
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr %"compiler/check:Checker", ptr %t183, i32 0, i32 1
  %t186 = load ptr, ptr %t185, !tbaa !29
  %t188 = getelementptr %"compiler/generic:Program", ptr %t186, i32 0, i32 2
  %t189 = load i32, ptr %l15, !tbaa !23
  %t192 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t188, i32 %t189)
  store i32 %t192, ptr %l113
  br label %bb48
bb48:
  %t193 = load i32, ptr %l113, !range !{i32 0, i32 33}
  %t195 = trunc i64 19 to i32
  %t196 = icmp eq i32 %t193, %t195
  %t198 = xor i1 %t196, true
  br i1 %t198, label %bb49, label %bb50
bb49:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb50:
  br label %bb51
bb51:
  %t201 = load ptr, ptr %l0, !tbaa !29
  store ptr %t201, ptr %l118, !tbaa !29
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t204 = getelementptr %"compiler/check:Checker", ptr %t202, i32 0, i32 1
  %t205 = load ptr, ptr %t204, !tbaa !29
  %t207 = getelementptr %"compiler/generic:Program", ptr %t205, i32 0, i32 2
  %t208 = load i32, ptr %l15, !tbaa !23
  %t211 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t207, i32 %t208)
  store i32 %t211, ptr %l123
  br label %bb52
bb52:
  %t212 = load ptr, ptr %l118, !tbaa !29
  %t213 = load i32, ptr %l123, !tbaa !23
  %t214 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t212, i32 %t213)
  store i32 %t214, ptr %l124
  br label %bb53
bb53:
  %t215 = load i32, ptr %l124, !tbaa !23
  store i32 %t215, ptr %l3, !tbaa !23
  br label %bb54
bb54:
  %t216 = load i64, ptr %l9, !tbaa !24
  %t218 = add i64 %t216, 1
  store i64 %t218, ptr %l9, !tbaa !24
  br label %bb10
bb55:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceWritten(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/check:ownerAt"
  %l3 = alloca ptr
  %l4 = alloca i1
  %l10 = alloca %"compiler/check:ownerAt"
  %l14 = alloca i1
  %l16 = alloca i1
  %l19 = alloca i1
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 28}
  %t8 = icmp eq i64 %t6, 11
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i32 -1, ptr %rv
  br label %ret
bb10:
  call void @__olang_check_failed(ptr @olang_loc_fee5565d650674df_3b318d0e6ee4625b)
  unreachable
bb11:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t15 = call %"compiler/check:ownerAt" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eownerOf(ptr %v0, ptr %v1, ptr %t11, ptr %t12)
  store %"compiler/check:ownerAt" %t15, ptr %l10
  br label %bb12
bb12:
  %t16 = load %"compiler/check:ownerAt", ptr %l10
  store %"compiler/check:ownerAt" %t16, ptr %l2
  %t17 = getelementptr %"compiler/check:ownerAt", ptr %l2, i32 0, i32 0
  %t18 = load i32, ptr %t17, !tbaa !23
  %t19 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t22 = icmp eq i32 %t18, %t19
  br i1 %t22, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb15
bb14:
  %t24 = getelementptr %"compiler/check:ownerAt", ptr %l2, i32 0, i32 1
  %t25 = load i1, ptr %t24, !tbaa !21
  store i1 %t25, ptr %l14, !tbaa !21
  br label %bb15
bb15:
  %t27 = load i1, ptr %l14, !tbaa !21
  br i1 %t27, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb19
bb17:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/check:ownerAt", ptr %l2, i32 0, i32 0
  %t30 = load i32, ptr %t29, !tbaa !23
  %t33 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t28, i32 %t30)
  store i1 %t33, ptr %l19
  br label %bb18
bb18:
  %t34 = load i1, ptr %l19, !tbaa !21
  store i1 %t34, ptr %l16, !tbaa !21
  br label %bb19
bb19:
  %t35 = load i1, ptr %l16, !tbaa !21
  br i1 %t35, label %bb20, label %bb21
bb20:
  store i32 -1, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t37 = getelementptr %"compiler/check:ownerAt", ptr %l2, i32 0, i32 0
  %t38 = load i32, ptr %t37, !tbaa !23
  store i32 %t38, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneDecl(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca %"compiler/check:laneNode"
  %l17 = alloca { i64, ptr }
  %l23 = alloca %"compiler/check:laneNode"
  %l40 = alloca i1
  %l48 = alloca i1
  %l51 = alloca ptr
  %l54 = alloca i32
  %l56 = alloca i1
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t1, ptr %l3, !tbaa !23
  store { i64, ptr } %a1, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l6, !tbaa !24
  br label %bb1
bb1:
  %t9 = load i64, ptr %l5, !tbaa !24
  %t10 = load i64, ptr %l6, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb2, label %bb3
bb2:
  br label %bb20
bb3:
  br label %bb4
bb4:
  %t17 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t17, ptr %l17, !tbaa !27
  %t18 = load i64, ptr %l5, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr i64, ptr %t21, i64 %t18
  %t23 = load i64, ptr %t22, !tbaa !34
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/check:Checker", ptr %t25, i32 0, i32 47
  %t31 = call %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %v0, ptr %t27, i64 %t23)
  store %"compiler/check:laneNode" %t31, ptr %l23
  br label %bb5
bb5:
  %t32 = load %"compiler/check:laneNode", ptr %l23
  store %"compiler/check:laneNode" %t32, ptr %l8
  %t33 = getelementptr %"compiler/check:laneNode", ptr %l8, i32 0, i32 0
  %t34 = load i64, ptr %t33, !tbaa !24
  %t35 = load i64, ptr @G_2ecompiler_2fcheck_2eLaneScalar, !tbaa !24
  %t38 = icmp eq i64 %t34, %t35
  br i1 %t38, label %bb6, label %bb7
bb6:
  br label %bb19
bb7:
  br label %bb8
bb8:
  %t40 = getelementptr %"compiler/check:laneNode", ptr %l8, i32 0, i32 10
  %t41 = load i32, ptr %t40, !tbaa !23
  %t42 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t45 = icmp eq i32 %t41, %t42
  br i1 %t45, label %bb9, label %bb10
bb9:
  %t47 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t47, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t49 = load i32, ptr %l3, !tbaa !23
  %t50 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t53 = icmp eq i32 %t49, %t50
  br i1 %t53, label %bb12, label %bb13
bb12:
  %t55 = getelementptr %"compiler/check:laneNode", ptr %l8, i32 0, i32 10
  %t56 = load i32, ptr %t55, !tbaa !23
  store i32 %t56, ptr %l3, !tbaa !23
  br label %bb18
bb13:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/check:Checker", ptr %t58, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = getelementptr %"compiler/generic:Program", ptr %t61, i32 0, i32 2
  %t64 = load i32, ptr %l3, !tbaa !23
  %t65 = getelementptr %"compiler/check:laneNode", ptr %l8, i32 0, i32 10
  %t66 = load i32, ptr %t65, !tbaa !23
  %t70 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t63, i32 %t64, i32 %t66)
  store i1 %t70, ptr %l40
  br label %bb14
bb14:
  %t71 = load i1, ptr %l40, !tbaa !21
  %t72 = xor i1 %t71, true
  br i1 %t72, label %bb15, label %bb16
bb15:
  %t74 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t74, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t76 = load i64, ptr %l5, !tbaa !24
  %t78 = add i64 %t76, 1
  store i64 %t78, ptr %l5, !tbaa !24
  br label %bb1
bb20:
  %t80 = load i32, ptr %l3, !tbaa !23
  %t81 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t84 = icmp eq i32 %t80, %t81
  br i1 %t84, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb25
bb22:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/check:Checker", ptr %t86, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t91 = getelementptr %"compiler/generic:Program", ptr %t89, i32 0, i32 2
  store ptr %t91, ptr %l51, !tbaa !29
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load i32, ptr %l3, !tbaa !23
  %t96 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElemOf(ptr %v0, ptr %t92, i32 %t93)
  store i32 %t96, ptr %l54
  br label %bb23
bb23:
  %t98 = load ptr, ptr %l51, !tbaa !29
  %t99 = load i32, ptr %l54, !tbaa !23
  %t101 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t98, i32 %t99, i32 %a2)
  store i1 %t101, ptr %l56
  br label %bb24
bb24:
  %t102 = load i1, ptr %l56, !tbaa !21
  %t103 = xor i1 %t102, true
  store i1 %t103, ptr %l48, !tbaa !21
  br label %bb25
bb25:
  %t105 = load i1, ptr %l48, !tbaa !21
  br i1 %t105, label %bb26, label %bb27
bb26:
  %t106 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t106, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t108 = load i32, ptr %l3, !tbaa !23
  store i32 %t108, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneHold(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2) #0 {
entry:
  %l2 = alloca i64
  %l3 = alloca %"compiler/source:Span"
  %l6 = alloca i32
  %rv = alloca ptr
  %t12 = alloca { i64, [5 x i64] }, align 8
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %"compiler/source:Span" %a1, ptr %l3
  %t3 = load i64, ptr %l2, !tbaa !24
  %t6 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneType(ptr %v0, ptr %a0, i64 %t3)
  store i32 %t6, ptr %l6
  br label %bb1
bb1:
  %t7 = load i64, ptr @G_2ecompiler_2fcheck_2eLaneMagic, !tbaa !24
  %t8 = load i64, ptr %l2, !tbaa !24
  %t11 = add i64 %t7, %t8
  store { i64, [5 x i64] } zeroinitializer, ptr %t12
  %t13 = getelementptr { i64, [5 x i64] }, ptr %t12, i32 0, i32 0
  store i64 0, ptr %t13
  %t14 = load %"compiler/source:Span", ptr %l3
  %t15 = insertvalue { %"compiler/source:Span", i32, i64 } undef, %"compiler/source:Span" %t14, 0
  %t16 = load i32, ptr %l6, !tbaa !23
  %t17 = insertvalue { %"compiler/source:Span", i32, i64 } %t15, i32 %t16, 1
  %t19 = insertvalue { %"compiler/source:Span", i32, i64 } %t17, i64 %t11, 2
  %t20 = getelementptr { i64, [5 x i64] }, ptr %t12, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64 } %t19, ptr %t20
  %t21 = load { i64, [5 x i64] }, ptr %t12
  %t23 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store { i64, [5 x i64] } %t21, ptr %t23
  store ptr %t23, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLeaf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca i32
  %l11 = alloca i64
  %l17 = alloca i32
  %l20 = alloca i1
  %l23 = alloca i32
  %l28 = alloca i32
  %l31 = alloca i1
  %l36 = alloca i32
  %l39 = alloca i64
  %l44 = alloca i64
  %l47 = alloca i32
  %l50 = alloca i1
  %l51 = alloca i32
  %l54 = alloca ptr
  %l55 = alloca i64
  %l56 = alloca i32
  %l58 = alloca %"compiler/source:Span"
  %l60 = alloca %"compiler/source:Span"
  %l62 = alloca ptr
  %l67 = alloca i32
  %l70 = alloca %"compiler/check:laneNode"
  %l71 = alloca i64
  %l72 = alloca ptr
  %l73 = alloca i64
  %l74 = alloca i32
  %l76 = alloca %"compiler/source:Span"
  %l78 = alloca %"compiler/source:Span"
  %l83 = alloca %"compiler/check:laneNode"
  %l84 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneOf(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i64 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i64, ptr %l11, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sge i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load i64, ptr %l2, !tbaa !24
  store i64 %t11, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t13 = load ptr, ptr %l1, !tbaa !29
  %t16 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t13)
  store i32 %t16, ptr %l17
  br label %bb5
bb5:
  %t17 = load i32, ptr %l17, !tbaa !23
  store i32 %t17, ptr %l3, !tbaa !23
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i32, ptr %l3, !tbaa !23
  %t22 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArray(ptr %v0, ptr %t18, i32 %t19)
  store i1 %t22, ptr %l20
  br label %bb6
bb6:
  %t23 = load i1, ptr %l20, !tbaa !21
  br i1 %t23, label %bb7, label %bb8
bb7:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load i32, ptr %l3, !tbaa !23
  %t28 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t24, i32 %t25)
  store i32 %t28, ptr %l23
  br label %bb9
bb8:
  br label %bb29
bb9:
  %t29 = load i32, ptr %l23, !tbaa !23
  store i32 %t29, ptr %l4, !tbaa !23
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/check:Checker", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/generic:Program", ptr %t33, i32 0, i32 2
  %t36 = load i32, ptr %l4, !tbaa !23
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t35, i32 %t36)
  store i32 %t39, ptr %l28
  br label %bb10
bb10:
  %t40 = load i32, ptr %l28, !tbaa !23
  store i32 %t40, ptr %l5, !tbaa !23
  %t41 = load i32, ptr %l5, !tbaa !23
  %t43 = icmp ne i32 %t41, 0
  br i1 %t43, label %bb11, label %bb12
bb11:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/check:Checker", ptr %t45, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t50 = getelementptr %"compiler/generic:Program", ptr %t48, i32 0, i32 2
  %t51 = load i32, ptr %l5, !tbaa !23
  %t54 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t50, i32 %t51)
  store i32 %t54, ptr %l36
  br label %bb13
bb12:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb14
bb13:
  %t55 = load i32, ptr %l36, !range !{i32 0, i32 33}
  %t57 = trunc i64 26 to i32
  %t58 = icmp eq i32 %t55, %t57
  store i1 %t58, ptr %l31, !tbaa !21
  br label %bb14
bb14:
  %t60 = load i1, ptr %l31, !tbaa !21
  br i1 %t60, label %bb15, label %bb16
bb15:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/check:Checker", ptr %t61, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t66 = getelementptr %"compiler/generic:Program", ptr %t64, i32 0, i32 2
  %t67 = load i32, ptr %l5, !tbaa !23
  %t70 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t66, i32 %t67)
  store i64 %t70, ptr %l44
  br label %bb17
bb16:
  store i64 -1, ptr %l39, !tbaa !24
  br label %bb18
bb17:
  %t71 = load i64, ptr %l44, !tbaa !24
  store i64 %t71, ptr %l39, !tbaa !24
  br label %bb18
bb18:
  %t72 = load i64, ptr %l39, !tbaa !24
  store i64 %t72, ptr %l6, !tbaa !24
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load i32, ptr %l3, !tbaa !23
  %t77 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t73, i32 %t74)
  store i32 %t77, ptr %l47
  br label %bb19
bb19:
  %t78 = load i32, ptr %l47, !tbaa !23
  store i32 %t78, ptr %l7, !tbaa !23
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load i32, ptr %l7, !tbaa !23
  %t83 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t79, i32 %t80)
  store i1 %t83, ptr %l50
  br label %bb20
bb20:
  %t84 = load i1, ptr %l50, !tbaa !21
  br i1 %t84, label %bb21, label %bb22
bb21:
  %t85 = load i32, ptr %l7, !tbaa !23
  store i32 %t85, ptr %l51, !tbaa !23
  br label %bb23
bb22:
  %t87 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t87, ptr %l51, !tbaa !23
  br label %bb23
bb23:
  %t89 = load i32, ptr %l51, !tbaa !23
  store i32 %t89, ptr %l8, !tbaa !23
  %t90 = load ptr, ptr %l0, !tbaa !29
  store ptr %t90, ptr %l54, !tbaa !29
  %t91 = load i64, ptr @G_2ecompiler_2fcheck_2eLaneArr, !tbaa !24
  store i64 %t91, ptr %l55, !tbaa !24
  store i32 67, ptr %l56
  %t92 = load ptr, ptr %l1, !tbaa !29
  %t94 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t92)
  store %"compiler/source:Span" %t94, ptr %l58
  br label %bb24
bb24:
  %t95 = load ptr, ptr %l1, !tbaa !29
  %t97 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t95)
  store %"compiler/source:Span" %t97, ptr %l60
  br label %bb25
bb25:
  %t98 = load ptr, ptr %l1, !tbaa !29
  store ptr %t98, ptr %l62, !tbaa !29
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/check:Checker", ptr %t100, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t105 = getelementptr %"compiler/generic:Program", ptr %t103, i32 0, i32 2
  %t106 = load i32, ptr %l4, !tbaa !23
  %t109 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t105, i32 %t106)
  store i32 %t109, ptr %l67
  br label %bb26
bb26:
  %t110 = load i64, ptr %l6, !tbaa !24
  %t111 = load i32, ptr %l8, !tbaa !23
  %t112 = load i64, ptr %l55, !tbaa !24
  %t113 = load i32, ptr %l56, !range !{i32 0, i32 113}
  %t114 = load %"compiler/source:Span", ptr %l58
  %t115 = load %"compiler/source:Span", ptr %l60
  %t116 = load ptr, ptr %l62, !tbaa !29
  %t117 = load i32, ptr %l67, !tbaa !23
  %t120 = call %"compiler/check:laneNode" @compiler_2fcheck_3alaneNode_2ector(ptr %v1, ptr %v0, i64 %t112, i32 %t113, %"compiler/source:Span" %t114, %"compiler/source:Span" %t115, i64 -1, i64 -1, i64 -1, ptr %t116, i32 %t117, i64 %t110, i32 %t111)
  store %"compiler/check:laneNode" %t120, ptr %l70
  br label %bb27
bb27:
  %t121 = load ptr, ptr %l54, !tbaa !29
  %t122 = load %"compiler/check:laneNode", ptr %l70
  %t123 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneAdd(ptr %v0, ptr %v0, ptr %t121, %"compiler/check:laneNode" %t122)
  store i64 %t123, ptr %l71
  br label %bb28
bb28:
  %t124 = load i64, ptr %l71, !tbaa !24
  store i64 %t124, ptr %rv
  br label %ret
bb29:
  %t125 = load ptr, ptr %l0, !tbaa !29
  store ptr %t125, ptr %l72, !tbaa !29
  %t126 = load i64, ptr @G_2ecompiler_2fcheck_2eLaneScalar, !tbaa !24
  store i64 %t126, ptr %l73, !tbaa !24
  store i32 67, ptr %l74
  %t127 = load ptr, ptr %l1, !tbaa !29
  %t129 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t127)
  store %"compiler/source:Span" %t129, ptr %l76
  br label %bb30
bb30:
  %t130 = load ptr, ptr %l1, !tbaa !29
  %t132 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t130)
  store %"compiler/source:Span" %t132, ptr %l78
  br label %bb31
bb31:
  %t133 = load ptr, ptr %l1, !tbaa !29
  %t135 = load i32, ptr %l3, !tbaa !23
  %t136 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t137 = load i64, ptr %l73, !tbaa !24
  %t138 = load i32, ptr %l74, !range !{i32 0, i32 113}
  %t139 = load %"compiler/source:Span", ptr %l76
  %t140 = load %"compiler/source:Span", ptr %l78
  %t144 = call %"compiler/check:laneNode" @compiler_2fcheck_3alaneNode_2ector(ptr %v1, ptr %v0, i64 %t137, i32 %t138, %"compiler/source:Span" %t139, %"compiler/source:Span" %t140, i64 -1, i64 -1, i64 -1, ptr %t133, i32 %t135, i64 -1, i32 %t136)
  store %"compiler/check:laneNode" %t144, ptr %l83
  br label %bb32
bb32:
  %t145 = load ptr, ptr %l72, !tbaa !29
  %t146 = load %"compiler/check:laneNode", ptr %l83
  %t147 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneAdd(ptr %v0, ptr %v0, ptr %t145, %"compiler/check:laneNode" %t146)
  store i64 %t147, ptr %l84
  br label %bb33
bb33:
  %t148 = load i64, ptr %l84, !tbaa !24
  store i64 %t148, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneSay(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca %"compiler/check:laneVals"
  %l7 = alloca i64
  %l11 = alloca %"compiler/check:laneVals"
  %l12 = alloca ptr
  %l13 = alloca %"compiler/source:Span"
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca %"compiler/source:Span"
  %l19 = alloca i32
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l27 = alloca ptr
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 45
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load i64, ptr %l7, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load %"compiler/source:Span", ptr %l1
  %t9 = load i64, ptr %l2, !tbaa !24
  %t13 = call %"compiler/check:laneVals" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneSetup(ptr %v0, ptr %s0, ptr %t7, %"compiler/source:Span" %t8, i64 %t9)
  store %"compiler/check:laneVals" %t13, ptr %l11
  br label %bb2
bb2:
  %t14 = load %"compiler/check:laneVals", ptr %l11
  store %"compiler/check:laneVals" %t14, ptr %l4
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l12, !tbaa !29
  %t16 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t16, ptr %l13
  %t17 = load i64, ptr %l2, !tbaa !24
  store i64 %t17, ptr %l14, !tbaa !24
  store ptr %l4, ptr %l15, !tbaa !29
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %l16, !tbaa !29
  %t19 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t19, ptr %l17
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t20)
  store i32 %t22, ptr %l19
  br label %bb3
bb3:
  %t23 = load ptr, ptr %l16, !tbaa !29
  %t24 = load %"compiler/source:Span", ptr %l17
  %t25 = load i32, ptr %l19, !tbaa !23
  %t26 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t23, %"compiler/source:Span" %t24, i32 %t25, i64 0)
  store ptr %t26, ptr %l20
  br label %bb4
bb4:
  %t27 = load ptr, ptr %l12, !tbaa !29
  %t28 = load %"compiler/source:Span", ptr %l13
  %t29 = load i64, ptr %l14, !tbaa !24
  %t30 = load ptr, ptr %l15, !tbaa !29
  %t31 = load ptr, ptr %l20, !tbaa !29
  %t32 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElem(ptr %v0, ptr %s0, ptr %v0, ptr %v0, ptr %t27, %"compiler/source:Span" %t28, i64 %t29, ptr %t30, ptr %t31)
  store ptr %t32, ptr %l21
  br label %bb5
bb5:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t33, i32 0, i32 45
  %t36 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eTrunca_Hc8531d0d5535cc9766a27157f9c0b07c(ptr %v0, ptr %t35, i64 %t36)
  br label %bb6
bb6:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load %"compiler/source:Span", ptr %l1
  %t43 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %t39, %"compiler/source:Span" %t40)
  store ptr %t43, ptr %l27
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t44 = load ptr, ptr %l27, !tbaa !29
  store ptr %t44, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elentWritable(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i32 %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l9 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t6, i32 %a3)
  store i64 %t10, ptr %l9
  br label %bb1
bb1:
  %t11 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t12 = load i64, ptr %l9, !tbaa !24
  %t14 = and i64 %t12, %t11
  %t16 = icmp eq i64 %t14, 0
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t18 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emustWrite(ptr %v0, ptr %v1, ptr %t18, ptr %a1, %"compiler/source:Span" %a4, i1 false)
  br label %bb5
bb5:
  %t24 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroDeepNeed(ptr %v0, ptr %v2, ptr %t24, ptr %a2)
  br label %bb6
bb6:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elimit(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l7 = alloca i1
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l16 = alloca i32
  %l21 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca %"compiler/source:Span"
  %l27 = alloca { i64, ptr }
  %l30 = alloca %"compiler/diagmsg:Msg"
  %l31 = alloca i64
  %l34 = alloca ptr
  %l37 = alloca i1
  %l38 = alloca i1
  %l42 = alloca i1
  %l44 = alloca i1
  %l48 = alloca i32
  %l51 = alloca ptr
  %l52 = alloca %"compiler/source:Span"
  %l55 = alloca { i64, ptr }
  %l58 = alloca %"compiler/diagmsg:Msg"
  %l59 = alloca i64
  %l62 = alloca ptr
  %l67 = alloca i1
  %l69 = alloca i64
  %l72 = alloca i1
  %l75 = alloca i1
  %l79 = alloca { i64, ptr }
  %l80 = alloca ptr
  %l81 = alloca %"compiler/source:Span"
  %l84 = alloca { i64, ptr }
  %l90 = alloca %"compiler/diagmsg:Msg"
  %l91 = alloca i64
  %l94 = alloca ptr
  %l97 = alloca i1
  %l102 = alloca i64
  %l108 = alloca i1
  %l114 = alloca ptr
  %l115 = alloca ptr
  %l116 = alloca %"compiler/source:Span"
  %l117 = alloca i32
  %l118 = alloca i32
  %l122 = alloca ptr
  %l123 = alloca ptr
  %l124 = alloca ptr
  %l125 = alloca %"compiler/source:Span"
  %l126 = alloca i32
  %l127 = alloca i32
  %l131 = alloca ptr
  %l132 = alloca ptr
  %l133 = alloca %"compiler/source:Span"
  %l135 = alloca i32
  %l140 = alloca i64
  %l142 = alloca ptr
  %l144 = alloca ptr
  %l153 = alloca ptr
  %l154 = alloca ptr
  %l155 = alloca %"compiler/source:Span"
  %l156 = alloca i32
  %l162 = alloca i64
  %l163 = alloca ptr
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t1, i32 %a4)
  store { i64, ptr } %t5, ptr %l13
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t6, ptr %l5, !tbaa !27
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l3, !tbaa !23
  %t11 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l16
  br label %bb2
bb2:
  %t12 = load i32, ptr %l16, !tbaa !23
  store i32 %t12, ptr %l6, !tbaa !23
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 2
  %t19 = load i32, ptr %l6, !tbaa !23
  %t22 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %t18, i32 %t19)
  store i1 %t22, ptr %l21
  br label %bb3
bb3:
  %t23 = load i1, ptr %l21, !tbaa !21
  %t24 = xor i1 %t23, true
  br i1 %t24, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l23, !tbaa !29
  %t27 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t27, ptr %l24
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l3, !tbaa !23
  %t32 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t28, i32 %t29)
  store { i64, ptr } %t32, ptr %l27
  br label %bb6
bb5:
  br label %bb10
bb6:
  %t33 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 0
  %t35 = extractvalue { i64, ptr } %t33, 1
  %t36 = mul i64 %t34, 1
  %t37 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t36)
  call void @llvm.memcpy.p0.p0.i64(ptr %t37, ptr %t35, i64 %t36, i1 false)
  %t38 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  %t40 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t43 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoLimit(ptr %s1, ptr %v0, ptr %s1, ptr %v0, { i64, ptr } %t39, { i64, ptr } %t40, { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d15, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t43, ptr %l30
  br label %bb7
bb7:
  %t44 = load ptr, ptr %l23, !tbaa !29
  %t45 = load %"compiler/source:Span", ptr %l24
  %t46 = load %"compiler/diagmsg:Msg", ptr %l30
  %t47 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t44, %"compiler/source:Span" %t45, %"compiler/diagmsg:Msg" %t46)
  store i64 %t47, ptr %l31
  br label %bb8
bb8:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load %"compiler/source:Span", ptr %l1
  %t52 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %t48, %"compiler/source:Span" %t49)
  store ptr %t52, ptr %l34
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s1)
  %t53 = load ptr, ptr %l34, !tbaa !29
  store ptr %t53, ptr %rv
  br label %ret
bb10:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load i32, ptr %l3, !tbaa !23
  %t58 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisOver(ptr %v0, ptr %t54, i32 %t55)
  store i1 %t58, ptr %l37
  br label %bb11
bb11:
  %t59 = load i1, ptr %l37, !tbaa !21
  br i1 %t59, label %bb12, label %bb13
bb12:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/check:Checker", ptr %t60, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t64 = load i32, ptr %l3, !tbaa !23
  %t67 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %t63, i32 %t64)
  store i1 %t67, ptr %l42
  br label %bb14
bb13:
  store i1 false, ptr %l38, !tbaa !21
  br label %bb19
bb14:
  %t68 = load i1, ptr %l42, !tbaa !21
  %t69 = xor i1 %t68, true
  br i1 %t69, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l44, !tbaa !21
  br label %bb18
bb16:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/check:Checker", ptr %t71, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t75 = load i32, ptr %l3, !tbaa !23
  %t78 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %t74, i32 %t75)
  store i32 %t78, ptr %l48
  br label %bb17
bb17:
  %t79 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t80 = load i32, ptr %l48, !tbaa !23
  %t82 = icmp ne i32 %t80, %t79
  store i1 %t82, ptr %l44, !tbaa !21
  br label %bb18
bb18:
  %t84 = load i1, ptr %l44, !tbaa !21
  store i1 %t84, ptr %l38, !tbaa !21
  br label %bb19
bb19:
  %t85 = load i1, ptr %l38, !tbaa !21
  br i1 %t85, label %bb20, label %bb21
bb20:
  store %olang.scope zeroinitializer, ptr %s2
  %t86 = load ptr, ptr %l0, !tbaa !29
  store ptr %t86, ptr %l51, !tbaa !29
  %t87 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t87, ptr %l52
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load i32, ptr %l3, !tbaa !23
  %t92 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t88, i32 %t89)
  store { i64, ptr } %t92, ptr %l55
  br label %bb22
bb21:
  br label %bb26
bb22:
  %t93 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t93, 0
  %t95 = extractvalue { i64, ptr } %t93, 1
  %t96 = mul i64 %t94, 1
  %t97 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t96)
  call void @llvm.memcpy.p0.p0.i64(ptr %t97, ptr %t95, i64 %t96, i1 false)
  %t98 = insertvalue { i64, ptr } undef, i64 %t94, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t97, 1
  %t100 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t103 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoLimit(ptr %s2, ptr %v0, ptr %s2, ptr %v0, { i64, ptr } %t99, { i64, ptr } %t100, { i64, ptr } { i64 93, ptr getelementptr inbounds (<{ i64, [93 x i8] }>, ptr @.d16, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t103, ptr %l58
  br label %bb23
bb23:
  %t104 = load ptr, ptr %l51, !tbaa !29
  %t105 = load %"compiler/source:Span", ptr %l52
  %t106 = load %"compiler/diagmsg:Msg", ptr %l58
  %t107 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t104, %"compiler/source:Span" %t105, %"compiler/diagmsg:Msg" %t106)
  store i64 %t107, ptr %l59
  br label %bb24
bb24:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load %"compiler/source:Span", ptr %l1
  %t112 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %t108, %"compiler/source:Span" %t109)
  store ptr %t112, ptr %l62
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s2)
  %t113 = load ptr, ptr %l62, !tbaa !29
  store ptr %t113, ptr %rv
  br label %ret
bb26:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/check:Checker", ptr %t114, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !29
  %t119 = getelementptr %"compiler/generic:Program", ptr %t117, i32 0, i32 2
  %t120 = load i32, ptr %l6, !tbaa !23
  %t123 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t119, i32 %t120)
  store i1 %t123, ptr %l67
  br label %bb27
bb27:
  %t124 = load i1, ptr %l67, !tbaa !21
  store i1 %t124, ptr %l7, !tbaa !21
  %t125 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t127 = call i64 @compiler_2fcheck_2elimitIndex(ptr %v0, { i64, ptr } %t125)
  store i64 %t127, ptr %l69
  br label %bb28
bb28:
  %t128 = load i64, ptr %l69, !tbaa !24
  store i64 %t128, ptr %l8, !tbaa !24
  %t129 = load i64, ptr %l8, !tbaa !24
  %t131 = icmp slt i64 %t129, 0
  br i1 %t131, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l72, !tbaa !21
  br label %bb34
bb30:
  %t133 = load i64, ptr %l8, !tbaa !24
  %t135 = icmp sgt i64 %t133, 1
  br i1 %t135, label %bb31, label %bb32
bb31:
  %t137 = load i1, ptr %l7, !tbaa !21
  %t139 = xor i1 %t137, true
  store i1 %t139, ptr %l75, !tbaa !21
  br label %bb33
bb32:
  store i1 false, ptr %l75, !tbaa !21
  br label %bb33
bb33:
  %t141 = load i1, ptr %l75, !tbaa !21
  store i1 %t141, ptr %l72, !tbaa !21
  br label %bb34
bb34:
  %t142 = load i1, ptr %l72, !tbaa !21
  br i1 %t142, label %bb35, label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s3
  %t143 = load i1, ptr %l7, !tbaa !21
  br i1 %t143, label %bb37, label %bb38
bb36:
  br label %bb44
bb37:
  store { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d17, i32 0, i32 1) }, ptr %l79, !tbaa !27
  br label %bb39
bb38:
  store { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d18, i32 0, i32 1) }, ptr %l79, !tbaa !27
  br label %bb39
bb39:
  %t145 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t145, ptr %l9, !tbaa !27
  %t146 = load ptr, ptr %l0, !tbaa !29
  store ptr %t146, ptr %l80, !tbaa !29
  %t147 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t147, ptr %l81
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t149 = load i32, ptr %l3, !tbaa !23
  %t152 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s3, ptr %t148, i32 %t149)
  store { i64, ptr } %t152, ptr %l84
  br label %bb40
bb40:
  %t153 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t154 = extractvalue { i64, ptr } %t153, 0
  %t155 = extractvalue { i64, ptr } %t153, 1
  %t156 = mul i64 %t154, 1
  %t157 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t156)
  call void @llvm.memcpy.p0.p0.i64(ptr %t157, ptr %t155, i64 %t156, i1 false)
  %t158 = insertvalue { i64, ptr } undef, i64 %t154, 0
  %t159 = insertvalue { i64, ptr } %t158, ptr %t157, 1
  %t160 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t161 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t162 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t163 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t165 = extractvalue { i64, ptr } %t161, 1
  %t166 = extractvalue { i64, ptr } %t161, 0
  %t167 = add i64 %t163, %t166
  %t168 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t167)
  call void @olang_textcopy(ptr %t168, ptr %t162, i64 %t163)
  %t169 = getelementptr i8, ptr %t168, i64 %t163
  call void @olang_textcopy(ptr %t169, ptr %t165, i64 %t166)
  %t170 = insertvalue { i64, ptr } undef, i64 %t167, 0
  %t171 = insertvalue { i64, ptr } %t170, ptr %t168, 1
  %t173 = extractvalue { i64, ptr } %t171, 0
  %t174 = extractvalue { i64, ptr } %t171, 1
  %t175 = mul i64 %t173, 1
  %t176 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t175)
  call void @llvm.memcpy.p0.p0.i64(ptr %t176, ptr %t174, i64 %t175, i1 false)
  %t177 = insertvalue { i64, ptr } undef, i64 %t173, 0
  %t178 = insertvalue { i64, ptr } %t177, ptr %t176, 1
  %t182 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoLimit(ptr %s3, ptr %v0, ptr %s3, ptr %v0, { i64, ptr } %t159, { i64, ptr } %t160, { i64, ptr } %t178)
  store %"compiler/diagmsg:Msg" %t182, ptr %l90
  br label %bb41
bb41:
  %t183 = load ptr, ptr %l80, !tbaa !29
  %t184 = load %"compiler/source:Span", ptr %l81
  %t185 = load %"compiler/diagmsg:Msg", ptr %l90
  %t186 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t183, %"compiler/source:Span" %t184, %"compiler/diagmsg:Msg" %t185)
  store i64 %t186, ptr %l91
  br label %bb42
bb42:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t188 = load %"compiler/source:Span", ptr %l1
  %t191 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %t187, %"compiler/source:Span" %t188)
  store ptr %t191, ptr %l94
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s3)
  %t192 = load ptr, ptr %l94, !tbaa !29
  store ptr %t192, ptr %rv
  br label %ret
bb44:
  %t193 = load i1, ptr %l7, !tbaa !21
  %t195 = xor i1 %t193, true
  br i1 %t195, label %bb45, label %bb46
bb45:
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t199 = getelementptr %"compiler/check:Checker", ptr %t197, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !29
  %t202 = getelementptr %"compiler/generic:Program", ptr %t200, i32 0, i32 2
  %t203 = load i32, ptr %l6, !tbaa !23
  %t206 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t202, i32 %t203)
  store i64 %t206, ptr %l102
  br label %bb47
bb46:
  store i1 false, ptr %l97, !tbaa !21
  br label %bb48
bb47:
  %t207 = load i64, ptr %l102, !tbaa !24
  %t208 = icmp sgt i64 %t207, 64
  store i1 %t208, ptr %l97, !tbaa !21
  br label %bb48
bb48:
  %t210 = load i1, ptr %l97, !tbaa !21
  br i1 %t210, label %bb49, label %bb50
bb49:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr %"compiler/check:Checker", ptr %t211, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !29
  %t216 = getelementptr %"compiler/generic:Program", ptr %t214, i32 0, i32 2
  %t217 = load i32, ptr %l6, !tbaa !23
  %t220 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t216, i32 %t217)
  store i1 %t220, ptr %l108
  br label %bb51
bb50:
  br label %bb70
bb51:
  %t221 = load i1, ptr %l108, !tbaa !21
  br i1 %t221, label %bb52, label %bb53
bb52:
  %t222 = load i64, ptr %l8, !tbaa !24
  %t224 = icmp eq i64 %t222, 1
  br i1 %t224, label %bb54, label %bb55
bb53:
  br label %bb60
bb54:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t227 = load %"compiler/source:Span", ptr %l1
  %t228 = load i32, ptr %l3, !tbaa !23
  %t232 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v1, ptr %t226, %"compiler/source:Span" %t227, i32 %t228, i64 0)
  store ptr %t232, ptr %l114
  br label %bb56
bb55:
  br label %bb57
bb56:
  %t233 = load ptr, ptr %l114, !tbaa !29
  store ptr %t233, ptr %rv
  br label %ret
bb57:
  %t234 = load ptr, ptr %l0, !tbaa !29
  store ptr %t234, ptr %l115, !tbaa !29
  %t235 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t235, ptr %l116
  %t236 = load i32, ptr %l3, !tbaa !23
  store i32 %t236, ptr %l117, !tbaa !23
  store i32 1, ptr %l118
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t238 = load %"compiler/source:Span", ptr %l1
  %t239 = load i32, ptr %l3, !tbaa !23
  %t243 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t237, %"compiler/source:Span" %t238, i32 %t239, i64 0)
  store ptr %t243, ptr %l122
  br label %bb58
bb58:
  %t244 = load ptr, ptr %l115, !tbaa !29
  %t245 = load %"compiler/source:Span", ptr %l116
  %t246 = load i32, ptr %l117, !tbaa !23
  %t247 = load i32, ptr %l118, !range !{i32 0, i32 52}
  %t248 = load ptr, ptr %l122, !tbaa !29
  %t249 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v0, ptr %v0, ptr %v1, ptr %t244, %"compiler/source:Span" %t245, i32 %t246, i32 %t247, ptr %t248, ptr null)
  store ptr %t249, ptr %l123
  br label %bb59
bb59:
  %t250 = load ptr, ptr %l123, !tbaa !29
  store ptr %t250, ptr %rv
  br label %ret
bb60:
  %t251 = load ptr, ptr %l0, !tbaa !29
  store ptr %t251, ptr %l124, !tbaa !29
  %t252 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t252, ptr %l125
  %t253 = load i32, ptr %l3, !tbaa !23
  store i32 %t253, ptr %l126, !tbaa !23
  store i32 8, ptr %l127
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t255 = load %"compiler/source:Span", ptr %l1
  %t256 = load i32, ptr %l3, !tbaa !23
  %t260 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t254, %"compiler/source:Span" %t255, i32 %t256, i64 1)
  store ptr %t260, ptr %l131
  br label %bb61
bb61:
  %t261 = load ptr, ptr %l0, !tbaa !29
  store ptr %t261, ptr %l132, !tbaa !29
  %t262 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t262, ptr %l133
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t265 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t263)
  store i32 %t265, ptr %l135
  br label %bb62
bb62:
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t268 = getelementptr %"compiler/check:Checker", ptr %t266, i32 0, i32 1
  %t269 = load ptr, ptr %t268, !tbaa !29
  %t271 = getelementptr %"compiler/generic:Program", ptr %t269, i32 0, i32 2
  %t272 = load i32, ptr %l6, !tbaa !23
  %t275 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t271, i32 %t272)
  store i64 %t275, ptr %l140
  br label %bb63
bb63:
  %t276 = load i64, ptr %l140, !tbaa !24
  %t277 = sub i64 %t276, 1
  %t278 = load ptr, ptr %l132, !tbaa !29
  %t279 = load %"compiler/source:Span", ptr %l133
  %t280 = load i32, ptr %l135, !tbaa !23
  %t282 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t278, %"compiler/source:Span" %t279, i32 %t280, i64 %t277)
  store ptr %t282, ptr %l142
  br label %bb64
bb64:
  %t283 = load ptr, ptr %l142, !tbaa !29
  %t284 = load ptr, ptr %l124, !tbaa !29
  %t285 = load %"compiler/source:Span", ptr %l125
  %t286 = load i32, ptr %l126, !tbaa !23
  %t287 = load i32, ptr %l127, !range !{i32 0, i32 52}
  %t288 = load ptr, ptr %l131, !tbaa !29
  %t290 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v0, ptr %v0, ptr %v1, ptr %t284, %"compiler/source:Span" %t285, i32 %t286, i32 %t287, ptr %t288, ptr %t283)
  store ptr %t290, ptr %l144
  br label %bb65
bb65:
  %t291 = load ptr, ptr %l144, !tbaa !29
  store ptr %t291, ptr %l10, !tbaa !29
  %t292 = load i64, ptr %l8, !tbaa !24
  %t294 = icmp eq i64 %t292, 1
  br i1 %t294, label %bb66, label %bb67
bb66:
  %t296 = load ptr, ptr %l10, !tbaa !29
  store ptr %t296, ptr %rv
  br label %ret
bb67:
  br label %bb68
bb68:
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t299 = load %"compiler/source:Span", ptr %l1
  %t300 = load i32, ptr %l3, !tbaa !23
  %t301 = load ptr, ptr %l10, !tbaa !29
  %t307 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v1, ptr %v0, ptr %v1, ptr %t298, %"compiler/source:Span" %t299, i32 %t300, i32 1, ptr %t301, ptr null)
  store ptr %t307, ptr %l153
  br label %bb69
bb69:
  %t308 = load ptr, ptr %l153, !tbaa !29
  store ptr %t308, ptr %rv
  br label %ret
bb70:
  %t309 = load ptr, ptr %l0, !tbaa !29
  store ptr %t309, ptr %l154, !tbaa !29
  %t310 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t310, ptr %l155
  %t311 = load i32, ptr %l3, !tbaa !23
  store i32 %t311, ptr %l156, !tbaa !23
  %t312 = load ptr, ptr %l0, !tbaa !29
  %t314 = getelementptr %"compiler/check:Checker", ptr %t312, i32 0, i32 1
  %t315 = load ptr, ptr %t314, !tbaa !29
  %t317 = getelementptr %"compiler/generic:Program", ptr %t315, i32 0, i32 2
  %t318 = load i32, ptr %l6, !tbaa !23
  %t319 = load i64, ptr %l8, !tbaa !24
  %t323 = call i64 @compiler_2fcheck_2elimitBits(ptr %v0, ptr %t317, i32 %t318, i64 %t319)
  store i64 %t323, ptr %l162
  br label %bb71
bb71:
  %t324 = load ptr, ptr %l154, !tbaa !29
  %t325 = load %"compiler/source:Span", ptr %l155
  %t326 = load i32, ptr %l156, !tbaa !23
  %t327 = load i64, ptr %l162, !tbaa !24
  %t328 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v1, ptr %t324, %"compiler/source:Span" %t325, i32 %t326, i64 %t327)
  store ptr %t328, ptr %l163
  br label %bb72
bb72:
  %t329 = load ptr, ptr %l163, !tbaa !29
  store ptr %t329, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ematchValueMismatch(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca ptr
  %l8 = alloca i32
  %l11 = alloca i1
  %l16 = alloca i1
  %l17 = alloca i1
  %l22 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca %"compiler/source:Span"
  %l26 = alloca ptr
  %l29 = alloca i32
  %l30 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l36 = alloca %"compiler/diagmsg:Msg"
  %l37 = alloca i64
  %l40 = alloca i32
  %l43 = alloca i1
  %l46 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca %"compiler/source:Span"
  %l51 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l53 = alloca ptr
  %l58 = alloca i32
  %l59 = alloca { i64, ptr }
  %l61 = alloca %"compiler/diagmsg:Msg"
  %l62 = alloca i64
  %l65 = alloca ptr
  %l66 = alloca %"compiler/source:Span"
  %l67 = alloca ptr
  %l71 = alloca i32
  %l74 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %l80 = alloca %"compiler/diagmsg:Msg"
  %l81 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i32 %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l4, !tbaa !29
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t1)
  store i32 %t4, ptr %l8
  br label %bb1
bb1:
  %t5 = load i32, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  %t6 = load i32, ptr %l8, !tbaa !23
  %t8 = icmp eq i32 %t6, %t5
  br i1 %t8, label %bb2, label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 2
  %t16 = load i32, ptr %l3, !tbaa !23
  %t19 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArrayRef(ptr %v0, ptr %t15, i32 %t16)
  store i1 %t19, ptr %l16
  br label %bb4
bb3:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb5
bb4:
  %t20 = load i1, ptr %l16, !tbaa !21
  store i1 %t20, ptr %l11, !tbaa !21
  br label %bb5
bb5:
  %t21 = load i1, ptr %l11, !tbaa !21
  br i1 %t21, label %bb6, label %bb7
bb6:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 2
  %t28 = load i32, ptr %l3, !tbaa !23
  %t31 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t27, i32 %t28)
  store i1 %t31, ptr %l22
  br label %bb8
bb7:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb9
bb8:
  %t32 = load i1, ptr %l22, !tbaa !21
  %t33 = xor i1 %t32, true
  store i1 %t33, ptr %l17, !tbaa !21
  br label %bb9
bb9:
  %t35 = load i1, ptr %l17, !tbaa !21
  br i1 %t35, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s1
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l24, !tbaa !29
  %t37 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t37, ptr %l25
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l26, !tbaa !29
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load i32, ptr %l3, !tbaa !23
  %t43 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t39, i32 %t40)
  store i32 %t43, ptr %l29
  br label %bb12
bb11:
  br label %bb17
bb12:
  %t44 = load ptr, ptr %l26, !tbaa !29
  %t45 = load i32, ptr %l29, !tbaa !23
  %t46 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t44, i32 %t45)
  store { i64, ptr } %t46, ptr %l30
  br label %bb13
bb13:
  %t47 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t47, 0
  %t49 = extractvalue { i64, ptr } %t47, 1
  %t50 = mul i64 %t48, 1
  %t51 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t50)
  call void @llvm.memcpy.p0.p0.i64(ptr %t51, ptr %t49, i64 %t50, i1 false)
  %t52 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t51, 1
  store { i64, ptr } %t53, ptr %l31, !tbaa !27
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load i32, ptr %l3, !tbaa !23
  %t58 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemptyArray(ptr %v0, ptr %s1, ptr %t54, i32 %t55)
  store { i64, ptr } %t58, ptr %l34
  br label %bb14
bb14:
  %t59 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t59, 0
  %t61 = extractvalue { i64, ptr } %t59, 1
  %t62 = mul i64 %t60, 1
  %t63 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t62)
  call void @llvm.memcpy.p0.p0.i64(ptr %t63, ptr %t61, i64 %t62, i1 false)
  %t64 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t63, 1
  %t66 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t68 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNullToArray(ptr %s1, ptr %s1, ptr %v0, { i64, ptr } %t66, { i64, ptr } %t65)
  store %"compiler/diagmsg:Msg" %t68, ptr %l36
  br label %bb15
bb15:
  %t69 = load ptr, ptr %l24, !tbaa !29
  %t70 = load %"compiler/source:Span", ptr %l25
  %t71 = load %"compiler/diagmsg:Msg", ptr %l36
  %t72 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t69, %"compiler/source:Span" %t70, %"compiler/diagmsg:Msg" %t71)
  store i64 %t72, ptr %l37
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb17:
  %t73 = load ptr, ptr %l4, !tbaa !29
  %t76 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t73)
  store i32 %t76, ptr %l40
  br label %bb18
bb18:
  %t77 = load i32, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  %t78 = load i32, ptr %l40, !tbaa !23
  %t80 = icmp eq i32 %t78, %t77
  br i1 %t80, label %bb19, label %bb20
bb19:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load i32, ptr %l3, !tbaa !23
  %t86 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneverNull(ptr %v0, ptr %t82, i32 %t83)
  store i1 %t86, ptr %l46
  br label %bb21
bb20:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb22
bb21:
  %t87 = load i1, ptr %l46, !tbaa !21
  store i1 %t87, ptr %l43, !tbaa !21
  br label %bb22
bb22:
  %t88 = load i1, ptr %l43, !tbaa !21
  br i1 %t88, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s2
  %t89 = load ptr, ptr %l0, !tbaa !29
  store ptr %t89, ptr %l47, !tbaa !29
  %t90 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t90, ptr %l48
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load i32, ptr %l3, !tbaa !23
  %t95 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t91, i32 %t92)
  store { i64, ptr } %t95, ptr %l51
  br label %bb25
bb24:
  br label %bb31
bb25:
  %t96 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t96, 0
  %t98 = extractvalue { i64, ptr } %t96, 1
  %t99 = mul i64 %t97, 1
  %t100 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t99)
  call void @llvm.memcpy.p0.p0.i64(ptr %t100, ptr %t98, i64 %t99, i1 false)
  %t101 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t100, 1
  store { i64, ptr } %t102, ptr %l52, !tbaa !27
  %t103 = load ptr, ptr %l0, !tbaa !29
  store ptr %t103, ptr %l53, !tbaa !29
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/check:Checker", ptr %t104, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !29
  %t109 = getelementptr %"compiler/generic:Program", ptr %t107, i32 0, i32 2
  %t110 = load i32, ptr %l3, !tbaa !23
  %t113 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %t109, i32 %t110)
  store i32 %t113, ptr %l58
  br label %bb26
bb26:
  %t114 = load ptr, ptr %l53, !tbaa !29
  %t115 = load i32, ptr %l58, !tbaa !23
  %t116 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t114, i32 %t115)
  store { i64, ptr } %t116, ptr %l59
  br label %bb27
bb27:
  %t117 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t118 = extractvalue { i64, ptr } %t117, 0
  %t119 = extractvalue { i64, ptr } %t117, 1
  %t120 = mul i64 %t118, 1
  %t121 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t120)
  call void @llvm.memcpy.p0.p0.i64(ptr %t121, ptr %t119, i64 %t120, i1 false)
  %t122 = insertvalue { i64, ptr } undef, i64 %t118, 0
  %t123 = insertvalue { i64, ptr } %t122, ptr %t121, 1
  %t124 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t126 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNullToNonNull(ptr %s2, ptr %s2, ptr %v0, { i64, ptr } %t124, { i64, ptr } %t123)
  store %"compiler/diagmsg:Msg" %t126, ptr %l61
  br label %bb28
bb28:
  %t127 = load ptr, ptr %l47, !tbaa !29
  %t128 = load %"compiler/source:Span", ptr %l48
  %t129 = load %"compiler/diagmsg:Msg", ptr %l61
  %t130 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t127, %"compiler/source:Span" %t128, %"compiler/diagmsg:Msg" %t129)
  store i64 %t130, ptr %l62
  br label %bb29
bb29:
  %t131 = load i64, ptr %l62, !tbaa !24
  %t132 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclNote(ptr %v0, ptr %t132, i64 %t131)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb31:
  %t136 = load ptr, ptr %l0, !tbaa !29
  store ptr %t136, ptr %l65, !tbaa !29
  %t137 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t137, ptr %l66
  %t138 = load ptr, ptr %l0, !tbaa !29
  store ptr %t138, ptr %l67, !tbaa !29
  %t139 = load i32, ptr %l2, !tbaa !23
  %t140 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t143 = icmp ne i32 %t139, %t140
  br i1 %t143, label %bb32, label %bb33
bb32:
  %t145 = load i32, ptr %l2, !tbaa !23
  store i32 %t145, ptr %l71, !tbaa !23
  br label %bb34
bb33:
  %t147 = load i32, ptr %l3, !tbaa !23
  store i32 %t147, ptr %l71, !tbaa !23
  br label %bb34
bb34:
  %t149 = load ptr, ptr %l67, !tbaa !29
  %t150 = load i32, ptr %l71, !tbaa !23
  %t151 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t149, i32 %t150)
  store { i64, ptr } %t151, ptr %l74
  br label %bb35
bb35:
  %t152 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t153 = extractvalue { i64, ptr } %t152, 0
  %t154 = extractvalue { i64, ptr } %t152, 1
  %t155 = mul i64 %t153, 1
  %t156 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t155)
  call void @llvm.memcpy.p0.p0.i64(ptr %t156, ptr %t154, i64 %t155, i1 false)
  %t157 = insertvalue { i64, ptr } undef, i64 %t153, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t156, 1
  store { i64, ptr } %t158, ptr %l75, !tbaa !27
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load ptr, ptr %l4, !tbaa !29
  %t163 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etyOf(ptr %v0, ptr %v1, ptr %s0, ptr %t159, ptr %t160)
  store { i64, ptr } %t163, ptr %l78
  br label %bb36
bb36:
  %t164 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t165 = extractvalue { i64, ptr } %t164, 0
  %t166 = extractvalue { i64, ptr } %t164, 1
  %t167 = mul i64 %t165, 1
  %t168 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t167)
  call void @llvm.memcpy.p0.p0.i64(ptr %t168, ptr %t166, i64 %t167, i1 false)
  %t169 = insertvalue { i64, ptr } undef, i64 %t165, 0
  %t170 = insertvalue { i64, ptr } %t169, ptr %t168, 1
  %t171 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t173 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMatchValueTypes(ptr %s0, ptr %s0, ptr %v0, { i64, ptr } %t171, { i64, ptr } %t170)
  store %"compiler/diagmsg:Msg" %t173, ptr %l80
  br label %bb37
bb37:
  %t174 = load ptr, ptr %l65, !tbaa !29
  %t175 = load %"compiler/source:Span", ptr %l66
  %t176 = load %"compiler/diagmsg:Msg", ptr %l80
  %t177 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t174, %"compiler/source:Span" %t175, %"compiler/diagmsg:Msg" %t176)
  store i64 %t177, ptr %l81
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ememberRules(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/source:Span"
  %l4 = alloca i64
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca { i64, ptr }
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca { i64, ptr }
  %l11 = alloca %"compiler/source:Span"
  %l16 = alloca i64
  %l22 = alloca ptr
  %l26 = alloca ptr
  %l28 = alloca %"compiler/source:Span"
  %l31 = alloca { i64, ptr }
  %l34 = alloca ptr
  %l35 = alloca %"compiler/source:Span"
  %l36 = alloca %"compiler/diagmsg:Msg"
  %l37 = alloca i64
  %l43 = alloca i32
  %l51 = alloca i32
  %l56 = alloca i32
  %l60 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l65 = alloca ptr
  %l68 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l71 = alloca i1
  %l72 = alloca i1
  %l77 = alloca i32
  %l81 = alloca i1
  %l86 = alloca i64
  %l88 = alloca { i64, ptr }
  %l90 = alloca { i64, ptr }
  %l92 = alloca i32
  %l94 = alloca i32
  %l97 = alloca { i64, ptr }
  %l101 = alloca %"compiler/source:Span"
  %l104 = alloca { i64, ptr }
  %l106 = alloca %"compiler/source:Span"
  %l108 = alloca i1
  %l110 = alloca ptr
  %l111 = alloca %"compiler/source:Span"
  %l112 = alloca { i64, ptr }
  %l115 = alloca { i64, ptr }
  %l118 = alloca %"compiler/diagmsg:Msg"
  %l119 = alloca i64
  %l124 = alloca i64
  %l126 = alloca ptr
  %l127 = alloca %"compiler/source:Span"
  %l128 = alloca { i64, ptr }
  %l131 = alloca { i64, ptr }
  %l133 = alloca %"compiler/diagmsg:Msg"
  %l134 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t6 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t7 = load i32, ptr %t6, !tbaa !23
  %t11 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMemberAt(ptr %v0, ptr %t4, i64 %t5, i32 %t7)
  store i64 %t11, ptr %l16
  br label %bb1
bb1:
  %t12 = load i64, ptr %l16, !tbaa !24
  store i64 %t12, ptr %l4, !tbaa !24
  %t13 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp slt i64 %t13, 0
  br i1 %t15, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load i64, ptr %l1, !tbaa !24
  %t19 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t23 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v0, ptr %t17, i64 -1, i64 %t18, i32 %t19, i32 0)
  store ptr %t23, ptr %l22
  br label %bb5
bb5:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMemberOwnerRef(ptr %v0, ptr %v0, ptr %t27, i64 %t28)
  store ptr %t31, ptr %l26
  br label %bb6
bb6:
  %t32 = load ptr, ptr %l26, !tbaa !29
  %t35 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %t32)
  store %"compiler/source:Span" %t35, ptr %l28
  br label %bb7
bb7:
  %t36 = load %"compiler/source:Span", ptr %l28
  store %"compiler/source:Span" %t36, ptr %l6
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load %"compiler/source:Span", ptr %l6
  %t41 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t37, %"compiler/source:Span" %t38)
  store { i64, ptr } %t41, ptr %l31
  br label %bb8
bb8:
  %t42 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t42, ptr %l7, !tbaa !27
  %t45 = xor i1 %a3, true
  br i1 %t45, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t47 = load ptr, ptr %l0, !tbaa !29
  store ptr %t47, ptr %l34, !tbaa !29
  %t48 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t48, ptr %l35
  %t49 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMemberInPlaceKind(ptr %s2, ptr %v0, { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d20, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t49, ptr %l36
  br label %bb11
bb10:
  br label %bb14
bb11:
  %t50 = load ptr, ptr %l34, !tbaa !29
  %t51 = load %"compiler/source:Span", ptr %l35
  %t52 = load %"compiler/diagmsg:Msg", ptr %l36
  %t53 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t50, %"compiler/source:Span" %t51, %"compiler/diagmsg:Msg" %t52)
  store i64 %t53, ptr %l37
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s2)
  %t54 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t54)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb14:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load i64, ptr %l1, !tbaa !24
  %t58 = load i64, ptr %l4, !tbaa !24
  %t59 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t64 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ememberOwnerOk(ptr %v0, ptr %v0, ptr %t56, i64 %t57, i64 %t58, { i64, ptr } %t59)
  store i32 %t64, ptr %l43
  br label %bb15
bb15:
  %t65 = load i32, ptr %l43, !tbaa !23
  store i32 %t65, ptr %l8, !tbaa !23
  %t66 = load i32, ptr %l8, !tbaa !23
  %t67 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t70 = icmp eq i32 %t66, %t67
  br i1 %t70, label %bb16, label %bb17
bb16:
  %t72 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t72)
  br label %bb18
bb17:
  br label %bb19
bb18:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb19:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/check:Checker", ptr %t74, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t78 = load i64, ptr %l4, !tbaa !24
  %t81 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMemberName(ptr %v0, ptr %t77, i64 %t78)
  store i32 %t81, ptr %l51
  br label %bb20
bb20:
  %t82 = load i32, ptr %l51, !tbaa !23
  store i32 %t82, ptr %l9, !tbaa !23
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/check:Checker", ptr %t83, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = getelementptr %"compiler/generic:Program", ptr %t86, i32 0, i32 2
  %t89 = load i32, ptr %l8, !tbaa !23
  %t92 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t88, i32 %t89)
  store i32 %t92, ptr %l56
  br label %bb21
bb21:
  %t93 = load i32, ptr %l56, !range !{i32 0, i32 33}
  %t95 = trunc i64 25 to i32
  %t96 = icmp eq i32 %t93, %t95
  %t98 = xor i1 %t96, true
  br i1 %t98, label %bb22, label %bb23
bb22:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load i32, ptr %l8, !tbaa !23
  %t102 = load i32, ptr %l9, !tbaa !23
  %t106 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamespaceTaken(ptr %v0, ptr %s0, ptr %t100, i32 %t101, i32 %t102)
  store { i64, ptr } %t106, ptr %l64
  br label %bb24
bb23:
  %t107 = load ptr, ptr %l0, !tbaa !29
  store ptr %t107, ptr %l65, !tbaa !29
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load i32, ptr %l9, !tbaa !23
  %t112 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t108, i32 %t109)
  store { i64, ptr } %t112, ptr %l68
  br label %bb25
bb24:
  %t113 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t113, ptr %l60, !tbaa !27
  br label %bb27
bb25:
  %t114 = load ptr, ptr %l65, !tbaa !29
  %t115 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t116 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflectedName(ptr %v0, ptr %v0, ptr %s0, ptr %t114, { i64, ptr } %t115)
  store { i64, ptr } %t116, ptr %l69
  br label %bb26
bb26:
  %t117 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t117, ptr %l60, !tbaa !27
  br label %bb27
bb27:
  %t118 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t118, ptr %l10, !tbaa !27
  %t119 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t121 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t119, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d21, i32 0, i32 1) })
  store i1 %t121, ptr %l71
  br label %bb28
bb28:
  %t122 = load i1, ptr %l71, !tbaa !21
  br i1 %t122, label %bb29, label %bb30
bb29:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/check:Checker", ptr %t123, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !29
  %t128 = getelementptr %"compiler/generic:Program", ptr %t126, i32 0, i32 2
  %t129 = load i32, ptr %l8, !tbaa !23
  %t132 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t128, i32 %t129)
  store i32 %t132, ptr %l77
  br label %bb31
bb30:
  store i1 false, ptr %l72, !tbaa !21
  br label %bb32
bb31:
  %t133 = load i32, ptr %l77, !range !{i32 0, i32 33}
  %t135 = trunc i64 25 to i32
  %t136 = icmp eq i32 %t133, %t135
  %t138 = xor i1 %t136, true
  store i1 %t138, ptr %l72, !tbaa !21
  br label %bb32
bb32:
  %t140 = load i1, ptr %l72, !tbaa !21
  br i1 %t140, label %bb33, label %bb34
bb33:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/check:Checker", ptr %t141, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !29
  %t145 = load i32, ptr %l8, !tbaa !23
  %t146 = load i32, ptr %l9, !tbaa !23
  %t150 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBuilderOf(ptr %v0, ptr %t144, i32 %t145, i32 %t146, i1 false)
  store i64 %t150, ptr %l86
  br label %bb35
bb34:
  store i1 false, ptr %l81, !tbaa !21
  br label %bb36
bb35:
  %t151 = load i64, ptr %l86, !tbaa !24
  %t152 = icmp sge i64 %t151, 0
  store i1 %t152, ptr %l81, !tbaa !21
  br label %bb36
bb36:
  %t154 = load i1, ptr %l81, !tbaa !21
  br i1 %t154, label %bb37, label %bb38
bb37:
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d22, i32 0, i32 1) }, ptr %l88, !tbaa !27
  %t155 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t156 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t156, ptr %l90, !tbaa !27
  store { i64, ptr } %t155, ptr %l10, !tbaa !27
  %t158 = load i1, ptr @olang_2esole_2ecompiler__2fcheck__2ecompiler__2fcheck__3aChecker__2ememberRules_2elocal_2e10
  br i1 %t158, label %bb39, label %bb40
bb38:
  br label %bb41
bb39:
  %t160 = load { i64, ptr }, ptr %l90
  %t161 = extractvalue { i64, ptr } %t160, 1
  call void @__olang_region_release(ptr %t161)
  store { i64, ptr } zeroinitializer, ptr %l90
  br label %bb40
bb40:
  br label %bb41
bb41:
  %t162 = getelementptr %"compiler/source:Span", ptr %l6, i32 0, i32 0
  %t163 = load i32, ptr %t162, !tbaa !23
  store i32 %t163, ptr %l92, !tbaa !23
  %t164 = getelementptr %"compiler/source:Span", ptr %l6, i32 0, i32 1
  %t165 = load i32, ptr %t164, !tbaa !23
  %t167 = add i32 %t165, 1
  store i32 %t167, ptr %l94, !tbaa !23
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t169 = load i32, ptr %l9, !tbaa !23
  %t172 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s0, ptr %t168, i32 %t169)
  store { i64, ptr } %t172, ptr %l97
  br label %bb42
bb42:
  %t173 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t174 = extractvalue { i64, ptr } %t173, 0
  %t176 = trunc i64 %t174 to i32
  %t177 = load i32, ptr %l94, !tbaa !23
  %t179 = add i32 %t177, %t176
  %t180 = load i32, ptr %l92, !tbaa !23
  %t182 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t180, i32 %t179)
  store %"compiler/source:Span" %t182, ptr %l101
  br label %bb43
bb43:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t184 = load i32, ptr %l9, !tbaa !23
  %t187 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s0, ptr %t183, i32 %t184)
  store { i64, ptr } %t187, ptr %l104
  br label %bb44
bb44:
  %t188 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t189 = extractvalue { i64, ptr } %t188, 0
  %t190 = load %"compiler/source:Span", ptr %l101
  %t192 = call %"compiler/source:Span" @compiler_2fcheck_2ememberSpan(%"compiler/source:Span" %t190, i64 %t189)
  store %"compiler/source:Span" %t192, ptr %l106
  br label %bb45
bb45:
  %t193 = load %"compiler/source:Span", ptr %l106
  store %"compiler/source:Span" %t193, ptr %l11
  %t194 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t196 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t194, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d23, i32 0, i32 1) })
  store i1 %t196, ptr %l108
  br label %bb46
bb46:
  %t197 = load i1, ptr %l108, !tbaa !21
  %t198 = xor i1 %t197, true
  br i1 %t198, label %bb47, label %bb48
bb47:
  store %olang.scope zeroinitializer, ptr %s7
  %t200 = load ptr, ptr %l0, !tbaa !29
  store ptr %t200, ptr %l110, !tbaa !29
  %t201 = load %"compiler/source:Span", ptr %l11
  store %"compiler/source:Span" %t201, ptr %l111
  %t202 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t202, ptr %l112, !tbaa !27
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load i32, ptr %l9, !tbaa !23
  %t207 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s7, ptr %t203, i32 %t204)
  store { i64, ptr } %t207, ptr %l115
  br label %bb49
bb48:
  br label %bb53
bb49:
  %t208 = load { i64, ptr }, ptr %l115, !tbaa !27
  %t209 = extractvalue { i64, ptr } %t208, 0
  %t210 = extractvalue { i64, ptr } %t208, 1
  %t211 = mul i64 %t209, 1
  %t212 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t211)
  call void @llvm.memcpy.p0.p0.i64(ptr %t212, ptr %t210, i64 %t211, i1 false)
  %t213 = insertvalue { i64, ptr } undef, i64 %t209, 0
  %t214 = insertvalue { i64, ptr } %t213, ptr %t212, 1
  %t215 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t216 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t219 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMemberNameTaken(ptr %v0, ptr %s7, ptr %s0, ptr %v0, { i64, ptr } %t216, { i64, ptr } %t214, { i64, ptr } %t215)
  store %"compiler/diagmsg:Msg" %t219, ptr %l118
  br label %bb50
bb50:
  %t220 = load ptr, ptr %l110, !tbaa !29
  %t221 = load %"compiler/source:Span", ptr %l111
  %t222 = load %"compiler/diagmsg:Msg", ptr %l118
  %t223 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t220, %"compiler/source:Span" %t221, %"compiler/diagmsg:Msg" %t222)
  store i64 %t223, ptr %l119
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s7)
  %t224 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t224)
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb53:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr %"compiler/check:Checker", ptr %t226, i32 0, i32 1
  %t229 = load ptr, ptr %t228, !tbaa !29
  %t230 = load i64, ptr %l4, !tbaa !24
  %t233 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMemberBefore(ptr %v0, ptr %t229, i64 %t230)
  store i64 %t233, ptr %l124
  br label %bb54
bb54:
  %t234 = load i64, ptr %l124, !tbaa !24
  %t235 = icmp sge i64 %t234, 0
  br i1 %t235, label %bb55, label %bb56
bb55:
  store %olang.scope zeroinitializer, ptr %s9
  %t237 = load ptr, ptr %l0, !tbaa !29
  store ptr %t237, ptr %l126, !tbaa !29
  %t238 = load %"compiler/source:Span", ptr %l11
  store %"compiler/source:Span" %t238, ptr %l127
  %t239 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t239, ptr %l128, !tbaa !27
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t241 = load i32, ptr %l9, !tbaa !23
  %t244 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s9, ptr %t240, i32 %t241)
  store { i64, ptr } %t244, ptr %l131
  br label %bb57
bb56:
  br label %bb60
bb57:
  %t245 = load { i64, ptr }, ptr %l131, !tbaa !27
  %t246 = extractvalue { i64, ptr } %t245, 0
  %t247 = extractvalue { i64, ptr } %t245, 1
  %t248 = mul i64 %t246, 1
  %t249 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t248)
  call void @llvm.memcpy.p0.p0.i64(ptr %t249, ptr %t247, i64 %t248, i1 false)
  %t250 = insertvalue { i64, ptr } undef, i64 %t246, 0
  %t251 = insertvalue { i64, ptr } %t250, ptr %t249, 1
  %t252 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t254 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMemberTwice(ptr %v0, ptr %s9, ptr %v0, { i64, ptr } %t252, { i64, ptr } %t251)
  store %"compiler/diagmsg:Msg" %t254, ptr %l133
  br label %bb58
bb58:
  %t255 = load ptr, ptr %l126, !tbaa !29
  %t256 = load %"compiler/source:Span", ptr %l127
  %t257 = load %"compiler/diagmsg:Msg", ptr %l133
  %t258 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t255, %"compiler/source:Span" %t256, %"compiler/diagmsg:Msg" %t257)
  store i64 %t258, ptr %l134
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s9)
  br label %bb60
bb60:
  %t259 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t259)
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emodOfFile(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l12 = alloca i64
  %l16 = alloca i64
  %l19 = alloca i64
  %l42 = alloca ptr
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 10
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l12
  br label %bb1
bb1:
  %t12 = load i64, ptr %l12, !tbaa !24
  store i64 %t12, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t13 = load i64, ptr %l3, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t17 = icmp sgt i64 %t13, %t14
  br i1 %t17, label %bb2, label %bb3
bb2:
  %t19 = load i64, ptr %l4, !tbaa !24
  %t21 = icmp sgt i64 %t19, 0
  br i1 %t21, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb7
bb4:
  %t23 = load i64, ptr %l3, !tbaa !24
  %t24 = load i64, ptr %l2, !tbaa !24
  %t27 = sub i64 %t23, %t24
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = add i64 %t27, %t28
  %t33 = sub i64 %t31, 1
  %t34 = load i64, ptr %l4, !tbaa !24
  %t37 = sdiv i64 %t33, %t34
  store i64 %t37, ptr %l19, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb6
bb6:
  %t39 = load i64, ptr %l19, !tbaa !24
  store i64 %t39, ptr %l16, !tbaa !24
  br label %bb7
bb7:
  %t40 = load i64, ptr %l16, !tbaa !24
  store i64 %t40, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  %t41 = load i64, ptr %l6, !tbaa !24
  %t42 = load i64, ptr %l5, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb9, label %bb10
bb9:
  br label %bb17
bb10:
  br label %bb11
bb11:
  %t49 = load i64, ptr %l2, !tbaa !24
  %t50 = load i64, ptr %l6, !tbaa !24
  %t51 = load i64, ptr %l4, !tbaa !24
  %t54 = mul i64 %t50, %t51
  %t57 = add i64 %t49, %t54
  store i64 %t57, ptr %l7, !tbaa !24
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Program", ptr %t62, i32 0, i32 0
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/load:Loader", ptr %t65, i32 0, i32 10
  %t68 = load i64, ptr %l7, !tbaa !24
  %t71 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t67, i64 %t68)
  store ptr %t71, ptr %l42
  br label %bb12
bb12:
  %t72 = load ptr, ptr %l42, !tbaa !29
  %t74 = getelementptr %"compiler/load:Module", ptr %t72, i32 0, i32 4
  %t75 = load i64, ptr %t74, !tbaa !24
  %t79 = icmp eq i64 %t75, %a1
  br i1 %t79, label %bb13, label %bb14
bb13:
  %t81 = load i64, ptr %l7, !tbaa !24
  store i64 %t81, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t83 = load i64, ptr %l6, !tbaa !24
  %t85 = add i64 %t83, 1
  store i64 %t85, ptr %l6, !tbaa !24
  br label %bb8
bb17:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamedArgUnknown(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, { i64, ptr } %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca %"compiler/msgs:Nearest"
  %l22 = alloca { i64, ptr }
  %l29 = alloca ptr
  %l33 = alloca { i64, ptr }
  %l40 = alloca ptr
  %l41 = alloca %"compiler/source:Span"
  %l44 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l51 = alloca %"compiler/diagmsg:Msg"
  %l52 = alloca i64
  %l53 = alloca ptr
  %l54 = alloca %"compiler/source:Span"
  %l57 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l62 = alloca %"compiler/diagmsg:Msg"
  %l63 = alloca i64
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t1, i32 %t2)
  store { i64, ptr } %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t7 = call %"compiler/msgs:Nearest" @compiler_2fmsgs_3aNearest_2ector(ptr %v0, ptr %s0, { i64, ptr } %t6)
  store %"compiler/msgs:Nearest" %t7, ptr %l13
  br label %bb2
bb2:
  %t8 = load %"compiler/msgs:Nearest", ptr %l13
  %t9 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 40, i64 8)
  store %"compiler/msgs:Nearest" %t8, ptr %t9
  store ptr %t9, ptr %l5, !tbaa !29
  store { i64, ptr } %a3, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t13 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  store i64 %t15, ptr %l8, !tbaa !24
  br label %bb3
bb3:
  %t17 = load i64, ptr %l7, !tbaa !24
  %t18 = load i64, ptr %l8, !tbaa !24
  %t21 = icmp slt i64 %t17, %t18
  %t23 = xor i1 %t21, true
  br i1 %t23, label %bb4, label %bb5
bb4:
  br label %bb13
bb5:
  br label %bb6
bb6:
  %t25 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t25, ptr %l22, !tbaa !27
  %t26 = load i64, ptr %l7, !tbaa !24
  %t28 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr ptr, ptr %t29, i64 %t26
  %t31 = load ptr, ptr %t30, !tbaa !39
  store ptr %t31, ptr %l9, !tbaa !29
  %t33 = load ptr, ptr %l9, !tbaa !29
  %t35 = getelementptr %"compiler/ast:Param", ptr %t33, i32 0, i32 3
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = icmp eq ptr %t36, null
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb7, label %bb8
bb7:
  %t42 = load ptr, ptr %l5, !tbaa !29
  store ptr %t42, ptr %l29, !tbaa !29
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load ptr, ptr %l9, !tbaa !29
  %t46 = getelementptr %"compiler/ast:Param", ptr %t44, i32 0, i32 1
  %t47 = load i32, ptr %t46, !tbaa !23
  %t50 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t43, i32 %t47)
  store { i64, ptr } %t50, ptr %l33
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t51 = load ptr, ptr %l29, !tbaa !29
  %t52 = load { i64, ptr }, ptr %l33, !tbaa !27
  call void @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eOffer(ptr %s0, ptr %v0, ptr %t51, { i64, ptr } %t52)
  br label %bb10
bb10:
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t53 = load i64, ptr %l7, !tbaa !24
  %t55 = add i64 %t53, 1
  store i64 %t55, ptr %l7, !tbaa !24
  br label %bb3
bb13:
  %t57 = load ptr, ptr %l5, !tbaa !29
  %t59 = getelementptr %"compiler/msgs:Nearest", ptr %t57, i32 0, i32 1
  %t60 = load { i64, ptr }, ptr %t59, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t60, 0
  %t64 = icmp sgt i64 %t62, 0
  br i1 %t64, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s5
  %t66 = load ptr, ptr %l0, !tbaa !29
  store ptr %t66, ptr %l40, !tbaa !29
  %t67 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t67, ptr %l41
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i32, ptr %l2, !tbaa !23
  %t72 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s5, ptr %t68, i32 %t69)
  store { i64, ptr } %t72, ptr %l44
  br label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s6
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l53, !tbaa !29
  %t74 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t74, ptr %l54
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load i32, ptr %l2, !tbaa !23
  %t79 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s6, ptr %t75, i32 %t76)
  store { i64, ptr } %t79, ptr %l57
  br label %bb20
bb16:
  %t80 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t80, 0
  %t82 = extractvalue { i64, ptr } %t80, 1
  %t83 = mul i64 %t81, 1
  %t84 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t83)
  call void @llvm.memcpy.p0.p0.i64(ptr %t84, ptr %t82, i64 %t83, i1 false)
  %t85 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t84, 1
  store { i64, ptr } %t86, ptr %l45, !tbaa !27
  %t87 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t89 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v2, ptr %s5, { i64, ptr } %t87)
  store { i64, ptr } %t89, ptr %l47
  br label %bb17
bb17:
  %t90 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t90, 0
  %t92 = extractvalue { i64, ptr } %t90, 1
  %t93 = mul i64 %t91, 1
  %t94 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t93)
  call void @llvm.memcpy.p0.p0.i64(ptr %t94, ptr %t92, i64 %t93, i1 false)
  %t95 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %t94, 1
  %t97 = load ptr, ptr %l5, !tbaa !29
  %t99 = getelementptr %"compiler/msgs:Nearest", ptr %t97, i32 0, i32 1
  %t100 = load { i64, ptr }, ptr %t99, !tbaa !27
  %t101 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t104 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNamedArgUnknownMeant(ptr %s5, ptr %s5, ptr %s0, ptr %v0, { i64, ptr } %t101, { i64, ptr } %t96, { i64, ptr } %t100)
  store %"compiler/diagmsg:Msg" %t104, ptr %l51
  br label %bb18
bb18:
  %t105 = load ptr, ptr %l40, !tbaa !29
  %t106 = load %"compiler/source:Span", ptr %l41
  %t107 = load %"compiler/diagmsg:Msg", ptr %l51
  %t108 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t105, %"compiler/source:Span" %t106, %"compiler/diagmsg:Msg" %t107)
  store i64 %t108, ptr %l52
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s5)
  br label %bb24
bb20:
  %t109 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t109, 0
  %t111 = extractvalue { i64, ptr } %t109, 1
  %t112 = mul i64 %t110, 1
  %t113 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t112)
  call void @llvm.memcpy.p0.p0.i64(ptr %t113, ptr %t111, i64 %t112, i1 false)
  %t114 = insertvalue { i64, ptr } undef, i64 %t110, 0
  %t115 = insertvalue { i64, ptr } %t114, ptr %t113, 1
  store { i64, ptr } %t115, ptr %l58, !tbaa !27
  %t116 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t118 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v2, ptr %s6, { i64, ptr } %t116)
  store { i64, ptr } %t118, ptr %l60
  br label %bb21
bb21:
  %t119 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t119, 0
  %t121 = extractvalue { i64, ptr } %t119, 1
  %t122 = mul i64 %t120, 1
  %t123 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t122)
  call void @llvm.memcpy.p0.p0.i64(ptr %t123, ptr %t121, i64 %t122, i1 false)
  %t124 = insertvalue { i64, ptr } undef, i64 %t120, 0
  %t125 = insertvalue { i64, ptr } %t124, ptr %t123, 1
  %t126 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t128 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNamedArgUnknown(ptr %s6, ptr %s6, ptr %v0, { i64, ptr } %t126, { i64, ptr } %t125)
  store %"compiler/diagmsg:Msg" %t128, ptr %l62
  br label %bb22
bb22:
  %t129 = load ptr, ptr %l53, !tbaa !29
  %t130 = load %"compiler/source:Span", ptr %l54
  %t131 = load %"compiler/diagmsg:Msg", ptr %l62
  %t132 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t129, %"compiler/source:Span" %t130, %"compiler/diagmsg:Msg" %t131)
  store i64 %t132, ptr %l63
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s6)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowedName(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i1
  %l15 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca i64
  %l24 = alloca i64
  %l26 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca i1
  %l33 = alloca { i64, ptr }
  %l40 = alloca i64
  %l43 = alloca ptr
  %l45 = alloca %"compiler/source:Span"
  %l47 = alloca ptr
  %l51 = alloca %"compiler/check:narrowed"
  %l57 = alloca i64
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 28}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb16
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l3, !tbaa !23
  %t20 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %t16, i32 %t17)
  store i64 %t20, ptr %l15
  br label %bb6
bb6:
  %t21 = load i64, ptr %l15, !tbaa !24
  store i64 %t21, ptr %l4, !tbaa !24
  %t22 = load i64, ptr %l4, !tbaa !24
  %t24 = icmp sge i64 %t22, 0
  br i1 %t24, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l18, !tbaa !29
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l19, !tbaa !29
  %t28 = load i64, ptr %l4, !tbaa !24
  store i64 %t28, ptr %l20, !tbaa !24
  %t29 = icmp sge i64 0, 0
  br i1 %t29, label %bb9, label %bb10
bb8:
  br label %bb15
bb9:
  %t31 = icmp sle i64 0, 2305843009213693951
  br i1 %t31, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_aca5fbea7f148a0b_8298f5f4d8f3acbf)
  unreachable
bb11:
  %t33 = mul i64 0, 4
  %t34 = insertvalue { i64, ptr } undef, i64 0, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t36 = load ptr, ptr %l19, !tbaa !29
  %t37 = load i64, ptr %l20, !tbaa !24
  %t39 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseNarrowing(ptr %v0, ptr %s2, ptr %t36, i64 %t37, { i64, ptr } %t35)
  store i64 %t39, ptr %l24
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_aca5fbea7f148a0b_8298f5f4d8f3acbf)
  unreachable
bb13:
  %t40 = load i32, ptr %l2, !tbaa !23
  %t41 = load ptr, ptr %l18, !tbaa !29
  %t42 = load i64, ptr %l24, !tbaa !24
  %t44 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowedField(ptr %v0, ptr %t41, i64 %t42, i32 %t40)
  store i64 %t44, ptr %l26
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s2)
  %t45 = load i64, ptr %l26, !tbaa !24
  store i64 %t45, ptr %rv
  br label %ret
bb15:
  br label %bb40
bb16:
  %t46 = load ptr, ptr %l1, !tbaa !29
  store ptr %t46, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t47 = load ptr, ptr %l27, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb17, label %bb18
bb17:
  %t50 = load ptr, ptr %l27, !tbaa !29
  %t51 = load i64, ptr %t50, !range !{i64 0, i64 28}
  %t53 = icmp eq i64 %t51, 12
  store i1 %t53, ptr %l28, !tbaa !21
  br label %bb18
bb18:
  %t54 = load i1, ptr %l28, !tbaa !21
  br i1 %t54, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb35
bb21:
  store %olang.scope zeroinitializer, ptr %s3
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load ptr, ptr %l1, !tbaa !29
  %t59 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowPath(ptr %v0, ptr %v1, ptr %s3, ptr %t55, ptr %t56)
  store { i64, ptr } %t59, ptr %l33
  br label %bb22
bb22:
  %t60 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t60, ptr %l5, !tbaa !27
  %t61 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t61, 0
  %t65 = icmp slt i64 %t63, 2
  br i1 %t65, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s3)
  store i64 -1, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t72 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseNarrowing(ptr %v0, ptr %s3, ptr %t68, i64 -1, { i64, ptr } %t69)
  store i64 %t72, ptr %l40
  br label %bb26
bb26:
  %t73 = load i64, ptr %l40, !tbaa !24
  store i64 %t73, ptr %l6, !tbaa !24
  %t74 = load i64, ptr %l6, !tbaa !24
  %t76 = icmp sge i64 %t74, 0
  br i1 %t76, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s5
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l43, !tbaa !29
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t79)
  store %"compiler/source:Span" %t81, ptr %l45
  br label %bb29
bb28:
  br label %bb33
bb29:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t82)
  store ptr %t84, ptr %l47
  br label %bb30
bb30:
  %t85 = load ptr, ptr %l47, !tbaa !29
  %t87 = getelementptr %"compiler/check:frame", ptr %t85, i32 0, i32 46
  %t88 = load i64, ptr %l6, !tbaa !24
  %t91 = call %"compiler/check:narrowed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eAt_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %s5, ptr %t87, i64 %t88)
  store %"compiler/check:narrowed" %t91, ptr %l51
  br label %bb31
bb31:
  %t92 = getelementptr %"compiler/check:narrowed", ptr %l51, i32 0, i32 6
  %t93 = load i64, ptr %t92, !tbaa !24
  %t94 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t95 = load ptr, ptr %l43, !tbaa !29
  %t96 = load %"compiler/source:Span", ptr %l45
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epathRead(ptr %v0, ptr %s3, ptr %t95, %"compiler/source:Span" %t96, i64 %t93, { i64, ptr } %t94)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s5)
  br label %bb33
bb33:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load i64, ptr %l6, !tbaa !24
  %t101 = load i32, ptr %l2, !tbaa !23
  %t105 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowedField(ptr %v0, ptr %t99, i64 %t100, i32 %t101)
  store i64 %t105, ptr %l57
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s3)
  %t106 = load i64, ptr %l57, !tbaa !24
  store i64 %t106, ptr %rv
  br label %ret
bb35:
  br i1 true, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_e6a66df527b36ded_181f8bf364cc8869)
  unreachable
bb40:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eorderModule(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca { i64, [2 x i64] }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca i64
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i1
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i64
  %l64 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l65 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l68 = alloca i64
  %l70 = alloca i64
  %l75 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l79 = alloca i64
  %l83 = alloca i64
  %l84 = alloca i32
  %l87 = alloca i1
  %l91 = alloca ptr
  %l95 = alloca i1
  %l98 = alloca i1
  %l99 = alloca ptr
  %l100 = alloca i64
  %l102 = alloca i64
  %l109 = alloca i64
  %l113 = alloca i64
  %l116 = alloca i64
  %l137 = alloca ptr
  %l146 = alloca i1
  %l150 = alloca ptr
  %l155 = alloca i1
  %l158 = alloca i1
  %l160 = alloca ptr
  %l161 = alloca i64
  %l163 = alloca i64
  %l169 = alloca i64
  %l170 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l171 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l173 = alloca i64
  %l175 = alloca i64
  %l180 = alloca i64
  %l181 = alloca ptr
  %l183 = alloca i64
  %l187 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l189 = alloca i64
  %l191 = alloca i64
  %l196 = alloca i64
  %l197 = alloca ptr
  %l198 = alloca i64
  %l201 = alloca i64
  %l202 = alloca i32
  %l207 = alloca ptr
  %l209 = alloca i64
  %l210 = alloca i64
  %l221 = alloca i64
  %l224 = alloca i64
  %l246 = alloca i64
  %l250 = alloca i64
  %l254 = alloca i64
  %l257 = alloca i64
  %l277 = alloca i64
  %l279 = alloca i1
  %l282 = alloca i64
  %l294 = alloca ptr
  %l297 = alloca i64
  %l305 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l306 = alloca i64
  %l309 = alloca i64
  %l310 = alloca i32
  %l319 = alloca i64
  %l323 = alloca i64
  %l326 = alloca i64
  %l346 = alloca i64
  %l347 = alloca ptr
  %l348 = alloca ptr
  %l351 = alloca i64
  %l352 = alloca i64
  %l361 = alloca i64
  %l365 = alloca i64
  %l369 = alloca i64
  %l372 = alloca i64
  %l392 = alloca i1
  %l395 = alloca i64
  %l397 = alloca i1
  %l400 = alloca i64
  %l405 = alloca i64
  %l414 = alloca i64
  %l417 = alloca i64
  %l438 = alloca ptr
  %l441 = alloca i64
  %s0 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s18 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l64
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l64
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l3
  %t3 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t3, ptr %l65
  br label %bb2
bb2:
  %t4 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l65
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t4, ptr %l4
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 34
  store ptr %t7, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb3
bb3:
  %t9 = load i64, ptr %l6, !tbaa !24
  store i64 %t9, ptr %l68, !tbaa !24
  %t10 = load ptr, ptr %l5, !tbaa !29
  %t12 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_Hda4ef06466535e66801340e999dad217(ptr %v0, ptr %t10)
  store i64 %t12, ptr %l70
  br label %bb4
bb4:
  %t13 = load i64, ptr %l68, !tbaa !24
  %t14 = load i64, ptr %l70, !tbaa !24
  %t15 = icmp slt i64 %t13, %t14
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb5, label %bb6
bb5:
  br label %bb31
bb6:
  br label %bb7
bb7:
  %t19 = load ptr, ptr %l5, !tbaa !29
  %t20 = load i64, ptr %l6, !tbaa !24
  %t23 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_H87a29777ccf22aa2985fa9d3c61f9cd3(ptr %v0, ptr %t19, i64 %t20)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t23, ptr %l75
  br label %bb8
bb8:
  %t24 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l75
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t24, ptr %l7
  %t25 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l7, i32 0, i32 0
  %t26 = load i64, ptr %t25, !tbaa !24
  %t27 = load i64, ptr %l1, !tbaa !24
  %t30 = icmp ne i64 %t26, %t27
  br i1 %t30, label %bb9, label %bb10
bb9:
  br label %bb30
bb10:
  br label %bb11
bb11:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 32
  %t35 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l7
  %t38 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %t34, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t35)
  %t39 = extractvalue { i32, i64 } %t38, 1
  %t40 = extractvalue { i32, i64 } %t38, 0
  store i32 %t40, ptr %l84
  %t41 = icmp ne i32 %t40, 0
  br i1 %t41, label %bb13, label %ok.42, !prof !99
ok.42:
  store i64 %t39, ptr %l83
  br label %bb12
bb12:
  %t43 = load i64, ptr %l83, !tbaa !24
  store i64 %t43, ptr %l79, !tbaa !24
  br label %bb15
bb13:
  br label %bb14
bb14:
  store i64 -1, ptr %l79, !tbaa !24
  br label %bb15
bb15:
  %t44 = load i64, ptr %l79, !tbaa !24
  store i64 %t44, ptr %l8, !tbaa !24
  %t45 = load i64, ptr %l8, !tbaa !24
  %t47 = icmp slt i64 %t45, 0
  br i1 %t47, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l87, !tbaa !21
  br label %bb19
bb17:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/check:Checker", ptr %t49, i32 0, i32 18
  %t52 = load i64, ptr %l8, !tbaa !24
  %t55 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t51, i64 %t52)
  store ptr %t55, ptr %l91
  br label %bb18
bb18:
  %t56 = load ptr, ptr %l91, !tbaa !29
  %t58 = getelementptr %"compiler/typed:Body", ptr %t56, i32 0, i32 11
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = icmp eq ptr %t59, null
  store i1 %t61, ptr %l87, !tbaa !21
  br label %bb19
bb19:
  %t63 = load i1, ptr %l87, !tbaa !21
  br i1 %t63, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l95, !tbaa !21
  br label %bb23
bb21:
  %t64 = load i64, ptr %l8, !tbaa !24
  %t67 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %s0, ptr %l4, i64 %t64)
  store i1 %t67, ptr %l98
  br label %bb22
bb22:
  %t68 = load i1, ptr %l98, !tbaa !21
  store i1 %t68, ptr %l95, !tbaa !21
  br label %bb23
bb23:
  %t69 = load i1, ptr %l95, !tbaa !21
  br i1 %t69, label %bb24, label %bb25
bb24:
  br label %bb30
bb25:
  br label %bb26
bb26:
  store ptr %l4, ptr %l99, !tbaa !29
  %t70 = load i64, ptr %l8, !tbaa !24
  store i64 %t70, ptr %l100, !tbaa !24
  %t72 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l3)
  store i64 %t72, ptr %l102
  br label %bb27
bb27:
  %t73 = load ptr, ptr %l99, !tbaa !29
  %t74 = load i64, ptr %l100, !tbaa !24
  %t75 = load i64, ptr %l102, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %s0, ptr %t73, i64 %t74, i64 %t75)
  br label %bb28
bb28:
  %t76 = load i64, ptr %l8, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l3, i64 %t76)
  br label %bb29
bb29:
  br label %bb30
bb30:
  %t79 = load i64, ptr %l6, !tbaa !24
  %t81 = add i64 %t79, 1
  store i64 %t81, ptr %l6, !tbaa !24
  br label %bb3
bb31:
  store i64 0, ptr %l9, !tbaa !24
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/check:Checker", ptr %t83, i32 0, i32 18
  %t87 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t85)
  store i64 %t87, ptr %l109
  br label %bb32
bb32:
  %t88 = load i64, ptr %l109, !tbaa !24
  store i64 %t88, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t89 = load i64, ptr %l10, !tbaa !24
  %t90 = load i64, ptr %l9, !tbaa !24
  %t93 = icmp sgt i64 %t89, %t90
  br i1 %t93, label %bb33, label %bb34
bb33:
  %t95 = load i64, ptr %l11, !tbaa !24
  %t97 = icmp sgt i64 %t95, 0
  br i1 %t97, label %bb35, label %bb36
bb34:
  store i64 0, ptr %l113, !tbaa !24
  br label %bb38
bb35:
  %t99 = load i64, ptr %l10, !tbaa !24
  %t100 = load i64, ptr %l9, !tbaa !24
  %t103 = sub i64 %t99, %t100
  %t104 = load i64, ptr %l11, !tbaa !24
  %t107 = add i64 %t103, %t104
  %t109 = sub i64 %t107, 1
  %t110 = load i64, ptr %l11, !tbaa !24
  %t113 = sdiv i64 %t109, %t110
  store i64 %t113, ptr %l116, !tbaa !24
  br label %bb37
bb36:
  store i64 0, ptr %l116, !tbaa !24
  br label %bb37
bb37:
  %t115 = load i64, ptr %l116, !tbaa !24
  store i64 %t115, ptr %l113, !tbaa !24
  br label %bb38
bb38:
  %t116 = load i64, ptr %l113, !tbaa !24
  store i64 %t116, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb39
bb39:
  %t117 = load i64, ptr %l13, !tbaa !24
  %t118 = load i64, ptr %l12, !tbaa !24
  %t121 = icmp slt i64 %t117, %t118
  %t123 = xor i1 %t121, true
  br i1 %t123, label %bb40, label %bb41
bb40:
  br label %bb68
bb41:
  br label %bb42
bb42:
  %t125 = load i64, ptr %l9, !tbaa !24
  %t126 = load i64, ptr %l13, !tbaa !24
  %t127 = load i64, ptr %l11, !tbaa !24
  %t130 = mul i64 %t126, %t127
  %t133 = add i64 %t125, %t130
  store i64 %t133, ptr %l14, !tbaa !24
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/check:Checker", ptr %t135, i32 0, i32 18
  %t138 = load i64, ptr %l14, !tbaa !24
  %t141 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t137, i64 %t138)
  store ptr %t141, ptr %l137
  br label %bb43
bb43:
  %t142 = load ptr, ptr %l137, !tbaa !29
  %t144 = getelementptr %"compiler/typed:Body", ptr %t142, i32 0, i32 1
  %t145 = load { i64, [2 x i64] }, ptr %t144
  store { i64, [2 x i64] } %t145, ptr %l15
  %t147 = load { i64, [2 x i64] }, ptr %l15
  %t149 = extractvalue { i64, [2 x i64] } %t147, 0
  %t150 = icmp eq i64 %t149, 6
  br i1 %t150, label %bb44, label %bb45
bb44:
  %t152 = getelementptr { i64, [2 x i64] }, ptr %l15, i32 0, i32 1
  %t153 = getelementptr { i64, i32 }, ptr %t152, i32 0, i32 0
  %t154 = load i64, ptr %t153
  store i64 %t154, ptr %l16, !tbaa !24
  br label %bb46
bb45:
  br label %bb61
bb46:
  %t156 = load i64, ptr %l16, !tbaa !24
  %t157 = load i64, ptr %l1, !tbaa !24
  %t160 = icmp eq i64 %t156, %t157
  br i1 %t160, label %bb47, label %bb48
bb47:
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr %"compiler/check:Checker", ptr %t162, i32 0, i32 18
  %t165 = load i64, ptr %l14, !tbaa !24
  %t168 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t164, i64 %t165)
  store ptr %t168, ptr %l150
  br label %bb49
bb48:
  store i1 false, ptr %l146, !tbaa !21
  br label %bb50
bb49:
  %t169 = load ptr, ptr %l150, !tbaa !29
  %t171 = getelementptr %"compiler/typed:Body", ptr %t169, i32 0, i32 11
  %t172 = load ptr, ptr %t171, !tbaa !29
  %t174 = icmp eq ptr %t172, null
  %t176 = xor i1 %t174, true
  store i1 %t176, ptr %l146, !tbaa !21
  br label %bb50
bb50:
  %t178 = load i1, ptr %l146, !tbaa !21
  br i1 %t178, label %bb51, label %bb52
bb51:
  %t179 = load i64, ptr %l14, !tbaa !24
  %t182 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %s0, ptr %l4, i64 %t179)
  store i1 %t182, ptr %l158
  br label %bb53
bb52:
  store i1 false, ptr %l155, !tbaa !21
  br label %bb54
bb53:
  %t183 = load i1, ptr %l158, !tbaa !21
  %t184 = xor i1 %t183, true
  store i1 %t184, ptr %l155, !tbaa !21
  br label %bb54
bb54:
  %t186 = load i1, ptr %l155, !tbaa !21
  br i1 %t186, label %bb55, label %bb56
bb55:
  store ptr %l4, ptr %l160, !tbaa !29
  %t187 = load i64, ptr %l14, !tbaa !24
  store i64 %t187, ptr %l161, !tbaa !24
  %t189 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l3)
  store i64 %t189, ptr %l163
  br label %bb57
bb56:
  br label %bb60
bb57:
  %t190 = load ptr, ptr %l160, !tbaa !29
  %t191 = load i64, ptr %l161, !tbaa !24
  %t192 = load i64, ptr %l163, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %s0, ptr %t190, i64 %t191, i64 %t192)
  br label %bb58
bb58:
  %t193 = load i64, ptr %l14, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l3, i64 %t193)
  br label %bb59
bb59:
  br label %bb60
bb60:
  br label %bb66
bb61:
  br i1 true, label %bb62, label %bb63
bb62:
  br label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb66
bb65:
  call void @__olang_check_failed(ptr @olang_loc_eb65b3680edb0345_685145072e457a11)
  unreachable
bb66:
  br label %bb67
bb67:
  %t196 = load i64, ptr %l13, !tbaa !24
  %t198 = add i64 %t196, 1
  store i64 %t198, ptr %l13, !tbaa !24
  br label %bb39
bb68:
  %t201 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l3)
  store i64 %t201, ptr %l169
  br label %bb69
bb69:
  %t202 = load i64, ptr %l169, !tbaa !24
  store i64 %t202, ptr %l17, !tbaa !24
  %t203 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t203, ptr %l170
  br label %bb70
bb70:
  %t204 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l170
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t204, ptr %l18
  %t205 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t205, ptr %l171
  br label %bb71
bb71:
  %t206 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l171
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t206, ptr %l19
  store ptr %l3, ptr %l20, !tbaa !29
  store i64 0, ptr %l21, !tbaa !24
  br label %bb72
bb72:
  %t208 = load i64, ptr %l21, !tbaa !24
  store i64 %t208, ptr %l173, !tbaa !24
  %t209 = load ptr, ptr %l20, !tbaa !29
  %t211 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t209)
  store i64 %t211, ptr %l175
  br label %bb73
bb73:
  %t212 = load i64, ptr %l173, !tbaa !24
  %t213 = load i64, ptr %l175, !tbaa !24
  %t214 = icmp slt i64 %t212, %t213
  %t216 = xor i1 %t214, true
  br i1 %t216, label %bb74, label %bb75
bb74:
  br label %bb95
bb75:
  br label %bb76
bb76:
  %t218 = load ptr, ptr %l20, !tbaa !29
  %t219 = load i64, ptr %l21, !tbaa !24
  %t222 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t218, i64 %t219)
  store i64 %t222, ptr %l180
  br label %bb77
bb77:
  %t223 = load i64, ptr %l180, !tbaa !24
  store i64 %t223, ptr %l22, !tbaa !24
  store ptr %l18, ptr %l181, !tbaa !29
  %t225 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l19)
  store i64 %t225, ptr %l183
  br label %bb78
bb78:
  %t226 = load ptr, ptr %l181, !tbaa !29
  %t227 = load i64, ptr %l183, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t226, i64 %t227)
  br label %bb79
bb79:
  store %olang.scope zeroinitializer, ptr %s14
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t229 = load i64, ptr %l1, !tbaa !24
  %t230 = load i64, ptr %l22, !tbaa !24
  %t234 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalDeps(ptr %v0, ptr %s14, ptr %t228, i64 %t229, i64 %t230)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t234, ptr %l187
  br label %bb80
bb80:
  %t235 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l187
  %t236 = call ptr @__olang_scope_alloc_a(ptr %s14, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t235, ptr %t236
  store ptr %t236, ptr %l23, !tbaa !29
  store i64 0, ptr %l24, !tbaa !24
  br label %bb81
bb81:
  %t238 = load i64, ptr %l24, !tbaa !24
  store i64 %t238, ptr %l189, !tbaa !24
  %t239 = load ptr, ptr %l23, !tbaa !29
  %t241 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s14, ptr %t239)
  store i64 %t241, ptr %l191
  br label %bb82
bb82:
  %t242 = load i64, ptr %l189, !tbaa !24
  %t243 = load i64, ptr %l191, !tbaa !24
  %t244 = icmp slt i64 %t242, %t243
  %t246 = xor i1 %t244, true
  br i1 %t246, label %bb83, label %bb84
bb83:
  br label %bb93
bb84:
  br label %bb85
bb85:
  %t248 = load ptr, ptr %l23, !tbaa !29
  %t249 = load i64, ptr %l24, !tbaa !24
  %t252 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s14, ptr %t248, i64 %t249)
  store i64 %t252, ptr %l196
  br label %bb86
bb86:
  %t253 = load i64, ptr %l196, !tbaa !24
  store ptr %l19, ptr %l197, !tbaa !29
  %t257 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %s0, ptr %l4, i64 %t253)
  %t258 = extractvalue { i32, i64 } %t257, 1
  %t259 = extractvalue { i32, i64 } %t257, 0
  store i32 %t259, ptr %l202
  %t260 = icmp ne i32 %t259, 0
  br i1 %t260, label %bb88, label %ok.261, !prof !99
ok.261:
  store i64 %t258, ptr %l201
  br label %bb87
bb87:
  %t262 = load i64, ptr %l201, !tbaa !24
  store i64 %t262, ptr %l198, !tbaa !24
  br label %bb90
bb88:
  br label %bb89
bb89:
  store i64 -1, ptr %l198, !tbaa !24
  br label %bb90
bb90:
  %t263 = load ptr, ptr %l197, !tbaa !29
  %t264 = load i64, ptr %l198, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t263, i64 %t264)
  br label %bb91
bb91:
  br label %bb92
bb92:
  %t265 = load i64, ptr %l24, !tbaa !24
  %t267 = add i64 %t265, 1
  store i64 %t267, ptr %l24, !tbaa !24
  br label %bb81
bb93:
  call void @__olang_scope_close(ptr %s14)
  br label %bb94
bb94:
  %t269 = load i64, ptr %l21, !tbaa !24
  %t271 = add i64 %t269, 1
  store i64 %t271, ptr %l21, !tbaa !24
  br label %bb72
bb95:
  store ptr %l18, ptr %l207, !tbaa !29
  %t274 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l19)
  store i64 %t274, ptr %l209
  br label %bb96
bb96:
  %t275 = load ptr, ptr %l207, !tbaa !29
  %t276 = load i64, ptr %l209, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t275, i64 %t276)
  br label %bb97
bb97:
  %t277 = load i64, ptr %l17, !tbaa !24
  store i64 %t277, ptr %l210, !tbaa !24
  %t278 = load i64, ptr %l210, !tbaa !24
  %t279 = icmp sge i64 %t278, 0
  br i1 %t279, label %bb98, label %bb99
bb98:
  %t281 = load i64, ptr %l210, !tbaa !24
  %t282 = mul i64 %t281, 1
  %t283 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t282)
  %t284 = insertvalue { i64, ptr } undef, i64 %t281, 0
  %t285 = insertvalue { i64, ptr } %t284, ptr %t283, 1
  store { i64, ptr } %t285, ptr %l26, !tbaa !27
  store i64 0, ptr %l27, !tbaa !24
  br label %bb100
bb99:
  call void @__olang_check_failed(ptr @olang_loc_becd3eb77e076db3_2d856a700a1e74b7)
  unreachable
bb100:
  store %olang.scope zeroinitializer, ptr %s18
  %t287 = load i64, ptr %l27, !tbaa !24
  %t288 = load i64, ptr %l17, !tbaa !24
  %t291 = icmp slt i64 %t287, %t288
  %t293 = xor i1 %t291, true
  br i1 %t293, label %bb101, label %bb102
bb101:
  call void @__olang_scope_close(ptr %s18)
  br label %bb232
bb102:
  br label %bb103
bb103:
  store i64 -1, ptr %l28, !tbaa !24
  store i64 0, ptr %l29, !tbaa !24
  %t295 = load i64, ptr %l17, !tbaa !24
  store i64 %t295, ptr %l30, !tbaa !24
  store i64 1, ptr %l31, !tbaa !24
  %t297 = load i64, ptr %l30, !tbaa !24
  %t298 = load i64, ptr %l29, !tbaa !24
  %t301 = icmp sgt i64 %t297, %t298
  br i1 %t301, label %bb104, label %bb105
bb104:
  %t303 = load i64, ptr %l31, !tbaa !24
  %t305 = icmp sgt i64 %t303, 0
  br i1 %t305, label %bb106, label %bb107
bb105:
  store i64 0, ptr %l221, !tbaa !24
  br label %bb109
bb106:
  %t307 = load i64, ptr %l30, !tbaa !24
  %t308 = load i64, ptr %l29, !tbaa !24
  %t311 = sub i64 %t307, %t308
  %t312 = load i64, ptr %l31, !tbaa !24
  %t315 = add i64 %t311, %t312
  %t317 = sub i64 %t315, 1
  %t318 = load i64, ptr %l31, !tbaa !24
  %t321 = sdiv i64 %t317, %t318
  store i64 %t321, ptr %l224, !tbaa !24
  br label %bb108
bb107:
  store i64 0, ptr %l224, !tbaa !24
  br label %bb108
bb108:
  %t323 = load i64, ptr %l224, !tbaa !24
  store i64 %t323, ptr %l221, !tbaa !24
  br label %bb109
bb109:
  %t324 = load i64, ptr %l221, !tbaa !24
  store i64 %t324, ptr %l32, !tbaa !24
  store i64 0, ptr %l33, !tbaa !24
  br label %bb110
bb110:
  %t325 = load i64, ptr %l33, !tbaa !24
  %t326 = load i64, ptr %l32, !tbaa !24
  %t329 = icmp slt i64 %t325, %t326
  %t331 = xor i1 %t329, true
  br i1 %t331, label %bb111, label %bb112
bb111:
  br label %bb143
bb112:
  br label %bb113
bb113:
  %t333 = load i64, ptr %l29, !tbaa !24
  %t334 = load i64, ptr %l33, !tbaa !24
  %t335 = load i64, ptr %l31, !tbaa !24
  %t338 = mul i64 %t334, %t335
  %t341 = add i64 %t333, %t338
  store i64 %t341, ptr %l34, !tbaa !24
  %t343 = load i64, ptr %l34, !tbaa !24
  %t345 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t346 = load ptr, ptr %t345, !tbaa !27
  %t347 = getelementptr i1, ptr %t346, i64 %t343
  %t348 = load i1, ptr %t347, !tbaa !31
  br i1 %t348, label %bb114, label %bb115
bb114:
  br label %bb142
bb115:
  br label %bb116
bb116:
  store i1 true, ptr %l35, !tbaa !21
  %t350 = load i64, ptr %l34, !tbaa !24
  %t353 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l18, i64 %t350)
  store i64 %t353, ptr %l246
  br label %bb117
bb117:
  %t354 = load i64, ptr %l246, !tbaa !24
  store i64 %t354, ptr %l36, !tbaa !24
  %t355 = load i64, ptr %l34, !tbaa !24
  %t357 = add i64 %t355, 1
  %t360 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l18, i64 %t357)
  store i64 %t360, ptr %l250
  br label %bb118
bb118:
  %t361 = load i64, ptr %l250, !tbaa !24
  store i64 %t361, ptr %l37, !tbaa !24
  store i64 1, ptr %l38, !tbaa !24
  %t362 = load i64, ptr %l37, !tbaa !24
  %t363 = load i64, ptr %l36, !tbaa !24
  %t366 = icmp sgt i64 %t362, %t363
  br i1 %t366, label %bb119, label %bb120
bb119:
  %t368 = load i64, ptr %l38, !tbaa !24
  %t370 = icmp sgt i64 %t368, 0
  br i1 %t370, label %bb121, label %bb122
bb120:
  store i64 0, ptr %l254, !tbaa !24
  br label %bb124
bb121:
  %t372 = load i64, ptr %l37, !tbaa !24
  %t373 = load i64, ptr %l36, !tbaa !24
  %t376 = sub i64 %t372, %t373
  %t377 = load i64, ptr %l38, !tbaa !24
  %t380 = add i64 %t376, %t377
  %t382 = sub i64 %t380, 1
  %t383 = load i64, ptr %l38, !tbaa !24
  %t386 = sdiv i64 %t382, %t383
  store i64 %t386, ptr %l257, !tbaa !24
  br label %bb123
bb122:
  store i64 0, ptr %l257, !tbaa !24
  br label %bb123
bb123:
  %t388 = load i64, ptr %l257, !tbaa !24
  store i64 %t388, ptr %l254, !tbaa !24
  br label %bb124
bb124:
  %t389 = load i64, ptr %l254, !tbaa !24
  store i64 %t389, ptr %l39, !tbaa !24
  store i64 0, ptr %l40, !tbaa !24
  br label %bb125
bb125:
  %t390 = load i64, ptr %l40, !tbaa !24
  %t391 = load i64, ptr %l39, !tbaa !24
  %t394 = icmp slt i64 %t390, %t391
  %t396 = xor i1 %t394, true
  br i1 %t396, label %bb126, label %bb127
bb126:
  br label %bb138
bb127:
  br label %bb128
bb128:
  %t398 = load i64, ptr %l36, !tbaa !24
  %t399 = load i64, ptr %l40, !tbaa !24
  %t400 = load i64, ptr %l38, !tbaa !24
  %t403 = mul i64 %t399, %t400
  %t406 = add i64 %t398, %t403
  store i64 %t406, ptr %l41, !tbaa !24
  %t408 = load i64, ptr %l41, !tbaa !24
  %t411 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l19, i64 %t408)
  store i64 %t411, ptr %l277
  br label %bb129
bb129:
  %t412 = load i64, ptr %l277, !tbaa !24
  %t413 = icmp sge i64 %t412, 0
  br i1 %t413, label %bb130, label %bb131
bb130:
  %t415 = load i64, ptr %l41, !tbaa !24
  %t418 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l19, i64 %t415)
  store i64 %t418, ptr %l282
  br label %bb132
bb131:
  store i1 false, ptr %l279, !tbaa !21
  br label %bb133
bb132:
  %t419 = load i64, ptr %l282, !tbaa !24
  %t420 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t421 = load ptr, ptr %t420, !tbaa !27
  %t422 = getelementptr i1, ptr %t421, i64 %t419
  %t423 = load i1, ptr %t422, !tbaa !31
  %t425 = xor i1 %t423, true
  store i1 %t425, ptr %l279, !tbaa !21
  br label %bb133
bb133:
  %t427 = load i1, ptr %l279, !tbaa !21
  br i1 %t427, label %bb134, label %bb135
bb134:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb136
bb135:
  br label %bb136
bb136:
  br label %bb137
bb137:
  %t428 = load i64, ptr %l40, !tbaa !24
  %t430 = add i64 %t428, 1
  store i64 %t430, ptr %l40, !tbaa !24
  br label %bb125
bb138:
  %t432 = load i1, ptr %l35, !tbaa !21
  br i1 %t432, label %bb139, label %bb140
bb139:
  %t434 = load i64, ptr %l34, !tbaa !24
  store i64 %t434, ptr %l28, !tbaa !24
  br label %bb143
bb140:
  br label %bb141
bb141:
  br label %bb142
bb142:
  %t436 = load i64, ptr %l33, !tbaa !24
  %t438 = add i64 %t436, 1
  store i64 %t438, ptr %l33, !tbaa !24
  br label %bb110
bb143:
  %t440 = load i64, ptr %l28, !tbaa !24
  %t442 = icmp sge i64 %t440, 0
  br i1 %t442, label %bb144, label %bb145
bb144:
  %t444 = load i64, ptr %l28, !tbaa !24
  %t446 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t447 = load ptr, ptr %t446, !tbaa !27
  %t448 = getelementptr i1, ptr %t447, i64 %t444
  store i1 true, ptr %t448, !tbaa !31
  %t449 = load ptr, ptr %l2, !tbaa !29
  store ptr %t449, ptr %l294, !tbaa !29
  %t450 = load i64, ptr %l28, !tbaa !24
  %t453 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l3, i64 %t450)
  store i64 %t453, ptr %l297
  br label %bb146
bb145:
  br label %bb148
bb146:
  %t454 = load ptr, ptr %l294, !tbaa !29
  %t455 = load i64, ptr %l297, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t454, i64 %t455)
  br label %bb147
bb147:
  %t456 = load i64, ptr %l27, !tbaa !24
  %t458 = add i64 %t456, 1
  store i64 %t458, ptr %l27, !tbaa !24
  call void @__olang_scope_close(ptr %s18)
  br label %bb231
bb148:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb149
bb149:
  %t460 = load i64, ptr %l42, !tbaa !24
  %t462 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t463 = load ptr, ptr %t462, !tbaa !27
  %t464 = getelementptr i1, ptr %t463, i64 %t460
  %t465 = load i1, ptr %t464, !tbaa !31
  %t467 = xor i1 %t465, true
  br i1 %t467, label %bb150, label %bb151
bb150:
  br label %bb154
bb151:
  br label %bb152
bb152:
  %t469 = load i64, ptr %l42, !tbaa !24
  %t471 = add i64 %t469, 1
  store i64 %t471, ptr %l42, !tbaa !24
  br label %bb153
bb153:
  br label %bb149
bb154:
  %t473 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s18, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t473, ptr %l305
  br label %bb155
bb155:
  %t474 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l305
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t474, ptr %l43
  br label %bb156
bb156:
  %t475 = load i64, ptr %l42, !tbaa !24
  %t478 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eIndexOf_3cI64_3e(ptr %s18, ptr %l43, i64 %t475)
  %t479 = extractvalue { i32, i64 } %t478, 1
  %t480 = extractvalue { i32, i64 } %t478, 0
  store i32 %t480, ptr %l310
  %t481 = icmp ne i32 %t480, 0
  br i1 %t481, label %bb158, label %ok.482, !prof !99
ok.482:
  store i64 %t479, ptr %l309
  br label %bb157
bb157:
  %t483 = load i64, ptr %l309, !tbaa !24
  store i64 %t483, ptr %l306, !tbaa !24
  br label %bb160
bb158:
  br label %bb159
bb159:
  store i64 -1, ptr %l306, !tbaa !24
  br label %bb160
bb160:
  %t484 = load i64, ptr %l306, !tbaa !24
  store i64 %t484, ptr %l44, !tbaa !24
  %t485 = load i64, ptr %l44, !tbaa !24
  %t487 = icmp sge i64 %t485, 0
  br i1 %t487, label %bb161, label %bb162
bb161:
  %t489 = load ptr, ptr %l0, !tbaa !29
  %t490 = load i64, ptr %l44, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aCycle(ptr %v0, ptr %s0, ptr %s18, ptr %t489, ptr %l3, ptr %l43, i64 %t490)
  br label %bb163
bb162:
  br label %bb181
bb163:
  %t495 = load i64, ptr %l44, !tbaa !24
  store i64 %t495, ptr %l45, !tbaa !24
  %t498 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s18, ptr %l43)
  store i64 %t498, ptr %l319
  br label %bb164
bb164:
  %t499 = load i64, ptr %l319, !tbaa !24
  store i64 %t499, ptr %l46, !tbaa !24
  store i64 1, ptr %l47, !tbaa !24
  %t500 = load i64, ptr %l46, !tbaa !24
  %t501 = load i64, ptr %l45, !tbaa !24
  %t504 = icmp sgt i64 %t500, %t501
  br i1 %t504, label %bb165, label %bb166
bb165:
  %t506 = load i64, ptr %l47, !tbaa !24
  %t508 = icmp sgt i64 %t506, 0
  br i1 %t508, label %bb167, label %bb168
bb166:
  store i64 0, ptr %l323, !tbaa !24
  br label %bb170
bb167:
  %t510 = load i64, ptr %l46, !tbaa !24
  %t511 = load i64, ptr %l45, !tbaa !24
  %t514 = sub i64 %t510, %t511
  %t515 = load i64, ptr %l47, !tbaa !24
  %t518 = add i64 %t514, %t515
  %t520 = sub i64 %t518, 1
  %t521 = load i64, ptr %l47, !tbaa !24
  %t524 = sdiv i64 %t520, %t521
  store i64 %t524, ptr %l326, !tbaa !24
  br label %bb169
bb168:
  store i64 0, ptr %l326, !tbaa !24
  br label %bb169
bb169:
  %t526 = load i64, ptr %l326, !tbaa !24
  store i64 %t526, ptr %l323, !tbaa !24
  br label %bb170
bb170:
  %t527 = load i64, ptr %l323, !tbaa !24
  store i64 %t527, ptr %l48, !tbaa !24
  store i64 0, ptr %l49, !tbaa !24
  br label %bb171
bb171:
  %t528 = load i64, ptr %l49, !tbaa !24
  %t529 = load i64, ptr %l48, !tbaa !24
  %t532 = icmp slt i64 %t528, %t529
  %t534 = xor i1 %t532, true
  br i1 %t534, label %bb172, label %bb173
bb172:
  br label %bb180
bb173:
  br label %bb174
bb174:
  %t536 = load i64, ptr %l45, !tbaa !24
  %t537 = load i64, ptr %l49, !tbaa !24
  %t538 = load i64, ptr %l47, !tbaa !24
  %t541 = mul i64 %t537, %t538
  %t544 = add i64 %t536, %t541
  store i64 %t544, ptr %l50, !tbaa !24
  %t546 = load i64, ptr %l50, !tbaa !24
  %t549 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s18, ptr %l43, i64 %t546)
  store i64 %t549, ptr %l346
  br label %bb175
bb175:
  %t550 = load i64, ptr %l346, !tbaa !24
  %t551 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t552 = load ptr, ptr %t551, !tbaa !27
  %t553 = getelementptr i1, ptr %t552, i64 %t550
  store i1 true, ptr %t553, !tbaa !31
  %t554 = load ptr, ptr %l2, !tbaa !29
  store ptr %t554, ptr %l347, !tbaa !29
  store ptr %l3, ptr %l348, !tbaa !29
  %t555 = load i64, ptr %l50, !tbaa !24
  %t558 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s18, ptr %l43, i64 %t555)
  store i64 %t558, ptr %l351
  br label %bb176
bb176:
  %t559 = load ptr, ptr %l348, !tbaa !29
  %t560 = load i64, ptr %l351, !tbaa !24
  %t561 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t559, i64 %t560)
  store i64 %t561, ptr %l352
  br label %bb177
bb177:
  %t562 = load ptr, ptr %l347, !tbaa !29
  %t563 = load i64, ptr %l352, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t562, i64 %t563)
  br label %bb178
bb178:
  %t564 = load i64, ptr %l27, !tbaa !24
  %t566 = add i64 %t564, 1
  store i64 %t566, ptr %l27, !tbaa !24
  br label %bb179
bb179:
  %t568 = load i64, ptr %l49, !tbaa !24
  %t570 = add i64 %t568, 1
  store i64 %t570, ptr %l49, !tbaa !24
  br label %bb171
bb180:
  br label %bb230
bb181:
  %t572 = load i64, ptr %l42, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s18, ptr %l43, i64 %t572)
  br label %bb182
bb182:
  store i64 -1, ptr %l51, !tbaa !24
  %t575 = load i64, ptr %l42, !tbaa !24
  %t578 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l18, i64 %t575)
  store i64 %t578, ptr %l361
  br label %bb183
bb183:
  %t579 = load i64, ptr %l361, !tbaa !24
  store i64 %t579, ptr %l52, !tbaa !24
  %t580 = load i64, ptr %l42, !tbaa !24
  %t582 = add i64 %t580, 1
  %t585 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l18, i64 %t582)
  store i64 %t585, ptr %l365
  br label %bb184
bb184:
  %t586 = load i64, ptr %l365, !tbaa !24
  store i64 %t586, ptr %l53, !tbaa !24
  store i64 1, ptr %l54, !tbaa !24
  %t587 = load i64, ptr %l53, !tbaa !24
  %t588 = load i64, ptr %l52, !tbaa !24
  %t591 = icmp sgt i64 %t587, %t588
  br i1 %t591, label %bb185, label %bb186
bb185:
  %t593 = load i64, ptr %l54, !tbaa !24
  %t595 = icmp sgt i64 %t593, 0
  br i1 %t595, label %bb187, label %bb188
bb186:
  store i64 0, ptr %l369, !tbaa !24
  br label %bb190
bb187:
  %t597 = load i64, ptr %l53, !tbaa !24
  %t598 = load i64, ptr %l52, !tbaa !24
  %t601 = sub i64 %t597, %t598
  %t602 = load i64, ptr %l54, !tbaa !24
  %t605 = add i64 %t601, %t602
  %t607 = sub i64 %t605, 1
  %t608 = load i64, ptr %l54, !tbaa !24
  %t611 = sdiv i64 %t607, %t608
  store i64 %t611, ptr %l372, !tbaa !24
  br label %bb189
bb188:
  store i64 0, ptr %l372, !tbaa !24
  br label %bb189
bb189:
  %t613 = load i64, ptr %l372, !tbaa !24
  store i64 %t613, ptr %l369, !tbaa !24
  br label %bb190
bb190:
  %t614 = load i64, ptr %l369, !tbaa !24
  store i64 %t614, ptr %l55, !tbaa !24
  store i64 0, ptr %l56, !tbaa !24
  br label %bb191
bb191:
  %t615 = load i64, ptr %l56, !tbaa !24
  %t616 = load i64, ptr %l55, !tbaa !24
  %t619 = icmp slt i64 %t615, %t616
  %t621 = xor i1 %t619, true
  br i1 %t621, label %bb192, label %bb193
bb192:
  br label %bb208
bb193:
  br label %bb194
bb194:
  %t623 = load i64, ptr %l52, !tbaa !24
  %t624 = load i64, ptr %l56, !tbaa !24
  %t625 = load i64, ptr %l54, !tbaa !24
  %t628 = mul i64 %t624, %t625
  %t631 = add i64 %t623, %t628
  store i64 %t631, ptr %l57, !tbaa !24
  %t633 = load i64, ptr %l51, !tbaa !24
  %t635 = icmp slt i64 %t633, 0
  br i1 %t635, label %bb195, label %bb196
bb195:
  %t637 = load i64, ptr %l57, !tbaa !24
  %t640 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l19, i64 %t637)
  store i64 %t640, ptr %l395
  br label %bb197
bb196:
  store i1 false, ptr %l392, !tbaa !21
  br label %bb198
bb197:
  %t641 = load i64, ptr %l395, !tbaa !24
  %t642 = icmp sge i64 %t641, 0
  store i1 %t642, ptr %l392, !tbaa !21
  br label %bb198
bb198:
  %t644 = load i1, ptr %l392, !tbaa !21
  br i1 %t644, label %bb199, label %bb200
bb199:
  %t645 = load i64, ptr %l57, !tbaa !24
  %t648 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l19, i64 %t645)
  store i64 %t648, ptr %l400
  br label %bb201
bb200:
  store i1 false, ptr %l397, !tbaa !21
  br label %bb202
bb201:
  %t649 = load i64, ptr %l400, !tbaa !24
  %t650 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t651 = load ptr, ptr %t650, !tbaa !27
  %t652 = getelementptr i1, ptr %t651, i64 %t649
  %t653 = load i1, ptr %t652, !tbaa !31
  %t655 = xor i1 %t653, true
  store i1 %t655, ptr %l397, !tbaa !21
  br label %bb202
bb202:
  %t657 = load i1, ptr %l397, !tbaa !21
  br i1 %t657, label %bb203, label %bb204
bb203:
  %t658 = load i64, ptr %l57, !tbaa !24
  %t661 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l19, i64 %t658)
  store i64 %t661, ptr %l405
  br label %bb205
bb204:
  br label %bb206
bb205:
  %t662 = load i64, ptr %l405, !tbaa !24
  store i64 %t662, ptr %l51, !tbaa !24
  br label %bb206
bb206:
  br label %bb207
bb207:
  %t663 = load i64, ptr %l56, !tbaa !24
  %t665 = add i64 %t663, 1
  store i64 %t665, ptr %l56, !tbaa !24
  br label %bb191
bb208:
  %t667 = load i64, ptr %l51, !tbaa !24
  %t669 = icmp slt i64 %t667, 0
  br i1 %t669, label %bb209, label %bb210
bb209:
  store i64 0, ptr %l58, !tbaa !24
  %t671 = load i64, ptr %l17, !tbaa !24
  store i64 %t671, ptr %l59, !tbaa !24
  store i64 1, ptr %l60, !tbaa !24
  %t673 = load i64, ptr %l59, !tbaa !24
  %t674 = load i64, ptr %l58, !tbaa !24
  %t677 = icmp sgt i64 %t673, %t674
  br i1 %t677, label %bb211, label %bb212
bb210:
  br label %bb228
bb211:
  %t679 = load i64, ptr %l60, !tbaa !24
  %t681 = icmp sgt i64 %t679, 0
  br i1 %t681, label %bb213, label %bb214
bb212:
  store i64 0, ptr %l414, !tbaa !24
  br label %bb216
bb213:
  %t683 = load i64, ptr %l59, !tbaa !24
  %t684 = load i64, ptr %l58, !tbaa !24
  %t687 = sub i64 %t683, %t684
  %t688 = load i64, ptr %l60, !tbaa !24
  %t691 = add i64 %t687, %t688
  %t693 = sub i64 %t691, 1
  %t694 = load i64, ptr %l60, !tbaa !24
  %t697 = sdiv i64 %t693, %t694
  store i64 %t697, ptr %l417, !tbaa !24
  br label %bb215
bb214:
  store i64 0, ptr %l417, !tbaa !24
  br label %bb215
bb215:
  %t699 = load i64, ptr %l417, !tbaa !24
  store i64 %t699, ptr %l414, !tbaa !24
  br label %bb216
bb216:
  %t700 = load i64, ptr %l414, !tbaa !24
  store i64 %t700, ptr %l61, !tbaa !24
  store i64 0, ptr %l62, !tbaa !24
  br label %bb217
bb217:
  %t701 = load i64, ptr %l62, !tbaa !24
  %t702 = load i64, ptr %l61, !tbaa !24
  %t705 = icmp slt i64 %t701, %t702
  %t707 = xor i1 %t705, true
  br i1 %t707, label %bb218, label %bb219
bb218:
  br label %bb227
bb219:
  br label %bb220
bb220:
  %t709 = load i64, ptr %l58, !tbaa !24
  %t710 = load i64, ptr %l62, !tbaa !24
  %t711 = load i64, ptr %l60, !tbaa !24
  %t714 = mul i64 %t710, %t711
  %t717 = add i64 %t709, %t714
  store i64 %t717, ptr %l63, !tbaa !24
  %t719 = load i64, ptr %l63, !tbaa !24
  %t721 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t722 = load ptr, ptr %t721, !tbaa !27
  %t723 = getelementptr i1, ptr %t722, i64 %t719
  %t724 = load i1, ptr %t723, !tbaa !31
  br i1 %t724, label %bb221, label %bb222
bb221:
  br label %bb226
bb222:
  br label %bb223
bb223:
  %t726 = load i64, ptr %l63, !tbaa !24
  %t728 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t729 = load ptr, ptr %t728, !tbaa !27
  %t730 = getelementptr i1, ptr %t729, i64 %t726
  store i1 true, ptr %t730, !tbaa !31
  %t731 = load ptr, ptr %l2, !tbaa !29
  store ptr %t731, ptr %l438, !tbaa !29
  %t732 = load i64, ptr %l63, !tbaa !24
  %t735 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l3, i64 %t732)
  store i64 %t735, ptr %l441
  br label %bb224
bb224:
  %t736 = load ptr, ptr %l438, !tbaa !29
  %t737 = load i64, ptr %l441, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t736, i64 %t737)
  br label %bb225
bb225:
  %t738 = load i64, ptr %l27, !tbaa !24
  %t740 = add i64 %t738, 1
  store i64 %t740, ptr %l27, !tbaa !24
  br label %bb226
bb226:
  %t742 = load i64, ptr %l62, !tbaa !24
  %t744 = add i64 %t742, 1
  store i64 %t744, ptr %l62, !tbaa !24
  br label %bb217
bb227:
  br label %bb230
bb228:
  %t746 = load i64, ptr %l51, !tbaa !24
  store i64 %t746, ptr %l42, !tbaa !24
  br label %bb229
bb229:
  br label %bb156
bb230:
  call void @__olang_scope_close(ptr %s18)
  br label %bb231
bb231:
  br label %bb100
bb232:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eownLit(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, ptr }
  %lp3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l19 = alloca ptr
  %l20 = alloca %"compiler/source:Span"
  %l21 = alloca %"compiler/diagmsg:Msg"
  %l22 = alloca i64
  %l25 = alloca ptr
  %l28 = alloca i64
  %l33 = alloca ptr
  %l35 = alloca i64
  %l42 = alloca i32
  %l48 = alloca ptr
  %l51 = alloca i32
  %l54 = alloca i1
  %l60 = alloca ptr
  %l63 = alloca i64
  %l69 = alloca i64
  %l72 = alloca i64
  %l91 = alloca { i64, ptr }
  %l97 = alloca ptr
  %l100 = alloca i1
  %l102 = alloca ptr
  %l104 = alloca ptr
  %l105 = alloca { i64, ptr }
  %l108 = alloca %"compiler/source:Span"
  %l110 = alloca i1
  %l112 = alloca ptr
  %l115 = alloca ptr
  %l121 = alloca { i64, ptr }
  %l124 = alloca ptr
  %l125 = alloca i32
  %l128 = alloca ptr
  %l130 = alloca i32
  %l133 = alloca i32
  %l134 = alloca i32
  %l135 = alloca %"compiler/source:Span"
  %l136 = alloca i32
  %l137 = alloca i32
  %l138 = alloca { i64, ptr }
  %l142 = alloca i32
  %l144 = alloca %"compiler/typed:Make"
  %s1 = alloca %olang.scope
  %rv = alloca ptr
  %t269 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l19, !tbaa !29
  %t8 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t8, ptr %l20
  %t9 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLiteralNoTarget(ptr %s1, ptr %s1, ptr %v0, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d24, i32 0, i32 1) }, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d25, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t9, ptr %l21
  br label %bb3
bb2:
  br label %bb6
bb3:
  %t10 = load ptr, ptr %l19, !tbaa !29
  %t11 = load %"compiler/source:Span", ptr %l20
  %t12 = load %"compiler/diagmsg:Msg", ptr %l21
  %t13 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t10, %"compiler/source:Span" %t11, %"compiler/diagmsg:Msg" %t12)
  store i64 %t13, ptr %l22
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load %"compiler/source:Span", ptr %l1
  %t18 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t14, %"compiler/source:Span" %t15)
  store ptr %t18, ptr %l25
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s1)
  %t19 = load ptr, ptr %l25, !tbaa !29
  store ptr %t19, ptr %rv
  br label %ret
bb6:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t24 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eentryAt(ptr %v0, ptr %v1, ptr %t20, { i64, ptr } %t21)
  store i64 %t24, ptr %l28
  br label %bb7
bb7:
  %t25 = load i64, ptr %l28, !tbaa !24
  %t26 = icmp sge i64 %t25, 0
  br i1 %t26, label %bb8, label %bb9
bb8:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load %"compiler/source:Span", ptr %l1
  %t30 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t34 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eownMap(ptr %v0, ptr %v1, ptr %v2, ptr %t28, %"compiler/source:Span" %t29, { i64, ptr } %t30)
  store ptr %t34, ptr %l33
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t35 = load ptr, ptr %l33, !tbaa !29
  store ptr %t35, ptr %rv
  br label %ret
bb11:
  %t36 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t36, 0
  store i64 %t38, ptr %l35, !tbaa !24
  %t39 = load i64, ptr %l35, !tbaa !24
  %t40 = icmp sge i64 %t39, 0
  br i1 %t40, label %bb12, label %bb13
bb12:
  %t42 = load i64, ptr %l35, !tbaa !24
  %t43 = icmp sle i64 %t42, 1152921504606846975
  br i1 %t43, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_78b67e7b86d014f7_b202530d028f16d3)
  unreachable
bb14:
  %t45 = load i64, ptr %l35, !tbaa !24
  %t46 = mul i64 %t45, 8
  %t47 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t46)
  %t48 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t47, 1
  %t50 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t50, ptr %lp3
  %t52 = load ptr, ptr %lp3
  store { i64, ptr } %t49, ptr %t52, !tbaa !27
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t55 = load ptr, ptr %lp3
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t60 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eownElem(ptr %v0, ptr %v1, ptr %v2, ptr %t53, { i64, ptr } %t54, { i64, ptr } %t56)
  store i32 %t60, ptr %l42
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_78b67e7b86d014f7_b202530d028f16d3)
  unreachable
bb16:
  %t61 = load i32, ptr %l42, !tbaa !23
  store i32 %t61, ptr %l4, !tbaa !23
  %t62 = load i32, ptr %l4, !tbaa !23
  %t63 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t66 = icmp eq i32 %t62, %t63
  br i1 %t66, label %bb17, label %bb18
bb17:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load %"compiler/source:Span", ptr %l1
  %t72 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t68, %"compiler/source:Span" %t69)
  store ptr %t72, ptr %l48
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t73 = load ptr, ptr %l48, !tbaa !29
  store ptr %t73, ptr %rv
  br label %ret
bb20:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load i32, ptr %l4, !tbaa !23
  %t78 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erowsOf(ptr %v0, ptr %t74, i32 %t75)
  store i32 %t78, ptr %l51
  br label %bb21
bb21:
  %t79 = load i32, ptr %l51, !tbaa !23
  store i32 %t79, ptr %l5, !tbaa !23
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load i32, ptr %l5, !tbaa !23
  %t84 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunArrayValue(ptr %v0, ptr %t80, i32 %t81)
  store i1 %t84, ptr %l54
  br label %bb22
bb22:
  %t85 = load i1, ptr %l54, !tbaa !21
  br i1 %t85, label %bb23, label %bb24
bb23:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load %"compiler/source:Span", ptr %l1
  %t88 = load i32, ptr %l5, !tbaa !23
  %t89 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t90 = load ptr, ptr %lp3
  %t91 = load { i64, ptr }, ptr %t90, !tbaa !27
  %t97 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elayRows(ptr %v0, ptr %v1, ptr %v2, ptr %v2, ptr %t86, %"compiler/source:Span" %t87, i32 %t88, { i64, ptr } %t89, { i64, ptr } %t91, i1 false)
  store ptr %t97, ptr %l60
  br label %bb25
bb24:
  br label %bb26
bb25:
  %t98 = load ptr, ptr %l60, !tbaa !29
  store ptr %t98, ptr %rv
  br label %ret
bb26:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/check:Checker", ptr %t99, i32 0, i32 44
  %t103 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t101)
  store i64 %t103, ptr %l63
  br label %bb27
bb27:
  %t104 = load i64, ptr %l63, !tbaa !24
  store i64 %t104, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  %t105 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t105, 0
  store i64 %t107, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t109 = load i64, ptr %l8, !tbaa !24
  %t110 = load i64, ptr %l7, !tbaa !24
  %t113 = icmp sgt i64 %t109, %t110
  br i1 %t113, label %bb28, label %bb29
bb28:
  %t115 = load i64, ptr %l9, !tbaa !24
  %t117 = icmp sgt i64 %t115, 0
  br i1 %t117, label %bb30, label %bb31
bb29:
  store i64 0, ptr %l69, !tbaa !24
  br label %bb33
bb30:
  %t119 = load i64, ptr %l8, !tbaa !24
  %t120 = load i64, ptr %l7, !tbaa !24
  %t123 = sub i64 %t119, %t120
  %t124 = load i64, ptr %l9, !tbaa !24
  %t127 = add i64 %t123, %t124
  %t129 = sub i64 %t127, 1
  %t130 = load i64, ptr %l9, !tbaa !24
  %t133 = sdiv i64 %t129, %t130
  store i64 %t133, ptr %l72, !tbaa !24
  br label %bb32
bb31:
  store i64 0, ptr %l72, !tbaa !24
  br label %bb32
bb32:
  %t135 = load i64, ptr %l72, !tbaa !24
  store i64 %t135, ptr %l69, !tbaa !24
  br label %bb33
bb33:
  %t136 = load i64, ptr %l69, !tbaa !24
  store i64 %t136, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb34
bb34:
  %t137 = load i64, ptr %l11, !tbaa !24
  %t138 = load i64, ptr %l10, !tbaa !24
  %t141 = icmp slt i64 %t137, %t138
  %t143 = xor i1 %t141, true
  br i1 %t143, label %bb35, label %bb36
bb35:
  br label %bb48
bb36:
  br label %bb37
bb37:
  %t145 = load i64, ptr %l7, !tbaa !24
  %t146 = load i64, ptr %l11, !tbaa !24
  %t147 = load i64, ptr %l9, !tbaa !24
  %t150 = mul i64 %t146, %t147
  %t153 = add i64 %t145, %t150
  store i64 %t153, ptr %l12, !tbaa !24
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t156, ptr %l91, !tbaa !27
  %t157 = load i64, ptr %l12, !tbaa !24
  %t159 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !27
  %t161 = getelementptr ptr, ptr %t160, i64 %t157
  %t162 = load ptr, ptr %t161, !tbaa !39
  %t163 = load i64, ptr %l12, !tbaa !24
  %t164 = load ptr, ptr %lp3
  %t166 = getelementptr { i64, ptr }, ptr %t164, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !27
  %t168 = getelementptr ptr, ptr %t167, i64 %t163
  %t169 = load ptr, ptr %t168, !tbaa !39
  %t170 = load i32, ptr %l4, !tbaa !23
  %t175 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleItem(ptr %v0, ptr %v1, ptr %v2, ptr %v0, ptr %t155, ptr %t162, ptr %t169, i32 %t170)
  store ptr %t175, ptr %l97
  br label %bb38
bb38:
  %t176 = load ptr, ptr %l97, !tbaa !29
  store ptr %t176, ptr %l13, !tbaa !29
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t178 = load i32, ptr %l4, !tbaa !23
  %t181 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t177, i32 %t178)
  store i1 %t181, ptr %l100
  br label %bb39
bb39:
  %t182 = load i1, ptr %l100, !tbaa !21
  %t183 = xor i1 %t182, true
  br i1 %t183, label %bb40, label %bb41
bb40:
  %t185 = load ptr, ptr %l0, !tbaa !29
  store ptr %t185, ptr %l102, !tbaa !29
  %t186 = load ptr, ptr %l13, !tbaa !29
  store ptr %t186, ptr %l104, !tbaa !29
  %t188 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t188, ptr %l105, !tbaa !27
  %t189 = load i64, ptr %l12, !tbaa !24
  %t191 = getelementptr { i64, ptr }, ptr %l105, i32 0, i32 1
  %t192 = load ptr, ptr %t191, !tbaa !27
  %t193 = getelementptr ptr, ptr %t192, i64 %t189
  %t194 = load ptr, ptr %t193, !tbaa !39
  %t196 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t194)
  store %"compiler/source:Span" %t196, ptr %l108
  br label %bb42
bb41:
  br label %bb44
bb42:
  %t197 = load i64, ptr @G_2ecompiler_2fcheck_2eRoStored, !tbaa !24
  %t198 = load ptr, ptr %l102, !tbaa !29
  %t199 = load ptr, ptr %l104, !tbaa !29
  %t200 = load %"compiler/source:Span", ptr %l108
  %t202 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroStore(ptr %v0, ptr %v0, ptr %t198, ptr %t199, %"compiler/source:Span" %t200, i64 %t197)
  store i1 %t202, ptr %l110
  br label %bb43
bb43:
  br label %bb44
bb44:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t205 = getelementptr %"compiler/check:Checker", ptr %t203, i32 0, i32 44
  store ptr %t205, ptr %l112, !tbaa !29
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t207 = load ptr, ptr %l13, !tbaa !29
  %t210 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epartCopy(ptr %v0, ptr %v0, ptr %v0, ptr %t206, ptr %t207)
  store ptr %t210, ptr %l115
  br label %bb45
bb45:
  %t211 = load ptr, ptr %l112, !tbaa !29
  %t212 = load ptr, ptr %l115, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t211, ptr %t212)
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t213 = load i64, ptr %l11, !tbaa !24
  %t215 = add i64 %t213, 1
  store i64 %t215, ptr %l11, !tbaa !24
  br label %bb34
bb48:
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t219 = getelementptr %"compiler/check:Checker", ptr %t217, i32 0, i32 44
  %t220 = load i64, ptr %l6, !tbaa !24
  %t223 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v2, ptr %t219, i64 %t220)
  store { i64, ptr } %t223, ptr %l121
  br label %bb49
bb49:
  %t224 = load { i64, ptr }, ptr %l121, !tbaa !27
  store { i64, ptr } %t224, ptr %l14, !tbaa !27
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t227 = getelementptr %"compiler/check:Checker", ptr %t225, i32 0, i32 1
  %t228 = load ptr, ptr %t227, !tbaa !29
  %t230 = getelementptr %"compiler/generic:Program", ptr %t228, i32 0, i32 2
  store ptr %t230, ptr %l124, !tbaa !29
  %t231 = load i32, ptr %l4, !tbaa !23
  store i32 %t231, ptr %l125, !tbaa !23
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t234 = getelementptr %"compiler/check:Checker", ptr %t232, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !29
  %t237 = getelementptr %"compiler/generic:Program", ptr %t235, i32 0, i32 2
  store ptr %t237, ptr %l128, !tbaa !29
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t240 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t238)
  store i32 %t240, ptr %l130
  br label %bb50
bb50:
  %t241 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t243 = extractvalue { i64, ptr } %t241, 0
  %t244 = load ptr, ptr %l128, !tbaa !29
  %t245 = load i32, ptr %l130, !tbaa !23
  %t247 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %t244, i32 %t245, i64 %t243)
  store i32 %t247, ptr %l133
  br label %bb51
bb51:
  %t248 = load ptr, ptr %l124, !tbaa !29
  %t249 = load i32, ptr %l125, !tbaa !23
  %t250 = load i32, ptr %l133, !tbaa !23
  %t251 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t248, i32 %t249, i32 %t250)
  store i32 %t251, ptr %l134
  br label %bb52
bb52:
  %t252 = load i32, ptr %l134, !tbaa !23
  %t253 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t253, ptr %l135
  store i32 %t252, ptr %l136, !tbaa !23
  store i32 2, ptr %l137
  %t255 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t255, ptr %l138, !tbaa !27
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t257 = load %"compiler/source:Span", ptr %l1
  %t261 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t256, i32 1, %"compiler/source:Span" %t257)
  store i32 %t261, ptr %l142
  br label %bb53
bb53:
  %t262 = load i32, ptr %l137, !range !{i32 0, i32 5}
  %t263 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t264 = load i32, ptr %l142, !tbaa !23
  %t266 = call %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t262, i64 0, { i64, ptr } %t263, ptr null, i32 %t264, i32 0, i1 false)
  store %"compiler/typed:Make" %t266, ptr %l144
  br label %bb54
bb54:
  %t267 = load %"compiler/typed:Make", ptr %l144
  %t268 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 56, i64 8)
  store %"compiler/typed:Make" %t267, ptr %t268
  store { i64, [5 x i64] } zeroinitializer, ptr %t269
  %t270 = getelementptr { i64, [5 x i64] }, ptr %t269, i32 0, i32 0
  store i64 7, ptr %t270
  %t271 = load %"compiler/source:Span", ptr %l135
  %t272 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t271, 0
  %t273 = load i32, ptr %l136, !tbaa !23
  %t274 = insertvalue { %"compiler/source:Span", i32, ptr } %t272, i32 %t273, 1
  %t276 = insertvalue { %"compiler/source:Span", i32, ptr } %t274, ptr %t268, 2
  %t277 = getelementptr { i64, [5 x i64] }, ptr %t269, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t276, ptr %t277
  %t278 = load { i64, [5 x i64] }, ptr %t269
  %t280 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t278, ptr %t280
  store ptr %t280, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamDefault(ptr %v0, ptr %v1, ptr %a0, %"compiler/generic:Desc" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/generic:Desc"
  %l2 = alloca %"compiler/generic:Desc"
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l9 = alloca i32
  %l16 = alloca %"compiler/generic:Desc"
  %l23 = alloca ptr
  %l31 = alloca ptr
  %l32 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/generic:Desc" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = getelementptr %"compiler/generic:Desc", ptr %l1, i32 0, i32 1
  %t8 = load i32, ptr %t7, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t6, i32 %t8)
  store i32 %t11, ptr %l9
  br label %bb1
bb1:
  %t12 = load i32, ptr %l9, !range !{i32 0, i32 33}
  %t14 = trunc i64 21 to i32
  %t15 = icmp eq i32 %t12, %t14
  br i1 %t15, label %bb2, label %bb3
bb2:
  store ptr null, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t22 = getelementptr %"compiler/generic:Desc", ptr %l1, i32 0, i32 1
  %t23 = load i32, ptr %t22, !tbaa !23
  %t26 = call %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %t21, i32 %t23)
  store %"compiler/generic:Desc" %t26, ptr %l16
  br label %bb5
bb5:
  %t27 = load %"compiler/generic:Desc", ptr %l16
  store %"compiler/generic:Desc" %t27, ptr %l2
  %t28 = getelementptr %"compiler/generic:Desc", ptr %l2, i32 0, i32 0
  %t29 = load i64, ptr %t28, !tbaa !24
  %t30 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescFunc, !tbaa !24
  %t33 = icmp eq i64 %t29, %t30
  br i1 %t33, label %bb6, label %bb7
bb6:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/check:Checker", ptr %t35, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t39 = getelementptr %"compiler/generic:Desc", ptr %l2, i32 0, i32 2
  %t40 = load i64, ptr %t39, !tbaa !24
  %t43 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t38, i64 %t40)
  store ptr %t43, ptr %l23
  br label %bb8
bb7:
  br label %bb12
bb8:
  %t44 = load ptr, ptr %l23, !tbaa !29
  %t46 = getelementptr %"compiler/ast:Func", ptr %t44, i32 0, i32 3
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/ast:Sig", ptr %t47, i32 0, i32 0
  %t50 = load { i64, ptr }, ptr %t49, !tbaa !27
  store { i64, ptr } %t50, ptr %l3, !tbaa !27
  %t52 = getelementptr %"compiler/generic:Desc", ptr %l1, i32 0, i32 3
  %t53 = load i64, ptr %t52, !tbaa !24
  %t54 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t54, 0
  %t59 = icmp slt i64 %t53, %t56
  br i1 %t59, label %bb9, label %bb10
bb9:
  %t61 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t61, ptr %l32, !tbaa !27
  %t62 = getelementptr %"compiler/generic:Desc", ptr %l1, i32 0, i32 3
  %t63 = load i64, ptr %t62, !tbaa !24
  %t65 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = getelementptr ptr, ptr %t66, i64 %t63
  %t68 = load ptr, ptr %t67, !tbaa !39
  %t70 = getelementptr %"compiler/ast:Param", ptr %t68, i32 0, i32 3
  %t71 = load ptr, ptr %t70, !tbaa !29
  store ptr %t71, ptr %l31, !tbaa !29
  br label %bb11
bb10:
  store ptr null, ptr %l31, !tbaa !29
  br label %bb11
bb11:
  %t73 = load ptr, ptr %l31, !tbaa !29
  store ptr %t73, ptr %rv
  br label %ret
bb12:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/check:Checker", ptr %t74, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t78 = getelementptr %"compiler/generic:Desc", ptr %l1, i32 0, i32 1
  %t79 = load i32, ptr %t78, !tbaa !23
  %t82 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorParams(ptr %v0, ptr %v1, ptr %t77, i32 %t79)
  store { i64, ptr } %t82, ptr %l39
  br label %bb13
bb13:
  %t83 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t83, ptr %l4, !tbaa !27
  %t84 = getelementptr %"compiler/generic:Desc", ptr %l1, i32 0, i32 3
  %t85 = load i64, ptr %t84, !tbaa !24
  %t86 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t91 = icmp sge i64 %t85, %t88
  br i1 %t91, label %bb14, label %bb15
bb14:
  store ptr null, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t94 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t94, ptr %l45, !tbaa !27
  %t95 = getelementptr %"compiler/generic:Desc", ptr %l1, i32 0, i32 3
  %t96 = load i64, ptr %t95, !tbaa !24
  %t98 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr ptr, ptr %t99, i64 %t96
  %t101 = load ptr, ptr %t100, !tbaa !39
  %t103 = getelementptr %"compiler/ast:Param", ptr %t101, i32 0, i32 3
  %t104 = load ptr, ptr %t103, !tbaa !29
  store ptr %t104, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epartCopy(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i1
  %l6 = alloca i32
  %l9 = alloca i1
  %l13 = alloca i1
  %l16 = alloca ptr
  %l18 = alloca i1
  %l23 = alloca i1
  %l24 = alloca i1
  %l29 = alloca i1
  %l34 = alloca ptr
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t1)
  store i32 %t4, ptr %l6
  br label %bb1
bb1:
  %t5 = load i32, ptr %l6, !tbaa !23
  store i32 %t5, ptr %l2, !tbaa !23
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr %l2, !tbaa !23
  %t10 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t6, i32 %t7)
  store i1 %t10, ptr %l9
  br label %bb2
bb2:
  %t11 = load i1, ptr %l9, !tbaa !21
  br i1 %t11, label %bb3, label %bb4
bb3:
  %t12 = load ptr, ptr %l1, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t12, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t18 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueMoved(ptr %v0, ptr %v1, ptr %t14, ptr %t15)
  store i1 %t18, ptr %l13
  br label %bb6
bb6:
  %t19 = load i1, ptr %l13, !tbaa !21
  store i1 %t19, ptr %l3, !tbaa !21
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t24 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueLand(ptr %v0, ptr %v1, ptr %s0, ptr %v2, ptr %t20, ptr %t21, { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d26, i32 0, i32 1) }, i1 false)
  store ptr %t24, ptr %l16
  br label %bb7
bb7:
  %t25 = load ptr, ptr %l16, !tbaa !29
  store ptr %t25, ptr %l1, !tbaa !29
  %t26 = load i1, ptr %l3, !tbaa !21
  br i1 %t26, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb15
bb9:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/generic:Program", ptr %t31, i32 0, i32 2
  %t34 = load i32, ptr %l2, !tbaa !23
  %t37 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnsParts(ptr %v0, ptr %t33, i32 %t34)
  store i1 %t37, ptr %l23
  br label %bb10
bb10:
  %t38 = load i1, ptr %l23, !tbaa !21
  br i1 %t38, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb14
bb12:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/check:Checker", ptr %t39, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = getelementptr %"compiler/generic:Program", ptr %t42, i32 0, i32 2
  %t45 = load i32, ptr %l2, !tbaa !23
  %t48 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %v0, ptr %t44, i32 %t45)
  store i1 %t48, ptr %l29
  br label %bb13
bb13:
  %t49 = load i1, ptr %l29, !tbaa !21
  store i1 %t49, ptr %l24, !tbaa !21
  br label %bb14
bb14:
  %t50 = load i1, ptr %l24, !tbaa !21
  %t51 = xor i1 %t50, true
  store i1 %t51, ptr %l18, !tbaa !21
  br label %bb15
bb15:
  %t53 = load i1, ptr %l18, !tbaa !21
  br i1 %t53, label %bb16, label %bb17
bb16:
  %t54 = load ptr, ptr %l1, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t54, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t60 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eownCopy(ptr %v0, ptr %v2, ptr %v2, ptr %t56, ptr %t57)
  store ptr %t60, ptr %l34
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s0)
  %t61 = load ptr, ptr %l34, !tbaa !29
  store ptr %t61, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epathText(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l15 = alloca i64
  %l18 = alloca i64
  %l39 = alloca ptr
  %l41 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l9
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l5, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l4, !tbaa !24
  %t18 = load i64, ptr %l3, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l5, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l18, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l18, !tbaa !24
  store i64 %t33, ptr %l15, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l15, !tbaa !24
  store i64 %t34, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  %t35 = load i64, ptr %l7, !tbaa !24
  %t36 = load i64, ptr %l6, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  br label %bb19
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l3, !tbaa !24
  %t44 = load i64, ptr %l7, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l8, !tbaa !24
  %t53 = load i64, ptr %l8, !tbaa !24
  %t55 = icmp sgt i64 %t53, 0
  br i1 %t55, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l2, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) })
  br label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb15:
  store ptr %l2, ptr %l39, !tbaa !29
  %t59 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t59, ptr %l41, !tbaa !27
  %t60 = load i64, ptr %l8, !tbaa !24
  %t62 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr i32, ptr %t63, i64 %t60
  %t65 = load i32, ptr %t64, !tbaa !33
  %t68 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %a0, i32 %t65)
  store { i64, ptr } %t68, ptr %l44
  br label %bb16
bb16:
  %t69 = load ptr, ptr %l39, !tbaa !29
  %t70 = load { i64, ptr }, ptr %l44, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t69, { i64, ptr } %t70)
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t71 = load i64, ptr %l7, !tbaa !24
  %t73 = add i64 %t71, 1
  store i64 %t73, ptr %l7, !tbaa !24
  br label %bb8
bb19:
  %t76 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l2)
  store { i64, ptr } %t76, ptr %l48
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t77 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t77, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epayloadPatternOk(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2, i1 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l11 = alloca { i64, i32 }
  %l12 = alloca i64
  %l13 = alloca i32
  %l14 = alloca { i64, ptr }
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca %"compiler/check:payloadItem"
  %l19 = alloca ptr
  %l20 = alloca i1
  %l34 = alloca ptr
  %l37 = alloca ptr
  %l38 = alloca %"compiler/source:Span"
  %l39 = alloca %"compiler/diagmsg:Msg"
  %l40 = alloca i64
  %l44 = alloca { i64, i32 }
  %l49 = alloca ptr
  %l50 = alloca %"compiler/source:Span"
  %l51 = alloca %"compiler/diagmsg:Msg"
  %l52 = alloca i64
  %l55 = alloca ptr
  %l60 = alloca i32
  %l62 = alloca { i64, ptr }
  %l66 = alloca ptr
  %l67 = alloca %"compiler/source:Span"
  %l71 = alloca { i64, ptr }
  %l73 = alloca %"compiler/diagmsg:Msg"
  %l74 = alloca i64
  %l81 = alloca ptr
  %l82 = alloca %"compiler/source:Span"
  %l86 = alloca { i64, ptr }
  %l92 = alloca %"compiler/diagmsg:Msg"
  %l93 = alloca i64
  %l97 = alloca ptr
  %l98 = alloca %"compiler/source:Span"
  %l100 = alloca %"compiler/diagmsg:Msg"
  %l101 = alloca i64
  %l103 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l106 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l108 = alloca i64
  %l110 = alloca i64
  %l115 = alloca %"compiler/check:payloadItem"
  %l126 = alloca i1
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t2 = load ptr, ptr %l19, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l19, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 9}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l20, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l20, !tbaa !21
  %t10 = xor i1 %t9, true
  br i1 %t10, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr { i64, [4 x i64] }, ptr %t13, i32 0, i32 1
  %t16 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t15, i32 0, i32 0
  %t17 = load %"compiler/source:Span", ptr %t16
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = getelementptr { i64, [4 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t21, i32 0, i32 1
  %t23 = load ptr, ptr %t22
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t27, i32 0, i32 2
  %t29 = load { i64, ptr }, ptr %t28
  store %"compiler/source:Span" %t17, ptr %l8
  store { i64, ptr } %t29, ptr %l9, !tbaa !27
  %t37 = call ptr @compiler_2fcheck_2eexprPath(ptr %v1, ptr %s0, ptr %t23)
  store ptr %t37, ptr %l34
  br label %bb6
bb6:
  %t38 = load ptr, ptr %l34, !tbaa !29
  store ptr %t38, ptr %l10, !tbaa !29
  %t39 = load ptr, ptr %l10, !tbaa !29
  %t41 = icmp eq ptr %t39, null
  br i1 %t41, label %bb7, label %bb8
bb7:
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l37, !tbaa !29
  %t44 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t44, ptr %l38
  %t45 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCaughtCaseForm(ptr %v0)
  store %"compiler/diagmsg:Msg" %t45, ptr %l39
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t46 = load ptr, ptr %l37, !tbaa !29
  %t47 = load %"compiler/source:Span", ptr %l38
  %t48 = load %"compiler/diagmsg:Msg", ptr %l39
  %t49 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t46, %"compiler/source:Span" %t47, %"compiler/diagmsg:Msg" %t48)
  store i64 %t49, ptr %l40
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb11:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load ptr, ptr %l10, !tbaa !29
  %t55 = call { i64, i32 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrorWord(ptr %v0, ptr %s0, ptr %t51, ptr %t52)
  store { i64, i32 } %t55, ptr %l44
  br label %bb12
bb12:
  %t56 = load { i64, i32 }, ptr %l44
  store { i64, i32 } %t56, ptr %l11
  %t57 = getelementptr { i64, i32 }, ptr %l11, i32 0, i32 0
  %t58 = load i64, ptr %t57, !tbaa !24
  store i64 %t58, ptr %l12, !tbaa !24
  %t60 = getelementptr { i64, i32 }, ptr %l11, i32 0, i32 1
  %t61 = load i32, ptr %t60, !tbaa !23
  store i32 %t61, ptr %l13, !tbaa !23
  %t63 = load i64, ptr %l12, !tbaa !24
  %t65 = icmp slt i64 %t63, 0
  br i1 %t65, label %bb13, label %bb14
bb13:
  %t67 = load ptr, ptr %l0, !tbaa !29
  store ptr %t67, ptr %l49, !tbaa !29
  %t68 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t68, ptr %l50
  %t69 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCaughtCaseForm(ptr %v0)
  store %"compiler/diagmsg:Msg" %t69, ptr %l51
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t70 = load ptr, ptr %l49, !tbaa !29
  %t71 = load %"compiler/source:Span", ptr %l50
  %t72 = load %"compiler/diagmsg:Msg", ptr %l51
  %t73 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t70, %"compiler/source:Span" %t71, %"compiler/diagmsg:Msg" %t72)
  store i64 %t73, ptr %l52
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb17:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/check:Checker", ptr %t75, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !29
  store ptr %t78, ptr %l55, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/check:Checker", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = getelementptr %"compiler/generic:Program", ptr %t82, i32 0, i32 2
  %t85 = load i32, ptr %l13, !tbaa !23
  %t88 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t84, i32 %t85)
  store i32 %t88, ptr %l60
  br label %bb18
bb18:
  %t89 = load i64, ptr %l12, !tbaa !24
  %t90 = load ptr, ptr %l55, !tbaa !29
  %t91 = load i32, ptr %l60, !tbaa !23
  %t93 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eWordFields(ptr %v0, ptr %s0, ptr %t90, i32 %t91, i64 %t89)
  store { i64, ptr } %t93, ptr %l62
  br label %bb19
bb19:
  %t94 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t94, ptr %l14, !tbaa !27
  %t95 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t95, 0
  %t99 = icmp eq i64 %t97, 0
  br i1 %t99, label %bb20, label %bb21
bb20:
  store %olang.scope zeroinitializer, ptr %s4
  %t101 = load ptr, ptr %l0, !tbaa !29
  store ptr %t101, ptr %l66, !tbaa !29
  %t102 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t102, ptr %l67
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load i32, ptr %l13, !tbaa !23
  %t105 = load i64, ptr %l12, !tbaa !24
  %t109 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordText(ptr %v0, ptr %s4, ptr %t103, i32 %t104, i64 %t105)
  store { i64, ptr } %t109, ptr %l71
  br label %bb22
bb21:
  br label %bb25
bb22:
  %t110 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t111 = extractvalue { i64, ptr } %t110, 0
  %t112 = extractvalue { i64, ptr } %t110, 1
  %t113 = mul i64 %t111, 1
  %t114 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t113)
  call void @llvm.memcpy.p0.p0.i64(ptr %t114, ptr %t112, i64 %t113, i1 false)
  %t115 = insertvalue { i64, ptr } undef, i64 %t111, 0
  %t116 = insertvalue { i64, ptr } %t115, ptr %t114, 1
  %t118 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePlainWordCalled(ptr %s4, ptr %v0, { i64, ptr } %t116)
  store %"compiler/diagmsg:Msg" %t118, ptr %l73
  br label %bb23
bb23:
  %t119 = load ptr, ptr %l66, !tbaa !29
  %t120 = load %"compiler/source:Span", ptr %l67
  %t121 = load %"compiler/diagmsg:Msg", ptr %l73
  %t122 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t119, %"compiler/source:Span" %t120, %"compiler/diagmsg:Msg" %t121)
  store i64 %t122, ptr %l74
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb25:
  %t124 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t124, 0
  %t127 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t127, 0
  %t132 = icmp sgt i64 %t126, %t129
  br i1 %t132, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s5
  %t134 = load ptr, ptr %l0, !tbaa !29
  store ptr %t134, ptr %l81, !tbaa !29
  %t135 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t135, ptr %l82
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load i32, ptr %l13, !tbaa !23
  %t138 = load i64, ptr %l12, !tbaa !24
  %t142 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordText(ptr %v0, ptr %s5, ptr %t136, i32 %t137, i64 %t138)
  store { i64, ptr } %t142, ptr %l86
  br label %bb28
bb27:
  br label %bb31
bb28:
  %t143 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t144 = extractvalue { i64, ptr } %t143, 0
  %t145 = extractvalue { i64, ptr } %t143, 1
  %t146 = mul i64 %t144, 1
  %t147 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t146)
  call void @llvm.memcpy.p0.p0.i64(ptr %t147, ptr %t145, i64 %t146, i1 false)
  %t148 = insertvalue { i64, ptr } undef, i64 %t144, 0
  %t149 = insertvalue { i64, ptr } %t148, ptr %t147, 1
  %t150 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t152 = extractvalue { i64, ptr } %t150, 0
  %t153 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t155 = extractvalue { i64, ptr } %t153, 0
  %t159 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePayloadArgs(ptr %s5, ptr %v0, { i64, ptr } %t149, i64 %t152, i64 %t155)
  store %"compiler/diagmsg:Msg" %t159, ptr %l92
  br label %bb29
bb29:
  %t160 = load ptr, ptr %l81, !tbaa !29
  %t161 = load %"compiler/source:Span", ptr %l82
  %t162 = load %"compiler/diagmsg:Msg", ptr %l92
  %t163 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t160, %"compiler/source:Span" %t161, %"compiler/diagmsg:Msg" %t162)
  store i64 %t163, ptr %l93
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb31:
  %t167 = xor i1 %a3, true
  br i1 %t167, label %bb32, label %bb33
bb32:
  %t169 = load ptr, ptr %l0, !tbaa !29
  store ptr %t169, ptr %l97, !tbaa !29
  %t170 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t170, ptr %l98
  %t173 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eErrPatternNeedsName(ptr %v2, ptr %v0, { i64, ptr } %a2)
  store %"compiler/diagmsg:Msg" %t173, ptr %l100
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t174 = load ptr, ptr %l97, !tbaa !29
  %t175 = load %"compiler/source:Span", ptr %l98
  %t176 = load %"compiler/diagmsg:Msg", ptr %l100
  %t177 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t174, %"compiler/source:Span" %t175, %"compiler/diagmsg:Msg" %t176)
  store i64 %t177, ptr %l101
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb36:
  %t179 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t179, ptr %l103
  br label %bb37
bb37:
  %t180 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l103
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t180, ptr %l15
  store %olang.scope zeroinitializer, ptr %s7
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t182 = load ptr, ptr %l1, !tbaa !29
  %t185 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epayloadItems(ptr %v0, ptr %v1, ptr %s7, ptr %t181, ptr %t182)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t185, ptr %l106
  br label %bb38
bb38:
  %t186 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l106
  %t187 = call ptr @__olang_scope_alloc_a(ptr %s7, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t186, ptr %t187
  store ptr %t187, ptr %l16, !tbaa !29
  store i64 0, ptr %l17, !tbaa !24
  br label %bb39
bb39:
  store %olang.scope zeroinitializer, ptr %s8
  %t189 = load i64, ptr %l17, !tbaa !24
  store i64 %t189, ptr %l108, !tbaa !24
  %t190 = load ptr, ptr %l16, !tbaa !29
  %t192 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3apayloadItem_3e_2eLe_Hf8109b64a4e45220d0da36a987cf38b1(ptr %s7, ptr %t190)
  store i64 %t192, ptr %l110
  br label %bb40
bb40:
  %t193 = load i64, ptr %l108, !tbaa !24
  %t194 = load i64, ptr %l110, !tbaa !24
  %t195 = icmp slt i64 %t193, %t194
  %t197 = xor i1 %t195, true
  br i1 %t197, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s8)
  br label %bb51
bb42:
  br label %bb43
bb43:
  %t199 = load ptr, ptr %l16, !tbaa !29
  %t200 = load i64, ptr %l17, !tbaa !24
  %t203 = call %"compiler/check:payloadItem" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3apayloadItem_3e_2eAt_H64f851f610dd8566f1d7651b626ec99d(ptr %s7, ptr %s7, ptr %t199, i64 %t200)
  store %"compiler/check:payloadItem" %t203, ptr %l115
  br label %bb44
bb44:
  %t204 = load %"compiler/check:payloadItem", ptr %l115
  store %"compiler/check:payloadItem" %t204, ptr %l18
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t206 = load %"compiler/source:Span", ptr %l8
  %t207 = load i32, ptr %l13, !tbaa !23
  %t208 = load i64, ptr %l12, !tbaa !24
  %t209 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t210 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t212 = extractvalue { i64, ptr } %t210, 0
  %t223 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epayloadItemOk(ptr %v0, ptr %s8, ptr %s0, ptr %s0, ptr %t205, ptr %l18, %"compiler/source:Span" %t206, i32 %t207, i64 %t208, { i64, ptr } %t209, i64 %t212, ptr %l15, i64 %a4)
  store i1 %t223, ptr %l126
  br label %bb45
bb45:
  %t224 = load i1, ptr %l126, !tbaa !21
  %t225 = xor i1 %t224, true
  br i1 %t225, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb47:
  br label %bb48
bb48:
  %t228 = getelementptr %"compiler/check:payloadItem", ptr %l18, i32 0, i32 0
  %t229 = load i32, ptr %t228, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %l15, i32 %t229)
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s8)
  br label %bb50
bb50:
  %t232 = load i64, ptr %l17, !tbaa !24
  %t234 = add i64 %t232, 1
  store i64 %t234, ptr %l17, !tbaa !24
  br label %bb39
bb51:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epayloadRefIn(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l11 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l23 = alloca i1
  %l28 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t6, i32 %a1)
  store { i64, ptr } %t10, ptr %l11
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t11, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  store i64 %t14, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t16 = load i64, ptr %l4, !tbaa !24
  %t17 = load i64, ptr %l5, !tbaa !24
  %t20 = icmp slt i64 %t16, %t17
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb3, label %bb4
bb3:
  br label %bb14
bb4:
  br label %bb5
bb5:
  %t24 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t24, ptr %l18, !tbaa !27
  %t25 = load i64, ptr %l4, !tbaa !24
  %t27 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i32, ptr %t28, i64 %t25
  %t30 = load i32, ptr %t29, !tbaa !33
  store i32 %t30, ptr %l6, !tbaa !23
  %t32 = load i32, ptr %l6, !tbaa !23
  %t34 = icmp ne i32 %t32, 0
  br i1 %t34, label %bb6, label %bb7
bb6:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load i32, ptr %l6, !tbaa !23
  %t40 = add i64 %a2, 1
  %t44 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epayloadRef(ptr %v0, ptr %t36, i32 %t37, i64 %t40)
  store i1 %t44, ptr %l28
  br label %bb8
bb7:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb9
bb8:
  %t45 = load i1, ptr %l28, !tbaa !21
  store i1 %t45, ptr %l23, !tbaa !21
  br label %bb9
bb9:
  %t46 = load i1, ptr %l23, !tbaa !21
  br i1 %t46, label %bb10, label %bb11
bb10:
  store i1 true, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t48 = load i64, ptr %l4, !tbaa !24
  %t50 = add i64 %t48, 1
  store i64 %t50, ptr %l4, !tbaa !24
  br label %bb2
bb14:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epowValues(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca i32
  %l16 = alloca i1
  %l19 = alloca i32
  %l24 = alloca ptr
  %l28 = alloca i64
  %l33 = alloca i1
  %l34 = alloca i1
  %l37 = alloca i1
  %l39 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l48 = alloca ptr
  %l49 = alloca %"compiler/source:Span"
  %l52 = alloca { i64, ptr }
  %l55 = alloca %"compiler/diagmsg:Msg"
  %l56 = alloca i64
  %l59 = alloca ptr
  %l60 = alloca ptr
  %l61 = alloca ptr
  %l65 = alloca ptr
  %l68 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l71 = alloca ptr
  %l72 = alloca %"compiler/source:Span"
  %l73 = alloca %"compiler/source:Span"
  %l74 = alloca i64
  %l76 = alloca ptr
  %l79 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  %l86 = alloca ptr
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t5 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t2)
  store i32 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l8, !tbaa !29
  %t7 = load i32, ptr %l11, !tbaa !23
  %t8 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t8, ptr %l12
  br label %bb2
bb2:
  %t9 = load i32, ptr %l12, !tbaa !23
  store i32 %t9, ptr %l5, !tbaa !23
  %t10 = load i32, ptr %l5, !tbaa !23
  %t11 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t14 = icmp eq i32 %t10, %t11
  br i1 %t14, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb6
bb4:
  %t16 = load ptr, ptr %l4, !tbaa !29
  %t19 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t16)
  store i32 %t19, ptr %l19
  br label %bb5
bb5:
  %t20 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t21 = load i32, ptr %l19, !tbaa !23
  %t23 = icmp eq i32 %t21, %t20
  store i1 %t23, ptr %l16, !tbaa !21
  br label %bb6
bb6:
  %t25 = load i1, ptr %l16, !tbaa !21
  br i1 %t25, label %bb7, label %bb8
bb7:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load %"compiler/source:Span", ptr %l1
  %t30 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t26, %"compiler/source:Span" %t27)
  store ptr %t30, ptr %l24
  br label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t31 = load ptr, ptr %l24, !tbaa !29
  store ptr %t31, ptr %rv
  br label %ret
bb10:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i32, ptr %l5, !tbaa !23
  %t34 = load %"compiler/source:Span", ptr %l2
  %t38 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epowMethod(ptr %v0, ptr %t32, i32 %t33, %"compiler/source:Span" %t34)
  store i64 %t38, ptr %l28
  br label %bb11
bb11:
  %t39 = load i64, ptr %l28, !tbaa !24
  store i64 %t39, ptr %l6, !tbaa !24
  %t40 = load i64, ptr %l6, !tbaa !24
  %t42 = icmp slt i64 %t40, 0
  br i1 %t42, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load i32, ptr %l5, !tbaa !23
  %t48 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t44, i32 %t45)
  store i1 %t48, ptr %l33
  br label %bb14
bb13:
  br label %bb28
bb14:
  %t49 = load i1, ptr %l33, !tbaa !21
  br i1 %t49, label %bb15, label %bb16
bb15:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load i32, ptr %l5, !tbaa !23
  %t54 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t50, i32 %t51)
  store i1 %t54, ptr %l37
  br label %bb17
bb16:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb18
bb17:
  %t55 = load i1, ptr %l37, !tbaa !21
  %t56 = xor i1 %t55, true
  store i1 %t56, ptr %l34, !tbaa !21
  br label %bb18
bb18:
  %t58 = load i1, ptr %l34, !tbaa !21
  br i1 %t58, label %bb19, label %bb20
bb19:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load i32, ptr %l5, !tbaa !23
  %t63 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t59, i32 %t60)
  store { i64, ptr } %t63, ptr %l42
  br label %bb21
bb20:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d28, i32 0, i32 1) }, ptr %l39, !tbaa !27
  br label %bb23
bb21:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load i32, ptr %l5, !tbaa !23
  %t68 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t64, i32 %t65)
  store { i64, ptr } %t68, ptr %l45
  br label %bb22
bb22:
  %t69 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t70 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  %t71 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t71, 1
  %t73 = extractvalue { i64, ptr } %t71, 0
  %t74 = add i64 %t70, %t73
  %t75 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d30, i32 0, i32 1) }, 1
  %t76 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d30, i32 0, i32 1) }, 0
  %t77 = add i64 %t74, %t76
  %t78 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t78, 1
  %t80 = extractvalue { i64, ptr } %t78, 0
  %t81 = add i64 %t77, %t80
  %t82 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t83 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  %t84 = add i64 %t81, %t83
  %t85 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t84)
  call void @olang_textcopy(ptr %t85, ptr %t69, i64 %t70)
  %t86 = getelementptr i8, ptr %t85, i64 %t70
  call void @olang_textcopy(ptr %t86, ptr %t72, i64 %t73)
  %t87 = getelementptr i8, ptr %t86, i64 %t73
  call void @olang_textcopy(ptr %t87, ptr %t75, i64 %t76)
  %t88 = getelementptr i8, ptr %t87, i64 %t76
  call void @olang_textcopy(ptr %t88, ptr %t79, i64 %t80)
  %t89 = getelementptr i8, ptr %t88, i64 %t80
  call void @olang_textcopy(ptr %t89, ptr %t82, i64 %t83)
  %t90 = insertvalue { i64, ptr } undef, i64 %t84, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t85, 1
  %t93 = extractvalue { i64, ptr } %t91, 0
  %t94 = extractvalue { i64, ptr } %t91, 1
  %t95 = mul i64 %t93, 1
  %t96 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t95)
  call void @llvm.memcpy.p0.p0.i64(ptr %t96, ptr %t94, i64 %t95, i1 false)
  %t97 = insertvalue { i64, ptr } undef, i64 %t93, 0
  %t98 = insertvalue { i64, ptr } %t97, ptr %t96, 1
  store { i64, ptr } %t98, ptr %l39, !tbaa !27
  br label %bb23
bb23:
  %t100 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t100, ptr %l7, !tbaa !27
  %t101 = load ptr, ptr %l0, !tbaa !29
  store ptr %t101, ptr %l48, !tbaa !29
  %t102 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t102, ptr %l49
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load i32, ptr %l5, !tbaa !23
  %t107 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t103, i32 %t104)
  store { i64, ptr } %t107, ptr %l52
  br label %bb24
bb24:
  %t108 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t108, 0
  %t110 = extractvalue { i64, ptr } %t108, 1
  %t111 = mul i64 %t109, 1
  %t112 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t111)
  call void @llvm.memcpy.p0.p0.i64(ptr %t112, ptr %t110, i64 %t111, i1 false)
  %t113 = insertvalue { i64, ptr } undef, i64 %t109, 0
  %t114 = insertvalue { i64, ptr } %t113, ptr %t112, 1
  %t115 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t118 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePowNone(ptr %s2, ptr %s2, ptr %v0, { i64, ptr } %t114, { i64, ptr } %t115)
  store %"compiler/diagmsg:Msg" %t118, ptr %l55
  br label %bb25
bb25:
  %t119 = load ptr, ptr %l48, !tbaa !29
  %t120 = load %"compiler/source:Span", ptr %l49
  %t121 = load %"compiler/diagmsg:Msg", ptr %l55
  %t122 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t119, %"compiler/source:Span" %t120, %"compiler/diagmsg:Msg" %t121)
  store i64 %t122, ptr %l56
  br label %bb26
bb26:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load %"compiler/source:Span", ptr %l1
  %t127 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t123, %"compiler/source:Span" %t124)
  store ptr %t127, ptr %l59
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t128 = load ptr, ptr %l59, !tbaa !29
  store ptr %t128, ptr %rv
  br label %ret
bb28:
  %t129 = load ptr, ptr %l0, !tbaa !29
  store ptr %t129, ptr %l60, !tbaa !29
  %t130 = load ptr, ptr %l0, !tbaa !29
  store ptr %t130, ptr %l61, !tbaa !29
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr %"compiler/check:Checker", ptr %t131, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !29
  %t135 = load i64, ptr %l6, !tbaa !24
  %t138 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s0, ptr %t134, i64 %t135)
  store ptr %t138, ptr %l65
  br label %bb29
bb29:
  %t139 = load ptr, ptr %l65, !tbaa !29
  %t141 = getelementptr %"compiler/ast:Func", ptr %t139, i32 0, i32 2
  %t142 = load i32, ptr %t141, !tbaa !23
  %t143 = load ptr, ptr %l61, !tbaa !29
  %t145 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t143, i32 %t142)
  store { i64, ptr } %t145, ptr %l68
  br label %bb30
bb30:
  %t146 = load ptr, ptr %l60, !tbaa !29
  %t147 = getelementptr %"compiler/check:Checker", ptr %t146, i32 0, i32 61
  %t148 = load { i64, ptr }, ptr %t147, !tbaa !27
  store { i64, ptr } %t148, ptr %l69, !tbaa !27
  %t149 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t150 = load ptr, ptr %l60, !tbaa !29
  %t151 = getelementptr %"compiler/check:Checker", ptr %t150, i32 0, i32 61
  store { i64, ptr } %t149, ptr %t151, !tbaa !27
  %t152 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3aChecker_2e61
  br i1 %t152, label %bb31, label %bb32
bb31:
  %t154 = load { i64, ptr }, ptr %l69
  %t155 = extractvalue { i64, ptr } %t154, 1
  call void @__olang_region_release(ptr %t155)
  store { i64, ptr } zeroinitializer, ptr %l69
  br label %bb32
bb32:
  %t156 = load ptr, ptr %l0, !tbaa !29
  store ptr %t156, ptr %l71, !tbaa !29
  %t157 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t157, ptr %l72
  %t158 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t158, ptr %l73
  %t159 = load i64, ptr %l6, !tbaa !24
  store i64 %t159, ptr %l74, !tbaa !24
  %t160 = load ptr, ptr %l3, !tbaa !29
  store ptr %t160, ptr %l76, !tbaa !29
  %t162 = icmp sge i64 0, 0
  br i1 %t162, label %bb33, label %bb34
bb33:
  %t164 = icmp sle i64 0, 1152921504606846975
  br i1 %t164, label %bb35, label %bb36
bb34:
  call void @__olang_check_failed(ptr @olang_loc_40ba663ddc86f216_8a32628f26d9e82)
  unreachable
bb35:
  %t166 = mul i64 0, 8
  %t167 = insertvalue { i64, ptr } undef, i64 0, 0
  %t168 = insertvalue { i64, ptr } %t167, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t168, ptr %l79, !tbaa !27
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t170 = load ptr, ptr %l4, !tbaa !29
  %t173 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %v2, ptr %v0, ptr %t169, ptr %t170)
  store { i64, ptr } %t173, ptr %l82
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_40ba663ddc86f216_8a32628f26d9e82)
  unreachable
bb37:
  %t174 = icmp sge i64 0, 0
  br i1 %t174, label %bb38, label %bb39
bb38:
  %t176 = icmp sle i64 0, 2305843009213693951
  br i1 %t176, label %bb40, label %bb41
bb39:
  call void @__olang_check_failed(ptr @olang_loc_e2e10646092ca22b_113878b4617d7337)
  unreachable
bb40:
  %t178 = mul i64 0, 4
  %t179 = insertvalue { i64, ptr } undef, i64 0, 0
  %t180 = insertvalue { i64, ptr } %t179, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t181 = load ptr, ptr %l71, !tbaa !29
  %t182 = load %"compiler/source:Span", ptr %l72
  %t183 = load %"compiler/source:Span", ptr %l73
  %t184 = load i64, ptr %l74, !tbaa !24
  %t185 = load ptr, ptr %l76, !tbaa !29
  %t186 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t187 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t189 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v1, ptr %v0, ptr %v0, ptr %v3, ptr %v3, ptr %t181, %"compiler/source:Span" %t182, %"compiler/source:Span" %t183, i64 %t184, ptr %t185, { i64, ptr } %t186, { i64, ptr } %t187, { i64, ptr } %t180)
  store ptr %t189, ptr %l86
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_e2e10646092ca22b_113878b4617d7337)
  unreachable
bb42:
  call void @__olang_scope_close(ptr %s0)
  %t190 = load ptr, ptr %l86, !tbaa !29
  store ptr %t190, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprivateRole(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, i32 %a2, { i64, ptr } %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l9 = alloca i1
  %l12 = alloca i64
  %l15 = alloca ptr
  %l19 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l25 = alloca i1
  %l26 = alloca i1
  %l30 = alloca i64
  %l32 = alloca ptr
  %l40 = alloca ptr
  %l43 = alloca { i64, [3 x i64] }
  %l44 = alloca { i64, ptr }
  %l45 = alloca ptr
  %l48 = alloca i32
  %l49 = alloca { i64, ptr }
  %l53 = alloca %"compiler/diagmsg:Msg"
  %l54 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb4
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 20
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l12
  br label %bb3
bb3:
  %t10 = load i64, ptr %l12, !tbaa !24
  %t11 = icmp eq i64 %t10, 0
  store i1 %t11, ptr %l9, !tbaa !21
  br label %bb4
bb4:
  %t13 = load i1, ptr %l9, !tbaa !21
  br i1 %t13, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l15, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t20 = load i64, ptr %l1, !tbaa !24
  %t23 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s0, ptr %t19, i64 %t20)
  store ptr %t23, ptr %l19
  br label %bb8
bb8:
  %t24 = load ptr, ptr %l19, !tbaa !29
  %t26 = getelementptr %"compiler/ast:Func", ptr %t24, i32 0, i32 2
  %t27 = load i32, ptr %t26, !tbaa !23
  %t28 = load ptr, ptr %l15, !tbaa !29
  %t30 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t28, i32 %t27)
  store { i64, ptr } %t30, ptr %l22
  br label %bb9
bb9:
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t31, ptr %l6, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t33 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t36 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t32, { i64, ptr } %t33)
  store i1 %t36, ptr %l25
  br label %bb10
bb10:
  %t37 = load i1, ptr %l25, !tbaa !21
  br i1 %t37, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb15
bb12:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/check:Checker", ptr %t38, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t42 = load i64, ptr %l1, !tbaa !24
  %t45 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t41, i64 %t42)
  store i64 %t45, ptr %l30
  br label %bb13
bb13:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t46)
  store ptr %t48, ptr %l32
  br label %bb14
bb14:
  %t49 = load ptr, ptr %l32, !tbaa !29
  %t51 = getelementptr %"compiler/check:frame", ptr %t49, i32 0, i32 1
  %t52 = load i64, ptr %t51, !tbaa !24
  %t53 = load i64, ptr %l30, !tbaa !24
  %t55 = icmp eq i64 %t53, %t52
  store i1 %t55, ptr %l26, !tbaa !21
  br label %bb15
bb15:
  %t57 = load i1, ptr %l26, !tbaa !21
  br i1 %t57, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Program", ptr %t62, i32 0, i32 0
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/load:Loader", ptr %t65, i32 0, i32 4
  %t68 = load ptr, ptr %t67, !tbaa !29
  store ptr %t68, ptr %l40, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t73 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t69, %"compiler/source:Span" %a4)
  store { i64, [3 x i64] } %t73, ptr %l43
  br label %bb19
bb19:
  store { i64, ptr } %a5, ptr %l44, !tbaa !27
  %t75 = load ptr, ptr %l0, !tbaa !29
  store ptr %t75, ptr %l45, !tbaa !29
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t80 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t76, i32 %a2)
  store i32 %t80, ptr %l48
  br label %bb20
bb20:
  %t81 = load ptr, ptr %l45, !tbaa !29
  %t82 = load i32, ptr %l48, !tbaa !23
  %t83 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t81, i32 %t82)
  store { i64, ptr } %t83, ptr %l49
  br label %bb21
bb21:
  %t84 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t84, 0
  %t86 = extractvalue { i64, ptr } %t84, 1
  %t87 = mul i64 %t85, 1
  %t88 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t87)
  call void @llvm.memcpy.p0.p0.i64(ptr %t88, ptr %t86, i64 %t87, i1 false)
  %t89 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  %t91 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t92 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t93 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t97 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eProtocolPrivate(ptr %v2, ptr %s0, ptr %v0, ptr %v1, ptr %v0, { i64, ptr } %t93, { i64, ptr } %t90, { i64, ptr } %t91, { i64, ptr } %t92)
  store %"compiler/diagmsg:Msg" %t97, ptr %l53
  br label %bb22
bb22:
  %t98 = load ptr, ptr %l40, !tbaa !29
  %t99 = load { i64, [3 x i64] }, ptr %l43
  %t100 = load %"compiler/diagmsg:Msg", ptr %l53
  %t101 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorOncePerLine(ptr %v0, ptr %v0, ptr %t98, { i64, [3 x i64] } %t99, %"compiler/diagmsg:Msg" %t100)
  store i64 %t101, ptr %l54
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprovenIndex(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca %"compiler/check:knownRange"
  %l7 = alloca i64
  %l10 = alloca i32
  %l17 = alloca i64
  %l20 = alloca i1
  %l24 = alloca ptr
  %l26 = alloca %"compiler/source:Span"
  %l27 = alloca ptr
  %l29 = alloca %"compiler/source:Span"
  %l30 = alloca { i64, ptr }
  %l33 = alloca %"compiler/diagmsg:Msg"
  %l34 = alloca i64
  %l37 = alloca %"compiler/check:knownRange"
  %l40 = alloca i1
  %l43 = alloca i1
  %l50 = alloca i64
  %l54 = alloca ptr
  %l55 = alloca i64
  %l56 = alloca %"compiler/source:Span"
  %l58 = alloca %"compiler/source:Span"
  %l59 = alloca ptr
  %l61 = alloca %"compiler/source:Span"
  %l62 = alloca { i64, ptr }
  %l66 = alloca %"compiler/check:rangeIndex"
  %l68 = alloca %"compiler/check:rangeIndex"
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprovenInt(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i32 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i32, ptr %l10, !tbaa !23
  store i32 %t6, ptr %l4, !tbaa !23
  %t7 = load i32, ptr %l4, !tbaa !23
  %t9 = icmp sge i32 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t11, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/generic:Program", ptr %t14, i32 0, i32 2
  %t17 = load i32, ptr %l4, !tbaa !23
  %t20 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t16, i32 %t17)
  store i64 %t20, ptr %l17
  br label %bb4
bb3:
  br label %bb16
bb4:
  %t21 = load i64, ptr %l17, !tbaa !24
  store i64 %t21, ptr %l5, !tbaa !24
  %t22 = load i64, ptr %l5, !tbaa !24
  %t24 = icmp slt i64 %t22, 0
  br i1 %t24, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb7
bb6:
  %t26 = load i64, ptr %l5, !tbaa !24
  %t27 = load i64, ptr %l2, !tbaa !24
  %t30 = icmp sge i64 %t26, %t27
  store i1 %t30, ptr %l20, !tbaa !21
  br label %bb7
bb7:
  %t32 = load i1, ptr %l20, !tbaa !21
  br i1 %t32, label %bb8, label %bb9
bb8:
  %t33 = load ptr, ptr %l0, !tbaa !29
  store ptr %t33, ptr %l24, !tbaa !29
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t34)
  store %"compiler/source:Span" %t36, ptr %l26
  br label %bb10
bb9:
  br label %bb15
bb10:
  %t37 = load ptr, ptr %l0, !tbaa !29
  store ptr %t37, ptr %l27, !tbaa !29
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t38)
  store %"compiler/source:Span" %t40, ptr %l29
  br label %bb11
bb11:
  %t41 = load ptr, ptr %l27, !tbaa !29
  %t42 = load %"compiler/source:Span", ptr %l29
  %t43 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t41, %"compiler/source:Span" %t42)
  store { i64, ptr } %t43, ptr %l30
  br label %bb12
bb12:
  %t44 = load i64, ptr %l5, !tbaa !24
  %t45 = load i64, ptr %l2, !tbaa !24
  %t46 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t49 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eIndexProven(ptr %v0, ptr %v0, { i64, ptr } %t46, i64 %t44, i64 %t45)
  store %"compiler/diagmsg:Msg" %t49, ptr %l33
  br label %bb13
bb13:
  %t50 = load ptr, ptr %l24, !tbaa !29
  %t51 = load %"compiler/source:Span", ptr %l26
  %t52 = load %"compiler/diagmsg:Msg", ptr %l33
  %t53 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t50, %"compiler/source:Span" %t51, %"compiler/diagmsg:Msg" %t52)
  store i64 %t53, ptr %l34
  br label %bb14
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb16:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t58 = call %"compiler/check:knownRange" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erangeOf(ptr %v0, ptr %v1, ptr %t54, ptr %t55, i64 0)
  store %"compiler/check:knownRange" %t58, ptr %l37
  br label %bb17
bb17:
  %t59 = load %"compiler/check:knownRange", ptr %l37
  store %"compiler/check:knownRange" %t59, ptr %l6
  %t60 = getelementptr %"compiler/check:knownRange", ptr %l6, i32 0, i32 2
  %t61 = load i64, ptr %t60, !tbaa !24
  %t63 = icmp slt i64 %t61, 0
  br i1 %t63, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb23
bb19:
  %t65 = getelementptr %"compiler/check:knownRange", ptr %l6, i32 0, i32 0
  %t66 = load i64, ptr %t65, !tbaa !24
  %t68 = icmp sge i64 %t66, 0
  br i1 %t68, label %bb20, label %bb21
bb20:
  %t70 = getelementptr %"compiler/check:knownRange", ptr %l6, i32 0, i32 1
  %t71 = load i64, ptr %t70, !tbaa !24
  %t72 = load i64, ptr %l2, !tbaa !24
  %t75 = icmp slt i64 %t71, %t72
  store i1 %t75, ptr %l43, !tbaa !21
  br label %bb22
bb21:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb22
bb22:
  %t77 = load i1, ptr %l43, !tbaa !21
  store i1 %t77, ptr %l40, !tbaa !21
  br label %bb23
bb23:
  %t78 = load i1, ptr %l40, !tbaa !21
  br i1 %t78, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb25:
  br label %bb26
bb26:
  %t79 = getelementptr %"compiler/check:knownRange", ptr %l6, i32 0, i32 1
  %t80 = load i64, ptr %t79, !tbaa !24
  %t81 = load i64, ptr %l2, !tbaa !24
  %t84 = icmp sge i64 %t80, %t81
  br i1 %t84, label %bb27, label %bb28
bb27:
  %t86 = getelementptr %"compiler/check:knownRange", ptr %l6, i32 0, i32 1
  %t87 = load i64, ptr %t86, !tbaa !24
  store i64 %t87, ptr %l50, !tbaa !24
  br label %bb29
bb28:
  %t89 = getelementptr %"compiler/check:knownRange", ptr %l6, i32 0, i32 0
  %t90 = load i64, ptr %t89, !tbaa !24
  store i64 %t90, ptr %l50, !tbaa !24
  br label %bb29
bb29:
  %t92 = load i64, ptr %l50, !tbaa !24
  store i64 %t92, ptr %l7, !tbaa !24
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/check:Checker", ptr %t93, i32 0, i32 43
  store ptr %t95, ptr %l54, !tbaa !29
  %t96 = getelementptr %"compiler/check:knownRange", ptr %l6, i32 0, i32 2
  %t97 = load i64, ptr %t96, !tbaa !24
  store i64 %t97, ptr %l55, !tbaa !24
  store %"compiler/source:Span" %a3, ptr %l56
  %t99 = load ptr, ptr %l1, !tbaa !29
  %t101 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t99)
  store %"compiler/source:Span" %t101, ptr %l58
  br label %bb30
bb30:
  %t102 = load ptr, ptr %l0, !tbaa !29
  store ptr %t102, ptr %l59, !tbaa !29
  %t103 = load ptr, ptr %l1, !tbaa !29
  %t105 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t103)
  store %"compiler/source:Span" %t105, ptr %l61
  br label %bb31
bb31:
  %t106 = load ptr, ptr %l59, !tbaa !29
  %t107 = load %"compiler/source:Span", ptr %l61
  %t108 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %s0, ptr %t106, %"compiler/source:Span" %t107)
  store { i64, ptr } %t108, ptr %l62
  br label %bb32
bb32:
  %t109 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t110 = load i64, ptr %l7, !tbaa !24
  %t111 = load i64, ptr %l2, !tbaa !24
  %t112 = load i64, ptr %l55, !tbaa !24
  %t113 = load %"compiler/source:Span", ptr %l56
  %t114 = load %"compiler/source:Span", ptr %l58
  %t118 = call %"compiler/check:rangeIndex" @compiler_2fcheck_3arangeIndex_2ector(ptr %s0, i64 %t112, %"compiler/source:Span" %t113, %"compiler/source:Span" %t114, { i64, ptr } %t109, i64 %t110, i64 %t111)
  store %"compiler/check:rangeIndex" %t118, ptr %l66
  br label %bb33
bb33:
  %t120 = call %"compiler/check:rangeIndex" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fcheck_3arangeIndex(ptr %s0, ptr %l66)
  store %"compiler/check:rangeIndex" %t120, ptr %l68
  br label %bb34
bb34:
  %t121 = load ptr, ptr %l54, !tbaa !29
  %t122 = load %"compiler/check:rangeIndex", ptr %l68
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3arangeIndex_3e_2ePus_Hb04e4a892496cc754693e16cdaa43e26(ptr %v0, ptr %s0, ptr %t121, %"compiler/check:rangeIndex" %t122)
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2equietPlace(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i1
  %l15 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 4
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/diag:Diagnostics", ptr %t10, i32 0, i32 24
  %t13 = load i1, ptr %t12, !tbaa !21
  store i1 %t13, ptr %l2, !tbaa !21
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/check:Checker", ptr %t15, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = getelementptr %"compiler/generic:Program", ptr %t18, i32 0, i32 0
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = getelementptr %"compiler/load:Loader", ptr %t21, i32 0, i32 4
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = getelementptr %"compiler/diag:Diagnostics", ptr %t24, i32 0, i32 24
  store i1 true, ptr %t26, !tbaa !21
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t31 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplace(ptr %v0, ptr %v1, ptr %v2, ptr %t27, ptr %a1)
  store ptr %t31, ptr %l15
  br label %bb1
bb1:
  %t32 = load ptr, ptr %l15, !tbaa !29
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t33, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = getelementptr %"compiler/generic:Program", ptr %t36, i32 0, i32 0
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t41 = getelementptr %"compiler/load:Loader", ptr %t39, i32 0, i32 4
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t43 = load i1, ptr %l2, !tbaa !21
  %t46 = getelementptr %"compiler/diag:Diagnostics", ptr %t42, i32 0, i32 24
  store i1 %t43, ptr %t46, !tbaa !21
  store ptr %t32, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereplaceTemp(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca i32
  %l12 = alloca ptr
  %l13 = alloca %"compiler/source:Span"
  %l14 = alloca i32
  %l15 = alloca ptr
  %l16 = alloca i1
  %l27 = alloca %"compiler/source:Span"
  %l28 = alloca i32
  %l32 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca i1
  %l46 = alloca %"compiler/source:Span"
  %l47 = alloca i32
  %l52 = alloca ptr
  %l57 = alloca %"compiler/typed:Elem"
  %l61 = alloca ptr
  %l62 = alloca i1
  %l71 = alloca %"compiler/source:Span"
  %l72 = alloca i32
  %l77 = alloca ptr
  %l82 = alloca %"compiler/typed:Payload"
  %l86 = alloca ptr
  %l87 = alloca i1
  %l94 = alloca ptr
  %l97 = alloca i32
  %l98 = alloca i1
  %l99 = alloca %"compiler/source:Span"
  %l100 = alloca i32
  %l104 = alloca ptr
  %rv = alloca ptr
  %t44 = alloca { i64, [4 x i64] }, align 8
  %t112 = alloca { i64, [4 x i64] }, align 8
  %t178 = alloca { i64, [4 x i64] }, align 8
  %t231 = alloca { i64, [4 x i64] }, align 8
  %t250 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t2 = load ptr, ptr %l15, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l15, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l16, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l16, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l3
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l4, !tbaa !23
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [4 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t24, i32 0, i32 2
  %t26 = load ptr, ptr %t25
  store ptr %t26, ptr %l5, !tbaa !29
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr { i64, [4 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t30, i32 0, i32 3
  %t32 = load i64, ptr %t31
  store i64 %t32, ptr %l6, !tbaa !24
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t34 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t34, ptr %l27
  %t35 = load i32, ptr %l4, !tbaa !23
  store i32 %t35, ptr %l28, !tbaa !23
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load ptr, ptr %l5, !tbaa !29
  %t38 = load i64, ptr %l2, !tbaa !24
  %t42 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereplaceTemp(ptr %v0, ptr %v1, ptr %v2, ptr %t36, ptr %t37, i64 %t38)
  store ptr %t42, ptr %l32
  br label %bb6
bb6:
  %t43 = load i64, ptr %l6, !tbaa !24
  store { i64, [4 x i64] } zeroinitializer, ptr %t44
  %t45 = getelementptr { i64, [4 x i64] }, ptr %t44, i32 0, i32 0
  store i64 3, ptr %t45
  %t46 = load %"compiler/source:Span", ptr %l27
  %t47 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } undef, %"compiler/source:Span" %t46, 0
  %t48 = load i32, ptr %l28, !tbaa !23
  %t49 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t47, i32 %t48, 1
  %t50 = load ptr, ptr %l32, !tbaa !29
  %t51 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t49, ptr %t50, 2
  %t53 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t51, i64 %t43, 3
  %t54 = getelementptr { i64, [4 x i64] }, ptr %t44, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i64 } %t53, ptr %t54
  %t55 = load { i64, [4 x i64] }, ptr %t44
  %t57 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t55, ptr %t57
  store ptr %t57, ptr %rv
  br label %ret
bb7:
  %t59 = load ptr, ptr %l1, !tbaa !29
  store ptr %t59, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t60 = load ptr, ptr %l36, !tbaa !29
  %t61 = icmp ne ptr %t60, null
  br i1 %t61, label %bb8, label %bb9
bb8:
  %t63 = load ptr, ptr %l36, !tbaa !29
  %t64 = load i64, ptr %t63, !range !{i64 0, i64 8}
  %t66 = icmp eq i64 %t64, 4
  store i1 %t66, ptr %l37, !tbaa !21
  br label %bb9
bb9:
  %t67 = load i1, ptr %l37, !tbaa !21
  br i1 %t67, label %bb10, label %bb11
bb10:
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t70 = getelementptr { i64, [4 x i64] }, ptr %t68, i32 0, i32 1
  %t71 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t70, i32 0, i32 0
  %t72 = load %"compiler/source:Span", ptr %t71
  store %"compiler/source:Span" %t72, ptr %l7
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr { i64, [4 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t76, i32 0, i32 1
  %t78 = load i32, ptr %t77
  store i32 %t78, ptr %l8, !tbaa !23
  %t80 = load ptr, ptr %l1, !tbaa !29
  %t82 = getelementptr { i64, [4 x i64] }, ptr %t80, i32 0, i32 1
  %t83 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t82, i32 0, i32 2
  %t84 = load ptr, ptr %t83
  store ptr %t84, ptr %l9, !tbaa !29
  br label %bb12
bb11:
  br label %bb15
bb12:
  %t86 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t86, ptr %l46
  %t87 = load i32, ptr %l8, !tbaa !23
  store i32 %t87, ptr %l47, !tbaa !23
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load ptr, ptr %l9, !tbaa !29
  %t91 = getelementptr %"compiler/typed:Elem", ptr %t89, i32 0, i32 0
  %t92 = load ptr, ptr %t91, !tbaa !29
  %t93 = load i64, ptr %l2, !tbaa !24
  %t97 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereplaceTemp(ptr %v0, ptr %v1, ptr %v1, ptr %t88, ptr %t92, i64 %t93)
  store ptr %t97, ptr %l52
  br label %bb13
bb13:
  %t98 = load ptr, ptr %l9, !tbaa !29
  %t100 = getelementptr %"compiler/typed:Elem", ptr %t98, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t102 = load ptr, ptr %l9, !tbaa !29
  %t104 = getelementptr %"compiler/typed:Elem", ptr %t102, i32 0, i32 2
  %t105 = load i32, ptr %t104, !range !{i32 0, i32 4}
  %t106 = load ptr, ptr %l52, !tbaa !29
  %t109 = call %"compiler/typed:Elem" @compiler_2ftyped_3aElem_2ector(ptr %v1, ptr %v1, ptr %v2, ptr %t106, ptr %t101, i32 %t105)
  store %"compiler/typed:Elem" %t109, ptr %l57
  br label %bb14
bb14:
  %t110 = load %"compiler/typed:Elem", ptr %l57
  %t111 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 24, i64 8)
  store %"compiler/typed:Elem" %t110, ptr %t111
  store { i64, [4 x i64] } zeroinitializer, ptr %t112
  %t113 = getelementptr { i64, [4 x i64] }, ptr %t112, i32 0, i32 0
  store i64 4, ptr %t113
  %t114 = load %"compiler/source:Span", ptr %l46
  %t115 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t114, 0
  %t116 = load i32, ptr %l47, !tbaa !23
  %t117 = insertvalue { %"compiler/source:Span", i32, ptr } %t115, i32 %t116, 1
  %t119 = insertvalue { %"compiler/source:Span", i32, ptr } %t117, ptr %t111, 2
  %t120 = getelementptr { i64, [4 x i64] }, ptr %t112, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t119, ptr %t120
  %t121 = load { i64, [4 x i64] }, ptr %t112
  %t123 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t121, ptr %t123
  store ptr %t123, ptr %rv
  br label %ret
bb15:
  %t125 = load ptr, ptr %l1, !tbaa !29
  store ptr %t125, ptr %l61, !tbaa !29
  store i1 false, ptr %l62, !tbaa !21
  %t126 = load ptr, ptr %l61, !tbaa !29
  %t127 = icmp ne ptr %t126, null
  br i1 %t127, label %bb16, label %bb17
bb16:
  %t129 = load ptr, ptr %l61, !tbaa !29
  %t130 = load i64, ptr %t129, !range !{i64 0, i64 8}
  %t132 = icmp eq i64 %t130, 5
  store i1 %t132, ptr %l62, !tbaa !21
  br label %bb17
bb17:
  %t133 = load i1, ptr %l62, !tbaa !21
  br i1 %t133, label %bb18, label %bb19
bb18:
  %t134 = load ptr, ptr %l1, !tbaa !29
  %t136 = getelementptr { i64, [4 x i64] }, ptr %t134, i32 0, i32 1
  %t137 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t136, i32 0, i32 0
  %t138 = load %"compiler/source:Span", ptr %t137
  store %"compiler/source:Span" %t138, ptr %l10
  %t140 = load ptr, ptr %l1, !tbaa !29
  %t142 = getelementptr { i64, [4 x i64] }, ptr %t140, i32 0, i32 1
  %t143 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t142, i32 0, i32 1
  %t144 = load i32, ptr %t143
  store i32 %t144, ptr %l11, !tbaa !23
  %t146 = load ptr, ptr %l1, !tbaa !29
  %t148 = getelementptr { i64, [4 x i64] }, ptr %t146, i32 0, i32 1
  %t149 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t148, i32 0, i32 2
  %t150 = load ptr, ptr %t149
  store ptr %t150, ptr %l12, !tbaa !29
  br label %bb20
bb19:
  br label %bb23
bb20:
  %t152 = load %"compiler/source:Span", ptr %l10
  store %"compiler/source:Span" %t152, ptr %l71
  %t153 = load i32, ptr %l11, !tbaa !23
  store i32 %t153, ptr %l72, !tbaa !23
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t155 = load ptr, ptr %l12, !tbaa !29
  %t157 = getelementptr %"compiler/typed:Payload", ptr %t155, i32 0, i32 0
  %t158 = load ptr, ptr %t157, !tbaa !29
  %t159 = load i64, ptr %l2, !tbaa !24
  %t163 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereplaceTemp(ptr %v0, ptr %v1, ptr %v1, ptr %t154, ptr %t158, i64 %t159)
  store ptr %t163, ptr %l77
  br label %bb21
bb21:
  %t164 = load ptr, ptr %l12, !tbaa !29
  %t166 = getelementptr %"compiler/typed:Payload", ptr %t164, i32 0, i32 1
  %t167 = load i64, ptr %t166, !tbaa !24
  %t168 = load ptr, ptr %l12, !tbaa !29
  %t170 = getelementptr %"compiler/typed:Payload", ptr %t168, i32 0, i32 2
  %t171 = load i32, ptr %t170, !range !{i32 0, i32 4}
  %t172 = load ptr, ptr %l77, !tbaa !29
  %t175 = call %"compiler/typed:Payload" @compiler_2ftyped_3aPayload_2ector(ptr %v1, ptr %v2, ptr %t172, i64 %t167, i32 %t171)
  store %"compiler/typed:Payload" %t175, ptr %l82
  br label %bb22
bb22:
  %t176 = load %"compiler/typed:Payload", ptr %l82
  %t177 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 24, i64 8)
  store %"compiler/typed:Payload" %t176, ptr %t177
  store { i64, [4 x i64] } zeroinitializer, ptr %t178
  %t179 = getelementptr { i64, [4 x i64] }, ptr %t178, i32 0, i32 0
  store i64 5, ptr %t179
  %t180 = load %"compiler/source:Span", ptr %l71
  %t181 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t180, 0
  %t182 = load i32, ptr %l72, !tbaa !23
  %t183 = insertvalue { %"compiler/source:Span", i32, ptr } %t181, i32 %t182, 1
  %t185 = insertvalue { %"compiler/source:Span", i32, ptr } %t183, ptr %t177, 2
  %t186 = getelementptr { i64, [4 x i64] }, ptr %t178, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t185, ptr %t186
  %t187 = load { i64, [4 x i64] }, ptr %t178
  %t189 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t187, ptr %t189
  store ptr %t189, ptr %rv
  br label %ret
bb23:
  %t191 = load ptr, ptr %l1, !tbaa !29
  store ptr %t191, ptr %l86, !tbaa !29
  store i1 false, ptr %l87, !tbaa !21
  %t192 = load ptr, ptr %l86, !tbaa !29
  %t193 = icmp ne ptr %t192, null
  br i1 %t193, label %bb24, label %bb25
bb24:
  %t195 = load ptr, ptr %l86, !tbaa !29
  %t196 = load i64, ptr %t195, !range !{i64 0, i64 8}
  %t198 = icmp eq i64 %t196, 6
  store i1 %t198, ptr %l87, !tbaa !21
  br label %bb25
bb25:
  %t199 = load i1, ptr %l87, !tbaa !21
  br i1 %t199, label %bb26, label %bb27
bb26:
  %t200 = load ptr, ptr %l1, !tbaa !29
  %t202 = getelementptr { i64, [4 x i64] }, ptr %t200, i32 0, i32 1
  %t203 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t202, i32 0, i32 0
  %t204 = load %"compiler/source:Span", ptr %t203
  store %"compiler/source:Span" %t204, ptr %l13
  %t206 = load ptr, ptr %l1, !tbaa !29
  %t208 = getelementptr { i64, [4 x i64] }, ptr %t206, i32 0, i32 1
  %t209 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t208, i32 0, i32 1
  %t210 = load i32, ptr %t209
  store i32 %t210, ptr %l14, !tbaa !23
  br label %bb28
bb27:
  br label %bb35
bb28:
  %t212 = load ptr, ptr %l0, !tbaa !29
  store ptr %t212, ptr %l94, !tbaa !29
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t214 = load i64, ptr %l2, !tbaa !24
  %t217 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t213, i64 %t214)
  store i32 %t217, ptr %l97
  br label %bb29
bb29:
  %t218 = load ptr, ptr %l94, !tbaa !29
  %t219 = load i32, ptr %l97, !tbaa !23
  %t220 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t218, i32 %t219)
  store i1 %t220, ptr %l98
  br label %bb30
bb30:
  %t221 = load i1, ptr %l98, !tbaa !21
  br i1 %t221, label %bb31, label %bb32
bb31:
  %t222 = load %"compiler/source:Span", ptr %l13
  store %"compiler/source:Span" %t222, ptr %l99
  %t223 = load i32, ptr %l14, !tbaa !23
  store i32 %t223, ptr %l100, !tbaa !23
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t225 = load %"compiler/source:Span", ptr %l13
  %t226 = load i64, ptr %l2, !tbaa !24
  %t230 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v2, ptr %t224, %"compiler/source:Span" %t225, i64 %t226)
  store ptr %t230, ptr %l104
  br label %bb33
bb32:
  br label %bb34
bb33:
  store { i64, [4 x i64] } zeroinitializer, ptr %t231
  %t232 = getelementptr { i64, [4 x i64] }, ptr %t231, i32 0, i32 0
  store i64 2, ptr %t232
  %t233 = load %"compiler/source:Span", ptr %l99
  %t234 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t233, 0
  %t235 = load i32, ptr %l100, !tbaa !23
  %t236 = insertvalue { %"compiler/source:Span", i32, ptr } %t234, i32 %t235, 1
  %t237 = load ptr, ptr %l104, !tbaa !29
  %t238 = insertvalue { %"compiler/source:Span", i32, ptr } %t236, ptr %t237, 2
  %t239 = getelementptr { i64, [4 x i64] }, ptr %t231, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t238, ptr %t239
  %t240 = load { i64, [4 x i64] }, ptr %t231
  %t242 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t240, ptr %t242
  store ptr %t242, ptr %rv
  br label %ret
bb34:
  %t244 = load %"compiler/source:Span", ptr %l13
  %t245 = load i32, ptr %l14, !tbaa !23
  %t246 = load i64, ptr %l2, !tbaa !24
  %t248 = trunc i64 %t246 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t250
  %t251 = getelementptr { i64, [4 x i64] }, ptr %t250, i32 0, i32 0
  store i64 0, ptr %t251
  %t253 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t244, 0
  %t255 = insertvalue { %"compiler/source:Span", i32, i32 } %t253, i32 %t245, 1
  %t257 = insertvalue { %"compiler/source:Span", i32, i32 } %t255, i32 %t248, 2
  %t258 = getelementptr { i64, [4 x i64] }, ptr %t250, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t257, ptr %t258
  %t259 = load { i64, [4 x i64] }, ptr %t250
  %t261 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t259, ptr %t261
  store ptr %t261, ptr %rv
  br label %ret
bb35:
  br i1 true, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb39
bb38:
  %t263 = load ptr, ptr %l1, !tbaa !29
  store ptr %t263, ptr %rv
  br label %ret
bb39:
  call void @__olang_check_failed(ptr @olang_loc_d14fb46e4520a903_82d87293fe98a067)
  unreachable
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresultBinds(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i64
  %l14 = alloca i32
  %l19 = alloca i32
  %l23 = alloca i1
  %l28 = alloca i64
  %l35 = alloca i64
  %l40 = alloca i1
  %l42 = alloca { i64, ptr }
  %l47 = alloca i1
  %l52 = alloca i1
  %l54 = alloca ptr
  %l55 = alloca i64
  %l56 = alloca i64
  %l62 = alloca i32
  %l64 = alloca i1
  %l67 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l4, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t12, i32 %a1)
  store i32 %t16, ptr %l14
  br label %bb4
bb4:
  %t17 = load i32, ptr %l14, !tbaa !23
  store i32 %t17, ptr %l5, !tbaa !23
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = getelementptr %"compiler/generic:Program", ptr %t21, i32 0, i32 2
  %t24 = load i32, ptr %l5, !tbaa !23
  %t27 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t27, ptr %l19
  br label %bb5
bb5:
  %t28 = load i32, ptr %l19, !range !{i32 0, i32 33}
  %t30 = trunc i64 25 to i32
  %t31 = icmp eq i32 %t28, %t30
  %t33 = xor i1 %t31, true
  br i1 %t33, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb9
bb7:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/check:Checker", ptr %t35, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = getelementptr %"compiler/generic:Program", ptr %t38, i32 0, i32 2
  %t41 = load i32, ptr %l5, !tbaa !23
  %t44 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t40, i32 %t41)
  store i64 %t44, ptr %l28
  br label %bb8
bb8:
  %t45 = load i64, ptr %l2, !tbaa !24
  %t46 = load i64, ptr %l28, !tbaa !24
  %t48 = icmp ne i64 %t46, %t45
  store i1 %t48, ptr %l23, !tbaa !21
  br label %bb9
bb9:
  %t50 = load i1, ptr %l23, !tbaa !21
  br i1 %t50, label %bb10, label %bb11
bb10:
  br label %ret
bb11:
  br label %bb12
bb12:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/check:Checker", ptr %t51, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t56 = getelementptr %"compiler/generic:Program", ptr %t54, i32 0, i32 2
  %t57 = load i32, ptr %l5, !tbaa !23
  %t60 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %t56, i32 %t57)
  store i64 %t60, ptr %l35
  br label %bb13
bb13:
  %t61 = load i64, ptr %l35, !tbaa !24
  store i64 %t61, ptr %l6, !tbaa !24
  %t62 = load i64, ptr %l6, !tbaa !24
  %t63 = load ptr, ptr %l3, !tbaa !29
  %t65 = getelementptr %"compiler/generic:Binding", ptr %t63, i32 0, i32 1
  %t66 = load i64, ptr %t65, !tbaa !24
  %t69 = icmp sge i64 %t62, %t66
  br i1 %t69, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb16
bb15:
  %t71 = load ptr, ptr %l3, !tbaa !29
  %t73 = getelementptr %"compiler/generic:Binding", ptr %t71, i32 0, i32 2
  %t74 = load { i64, ptr }, ptr %t73, !tbaa !27
  store { i64, ptr } %t74, ptr %l42, !tbaa !27
  %t75 = load i64, ptr %l6, !tbaa !24
  %t77 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr i32, ptr %t78, i64 %t75
  %t80 = load i32, ptr %t79, !tbaa !33
  %t81 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t84 = icmp ne i32 %t80, %t81
  store i1 %t84, ptr %l40, !tbaa !21
  br label %bb16
bb16:
  %t86 = load i1, ptr %l40, !tbaa !21
  br i1 %t86, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l47, !tbaa !21
  br label %bb20
bb18:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/check:Checker", ptr %t87, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !29
  %t91 = load i64, ptr %l2, !tbaa !24
  %t92 = load i64, ptr %l6, !tbaa !24
  %t96 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrVarAt(ptr %v0, ptr %t90, i64 %t91, i64 %t92)
  store i1 %t96, ptr %l52
  br label %bb19
bb19:
  %t97 = load i1, ptr %l52, !tbaa !21
  store i1 %t97, ptr %l47, !tbaa !21
  br label %bb20
bb20:
  %t98 = load i1, ptr %l47, !tbaa !21
  br i1 %t98, label %bb21, label %bb22
bb21:
  br label %ret
bb22:
  br label %bb23
bb23:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/check:Checker", ptr %t99, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !29
  store ptr %t102, ptr %l54, !tbaa !29
  %t103 = load i64, ptr %l2, !tbaa !24
  store i64 %t103, ptr %l55, !tbaa !24
  %t104 = load i64, ptr %l6, !tbaa !24
  store i64 %t104, ptr %l56, !tbaa !24
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/check:Checker", ptr %t105, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !29
  %t110 = getelementptr %"compiler/generic:Program", ptr %t108, i32 0, i32 2
  %t111 = load ptr, ptr %l3, !tbaa !29
  %t113 = getelementptr %"compiler/generic:Binding", ptr %t111, i32 0, i32 2
  %t114 = load { i64, ptr }, ptr %t113, !tbaa !27
  %t117 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %t110, { i64, ptr } %t114)
  store i32 %t117, ptr %l62
  br label %bb24
bb24:
  %t118 = load i32, ptr %l4, !tbaa !23
  %t119 = load ptr, ptr %l54, !tbaa !29
  %t120 = load i64, ptr %l55, !tbaa !24
  %t121 = load i64, ptr %l56, !tbaa !24
  %t122 = load i32, ptr %l62, !tbaa !23
  %t124 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMeetsBound(ptr %v0, ptr %t119, i64 %t120, i64 %t121, i32 %t122, i32 %t118)
  store i1 %t124, ptr %l64
  br label %bb25
bb25:
  %t125 = load i1, ptr %l64, !tbaa !21
  %t126 = xor i1 %t125, true
  br i1 %t126, label %bb26, label %bb27
bb26:
  br label %ret
bb27:
  br label %bb28
bb28:
  %t128 = load ptr, ptr %l3, !tbaa !29
  %t130 = getelementptr %"compiler/generic:Binding", ptr %t128, i32 0, i32 2
  %t131 = load { i64, ptr }, ptr %t130, !tbaa !27
  store { i64, ptr } %t131, ptr %l67, !tbaa !27
  %t132 = load i64, ptr %l6, !tbaa !24
  %t133 = load i32, ptr %l4, !tbaa !23
  %t136 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !27
  %t138 = getelementptr i32, ptr %t137, i64 %t132
  store i32 %t133, ptr %t138, !tbaa !33
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/check:Checker", ptr %t139, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !29
  %t143 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInferThroughBounds(ptr %v0, ptr %v1, ptr %t142, ptr %t143)
  br label %bb29
bb29:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroBorrowedFrom(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l12 = alloca i64
  %l15 = alloca i1
  %l18 = alloca i1
  %l27 = alloca i64
  %l30 = alloca i64
  %l51 = alloca i1
  %l52 = alloca i1
  %l56 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/typed:Call", ptr %t2, i32 0, i32 0
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t8 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyOfCallee(ptr %v0, ptr %v1, ptr %t1, ptr %t5)
  store i64 %t8, ptr %l12
  br label %bb1
bb1:
  %t9 = load i64, ptr %l12, !tbaa !24
  store i64 %t9, ptr %l2, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t12 = icmp slt i64 %t10, 0
  br i1 %t12, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb5
bb3:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i64, ptr %l2, !tbaa !24
  %t18 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceBody(ptr %v0, ptr %t14, i64 %t15)
  store i1 %t18, ptr %l18
  br label %bb4
bb4:
  %t19 = load i1, ptr %l18, !tbaa !21
  %t20 = xor i1 %t19, true
  store i1 %t20, ptr %l15, !tbaa !21
  br label %bb5
bb5:
  %t22 = load i1, ptr %l15, !tbaa !21
  br i1 %t22, label %bb6, label %bb7
bb6:
  store i64 -1, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  store i64 0, ptr %l3, !tbaa !24
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Call", ptr %t24, i32 0, i32 1
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  store i64 %t29, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t31 = load i64, ptr %l4, !tbaa !24
  %t32 = load i64, ptr %l3, !tbaa !24
  %t35 = icmp sgt i64 %t31, %t32
  br i1 %t35, label %bb9, label %bb10
bb9:
  %t37 = load i64, ptr %l5, !tbaa !24
  %t39 = icmp sgt i64 %t37, 0
  br i1 %t39, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb14
bb11:
  %t41 = load i64, ptr %l4, !tbaa !24
  %t42 = load i64, ptr %l3, !tbaa !24
  %t45 = sub i64 %t41, %t42
  %t46 = load i64, ptr %l5, !tbaa !24
  %t49 = add i64 %t45, %t46
  %t51 = sub i64 %t49, 1
  %t52 = load i64, ptr %l5, !tbaa !24
  %t55 = sdiv i64 %t51, %t52
  store i64 %t55, ptr %l30, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb13
bb13:
  %t57 = load i64, ptr %l30, !tbaa !24
  store i64 %t57, ptr %l27, !tbaa !24
  br label %bb14
bb14:
  %t58 = load i64, ptr %l27, !tbaa !24
  store i64 %t58, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb15
bb15:
  %t59 = load i64, ptr %l7, !tbaa !24
  %t60 = load i64, ptr %l6, !tbaa !24
  %t63 = icmp slt i64 %t59, %t60
  %t65 = xor i1 %t63, true
  br i1 %t65, label %bb16, label %bb17
bb16:
  br label %bb28
bb17:
  br label %bb18
bb18:
  %t67 = load i64, ptr %l3, !tbaa !24
  %t68 = load i64, ptr %l7, !tbaa !24
  %t69 = load i64, ptr %l5, !tbaa !24
  %t72 = mul i64 %t68, %t69
  %t75 = add i64 %t67, %t72
  store i64 %t75, ptr %l8, !tbaa !24
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load i64, ptr %l2, !tbaa !24
  %t79 = load i64, ptr %l8, !tbaa !24
  %t83 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroByArg(ptr %v0, ptr %t77, i64 %t78, i64 %t79)
  store i1 %t83, ptr %l51
  br label %bb19
bb19:
  %t84 = load i1, ptr %l51, !tbaa !21
  br i1 %t84, label %bb20, label %bb21
bb20:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load i64, ptr %l2, !tbaa !24
  %t87 = load i64, ptr %l8, !tbaa !24
  %t91 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroFollows(ptr %v0, ptr %t85, i64 %t86, i64 %t87)
  store i1 %t91, ptr %l56
  br label %bb22
bb21:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb23
bb22:
  %t92 = load i1, ptr %l56, !tbaa !21
  store i1 %t92, ptr %l52, !tbaa !21
  br label %bb23
bb23:
  %t93 = load i1, ptr %l52, !tbaa !21
  br i1 %t93, label %bb24, label %bb25
bb24:
  %t94 = load i64, ptr %l8, !tbaa !24
  store i64 %t94, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  br label %bb27
bb27:
  %t96 = load i64, ptr %l7, !tbaa !24
  %t98 = add i64 %t96, 1
  store i64 %t98, ptr %l7, !tbaa !24
  br label %bb15
bb28:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroFix(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l5 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i1
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l5, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t11 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t7, i32 %a2)
  store i32 %t11, ptr %l8
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l5, !tbaa !29
  %t13 = load i32, ptr %l8, !tbaa !23
  %t14 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclaresCopy(ptr %v0, ptr %t12, i32 %t13)
  store i1 %t14, ptr %l9
  br label %bb2
bb2:
  %t15 = load i1, ptr %l9, !tbaa !21
  %t16 = xor i1 %t15, true
  br i1 %t16, label %bb3, label %bb4
bb3:
  store { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d32, i32 0, i32 1) }, ptr %l11, !tbaa !27
  %t18 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t18, ptr %l12, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t19, 0
  store i64 %t20, ptr %l13, !tbaa !24
  %t21 = load i64, ptr %l13, !tbaa !24
  %t22 = mul i64 %t21, 1
  %t23 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t22)
  %t24 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  store { i64, ptr } %t25, ptr %l14, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = load i64, ptr %l13, !tbaa !24
  %t31 = mul i64 %t30, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t27, ptr %t29, i64 %t31, i1 false)
  %t32 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t32, ptr %l12, !tbaa !27
  %t33 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t33, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t34 = load i32, ptr %l1, !tbaa !23
  %t36 = icmp ne i32 %t34, 0
  br i1 %t36, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load i32, ptr %l1, !tbaa !23
  %t42 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s2, ptr %t38, i32 %t39)
  store { i64, ptr } %t42, ptr %l19
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t43 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d33, i32 0, i32 1) }, 1
  %t44 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d33, i32 0, i32 1) }, 0
  %t45 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t45, 1
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t48 = add i64 %t44, %t47
  %t49 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  %t50 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d34, i32 0, i32 1) }, 0
  %t51 = add i64 %t48, %t50
  %t52 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t51)
  call void @olang_textcopy(ptr %t52, ptr %t43, i64 %t44)
  %t53 = getelementptr i8, ptr %t52, i64 %t44
  call void @olang_textcopy(ptr %t53, ptr %t46, i64 %t47)
  %t54 = getelementptr i8, ptr %t53, i64 %t47
  call void @olang_textcopy(ptr %t54, ptr %t49, i64 %t50)
  %t55 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t52, 1
  call void @__olang_scope_close(ptr %s2)
  store { i64, ptr } %t56, ptr %rv
  br label %ret
bb9:
  store { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d35, i32 0, i32 1) }, ptr %l21, !tbaa !27
  %t58 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t58, ptr %l22, !tbaa !27
  %t59 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t59, 0
  store i64 %t60, ptr %l23, !tbaa !24
  %t61 = load i64, ptr %l23, !tbaa !24
  %t62 = mul i64 %t61, 1
  %t63 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t62)
  %t64 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t63, 1
  store { i64, ptr } %t65, ptr %l24, !tbaa !27
  %t66 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !27
  %t68 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = load i64, ptr %l23, !tbaa !24
  %t71 = mul i64 %t70, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t67, ptr %t69, i64 %t71, i1 false)
  %t72 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t72, ptr %l22, !tbaa !27
  %t73 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t73, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esayUncovered(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i32 %a2, ptr %a3, ptr %a4, i1 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i1
  %l6 = alloca i32
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l16 = alloca i32
  %l19 = alloca %"compiler/source:Span"
  %l22 = alloca i1
  %l26 = alloca i64
  %l31 = alloca { i64, ptr }
  %l34 = alloca ptr
  %l35 = alloca %"compiler/source:Span"
  %l39 = alloca i1
  %l44 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l54 = alloca %"compiler/diagmsg:Msg"
  %l55 = alloca i64
  %l57 = alloca i64
  %l59 = alloca i1
  %l64 = alloca i32
  %l68 = alloca ptr
  %l73 = alloca i32
  %l74 = alloca { i64, ptr }
  %l75 = alloca i64
  %l77 = alloca i64
  %l78 = alloca i32
  %l81 = alloca i1
  %l86 = alloca ptr
  %l87 = alloca %"compiler/source:Span"
  %l89 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l98 = alloca %"compiler/diagmsg:Msg"
  %l99 = alloca i64
  %l101 = alloca i1
  %l105 = alloca i1
  %l108 = alloca i1
  %l109 = alloca i64
  %l112 = alloca i64
  %l113 = alloca i32
  %l115 = alloca i1
  %l118 = alloca i64
  %l121 = alloca { i64, ptr }
  %l122 = alloca i64
  %l125 = alloca i64
  %l127 = alloca { i64, ptr }
  %l129 = alloca ptr
  %l135 = alloca %"compiler/source:Span"
  %l138 = alloca { i64, ptr }
  %l141 = alloca %"compiler/diagmsg:Msg"
  %l142 = alloca i64
  %l144 = alloca i1
  %l148 = alloca ptr
  %l154 = alloca %"compiler/source:Span"
  %l157 = alloca { i64, ptr }
  %l159 = alloca %"compiler/diagmsg:Msg"
  %l160 = alloca i64
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  store i1 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l16
  br label %bb1
bb1:
  %t6 = load i32, ptr %l16, !tbaa !23
  store i32 %t6, ptr %l6, !tbaa !23
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t9 = getelementptr %"compiler/ast:Match", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t10)
  store %"compiler/source:Span" %t12, ptr %l19
  br label %bb2
bb2:
  %t13 = load %"compiler/source:Span", ptr %l19
  store %"compiler/source:Span" %t13, ptr %l7
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i32, ptr %l6, !tbaa !23
  %t18 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t14, i32 %t15)
  store i1 %t18, ptr %l22
  br label %bb3
bb3:
  %t19 = load i1, ptr %l22, !tbaa !21
  br i1 %t19, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t22 = load i32, ptr %l6, !tbaa !23
  %t26 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efirstUncovered(ptr %v0, ptr %v2, ptr %t20, ptr %t21, i32 %t22)
  store i64 %t26, ptr %l26
  br label %bb6
bb5:
  br label %bb21
bb6:
  %t27 = load i64, ptr %l26, !tbaa !24
  store i64 %t27, ptr %l8, !tbaa !24
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/generic:Program", ptr %t31, i32 0, i32 2
  %t34 = load i32, ptr %l6, !tbaa !23
  %t37 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %s1, ptr %t33, i32 %t34)
  store { i64, ptr } %t37, ptr %l31
  br label %bb7
bb7:
  %t38 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t38, ptr %l9, !tbaa !27
  %t39 = load i64, ptr %l8, !tbaa !24
  %t41 = icmp sge i64 %t39, 0
  br i1 %t41, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l34, !tbaa !29
  %t44 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t44, ptr %l35
  %t45 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t49 = icmp sgt i64 %t47, 0
  br i1 %t49, label %bb10, label %bb11
bb9:
  br label %bb20
bb10:
  %t51 = load i64, ptr %l8, !tbaa !24
  %t52 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t52, 0
  %t57 = icmp slt i64 %t51, %t54
  store i1 %t57, ptr %l39, !tbaa !21
  br label %bb12
bb11:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb12
bb12:
  %t59 = load i1, ptr %l39, !tbaa !21
  br i1 %t59, label %bb13, label %bb14
bb13:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t61, ptr %l46, !tbaa !27
  %t62 = load i64, ptr %l8, !tbaa !24
  %t64 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = getelementptr i32, ptr %t65, i64 %t62
  %t67 = load i32, ptr %t66, !tbaa !33
  %t70 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s2, ptr %t60, i32 %t67)
  store { i64, ptr } %t70, ptr %l49
  br label %bb15
bb14:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) }, ptr %l44, !tbaa !27
  br label %bb16
bb15:
  %t71 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t71, ptr %l44, !tbaa !27
  br label %bb16
bb16:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load i32, ptr %l6, !tbaa !23
  %t76 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t72, i32 %t73)
  store { i64, ptr } %t76, ptr %l52
  br label %bb17
bb17:
  %t77 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t77, 0
  %t79 = extractvalue { i64, ptr } %t77, 1
  %t80 = mul i64 %t78, 1
  %t81 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t80)
  call void @llvm.memcpy.p0.p0.i64(ptr %t81, ptr %t79, i64 %t80, i1 false)
  %t82 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t83 = insertvalue { i64, ptr } %t82, ptr %t81, 1
  %t84 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t86 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMatchNotExhaustive(ptr %s2, ptr %s2, ptr %v0, { i64, ptr } %t84, { i64, ptr } %t83)
  store %"compiler/diagmsg:Msg" %t86, ptr %l54
  br label %bb18
bb18:
  %t87 = load ptr, ptr %l34, !tbaa !29
  %t88 = load %"compiler/source:Span", ptr %l35
  %t89 = load %"compiler/diagmsg:Msg", ptr %l54
  %t90 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t87, %"compiler/source:Span" %t88, %"compiler/diagmsg:Msg" %t89)
  store i64 %t90, ptr %l55
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb21:
  %t91 = load ptr, ptr %l4, !tbaa !29
  %t93 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v3, ptr %t91)
  store i64 %t93, ptr %l57
  br label %bb22
bb22:
  %t94 = load i64, ptr %l57, !tbaa !24
  %t95 = icmp sgt i64 %t94, 0
  br i1 %t95, label %bb23, label %bb24
bb23:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/check:Checker", ptr %t97, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = getelementptr %"compiler/generic:Program", ptr %t100, i32 0, i32 2
  %t103 = load i32, ptr %l6, !tbaa !23
  %t106 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t102, i32 %t103)
  store i32 %t106, ptr %l64
  br label %bb25
bb24:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb26
bb25:
  %t107 = load i32, ptr %l64, !range !{i32 0, i32 33}
  %t109 = trunc i64 29 to i32
  %t110 = icmp eq i32 %t107, %t109
  store i1 %t110, ptr %l59, !tbaa !21
  br label %bb26
bb26:
  %t112 = load i1, ptr %l59, !tbaa !21
  br i1 %t112, label %bb27, label %bb28
bb27:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/check:Checker", ptr %t113, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !29
  store ptr %t116, ptr %l68, !tbaa !29
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/check:Checker", ptr %t117, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !29
  %t122 = getelementptr %"compiler/generic:Program", ptr %t120, i32 0, i32 2
  %t123 = load i32, ptr %l6, !tbaa !23
  %t126 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %t122, i32 %t123)
  store i32 %t126, ptr %l73
  br label %bb29
bb28:
  br label %bb45
bb29:
  %t127 = load ptr, ptr %l68, !tbaa !29
  %t128 = load i32, ptr %l73, !tbaa !23
  %t129 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMembers(ptr %v0, ptr %v0, ptr %t127, i32 %t128)
  store { i64, ptr } %t129, ptr %l74
  br label %bb30
bb30:
  %t130 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t130, ptr %l10, !tbaa !27
  %t131 = load ptr, ptr %l4, !tbaa !29
  %t133 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eIndexOf_3cBool_3e(ptr %v3, ptr %t131, i1 false)
  %t134 = extractvalue { i32, i64 } %t133, 1
  %t135 = extractvalue { i32, i64 } %t133, 0
  store i32 %t135, ptr %l78
  %t136 = icmp ne i32 %t135, 0
  br i1 %t136, label %bb32, label %ok.137, !prof !99
ok.137:
  store i64 %t134, ptr %l77
  br label %bb31
bb31:
  %t138 = load i64, ptr %l77, !tbaa !24
  store i64 %t138, ptr %l75, !tbaa !24
  br label %bb34
bb32:
  br label %bb33
bb33:
  store i64 -1, ptr %l75, !tbaa !24
  br label %bb34
bb34:
  %t139 = load i64, ptr %l75, !tbaa !24
  store i64 %t139, ptr %l11, !tbaa !24
  %t140 = load i64, ptr %l11, !tbaa !24
  %t142 = icmp sge i64 %t140, 0
  br i1 %t142, label %bb35, label %bb36
bb35:
  %t144 = load i64, ptr %l11, !tbaa !24
  %t145 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t147 = extractvalue { i64, ptr } %t145, 0
  %t150 = icmp slt i64 %t144, %t147
  store i1 %t150, ptr %l81, !tbaa !21
  br label %bb37
bb36:
  store i1 false, ptr %l81, !tbaa !21
  br label %bb37
bb37:
  %t152 = load i1, ptr %l81, !tbaa !21
  br i1 %t152, label %bb38, label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s4
  %t153 = load ptr, ptr %l0, !tbaa !29
  store ptr %t153, ptr %l86, !tbaa !29
  %t154 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t154, ptr %l87
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t156, ptr %l89, !tbaa !27
  %t157 = load i64, ptr %l11, !tbaa !24
  %t159 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !27
  %t161 = getelementptr i32, ptr %t160, i64 %t157
  %t162 = load i32, ptr %t161, !tbaa !33
  %t165 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s4, ptr %t155, i32 %t162)
  store { i64, ptr } %t165, ptr %l92
  br label %bb40
bb39:
  br label %bb44
bb40:
  %t166 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t167 = extractvalue { i64, ptr } %t166, 0
  %t168 = extractvalue { i64, ptr } %t166, 1
  %t169 = mul i64 %t167, 1
  %t170 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t169)
  call void @llvm.memcpy.p0.p0.i64(ptr %t170, ptr %t168, i64 %t169, i1 false)
  %t171 = insertvalue { i64, ptr } undef, i64 %t167, 0
  %t172 = insertvalue { i64, ptr } %t171, ptr %t170, 1
  store { i64, ptr } %t172, ptr %l93, !tbaa !27
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load i32, ptr %l2, !tbaa !23
  %t177 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s4, ptr %t173, i32 %t174)
  store { i64, ptr } %t177, ptr %l96
  br label %bb41
bb41:
  %t178 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t179 = extractvalue { i64, ptr } %t178, 0
  %t180 = extractvalue { i64, ptr } %t178, 1
  %t181 = mul i64 %t179, 1
  %t182 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t181)
  call void @llvm.memcpy.p0.p0.i64(ptr %t182, ptr %t180, i64 %t181, i1 false)
  %t183 = insertvalue { i64, ptr } undef, i64 %t179, 0
  %t184 = insertvalue { i64, ptr } %t183, ptr %t182, 1
  %t185 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t187 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMatchNotExhaustive(ptr %s4, ptr %s4, ptr %v0, { i64, ptr } %t185, { i64, ptr } %t184)
  store %"compiler/diagmsg:Msg" %t187, ptr %l98
  br label %bb42
bb42:
  %t188 = load ptr, ptr %l86, !tbaa !29
  %t189 = load %"compiler/source:Span", ptr %l87
  %t190 = load %"compiler/diagmsg:Msg", ptr %l98
  %t191 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t188, %"compiler/source:Span" %t189, %"compiler/diagmsg:Msg" %t190)
  store i64 %t191, ptr %l99
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s4)
  br label %bb44
bb44:
  br label %ret
bb45:
  %t192 = load i1, ptr %l5, !tbaa !21
  br i1 %t192, label %bb46, label %bb47
bb46:
  %t194 = load i32, ptr %l2, !tbaa !23
  %t195 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t198 = icmp ne i32 %t194, %t195
  store i1 %t198, ptr %l101, !tbaa !21
  br label %bb48
bb47:
  store i1 false, ptr %l101, !tbaa !21
  br label %bb48
bb48:
  %t200 = load i1, ptr %l101, !tbaa !21
  br i1 %t200, label %bb49, label %bb50
bb49:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t202 = load ptr, ptr %l3, !tbaa !29
  %t205 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eseqColumn(ptr %v0, ptr %v2, ptr %t201, ptr %t202)
  store i1 %t205, ptr %l108
  br label %bb51
bb50:
  store i1 false, ptr %l105, !tbaa !21
  br label %bb52
bb51:
  %t206 = load i1, ptr %l108, !tbaa !21
  store i1 %t206, ptr %l105, !tbaa !21
  br label %bb52
bb52:
  %t207 = load i1, ptr %l105, !tbaa !21
  br i1 %t207, label %bb53, label %bb54
bb53:
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t209 = load ptr, ptr %l3, !tbaa !29
  %t212 = call { i32, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eseqUncovered(ptr %v0, ptr %v2, ptr %t208, ptr %t209)
  %t213 = extractvalue { i32, i64 } %t212, 1
  %t214 = extractvalue { i32, i64 } %t212, 0
  store i32 %t214, ptr %l113
  %t215 = icmp ne i32 %t214, 0
  br i1 %t215, label %bb56, label %ok.216, !prof !99
ok.216:
  store i64 %t213, ptr %l112
  br label %bb55
bb54:
  br label %bb73
bb55:
  %t217 = load i64, ptr %l112, !tbaa !24
  store i64 %t217, ptr %l109, !tbaa !24
  br label %bb58
bb56:
  %t218 = load i32, ptr %l113, !tbaa !23
  %t219 = ashr i32 %t218, 16
  %t221 = icmp eq i32 %t219, 1
  store i1 %t221, ptr %l115, !tbaa !21
  br label %bb57
bb57:
  store i64 -1, ptr %l109, !tbaa !24
  br label %bb58
bb58:
  %t222 = load i64, ptr %l109, !tbaa !24
  store i64 %t222, ptr %l12, !tbaa !24
  %t223 = load i64, ptr %l12, !tbaa !24
  %t225 = icmp sge i64 %t223, 0
  br i1 %t225, label %bb59, label %bb60
bb59:
  store %olang.scope zeroinitializer, ptr %s6
  %t227 = load i64, ptr %l12, !tbaa !24
  store i64 %t227, ptr %l118, !tbaa !24
  %t228 = load i64, ptr %l12, !tbaa !24
  %t230 = icmp eq i64 %t228, 1
  br i1 %t230, label %bb61, label %bb62
bb60:
  br label %bb72
bb61:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d37, i32 0, i32 1) }, ptr %l121, !tbaa !27
  br label %bb63
bb62:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d38, i32 0, i32 1) }, ptr %l121, !tbaa !27
  br label %bb63
bb63:
  %t232 = load i64, ptr %l12, !tbaa !24
  store i64 %t232, ptr %l122, !tbaa !24
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t234 = load ptr, ptr %l3, !tbaa !29
  %t237 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eseqLongest(ptr %v0, ptr %v2, ptr %t233, ptr %t234)
  store i64 %t237, ptr %l125
  br label %bb64
bb64:
  %t238 = load i64, ptr %l122, !tbaa !24
  %t239 = load i64, ptr %l125, !tbaa !24
  %t240 = icmp sgt i64 %t238, %t239
  br i1 %t240, label %bb65, label %bb66
bb65:
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d39, i32 0, i32 1) }, ptr %l127, !tbaa !27
  br label %bb67
bb66:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d40, i32 0, i32 1) }, ptr %l127, !tbaa !27
  br label %bb67
bb67:
  %t242 = load i64, ptr %l118, !tbaa !24
  %t243 = call i64 @__olang_fmt_i64(ptr null, i64 %t242)
  %t244 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d41, i32 0, i32 1) }, 1
  %t245 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d41, i32 0, i32 1) }, 0
  %t246 = add i64 %t243, %t245
  %t247 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t248 = extractvalue { i64, ptr } %t247, 1
  %t249 = extractvalue { i64, ptr } %t247, 0
  %t250 = add i64 %t246, %t249
  %t251 = load { i64, ptr }, ptr %l127, !tbaa !27
  %t252 = extractvalue { i64, ptr } %t251, 1
  %t253 = extractvalue { i64, ptr } %t251, 0
  %t254 = add i64 %t250, %t253
  %t255 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t254)
  %t256 = call i64 @__olang_fmt_i64(ptr %t255, i64 %t242)
  %t257 = getelementptr i8, ptr %t255, i64 %t243
  call void @olang_textcopy(ptr %t257, ptr %t244, i64 %t245)
  %t258 = getelementptr i8, ptr %t257, i64 %t245
  call void @olang_textcopy(ptr %t258, ptr %t248, i64 %t249)
  %t259 = getelementptr i8, ptr %t258, i64 %t249
  call void @olang_textcopy(ptr %t259, ptr %t252, i64 %t253)
  %t260 = insertvalue { i64, ptr } undef, i64 %t254, 0
  %t261 = insertvalue { i64, ptr } %t260, ptr %t255, 1
  store { i64, ptr } %t261, ptr %l13, !tbaa !27
  %t263 = load ptr, ptr %l0, !tbaa !29
  store ptr %t263, ptr %l129, !tbaa !29
  %t264 = load ptr, ptr %l1, !tbaa !29
  %t266 = getelementptr %"compiler/ast:Match", ptr %t264, i32 0, i32 0
  %t267 = getelementptr %"compiler/source:Span", ptr %t266, i32 0, i32 0
  %t268 = load i32, ptr %t267, !tbaa !23
  %t269 = load ptr, ptr %l1, !tbaa !29
  %t271 = getelementptr %"compiler/ast:Match", ptr %t269, i32 0, i32 0
  %t272 = getelementptr %"compiler/source:Span", ptr %t271, i32 0, i32 0
  %t273 = load i32, ptr %t272, !tbaa !23
  %t275 = add i32 %t273, 5
  %t278 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s6, i32 %t268, i32 %t275)
  store %"compiler/source:Span" %t278, ptr %l135
  br label %bb68
bb68:
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t280 = load i32, ptr %l2, !tbaa !23
  %t283 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s6, ptr %t279, i32 %t280)
  store { i64, ptr } %t283, ptr %l138
  br label %bb69
bb69:
  %t284 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t285 = extractvalue { i64, ptr } %t284, 0
  %t286 = extractvalue { i64, ptr } %t284, 1
  %t287 = mul i64 %t285, 1
  %t288 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t287)
  call void @llvm.memcpy.p0.p0.i64(ptr %t288, ptr %t286, i64 %t287, i1 false)
  %t289 = insertvalue { i64, ptr } undef, i64 %t285, 0
  %t290 = insertvalue { i64, ptr } %t289, ptr %t288, 1
  %t291 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t294 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMatchLengthUncovered(ptr %s6, ptr %s6, ptr %v0, { i64, ptr } %t290, { i64, ptr } %t291)
  store %"compiler/diagmsg:Msg" %t294, ptr %l141
  br label %bb70
bb70:
  %t295 = load ptr, ptr %l129, !tbaa !29
  %t296 = load %"compiler/source:Span", ptr %l135
  %t297 = load %"compiler/diagmsg:Msg", ptr %l141
  %t298 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t295, %"compiler/source:Span" %t296, %"compiler/diagmsg:Msg" %t297)
  store i64 %t298, ptr %l142
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s6)
  br label %ret
bb72:
  br label %bb73
bb73:
  %t299 = load i1, ptr %l5, !tbaa !21
  br i1 %t299, label %bb74, label %bb75
bb74:
  %t301 = load i32, ptr %l2, !tbaa !23
  %t302 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t305 = icmp ne i32 %t301, %t302
  store i1 %t305, ptr %l144, !tbaa !21
  br label %bb76
bb75:
  store i1 false, ptr %l144, !tbaa !21
  br label %bb76
bb76:
  %t307 = load i1, ptr %l144, !tbaa !21
  br i1 %t307, label %bb77, label %bb78
bb77:
  store %olang.scope zeroinitializer, ptr %s8
  %t308 = load ptr, ptr %l0, !tbaa !29
  store ptr %t308, ptr %l148, !tbaa !29
  %t309 = load ptr, ptr %l1, !tbaa !29
  %t311 = getelementptr %"compiler/ast:Match", ptr %t309, i32 0, i32 0
  %t312 = getelementptr %"compiler/source:Span", ptr %t311, i32 0, i32 0
  %t313 = load i32, ptr %t312, !tbaa !23
  %t314 = load ptr, ptr %l1, !tbaa !29
  %t316 = getelementptr %"compiler/ast:Match", ptr %t314, i32 0, i32 0
  %t317 = getelementptr %"compiler/source:Span", ptr %t316, i32 0, i32 0
  %t318 = load i32, ptr %t317, !tbaa !23
  %t320 = add i32 %t318, 5
  %t323 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s8, i32 %t313, i32 %t320)
  store %"compiler/source:Span" %t323, ptr %l154
  br label %bb79
bb78:
  br label %bb83
bb79:
  %t324 = load ptr, ptr %l0, !tbaa !29
  %t325 = load i32, ptr %l2, !tbaa !23
  %t328 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s8, ptr %t324, i32 %t325)
  store { i64, ptr } %t328, ptr %l157
  br label %bb80
bb80:
  %t329 = load { i64, ptr }, ptr %l157, !tbaa !27
  %t330 = extractvalue { i64, ptr } %t329, 0
  %t331 = extractvalue { i64, ptr } %t329, 1
  %t332 = mul i64 %t330, 1
  %t333 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t332)
  call void @llvm.memcpy.p0.p0.i64(ptr %t333, ptr %t331, i64 %t332, i1 false)
  %t334 = insertvalue { i64, ptr } undef, i64 %t330, 0
  %t335 = insertvalue { i64, ptr } %t334, ptr %t333, 1
  %t337 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMatchValueUncovered(ptr %s8, ptr %v0, { i64, ptr } %t335)
  store %"compiler/diagmsg:Msg" %t337, ptr %l159
  br label %bb81
bb81:
  %t338 = load ptr, ptr %l148, !tbaa !29
  %t339 = load %"compiler/source:Span", ptr %l154
  %t340 = load %"compiler/diagmsg:Msg", ptr %l159
  %t341 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t338, %"compiler/source:Span" %t339, %"compiler/diagmsg:Msg" %t340)
  store i64 %t341, ptr %l160
  br label %bb82
bb82:
  call void @__olang_scope_close(ptr %s8)
  br label %bb83
bb83:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eseqBase(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca ptr
  %l13 = alloca i32
  %l14 = alloca i32
  %l21 = alloca i64
  %l24 = alloca i64
  %l42 = alloca ptr
  %l43 = alloca ptr
  %l45 = alloca i32
  %l46 = alloca i1
  %l48 = alloca %"compiler/source:Span"
  %l51 = alloca ptr
  %l52 = alloca ptr
  %l54 = alloca i32
  %l55 = alloca i32
  %l58 = alloca ptr
  %l60 = alloca ptr
  %rv = alloca ptr
  %t108 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a2, ptr %l3, !tbaa !29
  %t3 = load ptr, ptr %l0, !tbaa !29
  store ptr %t3, ptr %l11, !tbaa !29
  %t4 = load ptr, ptr %l3, !tbaa !29
  %t6 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t4)
  store i32 %t6, ptr %l13
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l11, !tbaa !29
  %t8 = load i32, ptr %l13, !tbaa !23
  %t9 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t9, ptr %l14
  br label %bb2
bb2:
  %t10 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t11 = load i32, ptr %l14, !tbaa !23
  %t13 = icmp eq i32 %t11, %t10
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l3, !tbaa !29
  store ptr %t15, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  store i64 0, ptr %l4, !tbaa !24
  store i64 4, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t17 = load i64, ptr %l5, !tbaa !24
  %t18 = load i64, ptr %l4, !tbaa !24
  %t21 = icmp sgt i64 %t17, %t18
  br i1 %t21, label %bb6, label %bb7
bb6:
  %t23 = load i64, ptr %l6, !tbaa !24
  %t25 = icmp sgt i64 %t23, 0
  br i1 %t25, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb11
bb8:
  %t27 = load i64, ptr %l5, !tbaa !24
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = sub i64 %t27, %t28
  %t32 = load i64, ptr %l6, !tbaa !24
  %t35 = add i64 %t31, %t32
  %t37 = sub i64 %t35, 1
  %t38 = load i64, ptr %l6, !tbaa !24
  %t41 = sdiv i64 %t37, %t38
  store i64 %t41, ptr %l24, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb10
bb10:
  %t43 = load i64, ptr %l24, !tbaa !24
  store i64 %t43, ptr %l21, !tbaa !24
  br label %bb11
bb11:
  %t44 = load i64, ptr %l21, !tbaa !24
  store i64 %t44, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb12
bb12:
  %t45 = load i64, ptr %l8, !tbaa !24
  %t46 = load i64, ptr %l7, !tbaa !24
  %t49 = icmp slt i64 %t45, %t46
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb13, label %bb14
bb13:
  br label %bb25
bb14:
  br label %bb15
bb15:
  %t53 = load i64, ptr %l4, !tbaa !24
  %t54 = load i64, ptr %l8, !tbaa !24
  %t55 = load i64, ptr %l6, !tbaa !24
  %t58 = mul i64 %t54, %t55
  %t61 = add i64 %t53, %t58
  store i64 %t61, ptr %l9, !tbaa !24
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l42, !tbaa !29
  %t64 = load ptr, ptr %l3, !tbaa !29
  store ptr %t64, ptr %l43, !tbaa !29
  %t65 = load ptr, ptr %l43, !tbaa !29
  %t66 = call ptr @__olang_scope_of(ptr %t65, ptr null)
  %t67 = ptrtoint ptr %t66 to i64
  %t69 = inttoptr i64 %t67 to ptr
  %t70 = load ptr, ptr %l43, !tbaa !29
  %t71 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %t69, ptr %t70)
  store i32 %t71, ptr %l45
  br label %bb16
bb16:
  %t72 = load ptr, ptr %l42, !tbaa !29
  %t73 = load i32, ptr %l45, !tbaa !23
  %t74 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t72, i32 %t73)
  store i1 %t74, ptr %l46
  br label %bb17
bb17:
  %t75 = load i1, ptr %l46, !tbaa !21
  %t76 = xor i1 %t75, true
  br i1 %t76, label %bb18, label %bb19
bb18:
  br label %bb25
bb19:
  br label %bb20
bb20:
  %t78 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t78, ptr %l48
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/check:Checker", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = getelementptr %"compiler/generic:Program", ptr %t82, i32 0, i32 2
  store ptr %t84, ptr %l51, !tbaa !29
  %t85 = load ptr, ptr %l3, !tbaa !29
  store ptr %t85, ptr %l52, !tbaa !29
  %t86 = load ptr, ptr %l52, !tbaa !29
  %t87 = call ptr @__olang_scope_of(ptr %t86, ptr null)
  %t88 = ptrtoint ptr %t87 to i64
  %t90 = inttoptr i64 %t88 to ptr
  %t91 = load ptr, ptr %l52, !tbaa !29
  %t92 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %t90, ptr %t91)
  store i32 %t92, ptr %l54
  br label %bb21
bb21:
  %t93 = load ptr, ptr %l51, !tbaa !29
  %t94 = load i32, ptr %l54, !tbaa !23
  %t95 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t93, i32 %t94)
  store i32 %t95, ptr %l55
  br label %bb22
bb22:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load %"compiler/source:Span", ptr %l1
  %t98 = load ptr, ptr %l3, !tbaa !29
  store ptr %t98, ptr %l58, !tbaa !29
  %t99 = load ptr, ptr %l58, !tbaa !29
  %t100 = call ptr @__olang_scope_of(ptr %t99, ptr null)
  %t101 = ptrtoint ptr %t100 to i64
  %t103 = inttoptr i64 %t101 to ptr
  %t106 = load ptr, ptr %l58, !tbaa !29
  %t107 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t103, ptr %v2, ptr %t96, %"compiler/source:Span" %t97, ptr %t106)
  store ptr %t107, ptr %l60
  br label %bb23
bb23:
  store { i64, [4 x i64] } zeroinitializer, ptr %t108
  %t109 = getelementptr { i64, [4 x i64] }, ptr %t108, i32 0, i32 0
  store i64 2, ptr %t109
  %t110 = load %"compiler/source:Span", ptr %l48
  %t111 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t110, 0
  %t112 = load i32, ptr %l55, !tbaa !23
  %t113 = insertvalue { %"compiler/source:Span", i32, ptr } %t111, i32 %t112, 1
  %t114 = load ptr, ptr %l60, !tbaa !29
  %t115 = insertvalue { %"compiler/source:Span", i32, ptr } %t113, ptr %t114, 2
  %t116 = getelementptr { i64, [4 x i64] }, ptr %t108, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t115, ptr %t116
  %t117 = load { i64, [4 x i64] }, ptr %t108
  %t119 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t117, ptr %t119
  store ptr %t119, ptr %l3, !tbaa !29
  br label %bb24
bb24:
  %t121 = load i64, ptr %l8, !tbaa !24
  %t123 = add i64 %t121, 1
  store i64 %t123, ptr %l8, !tbaa !24
  br label %bb12
bb25:
  %t125 = load ptr, ptr %l3, !tbaa !29
  store ptr %t125, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetText(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca %"std/prelude/text:StringBuilder"
  %l18 = alloca i64
  %l22 = alloca i64
  %l25 = alloca i64
  %l46 = alloca ptr
  %l47 = alloca ptr
  %l50 = alloca i32
  %l51 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t1)
  store i64 %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = load i64, ptr %l10, !tbaa !24
  %t5 = icmp eq i64 %t4, 0
  br i1 %t5, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d42, i32 0, i32 1) }, ptr %l12, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t7, ptr %l13, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 0
  store i64 %t9, ptr %l14, !tbaa !24
  %t10 = load i64, ptr %l14, !tbaa !24
  %t11 = mul i64 %t10, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l15, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = load i64, ptr %l14, !tbaa !24
  %t20 = mul i64 %t19, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t16, ptr %t18, i64 %t20, i1 false)
  %t21 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t21, ptr %l13, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t22 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t22, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t23 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t23, ptr %l16
  br label %bb5
bb5:
  %t24 = load %"std/prelude/text:StringBuilder", ptr %l16
  store %"std/prelude/text:StringBuilder" %t24, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t25)
  store i64 %t27, ptr %l18
  br label %bb6
bb6:
  %t28 = load i64, ptr %l18, !tbaa !24
  store i64 %t28, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t29 = load i64, ptr %l4, !tbaa !24
  %t30 = load i64, ptr %l3, !tbaa !24
  %t33 = icmp sgt i64 %t29, %t30
  br i1 %t33, label %bb7, label %bb8
bb7:
  %t35 = load i64, ptr %l5, !tbaa !24
  %t37 = icmp sgt i64 %t35, 0
  br i1 %t37, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb12
bb9:
  %t39 = load i64, ptr %l4, !tbaa !24
  %t40 = load i64, ptr %l3, !tbaa !24
  %t43 = sub i64 %t39, %t40
  %t44 = load i64, ptr %l5, !tbaa !24
  %t47 = add i64 %t43, %t44
  %t49 = sub i64 %t47, 1
  %t50 = load i64, ptr %l5, !tbaa !24
  %t53 = sdiv i64 %t49, %t50
  store i64 %t53, ptr %l25, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb11
bb11:
  %t55 = load i64, ptr %l25, !tbaa !24
  store i64 %t55, ptr %l22, !tbaa !24
  br label %bb12
bb12:
  %t56 = load i64, ptr %l22, !tbaa !24
  store i64 %t56, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t57 = load i64, ptr %l7, !tbaa !24
  %t58 = load i64, ptr %l6, !tbaa !24
  %t61 = icmp slt i64 %t57, %t58
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb25
bb15:
  br label %bb16
bb16:
  %t65 = load i64, ptr %l3, !tbaa !24
  %t66 = load i64, ptr %l7, !tbaa !24
  %t67 = load i64, ptr %l5, !tbaa !24
  %t70 = mul i64 %t66, %t67
  %t73 = add i64 %t65, %t70
  store i64 %t73, ptr %l8, !tbaa !24
  %t75 = load i64, ptr %l8, !tbaa !24
  %t77 = icmp sgt i64 %t75, 0
  br i1 %t77, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s4
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %l2, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d43, i32 0, i32 1) })
  br label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_scope_close(ptr %s4)
  br label %bb20
bb20:
  store ptr %l2, ptr %l46, !tbaa !29
  store ptr %a0, ptr %l47, !tbaa !29
  %t81 = load ptr, ptr %l1, !tbaa !29
  %t82 = load i64, ptr %l8, !tbaa !24
  %t85 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t81, i64 %t82)
  store i32 %t85, ptr %l50
  br label %bb21
bb21:
  %t86 = load ptr, ptr %l47, !tbaa !29
  %t87 = load i32, ptr %l50, !tbaa !23
  %t88 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s3, ptr %t86, i32 %t87)
  store { i64, ptr } %t88, ptr %l51
  br label %bb22
bb22:
  %t89 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t89, 0
  %t91 = extractvalue { i64, ptr } %t89, 1
  %t92 = mul i64 %t90, 1
  %t93 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t92)
  call void @llvm.memcpy.p0.p0.i64(ptr %t93, ptr %t91, i64 %t92, i1 false)
  %t94 = insertvalue { i64, ptr } undef, i64 %t90, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t93, 1
  %t96 = load ptr, ptr %l46, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %t96, { i64, ptr } %t95)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s3)
  br label %bb24
bb24:
  %t98 = load i64, ptr %l7, !tbaa !24
  %t100 = add i64 %t98, 1
  store i64 %t100, ptr %l7, !tbaa !24
  br label %bb13
bb25:
  %t103 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l2)
  store { i64, ptr } %t103, ptr %l56
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s0)
  %t104 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t104, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estrBytes(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
  store { i64, ptr } %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t7 = call { i64, ptr } @compiler_2fscan_2eLiteralBytes(ptr %v0, ptr %v1, { i64, ptr } %t6)
  store { i64, ptr } %t7, ptr %l5
  br label %bb2
bb2:
  %t8 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 0
  %t10 = extractvalue { i64, ptr } %t8, 1
  %t11 = mul i64 %t9, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t10, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %a0, i32 %a1)
  store { i64, ptr } %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t7 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %t6)
  store { i64, ptr } %t7, ptr %l5
  br label %bb2
bb2:
  %t8 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t8, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeCaseHolds(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:typeCase" %a1, i32 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/check:typeCase"
  %l2 = alloca i32
  %l4 = alloca %"compiler/generic:Binding"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i32
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l28 = alloca %"compiler/generic:Binding"
  %l37 = alloca i64
  %l42 = alloca i64
  %l45 = alloca i64
  %l63 = alloca { i64, ptr }
  %l68 = alloca i1
  %l70 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l83 = alloca i32
  %l85 = alloca ptr
  %l86 = alloca i32
  %l87 = alloca i64
  %l92 = alloca i32
  %l93 = alloca i32
  %l99 = alloca i1
  %l107 = alloca i1
  %l110 = alloca ptr
  %l115 = alloca i32
  %l120 = alloca i64
  %l124 = alloca i32
  %l130 = alloca i1
  %l132 = alloca i1
  %l138 = alloca i1
  %l146 = alloca i32
  %l152 = alloca i64
  %l155 = alloca i64
  %l173 = alloca { i64, ptr }
  %l183 = alloca ptr
  %l185 = alloca ptr
  %l186 = alloca i32
  %l187 = alloca i64
  %l192 = alloca i32
  %l193 = alloca i32
  %l195 = alloca i1
  %l198 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l204 = alloca i64
  %l208 = alloca i64
  %l211 = alloca i64
  %l230 = alloca ptr
  %l233 = alloca i32
  %l234 = alloca { i64, ptr }
  %l237 = alloca %"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa"
  %s0 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/check:typeCase" %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 4
  %t2 = load i64, ptr %t1, !tbaa !24
  %t3 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 3
  %t4 = load i64, ptr %t3, !tbaa !24
  %t7 = call %"compiler/generic:Binding" @compiler_2fgeneric_3aBinding_2ector(ptr %s0, i64 %t2, i64 %t4)
  store %"compiler/generic:Binding" %t7, ptr %l28
  br label %bb1
bb1:
  %t8 = load %"compiler/generic:Binding", ptr %l28
  store %"compiler/generic:Binding" %t8, ptr %l4
  %t9 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 1
  %t10 = load i1, ptr %t9, !tbaa !21
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 3
  %t13 = load i64, ptr %t12, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  %t17 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 3
  %t18 = load i64, ptr %t17, !tbaa !24
  %t20 = icmp eq i64 %t18, 0
  br i1 %t20, label %bb38, label %bb39
bb4:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t26 = load i32, ptr %l2, !tbaa !23
  %t27 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 2
  %t28 = load i32, ptr %t27, !tbaa !23
  %t33 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnifyBound(ptr %v0, ptr %s0, ptr %t25, i32 %t26, i32 %t28, ptr %l4)
  store i64 %t33, ptr %l37
  br label %bb6
bb5:
  br label %bb28
bb6:
  store i64 0, ptr %l5, !tbaa !24
  %t34 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 3
  %t35 = load i64, ptr %t34, !tbaa !24
  store i64 %t35, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t37 = load i64, ptr %l6, !tbaa !24
  %t38 = load i64, ptr %l5, !tbaa !24
  %t41 = icmp sgt i64 %t37, %t38
  br i1 %t41, label %bb7, label %bb8
bb7:
  %t43 = load i64, ptr %l7, !tbaa !24
  %t45 = icmp sgt i64 %t43, 0
  br i1 %t45, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb12
bb9:
  %t47 = load i64, ptr %l6, !tbaa !24
  %t48 = load i64, ptr %l5, !tbaa !24
  %t51 = sub i64 %t47, %t48
  %t52 = load i64, ptr %l7, !tbaa !24
  %t55 = add i64 %t51, %t52
  %t57 = sub i64 %t55, 1
  %t58 = load i64, ptr %l7, !tbaa !24
  %t61 = sdiv i64 %t57, %t58
  store i64 %t61, ptr %l45, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l45, !tbaa !24
  br label %bb11
bb11:
  %t63 = load i64, ptr %l45, !tbaa !24
  store i64 %t63, ptr %l42, !tbaa !24
  br label %bb12
bb12:
  %t64 = load i64, ptr %l42, !tbaa !24
  store i64 %t64, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb13
bb13:
  %t65 = load i64, ptr %l9, !tbaa !24
  %t66 = load i64, ptr %l8, !tbaa !24
  %t69 = icmp slt i64 %t65, %t66
  %t71 = xor i1 %t69, true
  br i1 %t71, label %bb14, label %bb15
bb14:
  br label %bb27
bb15:
  br label %bb16
bb16:
  %t73 = load i64, ptr %l5, !tbaa !24
  %t74 = load i64, ptr %l9, !tbaa !24
  %t75 = load i64, ptr %l7, !tbaa !24
  %t78 = mul i64 %t74, %t75
  %t81 = add i64 %t73, %t78
  store i64 %t81, ptr %l10, !tbaa !24
  %t83 = getelementptr %"compiler/generic:Binding", ptr %l4, i32 0, i32 2
  %t84 = load { i64, ptr }, ptr %t83, !tbaa !27
  store { i64, ptr } %t84, ptr %l63, !tbaa !27
  %t85 = load i64, ptr %l10, !tbaa !24
  %t87 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = getelementptr i32, ptr %t88, i64 %t85
  %t90 = load i32, ptr %t89, !tbaa !33
  %t91 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t94 = icmp eq i32 %t90, %t91
  br i1 %t94, label %bb17, label %bb18
bb17:
  %t96 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 5
  %t97 = load i1, ptr %t96, !tbaa !21
  store i1 %t97, ptr %l68, !tbaa !21
  br label %bb19
bb18:
  store i1 false, ptr %l68, !tbaa !21
  br label %bb19
bb19:
  %t99 = load i1, ptr %l68, !tbaa !21
  br i1 %t99, label %bb20, label %bb21
bb20:
  %t100 = getelementptr %"compiler/generic:Binding", ptr %l4, i32 0, i32 2
  %t101 = load { i64, ptr }, ptr %t100, !tbaa !27
  store { i64, ptr } %t101, ptr %l70, !tbaa !27
  %t102 = load i64, ptr %l10, !tbaa !24
  %t103 = load i32, ptr %l2, !tbaa !23
  %t106 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = getelementptr i32, ptr %t107, i64 %t102
  store i32 %t103, ptr %t108, !tbaa !33
  br label %bb22
bb21:
  br label %bb22
bb22:
  %t109 = getelementptr %"compiler/generic:Binding", ptr %l4, i32 0, i32 2
  %t110 = load { i64, ptr }, ptr %t109, !tbaa !27
  store { i64, ptr } %t110, ptr %l73, !tbaa !27
  %t111 = load i64, ptr %l10, !tbaa !24
  %t113 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = getelementptr i32, ptr %t114, i64 %t111
  %t116 = load i32, ptr %t115, !tbaa !33
  %t117 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t120 = icmp eq i32 %t116, %t117
  br i1 %t120, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  br label %bb26
bb26:
  %t123 = load i64, ptr %l9, !tbaa !24
  %t125 = add i64 %t123, 1
  store i64 %t125, ptr %l9, !tbaa !24
  br label %bb13
bb27:
  br label %bb28
bb28:
  %t127 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 3
  %t128 = load i64, ptr %t127, !tbaa !24
  %t130 = icmp sgt i64 %t128, 0
  br i1 %t130, label %bb29, label %bb30
bb29:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/check:Checker", ptr %t132, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !29
  store ptr %t135, ptr %l85, !tbaa !29
  %t136 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 2
  %t137 = load i32, ptr %t136, !tbaa !23
  store i32 %t137, ptr %l86, !tbaa !23
  %t138 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 4
  %t139 = load i64, ptr %t138, !tbaa !24
  store i64 %t139, ptr %l87, !tbaa !24
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t142 = getelementptr %"compiler/check:Checker", ptr %t140, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !29
  %t145 = getelementptr %"compiler/generic:Program", ptr %t143, i32 0, i32 2
  %t146 = getelementptr %"compiler/generic:Binding", ptr %l4, i32 0, i32 2
  %t147 = load { i64, ptr }, ptr %t146, !tbaa !27
  %t150 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t145, { i64, ptr } %t147)
  store i32 %t150, ptr %l92
  br label %bb31
bb30:
  %t151 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 2
  %t152 = load i32, ptr %t151, !tbaa !23
  store i32 %t152, ptr %l83, !tbaa !23
  br label %bb33
bb31:
  %t154 = load ptr, ptr %l85, !tbaa !29
  %t155 = load i32, ptr %l86, !tbaa !23
  %t156 = load i64, ptr %l87, !tbaa !24
  %t157 = load i32, ptr %l92, !tbaa !23
  %t158 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSubst(ptr %v0, ptr %t154, i32 %t155, i64 %t156, i32 %t157)
  store i32 %t158, ptr %l93
  br label %bb32
bb32:
  %t159 = load i32, ptr %l93, !tbaa !23
  store i32 %t159, ptr %l83, !tbaa !23
  br label %bb33
bb33:
  %t160 = load i32, ptr %l83, !tbaa !23
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = getelementptr %"compiler/check:Checker", ptr %t161, i32 0, i32 1
  %t164 = load ptr, ptr %t163, !tbaa !29
  %t165 = load i32, ptr %l2, !tbaa !23
  %t170 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSatisfies(ptr %v0, ptr %t164, i32 %t165, i32 %t160)
  store i1 %t170, ptr %l99
  br label %bb34
bb34:
  %t171 = load i1, ptr %l99, !tbaa !21
  %t172 = xor i1 %t171, true
  br i1 %t172, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb36:
  br label %bb37
bb37:
  br label %bb81
bb38:
  %t175 = load i32, ptr %l2, !tbaa !23
  store i32 %t175, ptr %l12, !tbaa !23
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t178 = load i32, ptr %l2, !tbaa !23
  %t181 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t177, i32 %t178)
  store i1 %t181, ptr %l107
  br label %bb40
bb39:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr %"compiler/check:Checker", ptr %t182, i32 0, i32 1
  %t185 = load ptr, ptr %t184, !tbaa !29
  %t186 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 2
  %t187 = load i32, ptr %t186, !tbaa !23
  %t188 = load i32, ptr %l2, !tbaa !23
  %t193 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnify(ptr %v0, ptr %s0, ptr %t185, i32 %t187, i32 %t188, ptr %l4, i1 false, i1 false)
  store i32 %t193, ptr %l146
  %t194 = icmp ne i32 %t193, 0
  br i1 %t194, label %bb56, label %ok.195, !prof !99
ok.195:
  br label %bb55
bb40:
  %t196 = load i1, ptr %l107, !tbaa !21
  br i1 %t196, label %bb41, label %bb42
bb41:
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t199 = getelementptr %"compiler/check:Checker", ptr %t197, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !29
  %t202 = getelementptr %"compiler/generic:Program", ptr %t200, i32 0, i32 2
  store ptr %t202, ptr %l110, !tbaa !29
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t205 = getelementptr %"compiler/check:Checker", ptr %t203, i32 0, i32 1
  %t206 = load ptr, ptr %t205, !tbaa !29
  %t208 = getelementptr %"compiler/generic:Program", ptr %t206, i32 0, i32 2
  %t209 = load i32, ptr %l2, !tbaa !23
  %t212 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t208, i32 %t209)
  store i32 %t212, ptr %l115
  br label %bb43
bb42:
  br label %bb46
bb43:
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t215 = getelementptr %"compiler/check:Checker", ptr %t213, i32 0, i32 1
  %t216 = load ptr, ptr %t215, !tbaa !29
  %t218 = getelementptr %"compiler/generic:Program", ptr %t216, i32 0, i32 2
  %t219 = load i32, ptr %l2, !tbaa !23
  %t222 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t218, i32 %t219)
  store i64 %t222, ptr %l120
  br label %bb44
bb44:
  %t223 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t225 = xor i64 %t223, -1
  %t226 = load i64, ptr %l120, !tbaa !24
  %t228 = and i64 %t226, %t225
  %t229 = load ptr, ptr %l110, !tbaa !29
  %t230 = load i32, ptr %l115, !tbaa !23
  %t232 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t229, i32 %t230, i64 %t228)
  store i32 %t232, ptr %l124
  br label %bb45
bb45:
  %t233 = load i32, ptr %l124, !tbaa !23
  store i32 %t233, ptr %l12, !tbaa !23
  br label %bb46
bb46:
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t236 = getelementptr %"compiler/check:Checker", ptr %t234, i32 0, i32 1
  %t237 = load ptr, ptr %t236, !tbaa !29
  %t239 = getelementptr %"compiler/generic:Program", ptr %t237, i32 0, i32 2
  %t240 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 2
  %t241 = load i32, ptr %t240, !tbaa !23
  %t242 = load i32, ptr %l2, !tbaa !23
  %t246 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t239, i32 %t241, i32 %t242)
  store i1 %t246, ptr %l130
  br label %bb47
bb47:
  %t247 = load i1, ptr %l130, !tbaa !21
  %t248 = xor i1 %t247, true
  br i1 %t248, label %bb48, label %bb49
bb48:
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t252 = getelementptr %"compiler/check:Checker", ptr %t250, i32 0, i32 1
  %t253 = load ptr, ptr %t252, !tbaa !29
  %t255 = getelementptr %"compiler/generic:Program", ptr %t253, i32 0, i32 2
  %t256 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 2
  %t257 = load i32, ptr %t256, !tbaa !23
  %t258 = load i32, ptr %l12, !tbaa !23
  %t262 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t255, i32 %t257, i32 %t258)
  store i1 %t262, ptr %l138
  br label %bb50
bb49:
  store i1 false, ptr %l132, !tbaa !21
  br label %bb51
bb50:
  %t263 = load i1, ptr %l138, !tbaa !21
  %t264 = xor i1 %t263, true
  store i1 %t264, ptr %l132, !tbaa !21
  br label %bb51
bb51:
  %t266 = load i1, ptr %l132, !tbaa !21
  br i1 %t266, label %bb52, label %bb53
bb52:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb53:
  br label %bb54
bb54:
  br label %bb80
bb55:
  br label %bb58
bb56:
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb58:
  store i64 0, ptr %l13, !tbaa !24
  %t269 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 3
  %t270 = load i64, ptr %t269, !tbaa !24
  store i64 %t270, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t272 = load i64, ptr %l14, !tbaa !24
  %t273 = load i64, ptr %l13, !tbaa !24
  %t276 = icmp sgt i64 %t272, %t273
  br i1 %t276, label %bb59, label %bb60
bb59:
  %t278 = load i64, ptr %l15, !tbaa !24
  %t280 = icmp sgt i64 %t278, 0
  br i1 %t280, label %bb61, label %bb62
bb60:
  store i64 0, ptr %l152, !tbaa !24
  br label %bb64
bb61:
  %t282 = load i64, ptr %l14, !tbaa !24
  %t283 = load i64, ptr %l13, !tbaa !24
  %t286 = sub i64 %t282, %t283
  %t287 = load i64, ptr %l15, !tbaa !24
  %t290 = add i64 %t286, %t287
  %t292 = sub i64 %t290, 1
  %t293 = load i64, ptr %l15, !tbaa !24
  %t296 = sdiv i64 %t292, %t293
  store i64 %t296, ptr %l155, !tbaa !24
  br label %bb63
bb62:
  store i64 0, ptr %l155, !tbaa !24
  br label %bb63
bb63:
  %t298 = load i64, ptr %l155, !tbaa !24
  store i64 %t298, ptr %l152, !tbaa !24
  br label %bb64
bb64:
  %t299 = load i64, ptr %l152, !tbaa !24
  store i64 %t299, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb65
bb65:
  %t300 = load i64, ptr %l17, !tbaa !24
  %t301 = load i64, ptr %l16, !tbaa !24
  %t304 = icmp slt i64 %t300, %t301
  %t306 = xor i1 %t304, true
  br i1 %t306, label %bb66, label %bb67
bb66:
  br label %bb73
bb67:
  br label %bb68
bb68:
  %t308 = load i64, ptr %l13, !tbaa !24
  %t309 = load i64, ptr %l17, !tbaa !24
  %t310 = load i64, ptr %l15, !tbaa !24
  %t313 = mul i64 %t309, %t310
  %t316 = add i64 %t308, %t313
  %t318 = getelementptr %"compiler/generic:Binding", ptr %l4, i32 0, i32 2
  %t319 = load { i64, ptr }, ptr %t318, !tbaa !27
  store { i64, ptr } %t319, ptr %l173, !tbaa !27
  %t322 = getelementptr { i64, ptr }, ptr %l173, i32 0, i32 1
  %t323 = load ptr, ptr %t322, !tbaa !27
  %t324 = getelementptr i32, ptr %t323, i64 %t316
  %t325 = load i32, ptr %t324, !tbaa !33
  %t326 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t329 = icmp eq i32 %t325, %t326
  br i1 %t329, label %bb69, label %bb70
bb69:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb70:
  br label %bb71
bb71:
  br label %bb72
bb72:
  %t332 = load i64, ptr %l17, !tbaa !24
  %t334 = add i64 %t332, 1
  store i64 %t334, ptr %l17, !tbaa !24
  br label %bb65
bb73:
  %t336 = load ptr, ptr %l0, !tbaa !29
  %t338 = getelementptr %"compiler/check:Checker", ptr %t336, i32 0, i32 1
  %t339 = load ptr, ptr %t338, !tbaa !29
  %t341 = getelementptr %"compiler/generic:Program", ptr %t339, i32 0, i32 2
  store ptr %t341, ptr %l183, !tbaa !29
  %t342 = load ptr, ptr %l0, !tbaa !29
  %t344 = getelementptr %"compiler/check:Checker", ptr %t342, i32 0, i32 1
  %t345 = load ptr, ptr %t344, !tbaa !29
  store ptr %t345, ptr %l185, !tbaa !29
  %t346 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 2
  %t347 = load i32, ptr %t346, !tbaa !23
  store i32 %t347, ptr %l186, !tbaa !23
  %t348 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 4
  %t349 = load i64, ptr %t348, !tbaa !24
  store i64 %t349, ptr %l187, !tbaa !24
  %t350 = load ptr, ptr %l0, !tbaa !29
  %t352 = getelementptr %"compiler/check:Checker", ptr %t350, i32 0, i32 1
  %t353 = load ptr, ptr %t352, !tbaa !29
  %t355 = getelementptr %"compiler/generic:Program", ptr %t353, i32 0, i32 2
  %t356 = getelementptr %"compiler/generic:Binding", ptr %l4, i32 0, i32 2
  %t357 = load { i64, ptr }, ptr %t356, !tbaa !27
  %t360 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t355, { i64, ptr } %t357)
  store i32 %t360, ptr %l192
  br label %bb74
bb74:
  %t361 = load ptr, ptr %l185, !tbaa !29
  %t362 = load i32, ptr %l186, !tbaa !23
  %t363 = load i64, ptr %l187, !tbaa !24
  %t364 = load i32, ptr %l192, !tbaa !23
  %t365 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSubst(ptr %v0, ptr %t361, i32 %t362, i64 %t363, i32 %t364)
  store i32 %t365, ptr %l193
  br label %bb75
bb75:
  %t366 = load i32, ptr %l2, !tbaa !23
  %t367 = load ptr, ptr %l183, !tbaa !29
  %t368 = load i32, ptr %l193, !tbaa !23
  %t370 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t367, i32 %t368, i32 %t366)
  store i1 %t370, ptr %l195
  br label %bb76
bb76:
  %t371 = load i1, ptr %l195, !tbaa !21
  %t372 = xor i1 %t371, true
  br i1 %t372, label %bb77, label %bb78
bb77:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb78:
  br label %bb79
bb79:
  br label %bb80
bb80:
  br label %bb81
bb81:
  %t375 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t375, ptr %l198
  br label %bb82
bb82:
  %t376 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l198
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t376, ptr %l19
  %t377 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epatternNames(ptr %v0, ptr %v1, ptr %s0, ptr %t377, ptr %a3, ptr %l19, i1 false)
  br label %bb83
bb83:
  store i64 0, ptr %l20, !tbaa !24
  %t384 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %l19)
  store i64 %t384, ptr %l204
  br label %bb84
bb84:
  %t385 = load i64, ptr %l204, !tbaa !24
  store i64 %t385, ptr %l21, !tbaa !24
  store i64 1, ptr %l22, !tbaa !24
  %t386 = load i64, ptr %l21, !tbaa !24
  %t387 = load i64, ptr %l20, !tbaa !24
  %t390 = icmp sgt i64 %t386, %t387
  br i1 %t390, label %bb85, label %bb86
bb85:
  %t392 = load i64, ptr %l22, !tbaa !24
  %t394 = icmp sgt i64 %t392, 0
  br i1 %t394, label %bb87, label %bb88
bb86:
  store i64 0, ptr %l208, !tbaa !24
  br label %bb90
bb87:
  %t396 = load i64, ptr %l21, !tbaa !24
  %t397 = load i64, ptr %l20, !tbaa !24
  %t400 = sub i64 %t396, %t397
  %t401 = load i64, ptr %l22, !tbaa !24
  %t404 = add i64 %t400, %t401
  %t406 = sub i64 %t404, 1
  %t407 = load i64, ptr %l22, !tbaa !24
  %t410 = sdiv i64 %t406, %t407
  store i64 %t410, ptr %l211, !tbaa !24
  br label %bb89
bb88:
  store i64 0, ptr %l211, !tbaa !24
  br label %bb89
bb89:
  %t412 = load i64, ptr %l211, !tbaa !24
  store i64 %t412, ptr %l208, !tbaa !24
  br label %bb90
bb90:
  %t413 = load i64, ptr %l208, !tbaa !24
  store i64 %t413, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb91
bb91:
  store %olang.scope zeroinitializer, ptr %s21
  %t414 = load i64, ptr %l24, !tbaa !24
  %t415 = load i64, ptr %l23, !tbaa !24
  %t418 = icmp slt i64 %t414, %t415
  %t420 = xor i1 %t418, true
  br i1 %t420, label %bb92, label %bb93
bb92:
  call void @__olang_scope_close(ptr %s21)
  br label %bb99
bb93:
  br label %bb94
bb94:
  %t422 = load i64, ptr %l20, !tbaa !24
  %t423 = load i64, ptr %l24, !tbaa !24
  %t424 = load i64, ptr %l22, !tbaa !24
  %t427 = mul i64 %t423, %t424
  %t430 = add i64 %t422, %t427
  store i64 %t430, ptr %l25, !tbaa !24
  %t432 = load ptr, ptr %l0, !tbaa !29
  %t434 = getelementptr %"compiler/check:Checker", ptr %t432, i32 0, i32 172
  store ptr %t434, ptr %l230, !tbaa !29
  %t435 = load i64, ptr %l25, !tbaa !24
  %t438 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %l19, i64 %t435)
  store i32 %t438, ptr %l233
  br label %bb95
bb95:
  %t439 = getelementptr %"compiler/generic:Binding", ptr %l4, i32 0, i32 2
  %t440 = load { i64, ptr }, ptr %t439, !tbaa !27
  store { i64, ptr } %t440, ptr %l234, !tbaa !27
  %t441 = load i64, ptr %l25, !tbaa !24
  %t443 = getelementptr { i64, ptr }, ptr %l234, i32 0, i32 1
  %t444 = load ptr, ptr %t443, !tbaa !27
  %t445 = getelementptr i32, ptr %t444, i64 %t441
  %t446 = load i32, ptr %t445, !tbaa !33
  %t447 = load i32, ptr %l233, !tbaa !23
  %t449 = call %"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa" @std_2fpair_3aPair_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2ector(ptr %s21, i32 %t447, i32 %t446)
  store %"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa" %t449, ptr %l237
  br label %bb96
bb96:
  %t450 = load ptr, ptr %l230, !tbaa !29
  %t451 = load %"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa", ptr %l237
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__Habcf70cf374eb3bb03a96803ac10570d(ptr %v0, ptr %t450, %"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa" %t451)
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s21)
  br label %bb98
bb98:
  %t452 = load i64, ptr %l24, !tbaa !24
  %t454 = add i64 %t452, 1
  store i64 %t454, ptr %l24, !tbaa !24
  br label %bb91
bb99:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeWrittenAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca ptr
  %l9 = alloca { i64, [3 x i64] }
  %rv = alloca { i64, [3 x i64] }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t2)
  store ptr %t4, ptr %l4
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t5, i32 0, i32 1
  %t8 = load i64, ptr %t7, !tbaa !24
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t14 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emarkAt(ptr %v0, ptr %v1, ptr %t11, i64 %t8, ptr %a1)
  store { i64, [3 x i64] } %t14, ptr %l9
  br label %bb2
bb2:
  %t15 = load { i64, [3 x i64] }, ptr %l9
  store { i64, [3 x i64] } %t15, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [3 x i64] }, ptr %rv
  ret { i64, [3 x i64] } %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewholeNarrowed(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/check:narrowed"
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l10 = alloca i64
  %l15 = alloca ptr
  %l19 = alloca %"compiler/check:narrowed"
  %l21 = alloca ptr
  %l26 = alloca i32
  %l27 = alloca ptr
  %l29 = alloca ptr
  %l32 = alloca i1
  %l38 = alloca ptr
  %l42 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i64 %a1, ptr %l6, !tbaa !24
  %t3 = icmp sge i64 0, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = icmp sle i64 0, 2305843009213693951
  br i1 %t5, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_cd70ff81a8aaff09_d672b27f0a953c3d)
  unreachable
bb3:
  %t7 = mul i64 0, 4
  %t8 = insertvalue { i64, ptr } undef, i64 0, 0
  %t9 = insertvalue { i64, ptr } %t8, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t10 = load ptr, ptr %l5, !tbaa !29
  %t11 = load i64, ptr %l6, !tbaa !24
  %t13 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseNarrowing(ptr %v0, ptr %s0, ptr %t10, i64 %t11, { i64, ptr } %t9)
  store i64 %t13, ptr %l10
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_cd70ff81a8aaff09_d672b27f0a953c3d)
  unreachable
bb5:
  %t14 = load i64, ptr %l10, !tbaa !24
  store i64 %t14, ptr %l2, !tbaa !24
  %t15 = load i64, ptr %l2, !tbaa !24
  %t17 = icmp slt i64 %t15, 0
  br i1 %t17, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t20)
  store ptr %t22, ptr %l15
  br label %bb9
bb9:
  %t23 = load ptr, ptr %l15, !tbaa !29
  %t25 = getelementptr %"compiler/check:frame", ptr %t23, i32 0, i32 46
  %t26 = load i64, ptr %l2, !tbaa !24
  %t29 = call %"compiler/check:narrowed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eAt_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %v0, ptr %t25, i64 %t26)
  store %"compiler/check:narrowed" %t29, ptr %l19
  br label %bb10
bb10:
  %t30 = load %"compiler/check:narrowed", ptr %l19
  store %"compiler/check:narrowed" %t30, ptr %l3
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  store ptr %t34, ptr %l21, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/check:Checker", ptr %t35, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = getelementptr %"compiler/generic:Program", ptr %t38, i32 0, i32 2
  %t41 = getelementptr %"compiler/check:narrowed", ptr %l3, i32 0, i32 2
  %t42 = load i32, ptr %t41, !tbaa !23
  %t45 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t40, i32 %t42)
  store i32 %t45, ptr %l26
  br label %bb11
bb11:
  %t46 = load ptr, ptr %l21, !tbaa !29
  %t47 = load i32, ptr %l26, !tbaa !23
  %t48 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v0, ptr %t46, i32 %t47)
  store ptr %t48, ptr %l27
  br label %bb12
bb12:
  %t49 = getelementptr %"compiler/check:narrowed", ptr %l3, i32 0, i32 1
  %t50 = load i64, ptr %t49, !tbaa !24
  %t51 = load ptr, ptr %l27, !tbaa !29
  %t53 = call ptr @compiler_2fcheck_2ecaseDecl(ptr %v0, ptr %v0, ptr %t51, i64 %t50)
  store ptr %t53, ptr %l29
  br label %bb13
bb13:
  %t54 = load ptr, ptr %l29, !tbaa !29
  store ptr %t54, ptr %l4, !tbaa !29
  %t55 = load ptr, ptr %l4, !tbaa !29
  %t57 = icmp eq ptr %t55, null
  br i1 %t57, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb16
bb15:
  %t59 = load ptr, ptr %l4, !tbaa !29
  %t61 = getelementptr %"compiler/ast:CaseDecl", ptr %t59, i32 0, i32 3
  %t62 = load i1, ptr %t61, !tbaa !21
  %t64 = xor i1 %t62, true
  store i1 %t64, ptr %l32, !tbaa !21
  br label %bb16
bb16:
  %t66 = load i1, ptr %l32, !tbaa !21
  br i1 %t66, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t68)
  store ptr %t70, ptr %l38
  br label %bb20
bb20:
  %t71 = load ptr, ptr %l38, !tbaa !29
  %t73 = getelementptr %"compiler/check:frame", ptr %t71, i32 0, i32 47
  %t74 = getelementptr %"compiler/check:narrowed", ptr %l3, i32 0, i32 3
  %t75 = load i64, ptr %t74, !tbaa !24
  %t78 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t73, i64 %t75)
  store i64 %t78, ptr %l42
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s0)
  %t79 = load i64, ptr %l42, !tbaa !24
  store i64 %t79, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewrittenEnum(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i1
  %l13 = alloca i32
  %l19 = alloca i32
  %l25 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 28}
  %t8 = icmp eq i64 %t6, 12
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb15
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t20 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store i32 %t20, ptr %l13
  br label %bb6
bb6:
  %t21 = load i32, ptr %l13, !tbaa !23
  store i32 %t21, ptr %l3, !tbaa !23
  %t22 = load i32, ptr %l3, !tbaa !23
  %t24 = icmp sge i32 %t22, 0
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t26 = load i32, ptr %l3, !tbaa !23
  store i32 %t26, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t32 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenericNamed(ptr %v0, ptr %v1, ptr %t28, ptr %t29)
  store i32 %t32, ptr %l19
  br label %bb10
bb10:
  %t33 = load i32, ptr %l19, !tbaa !23
  store i32 %t33, ptr %l4, !tbaa !23
  %t34 = load i32, ptr %l4, !tbaa !23
  %t36 = icmp sge i32 %t34, 0
  br i1 %t36, label %bb11, label %bb12
bb11:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/check:Checker", ptr %t38, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t42 = load i32, ptr %l4, !tbaa !23
  %t45 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %t41, i32 %t42)
  store i32 %t45, ptr %l25
  br label %bb13
bb12:
  br label %bb14
bb13:
  %t46 = load i32, ptr %l25, !tbaa !23
  store i32 %t46, ptr %rv
  br label %ret
bb14:
  br label %bb20
bb15:
  br i1 true, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_dcc186c1d376e3fb_9ec0343880193f07)
  unreachable
bb20:
  store i32 -1, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewrongCase(ptr %v0, ptr %a0) #0 {
entry:
  %l2 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epreludeWord(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %a0, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d44, i32 0, i32 1) }, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d45, i32 0, i32 1) }, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d46, i32 0, i32 1) })
  store i32 %t3, ptr %l2
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t4 = load i32, ptr %l2, !tbaa !23
  store i32 %t4, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompoundOp(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i32
  %rv = alloca i32
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !range !{i32 0, i32 113}
  %t3 = trunc i64 80 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store i32 67, ptr %l1
  br label %bb49
bb4:
  %t7 = load i32, ptr %l0, !range !{i32 0, i32 113}
  %t9 = trunc i64 81 to i32
  %t10 = icmp eq i32 %t7, %t9
  br i1 %t10, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i32 68, ptr %l1
  br label %bb49
bb8:
  %t13 = load i32, ptr %l0, !range !{i32 0, i32 113}
  %t15 = trunc i64 82 to i32
  %t16 = icmp eq i32 %t13, %t15
  br i1 %t16, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i32 69, ptr %l1
  br label %bb49
bb12:
  %t19 = load i32, ptr %l0, !range !{i32 0, i32 113}
  %t21 = trunc i64 83 to i32
  %t22 = icmp eq i32 %t19, %t21
  br i1 %t22, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store i32 70, ptr %l1
  br label %bb49
bb16:
  %t25 = load i32, ptr %l0, !range !{i32 0, i32 113}
  %t27 = trunc i64 84 to i32
  %t28 = icmp eq i32 %t25, %t27
  br i1 %t28, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i32 71, ptr %l1
  br label %bb49
bb20:
  %t31 = load i32, ptr %l0, !range !{i32 0, i32 113}
  %t33 = trunc i64 85 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store i32 72, ptr %l1
  br label %bb49
bb24:
  %t37 = load i32, ptr %l0, !range !{i32 0, i32 113}
  %t39 = trunc i64 86 to i32
  %t40 = icmp eq i32 %t37, %t39
  br i1 %t40, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  store i32 105, ptr %l1
  br label %bb49
bb28:
  %t43 = load i32, ptr %l0, !range !{i32 0, i32 113}
  %t45 = trunc i64 87 to i32
  %t46 = icmp eq i32 %t43, %t45
  br i1 %t46, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store i32 106, ptr %l1
  br label %bb49
bb32:
  %t49 = load i32, ptr %l0, !range !{i32 0, i32 113}
  %t51 = trunc i64 88 to i32
  %t52 = icmp eq i32 %t49, %t51
  br i1 %t52, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  store i32 100, ptr %l1
  br label %bb49
bb36:
  %t55 = load i32, ptr %l0, !range !{i32 0, i32 113}
  %t57 = trunc i64 89 to i32
  %t58 = icmp eq i32 %t55, %t57
  br i1 %t58, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  store i32 101, ptr %l1
  br label %bb49
bb40:
  %t61 = load i32, ptr %l0, !range !{i32 0, i32 113}
  %t63 = trunc i64 90 to i32
  %t64 = icmp eq i32 %t61, %t63
  br i1 %t64, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  store i32 102, ptr %l1
  br label %bb49
bb44:
  br i1 true, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  store i32 0, ptr %l1
  br label %bb49
bb48:
  call void @__olang_check_failed(ptr @olang_loc_20f9f67d26588f89_c77aed4cf9eaedd5)
  unreachable
bb49:
  %t68 = load i32, ptr %l1, !range !{i32 0, i32 113}
  store i32 %t68, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2eextended(ptr %v0, ptr %v1, { i64, ptr } %a0, i32 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %lp2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i32
  %l25 = alloca i64
  %l28 = alloca i64
  %l47 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  %t25 = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t7, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  %t13 = add i64 %t11, 1
  store i64 %t13, ptr %l15, !tbaa !24
  store i32 %a1, ptr %l16, !tbaa !23
  %t15 = load i64, ptr %l15, !tbaa !24
  %t16 = icmp sge i64 %t15, 0
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t18 = load i64, ptr %l15, !tbaa !24
  %t19 = icmp sle i64 %t18, 2305843009213693951
  br i1 %t19, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_c65b3104d639b10f_156ca11db7f6d433)
  unreachable
bb6:
  %t21 = load i64, ptr %l15, !tbaa !24
  %t22 = mul i64 %t21, 4
  %t23 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t22)
  %t24 = load i32, ptr %l16, !tbaa !23
  store i64 0, ptr %t25
  br label %fill.26
fill.26:
  %t29 = load i64, ptr %t25
  %t30 = icmp slt i64 %t29, %t21
  br i1 %t30, label %fillb.27, label %filld.28
fillb.27:
  %t31 = getelementptr i32, ptr %t23, i64 %t29
  store i32 %t24, ptr %t31
  %t32 = add i64 %t29, 1
  store i64 %t32, ptr %t25
  br label %fill.26
filld.28:
  %t33 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t23, 1
  %t35 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t35, ptr %lp2
  %t37 = load ptr, ptr %lp2
  store { i64, ptr } %t34, ptr %t37, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t38 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t38, 0
  store i64 %t40, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t42 = load i64, ptr %l4, !tbaa !24
  %t43 = load i64, ptr %l3, !tbaa !24
  %t46 = icmp sgt i64 %t42, %t43
  br i1 %t46, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_c65b3104d639b10f_156ca11db7f6d433)
  unreachable
bb8:
  %t48 = load i64, ptr %l5, !tbaa !24
  %t50 = icmp sgt i64 %t48, 0
  br i1 %t50, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb13
bb10:
  %t52 = load i64, ptr %l4, !tbaa !24
  %t53 = load i64, ptr %l3, !tbaa !24
  %t56 = sub i64 %t52, %t53
  %t57 = load i64, ptr %l5, !tbaa !24
  %t60 = add i64 %t56, %t57
  %t62 = sub i64 %t60, 1
  %t63 = load i64, ptr %l5, !tbaa !24
  %t66 = sdiv i64 %t62, %t63
  store i64 %t66, ptr %l28, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb12
bb12:
  %t68 = load i64, ptr %l28, !tbaa !24
  store i64 %t68, ptr %l25, !tbaa !24
  br label %bb13
bb13:
  %t69 = load i64, ptr %l25, !tbaa !24
  store i64 %t69, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb14
bb14:
  %t70 = load i64, ptr %l7, !tbaa !24
  %t71 = load i64, ptr %l6, !tbaa !24
  %t74 = icmp slt i64 %t70, %t71
  %t76 = xor i1 %t74, true
  br i1 %t76, label %bb15, label %bb16
bb15:
  br label %bb19
bb16:
  br label %bb17
bb17:
  %t78 = load i64, ptr %l3, !tbaa !24
  %t79 = load i64, ptr %l7, !tbaa !24
  %t80 = load i64, ptr %l5, !tbaa !24
  %t83 = mul i64 %t79, %t80
  %t86 = add i64 %t78, %t83
  store i64 %t86, ptr %l8, !tbaa !24
  %t88 = load i64, ptr %l8, !tbaa !24
  %t89 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t89, ptr %l47, !tbaa !27
  %t90 = load i64, ptr %l8, !tbaa !24
  %t92 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = getelementptr i32, ptr %t93, i64 %t90
  %t95 = load i32, ptr %t94, !tbaa !33
  %t97 = load ptr, ptr %lp2
  %t99 = getelementptr { i64, ptr }, ptr %t97, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !27
  %t101 = getelementptr i32, ptr %t100, i64 %t88
  store i32 %t95, ptr %t101, !tbaa !33
  br label %bb18
bb18:
  %t102 = load i64, ptr %l7, !tbaa !24
  %t104 = add i64 %t102, 1
  store i64 %t104, ptr %l7, !tbaa !24
  br label %bb14
bb19:
  %t106 = load ptr, ptr %lp2
  %t107 = load { i64, ptr }, ptr %t106, !tbaa !27
  store { i64, ptr } %t107, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ejoinBytes(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %lp2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l19 = alloca i64
  %l27 = alloca i64
  %l30 = alloca i64
  %l49 = alloca { i64, ptr }
  %l59 = alloca i64
  %l62 = alloca i64
  %l84 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t4 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t9 = add i64 %t3, %t6
  store i64 %t9, ptr %l19, !tbaa !24
  %t10 = load i64, ptr %l19, !tbaa !24
  %t11 = icmp sge i64 %t10, 0
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load i64, ptr %l19, !tbaa !24
  %t14 = mul i64 %t13, 1
  %t15 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t14)
  %t16 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  %t18 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t18, ptr %lp2
  %t20 = load ptr, ptr %lp2
  store { i64, ptr } %t17, ptr %t20, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t21 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t25 = load i64, ptr %l4, !tbaa !24
  %t26 = load i64, ptr %l3, !tbaa !24
  %t29 = icmp sgt i64 %t25, %t26
  br i1 %t29, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_489f62f877911e0f_f9fedbe42e1f3c23)
  unreachable
bb3:
  %t31 = load i64, ptr %l5, !tbaa !24
  %t33 = icmp sgt i64 %t31, 0
  br i1 %t33, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb8
bb5:
  %t35 = load i64, ptr %l4, !tbaa !24
  %t36 = load i64, ptr %l3, !tbaa !24
  %t39 = sub i64 %t35, %t36
  %t40 = load i64, ptr %l5, !tbaa !24
  %t43 = add i64 %t39, %t40
  %t45 = sub i64 %t43, 1
  %t46 = load i64, ptr %l5, !tbaa !24
  %t49 = sdiv i64 %t45, %t46
  store i64 %t49, ptr %l30, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb7
bb7:
  %t51 = load i64, ptr %l30, !tbaa !24
  store i64 %t51, ptr %l27, !tbaa !24
  br label %bb8
bb8:
  %t52 = load i64, ptr %l27, !tbaa !24
  store i64 %t52, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb9
bb9:
  %t53 = load i64, ptr %l7, !tbaa !24
  %t54 = load i64, ptr %l6, !tbaa !24
  %t57 = icmp slt i64 %t53, %t54
  %t59 = xor i1 %t57, true
  br i1 %t59, label %bb10, label %bb11
bb10:
  br label %bb14
bb11:
  br label %bb12
bb12:
  %t61 = load i64, ptr %l3, !tbaa !24
  %t62 = load i64, ptr %l7, !tbaa !24
  %t63 = load i64, ptr %l5, !tbaa !24
  %t66 = mul i64 %t62, %t63
  %t69 = add i64 %t61, %t66
  store i64 %t69, ptr %l8, !tbaa !24
  %t71 = load i64, ptr %l8, !tbaa !24
  %t72 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t72, ptr %l49, !tbaa !27
  %t73 = load i64, ptr %l8, !tbaa !24
  %t75 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr i8, ptr %t76, i64 %t73
  %t78 = load i8, ptr %t77, !tbaa !32
  %t80 = load ptr, ptr %lp2
  %t82 = getelementptr { i64, ptr }, ptr %t80, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr i8, ptr %t83, i64 %t71
  store i8 %t78, ptr %t84, !tbaa !32
  br label %bb13
bb13:
  %t85 = load i64, ptr %l7, !tbaa !24
  %t87 = add i64 %t85, 1
  store i64 %t87, ptr %l7, !tbaa !24
  br label %bb9
bb14:
  store i64 0, ptr %l9, !tbaa !24
  %t89 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t89, 0
  store i64 %t91, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t93 = load i64, ptr %l10, !tbaa !24
  %t94 = load i64, ptr %l9, !tbaa !24
  %t97 = icmp sgt i64 %t93, %t94
  br i1 %t97, label %bb15, label %bb16
bb15:
  %t99 = load i64, ptr %l11, !tbaa !24
  %t101 = icmp sgt i64 %t99, 0
  br i1 %t101, label %bb17, label %bb18
bb16:
  store i64 0, ptr %l59, !tbaa !24
  br label %bb20
bb17:
  %t103 = load i64, ptr %l10, !tbaa !24
  %t104 = load i64, ptr %l9, !tbaa !24
  %t107 = sub i64 %t103, %t104
  %t108 = load i64, ptr %l11, !tbaa !24
  %t111 = add i64 %t107, %t108
  %t113 = sub i64 %t111, 1
  %t114 = load i64, ptr %l11, !tbaa !24
  %t117 = sdiv i64 %t113, %t114
  store i64 %t117, ptr %l62, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l62, !tbaa !24
  br label %bb19
bb19:
  %t119 = load i64, ptr %l62, !tbaa !24
  store i64 %t119, ptr %l59, !tbaa !24
  br label %bb20
bb20:
  %t120 = load i64, ptr %l59, !tbaa !24
  store i64 %t120, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb21
bb21:
  %t121 = load i64, ptr %l13, !tbaa !24
  %t122 = load i64, ptr %l12, !tbaa !24
  %t125 = icmp slt i64 %t121, %t122
  %t127 = xor i1 %t125, true
  br i1 %t127, label %bb22, label %bb23
bb22:
  br label %bb26
bb23:
  br label %bb24
bb24:
  %t129 = load i64, ptr %l9, !tbaa !24
  %t130 = load i64, ptr %l13, !tbaa !24
  %t131 = load i64, ptr %l11, !tbaa !24
  %t134 = mul i64 %t130, %t131
  %t137 = add i64 %t129, %t134
  store i64 %t137, ptr %l14, !tbaa !24
  %t139 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t141 = extractvalue { i64, ptr } %t139, 0
  %t142 = load i64, ptr %l14, !tbaa !24
  %t145 = add i64 %t141, %t142
  %t146 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t146, ptr %l84, !tbaa !27
  %t147 = load i64, ptr %l14, !tbaa !24
  %t149 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !27
  %t151 = getelementptr i8, ptr %t150, i64 %t147
  %t152 = load i8, ptr %t151, !tbaa !32
  %t154 = load ptr, ptr %lp2
  %t156 = getelementptr { i64, ptr }, ptr %t154, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !27
  %t158 = getelementptr i8, ptr %t157, i64 %t145
  store i8 %t152, ptr %t158, !tbaa !32
  br label %bb25
bb25:
  %t159 = load i64, ptr %l13, !tbaa !24
  %t161 = add i64 %t159, 1
  store i64 %t161, ptr %l13, !tbaa !24
  br label %bb21
bb26:
  %t163 = load ptr, ptr %lp2
  %t164 = load { i64, ptr }, ptr %t163, !tbaa !27
  store { i64, ptr } %t164, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fcheck_2elaneMethodName(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i1
  %l4 = alloca i1
  %l6 = alloca i1
  %l8 = alloca i1
  %l10 = alloca i1
  %l12 = alloca i1
  %l16 = alloca i1
  %l18 = alloca i1
  %l22 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d47, i32 0, i32 1) })
  store i1 %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load i1, ptr %l4, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  br label %bb16
bb3:
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t5, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d48, i32 0, i32 1) })
  store i1 %t7, ptr %l6
  br label %bb4
bb4:
  %t8 = load i1, ptr %l6, !tbaa !21
  br i1 %t8, label %bb5, label %bb6
bb5:
  br label %bb16
bb6:
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t11 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t9, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d49, i32 0, i32 1) })
  store i1 %t11, ptr %l8
  br label %bb7
bb7:
  %t12 = load i1, ptr %l8, !tbaa !21
  br i1 %t12, label %bb8, label %bb9
bb8:
  br label %bb16
bb9:
  %t13 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t15 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t13, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d50, i32 0, i32 1) })
  store i1 %t15, ptr %l10
  br label %bb10
bb10:
  %t16 = load i1, ptr %l10, !tbaa !21
  br i1 %t16, label %bb11, label %bb12
bb11:
  br label %bb16
bb12:
  %t17 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t19 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t17, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d51, i32 0, i32 1) })
  store i1 %t19, ptr %l12
  br label %bb13
bb13:
  %t20 = load i1, ptr %l12, !tbaa !21
  br i1 %t20, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  %t21 = load i64, ptr %l1, !tbaa !24
  %t23 = icmp eq i64 %t21, 0
  store i1 %t23, ptr %l2, !tbaa !21
  br label %bb35
bb17:
  %t25 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t27 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t25, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d52, i32 0, i32 1) })
  store i1 %t27, ptr %l16
  br label %bb18
bb18:
  %t28 = load i1, ptr %l16, !tbaa !21
  br i1 %t28, label %bb19, label %bb20
bb19:
  br label %bb24
bb20:
  %t29 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t31 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t29, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d53, i32 0, i32 1) })
  store i1 %t31, ptr %l18
  br label %bb21
bb21:
  %t32 = load i1, ptr %l18, !tbaa !21
  br i1 %t32, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  %t33 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp eq i64 %t33, 1
  store i1 %t35, ptr %l2, !tbaa !21
  br label %bb35
bb25:
  %t37 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t39 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t37, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d54, i32 0, i32 1) })
  store i1 %t39, ptr %l22
  br label %bb26
bb26:
  %t40 = load i1, ptr %l22, !tbaa !21
  br i1 %t40, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  %t41 = load i64, ptr %l1, !tbaa !24
  %t43 = icmp eq i64 %t41, 2
  store i1 %t43, ptr %l2, !tbaa !21
  br label %bb35
bb30:
  br i1 true, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_679df2ab066560af_73bde1caf560602b)
  unreachable
bb35:
  call void @__olang_scope_close(ptr %s0)
  %t45 = load i1, ptr %l2, !tbaa !21
  store i1 %t45, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/check:litv" @compiler_2fcheck_2elitv_2efloatLit(double %a0) #0 {
entry:
  %l2 = alloca %"compiler/check:litv"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/check:litv"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call %"compiler/check:litv" @compiler_2fcheck_3alitv_2ector(ptr %s0, i1 true, i1 true, i1 false, i64 0, double %a0)
  store %"compiler/check:litv" %t3, ptr %l2
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t4 = load %"compiler/check:litv", ptr %l2
  store %"compiler/check:litv" %t4, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:litv", ptr %rv
  ret %"compiler/check:litv" %rr
}

define dso_local %"compiler/check:litv" @compiler_2fcheck_2elitv_2eofMag(i1 %a0, i128 %a1) #0 {
entry:
  %l1 = alloca i128
  %l2 = alloca i128
  %l5 = alloca %"compiler/check:litv"
  %l14 = alloca %"compiler/check:litv"
  %l20 = alloca %"compiler/check:litv"
  %l22 = alloca %"compiler/check:litv"
  %l30 = alloca %"compiler/check:litv"
  %l35 = alloca %"compiler/check:litv"
  %l36 = alloca %"compiler/check:litv"
  %s4 = alloca %olang.scope
  %rv = alloca %"compiler/check:litv"
  store i128 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i128, ptr %l1
  %t3 = icmp eq i128 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2eintLit(i64 0)
  store %"compiler/check:litv" %t5, ptr %l5
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t6 = load %"compiler/check:litv", ptr %l5
  store %"compiler/check:litv" %t6, ptr %rv
  br label %ret
bb4:
  %t7 = shl i128 1, 63
  store i128 %t7, ptr %l2
  %t11 = xor i1 %a0, true
  br i1 %t11, label %bb5, label %bb6
bb5:
  %t13 = load i128, ptr %l1
  %t14 = load i128, ptr %l2
  %t17 = icmp ult i128 %t13, %t14
  br i1 %t17, label %bb7, label %bb8
bb6:
  br label %bb16
bb7:
  %t19 = load i128, ptr %l1
  %t21 = trunc i128 %t19 to i64
  %t23 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2eintLit(i64 %t21)
  store %"compiler/check:litv" %t23, ptr %l14
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t24 = load %"compiler/check:litv", ptr %l14
  store %"compiler/check:litv" %t24, ptr %rv
  br label %ret
bb10:
  %t25 = load i128, ptr %l1
  %t26 = shl i128 1, 64
  %t29 = icmp ult i128 %t25, %t26
  br i1 %t29, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s4
  %t31 = load i128, ptr %l1
  %t33 = trunc i128 %t31 to i64
  %t35 = call %"compiler/check:litv" @compiler_2fcheck_3alitv_2ector(ptr %s4, i1 true, i1 false, i1 true, i64 %t33, double 0x0000000000000000)
  store %"compiler/check:litv" %t35, ptr %l20
  br label %bb13
bb12:
  br label %bb14
bb13:
  call void @__olang_scope_close(ptr %s4)
  %t36 = load %"compiler/check:litv", ptr %l20
  store %"compiler/check:litv" %t36, ptr %rv
  br label %ret
bb14:
  %t37 = load i128, ptr %l1
  %t39 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2ewideLit(i1 false, i128 %t37)
  store %"compiler/check:litv" %t39, ptr %l22
  br label %bb15
bb15:
  %t40 = load %"compiler/check:litv", ptr %l22
  store %"compiler/check:litv" %t40, ptr %rv
  br label %ret
bb16:
  %t41 = load i128, ptr %l1
  %t42 = load i128, ptr %l2
  %t45 = icmp ule i128 %t41, %t42
  br i1 %t45, label %bb17, label %bb18
bb17:
  %t47 = load i128, ptr %l1
  %t49 = trunc i128 %t47 to i64
  %t51 = sub i64 0, %t49
  %t54 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2eintLit(i64 %t51)
  store %"compiler/check:litv" %t54, ptr %l30
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t55 = load %"compiler/check:litv", ptr %l30
  store %"compiler/check:litv" %t55, ptr %rv
  br label %ret
bb20:
  %t56 = load i128, ptr %l1
  %t57 = shl i128 1, 127
  %t60 = icmp ule i128 %t56, %t57
  br i1 %t60, label %bb21, label %bb22
bb21:
  %t62 = load i128, ptr %l1
  %t64 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2ewideLit(i1 true, i128 %t62)
  store %"compiler/check:litv" %t64, ptr %l35
  br label %bb23
bb22:
  br label %bb24
bb23:
  %t65 = load %"compiler/check:litv", ptr %l35
  store %"compiler/check:litv" %t65, ptr %rv
  br label %ret
bb24:
  %t66 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2enoLit()
  store %"compiler/check:litv" %t66, ptr %l36
  br label %bb25
bb25:
  %t67 = load %"compiler/check:litv", ptr %l36
  store %"compiler/check:litv" %t67, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:litv", ptr %rv
  ret %"compiler/check:litv" %rr
}

define dso_local i1 @compiler_2fcheck_2ematchExisting(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l21 = alloca i1
  %l27 = alloca i1
  %l35 = alloca i1
  %l45 = alloca i1
  %l56 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Match", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l2, !tbaa !24
  %t11 = load i64, ptr %l3, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb16
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t18, ptr %l14, !tbaa !27
  %t19 = load i64, ptr %l2, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  store ptr %t24, ptr %l4, !tbaa !29
  %t26 = load ptr, ptr %l4, !tbaa !29
  %t28 = getelementptr %"compiler/typed:Arm", ptr %t26, i32 0, i32 4
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = icmp eq ptr %t29, null
  %t33 = xor i1 %t31, true
  br i1 %t33, label %bb5, label %bb6
bb5:
  %t35 = load ptr, ptr %l4, !tbaa !29
  %t37 = getelementptr %"compiler/typed:Arm", ptr %t35, i32 0, i32 4
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = icmp eq ptr %t38, null
  br i1 %t40, label %bb7, label %bb8
bb6:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb11
bb7:
  call void @__olang_check_failed(ptr @olang_loc_3bef89c29375057e_93446d82378ce1ba)
  unreachable
bb8:
  br label %bb9
bb9:
  %t42 = load ptr, ptr %l4, !tbaa !29
  %t44 = getelementptr %"compiler/typed:Arm", ptr %t42, i32 0, i32 4
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t47 = call i1 @compiler_2fcheck_2eexistingValue(ptr %v0, ptr %t45)
  store i1 %t47, ptr %l27
  br label %bb10
bb10:
  %t48 = load i1, ptr %l27, !tbaa !21
  store i1 %t48, ptr %l21, !tbaa !21
  br label %bb11
bb11:
  %t49 = load i1, ptr %l21, !tbaa !21
  br i1 %t49, label %bb12, label %bb13
bb12:
  store i1 true, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t51 = load i64, ptr %l2, !tbaa !24
  %t53 = add i64 %t51, 1
  store i64 %t53, ptr %l2, !tbaa !24
  br label %bb1
bb16:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/typed:Match", ptr %t55, i32 0, i32 2
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t60 = icmp eq ptr %t58, null
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb17, label %bb18
bb17:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/typed:Match", ptr %t64, i32 0, i32 2
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = icmp eq ptr %t67, null
  br i1 %t69, label %bb19, label %bb20
bb18:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb22
bb19:
  call void @__olang_check_failed(ptr @olang_loc_f9ce4d996cc4e225_93403f8f2ddbd541)
  unreachable
bb20:
  br label %bb21
bb21:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/typed:Match", ptr %t71, i32 0, i32 2
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t77 = getelementptr %"compiler/typed:Arm", ptr %t74, i32 0, i32 4
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t80 = icmp eq ptr %t78, null
  %t82 = xor i1 %t80, true
  store i1 %t82, ptr %l35, !tbaa !21
  br label %bb22
bb22:
  %t84 = load i1, ptr %l35, !tbaa !21
  br i1 %t84, label %bb23, label %bb24
bb23:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/typed:Match", ptr %t85, i32 0, i32 2
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t90 = icmp eq ptr %t88, null
  br i1 %t90, label %bb25, label %bb26
bb24:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb32
bb25:
  call void @__olang_check_failed(ptr @olang_loc_f9ce4d996cc4e225_93403f8f2ddbd541)
  unreachable
bb26:
  br label %bb27
bb27:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/typed:Match", ptr %t92, i32 0, i32 2
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t98 = getelementptr %"compiler/typed:Arm", ptr %t95, i32 0, i32 4
  %t99 = load ptr, ptr %t98, !tbaa !29
  store ptr %t99, ptr %l5, !tbaa !29
  %t101 = load ptr, ptr %l5, !tbaa !29
  %t103 = icmp eq ptr %t101, null
  br i1 %t103, label %bb28, label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_f9ce4d996cc4e225_93403f8f2ddbd541)
  unreachable
bb29:
  br label %bb30
bb30:
  %t105 = load ptr, ptr %l5, !tbaa !29
  %t107 = call i1 @compiler_2fcheck_2eexistingValue(ptr %v0, ptr %t105)
  store i1 %t107, ptr %l56
  br label %bb31
bb31:
  %t108 = load i1, ptr %l56, !tbaa !21
  store i1 %t108, ptr %l45, !tbaa !21
  br label %bb32
bb32:
  %t109 = load i1, ptr %l45, !tbaa !21
  store i1 %t109, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2epastAway(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  %l10 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 17
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = call ptr @compiler_2fcheck_2epastAway(ptr %v0, ptr %v0, ptr %t16)
  store ptr %t18, ptr %l10
  br label %bb6
bb6:
  %t19 = load ptr, ptr %l10, !tbaa !29
  store ptr %t19, ptr %l2, !tbaa !29
  br label %bb12
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l2, !tbaa !29
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_55e43ab8a3145b19_623cb1abd394c54d)
  unreachable
bb12:
  %t22 = load ptr, ptr %l2, !tbaa !29
  store ptr %t22, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2estmtAssigns(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l28 = alloca ptr
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca i1
  %l42 = alloca ptr
  %l43 = alloca i1
  %l51 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca i1
  %l61 = alloca i1
  %l62 = alloca ptr
  %l63 = alloca i1
  %l72 = alloca i1
  %l73 = alloca i1
  %l77 = alloca i1
  %l78 = alloca i1
  %l82 = alloca i1
  %l83 = alloca ptr
  %l84 = alloca i1
  %l97 = alloca { i64, ptr }
  %l102 = alloca i1
  %l103 = alloca i1
  %l107 = alloca i1
  %l114 = alloca i1
  %l115 = alloca ptr
  %l116 = alloca i1
  %l126 = alloca i1
  %l127 = alloca i1
  %l130 = alloca i1
  %l131 = alloca ptr
  %l132 = alloca i1
  %l139 = alloca i1
  %l140 = alloca ptr
  %l141 = alloca i1
  %l146 = alloca ptr
  %l147 = alloca i1
  %l154 = alloca i1
  %l155 = alloca ptr
  %l156 = alloca i1
  %l163 = alloca ptr
  %l164 = alloca i1
  %l174 = alloca i1
  %l175 = alloca i1
  %l178 = alloca i1
  %l179 = alloca ptr
  %l180 = alloca i1
  %l189 = alloca i1
  %l190 = alloca i1
  %l194 = alloca i1
  %l195 = alloca i1
  %l200 = alloca i1
  %l201 = alloca i1
  %l205 = alloca i1
  %l206 = alloca ptr
  %l207 = alloca i1
  %l216 = alloca i1
  %l217 = alloca i1
  %l221 = alloca i1
  %l222 = alloca i1
  %l226 = alloca i1
  %l227 = alloca ptr
  %l228 = alloca i1
  %l235 = alloca i1
  %l236 = alloca ptr
  %l237 = alloca i1
  %l244 = alloca i1
  %l245 = alloca ptr
  %l246 = alloca i1
  %l254 = alloca i1
  %l255 = alloca ptr
  %l256 = alloca i1
  %l263 = alloca i1
  %l264 = alloca ptr
  %l265 = alloca i1
  %l275 = alloca i1
  %l276 = alloca i1
  %l279 = alloca i1
  %l280 = alloca ptr
  %l281 = alloca i1
  %l285 = alloca ptr
  %l286 = alloca i1
  %l294 = alloca i1
  %l295 = alloca i1
  %l299 = alloca i1
  %l300 = alloca ptr
  %l301 = alloca i1
  %l309 = alloca i1
  %l310 = alloca ptr
  %l311 = alloca i1
  %l325 = alloca { i64, ptr }
  %l330 = alloca i1
  %l331 = alloca i1
  %l335 = alloca i1
  %l342 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t7 = load ptr, ptr %l36, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l36, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 22}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l37, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l37, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr { i64, [4 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", ptr }, ptr %t17, i32 0, i32 1
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l2, !tbaa !29
  br label %bb12
bb7:
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t22 = load ptr, ptr %l42, !tbaa !29
  %t23 = icmp ne ptr %t22, null
  br i1 %t23, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l42, !tbaa !29
  %t26 = load i64, ptr %t25, !range !{i64 0, i64 22}
  %t28 = icmp eq i64 %t26, 21
  store i1 %t28, ptr %l43, !tbaa !21
  br label %bb9
bb9:
  %t29 = load i1, ptr %l43, !tbaa !21
  br i1 %t29, label %bb10, label %bb11
bb10:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr { i64, [4 x i64] }, ptr %t30, i32 0, i32 1
  %t33 = getelementptr { %"compiler/source:Span", ptr }, ptr %t32, i32 0, i32 1
  %t34 = load ptr, ptr %t33
  store ptr %t34, ptr %l2, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t38 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t41 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t36, { i64, ptr } %t38)
  store i1 %t41, ptr %l51
  br label %bb13
bb13:
  %t42 = load i1, ptr %l51, !tbaa !21
  store i1 %t42, ptr %rv
  br label %ret
bb14:
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l52, !tbaa !29
  store i1 false, ptr %l53, !tbaa !21
  %t44 = load ptr, ptr %l52, !tbaa !29
  %t45 = icmp ne ptr %t44, null
  br i1 %t45, label %bb15, label %bb16
bb15:
  %t47 = load ptr, ptr %l52, !tbaa !29
  %t48 = load i64, ptr %t47, !range !{i64 0, i64 22}
  %t50 = icmp eq i64 %t48, 1
  store i1 %t50, ptr %l53, !tbaa !21
  br label %bb16
bb16:
  %t51 = load i1, ptr %l53, !tbaa !21
  br i1 %t51, label %bb17, label %bb18
bb17:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr { i64, [4 x i64] }, ptr %t52, i32 0, i32 1
  %t55 = getelementptr { %"compiler/source:Span", ptr }, ptr %t54, i32 0, i32 1
  %t56 = load ptr, ptr %t55
  store ptr %t56, ptr %l3, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t58 = load ptr, ptr %l3, !tbaa !29
  %t60 = getelementptr %"compiler/ast:VarDecl", ptr %t58, i32 0, i32 3
  %t61 = load { i64, ptr }, ptr %t60, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t65 = call i1 @compiler_2fcheck_2eexprsAssign(ptr %v0, ptr %v1, { i64, ptr } %t61, { i64, ptr } %t62)
  store i1 %t65, ptr %l61
  br label %bb20
bb20:
  %t66 = load i1, ptr %l61, !tbaa !21
  store i1 %t66, ptr %rv
  br label %ret
bb21:
  %t67 = load ptr, ptr %l0, !tbaa !29
  store ptr %t67, ptr %l62, !tbaa !29
  store i1 false, ptr %l63, !tbaa !21
  %t68 = load ptr, ptr %l62, !tbaa !29
  %t69 = icmp ne ptr %t68, null
  br i1 %t69, label %bb22, label %bb23
bb22:
  %t71 = load ptr, ptr %l62, !tbaa !29
  %t72 = load i64, ptr %t71, !range !{i64 0, i64 22}
  %t74 = icmp eq i64 %t72, 3
  store i1 %t74, ptr %l63, !tbaa !21
  br label %bb23
bb23:
  %t75 = load i1, ptr %l63, !tbaa !21
  br i1 %t75, label %bb24, label %bb25
bb24:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr { i64, [4 x i64] }, ptr %t76, i32 0, i32 1
  %t79 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t78, i32 0, i32 2
  %t80 = load ptr, ptr %t79
  store ptr %t80, ptr %l4, !tbaa !29
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr { i64, [4 x i64] }, ptr %t82, i32 0, i32 1
  %t85 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t84, i32 0, i32 3
  %t86 = load ptr, ptr %t85
  store ptr %t86, ptr %l5, !tbaa !29
  br label %bb26
bb25:
  br label %bb36
bb26:
  %t88 = load ptr, ptr %l4, !tbaa !29
  %t89 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t92 = call i1 @compiler_2fcheck_2ehitsPath(ptr %v0, ptr %v1, ptr %t88, { i64, ptr } %t89)
  store i1 %t92, ptr %l72
  br label %bb27
bb27:
  %t93 = load i1, ptr %l72, !tbaa !21
  br i1 %t93, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l73, !tbaa !21
  br label %bb31
bb29:
  %t94 = load ptr, ptr %l4, !tbaa !29
  %t96 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t99 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t94, { i64, ptr } %t96)
  store i1 %t99, ptr %l77
  br label %bb30
bb30:
  %t100 = load i1, ptr %l77, !tbaa !21
  store i1 %t100, ptr %l73, !tbaa !21
  br label %bb31
bb31:
  %t101 = load i1, ptr %l73, !tbaa !21
  br i1 %t101, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l78, !tbaa !21
  br label %bb35
bb33:
  %t102 = load ptr, ptr %l5, !tbaa !29
  %t104 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t107 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t102, { i64, ptr } %t104)
  store i1 %t107, ptr %l82
  br label %bb34
bb34:
  %t108 = load i1, ptr %l82, !tbaa !21
  store i1 %t108, ptr %l78, !tbaa !21
  br label %bb35
bb35:
  %t109 = load i1, ptr %l78, !tbaa !21
  store i1 %t109, ptr %rv
  br label %ret
bb36:
  %t110 = load ptr, ptr %l0, !tbaa !29
  store ptr %t110, ptr %l83, !tbaa !29
  store i1 false, ptr %l84, !tbaa !21
  %t111 = load ptr, ptr %l83, !tbaa !29
  %t112 = icmp ne ptr %t111, null
  br i1 %t112, label %bb37, label %bb38
bb37:
  %t114 = load ptr, ptr %l83, !tbaa !29
  %t115 = load i64, ptr %t114, !range !{i64 0, i64 22}
  %t117 = icmp eq i64 %t115, 2
  store i1 %t117, ptr %l84, !tbaa !21
  br label %bb38
bb38:
  %t118 = load i1, ptr %l84, !tbaa !21
  br i1 %t118, label %bb39, label %bb40
bb39:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr { i64, [4 x i64] }, ptr %t119, i32 0, i32 1
  %t122 = getelementptr { %"compiler/source:Span", ptr }, ptr %t121, i32 0, i32 1
  %t123 = load ptr, ptr %t122
  store ptr %t123, ptr %l6, !tbaa !29
  br label %bb41
bb40:
  br label %bb57
bb41:
  %t125 = load ptr, ptr %l6, !tbaa !29
  %t127 = getelementptr %"compiler/ast:Multi", ptr %t125, i32 0, i32 0
  %t128 = load { i64, ptr }, ptr %t127, !tbaa !27
  store { i64, ptr } %t128, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t130 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t130, 0
  store i64 %t132, ptr %l9, !tbaa !24
  br label %bb42
bb42:
  %t134 = load i64, ptr %l8, !tbaa !24
  %t135 = load i64, ptr %l9, !tbaa !24
  %t138 = icmp slt i64 %t134, %t135
  %t140 = xor i1 %t138, true
  br i1 %t140, label %bb43, label %bb44
bb43:
  br label %bb55
bb44:
  br label %bb45
bb45:
  %t142 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t142, ptr %l97, !tbaa !27
  %t143 = load i64, ptr %l8, !tbaa !24
  %t145 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = getelementptr ptr, ptr %t146, i64 %t143
  %t148 = load ptr, ptr %t147, !tbaa !39
  store ptr %t148, ptr %l10, !tbaa !29
  %t150 = load ptr, ptr %l10, !tbaa !29
  %t151 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t154 = call i1 @compiler_2fcheck_2ehitsPath(ptr %v0, ptr %v1, ptr %t150, { i64, ptr } %t151)
  store i1 %t154, ptr %l102
  br label %bb46
bb46:
  %t155 = load i1, ptr %l102, !tbaa !21
  br i1 %t155, label %bb47, label %bb48
bb47:
  store i1 true, ptr %l103, !tbaa !21
  br label %bb50
bb48:
  %t156 = load ptr, ptr %l10, !tbaa !29
  %t158 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t161 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t156, { i64, ptr } %t158)
  store i1 %t161, ptr %l107
  br label %bb49
bb49:
  %t162 = load i1, ptr %l107, !tbaa !21
  store i1 %t162, ptr %l103, !tbaa !21
  br label %bb50
bb50:
  %t163 = load i1, ptr %l103, !tbaa !21
  br i1 %t163, label %bb51, label %bb52
bb51:
  store i1 true, ptr %rv
  br label %ret
bb52:
  br label %bb53
bb53:
  br label %bb54
bb54:
  %t165 = load i64, ptr %l8, !tbaa !24
  %t167 = add i64 %t165, 1
  store i64 %t167, ptr %l8, !tbaa !24
  br label %bb42
bb55:
  %t169 = load ptr, ptr %l6, !tbaa !29
  %t171 = getelementptr %"compiler/ast:Multi", ptr %t169, i32 0, i32 2
  %t172 = load { i64, ptr }, ptr %t171, !tbaa !27
  %t173 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t176 = call i1 @compiler_2fcheck_2eexprsAssign(ptr %v0, ptr %v1, { i64, ptr } %t172, { i64, ptr } %t173)
  store i1 %t176, ptr %l114
  br label %bb56
bb56:
  %t177 = load i1, ptr %l114, !tbaa !21
  store i1 %t177, ptr %rv
  br label %ret
bb57:
  %t178 = load ptr, ptr %l0, !tbaa !29
  store ptr %t178, ptr %l115, !tbaa !29
  store i1 false, ptr %l116, !tbaa !21
  %t179 = load ptr, ptr %l115, !tbaa !29
  %t180 = icmp ne ptr %t179, null
  br i1 %t180, label %bb58, label %bb59
bb58:
  %t182 = load ptr, ptr %l115, !tbaa !29
  %t183 = load i64, ptr %t182, !range !{i64 0, i64 22}
  %t185 = icmp eq i64 %t183, 4
  store i1 %t185, ptr %l116, !tbaa !21
  br label %bb59
bb59:
  %t186 = load i1, ptr %l116, !tbaa !21
  br i1 %t186, label %bb60, label %bb61
bb60:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr { i64, [4 x i64] }, ptr %t187, i32 0, i32 1
  %t190 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t189, i32 0, i32 1
  %t191 = load ptr, ptr %t190
  store ptr %t191, ptr %l11, !tbaa !29
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t195 = getelementptr { i64, [4 x i64] }, ptr %t193, i32 0, i32 1
  %t196 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t195, i32 0, i32 2
  %t197 = load { i64, ptr }, ptr %t196
  store { i64, ptr } %t197, ptr %l12, !tbaa !27
  br label %bb62
bb61:
  br label %bb68
bb62:
  %t199 = load ptr, ptr %l11, !tbaa !29
  %t201 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t204 = call i1 @compiler_2fcheck_2estmtAssigns(ptr %v0, ptr %v1, ptr %t199, { i64, ptr } %t201)
  store i1 %t204, ptr %l126
  br label %bb63
bb63:
  %t205 = load i1, ptr %l126, !tbaa !21
  br i1 %t205, label %bb64, label %bb65
bb64:
  store i1 true, ptr %l127, !tbaa !21
  br label %bb67
bb65:
  %t206 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t207 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t210 = call i1 @compiler_2fcheck_2eclausesAssign(ptr %v0, ptr %v1, { i64, ptr } %t206, { i64, ptr } %t207)
  store i1 %t210, ptr %l130
  br label %bb66
bb66:
  %t211 = load i1, ptr %l130, !tbaa !21
  store i1 %t211, ptr %l127, !tbaa !21
  br label %bb67
bb67:
  %t212 = load i1, ptr %l127, !tbaa !21
  store i1 %t212, ptr %rv
  br label %ret
bb68:
  %t213 = load ptr, ptr %l0, !tbaa !29
  store ptr %t213, ptr %l131, !tbaa !29
  store i1 false, ptr %l132, !tbaa !21
  %t214 = load ptr, ptr %l131, !tbaa !29
  %t215 = icmp ne ptr %t214, null
  br i1 %t215, label %bb69, label %bb70
bb69:
  %t217 = load ptr, ptr %l131, !tbaa !29
  %t218 = load i64, ptr %t217, !range !{i64 0, i64 22}
  %t220 = icmp eq i64 %t218, 5
  store i1 %t220, ptr %l132, !tbaa !21
  br label %bb70
bb70:
  %t221 = load i1, ptr %l132, !tbaa !21
  br i1 %t221, label %bb71, label %bb72
bb71:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr { i64, [4 x i64] }, ptr %t222, i32 0, i32 1
  %t225 = getelementptr { %"compiler/source:Span", ptr }, ptr %t224, i32 0, i32 1
  %t226 = load ptr, ptr %t225
  store ptr %t226, ptr %l13, !tbaa !29
  br label %bb73
bb72:
  br label %bb75
bb73:
  %t228 = load ptr, ptr %l13, !tbaa !29
  %t229 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t232 = call i1 @compiler_2fcheck_2eifAssigns(ptr %v0, ptr %v1, ptr %t228, { i64, ptr } %t229)
  store i1 %t232, ptr %l139
  br label %bb74
bb74:
  %t233 = load i1, ptr %l139, !tbaa !21
  store i1 %t233, ptr %rv
  br label %ret
bb75:
  %t234 = load ptr, ptr %l0, !tbaa !29
  store ptr %t234, ptr %l140, !tbaa !29
  store i1 false, ptr %l141, !tbaa !21
  %t235 = load ptr, ptr %l140, !tbaa !29
  %t236 = icmp ne ptr %t235, null
  br i1 %t236, label %bb76, label %bb77
bb76:
  %t238 = load ptr, ptr %l140, !tbaa !29
  %t239 = load i64, ptr %t238, !range !{i64 0, i64 22}
  %t241 = icmp eq i64 %t239, 6
  store i1 %t241, ptr %l141, !tbaa !21
  br label %bb77
bb77:
  %t242 = load i1, ptr %l141, !tbaa !21
  br i1 %t242, label %bb78, label %bb79
bb78:
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t245 = getelementptr { i64, [4 x i64] }, ptr %t243, i32 0, i32 1
  %t246 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t245, i32 0, i32 1
  %t247 = load { i64, ptr }, ptr %t246
  store { i64, ptr } %t247, ptr %l14, !tbaa !27
  br label %bb84
bb79:
  %t249 = load ptr, ptr %l0, !tbaa !29
  store ptr %t249, ptr %l146, !tbaa !29
  store i1 false, ptr %l147, !tbaa !21
  %t250 = load ptr, ptr %l146, !tbaa !29
  %t251 = icmp ne ptr %t250, null
  br i1 %t251, label %bb80, label %bb81
bb80:
  %t253 = load ptr, ptr %l146, !tbaa !29
  %t254 = load i64, ptr %t253, !range !{i64 0, i64 22}
  %t256 = icmp eq i64 %t254, 20
  store i1 %t256, ptr %l147, !tbaa !21
  br label %bb81
bb81:
  %t257 = load i1, ptr %l147, !tbaa !21
  br i1 %t257, label %bb82, label %bb83
bb82:
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t260 = getelementptr { i64, [4 x i64] }, ptr %t258, i32 0, i32 1
  %t261 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t260, i32 0, i32 1
  %t262 = load { i64, ptr }, ptr %t261
  store { i64, ptr } %t262, ptr %l14, !tbaa !27
  br label %bb84
bb83:
  br label %bb86
bb84:
  %t264 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t265 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t268 = call i1 @compiler_2fcheck_2eassignsName(ptr %v0, ptr %v1, { i64, ptr } %t264, { i64, ptr } %t265)
  store i1 %t268, ptr %l154
  br label %bb85
bb85:
  %t269 = load i1, ptr %l154, !tbaa !21
  store i1 %t269, ptr %rv
  br label %ret
bb86:
  %t270 = load ptr, ptr %l0, !tbaa !29
  store ptr %t270, ptr %l155, !tbaa !29
  store i1 false, ptr %l156, !tbaa !21
  %t271 = load ptr, ptr %l155, !tbaa !29
  %t272 = icmp ne ptr %t271, null
  br i1 %t272, label %bb87, label %bb88
bb87:
  %t274 = load ptr, ptr %l155, !tbaa !29
  %t275 = load i64, ptr %t274, !range !{i64 0, i64 22}
  %t277 = icmp eq i64 %t275, 7
  store i1 %t277, ptr %l156, !tbaa !21
  br label %bb88
bb88:
  %t278 = load i1, ptr %l156, !tbaa !21
  br i1 %t278, label %bb89, label %bb90
bb89:
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t281 = getelementptr { i64, [4 x i64] }, ptr %t279, i32 0, i32 1
  %t282 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t281, i32 0, i32 1
  %t283 = load ptr, ptr %t282
  store ptr %t283, ptr %l15, !tbaa !29
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t287 = getelementptr { i64, [4 x i64] }, ptr %t285, i32 0, i32 1
  %t288 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t287, i32 0, i32 2
  %t289 = load { i64, ptr }, ptr %t288
  store { i64, ptr } %t289, ptr %l16, !tbaa !27
  br label %bb95
bb90:
  %t291 = load ptr, ptr %l0, !tbaa !29
  store ptr %t291, ptr %l163, !tbaa !29
  store i1 false, ptr %l164, !tbaa !21
  %t292 = load ptr, ptr %l163, !tbaa !29
  %t293 = icmp ne ptr %t292, null
  br i1 %t293, label %bb91, label %bb92
bb91:
  %t295 = load ptr, ptr %l163, !tbaa !29
  %t296 = load i64, ptr %t295, !range !{i64 0, i64 22}
  %t298 = icmp eq i64 %t296, 10
  store i1 %t298, ptr %l164, !tbaa !21
  br label %bb92
bb92:
  %t299 = load i1, ptr %l164, !tbaa !21
  br i1 %t299, label %bb93, label %bb94
bb93:
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t302 = getelementptr { i64, [4 x i64] }, ptr %t300, i32 0, i32 1
  %t303 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t302, i32 0, i32 1
  %t304 = load { i64, ptr }, ptr %t303
  store { i64, ptr } %t304, ptr %l16, !tbaa !27
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t308 = getelementptr { i64, [4 x i64] }, ptr %t306, i32 0, i32 1
  %t309 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t308, i32 0, i32 2
  %t310 = load ptr, ptr %t309
  store ptr %t310, ptr %l15, !tbaa !29
  br label %bb95
bb94:
  br label %bb101
bb95:
  %t312 = load ptr, ptr %l15, !tbaa !29
  %t314 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t317 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t312, { i64, ptr } %t314)
  store i1 %t317, ptr %l174
  br label %bb96
bb96:
  %t318 = load i1, ptr %l174, !tbaa !21
  br i1 %t318, label %bb97, label %bb98
bb97:
  store i1 true, ptr %l175, !tbaa !21
  br label %bb100
bb98:
  %t319 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t320 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t323 = call i1 @compiler_2fcheck_2eassignsName(ptr %v0, ptr %v1, { i64, ptr } %t319, { i64, ptr } %t320)
  store i1 %t323, ptr %l178
  br label %bb99
bb99:
  %t324 = load i1, ptr %l178, !tbaa !21
  store i1 %t324, ptr %l175, !tbaa !21
  br label %bb100
bb100:
  %t325 = load i1, ptr %l175, !tbaa !21
  store i1 %t325, ptr %rv
  br label %ret
bb101:
  %t326 = load ptr, ptr %l0, !tbaa !29
  store ptr %t326, ptr %l179, !tbaa !29
  store i1 false, ptr %l180, !tbaa !21
  %t327 = load ptr, ptr %l179, !tbaa !29
  %t328 = icmp ne ptr %t327, null
  br i1 %t328, label %bb102, label %bb103
bb102:
  %t330 = load ptr, ptr %l179, !tbaa !29
  %t331 = load i64, ptr %t330, !range !{i64 0, i64 22}
  %t333 = icmp eq i64 %t331, 8
  store i1 %t333, ptr %l180, !tbaa !21
  br label %bb103
bb103:
  %t334 = load i1, ptr %l180, !tbaa !21
  br i1 %t334, label %bb104, label %bb105
bb104:
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t337 = getelementptr { i64, [4 x i64] }, ptr %t335, i32 0, i32 1
  %t338 = getelementptr { %"compiler/source:Span", ptr }, ptr %t337, i32 0, i32 1
  %t339 = load ptr, ptr %t338
  store ptr %t339, ptr %l17, !tbaa !29
  br label %bb106
bb105:
  br label %bb120
bb106:
  %t341 = load ptr, ptr %l17, !tbaa !29
  %t343 = getelementptr %"compiler/ast:For3", ptr %t341, i32 0, i32 0
  %t344 = load ptr, ptr %t343, !tbaa !29
  %t346 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t349 = call i1 @compiler_2fcheck_2estmtAssigns(ptr %v0, ptr %v1, ptr %t344, { i64, ptr } %t346)
  store i1 %t349, ptr %l189
  br label %bb107
bb107:
  %t350 = load i1, ptr %l189, !tbaa !21
  br i1 %t350, label %bb108, label %bb109
bb108:
  store i1 true, ptr %l190, !tbaa !21
  br label %bb111
bb109:
  %t351 = load ptr, ptr %l17, !tbaa !29
  %t353 = getelementptr %"compiler/ast:For3", ptr %t351, i32 0, i32 1
  %t354 = load ptr, ptr %t353, !tbaa !29
  %t355 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t358 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t354, { i64, ptr } %t355)
  store i1 %t358, ptr %l194
  br label %bb110
bb110:
  %t359 = load i1, ptr %l194, !tbaa !21
  store i1 %t359, ptr %l190, !tbaa !21
  br label %bb111
bb111:
  %t360 = load i1, ptr %l190, !tbaa !21
  br i1 %t360, label %bb112, label %bb113
bb112:
  store i1 true, ptr %l195, !tbaa !21
  br label %bb115
bb113:
  %t361 = load ptr, ptr %l17, !tbaa !29
  %t363 = getelementptr %"compiler/ast:For3", ptr %t361, i32 0, i32 2
  %t364 = load ptr, ptr %t363, !tbaa !29
  %t366 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t369 = call i1 @compiler_2fcheck_2estmtAssigns(ptr %v0, ptr %v1, ptr %t364, { i64, ptr } %t366)
  store i1 %t369, ptr %l200
  br label %bb114
bb114:
  %t370 = load i1, ptr %l200, !tbaa !21
  store i1 %t370, ptr %l195, !tbaa !21
  br label %bb115
bb115:
  %t371 = load i1, ptr %l195, !tbaa !21
  br i1 %t371, label %bb116, label %bb117
bb116:
  store i1 true, ptr %l201, !tbaa !21
  br label %bb119
bb117:
  %t372 = load ptr, ptr %l17, !tbaa !29
  %t374 = getelementptr %"compiler/ast:For3", ptr %t372, i32 0, i32 3
  %t375 = load { i64, ptr }, ptr %t374, !tbaa !27
  %t376 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t379 = call i1 @compiler_2fcheck_2eassignsName(ptr %v0, ptr %v1, { i64, ptr } %t375, { i64, ptr } %t376)
  store i1 %t379, ptr %l205
  br label %bb118
bb118:
  %t380 = load i1, ptr %l205, !tbaa !21
  store i1 %t380, ptr %l201, !tbaa !21
  br label %bb119
bb119:
  %t381 = load i1, ptr %l201, !tbaa !21
  store i1 %t381, ptr %rv
  br label %ret
bb120:
  %t382 = load ptr, ptr %l0, !tbaa !29
  store ptr %t382, ptr %l206, !tbaa !29
  store i1 false, ptr %l207, !tbaa !21
  %t383 = load ptr, ptr %l206, !tbaa !29
  %t384 = icmp ne ptr %t383, null
  br i1 %t384, label %bb121, label %bb122
bb121:
  %t386 = load ptr, ptr %l206, !tbaa !29
  %t387 = load i64, ptr %t386, !range !{i64 0, i64 22}
  %t389 = icmp eq i64 %t387, 9
  store i1 %t389, ptr %l207, !tbaa !21
  br label %bb122
bb122:
  %t390 = load i1, ptr %l207, !tbaa !21
  br i1 %t390, label %bb123, label %bb124
bb123:
  %t391 = load ptr, ptr %l0, !tbaa !29
  %t393 = getelementptr { i64, [4 x i64] }, ptr %t391, i32 0, i32 1
  %t394 = getelementptr { %"compiler/source:Span", ptr }, ptr %t393, i32 0, i32 1
  %t395 = load ptr, ptr %t394
  store ptr %t395, ptr %l18, !tbaa !29
  br label %bb125
bb124:
  br label %bb135
bb125:
  %t397 = load ptr, ptr %l18, !tbaa !29
  %t399 = getelementptr %"compiler/ast:ForIn", ptr %t397, i32 0, i32 2
  %t400 = load ptr, ptr %t399, !tbaa !29
  %t402 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t405 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t400, { i64, ptr } %t402)
  store i1 %t405, ptr %l216
  br label %bb126
bb126:
  %t406 = load i1, ptr %l216, !tbaa !21
  br i1 %t406, label %bb127, label %bb128
bb127:
  store i1 true, ptr %l217, !tbaa !21
  br label %bb130
bb128:
  %t407 = load ptr, ptr %l18, !tbaa !29
  %t409 = getelementptr %"compiler/ast:ForIn", ptr %t407, i32 0, i32 4
  %t410 = load { i64, ptr }, ptr %t409, !tbaa !27
  %t411 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t414 = call i1 @compiler_2fcheck_2eassignsName(ptr %v0, ptr %v1, { i64, ptr } %t410, { i64, ptr } %t411)
  store i1 %t414, ptr %l221
  br label %bb129
bb129:
  %t415 = load i1, ptr %l221, !tbaa !21
  store i1 %t415, ptr %l217, !tbaa !21
  br label %bb130
bb130:
  %t416 = load i1, ptr %l217, !tbaa !21
  br i1 %t416, label %bb131, label %bb132
bb131:
  store i1 true, ptr %l222, !tbaa !21
  br label %bb134
bb132:
  %t417 = load ptr, ptr %l18, !tbaa !29
  %t419 = getelementptr %"compiler/ast:ForIn", ptr %t417, i32 0, i32 5
  %t420 = load { i64, ptr }, ptr %t419, !tbaa !27
  %t421 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t424 = call i1 @compiler_2fcheck_2eclausesAssign(ptr %v0, ptr %v1, { i64, ptr } %t420, { i64, ptr } %t421)
  store i1 %t424, ptr %l226
  br label %bb133
bb133:
  %t425 = load i1, ptr %l226, !tbaa !21
  store i1 %t425, ptr %l222, !tbaa !21
  br label %bb134
bb134:
  %t426 = load i1, ptr %l222, !tbaa !21
  store i1 %t426, ptr %rv
  br label %ret
bb135:
  %t427 = load ptr, ptr %l0, !tbaa !29
  store ptr %t427, ptr %l227, !tbaa !29
  store i1 false, ptr %l228, !tbaa !21
  %t428 = load ptr, ptr %l227, !tbaa !29
  %t429 = icmp ne ptr %t428, null
  br i1 %t429, label %bb136, label %bb137
bb136:
  %t431 = load ptr, ptr %l227, !tbaa !29
  %t432 = load i64, ptr %t431, !range !{i64 0, i64 22}
  %t434 = icmp eq i64 %t432, 11
  store i1 %t434, ptr %l228, !tbaa !21
  br label %bb137
bb137:
  %t435 = load i1, ptr %l228, !tbaa !21
  br i1 %t435, label %bb138, label %bb139
bb138:
  %t436 = load ptr, ptr %l0, !tbaa !29
  %t438 = getelementptr { i64, [4 x i64] }, ptr %t436, i32 0, i32 1
  %t439 = getelementptr { %"compiler/source:Span", ptr }, ptr %t438, i32 0, i32 1
  %t440 = load ptr, ptr %t439
  store ptr %t440, ptr %l19, !tbaa !29
  br label %bb140
bb139:
  br label %bb142
bb140:
  %t442 = load ptr, ptr %l19, !tbaa !29
  %t443 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t446 = call i1 @compiler_2fcheck_2ematchAssigns(ptr %v0, ptr %v1, ptr %t442, { i64, ptr } %t443)
  store i1 %t446, ptr %l235
  br label %bb141
bb141:
  %t447 = load i1, ptr %l235, !tbaa !21
  store i1 %t447, ptr %rv
  br label %ret
bb142:
  %t448 = load ptr, ptr %l0, !tbaa !29
  store ptr %t448, ptr %l236, !tbaa !29
  store i1 false, ptr %l237, !tbaa !21
  %t449 = load ptr, ptr %l236, !tbaa !29
  %t450 = icmp ne ptr %t449, null
  br i1 %t450, label %bb143, label %bb144
bb143:
  %t452 = load ptr, ptr %l236, !tbaa !29
  %t453 = load i64, ptr %t452, !range !{i64 0, i64 22}
  %t455 = icmp eq i64 %t453, 12
  store i1 %t455, ptr %l237, !tbaa !21
  br label %bb144
bb144:
  %t456 = load i1, ptr %l237, !tbaa !21
  br i1 %t456, label %bb145, label %bb146
bb145:
  %t457 = load ptr, ptr %l0, !tbaa !29
  %t459 = getelementptr { i64, [4 x i64] }, ptr %t457, i32 0, i32 1
  %t460 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t459, i32 0, i32 1
  %t461 = load { i64, ptr }, ptr %t460
  store { i64, ptr } %t461, ptr %l20, !tbaa !27
  br label %bb147
bb146:
  br label %bb149
bb147:
  %t463 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t464 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t467 = call i1 @compiler_2fcheck_2eexprsAssign(ptr %v0, ptr %v1, { i64, ptr } %t463, { i64, ptr } %t464)
  store i1 %t467, ptr %l244
  br label %bb148
bb148:
  %t468 = load i1, ptr %l244, !tbaa !21
  store i1 %t468, ptr %rv
  br label %ret
bb149:
  %t469 = load ptr, ptr %l0, !tbaa !29
  store ptr %t469, ptr %l245, !tbaa !29
  store i1 false, ptr %l246, !tbaa !21
  %t470 = load ptr, ptr %l245, !tbaa !29
  %t471 = icmp ne ptr %t470, null
  br i1 %t471, label %bb150, label %bb151
bb150:
  %t473 = load ptr, ptr %l245, !tbaa !29
  %t474 = load i64, ptr %t473, !range !{i64 0, i64 22}
  %t476 = icmp eq i64 %t474, 15
  store i1 %t476, ptr %l246, !tbaa !21
  br label %bb151
bb151:
  %t477 = load i1, ptr %l246, !tbaa !21
  br i1 %t477, label %bb152, label %bb153
bb152:
  %t478 = load ptr, ptr %l0, !tbaa !29
  %t480 = getelementptr { i64, [4 x i64] }, ptr %t478, i32 0, i32 1
  %t481 = getelementptr { %"compiler/source:Span", ptr }, ptr %t480, i32 0, i32 1
  %t482 = load ptr, ptr %t481
  store ptr %t482, ptr %l21, !tbaa !29
  br label %bb154
bb153:
  br label %bb156
bb154:
  %t484 = load ptr, ptr %l21, !tbaa !29
  %t486 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t489 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t484, { i64, ptr } %t486)
  store i1 %t489, ptr %l254
  br label %bb155
bb155:
  %t490 = load i1, ptr %l254, !tbaa !21
  store i1 %t490, ptr %rv
  br label %ret
bb156:
  %t491 = load ptr, ptr %l0, !tbaa !29
  store ptr %t491, ptr %l255, !tbaa !29
  store i1 false, ptr %l256, !tbaa !21
  %t492 = load ptr, ptr %l255, !tbaa !29
  %t493 = icmp ne ptr %t492, null
  br i1 %t493, label %bb157, label %bb158
bb157:
  %t495 = load ptr, ptr %l255, !tbaa !29
  %t496 = load i64, ptr %t495, !range !{i64 0, i64 22}
  %t498 = icmp eq i64 %t496, 13
  store i1 %t498, ptr %l256, !tbaa !21
  br label %bb158
bb158:
  %t499 = load i1, ptr %l256, !tbaa !21
  br i1 %t499, label %bb159, label %bb160
bb159:
  %t500 = load ptr, ptr %l0, !tbaa !29
  %t502 = getelementptr { i64, [4 x i64] }, ptr %t500, i32 0, i32 1
  %t503 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t502, i32 0, i32 2
  %t504 = load ptr, ptr %t503
  store ptr %t504, ptr %l22, !tbaa !29
  br label %bb161
bb160:
  br label %bb163
bb161:
  %t506 = load ptr, ptr %l22, !tbaa !29
  %t507 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t510 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t506, { i64, ptr } %t507)
  store i1 %t510, ptr %l263
  br label %bb162
bb162:
  %t511 = load i1, ptr %l263, !tbaa !21
  store i1 %t511, ptr %rv
  br label %ret
bb163:
  %t512 = load ptr, ptr %l0, !tbaa !29
  store ptr %t512, ptr %l264, !tbaa !29
  store i1 false, ptr %l265, !tbaa !21
  %t513 = load ptr, ptr %l264, !tbaa !29
  %t514 = icmp ne ptr %t513, null
  br i1 %t514, label %bb164, label %bb165
bb164:
  %t516 = load ptr, ptr %l264, !tbaa !29
  %t517 = load i64, ptr %t516, !range !{i64 0, i64 22}
  %t519 = icmp eq i64 %t517, 14
  store i1 %t519, ptr %l265, !tbaa !21
  br label %bb165
bb165:
  %t520 = load i1, ptr %l265, !tbaa !21
  br i1 %t520, label %bb166, label %bb167
bb166:
  %t521 = load ptr, ptr %l0, !tbaa !29
  %t523 = getelementptr { i64, [4 x i64] }, ptr %t521, i32 0, i32 1
  %t524 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t523, i32 0, i32 1
  %t525 = load ptr, ptr %t524
  store ptr %t525, ptr %l23, !tbaa !29
  %t527 = load ptr, ptr %l0, !tbaa !29
  %t529 = getelementptr { i64, [4 x i64] }, ptr %t527, i32 0, i32 1
  %t530 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t529, i32 0, i32 2
  %t531 = load ptr, ptr %t530
  store ptr %t531, ptr %l24, !tbaa !29
  br label %bb168
bb167:
  br label %bb174
bb168:
  %t533 = load ptr, ptr %l23, !tbaa !29
  %t535 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t538 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t533, { i64, ptr } %t535)
  store i1 %t538, ptr %l275
  br label %bb169
bb169:
  %t539 = load i1, ptr %l275, !tbaa !21
  br i1 %t539, label %bb170, label %bb171
bb170:
  store i1 true, ptr %l276, !tbaa !21
  br label %bb173
bb171:
  %t540 = load ptr, ptr %l24, !tbaa !29
  %t541 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t544 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t540, { i64, ptr } %t541)
  store i1 %t544, ptr %l279
  br label %bb172
bb172:
  %t545 = load i1, ptr %l279, !tbaa !21
  store i1 %t545, ptr %l276, !tbaa !21
  br label %bb173
bb173:
  %t546 = load i1, ptr %l276, !tbaa !21
  store i1 %t546, ptr %rv
  br label %ret
bb174:
  %t547 = load ptr, ptr %l0, !tbaa !29
  store ptr %t547, ptr %l280, !tbaa !29
  store i1 false, ptr %l281, !tbaa !21
  %t548 = load ptr, ptr %l280, !tbaa !29
  %t549 = icmp ne ptr %t548, null
  br i1 %t549, label %bb175, label %bb176
bb175:
  %t551 = load ptr, ptr %l280, !tbaa !29
  %t552 = load i64, ptr %t551, !range !{i64 0, i64 22}
  %t554 = icmp eq i64 %t552, 16
  store i1 %t554, ptr %l281, !tbaa !21
  br label %bb176
bb176:
  %t555 = load i1, ptr %l281, !tbaa !21
  br i1 %t555, label %bb177, label %bb178
bb177:
  br label %bb179
bb178:
  br label %bb180
bb179:
  store i1 false, ptr %rv
  br label %ret
bb180:
  %t557 = load ptr, ptr %l0, !tbaa !29
  store ptr %t557, ptr %l285, !tbaa !29
  store i1 false, ptr %l286, !tbaa !21
  %t558 = load ptr, ptr %l285, !tbaa !29
  %t559 = icmp ne ptr %t558, null
  br i1 %t559, label %bb181, label %bb182
bb181:
  %t561 = load ptr, ptr %l285, !tbaa !29
  %t562 = load i64, ptr %t561, !range !{i64 0, i64 22}
  %t564 = icmp eq i64 %t562, 18
  store i1 %t564, ptr %l286, !tbaa !21
  br label %bb182
bb182:
  %t565 = load i1, ptr %l286, !tbaa !21
  br i1 %t565, label %bb183, label %bb184
bb183:
  %t566 = load ptr, ptr %l0, !tbaa !29
  %t568 = getelementptr { i64, [4 x i64] }, ptr %t566, i32 0, i32 1
  %t569 = getelementptr { %"compiler/source:Span", ptr }, ptr %t568, i32 0, i32 1
  %t570 = load ptr, ptr %t569
  store ptr %t570, ptr %l25, !tbaa !29
  br label %bb185
bb184:
  br label %bb191
bb185:
  %t572 = load ptr, ptr %l25, !tbaa !29
  %t574 = getelementptr %"compiler/ast:JoinS", ptr %t572, i32 0, i32 1
  %t575 = load { i64, ptr }, ptr %t574, !tbaa !27
  %t576 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t579 = call i1 @compiler_2fcheck_2eassignsName(ptr %v0, ptr %v1, { i64, ptr } %t575, { i64, ptr } %t576)
  store i1 %t579, ptr %l294
  br label %bb186
bb186:
  %t580 = load i1, ptr %l294, !tbaa !21
  br i1 %t580, label %bb187, label %bb188
bb187:
  store i1 true, ptr %l295, !tbaa !21
  br label %bb190
bb188:
  %t581 = load ptr, ptr %l25, !tbaa !29
  %t583 = getelementptr %"compiler/ast:JoinS", ptr %t581, i32 0, i32 2
  %t584 = load { i64, ptr }, ptr %t583, !tbaa !27
  %t585 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t588 = call i1 @compiler_2fcheck_2eclausesAssign(ptr %v0, ptr %v1, { i64, ptr } %t584, { i64, ptr } %t585)
  store i1 %t588, ptr %l299
  br label %bb189
bb189:
  %t589 = load i1, ptr %l299, !tbaa !21
  store i1 %t589, ptr %l295, !tbaa !21
  br label %bb190
bb190:
  %t590 = load i1, ptr %l295, !tbaa !21
  store i1 %t590, ptr %rv
  br label %ret
bb191:
  %t591 = load ptr, ptr %l0, !tbaa !29
  store ptr %t591, ptr %l300, !tbaa !29
  store i1 false, ptr %l301, !tbaa !21
  %t592 = load ptr, ptr %l300, !tbaa !29
  %t593 = icmp ne ptr %t592, null
  br i1 %t593, label %bb192, label %bb193
bb192:
  %t595 = load ptr, ptr %l300, !tbaa !29
  %t596 = load i64, ptr %t595, !range !{i64 0, i64 22}
  %t598 = icmp eq i64 %t596, 19
  store i1 %t598, ptr %l301, !tbaa !21
  br label %bb193
bb193:
  %t599 = load i1, ptr %l301, !tbaa !21
  br i1 %t599, label %bb194, label %bb195
bb194:
  %t600 = load ptr, ptr %l0, !tbaa !29
  %t602 = getelementptr { i64, [4 x i64] }, ptr %t600, i32 0, i32 1
  %t603 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t602, i32 0, i32 1
  %t604 = load ptr, ptr %t603
  store ptr %t604, ptr %l26, !tbaa !29
  br label %bb196
bb195:
  br label %bb198
bb196:
  %t606 = load ptr, ptr %l26, !tbaa !29
  %t608 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t611 = call i1 @compiler_2fcheck_2estmtAssigns(ptr %v0, ptr %v1, ptr %t606, { i64, ptr } %t608)
  store i1 %t611, ptr %l309
  br label %bb197
bb197:
  %t612 = load i1, ptr %l309, !tbaa !21
  store i1 %t612, ptr %rv
  br label %ret
bb198:
  %t613 = load ptr, ptr %l0, !tbaa !29
  store ptr %t613, ptr %l310, !tbaa !29
  store i1 false, ptr %l311, !tbaa !21
  %t614 = load ptr, ptr %l310, !tbaa !29
  %t615 = icmp ne ptr %t614, null
  br i1 %t615, label %bb199, label %bb200
bb199:
  %t617 = load ptr, ptr %l310, !tbaa !29
  %t618 = load i64, ptr %t617, !range !{i64 0, i64 22}
  %t620 = icmp eq i64 %t618, 17
  store i1 %t620, ptr %l311, !tbaa !21
  br label %bb200
bb200:
  %t621 = load i1, ptr %l311, !tbaa !21
  br i1 %t621, label %bb201, label %bb202
bb201:
  %t622 = load ptr, ptr %l0, !tbaa !29
  %t624 = getelementptr { i64, [4 x i64] }, ptr %t622, i32 0, i32 1
  %t625 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t624, i32 0, i32 1
  %t626 = load { i64, ptr }, ptr %t625
  store { i64, ptr } %t626, ptr %l27, !tbaa !27
  %t628 = load ptr, ptr %l0, !tbaa !29
  %t630 = getelementptr { i64, [4 x i64] }, ptr %t628, i32 0, i32 1
  %t631 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t630, i32 0, i32 2
  %t632 = load ptr, ptr %t631
  store ptr %t632, ptr %l28, !tbaa !29
  br label %bb203
bb202:
  br label %bb219
bb203:
  %t634 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t634, ptr %l29, !tbaa !27
  store i64 0, ptr %l30, !tbaa !24
  %t636 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t638 = extractvalue { i64, ptr } %t636, 0
  store i64 %t638, ptr %l31, !tbaa !24
  br label %bb204
bb204:
  %t640 = load i64, ptr %l30, !tbaa !24
  %t641 = load i64, ptr %l31, !tbaa !24
  %t644 = icmp slt i64 %t640, %t641
  %t646 = xor i1 %t644, true
  br i1 %t646, label %bb205, label %bb206
bb205:
  br label %bb217
bb206:
  br label %bb207
bb207:
  %t648 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t648, ptr %l325, !tbaa !27
  %t649 = load i64, ptr %l30, !tbaa !24
  %t651 = getelementptr { i64, ptr }, ptr %l325, i32 0, i32 1
  %t652 = load ptr, ptr %t651, !tbaa !27
  %t653 = getelementptr ptr, ptr %t652, i64 %t649
  %t654 = load ptr, ptr %t653, !tbaa !39
  store ptr %t654, ptr %l32, !tbaa !29
  %t656 = load ptr, ptr %l32, !tbaa !29
  %t657 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t660 = call i1 @compiler_2fcheck_2ehitsPath(ptr %v0, ptr %v1, ptr %t656, { i64, ptr } %t657)
  store i1 %t660, ptr %l330
  br label %bb208
bb208:
  %t661 = load i1, ptr %l330, !tbaa !21
  br i1 %t661, label %bb209, label %bb210
bb209:
  store i1 true, ptr %l331, !tbaa !21
  br label %bb212
bb210:
  %t662 = load ptr, ptr %l32, !tbaa !29
  %t664 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t667 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t662, { i64, ptr } %t664)
  store i1 %t667, ptr %l335
  br label %bb211
bb211:
  %t668 = load i1, ptr %l335, !tbaa !21
  store i1 %t668, ptr %l331, !tbaa !21
  br label %bb212
bb212:
  %t669 = load i1, ptr %l331, !tbaa !21
  br i1 %t669, label %bb213, label %bb214
bb213:
  store i1 true, ptr %rv
  br label %ret
bb214:
  br label %bb215
bb215:
  br label %bb216
bb216:
  %t671 = load i64, ptr %l30, !tbaa !24
  %t673 = add i64 %t671, 1
  store i64 %t673, ptr %l30, !tbaa !24
  br label %bb204
bb217:
  %t675 = load ptr, ptr %l28, !tbaa !29
  %t677 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t680 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t675, { i64, ptr } %t677)
  store i1 %t680, ptr %l342
  br label %bb218
bb218:
  %t681 = load i1, ptr %l342, !tbaa !21
  store i1 %t681, ptr %rv
  br label %ret
bb219:
  call void @__olang_check_failed(ptr @olang_loc_3f7a94628940c729_cdb98f41ead125dd)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2estoredCatches(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l16 = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l3, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb5, label %bb6
bb5:
  br label %bb11
bb6:
  br label %bb7
bb7:
  %t21 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t21, ptr %l16, !tbaa !27
  %t22 = load i64, ptr %l3, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr ptr, ptr %t25, i64 %t22
  %t27 = load ptr, ptr %t26, !tbaa !39
  store ptr %t27, ptr %l5, !tbaa !29
  %t29 = load ptr, ptr %l5, !tbaa !29
  %t31 = getelementptr %"compiler/ast:Catch", ptr %t29, i32 0, i32 2
  %t32 = load { i64, ptr }, ptr %t31, !tbaa !27
  %t33 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredIn(ptr %v0, ptr %v1, { i64, ptr } %t32, ptr %t33)
  br label %bb8
bb8:
  %t36 = load ptr, ptr %l5, !tbaa !29
  %t38 = getelementptr %"compiler/ast:Catch", ptr %t36, i32 0, i32 3
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !27
  %t40 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExprs(ptr %v0, ptr %v1, { i64, ptr } %t39, ptr %t40)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t43 = load i64, ptr %l3, !tbaa !24
  %t45 = add i64 %t43, 1
  store i64 %t45, ptr %l3, !tbaa !24
  br label %bb4
bb11:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2etryExisting(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l13 = alloca i1
  %l19 = alloca i1
  %l29 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l44 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Try", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  %t8 = xor i1 %t6, true
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/typed:Try", ptr %t10, i32 0, i32 0
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = icmp eq ptr %t13, null
  br i1 %t15, label %bb3, label %bb4
bb2:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb7
bb3:
  call void @__olang_check_failed(ptr @olang_loc_fa22773c0ed7d28e_9744d977b6aff1d2)
  unreachable
bb4:
  br label %bb5
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/typed:Try", ptr %t17, i32 0, i32 0
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = call i1 @compiler_2fcheck_2eexistingValue(ptr %v0, ptr %t20)
  store i1 %t22, ptr %l19
  br label %bb6
bb6:
  %t23 = load i1, ptr %l19, !tbaa !21
  store i1 %t23, ptr %l13, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l13, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  store i1 true, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/typed:Try", ptr %t26, i32 0, i32 1
  %t29 = load { i64, ptr }, ptr %t28, !tbaa !27
  store { i64, ptr } %t29, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t31, 0
  store i64 %t33, ptr %l3, !tbaa !24
  br label %bb11
bb11:
  %t35 = load i64, ptr %l2, !tbaa !24
  %t36 = load i64, ptr %l3, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb12, label %bb13
bb12:
  br label %bb26
bb13:
  br label %bb14
bb14:
  %t43 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t43, ptr %l29, !tbaa !27
  %t44 = load i64, ptr %l2, !tbaa !24
  %t46 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr ptr, ptr %t47, i64 %t44
  %t49 = load ptr, ptr %t48, !tbaa !39
  %t53 = getelementptr %"compiler/typed:Clause", ptr %t49, i32 0, i32 4
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !27
  store { i64, ptr } %t54, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t56 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t56, 0
  store i64 %t58, ptr %l7, !tbaa !24
  br label %bb15
bb15:
  %t60 = load i64, ptr %l6, !tbaa !24
  %t61 = load i64, ptr %l7, !tbaa !24
  %t64 = icmp slt i64 %t60, %t61
  %t66 = xor i1 %t64, true
  br i1 %t66, label %bb16, label %bb17
bb16:
  br label %bb24
bb17:
  br label %bb18
bb18:
  %t68 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t68, ptr %l40, !tbaa !27
  %t69 = load i64, ptr %l6, !tbaa !24
  %t71 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr ptr, ptr %t72, i64 %t69
  %t74 = load ptr, ptr %t73, !tbaa !39
  %t78 = call i1 @compiler_2fcheck_2eexistingValue(ptr %v0, ptr %t74)
  store i1 %t78, ptr %l44
  br label %bb19
bb19:
  %t79 = load i1, ptr %l44, !tbaa !21
  br i1 %t79, label %bb20, label %bb21
bb20:
  store i1 true, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t81 = load i64, ptr %l6, !tbaa !24
  %t83 = add i64 %t81, 1
  store i64 %t83, ptr %l6, !tbaa !24
  br label %bb15
bb24:
  br label %bb25
bb25:
  %t85 = load i64, ptr %l2, !tbaa !24
  %t87 = add i64 %t85, 1
  store i64 %t87, ptr %l2, !tbaa !24
  br label %bb11
bb26:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, i128 } @compiler_2fcheck_2ewideDigits(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l13 = alloca i1
  %l16 = alloca i1
  %l19 = alloca i1
  %l22 = alloca i128
  %l24 = alloca i64
  %l25 = alloca i64
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i32
  %l33 = alloca i128
  %l34 = alloca i32
  %l39 = alloca i1
  %l42 = alloca i1
  %l45 = alloca i1
  %l48 = alloca i128
  %l50 = alloca i64
  %l51 = alloca i64
  %l55 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca i32
  %l59 = alloca i128
  %l60 = alloca i32
  %l62 = alloca i128
  %l63 = alloca { i64, ptr }
  %l64 = alloca i64
  %l65 = alloca i32
  %l67 = alloca i128
  %l68 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i32, i128 }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d55, i32 0, i32 1) }, ptr %l4, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d56, i32 0, i32 1) }, ptr %l5, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t6 = call { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %a0, { i64, ptr } %t4, { i64, ptr } %t5)
  store { i64, ptr } %t6, ptr %l6
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t7, 0
  store i64 %t8, ptr %l7, !tbaa !24
  %t9 = load i64, ptr %l7, !tbaa !24
  %t10 = mul i64 %t9, 1
  %t11 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t10)
  %t12 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  store { i64, ptr } %t13, ptr %l8, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = load i64, ptr %l7, !tbaa !24
  %t19 = mul i64 %t18, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t15, ptr %t17, i64 %t19, i1 false)
  %t20 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t20, ptr %l1, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t22, 0
  %t26 = icmp sgt i64 %t24, 2
  br i1 %t26, label %bb2, label %bb3
bb2:
  %t28 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr i8, ptr %t29, i64 0
  %t31 = load i8, ptr %t30, !tbaa !32
  %t33 = icmp eq i8 %t31, 48
  store i1 %t33, ptr %l13, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb4
bb4:
  %t35 = load i1, ptr %l13, !tbaa !21
  br i1 %t35, label %bb5, label %bb6
bb5:
  %t36 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr i8, ptr %t37, i64 1
  %t39 = load i8, ptr %t38, !tbaa !32
  %t41 = icmp eq i8 %t39, 120
  br i1 %t41, label %bb7, label %bb8
bb6:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb10
bb7:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb9
bb8:
  %t43 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr i8, ptr %t44, i64 1
  %t46 = load i8, ptr %t45, !tbaa !32
  %t48 = icmp eq i8 %t46, 88
  store i1 %t48, ptr %l19, !tbaa !21
  br label %bb9
bb9:
  %t50 = load i1, ptr %l19, !tbaa !21
  store i1 %t50, ptr %l16, !tbaa !21
  br label %bb10
bb10:
  %t51 = load i1, ptr %l16, !tbaa !21
  br i1 %t51, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s1
  %t52 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t52, 0
  store i64 %t54, ptr %l24, !tbaa !24
  %t55 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t55, 0
  store i64 %t56, ptr %l25, !tbaa !24
  %t57 = icmp sge i64 2, 0
  br i1 %t57, label %bb13, label %bb14
bb12:
  br label %bb24
bb13:
  %t59 = load i64, ptr %l24, !tbaa !24
  %t60 = icmp sle i64 2, %t59
  br i1 %t60, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_a6a8aee764c9772b_17fecb5b27ccad8f)
  unreachable
bb15:
  %t62 = load i64, ptr %l24, !tbaa !24
  %t63 = load i64, ptr %l25, !tbaa !24
  %t64 = icmp sle i64 %t62, %t63
  br i1 %t64, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_a6a8aee764c9772b_17fecb5b27ccad8f)
  unreachable
bb17:
  %t66 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !27
  %t68 = load i64, ptr %l24, !tbaa !24
  %t69 = getelementptr i8, ptr %t67, i64 2
  %t70 = sub i64 %t68, 2
  %t71 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t69, 1
  store { i64, ptr } %t72, ptr %l29, !tbaa !27
  %t73 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s1, i64 16)
  %t74 = extractvalue { i32, i64 } %t73, 1
  %t75 = extractvalue { i32, i64 } %t73, 0
  store i32 %t75, ptr %l31
  %t76 = icmp ne i32 %t75, 0
  br i1 %t76, label %bb20, label %ok.77, !prof !99
ok.77:
  store i64 %t74, ptr %l30
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_a6a8aee764c9772b_17fecb5b27ccad8f)
  unreachable
bb19:
  %t78 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t79 = load i64, ptr %l30, !tbaa !24
  %t80 = call { i32, i128 } @std_2fprelude_2ftext_2eT_2eParse_3cU128_3e(ptr %s0, { i64, ptr } %t78, i64 %t79)
  %t81 = extractvalue { i32, i128 } %t80, 1
  %t82 = extractvalue { i32, i128 } %t80, 0
  store i32 %t82, ptr %l34
  %t83 = icmp ne i32 %t82, 0
  br i1 %t83, label %bb22, label %ok.84, !prof !99
ok.84:
  store i128 %t81, ptr %l33
  br label %bb21
bb20:
  %t85 = load i32, ptr %l31, !tbaa !23
  %t86 = lshr i32 %t85, 16
  %t87 = and i32 %t85, 65535
  %t88 = icmp eq i32 %t86, 1
  %t89 = select i1 %t88, i32 0, i32 0
  %t90 = icmp eq i32 %t85, 0
  %t91 = shl i32 %t89, 16
  %t92 = or i32 %t91, %t87
  %t93 = select i1 %t90, i32 0, i32 %t92
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t95 = insertvalue { i32, i128 } zeroinitializer, i32 %t93, 0
  store { i32, i128 } %t95, ptr %rv
  br label %ret
bb21:
  %t96 = load i128, ptr %l33
  store i128 %t96, ptr %l22
  br label %bb23
bb22:
  %t97 = load i32, ptr %l34, !tbaa !23
  %t98 = lshr i32 %t97, 16
  %t99 = and i32 %t97, 65535
  %t100 = icmp eq i32 %t98, 1
  %t101 = select i1 %t100, i32 1, i32 0
  %t102 = icmp eq i32 %t97, 0
  %t103 = shl i32 %t101, 16
  %t104 = or i32 %t103, %t99
  %t105 = select i1 %t102, i32 0, i32 %t104
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t107 = insertvalue { i32, i128 } zeroinitializer, i32 %t105, 0
  store { i32, i128 } %t107, ptr %rv
  br label %ret
bb23:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t108 = load i128, ptr %l22
  %t109 = insertvalue { i32, i128 } zeroinitializer, i128 %t108, 1
  store { i32, i128 } %t109, ptr %rv
  br label %ret
bb24:
  %t110 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t110, 0
  %t114 = icmp sgt i64 %t112, 2
  br i1 %t114, label %bb25, label %bb26
bb25:
  %t116 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !27
  %t118 = getelementptr i8, ptr %t117, i64 0
  %t119 = load i8, ptr %t118, !tbaa !32
  %t121 = icmp eq i8 %t119, 48
  store i1 %t121, ptr %l39, !tbaa !21
  br label %bb27
bb26:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb27
bb27:
  %t123 = load i1, ptr %l39, !tbaa !21
  br i1 %t123, label %bb28, label %bb29
bb28:
  %t124 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr i8, ptr %t125, i64 1
  %t127 = load i8, ptr %t126, !tbaa !32
  %t129 = icmp eq i8 %t127, 98
  br i1 %t129, label %bb30, label %bb31
bb29:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb33
bb30:
  store i1 true, ptr %l45, !tbaa !21
  br label %bb32
bb31:
  %t131 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr i8, ptr %t132, i64 1
  %t134 = load i8, ptr %t133, !tbaa !32
  %t136 = icmp eq i8 %t134, 66
  store i1 %t136, ptr %l45, !tbaa !21
  br label %bb32
bb32:
  %t138 = load i1, ptr %l45, !tbaa !21
  store i1 %t138, ptr %l42, !tbaa !21
  br label %bb33
bb33:
  %t139 = load i1, ptr %l42, !tbaa !21
  br i1 %t139, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s2
  %t140 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t140, 0
  store i64 %t142, ptr %l50, !tbaa !24
  %t143 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t144 = extractvalue { i64, ptr } %t143, 0
  store i64 %t144, ptr %l51, !tbaa !24
  %t145 = icmp sge i64 2, 0
  br i1 %t145, label %bb36, label %bb37
bb35:
  br label %bb47
bb36:
  %t147 = load i64, ptr %l50, !tbaa !24
  %t148 = icmp sle i64 2, %t147
  br i1 %t148, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_8cde041b4e8c8e2e_cde163ca5cf5392)
  unreachable
bb38:
  %t150 = load i64, ptr %l50, !tbaa !24
  %t151 = load i64, ptr %l51, !tbaa !24
  %t152 = icmp sle i64 %t150, %t151
  br i1 %t152, label %bb40, label %bb41
bb39:
  call void @__olang_check_failed(ptr @olang_loc_8cde041b4e8c8e2e_cde163ca5cf5392)
  unreachable
bb40:
  %t154 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !27
  %t156 = load i64, ptr %l50, !tbaa !24
  %t157 = getelementptr i8, ptr %t155, i64 2
  %t158 = sub i64 %t156, 2
  %t159 = insertvalue { i64, ptr } undef, i64 %t158, 0
  %t160 = insertvalue { i64, ptr } %t159, ptr %t157, 1
  store { i64, ptr } %t160, ptr %l55, !tbaa !27
  %t161 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s2, i64 2)
  %t162 = extractvalue { i32, i64 } %t161, 1
  %t163 = extractvalue { i32, i64 } %t161, 0
  store i32 %t163, ptr %l57
  %t164 = icmp ne i32 %t163, 0
  br i1 %t164, label %bb43, label %ok.165, !prof !99
ok.165:
  store i64 %t162, ptr %l56
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_8cde041b4e8c8e2e_cde163ca5cf5392)
  unreachable
bb42:
  %t166 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t167 = load i64, ptr %l56, !tbaa !24
  %t168 = call { i32, i128 } @std_2fprelude_2ftext_2eT_2eParse_3cU128_3e(ptr %s0, { i64, ptr } %t166, i64 %t167)
  %t169 = extractvalue { i32, i128 } %t168, 1
  %t170 = extractvalue { i32, i128 } %t168, 0
  store i32 %t170, ptr %l60
  %t171 = icmp ne i32 %t170, 0
  br i1 %t171, label %bb45, label %ok.172, !prof !99
ok.172:
  store i128 %t169, ptr %l59
  br label %bb44
bb43:
  %t173 = load i32, ptr %l57, !tbaa !23
  %t174 = lshr i32 %t173, 16
  %t175 = and i32 %t173, 65535
  %t176 = icmp eq i32 %t174, 1
  %t177 = select i1 %t176, i32 0, i32 0
  %t178 = icmp eq i32 %t173, 0
  %t179 = shl i32 %t177, 16
  %t180 = or i32 %t179, %t175
  %t181 = select i1 %t178, i32 0, i32 %t180
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t183 = insertvalue { i32, i128 } zeroinitializer, i32 %t181, 0
  store { i32, i128 } %t183, ptr %rv
  br label %ret
bb44:
  %t184 = load i128, ptr %l59
  store i128 %t184, ptr %l48
  br label %bb46
bb45:
  %t185 = load i32, ptr %l60, !tbaa !23
  %t186 = lshr i32 %t185, 16
  %t187 = and i32 %t185, 65535
  %t188 = icmp eq i32 %t186, 1
  %t189 = select i1 %t188, i32 1, i32 0
  %t190 = icmp eq i32 %t185, 0
  %t191 = shl i32 %t189, 16
  %t192 = or i32 %t191, %t187
  %t193 = select i1 %t190, i32 0, i32 %t192
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t195 = insertvalue { i32, i128 } zeroinitializer, i32 %t193, 0
  store { i32, i128 } %t195, ptr %rv
  br label %ret
bb46:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t196 = load i128, ptr %l48
  %t197 = insertvalue { i32, i128 } zeroinitializer, i128 %t196, 1
  store { i32, i128 } %t197, ptr %rv
  br label %ret
bb47:
  %t198 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t198, ptr %l63, !tbaa !27
  %t199 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s0, i64 10)
  %t200 = extractvalue { i32, i64 } %t199, 1
  %t201 = extractvalue { i32, i64 } %t199, 0
  store i32 %t201, ptr %l65
  %t202 = icmp ne i32 %t201, 0
  br i1 %t202, label %bb49, label %ok.203, !prof !99
ok.203:
  store i64 %t200, ptr %l64
  br label %bb48
bb48:
  %t204 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t205 = load i64, ptr %l64, !tbaa !24
  %t206 = call { i32, i128 } @std_2fprelude_2ftext_2eT_2eParse_3cU128_3e(ptr %s0, { i64, ptr } %t204, i64 %t205)
  %t207 = extractvalue { i32, i128 } %t206, 1
  %t208 = extractvalue { i32, i128 } %t206, 0
  store i32 %t208, ptr %l68
  %t209 = icmp ne i32 %t208, 0
  br i1 %t209, label %bb51, label %ok.210, !prof !99
ok.210:
  store i128 %t207, ptr %l67
  br label %bb50
bb49:
  %t211 = load i32, ptr %l65, !tbaa !23
  %t212 = lshr i32 %t211, 16
  %t213 = and i32 %t211, 65535
  %t214 = icmp eq i32 %t212, 1
  %t215 = select i1 %t214, i32 0, i32 0
  %t216 = icmp eq i32 %t211, 0
  %t217 = shl i32 %t215, 16
  %t218 = or i32 %t217, %t213
  %t219 = select i1 %t216, i32 0, i32 %t218
  call void @__olang_scope_close(ptr %s0)
  %t221 = insertvalue { i32, i128 } zeroinitializer, i32 %t219, 0
  store { i32, i128 } %t221, ptr %rv
  br label %ret
bb50:
  %t222 = load i128, ptr %l67
  store i128 %t222, ptr %l62
  br label %bb52
bb51:
  %t223 = load i32, ptr %l68, !tbaa !23
  %t224 = lshr i32 %t223, 16
  %t225 = and i32 %t223, 65535
  %t226 = icmp eq i32 %t224, 1
  %t227 = select i1 %t226, i32 1, i32 0
  %t228 = icmp eq i32 %t223, 0
  %t229 = shl i32 %t227, 16
  %t230 = or i32 %t229, %t225
  %t231 = select i1 %t228, i32 0, i32 %t230
  call void @__olang_scope_close(ptr %s0)
  %t233 = insertvalue { i32, i128 } zeroinitializer, i32 %t231, 0
  store { i32, i128 } %t233, ptr %rv
  br label %ret
bb52:
  call void @__olang_scope_close(ptr %s0)
  %t234 = load i128, ptr %l62
  %t235 = insertvalue { i32, i128 } zeroinitializer, i128 %t234, 1
  store { i32, i128 } %t235, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i128 }, ptr %rv
  ret { i32, i128 } %rr
}

define dso_local %"compiler/check:tailAsk" @compiler_2fcheck_3atailAsk_2ector(ptr %v0, i64 %a0, i64 %a1, %"compiler/source:Span" %a2, i64 %a3) #0 {
entry:
  %rv = alloca %"compiler/check:tailAsk"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/check:tailAsk" undef, i64 %a0, 0
  %t12 = insertvalue %"compiler/check:tailAsk" %t10, i64 %a1, 1
  %t14 = insertvalue %"compiler/check:tailAsk" %t12, %"compiler/source:Span" %a2, 2
  %t16 = insertvalue %"compiler/check:tailAsk" %t14, i64 %a3, 3
  store %"compiler/check:tailAsk" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:tailAsk", ptr %rv
  ret %"compiler/check:tailAsk" %rr
}

declare void @__olang_check_failed(ptr) cold noreturn
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d0 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"SetAt" }>, align 8
@.d1 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"SetAt" }>, align 8
@.d2 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"'x[i] = v'" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@__olang_empty_array = external constant [16 x i64]
@.d3 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"a build constant without a value" }>, align 8
@.d4 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U64" }>, align 8
@.d5 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F64" }>, align 8
@.d6 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"a build constant of this kind (B10)" }>, align 8
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 4
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@.d7 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d8 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
@olang_2esole_2ecompiler_2fcheck_3aframe_2e4 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @__olang_region_or(ptr, ptr)
declare ptr @__olang_region_home(ptr)
declare void @__olang_region_settle(ptr, i1)
declare void @__olang_region_drop(ptr) noinline
declare ptr @__olang_scope_of(ptr, ptr) noinline
@.d9 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d10 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@olang_2esole_2ecompiler_2ftyped_3aClause_2e1 = weak hidden constant i1 false
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d11 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d12 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d13 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare i64 @__olang_fmt_i64(ptr, i64)
@.d14 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
define linkonce_odr %"compiler/check:weakPlace" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fcheck_3aweakPlace(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/check:weakPlace"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"compiler/check:weakPlace"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/check:weakPlace", ptr %a0
  store %"compiler/check:weakPlace" %t2, ptr %l1
  %t3 = getelementptr %"compiler/check:weakPlace", ptr %l1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 1
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"compiler/check:weakPlace", ptr %l1, i32 0, i32 1
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"compiler/check:weakPlace", ptr %l1
  store %"compiler/check:weakPlace" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:weakPlace", ptr %rv
  ret %"compiler/check:weakPlace" %rr
}

@.d15 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c" - it is not a numeric type" }>, align 8
@.d16 = private constant <{ i64, [93 x i8] }> <{ i64 0, [93 x i8] c" - a declared type has its base's limits only where it extends it and declares no constructor" }>, align 8
@.d17 = private constant <{ i64, [46 x i8] }> <{ i64 0, [46 x i8] c"Max, Min, Inf, NaN, Epsilon and SmallestNormal" }>, align 8
@.d18 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"Max and Min" }>, align 8
@.d19 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c" - its limits are " }>, align 8
@.d20 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"is a struct or an enum" }>, align 8
@.d21 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d22 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"a builder" }>, align 8
@olang_2esole_2ecompiler__2fcheck__2ecompiler__2fcheck__3aChecker__2ememberRules_2elocal_2e10 = weak hidden constant i1 false
declare void @__olang_region_release(ptr) noinline
@.d23 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@.d24 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"[]" }>, align 8
@.d25 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"Array<I64>[]" }>, align 8
@.d26 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"a part of a value made" }>, align 8
@.d27 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d28 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d29 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c" - declare 'fn (x " }>, align 8
@.d30 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c") Pow(y E) " }>, align 8
@.d31 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@olang_2esole_2ecompiler_2fcheck_3aChecker_2e61 = weak hidden constant i1 false
define linkonce_odr %"compiler/check:rangeIndex" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fcheck_3arangeIndex(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/check:rangeIndex"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"compiler/check:rangeIndex"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/check:rangeIndex", ptr %a0
  store %"compiler/check:rangeIndex" %t2, ptr %l1
  %t3 = getelementptr %"compiler/check:rangeIndex", ptr %l1, i32 0, i32 3
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 1
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"compiler/check:rangeIndex", ptr %l1, i32 0, i32 3
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"compiler/check:rangeIndex", ptr %l1
  store %"compiler/check:rangeIndex" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:rangeIndex", ptr %rv
  ret %"compiler/check:rangeIndex" %rr
}

@.d32 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"from its parts" }>, align 8
@.d33 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"with '" }>, align 8
@.d34 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c".Copy()'" }>, align 8
@.d35 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"with 'Copy()'" }>, align 8
@.d36 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"?" }>, align 8
@.d37 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d38 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
@.d39 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" or more" }>, align 8
@.d40 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d41 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" element" }>, align 8
@.d42 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"nothing" }>, align 8
@.d43 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d44 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"std/prelude/enums" }>, align 8
@.d45 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"CaseError" }>, align 8
@.d46 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"WrongCase" }>, align 8
@.d47 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Sum" }>, align 8
@.d48 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Min" }>, align 8
@.d49 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Max" }>, align 8
@.d50 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Some" }>, align 8
@.d51 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Every" }>, align 8
@.d52 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"LanesEqual" }>, align 8
@.d53 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"LanesLess" }>, align 8
@.d54 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Select" }>, align 8
@.d55 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d56 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare i1 @compiler_2fcheck_2eclosedAll(ptr %v0, { i64, ptr } %a0)
@olang_loc_317fdf139725c543_9c9e0109f99156f7 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBind_26_3e_2eLen_3ccompiler_2ftyped_3aBind_26_3e(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBind_26_3e_2eAt_3ccompiler_2ftyped_3aBind_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAltBindsOtherNames(ptr %v0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/diagmsg:Msg" %a2)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsHandle(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnyTableOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v1, ptr %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eNewAnyTable(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3, %"compiler/source:Span" %a4)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnyStored(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodSig(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i64 @compiler_2fgeneric_2eFnOwner(i64 %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eimplSig(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDefaultAt(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyScopesAgree(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAnyMethodScopes(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteAnyMethod(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoteAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, %"compiler/diagmsg:Msg" %a3)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnyTable_3e_2eRef_H0986089bcad3c266fbd2f46fa03b07d1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erecvReplaced(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2, i64 %a3, %"compiler/source:Span" %a4)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_2ector(ptr %v0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewantStr(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2, i64 %a3)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplace(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2, i64 %a3)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopAfter(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, %"compiler/source:Span" %a3, { i64, ptr } %a4, i64 %a5, i1 %a6)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eSetatUndeclared(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalueTemp(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewriteBack(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, ptr %a4, %"compiler/source:Span" %a5, i64 %a6, { i64, ptr } %a7)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eToArray_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_481df18796619d00_e450b1e3b67cd36c = external constant [0 x i8]
@olang_loc_af0d91289a1be42d_4e0f74b352066f9 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3, ptr %a4, { i64, ptr } %a5, { i64, ptr } %a6, { i64, ptr } %a7)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_490471cc9535e935_aa1636ccadcd0f9 = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aStmt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eReopen(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eblockOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2, %"compiler/source:Span" %a3)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i32, %"compiler/cond:Value" } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eValueOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %a0)
@G_2ecompiler_2ftypes_2eReadOnly = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalledNow(ptr %v0, ptr %a0)
@olang_loc_af34769fdf26b030_eb833745f3a45efc = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare %"compiler/typed:Call" @compiler_2ftyped_3aCall_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2, i1 %a3, i1 %a4)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eColumnsRow(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %a0, i32 %a1)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFieldNames(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2fcheck_2eRoStored = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroStore(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i64 %a3)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, i64 %a1, { i64, ptr } %a2, ptr %a3, i32 %a4, i32 %a5, i1 %a6)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, i32 %a4, { i64, [1 x i64] } %a5)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2ePush_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropOnExit(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, i1 %a3)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflDecide(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadsConst(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFoldKnown(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i32 %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_1e68dbdbde35cba9_f30fa4c89b16ec2d = external constant [0 x i8]
@olang_loc_af264802bedcf8d8_5deeb41ed3d90c7c = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_bc2b949bbef92b23_ac5d28fb0edf1ff = external constant [0 x i8]
@olang_loc_fc391d98a693d1b5_39c844f8cb4c6229 = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eArgCountRange(ptr %v0, i64 %a0, i64 %a1, i64 %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eArgCount(ptr %v0, ptr %v1, i64 %a0, { i64, ptr } %a1, i64 %a2)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, i32 %a3, i32 %a4)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceContext(ptr %out, ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_ff2084232290eae7_203579eb66e705cb = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %a0)
@olang_loc_7351608f8313d577_54e294ea81fa84bb = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_7e44f5428cde099f_6973e730479eef7b = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/check:litv" @compiler_2fcheck_3alitv_2ector(ptr %v0, i1 %a0, i1 %a1, i1 %a2, i64 %a3, double %a4)
declare i64 @compiler_2fcheck_2eintFloatBits(i32 %a0, %"compiler/check:litv" %a1)
declare i64 @compiler_2fcheck_2efloatBits(i32 %a0, double %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_eaffdf15d9c064d4_e1a7ee300abdca20 = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotCapture(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euncovered(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvWords(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1, i1 %a2)
@olang_loc_ce45aa27b33b13c4_efb6d2bad65aad00 = external constant [0 x i8]
declare %"compiler/typed:Clause" @compiler_2ftyped_3aClause_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, %"compiler/source:Span" %a0, { i64, ptr } %a1, i1 %a2, ptr %a3, { i64, ptr } %a4, i64 %a5, i32 %a6)
declare %"compiler/typed:Try" @compiler_2ftyped_3aTry_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i1 %a2, i1 %a3, i1 %a4)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenArgs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, { i64, ptr } %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenHolds(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2, i1 %a3)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fdiag_3aWhere_3e_2e_Had7920a3eff3220b2e12299d961f9124(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eweakWord(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fdiag_3aWhere_3e_2e_Hc07a7e56a24d8f1225398db99ea19a4b(ptr %v0, ptr %a0, i64 %a1, { i64, [3 x i64] } %a2)
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_H243102d099229a8f815a09f79cb8b122(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_H7dde68908c71339667eba96ae7e6565c(ptr %v0, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20Boo_H6b1fa5c8028973ecd947936aac3caef3(ptr %v0, ptr %a0, { i64, ptr } %a1, i1 %a2)
declare %"compiler/check:weakPlace" @compiler_2fcheck_3aweakPlace_2ector(ptr %v0, { i64, [3 x i64] } %a0, { i64, ptr } %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aweakPlace_3e_2ePush_H297ef57e7eecfa1bdb33767a82738378(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:weakPlace" %a1)
@olang_loc_99b065cd1779adaf_71b4842056cbdbfb = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aDeclId_3e_2ector(ptr %v0, i64 %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aDeclId_3e_2eLen_3ccompiler_2ftypes_3aDeclId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aDeclId_3e_2eAt_3ccompiler_2ftypes_3aDeclId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aDeclId_3e_2ePush_3ccompiler_2ftypes_3aDeclId_3e(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_fee5565d650674df_3b318d0e6ee4625b = external constant [0 x i8]
declare %"compiler/check:ownerAt" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eownerOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@G_2ecompiler_2fcheck_2eLaneScalar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElemOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneType(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2fcheck_2eLaneMagic = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\01\00\00" }>, align 8
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArray(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2fcheck_2eLaneArr = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/check:laneNode" @compiler_2fcheck_3alaneNode_2ector(ptr %v0, ptr %v1, i64 %a0, i32 %a1, %"compiler/source:Span" %a2, %"compiler/source:Span" %a3, i64 %a4, i64 %a5, i64 %a6, ptr %a7, i32 %a8, i64 %a9, i32 %a10)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneAdd(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:laneNode" %a1)
declare %"compiler/check:laneVals" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneSetup(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, ptr %a3, ptr %a4)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eTrunca_Hc8531d0d5535cc9766a27157f9c0b07c(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emustWrite(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i1 %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroDeepNeed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoLimit(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisOver(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2elimitIndex(ptr %v0, { i64, ptr } %a0)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, ptr %a4, ptr %a5)
declare i64 @compiler_2fcheck_2elimitBits(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@G_2ecompiler_2ftypes_2eNullT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\0F\00\00\00" }>, align 8
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArrayRef(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemptyArray(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNullToArray(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneverNull(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNullToNonNull(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclNote(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etyOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMatchValueTypes(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMemberAt(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMemberOwnerRef(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMemberInPlaceKind(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ememberOwnerOk(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, { i64, ptr } %a3)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMemberName(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamespaceTaken(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflectedName(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBuilderOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i1 %a3)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare %"compiler/source:Span" @compiler_2fcheck_2ememberSpan(%"compiler/source:Span" %a0, i64 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMemberNameTaken(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMemberBefore(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMemberTwice(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/msgs:Nearest" @compiler_2fmsgs_3aNearest_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eOffer(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNamedArgUnknownMeant(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNamedArgUnknown(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_aca5fbea7f148a0b_8298f5f4d8f3acbf = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseNarrowing(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowedField(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowPath(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"compiler/check:narrowed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eAt_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epathRead(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, { i64, ptr } %a3)
@olang_loc_e6a66df527b36ded_181f8bf364cc8869 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_Hda4ef06466535e66801340e999dad217(ptr %v0, ptr %a0)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_H87a29777ccf22aa2985fa9d3c61f9cd3(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %a0)
@olang_loc_eb65b3680edb0345_685145072e457a11 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalDeps(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_becd3eb77e076db3_2d856a700a1e74b7 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eIndexOf_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aCycle(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i64 %a3)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLiteralNoTarget(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eentryAt(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eownMap(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
@olang_loc_78b67e7b86d014f7_b202530d028f16d3 = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eownElem(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erowsOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunArrayValue(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elayRows(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, { i64, ptr } %a3, { i64, ptr } %a4, i1 %a5)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleItem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i32 %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2fgeneric_2eDescFunc = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorParams(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueMoved(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueLand(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, i1 %a3)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnsParts(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eownCopy(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare ptr @compiler_2fcheck_2eexprPath(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCaughtCaseForm(ptr %v0)
declare { i64, i32 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrorWord(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eWordFields(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordText(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePlainWordCalled(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePayloadArgs(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i64 %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eErrPatternNeedsName(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epayloadItems(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3apayloadItem_3e_2eLe_Hf8109b64a4e45220d0da36a987cf38b1(ptr %v0, ptr %a0)
declare %"compiler/check:payloadItem" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3apayloadItem_3e_2eAt_H64f851f610dd8566f1d7651b626ec99d(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epayloadItemOk(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i32 %a3, i64 %a4, { i64, ptr } %a5, i64 %a6, ptr %a7, i64 %a8)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epayloadRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epowMethod(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePowNone(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_40ba663ddc86f216_8a32628f26d9e82 = external constant [0 x i8]
@olang_loc_e2e10646092ca22b_113878b4617d7337 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eProtocolPrivate(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorOncePerLine(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/diagmsg:Msg" %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprovenInt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eIndexProven(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i64 %a2)
declare %"compiler/check:knownRange" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erangeOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare %"compiler/check:rangeIndex" @compiler_2fcheck_3arangeIndex_2ector(ptr %v0, i64 %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, { i64, ptr } %a3, i64 %a4, i64 %a5)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3arangeIndex_3e_2ePus_Hb04e4a892496cc754693e16cdaa43e26(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:rangeIndex" %a1)
declare %"compiler/typed:Elem" @compiler_2ftyped_3aElem_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare %"compiler/typed:Payload" @compiler_2ftyped_3aPayload_2ector(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
@olang_loc_d14fb46e4520a903_82d87293fe98a067 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrVarAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMeetsBound(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i32 %a3, i32 %a4)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInferThroughBounds(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyOfCallee(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceBody(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroByArg(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroFollows(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclaresCopy(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efirstUncovered(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMatchNotExhaustive(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMembers(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eIndexOf_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eseqColumn(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eseqUncovered(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eseqLongest(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMatchLengthUncovered(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMatchValueUncovered(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fscan_2eLiteralBytes(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/generic:Binding" @compiler_2fgeneric_3aBinding_2ector(ptr %v0, i64 %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnifyBound(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSubst(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i32 %a3)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSatisfies(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnify(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3, i1 %a4, i1 %a5)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epatternNames(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i1 %a3)
declare %"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa" @std_2fpair_3aPair_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2ector(ptr %v0, i32 %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__Habcf70cf374eb3bb03a96803ac10570d(ptr %v0, ptr %a0, %"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa" %a1)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emarkAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
@olang_loc_cd70ff81a8aaff09_d672b27f0a953c3d = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecaseDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenericNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_dcc186c1d376e3fb_9ec0343880193f07 = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epreludeWord(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
@olang_loc_20f9f67d26588f89_c77aed4cf9eaedd5 = external constant [0 x i8]
@olang_loc_c65b3104d639b10f_156ca11db7f6d433 = external constant [0 x i8]
@olang_loc_489f62f877911e0f_f9fedbe42e1f3c23 = external constant [0 x i8]
@olang_loc_679df2ab066560af_73bde1caf560602b = external constant [0 x i8]
declare %"compiler/check:litv" @compiler_2fcheck_2elitv_2eintLit(i64 %a0)
declare %"compiler/check:litv" @compiler_2fcheck_2elitv_2ewideLit(i1 %a0, i128 %a1)
declare %"compiler/check:litv" @compiler_2fcheck_2elitv_2enoLit()
@olang_loc_3bef89c29375057e_93446d82378ce1ba = external constant [0 x i8]
declare i1 @compiler_2fcheck_2eexistingValue(ptr %v0, ptr %a0)
@olang_loc_f9ce4d996cc4e225_93403f8f2ddbd541 = external constant [0 x i8]
@olang_loc_55e43ab8a3145b19_623cb1abd394c54d = external constant [0 x i8]
declare i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2eexprsAssign(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2ehitsPath(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2eclausesAssign(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2eifAssigns(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2eassignsName(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2ematchAssigns(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_3f7a94628940c729_cdb98f41ead125dd = external constant [0 x i8]
declare void @compiler_2fcheck_2estoredIn(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1)
declare void @compiler_2fcheck_2estoredExprs(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1)
@olang_loc_fa22773c0ed7d28e_9744d977b6aff1d2 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
@olang_loc_a6a8aee764c9772b_17fecb5b27ccad8f = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i32, i128 } @std_2fprelude_2ftext_2eT_2eParse_3cU128_3e(ptr %v0, { i64, ptr } %a0, i64 %a1)
@olang_loc_8cde041b4e8c8e2e_cde163ca5cf5392 = external constant [0 x i8]
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
