; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, { i64, [2 x i64] }, i32, i1, i1 }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/check:frame" = type { i64, i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/generic:Context", i32, i32, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i32, i64, i64, i64, i1, i64, i1, i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, i64, i64, i64, i1, i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", i64, i1 }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/generic:Context" = type { i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i64, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, { i64, [3 x i64] }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i32, i64, %"compiler/source:Span", i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i64, i64, i64, i64, i64, i64, i64, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i1, i1, %"std/prelude/text:StringBuilder", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i32, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/typed:ContractInfo" = type { { i64, ptr }, i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/check:ctSource" = type { ptr, ptr, { i64, ptr }, i64, { i64, ptr } }
%"compiler/ast:ContractBlock" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/ast:TopIf" = type { ptr, ptr, ptr, ptr }
%"compiler/ast:TopBranch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr }
%"compiler/check:b5aWalk" = type { i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1 }
%"compiler/ast:Match" = type { %"compiler/source:Span", ptr, i1, { i64, ptr } }
%"compiler/ast:Case" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, ptr }
%"compiler/check:reflList" = type { i1, i32, i64, i64 }
%"compiler/generic:Desc" = type { i64, i32, i64, i64 }
%"compiler/check:litv" = type { i1, i1, i1, i64, double, i1, i1, i1, i128 }
%"compiler/generic:AnySlot" = type { i32, i32, i64, i64, i1, i32 }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, { i64, ptr } }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr, { i64, ptr } }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [2 x i64] }, i1 }
%"std/pair:Pair.1eb2466213689e002f25e81e83536e78" = type { i64, ptr }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"compiler/check:AssertAsk" = type { i64, i64, %"compiler/source:Span", %"compiler/source:Span", i64, i64, i1, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, [3 x i64] }, { i64, ptr } }
%"compiler/check:nullNarrow" = type { { i64, ptr }, i64, i1 }
%"compiler/check:narrowed" = type { i64, i64, i32, i64, i64, i1 }
%"compiler/check:errNarrow" = type { i32, i32, i64, i1 }
%"compiler/typed:Bind" = type { i32, ptr }
%"compiler/typed:Text" = type { { i64, ptr }, i32 }
%"compiler/ast:ForIn" = type { i32, i32, ptr, i1, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/check:unsetCand" = type { i64, i64, i64, i1, i64, %"compiler/source:Span", i32, i1 }
%"compiler/check:fixedInit" = type { ptr, i32 }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1, { i64, ptr }, i1 }
%"compiler/ast:CaseDecl" = type { %"compiler/source:Span", i32, { i64, ptr }, i1, ptr, { i64, ptr } }
%"compiler/check:factsMark" = type { i64, i64, i64 }
define dso_local i1 @compiler_2fcheck_2ebadSeparator(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l12 = alloca i64
  %l15 = alloca i64
  %l33 = alloca { i64, ptr }
  %l39 = alloca i1
  %l46 = alloca { i64, ptr }
  %l50 = alloca i1
  %l52 = alloca i1
  %l53 = alloca { i64, ptr }
  %l57 = alloca i1
  %l60 = alloca { i64, ptr }
  %l64 = alloca i1
  %l66 = alloca i1
  %l67 = alloca { i64, ptr }
  %l71 = alloca i1
  %l76 = alloca i1
  %l77 = alloca { i64, ptr }
  %l82 = alloca i1
  %l83 = alloca { i64, ptr }
  %l88 = alloca i1
  %l91 = alloca i1
  %l92 = alloca { i64, ptr }
  %l97 = alloca i1
  %l98 = alloca { i64, ptr }
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  %t6 = load i64, ptr %l1, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l3, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l12, !tbaa !24
  br label %bb6
bb3:
  %t15 = load i64, ptr %l2, !tbaa !24
  %t16 = load i64, ptr %l1, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l3, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l3, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l15, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb5
bb5:
  %t31 = load i64, ptr %l15, !tbaa !24
  store i64 %t31, ptr %l12, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l12, !tbaa !24
  store i64 %t32, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb7
bb7:
  %t33 = load i64, ptr %l5, !tbaa !24
  %t34 = load i64, ptr %l4, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  br label %bb55
bb9:
  br label %bb10
bb10:
  %t41 = load i64, ptr %l1, !tbaa !24
  %t42 = load i64, ptr %l5, !tbaa !24
  %t43 = load i64, ptr %l3, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l6, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t51, ptr %l33, !tbaa !27
  %t52 = load i64, ptr %l6, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr i8, ptr %t55, i64 %t52
  %t57 = load i8, ptr %t56, !tbaa !32
  %t59 = icmp ne i8 %t57, 95
  br i1 %t59, label %bb11, label %bb12
bb11:
  br label %bb54
bb12:
  br label %bb13
bb13:
  %t61 = load i64, ptr %l6, !tbaa !24
  %t63 = icmp eq i64 %t61, 0
  br i1 %t63, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb16
bb15:
  %t65 = load i64, ptr %l6, !tbaa !24
  %t67 = add i64 %t65, 1
  %t68 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t68, 0
  %t73 = icmp sge i64 %t67, %t70
  store i1 %t73, ptr %l39, !tbaa !21
  br label %bb16
bb16:
  %t75 = load i1, ptr %l39, !tbaa !21
  br i1 %t75, label %bb17, label %bb18
bb17:
  store i1 true, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t77 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t77, ptr %l46, !tbaa !27
  %t78 = load i64, ptr %l6, !tbaa !24
  %t80 = sub i64 %t78, 1
  %t82 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr i8, ptr %t83, i64 %t80
  %t85 = load i8, ptr %t84, !tbaa !32
  %t87 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t85)
  store i1 %t87, ptr %l50
  br label %bb20
bb20:
  %t88 = load i1, ptr %l50, !tbaa !21
  %t89 = xor i1 %t88, true
  br i1 %t89, label %bb21, label %bb22
bb21:
  %t91 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t91, ptr %l53, !tbaa !27
  %t92 = load i64, ptr %l6, !tbaa !24
  %t94 = sub i64 %t92, 1
  %t96 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = getelementptr i8, ptr %t97, i64 %t94
  %t99 = load i8, ptr %t98, !tbaa !32
  %t101 = call i1 @compiler_2fcheck_2eisHexDigit(i8 %t99)
  store i1 %t101, ptr %l57
  br label %bb23
bb22:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb24
bb23:
  %t102 = load i1, ptr %l57, !tbaa !21
  %t103 = xor i1 %t102, true
  store i1 %t103, ptr %l52, !tbaa !21
  br label %bb24
bb24:
  %t105 = load i1, ptr %l52, !tbaa !21
  br i1 %t105, label %bb25, label %bb26
bb25:
  store i1 true, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t107 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t107, ptr %l60, !tbaa !27
  %t108 = load i64, ptr %l6, !tbaa !24
  %t110 = add i64 %t108, 1
  %t112 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr i8, ptr %t113, i64 %t110
  %t115 = load i8, ptr %t114, !tbaa !32
  %t117 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t115)
  store i1 %t117, ptr %l64
  br label %bb28
bb28:
  %t118 = load i1, ptr %l64, !tbaa !21
  %t119 = xor i1 %t118, true
  br i1 %t119, label %bb29, label %bb30
bb29:
  %t121 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t121, ptr %l67, !tbaa !27
  %t122 = load i64, ptr %l6, !tbaa !24
  %t124 = add i64 %t122, 1
  %t126 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = getelementptr i8, ptr %t127, i64 %t124
  %t129 = load i8, ptr %t128, !tbaa !32
  %t131 = call i1 @compiler_2fcheck_2eisHexDigit(i8 %t129)
  store i1 %t131, ptr %l71
  br label %bb31
bb30:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb32
bb31:
  %t132 = load i1, ptr %l71, !tbaa !21
  %t133 = xor i1 %t132, true
  store i1 %t133, ptr %l66, !tbaa !21
  br label %bb32
bb32:
  %t135 = load i1, ptr %l66, !tbaa !21
  br i1 %t135, label %bb33, label %bb34
bb33:
  store i1 true, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  %t137 = load i64, ptr %l6, !tbaa !24
  %t139 = icmp sge i64 %t137, 2
  br i1 %t139, label %bb36, label %bb37
bb36:
  %t141 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t141, ptr %l77, !tbaa !27
  %t142 = load i64, ptr %l6, !tbaa !24
  %t144 = sub i64 %t142, 1
  %t146 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = getelementptr i8, ptr %t147, i64 %t144
  %t149 = load i8, ptr %t148, !tbaa !32
  %t151 = icmp eq i8 %t149, 120
  store i1 %t151, ptr %l76, !tbaa !21
  br label %bb38
bb37:
  store i1 false, ptr %l76, !tbaa !21
  br label %bb38
bb38:
  %t153 = load i1, ptr %l76, !tbaa !21
  br i1 %t153, label %bb39, label %bb40
bb39:
  %t154 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t154, ptr %l83, !tbaa !27
  %t155 = load i64, ptr %l6, !tbaa !24
  %t157 = sub i64 %t155, 2
  %t159 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !27
  %t161 = getelementptr i8, ptr %t160, i64 %t157
  %t162 = load i8, ptr %t161, !tbaa !32
  %t164 = icmp eq i8 %t162, 48
  store i1 %t164, ptr %l82, !tbaa !21
  br label %bb41
bb40:
  store i1 false, ptr %l82, !tbaa !21
  br label %bb41
bb41:
  %t166 = load i1, ptr %l82, !tbaa !21
  br i1 %t166, label %bb42, label %bb43
bb42:
  store i1 true, ptr %l88, !tbaa !21
  br label %bb50
bb43:
  %t167 = load i64, ptr %l6, !tbaa !24
  %t169 = icmp sge i64 %t167, 2
  br i1 %t169, label %bb44, label %bb45
bb44:
  %t171 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t171, ptr %l92, !tbaa !27
  %t172 = load i64, ptr %l6, !tbaa !24
  %t174 = sub i64 %t172, 1
  %t176 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = getelementptr i8, ptr %t177, i64 %t174
  %t179 = load i8, ptr %t178, !tbaa !32
  %t181 = icmp eq i8 %t179, 98
  store i1 %t181, ptr %l91, !tbaa !21
  br label %bb46
bb45:
  store i1 false, ptr %l91, !tbaa !21
  br label %bb46
bb46:
  %t183 = load i1, ptr %l91, !tbaa !21
  br i1 %t183, label %bb47, label %bb48
bb47:
  %t184 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t184, ptr %l98, !tbaa !27
  %t185 = load i64, ptr %l6, !tbaa !24
  %t187 = sub i64 %t185, 2
  %t189 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !27
  %t191 = getelementptr i8, ptr %t190, i64 %t187
  %t192 = load i8, ptr %t191, !tbaa !32
  %t194 = icmp eq i8 %t192, 48
  store i1 %t194, ptr %l97, !tbaa !21
  br label %bb49
bb48:
  store i1 false, ptr %l97, !tbaa !21
  br label %bb49
bb49:
  %t196 = load i1, ptr %l97, !tbaa !21
  store i1 %t196, ptr %l88, !tbaa !21
  br label %bb50
bb50:
  %t197 = load i1, ptr %l88, !tbaa !21
  br i1 %t197, label %bb51, label %bb52
bb51:
  store i1 true, ptr %rv
  br label %ret
bb52:
  br label %bb53
bb53:
  br label %bb54
bb54:
  %t199 = load i64, ptr %l5, !tbaa !24
  %t201 = add i64 %t199, 1
  store i64 %t201, ptr %l5, !tbaa !24
  br label %bb7
bb55:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2eclosedCall(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l22 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Call", ptr %t1, i32 0, i32 4
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/typed:Call", ptr %t6, i32 0, i32 2
  %t9 = load { i64, [2 x i64] }, ptr %t8
  %t11 = extractvalue { i64, [2 x i64] } %t9, 0
  %t12 = icmp eq i64 %t11, 0
  %t14 = xor i1 %t12, true
  store i1 %t14, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  %t16 = load i1, ptr %l4, !tbaa !21
  br i1 %t16, label %bb4, label %bb5
bb4:
  store i1 false, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/typed:Call", ptr %t18, i32 0, i32 0
  %t21 = load ptr, ptr %t20, !tbaa !29
  store ptr %t21, ptr %l1, !tbaa !29
  %t23 = load ptr, ptr %l1, !tbaa !29
  store ptr %t23, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t24 = load ptr, ptr %l12, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb7, label %bb8
bb7:
  %t27 = load ptr, ptr %l12, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 5}
  %t30 = icmp eq i64 %t28, 0
  store i1 %t30, ptr %l13, !tbaa !21
  br label %bb8
bb8:
  %t31 = load i1, ptr %l13, !tbaa !21
  br i1 %t31, label %bb9, label %bb10
bb9:
  br label %bb15
bb10:
  %t32 = load ptr, ptr %l1, !tbaa !29
  store ptr %t32, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t33 = load ptr, ptr %l16, !tbaa !29
  %t34 = icmp ne ptr %t33, null
  br i1 %t34, label %bb11, label %bb12
bb11:
  %t36 = load ptr, ptr %l16, !tbaa !29
  %t37 = load i64, ptr %t36, !range !{i64 0, i64 5}
  %t39 = icmp eq i64 %t37, 4
  store i1 %t39, ptr %l17, !tbaa !21
  br label %bb12
bb12:
  %t40 = load i1, ptr %l17, !tbaa !21
  br i1 %t40, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/typed:Call", ptr %t41, i32 0, i32 1
  %t44 = load { i64, ptr }, ptr %t43, !tbaa !27
  %t46 = call i1 @compiler_2fcheck_2eclosedAll(ptr %v0, { i64, ptr } %t44)
  store i1 %t46, ptr %l22
  br label %bb16
bb16:
  %t47 = load i1, ptr %l22, !tbaa !21
  store i1 %t47, ptr %rv
  br label %ret
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  store i1 false, ptr %rv
  br label %ret
bb21:
  call void @__olang_check_failed(ptr @olang_loc_317fdf139725c543_9c9e0109f99156f7)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eattrExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l8 = alloca ptr
  %l11 = alloca i64
  %l14 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l38 = alloca %"compiler/source:Span"
  %l41 = alloca i32
  %l43 = alloca ptr
  %l47 = alloca %"compiler/typed:Try"
  %rv = alloca ptr
  %t90 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l8
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l8, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t5, i32 0, i32 26
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l11
  br label %bb2
bb2:
  %t10 = load i64, ptr %l11, !tbaa !24
  store i64 %t10, ptr %l3, !tbaa !24
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t13 = getelementptr %"compiler/check:frame", ptr %t11, i32 0, i32 16
  %t14 = load i64, ptr %t13, !tbaa !24
  store i64 %t14, ptr %l4, !tbaa !24
  %t16 = load ptr, ptr %l2, !tbaa !29
  store ptr %t16, ptr %l14, !tbaa !29
  %t17 = load ptr, ptr %l14, !tbaa !29
  %t18 = getelementptr %"compiler/check:frame", ptr %t17, i32 0, i32 15
  %t19 = load i64, ptr %t18, !tbaa !24
  %t21 = add i64 %t19, 1
  %t23 = load ptr, ptr %l14, !tbaa !29
  %t24 = getelementptr %"compiler/check:frame", ptr %t23, i32 0, i32 15
  store i64 %t21, ptr %t24, !tbaa !24
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t28 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t32 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t25, ptr %t26, i32 %t28)
  store ptr %t32, ptr %l21
  br label %bb3
bb3:
  %t33 = load ptr, ptr %l21, !tbaa !29
  store ptr %t33, ptr %l5, !tbaa !29
  %t34 = load ptr, ptr %l2, !tbaa !29
  store ptr %t34, ptr %l22, !tbaa !29
  %t35 = load ptr, ptr %l22, !tbaa !29
  %t36 = getelementptr %"compiler/check:frame", ptr %t35, i32 0, i32 15
  %t37 = load i64, ptr %t36, !tbaa !24
  %t39 = sub i64 %t37, 1
  %t41 = load ptr, ptr %l22, !tbaa !29
  %t42 = getelementptr %"compiler/check:frame", ptr %t41, i32 0, i32 15
  store i64 %t39, ptr %t42, !tbaa !24
  %t43 = load ptr, ptr %l2, !tbaa !29
  %t45 = getelementptr %"compiler/check:frame", ptr %t43, i32 0, i32 16
  %t46 = load i64, ptr %t45, !tbaa !24
  %t47 = load i64, ptr %l4, !tbaa !24
  %t50 = icmp ne i64 %t46, %t47
  %t52 = load ptr, ptr %l2, !tbaa !29
  %t53 = load i64, ptr %l4, !tbaa !24
  %t56 = getelementptr %"compiler/check:frame", ptr %t52, i32 0, i32 16
  store i64 %t53, ptr %t56, !tbaa !24
  %t59 = xor i1 %t50, true
  br i1 %t59, label %bb4, label %bb5
bb4:
  %t61 = load ptr, ptr %l5, !tbaa !29
  store ptr %t61, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t63 = load ptr, ptr %l2, !tbaa !29
  %t65 = getelementptr %"compiler/check:frame", ptr %t63, i32 0, i32 26
  %t66 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eTruncate_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t65, i64 %t66)
  br label %bb7
bb7:
  %t69 = load ptr, ptr %l1, !tbaa !29
  %t71 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t69)
  store %"compiler/source:Span" %t71, ptr %l38
  br label %bb8
bb8:
  %t72 = load ptr, ptr %l5, !tbaa !29
  %t75 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t72)
  store i32 %t75, ptr %l41
  br label %bb9
bb9:
  %t76 = load ptr, ptr %l5, !tbaa !29
  store ptr %t76, ptr %l43, !tbaa !29
  %t78 = icmp sge i64 0, 0
  br i1 %t78, label %bb10, label %bb11
bb10:
  %t80 = icmp sle i64 0, 1152921504606846975
  br i1 %t80, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_ca088269e212954c_d643913a2551dac8)
  unreachable
bb12:
  %t82 = mul i64 0, 8
  %t83 = insertvalue { i64, ptr } undef, i64 0, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t85 = load ptr, ptr %l43, !tbaa !29
  %t87 = call %"compiler/typed:Try" @compiler_2ftyped_3aTry_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %t85, { i64, ptr } %t84, i1 true, i1 false, i1 true)
  store %"compiler/typed:Try" %t87, ptr %l47
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_ca088269e212954c_d643913a2551dac8)
  unreachable
bb14:
  %t88 = load %"compiler/typed:Try", ptr %l47
  %t89 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/typed:Try" %t88, ptr %t89
  store { i64, [5 x i64] } zeroinitializer, ptr %t90
  %t91 = getelementptr { i64, [5 x i64] }, ptr %t90, i32 0, i32 0
  store i64 14, ptr %t91
  %t92 = load %"compiler/source:Span", ptr %l38
  %t93 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t92, 0
  %t94 = load i32, ptr %l41, !tbaa !23
  %t95 = insertvalue { %"compiler/source:Span", i32, ptr } %t93, i32 %t94, 1
  %t97 = insertvalue { %"compiler/source:Span", i32, ptr } %t95, ptr %t89, 2
  %t98 = getelementptr { i64, [5 x i64] }, ptr %t90, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t97, ptr %t98
  %t99 = load { i64, [5 x i64] }, ptr %t90
  %t101 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t99, ptr %t101
  store ptr %t101, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aHoldsAny(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l14 = alloca { i64, ptr }
  %l21 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t15, ptr %l14, !tbaa !27
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i32, ptr %t19, i64 %t16
  %t21 = load i32, ptr %t20, !tbaa !33
  %t27 = add i64 %a2, 1
  %t31 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aHoldsFn(ptr %v0, ptr %a0, i32 %t21, i64 %t27)
  store i1 %t31, ptr %l21
  br label %bb5
bb5:
  %t32 = load i1, ptr %l21, !tbaa !21
  br i1 %t32, label %bb6, label %bb7
bb6:
  store i1 true, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t34 = load i64, ptr %l4, !tbaa !24
  %t36 = add i64 %t34, 1
  store i64 %t36, ptr %l4, !tbaa !24
  br label %bb1
bb10:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyErrors(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l8 = alloca ptr
  %l11 = alloca i1
  %l15 = alloca i1
  %l16 = alloca i32
  %l22 = alloca i32
  %l26 = alloca i64
  %l33 = alloca i64
  %l35 = alloca i32
  %l39 = alloca i32
  %l40 = alloca i32
  %l41 = alloca i1
  %l45 = alloca i1
  %l46 = alloca i32
  %l48 = alloca ptr
  %l49 = alloca i64
  %l54 = alloca { i64, ptr }
  %l56 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l59 = alloca i32
  %l61 = alloca ptr
  %l64 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l65 = alloca i32
  %l66 = alloca i32
  %l68 = alloca ptr
  %l69 = alloca i64
  %l74 = alloca { i64, ptr }
  %l76 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 12
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l8
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l8, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 2
  %t11 = load i32, ptr %t10, !tbaa !23
  store i32 %t11, ptr %l2, !tbaa !23
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 53
  %t16 = load i64, ptr %l1, !tbaa !24
  %t19 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eGet_3cI64_2c_20Bool_3e(ptr %v0, ptr %t15, i64 %t16)
  %t20 = extractvalue { i32, i1 } %t19, 1
  %t21 = extractvalue { i32, i1 } %t19, 0
  store i32 %t21, ptr %l16
  %t22 = icmp ne i32 %t21, 0
  br i1 %t22, label %bb3, label %ok.23, !prof !99
ok.23:
  store i1 %t20, ptr %l15
  br label %bb2
bb2:
  %t24 = load i1, ptr %l15, !tbaa !21
  store i1 %t24, ptr %l11, !tbaa !21
  br label %bb5
bb3:
  br label %bb4
bb4:
  call void @__olang_ert_req_clear()
  store i1 false, ptr %l11, !tbaa !21
  br label %bb5
bb5:
  %t25 = load i1, ptr %l11, !tbaa !21
  %t26 = xor i1 %t25, true
  br i1 %t26, label %bb6, label %bb7
bb6:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/generic:Program", ptr %t31, i32 0, i32 2
  %t34 = load i32, ptr %l2, !tbaa !23
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t33, i32 %t34)
  store i32 %t37, ptr %l22
  br label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t38 = load i32, ptr %l22, !tbaa !23
  store i32 %t38, ptr %rv
  br label %ret
bb9:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/check:Checker", ptr %t39, i32 0, i32 17
  %t42 = load i64, ptr %l1, !tbaa !24
  %t45 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t41, i64 %t42)
  store i64 %t45, ptr %l26
  br label %bb10
bb10:
  %t46 = load i64, ptr %l26, !tbaa !24
  %t47 = icmp eq i64 %t46, 0
  br i1 %t47, label %bb11, label %bb12
bb11:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckNow(ptr %v0, ptr %t49, i64 %t50)
  br label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb14
bb14:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/check:Checker", ptr %t53, i32 0, i32 17
  %t56 = load i64, ptr %l1, !tbaa !24
  %t59 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t55, i64 %t56)
  store i64 %t59, ptr %l33
  br label %bb15
bb15:
  %t60 = load i64, ptr %l33, !tbaa !24
  %t61 = icmp eq i64 %t60, 2
  br i1 %t61, label %bb16, label %bb17
bb16:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 54
  %t66 = load i64, ptr %l1, !tbaa !24
  %t69 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aListId_3e__H9cb5d99387f926677a92c13412f9a8b2(ptr %v0, ptr %t65, i64 %t66)
  %t70 = extractvalue { i32, i32 } %t69, 1
  %t71 = extractvalue { i32, i32 } %t69, 0
  store i32 %t71, ptr %l40
  %t72 = icmp ne i32 %t71, 0
  br i1 %t72, label %bb19, label %ok.73, !prof !99
ok.73:
  store i32 %t70, ptr %l39
  br label %bb18
bb17:
  br label %bb33
bb18:
  %t74 = load i32, ptr %l39, !tbaa !23
  store i32 %t74, ptr %l35, !tbaa !23
  br label %bb21
bb19:
  br label %bb20
bb20:
  call void @__olang_ert_req_clear()
  store i32 0, ptr %l35, !tbaa !23
  br label %bb21
bb21:
  %t75 = load i32, ptr %l35, !tbaa !23
  store i32 %t75, ptr %l3, !tbaa !23
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/check:Checker", ptr %t76, i32 0, i32 56
  %t79 = load i64, ptr %l1, !tbaa !24
  %t82 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eGet_3cI64_2c_20Bool_3e(ptr %v0, ptr %t78, i64 %t79)
  %t83 = extractvalue { i32, i1 } %t82, 1
  %t84 = extractvalue { i32, i1 } %t82, 0
  store i32 %t84, ptr %l46
  %t85 = icmp ne i32 %t84, 0
  br i1 %t85, label %bb23, label %ok.86, !prof !99
ok.86:
  store i1 %t83, ptr %l45
  br label %bb22
bb22:
  %t87 = load i1, ptr %l45, !tbaa !21
  store i1 %t87, ptr %l41, !tbaa !21
  br label %bb25
bb23:
  br label %bb24
bb24:
  call void @__olang_ert_req_clear()
  store i1 false, ptr %l41, !tbaa !21
  br label %bb25
bb25:
  %t88 = load i1, ptr %l41, !tbaa !21
  br i1 %t88, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s4
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/check:Checker", ptr %t89, i32 0, i32 55
  store ptr %t91, ptr %l48, !tbaa !29
  %t92 = load i64, ptr %l1, !tbaa !24
  store i64 %t92, ptr %l49, !tbaa !24
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/check:Checker", ptr %t93, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t98 = getelementptr %"compiler/generic:Program", ptr %t96, i32 0, i32 2
  %t99 = load i32, ptr %l3, !tbaa !23
  %t102 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t98, i32 %t99)
  store { i64, ptr } %t102, ptr %l54
  br label %bb28
bb27:
  br label %bb32
bb28:
  %t103 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t103, 0
  %t105 = load i64, ptr %l49, !tbaa !24
  %t107 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s4, i64 %t105, i64 %t104)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t107, ptr %l56
  br label %bb29
bb29:
  %t108 = load ptr, ptr %l48, !tbaa !29
  %t109 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l56
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_H2474e1fc3c93452d7765e4ed18f29a03(ptr %v0, ptr %t108, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t109)
  br label %bb30
bb30:
  %t110 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunsettle(ptr %v0, ptr %t110)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s4)
  br label %bb32
bb32:
  %t112 = load i32, ptr %l3, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t112, ptr %rv
  br label %ret
bb33:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/check:Checker", ptr %t114, i32 0, i32 57
  store ptr %t116, ptr %l61, !tbaa !29
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load i64, ptr %l1, !tbaa !24
  %t121 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyKey(ptr %v0, ptr %t117, i64 %t118)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t121, ptr %l64
  br label %bb34
bb34:
  %t122 = load ptr, ptr %l61, !tbaa !29
  %t123 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l64
  %t124 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hf3bb75ba9d3f922b4d327e9d3c1adfb0(ptr %v0, ptr %t122, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t123)
  %t125 = extractvalue { i32, i32 } %t124, 1
  %t126 = extractvalue { i32, i32 } %t124, 0
  store i32 %t126, ptr %l66
  %t127 = icmp ne i32 %t126, 0
  br i1 %t127, label %bb36, label %ok.128, !prof !99
ok.128:
  store i32 %t125, ptr %l65
  br label %bb35
bb35:
  %t129 = load i32, ptr %l65, !tbaa !23
  store i32 %t129, ptr %l59, !tbaa !23
  br label %bb38
bb36:
  br label %bb37
bb37:
  call void @__olang_ert_req_clear()
  store i32 0, ptr %l59, !tbaa !23
  br label %bb38
bb38:
  %t130 = load i32, ptr %l59, !tbaa !23
  store i32 %t130, ptr %l4, !tbaa !23
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr %"compiler/check:Checker", ptr %t131, i32 0, i32 55
  store ptr %t133, ptr %l68, !tbaa !29
  %t134 = load i64, ptr %l1, !tbaa !24
  store i64 %t134, ptr %l69, !tbaa !24
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/check:Checker", ptr %t135, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !29
  %t140 = getelementptr %"compiler/generic:Program", ptr %t138, i32 0, i32 2
  %t141 = load i32, ptr %l4, !tbaa !23
  %t144 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t140, i32 %t141)
  store { i64, ptr } %t144, ptr %l74
  br label %bb39
bb39:
  %t145 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t146 = extractvalue { i64, ptr } %t145, 0
  %t147 = load i64, ptr %l69, !tbaa !24
  %t149 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t147, i64 %t146)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t149, ptr %l76
  br label %bb40
bb40:
  %t150 = load ptr, ptr %l68, !tbaa !29
  %t151 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l76
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_H2474e1fc3c93452d7765e4ed18f29a03(ptr %v0, ptr %t150, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t151)
  br label %bb41
bb41:
  %t152 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunsettle(ptr %v0, ptr %t152)
  br label %bb42
bb42:
  %t154 = load i32, ptr %l4, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t154, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecBorrow(ptr %v0, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca ptr
  %l8 = alloca i32
  %l11 = alloca i1
  %l14 = alloca i1
  %l15 = alloca i1
  %l18 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca %"compiler/source:Span"
  %l24 = alloca { i64, ptr }
  %l26 = alloca %"compiler/msgs:Msg"
  %l27 = alloca i64
  %l30 = alloca ptr
  %l35 = alloca ptr
  %l38 = alloca i32
  %l39 = alloca i32
  %l43 = alloca ptr
  %l44 = alloca %"compiler/source:Span"
  %l47 = alloca { i64, ptr }
  %l49 = alloca %"compiler/msgs:Msg"
  %l50 = alloca i64
  %l54 = alloca i1
  %l58 = alloca %"compiler/source:Span"
  %l61 = alloca ptr
  %l62 = alloca i32
  %l65 = alloca i1
  %l66 = alloca i64
  %l68 = alloca i32
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca ptr
  %t133 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t1)
  store i32 %t4, ptr %l8
  br label %bb1
bb1:
  %t5 = load i32, ptr %l8, !tbaa !23
  store i32 %t5, ptr %l4, !tbaa !23
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr %l4, !tbaa !23
  %t10 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t6, i32 %t7)
  store i1 %t10, ptr %l11
  br label %bb2
bb2:
  %t11 = load i1, ptr %l11, !tbaa !21
  br i1 %t11, label %bb3, label %bb4
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i32, ptr %l2, !tbaa !23
  %t16 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewritable(ptr %v0, ptr %t12, i32 %t13)
  store i1 %t16, ptr %l14
  br label %bb5
bb4:
  br label %bb16
bb5:
  %t17 = load i1, ptr %l14, !tbaa !21
  br i1 %t17, label %bb6, label %bb7
bb6:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i32, ptr %l4, !tbaa !23
  %t22 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewritable(ptr %v0, ptr %t18, i32 %t19)
  store i1 %t22, ptr %l18
  br label %bb8
bb7:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb9
bb8:
  %t23 = load i1, ptr %l18, !tbaa !21
  %t24 = xor i1 %t23, true
  store i1 %t24, ptr %l15, !tbaa !21
  br label %bb9
bb9:
  %t26 = load i1, ptr %l15, !tbaa !21
  br i1 %t26, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l20, !tbaa !29
  %t28 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t28, ptr %l21
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load i32, ptr %l4, !tbaa !23
  %t33 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t29, i32 %t30)
  store { i64, ptr } %t33, ptr %l24
  br label %bb12
bb11:
  br label %bb15
bb12:
  %t34 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t34, 0
  %t36 = extractvalue { i64, ptr } %t34, 1
  %t37 = mul i64 %t35, 1
  %t38 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t37)
  call void @llvm.memcpy.p0.p0.i64(ptr %t38, ptr %t36, i64 %t37, i1 false)
  %t39 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  %t42 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCPointerReadOnly(ptr %s2, ptr %s2, { i64, ptr } %t40)
  store %"compiler/msgs:Msg" %t42, ptr %l26
  br label %bb13
bb13:
  %t43 = load ptr, ptr %l20, !tbaa !29
  %t44 = load %"compiler/source:Span", ptr %l21
  %t45 = load %"compiler/msgs:Msg", ptr %l26
  %t46 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t43, %"compiler/source:Span" %t44, %"compiler/msgs:Msg" %t45)
  store i64 %t46, ptr %l27
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb15:
  %t47 = load ptr, ptr %l1, !tbaa !29
  store ptr %t47, ptr %rv
  br label %ret
bb16:
  %t49 = load ptr, ptr %l1, !tbaa !29
  %t51 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %t49)
  store ptr %t51, ptr %l30
  br label %bb17
bb17:
  %t52 = load ptr, ptr %l30, !tbaa !29
  store ptr %t52, ptr %l5, !tbaa !29
  %t53 = load ptr, ptr %l5, !tbaa !29
  %t55 = icmp eq ptr %t53, null
  br i1 %t55, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s3
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = getelementptr %"compiler/generic:Program", ptr %t60, i32 0, i32 2
  store ptr %t62, ptr %l35, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load i32, ptr %l4, !tbaa !23
  %t67 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t63, i32 %t64)
  store i32 %t67, ptr %l38
  br label %bb20
bb19:
  br label %bb28
bb20:
  %t68 = load ptr, ptr %l35, !tbaa !29
  %t69 = load i32, ptr %l38, !tbaa !23
  %t70 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t68, i32 %t69)
  store i32 %t70, ptr %l39
  br label %bb21
bb21:
  %t71 = load i32, ptr %l39, !range !{i32 0, i32 33}
  %t73 = trunc i64 19 to i32
  %t74 = icmp eq i32 %t71, %t73
  br i1 %t74, label %bb22, label %bb23
bb22:
  %t76 = load ptr, ptr %l1, !tbaa !29
  call void @__olang_scope_close(ptr %s3)
  store ptr %t76, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l43, !tbaa !29
  %t79 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t79, ptr %l44
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load i32, ptr %l4, !tbaa !23
  %t84 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s3, ptr %t80, i32 %t81)
  store { i64, ptr } %t84, ptr %l47
  br label %bb25
bb25:
  %t85 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t85, 0
  %t87 = extractvalue { i64, ptr } %t85, 1
  %t88 = mul i64 %t86, 1
  %t89 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t88)
  call void @llvm.memcpy.p0.p0.i64(ptr %t89, ptr %t87, i64 %t88, i1 false)
  %t90 = insertvalue { i64, ptr } undef, i64 %t86, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t89, 1
  %t93 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCPointerTemporary(ptr %s3, ptr %s3, { i64, ptr } %t91)
  store %"compiler/msgs:Msg" %t93, ptr %l49
  br label %bb26
bb26:
  %t94 = load ptr, ptr %l43, !tbaa !29
  %t95 = load %"compiler/source:Span", ptr %l44
  %t96 = load %"compiler/msgs:Msg", ptr %l49
  %t97 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t94, %"compiler/source:Span" %t95, %"compiler/msgs:Msg" %t96)
  store i64 %t97, ptr %l50
  br label %bb27
bb27:
  %t98 = load ptr, ptr %l1, !tbaa !29
  call void @__olang_scope_close(ptr %s3)
  store ptr %t98, ptr %rv
  br label %ret
bb28:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load i32, ptr %l2, !tbaa !23
  %t104 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewritable(ptr %v0, ptr %t100, i32 %t101)
  store i1 %t104, ptr %l54
  br label %bb29
bb29:
  %t105 = load i1, ptr %l54, !tbaa !21
  br i1 %t105, label %bb30, label %bb31
bb30:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load ptr, ptr %l5, !tbaa !29
  %t108 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emustWrite(ptr %v0, ptr %v0, ptr %t106, ptr %t107, %"compiler/source:Span" %t108, i1 false)
  br label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb33
bb33:
  %t112 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t112, ptr %l58
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/check:Checker", ptr %t113, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !29
  %t118 = getelementptr %"compiler/generic:Program", ptr %t116, i32 0, i32 2
  store ptr %t118, ptr %l61, !tbaa !29
  %t119 = load i32, ptr %l4, !tbaa !23
  store i32 %t119, ptr %l62, !tbaa !23
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load i32, ptr %l2, !tbaa !23
  %t124 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewritable(ptr %v0, ptr %t120, i32 %t121)
  store i1 %t124, ptr %l65
  br label %bb34
bb34:
  %t125 = load i1, ptr %l65, !tbaa !21
  br i1 %t125, label %bb35, label %bb36
bb35:
  %t126 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  store i64 %t126, ptr %l66, !tbaa !24
  br label %bb37
bb36:
  store i64 0, ptr %l66, !tbaa !24
  br label %bb37
bb37:
  %t128 = load ptr, ptr %l61, !tbaa !29
  %t129 = load i32, ptr %l62, !tbaa !23
  %t130 = load i64, ptr %l66, !tbaa !24
  %t131 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t128, i32 %t129, i64 %t130)
  store i32 %t131, ptr %l68
  br label %bb38
bb38:
  %t132 = load ptr, ptr %l5, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t133
  %t134 = getelementptr { i64, [5 x i64] }, ptr %t133, i32 0, i32 0
  store i64 3, ptr %t134
  %t135 = load %"compiler/source:Span", ptr %l58
  %t136 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t135, 0
  %t137 = load i32, ptr %l68, !tbaa !23
  %t138 = insertvalue { %"compiler/source:Span", i32, ptr } %t136, i32 %t137, 1
  %t140 = insertvalue { %"compiler/source:Span", i32, ptr } %t138, ptr %t132, 2
  %t141 = getelementptr { i64, [5 x i64] }, ptr %t133, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t140, ptr %t141
  %t142 = load { i64, [5 x i64] }, ptr %t133
  %t144 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t142, ptr %t144
  store ptr %t144, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecPointerArg(ptr %v0, ptr %v1, ptr %a0, ptr %a1, ptr %a2, i32 %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca %"compiler/source:Span"
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l22 = alloca i32
  %l26 = alloca i1
  %l33 = alloca i32
  %l36 = alloca i32
  %l39 = alloca i1
  %l42 = alloca i1
  %l49 = alloca i32
  %l52 = alloca i1
  %l55 = alloca i1
  %l60 = alloca ptr
  %l63 = alloca ptr
  %l66 = alloca i32
  %l67 = alloca i32
  %l72 = alloca i32
  %l75 = alloca i1
  %l78 = alloca i1
  %l83 = alloca i32
  %l84 = alloca i32
  %l88 = alloca i32
  %l90 = alloca i1
  %l91 = alloca i32
  %l95 = alloca i32
  %l102 = alloca i1
  %l103 = alloca i1
  %l104 = alloca ptr
  %l107 = alloca i32
  %l108 = alloca i1
  %l109 = alloca i1
  %l114 = alloca i32
  %l121 = alloca i32
  %l124 = alloca ptr
  %l125 = alloca i32
  %l128 = alloca i32
  %l129 = alloca i1
  %l130 = alloca i1
  %l131 = alloca ptr
  %l134 = alloca i32
  %l135 = alloca i1
  %l140 = alloca ptr
  %l144 = alloca i1
  %l145 = alloca i1
  %l148 = alloca i1
  %l149 = alloca i1
  %l150 = alloca ptr
  %l153 = alloca i32
  %l154 = alloca i1
  %l155 = alloca i1
  %l158 = alloca i1
  %s8 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  store %"compiler/source:Span" %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a1, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t2 = load ptr, ptr %l13, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l13, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 5}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l14, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l14, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_7362f3ae74bf0a7_8f389ee36c95dce3)
  unreachable
bb11:
  %t10 = load i1, ptr %l12, !tbaa !21
  %t13 = xor i1 %t10, true
  br i1 %t13, label %bb12, label %bb13
bb12:
  store ptr null, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t19 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t16)
  store i32 %t19, ptr %l22
  br label %bb15
bb15:
  %t20 = load i32, ptr %l22, !tbaa !23
  store i32 %t20, ptr %l6, !tbaa !23
  %t21 = load i32, ptr %l6, !tbaa !23
  %t22 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t25 = icmp eq i32 %t21, %t22
  br i1 %t25, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb18
bb17:
  %t27 = load i32, ptr %l6, !tbaa !23
  %t28 = load i32, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  %t31 = icmp eq i32 %t27, %t28
  store i1 %t31, ptr %l26, !tbaa !21
  br label %bb18
bb18:
  %t33 = load i1, ptr %l26, !tbaa !21
  br i1 %t33, label %bb19, label %bb20
bb19:
  store ptr null, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load i32, ptr %l6, !tbaa !23
  %t39 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t35, i32 %t36)
  store i32 %t39, ptr %l33
  br label %bb22
bb22:
  %t40 = load i32, ptr %l33, !tbaa !23
  store i32 %t40, ptr %l7, !tbaa !23
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i32, ptr %l7, !tbaa !23
  %t45 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t41, i32 %t42)
  store i32 %t45, ptr %l36
  br label %bb23
bb23:
  %t46 = load i32, ptr %l36, !tbaa !23
  store i32 %t46, ptr %l8, !tbaa !23
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load i32, ptr %l3, !tbaa !23
  %t51 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecVoidRef(ptr %v0, ptr %t47, i32 %t48)
  store i1 %t51, ptr %l39
  br label %bb24
bb24:
  %t52 = load i1, ptr %l39, !tbaa !21
  br i1 %t52, label %bb25, label %bb26
bb25:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load i32, ptr %l6, !tbaa !23
  %t57 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eforeignRef(ptr %v0, ptr %t53, i32 %t54)
  store i1 %t57, ptr %l42
  br label %bb27
bb26:
  br label %bb40
bb27:
  %t58 = load i1, ptr %l42, !tbaa !21
  br i1 %t58, label %bb28, label %bb29
bb28:
  %t59 = load ptr, ptr %l2, !tbaa !29
  store ptr %t59, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Program", ptr %t65, i32 0, i32 2
  %t68 = load i32, ptr %l8, !tbaa !23
  %t71 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t67, i32 %t68)
  store i32 %t71, ptr %l49
  br label %bb31
bb31:
  %t72 = load i32, ptr %l49, !range !{i32 0, i32 33}
  %t74 = trunc i64 19 to i32
  %t75 = icmp eq i32 %t72, %t74
  br i1 %t75, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l52, !tbaa !21
  br label %bb35
bb33:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load i32, ptr %l7, !tbaa !23
  %t81 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplainStruct(ptr %v0, ptr %t77, i32 %t78, i64 0)
  store i1 %t81, ptr %l55
  br label %bb34
bb34:
  %t82 = load i1, ptr %l55, !tbaa !21
  store i1 %t82, ptr %l52, !tbaa !21
  br label %bb35
bb35:
  %t83 = load i1, ptr %l52, !tbaa !21
  br i1 %t83, label %bb36, label %bb37
bb36:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load ptr, ptr %l2, !tbaa !29
  %t86 = load i32, ptr %l3, !tbaa !23
  %t87 = load %"compiler/source:Span", ptr %l4
  %t92 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecBorrow(ptr %v0, ptr %t84, ptr %t85, i32 %t86, %"compiler/source:Span" %t87)
  store ptr %t92, ptr %l60
  br label %bb38
bb37:
  br label %bb39
bb38:
  %t93 = load ptr, ptr %l60, !tbaa !29
  store ptr %t93, ptr %rv
  br label %ret
bb39:
  store ptr null, ptr %rv
  br label %ret
bb40:
  %t96 = load ptr, ptr %l0, !tbaa !29
  store ptr %t96, ptr %l63, !tbaa !29
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load i32, ptr %l3, !tbaa !23
  %t101 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t97, i32 %t98)
  store i32 %t101, ptr %l66
  br label %bb41
bb41:
  %t102 = load ptr, ptr %l63, !tbaa !29
  %t103 = load i32, ptr %l66, !tbaa !23
  %t104 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t102, i32 %t103)
  store i32 %t104, ptr %l67
  br label %bb42
bb42:
  %t105 = load i32, ptr %l67, !tbaa !23
  store i32 %t105, ptr %l9, !tbaa !23
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/check:Checker", ptr %t106, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t111 = getelementptr %"compiler/generic:Program", ptr %t109, i32 0, i32 2
  %t112 = load i32, ptr %l9, !tbaa !23
  %t115 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t111, i32 %t112)
  store i32 %t115, ptr %l72
  br label %bb43
bb43:
  %t116 = load i32, ptr %l72, !range !{i32 0, i32 33}
  %t118 = trunc i64 19 to i32
  %t119 = icmp eq i32 %t116, %t118
  br i1 %t119, label %bb44, label %bb45
bb44:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load i32, ptr %l6, !tbaa !23
  %t125 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisCStrRef(ptr %v0, ptr %t121, i32 %t122)
  store i1 %t125, ptr %l78
  br label %bb46
bb45:
  store i1 false, ptr %l75, !tbaa !21
  br label %bb47
bb46:
  %t126 = load i1, ptr %l78, !tbaa !21
  store i1 %t126, ptr %l75, !tbaa !21
  br label %bb47
bb47:
  %t127 = load i1, ptr %l75, !tbaa !21
  br i1 %t127, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s8
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/check:Checker", ptr %t128, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !29
  %t133 = getelementptr %"compiler/generic:Program", ptr %t131, i32 0, i32 2
  %t134 = load i32, ptr %l9, !tbaa !23
  %t137 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t133, i32 %t134)
  store i32 %t137, ptr %l83
  br label %bb50
bb49:
  br label %bb59
bb50:
  %t138 = load i32, ptr %l83, !tbaa !23
  store i32 %t138, ptr %l10, !tbaa !23
  %t139 = load i32, ptr %l10, !tbaa !23
  store i32 %t139, ptr %l84, !tbaa !23
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t142 = getelementptr %"compiler/check:Checker", ptr %t140, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !29
  %t145 = getelementptr %"compiler/generic:Program", ptr %t143, i32 0, i32 2
  %t147 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s8, ptr %t145, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store i32 %t147, ptr %l88
  br label %bb51
bb51:
  %t148 = load i32, ptr %l84, !tbaa !23
  %t149 = load i32, ptr %l88, !tbaa !23
  %t150 = icmp eq i32 %t148, %t149
  br i1 %t150, label %bb52, label %bb53
bb52:
  store i1 true, ptr %l90, !tbaa !21
  br label %bb55
bb53:
  %t152 = load i32, ptr %l10, !tbaa !23
  store i32 %t152, ptr %l91, !tbaa !23
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t155 = getelementptr %"compiler/check:Checker", ptr %t153, i32 0, i32 1
  %t156 = load ptr, ptr %t155, !tbaa !29
  %t158 = getelementptr %"compiler/generic:Program", ptr %t156, i32 0, i32 2
  %t160 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s8, ptr %t158, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store i32 %t160, ptr %l95
  br label %bb54
bb54:
  %t161 = load i32, ptr %l91, !tbaa !23
  %t162 = load i32, ptr %l95, !tbaa !23
  %t163 = icmp eq i32 %t161, %t162
  store i1 %t163, ptr %l90, !tbaa !21
  br label %bb55
bb55:
  %t165 = load i1, ptr %l90, !tbaa !21
  br i1 %t165, label %bb56, label %bb57
bb56:
  %t166 = load ptr, ptr %l2, !tbaa !29
  call void @__olang_scope_close(ptr %s8)
  store ptr %t166, ptr %rv
  br label %ret
bb57:
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s8)
  store ptr null, ptr %rv
  br label %ret
bb59:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load i32, ptr %l3, !tbaa !23
  %t174 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t170, i32 %t171)
  store i1 %t174, ptr %l102
  br label %bb60
bb60:
  %t175 = load i1, ptr %l102, !tbaa !21
  br i1 %t175, label %bb61, label %bb62
bb61:
  %t176 = load ptr, ptr %l0, !tbaa !29
  store ptr %t176, ptr %l104, !tbaa !29
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t178 = load i32, ptr %l3, !tbaa !23
  %t181 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t177, i32 %t178)
  store i32 %t181, ptr %l107
  br label %bb63
bb62:
  store i1 false, ptr %l103, !tbaa !21
  br label %bb65
bb63:
  %t182 = load ptr, ptr %l104, !tbaa !29
  %t183 = load i32, ptr %l107, !tbaa !23
  %t184 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecStruct(ptr %v0, ptr %t182, i32 %t183)
  store i1 %t184, ptr %l108
  br label %bb64
bb64:
  %t185 = load i1, ptr %l108, !tbaa !21
  store i1 %t185, ptr %l103, !tbaa !21
  br label %bb65
bb65:
  %t186 = load i1, ptr %l103, !tbaa !21
  br i1 %t186, label %bb66, label %bb67
bb66:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr %"compiler/check:Checker", ptr %t187, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !29
  %t192 = getelementptr %"compiler/generic:Program", ptr %t190, i32 0, i32 2
  %t193 = load i32, ptr %l8, !tbaa !23
  %t196 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t192, i32 %t193)
  store i32 %t196, ptr %l114
  br label %bb68
bb67:
  store i1 false, ptr %l109, !tbaa !21
  br label %bb69
bb68:
  %t197 = load i32, ptr %l114, !range !{i32 0, i32 33}
  %t199 = trunc i64 19 to i32
  %t200 = icmp eq i32 %t197, %t199
  store i1 %t200, ptr %l109, !tbaa !21
  br label %bb69
bb69:
  %t202 = load i1, ptr %l109, !tbaa !21
  br i1 %t202, label %bb70, label %bb71
bb70:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t205 = getelementptr %"compiler/check:Checker", ptr %t203, i32 0, i32 1
  %t206 = load ptr, ptr %t205, !tbaa !29
  %t208 = getelementptr %"compiler/generic:Program", ptr %t206, i32 0, i32 2
  %t209 = load i32, ptr %l8, !tbaa !23
  %t212 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t208, i32 %t209)
  store i32 %t212, ptr %l121
  br label %bb72
bb71:
  br label %bb84
bb72:
  %t213 = load i32, ptr %l121, !tbaa !23
  store i32 %t213, ptr %l11, !tbaa !23
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t216 = getelementptr %"compiler/check:Checker", ptr %t214, i32 0, i32 1
  %t217 = load ptr, ptr %t216, !tbaa !29
  %t219 = getelementptr %"compiler/generic:Program", ptr %t217, i32 0, i32 2
  store ptr %t219, ptr %l124, !tbaa !29
  %t220 = load i32, ptr %l11, !tbaa !23
  store i32 %t220, ptr %l125, !tbaa !23
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t222 = load i32, ptr %l3, !tbaa !23
  %t225 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t221, i32 %t222)
  store i32 %t225, ptr %l128
  br label %bb73
bb73:
  %t226 = load ptr, ptr %l124, !tbaa !29
  %t227 = load i32, ptr %l125, !tbaa !23
  %t228 = load i32, ptr %l128, !tbaa !23
  %t229 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t226, i32 %t227, i32 %t228)
  store i1 %t229, ptr %l129
  br label %bb74
bb74:
  %t230 = load i1, ptr %l129, !tbaa !21
  br i1 %t230, label %bb75, label %bb76
bb75:
  store i1 true, ptr %l130, !tbaa !21
  br label %bb79
bb76:
  %t231 = load ptr, ptr %l0, !tbaa !29
  store ptr %t231, ptr %l131, !tbaa !29
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t233 = load i32, ptr %l11, !tbaa !23
  %t236 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t232, i32 %t233)
  store i32 %t236, ptr %l134
  br label %bb77
bb77:
  %t237 = load ptr, ptr %l131, !tbaa !29
  %t238 = load i32, ptr %l134, !tbaa !23
  %t239 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecNumber(ptr %v0, ptr %t237, i32 %t238)
  store i1 %t239, ptr %l135
  br label %bb78
bb78:
  %t240 = load i1, ptr %l135, !tbaa !21
  store i1 %t240, ptr %l130, !tbaa !21
  br label %bb79
bb79:
  %t241 = load i1, ptr %l130, !tbaa !21
  br i1 %t241, label %bb80, label %bb81
bb80:
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t243 = load ptr, ptr %l2, !tbaa !29
  %t244 = load i32, ptr %l3, !tbaa !23
  %t245 = load %"compiler/source:Span", ptr %l4
  %t250 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecBorrow(ptr %v0, ptr %t242, ptr %t243, i32 %t244, %"compiler/source:Span" %t245)
  store ptr %t250, ptr %l140
  br label %bb82
bb81:
  br label %bb83
bb82:
  %t251 = load ptr, ptr %l140, !tbaa !29
  store ptr %t251, ptr %rv
  br label %ret
bb83:
  br label %bb84
bb84:
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t254 = load i32, ptr %l3, !tbaa !23
  %t257 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t253, i32 %t254)
  store i1 %t257, ptr %l144
  br label %bb85
bb85:
  %t258 = load i1, ptr %l144, !tbaa !21
  br i1 %t258, label %bb86, label %bb87
bb86:
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t260 = load i32, ptr %l6, !tbaa !23
  %t263 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecVoidRef(ptr %v0, ptr %t259, i32 %t260)
  store i1 %t263, ptr %l148
  br label %bb88
bb87:
  store i1 false, ptr %l145, !tbaa !21
  br label %bb89
bb88:
  %t264 = load i1, ptr %l148, !tbaa !21
  store i1 %t264, ptr %l145, !tbaa !21
  br label %bb89
bb89:
  %t265 = load i1, ptr %l145, !tbaa !21
  br i1 %t265, label %bb90, label %bb91
bb90:
  %t266 = load ptr, ptr %l0, !tbaa !29
  store ptr %t266, ptr %l150, !tbaa !29
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t268 = load i32, ptr %l3, !tbaa !23
  %t271 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t267, i32 %t268)
  store i32 %t271, ptr %l153
  br label %bb92
bb91:
  store i1 false, ptr %l149, !tbaa !21
  br label %bb98
bb92:
  %t272 = load ptr, ptr %l150, !tbaa !29
  %t273 = load i32, ptr %l153, !tbaa !23
  %t274 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecStruct(ptr %v0, ptr %t272, i32 %t273)
  store i1 %t274, ptr %l154
  br label %bb93
bb93:
  %t275 = load i1, ptr %l154, !tbaa !21
  br i1 %t275, label %bb94, label %bb95
bb94:
  store i1 true, ptr %l155, !tbaa !21
  br label %bb97
bb95:
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t277 = load i32, ptr %l3, !tbaa !23
  %t280 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eforeignRef(ptr %v0, ptr %t276, i32 %t277)
  store i1 %t280, ptr %l158
  br label %bb96
bb96:
  %t281 = load i1, ptr %l158, !tbaa !21
  store i1 %t281, ptr %l155, !tbaa !21
  br label %bb97
bb97:
  %t282 = load i1, ptr %l155, !tbaa !21
  store i1 %t282, ptr %l149, !tbaa !21
  br label %bb98
bb98:
  %t283 = load i1, ptr %l149, !tbaa !21
  br i1 %t283, label %bb99, label %bb100
bb99:
  %t284 = load ptr, ptr %l2, !tbaa !29
  store ptr %t284, ptr %rv
  br label %ret
bb100:
  br label %bb101
bb101:
  store ptr null, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecStruct(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %l8 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i32
  %l15 = alloca i1
  %l19 = alloca ptr
  %l22 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca i64
  %l29 = alloca ptr
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplainStruct(ptr %v0, ptr %t1, i32 %t2, i64 0)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load i32, ptr %l1, !tbaa !23
  %t12 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t8, i32 %t9)
  store i1 %t12, ptr %l8
  br label %bb5
bb5:
  %t13 = load i1, ptr %l8, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i32, ptr %l1, !tbaa !23
  %t18 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t14, i32 %t15)
  store i32 %t18, ptr %l12
  br label %bb8
bb7:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb9
bb8:
  %t19 = load i32, ptr %l12, !range !{i32 0, i32 6}
  %t21 = trunc i64 0 to i32
  %t22 = icmp eq i32 %t19, %t21
  store i1 %t22, ptr %l9, !tbaa !21
  br label %bb9
bb9:
  %t24 = load i1, ptr %l9, !tbaa !21
  br i1 %t24, label %bb10, label %bb11
bb10:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/check:Checker", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = getelementptr %"compiler/generic:Program", ptr %t28, i32 0, i32 0
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/load:Loader", ptr %t31, i32 0, i32 5
  store ptr %t33, ptr %l19, !tbaa !29
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/generic:Program", ptr %t37, i32 0, i32 2
  store ptr %t39, ptr %l22, !tbaa !29
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/check:Checker", ptr %t40, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = getelementptr %"compiler/generic:Program", ptr %t43, i32 0, i32 2
  %t46 = load i32, ptr %l1, !tbaa !23
  %t49 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t45, i32 %t46)
  store i32 %t49, ptr %l27
  br label %bb12
bb11:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb15
bb12:
  %t50 = load ptr, ptr %l22, !tbaa !29
  %t51 = load i32, ptr %l27, !tbaa !23
  %t52 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t50, i32 %t51)
  store i64 %t52, ptr %l28
  br label %bb13
bb13:
  %t53 = load ptr, ptr %l19, !tbaa !29
  %t54 = load i64, ptr %l28, !tbaa !24
  %t55 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t53, i64 %t54)
  store ptr %t55, ptr %l29
  br label %bb14
bb14:
  %t56 = load ptr, ptr %l29, !tbaa !29
  %t58 = getelementptr %"compiler/load:Module", ptr %t56, i32 0, i32 30
  %t59 = load i1, ptr %t58, !tbaa !21
  store i1 %t59, ptr %l15, !tbaa !21
  br label %bb15
bb15:
  %t61 = load i1, ptr %l15, !tbaa !21
  store i1 %t61, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalleeErrors(ptr %v0, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i1
  %l14 = alloca i32
  %l19 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 5}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { i32 }, ptr %t12, i32 0, i32 0
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l3, !tbaa !23
  %t19 = sext i32 %t17 to i64
  %t22 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyErrors(ptr %v0, ptr %t16, i64 %t19)
  store i32 %t22, ptr %l14
  br label %bb6
bb6:
  %t23 = load i32, ptr %l14, !tbaa !23
  store i32 %t23, ptr %l4, !tbaa !23
  br label %bb13
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/generic:Program", ptr %t27, i32 0, i32 2
  %t33 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t29, i32 %a2)
  store i32 %t33, ptr %l19
  br label %bb11
bb11:
  %t34 = load i32, ptr %l19, !tbaa !23
  store i32 %t34, ptr %l4, !tbaa !23
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_27c62905650ee804_ddef4b1ccc198ce0)
  unreachable
bb13:
  %t35 = load i32, ptr %l4, !tbaa !23
  store i32 %t35, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaught(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca ptr
  %l16 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l24 = alloca i64
  %l28 = alloca i64
  %l31 = alloca i64
  %l52 = alloca i32
  %l61 = alloca i32
  %l75 = alloca i64
  %l77 = alloca i64
  %l82 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l19
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l19, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  %t5 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, ptr %l20
  br label %bb2
bb2:
  %t6 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l20
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t6, ptr %l6
  %t7 = load i64, ptr %l1, !tbaa !24
  store i64 %t7, ptr %l7, !tbaa !24
  %t9 = load ptr, ptr %l4, !tbaa !29
  %t11 = getelementptr %"compiler/check:frame", ptr %t9, i32 0, i32 26
  %t13 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t11)
  store i64 %t13, ptr %l24
  br label %bb3
bb3:
  %t14 = load i64, ptr %l24, !tbaa !24
  store i64 %t14, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t15 = load i64, ptr %l8, !tbaa !24
  %t16 = load i64, ptr %l7, !tbaa !24
  %t19 = icmp sgt i64 %t15, %t16
  br i1 %t19, label %bb4, label %bb5
bb4:
  %t21 = load i64, ptr %l9, !tbaa !24
  %t23 = icmp sgt i64 %t21, 0
  br i1 %t23, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb9
bb6:
  %t25 = load i64, ptr %l8, !tbaa !24
  %t26 = load i64, ptr %l7, !tbaa !24
  %t29 = sub i64 %t25, %t26
  %t30 = load i64, ptr %l9, !tbaa !24
  %t33 = add i64 %t29, %t30
  %t35 = sub i64 %t33, 1
  %t36 = load i64, ptr %l9, !tbaa !24
  %t39 = sdiv i64 %t35, %t36
  store i64 %t39, ptr %l31, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb8
bb8:
  %t41 = load i64, ptr %l31, !tbaa !24
  store i64 %t41, ptr %l28, !tbaa !24
  br label %bb9
bb9:
  %t42 = load i64, ptr %l28, !tbaa !24
  store i64 %t42, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb10
bb10:
  %t43 = load i64, ptr %l11, !tbaa !24
  %t44 = load i64, ptr %l10, !tbaa !24
  %t47 = icmp slt i64 %t43, %t44
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb11, label %bb12
bb11:
  br label %bb25
bb12:
  br label %bb13
bb13:
  %t51 = load i64, ptr %l7, !tbaa !24
  %t52 = load i64, ptr %l11, !tbaa !24
  %t53 = load i64, ptr %l9, !tbaa !24
  %t56 = mul i64 %t52, %t53
  %t59 = add i64 %t51, %t56
  store i64 %t59, ptr %l12, !tbaa !24
  %t61 = load ptr, ptr %l4, !tbaa !29
  %t63 = getelementptr %"compiler/check:frame", ptr %t61, i32 0, i32 26
  %t64 = load i64, ptr %l12, !tbaa !24
  %t67 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t63, i64 %t64)
  store i32 %t67, ptr %l52
  br label %bb14
bb14:
  %t68 = load i32, ptr %l52, !tbaa !23
  store i32 %t68, ptr %l13, !tbaa !23
  %t69 = load i64, ptr %l12, !tbaa !24
  %t73 = icmp sge i64 %t69, %a2
  br i1 %t73, label %bb15, label %bb16
bb15:
  %t75 = load i32, ptr %l13, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l6, i32 %t75)
  br label %bb17
bb16:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load i32, ptr %l13, !tbaa !23
  %t84 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleft(ptr %v0, ptr %v1, ptr %t78, i32 %t79, ptr %a3)
  store i32 %t84, ptr %l61
  br label %bb18
bb17:
  br label %bb23
bb18:
  %t85 = load i32, ptr %l61, !tbaa !23
  store i32 %t85, ptr %l14, !tbaa !23
  %t86 = load i32, ptr %l14, !tbaa !23
  %t87 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t90 = icmp ne i32 %t86, %t87
  br i1 %t90, label %bb19, label %bb20
bb19:
  %t92 = load i32, ptr %l14, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l6, i32 %t92)
  br label %bb21
bb20:
  br label %bb22
bb21:
  %t95 = load i64, ptr %l5, !tbaa !24
  %t97 = add i64 %t95, 1
  store i64 %t97, ptr %l5, !tbaa !24
  br label %bb22
bb22:
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t99 = load i64, ptr %l11, !tbaa !24
  %t101 = add i64 %t99, 1
  store i64 %t101, ptr %l11, !tbaa !24
  br label %bb10
bb25:
  %t103 = load ptr, ptr %l4, !tbaa !29
  %t105 = getelementptr %"compiler/check:frame", ptr %t103, i32 0, i32 26
  %t106 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eTruncate_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t105, i64 %t106)
  br label %bb26
bb26:
  store ptr %l6, ptr %l15, !tbaa !29
  store i64 0, ptr %l16, !tbaa !24
  br label %bb27
bb27:
  %t110 = load i64, ptr %l16, !tbaa !24
  store i64 %t110, ptr %l75, !tbaa !24
  %t111 = load ptr, ptr %l15, !tbaa !29
  %t113 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t111)
  store i64 %t113, ptr %l77
  br label %bb28
bb28:
  %t114 = load i64, ptr %l75, !tbaa !24
  %t115 = load i64, ptr %l77, !tbaa !24
  %t116 = icmp slt i64 %t114, %t115
  %t118 = xor i1 %t116, true
  br i1 %t118, label %bb29, label %bb30
bb29:
  br label %bb35
bb30:
  br label %bb31
bb31:
  %t120 = load ptr, ptr %l15, !tbaa !29
  %t121 = load i64, ptr %l16, !tbaa !24
  %t124 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t120, i64 %t121)
  store i32 %t124, ptr %l82
  br label %bb32
bb32:
  %t125 = load i32, ptr %l82, !tbaa !23
  %t126 = load ptr, ptr %l4, !tbaa !29
  %t128 = getelementptr %"compiler/check:frame", ptr %t126, i32 0, i32 26
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t128, i32 %t125)
  br label %bb33
bb33:
  br label %bb34
bb34:
  %t132 = load i64, ptr %l16, !tbaa !24
  %t134 = add i64 %t132, 1
  store i64 %t134, ptr %l16, !tbaa !24
  br label %bb27
bb35:
  %t136 = load i64, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t136, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econtractChecked(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/typed:ContractInfo"
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca %"compiler/source:Span"
  %l12 = alloca i1
  %l16 = alloca i1
  %l17 = alloca %"compiler/typed:ContractInfo"
  %l21 = alloca %"compiler/typed:ContractInfo"
  %l22 = alloca i32
  %l24 = alloca i64
  %l26 = alloca i64
  %l31 = alloca i64
  %l33 = alloca i1
  %l37 = alloca i1
  %l44 = alloca ptr
  %l59 = alloca i1
  %l63 = alloca i1
  %l67 = alloca i1
  %l71 = alloca ptr
  %l76 = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 101
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t3, i64 %t4)
  store i1 %t7, ptr %l12
  br label %bb1
bb1:
  %t8 = load i1, ptr %l12, !tbaa !21
  %t9 = xor i1 %t8, true
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i64, ptr %l1, !tbaa !24
  %t15 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehasContract(ptr %v0, ptr %t11, i64 %t12)
  store i1 %t15, ptr %l16
  br label %bb4
bb3:
  br label %bb5
bb4:
  br label %ret
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 100
  %t19 = load i64, ptr %l1, !tbaa !24
  %t22 = call { i32, %"compiler/typed:ContractInfo" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aContractIn_H1fc1bd863e6a60d3e5c2aece55d841d1(ptr %v0, ptr %v0, ptr %t18, i64 %t19)
  %t23 = extractvalue { i32, %"compiler/typed:ContractInfo" } %t22, 1
  %t24 = extractvalue { i32, %"compiler/typed:ContractInfo" } %t22, 0
  store i32 %t24, ptr %l22
  %t25 = icmp ne i32 %t24, 0
  br i1 %t25, label %bb7, label %ok.26, !prof !99
ok.26:
  store %"compiler/typed:ContractInfo" %t23, ptr %l21
  br label %bb6
bb6:
  %t27 = load %"compiler/typed:ContractInfo", ptr %l21
  store %"compiler/typed:ContractInfo" %t27, ptr %l17
  br label %bb9
bb7:
  br label %bb8
bb8:
  call void @__olang_ert_req_clear()
  br label %ret
bb9:
  %t28 = load %"compiler/typed:ContractInfo", ptr %l17
  store %"compiler/typed:ContractInfo" %t28, ptr %l2
  store i1 false, ptr %l3, !tbaa !21
  %t29 = getelementptr %"compiler/typed:ContractInfo", ptr %l2, i32 0, i32 2
  store ptr %t29, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb10
bb10:
  %t31 = load i64, ptr %l5, !tbaa !24
  store i64 %t31, ptr %l24, !tbaa !24
  %t32 = load ptr, ptr %l4, !tbaa !29
  %t34 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t32)
  store i64 %t34, ptr %l26
  br label %bb11
bb11:
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = load i64, ptr %l26, !tbaa !24
  %t37 = icmp slt i64 %t35, %t36
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb12, label %bb13
bb12:
  br label %bb21
bb13:
  br label %bb14
bb14:
  %t41 = load ptr, ptr %l4, !tbaa !29
  %t42 = load i64, ptr %l5, !tbaa !24
  %t45 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t41, i64 %t42)
  store i64 %t45, ptr %l31
  br label %bb15
bb15:
  %t46 = load i64, ptr %l31, !tbaa !24
  store i64 %t46, ptr %l6, !tbaa !24
  %t47 = load i1, ptr %l3, !tbaa !21
  br i1 %t47, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb19
bb17:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/check:Checker", ptr %t49, i32 0, i32 112
  %t52 = load i64, ptr %l6, !tbaa !24
  %t55 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t51, i64 %t52)
  store i1 %t55, ptr %l37
  br label %bb18
bb18:
  %t56 = load i1, ptr %l37, !tbaa !21
  store i1 %t56, ptr %l33, !tbaa !21
  br label %bb19
bb19:
  %t57 = load i1, ptr %l33, !tbaa !21
  store i1 %t57, ptr %l3, !tbaa !21
  br label %bb20
bb20:
  %t58 = load i64, ptr %l5, !tbaa !24
  %t60 = add i64 %t58, 1
  store i64 %t60, ptr %l5, !tbaa !24
  br label %bb10
bb21:
  %t62 = load i1, ptr %l3, !tbaa !21
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb22, label %bb23
bb22:
  br label %ret
bb23:
  br label %bb24
bb24:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load i64, ptr %l1, !tbaa !24
  %t70 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectSourceOf(ptr %v0, ptr %t66, i64 %t67)
  store ptr %t70, ptr %l44
  br label %bb25
bb25:
  %t71 = load ptr, ptr %l44, !tbaa !29
  store ptr %t71, ptr %l7, !tbaa !29
  %t72 = load ptr, ptr %l7, !tbaa !29
  %t74 = icmp eq ptr %t72, null
  br i1 %t74, label %bb26, label %bb27
bb26:
  br label %ret
bb27:
  br label %bb28
bb28:
  %t76 = load ptr, ptr %l7, !tbaa !29
  %t78 = getelementptr %"compiler/check:ctSource", ptr %t76, i32 0, i32 0
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t81 = getelementptr %"compiler/ast:ContractBlock", ptr %t79, i32 0, i32 0
  %t82 = load %"compiler/source:Span", ptr %t81
  store %"compiler/source:Span" %t82, ptr %l8
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/check:Checker", ptr %t84, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !29
  %t89 = getelementptr %"compiler/generic:Program", ptr %t87, i32 0, i32 0
  %t90 = load ptr, ptr %t89, !tbaa !29
  %t92 = getelementptr %"compiler/load:Loader", ptr %t90, i32 0, i32 4
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t94 = getelementptr %"compiler/typed:ContractInfo", ptr %l2, i32 0, i32 1
  %t95 = load i64, ptr %t94, !tbaa !24
  %t96 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 0
  %t97 = load i32, ptr %t96, !tbaa !23
  %t99 = sext i32 %t97 to i64
  %t100 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 1
  %t101 = load i32, ptr %t100, !tbaa !23
  %t103 = sext i32 %t101 to i64
  %t108 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorWithin(ptr %v0, ptr %t93, i64 %t95, i64 %t99, i64 %t103, i64 0)
  store i1 %t108, ptr %l59
  br label %bb29
bb29:
  %t109 = load i1, ptr %l59, !tbaa !21
  br i1 %t109, label %bb30, label %bb31
bb30:
  br label %ret
bb31:
  br label %bb32
bb32:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/check:Checker", ptr %t110, i32 0, i32 101
  %t113 = load i64, ptr %l1, !tbaa !24
  %t116 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eRemove_3cI64_2c_20Bool_3e(ptr %v0, ptr %t112, i64 %t113)
  store i1 %t116, ptr %l63
  br label %bb33
bb33:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/check:Checker", ptr %t117, i32 0, i32 100
  %t120 = load i64, ptr %l1, !tbaa !24
  %t123 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aContractIn_H044304b59760c17b661e6227d2ca1ac9(ptr %v0, ptr %t119, i64 %t120)
  store i1 %t123, ptr %l67
  br label %bb34
bb34:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/check:Checker", ptr %t124, i32 0, i32 12
  %t127 = load i64, ptr %l1, !tbaa !24
  %t130 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t126, i64 %t127)
  store ptr %t130, ptr %l71
  br label %bb35
bb35:
  %t131 = load ptr, ptr %l71, !tbaa !29
  %t133 = getelementptr %"compiler/typed:Body", ptr %t131, i32 0, i32 12
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeRel_3e_2eClear_H4f4a348a9dbae49661ad0a6f7cb416a9(ptr %v0, ptr %t133)
  br label %bb36
bb36:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load i64, ptr %l1, !tbaa !24
  %t139 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehasContract(ptr %v0, ptr %t135, i64 %t136)
  store i1 %t139, ptr %l76
  br label %bb37
bb37:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclsIf(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l8 = alloca i1
  %l13 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca i64
  %l36 = alloca ptr
  %l37 = alloca i64
  %l50 = alloca i1
  %l55 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t2 = load i64, ptr %l4, !tbaa !24
  %t5 = icmp eq i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = getelementptr %"compiler/ast:TopIf", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = icmp eq ptr %t10, null
  %t14 = xor i1 %t12, true
  store i1 %t14, ptr %l8, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb3
bb3:
  %t16 = load i1, ptr %l8, !tbaa !21
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t19 = getelementptr %"compiler/ast:TopIf", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = icmp eq ptr %t20, null
  br i1 %t22, label %bb6, label %bb7
bb5:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb9
bb6:
  call void @__olang_check_failed(ptr @olang_loc_cd06913e2f5eb0d4_3977f9e98d534b08)
  unreachable
bb7:
  br label %bb8
bb8:
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t26 = getelementptr %"compiler/ast:TopIf", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t30 = getelementptr %"compiler/ast:TopBranch", ptr %t27, i32 0, i32 1
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t35 = icmp sgt i64 %t33, 0
  store i1 %t35, ptr %l13, !tbaa !21
  br label %bb9
bb9:
  %t37 = load i1, ptr %l13, !tbaa !21
  br i1 %t37, label %bb10, label %bb11
bb10:
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l23, !tbaa !29
  %t39 = load i64, ptr %l1, !tbaa !24
  store i64 %t39, ptr %l24, !tbaa !24
  %t40 = load ptr, ptr %l2, !tbaa !29
  %t42 = getelementptr %"compiler/ast:TopIf", ptr %t40, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = icmp eq ptr %t43, null
  br i1 %t45, label %bb12, label %bb13
bb11:
  br label %bb16
bb12:
  call void @__olang_check_failed(ptr @olang_loc_cd06913e2f5eb0d4_3977f9e98d534b08)
  unreachable
bb13:
  br label %bb14
bb14:
  %t47 = load ptr, ptr %l2, !tbaa !29
  %t49 = getelementptr %"compiler/ast:TopIf", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t53 = getelementptr %"compiler/ast:TopBranch", ptr %t50, i32 0, i32 1
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !27
  %t55 = load ptr, ptr %l23, !tbaa !29
  %t56 = load i64, ptr %l24, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edecls(ptr %v0, ptr %v1, ptr %t55, i64 %t56, { i64, ptr } %t54)
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t58 = load ptr, ptr %l2, !tbaa !29
  %t60 = getelementptr %"compiler/ast:TopIf", ptr %t58, i32 0, i32 2
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = icmp eq ptr %t61, null
  %t65 = xor i1 %t63, true
  br i1 %t65, label %bb17, label %bb18
bb17:
  %t67 = load ptr, ptr %l0, !tbaa !29
  store ptr %t67, ptr %l36, !tbaa !29
  %t68 = load i64, ptr %l1, !tbaa !24
  store i64 %t68, ptr %l37, !tbaa !24
  %t69 = load ptr, ptr %l2, !tbaa !29
  %t71 = getelementptr %"compiler/ast:TopIf", ptr %t69, i32 0, i32 2
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t74 = icmp eq ptr %t72, null
  br i1 %t74, label %bb19, label %bb20
bb18:
  br label %bb23
bb19:
  call void @__olang_check_failed(ptr @olang_loc_40b85daad0e541e3_3cdd9f152c967927)
  unreachable
bb20:
  br label %bb21
bb21:
  %t76 = load ptr, ptr %l2, !tbaa !29
  %t78 = getelementptr %"compiler/ast:TopIf", ptr %t76, i32 0, i32 2
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t80 = load i64, ptr %l3, !tbaa !24
  %t81 = load i64, ptr %l4, !tbaa !24
  %t83 = add i64 %t81, 1
  %t84 = load ptr, ptr %l36, !tbaa !29
  %t85 = load i64, ptr %l37, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclsIf(ptr %v0, ptr %v1, ptr %t84, i64 %t85, ptr %t79, i64 %t80, i64 %t83)
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t89 = load ptr, ptr %l2, !tbaa !29
  %t91 = getelementptr %"compiler/ast:TopIf", ptr %t89, i32 0, i32 3
  %t92 = load ptr, ptr %t91, !tbaa !29
  %t94 = icmp eq ptr %t92, null
  %t96 = xor i1 %t94, true
  br i1 %t96, label %bb24, label %bb25
bb24:
  %t98 = load i64, ptr %l3, !tbaa !24
  %t99 = load i64, ptr %l4, !tbaa !24
  %t101 = add i64 %t99, 1
  %t104 = icmp eq i64 %t98, %t101
  store i1 %t104, ptr %l50, !tbaa !21
  br label %bb26
bb25:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb26
bb26:
  %t106 = load i1, ptr %l50, !tbaa !21
  br i1 %t106, label %bb27, label %bb28
bb27:
  %t107 = load ptr, ptr %l2, !tbaa !29
  %t109 = getelementptr %"compiler/ast:TopIf", ptr %t107, i32 0, i32 3
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = icmp eq ptr %t110, null
  br i1 %t112, label %bb29, label %bb30
bb28:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb32
bb29:
  call void @__olang_check_failed(ptr @olang_loc_17f9884e4c50a862_1761fccd5f6f3c76)
  unreachable
bb30:
  br label %bb31
bb31:
  %t114 = load ptr, ptr %l2, !tbaa !29
  %t116 = getelementptr %"compiler/ast:TopIf", ptr %t114, i32 0, i32 3
  %t117 = load ptr, ptr %t116, !tbaa !29
  %t120 = getelementptr %"compiler/ast:TopBranch", ptr %t117, i32 0, i32 1
  %t121 = load { i64, ptr }, ptr %t120, !tbaa !27
  %t123 = extractvalue { i64, ptr } %t121, 0
  %t125 = icmp sgt i64 %t123, 0
  store i1 %t125, ptr %l55, !tbaa !21
  br label %bb32
bb32:
  %t127 = load i1, ptr %l55, !tbaa !21
  br i1 %t127, label %bb33, label %bb34
bb33:
  %t128 = load ptr, ptr %l0, !tbaa !29
  store ptr %t128, ptr %l65, !tbaa !29
  %t129 = load i64, ptr %l1, !tbaa !24
  store i64 %t129, ptr %l66, !tbaa !24
  %t130 = load ptr, ptr %l2, !tbaa !29
  %t132 = getelementptr %"compiler/ast:TopIf", ptr %t130, i32 0, i32 3
  %t133 = load ptr, ptr %t132, !tbaa !29
  %t135 = icmp eq ptr %t133, null
  br i1 %t135, label %bb35, label %bb36
bb34:
  br label %bb39
bb35:
  call void @__olang_check_failed(ptr @olang_loc_17f9884e4c50a862_1761fccd5f6f3c76)
  unreachable
bb36:
  br label %bb37
bb37:
  %t137 = load ptr, ptr %l2, !tbaa !29
  %t139 = getelementptr %"compiler/ast:TopIf", ptr %t137, i32 0, i32 3
  %t140 = load ptr, ptr %t139, !tbaa !29
  %t143 = getelementptr %"compiler/ast:TopBranch", ptr %t140, i32 0, i32 1
  %t144 = load { i64, ptr }, ptr %t143, !tbaa !27
  %t145 = load ptr, ptr %l65, !tbaa !29
  %t146 = load i64, ptr %l66, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edecls(ptr %v0, ptr %v1, ptr %t145, i64 %t146, { i64, ptr } %t144)
  br label %bb38
bb38:
  br label %bb39
bb39:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edestructs(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i32
  %l12 = alloca i1
  %l13 = alloca i1
  %l18 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l5, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t11 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t7, i32 %a1)
  store i32 %t11, ptr %l8
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l5, !tbaa !29
  %t13 = load i32, ptr %l8, !tbaa !23
  %t14 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t14, ptr %l9
  br label %bb2
bb2:
  %t15 = load i32, ptr %l9, !tbaa !23
  store i32 %t15, ptr %l2, !tbaa !23
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l2, !tbaa !23
  %t20 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %t16, i32 %t17)
  store i1 %t20, ptr %l12
  br label %bb3
bb3:
  %t21 = load i1, ptr %l12, !tbaa !21
  br i1 %t21, label %bb4, label %bb5
bb4:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 2
  %t28 = load i32, ptr %l2, !tbaa !23
  %t31 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %t27, i32 %t28)
  store i1 %t31, ptr %l18
  br label %bb6
bb5:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb7
bb6:
  %t32 = load i1, ptr %l18, !tbaa !21
  store i1 %t32, ptr %l13, !tbaa !21
  br label %bb7
bb7:
  %t33 = load i1, ptr %l13, !tbaa !21
  store i1 %t33, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropTaken(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i64
  %l4 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l12 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca i64
  %l16 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l19 = alloca i64
  %l23 = alloca i64
  %l26 = alloca i64
  %l46 = alloca i32
  %l50 = alloca i32
  %l61 = alloca i64
  %l63 = alloca i64
  %l68 = alloca i32
  %s0 = alloca %olang.scope
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l16
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l16
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l4
  %t3 = load i64, ptr %l2, !tbaa !24
  store i64 %t3, ptr %l5, !tbaa !24
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t5)
  store i64 %t7, ptr %l19
  br label %bb2
bb2:
  %t8 = load i64, ptr %l19, !tbaa !24
  store i64 %t8, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t9 = load i64, ptr %l6, !tbaa !24
  %t10 = load i64, ptr %l5, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load i64, ptr %l7, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb8
bb5:
  %t19 = load i64, ptr %l6, !tbaa !24
  %t20 = load i64, ptr %l5, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l7, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l7, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l26, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb7
bb7:
  %t35 = load i64, ptr %l26, !tbaa !24
  store i64 %t35, ptr %l23, !tbaa !24
  br label %bb8
bb8:
  %t36 = load i64, ptr %l23, !tbaa !24
  store i64 %t36, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb9
bb9:
  %t37 = load i64, ptr %l9, !tbaa !24
  %t38 = load i64, ptr %l8, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb10, label %bb11
bb10:
  br label %bb20
bb11:
  br label %bb12
bb12:
  %t45 = load i64, ptr %l5, !tbaa !24
  %t46 = load i64, ptr %l9, !tbaa !24
  %t47 = load i64, ptr %l7, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t59 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t55, i64 %t53)
  store i32 %t59, ptr %l46
  br label %bb13
bb13:
  %t60 = load i32, ptr %l46, !tbaa !23
  %t67 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleft(ptr %v0, ptr %v2, ptr %a0, i32 %t60, ptr %a3)
  store i32 %t67, ptr %l50
  br label %bb14
bb14:
  %t68 = load i32, ptr %l50, !tbaa !23
  store i32 %t68, ptr %l12, !tbaa !23
  %t69 = load i32, ptr %l12, !tbaa !23
  %t70 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t73 = icmp ne i32 %t69, %t70
  br i1 %t73, label %bb15, label %bb16
bb15:
  %t75 = load i32, ptr %l12, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l4, i32 %t75)
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t78 = load i64, ptr %l9, !tbaa !24
  %t80 = add i64 %t78, 1
  store i64 %t80, ptr %l9, !tbaa !24
  br label %bb9
bb20:
  %t82 = load ptr, ptr %l1, !tbaa !29
  %t83 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eTruncate_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t82, i64 %t83)
  br label %bb21
bb21:
  store ptr %l4, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb22
bb22:
  %t87 = load i64, ptr %l14, !tbaa !24
  store i64 %t87, ptr %l61, !tbaa !24
  %t88 = load ptr, ptr %l13, !tbaa !29
  %t90 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t88)
  store i64 %t90, ptr %l63
  br label %bb23
bb23:
  %t91 = load i64, ptr %l61, !tbaa !24
  %t92 = load i64, ptr %l63, !tbaa !24
  %t93 = icmp slt i64 %t91, %t92
  %t95 = xor i1 %t93, true
  br i1 %t95, label %bb24, label %bb25
bb24:
  br label %bb30
bb25:
  br label %bb26
bb26:
  %t97 = load ptr, ptr %l13, !tbaa !29
  %t98 = load i64, ptr %l14, !tbaa !24
  %t101 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t97, i64 %t98)
  store i32 %t101, ptr %l68
  br label %bb27
bb27:
  %t102 = load i32, ptr %l68, !tbaa !23
  %t103 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t103, i32 %t102)
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t107 = load i64, ptr %l14, !tbaa !24
  %t109 = add i64 %t107, 1
  store i64 %t109, ptr %l14, !tbaa !24
  br label %bb22
bb30:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eequality(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca ptr
  %lp26 = alloca ptr
  %lp27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca i32
  %l32 = alloca ptr
  %l33 = alloca ptr
  %l34 = alloca i64
  %l35 = alloca ptr
  %l38 = alloca i32
  %l41 = alloca i32
  %l45 = alloca i1
  %l52 = alloca ptr
  %l55 = alloca ptr
  %l58 = alloca i32
  %l59 = alloca i1
  %l60 = alloca i1
  %l63 = alloca ptr
  %l66 = alloca i32
  %l67 = alloca i32
  %l70 = alloca ptr
  %l71 = alloca %"compiler/source:Span"
  %l74 = alloca i32
  %l75 = alloca ptr
  %l76 = alloca ptr
  %l77 = alloca %"compiler/source:Span"
  %l78 = alloca i32
  %l81 = alloca i32
  %l87 = alloca ptr
  %l93 = alloca ptr
  %l96 = alloca i32
  %l99 = alloca i32
  %l105 = alloca i1
  %l110 = alloca i1
  %l111 = alloca ptr
  %l112 = alloca ptr
  %l115 = alloca i1
  %l116 = alloca i1
  %l119 = alloca i1
  %l120 = alloca i32
  %l126 = alloca i32
  %l129 = alloca ptr
  %l132 = alloca i32
  %l137 = alloca i1
  %l138 = alloca ptr
  %l139 = alloca ptr
  %l142 = alloca i1
  %l143 = alloca i1
  %l146 = alloca i1
  %l147 = alloca i32
  %l153 = alloca i32
  %l156 = alloca ptr
  %l159 = alloca i32
  %l165 = alloca i32
  %l168 = alloca i1
  %l173 = alloca i32
  %l176 = alloca i1
  %l179 = alloca ptr
  %l184 = alloca i32
  %l189 = alloca i32
  %l190 = alloca i1
  %l193 = alloca ptr
  %l198 = alloca i32
  %l199 = alloca i32
  %l200 = alloca ptr
  %l201 = alloca ptr
  %l204 = alloca i1
  %l205 = alloca i1
  %l208 = alloca i1
  %l209 = alloca i32
  %l215 = alloca i32
  %l218 = alloca ptr
  %l219 = alloca ptr
  %l220 = alloca ptr
  %l223 = alloca i1
  %l224 = alloca i1
  %l227 = alloca i1
  %l228 = alloca i32
  %l234 = alloca i32
  %l237 = alloca ptr
  %l240 = alloca i32
  %l243 = alloca i32
  %l250 = alloca ptr
  %l251 = alloca %"compiler/source:Span"
  %l254 = alloca { i64, ptr }
  %l255 = alloca { i64, ptr }
  %l258 = alloca { i64, ptr }
  %l260 = alloca %"compiler/msgs:Msg"
  %l261 = alloca i64
  %l265 = alloca ptr
  %l268 = alloca i64
  %l274 = alloca ptr
  %l275 = alloca ptr
  %l279 = alloca %"compiler/source:Span"
  %l283 = alloca { i64, [3 x i64] }
  %l286 = alloca { i64, ptr }
  %l288 = alloca %"compiler/msgs:Msg"
  %l289 = alloca i64
  %l293 = alloca ptr
  %l296 = alloca i1
  %l299 = alloca i1
  %l300 = alloca i1
  %l303 = alloca i1
  %l304 = alloca i1
  %l309 = alloca i1
  %l310 = alloca i1
  %l315 = alloca i1
  %l318 = alloca i64
  %l324 = alloca i64
  %l339 = alloca i64
  %l349 = alloca ptr
  %l350 = alloca %"compiler/source:Span"
  %l351 = alloca i32
  %l352 = alloca i32
  %l356 = alloca ptr
  %l360 = alloca ptr
  %l362 = alloca ptr
  %l363 = alloca ptr
  %l364 = alloca %"compiler/source:Span"
  %l365 = alloca i32
  %l366 = alloca i32
  %l370 = alloca ptr
  %l374 = alloca ptr
  %l376 = alloca ptr
  %l377 = alloca ptr
  %l378 = alloca %"compiler/source:Span"
  %l379 = alloca i32
  %l380 = alloca i32
  %l384 = alloca ptr
  %l388 = alloca ptr
  %l390 = alloca ptr
  %l391 = alloca ptr
  %l392 = alloca %"compiler/source:Span"
  %l393 = alloca %"compiler/source:Span"
  %l398 = alloca i32
  %l404 = alloca ptr
  %l405 = alloca ptr
  %l406 = alloca %"compiler/source:Span"
  %l407 = alloca %"compiler/source:Span"
  %l412 = alloca i32
  %l418 = alloca ptr
  %l419 = alloca ptr
  %l420 = alloca %"compiler/source:Span"
  %l421 = alloca %"compiler/source:Span"
  %l422 = alloca i64
  %l424 = alloca ptr
  %l427 = alloca { i64, ptr }
  %l430 = alloca { i64, ptr }
  %l434 = alloca ptr
  %l435 = alloca %"compiler/source:Span"
  %l436 = alloca i32
  %l437 = alloca ptr
  %l441 = alloca ptr
  %l444 = alloca %"compiler/typed:Cond"
  %l447 = alloca %"compiler/source:Span"
  %l448 = alloca i32
  %l452 = alloca { i64, ptr }
  %l453 = alloca %"compiler/source:Span"
  %l454 = alloca i32
  %l459 = alloca %"compiler/typed:Cond"
  %l463 = alloca %"compiler/typed:Seq"
  %l468 = alloca ptr
  %l472 = alloca ptr
  %l476 = alloca ptr
  %l477 = alloca %"compiler/source:Span"
  %l478 = alloca %"compiler/source:Span"
  %l479 = alloca i64
  %l481 = alloca ptr
  %l484 = alloca { i64, ptr }
  %l487 = alloca { i64, ptr }
  %l491 = alloca ptr
  %l494 = alloca ptr
  %l498 = alloca ptr
  %l502 = alloca i1
  %l503 = alloca i1
  %l506 = alloca i1
  %l507 = alloca i1
  %l510 = alloca i1
  %l511 = alloca i1
  %l514 = alloca i1
  %l515 = alloca i1
  %l520 = alloca i32
  %l530 = alloca ptr
  %l533 = alloca ptr
  %l537 = alloca ptr
  %l541 = alloca i1
  %l547 = alloca ptr
  %l555 = alloca ptr
  %l558 = alloca ptr
  %l562 = alloca ptr
  %l566 = alloca i1
  %l567 = alloca i1
  %l570 = alloca i1
  %l571 = alloca i32
  %l577 = alloca i32
  %l581 = alloca i1
  %l582 = alloca i1
  %l585 = alloca i1
  %l586 = alloca i1
  %l591 = alloca i1
  %l592 = alloca i1
  %l597 = alloca i1
  %l602 = alloca i32
  %l607 = alloca ptr
  %l612 = alloca ptr
  %l615 = alloca i64
  %l622 = alloca ptr
  %l623 = alloca %"compiler/source:Span"
  %l624 = alloca i32
  %l628 = alloca ptr
  %l632 = alloca { i64, ptr }
  %l633 = alloca ptr
  %l636 = alloca ptr
  %l640 = alloca ptr
  %s1 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %rv = alloca ptr
  %t574 = alloca { i64, [2 x i64] }, align 8
  %t593 = alloca { i64, [3 x i64] }, align 8
  %t610 = alloca { i64, [2 x i64] }, align 8
  %t629 = alloca { i64, [3 x i64] }, align 8
  %t738 = alloca { i64, [4 x i64] }, align 8
  %t772 = alloca { i64, [4 x i64] }, align 8
  %t842 = alloca { i64, [5 x i64] }, align 8
  %t876 = alloca { i64, [5 x i64] }, align 8
  %t893 = alloca { i64, [5 x i64] }, align 8
  %t1219 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t1)
  store i32 %t4, ptr %l38
  br label %bb1
bb1:
  %t5 = load i32, ptr %l38, !tbaa !23
  store i32 %t5, ptr %l5, !tbaa !23
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t9 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t6)
  store i32 %t9, ptr %l41
  br label %bb2
bb2:
  %t10 = load i32, ptr %l41, !tbaa !23
  store i32 %t10, ptr %l6, !tbaa !23
  %t11 = load i32, ptr %l5, !tbaa !23
  %t12 = load i32, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  %t15 = icmp eq i32 %t11, %t12
  br i1 %t15, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l45, !tbaa !21
  br label %bb5
bb4:
  %t17 = load i32, ptr %l6, !tbaa !23
  %t18 = load i32, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  %t21 = icmp eq i32 %t17, %t18
  store i1 %t21, ptr %l45, !tbaa !21
  br label %bb5
bb5:
  %t23 = load i1, ptr %l45, !tbaa !21
  br i1 %t23, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t24 = load i32, ptr %l5, !tbaa !23
  %t25 = load i32, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  %t28 = icmp ne i32 %t24, %t25
  br i1 %t28, label %bb8, label %bb9
bb7:
  br label %bb29
bb8:
  %t30 = load ptr, ptr %l3, !tbaa !29
  store ptr %t30, ptr %l52, !tbaa !29
  br label %bb10
bb9:
  %t32 = load ptr, ptr %l4, !tbaa !29
  store ptr %t32, ptr %l52, !tbaa !29
  br label %bb10
bb10:
  %t34 = load ptr, ptr %l52, !tbaa !29
  store ptr %t34, ptr %l7, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l55, !tbaa !29
  %t36 = load ptr, ptr %l7, !tbaa !29
  %t39 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t36)
  store i32 %t39, ptr %l58
  br label %bb11
bb11:
  %t40 = load ptr, ptr %l55, !tbaa !29
  %t41 = load i32, ptr %l58, !tbaa !23
  %t42 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t40, i32 %t41)
  store i1 %t42, ptr %l59
  br label %bb12
bb12:
  %t43 = load i1, ptr %l59, !tbaa !21
  br i1 %t43, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb17
bb14:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/check:Checker", ptr %t44, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/generic:Program", ptr %t47, i32 0, i32 2
  store ptr %t49, ptr %l63, !tbaa !29
  %t50 = load ptr, ptr %l7, !tbaa !29
  %t53 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t50)
  store i32 %t53, ptr %l66
  br label %bb15
bb15:
  %t54 = load ptr, ptr %l63, !tbaa !29
  %t55 = load i32, ptr %l66, !tbaa !23
  %t56 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t54, i32 %t55)
  store i32 %t56, ptr %l67
  br label %bb16
bb16:
  %t57 = load i32, ptr %l67, !range !{i32 0, i32 33}
  %t59 = trunc i64 21 to i32
  %t60 = icmp eq i32 %t57, %t59
  store i1 %t60, ptr %l60, !tbaa !21
  br label %bb17
bb17:
  %t62 = load i1, ptr %l60, !tbaa !21
  br i1 %t62, label %bb18, label %bb19
bb18:
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l70, !tbaa !29
  %t64 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t64, ptr %l71
  %t65 = load ptr, ptr %l7, !tbaa !29
  %t68 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t65)
  store i32 %t68, ptr %l74
  br label %bb20
bb19:
  br label %bb26
bb20:
  %t69 = load ptr, ptr %l70, !tbaa !29
  %t70 = load %"compiler/source:Span", ptr %l71
  %t71 = load i32, ptr %l74, !tbaa !23
  %t72 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t69, %"compiler/source:Span" %t70, i32 %t71, i64 0)
  store ptr %t72, ptr %l75
  br label %bb21
bb21:
  %t73 = load ptr, ptr %l75, !tbaa !29
  store ptr %t73, ptr %l8, !tbaa !29
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l76, !tbaa !29
  %t75 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t75, ptr %l77
  %t76 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t76, ptr %l78, !tbaa !23
  %t77 = load i32, ptr %l2, !range !{i32 0, i32 96}
  %t79 = trunc i64 76 to i32
  %t80 = icmp eq i32 %t77, %t79
  br i1 %t80, label %bb22, label %bb23
bb22:
  store i32 19, ptr %l81
  br label %bb24
bb23:
  store i32 14, ptr %l81
  br label %bb24
bb24:
  %t84 = load ptr, ptr %l7, !tbaa !29
  %t85 = load ptr, ptr %l8, !tbaa !29
  %t87 = load ptr, ptr %l76, !tbaa !29
  %t88 = load %"compiler/source:Span", ptr %l77
  %t89 = load i32, ptr %l78, !tbaa !23
  %t90 = load i32, ptr %l81, !range !{i32 0, i32 43}
  %t93 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t87, %"compiler/source:Span" %t88, i32 %t89, i32 %t90, ptr %t84, ptr %t85)
  store ptr %t93, ptr %l87
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s1)
  %t94 = load ptr, ptr %l87, !tbaa !29
  store ptr %t94, ptr %rv
  br label %ret
bb26:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s1, ptr %t95, %"compiler/source:Span" %t96, { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d2, i32 0, i32 1) })
  br label %bb27
bb27:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load %"compiler/source:Span", ptr %l1
  %t101 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t105 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t99, %"compiler/source:Span" %t100, i32 %t101, i64 0)
  store ptr %t105, ptr %l93
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s1)
  %t106 = load ptr, ptr %l93, !tbaa !29
  store ptr %t106, ptr %rv
  br label %ret
bb29:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load i32, ptr %l5, !tbaa !23
  %t111 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t107, i32 %t108)
  store i32 %t111, ptr %l96
  br label %bb30
bb30:
  %t112 = load i32, ptr %l96, !tbaa !23
  store i32 %t112, ptr %l9, !tbaa !23
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load i32, ptr %l6, !tbaa !23
  %t117 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t113, i32 %t114)
  store i32 %t117, ptr %l99
  br label %bb31
bb31:
  %t118 = load i32, ptr %l99, !tbaa !23
  store i32 %t118, ptr %l10, !tbaa !23
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/check:Checker", ptr %t119, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !29
  %t124 = getelementptr %"compiler/generic:Program", ptr %t122, i32 0, i32 2
  %t125 = load i32, ptr %l9, !tbaa !23
  %t126 = load i32, ptr %l10, !tbaa !23
  %t130 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t124, i32 %t125, i32 %t126)
  store i1 %t130, ptr %l105
  br label %bb32
bb32:
  %t131 = load i1, ptr %l105, !tbaa !21
  %t132 = xor i1 %t131, true
  br i1 %t132, label %bb33, label %bb34
bb33:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load i32, ptr %l9, !tbaa !23
  %t136 = load i32, ptr %l10, !tbaa !23
  %t140 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eflowsInto(ptr %v0, ptr %t134, i32 %t135, i32 %t136)
  store i1 %t140, ptr %l110
  br label %bb35
bb34:
  br label %bb108
bb35:
  %t141 = load i1, ptr %l110, !tbaa !21
  br i1 %t141, label %bb36, label %bb37
bb36:
  %t142 = load ptr, ptr %l0, !tbaa !29
  store ptr %t142, ptr %l111, !tbaa !29
  %t143 = load ptr, ptr %l3, !tbaa !29
  store ptr %t143, ptr %l112, !tbaa !29
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t145 = load i32, ptr %l5, !tbaa !23
  %t148 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t144, i32 %t145)
  store i1 %t148, ptr %l115
  br label %bb38
bb37:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load i32, ptr %l10, !tbaa !23
  %t151 = load i32, ptr %l9, !tbaa !23
  %t155 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eflowsInto(ptr %v0, ptr %t149, i32 %t150, i32 %t151)
  store i1 %t155, ptr %l137
  br label %bb49
bb38:
  %t156 = load i1, ptr %l115, !tbaa !21
  br i1 %t156, label %bb39, label %bb40
bb39:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load i32, ptr %l6, !tbaa !23
  %t161 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t157, i32 %t158)
  store i1 %t161, ptr %l119
  br label %bb41
bb40:
  store i1 false, ptr %l116, !tbaa !21
  br label %bb42
bb41:
  %t162 = load i1, ptr %l119, !tbaa !21
  store i1 %t162, ptr %l116, !tbaa !21
  br label %bb42
bb42:
  %t163 = load i1, ptr %l116, !tbaa !21
  br i1 %t163, label %bb43, label %bb44
bb43:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/check:Checker", ptr %t164, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !29
  %t169 = getelementptr %"compiler/generic:Program", ptr %t167, i32 0, i32 2
  %t170 = load i32, ptr %l10, !tbaa !23
  %t171 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t175 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t169, i32 %t170, i64 %t171)
  store i32 %t175, ptr %l126
  br label %bb45
bb44:
  %t176 = load i32, ptr %l10, !tbaa !23
  store i32 %t176, ptr %l120, !tbaa !23
  br label %bb46
bb45:
  %t178 = load i32, ptr %l126, !tbaa !23
  store i32 %t178, ptr %l120, !tbaa !23
  br label %bb46
bb46:
  %t179 = load %"compiler/source:Span", ptr %l1
  %t180 = load ptr, ptr %l111, !tbaa !29
  %t181 = load ptr, ptr %l112, !tbaa !29
  %t182 = load i32, ptr %l120, !tbaa !23
  %t184 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t180, ptr %t181, i32 %t182, %"compiler/source:Span" %t179)
  store ptr %t184, ptr %l129
  br label %bb47
bb47:
  %t185 = load ptr, ptr %l129, !tbaa !29
  store ptr %t185, ptr %l3, !tbaa !29
  %t186 = load ptr, ptr %l3, !tbaa !29
  %t189 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t186)
  store i32 %t189, ptr %l132
  br label %bb48
bb48:
  %t190 = load i32, ptr %l132, !tbaa !23
  store i32 %t190, ptr %l5, !tbaa !23
  %t191 = load i32, ptr %l10, !tbaa !23
  store i32 %t191, ptr %l9, !tbaa !23
  br label %bb107
bb49:
  %t193 = load i1, ptr %l137, !tbaa !21
  br i1 %t193, label %bb50, label %bb51
bb50:
  %t194 = load ptr, ptr %l0, !tbaa !29
  store ptr %t194, ptr %l138, !tbaa !29
  %t195 = load ptr, ptr %l4, !tbaa !29
  store ptr %t195, ptr %l139, !tbaa !29
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t197 = load i32, ptr %l5, !tbaa !23
  %t200 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t196, i32 %t197)
  store i1 %t200, ptr %l142
  br label %bb52
bb51:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t203 = getelementptr %"compiler/check:Checker", ptr %t201, i32 0, i32 1
  %t204 = load ptr, ptr %t203, !tbaa !29
  %t206 = getelementptr %"compiler/generic:Program", ptr %t204, i32 0, i32 2
  %t207 = load i32, ptr %l9, !tbaa !23
  %t210 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t206, i32 %t207)
  store i32 %t210, ptr %l165
  br label %bb63
bb52:
  %t211 = load i1, ptr %l142, !tbaa !21
  br i1 %t211, label %bb53, label %bb54
bb53:
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t213 = load i32, ptr %l6, !tbaa !23
  %t216 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t212, i32 %t213)
  store i1 %t216, ptr %l146
  br label %bb55
bb54:
  store i1 false, ptr %l143, !tbaa !21
  br label %bb56
bb55:
  %t217 = load i1, ptr %l146, !tbaa !21
  store i1 %t217, ptr %l143, !tbaa !21
  br label %bb56
bb56:
  %t218 = load i1, ptr %l143, !tbaa !21
  br i1 %t218, label %bb57, label %bb58
bb57:
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t221 = getelementptr %"compiler/check:Checker", ptr %t219, i32 0, i32 1
  %t222 = load ptr, ptr %t221, !tbaa !29
  %t224 = getelementptr %"compiler/generic:Program", ptr %t222, i32 0, i32 2
  %t225 = load i32, ptr %l9, !tbaa !23
  %t226 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t230 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t224, i32 %t225, i64 %t226)
  store i32 %t230, ptr %l153
  br label %bb59
bb58:
  %t231 = load i32, ptr %l9, !tbaa !23
  store i32 %t231, ptr %l147, !tbaa !23
  br label %bb60
bb59:
  %t233 = load i32, ptr %l153, !tbaa !23
  store i32 %t233, ptr %l147, !tbaa !23
  br label %bb60
bb60:
  %t234 = load %"compiler/source:Span", ptr %l1
  %t235 = load ptr, ptr %l138, !tbaa !29
  %t236 = load ptr, ptr %l139, !tbaa !29
  %t237 = load i32, ptr %l147, !tbaa !23
  %t239 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t235, ptr %t236, i32 %t237, %"compiler/source:Span" %t234)
  store ptr %t239, ptr %l156
  br label %bb61
bb61:
  %t240 = load ptr, ptr %l156, !tbaa !29
  store ptr %t240, ptr %l4, !tbaa !29
  %t241 = load ptr, ptr %l4, !tbaa !29
  %t244 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t241)
  store i32 %t244, ptr %l159
  br label %bb62
bb62:
  %t245 = load i32, ptr %l159, !tbaa !23
  store i32 %t245, ptr %l6, !tbaa !23
  %t246 = load i32, ptr %l9, !tbaa !23
  store i32 %t246, ptr %l10, !tbaa !23
  br label %bb106
bb63:
  %t248 = load i32, ptr %l165, !range !{i32 0, i32 33}
  %t250 = trunc i64 19 to i32
  %t251 = icmp eq i32 %t248, %t250
  br i1 %t251, label %bb64, label %bb65
bb64:
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t255 = getelementptr %"compiler/check:Checker", ptr %t253, i32 0, i32 1
  %t256 = load ptr, ptr %t255, !tbaa !29
  %t258 = getelementptr %"compiler/generic:Program", ptr %t256, i32 0, i32 2
  %t259 = load i32, ptr %l10, !tbaa !23
  %t262 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t258, i32 %t259)
  store i32 %t262, ptr %l173
  br label %bb66
bb65:
  store i1 false, ptr %l168, !tbaa !21
  br label %bb67
bb66:
  %t263 = load i32, ptr %l173, !range !{i32 0, i32 33}
  %t265 = trunc i64 19 to i32
  %t266 = icmp eq i32 %t263, %t265
  store i1 %t266, ptr %l168, !tbaa !21
  br label %bb67
bb67:
  %t268 = load i1, ptr %l168, !tbaa !21
  br i1 %t268, label %bb68, label %bb69
bb68:
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t271 = getelementptr %"compiler/check:Checker", ptr %t269, i32 0, i32 1
  %t272 = load ptr, ptr %t271, !tbaa !29
  %t274 = getelementptr %"compiler/generic:Program", ptr %t272, i32 0, i32 2
  store ptr %t274, ptr %l179, !tbaa !29
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t277 = getelementptr %"compiler/check:Checker", ptr %t275, i32 0, i32 1
  %t278 = load ptr, ptr %t277, !tbaa !29
  %t280 = getelementptr %"compiler/generic:Program", ptr %t278, i32 0, i32 2
  %t281 = load i32, ptr %l9, !tbaa !23
  %t284 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t280, i32 %t281)
  store i32 %t284, ptr %l184
  br label %bb70
bb69:
  store i1 false, ptr %l176, !tbaa !21
  br label %bb73
bb70:
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t287 = getelementptr %"compiler/check:Checker", ptr %t285, i32 0, i32 1
  %t288 = load ptr, ptr %t287, !tbaa !29
  %t290 = getelementptr %"compiler/generic:Program", ptr %t288, i32 0, i32 2
  %t291 = load i32, ptr %l10, !tbaa !23
  %t294 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t290, i32 %t291)
  store i32 %t294, ptr %l189
  br label %bb71
bb71:
  %t295 = load ptr, ptr %l179, !tbaa !29
  %t296 = load i32, ptr %l184, !tbaa !23
  %t297 = load i32, ptr %l189, !tbaa !23
  %t298 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t295, i32 %t296, i32 %t297)
  store i1 %t298, ptr %l190
  br label %bb72
bb72:
  %t299 = load i1, ptr %l190, !tbaa !21
  store i1 %t299, ptr %l176, !tbaa !21
  br label %bb73
bb73:
  %t300 = load i1, ptr %l176, !tbaa !21
  br i1 %t300, label %bb74, label %bb75
bb74:
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t303 = getelementptr %"compiler/check:Checker", ptr %t301, i32 0, i32 1
  %t304 = load ptr, ptr %t303, !tbaa !29
  %t306 = getelementptr %"compiler/generic:Program", ptr %t304, i32 0, i32 2
  store ptr %t306, ptr %l193, !tbaa !29
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t309 = getelementptr %"compiler/check:Checker", ptr %t307, i32 0, i32 1
  %t310 = load ptr, ptr %t309, !tbaa !29
  %t312 = getelementptr %"compiler/generic:Program", ptr %t310, i32 0, i32 2
  %t313 = load i32, ptr %l9, !tbaa !23
  %t316 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t312, i32 %t313)
  store i32 %t316, ptr %l198
  br label %bb76
bb75:
  store %olang.scope zeroinitializer, ptr %s9
  %t317 = load ptr, ptr %l0, !tbaa !29
  store ptr %t317, ptr %l250, !tbaa !29
  %t318 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t318, ptr %l251
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t320 = load i32, ptr %l9, !tbaa !23
  %t323 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s9, ptr %t319, i32 %t320)
  store { i64, ptr } %t323, ptr %l254
  br label %bb100
bb76:
  %t324 = load ptr, ptr %l193, !tbaa !29
  %t325 = load i32, ptr %l198, !tbaa !23
  %t326 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t324, i32 %t325, i32 0)
  store i32 %t326, ptr %l199
  br label %bb77
bb77:
  %t327 = load i32, ptr %l199, !tbaa !23
  store i32 %t327, ptr %l11, !tbaa !23
  %t328 = load ptr, ptr %l0, !tbaa !29
  store ptr %t328, ptr %l200, !tbaa !29
  %t329 = load ptr, ptr %l3, !tbaa !29
  store ptr %t329, ptr %l201, !tbaa !29
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t331 = load i32, ptr %l5, !tbaa !23
  %t334 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t330, i32 %t331)
  store i1 %t334, ptr %l204
  br label %bb78
bb78:
  %t335 = load i1, ptr %l204, !tbaa !21
  br i1 %t335, label %bb79, label %bb80
bb79:
  %t336 = load ptr, ptr %l0, !tbaa !29
  %t337 = load i32, ptr %l6, !tbaa !23
  %t340 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t336, i32 %t337)
  store i1 %t340, ptr %l208
  br label %bb81
bb80:
  store i1 false, ptr %l205, !tbaa !21
  br label %bb82
bb81:
  %t341 = load i1, ptr %l208, !tbaa !21
  store i1 %t341, ptr %l205, !tbaa !21
  br label %bb82
bb82:
  %t342 = load i1, ptr %l205, !tbaa !21
  br i1 %t342, label %bb83, label %bb84
bb83:
  %t343 = load ptr, ptr %l0, !tbaa !29
  %t345 = getelementptr %"compiler/check:Checker", ptr %t343, i32 0, i32 1
  %t346 = load ptr, ptr %t345, !tbaa !29
  %t348 = getelementptr %"compiler/generic:Program", ptr %t346, i32 0, i32 2
  %t349 = load i32, ptr %l11, !tbaa !23
  %t350 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t354 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t348, i32 %t349, i64 %t350)
  store i32 %t354, ptr %l215
  br label %bb85
bb84:
  %t355 = load i32, ptr %l11, !tbaa !23
  store i32 %t355, ptr %l209, !tbaa !23
  br label %bb86
bb85:
  %t357 = load i32, ptr %l215, !tbaa !23
  store i32 %t357, ptr %l209, !tbaa !23
  br label %bb86
bb86:
  %t358 = load %"compiler/source:Span", ptr %l1
  %t359 = load ptr, ptr %l200, !tbaa !29
  %t360 = load ptr, ptr %l201, !tbaa !29
  %t361 = load i32, ptr %l209, !tbaa !23
  %t363 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t359, ptr %t360, i32 %t361, %"compiler/source:Span" %t358)
  store ptr %t363, ptr %l218
  br label %bb87
bb87:
  %t364 = load ptr, ptr %l218, !tbaa !29
  store ptr %t364, ptr %l3, !tbaa !29
  %t365 = load ptr, ptr %l0, !tbaa !29
  store ptr %t365, ptr %l219, !tbaa !29
  %t366 = load ptr, ptr %l4, !tbaa !29
  store ptr %t366, ptr %l220, !tbaa !29
  %t367 = load ptr, ptr %l0, !tbaa !29
  %t368 = load i32, ptr %l5, !tbaa !23
  %t371 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t367, i32 %t368)
  store i1 %t371, ptr %l223
  br label %bb88
bb88:
  %t372 = load i1, ptr %l223, !tbaa !21
  br i1 %t372, label %bb89, label %bb90
bb89:
  %t373 = load ptr, ptr %l0, !tbaa !29
  %t374 = load i32, ptr %l6, !tbaa !23
  %t377 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t373, i32 %t374)
  store i1 %t377, ptr %l227
  br label %bb91
bb90:
  store i1 false, ptr %l224, !tbaa !21
  br label %bb92
bb91:
  %t378 = load i1, ptr %l227, !tbaa !21
  store i1 %t378, ptr %l224, !tbaa !21
  br label %bb92
bb92:
  %t379 = load i1, ptr %l224, !tbaa !21
  br i1 %t379, label %bb93, label %bb94
bb93:
  %t380 = load ptr, ptr %l0, !tbaa !29
  %t382 = getelementptr %"compiler/check:Checker", ptr %t380, i32 0, i32 1
  %t383 = load ptr, ptr %t382, !tbaa !29
  %t385 = getelementptr %"compiler/generic:Program", ptr %t383, i32 0, i32 2
  %t386 = load i32, ptr %l11, !tbaa !23
  %t387 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t391 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t385, i32 %t386, i64 %t387)
  store i32 %t391, ptr %l234
  br label %bb95
bb94:
  %t392 = load i32, ptr %l11, !tbaa !23
  store i32 %t392, ptr %l228, !tbaa !23
  br label %bb96
bb95:
  %t394 = load i32, ptr %l234, !tbaa !23
  store i32 %t394, ptr %l228, !tbaa !23
  br label %bb96
bb96:
  %t395 = load %"compiler/source:Span", ptr %l1
  %t396 = load ptr, ptr %l219, !tbaa !29
  %t397 = load ptr, ptr %l220, !tbaa !29
  %t398 = load i32, ptr %l228, !tbaa !23
  %t400 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t396, ptr %t397, i32 %t398, %"compiler/source:Span" %t395)
  store ptr %t400, ptr %l237
  br label %bb97
bb97:
  %t401 = load ptr, ptr %l237, !tbaa !29
  store ptr %t401, ptr %l4, !tbaa !29
  %t402 = load ptr, ptr %l3, !tbaa !29
  %t405 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t402)
  store i32 %t405, ptr %l240
  br label %bb98
bb98:
  %t406 = load i32, ptr %l240, !tbaa !23
  store i32 %t406, ptr %l12, !tbaa !23
  %t407 = load ptr, ptr %l4, !tbaa !29
  %t410 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t407)
  store i32 %t410, ptr %l243
  br label %bb99
bb99:
  %t411 = load i32, ptr %l243, !tbaa !23
  %t412 = load i32, ptr %l12, !tbaa !23
  store i32 %t412, ptr %l5, !tbaa !23
  store i32 %t411, ptr %l6, !tbaa !23
  %t416 = load i32, ptr %l11, !tbaa !23
  %t418 = load i32, ptr %l11, !tbaa !23
  store i32 %t416, ptr %l9, !tbaa !23
  store i32 %t418, ptr %l10, !tbaa !23
  br label %bb105
bb100:
  %t424 = load { i64, ptr }, ptr %l254, !tbaa !27
  %t425 = extractvalue { i64, ptr } %t424, 0
  %t426 = extractvalue { i64, ptr } %t424, 1
  %t427 = mul i64 %t425, 1
  %t428 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t427)
  call void @llvm.memcpy.p0.p0.i64(ptr %t428, ptr %t426, i64 %t427, i1 false)
  %t429 = insertvalue { i64, ptr } undef, i64 %t425, 0
  %t430 = insertvalue { i64, ptr } %t429, ptr %t428, 1
  store { i64, ptr } %t430, ptr %l255, !tbaa !27
  %t431 = load ptr, ptr %l0, !tbaa !29
  %t432 = load i32, ptr %l10, !tbaa !23
  %t435 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s9, ptr %t431, i32 %t432)
  store { i64, ptr } %t435, ptr %l258
  br label %bb101
bb101:
  %t436 = load { i64, ptr }, ptr %l258, !tbaa !27
  %t437 = extractvalue { i64, ptr } %t436, 0
  %t438 = extractvalue { i64, ptr } %t436, 1
  %t439 = mul i64 %t437, 1
  %t440 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t439)
  call void @llvm.memcpy.p0.p0.i64(ptr %t440, ptr %t438, i64 %t439, i1 false)
  %t441 = insertvalue { i64, ptr } undef, i64 %t437, 0
  %t442 = insertvalue { i64, ptr } %t441, ptr %t440, 1
  %t443 = load { i64, ptr }, ptr %l255, !tbaa !27
  %t445 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeMismatch(ptr %s9, ptr %s9, ptr %s9, { i64, ptr } %t443, { i64, ptr } %t442)
  store %"compiler/msgs:Msg" %t445, ptr %l260
  br label %bb102
bb102:
  %t446 = load ptr, ptr %l250, !tbaa !29
  %t447 = load %"compiler/source:Span", ptr %l251
  %t448 = load %"compiler/msgs:Msg", ptr %l260
  %t449 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s9, ptr %t446, %"compiler/source:Span" %t447, %"compiler/msgs:Msg" %t448)
  store i64 %t449, ptr %l261
  br label %bb103
bb103:
  %t450 = load ptr, ptr %l0, !tbaa !29
  %t451 = load %"compiler/source:Span", ptr %l1
  %t452 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t456 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t450, %"compiler/source:Span" %t451, i32 %t452, i64 0)
  store ptr %t456, ptr %l265
  br label %bb104
bb104:
  call void @__olang_scope_close(ptr %s9)
  %t457 = load ptr, ptr %l265, !tbaa !29
  store ptr %t457, ptr %rv
  br label %ret
bb105:
  br label %bb106
bb106:
  br label %bb107
bb107:
  br label %bb108
bb108:
  %t458 = load ptr, ptr %l0, !tbaa !29
  %t459 = load i32, ptr %l9, !tbaa !23
  %t462 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeqMethod(ptr %v0, ptr %t458, i32 %t459)
  store i64 %t462, ptr %l268
  br label %bb109
bb109:
  %t463 = load i64, ptr %l268, !tbaa !24
  store i64 %t463, ptr %l16, !tbaa !24
  %t464 = load i64, ptr %l16, !tbaa !24
  %t466 = icmp eq i64 %t464, -2
  br i1 %t466, label %bb110, label %bb111
bb110:
  store %olang.scope zeroinitializer, ptr %s10
  %t468 = load ptr, ptr %l0, !tbaa !29
  %t470 = getelementptr %"compiler/check:Checker", ptr %t468, i32 0, i32 1
  %t471 = load ptr, ptr %t470, !tbaa !29
  %t473 = getelementptr %"compiler/generic:Program", ptr %t471, i32 0, i32 0
  %t474 = load ptr, ptr %t473, !tbaa !29
  %t476 = getelementptr %"compiler/load:Loader", ptr %t474, i32 0, i32 4
  %t477 = load ptr, ptr %t476, !tbaa !29
  store ptr %t477, ptr %l274, !tbaa !29
  %t478 = load ptr, ptr %l0, !tbaa !29
  store ptr %t478, ptr %l275, !tbaa !29
  %t479 = load ptr, ptr %l0, !tbaa !29
  %t481 = getelementptr %"compiler/check:Checker", ptr %t479, i32 0, i32 44
  %t482 = getelementptr %"compiler/source:Span", ptr %t481, i32 0, i32 0
  %t483 = load i32, ptr %t482, !tbaa !23
  %t485 = icmp sge i32 %t483, 0
  br i1 %t485, label %bb112, label %bb113
bb111:
  br label %bb120
bb112:
  %t487 = load ptr, ptr %l0, !tbaa !29
  %t489 = getelementptr %"compiler/check:Checker", ptr %t487, i32 0, i32 44
  %t490 = load %"compiler/source:Span", ptr %t489
  store %"compiler/source:Span" %t490, ptr %l279
  br label %bb114
bb113:
  %t492 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t492, ptr %l279
  br label %bb114
bb114:
  %t494 = load ptr, ptr %l275, !tbaa !29
  %t495 = load %"compiler/source:Span", ptr %l279
  %t496 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t494, %"compiler/source:Span" %t495)
  store { i64, [3 x i64] } %t496, ptr %l283
  br label %bb115
bb115:
  %t497 = load ptr, ptr %l0, !tbaa !29
  %t498 = load i32, ptr %l9, !tbaa !23
  %t501 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s10, ptr %t497, i32 %t498)
  store { i64, ptr } %t501, ptr %l286
  br label %bb116
bb116:
  %t502 = load { i64, ptr }, ptr %l286, !tbaa !27
  %t503 = extractvalue { i64, ptr } %t502, 0
  %t504 = extractvalue { i64, ptr } %t502, 1
  %t505 = mul i64 %t503, 1
  %t506 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t505)
  call void @llvm.memcpy.p0.p0.i64(ptr %t506, ptr %t504, i64 %t505, i1 false)
  %t507 = insertvalue { i64, ptr } undef, i64 %t503, 0
  %t508 = insertvalue { i64, ptr } %t507, ptr %t506, 1
  %t510 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eProtocolPrivate(ptr %s10, ptr %s10, ptr %s10, ptr %s10, ptr %s10, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d3, i32 0, i32 1) }, { i64, ptr } %t508, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d4, i32 0, i32 1) }, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d5, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t510, ptr %l288
  br label %bb117
bb117:
  %t511 = load ptr, ptr %l274, !tbaa !29
  %t512 = load { i64, [3 x i64] }, ptr %l283
  %t513 = load %"compiler/msgs:Msg", ptr %l288
  %t514 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorOncePerLine(ptr %v0, ptr %s10, ptr %t511, { i64, [3 x i64] } %t512, %"compiler/msgs:Msg" %t513)
  store i64 %t514, ptr %l289
  br label %bb118
bb118:
  %t515 = load ptr, ptr %l0, !tbaa !29
  %t516 = load %"compiler/source:Span", ptr %l1
  %t517 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t521 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t515, %"compiler/source:Span" %t516, i32 %t517, i64 0)
  store ptr %t521, ptr %l293
  br label %bb119
bb119:
  call void @__olang_scope_close(ptr %s10)
  %t522 = load ptr, ptr %l293, !tbaa !29
  store ptr %t522, ptr %rv
  br label %ret
bb120:
  %t523 = load i64, ptr %l16, !tbaa !24
  %t525 = icmp sge i64 %t523, 0
  br i1 %t525, label %bb121, label %bb122
bb121:
  %t527 = load ptr, ptr %l0, !tbaa !29
  %t528 = load i32, ptr %l5, !tbaa !23
  %t531 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t527, i32 %t528)
  store i1 %t531, ptr %l299
  br label %bb123
bb122:
  store i1 false, ptr %l296, !tbaa !21
  br label %bb124
bb123:
  %t532 = load i1, ptr %l299, !tbaa !21
  store i1 %t532, ptr %l296, !tbaa !21
  br label %bb124
bb124:
  %t533 = load i1, ptr %l296, !tbaa !21
  br i1 %t533, label %bb125, label %bb126
bb125:
  %t534 = load ptr, ptr %l0, !tbaa !29
  %t535 = load i32, ptr %l6, !tbaa !23
  %t538 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t534, i32 %t535)
  store i1 %t538, ptr %l303
  br label %bb127
bb126:
  store i1 false, ptr %l300, !tbaa !21
  br label %bb128
bb127:
  %t539 = load i1, ptr %l303, !tbaa !21
  store i1 %t539, ptr %l300, !tbaa !21
  br label %bb128
bb128:
  %t540 = load i1, ptr %l300, !tbaa !21
  br i1 %t540, label %bb129, label %bb130
bb129:
  %t541 = load ptr, ptr %l0, !tbaa !29
  %t543 = getelementptr %"compiler/check:Checker", ptr %t541, i32 0, i32 1
  %t544 = load ptr, ptr %t543, !tbaa !29
  %t546 = getelementptr %"compiler/generic:Program", ptr %t544, i32 0, i32 2
  %t547 = load i32, ptr %l5, !tbaa !23
  %t550 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t546, i32 %t547)
  store i1 %t550, ptr %l309
  br label %bb131
bb130:
  store i1 false, ptr %l304, !tbaa !21
  br label %bb136
bb131:
  %t551 = load i1, ptr %l309, !tbaa !21
  br i1 %t551, label %bb132, label %bb133
bb132:
  store i1 true, ptr %l310, !tbaa !21
  br label %bb135
bb133:
  %t552 = load ptr, ptr %l0, !tbaa !29
  %t554 = getelementptr %"compiler/check:Checker", ptr %t552, i32 0, i32 1
  %t555 = load ptr, ptr %t554, !tbaa !29
  %t557 = getelementptr %"compiler/generic:Program", ptr %t555, i32 0, i32 2
  %t558 = load i32, ptr %l6, !tbaa !23
  %t561 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t557, i32 %t558)
  store i1 %t561, ptr %l315
  br label %bb134
bb134:
  %t562 = load i1, ptr %l315, !tbaa !21
  store i1 %t562, ptr %l310, !tbaa !21
  br label %bb135
bb135:
  %t563 = load i1, ptr %l310, !tbaa !21
  store i1 %t563, ptr %l304, !tbaa !21
  br label %bb136
bb136:
  %t564 = load i1, ptr %l304, !tbaa !21
  br i1 %t564, label %bb137, label %bb138
bb137:
  store %olang.scope zeroinitializer, ptr %s11
  %t565 = load ptr, ptr %l0, !tbaa !29
  %t567 = getelementptr %"compiler/check:Checker", ptr %t565, i32 0, i32 37
  %t569 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t567)
  store i64 %t569, ptr %l318
  br label %bb139
bb138:
  br label %bb176
bb139:
  %t570 = load i64, ptr %l318, !tbaa !24
  store i64 %t570, ptr %l17, !tbaa !24
  %t571 = load ptr, ptr %l0, !tbaa !29
  %t572 = load %"compiler/source:Span", ptr %l1
  %t573 = load i32, ptr %l5, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t574
  %t575 = getelementptr { i64, [2 x i64] }, ptr %t574, i32 0, i32 0
  store i64 5, ptr %t575
  %t576 = load { i64, [2 x i64] }, ptr %t574
  %t582 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t571, i32 0, %"compiler/source:Span" %t572, i32 %t573, i32 1, { i64, [2 x i64] } %t576)
  store i64 %t582, ptr %l324
  br label %bb140
bb140:
  %t583 = load i64, ptr %l324, !tbaa !24
  store i64 %t583, ptr %l18, !tbaa !24
  %t584 = load ptr, ptr %l0, !tbaa !29
  %t586 = getelementptr %"compiler/check:Checker", ptr %t584, i32 0, i32 37
  %t587 = load %"compiler/source:Span", ptr %l1
  %t588 = load i64, ptr %l18, !tbaa !24
  %t590 = trunc i64 %t588 to i32
  %t592 = load ptr, ptr %l3, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t593
  %t594 = getelementptr { i64, [3 x i64] }, ptr %t593, i32 0, i32 0
  store i64 0, ptr %t594
  %t596 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t587, 0
  %t598 = insertvalue { %"compiler/source:Span", i32, ptr } %t596, i32 %t590, 1
  %t600 = insertvalue { %"compiler/source:Span", i32, ptr } %t598, ptr %t592, 2
  %t601 = getelementptr { i64, [3 x i64] }, ptr %t593, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t600, ptr %t601
  %t602 = load { i64, [3 x i64] }, ptr %t593
  %t604 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t602, ptr %t604
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t586, ptr %t604)
  br label %bb141
bb141:
  %t607 = load ptr, ptr %l0, !tbaa !29
  %t608 = load %"compiler/source:Span", ptr %l1
  %t609 = load i32, ptr %l6, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t610
  %t611 = getelementptr { i64, [2 x i64] }, ptr %t610, i32 0, i32 0
  store i64 5, ptr %t611
  %t612 = load { i64, [2 x i64] }, ptr %t610
  %t618 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t607, i32 0, %"compiler/source:Span" %t608, i32 %t609, i32 1, { i64, [2 x i64] } %t612)
  store i64 %t618, ptr %l339
  br label %bb142
bb142:
  %t619 = load i64, ptr %l339, !tbaa !24
  store i64 %t619, ptr %l19, !tbaa !24
  %t620 = load ptr, ptr %l0, !tbaa !29
  %t622 = getelementptr %"compiler/check:Checker", ptr %t620, i32 0, i32 37
  %t623 = load %"compiler/source:Span", ptr %l1
  %t624 = load i64, ptr %l19, !tbaa !24
  %t626 = trunc i64 %t624 to i32
  %t628 = load ptr, ptr %l4, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t629
  %t630 = getelementptr { i64, [3 x i64] }, ptr %t629, i32 0, i32 0
  store i64 0, ptr %t630
  %t632 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t623, 0
  %t634 = insertvalue { %"compiler/source:Span", i32, ptr } %t632, i32 %t626, 1
  %t636 = insertvalue { %"compiler/source:Span", i32, ptr } %t634, ptr %t628, 2
  %t637 = getelementptr { i64, [3 x i64] }, ptr %t629, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t636, ptr %t637
  %t638 = load { i64, [3 x i64] }, ptr %t629
  %t640 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t638, ptr %t640
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t622, ptr %t640)
  br label %bb143
bb143:
  %t643 = load ptr, ptr %l0, !tbaa !29
  store ptr %t643, ptr %l349, !tbaa !29
  %t644 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t644, ptr %l350
  %t645 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t645, ptr %l351, !tbaa !23
  store i32 19, ptr %l352
  %t646 = load ptr, ptr %l0, !tbaa !29
  %t647 = load %"compiler/source:Span", ptr %l1
  %t648 = load i64, ptr %l18, !tbaa !24
  %t652 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t646, %"compiler/source:Span" %t647, i64 %t648)
  store ptr %t652, ptr %l356
  br label %bb144
bb144:
  %t653 = load ptr, ptr %l0, !tbaa !29
  %t654 = load %"compiler/source:Span", ptr %l1
  %t655 = load i32, ptr %l5, !tbaa !23
  %t659 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t653, %"compiler/source:Span" %t654, i32 %t655, i64 0)
  store ptr %t659, ptr %l360
  br label %bb145
bb145:
  %t660 = load ptr, ptr %l360, !tbaa !29
  %t661 = load ptr, ptr %l349, !tbaa !29
  %t662 = load %"compiler/source:Span", ptr %l350
  %t663 = load i32, ptr %l351, !tbaa !23
  %t664 = load i32, ptr %l352, !range !{i32 0, i32 43}
  %t665 = load ptr, ptr %l356, !tbaa !29
  %t667 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t661, %"compiler/source:Span" %t662, i32 %t663, i32 %t664, ptr %t665, ptr %t660)
  store ptr %t667, ptr %l362
  br label %bb146
bb146:
  %t668 = load ptr, ptr %l362, !tbaa !29
  store ptr %t668, ptr %l20, !tbaa !29
  %t669 = load ptr, ptr %l0, !tbaa !29
  store ptr %t669, ptr %l363, !tbaa !29
  %t670 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t670, ptr %l364
  %t671 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t671, ptr %l365, !tbaa !23
  store i32 19, ptr %l366
  %t672 = load ptr, ptr %l0, !tbaa !29
  %t673 = load %"compiler/source:Span", ptr %l1
  %t674 = load i64, ptr %l19, !tbaa !24
  %t678 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t672, %"compiler/source:Span" %t673, i64 %t674)
  store ptr %t678, ptr %l370
  br label %bb147
bb147:
  %t679 = load ptr, ptr %l0, !tbaa !29
  %t680 = load %"compiler/source:Span", ptr %l1
  %t681 = load i32, ptr %l6, !tbaa !23
  %t685 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t679, %"compiler/source:Span" %t680, i32 %t681, i64 0)
  store ptr %t685, ptr %l374
  br label %bb148
bb148:
  %t686 = load ptr, ptr %l374, !tbaa !29
  %t687 = load ptr, ptr %l363, !tbaa !29
  %t688 = load %"compiler/source:Span", ptr %l364
  %t689 = load i32, ptr %l365, !tbaa !23
  %t690 = load i32, ptr %l366, !range !{i32 0, i32 43}
  %t691 = load ptr, ptr %l370, !tbaa !29
  %t693 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t687, %"compiler/source:Span" %t688, i32 %t689, i32 %t690, ptr %t691, ptr %t686)
  store ptr %t693, ptr %l376
  br label %bb149
bb149:
  %t694 = load ptr, ptr %l376, !tbaa !29
  store ptr %t694, ptr %l21, !tbaa !29
  %t695 = load ptr, ptr %l0, !tbaa !29
  store ptr %t695, ptr %l377, !tbaa !29
  %t696 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t696, ptr %l378
  %t697 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t697, ptr %l379, !tbaa !23
  store i32 19, ptr %l380
  %t698 = load ptr, ptr %l0, !tbaa !29
  %t699 = load %"compiler/source:Span", ptr %l1
  %t700 = load i64, ptr %l19, !tbaa !24
  %t704 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t698, %"compiler/source:Span" %t699, i64 %t700)
  store ptr %t704, ptr %l384
  br label %bb150
bb150:
  %t705 = load ptr, ptr %l0, !tbaa !29
  %t706 = load %"compiler/source:Span", ptr %l1
  %t707 = load i32, ptr %l6, !tbaa !23
  %t711 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t705, %"compiler/source:Span" %t706, i32 %t707, i64 0)
  store ptr %t711, ptr %l388
  br label %bb151
bb151:
  %t712 = load ptr, ptr %l388, !tbaa !29
  %t713 = load ptr, ptr %l377, !tbaa !29
  %t714 = load %"compiler/source:Span", ptr %l378
  %t715 = load i32, ptr %l379, !tbaa !23
  %t716 = load i32, ptr %l380, !range !{i32 0, i32 43}
  %t717 = load ptr, ptr %l384, !tbaa !29
  %t719 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t713, %"compiler/source:Span" %t714, i32 %t715, i32 %t716, ptr %t717, ptr %t712)
  store ptr %t719, ptr %l390
  br label %bb152
bb152:
  %t720 = load ptr, ptr %l390, !tbaa !29
  store ptr %t720, ptr %l22, !tbaa !29
  %t721 = load ptr, ptr %l0, !tbaa !29
  store ptr %t721, ptr %l391, !tbaa !29
  %t722 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t722, ptr %l392
  %t723 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t723, ptr %l393
  %t724 = load ptr, ptr %l0, !tbaa !29
  %t726 = getelementptr %"compiler/check:Checker", ptr %t724, i32 0, i32 1
  %t727 = load ptr, ptr %t726, !tbaa !29
  %t729 = getelementptr %"compiler/generic:Program", ptr %t727, i32 0, i32 2
  %t730 = load i32, ptr %l5, !tbaa !23
  %t733 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNonNull(ptr %v0, ptr %t729, i32 %t730)
  store i32 %t733, ptr %l398
  br label %bb153
bb153:
  %t734 = load i64, ptr %l18, !tbaa !24
  %t736 = trunc i64 %t734 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t738
  %t739 = getelementptr { i64, [4 x i64] }, ptr %t738, i32 0, i32 0
  store i64 0, ptr %t739
  %t740 = load %"compiler/source:Span", ptr %l393
  %t741 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t740, 0
  %t742 = load i32, ptr %l398, !tbaa !23
  %t743 = insertvalue { %"compiler/source:Span", i32, i32 } %t741, i32 %t742, 1
  %t745 = insertvalue { %"compiler/source:Span", i32, i32 } %t743, i32 %t736, 2
  %t746 = getelementptr { i64, [4 x i64] }, ptr %t738, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t745, ptr %t746
  %t747 = load { i64, [4 x i64] }, ptr %t738
  %t749 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t747, ptr %t749
  %t750 = load ptr, ptr %l391, !tbaa !29
  %t751 = load %"compiler/source:Span", ptr %l392
  %t753 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t750, %"compiler/source:Span" %t751, ptr %t749)
  store ptr %t753, ptr %l404
  br label %bb154
bb154:
  %t754 = load ptr, ptr %l404, !tbaa !29
  store ptr %t754, ptr %l23, !tbaa !29
  %t755 = load ptr, ptr %l0, !tbaa !29
  store ptr %t755, ptr %l405, !tbaa !29
  %t756 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t756, ptr %l406
  %t757 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t757, ptr %l407
  %t758 = load ptr, ptr %l0, !tbaa !29
  %t760 = getelementptr %"compiler/check:Checker", ptr %t758, i32 0, i32 1
  %t761 = load ptr, ptr %t760, !tbaa !29
  %t763 = getelementptr %"compiler/generic:Program", ptr %t761, i32 0, i32 2
  %t764 = load i32, ptr %l6, !tbaa !23
  %t767 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNonNull(ptr %v0, ptr %t763, i32 %t764)
  store i32 %t767, ptr %l412
  br label %bb155
bb155:
  %t768 = load i64, ptr %l19, !tbaa !24
  %t770 = trunc i64 %t768 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t772
  %t773 = getelementptr { i64, [4 x i64] }, ptr %t772, i32 0, i32 0
  store i64 0, ptr %t773
  %t774 = load %"compiler/source:Span", ptr %l407
  %t775 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t774, 0
  %t776 = load i32, ptr %l412, !tbaa !23
  %t777 = insertvalue { %"compiler/source:Span", i32, i32 } %t775, i32 %t776, 1
  %t779 = insertvalue { %"compiler/source:Span", i32, i32 } %t777, i32 %t770, 2
  %t780 = getelementptr { i64, [4 x i64] }, ptr %t772, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t779, ptr %t780
  %t781 = load { i64, [4 x i64] }, ptr %t772
  %t783 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t781, ptr %t783
  %t784 = load ptr, ptr %l405, !tbaa !29
  %t785 = load %"compiler/source:Span", ptr %l406
  %t787 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t784, %"compiler/source:Span" %t785, ptr %t783)
  store ptr %t787, ptr %l418
  br label %bb156
bb156:
  %t788 = load ptr, ptr %l418, !tbaa !29
  store ptr %t788, ptr %l24, !tbaa !29
  %t789 = load ptr, ptr %l0, !tbaa !29
  store ptr %t789, ptr %l419, !tbaa !29
  %t790 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t790, ptr %l420
  %t791 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t791, ptr %l421
  %t792 = load i64, ptr %l16, !tbaa !24
  store i64 %t792, ptr %l422, !tbaa !24
  %t793 = load ptr, ptr %l23, !tbaa !29
  store ptr %t793, ptr %l424, !tbaa !29
  %t795 = icmp sge i64 0, 0
  br i1 %t795, label %bb157, label %bb158
bb157:
  %t797 = icmp sle i64 0, 1152921504606846975
  br i1 %t797, label %bb159, label %bb160
bb158:
  call void @__olang_check_failed(ptr @olang_loc_1c2cb6c96b4eaee8_c1b953befa7e1dc)
  unreachable
bb159:
  %t799 = mul i64 0, 8
  %t800 = insertvalue { i64, ptr } undef, i64 0, 0
  %t801 = insertvalue { i64, ptr } %t800, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t801, ptr %l427, !tbaa !27
  %t802 = load ptr, ptr %l0, !tbaa !29
  %t803 = load ptr, ptr %l24, !tbaa !29
  %t806 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %t802, ptr %t803)
  store { i64, ptr } %t806, ptr %l430
  br label %bb161
bb160:
  call void @__olang_check_failed(ptr @olang_loc_1c2cb6c96b4eaee8_c1b953befa7e1dc)
  unreachable
bb161:
  %t807 = icmp sge i64 0, 0
  br i1 %t807, label %bb162, label %bb163
bb162:
  %t809 = icmp sle i64 0, 2305843009213693951
  br i1 %t809, label %bb164, label %bb165
bb163:
  call void @__olang_check_failed(ptr @olang_loc_7ec9c6dbabf95ed5_e8695782fec42ca9)
  unreachable
bb164:
  %t811 = mul i64 0, 4
  %t812 = insertvalue { i64, ptr } undef, i64 0, 0
  %t813 = insertvalue { i64, ptr } %t812, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t814 = load ptr, ptr %l419, !tbaa !29
  %t815 = load %"compiler/source:Span", ptr %l420
  %t816 = load %"compiler/source:Span", ptr %l421
  %t817 = load i64, ptr %l422, !tbaa !24
  %t818 = load ptr, ptr %l424, !tbaa !29
  %t819 = load { i64, ptr }, ptr %l427, !tbaa !27
  %t820 = load { i64, ptr }, ptr %l430, !tbaa !27
  %t822 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %s11, ptr %t814, %"compiler/source:Span" %t815, %"compiler/source:Span" %t816, i64 %t817, ptr %t818, { i64, ptr } %t819, { i64, ptr } %t820, { i64, ptr } %t813)
  store ptr %t822, ptr %l434
  br label %bb166
bb165:
  call void @__olang_check_failed(ptr @olang_loc_7ec9c6dbabf95ed5_e8695782fec42ca9)
  unreachable
bb166:
  %t823 = load ptr, ptr %l434, !tbaa !29
  store ptr %t823, ptr %l25, !tbaa !29
  %t824 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t824, ptr %l435
  %t825 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t825, ptr %l436, !tbaa !23
  %t826 = load ptr, ptr %l22, !tbaa !29
  store ptr %t826, ptr %l437, !tbaa !29
  %t827 = load ptr, ptr %l0, !tbaa !29
  %t828 = load %"compiler/source:Span", ptr %l1
  %t829 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t833 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t827, %"compiler/source:Span" %t828, i32 %t829, i64 0)
  store ptr %t833, ptr %l441
  br label %bb167
bb167:
  %t834 = load ptr, ptr %l441, !tbaa !29
  %t835 = load ptr, ptr %l25, !tbaa !29
  %t836 = load ptr, ptr %l437, !tbaa !29
  %t839 = call %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t836, ptr %t834, ptr %t835)
  store %"compiler/typed:Cond" %t839, ptr %l444
  br label %bb168
bb168:
  %t840 = load %"compiler/typed:Cond", ptr %l444
  %t841 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Cond" %t840, ptr %t841
  store { i64, [5 x i64] } zeroinitializer, ptr %t842
  %t843 = getelementptr { i64, [5 x i64] }, ptr %t842, i32 0, i32 0
  store i64 11, ptr %t843
  %t844 = load %"compiler/source:Span", ptr %l435
  %t845 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t844, 0
  %t846 = load i32, ptr %l436, !tbaa !23
  %t847 = insertvalue { %"compiler/source:Span", i32, ptr } %t845, i32 %t846, 1
  %t849 = insertvalue { %"compiler/source:Span", i32, ptr } %t847, ptr %t841, 2
  %t850 = getelementptr { i64, [5 x i64] }, ptr %t842, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t849, ptr %t850
  %t851 = load { i64, [5 x i64] }, ptr %t842
  %t852 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store ptr %t852, ptr %lp26
  %t854 = load ptr, ptr %lp26
  store { i64, [5 x i64] } %t851, ptr %t854
  %t855 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t855, ptr %l447
  %t856 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t856, ptr %l448, !tbaa !23
  %t857 = load ptr, ptr %l0, !tbaa !29
  %t859 = getelementptr %"compiler/check:Checker", ptr %t857, i32 0, i32 37
  %t860 = load i64, ptr %l17, !tbaa !24
  %t863 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t859, i64 %t860)
  store { i64, ptr } %t863, ptr %l452
  br label %bb169
bb169:
  %t864 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t864, ptr %l453
  %t865 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t865, ptr %l454, !tbaa !23
  %t866 = load ptr, ptr %l20, !tbaa !29
  %t867 = load ptr, ptr %l21, !tbaa !29
  %t869 = load ptr, ptr %lp26
  %t873 = call %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t866, ptr %t867, ptr %t869)
  store %"compiler/typed:Cond" %t873, ptr %l459
  br label %bb170
bb170:
  %t874 = load %"compiler/typed:Cond", ptr %l459
  %t875 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Cond" %t874, ptr %t875
  store { i64, [5 x i64] } zeroinitializer, ptr %t876
  %t877 = getelementptr { i64, [5 x i64] }, ptr %t876, i32 0, i32 0
  store i64 11, ptr %t877
  %t878 = load %"compiler/source:Span", ptr %l453
  %t879 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t878, 0
  %t880 = load i32, ptr %l454, !tbaa !23
  %t881 = insertvalue { %"compiler/source:Span", i32, ptr } %t879, i32 %t880, 1
  %t883 = insertvalue { %"compiler/source:Span", i32, ptr } %t881, ptr %t875, 2
  %t884 = getelementptr { i64, [5 x i64] }, ptr %t876, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t883, ptr %t884
  %t885 = load { i64, [5 x i64] }, ptr %t876
  %t887 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t885, ptr %t887
  %t888 = load { i64, ptr }, ptr %l452, !tbaa !27
  %t890 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t888, ptr %t887)
  store %"compiler/typed:Seq" %t890, ptr %l463
  br label %bb171
bb171:
  %t891 = load %"compiler/typed:Seq", ptr %l463
  %t892 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Seq" %t891, ptr %t892
  store { i64, [5 x i64] } zeroinitializer, ptr %t893
  %t894 = getelementptr { i64, [5 x i64] }, ptr %t893, i32 0, i32 0
  store i64 12, ptr %t894
  %t895 = load %"compiler/source:Span", ptr %l447
  %t896 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t895, 0
  %t897 = load i32, ptr %l448, !tbaa !23
  %t898 = insertvalue { %"compiler/source:Span", i32, ptr } %t896, i32 %t897, 1
  %t900 = insertvalue { %"compiler/source:Span", i32, ptr } %t898, ptr %t892, 2
  %t901 = getelementptr { i64, [5 x i64] }, ptr %t893, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t900, ptr %t901
  %t902 = load { i64, [5 x i64] }, ptr %t893
  %t903 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store ptr %t903, ptr %lp27
  %t905 = load ptr, ptr %lp27
  store { i64, [5 x i64] } %t902, ptr %t905
  %t906 = load i32, ptr %l2, !range !{i32 0, i32 96}
  %t908 = trunc i64 77 to i32
  %t909 = icmp eq i32 %t906, %t908
  br i1 %t909, label %bb172, label %bb173
bb172:
  %t911 = load ptr, ptr %l0, !tbaa !29
  %t912 = load %"compiler/source:Span", ptr %l1
  %t913 = load ptr, ptr %lp27
  %t917 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %t911, %"compiler/source:Span" %t912, ptr %t913)
  store ptr %t917, ptr %l472
  br label %bb174
bb173:
  %t918 = load ptr, ptr %lp27
  store ptr %t918, ptr %l468, !tbaa !29
  br label %bb175
bb174:
  %t920 = load ptr, ptr %l472, !tbaa !29
  store ptr %t920, ptr %l468, !tbaa !29
  br label %bb175
bb175:
  call void @__olang_scope_close(ptr %s11)
  %t921 = load ptr, ptr %l468, !tbaa !29
  store ptr %t921, ptr %rv
  br label %ret
bb176:
  %t922 = load i64, ptr %l16, !tbaa !24
  %t924 = icmp sge i64 %t922, 0
  br i1 %t924, label %bb177, label %bb178
bb177:
  store %olang.scope zeroinitializer, ptr %s12
  %t926 = load ptr, ptr %l0, !tbaa !29
  store ptr %t926, ptr %l476, !tbaa !29
  %t927 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t927, ptr %l477
  %t928 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t928, ptr %l478
  %t929 = load i64, ptr %l16, !tbaa !24
  store i64 %t929, ptr %l479, !tbaa !24
  %t930 = load ptr, ptr %l3, !tbaa !29
  store ptr %t930, ptr %l481, !tbaa !29
  %t932 = icmp sge i64 0, 0
  br i1 %t932, label %bb179, label %bb180
bb178:
  br label %bb193
bb179:
  %t934 = icmp sle i64 0, 1152921504606846975
  br i1 %t934, label %bb181, label %bb182
bb180:
  call void @__olang_check_failed(ptr @olang_loc_bc0d2701821819b6_446831e810be806a)
  unreachable
bb181:
  %t936 = mul i64 0, 8
  %t937 = insertvalue { i64, ptr } undef, i64 0, 0
  %t938 = insertvalue { i64, ptr } %t937, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t938, ptr %l484, !tbaa !27
  %t939 = load ptr, ptr %l0, !tbaa !29
  %t940 = load ptr, ptr %l4, !tbaa !29
  %t943 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %t939, ptr %t940)
  store { i64, ptr } %t943, ptr %l487
  br label %bb183
bb182:
  call void @__olang_check_failed(ptr @olang_loc_bc0d2701821819b6_446831e810be806a)
  unreachable
bb183:
  %t944 = icmp sge i64 0, 0
  br i1 %t944, label %bb184, label %bb185
bb184:
  %t946 = icmp sle i64 0, 2305843009213693951
  br i1 %t946, label %bb186, label %bb187
bb185:
  call void @__olang_check_failed(ptr @olang_loc_7ec9c6dbabf95ed5_e8695782fec42ca9)
  unreachable
bb186:
  %t948 = mul i64 0, 4
  %t949 = insertvalue { i64, ptr } undef, i64 0, 0
  %t950 = insertvalue { i64, ptr } %t949, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t951 = load ptr, ptr %l476, !tbaa !29
  %t952 = load %"compiler/source:Span", ptr %l477
  %t953 = load %"compiler/source:Span", ptr %l478
  %t954 = load i64, ptr %l479, !tbaa !24
  %t955 = load ptr, ptr %l481, !tbaa !29
  %t956 = load { i64, ptr }, ptr %l484, !tbaa !27
  %t957 = load { i64, ptr }, ptr %l487, !tbaa !27
  %t959 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %s12, ptr %t951, %"compiler/source:Span" %t952, %"compiler/source:Span" %t953, i64 %t954, ptr %t955, { i64, ptr } %t956, { i64, ptr } %t957, { i64, ptr } %t950)
  store ptr %t959, ptr %l491
  br label %bb188
bb187:
  call void @__olang_check_failed(ptr @olang_loc_7ec9c6dbabf95ed5_e8695782fec42ca9)
  unreachable
bb188:
  %t960 = load ptr, ptr %l491, !tbaa !29
  store ptr %t960, ptr %l28, !tbaa !29
  %t961 = load i32, ptr %l2, !range !{i32 0, i32 96}
  %t963 = trunc i64 77 to i32
  %t964 = icmp eq i32 %t961, %t963
  br i1 %t964, label %bb189, label %bb190
bb189:
  %t966 = load ptr, ptr %l0, !tbaa !29
  %t967 = load %"compiler/source:Span", ptr %l1
  %t968 = load ptr, ptr %l28, !tbaa !29
  %t972 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %t966, %"compiler/source:Span" %t967, ptr %t968)
  store ptr %t972, ptr %l498
  br label %bb191
bb190:
  %t973 = load ptr, ptr %l28, !tbaa !29
  store ptr %t973, ptr %l494, !tbaa !29
  br label %bb192
bb191:
  %t975 = load ptr, ptr %l498, !tbaa !29
  store ptr %t975, ptr %l494, !tbaa !29
  br label %bb192
bb192:
  call void @__olang_scope_close(ptr %s12)
  %t976 = load ptr, ptr %l494, !tbaa !29
  store ptr %t976, ptr %rv
  br label %ret
bb193:
  %t977 = load ptr, ptr %l0, !tbaa !29
  %t978 = load i32, ptr %l5, !tbaa !23
  %t981 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t977, i32 %t978)
  store i1 %t981, ptr %l502
  br label %bb194
bb194:
  %t982 = load i1, ptr %l502, !tbaa !21
  br i1 %t982, label %bb195, label %bb196
bb195:
  %t983 = load ptr, ptr %l0, !tbaa !29
  %t984 = load i32, ptr %l6, !tbaa !23
  %t987 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t983, i32 %t984)
  store i1 %t987, ptr %l506
  br label %bb197
bb196:
  store i1 false, ptr %l503, !tbaa !21
  br label %bb198
bb197:
  %t988 = load i1, ptr %l506, !tbaa !21
  store i1 %t988, ptr %l503, !tbaa !21
  br label %bb198
bb198:
  %t989 = load i1, ptr %l503, !tbaa !21
  br i1 %t989, label %bb199, label %bb200
bb199:
  %t990 = load ptr, ptr %l0, !tbaa !29
  %t991 = load i32, ptr %l9, !tbaa !23
  %t994 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %t990, i32 %t991)
  store i1 %t994, ptr %l510
  br label %bb201
bb200:
  store i1 false, ptr %l507, !tbaa !21
  br label %bb210
bb201:
  %t995 = load i1, ptr %l510, !tbaa !21
  br i1 %t995, label %bb202, label %bb203
bb202:
  store i1 true, ptr %l511, !tbaa !21
  br label %bb205
bb203:
  %t996 = load ptr, ptr %l0, !tbaa !29
  %t997 = load i32, ptr %l9, !tbaa !23
  %t1000 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t996, i32 %t997)
  store i1 %t1000, ptr %l514
  br label %bb204
bb204:
  %t1001 = load i1, ptr %l514, !tbaa !21
  store i1 %t1001, ptr %l511, !tbaa !21
  br label %bb205
bb205:
  %t1002 = load i1, ptr %l511, !tbaa !21
  br i1 %t1002, label %bb206, label %bb207
bb206:
  store i1 true, ptr %l515, !tbaa !21
  br label %bb209
bb207:
  %t1003 = load ptr, ptr %l0, !tbaa !29
  %t1005 = getelementptr %"compiler/check:Checker", ptr %t1003, i32 0, i32 1
  %t1006 = load ptr, ptr %t1005, !tbaa !29
  %t1008 = getelementptr %"compiler/generic:Program", ptr %t1006, i32 0, i32 2
  %t1009 = load i32, ptr %l9, !tbaa !23
  %t1012 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1008, i32 %t1009)
  store i32 %t1012, ptr %l520
  br label %bb208
bb208:
  %t1013 = load i32, ptr %l520, !range !{i32 0, i32 33}
  %t1015 = trunc i64 29 to i32
  %t1016 = icmp eq i32 %t1013, %t1015
  store i1 %t1016, ptr %l515, !tbaa !21
  br label %bb209
bb209:
  %t1018 = load i1, ptr %l515, !tbaa !21
  store i1 %t1018, ptr %l507, !tbaa !21
  br label %bb210
bb210:
  %t1019 = load i1, ptr %l507, !tbaa !21
  br i1 %t1019, label %bb211, label %bb212
bb211:
  %t1020 = load ptr, ptr %l0, !tbaa !29
  %t1021 = load %"compiler/source:Span", ptr %l1
  %t1022 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t1023 = load ptr, ptr %l3, !tbaa !29
  %t1024 = load ptr, ptr %l4, !tbaa !29
  %t1032 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t1020, %"compiler/source:Span" %t1021, i32 %t1022, i32 19, ptr %t1023, ptr %t1024)
  store ptr %t1032, ptr %l530
  br label %bb213
bb212:
  br label %bb218
bb213:
  %t1033 = load ptr, ptr %l530, !tbaa !29
  store ptr %t1033, ptr %l29, !tbaa !29
  %t1034 = load i32, ptr %l2, !range !{i32 0, i32 96}
  %t1036 = trunc i64 77 to i32
  %t1037 = icmp eq i32 %t1034, %t1036
  br i1 %t1037, label %bb214, label %bb215
bb214:
  %t1039 = load ptr, ptr %l0, !tbaa !29
  %t1040 = load %"compiler/source:Span", ptr %l1
  %t1041 = load ptr, ptr %l29, !tbaa !29
  %t1045 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %t1039, %"compiler/source:Span" %t1040, ptr %t1041)
  store ptr %t1045, ptr %l537
  br label %bb216
bb215:
  %t1046 = load ptr, ptr %l29, !tbaa !29
  store ptr %t1046, ptr %l533, !tbaa !29
  br label %bb217
bb216:
  %t1048 = load ptr, ptr %l537, !tbaa !29
  store ptr %t1048, ptr %l533, !tbaa !29
  br label %bb217
bb217:
  %t1049 = load ptr, ptr %l533, !tbaa !29
  store ptr %t1049, ptr %rv
  br label %ret
bb218:
  %t1050 = load ptr, ptr %l0, !tbaa !29
  %t1051 = load i32, ptr %l9, !tbaa !23
  %t1054 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epartsHaveEq(ptr %v0, ptr %t1050, i32 %t1051, i64 0)
  store i1 %t1054, ptr %l541
  br label %bb219
bb219:
  %t1055 = load i1, ptr %l541, !tbaa !21
  br i1 %t1055, label %bb220, label %bb221
bb220:
  %t1056 = load ptr, ptr %l0, !tbaa !29
  %t1057 = load %"compiler/source:Span", ptr %l1
  %t1058 = load ptr, ptr %l3, !tbaa !29
  %t1059 = load ptr, ptr %l4, !tbaa !29
  %t1060 = load i32, ptr %l9, !tbaa !23
  %t1066 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epartsEqual(ptr %v0, ptr %t1056, %"compiler/source:Span" %t1057, ptr %t1058, ptr %t1059, i32 %t1060)
  store ptr %t1066, ptr %l547
  br label %bb222
bb221:
  br label %bb232
bb222:
  %t1067 = load ptr, ptr %l547, !tbaa !29
  store ptr %t1067, ptr %l30, !tbaa !29
  %t1068 = load ptr, ptr %l30, !tbaa !29
  %t1070 = icmp eq ptr %t1068, null
  br i1 %t1070, label %bb223, label %bb224
bb223:
  store %olang.scope zeroinitializer, ptr %s15
  %t1072 = load ptr, ptr %l0, !tbaa !29
  %t1073 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s15, ptr %t1072, %"compiler/source:Span" %t1073, { i64, ptr } { i64 54, ptr getelementptr inbounds (<{ i64, [54 x i8] }>, ptr @.d6, i32 0, i32 1) })
  br label %bb225
bb224:
  br label %bb227
bb225:
  %t1076 = load ptr, ptr %l0, !tbaa !29
  %t1077 = load %"compiler/source:Span", ptr %l1
  %t1078 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t1082 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t1076, %"compiler/source:Span" %t1077, i32 %t1078, i64 0)
  store ptr %t1082, ptr %l555
  br label %bb226
bb226:
  call void @__olang_scope_close(ptr %s15)
  %t1083 = load ptr, ptr %l555, !tbaa !29
  store ptr %t1083, ptr %rv
  br label %ret
bb227:
  %t1084 = load i32, ptr %l2, !range !{i32 0, i32 96}
  %t1086 = trunc i64 77 to i32
  %t1087 = icmp eq i32 %t1084, %t1086
  br i1 %t1087, label %bb228, label %bb229
bb228:
  %t1089 = load ptr, ptr %l0, !tbaa !29
  %t1090 = load %"compiler/source:Span", ptr %l1
  %t1091 = load ptr, ptr %l30, !tbaa !29
  %t1095 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %t1089, %"compiler/source:Span" %t1090, ptr %t1091)
  store ptr %t1095, ptr %l562
  br label %bb230
bb229:
  %t1096 = load ptr, ptr %l30, !tbaa !29
  store ptr %t1096, ptr %l558, !tbaa !29
  br label %bb231
bb230:
  %t1098 = load ptr, ptr %l562, !tbaa !29
  store ptr %t1098, ptr %l558, !tbaa !29
  br label %bb231
bb231:
  %t1099 = load ptr, ptr %l558, !tbaa !29
  store ptr %t1099, ptr %rv
  br label %ret
bb232:
  %t1100 = load ptr, ptr %l0, !tbaa !29
  %t1101 = load i32, ptr %l5, !tbaa !23
  %t1104 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t1100, i32 %t1101)
  store i1 %t1104, ptr %l566
  br label %bb233
bb233:
  %t1105 = load i1, ptr %l566, !tbaa !21
  br i1 %t1105, label %bb234, label %bb235
bb234:
  %t1106 = load ptr, ptr %l0, !tbaa !29
  %t1107 = load i32, ptr %l6, !tbaa !23
  %t1110 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t1106, i32 %t1107)
  store i1 %t1110, ptr %l570
  br label %bb236
bb235:
  store i1 false, ptr %l567, !tbaa !21
  br label %bb237
bb236:
  %t1111 = load i1, ptr %l570, !tbaa !21
  store i1 %t1111, ptr %l567, !tbaa !21
  br label %bb237
bb237:
  %t1112 = load i1, ptr %l567, !tbaa !21
  br i1 %t1112, label %bb238, label %bb239
bb238:
  %t1113 = load ptr, ptr %l0, !tbaa !29
  %t1115 = getelementptr %"compiler/check:Checker", ptr %t1113, i32 0, i32 1
  %t1116 = load ptr, ptr %t1115, !tbaa !29
  %t1118 = getelementptr %"compiler/generic:Program", ptr %t1116, i32 0, i32 2
  %t1119 = load i32, ptr %l9, !tbaa !23
  %t1120 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t1124 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t1118, i32 %t1119, i64 %t1120)
  store i32 %t1124, ptr %l577
  br label %bb240
bb239:
  %t1125 = load i32, ptr %l9, !tbaa !23
  store i32 %t1125, ptr %l571, !tbaa !23
  br label %bb241
bb240:
  %t1127 = load i32, ptr %l577, !tbaa !23
  store i32 %t1127, ptr %l571, !tbaa !23
  br label %bb241
bb241:
  %t1128 = load i32, ptr %l571, !tbaa !23
  store i32 %t1128, ptr %l31, !tbaa !23
  %t1129 = load ptr, ptr %l0, !tbaa !29
  %t1130 = load i32, ptr %l5, !tbaa !23
  %t1133 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t1129, i32 %t1130)
  store i1 %t1133, ptr %l581
  br label %bb242
bb242:
  %t1134 = load i1, ptr %l581, !tbaa !21
  br i1 %t1134, label %bb243, label %bb244
bb243:
  %t1135 = load ptr, ptr %l0, !tbaa !29
  %t1136 = load i32, ptr %l6, !tbaa !23
  %t1139 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t1135, i32 %t1136)
  store i1 %t1139, ptr %l585
  br label %bb245
bb244:
  store i1 false, ptr %l582, !tbaa !21
  br label %bb246
bb245:
  %t1140 = load i1, ptr %l585, !tbaa !21
  store i1 %t1140, ptr %l582, !tbaa !21
  br label %bb246
bb246:
  %t1141 = load i1, ptr %l582, !tbaa !21
  br i1 %t1141, label %bb247, label %bb248
bb247:
  %t1142 = load ptr, ptr %l0, !tbaa !29
  %t1144 = getelementptr %"compiler/check:Checker", ptr %t1142, i32 0, i32 1
  %t1145 = load ptr, ptr %t1144, !tbaa !29
  %t1147 = getelementptr %"compiler/generic:Program", ptr %t1145, i32 0, i32 2
  %t1148 = load i32, ptr %l5, !tbaa !23
  %t1151 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t1147, i32 %t1148)
  store i1 %t1151, ptr %l591
  br label %bb249
bb248:
  store i1 false, ptr %l586, !tbaa !21
  br label %bb254
bb249:
  %t1152 = load i1, ptr %l591, !tbaa !21
  br i1 %t1152, label %bb250, label %bb251
bb250:
  store i1 true, ptr %l592, !tbaa !21
  br label %bb253
bb251:
  %t1153 = load ptr, ptr %l0, !tbaa !29
  %t1155 = getelementptr %"compiler/check:Checker", ptr %t1153, i32 0, i32 1
  %t1156 = load ptr, ptr %t1155, !tbaa !29
  %t1158 = getelementptr %"compiler/generic:Program", ptr %t1156, i32 0, i32 2
  %t1159 = load i32, ptr %l6, !tbaa !23
  %t1162 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t1158, i32 %t1159)
  store i1 %t1162, ptr %l597
  br label %bb252
bb252:
  %t1163 = load i1, ptr %l597, !tbaa !21
  store i1 %t1163, ptr %l592, !tbaa !21
  br label %bb253
bb253:
  %t1164 = load i1, ptr %l592, !tbaa !21
  store i1 %t1164, ptr %l586, !tbaa !21
  br label %bb254
bb254:
  %t1165 = load i1, ptr %l586, !tbaa !21
  br i1 %t1165, label %bb255, label %bb256
bb255:
  %t1166 = load ptr, ptr %l0, !tbaa !29
  %t1168 = getelementptr %"compiler/check:Checker", ptr %t1166, i32 0, i32 1
  %t1169 = load ptr, ptr %t1168, !tbaa !29
  %t1171 = getelementptr %"compiler/generic:Program", ptr %t1169, i32 0, i32 2
  %t1172 = load i32, ptr %l31, !tbaa !23
  %t1175 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %t1171, i32 %t1172)
  store i32 %t1175, ptr %l602
  br label %bb257
bb256:
  br label %bb258
bb257:
  %t1176 = load i32, ptr %l602, !tbaa !23
  store i32 %t1176, ptr %l31, !tbaa !23
  br label %bb258
bb258:
  %t1177 = load ptr, ptr %l0, !tbaa !29
  %t1178 = load ptr, ptr %l3, !tbaa !29
  %t1179 = load i32, ptr %l31, !tbaa !23
  %t1180 = load %"compiler/source:Span", ptr %l1
  %t1185 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t1177, ptr %t1178, i32 %t1179, %"compiler/source:Span" %t1180)
  store ptr %t1185, ptr %l607
  br label %bb259
bb259:
  %t1186 = load ptr, ptr %l607, !tbaa !29
  store ptr %t1186, ptr %l32, !tbaa !29
  %t1187 = load ptr, ptr %l0, !tbaa !29
  %t1188 = load ptr, ptr %l4, !tbaa !29
  %t1189 = load i32, ptr %l31, !tbaa !23
  %t1190 = load %"compiler/source:Span", ptr %l1
  %t1195 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t1187, ptr %t1188, i32 %t1189, %"compiler/source:Span" %t1190)
  store ptr %t1195, ptr %l612
  br label %bb260
bb260:
  %t1196 = load ptr, ptr %l612, !tbaa !29
  store ptr %t1196, ptr %l33, !tbaa !29
  %t1197 = load ptr, ptr %l0, !tbaa !29
  %t1199 = getelementptr %"compiler/check:Checker", ptr %t1197, i32 0, i32 36
  %t1201 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t1199)
  store i64 %t1201, ptr %l615
  br label %bb261
bb261:
  %t1202 = load i64, ptr %l615, !tbaa !24
  store i64 %t1202, ptr %l34, !tbaa !24
  %t1203 = load ptr, ptr %l0, !tbaa !29
  %t1205 = getelementptr %"compiler/check:Checker", ptr %t1203, i32 0, i32 36
  %t1206 = load ptr, ptr %l32, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t1205, ptr %t1206)
  br label %bb262
bb262:
  %t1209 = load ptr, ptr %l0, !tbaa !29
  %t1211 = getelementptr %"compiler/check:Checker", ptr %t1209, i32 0, i32 36
  %t1212 = load ptr, ptr %l33, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t1211, ptr %t1212)
  br label %bb263
bb263:
  %t1215 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1215, ptr %l622, !tbaa !29
  %t1216 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1216, ptr %l623
  %t1217 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t1217, ptr %l624, !tbaa !23
  %t1218 = load i32, ptr %l31, !tbaa !23
  store { i64, [3 x i64] } zeroinitializer, ptr %t1219
  %t1220 = getelementptr { i64, [3 x i64] }, ptr %t1219, i32 0, i32 0
  store i64 4, ptr %t1220
  %t1222 = insertvalue { i32, i32 } undef, i32 0, 0
  %t1224 = insertvalue { i32, i32 } %t1222, i32 %t1218, 1
  %t1225 = getelementptr { i64, [3 x i64] }, ptr %t1219, i32 0, i32 1
  store { i32, i32 } %t1224, ptr %t1225
  %t1226 = load { i64, [3 x i64] }, ptr %t1219
  %t1228 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t1226, ptr %t1228
  store ptr %t1228, ptr %l628, !tbaa !29
  %t1229 = load ptr, ptr %l0, !tbaa !29
  %t1231 = getelementptr %"compiler/check:Checker", ptr %t1229, i32 0, i32 36
  %t1232 = load i64, ptr %l34, !tbaa !24
  %t1235 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t1231, i64 %t1232)
  store { i64, ptr } %t1235, ptr %l632
  br label %bb264
bb264:
  %t1236 = load ptr, ptr %l622, !tbaa !29
  %t1237 = load %"compiler/source:Span", ptr %l623
  %t1238 = load i32, ptr %l624, !tbaa !23
  %t1239 = load ptr, ptr %l628, !tbaa !29
  %t1240 = load { i64, ptr }, ptr %l632, !tbaa !27
  %t1241 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallOf(ptr %v0, ptr %t1236, %"compiler/source:Span" %t1237, i32 %t1238, ptr %t1239, { i64, ptr } %t1240)
  store ptr %t1241, ptr %l633
  br label %bb265
bb265:
  %t1242 = load ptr, ptr %l633, !tbaa !29
  store ptr %t1242, ptr %l35, !tbaa !29
  %t1243 = load i32, ptr %l2, !range !{i32 0, i32 96}
  %t1245 = trunc i64 77 to i32
  %t1246 = icmp eq i32 %t1243, %t1245
  br i1 %t1246, label %bb266, label %bb267
bb266:
  %t1248 = load ptr, ptr %l0, !tbaa !29
  %t1249 = load %"compiler/source:Span", ptr %l1
  %t1250 = load ptr, ptr %l35, !tbaa !29
  %t1254 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %t1248, %"compiler/source:Span" %t1249, ptr %t1250)
  store ptr %t1254, ptr %l640
  br label %bb268
bb267:
  %t1255 = load ptr, ptr %l35, !tbaa !29
  store ptr %t1255, ptr %l636, !tbaa !29
  br label %bb269
bb268:
  %t1257 = load ptr, ptr %l640, !tbaa !29
  store ptr %t1257, ptr %l636, !tbaa !29
  br label %bb269
bb269:
  %t1258 = load ptr, ptr %l636, !tbaa !29
  store ptr %t1258, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrsText(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l14 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca %"std/prelude/text:StringBuilder"
  %l28 = alloca i64
  %l31 = alloca i64
  %l52 = alloca ptr
  %l54 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l64 = alloca i64
  %l65 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t6, i32 %a1)
  store { i64, ptr } %t10, ptr %l14
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t11, ptr %l2, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t16 = icmp eq i64 %t14, 0
  br i1 %t16, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d7, i32 0, i32 1) }, ptr %l18, !tbaa !27
  %t18 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t18, ptr %l19, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t19, 0
  store i64 %t20, ptr %l20, !tbaa !24
  %t21 = load i64, ptr %l20, !tbaa !24
  %t22 = mul i64 %t21, 1
  %t23 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t22)
  %t24 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  store { i64, ptr } %t25, ptr %l21, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = load i64, ptr %l20, !tbaa !24
  %t31 = mul i64 %t30, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t27, ptr %t29, i64 %t31, i1 false)
  %t32 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t32, ptr %l19, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t33 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t33, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t34 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t34, ptr %l22
  br label %bb5
bb5:
  %t35 = load %"std/prelude/text:StringBuilder", ptr %l22
  store %"std/prelude/text:StringBuilder" %t35, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  %t36 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t36, 0
  store i64 %t38, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t40 = load i64, ptr %l5, !tbaa !24
  %t41 = load i64, ptr %l4, !tbaa !24
  %t44 = icmp sgt i64 %t40, %t41
  br i1 %t44, label %bb6, label %bb7
bb6:
  %t46 = load i64, ptr %l6, !tbaa !24
  %t48 = icmp sgt i64 %t46, 0
  br i1 %t48, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb11
bb8:
  %t50 = load i64, ptr %l5, !tbaa !24
  %t51 = load i64, ptr %l4, !tbaa !24
  %t54 = sub i64 %t50, %t51
  %t55 = load i64, ptr %l6, !tbaa !24
  %t58 = add i64 %t54, %t55
  %t60 = sub i64 %t58, 1
  %t61 = load i64, ptr %l6, !tbaa !24
  %t64 = sdiv i64 %t60, %t61
  store i64 %t64, ptr %l31, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb10
bb10:
  %t66 = load i64, ptr %l31, !tbaa !24
  store i64 %t66, ptr %l28, !tbaa !24
  br label %bb11
bb11:
  %t67 = load i64, ptr %l28, !tbaa !24
  store i64 %t67, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t68 = load i64, ptr %l8, !tbaa !24
  %t69 = load i64, ptr %l7, !tbaa !24
  %t72 = icmp slt i64 %t68, %t69
  %t74 = xor i1 %t72, true
  br i1 %t74, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb14:
  br label %bb15
bb15:
  %t76 = load i64, ptr %l4, !tbaa !24
  %t77 = load i64, ptr %l8, !tbaa !24
  %t78 = load i64, ptr %l6, !tbaa !24
  %t81 = mul i64 %t77, %t78
  %t84 = add i64 %t76, %t81
  store i64 %t84, ptr %l9, !tbaa !24
  %t86 = load i64, ptr %l9, !tbaa !24
  %t88 = icmp sgt i64 %t86, 0
  br i1 %t88, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s4
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %l3, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d8, i32 0, i32 1) })
  br label %bb18
bb17:
  br label %bb19
bb18:
  call void @__olang_scope_close(ptr %s4)
  br label %bb19
bb19:
  store ptr %l3, ptr %l52, !tbaa !29
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t92, ptr %l54, !tbaa !27
  %t93 = load i64, ptr %l9, !tbaa !24
  %t95 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = getelementptr i32, ptr %t96, i64 %t93
  %t98 = load i32, ptr %t97, !tbaa !33
  %t101 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s3, ptr %t91, i32 %t98)
  store { i64, ptr } %t101, ptr %l57
  br label %bb20
bb20:
  %t102 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t102, 0
  %t104 = extractvalue { i64, ptr } %t102, 1
  %t105 = mul i64 %t103, 1
  %t106 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t105)
  call void @llvm.memcpy.p0.p0.i64(ptr %t106, ptr %t104, i64 %t105, i1 false)
  %t107 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t106, 1
  %t109 = load ptr, ptr %l52, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %t109, { i64, ptr } %t108)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s3)
  br label %bb22
bb22:
  %t111 = load i64, ptr %l8, !tbaa !24
  %t113 = add i64 %t111, 1
  store i64 %t113, ptr %l8, !tbaa !24
  br label %bb12
bb23:
  %t116 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l3)
  store { i64, ptr } %t116, ptr %l62
  br label %bb24
bb24:
  %t117 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t117, ptr %l63, !tbaa !27
  %t118 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t118, 0
  store i64 %t119, ptr %l64, !tbaa !24
  %t120 = load i64, ptr %l64, !tbaa !24
  %t121 = mul i64 %t120, 1
  %t122 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t121)
  %t123 = insertvalue { i64, ptr } undef, i64 %t120, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr %t122, 1
  store { i64, ptr } %t124, ptr %l65, !tbaa !27
  %t125 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !27
  %t127 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t128 = load ptr, ptr %t127, !tbaa !27
  %t129 = load i64, ptr %l64, !tbaa !24
  %t130 = mul i64 %t129, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t126, ptr %t128, i64 %t130, i1 false)
  %t131 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t131, ptr %l63, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t132 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t132, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexportParam(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l6 = alloca i1
  %l10 = alloca i1
  %l17 = alloca i32
  %l20 = alloca i1
  %l24 = alloca i32
  %l29 = alloca i32
  %l32 = alloca i1
  %l33 = alloca ptr
  %l38 = alloca i32
  %l39 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternValue(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i1, ptr %l6, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load i32, ptr %l1, !tbaa !23
  %t12 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t8, i32 %t9)
  store i1 %t12, ptr %l10
  br label %bb5
bb5:
  %t13 = load i1, ptr %l10, !tbaa !21
  %t14 = xor i1 %t13, true
  br i1 %t14, label %bb6, label %bb7
bb6:
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/check:Checker", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = getelementptr %"compiler/generic:Program", ptr %t20, i32 0, i32 2
  %t23 = load i32, ptr %l1, !tbaa !23
  %t26 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t22, i32 %t23)
  store i32 %t26, ptr %l17
  br label %bb9
bb9:
  %t27 = load i32, ptr %l17, !tbaa !23
  store i32 %t27, ptr %l2, !tbaa !23
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l2, !tbaa !23
  %t32 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplainStruct(ptr %v0, ptr %t28, i32 %t29, i64 0)
  store i1 %t32, ptr %l20
  br label %bb10
bb10:
  %t33 = load i1, ptr %l20, !tbaa !21
  br i1 %t33, label %bb11, label %bb12
bb11:
  store i1 true, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load i32, ptr %l2, !tbaa !23
  %t39 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t35, i32 %t36)
  store i32 %t39, ptr %l24
  br label %bb14
bb14:
  %t40 = load i32, ptr %l24, !tbaa !23
  store i32 %t40, ptr %l3, !tbaa !23
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/check:Checker", ptr %t41, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = getelementptr %"compiler/generic:Program", ptr %t44, i32 0, i32 2
  %t47 = load i32, ptr %l3, !tbaa !23
  %t50 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t46, i32 %t47)
  store i32 %t50, ptr %l29
  br label %bb15
bb15:
  %t51 = load i32, ptr %l29, !range !{i32 0, i32 33}
  %t53 = trunc i64 19 to i32
  %t54 = icmp eq i32 %t51, %t53
  br i1 %t54, label %bb16, label %bb17
bb16:
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l33, !tbaa !29
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = getelementptr %"compiler/generic:Program", ptr %t60, i32 0, i32 2
  %t63 = load i32, ptr %l3, !tbaa !23
  %t66 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t62, i32 %t63)
  store i32 %t66, ptr %l38
  br label %bb18
bb17:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb20
bb18:
  %t67 = load ptr, ptr %l33, !tbaa !29
  %t68 = load i32, ptr %l38, !tbaa !23
  %t69 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternValue(ptr %v0, ptr %t67, i32 %t68)
  store i1 %t69, ptr %l39
  br label %bb19
bb19:
  %t70 = load i1, ptr %l39, !tbaa !21
  store i1 %t70, ptr %l32, !tbaa !21
  br label %bb20
bb20:
  %t71 = load i1, ptr %l32, !tbaa !21
  store i1 %t71, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l9 = alloca ptr
  %l18 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca i32
  %l28 = alloca %"compiler/source:Span"
  %l29 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = load i32, ptr %l2, !tbaa !23
  %t8 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitCtor(ptr %v0, ptr %v1, ptr %t1, ptr %t2, i32 %t4)
  store ptr %t8, ptr %l9
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l9, !tbaa !29
  store ptr %t9, ptr %l3, !tbaa !29
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t12 = icmp eq ptr %t10, null
  %t14 = xor i1 %t12, true
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load ptr, ptr %l3, !tbaa !29
  store ptr %t16, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = load i32, ptr %l2, !tbaa !23
  %t25 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t18, ptr %t19, i32 %t21)
  store ptr %t25, ptr %l18
  br label %bb5
bb5:
  %t26 = load ptr, ptr %l18, !tbaa !29
  store ptr %t26, ptr %l4, !tbaa !29
  %t27 = load i32, ptr %l2, !tbaa !23
  %t28 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t31 = icmp eq i32 %t27, %t28
  br i1 %t31, label %bb6, label %bb7
bb6:
  %t33 = load ptr, ptr %l4, !tbaa !29
  store ptr %t33, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l23, !tbaa !29
  %t36 = load ptr, ptr %l4, !tbaa !29
  store ptr %t36, ptr %l24, !tbaa !29
  %t37 = load i32, ptr %l2, !tbaa !23
  store i32 %t37, ptr %l25, !tbaa !23
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t42 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargSpan(ptr %v0, ptr %v1, ptr %t38, ptr %t39)
  store %"compiler/source:Span" %t42, ptr %l28
  br label %bb9
bb9:
  %t43 = load ptr, ptr %l23, !tbaa !29
  %t44 = load ptr, ptr %l24, !tbaa !29
  %t45 = load i32, ptr %l25, !tbaa !23
  %t46 = load %"compiler/source:Span", ptr %l28
  %t47 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t43, ptr %t44, i32 %t45, %"compiler/source:Span" %t46)
  store ptr %t47, ptr %l29
  br label %bb10
bb10:
  %t48 = load ptr, ptr %l29, !tbaa !29
  store ptr %t48, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalDeps(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %lp3 = alloca ptr
  %l4 = alloca i64
  %l6 = alloca %"compiler/check:b5aWalk"
  %l11 = alloca i1
  %l12 = alloca i64
  %l14 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l21 = alloca i64
  %rv = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call %"compiler/check:b5aWalk" @compiler_2fcheck_3ab5aWalk_2ector(ptr %v1, i64 %a1)
  store %"compiler/check:b5aWalk" %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 56, i64 8)
  store ptr %t4, ptr %lp3
  %t5 = load %"compiler/check:b5aWalk", ptr %l6
  %t6 = load ptr, ptr %lp3
  store %"compiler/check:b5aWalk" %t5, ptr %t6
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load ptr, ptr %lp3
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aInit(ptr %v0, ptr %v1, ptr %t7, ptr %t8, i64 %a2)
  br label %bb2
bb2:
  store i64 0, ptr %l4, !tbaa !24
  br label %bb3
bb3:
  %t13 = load ptr, ptr %lp3
  %t14 = getelementptr %"compiler/check:b5aWalk", ptr %t13, i32 0, i32 7
  %t15 = load i1, ptr %t14, !tbaa !21
  br i1 %t15, label %bb4, label %bb5
bb4:
  %t17 = load i64, ptr %l4, !tbaa !24
  store i64 %t17, ptr %l12, !tbaa !24
  %t18 = load ptr, ptr %lp3
  %t19 = getelementptr %"compiler/check:b5aWalk", ptr %t18, i32 0, i32 2
  %t21 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t19)
  store i64 %t21, ptr %l14
  br label %bb6
bb5:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb7
bb6:
  %t22 = load i64, ptr %l12, !tbaa !24
  %t23 = load i64, ptr %l14, !tbaa !24
  %t24 = icmp slt i64 %t22, %t23
  store i1 %t24, ptr %l11, !tbaa !21
  br label %bb7
bb7:
  %t26 = load i1, ptr %l11, !tbaa !21
  %t27 = xor i1 %t26, true
  br i1 %t27, label %bb8, label %bb9
bb8:
  br label %bb14
bb9:
  br label %bb10
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l17, !tbaa !29
  %t30 = load ptr, ptr %lp3
  store ptr %t30, ptr %l18, !tbaa !29
  %t31 = load ptr, ptr %lp3
  %t32 = getelementptr %"compiler/check:b5aWalk", ptr %t31, i32 0, i32 2
  %t33 = load i64, ptr %l4, !tbaa !24
  %t36 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t32, i64 %t33)
  store i64 %t36, ptr %l21
  br label %bb11
bb11:
  %t37 = load ptr, ptr %l17, !tbaa !29
  %t38 = load ptr, ptr %l18, !tbaa !29
  %t39 = load i64, ptr %l21, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aFn(ptr %v0, ptr %v1, ptr %t37, ptr %t38, i64 %t39)
  br label %bb12
bb12:
  %t40 = load i64, ptr %l4, !tbaa !24
  %t42 = add i64 %t40, 1
  store i64 %t42, ptr %l4, !tbaa !24
  br label %bb13
bb13:
  br label %bb3
bb14:
  %t44 = load ptr, ptr %lp3
  %t45 = getelementptr %"compiler/check:b5aWalk", ptr %t44, i32 0, i32 3
  %t46 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t45
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t46, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2) #0 {
entry:
  %l8 = alloca i64
  %rv = alloca i64
  %t4 = alloca { i64, [2 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  store { i64, [2 x i64] } zeroinitializer, ptr %t4
  %t5 = getelementptr { i64, [2 x i64] }, ptr %t4, i32 0, i32 0
  store i64 0, ptr %t5
  %t6 = load { i64, [2 x i64] }, ptr %t4
  %t12 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %a0, i32 0, %"compiler/source:Span" %a1, i32 %a2, i32 3, { i64, [2 x i64] } %t6)
  store i64 %t12, ptr %l8
  br label %bb1
bb1:
  %t13 = load i64, ptr %l8, !tbaa !24
  store i64 %t13, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i1
  %l15 = alloca i1
  %l16 = alloca i64
  %l17 = alloca i64
  %l20 = alloca i64
  %l23 = alloca i1
  %l26 = alloca i32
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t18, i32 0, i32 2
  %t20 = load i64, ptr %t19
  store i64 %t20, ptr %l3, !tbaa !24
  br label %bb5
bb4:
  br label %bb17
bb5:
  %t22 = load i64, ptr %l3, !tbaa !24
  %t23 = load i64, ptr @G_2ecompiler_2fcheck_2eLaneMagic, !tbaa !24
  %t26 = icmp sge i64 %t22, %t23
  br i1 %t26, label %bb6, label %bb7
bb6:
  %t28 = load i64, ptr %l3, !tbaa !24
  store i64 %t28, ptr %l16, !tbaa !24
  %t29 = load i64, ptr @G_2ecompiler_2fcheck_2eLaneMagic, !tbaa !24
  store i64 %t29, ptr %l17, !tbaa !24
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/check:Checker", ptr %t30, i32 0, i32 39
  %t34 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eLen_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %t32)
  store i64 %t34, ptr %l20
  br label %bb8
bb7:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb9
bb8:
  %t35 = load i64, ptr %l17, !tbaa !24
  %t36 = load i64, ptr %l20, !tbaa !24
  %t37 = add i64 %t35, %t36
  %t38 = load i64, ptr %l16, !tbaa !24
  %t40 = icmp slt i64 %t38, %t37
  store i1 %t40, ptr %l15, !tbaa !21
  br label %bb9
bb9:
  %t42 = load i1, ptr %l15, !tbaa !21
  br i1 %t42, label %bb10, label %bb11
bb10:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load i32, ptr %l2, !tbaa !23
  %t47 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t43, i32 %t44)
  store i32 %t47, ptr %l26
  br label %bb12
bb11:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb13
bb12:
  %t48 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t49 = load i32, ptr %l26, !tbaa !23
  %t51 = icmp ne i32 %t49, %t48
  store i1 %t51, ptr %l23, !tbaa !21
  br label %bb13
bb13:
  %t53 = load i1, ptr %l23, !tbaa !21
  br i1 %t53, label %bb14, label %bb15
bb14:
  %t54 = load i64, ptr %l3, !tbaa !24
  %t55 = load i64, ptr @G_2ecompiler_2fcheck_2eLaneMagic, !tbaa !24
  %t58 = sub i64 %t54, %t55
  store i64 %t58, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  store i64 -1, ptr %rv
  br label %ret
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  store i64 -1, ptr %rv
  br label %ret
bb21:
  call void @__olang_check_failed(ptr @olang_loc_e09b0660792e8b62_512dd44834885876)
  unreachable
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elenMatch(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca i32
  %l22 = alloca i1
  %l26 = alloca ptr
  %l28 = alloca ptr
  %l30 = alloca ptr
  %l32 = alloca ptr
  %l34 = alloca i32
  %l35 = alloca i32
  %l40 = alloca i32
  %l51 = alloca i64
  %l54 = alloca i64
  %l73 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l93 = alloca i1
  %l97 = alloca ptr
  %l98 = alloca i1
  %l103 = alloca ptr
  %l104 = alloca i1
  %l113 = alloca ptr
  %l115 = alloca ptr
  %l117 = alloca ptr
  %l120 = alloca ptr
  %l122 = alloca i32
  %l123 = alloca i32
  %l128 = alloca i32
  %l135 = alloca i1
  %l140 = alloca i64
  %l145 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/ast:Match", ptr %t2, i32 0, i32 1
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t9 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadsConst(ptr %v0, ptr %v1, ptr %t1, ptr %t5)
  store i1 %t9, ptr %l22
  br label %bb1
bb1:
  %t10 = load i1, ptr %l22, !tbaa !21
  %t11 = xor i1 %t10, true
  br i1 %t11, label %bb2, label %bb3
bb2:
  store i64 -2, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  store ptr %t17, ptr %l26, !tbaa !29
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t18)
  store ptr %t20, ptr %l28
  br label %bb5
bb5:
  %t21 = load ptr, ptr %l28, !tbaa !29
  %t23 = getelementptr %"compiler/check:frame", ptr %t21, i32 0, i32 4
  store ptr %t23, ptr %l30, !tbaa !29
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr %"compiler/ast:Match", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  store ptr %t27, ptr %l32, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t28)
  store i32 %t30, ptr %l34
  br label %bb6
bb6:
  %t31 = load ptr, ptr %l26, !tbaa !29
  %t32 = load ptr, ptr %l30, !tbaa !29
  %t33 = load ptr, ptr %l32, !tbaa !29
  %t34 = load i32, ptr %l34, !tbaa !23
  %t35 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFoldKnown(ptr %v0, ptr %v0, ptr %v1, ptr %t31, ptr %t32, ptr %t33, i32 %t34)
  store i32 %t35, ptr %l35
  br label %bb7
bb7:
  %t36 = load i32, ptr %l35, !tbaa !23
  store i32 %t36, ptr %l2, !tbaa !23
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/check:Checker", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = getelementptr %"compiler/generic:Program", ptr %t40, i32 0, i32 2
  %t43 = load i32, ptr %l2, !tbaa !23
  %t46 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t42, i32 %t43)
  store i32 %t46, ptr %l40
  br label %bb8
bb8:
  %t47 = load i32, ptr %l40, !range !{i32 0, i32 33}
  %t49 = trunc i64 26 to i32
  %t50 = icmp eq i32 %t47, %t49
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb9, label %bb10
bb9:
  store i64 -2, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  store i64 -1, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t57 = getelementptr %"compiler/ast:Match", ptr %t55, i32 0, i32 3
  %t58 = load { i64, ptr }, ptr %t57, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t58, 0
  store i64 %t60, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t62 = load i64, ptr %l5, !tbaa !24
  %t63 = load i64, ptr %l4, !tbaa !24
  %t66 = icmp sgt i64 %t62, %t63
  br i1 %t66, label %bb12, label %bb13
bb12:
  %t68 = load i64, ptr %l6, !tbaa !24
  %t70 = icmp sgt i64 %t68, 0
  br i1 %t70, label %bb14, label %bb15
bb13:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb17
bb14:
  %t72 = load i64, ptr %l5, !tbaa !24
  %t73 = load i64, ptr %l4, !tbaa !24
  %t76 = sub i64 %t72, %t73
  %t77 = load i64, ptr %l6, !tbaa !24
  %t80 = add i64 %t76, %t77
  %t82 = sub i64 %t80, 1
  %t83 = load i64, ptr %l6, !tbaa !24
  %t86 = sdiv i64 %t82, %t83
  store i64 %t86, ptr %l54, !tbaa !24
  br label %bb16
bb15:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb16
bb16:
  %t88 = load i64, ptr %l54, !tbaa !24
  store i64 %t88, ptr %l51, !tbaa !24
  br label %bb17
bb17:
  %t89 = load i64, ptr %l51, !tbaa !24
  store i64 %t89, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb18
bb18:
  %t90 = load i64, ptr %l8, !tbaa !24
  %t91 = load i64, ptr %l7, !tbaa !24
  %t94 = icmp slt i64 %t90, %t91
  %t96 = xor i1 %t94, true
  br i1 %t96, label %bb19, label %bb20
bb19:
  br label %bb72
bb20:
  br label %bb21
bb21:
  %t98 = load i64, ptr %l4, !tbaa !24
  %t99 = load i64, ptr %l8, !tbaa !24
  %t100 = load i64, ptr %l6, !tbaa !24
  %t103 = mul i64 %t99, %t100
  %t106 = add i64 %t98, %t103
  store i64 %t106, ptr %l9, !tbaa !24
  %t108 = load ptr, ptr %l1, !tbaa !29
  %t110 = getelementptr %"compiler/ast:Match", ptr %t108, i32 0, i32 3
  %t111 = load { i64, ptr }, ptr %t110, !tbaa !27
  store { i64, ptr } %t111, ptr %l73, !tbaa !27
  %t112 = load i64, ptr %l9, !tbaa !24
  %t114 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr ptr, ptr %t115, i64 %t112
  %t117 = load ptr, ptr %t116, !tbaa !39
  store ptr %t117, ptr %l10, !tbaa !29
  %t119 = load ptr, ptr %l10, !tbaa !29
  %t121 = getelementptr %"compiler/ast:Case", ptr %t119, i32 0, i32 3
  %t122 = load ptr, ptr %t121, !tbaa !29
  %t124 = icmp eq ptr %t122, null
  %t126 = xor i1 %t124, true
  br i1 %t126, label %bb22, label %bb23
bb22:
  store i64 -2, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  %t129 = load ptr, ptr %l10, !tbaa !29
  %t131 = getelementptr %"compiler/ast:Case", ptr %t129, i32 0, i32 1
  %t132 = load { i64, ptr }, ptr %t131, !tbaa !27
  store { i64, ptr } %t132, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t134 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t134, 0
  store i64 %t136, ptr %l13, !tbaa !24
  br label %bb25
bb25:
  %t138 = load i64, ptr %l12, !tbaa !24
  %t139 = load i64, ptr %l13, !tbaa !24
  %t142 = icmp slt i64 %t138, %t139
  %t144 = xor i1 %t142, true
  br i1 %t144, label %bb26, label %bb27
bb26:
  br label %bb70
bb27:
  br label %bb28
bb28:
  %t146 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t146, ptr %l89, !tbaa !27
  %t147 = load i64, ptr %l12, !tbaa !24
  %t149 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !27
  %t151 = getelementptr ptr, ptr %t150, i64 %t147
  %t152 = load ptr, ptr %t151, !tbaa !39
  store ptr %t152, ptr %l14, !tbaa !29
  %t154 = load ptr, ptr %l14, !tbaa !29
  %t156 = call i1 @compiler_2fcheck_2eisWild(ptr %v1, ptr %t154)
  store i1 %t156, ptr %l93
  br label %bb29
bb29:
  %t157 = load i1, ptr %l93, !tbaa !21
  br i1 %t157, label %bb30, label %bb31
bb30:
  %t158 = load i64, ptr %l3, !tbaa !24
  %t160 = icmp slt i64 %t158, 0
  br i1 %t160, label %bb32, label %bb33
bb31:
  br label %bb35
bb32:
  %t162 = load i64, ptr %l9, !tbaa !24
  store i64 %t162, ptr %l3, !tbaa !24
  br label %bb34
bb33:
  br label %bb34
bb34:
  br label %bb69
bb35:
  store ptr null, ptr %l15, !tbaa !29
  %t164 = load ptr, ptr %l14, !tbaa !29
  store ptr %t164, ptr %l97, !tbaa !29
  store i1 false, ptr %l98, !tbaa !21
  %t165 = load ptr, ptr %l97, !tbaa !29
  %t166 = icmp ne ptr %t165, null
  br i1 %t166, label %bb36, label %bb37
bb36:
  %t168 = load ptr, ptr %l97, !tbaa !29
  %t169 = load i64, ptr %t168, !range !{i64 0, i64 6}
  %t171 = icmp eq i64 %t169, 4
  store i1 %t171, ptr %l98, !tbaa !21
  br label %bb37
bb37:
  %t172 = load i1, ptr %l98, !tbaa !21
  br i1 %t172, label %bb38, label %bb39
bb38:
  %t173 = load ptr, ptr %l14, !tbaa !29
  %t175 = getelementptr { i64, [4 x i64] }, ptr %t173, i32 0, i32 1
  %t176 = getelementptr { %"compiler/source:Span", ptr }, ptr %t175, i32 0, i32 1
  %t177 = load ptr, ptr %t176
  store ptr %t177, ptr %l16, !tbaa !29
  br label %bb44
bb39:
  %t179 = load ptr, ptr %l14, !tbaa !29
  store ptr %t179, ptr %l103, !tbaa !29
  store i1 false, ptr %l104, !tbaa !21
  %t180 = load ptr, ptr %l103, !tbaa !29
  %t181 = icmp ne ptr %t180, null
  br i1 %t181, label %bb40, label %bb41
bb40:
  %t183 = load ptr, ptr %l103, !tbaa !29
  %t184 = load i64, ptr %t183, !range !{i64 0, i64 6}
  %t186 = icmp eq i64 %t184, 1
  store i1 %t186, ptr %l104, !tbaa !21
  br label %bb41
bb41:
  %t187 = load i1, ptr %l104, !tbaa !21
  br i1 %t187, label %bb42, label %bb43
bb42:
  %t188 = load ptr, ptr %l14, !tbaa !29
  %t190 = getelementptr { i64, [4 x i64] }, ptr %t188, i32 0, i32 1
  %t191 = getelementptr { %"compiler/source:Span", ptr }, ptr %t190, i32 0, i32 1
  %t192 = load ptr, ptr %t191
  store ptr %t192, ptr %l16, !tbaa !29
  br label %bb44
bb43:
  br label %bb45
bb44:
  %t194 = load ptr, ptr %l16, !tbaa !29
  store ptr %t194, ptr %l15, !tbaa !29
  br label %bb50
bb45:
  br i1 true, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  store i64 -2, ptr %rv
  br label %ret
bb49:
  call void @__olang_check_failed(ptr @olang_loc_660a686bd581f793_38ac5a37531336d7)
  unreachable
bb50:
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t200 = getelementptr %"compiler/check:Checker", ptr %t198, i32 0, i32 1
  %t201 = load ptr, ptr %t200, !tbaa !29
  store ptr %t201, ptr %l113, !tbaa !29
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t204 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t202)
  store ptr %t204, ptr %l115
  br label %bb51
bb51:
  %t205 = load ptr, ptr %l115, !tbaa !29
  %t207 = getelementptr %"compiler/check:frame", ptr %t205, i32 0, i32 4
  store ptr %t207, ptr %l117, !tbaa !29
  %t208 = load ptr, ptr %l15, !tbaa !29
  %t210 = icmp eq ptr %t208, null
  br i1 %t210, label %bb52, label %bb53
bb52:
  call void @__olang_check_failed(ptr @olang_loc_21b1f67e4c6ce46b_15219dc677df2bef)
  unreachable
bb53:
  br label %bb54
bb54:
  %t212 = load ptr, ptr %l15, !tbaa !29
  store ptr %t212, ptr %l120, !tbaa !29
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t215 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t213)
  store i32 %t215, ptr %l122
  br label %bb55
bb55:
  %t216 = load ptr, ptr %l113, !tbaa !29
  %t217 = load ptr, ptr %l117, !tbaa !29
  %t218 = load ptr, ptr %l120, !tbaa !29
  %t219 = load i32, ptr %l122, !tbaa !23
  %t220 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFoldKnown(ptr %v0, ptr %v0, ptr %v1, ptr %t216, ptr %t217, ptr %t218, i32 %t219)
  store i32 %t220, ptr %l123
  br label %bb56
bb56:
  %t221 = load i32, ptr %l123, !tbaa !23
  store i32 %t221, ptr %l17, !tbaa !23
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/check:Checker", ptr %t222, i32 0, i32 1
  %t225 = load ptr, ptr %t224, !tbaa !29
  %t227 = getelementptr %"compiler/generic:Program", ptr %t225, i32 0, i32 2
  %t228 = load i32, ptr %l17, !tbaa !23
  %t231 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t227, i32 %t228)
  store i32 %t231, ptr %l128
  br label %bb57
bb57:
  %t232 = load i32, ptr %l128, !range !{i32 0, i32 33}
  %t234 = trunc i64 26 to i32
  %t235 = icmp eq i32 %t232, %t234
  %t237 = xor i1 %t235, true
  br i1 %t237, label %bb58, label %bb59
bb58:
  store i64 -2, ptr %rv
  br label %ret
bb59:
  br label %bb60
bb60:
  %t240 = load i64, ptr %l3, !tbaa !24
  %t242 = icmp slt i64 %t240, 0
  br i1 %t242, label %bb61, label %bb62
bb61:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t246 = getelementptr %"compiler/check:Checker", ptr %t244, i32 0, i32 1
  %t247 = load ptr, ptr %t246, !tbaa !29
  %t249 = getelementptr %"compiler/generic:Program", ptr %t247, i32 0, i32 2
  %t250 = load i32, ptr %l17, !tbaa !23
  %t253 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t249, i32 %t250)
  store i64 %t253, ptr %l140
  br label %bb63
bb62:
  store i1 false, ptr %l135, !tbaa !21
  br label %bb65
bb63:
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t256 = getelementptr %"compiler/check:Checker", ptr %t254, i32 0, i32 1
  %t257 = load ptr, ptr %t256, !tbaa !29
  %t259 = getelementptr %"compiler/generic:Program", ptr %t257, i32 0, i32 2
  %t260 = load i32, ptr %l2, !tbaa !23
  %t263 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t259, i32 %t260)
  store i64 %t263, ptr %l145
  br label %bb64
bb64:
  %t264 = load i64, ptr %l140, !tbaa !24
  %t265 = load i64, ptr %l145, !tbaa !24
  %t266 = icmp eq i64 %t264, %t265
  store i1 %t266, ptr %l135, !tbaa !21
  br label %bb65
bb65:
  %t268 = load i1, ptr %l135, !tbaa !21
  br i1 %t268, label %bb66, label %bb67
bb66:
  %t269 = load i64, ptr %l9, !tbaa !24
  store i64 %t269, ptr %l3, !tbaa !24
  br label %bb68
bb67:
  br label %bb68
bb68:
  br label %bb69
bb69:
  %t271 = load i64, ptr %l12, !tbaa !24
  %t273 = add i64 %t271, 1
  store i64 %t273, ptr %l12, !tbaa !24
  br label %bb25
bb70:
  br label %bb71
bb71:
  %t275 = load i64, ptr %l8, !tbaa !24
  %t277 = add i64 %t275, 1
  store i64 %t277, ptr %l8, !tbaa !24
  br label %bb18
bb72:
  %t279 = load i64, ptr %l3, !tbaa !24
  store i64 %t279, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/check:reflList" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca %"compiler/generic:Desc"
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i1
  %l20 = alloca { i64, ptr }
  %l21 = alloca i1
  %l24 = alloca i64
  %l27 = alloca i1
  %l31 = alloca i1
  %l36 = alloca %"compiler/check:reflList"
  %l37 = alloca %"compiler/check:reflList"
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l44 = alloca %"compiler/check:reflList"
  %l47 = alloca i32
  %l53 = alloca %"compiler/generic:Desc"
  %l57 = alloca i1
  %l64 = alloca %"compiler/check:reflList"
  %l68 = alloca i1
  %l74 = alloca %"compiler/check:reflList"
  %l78 = alloca i1
  %l84 = alloca %"compiler/check:reflList"
  %l85 = alloca %"compiler/check:reflList"
  %l88 = alloca i32
  %l91 = alloca %"compiler/check:reflList"
  %l94 = alloca i1
  %l95 = alloca i1
  %l98 = alloca i1
  %l100 = alloca i1
  %l104 = alloca i1
  %l105 = alloca %"compiler/check:reflList"
  %l108 = alloca %"compiler/check:reflList"
  %l109 = alloca ptr
  %l110 = alloca i1
  %l117 = alloca %"compiler/check:reflList"
  %l118 = alloca %"compiler/check:reflList"
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca %"compiler/check:reflList"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t2 = load ptr, ptr %l10, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l10, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 29}
  %t8 = icmp eq i64 %t6, 15
  store i1 %t8, ptr %l11, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l11, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t18, i32 0, i32 2
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb73
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i32, ptr %l3, !tbaa !23
  %t26 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t22, i32 %t23)
  store { i64, ptr } %t26, ptr %l20
  br label %bb6
bb6:
  %t27 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t28 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t27, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d9, i32 0, i32 1) })
  store i1 %t28, ptr %l21
  br label %bb7
bb7:
  %t29 = load i1, ptr %l21, !tbaa !21
  br i1 %t29, label %bb8, label %bb9
bb8:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t34 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ealiasModule(ptr %v0, ptr %v1, ptr %t30, ptr %t31)
  store i64 %t34, ptr %l24
  br label %bb10
bb9:
  br label %bb20
bb10:
  %t35 = load i64, ptr %l24, !tbaa !24
  store i64 %t35, ptr %l4, !tbaa !24
  %t36 = load i64, ptr %l4, !tbaa !24
  %t38 = icmp sge i64 %t36, 0
  br i1 %t38, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i64, ptr %l4, !tbaa !24
  %t42 = load i32, ptr %l3, !tbaa !23
  %t46 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclaresName(ptr %v0, ptr %t40, i64 %t41, i32 %t42)
  store i1 %t46, ptr %l31
  br label %bb13
bb12:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb14
bb13:
  %t47 = load i1, ptr %l31, !tbaa !21
  %t48 = xor i1 %t47, true
  store i1 %t48, ptr %l27, !tbaa !21
  br label %bb14
bb14:
  %t50 = load i1, ptr %l27, !tbaa !21
  br i1 %t50, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t51 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t52 = load i64, ptr @G_2ecompiler_2fgeneric_2eListFunctions, !tbaa !24
  %t53 = load i64, ptr %l4, !tbaa !24
  %t57 = call %"compiler/check:reflList" @compiler_2fcheck_3areflList_2ector(ptr %s3, i1 true, i32 %t51, i64 %t52, i64 %t53)
  store %"compiler/check:reflList" %t57, ptr %l36
  br label %bb17
bb16:
  br label %bb18
bb17:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s1)
  %t58 = load %"compiler/check:reflList", ptr %l36
  store %"compiler/check:reflList" %t58, ptr %rv
  br label %ret
bb18:
  %t59 = call %"compiler/check:reflList" @compiler_2fcheck_2enoList()
  store %"compiler/check:reflList" %t59, ptr %l37
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s1)
  %t60 = load %"compiler/check:reflList", ptr %l37
  store %"compiler/check:reflList" %t60, ptr %rv
  br label %ret
bb20:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load i32, ptr %l3, !tbaa !23
  %t65 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t61, i32 %t62)
  store { i64, ptr } %t65, ptr %l40
  br label %bb21
bb21:
  %t66 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t67 = call i64 @compiler_2fcheck_2elistIndex(ptr %v0, { i64, ptr } %t66)
  store i64 %t67, ptr %l41
  br label %bb22
bb22:
  %t68 = load i64, ptr %l41, !tbaa !24
  store i64 %t68, ptr %l5, !tbaa !24
  %t69 = load i64, ptr %l5, !tbaa !24
  %t71 = icmp slt i64 %t69, 0
  br i1 %t71, label %bb23, label %bb24
bb23:
  %t73 = call %"compiler/check:reflList" @compiler_2fcheck_2enoList()
  store %"compiler/check:reflList" %t73, ptr %l44
  br label %bb25
bb24:
  br label %bb26
bb25:
  call void @__olang_scope_close(ptr %s1)
  %t74 = load %"compiler/check:reflList", ptr %l44
  store %"compiler/check:reflList" %t74, ptr %rv
  br label %ret
bb26:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load ptr, ptr %l2, !tbaa !29
  %t79 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescTypeOf(ptr %v0, ptr %v1, ptr %t75, ptr %t76)
  store i32 %t79, ptr %l47
  br label %bb27
bb27:
  %t80 = load i32, ptr %l47, !tbaa !23
  store i32 %t80, ptr %l6, !tbaa !23
  %t81 = load i32, ptr %l6, !tbaa !23
  %t83 = icmp sge i32 %t81, 0
  br i1 %t83, label %bb28, label %bb29
bb28:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/check:Checker", ptr %t85, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t89 = load i32, ptr %l6, !tbaa !23
  %t92 = call %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %t88, i32 %t89)
  store %"compiler/generic:Desc" %t92, ptr %l53
  br label %bb30
bb29:
  br label %bb53
bb30:
  %t93 = load %"compiler/generic:Desc", ptr %l53
  store %"compiler/generic:Desc" %t93, ptr %l7
  %t94 = getelementptr %"compiler/generic:Desc", ptr %l7, i32 0, i32 0
  %t95 = load i64, ptr %t94, !tbaa !24
  %t96 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescCase, !tbaa !24
  %t99 = icmp eq i64 %t95, %t96
  br i1 %t99, label %bb31, label %bb32
bb31:
  %t101 = load i64, ptr %l5, !tbaa !24
  %t102 = load i64, ptr @G_2ecompiler_2fgeneric_2eListFields, !tbaa !24
  %t105 = icmp eq i64 %t101, %t102
  store i1 %t105, ptr %l57, !tbaa !21
  br label %bb33
bb32:
  store i1 false, ptr %l57, !tbaa !21
  br label %bb33
bb33:
  %t107 = load i1, ptr %l57, !tbaa !21
  br i1 %t107, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s6
  %t108 = getelementptr %"compiler/generic:Desc", ptr %l7, i32 0, i32 1
  %t109 = load i32, ptr %t108, !tbaa !23
  %t110 = load i64, ptr %l5, !tbaa !24
  %t111 = getelementptr %"compiler/generic:Desc", ptr %l7, i32 0, i32 2
  %t112 = load i64, ptr %t111, !tbaa !24
  %t116 = call %"compiler/check:reflList" @compiler_2fcheck_3areflList_2ector(ptr %s6, i1 true, i32 %t109, i64 %t110, i64 %t112)
  store %"compiler/check:reflList" %t116, ptr %l64
  br label %bb36
bb35:
  br label %bb37
bb36:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s1)
  %t117 = load %"compiler/check:reflList", ptr %l64
  store %"compiler/check:reflList" %t117, ptr %rv
  br label %ret
bb37:
  %t118 = getelementptr %"compiler/generic:Desc", ptr %l7, i32 0, i32 0
  %t119 = load i64, ptr %t118, !tbaa !24
  %t120 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescFunc, !tbaa !24
  %t123 = icmp eq i64 %t119, %t120
  br i1 %t123, label %bb38, label %bb39
bb38:
  %t125 = load i64, ptr %l5, !tbaa !24
  %t126 = load i64, ptr @G_2ecompiler_2fgeneric_2eListParams, !tbaa !24
  %t129 = icmp eq i64 %t125, %t126
  store i1 %t129, ptr %l68, !tbaa !21
  br label %bb40
bb39:
  store i1 false, ptr %l68, !tbaa !21
  br label %bb40
bb40:
  %t131 = load i1, ptr %l68, !tbaa !21
  br i1 %t131, label %bb41, label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s7
  %t132 = load i32, ptr %l6, !tbaa !23
  %t133 = load i64, ptr %l5, !tbaa !24
  %t136 = call %"compiler/check:reflList" @compiler_2fcheck_3areflList_2ector(ptr %s7, i1 true, i32 %t132, i64 %t133, i64 -1)
  store %"compiler/check:reflList" %t136, ptr %l74
  br label %bb43
bb42:
  br label %bb44
bb43:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s1)
  %t137 = load %"compiler/check:reflList", ptr %l74
  store %"compiler/check:reflList" %t137, ptr %rv
  br label %ret
bb44:
  %t138 = getelementptr %"compiler/generic:Desc", ptr %l7, i32 0, i32 0
  %t139 = load i64, ptr %t138, !tbaa !24
  %t140 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescFunc, !tbaa !24
  %t143 = icmp eq i64 %t139, %t140
  br i1 %t143, label %bb45, label %bb46
bb45:
  %t145 = load i64, ptr %l5, !tbaa !24
  %t146 = load i64, ptr @G_2ecompiler_2fgeneric_2eListResults, !tbaa !24
  %t149 = icmp eq i64 %t145, %t146
  store i1 %t149, ptr %l78, !tbaa !21
  br label %bb47
bb46:
  store i1 false, ptr %l78, !tbaa !21
  br label %bb47
bb47:
  %t151 = load i1, ptr %l78, !tbaa !21
  br i1 %t151, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s8
  %t152 = getelementptr %"compiler/generic:Desc", ptr %l7, i32 0, i32 1
  %t153 = load i32, ptr %t152, !tbaa !23
  %t154 = load i64, ptr %l5, !tbaa !24
  %t157 = call %"compiler/check:reflList" @compiler_2fcheck_3areflList_2ector(ptr %s8, i1 true, i32 %t153, i64 %t154, i64 -1)
  store %"compiler/check:reflList" %t157, ptr %l84
  br label %bb50
bb49:
  br label %bb51
bb50:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s1)
  %t158 = load %"compiler/check:reflList", ptr %l84
  store %"compiler/check:reflList" %t158, ptr %rv
  br label %ret
bb51:
  %t159 = call %"compiler/check:reflList" @compiler_2fcheck_2enoList()
  store %"compiler/check:reflList" %t159, ptr %l85
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s1)
  %t160 = load %"compiler/check:reflList", ptr %l85
  store %"compiler/check:reflList" %t160, ptr %rv
  br label %ret
bb53:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load ptr, ptr %l2, !tbaa !29
  %t165 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflType(ptr %v0, ptr %v1, ptr %t161, ptr %t162)
  store i32 %t165, ptr %l88
  br label %bb54
bb54:
  %t166 = load i32, ptr %l88, !tbaa !23
  store i32 %t166, ptr %l8, !tbaa !23
  %t167 = load i32, ptr %l8, !tbaa !23
  %t169 = icmp slt i32 %t167, 0
  br i1 %t169, label %bb55, label %bb56
bb55:
  %t171 = call %"compiler/check:reflList" @compiler_2fcheck_2enoList()
  store %"compiler/check:reflList" %t171, ptr %l91
  br label %bb57
bb56:
  br label %bb58
bb57:
  call void @__olang_scope_close(ptr %s1)
  %t172 = load %"compiler/check:reflList", ptr %l91
  store %"compiler/check:reflList" %t172, ptr %rv
  br label %ret
bb58:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load i32, ptr %l8, !tbaa !23
  %t177 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t173, i32 %t174)
  store i1 %t177, ptr %l94
  br label %bb59
bb59:
  %t178 = load i1, ptr %l94, !tbaa !21
  br i1 %t178, label %bb60, label %bb61
bb60:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = load ptr, ptr %l2, !tbaa !29
  %t183 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eviaTypeVar(ptr %v0, ptr %v1, ptr %t179, ptr %t180)
  store i1 %t183, ptr %l98
  br label %bb62
bb61:
  store i1 false, ptr %l95, !tbaa !21
  br label %bb63
bb62:
  %t184 = load i1, ptr %l98, !tbaa !21
  %t185 = xor i1 %t184, true
  store i1 %t185, ptr %l95, !tbaa !21
  br label %bb63
bb63:
  %t187 = load i1, ptr %l95, !tbaa !21
  br i1 %t187, label %bb64, label %bb65
bb64:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t189 = load i32, ptr %l8, !tbaa !23
  %t190 = load i32, ptr %l3, !tbaa !23
  %t194 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehasCase(ptr %v0, ptr %t188, i32 %t189, i32 %t190)
  store i1 %t194, ptr %l104
  br label %bb66
bb65:
  store i1 false, ptr %l100, !tbaa !21
  br label %bb67
bb66:
  %t195 = load i1, ptr %l104, !tbaa !21
  store i1 %t195, ptr %l100, !tbaa !21
  br label %bb67
bb67:
  %t196 = load i1, ptr %l100, !tbaa !21
  br i1 %t196, label %bb68, label %bb69
bb68:
  %t197 = call %"compiler/check:reflList" @compiler_2fcheck_2enoList()
  store %"compiler/check:reflList" %t197, ptr %l105
  br label %bb70
bb69:
  br label %bb71
bb70:
  call void @__olang_scope_close(ptr %s1)
  %t198 = load %"compiler/check:reflList", ptr %l105
  store %"compiler/check:reflList" %t198, ptr %rv
  br label %ret
bb71:
  %t199 = load i32, ptr %l8, !tbaa !23
  %t200 = load i64, ptr %l5, !tbaa !24
  %t203 = call %"compiler/check:reflList" @compiler_2fcheck_3areflList_2ector(ptr %s1, i1 true, i32 %t199, i64 %t200, i64 -1)
  store %"compiler/check:reflList" %t203, ptr %l108
  br label %bb72
bb72:
  call void @__olang_scope_close(ptr %s1)
  %t204 = load %"compiler/check:reflList", ptr %l108
  store %"compiler/check:reflList" %t204, ptr %rv
  br label %ret
bb73:
  %t205 = load ptr, ptr %l1, !tbaa !29
  store ptr %t205, ptr %l109, !tbaa !29
  store i1 false, ptr %l110, !tbaa !21
  %t206 = load ptr, ptr %l109, !tbaa !29
  %t207 = icmp ne ptr %t206, null
  br i1 %t207, label %bb74, label %bb75
bb74:
  %t209 = load ptr, ptr %l109, !tbaa !29
  %t210 = load i64, ptr %t209, !range !{i64 0, i64 29}
  %t212 = icmp eq i64 %t210, 2
  store i1 %t212, ptr %l110, !tbaa !21
  br label %bb75
bb75:
  %t213 = load i1, ptr %l110, !tbaa !21
  br i1 %t213, label %bb76, label %bb77
bb76:
  %t214 = load ptr, ptr %l1, !tbaa !29
  %t216 = getelementptr { i64, [5 x i64] }, ptr %t214, i32 0, i32 1
  %t217 = getelementptr { %"compiler/source:Span", ptr }, ptr %t216, i32 0, i32 1
  %t218 = load ptr, ptr %t217
  store ptr %t218, ptr %l9, !tbaa !29
  br label %bb78
bb77:
  br label %bb80
bb78:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load ptr, ptr %l9, !tbaa !29
  %t224 = call %"compiler/check:reflList" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistOf(ptr %v0, ptr %v1, ptr %t220, ptr %t221)
  store %"compiler/check:reflList" %t224, ptr %l117
  br label %bb79
bb79:
  %t225 = load %"compiler/check:reflList", ptr %l117
  store %"compiler/check:reflList" %t225, ptr %rv
  br label %ret
bb80:
  br i1 true, label %bb81, label %bb82
bb81:
  br label %bb83
bb82:
  br label %bb85
bb83:
  %t226 = call %"compiler/check:reflList" @compiler_2fcheck_2enoList()
  store %"compiler/check:reflList" %t226, ptr %l118
  br label %bb84
bb84:
  %t227 = load %"compiler/check:reflList", ptr %l118
  store %"compiler/check:reflList" %t227, ptr %rv
  br label %ret
bb85:
  call void @__olang_check_failed(ptr @olang_loc_7b7c458ad09559c8_7a5ff3a2c3d540e4)
  unreachable
ret:
  %rr = load %"compiler/check:reflList", ptr %rv
  ret %"compiler/check:reflList" %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitArray(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l24 = alloca i32
  %l26 = alloca ptr
  %l27 = alloca i1
  %l34 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca i1
  %l45 = alloca i1
  %l46 = alloca i1
  %l49 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca i1
  %l64 = alloca { i64, ptr }
  %l70 = alloca i1
  %l71 = alloca ptr
  %l77 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t2 = load ptr, ptr %l11, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l11, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 29}
  %t8 = icmp eq i64 %t6, 18
  store i1 %t8, ptr %l12, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l12, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %rv
  br label %ret
bb6:
  %t11 = load ptr, ptr %l1, !tbaa !29
  store ptr %t11, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t12 = load ptr, ptr %l16, !tbaa !29
  %t13 = icmp ne ptr %t12, null
  br i1 %t13, label %bb7, label %bb8
bb7:
  %t15 = load ptr, ptr %l16, !tbaa !29
  %t16 = load i64, ptr %t15, !range !{i64 0, i64 29}
  %t18 = icmp eq i64 %t16, 16
  store i1 %t18, ptr %l17, !tbaa !21
  br label %bb8
bb8:
  %t19 = load i1, ptr %l17, !tbaa !21
  br i1 %t19, label %bb9, label %bb10
bb9:
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr { i64, [5 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t22, i32 0, i32 1
  %t24 = load ptr, ptr %t23
  store ptr %t24, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t30 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %t26, ptr %t27)
  store i32 %t30, ptr %l24
  br label %bb12
bb12:
  %t31 = load i32, ptr %l24, !tbaa !23
  %t32 = icmp sge i32 %t31, 0
  store i1 %t32, ptr %rv
  br label %ret
bb13:
  %t34 = load ptr, ptr %l1, !tbaa !29
  store ptr %t34, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t35 = load ptr, ptr %l26, !tbaa !29
  %t36 = icmp ne ptr %t35, null
  br i1 %t36, label %bb14, label %bb15
bb14:
  %t38 = load ptr, ptr %l26, !tbaa !29
  %t39 = load i64, ptr %t38, !range !{i64 0, i64 29}
  %t41 = icmp eq i64 %t39, 2
  store i1 %t41, ptr %l27, !tbaa !21
  br label %bb15
bb15:
  %t42 = load i1, ptr %l27, !tbaa !21
  br i1 %t42, label %bb16, label %bb17
bb16:
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = getelementptr { i64, [5 x i64] }, ptr %t43, i32 0, i32 1
  %t46 = getelementptr { %"compiler/source:Span", ptr }, ptr %t45, i32 0, i32 1
  %t47 = load ptr, ptr %t46
  store ptr %t47, ptr %l3, !tbaa !29
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load ptr, ptr %l3, !tbaa !29
  %t53 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitArray(ptr %v0, ptr %v1, ptr %t49, ptr %t50)
  store i1 %t53, ptr %l34
  br label %bb19
bb19:
  %t54 = load i1, ptr %l34, !tbaa !21
  store i1 %t54, ptr %rv
  br label %ret
bb20:
  %t55 = load ptr, ptr %l1, !tbaa !29
  store ptr %t55, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t56 = load ptr, ptr %l35, !tbaa !29
  %t57 = icmp ne ptr %t56, null
  br i1 %t57, label %bb21, label %bb22
bb21:
  %t59 = load ptr, ptr %l35, !tbaa !29
  %t60 = load i64, ptr %t59, !range !{i64 0, i64 29}
  %t62 = icmp eq i64 %t60, 8
  store i1 %t62, ptr %l36, !tbaa !21
  br label %bb22
bb22:
  %t63 = load i1, ptr %l36, !tbaa !21
  br i1 %t63, label %bb23, label %bb24
bb23:
  %t64 = load ptr, ptr %l1, !tbaa !29
  %t66 = getelementptr { i64, [5 x i64] }, ptr %t64, i32 0, i32 1
  %t67 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t66, i32 0, i32 1
  %t68 = load ptr, ptr %t67
  store ptr %t68, ptr %l4, !tbaa !29
  %t70 = load ptr, ptr %l1, !tbaa !29
  %t72 = getelementptr { i64, [5 x i64] }, ptr %t70, i32 0, i32 1
  %t73 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t72, i32 0, i32 3
  %t74 = load ptr, ptr %t73
  store ptr %t74, ptr %l5, !tbaa !29
  br label %bb25
bb24:
  br label %bb31
bb25:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load ptr, ptr %l4, !tbaa !29
  %t80 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitArray(ptr %v0, ptr %v1, ptr %t76, ptr %t77)
  store i1 %t80, ptr %l45
  br label %bb26
bb26:
  %t81 = load i1, ptr %l45, !tbaa !21
  br i1 %t81, label %bb27, label %bb28
bb27:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load ptr, ptr %l5, !tbaa !29
  %t86 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitArray(ptr %v0, ptr %v1, ptr %t82, ptr %t83)
  store i1 %t86, ptr %l49
  br label %bb29
bb28:
  store i1 false, ptr %l46, !tbaa !21
  br label %bb30
bb29:
  %t87 = load i1, ptr %l49, !tbaa !21
  store i1 %t87, ptr %l46, !tbaa !21
  br label %bb30
bb30:
  %t88 = load i1, ptr %l46, !tbaa !21
  store i1 %t88, ptr %rv
  br label %ret
bb31:
  %t89 = load ptr, ptr %l1, !tbaa !29
  store ptr %t89, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t90 = load ptr, ptr %l50, !tbaa !29
  %t91 = icmp ne ptr %t90, null
  br i1 %t91, label %bb32, label %bb33
bb32:
  %t93 = load ptr, ptr %l50, !tbaa !29
  %t94 = load i64, ptr %t93, !range !{i64 0, i64 29}
  %t96 = icmp eq i64 %t94, 24
  store i1 %t96, ptr %l51, !tbaa !21
  br label %bb33
bb33:
  %t97 = load i1, ptr %l51, !tbaa !21
  br i1 %t97, label %bb34, label %bb35
bb34:
  %t98 = load ptr, ptr %l1, !tbaa !29
  %t100 = getelementptr { i64, [5 x i64] }, ptr %t98, i32 0, i32 1
  %t101 = getelementptr { %"compiler/source:Span", ptr }, ptr %t100, i32 0, i32 1
  %t102 = load ptr, ptr %t101
  store ptr %t102, ptr %l6, !tbaa !29
  br label %bb36
bb35:
  br label %bb53
bb36:
  %t104 = load ptr, ptr %l6, !tbaa !29
  %t106 = getelementptr %"compiler/ast:Match", ptr %t104, i32 0, i32 3
  %t107 = load { i64, ptr }, ptr %t106, !tbaa !27
  store { i64, ptr } %t107, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t109 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t111 = extractvalue { i64, ptr } %t109, 0
  store i64 %t111, ptr %l9, !tbaa !24
  br label %bb37
bb37:
  %t113 = load i64, ptr %l8, !tbaa !24
  %t114 = load i64, ptr %l9, !tbaa !24
  %t117 = icmp slt i64 %t113, %t114
  %t119 = xor i1 %t117, true
  br i1 %t119, label %bb38, label %bb39
bb38:
  br label %bb52
bb39:
  br label %bb40
bb40:
  %t121 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t121, ptr %l64, !tbaa !27
  %t122 = load i64, ptr %l8, !tbaa !24
  %t124 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr ptr, ptr %t125, i64 %t122
  %t127 = load ptr, ptr %t126, !tbaa !39
  store ptr %t127, ptr %l10, !tbaa !29
  %t129 = load ptr, ptr %l10, !tbaa !29
  %t131 = getelementptr %"compiler/ast:Case", ptr %t129, i32 0, i32 5
  %t132 = load ptr, ptr %t131, !tbaa !29
  %t134 = icmp eq ptr %t132, null
  br i1 %t134, label %bb41, label %bb42
bb41:
  store i1 true, ptr %l70, !tbaa !21
  br label %bb47
bb42:
  %t136 = load ptr, ptr %l0, !tbaa !29
  store ptr %t136, ptr %l71, !tbaa !29
  %t137 = load ptr, ptr %l10, !tbaa !29
  %t139 = getelementptr %"compiler/ast:Case", ptr %t137, i32 0, i32 5
  %t140 = load ptr, ptr %t139, !tbaa !29
  %t142 = icmp eq ptr %t140, null
  br i1 %t142, label %bb43, label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_ddeebe9155436d6a_19ee353760b572b6)
  unreachable
bb44:
  br label %bb45
bb45:
  %t144 = load ptr, ptr %l10, !tbaa !29
  %t146 = getelementptr %"compiler/ast:Case", ptr %t144, i32 0, i32 5
  %t147 = load ptr, ptr %t146, !tbaa !29
  %t148 = load ptr, ptr %l71, !tbaa !29
  %t150 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitArray(ptr %v0, ptr %v1, ptr %t148, ptr %t147)
  store i1 %t150, ptr %l77
  br label %bb46
bb46:
  %t151 = load i1, ptr %l77, !tbaa !21
  %t152 = xor i1 %t151, true
  store i1 %t152, ptr %l70, !tbaa !21
  br label %bb47
bb47:
  %t154 = load i1, ptr %l70, !tbaa !21
  br i1 %t154, label %bb48, label %bb49
bb48:
  store i1 false, ptr %rv
  br label %ret
bb49:
  br label %bb50
bb50:
  br label %bb51
bb51:
  %t156 = load i64, ptr %l8, !tbaa !24
  %t158 = add i64 %t156, 1
  store i64 %t158, ptr %l8, !tbaa !24
  br label %bb37
bb52:
  %t160 = load ptr, ptr %l6, !tbaa !29
  %t162 = getelementptr %"compiler/ast:Match", ptr %t160, i32 0, i32 3
  %t163 = load { i64, ptr }, ptr %t162, !tbaa !27
  %t165 = extractvalue { i64, ptr } %t163, 0
  %t167 = icmp sgt i64 %t165, 0
  store i1 %t167, ptr %rv
  br label %ret
bb53:
  br i1 true, label %bb54, label %bb55
bb54:
  br label %bb56
bb55:
  br label %bb57
bb56:
  store i1 false, ptr %rv
  br label %ret
bb57:
  call void @__olang_check_failed(ptr @olang_loc_7406e676cee1d8f8_b07044052169e244)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFloat(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/check:litv"
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l9 = alloca %"compiler/check:litv"
  %l12 = alloca ptr
  %l13 = alloca i1
  %l20 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i1
  %l31 = alloca i1
  %l32 = alloca i1
  %l35 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t6 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store %"compiler/check:litv" %t6, ptr %l9
  br label %bb1
bb1:
  %t7 = load %"compiler/check:litv", ptr %l9
  store %"compiler/check:litv" %t7, ptr %l2
  %t8 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 0
  %t9 = load i1, ptr %t8, !tbaa !21
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 1
  %t12 = load i1, ptr %t11, !tbaa !21
  store i1 %t12, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l1, !tbaa !29
  store ptr %t14, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t15 = load ptr, ptr %l12, !tbaa !29
  %t16 = icmp ne ptr %t15, null
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t18 = load ptr, ptr %l12, !tbaa !29
  %t19 = load i64, ptr %t18, !range !{i64 0, i64 29}
  %t21 = icmp eq i64 %t19, 2
  store i1 %t21, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t22 = load i1, ptr %l13, !tbaa !21
  br i1 %t22, label %bb7, label %bb8
bb7:
  %t23 = load ptr, ptr %l1, !tbaa !29
  %t25 = getelementptr { i64, [5 x i64] }, ptr %t23, i32 0, i32 1
  %t26 = getelementptr { %"compiler/source:Span", ptr }, ptr %t25, i32 0, i32 1
  %t27 = load ptr, ptr %t26
  store ptr %t27, ptr %l3, !tbaa !29
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load ptr, ptr %l3, !tbaa !29
  %t33 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFloat(ptr %v0, ptr %v1, ptr %t29, ptr %t30)
  store i1 %t33, ptr %l20
  br label %bb10
bb10:
  %t34 = load i1, ptr %l20, !tbaa !21
  store i1 %t34, ptr %rv
  br label %ret
bb11:
  %t35 = load ptr, ptr %l1, !tbaa !29
  store ptr %t35, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t36 = load ptr, ptr %l21, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb12, label %bb13
bb12:
  %t39 = load ptr, ptr %l21, !tbaa !29
  %t40 = load i64, ptr %t39, !range !{i64 0, i64 29}
  %t42 = icmp eq i64 %t40, 8
  store i1 %t42, ptr %l22, !tbaa !21
  br label %bb13
bb13:
  %t43 = load i1, ptr %l22, !tbaa !21
  br i1 %t43, label %bb14, label %bb15
bb14:
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t46 = getelementptr { i64, [5 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t46, i32 0, i32 1
  %t48 = load ptr, ptr %t47
  store ptr %t48, ptr %l4, !tbaa !29
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t52 = getelementptr { i64, [5 x i64] }, ptr %t50, i32 0, i32 1
  %t53 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t52, i32 0, i32 3
  %t54 = load ptr, ptr %t53
  store ptr %t54, ptr %l5, !tbaa !29
  br label %bb16
bb15:
  br label %bb22
bb16:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load ptr, ptr %l4, !tbaa !29
  %t60 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFloat(ptr %v0, ptr %v1, ptr %t56, ptr %t57)
  store i1 %t60, ptr %l31
  br label %bb17
bb17:
  %t61 = load i1, ptr %l31, !tbaa !21
  br i1 %t61, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb21
bb19:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load ptr, ptr %l5, !tbaa !29
  %t66 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFloat(ptr %v0, ptr %v1, ptr %t62, ptr %t63)
  store i1 %t66, ptr %l35
  br label %bb20
bb20:
  %t67 = load i1, ptr %l35, !tbaa !21
  store i1 %t67, ptr %l32, !tbaa !21
  br label %bb21
bb21:
  %t68 = load i1, ptr %l32, !tbaa !21
  store i1 %t68, ptr %rv
  br label %ret
bb22:
  br i1 true, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  store i1 false, ptr %rv
  br label %ret
bb26:
  call void @__olang_check_failed(ptr @olang_loc_742d7ba0854a02e0_30f006efbe908ac)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eloopCall(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, ptr %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca %"compiler/generic:AnySlot"
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca i64
  %l26 = alloca ptr
  %l29 = alloca i32
  %l32 = alloca i64
  %l33 = alloca ptr
  %l41 = alloca ptr
  %l44 = alloca i32
  %l45 = alloca i32
  %l49 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l59 = alloca ptr
  %l60 = alloca %"compiler/source:Span"
  %l61 = alloca %"compiler/source:Span"
  %l62 = alloca i32
  %l68 = alloca ptr
  %l70 = alloca ptr
  %l75 = alloca ptr
  %l77 = alloca ptr
  %l78 = alloca %"compiler/source:Span"
  %l79 = alloca %"compiler/source:Span"
  %l80 = alloca i64
  %l82 = alloca ptr
  %l85 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l90 = alloca ptr
  %l92 = alloca ptr
  %l100 = alloca { i64, ptr }
  %l107 = alloca { i64, ptr }
  %l114 = alloca i32
  %l117 = alloca ptr
  %l122 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l126 = alloca i64
  %l130 = alloca i64
  %l133 = alloca i64
  %l153 = alloca ptr
  %l157 = alloca i32
  %l158 = alloca i32
  %l161 = alloca ptr
  %l165 = alloca i32
  %l172 = alloca i64
  %l174 = alloca i64
  %l179 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca ptr
  %t95 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i64 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l26
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l26, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %s0, ptr %s0, ptr %t8, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d10, i32 0, i32 1) }, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d11, i32 0, i32 1) })
  store i32 %t10, ptr %l29
  br label %bb2
bb2:
  %t11 = load i32, ptr %l29, !tbaa !23
  store i32 %t11, ptr %l6, !tbaa !23
  %t12 = load ptr, ptr %l5, !tbaa !29
  %t14 = getelementptr %"compiler/check:frame", ptr %t12, i32 0, i32 26
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t14)
  store i64 %t16, ptr %l32
  br label %bb3
bb3:
  %t17 = load i64, ptr %l32, !tbaa !24
  store i64 %t17, ptr %l7, !tbaa !24
  %t18 = load ptr, ptr %l5, !tbaa !29
  store ptr %t18, ptr %l33, !tbaa !29
  %t19 = load ptr, ptr %l33, !tbaa !29
  %t20 = getelementptr %"compiler/check:frame", ptr %t19, i32 0, i32 15
  %t21 = load i64, ptr %t20, !tbaa !24
  %t23 = add i64 %t21, 1
  %t25 = load ptr, ptr %l33, !tbaa !29
  %t26 = getelementptr %"compiler/check:frame", ptr %t25, i32 0, i32 15
  store i64 %t23, ptr %t26, !tbaa !24
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/check:Checker", ptr %t27, i32 0, i32 41
  store i32 0, ptr %t29, !tbaa !23
  store ptr null, ptr %l8, !tbaa !29
  %t30 = load i64, ptr %l2, !tbaa !24
  %t32 = icmp slt i64 %t30, -1
  br i1 %t32, label %bb4, label %bb5
bb4:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/generic:Program", ptr %t37, i32 0, i32 2
  store ptr %t39, ptr %l41, !tbaa !29
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t43 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t40)
  store i32 %t43, ptr %l44
  br label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l77, !tbaa !29
  %t45 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t45, ptr %l78
  %t46 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t46, ptr %l79
  %t47 = load i64, ptr %l2, !tbaa !24
  store i64 %t47, ptr %l80, !tbaa !24
  %t48 = load ptr, ptr %l3, !tbaa !29
  store ptr %t48, ptr %l82, !tbaa !29
  %t50 = icmp sge i64 0, 0
  br i1 %t50, label %bb15, label %bb16
bb6:
  %t52 = load ptr, ptr %l41, !tbaa !29
  %t53 = load i32, ptr %l44, !tbaa !23
  %t54 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %t52, i32 %t53)
  store i32 %t54, ptr %l45
  br label %bb7
bb7:
  %t55 = load i32, ptr %l45, !tbaa !23
  store i32 %t55, ptr %l9, !tbaa !23
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t60 = load i32, ptr %l9, !tbaa !23
  %t63 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %t59, i32 %t60)
  store { i64, ptr } %t63, ptr %l49
  br label %bb8
bb8:
  %t64 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t64, ptr %l50, !tbaa !27
  %t65 = load i64, ptr %l2, !tbaa !24
  %t67 = sub i64 -2, %t65
  %t69 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr %"compiler/generic:AnySlot", ptr %t70, i64 %t67
  %t72 = load %"compiler/generic:AnySlot", ptr %t71
  store %"compiler/generic:AnySlot" %t72, ptr %l10
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load i32, ptr %l9, !tbaa !23
  %t76 = load i64, ptr %l2, !tbaa !24
  %t78 = sub i64 -2, %t76
  %t79 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eslotCall(ptr %v0, ptr %t74, i32 %t75, i64 %t78, %"compiler/source:Span" %t79)
  br label %bb9
bb9:
  %t84 = load ptr, ptr %l0, !tbaa !29
  store ptr %t84, ptr %l59, !tbaa !29
  %t85 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t85, ptr %l60
  %t86 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t86, ptr %l61
  %t87 = getelementptr %"compiler/generic:AnySlot", ptr %l10, i32 0, i32 5
  %t88 = load i32, ptr %t87, !tbaa !23
  store i32 %t88, ptr %l62, !tbaa !23
  %t89 = load i32, ptr %l9, !tbaa !23
  %t90 = load i64, ptr %l2, !tbaa !24
  %t92 = sub i64 -2, %t90
  %t93 = getelementptr %"compiler/generic:AnySlot", ptr %l10, i32 0, i32 5
  %t94 = load i32, ptr %t93, !tbaa !23
  store { i64, [3 x i64] } zeroinitializer, ptr %t95
  %t96 = getelementptr { i64, [3 x i64] }, ptr %t95, i32 0, i32 0
  store i64 3, ptr %t96
  %t98 = insertvalue { i32, i64, i32 } undef, i32 %t89, 0
  %t100 = insertvalue { i32, i64, i32 } %t98, i64 %t92, 1
  %t102 = insertvalue { i32, i64, i32 } %t100, i32 %t94, 2
  %t103 = getelementptr { i64, [3 x i64] }, ptr %t95, i32 0, i32 1
  store { i32, i64, i32 } %t102, ptr %t103
  %t104 = load { i64, [3 x i64] }, ptr %t95
  %t106 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t104, ptr %t106
  store ptr %t106, ptr %l68, !tbaa !29
  %t107 = load ptr, ptr %l3, !tbaa !29
  store ptr %t107, ptr %l70, !tbaa !29
  %t109 = icmp sge i64 0, 0
  br i1 %t109, label %bb10, label %bb11
bb10:
  %t111 = icmp sle i64 0, 1152921504606846975
  br i1 %t111, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_652199a1d15cfac6_f2a0b86627c88902)
  unreachable
bb12:
  %t113 = mul i64 0, 8
  %t114 = insertvalue { i64, ptr } undef, i64 0, 0
  %t115 = insertvalue { i64, ptr } %t114, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t116 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t117 = load ptr, ptr %l59, !tbaa !29
  %t118 = load %"compiler/source:Span", ptr %l60
  %t119 = load %"compiler/source:Span", ptr %l61
  %t120 = load i32, ptr %l62, !tbaa !23
  %t121 = load ptr, ptr %l68, !tbaa !29
  %t122 = load ptr, ptr %l70, !tbaa !29
  %t125 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallBody(ptr %v0, ptr %v0, ptr %t117, %"compiler/source:Span" %t118, %"compiler/source:Span" %t119, i32 %t120, ptr %t121, i64 -1, ptr %t122, { i64, ptr } %t115, { i64, ptr } %t116)
  store ptr %t125, ptr %l75
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_652199a1d15cfac6_f2a0b86627c88902)
  unreachable
bb14:
  %t126 = load ptr, ptr %l75, !tbaa !29
  store ptr %t126, ptr %l8, !tbaa !29
  br label %bb24
bb15:
  %t128 = icmp sle i64 0, 1152921504606846975
  br i1 %t128, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_7509e56452997e5b_fb360af196d85db7)
  unreachable
bb17:
  %t130 = mul i64 0, 8
  %t131 = insertvalue { i64, ptr } undef, i64 0, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t132, ptr %l85, !tbaa !27
  %t133 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t133, ptr %l86, !tbaa !27
  %t134 = icmp sge i64 0, 0
  br i1 %t134, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_7509e56452997e5b_fb360af196d85db7)
  unreachable
bb19:
  %t136 = icmp sle i64 0, 2305843009213693951
  br i1 %t136, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_ff81ff8210117a78_6f7a62fdc976c914)
  unreachable
bb21:
  %t138 = mul i64 0, 4
  %t139 = insertvalue { i64, ptr } undef, i64 0, 0
  %t140 = insertvalue { i64, ptr } %t139, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t141 = load ptr, ptr %l77, !tbaa !29
  %t142 = load %"compiler/source:Span", ptr %l78
  %t143 = load %"compiler/source:Span", ptr %l79
  %t144 = load i64, ptr %l80, !tbaa !24
  %t145 = load ptr, ptr %l82, !tbaa !29
  %t146 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t147 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t149 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %s2, ptr %t141, %"compiler/source:Span" %t142, %"compiler/source:Span" %t143, i64 %t144, ptr %t145, { i64, ptr } %t146, { i64, ptr } %t147, { i64, ptr } %t140)
  store ptr %t149, ptr %l90
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_ff81ff8210117a78_6f7a62fdc976c914)
  unreachable
bb23:
  %t150 = load ptr, ptr %l90, !tbaa !29
  store ptr %t150, ptr %l8, !tbaa !29
  call void @__olang_scope_close(ptr %s2)
  br label %bb24
bb24:
  %t152 = load ptr, ptr %l5, !tbaa !29
  store ptr %t152, ptr %l92, !tbaa !29
  %t153 = load ptr, ptr %l92, !tbaa !29
  %t154 = getelementptr %"compiler/check:frame", ptr %t153, i32 0, i32 15
  %t155 = load i64, ptr %t154, !tbaa !24
  %t157 = sub i64 %t155, 1
  %t159 = load ptr, ptr %l92, !tbaa !29
  %t160 = getelementptr %"compiler/check:frame", ptr %t159, i32 0, i32 15
  store i64 %t157, ptr %t160, !tbaa !24
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = getelementptr %"compiler/check:Checker", ptr %t161, i32 0, i32 1
  %t164 = load ptr, ptr %t163, !tbaa !29
  %t166 = getelementptr %"compiler/generic:Program", ptr %t164, i32 0, i32 2
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/check:Checker", ptr %t167, i32 0, i32 41
  %t170 = load i32, ptr %t169, !tbaa !23
  %t173 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t166, i32 %t170)
  store { i64, ptr } %t173, ptr %l100
  br label %bb25
bb25:
  %t174 = load { i64, ptr }, ptr %l100, !tbaa !27
  store { i64, ptr } %t174, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t175 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t177 = extractvalue { i64, ptr } %t175, 0
  store i64 %t177, ptr %l13, !tbaa !24
  br label %bb26
bb26:
  %t179 = load i64, ptr %l12, !tbaa !24
  %t180 = load i64, ptr %l13, !tbaa !24
  %t183 = icmp slt i64 %t179, %t180
  %t185 = xor i1 %t183, true
  br i1 %t185, label %bb27, label %bb28
bb27:
  br label %bb35
bb28:
  br label %bb29
bb29:
  %t187 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t187, ptr %l107, !tbaa !27
  %t188 = load i64, ptr %l12, !tbaa !24
  %t190 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !27
  %t192 = getelementptr i32, ptr %t191, i64 %t188
  %t193 = load i32, ptr %t192, !tbaa !33
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/check:Checker", ptr %t195, i32 0, i32 1
  %t198 = load ptr, ptr %t197, !tbaa !29
  %t200 = getelementptr %"compiler/generic:Program", ptr %t198, i32 0, i32 2
  %t204 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t200, i32 %t193)
  store i32 %t204, ptr %l114
  br label %bb30
bb30:
  %t205 = load i32, ptr %l6, !tbaa !23
  %t206 = load i32, ptr %l114, !tbaa !23
  %t208 = icmp ne i32 %t206, %t205
  br i1 %t208, label %bb31, label %bb32
bb31:
  %t210 = load ptr, ptr %l5, !tbaa !29
  store ptr %t210, ptr %l117, !tbaa !29
  %t211 = load ptr, ptr %l117, !tbaa !29
  %t212 = getelementptr %"compiler/check:frame", ptr %t211, i32 0, i32 17
  %t213 = load i64, ptr %t212, !tbaa !24
  %t215 = add i64 %t213, 1
  %t217 = load ptr, ptr %l117, !tbaa !29
  %t218 = getelementptr %"compiler/check:frame", ptr %t217, i32 0, i32 17
  store i64 %t215, ptr %t218, !tbaa !24
  br label %bb33
bb32:
  br label %bb33
bb33:
  br label %bb34
bb34:
  %t219 = load i64, ptr %l12, !tbaa !24
  %t221 = add i64 %t219, 1
  store i64 %t221, ptr %l12, !tbaa !24
  br label %bb26
bb35:
  %t223 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t223, ptr %l122
  br label %bb36
bb36:
  %t224 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l122
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t224, ptr %l15
  %t225 = load i64, ptr %l7, !tbaa !24
  store i64 %t225, ptr %l16, !tbaa !24
  %t227 = load ptr, ptr %l5, !tbaa !29
  %t229 = getelementptr %"compiler/check:frame", ptr %t227, i32 0, i32 26
  %t231 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t229)
  store i64 %t231, ptr %l126
  br label %bb37
bb37:
  %t232 = load i64, ptr %l126, !tbaa !24
  store i64 %t232, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t233 = load i64, ptr %l17, !tbaa !24
  %t234 = load i64, ptr %l16, !tbaa !24
  %t237 = icmp sgt i64 %t233, %t234
  br i1 %t237, label %bb38, label %bb39
bb38:
  %t239 = load i64, ptr %l18, !tbaa !24
  %t241 = icmp sgt i64 %t239, 0
  br i1 %t241, label %bb40, label %bb41
bb39:
  store i64 0, ptr %l130, !tbaa !24
  br label %bb43
bb40:
  %t243 = load i64, ptr %l17, !tbaa !24
  %t244 = load i64, ptr %l16, !tbaa !24
  %t247 = sub i64 %t243, %t244
  %t248 = load i64, ptr %l18, !tbaa !24
  %t251 = add i64 %t247, %t248
  %t253 = sub i64 %t251, 1
  %t254 = load i64, ptr %l18, !tbaa !24
  %t257 = sdiv i64 %t253, %t254
  store i64 %t257, ptr %l133, !tbaa !24
  br label %bb42
bb41:
  store i64 0, ptr %l133, !tbaa !24
  br label %bb42
bb42:
  %t259 = load i64, ptr %l133, !tbaa !24
  store i64 %t259, ptr %l130, !tbaa !24
  br label %bb43
bb43:
  %t260 = load i64, ptr %l130, !tbaa !24
  store i64 %t260, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb44
bb44:
  %t261 = load i64, ptr %l20, !tbaa !24
  %t262 = load i64, ptr %l19, !tbaa !24
  %t265 = icmp slt i64 %t261, %t262
  %t267 = xor i1 %t265, true
  br i1 %t267, label %bb45, label %bb46
bb45:
  br label %bb56
bb46:
  br label %bb47
bb47:
  %t269 = load i64, ptr %l16, !tbaa !24
  %t270 = load i64, ptr %l20, !tbaa !24
  %t271 = load i64, ptr %l18, !tbaa !24
  %t274 = mul i64 %t270, %t271
  %t277 = add i64 %t269, %t274
  store i64 %t277, ptr %l21, !tbaa !24
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t281 = getelementptr %"compiler/check:Checker", ptr %t279, i32 0, i32 1
  %t282 = load ptr, ptr %t281, !tbaa !29
  %t284 = getelementptr %"compiler/generic:Program", ptr %t282, i32 0, i32 2
  store ptr %t284, ptr %l153, !tbaa !29
  %t285 = load ptr, ptr %l5, !tbaa !29
  %t287 = getelementptr %"compiler/check:frame", ptr %t285, i32 0, i32 26
  %t288 = load i64, ptr %l21, !tbaa !24
  %t291 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t287, i64 %t288)
  store i32 %t291, ptr %l157
  br label %bb48
bb48:
  %t292 = load ptr, ptr %l153, !tbaa !29
  %t293 = load i32, ptr %l157, !tbaa !23
  %t294 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t292, i32 %t293)
  store i32 %t294, ptr %l158
  br label %bb49
bb49:
  %t295 = load i32, ptr %l6, !tbaa !23
  %t296 = load i32, ptr %l158, !tbaa !23
  %t298 = icmp ne i32 %t296, %t295
  br i1 %t298, label %bb50, label %bb51
bb50:
  store ptr %l15, ptr %l161, !tbaa !29
  %t300 = load ptr, ptr %l5, !tbaa !29
  %t302 = getelementptr %"compiler/check:frame", ptr %t300, i32 0, i32 26
  %t303 = load i64, ptr %l21, !tbaa !24
  %t306 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t302, i64 %t303)
  store i32 %t306, ptr %l165
  br label %bb52
bb51:
  br label %bb54
bb52:
  %t307 = load ptr, ptr %l161, !tbaa !29
  %t308 = load i32, ptr %l165, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t307, i32 %t308)
  br label %bb53
bb53:
  br label %bb54
bb54:
  br label %bb55
bb55:
  %t309 = load i64, ptr %l20, !tbaa !24
  %t311 = add i64 %t309, 1
  store i64 %t311, ptr %l20, !tbaa !24
  br label %bb44
bb56:
  %t313 = load ptr, ptr %l5, !tbaa !29
  %t315 = getelementptr %"compiler/check:frame", ptr %t313, i32 0, i32 26
  %t316 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eTruncate_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t315, i64 %t316)
  br label %bb57
bb57:
  store ptr %l15, ptr %l22, !tbaa !29
  store i64 0, ptr %l23, !tbaa !24
  br label %bb58
bb58:
  %t320 = load i64, ptr %l23, !tbaa !24
  store i64 %t320, ptr %l172, !tbaa !24
  %t321 = load ptr, ptr %l22, !tbaa !29
  %t323 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t321)
  store i64 %t323, ptr %l174
  br label %bb59
bb59:
  %t324 = load i64, ptr %l172, !tbaa !24
  %t325 = load i64, ptr %l174, !tbaa !24
  %t326 = icmp slt i64 %t324, %t325
  %t328 = xor i1 %t326, true
  br i1 %t328, label %bb60, label %bb61
bb60:
  br label %bb66
bb61:
  br label %bb62
bb62:
  %t330 = load ptr, ptr %l22, !tbaa !29
  %t331 = load i64, ptr %l23, !tbaa !24
  %t334 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t330, i64 %t331)
  store i32 %t334, ptr %l179
  br label %bb63
bb63:
  %t335 = load i32, ptr %l179, !tbaa !23
  %t336 = load ptr, ptr %l5, !tbaa !29
  %t338 = getelementptr %"compiler/check:frame", ptr %t336, i32 0, i32 26
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t338, i32 %t335)
  br label %bb64
bb64:
  br label %bb65
bb65:
  %t342 = load i64, ptr %l23, !tbaa !24
  %t344 = add i64 %t342, 1
  store i64 %t344, ptr %l23, !tbaa !24
  br label %bb58
bb66:
  %t346 = load ptr, ptr %l8, !tbaa !29
  %t348 = icmp eq ptr %t346, null
  br i1 %t348, label %bb67, label %bb68
bb67:
  call void @__olang_check_failed(ptr @olang_loc_77a5603a1298311f_4bb819fe8c7bb9e3)
  unreachable
bb68:
  br label %bb69
bb69:
  %t350 = load ptr, ptr %l8, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t350, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emsgOwner(ptr %v0, ptr %v1, ptr %a0, i1 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  br i1 %a1, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d12, i32 0, i32 1) }, ptr %l3, !tbaa !27
  br label %bb3
bb2:
  store { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d13, i32 0, i32 1) }, ptr %l3, !tbaa !27
  br label %bb3
bb3:
  %t3 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t3, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoteAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, %"compiler/msgs:Msg" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l15 = alloca ptr
  %l19 = alloca i64
  %l25 = alloca ptr
  %l36 = alloca { i64, ptr }
  %l41 = alloca i64
  %l53 = alloca i64
  %l54 = alloca { i64, ptr }
  %l55 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i32
  %l69 = alloca i64
  %l79 = alloca ptr
  %l80 = alloca i64
  %l86 = alloca ptr
  %t188 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l2, !tbaa !24
  %t8 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t4, i64 %t5)
  store ptr %t8, ptr %l15
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l15, !tbaa !29
  store ptr %t9, ptr %l4, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t14 = load i64, ptr %l2, !tbaa !24
  %t17 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t13, i64 %t14)
  store i64 %t17, ptr %l19
  br label %bb2
bb2:
  %t18 = load i64, ptr %l19, !tbaa !24
  store i64 %t18, ptr %l5, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr %"compiler/generic:Program", ptr %t22, i32 0, i32 0
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/load:Loader", ptr %t25, i32 0, i32 5
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t27, i64 %t28)
  store ptr %t31, ptr %l25
  br label %bb3
bb3:
  %t32 = load ptr, ptr %l25, !tbaa !29
  %t34 = getelementptr %"compiler/load:Module", ptr %t32, i32 0, i32 6
  %t35 = load ptr, ptr %t34, !tbaa !29
  store ptr %t35, ptr %l6, !tbaa !29
  %t37 = load ptr, ptr %l6, !tbaa !29
  %t39 = icmp eq ptr %t37, null
  br i1 %t39, label %bb4, label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_f66b04275832bdf5_49261566e6ebbc09)
  unreachable
bb5:
  br label %bb6
bb6:
  %t41 = load ptr, ptr %l6, !tbaa !29
  %t44 = getelementptr %"compiler/source:Source", ptr %t41, i32 0, i32 1
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !27
  store { i64, ptr } %t45, ptr %l7, !tbaa !27
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load ptr, ptr %l4, !tbaa !29
  %t50 = getelementptr %"compiler/ast:Func", ptr %t48, i32 0, i32 2
  %t51 = load i32, ptr %t50, !tbaa !23
  %t54 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t47, i32 %t51)
  store { i64, ptr } %t54, ptr %l36
  br label %bb7
bb7:
  %t55 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t55, ptr %l8, !tbaa !27
  %t56 = load ptr, ptr %l4, !tbaa !29
  %t58 = getelementptr %"compiler/ast:Func", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = icmp eq ptr %t59, null
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb8, label %bb9
bb8:
  %t65 = load ptr, ptr %l4, !tbaa !29
  %t67 = getelementptr %"compiler/ast:Func", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t70 = icmp eq ptr %t68, null
  br i1 %t70, label %bb10, label %bb11
bb9:
  %t72 = load ptr, ptr %l4, !tbaa !29
  %t74 = getelementptr %"compiler/ast:Func", ptr %t72, i32 0, i32 0
  %t75 = getelementptr %"compiler/source:Span", ptr %t74, i32 0, i32 0
  %t76 = load i32, ptr %t75, !tbaa !23
  %t78 = sext i32 %t76 to i64
  store i64 %t78, ptr %l41, !tbaa !24
  br label %bb13
bb10:
  call void @__olang_check_failed(ptr @olang_loc_959932aa8b846e4e_2c1999e37dfb1a2)
  unreachable
bb11:
  br label %bb12
bb12:
  %t80 = load ptr, ptr %l4, !tbaa !29
  %t82 = getelementptr %"compiler/ast:Func", ptr %t80, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t86 = getelementptr %"compiler/ast:Param", ptr %t83, i32 0, i32 0
  %t87 = getelementptr %"compiler/source:Span", ptr %t86, i32 0, i32 1
  %t88 = load i32, ptr %t87, !tbaa !23
  %t90 = sext i32 %t88 to i64
  store i64 %t90, ptr %l41, !tbaa !24
  br label %bb13
bb13:
  %t92 = load i64, ptr %l41, !tbaa !24
  store i64 %t92, ptr %l9, !tbaa !24
  %t93 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t93, ptr %l54, !tbaa !27
  %t94 = load i64, ptr %l9, !tbaa !24
  store i64 %t94, ptr %l55, !tbaa !24
  %t95 = load ptr, ptr %l4, !tbaa !29
  %t97 = getelementptr %"compiler/ast:Func", ptr %t95, i32 0, i32 0
  %t98 = getelementptr %"compiler/source:Span", ptr %t97, i32 0, i32 1
  %t99 = load i32, ptr %t98, !tbaa !23
  %t101 = sext i32 %t99 to i64
  store i64 %t101, ptr %l58, !tbaa !24
  %t102 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t102, 0
  store i64 %t103, ptr %l59, !tbaa !24
  %t104 = load i64, ptr %l55, !tbaa !24
  %t105 = icmp sge i64 %t104, 0
  br i1 %t105, label %bb14, label %bb15
bb14:
  %t107 = load i64, ptr %l55, !tbaa !24
  %t108 = load i64, ptr %l58, !tbaa !24
  %t109 = icmp sle i64 %t107, %t108
  br i1 %t109, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_f94ac378888081c5_5f597351c4418bf9)
  unreachable
bb16:
  %t111 = load i64, ptr %l58, !tbaa !24
  %t112 = load i64, ptr %l59, !tbaa !24
  %t113 = icmp sle i64 %t111, %t112
  br i1 %t113, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_f94ac378888081c5_5f597351c4418bf9)
  unreachable
bb18:
  %t115 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = load i64, ptr %l55, !tbaa !24
  %t118 = load i64, ptr %l58, !tbaa !24
  %t119 = getelementptr i8, ptr %t116, i64 %t117
  %t120 = sub i64 %t118, %t117
  %t121 = insertvalue { i64, ptr } undef, i64 %t120, 0
  %t122 = insertvalue { i64, ptr } %t121, ptr %t119, 1
  %t123 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t126 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v0, { i64, ptr } %t122, { i64, ptr } %t123)
  %t127 = extractvalue { i32, i64 } %t126, 1
  %t128 = extractvalue { i32, i64 } %t126, 0
  store i32 %t128, ptr %l66
  %t129 = icmp ne i32 %t128, 0
  br i1 %t129, label %bb21, label %ok.130, !prof !99
ok.130:
  store i64 %t127, ptr %l65
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_f94ac378888081c5_5f597351c4418bf9)
  unreachable
bb20:
  %t131 = load i64, ptr %l65, !tbaa !24
  store i64 %t131, ptr %l53, !tbaa !24
  br label %bb23
bb21:
  br label %bb22
bb22:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l53, !tbaa !24
  br label %bb23
bb23:
  %t132 = load i64, ptr %l53, !tbaa !24
  store i64 %t132, ptr %l10, !tbaa !24
  %t133 = load i64, ptr %l10, !tbaa !24
  %t135 = icmp slt i64 %t133, 0
  br i1 %t135, label %bb24, label %bb25
bb24:
  %t137 = load ptr, ptr %l4, !tbaa !29
  %t139 = getelementptr %"compiler/ast:Func", ptr %t137, i32 0, i32 0
  %t140 = getelementptr %"compiler/source:Span", ptr %t139, i32 0, i32 0
  %t141 = load i32, ptr %t140, !tbaa !23
  %t143 = sext i32 %t141 to i64
  store i64 %t143, ptr %l69, !tbaa !24
  br label %bb26
bb25:
  %t145 = load i64, ptr %l9, !tbaa !24
  %t146 = load i64, ptr %l10, !tbaa !24
  %t149 = add i64 %t145, %t146
  store i64 %t149, ptr %l69, !tbaa !24
  br label %bb26
bb26:
  %t151 = load i64, ptr %l69, !tbaa !24
  store i64 %t151, ptr %l11, !tbaa !24
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/check:Checker", ptr %t152, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !29
  %t157 = getelementptr %"compiler/generic:Program", ptr %t155, i32 0, i32 0
  %t158 = load ptr, ptr %t157, !tbaa !29
  %t160 = getelementptr %"compiler/load:Loader", ptr %t158, i32 0, i32 4
  %t161 = load ptr, ptr %t160, !tbaa !29
  store ptr %t161, ptr %l79, !tbaa !29
  store i64 %a1, ptr %l80, !tbaa !24
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t165 = getelementptr %"compiler/check:Checker", ptr %t163, i32 0, i32 1
  %t166 = load ptr, ptr %t165, !tbaa !29
  %t168 = getelementptr %"compiler/generic:Program", ptr %t166, i32 0, i32 0
  %t169 = load ptr, ptr %t168, !tbaa !29
  %t171 = getelementptr %"compiler/load:Loader", ptr %t169, i32 0, i32 5
  %t172 = load i64, ptr %l5, !tbaa !24
  %t175 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t171, i64 %t172)
  store ptr %t175, ptr %l86
  br label %bb27
bb27:
  %t176 = load ptr, ptr %l86, !tbaa !29
  %t178 = getelementptr %"compiler/load:Module", ptr %t176, i32 0, i32 4
  %t179 = load i64, ptr %t178, !tbaa !24
  %t180 = load i64, ptr %l11, !tbaa !24
  %t181 = load i64, ptr %l11, !tbaa !24
  %t182 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t184 = extractvalue { i64, ptr } %t182, 0
  %t187 = add i64 %t181, %t184
  store { i64, [3 x i64] } zeroinitializer, ptr %t188
  %t189 = getelementptr { i64, [3 x i64] }, ptr %t188, i32 0, i32 0
  store i64 3, ptr %t189
  %t191 = insertvalue { i64, i64, i64 } undef, i64 %t179, 0
  %t193 = insertvalue { i64, i64, i64 } %t191, i64 %t180, 1
  %t195 = insertvalue { i64, i64, i64 } %t193, i64 %t187, 2
  %t196 = getelementptr { i64, [3 x i64] }, ptr %t188, i32 0, i32 1
  store { i64, i64, i64 } %t195, ptr %t196
  %t197 = load { i64, [3 x i64] }, ptr %t188
  %t199 = load ptr, ptr %l79, !tbaa !29
  %t200 = load i64, ptr %l80, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %v1, ptr %t199, i64 %t200, { i64, [3 x i64] } %t197, %"compiler/msgs:Msg" %a3)
  br label %bb28
bb28:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoteRo(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca %"compiler/typed:Local"
  %l5 = alloca i32
  %l6 = alloca { i64, [3 x i64] }
  %l9 = alloca i64
  %l13 = alloca ptr
  %l17 = alloca %"compiler/typed:Local"
  %l20 = alloca i32
  %l22 = alloca ptr
  %l25 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l26 = alloca i32
  %l27 = alloca i32
  %l30 = alloca { i64, [3 x i64] }
  %l33 = alloca i1
  %l35 = alloca ptr
  %l38 = alloca i32
  %l43 = alloca i32
  %l44 = alloca i64
  %l49 = alloca ptr
  %l50 = alloca i64
  %l51 = alloca { i64, [3 x i64] }
  %l54 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l64 = alloca %"compiler/msgs:Msg"
  %l68 = alloca ptr
  %l69 = alloca i64
  %l70 = alloca { i64, [3 x i64] }
  %l73 = alloca { i64, ptr }
  %l74 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRoot(ptr %v0, ptr %v1, ptr %t1, ptr %a2)
  store i64 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i64, ptr %l9, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp slt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t11)
  store ptr %t13, ptr %l13
  br label %bb5
bb5:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t16 = trunc i64 %t14 to i32
  %t18 = load ptr, ptr %l13, !tbaa !29
  %t20 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t18, i32 %t16)
  store %"compiler/typed:Local" %t20, ptr %l17
  br label %bb6
bb6:
  %t21 = load %"compiler/typed:Local", ptr %l17
  store %"compiler/typed:Local" %t21, ptr %l4
  %t22 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 0
  %t23 = load i32, ptr %t22, !tbaa !23
  %t25 = icmp eq i32 %t23, 0
  br i1 %t25, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb8:
  br label %bb9
bb9:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/check:Checker", ptr %t27, i32 0, i32 61
  store ptr %t29, ptr %l22, !tbaa !29
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load i64, ptr %l3, !tbaa !24
  %t34 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKey(ptr %v0, ptr %t30, i64 %t31)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t34, ptr %l25
  br label %bb10
bb10:
  %t35 = load ptr, ptr %l22, !tbaa !29
  %t36 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l25
  %t37 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hc59daade663458096c0c7696954afd54(ptr %v0, ptr %t35, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t36)
  %t38 = extractvalue { i32, i32 } %t37, 1
  %t39 = extractvalue { i32, i32 } %t37, 0
  store i32 %t39, ptr %l27
  %t40 = icmp ne i32 %t39, 0
  br i1 %t40, label %bb12, label %ok.41, !prof !99
ok.41:
  store i32 %t38, ptr %l26
  br label %bb11
bb11:
  %t42 = load i32, ptr %l26, !tbaa !23
  store i32 %t42, ptr %l20, !tbaa !23
  br label %bb14
bb12:
  br label %bb13
bb13:
  call void @__olang_ert_req_clear()
  store i32 0, ptr %l20, !tbaa !23
  br label %bb14
bb14:
  %t43 = load i32, ptr %l20, !tbaa !23
  store i32 %t43, ptr %l5, !tbaa !23
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 1
  %t46 = load %"compiler/source:Span", ptr %t45
  %t49 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t44, %"compiler/source:Span" %t46)
  store { i64, [3 x i64] } %t49, ptr %l30
  br label %bb15
bb15:
  %t50 = load { i64, [3 x i64] }, ptr %l30
  store { i64, [3 x i64] } %t50, ptr %l6
  %t51 = load i32, ptr %l5, !tbaa !23
  %t53 = icmp ne i32 %t51, 0
  br i1 %t53, label %bb16, label %bb17
bb16:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/check:Checker", ptr %t55, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !29
  store ptr %t58, ptr %l35, !tbaa !29
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 2
  %t61 = load i32, ptr %t60, !tbaa !23
  %t64 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t59, i32 %t61)
  store i32 %t64, ptr %l38
  br label %bb18
bb17:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb21
bb18:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/check:Checker", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t70 = getelementptr %"compiler/generic:Program", ptr %t68, i32 0, i32 0
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = getelementptr %"compiler/load:Loader", ptr %t71, i32 0, i32 3
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t76 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s0, ptr %t74, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d14, i32 0, i32 1) })
  store i32 %t76, ptr %l43
  br label %bb19
bb19:
  %t77 = load ptr, ptr %l35, !tbaa !29
  %t78 = load i32, ptr %l38, !tbaa !23
  %t79 = load i32, ptr %l43, !tbaa !23
  %t80 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t77, i32 %t78, i32 %t79)
  store i64 %t80, ptr %l44
  br label %bb20
bb20:
  %t81 = load i64, ptr %l44, !tbaa !24
  %t82 = icmp sge i64 %t81, 0
  store i1 %t82, ptr %l33, !tbaa !21
  br label %bb21
bb21:
  %t84 = load i1, ptr %l33, !tbaa !21
  br i1 %t84, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s3
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/check:Checker", ptr %t85, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t90 = getelementptr %"compiler/generic:Program", ptr %t88, i32 0, i32 0
  %t91 = load ptr, ptr %t90, !tbaa !29
  %t93 = getelementptr %"compiler/load:Loader", ptr %t91, i32 0, i32 4
  %t94 = load ptr, ptr %t93, !tbaa !29
  store ptr %t94, ptr %l49, !tbaa !29
  %t95 = load i64, ptr %l1, !tbaa !24
  store i64 %t95, ptr %l50, !tbaa !24
  %t96 = load { i64, [3 x i64] }, ptr %l6
  store { i64, [3 x i64] } %t96, ptr %l51
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 0
  %t99 = load i32, ptr %t98, !tbaa !23
  %t102 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t97, i32 %t99)
  store { i64, ptr } %t102, ptr %l54
  br label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s4
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/check:Checker", ptr %t103, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t108 = getelementptr %"compiler/generic:Program", ptr %t106, i32 0, i32 0
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t111 = getelementptr %"compiler/load:Loader", ptr %t109, i32 0, i32 4
  %t112 = load ptr, ptr %t111, !tbaa !29
  store ptr %t112, ptr %l68, !tbaa !29
  %t113 = load i64, ptr %l1, !tbaa !24
  store i64 %t113, ptr %l69, !tbaa !24
  %t114 = load { i64, [3 x i64] }, ptr %l6
  store { i64, [3 x i64] } %t114, ptr %l70
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 0
  %t117 = load i32, ptr %t116, !tbaa !23
  %t120 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t115, i32 %t117)
  store { i64, ptr } %t120, ptr %l73
  br label %bb30
bb24:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load i32, ptr %l5, !tbaa !23
  %t125 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t121, i32 %t122)
  store { i64, ptr } %t125, ptr %l57
  br label %bb25
bb25:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 0
  %t128 = load i32, ptr %t127, !tbaa !23
  %t131 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t126, i32 %t128)
  store { i64, ptr } %t131, ptr %l60
  br label %bb26
bb26:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load i32, ptr %l5, !tbaa !23
  %t136 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t132, i32 %t133)
  store { i64, ptr } %t136, ptr %l63
  br label %bb27
bb27:
  %t137 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t138 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t139 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t140 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t141 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteReadOnlyCopyOf(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %s3, { i64, ptr } %t137, { i64, ptr } %t138, { i64, ptr } %t139, { i64, ptr } %t140)
  store %"compiler/msgs:Msg" %t141, ptr %l64
  br label %bb28
bb28:
  %t142 = load ptr, ptr %l49, !tbaa !29
  %t143 = load i64, ptr %l50, !tbaa !24
  %t144 = load { i64, [3 x i64] }, ptr %l51
  %t145 = load %"compiler/msgs:Msg", ptr %l64
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s3, ptr %t142, i64 %t143, { i64, [3 x i64] } %t144, %"compiler/msgs:Msg" %t145)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s3)
  br label %bb33
bb30:
  %t146 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t147 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteReadOnlyCopy(ptr %v0, ptr %s4, { i64, ptr } %t146)
  store %"compiler/msgs:Msg" %t147, ptr %l74
  br label %bb31
bb31:
  %t148 = load ptr, ptr %l68, !tbaa !29
  %t149 = load i64, ptr %l69, !tbaa !24
  %t150 = load { i64, [3 x i64] }, ptr %l70
  %t151 = load %"compiler/msgs:Msg", ptr %l74
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s4, ptr %t148, i64 %t149, { i64, [3 x i64] } %t150, %"compiler/msgs:Msg" %t151)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s4)
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullRead(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l5 = alloca i32
  %l10 = alloca i1
  %l13 = alloca %"compiler/source:Span"
  %l14 = alloca ptr
  %l15 = alloca %"compiler/source:Span"
  %l18 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l28 = alloca %"compiler/msgs:Msg"
  %l29 = alloca i64
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t1)
  store i32 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i32, ptr %l5, !tbaa !23
  store i32 %t4, ptr %l2, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = getelementptr %"compiler/generic:Program", ptr %t8, i32 0, i32 2
  %t11 = load i32, ptr %l2, !tbaa !23
  %t14 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t10, i32 %t11)
  store i1 %t14, ptr %l10
  br label %bb2
bb2:
  %t15 = load i1, ptr %l10, !tbaa !21
  %t16 = xor i1 %t15, true
  br i1 %t16, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb4:
  br label %bb5
bb5:
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v1, ptr %t18)
  store %"compiler/source:Span" %t20, ptr %l13
  br label %bb6
bb6:
  %t21 = load %"compiler/source:Span", ptr %l13
  store %"compiler/source:Span" %t21, ptr %l3
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l14, !tbaa !29
  %t23 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t23, ptr %l15
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load %"compiler/source:Span", ptr %l3
  %t28 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t24, %"compiler/source:Span" %t25)
  store { i64, ptr } %t28, ptr %l18
  br label %bb7
bb7:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load i32, ptr %l2, !tbaa !23
  %t33 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t29, i32 %t30)
  store { i64, ptr } %t33, ptr %l21
  br label %bb8
bb8:
  %t34 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t34, 0
  %t36 = extractvalue { i64, ptr } %t34, 1
  %t37 = mul i64 %t35, 1
  %t38 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t37)
  call void @llvm.memcpy.p0.p0.i64(ptr %t38, ptr %t36, i64 %t37, i1 false)
  %t39 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  store { i64, ptr } %t40, ptr %l22, !tbaa !27
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load %"compiler/source:Span", ptr %l3
  %t45 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t41, %"compiler/source:Span" %t42)
  store { i64, ptr } %t45, ptr %l25
  br label %bb9
bb9:
  %t46 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t47 = call { i64, ptr } @compiler_2fcheck_2ebangOf(ptr %v0, ptr %s0, { i64, ptr } %t46)
  store { i64, ptr } %t47, ptr %l26
  br label %bb10
bb10:
  %t48 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t48, 0
  %t50 = extractvalue { i64, ptr } %t48, 1
  %t51 = mul i64 %t49, 1
  %t52 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t51)
  call void @llvm.memcpy.p0.p0.i64(ptr %t52, ptr %t50, i64 %t51, i1 false)
  %t53 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t52, 1
  %t55 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t56 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t58 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadMaybeNull(ptr %v0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t55, { i64, ptr } %t56, { i64, ptr } %t54)
  store %"compiler/msgs:Msg" %t58, ptr %l28
  br label %bb11
bb11:
  %t59 = load ptr, ptr %l14, !tbaa !29
  %t60 = load %"compiler/source:Span", ptr %l15
  %t61 = load %"compiler/msgs:Msg", ptr %l28
  %t62 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s0, ptr %t59, %"compiler/source:Span" %t60, %"compiler/msgs:Msg" %t61)
  store i64 %t62, ptr %l29
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamIndex(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/typed:Local"
  %l3 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca ptr
  %l15 = alloca %"compiler/typed:Local"
  %l19 = alloca i1
  %l22 = alloca i1
  %l23 = alloca i1
  %l26 = alloca i1
  %l30 = alloca ptr
  %l34 = alloca i64
  %l38 = alloca i64
  %l41 = alloca i64
  %l61 = alloca i32
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l11
  br label %bb1
bb1:
  %t4 = load i64, ptr %l1, !tbaa !24
  %t6 = trunc i64 %t4 to i32
  %t8 = load ptr, ptr %l11, !tbaa !29
  %t10 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t8, i32 %t6)
  store %"compiler/typed:Local" %t10, ptr %l15
  br label %bb2
bb2:
  %t11 = load %"compiler/typed:Local", ptr %l15
  store %"compiler/typed:Local" %t11, ptr %l2
  %t12 = getelementptr %"compiler/typed:Local", ptr %l2, i32 0, i32 4
  %t13 = load i32, ptr %t12, !range !{i32 0, i32 7}
  %t15 = trunc i64 0 to i32
  %t16 = icmp eq i32 %t13, %t15
  %t18 = xor i1 %t16, true
  br i1 %t18, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb6
bb4:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/typed:Local", ptr %l2, i32 0, i32 2
  %t22 = load i32, ptr %t21, !tbaa !23
  %t25 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t20, i32 %t22)
  store i1 %t25, ptr %l22
  br label %bb5
bb5:
  %t26 = load i1, ptr %l22, !tbaa !21
  store i1 %t26, ptr %l19, !tbaa !21
  br label %bb6
bb6:
  %t27 = load i1, ptr %l19, !tbaa !21
  br i1 %t27, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb10
bb8:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/typed:Local", ptr %l2, i32 0, i32 2
  %t30 = load i32, ptr %t29, !tbaa !23
  %t33 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritable(ptr %v0, ptr %t28, i32 %t30)
  store i1 %t33, ptr %l26
  br label %bb9
bb9:
  %t34 = load i1, ptr %l26, !tbaa !21
  %t35 = xor i1 %t34, true
  store i1 %t35, ptr %l23, !tbaa !21
  br label %bb10
bb10:
  %t37 = load i1, ptr %l23, !tbaa !21
  br i1 %t37, label %bb11, label %bb12
bb11:
  store i64 -1, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t39)
  store ptr %t41, ptr %l30
  br label %bb14
bb14:
  %t42 = load ptr, ptr %l30, !tbaa !29
  %t44 = getelementptr %"compiler/typed:Body", ptr %t42, i32 0, i32 5
  %t45 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t44
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t45, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  %t48 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %l3)
  store i64 %t48, ptr %l34
  br label %bb15
bb15:
  %t49 = load i64, ptr %l34, !tbaa !24
  store i64 %t49, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t50 = load i64, ptr %l5, !tbaa !24
  %t51 = load i64, ptr %l4, !tbaa !24
  %t54 = icmp sgt i64 %t50, %t51
  br i1 %t54, label %bb16, label %bb17
bb16:
  %t56 = load i64, ptr %l6, !tbaa !24
  %t58 = icmp sgt i64 %t56, 0
  br i1 %t58, label %bb18, label %bb19
bb17:
  store i64 0, ptr %l38, !tbaa !24
  br label %bb21
bb18:
  %t60 = load i64, ptr %l5, !tbaa !24
  %t61 = load i64, ptr %l4, !tbaa !24
  %t64 = sub i64 %t60, %t61
  %t65 = load i64, ptr %l6, !tbaa !24
  %t68 = add i64 %t64, %t65
  %t70 = sub i64 %t68, 1
  %t71 = load i64, ptr %l6, !tbaa !24
  %t74 = sdiv i64 %t70, %t71
  store i64 %t74, ptr %l41, !tbaa !24
  br label %bb20
bb19:
  store i64 0, ptr %l41, !tbaa !24
  br label %bb20
bb20:
  %t76 = load i64, ptr %l41, !tbaa !24
  store i64 %t76, ptr %l38, !tbaa !24
  br label %bb21
bb21:
  %t77 = load i64, ptr %l38, !tbaa !24
  store i64 %t77, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb22
bb22:
  %t78 = load i64, ptr %l8, !tbaa !24
  %t79 = load i64, ptr %l7, !tbaa !24
  %t82 = icmp slt i64 %t78, %t79
  %t84 = xor i1 %t82, true
  br i1 %t84, label %bb23, label %bb24
bb23:
  br label %bb31
bb24:
  br label %bb25
bb25:
  %t86 = load i64, ptr %l4, !tbaa !24
  %t87 = load i64, ptr %l8, !tbaa !24
  %t88 = load i64, ptr %l6, !tbaa !24
  %t91 = mul i64 %t87, %t88
  %t94 = add i64 %t86, %t91
  store i64 %t94, ptr %l9, !tbaa !24
  %t96 = load i64, ptr %l9, !tbaa !24
  %t99 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %l3, i64 %t96)
  store i32 %t99, ptr %l61
  br label %bb26
bb26:
  %t100 = load i32, ptr %l61, !tbaa !23
  %t101 = sext i32 %t100 to i64
  %t102 = load i64, ptr %l1, !tbaa !24
  %t105 = icmp eq i64 %t101, %t102
  br i1 %t105, label %bb27, label %bb28
bb27:
  %t107 = load i64, ptr %l9, !tbaa !24
  store i64 %t107, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  br label %bb30
bb30:
  %t109 = load i64, ptr %l8, !tbaa !24
  %t111 = add i64 %t109, 1
  store i64 %t111, ptr %l8, !tbaa !24
  br label %bb22
bb31:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eputTarget(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca i32
  %l9 = alloca ptr
  %l11 = alloca %"compiler/source:Span"
  %l13 = alloca ptr
  %l14 = alloca i1
  %l23 = alloca { i64, ptr }
  %l24 = alloca i1
  %l26 = alloca ptr
  %l30 = alloca i1
  %l31 = alloca i1
  %l34 = alloca i32
  %l39 = alloca i32
  %l42 = alloca ptr
  %l45 = alloca i32
  %l46 = alloca i32
  %l49 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca i32
  %l56 = alloca i32
  %l57 = alloca i1
  %l63 = alloca ptr
  %l70 = alloca i64
  %l79 = alloca ptr
  %l80 = alloca %"compiler/source:Span"
  %l81 = alloca %"compiler/msgs:Msg"
  %l82 = alloca i64
  %l85 = alloca ptr
  %l88 = alloca ptr
  %l89 = alloca %"compiler/source:Span"
  %l90 = alloca ptr
  %l91 = alloca ptr
  %l92 = alloca ptr
  %l94 = alloca i32
  %l96 = alloca ptr
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %t116 = alloca { i64, [2 x i64] }, align 8
  %t134 = alloca { i64, [3 x i64] }, align 8
  %t179 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t1)
  store %"compiler/source:Span" %t3, ptr %l11
  br label %bb1
bb1:
  %t4 = load %"compiler/source:Span", ptr %l11
  store %"compiler/source:Span" %t4, ptr %l5
  br i1 %a2, label %bb2, label %bb3
bb2:
  %t7 = load ptr, ptr %l1, !tbaa !29
  store ptr %t7, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t8 = load ptr, ptr %l13, !tbaa !29
  %t9 = icmp ne ptr %t8, null
  br i1 %t9, label %bb4, label %bb5
bb3:
  br label %bb45
bb4:
  %t11 = load ptr, ptr %l13, !tbaa !29
  %t12 = load i64, ptr %t11, !range !{i64 0, i64 29}
  %t14 = icmp eq i64 %t12, 0
  store i1 %t14, ptr %l14, !tbaa !21
  br label %bb5
bb5:
  %t15 = load i1, ptr %l14, !tbaa !21
  br i1 %t15, label %bb6, label %bb7
bb6:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32 }, ptr %t18, i32 0, i32 0
  %t20 = load %"compiler/source:Span", ptr %t19
  store %"compiler/source:Span" %t20, ptr %l6
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [5 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", i32 }, ptr %t24, i32 0, i32 1
  %t26 = load i32, ptr %t25
  store i32 %t26, ptr %l7, !tbaa !23
  br label %bb8
bb7:
  br label %bb37
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l7, !tbaa !23
  %t32 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t28, i32 %t29)
  store { i64, ptr } %t32, ptr %l23
  br label %bb9
bb9:
  %t33 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t34 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t33, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) })
  store i1 %t34, ptr %l24
  br label %bb10
bb10:
  %t35 = load i1, ptr %l24, !tbaa !21
  br i1 %t35, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb12:
  br label %bb13
bb13:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t36)
  store ptr %t38, ptr %l26
  br label %bb14
bb14:
  %t39 = load ptr, ptr %l26, !tbaa !29
  %t41 = getelementptr %"compiler/check:frame", ptr %t39, i32 0, i32 41
  %t42 = load i32, ptr %l7, !tbaa !23
  %t45 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %t41, i32 %t42)
  store i1 %t45, ptr %l30
  br label %bb15
bb15:
  %t46 = load i1, ptr %l30, !tbaa !21
  br i1 %t46, label %bb16, label %bb17
bb16:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load i32, ptr %l4, !tbaa !23
  %t51 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunLength(ptr %v0, ptr %t47, i32 %t48)
  store i32 %t51, ptr %l34
  br label %bb18
bb17:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb19
bb18:
  %t52 = load i32, ptr %l4, !tbaa !23
  %t53 = load i32, ptr %l34, !tbaa !23
  %t55 = icmp ne i32 %t53, %t52
  store i1 %t55, ptr %l31, !tbaa !21
  br label %bb19
bb19:
  %t57 = load i1, ptr %l31, !tbaa !21
  br i1 %t57, label %bb20, label %bb21
bb20:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i32, ptr %l4, !tbaa !23
  %t62 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunLength(ptr %v0, ptr %t58, i32 %t59)
  store i32 %t62, ptr %l39
  br label %bb22
bb21:
  br label %bb23
bb22:
  %t63 = load i32, ptr %l39, !tbaa !23
  store i32 %t63, ptr %l4, !tbaa !23
  br label %bb23
bb23:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/check:Checker", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = getelementptr %"compiler/generic:Program", ptr %t67, i32 0, i32 2
  store ptr %t69, ptr %l42, !tbaa !29
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load i32, ptr %l4, !tbaa !23
  %t74 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t70, i32 %t71)
  store i32 %t74, ptr %l45
  br label %bb24
bb24:
  %t75 = load ptr, ptr %l42, !tbaa !29
  %t76 = load i32, ptr %l45, !tbaa !23
  %t77 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t75, i32 %t76)
  store i32 %t77, ptr %l46
  br label %bb25
bb25:
  %t78 = load i32, ptr %l46, !range !{i32 0, i32 33}
  %t80 = trunc i64 19 to i32
  %t81 = icmp eq i32 %t78, %t80
  br i1 %t81, label %bb26, label %bb27
bb26:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/check:Checker", ptr %t83, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = getelementptr %"compiler/generic:Program", ptr %t86, i32 0, i32 2
  store ptr %t88, ptr %l52, !tbaa !29
  %t89 = load i32, ptr %l4, !tbaa !23
  store i32 %t89, ptr %l53, !tbaa !23
  %t90 = load ptr, ptr %l3, !tbaa !29
  %t93 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t90)
  store i32 %t93, ptr %l56
  br label %bb28
bb27:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb30
bb28:
  %t94 = load ptr, ptr %l52, !tbaa !29
  %t95 = load i32, ptr %l53, !tbaa !23
  %t96 = load i32, ptr %l56, !tbaa !23
  %t97 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t94, i32 %t95, i32 %t96)
  store i1 %t97, ptr %l57
  br label %bb29
bb29:
  %t98 = load i1, ptr %l57, !tbaa !21
  %t99 = xor i1 %t98, true
  store i1 %t99, ptr %l49, !tbaa !21
  br label %bb30
bb30:
  %t101 = load i1, ptr %l49, !tbaa !21
  br i1 %t101, label %bb31, label %bb32
bb31:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load ptr, ptr %l3, !tbaa !29
  %t104 = load i32, ptr %l4, !tbaa !23
  %t105 = load %"compiler/source:Span", ptr %l6
  %t110 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t102, ptr %t103, i32 %t104, %"compiler/source:Span" %t105)
  store ptr %t110, ptr %l63
  br label %bb33
bb32:
  br label %bb34
bb33:
  %t111 = load ptr, ptr %l63, !tbaa !29
  store ptr %t111, ptr %l3, !tbaa !29
  br label %bb34
bb34:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load i32, ptr %l7, !tbaa !23
  %t114 = load %"compiler/source:Span", ptr %l6
  %t115 = load i32, ptr %l4, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t116
  %t117 = getelementptr { i64, [2 x i64] }, ptr %t116, i32 0, i32 0
  store i64 5, ptr %t117
  %t118 = load { i64, [2 x i64] }, ptr %t116
  %t125 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t112, i32 %t113, %"compiler/source:Span" %t114, i32 %t115, i32 1, { i64, [2 x i64] } %t118)
  store i64 %t125, ptr %l70
  br label %bb35
bb35:
  %t126 = load i64, ptr %l70, !tbaa !24
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load %"compiler/source:Span", ptr %l6
  %t131 = trunc i64 %t126 to i32
  %t133 = load ptr, ptr %l3, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t134
  %t135 = getelementptr { i64, [3 x i64] }, ptr %t134, i32 0, i32 0
  store i64 0, ptr %t135
  %t137 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t128, 0
  %t139 = insertvalue { %"compiler/source:Span", i32, ptr } %t137, i32 %t131, 1
  %t141 = insertvalue { %"compiler/source:Span", i32, ptr } %t139, ptr %t133, 2
  %t142 = getelementptr { i64, [3 x i64] }, ptr %t134, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t141, ptr %t142
  %t143 = load { i64, [3 x i64] }, ptr %t134
  %t145 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t143, ptr %t145
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t127, ptr %t145)
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s2)
  br label %bb44
bb37:
  br i1 true, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb43
bb40:
  store %olang.scope zeroinitializer, ptr %s6
  %t148 = load ptr, ptr %l0, !tbaa !29
  store ptr %t148, ptr %l79, !tbaa !29
  %t149 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t149, ptr %l80
  %t150 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestructNotName(ptr %s6)
  store %"compiler/msgs:Msg" %t150, ptr %l81
  br label %bb41
bb41:
  %t151 = load ptr, ptr %l79, !tbaa !29
  %t152 = load %"compiler/source:Span", ptr %l80
  %t153 = load %"compiler/msgs:Msg", ptr %l81
  %t154 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s6, ptr %t151, %"compiler/source:Span" %t152, %"compiler/msgs:Msg" %t153)
  store i64 %t154, ptr %l82
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s6)
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_fb06dcd16342dc9_94e70e479081575d)
  unreachable
bb44:
  br label %ret
bb45:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load ptr, ptr %l1, !tbaa !29
  %t159 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ediscardOr(ptr %v0, ptr %v1, ptr %t155, ptr %t156)
  store ptr %t159, ptr %l85
  br label %bb46
bb46:
  %t160 = load ptr, ptr %l85, !tbaa !29
  store ptr %t160, ptr %l9, !tbaa !29
  %t161 = load ptr, ptr %l9, !tbaa !29
  %t163 = icmp eq ptr %t161, null
  br i1 %t163, label %bb47, label %bb48
bb47:
  br label %ret
bb48:
  br label %bb49
bb49:
  %t165 = load ptr, ptr %l0, !tbaa !29
  store ptr %t165, ptr %l88, !tbaa !29
  %t166 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t166, ptr %l89
  %t167 = load ptr, ptr %l9, !tbaa !29
  store ptr %t167, ptr %l90, !tbaa !29
  %t168 = load ptr, ptr %l0, !tbaa !29
  store ptr %t168, ptr %l91, !tbaa !29
  %t169 = load ptr, ptr %l3, !tbaa !29
  store ptr %t169, ptr %l92, !tbaa !29
  %t170 = load ptr, ptr %l9, !tbaa !29
  %t172 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %t170)
  store i32 %t172, ptr %l94
  br label %bb50
bb50:
  %t173 = load %"compiler/source:Span", ptr %l5
  %t174 = load ptr, ptr %l91, !tbaa !29
  %t175 = load ptr, ptr %l92, !tbaa !29
  %t176 = load i32, ptr %l94, !tbaa !23
  %t178 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t174, ptr %t175, i32 %t176, %"compiler/source:Span" %t173)
  store ptr %t178, ptr %l96
  br label %bb51
bb51:
  store { i64, [3 x i64] } zeroinitializer, ptr %t179
  %t180 = getelementptr { i64, [3 x i64] }, ptr %t179, i32 0, i32 0
  store i64 1, ptr %t180
  %t181 = load %"compiler/source:Span", ptr %l89
  %t182 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t181, 0
  %t183 = load ptr, ptr %l90, !tbaa !29
  %t184 = insertvalue { %"compiler/source:Span", ptr, ptr } %t182, ptr %t183, 1
  %t185 = load ptr, ptr %l96, !tbaa !29
  %t186 = insertvalue { %"compiler/source:Span", ptr, ptr } %t184, ptr %t185, 2
  %t187 = getelementptr { i64, [3 x i64] }, ptr %t179, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t186, ptr %t187
  %t188 = load { i64, [3 x i64] }, ptr %t179
  %t190 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t188, ptr %t190
  %t191 = load ptr, ptr %l88, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t191, ptr %t190)
  br label %bb52
bb52:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereachesTrait(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l14 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l29 = alloca i32
  %l37 = alloca i32
  %l46 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t3 = icmp sgt i64 %t1, 32
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t13 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtended(ptr %v0, ptr %s2, ptr %t9, i32 %a2)
  store { i64, ptr } %t13, ptr %l14
  br label %bb4
bb4:
  %t14 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t14, 0
  %t16 = extractvalue { i64, ptr } %t14, 1
  %t17 = mul i64 %t15, 4
  %t18 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t16, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t22 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t22, 0
  store i64 %t24, ptr %l6, !tbaa !24
  br label %bb5
bb5:
  %t26 = load i64, ptr %l5, !tbaa !24
  %t27 = load i64, ptr %l6, !tbaa !24
  %t30 = icmp slt i64 %t26, %t27
  %t32 = xor i1 %t30, true
  br i1 %t32, label %bb6, label %bb7
bb6:
  br label %bb22
bb7:
  br label %bb8
bb8:
  %t34 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t34, ptr %l22, !tbaa !27
  %t35 = load i64, ptr %l5, !tbaa !24
  %t37 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = getelementptr i32, ptr %t38, i64 %t35
  %t40 = load i32, ptr %t39, !tbaa !33
  store i32 %t40, ptr %l7, !tbaa !23
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/check:Checker", ptr %t42, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t47 = getelementptr %"compiler/generic:Program", ptr %t45, i32 0, i32 2
  %t48 = load i32, ptr %l7, !tbaa !23
  %t51 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t47, i32 %t48)
  store i32 %t51, ptr %l29
  br label %bb9
bb9:
  %t52 = load i32, ptr %l29, !range !{i32 0, i32 33}
  %t54 = trunc i64 18 to i32
  %t55 = icmp eq i32 %t52, %t54
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb10, label %bb11
bb10:
  br label %bb21
bb11:
  br label %bb12
bb12:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Program", ptr %t62, i32 0, i32 2
  %t65 = load i32, ptr %l7, !tbaa !23
  %t68 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t64, i32 %t65)
  store i32 %t68, ptr %l37
  br label %bb13
bb13:
  %t69 = load i32, ptr %l1, !tbaa !23
  %t70 = load i32, ptr %l37, !tbaa !23
  %t72 = icmp eq i32 %t70, %t69
  br i1 %t72, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load i32, ptr %l1, !tbaa !23
  %t77 = load i32, ptr %l7, !tbaa !23
  %t78 = load i64, ptr %l3, !tbaa !24
  %t80 = add i64 %t78, 1
  %t85 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereachesTrait(ptr %v0, ptr %t75, i32 %t76, i32 %t77, i64 %t80)
  store i1 %t85, ptr %l46
  br label %bb17
bb17:
  %t86 = load i1, ptr %l46, !tbaa !21
  br i1 %t86, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t88 = load i64, ptr %l5, !tbaa !24
  %t90 = add i64 %t88, 1
  store i64 %t90, ptr %l5, !tbaa !24
  br label %bb5
bb22:
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflTextOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %lp6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i1
  %l23 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca { i64, ptr }
  %l28 = alloca ptr
  %l29 = alloca i1
  %l34 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l38 = alloca i32
  %l40 = alloca ptr
  %l41 = alloca i1
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l49 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l65 = alloca i32
  %l67 = alloca { i64, ptr }
  %l69 = alloca i64
  %s6 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t2 = load ptr, ptr %l11, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l11, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 29}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l12, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l12, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32 }, ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19, !range !{i32 0, i32 96}
  store i32 %t20, ptr %l3
  br label %bb5
bb4:
  br label %bb10
bb5:
  %t22 = load i32, ptr %l3, !range !{i32 0, i32 96}
  %t24 = trunc i64 5 to i32
  %t25 = icmp eq i32 %t22, %t24
  br i1 %t25, label %bb6, label %bb7
bb6:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load %"compiler/source:Span", ptr %l2
  %t31 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estrBytes(ptr %v0, ptr %t27, %"compiler/source:Span" %t28)
  store { i64, ptr } %t31, ptr %l23
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t32 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t32, ptr %l25, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t34, 0
  store i64 %t35, ptr %l26, !tbaa !24
  %t36 = load i64, ptr %l26, !tbaa !24
  %t37 = mul i64 %t36, 1
  %t38 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t37)
  %t39 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  store { i64, ptr } %t40, ptr %l27, !tbaa !27
  %t41 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = load i64, ptr %l26, !tbaa !24
  %t46 = mul i64 %t45, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t42, ptr %t44, i64 %t46, i1 false)
  %t47 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t47, ptr %l25, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t49 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t48, 1
  store { i32, { i64, ptr } } %t49, ptr %rv
  br label %ret
bb9:
  br label %bb42
bb10:
  %t50 = load ptr, ptr %l1, !tbaa !29
  store ptr %t50, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t51 = load ptr, ptr %l28, !tbaa !29
  %t52 = icmp ne ptr %t51, null
  br i1 %t52, label %bb11, label %bb12
bb11:
  %t54 = load ptr, ptr %l28, !tbaa !29
  %t55 = load i64, ptr %t54, !range !{i64 0, i64 29}
  %t57 = icmp eq i64 %t55, 2
  store i1 %t57, ptr %l29, !tbaa !21
  br label %bb12
bb12:
  %t58 = load i1, ptr %l29, !tbaa !21
  br i1 %t58, label %bb13, label %bb14
bb13:
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr { i64, [5 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { %"compiler/source:Span", ptr }, ptr %t61, i32 0, i32 1
  %t63 = load ptr, ptr %t62
  store ptr %t63, ptr %l4, !tbaa !29
  br label %bb15
bb14:
  br label %bb19
bb15:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load ptr, ptr %l4, !tbaa !29
  %t69 = call { i32, { i64, ptr } } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflTextOf(ptr %v0, ptr %v1, ptr %v2, ptr %t65, ptr %t66)
  %t70 = extractvalue { i32, { i64, ptr } } %t69, 1
  %t71 = extractvalue { i32, { i64, ptr } } %t69, 0
  store i32 %t71, ptr %l38
  %t72 = icmp ne i32 %t71, 0
  br i1 %t72, label %bb17, label %ok.73, !prof !99
ok.73:
  store { i64, ptr } %t70, ptr %l37
  br label %bb16
bb16:
  %t74 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t74, ptr %l34, !tbaa !27
  br label %bb18
bb17:
  %t75 = load i32, ptr %l38, !tbaa !23
  %t76 = lshr i32 %t75, 16
  %t77 = and i32 %t75, 65535
  %t78 = icmp eq i32 %t76, 1
  %t79 = select i1 %t78, i32 1, i32 0
  %t80 = icmp eq i32 %t75, 0
  %t81 = shl i32 %t79, 16
  %t82 = or i32 %t81, %t77
  %t83 = select i1 %t80, i32 0, i32 %t82
  %t85 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t83, 0
  store { i32, { i64, ptr } } %t85, ptr %rv
  br label %ret
bb18:
  %t86 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t87 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t86, 1
  store { i32, { i64, ptr } } %t87, ptr %rv
  br label %ret
bb19:
  %t88 = load ptr, ptr %l1, !tbaa !29
  store ptr %t88, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t89 = load ptr, ptr %l40, !tbaa !29
  %t90 = icmp ne ptr %t89, null
  br i1 %t90, label %bb20, label %bb21
bb20:
  %t92 = load ptr, ptr %l40, !tbaa !29
  %t93 = load i64, ptr %t92, !range !{i64 0, i64 29}
  %t95 = icmp eq i64 %t93, 21
  store i1 %t95, ptr %l41, !tbaa !21
  br label %bb21
bb21:
  %t96 = load i1, ptr %l41, !tbaa !21
  br i1 %t96, label %bb22, label %bb23
bb22:
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t99 = getelementptr { i64, [5 x i64] }, ptr %t97, i32 0, i32 1
  %t100 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t99, i32 0, i32 1
  %t101 = load { i64, ptr }, ptr %t100
  store { i64, ptr } %t101, ptr %l5, !tbaa !27
  br label %bb24
bb23:
  br label %bb37
bb24:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d16, i32 0, i32 1) }, ptr %l46, !tbaa !27
  %t103 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t103, ptr %l47, !tbaa !27
  %t104 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t104, 0
  store i64 %t105, ptr %l48, !tbaa !24
  %t106 = load i64, ptr %l48, !tbaa !24
  %t107 = mul i64 %t106, 1
  %t108 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t107)
  %t109 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t108, 1
  store { i64, ptr } %t110, ptr %l49, !tbaa !27
  %t111 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = load i64, ptr %l48, !tbaa !24
  %t116 = mul i64 %t115, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t112, ptr %t114, i64 %t116, i1 false)
  %t117 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t117, ptr %lp6
  %t118 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t119 = load ptr, ptr %lp6
  store { i64, ptr } %t118, ptr %t119, !tbaa !27
  %t120 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t120, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t122 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t122, 0
  store i64 %t124, ptr %l9, !tbaa !24
  br label %bb25
bb25:
  store %olang.scope zeroinitializer, ptr %s6
  %t126 = load i64, ptr %l8, !tbaa !24
  %t127 = load i64, ptr %l9, !tbaa !24
  %t130 = icmp slt i64 %t126, %t127
  %t132 = xor i1 %t130, true
  br i1 %t132, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s6)
  br label %bb36
bb27:
  br label %bb28
bb28:
  %t134 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t134, ptr %l57, !tbaa !27
  %t135 = load i64, ptr %l8, !tbaa !24
  %t137 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr ptr, ptr %t138, i64 %t135
  %t140 = load ptr, ptr %t139, !tbaa !39
  %t142 = load ptr, ptr %lp6
  %t143 = load { i64, ptr }, ptr %t142, !tbaa !27
  store { i64, ptr } %t143, ptr %l60, !tbaa !27
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t148 = call { i32, { i64, ptr } } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflPiece(ptr %v0, ptr %v1, ptr %s6, ptr %t144, ptr %t140)
  %t149 = extractvalue { i32, { i64, ptr } } %t148, 1
  %t150 = extractvalue { i32, { i64, ptr } } %t148, 0
  store i32 %t150, ptr %l65
  %t151 = icmp ne i32 %t150, 0
  br i1 %t151, label %bb30, label %ok.152, !prof !99
ok.152:
  store { i64, ptr } %t149, ptr %l64
  br label %bb29
bb29:
  %t153 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t153, ptr %l61, !tbaa !27
  br label %bb31
bb30:
  %t154 = load i32, ptr %l65, !tbaa !23
  %t155 = lshr i32 %t154, 16
  %t156 = and i32 %t154, 65535
  %t157 = icmp eq i32 %t155, 1
  %t158 = select i1 %t157, i32 1, i32 0
  %t159 = icmp eq i32 %t154, 0
  %t160 = shl i32 %t158, 16
  %t161 = or i32 %t160, %t156
  %t162 = select i1 %t159, i32 0, i32 %t161
  call void @__olang_scope_close(ptr %s6)
  %t164 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t162, 0
  store { i32, { i64, ptr } } %t164, ptr %rv
  br label %ret
bb31:
  %t165 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t166 = extractvalue { i64, ptr } %t165, 1
  %t167 = extractvalue { i64, ptr } %t165, 0
  %t168 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t168, 1
  %t170 = extractvalue { i64, ptr } %t168, 0
  %t171 = add i64 %t167, %t170
  %t172 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t171)
  call void @olang_textcopy(ptr %t172, ptr %t166, i64 %t167)
  %t173 = getelementptr i8, ptr %t172, i64 %t167
  call void @olang_textcopy(ptr %t173, ptr %t169, i64 %t170)
  %t174 = insertvalue { i64, ptr } undef, i64 %t171, 0
  %t175 = insertvalue { i64, ptr } %t174, ptr %t172, 1
  store { i64, ptr } %t175, ptr %l67, !tbaa !27
  %t176 = load ptr, ptr %lp6
  %t177 = load { i64, ptr }, ptr %t176, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t177, 0
  %t179 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t180 = extractvalue { i64, ptr } %t179, 0
  store i64 %t180, ptr %l69, !tbaa !24
  %t182 = load i64, ptr %l69, !tbaa !24
  %t183 = icmp eq i64 %t178, %t182
  br i1 %t183, label %bb32, label %bb33
bb32:
  %t185 = load ptr, ptr %lp6
  %t186 = getelementptr { i64, ptr }, ptr %t185, i32 0, i32 1
  %t187 = load ptr, ptr %t186, !tbaa !27
  %t188 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t189 = load ptr, ptr %t188, !tbaa !27
  %t190 = load i64, ptr %l69, !tbaa !24
  %t191 = mul i64 %t190, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t187, ptr %t189, i64 %t191, i1 false)
  br label %bb34
bb33:
  %t192 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t193 = load ptr, ptr %lp6
  store { i64, ptr } %t192, ptr %t193, !tbaa !27
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s6)
  br label %bb35
bb35:
  %t194 = load i64, ptr %l8, !tbaa !24
  %t196 = add i64 %t194, 1
  store i64 %t196, ptr %l8, !tbaa !24
  br label %bb25
bb36:
  %t198 = load ptr, ptr %lp6
  %t199 = load { i64, ptr }, ptr %t198, !tbaa !27
  %t201 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t199, 1
  store { i32, { i64, ptr } } %t201, ptr %rv
  br label %ret
bb37:
  br i1 true, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_3ff8b815b8f08888_72cba32f0bfc98b4)
  unreachable
bb42:
  %t203 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t203, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erenderPiece(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca { i64, [2 x i64] }
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %lp9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i32
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca i1
  %l38 = alloca ptr
  %l48 = alloca { i64, ptr }
  %l50 = alloca i64
  %l58 = alloca i64
  %l61 = alloca i64
  %l89 = alloca ptr
  %l92 = alloca i32
  %l96 = alloca i1
  %l101 = alloca i32
  %l104 = alloca i1
  %l109 = alloca i32
  %l112 = alloca %"compiler/source:Span"
  %l118 = alloca i32
  %s3 = alloca %olang.scope
  %rv = alloca ptr
  %t156 = alloca { i64, [2 x i64] }, align 8
  %t226 = alloca { i64, [5 x i64] }, align 8
  %t238 = alloca { i64, [2 x i64] }, align 8
  %t248 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t7 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erendered(ptr %v0, ptr %v1, ptr %t1, %"compiler/source:Span" %a1, ptr %a2)
  store ptr %t7, ptr %l21
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l21, !tbaa !29
  store ptr %t8, ptr %l3, !tbaa !29
  %t9 = load ptr, ptr %l3, !tbaa !29
  store ptr %t9, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t10 = load ptr, ptr %l22, !tbaa !29
  %t11 = icmp ne ptr %t10, null
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l22, !tbaa !29
  %t14 = load i64, ptr %t13, !range !{i64 0, i64 18}
  %t16 = icmp eq i64 %t14, 15
  store i1 %t16, ptr %l23, !tbaa !21
  br label %bb3
bb3:
  %t17 = load i1, ptr %l23, !tbaa !21
  br i1 %t17, label %bb4, label %bb5
bb4:
  %t18 = load ptr, ptr %l3, !tbaa !29
  %t20 = getelementptr { i64, [5 x i64] }, ptr %t18, i32 0, i32 1
  %t21 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t20, i32 0, i32 2
  %t22 = load ptr, ptr %t21
  store ptr %t22, ptr %l4, !tbaa !29
  br label %bb6
bb5:
  br label %bb43
bb6:
  %t24 = load ptr, ptr %l4, !tbaa !29
  store ptr %t24, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t25 = load ptr, ptr %l28, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb7, label %bb8
bb7:
  %t28 = load ptr, ptr %l28, !tbaa !29
  %t29 = load i64, ptr %t28, !range !{i64 0, i64 3}
  %t31 = icmp eq i64 %t29, 0
  store i1 %t31, ptr %l29, !tbaa !21
  br label %bb8
bb8:
  %t32 = load i1, ptr %l29, !tbaa !21
  br i1 %t32, label %bb9, label %bb10
bb9:
  %t33 = load ptr, ptr %l4, !tbaa !29
  %t35 = getelementptr { i64, [4 x i64] }, ptr %t33, i32 0, i32 1
  %t36 = getelementptr { i32 }, ptr %t35, i32 0, i32 0
  %t37 = load i32, ptr %t36
  store i32 %t37, ptr %l5, !tbaa !23
  br label %bb11
bb10:
  br label %bb37
bb11:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/check:Checker", ptr %t39, i32 0, i32 12
  %t42 = load i32, ptr %l5, !tbaa !23
  %t44 = sext i32 %t42 to i64
  %t47 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t41, i64 %t44)
  store ptr %t47, ptr %l38
  br label %bb12
bb12:
  %t48 = load ptr, ptr %l38, !tbaa !29
  %t50 = getelementptr %"compiler/typed:Body", ptr %t48, i32 0, i32 1
  %t51 = load { i64, [2 x i64] }, ptr %t50
  store { i64, [2 x i64] } %t51, ptr %l6
  %t53 = load { i64, [2 x i64] }, ptr %l6
  %t55 = extractvalue { i64, [2 x i64] } %t53, 0
  %t56 = icmp eq i64 %t55, 0
  br i1 %t56, label %bb13, label %bb14
bb13:
  %t58 = getelementptr { i64, [2 x i64] }, ptr %l6, i32 0, i32 1
  %t59 = getelementptr { i64 }, ptr %t58, i32 0, i32 0
  %t60 = load i64, ptr %t59
  store i64 %t60, ptr %l7, !tbaa !24
  br label %bb15
bb14:
  br label %bb31
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load i64, ptr %l7, !tbaa !24
  %t64 = load i32, ptr %l5, !tbaa !23
  %t66 = sext i32 %t64 to i64
  %t70 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esigText(ptr %v0, ptr %s3, ptr %t62, i64 %t63, i64 %t66)
  store { i64, ptr } %t70, ptr %l48
  br label %bb16
bb16:
  %t71 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t71, ptr %l8, !tbaa !27
  %t72 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t74 = extractvalue { i64, ptr } %t72, 0
  store i64 %t74, ptr %l50, !tbaa !24
  %t75 = load i64, ptr %l50, !tbaa !24
  %t76 = icmp sge i64 %t75, 0
  br i1 %t76, label %bb17, label %bb18
bb17:
  %t78 = load i64, ptr %l50, !tbaa !24
  %t79 = mul i64 %t78, 1
  %t80 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t79)
  %t81 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t80, 1
  %t83 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t83, ptr %lp9
  %t85 = load ptr, ptr %lp9
  store { i64, ptr } %t82, ptr %t85, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t86 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t86, 0
  store i64 %t88, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t90 = load i64, ptr %l11, !tbaa !24
  %t91 = load i64, ptr %l10, !tbaa !24
  %t94 = icmp sgt i64 %t90, %t91
  br i1 %t94, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_db1f2ae5e4bef7a4_1fc823cb35fb1540)
  unreachable
bb19:
  %t96 = load i64, ptr %l12, !tbaa !24
  %t98 = icmp sgt i64 %t96, 0
  br i1 %t98, label %bb21, label %bb22
bb20:
  store i64 0, ptr %l58, !tbaa !24
  br label %bb24
bb21:
  %t100 = load i64, ptr %l11, !tbaa !24
  %t101 = load i64, ptr %l10, !tbaa !24
  %t104 = sub i64 %t100, %t101
  %t105 = load i64, ptr %l12, !tbaa !24
  %t108 = add i64 %t104, %t105
  %t110 = sub i64 %t108, 1
  %t111 = load i64, ptr %l12, !tbaa !24
  %t114 = sdiv i64 %t110, %t111
  store i64 %t114, ptr %l61, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb23
bb23:
  %t116 = load i64, ptr %l61, !tbaa !24
  store i64 %t116, ptr %l58, !tbaa !24
  br label %bb24
bb24:
  %t117 = load i64, ptr %l58, !tbaa !24
  store i64 %t117, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb25
bb25:
  %t118 = load i64, ptr %l14, !tbaa !24
  %t119 = load i64, ptr %l13, !tbaa !24
  %t122 = icmp slt i64 %t118, %t119
  %t124 = xor i1 %t122, true
  br i1 %t124, label %bb26, label %bb27
bb26:
  br label %bb30
bb27:
  br label %bb28
bb28:
  %t126 = load i64, ptr %l10, !tbaa !24
  %t127 = load i64, ptr %l14, !tbaa !24
  %t128 = load i64, ptr %l12, !tbaa !24
  %t131 = mul i64 %t127, %t128
  %t134 = add i64 %t126, %t131
  store i64 %t134, ptr %l15, !tbaa !24
  %t136 = load i64, ptr %l15, !tbaa !24
  %t137 = load i64, ptr %l15, !tbaa !24
  %t139 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t140 = load ptr, ptr %t139, !tbaa !27
  %t141 = getelementptr i8, ptr %t140, i64 %t137
  %t142 = load i8, ptr %t141, !tbaa !32
  %t145 = load ptr, ptr %lp9
  %t147 = getelementptr { i64, ptr }, ptr %t145, i32 0, i32 1
  %t148 = load ptr, ptr %t147, !tbaa !27
  %t149 = getelementptr i8, ptr %t148, i64 %t136
  store i8 %t142, ptr %t149, !tbaa !32
  br label %bb29
bb29:
  %t150 = load i64, ptr %l14, !tbaa !24
  %t152 = add i64 %t150, 1
  store i64 %t152, ptr %l14, !tbaa !24
  br label %bb25
bb30:
  %t154 = load ptr, ptr %lp9
  %t155 = load { i64, ptr }, ptr %t154, !tbaa !27
  store { i64, [2 x i64] } zeroinitializer, ptr %t156
  %t157 = getelementptr { i64, [2 x i64] }, ptr %t156, i32 0, i32 0
  store i64 0, ptr %t157
  %t159 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t155, 0
  %t160 = getelementptr { i64, [2 x i64] }, ptr %t156, i32 0, i32 1
  store { { i64, ptr } } %t159, ptr %t160
  %t161 = load { i64, [2 x i64] }, ptr %t156
  %t163 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store { i64, [2 x i64] } %t161, ptr %t163
  call void @__olang_scope_close(ptr %s3)
  store ptr %t163, ptr %rv
  br label %ret
bb31:
  br i1 true, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_404270212748a64a_94da604f2263273e)
  unreachable
bb36:
  br label %bb42
bb37:
  br i1 true, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_e2c214b199db46e1_ccde8582cd2310f5)
  unreachable
bb42:
  br label %bb48
bb43:
  br i1 true, label %bb44, label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  call void @__olang_check_failed(ptr @olang_loc_2d29d2076870b150_9b91c954cc3aa504)
  unreachable
bb48:
  %t165 = load ptr, ptr %l3, !tbaa !29
  %t167 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %t165)
  store ptr %t167, ptr %l89
  br label %bb49
bb49:
  %t168 = load ptr, ptr %l89, !tbaa !29
  store ptr %t168, ptr %l16, !tbaa !29
  %t169 = load ptr, ptr %l3, !tbaa !29
  %t172 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t169)
  store i32 %t172, ptr %l92
  br label %bb50
bb50:
  %t173 = load i32, ptr %l92, !tbaa !23
  store i32 %t173, ptr %l17, !tbaa !23
  %t174 = load ptr, ptr %l16, !tbaa !29
  %t176 = icmp eq ptr %t174, null
  %t178 = xor i1 %t176, true
  br i1 %t178, label %bb51, label %bb52
bb51:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t182 = getelementptr %"compiler/check:Checker", ptr %t180, i32 0, i32 1
  %t183 = load ptr, ptr %t182, !tbaa !29
  %t185 = getelementptr %"compiler/generic:Program", ptr %t183, i32 0, i32 2
  %t186 = load i32, ptr %l17, !tbaa !23
  %t189 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t185, i32 %t186)
  store i32 %t189, ptr %l101
  br label %bb53
bb52:
  store i1 false, ptr %l96, !tbaa !21
  br label %bb54
bb53:
  %t190 = load i32, ptr %l101, !range !{i32 0, i32 33}
  %t192 = trunc i64 19 to i32
  %t193 = icmp eq i32 %t190, %t192
  store i1 %t193, ptr %l96, !tbaa !21
  br label %bb54
bb54:
  %t195 = load i1, ptr %l96, !tbaa !21
  br i1 %t195, label %bb55, label %bb56
bb55:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr %"compiler/check:Checker", ptr %t196, i32 0, i32 1
  %t199 = load ptr, ptr %t198, !tbaa !29
  %t201 = getelementptr %"compiler/generic:Program", ptr %t199, i32 0, i32 2
  %t202 = load i32, ptr %l17, !tbaa !23
  %t205 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t201, i32 %t202)
  store i32 %t205, ptr %l109
  br label %bb57
bb56:
  store i1 false, ptr %l104, !tbaa !21
  br label %bb58
bb57:
  %t206 = load i32, ptr %l109, !tbaa !23
  %t207 = icmp ne i32 %t206, 0
  store i1 %t207, ptr %l104, !tbaa !21
  br label %bb58
bb58:
  %t209 = load i1, ptr %l104, !tbaa !21
  br i1 %t209, label %bb59, label %bb60
bb59:
  %t210 = load ptr, ptr %l3, !tbaa !29
  %t212 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %t210)
  store %"compiler/source:Span" %t212, ptr %l112
  br label %bb61
bb60:
  br label %bb63
bb61:
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t215 = getelementptr %"compiler/check:Checker", ptr %t213, i32 0, i32 1
  %t216 = load ptr, ptr %t215, !tbaa !29
  %t218 = getelementptr %"compiler/generic:Program", ptr %t216, i32 0, i32 2
  %t219 = load i32, ptr %l17, !tbaa !23
  %t220 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t224 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t218, i32 %t219, i64 %t220)
  store i32 %t224, ptr %l118
  br label %bb62
bb62:
  %t225 = load ptr, ptr %l16, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t226
  %t227 = getelementptr { i64, [5 x i64] }, ptr %t226, i32 0, i32 0
  store i64 3, ptr %t227
  %t228 = load %"compiler/source:Span", ptr %l112
  %t229 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t228, 0
  %t230 = load i32, ptr %l118, !tbaa !23
  %t231 = insertvalue { %"compiler/source:Span", i32, ptr } %t229, i32 %t230, 1
  %t233 = insertvalue { %"compiler/source:Span", i32, ptr } %t231, ptr %t225, 2
  %t234 = getelementptr { i64, [5 x i64] }, ptr %t226, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t233, ptr %t234
  %t235 = load { i64, [5 x i64] }, ptr %t226
  %t237 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t235, ptr %t237
  store { i64, [2 x i64] } zeroinitializer, ptr %t238
  %t239 = getelementptr { i64, [2 x i64] }, ptr %t238, i32 0, i32 0
  store i64 1, ptr %t239
  %t241 = insertvalue { ptr } undef, ptr %t237, 0
  %t242 = getelementptr { i64, [2 x i64] }, ptr %t238, i32 0, i32 1
  store { ptr } %t241, ptr %t242
  %t243 = load { i64, [2 x i64] }, ptr %t238
  %t245 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store { i64, [2 x i64] } %t243, ptr %t245
  store ptr %t245, ptr %rv
  br label %ret
bb63:
  %t247 = load ptr, ptr %l3, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t248
  %t249 = getelementptr { i64, [2 x i64] }, ptr %t248, i32 0, i32 0
  store i64 1, ptr %t249
  %t251 = insertvalue { ptr } undef, ptr %t247, 0
  %t252 = getelementptr { i64, [2 x i64] }, ptr %t248, i32 0, i32 1
  store { ptr } %t251, ptr %t252
  %t253 = load { i64, [2 x i64] }, ptr %t248
  %t255 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store { i64, [2 x i64] } %t253, ptr %t255
  store ptr %t255, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCallRef(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l5 = alloca i64
  %l8 = alloca i1
  %l14 = alloca i1
  %l17 = alloca { i64, ptr }
  %l21 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroBorrowedFrom(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sge i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load i64, ptr %l2, !tbaa !24
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Call", ptr %t12, i32 0, i32 1
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t20 = icmp slt i64 %t11, %t17
  store i1 %t20, ptr %l8, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb4
bb4:
  %t22 = load i1, ptr %l8, !tbaa !21
  br i1 %t22, label %bb5, label %bb6
bb5:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Call", ptr %t24, i32 0, i32 1
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  store { i64, ptr } %t27, ptr %l17, !tbaa !27
  %t28 = load i64, ptr %l2, !tbaa !24
  %t30 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr ptr, ptr %t31, i64 %t28
  %t33 = load ptr, ptr %t32, !tbaa !39
  %t37 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRef(ptr %v0, ptr %v1, ptr %t23, ptr %t33)
  store i1 %t37, ptr %l21
  br label %bb7
bb6:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb8
bb7:
  %t38 = load i1, ptr %l21, !tbaa !21
  store i1 %t38, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t39 = load i1, ptr %l14, !tbaa !21
  store i1 %t39, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroSettleResults(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca %"std/pair:Pair.1eb2466213689e002f25e81e83536e78"
  %l5 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca ptr
  %l7 = alloca i64
  %l11 = alloca i64
  %l13 = alloca i64
  %l18 = alloca %"std/pair:Pair.1eb2466213689e002f25e81e83536e78"
  %l22 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l28 = alloca i64
  %l30 = alloca i64
  %l35 = alloca i64
  %l37 = alloca ptr
  %l40 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 70
  store ptr %t3, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load i64, ptr %l3, !tbaa !24
  store i64 %t5, ptr %l11, !tbaa !24
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H48754b4fa56ee3a8c3b855086bca91dc(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l13
  br label %bb2
bb2:
  %t9 = load i64, ptr %l11, !tbaa !24
  %t10 = load i64, ptr %l13, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb23
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = call %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H015c7298d54f1d140374736283ef15ae(ptr %v0, ptr %v0, ptr %t15, i64 %t16)
  store %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" %t19, ptr %l18
  br label %bb6
bb6:
  %t20 = load %"std/pair:Pair.1eb2466213689e002f25e81e83536e78", ptr %l18
  store %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" %t20, ptr %l4
  %t21 = getelementptr %"std/pair:Pair.1eb2466213689e002f25e81e83536e78", ptr %l4, i32 0, i32 0
  %t22 = load i64, ptr %t21, !tbaa !24
  %t23 = load i64, ptr %l1, !tbaa !24
  %t26 = icmp ne i64 %t22, %t23
  br i1 %t26, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb8:
  br label %bb9
bb9:
  %t28 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t28, ptr %l22
  br label %bb10
bb10:
  %t29 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l22
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t29, ptr %l5
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load i64, ptr %l1, !tbaa !24
  %t32 = getelementptr %"std/pair:Pair.1eb2466213689e002f25e81e83536e78", ptr %l4, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroDeep(ptr %v0, ptr %v0, ptr %s2, ptr %t30, i64 %t31, ptr %t33, ptr %l5)
  br label %bb11
bb11:
  store ptr %l5, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s5
  %t39 = load i64, ptr %l7, !tbaa !24
  store i64 %t39, ptr %l28, !tbaa !24
  %t40 = load ptr, ptr %l6, !tbaa !29
  %t42 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s2, ptr %t40)
  store i64 %t42, ptr %l30
  br label %bb13
bb13:
  %t43 = load i64, ptr %l28, !tbaa !24
  %t44 = load i64, ptr %l30, !tbaa !24
  %t45 = icmp slt i64 %t43, %t44
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s5)
  br label %bb21
bb15:
  br label %bb16
bb16:
  %t49 = load ptr, ptr %l6, !tbaa !29
  %t50 = load i64, ptr %l7, !tbaa !24
  %t53 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s2, ptr %t49, i64 %t50)
  store i64 %t53, ptr %l35
  br label %bb17
bb17:
  %t54 = load i64, ptr %l35, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/check:Checker", ptr %t55, i32 0, i32 69
  store ptr %t57, ptr %l37, !tbaa !29
  %t58 = load i64, ptr %l1, !tbaa !24
  %t62 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s5, i64 %t58, i64 %t54)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t62, ptr %l40
  br label %bb18
bb18:
  %t63 = load ptr, ptr %l37, !tbaa !29
  %t64 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l40
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t63, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t64, i1 true)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s5)
  br label %bb20
bb20:
  %t65 = load i64, ptr %l7, !tbaa !24
  %t67 = add i64 %t65, 1
  store i64 %t67, ptr %l7, !tbaa !24
  br label %bb12
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb22:
  %t69 = load i64, ptr %l3, !tbaa !24
  %t71 = add i64 %t69, 1
  store i64 %t71, ptr %l3, !tbaa !24
  br label %bb1
bb23:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i64
  %l17 = alloca i1
  %l20 = alloca ptr
  %l23 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca i32
  %l29 = alloca { i64, ptr }
  %l36 = alloca ptr
  %l37 = alloca i32
  %l41 = alloca ptr
  %l43 = alloca { i64, ptr }
  %l45 = alloca i32
  %l46 = alloca i64
  %l49 = alloca i1
  %l52 = alloca ptr
  %l55 = alloca ptr
  %l59 = alloca i32
  %l60 = alloca i32
  %l61 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l6, !tbaa !29
  %t5 = load i32, ptr %l1, !tbaa !23
  store i32 %t5, ptr %l7, !tbaa !23
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 0
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/load:Loader", ptr %t12, i32 0, i32 3
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t16 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t19 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %t15, { i64, ptr } %t16)
  store i32 %t19, ptr %l13
  br label %bb1
bb1:
  %t20 = load ptr, ptr %l6, !tbaa !29
  %t21 = load i32, ptr %l7, !tbaa !23
  %t22 = load i32, ptr %l13, !tbaa !23
  %t23 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t20, i32 %t21, i32 %t22)
  store i64 %t23, ptr %l14
  br label %bb2
bb2:
  %t24 = load i64, ptr %l14, !tbaa !24
  store i64 %t24, ptr %l4, !tbaa !24
  %t25 = load i64, ptr %l4, !tbaa !24
  %t27 = icmp sge i64 %t25, 0
  br i1 %t27, label %bb3, label %bb4
bb3:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 2
  store ptr %t34, ptr %l20, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/check:Checker", ptr %t35, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = getelementptr %"compiler/generic:Program", ptr %t38, i32 0, i32 2
  store ptr %t40, ptr %l23, !tbaa !29
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/check:Checker", ptr %t41, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t45 = load i64, ptr %l4, !tbaa !24
  %t48 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t44, i64 %t45)
  store i32 %t48, ptr %l27
  br label %bb5
bb4:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb8
bb5:
  %t49 = load ptr, ptr %l23, !tbaa !29
  %t50 = load i32, ptr %l27, !tbaa !23
  %t51 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t49, i32 %t50)
  store i32 %t51, ptr %l28
  br label %bb6
bb6:
  %t52 = load ptr, ptr %l20, !tbaa !29
  %t53 = load i32, ptr %l28, !tbaa !23
  %t54 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t52, i32 %t53)
  store { i64, ptr } %t54, ptr %l29
  br label %bb7
bb7:
  %t55 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t55, 0
  %t57 = load i64, ptr %l3, !tbaa !24
  %t59 = add i64 %t57, 1
  %t62 = icmp eq i64 %t56, %t59
  store i1 %t62, ptr %l17, !tbaa !21
  br label %bb8
bb8:
  %t64 = load i1, ptr %l17, !tbaa !21
  br i1 %t64, label %bb9, label %bb10
bb9:
  %t65 = load i64, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t65, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/check:Checker", ptr %t67, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !29
  store ptr %t70, ptr %l36, !tbaa !29
  %t71 = load i32, ptr %l1, !tbaa !23
  store i32 %t71, ptr %l37, !tbaa !23
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/check:Checker", ptr %t72, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !29
  %t77 = getelementptr %"compiler/generic:Program", ptr %t75, i32 0, i32 0
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t80 = getelementptr %"compiler/load:Loader", ptr %t78, i32 0, i32 3
  %t81 = load ptr, ptr %t80, !tbaa !29
  store ptr %t81, ptr %l41, !tbaa !29
  %t82 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t84 = call { i64, ptr } @compiler_2fcheck_2elowerFirst(ptr %v1, ptr %s0, { i64, ptr } %t82)
  store { i64, ptr } %t84, ptr %l43
  br label %bb12
bb12:
  %t85 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t85, 0
  %t87 = extractvalue { i64, ptr } %t85, 1
  %t88 = mul i64 %t86, 1
  %t89 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t88)
  call void @llvm.memcpy.p0.p0.i64(ptr %t89, ptr %t87, i64 %t88, i1 false)
  %t90 = insertvalue { i64, ptr } undef, i64 %t86, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t89, 1
  %t92 = load ptr, ptr %l41, !tbaa !29
  %t94 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s0, ptr %t92, { i64, ptr } %t91)
  store i32 %t94, ptr %l45
  br label %bb13
bb13:
  %t95 = load ptr, ptr %l36, !tbaa !29
  %t96 = load i32, ptr %l37, !tbaa !23
  %t97 = load i32, ptr %l45, !tbaa !23
  %t98 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t95, i32 %t96, i32 %t97)
  store i64 %t98, ptr %l46
  br label %bb14
bb14:
  %t99 = load i64, ptr %l46, !tbaa !24
  store i64 %t99, ptr %l4, !tbaa !24
  %t100 = load i64, ptr %l4, !tbaa !24
  %t102 = icmp sge i64 %t100, 0
  br i1 %t102, label %bb15, label %bb16
bb15:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/check:Checker", ptr %t104, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !29
  %t109 = getelementptr %"compiler/generic:Program", ptr %t107, i32 0, i32 2
  store ptr %t109, ptr %l52, !tbaa !29
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/check:Checker", ptr %t110, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t115 = getelementptr %"compiler/generic:Program", ptr %t113, i32 0, i32 2
  store ptr %t115, ptr %l55, !tbaa !29
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/check:Checker", ptr %t116, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !29
  %t120 = load i64, ptr %l4, !tbaa !24
  %t123 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t119, i64 %t120)
  store i32 %t123, ptr %l59
  br label %bb17
bb16:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb20
bb17:
  %t124 = load ptr, ptr %l55, !tbaa !29
  %t125 = load i32, ptr %l59, !tbaa !23
  %t126 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t124, i32 %t125)
  store i32 %t126, ptr %l60
  br label %bb18
bb18:
  %t127 = load ptr, ptr %l52, !tbaa !29
  %t128 = load i32, ptr %l60, !tbaa !23
  %t129 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t127, i32 %t128)
  store { i64, ptr } %t129, ptr %l61
  br label %bb19
bb19:
  %t130 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t130, 0
  %t132 = load i64, ptr %l3, !tbaa !24
  %t134 = add i64 %t132, 1
  %t137 = icmp eq i64 %t131, %t134
  store i1 %t137, ptr %l49, !tbaa !21
  br label %bb20
bb20:
  %t139 = load i1, ptr %l49, !tbaa !21
  br i1 %t139, label %bb21, label %bb22
bb21:
  %t140 = load i64, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t140, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eseqOf(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l7 = alloca i64
  %l11 = alloca %"compiler/source:Span"
  %l12 = alloca i32
  %l16 = alloca { i64, ptr }
  %l19 = alloca %"compiler/typed:Seq"
  %rv = alloca ptr
  %t29 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 37
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load i64, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l7, !tbaa !24
  %t9 = icmp eq i64 %t7, %t6
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l4, !tbaa !29
  store ptr %t11, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  store %"compiler/source:Span" %a1, ptr %l11
  store i32 %a2, ptr %l12, !tbaa !23
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/check:Checker", ptr %t15, i32 0, i32 37
  %t18 = load i64, ptr %l3, !tbaa !24
  %t21 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t17, i64 %t18)
  store { i64, ptr } %t21, ptr %l16
  br label %bb5
bb5:
  %t22 = load ptr, ptr %l4, !tbaa !29
  %t24 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t26 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t24, ptr %t22)
  store %"compiler/typed:Seq" %t26, ptr %l19
  br label %bb6
bb6:
  %t27 = load %"compiler/typed:Seq", ptr %l19
  %t28 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Seq" %t27, ptr %t28
  store { i64, [5 x i64] } zeroinitializer, ptr %t29
  %t30 = getelementptr { i64, [5 x i64] }, ptr %t29, i32 0, i32 0
  store i64 12, ptr %t30
  %t31 = load %"compiler/source:Span", ptr %l11
  %t32 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t31, 0
  %t33 = load i32, ptr %l12, !tbaa !23
  %t34 = insertvalue { %"compiler/source:Span", i32, ptr } %t32, i32 %t33, 1
  %t36 = insertvalue { %"compiler/source:Span", i32, ptr } %t34, ptr %t28, 2
  %t37 = getelementptr { i64, [5 x i64] }, ptr %t29, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t36, ptr %t37
  %t38 = load { i64, [5 x i64] }, ptr %t29
  %t40 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t38, ptr %t40
  store ptr %t40, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esliceOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, ptr %a4, i32 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l26 = alloca i32
  %l29 = alloca i1
  %l30 = alloca i64
  %l36 = alloca i64
  %l39 = alloca i64
  %l59 = alloca i1
  %l67 = alloca i64
  %l70 = alloca %"compiler/source:Span"
  %l75 = alloca i32
  %l79 = alloca ptr
  %l86 = alloca i32
  %l91 = alloca i32
  %l100 = alloca ptr
  %l103 = alloca i1
  %l105 = alloca ptr
  %l106 = alloca %"compiler/source:Span"
  %l109 = alloca { i64, ptr }
  %l111 = alloca %"compiler/msgs:Msg"
  %l112 = alloca i64
  %l115 = alloca ptr
  %l118 = alloca i64
  %l124 = alloca i1
  %l126 = alloca ptr
  %l127 = alloca %"compiler/source:Span"
  %l130 = alloca { i64, ptr }
  %l132 = alloca %"compiler/msgs:Msg"
  %l133 = alloca i64
  %l136 = alloca ptr
  %l139 = alloca i64
  %l142 = alloca i1
  %l149 = alloca ptr
  %l152 = alloca ptr
  %l153 = alloca ptr
  %l154 = alloca %"compiler/source:Span"
  %l156 = alloca i32
  %l157 = alloca ptr
  %l158 = alloca ptr
  %l159 = alloca ptr
  %l160 = alloca ptr
  %l162 = alloca i32
  %l163 = alloca ptr
  %l165 = alloca %"compiler/source:Span"
  %l166 = alloca ptr
  %l169 = alloca ptr
  %l170 = alloca %"compiler/source:Span"
  %l171 = alloca %"compiler/source:Span"
  %l172 = alloca i64
  %l176 = alloca ptr
  %l177 = alloca ptr
  %l180 = alloca { i64, ptr }
  %l183 = alloca { i64, ptr }
  %l187 = alloca ptr
  %l189 = alloca ptr
  %l190 = alloca ptr
  %l191 = alloca ptr
  %l193 = alloca i32
  %l194 = alloca ptr
  %l196 = alloca %"compiler/source:Span"
  %l197 = alloca ptr
  %l201 = alloca i64
  %l206 = alloca ptr
  %l210 = alloca ptr
  %l211 = alloca %"compiler/source:Span"
  %l212 = alloca %"compiler/source:Span"
  %l213 = alloca i64
  %l217 = alloca ptr
  %l218 = alloca ptr
  %l221 = alloca { i64, ptr }
  %l225 = alloca { i64, ptr }
  %l229 = alloca ptr
  %l232 = alloca ptr
  %l233 = alloca %"compiler/source:Span"
  %l235 = alloca i32
  %l236 = alloca ptr
  %l238 = alloca ptr
  %l239 = alloca ptr
  %l241 = alloca i32
  %l242 = alloca ptr
  %l246 = alloca ptr
  %l247 = alloca %"compiler/source:Span"
  %l249 = alloca i32
  %l250 = alloca i32
  %l251 = alloca %"compiler/source:Span"
  %l257 = alloca i32
  %l261 = alloca ptr
  %l263 = alloca ptr
  %l264 = alloca ptr
  %l266 = alloca i32
  %l267 = alloca ptr
  %l271 = alloca i1
  %l272 = alloca i32
  %l276 = alloca ptr
  %l281 = alloca i32
  %l284 = alloca i32
  %l289 = alloca i32
  %l290 = alloca i32
  %l291 = alloca %"compiler/source:Span"
  %l297 = alloca i32
  %l298 = alloca ptr
  %l301 = alloca ptr
  %l306 = alloca %"compiler/typed:Slice"
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca ptr
  %t109 = alloca { i64, [4 x i64] }, align 8
  %t485 = alloca { i64, [5 x i64] }, align 8
  %t588 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  store i32 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  %t3 = load ptr, ptr %l6, !tbaa !29
  %t5 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %t3)
  store i32 %t5, ptr %l26
  br label %bb1
bb1:
  %t6 = load i32, ptr %l26, !tbaa !23
  store i32 %t6, ptr %l7, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load ptr, ptr %l2, !tbaa !29
  %t11 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eslicedWritable(ptr %v0, ptr %v0, ptr %t7, ptr %t8)
  store i1 %t11, ptr %l29
  br label %bb2
bb2:
  %t12 = load i1, ptr %l29, !tbaa !21
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t13 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  store i64 %t13, ptr %l30, !tbaa !24
  br label %bb5
bb4:
  %t15 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  store i64 %t15, ptr %l30, !tbaa !24
  br label %bb5
bb5:
  %t17 = load i64, ptr %l30, !tbaa !24
  store i64 %t17, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  store i64 4, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t18 = load i64, ptr %l10, !tbaa !24
  %t19 = load i64, ptr %l9, !tbaa !24
  %t22 = icmp sgt i64 %t18, %t19
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t24 = load i64, ptr %l11, !tbaa !24
  %t26 = icmp sgt i64 %t24, 0
  br i1 %t26, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l36, !tbaa !24
  br label %bb11
bb8:
  %t28 = load i64, ptr %l10, !tbaa !24
  %t29 = load i64, ptr %l9, !tbaa !24
  %t32 = sub i64 %t28, %t29
  %t33 = load i64, ptr %l11, !tbaa !24
  %t36 = add i64 %t32, %t33
  %t38 = sub i64 %t36, 1
  %t39 = load i64, ptr %l11, !tbaa !24
  %t42 = sdiv i64 %t38, %t39
  store i64 %t42, ptr %l39, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l39, !tbaa !24
  br label %bb10
bb10:
  %t44 = load i64, ptr %l39, !tbaa !24
  store i64 %t44, ptr %l36, !tbaa !24
  br label %bb11
bb11:
  %t45 = load i64, ptr %l36, !tbaa !24
  store i64 %t45, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb12
bb12:
  %t46 = load i64, ptr %l13, !tbaa !24
  %t47 = load i64, ptr %l12, !tbaa !24
  %t50 = icmp slt i64 %t46, %t47
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb13, label %bb14
bb13:
  br label %bb26
bb14:
  br label %bb15
bb15:
  %t54 = load i64, ptr %l9, !tbaa !24
  %t55 = load i64, ptr %l13, !tbaa !24
  %t56 = load i64, ptr %l11, !tbaa !24
  %t59 = mul i64 %t55, %t56
  %t62 = add i64 %t54, %t59
  store i64 %t62, ptr %l14, !tbaa !24
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load i32, ptr %l7, !tbaa !23
  %t68 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t64, i32 %t65)
  store i1 %t68, ptr %l59
  br label %bb16
bb16:
  %t69 = load i1, ptr %l59, !tbaa !21
  %t70 = xor i1 %t69, true
  br i1 %t70, label %bb17, label %bb18
bb17:
  br label %bb26
bb18:
  br label %bb19
bb19:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullRead(ptr %v0, ptr %v0, ptr %t72, ptr %t73)
  br label %bb20
bb20:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/check:Checker", ptr %t76, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t81 = getelementptr %"compiler/generic:Program", ptr %t79, i32 0, i32 2
  %t82 = load i32, ptr %l7, !tbaa !23
  %t85 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t81, i32 %t82)
  store i64 %t85, ptr %l67
  br label %bb21
bb21:
  %t86 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t87 = load i64, ptr %l67, !tbaa !24
  %t89 = and i64 %t87, %t86
  store i64 %t89, ptr %l8, !tbaa !24
  %t91 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t91, ptr %l70
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/check:Checker", ptr %t92, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t97 = getelementptr %"compiler/generic:Program", ptr %t95, i32 0, i32 2
  %t98 = load i32, ptr %l7, !tbaa !23
  %t101 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t97, i32 %t98)
  store i32 %t101, ptr %l75
  br label %bb22
bb22:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load %"compiler/source:Span", ptr %l1
  %t104 = load ptr, ptr %l6, !tbaa !29
  %t108 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t102, %"compiler/source:Span" %t103, ptr %t104)
  store ptr %t108, ptr %l79
  br label %bb23
bb23:
  store { i64, [4 x i64] } zeroinitializer, ptr %t109
  %t110 = getelementptr { i64, [4 x i64] }, ptr %t109, i32 0, i32 0
  store i64 2, ptr %t110
  %t111 = load %"compiler/source:Span", ptr %l70
  %t112 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t111, 0
  %t113 = load i32, ptr %l75, !tbaa !23
  %t114 = insertvalue { %"compiler/source:Span", i32, ptr } %t112, i32 %t113, 1
  %t115 = load ptr, ptr %l79, !tbaa !29
  %t116 = insertvalue { %"compiler/source:Span", i32, ptr } %t114, ptr %t115, 2
  %t117 = getelementptr { i64, [4 x i64] }, ptr %t109, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t116, ptr %t117
  %t118 = load { i64, [4 x i64] }, ptr %t109
  %t120 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t118, ptr %t120
  store ptr %t120, ptr %l6, !tbaa !29
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/check:Checker", ptr %t122, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !29
  %t127 = getelementptr %"compiler/generic:Program", ptr %t125, i32 0, i32 2
  %t128 = load i32, ptr %l7, !tbaa !23
  %t131 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t127, i32 %t128)
  store i32 %t131, ptr %l86
  br label %bb24
bb24:
  %t132 = load i32, ptr %l86, !tbaa !23
  store i32 %t132, ptr %l7, !tbaa !23
  br label %bb25
bb25:
  %t133 = load i64, ptr %l13, !tbaa !24
  %t135 = add i64 %t133, 1
  store i64 %t135, ptr %l13, !tbaa !24
  br label %bb12
bb26:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load i32, ptr %l7, !tbaa !23
  %t141 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t137, i32 %t138)
  store i32 %t141, ptr %l91
  br label %bb27
bb27:
  %t142 = load i32, ptr %l91, !tbaa !23
  store i32 %t142, ptr %l15, !tbaa !23
  %t143 = load i32, ptr %l15, !tbaa !23
  %t144 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t147 = icmp eq i32 %t143, %t144
  br i1 %t147, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s5
  %t149 = load i32, ptr %l7, !tbaa !23
  %t150 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t153 = icmp eq i32 %t149, %t150
  br i1 %t153, label %bb30, label %bb31
bb29:
  br label %bb110
bb30:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load %"compiler/source:Span", ptr %l1
  %t159 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t155, %"compiler/source:Span" %t156)
  store ptr %t159, ptr %l100
  br label %bb32
bb31:
  br label %bb33
bb32:
  call void @__olang_scope_close(ptr %s5)
  %t160 = load ptr, ptr %l100, !tbaa !29
  store ptr %t160, ptr %rv
  br label %ret
bb33:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load i32, ptr %l7, !tbaa !23
  %t165 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t161, i32 %t162)
  store i1 %t165, ptr %l103
  br label %bb34
bb34:
  %t166 = load i1, ptr %l103, !tbaa !21
  %t167 = xor i1 %t166, true
  br i1 %t167, label %bb35, label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s7
  %t169 = load ptr, ptr %l0, !tbaa !29
  store ptr %t169, ptr %l105, !tbaa !29
  %t170 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t170, ptr %l106
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load i32, ptr %l7, !tbaa !23
  %t175 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s7, ptr %t171, i32 %t172)
  store { i64, ptr } %t175, ptr %l109
  br label %bb37
bb36:
  br label %bb41
bb37:
  %t176 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t177 = extractvalue { i64, ptr } %t176, 0
  %t178 = extractvalue { i64, ptr } %t176, 1
  %t179 = mul i64 %t177, 1
  %t180 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t179)
  call void @llvm.memcpy.p0.p0.i64(ptr %t180, ptr %t178, i64 %t179, i1 false)
  %t181 = insertvalue { i64, ptr } undef, i64 %t177, 0
  %t182 = insertvalue { i64, ptr } %t181, ptr %t180, 1
  %t184 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotIndexable(ptr %s7, ptr %s7, { i64, ptr } %t182)
  store %"compiler/msgs:Msg" %t184, ptr %l111
  br label %bb38
bb38:
  %t185 = load ptr, ptr %l105, !tbaa !29
  %t186 = load %"compiler/source:Span", ptr %l106
  %t187 = load %"compiler/msgs:Msg", ptr %l111
  %t188 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s7, ptr %t185, %"compiler/source:Span" %t186, %"compiler/msgs:Msg" %t187)
  store i64 %t188, ptr %l112
  br label %bb39
bb39:
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t190 = load %"compiler/source:Span", ptr %l1
  %t193 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t189, %"compiler/source:Span" %t190)
  store ptr %t193, ptr %l115
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s5)
  %t194 = load ptr, ptr %l115, !tbaa !29
  store ptr %t194, ptr %rv
  br label %ret
bb41:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t196 = load i32, ptr %l7, !tbaa !23
  %t199 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s5, ptr %t195, i32 %t196, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d17, i32 0, i32 1) }, i64 2)
  store i64 %t199, ptr %l118
  br label %bb42
bb42:
  %t200 = load i64, ptr %l118, !tbaa !24
  store i64 %t200, ptr %l16, !tbaa !24
  %t201 = load i64, ptr %l16, !tbaa !24
  %t203 = icmp slt i64 %t201, 0
  br i1 %t203, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s8
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t206 = load i32, ptr %l7, !tbaa !23
  %t207 = load %"compiler/source:Span", ptr %l1
  %t211 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %s8, ptr %s8, ptr %t205, i32 %t206, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d18, i32 0, i32 1) }, %"compiler/source:Span" %t207, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d19, i32 0, i32 1) }, i64 2, i1 false)
  store i1 %t211, ptr %l124
  br label %bb45
bb44:
  br label %bb53
bb45:
  %t212 = load i1, ptr %l124, !tbaa !21
  %t213 = xor i1 %t212, true
  br i1 %t213, label %bb46, label %bb47
bb46:
  store %olang.scope zeroinitializer, ptr %s9
  %t215 = load ptr, ptr %l0, !tbaa !29
  store ptr %t215, ptr %l126, !tbaa !29
  %t216 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t216, ptr %l127
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t218 = load i32, ptr %l7, !tbaa !23
  %t221 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s9, ptr %t217, i32 %t218)
  store { i64, ptr } %t221, ptr %l130
  br label %bb48
bb47:
  br label %bb51
bb48:
  %t222 = load { i64, ptr }, ptr %l130, !tbaa !27
  %t223 = extractvalue { i64, ptr } %t222, 0
  %t224 = extractvalue { i64, ptr } %t222, 1
  %t225 = mul i64 %t223, 1
  %t226 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t225)
  call void @llvm.memcpy.p0.p0.i64(ptr %t226, ptr %t224, i64 %t225, i1 false)
  %t227 = insertvalue { i64, ptr } undef, i64 %t223, 0
  %t228 = insertvalue { i64, ptr } %t227, ptr %t226, 1
  %t230 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotIndexable(ptr %s9, ptr %s9, { i64, ptr } %t228)
  store %"compiler/msgs:Msg" %t230, ptr %l132
  br label %bb49
bb49:
  %t231 = load ptr, ptr %l126, !tbaa !29
  %t232 = load %"compiler/source:Span", ptr %l127
  %t233 = load %"compiler/msgs:Msg", ptr %l132
  %t234 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s9, ptr %t231, %"compiler/source:Span" %t232, %"compiler/msgs:Msg" %t233)
  store i64 %t234, ptr %l133
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s9)
  br label %bb51
bb51:
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t236 = load %"compiler/source:Span", ptr %l1
  %t239 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t235, %"compiler/source:Span" %t236)
  store ptr %t239, ptr %l136
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s5)
  %t240 = load ptr, ptr %l136, !tbaa !29
  store ptr %t240, ptr %rv
  br label %ret
bb53:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t242 = load i32, ptr %l7, !tbaa !23
  %t245 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s5, ptr %t241, i32 %t242, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d20, i32 0, i32 1) }, i64 0)
  store i64 %t245, ptr %l139
  br label %bb54
bb54:
  %t246 = load i64, ptr %l139, !tbaa !24
  store i64 %t246, ptr %l17, !tbaa !24
  %t247 = load ptr, ptr %l4, !tbaa !29
  %t249 = icmp eq ptr %t247, null
  br i1 %t249, label %bb55, label %bb56
bb55:
  %t251 = load i64, ptr %l17, !tbaa !24
  %t253 = icmp slt i64 %t251, 0
  store i1 %t253, ptr %l142, !tbaa !21
  br label %bb57
bb56:
  store i1 false, ptr %l142, !tbaa !21
  br label %bb57
bb57:
  %t255 = load i1, ptr %l142, !tbaa !21
  br i1 %t255, label %bb58, label %bb59
bb58:
  store %olang.scope zeroinitializer, ptr %s10
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t257 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s10, ptr %t256, %"compiler/source:Span" %t257, { i64, ptr } { i64 47, ptr getelementptr inbounds (<{ i64, [47 x i8] }>, ptr @.d21, i32 0, i32 1) })
  br label %bb60
bb59:
  br label %bb62
bb60:
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t261 = load %"compiler/source:Span", ptr %l1
  %t264 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t260, %"compiler/source:Span" %t261)
  store ptr %t264, ptr %l149
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s5)
  %t265 = load ptr, ptr %l149, !tbaa !29
  store ptr %t265, ptr %rv
  br label %ret
bb62:
  %t266 = load ptr, ptr %l3, !tbaa !29
  %t268 = icmp eq ptr %t266, null
  br i1 %t268, label %bb63, label %bb64
bb63:
  %t270 = load ptr, ptr %l0, !tbaa !29
  store ptr %t270, ptr %l153, !tbaa !29
  %t271 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t271, ptr %l154
  %t272 = load ptr, ptr %l0, !tbaa !29
  %t274 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t272)
  store i32 %t274, ptr %l156
  br label %bb65
bb64:
  %t275 = load ptr, ptr %l0, !tbaa !29
  store ptr %t275, ptr %l158, !tbaa !29
  %t276 = load ptr, ptr %l0, !tbaa !29
  store ptr %t276, ptr %l159, !tbaa !29
  %t277 = load ptr, ptr %l3, !tbaa !29
  store ptr %t277, ptr %l160, !tbaa !29
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t280 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t278)
  store i32 %t280, ptr %l162
  br label %bb67
bb65:
  %t281 = load ptr, ptr %l153, !tbaa !29
  %t282 = load %"compiler/source:Span", ptr %l154
  %t283 = load i32, ptr %l156, !tbaa !23
  %t284 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t281, %"compiler/source:Span" %t282, i32 %t283, i64 0)
  store ptr %t284, ptr %l157
  br label %bb66
bb66:
  %t285 = load ptr, ptr %l157, !tbaa !29
  store ptr %t285, ptr %l152, !tbaa !29
  br label %bb71
bb67:
  %t286 = load ptr, ptr %l159, !tbaa !29
  %t287 = load ptr, ptr %l160, !tbaa !29
  %t288 = load i32, ptr %l162, !tbaa !23
  %t289 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %t286, ptr %t287, i32 %t288)
  store ptr %t289, ptr %l163
  br label %bb68
bb68:
  %t290 = load ptr, ptr %l3, !tbaa !29
  %t292 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t290)
  store %"compiler/source:Span" %t292, ptr %l165
  br label %bb69
bb69:
  %t293 = load ptr, ptr %l158, !tbaa !29
  %t294 = load ptr, ptr %l163, !tbaa !29
  %t295 = load %"compiler/source:Span", ptr %l165
  %t296 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %t293, ptr %t294, %"compiler/source:Span" %t295)
  store ptr %t296, ptr %l166
  br label %bb70
bb70:
  %t297 = load ptr, ptr %l166, !tbaa !29
  store ptr %t297, ptr %l152, !tbaa !29
  br label %bb71
bb71:
  %t298 = load ptr, ptr %l152, !tbaa !29
  store ptr %t298, ptr %l18, !tbaa !29
  store ptr null, ptr %l19, !tbaa !29
  %t299 = load ptr, ptr %l4, !tbaa !29
  %t301 = icmp eq ptr %t299, null
  br i1 %t301, label %bb72, label %bb73
bb72:
  store %olang.scope zeroinitializer, ptr %s11
  %t303 = load ptr, ptr %l0, !tbaa !29
  store ptr %t303, ptr %l169, !tbaa !29
  %t304 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t304, ptr %l170
  %t305 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t305, ptr %l171
  %t306 = load i64, ptr %l17, !tbaa !24
  store i64 %t306, ptr %l172, !tbaa !24
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t308 = load %"compiler/source:Span", ptr %l1
  %t309 = load ptr, ptr %l6, !tbaa !29
  %t313 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t307, %"compiler/source:Span" %t308, ptr %t309)
  store ptr %t313, ptr %l176
  br label %bb74
bb73:
  %t314 = load ptr, ptr %l0, !tbaa !29
  store ptr %t314, ptr %l189, !tbaa !29
  %t315 = load ptr, ptr %l0, !tbaa !29
  store ptr %t315, ptr %l190, !tbaa !29
  %t316 = load ptr, ptr %l4, !tbaa !29
  store ptr %t316, ptr %l191, !tbaa !29
  %t317 = load ptr, ptr %l0, !tbaa !29
  %t319 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t317)
  store i32 %t319, ptr %l193
  br label %bb88
bb74:
  %t320 = load ptr, ptr %l176, !tbaa !29
  store ptr %t320, ptr %l177, !tbaa !29
  %t321 = icmp sge i64 0, 0
  br i1 %t321, label %bb75, label %bb76
bb75:
  %t323 = icmp sle i64 0, 1152921504606846975
  br i1 %t323, label %bb77, label %bb78
bb76:
  call void @__olang_check_failed(ptr @olang_loc_5aa0e1f55b10e6f_53045464d54dc2fb)
  unreachable
bb77:
  %t325 = mul i64 0, 8
  %t326 = insertvalue { i64, ptr } undef, i64 0, 0
  %t327 = insertvalue { i64, ptr } %t326, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t327, ptr %l180, !tbaa !27
  %t328 = icmp sge i64 0, 0
  br i1 %t328, label %bb79, label %bb80
bb78:
  call void @__olang_check_failed(ptr @olang_loc_5aa0e1f55b10e6f_53045464d54dc2fb)
  unreachable
bb79:
  %t330 = icmp sle i64 0, 1152921504606846975
  br i1 %t330, label %bb81, label %bb82
bb80:
  call void @__olang_check_failed(ptr @olang_loc_5aa0e1f55b10e6f_53045464d54dc2fb)
  unreachable
bb81:
  %t332 = mul i64 0, 8
  %t333 = insertvalue { i64, ptr } undef, i64 0, 0
  %t334 = insertvalue { i64, ptr } %t333, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t334, ptr %l183, !tbaa !27
  %t335 = icmp sge i64 0, 0
  br i1 %t335, label %bb83, label %bb84
bb82:
  call void @__olang_check_failed(ptr @olang_loc_5aa0e1f55b10e6f_53045464d54dc2fb)
  unreachable
bb83:
  %t337 = icmp sle i64 0, 2305843009213693951
  br i1 %t337, label %bb85, label %bb86
bb84:
  call void @__olang_check_failed(ptr @olang_loc_e4f33d7277813d9a_8adeed4fca551266)
  unreachable
bb85:
  %t339 = mul i64 0, 4
  %t340 = insertvalue { i64, ptr } undef, i64 0, 0
  %t341 = insertvalue { i64, ptr } %t340, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t342 = load ptr, ptr %l169, !tbaa !29
  %t343 = load %"compiler/source:Span", ptr %l170
  %t344 = load %"compiler/source:Span", ptr %l171
  %t345 = load i64, ptr %l172, !tbaa !24
  %t346 = load ptr, ptr %l177, !tbaa !29
  %t347 = load { i64, ptr }, ptr %l180, !tbaa !27
  %t348 = load { i64, ptr }, ptr %l183, !tbaa !27
  %t350 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %s11, ptr %t342, %"compiler/source:Span" %t343, %"compiler/source:Span" %t344, i64 %t345, ptr %t346, { i64, ptr } %t347, { i64, ptr } %t348, { i64, ptr } %t341)
  store ptr %t350, ptr %l187
  br label %bb87
bb86:
  call void @__olang_check_failed(ptr @olang_loc_e4f33d7277813d9a_8adeed4fca551266)
  unreachable
bb87:
  %t351 = load ptr, ptr %l187, !tbaa !29
  store ptr %t351, ptr %l19, !tbaa !29
  call void @__olang_scope_close(ptr %s11)
  br label %bb92
bb88:
  %t353 = load ptr, ptr %l190, !tbaa !29
  %t354 = load ptr, ptr %l191, !tbaa !29
  %t355 = load i32, ptr %l193, !tbaa !23
  %t356 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v2, ptr %t353, ptr %t354, i32 %t355)
  store ptr %t356, ptr %l194
  br label %bb89
bb89:
  %t357 = load ptr, ptr %l4, !tbaa !29
  %t359 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t357)
  store %"compiler/source:Span" %t359, ptr %l196
  br label %bb90
bb90:
  %t360 = load ptr, ptr %l189, !tbaa !29
  %t361 = load ptr, ptr %l194, !tbaa !29
  %t362 = load %"compiler/source:Span", ptr %l196
  %t363 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %t360, ptr %t361, %"compiler/source:Span" %t362)
  store ptr %t363, ptr %l197
  br label %bb91
bb91:
  %t364 = load ptr, ptr %l197, !tbaa !29
  store ptr %t364, ptr %l19, !tbaa !29
  br label %bb92
bb92:
  %t366 = load ptr, ptr %l0, !tbaa !29
  %t368 = getelementptr %"compiler/check:Checker", ptr %t366, i32 0, i32 36
  %t370 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t368)
  store i64 %t370, ptr %l201
  br label %bb93
bb93:
  %t371 = load i64, ptr %l201, !tbaa !24
  store i64 %t371, ptr %l20, !tbaa !24
  %t372 = load ptr, ptr %l0, !tbaa !29
  %t374 = getelementptr %"compiler/check:Checker", ptr %t372, i32 0, i32 36
  %t375 = load ptr, ptr %l18, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t374, ptr %t375)
  br label %bb94
bb94:
  %t378 = load ptr, ptr %l0, !tbaa !29
  %t380 = getelementptr %"compiler/check:Checker", ptr %t378, i32 0, i32 36
  store ptr %t380, ptr %l206, !tbaa !29
  %t381 = load ptr, ptr %l19, !tbaa !29
  %t383 = icmp eq ptr %t381, null
  br i1 %t383, label %bb95, label %bb96
bb95:
  call void @__olang_check_failed(ptr @olang_loc_b203c9fbf4c249fb_735051f472c86bf)
  unreachable
bb96:
  br label %bb97
bb97:
  %t385 = load ptr, ptr %l19, !tbaa !29
  %t386 = load ptr, ptr %l206, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t386, ptr %t385)
  br label %bb98
bb98:
  %t388 = load ptr, ptr %l0, !tbaa !29
  store ptr %t388, ptr %l210, !tbaa !29
  %t389 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t389, ptr %l211
  %t390 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t390, ptr %l212
  %t391 = load i64, ptr %l16, !tbaa !24
  store i64 %t391, ptr %l213, !tbaa !24
  %t392 = load ptr, ptr %l0, !tbaa !29
  %t393 = load %"compiler/source:Span", ptr %l1
  %t394 = load ptr, ptr %l6, !tbaa !29
  %t398 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t392, %"compiler/source:Span" %t393, ptr %t394)
  store ptr %t398, ptr %l217
  br label %bb99
bb99:
  %t399 = load ptr, ptr %l217, !tbaa !29
  store ptr %t399, ptr %l218, !tbaa !29
  %t400 = icmp sge i64 0, 0
  br i1 %t400, label %bb100, label %bb101
bb100:
  %t402 = icmp sle i64 0, 1152921504606846975
  br i1 %t402, label %bb102, label %bb103
bb101:
  call void @__olang_check_failed(ptr @olang_loc_85a2f2931038d80c_e5a946dd8e187d18)
  unreachable
bb102:
  %t404 = mul i64 0, 8
  %t405 = insertvalue { i64, ptr } undef, i64 0, 0
  %t406 = insertvalue { i64, ptr } %t405, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t406, ptr %l221, !tbaa !27
  %t407 = load ptr, ptr %l0, !tbaa !29
  %t409 = getelementptr %"compiler/check:Checker", ptr %t407, i32 0, i32 36
  %t410 = load i64, ptr %l20, !tbaa !24
  %t413 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t409, i64 %t410)
  store { i64, ptr } %t413, ptr %l225
  br label %bb104
bb103:
  call void @__olang_check_failed(ptr @olang_loc_85a2f2931038d80c_e5a946dd8e187d18)
  unreachable
bb104:
  %t414 = icmp sge i64 0, 0
  br i1 %t414, label %bb105, label %bb106
bb105:
  %t416 = icmp sle i64 0, 2305843009213693951
  br i1 %t416, label %bb107, label %bb108
bb106:
  call void @__olang_check_failed(ptr @olang_loc_e4f33d7277813d9a_8adeed4fca551266)
  unreachable
bb107:
  %t418 = mul i64 0, 4
  %t419 = insertvalue { i64, ptr } undef, i64 0, 0
  %t420 = insertvalue { i64, ptr } %t419, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t421 = load ptr, ptr %l210, !tbaa !29
  %t422 = load %"compiler/source:Span", ptr %l211
  %t423 = load %"compiler/source:Span", ptr %l212
  %t424 = load i64, ptr %l213, !tbaa !24
  %t425 = load ptr, ptr %l218, !tbaa !29
  %t426 = load { i64, ptr }, ptr %l221, !tbaa !27
  %t427 = load { i64, ptr }, ptr %l225, !tbaa !27
  %t429 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %s5, ptr %t421, %"compiler/source:Span" %t422, %"compiler/source:Span" %t423, i64 %t424, ptr %t425, { i64, ptr } %t426, { i64, ptr } %t427, { i64, ptr } %t420)
  store ptr %t429, ptr %l229
  br label %bb109
bb108:
  call void @__olang_check_failed(ptr @olang_loc_e4f33d7277813d9a_8adeed4fca551266)
  unreachable
bb109:
  call void @__olang_scope_close(ptr %s5)
  %t430 = load ptr, ptr %l229, !tbaa !29
  store ptr %t430, ptr %rv
  br label %ret
bb110:
  store ptr null, ptr %l21, !tbaa !29
  %t431 = load ptr, ptr %l3, !tbaa !29
  %t433 = icmp eq ptr %t431, null
  br i1 %t433, label %bb111, label %bb112
bb111:
  %t435 = load ptr, ptr %l0, !tbaa !29
  store ptr %t435, ptr %l232, !tbaa !29
  %t436 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t436, ptr %l233
  %t437 = load ptr, ptr %l0, !tbaa !29
  %t439 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t437)
  store i32 %t439, ptr %l235
  br label %bb113
bb112:
  %t440 = load ptr, ptr %l0, !tbaa !29
  store ptr %t440, ptr %l238, !tbaa !29
  %t441 = load ptr, ptr %l3, !tbaa !29
  store ptr %t441, ptr %l239, !tbaa !29
  %t442 = load ptr, ptr %l0, !tbaa !29
  %t444 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t442)
  store i32 %t444, ptr %l241
  br label %bb115
bb113:
  %t445 = load ptr, ptr %l232, !tbaa !29
  %t446 = load %"compiler/source:Span", ptr %l233
  %t447 = load i32, ptr %l235, !tbaa !23
  %t448 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t445, %"compiler/source:Span" %t446, i32 %t447, i64 0)
  store ptr %t448, ptr %l236
  br label %bb114
bb114:
  %t449 = load ptr, ptr %l236, !tbaa !29
  store ptr %t449, ptr %l21, !tbaa !29
  br label %bb117
bb115:
  %t451 = load ptr, ptr %l238, !tbaa !29
  %t452 = load ptr, ptr %l239, !tbaa !29
  %t453 = load i32, ptr %l241, !tbaa !23
  %t454 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %t451, ptr %t452, i32 %t453)
  store ptr %t454, ptr %l242
  br label %bb116
bb116:
  %t455 = load ptr, ptr %l242, !tbaa !29
  store ptr %t455, ptr %l21, !tbaa !29
  br label %bb117
bb117:
  store ptr null, ptr %l22, !tbaa !29
  %t457 = load ptr, ptr %l4, !tbaa !29
  %t459 = icmp eq ptr %t457, null
  br i1 %t459, label %bb118, label %bb119
bb118:
  %t461 = load ptr, ptr %l0, !tbaa !29
  store ptr %t461, ptr %l246, !tbaa !29
  %t462 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t462, ptr %l247
  %t463 = load ptr, ptr %l0, !tbaa !29
  %t465 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t463)
  store i32 %t465, ptr %l249
  br label %bb120
bb119:
  %t466 = load ptr, ptr %l0, !tbaa !29
  store ptr %t466, ptr %l263, !tbaa !29
  %t467 = load ptr, ptr %l4, !tbaa !29
  store ptr %t467, ptr %l264, !tbaa !29
  %t468 = load ptr, ptr %l0, !tbaa !29
  %t470 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t468)
  store i32 %t470, ptr %l266
  br label %bb123
bb120:
  store i32 22, ptr %l250
  %t471 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t471, ptr %l251
  %t472 = load ptr, ptr %l0, !tbaa !29
  %t474 = getelementptr %"compiler/check:Checker", ptr %t472, i32 0, i32 1
  %t475 = load ptr, ptr %t474, !tbaa !29
  %t477 = getelementptr %"compiler/generic:Program", ptr %t475, i32 0, i32 2
  %t478 = load i32, ptr %l7, !tbaa !23
  %t479 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t483 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t477, i32 %t478, i64 %t479)
  store i32 %t483, ptr %l257
  br label %bb121
bb121:
  %t484 = load ptr, ptr %l6, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t485
  %t486 = getelementptr { i64, [5 x i64] }, ptr %t485, i32 0, i32 0
  store i64 3, ptr %t486
  %t487 = load %"compiler/source:Span", ptr %l251
  %t488 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t487, 0
  %t489 = load i32, ptr %l257, !tbaa !23
  %t490 = insertvalue { %"compiler/source:Span", i32, ptr } %t488, i32 %t489, 1
  %t492 = insertvalue { %"compiler/source:Span", i32, ptr } %t490, ptr %t484, 2
  %t493 = getelementptr { i64, [5 x i64] }, ptr %t485, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t492, ptr %t493
  %t494 = load { i64, [5 x i64] }, ptr %t485
  %t496 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t494, ptr %t496
  %t497 = load ptr, ptr %l246, !tbaa !29
  %t498 = load %"compiler/source:Span", ptr %l247
  %t499 = load i32, ptr %l249, !tbaa !23
  %t500 = load i32, ptr %l250, !range !{i32 0, i32 43}
  %t502 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t497, %"compiler/source:Span" %t498, i32 %t499, i32 %t500, ptr %t496, ptr null)
  store ptr %t502, ptr %l261
  br label %bb122
bb122:
  %t503 = load ptr, ptr %l261, !tbaa !29
  store ptr %t503, ptr %l22, !tbaa !29
  br label %bb125
bb123:
  %t505 = load ptr, ptr %l263, !tbaa !29
  %t506 = load ptr, ptr %l264, !tbaa !29
  %t507 = load i32, ptr %l266, !tbaa !23
  %t508 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v2, ptr %t505, ptr %t506, i32 %t507)
  store ptr %t508, ptr %l267
  br label %bb124
bb124:
  %t509 = load ptr, ptr %l267, !tbaa !29
  store ptr %t509, ptr %l22, !tbaa !29
  br label %bb125
bb125:
  %t511 = load ptr, ptr %l0, !tbaa !29
  %t512 = load i32, ptr %l7, !tbaa !23
  %t515 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t511, i32 %t512)
  store i1 %t515, ptr %l271
  br label %bb126
bb126:
  %t516 = load i1, ptr %l271, !tbaa !21
  br i1 %t516, label %bb127, label %bb128
bb127:
  %t517 = load i32, ptr %l7, !tbaa !23
  store i32 %t517, ptr %l272, !tbaa !23
  br label %bb135
bb128:
  %t519 = load ptr, ptr %l0, !tbaa !29
  %t521 = getelementptr %"compiler/check:Checker", ptr %t519, i32 0, i32 1
  %t522 = load ptr, ptr %t521, !tbaa !29
  %t524 = getelementptr %"compiler/generic:Program", ptr %t522, i32 0, i32 2
  store ptr %t524, ptr %l276, !tbaa !29
  %t525 = load ptr, ptr %l0, !tbaa !29
  %t527 = getelementptr %"compiler/check:Checker", ptr %t525, i32 0, i32 1
  %t528 = load ptr, ptr %t527, !tbaa !29
  %t530 = getelementptr %"compiler/generic:Program", ptr %t528, i32 0, i32 2
  %t531 = load i32, ptr %l15, !tbaa !23
  %t534 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t530, i32 %t531)
  store i32 %t534, ptr %l281
  br label %bb129
bb129:
  %t535 = load i32, ptr %l5, !range !{i32 0, i32 3}
  %t537 = trunc i64 1 to i32
  %t538 = icmp eq i32 %t535, %t537
  br i1 %t538, label %bb130, label %bb131
bb130:
  %t540 = load ptr, ptr %l0, !tbaa !29
  %t541 = load i32, ptr %l15, !tbaa !23
  %t542 = load ptr, ptr %l3, !tbaa !29
  %t543 = load ptr, ptr %l4, !tbaa !29
  %t548 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esliceLength(ptr %v0, ptr %v1, ptr %v2, ptr %t540, i32 %t541, ptr %t542, ptr %t543)
  store i32 %t548, ptr %l289
  br label %bb132
bb131:
  store i32 0, ptr %l284, !tbaa !23
  br label %bb133
bb132:
  %t549 = load i32, ptr %l289, !tbaa !23
  store i32 %t549, ptr %l284, !tbaa !23
  br label %bb133
bb133:
  %t550 = load ptr, ptr %l276, !tbaa !29
  %t551 = load i32, ptr %l281, !tbaa !23
  %t552 = load i32, ptr %l284, !tbaa !23
  %t553 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t550, i32 %t551, i32 %t552)
  store i32 %t553, ptr %l290
  br label %bb134
bb134:
  %t554 = load i32, ptr %l290, !tbaa !23
  store i32 %t554, ptr %l272, !tbaa !23
  br label %bb135
bb135:
  %t555 = load i32, ptr %l272, !tbaa !23
  %t556 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t556, ptr %l291
  %t557 = load ptr, ptr %l0, !tbaa !29
  %t559 = getelementptr %"compiler/check:Checker", ptr %t557, i32 0, i32 1
  %t560 = load ptr, ptr %t559, !tbaa !29
  %t562 = getelementptr %"compiler/generic:Program", ptr %t560, i32 0, i32 2
  %t564 = load i64, ptr %l8, !tbaa !24
  %t568 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t562, i32 %t555, i64 %t564)
  store i32 %t568, ptr %l297
  br label %bb136
bb136:
  %t569 = load ptr, ptr %l6, !tbaa !29
  store ptr %t569, ptr %l298, !tbaa !29
  %t570 = load ptr, ptr %l21, !tbaa !29
  %t572 = icmp eq ptr %t570, null
  br i1 %t572, label %bb137, label %bb138
bb137:
  call void @__olang_check_failed(ptr @olang_loc_2f1aad6b95023edd_c82f5ce971f0d619)
  unreachable
bb138:
  br label %bb139
bb139:
  %t574 = load ptr, ptr %l21, !tbaa !29
  store ptr %t574, ptr %l301, !tbaa !29
  %t575 = load ptr, ptr %l22, !tbaa !29
  %t577 = icmp eq ptr %t575, null
  br i1 %t577, label %bb140, label %bb141
bb140:
  call void @__olang_check_failed(ptr @olang_loc_2f1aad6b95023edd_c82f5ce971f0d619)
  unreachable
bb141:
  br label %bb142
bb142:
  %t579 = load ptr, ptr %l22, !tbaa !29
  %t580 = load i32, ptr %l5, !range !{i32 0, i32 3}
  %t581 = load ptr, ptr %l298, !tbaa !29
  %t582 = load ptr, ptr %l301, !tbaa !29
  %t585 = call %"compiler/typed:Slice" @compiler_2ftyped_3aSlice_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t581, ptr %t582, ptr %t579, i32 %t580)
  store %"compiler/typed:Slice" %t585, ptr %l306
  br label %bb143
bb143:
  %t586 = load %"compiler/typed:Slice", ptr %l306
  %t587 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/typed:Slice" %t586, ptr %t587
  store { i64, [5 x i64] } zeroinitializer, ptr %t588
  %t589 = getelementptr { i64, [5 x i64] }, ptr %t588, i32 0, i32 0
  store i64 10, ptr %t589
  %t590 = load %"compiler/source:Span", ptr %l291
  %t591 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t590, 0
  %t592 = load i32, ptr %l297, !tbaa !23
  %t593 = insertvalue { %"compiler/source:Span", i32, ptr } %t591, i32 %t592, 1
  %t595 = insertvalue { %"compiler/source:Span", i32, ptr } %t593, ptr %t587, 2
  %t596 = getelementptr { i64, [5 x i64] }, ptr %t588, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t595, ptr %t596
  %t597 = load { i64, [5 x i64] }, ptr %t588
  %t599 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t597, ptr %t599
  store ptr %t599, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l9 = alloca ptr
  %l12 = alloca ptr
  %l22 = alloca i1
  %l28 = alloca i1
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l35 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 5
  store ptr %t9, ptr %l7, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t10)
  store ptr %t12, ptr %l9
  br label %bb1
bb1:
  %t13 = load ptr, ptr %l9, !tbaa !29
  %t15 = getelementptr %"compiler/check:frame", ptr %t13, i32 0, i32 1
  %t16 = load i64, ptr %t15, !tbaa !24
  %t17 = load ptr, ptr %l7, !tbaa !29
  %t19 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t17, i64 %t16)
  store ptr %t19, ptr %l12
  br label %bb2
bb2:
  %t20 = load ptr, ptr %l12, !tbaa !29
  %t22 = getelementptr %"compiler/load:Module", ptr %t20, i32 0, i32 6
  %t23 = load ptr, ptr %t22, !tbaa !29
  store ptr %t23, ptr %l2, !tbaa !29
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t27 = icmp eq ptr %t25, null
  br i1 %t27, label %bb3, label %bb4
bb3:
  call void @__olang_check_failed(ptr @olang_loc_7151da8c7014d0c8_6aa5246f01d956ac)
  unreachable
bb4:
  br label %bb5
bb5:
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t32 = getelementptr %"compiler/source:Source", ptr %t29, i32 0, i32 1
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } %t33, ptr %l3, !tbaa !27
  %t35 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t36 = load i32, ptr %t35, !tbaa !23
  %t38 = icmp slt i32 %t36, 0
  br i1 %t38, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb8
bb7:
  %t40 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t41 = load i32, ptr %t40, !tbaa !23
  %t42 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t46 = trunc i64 %t44 to i32
  %t49 = icmp sgt i32 %t41, %t46
  store i1 %t49, ptr %l22, !tbaa !21
  br label %bb8
bb8:
  %t51 = load i1, ptr %l22, !tbaa !21
  br i1 %t51, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb11
bb10:
  %t52 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t53 = load i32, ptr %t52, !tbaa !23
  %t54 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t55 = load i32, ptr %t54, !tbaa !23
  %t58 = icmp sgt i32 %t53, %t55
  store i1 %t58, ptr %l28, !tbaa !21
  br label %bb11
bb11:
  %t60 = load i1, ptr %l28, !tbaa !21
  br i1 %t60, label %bb12, label %bb13
bb12:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d22, i32 0, i32 1) }, ptr %l32, !tbaa !27
  %t61 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t61, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t62 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t62, ptr %l33, !tbaa !27
  %t63 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t64 = load i32, ptr %t63, !tbaa !23
  %t66 = sext i32 %t64 to i64
  store i64 %t66, ptr %l35, !tbaa !24
  %t67 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t68 = load i32, ptr %t67, !tbaa !23
  %t70 = sext i32 %t68 to i64
  store i64 %t70, ptr %l37, !tbaa !24
  %t71 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t71, 0
  store i64 %t72, ptr %l38, !tbaa !24
  %t73 = load i64, ptr %l35, !tbaa !24
  %t74 = icmp sge i64 %t73, 0
  br i1 %t74, label %bb15, label %bb16
bb15:
  %t76 = load i64, ptr %l35, !tbaa !24
  %t77 = load i64, ptr %l37, !tbaa !24
  %t78 = icmp sle i64 %t76, %t77
  br i1 %t78, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_16d25af731eb828d_f9df92790de43871)
  unreachable
bb17:
  %t80 = load i64, ptr %l37, !tbaa !24
  %t81 = load i64, ptr %l38, !tbaa !24
  %t82 = icmp sle i64 %t80, %t81
  br i1 %t82, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_16d25af731eb828d_f9df92790de43871)
  unreachable
bb19:
  %t84 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !27
  %t86 = load i64, ptr %l35, !tbaa !24
  %t87 = load i64, ptr %l37, !tbaa !24
  %t88 = getelementptr i8, ptr %t85, i64 %t86
  %t89 = sub i64 %t87, %t86
  %t90 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t88, 1
  store { i64, ptr } %t91, ptr %rv
  br label %ret
bb20:
  call void @__olang_check_failed(ptr @olang_loc_16d25af731eb828d_f9df92790de43871)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca ptr
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca %"compiler/source:Span"
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca %"compiler/source:Span"
  %l16 = alloca ptr
  %l17 = alloca %"compiler/source:Span"
  %l18 = alloca { i64, ptr }
  %l19 = alloca %"compiler/source:Span"
  %l20 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l22 = alloca %"compiler/source:Span"
  %l23 = alloca ptr
  %l24 = alloca %"compiler/source:Span"
  %l25 = alloca ptr
  %l26 = alloca %"compiler/source:Span"
  %l27 = alloca { i64, ptr }
  %l28 = alloca ptr
  %l29 = alloca %"compiler/source:Span"
  %l30 = alloca { i64, ptr }
  %l31 = alloca %"compiler/source:Span"
  %l32 = alloca ptr
  %l33 = alloca %"compiler/source:Span"
  %l34 = alloca ptr
  %l35 = alloca %"compiler/source:Span"
  %l36 = alloca ptr
  %l37 = alloca %"compiler/source:Span"
  %l38 = alloca i32
  %l39 = alloca ptr
  %l40 = alloca %"compiler/source:Span"
  %l41 = alloca ptr
  %l42 = alloca %"compiler/source:Span"
  %l43 = alloca ptr
  %l44 = alloca ptr
  %l45 = alloca i64
  %l46 = alloca ptr
  %l48 = alloca ptr
  %l49 = alloca i64
  %l50 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l51 = alloca ptr
  %l52 = alloca i64
  %l54 = alloca i64
  %l55 = alloca { i64, ptr }
  %l56 = alloca i1
  %l57 = alloca { i64, ptr }
  %l58 = alloca ptr
  %l59 = alloca i64
  %l61 = alloca { { i64, [3 x i64] }, { i64, ptr } }
  %l62 = alloca { i64, [3 x i64] }
  %l63 = alloca { i64, ptr }
  %l64 = alloca i1
  %l65 = alloca %"compiler/source:Span"
  %l66 = alloca ptr
  %l67 = alloca %"compiler/source:Span"
  %l68 = alloca ptr
  %l69 = alloca i1
  %l70 = alloca %"compiler/source:Span"
  %l71 = alloca { i64, ptr }
  %l72 = alloca %"compiler/source:Span"
  %l73 = alloca ptr
  %l74 = alloca %"compiler/source:Span"
  %l75 = alloca { i64, ptr }
  %l76 = alloca ptr
  %l79 = alloca ptr
  %l80 = alloca i1
  %l90 = alloca ptr
  %l91 = alloca i1
  %l101 = alloca ptr
  %l102 = alloca i1
  %l112 = alloca ptr
  %l113 = alloca i1
  %l129 = alloca ptr
  %l130 = alloca i1
  %l143 = alloca ptr
  %l144 = alloca i1
  %l154 = alloca ptr
  %l155 = alloca i1
  %l165 = alloca ptr
  %l166 = alloca i1
  %l180 = alloca ptr
  %l181 = alloca i1
  %l191 = alloca ptr
  %l192 = alloca i1
  %l202 = alloca ptr
  %l203 = alloca i1
  %l216 = alloca ptr
  %l217 = alloca i1
  %l227 = alloca ptr
  %l228 = alloca i1
  %l238 = alloca ptr
  %l239 = alloca i1
  %l249 = alloca ptr
  %l250 = alloca i1
  %l260 = alloca ptr
  %l261 = alloca i1
  %l274 = alloca ptr
  %l275 = alloca i1
  %l283 = alloca ptr
  %l290 = alloca ptr
  %l291 = alloca i1
  %l303 = alloca i64
  %l308 = alloca ptr
  %l311 = alloca ptr
  %l313 = alloca %"compiler/source:Span"
  %l319 = alloca ptr
  %l326 = alloca ptr
  %l327 = alloca ptr
  %l329 = alloca ptr
  %l333 = alloca ptr
  %l336 = alloca i1
  %l340 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l348 = alloca i64
  %l352 = alloca i64
  %l354 = alloca i64
  %l359 = alloca i64
  %l364 = alloca { i64, ptr }
  %l365 = alloca { i64, ptr }
  %l366 = alloca i64
  %l367 = alloca { i64, ptr }
  %l368 = alloca { i64, ptr }
  %l369 = alloca { i64, ptr }
  %l370 = alloca i64
  %l371 = alloca { i64, ptr }
  %l374 = alloca i1
  %l377 = alloca i1
  %l381 = alloca { i64, ptr }
  %l384 = alloca { i64, ptr }
  %l385 = alloca i32
  %l387 = alloca i1
  %l388 = alloca { i64, ptr }
  %l391 = alloca i64
  %l396 = alloca ptr
  %l398 = alloca i64
  %l399 = alloca ptr
  %l402 = alloca ptr
  %l404 = alloca i32
  %l406 = alloca i32
  %l407 = alloca i64
  %l411 = alloca i64
  %l413 = alloca i64
  %l418 = alloca i64
  %l423 = alloca ptr
  %l425 = alloca %"compiler/source:Span"
  %l426 = alloca { i64, ptr }
  %l427 = alloca { i64, ptr }
  %l429 = alloca i64
  %l431 = alloca i64
  %l432 = alloca { i64, ptr }
  %l435 = alloca i1
  %l442 = alloca { { i64, [3 x i64] }, { i64, ptr } }
  %l444 = alloca { i64, ptr }
  %l445 = alloca i64
  %l446 = alloca { i64, ptr }
  %l453 = alloca ptr
  %l456 = alloca i1
  %l460 = alloca i1
  %l462 = alloca i1
  %l465 = alloca i1
  %l467 = alloca i1
  %l471 = alloca i1
  %l474 = alloca { i64, ptr }
  %l475 = alloca { i64, ptr }
  %l477 = alloca i64
  %l479 = alloca i64
  %l480 = alloca { i64, ptr }
  %l482 = alloca ptr
  %l484 = alloca i64
  %l486 = alloca i64
  %l487 = alloca %"compiler/source:Span"
  %l490 = alloca %"compiler/source:Span"
  %l491 = alloca i64
  %l492 = alloca i64
  %l494 = alloca { i64, ptr }
  %l506 = alloca %"compiler/check:AssertAsk"
  %l507 = alloca ptr
  %l508 = alloca i1
  %l518 = alloca ptr
  %l519 = alloca i1
  %l532 = alloca ptr
  %l533 = alloca i1
  %l540 = alloca ptr
  %l541 = alloca %"compiler/source:Span"
  %l546 = alloca ptr
  %l549 = alloca ptr
  %l550 = alloca i1
  %l560 = alloca ptr
  %l561 = alloca i1
  %l574 = alloca ptr
  %l576 = alloca %"compiler/source:Span"
  %s21 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s42 = alloca %olang.scope
  %t575 = alloca { i64, [5 x i64] }, align 8
  %t598 = alloca { i64, [3 x i64] }, align 8
  %t1055 = alloca %"compiler/check:AssertAsk", align 8
  %t1069 = alloca %"compiler/check:AssertAsk", align 8
  %t1163 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l79, !tbaa !29
  store i1 false, ptr %l80, !tbaa !21
  %t6 = load ptr, ptr %l79, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l79, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 22}
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l80, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l80, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [4 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", ptr }, ptr %t16, i32 0, i32 0
  %t18 = load %"compiler/source:Span", ptr %t17
  store %"compiler/source:Span" %t18, ptr %l2
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr { i64, [4 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", ptr }, ptr %t22, i32 0, i32 1
  %t24 = load ptr, ptr %t23
  store ptr %t24, ptr %l3, !tbaa !29
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load %"compiler/source:Span", ptr %l2
  %t28 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprStmt(ptr %v0, ptr %v1, ptr %t26, %"compiler/source:Span" %t27, ptr %t28)
  br label %bb9
bb9:
  br label %bb276
bb10:
  %t32 = load ptr, ptr %l1, !tbaa !29
  store ptr %t32, ptr %l90, !tbaa !29
  store i1 false, ptr %l91, !tbaa !21
  %t33 = load ptr, ptr %l90, !tbaa !29
  %t34 = icmp ne ptr %t33, null
  br i1 %t34, label %bb11, label %bb12
bb11:
  %t36 = load ptr, ptr %l90, !tbaa !29
  %t37 = load i64, ptr %t36, !range !{i64 0, i64 22}
  %t39 = icmp eq i64 %t37, 1
  store i1 %t39, ptr %l91, !tbaa !21
  br label %bb12
bb12:
  %t40 = load i1, ptr %l91, !tbaa !21
  br i1 %t40, label %bb13, label %bb14
bb13:
  %t41 = load ptr, ptr %l1, !tbaa !29
  %t43 = getelementptr { i64, [4 x i64] }, ptr %t41, i32 0, i32 1
  %t44 = getelementptr { %"compiler/source:Span", ptr }, ptr %t43, i32 0, i32 0
  %t45 = load %"compiler/source:Span", ptr %t44
  store %"compiler/source:Span" %t45, ptr %l4
  %t47 = load ptr, ptr %l1, !tbaa !29
  %t49 = getelementptr { i64, [4 x i64] }, ptr %t47, i32 0, i32 1
  %t50 = getelementptr { %"compiler/source:Span", ptr }, ptr %t49, i32 0, i32 1
  %t51 = load ptr, ptr %t50
  store ptr %t51, ptr %l5, !tbaa !29
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load %"compiler/source:Span", ptr %l4
  %t55 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evarDecl(ptr %v0, ptr %v1, ptr %t53, %"compiler/source:Span" %t54, ptr %t55)
  br label %bb16
bb16:
  br label %bb276
bb17:
  %t59 = load ptr, ptr %l1, !tbaa !29
  store ptr %t59, ptr %l101, !tbaa !29
  store i1 false, ptr %l102, !tbaa !21
  %t60 = load ptr, ptr %l101, !tbaa !29
  %t61 = icmp ne ptr %t60, null
  br i1 %t61, label %bb18, label %bb19
bb18:
  %t63 = load ptr, ptr %l101, !tbaa !29
  %t64 = load i64, ptr %t63, !range !{i64 0, i64 22}
  %t66 = icmp eq i64 %t64, 2
  store i1 %t66, ptr %l102, !tbaa !21
  br label %bb19
bb19:
  %t67 = load i1, ptr %l102, !tbaa !21
  br i1 %t67, label %bb20, label %bb21
bb20:
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t70 = getelementptr { i64, [4 x i64] }, ptr %t68, i32 0, i32 1
  %t71 = getelementptr { %"compiler/source:Span", ptr }, ptr %t70, i32 0, i32 0
  %t72 = load %"compiler/source:Span", ptr %t71
  store %"compiler/source:Span" %t72, ptr %l6
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr { i64, [4 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", ptr }, ptr %t76, i32 0, i32 1
  %t78 = load ptr, ptr %t77
  store ptr %t78, ptr %l7, !tbaa !29
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load %"compiler/source:Span", ptr %l6
  %t82 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emulti(ptr %v0, ptr %v1, ptr %t80, %"compiler/source:Span" %t81, ptr %t82)
  br label %bb23
bb23:
  br label %bb276
bb24:
  %t86 = load ptr, ptr %l1, !tbaa !29
  store ptr %t86, ptr %l112, !tbaa !29
  store i1 false, ptr %l113, !tbaa !21
  %t87 = load ptr, ptr %l112, !tbaa !29
  %t88 = icmp ne ptr %t87, null
  br i1 %t88, label %bb25, label %bb26
bb25:
  %t90 = load ptr, ptr %l112, !tbaa !29
  %t91 = load i64, ptr %t90, !range !{i64 0, i64 22}
  %t93 = icmp eq i64 %t91, 3
  store i1 %t93, ptr %l113, !tbaa !21
  br label %bb26
bb26:
  %t94 = load i1, ptr %l113, !tbaa !21
  br i1 %t94, label %bb27, label %bb28
bb27:
  %t95 = load ptr, ptr %l1, !tbaa !29
  %t97 = getelementptr { i64, [4 x i64] }, ptr %t95, i32 0, i32 1
  %t98 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t97, i32 0, i32 0
  %t99 = load %"compiler/source:Span", ptr %t98
  store %"compiler/source:Span" %t99, ptr %l8
  %t101 = load ptr, ptr %l1, !tbaa !29
  %t103 = getelementptr { i64, [4 x i64] }, ptr %t101, i32 0, i32 1
  %t104 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t103, i32 0, i32 1
  %t105 = load i32, ptr %t104, !range !{i32 0, i32 96}
  store i32 %t105, ptr %l9
  %t107 = load ptr, ptr %l1, !tbaa !29
  %t109 = getelementptr { i64, [4 x i64] }, ptr %t107, i32 0, i32 1
  %t110 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t109, i32 0, i32 2
  %t111 = load ptr, ptr %t110
  store ptr %t111, ptr %l10, !tbaa !29
  %t113 = load ptr, ptr %l1, !tbaa !29
  %t115 = getelementptr { i64, [4 x i64] }, ptr %t113, i32 0, i32 1
  %t116 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t115, i32 0, i32 3
  %t117 = load ptr, ptr %t116
  store ptr %t117, ptr %l11, !tbaa !29
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t120 = load %"compiler/source:Span", ptr %l8
  %t121 = load i32, ptr %l9, !range !{i32 0, i32 96}
  %t122 = load ptr, ptr %l10, !tbaa !29
  %t123 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eassign(ptr %v0, ptr %v1, ptr %v1, ptr %t119, %"compiler/source:Span" %t120, i32 %t121, ptr %t122, ptr %t123)
  br label %bb30
bb30:
  br label %bb276
bb31:
  %t129 = load ptr, ptr %l1, !tbaa !29
  store ptr %t129, ptr %l129, !tbaa !29
  store i1 false, ptr %l130, !tbaa !21
  %t130 = load ptr, ptr %l129, !tbaa !29
  %t131 = icmp ne ptr %t130, null
  br i1 %t131, label %bb32, label %bb33
bb32:
  %t133 = load ptr, ptr %l129, !tbaa !29
  %t134 = load i64, ptr %t133, !range !{i64 0, i64 22}
  %t136 = icmp eq i64 %t134, 4
  store i1 %t136, ptr %l130, !tbaa !21
  br label %bb33
bb33:
  %t137 = load i1, ptr %l130, !tbaa !21
  br i1 %t137, label %bb34, label %bb35
bb34:
  %t138 = load ptr, ptr %l1, !tbaa !29
  %t140 = getelementptr { i64, [4 x i64] }, ptr %t138, i32 0, i32 1
  %t141 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t140, i32 0, i32 0
  %t142 = load %"compiler/source:Span", ptr %t141
  store %"compiler/source:Span" %t142, ptr %l12
  %t144 = load ptr, ptr %l1, !tbaa !29
  %t146 = getelementptr { i64, [4 x i64] }, ptr %t144, i32 0, i32 1
  %t147 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t146, i32 0, i32 1
  %t148 = load ptr, ptr %t147
  store ptr %t148, ptr %l13, !tbaa !29
  %t150 = load ptr, ptr %l1, !tbaa !29
  %t152 = getelementptr { i64, [4 x i64] }, ptr %t150, i32 0, i32 1
  %t153 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t152, i32 0, i32 2
  %t154 = load { i64, ptr }, ptr %t153
  store { i64, ptr } %t154, ptr %l14, !tbaa !27
  br label %bb36
bb35:
  br label %bb38
bb36:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load %"compiler/source:Span", ptr %l12
  %t158 = load ptr, ptr %l13, !tbaa !29
  %t159 = load { i64, ptr }, ptr %l14, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etryStore(ptr %v0, ptr %v1, ptr %v1, ptr %t156, %"compiler/source:Span" %t157, ptr %t158, { i64, ptr } %t159)
  br label %bb37
bb37:
  br label %bb276
bb38:
  %t164 = load ptr, ptr %l1, !tbaa !29
  store ptr %t164, ptr %l143, !tbaa !29
  store i1 false, ptr %l144, !tbaa !21
  %t165 = load ptr, ptr %l143, !tbaa !29
  %t166 = icmp ne ptr %t165, null
  br i1 %t166, label %bb39, label %bb40
bb39:
  %t168 = load ptr, ptr %l143, !tbaa !29
  %t169 = load i64, ptr %t168, !range !{i64 0, i64 22}
  %t171 = icmp eq i64 %t169, 5
  store i1 %t171, ptr %l144, !tbaa !21
  br label %bb40
bb40:
  %t172 = load i1, ptr %l144, !tbaa !21
  br i1 %t172, label %bb41, label %bb42
bb41:
  %t173 = load ptr, ptr %l1, !tbaa !29
  %t175 = getelementptr { i64, [4 x i64] }, ptr %t173, i32 0, i32 1
  %t176 = getelementptr { %"compiler/source:Span", ptr }, ptr %t175, i32 0, i32 0
  %t177 = load %"compiler/source:Span", ptr %t176
  store %"compiler/source:Span" %t177, ptr %l15
  %t179 = load ptr, ptr %l1, !tbaa !29
  %t181 = getelementptr { i64, [4 x i64] }, ptr %t179, i32 0, i32 1
  %t182 = getelementptr { %"compiler/source:Span", ptr }, ptr %t181, i32 0, i32 1
  %t183 = load ptr, ptr %t182
  store ptr %t183, ptr %l16, !tbaa !29
  br label %bb43
bb42:
  br label %bb45
bb43:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t186 = load %"compiler/source:Span", ptr %l15
  %t187 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eifStmt(ptr %v0, ptr %v1, ptr %t185, %"compiler/source:Span" %t186, ptr %t187)
  br label %bb44
bb44:
  br label %bb276
bb45:
  %t191 = load ptr, ptr %l1, !tbaa !29
  store ptr %t191, ptr %l154, !tbaa !29
  store i1 false, ptr %l155, !tbaa !21
  %t192 = load ptr, ptr %l154, !tbaa !29
  %t193 = icmp ne ptr %t192, null
  br i1 %t193, label %bb46, label %bb47
bb46:
  %t195 = load ptr, ptr %l154, !tbaa !29
  %t196 = load i64, ptr %t195, !range !{i64 0, i64 22}
  %t198 = icmp eq i64 %t196, 6
  store i1 %t198, ptr %l155, !tbaa !21
  br label %bb47
bb47:
  %t199 = load i1, ptr %l155, !tbaa !21
  br i1 %t199, label %bb48, label %bb49
bb48:
  %t200 = load ptr, ptr %l1, !tbaa !29
  %t202 = getelementptr { i64, [4 x i64] }, ptr %t200, i32 0, i32 1
  %t203 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t202, i32 0, i32 0
  %t204 = load %"compiler/source:Span", ptr %t203
  store %"compiler/source:Span" %t204, ptr %l17
  %t206 = load ptr, ptr %l1, !tbaa !29
  %t208 = getelementptr { i64, [4 x i64] }, ptr %t206, i32 0, i32 1
  %t209 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t208, i32 0, i32 1
  %t210 = load { i64, ptr }, ptr %t209
  store { i64, ptr } %t210, ptr %l18, !tbaa !27
  br label %bb50
bb49:
  br label %bb52
bb50:
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t213 = load %"compiler/source:Span", ptr %l17
  %t214 = load { i64, ptr }, ptr %l18, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eloop(ptr %v0, ptr %v0, ptr %v1, ptr %v0, ptr %t212, %"compiler/source:Span" %t213, ptr null, { i64, ptr } %t214, ptr null)
  br label %bb51
bb51:
  br label %bb276
bb52:
  %t218 = load ptr, ptr %l1, !tbaa !29
  store ptr %t218, ptr %l165, !tbaa !29
  store i1 false, ptr %l166, !tbaa !21
  %t219 = load ptr, ptr %l165, !tbaa !29
  %t220 = icmp ne ptr %t219, null
  br i1 %t220, label %bb53, label %bb54
bb53:
  %t222 = load ptr, ptr %l165, !tbaa !29
  %t223 = load i64, ptr %t222, !range !{i64 0, i64 22}
  %t225 = icmp eq i64 %t223, 7
  store i1 %t225, ptr %l166, !tbaa !21
  br label %bb54
bb54:
  %t226 = load i1, ptr %l166, !tbaa !21
  br i1 %t226, label %bb55, label %bb56
bb55:
  %t227 = load ptr, ptr %l1, !tbaa !29
  %t229 = getelementptr { i64, [4 x i64] }, ptr %t227, i32 0, i32 1
  %t230 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t229, i32 0, i32 0
  %t231 = load %"compiler/source:Span", ptr %t230
  store %"compiler/source:Span" %t231, ptr %l19
  %t233 = load ptr, ptr %l1, !tbaa !29
  %t235 = getelementptr { i64, [4 x i64] }, ptr %t233, i32 0, i32 1
  %t236 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t235, i32 0, i32 1
  %t237 = load ptr, ptr %t236
  store ptr %t237, ptr %l20, !tbaa !29
  %t239 = load ptr, ptr %l1, !tbaa !29
  %t241 = getelementptr { i64, [4 x i64] }, ptr %t239, i32 0, i32 1
  %t242 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t241, i32 0, i32 2
  %t243 = load { i64, ptr }, ptr %t242
  store { i64, ptr } %t243, ptr %l21, !tbaa !27
  br label %bb57
bb56:
  br label %bb59
bb57:
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t246 = load %"compiler/source:Span", ptr %l19
  %t247 = load ptr, ptr %l20, !tbaa !29
  %t249 = load { i64, ptr }, ptr %l21, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eloop(ptr %v0, ptr %v1, ptr %v1, ptr %v0, ptr %t245, %"compiler/source:Span" %t246, ptr %t247, { i64, ptr } %t249, ptr null)
  br label %bb58
bb58:
  br label %bb276
bb59:
  %t254 = load ptr, ptr %l1, !tbaa !29
  store ptr %t254, ptr %l180, !tbaa !29
  store i1 false, ptr %l181, !tbaa !21
  %t255 = load ptr, ptr %l180, !tbaa !29
  %t256 = icmp ne ptr %t255, null
  br i1 %t256, label %bb60, label %bb61
bb60:
  %t258 = load ptr, ptr %l180, !tbaa !29
  %t259 = load i64, ptr %t258, !range !{i64 0, i64 22}
  %t261 = icmp eq i64 %t259, 8
  store i1 %t261, ptr %l181, !tbaa !21
  br label %bb61
bb61:
  %t262 = load i1, ptr %l181, !tbaa !21
  br i1 %t262, label %bb62, label %bb63
bb62:
  %t263 = load ptr, ptr %l1, !tbaa !29
  %t265 = getelementptr { i64, [4 x i64] }, ptr %t263, i32 0, i32 1
  %t266 = getelementptr { %"compiler/source:Span", ptr }, ptr %t265, i32 0, i32 0
  %t267 = load %"compiler/source:Span", ptr %t266
  store %"compiler/source:Span" %t267, ptr %l22
  %t269 = load ptr, ptr %l1, !tbaa !29
  %t271 = getelementptr { i64, [4 x i64] }, ptr %t269, i32 0, i32 1
  %t272 = getelementptr { %"compiler/source:Span", ptr }, ptr %t271, i32 0, i32 1
  %t273 = load ptr, ptr %t272
  store ptr %t273, ptr %l23, !tbaa !29
  br label %bb64
bb63:
  br label %bb66
bb64:
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t276 = load %"compiler/source:Span", ptr %l22
  %t277 = load ptr, ptr %l23, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efor3(ptr %v0, ptr %v1, ptr %t275, %"compiler/source:Span" %t276, ptr %t277)
  br label %bb65
bb65:
  br label %bb276
bb66:
  %t281 = load ptr, ptr %l1, !tbaa !29
  store ptr %t281, ptr %l191, !tbaa !29
  store i1 false, ptr %l192, !tbaa !21
  %t282 = load ptr, ptr %l191, !tbaa !29
  %t283 = icmp ne ptr %t282, null
  br i1 %t283, label %bb67, label %bb68
bb67:
  %t285 = load ptr, ptr %l191, !tbaa !29
  %t286 = load i64, ptr %t285, !range !{i64 0, i64 22}
  %t288 = icmp eq i64 %t286, 9
  store i1 %t288, ptr %l192, !tbaa !21
  br label %bb68
bb68:
  %t289 = load i1, ptr %l192, !tbaa !21
  br i1 %t289, label %bb69, label %bb70
bb69:
  %t290 = load ptr, ptr %l1, !tbaa !29
  %t292 = getelementptr { i64, [4 x i64] }, ptr %t290, i32 0, i32 1
  %t293 = getelementptr { %"compiler/source:Span", ptr }, ptr %t292, i32 0, i32 0
  %t294 = load %"compiler/source:Span", ptr %t293
  store %"compiler/source:Span" %t294, ptr %l24
  %t296 = load ptr, ptr %l1, !tbaa !29
  %t298 = getelementptr { i64, [4 x i64] }, ptr %t296, i32 0, i32 1
  %t299 = getelementptr { %"compiler/source:Span", ptr }, ptr %t298, i32 0, i32 1
  %t300 = load ptr, ptr %t299
  store ptr %t300, ptr %l25, !tbaa !29
  br label %bb71
bb70:
  br label %bb73
bb71:
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t303 = load %"compiler/source:Span", ptr %l24
  %t304 = load ptr, ptr %l25, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eforIn(ptr %v0, ptr %v1, ptr %t302, %"compiler/source:Span" %t303, ptr %t304)
  br label %bb72
bb72:
  br label %bb276
bb73:
  %t308 = load ptr, ptr %l1, !tbaa !29
  store ptr %t308, ptr %l202, !tbaa !29
  store i1 false, ptr %l203, !tbaa !21
  %t309 = load ptr, ptr %l202, !tbaa !29
  %t310 = icmp ne ptr %t309, null
  br i1 %t310, label %bb74, label %bb75
bb74:
  %t312 = load ptr, ptr %l202, !tbaa !29
  %t313 = load i64, ptr %t312, !range !{i64 0, i64 22}
  %t315 = icmp eq i64 %t313, 10
  store i1 %t315, ptr %l203, !tbaa !21
  br label %bb75
bb75:
  %t316 = load i1, ptr %l203, !tbaa !21
  br i1 %t316, label %bb76, label %bb77
bb76:
  %t317 = load ptr, ptr %l1, !tbaa !29
  %t319 = getelementptr { i64, [4 x i64] }, ptr %t317, i32 0, i32 1
  %t320 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t319, i32 0, i32 0
  %t321 = load %"compiler/source:Span", ptr %t320
  store %"compiler/source:Span" %t321, ptr %l26
  %t323 = load ptr, ptr %l1, !tbaa !29
  %t325 = getelementptr { i64, [4 x i64] }, ptr %t323, i32 0, i32 1
  %t326 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t325, i32 0, i32 1
  %t327 = load { i64, ptr }, ptr %t326
  store { i64, ptr } %t327, ptr %l27, !tbaa !27
  %t329 = load ptr, ptr %l1, !tbaa !29
  %t331 = getelementptr { i64, [4 x i64] }, ptr %t329, i32 0, i32 1
  %t332 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t331, i32 0, i32 2
  %t333 = load ptr, ptr %t332
  store ptr %t333, ptr %l28, !tbaa !29
  br label %bb78
bb77:
  br label %bb80
bb78:
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t336 = load %"compiler/source:Span", ptr %l26
  %t337 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t338 = load ptr, ptr %l28, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edoFor(ptr %v0, ptr %v1, ptr %v1, ptr %t335, %"compiler/source:Span" %t336, { i64, ptr } %t337, ptr %t338)
  br label %bb79
bb79:
  br label %bb276
bb80:
  %t343 = load ptr, ptr %l1, !tbaa !29
  store ptr %t343, ptr %l216, !tbaa !29
  store i1 false, ptr %l217, !tbaa !21
  %t344 = load ptr, ptr %l216, !tbaa !29
  %t345 = icmp ne ptr %t344, null
  br i1 %t345, label %bb81, label %bb82
bb81:
  %t347 = load ptr, ptr %l216, !tbaa !29
  %t348 = load i64, ptr %t347, !range !{i64 0, i64 22}
  %t350 = icmp eq i64 %t348, 12
  store i1 %t350, ptr %l217, !tbaa !21
  br label %bb82
bb82:
  %t351 = load i1, ptr %l217, !tbaa !21
  br i1 %t351, label %bb83, label %bb84
bb83:
  %t352 = load ptr, ptr %l1, !tbaa !29
  %t354 = getelementptr { i64, [4 x i64] }, ptr %t352, i32 0, i32 1
  %t355 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t354, i32 0, i32 0
  %t356 = load %"compiler/source:Span", ptr %t355
  store %"compiler/source:Span" %t356, ptr %l29
  %t358 = load ptr, ptr %l1, !tbaa !29
  %t360 = getelementptr { i64, [4 x i64] }, ptr %t358, i32 0, i32 1
  %t361 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t360, i32 0, i32 1
  %t362 = load { i64, ptr }, ptr %t361
  store { i64, ptr } %t362, ptr %l30, !tbaa !27
  br label %bb85
bb84:
  br label %bb87
bb85:
  %t364 = load ptr, ptr %l0, !tbaa !29
  %t365 = load %"compiler/source:Span", ptr %l29
  %t366 = load { i64, ptr }, ptr %l30, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereturnStmt(ptr %v0, ptr %v1, ptr %t364, %"compiler/source:Span" %t365, { i64, ptr } %t366)
  br label %bb86
bb86:
  br label %bb276
bb87:
  %t370 = load ptr, ptr %l1, !tbaa !29
  store ptr %t370, ptr %l227, !tbaa !29
  store i1 false, ptr %l228, !tbaa !21
  %t371 = load ptr, ptr %l227, !tbaa !29
  %t372 = icmp ne ptr %t371, null
  br i1 %t372, label %bb88, label %bb89
bb88:
  %t374 = load ptr, ptr %l227, !tbaa !29
  %t375 = load i64, ptr %t374, !range !{i64 0, i64 22}
  %t377 = icmp eq i64 %t375, 15
  store i1 %t377, ptr %l228, !tbaa !21
  br label %bb89
bb89:
  %t378 = load i1, ptr %l228, !tbaa !21
  br i1 %t378, label %bb90, label %bb91
bb90:
  %t379 = load ptr, ptr %l1, !tbaa !29
  %t381 = getelementptr { i64, [4 x i64] }, ptr %t379, i32 0, i32 1
  %t382 = getelementptr { %"compiler/source:Span", ptr }, ptr %t381, i32 0, i32 0
  %t383 = load %"compiler/source:Span", ptr %t382
  store %"compiler/source:Span" %t383, ptr %l31
  %t385 = load ptr, ptr %l1, !tbaa !29
  %t387 = getelementptr { i64, [4 x i64] }, ptr %t385, i32 0, i32 1
  %t388 = getelementptr { %"compiler/source:Span", ptr }, ptr %t387, i32 0, i32 1
  %t389 = load ptr, ptr %t388
  store ptr %t389, ptr %l32, !tbaa !29
  br label %bb92
bb91:
  br label %bb94
bb92:
  %t391 = load ptr, ptr %l0, !tbaa !29
  %t392 = load %"compiler/source:Span", ptr %l31
  %t393 = load ptr, ptr %l32, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebecomeStmt(ptr %v0, ptr %v1, ptr %t391, %"compiler/source:Span" %t392, ptr %t393)
  br label %bb93
bb93:
  br label %bb276
bb94:
  %t397 = load ptr, ptr %l1, !tbaa !29
  store ptr %t397, ptr %l238, !tbaa !29
  store i1 false, ptr %l239, !tbaa !21
  %t398 = load ptr, ptr %l238, !tbaa !29
  %t399 = icmp ne ptr %t398, null
  br i1 %t399, label %bb95, label %bb96
bb95:
  %t401 = load ptr, ptr %l238, !tbaa !29
  %t402 = load i64, ptr %t401, !range !{i64 0, i64 22}
  %t404 = icmp eq i64 %t402, 21
  store i1 %t404, ptr %l239, !tbaa !21
  br label %bb96
bb96:
  %t405 = load i1, ptr %l239, !tbaa !21
  br i1 %t405, label %bb97, label %bb98
bb97:
  %t406 = load ptr, ptr %l1, !tbaa !29
  %t408 = getelementptr { i64, [4 x i64] }, ptr %t406, i32 0, i32 1
  %t409 = getelementptr { %"compiler/source:Span", ptr }, ptr %t408, i32 0, i32 0
  %t410 = load %"compiler/source:Span", ptr %t409
  store %"compiler/source:Span" %t410, ptr %l33
  %t412 = load ptr, ptr %l1, !tbaa !29
  %t414 = getelementptr { i64, [4 x i64] }, ptr %t412, i32 0, i32 1
  %t415 = getelementptr { %"compiler/source:Span", ptr }, ptr %t414, i32 0, i32 1
  %t416 = load ptr, ptr %t415
  store ptr %t416, ptr %l34, !tbaa !29
  br label %bb99
bb98:
  br label %bb101
bb99:
  %t418 = load ptr, ptr %l0, !tbaa !29
  %t419 = load %"compiler/source:Span", ptr %l33
  %t420 = load ptr, ptr %l34, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eyieldStmt(ptr %v0, ptr %v1, ptr %t418, %"compiler/source:Span" %t419, ptr %t420)
  br label %bb100
bb100:
  br label %bb276
bb101:
  %t424 = load ptr, ptr %l1, !tbaa !29
  store ptr %t424, ptr %l249, !tbaa !29
  store i1 false, ptr %l250, !tbaa !21
  %t425 = load ptr, ptr %l249, !tbaa !29
  %t426 = icmp ne ptr %t425, null
  br i1 %t426, label %bb102, label %bb103
bb102:
  %t428 = load ptr, ptr %l249, !tbaa !29
  %t429 = load i64, ptr %t428, !range !{i64 0, i64 22}
  %t431 = icmp eq i64 %t429, 11
  store i1 %t431, ptr %l250, !tbaa !21
  br label %bb103
bb103:
  %t432 = load i1, ptr %l250, !tbaa !21
  br i1 %t432, label %bb104, label %bb105
bb104:
  %t433 = load ptr, ptr %l1, !tbaa !29
  %t435 = getelementptr { i64, [4 x i64] }, ptr %t433, i32 0, i32 1
  %t436 = getelementptr { %"compiler/source:Span", ptr }, ptr %t435, i32 0, i32 0
  %t437 = load %"compiler/source:Span", ptr %t436
  store %"compiler/source:Span" %t437, ptr %l35
  %t439 = load ptr, ptr %l1, !tbaa !29
  %t441 = getelementptr { i64, [4 x i64] }, ptr %t439, i32 0, i32 1
  %t442 = getelementptr { %"compiler/source:Span", ptr }, ptr %t441, i32 0, i32 1
  %t443 = load ptr, ptr %t442
  store ptr %t443, ptr %l36, !tbaa !29
  br label %bb106
bb105:
  br label %bb108
bb106:
  %t445 = load ptr, ptr %l0, !tbaa !29
  %t446 = load %"compiler/source:Span", ptr %l35
  %t447 = load ptr, ptr %l36, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ematchStmt(ptr %v0, ptr %v1, ptr %t445, %"compiler/source:Span" %t446, ptr %t447)
  br label %bb107
bb107:
  br label %bb276
bb108:
  %t451 = load ptr, ptr %l1, !tbaa !29
  store ptr %t451, ptr %l260, !tbaa !29
  store i1 false, ptr %l261, !tbaa !21
  %t452 = load ptr, ptr %l260, !tbaa !29
  %t453 = icmp ne ptr %t452, null
  br i1 %t453, label %bb109, label %bb110
bb109:
  %t455 = load ptr, ptr %l260, !tbaa !29
  %t456 = load i64, ptr %t455, !range !{i64 0, i64 22}
  %t458 = icmp eq i64 %t456, 13
  store i1 %t458, ptr %l261, !tbaa !21
  br label %bb110
bb110:
  %t459 = load i1, ptr %l261, !tbaa !21
  br i1 %t459, label %bb111, label %bb112
bb111:
  %t460 = load ptr, ptr %l1, !tbaa !29
  %t462 = getelementptr { i64, [4 x i64] }, ptr %t460, i32 0, i32 1
  %t463 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t462, i32 0, i32 0
  %t464 = load %"compiler/source:Span", ptr %t463
  store %"compiler/source:Span" %t464, ptr %l37
  %t466 = load ptr, ptr %l1, !tbaa !29
  %t468 = getelementptr { i64, [4 x i64] }, ptr %t466, i32 0, i32 1
  %t469 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t468, i32 0, i32 1
  %t470 = load i32, ptr %t469, !range !{i32 0, i32 96}
  store i32 %t470, ptr %l38
  %t472 = load ptr, ptr %l1, !tbaa !29
  %t474 = getelementptr { i64, [4 x i64] }, ptr %t472, i32 0, i32 1
  %t475 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t474, i32 0, i32 2
  %t476 = load ptr, ptr %t475
  store ptr %t476, ptr %l39, !tbaa !29
  br label %bb113
bb112:
  br label %bb115
bb113:
  %t478 = load ptr, ptr %l0, !tbaa !29
  %t479 = load %"compiler/source:Span", ptr %l37
  %t480 = load i32, ptr %l38, !range !{i32 0, i32 96}
  %t481 = load ptr, ptr %l39, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ejump(ptr %v0, ptr %v1, ptr %t478, %"compiler/source:Span" %t479, i32 %t480, ptr %t481)
  br label %bb114
bb114:
  br label %bb276
bb115:
  %t486 = load ptr, ptr %l1, !tbaa !29
  store ptr %t486, ptr %l274, !tbaa !29
  store i1 false, ptr %l275, !tbaa !21
  %t487 = load ptr, ptr %l274, !tbaa !29
  %t488 = icmp ne ptr %t487, null
  br i1 %t488, label %bb116, label %bb117
bb116:
  %t490 = load ptr, ptr %l274, !tbaa !29
  %t491 = load i64, ptr %t490, !range !{i64 0, i64 22}
  %t493 = icmp eq i64 %t491, 14
  store i1 %t493, ptr %l275, !tbaa !21
  br label %bb117
bb117:
  %t494 = load i1, ptr %l275, !tbaa !21
  br i1 %t494, label %bb118, label %bb119
bb118:
  %t495 = load ptr, ptr %l1, !tbaa !29
  %t497 = getelementptr { i64, [4 x i64] }, ptr %t495, i32 0, i32 1
  %t498 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t497, i32 0, i32 0
  %t499 = load %"compiler/source:Span", ptr %t498
  store %"compiler/source:Span" %t499, ptr %l40
  %t501 = load ptr, ptr %l1, !tbaa !29
  %t503 = getelementptr { i64, [4 x i64] }, ptr %t501, i32 0, i32 1
  %t504 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t503, i32 0, i32 1
  %t505 = load ptr, ptr %t504
  store ptr %t505, ptr %l41, !tbaa !29
  br label %bb120
bb119:
  br label %bb125
bb120:
  %t507 = load ptr, ptr %l0, !tbaa !29
  %t509 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t507)
  store ptr %t509, ptr %l283
  br label %bb121
bb121:
  %t510 = load ptr, ptr %l283, !tbaa !29
  %t512 = getelementptr %"compiler/check:frame", ptr %t510, i32 0, i32 50
  %t513 = load i64, ptr %t512, !tbaa !24
  %t515 = icmp ne i64 %t513, 0
  br i1 %t515, label %bb122, label %bb123
bb122:
  %t517 = load ptr, ptr %l0, !tbaa !29
  %t518 = load %"compiler/source:Span", ptr %l40
  %t519 = load ptr, ptr %l41, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectCond(ptr %v0, ptr %v1, ptr %t517, %"compiler/source:Span" %t518, ptr %t519)
  br label %bb124
bb123:
  br label %bb125
bb124:
  br label %bb276
bb125:
  %t523 = load ptr, ptr %l1, !tbaa !29
  store ptr %t523, ptr %l290, !tbaa !29
  store i1 false, ptr %l291, !tbaa !21
  %t524 = load ptr, ptr %l290, !tbaa !29
  %t525 = icmp ne ptr %t524, null
  br i1 %t525, label %bb126, label %bb127
bb126:
  %t527 = load ptr, ptr %l290, !tbaa !29
  %t528 = load i64, ptr %t527, !range !{i64 0, i64 22}
  %t530 = icmp eq i64 %t528, 14
  store i1 %t530, ptr %l291, !tbaa !21
  br label %bb127
bb127:
  %t531 = load i1, ptr %l291, !tbaa !21
  br i1 %t531, label %bb128, label %bb129
bb128:
  %t532 = load ptr, ptr %l1, !tbaa !29
  %t534 = getelementptr { i64, [4 x i64] }, ptr %t532, i32 0, i32 1
  %t535 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t534, i32 0, i32 0
  %t536 = load %"compiler/source:Span", ptr %t535
  store %"compiler/source:Span" %t536, ptr %l42
  %t538 = load ptr, ptr %l1, !tbaa !29
  %t540 = getelementptr { i64, [4 x i64] }, ptr %t538, i32 0, i32 1
  %t541 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t540, i32 0, i32 1
  %t542 = load ptr, ptr %t541
  store ptr %t542, ptr %l43, !tbaa !29
  %t544 = load ptr, ptr %l1, !tbaa !29
  %t546 = getelementptr { i64, [4 x i64] }, ptr %t544, i32 0, i32 1
  %t547 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t546, i32 0, i32 2
  %t548 = load ptr, ptr %t547
  store ptr %t548, ptr %l44, !tbaa !29
  br label %bb130
bb129:
  br label %bb233
bb130:
  %t550 = load ptr, ptr %l0, !tbaa !29
  %t551 = load ptr, ptr %l43, !tbaa !29
  %t555 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflDecide(ptr %v0, ptr %v1, ptr %t550, ptr %t551)
  store i64 %t555, ptr %l303
  br label %bb131
bb131:
  %t556 = load i64, ptr %l303, !tbaa !24
  store i64 %t556, ptr %l45, !tbaa !24
  %t557 = load i64, ptr %l45, !tbaa !24
  %t559 = icmp eq i64 %t557, 1
  br i1 %t559, label %bb132, label %bb133
bb132:
  br label %ret
bb133:
  br label %bb134
bb134:
  %t561 = load i64, ptr %l45, !tbaa !24
  %t563 = icmp slt i64 %t561, 0
  br i1 %t563, label %bb135, label %bb136
bb135:
  %t565 = load ptr, ptr %l0, !tbaa !29
  %t566 = load ptr, ptr %l43, !tbaa !29
  %t569 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econd1(ptr %v0, ptr %v1, ptr %t565, ptr %t566)
  store ptr %t569, ptr %l311
  br label %bb137
bb136:
  %t570 = load ptr, ptr %l43, !tbaa !29
  %t572 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t570)
  store %"compiler/source:Span" %t572, ptr %l313
  br label %bb138
bb137:
  %t573 = load ptr, ptr %l311, !tbaa !29
  store ptr %t573, ptr %l308, !tbaa !29
  br label %bb139
bb138:
  %t574 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store { i64, [5 x i64] } zeroinitializer, ptr %t575
  %t576 = getelementptr { i64, [5 x i64] }, ptr %t575, i32 0, i32 0
  store i64 0, ptr %t576
  %t577 = load %"compiler/source:Span", ptr %l313
  %t578 = insertvalue { %"compiler/source:Span", i32, i64 } undef, %"compiler/source:Span" %t577, 0
  %t580 = insertvalue { %"compiler/source:Span", i32, i64 } %t578, i32 %t574, 1
  %t581 = insertvalue { %"compiler/source:Span", i32, i64 } %t580, i64 0, 2
  %t582 = getelementptr { i64, [5 x i64] }, ptr %t575, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64 } %t581, ptr %t582
  %t583 = load { i64, [5 x i64] }, ptr %t575
  %t585 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t583, ptr %t585
  store ptr %t585, ptr %l308, !tbaa !29
  br label %bb139
bb139:
  %t587 = load ptr, ptr %l308, !tbaa !29
  store ptr %t587, ptr %l46, !tbaa !29
  %t588 = load ptr, ptr %l0, !tbaa !29
  %t589 = load ptr, ptr %l44, !tbaa !29
  %t592 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emessage(ptr %v0, ptr %v1, ptr %t588, ptr %t589, i1 false)
  store ptr %t592, ptr %l319
  br label %bb140
bb140:
  %t593 = load ptr, ptr %l319, !tbaa !29
  %t594 = load ptr, ptr %l0, !tbaa !29
  %t595 = load %"compiler/source:Span", ptr %l42
  %t596 = load ptr, ptr %l46, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t598
  %t599 = getelementptr { i64, [3 x i64] }, ptr %t598, i32 0, i32 0
  store i64 10, ptr %t599
  %t601 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t595, 0
  %t603 = insertvalue { %"compiler/source:Span", ptr, ptr } %t601, ptr %t596, 1
  %t605 = insertvalue { %"compiler/source:Span", ptr, ptr } %t603, ptr %t593, 2
  %t606 = getelementptr { i64, [3 x i64] }, ptr %t598, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t605, ptr %t606
  %t607 = load { i64, [3 x i64] }, ptr %t598
  %t609 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t607, ptr %t609
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t594, ptr %t609)
  br label %bb141
bb141:
  %t612 = load ptr, ptr %l0, !tbaa !29
  store ptr %t612, ptr %l326, !tbaa !29
  %t613 = load ptr, ptr %l43, !tbaa !29
  store ptr %t613, ptr %l327, !tbaa !29
  %t614 = load ptr, ptr %l0, !tbaa !29
  %t616 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t614)
  store ptr %t616, ptr %l329
  br label %bb142
bb142:
  %t617 = load ptr, ptr %l329, !tbaa !29
  %t619 = getelementptr %"compiler/check:frame", ptr %t617, i32 0, i32 7
  %t620 = load i64, ptr %t619, !tbaa !24
  %t621 = load ptr, ptr %l326, !tbaa !29
  %t622 = load ptr, ptr %l327, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushFacts(ptr %v0, ptr %v1, ptr %t621, ptr %t622, i1 true, i64 %t620)
  br label %bb143
bb143:
  %t624 = load ptr, ptr %l0, !tbaa !29
  %t626 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t624)
  store ptr %t626, ptr %l333
  br label %bb144
bb144:
  %t627 = load ptr, ptr %l333, !tbaa !29
  store ptr %t627, ptr %l48, !tbaa !29
  %t628 = load ptr, ptr %l0, !tbaa !29
  %t630 = getelementptr %"compiler/check:Checker", ptr %t628, i32 0, i32 2
  %t631 = load i1, ptr %t630, !tbaa !21
  br i1 %t631, label %bb145, label %bb146
bb145:
  store i1 true, ptr %l336, !tbaa !21
  br label %bb147
bb146:
  %t633 = load ptr, ptr %l48, !tbaa !29
  %t635 = getelementptr %"compiler/check:frame", ptr %t633, i32 0, i32 12
  %t636 = load i1, ptr %t635, !tbaa !21
  %t638 = xor i1 %t636, true
  store i1 %t638, ptr %l336, !tbaa !21
  br label %bb147
bb147:
  %t640 = load i1, ptr %l336, !tbaa !21
  br i1 %t640, label %bb148, label %bb149
bb148:
  store %olang.scope zeroinitializer, ptr %s21
  store i64 -1, ptr %l49, !tbaa !24
  %t641 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s21, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t641, ptr %l340
  br label %bb150
bb149:
  br label %bb232
bb150:
  %t642 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l340
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t642, ptr %l50
  %t643 = load i64, ptr %l45, !tbaa !24
  %t645 = icmp slt i64 %t643, 0
  br i1 %t645, label %bb151, label %bb152
bb151:
  %t647 = load ptr, ptr %l0, !tbaa !29
  %t649 = getelementptr %"compiler/check:Checker", ptr %t647, i32 0, i32 106
  store i1 true, ptr %t649, !tbaa !21
  %t650 = load ptr, ptr %l0, !tbaa !29
  %t651 = load ptr, ptr %l48, !tbaa !29
  %t653 = getelementptr %"compiler/check:frame", ptr %t651, i32 0, i32 1
  %t654 = load i64, ptr %t653, !tbaa !24
  %t655 = load ptr, ptr %l43, !tbaa !29
  %t659 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eCondBody(ptr %v0, ptr %v1, ptr %t650, i64 %t654, ptr %t655)
  store i64 %t659, ptr %l348
  br label %bb153
bb152:
  br label %bb163
bb153:
  %t660 = load i64, ptr %l348, !tbaa !24
  store i64 %t660, ptr %l49, !tbaa !24
  %t661 = load ptr, ptr %l0, !tbaa !29
  %t663 = getelementptr %"compiler/check:Checker", ptr %t661, i32 0, i32 106
  store i1 false, ptr %t663, !tbaa !21
  %t664 = load ptr, ptr %l0, !tbaa !29
  %t666 = getelementptr %"compiler/check:Checker", ptr %t664, i32 0, i32 115
  store ptr %t666, ptr %l51, !tbaa !29
  store i64 0, ptr %l52, !tbaa !24
  br label %bb154
bb154:
  %t668 = load i64, ptr %l52, !tbaa !24
  store i64 %t668, ptr %l352, !tbaa !24
  %t669 = load ptr, ptr %l51, !tbaa !29
  %t671 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t669)
  store i64 %t671, ptr %l354
  br label %bb155
bb155:
  %t672 = load i64, ptr %l352, !tbaa !24
  %t673 = load i64, ptr %l354, !tbaa !24
  %t674 = icmp slt i64 %t672, %t673
  %t676 = xor i1 %t674, true
  br i1 %t676, label %bb156, label %bb157
bb156:
  br label %bb162
bb157:
  br label %bb158
bb158:
  %t678 = load ptr, ptr %l51, !tbaa !29
  %t679 = load i64, ptr %l52, !tbaa !24
  %t682 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t678, i64 %t679)
  store i64 %t682, ptr %l359
  br label %bb159
bb159:
  %t683 = load i64, ptr %l359, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s21, ptr %l50, i64 %t683)
  br label %bb160
bb160:
  br label %bb161
bb161:
  %t687 = load i64, ptr %l52, !tbaa !24
  %t689 = add i64 %t687, 1
  store i64 %t689, ptr %l52, !tbaa !24
  br label %bb154
bb162:
  br label %bb163
bb163:
  store i64 -1, ptr %l54, !tbaa !24
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d23, i32 0, i32 1) }, ptr %l364, !tbaa !27
  %t691 = load { i64, ptr }, ptr %l364, !tbaa !27
  store { i64, ptr } %t691, ptr %l365, !tbaa !27
  %t692 = load { i64, ptr }, ptr %l365, !tbaa !27
  %t693 = extractvalue { i64, ptr } %t692, 0
  store i64 %t693, ptr %l366, !tbaa !24
  %t694 = load i64, ptr %l366, !tbaa !24
  %t695 = mul i64 %t694, 1
  %t696 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t695)
  %t697 = insertvalue { i64, ptr } undef, i64 %t694, 0
  %t698 = insertvalue { i64, ptr } %t697, ptr %t696, 1
  store { i64, ptr } %t698, ptr %l367, !tbaa !27
  %t699 = getelementptr { i64, ptr }, ptr %l367, i32 0, i32 1
  %t700 = load ptr, ptr %t699, !tbaa !27
  %t701 = getelementptr { i64, ptr }, ptr %l365, i32 0, i32 1
  %t702 = load ptr, ptr %t701, !tbaa !27
  %t703 = load i64, ptr %l366, !tbaa !24
  %t704 = mul i64 %t703, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t700, ptr %t702, i64 %t704, i1 false)
  %t705 = load { i64, ptr }, ptr %l367, !tbaa !27
  store { i64, ptr } %t705, ptr %l55, !tbaa !27
  store i1 false, ptr %l56, !tbaa !21
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d24, i32 0, i32 1) }, ptr %l368, !tbaa !27
  %t706 = load { i64, ptr }, ptr %l368, !tbaa !27
  store { i64, ptr } %t706, ptr %l369, !tbaa !27
  %t707 = load { i64, ptr }, ptr %l369, !tbaa !27
  %t708 = extractvalue { i64, ptr } %t707, 0
  store i64 %t708, ptr %l370, !tbaa !24
  %t709 = load i64, ptr %l370, !tbaa !24
  %t710 = mul i64 %t709, 1
  %t711 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t710)
  %t712 = insertvalue { i64, ptr } undef, i64 %t709, 0
  %t713 = insertvalue { i64, ptr } %t712, ptr %t711, 1
  store { i64, ptr } %t713, ptr %l371, !tbaa !27
  %t714 = getelementptr { i64, ptr }, ptr %l371, i32 0, i32 1
  %t715 = load ptr, ptr %t714, !tbaa !27
  %t716 = getelementptr { i64, ptr }, ptr %l369, i32 0, i32 1
  %t717 = load ptr, ptr %t716, !tbaa !27
  %t718 = load i64, ptr %l370, !tbaa !24
  %t719 = mul i64 %t718, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t715, ptr %t717, i64 %t719, i1 false)
  %t720 = load { i64, ptr }, ptr %l371, !tbaa !27
  store { i64, ptr } %t720, ptr %l57, !tbaa !27
  %t721 = load i64, ptr %l49, !tbaa !24
  %t723 = icmp sge i64 %t721, 0
  br i1 %t723, label %bb164, label %bb165
bb164:
  store i1 true, ptr %l374, !tbaa !21
  br label %bb166
bb165:
  %t725 = load i64, ptr %l45, !tbaa !24
  %t727 = icmp eq i64 %t725, 0
  store i1 %t727, ptr %l374, !tbaa !21
  br label %bb166
bb166:
  %t729 = load i1, ptr %l374, !tbaa !21
  br i1 %t729, label %bb167, label %bb168
bb167:
  %t730 = load ptr, ptr %l44, !tbaa !29
  %t732 = icmp eq ptr %t730, null
  %t734 = xor i1 %t732, true
  store i1 %t734, ptr %l377, !tbaa !21
  br label %bb169
bb168:
  store i1 false, ptr %l377, !tbaa !21
  br label %bb169
bb169:
  %t736 = load i1, ptr %l377, !tbaa !21
  br i1 %t736, label %bb170, label %bb171
bb170:
  store i1 true, ptr %l56, !tbaa !21
  %t737 = load ptr, ptr %l0, !tbaa !29
  %t738 = load ptr, ptr %l44, !tbaa !29
  %t741 = call { i32, { i64, ptr } } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflText(ptr %v0, ptr %v1, ptr %s21, ptr %t737, ptr %t738)
  %t742 = extractvalue { i32, { i64, ptr } } %t741, 1
  %t743 = extractvalue { i32, { i64, ptr } } %t741, 0
  store i32 %t743, ptr %l385
  %t744 = icmp ne i32 %t743, 0
  br i1 %t744, label %bb173, label %ok.745, !prof !99
ok.745:
  store { i64, ptr } %t742, ptr %l384
  br label %bb172
bb171:
  br label %bb199
bb172:
  %t746 = load { i64, ptr }, ptr %l384, !tbaa !27
  store { i64, ptr } %t746, ptr %l381, !tbaa !27
  br label %bb175
bb173:
  %t747 = load i32, ptr %l385, !tbaa !23
  %t748 = ashr i32 %t747, 16
  %t750 = icmp eq i32 %t748, 1
  store i1 %t750, ptr %l387, !tbaa !21
  br label %bb174
bb174:
  call void @__olang_ert_req_clear()
  store i1 false, ptr %l56, !tbaa !21
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d25, i32 0, i32 1) }, ptr %l388, !tbaa !27
  %t751 = load { i64, ptr }, ptr %l388, !tbaa !27
  store { i64, ptr } %t751, ptr %l381, !tbaa !27
  br label %bb175
bb175:
  %t753 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t754 = extractvalue { i64, ptr } %t753, 0
  %t755 = load { i64, ptr }, ptr %l381, !tbaa !27
  %t756 = extractvalue { i64, ptr } %t755, 0
  store i64 %t756, ptr %l391, !tbaa !24
  %t758 = load i64, ptr %l391, !tbaa !24
  %t759 = icmp eq i64 %t754, %t758
  br i1 %t759, label %bb176, label %bb177
bb176:
  %t761 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t762 = load ptr, ptr %t761, !tbaa !27
  %t763 = getelementptr { i64, ptr }, ptr %l381, i32 0, i32 1
  %t764 = load ptr, ptr %t763, !tbaa !27
  %t765 = load i64, ptr %l391, !tbaa !24
  %t766 = mul i64 %t765, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t762, ptr %t764, i64 %t766, i1 false)
  br label %bb178
bb177:
  %t767 = load { i64, ptr }, ptr %l381, !tbaa !27
  store { i64, ptr } %t767, ptr %l55, !tbaa !27
  br label %bb178
bb178:
  %t768 = load i1, ptr %l56, !tbaa !21
  %t770 = xor i1 %t768, true
  br i1 %t770, label %bb179, label %bb180
bb179:
  %t772 = load ptr, ptr %l0, !tbaa !29
  %t774 = getelementptr %"compiler/check:Checker", ptr %t772, i32 0, i32 106
  store i1 true, ptr %t774, !tbaa !21
  %t775 = load ptr, ptr %l0, !tbaa !29
  store ptr %t775, ptr %l396, !tbaa !29
  %t776 = load ptr, ptr %l48, !tbaa !29
  %t778 = getelementptr %"compiler/check:frame", ptr %t776, i32 0, i32 1
  %t779 = load i64, ptr %t778, !tbaa !24
  store i64 %t779, ptr %l398, !tbaa !24
  %t780 = load ptr, ptr %l44, !tbaa !29
  store ptr %t780, ptr %l399, !tbaa !29
  %t781 = load ptr, ptr %l0, !tbaa !29
  %t783 = getelementptr %"compiler/check:Checker", ptr %t781, i32 0, i32 1
  %t784 = load ptr, ptr %t783, !tbaa !29
  %t786 = getelementptr %"compiler/generic:Program", ptr %t784, i32 0, i32 2
  store ptr %t786, ptr %l402, !tbaa !29
  %t787 = load ptr, ptr %l0, !tbaa !29
  %t789 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t787)
  store i32 %t789, ptr %l404
  br label %bb181
bb180:
  br label %bb198
bb181:
  %t790 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t791 = load ptr, ptr %l402, !tbaa !29
  %t792 = load i32, ptr %l404, !tbaa !23
  %t794 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t791, i32 %t792, i64 %t790)
  store i32 %t794, ptr %l406
  br label %bb182
bb182:
  %t795 = load ptr, ptr %l396, !tbaa !29
  %t796 = load i64, ptr %l398, !tbaa !24
  %t797 = load ptr, ptr %l399, !tbaa !29
  %t798 = load i32, ptr %l406, !tbaa !23
  %t799 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eExprBody(ptr %v0, ptr %v1, ptr %t795, i64 %t796, ptr %t797, i32 %t798)
  store i64 %t799, ptr %l407
  br label %bb183
bb183:
  %t800 = load i64, ptr %l407, !tbaa !24
  store i64 %t800, ptr %l54, !tbaa !24
  %t801 = load ptr, ptr %l0, !tbaa !29
  %t803 = getelementptr %"compiler/check:Checker", ptr %t801, i32 0, i32 106
  store i1 false, ptr %t803, !tbaa !21
  %t804 = load ptr, ptr %l0, !tbaa !29
  %t806 = getelementptr %"compiler/check:Checker", ptr %t804, i32 0, i32 115
  store ptr %t806, ptr %l58, !tbaa !29
  store i64 0, ptr %l59, !tbaa !24
  br label %bb184
bb184:
  %t808 = load i64, ptr %l59, !tbaa !24
  store i64 %t808, ptr %l411, !tbaa !24
  %t809 = load ptr, ptr %l58, !tbaa !29
  %t811 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t809)
  store i64 %t811, ptr %l413
  br label %bb185
bb185:
  %t812 = load i64, ptr %l411, !tbaa !24
  %t813 = load i64, ptr %l413, !tbaa !24
  %t814 = icmp slt i64 %t812, %t813
  %t816 = xor i1 %t814, true
  br i1 %t816, label %bb186, label %bb187
bb186:
  br label %bb192
bb187:
  br label %bb188
bb188:
  %t818 = load ptr, ptr %l58, !tbaa !29
  %t819 = load i64, ptr %l59, !tbaa !24
  %t822 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t818, i64 %t819)
  store i64 %t822, ptr %l418
  br label %bb189
bb189:
  %t823 = load i64, ptr %l418, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s21, ptr %l50, i64 %t823)
  br label %bb190
bb190:
  br label %bb191
bb191:
  %t827 = load i64, ptr %l59, !tbaa !24
  %t829 = add i64 %t827, 1
  store i64 %t829, ptr %l59, !tbaa !24
  br label %bb184
bb192:
  %t831 = load ptr, ptr %l0, !tbaa !29
  store ptr %t831, ptr %l423, !tbaa !29
  %t832 = load ptr, ptr %l44, !tbaa !29
  %t834 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t832)
  store %"compiler/source:Span" %t834, ptr %l425
  br label %bb193
bb193:
  %t835 = load ptr, ptr %l423, !tbaa !29
  %t836 = load %"compiler/source:Span", ptr %l425
  %t837 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t835, %"compiler/source:Span" %t836)
  store { i64, ptr } %t837, ptr %l426
  br label %bb194
bb194:
  %t838 = load { i64, ptr }, ptr %l426, !tbaa !27
  store { i64, ptr } %t838, ptr %l427, !tbaa !27
  %t839 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t840 = extractvalue { i64, ptr } %t839, 0
  %t841 = load { i64, ptr }, ptr %l427, !tbaa !27
  %t842 = extractvalue { i64, ptr } %t841, 0
  store i64 %t842, ptr %l429, !tbaa !24
  %t844 = load i64, ptr %l429, !tbaa !24
  %t845 = icmp eq i64 %t840, %t844
  br i1 %t845, label %bb195, label %bb196
bb195:
  %t847 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t848 = load ptr, ptr %t847, !tbaa !27
  %t849 = getelementptr { i64, ptr }, ptr %l427, i32 0, i32 1
  %t850 = load ptr, ptr %t849, !tbaa !27
  %t851 = load i64, ptr %l429, !tbaa !24
  %t852 = mul i64 %t851, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t848, ptr %t850, i64 %t852, i1 false)
  br label %bb197
bb196:
  %t853 = load { i64, ptr }, ptr %l427, !tbaa !27
  %t854 = extractvalue { i64, ptr } %t853, 0
  store i64 %t854, ptr %l431, !tbaa !24
  %t855 = load i64, ptr %l431, !tbaa !24
  %t856 = mul i64 %t855, 1
  %t857 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t856)
  %t858 = insertvalue { i64, ptr } undef, i64 %t855, 0
  %t859 = insertvalue { i64, ptr } %t858, ptr %t857, 1
  store { i64, ptr } %t859, ptr %l432, !tbaa !27
  %t860 = getelementptr { i64, ptr }, ptr %l432, i32 0, i32 1
  %t861 = load ptr, ptr %t860, !tbaa !27
  %t862 = getelementptr { i64, ptr }, ptr %l427, i32 0, i32 1
  %t863 = load ptr, ptr %t862, !tbaa !27
  %t864 = load i64, ptr %l431, !tbaa !24
  %t865 = mul i64 %t864, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t861, ptr %t863, i64 %t865, i1 false)
  %t866 = load { i64, ptr }, ptr %l432, !tbaa !27
  store { i64, ptr } %t866, ptr %l57, !tbaa !27
  br label %bb197
bb197:
  br label %bb198
bb198:
  br label %bb199
bb199:
  %t867 = load i64, ptr %l49, !tbaa !24
  %t869 = icmp sge i64 %t867, 0
  br i1 %t869, label %bb200, label %bb201
bb200:
  store i1 true, ptr %l435, !tbaa !21
  br label %bb202
bb201:
  %t871 = load i64, ptr %l45, !tbaa !24
  %t873 = icmp eq i64 %t871, 0
  store i1 %t873, ptr %l435, !tbaa !21
  br label %bb202
bb202:
  %t875 = load i1, ptr %l435, !tbaa !21
  br i1 %t875, label %bb203, label %bb204
bb203:
  store %olang.scope zeroinitializer, ptr %s32
  %t876 = load ptr, ptr %l0, !tbaa !29
  %t878 = getelementptr %"compiler/check:Checker", ptr %t876, i32 0, i32 1
  %t879 = load ptr, ptr %t878, !tbaa !29
  %t881 = getelementptr %"compiler/generic:Program", ptr %t879, i32 0, i32 0
  %t882 = load ptr, ptr %t881, !tbaa !29
  %t884 = getelementptr %"compiler/load:Loader", ptr %t882, i32 0, i32 4
  %t885 = load ptr, ptr %t884, !tbaa !29
  %t887 = call { { i64, [3 x i64] }, { i64, ptr } } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eTopContext(ptr %v0, ptr %s32, ptr %t885)
  store { { i64, [3 x i64] }, { i64, ptr } } %t887, ptr %l442
  br label %bb205
bb204:
  br label %bb231
bb205:
  %t888 = load { { i64, [3 x i64] }, { i64, ptr } }, ptr %l442
  store { { i64, [3 x i64] }, { i64, ptr } } %t888, ptr %l61
  %t889 = getelementptr { { i64, [3 x i64] }, { i64, ptr } }, ptr %l61, i32 0, i32 0
  %t890 = load { i64, [3 x i64] }, ptr %t889
  store { i64, [3 x i64] } %t890, ptr %l62
  %t892 = getelementptr { { i64, [3 x i64] }, { i64, ptr } }, ptr %l61, i32 0, i32 1
  %t893 = load { i64, ptr }, ptr %t892, !tbaa !27
  store { i64, ptr } %t893, ptr %l444, !tbaa !27
  %t894 = load { i64, ptr }, ptr %l444, !tbaa !27
  %t895 = extractvalue { i64, ptr } %t894, 0
  store i64 %t895, ptr %l445, !tbaa !24
  %t896 = load i64, ptr %l445, !tbaa !24
  %t897 = mul i64 %t896, 1
  %t898 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t897)
  %t899 = insertvalue { i64, ptr } undef, i64 %t896, 0
  %t900 = insertvalue { i64, ptr } %t899, ptr %t898, 1
  store { i64, ptr } %t900, ptr %l446, !tbaa !27
  %t901 = getelementptr { i64, ptr }, ptr %l446, i32 0, i32 1
  %t902 = load ptr, ptr %t901, !tbaa !27
  %t903 = getelementptr { i64, ptr }, ptr %l444, i32 0, i32 1
  %t904 = load ptr, ptr %t903, !tbaa !27
  %t905 = load i64, ptr %l445, !tbaa !24
  %t906 = mul i64 %t905, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t902, ptr %t904, i64 %t906, i1 false)
  %t907 = load { i64, ptr }, ptr %l446, !tbaa !27
  store { i64, ptr } %t907, ptr %l63, !tbaa !27
  %t908 = load ptr, ptr %l0, !tbaa !29
  %t910 = getelementptr %"compiler/check:Checker", ptr %t908, i32 0, i32 1
  %t911 = load ptr, ptr %t910, !tbaa !29
  %t913 = getelementptr %"compiler/generic:Program", ptr %t911, i32 0, i32 0
  %t914 = load ptr, ptr %t913, !tbaa !29
  %t916 = getelementptr %"compiler/load:Loader", ptr %t914, i32 0, i32 5
  %t917 = load ptr, ptr %l48, !tbaa !29
  %t919 = getelementptr %"compiler/check:frame", ptr %t917, i32 0, i32 1
  %t920 = load i64, ptr %t919, !tbaa !24
  %t923 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t916, i64 %t920)
  store ptr %t923, ptr %l453
  br label %bb206
bb206:
  %t924 = load ptr, ptr %l453, !tbaa !29
  %t926 = getelementptr %"compiler/load:Module", ptr %t924, i32 0, i32 2
  %t927 = load { i64, ptr }, ptr %t926, !tbaa !27
  %t929 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s32, { i64, ptr } %t927, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d26, i32 0, i32 1) })
  store i1 %t929, ptr %l456
  br label %bb207
bb207:
  %t930 = load i1, ptr %l456, !tbaa !21
  store i1 %t930, ptr %l64, !tbaa !21
  %t931 = load ptr, ptr %l0, !tbaa !29
  %t932 = load ptr, ptr %l43, !tbaa !29
  %t936 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadsConst(ptr %v0, ptr %v1, ptr %t931, ptr %t932)
  store i1 %t936, ptr %l460
  br label %bb208
bb208:
  %t937 = load i1, ptr %l460, !tbaa !21
  %t938 = xor i1 %t937, true
  br i1 %t938, label %bb209, label %bb210
bb209:
  %t940 = load i64, ptr %l45, !tbaa !24
  %t942 = icmp slt i64 %t940, 0
  store i1 %t942, ptr %l462, !tbaa !21
  br label %bb211
bb210:
  store i1 false, ptr %l462, !tbaa !21
  br label %bb211
bb211:
  %t944 = load i1, ptr %l462, !tbaa !21
  br i1 %t944, label %bb212, label %bb213
bb212:
  %t945 = load i1, ptr %l56, !tbaa !21
  br i1 %t945, label %bb214, label %bb215
bb213:
  store i1 false, ptr %l465, !tbaa !21
  br label %bb217
bb214:
  %t947 = load ptr, ptr %l0, !tbaa !29
  %t949 = getelementptr %"compiler/check:Checker", ptr %t947, i32 0, i32 121
  %t950 = load i1, ptr %t949, !tbaa !21
  store i1 %t950, ptr %l467, !tbaa !21
  br label %bb216
bb215:
  store i1 false, ptr %l467, !tbaa !21
  br label %bb216
bb216:
  %t952 = load i1, ptr %l467, !tbaa !21
  %t953 = xor i1 %t952, true
  store i1 %t953, ptr %l465, !tbaa !21
  br label %bb217
bb217:
  %t955 = load i1, ptr %l465, !tbaa !21
  br i1 %t955, label %bb218, label %bb219
bb218:
  %t956 = load i1, ptr %l64, !tbaa !21
  %t958 = xor i1 %t956, true
  store i1 %t958, ptr %l471, !tbaa !21
  br label %bb220
bb219:
  store i1 false, ptr %l471, !tbaa !21
  br label %bb220
bb220:
  %t960 = load i1, ptr %l471, !tbaa !21
  br i1 %t960, label %bb221, label %bb222
bb221:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d27, i32 0, i32 1) }, ptr %l474, !tbaa !27
  %t961 = load { i64, ptr }, ptr %l474, !tbaa !27
  store { i64, ptr } %t961, ptr %l475, !tbaa !27
  %t962 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t963 = extractvalue { i64, ptr } %t962, 0
  %t964 = load { i64, ptr }, ptr %l475, !tbaa !27
  %t965 = extractvalue { i64, ptr } %t964, 0
  store i64 %t965, ptr %l477, !tbaa !24
  %t967 = load i64, ptr %l477, !tbaa !24
  %t968 = icmp eq i64 %t963, %t967
  br i1 %t968, label %bb223, label %bb224
bb222:
  br label %bb226
bb223:
  %t970 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t971 = load ptr, ptr %t970, !tbaa !27
  %t972 = getelementptr { i64, ptr }, ptr %l475, i32 0, i32 1
  %t973 = load ptr, ptr %t972, !tbaa !27
  %t974 = load i64, ptr %l477, !tbaa !24
  %t975 = mul i64 %t974, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t971, ptr %t973, i64 %t975, i1 false)
  br label %bb225
bb224:
  %t976 = load { i64, ptr }, ptr %l475, !tbaa !27
  %t977 = extractvalue { i64, ptr } %t976, 0
  store i64 %t977, ptr %l479, !tbaa !24
  %t978 = load i64, ptr %l479, !tbaa !24
  %t979 = mul i64 %t978, 1
  %t980 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t979)
  %t981 = insertvalue { i64, ptr } undef, i64 %t978, 0
  %t982 = insertvalue { i64, ptr } %t981, ptr %t980, 1
  store { i64, ptr } %t982, ptr %l480, !tbaa !27
  %t983 = getelementptr { i64, ptr }, ptr %l480, i32 0, i32 1
  %t984 = load ptr, ptr %t983, !tbaa !27
  %t985 = getelementptr { i64, ptr }, ptr %l475, i32 0, i32 1
  %t986 = load ptr, ptr %t985, !tbaa !27
  %t987 = load i64, ptr %l479, !tbaa !24
  %t988 = mul i64 %t987, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t984, ptr %t986, i64 %t988, i1 false)
  %t989 = load { i64, ptr }, ptr %l480, !tbaa !27
  store { i64, ptr } %t989, ptr %l63, !tbaa !27
  br label %bb225
bb225:
  br label %bb226
bb226:
  %t990 = load ptr, ptr %l0, !tbaa !29
  %t992 = getelementptr %"compiler/check:Checker", ptr %t990, i32 0, i32 82
  store ptr %t992, ptr %l482, !tbaa !29
  %t993 = load ptr, ptr %l48, !tbaa !29
  %t995 = getelementptr %"compiler/check:frame", ptr %t993, i32 0, i32 0
  %t996 = load i64, ptr %t995, !tbaa !24
  store i64 %t996, ptr %l484, !tbaa !24
  %t997 = load ptr, ptr %l48, !tbaa !29
  %t999 = getelementptr %"compiler/check:frame", ptr %t997, i32 0, i32 2
  %t1000 = load i64, ptr %t999, !tbaa !24
  store i64 %t1000, ptr %l486, !tbaa !24
  %t1001 = load %"compiler/source:Span", ptr %l42
  store %"compiler/source:Span" %t1001, ptr %l487
  %t1002 = load ptr, ptr %l0, !tbaa !29
  %t1003 = load ptr, ptr %l43, !tbaa !29
  %t1006 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperatorOf(ptr %v0, ptr %v1, ptr %t1002, ptr %t1003)
  store %"compiler/source:Span" %t1006, ptr %l490
  br label %bb227
bb227:
  %t1007 = load i64, ptr %l49, !tbaa !24
  store i64 %t1007, ptr %l491, !tbaa !24
  %t1008 = load i64, ptr %l54, !tbaa !24
  store i64 %t1008, ptr %l492, !tbaa !24
  %t1010 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %s21, ptr %v0, ptr %l50)
  store { i64, ptr } %t1010, ptr %l494
  br label %bb228
bb228:
  %t1011 = load { i64, [3 x i64] }, ptr %l62
  %t1012 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t1014 = extractvalue { i64, ptr } %t1012, 1
  %t1015 = extractvalue { i64, ptr } %t1012, 0
  %t1016 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t1015)
  call void @olang_textcopy(ptr %t1016, ptr %t1014, i64 %t1015)
  %t1017 = insertvalue { i64, ptr } undef, i64 %t1015, 0
  %t1018 = insertvalue { i64, ptr } %t1017, ptr %t1016, 1
  %t1020 = extractvalue { i64, ptr } %t1018, 0
  %t1021 = extractvalue { i64, ptr } %t1018, 1
  %t1022 = mul i64 %t1020, 1
  %t1023 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t1022)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1023, ptr %t1021, i64 %t1022, i1 false)
  %t1024 = insertvalue { i64, ptr } undef, i64 %t1020, 0
  %t1025 = insertvalue { i64, ptr } %t1024, ptr %t1023, 1
  %t1026 = load i1, ptr %l56, !tbaa !21
  %t1027 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t1029 = extractvalue { i64, ptr } %t1027, 1
  %t1030 = extractvalue { i64, ptr } %t1027, 0
  %t1031 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t1030)
  call void @olang_textcopy(ptr %t1031, ptr %t1029, i64 %t1030)
  %t1032 = insertvalue { i64, ptr } undef, i64 %t1030, 0
  %t1033 = insertvalue { i64, ptr } %t1032, ptr %t1031, 1
  %t1035 = extractvalue { i64, ptr } %t1033, 0
  %t1036 = extractvalue { i64, ptr } %t1033, 1
  %t1037 = mul i64 %t1035, 1
  %t1038 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t1037)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1038, ptr %t1036, i64 %t1037, i1 false)
  %t1039 = insertvalue { i64, ptr } undef, i64 %t1035, 0
  %t1040 = insertvalue { i64, ptr } %t1039, ptr %t1038, 1
  %t1041 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t1043 = extractvalue { i64, ptr } %t1041, 1
  %t1044 = extractvalue { i64, ptr } %t1041, 0
  %t1045 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t1044)
  call void @olang_textcopy(ptr %t1045, ptr %t1043, i64 %t1044)
  %t1046 = insertvalue { i64, ptr } undef, i64 %t1044, 0
  %t1047 = insertvalue { i64, ptr } %t1046, ptr %t1045, 1
  %t1049 = extractvalue { i64, ptr } %t1047, 0
  %t1050 = extractvalue { i64, ptr } %t1047, 1
  %t1051 = mul i64 %t1049, 1
  %t1052 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t1051)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1052, ptr %t1050, i64 %t1051, i1 false)
  %t1053 = insertvalue { i64, ptr } undef, i64 %t1049, 0
  %t1054 = insertvalue { i64, ptr } %t1053, ptr %t1052, 1
  %t1056 = load i64, ptr %l484, !tbaa !24
  %t1057 = load i64, ptr %l486, !tbaa !24
  %t1058 = load %"compiler/source:Span", ptr %l487
  %t1059 = load %"compiler/source:Span", ptr %l490
  %t1060 = load i64, ptr %l491, !tbaa !24
  %t1061 = load i64, ptr %l492, !tbaa !24
  %t1062 = load { i64, ptr }, ptr %l494, !tbaa !27
  call void @compiler_2fcheck_3aAssertAsk_2ector(ptr %t1055, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, i64 %t1056, i64 %t1057, %"compiler/source:Span" %t1058, %"compiler/source:Span" %t1059, i64 %t1060, i64 %t1061, { i64, ptr } %t1062, { i64, [3 x i64] } %t1011, { i64, ptr } %t1025, i1 %t1026, { i64, ptr } %t1040, { i64, ptr } %t1054)
  call void @llvm.memmove.p0.p0.i64(ptr %l506, ptr %t1055, i64 152, i1 false)
  br label %bb229
bb229:
  %t1068 = load ptr, ptr %l482, !tbaa !29
  call void @llvm.memmove.p0.p0.i64(ptr %t1069, ptr %l506, i64 152, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAssertAsk_3e_2ePush_Hbdaad063a73077b3b5842d615b8c1d82(ptr %v0, ptr %v0, ptr %t1068, ptr %t1069)
  br label %bb230
bb230:
  call void @__olang_scope_close(ptr %s32)
  br label %bb231
bb231:
  call void @__olang_scope_close(ptr %s21)
  br label %bb232
bb232:
  br label %bb276
bb233:
  %t1070 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1070, ptr %l507, !tbaa !29
  store i1 false, ptr %l508, !tbaa !21
  %t1071 = load ptr, ptr %l507, !tbaa !29
  %t1072 = icmp ne ptr %t1071, null
  br i1 %t1072, label %bb234, label %bb235
bb234:
  %t1074 = load ptr, ptr %l507, !tbaa !29
  %t1075 = load i64, ptr %t1074, !range !{i64 0, i64 22}
  %t1077 = icmp eq i64 %t1075, 16
  store i1 %t1077, ptr %l508, !tbaa !21
  br label %bb235
bb235:
  %t1078 = load i1, ptr %l508, !tbaa !21
  br i1 %t1078, label %bb236, label %bb237
bb236:
  %t1079 = load ptr, ptr %l1, !tbaa !29
  %t1081 = getelementptr { i64, [4 x i64] }, ptr %t1079, i32 0, i32 1
  %t1082 = getelementptr { %"compiler/source:Span", ptr }, ptr %t1081, i32 0, i32 0
  %t1083 = load %"compiler/source:Span", ptr %t1082
  store %"compiler/source:Span" %t1083, ptr %l65
  %t1085 = load ptr, ptr %l1, !tbaa !29
  %t1087 = getelementptr { i64, [4 x i64] }, ptr %t1085, i32 0, i32 1
  %t1088 = getelementptr { %"compiler/source:Span", ptr }, ptr %t1087, i32 0, i32 1
  %t1089 = load ptr, ptr %t1088
  store ptr %t1089, ptr %l66, !tbaa !29
  br label %bb238
bb237:
  br label %bb240
bb238:
  %t1091 = load ptr, ptr %l0, !tbaa !29
  %t1092 = load %"compiler/source:Span", ptr %l65
  %t1093 = load ptr, ptr %l66, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eraise(ptr %v0, ptr %v1, ptr %t1091, %"compiler/source:Span" %t1092, ptr %t1093)
  br label %bb239
bb239:
  br label %bb276
bb240:
  %t1097 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1097, ptr %l518, !tbaa !29
  store i1 false, ptr %l519, !tbaa !21
  %t1098 = load ptr, ptr %l518, !tbaa !29
  %t1099 = icmp ne ptr %t1098, null
  br i1 %t1099, label %bb241, label %bb242
bb241:
  %t1101 = load ptr, ptr %l518, !tbaa !29
  %t1102 = load i64, ptr %t1101, !range !{i64 0, i64 22}
  %t1104 = icmp eq i64 %t1102, 19
  store i1 %t1104, ptr %l519, !tbaa !21
  br label %bb242
bb242:
  %t1105 = load i1, ptr %l519, !tbaa !21
  br i1 %t1105, label %bb243, label %bb244
bb243:
  %t1106 = load ptr, ptr %l1, !tbaa !29
  %t1108 = getelementptr { i64, [4 x i64] }, ptr %t1106, i32 0, i32 1
  %t1109 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t1108, i32 0, i32 0
  %t1110 = load %"compiler/source:Span", ptr %t1109
  store %"compiler/source:Span" %t1110, ptr %l67
  %t1112 = load ptr, ptr %l1, !tbaa !29
  %t1114 = getelementptr { i64, [4 x i64] }, ptr %t1112, i32 0, i32 1
  %t1115 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t1114, i32 0, i32 1
  %t1116 = load ptr, ptr %t1115
  store ptr %t1116, ptr %l68, !tbaa !29
  %t1118 = load ptr, ptr %l1, !tbaa !29
  %t1120 = getelementptr { i64, [4 x i64] }, ptr %t1118, i32 0, i32 1
  %t1121 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t1120, i32 0, i32 2
  %t1122 = load i1, ptr %t1121
  store i1 %t1122, ptr %l69, !tbaa !21
  br label %bb245
bb244:
  br label %bb247
bb245:
  %t1124 = load ptr, ptr %l0, !tbaa !29
  %t1125 = load %"compiler/source:Span", ptr %l67
  %t1126 = load ptr, ptr %l68, !tbaa !29
  %t1127 = load i1, ptr %l69, !tbaa !21
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeferStmt(ptr %v0, ptr %v1, ptr %t1124, %"compiler/source:Span" %t1125, ptr %t1126, i1 %t1127)
  br label %bb246
bb246:
  br label %bb276
bb247:
  %t1132 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1132, ptr %l532, !tbaa !29
  store i1 false, ptr %l533, !tbaa !21
  %t1133 = load ptr, ptr %l532, !tbaa !29
  %t1134 = icmp ne ptr %t1133, null
  br i1 %t1134, label %bb248, label %bb249
bb248:
  %t1136 = load ptr, ptr %l532, !tbaa !29
  %t1137 = load i64, ptr %t1136, !range !{i64 0, i64 22}
  %t1139 = icmp eq i64 %t1137, 20
  store i1 %t1139, ptr %l533, !tbaa !21
  br label %bb249
bb249:
  %t1140 = load i1, ptr %l533, !tbaa !21
  br i1 %t1140, label %bb250, label %bb251
bb250:
  %t1141 = load ptr, ptr %l1, !tbaa !29
  %t1143 = getelementptr { i64, [4 x i64] }, ptr %t1141, i32 0, i32 1
  %t1144 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t1143, i32 0, i32 0
  %t1145 = load %"compiler/source:Span", ptr %t1144
  store %"compiler/source:Span" %t1145, ptr %l70
  %t1147 = load ptr, ptr %l1, !tbaa !29
  %t1149 = getelementptr { i64, [4 x i64] }, ptr %t1147, i32 0, i32 1
  %t1150 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t1149, i32 0, i32 1
  %t1151 = load { i64, ptr }, ptr %t1150
  store { i64, ptr } %t1151, ptr %l71, !tbaa !27
  br label %bb252
bb251:
  br label %bb255
bb252:
  %t1153 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1153, ptr %l540, !tbaa !29
  %t1154 = load %"compiler/source:Span", ptr %l70
  store %"compiler/source:Span" %t1154, ptr %l541
  %t1155 = load ptr, ptr %l0, !tbaa !29
  %t1156 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t1157 = load %"compiler/source:Span", ptr %l70
  %t1162 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eblockOf(ptr %v0, ptr %v1, ptr %t1155, { i64, ptr } %t1156, i32 1, %"compiler/source:Span" %t1157)
  store ptr %t1162, ptr %l546
  br label %bb253
bb253:
  store { i64, [3 x i64] } zeroinitializer, ptr %t1163
  %t1164 = getelementptr { i64, [3 x i64] }, ptr %t1163, i32 0, i32 0
  store i64 11, ptr %t1164
  %t1165 = load %"compiler/source:Span", ptr %l541
  %t1166 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t1165, 0
  %t1167 = load ptr, ptr %l546, !tbaa !29
  %t1168 = insertvalue { %"compiler/source:Span", ptr } %t1166, ptr %t1167, 1
  %t1169 = getelementptr { i64, [3 x i64] }, ptr %t1163, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t1168, ptr %t1169
  %t1170 = load { i64, [3 x i64] }, ptr %t1163
  %t1172 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t1170, ptr %t1172
  %t1173 = load ptr, ptr %l540, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t1173, ptr %t1172)
  br label %bb254
bb254:
  br label %bb276
bb255:
  %t1175 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1175, ptr %l549, !tbaa !29
  store i1 false, ptr %l550, !tbaa !21
  %t1176 = load ptr, ptr %l549, !tbaa !29
  %t1177 = icmp ne ptr %t1176, null
  br i1 %t1177, label %bb256, label %bb257
bb256:
  %t1179 = load ptr, ptr %l549, !tbaa !29
  %t1180 = load i64, ptr %t1179, !range !{i64 0, i64 22}
  %t1182 = icmp eq i64 %t1180, 18
  store i1 %t1182, ptr %l550, !tbaa !21
  br label %bb257
bb257:
  %t1183 = load i1, ptr %l550, !tbaa !21
  br i1 %t1183, label %bb258, label %bb259
bb258:
  %t1184 = load ptr, ptr %l1, !tbaa !29
  %t1186 = getelementptr { i64, [4 x i64] }, ptr %t1184, i32 0, i32 1
  %t1187 = getelementptr { %"compiler/source:Span", ptr }, ptr %t1186, i32 0, i32 0
  %t1188 = load %"compiler/source:Span", ptr %t1187
  store %"compiler/source:Span" %t1188, ptr %l72
  %t1190 = load ptr, ptr %l1, !tbaa !29
  %t1192 = getelementptr { i64, [4 x i64] }, ptr %t1190, i32 0, i32 1
  %t1193 = getelementptr { %"compiler/source:Span", ptr }, ptr %t1192, i32 0, i32 1
  %t1194 = load ptr, ptr %t1193
  store ptr %t1194, ptr %l73, !tbaa !29
  br label %bb260
bb259:
  br label %bb262
bb260:
  %t1196 = load ptr, ptr %l0, !tbaa !29
  %t1197 = load %"compiler/source:Span", ptr %l72
  %t1198 = load ptr, ptr %l73, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ejoinStmt(ptr %v0, ptr %v1, ptr %t1196, %"compiler/source:Span" %t1197, ptr %t1198)
  br label %bb261
bb261:
  br label %bb276
bb262:
  %t1202 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1202, ptr %l560, !tbaa !29
  store i1 false, ptr %l561, !tbaa !21
  %t1203 = load ptr, ptr %l560, !tbaa !29
  %t1204 = icmp ne ptr %t1203, null
  br i1 %t1204, label %bb263, label %bb264
bb263:
  %t1206 = load ptr, ptr %l560, !tbaa !29
  %t1207 = load i64, ptr %t1206, !range !{i64 0, i64 22}
  %t1209 = icmp eq i64 %t1207, 17
  store i1 %t1209, ptr %l561, !tbaa !21
  br label %bb264
bb264:
  %t1210 = load i1, ptr %l561, !tbaa !21
  br i1 %t1210, label %bb265, label %bb266
bb265:
  %t1211 = load ptr, ptr %l1, !tbaa !29
  %t1213 = getelementptr { i64, [4 x i64] }, ptr %t1211, i32 0, i32 1
  %t1214 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t1213, i32 0, i32 0
  %t1215 = load %"compiler/source:Span", ptr %t1214
  store %"compiler/source:Span" %t1215, ptr %l74
  %t1217 = load ptr, ptr %l1, !tbaa !29
  %t1219 = getelementptr { i64, [4 x i64] }, ptr %t1217, i32 0, i32 1
  %t1220 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t1219, i32 0, i32 1
  %t1221 = load { i64, ptr }, ptr %t1220
  store { i64, ptr } %t1221, ptr %l75, !tbaa !27
  %t1223 = load ptr, ptr %l1, !tbaa !29
  %t1225 = getelementptr { i64, [4 x i64] }, ptr %t1223, i32 0, i32 1
  %t1226 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t1225, i32 0, i32 2
  %t1227 = load ptr, ptr %t1226
  store ptr %t1227, ptr %l76, !tbaa !29
  br label %bb267
bb266:
  br label %bb269
bb267:
  %t1229 = load ptr, ptr %l0, !tbaa !29
  %t1230 = load %"compiler/source:Span", ptr %l74
  %t1231 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t1232 = load ptr, ptr %l76, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espawnStmt(ptr %v0, ptr %v1, ptr %v1, ptr %t1229, %"compiler/source:Span" %t1230, { i64, ptr } %t1231, ptr %t1232)
  br label %bb268
bb268:
  br label %bb276
bb269:
  br i1 true, label %bb270, label %bb271
bb270:
  br label %bb272
bb271:
  br label %bb275
bb272:
  store %olang.scope zeroinitializer, ptr %s42
  %t1237 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1237, ptr %l574, !tbaa !29
  %t1238 = load ptr, ptr %l1, !tbaa !29
  %t1240 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v1, ptr %t1238)
  store %"compiler/source:Span" %t1240, ptr %l576
  br label %bb273
bb273:
  %t1241 = load ptr, ptr %l574, !tbaa !29
  %t1242 = load %"compiler/source:Span", ptr %l576
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s42, ptr %t1241, %"compiler/source:Span" %t1242, { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d28, i32 0, i32 1) })
  br label %bb274
bb274:
  call void @__olang_scope_close(ptr %s42)
  br label %bb276
bb275:
  call void @__olang_check_failed(ptr @olang_loc_97a078c1fd6401ad_6b439c1864d584b1)
  unreachable
bb276:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmtsOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca %"compiler/check:nullNarrow"
  %l19 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca %"compiler/check:narrowed"
  %l27 = alloca [1 x i32]
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca %"compiler/check:errNarrow"
  %l35 = alloca ptr
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca i64
  %l49 = alloca ptr
  %l59 = alloca i64
  %l62 = alloca i64
  %l85 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l88 = alloca i64
  %l92 = alloca i64
  %l95 = alloca i64
  %l116 = alloca %"compiler/check:nullNarrow"
  %l118 = alloca i1
  %l119 = alloca { i64, ptr }
  %l124 = alloca i1
  %l126 = alloca { i64, ptr }
  %l130 = alloca i1
  %l134 = alloca ptr
  %l135 = alloca i64
  %l138 = alloca %"compiler/check:nullNarrow"
  %l141 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l144 = alloca i64
  %l148 = alloca i64
  %l151 = alloca i64
  %l172 = alloca %"compiler/check:narrowed"
  %l175 = alloca ptr
  %l179 = alloca %"compiler/typed:Local"
  %l182 = alloca { i64, ptr }
  %l188 = alloca i1
  %l190 = alloca { i64, ptr }
  %l195 = alloca i1
  %l199 = alloca ptr
  %l200 = alloca i64
  %l202 = alloca %"compiler/check:narrowed"
  %l207 = alloca i64
  %l211 = alloca i64
  %l214 = alloca i64
  %l235 = alloca %"compiler/check:errNarrow"
  %l238 = alloca i1
  %l239 = alloca { i64, ptr }
  %l242 = alloca ptr
  %l243 = alloca i32
  %l247 = alloca i1
  %l249 = alloca ptr
  %l250 = alloca i64
  %l254 = alloca %"compiler/check:errNarrow"
  %l257 = alloca ptr
  %l262 = alloca { i64, ptr }
  %l267 = alloca i64
  %l269 = alloca i64
  %l274 = alloca i64
  %l275 = alloca i64
  %l278 = alloca i64
  %l281 = alloca ptr
  %l282 = alloca i64
  %l286 = alloca %"compiler/check:nullNarrow"
  %l287 = alloca { i64, ptr }
  %l291 = alloca %"compiler/check:nullNarrow"
  %l293 = alloca %"compiler/check:nullNarrow"
  %l297 = alloca i64
  %l299 = alloca i64
  %l304 = alloca i64
  %l305 = alloca i64
  %l308 = alloca i64
  %l311 = alloca ptr
  %l312 = alloca i64
  %l316 = alloca %"compiler/check:narrowed"
  %l317 = alloca %"compiler/check:narrowed"
  %l324 = alloca i1
  %l330 = alloca ptr
  %l336 = alloca { i64, ptr }
  %l337 = alloca i64
  %l342 = alloca { i64, ptr }
  %l350 = alloca %"compiler/check:nullNarrow"
  %l351 = alloca ptr
  %s3 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %t410 = alloca i64
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t7)
  store ptr %t9, ptr %l49
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l49, !tbaa !29
  store ptr %t10, ptr %l2, !tbaa !29
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t13 = getelementptr %"compiler/check:frame", ptr %t11, i32 0, i32 48
  %t14 = load { i64, ptr }, ptr %t13, !tbaa !27
  store { i64, ptr } %t14, ptr %l3, !tbaa !27
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = getelementptr %"compiler/check:frame", ptr %t16, i32 0, i32 49
  %t19 = load i64, ptr %t18, !tbaa !24
  store i64 %t19, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  %t21 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t25 = load i64, ptr %l6, !tbaa !24
  %t26 = load i64, ptr %l5, !tbaa !24
  %t29 = icmp sgt i64 %t25, %t26
  br i1 %t29, label %bb5, label %bb6
bb5:
  %t31 = load i64, ptr %l7, !tbaa !24
  %t33 = icmp sgt i64 %t31, 0
  br i1 %t33, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l59, !tbaa !24
  br label %bb10
bb7:
  %t35 = load i64, ptr %l6, !tbaa !24
  %t36 = load i64, ptr %l5, !tbaa !24
  %t39 = sub i64 %t35, %t36
  %t40 = load i64, ptr %l7, !tbaa !24
  %t43 = add i64 %t39, %t40
  %t45 = sub i64 %t43, 1
  %t46 = load i64, ptr %l7, !tbaa !24
  %t49 = sdiv i64 %t45, %t46
  store i64 %t49, ptr %l62, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l62, !tbaa !24
  br label %bb9
bb9:
  %t51 = load i64, ptr %l62, !tbaa !24
  store i64 %t51, ptr %l59, !tbaa !24
  br label %bb10
bb10:
  %t52 = load i64, ptr %l59, !tbaa !24
  store i64 %t52, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t53 = load i64, ptr %l9, !tbaa !24
  %t54 = load i64, ptr %l8, !tbaa !24
  %t57 = icmp slt i64 %t53, %t54
  %t59 = xor i1 %t57, true
  br i1 %t59, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb157
bb13:
  br label %bb14
bb14:
  %t61 = load i64, ptr %l5, !tbaa !24
  %t62 = load i64, ptr %l9, !tbaa !24
  %t63 = load i64, ptr %l7, !tbaa !24
  %t66 = mul i64 %t62, %t63
  %t69 = add i64 %t61, %t66
  store i64 %t69, ptr %l10, !tbaa !24
  %t71 = load ptr, ptr %l2, !tbaa !29
  %t72 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t75 = getelementptr %"compiler/check:frame", ptr %t71, i32 0, i32 48
  store { i64, ptr } %t72, ptr %t75, !tbaa !27
  %t76 = load ptr, ptr %l2, !tbaa !29
  %t77 = load i64, ptr %l10, !tbaa !24
  %t79 = add i64 %t77, 1
  %t82 = getelementptr %"compiler/check:frame", ptr %t76, i32 0, i32 49
  store i64 %t79, ptr %t82, !tbaa !24
  %t83 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s3, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t83, ptr %l85
  br label %bb15
bb15:
  %t84 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l85
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t84, ptr %l11
  store i64 0, ptr %l12, !tbaa !24
  %t85 = load ptr, ptr %l2, !tbaa !29
  %t87 = getelementptr %"compiler/check:frame", ptr %t85, i32 0, i32 47
  %t89 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eLen_H4b13e48b0a317e727dbe35330ad8712a(ptr %v0, ptr %t87)
  store i64 %t89, ptr %l88
  br label %bb16
bb16:
  %t90 = load i64, ptr %l88, !tbaa !24
  store i64 %t90, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t91 = load i64, ptr %l13, !tbaa !24
  %t92 = load i64, ptr %l12, !tbaa !24
  %t95 = icmp sgt i64 %t91, %t92
  br i1 %t95, label %bb17, label %bb18
bb17:
  %t97 = load i64, ptr %l14, !tbaa !24
  %t99 = icmp sgt i64 %t97, 0
  br i1 %t99, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l92, !tbaa !24
  br label %bb22
bb19:
  %t101 = load i64, ptr %l13, !tbaa !24
  %t102 = load i64, ptr %l12, !tbaa !24
  %t105 = sub i64 %t101, %t102
  %t106 = load i64, ptr %l14, !tbaa !24
  %t109 = add i64 %t105, %t106
  %t111 = sub i64 %t109, 1
  %t112 = load i64, ptr %l14, !tbaa !24
  %t115 = sdiv i64 %t111, %t112
  store i64 %t115, ptr %l95, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l95, !tbaa !24
  br label %bb21
bb21:
  %t117 = load i64, ptr %l95, !tbaa !24
  store i64 %t117, ptr %l92, !tbaa !24
  br label %bb22
bb22:
  %t118 = load i64, ptr %l92, !tbaa !24
  store i64 %t118, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb23
bb23:
  %t119 = load i64, ptr %l16, !tbaa !24
  %t120 = load i64, ptr %l15, !tbaa !24
  %t123 = icmp slt i64 %t119, %t120
  %t125 = xor i1 %t123, true
  br i1 %t125, label %bb24, label %bb25
bb24:
  br label %bb43
bb25:
  br label %bb26
bb26:
  %t127 = load i64, ptr %l12, !tbaa !24
  %t128 = load i64, ptr %l16, !tbaa !24
  %t129 = load i64, ptr %l14, !tbaa !24
  %t132 = mul i64 %t128, %t129
  %t135 = add i64 %t127, %t132
  store i64 %t135, ptr %l17, !tbaa !24
  %t137 = load ptr, ptr %l2, !tbaa !29
  %t139 = getelementptr %"compiler/check:frame", ptr %t137, i32 0, i32 47
  %t140 = load i64, ptr %l17, !tbaa !24
  %t143 = call %"compiler/check:nullNarrow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eAt__H22e551fb00043bde3f1f8b2c6007f7cb(ptr %v0, ptr %v0, ptr %t139, i64 %t140)
  store %"compiler/check:nullNarrow" %t143, ptr %l116
  br label %bb27
bb27:
  %t144 = load %"compiler/check:nullNarrow", ptr %l116
  store %"compiler/check:nullNarrow" %t144, ptr %l18
  %t145 = getelementptr %"compiler/check:nullNarrow", ptr %l18, i32 0, i32 2
  %t146 = load i1, ptr %t145, !tbaa !21
  br i1 %t146, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l118, !tbaa !21
  br label %bb31
bb29:
  %t148 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t148, ptr %l119, !tbaa !27
  %t149 = load i64, ptr %l10, !tbaa !24
  %t151 = getelementptr { i64, ptr }, ptr %l119, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = getelementptr ptr, ptr %t152, i64 %t149
  %t154 = load ptr, ptr %t153, !tbaa !39
  %t156 = getelementptr %"compiler/check:nullNarrow", ptr %l18, i32 0, i32 0
  %t157 = load { i64, ptr }, ptr %t156, !tbaa !27
  %t160 = call i1 @compiler_2fcheck_2estmtAssigns(ptr %v1, ptr %v0, ptr %t154, { i64, ptr } %t157)
  store i1 %t160, ptr %l124
  br label %bb30
bb30:
  %t161 = load i1, ptr %l124, !tbaa !21
  %t162 = xor i1 %t161, true
  store i1 %t162, ptr %l118, !tbaa !21
  br label %bb31
bb31:
  %t164 = load i1, ptr %l118, !tbaa !21
  br i1 %t164, label %bb32, label %bb33
bb32:
  br label %bb42
bb33:
  br label %bb34
bb34:
  %t165 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t165, ptr %l126, !tbaa !27
  %t166 = load i64, ptr %l10, !tbaa !24
  %t168 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !27
  %t170 = getelementptr ptr, ptr %t169, i64 %t166
  %t171 = load ptr, ptr %t170, !tbaa !39
  %t172 = getelementptr %"compiler/check:nullNarrow", ptr %l18, i32 0, i32 0
  %t173 = load { i64, ptr }, ptr %t172, !tbaa !27
  %t176 = call i1 @compiler_2fcheck_2eassignsWhole(ptr %v1, ptr %v0, ptr %t171, { i64, ptr } %t173)
  store i1 %t176, ptr %l130
  br label %bb35
bb35:
  %t177 = load i1, ptr %l130, !tbaa !21
  br i1 %t177, label %bb36, label %bb37
bb36:
  %t178 = load i64, ptr %l17, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s3, ptr %l11, i64 %t178)
  br label %bb38
bb37:
  %t181 = load ptr, ptr %l2, !tbaa !29
  %t183 = getelementptr %"compiler/check:frame", ptr %t181, i32 0, i32 47
  store ptr %t183, ptr %l134, !tbaa !29
  %t184 = load i64, ptr %l17, !tbaa !24
  store i64 %t184, ptr %l135, !tbaa !24
  %t185 = getelementptr %"compiler/check:nullNarrow", ptr %l18, i32 0, i32 0
  %t186 = load { i64, ptr }, ptr %t185, !tbaa !27
  %t187 = getelementptr %"compiler/check:nullNarrow", ptr %l18, i32 0, i32 1
  %t188 = load i64, ptr %t187, !tbaa !24
  %t191 = call %"compiler/check:nullNarrow" @compiler_2fcheck_3anullNarrow_2ector(ptr %v0, ptr %v0, { i64, ptr } %t186, i64 %t188, i1 true)
  store %"compiler/check:nullNarrow" %t191, ptr %l138
  br label %bb39
bb38:
  br label %bb41
bb39:
  %t192 = load ptr, ptr %l134, !tbaa !29
  %t193 = load i64, ptr %l135, !tbaa !24
  %t194 = load %"compiler/check:nullNarrow", ptr %l138
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eSet_H93968e49180de2bc6256fae5bb61b442(ptr %v0, ptr %v0, ptr %t192, i64 %t193, %"compiler/check:nullNarrow" %t194)
  br label %bb40
bb40:
  br label %bb41
bb41:
  br label %bb42
bb42:
  %t195 = load i64, ptr %l16, !tbaa !24
  %t197 = add i64 %t195, 1
  store i64 %t197, ptr %l16, !tbaa !24
  br label %bb23
bb43:
  %t199 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s3, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t199, ptr %l141
  br label %bb44
bb44:
  %t200 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l141
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t200, ptr %l19
  store i64 0, ptr %l20, !tbaa !24
  %t201 = load ptr, ptr %l2, !tbaa !29
  %t203 = getelementptr %"compiler/check:frame", ptr %t201, i32 0, i32 44
  %t205 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eLen_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %t203)
  store i64 %t205, ptr %l144
  br label %bb45
bb45:
  %t206 = load i64, ptr %l144, !tbaa !24
  store i64 %t206, ptr %l21, !tbaa !24
  store i64 1, ptr %l22, !tbaa !24
  %t207 = load i64, ptr %l21, !tbaa !24
  %t208 = load i64, ptr %l20, !tbaa !24
  %t211 = icmp sgt i64 %t207, %t208
  br i1 %t211, label %bb46, label %bb47
bb46:
  %t213 = load i64, ptr %l22, !tbaa !24
  %t215 = icmp sgt i64 %t213, 0
  br i1 %t215, label %bb48, label %bb49
bb47:
  store i64 0, ptr %l148, !tbaa !24
  br label %bb51
bb48:
  %t217 = load i64, ptr %l21, !tbaa !24
  %t218 = load i64, ptr %l20, !tbaa !24
  %t221 = sub i64 %t217, %t218
  %t222 = load i64, ptr %l22, !tbaa !24
  %t225 = add i64 %t221, %t222
  %t227 = sub i64 %t225, 1
  %t228 = load i64, ptr %l22, !tbaa !24
  %t231 = sdiv i64 %t227, %t228
  store i64 %t231, ptr %l151, !tbaa !24
  br label %bb50
bb49:
  store i64 0, ptr %l151, !tbaa !24
  br label %bb50
bb50:
  %t233 = load i64, ptr %l151, !tbaa !24
  store i64 %t233, ptr %l148, !tbaa !24
  br label %bb51
bb51:
  %t234 = load i64, ptr %l148, !tbaa !24
  store i64 %t234, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb52
bb52:
  store %olang.scope zeroinitializer, ptr %s11
  %t235 = load i64, ptr %l24, !tbaa !24
  %t236 = load i64, ptr %l23, !tbaa !24
  %t239 = icmp slt i64 %t235, %t236
  %t241 = xor i1 %t239, true
  br i1 %t241, label %bb53, label %bb54
bb53:
  call void @__olang_scope_close(ptr %s11)
  br label %bb74
bb54:
  br label %bb55
bb55:
  %t243 = load i64, ptr %l20, !tbaa !24
  %t244 = load i64, ptr %l24, !tbaa !24
  %t245 = load i64, ptr %l22, !tbaa !24
  %t248 = mul i64 %t244, %t245
  %t251 = add i64 %t243, %t248
  store i64 %t251, ptr %l25, !tbaa !24
  %t253 = load ptr, ptr %l2, !tbaa !29
  %t255 = getelementptr %"compiler/check:frame", ptr %t253, i32 0, i32 44
  %t256 = load i64, ptr %l25, !tbaa !24
  %t259 = call %"compiler/check:narrowed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eAt_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %t255, i64 %t256)
  store %"compiler/check:narrowed" %t259, ptr %l172
  br label %bb56
bb56:
  %t260 = load %"compiler/check:narrowed", ptr %l172
  store %"compiler/check:narrowed" %t260, ptr %l26
  %t261 = getelementptr %"compiler/check:narrowed", ptr %l26, i32 0, i32 5
  %t262 = load i1, ptr %t261, !tbaa !21
  br i1 %t262, label %bb57, label %bb58
bb57:
  call void @__olang_scope_close(ptr %s11)
  br label %bb73
bb58:
  br label %bb59
bb59:
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t266 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t264)
  store ptr %t266, ptr %l175
  br label %bb60
bb60:
  %t267 = load ptr, ptr %l175, !tbaa !29
  %t269 = getelementptr %"compiler/typed:Body", ptr %t267, i32 0, i32 7
  %t270 = getelementptr %"compiler/check:narrowed", ptr %l26, i32 0, i32 0
  %t271 = load i64, ptr %t270, !tbaa !24
  %t274 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t269, i64 %t271)
  store %"compiler/typed:Local" %t274, ptr %l179
  br label %bb61
bb61:
  %t275 = getelementptr %"compiler/typed:Local", ptr %l179, i32 0, i32 0
  %t276 = load i32, ptr %t275, !tbaa !23
  %t278 = insertvalue [1 x i32] undef, i32 %t276, 0
  store [1 x i32] %t278, ptr %l27
  %t280 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t280, ptr %l182, !tbaa !27
  %t281 = load i64, ptr %l10, !tbaa !24
  %t283 = getelementptr { i64, ptr }, ptr %l182, i32 0, i32 1
  %t284 = load ptr, ptr %t283, !tbaa !27
  %t285 = getelementptr ptr, ptr %t284, i64 %t281
  %t286 = load ptr, ptr %t285, !tbaa !39
  %t289 = insertvalue { i64, ptr } undef, i64 1, 0
  %t290 = insertvalue { i64, ptr } %t289, ptr %l27, 1
  %t293 = call i1 @compiler_2fcheck_2estmtAssigns(ptr %v1, ptr %s11, ptr %t286, { i64, ptr } %t290)
  store i1 %t293, ptr %l188
  br label %bb62
bb62:
  %t294 = load i1, ptr %l188, !tbaa !21
  %t295 = xor i1 %t294, true
  br i1 %t295, label %bb63, label %bb64
bb63:
  call void @__olang_scope_close(ptr %s11)
  br label %bb73
bb64:
  br label %bb65
bb65:
  %t297 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t297, ptr %l190, !tbaa !27
  %t298 = load i64, ptr %l10, !tbaa !24
  %t300 = getelementptr { i64, ptr }, ptr %l190, i32 0, i32 1
  %t301 = load ptr, ptr %t300, !tbaa !27
  %t302 = getelementptr ptr, ptr %t301, i64 %t298
  %t303 = load ptr, ptr %t302, !tbaa !39
  %t305 = insertvalue { i64, ptr } undef, i64 1, 0
  %t306 = insertvalue { i64, ptr } %t305, ptr %l27, 1
  %t309 = call i1 @compiler_2fcheck_2eassignsWhole(ptr %v1, ptr %s11, ptr %t303, { i64, ptr } %t306)
  store i1 %t309, ptr %l195
  br label %bb66
bb66:
  %t310 = load i1, ptr %l195, !tbaa !21
  br i1 %t310, label %bb67, label %bb68
bb67:
  %t311 = load i64, ptr %l25, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s3, ptr %l19, i64 %t311)
  br label %bb69
bb68:
  %t314 = load ptr, ptr %l2, !tbaa !29
  %t316 = getelementptr %"compiler/check:frame", ptr %t314, i32 0, i32 44
  store ptr %t316, ptr %l199, !tbaa !29
  %t317 = load i64, ptr %l25, !tbaa !24
  store i64 %t317, ptr %l200, !tbaa !24
  %t318 = load %"compiler/check:narrowed", ptr %l26
  %t320 = call %"compiler/check:narrowed" @compiler_2fcheck_2ecompiler_2fcheck_3anarrowed_2eKilled(%"compiler/check:narrowed" %t318)
  store %"compiler/check:narrowed" %t320, ptr %l202
  br label %bb70
bb69:
  br label %bb72
bb70:
  %t321 = load ptr, ptr %l199, !tbaa !29
  %t322 = load i64, ptr %l200, !tbaa !24
  %t323 = load %"compiler/check:narrowed", ptr %l202
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eSetAt_Hd90ea4a0afde5538aa0fe5c36a170321(ptr %v0, ptr %t321, i64 %t322, %"compiler/check:narrowed" %t323)
  br label %bb71
bb71:
  br label %bb72
bb72:
  call void @__olang_scope_close(ptr %s11)
  br label %bb73
bb73:
  %t324 = load i64, ptr %l24, !tbaa !24
  %t326 = add i64 %t324, 1
  store i64 %t326, ptr %l24, !tbaa !24
  br label %bb52
bb74:
  store i64 0, ptr %l28, !tbaa !24
  %t328 = load ptr, ptr %l2, !tbaa !29
  %t330 = getelementptr %"compiler/check:frame", ptr %t328, i32 0, i32 56
  %t332 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eLen__H3cdfcddd9c493bd8bcefc7b766e0438b(ptr %v0, ptr %t330)
  store i64 %t332, ptr %l207
  br label %bb75
bb75:
  %t333 = load i64, ptr %l207, !tbaa !24
  store i64 %t333, ptr %l29, !tbaa !24
  store i64 1, ptr %l30, !tbaa !24
  %t334 = load i64, ptr %l29, !tbaa !24
  %t335 = load i64, ptr %l28, !tbaa !24
  %t338 = icmp sgt i64 %t334, %t335
  br i1 %t338, label %bb76, label %bb77
bb76:
  %t340 = load i64, ptr %l30, !tbaa !24
  %t342 = icmp sgt i64 %t340, 0
  br i1 %t342, label %bb78, label %bb79
bb77:
  store i64 0, ptr %l211, !tbaa !24
  br label %bb81
bb78:
  %t344 = load i64, ptr %l29, !tbaa !24
  %t345 = load i64, ptr %l28, !tbaa !24
  %t348 = sub i64 %t344, %t345
  %t349 = load i64, ptr %l30, !tbaa !24
  %t352 = add i64 %t348, %t349
  %t354 = sub i64 %t352, 1
  %t355 = load i64, ptr %l30, !tbaa !24
  %t358 = sdiv i64 %t354, %t355
  store i64 %t358, ptr %l214, !tbaa !24
  br label %bb80
bb79:
  store i64 0, ptr %l214, !tbaa !24
  br label %bb80
bb80:
  %t360 = load i64, ptr %l214, !tbaa !24
  store i64 %t360, ptr %l211, !tbaa !24
  br label %bb81
bb81:
  %t361 = load i64, ptr %l211, !tbaa !24
  store i64 %t361, ptr %l31, !tbaa !24
  store i64 0, ptr %l32, !tbaa !24
  br label %bb82
bb82:
  store %olang.scope zeroinitializer, ptr %s18
  %t362 = load i64, ptr %l32, !tbaa !24
  %t363 = load i64, ptr %l31, !tbaa !24
  %t366 = icmp slt i64 %t362, %t363
  %t368 = xor i1 %t366, true
  br i1 %t368, label %bb83, label %bb84
bb83:
  call void @__olang_scope_close(ptr %s18)
  br label %bb101
bb84:
  br label %bb85
bb85:
  %t370 = load i64, ptr %l28, !tbaa !24
  %t371 = load i64, ptr %l32, !tbaa !24
  %t372 = load i64, ptr %l30, !tbaa !24
  %t375 = mul i64 %t371, %t372
  %t378 = add i64 %t370, %t375
  store i64 %t378, ptr %l33, !tbaa !24
  %t380 = load ptr, ptr %l2, !tbaa !29
  %t382 = getelementptr %"compiler/check:frame", ptr %t380, i32 0, i32 56
  %t383 = load i64, ptr %l33, !tbaa !24
  %t386 = call %"compiler/check:errNarrow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eAt_3ccompiler_2fcheck_3aerrNarrow_3e(ptr %v0, ptr %t382, i64 %t383)
  store %"compiler/check:errNarrow" %t386, ptr %l235
  br label %bb86
bb86:
  %t387 = load %"compiler/check:errNarrow", ptr %l235
  store %"compiler/check:errNarrow" %t387, ptr %l34
  %t388 = getelementptr %"compiler/check:errNarrow", ptr %l34, i32 0, i32 3
  %t389 = load i1, ptr %t388, !tbaa !21
  %t391 = xor i1 %t389, true
  br i1 %t391, label %bb87, label %bb88
bb87:
  %t393 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t393, ptr %l239, !tbaa !27
  %t394 = load i64, ptr %l10, !tbaa !24
  %t396 = getelementptr { i64, ptr }, ptr %l239, i32 0, i32 1
  %t397 = load ptr, ptr %t396, !tbaa !27
  %t398 = getelementptr ptr, ptr %t397, i64 %t394
  %t399 = load ptr, ptr %t398, !tbaa !39
  store ptr %t399, ptr %l242, !tbaa !29
  %t401 = getelementptr %"compiler/check:errNarrow", ptr %l34, i32 0, i32 0
  %t402 = load i32, ptr %t401, !tbaa !23
  store i32 %t402, ptr %l243, !tbaa !23
  %t403 = icmp sge i64 1, 0
  br i1 %t403, label %bb89, label %bb90
bb88:
  store i1 false, ptr %l238, !tbaa !21
  br label %bb94
bb89:
  %t405 = icmp sle i64 1, 2305843009213693951
  br i1 %t405, label %bb91, label %bb92
bb90:
  call void @__olang_check_failed(ptr @olang_loc_f0430e4b284237b0_c6243626a46be64)
  unreachable
bb91:
  %t407 = mul i64 1, 4
  %t408 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t407)
  %t409 = load i32, ptr %l243, !tbaa !23
  store i64 0, ptr %t410
  br label %fill.411
fill.411:
  %t414 = load i64, ptr %t410
  %t415 = icmp slt i64 %t414, 1
  br i1 %t415, label %fillb.412, label %filld.413
fillb.412:
  %t416 = getelementptr i32, ptr %t408, i64 %t414
  store i32 %t409, ptr %t416
  %t417 = add i64 %t414, 1
  store i64 %t417, ptr %t410
  br label %fill.411
filld.413:
  %t418 = insertvalue { i64, ptr } undef, i64 1, 0
  %t419 = insertvalue { i64, ptr } %t418, ptr %t408, 1
  %t420 = load ptr, ptr %l242, !tbaa !29
  %t422 = call i1 @compiler_2fcheck_2estmtAssigns(ptr %v1, ptr %s18, ptr %t420, { i64, ptr } %t419)
  store i1 %t422, ptr %l247
  br label %bb93
bb92:
  call void @__olang_check_failed(ptr @olang_loc_f0430e4b284237b0_c6243626a46be64)
  unreachable
bb93:
  %t423 = load i1, ptr %l247, !tbaa !21
  store i1 %t423, ptr %l238, !tbaa !21
  br label %bb94
bb94:
  %t424 = load i1, ptr %l238, !tbaa !21
  br i1 %t424, label %bb95, label %bb96
bb95:
  store %olang.scope zeroinitializer, ptr %s19
  %t425 = load ptr, ptr %l2, !tbaa !29
  %t427 = getelementptr %"compiler/check:frame", ptr %t425, i32 0, i32 56
  store ptr %t427, ptr %l249, !tbaa !29
  %t428 = load i64, ptr %l33, !tbaa !24
  store i64 %t428, ptr %l250, !tbaa !24
  %t429 = getelementptr %"compiler/check:errNarrow", ptr %l34, i32 0, i32 0
  %t430 = load i32, ptr %t429, !tbaa !23
  %t431 = getelementptr %"compiler/check:errNarrow", ptr %l34, i32 0, i32 1
  %t432 = load i32, ptr %t431, !tbaa !23
  %t433 = getelementptr %"compiler/check:errNarrow", ptr %l34, i32 0, i32 2
  %t434 = load i64, ptr %t433, !tbaa !24
  %t438 = call %"compiler/check:errNarrow" @compiler_2fcheck_3aerrNarrow_2ector(ptr %s19, i32 %t430, i32 %t432, i64 %t434, i1 true)
  store %"compiler/check:errNarrow" %t438, ptr %l254
  br label %bb97
bb96:
  br label %bb99
bb97:
  %t439 = load ptr, ptr %l249, !tbaa !29
  %t440 = load i64, ptr %l250, !tbaa !24
  %t441 = load %"compiler/check:errNarrow", ptr %l254
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eSetA_H34a7475a189e9b126454728216b32261(ptr %v0, ptr %t439, i64 %t440, %"compiler/check:errNarrow" %t441)
  br label %bb98
bb98:
  call void @__olang_scope_close(ptr %s19)
  br label %bb99
bb99:
  call void @__olang_scope_close(ptr %s18)
  br label %bb100
bb100:
  %t442 = load i64, ptr %l32, !tbaa !24
  %t444 = add i64 %t442, 1
  store i64 %t444, ptr %l32, !tbaa !24
  br label %bb82
bb101:
  %t446 = load ptr, ptr %l2, !tbaa !29
  store ptr %t446, ptr %l257, !tbaa !29
  %t447 = icmp sge i64 0, 0
  br i1 %t447, label %bb102, label %bb103
bb102:
  %t449 = icmp sle i64 0, 2305843009213693951
  br i1 %t449, label %bb104, label %bb105
bb103:
  call void @__olang_check_failed(ptr @olang_loc_28ca8569d2f90b5d_c88a44871853971)
  unreachable
bb104:
  %t451 = mul i64 0, 4
  %t452 = insertvalue { i64, ptr } undef, i64 0, 0
  %t453 = insertvalue { i64, ptr } %t452, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t455 = load ptr, ptr %l257, !tbaa !29
  %t456 = getelementptr %"compiler/check:frame", ptr %t455, i32 0, i32 46
  store { i64, ptr } %t453, ptr %t456, !tbaa !27
  %t457 = load ptr, ptr %l0, !tbaa !29
  %t458 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t458, ptr %l262, !tbaa !27
  %t459 = load i64, ptr %l10, !tbaa !24
  %t461 = getelementptr { i64, ptr }, ptr %l262, i32 0, i32 1
  %t462 = load ptr, ptr %t461, !tbaa !27
  %t463 = getelementptr ptr, ptr %t462, i64 %t459
  %t464 = load ptr, ptr %t463, !tbaa !39
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmt(ptr %v0, ptr %v1, ptr %t457, ptr %t464)
  br label %bb106
bb105:
  call void @__olang_check_failed(ptr @olang_loc_28ca8569d2f90b5d_c88a44871853971)
  unreachable
bb106:
  store ptr %l11, ptr %l35, !tbaa !29
  store i64 0, ptr %l36, !tbaa !24
  br label %bb107
bb107:
  %t469 = load i64, ptr %l36, !tbaa !24
  store i64 %t469, ptr %l267, !tbaa !24
  %t470 = load ptr, ptr %l35, !tbaa !29
  %t472 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s3, ptr %t470)
  store i64 %t472, ptr %l269
  br label %bb108
bb108:
  %t473 = load i64, ptr %l267, !tbaa !24
  %t474 = load i64, ptr %l269, !tbaa !24
  %t475 = icmp slt i64 %t473, %t474
  %t477 = xor i1 %t475, true
  br i1 %t477, label %bb109, label %bb110
bb109:
  br label %bb122
bb110:
  br label %bb111
bb111:
  %t479 = load ptr, ptr %l35, !tbaa !29
  %t480 = load i64, ptr %l36, !tbaa !24
  %t483 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s3, ptr %t479, i64 %t480)
  store i64 %t483, ptr %l274
  br label %bb112
bb112:
  %t484 = load i64, ptr %l274, !tbaa !24
  store i64 %t484, ptr %l37, !tbaa !24
  %t485 = load i64, ptr %l37, !tbaa !24
  store i64 %t485, ptr %l275, !tbaa !24
  %t486 = load ptr, ptr %l2, !tbaa !29
  %t488 = getelementptr %"compiler/check:frame", ptr %t486, i32 0, i32 47
  %t490 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eLen_H4b13e48b0a317e727dbe35330ad8712a(ptr %v0, ptr %t488)
  store i64 %t490, ptr %l278
  br label %bb113
bb113:
  %t491 = load i64, ptr %l275, !tbaa !24
  %t492 = load i64, ptr %l278, !tbaa !24
  %t493 = icmp slt i64 %t491, %t492
  br i1 %t493, label %bb114, label %bb115
bb114:
  store %olang.scope zeroinitializer, ptr %s23
  %t495 = load ptr, ptr %l2, !tbaa !29
  %t497 = getelementptr %"compiler/check:frame", ptr %t495, i32 0, i32 47
  store ptr %t497, ptr %l281, !tbaa !29
  %t498 = load i64, ptr %l37, !tbaa !24
  store i64 %t498, ptr %l282, !tbaa !24
  %t499 = load ptr, ptr %l2, !tbaa !29
  %t501 = getelementptr %"compiler/check:frame", ptr %t499, i32 0, i32 47
  %t502 = load i64, ptr %l37, !tbaa !24
  %t505 = call %"compiler/check:nullNarrow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eAt__H22e551fb00043bde3f1f8b2c6007f7cb(ptr %v0, ptr %v0, ptr %t501, i64 %t502)
  store %"compiler/check:nullNarrow" %t505, ptr %l286
  br label %bb116
bb115:
  br label %bb120
bb116:
  %t506 = getelementptr %"compiler/check:nullNarrow", ptr %l286, i32 0, i32 0
  %t507 = load { i64, ptr }, ptr %t506, !tbaa !27
  store { i64, ptr } %t507, ptr %l287, !tbaa !27
  %t508 = load ptr, ptr %l2, !tbaa !29
  %t510 = getelementptr %"compiler/check:frame", ptr %t508, i32 0, i32 47
  %t511 = load i64, ptr %l37, !tbaa !24
  %t514 = call %"compiler/check:nullNarrow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eAt__H22e551fb00043bde3f1f8b2c6007f7cb(ptr %v0, ptr %s23, ptr %t510, i64 %t511)
  store %"compiler/check:nullNarrow" %t514, ptr %l291
  br label %bb117
bb117:
  %t515 = getelementptr %"compiler/check:nullNarrow", ptr %l291, i32 0, i32 1
  %t516 = load i64, ptr %t515, !tbaa !24
  %t517 = load { i64, ptr }, ptr %l287, !tbaa !27
  %t519 = call %"compiler/check:nullNarrow" @compiler_2fcheck_3anullNarrow_2ector(ptr %v0, ptr %v0, { i64, ptr } %t517, i64 %t516, i1 true)
  store %"compiler/check:nullNarrow" %t519, ptr %l293
  br label %bb118
bb118:
  %t520 = load ptr, ptr %l281, !tbaa !29
  %t521 = load i64, ptr %l282, !tbaa !24
  %t522 = load %"compiler/check:nullNarrow", ptr %l293
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eSet_H93968e49180de2bc6256fae5bb61b442(ptr %v0, ptr %v0, ptr %t520, i64 %t521, %"compiler/check:nullNarrow" %t522)
  br label %bb119
bb119:
  call void @__olang_scope_close(ptr %s23)
  br label %bb120
bb120:
  br label %bb121
bb121:
  %t523 = load i64, ptr %l36, !tbaa !24
  %t525 = add i64 %t523, 1
  store i64 %t525, ptr %l36, !tbaa !24
  br label %bb107
bb122:
  store ptr %l19, ptr %l38, !tbaa !29
  store i64 0, ptr %l39, !tbaa !24
  br label %bb123
bb123:
  %t528 = load i64, ptr %l39, !tbaa !24
  store i64 %t528, ptr %l297, !tbaa !24
  %t529 = load ptr, ptr %l38, !tbaa !29
  %t531 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s3, ptr %t529)
  store i64 %t531, ptr %l299
  br label %bb124
bb124:
  %t532 = load i64, ptr %l297, !tbaa !24
  %t533 = load i64, ptr %l299, !tbaa !24
  %t534 = icmp slt i64 %t532, %t533
  %t536 = xor i1 %t534, true
  br i1 %t536, label %bb125, label %bb126
bb125:
  br label %bb137
bb126:
  br label %bb127
bb127:
  %t538 = load ptr, ptr %l38, !tbaa !29
  %t539 = load i64, ptr %l39, !tbaa !24
  %t542 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s3, ptr %t538, i64 %t539)
  store i64 %t542, ptr %l304
  br label %bb128
bb128:
  %t543 = load i64, ptr %l304, !tbaa !24
  store i64 %t543, ptr %l40, !tbaa !24
  %t544 = load i64, ptr %l40, !tbaa !24
  store i64 %t544, ptr %l305, !tbaa !24
  %t545 = load ptr, ptr %l2, !tbaa !29
  %t547 = getelementptr %"compiler/check:frame", ptr %t545, i32 0, i32 44
  %t549 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eLen_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %t547)
  store i64 %t549, ptr %l308
  br label %bb129
bb129:
  %t550 = load i64, ptr %l305, !tbaa !24
  %t551 = load i64, ptr %l308, !tbaa !24
  %t552 = icmp slt i64 %t550, %t551
  br i1 %t552, label %bb130, label %bb131
bb130:
  %t554 = load ptr, ptr %l2, !tbaa !29
  %t556 = getelementptr %"compiler/check:frame", ptr %t554, i32 0, i32 44
  store ptr %t556, ptr %l311, !tbaa !29
  %t557 = load i64, ptr %l40, !tbaa !24
  store i64 %t557, ptr %l312, !tbaa !24
  %t558 = load ptr, ptr %l2, !tbaa !29
  %t560 = getelementptr %"compiler/check:frame", ptr %t558, i32 0, i32 44
  %t561 = load i64, ptr %l40, !tbaa !24
  %t564 = call %"compiler/check:narrowed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eAt_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %t560, i64 %t561)
  store %"compiler/check:narrowed" %t564, ptr %l316
  br label %bb132
bb131:
  br label %bb135
bb132:
  %t565 = load %"compiler/check:narrowed", ptr %l316
  %t566 = call %"compiler/check:narrowed" @compiler_2fcheck_2ecompiler_2fcheck_3anarrowed_2eKilled(%"compiler/check:narrowed" %t565)
  store %"compiler/check:narrowed" %t566, ptr %l317
  br label %bb133
bb133:
  %t567 = load ptr, ptr %l311, !tbaa !29
  %t568 = load i64, ptr %l312, !tbaa !24
  %t569 = load %"compiler/check:narrowed", ptr %l317
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eSetAt_Hd90ea4a0afde5538aa0fe5c36a170321(ptr %v0, ptr %t567, i64 %t568, %"compiler/check:narrowed" %t569)
  br label %bb134
bb134:
  br label %bb135
bb135:
  br label %bb136
bb136:
  %t570 = load i64, ptr %l39, !tbaa !24
  %t572 = add i64 %t570, 1
  store i64 %t572, ptr %l39, !tbaa !24
  br label %bb123
bb137:
  %t574 = load ptr, ptr %l2, !tbaa !29
  %t576 = getelementptr %"compiler/check:frame", ptr %t574, i32 0, i32 46
  %t577 = load { i64, ptr }, ptr %t576, !tbaa !27
  %t579 = extractvalue { i64, ptr } %t577, 0
  %t581 = icmp sgt i64 %t579, 0
  br i1 %t581, label %bb138, label %bb139
bb138:
  %t583 = load ptr, ptr %l2, !tbaa !29
  %t585 = getelementptr %"compiler/check:frame", ptr %t583, i32 0, i32 46
  %t586 = load { i64, ptr }, ptr %t585, !tbaa !27
  %t588 = extractvalue { i64, ptr } %t586, 0
  %t590 = icmp eq i64 %t588, 1
  store i1 %t590, ptr %l324, !tbaa !21
  br label %bb140
bb139:
  store i1 false, ptr %l324, !tbaa !21
  br label %bb140
bb140:
  %t592 = load i1, ptr %l324, !tbaa !21
  br i1 %t592, label %bb141, label %bb142
bb141:
  %t593 = load ptr, ptr %l2, !tbaa !29
  %t595 = getelementptr %"compiler/check:frame", ptr %t593, i32 0, i32 47
  store ptr %t595, ptr %l330, !tbaa !29
  %t596 = load ptr, ptr %l2, !tbaa !29
  %t598 = getelementptr %"compiler/check:frame", ptr %t596, i32 0, i32 46
  %t599 = load { i64, ptr }, ptr %t598, !tbaa !27
  store { i64, ptr } %t599, ptr %l41, !tbaa !27
  store i64 0, ptr %l42, !tbaa !24
  %t601 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t603 = extractvalue { i64, ptr } %t601, 0
  store i64 %t603, ptr %l43, !tbaa !24
  %t605 = load i64, ptr %l43, !tbaa !24
  %t607 = mul i64 %t605, 4
  %t608 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t607)
  %t609 = insertvalue { i64, ptr } undef, i64 %t605, 0
  %t610 = insertvalue { i64, ptr } %t609, ptr %t608, 1
  store { i64, ptr } %t610, ptr %l336, !tbaa !27
  store i64 0, ptr %l337, !tbaa !24
  br label %bb143
bb142:
  br label %bb155
bb143:
  %t611 = load i64, ptr %l42, !tbaa !24
  %t612 = load i64, ptr %l43, !tbaa !24
  %t615 = icmp slt i64 %t611, %t612
  %t617 = xor i1 %t615, true
  br i1 %t617, label %bb144, label %bb145
bb144:
  br label %bb148
bb145:
  br label %bb146
bb146:
  %t619 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t619, ptr %l342, !tbaa !27
  %t620 = load i64, ptr %l42, !tbaa !24
  %t622 = getelementptr { i64, ptr }, ptr %l342, i32 0, i32 1
  %t623 = load ptr, ptr %t622, !tbaa !27
  %t624 = getelementptr i32, ptr %t623, i64 %t620
  %t625 = load i32, ptr %t624, !tbaa !33
  %t629 = load i64, ptr %l337, !tbaa !24
  %t630 = getelementptr { i64, ptr }, ptr %l336, i32 0, i32 1
  %t631 = load ptr, ptr %t630, !tbaa !27
  %t632 = getelementptr i32, ptr %t631, i64 %t629
  store i32 %t625, ptr %t632, !tbaa !33
  %t633 = load i64, ptr %l337, !tbaa !24
  %t634 = add i64 %t633, 1
  store i64 %t634, ptr %l337, !tbaa !24
  br label %bb147
bb147:
  %t635 = load i64, ptr %l42, !tbaa !24
  %t637 = add i64 %t635, 1
  store i64 %t637, ptr %l42, !tbaa !24
  br label %bb143
bb148:
  %t639 = load ptr, ptr %l2, !tbaa !29
  %t641 = getelementptr %"compiler/check:frame", ptr %t639, i32 0, i32 7
  %t642 = load i64, ptr %t641, !tbaa !24
  %t643 = load { i64, ptr }, ptr %l336, !tbaa !27
  %t645 = call %"compiler/check:nullNarrow" @compiler_2fcheck_3anullNarrow_2ector(ptr %v0, ptr %v0, { i64, ptr } %t643, i64 %t642, i1 false)
  store %"compiler/check:nullNarrow" %t645, ptr %l350
  br label %bb149
bb149:
  %t646 = load ptr, ptr %l330, !tbaa !29
  %t647 = load %"compiler/check:nullNarrow", ptr %l350
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2ePus_H6cb9d90d121a5c1d081cb085b656665f(ptr %v0, ptr %v0, ptr %t646, %"compiler/check:nullNarrow" %t647)
  br label %bb150
bb150:
  %t648 = load ptr, ptr %l2, !tbaa !29
  store ptr %t648, ptr %l351, !tbaa !29
  %t649 = icmp sge i64 0, 0
  br i1 %t649, label %bb151, label %bb152
bb151:
  %t651 = icmp sle i64 0, 2305843009213693951
  br i1 %t651, label %bb153, label %bb154
bb152:
  call void @__olang_check_failed(ptr @olang_loc_8296d6abcbfdbd1e_e4e071066943c4d2)
  unreachable
bb153:
  %t653 = mul i64 0, 4
  %t654 = insertvalue { i64, ptr } undef, i64 0, 0
  %t655 = insertvalue { i64, ptr } %t654, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t657 = load ptr, ptr %l351, !tbaa !29
  %t658 = getelementptr %"compiler/check:frame", ptr %t657, i32 0, i32 46
  store { i64, ptr } %t655, ptr %t658, !tbaa !27
  br label %bb155
bb154:
  call void @__olang_check_failed(ptr @olang_loc_8296d6abcbfdbd1e_e4e071066943c4d2)
  unreachable
bb155:
  call void @__olang_scope_close(ptr %s3)
  br label %bb156
bb156:
  %t659 = load i64, ptr %l9, !tbaa !24
  %t661 = add i64 %t659, 1
  store i64 %t661, ptr %l9, !tbaa !24
  br label %bb11
bb157:
  %t663 = load ptr, ptr %l2, !tbaa !29
  %t664 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t667 = getelementptr %"compiler/check:frame", ptr %t663, i32 0, i32 48
  store { i64, ptr } %t664, ptr %t667, !tbaa !27
  %t668 = load ptr, ptr %l2, !tbaa !29
  %t669 = load i64, ptr %l4, !tbaa !24
  %t672 = getelementptr %"compiler/check:frame", ptr %t668, i32 0, i32 49
  store i64 %t669, ptr %t672, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estrBytes(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
  store { i64, ptr } %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t7 = call { i64, ptr } @compiler_2fscan_2eLiteralBytes(ptr %v0, ptr %v0, { i64, ptr } %t6)
  store { i64, ptr } %t7, ptr %l5
  br label %bb2
bb2:
  %t8 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 0
  %t10 = extractvalue { i64, ptr } %t8, 1
  %t11 = mul i64 %t9, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t10, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estrReceivers(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, [2 x i64] }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l22 = alloca i64
  %l26 = alloca i64
  %l29 = alloca i64
  %l50 = alloca i64
  %l52 = alloca i1
  %l54 = alloca ptr
  %l56 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l57 = alloca i1
  %l62 = alloca ptr
  %l71 = alloca i64
  %l75 = alloca ptr
  %l79 = alloca { i64, ptr }
  %l83 = alloca i1
  %l85 = alloca i1
  %l87 = alloca i1
  %l89 = alloca i1
  %l91 = alloca i1
  %l94 = alloca i1
  %l100 = alloca i64
  %l106 = alloca ptr
  %l122 = alloca i64
  %l123 = alloca { i64, ptr }
  %l124 = alloca i64
  %l127 = alloca i64
  %l128 = alloca i64
  %l134 = alloca i64
  %l135 = alloca i32
  %l138 = alloca i64
  %l148 = alloca ptr
  %l154 = alloca ptr
  %l162 = alloca { i64, [3 x i64] }
  %l163 = alloca %"compiler/msgs:Msg"
  %l164 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %t306 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %s0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l19
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l19
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l1
  store i64 0, ptr %l2, !tbaa !24
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/check:Checker", ptr %t3, i32 0, i32 12
  %t7 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t5)
  store i64 %t7, ptr %l22
  br label %bb2
bb2:
  %t8 = load i64, ptr %l22, !tbaa !24
  store i64 %t8, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb8
bb5:
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l4, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l29, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb7
bb7:
  %t35 = load i64, ptr %l29, !tbaa !24
  store i64 %t35, ptr %l26, !tbaa !24
  br label %bb8
bb8:
  %t36 = load i64, ptr %l26, !tbaa !24
  store i64 %t36, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t37 = load i64, ptr %l6, !tbaa !24
  %t38 = load i64, ptr %l5, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb76
bb11:
  br label %bb12
bb12:
  %t45 = load i64, ptr %l2, !tbaa !24
  %t46 = load i64, ptr %l6, !tbaa !24
  %t47 = load i64, ptr %l4, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  store i64 %t53, ptr %l7, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/check:Checker", ptr %t55, i32 0, i32 17
  %t58 = load i64, ptr %l7, !tbaa !24
  %t61 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t57, i64 %t58)
  store i64 %t61, ptr %l50
  br label %bb13
bb13:
  %t62 = load i64, ptr %l50, !tbaa !24
  %t63 = icmp ne i64 %t62, 2
  br i1 %t63, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l52, !tbaa !21
  br label %bb18
bb15:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/check:Checker", ptr %t65, i32 0, i32 64
  store ptr %t67, ptr %l54, !tbaa !29
  %t68 = load i64, ptr %l7, !tbaa !24
  %t70 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s2, i64 %t68, i64 0)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t70, ptr %l56
  br label %bb16
bb16:
  %t71 = load ptr, ptr %l54, !tbaa !29
  %t72 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l56
  %t73 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t71, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t72)
  store i1 %t73, ptr %l57
  br label %bb17
bb17:
  %t74 = load i1, ptr %l57, !tbaa !21
  %t75 = xor i1 %t74, true
  store i1 %t75, ptr %l52, !tbaa !21
  br label %bb18
bb18:
  %t77 = load i1, ptr %l52, !tbaa !21
  br i1 %t77, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s2)
  br label %bb75
bb20:
  br label %bb21
bb21:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/check:Checker", ptr %t78, i32 0, i32 12
  %t81 = load i64, ptr %l7, !tbaa !24
  %t84 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t80, i64 %t81)
  store ptr %t84, ptr %l62
  br label %bb22
bb22:
  %t85 = load ptr, ptr %l62, !tbaa !29
  %t87 = getelementptr %"compiler/typed:Body", ptr %t85, i32 0, i32 1
  %t88 = load { i64, [2 x i64] }, ptr %t87
  store { i64, [2 x i64] } %t88, ptr %l8
  %t90 = load { i64, [2 x i64] }, ptr %l8
  %t92 = extractvalue { i64, [2 x i64] } %t90, 0
  %t93 = icmp eq i64 %t92, 0
  br i1 %t93, label %bb23, label %bb24
bb23:
  %t95 = getelementptr { i64, [2 x i64] }, ptr %l8, i32 0, i32 1
  %t96 = getelementptr { i64 }, ptr %t95, i32 0, i32 0
  %t97 = load i64, ptr %t96
  store i64 %t97, ptr %l9, !tbaa !24
  br label %bb25
bb24:
  br label %bb69
bb25:
  store %olang.scope zeroinitializer, ptr %s4
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/check:Checker", ptr %t99, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t103 = load i64, ptr %l9, !tbaa !24
  %t106 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t102, i64 %t103)
  store i64 %t106, ptr %l71
  br label %bb26
bb26:
  %t107 = load i64, ptr %l71, !tbaa !24
  store i64 %t107, ptr %l10, !tbaa !24
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/check:Checker", ptr %t108, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t112 = load i64, ptr %l10, !tbaa !24
  %t115 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t111, i64 %t112)
  store ptr %t115, ptr %l75
  br label %bb27
bb27:
  %t116 = load ptr, ptr %l75, !tbaa !29
  store ptr %t116, ptr %l11, !tbaa !29
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load ptr, ptr %l11, !tbaa !29
  %t120 = getelementptr %"compiler/ast:Func", ptr %t118, i32 0, i32 2
  %t121 = load i32, ptr %t120, !tbaa !23
  %t124 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t117, i32 %t121)
  store { i64, ptr } %t124, ptr %l79
  br label %bb28
bb28:
  %t125 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t125, ptr %l12, !tbaa !27
  %t126 = load ptr, ptr %l11, !tbaa !29
  %t128 = getelementptr %"compiler/ast:Func", ptr %t126, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t131 = icmp eq ptr %t129, null
  br i1 %t131, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l83, !tbaa !21
  br label %bb36
bb30:
  %t133 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t135 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s4, { i64, ptr } %t133, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d29, i32 0, i32 1) })
  store i1 %t135, ptr %l85
  br label %bb31
bb31:
  %t136 = load i1, ptr %l85, !tbaa !21
  %t137 = xor i1 %t136, true
  br i1 %t137, label %bb32, label %bb33
bb32:
  %t139 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t141 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s4, { i64, ptr } %t139, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d30, i32 0, i32 1) })
  store i1 %t141, ptr %l89
  br label %bb34
bb33:
  store i1 false, ptr %l87, !tbaa !21
  br label %bb35
bb34:
  %t142 = load i1, ptr %l89, !tbaa !21
  %t143 = xor i1 %t142, true
  store i1 %t143, ptr %l87, !tbaa !21
  br label %bb35
bb35:
  %t145 = load i1, ptr %l87, !tbaa !21
  store i1 %t145, ptr %l83, !tbaa !21
  br label %bb36
bb36:
  %t146 = load i1, ptr %l83, !tbaa !21
  br i1 %t146, label %bb37, label %bb38
bb37:
  store i1 true, ptr %l91, !tbaa !21
  br label %bb40
bb38:
  %t147 = load i64, ptr %l10, !tbaa !24
  %t150 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %s0, ptr %l1, i64 %t147)
  store i1 %t150, ptr %l94
  br label %bb39
bb39:
  %t151 = load i1, ptr %l94, !tbaa !21
  store i1 %t151, ptr %l91, !tbaa !21
  br label %bb40
bb40:
  %t152 = load i1, ptr %l91, !tbaa !21
  br i1 %t152, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  br label %bb75
bb42:
  br label %bb43
bb43:
  %t153 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %s0, ptr %l1, i64 %t153, i1 true)
  br label %bb44
bb44:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = getelementptr %"compiler/check:Checker", ptr %t156, i32 0, i32 1
  %t159 = load ptr, ptr %t158, !tbaa !29
  %t160 = load i64, ptr %l10, !tbaa !24
  %t163 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t159, i64 %t160)
  store i64 %t163, ptr %l100
  br label %bb45
bb45:
  %t164 = load i64, ptr %l100, !tbaa !24
  store i64 %t164, ptr %l13, !tbaa !24
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/check:Checker", ptr %t165, i32 0, i32 1
  %t168 = load ptr, ptr %t167, !tbaa !29
  %t170 = getelementptr %"compiler/generic:Program", ptr %t168, i32 0, i32 0
  %t171 = load ptr, ptr %t170, !tbaa !29
  %t173 = getelementptr %"compiler/load:Loader", ptr %t171, i32 0, i32 5
  %t174 = load i64, ptr %l13, !tbaa !24
  %t177 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t173, i64 %t174)
  store ptr %t177, ptr %l106
  br label %bb46
bb46:
  %t178 = load ptr, ptr %l106, !tbaa !29
  %t180 = getelementptr %"compiler/load:Module", ptr %t178, i32 0, i32 6
  %t181 = load ptr, ptr %t180, !tbaa !29
  store ptr %t181, ptr %l14, !tbaa !29
  %t183 = load ptr, ptr %l14, !tbaa !29
  %t185 = icmp eq ptr %t183, null
  br i1 %t185, label %bb47, label %bb48
bb47:
  call void @__olang_check_failed(ptr @olang_loc_7cf0066f219391e3_f59e2f38f1229917)
  unreachable
bb48:
  br label %bb49
bb49:
  %t187 = load ptr, ptr %l14, !tbaa !29
  %t190 = getelementptr %"compiler/source:Source", ptr %t187, i32 0, i32 1
  %t191 = load { i64, ptr }, ptr %t190, !tbaa !27
  store { i64, ptr } %t191, ptr %l15, !tbaa !27
  %t193 = load ptr, ptr %l11, !tbaa !29
  %t195 = getelementptr %"compiler/ast:Func", ptr %t193, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !29
  %t198 = icmp eq ptr %t196, null
  br i1 %t198, label %bb50, label %bb51
bb50:
  call void @__olang_check_failed(ptr @olang_loc_93e3a02800d00d4_2c47855b6b12ccf8)
  unreachable
bb51:
  br label %bb52
bb52:
  %t200 = load ptr, ptr %l11, !tbaa !29
  %t202 = getelementptr %"compiler/ast:Func", ptr %t200, i32 0, i32 1
  %t203 = load ptr, ptr %t202, !tbaa !29
  %t206 = getelementptr %"compiler/ast:Param", ptr %t203, i32 0, i32 0
  %t207 = getelementptr %"compiler/source:Span", ptr %t206, i32 0, i32 1
  %t208 = load i32, ptr %t207, !tbaa !23
  %t210 = sext i32 %t208 to i64
  store i64 %t210, ptr %l16, !tbaa !24
  %t212 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t212, ptr %l123, !tbaa !27
  %t213 = load i64, ptr %l16, !tbaa !24
  store i64 %t213, ptr %l124, !tbaa !24
  %t214 = load ptr, ptr %l11, !tbaa !29
  %t216 = getelementptr %"compiler/ast:Func", ptr %t214, i32 0, i32 0
  %t217 = getelementptr %"compiler/source:Span", ptr %t216, i32 0, i32 1
  %t218 = load i32, ptr %t217, !tbaa !23
  %t220 = sext i32 %t218 to i64
  store i64 %t220, ptr %l127, !tbaa !24
  %t221 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t222 = extractvalue { i64, ptr } %t221, 0
  store i64 %t222, ptr %l128, !tbaa !24
  %t223 = load i64, ptr %l124, !tbaa !24
  %t224 = icmp sge i64 %t223, 0
  br i1 %t224, label %bb53, label %bb54
bb53:
  %t226 = load i64, ptr %l124, !tbaa !24
  %t227 = load i64, ptr %l127, !tbaa !24
  %t228 = icmp sle i64 %t226, %t227
  br i1 %t228, label %bb55, label %bb56
bb54:
  call void @__olang_check_failed(ptr @olang_loc_ead499c86a25c3f7_b1128c547d2ccfbb)
  unreachable
bb55:
  %t230 = load i64, ptr %l127, !tbaa !24
  %t231 = load i64, ptr %l128, !tbaa !24
  %t232 = icmp sle i64 %t230, %t231
  br i1 %t232, label %bb57, label %bb58
bb56:
  call void @__olang_check_failed(ptr @olang_loc_ead499c86a25c3f7_b1128c547d2ccfbb)
  unreachable
bb57:
  %t234 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !27
  %t236 = load i64, ptr %l124, !tbaa !24
  %t237 = load i64, ptr %l127, !tbaa !24
  %t238 = getelementptr i8, ptr %t235, i64 %t236
  %t239 = sub i64 %t237, %t236
  %t240 = insertvalue { i64, ptr } undef, i64 %t239, 0
  %t241 = insertvalue { i64, ptr } %t240, ptr %t238, 1
  %t242 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t245 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v0, { i64, ptr } %t241, { i64, ptr } %t242)
  %t246 = extractvalue { i32, i64 } %t245, 1
  %t247 = extractvalue { i32, i64 } %t245, 0
  store i32 %t247, ptr %l135
  %t248 = icmp ne i32 %t247, 0
  br i1 %t248, label %bb60, label %ok.249, !prof !99
ok.249:
  store i64 %t246, ptr %l134
  br label %bb59
bb58:
  call void @__olang_check_failed(ptr @olang_loc_ead499c86a25c3f7_b1128c547d2ccfbb)
  unreachable
bb59:
  %t250 = load i64, ptr %l134, !tbaa !24
  store i64 %t250, ptr %l122, !tbaa !24
  br label %bb62
bb60:
  br label %bb61
bb61:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l122, !tbaa !24
  br label %bb62
bb62:
  %t251 = load i64, ptr %l122, !tbaa !24
  store i64 %t251, ptr %l17, !tbaa !24
  %t252 = load i64, ptr %l17, !tbaa !24
  %t254 = icmp slt i64 %t252, 0
  br i1 %t254, label %bb63, label %bb64
bb63:
  %t256 = load ptr, ptr %l11, !tbaa !29
  %t258 = getelementptr %"compiler/ast:Func", ptr %t256, i32 0, i32 0
  %t259 = getelementptr %"compiler/source:Span", ptr %t258, i32 0, i32 0
  %t260 = load i32, ptr %t259, !tbaa !23
  %t262 = sext i32 %t260 to i64
  store i64 %t262, ptr %l138, !tbaa !24
  br label %bb65
bb64:
  %t264 = load i64, ptr %l16, !tbaa !24
  %t265 = load i64, ptr %l17, !tbaa !24
  %t268 = add i64 %t264, %t265
  store i64 %t268, ptr %l138, !tbaa !24
  br label %bb65
bb65:
  %t270 = load i64, ptr %l138, !tbaa !24
  store i64 %t270, ptr %l18, !tbaa !24
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t273 = getelementptr %"compiler/check:Checker", ptr %t271, i32 0, i32 1
  %t274 = load ptr, ptr %t273, !tbaa !29
  %t276 = getelementptr %"compiler/generic:Program", ptr %t274, i32 0, i32 0
  %t277 = load ptr, ptr %t276, !tbaa !29
  %t279 = getelementptr %"compiler/load:Loader", ptr %t277, i32 0, i32 4
  %t280 = load ptr, ptr %t279, !tbaa !29
  store ptr %t280, ptr %l148, !tbaa !29
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t283 = getelementptr %"compiler/check:Checker", ptr %t281, i32 0, i32 1
  %t284 = load ptr, ptr %t283, !tbaa !29
  %t286 = getelementptr %"compiler/generic:Program", ptr %t284, i32 0, i32 0
  %t287 = load ptr, ptr %t286, !tbaa !29
  %t289 = getelementptr %"compiler/load:Loader", ptr %t287, i32 0, i32 5
  %t290 = load i64, ptr %l13, !tbaa !24
  %t293 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t289, i64 %t290)
  store ptr %t293, ptr %l154
  br label %bb66
bb66:
  %t294 = load ptr, ptr %l154, !tbaa !29
  %t296 = getelementptr %"compiler/load:Module", ptr %t294, i32 0, i32 4
  %t297 = load i64, ptr %t296, !tbaa !24
  %t298 = load i64, ptr %l18, !tbaa !24
  %t299 = load i64, ptr %l18, !tbaa !24
  %t300 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t302 = extractvalue { i64, ptr } %t300, 0
  %t305 = add i64 %t299, %t302
  store { i64, [3 x i64] } zeroinitializer, ptr %t306
  %t307 = getelementptr { i64, [3 x i64] }, ptr %t306, i32 0, i32 0
  store i64 3, ptr %t307
  %t309 = insertvalue { i64, i64, i64 } undef, i64 %t297, 0
  %t311 = insertvalue { i64, i64, i64 } %t309, i64 %t298, 1
  %t313 = insertvalue { i64, i64, i64 } %t311, i64 %t305, 2
  %t314 = getelementptr { i64, [3 x i64] }, ptr %t306, i32 0, i32 1
  store { i64, i64, i64 } %t313, ptr %t314
  %t315 = load { i64, [3 x i64] }, ptr %t306
  store { i64, [3 x i64] } %t315, ptr %l162
  %t316 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eStrReceiverWritable(ptr %s4)
  store %"compiler/msgs:Msg" %t316, ptr %l163
  br label %bb67
bb67:
  %t317 = load ptr, ptr %l148, !tbaa !29
  %t318 = load { i64, [3 x i64] }, ptr %l162
  %t319 = load %"compiler/msgs:Msg", ptr %l163
  %t320 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s4, ptr %t317, { i64, [3 x i64] } %t318, %"compiler/msgs:Msg" %t319)
  store i64 %t320, ptr %l164
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s4)
  br label %bb74
bb69:
  br i1 true, label %bb70, label %bb71
bb70:
  br label %bb72
bb71:
  br label %bb73
bb72:
  br label %bb74
bb73:
  call void @__olang_check_failed(ptr @olang_loc_4caebcac4cec7311_26f3d9a9847d99e5)
  unreachable
bb74:
  call void @__olang_scope_close(ptr %s2)
  br label %bb75
bb75:
  %t321 = load i64, ptr %l6, !tbaa !24
  %t323 = add i64 %t321, 1
  store i64 %t323, ptr %l6, !tbaa !24
  br label %bb9
bb76:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextConst(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2, i32 %a3) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %lp4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i64
  %l20 = alloca i64
  %l23 = alloca i64
  %l42 = alloca { i64, ptr }
  %l48 = alloca %"compiler/source:Span"
  %l49 = alloca i32
  %l51 = alloca ptr
  %rv = alloca ptr
  %t95 = alloca { i64, [2 x i64] }, align 8
  %t103 = alloca { i64, [5 x i64] }, align 8
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l12, !tbaa !24
  %t4 = load i64, ptr %l12, !tbaa !24
  %t5 = icmp sge i64 %t4, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l12, !tbaa !24
  %t8 = mul i64 %t7, 1
  %t9 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  %t12 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t12, ptr %lp4
  %t14 = load ptr, ptr %lp4
  store { i64, ptr } %t11, ptr %t14, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  store i64 %t17, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t19 = load i64, ptr %l6, !tbaa !24
  %t20 = load i64, ptr %l5, !tbaa !24
  %t23 = icmp sgt i64 %t19, %t20
  br i1 %t23, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_35044444f92db59c_e1f3123be845f968)
  unreachable
bb3:
  %t25 = load i64, ptr %l7, !tbaa !24
  %t27 = icmp sgt i64 %t25, 0
  br i1 %t27, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb8
bb5:
  %t29 = load i64, ptr %l6, !tbaa !24
  %t30 = load i64, ptr %l5, !tbaa !24
  %t33 = sub i64 %t29, %t30
  %t34 = load i64, ptr %l7, !tbaa !24
  %t37 = add i64 %t33, %t34
  %t39 = sub i64 %t37, 1
  %t40 = load i64, ptr %l7, !tbaa !24
  %t43 = sdiv i64 %t39, %t40
  store i64 %t43, ptr %l23, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb7
bb7:
  %t45 = load i64, ptr %l23, !tbaa !24
  store i64 %t45, ptr %l20, !tbaa !24
  br label %bb8
bb8:
  %t46 = load i64, ptr %l20, !tbaa !24
  store i64 %t46, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb9
bb9:
  %t47 = load i64, ptr %l9, !tbaa !24
  %t48 = load i64, ptr %l8, !tbaa !24
  %t51 = icmp slt i64 %t47, %t48
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb10, label %bb11
bb10:
  br label %bb14
bb11:
  br label %bb12
bb12:
  %t55 = load i64, ptr %l5, !tbaa !24
  %t56 = load i64, ptr %l9, !tbaa !24
  %t57 = load i64, ptr %l7, !tbaa !24
  %t60 = mul i64 %t56, %t57
  %t63 = add i64 %t55, %t60
  store i64 %t63, ptr %l10, !tbaa !24
  %t65 = load i64, ptr %l10, !tbaa !24
  %t66 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t66, ptr %l42, !tbaa !27
  %t67 = load i64, ptr %l10, !tbaa !24
  %t69 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr i8, ptr %t70, i64 %t67
  %t72 = load i8, ptr %t71, !tbaa !32
  %t75 = load ptr, ptr %lp4
  %t77 = getelementptr { i64, ptr }, ptr %t75, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr i8, ptr %t78, i64 %t65
  store i8 %t72, ptr %t79, !tbaa !32
  br label %bb13
bb13:
  %t80 = load i64, ptr %l9, !tbaa !24
  %t82 = add i64 %t80, 1
  store i64 %t82, ptr %l9, !tbaa !24
  br label %bb9
bb14:
  store %"compiler/source:Span" %a1, ptr %l48
  store i32 %a3, ptr %l49, !tbaa !23
  %t88 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %a0)
  store ptr %t88, ptr %l51
  br label %bb15
bb15:
  %t89 = load ptr, ptr %l51, !tbaa !29
  %t91 = getelementptr %"compiler/check:frame", ptr %t89, i32 0, i32 2
  %t92 = load i64, ptr %t91, !tbaa !24
  %t93 = load ptr, ptr %lp4
  %t94 = load { i64, ptr }, ptr %t93, !tbaa !27
  store { i64, [2 x i64] } zeroinitializer, ptr %t95
  %t96 = getelementptr { i64, [2 x i64] }, ptr %t95, i32 0, i32 0
  store i64 1, ptr %t96
  %t98 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t94, 0
  %t99 = getelementptr { i64, [2 x i64] }, ptr %t95, i32 0, i32 1
  store { { i64, ptr } } %t98, ptr %t99
  %t100 = load { i64, [2 x i64] }, ptr %t95
  %t102 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store { i64, [2 x i64] } %t100, ptr %t102
  store { i64, [5 x i64] } zeroinitializer, ptr %t103
  %t104 = getelementptr { i64, [5 x i64] }, ptr %t103, i32 0, i32 0
  store i64 1, ptr %t104
  %t105 = load %"compiler/source:Span", ptr %l48
  %t106 = insertvalue { %"compiler/source:Span", i32, i64, ptr } undef, %"compiler/source:Span" %t105, 0
  %t107 = load i32, ptr %l49, !tbaa !23
  %t108 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t106, i32 %t107, 1
  %t110 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t108, i64 %t92, 2
  %t112 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t110, ptr %t102, 3
  %t113 = getelementptr { i64, [5 x i64] }, ptr %t103, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64, ptr } %t112, ptr %t113
  %t114 = load { i64, [5 x i64] }, ptr %t103
  %t116 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t114, ptr %t116
  store ptr %t116, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %a0, i32 %a1)
  store { i64, ptr } %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t7 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %t6)
  store { i64, ptr } %t7, ptr %l5
  br label %bb2
bb2:
  %t8 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t8, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeCase(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3, %"compiler/source:Span" %a4, ptr %a5, i32 %a6, ptr %a7) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i32
  %l8 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i64
  %l19 = alloca ptr
  %l24 = alloca i32
  %l31 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca %"compiler/source:Span"
  %l38 = alloca i32
  %l39 = alloca i32
  %l40 = alloca ptr
  %l44 = alloca ptr
  %l46 = alloca ptr
  %l49 = alloca { i64, ptr }
  %l50 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca %"compiler/source:Span"
  %l57 = alloca ptr
  %l60 = alloca ptr
  %l61 = alloca ptr
  %l62 = alloca i32
  %l63 = alloca %"compiler/source:Span"
  %l66 = alloca i32
  %l69 = alloca i64
  %l73 = alloca ptr
  %l78 = alloca %"compiler/typed:Bind"
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  %t101 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a3, ptr %l3
  store ptr %a5, ptr %l5
  store i32 %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l6, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load %"compiler/source:Span", ptr %l1
  %t9 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t13 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t7, %"compiler/source:Span" %t8, i32 %t9, i64 0)
  store ptr %t13, ptr %l19
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t14 = load ptr, ptr %l19, !tbaa !29
  store ptr %t14, ptr %rv
  br label %ret
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load %"compiler/source:Span", ptr %l1
  %t17 = load i32, ptr %l6, !tbaa !23
  %t23 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyCaseType(ptr %v0, ptr %v1, ptr %t15, %"compiler/source:Span" %t16, i32 %t17, ptr %a2)
  store i32 %t23, ptr %l24
  br label %bb5
bb5:
  %t24 = load i32, ptr %l24, !tbaa !23
  store i32 %t24, ptr %l8, !tbaa !23
  %t25 = load i32, ptr %l8, !tbaa !23
  %t26 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t29 = icmp eq i32 %t25, %t26
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load %"compiler/source:Span", ptr %l1
  %t33 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t37 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t31, %"compiler/source:Span" %t32, i32 %t33, i64 0)
  store ptr %t37, ptr %l31
  br label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t38 = load ptr, ptr %l31, !tbaa !29
  store ptr %t38, ptr %rv
  br label %ret
bb9:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load %"compiler/source:Span", ptr %l1
  %t41 = load ptr, ptr %l5, !tbaa !29
  %t45 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t39, %"compiler/source:Span" %t40, ptr %t41)
  store ptr %t45, ptr %l35
  br label %bb10
bb10:
  %t46 = load ptr, ptr %l35, !tbaa !29
  %t47 = load ptr, ptr %l0, !tbaa !29
  store ptr %t47, ptr %l36, !tbaa !29
  %t48 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t48, ptr %l37
  %t49 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t49, ptr %l38, !tbaa !23
  store i32 42, ptr %l39
  store ptr %t46, ptr %l40, !tbaa !29
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load %"compiler/source:Span", ptr %l1
  %t53 = load i32, ptr %l8, !tbaa !23
  %t57 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t51, %"compiler/source:Span" %t52, i32 %t53, i64 0)
  store ptr %t57, ptr %l44
  br label %bb11
bb11:
  %t58 = load ptr, ptr %l44, !tbaa !29
  %t59 = load ptr, ptr %l36, !tbaa !29
  %t60 = load %"compiler/source:Span", ptr %l37
  %t61 = load i32, ptr %l38, !tbaa !23
  %t62 = load i32, ptr %l39, !range !{i32 0, i32 43}
  %t63 = load ptr, ptr %l40, !tbaa !29
  %t65 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t59, %"compiler/source:Span" %t60, i32 %t61, i32 %t62, ptr %t63, ptr %t58)
  store ptr %t65, ptr %l46
  br label %bb12
bb12:
  %t66 = load ptr, ptr %l46, !tbaa !29
  store ptr %t66, ptr %l10, !tbaa !29
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load i32, ptr %l3, !tbaa !23
  %t71 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t67, i32 %t68)
  store { i64, ptr } %t71, ptr %l49
  br label %bb13
bb13:
  %t72 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t73 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t72, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) })
  store i1 %t73, ptr %l50
  br label %bb14
bb14:
  %t74 = load i1, ptr %l50, !tbaa !21
  %t75 = xor i1 %t74, true
  br i1 %t75, label %bb15, label %bb16
bb15:
  %t77 = load ptr, ptr %l0, !tbaa !29
  store ptr %t77, ptr %l52, !tbaa !29
  %t78 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t78, ptr %l53
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load %"compiler/source:Span", ptr %l1
  %t81 = load ptr, ptr %l5, !tbaa !29
  %t85 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t79, %"compiler/source:Span" %t80, ptr %t81)
  store ptr %t85, ptr %l57
  br label %bb17
bb16:
  br label %bb24
bb17:
  %t86 = load i32, ptr %l8, !tbaa !23
  %t87 = load ptr, ptr %l52, !tbaa !29
  %t88 = load %"compiler/source:Span", ptr %l53
  %t89 = load ptr, ptr %l57, !tbaa !29
  %t92 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyInstance(ptr %v0, ptr %t87, %"compiler/source:Span" %t88, ptr %t89, i32 %t86, i32 0)
  store ptr %t92, ptr %l60
  br label %bb18
bb18:
  %t93 = load ptr, ptr %l60, !tbaa !29
  store ptr %t93, ptr %l11, !tbaa !29
  %t94 = load ptr, ptr %l0, !tbaa !29
  store ptr %t94, ptr %l61, !tbaa !29
  %t95 = load i32, ptr %l3, !tbaa !23
  store i32 %t95, ptr %l62, !tbaa !23
  store %"compiler/source:Span" %a4, ptr %l63
  %t97 = load ptr, ptr %l11, !tbaa !29
  %t100 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t97)
  store i32 %t100, ptr %l66
  br label %bb19
bb19:
  store { i64, [2 x i64] } zeroinitializer, ptr %t101
  %t102 = getelementptr { i64, [2 x i64] }, ptr %t101, i32 0, i32 0
  store i64 5, ptr %t102
  %t103 = load { i64, [2 x i64] }, ptr %t101
  %t104 = load ptr, ptr %l61, !tbaa !29
  %t105 = load i32, ptr %l62, !tbaa !23
  %t106 = load %"compiler/source:Span", ptr %l63
  %t107 = load i32, ptr %l66, !tbaa !23
  %t110 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t104, i32 %t105, %"compiler/source:Span" %t106, i32 %t107, i32 4, { i64, [2 x i64] } %t103)
  store i64 %t110, ptr %l69
  br label %bb20
bb20:
  %t111 = load i64, ptr %l69, !tbaa !24
  store i64 %t111, ptr %l12, !tbaa !24
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load i64, ptr %l12, !tbaa !24
  %t114 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLet(ptr %v0, ptr %v0, ptr %t112, i64 %t113, ptr %t114)
  br label %bb21
bb21:
  store ptr %a7, ptr %l73, !tbaa !29
  %t119 = load i64, ptr %l12, !tbaa !24
  %t121 = trunc i64 %t119 to i32
  %t123 = load ptr, ptr %l11, !tbaa !29
  %t126 = call %"compiler/typed:Bind" @compiler_2ftyped_3aBind_2ector(ptr %v0, ptr %v0, i32 %t121, ptr %t123)
  store %"compiler/typed:Bind" %t126, ptr %l78
  br label %bb22
bb22:
  %t127 = load %"compiler/typed:Bind", ptr %l78
  %t128 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store %"compiler/typed:Bind" %t127, ptr %t128
  %t129 = load ptr, ptr %l73, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBind_26_3e_2ePush_3ccompiler_2ftyped_3aBind_26_3e(ptr %v0, ptr %v0, ptr %t129, ptr %t128)
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t131 = load ptr, ptr %l10, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t131, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeKindType(ptr %v0, ptr %a0) #0 {
entry:
  %l3 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %s0, ptr %s0, ptr %t4, { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d32, i32 0, i32 1) }, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d33, i32 0, i32 1) })
  store i32 %t6, ptr %l3
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t7 = load i32, ptr %l3, !tbaa !23
  store i32 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunary(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca ptr
  %lp7 = alloca ptr
  %l13 = alloca ptr
  %l21 = alloca ptr
  %l30 = alloca ptr
  %l33 = alloca i64
  %l35 = alloca i1
  %l36 = alloca ptr
  %l39 = alloca i32
  %l40 = alloca i1
  %l45 = alloca ptr
  %l49 = alloca i32
  %l52 = alloca i1
  %l55 = alloca i32
  %l58 = alloca ptr
  %l60 = alloca %"compiler/source:Span"
  %l61 = alloca ptr
  %l64 = alloca i32
  %l65 = alloca { i64, ptr }
  %l67 = alloca %"compiler/msgs:Msg"
  %l68 = alloca i64
  %l72 = alloca ptr
  %l76 = alloca i1
  %l80 = alloca ptr
  %l85 = alloca ptr
  %l87 = alloca %"compiler/source:Span"
  %l88 = alloca ptr
  %l91 = alloca i64
  %l93 = alloca i1
  %l94 = alloca ptr
  %l97 = alloca i32
  %l98 = alloca i1
  %l103 = alloca ptr
  %l109 = alloca ptr
  %l113 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l114 = alloca ptr
  %l118 = alloca ptr
  %l119 = alloca %"compiler/source:Span"
  %l121 = alloca i32
  %l123 = alloca { i64, ptr }
  %l127 = alloca i32
  %l128 = alloca %"compiler/typed:Text"
  %l136 = alloca ptr
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca ptr
  %t238 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l2, !range !{i32 0, i32 96}
  %t3 = trunc i64 18 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load %"compiler/source:Span", ptr %l1
  %t8 = load ptr, ptr %l3, !tbaa !29
  %t12 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eembed(ptr %v0, ptr %v1, ptr %t6, %"compiler/source:Span" %t7, ptr %t8)
  store ptr %t12, ptr %l13
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t13 = load ptr, ptr %l13, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t13, ptr %rv
  br label %ret
bb4:
  %t15 = load i32, ptr %l2, !range !{i32 0, i32 96}
  %t17 = trunc i64 51 to i32
  %t18 = icmp eq i32 %t15, %t17
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load %"compiler/source:Span", ptr %l1
  %t22 = load ptr, ptr %l3, !tbaa !29
  %t23 = load i32, ptr %l4, !tbaa !23
  %t28 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecomptime(ptr %v0, ptr %v1, ptr %t20, %"compiler/source:Span" %t21, ptr %t22, i32 %t23)
  store ptr %t28, ptr %l21
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t29 = load ptr, ptr %l21, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t29, ptr %rv
  br label %ret
bb8:
  %t31 = load i32, ptr %l2, !range !{i32 0, i32 96}
  %t33 = trunc i64 48 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/check:Checker", ptr %t36, i32 0, i32 40
  store i1 true, ptr %t38, !tbaa !21
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t42 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t46 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t39, ptr %t40, i32 %t42)
  store ptr %t46, ptr %l30
  br label %bb11
bb10:
  br label %bb36
bb11:
  %t47 = load ptr, ptr %l30, !tbaa !29
  store ptr %t47, ptr %l5, !tbaa !29
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load ptr, ptr %l5, !tbaa !29
  %t52 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneOf(ptr %v0, ptr %v0, ptr %t48, ptr %t49)
  store i64 %t52, ptr %l33
  br label %bb12
bb12:
  %t53 = load i64, ptr %l33, !tbaa !24
  %t54 = icmp sge i64 %t53, 0
  br i1 %t54, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb17
bb14:
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l36, !tbaa !29
  %t57 = load ptr, ptr %l5, !tbaa !29
  %t60 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t57)
  store i32 %t60, ptr %l39
  br label %bb15
bb15:
  %t61 = load ptr, ptr %l36, !tbaa !29
  %t62 = load i32, ptr %l39, !tbaa !23
  %t63 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArray(ptr %v0, ptr %t61, i32 %t62)
  store i1 %t63, ptr %l40
  br label %bb16
bb16:
  %t64 = load i1, ptr %l40, !tbaa !21
  store i1 %t64, ptr %l35, !tbaa !21
  br label %bb17
bb17:
  %t65 = load i1, ptr %l35, !tbaa !21
  br i1 %t65, label %bb18, label %bb19
bb18:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load %"compiler/source:Span", ptr %l1
  %t68 = load i32, ptr %l2, !range !{i32 0, i32 96}
  %t69 = load ptr, ptr %l5, !tbaa !29
  %t74 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneUnary(ptr %v0, ptr %t66, %"compiler/source:Span" %t67, i32 %t68, ptr %t69)
  store ptr %t74, ptr %l45
  br label %bb20
bb19:
  br label %bb21
bb20:
  %t75 = load ptr, ptr %l45, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t75, ptr %rv
  br label %ret
bb21:
  %t77 = load ptr, ptr %l5, !tbaa !29
  %t80 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t77)
  store i32 %t80, ptr %l49
  br label %bb22
bb22:
  %t81 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t82 = load i32, ptr %l49, !tbaa !23
  %t84 = icmp ne i32 %t82, %t81
  br i1 %t84, label %bb23, label %bb24
bb23:
  %t86 = load ptr, ptr %l5, !tbaa !29
  %t89 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t86)
  store i32 %t89, ptr %l55
  br label %bb25
bb24:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb26
bb25:
  %t90 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t91 = load i32, ptr %l55, !tbaa !23
  %t93 = icmp ne i32 %t91, %t90
  store i1 %t93, ptr %l52, !tbaa !21
  br label %bb26
bb26:
  %t95 = load i1, ptr %l52, !tbaa !21
  br i1 %t95, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s5
  %t96 = load ptr, ptr %l0, !tbaa !29
  store ptr %t96, ptr %l58, !tbaa !29
  %t97 = load ptr, ptr %l3, !tbaa !29
  %t99 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t97)
  store %"compiler/source:Span" %t99, ptr %l60
  br label %bb29
bb28:
  br label %bb34
bb29:
  %t100 = load ptr, ptr %l0, !tbaa !29
  store ptr %t100, ptr %l61, !tbaa !29
  %t101 = load ptr, ptr %l5, !tbaa !29
  %t104 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t101)
  store i32 %t104, ptr %l64
  br label %bb30
bb30:
  %t105 = load ptr, ptr %l61, !tbaa !29
  %t106 = load i32, ptr %l64, !tbaa !23
  %t107 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s5, ptr %t105, i32 %t106)
  store { i64, ptr } %t107, ptr %l65
  br label %bb31
bb31:
  %t108 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t108, 0
  %t110 = extractvalue { i64, ptr } %t108, 1
  %t111 = mul i64 %t109, 1
  %t112 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t111)
  call void @llvm.memcpy.p0.p0.i64(ptr %t112, ptr %t110, i64 %t111, i1 false)
  %t113 = insertvalue { i64, ptr } undef, i64 %t109, 0
  %t114 = insertvalue { i64, ptr } %t113, ptr %t112, 1
  %t116 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eOperandNotBool(ptr %s5, ptr %s5, ptr %s5, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d34, i32 0, i32 1) }, { i64, ptr } %t114)
  store %"compiler/msgs:Msg" %t116, ptr %l67
  br label %bb32
bb32:
  %t117 = load ptr, ptr %l58, !tbaa !29
  %t118 = load %"compiler/source:Span", ptr %l60
  %t119 = load %"compiler/msgs:Msg", ptr %l67
  %t120 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t117, %"compiler/source:Span" %t118, %"compiler/msgs:Msg" %t119)
  store i64 %t120, ptr %l68
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s5)
  br label %bb34
bb34:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load %"compiler/source:Span", ptr %l1
  %t123 = load ptr, ptr %l5, !tbaa !29
  %t127 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %t121, %"compiler/source:Span" %t122, ptr %t123)
  store ptr %t127, ptr %l72
  br label %bb35
bb35:
  %t128 = load ptr, ptr %l72, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t128, ptr %rv
  br label %ret
bb36:
  %t130 = load i32, ptr %l2, !range !{i32 0, i32 96}
  %t132 = trunc i64 53 to i32
  %t133 = icmp eq i32 %t130, %t132
  br i1 %t133, label %bb37, label %bb38
bb37:
  store i1 true, ptr %l76, !tbaa !21
  br label %bb39
bb38:
  %t135 = load i32, ptr %l2, !range !{i32 0, i32 96}
  %t137 = trunc i64 86 to i32
  %t138 = icmp eq i32 %t135, %t137
  store i1 %t138, ptr %l76, !tbaa !21
  br label %bb39
bb39:
  %t140 = load i1, ptr %l76, !tbaa !21
  br i1 %t140, label %bb40, label %bb41
bb40:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/check:Checker", ptr %t141, i32 0, i32 40
  store i1 true, ptr %t143, !tbaa !21
  %t144 = load ptr, ptr %l0, !tbaa !29
  store ptr %t144, ptr %l80, !tbaa !29
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load ptr, ptr %l3, !tbaa !29
  %t148 = load i32, ptr %l4, !tbaa !23
  %t152 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t145, ptr %t146, i32 %t148)
  store ptr %t152, ptr %l85
  br label %bb42
bb41:
  br label %bb56
bb42:
  %t153 = load ptr, ptr %l3, !tbaa !29
  %t155 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t153)
  store %"compiler/source:Span" %t155, ptr %l87
  br label %bb43
bb43:
  %t156 = load ptr, ptr %l80, !tbaa !29
  %t157 = load ptr, ptr %l85, !tbaa !29
  %t158 = load %"compiler/source:Span", ptr %l87
  %t159 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %t156, ptr %t157, %"compiler/source:Span" %t158)
  store ptr %t159, ptr %l88
  br label %bb44
bb44:
  %t160 = load ptr, ptr %l88, !tbaa !29
  store ptr %t160, ptr %l6, !tbaa !29
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load ptr, ptr %l6, !tbaa !29
  %t165 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneOf(ptr %v0, ptr %v0, ptr %t161, ptr %t162)
  store i64 %t165, ptr %l91
  br label %bb45
bb45:
  %t166 = load i64, ptr %l91, !tbaa !24
  %t167 = icmp sge i64 %t166, 0
  br i1 %t167, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l93, !tbaa !21
  br label %bb50
bb47:
  %t169 = load ptr, ptr %l0, !tbaa !29
  store ptr %t169, ptr %l94, !tbaa !29
  %t170 = load ptr, ptr %l6, !tbaa !29
  %t173 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t170)
  store i32 %t173, ptr %l97
  br label %bb48
bb48:
  %t174 = load ptr, ptr %l94, !tbaa !29
  %t175 = load i32, ptr %l97, !tbaa !23
  %t176 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArray(ptr %v0, ptr %t174, i32 %t175)
  store i1 %t176, ptr %l98
  br label %bb49
bb49:
  %t177 = load i1, ptr %l98, !tbaa !21
  store i1 %t177, ptr %l93, !tbaa !21
  br label %bb50
bb50:
  %t178 = load i1, ptr %l93, !tbaa !21
  br i1 %t178, label %bb51, label %bb52
bb51:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = load %"compiler/source:Span", ptr %l1
  %t181 = load i32, ptr %l2, !range !{i32 0, i32 96}
  %t182 = load ptr, ptr %l6, !tbaa !29
  %t187 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneUnary(ptr %v0, ptr %t179, %"compiler/source:Span" %t180, i32 %t181, ptr %t182)
  store ptr %t187, ptr %l103
  br label %bb53
bb52:
  br label %bb54
bb53:
  %t188 = load ptr, ptr %l103, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t188, ptr %rv
  br label %ret
bb54:
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t191 = load %"compiler/source:Span", ptr %l1
  %t192 = load i32, ptr %l2, !range !{i32 0, i32 96}
  %t193 = load ptr, ptr %l6, !tbaa !29
  %t198 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunaryOn(ptr %v0, ptr %t190, %"compiler/source:Span" %t191, i32 %t192, ptr %t193)
  store ptr %t198, ptr %l109
  br label %bb55
bb55:
  %t199 = load ptr, ptr %l109, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t199, ptr %rv
  br label %ret
bb56:
  %t201 = load i32, ptr %l2, !range !{i32 0, i32 96}
  %t203 = trunc i64 87 to i32
  %t204 = icmp eq i32 %t201, %t203
  br i1 %t204, label %bb57, label %bb58
bb57:
  %t206 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPiece_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t206, ptr %l113
  br label %bb59
bb58:
  br label %bb66
bb59:
  %t207 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store ptr %t207, ptr %lp7
  %t208 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l113
  %t209 = load ptr, ptr %lp7
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t208, ptr %t209
  %t210 = load ptr, ptr %lp7
  store ptr %t210, ptr %l114, !tbaa !29
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t212 = load %"compiler/source:Span", ptr %l1
  %t213 = load ptr, ptr %l3, !tbaa !29
  %t217 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erenderPiece(ptr %v0, ptr %v1, ptr %t211, %"compiler/source:Span" %t212, ptr %t213)
  store ptr %t217, ptr %l118
  br label %bb60
bb60:
  %t218 = load ptr, ptr %l114, !tbaa !29
  %t219 = load ptr, ptr %l118, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPiece_26_3e_2ePush_3ccompiler_2ftyped_3aPiece_26_3e(ptr %v0, ptr %v0, ptr %t218, ptr %t219)
  br label %bb61
bb61:
  %t220 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t220, ptr %l119
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t223 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t221)
  store i32 %t223, ptr %l121
  br label %bb62
bb62:
  %t224 = load ptr, ptr %lp7
  %t226 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPiece_26_3e_2eToArr_H1b89f7fcc263bba924ca04e7c3aa48c7(ptr %v0, ptr %v0, ptr %t224)
  store { i64, ptr } %t226, ptr %l123
  br label %bb63
bb63:
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t228 = load %"compiler/source:Span", ptr %l1
  %t232 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t227, i32 4, %"compiler/source:Span" %t228)
  store i32 %t232, ptr %l127
  br label %bb64
bb64:
  %t233 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t234 = load i32, ptr %l127, !tbaa !23
  %t235 = call %"compiler/typed:Text" @compiler_2ftyped_3aText_2ector(ptr %v0, ptr %v0, { i64, ptr } %t233, i32 %t234)
  store %"compiler/typed:Text" %t235, ptr %l128
  br label %bb65
bb65:
  %t236 = load %"compiler/typed:Text", ptr %l128
  %t237 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Text" %t236, ptr %t237
  store { i64, [5 x i64] } zeroinitializer, ptr %t238
  %t239 = getelementptr { i64, [5 x i64] }, ptr %t238, i32 0, i32 0
  store i64 16, ptr %t239
  %t240 = load %"compiler/source:Span", ptr %l119
  %t241 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t240, 0
  %t242 = load i32, ptr %l121, !tbaa !23
  %t243 = insertvalue { %"compiler/source:Span", i32, ptr } %t241, i32 %t242, 1
  %t245 = insertvalue { %"compiler/source:Span", i32, ptr } %t243, ptr %t237, 2
  %t246 = getelementptr { i64, [5 x i64] }, ptr %t238, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t245, ptr %t246
  %t247 = load { i64, [5 x i64] }, ptr %t238
  %t249 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t247, ptr %t249
  call void @__olang_scope_close(ptr %s0)
  store ptr %t249, ptr %rv
  br label %ret
bb66:
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t252 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s0, ptr %t251, %"compiler/source:Span" %t252, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d35, i32 0, i32 1) })
  br label %bb67
bb67:
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t256 = load %"compiler/source:Span", ptr %l1
  %t259 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t255, %"compiler/source:Span" %t256)
  store ptr %t259, ptr %l136
  br label %bb68
bb68:
  %t260 = load ptr, ptr %l136, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t260, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunaryOn(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l10 = alloca i32
  %l15 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca i1
  %l20 = alloca i1
  %l23 = alloca i1
  %l24 = alloca i1
  %l28 = alloca i1
  %l32 = alloca { i64, ptr }
  %l33 = alloca ptr
  %l36 = alloca i32
  %l37 = alloca { i64, ptr }
  %l38 = alloca %"compiler/source:Span"
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l43 = alloca i64
  %l46 = alloca ptr
  %l47 = alloca ptr
  %l51 = alloca ptr
  %l54 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l56 = alloca %"compiler/source:Span"
  %l57 = alloca %"compiler/source:Span"
  %l58 = alloca i64
  %l60 = alloca ptr
  %l63 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l70 = alloca ptr
  %l71 = alloca ptr
  %l74 = alloca i32
  %l75 = alloca { i64, ptr }
  %l76 = alloca %"compiler/source:Span"
  %l78 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l81 = alloca i1
  %l84 = alloca ptr
  %l87 = alloca i1
  %l88 = alloca ptr
  %l89 = alloca %"compiler/source:Span"
  %l92 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l101 = alloca %"compiler/msgs:Msg"
  %l102 = alloca i64
  %l105 = alloca ptr
  %l110 = alloca i1
  %l112 = alloca ptr
  %l113 = alloca %"compiler/source:Span"
  %l116 = alloca { i64, ptr }
  %l118 = alloca %"compiler/msgs:Msg"
  %l119 = alloca i64
  %l122 = alloca ptr
  %l125 = alloca i64
  %l129 = alloca %"compiler/source:Span"
  %l130 = alloca i32
  %l131 = alloca i32
  %l132 = alloca i32
  %l136 = alloca { i64, ptr }
  %l141 = alloca i1
  %l143 = alloca ptr
  %l144 = alloca %"compiler/source:Span"
  %l147 = alloca { i64, ptr }
  %l149 = alloca %"compiler/msgs:Msg"
  %l150 = alloca i64
  %l153 = alloca ptr
  %l159 = alloca ptr
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca ptr
  %t300 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t1)
  store i32 %t4, ptr %l10
  br label %bb1
bb1:
  %t5 = load i32, ptr %l10, !tbaa !23
  store i32 %t5, ptr %l4, !tbaa !23
  %t6 = load i32, ptr %l4, !tbaa !23
  %t7 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t10 = icmp eq i32 %t6, %t7
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %l3, !tbaa !29
  store ptr %t12, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l15, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l4, !tbaa !23
  %t19 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t15, i32 %t16)
  store i32 %t19, ptr %l18
  br label %bb5
bb5:
  %t20 = load ptr, ptr %l15, !tbaa !29
  %t21 = load i32, ptr %l18, !tbaa !23
  %t22 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t20, i32 %t21)
  store i1 %t22, ptr %l19
  br label %bb6
bb6:
  %t23 = load i1, ptr %l19, !tbaa !21
  br i1 %t23, label %bb7, label %bb8
bb7:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load i32, ptr %l4, !tbaa !23
  %t28 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t24, i32 %t25)
  store i1 %t28, ptr %l23
  br label %bb9
bb8:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb14
bb9:
  %t29 = load i1, ptr %l23, !tbaa !21
  br i1 %t29, label %bb10, label %bb11
bb10:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/check:Checker", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t34 = load i32, ptr %l4, !tbaa !23
  %t37 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %t33, i32 %t34)
  store i1 %t37, ptr %l28
  br label %bb12
bb11:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb13
bb12:
  %t38 = load i1, ptr %l28, !tbaa !21
  store i1 %t38, ptr %l24, !tbaa !21
  br label %bb13
bb13:
  %t39 = load i1, ptr %l24, !tbaa !21
  %t40 = xor i1 %t39, true
  store i1 %t40, ptr %l20, !tbaa !21
  br label %bb14
bb14:
  %t42 = load i1, ptr %l20, !tbaa !21
  br i1 %t42, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  %t43 = load i32, ptr %l2, !range !{i32 0, i32 96}
  %t45 = trunc i64 53 to i32
  %t46 = icmp eq i32 %t43, %t45
  br i1 %t46, label %bb17, label %bb18
bb16:
  br label %bb60
bb17:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d36, i32 0, i32 1) }, ptr %l32, !tbaa !27
  br label %bb19
bb18:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d37, i32 0, i32 1) }, ptr %l32, !tbaa !27
  br label %bb19
bb19:
  %t48 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t48, ptr %l5, !tbaa !27
  %t49 = load ptr, ptr %l0, !tbaa !29
  store ptr %t49, ptr %l33, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load i32, ptr %l4, !tbaa !23
  %t54 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t50, i32 %t51)
  store i32 %t54, ptr %l36
  br label %bb20
bb20:
  %t55 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t55, ptr %l37, !tbaa !27
  %t56 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t56, ptr %l38
  %t57 = load i32, ptr %l2, !range !{i32 0, i32 96}
  %t59 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s2, i32 %t57)
  store { i64, ptr } %t59, ptr %l40
  br label %bb21
bb21:
  %t60 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t61 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s2, ptr %s2, { i64, ptr } %t60)
  store { i64, ptr } %t61, ptr %l41
  br label %bb22
bb22:
  %t62 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t62, 0
  %t64 = extractvalue { i64, ptr } %t62, 1
  %t65 = mul i64 %t63, 1
  %t66 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t65)
  call void @llvm.memcpy.p0.p0.i64(ptr %t66, ptr %t64, i64 %t65, i1 false)
  %t67 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t66, 1
  %t69 = load ptr, ptr @__olang_prog_scope
  %t70 = load ptr, ptr %l33, !tbaa !29
  %t71 = load i32, ptr %l36, !tbaa !23
  %t72 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t73 = load %"compiler/source:Span", ptr %l38
  %t75 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleUse(ptr %v0, ptr %t69, ptr %s2, ptr %t70, i32 %t71, { i64, ptr } %t72, i64 0, %"compiler/source:Span" %t73, { i64, ptr } %t68)
  store i64 %t75, ptr %l43
  br label %bb23
bb23:
  %t76 = load i64, ptr %l43, !tbaa !24
  store i64 %t76, ptr %l6, !tbaa !24
  %t77 = load i64, ptr %l6, !tbaa !24
  %t79 = icmp sge i64 %t77, 0
  br i1 %t79, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s3
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l46, !tbaa !29
  %t82 = load ptr, ptr %l0, !tbaa !29
  store ptr %t82, ptr %l47, !tbaa !29
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/check:Checker", ptr %t83, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t87 = load i64, ptr %l6, !tbaa !24
  %t90 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t86, i64 %t87)
  store ptr %t90, ptr %l51
  br label %bb26
bb25:
  br label %bb41
bb26:
  %t91 = load ptr, ptr %l51, !tbaa !29
  %t93 = getelementptr %"compiler/ast:Func", ptr %t91, i32 0, i32 2
  %t94 = load i32, ptr %t93, !tbaa !23
  %t95 = load ptr, ptr %l47, !tbaa !29
  %t97 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t95, i32 %t94)
  store { i64, ptr } %t97, ptr %l54
  br label %bb27
bb27:
  %t98 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t99 = load ptr, ptr %l46, !tbaa !29
  %t100 = getelementptr %"compiler/check:Checker", ptr %t99, i32 0, i32 49
  store { i64, ptr } %t98, ptr %t100, !tbaa !27
  %t101 = load ptr, ptr %l0, !tbaa !29
  store ptr %t101, ptr %l55, !tbaa !29
  %t102 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t102, ptr %l56
  %t103 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t103, ptr %l57
  %t104 = load i64, ptr %l6, !tbaa !24
  store i64 %t104, ptr %l58, !tbaa !24
  %t105 = load ptr, ptr %l3, !tbaa !29
  store ptr %t105, ptr %l60, !tbaa !29
  %t107 = icmp sge i64 0, 0
  br i1 %t107, label %bb28, label %bb29
bb28:
  %t109 = icmp sle i64 0, 1152921504606846975
  br i1 %t109, label %bb30, label %bb31
bb29:
  call void @__olang_check_failed(ptr @olang_loc_e153c6abdfe6ecb0_f26e63b1d3597a0c)
  unreachable
bb30:
  %t111 = mul i64 0, 8
  %t112 = insertvalue { i64, ptr } undef, i64 0, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t113, ptr %l63, !tbaa !27
  %t114 = icmp sge i64 0, 0
  br i1 %t114, label %bb32, label %bb33
bb31:
  call void @__olang_check_failed(ptr @olang_loc_e153c6abdfe6ecb0_f26e63b1d3597a0c)
  unreachable
bb32:
  %t116 = icmp sle i64 0, 1152921504606846975
  br i1 %t116, label %bb34, label %bb35
bb33:
  call void @__olang_check_failed(ptr @olang_loc_e153c6abdfe6ecb0_f26e63b1d3597a0c)
  unreachable
bb34:
  %t118 = mul i64 0, 8
  %t119 = insertvalue { i64, ptr } undef, i64 0, 0
  %t120 = insertvalue { i64, ptr } %t119, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t120, ptr %l66, !tbaa !27
  %t121 = icmp sge i64 0, 0
  br i1 %t121, label %bb36, label %bb37
bb35:
  call void @__olang_check_failed(ptr @olang_loc_e153c6abdfe6ecb0_f26e63b1d3597a0c)
  unreachable
bb36:
  %t123 = icmp sle i64 0, 2305843009213693951
  br i1 %t123, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_19db3dca8a9dc05d_2b95ab49e23e3919)
  unreachable
bb38:
  %t125 = mul i64 0, 4
  %t126 = insertvalue { i64, ptr } undef, i64 0, 0
  %t127 = insertvalue { i64, ptr } %t126, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t128 = load ptr, ptr %l55, !tbaa !29
  %t129 = load %"compiler/source:Span", ptr %l56
  %t130 = load %"compiler/source:Span", ptr %l57
  %t131 = load i64, ptr %l58, !tbaa !24
  %t132 = load ptr, ptr %l60, !tbaa !29
  %t133 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t134 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t136 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %s3, ptr %t128, %"compiler/source:Span" %t129, %"compiler/source:Span" %t130, i64 %t131, ptr %t132, { i64, ptr } %t133, { i64, ptr } %t134, { i64, ptr } %t127)
  store ptr %t136, ptr %l70
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_19db3dca8a9dc05d_2b95ab49e23e3919)
  unreachable
bb40:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  %t137 = load ptr, ptr %l70, !tbaa !29
  store ptr %t137, ptr %rv
  br label %ret
bb41:
  %t138 = load ptr, ptr %l0, !tbaa !29
  store ptr %t138, ptr %l71, !tbaa !29
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load i32, ptr %l4, !tbaa !23
  %t143 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t139, i32 %t140)
  store i32 %t143, ptr %l74
  br label %bb42
bb42:
  %t144 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t144, ptr %l75, !tbaa !27
  %t145 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t145, ptr %l76
  %t146 = load i32, ptr %l2, !range !{i32 0, i32 96}
  %t148 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s2, i32 %t146)
  store { i64, ptr } %t148, ptr %l78
  br label %bb43
bb43:
  %t149 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t150 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s2, ptr %s2, { i64, ptr } %t149)
  store { i64, ptr } %t150, ptr %l79
  br label %bb44
bb44:
  %t151 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t152 = extractvalue { i64, ptr } %t151, 0
  %t153 = extractvalue { i64, ptr } %t151, 1
  %t154 = mul i64 %t152, 1
  %t155 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t154)
  call void @llvm.memcpy.p0.p0.i64(ptr %t155, ptr %t153, i64 %t154, i1 false)
  %t156 = insertvalue { i64, ptr } undef, i64 %t152, 0
  %t157 = insertvalue { i64, ptr } %t156, ptr %t155, 1
  %t158 = load ptr, ptr @__olang_prog_scope
  %t159 = load ptr, ptr %l71, !tbaa !29
  %t160 = load i32, ptr %l74, !tbaa !23
  %t161 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t162 = load %"compiler/source:Span", ptr %l76
  %t164 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %t158, ptr %s2, ptr %t159, i32 %t160, { i64, ptr } %t161, %"compiler/source:Span" %t162, { i64, ptr } %t157, i64 0, i1 false)
  store i1 %t164, ptr %l81
  br label %bb45
bb45:
  %t165 = load i1, ptr %l81, !tbaa !21
  br i1 %t165, label %bb46, label %bb47
bb46:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load %"compiler/source:Span", ptr %l1
  %t170 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t166, %"compiler/source:Span" %t167)
  store ptr %t170, ptr %l84
  br label %bb48
bb47:
  br label %bb49
bb48:
  call void @__olang_scope_close(ptr %s2)
  %t171 = load ptr, ptr %l84, !tbaa !29
  store ptr %t171, ptr %rv
  br label %ret
bb49:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t173 = load i32, ptr %l4, !tbaa !23
  %t176 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t172, i32 %t173)
  store i1 %t176, ptr %l87
  br label %bb50
bb50:
  %t177 = load i1, ptr %l87, !tbaa !21
  br i1 %t177, label %bb51, label %bb52
bb51:
  store %olang.scope zeroinitializer, ptr %s5
  %t178 = load ptr, ptr %l0, !tbaa !29
  store ptr %t178, ptr %l88, !tbaa !29
  %t179 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t179, ptr %l89
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t181 = load i32, ptr %l4, !tbaa !23
  %t184 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s5, ptr %t180, i32 %t181)
  store { i64, ptr } %t184, ptr %l92
  br label %bb53
bb52:
  br label %bb59
bb53:
  %t185 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t186 = extractvalue { i64, ptr } %t185, 0
  %t187 = extractvalue { i64, ptr } %t185, 1
  %t188 = mul i64 %t186, 1
  %t189 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t188)
  call void @llvm.memcpy.p0.p0.i64(ptr %t189, ptr %t187, i64 %t188, i1 false)
  %t190 = insertvalue { i64, ptr } undef, i64 %t186, 0
  %t191 = insertvalue { i64, ptr } %t190, ptr %t189, 1
  store { i64, ptr } %t191, ptr %l93, !tbaa !27
  %t192 = load i32, ptr %l2, !range !{i32 0, i32 96}
  %t194 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s5, i32 %t192)
  store { i64, ptr } %t194, ptr %l95
  br label %bb54
bb54:
  %t195 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t196 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s5, ptr %s5, { i64, ptr } %t195)
  store { i64, ptr } %t196, ptr %l96
  br label %bb55
bb55:
  %t197 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t198 = extractvalue { i64, ptr } %t197, 0
  %t199 = extractvalue { i64, ptr } %t197, 1
  %t200 = mul i64 %t198, 1
  %t201 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t200)
  call void @llvm.memcpy.p0.p0.i64(ptr %t201, ptr %t199, i64 %t200, i1 false)
  %t202 = insertvalue { i64, ptr } undef, i64 %t198, 0
  %t203 = insertvalue { i64, ptr } %t202, ptr %t201, 1
  %t204 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t205 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d38, i32 0, i32 1) }, 1
  %t206 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d38, i32 0, i32 1) }, 0
  %t208 = extractvalue { i64, ptr } %t204, 1
  %t209 = extractvalue { i64, ptr } %t204, 0
  %t210 = add i64 %t206, %t209
  %t211 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d38, i32 0, i32 1) }, 1
  %t212 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d38, i32 0, i32 1) }, 0
  %t213 = add i64 %t210, %t212
  %t214 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t213)
  call void @olang_textcopy(ptr %t214, ptr %t205, i64 %t206)
  %t215 = getelementptr i8, ptr %t214, i64 %t206
  call void @olang_textcopy(ptr %t215, ptr %t208, i64 %t209)
  %t216 = getelementptr i8, ptr %t215, i64 %t209
  call void @olang_textcopy(ptr %t216, ptr %t211, i64 %t212)
  %t217 = insertvalue { i64, ptr } undef, i64 %t213, 0
  %t218 = insertvalue { i64, ptr } %t217, ptr %t214, 1
  %t220 = extractvalue { i64, ptr } %t218, 0
  %t221 = extractvalue { i64, ptr } %t218, 1
  %t222 = mul i64 %t220, 1
  %t223 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t222)
  call void @llvm.memcpy.p0.p0.i64(ptr %t223, ptr %t221, i64 %t222, i1 false)
  %t224 = insertvalue { i64, ptr } undef, i64 %t220, 0
  %t225 = insertvalue { i64, ptr } %t224, ptr %t223, 1
  %t226 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t229 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotExtendedOp(ptr %s5, ptr %s5, ptr %s5, ptr %s5, { i64, ptr } %t226, { i64, ptr } %t203, { i64, ptr } %t225)
  store %"compiler/msgs:Msg" %t229, ptr %l101
  br label %bb56
bb56:
  %t230 = load ptr, ptr %l88, !tbaa !29
  %t231 = load %"compiler/source:Span", ptr %l89
  %t232 = load %"compiler/msgs:Msg", ptr %l101
  %t233 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t230, %"compiler/source:Span" %t231, %"compiler/msgs:Msg" %t232)
  store i64 %t233, ptr %l102
  br label %bb57
bb57:
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = load %"compiler/source:Span", ptr %l1
  %t238 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t234, %"compiler/source:Span" %t235)
  store ptr %t238, ptr %l105
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s2)
  %t239 = load ptr, ptr %l105, !tbaa !29
  store ptr %t239, ptr %rv
  br label %ret
bb59:
  call void @__olang_scope_close(ptr %s2)
  br label %bb60
bb60:
  %t240 = load i32, ptr %l2, !range !{i32 0, i32 96}
  %t242 = trunc i64 53 to i32
  %t243 = icmp eq i32 %t240, %t242
  br i1 %t243, label %bb61, label %bb62
bb61:
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t246 = load i32, ptr %l4, !tbaa !23
  %t249 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t245, i32 %t246)
  store i1 %t249, ptr %l110
  br label %bb63
bb62:
  br label %bb74
bb63:
  %t250 = load i1, ptr %l110, !tbaa !21
  %t251 = xor i1 %t250, true
  br i1 %t251, label %bb64, label %bb65
bb64:
  store %olang.scope zeroinitializer, ptr %s8
  %t253 = load ptr, ptr %l0, !tbaa !29
  store ptr %t253, ptr %l112, !tbaa !29
  %t254 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t254, ptr %l113
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t256 = load i32, ptr %l4, !tbaa !23
  %t259 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s8, ptr %t255, i32 %t256)
  store { i64, ptr } %t259, ptr %l116
  br label %bb66
bb65:
  br label %bb70
bb66:
  %t260 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t261 = extractvalue { i64, ptr } %t260, 0
  %t262 = extractvalue { i64, ptr } %t260, 1
  %t263 = mul i64 %t261, 1
  %t264 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t263)
  call void @llvm.memcpy.p0.p0.i64(ptr %t264, ptr %t262, i64 %t263, i1 false)
  %t265 = insertvalue { i64, ptr } undef, i64 %t261, 0
  %t266 = insertvalue { i64, ptr } %t265, ptr %t264, 1
  %t268 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eOperandNotNumber(ptr %s8, ptr %s8, ptr %s8, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d39, i32 0, i32 1) }, { i64, ptr } %t266)
  store %"compiler/msgs:Msg" %t268, ptr %l118
  br label %bb67
bb67:
  %t269 = load ptr, ptr %l112, !tbaa !29
  %t270 = load %"compiler/source:Span", ptr %l113
  %t271 = load %"compiler/msgs:Msg", ptr %l118
  %t272 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s8, ptr %t269, %"compiler/source:Span" %t270, %"compiler/msgs:Msg" %t271)
  store i64 %t272, ptr %l119
  br label %bb68
bb68:
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t274 = load %"compiler/source:Span", ptr %l1
  %t277 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t273, %"compiler/source:Span" %t274)
  store ptr %t277, ptr %l122
  br label %bb69
bb69:
  call void @__olang_scope_close(ptr %s8)
  %t278 = load ptr, ptr %l122, !tbaa !29
  store ptr %t278, ptr %rv
  br label %ret
bb70:
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t281 = getelementptr %"compiler/check:Checker", ptr %t279, i32 0, i32 36
  %t283 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t281)
  store i64 %t283, ptr %l125
  br label %bb71
bb71:
  %t284 = load i64, ptr %l125, !tbaa !24
  store i64 %t284, ptr %l7, !tbaa !24
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t287 = getelementptr %"compiler/check:Checker", ptr %t285, i32 0, i32 36
  %t288 = load ptr, ptr %l3, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t287, ptr %t288)
  br label %bb72
bb72:
  %t291 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t291, ptr %l129
  %t292 = load i32, ptr %l4, !tbaa !23
  store i32 %t292, ptr %l130, !tbaa !23
  store i32 0, ptr %l131
  store i32 0, ptr %l132
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t295 = getelementptr %"compiler/check:Checker", ptr %t293, i32 0, i32 36
  %t296 = load i64, ptr %l7, !tbaa !24
  %t299 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t295, i64 %t296)
  store { i64, ptr } %t299, ptr %l136
  br label %bb73
bb73:
  store { i64, [5 x i64] } zeroinitializer, ptr %t300
  %t301 = getelementptr { i64, [5 x i64] }, ptr %t300, i32 0, i32 0
  store i64 9, ptr %t301
  %t302 = load %"compiler/source:Span", ptr %l129
  %t303 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } undef, %"compiler/source:Span" %t302, 0
  %t304 = load i32, ptr %l130, !tbaa !23
  %t305 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t303, i32 %t304, 1
  %t306 = load i32, ptr %l131, !range !{i32 0, i32 43}
  %t307 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t305, i32 %t306, 2
  %t308 = load i32, ptr %l132, !range !{i32 0, i32 3}
  %t309 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t307, i32 %t308, 3
  %t310 = load { i64, ptr }, ptr %l136, !tbaa !27
  %t311 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t309, { i64, ptr } %t310, 4
  %t312 = getelementptr { i64, [5 x i64] }, ptr %t300, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t311, ptr %t312
  %t313 = load { i64, [5 x i64] }, ptr %t300
  %t315 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t313, ptr %t315
  store ptr %t315, ptr %rv
  br label %ret
bb74:
  %t317 = load ptr, ptr %l0, !tbaa !29
  %t318 = load i32, ptr %l4, !tbaa !23
  %t321 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisInt(ptr %v0, ptr %t317, i32 %t318)
  store i1 %t321, ptr %l141
  br label %bb75
bb75:
  %t322 = load i1, ptr %l141, !tbaa !21
  %t323 = xor i1 %t322, true
  br i1 %t323, label %bb76, label %bb77
bb76:
  store %olang.scope zeroinitializer, ptr %s9
  %t325 = load ptr, ptr %l0, !tbaa !29
  store ptr %t325, ptr %l143, !tbaa !29
  %t326 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t326, ptr %l144
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t328 = load i32, ptr %l4, !tbaa !23
  %t331 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s9, ptr %t327, i32 %t328)
  store { i64, ptr } %t331, ptr %l147
  br label %bb78
bb77:
  br label %bb82
bb78:
  %t332 = load { i64, ptr }, ptr %l147, !tbaa !27
  %t333 = extractvalue { i64, ptr } %t332, 0
  %t334 = extractvalue { i64, ptr } %t332, 1
  %t335 = mul i64 %t333, 1
  %t336 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t335)
  call void @llvm.memcpy.p0.p0.i64(ptr %t336, ptr %t334, i64 %t335, i1 false)
  %t337 = insertvalue { i64, ptr } undef, i64 %t333, 0
  %t338 = insertvalue { i64, ptr } %t337, ptr %t336, 1
  %t340 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eOperandNotInt(ptr %s9, ptr %s9, ptr %s9, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d40, i32 0, i32 1) }, { i64, ptr } %t338)
  store %"compiler/msgs:Msg" %t340, ptr %l149
  br label %bb79
bb79:
  %t341 = load ptr, ptr %l143, !tbaa !29
  %t342 = load %"compiler/source:Span", ptr %l144
  %t343 = load %"compiler/msgs:Msg", ptr %l149
  %t344 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s9, ptr %t341, %"compiler/source:Span" %t342, %"compiler/msgs:Msg" %t343)
  store i64 %t344, ptr %l150
  br label %bb80
bb80:
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t346 = load %"compiler/source:Span", ptr %l1
  %t349 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t345, %"compiler/source:Span" %t346)
  store ptr %t349, ptr %l153
  br label %bb81
bb81:
  call void @__olang_scope_close(ptr %s9)
  %t350 = load ptr, ptr %l153, !tbaa !29
  store ptr %t350, ptr %rv
  br label %ret
bb82:
  %t351 = load ptr, ptr %l0, !tbaa !29
  %t352 = load %"compiler/source:Span", ptr %l1
  %t353 = load i32, ptr %l4, !tbaa !23
  %t354 = load ptr, ptr %l3, !tbaa !29
  %t360 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t351, %"compiler/source:Span" %t352, i32 %t353, i32 1, ptr %t354, ptr null)
  store ptr %t360, ptr %l159
  br label %bb83
bb83:
  %t361 = load ptr, ptr %l159, !tbaa !29
  store ptr %t361, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrollConsts(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, { i64, ptr } %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca { i64, i64, i64 }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca { i64, i64, i64 }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i32
  %l22 = alloca i32
  %l23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca { i64, i64, i64 }
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l33 = alloca i64
  %l37 = alloca { i64, i64, i64 }
  %l42 = alloca ptr
  %l51 = alloca i64
  %l54 = alloca i64
  %l74 = alloca i64
  %l78 = alloca { i64, i64, i64 }
  %l83 = alloca ptr
  %l87 = alloca ptr
  %l89 = alloca i32
  %l94 = alloca { i64, ptr }
  %l97 = alloca i32
  %l98 = alloca i32
  %l99 = alloca ptr
  %l101 = alloca i32
  %l104 = alloca ptr
  %l106 = alloca i32
  %l108 = alloca i32
  %l109 = alloca i32
  %l133 = alloca i64
  %l135 = alloca ptr
  %l138 = alloca i64
  %l139 = alloca i32
  %l145 = alloca ptr
  %l148 = alloca i64
  %l152 = alloca { i64, i64, i64 }
  %l169 = alloca ptr
  %l187 = alloca i64
  %l189 = alloca ptr
  %l192 = alloca i64
  %l193 = alloca i32
  %l199 = alloca ptr
  %t205 = alloca { i64, [3 x i64] }, align 8
  %t272 = alloca { i64, [3 x i64] }, align 8
  %t303 = alloca { i64, [3 x i64] }, align 8
  %t327 = alloca { i64, [3 x i64] }, align 8
  %t369 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 37
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l33
  br label %bb1
bb1:
  %t6 = load i64, ptr %l33, !tbaa !24
  store i64 %t6, ptr %l5, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load %"compiler/source:Span", ptr %l1
  %t12 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t7, i32 2, %"compiler/source:Span" %t8)
  store { i64, i64, i64 } %t12, ptr %l37
  br label %bb2
bb2:
  %t13 = load { i64, i64, i64 }, ptr %l37
  store { i64, i64, i64 } %t13, ptr %l6
  %t14 = getelementptr { i64, i64, i64 }, ptr %l6, i32 0, i32 0
  %t15 = load i64, ptr %t14, !tbaa !24
  store i64 %t15, ptr %l7, !tbaa !24
  %t17 = getelementptr { i64, i64, i64 }, ptr %l6, i32 0, i32 1
  %t18 = load i64, ptr %t17, !tbaa !24
  store i64 %t18, ptr %l8, !tbaa !24
  %t20 = getelementptr { i64, i64, i64 }, ptr %l6, i32 0, i32 2
  %t21 = load i64, ptr %t20, !tbaa !24
  store i64 %t21, ptr %l9, !tbaa !24
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t23)
  store ptr %t25, ptr %l42
  br label %bb3
bb3:
  %t26 = load ptr, ptr %l42, !tbaa !29
  %t28 = getelementptr %"compiler/check:frame", ptr %t26, i32 0, i32 11
  %t29 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t28, i64 %t29)
  br label %bb4
bb4:
  store i64 0, ptr %l10, !tbaa !24
  %t32 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t32, 0
  store i64 %t34, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t36 = load i64, ptr %l11, !tbaa !24
  %t37 = load i64, ptr %l10, !tbaa !24
  %t40 = icmp sgt i64 %t36, %t37
  br i1 %t40, label %bb5, label %bb6
bb5:
  %t42 = load i64, ptr %l12, !tbaa !24
  %t44 = icmp sgt i64 %t42, 0
  br i1 %t44, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb10
bb7:
  %t46 = load i64, ptr %l11, !tbaa !24
  %t47 = load i64, ptr %l10, !tbaa !24
  %t50 = sub i64 %t46, %t47
  %t51 = load i64, ptr %l12, !tbaa !24
  %t54 = add i64 %t50, %t51
  %t56 = sub i64 %t54, 1
  %t57 = load i64, ptr %l12, !tbaa !24
  %t60 = sdiv i64 %t56, %t57
  store i64 %t60, ptr %l54, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb9
bb9:
  %t62 = load i64, ptr %l54, !tbaa !24
  store i64 %t62, ptr %l51, !tbaa !24
  br label %bb10
bb10:
  %t63 = load i64, ptr %l51, !tbaa !24
  store i64 %t63, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb11
bb11:
  %t64 = load i64, ptr %l14, !tbaa !24
  %t65 = load i64, ptr %l13, !tbaa !24
  %t68 = icmp slt i64 %t64, %t65
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb12, label %bb13
bb12:
  br label %bb43
bb13:
  br label %bb14
bb14:
  %t72 = load i64, ptr %l10, !tbaa !24
  %t73 = load i64, ptr %l14, !tbaa !24
  %t74 = load i64, ptr %l12, !tbaa !24
  %t77 = mul i64 %t73, %t74
  %t80 = add i64 %t72, %t77
  store i64 %t80, ptr %l15, !tbaa !24
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/check:Checker", ptr %t82, i32 0, i32 37
  %t86 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t84)
  store i64 %t86, ptr %l74
  br label %bb15
bb15:
  %t87 = load i64, ptr %l74, !tbaa !24
  store i64 %t87, ptr %l16, !tbaa !24
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load %"compiler/source:Span", ptr %l1
  %t93 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t88, i32 2, %"compiler/source:Span" %t89)
  store { i64, i64, i64 } %t93, ptr %l78
  br label %bb16
bb16:
  %t94 = load { i64, i64, i64 }, ptr %l78
  store { i64, i64, i64 } %t94, ptr %l17
  %t95 = getelementptr { i64, i64, i64 }, ptr %l17, i32 0, i32 0
  %t96 = load i64, ptr %t95, !tbaa !24
  store i64 %t96, ptr %l18, !tbaa !24
  %t98 = getelementptr { i64, i64, i64 }, ptr %l17, i32 0, i32 1
  %t99 = load i64, ptr %t98, !tbaa !24
  store i64 %t99, ptr %l19, !tbaa !24
  %t101 = getelementptr { i64, i64, i64 }, ptr %l17, i32 0, i32 2
  %t102 = load i64, ptr %t101, !tbaa !24
  store i64 %t102, ptr %l20, !tbaa !24
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t104)
  store ptr %t106, ptr %l83
  br label %bb17
bb17:
  %t107 = load ptr, ptr %l83, !tbaa !29
  %t109 = getelementptr %"compiler/check:frame", ptr %t107, i32 0, i32 10
  %t110 = load i64, ptr %l18, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t109, i64 %t110)
  br label %bb18
bb18:
  %t113 = load ptr, ptr %l0, !tbaa !29
  store ptr %t113, ptr %l87, !tbaa !29
  %t114 = load ptr, ptr %l2, !tbaa !29
  %t116 = getelementptr %"compiler/ast:ForIn", ptr %t114, i32 0, i32 1
  %t117 = load i32, ptr %t116, !tbaa !23
  store i32 %t117, ptr %l89, !tbaa !23
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/check:Checker", ptr %t118, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !29
  %t123 = getelementptr %"compiler/generic:Program", ptr %t121, i32 0, i32 2
  %t125 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t125, ptr %l94, !tbaa !27
  %t126 = load i64, ptr %l15, !tbaa !24
  %t128 = getelementptr { i64, ptr }, ptr %l94, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = getelementptr i64, ptr %t129, i64 %t126
  %t131 = load i64, ptr %t130, !tbaa !34
  %t135 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %t123, i32 %a4, i64 %t131)
  store i32 %t135, ptr %l97
  br label %bb19
bb19:
  %t136 = load ptr, ptr %l87, !tbaa !29
  %t137 = load i32, ptr %l89, !tbaa !23
  %t138 = load i32, ptr %l97, !tbaa !23
  %t139 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrollBind(ptr %v0, ptr %t136, i32 %t137, i32 %t138)
  store i32 %t139, ptr %l98
  br label %bb20
bb20:
  %t140 = load i32, ptr %l98, !tbaa !23
  store i32 %t140, ptr %l21, !tbaa !23
  %t141 = load ptr, ptr %l0, !tbaa !29
  store ptr %t141, ptr %l99, !tbaa !29
  %t142 = load ptr, ptr %l2, !tbaa !29
  %t144 = getelementptr %"compiler/ast:ForIn", ptr %t142, i32 0, i32 0
  %t145 = load i32, ptr %t144, !tbaa !23
  store i32 %t145, ptr %l101, !tbaa !23
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"compiler/check:Checker", ptr %t146, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !29
  %t151 = getelementptr %"compiler/generic:Program", ptr %t149, i32 0, i32 2
  store ptr %t151, ptr %l104, !tbaa !29
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t152)
  store i32 %t154, ptr %l106
  br label %bb21
bb21:
  %t155 = load i64, ptr %l15, !tbaa !24
  %t156 = load ptr, ptr %l104, !tbaa !29
  %t157 = load i32, ptr %l106, !tbaa !23
  %t159 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %t156, i32 %t157, i64 %t155)
  store i32 %t159, ptr %l108
  br label %bb22
bb22:
  %t160 = load ptr, ptr %l99, !tbaa !29
  %t161 = load i32, ptr %l101, !tbaa !23
  %t162 = load i32, ptr %l108, !tbaa !23
  %t163 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrollBind(ptr %v0, ptr %t160, i32 %t161, i32 %t162)
  store i32 %t163, ptr %l109
  br label %bb23
bb23:
  %t164 = load i32, ptr %l109, !tbaa !23
  store i32 %t164, ptr %l22, !tbaa !23
  %t165 = load ptr, ptr %l2, !tbaa !29
  %t167 = getelementptr %"compiler/ast:ForIn", ptr %t165, i32 0, i32 4
  %t168 = load { i64, ptr }, ptr %t167, !tbaa !27
  %t170 = extractvalue { i64, ptr } %t168, 0
  %t172 = icmp sgt i64 %t170, 0
  br i1 %t172, label %bb24, label %bb25
bb24:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = load ptr, ptr %l2, !tbaa !29
  %t177 = getelementptr %"compiler/ast:ForIn", ptr %t175, i32 0, i32 4
  %t178 = load { i64, ptr }, ptr %t177, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmtsOf(ptr %v0, ptr %v1, ptr %t174, { i64, ptr } %t178)
  br label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb27
bb27:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t182 = load ptr, ptr %l2, !tbaa !29
  %t184 = getelementptr %"compiler/ast:ForIn", ptr %t182, i32 0, i32 0
  %t185 = load i32, ptr %t184, !tbaa !23
  %t186 = load i32, ptr %l22, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrollUnbind(ptr %v0, ptr %t181, i32 %t185, i32 %t186)
  br label %bb28
bb28:
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t191 = load ptr, ptr %l2, !tbaa !29
  %t193 = getelementptr %"compiler/ast:ForIn", ptr %t191, i32 0, i32 1
  %t194 = load i32, ptr %t193, !tbaa !23
  %t195 = load i32, ptr %l21, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrollUnbind(ptr %v0, ptr %t190, i32 %t194, i32 %t195)
  br label %bb29
bb29:
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t200 = load %"compiler/source:Span", ptr %l1
  %t201 = load i64, ptr %l18, !tbaa !24
  %t203 = trunc i64 %t201 to i32
  store { i64, [3 x i64] } zeroinitializer, ptr %t205
  %t206 = getelementptr { i64, [3 x i64] }, ptr %t205, i32 0, i32 0
  store i64 5, ptr %t206
  %t208 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t200, 0
  %t210 = insertvalue { %"compiler/source:Span", i32, i32 } %t208, i32 0, 1
  %t212 = insertvalue { %"compiler/source:Span", i32, i32 } %t210, i32 %t203, 2
  %t213 = getelementptr { i64, [3 x i64] }, ptr %t205, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t212, ptr %t213
  %t214 = load { i64, [3 x i64] }, ptr %t205
  %t216 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t214, ptr %t216
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t199, ptr %t216)
  br label %bb30
bb30:
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t221 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t219)
  store ptr %t221, ptr %l135
  br label %bb31
bb31:
  %t222 = load ptr, ptr %l135, !tbaa !29
  %t224 = getelementptr %"compiler/check:frame", ptr %t222, i32 0, i32 10
  %t226 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t224)
  %t227 = extractvalue { i32, i64 } %t226, 1
  %t228 = extractvalue { i32, i64 } %t226, 0
  store i32 %t228, ptr %l139
  %t229 = icmp ne i32 %t228, 0
  br i1 %t229, label %bb33, label %ok.230, !prof !99
ok.230:
  store i64 %t227, ptr %l138
  br label %bb32
bb32:
  %t231 = load i64, ptr %l138, !tbaa !24
  store i64 %t231, ptr %l133, !tbaa !24
  br label %bb35
bb33:
  br label %bb34
bb34:
  call void @__olang_ert_req_clear()
  br label %bb35
bb35:
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t233 = load i64, ptr %l18, !tbaa !24
  %t234 = load i64, ptr %l19, !tbaa !24
  %t235 = load i64, ptr %l20, !tbaa !24
  %t236 = load i64, ptr %l16, !tbaa !24
  %t242 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %t232, i64 %t233, i64 %t234, i64 %t235, i64 %t236)
  store ptr %t242, ptr %l145
  br label %bb36
bb36:
  %t243 = load ptr, ptr %l145, !tbaa !29
  store ptr %t243, ptr %l23, !tbaa !29
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t246 = getelementptr %"compiler/check:Checker", ptr %t244, i32 0, i32 37
  %t248 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t246)
  store i64 %t248, ptr %l148
  br label %bb37
bb37:
  %t249 = load i64, ptr %l148, !tbaa !24
  store i64 %t249, ptr %l24, !tbaa !24
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t251 = load %"compiler/source:Span", ptr %l1
  %t255 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t250, i32 3, %"compiler/source:Span" %t251)
  store { i64, i64, i64 } %t255, ptr %l152
  br label %bb38
bb38:
  %t256 = load { i64, i64, i64 }, ptr %l152
  store { i64, i64, i64 } %t256, ptr %l25
  %t257 = getelementptr { i64, i64, i64 }, ptr %l25, i32 0, i32 0
  %t258 = load i64, ptr %t257, !tbaa !24
  store i64 %t258, ptr %l26, !tbaa !24
  %t260 = getelementptr { i64, i64, i64 }, ptr %l25, i32 0, i32 1
  %t261 = load i64, ptr %t260, !tbaa !24
  store i64 %t261, ptr %l27, !tbaa !24
  %t263 = getelementptr { i64, i64, i64 }, ptr %l25, i32 0, i32 2
  %t264 = load i64, ptr %t263, !tbaa !24
  store i64 %t264, ptr %l28, !tbaa !24
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t267 = load %"compiler/source:Span", ptr %l1
  %t268 = load i64, ptr %l18, !tbaa !24
  %t270 = trunc i64 %t268 to i32
  store { i64, [3 x i64] } zeroinitializer, ptr %t272
  %t273 = getelementptr { i64, [3 x i64] }, ptr %t272, i32 0, i32 0
  store i64 5, ptr %t273
  %t275 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t267, 0
  %t277 = insertvalue { %"compiler/source:Span", i32, i32 } %t275, i32 0, 1
  %t279 = insertvalue { %"compiler/source:Span", i32, i32 } %t277, i32 %t270, 2
  %t280 = getelementptr { i64, [3 x i64] }, ptr %t272, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t279, ptr %t280
  %t281 = load { i64, [3 x i64] }, ptr %t272
  %t283 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t281, ptr %t283
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t266, ptr %t283)
  br label %bb39
bb39:
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t287 = load i64, ptr %l26, !tbaa !24
  %t288 = load i64, ptr %l27, !tbaa !24
  %t289 = load i64, ptr %l28, !tbaa !24
  %t290 = load i64, ptr %l24, !tbaa !24
  %t296 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %t286, i64 %t287, i64 %t288, i64 %t289, i64 %t290)
  store ptr %t296, ptr %l169
  br label %bb40
bb40:
  %t297 = load ptr, ptr %l169, !tbaa !29
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t299 = load %"compiler/source:Span", ptr %l1
  %t300 = load ptr, ptr %l23, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t303
  %t304 = getelementptr { i64, [3 x i64] }, ptr %t303, i32 0, i32 0
  store i64 4, ptr %t304
  %t306 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t299, 0
  %t308 = insertvalue { %"compiler/source:Span", ptr, ptr } %t306, ptr %t300, 1
  %t310 = insertvalue { %"compiler/source:Span", ptr, ptr } %t308, ptr %t297, 2
  %t311 = getelementptr { i64, [3 x i64] }, ptr %t303, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t310, ptr %t311
  %t312 = load { i64, [3 x i64] }, ptr %t303
  %t314 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t312, ptr %t314
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t298, ptr %t314)
  br label %bb41
bb41:
  br label %bb42
bb42:
  %t317 = load i64, ptr %l14, !tbaa !24
  %t319 = add i64 %t317, 1
  store i64 %t319, ptr %l14, !tbaa !24
  br label %bb11
bb43:
  %t321 = load ptr, ptr %l0, !tbaa !29
  %t322 = load %"compiler/source:Span", ptr %l1
  %t323 = load i64, ptr %l7, !tbaa !24
  %t325 = trunc i64 %t323 to i32
  store { i64, [3 x i64] } zeroinitializer, ptr %t327
  %t328 = getelementptr { i64, [3 x i64] }, ptr %t327, i32 0, i32 0
  store i64 5, ptr %t328
  %t330 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t322, 0
  %t332 = insertvalue { %"compiler/source:Span", i32, i32 } %t330, i32 0, 1
  %t334 = insertvalue { %"compiler/source:Span", i32, i32 } %t332, i32 %t325, 2
  %t335 = getelementptr { i64, [3 x i64] }, ptr %t327, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t334, ptr %t335
  %t336 = load { i64, [3 x i64] }, ptr %t327
  %t338 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t336, ptr %t338
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t321, ptr %t338)
  br label %bb44
bb44:
  %t341 = load ptr, ptr %l0, !tbaa !29
  %t343 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t341)
  store ptr %t343, ptr %l189
  br label %bb45
bb45:
  %t344 = load ptr, ptr %l189, !tbaa !29
  %t346 = getelementptr %"compiler/check:frame", ptr %t344, i32 0, i32 11
  %t348 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t346)
  %t349 = extractvalue { i32, i64 } %t348, 1
  %t350 = extractvalue { i32, i64 } %t348, 0
  store i32 %t350, ptr %l193
  %t351 = icmp ne i32 %t350, 0
  br i1 %t351, label %bb47, label %ok.352, !prof !99
ok.352:
  store i64 %t349, ptr %l192
  br label %bb46
bb46:
  %t353 = load i64, ptr %l192, !tbaa !24
  store i64 %t353, ptr %l187, !tbaa !24
  br label %bb49
bb47:
  br label %bb48
bb48:
  call void @__olang_ert_req_clear()
  br label %bb49
bb49:
  %t354 = load ptr, ptr %l0, !tbaa !29
  %t355 = load i64, ptr %l7, !tbaa !24
  %t356 = load i64, ptr %l8, !tbaa !24
  %t357 = load i64, ptr %l9, !tbaa !24
  %t358 = load i64, ptr %l5, !tbaa !24
  %t364 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %t354, i64 %t355, i64 %t356, i64 %t357, i64 %t358)
  store ptr %t364, ptr %l199
  br label %bb50
bb50:
  %t365 = load ptr, ptr %l199, !tbaa !29
  %t366 = load ptr, ptr %l0, !tbaa !29
  %t367 = load %"compiler/source:Span", ptr %l1
  store { i64, [3 x i64] } zeroinitializer, ptr %t369
  %t370 = getelementptr { i64, [3 x i64] }, ptr %t369, i32 0, i32 0
  store i64 4, ptr %t370
  %t372 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t367, 0
  %t374 = insertvalue { %"compiler/source:Span", ptr, ptr } %t372, ptr %t365, 1
  %t375 = insertvalue { %"compiler/source:Span", ptr, ptr } %t374, ptr null, 2
  %t376 = getelementptr { i64, [3 x i64] }, ptr %t369, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t375, ptr %t376
  %t377 = load { i64, [3 x i64] }, ptr %t369
  %t379 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t377, ptr %t379
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t366, ptr %t379)
  br label %bb51
bb51:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrollElem(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l8 = alloca ptr
  %l12 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca i32
  %l24 = alloca ptr
  %l26 = alloca %"compiler/source:Span"
  %l29 = alloca { i64, ptr }
  %l31 = alloca %"compiler/msgs:Msg"
  %l32 = alloca i64
  %l38 = alloca i32
  %l41 = alloca i1
  %l43 = alloca ptr
  %l45 = alloca %"compiler/source:Span"
  %l48 = alloca { i64, ptr }
  %l50 = alloca %"compiler/msgs:Msg"
  %l51 = alloca i64
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l8, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 12
  %t13 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t9, i64 %a2)
  store ptr %t13, ptr %l12
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l12, !tbaa !29
  %t16 = getelementptr %"compiler/typed:Body", ptr %t14, i32 0, i32 2
  %t17 = load i32, ptr %t16, !tbaa !23
  %t18 = load ptr, ptr %l8, !tbaa !29
  %t20 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t18, i32 %t17)
  store i32 %t20, ptr %l15
  br label %bb2
bb2:
  %t21 = load i32, ptr %l15, !tbaa !23
  store i32 %t21, ptr %l3, !tbaa !23
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l16, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i32, ptr %l3, !tbaa !23
  %t27 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t27, ptr %l19
  br label %bb3
bb3:
  %t28 = load ptr, ptr %l16, !tbaa !29
  %t29 = load i32, ptr %l19, !tbaa !23
  %t30 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t28, i32 %t29)
  store i32 %t30, ptr %l20
  br label %bb4
bb4:
  %t31 = load i32, ptr %l20, !tbaa !23
  store i32 %t31, ptr %l4, !tbaa !23
  %t32 = load i32, ptr %l4, !tbaa !23
  %t33 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t36 = icmp eq i32 %t32, %t33
  br i1 %t36, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l24, !tbaa !29
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t39)
  store %"compiler/source:Span" %t41, ptr %l26
  br label %bb7
bb6:
  br label %bb11
bb7:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load i32, ptr %l3, !tbaa !23
  %t46 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t42, i32 %t43)
  store { i64, ptr } %t46, ptr %l29
  br label %bb8
bb8:
  %t47 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t47, 0
  %t49 = extractvalue { i64, ptr } %t47, 1
  %t50 = mul i64 %t48, 1
  %t51 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t50)
  call void @llvm.memcpy.p0.p0.i64(ptr %t51, ptr %t49, i64 %t50, i1 false)
  %t52 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t51, 1
  %t55 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eComptimeForSource(ptr %s1, ptr %s1, { i64, ptr } %t53)
  store %"compiler/msgs:Msg" %t55, ptr %l31
  br label %bb9
bb9:
  %t56 = load ptr, ptr %l24, !tbaa !29
  %t57 = load %"compiler/source:Span", ptr %l26
  %t58 = load %"compiler/msgs:Msg", ptr %l31
  %t59 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t56, %"compiler/source:Span" %t57, %"compiler/msgs:Msg" %t58)
  store i64 %t59, ptr %l32
  br label %bb10
bb10:
  %t60 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  store i32 %t60, ptr %rv
  br label %ret
bb11:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Program", ptr %t65, i32 0, i32 2
  %t68 = load i32, ptr %l4, !tbaa !23
  %t71 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t67, i32 %t68)
  store i32 %t71, ptr %l38
  br label %bb12
bb12:
  %t72 = load i32, ptr %l38, !tbaa !23
  store i32 %t72, ptr %l5, !tbaa !23
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load i32, ptr %l5, !tbaa !23
  %t77 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrollable(ptr %v0, ptr %t73, i32 %t74)
  store i1 %t77, ptr %l41
  br label %bb13
bb13:
  %t78 = load i1, ptr %l41, !tbaa !21
  %t79 = xor i1 %t78, true
  br i1 %t79, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s2
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l43, !tbaa !29
  %t82 = load ptr, ptr %l1, !tbaa !29
  %t84 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t82)
  store %"compiler/source:Span" %t84, ptr %l45
  br label %bb16
bb15:
  br label %bb20
bb16:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load i32, ptr %l5, !tbaa !23
  %t89 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t85, i32 %t86)
  store { i64, ptr } %t89, ptr %l48
  br label %bb17
bb17:
  %t90 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t90, 0
  %t92 = extractvalue { i64, ptr } %t90, 1
  %t93 = mul i64 %t91, 1
  %t94 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t93)
  call void @llvm.memcpy.p0.p0.i64(ptr %t94, ptr %t92, i64 %t93, i1 false)
  %t95 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %t94, 1
  %t98 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eComptimeForElem(ptr %s2, ptr %s2, { i64, ptr } %t96)
  store %"compiler/msgs:Msg" %t98, ptr %l50
  br label %bb18
bb18:
  %t99 = load ptr, ptr %l43, !tbaa !29
  %t100 = load %"compiler/source:Span", ptr %l45
  %t101 = load %"compiler/msgs:Msg", ptr %l50
  %t102 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t99, %"compiler/source:Span" %t100, %"compiler/msgs:Msg" %t101)
  store i64 %t102, ptr %l51
  br label %bb19
bb19:
  %t103 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  store i32 %t103, ptr %rv
  br label %ret
bb20:
  %t105 = load i32, ptr %l5, !tbaa !23
  store i32 %t105, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evarDecl(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca i1
  %l12 = alloca i64
  %l13 = alloca i32
  %l14 = alloca { i64, [2 x i64] }
  %l15 = alloca %"compiler/source:Span"
  %l16 = alloca %"compiler/source:Span"
  %l17 = alloca i32
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca %"compiler/source:Span"
  %l25 = alloca i64
  %l27 = alloca i32
  %l28 = alloca ptr
  %l29 = alloca %"compiler/check:unsetCand"
  %l30 = alloca i1
  %l31 = alloca i32
  %l32 = alloca i32
  %l33 = alloca { i64, [3 x i64] }
  %l35 = alloca %"compiler/source:Span"
  %l36 = alloca { i64, [3 x i64] }
  %l37 = alloca ptr
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i1
  %l41 = alloca i64
  %l42 = alloca i1
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i1
  %l46 = alloca %"compiler/typed:Local"
  %l49 = alloca i1
  %l53 = alloca i1
  %l58 = alloca i1
  %l68 = alloca i64
  %l71 = alloca i64
  %l91 = alloca { i64, ptr }
  %l94 = alloca i64
  %l99 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %l106 = alloca i1
  %l108 = alloca ptr
  %l110 = alloca ptr
  %l112 = alloca i64
  %l114 = alloca ptr
  %l118 = alloca %"compiler/typed:Local"
  %l121 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l122 = alloca i1
  %l123 = alloca i32
  %l124 = alloca ptr
  %l127 = alloca i32
  %l128 = alloca i1
  %l129 = alloca i1
  %l132 = alloca ptr
  %l133 = alloca %"compiler/source:Span"
  %l134 = alloca ptr
  %l137 = alloca i32
  %l138 = alloca { i64, ptr }
  %l140 = alloca %"compiler/msgs:Msg"
  %l141 = alloca i64
  %l142 = alloca ptr
  %l143 = alloca %"compiler/source:Span"
  %l146 = alloca i32
  %l147 = alloca i32
  %l149 = alloca ptr
  %l153 = alloca %"compiler/typed:Local"
  %l155 = alloca i64
  %l156 = alloca ptr
  %l157 = alloca %"compiler/source:Span"
  %l160 = alloca i32
  %l166 = alloca ptr
  %l167 = alloca %"compiler/source:Span"
  %l170 = alloca i32
  %l174 = alloca ptr
  %l178 = alloca ptr
  %l190 = alloca i1
  %l206 = alloca ptr
  %l211 = alloca i1
  %l215 = alloca i1
  %l221 = alloca i1
  %l226 = alloca i32
  %l231 = alloca { i64, [2 x i64] }
  %l234 = alloca i1
  %l238 = alloca ptr
  %l245 = alloca %"compiler/source:Span"
  %l248 = alloca ptr
  %l249 = alloca %"compiler/source:Span"
  %l250 = alloca %"compiler/msgs:Msg"
  %l251 = alloca i64
  %l255 = alloca ptr
  %l262 = alloca %"compiler/source:Span"
  %l265 = alloca ptr
  %l266 = alloca %"compiler/source:Span"
  %l269 = alloca %"compiler/msgs:Msg"
  %l272 = alloca { i64, ptr }
  %l274 = alloca %"compiler/msgs:Msg"
  %l277 = alloca { i64, ptr }
  %l279 = alloca %"compiler/msgs:Msg"
  %l280 = alloca i64
  %l283 = alloca i32
  %l292 = alloca i64
  %l295 = alloca i64
  %l314 = alloca { i64, ptr }
  %l321 = alloca { i64, ptr }
  %l324 = alloca i64
  %l327 = alloca i1
  %l329 = alloca ptr
  %l333 = alloca %"compiler/typed:Local"
  %l336 = alloca ptr
  %l337 = alloca %"compiler/source:Span"
  %l340 = alloca { i64, ptr }
  %l343 = alloca { i64, ptr }
  %l345 = alloca %"compiler/msgs:Msg"
  %l346 = alloca i64
  %l350 = alloca ptr
  %l351 = alloca i64
  %l352 = alloca ptr
  %l354 = alloca ptr
  %l358 = alloca %"compiler/typed:Local"
  %l360 = alloca { i64, [3 x i64] }
  %l363 = alloca { i64, ptr }
  %l366 = alloca { i64, ptr }
  %l368 = alloca %"compiler/msgs:Msg"
  %l372 = alloca %"compiler/check:unsetCand"
  %l374 = alloca ptr
  %l378 = alloca { i64, ptr }
  %l381 = alloca i1
  %l386 = alloca ptr
  %l388 = alloca ptr
  %l391 = alloca i64
  %l392 = alloca i32
  %l397 = alloca i32
  %l400 = alloca i1
  %l405 = alloca i32
  %l410 = alloca i1
  %l415 = alloca i1
  %l419 = alloca i1
  %l426 = alloca ptr
  %l428 = alloca ptr
  %l433 = alloca { i64, ptr }
  %l437 = alloca i32
  %l440 = alloca i1
  %l446 = alloca i1
  %l450 = alloca i1
  %l455 = alloca i1
  %l459 = alloca i1
  %l464 = alloca i32
  %l467 = alloca i1
  %l468 = alloca ptr
  %l473 = alloca i32
  %l474 = alloca i1
  %l477 = alloca { i64, ptr }
  %l482 = alloca ptr
  %l485 = alloca ptr
  %l487 = alloca i32
  %l489 = alloca i1
  %l490 = alloca i1
  %l493 = alloca ptr
  %l495 = alloca i32
  %l496 = alloca i32
  %l500 = alloca i32
  %l501 = alloca ptr
  %l504 = alloca ptr
  %l505 = alloca i32
  %l507 = alloca { i64, ptr }
  %l510 = alloca %"compiler/source:Span"
  %l511 = alloca ptr
  %l524 = alloca i1
  %l528 = alloca ptr
  %l529 = alloca ptr
  %l535 = alloca { i64, [3 x i64] }
  %l539 = alloca i1
  %l544 = alloca i1
  %l547 = alloca { i64, ptr }
  %l551 = alloca { i64, ptr }
  %l554 = alloca i1
  %l559 = alloca { i64, ptr }
  %l563 = alloca ptr
  %l571 = alloca i1
  %l574 = alloca ptr
  %l576 = alloca { i64, ptr }
  %l578 = alloca ptr
  %l583 = alloca i32
  %l586 = alloca i1
  %l591 = alloca ptr
  %l598 = alloca %"compiler/source:Span"
  %l601 = alloca ptr
  %l602 = alloca %"compiler/source:Span"
  %l605 = alloca { i64, ptr }
  %l607 = alloca %"compiler/msgs:Msg"
  %l608 = alloca i64
  %l611 = alloca ptr
  %l614 = alloca i32
  %l615 = alloca i32
  %l618 = alloca i1
  %l621 = alloca ptr
  %l622 = alloca i32
  %l624 = alloca i32
  %l625 = alloca i1
  %l627 = alloca ptr
  %l630 = alloca ptr
  %l631 = alloca i32
  %l633 = alloca { i64, ptr }
  %l636 = alloca %"compiler/source:Span"
  %l637 = alloca ptr
  %l641 = alloca ptr
  %l642 = alloca ptr
  %l648 = alloca { i64, [3 x i64] }
  %l654 = alloca i64
  %l656 = alloca i64
  %l660 = alloca ptr
  %l664 = alloca i64
  %l671 = alloca ptr
  %l677 = alloca i64
  %l684 = alloca i64
  %l688 = alloca ptr
  %l698 = alloca %"compiler/check:unsetCand"
  %l699 = alloca i32
  %l701 = alloca i32
  %l703 = alloca i1
  %l704 = alloca ptr
  %l706 = alloca i32
  %l707 = alloca i1
  %l708 = alloca ptr
  %l709 = alloca %"compiler/source:Span"
  %l710 = alloca %"compiler/source:Span"
  %l711 = alloca i32
  %l717 = alloca ptr
  %l721 = alloca i1
  %l724 = alloca i1
  %l725 = alloca ptr
  %l726 = alloca %"compiler/source:Span"
  %l729 = alloca { i64, ptr }
  %l731 = alloca %"compiler/msgs:Msg"
  %l732 = alloca i64
  %l737 = alloca i1
  %l741 = alloca i1
  %l747 = alloca i1
  %l752 = alloca i32
  %l755 = alloca i1
  %l756 = alloca ptr
  %l761 = alloca i32
  %l762 = alloca i1
  %l763 = alloca ptr
  %l769 = alloca %"compiler/source:Span"
  %l770 = alloca ptr
  %l775 = alloca i32
  %l776 = alloca { i64, ptr }
  %l778 = alloca %"compiler/msgs:Msg"
  %l779 = alloca i64
  %l785 = alloca i1
  %l789 = alloca i1
  %l793 = alloca i1
  %l796 = alloca i1
  %l797 = alloca i1
  %l802 = alloca i64
  %l806 = alloca i1
  %l809 = alloca ptr
  %l812 = alloca i32
  %l813 = alloca i32
  %l817 = alloca i1
  %l820 = alloca i1
  %l823 = alloca ptr
  %l828 = alloca i32
  %l833 = alloca i64
  %l836 = alloca i32
  %l842 = alloca i1
  %l845 = alloca i1
  %l848 = alloca i1
  %l850 = alloca ptr
  %l851 = alloca ptr
  %l853 = alloca { i64, ptr }
  %l856 = alloca %"compiler/source:Span"
  %l858 = alloca i1
  %l861 = alloca { i64, ptr }
  %l868 = alloca i64
  %l874 = alloca i1
  %l878 = alloca i1
  %l883 = alloca i1
  %l886 = alloca ptr
  %l891 = alloca i32
  %l892 = alloca i32
  %l895 = alloca i1
  %l898 = alloca ptr
  %l903 = alloca i32
  %l904 = alloca i32
  %l906 = alloca i1
  %l909 = alloca i1
  %l912 = alloca ptr
  %l916 = alloca %"compiler/typed:Local"
  %l919 = alloca ptr
  %l927 = alloca ptr
  %l936 = alloca %"compiler/check:unsetCand"
  %l941 = alloca i1
  %l946 = alloca ptr
  %l948 = alloca ptr
  %l949 = alloca i64
  %l950 = alloca ptr
  %l956 = alloca { i64, [3 x i64] }
  %l958 = alloca ptr
  %l959 = alloca i64
  %l964 = alloca i1
  %l968 = alloca i1
  %l971 = alloca i1
  %l972 = alloca i1
  %l975 = alloca { i64, ptr }
  %l978 = alloca i1
  %l980 = alloca ptr
  %l982 = alloca ptr
  %l986 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l990 = alloca i1
  %l996 = alloca i1
  %l999 = alloca i1
  %l1001 = alloca ptr
  %l1003 = alloca ptr
  %l1007 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l1009 = alloca { i64, ptr }
  %l1013 = alloca %"compiler/check:fixedInit"
  %l1014 = alloca ptr
  %l1015 = alloca %"compiler/source:Span"
  %l1018 = alloca i32
  %l1027 = alloca ptr
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %s37 = alloca %olang.scope
  %s41 = alloca %olang.scope
  %s44 = alloca %olang.scope
  %s45 = alloca %olang.scope
  %t241 = alloca { i64, [4 x i64] }, align 8
  %t268 = alloca { i64, [3 x i64] }, align 8
  %t330 = alloca { i64, [2 x i64] }, align 8
  %t1445 = alloca { i64, [4 x i64] }, align 8
  %t2097 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:VarDecl", ptr %t1, i32 0, i32 5
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"compiler/ast:VarDecl", ptr %t6, i32 0, i32 2
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = icmp eq ptr %t9, null
  store i1 %t11, ptr %l49, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l49, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  %t14 = load ptr, ptr %l2, !tbaa !29
  %t16 = getelementptr %"compiler/ast:VarDecl", ptr %t14, i32 0, i32 3
  %t17 = load { i64, ptr }, ptr %t16, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t21 = icmp eq i64 %t19, 0
  store i1 %t21, ptr %l53, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb6
bb6:
  %t23 = load i1, ptr %l53, !tbaa !21
  br i1 %t23, label %bb7, label %bb8
bb7:
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t26 = getelementptr %"compiler/ast:VarDecl", ptr %t24, i32 0, i32 4
  %t27 = load i1, ptr %t26, !tbaa !21
  %t29 = xor i1 %t27, true
  store i1 %t29, ptr %l58, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l58, !tbaa !21
  br label %bb9
bb9:
  %t31 = load i1, ptr %l58, !tbaa !21
  br i1 %t31, label %bb10, label %bb11
bb10:
  store i64 0, ptr %l3, !tbaa !24
  %t32 = load ptr, ptr %l2, !tbaa !29
  %t34 = getelementptr %"compiler/ast:VarDecl", ptr %t32, i32 0, i32 0
  %t35 = load { i64, ptr }, ptr %t34, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  store i64 %t37, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t39 = load i64, ptr %l4, !tbaa !24
  %t40 = load i64, ptr %l3, !tbaa !24
  %t43 = icmp sgt i64 %t39, %t40
  br i1 %t43, label %bb12, label %bb13
bb11:
  br label %bb59
bb12:
  %t45 = load i64, ptr %l5, !tbaa !24
  %t47 = icmp sgt i64 %t45, 0
  br i1 %t47, label %bb14, label %bb15
bb13:
  store i64 0, ptr %l68, !tbaa !24
  br label %bb17
bb14:
  %t49 = load i64, ptr %l4, !tbaa !24
  %t50 = load i64, ptr %l3, !tbaa !24
  %t53 = sub i64 %t49, %t50
  %t54 = load i64, ptr %l5, !tbaa !24
  %t57 = add i64 %t53, %t54
  %t59 = sub i64 %t57, 1
  %t60 = load i64, ptr %l5, !tbaa !24
  %t63 = sdiv i64 %t59, %t60
  store i64 %t63, ptr %l71, !tbaa !24
  br label %bb16
bb15:
  store i64 0, ptr %l71, !tbaa !24
  br label %bb16
bb16:
  %t65 = load i64, ptr %l71, !tbaa !24
  store i64 %t65, ptr %l68, !tbaa !24
  br label %bb17
bb17:
  %t66 = load i64, ptr %l68, !tbaa !24
  store i64 %t66, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb18
bb18:
  store %olang.scope zeroinitializer, ptr %s3
  %t67 = load i64, ptr %l7, !tbaa !24
  %t68 = load i64, ptr %l6, !tbaa !24
  %t71 = icmp slt i64 %t67, %t68
  %t73 = xor i1 %t71, true
  br i1 %t73, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s3)
  br label %bb58
bb20:
  br label %bb21
bb21:
  %t75 = load i64, ptr %l3, !tbaa !24
  %t76 = load i64, ptr %l7, !tbaa !24
  %t77 = load i64, ptr %l5, !tbaa !24
  %t80 = mul i64 %t76, %t77
  %t83 = add i64 %t75, %t80
  store i64 %t83, ptr %l8, !tbaa !24
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load ptr, ptr %l2, !tbaa !29
  %t88 = getelementptr %"compiler/ast:VarDecl", ptr %t86, i32 0, i32 0
  %t89 = load { i64, ptr }, ptr %t88, !tbaa !27
  store { i64, ptr } %t89, ptr %l91, !tbaa !27
  %t90 = load i64, ptr %l8, !tbaa !24
  %t92 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = getelementptr i32, ptr %t93, i64 %t90
  %t95 = load i32, ptr %t94, !tbaa !33
  %t98 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %t85, i32 %t95)
  store i64 %t98, ptr %l94
  br label %bb22
bb22:
  %t99 = load i64, ptr %l94, !tbaa !24
  store i64 %t99, ptr %l9, !tbaa !24
  %t100 = load i64, ptr %l9, !tbaa !24
  %t102 = icmp slt i64 %t100, 0
  br i1 %t102, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s4
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load ptr, ptr %l2, !tbaa !29
  %t107 = getelementptr %"compiler/ast:VarDecl", ptr %t105, i32 0, i32 1
  %t108 = load { i64, ptr }, ptr %t107, !tbaa !27
  store { i64, ptr } %t108, ptr %l99, !tbaa !27
  %t109 = load i64, ptr %l8, !tbaa !24
  %t111 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr %"compiler/source:Span", ptr %t112, i64 %t109
  %t114 = load %"compiler/source:Span", ptr %t113
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s4, ptr %t104, %"compiler/source:Span" %t114, { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d41, i32 0, i32 1) })
  br label %bb25
bb24:
  br label %bb26
bb25:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  br label %bb57
bb26:
  %t117 = load ptr, ptr %l2, !tbaa !29
  %t119 = getelementptr %"compiler/ast:VarDecl", ptr %t117, i32 0, i32 1
  %t120 = load { i64, ptr }, ptr %t119, !tbaa !27
  store { i64, ptr } %t120, ptr %l103, !tbaa !27
  %t121 = load i64, ptr %l8, !tbaa !24
  %t123 = getelementptr { i64, ptr }, ptr %l103, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !27
  %t125 = getelementptr %"compiler/source:Span", ptr %t124, i64 %t121
  %t126 = load %"compiler/source:Span", ptr %t125
  store %"compiler/source:Span" %t126, ptr %l10
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/check:Checker", ptr %t128, i32 0, i32 20
  store ptr %t130, ptr %l108, !tbaa !29
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t131)
  store ptr %t133, ptr %l110
  br label %bb27
bb27:
  %t134 = load ptr, ptr %l110, !tbaa !29
  %t136 = getelementptr %"compiler/check:frame", ptr %t134, i32 0, i32 2
  %t137 = load i64, ptr %t136, !tbaa !24
  store i64 %t137, ptr %l112, !tbaa !24
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t138)
  store ptr %t140, ptr %l114
  br label %bb28
bb28:
  %t141 = load ptr, ptr %l114, !tbaa !29
  %t143 = getelementptr %"compiler/typed:Body", ptr %t141, i32 0, i32 7
  %t144 = load i64, ptr %l9, !tbaa !24
  %t147 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t143, i64 %t144)
  store %"compiler/typed:Local" %t147, ptr %l118
  br label %bb29
bb29:
  %t148 = getelementptr %"compiler/typed:Local", ptr %l118, i32 0, i32 1
  %t149 = getelementptr %"compiler/source:Span", ptr %t148, i32 0, i32 0
  %t150 = load i32, ptr %t149, !tbaa !23
  %t152 = sext i32 %t150 to i64
  %t153 = load i64, ptr %l112, !tbaa !24
  %t155 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s3, i64 %t153, i64 %t152)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t155, ptr %l121
  br label %bb30
bb30:
  %t156 = load ptr, ptr %l108, !tbaa !29
  %t157 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l121
  %t158 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H190b78e3c1eec037529224679e114a85(ptr %v0, ptr %t156, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t157)
  %t159 = extractvalue { i32, i1 } %t158, 1
  %t160 = extractvalue { i32, i1 } %t158, 0
  store i32 %t160, ptr %l123
  %t161 = icmp ne i32 %t160, 0
  br i1 %t161, label %bb32, label %ok.162, !prof !99
ok.162:
  store i1 %t159, ptr %l122
  br label %bb31
bb31:
  %t163 = load i1, ptr %l122, !tbaa !21
  store i1 %t163, ptr %l106, !tbaa !21
  br label %bb34
bb32:
  br label %bb33
bb33:
  call void @__olang_ert_req_clear()
  store i1 false, ptr %l106, !tbaa !21
  br label %bb34
bb34:
  %t164 = load i1, ptr %l106, !tbaa !21
  store i1 %t164, ptr %l11, !tbaa !21
  %t165 = load ptr, ptr %l0, !tbaa !29
  store ptr %t165, ptr %l124, !tbaa !29
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load i64, ptr %l9, !tbaa !24
  %t170 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t166, i64 %t167)
  store i32 %t170, ptr %l127
  br label %bb35
bb35:
  %t171 = load ptr, ptr %l124, !tbaa !29
  %t172 = load i32, ptr %l127, !tbaa !23
  %t173 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunArrayValue(ptr %v0, ptr %t171, i32 %t172)
  store i1 %t173, ptr %l128
  br label %bb36
bb36:
  %t174 = load i1, ptr %l128, !tbaa !21
  br i1 %t174, label %bb37, label %bb38
bb37:
  %t175 = load i1, ptr %l11, !tbaa !21
  %t177 = xor i1 %t175, true
  store i1 %t177, ptr %l129, !tbaa !21
  br label %bb39
bb38:
  store i1 false, ptr %l129, !tbaa !21
  br label %bb39
bb39:
  %t179 = load i1, ptr %l129, !tbaa !21
  br i1 %t179, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s5
  %t180 = load ptr, ptr %l0, !tbaa !29
  store ptr %t180, ptr %l132, !tbaa !29
  %t181 = load %"compiler/source:Span", ptr %l10
  store %"compiler/source:Span" %t181, ptr %l133
  %t182 = load ptr, ptr %l0, !tbaa !29
  store ptr %t182, ptr %l134, !tbaa !29
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t184 = load i64, ptr %l9, !tbaa !24
  %t187 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t183, i64 %t184)
  store i32 %t187, ptr %l137
  br label %bb42
bb41:
  br label %bb46
bb42:
  %t188 = load ptr, ptr %l134, !tbaa !29
  %t189 = load i32, ptr %l137, !tbaa !23
  %t190 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s5, ptr %t188, i32 %t189)
  store { i64, ptr } %t190, ptr %l138
  br label %bb43
bb43:
  %t191 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t192 = extractvalue { i64, ptr } %t191, 0
  %t193 = extractvalue { i64, ptr } %t191, 1
  %t194 = mul i64 %t192, 1
  %t195 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t194)
  call void @llvm.memcpy.p0.p0.i64(ptr %t195, ptr %t193, i64 %t194, i1 false)
  %t196 = insertvalue { i64, ptr } undef, i64 %t192, 0
  %t197 = insertvalue { i64, ptr } %t196, ptr %t195, 1
  %t199 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayNestedByValue(ptr %s5, ptr %s5, { i64, ptr } %t197)
  store %"compiler/msgs:Msg" %t199, ptr %l140
  br label %bb44
bb44:
  %t200 = load ptr, ptr %l132, !tbaa !29
  %t201 = load %"compiler/source:Span", ptr %l133
  %t202 = load %"compiler/msgs:Msg", ptr %l140
  %t203 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t200, %"compiler/source:Span" %t201, %"compiler/msgs:Msg" %t202)
  store i64 %t203, ptr %l141
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s5)
  br label %bb46
bb46:
  %t204 = load ptr, ptr %l0, !tbaa !29
  store ptr %t204, ptr %l142, !tbaa !29
  %t205 = load %"compiler/source:Span", ptr %l10
  store %"compiler/source:Span" %t205, ptr %l143
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t207 = load i64, ptr %l9, !tbaa !24
  %t210 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t206, i64 %t207)
  store i32 %t210, ptr %l146
  br label %bb47
bb47:
  store i32 6, ptr %l147
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t211)
  store ptr %t213, ptr %l149
  br label %bb48
bb48:
  %t214 = load ptr, ptr %l149, !tbaa !29
  %t216 = getelementptr %"compiler/typed:Body", ptr %t214, i32 0, i32 7
  %t217 = load i64, ptr %l9, !tbaa !24
  %t220 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t216, i64 %t217)
  store %"compiler/typed:Local" %t220, ptr %l153
  br label %bb49
bb49:
  %t221 = getelementptr %"compiler/typed:Local", ptr %l153, i32 0, i32 5
  %t222 = load { i64, [2 x i64] }, ptr %t221
  %t223 = load ptr, ptr %l142, !tbaa !29
  %t224 = load %"compiler/source:Span", ptr %l143
  %t225 = load i32, ptr %l146, !tbaa !23
  %t226 = load i32, ptr %l147, !range !{i32 0, i32 7}
  %t228 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t223, i32 0, %"compiler/source:Span" %t224, i32 %t225, i32 %t226, { i64, [2 x i64] } %t222)
  store i64 %t228, ptr %l155
  br label %bb50
bb50:
  %t229 = load i64, ptr %l155, !tbaa !24
  store i64 %t229, ptr %l12, !tbaa !24
  %t230 = load ptr, ptr %l0, !tbaa !29
  store ptr %t230, ptr %l156, !tbaa !29
  %t231 = load %"compiler/source:Span", ptr %l10
  store %"compiler/source:Span" %t231, ptr %l157
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t233 = load i64, ptr %l9, !tbaa !24
  %t236 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t232, i64 %t233)
  store i32 %t236, ptr %l160
  br label %bb51
bb51:
  %t237 = load i64, ptr %l9, !tbaa !24
  %t239 = trunc i64 %t237 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t241
  %t242 = getelementptr { i64, [4 x i64] }, ptr %t241, i32 0, i32 0
  store i64 0, ptr %t242
  %t243 = load %"compiler/source:Span", ptr %l157
  %t244 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t243, 0
  %t245 = load i32, ptr %l160, !tbaa !23
  %t246 = insertvalue { %"compiler/source:Span", i32, i32 } %t244, i32 %t245, 1
  %t248 = insertvalue { %"compiler/source:Span", i32, i32 } %t246, i32 %t239, 2
  %t249 = getelementptr { i64, [4 x i64] }, ptr %t241, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t248, ptr %t249
  %t250 = load { i64, [4 x i64] }, ptr %t241
  %t252 = call ptr @__olang_scope_alloc_a(ptr %s3, i64 40, i64 8)
  store { i64, [4 x i64] } %t250, ptr %t252
  %t253 = load ptr, ptr %l156, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroNeed(ptr %v0, ptr %s3, ptr %t253, ptr %t252)
  br label %bb52
bb52:
  %t255 = load ptr, ptr %l0, !tbaa !29
  store ptr %t255, ptr %l166, !tbaa !29
  %t256 = load %"compiler/source:Span", ptr %l10
  store %"compiler/source:Span" %t256, ptr %l167
  %t257 = load i64, ptr %l12, !tbaa !24
  %t259 = trunc i64 %t257 to i32
  store i32 %t259, ptr %l170, !tbaa !23
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t262 = load %"compiler/source:Span", ptr %l10
  %t263 = load i64, ptr %l9, !tbaa !24
  %t267 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t261, %"compiler/source:Span" %t262, i64 %t263)
  store ptr %t267, ptr %l174
  br label %bb53
bb53:
  store { i64, [3 x i64] } zeroinitializer, ptr %t268
  %t269 = getelementptr { i64, [3 x i64] }, ptr %t268, i32 0, i32 0
  store i64 0, ptr %t269
  %t270 = load %"compiler/source:Span", ptr %l167
  %t271 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t270, 0
  %t272 = load i32, ptr %l170, !tbaa !23
  %t273 = insertvalue { %"compiler/source:Span", i32, ptr } %t271, i32 %t272, 1
  %t274 = load ptr, ptr %l174, !tbaa !29
  %t275 = insertvalue { %"compiler/source:Span", i32, ptr } %t273, ptr %t274, 2
  %t276 = getelementptr { i64, [3 x i64] }, ptr %t268, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t275, ptr %t276
  %t277 = load { i64, [3 x i64] }, ptr %t268
  %t279 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t277, ptr %t279
  %t280 = load ptr, ptr %l166, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t280, ptr %t279)
  br label %bb54
bb54:
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t284 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t282)
  store ptr %t284, ptr %l178
  br label %bb55
bb55:
  %t285 = load ptr, ptr %l178, !tbaa !29
  %t287 = getelementptr %"compiler/typed:Body", ptr %t285, i32 0, i32 10
  %t288 = load i64, ptr %l12, !tbaa !24
  %t290 = trunc i64 %t288 to i32
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2ePush_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t287, i32 %t290)
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s3)
  br label %bb57
bb57:
  %t294 = load i64, ptr %l7, !tbaa !24
  %t296 = add i64 %t294, 1
  store i64 %t296, ptr %l7, !tbaa !24
  br label %bb18
bb58:
  br label %ret
bb59:
  %t298 = load ptr, ptr %l2, !tbaa !29
  %t300 = getelementptr %"compiler/ast:VarDecl", ptr %t298, i32 0, i32 3
  %t301 = load { i64, ptr }, ptr %t300, !tbaa !27
  %t303 = extractvalue { i64, ptr } %t301, 0
  %t305 = icmp ne i64 %t303, 0
  br i1 %t305, label %bb60, label %bb61
bb60:
  %t307 = load ptr, ptr %l2, !tbaa !29
  %t309 = getelementptr %"compiler/ast:VarDecl", ptr %t307, i32 0, i32 3
  %t310 = load { i64, ptr }, ptr %t309, !tbaa !27
  %t312 = extractvalue { i64, ptr } %t310, 0
  %t313 = load ptr, ptr %l2, !tbaa !29
  %t315 = getelementptr %"compiler/ast:VarDecl", ptr %t313, i32 0, i32 0
  %t316 = load { i64, ptr }, ptr %t315, !tbaa !27
  %t318 = extractvalue { i64, ptr } %t316, 0
  %t321 = icmp ne i64 %t312, %t318
  store i1 %t321, ptr %l190, !tbaa !21
  br label %bb62
bb61:
  store i1 false, ptr %l190, !tbaa !21
  br label %bb62
bb62:
  %t323 = load i1, ptr %l190, !tbaa !21
  br i1 %t323, label %bb63, label %bb64
bb63:
  store %olang.scope zeroinitializer, ptr %s7
  %t324 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s7, ptr %t324, %"compiler/source:Span" %a1, { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d42, i32 0, i32 1) })
  br label %bb65
bb64:
  br label %bb66
bb65:
  call void @__olang_scope_close(ptr %s7)
  br label %ret
bb66:
  %t328 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t328, ptr %l13, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t330
  %t331 = getelementptr { i64, [2 x i64] }, ptr %t330, i32 0, i32 0
  store i64 5, ptr %t331
  %t332 = load { i64, [2 x i64] }, ptr %t330
  store { i64, [2 x i64] } %t332, ptr %l14
  %t334 = load ptr, ptr %l2, !tbaa !29
  %t336 = getelementptr %"compiler/ast:VarDecl", ptr %t334, i32 0, i32 2
  %t337 = load ptr, ptr %t336, !tbaa !29
  %t339 = icmp eq ptr %t337, null
  %t341 = xor i1 %t339, true
  br i1 %t341, label %bb67, label %bb68
bb67:
  %t343 = load ptr, ptr %l0, !tbaa !29
  store ptr %t343, ptr %l206, !tbaa !29
  %t344 = load ptr, ptr %l2, !tbaa !29
  %t346 = getelementptr %"compiler/ast:VarDecl", ptr %t344, i32 0, i32 3
  %t347 = load { i64, ptr }, ptr %t346, !tbaa !27
  %t349 = extractvalue { i64, ptr } %t347, 0
  %t351 = icmp sgt i64 %t349, 0
  br i1 %t351, label %bb69, label %bb70
bb68:
  br label %bb114
bb69:
  %t353 = load ptr, ptr %l2, !tbaa !29
  %t355 = getelementptr %"compiler/ast:VarDecl", ptr %t353, i32 0, i32 4
  %t356 = load i1, ptr %t355, !tbaa !21
  %t358 = xor i1 %t356, true
  store i1 %t358, ptr %l211, !tbaa !21
  br label %bb71
bb70:
  store i1 false, ptr %l211, !tbaa !21
  br label %bb71
bb71:
  %t360 = load i1, ptr %l211, !tbaa !21
  br i1 %t360, label %bb72, label %bb73
bb72:
  %t361 = load ptr, ptr %l2, !tbaa !29
  %t363 = getelementptr %"compiler/ast:VarDecl", ptr %t361, i32 0, i32 2
  %t364 = load ptr, ptr %t363, !tbaa !29
  %t366 = icmp eq ptr %t364, null
  br i1 %t366, label %bb74, label %bb75
bb73:
  store i1 false, ptr %l215, !tbaa !21
  br label %bb78
bb74:
  call void @__olang_check_failed(ptr @olang_loc_31b59b203b4a4e3f_1cfff4f24a22d803)
  unreachable
bb75:
  br label %bb76
bb76:
  %t368 = load ptr, ptr %l2, !tbaa !29
  %t370 = getelementptr %"compiler/ast:VarDecl", ptr %t368, i32 0, i32 2
  %t371 = load ptr, ptr %t370, !tbaa !29
  %t373 = call i1 @compiler_2fcheck_2erefWrittenTop(ptr %v1, ptr %t371)
  store i1 %t373, ptr %l221
  br label %bb77
bb77:
  %t374 = load i1, ptr %l221, !tbaa !21
  %t375 = xor i1 %t374, true
  store i1 %t375, ptr %l215, !tbaa !21
  br label %bb78
bb78:
  %t377 = load i1, ptr %l215, !tbaa !21
  %t378 = load ptr, ptr %l206, !tbaa !29
  %t379 = getelementptr %"compiler/check:Checker", ptr %t378, i32 0, i32 77
  store i1 %t377, ptr %t379, !tbaa !21
  %t380 = load ptr, ptr %l0, !tbaa !29
  %t381 = load ptr, ptr %l2, !tbaa !29
  %t383 = getelementptr %"compiler/ast:VarDecl", ptr %t381, i32 0, i32 2
  %t384 = load ptr, ptr %t383, !tbaa !29
  %t387 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %t380, ptr %t384)
  store i32 %t387, ptr %l226
  br label %bb79
bb79:
  %t388 = load i32, ptr %l226, !tbaa !23
  store i32 %t388, ptr %l13, !tbaa !23
  %t389 = load ptr, ptr %l0, !tbaa !29
  %t391 = getelementptr %"compiler/check:Checker", ptr %t389, i32 0, i32 77
  store i1 false, ptr %t391, !tbaa !21
  %t392 = load ptr, ptr %l0, !tbaa !29
  %t393 = load ptr, ptr %l2, !tbaa !29
  %t395 = getelementptr %"compiler/ast:VarDecl", ptr %t393, i32 0, i32 2
  %t396 = load ptr, ptr %t395, !tbaa !29
  %t399 = call { i64, [2 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emarkOf(ptr %v0, ptr %v1, ptr %t392, ptr %t396)
  store { i64, [2 x i64] } %t399, ptr %l231
  br label %bb80
bb80:
  %t400 = load { i64, [2 x i64] }, ptr %l231
  store { i64, [2 x i64] } %t400, ptr %l14
  %t401 = load ptr, ptr %l2, !tbaa !29
  %t403 = getelementptr %"compiler/ast:VarDecl", ptr %t401, i32 0, i32 4
  %t404 = load i1, ptr %t403, !tbaa !21
  br i1 %t404, label %bb81, label %bb82
bb81:
  %t406 = load ptr, ptr %l2, !tbaa !29
  %t408 = getelementptr %"compiler/ast:VarDecl", ptr %t406, i32 0, i32 5
  %t409 = load i1, ptr %t408, !tbaa !21
  %t411 = xor i1 %t409, true
  store i1 %t411, ptr %l234, !tbaa !21
  br label %bb83
bb82:
  store i1 false, ptr %l234, !tbaa !21
  br label %bb83
bb83:
  %t413 = load i1, ptr %l234, !tbaa !21
  br i1 %t413, label %bb84, label %bb85
bb84:
  %t414 = load ptr, ptr %l0, !tbaa !29
  store ptr %t414, ptr %l238, !tbaa !29
  %t415 = load ptr, ptr %l2, !tbaa !29
  %t417 = getelementptr %"compiler/ast:VarDecl", ptr %t415, i32 0, i32 2
  %t418 = load ptr, ptr %t417, !tbaa !29
  %t420 = icmp eq ptr %t418, null
  br i1 %t420, label %bb86, label %bb87
bb85:
  %t422 = load ptr, ptr %l2, !tbaa !29
  %t424 = getelementptr %"compiler/ast:VarDecl", ptr %t422, i32 0, i32 4
  %t425 = load i1, ptr %t424, !tbaa !21
  %t427 = xor i1 %t425, true
  br i1 %t427, label %bb95, label %bb96
bb86:
  call void @__olang_check_failed(ptr @olang_loc_35f48b5c7c141c20_d3954a821088874)
  unreachable
bb87:
  br label %bb88
bb88:
  %t429 = load ptr, ptr %l2, !tbaa !29
  %t431 = getelementptr %"compiler/ast:VarDecl", ptr %t429, i32 0, i32 2
  %t432 = load ptr, ptr %t431, !tbaa !29
  %t433 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t434 = load ptr, ptr %l238, !tbaa !29
  %t437 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emutBefore(ptr %v0, ptr %v1, ptr %t434, ptr %t432, i32 %t433)
  store %"compiler/source:Span" %t437, ptr %l245
  br label %bb89
bb89:
  %t438 = load %"compiler/source:Span", ptr %l245
  store %"compiler/source:Span" %t438, ptr %l15
  %t439 = getelementptr %"compiler/source:Span", ptr %l15, i32 0, i32 0
  %t440 = load i32, ptr %t439, !tbaa !23
  %t442 = icmp sge i32 %t440, 0
  br i1 %t442, label %bb90, label %bb91
bb90:
  store %olang.scope zeroinitializer, ptr %s10
  %t444 = load ptr, ptr %l0, !tbaa !29
  store ptr %t444, ptr %l248, !tbaa !29
  %t445 = load %"compiler/source:Span", ptr %l15
  store %"compiler/source:Span" %t445, ptr %l249
  %t446 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eMutOnInferredLocal(ptr %s10)
  store %"compiler/msgs:Msg" %t446, ptr %l250
  br label %bb92
bb91:
  br label %bb94
bb92:
  %t447 = load ptr, ptr %l248, !tbaa !29
  %t448 = load %"compiler/source:Span", ptr %l249
  %t449 = load %"compiler/msgs:Msg", ptr %l250
  %t450 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s10, ptr %t447, %"compiler/source:Span" %t448, %"compiler/msgs:Msg" %t449)
  store i64 %t450, ptr %l251
  br label %bb93
bb93:
  call void @__olang_scope_close(ptr %s10)
  br label %bb94
bb94:
  br label %bb113
bb95:
  %t451 = load ptr, ptr %l0, !tbaa !29
  store ptr %t451, ptr %l255, !tbaa !29
  %t452 = load ptr, ptr %l2, !tbaa !29
  %t454 = getelementptr %"compiler/ast:VarDecl", ptr %t452, i32 0, i32 2
  %t455 = load ptr, ptr %t454, !tbaa !29
  %t457 = icmp eq ptr %t455, null
  br i1 %t457, label %bb97, label %bb98
bb96:
  br label %bb112
bb97:
  call void @__olang_check_failed(ptr @olang_loc_458efae6ce1c735_ac6225d3d907fb69)
  unreachable
bb98:
  br label %bb99
bb99:
  %t459 = load ptr, ptr %l2, !tbaa !29
  %t461 = getelementptr %"compiler/ast:VarDecl", ptr %t459, i32 0, i32 2
  %t462 = load ptr, ptr %t461, !tbaa !29
  %t463 = load i32, ptr %l13, !tbaa !23
  %t464 = load ptr, ptr %l255, !tbaa !29
  %t467 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emutBefore(ptr %v0, ptr %v1, ptr %t464, ptr %t462, i32 %t463)
  store %"compiler/source:Span" %t467, ptr %l262
  br label %bb100
bb100:
  %t468 = load %"compiler/source:Span", ptr %l262
  store %"compiler/source:Span" %t468, ptr %l16
  %t469 = getelementptr %"compiler/source:Span", ptr %l16, i32 0, i32 0
  %t470 = load i32, ptr %t469, !tbaa !23
  %t472 = icmp sge i32 %t470, 0
  br i1 %t472, label %bb101, label %bb102
bb101:
  store %olang.scope zeroinitializer, ptr %s13
  %t474 = load ptr, ptr %l0, !tbaa !29
  store ptr %t474, ptr %l265, !tbaa !29
  %t475 = load %"compiler/source:Span", ptr %l16
  store %"compiler/source:Span" %t475, ptr %l266
  %t476 = load ptr, ptr %l2, !tbaa !29
  %t478 = getelementptr %"compiler/ast:VarDecl", ptr %t476, i32 0, i32 5
  %t479 = load i1, ptr %t478, !tbaa !21
  br i1 %t479, label %bb103, label %bb104
bb102:
  br label %bb111
bb103:
  %t481 = load ptr, ptr %l0, !tbaa !29
  %t482 = load i32, ptr %l13, !tbaa !23
  %t485 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s13, ptr %t481, i32 %t482)
  store { i64, ptr } %t485, ptr %l272
  br label %bb105
bb104:
  %t486 = load ptr, ptr %l0, !tbaa !29
  %t487 = load i32, ptr %l13, !tbaa !23
  %t490 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s13, ptr %t486, i32 %t487)
  store { i64, ptr } %t490, ptr %l277
  br label %bb107
bb105:
  %t491 = load { i64, ptr }, ptr %l272, !tbaa !27
  %t492 = extractvalue { i64, ptr } %t491, 0
  %t493 = extractvalue { i64, ptr } %t491, 1
  %t494 = mul i64 %t492, 1
  %t495 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t494)
  call void @llvm.memcpy.p0.p0.i64(ptr %t495, ptr %t493, i64 %t494, i1 false)
  %t496 = insertvalue { i64, ptr } undef, i64 %t492, 0
  %t497 = insertvalue { i64, ptr } %t496, ptr %t495, 1
  %t499 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eMutOnValueField(ptr %s13, ptr %s13, { i64, ptr } %t497)
  store %"compiler/msgs:Msg" %t499, ptr %l274
  br label %bb106
bb106:
  %t500 = load %"compiler/msgs:Msg", ptr %l274
  store %"compiler/msgs:Msg" %t500, ptr %l269
  br label %bb109
bb107:
  %t501 = load { i64, ptr }, ptr %l277, !tbaa !27
  %t502 = extractvalue { i64, ptr } %t501, 0
  %t503 = extractvalue { i64, ptr } %t501, 1
  %t504 = mul i64 %t502, 1
  %t505 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t504)
  call void @llvm.memcpy.p0.p0.i64(ptr %t505, ptr %t503, i64 %t504, i1 false)
  %t506 = insertvalue { i64, ptr } undef, i64 %t502, 0
  %t507 = insertvalue { i64, ptr } %t506, ptr %t505, 1
  %t509 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eMutOnLocal(ptr %s13, ptr %s13, { i64, ptr } %t507)
  store %"compiler/msgs:Msg" %t509, ptr %l279
  br label %bb108
bb108:
  %t510 = load %"compiler/msgs:Msg", ptr %l279
  store %"compiler/msgs:Msg" %t510, ptr %l269
  br label %bb109
bb109:
  %t511 = load ptr, ptr %l265, !tbaa !29
  %t512 = load %"compiler/source:Span", ptr %l266
  %t513 = load %"compiler/msgs:Msg", ptr %l269
  %t514 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s13, ptr %t511, %"compiler/source:Span" %t512, %"compiler/msgs:Msg" %t513)
  store i64 %t514, ptr %l280
  br label %bb110
bb110:
  call void @__olang_scope_close(ptr %s13)
  br label %bb111
bb111:
  br label %bb112
bb112:
  br label %bb113
bb113:
  br label %bb114
bb114:
  %t515 = load ptr, ptr %l2, !tbaa !29
  %t517 = getelementptr %"compiler/ast:VarDecl", ptr %t515, i32 0, i32 5
  %t518 = load i1, ptr %t517, !tbaa !21
  br i1 %t518, label %bb115, label %bb116
bb115:
  store i32 6, ptr %l283
  br label %bb117
bb116:
  store i32 1, ptr %l283
  br label %bb117
bb117:
  %t522 = load i32, ptr %l283, !range !{i32 0, i32 7}
  store i32 %t522, ptr %l17
  store i64 0, ptr %l18, !tbaa !24
  %t523 = load ptr, ptr %l2, !tbaa !29
  %t525 = getelementptr %"compiler/ast:VarDecl", ptr %t523, i32 0, i32 0
  %t526 = load { i64, ptr }, ptr %t525, !tbaa !27
  %t528 = extractvalue { i64, ptr } %t526, 0
  store i64 %t528, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t530 = load i64, ptr %l19, !tbaa !24
  %t531 = load i64, ptr %l18, !tbaa !24
  %t534 = icmp sgt i64 %t530, %t531
  br i1 %t534, label %bb118, label %bb119
bb118:
  %t536 = load i64, ptr %l20, !tbaa !24
  %t538 = icmp sgt i64 %t536, 0
  br i1 %t538, label %bb120, label %bb121
bb119:
  store i64 0, ptr %l292, !tbaa !24
  br label %bb123
bb120:
  %t540 = load i64, ptr %l19, !tbaa !24
  %t541 = load i64, ptr %l18, !tbaa !24
  %t544 = sub i64 %t540, %t541
  %t545 = load i64, ptr %l20, !tbaa !24
  %t548 = add i64 %t544, %t545
  %t550 = sub i64 %t548, 1
  %t551 = load i64, ptr %l20, !tbaa !24
  %t554 = sdiv i64 %t550, %t551
  store i64 %t554, ptr %l295, !tbaa !24
  br label %bb122
bb121:
  store i64 0, ptr %l295, !tbaa !24
  br label %bb122
bb122:
  %t556 = load i64, ptr %l295, !tbaa !24
  store i64 %t556, ptr %l292, !tbaa !24
  br label %bb123
bb123:
  %t557 = load i64, ptr %l292, !tbaa !24
  store i64 %t557, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb124
bb124:
  store %olang.scope zeroinitializer, ptr %s15
  %t558 = load i64, ptr %l22, !tbaa !24
  %t559 = load i64, ptr %l21, !tbaa !24
  %t562 = icmp slt i64 %t558, %t559
  %t564 = xor i1 %t562, true
  br i1 %t564, label %bb125, label %bb126
bb125:
  call void @__olang_scope_close(ptr %s15)
  br label %bb487
bb126:
  br label %bb127
bb127:
  %t566 = load i64, ptr %l18, !tbaa !24
  %t567 = load i64, ptr %l22, !tbaa !24
  %t568 = load i64, ptr %l20, !tbaa !24
  %t571 = mul i64 %t567, %t568
  %t574 = add i64 %t566, %t571
  store i64 %t574, ptr %l23, !tbaa !24
  %t576 = load ptr, ptr %l2, !tbaa !29
  %t578 = getelementptr %"compiler/ast:VarDecl", ptr %t576, i32 0, i32 1
  %t579 = load { i64, ptr }, ptr %t578, !tbaa !27
  store { i64, ptr } %t579, ptr %l314, !tbaa !27
  %t580 = load i64, ptr %l23, !tbaa !24
  %t582 = getelementptr { i64, ptr }, ptr %l314, i32 0, i32 1
  %t583 = load ptr, ptr %t582, !tbaa !27
  %t584 = getelementptr %"compiler/source:Span", ptr %t583, i64 %t580
  %t585 = load %"compiler/source:Span", ptr %t584
  store %"compiler/source:Span" %t585, ptr %l24
  %t587 = load ptr, ptr %l2, !tbaa !29
  %t589 = getelementptr %"compiler/ast:VarDecl", ptr %t587, i32 0, i32 5
  %t590 = load i1, ptr %t589, !tbaa !21
  br i1 %t590, label %bb128, label %bb129
bb128:
  %t592 = load ptr, ptr %l0, !tbaa !29
  %t593 = load ptr, ptr %l2, !tbaa !29
  %t595 = getelementptr %"compiler/ast:VarDecl", ptr %t593, i32 0, i32 0
  %t596 = load { i64, ptr }, ptr %t595, !tbaa !27
  store { i64, ptr } %t596, ptr %l321, !tbaa !27
  %t597 = load i64, ptr %l23, !tbaa !24
  %t599 = getelementptr { i64, ptr }, ptr %l321, i32 0, i32 1
  %t600 = load ptr, ptr %t599, !tbaa !27
  %t601 = getelementptr i32, ptr %t600, i64 %t597
  %t602 = load i32, ptr %t601, !tbaa !33
  %t605 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %t592, i32 %t602)
  store i64 %t605, ptr %l324
  br label %bb130
bb129:
  br label %bb148
bb130:
  %t606 = load i64, ptr %l324, !tbaa !24
  store i64 %t606, ptr %l25, !tbaa !24
  %t607 = load i64, ptr %l25, !tbaa !24
  %t609 = icmp sge i64 %t607, 0
  br i1 %t609, label %bb131, label %bb132
bb131:
  %t611 = load ptr, ptr %l0, !tbaa !29
  %t613 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t611)
  store ptr %t613, ptr %l329
  br label %bb133
bb132:
  store i1 false, ptr %l327, !tbaa !21
  br label %bb135
bb133:
  %t614 = load ptr, ptr %l329, !tbaa !29
  %t616 = getelementptr %"compiler/typed:Body", ptr %t614, i32 0, i32 7
  %t617 = load i64, ptr %l25, !tbaa !24
  %t620 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t616, i64 %t617)
  store %"compiler/typed:Local" %t620, ptr %l333
  br label %bb134
bb134:
  %t621 = getelementptr %"compiler/typed:Local", ptr %l333, i32 0, i32 4
  %t622 = load i32, ptr %t621, !range !{i32 0, i32 7}
  %t624 = trunc i64 0 to i32
  %t625 = icmp eq i32 %t622, %t624
  store i1 %t625, ptr %l327, !tbaa !21
  br label %bb135
bb135:
  %t627 = load i1, ptr %l327, !tbaa !21
  br i1 %t627, label %bb136, label %bb137
bb136:
  store %olang.scope zeroinitializer, ptr %s17
  %t628 = load ptr, ptr %l0, !tbaa !29
  store ptr %t628, ptr %l336, !tbaa !29
  %t629 = load %"compiler/source:Span", ptr %l24
  store %"compiler/source:Span" %t629, ptr %l337
  %t630 = load ptr, ptr %l0, !tbaa !29
  %t631 = load ptr, ptr %l2, !tbaa !29
  %t633 = getelementptr %"compiler/ast:VarDecl", ptr %t631, i32 0, i32 0
  %t634 = load { i64, ptr }, ptr %t633, !tbaa !27
  store { i64, ptr } %t634, ptr %l340, !tbaa !27
  %t635 = load i64, ptr %l23, !tbaa !24
  %t637 = getelementptr { i64, ptr }, ptr %l340, i32 0, i32 1
  %t638 = load ptr, ptr %t637, !tbaa !27
  %t639 = getelementptr i32, ptr %t638, i64 %t635
  %t640 = load i32, ptr %t639, !tbaa !33
  %t643 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s17, ptr %t630, i32 %t640)
  store { i64, ptr } %t643, ptr %l343
  br label %bb138
bb137:
  br label %bb147
bb138:
  %t644 = load { i64, ptr }, ptr %l343, !tbaa !27
  %t645 = extractvalue { i64, ptr } %t644, 0
  %t646 = extractvalue { i64, ptr } %t644, 1
  %t647 = mul i64 %t645, 1
  %t648 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t647)
  call void @llvm.memcpy.p0.p0.i64(ptr %t648, ptr %t646, i64 %t647, i1 false)
  %t649 = insertvalue { i64, ptr } undef, i64 %t645, 0
  %t650 = insertvalue { i64, ptr } %t649, ptr %t648, 1
  %t652 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eFieldHasParamName(ptr %s17, ptr %s17, { i64, ptr } %t650)
  store %"compiler/msgs:Msg" %t652, ptr %l345
  br label %bb139
bb139:
  %t653 = load ptr, ptr %l336, !tbaa !29
  %t654 = load %"compiler/source:Span", ptr %l337
  %t655 = load %"compiler/msgs:Msg", ptr %l345
  %t656 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s17, ptr %t653, %"compiler/source:Span" %t654, %"compiler/msgs:Msg" %t655)
  store i64 %t656, ptr %l346
  br label %bb140
bb140:
  %t657 = load i64, ptr %l346, !tbaa !24
  %t658 = load ptr, ptr %l0, !tbaa !29
  %t660 = getelementptr %"compiler/check:Checker", ptr %t658, i32 0, i32 1
  %t661 = load ptr, ptr %t660, !tbaa !29
  %t663 = getelementptr %"compiler/generic:Program", ptr %t661, i32 0, i32 0
  %t664 = load ptr, ptr %t663, !tbaa !29
  %t666 = getelementptr %"compiler/load:Loader", ptr %t664, i32 0, i32 4
  %t667 = load ptr, ptr %t666, !tbaa !29
  store ptr %t667, ptr %l350, !tbaa !29
  store i64 %t657, ptr %l351, !tbaa !24
  %t669 = load ptr, ptr %l0, !tbaa !29
  store ptr %t669, ptr %l352, !tbaa !29
  %t670 = load ptr, ptr %l0, !tbaa !29
  %t672 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t670)
  store ptr %t672, ptr %l354
  br label %bb141
bb141:
  %t673 = load ptr, ptr %l354, !tbaa !29
  %t675 = getelementptr %"compiler/typed:Body", ptr %t673, i32 0, i32 7
  %t676 = load i64, ptr %l25, !tbaa !24
  %t679 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t675, i64 %t676)
  store %"compiler/typed:Local" %t679, ptr %l358
  br label %bb142
bb142:
  %t680 = getelementptr %"compiler/typed:Local", ptr %l358, i32 0, i32 1
  %t681 = load %"compiler/source:Span", ptr %t680
  %t682 = load ptr, ptr %l352, !tbaa !29
  %t684 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t682, %"compiler/source:Span" %t681)
  store { i64, [3 x i64] } %t684, ptr %l360
  br label %bb143
bb143:
  %t685 = load ptr, ptr %l0, !tbaa !29
  %t686 = load ptr, ptr %l2, !tbaa !29
  %t688 = getelementptr %"compiler/ast:VarDecl", ptr %t686, i32 0, i32 0
  %t689 = load { i64, ptr }, ptr %t688, !tbaa !27
  store { i64, ptr } %t689, ptr %l363, !tbaa !27
  %t690 = load i64, ptr %l23, !tbaa !24
  %t692 = getelementptr { i64, ptr }, ptr %l363, i32 0, i32 1
  %t693 = load ptr, ptr %t692, !tbaa !27
  %t694 = getelementptr i32, ptr %t693, i64 %t690
  %t695 = load i32, ptr %t694, !tbaa !33
  %t698 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s17, ptr %t685, i32 %t695)
  store { i64, ptr } %t698, ptr %l366
  br label %bb144
bb144:
  %t699 = load { i64, ptr }, ptr %l366, !tbaa !27
  %t700 = extractvalue { i64, ptr } %t699, 0
  %t701 = extractvalue { i64, ptr } %t699, 1
  %t702 = mul i64 %t700, 1
  %t703 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t702)
  call void @llvm.memcpy.p0.p0.i64(ptr %t703, ptr %t701, i64 %t702, i1 false)
  %t704 = insertvalue { i64, ptr } undef, i64 %t700, 0
  %t705 = insertvalue { i64, ptr } %t704, ptr %t703, 1
  %t707 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteDeclaredHere(ptr %s17, ptr %s17, { i64, ptr } %t705)
  store %"compiler/msgs:Msg" %t707, ptr %l368
  br label %bb145
bb145:
  %t708 = load ptr, ptr %l350, !tbaa !29
  %t709 = load i64, ptr %l351, !tbaa !24
  %t710 = load { i64, [3 x i64] }, ptr %l360
  %t711 = load %"compiler/msgs:Msg", ptr %l368
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s17, ptr %t708, i64 %t709, { i64, [3 x i64] } %t710, %"compiler/msgs:Msg" %t711)
  br label %bb146
bb146:
  call void @__olang_scope_close(ptr %s17)
  br label %bb147
bb147:
  br label %bb148
bb148:
  %t712 = load i32, ptr %l13, !tbaa !23
  store i32 %t712, ptr %l27, !tbaa !23
  store ptr null, ptr %l28, !tbaa !29
  %t714 = load %"compiler/source:Span", ptr %l24
  %t715 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t718 = call %"compiler/check:unsetCand" @compiler_2fcheck_3aunsetCand_2ector(ptr %s15, i64 -1, i64 -1, i64 -1, i1 false, i64 -1, %"compiler/source:Span" %t714, i32 %t715, i1 false)
  store %"compiler/check:unsetCand" %t718, ptr %l372
  br label %bb149
bb149:
  %t719 = load %"compiler/check:unsetCand", ptr %l372
  store %"compiler/check:unsetCand" %t719, ptr %l29
  %t720 = load ptr, ptr %l0, !tbaa !29
  %t722 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t720)
  store ptr %t722, ptr %l374
  br label %bb150
bb150:
  %t723 = load ptr, ptr %l374, !tbaa !29
  %t725 = getelementptr %"compiler/check:frame", ptr %t723, i32 0, i32 41
  %t726 = load ptr, ptr %l2, !tbaa !29
  %t728 = getelementptr %"compiler/ast:VarDecl", ptr %t726, i32 0, i32 0
  %t729 = load { i64, ptr }, ptr %t728, !tbaa !27
  store { i64, ptr } %t729, ptr %l378, !tbaa !27
  %t730 = load i64, ptr %l23, !tbaa !24
  %t732 = getelementptr { i64, ptr }, ptr %l378, i32 0, i32 1
  %t733 = load ptr, ptr %t732, !tbaa !27
  %t734 = getelementptr i32, ptr %t733, i64 %t730
  %t735 = load i32, ptr %t734, !tbaa !33
  %t738 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %t725, i32 %t735)
  store i1 %t738, ptr %l381
  br label %bb151
bb151:
  %t739 = load i1, ptr %l381, !tbaa !21
  %t740 = xor i1 %t739, true
  store i1 %t740, ptr %l30, !tbaa !21
  %t742 = load i32, ptr %l13, !tbaa !23
  store i32 %t742, ptr %l31, !tbaa !23
  %t744 = load ptr, ptr %l2, !tbaa !29
  %t746 = getelementptr %"compiler/ast:VarDecl", ptr %t744, i32 0, i32 5
  %t747 = load i1, ptr %t746, !tbaa !21
  br i1 %t747, label %bb152, label %bb153
bb152:
  store i1 true, ptr %l30, !tbaa !21
  %t749 = load ptr, ptr %l0, !tbaa !29
  store ptr %t749, ptr %l386, !tbaa !29
  %t750 = load ptr, ptr %l0, !tbaa !29
  %t752 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t750)
  store ptr %t752, ptr %l388
  br label %bb154
bb153:
  %t753 = load i1, ptr %l30, !tbaa !21
  br i1 %t753, label %bb165, label %bb166
bb154:
  %t755 = load ptr, ptr %l388, !tbaa !29
  %t757 = getelementptr %"compiler/typed:Body", ptr %t755, i32 0, i32 10
  %t759 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t757)
  store i64 %t759, ptr %l391
  br label %bb155
bb155:
  %t760 = load ptr, ptr %l386, !tbaa !29
  %t761 = load i64, ptr %l391, !tbaa !24
  %t762 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efieldTypeAt(ptr %v0, ptr %t760, i64 %t761)
  store i32 %t762, ptr %l392
  br label %bb156
bb156:
  %t763 = load i32, ptr %l392, !tbaa !23
  store i32 %t763, ptr %l32, !tbaa !23
  %t764 = load ptr, ptr %l0, !tbaa !29
  %t766 = getelementptr %"compiler/check:Checker", ptr %t764, i32 0, i32 1
  %t767 = load ptr, ptr %t766, !tbaa !29
  %t769 = getelementptr %"compiler/generic:Program", ptr %t767, i32 0, i32 2
  %t770 = load i32, ptr %l32, !tbaa !23
  %t773 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t769, i32 %t770)
  store i32 %t773, ptr %l397
  br label %bb157
bb157:
  %t774 = load i32, ptr %l397, !range !{i32 0, i32 33}
  %t776 = trunc i64 19 to i32
  %t777 = icmp eq i32 %t774, %t776
  br i1 %t777, label %bb158, label %bb159
bb158:
  %t779 = load ptr, ptr %l0, !tbaa !29
  %t781 = getelementptr %"compiler/check:Checker", ptr %t779, i32 0, i32 1
  %t782 = load ptr, ptr %t781, !tbaa !29
  %t784 = getelementptr %"compiler/generic:Program", ptr %t782, i32 0, i32 2
  %t785 = load i32, ptr %l32, !tbaa !23
  %t788 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t784, i32 %t785)
  store i32 %t788, ptr %l405
  br label %bb160
bb159:
  store i1 false, ptr %l400, !tbaa !21
  br label %bb161
bb160:
  %t789 = load i32, ptr %l405, !tbaa !23
  %t790 = icmp ne i32 %t789, 0
  store i1 %t790, ptr %l400, !tbaa !21
  br label %bb161
bb161:
  %t792 = load i1, ptr %l400, !tbaa !21
  br i1 %t792, label %bb162, label %bb163
bb162:
  %t793 = load i32, ptr %l32, !tbaa !23
  store i32 %t793, ptr %l31, !tbaa !23
  %t795 = load i32, ptr %l32, !tbaa !23
  store i32 %t795, ptr %l27, !tbaa !23
  br label %bb164
bb163:
  br label %bb164
bb164:
  br label %bb179
bb165:
  %t797 = load ptr, ptr %l2, !tbaa !29
  %t799 = getelementptr %"compiler/ast:VarDecl", ptr %t797, i32 0, i32 2
  %t800 = load ptr, ptr %t799, !tbaa !29
  %t802 = icmp eq ptr %t800, null
  %t804 = xor i1 %t802, true
  store i1 %t804, ptr %l410, !tbaa !21
  br label %bb167
bb166:
  store i1 false, ptr %l410, !tbaa !21
  br label %bb167
bb167:
  %t806 = load i1, ptr %l410, !tbaa !21
  br i1 %t806, label %bb168, label %bb169
bb168:
  %t807 = load ptr, ptr %l2, !tbaa !29
  %t809 = getelementptr %"compiler/ast:VarDecl", ptr %t807, i32 0, i32 4
  %t810 = load i1, ptr %t809, !tbaa !21
  %t812 = xor i1 %t810, true
  store i1 %t812, ptr %l415, !tbaa !21
  br label %bb170
bb169:
  store i1 false, ptr %l415, !tbaa !21
  br label %bb170
bb170:
  %t814 = load i1, ptr %l415, !tbaa !21
  br i1 %t814, label %bb171, label %bb172
bb171:
  %t815 = load i64, ptr %l23, !tbaa !24
  %t816 = load ptr, ptr %l2, !tbaa !29
  %t818 = getelementptr %"compiler/ast:VarDecl", ptr %t816, i32 0, i32 3
  %t819 = load { i64, ptr }, ptr %t818, !tbaa !27
  %t821 = extractvalue { i64, ptr } %t819, 0
  %t824 = icmp slt i64 %t815, %t821
  store i1 %t824, ptr %l419, !tbaa !21
  br label %bb173
bb172:
  store i1 false, ptr %l419, !tbaa !21
  br label %bb173
bb173:
  %t826 = load i1, ptr %l419, !tbaa !21
  br i1 %t826, label %bb174, label %bb175
bb174:
  %t827 = load ptr, ptr %l0, !tbaa !29
  %t829 = getelementptr %"compiler/check:Checker", ptr %t827, i32 0, i32 1
  %t830 = load ptr, ptr %t829, !tbaa !29
  store ptr %t830, ptr %l426, !tbaa !29
  %t831 = load ptr, ptr %l0, !tbaa !29
  %t833 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t831)
  store ptr %t833, ptr %l428
  br label %bb176
bb175:
  br label %bb178
bb176:
  %t834 = load ptr, ptr %l428, !tbaa !29
  %t836 = getelementptr %"compiler/check:frame", ptr %t834, i32 0, i32 4
  %t837 = load i32, ptr %l13, !tbaa !23
  %t838 = load ptr, ptr %l2, !tbaa !29
  %t840 = getelementptr %"compiler/ast:VarDecl", ptr %t838, i32 0, i32 3
  %t841 = load { i64, ptr }, ptr %t840, !tbaa !27
  store { i64, ptr } %t841, ptr %l433, !tbaa !27
  %t842 = load i64, ptr %l23, !tbaa !24
  %t844 = getelementptr { i64, ptr }, ptr %l433, i32 0, i32 1
  %t845 = load ptr, ptr %t844, !tbaa !27
  %t846 = getelementptr ptr, ptr %t845, i64 %t842
  %t847 = load ptr, ptr %t846, !tbaa !39
  %t849 = load ptr, ptr %l426, !tbaa !29
  %t853 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eStorageOf(ptr %v0, ptr %v0, ptr %v1, ptr %t849, ptr %t836, i32 %t837, ptr %t847)
  store i32 %t853, ptr %l437
  br label %bb177
bb177:
  %t854 = load i32, ptr %l437, !tbaa !23
  store i32 %t854, ptr %l31, !tbaa !23
  %t855 = load i32, ptr %l31, !tbaa !23
  store i32 %t855, ptr %l27, !tbaa !23
  br label %bb178
bb178:
  br label %bb179
bb179:
  %t857 = load i1, ptr %l30, !tbaa !21
  br i1 %t857, label %bb180, label %bb181
bb180:
  %t859 = load i64, ptr %l23, !tbaa !24
  %t860 = load ptr, ptr %l2, !tbaa !29
  %t862 = getelementptr %"compiler/ast:VarDecl", ptr %t860, i32 0, i32 3
  %t863 = load { i64, ptr }, ptr %t862, !tbaa !27
  %t865 = extractvalue { i64, ptr } %t863, 0
  %t868 = icmp slt i64 %t859, %t865
  store i1 %t868, ptr %l440, !tbaa !21
  br label %bb182
bb181:
  store i1 false, ptr %l440, !tbaa !21
  br label %bb182
bb182:
  %t870 = load i1, ptr %l440, !tbaa !21
  br i1 %t870, label %bb183, label %bb184
bb183:
  %t871 = load ptr, ptr %l2, !tbaa !29
  %t873 = getelementptr %"compiler/ast:VarDecl", ptr %t871, i32 0, i32 5
  %t874 = load i1, ptr %t873, !tbaa !21
  %t876 = xor i1 %t874, true
  store i1 %t876, ptr %l446, !tbaa !21
  br label %bb185
bb184:
  store i1 false, ptr %l446, !tbaa !21
  br label %bb185
bb185:
  %t878 = load i1, ptr %l446, !tbaa !21
  br i1 %t878, label %bb186, label %bb187
bb186:
  %t879 = load ptr, ptr %l2, !tbaa !29
  %t881 = getelementptr %"compiler/ast:VarDecl", ptr %t879, i32 0, i32 2
  %t882 = load ptr, ptr %t881, !tbaa !29
  %t884 = icmp eq ptr %t882, null
  %t886 = xor i1 %t884, true
  store i1 %t886, ptr %l450, !tbaa !21
  br label %bb188
bb187:
  store i1 false, ptr %l450, !tbaa !21
  br label %bb188
bb188:
  %t888 = load i1, ptr %l450, !tbaa !21
  br i1 %t888, label %bb189, label %bb190
bb189:
  %t889 = load ptr, ptr %l2, !tbaa !29
  %t891 = getelementptr %"compiler/ast:VarDecl", ptr %t889, i32 0, i32 4
  %t892 = load i1, ptr %t891, !tbaa !21
  %t894 = xor i1 %t892, true
  store i1 %t894, ptr %l455, !tbaa !21
  br label %bb191
bb190:
  store i1 false, ptr %l455, !tbaa !21
  br label %bb191
bb191:
  %t896 = load i1, ptr %l455, !tbaa !21
  br i1 %t896, label %bb192, label %bb193
bb192:
  %t897 = load ptr, ptr %l0, !tbaa !29
  %t899 = getelementptr %"compiler/check:Checker", ptr %t897, i32 0, i32 1
  %t900 = load ptr, ptr %t899, !tbaa !29
  %t902 = getelementptr %"compiler/generic:Program", ptr %t900, i32 0, i32 2
  %t903 = load i32, ptr %l31, !tbaa !23
  %t906 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t902, i32 %t903)
  store i32 %t906, ptr %l464
  br label %bb194
bb193:
  store i1 false, ptr %l459, !tbaa !21
  br label %bb195
bb194:
  %t907 = load i32, ptr %l464, !range !{i32 0, i32 33}
  %t909 = trunc i64 19 to i32
  %t910 = icmp eq i32 %t907, %t909
  store i1 %t910, ptr %l459, !tbaa !21
  br label %bb195
bb195:
  %t912 = load i1, ptr %l459, !tbaa !21
  br i1 %t912, label %bb196, label %bb197
bb196:
  %t913 = load ptr, ptr %l0, !tbaa !29
  store ptr %t913, ptr %l468, !tbaa !29
  %t914 = load ptr, ptr %l0, !tbaa !29
  %t916 = getelementptr %"compiler/check:Checker", ptr %t914, i32 0, i32 1
  %t917 = load ptr, ptr %t916, !tbaa !29
  %t919 = getelementptr %"compiler/generic:Program", ptr %t917, i32 0, i32 2
  %t920 = load i32, ptr %l31, !tbaa !23
  %t923 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t919, i32 %t920)
  store i32 %t923, ptr %l473
  br label %bb198
bb197:
  store i1 false, ptr %l467, !tbaa !21
  br label %bb200
bb198:
  %t924 = load ptr, ptr %l468, !tbaa !29
  %t925 = load i32, ptr %l473, !tbaa !23
  %t926 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunArrayValue(ptr %v0, ptr %t924, i32 %t925)
  store i1 %t926, ptr %l474
  br label %bb199
bb199:
  %t927 = load i1, ptr %l474, !tbaa !21
  store i1 %t927, ptr %l467, !tbaa !21
  br label %bb200
bb200:
  %t928 = load i1, ptr %l467, !tbaa !21
  br i1 %t928, label %bb201, label %bb202
bb201:
  %t929 = load ptr, ptr %l0, !tbaa !29
  %t930 = load ptr, ptr %l2, !tbaa !29
  %t932 = getelementptr %"compiler/ast:VarDecl", ptr %t930, i32 0, i32 3
  %t933 = load { i64, ptr }, ptr %t932, !tbaa !27
  store { i64, ptr } %t933, ptr %l477, !tbaa !27
  %t934 = load i64, ptr %l23, !tbaa !24
  %t936 = getelementptr { i64, ptr }, ptr %l477, i32 0, i32 1
  %t937 = load ptr, ptr %t936, !tbaa !27
  %t938 = getelementptr ptr, ptr %t937, i64 %t934
  %t939 = load ptr, ptr %t938, !tbaa !39
  %t941 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t945 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t929, ptr %t939, i32 %t941)
  store ptr %t945, ptr %l482
  br label %bb203
bb202:
  %t946 = load i64, ptr %l23, !tbaa !24
  %t947 = load ptr, ptr %l2, !tbaa !29
  %t949 = getelementptr %"compiler/ast:VarDecl", ptr %t947, i32 0, i32 3
  %t950 = load { i64, ptr }, ptr %t949, !tbaa !27
  %t952 = extractvalue { i64, ptr } %t950, 0
  %t955 = icmp slt i64 %t946, %t952
  br i1 %t955, label %bb220, label %bb221
bb203:
  %t957 = load ptr, ptr %l482, !tbaa !29
  store ptr %t957, ptr %l28, !tbaa !29
  %t959 = load ptr, ptr %l0, !tbaa !29
  %t961 = getelementptr %"compiler/check:Checker", ptr %t959, i32 0, i32 1
  %t962 = load ptr, ptr %t961, !tbaa !29
  store ptr %t962, ptr %l485, !tbaa !29
  %t963 = load ptr, ptr %l28, !tbaa !29
  %t965 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t963)
  store i32 %t965, ptr %l487
  br label %bb204
bb204:
  %t966 = load i32, ptr %l31, !tbaa !23
  %t967 = load ptr, ptr %l485, !tbaa !29
  %t968 = load i32, ptr %l487, !tbaa !23
  %t970 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLengthsOnly(ptr %v0, ptr %t967, i32 %t968, i32 %t966)
  store i1 %t970, ptr %l489
  br label %bb205
bb205:
  %t971 = load i1, ptr %l489, !tbaa !21
  br i1 %t971, label %bb206, label %bb207
bb206:
  %t972 = load ptr, ptr %l0, !tbaa !29
  %t974 = getelementptr %"compiler/check:Checker", ptr %t972, i32 0, i32 1
  %t975 = load ptr, ptr %t974, !tbaa !29
  %t977 = getelementptr %"compiler/generic:Program", ptr %t975, i32 0, i32 2
  store ptr %t977, ptr %l493, !tbaa !29
  %t978 = load ptr, ptr %l28, !tbaa !29
  %t980 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t978)
  store i32 %t980, ptr %l495
  br label %bb208
bb207:
  store i1 false, ptr %l490, !tbaa !21
  br label %bb210
bb208:
  %t981 = load ptr, ptr %l493, !tbaa !29
  %t982 = load i32, ptr %l495, !tbaa !23
  %t983 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t981, i32 %t982)
  store i32 %t983, ptr %l496
  br label %bb209
bb209:
  %t984 = load i32, ptr %l496, !range !{i32 0, i32 33}
  %t986 = trunc i64 19 to i32
  %t987 = icmp eq i32 %t984, %t986
  store i1 %t987, ptr %l490, !tbaa !21
  br label %bb210
bb210:
  %t989 = load i1, ptr %l490, !tbaa !21
  br i1 %t989, label %bb211, label %bb212
bb211:
  %t990 = load ptr, ptr %l28, !tbaa !29
  %t992 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t990)
  store i32 %t992, ptr %l500
  br label %bb213
bb212:
  %t993 = load ptr, ptr %l0, !tbaa !29
  store ptr %t993, ptr %l501, !tbaa !29
  %t994 = load ptr, ptr %l28, !tbaa !29
  %t996 = icmp eq ptr %t994, null
  br i1 %t996, label %bb214, label %bb215
bb213:
  %t998 = load i32, ptr %l500, !tbaa !23
  store i32 %t998, ptr %l27, !tbaa !23
  br label %bb219
bb214:
  call void @__olang_check_failed(ptr @olang_loc_f3c73b72e55a8b8e_5460cc7526c67482)
  unreachable
bb215:
  br label %bb216
bb216:
  %t999 = load ptr, ptr %l28, !tbaa !29
  store ptr %t999, ptr %l504, !tbaa !29
  %t1000 = load i32, ptr %l31, !tbaa !23
  store i32 %t1000, ptr %l505, !tbaa !23
  %t1001 = load ptr, ptr %l2, !tbaa !29
  %t1003 = getelementptr %"compiler/ast:VarDecl", ptr %t1001, i32 0, i32 3
  %t1004 = load { i64, ptr }, ptr %t1003, !tbaa !27
  store { i64, ptr } %t1004, ptr %l507, !tbaa !27
  %t1005 = load i64, ptr %l23, !tbaa !24
  %t1007 = getelementptr { i64, ptr }, ptr %l507, i32 0, i32 1
  %t1008 = load ptr, ptr %t1007, !tbaa !27
  %t1009 = getelementptr ptr, ptr %t1008, i64 %t1005
  %t1010 = load ptr, ptr %t1009, !tbaa !39
  %t1012 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t1010)
  store %"compiler/source:Span" %t1012, ptr %l510
  br label %bb217
bb217:
  %t1013 = load ptr, ptr %l501, !tbaa !29
  %t1014 = load ptr, ptr %l504, !tbaa !29
  %t1015 = load i32, ptr %l505, !tbaa !23
  %t1016 = load %"compiler/source:Span", ptr %l510
  %t1017 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t1013, ptr %t1014, i32 %t1015, %"compiler/source:Span" %t1016)
  store ptr %t1017, ptr %l511
  br label %bb218
bb218:
  %t1018 = load ptr, ptr %l511, !tbaa !29
  store ptr %t1018, ptr %l28, !tbaa !29
  br label %bb219
bb219:
  br label %bb303
bb220:
  %t1020 = load ptr, ptr %l0, !tbaa !29
  %t1022 = getelementptr %"compiler/check:Checker", ptr %t1020, i32 0, i32 11
  %t1023 = load { i64, [3 x i64] }, ptr %t1022
  store { i64, [3 x i64] } %t1023, ptr %l33
  %t1025 = load ptr, ptr %l2, !tbaa !29
  %t1027 = getelementptr %"compiler/ast:VarDecl", ptr %t1025, i32 0, i32 2
  %t1028 = load ptr, ptr %t1027, !tbaa !29
  %t1030 = icmp eq ptr %t1028, null
  %t1032 = xor i1 %t1030, true
  br i1 %t1032, label %bb222, label %bb223
bb221:
  store %olang.scope zeroinitializer, ptr %s32
  %t1034 = load ptr, ptr %l0, !tbaa !29
  %t1036 = getelementptr %"compiler/check:Checker", ptr %t1034, i32 0, i32 11
  %t1037 = load { i64, [3 x i64] }, ptr %t1036
  store { i64, [3 x i64] } %t1037, ptr %l36
  %t1039 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1039, ptr %l641, !tbaa !29
  %t1040 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1040, ptr %l642, !tbaa !29
  %t1041 = load ptr, ptr %l2, !tbaa !29
  %t1043 = getelementptr %"compiler/ast:VarDecl", ptr %t1041, i32 0, i32 2
  %t1044 = load ptr, ptr %t1043, !tbaa !29
  %t1046 = icmp eq ptr %t1044, null
  br i1 %t1046, label %bb281, label %bb282
bb222:
  %t1048 = load ptr, ptr %l2, !tbaa !29
  %t1050 = getelementptr %"compiler/ast:VarDecl", ptr %t1048, i32 0, i32 4
  %t1051 = load i1, ptr %t1050, !tbaa !21
  %t1053 = xor i1 %t1051, true
  store i1 %t1053, ptr %l524, !tbaa !21
  br label %bb224
bb223:
  store i1 false, ptr %l524, !tbaa !21
  br label %bb224
bb224:
  %t1055 = load i1, ptr %l524, !tbaa !21
  br i1 %t1055, label %bb225, label %bb226
bb225:
  %t1056 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1056, ptr %l528, !tbaa !29
  %t1057 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1057, ptr %l529, !tbaa !29
  %t1058 = load ptr, ptr %l2, !tbaa !29
  %t1060 = getelementptr %"compiler/ast:VarDecl", ptr %t1058, i32 0, i32 2
  %t1061 = load ptr, ptr %t1060, !tbaa !29
  %t1063 = icmp eq ptr %t1061, null
  br i1 %t1063, label %bb227, label %bb228
bb226:
  br label %bb231
bb227:
  call void @__olang_check_failed(ptr @olang_loc_de90e7498c4216b3_b17be322d1a772cf)
  unreachable
bb228:
  br label %bb229
bb229:
  %t1065 = load ptr, ptr %l2, !tbaa !29
  %t1067 = getelementptr %"compiler/ast:VarDecl", ptr %t1065, i32 0, i32 2
  %t1068 = load ptr, ptr %t1067, !tbaa !29
  %t1069 = load ptr, ptr %l529, !tbaa !29
  %t1071 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeWrittenAt(ptr %v0, ptr %v1, ptr %t1069, ptr %t1068)
  store { i64, [3 x i64] } %t1071, ptr %l535
  br label %bb230
bb230:
  %t1072 = load { i64, [3 x i64] }, ptr %l535
  %t1073 = load ptr, ptr %l528, !tbaa !29
  %t1074 = getelementptr %"compiler/check:Checker", ptr %t1073, i32 0, i32 11
  store { i64, [3 x i64] } %t1072, ptr %t1074
  br label %bb231
bb231:
  %t1075 = load ptr, ptr %l2, !tbaa !29
  %t1077 = getelementptr %"compiler/ast:VarDecl", ptr %t1075, i32 0, i32 5
  %t1078 = load i1, ptr %t1077, !tbaa !21
  %t1080 = xor i1 %t1078, true
  br i1 %t1080, label %bb232, label %bb233
bb232:
  %t1082 = load ptr, ptr %l2, !tbaa !29
  %t1084 = getelementptr %"compiler/ast:VarDecl", ptr %t1082, i32 0, i32 0
  %t1085 = load { i64, ptr }, ptr %t1084, !tbaa !27
  %t1087 = extractvalue { i64, ptr } %t1085, 0
  %t1089 = icmp eq i64 %t1087, 1
  store i1 %t1089, ptr %l539, !tbaa !21
  br label %bb234
bb233:
  store i1 false, ptr %l539, !tbaa !21
  br label %bb234
bb234:
  %t1091 = load i1, ptr %l539, !tbaa !21
  br i1 %t1091, label %bb235, label %bb236
bb235:
  %t1092 = load ptr, ptr %l0, !tbaa !29
  %t1093 = load ptr, ptr %l2, !tbaa !29
  %t1095 = getelementptr %"compiler/ast:VarDecl", ptr %t1093, i32 0, i32 0
  %t1096 = load { i64, ptr }, ptr %t1095, !tbaa !27
  store { i64, ptr } %t1096, ptr %l547, !tbaa !27
  %t1097 = load i64, ptr %l23, !tbaa !24
  %t1099 = getelementptr { i64, ptr }, ptr %l547, i32 0, i32 1
  %t1100 = load ptr, ptr %t1099, !tbaa !27
  %t1101 = getelementptr i32, ptr %t1100, i64 %t1097
  %t1102 = load i32, ptr %t1101, !tbaa !33
  %t1103 = load ptr, ptr %l2, !tbaa !29
  %t1105 = getelementptr %"compiler/ast:VarDecl", ptr %t1103, i32 0, i32 3
  %t1106 = load { i64, ptr }, ptr %t1105, !tbaa !27
  store { i64, ptr } %t1106, ptr %l551, !tbaa !27
  %t1107 = load i64, ptr %l23, !tbaa !24
  %t1109 = getelementptr { i64, ptr }, ptr %l551, i32 0, i32 1
  %t1110 = load ptr, ptr %t1109, !tbaa !27
  %t1111 = getelementptr ptr, ptr %t1110, i64 %t1107
  %t1112 = load ptr, ptr %t1111, !tbaa !39
  %t1116 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efilledNext(ptr %v0, ptr %v1, ptr %t1092, i32 %t1102, ptr %t1112)
  store i1 %t1116, ptr %l554
  br label %bb237
bb236:
  store i1 false, ptr %l544, !tbaa !21
  br label %bb238
bb237:
  %t1117 = load i1, ptr %l554, !tbaa !21
  store i1 %t1117, ptr %l544, !tbaa !21
  br label %bb238
bb238:
  %t1118 = load i1, ptr %l544, !tbaa !21
  %t1119 = load ptr, ptr %l0, !tbaa !29
  %t1123 = getelementptr %"compiler/check:Checker", ptr %t1119, i32 0, i32 99
  store i1 %t1118, ptr %t1123, !tbaa !21
  %t1124 = load ptr, ptr %l0, !tbaa !29
  %t1125 = load ptr, ptr %l2, !tbaa !29
  %t1127 = getelementptr %"compiler/ast:VarDecl", ptr %t1125, i32 0, i32 3
  %t1128 = load { i64, ptr }, ptr %t1127, !tbaa !27
  store { i64, ptr } %t1128, ptr %l559, !tbaa !27
  %t1129 = load i64, ptr %l23, !tbaa !24
  %t1131 = getelementptr { i64, ptr }, ptr %l559, i32 0, i32 1
  %t1132 = load ptr, ptr %t1131, !tbaa !27
  %t1133 = getelementptr ptr, ptr %t1132, i64 %t1129
  %t1134 = load ptr, ptr %t1133, !tbaa !39
  %t1135 = load i32, ptr %l31, !tbaa !23
  %t1139 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %t1124, ptr %t1134, i32 %t1135)
  store ptr %t1139, ptr %l563
  br label %bb239
bb239:
  %t1140 = load ptr, ptr %l563, !tbaa !29
  store ptr %t1140, ptr %l28, !tbaa !29
  %t1142 = load ptr, ptr %l0, !tbaa !29
  %t1144 = getelementptr %"compiler/check:Checker", ptr %t1142, i32 0, i32 99
  store i1 false, ptr %t1144, !tbaa !21
  %t1145 = load ptr, ptr %l0, !tbaa !29
  %t1146 = load { i64, [3 x i64] }, ptr %l33
  %t1149 = getelementptr %"compiler/check:Checker", ptr %t1145, i32 0, i32 11
  store { i64, [3 x i64] } %t1146, ptr %t1149
  %t1150 = load ptr, ptr %l2, !tbaa !29
  %t1152 = getelementptr %"compiler/ast:VarDecl", ptr %t1150, i32 0, i32 2
  %t1153 = load ptr, ptr %t1152, !tbaa !29
  %t1155 = icmp eq ptr %t1153, null
  br i1 %t1155, label %bb240, label %bb241
bb240:
  store i1 true, ptr %l571, !tbaa !21
  br label %bb242
bb241:
  %t1157 = load ptr, ptr %l2, !tbaa !29
  %t1159 = getelementptr %"compiler/ast:VarDecl", ptr %t1157, i32 0, i32 4
  %t1160 = load i1, ptr %t1159, !tbaa !21
  store i1 %t1160, ptr %l571, !tbaa !21
  br label %bb242
bb242:
  %t1162 = load i1, ptr %l571, !tbaa !21
  br i1 %t1162, label %bb243, label %bb244
bb243:
  %t1163 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1163, ptr %l574, !tbaa !29
  %t1164 = load ptr, ptr %l2, !tbaa !29
  %t1166 = getelementptr %"compiler/ast:VarDecl", ptr %t1164, i32 0, i32 3
  %t1167 = load { i64, ptr }, ptr %t1166, !tbaa !27
  store { i64, ptr } %t1167, ptr %l576, !tbaa !27
  %t1168 = load i64, ptr %l23, !tbaa !24
  %t1170 = getelementptr { i64, ptr }, ptr %l576, i32 0, i32 1
  %t1171 = load ptr, ptr %t1170, !tbaa !27
  %t1172 = getelementptr ptr, ptr %t1171, i64 %t1168
  %t1173 = load ptr, ptr %t1172, !tbaa !39
  store ptr %t1173, ptr %l578, !tbaa !29
  %t1174 = load ptr, ptr %l28, !tbaa !29
  %t1176 = icmp eq ptr %t1174, null
  br i1 %t1176, label %bb245, label %bb246
bb244:
  br label %bb280
bb245:
  call void @__olang_check_failed(ptr @olang_loc_36f1ca435b2ee6e4_790f65bce77245f0)
  unreachable
bb246:
  br label %bb247
bb247:
  %t1178 = load ptr, ptr %l28, !tbaa !29
  %t1179 = load i1, ptr %l30, !tbaa !21
  %t1180 = load ptr, ptr %l574, !tbaa !29
  %t1181 = load ptr, ptr %l578, !tbaa !29
  %t1184 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einferred(ptr %v0, ptr %v1, ptr %v0, ptr %t1180, ptr %t1181, ptr %t1178, i1 %t1179)
  store i32 %t1184, ptr %l583
  br label %bb248
bb248:
  %t1185 = load i32, ptr %l583, !tbaa !23
  store i32 %t1185, ptr %l27, !tbaa !23
  %t1186 = load ptr, ptr %l2, !tbaa !29
  %t1188 = getelementptr %"compiler/ast:VarDecl", ptr %t1186, i32 0, i32 5
  %t1189 = load i1, ptr %t1188, !tbaa !21
  br i1 %t1189, label %bb249, label %bb250
bb249:
  %t1191 = load ptr, ptr %l2, !tbaa !29
  %t1193 = getelementptr %"compiler/ast:VarDecl", ptr %t1191, i32 0, i32 2
  %t1194 = load ptr, ptr %t1193, !tbaa !29
  %t1196 = icmp eq ptr %t1194, null
  %t1198 = xor i1 %t1196, true
  store i1 %t1198, ptr %l586, !tbaa !21
  br label %bb251
bb250:
  store i1 false, ptr %l586, !tbaa !21
  br label %bb251
bb251:
  %t1200 = load i1, ptr %l586, !tbaa !21
  br i1 %t1200, label %bb252, label %bb253
bb252:
  %t1201 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1201, ptr %l591, !tbaa !29
  %t1202 = load ptr, ptr %l2, !tbaa !29
  %t1204 = getelementptr %"compiler/ast:VarDecl", ptr %t1202, i32 0, i32 2
  %t1205 = load ptr, ptr %t1204, !tbaa !29
  %t1207 = icmp eq ptr %t1205, null
  br i1 %t1207, label %bb254, label %bb255
bb253:
  br label %bb264
bb254:
  call void @__olang_check_failed(ptr @olang_loc_f2aff2ea660e9d99_96029929a029dd45)
  unreachable
bb255:
  br label %bb256
bb256:
  %t1209 = load ptr, ptr %l2, !tbaa !29
  %t1211 = getelementptr %"compiler/ast:VarDecl", ptr %t1209, i32 0, i32 2
  %t1212 = load ptr, ptr %t1211, !tbaa !29
  %t1213 = load i32, ptr %l27, !tbaa !23
  %t1214 = load ptr, ptr %l591, !tbaa !29
  %t1217 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emutBefore(ptr %v0, ptr %v1, ptr %t1214, ptr %t1212, i32 %t1213)
  store %"compiler/source:Span" %t1217, ptr %l598
  br label %bb257
bb257:
  %t1218 = load %"compiler/source:Span", ptr %l598
  store %"compiler/source:Span" %t1218, ptr %l35
  %t1219 = getelementptr %"compiler/source:Span", ptr %l35, i32 0, i32 0
  %t1220 = load i32, ptr %t1219, !tbaa !23
  %t1222 = icmp sge i32 %t1220, 0
  br i1 %t1222, label %bb258, label %bb259
bb258:
  store %olang.scope zeroinitializer, ptr %s30
  %t1224 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1224, ptr %l601, !tbaa !29
  %t1225 = load %"compiler/source:Span", ptr %l35
  store %"compiler/source:Span" %t1225, ptr %l602
  %t1226 = load ptr, ptr %l0, !tbaa !29
  %t1227 = load i32, ptr %l27, !tbaa !23
  %t1230 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s30, ptr %t1226, i32 %t1227)
  store { i64, ptr } %t1230, ptr %l605
  br label %bb260
bb259:
  br label %bb263
bb260:
  %t1231 = load { i64, ptr }, ptr %l605, !tbaa !27
  %t1232 = extractvalue { i64, ptr } %t1231, 0
  %t1233 = extractvalue { i64, ptr } %t1231, 1
  %t1234 = mul i64 %t1232, 1
  %t1235 = call ptr @__olang_scope_alloc(ptr %s30, i64 %t1234)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1235, ptr %t1233, i64 %t1234, i1 false)
  %t1236 = insertvalue { i64, ptr } undef, i64 %t1232, 0
  %t1237 = insertvalue { i64, ptr } %t1236, ptr %t1235, 1
  %t1239 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eMutOnValueField(ptr %s30, ptr %s30, { i64, ptr } %t1237)
  store %"compiler/msgs:Msg" %t1239, ptr %l607
  br label %bb261
bb261:
  %t1240 = load ptr, ptr %l601, !tbaa !29
  %t1241 = load %"compiler/source:Span", ptr %l602
  %t1242 = load %"compiler/msgs:Msg", ptr %l607
  %t1243 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s30, ptr %t1240, %"compiler/source:Span" %t1241, %"compiler/msgs:Msg" %t1242)
  store i64 %t1243, ptr %l608
  br label %bb262
bb262:
  call void @__olang_scope_close(ptr %s30)
  br label %bb263
bb263:
  br label %bb264
bb264:
  %t1244 = load ptr, ptr %l0, !tbaa !29
  %t1246 = getelementptr %"compiler/check:Checker", ptr %t1244, i32 0, i32 1
  %t1247 = load ptr, ptr %t1246, !tbaa !29
  %t1249 = getelementptr %"compiler/generic:Program", ptr %t1247, i32 0, i32 2
  store ptr %t1249, ptr %l611, !tbaa !29
  %t1250 = load ptr, ptr %l0, !tbaa !29
  %t1251 = load i32, ptr %l27, !tbaa !23
  %t1254 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t1250, i32 %t1251)
  store i32 %t1254, ptr %l614
  br label %bb265
bb265:
  %t1255 = load ptr, ptr %l611, !tbaa !29
  %t1256 = load i32, ptr %l614, !tbaa !23
  %t1257 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1255, i32 %t1256)
  store i32 %t1257, ptr %l615
  br label %bb266
bb266:
  %t1258 = load i32, ptr %l615, !range !{i32 0, i32 33}
  %t1260 = trunc i64 19 to i32
  %t1261 = icmp eq i32 %t1258, %t1260
  br i1 %t1261, label %bb267, label %bb268
bb267:
  %t1263 = load ptr, ptr %l0, !tbaa !29
  %t1265 = getelementptr %"compiler/check:Checker", ptr %t1263, i32 0, i32 1
  %t1266 = load ptr, ptr %t1265, !tbaa !29
  %t1268 = getelementptr %"compiler/generic:Program", ptr %t1266, i32 0, i32 2
  store ptr %t1268, ptr %l621, !tbaa !29
  %t1269 = load i32, ptr %l27, !tbaa !23
  store i32 %t1269, ptr %l622, !tbaa !23
  %t1270 = load ptr, ptr %l28, !tbaa !29
  %t1272 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t1270)
  store i32 %t1272, ptr %l624
  br label %bb269
bb268:
  store i1 false, ptr %l618, !tbaa !21
  br label %bb271
bb269:
  %t1273 = load ptr, ptr %l621, !tbaa !29
  %t1274 = load i32, ptr %l622, !tbaa !23
  %t1275 = load i32, ptr %l624, !tbaa !23
  %t1276 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t1273, i32 %t1274, i32 %t1275)
  store i1 %t1276, ptr %l625
  br label %bb270
bb270:
  %t1277 = load i1, ptr %l625, !tbaa !21
  %t1278 = xor i1 %t1277, true
  store i1 %t1278, ptr %l618, !tbaa !21
  br label %bb271
bb271:
  %t1280 = load i1, ptr %l618, !tbaa !21
  br i1 %t1280, label %bb272, label %bb273
bb272:
  %t1281 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1281, ptr %l627, !tbaa !29
  %t1282 = load ptr, ptr %l28, !tbaa !29
  %t1284 = icmp eq ptr %t1282, null
  br i1 %t1284, label %bb274, label %bb275
bb273:
  br label %bb279
bb274:
  call void @__olang_check_failed(ptr @olang_loc_91617ece661d0672_429c03ea7d9d989e)
  unreachable
bb275:
  br label %bb276
bb276:
  %t1286 = load ptr, ptr %l28, !tbaa !29
  store ptr %t1286, ptr %l630, !tbaa !29
  %t1287 = load i32, ptr %l27, !tbaa !23
  store i32 %t1287, ptr %l631, !tbaa !23
  %t1288 = load ptr, ptr %l2, !tbaa !29
  %t1290 = getelementptr %"compiler/ast:VarDecl", ptr %t1288, i32 0, i32 3
  %t1291 = load { i64, ptr }, ptr %t1290, !tbaa !27
  store { i64, ptr } %t1291, ptr %l633, !tbaa !27
  %t1292 = load i64, ptr %l23, !tbaa !24
  %t1294 = getelementptr { i64, ptr }, ptr %l633, i32 0, i32 1
  %t1295 = load ptr, ptr %t1294, !tbaa !27
  %t1296 = getelementptr ptr, ptr %t1295, i64 %t1292
  %t1297 = load ptr, ptr %t1296, !tbaa !39
  %t1299 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t1297)
  store %"compiler/source:Span" %t1299, ptr %l636
  br label %bb277
bb277:
  %t1300 = load ptr, ptr %l627, !tbaa !29
  %t1301 = load ptr, ptr %l630, !tbaa !29
  %t1302 = load i32, ptr %l631, !tbaa !23
  %t1303 = load %"compiler/source:Span", ptr %l636
  %t1304 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t1300, ptr %t1301, i32 %t1302, %"compiler/source:Span" %t1303)
  store ptr %t1304, ptr %l637
  br label %bb278
bb278:
  %t1305 = load ptr, ptr %l637, !tbaa !29
  store ptr %t1305, ptr %l28, !tbaa !29
  br label %bb279
bb279:
  br label %bb280
bb280:
  br label %bb302
bb281:
  call void @__olang_check_failed(ptr @olang_loc_60b97769ab73fcb7_dac12c977cbf3c9b)
  unreachable
bb282:
  br label %bb283
bb283:
  %t1307 = load ptr, ptr %l2, !tbaa !29
  %t1309 = getelementptr %"compiler/ast:VarDecl", ptr %t1307, i32 0, i32 2
  %t1310 = load ptr, ptr %t1309, !tbaa !29
  %t1311 = load ptr, ptr %l642, !tbaa !29
  %t1313 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeWrittenAt(ptr %v0, ptr %v1, ptr %t1311, ptr %t1310)
  store { i64, [3 x i64] } %t1313, ptr %l648
  br label %bb284
bb284:
  %t1314 = load { i64, [3 x i64] }, ptr %l648
  %t1315 = load ptr, ptr %l641, !tbaa !29
  %t1316 = getelementptr %"compiler/check:Checker", ptr %t1315, i32 0, i32 11
  store { i64, [3 x i64] } %t1314, ptr %t1316
  %t1317 = load ptr, ptr %l0, !tbaa !29
  %t1319 = getelementptr %"compiler/check:Checker", ptr %t1317, i32 0, i32 1
  %t1320 = load ptr, ptr %t1319, !tbaa !29
  %t1322 = getelementptr %"compiler/generic:Program", ptr %t1320, i32 0, i32 0
  %t1323 = load ptr, ptr %t1322, !tbaa !29
  %t1325 = getelementptr %"compiler/load:Loader", ptr %t1323, i32 0, i32 4
  %t1326 = load ptr, ptr %t1325, !tbaa !29
  store ptr %t1326, ptr %l37, !tbaa !29
  %t1328 = load ptr, ptr %l37, !tbaa !29
  %t1330 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHold(ptr %v0, ptr %t1328)
  store i64 %t1330, ptr %l654
  br label %bb285
bb285:
  %t1331 = load i64, ptr %l654, !tbaa !24
  store i64 %t1331, ptr %l38, !tbaa !24
  %t1332 = load ptr, ptr %l37, !tbaa !29
  %t1334 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t1332)
  store i64 %t1334, ptr %l656
  br label %bb286
bb286:
  %t1335 = load i64, ptr %l656, !tbaa !24
  store i64 %t1335, ptr %l39, !tbaa !24
  %t1336 = load ptr, ptr %l0, !tbaa !29
  %t1337 = load %"compiler/source:Span", ptr %l24
  %t1338 = load i32, ptr %l27, !tbaa !23
  %t1342 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezero(ptr %v0, ptr %t1336, %"compiler/source:Span" %t1337, i32 %t1338)
  store ptr %t1342, ptr %l660
  br label %bb287
bb287:
  %t1343 = load ptr, ptr %l660, !tbaa !29
  store ptr %t1343, ptr %l28, !tbaa !29
  %t1345 = load ptr, ptr %l37, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %t1345)
  br label %bb288
bb288:
  %t1347 = load ptr, ptr %l37, !tbaa !29
  %t1349 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t1347)
  store i64 %t1349, ptr %l664
  br label %bb289
bb289:
  %t1350 = load i64, ptr %l39, !tbaa !24
  %t1351 = load i64, ptr %l664, !tbaa !24
  %t1353 = icmp sgt i64 %t1351, %t1350
  store i1 %t1353, ptr %l40, !tbaa !21
  %t1355 = load i1, ptr %l40, !tbaa !21
  br i1 %t1355, label %bb290, label %bb291
bb290:
  %t1357 = load ptr, ptr %l0, !tbaa !29
  %t1358 = load %"compiler/source:Span", ptr %l24
  %t1359 = load i32, ptr %l27, !tbaa !23
  %t1363 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t1357, %"compiler/source:Span" %t1358, i32 %t1359, i64 0)
  store ptr %t1363, ptr %l671
  br label %bb292
bb291:
  br label %bb293
bb292:
  %t1364 = load ptr, ptr %l671, !tbaa !29
  store ptr %t1364, ptr %l28, !tbaa !29
  br label %bb293
bb293:
  %t1366 = load ptr, ptr %l0, !tbaa !29
  %t1367 = load { i64, [3 x i64] }, ptr %l36
  %t1370 = getelementptr %"compiler/check:Checker", ptr %t1366, i32 0, i32 11
  store { i64, [3 x i64] } %t1367, ptr %t1370
  %t1371 = load ptr, ptr %l0, !tbaa !29
  %t1373 = getelementptr %"compiler/check:Checker", ptr %t1371, i32 0, i32 85
  %t1375 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aValueAsk_3e_2eLen_3ccompiler_2fcheck_3aValueAsk_3e(ptr %v0, ptr %t1373)
  store i64 %t1375, ptr %l677
  br label %bb294
bb294:
  %t1376 = load i64, ptr %l677, !tbaa !24
  store i64 %t1376, ptr %l41, !tbaa !24
  %t1377 = load ptr, ptr %l0, !tbaa !29
  %t1378 = load %"compiler/source:Span", ptr %l24
  %t1379 = load i32, ptr %l27, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2easkValue(ptr %v0, ptr %v0, ptr %t1377, i32 1, %"compiler/source:Span" %t1378, i32 %t1379, ptr null)
  br label %bb295
bb295:
  %t1384 = load ptr, ptr %l0, !tbaa !29
  %t1386 = getelementptr %"compiler/check:Checker", ptr %t1384, i32 0, i32 85
  %t1388 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aValueAsk_3e_2eLen_3ccompiler_2fcheck_3aValueAsk_3e(ptr %v0, ptr %t1386)
  store i64 %t1388, ptr %l684
  br label %bb296
bb296:
  %t1389 = load i64, ptr %l41, !tbaa !24
  %t1390 = load i64, ptr %l684, !tbaa !24
  %t1392 = icmp eq i64 %t1390, %t1389
  br i1 %t1392, label %bb297, label %bb298
bb297:
  store i64 -1, ptr %l41, !tbaa !24
  br label %bb299
bb298:
  br label %bb299
bb299:
  %t1394 = load ptr, ptr %l0, !tbaa !29
  %t1396 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1394)
  store ptr %t1396, ptr %l688
  br label %bb300
bb300:
  %t1397 = load ptr, ptr %l688, !tbaa !29
  %t1399 = getelementptr %"compiler/check:frame", ptr %t1397, i32 0, i32 0
  %t1400 = load i64, ptr %t1399, !tbaa !24
  %t1401 = load i64, ptr %l38, !tbaa !24
  %t1402 = load i1, ptr %l40, !tbaa !21
  %t1403 = load i64, ptr %l41, !tbaa !24
  %t1404 = load %"compiler/source:Span", ptr %l24
  %t1405 = load i32, ptr %l27, !tbaa !23
  %t1406 = load ptr, ptr %l2, !tbaa !29
  %t1408 = getelementptr %"compiler/ast:VarDecl", ptr %t1406, i32 0, i32 5
  %t1409 = load i1, ptr %t1408, !tbaa !21
  %t1417 = call %"compiler/check:unsetCand" @compiler_2fcheck_3aunsetCand_2ector(ptr %s32, i64 %t1400, i64 -1, i64 %t1401, i1 %t1402, i64 %t1403, %"compiler/source:Span" %t1404, i32 %t1405, i1 %t1409)
  store %"compiler/check:unsetCand" %t1417, ptr %l698
  br label %bb301
bb301:
  %t1418 = load %"compiler/check:unsetCand", ptr %l698
  store %"compiler/check:unsetCand" %t1418, ptr %l29
  call void @__olang_scope_close(ptr %s32)
  br label %bb302
bb302:
  br label %bb303
bb303:
  %t1419 = load i32, ptr %l27, !tbaa !23
  store i32 %t1419, ptr %l699, !tbaa !23
  %t1420 = load ptr, ptr %l0, !tbaa !29
  %t1422 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t1420)
  store i32 %t1422, ptr %l701
  br label %bb304
bb304:
  %t1423 = load i32, ptr %l699, !tbaa !23
  %t1424 = load i32, ptr %l701, !tbaa !23
  %t1425 = icmp eq i32 %t1423, %t1424
  br i1 %t1425, label %bb305, label %bb306
bb305:
  %t1427 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1427, ptr %l704, !tbaa !29
  %t1428 = load ptr, ptr %l28, !tbaa !29
  %t1430 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t1428)
  store i32 %t1430, ptr %l706
  br label %bb307
bb306:
  store i1 false, ptr %l703, !tbaa !21
  br label %bb309
bb307:
  %t1431 = load ptr, ptr %l704, !tbaa !29
  %t1432 = load i32, ptr %l706, !tbaa !23
  %t1433 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t1431, i32 %t1432)
  store i1 %t1433, ptr %l707
  br label %bb308
bb308:
  %t1434 = load i1, ptr %l707, !tbaa !21
  store i1 %t1434, ptr %l703, !tbaa !21
  br label %bb309
bb309:
  %t1435 = load i1, ptr %l703, !tbaa !21
  br i1 %t1435, label %bb310, label %bb311
bb310:
  %t1436 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1436, ptr %l708, !tbaa !29
  %t1437 = load %"compiler/source:Span", ptr %l24
  store %"compiler/source:Span" %t1437, ptr %l709
  %t1438 = load %"compiler/source:Span", ptr %l24
  store %"compiler/source:Span" %t1438, ptr %l710
  %t1439 = load i32, ptr %l27, !tbaa !23
  store i32 %t1439, ptr %l711, !tbaa !23
  %t1440 = load ptr, ptr %l28, !tbaa !29
  %t1442 = icmp eq ptr %t1440, null
  br i1 %t1442, label %bb312, label %bb313
bb311:
  br label %bb316
bb312:
  call void @__olang_check_failed(ptr @olang_loc_456a500fefc58a98_a2eaf47e24a406ac)
  unreachable
bb313:
  br label %bb314
bb314:
  %t1444 = load ptr, ptr %l28, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t1445
  %t1446 = getelementptr { i64, [4 x i64] }, ptr %t1445, i32 0, i32 0
  store i64 2, ptr %t1446
  %t1447 = load %"compiler/source:Span", ptr %l710
  %t1448 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t1447, 0
  %t1449 = load i32, ptr %l711, !tbaa !23
  %t1450 = insertvalue { %"compiler/source:Span", i32, ptr } %t1448, i32 %t1449, 1
  %t1452 = insertvalue { %"compiler/source:Span", i32, ptr } %t1450, ptr %t1444, 2
  %t1453 = getelementptr { i64, [4 x i64] }, ptr %t1445, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t1452, ptr %t1453
  %t1454 = load { i64, [4 x i64] }, ptr %t1445
  %t1456 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t1454, ptr %t1456
  %t1457 = load ptr, ptr %l708, !tbaa !29
  %t1458 = load %"compiler/source:Span", ptr %l709
  %t1460 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t1457, %"compiler/source:Span" %t1458, ptr %t1456)
  store ptr %t1460, ptr %l717
  br label %bb315
bb315:
  %t1461 = load ptr, ptr %l717, !tbaa !29
  store ptr %t1461, ptr %l28, !tbaa !29
  br label %bb316
bb316:
  %t1463 = load ptr, ptr %l2, !tbaa !29
  %t1465 = getelementptr %"compiler/ast:VarDecl", ptr %t1463, i32 0, i32 5
  %t1466 = load i1, ptr %t1465, !tbaa !21
  br i1 %t1466, label %bb317, label %bb318
bb317:
  %t1468 = load ptr, ptr %l0, !tbaa !29
  %t1469 = load i32, ptr %l27, !tbaa !23
  %t1472 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunArrayValue(ptr %v0, ptr %t1468, i32 %t1469)
  store i1 %t1472, ptr %l724
  br label %bb319
bb318:
  store i1 false, ptr %l721, !tbaa !21
  br label %bb320
bb319:
  %t1473 = load i1, ptr %l724, !tbaa !21
  store i1 %t1473, ptr %l721, !tbaa !21
  br label %bb320
bb320:
  %t1474 = load i1, ptr %l721, !tbaa !21
  br i1 %t1474, label %bb321, label %bb322
bb321:
  store %olang.scope zeroinitializer, ptr %s36
  %t1475 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1475, ptr %l725, !tbaa !29
  %t1476 = load %"compiler/source:Span", ptr %l24
  store %"compiler/source:Span" %t1476, ptr %l726
  %t1477 = load ptr, ptr %l0, !tbaa !29
  %t1478 = load i32, ptr %l27, !tbaa !23
  %t1481 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s36, ptr %t1477, i32 %t1478)
  store { i64, ptr } %t1481, ptr %l729
  br label %bb323
bb322:
  br label %bb326
bb323:
  %t1482 = load { i64, ptr }, ptr %l729, !tbaa !27
  %t1483 = extractvalue { i64, ptr } %t1482, 0
  %t1484 = extractvalue { i64, ptr } %t1482, 1
  %t1485 = mul i64 %t1483, 1
  %t1486 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t1485)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1486, ptr %t1484, i64 %t1485, i1 false)
  %t1487 = insertvalue { i64, ptr } undef, i64 %t1483, 0
  %t1488 = insertvalue { i64, ptr } %t1487, ptr %t1486, 1
  %t1490 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayNestedByValue(ptr %s36, ptr %s36, { i64, ptr } %t1488)
  store %"compiler/msgs:Msg" %t1490, ptr %l731
  br label %bb324
bb324:
  %t1491 = load ptr, ptr %l725, !tbaa !29
  %t1492 = load %"compiler/source:Span", ptr %l726
  %t1493 = load %"compiler/msgs:Msg", ptr %l731
  %t1494 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s36, ptr %t1491, %"compiler/source:Span" %t1492, %"compiler/msgs:Msg" %t1493)
  store i64 %t1494, ptr %l732
  br label %bb325
bb325:
  call void @__olang_scope_close(ptr %s36)
  br label %bb326
bb326:
  %t1495 = load ptr, ptr %l2, !tbaa !29
  %t1497 = getelementptr %"compiler/ast:VarDecl", ptr %t1495, i32 0, i32 2
  %t1498 = load ptr, ptr %t1497, !tbaa !29
  %t1500 = icmp eq ptr %t1498, null
  %t1502 = xor i1 %t1500, true
  br i1 %t1502, label %bb327, label %bb328
bb327:
  %t1504 = load ptr, ptr %l2, !tbaa !29
  %t1506 = getelementptr %"compiler/ast:VarDecl", ptr %t1504, i32 0, i32 4
  %t1507 = load i1, ptr %t1506, !tbaa !21
  %t1509 = xor i1 %t1507, true
  store i1 %t1509, ptr %l737, !tbaa !21
  br label %bb329
bb328:
  store i1 false, ptr %l737, !tbaa !21
  br label %bb329
bb329:
  %t1511 = load i1, ptr %l737, !tbaa !21
  br i1 %t1511, label %bb330, label %bb331
bb330:
  %t1512 = load i64, ptr %l23, !tbaa !24
  %t1513 = load ptr, ptr %l2, !tbaa !29
  %t1515 = getelementptr %"compiler/ast:VarDecl", ptr %t1513, i32 0, i32 3
  %t1516 = load { i64, ptr }, ptr %t1515, !tbaa !27
  %t1518 = extractvalue { i64, ptr } %t1516, 0
  %t1521 = icmp slt i64 %t1512, %t1518
  store i1 %t1521, ptr %l741, !tbaa !21
  br label %bb332
bb331:
  store i1 false, ptr %l741, !tbaa !21
  br label %bb332
bb332:
  %t1523 = load i1, ptr %l741, !tbaa !21
  br i1 %t1523, label %bb333, label %bb334
bb333:
  %t1524 = load ptr, ptr %l0, !tbaa !29
  %t1526 = getelementptr %"compiler/check:Checker", ptr %t1524, i32 0, i32 1
  %t1527 = load ptr, ptr %t1526, !tbaa !29
  %t1529 = getelementptr %"compiler/generic:Program", ptr %t1527, i32 0, i32 2
  %t1530 = load i32, ptr %l27, !tbaa !23
  %t1533 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1529, i32 %t1530)
  store i32 %t1533, ptr %l752
  br label %bb335
bb334:
  store i1 false, ptr %l747, !tbaa !21
  br label %bb336
bb335:
  %t1534 = load i32, ptr %l752, !range !{i32 0, i32 33}
  %t1536 = trunc i64 19 to i32
  %t1537 = icmp eq i32 %t1534, %t1536
  store i1 %t1537, ptr %l747, !tbaa !21
  br label %bb336
bb336:
  %t1539 = load i1, ptr %l747, !tbaa !21
  br i1 %t1539, label %bb337, label %bb338
bb337:
  %t1540 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1540, ptr %l756, !tbaa !29
  %t1541 = load ptr, ptr %l0, !tbaa !29
  %t1543 = getelementptr %"compiler/check:Checker", ptr %t1541, i32 0, i32 1
  %t1544 = load ptr, ptr %t1543, !tbaa !29
  %t1546 = getelementptr %"compiler/generic:Program", ptr %t1544, i32 0, i32 2
  %t1547 = load i32, ptr %l27, !tbaa !23
  %t1550 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t1546, i32 %t1547)
  store i32 %t1550, ptr %l761
  br label %bb339
bb338:
  store i1 false, ptr %l755, !tbaa !21
  br label %bb341
bb339:
  %t1551 = load ptr, ptr %l756, !tbaa !29
  %t1552 = load i32, ptr %l761, !tbaa !23
  %t1553 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunArrayValue(ptr %v0, ptr %t1551, i32 %t1552)
  store i1 %t1553, ptr %l762
  br label %bb340
bb340:
  %t1554 = load i1, ptr %l762, !tbaa !21
  store i1 %t1554, ptr %l755, !tbaa !21
  br label %bb341
bb341:
  %t1555 = load i1, ptr %l755, !tbaa !21
  br i1 %t1555, label %bb342, label %bb343
bb342:
  store %olang.scope zeroinitializer, ptr %s37
  %t1556 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1556, ptr %l763, !tbaa !29
  %t1557 = load ptr, ptr %l2, !tbaa !29
  %t1559 = getelementptr %"compiler/ast:VarDecl", ptr %t1557, i32 0, i32 2
  %t1560 = load ptr, ptr %t1559, !tbaa !29
  %t1562 = icmp eq ptr %t1560, null
  br i1 %t1562, label %bb344, label %bb345
bb343:
  br label %bb352
bb344:
  call void @__olang_check_failed(ptr @olang_loc_3b566e89984acdce_dde06b5f9a89c81a)
  unreachable
bb345:
  br label %bb346
bb346:
  %t1564 = load ptr, ptr %l2, !tbaa !29
  %t1566 = getelementptr %"compiler/ast:VarDecl", ptr %t1564, i32 0, i32 2
  %t1567 = load ptr, ptr %t1566, !tbaa !29
  %t1569 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t1567)
  store %"compiler/source:Span" %t1569, ptr %l769
  br label %bb347
bb347:
  %t1570 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1570, ptr %l770, !tbaa !29
  %t1571 = load ptr, ptr %l0, !tbaa !29
  %t1573 = getelementptr %"compiler/check:Checker", ptr %t1571, i32 0, i32 1
  %t1574 = load ptr, ptr %t1573, !tbaa !29
  %t1576 = getelementptr %"compiler/generic:Program", ptr %t1574, i32 0, i32 2
  %t1577 = load i32, ptr %l27, !tbaa !23
  %t1580 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t1576, i32 %t1577)
  store i32 %t1580, ptr %l775
  br label %bb348
bb348:
  %t1581 = load ptr, ptr %l770, !tbaa !29
  %t1582 = load i32, ptr %l775, !tbaa !23
  %t1583 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s37, ptr %t1581, i32 %t1582)
  store { i64, ptr } %t1583, ptr %l776
  br label %bb349
bb349:
  %t1584 = load { i64, ptr }, ptr %l776, !tbaa !27
  %t1585 = extractvalue { i64, ptr } %t1584, 0
  %t1586 = extractvalue { i64, ptr } %t1584, 1
  %t1587 = mul i64 %t1585, 1
  %t1588 = call ptr @__olang_scope_alloc(ptr %s37, i64 %t1587)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1588, ptr %t1586, i64 %t1587, i1 false)
  %t1589 = insertvalue { i64, ptr } undef, i64 %t1585, 0
  %t1590 = insertvalue { i64, ptr } %t1589, ptr %t1588, 1
  %t1592 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayNestedByValue(ptr %s37, ptr %s37, { i64, ptr } %t1590)
  store %"compiler/msgs:Msg" %t1592, ptr %l778
  br label %bb350
bb350:
  %t1593 = load ptr, ptr %l763, !tbaa !29
  %t1594 = load %"compiler/source:Span", ptr %l769
  %t1595 = load %"compiler/msgs:Msg", ptr %l778
  %t1596 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s37, ptr %t1593, %"compiler/source:Span" %t1594, %"compiler/msgs:Msg" %t1595)
  store i64 %t1596, ptr %l779
  br label %bb351
bb351:
  call void @__olang_scope_close(ptr %s37)
  br label %bb352
bb352:
  %t1597 = load i64, ptr %l23, !tbaa !24
  %t1598 = load ptr, ptr %l2, !tbaa !29
  %t1600 = getelementptr %"compiler/ast:VarDecl", ptr %t1598, i32 0, i32 3
  %t1601 = load { i64, ptr }, ptr %t1600, !tbaa !27
  %t1603 = extractvalue { i64, ptr } %t1601, 0
  %t1606 = icmp slt i64 %t1597, %t1603
  br i1 %t1606, label %bb353, label %bb354
bb353:
  %t1608 = load ptr, ptr %l2, !tbaa !29
  %t1610 = getelementptr %"compiler/ast:VarDecl", ptr %t1608, i32 0, i32 2
  %t1611 = load ptr, ptr %t1610, !tbaa !29
  %t1613 = icmp eq ptr %t1611, null
  br i1 %t1613, label %bb355, label %bb356
bb354:
  store i1 false, ptr %l785, !tbaa !21
  br label %bb358
bb355:
  store i1 true, ptr %l789, !tbaa !21
  br label %bb357
bb356:
  %t1615 = load ptr, ptr %l2, !tbaa !29
  %t1617 = getelementptr %"compiler/ast:VarDecl", ptr %t1615, i32 0, i32 4
  %t1618 = load i1, ptr %t1617, !tbaa !21
  store i1 %t1618, ptr %l789, !tbaa !21
  br label %bb357
bb357:
  %t1620 = load i1, ptr %l789, !tbaa !21
  store i1 %t1620, ptr %l785, !tbaa !21
  br label %bb358
bb358:
  %t1621 = load i1, ptr %l785, !tbaa !21
  store i1 %t1621, ptr %l42, !tbaa !21
  %t1622 = load i1, ptr %l42, !tbaa !21
  br i1 %t1622, label %bb359, label %bb360
bb359:
  %t1624 = load ptr, ptr %l0, !tbaa !29
  %t1625 = load i32, ptr %l27, !tbaa !23
  %t1628 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t1624, i32 %t1625)
  store i1 %t1628, ptr %l796
  br label %bb361
bb360:
  store i1 false, ptr %l793, !tbaa !21
  br label %bb362
bb361:
  %t1629 = load i1, ptr %l796, !tbaa !21
  store i1 %t1629, ptr %l793, !tbaa !21
  br label %bb362
bb362:
  %t1630 = load i1, ptr %l793, !tbaa !21
  br i1 %t1630, label %bb363, label %bb364
bb363:
  %t1631 = load ptr, ptr %l0, !tbaa !29
  %t1633 = getelementptr %"compiler/check:Checker", ptr %t1631, i32 0, i32 1
  %t1634 = load ptr, ptr %t1633, !tbaa !29
  %t1636 = getelementptr %"compiler/generic:Program", ptr %t1634, i32 0, i32 2
  %t1637 = load i32, ptr %l27, !tbaa !23
  %t1640 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t1636, i32 %t1637)
  store i64 %t1640, ptr %l802
  br label %bb365
bb364:
  store i1 false, ptr %l797, !tbaa !21
  br label %bb366
bb365:
  %t1641 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t1642 = load i64, ptr %l802, !tbaa !24
  %t1644 = and i64 %t1642, %t1641
  %t1646 = icmp ne i64 %t1644, 0
  store i1 %t1646, ptr %l797, !tbaa !21
  br label %bb366
bb366:
  %t1648 = load i1, ptr %l797, !tbaa !21
  br i1 %t1648, label %bb367, label %bb368
bb367:
  %t1649 = load ptr, ptr %l0, !tbaa !29
  %t1651 = getelementptr %"compiler/check:Checker", ptr %t1649, i32 0, i32 1
  %t1652 = load ptr, ptr %t1651, !tbaa !29
  %t1654 = getelementptr %"compiler/generic:Program", ptr %t1652, i32 0, i32 2
  store ptr %t1654, ptr %l809, !tbaa !29
  %t1655 = load ptr, ptr %l0, !tbaa !29
  %t1656 = load i32, ptr %l27, !tbaa !23
  %t1659 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t1655, i32 %t1656)
  store i32 %t1659, ptr %l812
  br label %bb369
bb368:
  store i1 false, ptr %l806, !tbaa !21
  br label %bb371
bb369:
  %t1660 = load ptr, ptr %l809, !tbaa !29
  %t1661 = load i32, ptr %l812, !tbaa !23
  %t1662 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1660, i32 %t1661)
  store i32 %t1662, ptr %l813
  br label %bb370
bb370:
  %t1663 = load i32, ptr %l813, !range !{i32 0, i32 33}
  %t1665 = trunc i64 21 to i32
  %t1666 = icmp eq i32 %t1663, %t1665
  %t1668 = xor i1 %t1666, true
  store i1 %t1668, ptr %l806, !tbaa !21
  br label %bb371
bb371:
  %t1670 = load i1, ptr %l806, !tbaa !21
  br i1 %t1670, label %bb372, label %bb373
bb372:
  %t1671 = load ptr, ptr %l0, !tbaa !29
  %t1672 = load ptr, ptr %l28, !tbaa !29
  %t1675 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRef(ptr %v0, ptr %v0, ptr %t1671, ptr %t1672)
  store i1 %t1675, ptr %l820
  br label %bb374
bb373:
  store i1 false, ptr %l817, !tbaa !21
  br label %bb375
bb374:
  %t1676 = load i1, ptr %l820, !tbaa !21
  store i1 %t1676, ptr %l817, !tbaa !21
  br label %bb375
bb375:
  %t1677 = load i1, ptr %l817, !tbaa !21
  br i1 %t1677, label %bb376, label %bb377
bb376:
  %t1678 = load ptr, ptr %l0, !tbaa !29
  %t1680 = getelementptr %"compiler/check:Checker", ptr %t1678, i32 0, i32 1
  %t1681 = load ptr, ptr %t1680, !tbaa !29
  %t1683 = getelementptr %"compiler/generic:Program", ptr %t1681, i32 0, i32 2
  store ptr %t1683, ptr %l823, !tbaa !29
  %t1684 = load ptr, ptr %l0, !tbaa !29
  %t1686 = getelementptr %"compiler/check:Checker", ptr %t1684, i32 0, i32 1
  %t1687 = load ptr, ptr %t1686, !tbaa !29
  %t1689 = getelementptr %"compiler/generic:Program", ptr %t1687, i32 0, i32 2
  %t1690 = load i32, ptr %l27, !tbaa !23
  %t1693 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t1689, i32 %t1690)
  store i32 %t1693, ptr %l828
  br label %bb378
bb377:
  br label %bb381
bb378:
  %t1694 = load ptr, ptr %l0, !tbaa !29
  %t1696 = getelementptr %"compiler/check:Checker", ptr %t1694, i32 0, i32 1
  %t1697 = load ptr, ptr %t1696, !tbaa !29
  %t1699 = getelementptr %"compiler/generic:Program", ptr %t1697, i32 0, i32 2
  %t1700 = load i32, ptr %l27, !tbaa !23
  %t1703 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t1699, i32 %t1700)
  store i64 %t1703, ptr %l833
  br label %bb379
bb379:
  %t1704 = load i64, ptr @G_2ecompiler_2ftypes_2eOwning, !tbaa !24
  %t1705 = load i64, ptr %l833, !tbaa !24
  %t1707 = and i64 %t1705, %t1704
  %t1708 = load ptr, ptr %l823, !tbaa !29
  %t1709 = load i32, ptr %l828, !tbaa !23
  %t1711 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t1708, i32 %t1709, i64 %t1707)
  store i32 %t1711, ptr %l836
  br label %bb380
bb380:
  %t1712 = load i32, ptr %l836, !tbaa !23
  store i32 %t1712, ptr %l27, !tbaa !23
  br label %bb381
bb381:
  %t1713 = load i64, ptr %l23, !tbaa !24
  %t1714 = load ptr, ptr %l2, !tbaa !29
  %t1716 = getelementptr %"compiler/ast:VarDecl", ptr %t1714, i32 0, i32 3
  %t1717 = load { i64, ptr }, ptr %t1716, !tbaa !27
  %t1719 = extractvalue { i64, ptr } %t1717, 0
  %t1722 = icmp slt i64 %t1713, %t1719
  br i1 %t1722, label %bb382, label %bb383
bb382:
  %t1724 = load i1, ptr %l42, !tbaa !21
  %t1726 = xor i1 %t1724, true
  store i1 %t1726, ptr %l842, !tbaa !21
  br label %bb384
bb383:
  store i1 false, ptr %l842, !tbaa !21
  br label %bb384
bb384:
  %t1728 = load i1, ptr %l842, !tbaa !21
  br i1 %t1728, label %bb385, label %bb386
bb385:
  %t1729 = load ptr, ptr %l0, !tbaa !29
  %t1730 = load i32, ptr %l27, !tbaa !23
  %t1733 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t1729, i32 %t1730)
  store i1 %t1733, ptr %l848
  br label %bb387
bb386:
  store i1 false, ptr %l845, !tbaa !21
  br label %bb388
bb387:
  %t1734 = load i1, ptr %l848, !tbaa !21
  %t1735 = xor i1 %t1734, true
  store i1 %t1735, ptr %l845, !tbaa !21
  br label %bb388
bb388:
  %t1737 = load i1, ptr %l845, !tbaa !21
  br i1 %t1737, label %bb389, label %bb390
bb389:
  %t1738 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1738, ptr %l850, !tbaa !29
  %t1739 = load ptr, ptr %l28, !tbaa !29
  store ptr %t1739, ptr %l851, !tbaa !29
  %t1740 = load ptr, ptr %l2, !tbaa !29
  %t1742 = getelementptr %"compiler/ast:VarDecl", ptr %t1740, i32 0, i32 3
  %t1743 = load { i64, ptr }, ptr %t1742, !tbaa !27
  store { i64, ptr } %t1743, ptr %l853, !tbaa !27
  %t1744 = load i64, ptr %l23, !tbaa !24
  %t1746 = getelementptr { i64, ptr }, ptr %l853, i32 0, i32 1
  %t1747 = load ptr, ptr %t1746, !tbaa !27
  %t1748 = getelementptr ptr, ptr %t1747, i64 %t1744
  %t1749 = load ptr, ptr %t1748, !tbaa !39
  %t1751 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t1749)
  store %"compiler/source:Span" %t1751, ptr %l856
  br label %bb391
bb390:
  br label %bb393
bb391:
  %t1752 = load i64, ptr @G_2ecompiler_2fcheck_2eRoDecl, !tbaa !24
  %t1753 = load ptr, ptr %l850, !tbaa !29
  %t1754 = load ptr, ptr %l851, !tbaa !29
  %t1755 = load %"compiler/source:Span", ptr %l856
  %t1757 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroStore(ptr %v0, ptr %v0, ptr %t1753, ptr %t1754, %"compiler/source:Span" %t1755, i64 %t1752)
  store i1 %t1757, ptr %l858
  br label %bb392
bb392:
  br label %bb393
bb393:
  %t1758 = load ptr, ptr %l0, !tbaa !29
  %t1759 = load ptr, ptr %l2, !tbaa !29
  %t1761 = getelementptr %"compiler/ast:VarDecl", ptr %t1759, i32 0, i32 0
  %t1762 = load { i64, ptr }, ptr %t1761, !tbaa !27
  store { i64, ptr } %t1762, ptr %l861, !tbaa !27
  %t1763 = load i64, ptr %l23, !tbaa !24
  %t1765 = getelementptr { i64, ptr }, ptr %l861, i32 0, i32 1
  %t1766 = load ptr, ptr %t1765, !tbaa !27
  %t1767 = getelementptr i32, ptr %t1766, i64 %t1763
  %t1768 = load i32, ptr %t1767, !tbaa !33
  %t1769 = load %"compiler/source:Span", ptr %l24
  %t1770 = load i32, ptr %l27, !tbaa !23
  %t1771 = load i32, ptr %l17, !range !{i32 0, i32 7}
  %t1772 = load { i64, [2 x i64] }, ptr %l14
  %t1779 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t1758, i32 %t1768, %"compiler/source:Span" %t1769, i32 %t1770, i32 %t1771, { i64, [2 x i64] } %t1772)
  store i64 %t1779, ptr %l868
  br label %bb394
bb394:
  %t1780 = load i64, ptr %l868, !tbaa !24
  store i64 %t1780, ptr %l43, !tbaa !24
  %t1781 = load i64, ptr %l23, !tbaa !24
  %t1782 = load ptr, ptr %l2, !tbaa !29
  %t1784 = getelementptr %"compiler/ast:VarDecl", ptr %t1782, i32 0, i32 3
  %t1785 = load { i64, ptr }, ptr %t1784, !tbaa !27
  %t1787 = extractvalue { i64, ptr } %t1785, 0
  %t1790 = icmp slt i64 %t1781, %t1787
  br i1 %t1790, label %bb395, label %bb396
bb395:
  %t1792 = load ptr, ptr %l2, !tbaa !29
  %t1794 = getelementptr %"compiler/ast:VarDecl", ptr %t1792, i32 0, i32 5
  %t1795 = load i1, ptr %t1794, !tbaa !21
  %t1797 = xor i1 %t1795, true
  store i1 %t1797, ptr %l874, !tbaa !21
  br label %bb397
bb396:
  store i1 false, ptr %l874, !tbaa !21
  br label %bb397
bb397:
  %t1799 = load i1, ptr %l874, !tbaa !21
  br i1 %t1799, label %bb398, label %bb399
bb398:
  %t1800 = load ptr, ptr %l2, !tbaa !29
  %t1802 = getelementptr %"compiler/ast:VarDecl", ptr %t1800, i32 0, i32 0
  %t1803 = load { i64, ptr }, ptr %t1802, !tbaa !27
  %t1805 = extractvalue { i64, ptr } %t1803, 0
  %t1807 = icmp eq i64 %t1805, 1
  store i1 %t1807, ptr %l878, !tbaa !21
  br label %bb400
bb399:
  store i1 false, ptr %l878, !tbaa !21
  br label %bb400
bb400:
  %t1809 = load i1, ptr %l878, !tbaa !21
  br i1 %t1809, label %bb401, label %bb402
bb401:
  %t1810 = load ptr, ptr %l0, !tbaa !29
  %t1812 = getelementptr %"compiler/check:Checker", ptr %t1810, i32 0, i32 1
  %t1813 = load ptr, ptr %t1812, !tbaa !29
  %t1815 = getelementptr %"compiler/generic:Program", ptr %t1813, i32 0, i32 2
  store ptr %t1815, ptr %l886, !tbaa !29
  %t1816 = load ptr, ptr %l0, !tbaa !29
  %t1818 = getelementptr %"compiler/check:Checker", ptr %t1816, i32 0, i32 1
  %t1819 = load ptr, ptr %t1818, !tbaa !29
  %t1821 = getelementptr %"compiler/generic:Program", ptr %t1819, i32 0, i32 2
  %t1822 = load i32, ptr %l27, !tbaa !23
  %t1825 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t1821, i32 %t1822)
  store i32 %t1825, ptr %l891
  br label %bb403
bb402:
  store i1 false, ptr %l883, !tbaa !21
  br label %bb405
bb403:
  %t1826 = load ptr, ptr %l886, !tbaa !29
  %t1827 = load i32, ptr %l891, !tbaa !23
  %t1828 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1826, i32 %t1827)
  store i32 %t1828, ptr %l892
  br label %bb404
bb404:
  %t1829 = load i32, ptr %l892, !range !{i32 0, i32 33}
  %t1831 = trunc i64 19 to i32
  %t1832 = icmp eq i32 %t1829, %t1831
  store i1 %t1832, ptr %l883, !tbaa !21
  br label %bb405
bb405:
  %t1834 = load i1, ptr %l883, !tbaa !21
  br i1 %t1834, label %bb406, label %bb407
bb406:
  %t1835 = load ptr, ptr %l0, !tbaa !29
  %t1837 = getelementptr %"compiler/check:Checker", ptr %t1835, i32 0, i32 1
  %t1838 = load ptr, ptr %t1837, !tbaa !29
  %t1840 = getelementptr %"compiler/generic:Program", ptr %t1838, i32 0, i32 2
  store ptr %t1840, ptr %l898, !tbaa !29
  %t1841 = load ptr, ptr %l0, !tbaa !29
  %t1843 = getelementptr %"compiler/check:Checker", ptr %t1841, i32 0, i32 1
  %t1844 = load ptr, ptr %t1843, !tbaa !29
  %t1846 = getelementptr %"compiler/generic:Program", ptr %t1844, i32 0, i32 2
  %t1847 = load i32, ptr %l27, !tbaa !23
  %t1850 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t1846, i32 %t1847)
  store i32 %t1850, ptr %l903
  br label %bb408
bb407:
  store i1 false, ptr %l895, !tbaa !21
  br label %bb410
bb408:
  %t1851 = load ptr, ptr %l898, !tbaa !29
  %t1852 = load i32, ptr %l903, !tbaa !23
  %t1853 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t1851, i32 %t1852)
  store i32 %t1853, ptr %l904
  br label %bb409
bb409:
  %t1854 = load i32, ptr %l904, !tbaa !23
  %t1855 = icmp ne i32 %t1854, 0
  store i1 %t1855, ptr %l895, !tbaa !21
  br label %bb410
bb410:
  %t1857 = load i1, ptr %l895, !tbaa !21
  br i1 %t1857, label %bb411, label %bb412
bb411:
  %t1858 = load ptr, ptr %l0, !tbaa !29
  %t1859 = load ptr, ptr %l28, !tbaa !29
  %t1862 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoClearMade(ptr %v0, ptr %v0, ptr %t1858, ptr %t1859)
  store i1 %t1862, ptr %l909
  br label %bb413
bb412:
  store i1 false, ptr %l906, !tbaa !21
  br label %bb414
bb413:
  %t1863 = load i1, ptr %l909, !tbaa !21
  store i1 %t1863, ptr %l906, !tbaa !21
  br label %bb414
bb414:
  %t1864 = load i1, ptr %l906, !tbaa !21
  br i1 %t1864, label %bb415, label %bb416
bb415:
  %t1865 = load i64, ptr %l43, !tbaa !24
  store i64 %t1865, ptr %l44, !tbaa !24
  store i1 true, ptr %l45, !tbaa !21
  %t1867 = load ptr, ptr %l0, !tbaa !29
  %t1869 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t1867)
  store ptr %t1869, ptr %l912
  br label %bb417
bb416:
  br label %bb421
bb417:
  %t1870 = load ptr, ptr %l912, !tbaa !29
  %t1872 = getelementptr %"compiler/typed:Body", ptr %t1870, i32 0, i32 7
  %t1873 = load i64, ptr %l44, !tbaa !24
  %t1876 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t1872, i64 %t1873)
  store %"compiler/typed:Local" %t1876, ptr %l916
  br label %bb418
bb418:
  %t1877 = load %"compiler/typed:Local", ptr %l916
  store %"compiler/typed:Local" %t1877, ptr %l46
  %t1878 = load i1, ptr %l45, !tbaa !21
  %t1880 = getelementptr %"compiler/typed:Local", ptr %l46, i32 0, i32 6
  store i1 %t1878, ptr %t1880, !tbaa !21
  %t1881 = load ptr, ptr %l0, !tbaa !29
  %t1883 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t1881)
  store ptr %t1883, ptr %l919
  br label %bb419
bb419:
  %t1884 = load ptr, ptr %l919, !tbaa !29
  %t1886 = getelementptr %"compiler/typed:Body", ptr %t1884, i32 0, i32 7
  %t1887 = load i64, ptr %l44, !tbaa !24
  %t1888 = load %"compiler/typed:Local", ptr %l46
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eSetAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t1886, i64 %t1887, %"compiler/typed:Local" %t1888)
  br label %bb420
bb420:
  br label %bb421
bb421:
  %t1892 = getelementptr %"compiler/check:unsetCand", ptr %l29, i32 0, i32 2
  %t1893 = load i64, ptr %t1892, !tbaa !24
  %t1895 = icmp sge i64 %t1893, 0
  br i1 %t1895, label %bb422, label %bb423
bb422:
  store %olang.scope zeroinitializer, ptr %s41
  %t1897 = load ptr, ptr %l0, !tbaa !29
  %t1899 = getelementptr %"compiler/check:Checker", ptr %t1897, i32 0, i32 86
  store ptr %t1899, ptr %l927, !tbaa !29
  %t1900 = getelementptr %"compiler/check:unsetCand", ptr %l29, i32 0, i32 0
  %t1901 = load i64, ptr %t1900, !tbaa !24
  %t1902 = load i64, ptr %l43, !tbaa !24
  %t1903 = getelementptr %"compiler/check:unsetCand", ptr %l29, i32 0, i32 2
  %t1904 = load i64, ptr %t1903, !tbaa !24
  %t1905 = getelementptr %"compiler/check:unsetCand", ptr %l29, i32 0, i32 3
  %t1906 = load i1, ptr %t1905, !tbaa !21
  %t1907 = getelementptr %"compiler/check:unsetCand", ptr %l29, i32 0, i32 4
  %t1908 = load i64, ptr %t1907, !tbaa !24
  %t1909 = getelementptr %"compiler/check:unsetCand", ptr %l29, i32 0, i32 5
  %t1910 = load %"compiler/source:Span", ptr %t1909
  %t1911 = getelementptr %"compiler/check:unsetCand", ptr %l29, i32 0, i32 6
  %t1912 = load i32, ptr %t1911, !tbaa !23
  %t1913 = getelementptr %"compiler/check:unsetCand", ptr %l29, i32 0, i32 7
  %t1914 = load i1, ptr %t1913, !tbaa !21
  %t1923 = call %"compiler/check:unsetCand" @compiler_2fcheck_3aunsetCand_2ector(ptr %s41, i64 %t1901, i64 %t1902, i64 %t1904, i1 %t1906, i64 %t1908, %"compiler/source:Span" %t1910, i32 %t1912, i1 %t1914)
  store %"compiler/check:unsetCand" %t1923, ptr %l936
  br label %bb424
bb423:
  br label %bb426
bb424:
  %t1924 = load ptr, ptr %l927, !tbaa !29
  %t1925 = load %"compiler/check:unsetCand", ptr %l936
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aunsetCand_3e_2ePush_Hd5bae6439baa110b1f2b8b5b7cdda5ce(ptr %v0, ptr %t1924, %"compiler/check:unsetCand" %t1925)
  br label %bb425
bb425:
  call void @__olang_scope_close(ptr %s41)
  br label %bb426
bb426:
  %t1926 = load ptr, ptr %l2, !tbaa !29
  %t1928 = getelementptr %"compiler/ast:VarDecl", ptr %t1926, i32 0, i32 2
  %t1929 = load ptr, ptr %t1928, !tbaa !29
  %t1931 = icmp eq ptr %t1929, null
  %t1933 = xor i1 %t1931, true
  br i1 %t1933, label %bb427, label %bb428
bb427:
  %t1935 = load ptr, ptr %l2, !tbaa !29
  %t1937 = getelementptr %"compiler/ast:VarDecl", ptr %t1935, i32 0, i32 4
  %t1938 = load i1, ptr %t1937, !tbaa !21
  %t1940 = xor i1 %t1938, true
  store i1 %t1940, ptr %l941, !tbaa !21
  br label %bb429
bb428:
  store i1 false, ptr %l941, !tbaa !21
  br label %bb429
bb429:
  %t1942 = load i1, ptr %l941, !tbaa !21
  br i1 %t1942, label %bb430, label %bb431
bb430:
  %t1943 = load ptr, ptr %l0, !tbaa !29
  %t1945 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1943)
  store ptr %t1945, ptr %l946
  br label %bb432
bb431:
  br label %bb438
bb432:
  %t1946 = load ptr, ptr %l946, !tbaa !29
  %t1948 = getelementptr %"compiler/check:frame", ptr %t1946, i32 0, i32 3
  store ptr %t1948, ptr %l948, !tbaa !29
  %t1949 = load i64, ptr %l43, !tbaa !24
  store i64 %t1949, ptr %l949, !tbaa !24
  %t1950 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1950, ptr %l950, !tbaa !29
  %t1951 = load ptr, ptr %l2, !tbaa !29
  %t1953 = getelementptr %"compiler/ast:VarDecl", ptr %t1951, i32 0, i32 2
  %t1954 = load ptr, ptr %t1953, !tbaa !29
  %t1956 = icmp eq ptr %t1954, null
  br i1 %t1956, label %bb433, label %bb434
bb433:
  call void @__olang_check_failed(ptr @olang_loc_9c28400664f91d75_969ef375bde61da1)
  unreachable
bb434:
  br label %bb435
bb435:
  %t1958 = load ptr, ptr %l2, !tbaa !29
  %t1960 = getelementptr %"compiler/ast:VarDecl", ptr %t1958, i32 0, i32 2
  %t1961 = load ptr, ptr %t1960, !tbaa !29
  %t1962 = load ptr, ptr %l950, !tbaa !29
  %t1964 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeWrittenAt(ptr %v0, ptr %v1, ptr %t1962, ptr %t1961)
  store { i64, [3 x i64] } %t1964, ptr %l956
  br label %bb436
bb436:
  %t1965 = load ptr, ptr %l948, !tbaa !29
  %t1966 = load i64, ptr %l949, !tbaa !24
  %t1967 = load { i64, [3 x i64] }, ptr %l956
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fdiag_3aWhere_3e_2e_Hc07a7e56a24d8f1225398db99ea19a4b(ptr %v0, ptr %t1965, i64 %t1966, { i64, [3 x i64] } %t1967)
  br label %bb437
bb437:
  br label %bb438
bb438:
  %t1968 = load i1, ptr %l42, !tbaa !21
  br i1 %t1968, label %bb439, label %bb440
bb439:
  %t1970 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1970, ptr %l958, !tbaa !29
  %t1971 = load i64, ptr %l43, !tbaa !24
  store i64 %t1971, ptr %l959, !tbaa !24
  %t1972 = load ptr, ptr %l28, !tbaa !29
  %t1974 = icmp eq ptr %t1972, null
  br i1 %t1974, label %bb441, label %bb442
bb440:
  br label %bb445
bb441:
  call void @__olang_check_failed(ptr @olang_loc_982a334cfac79560_875fefac8daf1dec)
  unreachable
bb442:
  br label %bb443
bb443:
  %t1976 = load ptr, ptr %l28, !tbaa !29
  %t1977 = load ptr, ptr %l958, !tbaa !29
  %t1978 = load i64, ptr %l959, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLet(ptr %v0, ptr %v0, ptr %t1977, i64 %t1978, ptr %t1976)
  br label %bb444
bb444:
  br label %bb445
bb445:
  %t1980 = load i1, ptr %l42, !tbaa !21
  br i1 %t1980, label %bb446, label %bb447
bb446:
  %t1982 = load ptr, ptr %l2, !tbaa !29
  %t1984 = getelementptr %"compiler/ast:VarDecl", ptr %t1982, i32 0, i32 5
  %t1985 = load i1, ptr %t1984, !tbaa !21
  %t1987 = xor i1 %t1985, true
  store i1 %t1987, ptr %l964, !tbaa !21
  br label %bb448
bb447:
  store i1 false, ptr %l964, !tbaa !21
  br label %bb448
bb448:
  %t1989 = load i1, ptr %l964, !tbaa !21
  br i1 %t1989, label %bb449, label %bb450
bb449:
  %t1990 = load ptr, ptr %l0, !tbaa !29
  %t1991 = load i32, ptr %l27, !tbaa !23
  %t1994 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t1990, i32 %t1991)
  store i1 %t1994, ptr %l971
  br label %bb451
bb450:
  store i1 false, ptr %l968, !tbaa !21
  br label %bb452
bb451:
  %t1995 = load i1, ptr %l971, !tbaa !21
  store i1 %t1995, ptr %l968, !tbaa !21
  br label %bb452
bb452:
  %t1996 = load i1, ptr %l968, !tbaa !21
  br i1 %t1996, label %bb453, label %bb454
bb453:
  %t1997 = load ptr, ptr %l0, !tbaa !29
  %t1998 = load ptr, ptr %l2, !tbaa !29
  %t2000 = getelementptr %"compiler/ast:VarDecl", ptr %t1998, i32 0, i32 3
  %t2001 = load { i64, ptr }, ptr %t2000, !tbaa !27
  store { i64, ptr } %t2001, ptr %l975, !tbaa !27
  %t2002 = load i64, ptr %l23, !tbaa !24
  %t2004 = getelementptr { i64, ptr }, ptr %l975, i32 0, i32 1
  %t2005 = load ptr, ptr %t2004, !tbaa !27
  %t2006 = getelementptr ptr, ptr %t2005, i64 %t2002
  %t2007 = load ptr, ptr %t2006, !tbaa !39
  %t2010 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %t1997, ptr %t2007)
  store i1 %t2010, ptr %l978
  br label %bb455
bb454:
  store i1 false, ptr %l972, !tbaa !21
  br label %bb456
bb455:
  %t2011 = load i1, ptr %l978, !tbaa !21
  store i1 %t2011, ptr %l972, !tbaa !21
  br label %bb456
bb456:
  %t2012 = load i1, ptr %l972, !tbaa !21
  br i1 %t2012, label %bb457, label %bb458
bb457:
  store %olang.scope zeroinitializer, ptr %s44
  %t2013 = load ptr, ptr %l0, !tbaa !29
  %t2015 = getelementptr %"compiler/check:Checker", ptr %t2013, i32 0, i32 31
  store ptr %t2015, ptr %l980, !tbaa !29
  %t2016 = load ptr, ptr %l0, !tbaa !29
  %t2018 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t2016)
  store ptr %t2018, ptr %l982
  br label %bb459
bb458:
  br label %bb462
bb459:
  %t2019 = load ptr, ptr %l982, !tbaa !29
  %t2021 = getelementptr %"compiler/check:frame", ptr %t2019, i32 0, i32 0
  %t2022 = load i64, ptr %t2021, !tbaa !24
  %t2023 = load i64, ptr %l43, !tbaa !24
  %t2026 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s44, i64 %t2022, i64 %t2023)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t2026, ptr %l986
  br label %bb460
bb460:
  %t2027 = load ptr, ptr %l980, !tbaa !29
  %t2028 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l986
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t2027, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t2028, i1 true)
  br label %bb461
bb461:
  call void @__olang_scope_close(ptr %s44)
  br label %bb462
bb462:
  %t2029 = load ptr, ptr %l2, !tbaa !29
  %t2031 = getelementptr %"compiler/ast:VarDecl", ptr %t2029, i32 0, i32 5
  %t2032 = load i1, ptr %t2031, !tbaa !21
  %t2034 = xor i1 %t2032, true
  br i1 %t2034, label %bb463, label %bb464
bb463:
  %t2036 = load i64, ptr %l23, !tbaa !24
  %t2037 = load ptr, ptr %l2, !tbaa !29
  %t2039 = getelementptr %"compiler/ast:VarDecl", ptr %t2037, i32 0, i32 3
  %t2040 = load { i64, ptr }, ptr %t2039, !tbaa !27
  %t2042 = extractvalue { i64, ptr } %t2040, 0
  %t2045 = icmp slt i64 %t2036, %t2042
  store i1 %t2045, ptr %l990, !tbaa !21
  br label %bb465
bb464:
  store i1 false, ptr %l990, !tbaa !21
  br label %bb465
bb465:
  %t2047 = load i1, ptr %l990, !tbaa !21
  br i1 %t2047, label %bb466, label %bb467
bb466:
  %t2048 = load ptr, ptr %l0, !tbaa !29
  %t2049 = load i32, ptr %l27, !tbaa !23
  %t2052 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplainScalar(ptr %v0, ptr %t2048, i32 %t2049)
  store i1 %t2052, ptr %l999
  br label %bb468
bb467:
  store i1 false, ptr %l996, !tbaa !21
  br label %bb469
bb468:
  %t2053 = load i1, ptr %l999, !tbaa !21
  store i1 %t2053, ptr %l996, !tbaa !21
  br label %bb469
bb469:
  %t2054 = load i1, ptr %l996, !tbaa !21
  br i1 %t2054, label %bb470, label %bb471
bb470:
  store %olang.scope zeroinitializer, ptr %s45
  %t2055 = load ptr, ptr %l0, !tbaa !29
  %t2057 = getelementptr %"compiler/check:Checker", ptr %t2055, i32 0, i32 113
  store ptr %t2057, ptr %l1001, !tbaa !29
  %t2058 = load ptr, ptr %l0, !tbaa !29
  %t2060 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t2058)
  store ptr %t2060, ptr %l1003
  br label %bb472
bb471:
  br label %bb476
bb472:
  %t2061 = load ptr, ptr %l1003, !tbaa !29
  %t2063 = getelementptr %"compiler/check:frame", ptr %t2061, i32 0, i32 0
  %t2064 = load i64, ptr %t2063, !tbaa !24
  %t2065 = load i64, ptr %l43, !tbaa !24
  %t2068 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s45, i64 %t2064, i64 %t2065)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t2068, ptr %l1007
  br label %bb473
bb473:
  %t2069 = load ptr, ptr %l2, !tbaa !29
  %t2071 = getelementptr %"compiler/ast:VarDecl", ptr %t2069, i32 0, i32 3
  %t2072 = load { i64, ptr }, ptr %t2071, !tbaa !27
  store { i64, ptr } %t2072, ptr %l1009, !tbaa !27
  %t2073 = load i64, ptr %l23, !tbaa !24
  %t2075 = getelementptr { i64, ptr }, ptr %l1009, i32 0, i32 1
  %t2076 = load ptr, ptr %t2075, !tbaa !27
  %t2077 = getelementptr ptr, ptr %t2076, i64 %t2073
  %t2078 = load ptr, ptr %t2077, !tbaa !39
  %t2079 = load i32, ptr %l27, !tbaa !23
  %t2082 = call %"compiler/check:fixedInit" @compiler_2fcheck_3afixedInit_2ector(ptr %v1, ptr %v0, ptr %t2078, i32 %t2079)
  store %"compiler/check:fixedInit" %t2082, ptr %l1013
  br label %bb474
bb474:
  %t2083 = load ptr, ptr %l1001, !tbaa !29
  %t2084 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l1007
  %t2085 = load %"compiler/check:fixedInit", ptr %l1013
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5daf2b89f219287cc2404f0b0e96c809(ptr %v0, ptr %v0, ptr %t2083, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t2084, %"compiler/check:fixedInit" %t2085)
  br label %bb475
bb475:
  call void @__olang_scope_close(ptr %s45)
  br label %bb476
bb476:
  %t2086 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2086, ptr %l1014, !tbaa !29
  %t2087 = load %"compiler/source:Span", ptr %l24
  store %"compiler/source:Span" %t2087, ptr %l1015
  %t2088 = load i64, ptr %l43, !tbaa !24
  %t2090 = trunc i64 %t2088 to i32
  store i32 %t2090, ptr %l1018, !tbaa !23
  %t2092 = load ptr, ptr %l28, !tbaa !29
  %t2094 = icmp eq ptr %t2092, null
  br i1 %t2094, label %bb477, label %bb478
bb477:
  call void @__olang_check_failed(ptr @olang_loc_376d11cdba21927f_511e748ac6a9e8db)
  unreachable
bb478:
  br label %bb479
bb479:
  %t2096 = load ptr, ptr %l28, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t2097
  %t2098 = getelementptr { i64, [3 x i64] }, ptr %t2097, i32 0, i32 0
  store i64 0, ptr %t2098
  %t2099 = load %"compiler/source:Span", ptr %l1015
  %t2100 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t2099, 0
  %t2101 = load i32, ptr %l1018, !tbaa !23
  %t2102 = insertvalue { %"compiler/source:Span", i32, ptr } %t2100, i32 %t2101, 1
  %t2104 = insertvalue { %"compiler/source:Span", i32, ptr } %t2102, ptr %t2096, 2
  %t2105 = getelementptr { i64, [3 x i64] }, ptr %t2097, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t2104, ptr %t2105
  %t2106 = load { i64, [3 x i64] }, ptr %t2097
  %t2108 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t2106, ptr %t2108
  %t2109 = load ptr, ptr %l1014, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t2109, ptr %t2108)
  br label %bb480
bb480:
  %t2111 = load ptr, ptr %l2, !tbaa !29
  %t2113 = getelementptr %"compiler/ast:VarDecl", ptr %t2111, i32 0, i32 5
  %t2114 = load i1, ptr %t2113, !tbaa !21
  br i1 %t2114, label %bb481, label %bb482
bb481:
  %t2116 = load ptr, ptr %l0, !tbaa !29
  %t2118 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t2116)
  store ptr %t2118, ptr %l1027
  br label %bb483
bb482:
  br label %bb485
bb483:
  %t2119 = load ptr, ptr %l1027, !tbaa !29
  %t2121 = getelementptr %"compiler/typed:Body", ptr %t2119, i32 0, i32 10
  %t2122 = load i64, ptr %l43, !tbaa !24
  %t2124 = trunc i64 %t2122 to i32
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2ePush_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t2121, i32 %t2124)
  br label %bb484
bb484:
  br label %bb485
bb485:
  call void @__olang_scope_close(ptr %s15)
  br label %bb486
bb486:
  %t2128 = load i64, ptr %l22, !tbaa !24
  %t2130 = add i64 %t2128, 1
  store i64 %t2130, ptr %l22, !tbaa !24
  br label %bb124
bb487:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalk(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca i1
  %l44 = alloca ptr
  %l48 = alloca ptr
  %l49 = alloca ptr
  %l57 = alloca ptr
  %l61 = alloca ptr
  %l62 = alloca ptr
  %l67 = alloca i32
  %l74 = alloca i32
  %l80 = alloca i1
  %l81 = alloca i32
  %l88 = alloca i32
  %l92 = alloca i64
  %l94 = alloca ptr
  %l97 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l100 = alloca i1
  %l101 = alloca i1
  %l105 = alloca i1
  %l106 = alloca ptr
  %l108 = alloca ptr
  %l109 = alloca i1
  %l110 = alloca ptr
  %l111 = alloca ptr
  %l112 = alloca i32
  %l115 = alloca %"compiler/source:Span"
  %l116 = alloca ptr
  %l129 = alloca ptr
  %l130 = alloca %"compiler/source:Span"
  %l132 = alloca i32
  %l133 = alloca i64
  %l134 = alloca ptr
  %l135 = alloca %"compiler/source:Span"
  %l138 = alloca i32
  %l139 = alloca ptr
  %l140 = alloca %"compiler/source:Span"
  %l142 = alloca i32
  %l143 = alloca ptr
  %l146 = alloca ptr
  %l147 = alloca %"compiler/source:Span"
  %l149 = alloca i32
  %l150 = alloca i64
  %l151 = alloca ptr
  %l152 = alloca %"compiler/source:Span"
  %l155 = alloca i32
  %l156 = alloca ptr
  %l157 = alloca %"compiler/source:Span"
  %l159 = alloca i32
  %l160 = alloca i32
  %l164 = alloca ptr
  %l165 = alloca ptr
  %l171 = alloca i1
  %l176 = alloca i32
  %l178 = alloca i1
  %l181 = alloca ptr
  %l186 = alloca i32
  %l187 = alloca i32
  %l190 = alloca ptr
  %l193 = alloca ptr
  %l198 = alloca i32
  %l199 = alloca i64
  %l212 = alloca ptr
  %l221 = alloca i32
  %l226 = alloca i32
  %l230 = alloca ptr
  %l235 = alloca i32
  %l236 = alloca { i64, ptr }
  %l242 = alloca i64
  %l245 = alloca i64
  %l264 = alloca { i64, ptr }
  %l267 = alloca { i64, ptr }
  %l268 = alloca i1
  %l269 = alloca i1
  %l272 = alloca ptr
  %l276 = alloca { i64, ptr }
  %l279 = alloca i32
  %l280 = alloca { i64, ptr }
  %l294 = alloca ptr
  %l297 = alloca %"compiler/source:Span"
  %l300 = alloca { i64, ptr }
  %l302 = alloca %"compiler/msgs:Msg"
  %l303 = alloca i64
  %l308 = alloca i64
  %l312 = alloca i64
  %l315 = alloca i1
  %l318 = alloca i1
  %l322 = alloca i1
  %l346 = alloca i64
  %l349 = alloca ptr
  %l350 = alloca %"compiler/source:Span"
  %l353 = alloca %"compiler/source:Span"
  %l354 = alloca i64
  %l356 = alloca ptr
  %l359 = alloca { i64, ptr }
  %l362 = alloca { i64, ptr }
  %l366 = alloca ptr
  %l367 = alloca ptr
  %l368 = alloca ptr
  %l371 = alloca i32
  %l372 = alloca i32
  %l373 = alloca i64
  %l376 = alloca ptr
  %l379 = alloca %"compiler/source:Span"
  %l392 = alloca i64
  %l395 = alloca i64
  %l398 = alloca i1
  %l401 = alloca ptr
  %l404 = alloca ptr
  %l408 = alloca i32
  %l409 = alloca i32
  %l410 = alloca { i64, ptr }
  %l414 = alloca ptr
  %l415 = alloca ptr
  %l420 = alloca i1
  %l435 = alloca i1
  %l437 = alloca ptr
  %l440 = alloca %"compiler/source:Span"
  %l443 = alloca { i64, ptr }
  %l445 = alloca %"compiler/msgs:Msg"
  %l446 = alloca i64
  %s0 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %rv = alloca ptr
  %t196 = alloca { i64, [3 x i64] }, align 8
  %t235 = alloca { i64, [3 x i64] }, align 8
  %t283 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:ForIn", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l5, !tbaa !29
  store ptr %t6, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t7 = load ptr, ptr %l32, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l32, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 29}
  %t13 = icmp eq i64 %t11, 25
  store i1 %t13, ptr %l33, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l33, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l5, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t17, i32 0, i32 1
  %t19 = load { i64, ptr }, ptr %t18
  store { i64, ptr } %t19, ptr %l6, !tbaa !27
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load %"compiler/source:Span", ptr %l1
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t24 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t25 = load ptr, ptr %l3, !tbaa !29
  %t26 = load i32, ptr %l4, !tbaa !23
  %t33 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eforRange(ptr %v0, ptr %v1, ptr %v1, ptr %v2, ptr %t21, %"compiler/source:Span" %t22, ptr %t23, { i64, ptr } %t24, ptr %t25, i32 %t26)
  store ptr %t33, ptr %l44
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t34 = load ptr, ptr %l44, !tbaa !29
  store ptr %t34, ptr %rv
  br label %ret
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_1c0ab263f2e4f7dc_3e069dbdc7ae0b68)
  unreachable
bb12:
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr %"compiler/ast:ForIn", ptr %t35, i32 0, i32 3
  %t38 = load i1, ptr %t37, !tbaa !21
  br i1 %t38, label %bb13, label %bb14
bb13:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t40)
  store ptr %t42, ptr %l48
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t43 = load ptr, ptr %l48, !tbaa !29
  store ptr %t43, ptr %l49, !tbaa !29
  %t44 = load ptr, ptr %l49, !tbaa !29
  %t45 = getelementptr %"compiler/check:frame", ptr %t44, i32 0, i32 15
  %t46 = load i64, ptr %t45, !tbaa !24
  %t48 = add i64 %t46, 1
  %t50 = load ptr, ptr %l49, !tbaa !29
  %t51 = getelementptr %"compiler/check:frame", ptr %t50, i32 0, i32 15
  store i64 %t48, ptr %t51, !tbaa !24
  br label %bb16
bb16:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l2, !tbaa !29
  %t55 = getelementptr %"compiler/ast:ForIn", ptr %t53, i32 0, i32 2
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t62 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t52, ptr %t56, i32 %t58)
  store ptr %t62, ptr %l57
  br label %bb17
bb17:
  %t63 = load ptr, ptr %l57, !tbaa !29
  store ptr %t63, ptr %l7, !tbaa !29
  %t64 = load ptr, ptr %l2, !tbaa !29
  %t66 = getelementptr %"compiler/ast:ForIn", ptr %t64, i32 0, i32 3
  %t67 = load i1, ptr %t66, !tbaa !21
  br i1 %t67, label %bb18, label %bb19
bb18:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t69)
  store ptr %t71, ptr %l61
  br label %bb20
bb19:
  br label %bb21
bb20:
  %t72 = load ptr, ptr %l61, !tbaa !29
  store ptr %t72, ptr %l62, !tbaa !29
  %t73 = load ptr, ptr %l62, !tbaa !29
  %t74 = getelementptr %"compiler/check:frame", ptr %t73, i32 0, i32 15
  %t75 = load i64, ptr %t74, !tbaa !24
  %t77 = sub i64 %t75, 1
  %t79 = load ptr, ptr %l62, !tbaa !29
  %t80 = getelementptr %"compiler/check:frame", ptr %t79, i32 0, i32 15
  store i64 %t77, ptr %t80, !tbaa !24
  br label %bb21
bb21:
  %t81 = load ptr, ptr %l7, !tbaa !29
  %t84 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t81)
  store i32 %t84, ptr %l67
  br label %bb22
bb22:
  %t85 = load i32, ptr %l67, !tbaa !23
  store i32 %t85, ptr %l8, !tbaa !23
  %t86 = load i32, ptr %l8, !tbaa !23
  %t87 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t90 = icmp eq i32 %t86, %t87
  br i1 %t90, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load i32, ptr %l8, !tbaa !23
  %t97 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t93, i32 %t94)
  store i32 %t97, ptr %l74
  br label %bb26
bb26:
  %t98 = load i32, ptr %l74, !tbaa !23
  store i32 %t98, ptr %l9, !tbaa !23
  %t99 = load i32, ptr %l9, !tbaa !23
  %t100 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t103 = icmp ne i32 %t99, %t100
  br i1 %t103, label %bb27, label %bb28
bb27:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load i32, ptr %l8, !tbaa !23
  %t109 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t105, i32 %t106)
  store i1 %t109, ptr %l80
  br label %bb29
bb28:
  br label %bb75
bb29:
  %t110 = load i1, ptr %l80, !tbaa !21
  br i1 %t110, label %bb30, label %bb31
bb30:
  %t111 = load i32, ptr %l8, !tbaa !23
  store i32 %t111, ptr %l81, !tbaa !23
  br label %bb33
bb31:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/check:Checker", ptr %t113, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !29
  %t118 = getelementptr %"compiler/generic:Program", ptr %t116, i32 0, i32 2
  %t119 = load i32, ptr %l8, !tbaa !23
  %t120 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t124 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t118, i32 %t119, i64 %t120)
  store i32 %t124, ptr %l88
  br label %bb32
bb32:
  %t125 = load i32, ptr %l88, !tbaa !23
  store i32 %t125, ptr %l81, !tbaa !23
  br label %bb33
bb33:
  %t126 = load i32, ptr %l81, !tbaa !23
  store i32 %t126, ptr %l10, !tbaa !23
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load %"compiler/source:Span", ptr %l1
  %t129 = load i32, ptr %l10, !tbaa !23
  %t133 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t127, %"compiler/source:Span" %t128, i32 %t129)
  store i64 %t133, ptr %l92
  br label %bb34
bb34:
  %t134 = load i64, ptr %l92, !tbaa !24
  store i64 %t134, ptr %l11, !tbaa !24
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/check:Checker", ptr %t135, i32 0, i32 62
  store ptr %t137, ptr %l94, !tbaa !29
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t139 = load i64, ptr %l11, !tbaa !24
  %t142 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKey(ptr %v0, ptr %t138, i64 %t139)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t142, ptr %l97
  br label %bb35
bb35:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load i32, ptr %l8, !tbaa !23
  %t147 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t143, i32 %t144)
  store i1 %t147, ptr %l100
  br label %bb36
bb36:
  %t148 = load i1, ptr %l100, !tbaa !21
  br i1 %t148, label %bb37, label %bb38
bb37:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load ptr, ptr %l7, !tbaa !29
  %t154 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRef(ptr %v0, ptr %v0, ptr %t149, ptr %t150)
  store i1 %t154, ptr %l105
  br label %bb39
bb38:
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l106, !tbaa !29
  %t156 = load ptr, ptr %l7, !tbaa !29
  %t158 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %t156)
  store ptr %t158, ptr %l108
  br label %bb40
bb39:
  %t159 = load i1, ptr %l105, !tbaa !21
  store i1 %t159, ptr %l101, !tbaa !21
  br label %bb42
bb40:
  %t160 = load ptr, ptr %l106, !tbaa !29
  %t161 = load ptr, ptr %l108, !tbaa !29
  %t162 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroPlace(ptr %v0, ptr %v0, ptr %t160, ptr %t161)
  store i1 %t162, ptr %l109
  br label %bb41
bb41:
  %t163 = load i1, ptr %l109, !tbaa !21
  store i1 %t163, ptr %l101, !tbaa !21
  br label %bb42
bb42:
  %t164 = load ptr, ptr %l94, !tbaa !29
  %t165 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l97
  %t166 = load i1, ptr %l101, !tbaa !21
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t164, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t165, i1 %t166)
  br label %bb43
bb43:
  %t167 = load ptr, ptr %l0, !tbaa !29
  store ptr %t167, ptr %l110, !tbaa !29
  %t168 = load ptr, ptr %l7, !tbaa !29
  store ptr %t168, ptr %l111, !tbaa !29
  %t169 = load i32, ptr %l10, !tbaa !23
  store i32 %t169, ptr %l112, !tbaa !23
  %t170 = load ptr, ptr %l2, !tbaa !29
  %t172 = getelementptr %"compiler/ast:ForIn", ptr %t170, i32 0, i32 2
  %t173 = load ptr, ptr %t172, !tbaa !29
  %t175 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t173)
  store %"compiler/source:Span" %t175, ptr %l115
  br label %bb44
bb44:
  %t176 = load ptr, ptr %l110, !tbaa !29
  %t177 = load ptr, ptr %l111, !tbaa !29
  %t178 = load i32, ptr %l112, !tbaa !23
  %t179 = load %"compiler/source:Span", ptr %l115
  %t180 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t176, ptr %t177, i32 %t178, %"compiler/source:Span" %t179)
  store ptr %t180, ptr %l116
  br label %bb45
bb45:
  %t181 = load ptr, ptr %l116, !tbaa !29
  store ptr %t181, ptr %l12, !tbaa !29
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t183 = load i64, ptr %l11, !tbaa !24
  %t184 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroTrack(ptr %v0, ptr %v0, ptr %t182, i64 %t183, ptr %t184)
  br label %bb46
bb46:
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t190 = load %"compiler/source:Span", ptr %l1
  %t191 = load i64, ptr %l11, !tbaa !24
  %t193 = trunc i64 %t191 to i32
  %t195 = load ptr, ptr %l12, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t196
  %t197 = getelementptr { i64, [3 x i64] }, ptr %t196, i32 0, i32 0
  store i64 0, ptr %t197
  %t199 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t190, 0
  %t201 = insertvalue { %"compiler/source:Span", i32, ptr } %t199, i32 %t193, 1
  %t203 = insertvalue { %"compiler/source:Span", i32, ptr } %t201, ptr %t195, 2
  %t204 = getelementptr { i64, [3 x i64] }, ptr %t196, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t203, ptr %t204
  %t205 = load { i64, [3 x i64] }, ptr %t196
  %t207 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t205, ptr %t207
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t189, ptr %t207)
  br label %bb47
bb47:
  %t210 = load ptr, ptr %l0, !tbaa !29
  store ptr %t210, ptr %l129, !tbaa !29
  %t211 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t211, ptr %l130
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t212)
  store i32 %t214, ptr %l132
  br label %bb48
bb48:
  %t215 = load ptr, ptr %l129, !tbaa !29
  %t216 = load %"compiler/source:Span", ptr %l130
  %t217 = load i32, ptr %l132, !tbaa !23
  %t218 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t215, %"compiler/source:Span" %t216, i32 %t217)
  store i64 %t218, ptr %l133
  br label %bb49
bb49:
  %t219 = load i64, ptr %l133, !tbaa !24
  store i64 %t219, ptr %l13, !tbaa !24
  %t220 = load ptr, ptr %l0, !tbaa !29
  store ptr %t220, ptr %l134, !tbaa !29
  %t221 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t221, ptr %l135
  %t222 = load i64, ptr %l13, !tbaa !24
  %t224 = trunc i64 %t222 to i32
  store i32 %t224, ptr %l138, !tbaa !23
  %t226 = load ptr, ptr %l0, !tbaa !29
  store ptr %t226, ptr %l139, !tbaa !29
  %t227 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t227, ptr %l140
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t230 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t228)
  store i32 %t230, ptr %l142
  br label %bb50
bb50:
  %t231 = load ptr, ptr %l139, !tbaa !29
  %t232 = load %"compiler/source:Span", ptr %l140
  %t233 = load i32, ptr %l142, !tbaa !23
  %t234 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t231, %"compiler/source:Span" %t232, i32 %t233, i64 0)
  store ptr %t234, ptr %l143
  br label %bb51
bb51:
  store { i64, [3 x i64] } zeroinitializer, ptr %t235
  %t236 = getelementptr { i64, [3 x i64] }, ptr %t235, i32 0, i32 0
  store i64 0, ptr %t236
  %t237 = load %"compiler/source:Span", ptr %l135
  %t238 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t237, 0
  %t239 = load i32, ptr %l138, !tbaa !23
  %t240 = insertvalue { %"compiler/source:Span", i32, ptr } %t238, i32 %t239, 1
  %t241 = load ptr, ptr %l143, !tbaa !29
  %t242 = insertvalue { %"compiler/source:Span", i32, ptr } %t240, ptr %t241, 2
  %t243 = getelementptr { i64, [3 x i64] }, ptr %t235, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t242, ptr %t243
  %t244 = load { i64, [3 x i64] }, ptr %t235
  %t246 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t244, ptr %t246
  %t247 = load ptr, ptr %l134, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t247, ptr %t246)
  br label %bb52
bb52:
  %t249 = load ptr, ptr %l0, !tbaa !29
  store ptr %t249, ptr %l146, !tbaa !29
  %t250 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t250, ptr %l147
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t253 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t251)
  store i32 %t253, ptr %l149
  br label %bb53
bb53:
  %t254 = load ptr, ptr %l146, !tbaa !29
  %t255 = load %"compiler/source:Span", ptr %l147
  %t256 = load i32, ptr %l149, !tbaa !23
  %t257 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t254, %"compiler/source:Span" %t255, i32 %t256)
  store i64 %t257, ptr %l150
  br label %bb54
bb54:
  %t258 = load i64, ptr %l150, !tbaa !24
  store i64 %t258, ptr %l14, !tbaa !24
  %t259 = load ptr, ptr %l0, !tbaa !29
  store ptr %t259, ptr %l151, !tbaa !29
  %t260 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t260, ptr %l152
  %t261 = load i64, ptr %l14, !tbaa !24
  %t263 = trunc i64 %t261 to i32
  store i32 %t263, ptr %l155, !tbaa !23
  %t265 = load ptr, ptr %l0, !tbaa !29
  store ptr %t265, ptr %l156, !tbaa !29
  %t266 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t266, ptr %l157
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t269 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t267)
  store i32 %t269, ptr %l159
  br label %bb55
bb55:
  store i32 22, ptr %l160
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t271 = load %"compiler/source:Span", ptr %l1
  %t272 = load i64, ptr %l11, !tbaa !24
  %t276 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t270, %"compiler/source:Span" %t271, i64 %t272)
  store ptr %t276, ptr %l164
  br label %bb56
bb56:
  %t277 = load ptr, ptr %l156, !tbaa !29
  %t278 = load %"compiler/source:Span", ptr %l157
  %t279 = load i32, ptr %l159, !tbaa !23
  %t280 = load i32, ptr %l160, !range !{i32 0, i32 43}
  %t281 = load ptr, ptr %l164, !tbaa !29
  %t282 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t277, %"compiler/source:Span" %t278, i32 %t279, i32 %t280, ptr %t281, ptr null)
  store ptr %t282, ptr %l165
  br label %bb57
bb57:
  store { i64, [3 x i64] } zeroinitializer, ptr %t283
  %t284 = getelementptr { i64, [3 x i64] }, ptr %t283, i32 0, i32 0
  store i64 0, ptr %t284
  %t285 = load %"compiler/source:Span", ptr %l152
  %t286 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t285, 0
  %t287 = load i32, ptr %l155, !tbaa !23
  %t288 = insertvalue { %"compiler/source:Span", i32, ptr } %t286, i32 %t287, 1
  %t289 = load ptr, ptr %l165, !tbaa !29
  %t290 = insertvalue { %"compiler/source:Span", i32, ptr } %t288, ptr %t289, 2
  %t291 = getelementptr { i64, [3 x i64] }, ptr %t283, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t290, ptr %t291
  %t292 = load { i64, [3 x i64] }, ptr %t283
  %t294 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t292, ptr %t294
  %t295 = load ptr, ptr %l151, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t295, ptr %t294)
  br label %bb58
bb58:
  %t297 = load ptr, ptr %l3, !tbaa !29
  %t299 = icmp eq ptr %t297, null
  %t301 = xor i1 %t299, true
  br i1 %t301, label %bb59, label %bb60
bb59:
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t305 = getelementptr %"compiler/check:Checker", ptr %t303, i32 0, i32 1
  %t306 = load ptr, ptr %t305, !tbaa !29
  %t308 = getelementptr %"compiler/generic:Program", ptr %t306, i32 0, i32 2
  %t309 = load i32, ptr %l9, !tbaa !23
  %t312 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t308, i32 %t309)
  store i32 %t312, ptr %l176
  br label %bb61
bb60:
  store i1 false, ptr %l171, !tbaa !21
  br label %bb62
bb61:
  %t313 = load i32, ptr %l176, !tbaa !23
  %t314 = icmp ne i32 %t313, 0
  store i1 %t314, ptr %l171, !tbaa !21
  br label %bb62
bb62:
  %t316 = load i1, ptr %l171, !tbaa !21
  br i1 %t316, label %bb63, label %bb64
bb63:
  %t317 = load ptr, ptr %l0, !tbaa !29
  %t319 = getelementptr %"compiler/check:Checker", ptr %t317, i32 0, i32 1
  %t320 = load ptr, ptr %t319, !tbaa !29
  %t322 = getelementptr %"compiler/generic:Program", ptr %t320, i32 0, i32 2
  store ptr %t322, ptr %l181, !tbaa !29
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t325 = getelementptr %"compiler/check:Checker", ptr %t323, i32 0, i32 1
  %t326 = load ptr, ptr %t325, !tbaa !29
  %t328 = getelementptr %"compiler/generic:Program", ptr %t326, i32 0, i32 2
  %t329 = load i32, ptr %l9, !tbaa !23
  %t332 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t328, i32 %t329)
  store i32 %t332, ptr %l186
  br label %bb65
bb64:
  store i1 false, ptr %l178, !tbaa !21
  br label %bb67
bb65:
  %t333 = load ptr, ptr %l181, !tbaa !29
  %t334 = load i32, ptr %l186, !tbaa !23
  %t335 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t333, i32 %t334)
  store i32 %t335, ptr %l187
  br label %bb66
bb66:
  %t336 = load i32, ptr %l187, !range !{i32 0, i32 33}
  %t338 = trunc i64 26 to i32
  %t339 = icmp eq i32 %t336, %t338
  store i1 %t339, ptr %l178, !tbaa !21
  br label %bb67
bb67:
  %t341 = load i1, ptr %l178, !tbaa !21
  br i1 %t341, label %bb68, label %bb69
bb68:
  %t342 = load ptr, ptr %l0, !tbaa !29
  store ptr %t342, ptr %l190, !tbaa !29
  %t343 = load ptr, ptr %l0, !tbaa !29
  %t345 = getelementptr %"compiler/check:Checker", ptr %t343, i32 0, i32 1
  %t346 = load ptr, ptr %t345, !tbaa !29
  %t348 = getelementptr %"compiler/generic:Program", ptr %t346, i32 0, i32 2
  store ptr %t348, ptr %l193, !tbaa !29
  %t349 = load ptr, ptr %l0, !tbaa !29
  %t351 = getelementptr %"compiler/check:Checker", ptr %t349, i32 0, i32 1
  %t352 = load ptr, ptr %t351, !tbaa !29
  %t354 = getelementptr %"compiler/generic:Program", ptr %t352, i32 0, i32 2
  %t355 = load i32, ptr %l9, !tbaa !23
  %t358 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t354, i32 %t355)
  store i32 %t358, ptr %l198
  br label %bb70
bb69:
  br label %bb72
bb70:
  %t359 = load ptr, ptr %l193, !tbaa !29
  %t360 = load i32, ptr %l198, !tbaa !23
  %t361 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t359, i32 %t360)
  store i64 %t361, ptr %l199
  br label %bb71
bb71:
  %t362 = load i64, ptr %l199, !tbaa !24
  %t363 = load ptr, ptr %l190, !tbaa !29
  %t364 = getelementptr %"compiler/check:Checker", ptr %t363, i32 0, i32 98
  store i64 %t362, ptr %t364, !tbaa !24
  br label %bb72
bb72:
  %t365 = load ptr, ptr %l0, !tbaa !29
  %t366 = load %"compiler/source:Span", ptr %l1
  %t367 = load ptr, ptr %l2, !tbaa !29
  %t368 = load i64, ptr %l13, !tbaa !24
  %t369 = load i64, ptr %l14, !tbaa !24
  %t370 = load i64, ptr %l11, !tbaa !24
  %t371 = load i32, ptr %l9, !tbaa !23
  %t372 = load ptr, ptr %l3, !tbaa !29
  %t373 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecounted(ptr %v0, ptr %v1, ptr %v2, ptr %t365, %"compiler/source:Span" %t366, ptr %t367, i64 %t368, i64 %t369, i64 %t370, i32 %t371, i64 -1, i64 -1, ptr %t372, i32 %t373)
  br label %bb73
bb73:
  %t383 = load ptr, ptr %l0, !tbaa !29
  %t384 = load %"compiler/source:Span", ptr %l1
  %t385 = load i64, ptr %l14, !tbaa !24
  %t389 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t383, %"compiler/source:Span" %t384, i64 %t385)
  store ptr %t389, ptr %l212
  br label %bb74
bb74:
  %t390 = load ptr, ptr %l212, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t390, ptr %rv
  br label %ret
bb75:
  %t392 = load ptr, ptr %l3, !tbaa !29
  %t394 = icmp eq ptr %t392, null
  %t396 = xor i1 %t394, true
  br i1 %t396, label %bb76, label %bb77
bb76:
  %t398 = load ptr, ptr %l0, !tbaa !29
  %t399 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecomprOpen(ptr %v0, ptr %t398, %"compiler/source:Span" %t399)
  br label %bb78
bb77:
  br label %bb79
bb78:
  br label %bb79
bb79:
  %t402 = load ptr, ptr %l0, !tbaa !29
  %t403 = load i32, ptr %l8, !tbaa !23
  %t406 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t402, i32 %t403)
  store i32 %t406, ptr %l221
  br label %bb80
bb80:
  %t407 = load i32, ptr %l221, !tbaa !23
  store i32 %t407, ptr %l15, !tbaa !23
  %t408 = load ptr, ptr %l0, !tbaa !29
  %t410 = getelementptr %"compiler/check:Checker", ptr %t408, i32 0, i32 1
  %t411 = load ptr, ptr %t410, !tbaa !29
  %t413 = getelementptr %"compiler/generic:Program", ptr %t411, i32 0, i32 2
  %t414 = load i32, ptr %l15, !tbaa !23
  %t417 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t413, i32 %t414)
  store i32 %t417, ptr %l226
  br label %bb81
bb81:
  %t418 = load i32, ptr %l226, !range !{i32 0, i32 33}
  %t420 = trunc i64 29 to i32
  %t421 = icmp eq i32 %t418, %t420
  br i1 %t421, label %bb82, label %bb83
bb82:
  store %olang.scope zeroinitializer, ptr %s9
  %t423 = load ptr, ptr %l0, !tbaa !29
  %t425 = getelementptr %"compiler/check:Checker", ptr %t423, i32 0, i32 1
  %t426 = load ptr, ptr %t425, !tbaa !29
  store ptr %t426, ptr %l230, !tbaa !29
  %t427 = load ptr, ptr %l0, !tbaa !29
  %t429 = getelementptr %"compiler/check:Checker", ptr %t427, i32 0, i32 1
  %t430 = load ptr, ptr %t429, !tbaa !29
  %t432 = getelementptr %"compiler/generic:Program", ptr %t430, i32 0, i32 2
  %t433 = load i32, ptr %l15, !tbaa !23
  %t436 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %t432, i32 %t433)
  store i32 %t436, ptr %l235
  br label %bb84
bb83:
  br label %bb113
bb84:
  %t437 = load ptr, ptr %l230, !tbaa !29
  %t438 = load i32, ptr %l235, !tbaa !23
  %t439 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %t437, i32 %t438)
  store { i64, ptr } %t439, ptr %l236
  br label %bb85
bb85:
  %t440 = load { i64, ptr }, ptr %l236, !tbaa !27
  store { i64, ptr } %t440, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t441 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t443 = extractvalue { i64, ptr } %t441, 0
  store i64 %t443, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t445 = load i64, ptr %l18, !tbaa !24
  %t446 = load i64, ptr %l17, !tbaa !24
  %t449 = icmp sgt i64 %t445, %t446
  br i1 %t449, label %bb86, label %bb87
bb86:
  %t451 = load i64, ptr %l19, !tbaa !24
  %t453 = icmp sgt i64 %t451, 0
  br i1 %t453, label %bb88, label %bb89
bb87:
  store i64 0, ptr %l242, !tbaa !24
  br label %bb91
bb88:
  %t455 = load i64, ptr %l18, !tbaa !24
  %t456 = load i64, ptr %l17, !tbaa !24
  %t459 = sub i64 %t455, %t456
  %t460 = load i64, ptr %l19, !tbaa !24
  %t463 = add i64 %t459, %t460
  %t465 = sub i64 %t463, 1
  %t466 = load i64, ptr %l19, !tbaa !24
  %t469 = sdiv i64 %t465, %t466
  store i64 %t469, ptr %l245, !tbaa !24
  br label %bb90
bb89:
  store i64 0, ptr %l245, !tbaa !24
  br label %bb90
bb90:
  %t471 = load i64, ptr %l245, !tbaa !24
  store i64 %t471, ptr %l242, !tbaa !24
  br label %bb91
bb91:
  %t472 = load i64, ptr %l242, !tbaa !24
  store i64 %t472, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb92
bb92:
  store %olang.scope zeroinitializer, ptr %s11
  %t473 = load i64, ptr %l21, !tbaa !24
  %t474 = load i64, ptr %l20, !tbaa !24
  %t477 = icmp slt i64 %t473, %t474
  %t479 = xor i1 %t477, true
  br i1 %t479, label %bb93, label %bb94
bb93:
  call void @__olang_scope_close(ptr %s11)
  br label %bb108
bb94:
  br label %bb95
bb95:
  %t481 = load i64, ptr %l17, !tbaa !24
  %t482 = load i64, ptr %l21, !tbaa !24
  %t483 = load i64, ptr %l19, !tbaa !24
  %t486 = mul i64 %t482, %t483
  %t489 = add i64 %t481, %t486
  store i64 %t489, ptr %l22, !tbaa !24
  %t491 = load ptr, ptr %l0, !tbaa !29
  %t492 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t492, ptr %l264, !tbaa !27
  %t493 = load i64, ptr %l22, !tbaa !24
  %t495 = getelementptr { i64, ptr }, ptr %l264, i32 0, i32 1
  %t496 = load ptr, ptr %t495, !tbaa !27
  %t497 = getelementptr %"compiler/generic:AnySlot", ptr %t496, i64 %t493
  %t498 = getelementptr %"compiler/generic:AnySlot", ptr %t497, i32 0, i32 0
  %t499 = load i32, ptr %t498, !tbaa !23
  %t502 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t491, i32 %t499)
  store { i64, ptr } %t502, ptr %l267
  br label %bb96
bb96:
  %t503 = load { i64, ptr }, ptr %l267, !tbaa !27
  %t504 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s11, { i64, ptr } %t503, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d43, i32 0, i32 1) })
  store i1 %t504, ptr %l268
  br label %bb97
bb97:
  %t505 = load i1, ptr %l268, !tbaa !21
  br i1 %t505, label %bb98, label %bb99
bb98:
  %t506 = load ptr, ptr %l0, !tbaa !29
  %t508 = getelementptr %"compiler/check:Checker", ptr %t506, i32 0, i32 1
  %t509 = load ptr, ptr %t508, !tbaa !29
  %t511 = getelementptr %"compiler/generic:Program", ptr %t509, i32 0, i32 2
  store ptr %t511, ptr %l272, !tbaa !29
  %t512 = load ptr, ptr %l0, !tbaa !29
  %t514 = getelementptr %"compiler/check:Checker", ptr %t512, i32 0, i32 1
  %t515 = load ptr, ptr %t514, !tbaa !29
  %t517 = getelementptr %"compiler/generic:Program", ptr %t515, i32 0, i32 2
  %t518 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t518, ptr %l276, !tbaa !27
  %t519 = load i64, ptr %l22, !tbaa !24
  %t521 = getelementptr { i64, ptr }, ptr %l276, i32 0, i32 1
  %t522 = load ptr, ptr %t521, !tbaa !27
  %t523 = getelementptr %"compiler/generic:AnySlot", ptr %t522, i64 %t519
  %t524 = getelementptr %"compiler/generic:AnySlot", ptr %t523, i32 0, i32 5
  %t525 = load i32, ptr %t524, !tbaa !23
  %t528 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t517, i32 %t525)
  store i32 %t528, ptr %l279
  br label %bb100
bb99:
  store i1 false, ptr %l269, !tbaa !21
  br label %bb102
bb100:
  %t529 = load ptr, ptr %l272, !tbaa !29
  %t530 = load i32, ptr %l279, !tbaa !23
  %t531 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t529, i32 %t530)
  store { i64, ptr } %t531, ptr %l280
  br label %bb101
bb101:
  %t532 = load { i64, ptr }, ptr %l280, !tbaa !27
  %t533 = extractvalue { i64, ptr } %t532, 0
  %t535 = icmp eq i64 %t533, 1
  store i1 %t535, ptr %l269, !tbaa !21
  br label %bb102
bb102:
  %t537 = load i1, ptr %l269, !tbaa !21
  br i1 %t537, label %bb103, label %bb104
bb103:
  %t538 = load ptr, ptr %l0, !tbaa !29
  %t539 = load %"compiler/source:Span", ptr %l1
  %t540 = load ptr, ptr %l2, !tbaa !29
  %t541 = load ptr, ptr %l7, !tbaa !29
  %t542 = load i64, ptr %l22, !tbaa !24
  %t544 = sub i64 -2, %t542
  %t545 = load ptr, ptr %l3, !tbaa !29
  %t546 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkIter(ptr %v0, ptr %v1, ptr %v2, ptr %t538, %"compiler/source:Span" %t539, ptr %t540, ptr %t541, i64 %t544, ptr %t545, i32 %t546)
  br label %bb105
bb104:
  br label %bb106
bb105:
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb106:
  call void @__olang_scope_close(ptr %s11)
  br label %bb107
bb107:
  %t555 = load i64, ptr %l21, !tbaa !24
  %t557 = add i64 %t555, 1
  store i64 %t557, ptr %l21, !tbaa !24
  br label %bb92
bb108:
  %t559 = load ptr, ptr %l0, !tbaa !29
  store ptr %t559, ptr %l294, !tbaa !29
  %t560 = load ptr, ptr %l2, !tbaa !29
  %t562 = getelementptr %"compiler/ast:ForIn", ptr %t560, i32 0, i32 2
  %t563 = load ptr, ptr %t562, !tbaa !29
  %t565 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t563)
  store %"compiler/source:Span" %t565, ptr %l297
  br label %bb109
bb109:
  %t566 = load ptr, ptr %l0, !tbaa !29
  %t567 = load i32, ptr %l8, !tbaa !23
  %t570 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s9, ptr %t566, i32 %t567)
  store { i64, ptr } %t570, ptr %l300
  br label %bb110
bb110:
  %t571 = load { i64, ptr }, ptr %l300, !tbaa !27
  %t572 = extractvalue { i64, ptr } %t571, 0
  %t573 = extractvalue { i64, ptr } %t571, 1
  %t574 = mul i64 %t572, 1
  %t575 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t574)
  call void @llvm.memcpy.p0.p0.i64(ptr %t575, ptr %t573, i64 %t574, i1 false)
  %t576 = insertvalue { i64, ptr } undef, i64 %t572, 0
  %t577 = insertvalue { i64, ptr } %t576, ptr %t575, 1
  %t579 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotIterable(ptr %s9, ptr %s9, { i64, ptr } %t577)
  store %"compiler/msgs:Msg" %t579, ptr %l302
  br label %bb111
bb111:
  %t580 = load ptr, ptr %l294, !tbaa !29
  %t581 = load %"compiler/source:Span", ptr %l297
  %t582 = load %"compiler/msgs:Msg", ptr %l302
  %t583 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s9, ptr %t580, %"compiler/source:Span" %t581, %"compiler/msgs:Msg" %t582)
  store i64 %t583, ptr %l303
  br label %bb112
bb112:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb113:
  %t585 = load ptr, ptr %l0, !tbaa !29
  %t586 = load i32, ptr %l15, !tbaa !23
  %t587 = load %"compiler/source:Span", ptr %l1
  %t591 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleUse(ptr %v0, ptr %s0, ptr %s0, ptr %t585, i32 %t586, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d44, i32 0, i32 1) }, i64 1, %"compiler/source:Span" %t587, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d45, i32 0, i32 1) })
  store i64 %t591, ptr %l308
  br label %bb114
bb114:
  %t592 = load i64, ptr %l308, !tbaa !24
  store i64 %t592, ptr %l23, !tbaa !24
  %t593 = load ptr, ptr %l0, !tbaa !29
  %t594 = load i32, ptr %l15, !tbaa !23
  %t595 = load %"compiler/source:Span", ptr %l1
  %t599 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleUse(ptr %v0, ptr %s0, ptr %s0, ptr %t593, i32 %t594, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d46, i32 0, i32 1) }, i64 0, %"compiler/source:Span" %t595, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d47, i32 0, i32 1) })
  store i64 %t599, ptr %l312
  br label %bb115
bb115:
  %t600 = load i64, ptr %l312, !tbaa !24
  store i64 %t600, ptr %l24, !tbaa !24
  %t601 = load i64, ptr %l24, !tbaa !24
  %t603 = icmp sge i64 %t601, 0
  br i1 %t603, label %bb116, label %bb117
bb116:
  %t605 = load ptr, ptr %l0, !tbaa !29
  %t606 = load i64, ptr %l24, !tbaa !24
  %t609 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eiterShaped(ptr %v0, ptr %t605, i64 %t606)
  store i1 %t609, ptr %l318
  br label %bb118
bb117:
  store i1 false, ptr %l315, !tbaa !21
  br label %bb119
bb118:
  %t610 = load i1, ptr %l318, !tbaa !21
  %t611 = xor i1 %t610, true
  store i1 %t611, ptr %l315, !tbaa !21
  br label %bb119
bb119:
  %t613 = load i1, ptr %l315, !tbaa !21
  br i1 %t613, label %bb120, label %bb121
bb120:
  store i64 -1, ptr %l24, !tbaa !24
  br label %bb122
bb121:
  br label %bb122
bb122:
  %t614 = load i64, ptr %l23, !tbaa !24
  %t616 = icmp sge i64 %t614, 0
  br i1 %t616, label %bb123, label %bb124
bb123:
  %t618 = load i64, ptr %l24, !tbaa !24
  %t620 = icmp slt i64 %t618, 0
  store i1 %t620, ptr %l322, !tbaa !21
  br label %bb125
bb124:
  store i1 false, ptr %l322, !tbaa !21
  br label %bb125
bb125:
  %t622 = load i1, ptr %l322, !tbaa !21
  br i1 %t622, label %bb126, label %bb127
bb126:
  %t623 = load ptr, ptr %l0, !tbaa !29
  %t624 = load %"compiler/source:Span", ptr %l1
  %t625 = load ptr, ptr %l2, !tbaa !29
  %t626 = load ptr, ptr %l7, !tbaa !29
  %t627 = load i64, ptr %l23, !tbaa !24
  %t628 = load ptr, ptr %l3, !tbaa !29
  %t629 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkRuns(ptr %v0, ptr %v1, ptr %v2, ptr %t623, %"compiler/source:Span" %t624, ptr %t625, ptr %t626, i64 %t627, ptr %t628, i32 %t629)
  br label %bb128
bb127:
  br label %bb129
bb128:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb129:
  %t638 = load i64, ptr %l24, !tbaa !24
  %t640 = icmp sge i64 %t638, 0
  br i1 %t640, label %bb130, label %bb131
bb130:
  %t642 = load ptr, ptr %l0, !tbaa !29
  %t643 = load %"compiler/source:Span", ptr %l1
  %t644 = load ptr, ptr %l2, !tbaa !29
  %t645 = load ptr, ptr %l7, !tbaa !29
  %t646 = load i64, ptr %l24, !tbaa !24
  %t647 = load ptr, ptr %l3, !tbaa !29
  %t648 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkIter(ptr %v0, ptr %v1, ptr %v2, ptr %t642, %"compiler/source:Span" %t643, ptr %t644, ptr %t645, i64 %t646, ptr %t647, i32 %t648)
  br label %bb132
bb131:
  br label %bb133
bb132:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb133:
  %t657 = load ptr, ptr %l0, !tbaa !29
  %t658 = load i32, ptr %l15, !tbaa !23
  %t659 = load %"compiler/source:Span", ptr %l1
  %t663 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleUse(ptr %v0, ptr %s0, ptr %s0, ptr %t657, i32 %t658, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d48, i32 0, i32 1) }, i64 0, %"compiler/source:Span" %t659, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d49, i32 0, i32 1) })
  store i64 %t663, ptr %l346
  br label %bb134
bb134:
  %t664 = load i64, ptr %l346, !tbaa !24
  store i64 %t664, ptr %l25, !tbaa !24
  %t665 = load i64, ptr %l25, !tbaa !24
  %t667 = icmp sge i64 %t665, 0
  br i1 %t667, label %bb135, label %bb136
bb135:
  store %olang.scope zeroinitializer, ptr %s17
  %t669 = load ptr, ptr %l0, !tbaa !29
  store ptr %t669, ptr %l349, !tbaa !29
  %t670 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t670, ptr %l350
  %t671 = load ptr, ptr %l2, !tbaa !29
  %t673 = getelementptr %"compiler/ast:ForIn", ptr %t671, i32 0, i32 2
  %t674 = load ptr, ptr %t673, !tbaa !29
  %t676 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t674)
  store %"compiler/source:Span" %t676, ptr %l353
  br label %bb137
bb136:
  br label %bb160
bb137:
  %t677 = load i64, ptr %l25, !tbaa !24
  store i64 %t677, ptr %l354, !tbaa !24
  %t678 = load ptr, ptr %l7, !tbaa !29
  store ptr %t678, ptr %l356, !tbaa !29
  %t680 = icmp sge i64 0, 0
  br i1 %t680, label %bb138, label %bb139
bb138:
  %t682 = icmp sle i64 0, 1152921504606846975
  br i1 %t682, label %bb140, label %bb141
bb139:
  call void @__olang_check_failed(ptr @olang_loc_139af6e2a2dcda96_1438f6a9e620193a)
  unreachable
bb140:
  %t684 = mul i64 0, 8
  %t685 = insertvalue { i64, ptr } undef, i64 0, 0
  %t686 = insertvalue { i64, ptr } %t685, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t686, ptr %l359, !tbaa !27
  %t687 = icmp sge i64 0, 0
  br i1 %t687, label %bb142, label %bb143
bb141:
  call void @__olang_check_failed(ptr @olang_loc_139af6e2a2dcda96_1438f6a9e620193a)
  unreachable
bb142:
  %t689 = icmp sle i64 0, 1152921504606846975
  br i1 %t689, label %bb144, label %bb145
bb143:
  call void @__olang_check_failed(ptr @olang_loc_139af6e2a2dcda96_1438f6a9e620193a)
  unreachable
bb144:
  %t691 = mul i64 0, 8
  %t692 = insertvalue { i64, ptr } undef, i64 0, 0
  %t693 = insertvalue { i64, ptr } %t692, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t693, ptr %l362, !tbaa !27
  %t694 = icmp sge i64 0, 0
  br i1 %t694, label %bb146, label %bb147
bb145:
  call void @__olang_check_failed(ptr @olang_loc_139af6e2a2dcda96_1438f6a9e620193a)
  unreachable
bb146:
  %t696 = icmp sle i64 0, 2305843009213693951
  br i1 %t696, label %bb148, label %bb149
bb147:
  call void @__olang_check_failed(ptr @olang_loc_a734531b29123b5_def2307fb88201b9)
  unreachable
bb148:
  %t698 = mul i64 0, 4
  %t699 = insertvalue { i64, ptr } undef, i64 0, 0
  %t700 = insertvalue { i64, ptr } %t699, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t701 = load ptr, ptr %l349, !tbaa !29
  %t702 = load %"compiler/source:Span", ptr %l350
  %t703 = load %"compiler/source:Span", ptr %l353
  %t704 = load i64, ptr %l354, !tbaa !24
  %t705 = load ptr, ptr %l356, !tbaa !29
  %t706 = load { i64, ptr }, ptr %l359, !tbaa !27
  %t707 = load { i64, ptr }, ptr %l362, !tbaa !27
  %t709 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %s17, ptr %t701, %"compiler/source:Span" %t702, %"compiler/source:Span" %t703, i64 %t704, ptr %t705, { i64, ptr } %t706, { i64, ptr } %t707, { i64, ptr } %t700)
  store ptr %t709, ptr %l366
  br label %bb150
bb149:
  call void @__olang_check_failed(ptr @olang_loc_a734531b29123b5_def2307fb88201b9)
  unreachable
bb150:
  %t710 = load ptr, ptr %l366, !tbaa !29
  store ptr %t710, ptr %l26, !tbaa !29
  %t711 = load ptr, ptr %l0, !tbaa !29
  store ptr %t711, ptr %l367, !tbaa !29
  %t712 = load ptr, ptr %l0, !tbaa !29
  store ptr %t712, ptr %l368, !tbaa !29
  %t713 = load ptr, ptr %l26, !tbaa !29
  %t716 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t713)
  store i32 %t716, ptr %l371
  br label %bb151
bb151:
  %t717 = load ptr, ptr %l368, !tbaa !29
  %t718 = load i32, ptr %l371, !tbaa !23
  %t719 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t717, i32 %t718)
  store i32 %t719, ptr %l372
  br label %bb152
bb152:
  %t720 = load ptr, ptr %l367, !tbaa !29
  %t721 = load i32, ptr %l372, !tbaa !23
  %t722 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s17, ptr %t720, i32 %t721, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d50, i32 0, i32 1) }, i64 0)
  store i64 %t722, ptr %l373
  br label %bb153
bb153:
  %t723 = load i64, ptr %l373, !tbaa !24
  store i64 %t723, ptr %l27, !tbaa !24
  %t724 = load i64, ptr %l27, !tbaa !24
  %t726 = icmp slt i64 %t724, 0
  br i1 %t726, label %bb154, label %bb155
bb154:
  store %olang.scope zeroinitializer, ptr %s18
  %t728 = load ptr, ptr %l0, !tbaa !29
  store ptr %t728, ptr %l376, !tbaa !29
  %t729 = load ptr, ptr %l2, !tbaa !29
  %t731 = getelementptr %"compiler/ast:ForIn", ptr %t729, i32 0, i32 2
  %t732 = load ptr, ptr %t731, !tbaa !29
  %t734 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t732)
  store %"compiler/source:Span" %t734, ptr %l379
  br label %bb156
bb155:
  br label %bb158
bb156:
  %t735 = load ptr, ptr %l376, !tbaa !29
  %t736 = load %"compiler/source:Span", ptr %l379
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s18, ptr %t735, %"compiler/source:Span" %t736, { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d51, i32 0, i32 1) })
  br label %bb157
bb157:
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb158:
  %t738 = load ptr, ptr %l0, !tbaa !29
  %t739 = load %"compiler/source:Span", ptr %l1
  %t740 = load ptr, ptr %l2, !tbaa !29
  %t741 = load ptr, ptr %l26, !tbaa !29
  %t742 = load i64, ptr %l27, !tbaa !24
  %t743 = load ptr, ptr %l3, !tbaa !29
  %t744 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkIter(ptr %v0, ptr %v1, ptr %v2, ptr %t738, %"compiler/source:Span" %t739, ptr %t740, ptr %t741, i64 %t742, ptr %t743, i32 %t744)
  br label %bb159
bb159:
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb160:
  %t753 = load ptr, ptr %l0, !tbaa !29
  %t754 = load i32, ptr %l15, !tbaa !23
  %t755 = load %"compiler/source:Span", ptr %l1
  %t759 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleUse(ptr %v0, ptr %s0, ptr %s0, ptr %t753, i32 %t754, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d52, i32 0, i32 1) }, i64 1, %"compiler/source:Span" %t755, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d53, i32 0, i32 1) })
  store i64 %t759, ptr %l392
  br label %bb161
bb161:
  %t760 = load i64, ptr %l392, !tbaa !24
  store i64 %t760, ptr %l28, !tbaa !24
  %t761 = load ptr, ptr %l0, !tbaa !29
  %t762 = load i32, ptr %l15, !tbaa !23
  %t765 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s0, ptr %t761, i32 %t762, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d54, i32 0, i32 1) }, i64 0)
  store i64 %t765, ptr %l395
  br label %bb162
bb162:
  %t766 = load i64, ptr %l395, !tbaa !24
  store i64 %t766, ptr %l29, !tbaa !24
  %t767 = load i64, ptr %l28, !tbaa !24
  %t769 = icmp sge i64 %t767, 0
  br i1 %t769, label %bb163, label %bb164
bb163:
  %t771 = load ptr, ptr %l0, !tbaa !29
  %t773 = getelementptr %"compiler/check:Checker", ptr %t771, i32 0, i32 1
  %t774 = load ptr, ptr %t773, !tbaa !29
  %t776 = getelementptr %"compiler/generic:Program", ptr %t774, i32 0, i32 2
  store ptr %t776, ptr %l401, !tbaa !29
  %t777 = load ptr, ptr %l0, !tbaa !29
  %t779 = getelementptr %"compiler/check:Checker", ptr %t777, i32 0, i32 1
  %t780 = load ptr, ptr %t779, !tbaa !29
  %t782 = getelementptr %"compiler/generic:Program", ptr %t780, i32 0, i32 2
  store ptr %t782, ptr %l404, !tbaa !29
  %t783 = load ptr, ptr %l0, !tbaa !29
  %t785 = getelementptr %"compiler/check:Checker", ptr %t783, i32 0, i32 1
  %t786 = load ptr, ptr %t785, !tbaa !29
  %t787 = load i64, ptr %l28, !tbaa !24
  %t790 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t786, i64 %t787)
  store i32 %t790, ptr %l408
  br label %bb165
bb164:
  store i1 false, ptr %l398, !tbaa !21
  br label %bb168
bb165:
  %t791 = load ptr, ptr %l404, !tbaa !29
  %t792 = load i32, ptr %l408, !tbaa !23
  %t793 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t791, i32 %t792)
  store i32 %t793, ptr %l409
  br label %bb166
bb166:
  %t794 = load ptr, ptr %l401, !tbaa !29
  %t795 = load i32, ptr %l409, !tbaa !23
  %t796 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t794, i32 %t795)
  store { i64, ptr } %t796, ptr %l410
  br label %bb167
bb167:
  %t797 = load { i64, ptr }, ptr %l410, !tbaa !27
  %t798 = extractvalue { i64, ptr } %t797, 0
  %t800 = icmp sgt i64 %t798, 0
  store i1 %t800, ptr %l398, !tbaa !21
  br label %bb168
bb168:
  %t802 = load i1, ptr %l398, !tbaa !21
  br i1 %t802, label %bb169, label %bb170
bb169:
  %t803 = load ptr, ptr %l0, !tbaa !29
  %t805 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t803)
  store ptr %t805, ptr %l414
  br label %bb171
bb170:
  br label %bb172
bb171:
  %t806 = load ptr, ptr %l414, !tbaa !29
  store ptr %t806, ptr %l415, !tbaa !29
  %t807 = load ptr, ptr %l415, !tbaa !29
  %t808 = getelementptr %"compiler/check:frame", ptr %t807, i32 0, i32 17
  %t809 = load i64, ptr %t808, !tbaa !24
  %t811 = add i64 %t809, 1
  %t813 = load ptr, ptr %l415, !tbaa !29
  %t814 = getelementptr %"compiler/check:frame", ptr %t813, i32 0, i32 17
  store i64 %t811, ptr %t814, !tbaa !24
  br label %bb172
bb172:
  %t815 = load i64, ptr %l28, !tbaa !24
  %t817 = icmp sge i64 %t815, 0
  br i1 %t817, label %bb173, label %bb174
bb173:
  %t819 = load i64, ptr %l29, !tbaa !24
  %t821 = icmp sge i64 %t819, 0
  store i1 %t821, ptr %l420, !tbaa !21
  br label %bb175
bb174:
  store i1 false, ptr %l420, !tbaa !21
  br label %bb175
bb175:
  %t823 = load i1, ptr %l420, !tbaa !21
  br i1 %t823, label %bb176, label %bb177
bb176:
  %t824 = load ptr, ptr %l0, !tbaa !29
  %t825 = load %"compiler/source:Span", ptr %l1
  %t826 = load ptr, ptr %l2, !tbaa !29
  %t827 = load ptr, ptr %l7, !tbaa !29
  %t828 = load i64, ptr %l28, !tbaa !24
  %t829 = load i64, ptr %l29, !tbaa !24
  %t830 = load ptr, ptr %l3, !tbaa !29
  %t831 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkIndexed(ptr %v0, ptr %v1, ptr %v2, ptr %t824, %"compiler/source:Span" %t825, ptr %t826, ptr %t827, i64 %t828, i64 %t829, ptr %t830, i32 %t831)
  br label %bb178
bb177:
  br label %bb179
bb178:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb179:
  %t841 = load ptr, ptr %l0, !tbaa !29
  %t842 = load i32, ptr %l15, !tbaa !23
  %t843 = load %"compiler/source:Span", ptr %l1
  %t847 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %s0, ptr %s0, ptr %t841, i32 %t842, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d55, i32 0, i32 1) }, %"compiler/source:Span" %t843, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d56, i32 0, i32 1) }, i64 0, i1 false)
  store i1 %t847, ptr %l435
  br label %bb180
bb180:
  %t848 = load i1, ptr %l435, !tbaa !21
  br i1 %t848, label %bb181, label %bb182
bb181:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb182:
  br label %bb183
bb183:
  %t850 = load ptr, ptr %l0, !tbaa !29
  store ptr %t850, ptr %l437, !tbaa !29
  %t851 = load ptr, ptr %l2, !tbaa !29
  %t853 = getelementptr %"compiler/ast:ForIn", ptr %t851, i32 0, i32 2
  %t854 = load ptr, ptr %t853, !tbaa !29
  %t856 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t854)
  store %"compiler/source:Span" %t856, ptr %l440
  br label %bb184
bb184:
  %t857 = load ptr, ptr %l0, !tbaa !29
  %t858 = load i32, ptr %l8, !tbaa !23
  %t861 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t857, i32 %t858)
  store { i64, ptr } %t861, ptr %l443
  br label %bb185
bb185:
  %t862 = load { i64, ptr }, ptr %l443, !tbaa !27
  %t863 = extractvalue { i64, ptr } %t862, 0
  %t864 = extractvalue { i64, ptr } %t862, 1
  %t865 = mul i64 %t863, 1
  %t866 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t865)
  call void @llvm.memcpy.p0.p0.i64(ptr %t866, ptr %t864, i64 %t865, i1 false)
  %t867 = insertvalue { i64, ptr } undef, i64 %t863, 0
  %t868 = insertvalue { i64, ptr } %t867, ptr %t866, 1
  %t870 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotIterable(ptr %s0, ptr %s0, { i64, ptr } %t868)
  store %"compiler/msgs:Msg" %t870, ptr %l445
  br label %bb186
bb186:
  %t871 = load ptr, ptr %l437, !tbaa !29
  %t872 = load %"compiler/source:Span", ptr %l440
  %t873 = load %"compiler/msgs:Msg", ptr %l445
  %t874 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s0, ptr %t871, %"compiler/source:Span" %t872, %"compiler/msgs:Msg" %t873)
  store i64 %t874, ptr %l446
  br label %bb187
bb187:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewholeNarrowed(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"compiler/check:narrowed"
  %l10 = alloca ptr
  %l12 = alloca ptr
  %l15 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l41 = alloca ptr
  %l44 = alloca i64
  %l48 = alloca %"compiler/check:narrowed"
  %l52 = alloca i1
  %l55 = alloca ptr
  %l60 = alloca i32
  %l61 = alloca ptr
  %l63 = alloca ptr
  %l66 = alloca i1
  %l74 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l12
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l12, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t5, i32 0, i32 44
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eLen_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l15
  br label %bb2
bb2:
  %t10 = load i64, ptr %l15, !tbaa !24
  store i64 %t10, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t12 = load i64, ptr %l3, !tbaa !24
  %t15 = icmp sgt i64 %t11, %t12
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = load i64, ptr %l5, !tbaa !24
  %t19 = icmp sgt i64 %t17, 0
  br i1 %t19, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb8
bb5:
  %t21 = load i64, ptr %l4, !tbaa !24
  %t22 = load i64, ptr %l3, !tbaa !24
  %t25 = sub i64 %t21, %t22
  %t26 = load i64, ptr %l5, !tbaa !24
  %t29 = add i64 %t25, %t26
  %t31 = sub i64 %t29, 1
  %t32 = load i64, ptr %l5, !tbaa !24
  %t35 = sdiv i64 %t31, %t32
  store i64 %t35, ptr %l22, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb7
bb7:
  %t37 = load i64, ptr %l22, !tbaa !24
  store i64 %t37, ptr %l19, !tbaa !24
  br label %bb8
bb8:
  %t38 = load i64, ptr %l19, !tbaa !24
  store i64 %t38, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb9
bb9:
  %t39 = load i64, ptr %l7, !tbaa !24
  %t40 = load i64, ptr %l6, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb10, label %bb11
bb10:
  br label %bb32
bb11:
  br label %bb12
bb12:
  %t47 = load i64, ptr %l3, !tbaa !24
  %t48 = load i64, ptr %l7, !tbaa !24
  %t49 = load i64, ptr %l5, !tbaa !24
  %t52 = mul i64 %t48, %t49
  %t55 = add i64 %t47, %t52
  store i64 %t55, ptr %l8, !tbaa !24
  %t57 = load ptr, ptr %l2, !tbaa !29
  %t59 = getelementptr %"compiler/check:frame", ptr %t57, i32 0, i32 44
  store ptr %t59, ptr %l41, !tbaa !29
  %t60 = load ptr, ptr %l2, !tbaa !29
  %t62 = getelementptr %"compiler/check:frame", ptr %t60, i32 0, i32 44
  %t64 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eLen_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %t62)
  store i64 %t64, ptr %l44
  br label %bb13
bb13:
  %t65 = load i64, ptr %l44, !tbaa !24
  %t66 = sub i64 %t65, 1
  %t67 = load i64, ptr %l8, !tbaa !24
  %t70 = sub i64 %t66, %t67
  %t71 = load ptr, ptr %l41, !tbaa !29
  %t73 = call %"compiler/check:narrowed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eAt_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %t71, i64 %t70)
  store %"compiler/check:narrowed" %t73, ptr %l48
  br label %bb14
bb14:
  %t74 = load %"compiler/check:narrowed", ptr %l48
  store %"compiler/check:narrowed" %t74, ptr %l9
  %t75 = getelementptr %"compiler/check:narrowed", ptr %l9, i32 0, i32 0
  %t76 = load i64, ptr %t75, !tbaa !24
  %t80 = icmp ne i64 %t76, %a1
  br i1 %t80, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l52, !tbaa !21
  br label %bb17
bb16:
  %t82 = getelementptr %"compiler/check:narrowed", ptr %l9, i32 0, i32 5
  %t83 = load i1, ptr %t82, !tbaa !21
  store i1 %t83, ptr %l52, !tbaa !21
  br label %bb17
bb17:
  %t85 = load i1, ptr %l52, !tbaa !21
  br i1 %t85, label %bb18, label %bb19
bb18:
  br label %bb31
bb19:
  br label %bb20
bb20:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/check:Checker", ptr %t86, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !29
  store ptr %t89, ptr %l55, !tbaa !29
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/check:Checker", ptr %t90, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t95 = getelementptr %"compiler/generic:Program", ptr %t93, i32 0, i32 2
  %t96 = getelementptr %"compiler/check:narrowed", ptr %l9, i32 0, i32 2
  %t97 = load i32, ptr %t96, !tbaa !23
  %t100 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t95, i32 %t97)
  store i32 %t100, ptr %l60
  br label %bb21
bb21:
  %t101 = load ptr, ptr %l55, !tbaa !29
  %t102 = load i32, ptr %l60, !tbaa !23
  %t103 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %t101, i32 %t102)
  store ptr %t103, ptr %l61
  br label %bb22
bb22:
  %t104 = getelementptr %"compiler/check:narrowed", ptr %l9, i32 0, i32 1
  %t105 = load i64, ptr %t104, !tbaa !24
  %t106 = load ptr, ptr %l61, !tbaa !29
  %t108 = call ptr @compiler_2fcheck_2ecaseDecl(ptr %v0, ptr %t106, i64 %t105)
  store ptr %t108, ptr %l63
  br label %bb23
bb23:
  %t109 = load ptr, ptr %l63, !tbaa !29
  store ptr %t109, ptr %l10, !tbaa !29
  %t110 = load ptr, ptr %l10, !tbaa !29
  %t112 = icmp eq ptr %t110, null
  br i1 %t112, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l66, !tbaa !21
  br label %bb26
bb25:
  %t114 = load ptr, ptr %l10, !tbaa !29
  %t116 = getelementptr %"compiler/ast:CaseDecl", ptr %t114, i32 0, i32 3
  %t117 = load i1, ptr %t116, !tbaa !21
  %t119 = xor i1 %t117, true
  store i1 %t119, ptr %l66, !tbaa !21
  br label %bb26
bb26:
  %t121 = load i1, ptr %l66, !tbaa !21
  br i1 %t121, label %bb27, label %bb28
bb27:
  store i64 -1, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  %t123 = load ptr, ptr %l2, !tbaa !29
  %t125 = getelementptr %"compiler/check:frame", ptr %t123, i32 0, i32 45
  %t126 = getelementptr %"compiler/check:narrowed", ptr %l9, i32 0, i32 3
  %t127 = load i64, ptr %t126, !tbaa !24
  %t130 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t125, i64 %t127)
  store i64 %t130, ptr %l74
  br label %bb30
bb30:
  %t131 = load i64, ptr %l74, !tbaa !24
  store i64 %t131, ptr %rv
  br label %ret
bb31:
  %t132 = load i64, ptr %l7, !tbaa !24
  %t134 = add i64 %t132, 1
  store i64 %t134, ptr %l7, !tbaa !24
  br label %bb9
bb32:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewriteBackNoNumber(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, ptr %a4, %"compiler/source:Span" %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i1
  %l7 = alloca { i64, ptr }
  %l8 = alloca i32
  %l9 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l20 = alloca i1
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l28 = alloca i64
  %l33 = alloca i64
  %l36 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l42 = alloca i64
  %l47 = alloca i64
  %l49 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l52 = alloca i64
  %l54 = alloca i64
  %l55 = alloca { i64, ptr }
  %l57 = alloca i1
  %l58 = alloca ptr
  %l59 = alloca %"compiler/source:Span"
  %l62 = alloca { i64, ptr }
  %l64 = alloca %"compiler/msgs:Msg"
  %l65 = alloca i64
  %l67 = alloca i32
  %l70 = alloca i1
  %l71 = alloca i1
  %l72 = alloca ptr
  %l73 = alloca i32
  %l75 = alloca { i64, ptr }
  %l76 = alloca i64
  %l79 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l82 = alloca i64
  %l84 = alloca i64
  %l85 = alloca { i64, ptr }
  %l90 = alloca ptr
  %l93 = alloca i32
  %l96 = alloca i1
  %l97 = alloca ptr
  %l98 = alloca %"compiler/source:Span"
  %l99 = alloca %"compiler/source:Span"
  %l100 = alloca i32
  %l107 = alloca ptr
  %l109 = alloca ptr
  %l113 = alloca ptr
  %l114 = alloca %"compiler/source:Span"
  %l117 = alloca { i64, ptr }
  %l122 = alloca %"compiler/msgs:Msg"
  %l123 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %t227 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i32 %a3, ptr %l3
  store ptr %a4, ptr %l4
  store %"compiler/source:Span" %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l2, !range !{i32 0, i32 96}
  %t3 = trunc i64 64 to i32
  %t4 = icmp eq i32 %t1, %t3
  store i1 %t4, ptr %l6, !tbaa !21
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d57, i32 0, i32 1) }, ptr %l12, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t6, ptr %l13, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t7, 0
  store i64 %t8, ptr %l14, !tbaa !24
  %t9 = load i64, ptr %l14, !tbaa !24
  %t10 = mul i64 %t9, 1
  %t11 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t10)
  %t12 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  store { i64, ptr } %t13, ptr %l15, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = load i64, ptr %l14, !tbaa !24
  %t19 = mul i64 %t18, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t15, ptr %t17, i64 %t19, i1 false)
  %t20 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t20, ptr %l7, !tbaa !27
  %t21 = load ptr, ptr %l4, !tbaa !29
  %t23 = icmp eq ptr %t21, null
  br i1 %t23, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i32, ptr %l3, !tbaa !23
  %t29 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t25, i32 %t26)
  store i1 %t29, ptr %l20
  br label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s6
  %t30 = load i32, ptr %l2, !range !{i32 0, i32 96}
  %t32 = call i32 @compiler_2fcheck_2ecompoundOp(i32 %t30)
  store i32 %t32, ptr %l67
  br label %bb37
bb3:
  %t33 = load i1, ptr %l20, !tbaa !21
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t34 = load i1, ptr %l6, !tbaa !21
  br i1 %t34, label %bb6, label %bb7
bb5:
  br label %bb29
bb6:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d58, i32 0, i32 1) }, ptr %l23, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t36, ptr %l22, !tbaa !27
  br label %bb8
bb7:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d59, i32 0, i32 1) }, ptr %l25, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t38, ptr %l22, !tbaa !27
  br label %bb8
bb8:
  %t40 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 0
  %t42 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 0
  store i64 %t43, ptr %l28, !tbaa !24
  %t45 = load i64, ptr %l28, !tbaa !24
  %t46 = icmp eq i64 %t41, %t45
  br i1 %t46, label %bb9, label %bb10
bb9:
  %t48 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = load i64, ptr %l28, !tbaa !24
  %t53 = mul i64 %t52, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t49, ptr %t51, i64 %t53, i1 false)
  br label %bb11
bb10:
  %t54 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t54, ptr %l7, !tbaa !27
  br label %bb11
bb11:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load i32, ptr %l3, !tbaa !23
  %t57 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t61 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s0, ptr %t55, i32 %t56, { i64, ptr } %t57, i64 0)
  store i64 %t61, ptr %l33
  br label %bb12
bb12:
  %t62 = load i64, ptr %l33, !tbaa !24
  %t63 = icmp slt i64 %t62, 0
  br i1 %t63, label %bb13, label %bb14
bb13:
  %t65 = load i1, ptr %l6, !tbaa !21
  br i1 %t65, label %bb15, label %bb16
bb14:
  br label %bb28
bb15:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d60, i32 0, i32 1) }, ptr %l37, !tbaa !27
  %t67 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t67, ptr %l36, !tbaa !27
  br label %bb17
bb16:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d61, i32 0, i32 1) }, ptr %l39, !tbaa !27
  %t69 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t69, ptr %l36, !tbaa !27
  br label %bb17
bb17:
  %t71 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t71, 0
  %t73 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t74 = extractvalue { i64, ptr } %t73, 0
  store i64 %t74, ptr %l42, !tbaa !24
  %t76 = load i64, ptr %l42, !tbaa !24
  %t77 = icmp eq i64 %t72, %t76
  br i1 %t77, label %bb18, label %bb19
bb18:
  %t79 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = load i64, ptr %l42, !tbaa !24
  %t84 = mul i64 %t83, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t80, ptr %t82, i64 %t84, i1 false)
  br label %bb20
bb19:
  %t85 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t85, ptr %l7, !tbaa !27
  br label %bb20
bb20:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load i32, ptr %l3, !tbaa !23
  %t88 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t92 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s0, ptr %t86, i32 %t87, { i64, ptr } %t88, i64 1)
  store i64 %t92, ptr %l47
  br label %bb21
bb21:
  %t93 = load i64, ptr %l47, !tbaa !24
  %t94 = icmp slt i64 %t93, 0
  br i1 %t94, label %bb22, label %bb23
bb22:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d62, i32 0, i32 1) }, ptr %l49, !tbaa !27
  %t96 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t96, ptr %l50, !tbaa !27
  %t97 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t97, 0
  %t99 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t99, 0
  store i64 %t100, ptr %l52, !tbaa !24
  %t102 = load i64, ptr %l52, !tbaa !24
  %t103 = icmp eq i64 %t98, %t102
  br i1 %t103, label %bb24, label %bb25
bb23:
  br label %bb27
bb24:
  %t105 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !27
  %t107 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = load i64, ptr %l52, !tbaa !24
  %t110 = mul i64 %t109, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t106, ptr %t108, i64 %t110, i1 false)
  br label %bb26
bb25:
  %t111 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t111, 0
  store i64 %t112, ptr %l54, !tbaa !24
  %t113 = load i64, ptr %l54, !tbaa !24
  %t114 = mul i64 %t113, 1
  %t115 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t114)
  %t116 = insertvalue { i64, ptr } undef, i64 %t113, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr %t115, 1
  store { i64, ptr } %t117, ptr %l55, !tbaa !27
  %t118 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !27
  %t120 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !27
  %t122 = load i64, ptr %l54, !tbaa !24
  %t123 = mul i64 %t122, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t119, ptr %t121, i64 %t123, i1 false)
  %t124 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t124, ptr %l7, !tbaa !27
  br label %bb26
bb26:
  br label %bb27
bb27:
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t125 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t127 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s1, { i64, ptr } %t125, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d63, i32 0, i32 1) })
  store i1 %t127, ptr %l57
  br label %bb30
bb30:
  %t128 = load i1, ptr %l57, !tbaa !21
  br i1 %t128, label %bb31, label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s5
  %t129 = load ptr, ptr %l0, !tbaa !29
  store ptr %t129, ptr %l58, !tbaa !29
  %t130 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t130, ptr %l59
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load i32, ptr %l3, !tbaa !23
  %t135 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s5, ptr %t131, i32 %t132)
  store { i64, ptr } %t135, ptr %l62
  br label %bb33
bb32:
  br label %bb36
bb33:
  %t136 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t136, 0
  %t138 = extractvalue { i64, ptr } %t136, 1
  %t139 = mul i64 %t137, 1
  %t140 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t139)
  call void @llvm.memcpy.p0.p0.i64(ptr %t140, ptr %t138, i64 %t139, i1 false)
  %t141 = insertvalue { i64, ptr } undef, i64 %t137, 0
  %t142 = insertvalue { i64, ptr } %t141, ptr %t140, 1
  %t144 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eStepNotNumber(ptr %s5, ptr %s5, { i64, ptr } %t142)
  store %"compiler/msgs:Msg" %t144, ptr %l64
  br label %bb34
bb34:
  %t145 = load ptr, ptr %l58, !tbaa !29
  %t146 = load %"compiler/source:Span", ptr %l59
  %t147 = load %"compiler/msgs:Msg", ptr %l64
  %t148 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t145, %"compiler/source:Span" %t146, %"compiler/msgs:Msg" %t147)
  store i64 %t148, ptr %l65
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb36:
  call void @__olang_scope_close(ptr %s1)
  br label %bb62
bb37:
  %t149 = load i32, ptr %l67, !range !{i32 0, i32 96}
  store i32 %t149, ptr %l8
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t151 = load i32, ptr %l3, !tbaa !23
  %t154 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t150, i32 %t151)
  store i1 %t154, ptr %l70
  br label %bb38
bb38:
  %t155 = load i1, ptr %l70, !tbaa !21
  br i1 %t155, label %bb39, label %bb40
bb39:
  %t156 = load ptr, ptr %l0, !tbaa !29
  store ptr %t156, ptr %l72, !tbaa !29
  %t157 = load i32, ptr %l3, !tbaa !23
  store i32 %t157, ptr %l73, !tbaa !23
  %t158 = load i32, ptr %l8, !range !{i32 0, i32 96}
  %t160 = call { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %s6, i32 %t158)
  store { i64, ptr } %t160, ptr %l75
  br label %bb41
bb40:
  store i1 false, ptr %l71, !tbaa !21
  br label %bb43
bb41:
  %t161 = load ptr, ptr %l72, !tbaa !29
  %t162 = load i32, ptr %l73, !tbaa !23
  %t163 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t164 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s6, ptr %t161, i32 %t162, { i64, ptr } %t163, i64 1)
  store i64 %t164, ptr %l76
  br label %bb42
bb42:
  %t165 = load i64, ptr %l76, !tbaa !24
  %t166 = icmp sge i64 %t165, 0
  store i1 %t166, ptr %l71, !tbaa !21
  br label %bb43
bb43:
  %t168 = load i1, ptr %l71, !tbaa !21
  br i1 %t168, label %bb44, label %bb45
bb44:
  %t169 = load i32, ptr %l8, !range !{i32 0, i32 96}
  %t171 = call { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %s0, i32 %t169)
  store { i64, ptr } %t171, ptr %l79
  br label %bb46
bb45:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t173 = load ptr, ptr %l4, !tbaa !29
  %t175 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t179 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t172, ptr %t173, i32 %t175)
  store ptr %t179, ptr %l90
  br label %bb50
bb46:
  %t180 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t180, ptr %l80, !tbaa !27
  %t181 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t182 = extractvalue { i64, ptr } %t181, 0
  %t183 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t184 = extractvalue { i64, ptr } %t183, 0
  store i64 %t184, ptr %l82, !tbaa !24
  %t186 = load i64, ptr %l82, !tbaa !24
  %t187 = icmp eq i64 %t182, %t186
  br i1 %t187, label %bb47, label %bb48
bb47:
  %t189 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !27
  %t191 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t192 = load ptr, ptr %t191, !tbaa !27
  %t193 = load i64, ptr %l82, !tbaa !24
  %t194 = mul i64 %t193, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t190, ptr %t192, i64 %t194, i1 false)
  br label %bb49
bb48:
  %t195 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t196 = extractvalue { i64, ptr } %t195, 0
  store i64 %t196, ptr %l84, !tbaa !24
  %t197 = load i64, ptr %l84, !tbaa !24
  %t198 = mul i64 %t197, 1
  %t199 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t198)
  %t200 = insertvalue { i64, ptr } undef, i64 %t197, 0
  %t201 = insertvalue { i64, ptr } %t200, ptr %t199, 1
  store { i64, ptr } %t201, ptr %l85, !tbaa !27
  %t202 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t203 = load ptr, ptr %t202, !tbaa !27
  %t204 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t205 = load ptr, ptr %t204, !tbaa !27
  %t206 = load i64, ptr %l84, !tbaa !24
  %t207 = mul i64 %t206, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t203, ptr %t205, i64 %t207, i1 false)
  %t208 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t208, ptr %l7, !tbaa !27
  br label %bb49
bb49:
  br label %bb61
bb50:
  %t209 = load ptr, ptr %l90, !tbaa !29
  store ptr %t209, ptr %l9, !tbaa !29
  %t210 = load ptr, ptr %l9, !tbaa !29
  %t213 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t210)
  store i32 %t213, ptr %l93
  br label %bb51
bb51:
  %t214 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t215 = load i32, ptr %l93, !tbaa !23
  %t217 = icmp ne i32 %t215, %t214
  br i1 %t217, label %bb52, label %bb53
bb52:
  %t219 = load ptr, ptr %l0, !tbaa !29
  store ptr %t219, ptr %l97, !tbaa !29
  %t220 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t220, ptr %l98
  %t221 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t221, ptr %l99
  %t222 = load i32, ptr %l8, !range !{i32 0, i32 96}
  store i32 %t222, ptr %l100
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t224 = load %"compiler/source:Span", ptr %l1
  %t225 = load %"compiler/source:Span", ptr %l1
  %t226 = load i32, ptr %l3, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t227
  %t228 = getelementptr { i64, [4 x i64] }, ptr %t227, i32 0, i32 0
  store i64 7, ptr %t228
  %t230 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t225, 0
  %t232 = insertvalue { %"compiler/source:Span", i32 } %t230, i32 %t226, 1
  %t233 = getelementptr { i64, [4 x i64] }, ptr %t227, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t232, ptr %t233
  %t234 = load { i64, [4 x i64] }, ptr %t227
  %t236 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t234, ptr %t236
  %t240 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t223, %"compiler/source:Span" %t224, ptr %t236)
  store ptr %t240, ptr %l107
  br label %bb54
bb53:
  store i1 false, ptr %l96, !tbaa !21
  br label %bb56
bb54:
  %t241 = load ptr, ptr %l9, !tbaa !29
  %t242 = load ptr, ptr %l97, !tbaa !29
  %t243 = load %"compiler/source:Span", ptr %l98
  %t244 = load %"compiler/source:Span", ptr %l99
  %t245 = load i32, ptr %l100, !range !{i32 0, i32 96}
  %t246 = load ptr, ptr %l107, !tbaa !29
  %t248 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperatorCall(ptr %v0, ptr %t242, %"compiler/source:Span" %t243, %"compiler/source:Span" %t244, i32 %t245, ptr %t246, ptr %t241)
  store ptr %t248, ptr %l109
  br label %bb55
bb55:
  %t249 = load ptr, ptr %l109, !tbaa !29
  %t250 = icmp eq ptr %t249, null
  store i1 %t250, ptr %l96, !tbaa !21
  br label %bb56
bb56:
  %t252 = load i1, ptr %l96, !tbaa !21
  br i1 %t252, label %bb57, label %bb58
bb57:
  store %olang.scope zeroinitializer, ptr %s9
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t254 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s9, ptr %t253, %"compiler/source:Span" %t254, { i64, ptr } { i64 58, ptr getelementptr inbounds (<{ i64, [58 x i8] }>, ptr @.d64, i32 0, i32 1) })
  br label %bb59
bb58:
  br label %bb60
bb59:
  call void @__olang_scope_close(ptr %s9)
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb61:
  call void @__olang_scope_close(ptr %s6)
  br label %bb62
bb62:
  %t257 = load ptr, ptr %l0, !tbaa !29
  store ptr %t257, ptr %l113, !tbaa !29
  %t258 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t258, ptr %l114
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t260 = load i32, ptr %l3, !tbaa !23
  %t263 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t259, i32 %t260)
  store { i64, ptr } %t263, ptr %l117
  br label %bb63
bb63:
  %t264 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t265 = extractvalue { i64, ptr } %t264, 0
  %t266 = extractvalue { i64, ptr } %t264, 1
  %t267 = mul i64 %t265, 1
  %t268 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t267)
  call void @llvm.memcpy.p0.p0.i64(ptr %t268, ptr %t266, i64 %t267, i1 false)
  %t269 = insertvalue { i64, ptr } undef, i64 %t265, 0
  %t270 = insertvalue { i64, ptr } %t269, ptr %t268, 1
  %t271 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t272 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d65, i32 0, i32 1) }, 1
  %t273 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d65, i32 0, i32 1) }, 0
  %t275 = extractvalue { i64, ptr } %t271, 1
  %t276 = extractvalue { i64, ptr } %t271, 0
  %t277 = add i64 %t273, %t276
  %t278 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d65, i32 0, i32 1) }, 1
  %t279 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d65, i32 0, i32 1) }, 0
  %t280 = add i64 %t277, %t279
  %t281 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t280)
  call void @olang_textcopy(ptr %t281, ptr %t272, i64 %t273)
  %t282 = getelementptr i8, ptr %t281, i64 %t273
  call void @olang_textcopy(ptr %t282, ptr %t275, i64 %t276)
  %t283 = getelementptr i8, ptr %t282, i64 %t276
  call void @olang_textcopy(ptr %t283, ptr %t278, i64 %t279)
  %t284 = insertvalue { i64, ptr } undef, i64 %t280, 0
  %t285 = insertvalue { i64, ptr } %t284, ptr %t281, 1
  %t287 = extractvalue { i64, ptr } %t285, 0
  %t288 = extractvalue { i64, ptr } %t285, 1
  %t289 = mul i64 %t287, 1
  %t290 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t289)
  call void @llvm.memcpy.p0.p0.i64(ptr %t290, ptr %t288, i64 %t289, i1 false)
  %t291 = insertvalue { i64, ptr } undef, i64 %t287, 0
  %t292 = insertvalue { i64, ptr } %t291, ptr %t290, 1
  %t295 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eWriteThroughAtOperator(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t270, { i64, ptr } %t292)
  store %"compiler/msgs:Msg" %t295, ptr %l122
  br label %bb64
bb64:
  %t296 = load ptr, ptr %l113, !tbaa !29
  %t297 = load %"compiler/source:Span", ptr %l114
  %t298 = load %"compiler/msgs:Msg", ptr %l122
  %t299 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s0, ptr %t296, %"compiler/source:Span" %t297, %"compiler/msgs:Msg" %t298)
  store i64 %t299, ptr %l123
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2ecompoundOp(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i32
  %rv = alloca i32
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !range !{i32 0, i32 96}
  %t3 = trunc i64 64 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store i32 52, ptr %l1
  br label %bb45
bb4:
  %t7 = load i32, ptr %l0, !range !{i32 0, i32 96}
  %t9 = trunc i64 65 to i32
  %t10 = icmp eq i32 %t7, %t9
  br i1 %t10, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i32 53, ptr %l1
  br label %bb45
bb8:
  %t13 = load i32, ptr %l0, !range !{i32 0, i32 96}
  %t15 = trunc i64 66 to i32
  %t16 = icmp eq i32 %t13, %t15
  br i1 %t16, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i32 54, ptr %l1
  br label %bb45
bb12:
  %t19 = load i32, ptr %l0, !range !{i32 0, i32 96}
  %t21 = trunc i64 67 to i32
  %t22 = icmp eq i32 %t19, %t21
  br i1 %t22, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store i32 55, ptr %l1
  br label %bb45
bb16:
  %t25 = load i32, ptr %l0, !range !{i32 0, i32 96}
  %t27 = trunc i64 68 to i32
  %t28 = icmp eq i32 %t25, %t27
  br i1 %t28, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i32 56, ptr %l1
  br label %bb45
bb20:
  %t31 = load i32, ptr %l0, !range !{i32 0, i32 96}
  %t33 = trunc i64 69 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store i32 88, ptr %l1
  br label %bb45
bb24:
  %t37 = load i32, ptr %l0, !range !{i32 0, i32 96}
  %t39 = trunc i64 70 to i32
  %t40 = icmp eq i32 %t37, %t39
  br i1 %t40, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  store i32 89, ptr %l1
  br label %bb45
bb28:
  %t43 = load i32, ptr %l0, !range !{i32 0, i32 96}
  %t45 = trunc i64 71 to i32
  %t46 = icmp eq i32 %t43, %t45
  br i1 %t46, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store i32 83, ptr %l1
  br label %bb45
bb32:
  %t49 = load i32, ptr %l0, !range !{i32 0, i32 96}
  %t51 = trunc i64 72 to i32
  %t52 = icmp eq i32 %t49, %t51
  br i1 %t52, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  store i32 84, ptr %l1
  br label %bb45
bb36:
  %t55 = load i32, ptr %l0, !range !{i32 0, i32 96}
  %t57 = trunc i64 73 to i32
  %t58 = icmp eq i32 %t55, %t57
  br i1 %t58, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  store i32 85, ptr %l1
  br label %bb45
bb40:
  br i1 true, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  store i32 0, ptr %l1
  br label %bb45
bb44:
  call void @__olang_check_failed(ptr @olang_loc_20f9f67d26588f89_c77aed4cf9eaedd5)
  unreachable
bb45:
  %t62 = load i32, ptr %l1, !range !{i32 0, i32 96}
  store i32 %t62, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fcheck_2edirectSet(ptr %v0, { i64, ptr } %a0, i32 %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l18 = alloca i1
  %l24 = alloca i32
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb21
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l5, !tbaa !29
  %t23 = load ptr, ptr %l5, !tbaa !29
  store ptr %t23, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t24 = load ptr, ptr %l17, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb5, label %bb6
bb5:
  %t27 = load ptr, ptr %l17, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 11}
  %t30 = icmp eq i64 %t28, 8
  store i1 %t30, ptr %l18, !tbaa !21
  br label %bb6
bb6:
  %t31 = load i1, ptr %l18, !tbaa !21
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t32 = load ptr, ptr %l5, !tbaa !29
  %t34 = getelementptr { i64, [6 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t34, i32 0, i32 1
  %t36 = load ptr, ptr %t35
  store ptr %t36, ptr %l6, !tbaa !29
  br label %bb9
bb8:
  br label %bb14
bb9:
  %t38 = load ptr, ptr %l6, !tbaa !29
  %t40 = call i32 @compiler_2fcheck_2esetName(ptr %v0, ptr %t38)
  store i32 %t40, ptr %l24
  br label %bb10
bb10:
  %t42 = load i32, ptr %l24, !tbaa !23
  %t44 = icmp eq i32 %t42, %a1
  br i1 %t44, label %bb11, label %bb12
bb11:
  store i1 true, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  br label %bb19
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_19f4e92ae3000dc_edc59080f5379130)
  unreachable
bb19:
  br label %bb20
bb20:
  %t47 = load i64, ptr %l3, !tbaa !24
  %t49 = add i64 %t47, 1
  store i64 %t49, ptr %l3, !tbaa !24
  br label %bb1
bb21:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2eintOnly(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l3 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %l15 = alloca i1
  %rv = alloca i1
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !range !{i32 0, i32 96}
  %t3 = trunc i64 83 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  %t6 = load i32, ptr %l0, !range !{i32 0, i32 96}
  %t8 = trunc i64 84 to i32
  %t9 = icmp eq i32 %t6, %t8
  store i1 %t9, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l3, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb6
bb5:
  %t12 = load i32, ptr %l0, !range !{i32 0, i32 96}
  %t14 = trunc i64 85 to i32
  %t15 = icmp eq i32 %t12, %t14
  store i1 %t15, ptr %l6, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l6, !tbaa !21
  br i1 %t17, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb9
bb8:
  %t18 = load i32, ptr %l0, !range !{i32 0, i32 96}
  %t20 = trunc i64 56 to i32
  %t21 = icmp eq i32 %t18, %t20
  store i1 %t21, ptr %l9, !tbaa !21
  br label %bb9
bb9:
  %t23 = load i1, ptr %l9, !tbaa !21
  br i1 %t23, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb12
bb11:
  %t24 = load i32, ptr %l0, !range !{i32 0, i32 96}
  %t26 = trunc i64 88 to i32
  %t27 = icmp eq i32 %t24, %t26
  store i1 %t27, ptr %l12, !tbaa !21
  br label %bb12
bb12:
  %t29 = load i1, ptr %l12, !tbaa !21
  br i1 %t29, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb15
bb14:
  %t30 = load i32, ptr %l0, !range !{i32 0, i32 96}
  %t32 = trunc i64 89 to i32
  %t33 = icmp eq i32 %t30, %t32
  store i1 %t33, ptr %l15, !tbaa !21
  br label %bb15
bb15:
  %t35 = load i1, ptr %l15, !tbaa !21
  store i1 %t35, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2eisTrue(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i1
  %l14 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l1, !tbaa !23
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t18, i32 0, i32 2
  %t20 = load i64, ptr %t19
  store i64 %t20, ptr %l2, !tbaa !24
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t22 = load i32, ptr %l1, !tbaa !23
  %t23 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t26 = icmp eq i32 %t22, %t23
  br i1 %t26, label %bb6, label %bb7
bb6:
  %t28 = load i64, ptr %l2, !tbaa !24
  %t30 = icmp eq i64 %t28, 1
  store i1 %t30, ptr %l14, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t32 = load i1, ptr %l14, !tbaa !21
  store i1 %t32, ptr %rv
  br label %ret
bb9:
  br i1 true, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  store i1 false, ptr %rv
  br label %ret
bb13:
  call void @__olang_check_failed(ptr @olang_loc_a08a248bd178667f_2aaba0f11d7155db)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2eisWild(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l1, !tbaa !29
  store i1 false, ptr %l2, !tbaa !21
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 6}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l2, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l2, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %rv
  br label %ret
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 false, ptr %rv
  br label %ret
bb10:
  call void @__olang_check_failed(ptr @olang_loc_4777492a424db66f_87dc2d494f6ca16b)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %rv
  br label %ret
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store ptr null, ptr %rv
  br label %ret
bb10:
  call void @__olang_check_failed(ptr @olang_loc_8d3b159055c7af2c_5997e8ea93888888)
  unreachable
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"compiler/check:b5aWalk" @compiler_2fcheck_3ab5aWalk_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l3 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l11 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l13 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/check:b5aWalk"
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a0, ptr %l1, !tbaa !24
  %t3 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %l2
  %t5 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, ptr %l11
  br label %bb2
bb2:
  %t6 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t6, ptr %l3
  %t7 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t7, ptr %l12
  br label %bb3
bb3:
  %t8 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l12
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %l4
  %t9 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t9, ptr %l13
  br label %bb4
bb4:
  %t10 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t10, ptr %l5
  %t11 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t11, ptr %l14
  br label %bb5
bb5:
  %t12 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l14
  %t13 = load i64, ptr %l1, !tbaa !24
  %t14 = insertvalue %"compiler/check:b5aWalk" undef, i64 %t13, 0
  %t15 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l2
  %t16 = insertvalue %"compiler/check:b5aWalk" %t14, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, 1
  %t17 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l3
  %t18 = insertvalue %"compiler/check:b5aWalk" %t16, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t17, 2
  %t19 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l4
  %t20 = insertvalue %"compiler/check:b5aWalk" %t18, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t19, 3
  %t21 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l5
  %t22 = insertvalue %"compiler/check:b5aWalk" %t20, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t21, 4
  %t24 = insertvalue %"compiler/check:b5aWalk" %t22, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, 5
  %t26 = insertvalue %"compiler/check:b5aWalk" %t24, i1 false, 6
  %t28 = insertvalue %"compiler/check:b5aWalk" %t26, i1 false, 7
  store %"compiler/check:b5aWalk" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:b5aWalk", ptr %rv
  ret %"compiler/check:b5aWalk" %rr
}

define dso_local %"compiler/check:factsMark" @compiler_2fcheck_3afactsMark_2ector(ptr %v0, i64 %a0, i64 %a1, i64 %a2) #0 {
entry:
  %rv = alloca %"compiler/check:factsMark"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/check:factsMark" undef, i64 %a0, 0
  %t10 = insertvalue %"compiler/check:factsMark" %t8, i64 %a1, 1
  %t12 = insertvalue %"compiler/check:factsMark" %t10, i64 %a2, 2
  store %"compiler/check:factsMark" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:factsMark", ptr %rv
  ret %"compiler/check:factsMark" %rr
}

declare void @__olang_check_failed(ptr) cold noreturn
@__olang_empty_array = external constant [16 x i64]
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
declare void @__olang_ert_req_clear()
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d0 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"U8" }>, align 8
@.d1 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"I8" }>, align 8
@.d2 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"'==' between null and a value" }>, align 8
@.d3 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"'=='" }>, align 8
@.d4 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"eq" }>, align 8
@.d5 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"Eq" }>, align 8
@.d6 = private constant <{ i64, [54 x i8] }> <{ i64 0, [54 x i8] c"'==' on an array or enum whose parts declare Eq (E10a)" }>, align 8
@.d7 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"nothing" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d8 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d9 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"Functions" }>, align 8
@.d10 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"std/prelude/iterator" }>, align 8
@.d11 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"Exhausted" }>, align 8
@.d12 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"an unreachable's" }>, align 8
@.d13 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"an assert's" }>, align 8
@.d14 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Clone" }>, align 8
@.d15 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d16 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d17 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Slice" }>, align 8
@.d18 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Slice" }>, align 8
@.d19 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"'x[lo:hi]'" }>, align 8
@.d20 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Len" }>, align 8
@.d21 = private constant <{ i64, [47 x i8] }> <{ i64 0, [47 x i8] c"a slice with no end of a type with no Len (E31)" }>, align 8
@.d22 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d23 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d24 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d25 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d26 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"std/" }>, align 8
@.d27 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d28 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"a statement of this kind" }>, align 8
@.d29 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Str" }>, align 8
@.d30 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"str" }>, align 8
@.d31 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d32 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"std/prelude/reflect" }>, align 8
@.d33 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"TypeKind" }>, align 8
@.d34 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"'not'" }>, align 8
@.d35 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"this prefix operator" }>, align 8
@.d36 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Neg" }>, align 8
@.d37 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"BitNot" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d38 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d39 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"'-'" }>, align 8
@.d40 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"'~'" }>, align 8
@.d41 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"a pun naming no parameter (C4)" }>, align 8
@.d42 = private constant <{ i64, [51 x i8] }> <{ i64 0, [51 x i8] c"a declaration of several names from one value (D8c)" }>, align 8
@.d43 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Next" }>, align 8
@.d44 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"RunFrom" }>, align 8
@.d45 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"'for'" }>, align 8
@.d46 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Next" }>, align 8
@.d47 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"'for'" }>, align 8
@.d48 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Iter" }>, align 8
@.d49 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"'for'" }>, align 8
@.d50 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Next" }>, align 8
@.d51 = private constant <{ i64, [43 x i8] }> <{ i64 0, [43 x i8] c"an Iter() whose result is no iterator (S9c)" }>, align 8
@.d52 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"At" }>, align 8
@.d53 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"'for'" }>, align 8
@.d54 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Len" }>, align 8
@.d55 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Next" }>, align 8
@.d56 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"'for ... in'" }>, align 8
@.d57 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d58 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Inc" }>, align 8
@.d59 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Dec" }>, align 8
@.d60 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Plus" }>, align 8
@.d61 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Minus" }>, align 8
@.d62 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d63 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d64 = private constant <{ i64, [58 x i8] }> <{ i64 0, [58 x i8] c"a compound assignment to what has no operator method (E31)" }>, align 8
@.d65 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
declare i1 @compiler_2fcheck_2eisHexDigit(i8 %a0)
declare i1 @compiler_2fcheck_2eclosedAll(ptr %v0, { i64, ptr } %a0)
@olang_loc_317fdf139725c543_9c9e0109f99156f7 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eTruncate_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %a0)
@olang_loc_ca088269e212954c_d643913a2551dac8 = external constant [0 x i8]
declare %"compiler/typed:Try" @compiler_2ftyped_3aTry_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i1 %a2, i1 %a3, i1 %a4)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aHoldsFn(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eGet_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckNow(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aListId_3e__H9cb5d99387f926677a92c13412f9a8b2(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_H2474e1fc3c93452d7765e4ed18f29a03(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunsettle(ptr %v0, ptr %a0)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyKey(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hf3bb75ba9d3f922b4d327e9d3c1adfb0(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewritable(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCPointerReadOnly(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/msgs:Msg" %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCPointerTemporary(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emustWrite(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i1 %a3)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_7362f3ae74bf0a7_8f389ee36c95dce3 = external constant [0 x i8]
@G_2ecompiler_2ftypes_2eNullT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\0F\00\00\00" }>, align 8
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecVoidRef(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eforeignRef(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplainStruct(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisCStrRef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecNumber(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_27c62905650ee804_ddef4b1ccc198ce0 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0, i64 %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleft(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehasContract(ptr %v0, ptr %a0, i64 %a1)
declare { i32, %"compiler/typed:ContractInfo" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aContractIn_H1fc1bd863e6a60d3e5c2aece55d841d1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectSourceOf(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorWithin(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eRemove_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aContractIn_H044304b59760c17b661e6227d2ca1ac9(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeRel_3e_2eClear_H4f4a348a9dbae49661ad0a6f7cb416a9(ptr %v0, ptr %a0)
@olang_loc_cd06913e2f5eb0d4_3977f9e98d534b08 = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edecls(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
@olang_loc_40b85daad0e541e3_3cdd9f152c967927 = external constant [0 x i8]
@olang_loc_17f9884e4c50a862_1761fccd5f6f3c76 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, ptr %a4, ptr %a5)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eflowsInto(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@G_2ecompiler_2ftypes_2eReadOnly = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeMismatch(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeqMethod(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eProtocolPrivate(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorOncePerLine(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, i32 %a4, { i64, [2 x i64] } %a5)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNonNull(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
@olang_loc_1c2cb6c96b4eaee8_c1b953befa7e1dc = external constant [0 x i8]
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %a0, ptr %a1)
@olang_loc_7ec9c6dbabf95ed5_e8695782fec42ca9 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3, ptr %a4, { i64, ptr } %a5, { i64, ptr } %a6, { i64, ptr } %a7)
declare %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
@olang_loc_bc0d2701821819b6_446831e810be806a = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epartsHaveEq(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epartsEqual(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i32 %a4)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallOf(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, { i64, ptr } %a4)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternValue(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitCtor(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aInit(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aFn(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
@G_2ecompiler_2fcheck_2eLaneMagic = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\01\00\00" }>, align 8
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eLen_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_e09b0660792e8b62_512dd44834885876 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadsConst(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFoldKnown(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i32 %a3)
@olang_loc_660a686bd581f793_38ac5a37531336d7 = external constant [0 x i8]
@olang_loc_21b1f67e4c6ce46b_15219dc677df2bef = external constant [0 x i8]
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ealiasModule(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclaresName(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eListFunctions = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/check:reflList" @compiler_2fcheck_3areflList_2ector(ptr %v0, i1 %a0, i32 %a1, i64 %a2, i64 %a3)
declare %"compiler/check:reflList" @compiler_2fcheck_2enoList()
declare i64 @compiler_2fcheck_2elistIndex(ptr %v0, { i64, ptr } %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescTypeOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2fgeneric_2eDescCase = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eListFields = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eDescFunc = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eListParams = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eListResults = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflType(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eviaTypeVar(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehasCase(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@olang_loc_7b7c458ad09559c8_7a5ff3a2c3d540e4 = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_ddeebe9155436d6a_19ee353760b572b6 = external constant [0 x i8]
@olang_loc_7406e676cee1d8f8_b07044052169e244 = external constant [0 x i8]
declare %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_742d7ba0854a02e0_30f006efbe908ac = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eslotCall(ptr %v0, ptr %a0, i32 %a1, i64 %a2, %"compiler/source:Span" %a3)
@olang_loc_652199a1d15cfac6_f2a0b86627c88902 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallBody(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, i64 %a5, ptr %a6, { i64, ptr } %a7, { i64, ptr } %a8)
@olang_loc_7509e56452997e5b_fb360af196d85db7 = external constant [0 x i8]
@olang_loc_ff81ff8210117a78_6f7a62fdc976c914 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_77a5603a1298311f_4bb819fe8c7bb9e3 = external constant [0 x i8]
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_f66b04275832bdf5_49261566e6ebbc09 = external constant [0 x i8]
@olang_loc_959932aa8b846e4e_2c1999e37dfb1a2 = external constant [0 x i8]
@olang_loc_f94ac378888081c5_5f597351c4418bf9 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, [3 x i64] } %a2, %"compiler/msgs:Msg" %a3)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %a0)
declare %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %a0, i32 %a1)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKey(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hc59daade663458096c0c7696954afd54(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteReadOnlyCopyOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteReadOnlyCopy(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fcheck_2ebangOf(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadMaybeNull(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritable(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunLength(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestructNotName(ptr %v0)
@olang_loc_fb06dcd16342dc9_94e70e479081575d = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ediscardOr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtended(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i32, { i64, ptr } } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflPiece(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
@olang_loc_3ff8b815b8f08888_72cba32f0bfc98b4 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erendered(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esigText(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2)
@olang_loc_db1f2ae5e4bef7a4_1fc823cb35fb1540 = external constant [0 x i8]
@olang_loc_404270212748a64a_94da604f2263273e = external constant [0 x i8]
@olang_loc_e2c214b199db46e1_ccde8582cd2310f5 = external constant [0 x i8]
@olang_loc_2d29d2076870b150_9b91c954cc3aa504 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroBorrowedFrom(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRef(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H48754b4fa56ee3a8c3b855086bca91dc(ptr %v0, ptr %a0)
declare %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H015c7298d54f1d140374736283ef15ae(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroDeep(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, ptr %a3)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i1 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2elowerFirst(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eslicedWritable(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotIndexable(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, %"compiler/source:Span" %a3, { i64, ptr } %a4, i64 %a5, i1 %a6)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %a0, ptr %a1, %"compiler/source:Span" %a2)
@olang_loc_5aa0e1f55b10e6f_53045464d54dc2fb = external constant [0 x i8]
@olang_loc_e4f33d7277813d9a_8adeed4fca551266 = external constant [0 x i8]
@olang_loc_b203c9fbf4c249fb_735051f472c86bf = external constant [0 x i8]
@olang_loc_85a2f2931038d80c_e5a946dd8e187d18 = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esliceLength(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2, ptr %a3)
@olang_loc_2f1aad6b95023edd_c82f5ce971f0d619 = external constant [0 x i8]
declare %"compiler/typed:Slice" @compiler_2ftyped_3aSlice_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i32 %a3)
@olang_loc_7151da8c7014d0c8_6aa5246f01d956ac = external constant [0 x i8]
@olang_loc_16d25af731eb828d_f9df92790de43871 = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprStmt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emulti(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eassign(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, ptr %a4)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etryStore(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, { i64, ptr } %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eifStmt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eloop(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, { i64, ptr } %a3, ptr %a4)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efor3(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eforIn(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edoFor(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2, ptr %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereturnStmt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebecomeStmt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eyieldStmt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ematchStmt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ejump(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectCond(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflDecide(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econd1(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emessage(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushFacts(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2, i64 %a3)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eCondBody(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflText(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eExprBody(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i32 %a3)
declare { { i64, [3 x i64] }, { i64, ptr } } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eTopContext(ptr %v0, ptr %v1, ptr %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperatorOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2fcheck_3aAssertAsk_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, i64 %a0, i64 %a1, %"compiler/source:Span" %a2, %"compiler/source:Span" %a3, i64 %a4, i64 %a5, { i64, ptr } %a6, { i64, [3 x i64] } %a7, { i64, ptr } %a8, i1 %a9, { i64, ptr } %a10, { i64, ptr } %a11)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAssertAsk_3e_2ePush_Hbdaad063a73077b3b5842d615b8c1d82(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eraise(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeferStmt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i1 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eblockOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i32 %a2, %"compiler/source:Span" %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ejoinStmt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espawnStmt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2, ptr %a3)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v0, ptr %a0)
@olang_loc_97a078c1fd6401ad_6b439c1864d584b1 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eLen_H4b13e48b0a317e727dbe35330ad8712a(ptr %v0, ptr %a0)
declare %"compiler/check:nullNarrow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eAt__H22e551fb00043bde3f1f8b2c6007f7cb(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2estmtAssigns(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2eassignsWhole(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/check:nullNarrow" @compiler_2fcheck_3anullNarrow_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i1 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eSet_H93968e49180de2bc6256fae5bb61b442(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/check:nullNarrow" %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eLen_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %a0)
declare %"compiler/check:narrowed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eAt_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/check:narrowed" @compiler_2fcheck_2ecompiler_2fcheck_3anarrowed_2eKilled(%"compiler/check:narrowed" %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eSetAt_Hd90ea4a0afde5538aa0fe5c36a170321(ptr %v0, ptr %a0, i64 %a1, %"compiler/check:narrowed" %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eLen__H3cdfcddd9c493bd8bcefc7b766e0438b(ptr %v0, ptr %a0)
declare %"compiler/check:errNarrow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eAt_3ccompiler_2fcheck_3aerrNarrow_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_f0430e4b284237b0_c6243626a46be64 = external constant [0 x i8]
declare %"compiler/check:errNarrow" @compiler_2fcheck_3aerrNarrow_2ector(ptr %v0, i32 %a0, i32 %a1, i64 %a2, i1 %a3)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eSetA_H34a7475a189e9b126454728216b32261(ptr %v0, ptr %a0, i64 %a1, %"compiler/check:errNarrow" %a2)
@olang_loc_28ca8569d2f90b5d_c88a44871853971 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2ePus_H6cb9d90d121a5c1d081cb085b656665f(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:nullNarrow" %a1)
@olang_loc_8296d6abcbfdbd1e_e4e071066943c4d2 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fscan_2eLiteralBytes(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
@olang_loc_7cf0066f219391e3_f59e2f38f1229917 = external constant [0 x i8]
@olang_loc_93e3a02800d00d4_2c47855b6b12ccf8 = external constant [0 x i8]
@olang_loc_ead499c86a25c3f7_b1128c547d2ccfbb = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eStrReceiverWritable(ptr %v0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
@olang_loc_4caebcac4cec7311_26f3d9a9847d99e5 = external constant [0 x i8]
@olang_loc_35044444f92db59c_e1f3123be845f968 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyCaseType(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyInstance(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3, i32 %a4)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLet(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare %"compiler/typed:Bind" @compiler_2ftyped_3aBind_2ector(ptr %v0, ptr %v1, i32 %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBind_26_3e_2ePush_3ccompiler_2ftyped_3aBind_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eembed(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecomptime(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArray(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneUnary(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eOperandNotBool(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPiece_26_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPiece_26_3e_2ePush_3ccompiler_2ftyped_3aPiece_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPiece_26_3e_2eToArr_H1b89f7fcc263bba924ca04e7c3aa48c7(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare %"compiler/typed:Text" @compiler_2ftyped_3aText_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %v0, i32 %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleUse(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, i64 %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5)
@olang_loc_e153c6abdfe6ecb0_f26e63b1d3597a0c = external constant [0 x i8]
@olang_loc_19db3dca8a9dc05d_2b95ab49e23e3919 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotExtendedOp(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eOperandNotNumber(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisInt(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eOperandNotInt(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrollBind(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrollUnbind(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eComptimeForSource(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrollable(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eComptimeForElem(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %a0, i32 %a1)
declare { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H190b78e3c1eec037529224679e114a85(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunArrayValue(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayNestedByValue(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroNeed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2ePush_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_31b59b203b4a4e3f_1cfff4f24a22d803 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2erefWrittenTop(ptr %v0, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, [2 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emarkOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_35f48b5c7c141c20_d3954a821088874 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emutBefore(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eMutOnInferredLocal(ptr %v0)
@olang_loc_458efae6ce1c735_ac6225d3d907fb69 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eMutOnValueField(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eMutOnLocal(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eFieldHasParamName(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteDeclaredHere(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/check:unsetCand" @compiler_2fcheck_3aunsetCand_2ector(ptr %v0, i64 %a0, i64 %a1, i64 %a2, i1 %a3, i64 %a4, %"compiler/source:Span" %a5, i32 %a6, i1 %a7)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efieldTypeAt(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eStorageOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, ptr %a3)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLengthsOnly(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@olang_loc_f3c73b72e55a8b8e_5460cc7526c67482 = external constant [0 x i8]
@olang_loc_de90e7498c4216b3_b17be322d1a772cf = external constant [0 x i8]
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeWrittenAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efilledNext(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
@olang_loc_36f1ca435b2ee6e4_790f65bce77245f0 = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einferred(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i1 %a3)
@olang_loc_f2aff2ea660e9d99_96029929a029dd45 = external constant [0 x i8]
@olang_loc_91617ece661d0672_429c03ea7d9d989e = external constant [0 x i8]
@olang_loc_60b97769ab73fcb7_dac12c977cbf3c9b = external constant [0 x i8]
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHold(ptr %v0, ptr %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezero(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aValueAsk_3e_2eLen_3ccompiler_2fcheck_3aValueAsk_3e(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2easkValue(ptr %v0, ptr %v1, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4)
@olang_loc_456a500fefc58a98_a2eaf47e24a406ac = external constant [0 x i8]
@olang_loc_3b566e89984acdce_dde06b5f9a89c81a = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %a0)
@G_2ecompiler_2ftypes_2eOwning = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eRoDecl = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroStore(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i64 %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoClearMade(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eSetAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1, %"compiler/typed:Local" %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aunsetCand_3e_2ePush_Hd5bae6439baa110b1f2b8b5b7cdda5ce(ptr %v0, ptr %a0, %"compiler/check:unsetCand" %a1)
@olang_loc_9c28400664f91d75_969ef375bde61da1 = external constant [0 x i8]
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fdiag_3aWhere_3e_2e_Hc07a7e56a24d8f1225398db99ea19a4b(ptr %v0, ptr %a0, i64 %a1, { i64, [3 x i64] } %a2)
@olang_loc_982a334cfac79560_875fefac8daf1dec = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplainScalar(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/check:fixedInit" @compiler_2fcheck_3afixedInit_2ector(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5daf2b89f219287cc2404f0b0e96c809(ptr %v0, ptr %v1, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, %"compiler/check:fixedInit" %a2)
@olang_loc_376d11cdba21927f_511e748ac6a9e8db = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eforRange(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, { i64, ptr } %a3, ptr %a4, i32 %a5)
@olang_loc_1c0ab263f2e4f7dc_3e069dbdc7ae0b68 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroTrack(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecounted(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3, i64 %a4, i64 %a5, i32 %a6, i64 %a7, i64 %a8, ptr %a9, i32 %a10)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecomprOpen(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkIter(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i64 %a4, ptr %a5, i32 %a6)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotIterable(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eiterShaped(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkRuns(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i64 %a4, ptr %a5, i32 %a6)
@olang_loc_139af6e2a2dcda96_1438f6a9e620193a = external constant [0 x i8]
@olang_loc_a734531b29123b5_def2307fb88201b9 = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkIndexed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i64 %a4, i64 %a5, ptr %a6, i32 %a7)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecaseDecl(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eStepNotNumber(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %v0, i32 %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperatorCall(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, ptr %a5)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eWriteThroughAtOperator(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_20f9f67d26588f89_c77aed4cf9eaedd5 = external constant [0 x i8]
declare i32 @compiler_2fcheck_2esetName(ptr %v0, ptr %a0)
@olang_loc_19f4e92ae3000dc_edc59080f5379130 = external constant [0 x i8]
@olang_loc_a08a248bd178667f_2aaba0f11d7155db = external constant [0 x i8]
@olang_loc_4777492a424db66f_87dc2d494f6ca16b = external constant [0 x i8]
@olang_loc_8d3b159055c7af2c_5997e8ea93888888 = external constant [0 x i8]
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
