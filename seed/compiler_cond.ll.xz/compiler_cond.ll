; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/cond:Decision" = type { i32, i1 }
%"compiler/cond:Value" = type { i32, i64, double, i64, i64, i1, i1 }
%"compiler/cond:Consts" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/diagmsg:Msg" = type { i32, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/cond:Eval" = type { { i64, ptr }, ptr, ptr, ptr, i1, i1, i1, %"compiler/source:Span", %"compiler/diagmsg:Msg", i64, i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/ast:Chain" = type { { i64, ptr }, { i64, ptr } }
%"compiler/cond:Scope" = type { i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/cond:Global" = type { { i64, ptr }, %"compiler/source:Span", i1, { i64, ptr }, ptr, i1 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
@G_2ecompiler_2fcond_2eLiteralIntBits = constant <{ [8 x i8] }> <{ [8 x i8] c"\40\00\00\00\00\00\00\00" }>, align 8
define dso_local %"compiler/cond:Decision" @compiler_2fcond_2eDecision_2eundecided(i32 %a0) #0 {
entry:
  %l2 = alloca %"compiler/cond:Decision"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/cond:Decision"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call %"compiler/cond:Decision" @compiler_2fcond_3aDecision_2ector(ptr %s0, i32 %a0, i1 false)
  store %"compiler/cond:Decision" %t3, ptr %l2
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t4 = load %"compiler/cond:Decision", ptr %l2
  store %"compiler/cond:Decision" %t4, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cond:Decision", ptr %rv
  ret %"compiler/cond:Decision" %rr
}

define dso_local %"compiler/cond:Value" @compiler_2fcond_2eValue_2ebool(i1 %a0) #0 {
entry:
  %l1 = alloca i32
  %l3 = alloca i64
  %l4 = alloca %"compiler/cond:Value"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/cond:Value"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 1, ptr %l1
  br i1 %a0, label %bb1, label %bb2
bb1:
  store i64 1, ptr %l3, !tbaa !24
  br label %bb3
bb2:
  store i64 0, ptr %l3, !tbaa !24
  br label %bb3
bb3:
  %t3 = load i32, ptr %l1, !range !{i32 0, i32 5}
  %t4 = load i64, ptr %l3, !tbaa !24
  %t5 = call %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %s0, i32 %t3, i64 %t4, double 0x0000000000000000, i64 0, i64 0, i1 false, i1 false)
  store %"compiler/cond:Value" %t5, ptr %l4
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t6 = load %"compiler/cond:Value", ptr %l4
  store %"compiler/cond:Value" %t6, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cond:Value", ptr %rv
  ret %"compiler/cond:Value" %rr
}

define dso_local %"compiler/cond:Value" @compiler_2fcond_2eValue_2enone() #0 {
entry:
  %l1 = alloca %"compiler/cond:Value"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/cond:Value"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t2 = call %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %s0, i32 0, i64 0, double 0x0000000000000000, i64 0, i64 0, i1 false, i1 false)
  store %"compiler/cond:Value" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/cond:Value", ptr %l1
  store %"compiler/cond:Value" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cond:Value", ptr %rv
  ret %"compiler/cond:Value" %rr
}

define dso_local %"compiler/cond:Value" @compiler_2fcond_2eValue_2eshape(i32 %a0, i64 %a1, i1 %a2) #0 {
entry:
  %l6 = alloca %"compiler/cond:Value"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/cond:Value"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t7 = call %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %s0, i32 %a0, i64 0, double 0x0000000000000000, i64 0, i64 %a1, i1 %a2, i1 false)
  store %"compiler/cond:Value" %t7, ptr %l6
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t8 = load %"compiler/cond:Value", ptr %l6
  store %"compiler/cond:Value" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cond:Value", ptr %rv
  ret %"compiler/cond:Value" %rr
}

define dso_local { i32, double } @compiler_2fcond_2easFloat(%"compiler/cond:Value" %a0) #0 {
entry:
  %l0 = alloca %"compiler/cond:Value"
  %l3 = alloca i1
  %l6 = alloca i1
  %rv = alloca { i32, double }
  store %"compiler/cond:Value" %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/cond:Value", ptr %l0, i32 0, i32 4
  %t2 = load i64, ptr %t1, !tbaa !24
  %t4 = icmp ne i64 %t2, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  %t6 = getelementptr %"compiler/cond:Value", ptr %l0, i32 0, i32 1
  %t7 = load i64, ptr %t6, !tbaa !24
  %t9 = icmp sgt i64 %t7, 9007199254740992
  store i1 %t9, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l3, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb6
bb5:
  %t12 = getelementptr %"compiler/cond:Value", ptr %l0, i32 0, i32 1
  %t13 = load i64, ptr %t12, !tbaa !24
  %t15 = icmp slt i64 %t13, -9007199254740992
  store i1 %t15, ptr %l6, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l6, !tbaa !21
  br i1 %t17, label %bb7, label %bb8
bb7:
  %t19 = insertvalue { i32, double } zeroinitializer, i32 65536, 0
  store { i32, double } %t19, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t20 = getelementptr %"compiler/cond:Value", ptr %l0, i32 0, i32 1
  %t21 = load i64, ptr %t20, !tbaa !24
  %t23 = sitofp i64 %t21 to double
  %t25 = insertvalue { i32, double } zeroinitializer, double %t23, 1
  store { i32, double } %t25, ptr %rv
  br label %ret
ret:
  %rr = load { i32, double }, ptr %rv
  ret { i32, double } %rr
}

define dso_local void @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eBuiltins(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, i64 %a4, i64 %a5, i1 %a6, i1 %a7, i1 %a8, i64 %a9) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i32
  %l14 = alloca i64
  %l15 = alloca %"compiler/cond:Value"
  %l17 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i32
  %l23 = alloca i64
  %l24 = alloca %"compiler/cond:Value"
  %l26 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca i32
  %l32 = alloca i64
  %l33 = alloca %"compiler/cond:Value"
  %l35 = alloca i1
  %l37 = alloca ptr
  %l41 = alloca %"compiler/cond:Value"
  %l44 = alloca ptr
  %l47 = alloca %"compiler/cond:Value"
  %l50 = alloca ptr
  %l53 = alloca %"compiler/cond:Value"
  %l56 = alloca ptr
  %l58 = alloca %"compiler/cond:Value"
  %l59 = alloca ptr
  %l61 = alloca %"compiler/cond:Value"
  %l62 = alloca ptr
  %l64 = alloca %"compiler/cond:Value"
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store i64 %a4, ptr %l4
  store i64 %a5, ptr %l5
  store i64 %a9, ptr %l9
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l10, !tbaa !29
  store i32 4, ptr %l11
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t6 = call i64 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2etext(ptr %v0, ptr %v1, ptr %t2, { i64, ptr } %t3)
  store i64 %t6, ptr %l14
  br label %bb1
bb1:
  %t7 = load i32, ptr %l11, !range !{i32 0, i32 5}
  %t8 = load i64, ptr %l14, !tbaa !24
  %t9 = call %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %s0, i32 %t7, i64 0, double 0x0000000000000000, i64 %t8, i64 0, i1 false, i1 false)
  store %"compiler/cond:Value" %t9, ptr %l15
  br label %bb2
bb2:
  %t10 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t12 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t10, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store i1 %t12, ptr %l17
  br label %bb3
bb3:
  %t13 = load i1, ptr %l17, !tbaa !21
  %t14 = xor i1 %t13, true
  %t15 = load ptr, ptr %l10, !tbaa !29
  %t16 = load %"compiler/cond:Value", ptr %l15
  call void @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eadd(ptr %v0, ptr %v0, ptr %t15, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d1, i32 0, i32 1) }, %"compiler/cond:Value" %t16, i1 true, i1 false, i1 %t14)
  br label %bb4
bb4:
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %l19, !tbaa !29
  store i32 4, ptr %l20
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t23 = call i64 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2etext(ptr %v0, ptr %v2, ptr %t19, { i64, ptr } %t20)
  store i64 %t23, ptr %l23
  br label %bb5
bb5:
  %t24 = load i32, ptr %l20, !range !{i32 0, i32 5}
  %t25 = load i64, ptr %l23, !tbaa !24
  %t26 = call %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %s0, i32 %t24, i64 0, double 0x0000000000000000, i64 %t25, i64 0, i1 false, i1 false)
  store %"compiler/cond:Value" %t26, ptr %l24
  br label %bb6
bb6:
  %t27 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t29 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t27, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d2, i32 0, i32 1) })
  store i1 %t29, ptr %l26
  br label %bb7
bb7:
  %t30 = load i1, ptr %l26, !tbaa !21
  %t31 = xor i1 %t30, true
  %t32 = load ptr, ptr %l19, !tbaa !29
  %t33 = load %"compiler/cond:Value", ptr %l24
  call void @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eadd(ptr %v0, ptr %v0, ptr %t32, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d3, i32 0, i32 1) }, %"compiler/cond:Value" %t33, i1 true, i1 false, i1 %t31)
  br label %bb8
bb8:
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l28, !tbaa !29
  store i32 4, ptr %l29
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t40 = call i64 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2etext(ptr %v0, ptr %v3, ptr %t36, { i64, ptr } %t37)
  store i64 %t40, ptr %l32
  br label %bb9
bb9:
  %t41 = load i32, ptr %l29, !range !{i32 0, i32 5}
  %t42 = load i64, ptr %l32, !tbaa !24
  %t43 = call %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %s0, i32 %t41, i64 0, double 0x0000000000000000, i64 %t42, i64 0, i1 false, i1 false)
  store %"compiler/cond:Value" %t43, ptr %l33
  br label %bb10
bb10:
  %t44 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t46 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s0, { i64, ptr } %t44, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d4, i32 0, i32 1) })
  store i1 %t46, ptr %l35
  br label %bb11
bb11:
  %t47 = load i1, ptr %l35, !tbaa !21
  %t48 = xor i1 %t47, true
  %t49 = load ptr, ptr %l28, !tbaa !29
  %t50 = load %"compiler/cond:Value", ptr %l33
  call void @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eadd(ptr %v0, ptr %v0, ptr %t49, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d5, i32 0, i32 1) }, %"compiler/cond:Value" %t50, i1 true, i1 false, i1 %t48)
  br label %bb12
bb12:
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %l37, !tbaa !29
  %t53 = load i64, ptr %l4, !tbaa !24
  %t54 = load i64, ptr @G_2ecompiler_2fcond_2eLiteralIntBits, !tbaa !24
  %t58 = call %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %s0, i32 2, i64 %t53, double 0x0000000000000000, i64 0, i64 %t54, i1 false, i1 false)
  store %"compiler/cond:Value" %t58, ptr %l41
  br label %bb13
bb13:
  %t59 = load i64, ptr %l4, !tbaa !24
  %t61 = icmp sgt i64 %t59, 0
  %t62 = load ptr, ptr %l37, !tbaa !29
  %t63 = load %"compiler/cond:Value", ptr %l41
  call void @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eadd(ptr %v0, ptr %v0, ptr %t62, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d6, i32 0, i32 1) }, %"compiler/cond:Value" %t63, i1 true, i1 false, i1 %t61)
  br label %bb14
bb14:
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l44, !tbaa !29
  %t66 = load i64, ptr %l5, !tbaa !24
  %t68 = icmp eq i64 %t66, 1
  %t70 = call %"compiler/cond:Value" @compiler_2fcond_2eValue_2ebool(i1 %t68)
  store %"compiler/cond:Value" %t70, ptr %l47
  br label %bb15
bb15:
  %t71 = load i64, ptr %l5, !tbaa !24
  %t73 = icmp sge i64 %t71, 0
  %t74 = load ptr, ptr %l44, !tbaa !29
  %t75 = load %"compiler/cond:Value", ptr %l47
  call void @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eadd(ptr %v0, ptr %v0, ptr %t74, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d7, i32 0, i32 1) }, %"compiler/cond:Value" %t75, i1 true, i1 false, i1 %t73)
  br label %bb16
bb16:
  %t77 = load ptr, ptr %l0, !tbaa !29
  store ptr %t77, ptr %l50, !tbaa !29
  %t78 = load i64, ptr %l9, !tbaa !24
  %t80 = icmp eq i64 %t78, 1
  %t82 = call %"compiler/cond:Value" @compiler_2fcond_2eValue_2ebool(i1 %t80)
  store %"compiler/cond:Value" %t82, ptr %l53
  br label %bb17
bb17:
  %t83 = load i64, ptr %l9, !tbaa !24
  %t85 = icmp sge i64 %t83, 0
  %t86 = load ptr, ptr %l50, !tbaa !29
  %t87 = load %"compiler/cond:Value", ptr %l53
  call void @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eadd(ptr %v0, ptr %v0, ptr %t86, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d8, i32 0, i32 1) }, %"compiler/cond:Value" %t87, i1 true, i1 false, i1 %t85)
  br label %bb18
bb18:
  %t89 = load ptr, ptr %l0, !tbaa !29
  store ptr %t89, ptr %l56, !tbaa !29
  %t92 = call %"compiler/cond:Value" @compiler_2fcond_2eValue_2ebool(i1 %a6)
  store %"compiler/cond:Value" %t92, ptr %l58
  br label %bb19
bb19:
  %t93 = load ptr, ptr %l56, !tbaa !29
  %t94 = load %"compiler/cond:Value", ptr %l58
  call void @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eadd(ptr %v0, ptr %v0, ptr %t93, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d9, i32 0, i32 1) }, %"compiler/cond:Value" %t94, i1 true, i1 false, i1 true)
  br label %bb20
bb20:
  %t95 = load ptr, ptr %l0, !tbaa !29
  store ptr %t95, ptr %l59, !tbaa !29
  %t98 = call %"compiler/cond:Value" @compiler_2fcond_2eValue_2ebool(i1 %a7)
  store %"compiler/cond:Value" %t98, ptr %l61
  br label %bb21
bb21:
  %t99 = load ptr, ptr %l59, !tbaa !29
  %t100 = load %"compiler/cond:Value", ptr %l61
  call void @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eadd(ptr %v0, ptr %v0, ptr %t99, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d10, i32 0, i32 1) }, %"compiler/cond:Value" %t100, i1 true, i1 false, i1 true)
  br label %bb22
bb22:
  %t101 = load ptr, ptr %l0, !tbaa !29
  store ptr %t101, ptr %l62, !tbaa !29
  %t104 = call %"compiler/cond:Value" @compiler_2fcond_2eValue_2ebool(i1 %a8)
  store %"compiler/cond:Value" %t104, ptr %l64
  br label %bb23
bb23:
  %t105 = load ptr, ptr %l62, !tbaa !29
  %t106 = load %"compiler/cond:Value", ptr %l64
  call void @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eadd(ptr %v0, ptr %v0, ptr %t105, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d11, i32 0, i32 1) }, %"compiler/cond:Value" %t106, i1 true, i1 false, i1 true)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eDefined(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l10 = alloca i1
  %l14 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { i32, i64 } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2efind(ptr %v0, ptr %v1, ptr %t1, { i64, ptr } %a1)
  %t6 = extractvalue { i32, i64 } %t5, 1
  %t7 = extractvalue { i32, i64 } %t5, 0
  store i32 %t7, ptr %l7
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9, !prof !99
ok.9:
  store i64 %t6, ptr %l6
  br label %bb1
bb1:
  %t10 = load i64, ptr %l6, !tbaa !24
  store i64 %t10, ptr %l3, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 -1, ptr %l3, !tbaa !24
  br label %bb4
bb4:
  %t11 = load i64, ptr %l3, !tbaa !24
  store i64 %t11, ptr %l2, !tbaa !24
  %t12 = load i64, ptr %l2, !tbaa !24
  %t14 = icmp sge i64 %t12, 0
  br i1 %t14, label %bb5, label %bb6
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/cond:Consts", ptr %t16, i32 0, i32 2
  %t19 = load i64, ptr %l2, !tbaa !24
  %t22 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t18, i64 %t19)
  store i1 %t22, ptr %l14
  br label %bb7
bb6:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb8
bb7:
  %t23 = load i1, ptr %l14, !tbaa !21
  %t24 = xor i1 %t23, true
  store i1 %t24, ptr %l10, !tbaa !21
  br label %bb8
bb8:
  %t26 = load i1, ptr %l10, !tbaa !21
  store i1 %t26, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eFits(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca %"compiler/cond:Value"
  %l5 = alloca i1
  %l6 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %l15 = alloca %"compiler/cond:Value"
  %l19 = alloca i1
  %l20 = alloca i1
  %l22 = alloca i1
  %l26 = alloca i1
  %l30 = alloca i1
  %l33 = alloca i1
  %l36 = alloca i1
  %l38 = alloca i1
  %l40 = alloca i1
  %l43 = alloca i1
  %l47 = alloca i1
  %l50 = alloca i1
  %l52 = alloca i1
  %l56 = alloca i1
  %l59 = alloca i1
  %l62 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { i32, i64 } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2efind(ptr %v0, ptr %v1, ptr %t1, { i64, ptr } %a1)
  %t6 = extractvalue { i32, i64 } %t5, 1
  %t7 = extractvalue { i32, i64 } %t5, 0
  store i32 %t7, ptr %l10
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9, !prof !99
ok.9:
  store i64 %t6, ptr %l9
  br label %bb1
bb1:
  %t10 = load i64, ptr %l9, !tbaa !24
  store i64 %t10, ptr %l6, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb4:
  %t12 = load i64, ptr %l6, !tbaa !24
  store i64 %t12, ptr %l3, !tbaa !24
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/cond:Consts", ptr %t13, i32 0, i32 1
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = call %"compiler/cond:Value" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcond_3aValue_3e_2eAt_3ccompiler_2fcond_3aValue_3e(ptr %v0, ptr %t15, i64 %t16)
  store %"compiler/cond:Value" %t19, ptr %l15
  br label %bb5
bb5:
  %t20 = load %"compiler/cond:Value", ptr %l15
  store %"compiler/cond:Value" %t20, ptr %l4
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/cond:Consts", ptr %t21, i32 0, i32 3
  %t24 = load i64, ptr %l3, !tbaa !24
  %t27 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t23, i64 %t24)
  store i1 %t27, ptr %l19
  br label %bb6
bb6:
  %t28 = load i1, ptr %l19, !tbaa !21
  store i1 %t28, ptr %l5, !tbaa !21
  %t29 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t31 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t29, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d12, i32 0, i32 1) })
  store i1 %t31, ptr %l22
  br label %bb7
bb7:
  %t32 = load i1, ptr %l22, !tbaa !21
  br i1 %t32, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t33 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 0
  %t34 = load i32, ptr %t33, !range !{i32 0, i32 5}
  %t36 = trunc i64 1 to i32
  %t37 = icmp eq i32 %t34, %t36
  store i1 %t37, ptr %l20, !tbaa !21
  br label %bb63
bb11:
  %t39 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t41 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t39, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d13, i32 0, i32 1) })
  store i1 %t41, ptr %l26
  br label %bb12
bb12:
  %t42 = load i1, ptr %l26, !tbaa !21
  br i1 %t42, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t43 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 0
  %t44 = load i32, ptr %t43, !range !{i32 0, i32 5}
  %t46 = trunc i64 4 to i32
  %t47 = icmp eq i32 %t44, %t46
  store i1 %t47, ptr %l20, !tbaa !21
  br label %bb63
bb16:
  %t49 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t51 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t49, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d14, i32 0, i32 1) })
  store i1 %t51, ptr %l30
  br label %bb17
bb17:
  %t52 = load i1, ptr %l30, !tbaa !21
  br i1 %t52, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb28
bb20:
  %t53 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 0
  %t54 = load i32, ptr %t53, !range !{i32 0, i32 5}
  %t56 = trunc i64 2 to i32
  %t57 = icmp eq i32 %t54, %t56
  br i1 %t57, label %bb21, label %bb22
bb21:
  %t59 = load i1, ptr %l5, !tbaa !21
  %t61 = xor i1 %t59, true
  store i1 %t61, ptr %l33, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb23
bb23:
  %t63 = load i1, ptr %l33, !tbaa !21
  br i1 %t63, label %bb24, label %bb25
bb24:
  %t64 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 1
  %t65 = load i64, ptr %t64, !tbaa !24
  %t67 = call i1 @compiler_2fcond_2efits(i64 %t65, i64 32, i1 false)
  store i1 %t67, ptr %l38
  br label %bb26
bb25:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb27
bb26:
  %t68 = load i1, ptr %l38, !tbaa !21
  store i1 %t68, ptr %l36, !tbaa !21
  br label %bb27
bb27:
  %t69 = load i1, ptr %l36, !tbaa !21
  store i1 %t69, ptr %l20, !tbaa !21
  br label %bb63
bb28:
  %t70 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t72 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t70, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d15, i32 0, i32 1) })
  store i1 %t72, ptr %l40
  br label %bb29
bb29:
  %t73 = load i1, ptr %l40, !tbaa !21
  br i1 %t73, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb36
bb32:
  %t74 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 0
  %t75 = load i32, ptr %t74, !range !{i32 0, i32 5}
  %t77 = trunc i64 2 to i32
  %t78 = icmp eq i32 %t75, %t77
  br i1 %t78, label %bb33, label %bb34
bb33:
  %t80 = load i1, ptr %l5, !tbaa !21
  %t82 = xor i1 %t80, true
  store i1 %t82, ptr %l43, !tbaa !21
  br label %bb35
bb34:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb35
bb35:
  %t84 = load i1, ptr %l43, !tbaa !21
  store i1 %t84, ptr %l20, !tbaa !21
  br label %bb63
bb36:
  %t85 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t87 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t85, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d16, i32 0, i32 1) })
  store i1 %t87, ptr %l47
  br label %bb37
bb37:
  %t88 = load i1, ptr %l47, !tbaa !21
  br i1 %t88, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb47
bb40:
  %t89 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 0
  %t90 = load i32, ptr %t89, !range !{i32 0, i32 5}
  %t92 = trunc i64 2 to i32
  %t93 = icmp eq i32 %t90, %t92
  br i1 %t93, label %bb41, label %bb42
bb41:
  %t95 = load i1, ptr %l5, !tbaa !21
  br i1 %t95, label %bb43, label %bb44
bb42:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb46
bb43:
  store i1 true, ptr %l52, !tbaa !21
  br label %bb45
bb44:
  %t97 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 1
  %t98 = load i64, ptr %t97, !tbaa !24
  %t100 = icmp sge i64 %t98, 0
  store i1 %t100, ptr %l52, !tbaa !21
  br label %bb45
bb45:
  %t102 = load i1, ptr %l52, !tbaa !21
  store i1 %t102, ptr %l50, !tbaa !21
  br label %bb46
bb46:
  %t103 = load i1, ptr %l50, !tbaa !21
  store i1 %t103, ptr %l20, !tbaa !21
  br label %bb63
bb47:
  %t104 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t106 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t104, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d17, i32 0, i32 1) })
  store i1 %t106, ptr %l56
  br label %bb48
bb48:
  %t107 = load i1, ptr %l56, !tbaa !21
  br i1 %t107, label %bb49, label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb58
bb51:
  %t108 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 0
  %t109 = load i32, ptr %t108, !range !{i32 0, i32 5}
  %t111 = trunc i64 3 to i32
  %t112 = icmp eq i32 %t109, %t111
  br i1 %t112, label %bb52, label %bb53
bb52:
  store i1 true, ptr %l59, !tbaa !21
  br label %bb57
bb53:
  %t114 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 0
  %t115 = load i32, ptr %t114, !range !{i32 0, i32 5}
  %t117 = trunc i64 2 to i32
  %t118 = icmp eq i32 %t115, %t117
  br i1 %t118, label %bb54, label %bb55
bb54:
  %t120 = load i1, ptr %l5, !tbaa !21
  %t122 = xor i1 %t120, true
  store i1 %t122, ptr %l62, !tbaa !21
  br label %bb56
bb55:
  store i1 false, ptr %l62, !tbaa !21
  br label %bb56
bb56:
  %t124 = load i1, ptr %l62, !tbaa !21
  store i1 %t124, ptr %l59, !tbaa !21
  br label %bb57
bb57:
  %t125 = load i1, ptr %l59, !tbaa !21
  store i1 %t125, ptr %l20, !tbaa !21
  br label %bb63
bb58:
  br i1 true, label %bb59, label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb62
bb61:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb63
bb62:
  call void @__olang_check_failed(ptr @olang_loc_1b6b73656135f28c_5e0b436694761b68)
  unreachable
bb63:
  call void @__olang_scope_close(ptr %s0)
  %t126 = load i1, ptr %l20, !tbaa !21
  store i1 %t126, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eHas(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call { i32, i64 } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2efind(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
  %t6 = extractvalue { i32, i64 } %t5, 1
  %t7 = extractvalue { i32, i64 } %t5, 0
  store i32 %t7, ptr %l6
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9, !prof !99
ok.9:
  store i64 %t6, ptr %l5
  br label %bb1
bb1:
  %t10 = load i64, ptr %l5, !tbaa !24
  store i64 %t10, ptr %l2, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 -1, ptr %l2, !tbaa !24
  br label %bb4
bb4:
  %t11 = load i64, ptr %l2, !tbaa !24
  %t12 = icmp sge i64 %t11, 0
  store i1 %t12, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eIsBuiltin(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l10 = alloca i1
  %l14 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { i32, i64 } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2efind(ptr %v0, ptr %v1, ptr %t1, { i64, ptr } %a1)
  %t6 = extractvalue { i32, i64 } %t5, 1
  %t7 = extractvalue { i32, i64 } %t5, 0
  store i32 %t7, ptr %l7
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9, !prof !99
ok.9:
  store i64 %t6, ptr %l6
  br label %bb1
bb1:
  %t10 = load i64, ptr %l6, !tbaa !24
  store i64 %t10, ptr %l3, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 -1, ptr %l3, !tbaa !24
  br label %bb4
bb4:
  %t11 = load i64, ptr %l3, !tbaa !24
  store i64 %t11, ptr %l2, !tbaa !24
  %t12 = load i64, ptr %l2, !tbaa !24
  %t14 = icmp sge i64 %t12, 0
  br i1 %t14, label %bb5, label %bb6
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/cond:Consts", ptr %t16, i32 0, i32 2
  %t19 = load i64, ptr %l2, !tbaa !24
  %t22 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t18, i64 %t19)
  store i1 %t22, ptr %l14
  br label %bb7
bb6:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb8
bb7:
  %t23 = load i1, ptr %l14, !tbaa !21
  store i1 %t23, ptr %l10, !tbaa !21
  br label %bb8
bb8:
  %t24 = load i1, ptr %l10, !tbaa !21
  store i1 %t24, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eRaw(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { i32, i64 } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2efind(ptr %v0, ptr %v1, ptr %t1, { i64, ptr } %a1)
  %t6 = extractvalue { i32, i64 } %t5, 1
  %t7 = extractvalue { i32, i64 } %t5, 0
  store i32 %t7, ptr %l7
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9, !prof !99
ok.9:
  store i64 %t6, ptr %l6
  br label %bb1
bb1:
  %t10 = load i64, ptr %l6, !tbaa !24
  store i64 %t10, ptr %l3, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d18, i32 0, i32 1) }, ptr %l8, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t11, ptr %l9, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 0
  store i64 %t13, ptr %l10, !tbaa !24
  %t14 = load i64, ptr %l10, !tbaa !24
  %t15 = mul i64 %t14, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  %t17 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l11, !tbaa !27
  %t19 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = load i64, ptr %l10, !tbaa !24
  %t24 = mul i64 %t23, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t20, ptr %t22, i64 %t24, i1 false)
  %t25 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t25, ptr %l9, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t26 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t26, ptr %rv
  br label %ret
bb4:
  %t27 = load i64, ptr %l3, !tbaa !24
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/cond:Consts", ptr %t28, i32 0, i32 5
  %t34 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %s0, ptr %t30, i64 %t27)
  store { i64, ptr } %t34, ptr %l15
  br label %bb5
bb5:
  %t35 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t35, 1
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t38 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t37)
  call void @olang_textcopy(ptr %t38, ptr %t36, i64 %t37)
  %t39 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t40, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eSetBool(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l12 = alloca ptr
  %l13 = alloca i64
  %l15 = alloca %"compiler/cond:Value"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { i32, i64 } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2efind(ptr %v0, ptr %v1, ptr %t1, { i64, ptr } %a1)
  %t6 = extractvalue { i32, i64 } %t5, 1
  %t7 = extractvalue { i32, i64 } %t5, 0
  store i32 %t7, ptr %l8
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9, !prof !99
ok.9:
  store i64 %t6, ptr %l7
  br label %bb1
bb1:
  %t10 = load i64, ptr %l7, !tbaa !24
  store i64 %t10, ptr %l4, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 -1, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t11 = load i64, ptr %l4, !tbaa !24
  store i64 %t11, ptr %l3, !tbaa !24
  %t12 = load i64, ptr %l3, !tbaa !24
  %t14 = icmp sge i64 %t12, 0
  br i1 %t14, label %bb5, label %bb6
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/cond:Consts", ptr %t16, i32 0, i32 1
  store ptr %t18, ptr %l12, !tbaa !29
  %t19 = load i64, ptr %l3, !tbaa !24
  store i64 %t19, ptr %l13, !tbaa !24
  %t22 = call %"compiler/cond:Value" @compiler_2fcond_2eValue_2ebool(i1 %a2)
  store %"compiler/cond:Value" %t22, ptr %l15
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t23 = load ptr, ptr %l12, !tbaa !29
  %t24 = load i64, ptr %l13, !tbaa !24
  %t25 = load %"compiler/cond:Value", ptr %l15
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcond_3aValue_3e_2eSetAt_3ccompiler_2fcond_3aValue_3e(ptr %v0, ptr %t23, i64 %t24, %"compiler/cond:Value" %t25)
  br label %bb8
bb8:
  br label %bb9
bb9:
  br label %ret
ret:
  ret void
}

define dso_local { i32, %"compiler/cond:Value" } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eValueOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/cond:Value"
  %l4 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l13 = alloca %"compiler/cond:Value"
  %l14 = alloca i32
  %l15 = alloca i64
  %l16 = alloca double
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i1
  %l23 = alloca i1
  %l24 = alloca %"compiler/cond:Value"
  %s0 = alloca %olang.scope
  %rv = alloca { i32, %"compiler/cond:Value" }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { i32, i64 } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2efind(ptr %v0, ptr %v1, ptr %t1, { i64, ptr } %a1)
  %t6 = extractvalue { i32, i64 } %t5, 1
  %t7 = extractvalue { i32, i64 } %t5, 0
  store i32 %t7, ptr %l8
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9, !prof !99
ok.9:
  store i64 %t6, ptr %l7
  br label %bb1
bb1:
  %t10 = load i64, ptr %l7, !tbaa !24
  store i64 %t10, ptr %l4, !tbaa !24
  br label %bb3
bb2:
  %t11 = load i32, ptr %l8, !tbaa !23
  %t12 = lshr i32 %t11, 16
  %t13 = and i32 %t11, 65535
  %t14 = icmp eq i32 %t12, 1
  %t15 = select i1 %t14, i32 1, i32 0
  %t16 = icmp eq i32 %t11, 0
  %t17 = shl i32 %t15, 16
  %t18 = or i32 %t17, %t13
  %t19 = select i1 %t16, i32 0, i32 %t18
  call void @__olang_scope_close(ptr %s0)
  %t21 = insertvalue { i32, %"compiler/cond:Value" } zeroinitializer, i32 %t19, 0
  store { i32, %"compiler/cond:Value" } %t21, ptr %rv
  br label %ret
bb3:
  %t22 = load i64, ptr %l4, !tbaa !24
  store i64 %t22, ptr %l2, !tbaa !24
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/cond:Consts", ptr %t23, i32 0, i32 1
  %t26 = load i64, ptr %l2, !tbaa !24
  %t29 = call %"compiler/cond:Value" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcond_3aValue_3e_2eAt_3ccompiler_2fcond_3aValue_3e(ptr %v0, ptr %t25, i64 %t26)
  store %"compiler/cond:Value" %t29, ptr %l13
  br label %bb4
bb4:
  %t30 = load %"compiler/cond:Value", ptr %l13
  store %"compiler/cond:Value" %t30, ptr %l3
  %t31 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 0
  %t32 = load i32, ptr %t31, !range !{i32 0, i32 5}
  store i32 %t32, ptr %l14
  %t33 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 1
  %t34 = load i64, ptr %t33, !tbaa !24
  store i64 %t34, ptr %l15, !tbaa !24
  %t35 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 2
  %t36 = load double, ptr %t35, !tbaa !26
  store double %t36, ptr %l16, !tbaa !26
  %t37 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 3
  %t38 = load i64, ptr %t37, !tbaa !24
  store i64 %t38, ptr %l17, !tbaa !24
  %t39 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 4
  %t40 = load i64, ptr %t39, !tbaa !24
  store i64 %t40, ptr %l18, !tbaa !24
  %t41 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 5
  %t42 = load i1, ptr %t41, !tbaa !21
  store i1 %t42, ptr %l19, !tbaa !21
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/cond:Consts", ptr %t43, i32 0, i32 3
  %t46 = load i64, ptr %l2, !tbaa !24
  %t49 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t45, i64 %t46)
  store i1 %t49, ptr %l23
  br label %bb5
bb5:
  %t50 = load i32, ptr %l14, !range !{i32 0, i32 5}
  %t51 = load i64, ptr %l15, !tbaa !24
  %t52 = load double, ptr %l16, !tbaa !26
  %t53 = load i64, ptr %l17, !tbaa !24
  %t54 = load i64, ptr %l18, !tbaa !24
  %t55 = load i1, ptr %l19, !tbaa !21
  %t56 = load i1, ptr %l23, !tbaa !21
  %t57 = call %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %s0, i32 %t50, i64 %t51, double %t52, i64 %t53, i64 %t54, i1 %t55, i1 %t56)
  store %"compiler/cond:Value" %t57, ptr %l24
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t58 = load %"compiler/cond:Value", ptr %l24
  %t59 = insertvalue { i32, %"compiler/cond:Value" } zeroinitializer, %"compiler/cond:Value" %t58, 1
  store { i32, %"compiler/cond:Value" } %t59, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/cond:Value" }, ptr %rv
  ret { i32, %"compiler/cond:Value" } %rr
}

define dso_local void @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eadd(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, %"compiler/cond:Value" %a2, i1 %a3, i1 %a4, i1 %a5) #0 {
entry:
  %l0 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/cond:Consts", ptr %t1, i32 0, i32 0
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %t3, { i64, ptr } %a1)
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/cond:Consts", ptr %t7, i32 0, i32 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcond_3aValue_3e_2ePush_3ccompiler_2fcond_3aValue_3e(ptr %v0, ptr %t9, %"compiler/cond:Value" %a2)
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/cond:Consts", ptr %t13, i32 0, i32 2
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t15, i1 %a3)
  br label %bb3
bb3:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/cond:Consts", ptr %t19, i32 0, i32 3
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t21, i1 %a4)
  br label %bb4
bb4:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/cond:Consts", ptr %t25, i32 0, i32 4
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t27, i1 %a5)
  br label %bb5
bb5:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/cond:Consts", ptr %t31, i32 0, i32 5
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t33, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d19, i32 0, i32 1) })
  br label %bb6
bb6:
  br label %ret
ret:
  ret void
}

define dso_local { i32, i64 } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2efind(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l10 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l38 = alloca { i64, ptr }
  %l40 = alloca i1
  %rv = alloca { i32, i64 }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/cond:Consts", ptr %t1, i32 0, i32 0
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i64, ptr %l10, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l2, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l3, !tbaa !24
  %t18 = load i64, ptr %l2, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l17, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l17, !tbaa !24
  store i64 %t33, ptr %l14, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l14, !tbaa !24
  store i64 %t34, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  %t35 = load i64, ptr %l6, !tbaa !24
  %t36 = load i64, ptr %l5, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  br label %bb18
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l2, !tbaa !24
  %t44 = load i64, ptr %l6, !tbaa !24
  %t45 = load i64, ptr %l4, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l7, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/cond:Consts", ptr %t53, i32 0, i32 0
  %t56 = load i64, ptr %l7, !tbaa !24
  %t59 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t55, i64 %t56)
  store { i64, ptr } %t59, ptr %l38
  br label %bb12
bb12:
  %t61 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t63 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t61, { i64, ptr } %a1)
  store i1 %t63, ptr %l40
  br label %bb13
bb13:
  %t64 = load i1, ptr %l40, !tbaa !21
  br i1 %t64, label %bb14, label %bb15
bb14:
  %t65 = load i64, ptr %l7, !tbaa !24
  %t67 = insertvalue { i32, i64 } zeroinitializer, i64 %t65, 1
  store { i32, i64 } %t67, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t68 = load i64, ptr %l6, !tbaa !24
  %t71 = add i64 %t68, 1
  store i64 %t71, ptr %l6, !tbaa !24
  br label %bb8
bb18:
  %t74 = insertvalue { i32, i64 } zeroinitializer, i32 65536, 0
  store { i32, i64 } %t74, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local i64 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2etext(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l7 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/cond:Consts", ptr %t1, i32 0, i32 6
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %t3, { i64, ptr } %a1)
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/cond:Consts", ptr %t7, i32 0, i32 6
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l7
  br label %bb2
bb2:
  %t12 = load i64, ptr %l7, !tbaa !24
  %t13 = sub i64 %t12, 1
  store i64 %t13, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { %"compiler/source:Span", %"compiler/diagmsg:Msg" } @compiler_2fcond_2ecompiler_2fcond_3aEval_2eError(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %rv = alloca { %"compiler/source:Span", %"compiler/diagmsg:Msg" }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/cond:Eval", ptr %t1, i32 0, i32 7
  %t4 = load %"compiler/source:Span", ptr %t3
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/cond:Eval", ptr %t5, i32 0, i32 8
  %t8 = load %"compiler/diagmsg:Msg", ptr %t7
  %t10 = insertvalue { %"compiler/source:Span", %"compiler/diagmsg:Msg" } undef, %"compiler/source:Span" %t4, 0
  %t12 = insertvalue { %"compiler/source:Span", %"compiler/diagmsg:Msg" } %t10, %"compiler/diagmsg:Msg" %t8, 1
  store { %"compiler/source:Span", %"compiler/diagmsg:Msg" } %t12, ptr %rv
  br label %ret
ret:
  %rr = load { %"compiler/source:Span", %"compiler/diagmsg:Msg" }, ptr %rv
  ret { %"compiler/source:Span", %"compiler/diagmsg:Msg" } %rr
}

define dso_local %"compiler/cond:Decision" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eLocal(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/cond:Value"
  %l5 = alloca %"compiler/cond:Value"
  %l10 = alloca i1
  %l14 = alloca i1
  %l16 = alloca %"compiler/cond:Decision"
  %l19 = alloca i32
  %l22 = alloca %"compiler/cond:Decision"
  %l27 = alloca %"compiler/cond:Decision"
  %l34 = alloca %"compiler/cond:Decision"
  %l38 = alloca %"compiler/cond:Decision"
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca %"compiler/cond:Decision"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eexpr(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store %"compiler/cond:Value" %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load %"compiler/cond:Value", ptr %l5
  store %"compiler/cond:Value" %t6, ptr %l2
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/cond:Eval", ptr %t7, i32 0, i32 4
  %t10 = load i1, ptr %t9, !tbaa !21
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/cond:Eval", ptr %t12, i32 0, i32 6
  %t15 = load i1, ptr %t14, !tbaa !21
  br i1 %t15, label %bb4, label %bb5
bb3:
  br label %bb16
bb4:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb7
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t22 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2ementionsLocal(ptr %v0, ptr %v1, ptr %t17, ptr %t18)
  store i1 %t22, ptr %l14
  br label %bb6
bb6:
  %t23 = load i1, ptr %l14, !tbaa !21
  store i1 %t23, ptr %l10, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l10, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = call %"compiler/cond:Decision" @compiler_2fcond_2eDecision_2eundecided(i32 3)
  store %"compiler/cond:Decision" %t26, ptr %l16
  br label %bb10
bb9:
  br label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t27 = load %"compiler/cond:Decision", ptr %l16
  store %"compiler/cond:Decision" %t27, ptr %rv
  br label %ret
bb11:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/cond:Eval", ptr %t28, i32 0, i32 5
  %t31 = load i1, ptr %t30, !tbaa !21
  br i1 %t31, label %bb12, label %bb13
bb12:
  store i32 1, ptr %l19
  br label %bb14
bb13:
  store i32 3, ptr %l19
  br label %bb14
bb14:
  %t35 = load i32, ptr %l19, !range !{i32 0, i32 5}
  %t36 = call %"compiler/cond:Decision" @compiler_2fcond_2eDecision_2eundecided(i32 %t35)
  store %"compiler/cond:Decision" %t36, ptr %l22
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s0)
  %t37 = load %"compiler/cond:Decision", ptr %l22
  store %"compiler/cond:Decision" %t37, ptr %rv
  br label %ret
bb16:
  %t38 = getelementptr %"compiler/cond:Value", ptr %l2, i32 0, i32 0
  %t39 = load i32, ptr %t38, !range !{i32 0, i32 5}
  %t41 = trunc i64 1 to i32
  %t42 = icmp eq i32 %t39, %t41
  %t44 = xor i1 %t42, true
  br i1 %t44, label %bb17, label %bb18
bb17:
  %t47 = call %"compiler/cond:Decision" @compiler_2fcond_2eDecision_2eundecided(i32 3)
  store %"compiler/cond:Decision" %t47, ptr %l27
  br label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_scope_close(ptr %s0)
  %t48 = load %"compiler/cond:Decision", ptr %l27
  store %"compiler/cond:Decision" %t48, ptr %rv
  br label %ret
bb20:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/cond:Eval", ptr %t49, i32 0, i32 11
  %t52 = load i1, ptr %t51, !tbaa !21
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s4
  %t56 = getelementptr %"compiler/cond:Value", ptr %l2, i32 0, i32 1
  %t57 = load i64, ptr %t56, !tbaa !24
  %t59 = icmp ne i64 %t57, 0
  %t62 = call %"compiler/cond:Decision" @compiler_2fcond_3aDecision_2ector(ptr %s4, i32 4, i1 %t59)
  store %"compiler/cond:Decision" %t62, ptr %l34
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t63 = load %"compiler/cond:Decision", ptr %l34
  store %"compiler/cond:Decision" %t63, ptr %rv
  br label %ret
bb24:
  %t64 = getelementptr %"compiler/cond:Value", ptr %l2, i32 0, i32 1
  %t65 = load i64, ptr %t64, !tbaa !24
  %t67 = icmp ne i64 %t65, 0
  %t70 = call %"compiler/cond:Decision" @compiler_2fcond_3aDecision_2ector(ptr %s0, i32 0, i1 %t67)
  store %"compiler/cond:Decision" %t70, ptr %l38
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s0)
  %t71 = load %"compiler/cond:Decision", ptr %l38
  store %"compiler/cond:Decision" %t71, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cond:Decision", ptr %rv
  ret %"compiler/cond:Decision" %rr
}

define dso_local %"compiler/cond:Decision" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eTop(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/cond:Value"
  %l5 = alloca %"compiler/cond:Value"
  %l9 = alloca i1
  %l13 = alloca ptr
  %l16 = alloca %"compiler/source:Span"
  %l17 = alloca ptr
  %l20 = alloca %"compiler/source:Span"
  %l21 = alloca { i64, ptr }
  %l23 = alloca %"compiler/diagmsg:Msg"
  %l24 = alloca %"compiler/cond:Value"
  %l29 = alloca i32
  %l32 = alloca %"compiler/cond:Decision"
  %l36 = alloca %"compiler/cond:Decision"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca %"compiler/cond:Decision"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eexpr(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store %"compiler/cond:Value" %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load %"compiler/cond:Value", ptr %l5
  store %"compiler/cond:Value" %t6, ptr %l2
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/cond:Eval", ptr %t7, i32 0, i32 4
  %t10 = load i1, ptr %t9, !tbaa !21
  %t12 = xor i1 %t10, true
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t14 = getelementptr %"compiler/cond:Value", ptr %l2, i32 0, i32 0
  %t15 = load i32, ptr %t14, !range !{i32 0, i32 5}
  %t17 = trunc i64 1 to i32
  %t18 = icmp eq i32 %t15, %t17
  %t20 = xor i1 %t18, true
  store i1 %t20, ptr %l9, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb4
bb4:
  %t22 = load i1, ptr %l9, !tbaa !21
  br i1 %t22, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l13, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t28 = call %"compiler/source:Span" @compiler_2fcond_2ecompiler_2fcond_3aEval_2efirst(ptr %v0, ptr %v1, ptr %t24, ptr %t25)
  store %"compiler/source:Span" %t28, ptr %l16
  br label %bb7
bb6:
  br label %bb12
bb7:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l17, !tbaa !29
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t34 = call %"compiler/source:Span" @compiler_2fcond_2ecompiler_2fcond_3aEval_2efirst(ptr %v0, ptr %v1, ptr %t30, ptr %t31)
  store %"compiler/source:Span" %t34, ptr %l20
  br label %bb8
bb8:
  %t35 = load ptr, ptr %l17, !tbaa !29
  %t36 = load %"compiler/source:Span", ptr %l20
  %t37 = call { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aEval_2etokText(ptr %v0, ptr %s1, ptr %t35, %"compiler/source:Span" %t36)
  store { i64, ptr } %t37, ptr %l21
  br label %bb9
bb9:
  %t38 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t40 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCondNotBool(ptr %s1, ptr %v0, { i64, ptr } %t38)
  store %"compiler/diagmsg:Msg" %t40, ptr %l23
  br label %bb10
bb10:
  %t41 = load ptr, ptr %l13, !tbaa !29
  %t42 = load %"compiler/source:Span", ptr %l16
  %t43 = load %"compiler/diagmsg:Msg", ptr %l23
  %t44 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2efail(ptr %v0, ptr %v0, ptr %t41, %"compiler/source:Span" %t42, %"compiler/diagmsg:Msg" %t43)
  store %"compiler/cond:Value" %t44, ptr %l24
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s1)
  br label %bb12
bb12:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/cond:Eval", ptr %t45, i32 0, i32 4
  %t48 = load i1, ptr %t47, !tbaa !21
  br i1 %t48, label %bb13, label %bb14
bb13:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/cond:Eval", ptr %t50, i32 0, i32 5
  %t53 = load i1, ptr %t52, !tbaa !21
  br i1 %t53, label %bb15, label %bb16
bb14:
  br label %bb19
bb15:
  store i32 1, ptr %l29
  br label %bb17
bb16:
  store i32 2, ptr %l29
  br label %bb17
bb17:
  %t57 = load i32, ptr %l29, !range !{i32 0, i32 5}
  %t58 = call %"compiler/cond:Decision" @compiler_2fcond_2eDecision_2eundecided(i32 %t57)
  store %"compiler/cond:Decision" %t58, ptr %l32
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s0)
  %t59 = load %"compiler/cond:Decision", ptr %l32
  store %"compiler/cond:Decision" %t59, ptr %rv
  br label %ret
bb19:
  %t60 = getelementptr %"compiler/cond:Value", ptr %l2, i32 0, i32 1
  %t61 = load i64, ptr %t60, !tbaa !24
  %t63 = icmp ne i64 %t61, 0
  %t66 = call %"compiler/cond:Decision" @compiler_2fcond_3aDecision_2ector(ptr %s0, i32 0, i1 %t63)
  store %"compiler/cond:Decision" %t66, ptr %l36
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t67 = load %"compiler/cond:Decision", ptr %l36
  store %"compiler/cond:Decision" %t67, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cond:Decision", ptr %rv
  ret %"compiler/cond:Decision" %rr
}

define dso_local i64 @compiler_2fcond_2ecompiler_2fcond_3aEval_2eaddText(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l7 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/cond:Eval", ptr %t1, i32 0, i32 12
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %t3, { i64, ptr } %a1)
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/cond:Eval", ptr %t7, i32 0, i32 12
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l7
  br label %bb2
bb2:
  %t12 = load i64, ptr %l7, !tbaa !24
  %t13 = sub i64 %t12, 1
  store i64 %t13, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2ebinary(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca ptr
  %l8 = alloca %"compiler/source:Span"
  %l10 = alloca %"compiler/source:Span"
  %l20 = alloca %"compiler/cond:Value"
  %l33 = alloca ptr
  %l34 = alloca %"compiler/source:Span"
  %l35 = alloca i32
  %l38 = alloca %"compiler/cond:Value"
  %l41 = alloca %"compiler/cond:Value"
  %l42 = alloca %"compiler/cond:Value"
  %l53 = alloca ptr
  %l54 = alloca %"compiler/source:Span"
  %l55 = alloca i32
  %l58 = alloca %"compiler/cond:Value"
  %l61 = alloca %"compiler/cond:Value"
  %l62 = alloca %"compiler/cond:Value"
  %l65 = alloca %"compiler/cond:Value"
  %l68 = alloca %"compiler/cond:Value"
  %rv = alloca %"compiler/cond:Value"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t4 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t2)
  store %"compiler/source:Span" %t4, ptr %l8
  br label %bb1
bb1:
  %t5 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 1
  %t6 = load i32, ptr %t5, !tbaa !23
  %t7 = load ptr, ptr %l6, !tbaa !29
  %t9 = call %"compiler/source:Span" @compiler_2fcond_2ecompiler_2fcond_3aEval_2etokenAt(ptr %v0, ptr %t7, i32 %t6)
  store %"compiler/source:Span" %t9, ptr %l10
  br label %bb2
bb2:
  %t10 = load %"compiler/source:Span", ptr %l10
  store %"compiler/source:Span" %t10, ptr %l5
  %t11 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t13 = trunc i64 45 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb3, label %bb4
bb3:
  br label %bb7
bb4:
  %t16 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t18 = trunc i64 46 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load %"compiler/source:Span", ptr %l5
  %t23 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t24 = load ptr, ptr %l3, !tbaa !29
  %t25 = load ptr, ptr %l4, !tbaa !29
  %t31 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2elogic(ptr %v0, ptr %v1, ptr %v2, ptr %t21, %"compiler/source:Span" %t22, i32 %t23, ptr %t24, ptr %t25)
  store %"compiler/cond:Value" %t31, ptr %l20
  br label %bb8
bb8:
  %t32 = load %"compiler/cond:Value", ptr %l20
  store %"compiler/cond:Value" %t32, ptr %rv
  br label %ret
bb9:
  %t33 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t35 = trunc i64 95 to i32
  %t36 = icmp eq i32 %t33, %t35
  br i1 %t36, label %bb10, label %bb11
bb10:
  br label %bb22
bb11:
  %t38 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t40 = trunc i64 96 to i32
  %t41 = icmp eq i32 %t38, %t40
  br i1 %t41, label %bb12, label %bb13
bb12:
  br label %bb22
bb13:
  %t43 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t45 = trunc i64 98 to i32
  %t46 = icmp eq i32 %t43, %t45
  br i1 %t46, label %bb14, label %bb15
bb14:
  br label %bb22
bb15:
  %t48 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t50 = trunc i64 99 to i32
  %t51 = icmp eq i32 %t48, %t50
  br i1 %t51, label %bb16, label %bb17
bb16:
  br label %bb22
bb17:
  %t53 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t55 = trunc i64 100 to i32
  %t56 = icmp eq i32 %t53, %t55
  br i1 %t56, label %bb18, label %bb19
bb18:
  br label %bb22
bb19:
  %t58 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t60 = trunc i64 101 to i32
  %t61 = icmp eq i32 %t58, %t60
  br i1 %t61, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb26
bb22:
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l33, !tbaa !29
  %t64 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t64, ptr %l34
  %t65 = load i32, ptr %l2, !range !{i32 0, i32 116}
  store i32 %t65, ptr %l35
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load ptr, ptr %l3, !tbaa !29
  %t70 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eexpr(ptr %v0, ptr %v1, ptr %t66, ptr %t67)
  store %"compiler/cond:Value" %t70, ptr %l38
  br label %bb23
bb23:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load ptr, ptr %l4, !tbaa !29
  %t75 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eexpr(ptr %v0, ptr %v2, ptr %t71, ptr %t72)
  store %"compiler/cond:Value" %t75, ptr %l41
  br label %bb24
bb24:
  %t76 = load ptr, ptr %l33, !tbaa !29
  %t77 = load %"compiler/source:Span", ptr %l34
  %t78 = load i32, ptr %l35, !range !{i32 0, i32 116}
  %t79 = load %"compiler/cond:Value", ptr %l38
  %t80 = load %"compiler/cond:Value", ptr %l41
  %t81 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2ecompare(ptr %v0, ptr %t76, %"compiler/source:Span" %t77, i32 %t78, %"compiler/cond:Value" %t79, %"compiler/cond:Value" %t80)
  store %"compiler/cond:Value" %t81, ptr %l42
  br label %bb25
bb25:
  %t82 = load %"compiler/cond:Value", ptr %l42
  store %"compiler/cond:Value" %t82, ptr %rv
  br label %ret
bb26:
  %t83 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t85 = trunc i64 68 to i32
  %t86 = icmp eq i32 %t83, %t85
  br i1 %t86, label %bb27, label %bb28
bb27:
  br label %bb37
bb28:
  %t88 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t90 = trunc i64 69 to i32
  %t91 = icmp eq i32 %t88, %t90
  br i1 %t91, label %bb29, label %bb30
bb29:
  br label %bb37
bb30:
  %t93 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t95 = trunc i64 70 to i32
  %t96 = icmp eq i32 %t93, %t95
  br i1 %t96, label %bb31, label %bb32
bb31:
  br label %bb37
bb32:
  %t98 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t100 = trunc i64 72 to i32
  %t101 = icmp eq i32 %t98, %t100
  br i1 %t101, label %bb33, label %bb34
bb33:
  br label %bb37
bb34:
  %t103 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t105 = trunc i64 73 to i32
  %t106 = icmp eq i32 %t103, %t105
  br i1 %t106, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb41
bb37:
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l53, !tbaa !29
  %t109 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t109, ptr %l54
  %t110 = load i32, ptr %l2, !range !{i32 0, i32 116}
  store i32 %t110, ptr %l55
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = load ptr, ptr %l3, !tbaa !29
  %t115 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eexpr(ptr %v0, ptr %v1, ptr %t111, ptr %t112)
  store %"compiler/cond:Value" %t115, ptr %l58
  br label %bb38
bb38:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load ptr, ptr %l4, !tbaa !29
  %t120 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eexpr(ptr %v0, ptr %v2, ptr %t116, ptr %t117)
  store %"compiler/cond:Value" %t120, ptr %l61
  br label %bb39
bb39:
  %t121 = load ptr, ptr %l53, !tbaa !29
  %t122 = load %"compiler/source:Span", ptr %l54
  %t123 = load i32, ptr %l55, !range !{i32 0, i32 116}
  %t124 = load %"compiler/cond:Value", ptr %l58
  %t125 = load %"compiler/cond:Value", ptr %l61
  %t126 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2earith(ptr %v0, ptr %t121, %"compiler/source:Span" %t122, i32 %t123, %"compiler/cond:Value" %t124, %"compiler/cond:Value" %t125)
  store %"compiler/cond:Value" %t126, ptr %l62
  br label %bb40
bb40:
  %t127 = load %"compiler/cond:Value", ptr %l62
  store %"compiler/cond:Value" %t127, ptr %rv
  br label %ret
bb41:
  br i1 true, label %bb42, label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb47
bb44:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load ptr, ptr %l3, !tbaa !29
  %t132 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eexpr(ptr %v0, ptr %v1, ptr %t128, ptr %t129)
  store %"compiler/cond:Value" %t132, ptr %l65
  br label %bb45
bb45:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load %"compiler/source:Span", ptr %l5
  %t137 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t133, %"compiler/source:Span" %t134)
  store %"compiler/cond:Value" %t137, ptr %l68
  br label %bb46
bb46:
  %t138 = load %"compiler/cond:Value", ptr %l68
  store %"compiler/cond:Value" %t138, ptr %rv
  br label %ret
bb47:
  call void @__olang_check_failed(ptr @olang_loc_5546f0ea7c9d5f01_1e107de9ea891e15)
  unreachable
ret:
  %rr = load %"compiler/cond:Value", ptr %rv
  ret %"compiler/cond:Value" %rr
}

define dso_local %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2econstValue(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/cond:Value"
  %l7 = alloca %"compiler/cond:Value"
  %l12 = alloca i32
  %l13 = alloca i64
  %l14 = alloca double
  %l15 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l24 = alloca %"compiler/cond:Value"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/cond:Value"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/cond:Eval", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/cond:Consts", ptr %t4, i32 0, i32 1
  %t10 = call %"compiler/cond:Value" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcond_3aValue_3e_2eAt_3ccompiler_2fcond_3aValue_3e(ptr %v0, ptr %t6, i64 %a1)
  store %"compiler/cond:Value" %t10, ptr %l7
  br label %bb1
bb1:
  %t11 = load %"compiler/cond:Value", ptr %l7
  store %"compiler/cond:Value" %t11, ptr %l2
  %t12 = getelementptr %"compiler/cond:Value", ptr %l2, i32 0, i32 0
  %t13 = load i32, ptr %t12, !range !{i32 0, i32 5}
  %t15 = trunc i64 4 to i32
  %t16 = icmp eq i32 %t13, %t15
  %t18 = xor i1 %t16, true
  br i1 %t18, label %bb2, label %bb3
bb2:
  %t20 = load %"compiler/cond:Value", ptr %l2
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/cond:Value" %t20, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t22 = getelementptr %"compiler/cond:Value", ptr %l2, i32 0, i32 0
  %t23 = load i32, ptr %t22, !range !{i32 0, i32 5}
  store i32 %t23, ptr %l12
  %t24 = getelementptr %"compiler/cond:Value", ptr %l2, i32 0, i32 1
  %t25 = load i64, ptr %t24, !tbaa !24
  store i64 %t25, ptr %l13, !tbaa !24
  %t26 = getelementptr %"compiler/cond:Value", ptr %l2, i32 0, i32 2
  %t27 = load double, ptr %t26, !tbaa !26
  store double %t27, ptr %l14, !tbaa !26
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l15, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/cond:Eval", ptr %t29, i32 0, i32 3
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/cond:Consts", ptr %t32, i32 0, i32 6
  %t35 = getelementptr %"compiler/cond:Value", ptr %l2, i32 0, i32 3
  %t36 = load i64, ptr %t35, !tbaa !24
  %t39 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t34, i64 %t36)
  store { i64, ptr } %t39, ptr %l20
  br label %bb5
bb5:
  %t40 = load ptr, ptr %l15, !tbaa !29
  %t41 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t42 = call i64 @compiler_2fcond_2ecompiler_2fcond_3aEval_2eaddText(ptr %v0, ptr %v0, ptr %t40, { i64, ptr } %t41)
  store i64 %t42, ptr %l21
  br label %bb6
bb6:
  %t43 = getelementptr %"compiler/cond:Value", ptr %l2, i32 0, i32 4
  %t44 = load i64, ptr %t43, !tbaa !24
  %t45 = getelementptr %"compiler/cond:Value", ptr %l2, i32 0, i32 5
  %t46 = load i1, ptr %t45, !tbaa !21
  %t47 = load i32, ptr %l12, !range !{i32 0, i32 5}
  %t48 = load i64, ptr %l13, !tbaa !24
  %t49 = load double, ptr %l14, !tbaa !26
  %t50 = load i64, ptr %l21, !tbaa !24
  %t53 = call %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %s0, i32 %t47, i64 %t48, double %t49, i64 %t50, i64 %t44, i1 %t46, i1 false)
  store %"compiler/cond:Value" %t53, ptr %l24
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t54 = load %"compiler/cond:Value", ptr %l24
  store %"compiler/cond:Value" %t54, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cond:Value", ptr %rv
  ret %"compiler/cond:Value" %rr
}

define dso_local %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l5 = alloca %"compiler/cond:Value"
  %l10 = alloca ptr
  %l11 = alloca %"compiler/source:Span"
  %l14 = alloca { i64, ptr }
  %l16 = alloca %"compiler/diagmsg:Msg"
  %l17 = alloca %"compiler/cond:Value"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/cond:Value"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/cond:Eval", ptr %t1, i32 0, i32 10
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp sgt i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = call %"compiler/cond:Value" @compiler_2fcond_2eValue_2enone()
  store %"compiler/cond:Value" %t8, ptr %l5
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t9 = load %"compiler/cond:Value", ptr %l5
  store %"compiler/cond:Value" %t9, ptr %rv
  br label %ret
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/cond:Eval", ptr %t10, i32 0, i32 4
  %t13 = load i1, ptr %t12, !tbaa !21
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb5, label %bb6
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/cond:Eval", ptr %t17, i32 0, i32 5
  store i1 true, ptr %t19, !tbaa !21
  br label %bb7
bb6:
  br label %bb7
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l10, !tbaa !29
  %t21 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t21, ptr %l11
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load %"compiler/source:Span", ptr %l1
  %t26 = call { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aEval_2etokText(ptr %v0, ptr %s0, ptr %t22, %"compiler/source:Span" %t23)
  store { i64, ptr } %t26, ptr %l14
  br label %bb8
bb8:
  %t27 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t29 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCondName(ptr %s0, ptr %v0, { i64, ptr } %t27)
  store %"compiler/diagmsg:Msg" %t29, ptr %l16
  br label %bb9
bb9:
  %t30 = load ptr, ptr %l10, !tbaa !29
  %t31 = load %"compiler/source:Span", ptr %l11
  %t32 = load %"compiler/diagmsg:Msg", ptr %l16
  %t33 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2efail(ptr %v0, ptr %v0, ptr %t30, %"compiler/source:Span" %t31, %"compiler/diagmsg:Msg" %t32)
  store %"compiler/cond:Value" %t33, ptr %l17
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t34 = load %"compiler/cond:Value", ptr %l17
  store %"compiler/cond:Value" %t34, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cond:Value", ptr %rv
  ret %"compiler/cond:Value" %rr
}

define dso_local %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca i32
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca %"compiler/cond:Value"
  %l15 = alloca ptr
  %l16 = alloca i1
  %l26 = alloca %"compiler/cond:Value"
  %l27 = alloca ptr
  %l28 = alloca i1
  %l38 = alloca %"compiler/cond:Value"
  %l39 = alloca ptr
  %l40 = alloca i1
  %l47 = alloca %"compiler/cond:Value"
  %l48 = alloca ptr
  %l49 = alloca i1
  %l62 = alloca %"compiler/cond:Value"
  %l63 = alloca ptr
  %l64 = alloca i1
  %l80 = alloca %"compiler/cond:Value"
  %l81 = alloca ptr
  %l84 = alloca %"compiler/source:Span"
  %l85 = alloca %"compiler/cond:Value"
  %rv = alloca %"compiler/cond:Value"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t2 = load ptr, ptr %l15, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l15, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 28}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l16, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l16, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32 }, ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19, !range !{i32 0, i32 116}
  store i32 %t20, ptr %l3
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load %"compiler/source:Span", ptr %l2
  %t24 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t28 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eliteral(ptr %v0, ptr %t22, %"compiler/source:Span" %t23, i32 %t24)
  store %"compiler/cond:Value" %t28, ptr %l26
  br label %bb6
bb6:
  %t29 = load %"compiler/cond:Value", ptr %l26
  store %"compiler/cond:Value" %t29, ptr %l14
  br label %bb42
bb7:
  %t30 = load ptr, ptr %l1, !tbaa !29
  store ptr %t30, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t31 = load ptr, ptr %l27, !tbaa !29
  %t32 = icmp ne ptr %t31, null
  br i1 %t32, label %bb8, label %bb9
bb8:
  %t34 = load ptr, ptr %l27, !tbaa !29
  %t35 = load i64, ptr %t34, !range !{i64 0, i64 28}
  %t37 = icmp eq i64 %t35, 0
  store i1 %t37, ptr %l28, !tbaa !21
  br label %bb9
bb9:
  %t38 = load i1, ptr %l28, !tbaa !21
  br i1 %t38, label %bb10, label %bb11
bb10:
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr { i64, [4 x i64] }, ptr %t39, i32 0, i32 1
  %t42 = getelementptr { %"compiler/source:Span", i32 }, ptr %t41, i32 0, i32 0
  %t43 = load %"compiler/source:Span", ptr %t42
  store %"compiler/source:Span" %t43, ptr %l4
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t47 = getelementptr { i64, [4 x i64] }, ptr %t45, i32 0, i32 1
  %t48 = getelementptr { %"compiler/source:Span", i32 }, ptr %t47, i32 0, i32 1
  %t49 = load i32, ptr %t48
  store i32 %t49, ptr %l5, !tbaa !23
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load %"compiler/source:Span", ptr %l4
  %t53 = load i32, ptr %l5, !tbaa !23
  %t57 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2ename(ptr %v0, ptr %t51, %"compiler/source:Span" %t52, i32 %t53)
  store %"compiler/cond:Value" %t57, ptr %l38
  br label %bb13
bb13:
  %t58 = load %"compiler/cond:Value", ptr %l38
  store %"compiler/cond:Value" %t58, ptr %l14
  br label %bb42
bb14:
  %t59 = load ptr, ptr %l1, !tbaa !29
  store ptr %t59, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t60 = load ptr, ptr %l39, !tbaa !29
  %t61 = icmp ne ptr %t60, null
  br i1 %t61, label %bb15, label %bb16
bb15:
  %t63 = load ptr, ptr %l39, !tbaa !29
  %t64 = load i64, ptr %t63, !range !{i64 0, i64 28}
  %t66 = icmp eq i64 %t64, 2
  store i1 %t66, ptr %l40, !tbaa !21
  br label %bb16
bb16:
  %t67 = load i1, ptr %l40, !tbaa !21
  br i1 %t67, label %bb17, label %bb18
bb17:
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t70 = getelementptr { i64, [4 x i64] }, ptr %t68, i32 0, i32 1
  %t71 = getelementptr { %"compiler/source:Span", ptr }, ptr %t70, i32 0, i32 1
  %t72 = load ptr, ptr %t71
  store ptr %t72, ptr %l6, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load ptr, ptr %l6, !tbaa !29
  %t78 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eexpr(ptr %v0, ptr %v1, ptr %t74, ptr %t75)
  store %"compiler/cond:Value" %t78, ptr %l47
  br label %bb20
bb20:
  %t79 = load %"compiler/cond:Value", ptr %l47
  store %"compiler/cond:Value" %t79, ptr %l14
  br label %bb42
bb21:
  %t80 = load ptr, ptr %l1, !tbaa !29
  store ptr %t80, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t81 = load ptr, ptr %l48, !tbaa !29
  %t82 = icmp ne ptr %t81, null
  br i1 %t82, label %bb22, label %bb23
bb22:
  %t84 = load ptr, ptr %l48, !tbaa !29
  %t85 = load i64, ptr %t84, !range !{i64 0, i64 28}
  %t87 = icmp eq i64 %t85, 3
  store i1 %t87, ptr %l49, !tbaa !21
  br label %bb23
bb23:
  %t88 = load i1, ptr %l49, !tbaa !21
  br i1 %t88, label %bb24, label %bb25
bb24:
  %t89 = load ptr, ptr %l1, !tbaa !29
  %t91 = getelementptr { i64, [4 x i64] }, ptr %t89, i32 0, i32 1
  %t92 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t91, i32 0, i32 0
  %t93 = load %"compiler/source:Span", ptr %t92
  store %"compiler/source:Span" %t93, ptr %l7
  %t95 = load ptr, ptr %l1, !tbaa !29
  %t97 = getelementptr { i64, [4 x i64] }, ptr %t95, i32 0, i32 1
  %t98 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t97, i32 0, i32 1
  %t99 = load i32, ptr %t98, !range !{i32 0, i32 116}
  store i32 %t99, ptr %l8
  %t101 = load ptr, ptr %l1, !tbaa !29
  %t103 = getelementptr { i64, [4 x i64] }, ptr %t101, i32 0, i32 1
  %t104 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t103, i32 0, i32 2
  %t105 = load ptr, ptr %t104
  store ptr %t105, ptr %l9, !tbaa !29
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load %"compiler/source:Span", ptr %l7
  %t109 = load i32, ptr %l8, !range !{i32 0, i32 116}
  %t110 = load ptr, ptr %l9, !tbaa !29
  %t115 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eunary(ptr %v0, ptr %v1, ptr %t107, %"compiler/source:Span" %t108, i32 %t109, ptr %t110)
  store %"compiler/cond:Value" %t115, ptr %l62
  br label %bb27
bb27:
  %t116 = load %"compiler/cond:Value", ptr %l62
  store %"compiler/cond:Value" %t116, ptr %l14
  br label %bb42
bb28:
  %t117 = load ptr, ptr %l1, !tbaa !29
  store ptr %t117, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t118 = load ptr, ptr %l63, !tbaa !29
  %t119 = icmp ne ptr %t118, null
  br i1 %t119, label %bb29, label %bb30
bb29:
  %t121 = load ptr, ptr %l63, !tbaa !29
  %t122 = load i64, ptr %t121, !range !{i64 0, i64 28}
  %t124 = icmp eq i64 %t122, 5
  store i1 %t124, ptr %l64, !tbaa !21
  br label %bb30
bb30:
  %t125 = load i1, ptr %l64, !tbaa !21
  br i1 %t125, label %bb31, label %bb32
bb31:
  %t126 = load ptr, ptr %l1, !tbaa !29
  %t128 = getelementptr { i64, [4 x i64] }, ptr %t126, i32 0, i32 1
  %t129 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t128, i32 0, i32 0
  %t130 = load %"compiler/source:Span", ptr %t129
  store %"compiler/source:Span" %t130, ptr %l10
  %t132 = load ptr, ptr %l1, !tbaa !29
  %t134 = getelementptr { i64, [4 x i64] }, ptr %t132, i32 0, i32 1
  %t135 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t134, i32 0, i32 1
  %t136 = load i32, ptr %t135, !range !{i32 0, i32 116}
  store i32 %t136, ptr %l11
  %t138 = load ptr, ptr %l1, !tbaa !29
  %t140 = getelementptr { i64, [4 x i64] }, ptr %t138, i32 0, i32 1
  %t141 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t140, i32 0, i32 2
  %t142 = load ptr, ptr %t141
  store ptr %t142, ptr %l12, !tbaa !29
  %t144 = load ptr, ptr %l1, !tbaa !29
  %t146 = getelementptr { i64, [4 x i64] }, ptr %t144, i32 0, i32 1
  %t147 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t146, i32 0, i32 3
  %t148 = load ptr, ptr %t147
  store ptr %t148, ptr %l13, !tbaa !29
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t151 = load %"compiler/source:Span", ptr %l10
  %t152 = load i32, ptr %l11, !range !{i32 0, i32 116}
  %t153 = load ptr, ptr %l12, !tbaa !29
  %t154 = load ptr, ptr %l13, !tbaa !29
  %t160 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2ebinary(ptr %v0, ptr %v1, ptr %v1, ptr %t150, %"compiler/source:Span" %t151, i32 %t152, ptr %t153, ptr %t154)
  store %"compiler/cond:Value" %t160, ptr %l80
  br label %bb34
bb34:
  %t161 = load %"compiler/cond:Value", ptr %l80
  store %"compiler/cond:Value" %t161, ptr %l14
  br label %bb42
bb35:
  br i1 true, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb41
bb38:
  %t162 = load ptr, ptr %l0, !tbaa !29
  store ptr %t162, ptr %l81, !tbaa !29
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load ptr, ptr %l1, !tbaa !29
  %t167 = call %"compiler/source:Span" @compiler_2fcond_2ecompiler_2fcond_3aEval_2efirst(ptr %v0, ptr %v1, ptr %t163, ptr %t164)
  store %"compiler/source:Span" %t167, ptr %l84
  br label %bb39
bb39:
  %t168 = load ptr, ptr %l81, !tbaa !29
  %t169 = load %"compiler/source:Span", ptr %l84
  %t170 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t168, %"compiler/source:Span" %t169)
  store %"compiler/cond:Value" %t170, ptr %l85
  br label %bb40
bb40:
  %t171 = load %"compiler/cond:Value", ptr %l85
  store %"compiler/cond:Value" %t171, ptr %l14
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_4f7f4596ea7a5dcf_15046327e746a0a3)
  unreachable
bb42:
  %t172 = load %"compiler/cond:Value", ptr %l14
  store %"compiler/cond:Value" %t172, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cond:Value", ptr %rv
  ret %"compiler/cond:Value" %rr
}

define dso_local %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2efail(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/diagmsg:Msg" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l9 = alloca ptr
  %l11 = alloca %"compiler/diagmsg:Msg"
  %l16 = alloca %"compiler/cond:Value"
  %rv = alloca %"compiler/cond:Value"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/cond:Eval", ptr %t1, i32 0, i32 4
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/cond:Eval", ptr %t8, i32 0, i32 4
  store i1 true, ptr %t10, !tbaa !21
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/cond:Eval", ptr %t11, i32 0, i32 7
  store %"compiler/source:Span" %a1, ptr %t15
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l9, !tbaa !29
  %t18 = load ptr, ptr %l9, !tbaa !29
  %t19 = getelementptr %"compiler/cond:Eval", ptr %t18, i32 0, i32 8
  %t20 = load %"compiler/diagmsg:Msg", ptr %t19
  store %"compiler/diagmsg:Msg" %t20, ptr %l11
  %t22 = load ptr, ptr %l9, !tbaa !29
  %t23 = getelementptr %"compiler/cond:Eval", ptr %t22, i32 0, i32 8
  store %"compiler/diagmsg:Msg" %a2, ptr %t23
  %t24 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e1
  br i1 %t24, label %bb3, label %bb4
bb2:
  br label %bb11
bb3:
  %t26 = getelementptr %"compiler/diagmsg:Msg", ptr %l11, i32 0, i32 1
  %t27 = load { i64, ptr }, ptr %t26
  %t28 = extractvalue { i64, ptr } %t27, 1
  call void @__olang_region_release(ptr %t28)
  store { i64, ptr } zeroinitializer, ptr %t26
  br label %bb4
bb4:
  %t29 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t29, label %bb5, label %bb6
bb5:
  %t31 = getelementptr %"compiler/diagmsg:Msg", ptr %l11, i32 0, i32 2
  %t32 = load { i64, ptr }, ptr %t31
  %t33 = extractvalue { i64, ptr } %t32, 1
  call void @__olang_region_release(ptr %t33)
  store { i64, ptr } zeroinitializer, ptr %t31
  br label %bb6
bb6:
  %t34 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3
  br i1 %t34, label %bb7, label %bb8
bb7:
  %t36 = getelementptr %"compiler/diagmsg:Msg", ptr %l11, i32 0, i32 3
  %t37 = load { i64, ptr }, ptr %t36
  %t38 = extractvalue { i64, ptr } %t37, 1
  call void @__olang_region_release(ptr %t38)
  store { i64, ptr } zeroinitializer, ptr %t36
  br label %bb8
bb8:
  %t39 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t39, label %bb9, label %bb10
bb9:
  %t41 = getelementptr %"compiler/diagmsg:Msg", ptr %l11, i32 0, i32 4
  %t42 = load { i64, ptr }, ptr %t41
  %t43 = extractvalue { i64, ptr } %t42, 1
  call void @__olang_region_release(ptr %t43)
  store { i64, ptr } zeroinitializer, ptr %t41
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t44 = call %"compiler/cond:Value" @compiler_2fcond_2eValue_2enone()
  store %"compiler/cond:Value" %t44, ptr %l16
  br label %bb12
bb12:
  %t45 = load %"compiler/cond:Value", ptr %l16
  store %"compiler/cond:Value" %t45, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cond:Value", ptr %rv
  ret %"compiler/cond:Value" %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcond_2ecompiler_2fcond_3aEval_2efirst(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca ptr
  %l10 = alloca i1
  %l17 = alloca %"compiler/source:Span"
  %l18 = alloca ptr
  %l19 = alloca i1
  %l26 = alloca { i64, ptr }
  %l28 = alloca %"compiler/source:Span"
  %l29 = alloca ptr
  %l30 = alloca i1
  %l37 = alloca %"compiler/source:Span"
  %l38 = alloca ptr
  %l39 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca i1
  %l58 = alloca %"compiler/source:Span"
  %l59 = alloca ptr
  %l60 = alloca i1
  %l67 = alloca %"compiler/source:Span"
  %l68 = alloca ptr
  %l69 = alloca i1
  %l74 = alloca ptr
  %l75 = alloca i1
  %l81 = alloca ptr
  %l83 = alloca %"compiler/source:Span"
  %l85 = alloca %"compiler/source:Span"
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 28}
  %t8 = icmp eq i64 %t6, 5
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t20 = call %"compiler/source:Span" @compiler_2fcond_2ecompiler_2fcond_3aEval_2efirst(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store %"compiler/source:Span" %t20, ptr %l17
  br label %bb6
bb6:
  %t21 = load %"compiler/source:Span", ptr %l17
  store %"compiler/source:Span" %t21, ptr %l8
  br label %bb60
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t23 = load ptr, ptr %l18, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l18, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 28}
  %t29 = icmp eq i64 %t27, 7
  store i1 %t29, ptr %l19, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l19, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", ptr }, ptr %t33, i32 0, i32 1
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t40 = getelementptr %"compiler/ast:Chain", ptr %t38, i32 0, i32 1
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  store { i64, ptr } %t41, ptr %l26, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr ptr, ptr %t43, i64 0
  %t45 = load ptr, ptr %t44, !tbaa !39
  %t48 = call %"compiler/source:Span" @compiler_2fcond_2ecompiler_2fcond_3aEval_2efirst(ptr %v0, ptr %v1, ptr %t37, ptr %t45)
  store %"compiler/source:Span" %t48, ptr %l28
  br label %bb13
bb13:
  %t49 = load %"compiler/source:Span", ptr %l28
  store %"compiler/source:Span" %t49, ptr %l8
  br label %bb60
bb14:
  %t50 = load ptr, ptr %l1, !tbaa !29
  store ptr %t50, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t51 = load ptr, ptr %l29, !tbaa !29
  %t52 = icmp ne ptr %t51, null
  br i1 %t52, label %bb15, label %bb16
bb15:
  %t54 = load ptr, ptr %l29, !tbaa !29
  %t55 = load i64, ptr %t54, !range !{i64 0, i64 28}
  %t57 = icmp eq i64 %t55, 8
  store i1 %t57, ptr %l30, !tbaa !21
  br label %bb16
bb16:
  %t58 = load i1, ptr %l30, !tbaa !21
  br i1 %t58, label %bb17, label %bb18
bb17:
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr { i64, [4 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t61, i32 0, i32 1
  %t63 = load ptr, ptr %t62
  store ptr %t63, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load ptr, ptr %l4, !tbaa !29
  %t69 = call %"compiler/source:Span" @compiler_2fcond_2ecompiler_2fcond_3aEval_2efirst(ptr %v0, ptr %v1, ptr %t65, ptr %t66)
  store %"compiler/source:Span" %t69, ptr %l37
  br label %bb20
bb20:
  %t70 = load %"compiler/source:Span", ptr %l37
  store %"compiler/source:Span" %t70, ptr %l8
  br label %bb60
bb21:
  %t71 = load ptr, ptr %l1, !tbaa !29
  store ptr %t71, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t72 = load ptr, ptr %l38, !tbaa !29
  %t73 = icmp ne ptr %t72, null
  br i1 %t73, label %bb22, label %bb23
bb22:
  %t75 = load ptr, ptr %l38, !tbaa !29
  %t76 = load i64, ptr %t75, !range !{i64 0, i64 28}
  %t78 = icmp eq i64 %t76, 10
  store i1 %t78, ptr %l39, !tbaa !21
  br label %bb23
bb23:
  %t79 = load i1, ptr %l39, !tbaa !21
  br i1 %t79, label %bb24, label %bb25
bb24:
  %t80 = load ptr, ptr %l1, !tbaa !29
  %t82 = getelementptr { i64, [4 x i64] }, ptr %t80, i32 0, i32 1
  %t83 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t82, i32 0, i32 1
  %t84 = load ptr, ptr %t83
  store ptr %t84, ptr %l5, !tbaa !29
  br label %bb34
bb25:
  %t86 = load ptr, ptr %l1, !tbaa !29
  store ptr %t86, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t87 = load ptr, ptr %l44, !tbaa !29
  %t88 = icmp ne ptr %t87, null
  br i1 %t88, label %bb26, label %bb27
bb26:
  %t90 = load ptr, ptr %l44, !tbaa !29
  %t91 = load i64, ptr %t90, !range !{i64 0, i64 28}
  %t93 = icmp eq i64 %t91, 12
  store i1 %t93, ptr %l45, !tbaa !21
  br label %bb27
bb27:
  %t94 = load i1, ptr %l45, !tbaa !21
  br i1 %t94, label %bb28, label %bb29
bb28:
  %t95 = load ptr, ptr %l1, !tbaa !29
  %t97 = getelementptr { i64, [4 x i64] }, ptr %t95, i32 0, i32 1
  %t98 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t97, i32 0, i32 1
  %t99 = load ptr, ptr %t98
  store ptr %t99, ptr %l5, !tbaa !29
  br label %bb34
bb29:
  %t101 = load ptr, ptr %l1, !tbaa !29
  store ptr %t101, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t102 = load ptr, ptr %l50, !tbaa !29
  %t103 = icmp ne ptr %t102, null
  br i1 %t103, label %bb30, label %bb31
bb30:
  %t105 = load ptr, ptr %l50, !tbaa !29
  %t106 = load i64, ptr %t105, !range !{i64 0, i64 28}
  %t108 = icmp eq i64 %t106, 13
  store i1 %t108, ptr %l51, !tbaa !21
  br label %bb31
bb31:
  %t109 = load i1, ptr %l51, !tbaa !21
  br i1 %t109, label %bb32, label %bb33
bb32:
  %t110 = load ptr, ptr %l1, !tbaa !29
  %t112 = getelementptr { i64, [4 x i64] }, ptr %t110, i32 0, i32 1
  %t113 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t112, i32 0, i32 1
  %t114 = load ptr, ptr %t113
  store ptr %t114, ptr %l5, !tbaa !29
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load ptr, ptr %l5, !tbaa !29
  %t120 = call %"compiler/source:Span" @compiler_2fcond_2ecompiler_2fcond_3aEval_2efirst(ptr %v0, ptr %v1, ptr %t116, ptr %t117)
  store %"compiler/source:Span" %t120, ptr %l58
  br label %bb35
bb35:
  %t121 = load %"compiler/source:Span", ptr %l58
  store %"compiler/source:Span" %t121, ptr %l8
  br label %bb60
bb36:
  %t122 = load ptr, ptr %l1, !tbaa !29
  store ptr %t122, ptr %l59, !tbaa !29
  store i1 false, ptr %l60, !tbaa !21
  %t123 = load ptr, ptr %l59, !tbaa !29
  %t124 = icmp ne ptr %t123, null
  br i1 %t124, label %bb37, label %bb38
bb37:
  %t126 = load ptr, ptr %l59, !tbaa !29
  %t127 = load i64, ptr %t126, !range !{i64 0, i64 28}
  %t129 = icmp eq i64 %t127, 9
  store i1 %t129, ptr %l60, !tbaa !21
  br label %bb38
bb38:
  %t130 = load i1, ptr %l60, !tbaa !21
  br i1 %t130, label %bb39, label %bb40
bb39:
  %t131 = load ptr, ptr %l1, !tbaa !29
  %t133 = getelementptr { i64, [4 x i64] }, ptr %t131, i32 0, i32 1
  %t134 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t133, i32 0, i32 1
  %t135 = load ptr, ptr %t134
  store ptr %t135, ptr %l6, !tbaa !29
  br label %bb41
bb40:
  br label %bb43
bb41:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load ptr, ptr %l6, !tbaa !29
  %t141 = call %"compiler/source:Span" @compiler_2fcond_2ecompiler_2fcond_3aEval_2efirst(ptr %v0, ptr %v1, ptr %t137, ptr %t138)
  store %"compiler/source:Span" %t141, ptr %l67
  br label %bb42
bb42:
  %t142 = load %"compiler/source:Span", ptr %l67
  store %"compiler/source:Span" %t142, ptr %l8
  br label %bb60
bb43:
  %t143 = load ptr, ptr %l1, !tbaa !29
  store ptr %t143, ptr %l68, !tbaa !29
  store i1 false, ptr %l69, !tbaa !21
  %t144 = load ptr, ptr %l68, !tbaa !29
  %t145 = icmp ne ptr %t144, null
  br i1 %t145, label %bb44, label %bb45
bb44:
  %t147 = load ptr, ptr %l68, !tbaa !29
  %t148 = load i64, ptr %t147, !range !{i64 0, i64 28}
  %t150 = icmp eq i64 %t148, 1
  store i1 %t150, ptr %l69, !tbaa !21
  br label %bb45
bb45:
  %t151 = load i1, ptr %l69, !tbaa !21
  br i1 %t151, label %bb46, label %bb47
bb46:
  %t152 = load ptr, ptr %l1, !tbaa !29
  %t154 = getelementptr { i64, [4 x i64] }, ptr %t152, i32 0, i32 1
  %t155 = getelementptr { %"compiler/source:Span", i32 }, ptr %t154, i32 0, i32 0
  %t156 = load %"compiler/source:Span", ptr %t155
  store %"compiler/source:Span" %t156, ptr %l7
  br label %bb52
bb47:
  %t158 = load ptr, ptr %l1, !tbaa !29
  store ptr %t158, ptr %l74, !tbaa !29
  store i1 false, ptr %l75, !tbaa !21
  %t159 = load ptr, ptr %l74, !tbaa !29
  %t160 = icmp ne ptr %t159, null
  br i1 %t160, label %bb48, label %bb49
bb48:
  %t162 = load ptr, ptr %l74, !tbaa !29
  %t163 = load i64, ptr %t162, !range !{i64 0, i64 28}
  %t165 = icmp eq i64 %t163, 0
  store i1 %t165, ptr %l75, !tbaa !21
  br label %bb49
bb49:
  %t166 = load i1, ptr %l75, !tbaa !21
  br i1 %t166, label %bb50, label %bb51
bb50:
  %t167 = load ptr, ptr %l1, !tbaa !29
  %t169 = getelementptr { i64, [4 x i64] }, ptr %t167, i32 0, i32 1
  %t170 = getelementptr { %"compiler/source:Span", i32 }, ptr %t169, i32 0, i32 0
  %t171 = load %"compiler/source:Span", ptr %t170
  store %"compiler/source:Span" %t171, ptr %l7
  br label %bb52
bb51:
  br label %bb53
bb52:
  %t173 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t173, ptr %l8
  br label %bb60
bb53:
  br i1 true, label %bb54, label %bb55
bb54:
  br label %bb56
bb55:
  br label %bb59
bb56:
  %t175 = load ptr, ptr %l0, !tbaa !29
  store ptr %t175, ptr %l81, !tbaa !29
  %t176 = load ptr, ptr %l1, !tbaa !29
  %t178 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t176)
  store %"compiler/source:Span" %t178, ptr %l83
  br label %bb57
bb57:
  %t179 = getelementptr %"compiler/source:Span", ptr %l83, i32 0, i32 0
  %t180 = load i32, ptr %t179, !tbaa !23
  %t181 = load ptr, ptr %l81, !tbaa !29
  %t183 = call %"compiler/source:Span" @compiler_2fcond_2ecompiler_2fcond_3aEval_2etokenAt(ptr %v0, ptr %t181, i32 %t180)
  store %"compiler/source:Span" %t183, ptr %l85
  br label %bb58
bb58:
  %t184 = load %"compiler/source:Span", ptr %l85
  store %"compiler/source:Span" %t184, ptr %l8
  br label %bb60
bb59:
  call void @__olang_check_failed(ptr @olang_loc_c6445e8eb561a5e0_a28b098f67507e74)
  unreachable
bb60:
  %t185 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t185, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2eisFixed(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i64
  %l15 = alloca i32
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/cond:Eval", ptr %a0, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/cond:Scope", ptr %t4, i32 0, i32 3
  store ptr %t6, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l3, !tbaa !24
  store i64 %t8, ptr %l8, !tbaa !24
  %t9 = load ptr, ptr %l2, !tbaa !29
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l10
  br label %bb2
bb2:
  %t12 = load i64, ptr %l8, !tbaa !24
  %t13 = load i64, ptr %l10, !tbaa !24
  %t14 = icmp slt i64 %t12, %t13
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t19 = load i64, ptr %l3, !tbaa !24
  %t22 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t18, i64 %t19)
  store i32 %t22, ptr %l15
  br label %bb6
bb6:
  %t23 = load i32, ptr %l15, !tbaa !23
  %t28 = icmp eq i32 %t23, %a1
  br i1 %t28, label %bb7, label %bb8
bb7:
  store i1 true, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t31 = load i64, ptr %l3, !tbaa !24
  %t34 = add i64 %t31, 1
  store i64 %t34, ptr %l3, !tbaa !24
  br label %bb1
bb11:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2eisLocal(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i64
  %l7 = alloca i1
  %l12 = alloca i64
  %l14 = alloca i64
  %l19 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2eisFixed(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load i1, ptr %l7, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/cond:Eval", ptr %t8, i32 0, i32 2
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/cond:Scope", ptr %t11, i32 0, i32 2
  store ptr %t13, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb5
bb5:
  %t15 = load i64, ptr %l3, !tbaa !24
  store i64 %t15, ptr %l12, !tbaa !24
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t16)
  store i64 %t18, ptr %l14
  br label %bb6
bb6:
  %t19 = load i64, ptr %l12, !tbaa !24
  %t20 = load i64, ptr %l14, !tbaa !24
  %t21 = icmp slt i64 %t19, %t20
  %t23 = xor i1 %t21, true
  br i1 %t23, label %bb7, label %bb8
bb7:
  br label %bb15
bb8:
  br label %bb9
bb9:
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t26 = load i64, ptr %l3, !tbaa !24
  %t29 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t25, i64 %t26)
  store i32 %t29, ptr %l19
  br label %bb10
bb10:
  %t30 = load i32, ptr %l19, !tbaa !23
  %t32 = load i32, ptr %l1, !tbaa !23
  %t35 = icmp eq i32 %t30, %t32
  br i1 %t35, label %bb11, label %bb12
bb11:
  store i1 true, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t38 = load i64, ptr %l3, !tbaa !24
  %t41 = add i64 %t38, 1
  store i64 %t41, ptr %l3, !tbaa !24
  br label %bb5
bb15:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2elogic(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l5 = alloca %"compiler/cond:Value"
  %l6 = alloca i1
  %l7 = alloca %"compiler/cond:Value"
  %l10 = alloca %"compiler/cond:Value"
  %l14 = alloca i1
  %l17 = alloca i1
  %l18 = alloca i64
  %l21 = alloca i64
  %l24 = alloca ptr
  %l30 = alloca %"compiler/cond:Value"
  %l32 = alloca ptr
  %l40 = alloca i1
  %l44 = alloca i1
  %l48 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca %"compiler/source:Span"
  %l56 = alloca { i64, ptr }
  %l58 = alloca %"compiler/diagmsg:Msg"
  %l59 = alloca %"compiler/cond:Value"
  %l62 = alloca i1
  %l65 = alloca %"compiler/cond:Value"
  %l70 = alloca i1
  %l73 = alloca %"compiler/cond:Value"
  %l76 = alloca i1
  %l79 = alloca %"compiler/cond:Value"
  %s3 = alloca %olang.scope
  %rv = alloca %"compiler/cond:Value"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eexpr(ptr %v0, ptr %v1, ptr %t1, ptr %a3)
  store %"compiler/cond:Value" %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load %"compiler/cond:Value", ptr %l10
  store %"compiler/cond:Value" %t6, ptr %l5
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/cond:Eval", ptr %t7, i32 0, i32 4
  %t10 = load i1, ptr %t9, !tbaa !21
  %t12 = xor i1 %t10, true
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t14 = getelementptr %"compiler/cond:Value", ptr %l5, i32 0, i32 0
  %t15 = load i32, ptr %t14, !range !{i32 0, i32 5}
  %t17 = trunc i64 1 to i32
  %t18 = icmp eq i32 %t15, %t17
  store i1 %t18, ptr %l14, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb4
bb4:
  %t20 = load i1, ptr %l14, !tbaa !21
  br i1 %t20, label %bb5, label %bb6
bb5:
  %t21 = getelementptr %"compiler/cond:Value", ptr %l5, i32 0, i32 1
  %t22 = load i64, ptr %t21, !tbaa !24
  store i64 %t22, ptr %l18, !tbaa !24
  %t23 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t25 = trunc i64 46 to i32
  %t26 = icmp eq i32 %t23, %t25
  br i1 %t26, label %bb7, label %bb8
bb6:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb10
bb7:
  store i64 1, ptr %l21, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb9
bb9:
  %t28 = load i64, ptr %l18, !tbaa !24
  %t29 = load i64, ptr %l21, !tbaa !24
  %t30 = icmp eq i64 %t28, %t29
  store i1 %t30, ptr %l17, !tbaa !21
  br label %bb10
bb10:
  %t32 = load i1, ptr %l17, !tbaa !21
  store i1 %t32, ptr %l6, !tbaa !21
  %t33 = load i1, ptr %l6, !tbaa !21
  br i1 %t33, label %bb11, label %bb12
bb11:
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l24, !tbaa !29
  %t36 = load ptr, ptr %l24, !tbaa !29
  %t37 = getelementptr %"compiler/cond:Eval", ptr %t36, i32 0, i32 10
  %t38 = load i64, ptr %t37, !tbaa !24
  %t41 = add i64 %t38, 1
  %t43 = load ptr, ptr %l24, !tbaa !29
  %t44 = getelementptr %"compiler/cond:Eval", ptr %t43, i32 0, i32 10
  store i64 %t41, ptr %t44, !tbaa !24
  br label %bb13
bb12:
  br label %bb13
bb13:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t49 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eexpr(ptr %v0, ptr %v2, ptr %t45, ptr %a4)
  store %"compiler/cond:Value" %t49, ptr %l30
  br label %bb14
bb14:
  %t50 = load %"compiler/cond:Value", ptr %l30
  store %"compiler/cond:Value" %t50, ptr %l7
  %t51 = load i1, ptr %l6, !tbaa !21
  br i1 %t51, label %bb15, label %bb16
bb15:
  %t53 = load ptr, ptr %l0, !tbaa !29
  store ptr %t53, ptr %l32, !tbaa !29
  %t54 = load ptr, ptr %l32, !tbaa !29
  %t55 = getelementptr %"compiler/cond:Eval", ptr %t54, i32 0, i32 10
  %t56 = load i64, ptr %t55, !tbaa !24
  %t59 = sub i64 %t56, 1
  %t61 = load ptr, ptr %l32, !tbaa !29
  %t62 = getelementptr %"compiler/cond:Eval", ptr %t61, i32 0, i32 10
  store i64 %t59, ptr %t62, !tbaa !24
  %t63 = load %"compiler/cond:Value", ptr %l5
  store %"compiler/cond:Value" %t63, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t65 = getelementptr %"compiler/cond:Value", ptr %l5, i32 0, i32 0
  %t66 = load i32, ptr %t65, !range !{i32 0, i32 5}
  %t68 = trunc i64 0 to i32
  %t69 = icmp eq i32 %t66, %t68
  %t71 = xor i1 %t69, true
  br i1 %t71, label %bb18, label %bb19
bb18:
  %t73 = getelementptr %"compiler/cond:Value", ptr %l5, i32 0, i32 0
  %t74 = load i32, ptr %t73, !range !{i32 0, i32 5}
  %t76 = trunc i64 1 to i32
  %t77 = icmp eq i32 %t74, %t76
  %t79 = xor i1 %t77, true
  store i1 %t79, ptr %l40, !tbaa !21
  br label %bb20
bb19:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb20
bb20:
  %t81 = load i1, ptr %l40, !tbaa !21
  br i1 %t81, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l44, !tbaa !21
  br label %bb26
bb22:
  %t82 = getelementptr %"compiler/cond:Value", ptr %l7, i32 0, i32 0
  %t83 = load i32, ptr %t82, !range !{i32 0, i32 5}
  %t85 = trunc i64 0 to i32
  %t86 = icmp eq i32 %t83, %t85
  %t88 = xor i1 %t86, true
  br i1 %t88, label %bb23, label %bb24
bb23:
  %t90 = getelementptr %"compiler/cond:Value", ptr %l7, i32 0, i32 0
  %t91 = load i32, ptr %t90, !range !{i32 0, i32 5}
  %t93 = trunc i64 1 to i32
  %t94 = icmp eq i32 %t91, %t93
  %t96 = xor i1 %t94, true
  store i1 %t96, ptr %l48, !tbaa !21
  br label %bb25
bb24:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb25
bb25:
  %t98 = load i1, ptr %l48, !tbaa !21
  store i1 %t98, ptr %l44, !tbaa !21
  br label %bb26
bb26:
  %t99 = load i1, ptr %l44, !tbaa !21
  br i1 %t99, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s3
  %t100 = load ptr, ptr %l0, !tbaa !29
  store ptr %t100, ptr %l52, !tbaa !29
  %t101 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t101, ptr %l53
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load %"compiler/source:Span", ptr %l1
  %t106 = call { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aEval_2etokText(ptr %v0, ptr %s3, ptr %t102, %"compiler/source:Span" %t103)
  store { i64, ptr } %t106, ptr %l56
  br label %bb29
bb28:
  br label %bb32
bb29:
  %t107 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t109 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCondTypes(ptr %s3, ptr %v0, { i64, ptr } %t107)
  store %"compiler/diagmsg:Msg" %t109, ptr %l58
  br label %bb30
bb30:
  %t110 = load ptr, ptr %l52, !tbaa !29
  %t111 = load %"compiler/source:Span", ptr %l53
  %t112 = load %"compiler/diagmsg:Msg", ptr %l58
  %t113 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2efail(ptr %v0, ptr %v0, ptr %t110, %"compiler/source:Span" %t111, %"compiler/diagmsg:Msg" %t112)
  store %"compiler/cond:Value" %t113, ptr %l59
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s3)
  %t114 = load %"compiler/cond:Value", ptr %l59
  store %"compiler/cond:Value" %t114, ptr %rv
  br label %ret
bb32:
  %t115 = getelementptr %"compiler/cond:Value", ptr %l5, i32 0, i32 0
  %t116 = load i32, ptr %t115, !range !{i32 0, i32 5}
  %t118 = trunc i64 0 to i32
  %t119 = icmp eq i32 %t116, %t118
  br i1 %t119, label %bb33, label %bb34
bb33:
  store i1 true, ptr %l62, !tbaa !21
  br label %bb35
bb34:
  %t121 = getelementptr %"compiler/cond:Value", ptr %l7, i32 0, i32 0
  %t122 = load i32, ptr %t121, !range !{i32 0, i32 5}
  %t124 = trunc i64 0 to i32
  %t125 = icmp eq i32 %t122, %t124
  store i1 %t125, ptr %l62, !tbaa !21
  br label %bb35
bb35:
  %t127 = load i1, ptr %l62, !tbaa !21
  br i1 %t127, label %bb36, label %bb37
bb36:
  %t128 = call %"compiler/cond:Value" @compiler_2fcond_2eValue_2enone()
  store %"compiler/cond:Value" %t128, ptr %l65
  br label %bb38
bb37:
  br label %bb39
bb38:
  %t129 = load %"compiler/cond:Value", ptr %l65
  store %"compiler/cond:Value" %t129, ptr %rv
  br label %ret
bb39:
  %t130 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t132 = trunc i64 46 to i32
  %t133 = icmp eq i32 %t130, %t132
  br i1 %t133, label %bb40, label %bb41
bb40:
  %t135 = getelementptr %"compiler/cond:Value", ptr %l5, i32 0, i32 1
  %t136 = load i64, ptr %t135, !tbaa !24
  %t138 = icmp ne i64 %t136, 0
  br i1 %t138, label %bb42, label %bb43
bb41:
  br label %bb46
bb42:
  store i1 true, ptr %l70, !tbaa !21
  br label %bb44
bb43:
  %t140 = getelementptr %"compiler/cond:Value", ptr %l7, i32 0, i32 1
  %t141 = load i64, ptr %t140, !tbaa !24
  %t143 = icmp ne i64 %t141, 0
  store i1 %t143, ptr %l70, !tbaa !21
  br label %bb44
bb44:
  %t145 = load i1, ptr %l70, !tbaa !21
  %t146 = call %"compiler/cond:Value" @compiler_2fcond_2eValue_2ebool(i1 %t145)
  store %"compiler/cond:Value" %t146, ptr %l73
  br label %bb45
bb45:
  %t147 = load %"compiler/cond:Value", ptr %l73
  store %"compiler/cond:Value" %t147, ptr %rv
  br label %ret
bb46:
  %t148 = getelementptr %"compiler/cond:Value", ptr %l5, i32 0, i32 1
  %t149 = load i64, ptr %t148, !tbaa !24
  %t151 = icmp ne i64 %t149, 0
  br i1 %t151, label %bb47, label %bb48
bb47:
  %t153 = getelementptr %"compiler/cond:Value", ptr %l7, i32 0, i32 1
  %t154 = load i64, ptr %t153, !tbaa !24
  %t156 = icmp ne i64 %t154, 0
  store i1 %t156, ptr %l76, !tbaa !21
  br label %bb49
bb48:
  store i1 false, ptr %l76, !tbaa !21
  br label %bb49
bb49:
  %t158 = load i1, ptr %l76, !tbaa !21
  %t159 = call %"compiler/cond:Value" @compiler_2fcond_2eValue_2ebool(i1 %t158)
  store %"compiler/cond:Value" %t159, ptr %l79
  br label %bb50
bb50:
  %t160 = load %"compiler/cond:Value", ptr %l79
  store %"compiler/cond:Value" %t160, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cond:Value", ptr %rv
  ret %"compiler/cond:Value" %rr
}

define dso_local %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2ename(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"compiler/cond:Value"
  %l9 = alloca i1
  %l12 = alloca %"compiler/cond:Value"
  %l15 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca %"compiler/source:Span"
  %l20 = alloca { i64, ptr }
  %l22 = alloca %"compiler/diagmsg:Msg"
  %l23 = alloca %"compiler/cond:Value"
  %l27 = alloca { i64, ptr }
  %l28 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca i32
  %l40 = alloca %"compiler/cond:Value"
  %l41 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i32
  %l53 = alloca i1
  %l54 = alloca i1
  %l59 = alloca i1
  %l63 = alloca %"compiler/cond:Value"
  %l66 = alloca %"compiler/cond:Value"
  %l74 = alloca %"compiler/cond:Value"
  %s2 = alloca %olang.scope
  %rv = alloca %"compiler/cond:Value"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2eisFixed(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i1, ptr %l9, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load %"compiler/source:Span", ptr %l1
  %t11 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t7, %"compiler/source:Span" %t8)
  store %"compiler/cond:Value" %t11, ptr %l12
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t12 = load %"compiler/cond:Value", ptr %l12
  store %"compiler/cond:Value" %t12, ptr %rv
  br label %ret
bb5:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i32, ptr %l2, !tbaa !23
  %t17 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2eisLocal(ptr %v0, ptr %t13, i32 %t14)
  store i1 %t17, ptr %l15
  br label %bb6
bb6:
  %t18 = load i1, ptr %l15, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l16, !tbaa !29
  %t20 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t20, ptr %l17
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load %"compiler/source:Span", ptr %l1
  %t25 = call { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aEval_2etokText(ptr %v0, ptr %s2, ptr %t21, %"compiler/source:Span" %t22)
  store { i64, ptr } %t25, ptr %l20
  br label %bb9
bb8:
  br label %bb12
bb9:
  %t26 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t28 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCondName(ptr %s2, ptr %v0, { i64, ptr } %t26)
  store %"compiler/diagmsg:Msg" %t28, ptr %l22
  br label %bb10
bb10:
  %t29 = load ptr, ptr %l16, !tbaa !29
  %t30 = load %"compiler/source:Span", ptr %l17
  %t31 = load %"compiler/diagmsg:Msg", ptr %l22
  %t32 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eruntimeValue(ptr %v0, ptr %v0, ptr %t29, %"compiler/source:Span" %t30, %"compiler/diagmsg:Msg" %t31, i1 true)
  store %"compiler/cond:Value" %t32, ptr %l23
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s2)
  %t33 = load %"compiler/cond:Value", ptr %l23
  store %"compiler/cond:Value" %t33, ptr %rv
  br label %ret
bb12:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/cond:Eval", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t38 = load i32, ptr %l2, !tbaa !23
  %t41 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t37, i32 %t38)
  store { i64, ptr } %t41, ptr %l27
  br label %bb13
bb13:
  %t42 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t42, ptr %l3, !tbaa !27
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/cond:Eval", ptr %t43, i32 0, i32 2
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t47 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t50 = call { i32, ptr } @compiler_2fcond_2ecompiler_2fcond_3aScope_2efind(ptr %v0, ptr %v0, ptr %v0, ptr %t46, { i64, ptr } %t47)
  %t51 = extractvalue { i32, ptr } %t50, 1
  %t52 = extractvalue { i32, ptr } %t50, 0
  store i32 %t52, ptr %l33
  %t53 = icmp ne i32 %t52, 0
  br i1 %t53, label %bb15, label %ok.54, !prof !99
ok.54:
  store ptr %t51, ptr %l32
  br label %bb14
bb14:
  %t55 = load ptr, ptr %l32, !tbaa !29
  store ptr %t55, ptr %l28, !tbaa !29
  br label %bb17
bb15:
  br label %bb16
bb16:
  store ptr null, ptr %l28, !tbaa !29
  br label %bb17
bb17:
  %t56 = load ptr, ptr %l28, !tbaa !29
  store ptr %t56, ptr %l4, !tbaa !29
  %t57 = load ptr, ptr %l4, !tbaa !29
  %t59 = icmp eq ptr %t57, null
  %t61 = xor i1 %t59, true
  br i1 %t61, label %bb18, label %bb19
bb18:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load %"compiler/source:Span", ptr %l1
  %t65 = load ptr, ptr %l4, !tbaa !29
  %t69 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eglobal(ptr %v0, ptr %v0, ptr %t63, %"compiler/source:Span" %t64, ptr %t65)
  store %"compiler/cond:Value" %t69, ptr %l40
  br label %bb20
bb19:
  br label %bb21
bb20:
  %t70 = load %"compiler/cond:Value", ptr %l40
  store %"compiler/cond:Value" %t70, ptr %rv
  br label %ret
bb21:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/cond:Eval", ptr %t71, i32 0, i32 3
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t75 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t78 = call { i32, i64 } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2efind(ptr %v0, ptr %v0, ptr %t74, { i64, ptr } %t75)
  %t79 = extractvalue { i32, i64 } %t78, 1
  %t80 = extractvalue { i32, i64 } %t78, 0
  store i32 %t80, ptr %l46
  %t81 = icmp ne i32 %t80, 0
  br i1 %t81, label %bb23, label %ok.82, !prof !99
ok.82:
  store i64 %t79, ptr %l45
  br label %bb22
bb22:
  %t83 = load i64, ptr %l45, !tbaa !24
  store i64 %t83, ptr %l41, !tbaa !24
  br label %bb25
bb23:
  br label %bb24
bb24:
  store i64 -1, ptr %l41, !tbaa !24
  br label %bb25
bb25:
  %t84 = load i64, ptr %l41, !tbaa !24
  store i64 %t84, ptr %l5, !tbaa !24
  %t85 = load i64, ptr %l5, !tbaa !24
  %t87 = icmp sge i64 %t85, 0
  br i1 %t87, label %bb26, label %bb27
bb26:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/cond:Eval", ptr %t89, i32 0, i32 3
  %t92 = load ptr, ptr %t91, !tbaa !29
  %t94 = getelementptr %"compiler/cond:Consts", ptr %t92, i32 0, i32 3
  %t95 = load i64, ptr %l5, !tbaa !24
  %t98 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t94, i64 %t95)
  store i1 %t98, ptr %l53
  br label %bb28
bb27:
  br label %bb41
bb28:
  %t99 = load i1, ptr %l53, !tbaa !21
  br i1 %t99, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l54, !tbaa !21
  br label %bb32
bb30:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/cond:Eval", ptr %t100, i32 0, i32 3
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t105 = getelementptr %"compiler/cond:Consts", ptr %t103, i32 0, i32 4
  %t106 = load i64, ptr %l5, !tbaa !24
  %t109 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t105, i64 %t106)
  store i1 %t109, ptr %l59
  br label %bb31
bb31:
  %t110 = load i1, ptr %l59, !tbaa !21
  %t111 = xor i1 %t110, true
  store i1 %t111, ptr %l54, !tbaa !21
  br label %bb32
bb32:
  %t113 = load i1, ptr %l54, !tbaa !21
  br i1 %t113, label %bb33, label %bb34
bb33:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load %"compiler/source:Span", ptr %l1
  %t118 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t114, %"compiler/source:Span" %t115)
  store %"compiler/cond:Value" %t118, ptr %l63
  br label %bb35
bb34:
  br label %bb36
bb35:
  %t119 = load %"compiler/cond:Value", ptr %l63
  store %"compiler/cond:Value" %t119, ptr %rv
  br label %ret
bb36:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load i64, ptr %l5, !tbaa !24
  %t124 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2econstValue(ptr %v0, ptr %t120, i64 %t121)
  store %"compiler/cond:Value" %t124, ptr %l66
  br label %bb37
bb37:
  %t125 = load %"compiler/cond:Value", ptr %l66
  store %"compiler/cond:Value" %t125, ptr %l6
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/cond:Eval", ptr %t126, i32 0, i32 10
  %t129 = load i64, ptr %t128, !tbaa !24
  %t131 = icmp eq i64 %t129, 0
  br i1 %t131, label %bb38, label %bb39
bb38:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/cond:Eval", ptr %t133, i32 0, i32 11
  store i1 true, ptr %t135, !tbaa !21
  br label %bb40
bb39:
  br label %bb40
bb40:
  %t136 = load %"compiler/cond:Value", ptr %l6
  store %"compiler/cond:Value" %t136, ptr %rv
  br label %ret
bb41:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t139 = load %"compiler/source:Span", ptr %l1
  %t142 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t138, %"compiler/source:Span" %t139)
  store %"compiler/cond:Value" %t142, ptr %l74
  br label %bb42
bb42:
  %t143 = load %"compiler/cond:Value", ptr %l74
  store %"compiler/cond:Value" %t143, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cond:Value", ptr %rv
  ret %"compiler/cond:Value" %rr
}

define dso_local %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eruntimeValue(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/diagmsg:Msg" %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l7 = alloca %"compiler/cond:Value"
  %l9 = alloca i1
  %l17 = alloca %"compiler/cond:Value"
  %rv = alloca %"compiler/cond:Value"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/cond:Eval", ptr %t1, i32 0, i32 10
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp sgt i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = call %"compiler/cond:Value" @compiler_2fcond_2eValue_2enone()
  store %"compiler/cond:Value" %t8, ptr %l7
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t9 = load %"compiler/cond:Value", ptr %l7
  store %"compiler/cond:Value" %t9, ptr %rv
  br label %ret
bb4:
  br i1 %a3, label %bb5, label %bb6
bb5:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/cond:Eval", ptr %t12, i32 0, i32 4
  %t15 = load i1, ptr %t14, !tbaa !21
  %t17 = xor i1 %t15, true
  store i1 %t17, ptr %l9, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb7
bb7:
  %t19 = load i1, ptr %l9, !tbaa !21
  br i1 %t19, label %bb8, label %bb9
bb8:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/cond:Eval", ptr %t20, i32 0, i32 6
  store i1 true, ptr %t22, !tbaa !21
  br label %bb10
bb9:
  br label %bb10
bb10:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t29 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2efail(ptr %v0, ptr %v1, ptr %t23, %"compiler/source:Span" %a1, %"compiler/diagmsg:Msg" %a2)
  store %"compiler/cond:Value" %t29, ptr %l17
  br label %bb11
bb11:
  %t30 = load %"compiler/cond:Value", ptr %l17
  store %"compiler/cond:Value" %t30, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cond:Value", ptr %rv
  ret %"compiler/cond:Value" %rr
}

define dso_local { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aEval_2etokText(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l13 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/cond:Eval", ptr %a0, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l3, !tbaa !27
  %t5 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t6 = load i32, ptr %t5, !tbaa !23
  %t8 = sext i32 %t6 to i64
  store i64 %t8, ptr %l5, !tbaa !24
  %t9 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t10 = load i32, ptr %t9, !tbaa !23
  %t12 = sext i32 %t10 to i64
  store i64 %t12, ptr %l7, !tbaa !24
  %t13 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t13, 0
  store i64 %t14, ptr %l8, !tbaa !24
  %t15 = load i64, ptr %l5, !tbaa !24
  %t16 = icmp sge i64 %t15, 0
  br i1 %t16, label %bb1, label %bb2
bb1:
  %t18 = load i64, ptr %l5, !tbaa !24
  %t19 = load i64, ptr %l7, !tbaa !24
  %t20 = icmp sle i64 %t18, %t19
  br i1 %t20, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_a2ac67dda58979b2_83eb4d620334066e)
  unreachable
bb3:
  %t22 = load i64, ptr %l7, !tbaa !24
  %t23 = load i64, ptr %l8, !tbaa !24
  %t24 = icmp sle i64 %t22, %t23
  br i1 %t24, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_a2ac67dda58979b2_83eb4d620334066e)
  unreachable
bb5:
  %t26 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = load i64, ptr %l5, !tbaa !24
  %t29 = load i64, ptr %l7, !tbaa !24
  %t30 = getelementptr i8, ptr %t27, i64 %t28
  %t31 = sub i64 %t29, %t28
  %t32 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t30, 1
  %t35 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %t33)
  store { i64, ptr } %t35, ptr %l13
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_a2ac67dda58979b2_83eb4d620334066e)
  unreachable
bb7:
  %t36 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t36, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fcond_2ecompiler_2fcond_3aScope_2eAdd(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l7 = alloca i64
  %l9 = alloca i64
  %l14 = alloca ptr
  %l19 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/cond:Scope", ptr %t1, i32 0, i32 1
  store ptr %t3, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l3, !tbaa !24
  store i64 %t5, ptr %l7, !tbaa !24
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcond_3aGlobal_26_3e_2eLen_3ccompiler_2fcond_3aGlobal_26_3e(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l9
  br label %bb2
bb2:
  %t9 = load i64, ptr %l7, !tbaa !24
  %t10 = load i64, ptr %l9, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb12
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcond_3aGlobal_26_3e_2eAt_3ccompiler_2fcond_3aGlobal_26_3e(ptr %v0, ptr %v0, ptr %t15, i64 %t16)
  store ptr %t19, ptr %l14
  br label %bb6
bb6:
  %t20 = load ptr, ptr %l14, !tbaa !29
  %t23 = getelementptr %"compiler/cond:Global", ptr %t20, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr %"compiler/cond:Global", ptr %t25, i32 0, i32 0
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  %t31 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t24, { i64, ptr } %t28)
  store i1 %t31, ptr %l19
  br label %bb7
bb7:
  %t32 = load i1, ptr %l19, !tbaa !21
  br i1 %t32, label %bb8, label %bb9
bb8:
  br label %ret
bb9:
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t33 = load i64, ptr %l3, !tbaa !24
  %t36 = add i64 %t33, 1
  store i64 %t36, ptr %l3, !tbaa !24
  br label %bb1
bb12:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/cond:Scope", ptr %t38, i32 0, i32 1
  %t41 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcond_3aGlobal_26_3e_2ePush_3ccompiler_2fcond_3aGlobal_26_3e(ptr %v0, ptr %v1, ptr %t40, ptr %t41)
  br label %bb13
bb13:
  br label %ret
ret:
  ret void
}

define dso_local { i32, ptr } @compiler_2fcond_2ecompiler_2fcond_3aScope_2efind(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l7 = alloca i64
  %l9 = alloca i64
  %l14 = alloca ptr
  %l18 = alloca i1
  %rv = alloca { i32, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/cond:Scope", ptr %a0, i32 0, i32 1
  store ptr %t3, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l3, !tbaa !24
  store i64 %t5, ptr %l7, !tbaa !24
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcond_3aGlobal_26_3e_2eLen_3ccompiler_2fcond_3aGlobal_26_3e(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l9
  br label %bb2
bb2:
  %t9 = load i64, ptr %l7, !tbaa !24
  %t10 = load i64, ptr %l9, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb12
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcond_3aGlobal_26_3e_2eAt_3ccompiler_2fcond_3aGlobal_26_3e(ptr %v0, ptr %v0, ptr %t15, i64 %t16)
  store ptr %t19, ptr %l14
  br label %bb6
bb6:
  %t20 = load ptr, ptr %l14, !tbaa !29
  store ptr %t20, ptr %l4, !tbaa !29
  %t21 = load ptr, ptr %l4, !tbaa !29
  %t23 = getelementptr %"compiler/cond:Global", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t28 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t24, { i64, ptr } %a1)
  store i1 %t28, ptr %l18
  br label %bb7
bb7:
  %t29 = load i1, ptr %l18, !tbaa !21
  br i1 %t29, label %bb8, label %bb9
bb8:
  %t30 = load ptr, ptr %l4, !tbaa !29
  %t32 = insertvalue { i32, ptr } zeroinitializer, ptr %t30, 1
  store { i32, ptr } %t32, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t33 = load i64, ptr %l3, !tbaa !24
  %t36 = add i64 %t33, 1
  store i64 %t36, ptr %l3, !tbaa !24
  br label %bb1
bb12:
  %t39 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t39, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i1 @compiler_2fcond_2efits(i64 %a0, i64 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l3 = alloca i64
  %l10 = alloca i1
  %l13 = alloca i1
  %l15 = alloca i64
  %l22 = alloca i64
  %l28 = alloca i1
  %rv = alloca i1
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp eq i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  br i1 %a2, label %bb4, label %bb5
bb4:
  %t8 = load i64, ptr %l0, !tbaa !24
  %t10 = icmp sge i64 %t8, 0
  br i1 %t10, label %bb6, label %bb7
bb5:
  br label %bb12
bb6:
  %t12 = load i64, ptr %l1, !tbaa !24
  %t14 = icmp eq i64 %t12, 64
  br i1 %t14, label %bb8, label %bb9
bb7:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb11
bb8:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb10
bb9:
  %t16 = load i64, ptr %l0, !tbaa !24
  %t17 = load i64, ptr %l1, !tbaa !24
  store i64 %t17, ptr %l15, !tbaa !24
  %t18 = load i64, ptr %l15, !tbaa !24
  %t19 = load i64, ptr %l15, !tbaa !24
  %t20 = shl i64 1, %t19
  %t23 = icmp slt i64 %t16, %t20
  store i1 %t23, ptr %l13, !tbaa !21
  br label %bb10
bb10:
  %t25 = load i1, ptr %l13, !tbaa !21
  store i1 %t25, ptr %l10, !tbaa !21
  br label %bb11
bb11:
  %t26 = load i1, ptr %l10, !tbaa !21
  store i1 %t26, ptr %rv
  br label %ret
bb12:
  %t27 = load i64, ptr %l1, !tbaa !24
  %t29 = icmp eq i64 %t27, 64
  br i1 %t29, label %bb13, label %bb14
bb13:
  store i1 true, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t32 = load i64, ptr %l1, !tbaa !24
  %t34 = sub i64 %t32, 1
  store i64 %t34, ptr %l22, !tbaa !24
  %t35 = load i64, ptr %l22, !tbaa !24
  %t36 = load i64, ptr %l22, !tbaa !24
  %t37 = shl i64 1, %t36
  store i64 %t37, ptr %l3, !tbaa !24
  %t39 = load i64, ptr %l0, !tbaa !24
  %t40 = load i64, ptr %l3, !tbaa !24
  %t42 = sub i64 0, %t40
  %t45 = icmp sge i64 %t39, %t42
  br i1 %t45, label %bb16, label %bb17
bb16:
  %t47 = load i64, ptr %l0, !tbaa !24
  %t48 = load i64, ptr %l3, !tbaa !24
  %t51 = icmp slt i64 %t47, %t48
  store i1 %t51, ptr %l28, !tbaa !21
  br label %bb18
bb17:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb18
bb18:
  %t53 = load i1, ptr %l28, !tbaa !21
  store i1 %t53, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcond_2eflows(i64 %a0, i1 %a1, i64 %a2, i1 %a3) #0 {
entry:
  %l1 = alloca i1
  %l3 = alloca i1
  %l11 = alloca i1
  %l13 = alloca i1
  %rv = alloca i1
  store i1 %a1, ptr %l1
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t5 = icmp sge i64 %a0, %a2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load i1, ptr %l1, !tbaa !21
  %t9 = load i1, ptr %l3, !tbaa !21
  %t12 = icmp eq i1 %t8, %t9
  br i1 %t12, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb9
bb5:
  %t14 = load i1, ptr %l1, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t16 = load i1, ptr %l3, !tbaa !21
  %t18 = xor i1 %t16, true
  store i1 %t18, ptr %l13, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb8
bb8:
  %t20 = load i1, ptr %l13, !tbaa !21
  store i1 %t20, ptr %l11, !tbaa !21
  br label %bb9
bb9:
  %t21 = load i1, ptr %l11, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, %"compiler/cond:Value" } @compiler_2fcond_2emeet(%"compiler/cond:Value" %a0, %"compiler/cond:Value" %a1) #0 {
entry:
  %l0 = alloca %"compiler/cond:Value"
  %l1 = alloca %"compiler/cond:Value"
  %l2 = alloca %"compiler/cond:Value"
  %l3 = alloca %"compiler/cond:Value"
  %l6 = alloca i1
  %l12 = alloca i1
  %l19 = alloca %"compiler/cond:Value"
  %l24 = alloca i1
  %l28 = alloca %"compiler/cond:Value"
  %l33 = alloca i1
  %l37 = alloca %"compiler/cond:Value"
  %l41 = alloca i1
  %l46 = alloca %"compiler/cond:Value"
  %l51 = alloca %"compiler/cond:Value"
  %l57 = alloca i1
  %l61 = alloca %"compiler/cond:Value"
  %l65 = alloca i1
  %l67 = alloca i1
  %l71 = alloca i1
  %l78 = alloca %"compiler/cond:Value"
  %l80 = alloca %"compiler/cond:Value"
  %rv = alloca { i32, %"compiler/cond:Value" }
  store %"compiler/cond:Value" %a0, ptr %l0
  store %"compiler/cond:Value" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/cond:Value", ptr %l0, i32 0, i32 4
  %t2 = load i64, ptr %t1, !tbaa !24
  %t4 = icmp ne i64 %t2, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr %"compiler/cond:Value", ptr %l1, i32 0, i32 4
  %t7 = load i64, ptr %t6, !tbaa !24
  %t9 = icmp ne i64 %t7, 0
  store i1 %t9, ptr %l6, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l6, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  %t12 = getelementptr %"compiler/cond:Value", ptr %l0, i32 0, i32 4
  %t13 = load i64, ptr %t12, !tbaa !24
  %t14 = getelementptr %"compiler/cond:Value", ptr %l1, i32 0, i32 4
  %t15 = load i64, ptr %t14, !tbaa !24
  %t18 = icmp eq i64 %t13, %t15
  br i1 %t18, label %bb6, label %bb7
bb5:
  br label %bb23
bb6:
  %t20 = getelementptr %"compiler/cond:Value", ptr %l0, i32 0, i32 5
  %t21 = load i1, ptr %t20, !tbaa !21
  %t22 = getelementptr %"compiler/cond:Value", ptr %l1, i32 0, i32 5
  %t23 = load i1, ptr %t22, !tbaa !21
  %t26 = icmp eq i1 %t21, %t23
  store i1 %t26, ptr %l12, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb8
bb8:
  %t28 = load i1, ptr %l12, !tbaa !21
  br i1 %t28, label %bb9, label %bb10
bb9:
  %t29 = getelementptr %"compiler/cond:Value", ptr %l0, i32 0, i32 4
  %t30 = load i64, ptr %t29, !tbaa !24
  %t31 = getelementptr %"compiler/cond:Value", ptr %l0, i32 0, i32 5
  %t32 = load i1, ptr %t31, !tbaa !21
  %t36 = call %"compiler/cond:Value" @compiler_2fcond_2eValue_2eshape(i32 2, i64 %t30, i1 %t32)
  store %"compiler/cond:Value" %t36, ptr %l19
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t37 = load %"compiler/cond:Value", ptr %l19
  %t38 = insertvalue { i32, %"compiler/cond:Value" } zeroinitializer, %"compiler/cond:Value" %t37, 1
  store { i32, %"compiler/cond:Value" } %t38, ptr %rv
  br label %ret
bb12:
  %t39 = getelementptr %"compiler/cond:Value", ptr %l0, i32 0, i32 4
  %t40 = load i64, ptr %t39, !tbaa !24
  %t41 = getelementptr %"compiler/cond:Value", ptr %l0, i32 0, i32 5
  %t42 = load i1, ptr %t41, !tbaa !21
  %t43 = getelementptr %"compiler/cond:Value", ptr %l1, i32 0, i32 4
  %t44 = load i64, ptr %t43, !tbaa !24
  %t45 = getelementptr %"compiler/cond:Value", ptr %l1, i32 0, i32 5
  %t46 = load i1, ptr %t45, !tbaa !21
  %t51 = call i1 @compiler_2fcond_2eflows(i64 %t40, i1 %t42, i64 %t44, i1 %t46)
  store i1 %t51, ptr %l24
  br label %bb13
bb13:
  %t52 = load i1, ptr %l24, !tbaa !21
  br i1 %t52, label %bb14, label %bb15
bb14:
  %t53 = getelementptr %"compiler/cond:Value", ptr %l1, i32 0, i32 4
  %t54 = load i64, ptr %t53, !tbaa !24
  %t55 = getelementptr %"compiler/cond:Value", ptr %l1, i32 0, i32 5
  %t56 = load i1, ptr %t55, !tbaa !21
  %t60 = call %"compiler/cond:Value" @compiler_2fcond_2eValue_2eshape(i32 2, i64 %t54, i1 %t56)
  store %"compiler/cond:Value" %t60, ptr %l28
  br label %bb16
bb15:
  br label %bb17
bb16:
  %t61 = load %"compiler/cond:Value", ptr %l28
  %t62 = insertvalue { i32, %"compiler/cond:Value" } zeroinitializer, %"compiler/cond:Value" %t61, 1
  store { i32, %"compiler/cond:Value" } %t62, ptr %rv
  br label %ret
bb17:
  %t63 = getelementptr %"compiler/cond:Value", ptr %l1, i32 0, i32 4
  %t64 = load i64, ptr %t63, !tbaa !24
  %t65 = getelementptr %"compiler/cond:Value", ptr %l1, i32 0, i32 5
  %t66 = load i1, ptr %t65, !tbaa !21
  %t67 = getelementptr %"compiler/cond:Value", ptr %l0, i32 0, i32 4
  %t68 = load i64, ptr %t67, !tbaa !24
  %t69 = getelementptr %"compiler/cond:Value", ptr %l0, i32 0, i32 5
  %t70 = load i1, ptr %t69, !tbaa !21
  %t75 = call i1 @compiler_2fcond_2eflows(i64 %t64, i1 %t66, i64 %t68, i1 %t70)
  store i1 %t75, ptr %l33
  br label %bb18
bb18:
  %t76 = load i1, ptr %l33, !tbaa !21
  br i1 %t76, label %bb19, label %bb20
bb19:
  %t77 = getelementptr %"compiler/cond:Value", ptr %l0, i32 0, i32 4
  %t78 = load i64, ptr %t77, !tbaa !24
  %t79 = getelementptr %"compiler/cond:Value", ptr %l0, i32 0, i32 5
  %t80 = load i1, ptr %t79, !tbaa !21
  %t84 = call %"compiler/cond:Value" @compiler_2fcond_2eValue_2eshape(i32 2, i64 %t78, i1 %t80)
  store %"compiler/cond:Value" %t84, ptr %l37
  br label %bb21
bb20:
  br label %bb22
bb21:
  %t85 = load %"compiler/cond:Value", ptr %l37
  %t86 = insertvalue { i32, %"compiler/cond:Value" } zeroinitializer, %"compiler/cond:Value" %t85, 1
  store { i32, %"compiler/cond:Value" } %t86, ptr %rv
  br label %ret
bb22:
  %t88 = insertvalue { i32, %"compiler/cond:Value" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/cond:Value" } %t88, ptr %rv
  br label %ret
bb23:
  %t89 = getelementptr %"compiler/cond:Value", ptr %l0, i32 0, i32 4
  %t90 = load i64, ptr %t89, !tbaa !24
  %t92 = icmp ne i64 %t90, 0
  br i1 %t92, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l41, !tbaa !21
  br label %bb26
bb25:
  %t94 = getelementptr %"compiler/cond:Value", ptr %l1, i32 0, i32 4
  %t95 = load i64, ptr %t94, !tbaa !24
  %t97 = icmp ne i64 %t95, 0
  store i1 %t97, ptr %l41, !tbaa !21
  br label %bb26
bb26:
  %t99 = load i1, ptr %l41, !tbaa !21
  br i1 %t99, label %bb27, label %bb28
bb27:
  %t100 = getelementptr %"compiler/cond:Value", ptr %l0, i32 0, i32 4
  %t101 = load i64, ptr %t100, !tbaa !24
  %t103 = icmp ne i64 %t101, 0
  br i1 %t103, label %bb29, label %bb30
bb28:
  br label %bb51
bb29:
  %t105 = load %"compiler/cond:Value", ptr %l0
  store %"compiler/cond:Value" %t105, ptr %l46
  br label %bb31
bb30:
  %t107 = load %"compiler/cond:Value", ptr %l1
  store %"compiler/cond:Value" %t107, ptr %l46
  br label %bb31
bb31:
  %t109 = load %"compiler/cond:Value", ptr %l46
  store %"compiler/cond:Value" %t109, ptr %l2
  %t110 = getelementptr %"compiler/cond:Value", ptr %l0, i32 0, i32 4
  %t111 = load i64, ptr %t110, !tbaa !24
  %t113 = icmp ne i64 %t111, 0
  br i1 %t113, label %bb32, label %bb33
bb32:
  %t115 = load %"compiler/cond:Value", ptr %l1
  store %"compiler/cond:Value" %t115, ptr %l51
  br label %bb34
bb33:
  %t117 = load %"compiler/cond:Value", ptr %l0
  store %"compiler/cond:Value" %t117, ptr %l51
  br label %bb34
bb34:
  %t119 = load %"compiler/cond:Value", ptr %l51
  store %"compiler/cond:Value" %t119, ptr %l3
  %t120 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 1
  %t121 = load i64, ptr %t120, !tbaa !24
  %t122 = getelementptr %"compiler/cond:Value", ptr %l2, i32 0, i32 4
  %t123 = load i64, ptr %t122, !tbaa !24
  %t124 = getelementptr %"compiler/cond:Value", ptr %l2, i32 0, i32 5
  %t125 = load i1, ptr %t124, !tbaa !21
  %t129 = call i1 @compiler_2fcond_2efits(i64 %t121, i64 %t123, i1 %t125)
  store i1 %t129, ptr %l57
  br label %bb35
bb35:
  %t130 = load i1, ptr %l57, !tbaa !21
  br i1 %t130, label %bb36, label %bb37
bb36:
  %t131 = getelementptr %"compiler/cond:Value", ptr %l2, i32 0, i32 4
  %t132 = load i64, ptr %t131, !tbaa !24
  %t133 = getelementptr %"compiler/cond:Value", ptr %l2, i32 0, i32 5
  %t134 = load i1, ptr %t133, !tbaa !21
  %t138 = call %"compiler/cond:Value" @compiler_2fcond_2eValue_2eshape(i32 2, i64 %t132, i1 %t134)
  store %"compiler/cond:Value" %t138, ptr %l61
  br label %bb38
bb37:
  br label %bb39
bb38:
  %t139 = load %"compiler/cond:Value", ptr %l61
  %t140 = insertvalue { i32, %"compiler/cond:Value" } zeroinitializer, %"compiler/cond:Value" %t139, 1
  store { i32, %"compiler/cond:Value" } %t140, ptr %rv
  br label %ret
bb39:
  %t141 = getelementptr %"compiler/cond:Value", ptr %l2, i32 0, i32 4
  %t142 = load i64, ptr %t141, !tbaa !24
  %t143 = getelementptr %"compiler/cond:Value", ptr %l2, i32 0, i32 5
  %t144 = load i1, ptr %t143, !tbaa !21
  %t145 = load i64, ptr @G_2ecompiler_2fcond_2eLiteralIntBits, !tbaa !24
  %t149 = call i1 @compiler_2fcond_2eflows(i64 %t142, i1 %t144, i64 %t145, i1 false)
  store i1 %t149, ptr %l65
  br label %bb40
bb40:
  %t150 = load i1, ptr %l65, !tbaa !21
  %t151 = xor i1 %t150, true
  br i1 %t151, label %bb41, label %bb42
bb41:
  %t153 = getelementptr %"compiler/cond:Value", ptr %l2, i32 0, i32 4
  %t154 = load i64, ptr %t153, !tbaa !24
  %t155 = load i64, ptr @G_2ecompiler_2fcond_2eLiteralIntBits, !tbaa !24
  %t158 = icmp eq i64 %t154, %t155
  br i1 %t158, label %bb43, label %bb44
bb42:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb46
bb43:
  %t160 = getelementptr %"compiler/cond:Value", ptr %l2, i32 0, i32 5
  %t161 = load i1, ptr %t160, !tbaa !21
  %t163 = xor i1 %t161, true
  store i1 %t163, ptr %l71, !tbaa !21
  br label %bb45
bb44:
  store i1 false, ptr %l71, !tbaa !21
  br label %bb45
bb45:
  %t165 = load i1, ptr %l71, !tbaa !21
  %t166 = xor i1 %t165, true
  store i1 %t166, ptr %l67, !tbaa !21
  br label %bb46
bb46:
  %t168 = load i1, ptr %l67, !tbaa !21
  br i1 %t168, label %bb47, label %bb48
bb47:
  %t170 = insertvalue { i32, %"compiler/cond:Value" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/cond:Value" } %t170, ptr %rv
  br label %ret
bb48:
  br label %bb49
bb49:
  %t171 = load i64, ptr @G_2ecompiler_2fcond_2eLiteralIntBits, !tbaa !24
  %t174 = call %"compiler/cond:Value" @compiler_2fcond_2eValue_2eshape(i32 2, i64 %t171, i1 false)
  store %"compiler/cond:Value" %t174, ptr %l78
  br label %bb50
bb50:
  %t175 = load %"compiler/cond:Value", ptr %l78
  %t176 = insertvalue { i32, %"compiler/cond:Value" } zeroinitializer, %"compiler/cond:Value" %t175, 1
  store { i32, %"compiler/cond:Value" } %t176, ptr %rv
  br label %ret
bb51:
  %t178 = call %"compiler/cond:Value" @compiler_2fcond_2eValue_2eshape(i32 2, i64 0, i1 false)
  store %"compiler/cond:Value" %t178, ptr %l80
  br label %bb52
bb52:
  %t179 = load %"compiler/cond:Value", ptr %l80
  %t180 = insertvalue { i32, %"compiler/cond:Value" } zeroinitializer, %"compiler/cond:Value" %t179, 1
  store { i32, %"compiler/cond:Value" } %t180, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/cond:Value" }, ptr %rv
  ret { i32, %"compiler/cond:Value" } %rr
}

define dso_local i1 @compiler_2fcond_2enumeric(%"compiler/cond:Value" %a0) #0 {
entry:
  %l0 = alloca %"compiler/cond:Value"
  %l3 = alloca i1
  %rv = alloca i1
  store %"compiler/cond:Value" %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/cond:Value", ptr %l0, i32 0, i32 0
  %t2 = load i32, ptr %t1, !range !{i32 0, i32 5}
  %t4 = trunc i64 2 to i32
  %t5 = icmp eq i32 %t2, %t4
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  %t7 = getelementptr %"compiler/cond:Value", ptr %l0, i32 0, i32 0
  %t8 = load i32, ptr %t7, !range !{i32 0, i32 5}
  %t10 = trunc i64 3 to i32
  %t11 = icmp eq i32 %t8, %t10
  store i1 %t11, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l3, !tbaa !21
  store i1 %t13, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fcond_2estripped(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i8
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l14 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l6
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t17, ptr %l14, !tbaa !27
  %t18 = load i64, ptr %l3, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr i8, ptr %t21, i64 %t18
  %t23 = load i8, ptr %t22, !tbaa !32
  store i8 %t23, ptr %l5, !tbaa !22
  %t25 = load i8, ptr %l5, !tbaa !22
  %t27 = icmp ne i8 %t25, 95
  br i1 %t27, label %bb6, label %bb7
bb6:
  %t29 = load i8, ptr %l5, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 %t29)
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t32 = load i64, ptr %l3, !tbaa !24
  %t35 = add i64 %t32, 1
  store i64 %t35, ptr %l3, !tbaa !24
  br label %bb2
bb11:
  %t38 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t38, ptr %l25
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s0)
  %t39 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t39, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/cond:Decision" @compiler_2fcond_3aDecision_2ector(ptr %v0, i32 %a0, i1 %a1) #0 {
entry:
  %rv = alloca %"compiler/cond:Decision"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/cond:Decision" undef, i32 %a0, 0
  %t8 = insertvalue %"compiler/cond:Decision" %t6, i1 %a1, 1
  store %"compiler/cond:Decision" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cond:Decision", ptr %rv
  ret %"compiler/cond:Decision" %rr
}

define dso_local void @compiler_2fcond_3aEval_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i1
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca %"compiler/source:Span"
  %l12 = alloca %"compiler/diagmsg:Msg"
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i1
  %l21 = alloca %"compiler/source:Span"
  %l22 = alloca %"compiler/diagmsg:Msg"
  %l23 = alloca i64
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l27 = alloca %"compiler/cond:Eval"
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a0, ptr %l4, !tbaa !27
  store ptr %a1, ptr %l5, !tbaa !29
  store ptr %a2, ptr %l6, !tbaa !29
  store ptr %a3, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  store i1 false, ptr %l9, !tbaa !21
  store i1 false, ptr %l10, !tbaa !21
  %t9 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v4, i32 0, i32 0)
  store %"compiler/source:Span" %t9, ptr %l21
  br label %bb1
bb1:
  %t10 = load %"compiler/source:Span", ptr %l21
  store %"compiler/source:Span" %t10, ptr %l11
  %t11 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCondNotBool(ptr %v4, ptr %v4, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d20, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t11, ptr %l22
  br label %bb2
bb2:
  %t12 = load %"compiler/diagmsg:Msg", ptr %l22
  store %"compiler/diagmsg:Msg" %t12, ptr %l12
  store i64 0, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  store i1 false, ptr %l15, !tbaa !21
  %t13 = call ptr @__olang_scope_hold(ptr %v4)
  %t14 = ptrtoint ptr %t13 to i64
  store i64 %t14, ptr %l23, !tbaa !24
  %t15 = load i1, ptr @olang_2esole_2ecompiler_2fcond_3aEval_2e12
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = call ptr @__olang_region_make(ptr %v4)
  %t18 = ptrtoint ptr %t17 to i64
  store i64 %t18, ptr %l23, !tbaa !24
  br label %bb4
bb4:
  %t19 = load i64, ptr %l23
  %t20 = inttoptr i64 %t19 to ptr
  %t21 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t20, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %l25
  br label %bb5
bb5:
  %t22 = load i1, ptr @olang_2esole_2ecompiler_2fcond_3aEval_2e12
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t24 = load i64, ptr %l23
  %t25 = inttoptr i64 %t24 to ptr
  %t26 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l25, i32 0, i32 0
  %t27 = load { i64, ptr }, ptr %t26
  %t28 = extractvalue { i64, ptr } %t27, 1
  %t29 = call ptr @__olang_region_or(ptr %t28, ptr null)
  %t30 = call ptr @__olang_region_home(ptr %t29)
  %t31 = icmp ne ptr %t30, null
  %t32 = select i1 %t31, ptr %t30, ptr null
  call void @__olang_region_settle_in(ptr %t25, ptr %t32)
  br label %bb7
bb7:
  %t33 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l25
  %t34 = getelementptr %"compiler/cond:Eval", ptr %l27, i32 0, i32 0
  %t35 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t35, ptr %t34, !tbaa !27
  %t36 = getelementptr %"compiler/cond:Eval", ptr %l27, i32 0, i32 1
  %t37 = load ptr, ptr %l5, !tbaa !29
  store ptr %t37, ptr %t36, !tbaa !29
  %t38 = getelementptr %"compiler/cond:Eval", ptr %l27, i32 0, i32 2
  %t39 = load ptr, ptr %l6, !tbaa !29
  store ptr %t39, ptr %t38, !tbaa !29
  %t40 = getelementptr %"compiler/cond:Eval", ptr %l27, i32 0, i32 3
  %t41 = load ptr, ptr %l7, !tbaa !29
  store ptr %t41, ptr %t40, !tbaa !29
  %t42 = getelementptr %"compiler/cond:Eval", ptr %l27, i32 0, i32 4
  %t43 = load i1, ptr %l8, !tbaa !21
  store i1 %t43, ptr %t42, !tbaa !21
  %t44 = getelementptr %"compiler/cond:Eval", ptr %l27, i32 0, i32 5
  %t45 = load i1, ptr %l9, !tbaa !21
  store i1 %t45, ptr %t44, !tbaa !21
  %t46 = getelementptr %"compiler/cond:Eval", ptr %l27, i32 0, i32 6
  %t47 = load i1, ptr %l10, !tbaa !21
  store i1 %t47, ptr %t46, !tbaa !21
  %t48 = getelementptr %"compiler/cond:Eval", ptr %l27, i32 0, i32 7
  %t49 = load %"compiler/source:Span", ptr %l11
  store %"compiler/source:Span" %t49, ptr %t48
  %t50 = getelementptr %"compiler/cond:Eval", ptr %l27, i32 0, i32 8
  %t51 = load %"compiler/diagmsg:Msg", ptr %l12
  store %"compiler/diagmsg:Msg" %t51, ptr %t50
  %t52 = getelementptr %"compiler/cond:Eval", ptr %l27, i32 0, i32 9
  %t53 = load i64, ptr %l13, !tbaa !24
  store i64 %t53, ptr %t52, !tbaa !24
  %t54 = getelementptr %"compiler/cond:Eval", ptr %l27, i32 0, i32 10
  %t55 = load i64, ptr %l14, !tbaa !24
  store i64 %t55, ptr %t54, !tbaa !24
  %t56 = getelementptr %"compiler/cond:Eval", ptr %l27, i32 0, i32 11
  %t57 = load i1, ptr %l15, !tbaa !21
  store i1 %t57, ptr %t56, !tbaa !21
  %t58 = getelementptr %"compiler/cond:Eval", ptr %l27, i32 0, i32 12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t33, ptr %t58
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l27, i64 184, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/cond:Global" @compiler_2fcond_3aGlobal_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, %"compiler/source:Span" %a1, i1 %a2, { i64, ptr } %a3, ptr %a4, i1 %a5) #0 {
entry:
  %rv = alloca %"compiler/cond:Global"
  br label %start
start:
  br label %bb0
bb0:
  %t14 = insertvalue %"compiler/cond:Global" undef, { i64, ptr } %a0, 0
  %t16 = insertvalue %"compiler/cond:Global" %t14, %"compiler/source:Span" %a1, 1
  %t18 = insertvalue %"compiler/cond:Global" %t16, i1 %a2, 2
  %t20 = insertvalue %"compiler/cond:Global" %t18, { i64, ptr } %a3, 3
  %t22 = insertvalue %"compiler/cond:Global" %t20, ptr %a4, 4
  %t24 = insertvalue %"compiler/cond:Global" %t22, i1 %a5, 5
  store %"compiler/cond:Global" %t24, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cond:Global", ptr %rv
  ret %"compiler/cond:Global" %rr
}

define dso_local %"compiler/cond:Scope" @compiler_2fcond_3aScope_2ector(ptr %v0, i1 %a0) #0 {
entry:
  %l1 = alloca i1
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca i64
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca i64
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/cond:Scope"
  br label %start
start:
  br label %bb0
bb0:
  store i1 %a0, ptr %l1, !tbaa !21
  %t3 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcond_3aGlobal_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l2
  %t5 = call ptr @__olang_scope_hold(ptr %v0)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l7, !tbaa !24
  %t7 = load i1, ptr @olang_2esole_2ecompiler_2fcond_3aScope_2e2
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = call ptr @__olang_region_make(ptr %v0)
  %t10 = ptrtoint ptr %t9 to i64
  store i64 %t10, ptr %l7, !tbaa !24
  br label %bb3
bb3:
  %t11 = load i64, ptr %l7
  %t12 = inttoptr i64 %t11 to ptr
  %t13 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %t12, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t13, ptr %l9
  br label %bb4
bb4:
  %t14 = load i1, ptr @olang_2esole_2ecompiler_2fcond_3aScope_2e2
  br i1 %t14, label %bb5, label %bb6
bb5:
  %t16 = load i64, ptr %l7
  %t17 = inttoptr i64 %t16 to ptr
  %t18 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9, i32 0, i32 0
  %t19 = load { i64, ptr }, ptr %t18
  %t20 = extractvalue { i64, ptr } %t19, 1
  %t21 = call ptr @__olang_region_or(ptr %t20, ptr null)
  %t22 = call ptr @__olang_region_home(ptr %t21)
  %t23 = icmp ne ptr %t22, null
  %t24 = select i1 %t23, ptr %t22, ptr null
  call void @__olang_region_settle_in(ptr %t17, ptr %t24)
  br label %bb6
bb6:
  %t25 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %l3
  %t26 = call ptr @__olang_scope_hold(ptr %v0)
  %t27 = ptrtoint ptr %t26 to i64
  store i64 %t27, ptr %l11, !tbaa !24
  %t28 = load i1, ptr @olang_2esole_2ecompiler_2fcond_3aScope_2e3
  br i1 %t28, label %bb7, label %bb8
bb7:
  %t30 = call ptr @__olang_region_make(ptr %v0)
  %t31 = ptrtoint ptr %t30 to i64
  store i64 %t31, ptr %l11, !tbaa !24
  br label %bb8
bb8:
  %t32 = load i64, ptr %l11
  %t33 = inttoptr i64 %t32 to ptr
  %t34 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %t33, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t34, ptr %l13
  br label %bb9
bb9:
  %t35 = load i1, ptr @olang_2esole_2ecompiler_2fcond_3aScope_2e3
  br i1 %t35, label %bb10, label %bb11
bb10:
  %t37 = load i64, ptr %l11
  %t38 = inttoptr i64 %t37 to ptr
  %t39 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13, i32 0, i32 0
  %t40 = load { i64, ptr }, ptr %t39
  %t41 = extractvalue { i64, ptr } %t40, 1
  %t42 = call ptr @__olang_region_or(ptr %t41, ptr null)
  %t43 = call ptr @__olang_region_home(ptr %t42)
  %t44 = icmp ne ptr %t43, null
  %t45 = select i1 %t44, ptr %t43, ptr null
  call void @__olang_region_settle_in(ptr %t38, ptr %t45)
  br label %bb11
bb11:
  %t46 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  %t47 = load i1, ptr %l1, !tbaa !21
  %t48 = insertvalue %"compiler/cond:Scope" undef, i1 %t47, 0
  %t49 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  %t50 = insertvalue %"compiler/cond:Scope" %t48, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t49, 1
  %t51 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t52 = insertvalue %"compiler/cond:Scope" %t50, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t51, 2
  %t54 = insertvalue %"compiler/cond:Scope" %t52, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t46, 3
  store %"compiler/cond:Scope" %t54, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cond:Scope", ptr %rv
  ret %"compiler/cond:Scope" %rr
}

define dso_local %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %v0, i32 %a0, i64 %a1, double %a2, i64 %a3, i64 %a4, i1 %a5, i1 %a6) #0 {
entry:
  %rv = alloca %"compiler/cond:Value"
  br label %start
start:
  br label %bb0
bb0:
  %t16 = insertvalue %"compiler/cond:Value" undef, i32 %a0, 0
  %t18 = insertvalue %"compiler/cond:Value" %t16, i64 %a1, 1
  %t20 = insertvalue %"compiler/cond:Value" %t18, double %a2, 2
  %t22 = insertvalue %"compiler/cond:Value" %t20, i64 %a3, 3
  %t24 = insertvalue %"compiler/cond:Value" %t22, i64 %a4, 4
  %t26 = insertvalue %"compiler/cond:Value" %t24, i1 %a5, 5
  %t28 = insertvalue %"compiler/cond:Value" %t26, i1 %a6, 6
  store %"compiler/cond:Value" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cond:Value", ptr %rv
  ret %"compiler/cond:Value" %rr
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d0 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d1 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"TargetOs" }>, align 8
@.d2 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d3 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"TargetArch" }>, align 8
@.d4 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d5 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"TargetCpu" }>, align 8
@.d6 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"TargetVectorBits" }>, align 8
@.d7 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"TargetHasFma" }>, align 8
@.d8 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"TargetHasTileDot" }>, align 8
@.d9 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"DebugBuild" }>, align 8
@.d10 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"RaceBuild" }>, align 8
@.d11 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"TestBuild" }>, align 8
@.d12 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Bool" }>, align 8
@.d13 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"String" }>, align 8
@.d14 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I32" }>, align 8
@.d15 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d16 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U64" }>, align 8
@.d17 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F64" }>, align 8
declare void @__olang_check_failed(ptr) cold noreturn
@.d18 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d19 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e1 = weak hidden constant i1 false
declare void @__olang_region_release(ptr) noinline
@olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4 = weak hidden constant i1 false
@.d20 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@olang_2esole_2ecompiler_2fcond_3aEval_2e12 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
declare ptr @__olang_region_or(ptr, ptr)
declare ptr @__olang_region_home(ptr)
declare void @__olang_region_settle_in(ptr, ptr)
@olang_2esole_2ecompiler_2fcond_3aScope_2e2 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fcond_3aScope_2e3 = weak hidden constant i1 false
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/cond:Value" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcond_3aValue_3e_2eAt_3ccompiler_2fcond_3aValue_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_1b6b73656135f28c_5e0b436694761b68 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcond_3aValue_3e_2eSetAt_3ccompiler_2fcond_3aValue_3e(ptr %v0, ptr %a0, i64 %a1, %"compiler/cond:Value" %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcond_3aValue_3e_2ePush_3ccompiler_2fcond_3aValue_3e(ptr %v0, ptr %a0, %"compiler/cond:Value" %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2ementionsLocal(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCondNotBool(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fcond_2ecompiler_2fcond_3aEval_2etokenAt(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2ecompare(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, %"compiler/cond:Value" %a3, %"compiler/cond:Value" %a4)
declare %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2earith(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, %"compiler/cond:Value" %a3, %"compiler/cond:Value" %a4)
@olang_loc_5546f0ea7c9d5f01_1e107de9ea891e15 = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCondName(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eliteral(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eunary(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3)
@olang_loc_4f7f4596ea7a5dcf_15046327e746a0a3 = external constant [0 x i8]
@olang_loc_c6445e8eb561a5e0_a28b098f67507e74 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCondTypes(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eglobal(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
@olang_loc_a2ac67dda58979b2_83eb4d620334066e = external constant [0 x i8]
declare { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcond_3aGlobal_26_3e_2eLen_3ccompiler_2fcond_3aGlobal_26_3e(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcond_3aGlobal_26_3e_2eAt_3ccompiler_2fcond_3aGlobal_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcond_3aGlobal_26_3e_2ePush_3ccompiler_2fcond_3aGlobal_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcond_3aGlobal_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v0, i64 %a0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
