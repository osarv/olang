; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/cond:Value" = type { i32, i64, double, i64, i64, i1 }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/cond:Consts" = type { %"std/prelude/list:List<std/prelude/text:String&>", %"std/prelude/list:List<compiler/cond:Value>", %"std/prelude/list:List<Bool>", %"std/prelude/list:List<Bool>", %"std/prelude/list:List<Bool>", %"std/prelude/list:List<std/prelude/text:String&>", %"std/prelude/list:List<std/prelude/text:String&>" }
%"std/prelude/list:List<std/prelude/text:String&>" = type { ptr }
%"std/prelude/list:List<compiler/cond:Value>" = type { ptr }
%"std/prelude/list:List<Bool>" = type { ptr }
%"compiler/scan:Tokens" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/token:Token" = type { i32, i8, i32, i32 }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/cond:Eval" = type { { i64, ptr }, ptr, ptr, ptr, i1, i1, i1, %"compiler/source:Span", %"compiler/msgs:Msg", i64, i64, i1, %"std/prelude/list:List<std/prelude/text:String&>" }
%"compiler/cond:Global" = type { { i64, ptr }, %"compiler/source:Span", i1, { i64, ptr }, ptr, i1 }
%"compiler/ast:Chain" = type { { i64, ptr }, { i64, ptr } }
%"compiler/cond:Scope" = type { i1, %"std/prelude/list:List<compiler/cond:Global&>", %"std/prelude/list:List<compiler/source:NameId>", %"std/prelude/list:List<compiler/source:NameId>" }
%"std/prelude/list:List<compiler/cond:Global&>" = type { ptr }
%"std/prelude/list:List<compiler/source:NameId>" = type { ptr }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List<std/prelude/text:Char>" }
%"std/prelude/list:List<std/prelude/text:Char>" = type { ptr }
@G_2ecompiler_2fcond_2eLiteralIntBits = global i64 zeroinitializer
define dso_local void @compiler_2fcond_2eLiteralIntBits_2einit() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 64, ptr @G_2ecompiler_2fcond_2eLiteralIntBits, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i1, double } @compiler_2fcond_2easFloat(%"compiler/cond:Value" %a0) #0 {
entry:
  %l0 = alloca %"compiler/cond:Value"
  %l1 = alloca i64
  %l2 = alloca i1
  %l3 = alloca i1
  %l4 = alloca i64
  %l5 = alloca i1
  %l6 = alloca i1
  %l7 = alloca i64
  %l8 = alloca i1
  %l9 = alloca { i1, double }
  %l10 = alloca i64
  %l11 = alloca double
  %l12 = alloca { i1, double }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { i1, double }
  store %"compiler/cond:Value" %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/cond:Value", ptr %l0, i32 0, i32 4
  %t2 = load i64, ptr %t1, !tbaa !24
  store i64 %t2, ptr %l1, !tbaa !24
  %t3 = load i64, ptr %l1, !tbaa !24
  %t4 = icmp ne i64 %t3, 0
  store i1 %t4, ptr %l2, !tbaa !21
  %t5 = load i1, ptr %l2, !tbaa !21
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  %t6 = getelementptr %"compiler/cond:Value", ptr %l0, i32 0, i32 1
  %t7 = load i64, ptr %t6, !tbaa !24
  store i64 %t7, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t9 = icmp sgt i64 %t8, 9007199254740992
  store i1 %t9, ptr %l5, !tbaa !21
  %t10 = load i1, ptr %l5, !tbaa !21
  store i1 %t10, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l3, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb6
bb5:
  %t12 = getelementptr %"compiler/cond:Value", ptr %l0, i32 0, i32 1
  %t13 = load i64, ptr %t12, !tbaa !24
  store i64 %t13, ptr %l7, !tbaa !24
  %t14 = load i64, ptr %l7, !tbaa !24
  %t15 = icmp slt i64 %t14, -9007199254740992
  store i1 %t15, ptr %l8, !tbaa !21
  %t16 = load i1, ptr %l8, !tbaa !21
  store i1 %t16, ptr %l6, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l6, !tbaa !21
  br i1 %t17, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s1
  %t18 = insertvalue { i1, double } undef, i1 false, 0
  %t19 = insertvalue { i1, double } %t18, double 0x0000000000000000, 1
  store { i1, double } %t19, ptr %l9
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t20 = load { i1, double }, ptr %l9
  store { i1, double } %t20, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t21 = getelementptr %"compiler/cond:Value", ptr %l0, i32 0, i32 1
  %t22 = load i64, ptr %t21, !tbaa !24
  store i64 %t22, ptr %l10, !tbaa !24
  %t23 = load i64, ptr %l10, !tbaa !24
  %t24 = sitofp i64 %t23 to double
  store double %t24, ptr %l11, !tbaa !26
  %t25 = insertvalue { i1, double } undef, i1 true, 0
  %t26 = load double, ptr %l11, !tbaa !26
  %t27 = insertvalue { i1, double } %t25, double %t26, 1
  store { i1, double } %t27, ptr %l12
  call void @__olang_scope_close(ptr %s0)
  %t28 = load { i1, double }, ptr %l12
  store { i1, double } %t28, ptr %rv
  br label %ret
ret:
  %rr = load { i1, double }, ptr %rv
  ret { i1, double } %rr
}

define dso_local i32 @compiler_2fcond_2ebadDefine(ptr %v0, ptr %v1, ptr %a0, %"compiler/msgs:Msg" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/msgs:Msg"
  %l2 = alloca ptr
  %l3 = alloca { i64, [3 x i64] }
  %l4 = alloca %"compiler/msgs:Msg"
  %l5 = alloca i64
  %l6 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  %t2 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/msgs:Msg" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t2
  %t3 = getelementptr { i64, [3 x i64] }, ptr %t2, i32 0, i32 0
  store i64 0, ptr %t3
  %t4 = load { i64, [3 x i64] }, ptr %t2
  store { i64, [3 x i64] } %t4, ptr %l3
  %t5 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t5, ptr %l4
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t7 = load { i64, [3 x i64] }, ptr %l3
  %t8 = load %"compiler/msgs:Msg", ptr %l4
  %t9 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %t6, { i64, [3 x i64] } %t7, %"compiler/msgs:Msg" %t8)
  store i64 %t9, ptr %l5
  br label %bb1
bb1:
  store i32 65536, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t10 = load i32, ptr %l6, !tbaa !23
  store i32 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"compiler/cond:Value" @compiler_2fcond_2eboolValue(i1 %a0) #0 {
entry:
  %l0 = alloca i1
  %l1 = alloca i32
  %l2 = alloca i1
  %l3 = alloca i64
  %l4 = alloca %"compiler/cond:Value"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/cond:Value"
  store i1 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 1, ptr %l1
  %t1 = load i1, ptr %l0, !tbaa !21
  store i1 %t1, ptr %l2, !tbaa !21
  %t2 = load i1, ptr %l2, !tbaa !21
  br i1 %t2, label %bb1, label %bb2
bb1:
  store i64 1, ptr %l3, !tbaa !24
  br label %bb3
bb2:
  store i64 0, ptr %l3, !tbaa !24
  br label %bb3
bb3:
  %t3 = load i32, ptr %l1
  %t4 = load i64, ptr %l3, !tbaa !24
  %t5 = call %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %s0, i32 %t3, i64 %t4, double 0x0000000000000000, i64 0, i64 0, i1 false)
  store %"compiler/cond:Value" %t5, ptr %l4
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t6 = load %"compiler/cond:Value", ptr %l4
  store %"compiler/cond:Value" %t6, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cond:Value", ptr %rv
  ret %"compiler/cond:Value" %rr
}

define dso_local i1 @compiler_2fcond_2ebuildType(%"compiler/cond:Value" %a0) #0 {
entry:
  %l0 = alloca %"compiler/cond:Value"
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i1
  %l4 = alloca i32
  %l5 = alloca i1
  %l6 = alloca i32
  %l7 = alloca i1
  %l8 = alloca i32
  %l9 = alloca i1
  %l10 = alloca i64
  %l11 = alloca i1
  %l12 = alloca i32
  %l13 = alloca i1
  %l14 = alloca i1
  %l15 = alloca i1
  %l16 = alloca i64
  %l17 = alloca i1
  %l18 = alloca i64
  %l19 = alloca i1
  %l20 = alloca i1
  %l21 = alloca i64
  %l22 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i1
  store %"compiler/cond:Value" %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/cond:Value", ptr %l0, i32 0, i32 0
  %t2 = load i32, ptr %t1
  store i32 %t2, ptr %l2
  %t3 = load i32, ptr %l2
  store i32 %t3, ptr %l1
  %t4 = load i32, ptr %l1
  store i32 %t4, ptr %l4
  %t5 = load i32, ptr %l4
  %t6 = trunc i64 1 to i32
  %t7 = icmp eq i32 %t5, %t6
  store i1 %t7, ptr %l5, !tbaa !21
  %t8 = load i1, ptr %l5, !tbaa !21
  br i1 %t8, label %bb1, label %bb2
bb1:
  br label %bb5
bb2:
  %t9 = load i32, ptr %l1
  store i32 %t9, ptr %l6
  %t10 = load i32, ptr %l6
  %t11 = trunc i64 4 to i32
  %t12 = icmp eq i32 %t10, %t11
  store i1 %t12, ptr %l7, !tbaa !21
  %t13 = load i1, ptr %l7, !tbaa !21
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  store i1 true, ptr %l3, !tbaa !21
  call void @__olang_scope_close(ptr %s1)
  br label %bb25
bb6:
  %t14 = load i32, ptr %l1
  store i32 %t14, ptr %l8
  %t15 = load i32, ptr %l8
  %t16 = trunc i64 3 to i32
  %t17 = icmp eq i32 %t15, %t16
  store i1 %t17, ptr %l9, !tbaa !21
  %t18 = load i1, ptr %l9, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t19 = getelementptr %"compiler/cond:Value", ptr %l0, i32 0, i32 4
  %t20 = load i64, ptr %t19, !tbaa !24
  store i64 %t20, ptr %l10, !tbaa !24
  %t21 = load i64, ptr %l10, !tbaa !24
  %t22 = icmp eq i64 %t21, 64
  store i1 %t22, ptr %l11, !tbaa !21
  %t23 = load i1, ptr %l11, !tbaa !21
  store i1 %t23, ptr %l3, !tbaa !21
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb10:
  %t24 = load i32, ptr %l1
  store i32 %t24, ptr %l12
  %t25 = load i32, ptr %l12
  %t26 = trunc i64 2 to i32
  %t27 = icmp eq i32 %t25, %t26
  store i1 %t27, ptr %l13, !tbaa !21
  %t28 = load i1, ptr %l13, !tbaa !21
  br i1 %t28, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb20
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t29 = getelementptr %"compiler/cond:Value", ptr %l0, i32 0, i32 5
  %t30 = load i1, ptr %t29, !tbaa !21
  store i1 %t30, ptr %l14, !tbaa !21
  %t31 = load i1, ptr %l14, !tbaa !21
  br i1 %t31, label %bb14, label %bb15
bb14:
  %t32 = getelementptr %"compiler/cond:Value", ptr %l0, i32 0, i32 4
  %t33 = load i64, ptr %t32, !tbaa !24
  store i64 %t33, ptr %l16, !tbaa !24
  %t34 = load i64, ptr %l16, !tbaa !24
  %t35 = icmp eq i64 %t34, 64
  store i1 %t35, ptr %l17, !tbaa !21
  %t36 = load i1, ptr %l17, !tbaa !21
  store i1 %t36, ptr %l15, !tbaa !21
  br label %bb19
bb15:
  %t37 = getelementptr %"compiler/cond:Value", ptr %l0, i32 0, i32 4
  %t38 = load i64, ptr %t37, !tbaa !24
  store i64 %t38, ptr %l18, !tbaa !24
  %t39 = load i64, ptr %l18, !tbaa !24
  %t40 = icmp eq i64 %t39, 32
  store i1 %t40, ptr %l19, !tbaa !21
  %t41 = load i1, ptr %l19, !tbaa !21
  br i1 %t41, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb18
bb17:
  %t42 = getelementptr %"compiler/cond:Value", ptr %l0, i32 0, i32 4
  %t43 = load i64, ptr %t42, !tbaa !24
  store i64 %t43, ptr %l21, !tbaa !24
  %t44 = load i64, ptr %l21, !tbaa !24
  %t45 = icmp eq i64 %t44, 64
  store i1 %t45, ptr %l22, !tbaa !21
  %t46 = load i1, ptr %l22, !tbaa !21
  store i1 %t46, ptr %l20, !tbaa !21
  br label %bb18
bb18:
  %t47 = load i1, ptr %l20, !tbaa !21
  store i1 %t47, ptr %l15, !tbaa !21
  br label %bb19
bb19:
  %t48 = load i1, ptr %l15, !tbaa !21
  store i1 %t48, ptr %l3, !tbaa !21
  call void @__olang_scope_close(ptr %s3)
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s4
  store i1 false, ptr %l3, !tbaa !21
  call void @__olang_scope_close(ptr %s4)
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @.c0)
  unreachable
bb25:
  call void @__olang_scope_close(ptr %s0)
  %t49 = load i1, ptr %l3, !tbaa !21
  store i1 %t49, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eBuiltins(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, i64 %a4, i64 %a5, i1 %a6, i1 %a7, i1 %a8) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i1
  %l7 = alloca i1
  %l8 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca %"compiler/cond:Value"
  %l15 = alloca { i64, ptr }
  %l16 = alloca i1
  %l17 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca %"compiler/cond:Value"
  %l24 = alloca { i64, ptr }
  %l25 = alloca i1
  %l26 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i32
  %l29 = alloca ptr
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca %"compiler/cond:Value"
  %l33 = alloca { i64, ptr }
  %l34 = alloca i1
  %l35 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca i32
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca %"compiler/cond:Value"
  %l41 = alloca i64
  %l42 = alloca i1
  %l43 = alloca ptr
  %l44 = alloca i64
  %l45 = alloca i1
  %l46 = alloca %"compiler/cond:Value"
  %l47 = alloca i64
  %l48 = alloca i1
  %l49 = alloca ptr
  %l50 = alloca i1
  %l51 = alloca %"compiler/cond:Value"
  %l52 = alloca ptr
  %l53 = alloca i1
  %l54 = alloca %"compiler/cond:Value"
  %l55 = alloca ptr
  %l56 = alloca i1
  %l57 = alloca %"compiler/cond:Value"
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store i64 %a4, ptr %l4
  store i64 %a5, ptr %l5
  store i1 %a6, ptr %l6
  store i1 %a7, ptr %l7
  store i1 %a8, ptr %l8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i32 4, ptr %l10
  %t2 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2, ptr %l11, !tbaa !29
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t3, ptr %l12, !tbaa !27
  %t4 = load ptr, ptr %l11, !tbaa !29
  %t5 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t6 = call i64 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2etext(ptr %v0, ptr %v1, ptr %t4, { i64, ptr } %t5)
  store i64 %t6, ptr %l13
  br label %bb1
bb1:
  %t7 = load i32, ptr %l10
  %t8 = load i64, ptr %l13, !tbaa !24
  %t9 = call %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %s0, i32 %t7, i64 0, double 0x0000000000000000, i64 %t8, i64 0, i1 false)
  store %"compiler/cond:Value" %t9, ptr %l14
  br label %bb2
bb2:
  %t10 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t10, ptr %l15, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t12 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t11, { i64, ptr } { i64 0, ptr @.d1 })
  store i1 %t12, ptr %l16
  br label %bb3
bb3:
  %t13 = load i1, ptr %l16, !tbaa !21
  %t14 = xor i1 %t13, true
  store i1 %t14, ptr %l17, !tbaa !21
  %t15 = load ptr, ptr %l9, !tbaa !29
  %t16 = load %"compiler/cond:Value", ptr %l14
  %t17 = load i1, ptr %l17, !tbaa !21
  call void @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eadd(ptr %v0, ptr %s0, ptr %t15, { i64, ptr } { i64 8, ptr @.d2 }, %"compiler/cond:Value" %t16, i1 true, i1 false, i1 %t17)
  br label %bb4
bb4:
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %l18, !tbaa !29
  store i32 4, ptr %l19
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l20, !tbaa !29
  %t20 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t20, ptr %l21, !tbaa !27
  %t21 = load ptr, ptr %l20, !tbaa !29
  %t22 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t23 = call i64 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2etext(ptr %v0, ptr %v2, ptr %t21, { i64, ptr } %t22)
  store i64 %t23, ptr %l22
  br label %bb5
bb5:
  %t24 = load i32, ptr %l19
  %t25 = load i64, ptr %l22, !tbaa !24
  %t26 = call %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %s0, i32 %t24, i64 0, double 0x0000000000000000, i64 %t25, i64 0, i1 false)
  store %"compiler/cond:Value" %t26, ptr %l23
  br label %bb6
bb6:
  %t27 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t27, ptr %l24, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t29 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t28, { i64, ptr } { i64 0, ptr @.d3 })
  store i1 %t29, ptr %l25
  br label %bb7
bb7:
  %t30 = load i1, ptr %l25, !tbaa !21
  %t31 = xor i1 %t30, true
  store i1 %t31, ptr %l26, !tbaa !21
  %t32 = load ptr, ptr %l18, !tbaa !29
  %t33 = load %"compiler/cond:Value", ptr %l23
  %t34 = load i1, ptr %l26, !tbaa !21
  call void @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eadd(ptr %v0, ptr %s0, ptr %t32, { i64, ptr } { i64 10, ptr @.d4 }, %"compiler/cond:Value" %t33, i1 true, i1 false, i1 %t34)
  br label %bb8
bb8:
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l27, !tbaa !29
  store i32 4, ptr %l28
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l29, !tbaa !29
  %t37 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t37, ptr %l30, !tbaa !27
  %t38 = load ptr, ptr %l29, !tbaa !29
  %t39 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t40 = call i64 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2etext(ptr %v0, ptr %v3, ptr %t38, { i64, ptr } %t39)
  store i64 %t40, ptr %l31
  br label %bb9
bb9:
  %t41 = load i32, ptr %l28
  %t42 = load i64, ptr %l31, !tbaa !24
  %t43 = call %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %s0, i32 %t41, i64 0, double 0x0000000000000000, i64 %t42, i64 0, i1 false)
  store %"compiler/cond:Value" %t43, ptr %l32
  br label %bb10
bb10:
  %t44 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t44, ptr %l33, !tbaa !27
  %t45 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t46 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s0, { i64, ptr } %t45, { i64, ptr } { i64 0, ptr @.d5 })
  store i1 %t46, ptr %l34
  br label %bb11
bb11:
  %t47 = load i1, ptr %l34, !tbaa !21
  %t48 = xor i1 %t47, true
  store i1 %t48, ptr %l35, !tbaa !21
  %t49 = load ptr, ptr %l27, !tbaa !29
  %t50 = load %"compiler/cond:Value", ptr %l32
  %t51 = load i1, ptr %l35, !tbaa !21
  call void @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eadd(ptr %v0, ptr %s0, ptr %t49, { i64, ptr } { i64 9, ptr @.d6 }, %"compiler/cond:Value" %t50, i1 true, i1 false, i1 %t51)
  br label %bb12
bb12:
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %l36, !tbaa !29
  store i32 2, ptr %l37
  %t53 = load i64, ptr %l4, !tbaa !24
  store i64 %t53, ptr %l38, !tbaa !24
  %t54 = load i64, ptr @G_2ecompiler_2fcond_2eLiteralIntBits, !tbaa !24
  store i64 %t54, ptr %l39, !tbaa !24
  %t55 = load i32, ptr %l37
  %t56 = load i64, ptr %l38, !tbaa !24
  %t57 = load i64, ptr %l39, !tbaa !24
  %t58 = call %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %s0, i32 %t55, i64 %t56, double 0x0000000000000000, i64 0, i64 %t57, i1 false)
  store %"compiler/cond:Value" %t58, ptr %l40
  br label %bb13
bb13:
  %t59 = load i64, ptr %l4, !tbaa !24
  store i64 %t59, ptr %l41, !tbaa !24
  %t60 = load i64, ptr %l41, !tbaa !24
  %t61 = icmp sgt i64 %t60, 0
  store i1 %t61, ptr %l42, !tbaa !21
  %t62 = load ptr, ptr %l36, !tbaa !29
  %t63 = load %"compiler/cond:Value", ptr %l40
  %t64 = load i1, ptr %l42, !tbaa !21
  call void @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eadd(ptr %v0, ptr %s0, ptr %t62, { i64, ptr } { i64 16, ptr @.d7 }, %"compiler/cond:Value" %t63, i1 true, i1 false, i1 %t64)
  br label %bb14
bb14:
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l43, !tbaa !29
  %t66 = load i64, ptr %l5, !tbaa !24
  store i64 %t66, ptr %l44, !tbaa !24
  %t67 = load i64, ptr %l44, !tbaa !24
  %t68 = icmp eq i64 %t67, 1
  store i1 %t68, ptr %l45, !tbaa !21
  %t69 = load i1, ptr %l45, !tbaa !21
  %t70 = call %"compiler/cond:Value" @compiler_2fcond_2eboolValue(i1 %t69)
  store %"compiler/cond:Value" %t70, ptr %l46
  br label %bb15
bb15:
  %t71 = load i64, ptr %l5, !tbaa !24
  store i64 %t71, ptr %l47, !tbaa !24
  %t72 = load i64, ptr %l47, !tbaa !24
  %t73 = icmp sge i64 %t72, 0
  store i1 %t73, ptr %l48, !tbaa !21
  %t74 = load ptr, ptr %l43, !tbaa !29
  %t75 = load %"compiler/cond:Value", ptr %l46
  %t76 = load i1, ptr %l48, !tbaa !21
  call void @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eadd(ptr %v0, ptr %s0, ptr %t74, { i64, ptr } { i64 12, ptr @.d8 }, %"compiler/cond:Value" %t75, i1 true, i1 false, i1 %t76)
  br label %bb16
bb16:
  %t77 = load ptr, ptr %l0, !tbaa !29
  store ptr %t77, ptr %l49, !tbaa !29
  %t78 = load i1, ptr %l6, !tbaa !21
  store i1 %t78, ptr %l50, !tbaa !21
  %t79 = load i1, ptr %l50, !tbaa !21
  %t80 = call %"compiler/cond:Value" @compiler_2fcond_2eboolValue(i1 %t79)
  store %"compiler/cond:Value" %t80, ptr %l51
  br label %bb17
bb17:
  %t81 = load ptr, ptr %l49, !tbaa !29
  %t82 = load %"compiler/cond:Value", ptr %l51
  call void @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eadd(ptr %v0, ptr %s0, ptr %t81, { i64, ptr } { i64 10, ptr @.d9 }, %"compiler/cond:Value" %t82, i1 true, i1 false, i1 true)
  br label %bb18
bb18:
  %t83 = load ptr, ptr %l0, !tbaa !29
  store ptr %t83, ptr %l52, !tbaa !29
  %t84 = load i1, ptr %l7, !tbaa !21
  store i1 %t84, ptr %l53, !tbaa !21
  %t85 = load i1, ptr %l53, !tbaa !21
  %t86 = call %"compiler/cond:Value" @compiler_2fcond_2eboolValue(i1 %t85)
  store %"compiler/cond:Value" %t86, ptr %l54
  br label %bb19
bb19:
  %t87 = load ptr, ptr %l52, !tbaa !29
  %t88 = load %"compiler/cond:Value", ptr %l54
  call void @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eadd(ptr %v0, ptr %s0, ptr %t87, { i64, ptr } { i64 9, ptr @.d10 }, %"compiler/cond:Value" %t88, i1 true, i1 false, i1 true)
  br label %bb20
bb20:
  %t89 = load ptr, ptr %l0, !tbaa !29
  store ptr %t89, ptr %l55, !tbaa !29
  %t90 = load i1, ptr %l8, !tbaa !21
  store i1 %t90, ptr %l56, !tbaa !21
  %t91 = load i1, ptr %l56, !tbaa !21
  %t92 = call %"compiler/cond:Value" @compiler_2fcond_2eboolValue(i1 %t91)
  store %"compiler/cond:Value" %t92, ptr %l57
  br label %bb21
bb21:
  %t93 = load ptr, ptr %l55, !tbaa !29
  %t94 = load %"compiler/cond:Value", ptr %l57
  call void @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eadd(ptr %v0, ptr %s0, ptr %t93, { i64, ptr } { i64 9, ptr @.d11 }, %"compiler/cond:Value" %t94, i1 true, i1 false, i1 true)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eDefine(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i8
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i1
  %l17 = alloca i1
  %l18 = alloca i1
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i1
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i1
  %l33 = alloca i1
  %l34 = alloca i1
  %l35 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i1
  %l44 = alloca i1
  %l45 = alloca i1
  %l46 = alloca { i64, ptr }
  %l47 = alloca ptr
  %l48 = alloca { i64, ptr }
  %l49 = alloca i32
  %l50 = alloca i1
  %l51 = alloca i1
  %l52 = alloca i1
  %l53 = alloca i1
  %l54 = alloca i1
  %l55 = alloca i1
  %l56 = alloca i1
  %l57 = alloca i1
  %l58 = alloca i32
  %l59 = alloca ptr
  %l60 = alloca { i64, ptr }
  %l61 = alloca %"compiler/msgs:Msg"
  %l62 = alloca i32
  %l63 = alloca i32
  %l64 = alloca ptr
  %l65 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l67 = alloca %"compiler/msgs:Msg"
  %l68 = alloca i32
  %l69 = alloca i32
  %l70 = alloca ptr
  %l71 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l73 = alloca %"compiler/msgs:Msg"
  %l74 = alloca i32
  %l75 = alloca i32
  %l76 = alloca ptr
  %l77 = alloca { i64, ptr }
  %l78 = alloca %"compiler/msgs:Msg"
  %l79 = alloca i32
  %l80 = alloca i32
  %l81 = alloca ptr
  %l82 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l84 = alloca %"compiler/msgs:Msg"
  %l85 = alloca i32
  %l86 = alloca i32
  %l87 = alloca ptr
  %l88 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l90 = alloca %"compiler/msgs:Msg"
  %l91 = alloca i32
  %l92 = alloca i32
  %l93 = alloca ptr
  %l94 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l96 = alloca %"compiler/msgs:Msg"
  %l97 = alloca i32
  %l98 = alloca i32
  %l99 = alloca ptr
  %l100 = alloca { i64, ptr }
  %l101 = alloca { i64, ptr }
  %l102 = alloca %"compiler/msgs:Msg"
  %l103 = alloca i32
  %l104 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t1, ptr %l7, !tbaa !27
  store i8 61, ptr %l8, !tbaa !22
  %t2 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t3 = load i8, ptr %l8, !tbaa !22
  %t4 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v1, { i64, ptr } %t2, i8 %t3)
  %t5 = extractvalue { i32, i64 } %t4, 1
  %t6 = extractvalue { i32, i64 } %t4, 0
  store i32 %t6, ptr %l10
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8
ok.8:
  store i64 %t5, ptr %l9
  br label %bb1
bb1:
  %t9 = load i64, ptr %l9, !tbaa !24
  store i64 %t9, ptr %l6, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  %t10 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t10, ptr %l11, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t11, 0
  store i64 %t12, ptr %l12, !tbaa !24
  %t13 = load i64, ptr %l12, !tbaa !24
  store i64 %t13, ptr %l6, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l6, !tbaa !24
  store i64 %t14, ptr %l3, !tbaa !24
  %t15 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t15, ptr %l13, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  store i64 %t16, ptr %l14, !tbaa !24
  %t17 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t17, 0
  store i64 %t18, ptr %l15, !tbaa !24
  %t19 = icmp sge i64 0, 0
  store i1 %t19, ptr %l16, !tbaa !21
  %t20 = load i1, ptr %l16, !tbaa !21
  br i1 %t20, label %bb5, label %bb6
bb5:
  %t21 = load i64, ptr %l14, !tbaa !24
  %t22 = icmp sle i64 0, %t21
  store i1 %t22, ptr %l17, !tbaa !21
  %t23 = load i1, ptr %l17, !tbaa !21
  br i1 %t23, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @.c12)
  unreachable
bb7:
  %t24 = load i64, ptr %l14, !tbaa !24
  %t25 = load i64, ptr %l15, !tbaa !24
  %t26 = icmp sle i64 %t24, %t25
  store i1 %t26, ptr %l18, !tbaa !21
  %t27 = load i1, ptr %l18, !tbaa !21
  br i1 %t27, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @.c12)
  unreachable
bb9:
  %t28 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = load i64, ptr %l14, !tbaa !24
  %t31 = getelementptr i8, ptr %t29, i64 0
  %t32 = sub i64 %t30, 0
  %t33 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t31, 1
  store { i64, ptr } %t34, ptr %l19, !tbaa !27
  %t35 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t35, ptr %l4, !tbaa !27
  %t36 = load i64, ptr %l3, !tbaa !24
  store i64 %t36, ptr %l20, !tbaa !24
  %t37 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t37, ptr %l21, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 0
  store i64 %t39, ptr %l22, !tbaa !24
  %t40 = load i64, ptr %l20, !tbaa !24
  %t41 = load i64, ptr %l22, !tbaa !24
  %t42 = icmp slt i64 %t40, %t41
  store i1 %t42, ptr %l23, !tbaa !21
  %t43 = load i1, ptr %l23, !tbaa !21
  br i1 %t43, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @.c12)
  unreachable
bb11:
  %t44 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t44, ptr %l25, !tbaa !27
  %t45 = load i64, ptr %l3, !tbaa !24
  store i64 %t45, ptr %l26, !tbaa !24
  %t46 = load i64, ptr %l26, !tbaa !24
  %t47 = add i64 %t46, 1
  store i64 %t47, ptr %l27, !tbaa !24
  %t48 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t48, ptr %l28, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t49, ptr %l29, !tbaa !27
  %t50 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t50, 0
  store i64 %t51, ptr %l30, !tbaa !24
  %t52 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t52, 0
  store i64 %t53, ptr %l31, !tbaa !24
  %t54 = load i64, ptr %l27, !tbaa !24
  %t55 = icmp sge i64 %t54, 0
  store i1 %t55, ptr %l32, !tbaa !21
  %t56 = load i1, ptr %l32, !tbaa !21
  br i1 %t56, label %bb13, label %bb14
bb12:
  %t57 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t57, ptr %l36, !tbaa !27
  %t58 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t58, ptr %l37, !tbaa !27
  %t59 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t59, 0
  store i64 %t60, ptr %l38, !tbaa !24
  %t61 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t61, ptr %l39, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t62, ptr %l40, !tbaa !27
  %t63 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t63, 0
  store i64 %t64, ptr %l41, !tbaa !24
  %t65 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t65, 0
  store i64 %t66, ptr %l42, !tbaa !24
  %t67 = load i64, ptr %l38, !tbaa !24
  %t68 = icmp sge i64 %t67, 0
  store i1 %t68, ptr %l43, !tbaa !21
  %t69 = load i1, ptr %l43, !tbaa !21
  br i1 %t69, label %bb19, label %bb20
bb13:
  %t70 = load i64, ptr %l27, !tbaa !24
  %t71 = load i64, ptr %l30, !tbaa !24
  %t72 = icmp sle i64 %t70, %t71
  store i1 %t72, ptr %l33, !tbaa !21
  %t73 = load i1, ptr %l33, !tbaa !21
  br i1 %t73, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @.c13)
  unreachable
bb15:
  %t74 = load i64, ptr %l30, !tbaa !24
  %t75 = load i64, ptr %l31, !tbaa !24
  %t76 = icmp sle i64 %t74, %t75
  store i1 %t76, ptr %l34, !tbaa !21
  %t77 = load i1, ptr %l34, !tbaa !21
  br i1 %t77, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @.c13)
  unreachable
bb17:
  %t78 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = load i64, ptr %l27, !tbaa !24
  %t81 = load i64, ptr %l30, !tbaa !24
  %t82 = getelementptr i8, ptr %t79, i64 %t80
  %t83 = sub i64 %t81, %t80
  %t84 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t82, 1
  store { i64, ptr } %t85, ptr %l35, !tbaa !27
  %t86 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t86, ptr %l24, !tbaa !27
  br label %bb25
bb18:
  call void @__olang_check_failed(ptr @.c13)
  unreachable
bb19:
  %t87 = load i64, ptr %l38, !tbaa !24
  %t88 = load i64, ptr %l41, !tbaa !24
  %t89 = icmp sle i64 %t87, %t88
  store i1 %t89, ptr %l44, !tbaa !21
  %t90 = load i1, ptr %l44, !tbaa !21
  br i1 %t90, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @.c13)
  unreachable
bb21:
  %t91 = load i64, ptr %l41, !tbaa !24
  %t92 = load i64, ptr %l42, !tbaa !24
  %t93 = icmp sle i64 %t91, %t92
  store i1 %t93, ptr %l45, !tbaa !21
  %t94 = load i1, ptr %l45, !tbaa !21
  br i1 %t94, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @.c13)
  unreachable
bb23:
  %t95 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = load i64, ptr %l38, !tbaa !24
  %t98 = load i64, ptr %l41, !tbaa !24
  %t99 = getelementptr i8, ptr %t96, i64 %t97
  %t100 = sub i64 %t98, %t97
  %t101 = insertvalue { i64, ptr } undef, i64 %t100, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t99, 1
  store { i64, ptr } %t102, ptr %l46, !tbaa !27
  %t103 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t103, ptr %l24, !tbaa !27
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @.c13)
  unreachable
bb25:
  %t104 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t104, ptr %l5, !tbaa !27
  %t105 = load ptr, ptr %l0, !tbaa !29
  store ptr %t105, ptr %l47, !tbaa !29
  %t106 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t106, ptr %l48, !tbaa !27
  %t107 = load ptr, ptr %l47, !tbaa !29
  %t108 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t109 = call i32 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2edefine(ptr %v0, ptr %v1, ptr %t107, { i64, ptr } %t108)
  store i32 %t109, ptr %l49
  %t110 = icmp ne i32 %t109, 0
  br i1 %t110, label %bb27, label %ok.111
ok.111:
  br label %bb26
bb26:
  br label %bb84
bb27:
  %t112 = load i32, ptr %l49, !tbaa !23
  %t113 = icmp eq i32 %t112, 65536
  store i1 %t113, ptr %l50, !tbaa !21
  %t114 = load i1, ptr %l50, !tbaa !21
  br i1 %t114, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  %t115 = load i32, ptr %l49, !tbaa !23
  %t116 = icmp eq i32 %t115, 65537
  store i1 %t116, ptr %l51, !tbaa !21
  %t117 = load i1, ptr %l51, !tbaa !21
  br i1 %t117, label %bb31, label %bb32
bb30:
  store %olang.scope zeroinitializer, ptr %s1
  %t118 = load ptr, ptr %l2, !tbaa !29
  store ptr %t118, ptr %l59, !tbaa !29
  %t119 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t119, ptr %l60, !tbaa !27
  %t120 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t121 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefineShape(ptr %v1, ptr %s1, { i64, ptr } %t120)
  store %"compiler/msgs:Msg" %t121, ptr %l61
  br label %bb52
bb31:
  br label %bb33
bb32:
  %t122 = load i32, ptr %l49, !tbaa !23
  %t123 = icmp eq i32 %t122, 65538
  store i1 %t123, ptr %l52, !tbaa !21
  %t124 = load i1, ptr %l52, !tbaa !21
  br i1 %t124, label %bb34, label %bb35
bb33:
  store %olang.scope zeroinitializer, ptr %s2
  %t125 = load ptr, ptr %l2, !tbaa !29
  store ptr %t125, ptr %l64, !tbaa !29
  %t126 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t126, ptr %l65, !tbaa !27
  %t127 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t127, ptr %l66, !tbaa !27
  %t128 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t129 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t130 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefineNotName(ptr %v1, ptr %v1, ptr %s2, { i64, ptr } %t128, { i64, ptr } %t129)
  store %"compiler/msgs:Msg" %t130, ptr %l67
  br label %bb56
bb34:
  br label %bb36
bb35:
  %t131 = load i32, ptr %l49, !tbaa !23
  %t132 = icmp eq i32 %t131, 65539
  store i1 %t132, ptr %l53, !tbaa !21
  %t133 = load i1, ptr %l53, !tbaa !21
  br i1 %t133, label %bb37, label %bb38
bb36:
  store %olang.scope zeroinitializer, ptr %s3
  %t134 = load ptr, ptr %l2, !tbaa !29
  store ptr %t134, ptr %l70, !tbaa !29
  %t135 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t135, ptr %l71, !tbaa !27
  %t136 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t136, ptr %l72, !tbaa !27
  %t137 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t138 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t139 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefineTwice(ptr %v1, ptr %v1, ptr %s3, { i64, ptr } %t137, { i64, ptr } %t138)
  store %"compiler/msgs:Msg" %t139, ptr %l73
  br label %bb60
bb37:
  br label %bb39
bb38:
  %t140 = load i32, ptr %l49, !tbaa !23
  %t141 = icmp eq i32 %t140, 65540
  store i1 %t141, ptr %l54, !tbaa !21
  %t142 = load i1, ptr %l54, !tbaa !21
  br i1 %t142, label %bb40, label %bb41
bb39:
  store %olang.scope zeroinitializer, ptr %s4
  %t143 = load ptr, ptr %l2, !tbaa !29
  store ptr %t143, ptr %l76, !tbaa !29
  %t144 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t144, ptr %l77, !tbaa !27
  %t145 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t146 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefineBuiltin(ptr %v1, ptr %s4, { i64, ptr } %t145)
  store %"compiler/msgs:Msg" %t146, ptr %l78
  br label %bb64
bb40:
  br label %bb42
bb41:
  %t147 = load i32, ptr %l49, !tbaa !23
  %t148 = icmp eq i32 %t147, 65541
  store i1 %t148, ptr %l55, !tbaa !21
  %t149 = load i1, ptr %l55, !tbaa !21
  br i1 %t149, label %bb43, label %bb44
bb42:
  store %olang.scope zeroinitializer, ptr %s5
  %t150 = load ptr, ptr %l2, !tbaa !29
  store ptr %t150, ptr %l81, !tbaa !29
  %t151 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t151, ptr %l82, !tbaa !27
  %t152 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t152, ptr %l83, !tbaa !27
  %t153 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t154 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t155 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefineBadNumber(ptr %v1, ptr %v1, ptr %s5, { i64, ptr } %t153, { i64, ptr } %t154)
  store %"compiler/msgs:Msg" %t155, ptr %l84
  br label %bb68
bb43:
  br label %bb45
bb44:
  %t156 = load i32, ptr %l49, !tbaa !23
  %t157 = icmp eq i32 %t156, 65542
  store i1 %t157, ptr %l56, !tbaa !21
  %t158 = load i1, ptr %l56, !tbaa !21
  br i1 %t158, label %bb46, label %bb47
bb45:
  store %olang.scope zeroinitializer, ptr %s6
  %t159 = load ptr, ptr %l2, !tbaa !29
  store ptr %t159, ptr %l87, !tbaa !29
  %t160 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t160, ptr %l88, !tbaa !27
  %t161 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t161, ptr %l89, !tbaa !27
  %t162 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t163 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t164 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefineIntRange(ptr %v1, ptr %v1, ptr %s6, { i64, ptr } %t162, { i64, ptr } %t163)
  store %"compiler/msgs:Msg" %t164, ptr %l90
  br label %bb72
bb46:
  br label %bb48
bb47:
  %t165 = load i32, ptr %l49, !tbaa !23
  %t166 = icmp eq i32 %t165, 65543
  store i1 %t166, ptr %l57, !tbaa !21
  %t167 = load i1, ptr %l57, !tbaa !21
  br i1 %t167, label %bb49, label %bb50
bb48:
  store %olang.scope zeroinitializer, ptr %s7
  %t168 = load ptr, ptr %l2, !tbaa !29
  store ptr %t168, ptr %l93, !tbaa !29
  %t169 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t169, ptr %l94, !tbaa !27
  %t170 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t170, ptr %l95, !tbaa !27
  %t171 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t172 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t173 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefineNegRange(ptr %v1, ptr %v1, ptr %s7, { i64, ptr } %t171, { i64, ptr } %t172)
  store %"compiler/msgs:Msg" %t173, ptr %l96
  br label %bb76
bb49:
  br label %bb51
bb50:
  %t174 = load i32, ptr %l49, !tbaa !23
  %t175 = lshr i32 %t174, 16
  %t176 = and i32 %t174, 65535
  %t177 = icmp eq i32 %t175, 1
  %t178 = select i1 %t177, i32 0, i32 0
  %t179 = icmp eq i32 %t174, 0
  %t180 = shl i32 %t178, 16
  %t181 = or i32 %t180, %t176
  %t182 = select i1 %t179, i32 0, i32 %t181
  store i32 %t182, ptr %l58, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t183 = load i32, ptr %l58, !tbaa !23
  store i32 %t183, ptr %rv
  br label %ret
bb51:
  store %olang.scope zeroinitializer, ptr %s8
  %t184 = load ptr, ptr %l2, !tbaa !29
  store ptr %t184, ptr %l99, !tbaa !29
  %t185 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t185, ptr %l100, !tbaa !27
  %t186 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t186, ptr %l101, !tbaa !27
  %t187 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t188 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t189 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefineFloatRange(ptr %v1, ptr %v1, ptr %s8, { i64, ptr } %t187, { i64, ptr } %t188)
  store %"compiler/msgs:Msg" %t189, ptr %l102
  br label %bb80
bb52:
  %t190 = load ptr, ptr %l59, !tbaa !29
  %t191 = load %"compiler/msgs:Msg", ptr %l61
  %t192 = call i32 @compiler_2fcond_2ebadDefine(ptr %v2, ptr %s1, ptr %t190, %"compiler/msgs:Msg" %t191)
  store i32 %t192, ptr %l62
  %t193 = icmp ne i32 %t192, 0
  br i1 %t193, label %bb54, label %ok.194
ok.194:
  br label %bb53
bb53:
  br label %bb55
bb54:
  %t195 = load i32, ptr %l62, !tbaa !23
  %t196 = lshr i32 %t195, 16
  %t197 = and i32 %t195, 65535
  %t198 = icmp eq i32 %t196, 1
  %t199 = select i1 %t198, i32 1, i32 0
  %t200 = icmp eq i32 %t195, 0
  %t201 = shl i32 %t199, 16
  %t202 = or i32 %t201, %t197
  %t203 = select i1 %t200, i32 0, i32 %t202
  store i32 %t203, ptr %l63, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t204 = load i32, ptr %l63, !tbaa !23
  store i32 %t204, ptr %rv
  br label %ret
bb55:
  call void @__olang_scope_close(ptr %s1)
  br label %bb84
bb56:
  %t205 = load ptr, ptr %l64, !tbaa !29
  %t206 = load %"compiler/msgs:Msg", ptr %l67
  %t207 = call i32 @compiler_2fcond_2ebadDefine(ptr %v2, ptr %s2, ptr %t205, %"compiler/msgs:Msg" %t206)
  store i32 %t207, ptr %l68
  %t208 = icmp ne i32 %t207, 0
  br i1 %t208, label %bb58, label %ok.209
ok.209:
  br label %bb57
bb57:
  br label %bb59
bb58:
  %t210 = load i32, ptr %l68, !tbaa !23
  %t211 = lshr i32 %t210, 16
  %t212 = and i32 %t210, 65535
  %t213 = icmp eq i32 %t211, 1
  %t214 = select i1 %t213, i32 1, i32 0
  %t215 = icmp eq i32 %t210, 0
  %t216 = shl i32 %t214, 16
  %t217 = or i32 %t216, %t212
  %t218 = select i1 %t215, i32 0, i32 %t217
  store i32 %t218, ptr %l69, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t219 = load i32, ptr %l69, !tbaa !23
  store i32 %t219, ptr %rv
  br label %ret
bb59:
  call void @__olang_scope_close(ptr %s2)
  br label %bb84
bb60:
  %t220 = load ptr, ptr %l70, !tbaa !29
  %t221 = load %"compiler/msgs:Msg", ptr %l73
  %t222 = call i32 @compiler_2fcond_2ebadDefine(ptr %v2, ptr %s3, ptr %t220, %"compiler/msgs:Msg" %t221)
  store i32 %t222, ptr %l74
  %t223 = icmp ne i32 %t222, 0
  br i1 %t223, label %bb62, label %ok.224
ok.224:
  br label %bb61
bb61:
  br label %bb63
bb62:
  %t225 = load i32, ptr %l74, !tbaa !23
  %t226 = lshr i32 %t225, 16
  %t227 = and i32 %t225, 65535
  %t228 = icmp eq i32 %t226, 1
  %t229 = select i1 %t228, i32 1, i32 0
  %t230 = icmp eq i32 %t225, 0
  %t231 = shl i32 %t229, 16
  %t232 = or i32 %t231, %t227
  %t233 = select i1 %t230, i32 0, i32 %t232
  store i32 %t233, ptr %l75, !tbaa !23
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t234 = load i32, ptr %l75, !tbaa !23
  store i32 %t234, ptr %rv
  br label %ret
bb63:
  call void @__olang_scope_close(ptr %s3)
  br label %bb84
bb64:
  %t235 = load ptr, ptr %l76, !tbaa !29
  %t236 = load %"compiler/msgs:Msg", ptr %l78
  %t237 = call i32 @compiler_2fcond_2ebadDefine(ptr %v2, ptr %s4, ptr %t235, %"compiler/msgs:Msg" %t236)
  store i32 %t237, ptr %l79
  %t238 = icmp ne i32 %t237, 0
  br i1 %t238, label %bb66, label %ok.239
ok.239:
  br label %bb65
bb65:
  br label %bb67
bb66:
  %t240 = load i32, ptr %l79, !tbaa !23
  %t241 = lshr i32 %t240, 16
  %t242 = and i32 %t240, 65535
  %t243 = icmp eq i32 %t241, 1
  %t244 = select i1 %t243, i32 1, i32 0
  %t245 = icmp eq i32 %t240, 0
  %t246 = shl i32 %t244, 16
  %t247 = or i32 %t246, %t242
  %t248 = select i1 %t245, i32 0, i32 %t247
  store i32 %t248, ptr %l80, !tbaa !23
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t249 = load i32, ptr %l80, !tbaa !23
  store i32 %t249, ptr %rv
  br label %ret
bb67:
  call void @__olang_scope_close(ptr %s4)
  br label %bb84
bb68:
  %t250 = load ptr, ptr %l81, !tbaa !29
  %t251 = load %"compiler/msgs:Msg", ptr %l84
  %t252 = call i32 @compiler_2fcond_2ebadDefine(ptr %v2, ptr %s5, ptr %t250, %"compiler/msgs:Msg" %t251)
  store i32 %t252, ptr %l85
  %t253 = icmp ne i32 %t252, 0
  br i1 %t253, label %bb70, label %ok.254
ok.254:
  br label %bb69
bb69:
  br label %bb71
bb70:
  %t255 = load i32, ptr %l85, !tbaa !23
  %t256 = lshr i32 %t255, 16
  %t257 = and i32 %t255, 65535
  %t258 = icmp eq i32 %t256, 1
  %t259 = select i1 %t258, i32 1, i32 0
  %t260 = icmp eq i32 %t255, 0
  %t261 = shl i32 %t259, 16
  %t262 = or i32 %t261, %t257
  %t263 = select i1 %t260, i32 0, i32 %t262
  store i32 %t263, ptr %l86, !tbaa !23
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t264 = load i32, ptr %l86, !tbaa !23
  store i32 %t264, ptr %rv
  br label %ret
bb71:
  call void @__olang_scope_close(ptr %s5)
  br label %bb84
bb72:
  %t265 = load ptr, ptr %l87, !tbaa !29
  %t266 = load %"compiler/msgs:Msg", ptr %l90
  %t267 = call i32 @compiler_2fcond_2ebadDefine(ptr %v2, ptr %s6, ptr %t265, %"compiler/msgs:Msg" %t266)
  store i32 %t267, ptr %l91
  %t268 = icmp ne i32 %t267, 0
  br i1 %t268, label %bb74, label %ok.269
ok.269:
  br label %bb73
bb73:
  br label %bb75
bb74:
  %t270 = load i32, ptr %l91, !tbaa !23
  %t271 = lshr i32 %t270, 16
  %t272 = and i32 %t270, 65535
  %t273 = icmp eq i32 %t271, 1
  %t274 = select i1 %t273, i32 1, i32 0
  %t275 = icmp eq i32 %t270, 0
  %t276 = shl i32 %t274, 16
  %t277 = or i32 %t276, %t272
  %t278 = select i1 %t275, i32 0, i32 %t277
  store i32 %t278, ptr %l92, !tbaa !23
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t279 = load i32, ptr %l92, !tbaa !23
  store i32 %t279, ptr %rv
  br label %ret
bb75:
  call void @__olang_scope_close(ptr %s6)
  br label %bb84
bb76:
  %t280 = load ptr, ptr %l93, !tbaa !29
  %t281 = load %"compiler/msgs:Msg", ptr %l96
  %t282 = call i32 @compiler_2fcond_2ebadDefine(ptr %v2, ptr %s7, ptr %t280, %"compiler/msgs:Msg" %t281)
  store i32 %t282, ptr %l97
  %t283 = icmp ne i32 %t282, 0
  br i1 %t283, label %bb78, label %ok.284
ok.284:
  br label %bb77
bb77:
  br label %bb79
bb78:
  %t285 = load i32, ptr %l97, !tbaa !23
  %t286 = lshr i32 %t285, 16
  %t287 = and i32 %t285, 65535
  %t288 = icmp eq i32 %t286, 1
  %t289 = select i1 %t288, i32 1, i32 0
  %t290 = icmp eq i32 %t285, 0
  %t291 = shl i32 %t289, 16
  %t292 = or i32 %t291, %t287
  %t293 = select i1 %t290, i32 0, i32 %t292
  store i32 %t293, ptr %l98, !tbaa !23
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  %t294 = load i32, ptr %l98, !tbaa !23
  store i32 %t294, ptr %rv
  br label %ret
bb79:
  call void @__olang_scope_close(ptr %s7)
  br label %bb84
bb80:
  %t295 = load ptr, ptr %l99, !tbaa !29
  %t296 = load %"compiler/msgs:Msg", ptr %l102
  %t297 = call i32 @compiler_2fcond_2ebadDefine(ptr %v2, ptr %s8, ptr %t295, %"compiler/msgs:Msg" %t296)
  store i32 %t297, ptr %l103
  %t298 = icmp ne i32 %t297, 0
  br i1 %t298, label %bb82, label %ok.299
ok.299:
  br label %bb81
bb81:
  br label %bb83
bb82:
  %t300 = load i32, ptr %l103, !tbaa !23
  %t301 = lshr i32 %t300, 16
  %t302 = and i32 %t300, 65535
  %t303 = icmp eq i32 %t301, 1
  %t304 = select i1 %t303, i32 1, i32 0
  %t305 = icmp eq i32 %t300, 0
  %t306 = shl i32 %t304, 16
  %t307 = or i32 %t306, %t302
  %t308 = select i1 %t305, i32 0, i32 %t307
  store i32 %t308, ptr %l104, !tbaa !23
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t309 = load i32, ptr %l104, !tbaa !23
  store i32 %t309, ptr %rv
  br label %ret
bb83:
  call void @__olang_scope_close(ptr %s8)
  br label %bb84
bb84:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eDefined(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca i1
  %l15 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t2, ptr %l5, !tbaa !27
  %t3 = load ptr, ptr %l4, !tbaa !29
  %t4 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t5 = call { i32, i64 } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2efind(ptr %v0, ptr %v1, ptr %t3, { i64, ptr } %t4)
  %t6 = extractvalue { i32, i64 } %t5, 1
  %t7 = extractvalue { i32, i64 } %t5, 0
  store i32 %t7, ptr %l7
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9
ok.9:
  store i64 %t6, ptr %l6
  br label %bb1
bb1:
  %t10 = load i64, ptr %l6, !tbaa !24
  store i64 %t10, ptr %l3, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 -1, ptr %l3, !tbaa !24
  br label %bb4
bb4:
  %t11 = load i64, ptr %l3, !tbaa !24
  store i64 %t11, ptr %l2, !tbaa !24
  %t12 = load i64, ptr %l2, !tbaa !24
  store i64 %t12, ptr %l8, !tbaa !24
  %t13 = load i64, ptr %l8, !tbaa !24
  %t14 = icmp sge i64 %t13, 0
  store i1 %t14, ptr %l9, !tbaa !21
  %t15 = load i1, ptr %l9, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l11, !tbaa !29
  %t17 = load ptr, ptr %l11, !tbaa !29
  %t18 = getelementptr %"compiler/cond:Consts", ptr %t17, i32 0, i32 2
  store ptr %t18, ptr %l12, !tbaa !29
  %t19 = load i64, ptr %l2, !tbaa !24
  store i64 %t19, ptr %l13, !tbaa !24
  %t20 = load ptr, ptr %l12, !tbaa !29
  %t21 = load i64, ptr %l13, !tbaa !24
  %t22 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t20, i64 %t21)
  store i1 %t22, ptr %l14
  br label %bb7
bb6:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb8
bb7:
  %t23 = load i1, ptr %l14, !tbaa !21
  %t24 = xor i1 %t23, true
  store i1 %t24, ptr %l15, !tbaa !21
  %t25 = load i1, ptr %l15, !tbaa !21
  store i1 %t25, ptr %l10, !tbaa !21
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t26 = load i1, ptr %l10, !tbaa !21
  store i1 %t26, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eFits(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca %"compiler/cond:Value"
  %l5 = alloca i1
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca %"compiler/cond:Value"
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca i1
  %l20 = alloca i1
  %l21 = alloca { i64, ptr }
  %l22 = alloca i1
  %l23 = alloca i32
  %l24 = alloca ptr
  %l25 = alloca i32
  %l26 = alloca ptr
  %l27 = alloca i1
  %l28 = alloca { i64, ptr }
  %l29 = alloca i1
  %l30 = alloca i32
  %l31 = alloca ptr
  %l32 = alloca i32
  %l33 = alloca ptr
  %l34 = alloca i1
  %l35 = alloca { i64, ptr }
  %l36 = alloca i1
  %l37 = alloca i32
  %l38 = alloca ptr
  %l39 = alloca i32
  %l40 = alloca ptr
  %l41 = alloca i1
  %l42 = alloca i1
  %l43 = alloca i1
  %l44 = alloca i1
  %l45 = alloca i1
  %l46 = alloca i64
  %l47 = alloca i1
  %l48 = alloca { i64, ptr }
  %l49 = alloca i1
  %l50 = alloca i32
  %l51 = alloca ptr
  %l52 = alloca i32
  %l53 = alloca ptr
  %l54 = alloca i1
  %l55 = alloca i1
  %l56 = alloca i1
  %l57 = alloca i1
  %l58 = alloca { i64, ptr }
  %l59 = alloca i1
  %l60 = alloca i32
  %l61 = alloca ptr
  %l62 = alloca i32
  %l63 = alloca ptr
  %l64 = alloca i1
  %l65 = alloca i1
  %l66 = alloca i1
  %l67 = alloca i1
  %l68 = alloca i64
  %l69 = alloca i1
  %l70 = alloca { i64, ptr }
  %l71 = alloca i1
  %l72 = alloca i32
  %l73 = alloca ptr
  %l74 = alloca i32
  %l75 = alloca ptr
  %l76 = alloca i1
  %l77 = alloca i1
  %l78 = alloca i32
  %l79 = alloca ptr
  %l80 = alloca i32
  %l81 = alloca ptr
  %l82 = alloca i1
  %l83 = alloca i1
  %l84 = alloca i1
  %l85 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t2, ptr %l8, !tbaa !27
  %t3 = load ptr, ptr %l7, !tbaa !29
  %t4 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t5 = call { i32, i64 } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2efind(ptr %v0, ptr %v1, ptr %t3, { i64, ptr } %t4)
  %t6 = extractvalue { i32, i64 } %t5, 1
  %t7 = extractvalue { i32, i64 } %t5, 0
  store i32 %t7, ptr %l10
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9
ok.9:
  store i64 %t6, ptr %l9
  br label %bb1
bb1:
  %t10 = load i64, ptr %l9, !tbaa !24
  store i64 %t10, ptr %l6, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  store i1 false, ptr %l11, !tbaa !21
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t11 = load i1, ptr %l11, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
bb4:
  %t12 = load i64, ptr %l6, !tbaa !24
  store i64 %t12, ptr %l3, !tbaa !24
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l12, !tbaa !29
  %t14 = load ptr, ptr %l12, !tbaa !29
  %t15 = getelementptr %"compiler/cond:Consts", ptr %t14, i32 0, i32 1
  store ptr %t15, ptr %l13, !tbaa !29
  %t16 = load i64, ptr %l3, !tbaa !24
  store i64 %t16, ptr %l14, !tbaa !24
  %t17 = load ptr, ptr %l13, !tbaa !29
  %t18 = load i64, ptr %l14, !tbaa !24
  %t19 = call %"compiler/cond:Value" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcond_3aValue_3e_2eAt_3ccompiler_2fcond_3aValue_3e(ptr %v0, ptr %t17, i64 %t18)
  store %"compiler/cond:Value" %t19, ptr %l15
  br label %bb5
bb5:
  %t20 = load %"compiler/cond:Value", ptr %l15
  store %"compiler/cond:Value" %t20, ptr %l4
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l16, !tbaa !29
  %t22 = load ptr, ptr %l16, !tbaa !29
  %t23 = getelementptr %"compiler/cond:Consts", ptr %t22, i32 0, i32 3
  store ptr %t23, ptr %l17, !tbaa !29
  %t24 = load i64, ptr %l3, !tbaa !24
  store i64 %t24, ptr %l18, !tbaa !24
  %t25 = load ptr, ptr %l17, !tbaa !29
  %t26 = load i64, ptr %l18, !tbaa !24
  %t27 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t25, i64 %t26)
  store i1 %t27, ptr %l19
  br label %bb6
bb6:
  %t28 = load i1, ptr %l19, !tbaa !21
  store i1 %t28, ptr %l5, !tbaa !21
  %t29 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t29, ptr %l21, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t31 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t30, { i64, ptr } { i64 4, ptr @.d14 })
  store i1 %t31, ptr %l22
  br label %bb7
bb7:
  %t32 = load i1, ptr %l22, !tbaa !21
  br i1 %t32, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb12
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t33 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 0
  %t34 = load i32, ptr %t33
  store i32 %t34, ptr %l23
  store ptr %l23, ptr %l24, !tbaa !29
  store i32 1, ptr %l25
  store ptr %l25, ptr %l26, !tbaa !29
  %t35 = load ptr, ptr %l24, !tbaa !29
  %t36 = load ptr, ptr %l26, !tbaa !29
  %t37 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %t35, ptr %t36)
  store i1 %t37, ptr %l27
  br label %bb11
bb11:
  %t38 = load i1, ptr %l27, !tbaa !21
  store i1 %t38, ptr %l20, !tbaa !21
  call void @__olang_scope_close(ptr %s2)
  br label %bb70
bb12:
  %t39 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t39, ptr %l28, !tbaa !27
  %t40 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t41 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t40, { i64, ptr } { i64 6, ptr @.d15 })
  store i1 %t41, ptr %l29
  br label %bb13
bb13:
  %t42 = load i1, ptr %l29, !tbaa !21
  br i1 %t42, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb18
bb16:
  store %olang.scope zeroinitializer, ptr %s3
  %t43 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 0
  %t44 = load i32, ptr %t43
  store i32 %t44, ptr %l30
  store ptr %l30, ptr %l31, !tbaa !29
  store i32 4, ptr %l32
  store ptr %l32, ptr %l33, !tbaa !29
  %t45 = load ptr, ptr %l31, !tbaa !29
  %t46 = load ptr, ptr %l33, !tbaa !29
  %t47 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %t45, ptr %t46)
  store i1 %t47, ptr %l34
  br label %bb17
bb17:
  %t48 = load i1, ptr %l34, !tbaa !21
  store i1 %t48, ptr %l20, !tbaa !21
  call void @__olang_scope_close(ptr %s3)
  br label %bb70
bb18:
  %t49 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t49, ptr %l35, !tbaa !27
  %t50 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t51 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t50, { i64, ptr } { i64 3, ptr @.d16 })
  store i1 %t51, ptr %l36
  br label %bb19
bb19:
  %t52 = load i1, ptr %l36, !tbaa !21
  br i1 %t52, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb31
bb22:
  store %olang.scope zeroinitializer, ptr %s4
  %t53 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 0
  %t54 = load i32, ptr %t53
  store i32 %t54, ptr %l37
  store ptr %l37, ptr %l38, !tbaa !29
  store i32 2, ptr %l39
  store ptr %l39, ptr %l40, !tbaa !29
  %t55 = load ptr, ptr %l38, !tbaa !29
  %t56 = load ptr, ptr %l40, !tbaa !29
  %t57 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %t55, ptr %t56)
  store i1 %t57, ptr %l41
  br label %bb23
bb23:
  %t58 = load i1, ptr %l41, !tbaa !21
  br i1 %t58, label %bb24, label %bb25
bb24:
  %t59 = load i1, ptr %l5, !tbaa !21
  store i1 %t59, ptr %l43, !tbaa !21
  %t60 = load i1, ptr %l43, !tbaa !21
  %t61 = xor i1 %t60, true
  store i1 %t61, ptr %l44, !tbaa !21
  %t62 = load i1, ptr %l44, !tbaa !21
  store i1 %t62, ptr %l42, !tbaa !21
  br label %bb26
bb25:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb26
bb26:
  %t63 = load i1, ptr %l42, !tbaa !21
  br i1 %t63, label %bb27, label %bb28
bb27:
  %t64 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 1
  %t65 = load i64, ptr %t64, !tbaa !24
  store i64 %t65, ptr %l46, !tbaa !24
  %t66 = load i64, ptr %l46, !tbaa !24
  %t67 = call i1 @compiler_2fcond_2efits(i64 %t66, i64 32, i1 false)
  store i1 %t67, ptr %l47
  br label %bb29
bb28:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb30
bb29:
  %t68 = load i1, ptr %l47, !tbaa !21
  store i1 %t68, ptr %l45, !tbaa !21
  br label %bb30
bb30:
  %t69 = load i1, ptr %l45, !tbaa !21
  store i1 %t69, ptr %l20, !tbaa !21
  call void @__olang_scope_close(ptr %s4)
  br label %bb70
bb31:
  %t70 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t70, ptr %l48, !tbaa !27
  %t71 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t72 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t71, { i64, ptr } { i64 3, ptr @.d17 })
  store i1 %t72, ptr %l49
  br label %bb32
bb32:
  %t73 = load i1, ptr %l49, !tbaa !21
  br i1 %t73, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb40
bb35:
  store %olang.scope zeroinitializer, ptr %s5
  %t74 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 0
  %t75 = load i32, ptr %t74
  store i32 %t75, ptr %l50
  store ptr %l50, ptr %l51, !tbaa !29
  store i32 2, ptr %l52
  store ptr %l52, ptr %l53, !tbaa !29
  %t76 = load ptr, ptr %l51, !tbaa !29
  %t77 = load ptr, ptr %l53, !tbaa !29
  %t78 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %t76, ptr %t77)
  store i1 %t78, ptr %l54
  br label %bb36
bb36:
  %t79 = load i1, ptr %l54, !tbaa !21
  br i1 %t79, label %bb37, label %bb38
bb37:
  %t80 = load i1, ptr %l5, !tbaa !21
  store i1 %t80, ptr %l56, !tbaa !21
  %t81 = load i1, ptr %l56, !tbaa !21
  %t82 = xor i1 %t81, true
  store i1 %t82, ptr %l57, !tbaa !21
  %t83 = load i1, ptr %l57, !tbaa !21
  store i1 %t83, ptr %l55, !tbaa !21
  br label %bb39
bb38:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb39
bb39:
  %t84 = load i1, ptr %l55, !tbaa !21
  store i1 %t84, ptr %l20, !tbaa !21
  call void @__olang_scope_close(ptr %s5)
  br label %bb70
bb40:
  %t85 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t85, ptr %l58, !tbaa !27
  %t86 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t87 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t86, { i64, ptr } { i64 3, ptr @.d18 })
  store i1 %t87, ptr %l59
  br label %bb41
bb41:
  %t88 = load i1, ptr %l59, !tbaa !21
  br i1 %t88, label %bb42, label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb52
bb44:
  store %olang.scope zeroinitializer, ptr %s6
  %t89 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 0
  %t90 = load i32, ptr %t89
  store i32 %t90, ptr %l60
  store ptr %l60, ptr %l61, !tbaa !29
  store i32 2, ptr %l62
  store ptr %l62, ptr %l63, !tbaa !29
  %t91 = load ptr, ptr %l61, !tbaa !29
  %t92 = load ptr, ptr %l63, !tbaa !29
  %t93 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %t91, ptr %t92)
  store i1 %t93, ptr %l64
  br label %bb45
bb45:
  %t94 = load i1, ptr %l64, !tbaa !21
  br i1 %t94, label %bb46, label %bb47
bb46:
  %t95 = load i1, ptr %l5, !tbaa !21
  store i1 %t95, ptr %l66, !tbaa !21
  %t96 = load i1, ptr %l66, !tbaa !21
  br i1 %t96, label %bb48, label %bb49
bb47:
  store i1 false, ptr %l65, !tbaa !21
  br label %bb51
bb48:
  store i1 true, ptr %l67, !tbaa !21
  br label %bb50
bb49:
  %t97 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 1
  %t98 = load i64, ptr %t97, !tbaa !24
  store i64 %t98, ptr %l68, !tbaa !24
  %t99 = load i64, ptr %l68, !tbaa !24
  %t100 = icmp sge i64 %t99, 0
  store i1 %t100, ptr %l69, !tbaa !21
  %t101 = load i1, ptr %l69, !tbaa !21
  store i1 %t101, ptr %l67, !tbaa !21
  br label %bb50
bb50:
  %t102 = load i1, ptr %l67, !tbaa !21
  store i1 %t102, ptr %l65, !tbaa !21
  br label %bb51
bb51:
  %t103 = load i1, ptr %l65, !tbaa !21
  store i1 %t103, ptr %l20, !tbaa !21
  call void @__olang_scope_close(ptr %s6)
  br label %bb70
bb52:
  %t104 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t104, ptr %l70, !tbaa !27
  %t105 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t106 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t105, { i64, ptr } { i64 3, ptr @.d19 })
  store i1 %t106, ptr %l71
  br label %bb53
bb53:
  %t107 = load i1, ptr %l71, !tbaa !21
  br i1 %t107, label %bb54, label %bb55
bb54:
  br label %bb56
bb55:
  br label %bb65
bb56:
  store %olang.scope zeroinitializer, ptr %s7
  %t108 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 0
  %t109 = load i32, ptr %t108
  store i32 %t109, ptr %l72
  store ptr %l72, ptr %l73, !tbaa !29
  store i32 3, ptr %l74
  store ptr %l74, ptr %l75, !tbaa !29
  %t110 = load ptr, ptr %l73, !tbaa !29
  %t111 = load ptr, ptr %l75, !tbaa !29
  %t112 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %t110, ptr %t111)
  store i1 %t112, ptr %l76
  br label %bb57
bb57:
  %t113 = load i1, ptr %l76, !tbaa !21
  br i1 %t113, label %bb58, label %bb59
bb58:
  store i1 true, ptr %l77, !tbaa !21
  br label %bb64
bb59:
  %t114 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 0
  %t115 = load i32, ptr %t114
  store i32 %t115, ptr %l78
  store ptr %l78, ptr %l79, !tbaa !29
  store i32 2, ptr %l80
  store ptr %l80, ptr %l81, !tbaa !29
  %t116 = load ptr, ptr %l79, !tbaa !29
  %t117 = load ptr, ptr %l81, !tbaa !29
  %t118 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %t116, ptr %t117)
  store i1 %t118, ptr %l82
  br label %bb60
bb60:
  %t119 = load i1, ptr %l82, !tbaa !21
  br i1 %t119, label %bb61, label %bb62
bb61:
  %t120 = load i1, ptr %l5, !tbaa !21
  store i1 %t120, ptr %l84, !tbaa !21
  %t121 = load i1, ptr %l84, !tbaa !21
  %t122 = xor i1 %t121, true
  store i1 %t122, ptr %l85, !tbaa !21
  %t123 = load i1, ptr %l85, !tbaa !21
  store i1 %t123, ptr %l83, !tbaa !21
  br label %bb63
bb62:
  store i1 false, ptr %l83, !tbaa !21
  br label %bb63
bb63:
  %t124 = load i1, ptr %l83, !tbaa !21
  store i1 %t124, ptr %l77, !tbaa !21
  br label %bb64
bb64:
  %t125 = load i1, ptr %l77, !tbaa !21
  store i1 %t125, ptr %l20, !tbaa !21
  call void @__olang_scope_close(ptr %s7)
  br label %bb70
bb65:
  br i1 true, label %bb66, label %bb67
bb66:
  br label %bb68
bb67:
  br label %bb69
bb68:
  store %olang.scope zeroinitializer, ptr %s8
  store i1 false, ptr %l20, !tbaa !21
  call void @__olang_scope_close(ptr %s8)
  br label %bb70
bb69:
  call void @__olang_check_failed(ptr @.c20)
  unreachable
bb70:
  call void @__olang_scope_close(ptr %s0)
  %t126 = load i1, ptr %l20, !tbaa !21
  store i1 %t126, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eHas(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t2, ptr %l4, !tbaa !27
  %t3 = load ptr, ptr %l3, !tbaa !29
  %t4 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t5 = call { i32, i64 } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2efind(ptr %v0, ptr %v1, ptr %t3, { i64, ptr } %t4)
  %t6 = extractvalue { i32, i64 } %t5, 1
  %t7 = extractvalue { i32, i64 } %t5, 0
  store i32 %t7, ptr %l6
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9
ok.9:
  store i64 %t6, ptr %l5
  br label %bb1
bb1:
  %t10 = load i64, ptr %l5, !tbaa !24
  store i64 %t10, ptr %l2, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 -1, ptr %l2, !tbaa !24
  br label %bb4
bb4:
  %t11 = load i64, ptr %l2, !tbaa !24
  %t12 = icmp sge i64 %t11, 0
  store i1 %t12, ptr %l7, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  %t13 = load i1, ptr %l7, !tbaa !21
  store i1 %t13, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eRaw(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.builder
  %s2room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t2, ptr %l5, !tbaa !27
  %t3 = load ptr, ptr %l4, !tbaa !29
  %t4 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t5 = call { i32, i64 } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2efind(ptr %v0, ptr %v1, ptr %t3, { i64, ptr } %t4)
  %t6 = extractvalue { i32, i64 } %t5, 1
  %t7 = extractvalue { i32, i64 } %t5, 0
  store i32 %t7, ptr %l7
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9
ok.9:
  store i64 %t6, ptr %l6
  br label %bb1
bb1:
  %t10 = load i64, ptr %l6, !tbaa !24
  store i64 %t10, ptr %l3, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  store { i64, ptr } { i64 0, ptr @.d21 }, ptr %l8, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t11, ptr %l9, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 0
  store i64 %t13, ptr %l10, !tbaa !24
  %t14 = load i64, ptr %l10, !tbaa !24
  %t15 = mul i64 %t14, 1
  %t16 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t15)
  %t17 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l11, !tbaa !27
  %t19 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = load i64, ptr %l10, !tbaa !24
  %t24 = mul i64 %t23, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t20, ptr %t22, i64 %t24, i1 false)
  %t25 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t25, ptr %l9, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t26 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t26, ptr %rv
  br label %ret
bb4:
  %t27 = load i64, ptr %l3, !tbaa !24
  store i64 %t27, ptr %l2, !tbaa !24
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l12, !tbaa !29
  %t29 = load ptr, ptr %l12, !tbaa !29
  %t30 = getelementptr %"compiler/cond:Consts", ptr %t29, i32 0, i32 5
  store ptr %t30, ptr %l13, !tbaa !29
  %t31 = load i64, ptr %l2, !tbaa !24
  store i64 %t31, ptr %l14, !tbaa !24
  %t32 = load ptr, ptr %l13, !tbaa !29
  %t33 = load i64, ptr %l14, !tbaa !24
  %t34 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %s0, ptr %t32, i64 %t33)
  store { i64, ptr } %t34, ptr %l15
  br label %bb5
bb5:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s2
  store ptr %s2room, ptr %s2
  %t35 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t35, 1
  %t37 = extractvalue { i64, ptr } %t35, 0
  call void @__olang_sb_put(ptr %s2, ptr %t36, i64 %t37)
  %t38 = load ptr, ptr %s2
  %t39 = getelementptr %olang.builder, ptr %s2, i32 0, i32 1
  %t40 = load i64, ptr %t39
  %t41 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t40)
  call void @llvm.memcpy.p0.p0.i64(ptr %t41, ptr %t38, i64 %t40, i1 false)
  %t42 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t41, 1
  store { i64, ptr } %t43, ptr %l16, !tbaa !27
  call void @__olang_sb_done(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t44 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t44, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, { %"compiler/cond:Value", i1 } } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eValueOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca %"compiler/cond:Value"
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca i1
  %l17 = alloca { %"compiler/cond:Value", i1 }
  %s0 = alloca %olang.scope
  %rv = alloca { i32, { %"compiler/cond:Value", i1 } }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t2, ptr %l5, !tbaa !27
  %t3 = load ptr, ptr %l4, !tbaa !29
  %t4 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t5 = call { i32, i64 } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2efind(ptr %v0, ptr %v1, ptr %t3, { i64, ptr } %t4)
  %t6 = extractvalue { i32, i64 } %t5, 1
  %t7 = extractvalue { i32, i64 } %t5, 0
  store i32 %t7, ptr %l7
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9
ok.9:
  store i64 %t6, ptr %l6
  br label %bb1
bb1:
  %t10 = load i64, ptr %l6, !tbaa !24
  store i64 %t10, ptr %l3, !tbaa !24
  br label %bb3
bb2:
  %t11 = load i32, ptr %l7, !tbaa !23
  %t12 = lshr i32 %t11, 16
  %t13 = and i32 %t11, 65535
  %t14 = icmp eq i32 %t12, 1
  %t15 = select i1 %t14, i32 1, i32 0
  %t16 = icmp eq i32 %t11, 0
  %t17 = shl i32 %t15, 16
  %t18 = or i32 %t17, %t13
  %t19 = select i1 %t16, i32 0, i32 %t18
  store i32 %t19, ptr %l8, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t20 = load i32, ptr %l8, !tbaa !23
  %t21 = insertvalue { i32, { %"compiler/cond:Value", i1 } } zeroinitializer, i32 %t20, 0
  store { i32, { %"compiler/cond:Value", i1 } } %t21, ptr %rv
  br label %ret
bb3:
  %t22 = load i64, ptr %l3, !tbaa !24
  store i64 %t22, ptr %l2, !tbaa !24
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l9, !tbaa !29
  %t24 = load ptr, ptr %l9, !tbaa !29
  %t25 = getelementptr %"compiler/cond:Consts", ptr %t24, i32 0, i32 1
  store ptr %t25, ptr %l10, !tbaa !29
  %t26 = load i64, ptr %l2, !tbaa !24
  store i64 %t26, ptr %l11, !tbaa !24
  %t27 = load ptr, ptr %l10, !tbaa !29
  %t28 = load i64, ptr %l11, !tbaa !24
  %t29 = call %"compiler/cond:Value" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcond_3aValue_3e_2eAt_3ccompiler_2fcond_3aValue_3e(ptr %v0, ptr %t27, i64 %t28)
  store %"compiler/cond:Value" %t29, ptr %l12
  br label %bb4
bb4:
  %t30 = load ptr, ptr %l0, !tbaa !29
  store ptr %t30, ptr %l13, !tbaa !29
  %t31 = load ptr, ptr %l13, !tbaa !29
  %t32 = getelementptr %"compiler/cond:Consts", ptr %t31, i32 0, i32 3
  store ptr %t32, ptr %l14, !tbaa !29
  %t33 = load i64, ptr %l2, !tbaa !24
  store i64 %t33, ptr %l15, !tbaa !24
  %t34 = load ptr, ptr %l14, !tbaa !29
  %t35 = load i64, ptr %l15, !tbaa !24
  %t36 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t34, i64 %t35)
  store i1 %t36, ptr %l16
  br label %bb5
bb5:
  %t37 = load %"compiler/cond:Value", ptr %l12
  %t38 = insertvalue { %"compiler/cond:Value", i1 } undef, %"compiler/cond:Value" %t37, 0
  %t39 = load i1, ptr %l16, !tbaa !21
  %t40 = insertvalue { %"compiler/cond:Value", i1 } %t38, i1 %t39, 1
  store { %"compiler/cond:Value", i1 } %t40, ptr %l17
  call void @__olang_scope_close(ptr %s0)
  %t41 = load { %"compiler/cond:Value", i1 }, ptr %l17
  %t42 = insertvalue { i32, { %"compiler/cond:Value", i1 } } zeroinitializer, { %"compiler/cond:Value", i1 } %t41, 1
  store { i32, { %"compiler/cond:Value", i1 } } %t42, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { %"compiler/cond:Value", i1 } }, ptr %rv
  ret { i32, { %"compiler/cond:Value", i1 } } %rr
}

define dso_local void @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eadd(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, %"compiler/cond:Value" %a2, i1 %a3, i1 %a4, i1 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"compiler/cond:Value"
  %l3 = alloca i1
  %l4 = alloca i1
  %l5 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca %"compiler/cond:Value"
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store %"compiler/cond:Value" %a2, ptr %l2
  store i1 %a3, ptr %l3
  store i1 %a4, ptr %l4
  store i1 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = getelementptr %"compiler/cond:Consts", ptr %t2, i32 0, i32 0
  store ptr %t3, ptr %l7, !tbaa !29
  %t4 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t4, ptr %l8, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t5 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 1
  %t7 = extractvalue { i64, ptr } %t5, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = load ptr, ptr %s1
  %t9 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t10 = load i64, ptr %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t10)
  call void @llvm.memcpy.p0.p0.i64(ptr %t11, ptr %t8, i64 %t10, i1 false)
  %t12 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  store { i64, ptr } %t13, ptr %l9, !tbaa !27
  call void @__olang_sb_done(ptr %s1)
  %t14 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t14, 0
  %t16 = extractvalue { i64, ptr } %t14, 1
  %t17 = mul i64 %t15, 1
  %t18 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t16, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l10, !tbaa !27
  %t21 = load ptr, ptr %l7, !tbaa !29
  %t22 = load { i64, ptr }, ptr %l10, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v0, ptr %t21, { i64, ptr } %t22)
  br label %bb1
bb1:
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l11, !tbaa !29
  %t24 = load ptr, ptr %l11, !tbaa !29
  %t25 = getelementptr %"compiler/cond:Consts", ptr %t24, i32 0, i32 1
  store ptr %t25, ptr %l12, !tbaa !29
  %t26 = load %"compiler/cond:Value", ptr %l2
  store %"compiler/cond:Value" %t26, ptr %l13
  %t27 = load ptr, ptr %l12, !tbaa !29
  %t28 = load %"compiler/cond:Value", ptr %l13
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcond_3aValue_3e_2ePush_3ccompiler_2fcond_3aValue_3e(ptr %v0, ptr %t27, %"compiler/cond:Value" %t28)
  br label %bb2
bb2:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l14, !tbaa !29
  %t30 = load ptr, ptr %l14, !tbaa !29
  %t31 = getelementptr %"compiler/cond:Consts", ptr %t30, i32 0, i32 2
  store ptr %t31, ptr %l15, !tbaa !29
  %t32 = load i1, ptr %l3, !tbaa !21
  store i1 %t32, ptr %l16, !tbaa !21
  %t33 = load ptr, ptr %l15, !tbaa !29
  %t34 = load i1, ptr %l16, !tbaa !21
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t33, i1 %t34)
  br label %bb3
bb3:
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l17, !tbaa !29
  %t36 = load ptr, ptr %l17, !tbaa !29
  %t37 = getelementptr %"compiler/cond:Consts", ptr %t36, i32 0, i32 3
  store ptr %t37, ptr %l18, !tbaa !29
  %t38 = load i1, ptr %l4, !tbaa !21
  store i1 %t38, ptr %l19, !tbaa !21
  %t39 = load ptr, ptr %l18, !tbaa !29
  %t40 = load i1, ptr %l19, !tbaa !21
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t39, i1 %t40)
  br label %bb4
bb4:
  %t41 = load ptr, ptr %l0, !tbaa !29
  store ptr %t41, ptr %l20, !tbaa !29
  %t42 = load ptr, ptr %l20, !tbaa !29
  %t43 = getelementptr %"compiler/cond:Consts", ptr %t42, i32 0, i32 4
  store ptr %t43, ptr %l21, !tbaa !29
  %t44 = load i1, ptr %l5, !tbaa !21
  store i1 %t44, ptr %l22, !tbaa !21
  %t45 = load ptr, ptr %l21, !tbaa !29
  %t46 = load i1, ptr %l22, !tbaa !21
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t45, i1 %t46)
  br label %bb5
bb5:
  %t47 = load ptr, ptr %l0, !tbaa !29
  store ptr %t47, ptr %l23, !tbaa !29
  %t48 = load ptr, ptr %l23, !tbaa !29
  %t49 = getelementptr %"compiler/cond:Consts", ptr %t48, i32 0, i32 5
  store ptr %t49, ptr %l24, !tbaa !29
  %t50 = load ptr, ptr %l24, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v0, ptr %t50, { i64, ptr } { i64 0, ptr @.d22 })
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2edefine(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca { %"compiler/cond:Value", i1 }
  %l7 = alloca %"compiler/cond:Value"
  %l8 = alloca i1
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i8
  %l12 = alloca i64
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i1
  %l19 = alloca i1
  %l20 = alloca i1
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i1
  %l30 = alloca i1
  %l31 = alloca i1
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca i1
  %l35 = alloca i1
  %l36 = alloca i32
  %l37 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca i32
  %l42 = alloca i64
  %l43 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca ptr
  %l46 = alloca i64
  %l47 = alloca i1
  %l48 = alloca i32
  %l49 = alloca i32
  %l50 = alloca { %"compiler/cond:Value", i1 }
  %l51 = alloca ptr
  %l52 = alloca { i64, ptr }
  %l53 = alloca { %"compiler/cond:Value", i1 }
  %l54 = alloca i32
  %l55 = alloca i32
  %l56 = alloca %"compiler/cond:Value"
  %l57 = alloca i1
  %l58 = alloca ptr
  %l59 = alloca { i64, ptr }
  %l60 = alloca %"compiler/cond:Value"
  %l61 = alloca i1
  %l62 = alloca ptr
  %l63 = alloca ptr
  %l64 = alloca ptr
  %l65 = alloca ptr
  %l66 = alloca i64
  %l67 = alloca i64
  %l68 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.builder
  %s5room = alloca [64 x i8], align 8
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t1, ptr %l10, !tbaa !27
  store i8 61, ptr %l11, !tbaa !22
  %t2 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t3 = load i8, ptr %l11, !tbaa !22
  %t4 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v1, { i64, ptr } %t2, i8 %t3)
  %t5 = extractvalue { i32, i64 } %t4, 1
  %t6 = extractvalue { i32, i64 } %t4, 0
  store i32 %t6, ptr %l13
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8
ok.8:
  store i64 %t5, ptr %l12
  br label %bb1
bb1:
  %t9 = load i64, ptr %l12, !tbaa !24
  store i64 %t9, ptr %l9, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  store i32 65536, ptr %l14, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t10 = load i32, ptr %l14, !tbaa !23
  store i32 %t10, ptr %rv
  br label %ret
bb4:
  %t11 = load i64, ptr %l9, !tbaa !24
  store i64 %t11, ptr %l2, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t12, ptr %l15, !tbaa !27
  %t13 = load i64, ptr %l2, !tbaa !24
  store i64 %t13, ptr %l16, !tbaa !24
  %t14 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t14, 0
  store i64 %t15, ptr %l17, !tbaa !24
  %t16 = icmp sge i64 0, 0
  store i1 %t16, ptr %l18, !tbaa !21
  %t17 = load i1, ptr %l18, !tbaa !21
  br i1 %t17, label %bb5, label %bb6
bb5:
  %t18 = load i64, ptr %l16, !tbaa !24
  %t19 = icmp sle i64 0, %t18
  store i1 %t19, ptr %l19, !tbaa !21
  %t20 = load i1, ptr %l19, !tbaa !21
  br i1 %t20, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @.c23)
  unreachable
bb7:
  %t21 = load i64, ptr %l16, !tbaa !24
  %t22 = load i64, ptr %l17, !tbaa !24
  %t23 = icmp sle i64 %t21, %t22
  store i1 %t23, ptr %l20, !tbaa !21
  %t24 = load i1, ptr %l20, !tbaa !21
  br i1 %t24, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @.c23)
  unreachable
bb9:
  %t25 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = load i64, ptr %l16, !tbaa !24
  %t28 = getelementptr i8, ptr %t26, i64 0
  %t29 = sub i64 %t27, 0
  %t30 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t28, 1
  store { i64, ptr } %t31, ptr %l21, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t32, ptr %l3, !tbaa !27
  %t33 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t33, ptr %l22, !tbaa !27
  %t34 = load i64, ptr %l2, !tbaa !24
  store i64 %t34, ptr %l23, !tbaa !24
  %t35 = load i64, ptr %l23, !tbaa !24
  %t36 = add i64 %t35, 1
  store i64 %t36, ptr %l24, !tbaa !24
  %t37 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t37, ptr %l25, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t38, ptr %l26, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  store i64 %t40, ptr %l27, !tbaa !24
  %t41 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t41, 0
  store i64 %t42, ptr %l28, !tbaa !24
  %t43 = load i64, ptr %l24, !tbaa !24
  %t44 = icmp sge i64 %t43, 0
  store i1 %t44, ptr %l29, !tbaa !21
  %t45 = load i1, ptr %l29, !tbaa !21
  br i1 %t45, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @.c23)
  unreachable
bb11:
  %t46 = load i64, ptr %l24, !tbaa !24
  %t47 = load i64, ptr %l27, !tbaa !24
  %t48 = icmp sle i64 %t46, %t47
  store i1 %t48, ptr %l30, !tbaa !21
  %t49 = load i1, ptr %l30, !tbaa !21
  br i1 %t49, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @.c24)
  unreachable
bb13:
  %t50 = load i64, ptr %l27, !tbaa !24
  %t51 = load i64, ptr %l28, !tbaa !24
  %t52 = icmp sle i64 %t50, %t51
  store i1 %t52, ptr %l31, !tbaa !21
  %t53 = load i1, ptr %l31, !tbaa !21
  br i1 %t53, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @.c24)
  unreachable
bb15:
  %t54 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = load i64, ptr %l24, !tbaa !24
  %t57 = load i64, ptr %l27, !tbaa !24
  %t58 = getelementptr i8, ptr %t55, i64 %t56
  %t59 = sub i64 %t57, %t56
  %t60 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t58, 1
  store { i64, ptr } %t61, ptr %l32, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t62, ptr %l4, !tbaa !27
  %t63 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t63, ptr %l33, !tbaa !27
  %t64 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t65 = call i1 @compiler_2fcond_2eisName(ptr %v1, { i64, ptr } %t64)
  store i1 %t65, ptr %l34
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @.c24)
  unreachable
bb17:
  %t66 = load i1, ptr %l34, !tbaa !21
  %t67 = xor i1 %t66, true
  store i1 %t67, ptr %l35, !tbaa !21
  %t68 = load i1, ptr %l35, !tbaa !21
  br i1 %t68, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s2
  store i32 65537, ptr %l36, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t69 = load i32, ptr %l36, !tbaa !23
  store i32 %t69, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t70 = load ptr, ptr %l0, !tbaa !29
  store ptr %t70, ptr %l38, !tbaa !29
  %t71 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t71, ptr %l39, !tbaa !27
  %t72 = load ptr, ptr %l38, !tbaa !29
  %t73 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t74 = call { i32, i64 } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2efind(ptr %v0, ptr %v1, ptr %t72, { i64, ptr } %t73)
  %t75 = extractvalue { i32, i64 } %t74, 1
  %t76 = extractvalue { i32, i64 } %t74, 0
  store i32 %t76, ptr %l41
  %t77 = icmp ne i32 %t76, 0
  br i1 %t77, label %bb22, label %ok.78
ok.78:
  store i64 %t75, ptr %l40
  br label %bb21
bb21:
  %t79 = load i64, ptr %l40, !tbaa !24
  store i64 %t79, ptr %l37, !tbaa !24
  br label %bb24
bb22:
  br label %bb23
bb23:
  store i64 -1, ptr %l37, !tbaa !24
  br label %bb24
bb24:
  %t80 = load i64, ptr %l37, !tbaa !24
  store i64 %t80, ptr %l5, !tbaa !24
  %t81 = load i64, ptr %l5, !tbaa !24
  store i64 %t81, ptr %l42, !tbaa !24
  %t82 = load i64, ptr %l42, !tbaa !24
  %t83 = icmp sge i64 %t82, 0
  store i1 %t83, ptr %l43, !tbaa !21
  %t84 = load i1, ptr %l43, !tbaa !21
  br i1 %t84, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s3
  %t85 = load ptr, ptr %l0, !tbaa !29
  store ptr %t85, ptr %l44, !tbaa !29
  %t86 = load ptr, ptr %l44, !tbaa !29
  %t87 = getelementptr %"compiler/cond:Consts", ptr %t86, i32 0, i32 2
  store ptr %t87, ptr %l45, !tbaa !29
  %t88 = load i64, ptr %l5, !tbaa !24
  store i64 %t88, ptr %l46, !tbaa !24
  %t89 = load ptr, ptr %l45, !tbaa !29
  %t90 = load i64, ptr %l46, !tbaa !24
  %t91 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t89, i64 %t90)
  store i1 %t91, ptr %l47
  br label %bb27
bb26:
  br label %bb31
bb27:
  %t92 = load i1, ptr %l47, !tbaa !21
  br i1 %t92, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s4
  store i32 65539, ptr %l48, !tbaa !23
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t93 = load i32, ptr %l48, !tbaa !23
  store i32 %t93, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  store i32 65538, ptr %l49, !tbaa !23
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t94 = load i32, ptr %l49, !tbaa !23
  store i32 %t94, ptr %rv
  br label %ret
bb31:
  %t95 = load ptr, ptr %l0, !tbaa !29
  store ptr %t95, ptr %l51, !tbaa !29
  %t96 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t96, ptr %l52, !tbaa !27
  %t97 = load ptr, ptr %l51, !tbaa !29
  %t98 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t99 = call { i32, { %"compiler/cond:Value", i1 } } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eliteral(ptr %v0, ptr %v1, ptr %t97, { i64, ptr } %t98)
  %t100 = extractvalue { i32, { %"compiler/cond:Value", i1 } } %t99, 1
  %t101 = extractvalue { i32, { %"compiler/cond:Value", i1 } } %t99, 0
  store i32 %t101, ptr %l54
  %t102 = icmp ne i32 %t101, 0
  br i1 %t102, label %bb33, label %ok.103
ok.103:
  store { %"compiler/cond:Value", i1 } %t100, ptr %l53
  br label %bb32
bb32:
  %t104 = load { %"compiler/cond:Value", i1 }, ptr %l53
  store { %"compiler/cond:Value", i1 } %t104, ptr %l50
  br label %bb34
bb33:
  %t105 = load i32, ptr %l54, !tbaa !23
  %t106 = lshr i32 %t105, 16
  %t107 = and i32 %t105, 65535
  %t108 = icmp eq i32 %t106, 1
  %t109 = select i1 %t108, i32 1, i32 0
  %t110 = icmp eq i32 %t105, 0
  %t111 = shl i32 %t109, 16
  %t112 = or i32 %t111, %t107
  %t113 = select i1 %t110, i32 0, i32 %t112
  store i32 %t113, ptr %l55, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t114 = load i32, ptr %l55, !tbaa !23
  store i32 %t114, ptr %rv
  br label %ret
bb34:
  %t115 = load { %"compiler/cond:Value", i1 }, ptr %l50
  store { %"compiler/cond:Value", i1 } %t115, ptr %l6
  %t116 = getelementptr { %"compiler/cond:Value", i1 }, ptr %l6, i32 0, i32 0
  %t117 = load %"compiler/cond:Value", ptr %t116
  store %"compiler/cond:Value" %t117, ptr %l56
  %t118 = load %"compiler/cond:Value", ptr %l56
  store %"compiler/cond:Value" %t118, ptr %l7
  %t119 = getelementptr { %"compiler/cond:Value", i1 }, ptr %l6, i32 0, i32 1
  %t120 = load i1, ptr %t119, !tbaa !21
  store i1 %t120, ptr %l57, !tbaa !21
  %t121 = load i1, ptr %l57, !tbaa !21
  store i1 %t121, ptr %l8, !tbaa !21
  %t122 = load ptr, ptr %l0, !tbaa !29
  store ptr %t122, ptr %l58, !tbaa !29
  %t123 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t123, ptr %l59, !tbaa !27
  %t124 = load %"compiler/cond:Value", ptr %l7
  store %"compiler/cond:Value" %t124, ptr %l60
  %t125 = load i1, ptr %l8, !tbaa !21
  store i1 %t125, ptr %l61, !tbaa !21
  %t126 = load ptr, ptr %l58, !tbaa !29
  %t127 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t128 = load %"compiler/cond:Value", ptr %l60
  %t129 = load i1, ptr %l61, !tbaa !21
  call void @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eadd(ptr %v0, ptr %v1, ptr %t126, { i64, ptr } %t127, %"compiler/cond:Value" %t128, i1 false, i1 %t129, i1 true)
  br label %bb35
bb35:
  %t130 = load ptr, ptr %l0, !tbaa !29
  store ptr %t130, ptr %l62, !tbaa !29
  %t131 = load ptr, ptr %l62, !tbaa !29
  %t132 = getelementptr %"compiler/cond:Consts", ptr %t131, i32 0, i32 5
  store ptr %t132, ptr %l63, !tbaa !29
  %t133 = load ptr, ptr %l0, !tbaa !29
  store ptr %t133, ptr %l64, !tbaa !29
  %t134 = load ptr, ptr %l64, !tbaa !29
  %t135 = getelementptr %"compiler/cond:Consts", ptr %t134, i32 0, i32 5
  store ptr %t135, ptr %l65, !tbaa !29
  %t136 = load ptr, ptr %l65, !tbaa !29
  %t137 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %t136)
  store i64 %t137, ptr %l66
  br label %bb36
bb36:
  %t138 = load i64, ptr %l66, !tbaa !24
  %t139 = sub i64 %t138, 1
  store i64 %t139, ptr %l67, !tbaa !24
  %t140 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t140, ptr %l68, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s5
  store ptr %s5room, ptr %s5
  %t141 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t141, 1
  %t143 = extractvalue { i64, ptr } %t141, 0
  call void @__olang_sb_put(ptr %s5, ptr %t142, i64 %t143)
  %t144 = load ptr, ptr %s5
  %t145 = getelementptr %olang.builder, ptr %s5, i32 0, i32 1
  %t146 = load i64, ptr %t145
  %t147 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t146)
  call void @llvm.memcpy.p0.p0.i64(ptr %t147, ptr %t144, i64 %t146, i1 false)
  %t148 = insertvalue { i64, ptr } undef, i64 %t146, 0
  %t149 = insertvalue { i64, ptr } %t148, ptr %t147, 1
  store { i64, ptr } %t149, ptr %l69, !tbaa !27
  call void @__olang_sb_done(ptr %s5)
  %t150 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t151 = extractvalue { i64, ptr } %t150, 0
  %t152 = extractvalue { i64, ptr } %t150, 1
  %t153 = mul i64 %t151, 1
  %t154 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t153)
  call void @llvm.memcpy.p0.p0.i64(ptr %t154, ptr %t152, i64 %t153, i1 false)
  %t155 = insertvalue { i64, ptr } undef, i64 %t151, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t154, 1
  store { i64, ptr } %t156, ptr %l70, !tbaa !27
  %t157 = load ptr, ptr %l63, !tbaa !29
  %t158 = load i64, ptr %l67, !tbaa !24
  %t159 = load { i64, ptr }, ptr %l70, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H6b12c12825efdaf6153dbfa8fc9a5aca(ptr %v0, ptr %v0, ptr %t157, i64 %t158, { i64, ptr } %t159)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, i64 } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2efind(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i1
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i1
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i1
  %l29 = alloca i1
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca i64
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca i1
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i32, i64 }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store %olang.scope zeroinitializer, ptr %s1
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = getelementptr %"compiler/cond:Consts", ptr %t2, i32 0, i32 0
  store ptr %t3, ptr %l9, !tbaa !29
  %t4 = load ptr, ptr %l9, !tbaa !29
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %t4)
  store i64 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i64, ptr %l10, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  store i64 %t7, ptr %l11, !tbaa !24
  %t8 = load i64, ptr %l2, !tbaa !24
  store i64 %t8, ptr %l12, !tbaa !24
  %t9 = load i64, ptr %l11, !tbaa !24
  %t10 = load i64, ptr %l12, !tbaa !24
  %t11 = icmp sgt i64 %t9, %t10
  store i1 %t11, ptr %l13, !tbaa !21
  %t12 = load i1, ptr %l13, !tbaa !21
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l4, !tbaa !24
  store i64 %t13, ptr %l15, !tbaa !24
  %t14 = load i64, ptr %l15, !tbaa !24
  %t15 = icmp sgt i64 %t14, 0
  store i1 %t15, ptr %l16, !tbaa !21
  %t16 = load i1, ptr %l16, !tbaa !21
  br i1 %t16, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l3, !tbaa !24
  store i64 %t17, ptr %l18, !tbaa !24
  %t18 = load i64, ptr %l2, !tbaa !24
  store i64 %t18, ptr %l19, !tbaa !24
  %t19 = load i64, ptr %l18, !tbaa !24
  %t20 = load i64, ptr %l19, !tbaa !24
  %t21 = sub i64 %t19, %t20
  store i64 %t21, ptr %l20, !tbaa !24
  %t22 = load i64, ptr %l4, !tbaa !24
  store i64 %t22, ptr %l21, !tbaa !24
  %t23 = load i64, ptr %l20, !tbaa !24
  %t24 = load i64, ptr %l21, !tbaa !24
  %t25 = add i64 %t23, %t24
  store i64 %t25, ptr %l22, !tbaa !24
  %t26 = load i64, ptr %l22, !tbaa !24
  %t27 = sub i64 %t26, 1
  store i64 %t27, ptr %l23, !tbaa !24
  %t28 = load i64, ptr %l4, !tbaa !24
  store i64 %t28, ptr %l24, !tbaa !24
  %t29 = load i64, ptr %l23, !tbaa !24
  %t30 = load i64, ptr %l24, !tbaa !24
  %t31 = sdiv i64 %t29, %t30
  store i64 %t31, ptr %l25, !tbaa !24
  %t32 = load i64, ptr %l25, !tbaa !24
  store i64 %t32, ptr %l17, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l17, !tbaa !24
  store i64 %t33, ptr %l14, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l14, !tbaa !24
  store i64 %t34, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load i64, ptr %l6, !tbaa !24
  store i64 %t35, ptr %l26, !tbaa !24
  %t36 = load i64, ptr %l5, !tbaa !24
  store i64 %t36, ptr %l27, !tbaa !24
  %t37 = load i64, ptr %l26, !tbaa !24
  %t38 = load i64, ptr %l27, !tbaa !24
  %t39 = icmp slt i64 %t37, %t38
  store i1 %t39, ptr %l28, !tbaa !21
  %t40 = load i1, ptr %l28, !tbaa !21
  %t41 = xor i1 %t40, true
  store i1 %t41, ptr %l29, !tbaa !21
  %t42 = load i1, ptr %l29, !tbaa !21
  br i1 %t42, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l2, !tbaa !24
  store i64 %t43, ptr %l30, !tbaa !24
  %t44 = load i64, ptr %l6, !tbaa !24
  store i64 %t44, ptr %l31, !tbaa !24
  %t45 = load i64, ptr %l4, !tbaa !24
  store i64 %t45, ptr %l32, !tbaa !24
  %t46 = load i64, ptr %l31, !tbaa !24
  %t47 = load i64, ptr %l32, !tbaa !24
  %t48 = mul i64 %t46, %t47
  store i64 %t48, ptr %l33, !tbaa !24
  %t49 = load i64, ptr %l30, !tbaa !24
  %t50 = load i64, ptr %l33, !tbaa !24
  %t51 = add i64 %t49, %t50
  store i64 %t51, ptr %l34, !tbaa !24
  %t52 = load i64, ptr %l34, !tbaa !24
  store i64 %t52, ptr %l7, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  store ptr %t53, ptr %l35, !tbaa !29
  %t54 = load ptr, ptr %l35, !tbaa !29
  %t55 = getelementptr %"compiler/cond:Consts", ptr %t54, i32 0, i32 0
  store ptr %t55, ptr %l36, !tbaa !29
  %t56 = load i64, ptr %l7, !tbaa !24
  store i64 %t56, ptr %l37, !tbaa !24
  %t57 = load ptr, ptr %l36, !tbaa !29
  %t58 = load i64, ptr %l37, !tbaa !24
  %t59 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t57, i64 %t58)
  store { i64, ptr } %t59, ptr %l38
  br label %bb12
bb12:
  %t60 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t60, ptr %l39, !tbaa !27
  %t61 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t63 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t61, { i64, ptr } %t62)
  store i1 %t63, ptr %l40
  br label %bb13
bb13:
  %t64 = load i1, ptr %l40, !tbaa !21
  br i1 %t64, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t65 = load i64, ptr %l7, !tbaa !24
  store i64 %t65, ptr %l41, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t66 = load i64, ptr %l41, !tbaa !24
  %t67 = insertvalue { i32, i64 } zeroinitializer, i64 %t66, 1
  store { i32, i64 } %t67, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s4
  %t68 = load i64, ptr %l6, !tbaa !24
  store i64 %t68, ptr %l42, !tbaa !24
  %t69 = load i64, ptr %l42, !tbaa !24
  %t70 = add i64 %t69, 1
  store i64 %t70, ptr %l43, !tbaa !24
  %t71 = load i64, ptr %l43, !tbaa !24
  store i64 %t71, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb8
bb18:
  call void @__olang_scope_close(ptr %s1)
  store i32 65536, ptr %l44, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t72 = load i32, ptr %l44, !tbaa !23
  %t73 = insertvalue { i32, i64 } zeroinitializer, i32 %t72, 0
  store { i32, i64 } %t73, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local { i32, { %"compiler/cond:Value", i1 } } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eliteral(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca %"compiler/scan:Tokens"
  %l6 = alloca i1
  %l7 = alloca i32
  %l8 = alloca double
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i1
  %l12 = alloca { i64, ptr }
  %l13 = alloca i1
  %l14 = alloca i1
  %l15 = alloca { i64, ptr }
  %l16 = alloca i1
  %l17 = alloca { i64, ptr }
  %l18 = alloca i1
  %l19 = alloca %"compiler/cond:Value"
  %l20 = alloca { %"compiler/cond:Value", i1 }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i1
  %l24 = alloca i1
  %l25 = alloca { i64, ptr }
  %l26 = alloca i8
  %l27 = alloca i1
  %l28 = alloca i1
  %l29 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i8
  %l34 = alloca i1
  %l35 = alloca i32
  %l36 = alloca ptr
  %l37 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i1
  %l43 = alloca i1
  %l44 = alloca i1
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l47 = alloca %"compiler/cond:Value"
  %l48 = alloca { %"compiler/cond:Value", i1 }
  %l49 = alloca { i64, ptr }
  %l50 = alloca i64
  %l51 = alloca i1
  %l52 = alloca i1
  %l53 = alloca { i64, ptr }
  %l54 = alloca i8
  %l55 = alloca i1
  %l56 = alloca i1
  %l57 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i1
  %l64 = alloca i1
  %l65 = alloca i1
  %l66 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l70 = alloca i64
  %l71 = alloca i64
  %l72 = alloca i1
  %l73 = alloca i1
  %l74 = alloca i1
  %l75 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l77 = alloca i64
  %l78 = alloca i1
  %l79 = alloca i1
  %l80 = alloca { i64, ptr }
  %l81 = alloca i8
  %l82 = alloca i1
  %l83 = alloca i1
  %l84 = alloca { i64, ptr }
  %l85 = alloca i8
  %l86 = alloca i1
  %l87 = alloca i1
  %l88 = alloca { i64, ptr }
  %l89 = alloca i8
  %l90 = alloca i1
  %l91 = alloca i1
  %l92 = alloca { i64, ptr }
  %l93 = alloca i8
  %l94 = alloca i1
  %l95 = alloca i1
  %l96 = alloca { i64, ptr }
  %l97 = alloca i8
  %l98 = alloca i1
  %l99 = alloca { i64, ptr }
  %l100 = alloca %"compiler/scan:Tokens"
  %l101 = alloca { i64, ptr }
  %l102 = alloca i64
  %l103 = alloca i1
  %l104 = alloca i1
  %l105 = alloca { i64, ptr }
  %l106 = alloca i64
  %l107 = alloca i1
  %l108 = alloca i1
  %l109 = alloca { i64, ptr }
  %l110 = alloca i32
  %l111 = alloca i1
  %l112 = alloca i1
  %l113 = alloca { i64, ptr }
  %l114 = alloca i32
  %l115 = alloca { i64, ptr }
  %l116 = alloca i64
  %l117 = alloca i32
  %l118 = alloca i1
  %l119 = alloca i1
  %l120 = alloca i32
  %l121 = alloca { i64, ptr }
  %l122 = alloca i32
  %l123 = alloca i32
  %l124 = alloca i32
  %l125 = alloca ptr
  %l126 = alloca i32
  %l127 = alloca ptr
  %l128 = alloca i1
  %l129 = alloca i1
  %l130 = alloca i1
  %l131 = alloca i32
  %l132 = alloca ptr
  %l133 = alloca i32
  %l134 = alloca ptr
  %l135 = alloca i1
  %l136 = alloca i1
  %l137 = alloca i1
  %l138 = alloca i32
  %l139 = alloca i32
  %l140 = alloca ptr
  %l141 = alloca { i64, ptr }
  %l142 = alloca i64
  %l143 = alloca %"compiler/cond:Value"
  %l144 = alloca { %"compiler/cond:Value", i1 }
  %l145 = alloca i32
  %l146 = alloca ptr
  %l147 = alloca i32
  %l148 = alloca ptr
  %l149 = alloca i1
  %l150 = alloca double
  %l151 = alloca { i64, ptr }
  %l152 = alloca { i64, ptr }
  %l153 = alloca { i64, ptr }
  %l154 = alloca double
  %l155 = alloca i32
  %l156 = alloca i32
  %l157 = alloca double
  %l158 = alloca double
  %l159 = alloca double
  %l160 = alloca i1
  %l161 = alloca i32
  %l162 = alloca i32
  %l163 = alloca i1
  %l164 = alloca double
  %l165 = alloca double
  %l166 = alloca double
  %l167 = alloca double
  %l168 = alloca %"compiler/cond:Value"
  %l169 = alloca { %"compiler/cond:Value", i1 }
  %l170 = alloca i64
  %l171 = alloca { i64, ptr }
  %l172 = alloca i64
  %l173 = alloca i32
  %l174 = alloca i64
  %l175 = alloca i32
  %l176 = alloca i32
  %l177 = alloca i1
  %l178 = alloca i64
  %l179 = alloca i64
  %l180 = alloca i32
  %l181 = alloca i1
  %l182 = alloca i64
  %l183 = alloca i64
  %l184 = alloca i64
  %l185 = alloca i64
  %l186 = alloca i64
  %l187 = alloca %"compiler/cond:Value"
  %l188 = alloca { %"compiler/cond:Value", i1 }
  %l189 = alloca i1
  %l190 = alloca i64
  %l191 = alloca i64
  %l192 = alloca i1
  %l193 = alloca i32
  %l194 = alloca i32
  %l195 = alloca i64
  %l196 = alloca i64
  %l197 = alloca i64
  %l198 = alloca i64
  %l199 = alloca %"compiler/cond:Value"
  %l200 = alloca { %"compiler/cond:Value", i1 }
  %l201 = alloca i64
  %l202 = alloca i1
  %l203 = alloca i32
  %l204 = alloca i64
  %l205 = alloca i64
  %l206 = alloca i64
  %l207 = alloca %"compiler/cond:Value"
  %l208 = alloca i1
  %l209 = alloca { %"compiler/cond:Value", i1 }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca { i32, { %"compiler/cond:Value", i1 } }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t1, ptr %l12, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t2, { i64, ptr } { i64 4, ptr @.d25 })
  store i1 %t3, ptr %l13
  br label %bb1
bb1:
  %t4 = load i1, ptr %l13, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb5
bb3:
  %t5 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t5, ptr %l15, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t6, { i64, ptr } { i64 5, ptr @.d26 })
  store i1 %t7, ptr %l16
  br label %bb4
bb4:
  %t8 = load i1, ptr %l16, !tbaa !21
  store i1 %t8, ptr %l14, !tbaa !21
  br label %bb5
bb5:
  %t9 = load i1, ptr %l14, !tbaa !21
  br i1 %t9, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t10 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t10, ptr %l17, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t12 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s1, { i64, ptr } %t11, { i64, ptr } { i64 4, ptr @.d27 })
  store i1 %t12, ptr %l18
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t13 = load i1, ptr %l18, !tbaa !21
  %t14 = call %"compiler/cond:Value" @compiler_2fcond_2eboolValue(i1 %t13)
  store %"compiler/cond:Value" %t14, ptr %l19
  br label %bb9
bb9:
  %t15 = load %"compiler/cond:Value", ptr %l19
  %t16 = insertvalue { %"compiler/cond:Value", i1 } undef, %"compiler/cond:Value" %t15, 0
  %t17 = insertvalue { %"compiler/cond:Value", i1 } %t16, i1 false, 1
  store { %"compiler/cond:Value", i1 } %t17, ptr %l20
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t18 = load { %"compiler/cond:Value", i1 }, ptr %l20
  %t19 = insertvalue { i32, { %"compiler/cond:Value", i1 } } zeroinitializer, { %"compiler/cond:Value", i1 } %t18, 1
  store { i32, { %"compiler/cond:Value", i1 } } %t19, ptr %rv
  br label %ret
bb10:
  %t20 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t20, ptr %l21, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t21, 0
  store i64 %t22, ptr %l22, !tbaa !24
  %t23 = load i64, ptr %l22, !tbaa !24
  %t24 = icmp sge i64 %t23, 2
  store i1 %t24, ptr %l23, !tbaa !21
  %t25 = load i1, ptr %l23, !tbaa !21
  br i1 %t25, label %bb11, label %bb12
bb11:
  %t26 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t26, ptr %l25, !tbaa !27
  %t27 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i8, ptr %t28, i64 0
  %t30 = load i8, ptr %t29, !tbaa !32
  store i8 %t30, ptr %l26, !tbaa !22
  %t31 = load i8, ptr %l26, !tbaa !22
  %t32 = icmp eq i8 %t31, 34
  store i1 %t32, ptr %l27, !tbaa !21
  %t33 = load i1, ptr %l27, !tbaa !21
  store i1 %t33, ptr %l24, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb13
bb13:
  %t34 = load i1, ptr %l24, !tbaa !21
  br i1 %t34, label %bb14, label %bb15
bb14:
  %t35 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t35, ptr %l29, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t36, ptr %l30, !tbaa !27
  %t37 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t37, 0
  store i64 %t38, ptr %l31, !tbaa !24
  %t39 = load i64, ptr %l31, !tbaa !24
  %t40 = sub i64 %t39, 1
  store i64 %t40, ptr %l32, !tbaa !24
  %t41 = load i64, ptr %l32, !tbaa !24
  %t42 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr i8, ptr %t43, i64 %t41
  %t45 = load i8, ptr %t44, !tbaa !32
  store i8 %t45, ptr %l33, !tbaa !22
  %t46 = load i8, ptr %l33, !tbaa !22
  %t47 = icmp eq i8 %t46, 34
  store i1 %t47, ptr %l34, !tbaa !21
  %t48 = load i1, ptr %l34, !tbaa !21
  store i1 %t48, ptr %l28, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb16
bb16:
  %t49 = load i1, ptr %l28, !tbaa !21
  br i1 %t49, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s2
  store i32 4, ptr %l35
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l36, !tbaa !29
  %t51 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t51, ptr %l37, !tbaa !27
  %t52 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t52, ptr %l38, !tbaa !27
  %t53 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t53, 0
  store i64 %t54, ptr %l39, !tbaa !24
  %t55 = load i64, ptr %l39, !tbaa !24
  %t56 = sub i64 %t55, 1
  store i64 %t56, ptr %l40, !tbaa !24
  %t57 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t57, 0
  store i64 %t58, ptr %l41, !tbaa !24
  %t59 = icmp sge i64 1, 0
  store i1 %t59, ptr %l42, !tbaa !21
  %t60 = load i1, ptr %l42, !tbaa !21
  br i1 %t60, label %bb19, label %bb20
bb18:
  br label %bb27
bb19:
  %t61 = load i64, ptr %l40, !tbaa !24
  %t62 = icmp sle i64 1, %t61
  store i1 %t62, ptr %l43, !tbaa !21
  %t63 = load i1, ptr %l43, !tbaa !21
  br i1 %t63, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @.c28)
  unreachable
bb21:
  %t64 = load i64, ptr %l40, !tbaa !24
  %t65 = load i64, ptr %l41, !tbaa !24
  %t66 = icmp sle i64 %t64, %t65
  store i1 %t66, ptr %l44, !tbaa !21
  %t67 = load i1, ptr %l44, !tbaa !21
  br i1 %t67, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @.c28)
  unreachable
bb23:
  %t68 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = load i64, ptr %l40, !tbaa !24
  %t71 = getelementptr i8, ptr %t69, i64 1
  %t72 = sub i64 %t70, 1
  %t73 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t71, 1
  store { i64, ptr } %t74, ptr %l45, !tbaa !27
  %t75 = load ptr, ptr %l36, !tbaa !29
  %t76 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t77 = call i64 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2etext(ptr %v0, ptr %v1, ptr %t75, { i64, ptr } %t76)
  store i64 %t77, ptr %l46
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @.c28)
  unreachable
bb25:
  %t78 = load i32, ptr %l35
  %t79 = load i64, ptr %l46, !tbaa !24
  %t80 = call %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %s2, i32 %t78, i64 0, double 0x0000000000000000, i64 %t79, i64 0, i1 false)
  store %"compiler/cond:Value" %t80, ptr %l47
  br label %bb26
bb26:
  %t81 = load %"compiler/cond:Value", ptr %l47
  %t82 = insertvalue { %"compiler/cond:Value", i1 } undef, %"compiler/cond:Value" %t81, 0
  %t83 = insertvalue { %"compiler/cond:Value", i1 } %t82, i1 false, 1
  store { %"compiler/cond:Value", i1 } %t83, ptr %l48
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t84 = load { %"compiler/cond:Value", i1 }, ptr %l48
  %t85 = insertvalue { i32, { %"compiler/cond:Value", i1 } } zeroinitializer, { %"compiler/cond:Value", i1 } %t84, 1
  store { i32, { %"compiler/cond:Value", i1 } } %t85, ptr %rv
  br label %ret
bb27:
  %t86 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t86, ptr %l49, !tbaa !27
  %t87 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t87, 0
  store i64 %t88, ptr %l50, !tbaa !24
  %t89 = load i64, ptr %l50, !tbaa !24
  %t90 = icmp sgt i64 %t89, 0
  store i1 %t90, ptr %l51, !tbaa !21
  %t91 = load i1, ptr %l51, !tbaa !21
  br i1 %t91, label %bb28, label %bb29
bb28:
  %t92 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t92, ptr %l53, !tbaa !27
  %t93 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr i8, ptr %t94, i64 0
  %t96 = load i8, ptr %t95, !tbaa !32
  store i8 %t96, ptr %l54, !tbaa !22
  %t97 = load i8, ptr %l54, !tbaa !22
  %t98 = icmp eq i8 %t97, 45
  store i1 %t98, ptr %l55, !tbaa !21
  %t99 = load i1, ptr %l55, !tbaa !21
  store i1 %t99, ptr %l52, !tbaa !21
  br label %bb30
bb29:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb30
bb30:
  %t100 = load i1, ptr %l52, !tbaa !21
  store i1 %t100, ptr %l2, !tbaa !21
  %t101 = load i1, ptr %l2, !tbaa !21
  store i1 %t101, ptr %l56, !tbaa !21
  %t102 = load i1, ptr %l56, !tbaa !21
  br i1 %t102, label %bb31, label %bb32
bb31:
  %t103 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t103, ptr %l58, !tbaa !27
  %t104 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t104, ptr %l59, !tbaa !27
  %t105 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t105, ptr %l60, !tbaa !27
  %t106 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t106, 0
  store i64 %t107, ptr %l61, !tbaa !24
  %t108 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t108, 0
  store i64 %t109, ptr %l62, !tbaa !24
  %t110 = icmp sge i64 1, 0
  store i1 %t110, ptr %l63, !tbaa !21
  %t111 = load i1, ptr %l63, !tbaa !21
  br i1 %t111, label %bb33, label %bb34
bb32:
  %t112 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t112, ptr %l67, !tbaa !27
  %t113 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t113, ptr %l68, !tbaa !27
  %t114 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t114, ptr %l69, !tbaa !27
  %t115 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t116 = extractvalue { i64, ptr } %t115, 0
  store i64 %t116, ptr %l70, !tbaa !24
  %t117 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t118 = extractvalue { i64, ptr } %t117, 0
  store i64 %t118, ptr %l71, !tbaa !24
  %t119 = icmp sge i64 0, 0
  store i1 %t119, ptr %l72, !tbaa !21
  %t120 = load i1, ptr %l72, !tbaa !21
  br i1 %t120, label %bb39, label %bb40
bb33:
  %t121 = load i64, ptr %l61, !tbaa !24
  %t122 = icmp sle i64 1, %t121
  store i1 %t122, ptr %l64, !tbaa !21
  %t123 = load i1, ptr %l64, !tbaa !21
  br i1 %t123, label %bb35, label %bb36
bb34:
  call void @__olang_check_failed(ptr @.c29)
  unreachable
bb35:
  %t124 = load i64, ptr %l61, !tbaa !24
  %t125 = load i64, ptr %l62, !tbaa !24
  %t126 = icmp sle i64 %t124, %t125
  store i1 %t126, ptr %l65, !tbaa !21
  %t127 = load i1, ptr %l65, !tbaa !21
  br i1 %t127, label %bb37, label %bb38
bb36:
  call void @__olang_check_failed(ptr @.c29)
  unreachable
bb37:
  %t128 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = load i64, ptr %l61, !tbaa !24
  %t131 = getelementptr i8, ptr %t129, i64 1
  %t132 = sub i64 %t130, 1
  %t133 = insertvalue { i64, ptr } undef, i64 %t132, 0
  %t134 = insertvalue { i64, ptr } %t133, ptr %t131, 1
  store { i64, ptr } %t134, ptr %l66, !tbaa !27
  %t135 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t135, ptr %l57, !tbaa !27
  br label %bb45
bb38:
  call void @__olang_check_failed(ptr @.c29)
  unreachable
bb39:
  %t136 = load i64, ptr %l70, !tbaa !24
  %t137 = icmp sle i64 0, %t136
  store i1 %t137, ptr %l73, !tbaa !21
  %t138 = load i1, ptr %l73, !tbaa !21
  br i1 %t138, label %bb41, label %bb42
bb40:
  call void @__olang_check_failed(ptr @.c29)
  unreachable
bb41:
  %t139 = load i64, ptr %l70, !tbaa !24
  %t140 = load i64, ptr %l71, !tbaa !24
  %t141 = icmp sle i64 %t139, %t140
  store i1 %t141, ptr %l74, !tbaa !21
  %t142 = load i1, ptr %l74, !tbaa !21
  br i1 %t142, label %bb43, label %bb44
bb42:
  call void @__olang_check_failed(ptr @.c29)
  unreachable
bb43:
  %t143 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !27
  %t145 = load i64, ptr %l70, !tbaa !24
  %t146 = getelementptr i8, ptr %t144, i64 0
  %t147 = sub i64 %t145, 0
  %t148 = insertvalue { i64, ptr } undef, i64 %t147, 0
  %t149 = insertvalue { i64, ptr } %t148, ptr %t146, 1
  store { i64, ptr } %t149, ptr %l75, !tbaa !27
  %t150 = load { i64, ptr }, ptr %l75, !tbaa !27
  store { i64, ptr } %t150, ptr %l57, !tbaa !27
  br label %bb45
bb44:
  call void @__olang_check_failed(ptr @.c29)
  unreachable
bb45:
  %t151 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t151, ptr %l3, !tbaa !27
  %t152 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t152, ptr %l76, !tbaa !27
  %t153 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t154 = extractvalue { i64, ptr } %t153, 0
  store i64 %t154, ptr %l77, !tbaa !24
  %t155 = load i64, ptr %l77, !tbaa !24
  %t156 = icmp sge i64 %t155, 2
  store i1 %t156, ptr %l78, !tbaa !21
  %t157 = load i1, ptr %l78, !tbaa !21
  br i1 %t157, label %bb46, label %bb47
bb46:
  %t158 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t158, ptr %l80, !tbaa !27
  %t159 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !27
  %t161 = getelementptr i8, ptr %t160, i64 0
  %t162 = load i8, ptr %t161, !tbaa !32
  store i8 %t162, ptr %l81, !tbaa !22
  %t163 = load i8, ptr %l81, !tbaa !22
  %t164 = icmp eq i8 %t163, 48
  store i1 %t164, ptr %l82, !tbaa !21
  %t165 = load i1, ptr %l82, !tbaa !21
  store i1 %t165, ptr %l79, !tbaa !21
  br label %bb48
bb47:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb48
bb48:
  %t166 = load i1, ptr %l79, !tbaa !21
  br i1 %t166, label %bb49, label %bb50
bb49:
  %t167 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t167, ptr %l84, !tbaa !27
  %t168 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !27
  %t170 = getelementptr i8, ptr %t169, i64 1
  %t171 = load i8, ptr %t170, !tbaa !32
  store i8 %t171, ptr %l85, !tbaa !22
  %t172 = load i8, ptr %l85, !tbaa !22
  %t173 = icmp eq i8 %t172, 120
  store i1 %t173, ptr %l86, !tbaa !21
  %t174 = load i1, ptr %l86, !tbaa !21
  br i1 %t174, label %bb51, label %bb52
bb50:
  store i1 false, ptr %l83, !tbaa !21
  br label %bb60
bb51:
  store i1 true, ptr %l87, !tbaa !21
  br label %bb53
bb52:
  %t175 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t175, ptr %l88, !tbaa !27
  %t176 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = getelementptr i8, ptr %t177, i64 1
  %t179 = load i8, ptr %t178, !tbaa !32
  store i8 %t179, ptr %l89, !tbaa !22
  %t180 = load i8, ptr %l89, !tbaa !22
  %t181 = icmp eq i8 %t180, 88
  store i1 %t181, ptr %l90, !tbaa !21
  %t182 = load i1, ptr %l90, !tbaa !21
  store i1 %t182, ptr %l87, !tbaa !21
  br label %bb53
bb53:
  %t183 = load i1, ptr %l87, !tbaa !21
  br i1 %t183, label %bb54, label %bb55
bb54:
  store i1 true, ptr %l91, !tbaa !21
  br label %bb56
bb55:
  %t184 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t184, ptr %l92, !tbaa !27
  %t185 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t186 = load ptr, ptr %t185, !tbaa !27
  %t187 = getelementptr i8, ptr %t186, i64 1
  %t188 = load i8, ptr %t187, !tbaa !32
  store i8 %t188, ptr %l93, !tbaa !22
  %t189 = load i8, ptr %l93, !tbaa !22
  %t190 = icmp eq i8 %t189, 98
  store i1 %t190, ptr %l94, !tbaa !21
  %t191 = load i1, ptr %l94, !tbaa !21
  store i1 %t191, ptr %l91, !tbaa !21
  br label %bb56
bb56:
  %t192 = load i1, ptr %l91, !tbaa !21
  br i1 %t192, label %bb57, label %bb58
bb57:
  store i1 true, ptr %l95, !tbaa !21
  br label %bb59
bb58:
  %t193 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t193, ptr %l96, !tbaa !27
  %t194 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t195 = load ptr, ptr %t194, !tbaa !27
  %t196 = getelementptr i8, ptr %t195, i64 1
  %t197 = load i8, ptr %t196, !tbaa !32
  store i8 %t197, ptr %l97, !tbaa !22
  %t198 = load i8, ptr %l97, !tbaa !22
  %t199 = icmp eq i8 %t198, 66
  store i1 %t199, ptr %l98, !tbaa !21
  %t200 = load i1, ptr %l98, !tbaa !21
  store i1 %t200, ptr %l95, !tbaa !21
  br label %bb59
bb59:
  %t201 = load i1, ptr %l95, !tbaa !21
  store i1 %t201, ptr %l83, !tbaa !21
  br label %bb60
bb60:
  %t202 = load i1, ptr %l83, !tbaa !21
  store i1 %t202, ptr %l4, !tbaa !21
  %t203 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t203, ptr %l99, !tbaa !27
  %t204 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t205 = call %"compiler/scan:Tokens" @compiler_2fscan_2eScan(ptr %v1, ptr %s0, { i64, ptr } %t204)
  store %"compiler/scan:Tokens" %t205, ptr %l100
  br label %bb61
bb61:
  %t206 = load %"compiler/scan:Tokens", ptr %l100
  store %"compiler/scan:Tokens" %t206, ptr %l5
  %t207 = getelementptr %"compiler/scan:Tokens", ptr %l5, i32 0, i32 0
  %t208 = load { i64, ptr }, ptr %t207, !tbaa !27
  store { i64, ptr } %t208, ptr %l101, !tbaa !27
  %t209 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t210 = extractvalue { i64, ptr } %t209, 0
  store i64 %t210, ptr %l102, !tbaa !24
  %t211 = load i64, ptr %l102, !tbaa !24
  %t212 = icmp sge i64 %t211, 2
  store i1 %t212, ptr %l103, !tbaa !21
  %t213 = load i1, ptr %l103, !tbaa !21
  br i1 %t213, label %bb62, label %bb63
bb62:
  %t214 = getelementptr %"compiler/scan:Tokens", ptr %l5, i32 0, i32 3
  %t215 = load { i64, ptr }, ptr %t214, !tbaa !27
  store { i64, ptr } %t215, ptr %l105, !tbaa !27
  %t216 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t217 = extractvalue { i64, ptr } %t216, 0
  store i64 %t217, ptr %l106, !tbaa !24
  %t218 = load i64, ptr %l106, !tbaa !24
  %t219 = icmp eq i64 %t218, 0
  store i1 %t219, ptr %l107, !tbaa !21
  %t220 = load i1, ptr %l107, !tbaa !21
  store i1 %t220, ptr %l104, !tbaa !21
  br label %bb64
bb63:
  store i1 false, ptr %l104, !tbaa !21
  br label %bb64
bb64:
  %t221 = load i1, ptr %l104, !tbaa !21
  br i1 %t221, label %bb65, label %bb66
bb65:
  %t222 = getelementptr %"compiler/scan:Tokens", ptr %l5, i32 0, i32 0
  %t223 = load { i64, ptr }, ptr %t222, !tbaa !27
  store { i64, ptr } %t223, ptr %l109, !tbaa !27
  %t224 = getelementptr { i64, ptr }, ptr %l109, i32 0, i32 1
  %t225 = load ptr, ptr %t224, !tbaa !27
  %t226 = getelementptr %"compiler/token:Token", ptr %t225, i64 0
  %t227 = getelementptr %"compiler/token:Token", ptr %t226, i32 0, i32 2
  %t228 = load i32, ptr %t227, !tbaa !23
  store i32 %t228, ptr %l110, !tbaa !23
  %t229 = load i32, ptr %l110, !tbaa !23
  %t230 = icmp eq i32 %t229, 0
  store i1 %t230, ptr %l111, !tbaa !21
  %t231 = load i1, ptr %l111, !tbaa !21
  store i1 %t231, ptr %l108, !tbaa !21
  br label %bb67
bb66:
  store i1 false, ptr %l108, !tbaa !21
  br label %bb67
bb67:
  %t232 = load i1, ptr %l108, !tbaa !21
  br i1 %t232, label %bb68, label %bb69
bb68:
  %t233 = getelementptr %"compiler/scan:Tokens", ptr %l5, i32 0, i32 0
  %t234 = load { i64, ptr }, ptr %t233, !tbaa !27
  store { i64, ptr } %t234, ptr %l113, !tbaa !27
  %t235 = getelementptr { i64, ptr }, ptr %l113, i32 0, i32 1
  %t236 = load ptr, ptr %t235, !tbaa !27
  %t237 = getelementptr %"compiler/token:Token", ptr %t236, i64 0
  %t238 = getelementptr %"compiler/token:Token", ptr %t237, i32 0, i32 3
  %t239 = load i32, ptr %t238, !tbaa !23
  store i32 %t239, ptr %l114, !tbaa !23
  %t240 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t240, ptr %l115, !tbaa !27
  %t241 = load { i64, ptr }, ptr %l115, !tbaa !27
  %t242 = extractvalue { i64, ptr } %t241, 0
  store i64 %t242, ptr %l116, !tbaa !24
  %t243 = load i64, ptr %l116, !tbaa !24
  %t244 = trunc i64 %t243 to i32
  store i32 %t244, ptr %l117, !tbaa !23
  %t245 = load i32, ptr %l114, !tbaa !23
  %t246 = load i32, ptr %l117, !tbaa !23
  %t247 = icmp eq i32 %t245, %t246
  store i1 %t247, ptr %l118, !tbaa !21
  %t248 = load i1, ptr %l118, !tbaa !21
  store i1 %t248, ptr %l112, !tbaa !21
  br label %bb70
bb69:
  store i1 false, ptr %l112, !tbaa !21
  br label %bb70
bb70:
  %t249 = load i1, ptr %l112, !tbaa !21
  store i1 %t249, ptr %l6, !tbaa !21
  %t250 = load i1, ptr %l6, !tbaa !21
  store i1 %t250, ptr %l119, !tbaa !21
  %t251 = load i1, ptr %l119, !tbaa !21
  br i1 %t251, label %bb71, label %bb72
bb71:
  %t252 = getelementptr %"compiler/scan:Tokens", ptr %l5, i32 0, i32 0
  %t253 = load { i64, ptr }, ptr %t252, !tbaa !27
  store { i64, ptr } %t253, ptr %l121, !tbaa !27
  %t254 = getelementptr { i64, ptr }, ptr %l121, i32 0, i32 1
  %t255 = load ptr, ptr %t254, !tbaa !27
  %t256 = getelementptr %"compiler/token:Token", ptr %t255, i64 0
  %t257 = getelementptr %"compiler/token:Token", ptr %t256, i32 0, i32 0
  %t258 = load i32, ptr %t257
  store i32 %t258, ptr %l122
  %t259 = load i32, ptr %l122
  store i32 %t259, ptr %l120
  br label %bb73
bb72:
  store i32 0, ptr %l123
  %t260 = load i32, ptr %l123
  store i32 %t260, ptr %l120
  br label %bb73
bb73:
  %t261 = load i32, ptr %l120
  store i32 %t261, ptr %l7
  %t262 = load i32, ptr %l7
  store i32 %t262, ptr %l124
  store ptr %l124, ptr %l125, !tbaa !29
  store i32 2, ptr %l126
  store ptr %l126, ptr %l127, !tbaa !29
  %t263 = load ptr, ptr %l125, !tbaa !29
  %t264 = load ptr, ptr %l127, !tbaa !29
  %t265 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t263, ptr %t264)
  store i1 %t265, ptr %l128
  br label %bb74
bb74:
  %t266 = load i1, ptr %l128, !tbaa !21
  %t267 = xor i1 %t266, true
  store i1 %t267, ptr %l129, !tbaa !21
  %t268 = load i1, ptr %l129, !tbaa !21
  br i1 %t268, label %bb75, label %bb76
bb75:
  %t269 = load i32, ptr %l7
  store i32 %t269, ptr %l131
  store ptr %l131, ptr %l132, !tbaa !29
  store i32 3, ptr %l133
  store ptr %l133, ptr %l134, !tbaa !29
  %t270 = load ptr, ptr %l132, !tbaa !29
  %t271 = load ptr, ptr %l134, !tbaa !29
  %t272 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t270, ptr %t271)
  store i1 %t272, ptr %l135
  br label %bb77
bb76:
  store i1 false, ptr %l130, !tbaa !21
  br label %bb78
bb77:
  %t273 = load i1, ptr %l135, !tbaa !21
  %t274 = xor i1 %t273, true
  store i1 %t274, ptr %l136, !tbaa !21
  %t275 = load i1, ptr %l136, !tbaa !21
  store i1 %t275, ptr %l130, !tbaa !21
  br label %bb78
bb78:
  %t276 = load i1, ptr %l130, !tbaa !21
  br i1 %t276, label %bb79, label %bb80
bb79:
  store %olang.scope zeroinitializer, ptr %s3
  %t277 = load i1, ptr %l4, !tbaa !21
  store i1 %t277, ptr %l137, !tbaa !21
  %t278 = load i1, ptr %l137, !tbaa !21
  br i1 %t278, label %bb81, label %bb82
bb80:
  br label %bb86
bb81:
  store %olang.scope zeroinitializer, ptr %s4
  store i32 65540, ptr %l138, !tbaa !23
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t279 = load i32, ptr %l138, !tbaa !23
  %t280 = insertvalue { i32, { %"compiler/cond:Value", i1 } } zeroinitializer, i32 %t279, 0
  store { i32, { %"compiler/cond:Value", i1 } } %t280, ptr %rv
  br label %ret
bb82:
  br label %bb83
bb83:
  store i32 4, ptr %l139
  %t281 = load ptr, ptr %l0, !tbaa !29
  store ptr %t281, ptr %l140, !tbaa !29
  %t282 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t282, ptr %l141, !tbaa !27
  %t283 = load ptr, ptr %l140, !tbaa !29
  %t284 = load { i64, ptr }, ptr %l141, !tbaa !27
  %t285 = call i64 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2etext(ptr %v0, ptr %v1, ptr %t283, { i64, ptr } %t284)
  store i64 %t285, ptr %l142
  br label %bb84
bb84:
  %t286 = load i32, ptr %l139
  %t287 = load i64, ptr %l142, !tbaa !24
  %t288 = call %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %s3, i32 %t286, i64 0, double 0x0000000000000000, i64 %t287, i64 0, i1 false)
  store %"compiler/cond:Value" %t288, ptr %l143
  br label %bb85
bb85:
  %t289 = load %"compiler/cond:Value", ptr %l143
  %t290 = insertvalue { %"compiler/cond:Value", i1 } undef, %"compiler/cond:Value" %t289, 0
  %t291 = insertvalue { %"compiler/cond:Value", i1 } %t290, i1 false, 1
  store { %"compiler/cond:Value", i1 } %t291, ptr %l144
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t292 = load { %"compiler/cond:Value", i1 }, ptr %l144
  %t293 = insertvalue { i32, { %"compiler/cond:Value", i1 } } zeroinitializer, { %"compiler/cond:Value", i1 } %t292, 1
  store { i32, { %"compiler/cond:Value", i1 } } %t293, ptr %rv
  br label %ret
bb86:
  %t294 = load i32, ptr %l7
  store i32 %t294, ptr %l145
  store ptr %l145, ptr %l146, !tbaa !29
  store i32 3, ptr %l147
  store ptr %l147, ptr %l148, !tbaa !29
  %t295 = load ptr, ptr %l146, !tbaa !29
  %t296 = load ptr, ptr %l148, !tbaa !29
  %t297 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t295, ptr %t296)
  store i1 %t297, ptr %l149
  br label %bb87
bb87:
  %t298 = load i1, ptr %l149, !tbaa !21
  br i1 %t298, label %bb88, label %bb89
bb88:
  store %olang.scope zeroinitializer, ptr %s5
  %t299 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t299, ptr %l151, !tbaa !27
  %t300 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t301 = call { i64, ptr } @compiler_2fcond_2estripped(ptr %v1, ptr %s5, { i64, ptr } %t300)
  store { i64, ptr } %t301, ptr %l152
  br label %bb90
bb89:
  br label %bb102
bb90:
  %t302 = load { i64, ptr }, ptr %l152, !tbaa !27
  %t303 = extractvalue { i64, ptr } %t302, 0
  %t304 = extractvalue { i64, ptr } %t302, 1
  %t305 = mul i64 %t303, 1
  %t306 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t305)
  call void @llvm.memcpy.p0.p0.i64(ptr %t306, ptr %t304, i64 %t305, i1 false)
  %t307 = insertvalue { i64, ptr } undef, i64 %t303, 0
  %t308 = insertvalue { i64, ptr } %t307, ptr %t306, 1
  store { i64, ptr } %t308, ptr %l153, !tbaa !27
  %t309 = load { i64, ptr }, ptr %l153, !tbaa !27
  %t310 = call { i32, double } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseFloat(ptr %s5, { i64, ptr } %t309)
  %t311 = extractvalue { i32, double } %t310, 1
  %t312 = extractvalue { i32, double } %t310, 0
  store i32 %t312, ptr %l155
  %t313 = icmp ne i32 %t312, 0
  br i1 %t313, label %bb92, label %ok.314
ok.314:
  store double %t311, ptr %l154
  br label %bb91
bb91:
  %t315 = load double, ptr %l154, !tbaa !26
  store double %t315, ptr %l150, !tbaa !26
  br label %bb94
bb92:
  br label %bb93
bb93:
  store %olang.scope zeroinitializer, ptr %s6
  store i32 65543, ptr %l156, !tbaa !23
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t316 = load i32, ptr %l156, !tbaa !23
  %t317 = insertvalue { i32, { %"compiler/cond:Value", i1 } } zeroinitializer, i32 %t316, 0
  store { i32, { %"compiler/cond:Value", i1 } } %t317, ptr %rv
  br label %ret
bb94:
  %t318 = load double, ptr %l150, !tbaa !26
  store double %t318, ptr %l8, !tbaa !26
  %t319 = load double, ptr %l8, !tbaa !26
  store double %t319, ptr %l157, !tbaa !26
  %t320 = load double, ptr %l8, !tbaa !26
  store double %t320, ptr %l158, !tbaa !26
  %t321 = load double, ptr %l157, !tbaa !26
  %t322 = load double, ptr %l158, !tbaa !26
  %t323 = fsub double %t321, %t322
  store double %t323, ptr %l159, !tbaa !26
  %t324 = load double, ptr %l159, !tbaa !26
  %t325 = fcmp une double %t324, 0x0000000000000000
  store i1 %t325, ptr %l160, !tbaa !21
  %t326 = load i1, ptr %l160, !tbaa !21
  br i1 %t326, label %bb95, label %bb96
bb95:
  store %olang.scope zeroinitializer, ptr %s7
  store i32 65543, ptr %l161, !tbaa !23
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t327 = load i32, ptr %l161, !tbaa !23
  %t328 = insertvalue { i32, { %"compiler/cond:Value", i1 } } zeroinitializer, i32 %t327, 0
  store { i32, { %"compiler/cond:Value", i1 } } %t328, ptr %rv
  br label %ret
bb96:
  br label %bb97
bb97:
  store i32 3, ptr %l162
  %t329 = load i1, ptr %l2, !tbaa !21
  store i1 %t329, ptr %l163, !tbaa !21
  %t330 = load i1, ptr %l163, !tbaa !21
  br i1 %t330, label %bb98, label %bb99
bb98:
  %t331 = load double, ptr %l8, !tbaa !26
  store double %t331, ptr %l165, !tbaa !26
  %t332 = load double, ptr %l165, !tbaa !26
  %t333 = fneg double %t332
  store double %t333, ptr %l166, !tbaa !26
  %t334 = load double, ptr %l166, !tbaa !26
  store double %t334, ptr %l164, !tbaa !26
  br label %bb100
bb99:
  %t335 = load double, ptr %l8, !tbaa !26
  store double %t335, ptr %l167, !tbaa !26
  %t336 = load double, ptr %l167, !tbaa !26
  store double %t336, ptr %l164, !tbaa !26
  br label %bb100
bb100:
  %t337 = load i32, ptr %l162
  %t338 = load double, ptr %l164, !tbaa !26
  %t339 = call %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %s5, i32 %t337, i64 0, double %t338, i64 0, i64 64, i1 false)
  store %"compiler/cond:Value" %t339, ptr %l168
  br label %bb101
bb101:
  %t340 = load %"compiler/cond:Value", ptr %l168
  %t341 = insertvalue { %"compiler/cond:Value", i1 } undef, %"compiler/cond:Value" %t340, 0
  %t342 = insertvalue { %"compiler/cond:Value", i1 } %t341, i1 false, 1
  store { %"compiler/cond:Value", i1 } %t342, ptr %l169
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t343 = load { %"compiler/cond:Value", i1 }, ptr %l169
  %t344 = insertvalue { i32, { %"compiler/cond:Value", i1 } } zeroinitializer, { %"compiler/cond:Value", i1 } %t343, 1
  store { i32, { %"compiler/cond:Value", i1 } } %t344, ptr %rv
  br label %ret
bb102:
  %t345 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t345, ptr %l171, !tbaa !27
  %t346 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s0, i64 0)
  %t347 = extractvalue { i32, i64 } %t346, 1
  %t348 = extractvalue { i32, i64 } %t346, 0
  store i32 %t348, ptr %l173
  %t349 = icmp ne i32 %t348, 0
  br i1 %t349, label %bb104, label %ok.350
ok.350:
  store i64 %t347, ptr %l172
  br label %bb103
bb103:
  %t351 = load { i64, ptr }, ptr %l171, !tbaa !27
  %t352 = load i64, ptr %l172, !tbaa !24
  %t353 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseUint(ptr %v1, { i64, ptr } %t351, i64 %t352)
  %t354 = extractvalue { i32, i64 } %t353, 1
  %t355 = extractvalue { i32, i64 } %t353, 0
  store i32 %t355, ptr %l175
  %t356 = icmp ne i32 %t355, 0
  br i1 %t356, label %bb107, label %ok.357
ok.357:
  store i64 %t354, ptr %l174
  br label %bb106
bb104:
  br label %bb105
bb105:
  store %olang.scope zeroinitializer, ptr %s8
  store i32 65541, ptr %l176, !tbaa !23
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t358 = load i32, ptr %l176, !tbaa !23
  %t359 = insertvalue { i32, { %"compiler/cond:Value", i1 } } zeroinitializer, i32 %t358, 0
  store { i32, { %"compiler/cond:Value", i1 } } %t359, ptr %rv
  br label %ret
bb106:
  %t360 = load i64, ptr %l174, !tbaa !65
  store i64 %t360, ptr %l170, !tbaa !65
  br label %bb108
bb107:
  br label %bb105
bb108:
  %t361 = load i64, ptr %l170, !tbaa !65
  store i64 %t361, ptr %l9, !tbaa !65
  %t362 = load i1, ptr %l4, !tbaa !21
  store i1 %t362, ptr %l177, !tbaa !21
  %t363 = load i1, ptr %l177, !tbaa !21
  br i1 %t363, label %bb109, label %bb110
bb109:
  store %olang.scope zeroinitializer, ptr %s9
  %t364 = load i64, ptr %l9, !tbaa !65
  store i64 %t364, ptr %l178, !tbaa !65
  %t365 = load i64, ptr %l178, !tbaa !65
  store i64 %t365, ptr %l179, !tbaa !24
  %t366 = load i64, ptr %l179, !tbaa !24
  store i64 %t366, ptr %l10, !tbaa !24
  store i32 2, ptr %l180
  %t367 = load i1, ptr %l2, !tbaa !21
  store i1 %t367, ptr %l181, !tbaa !21
  %t368 = load i1, ptr %l181, !tbaa !21
  br i1 %t368, label %bb111, label %bb112
bb110:
  br label %bb115
bb111:
  %t369 = load i64, ptr %l10, !tbaa !24
  store i64 %t369, ptr %l183, !tbaa !24
  %t370 = load i64, ptr %l183, !tbaa !24
  %t371 = sub i64 0, %t370
  store i64 %t371, ptr %l184, !tbaa !24
  %t372 = load i64, ptr %l184, !tbaa !24
  store i64 %t372, ptr %l182, !tbaa !24
  br label %bb113
bb112:
  %t373 = load i64, ptr %l10, !tbaa !24
  store i64 %t373, ptr %l185, !tbaa !24
  %t374 = load i64, ptr %l185, !tbaa !24
  store i64 %t374, ptr %l182, !tbaa !24
  br label %bb113
bb113:
  %t375 = load i64, ptr @G_2ecompiler_2fcond_2eLiteralIntBits, !tbaa !24
  store i64 %t375, ptr %l186, !tbaa !24
  %t376 = load i32, ptr %l180
  %t377 = load i64, ptr %l182, !tbaa !24
  %t378 = load i64, ptr %l186, !tbaa !24
  %t379 = call %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %s9, i32 %t376, i64 %t377, double 0x0000000000000000, i64 0, i64 %t378, i1 false)
  store %"compiler/cond:Value" %t379, ptr %l187
  br label %bb114
bb114:
  %t380 = load %"compiler/cond:Value", ptr %l187
  %t381 = insertvalue { %"compiler/cond:Value", i1 } undef, %"compiler/cond:Value" %t380, 0
  %t382 = insertvalue { %"compiler/cond:Value", i1 } %t381, i1 false, 1
  store { %"compiler/cond:Value", i1 } %t382, ptr %l188
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  %t383 = load { %"compiler/cond:Value", i1 }, ptr %l188
  %t384 = insertvalue { i32, { %"compiler/cond:Value", i1 } } zeroinitializer, { %"compiler/cond:Value", i1 } %t383, 1
  store { i32, { %"compiler/cond:Value", i1 } } %t384, ptr %rv
  br label %ret
bb115:
  %t385 = load i1, ptr %l2, !tbaa !21
  store i1 %t385, ptr %l189, !tbaa !21
  %t386 = load i1, ptr %l189, !tbaa !21
  br i1 %t386, label %bb116, label %bb117
bb116:
  store %olang.scope zeroinitializer, ptr %s10
  %t387 = load i64, ptr %l9, !tbaa !65
  store i64 %t387, ptr %l190, !tbaa !65
  %t388 = add i64 9223372036854775807, 1
  store i64 %t388, ptr %l191, !tbaa !65
  %t389 = load i64, ptr %l190, !tbaa !65
  %t390 = load i64, ptr %l191, !tbaa !65
  %t391 = icmp ugt i64 %t389, %t390
  store i1 %t391, ptr %l192, !tbaa !21
  %t392 = load i1, ptr %l192, !tbaa !21
  br i1 %t392, label %bb118, label %bb119
bb117:
  br label %bb122
bb118:
  store %olang.scope zeroinitializer, ptr %s11
  store i32 65542, ptr %l193, !tbaa !23
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  %t393 = load i32, ptr %l193, !tbaa !23
  %t394 = insertvalue { i32, { %"compiler/cond:Value", i1 } } zeroinitializer, i32 %t393, 0
  store { i32, { %"compiler/cond:Value", i1 } } %t394, ptr %rv
  br label %ret
bb119:
  br label %bb120
bb120:
  store i32 2, ptr %l194
  %t395 = load i64, ptr %l9, !tbaa !65
  store i64 %t395, ptr %l195, !tbaa !65
  %t396 = load i64, ptr %l195, !tbaa !65
  store i64 %t396, ptr %l196, !tbaa !24
  %t397 = load i64, ptr %l196, !tbaa !24
  %t398 = sub i64 0, %t397
  store i64 %t398, ptr %l197, !tbaa !24
  %t399 = load i64, ptr @G_2ecompiler_2fcond_2eLiteralIntBits, !tbaa !24
  store i64 %t399, ptr %l198, !tbaa !24
  %t400 = load i32, ptr %l194
  %t401 = load i64, ptr %l197, !tbaa !24
  %t402 = load i64, ptr %l198, !tbaa !24
  %t403 = call %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %s10, i32 %t400, i64 %t401, double 0x0000000000000000, i64 0, i64 %t402, i1 false)
  store %"compiler/cond:Value" %t403, ptr %l199
  br label %bb121
bb121:
  %t404 = load %"compiler/cond:Value", ptr %l199
  %t405 = insertvalue { %"compiler/cond:Value", i1 } undef, %"compiler/cond:Value" %t404, 0
  %t406 = insertvalue { %"compiler/cond:Value", i1 } %t405, i1 false, 1
  store { %"compiler/cond:Value", i1 } %t406, ptr %l200
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  %t407 = load { %"compiler/cond:Value", i1 }, ptr %l200
  %t408 = insertvalue { i32, { %"compiler/cond:Value", i1 } } zeroinitializer, { %"compiler/cond:Value", i1 } %t407, 1
  store { i32, { %"compiler/cond:Value", i1 } } %t408, ptr %rv
  br label %ret
bb122:
  %t409 = load i64, ptr %l9, !tbaa !65
  store i64 %t409, ptr %l201, !tbaa !65
  %t410 = load i64, ptr %l201, !tbaa !65
  %t411 = icmp ugt i64 %t410, 9223372036854775807
  store i1 %t411, ptr %l202, !tbaa !21
  %t412 = load i1, ptr %l202, !tbaa !21
  store i1 %t412, ptr %l11, !tbaa !21
  store i32 2, ptr %l203
  %t413 = load i64, ptr %l9, !tbaa !65
  store i64 %t413, ptr %l204, !tbaa !65
  %t414 = load i64, ptr %l204, !tbaa !65
  store i64 %t414, ptr %l205, !tbaa !24
  %t415 = load i64, ptr @G_2ecompiler_2fcond_2eLiteralIntBits, !tbaa !24
  store i64 %t415, ptr %l206, !tbaa !24
  %t416 = load i32, ptr %l203
  %t417 = load i64, ptr %l205, !tbaa !24
  %t418 = load i64, ptr %l206, !tbaa !24
  %t419 = call %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %s0, i32 %t416, i64 %t417, double 0x0000000000000000, i64 0, i64 %t418, i1 false)
  store %"compiler/cond:Value" %t419, ptr %l207
  br label %bb123
bb123:
  %t420 = load i1, ptr %l11, !tbaa !21
  store i1 %t420, ptr %l208, !tbaa !21
  %t421 = load %"compiler/cond:Value", ptr %l207
  %t422 = insertvalue { %"compiler/cond:Value", i1 } undef, %"compiler/cond:Value" %t421, 0
  %t423 = load i1, ptr %l208, !tbaa !21
  %t424 = insertvalue { %"compiler/cond:Value", i1 } %t422, i1 %t423, 1
  store { %"compiler/cond:Value", i1 } %t424, ptr %l209
  call void @__olang_scope_close(ptr %s0)
  %t425 = load { %"compiler/cond:Value", i1 }, ptr %l209
  %t426 = insertvalue { i32, { %"compiler/cond:Value", i1 } } zeroinitializer, { %"compiler/cond:Value", i1 } %t425, 1
  store { i32, { %"compiler/cond:Value", i1 } } %t426, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { %"compiler/cond:Value", i1 } }, ptr %rv
  ret { i32, { %"compiler/cond:Value", i1 } } %rr
}

define dso_local i64 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2etext(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/cond:Consts", ptr %t2, i32 0, i32 6
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t4, ptr %l4, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t5 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 1
  %t7 = extractvalue { i64, ptr } %t5, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = load ptr, ptr %s1
  %t9 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t10 = load i64, ptr %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t10)
  call void @llvm.memcpy.p0.p0.i64(ptr %t11, ptr %t8, i64 %t10, i1 false)
  %t12 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  store { i64, ptr } %t13, ptr %l5, !tbaa !27
  call void @__olang_sb_done(ptr %s1)
  %t14 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t14, 0
  %t16 = extractvalue { i64, ptr } %t14, 1
  %t17 = mul i64 %t15, 1
  %t18 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t16, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l6, !tbaa !27
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t22 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v0, ptr %t21, { i64, ptr } %t22)
  br label %bb1
bb1:
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l7, !tbaa !29
  %t24 = load ptr, ptr %l7, !tbaa !29
  %t25 = getelementptr %"compiler/cond:Consts", ptr %t24, i32 0, i32 6
  store ptr %t25, ptr %l8, !tbaa !29
  %t26 = load ptr, ptr %l8, !tbaa !29
  %t27 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %t26)
  store i64 %t27, ptr %l9
  br label %bb2
bb2:
  %t28 = load i64, ptr %l9, !tbaa !24
  %t29 = sub i64 %t28, 1
  store i64 %t29, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  %t30 = load i64, ptr %l10, !tbaa !24
  store i64 %t30, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { %"compiler/source:Span", %"compiler/msgs:Msg" } @compiler_2fcond_2ecompiler_2fcond_3aEval_2eError(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca %"compiler/msgs:Msg"
  %l5 = alloca { %"compiler/source:Span", %"compiler/msgs:Msg" }
  %s0 = alloca %olang.scope
  %rv = alloca { %"compiler/source:Span", %"compiler/msgs:Msg" }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l1, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/cond:Eval", ptr %t2, i32 0, i32 7
  %t4 = load %"compiler/source:Span", ptr %t3
  store %"compiler/source:Span" %t4, ptr %l2
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t7 = getelementptr %"compiler/cond:Eval", ptr %t6, i32 0, i32 8
  %t8 = load %"compiler/msgs:Msg", ptr %t7
  store %"compiler/msgs:Msg" %t8, ptr %l4
  %t9 = load %"compiler/source:Span", ptr %l2
  %t10 = insertvalue { %"compiler/source:Span", %"compiler/msgs:Msg" } undef, %"compiler/source:Span" %t9, 0
  %t11 = load %"compiler/msgs:Msg", ptr %l4
  %t12 = insertvalue { %"compiler/source:Span", %"compiler/msgs:Msg" } %t10, %"compiler/msgs:Msg" %t11, 1
  store { %"compiler/source:Span", %"compiler/msgs:Msg" } %t12, ptr %l5
  call void @__olang_scope_close(ptr %s0)
  %t13 = load { %"compiler/source:Span", %"compiler/msgs:Msg" }, ptr %l5
  store { %"compiler/source:Span", %"compiler/msgs:Msg" } %t13, ptr %rv
  br label %ret
ret:
  %rr = load { %"compiler/source:Span", %"compiler/msgs:Msg" }, ptr %rv
  ret { %"compiler/source:Span", %"compiler/msgs:Msg" } %rr
}

define dso_local { i32, i1 } @compiler_2fcond_2ecompiler_2fcond_3aEval_2eLocal(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/cond:Value"
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca %"compiler/cond:Value"
  %l6 = alloca ptr
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i1
  %l14 = alloca i32
  %l15 = alloca { i32, i1 }
  %l16 = alloca ptr
  %l17 = alloca i1
  %l18 = alloca i32
  %l19 = alloca i32
  %l20 = alloca i32
  %l21 = alloca { i32, i1 }
  %l22 = alloca i32
  %l23 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca ptr
  %l26 = alloca i1
  %l27 = alloca i1
  %l28 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %l31 = alloca i1
  %l32 = alloca i32
  %l33 = alloca { i32, i1 }
  %l34 = alloca i32
  %l35 = alloca i64
  %l36 = alloca i1
  %l37 = alloca { i32, i1 }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i32, i1 }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  store ptr %t2, ptr %l4, !tbaa !29
  %t3 = load ptr, ptr %l3, !tbaa !29
  %t4 = load ptr, ptr %l4, !tbaa !29
  %t5 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eexpr(ptr %v0, ptr %v1, ptr %t3, ptr %t4)
  store %"compiler/cond:Value" %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load %"compiler/cond:Value", ptr %l5
  store %"compiler/cond:Value" %t6, ptr %l2
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l6, !tbaa !29
  %t8 = load ptr, ptr %l6, !tbaa !29
  %t9 = getelementptr %"compiler/cond:Eval", ptr %t8, i32 0, i32 4
  %t10 = load i1, ptr %t9, !tbaa !21
  store i1 %t10, ptr %l7, !tbaa !21
  %t11 = load i1, ptr %l7, !tbaa !21
  br i1 %t11, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t12 = load ptr, ptr %l0, !tbaa !29
  store ptr %t12, ptr %l8, !tbaa !29
  %t13 = load ptr, ptr %l8, !tbaa !29
  %t14 = getelementptr %"compiler/cond:Eval", ptr %t13, i32 0, i32 6
  %t15 = load i1, ptr %t14, !tbaa !21
  store i1 %t15, ptr %l9, !tbaa !21
  %t16 = load i1, ptr %l9, !tbaa !21
  br i1 %t16, label %bb4, label %bb5
bb3:
  br label %bb14
bb4:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb7
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  store ptr %t17, ptr %l11, !tbaa !29
  %t18 = load ptr, ptr %l1, !tbaa !29
  store ptr %t18, ptr %l12, !tbaa !29
  %t19 = load ptr, ptr %l11, !tbaa !29
  %t20 = load ptr, ptr %l12, !tbaa !29
  %t21 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2ementionsLocal(ptr %v0, ptr %v1, ptr %t19, ptr %t20)
  store i1 %t21, ptr %l13
  br label %bb6
bb6:
  %t22 = load i1, ptr %l13, !tbaa !21
  store i1 %t22, ptr %l10, !tbaa !21
  br label %bb7
bb7:
  %t23 = load i1, ptr %l10, !tbaa !21
  br i1 %t23, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  store i32 3, ptr %l14
  %t24 = load i32, ptr %l14
  %t25 = insertvalue { i32, i1 } undef, i32 %t24, 0
  %t26 = insertvalue { i32, i1 } %t25, i1 false, 1
  store { i32, i1 } %t26, ptr %l15
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t27 = load { i32, i1 }, ptr %l15
  store { i32, i1 } %t27, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l16, !tbaa !29
  %t29 = load ptr, ptr %l16, !tbaa !29
  %t30 = getelementptr %"compiler/cond:Eval", ptr %t29, i32 0, i32 5
  %t31 = load i1, ptr %t30, !tbaa !21
  store i1 %t31, ptr %l17, !tbaa !21
  %t32 = load i1, ptr %l17, !tbaa !21
  br i1 %t32, label %bb11, label %bb12
bb11:
  store i32 1, ptr %l19
  %t33 = load i32, ptr %l19
  store i32 %t33, ptr %l18
  br label %bb13
bb12:
  store i32 3, ptr %l20
  %t34 = load i32, ptr %l20
  store i32 %t34, ptr %l18
  br label %bb13
bb13:
  %t35 = load i32, ptr %l18
  %t36 = insertvalue { i32, i1 } undef, i32 %t35, 0
  %t37 = insertvalue { i32, i1 } %t36, i1 false, 1
  store { i32, i1 } %t37, ptr %l21
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t38 = load { i32, i1 }, ptr %l21
  store { i32, i1 } %t38, ptr %rv
  br label %ret
bb14:
  %t39 = getelementptr %"compiler/cond:Value", ptr %l2, i32 0, i32 0
  %t40 = load i32, ptr %t39
  store i32 %t40, ptr %l22
  store ptr %l22, ptr %l23, !tbaa !29
  store i32 1, ptr %l24
  store ptr %l24, ptr %l25, !tbaa !29
  %t41 = load ptr, ptr %l23, !tbaa !29
  %t42 = load ptr, ptr %l25, !tbaa !29
  %t43 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %t41, ptr %t42)
  store i1 %t43, ptr %l26
  br label %bb15
bb15:
  %t44 = load i1, ptr %l26, !tbaa !21
  %t45 = xor i1 %t44, true
  store i1 %t45, ptr %l27, !tbaa !21
  %t46 = load i1, ptr %l27, !tbaa !21
  br i1 %t46, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb18
bb17:
  %t47 = load ptr, ptr %l0, !tbaa !29
  store ptr %t47, ptr %l29, !tbaa !29
  %t48 = load ptr, ptr %l29, !tbaa !29
  %t49 = getelementptr %"compiler/cond:Eval", ptr %t48, i32 0, i32 11
  %t50 = load i1, ptr %t49, !tbaa !21
  store i1 %t50, ptr %l30, !tbaa !21
  %t51 = load i1, ptr %l30, !tbaa !21
  %t52 = xor i1 %t51, true
  store i1 %t52, ptr %l31, !tbaa !21
  %t53 = load i1, ptr %l31, !tbaa !21
  store i1 %t53, ptr %l28, !tbaa !21
  br label %bb18
bb18:
  %t54 = load i1, ptr %l28, !tbaa !21
  br i1 %t54, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  store i32 3, ptr %l32
  %t55 = load i32, ptr %l32
  %t56 = insertvalue { i32, i1 } undef, i32 %t55, 0
  %t57 = insertvalue { i32, i1 } %t56, i1 false, 1
  store { i32, i1 } %t57, ptr %l33
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t58 = load { i32, i1 }, ptr %l33
  store { i32, i1 } %t58, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  store i32 0, ptr %l34
  %t59 = getelementptr %"compiler/cond:Value", ptr %l2, i32 0, i32 1
  %t60 = load i64, ptr %t59, !tbaa !24
  store i64 %t60, ptr %l35, !tbaa !24
  %t61 = load i64, ptr %l35, !tbaa !24
  %t62 = icmp ne i64 %t61, 0
  store i1 %t62, ptr %l36, !tbaa !21
  %t63 = load i32, ptr %l34
  %t64 = insertvalue { i32, i1 } undef, i32 %t63, 0
  %t65 = load i1, ptr %l36, !tbaa !21
  %t66 = insertvalue { i32, i1 } %t64, i1 %t65, 1
  store { i32, i1 } %t66, ptr %l37
  call void @__olang_scope_close(ptr %s0)
  %t67 = load { i32, i1 }, ptr %l37
  store { i32, i1 } %t67, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i1 }, ptr %rv
  ret { i32, i1 } %rr
}

define dso_local { i32, i1 } @compiler_2fcond_2ecompiler_2fcond_3aEval_2eTop(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/cond:Value"
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca %"compiler/cond:Value"
  %l6 = alloca ptr
  %l7 = alloca i1
  %l8 = alloca i1
  %l9 = alloca i1
  %l10 = alloca i32
  %l11 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca i1
  %l15 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca %"compiler/source:Span"
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca %"compiler/source:Span"
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca %"compiler/msgs:Msg"
  %l27 = alloca %"compiler/cond:Value"
  %l28 = alloca ptr
  %l29 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i1
  %l32 = alloca i32
  %l33 = alloca i32
  %l34 = alloca i32
  %l35 = alloca { i32, i1 }
  %l36 = alloca i32
  %l37 = alloca i64
  %l38 = alloca i1
  %l39 = alloca { i32, i1 }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i32, i1 }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  store ptr %t2, ptr %l4, !tbaa !29
  %t3 = load ptr, ptr %l3, !tbaa !29
  %t4 = load ptr, ptr %l4, !tbaa !29
  %t5 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eexpr(ptr %v0, ptr %v1, ptr %t3, ptr %t4)
  store %"compiler/cond:Value" %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load %"compiler/cond:Value", ptr %l5
  store %"compiler/cond:Value" %t6, ptr %l2
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l6, !tbaa !29
  %t8 = load ptr, ptr %l6, !tbaa !29
  %t9 = getelementptr %"compiler/cond:Eval", ptr %t8, i32 0, i32 4
  %t10 = load i1, ptr %t9, !tbaa !21
  store i1 %t10, ptr %l7, !tbaa !21
  %t11 = load i1, ptr %l7, !tbaa !21
  %t12 = xor i1 %t11, true
  store i1 %t12, ptr %l8, !tbaa !21
  %t13 = load i1, ptr %l8, !tbaa !21
  br i1 %t13, label %bb2, label %bb3
bb2:
  %t14 = getelementptr %"compiler/cond:Value", ptr %l2, i32 0, i32 0
  %t15 = load i32, ptr %t14
  store i32 %t15, ptr %l10
  store ptr %l10, ptr %l11, !tbaa !29
  store i32 1, ptr %l12
  store ptr %l12, ptr %l13, !tbaa !29
  %t16 = load ptr, ptr %l11, !tbaa !29
  %t17 = load ptr, ptr %l13, !tbaa !29
  %t18 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %t16, ptr %t17)
  store i1 %t18, ptr %l14
  br label %bb4
bb3:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb5
bb4:
  %t19 = load i1, ptr %l14, !tbaa !21
  %t20 = xor i1 %t19, true
  store i1 %t20, ptr %l15, !tbaa !21
  %t21 = load i1, ptr %l15, !tbaa !21
  store i1 %t21, ptr %l9, !tbaa !21
  br label %bb5
bb5:
  %t22 = load i1, ptr %l9, !tbaa !21
  br i1 %t22, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l16, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l17, !tbaa !29
  %t25 = load ptr, ptr %l1, !tbaa !29
  store ptr %t25, ptr %l18, !tbaa !29
  %t26 = load ptr, ptr %l17, !tbaa !29
  %t27 = load ptr, ptr %l18, !tbaa !29
  %t28 = call %"compiler/source:Span" @compiler_2fcond_2ecompiler_2fcond_3aEval_2efirst(ptr %v0, ptr %v1, ptr %t26, ptr %t27)
  store %"compiler/source:Span" %t28, ptr %l19
  br label %bb8
bb7:
  br label %bb13
bb8:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l20, !tbaa !29
  %t30 = load ptr, ptr %l0, !tbaa !29
  store ptr %t30, ptr %l21, !tbaa !29
  %t31 = load ptr, ptr %l1, !tbaa !29
  store ptr %t31, ptr %l22, !tbaa !29
  %t32 = load ptr, ptr %l21, !tbaa !29
  %t33 = load ptr, ptr %l22, !tbaa !29
  %t34 = call %"compiler/source:Span" @compiler_2fcond_2ecompiler_2fcond_3aEval_2efirst(ptr %v0, ptr %v1, ptr %t32, ptr %t33)
  store %"compiler/source:Span" %t34, ptr %l23
  br label %bb9
bb9:
  %t35 = load ptr, ptr %l20, !tbaa !29
  %t36 = load %"compiler/source:Span", ptr %l23
  %t37 = call { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aEval_2etokText(ptr %v0, ptr %v0, ptr %t35, %"compiler/source:Span" %t36)
  store { i64, ptr } %t37, ptr %l24
  br label %bb10
bb10:
  %t38 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 0
  %t40 = extractvalue { i64, ptr } %t38, 1
  %t41 = mul i64 %t39, 1
  %t42 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t41)
  call void @llvm.memcpy.p0.p0.i64(ptr %t42, ptr %t40, i64 %t41, i1 false)
  %t43 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t42, 1
  store { i64, ptr } %t44, ptr %l25, !tbaa !27
  %t45 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t46 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondNotBool(ptr %v0, ptr %v0, { i64, ptr } %t45)
  store %"compiler/msgs:Msg" %t46, ptr %l26
  br label %bb11
bb11:
  %t47 = load ptr, ptr %l16, !tbaa !29
  %t48 = load %"compiler/source:Span", ptr %l19
  %t49 = load %"compiler/msgs:Msg", ptr %l26
  %t50 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2efail(ptr %v0, ptr %v0, ptr %t47, %"compiler/source:Span" %t48, %"compiler/msgs:Msg" %t49)
  store %"compiler/cond:Value" %t50, ptr %l27
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s1)
  br label %bb13
bb13:
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l28, !tbaa !29
  %t52 = load ptr, ptr %l28, !tbaa !29
  %t53 = getelementptr %"compiler/cond:Eval", ptr %t52, i32 0, i32 4
  %t54 = load i1, ptr %t53, !tbaa !21
  store i1 %t54, ptr %l29, !tbaa !21
  %t55 = load i1, ptr %l29, !tbaa !21
  br i1 %t55, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s2
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l30, !tbaa !29
  %t57 = load ptr, ptr %l30, !tbaa !29
  %t58 = getelementptr %"compiler/cond:Eval", ptr %t57, i32 0, i32 5
  %t59 = load i1, ptr %t58, !tbaa !21
  store i1 %t59, ptr %l31, !tbaa !21
  %t60 = load i1, ptr %l31, !tbaa !21
  br i1 %t60, label %bb16, label %bb17
bb15:
  br label %bb19
bb16:
  store i32 1, ptr %l33
  %t61 = load i32, ptr %l33
  store i32 %t61, ptr %l32
  br label %bb18
bb17:
  store i32 2, ptr %l34
  %t62 = load i32, ptr %l34
  store i32 %t62, ptr %l32
  br label %bb18
bb18:
  %t63 = load i32, ptr %l32
  %t64 = insertvalue { i32, i1 } undef, i32 %t63, 0
  %t65 = insertvalue { i32, i1 } %t64, i1 false, 1
  store { i32, i1 } %t65, ptr %l35
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t66 = load { i32, i1 }, ptr %l35
  store { i32, i1 } %t66, ptr %rv
  br label %ret
bb19:
  store i32 0, ptr %l36
  %t67 = getelementptr %"compiler/cond:Value", ptr %l2, i32 0, i32 1
  %t68 = load i64, ptr %t67, !tbaa !24
  store i64 %t68, ptr %l37, !tbaa !24
  %t69 = load i64, ptr %l37, !tbaa !24
  %t70 = icmp ne i64 %t69, 0
  store i1 %t70, ptr %l38, !tbaa !21
  %t71 = load i32, ptr %l36
  %t72 = insertvalue { i32, i1 } undef, i32 %t71, 0
  %t73 = load i1, ptr %l38, !tbaa !21
  %t74 = insertvalue { i32, i1 } %t72, i1 %t73, 1
  store { i32, i1 } %t74, ptr %l39
  call void @__olang_scope_close(ptr %s0)
  %t75 = load { i32, i1 }, ptr %l39
  store { i32, i1 } %t75, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i1 }, ptr %rv
  ret { i32, i1 } %rr
}

define dso_local i64 @compiler_2fcond_2ecompiler_2fcond_3aEval_2eaddText(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/cond:Eval", ptr %t2, i32 0, i32 12
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t4, ptr %l4, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t5 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 1
  %t7 = extractvalue { i64, ptr } %t5, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = load ptr, ptr %s1
  %t9 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t10 = load i64, ptr %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t10)
  call void @llvm.memcpy.p0.p0.i64(ptr %t11, ptr %t8, i64 %t10, i1 false)
  %t12 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  store { i64, ptr } %t13, ptr %l5, !tbaa !27
  call void @__olang_sb_done(ptr %s1)
  %t14 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t14, 0
  %t16 = extractvalue { i64, ptr } %t14, 1
  %t17 = mul i64 %t15, 1
  %t18 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t16, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l6, !tbaa !27
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t22 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v0, ptr %t21, { i64, ptr } %t22)
  br label %bb1
bb1:
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l7, !tbaa !29
  %t24 = load ptr, ptr %l7, !tbaa !29
  %t25 = getelementptr %"compiler/cond:Eval", ptr %t24, i32 0, i32 12
  store ptr %t25, ptr %l8, !tbaa !29
  %t26 = load ptr, ptr %l8, !tbaa !29
  %t27 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %t26)
  store i64 %t27, ptr %l9
  br label %bb2
bb2:
  %t28 = load i64, ptr %l9, !tbaa !24
  %t29 = sub i64 %t28, 1
  store i64 %t29, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  %t30 = load i64, ptr %l10, !tbaa !24
  store i64 %t30, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2eanyLocal(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i1
  %l12 = alloca i1
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i1
  %l19 = alloca i1
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t1, ptr %l6, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t2, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t3, ptr %l7, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t4, 0
  store i64 %t5, ptr %l8, !tbaa !24
  %t6 = load i64, ptr %l8, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l3, !tbaa !24
  store i64 %t7, ptr %l9, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  store i64 %t8, ptr %l10, !tbaa !24
  %t9 = load i64, ptr %l9, !tbaa !24
  %t10 = load i64, ptr %l10, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  store i1 %t11, ptr %l11, !tbaa !21
  %t12 = load i1, ptr %l11, !tbaa !21
  %t13 = xor i1 %t12, true
  store i1 %t13, ptr %l12, !tbaa !21
  %t14 = load i1, ptr %l12, !tbaa !21
  br i1 %t14, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l13, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  store i64 %t16, ptr %l14, !tbaa !24
  %t17 = load i64, ptr %l14, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t17
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l15, !tbaa !29
  %t22 = load ptr, ptr %l15, !tbaa !29
  store ptr %t22, ptr %l5, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l16, !tbaa !29
  %t24 = load ptr, ptr %l5, !tbaa !29
  store ptr %t24, ptr %l17, !tbaa !29
  %t25 = load ptr, ptr %l16, !tbaa !29
  %t26 = load ptr, ptr %l17, !tbaa !29
  %t27 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2ementionsLocal(ptr %v0, ptr %v1, ptr %t25, ptr %t26)
  store i1 %t27, ptr %l18
  br label %bb5
bb5:
  %t28 = load i1, ptr %l18, !tbaa !21
  br i1 %t28, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  store i1 true, ptr %l19, !tbaa !21
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t29 = load i1, ptr %l19, !tbaa !21
  store i1 %t29, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s4
  %t30 = load i64, ptr %l3, !tbaa !24
  store i64 %t30, ptr %l20, !tbaa !24
  %t31 = load i64, ptr %l20, !tbaa !24
  %t32 = add i64 %t31, 1
  store i64 %t32, ptr %l21, !tbaa !24
  %t33 = load i64, ptr %l21, !tbaa !24
  store i64 %t33, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb1
bb10:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %l22, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  %t34 = load i1, ptr %l22, !tbaa !21
  store i1 %t34, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2earith(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, %"compiler/cond:Value" %a3, %"compiler/cond:Value" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca %"compiler/cond:Value"
  %l4 = alloca %"compiler/cond:Value"
  %l5 = alloca { i1, i64, i1 }
  %l6 = alloca i1
  %l7 = alloca i64
  %l8 = alloca i1
  %l9 = alloca i64
  %l10 = alloca i1
  %l11 = alloca double
  %l12 = alloca double
  %l13 = alloca { i1, double }
  %l14 = alloca i1
  %l15 = alloca double
  %l16 = alloca { i1, double }
  %l17 = alloca i1
  %l18 = alloca double
  %l19 = alloca i64
  %l20 = alloca double
  %l21 = alloca i32
  %l22 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca ptr
  %l25 = alloca i1
  %l26 = alloca i1
  %l27 = alloca i32
  %l28 = alloca ptr
  %l29 = alloca i32
  %l30 = alloca ptr
  %l31 = alloca i1
  %l32 = alloca %"compiler/cond:Value"
  %l33 = alloca %"compiler/cond:Value"
  %l34 = alloca i1
  %l35 = alloca i1
  %l36 = alloca i1
  %l37 = alloca %"compiler/cond:Value"
  %l38 = alloca i1
  %l39 = alloca i1
  %l40 = alloca ptr
  %l41 = alloca %"compiler/source:Span"
  %l42 = alloca ptr
  %l43 = alloca %"compiler/source:Span"
  %l44 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca %"compiler/msgs:Msg"
  %l47 = alloca %"compiler/cond:Value"
  %l48 = alloca i32
  %l49 = alloca ptr
  %l50 = alloca i32
  %l51 = alloca ptr
  %l52 = alloca i1
  %l53 = alloca i1
  %l54 = alloca i32
  %l55 = alloca ptr
  %l56 = alloca i32
  %l57 = alloca ptr
  %l58 = alloca i1
  %l59 = alloca %"compiler/cond:Value"
  %l60 = alloca %"compiler/cond:Value"
  %l61 = alloca { i1, i64, i1 }
  %l62 = alloca i1
  %l63 = alloca i64
  %l64 = alloca i1
  %l65 = alloca i1
  %l66 = alloca i1
  %l67 = alloca ptr
  %l68 = alloca %"compiler/source:Span"
  %l69 = alloca ptr
  %l70 = alloca %"compiler/source:Span"
  %l71 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l73 = alloca %"compiler/msgs:Msg"
  %l74 = alloca %"compiler/cond:Value"
  %l75 = alloca i32
  %l76 = alloca i1
  %l77 = alloca i64
  %l78 = alloca i64
  %l79 = alloca i64
  %l80 = alloca i64
  %l81 = alloca i1
  %l82 = alloca i1
  %l83 = alloca i64
  %l84 = alloca i64
  %l85 = alloca i1
  %l86 = alloca i1
  %l87 = alloca i64
  %l88 = alloca i1
  %l89 = alloca i1
  %l90 = alloca i64
  %l91 = alloca i64
  %l92 = alloca i1
  %l93 = alloca i32
  %l94 = alloca i1
  %l95 = alloca i64
  %l96 = alloca i64
  %l97 = alloca i64
  %l98 = alloca i64
  %l99 = alloca i1
  %l100 = alloca i1
  %l101 = alloca i64
  %l102 = alloca i64
  %l103 = alloca i1
  %l104 = alloca i1
  %l105 = alloca i64
  %l106 = alloca i1
  %l107 = alloca i1
  %l108 = alloca i64
  %l109 = alloca i64
  %l110 = alloca i1
  %l111 = alloca i32
  %l112 = alloca i1
  %l113 = alloca i64
  %l114 = alloca i64
  %l115 = alloca i64
  %l116 = alloca i64
  %l117 = alloca i1
  %l118 = alloca i1
  %l119 = alloca i64
  %l120 = alloca i64
  %l121 = alloca i64
  %l122 = alloca i64
  %l123 = alloca i1
  %l124 = alloca i1
  %l125 = alloca i64
  %l126 = alloca i1
  %l127 = alloca i1
  %l128 = alloca i64
  %l129 = alloca i1
  %l130 = alloca i64
  %l131 = alloca i1
  %l132 = alloca i1
  %l133 = alloca i64
  %l134 = alloca i1
  %l135 = alloca i1
  %l136 = alloca i64
  %l137 = alloca i1
  %l138 = alloca ptr
  %l139 = alloca %"compiler/source:Span"
  %l140 = alloca %"compiler/cond:Value"
  %l141 = alloca i32
  %l142 = alloca ptr
  %l143 = alloca i32
  %l144 = alloca ptr
  %l145 = alloca i1
  %l146 = alloca i64
  %l147 = alloca i64
  %l148 = alloca i64
  %l149 = alloca i64
  %l150 = alloca i64
  %l151 = alloca i64
  %l152 = alloca i64
  %l153 = alloca i1
  %l154 = alloca i1
  %l155 = alloca i64
  %l156 = alloca i64
  %l157 = alloca i1
  %l158 = alloca i64
  %l159 = alloca i64
  %l160 = alloca i64
  %l161 = alloca i1
  %l162 = alloca i1
  %l163 = alloca i1
  %l164 = alloca ptr
  %l165 = alloca %"compiler/source:Span"
  %l166 = alloca %"compiler/cond:Value"
  %l167 = alloca i32
  %l168 = alloca i64
  %l169 = alloca i64
  %l170 = alloca i1
  %l171 = alloca %"compiler/cond:Value"
  %l172 = alloca i32
  %l173 = alloca ptr
  %l174 = alloca i32
  %l175 = alloca ptr
  %l176 = alloca i1
  %l177 = alloca i1
  %l178 = alloca i64
  %l179 = alloca i1
  %l180 = alloca i1
  %l181 = alloca i32
  %l182 = alloca ptr
  %l183 = alloca i32
  %l184 = alloca ptr
  %l185 = alloca i1
  %l186 = alloca i1
  %l187 = alloca i64
  %l188 = alloca i1
  %l189 = alloca ptr
  %l190 = alloca %"compiler/source:Span"
  %l191 = alloca ptr
  %l192 = alloca %"compiler/source:Span"
  %l193 = alloca { i64, ptr }
  %l194 = alloca { i64, ptr }
  %l195 = alloca %"compiler/msgs:Msg"
  %l196 = alloca %"compiler/cond:Value"
  %l197 = alloca double
  %l198 = alloca double
  %l199 = alloca i32
  %l200 = alloca ptr
  %l201 = alloca i32
  %l202 = alloca ptr
  %l203 = alloca i1
  %l204 = alloca %"compiler/cond:Value"
  %l205 = alloca { i1, double }
  %l206 = alloca i1
  %l207 = alloca double
  %l208 = alloca i1
  %l209 = alloca i1
  %l210 = alloca ptr
  %l211 = alloca %"compiler/source:Span"
  %l212 = alloca %"compiler/cond:Value"
  %l213 = alloca double
  %l214 = alloca i32
  %l215 = alloca ptr
  %l216 = alloca i32
  %l217 = alloca ptr
  %l218 = alloca i1
  %l219 = alloca %"compiler/cond:Value"
  %l220 = alloca { i1, double }
  %l221 = alloca i1
  %l222 = alloca double
  %l223 = alloca i1
  %l224 = alloca i1
  %l225 = alloca ptr
  %l226 = alloca %"compiler/source:Span"
  %l227 = alloca %"compiler/cond:Value"
  %l228 = alloca double
  %l229 = alloca i32
  %l230 = alloca ptr
  %l231 = alloca i32
  %l232 = alloca ptr
  %l233 = alloca i1
  %l234 = alloca ptr
  %l235 = alloca %"compiler/source:Span"
  %l236 = alloca %"compiler/cond:Value"
  %l237 = alloca i64
  %l238 = alloca i1
  %l239 = alloca i1
  %l240 = alloca i64
  %l241 = alloca i1
  %l242 = alloca i64
  %l243 = alloca i32
  %l244 = alloca ptr
  %l245 = alloca i32
  %l246 = alloca ptr
  %l247 = alloca i1
  %l248 = alloca double
  %l249 = alloca double
  %l250 = alloca double
  %l251 = alloca double
  %l252 = alloca i32
  %l253 = alloca ptr
  %l254 = alloca i32
  %l255 = alloca ptr
  %l256 = alloca i1
  %l257 = alloca double
  %l258 = alloca double
  %l259 = alloca double
  %l260 = alloca double
  %l261 = alloca i32
  %l262 = alloca ptr
  %l263 = alloca i32
  %l264 = alloca ptr
  %l265 = alloca i1
  %l266 = alloca double
  %l267 = alloca double
  %l268 = alloca double
  %l269 = alloca double
  %l270 = alloca double
  %l271 = alloca double
  %l272 = alloca double
  %l273 = alloca i32
  %l274 = alloca double
  %l275 = alloca i64
  %l276 = alloca %"compiler/cond:Value"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %rv = alloca %"compiler/cond:Value"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/cond:Value" %a3, ptr %l3
  store %"compiler/cond:Value" %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 0
  %t2 = load i32, ptr %t1
  store i32 %t2, ptr %l21
  store ptr %l21, ptr %l22, !tbaa !29
  store i32 0, ptr %l23
  store ptr %l23, ptr %l24, !tbaa !29
  %t3 = load ptr, ptr %l22, !tbaa !29
  %t4 = load ptr, ptr %l24, !tbaa !29
  %t5 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %t3, ptr %t4)
  store i1 %t5, ptr %l25
  br label %bb1
bb1:
  %t6 = load i1, ptr %l25, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb5
bb3:
  %t7 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l27
  store ptr %l27, ptr %l28, !tbaa !29
  store i32 0, ptr %l29
  store ptr %l29, ptr %l30, !tbaa !29
  %t9 = load ptr, ptr %l28, !tbaa !29
  %t10 = load ptr, ptr %l30, !tbaa !29
  %t11 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %t9, ptr %t10)
  store i1 %t11, ptr %l31
  br label %bb4
bb4:
  %t12 = load i1, ptr %l31, !tbaa !21
  store i1 %t12, ptr %l26, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l26, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t14 = call %"compiler/cond:Value" @compiler_2fcond_2enone()
  store %"compiler/cond:Value" %t14, ptr %l32
  br label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t15 = load %"compiler/cond:Value", ptr %l32
  store %"compiler/cond:Value" %t15, ptr %rv
  br label %ret
bb9:
  %t16 = load %"compiler/cond:Value", ptr %l3
  store %"compiler/cond:Value" %t16, ptr %l33
  %t17 = load %"compiler/cond:Value", ptr %l33
  %t18 = call i1 @compiler_2fcond_2enumeric(%"compiler/cond:Value" %t17)
  store i1 %t18, ptr %l34
  br label %bb10
bb10:
  %t19 = load i1, ptr %l34, !tbaa !21
  %t20 = xor i1 %t19, true
  store i1 %t20, ptr %l35, !tbaa !21
  %t21 = load i1, ptr %l35, !tbaa !21
  br i1 %t21, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb14
bb12:
  %t22 = load %"compiler/cond:Value", ptr %l4
  store %"compiler/cond:Value" %t22, ptr %l37
  %t23 = load %"compiler/cond:Value", ptr %l37
  %t24 = call i1 @compiler_2fcond_2enumeric(%"compiler/cond:Value" %t23)
  store i1 %t24, ptr %l38
  br label %bb13
bb13:
  %t25 = load i1, ptr %l38, !tbaa !21
  %t26 = xor i1 %t25, true
  store i1 %t26, ptr %l39, !tbaa !21
  %t27 = load i1, ptr %l39, !tbaa !21
  store i1 %t27, ptr %l36, !tbaa !21
  br label %bb14
bb14:
  %t28 = load i1, ptr %l36, !tbaa !21
  br i1 %t28, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l40, !tbaa !29
  %t30 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t30, ptr %l41
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l42, !tbaa !29
  %t32 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t32, ptr %l43
  %t33 = load ptr, ptr %l42, !tbaa !29
  %t34 = load %"compiler/source:Span", ptr %l43
  %t35 = call { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aEval_2etokText(ptr %v0, ptr %v0, ptr %t33, %"compiler/source:Span" %t34)
  store { i64, ptr } %t35, ptr %l44
  br label %bb17
bb16:
  br label %bb20
bb17:
  %t36 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t36, 0
  %t38 = extractvalue { i64, ptr } %t36, 1
  %t39 = mul i64 %t37, 1
  %t40 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t39)
  call void @llvm.memcpy.p0.p0.i64(ptr %t40, ptr %t38, i64 %t39, i1 false)
  %t41 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  store { i64, ptr } %t42, ptr %l45, !tbaa !27
  %t43 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t44 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondTypes(ptr %v0, ptr %v0, { i64, ptr } %t43)
  store %"compiler/msgs:Msg" %t44, ptr %l46
  br label %bb18
bb18:
  %t45 = load ptr, ptr %l40, !tbaa !29
  %t46 = load %"compiler/source:Span", ptr %l41
  %t47 = load %"compiler/msgs:Msg", ptr %l46
  %t48 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2efail(ptr %v0, ptr %v0, ptr %t45, %"compiler/source:Span" %t46, %"compiler/msgs:Msg" %t47)
  store %"compiler/cond:Value" %t48, ptr %l47
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t49 = load %"compiler/cond:Value", ptr %l47
  store %"compiler/cond:Value" %t49, ptr %rv
  br label %ret
bb20:
  %t50 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 0
  %t51 = load i32, ptr %t50
  store i32 %t51, ptr %l48
  store ptr %l48, ptr %l49, !tbaa !29
  store i32 2, ptr %l50
  store ptr %l50, ptr %l51, !tbaa !29
  %t52 = load ptr, ptr %l49, !tbaa !29
  %t53 = load ptr, ptr %l51, !tbaa !29
  %t54 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %t52, ptr %t53)
  store i1 %t54, ptr %l52
  br label %bb21
bb21:
  %t55 = load i1, ptr %l52, !tbaa !21
  br i1 %t55, label %bb22, label %bb23
bb22:
  %t56 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 0
  %t57 = load i32, ptr %t56
  store i32 %t57, ptr %l54
  store ptr %l54, ptr %l55, !tbaa !29
  store i32 2, ptr %l56
  store ptr %l56, ptr %l57, !tbaa !29
  %t58 = load ptr, ptr %l55, !tbaa !29
  %t59 = load ptr, ptr %l57, !tbaa !29
  %t60 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %t58, ptr %t59)
  store i1 %t60, ptr %l58
  br label %bb24
bb23:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb25
bb24:
  %t61 = load i1, ptr %l58, !tbaa !21
  store i1 %t61, ptr %l53, !tbaa !21
  br label %bb25
bb25:
  %t62 = load i1, ptr %l53, !tbaa !21
  br i1 %t62, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s3
  %t63 = load %"compiler/cond:Value", ptr %l3
  store %"compiler/cond:Value" %t63, ptr %l59
  %t64 = load %"compiler/cond:Value", ptr %l4
  store %"compiler/cond:Value" %t64, ptr %l60
  %t65 = load %"compiler/cond:Value", ptr %l59
  %t66 = load %"compiler/cond:Value", ptr %l60
  %t67 = call { i1, i64, i1 } @compiler_2fcond_2emeet(%"compiler/cond:Value" %t65, %"compiler/cond:Value" %t66)
  store { i1, i64, i1 } %t67, ptr %l61
  br label %bb28
bb27:
  br label %bb101
bb28:
  %t68 = load { i1, i64, i1 }, ptr %l61
  store { i1, i64, i1 } %t68, ptr %l5
  %t69 = getelementptr { i1, i64, i1 }, ptr %l5, i32 0, i32 0
  %t70 = load i1, ptr %t69, !tbaa !21
  store i1 %t70, ptr %l62, !tbaa !21
  %t71 = load i1, ptr %l62, !tbaa !21
  store i1 %t71, ptr %l6, !tbaa !21
  %t72 = getelementptr { i1, i64, i1 }, ptr %l5, i32 0, i32 1
  %t73 = load i64, ptr %t72, !tbaa !24
  store i64 %t73, ptr %l63, !tbaa !24
  %t74 = load i64, ptr %l63, !tbaa !24
  store i64 %t74, ptr %l7, !tbaa !24
  %t75 = getelementptr { i1, i64, i1 }, ptr %l5, i32 0, i32 2
  %t76 = load i1, ptr %t75, !tbaa !21
  store i1 %t76, ptr %l64, !tbaa !21
  %t77 = load i1, ptr %l64, !tbaa !21
  store i1 %t77, ptr %l8, !tbaa !21
  %t78 = load i1, ptr %l6, !tbaa !21
  store i1 %t78, ptr %l65, !tbaa !21
  %t79 = load i1, ptr %l65, !tbaa !21
  %t80 = xor i1 %t79, true
  store i1 %t80, ptr %l66, !tbaa !21
  %t81 = load i1, ptr %l66, !tbaa !21
  br i1 %t81, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s4
  %t82 = load ptr, ptr %l0, !tbaa !29
  store ptr %t82, ptr %l67, !tbaa !29
  %t83 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t83, ptr %l68
  %t84 = load ptr, ptr %l0, !tbaa !29
  store ptr %t84, ptr %l69, !tbaa !29
  %t85 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t85, ptr %l70
  %t86 = load ptr, ptr %l69, !tbaa !29
  %t87 = load %"compiler/source:Span", ptr %l70
  %t88 = call { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aEval_2etokText(ptr %v0, ptr %v0, ptr %t86, %"compiler/source:Span" %t87)
  store { i64, ptr } %t88, ptr %l71
  br label %bb31
bb30:
  br label %bb34
bb31:
  %t89 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t89, 0
  %t91 = extractvalue { i64, ptr } %t89, 1
  %t92 = mul i64 %t90, 1
  %t93 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t92)
  call void @llvm.memcpy.p0.p0.i64(ptr %t93, ptr %t91, i64 %t92, i1 false)
  %t94 = insertvalue { i64, ptr } undef, i64 %t90, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t93, 1
  store { i64, ptr } %t95, ptr %l72, !tbaa !27
  %t96 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t97 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondNoMeet(ptr %v0, ptr %v0, { i64, ptr } %t96)
  store %"compiler/msgs:Msg" %t97, ptr %l73
  br label %bb32
bb32:
  %t98 = load ptr, ptr %l67, !tbaa !29
  %t99 = load %"compiler/source:Span", ptr %l68
  %t100 = load %"compiler/msgs:Msg", ptr %l73
  %t101 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2efail(ptr %v0, ptr %v0, ptr %t98, %"compiler/source:Span" %t99, %"compiler/msgs:Msg" %t100)
  store %"compiler/cond:Value" %t101, ptr %l74
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t102 = load %"compiler/cond:Value", ptr %l74
  store %"compiler/cond:Value" %t102, ptr %rv
  br label %ret
bb34:
  store i64 0, ptr %l9, !tbaa !24
  store i1 false, ptr %l10, !tbaa !21
  %t103 = load i32, ptr %l2
  store i32 %t103, ptr %l75
  %t104 = load i32, ptr %l75
  %t105 = trunc i64 51 to i32
  %t106 = icmp eq i32 %t104, %t105
  store i1 %t106, ptr %l76, !tbaa !21
  %t107 = load i1, ptr %l76, !tbaa !21
  br i1 %t107, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb47
bb37:
  store %olang.scope zeroinitializer, ptr %s5
  %t108 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 1
  %t109 = load i64, ptr %t108, !tbaa !24
  store i64 %t109, ptr %l77, !tbaa !24
  %t110 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 1
  %t111 = load i64, ptr %t110, !tbaa !24
  store i64 %t111, ptr %l78, !tbaa !24
  %t112 = load i64, ptr %l77, !tbaa !24
  %t113 = load i64, ptr %l78, !tbaa !24
  %t114 = add i64 %t112, %t113
  store i64 %t114, ptr %l79, !tbaa !24
  %t115 = load i64, ptr %l79, !tbaa !24
  store i64 %t115, ptr %l9, !tbaa !24
  %t116 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 1
  %t117 = load i64, ptr %t116, !tbaa !24
  store i64 %t117, ptr %l80, !tbaa !24
  %t118 = load i64, ptr %l80, !tbaa !24
  %t119 = icmp sgt i64 %t118, 0
  store i1 %t119, ptr %l81, !tbaa !21
  %t120 = load i1, ptr %l81, !tbaa !21
  br i1 %t120, label %bb38, label %bb39
bb38:
  %t121 = load i64, ptr %l9, !tbaa !24
  store i64 %t121, ptr %l83, !tbaa !24
  %t122 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 1
  %t123 = load i64, ptr %t122, !tbaa !24
  store i64 %t123, ptr %l84, !tbaa !24
  %t124 = load i64, ptr %l83, !tbaa !24
  %t125 = load i64, ptr %l84, !tbaa !24
  %t126 = icmp slt i64 %t124, %t125
  store i1 %t126, ptr %l85, !tbaa !21
  %t127 = load i1, ptr %l85, !tbaa !21
  store i1 %t127, ptr %l82, !tbaa !21
  br label %bb40
bb39:
  store i1 false, ptr %l82, !tbaa !21
  br label %bb40
bb40:
  %t128 = load i1, ptr %l82, !tbaa !21
  br i1 %t128, label %bb41, label %bb42
bb41:
  store i1 true, ptr %l86, !tbaa !21
  br label %bb46
bb42:
  %t129 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 1
  %t130 = load i64, ptr %t129, !tbaa !24
  store i64 %t130, ptr %l87, !tbaa !24
  %t131 = load i64, ptr %l87, !tbaa !24
  %t132 = icmp slt i64 %t131, 0
  store i1 %t132, ptr %l88, !tbaa !21
  %t133 = load i1, ptr %l88, !tbaa !21
  br i1 %t133, label %bb43, label %bb44
bb43:
  %t134 = load i64, ptr %l9, !tbaa !24
  store i64 %t134, ptr %l90, !tbaa !24
  %t135 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 1
  %t136 = load i64, ptr %t135, !tbaa !24
  store i64 %t136, ptr %l91, !tbaa !24
  %t137 = load i64, ptr %l90, !tbaa !24
  %t138 = load i64, ptr %l91, !tbaa !24
  %t139 = icmp sgt i64 %t137, %t138
  store i1 %t139, ptr %l92, !tbaa !21
  %t140 = load i1, ptr %l92, !tbaa !21
  store i1 %t140, ptr %l89, !tbaa !21
  br label %bb45
bb44:
  store i1 false, ptr %l89, !tbaa !21
  br label %bb45
bb45:
  %t141 = load i1, ptr %l89, !tbaa !21
  store i1 %t141, ptr %l86, !tbaa !21
  br label %bb46
bb46:
  %t142 = load i1, ptr %l86, !tbaa !21
  store i1 %t142, ptr %l10, !tbaa !21
  call void @__olang_scope_close(ptr %s5)
  br label %bb88
bb47:
  %t143 = load i32, ptr %l2
  store i32 %t143, ptr %l93
  %t144 = load i32, ptr %l93
  %t145 = trunc i64 52 to i32
  %t146 = icmp eq i32 %t144, %t145
  store i1 %t146, ptr %l94, !tbaa !21
  %t147 = load i1, ptr %l94, !tbaa !21
  br i1 %t147, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb60
bb50:
  store %olang.scope zeroinitializer, ptr %s6
  %t148 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 1
  %t149 = load i64, ptr %t148, !tbaa !24
  store i64 %t149, ptr %l95, !tbaa !24
  %t150 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 1
  %t151 = load i64, ptr %t150, !tbaa !24
  store i64 %t151, ptr %l96, !tbaa !24
  %t152 = load i64, ptr %l95, !tbaa !24
  %t153 = load i64, ptr %l96, !tbaa !24
  %t154 = sub i64 %t152, %t153
  store i64 %t154, ptr %l97, !tbaa !24
  %t155 = load i64, ptr %l97, !tbaa !24
  store i64 %t155, ptr %l9, !tbaa !24
  %t156 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 1
  %t157 = load i64, ptr %t156, !tbaa !24
  store i64 %t157, ptr %l98, !tbaa !24
  %t158 = load i64, ptr %l98, !tbaa !24
  %t159 = icmp slt i64 %t158, 0
  store i1 %t159, ptr %l99, !tbaa !21
  %t160 = load i1, ptr %l99, !tbaa !21
  br i1 %t160, label %bb51, label %bb52
bb51:
  %t161 = load i64, ptr %l9, !tbaa !24
  store i64 %t161, ptr %l101, !tbaa !24
  %t162 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 1
  %t163 = load i64, ptr %t162, !tbaa !24
  store i64 %t163, ptr %l102, !tbaa !24
  %t164 = load i64, ptr %l101, !tbaa !24
  %t165 = load i64, ptr %l102, !tbaa !24
  %t166 = icmp slt i64 %t164, %t165
  store i1 %t166, ptr %l103, !tbaa !21
  %t167 = load i1, ptr %l103, !tbaa !21
  store i1 %t167, ptr %l100, !tbaa !21
  br label %bb53
bb52:
  store i1 false, ptr %l100, !tbaa !21
  br label %bb53
bb53:
  %t168 = load i1, ptr %l100, !tbaa !21
  br i1 %t168, label %bb54, label %bb55
bb54:
  store i1 true, ptr %l104, !tbaa !21
  br label %bb59
bb55:
  %t169 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 1
  %t170 = load i64, ptr %t169, !tbaa !24
  store i64 %t170, ptr %l105, !tbaa !24
  %t171 = load i64, ptr %l105, !tbaa !24
  %t172 = icmp sgt i64 %t171, 0
  store i1 %t172, ptr %l106, !tbaa !21
  %t173 = load i1, ptr %l106, !tbaa !21
  br i1 %t173, label %bb56, label %bb57
bb56:
  %t174 = load i64, ptr %l9, !tbaa !24
  store i64 %t174, ptr %l108, !tbaa !24
  %t175 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 1
  %t176 = load i64, ptr %t175, !tbaa !24
  store i64 %t176, ptr %l109, !tbaa !24
  %t177 = load i64, ptr %l108, !tbaa !24
  %t178 = load i64, ptr %l109, !tbaa !24
  %t179 = icmp sgt i64 %t177, %t178
  store i1 %t179, ptr %l110, !tbaa !21
  %t180 = load i1, ptr %l110, !tbaa !21
  store i1 %t180, ptr %l107, !tbaa !21
  br label %bb58
bb57:
  store i1 false, ptr %l107, !tbaa !21
  br label %bb58
bb58:
  %t181 = load i1, ptr %l107, !tbaa !21
  store i1 %t181, ptr %l104, !tbaa !21
  br label %bb59
bb59:
  %t182 = load i1, ptr %l104, !tbaa !21
  store i1 %t182, ptr %l10, !tbaa !21
  call void @__olang_scope_close(ptr %s6)
  br label %bb88
bb60:
  %t183 = load i32, ptr %l2
  store i32 %t183, ptr %l111
  %t184 = load i32, ptr %l111
  %t185 = trunc i64 53 to i32
  %t186 = icmp eq i32 %t184, %t185
  store i1 %t186, ptr %l112, !tbaa !21
  %t187 = load i1, ptr %l112, !tbaa !21
  br i1 %t187, label %bb61, label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb73
bb63:
  store %olang.scope zeroinitializer, ptr %s7
  %t188 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 1
  %t189 = load i64, ptr %t188, !tbaa !24
  store i64 %t189, ptr %l113, !tbaa !24
  %t190 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 1
  %t191 = load i64, ptr %t190, !tbaa !24
  store i64 %t191, ptr %l114, !tbaa !24
  %t192 = load i64, ptr %l113, !tbaa !24
  %t193 = load i64, ptr %l114, !tbaa !24
  %t194 = mul i64 %t192, %t193
  store i64 %t194, ptr %l115, !tbaa !24
  %t195 = load i64, ptr %l115, !tbaa !24
  store i64 %t195, ptr %l9, !tbaa !24
  %t196 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 1
  %t197 = load i64, ptr %t196, !tbaa !24
  store i64 %t197, ptr %l116, !tbaa !24
  %t198 = load i64, ptr %l116, !tbaa !24
  %t199 = icmp ne i64 %t198, 0
  store i1 %t199, ptr %l117, !tbaa !21
  %t200 = load i1, ptr %l117, !tbaa !21
  br i1 %t200, label %bb64, label %bb65
bb64:
  %t201 = load i64, ptr %l9, !tbaa !24
  store i64 %t201, ptr %l119, !tbaa !24
  %t202 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 1
  %t203 = load i64, ptr %t202, !tbaa !24
  store i64 %t203, ptr %l120, !tbaa !24
  %t204 = load i64, ptr %l119, !tbaa !24
  %t205 = load i64, ptr %l120, !tbaa !24
  %t206 = sdiv i64 %t204, %t205
  store i64 %t206, ptr %l121, !tbaa !24
  %t207 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 1
  %t208 = load i64, ptr %t207, !tbaa !24
  store i64 %t208, ptr %l122, !tbaa !24
  %t209 = load i64, ptr %l121, !tbaa !24
  %t210 = load i64, ptr %l122, !tbaa !24
  %t211 = icmp ne i64 %t209, %t210
  store i1 %t211, ptr %l123, !tbaa !21
  %t212 = load i1, ptr %l123, !tbaa !21
  br i1 %t212, label %bb66, label %bb67
bb65:
  store i1 false, ptr %l118, !tbaa !21
  br label %bb72
bb66:
  store i1 true, ptr %l124, !tbaa !21
  br label %bb71
bb67:
  %t213 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 1
  %t214 = load i64, ptr %t213, !tbaa !24
  store i64 %t214, ptr %l125, !tbaa !24
  %t215 = load i64, ptr %l125, !tbaa !24
  %t216 = icmp eq i64 %t215, -1
  store i1 %t216, ptr %l126, !tbaa !21
  %t217 = load i1, ptr %l126, !tbaa !21
  br i1 %t217, label %bb68, label %bb69
bb68:
  %t218 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 1
  %t219 = load i64, ptr %t218, !tbaa !24
  store i64 %t219, ptr %l128, !tbaa !24
  %t220 = load i64, ptr %l128, !tbaa !24
  %t221 = icmp eq i64 %t220, -9223372036854775808
  store i1 %t221, ptr %l129, !tbaa !21
  %t222 = load i1, ptr %l129, !tbaa !21
  store i1 %t222, ptr %l127, !tbaa !21
  br label %bb70
bb69:
  store i1 false, ptr %l127, !tbaa !21
  br label %bb70
bb70:
  %t223 = load i1, ptr %l127, !tbaa !21
  store i1 %t223, ptr %l124, !tbaa !21
  br label %bb71
bb71:
  %t224 = load i1, ptr %l124, !tbaa !21
  store i1 %t224, ptr %l118, !tbaa !21
  br label %bb72
bb72:
  %t225 = load i1, ptr %l118, !tbaa !21
  store i1 %t225, ptr %l10, !tbaa !21
  call void @__olang_scope_close(ptr %s7)
  br label %bb88
bb73:
  store %olang.scope zeroinitializer, ptr %s8
  %t226 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 1
  %t227 = load i64, ptr %t226, !tbaa !24
  store i64 %t227, ptr %l130, !tbaa !24
  %t228 = load i64, ptr %l130, !tbaa !24
  %t229 = icmp eq i64 %t228, 0
  store i1 %t229, ptr %l131, !tbaa !21
  %t230 = load i1, ptr %l131, !tbaa !21
  br i1 %t230, label %bb74, label %bb75
bb74:
  store i1 true, ptr %l132, !tbaa !21
  br label %bb79
bb75:
  %t231 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 1
  %t232 = load i64, ptr %t231, !tbaa !24
  store i64 %t232, ptr %l133, !tbaa !24
  %t233 = load i64, ptr %l133, !tbaa !24
  %t234 = icmp eq i64 %t233, -9223372036854775808
  store i1 %t234, ptr %l134, !tbaa !21
  %t235 = load i1, ptr %l134, !tbaa !21
  br i1 %t235, label %bb76, label %bb77
bb76:
  %t236 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 1
  %t237 = load i64, ptr %t236, !tbaa !24
  store i64 %t237, ptr %l136, !tbaa !24
  %t238 = load i64, ptr %l136, !tbaa !24
  %t239 = icmp eq i64 %t238, -1
  store i1 %t239, ptr %l137, !tbaa !21
  %t240 = load i1, ptr %l137, !tbaa !21
  store i1 %t240, ptr %l135, !tbaa !21
  br label %bb78
bb77:
  store i1 false, ptr %l135, !tbaa !21
  br label %bb78
bb78:
  %t241 = load i1, ptr %l135, !tbaa !21
  store i1 %t241, ptr %l132, !tbaa !21
  br label %bb79
bb79:
  %t242 = load i1, ptr %l132, !tbaa !21
  br i1 %t242, label %bb80, label %bb81
bb80:
  store %olang.scope zeroinitializer, ptr %s9
  %t243 = load ptr, ptr %l0, !tbaa !29
  store ptr %t243, ptr %l138, !tbaa !29
  %t244 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t244, ptr %l139
  %t245 = load ptr, ptr %l138, !tbaa !29
  %t246 = load %"compiler/source:Span", ptr %l139
  %t247 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t245, %"compiler/source:Span" %t246)
  store %"compiler/cond:Value" %t247, ptr %l140
  br label %bb82
bb81:
  br label %bb83
bb82:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t248 = load %"compiler/cond:Value", ptr %l140
  store %"compiler/cond:Value" %t248, ptr %rv
  br label %ret
bb83:
  %t249 = load i32, ptr %l2
  store i32 %t249, ptr %l141
  store ptr %l141, ptr %l142, !tbaa !29
  store i32 54, ptr %l143
  store ptr %l143, ptr %l144, !tbaa !29
  %t250 = load ptr, ptr %l142, !tbaa !29
  %t251 = load ptr, ptr %l144, !tbaa !29
  %t252 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t250, ptr %t251)
  store i1 %t252, ptr %l145
  br label %bb84
bb84:
  %t253 = load i1, ptr %l145, !tbaa !21
  br i1 %t253, label %bb85, label %bb86
bb85:
  %t254 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 1
  %t255 = load i64, ptr %t254, !tbaa !24
  store i64 %t255, ptr %l147, !tbaa !24
  %t256 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 1
  %t257 = load i64, ptr %t256, !tbaa !24
  store i64 %t257, ptr %l148, !tbaa !24
  %t258 = load i64, ptr %l147, !tbaa !24
  %t259 = load i64, ptr %l148, !tbaa !24
  %t260 = sdiv i64 %t258, %t259
  store i64 %t260, ptr %l149, !tbaa !24
  %t261 = load i64, ptr %l149, !tbaa !24
  store i64 %t261, ptr %l146, !tbaa !24
  br label %bb87
bb86:
  %t262 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 1
  %t263 = load i64, ptr %t262, !tbaa !24
  store i64 %t263, ptr %l150, !tbaa !24
  %t264 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 1
  %t265 = load i64, ptr %t264, !tbaa !24
  store i64 %t265, ptr %l151, !tbaa !24
  %t266 = load i64, ptr %l150, !tbaa !24
  %t267 = load i64, ptr %l151, !tbaa !24
  %t268 = srem i64 %t266, %t267
  store i64 %t268, ptr %l152, !tbaa !24
  %t269 = load i64, ptr %l152, !tbaa !24
  store i64 %t269, ptr %l146, !tbaa !24
  br label %bb87
bb87:
  %t270 = load i64, ptr %l146, !tbaa !24
  store i64 %t270, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s8)
  br label %bb88
bb88:
  %t271 = load i1, ptr %l10, !tbaa !21
  store i1 %t271, ptr %l153, !tbaa !21
  %t272 = load i1, ptr %l153, !tbaa !21
  br i1 %t272, label %bb89, label %bb90
bb89:
  store i1 true, ptr %l154, !tbaa !21
  br label %bb95
bb90:
  %t273 = load i64, ptr %l9, !tbaa !24
  store i64 %t273, ptr %l155, !tbaa !24
  %t274 = load i64, ptr %l7, !tbaa !24
  store i64 %t274, ptr %l156, !tbaa !24
  %t275 = load i64, ptr %l156, !tbaa !24
  %t276 = icmp ne i64 %t275, 0
  store i1 %t276, ptr %l157, !tbaa !21
  %t277 = load i1, ptr %l157, !tbaa !21
  br i1 %t277, label %bb91, label %bb92
bb91:
  %t278 = load i64, ptr %l7, !tbaa !24
  store i64 %t278, ptr %l159, !tbaa !24
  %t279 = load i64, ptr %l159, !tbaa !24
  store i64 %t279, ptr %l158, !tbaa !24
  br label %bb93
bb92:
  %t280 = load i64, ptr @G_2ecompiler_2fcond_2eLiteralIntBits, !tbaa !24
  store i64 %t280, ptr %l160, !tbaa !24
  %t281 = load i64, ptr %l160, !tbaa !24
  store i64 %t281, ptr %l158, !tbaa !24
  br label %bb93
bb93:
  %t282 = load i1, ptr %l8, !tbaa !21
  store i1 %t282, ptr %l161, !tbaa !21
  %t283 = load i64, ptr %l155, !tbaa !24
  %t284 = load i64, ptr %l158, !tbaa !24
  %t285 = load i1, ptr %l161, !tbaa !21
  %t286 = call i1 @compiler_2fcond_2efits(i64 %t283, i64 %t284, i1 %t285)
  store i1 %t286, ptr %l162
  br label %bb94
bb94:
  %t287 = load i1, ptr %l162, !tbaa !21
  %t288 = xor i1 %t287, true
  store i1 %t288, ptr %l163, !tbaa !21
  %t289 = load i1, ptr %l163, !tbaa !21
  store i1 %t289, ptr %l154, !tbaa !21
  br label %bb95
bb95:
  %t290 = load i1, ptr %l154, !tbaa !21
  br i1 %t290, label %bb96, label %bb97
bb96:
  store %olang.scope zeroinitializer, ptr %s10
  %t291 = load ptr, ptr %l0, !tbaa !29
  store ptr %t291, ptr %l164, !tbaa !29
  %t292 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t292, ptr %l165
  %t293 = load ptr, ptr %l164, !tbaa !29
  %t294 = load %"compiler/source:Span", ptr %l165
  %t295 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t293, %"compiler/source:Span" %t294)
  store %"compiler/cond:Value" %t295, ptr %l166
  br label %bb98
bb97:
  br label %bb99
bb98:
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t296 = load %"compiler/cond:Value", ptr %l166
  store %"compiler/cond:Value" %t296, ptr %rv
  br label %ret
bb99:
  store i32 2, ptr %l167
  %t297 = load i64, ptr %l9, !tbaa !24
  store i64 %t297, ptr %l168, !tbaa !24
  %t298 = load i64, ptr %l7, !tbaa !24
  store i64 %t298, ptr %l169, !tbaa !24
  %t299 = load i1, ptr %l8, !tbaa !21
  store i1 %t299, ptr %l170, !tbaa !21
  %t300 = load i32, ptr %l167
  %t301 = load i64, ptr %l168, !tbaa !24
  %t302 = load i64, ptr %l169, !tbaa !24
  %t303 = load i1, ptr %l170, !tbaa !21
  %t304 = call %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %s3, i32 %t300, i64 %t301, double 0x0000000000000000, i64 0, i64 %t302, i1 %t303)
  store %"compiler/cond:Value" %t304, ptr %l171
  br label %bb100
bb100:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t305 = load %"compiler/cond:Value", ptr %l171
  store %"compiler/cond:Value" %t305, ptr %rv
  br label %ret
bb101:
  %t306 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 0
  %t307 = load i32, ptr %t306
  store i32 %t307, ptr %l172
  store ptr %l172, ptr %l173, !tbaa !29
  store i32 2, ptr %l174
  store ptr %l174, ptr %l175, !tbaa !29
  %t308 = load ptr, ptr %l173, !tbaa !29
  %t309 = load ptr, ptr %l175, !tbaa !29
  %t310 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %t308, ptr %t309)
  store i1 %t310, ptr %l176
  br label %bb102
bb102:
  %t311 = load i1, ptr %l176, !tbaa !21
  br i1 %t311, label %bb103, label %bb104
bb103:
  %t312 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 4
  %t313 = load i64, ptr %t312, !tbaa !24
  store i64 %t313, ptr %l178, !tbaa !24
  %t314 = load i64, ptr %l178, !tbaa !24
  %t315 = icmp ne i64 %t314, 0
  store i1 %t315, ptr %l179, !tbaa !21
  %t316 = load i1, ptr %l179, !tbaa !21
  store i1 %t316, ptr %l177, !tbaa !21
  br label %bb105
bb104:
  store i1 false, ptr %l177, !tbaa !21
  br label %bb105
bb105:
  %t317 = load i1, ptr %l177, !tbaa !21
  br i1 %t317, label %bb106, label %bb107
bb106:
  store i1 true, ptr %l180, !tbaa !21
  br label %bb112
bb107:
  %t318 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 0
  %t319 = load i32, ptr %t318
  store i32 %t319, ptr %l181
  store ptr %l181, ptr %l182, !tbaa !29
  store i32 2, ptr %l183
  store ptr %l183, ptr %l184, !tbaa !29
  %t320 = load ptr, ptr %l182, !tbaa !29
  %t321 = load ptr, ptr %l184, !tbaa !29
  %t322 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %t320, ptr %t321)
  store i1 %t322, ptr %l185
  br label %bb108
bb108:
  %t323 = load i1, ptr %l185, !tbaa !21
  br i1 %t323, label %bb109, label %bb110
bb109:
  %t324 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 4
  %t325 = load i64, ptr %t324, !tbaa !24
  store i64 %t325, ptr %l187, !tbaa !24
  %t326 = load i64, ptr %l187, !tbaa !24
  %t327 = icmp ne i64 %t326, 0
  store i1 %t327, ptr %l188, !tbaa !21
  %t328 = load i1, ptr %l188, !tbaa !21
  store i1 %t328, ptr %l186, !tbaa !21
  br label %bb111
bb110:
  store i1 false, ptr %l186, !tbaa !21
  br label %bb111
bb111:
  %t329 = load i1, ptr %l186, !tbaa !21
  store i1 %t329, ptr %l180, !tbaa !21
  br label %bb112
bb112:
  %t330 = load i1, ptr %l180, !tbaa !21
  br i1 %t330, label %bb113, label %bb114
bb113:
  store %olang.scope zeroinitializer, ptr %s11
  %t331 = load ptr, ptr %l0, !tbaa !29
  store ptr %t331, ptr %l189, !tbaa !29
  %t332 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t332, ptr %l190
  %t333 = load ptr, ptr %l0, !tbaa !29
  store ptr %t333, ptr %l191, !tbaa !29
  %t334 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t334, ptr %l192
  %t335 = load ptr, ptr %l191, !tbaa !29
  %t336 = load %"compiler/source:Span", ptr %l192
  %t337 = call { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aEval_2etokText(ptr %v0, ptr %v0, ptr %t335, %"compiler/source:Span" %t336)
  store { i64, ptr } %t337, ptr %l193
  br label %bb115
bb114:
  br label %bb118
bb115:
  %t338 = load { i64, ptr }, ptr %l193, !tbaa !27
  %t339 = extractvalue { i64, ptr } %t338, 0
  %t340 = extractvalue { i64, ptr } %t338, 1
  %t341 = mul i64 %t339, 1
  %t342 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t341)
  call void @llvm.memcpy.p0.p0.i64(ptr %t342, ptr %t340, i64 %t341, i1 false)
  %t343 = insertvalue { i64, ptr } undef, i64 %t339, 0
  %t344 = insertvalue { i64, ptr } %t343, ptr %t342, 1
  store { i64, ptr } %t344, ptr %l194, !tbaa !27
  %t345 = load { i64, ptr }, ptr %l194, !tbaa !27
  %t346 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondNoMeet(ptr %v0, ptr %v0, { i64, ptr } %t345)
  store %"compiler/msgs:Msg" %t346, ptr %l195
  br label %bb116
bb116:
  %t347 = load ptr, ptr %l189, !tbaa !29
  %t348 = load %"compiler/source:Span", ptr %l190
  %t349 = load %"compiler/msgs:Msg", ptr %l195
  %t350 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2efail(ptr %v0, ptr %v0, ptr %t347, %"compiler/source:Span" %t348, %"compiler/msgs:Msg" %t349)
  store %"compiler/cond:Value" %t350, ptr %l196
  br label %bb117
bb117:
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  %t351 = load %"compiler/cond:Value", ptr %l196
  store %"compiler/cond:Value" %t351, ptr %rv
  br label %ret
bb118:
  %t352 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 2
  %t353 = load double, ptr %t352, !tbaa !26
  store double %t353, ptr %l197, !tbaa !26
  %t354 = load double, ptr %l197, !tbaa !26
  store double %t354, ptr %l11, !tbaa !26
  %t355 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 2
  %t356 = load double, ptr %t355, !tbaa !26
  store double %t356, ptr %l198, !tbaa !26
  %t357 = load double, ptr %l198, !tbaa !26
  store double %t357, ptr %l12, !tbaa !26
  %t358 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 0
  %t359 = load i32, ptr %t358
  store i32 %t359, ptr %l199
  store ptr %l199, ptr %l200, !tbaa !29
  store i32 2, ptr %l201
  store ptr %l201, ptr %l202, !tbaa !29
  %t360 = load ptr, ptr %l200, !tbaa !29
  %t361 = load ptr, ptr %l202, !tbaa !29
  %t362 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %t360, ptr %t361)
  store i1 %t362, ptr %l203
  br label %bb119
bb119:
  %t363 = load i1, ptr %l203, !tbaa !21
  br i1 %t363, label %bb120, label %bb121
bb120:
  store %olang.scope zeroinitializer, ptr %s12
  %t364 = load %"compiler/cond:Value", ptr %l3
  store %"compiler/cond:Value" %t364, ptr %l204
  %t365 = load %"compiler/cond:Value", ptr %l204
  %t366 = call { i1, double } @compiler_2fcond_2easFloat(%"compiler/cond:Value" %t365)
  store { i1, double } %t366, ptr %l205
  br label %bb122
bb121:
  br label %bb127
bb122:
  %t367 = load { i1, double }, ptr %l205
  store { i1, double } %t367, ptr %l13
  %t368 = getelementptr { i1, double }, ptr %l13, i32 0, i32 0
  %t369 = load i1, ptr %t368, !tbaa !21
  store i1 %t369, ptr %l206, !tbaa !21
  %t370 = load i1, ptr %l206, !tbaa !21
  store i1 %t370, ptr %l14, !tbaa !21
  %t371 = getelementptr { i1, double }, ptr %l13, i32 0, i32 1
  %t372 = load double, ptr %t371, !tbaa !26
  store double %t372, ptr %l207, !tbaa !26
  %t373 = load double, ptr %l207, !tbaa !26
  store double %t373, ptr %l15, !tbaa !26
  %t374 = load i1, ptr %l14, !tbaa !21
  store i1 %t374, ptr %l208, !tbaa !21
  %t375 = load i1, ptr %l208, !tbaa !21
  %t376 = xor i1 %t375, true
  store i1 %t376, ptr %l209, !tbaa !21
  %t377 = load i1, ptr %l209, !tbaa !21
  br i1 %t377, label %bb123, label %bb124
bb123:
  store %olang.scope zeroinitializer, ptr %s13
  %t378 = load ptr, ptr %l0, !tbaa !29
  store ptr %t378, ptr %l210, !tbaa !29
  %t379 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t379, ptr %l211
  %t380 = load ptr, ptr %l210, !tbaa !29
  %t381 = load %"compiler/source:Span", ptr %l211
  %t382 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t380, %"compiler/source:Span" %t381)
  store %"compiler/cond:Value" %t382, ptr %l212
  br label %bb125
bb124:
  br label %bb126
bb125:
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s0)
  %t383 = load %"compiler/cond:Value", ptr %l212
  store %"compiler/cond:Value" %t383, ptr %rv
  br label %ret
bb126:
  %t384 = load double, ptr %l15, !tbaa !26
  store double %t384, ptr %l213, !tbaa !26
  %t385 = load double, ptr %l213, !tbaa !26
  store double %t385, ptr %l11, !tbaa !26
  call void @__olang_scope_close(ptr %s12)
  br label %bb127
bb127:
  %t386 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 0
  %t387 = load i32, ptr %t386
  store i32 %t387, ptr %l214
  store ptr %l214, ptr %l215, !tbaa !29
  store i32 2, ptr %l216
  store ptr %l216, ptr %l217, !tbaa !29
  %t388 = load ptr, ptr %l215, !tbaa !29
  %t389 = load ptr, ptr %l217, !tbaa !29
  %t390 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %t388, ptr %t389)
  store i1 %t390, ptr %l218
  br label %bb128
bb128:
  %t391 = load i1, ptr %l218, !tbaa !21
  br i1 %t391, label %bb129, label %bb130
bb129:
  store %olang.scope zeroinitializer, ptr %s14
  %t392 = load %"compiler/cond:Value", ptr %l4
  store %"compiler/cond:Value" %t392, ptr %l219
  %t393 = load %"compiler/cond:Value", ptr %l219
  %t394 = call { i1, double } @compiler_2fcond_2easFloat(%"compiler/cond:Value" %t393)
  store { i1, double } %t394, ptr %l220
  br label %bb131
bb130:
  br label %bb136
bb131:
  %t395 = load { i1, double }, ptr %l220
  store { i1, double } %t395, ptr %l16
  %t396 = getelementptr { i1, double }, ptr %l16, i32 0, i32 0
  %t397 = load i1, ptr %t396, !tbaa !21
  store i1 %t397, ptr %l221, !tbaa !21
  %t398 = load i1, ptr %l221, !tbaa !21
  store i1 %t398, ptr %l17, !tbaa !21
  %t399 = getelementptr { i1, double }, ptr %l16, i32 0, i32 1
  %t400 = load double, ptr %t399, !tbaa !26
  store double %t400, ptr %l222, !tbaa !26
  %t401 = load double, ptr %l222, !tbaa !26
  store double %t401, ptr %l18, !tbaa !26
  %t402 = load i1, ptr %l17, !tbaa !21
  store i1 %t402, ptr %l223, !tbaa !21
  %t403 = load i1, ptr %l223, !tbaa !21
  %t404 = xor i1 %t403, true
  store i1 %t404, ptr %l224, !tbaa !21
  %t405 = load i1, ptr %l224, !tbaa !21
  br i1 %t405, label %bb132, label %bb133
bb132:
  store %olang.scope zeroinitializer, ptr %s15
  %t406 = load ptr, ptr %l0, !tbaa !29
  store ptr %t406, ptr %l225, !tbaa !29
  %t407 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t407, ptr %l226
  %t408 = load ptr, ptr %l225, !tbaa !29
  %t409 = load %"compiler/source:Span", ptr %l226
  %t410 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t408, %"compiler/source:Span" %t409)
  store %"compiler/cond:Value" %t410, ptr %l227
  br label %bb134
bb133:
  br label %bb135
bb134:
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s0)
  %t411 = load %"compiler/cond:Value", ptr %l227
  store %"compiler/cond:Value" %t411, ptr %rv
  br label %ret
bb135:
  %t412 = load double, ptr %l18, !tbaa !26
  store double %t412, ptr %l228, !tbaa !26
  %t413 = load double, ptr %l228, !tbaa !26
  store double %t413, ptr %l12, !tbaa !26
  call void @__olang_scope_close(ptr %s14)
  br label %bb136
bb136:
  %t414 = load i32, ptr %l2
  store i32 %t414, ptr %l229
  store ptr %l229, ptr %l230, !tbaa !29
  store i32 55, ptr %l231
  store ptr %l231, ptr %l232, !tbaa !29
  %t415 = load ptr, ptr %l230, !tbaa !29
  %t416 = load ptr, ptr %l232, !tbaa !29
  %t417 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t415, ptr %t416)
  store i1 %t417, ptr %l233
  br label %bb137
bb137:
  %t418 = load i1, ptr %l233, !tbaa !21
  br i1 %t418, label %bb138, label %bb139
bb138:
  store %olang.scope zeroinitializer, ptr %s16
  %t419 = load ptr, ptr %l0, !tbaa !29
  store ptr %t419, ptr %l234, !tbaa !29
  %t420 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t420, ptr %l235
  %t421 = load ptr, ptr %l234, !tbaa !29
  %t422 = load %"compiler/source:Span", ptr %l235
  %t423 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t421, %"compiler/source:Span" %t422)
  store %"compiler/cond:Value" %t423, ptr %l236
  br label %bb140
bb139:
  br label %bb141
bb140:
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s0)
  %t424 = load %"compiler/cond:Value", ptr %l236
  store %"compiler/cond:Value" %t424, ptr %rv
  br label %ret
bb141:
  %t425 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 4
  %t426 = load i64, ptr %t425, !tbaa !24
  store i64 %t426, ptr %l237, !tbaa !24
  %t427 = load i64, ptr %l237, !tbaa !24
  %t428 = icmp ne i64 %t427, 0
  store i1 %t428, ptr %l238, !tbaa !21
  %t429 = load i1, ptr %l238, !tbaa !21
  br i1 %t429, label %bb142, label %bb143
bb142:
  store i1 true, ptr %l239, !tbaa !21
  br label %bb144
bb143:
  %t430 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 4
  %t431 = load i64, ptr %t430, !tbaa !24
  store i64 %t431, ptr %l240, !tbaa !24
  %t432 = load i64, ptr %l240, !tbaa !24
  %t433 = icmp ne i64 %t432, 0
  store i1 %t433, ptr %l241, !tbaa !21
  %t434 = load i1, ptr %l241, !tbaa !21
  store i1 %t434, ptr %l239, !tbaa !21
  br label %bb144
bb144:
  %t435 = load i1, ptr %l239, !tbaa !21
  br i1 %t435, label %bb145, label %bb146
bb145:
  store i64 64, ptr %l242, !tbaa !24
  br label %bb147
bb146:
  store i64 0, ptr %l242, !tbaa !24
  br label %bb147
bb147:
  %t436 = load i64, ptr %l242, !tbaa !24
  store i64 %t436, ptr %l19, !tbaa !24
  %t437 = load i32, ptr %l2
  store i32 %t437, ptr %l243
  store ptr %l243, ptr %l244, !tbaa !29
  store i32 51, ptr %l245
  store ptr %l245, ptr %l246, !tbaa !29
  %t438 = load ptr, ptr %l244, !tbaa !29
  %t439 = load ptr, ptr %l246, !tbaa !29
  %t440 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t438, ptr %t439)
  store i1 %t440, ptr %l247
  br label %bb148
bb148:
  %t441 = load i1, ptr %l247, !tbaa !21
  br i1 %t441, label %bb149, label %bb150
bb149:
  %t442 = load double, ptr %l11, !tbaa !26
  store double %t442, ptr %l249, !tbaa !26
  %t443 = load double, ptr %l12, !tbaa !26
  store double %t443, ptr %l250, !tbaa !26
  %t444 = load double, ptr %l249, !tbaa !26
  %t445 = load double, ptr %l250, !tbaa !26
  %t446 = fadd double %t444, %t445
  store double %t446, ptr %l251, !tbaa !26
  %t447 = load double, ptr %l251, !tbaa !26
  store double %t447, ptr %l248, !tbaa !26
  br label %bb159
bb150:
  %t448 = load i32, ptr %l2
  store i32 %t448, ptr %l252
  store ptr %l252, ptr %l253, !tbaa !29
  store i32 52, ptr %l254
  store ptr %l254, ptr %l255, !tbaa !29
  %t449 = load ptr, ptr %l253, !tbaa !29
  %t450 = load ptr, ptr %l255, !tbaa !29
  %t451 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t449, ptr %t450)
  store i1 %t451, ptr %l256
  br label %bb151
bb151:
  %t452 = load i1, ptr %l256, !tbaa !21
  br i1 %t452, label %bb152, label %bb153
bb152:
  %t453 = load double, ptr %l11, !tbaa !26
  store double %t453, ptr %l258, !tbaa !26
  %t454 = load double, ptr %l12, !tbaa !26
  store double %t454, ptr %l259, !tbaa !26
  %t455 = load double, ptr %l258, !tbaa !26
  %t456 = load double, ptr %l259, !tbaa !26
  %t457 = fsub double %t455, %t456
  store double %t457, ptr %l260, !tbaa !26
  %t458 = load double, ptr %l260, !tbaa !26
  store double %t458, ptr %l257, !tbaa !26
  br label %bb158
bb153:
  %t459 = load i32, ptr %l2
  store i32 %t459, ptr %l261
  store ptr %l261, ptr %l262, !tbaa !29
  store i32 53, ptr %l263
  store ptr %l263, ptr %l264, !tbaa !29
  %t460 = load ptr, ptr %l262, !tbaa !29
  %t461 = load ptr, ptr %l264, !tbaa !29
  %t462 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t460, ptr %t461)
  store i1 %t462, ptr %l265
  br label %bb154
bb154:
  %t463 = load i1, ptr %l265, !tbaa !21
  br i1 %t463, label %bb155, label %bb156
bb155:
  %t464 = load double, ptr %l11, !tbaa !26
  store double %t464, ptr %l267, !tbaa !26
  %t465 = load double, ptr %l12, !tbaa !26
  store double %t465, ptr %l268, !tbaa !26
  %t466 = load double, ptr %l267, !tbaa !26
  %t467 = load double, ptr %l268, !tbaa !26
  %t468 = fmul double %t466, %t467
  store double %t468, ptr %l269, !tbaa !26
  %t469 = load double, ptr %l269, !tbaa !26
  store double %t469, ptr %l266, !tbaa !26
  br label %bb157
bb156:
  %t470 = load double, ptr %l11, !tbaa !26
  store double %t470, ptr %l270, !tbaa !26
  %t471 = load double, ptr %l12, !tbaa !26
  store double %t471, ptr %l271, !tbaa !26
  %t472 = load double, ptr %l270, !tbaa !26
  %t473 = load double, ptr %l271, !tbaa !26
  %t474 = fdiv double %t472, %t473
  store double %t474, ptr %l272, !tbaa !26
  %t475 = load double, ptr %l272, !tbaa !26
  store double %t475, ptr %l266, !tbaa !26
  br label %bb157
bb157:
  %t476 = load double, ptr %l266, !tbaa !26
  store double %t476, ptr %l257, !tbaa !26
  br label %bb158
bb158:
  %t477 = load double, ptr %l257, !tbaa !26
  store double %t477, ptr %l248, !tbaa !26
  br label %bb159
bb159:
  %t478 = load double, ptr %l248, !tbaa !26
  store double %t478, ptr %l20, !tbaa !26
  store i32 3, ptr %l273
  %t479 = load double, ptr %l20, !tbaa !26
  store double %t479, ptr %l274, !tbaa !26
  %t480 = load i64, ptr %l19, !tbaa !24
  store i64 %t480, ptr %l275, !tbaa !24
  %t481 = load i32, ptr %l273
  %t482 = load double, ptr %l274, !tbaa !26
  %t483 = load i64, ptr %l275, !tbaa !24
  %t484 = call %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %s0, i32 %t481, i64 0, double %t482, i64 0, i64 %t483, i1 false)
  store %"compiler/cond:Value" %t484, ptr %l276
  br label %bb160
bb160:
  call void @__olang_scope_close(ptr %s0)
  %t485 = load %"compiler/cond:Value", ptr %l276
  store %"compiler/cond:Value" %t485, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cond:Value", ptr %rv
  ret %"compiler/cond:Value" %rr
}

define dso_local %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2easDeclared(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, %"compiler/cond:Value" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca %"compiler/cond:Value"
  %l4 = alloca { i32, i64, i1 }
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i1
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca ptr
  %l12 = alloca i1
  %l13 = alloca %"compiler/cond:Value"
  %l14 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l16 = alloca i1
  %l17 = alloca i32
  %l18 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca ptr
  %l21 = alloca i1
  %l22 = alloca i1
  %l23 = alloca i64
  %l24 = alloca i1
  %l25 = alloca i32
  %l26 = alloca i64
  %l27 = alloca double
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca %"compiler/cond:Value"
  %l31 = alloca i32
  %l32 = alloca ptr
  %l33 = alloca i32
  %l34 = alloca ptr
  %l35 = alloca i1
  %l36 = alloca i32
  %l37 = alloca i64
  %l38 = alloca double
  %l39 = alloca i64
  %l40 = alloca %"compiler/cond:Value"
  %l41 = alloca %"compiler/cond:Value"
  %l42 = alloca ptr
  %l43 = alloca { i64, ptr }
  %l44 = alloca { i32, i64, i1 }
  %l45 = alloca i32
  %l46 = alloca i64
  %l47 = alloca i1
  %l48 = alloca %"compiler/cond:Value"
  %l49 = alloca i32
  %l50 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca %"compiler/source:Span"
  %l53 = alloca %"compiler/cond:Value"
  %l54 = alloca i64
  %l55 = alloca i1
  %l56 = alloca %"compiler/cond:Value"
  %l57 = alloca i32
  %l58 = alloca i1
  %l59 = alloca ptr
  %l60 = alloca %"compiler/source:Span"
  %l61 = alloca %"compiler/cond:Value"
  %l62 = alloca i64
  %l63 = alloca %"compiler/cond:Value"
  %l64 = alloca i32
  %l65 = alloca i1
  %l66 = alloca i32
  %l67 = alloca ptr
  %l68 = alloca i32
  %l69 = alloca ptr
  %l70 = alloca i1
  %l71 = alloca %"compiler/cond:Value"
  %l72 = alloca %"compiler/cond:Value"
  %l73 = alloca ptr
  %l74 = alloca %"compiler/source:Span"
  %l75 = alloca %"compiler/cond:Value"
  %l76 = alloca i32
  %l77 = alloca i1
  %l78 = alloca i32
  %l79 = alloca ptr
  %l80 = alloca i32
  %l81 = alloca ptr
  %l82 = alloca i1
  %l83 = alloca %"compiler/cond:Value"
  %l84 = alloca %"compiler/cond:Value"
  %l85 = alloca ptr
  %l86 = alloca %"compiler/source:Span"
  %l87 = alloca %"compiler/cond:Value"
  %l88 = alloca i32
  %l89 = alloca ptr
  %l90 = alloca i32
  %l91 = alloca ptr
  %l92 = alloca i1
  %l93 = alloca i1
  %l94 = alloca i32
  %l95 = alloca ptr
  %l96 = alloca i32
  %l97 = alloca ptr
  %l98 = alloca i1
  %l99 = alloca %"compiler/cond:Value"
  %l100 = alloca %"compiler/cond:Value"
  %l101 = alloca ptr
  %l102 = alloca %"compiler/source:Span"
  %l103 = alloca %"compiler/cond:Value"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca %"compiler/cond:Value"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store %"compiler/cond:Value" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 0
  %t2 = load i32, ptr %t1
  store i32 %t2, ptr %l8
  store ptr %l8, ptr %l9, !tbaa !29
  store i32 0, ptr %l10
  store ptr %l10, ptr %l11, !tbaa !29
  %t3 = load ptr, ptr %l9, !tbaa !29
  %t4 = load ptr, ptr %l11, !tbaa !29
  %t5 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %t3, ptr %t4)
  store i1 %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load i1, ptr %l12, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t7 = load %"compiler/cond:Value", ptr %l3
  store %"compiler/cond:Value" %t7, ptr %l13
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t8 = load %"compiler/cond:Value", ptr %l13
  store %"compiler/cond:Value" %t8, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t9 = load ptr, ptr %l2, !tbaa !29
  store ptr %t9, ptr %l14, !tbaa !29
  %t10 = load ptr, ptr %l14, !tbaa !29
  %t11 = getelementptr %"compiler/cond:Global", ptr %t10, i32 0, i32 3
  %t12 = load { i64, ptr }, ptr %t11, !tbaa !27
  store { i64, ptr } %t12, ptr %l15, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t14 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t13, { i64, ptr } { i64 0, ptr @.d30 })
  store i1 %t14, ptr %l16
  br label %bb5
bb5:
  %t15 = load i1, ptr %l16, !tbaa !21
  br i1 %t15, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t16 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 0
  %t17 = load i32, ptr %t16
  store i32 %t17, ptr %l17
  store ptr %l17, ptr %l18, !tbaa !29
  store i32 2, ptr %l19
  store ptr %l19, ptr %l20, !tbaa !29
  %t18 = load ptr, ptr %l18, !tbaa !29
  %t19 = load ptr, ptr %l20, !tbaa !29
  %t20 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %t18, ptr %t19)
  store i1 %t20, ptr %l21
  br label %bb8
bb7:
  br label %bb21
bb8:
  %t21 = load i1, ptr %l21, !tbaa !21
  br i1 %t21, label %bb9, label %bb10
bb9:
  %t22 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 4
  %t23 = load i64, ptr %t22, !tbaa !24
  store i64 %t23, ptr %l23, !tbaa !24
  %t24 = load i64, ptr %l23, !tbaa !24
  %t25 = icmp eq i64 %t24, 0
  store i1 %t25, ptr %l24, !tbaa !21
  %t26 = load i1, ptr %l24, !tbaa !21
  store i1 %t26, ptr %l22, !tbaa !21
  br label %bb11
bb10:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb11
bb11:
  %t27 = load i1, ptr %l22, !tbaa !21
  br i1 %t27, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t28 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 0
  %t29 = load i32, ptr %t28
  store i32 %t29, ptr %l25
  %t30 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 1
  %t31 = load i64, ptr %t30, !tbaa !24
  store i64 %t31, ptr %l26, !tbaa !24
  %t32 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 2
  %t33 = load double, ptr %t32, !tbaa !26
  store double %t33, ptr %l27, !tbaa !26
  %t34 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 3
  %t35 = load i64, ptr %t34, !tbaa !24
  store i64 %t35, ptr %l28, !tbaa !24
  %t36 = load i64, ptr @G_2ecompiler_2fcond_2eLiteralIntBits, !tbaa !24
  store i64 %t36, ptr %l29, !tbaa !24
  %t37 = load i32, ptr %l25
  %t38 = load i64, ptr %l26, !tbaa !24
  %t39 = load double, ptr %l27, !tbaa !26
  %t40 = load i64, ptr %l28, !tbaa !24
  %t41 = load i64, ptr %l29, !tbaa !24
  %t42 = call %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %s3, i32 %t37, i64 %t38, double %t39, i64 %t40, i64 %t41, i1 false)
  store %"compiler/cond:Value" %t42, ptr %l30
  br label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t43 = load %"compiler/cond:Value", ptr %l30
  store %"compiler/cond:Value" %t43, ptr %rv
  br label %ret
bb15:
  %t44 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 0
  %t45 = load i32, ptr %t44
  store i32 %t45, ptr %l31
  store ptr %l31, ptr %l32, !tbaa !29
  store i32 3, ptr %l33
  store ptr %l33, ptr %l34, !tbaa !29
  %t46 = load ptr, ptr %l32, !tbaa !29
  %t47 = load ptr, ptr %l34, !tbaa !29
  %t48 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %t46, ptr %t47)
  store i1 %t48, ptr %l35
  br label %bb16
bb16:
  %t49 = load i1, ptr %l35, !tbaa !21
  br i1 %t49, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s4
  %t50 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 0
  %t51 = load i32, ptr %t50
  store i32 %t51, ptr %l36
  %t52 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 1
  %t53 = load i64, ptr %t52, !tbaa !24
  store i64 %t53, ptr %l37, !tbaa !24
  %t54 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 2
  %t55 = load double, ptr %t54, !tbaa !26
  store double %t55, ptr %l38, !tbaa !26
  %t56 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 3
  %t57 = load i64, ptr %t56, !tbaa !24
  store i64 %t57, ptr %l39, !tbaa !24
  %t58 = load i32, ptr %l36
  %t59 = load i64, ptr %l37, !tbaa !24
  %t60 = load double, ptr %l38, !tbaa !26
  %t61 = load i64, ptr %l39, !tbaa !24
  %t62 = call %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %s4, i32 %t58, i64 %t59, double %t60, i64 %t61, i64 64, i1 false)
  store %"compiler/cond:Value" %t62, ptr %l40
  br label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t63 = load %"compiler/cond:Value", ptr %l40
  store %"compiler/cond:Value" %t63, ptr %rv
  br label %ret
bb20:
  %t64 = load %"compiler/cond:Value", ptr %l3
  store %"compiler/cond:Value" %t64, ptr %l41
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t65 = load %"compiler/cond:Value", ptr %l41
  store %"compiler/cond:Value" %t65, ptr %rv
  br label %ret
bb21:
  %t66 = load ptr, ptr %l2, !tbaa !29
  store ptr %t66, ptr %l42, !tbaa !29
  %t67 = load ptr, ptr %l42, !tbaa !29
  %t68 = getelementptr %"compiler/cond:Global", ptr %t67, i32 0, i32 3
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  store { i64, ptr } %t69, ptr %l43, !tbaa !27
  %t70 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t71 = call { i32, i64, i1 } @compiler_2fcond_2edeclaredKind(ptr %v1, { i64, ptr } %t70)
  store { i32, i64, i1 } %t71, ptr %l44
  br label %bb22
bb22:
  %t72 = load { i32, i64, i1 }, ptr %l44
  store { i32, i64, i1 } %t72, ptr %l4
  %t73 = getelementptr { i32, i64, i1 }, ptr %l4, i32 0, i32 0
  %t74 = load i32, ptr %t73
  store i32 %t74, ptr %l45
  %t75 = load i32, ptr %l45
  store i32 %t75, ptr %l5
  %t76 = getelementptr { i32, i64, i1 }, ptr %l4, i32 0, i32 1
  %t77 = load i64, ptr %t76, !tbaa !24
  store i64 %t77, ptr %l46, !tbaa !24
  %t78 = load i64, ptr %l46, !tbaa !24
  store i64 %t78, ptr %l6, !tbaa !24
  %t79 = getelementptr { i32, i64, i1 }, ptr %l4, i32 0, i32 2
  %t80 = load i1, ptr %t79, !tbaa !21
  store i1 %t80, ptr %l47, !tbaa !21
  %t81 = load i1, ptr %l47, !tbaa !21
  store i1 %t81, ptr %l7, !tbaa !21
  %t82 = load i32, ptr %l5
  store i32 %t82, ptr %l49
  %t83 = load i32, ptr %l49
  %t84 = trunc i64 2 to i32
  %t85 = icmp eq i32 %t83, %t84
  store i1 %t85, ptr %l50, !tbaa !21
  %t86 = load i1, ptr %l50, !tbaa !21
  br i1 %t86, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb27
bb25:
  store %olang.scope zeroinitializer, ptr %s5
  %t87 = load ptr, ptr %l0, !tbaa !29
  store ptr %t87, ptr %l51, !tbaa !29
  %t88 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t88, ptr %l52
  %t89 = load %"compiler/cond:Value", ptr %l3
  store %"compiler/cond:Value" %t89, ptr %l53
  %t90 = load i64, ptr %l6, !tbaa !24
  store i64 %t90, ptr %l54, !tbaa !24
  %t91 = load i1, ptr %l7, !tbaa !21
  store i1 %t91, ptr %l55, !tbaa !21
  %t92 = load ptr, ptr %l51, !tbaa !29
  %t93 = load %"compiler/source:Span", ptr %l52
  %t94 = load %"compiler/cond:Value", ptr %l53
  %t95 = load i64, ptr %l54, !tbaa !24
  %t96 = load i1, ptr %l55, !tbaa !21
  %t97 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eintDeclared(ptr %v0, ptr %t92, %"compiler/source:Span" %t93, %"compiler/cond:Value" %t94, i64 %t95, i1 %t96)
  store %"compiler/cond:Value" %t97, ptr %l56
  br label %bb26
bb26:
  %t98 = load %"compiler/cond:Value", ptr %l56
  store %"compiler/cond:Value" %t98, ptr %l48
  call void @__olang_scope_close(ptr %s5)
  br label %bb64
bb27:
  %t99 = load i32, ptr %l5
  store i32 %t99, ptr %l57
  %t100 = load i32, ptr %l57
  %t101 = trunc i64 3 to i32
  %t102 = icmp eq i32 %t100, %t101
  store i1 %t102, ptr %l58, !tbaa !21
  %t103 = load i1, ptr %l58, !tbaa !21
  br i1 %t103, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb32
bb30:
  store %olang.scope zeroinitializer, ptr %s6
  %t104 = load ptr, ptr %l0, !tbaa !29
  store ptr %t104, ptr %l59, !tbaa !29
  %t105 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t105, ptr %l60
  %t106 = load %"compiler/cond:Value", ptr %l3
  store %"compiler/cond:Value" %t106, ptr %l61
  %t107 = load i64, ptr %l6, !tbaa !24
  store i64 %t107, ptr %l62, !tbaa !24
  %t108 = load ptr, ptr %l59, !tbaa !29
  %t109 = load %"compiler/source:Span", ptr %l60
  %t110 = load %"compiler/cond:Value", ptr %l61
  %t111 = load i64, ptr %l62, !tbaa !24
  %t112 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2efloatDeclared(ptr %v0, ptr %t108, %"compiler/source:Span" %t109, %"compiler/cond:Value" %t110, i64 %t111)
  store %"compiler/cond:Value" %t112, ptr %l63
  br label %bb31
bb31:
  %t113 = load %"compiler/cond:Value", ptr %l63
  store %"compiler/cond:Value" %t113, ptr %l48
  call void @__olang_scope_close(ptr %s6)
  br label %bb64
bb32:
  %t114 = load i32, ptr %l5
  store i32 %t114, ptr %l64
  %t115 = load i32, ptr %l64
  %t116 = trunc i64 1 to i32
  %t117 = icmp eq i32 %t115, %t116
  store i1 %t117, ptr %l65, !tbaa !21
  %t118 = load i1, ptr %l65, !tbaa !21
  br i1 %t118, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb41
bb35:
  store %olang.scope zeroinitializer, ptr %s7
  %t119 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 0
  %t120 = load i32, ptr %t119
  store i32 %t120, ptr %l66
  store ptr %l66, ptr %l67, !tbaa !29
  store i32 1, ptr %l68
  store ptr %l68, ptr %l69, !tbaa !29
  %t121 = load ptr, ptr %l67, !tbaa !29
  %t122 = load ptr, ptr %l69, !tbaa !29
  %t123 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %t121, ptr %t122)
  store i1 %t123, ptr %l70
  br label %bb36
bb36:
  %t124 = load i1, ptr %l70, !tbaa !21
  br i1 %t124, label %bb37, label %bb38
bb37:
  %t125 = load %"compiler/cond:Value", ptr %l3
  store %"compiler/cond:Value" %t125, ptr %l72
  %t126 = load %"compiler/cond:Value", ptr %l72
  store %"compiler/cond:Value" %t126, ptr %l71
  br label %bb40
bb38:
  %t127 = load ptr, ptr %l0, !tbaa !29
  store ptr %t127, ptr %l73, !tbaa !29
  %t128 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t128, ptr %l74
  %t129 = load ptr, ptr %l73, !tbaa !29
  %t130 = load %"compiler/source:Span", ptr %l74
  %t131 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t129, %"compiler/source:Span" %t130)
  store %"compiler/cond:Value" %t131, ptr %l75
  br label %bb39
bb39:
  %t132 = load %"compiler/cond:Value", ptr %l75
  store %"compiler/cond:Value" %t132, ptr %l71
  br label %bb40
bb40:
  %t133 = load %"compiler/cond:Value", ptr %l71
  store %"compiler/cond:Value" %t133, ptr %l48
  call void @__olang_scope_close(ptr %s7)
  br label %bb64
bb41:
  %t134 = load i32, ptr %l5
  store i32 %t134, ptr %l76
  %t135 = load i32, ptr %l76
  %t136 = trunc i64 4 to i32
  %t137 = icmp eq i32 %t135, %t136
  store i1 %t137, ptr %l77, !tbaa !21
  %t138 = load i1, ptr %l77, !tbaa !21
  br i1 %t138, label %bb42, label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb50
bb44:
  store %olang.scope zeroinitializer, ptr %s8
  %t139 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 0
  %t140 = load i32, ptr %t139
  store i32 %t140, ptr %l78
  store ptr %l78, ptr %l79, !tbaa !29
  store i32 4, ptr %l80
  store ptr %l80, ptr %l81, !tbaa !29
  %t141 = load ptr, ptr %l79, !tbaa !29
  %t142 = load ptr, ptr %l81, !tbaa !29
  %t143 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %t141, ptr %t142)
  store i1 %t143, ptr %l82
  br label %bb45
bb45:
  %t144 = load i1, ptr %l82, !tbaa !21
  br i1 %t144, label %bb46, label %bb47
bb46:
  %t145 = load %"compiler/cond:Value", ptr %l3
  store %"compiler/cond:Value" %t145, ptr %l84
  %t146 = load %"compiler/cond:Value", ptr %l84
  store %"compiler/cond:Value" %t146, ptr %l83
  br label %bb49
bb47:
  %t147 = load ptr, ptr %l0, !tbaa !29
  store ptr %t147, ptr %l85, !tbaa !29
  %t148 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t148, ptr %l86
  %t149 = load ptr, ptr %l85, !tbaa !29
  %t150 = load %"compiler/source:Span", ptr %l86
  %t151 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t149, %"compiler/source:Span" %t150)
  store %"compiler/cond:Value" %t151, ptr %l87
  br label %bb48
bb48:
  %t152 = load %"compiler/cond:Value", ptr %l87
  store %"compiler/cond:Value" %t152, ptr %l83
  br label %bb49
bb49:
  %t153 = load %"compiler/cond:Value", ptr %l83
  store %"compiler/cond:Value" %t153, ptr %l48
  call void @__olang_scope_close(ptr %s8)
  br label %bb64
bb50:
  br i1 true, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb63
bb53:
  store %olang.scope zeroinitializer, ptr %s9
  %t154 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 0
  %t155 = load i32, ptr %t154
  store i32 %t155, ptr %l88
  store ptr %l88, ptr %l89, !tbaa !29
  store i32 4, ptr %l90
  store ptr %l90, ptr %l91, !tbaa !29
  %t156 = load ptr, ptr %l89, !tbaa !29
  %t157 = load ptr, ptr %l91, !tbaa !29
  %t158 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %t156, ptr %t157)
  store i1 %t158, ptr %l92
  br label %bb54
bb54:
  %t159 = load i1, ptr %l92, !tbaa !21
  br i1 %t159, label %bb55, label %bb56
bb55:
  store i1 true, ptr %l93, !tbaa !21
  br label %bb58
bb56:
  %t160 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 0
  %t161 = load i32, ptr %t160
  store i32 %t161, ptr %l94
  store ptr %l94, ptr %l95, !tbaa !29
  store i32 1, ptr %l96
  store ptr %l96, ptr %l97, !tbaa !29
  %t162 = load ptr, ptr %l95, !tbaa !29
  %t163 = load ptr, ptr %l97, !tbaa !29
  %t164 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %t162, ptr %t163)
  store i1 %t164, ptr %l98
  br label %bb57
bb57:
  %t165 = load i1, ptr %l98, !tbaa !21
  store i1 %t165, ptr %l93, !tbaa !21
  br label %bb58
bb58:
  %t166 = load i1, ptr %l93, !tbaa !21
  br i1 %t166, label %bb59, label %bb60
bb59:
  %t167 = load %"compiler/cond:Value", ptr %l3
  store %"compiler/cond:Value" %t167, ptr %l100
  %t168 = load %"compiler/cond:Value", ptr %l100
  store %"compiler/cond:Value" %t168, ptr %l99
  br label %bb62
bb60:
  %t169 = load ptr, ptr %l0, !tbaa !29
  store ptr %t169, ptr %l101, !tbaa !29
  %t170 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t170, ptr %l102
  %t171 = load ptr, ptr %l101, !tbaa !29
  %t172 = load %"compiler/source:Span", ptr %l102
  %t173 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t171, %"compiler/source:Span" %t172)
  store %"compiler/cond:Value" %t173, ptr %l103
  br label %bb61
bb61:
  %t174 = load %"compiler/cond:Value", ptr %l103
  store %"compiler/cond:Value" %t174, ptr %l99
  br label %bb62
bb62:
  %t175 = load %"compiler/cond:Value", ptr %l99
  store %"compiler/cond:Value" %t175, ptr %l48
  call void @__olang_scope_close(ptr %s9)
  br label %bb64
bb63:
  call void @__olang_check_failed(ptr @.c31)
  unreachable
bb64:
  call void @__olang_scope_close(ptr %s0)
  %t176 = load %"compiler/cond:Value", ptr %l48
  store %"compiler/cond:Value" %t176, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cond:Value", ptr %rv
  ret %"compiler/cond:Value" %rr
}

define dso_local %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2ebinary(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca i32
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca i32
  %l12 = alloca i1
  %l13 = alloca i32
  %l14 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca %"compiler/source:Span"
  %l17 = alloca i32
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca %"compiler/cond:Value"
  %l21 = alloca i32
  %l22 = alloca i1
  %l23 = alloca i32
  %l24 = alloca i1
  %l25 = alloca i32
  %l26 = alloca i1
  %l27 = alloca i32
  %l28 = alloca i1
  %l29 = alloca i32
  %l30 = alloca i1
  %l31 = alloca i32
  %l32 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca %"compiler/source:Span"
  %l35 = alloca i32
  %l36 = alloca ptr
  %l37 = alloca ptr
  %l38 = alloca %"compiler/cond:Value"
  %l39 = alloca ptr
  %l40 = alloca ptr
  %l41 = alloca %"compiler/cond:Value"
  %l42 = alloca %"compiler/cond:Value"
  %l43 = alloca i32
  %l44 = alloca i1
  %l45 = alloca i32
  %l46 = alloca i1
  %l47 = alloca i32
  %l48 = alloca i1
  %l49 = alloca i32
  %l50 = alloca i1
  %l51 = alloca i32
  %l52 = alloca i1
  %l53 = alloca ptr
  %l54 = alloca %"compiler/source:Span"
  %l55 = alloca i32
  %l56 = alloca ptr
  %l57 = alloca ptr
  %l58 = alloca %"compiler/cond:Value"
  %l59 = alloca ptr
  %l60 = alloca ptr
  %l61 = alloca %"compiler/cond:Value"
  %l62 = alloca %"compiler/cond:Value"
  %l63 = alloca ptr
  %l64 = alloca ptr
  %l65 = alloca %"compiler/cond:Value"
  %l66 = alloca ptr
  %l67 = alloca %"compiler/source:Span"
  %l68 = alloca %"compiler/cond:Value"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca %"compiler/cond:Value"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  %t2 = load ptr, ptr %l3, !tbaa !29
  store ptr %t2, ptr %l7, !tbaa !29
  %t3 = load ptr, ptr %l7, !tbaa !29
  %t4 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t3)
  store %"compiler/source:Span" %t4, ptr %l8
  br label %bb1
bb1:
  %t5 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 1
  %t6 = load i32, ptr %t5, !tbaa !23
  store i32 %t6, ptr %l9, !tbaa !23
  %t7 = load ptr, ptr %l6, !tbaa !29
  %t8 = load i32, ptr %l9, !tbaa !23
  %t9 = call %"compiler/source:Span" @compiler_2fcond_2ecompiler_2fcond_3aEval_2etokenAt(ptr %v0, ptr %t7, i32 %t8)
  store %"compiler/source:Span" %t9, ptr %l10
  br label %bb2
bb2:
  %t10 = load %"compiler/source:Span", ptr %l10
  store %"compiler/source:Span" %t10, ptr %l5
  %t11 = load i32, ptr %l2
  store i32 %t11, ptr %l11
  %t12 = load i32, ptr %l11
  %t13 = trunc i64 47 to i32
  %t14 = icmp eq i32 %t12, %t13
  store i1 %t14, ptr %l12, !tbaa !21
  %t15 = load i1, ptr %l12, !tbaa !21
  br i1 %t15, label %bb3, label %bb4
bb3:
  br label %bb7
bb4:
  %t16 = load i32, ptr %l2
  store i32 %t16, ptr %l13
  %t17 = load i32, ptr %l13
  %t18 = trunc i64 48 to i32
  %t19 = icmp eq i32 %t17, %t18
  store i1 %t19, ptr %l14, !tbaa !21
  %t20 = load i1, ptr %l14, !tbaa !21
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb9
bb7:
  store %olang.scope zeroinitializer, ptr %s1
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l15, !tbaa !29
  %t22 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t22, ptr %l16
  %t23 = load i32, ptr %l2
  store i32 %t23, ptr %l17
  %t24 = load ptr, ptr %l3, !tbaa !29
  store ptr %t24, ptr %l18, !tbaa !29
  %t25 = load ptr, ptr %l4, !tbaa !29
  store ptr %t25, ptr %l19, !tbaa !29
  %t26 = load ptr, ptr %l15, !tbaa !29
  %t27 = load %"compiler/source:Span", ptr %l16
  %t28 = load i32, ptr %l17
  %t29 = load ptr, ptr %l18, !tbaa !29
  %t30 = load ptr, ptr %l19, !tbaa !29
  %t31 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2elogic(ptr %v0, ptr %v1, ptr %v2, ptr %t26, %"compiler/source:Span" %t27, i32 %t28, ptr %t29, ptr %t30)
  store %"compiler/cond:Value" %t31, ptr %l20
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t32 = load %"compiler/cond:Value", ptr %l20
  store %"compiler/cond:Value" %t32, ptr %rv
  br label %ret
bb9:
  %t33 = load i32, ptr %l2
  store i32 %t33, ptr %l21
  %t34 = load i32, ptr %l21
  %t35 = trunc i64 75 to i32
  %t36 = icmp eq i32 %t34, %t35
  store i1 %t36, ptr %l22, !tbaa !21
  %t37 = load i1, ptr %l22, !tbaa !21
  br i1 %t37, label %bb10, label %bb11
bb10:
  br label %bb22
bb11:
  %t38 = load i32, ptr %l2
  store i32 %t38, ptr %l23
  %t39 = load i32, ptr %l23
  %t40 = trunc i64 77 to i32
  %t41 = icmp eq i32 %t39, %t40
  store i1 %t41, ptr %l24, !tbaa !21
  %t42 = load i1, ptr %l24, !tbaa !21
  br i1 %t42, label %bb12, label %bb13
bb12:
  br label %bb22
bb13:
  %t43 = load i32, ptr %l2
  store i32 %t43, ptr %l25
  %t44 = load i32, ptr %l25
  %t45 = trunc i64 79 to i32
  %t46 = icmp eq i32 %t44, %t45
  store i1 %t46, ptr %l26, !tbaa !21
  %t47 = load i1, ptr %l26, !tbaa !21
  br i1 %t47, label %bb14, label %bb15
bb14:
  br label %bb22
bb15:
  %t48 = load i32, ptr %l2
  store i32 %t48, ptr %l27
  %t49 = load i32, ptr %l27
  %t50 = trunc i64 80 to i32
  %t51 = icmp eq i32 %t49, %t50
  store i1 %t51, ptr %l28, !tbaa !21
  %t52 = load i1, ptr %l28, !tbaa !21
  br i1 %t52, label %bb16, label %bb17
bb16:
  br label %bb22
bb17:
  %t53 = load i32, ptr %l2
  store i32 %t53, ptr %l29
  %t54 = load i32, ptr %l29
  %t55 = trunc i64 81 to i32
  %t56 = icmp eq i32 %t54, %t55
  store i1 %t56, ptr %l30, !tbaa !21
  %t57 = load i1, ptr %l30, !tbaa !21
  br i1 %t57, label %bb18, label %bb19
bb18:
  br label %bb22
bb19:
  %t58 = load i32, ptr %l2
  store i32 %t58, ptr %l31
  %t59 = load i32, ptr %l31
  %t60 = trunc i64 82 to i32
  %t61 = icmp eq i32 %t59, %t60
  store i1 %t61, ptr %l32, !tbaa !21
  %t62 = load i1, ptr %l32, !tbaa !21
  br i1 %t62, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb26
bb22:
  store %olang.scope zeroinitializer, ptr %s2
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l33, !tbaa !29
  %t64 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t64, ptr %l34
  %t65 = load i32, ptr %l2
  store i32 %t65, ptr %l35
  %t66 = load ptr, ptr %l0, !tbaa !29
  store ptr %t66, ptr %l36, !tbaa !29
  %t67 = load ptr, ptr %l3, !tbaa !29
  store ptr %t67, ptr %l37, !tbaa !29
  %t68 = load ptr, ptr %l36, !tbaa !29
  %t69 = load ptr, ptr %l37, !tbaa !29
  %t70 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eexpr(ptr %v0, ptr %v1, ptr %t68, ptr %t69)
  store %"compiler/cond:Value" %t70, ptr %l38
  br label %bb23
bb23:
  %t71 = load ptr, ptr %l0, !tbaa !29
  store ptr %t71, ptr %l39, !tbaa !29
  %t72 = load ptr, ptr %l4, !tbaa !29
  store ptr %t72, ptr %l40, !tbaa !29
  %t73 = load ptr, ptr %l39, !tbaa !29
  %t74 = load ptr, ptr %l40, !tbaa !29
  %t75 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eexpr(ptr %v0, ptr %v2, ptr %t73, ptr %t74)
  store %"compiler/cond:Value" %t75, ptr %l41
  br label %bb24
bb24:
  %t76 = load ptr, ptr %l33, !tbaa !29
  %t77 = load %"compiler/source:Span", ptr %l34
  %t78 = load i32, ptr %l35
  %t79 = load %"compiler/cond:Value", ptr %l38
  %t80 = load %"compiler/cond:Value", ptr %l41
  %t81 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2ecompare(ptr %v0, ptr %t76, %"compiler/source:Span" %t77, i32 %t78, %"compiler/cond:Value" %t79, %"compiler/cond:Value" %t80)
  store %"compiler/cond:Value" %t81, ptr %l42
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t82 = load %"compiler/cond:Value", ptr %l42
  store %"compiler/cond:Value" %t82, ptr %rv
  br label %ret
bb26:
  %t83 = load i32, ptr %l2
  store i32 %t83, ptr %l43
  %t84 = load i32, ptr %l43
  %t85 = trunc i64 51 to i32
  %t86 = icmp eq i32 %t84, %t85
  store i1 %t86, ptr %l44, !tbaa !21
  %t87 = load i1, ptr %l44, !tbaa !21
  br i1 %t87, label %bb27, label %bb28
bb27:
  br label %bb37
bb28:
  %t88 = load i32, ptr %l2
  store i32 %t88, ptr %l45
  %t89 = load i32, ptr %l45
  %t90 = trunc i64 52 to i32
  %t91 = icmp eq i32 %t89, %t90
  store i1 %t91, ptr %l46, !tbaa !21
  %t92 = load i1, ptr %l46, !tbaa !21
  br i1 %t92, label %bb29, label %bb30
bb29:
  br label %bb37
bb30:
  %t93 = load i32, ptr %l2
  store i32 %t93, ptr %l47
  %t94 = load i32, ptr %l47
  %t95 = trunc i64 53 to i32
  %t96 = icmp eq i32 %t94, %t95
  store i1 %t96, ptr %l48, !tbaa !21
  %t97 = load i1, ptr %l48, !tbaa !21
  br i1 %t97, label %bb31, label %bb32
bb31:
  br label %bb37
bb32:
  %t98 = load i32, ptr %l2
  store i32 %t98, ptr %l49
  %t99 = load i32, ptr %l49
  %t100 = trunc i64 54 to i32
  %t101 = icmp eq i32 %t99, %t100
  store i1 %t101, ptr %l50, !tbaa !21
  %t102 = load i1, ptr %l50, !tbaa !21
  br i1 %t102, label %bb33, label %bb34
bb33:
  br label %bb37
bb34:
  %t103 = load i32, ptr %l2
  store i32 %t103, ptr %l51
  %t104 = load i32, ptr %l51
  %t105 = trunc i64 55 to i32
  %t106 = icmp eq i32 %t104, %t105
  store i1 %t106, ptr %l52, !tbaa !21
  %t107 = load i1, ptr %l52, !tbaa !21
  br i1 %t107, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb41
bb37:
  store %olang.scope zeroinitializer, ptr %s3
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l53, !tbaa !29
  %t109 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t109, ptr %l54
  %t110 = load i32, ptr %l2
  store i32 %t110, ptr %l55
  %t111 = load ptr, ptr %l0, !tbaa !29
  store ptr %t111, ptr %l56, !tbaa !29
  %t112 = load ptr, ptr %l3, !tbaa !29
  store ptr %t112, ptr %l57, !tbaa !29
  %t113 = load ptr, ptr %l56, !tbaa !29
  %t114 = load ptr, ptr %l57, !tbaa !29
  %t115 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eexpr(ptr %v0, ptr %v1, ptr %t113, ptr %t114)
  store %"compiler/cond:Value" %t115, ptr %l58
  br label %bb38
bb38:
  %t116 = load ptr, ptr %l0, !tbaa !29
  store ptr %t116, ptr %l59, !tbaa !29
  %t117 = load ptr, ptr %l4, !tbaa !29
  store ptr %t117, ptr %l60, !tbaa !29
  %t118 = load ptr, ptr %l59, !tbaa !29
  %t119 = load ptr, ptr %l60, !tbaa !29
  %t120 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eexpr(ptr %v0, ptr %v2, ptr %t118, ptr %t119)
  store %"compiler/cond:Value" %t120, ptr %l61
  br label %bb39
bb39:
  %t121 = load ptr, ptr %l53, !tbaa !29
  %t122 = load %"compiler/source:Span", ptr %l54
  %t123 = load i32, ptr %l55
  %t124 = load %"compiler/cond:Value", ptr %l58
  %t125 = load %"compiler/cond:Value", ptr %l61
  %t126 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2earith(ptr %v0, ptr %t121, %"compiler/source:Span" %t122, i32 %t123, %"compiler/cond:Value" %t124, %"compiler/cond:Value" %t125)
  store %"compiler/cond:Value" %t126, ptr %l62
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t127 = load %"compiler/cond:Value", ptr %l62
  store %"compiler/cond:Value" %t127, ptr %rv
  br label %ret
bb41:
  store %olang.scope zeroinitializer, ptr %s4
  %t128 = load ptr, ptr %l0, !tbaa !29
  store ptr %t128, ptr %l63, !tbaa !29
  %t129 = load ptr, ptr %l3, !tbaa !29
  store ptr %t129, ptr %l64, !tbaa !29
  %t130 = load ptr, ptr %l63, !tbaa !29
  %t131 = load ptr, ptr %l64, !tbaa !29
  %t132 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eexpr(ptr %v0, ptr %v1, ptr %t130, ptr %t131)
  store %"compiler/cond:Value" %t132, ptr %l65
  br label %bb42
bb42:
  %t133 = load ptr, ptr %l0, !tbaa !29
  store ptr %t133, ptr %l66, !tbaa !29
  %t134 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t134, ptr %l67
  %t135 = load ptr, ptr %l66, !tbaa !29
  %t136 = load %"compiler/source:Span", ptr %l67
  %t137 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t135, %"compiler/source:Span" %t136)
  store %"compiler/cond:Value" %t137, ptr %l68
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t138 = load %"compiler/cond:Value", ptr %l68
  store %"compiler/cond:Value" %t138, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cond:Value", ptr %rv
  ret %"compiler/cond:Value" %rr
}

define dso_local %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2ecompare(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, %"compiler/cond:Value" %a3, %"compiler/cond:Value" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca %"compiler/cond:Value"
  %l4 = alloca %"compiler/cond:Value"
  %l5 = alloca i1
  %l6 = alloca i64
  %l7 = alloca { i1, i64, i1 }
  %l8 = alloca i1
  %l9 = alloca double
  %l10 = alloca double
  %l11 = alloca { i1, double }
  %l12 = alloca i1
  %l13 = alloca double
  %l14 = alloca { i1, double }
  %l15 = alloca i1
  %l16 = alloca double
  %l17 = alloca i32
  %l18 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca ptr
  %l21 = alloca i1
  %l22 = alloca i1
  %l23 = alloca i32
  %l24 = alloca ptr
  %l25 = alloca i32
  %l26 = alloca ptr
  %l27 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca i64
  %l30 = alloca i1
  %l31 = alloca %"compiler/cond:Value"
  %l32 = alloca %"compiler/cond:Value"
  %l33 = alloca %"compiler/cond:Value"
  %l34 = alloca i32
  %l35 = alloca ptr
  %l36 = alloca i32
  %l37 = alloca ptr
  %l38 = alloca i1
  %l39 = alloca i1
  %l40 = alloca i32
  %l41 = alloca ptr
  %l42 = alloca i32
  %l43 = alloca ptr
  %l44 = alloca i1
  %l45 = alloca i32
  %l46 = alloca ptr
  %l47 = alloca i32
  %l48 = alloca ptr
  %l49 = alloca i1
  %l50 = alloca i1
  %l51 = alloca i32
  %l52 = alloca ptr
  %l53 = alloca i32
  %l54 = alloca ptr
  %l55 = alloca i1
  %l56 = alloca i1
  %l57 = alloca i1
  %l58 = alloca ptr
  %l59 = alloca ptr
  %l60 = alloca i64
  %l61 = alloca { i64, ptr }
  %l62 = alloca ptr
  %l63 = alloca ptr
  %l64 = alloca i64
  %l65 = alloca { i64, ptr }
  %l66 = alloca i1
  %l67 = alloca i64
  %l68 = alloca i32
  %l69 = alloca ptr
  %l70 = alloca i32
  %l71 = alloca ptr
  %l72 = alloca i1
  %l73 = alloca i1
  %l74 = alloca i32
  %l75 = alloca ptr
  %l76 = alloca i32
  %l77 = alloca ptr
  %l78 = alloca i1
  %l79 = alloca i1
  %l80 = alloca i1
  %l81 = alloca i64
  %l82 = alloca i64
  %l83 = alloca i1
  %l84 = alloca i64
  %l85 = alloca i32
  %l86 = alloca ptr
  %l87 = alloca i32
  %l88 = alloca ptr
  %l89 = alloca i1
  %l90 = alloca i1
  %l91 = alloca i32
  %l92 = alloca ptr
  %l93 = alloca i32
  %l94 = alloca ptr
  %l95 = alloca i1
  %l96 = alloca %"compiler/cond:Value"
  %l97 = alloca %"compiler/cond:Value"
  %l98 = alloca { i1, i64, i1 }
  %l99 = alloca i1
  %l100 = alloca i1
  %l101 = alloca i1
  %l102 = alloca ptr
  %l103 = alloca %"compiler/source:Span"
  %l104 = alloca ptr
  %l105 = alloca %"compiler/source:Span"
  %l106 = alloca { i64, ptr }
  %l107 = alloca { i64, ptr }
  %l108 = alloca %"compiler/msgs:Msg"
  %l109 = alloca %"compiler/cond:Value"
  %l110 = alloca i64
  %l111 = alloca i64
  %l112 = alloca i1
  %l113 = alloca i64
  %l114 = alloca i64
  %l115 = alloca i64
  %l116 = alloca i1
  %l117 = alloca i64
  %l118 = alloca %"compiler/cond:Value"
  %l119 = alloca i1
  %l120 = alloca i1
  %l121 = alloca %"compiler/cond:Value"
  %l122 = alloca i1
  %l123 = alloca i32
  %l124 = alloca ptr
  %l125 = alloca i32
  %l126 = alloca ptr
  %l127 = alloca i1
  %l128 = alloca i1
  %l129 = alloca i64
  %l130 = alloca i1
  %l131 = alloca i1
  %l132 = alloca i32
  %l133 = alloca ptr
  %l134 = alloca i32
  %l135 = alloca ptr
  %l136 = alloca i1
  %l137 = alloca i1
  %l138 = alloca i64
  %l139 = alloca i1
  %l140 = alloca ptr
  %l141 = alloca %"compiler/source:Span"
  %l142 = alloca ptr
  %l143 = alloca %"compiler/source:Span"
  %l144 = alloca { i64, ptr }
  %l145 = alloca { i64, ptr }
  %l146 = alloca %"compiler/msgs:Msg"
  %l147 = alloca %"compiler/cond:Value"
  %l148 = alloca double
  %l149 = alloca double
  %l150 = alloca i32
  %l151 = alloca ptr
  %l152 = alloca i32
  %l153 = alloca ptr
  %l154 = alloca i1
  %l155 = alloca %"compiler/cond:Value"
  %l156 = alloca { i1, double }
  %l157 = alloca i1
  %l158 = alloca double
  %l159 = alloca i1
  %l160 = alloca i1
  %l161 = alloca ptr
  %l162 = alloca %"compiler/source:Span"
  %l163 = alloca %"compiler/cond:Value"
  %l164 = alloca double
  %l165 = alloca i32
  %l166 = alloca ptr
  %l167 = alloca i32
  %l168 = alloca ptr
  %l169 = alloca i1
  %l170 = alloca %"compiler/cond:Value"
  %l171 = alloca { i1, double }
  %l172 = alloca i1
  %l173 = alloca double
  %l174 = alloca i1
  %l175 = alloca i1
  %l176 = alloca ptr
  %l177 = alloca %"compiler/source:Span"
  %l178 = alloca %"compiler/cond:Value"
  %l179 = alloca double
  %l180 = alloca double
  %l181 = alloca double
  %l182 = alloca i1
  %l183 = alloca i1
  %l184 = alloca double
  %l185 = alloca double
  %l186 = alloca i1
  %l187 = alloca i32
  %l188 = alloca ptr
  %l189 = alloca i32
  %l190 = alloca ptr
  %l191 = alloca i1
  %l192 = alloca %"compiler/cond:Value"
  %l193 = alloca double
  %l194 = alloca double
  %l195 = alloca i1
  %l196 = alloca i64
  %l197 = alloca double
  %l198 = alloca double
  %l199 = alloca i1
  %l200 = alloca i64
  %l201 = alloca ptr
  %l202 = alloca %"compiler/source:Span"
  %l203 = alloca ptr
  %l204 = alloca %"compiler/source:Span"
  %l205 = alloca { i64, ptr }
  %l206 = alloca { i64, ptr }
  %l207 = alloca %"compiler/msgs:Msg"
  %l208 = alloca %"compiler/cond:Value"
  %l209 = alloca %"compiler/cond:Value"
  %l210 = alloca i32
  %l211 = alloca i1
  %l212 = alloca i64
  %l213 = alloca i1
  %l214 = alloca %"compiler/cond:Value"
  %l215 = alloca i32
  %l216 = alloca i1
  %l217 = alloca i64
  %l218 = alloca i1
  %l219 = alloca %"compiler/cond:Value"
  %l220 = alloca i32
  %l221 = alloca i1
  %l222 = alloca i64
  %l223 = alloca i1
  %l224 = alloca %"compiler/cond:Value"
  %l225 = alloca i32
  %l226 = alloca i1
  %l227 = alloca i64
  %l228 = alloca i1
  %l229 = alloca %"compiler/cond:Value"
  %l230 = alloca i32
  %l231 = alloca i1
  %l232 = alloca i64
  %l233 = alloca i1
  %l234 = alloca %"compiler/cond:Value"
  %l235 = alloca i64
  %l236 = alloca i1
  %l237 = alloca %"compiler/cond:Value"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %rv = alloca %"compiler/cond:Value"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/cond:Value" %a3, ptr %l3
  store %"compiler/cond:Value" %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 0
  %t2 = load i32, ptr %t1
  store i32 %t2, ptr %l17
  store ptr %l17, ptr %l18, !tbaa !29
  store i32 0, ptr %l19
  store ptr %l19, ptr %l20, !tbaa !29
  %t3 = load ptr, ptr %l18, !tbaa !29
  %t4 = load ptr, ptr %l20, !tbaa !29
  %t5 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %t3, ptr %t4)
  store i1 %t5, ptr %l21
  br label %bb1
bb1:
  %t6 = load i1, ptr %l21, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb5
bb3:
  %t7 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l23
  store ptr %l23, ptr %l24, !tbaa !29
  store i32 0, ptr %l25
  store ptr %l25, ptr %l26, !tbaa !29
  %t9 = load ptr, ptr %l24, !tbaa !29
  %t10 = load ptr, ptr %l26, !tbaa !29
  %t11 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %t9, ptr %t10)
  store i1 %t11, ptr %l27
  br label %bb4
bb4:
  %t12 = load i1, ptr %l27, !tbaa !21
  store i1 %t12, ptr %l22, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l22, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l28, !tbaa !29
  %t15 = load ptr, ptr %l28, !tbaa !29
  %t16 = getelementptr %"compiler/cond:Eval", ptr %t15, i32 0, i32 10
  %t17 = load i64, ptr %t16, !tbaa !24
  store i64 %t17, ptr %l29, !tbaa !24
  %t18 = load i64, ptr %l29, !tbaa !24
  %t19 = icmp sgt i64 %t18, 0
  store i1 %t19, ptr %l30, !tbaa !21
  %t20 = load i1, ptr %l30, !tbaa !21
  br i1 %t20, label %bb8, label %bb9
bb7:
  br label %bb13
bb8:
  %t21 = call %"compiler/cond:Value" @compiler_2fcond_2eboolValue(i1 false)
  store %"compiler/cond:Value" %t21, ptr %l32
  br label %bb10
bb9:
  %t22 = call %"compiler/cond:Value" @compiler_2fcond_2enone()
  store %"compiler/cond:Value" %t22, ptr %l33
  br label %bb11
bb10:
  %t23 = load %"compiler/cond:Value", ptr %l32
  store %"compiler/cond:Value" %t23, ptr %l31
  br label %bb12
bb11:
  %t24 = load %"compiler/cond:Value", ptr %l33
  store %"compiler/cond:Value" %t24, ptr %l31
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/cond:Value", ptr %l31
  store %"compiler/cond:Value" %t25, ptr %rv
  br label %ret
bb13:
  %t26 = load i32, ptr %l2
  store i32 %t26, ptr %l34
  store ptr %l34, ptr %l35, !tbaa !29
  store i32 75, ptr %l36
  store ptr %l36, ptr %l37, !tbaa !29
  %t27 = load ptr, ptr %l35, !tbaa !29
  %t28 = load ptr, ptr %l37, !tbaa !29
  %t29 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t27, ptr %t28)
  store i1 %t29, ptr %l38
  br label %bb14
bb14:
  %t30 = load i1, ptr %l38, !tbaa !21
  br i1 %t30, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb18
bb16:
  %t31 = load i32, ptr %l2
  store i32 %t31, ptr %l40
  store ptr %l40, ptr %l41, !tbaa !29
  store i32 77, ptr %l42
  store ptr %l42, ptr %l43, !tbaa !29
  %t32 = load ptr, ptr %l41, !tbaa !29
  %t33 = load ptr, ptr %l43, !tbaa !29
  %t34 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t32, ptr %t33)
  store i1 %t34, ptr %l44
  br label %bb17
bb17:
  %t35 = load i1, ptr %l44, !tbaa !21
  store i1 %t35, ptr %l39, !tbaa !21
  br label %bb18
bb18:
  %t36 = load i1, ptr %l39, !tbaa !21
  store i1 %t36, ptr %l5, !tbaa !21
  store i64 0, ptr %l6, !tbaa !24
  %t37 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 0
  %t38 = load i32, ptr %t37
  store i32 %t38, ptr %l45
  store ptr %l45, ptr %l46, !tbaa !29
  store i32 4, ptr %l47
  store ptr %l47, ptr %l48, !tbaa !29
  %t39 = load ptr, ptr %l46, !tbaa !29
  %t40 = load ptr, ptr %l48, !tbaa !29
  %t41 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %t39, ptr %t40)
  store i1 %t41, ptr %l49
  br label %bb19
bb19:
  %t42 = load i1, ptr %l49, !tbaa !21
  br i1 %t42, label %bb20, label %bb21
bb20:
  %t43 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 0
  %t44 = load i32, ptr %t43
  store i32 %t44, ptr %l51
  store ptr %l51, ptr %l52, !tbaa !29
  store i32 4, ptr %l53
  store ptr %l53, ptr %l54, !tbaa !29
  %t45 = load ptr, ptr %l52, !tbaa !29
  %t46 = load ptr, ptr %l54, !tbaa !29
  %t47 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %t45, ptr %t46)
  store i1 %t47, ptr %l55
  br label %bb22
bb21:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb23
bb22:
  %t48 = load i1, ptr %l55, !tbaa !21
  store i1 %t48, ptr %l50, !tbaa !21
  br label %bb23
bb23:
  %t49 = load i1, ptr %l50, !tbaa !21
  br i1 %t49, label %bb24, label %bb25
bb24:
  %t50 = load i1, ptr %l5, !tbaa !21
  store i1 %t50, ptr %l57, !tbaa !21
  %t51 = load i1, ptr %l57, !tbaa !21
  store i1 %t51, ptr %l56, !tbaa !21
  br label %bb26
bb25:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb26
bb26:
  %t52 = load i1, ptr %l56, !tbaa !21
  br i1 %t52, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s2
  %t53 = load ptr, ptr %l0, !tbaa !29
  store ptr %t53, ptr %l58, !tbaa !29
  %t54 = load ptr, ptr %l58, !tbaa !29
  %t55 = getelementptr %"compiler/cond:Eval", ptr %t54, i32 0, i32 12
  store ptr %t55, ptr %l59, !tbaa !29
  %t56 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 3
  %t57 = load i64, ptr %t56, !tbaa !24
  store i64 %t57, ptr %l60, !tbaa !24
  %t58 = load ptr, ptr %l59, !tbaa !29
  %t59 = load i64, ptr %l60, !tbaa !24
  %t60 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t58, i64 %t59)
  store { i64, ptr } %t60, ptr %l61
  br label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s3
  %t61 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 0
  %t62 = load i32, ptr %t61
  store i32 %t62, ptr %l68
  store ptr %l68, ptr %l69, !tbaa !29
  store i32 1, ptr %l70
  store ptr %l70, ptr %l71, !tbaa !29
  %t63 = load ptr, ptr %l69, !tbaa !29
  %t64 = load ptr, ptr %l71, !tbaa !29
  %t65 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %t63, ptr %t64)
  store i1 %t65, ptr %l72
  br label %bb35
bb29:
  %t66 = load ptr, ptr %l0, !tbaa !29
  store ptr %t66, ptr %l62, !tbaa !29
  %t67 = load ptr, ptr %l62, !tbaa !29
  %t68 = getelementptr %"compiler/cond:Eval", ptr %t67, i32 0, i32 12
  store ptr %t68, ptr %l63, !tbaa !29
  %t69 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 3
  %t70 = load i64, ptr %t69, !tbaa !24
  store i64 %t70, ptr %l64, !tbaa !24
  %t71 = load ptr, ptr %l63, !tbaa !29
  %t72 = load i64, ptr %l64, !tbaa !24
  %t73 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t71, i64 %t72)
  store { i64, ptr } %t73, ptr %l65
  br label %bb30
bb30:
  %t74 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t75 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t76 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v0, { i64, ptr } %t74, { i64, ptr } %t75)
  store i1 %t76, ptr %l66
  br label %bb31
bb31:
  %t77 = load i1, ptr %l66, !tbaa !21
  br i1 %t77, label %bb32, label %bb33
bb32:
  store i64 0, ptr %l67, !tbaa !24
  br label %bb34
bb33:
  store i64 1, ptr %l67, !tbaa !24
  br label %bb34
bb34:
  %t78 = load i64, ptr %l67, !tbaa !24
  store i64 %t78, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb130
bb35:
  %t79 = load i1, ptr %l72, !tbaa !21
  br i1 %t79, label %bb36, label %bb37
bb36:
  %t80 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 0
  %t81 = load i32, ptr %t80
  store i32 %t81, ptr %l74
  store ptr %l74, ptr %l75, !tbaa !29
  store i32 1, ptr %l76
  store ptr %l76, ptr %l77, !tbaa !29
  %t82 = load ptr, ptr %l75, !tbaa !29
  %t83 = load ptr, ptr %l77, !tbaa !29
  %t84 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %t82, ptr %t83)
  store i1 %t84, ptr %l78
  br label %bb38
bb37:
  store i1 false, ptr %l73, !tbaa !21
  br label %bb39
bb38:
  %t85 = load i1, ptr %l78, !tbaa !21
  store i1 %t85, ptr %l73, !tbaa !21
  br label %bb39
bb39:
  %t86 = load i1, ptr %l73, !tbaa !21
  br i1 %t86, label %bb40, label %bb41
bb40:
  %t87 = load i1, ptr %l5, !tbaa !21
  store i1 %t87, ptr %l80, !tbaa !21
  %t88 = load i1, ptr %l80, !tbaa !21
  store i1 %t88, ptr %l79, !tbaa !21
  br label %bb42
bb41:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb42
bb42:
  %t89 = load i1, ptr %l79, !tbaa !21
  br i1 %t89, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s4
  %t90 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 1
  %t91 = load i64, ptr %t90, !tbaa !24
  store i64 %t91, ptr %l81, !tbaa !24
  %t92 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 1
  %t93 = load i64, ptr %t92, !tbaa !24
  store i64 %t93, ptr %l82, !tbaa !24
  %t94 = load i64, ptr %l81, !tbaa !24
  %t95 = load i64, ptr %l82, !tbaa !24
  %t96 = icmp eq i64 %t94, %t95
  store i1 %t96, ptr %l83, !tbaa !21
  %t97 = load i1, ptr %l83, !tbaa !21
  br i1 %t97, label %bb45, label %bb46
bb44:
  store %olang.scope zeroinitializer, ptr %s5
  %t98 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 0
  %t99 = load i32, ptr %t98
  store i32 %t99, ptr %l85
  store ptr %l85, ptr %l86, !tbaa !29
  store i32 2, ptr %l87
  store ptr %l87, ptr %l88, !tbaa !29
  %t100 = load ptr, ptr %l86, !tbaa !29
  %t101 = load ptr, ptr %l88, !tbaa !29
  %t102 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %t100, ptr %t101)
  store i1 %t102, ptr %l89
  br label %bb48
bb45:
  store i64 0, ptr %l84, !tbaa !24
  br label %bb47
bb46:
  store i64 1, ptr %l84, !tbaa !24
  br label %bb47
bb47:
  %t103 = load i64, ptr %l84, !tbaa !24
  store i64 %t103, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb129
bb48:
  %t104 = load i1, ptr %l89, !tbaa !21
  br i1 %t104, label %bb49, label %bb50
bb49:
  %t105 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 0
  %t106 = load i32, ptr %t105
  store i32 %t106, ptr %l91
  store ptr %l91, ptr %l92, !tbaa !29
  store i32 2, ptr %l93
  store ptr %l93, ptr %l94, !tbaa !29
  %t107 = load ptr, ptr %l92, !tbaa !29
  %t108 = load ptr, ptr %l94, !tbaa !29
  %t109 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %t107, ptr %t108)
  store i1 %t109, ptr %l95
  br label %bb51
bb50:
  store i1 false, ptr %l90, !tbaa !21
  br label %bb52
bb51:
  %t110 = load i1, ptr %l95, !tbaa !21
  store i1 %t110, ptr %l90, !tbaa !21
  br label %bb52
bb52:
  %t111 = load i1, ptr %l90, !tbaa !21
  br i1 %t111, label %bb53, label %bb54
bb53:
  store %olang.scope zeroinitializer, ptr %s6
  %t112 = load %"compiler/cond:Value", ptr %l3
  store %"compiler/cond:Value" %t112, ptr %l96
  %t113 = load %"compiler/cond:Value", ptr %l4
  store %"compiler/cond:Value" %t113, ptr %l97
  %t114 = load %"compiler/cond:Value", ptr %l96
  %t115 = load %"compiler/cond:Value", ptr %l97
  %t116 = call { i1, i64, i1 } @compiler_2fcond_2emeet(%"compiler/cond:Value" %t114, %"compiler/cond:Value" %t115)
  store { i1, i64, i1 } %t116, ptr %l98
  br label %bb55
bb54:
  store %olang.scope zeroinitializer, ptr %s8
  %t117 = load %"compiler/cond:Value", ptr %l3
  store %"compiler/cond:Value" %t117, ptr %l118
  %t118 = load %"compiler/cond:Value", ptr %l118
  %t119 = call i1 @compiler_2fcond_2enumeric(%"compiler/cond:Value" %t118)
  store i1 %t119, ptr %l119
  br label %bb68
bb55:
  %t120 = load { i1, i64, i1 }, ptr %l98
  store { i1, i64, i1 } %t120, ptr %l7
  %t121 = getelementptr { i1, i64, i1 }, ptr %l7, i32 0, i32 0
  %t122 = load i1, ptr %t121, !tbaa !21
  store i1 %t122, ptr %l99, !tbaa !21
  %t123 = load i1, ptr %l99, !tbaa !21
  store i1 %t123, ptr %l8, !tbaa !21
  %t124 = load i1, ptr %l8, !tbaa !21
  store i1 %t124, ptr %l100, !tbaa !21
  %t125 = load i1, ptr %l100, !tbaa !21
  %t126 = xor i1 %t125, true
  store i1 %t126, ptr %l101, !tbaa !21
  %t127 = load i1, ptr %l101, !tbaa !21
  br i1 %t127, label %bb56, label %bb57
bb56:
  store %olang.scope zeroinitializer, ptr %s7
  %t128 = load ptr, ptr %l0, !tbaa !29
  store ptr %t128, ptr %l102, !tbaa !29
  %t129 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t129, ptr %l103
  %t130 = load ptr, ptr %l0, !tbaa !29
  store ptr %t130, ptr %l104, !tbaa !29
  %t131 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t131, ptr %l105
  %t132 = load ptr, ptr %l104, !tbaa !29
  %t133 = load %"compiler/source:Span", ptr %l105
  %t134 = call { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aEval_2etokText(ptr %v0, ptr %v0, ptr %t132, %"compiler/source:Span" %t133)
  store { i64, ptr } %t134, ptr %l106
  br label %bb58
bb57:
  br label %bb61
bb58:
  %t135 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t135, 0
  %t137 = extractvalue { i64, ptr } %t135, 1
  %t138 = mul i64 %t136, 1
  %t139 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t138)
  call void @llvm.memcpy.p0.p0.i64(ptr %t139, ptr %t137, i64 %t138, i1 false)
  %t140 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t141 = insertvalue { i64, ptr } %t140, ptr %t139, 1
  store { i64, ptr } %t141, ptr %l107, !tbaa !27
  %t142 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t143 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondNoMeet(ptr %v0, ptr %v0, { i64, ptr } %t142)
  store %"compiler/msgs:Msg" %t143, ptr %l108
  br label %bb59
bb59:
  %t144 = load ptr, ptr %l102, !tbaa !29
  %t145 = load %"compiler/source:Span", ptr %l103
  %t146 = load %"compiler/msgs:Msg", ptr %l108
  %t147 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2efail(ptr %v0, ptr %v0, ptr %t144, %"compiler/source:Span" %t145, %"compiler/msgs:Msg" %t146)
  store %"compiler/cond:Value" %t147, ptr %l109
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t148 = load %"compiler/cond:Value", ptr %l109
  store %"compiler/cond:Value" %t148, ptr %rv
  br label %ret
bb61:
  %t149 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 1
  %t150 = load i64, ptr %t149, !tbaa !24
  store i64 %t150, ptr %l110, !tbaa !24
  %t151 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 1
  %t152 = load i64, ptr %t151, !tbaa !24
  store i64 %t152, ptr %l111, !tbaa !24
  %t153 = load i64, ptr %l110, !tbaa !24
  %t154 = load i64, ptr %l111, !tbaa !24
  %t155 = icmp slt i64 %t153, %t154
  store i1 %t155, ptr %l112, !tbaa !21
  %t156 = load i1, ptr %l112, !tbaa !21
  br i1 %t156, label %bb62, label %bb63
bb62:
  store i64 -1, ptr %l113, !tbaa !24
  br label %bb67
bb63:
  %t157 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 1
  %t158 = load i64, ptr %t157, !tbaa !24
  store i64 %t158, ptr %l114, !tbaa !24
  %t159 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 1
  %t160 = load i64, ptr %t159, !tbaa !24
  store i64 %t160, ptr %l115, !tbaa !24
  %t161 = load i64, ptr %l114, !tbaa !24
  %t162 = load i64, ptr %l115, !tbaa !24
  %t163 = icmp sgt i64 %t161, %t162
  store i1 %t163, ptr %l116, !tbaa !21
  %t164 = load i1, ptr %l116, !tbaa !21
  br i1 %t164, label %bb64, label %bb65
bb64:
  store i64 1, ptr %l117, !tbaa !24
  br label %bb66
bb65:
  store i64 0, ptr %l117, !tbaa !24
  br label %bb66
bb66:
  %t165 = load i64, ptr %l117, !tbaa !24
  store i64 %t165, ptr %l113, !tbaa !24
  br label %bb67
bb67:
  %t166 = load i64, ptr %l113, !tbaa !24
  store i64 %t166, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb128
bb68:
  %t167 = load i1, ptr %l119, !tbaa !21
  br i1 %t167, label %bb69, label %bb70
bb69:
  %t168 = load %"compiler/cond:Value", ptr %l4
  store %"compiler/cond:Value" %t168, ptr %l121
  %t169 = load %"compiler/cond:Value", ptr %l121
  %t170 = call i1 @compiler_2fcond_2enumeric(%"compiler/cond:Value" %t169)
  store i1 %t170, ptr %l122
  br label %bb71
bb70:
  store i1 false, ptr %l120, !tbaa !21
  br label %bb72
bb71:
  %t171 = load i1, ptr %l122, !tbaa !21
  store i1 %t171, ptr %l120, !tbaa !21
  br label %bb72
bb72:
  %t172 = load i1, ptr %l120, !tbaa !21
  br i1 %t172, label %bb73, label %bb74
bb73:
  store %olang.scope zeroinitializer, ptr %s9
  %t173 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 0
  %t174 = load i32, ptr %t173
  store i32 %t174, ptr %l123
  store ptr %l123, ptr %l124, !tbaa !29
  store i32 2, ptr %l125
  store ptr %l125, ptr %l126, !tbaa !29
  %t175 = load ptr, ptr %l124, !tbaa !29
  %t176 = load ptr, ptr %l126, !tbaa !29
  %t177 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %t175, ptr %t176)
  store i1 %t177, ptr %l127
  br label %bb75
bb74:
  store %olang.scope zeroinitializer, ptr %s16
  %t178 = load ptr, ptr %l0, !tbaa !29
  store ptr %t178, ptr %l201, !tbaa !29
  %t179 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t179, ptr %l202
  %t180 = load ptr, ptr %l0, !tbaa !29
  store ptr %t180, ptr %l203, !tbaa !29
  %t181 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t181, ptr %l204
  %t182 = load ptr, ptr %l203, !tbaa !29
  %t183 = load %"compiler/source:Span", ptr %l204
  %t184 = call { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aEval_2etokText(ptr %v0, ptr %v0, ptr %t182, %"compiler/source:Span" %t183)
  store { i64, ptr } %t184, ptr %l205
  br label %bb124
bb75:
  %t185 = load i1, ptr %l127, !tbaa !21
  br i1 %t185, label %bb76, label %bb77
bb76:
  %t186 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 4
  %t187 = load i64, ptr %t186, !tbaa !24
  store i64 %t187, ptr %l129, !tbaa !24
  %t188 = load i64, ptr %l129, !tbaa !24
  %t189 = icmp ne i64 %t188, 0
  store i1 %t189, ptr %l130, !tbaa !21
  %t190 = load i1, ptr %l130, !tbaa !21
  store i1 %t190, ptr %l128, !tbaa !21
  br label %bb78
bb77:
  store i1 false, ptr %l128, !tbaa !21
  br label %bb78
bb78:
  %t191 = load i1, ptr %l128, !tbaa !21
  br i1 %t191, label %bb79, label %bb80
bb79:
  store i1 true, ptr %l131, !tbaa !21
  br label %bb85
bb80:
  %t192 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 0
  %t193 = load i32, ptr %t192
  store i32 %t193, ptr %l132
  store ptr %l132, ptr %l133, !tbaa !29
  store i32 2, ptr %l134
  store ptr %l134, ptr %l135, !tbaa !29
  %t194 = load ptr, ptr %l133, !tbaa !29
  %t195 = load ptr, ptr %l135, !tbaa !29
  %t196 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %t194, ptr %t195)
  store i1 %t196, ptr %l136
  br label %bb81
bb81:
  %t197 = load i1, ptr %l136, !tbaa !21
  br i1 %t197, label %bb82, label %bb83
bb82:
  %t198 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 4
  %t199 = load i64, ptr %t198, !tbaa !24
  store i64 %t199, ptr %l138, !tbaa !24
  %t200 = load i64, ptr %l138, !tbaa !24
  %t201 = icmp ne i64 %t200, 0
  store i1 %t201, ptr %l139, !tbaa !21
  %t202 = load i1, ptr %l139, !tbaa !21
  store i1 %t202, ptr %l137, !tbaa !21
  br label %bb84
bb83:
  store i1 false, ptr %l137, !tbaa !21
  br label %bb84
bb84:
  %t203 = load i1, ptr %l137, !tbaa !21
  store i1 %t203, ptr %l131, !tbaa !21
  br label %bb85
bb85:
  %t204 = load i1, ptr %l131, !tbaa !21
  br i1 %t204, label %bb86, label %bb87
bb86:
  store %olang.scope zeroinitializer, ptr %s10
  %t205 = load ptr, ptr %l0, !tbaa !29
  store ptr %t205, ptr %l140, !tbaa !29
  %t206 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t206, ptr %l141
  %t207 = load ptr, ptr %l0, !tbaa !29
  store ptr %t207, ptr %l142, !tbaa !29
  %t208 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t208, ptr %l143
  %t209 = load ptr, ptr %l142, !tbaa !29
  %t210 = load %"compiler/source:Span", ptr %l143
  %t211 = call { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aEval_2etokText(ptr %v0, ptr %v0, ptr %t209, %"compiler/source:Span" %t210)
  store { i64, ptr } %t211, ptr %l144
  br label %bb88
bb87:
  br label %bb91
bb88:
  %t212 = load { i64, ptr }, ptr %l144, !tbaa !27
  %t213 = extractvalue { i64, ptr } %t212, 0
  %t214 = extractvalue { i64, ptr } %t212, 1
  %t215 = mul i64 %t213, 1
  %t216 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t215)
  call void @llvm.memcpy.p0.p0.i64(ptr %t216, ptr %t214, i64 %t215, i1 false)
  %t217 = insertvalue { i64, ptr } undef, i64 %t213, 0
  %t218 = insertvalue { i64, ptr } %t217, ptr %t216, 1
  store { i64, ptr } %t218, ptr %l145, !tbaa !27
  %t219 = load { i64, ptr }, ptr %l145, !tbaa !27
  %t220 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondNoMeet(ptr %v0, ptr %v0, { i64, ptr } %t219)
  store %"compiler/msgs:Msg" %t220, ptr %l146
  br label %bb89
bb89:
  %t221 = load ptr, ptr %l140, !tbaa !29
  %t222 = load %"compiler/source:Span", ptr %l141
  %t223 = load %"compiler/msgs:Msg", ptr %l146
  %t224 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2efail(ptr %v0, ptr %v0, ptr %t221, %"compiler/source:Span" %t222, %"compiler/msgs:Msg" %t223)
  store %"compiler/cond:Value" %t224, ptr %l147
  br label %bb90
bb90:
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t225 = load %"compiler/cond:Value", ptr %l147
  store %"compiler/cond:Value" %t225, ptr %rv
  br label %ret
bb91:
  %t226 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 2
  %t227 = load double, ptr %t226, !tbaa !26
  store double %t227, ptr %l148, !tbaa !26
  %t228 = load double, ptr %l148, !tbaa !26
  store double %t228, ptr %l9, !tbaa !26
  %t229 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 2
  %t230 = load double, ptr %t229, !tbaa !26
  store double %t230, ptr %l149, !tbaa !26
  %t231 = load double, ptr %l149, !tbaa !26
  store double %t231, ptr %l10, !tbaa !26
  %t232 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 0
  %t233 = load i32, ptr %t232
  store i32 %t233, ptr %l150
  store ptr %l150, ptr %l151, !tbaa !29
  store i32 2, ptr %l152
  store ptr %l152, ptr %l153, !tbaa !29
  %t234 = load ptr, ptr %l151, !tbaa !29
  %t235 = load ptr, ptr %l153, !tbaa !29
  %t236 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %t234, ptr %t235)
  store i1 %t236, ptr %l154
  br label %bb92
bb92:
  %t237 = load i1, ptr %l154, !tbaa !21
  br i1 %t237, label %bb93, label %bb94
bb93:
  store %olang.scope zeroinitializer, ptr %s11
  %t238 = load %"compiler/cond:Value", ptr %l3
  store %"compiler/cond:Value" %t238, ptr %l155
  %t239 = load %"compiler/cond:Value", ptr %l155
  %t240 = call { i1, double } @compiler_2fcond_2easFloat(%"compiler/cond:Value" %t239)
  store { i1, double } %t240, ptr %l156
  br label %bb95
bb94:
  br label %bb100
bb95:
  %t241 = load { i1, double }, ptr %l156
  store { i1, double } %t241, ptr %l11
  %t242 = getelementptr { i1, double }, ptr %l11, i32 0, i32 0
  %t243 = load i1, ptr %t242, !tbaa !21
  store i1 %t243, ptr %l157, !tbaa !21
  %t244 = load i1, ptr %l157, !tbaa !21
  store i1 %t244, ptr %l12, !tbaa !21
  %t245 = getelementptr { i1, double }, ptr %l11, i32 0, i32 1
  %t246 = load double, ptr %t245, !tbaa !26
  store double %t246, ptr %l158, !tbaa !26
  %t247 = load double, ptr %l158, !tbaa !26
  store double %t247, ptr %l13, !tbaa !26
  %t248 = load i1, ptr %l12, !tbaa !21
  store i1 %t248, ptr %l159, !tbaa !21
  %t249 = load i1, ptr %l159, !tbaa !21
  %t250 = xor i1 %t249, true
  store i1 %t250, ptr %l160, !tbaa !21
  %t251 = load i1, ptr %l160, !tbaa !21
  br i1 %t251, label %bb96, label %bb97
bb96:
  store %olang.scope zeroinitializer, ptr %s12
  %t252 = load ptr, ptr %l0, !tbaa !29
  store ptr %t252, ptr %l161, !tbaa !29
  %t253 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t253, ptr %l162
  %t254 = load ptr, ptr %l161, !tbaa !29
  %t255 = load %"compiler/source:Span", ptr %l162
  %t256 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t254, %"compiler/source:Span" %t255)
  store %"compiler/cond:Value" %t256, ptr %l163
  br label %bb98
bb97:
  br label %bb99
bb98:
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t257 = load %"compiler/cond:Value", ptr %l163
  store %"compiler/cond:Value" %t257, ptr %rv
  br label %ret
bb99:
  %t258 = load double, ptr %l13, !tbaa !26
  store double %t258, ptr %l164, !tbaa !26
  %t259 = load double, ptr %l164, !tbaa !26
  store double %t259, ptr %l9, !tbaa !26
  call void @__olang_scope_close(ptr %s11)
  br label %bb100
bb100:
  %t260 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 0
  %t261 = load i32, ptr %t260
  store i32 %t261, ptr %l165
  store ptr %l165, ptr %l166, !tbaa !29
  store i32 2, ptr %l167
  store ptr %l167, ptr %l168, !tbaa !29
  %t262 = load ptr, ptr %l166, !tbaa !29
  %t263 = load ptr, ptr %l168, !tbaa !29
  %t264 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %t262, ptr %t263)
  store i1 %t264, ptr %l169
  br label %bb101
bb101:
  %t265 = load i1, ptr %l169, !tbaa !21
  br i1 %t265, label %bb102, label %bb103
bb102:
  store %olang.scope zeroinitializer, ptr %s13
  %t266 = load %"compiler/cond:Value", ptr %l4
  store %"compiler/cond:Value" %t266, ptr %l170
  %t267 = load %"compiler/cond:Value", ptr %l170
  %t268 = call { i1, double } @compiler_2fcond_2easFloat(%"compiler/cond:Value" %t267)
  store { i1, double } %t268, ptr %l171
  br label %bb104
bb103:
  br label %bb109
bb104:
  %t269 = load { i1, double }, ptr %l171
  store { i1, double } %t269, ptr %l14
  %t270 = getelementptr { i1, double }, ptr %l14, i32 0, i32 0
  %t271 = load i1, ptr %t270, !tbaa !21
  store i1 %t271, ptr %l172, !tbaa !21
  %t272 = load i1, ptr %l172, !tbaa !21
  store i1 %t272, ptr %l15, !tbaa !21
  %t273 = getelementptr { i1, double }, ptr %l14, i32 0, i32 1
  %t274 = load double, ptr %t273, !tbaa !26
  store double %t274, ptr %l173, !tbaa !26
  %t275 = load double, ptr %l173, !tbaa !26
  store double %t275, ptr %l16, !tbaa !26
  %t276 = load i1, ptr %l15, !tbaa !21
  store i1 %t276, ptr %l174, !tbaa !21
  %t277 = load i1, ptr %l174, !tbaa !21
  %t278 = xor i1 %t277, true
  store i1 %t278, ptr %l175, !tbaa !21
  %t279 = load i1, ptr %l175, !tbaa !21
  br i1 %t279, label %bb105, label %bb106
bb105:
  store %olang.scope zeroinitializer, ptr %s14
  %t280 = load ptr, ptr %l0, !tbaa !29
  store ptr %t280, ptr %l176, !tbaa !29
  %t281 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t281, ptr %l177
  %t282 = load ptr, ptr %l176, !tbaa !29
  %t283 = load %"compiler/source:Span", ptr %l177
  %t284 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t282, %"compiler/source:Span" %t283)
  store %"compiler/cond:Value" %t284, ptr %l178
  br label %bb107
bb106:
  br label %bb108
bb107:
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t285 = load %"compiler/cond:Value", ptr %l178
  store %"compiler/cond:Value" %t285, ptr %rv
  br label %ret
bb108:
  %t286 = load double, ptr %l16, !tbaa !26
  store double %t286, ptr %l179, !tbaa !26
  %t287 = load double, ptr %l179, !tbaa !26
  store double %t287, ptr %l10, !tbaa !26
  call void @__olang_scope_close(ptr %s13)
  br label %bb109
bb109:
  %t288 = load double, ptr %l9, !tbaa !26
  store double %t288, ptr %l180, !tbaa !26
  %t289 = load double, ptr %l9, !tbaa !26
  store double %t289, ptr %l181, !tbaa !26
  %t290 = load double, ptr %l180, !tbaa !26
  %t291 = load double, ptr %l181, !tbaa !26
  %t292 = fcmp une double %t290, %t291
  store i1 %t292, ptr %l182, !tbaa !21
  %t293 = load i1, ptr %l182, !tbaa !21
  br i1 %t293, label %bb110, label %bb111
bb110:
  store i1 true, ptr %l183, !tbaa !21
  br label %bb112
bb111:
  %t294 = load double, ptr %l10, !tbaa !26
  store double %t294, ptr %l184, !tbaa !26
  %t295 = load double, ptr %l10, !tbaa !26
  store double %t295, ptr %l185, !tbaa !26
  %t296 = load double, ptr %l184, !tbaa !26
  %t297 = load double, ptr %l185, !tbaa !26
  %t298 = fcmp une double %t296, %t297
  store i1 %t298, ptr %l186, !tbaa !21
  %t299 = load i1, ptr %l186, !tbaa !21
  store i1 %t299, ptr %l183, !tbaa !21
  br label %bb112
bb112:
  %t300 = load i1, ptr %l183, !tbaa !21
  br i1 %t300, label %bb113, label %bb114
bb113:
  store %olang.scope zeroinitializer, ptr %s15
  %t301 = load i32, ptr %l2
  store i32 %t301, ptr %l187
  store ptr %l187, ptr %l188, !tbaa !29
  store i32 77, ptr %l189
  store ptr %l189, ptr %l190, !tbaa !29
  %t302 = load ptr, ptr %l188, !tbaa !29
  %t303 = load ptr, ptr %l190, !tbaa !29
  %t304 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t302, ptr %t303)
  store i1 %t304, ptr %l191
  br label %bb115
bb114:
  br label %bb117
bb115:
  %t305 = load i1, ptr %l191, !tbaa !21
  %t306 = call %"compiler/cond:Value" @compiler_2fcond_2eboolValue(i1 %t305)
  store %"compiler/cond:Value" %t306, ptr %l192
  br label %bb116
bb116:
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t307 = load %"compiler/cond:Value", ptr %l192
  store %"compiler/cond:Value" %t307, ptr %rv
  br label %ret
bb117:
  %t308 = load double, ptr %l9, !tbaa !26
  store double %t308, ptr %l193, !tbaa !26
  %t309 = load double, ptr %l10, !tbaa !26
  store double %t309, ptr %l194, !tbaa !26
  %t310 = load double, ptr %l193, !tbaa !26
  %t311 = load double, ptr %l194, !tbaa !26
  %t312 = fcmp olt double %t310, %t311
  store i1 %t312, ptr %l195, !tbaa !21
  %t313 = load i1, ptr %l195, !tbaa !21
  br i1 %t313, label %bb118, label %bb119
bb118:
  store i64 -1, ptr %l196, !tbaa !24
  br label %bb123
bb119:
  %t314 = load double, ptr %l9, !tbaa !26
  store double %t314, ptr %l197, !tbaa !26
  %t315 = load double, ptr %l10, !tbaa !26
  store double %t315, ptr %l198, !tbaa !26
  %t316 = load double, ptr %l197, !tbaa !26
  %t317 = load double, ptr %l198, !tbaa !26
  %t318 = fcmp ogt double %t316, %t317
  store i1 %t318, ptr %l199, !tbaa !21
  %t319 = load i1, ptr %l199, !tbaa !21
  br i1 %t319, label %bb120, label %bb121
bb120:
  store i64 1, ptr %l200, !tbaa !24
  br label %bb122
bb121:
  store i64 0, ptr %l200, !tbaa !24
  br label %bb122
bb122:
  %t320 = load i64, ptr %l200, !tbaa !24
  store i64 %t320, ptr %l196, !tbaa !24
  br label %bb123
bb123:
  %t321 = load i64, ptr %l196, !tbaa !24
  store i64 %t321, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  br label %bb127
bb124:
  %t322 = load { i64, ptr }, ptr %l205, !tbaa !27
  %t323 = extractvalue { i64, ptr } %t322, 0
  %t324 = extractvalue { i64, ptr } %t322, 1
  %t325 = mul i64 %t323, 1
  %t326 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t325)
  call void @llvm.memcpy.p0.p0.i64(ptr %t326, ptr %t324, i64 %t325, i1 false)
  %t327 = insertvalue { i64, ptr } undef, i64 %t323, 0
  %t328 = insertvalue { i64, ptr } %t327, ptr %t326, 1
  store { i64, ptr } %t328, ptr %l206, !tbaa !27
  %t329 = load { i64, ptr }, ptr %l206, !tbaa !27
  %t330 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondTypes(ptr %v0, ptr %v0, { i64, ptr } %t329)
  store %"compiler/msgs:Msg" %t330, ptr %l207
  br label %bb125
bb125:
  %t331 = load ptr, ptr %l201, !tbaa !29
  %t332 = load %"compiler/source:Span", ptr %l202
  %t333 = load %"compiler/msgs:Msg", ptr %l207
  %t334 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2efail(ptr %v0, ptr %v0, ptr %t331, %"compiler/source:Span" %t332, %"compiler/msgs:Msg" %t333)
  store %"compiler/cond:Value" %t334, ptr %l208
  br label %bb126
bb126:
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t335 = load %"compiler/cond:Value", ptr %l208
  store %"compiler/cond:Value" %t335, ptr %rv
  br label %ret
bb127:
  call void @__olang_scope_close(ptr %s8)
  br label %bb128
bb128:
  call void @__olang_scope_close(ptr %s5)
  br label %bb129
bb129:
  call void @__olang_scope_close(ptr %s3)
  br label %bb130
bb130:
  %t336 = load i32, ptr %l2
  store i32 %t336, ptr %l210
  %t337 = load i32, ptr %l210
  %t338 = trunc i64 75 to i32
  %t339 = icmp eq i32 %t337, %t338
  store i1 %t339, ptr %l211, !tbaa !21
  %t340 = load i1, ptr %l211, !tbaa !21
  br i1 %t340, label %bb131, label %bb132
bb131:
  br label %bb133
bb132:
  br label %bb135
bb133:
  store %olang.scope zeroinitializer, ptr %s17
  %t341 = load i64, ptr %l6, !tbaa !24
  store i64 %t341, ptr %l212, !tbaa !24
  %t342 = load i64, ptr %l212, !tbaa !24
  %t343 = icmp eq i64 %t342, 0
  store i1 %t343, ptr %l213, !tbaa !21
  %t344 = load i1, ptr %l213, !tbaa !21
  %t345 = call %"compiler/cond:Value" @compiler_2fcond_2eboolValue(i1 %t344)
  store %"compiler/cond:Value" %t345, ptr %l214
  br label %bb134
bb134:
  %t346 = load %"compiler/cond:Value", ptr %l214
  store %"compiler/cond:Value" %t346, ptr %l209
  call void @__olang_scope_close(ptr %s17)
  br label %bb161
bb135:
  %t347 = load i32, ptr %l2
  store i32 %t347, ptr %l215
  %t348 = load i32, ptr %l215
  %t349 = trunc i64 77 to i32
  %t350 = icmp eq i32 %t348, %t349
  store i1 %t350, ptr %l216, !tbaa !21
  %t351 = load i1, ptr %l216, !tbaa !21
  br i1 %t351, label %bb136, label %bb137
bb136:
  br label %bb138
bb137:
  br label %bb140
bb138:
  store %olang.scope zeroinitializer, ptr %s18
  %t352 = load i64, ptr %l6, !tbaa !24
  store i64 %t352, ptr %l217, !tbaa !24
  %t353 = load i64, ptr %l217, !tbaa !24
  %t354 = icmp ne i64 %t353, 0
  store i1 %t354, ptr %l218, !tbaa !21
  %t355 = load i1, ptr %l218, !tbaa !21
  %t356 = call %"compiler/cond:Value" @compiler_2fcond_2eboolValue(i1 %t355)
  store %"compiler/cond:Value" %t356, ptr %l219
  br label %bb139
bb139:
  %t357 = load %"compiler/cond:Value", ptr %l219
  store %"compiler/cond:Value" %t357, ptr %l209
  call void @__olang_scope_close(ptr %s18)
  br label %bb161
bb140:
  %t358 = load i32, ptr %l2
  store i32 %t358, ptr %l220
  %t359 = load i32, ptr %l220
  %t360 = trunc i64 79 to i32
  %t361 = icmp eq i32 %t359, %t360
  store i1 %t361, ptr %l221, !tbaa !21
  %t362 = load i1, ptr %l221, !tbaa !21
  br i1 %t362, label %bb141, label %bb142
bb141:
  br label %bb143
bb142:
  br label %bb145
bb143:
  store %olang.scope zeroinitializer, ptr %s19
  %t363 = load i64, ptr %l6, !tbaa !24
  store i64 %t363, ptr %l222, !tbaa !24
  %t364 = load i64, ptr %l222, !tbaa !24
  %t365 = icmp slt i64 %t364, 0
  store i1 %t365, ptr %l223, !tbaa !21
  %t366 = load i1, ptr %l223, !tbaa !21
  %t367 = call %"compiler/cond:Value" @compiler_2fcond_2eboolValue(i1 %t366)
  store %"compiler/cond:Value" %t367, ptr %l224
  br label %bb144
bb144:
  %t368 = load %"compiler/cond:Value", ptr %l224
  store %"compiler/cond:Value" %t368, ptr %l209
  call void @__olang_scope_close(ptr %s19)
  br label %bb161
bb145:
  %t369 = load i32, ptr %l2
  store i32 %t369, ptr %l225
  %t370 = load i32, ptr %l225
  %t371 = trunc i64 80 to i32
  %t372 = icmp eq i32 %t370, %t371
  store i1 %t372, ptr %l226, !tbaa !21
  %t373 = load i1, ptr %l226, !tbaa !21
  br i1 %t373, label %bb146, label %bb147
bb146:
  br label %bb148
bb147:
  br label %bb150
bb148:
  store %olang.scope zeroinitializer, ptr %s20
  %t374 = load i64, ptr %l6, !tbaa !24
  store i64 %t374, ptr %l227, !tbaa !24
  %t375 = load i64, ptr %l227, !tbaa !24
  %t376 = icmp sle i64 %t375, 0
  store i1 %t376, ptr %l228, !tbaa !21
  %t377 = load i1, ptr %l228, !tbaa !21
  %t378 = call %"compiler/cond:Value" @compiler_2fcond_2eboolValue(i1 %t377)
  store %"compiler/cond:Value" %t378, ptr %l229
  br label %bb149
bb149:
  %t379 = load %"compiler/cond:Value", ptr %l229
  store %"compiler/cond:Value" %t379, ptr %l209
  call void @__olang_scope_close(ptr %s20)
  br label %bb161
bb150:
  %t380 = load i32, ptr %l2
  store i32 %t380, ptr %l230
  %t381 = load i32, ptr %l230
  %t382 = trunc i64 81 to i32
  %t383 = icmp eq i32 %t381, %t382
  store i1 %t383, ptr %l231, !tbaa !21
  %t384 = load i1, ptr %l231, !tbaa !21
  br i1 %t384, label %bb151, label %bb152
bb151:
  br label %bb153
bb152:
  br label %bb155
bb153:
  store %olang.scope zeroinitializer, ptr %s21
  %t385 = load i64, ptr %l6, !tbaa !24
  store i64 %t385, ptr %l232, !tbaa !24
  %t386 = load i64, ptr %l232, !tbaa !24
  %t387 = icmp sgt i64 %t386, 0
  store i1 %t387, ptr %l233, !tbaa !21
  %t388 = load i1, ptr %l233, !tbaa !21
  %t389 = call %"compiler/cond:Value" @compiler_2fcond_2eboolValue(i1 %t388)
  store %"compiler/cond:Value" %t389, ptr %l234
  br label %bb154
bb154:
  %t390 = load %"compiler/cond:Value", ptr %l234
  store %"compiler/cond:Value" %t390, ptr %l209
  call void @__olang_scope_close(ptr %s21)
  br label %bb161
bb155:
  br i1 true, label %bb156, label %bb157
bb156:
  br label %bb158
bb157:
  br label %bb160
bb158:
  store %olang.scope zeroinitializer, ptr %s22
  %t391 = load i64, ptr %l6, !tbaa !24
  store i64 %t391, ptr %l235, !tbaa !24
  %t392 = load i64, ptr %l235, !tbaa !24
  %t393 = icmp sge i64 %t392, 0
  store i1 %t393, ptr %l236, !tbaa !21
  %t394 = load i1, ptr %l236, !tbaa !21
  %t395 = call %"compiler/cond:Value" @compiler_2fcond_2eboolValue(i1 %t394)
  store %"compiler/cond:Value" %t395, ptr %l237
  br label %bb159
bb159:
  %t396 = load %"compiler/cond:Value", ptr %l237
  store %"compiler/cond:Value" %t396, ptr %l209
  call void @__olang_scope_close(ptr %s22)
  br label %bb161
bb160:
  call void @__olang_check_failed(ptr @.c32)
  unreachable
bb161:
  call void @__olang_scope_close(ptr %s0)
  %t397 = load %"compiler/cond:Value", ptr %l209
  store %"compiler/cond:Value" %t397, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cond:Value", ptr %rv
  ret %"compiler/cond:Value" %rr
}

define dso_local %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2econstValue(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/cond:Value"
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"compiler/cond:Value"
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca ptr
  %l12 = alloca i1
  %l13 = alloca i1
  %l14 = alloca %"compiler/cond:Value"
  %l15 = alloca i32
  %l16 = alloca i64
  %l17 = alloca double
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i1
  %l27 = alloca %"compiler/cond:Value"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca %"compiler/cond:Value"
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = getelementptr %"compiler/cond:Eval", ptr %t2, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = getelementptr %"compiler/cond:Consts", ptr %t5, i32 0, i32 1
  store ptr %t6, ptr %l5, !tbaa !29
  %t7 = load i64, ptr %l1, !tbaa !24
  store i64 %t7, ptr %l6, !tbaa !24
  %t8 = load ptr, ptr %l5, !tbaa !29
  %t9 = load i64, ptr %l6, !tbaa !24
  %t10 = call %"compiler/cond:Value" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcond_3aValue_3e_2eAt_3ccompiler_2fcond_3aValue_3e(ptr %v0, ptr %t8, i64 %t9)
  store %"compiler/cond:Value" %t10, ptr %l7
  br label %bb1
bb1:
  %t11 = load %"compiler/cond:Value", ptr %l7
  store %"compiler/cond:Value" %t11, ptr %l2
  %t12 = getelementptr %"compiler/cond:Value", ptr %l2, i32 0, i32 0
  %t13 = load i32, ptr %t12
  store i32 %t13, ptr %l8
  store ptr %l8, ptr %l9, !tbaa !29
  store i32 4, ptr %l10
  store ptr %l10, ptr %l11, !tbaa !29
  %t14 = load ptr, ptr %l9, !tbaa !29
  %t15 = load ptr, ptr %l11, !tbaa !29
  %t16 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %t14, ptr %t15)
  store i1 %t16, ptr %l12
  br label %bb2
bb2:
  %t17 = load i1, ptr %l12, !tbaa !21
  %t18 = xor i1 %t17, true
  store i1 %t18, ptr %l13, !tbaa !21
  %t19 = load i1, ptr %l13, !tbaa !21
  br i1 %t19, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t20 = load %"compiler/cond:Value", ptr %l2
  store %"compiler/cond:Value" %t20, ptr %l14
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t21 = load %"compiler/cond:Value", ptr %l14
  store %"compiler/cond:Value" %t21, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t22 = getelementptr %"compiler/cond:Value", ptr %l2, i32 0, i32 0
  %t23 = load i32, ptr %t22
  store i32 %t23, ptr %l15
  %t24 = getelementptr %"compiler/cond:Value", ptr %l2, i32 0, i32 1
  %t25 = load i64, ptr %t24, !tbaa !24
  store i64 %t25, ptr %l16, !tbaa !24
  %t26 = getelementptr %"compiler/cond:Value", ptr %l2, i32 0, i32 2
  %t27 = load double, ptr %t26, !tbaa !26
  store double %t27, ptr %l17, !tbaa !26
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l18, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l19, !tbaa !29
  %t30 = load ptr, ptr %l19, !tbaa !29
  %t31 = getelementptr %"compiler/cond:Eval", ptr %t30, i32 0, i32 3
  %t32 = load ptr, ptr %t31, !tbaa !29
  store ptr %t32, ptr %l20, !tbaa !29
  %t33 = load ptr, ptr %l20, !tbaa !29
  %t34 = getelementptr %"compiler/cond:Consts", ptr %t33, i32 0, i32 6
  store ptr %t34, ptr %l21, !tbaa !29
  %t35 = getelementptr %"compiler/cond:Value", ptr %l2, i32 0, i32 3
  %t36 = load i64, ptr %t35, !tbaa !24
  store i64 %t36, ptr %l22, !tbaa !24
  %t37 = load ptr, ptr %l21, !tbaa !29
  %t38 = load i64, ptr %l22, !tbaa !24
  %t39 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t37, i64 %t38)
  store { i64, ptr } %t39, ptr %l23
  br label %bb6
bb6:
  %t40 = load ptr, ptr %l18, !tbaa !29
  %t41 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t42 = call i64 @compiler_2fcond_2ecompiler_2fcond_3aEval_2eaddText(ptr %v0, ptr %v0, ptr %t40, { i64, ptr } %t41)
  store i64 %t42, ptr %l24
  br label %bb7
bb7:
  %t43 = getelementptr %"compiler/cond:Value", ptr %l2, i32 0, i32 4
  %t44 = load i64, ptr %t43, !tbaa !24
  store i64 %t44, ptr %l25, !tbaa !24
  %t45 = getelementptr %"compiler/cond:Value", ptr %l2, i32 0, i32 5
  %t46 = load i1, ptr %t45, !tbaa !21
  store i1 %t46, ptr %l26, !tbaa !21
  %t47 = load i32, ptr %l15
  %t48 = load i64, ptr %l16, !tbaa !24
  %t49 = load double, ptr %l17, !tbaa !26
  %t50 = load i64, ptr %l24, !tbaa !24
  %t51 = load i64, ptr %l25, !tbaa !24
  %t52 = load i1, ptr %l26, !tbaa !21
  %t53 = call %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %s0, i32 %t47, i64 %t48, double %t49, i64 %t50, i64 %t51, i1 %t52)
  store %"compiler/cond:Value" %t53, ptr %l27
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t54 = load %"compiler/cond:Value", ptr %l27
  store %"compiler/cond:Value" %t54, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cond:Value", ptr %rv
  ret %"compiler/cond:Value" %rr
}

define dso_local %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i1
  %l5 = alloca %"compiler/cond:Value"
  %l6 = alloca ptr
  %l7 = alloca i1
  %l8 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca %"compiler/source:Span"
  %l12 = alloca ptr
  %l13 = alloca %"compiler/source:Span"
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca %"compiler/msgs:Msg"
  %l17 = alloca %"compiler/cond:Value"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca %"compiler/cond:Value"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/cond:Eval", ptr %t2, i32 0, i32 10
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %l3, !tbaa !24
  %t5 = load i64, ptr %l3, !tbaa !24
  %t6 = icmp sgt i64 %t5, 0
  store i1 %t6, ptr %l4, !tbaa !21
  %t7 = load i1, ptr %l4, !tbaa !21
  br i1 %t7, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = call %"compiler/cond:Value" @compiler_2fcond_2enone()
  store %"compiler/cond:Value" %t8, ptr %l5
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t9 = load %"compiler/cond:Value", ptr %l5
  store %"compiler/cond:Value" %t9, ptr %rv
  br label %ret
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l6, !tbaa !29
  %t11 = load ptr, ptr %l6, !tbaa !29
  %t12 = getelementptr %"compiler/cond:Eval", ptr %t11, i32 0, i32 4
  %t13 = load i1, ptr %t12, !tbaa !21
  store i1 %t13, ptr %l7, !tbaa !21
  %t14 = load i1, ptr %l7, !tbaa !21
  %t15 = xor i1 %t14, true
  store i1 %t15, ptr %l8, !tbaa !21
  %t16 = load i1, ptr %l8, !tbaa !21
  br i1 %t16, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t17 = load ptr, ptr %l0, !tbaa !29
  store ptr %t17, ptr %l9, !tbaa !29
  %t18 = load ptr, ptr %l9, !tbaa !29
  %t19 = getelementptr %"compiler/cond:Eval", ptr %t18, i32 0, i32 5
  store i1 true, ptr %t19, !tbaa !21
  call void @__olang_scope_close(ptr %s2)
  br label %bb7
bb6:
  br label %bb7
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l10, !tbaa !29
  %t21 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t21, ptr %l11
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l12, !tbaa !29
  %t23 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t23, ptr %l13
  %t24 = load ptr, ptr %l12, !tbaa !29
  %t25 = load %"compiler/source:Span", ptr %l13
  %t26 = call { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aEval_2etokText(ptr %v0, ptr %v0, ptr %t24, %"compiler/source:Span" %t25)
  store { i64, ptr } %t26, ptr %l14
  br label %bb8
bb8:
  %t27 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t27, 0
  %t29 = extractvalue { i64, ptr } %t27, 1
  %t30 = mul i64 %t28, 1
  %t31 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t30)
  call void @llvm.memcpy.p0.p0.i64(ptr %t31, ptr %t29, i64 %t30, i1 false)
  %t32 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t31, 1
  store { i64, ptr } %t33, ptr %l15, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondName(ptr %v0, ptr %v0, { i64, ptr } %t34)
  store %"compiler/msgs:Msg" %t35, ptr %l16
  br label %bb9
bb9:
  %t36 = load ptr, ptr %l10, !tbaa !29
  %t37 = load %"compiler/source:Span", ptr %l11
  %t38 = load %"compiler/msgs:Msg", ptr %l16
  %t39 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2efail(ptr %v0, ptr %v0, ptr %t36, %"compiler/source:Span" %t37, %"compiler/msgs:Msg" %t38)
  store %"compiler/cond:Value" %t39, ptr %l17
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t40 = load %"compiler/cond:Value", ptr %l17
  store %"compiler/cond:Value" %t40, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cond:Value", ptr %rv
  ret %"compiler/cond:Value" %rr
}

define dso_local %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefinedValue(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca %"compiler/cond:Value"
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca ptr
  %l12 = alloca %"compiler/source:Span"
  %l13 = alloca %"compiler/cond:Value"
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca %"compiler/source:Span"
  %l21 = alloca %"compiler/cond:Value"
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca %"compiler/cond:Value"
  %l25 = alloca i32
  %l26 = alloca i64
  %l27 = alloca double
  %l28 = alloca i64
  %l29 = alloca %"compiler/cond:Value"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca %"compiler/cond:Value"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = getelementptr %"compiler/cond:Eval", ptr %t2, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l7, !tbaa !29
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t5, ptr %l8, !tbaa !27
  %t6 = load ptr, ptr %l7, !tbaa !29
  %t7 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t8 = call { i32, i64 } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2efind(ptr %v0, ptr %v1, ptr %t6, { i64, ptr } %t7)
  %t9 = extractvalue { i32, i64 } %t8, 1
  %t10 = extractvalue { i32, i64 } %t8, 0
  store i32 %t10, ptr %l10
  %t11 = icmp ne i32 %t10, 0
  br i1 %t11, label %bb2, label %ok.12
ok.12:
  store i64 %t9, ptr %l9
  br label %bb1
bb1:
  %t13 = load i64, ptr %l9, !tbaa !24
  store i64 %t13, ptr %l5, !tbaa !24
  br label %bb5
bb2:
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l11, !tbaa !29
  %t15 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t15, ptr %l12
  %t16 = load ptr, ptr %l11, !tbaa !29
  %t17 = load %"compiler/source:Span", ptr %l12
  %t18 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t16, %"compiler/source:Span" %t17)
  store %"compiler/cond:Value" %t18, ptr %l13
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t19 = load %"compiler/cond:Value", ptr %l13
  store %"compiler/cond:Value" %t19, ptr %rv
  br label %ret
bb5:
  %t20 = load i64, ptr %l5, !tbaa !24
  store i64 %t20, ptr %l3, !tbaa !24
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l14, !tbaa !29
  %t22 = load ptr, ptr %l14, !tbaa !29
  %t23 = getelementptr %"compiler/cond:Eval", ptr %t22, i32 0, i32 3
  %t24 = load ptr, ptr %t23, !tbaa !29
  store ptr %t24, ptr %l15, !tbaa !29
  %t25 = load ptr, ptr %l15, !tbaa !29
  %t26 = getelementptr %"compiler/cond:Consts", ptr %t25, i32 0, i32 3
  store ptr %t26, ptr %l16, !tbaa !29
  %t27 = load i64, ptr %l3, !tbaa !24
  store i64 %t27, ptr %l17, !tbaa !24
  %t28 = load ptr, ptr %l16, !tbaa !29
  %t29 = load i64, ptr %l17, !tbaa !24
  %t30 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t28, i64 %t29)
  store i1 %t30, ptr %l18
  br label %bb6
bb6:
  %t31 = load i1, ptr %l18, !tbaa !21
  br i1 %t31, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l19, !tbaa !29
  %t33 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t33, ptr %l20
  %t34 = load ptr, ptr %l19, !tbaa !29
  %t35 = load %"compiler/source:Span", ptr %l20
  %t36 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t34, %"compiler/source:Span" %t35)
  store %"compiler/cond:Value" %t36, ptr %l21
  br label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t37 = load %"compiler/cond:Value", ptr %l21
  store %"compiler/cond:Value" %t37, ptr %rv
  br label %ret
bb10:
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l22, !tbaa !29
  %t39 = load i64, ptr %l3, !tbaa !24
  store i64 %t39, ptr %l23, !tbaa !24
  %t40 = load ptr, ptr %l22, !tbaa !29
  %t41 = load i64, ptr %l23, !tbaa !24
  %t42 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2econstValue(ptr %v0, ptr %t40, i64 %t41)
  store %"compiler/cond:Value" %t42, ptr %l24
  br label %bb11
bb11:
  %t43 = load %"compiler/cond:Value", ptr %l24
  store %"compiler/cond:Value" %t43, ptr %l4
  %t44 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 0
  %t45 = load i32, ptr %t44
  store i32 %t45, ptr %l25
  %t46 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 1
  %t47 = load i64, ptr %t46, !tbaa !24
  store i64 %t47, ptr %l26, !tbaa !24
  %t48 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 2
  %t49 = load double, ptr %t48, !tbaa !26
  store double %t49, ptr %l27, !tbaa !26
  %t50 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 3
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l28, !tbaa !24
  %t52 = load i32, ptr %l25
  %t53 = load i64, ptr %l26, !tbaa !24
  %t54 = load double, ptr %l27, !tbaa !26
  %t55 = load i64, ptr %l28, !tbaa !24
  %t56 = call %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %s0, i32 %t52, i64 %t53, double %t54, i64 %t55, i64 0, i1 false)
  store %"compiler/cond:Value" %t56, ptr %l29
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s0)
  %t57 = load %"compiler/cond:Value", ptr %l29
  store %"compiler/cond:Value" %t57, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cond:Value", ptr %rv
  ret %"compiler/cond:Value" %rr
}

define dso_local %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca i32
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca %"compiler/cond:Value"
  %l15 = alloca ptr
  %l16 = alloca i1
  %l17 = alloca i1
  %l18 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca %"compiler/source:Span"
  %l21 = alloca ptr
  %l22 = alloca i32
  %l23 = alloca ptr
  %l24 = alloca %"compiler/source:Span"
  %l25 = alloca i32
  %l26 = alloca %"compiler/cond:Value"
  %l27 = alloca ptr
  %l28 = alloca i1
  %l29 = alloca i1
  %l30 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca %"compiler/source:Span"
  %l33 = alloca ptr
  %l34 = alloca i32
  %l35 = alloca ptr
  %l36 = alloca %"compiler/source:Span"
  %l37 = alloca i32
  %l38 = alloca %"compiler/cond:Value"
  %l39 = alloca ptr
  %l40 = alloca i1
  %l41 = alloca i1
  %l42 = alloca i64
  %l43 = alloca ptr
  %l44 = alloca ptr
  %l45 = alloca ptr
  %l46 = alloca ptr
  %l47 = alloca %"compiler/cond:Value"
  %l48 = alloca ptr
  %l49 = alloca i1
  %l50 = alloca i1
  %l51 = alloca i64
  %l52 = alloca ptr
  %l53 = alloca %"compiler/source:Span"
  %l54 = alloca ptr
  %l55 = alloca i32
  %l56 = alloca ptr
  %l57 = alloca ptr
  %l58 = alloca ptr
  %l59 = alloca %"compiler/source:Span"
  %l60 = alloca i32
  %l61 = alloca ptr
  %l62 = alloca %"compiler/cond:Value"
  %l63 = alloca ptr
  %l64 = alloca i1
  %l65 = alloca i1
  %l66 = alloca i64
  %l67 = alloca ptr
  %l68 = alloca %"compiler/source:Span"
  %l69 = alloca ptr
  %l70 = alloca i32
  %l71 = alloca ptr
  %l72 = alloca ptr
  %l73 = alloca ptr
  %l74 = alloca ptr
  %l75 = alloca ptr
  %l76 = alloca %"compiler/source:Span"
  %l77 = alloca i32
  %l78 = alloca ptr
  %l79 = alloca ptr
  %l80 = alloca %"compiler/cond:Value"
  %l81 = alloca ptr
  %l82 = alloca ptr
  %l83 = alloca ptr
  %l84 = alloca %"compiler/source:Span"
  %l85 = alloca %"compiler/cond:Value"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca %"compiler/cond:Value"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t2 = load ptr, ptr %l15, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  store i1 %t3, ptr %l17, !tbaa !21
  %t4 = load i1, ptr %l17, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l15, !tbaa !29
  %t6 = load i64, ptr %t5
  store i64 %t6, ptr %l18, !tbaa !24
  %t7 = load i64, ptr %l18, !tbaa !24
  %t8 = icmp eq i64 %t7, 1
  store i1 %t8, ptr %l16, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l16, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l19, !tbaa !29
  %t11 = load ptr, ptr %l19, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t11, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l20
  %t15 = load %"compiler/source:Span", ptr %l20
  store %"compiler/source:Span" %t15, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l21, !tbaa !29
  %t17 = load ptr, ptr %l21, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t17, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32 }, ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l22
  %t21 = load i32, ptr %l22
  store i32 %t21, ptr %l3
  br label %bb5
bb4:
  br label %bb7
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l23, !tbaa !29
  %t23 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t23, ptr %l24
  %t24 = load i32, ptr %l3
  store i32 %t24, ptr %l25
  %t25 = load ptr, ptr %l23, !tbaa !29
  %t26 = load %"compiler/source:Span", ptr %l24
  %t27 = load i32, ptr %l25
  %t28 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eliteral(ptr %v0, ptr %t25, %"compiler/source:Span" %t26, i32 %t27)
  store %"compiler/cond:Value" %t28, ptr %l26
  br label %bb6
bb6:
  %t29 = load %"compiler/cond:Value", ptr %l26
  store %"compiler/cond:Value" %t29, ptr %l14
  call void @__olang_scope_close(ptr %s1)
  br label %bb42
bb7:
  %t30 = load ptr, ptr %l1, !tbaa !29
  store ptr %t30, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t31 = load ptr, ptr %l27, !tbaa !29
  %t32 = icmp ne ptr %t31, null
  store i1 %t32, ptr %l29, !tbaa !21
  %t33 = load i1, ptr %l29, !tbaa !21
  br i1 %t33, label %bb8, label %bb9
bb8:
  %t34 = load ptr, ptr %l27, !tbaa !29
  %t35 = load i64, ptr %t34
  store i64 %t35, ptr %l30, !tbaa !24
  %t36 = load i64, ptr %l30, !tbaa !24
  %t37 = icmp eq i64 %t36, 0
  store i1 %t37, ptr %l28, !tbaa !21
  br label %bb9
bb9:
  %t38 = load i1, ptr %l28, !tbaa !21
  br i1 %t38, label %bb10, label %bb11
bb10:
  %t39 = load ptr, ptr %l1, !tbaa !29
  store ptr %t39, ptr %l31, !tbaa !29
  %t40 = load ptr, ptr %l31, !tbaa !29
  %t41 = getelementptr { i64, [5 x i64] }, ptr %t40, i32 0, i32 1
  %t42 = getelementptr { %"compiler/source:Span", i32 }, ptr %t41, i32 0, i32 0
  %t43 = load %"compiler/source:Span", ptr %t42
  store %"compiler/source:Span" %t43, ptr %l32
  %t44 = load %"compiler/source:Span", ptr %l32
  store %"compiler/source:Span" %t44, ptr %l4
  %t45 = load ptr, ptr %l1, !tbaa !29
  store ptr %t45, ptr %l33, !tbaa !29
  %t46 = load ptr, ptr %l33, !tbaa !29
  %t47 = getelementptr { i64, [5 x i64] }, ptr %t46, i32 0, i32 1
  %t48 = getelementptr { %"compiler/source:Span", i32 }, ptr %t47, i32 0, i32 1
  %t49 = load i32, ptr %t48
  store i32 %t49, ptr %l34, !tbaa !23
  %t50 = load i32, ptr %l34, !tbaa !23
  store i32 %t50, ptr %l5, !tbaa !23
  br label %bb12
bb11:
  br label %bb14
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l35, !tbaa !29
  %t52 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t52, ptr %l36
  %t53 = load i32, ptr %l5, !tbaa !23
  store i32 %t53, ptr %l37, !tbaa !23
  %t54 = load ptr, ptr %l35, !tbaa !29
  %t55 = load %"compiler/source:Span", ptr %l36
  %t56 = load i32, ptr %l37, !tbaa !23
  %t57 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2ename(ptr %v0, ptr %t54, %"compiler/source:Span" %t55, i32 %t56)
  store %"compiler/cond:Value" %t57, ptr %l38
  br label %bb13
bb13:
  %t58 = load %"compiler/cond:Value", ptr %l38
  store %"compiler/cond:Value" %t58, ptr %l14
  call void @__olang_scope_close(ptr %s2)
  br label %bb42
bb14:
  %t59 = load ptr, ptr %l1, !tbaa !29
  store ptr %t59, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t60 = load ptr, ptr %l39, !tbaa !29
  %t61 = icmp ne ptr %t60, null
  store i1 %t61, ptr %l41, !tbaa !21
  %t62 = load i1, ptr %l41, !tbaa !21
  br i1 %t62, label %bb15, label %bb16
bb15:
  %t63 = load ptr, ptr %l39, !tbaa !29
  %t64 = load i64, ptr %t63
  store i64 %t64, ptr %l42, !tbaa !24
  %t65 = load i64, ptr %l42, !tbaa !24
  %t66 = icmp eq i64 %t65, 2
  store i1 %t66, ptr %l40, !tbaa !21
  br label %bb16
bb16:
  %t67 = load i1, ptr %l40, !tbaa !21
  br i1 %t67, label %bb17, label %bb18
bb17:
  %t68 = load ptr, ptr %l1, !tbaa !29
  store ptr %t68, ptr %l43, !tbaa !29
  %t69 = load ptr, ptr %l43, !tbaa !29
  %t70 = getelementptr { i64, [5 x i64] }, ptr %t69, i32 0, i32 1
  %t71 = getelementptr { %"compiler/source:Span", ptr }, ptr %t70, i32 0, i32 1
  %t72 = load ptr, ptr %t71
  store ptr %t72, ptr %l44, !tbaa !29
  %t73 = load ptr, ptr %l44, !tbaa !29
  store ptr %t73, ptr %l6, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l45, !tbaa !29
  %t75 = load ptr, ptr %l6, !tbaa !29
  store ptr %t75, ptr %l46, !tbaa !29
  %t76 = load ptr, ptr %l45, !tbaa !29
  %t77 = load ptr, ptr %l46, !tbaa !29
  %t78 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eexpr(ptr %v0, ptr %v1, ptr %t76, ptr %t77)
  store %"compiler/cond:Value" %t78, ptr %l47
  br label %bb20
bb20:
  %t79 = load %"compiler/cond:Value", ptr %l47
  store %"compiler/cond:Value" %t79, ptr %l14
  call void @__olang_scope_close(ptr %s3)
  br label %bb42
bb21:
  %t80 = load ptr, ptr %l1, !tbaa !29
  store ptr %t80, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t81 = load ptr, ptr %l48, !tbaa !29
  %t82 = icmp ne ptr %t81, null
  store i1 %t82, ptr %l50, !tbaa !21
  %t83 = load i1, ptr %l50, !tbaa !21
  br i1 %t83, label %bb22, label %bb23
bb22:
  %t84 = load ptr, ptr %l48, !tbaa !29
  %t85 = load i64, ptr %t84
  store i64 %t85, ptr %l51, !tbaa !24
  %t86 = load i64, ptr %l51, !tbaa !24
  %t87 = icmp eq i64 %t86, 3
  store i1 %t87, ptr %l49, !tbaa !21
  br label %bb23
bb23:
  %t88 = load i1, ptr %l49, !tbaa !21
  br i1 %t88, label %bb24, label %bb25
bb24:
  %t89 = load ptr, ptr %l1, !tbaa !29
  store ptr %t89, ptr %l52, !tbaa !29
  %t90 = load ptr, ptr %l52, !tbaa !29
  %t91 = getelementptr { i64, [5 x i64] }, ptr %t90, i32 0, i32 1
  %t92 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t91, i32 0, i32 0
  %t93 = load %"compiler/source:Span", ptr %t92
  store %"compiler/source:Span" %t93, ptr %l53
  %t94 = load %"compiler/source:Span", ptr %l53
  store %"compiler/source:Span" %t94, ptr %l7
  %t95 = load ptr, ptr %l1, !tbaa !29
  store ptr %t95, ptr %l54, !tbaa !29
  %t96 = load ptr, ptr %l54, !tbaa !29
  %t97 = getelementptr { i64, [5 x i64] }, ptr %t96, i32 0, i32 1
  %t98 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t97, i32 0, i32 1
  %t99 = load i32, ptr %t98
  store i32 %t99, ptr %l55
  %t100 = load i32, ptr %l55
  store i32 %t100, ptr %l8
  %t101 = load ptr, ptr %l1, !tbaa !29
  store ptr %t101, ptr %l56, !tbaa !29
  %t102 = load ptr, ptr %l56, !tbaa !29
  %t103 = getelementptr { i64, [5 x i64] }, ptr %t102, i32 0, i32 1
  %t104 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t103, i32 0, i32 2
  %t105 = load ptr, ptr %t104
  store ptr %t105, ptr %l57, !tbaa !29
  %t106 = load ptr, ptr %l57, !tbaa !29
  store ptr %t106, ptr %l9, !tbaa !29
  br label %bb26
bb25:
  br label %bb28
bb26:
  store %olang.scope zeroinitializer, ptr %s4
  %t107 = load ptr, ptr %l0, !tbaa !29
  store ptr %t107, ptr %l58, !tbaa !29
  %t108 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t108, ptr %l59
  %t109 = load i32, ptr %l8
  store i32 %t109, ptr %l60
  %t110 = load ptr, ptr %l9, !tbaa !29
  store ptr %t110, ptr %l61, !tbaa !29
  %t111 = load ptr, ptr %l58, !tbaa !29
  %t112 = load %"compiler/source:Span", ptr %l59
  %t113 = load i32, ptr %l60
  %t114 = load ptr, ptr %l61, !tbaa !29
  %t115 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eunary(ptr %v0, ptr %v1, ptr %t111, %"compiler/source:Span" %t112, i32 %t113, ptr %t114)
  store %"compiler/cond:Value" %t115, ptr %l62
  br label %bb27
bb27:
  %t116 = load %"compiler/cond:Value", ptr %l62
  store %"compiler/cond:Value" %t116, ptr %l14
  call void @__olang_scope_close(ptr %s4)
  br label %bb42
bb28:
  %t117 = load ptr, ptr %l1, !tbaa !29
  store ptr %t117, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t118 = load ptr, ptr %l63, !tbaa !29
  %t119 = icmp ne ptr %t118, null
  store i1 %t119, ptr %l65, !tbaa !21
  %t120 = load i1, ptr %l65, !tbaa !21
  br i1 %t120, label %bb29, label %bb30
bb29:
  %t121 = load ptr, ptr %l63, !tbaa !29
  %t122 = load i64, ptr %t121
  store i64 %t122, ptr %l66, !tbaa !24
  %t123 = load i64, ptr %l66, !tbaa !24
  %t124 = icmp eq i64 %t123, 5
  store i1 %t124, ptr %l64, !tbaa !21
  br label %bb30
bb30:
  %t125 = load i1, ptr %l64, !tbaa !21
  br i1 %t125, label %bb31, label %bb32
bb31:
  %t126 = load ptr, ptr %l1, !tbaa !29
  store ptr %t126, ptr %l67, !tbaa !29
  %t127 = load ptr, ptr %l67, !tbaa !29
  %t128 = getelementptr { i64, [5 x i64] }, ptr %t127, i32 0, i32 1
  %t129 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t128, i32 0, i32 0
  %t130 = load %"compiler/source:Span", ptr %t129
  store %"compiler/source:Span" %t130, ptr %l68
  %t131 = load %"compiler/source:Span", ptr %l68
  store %"compiler/source:Span" %t131, ptr %l10
  %t132 = load ptr, ptr %l1, !tbaa !29
  store ptr %t132, ptr %l69, !tbaa !29
  %t133 = load ptr, ptr %l69, !tbaa !29
  %t134 = getelementptr { i64, [5 x i64] }, ptr %t133, i32 0, i32 1
  %t135 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t134, i32 0, i32 1
  %t136 = load i32, ptr %t135
  store i32 %t136, ptr %l70
  %t137 = load i32, ptr %l70
  store i32 %t137, ptr %l11
  %t138 = load ptr, ptr %l1, !tbaa !29
  store ptr %t138, ptr %l71, !tbaa !29
  %t139 = load ptr, ptr %l71, !tbaa !29
  %t140 = getelementptr { i64, [5 x i64] }, ptr %t139, i32 0, i32 1
  %t141 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t140, i32 0, i32 2
  %t142 = load ptr, ptr %t141
  store ptr %t142, ptr %l72, !tbaa !29
  %t143 = load ptr, ptr %l72, !tbaa !29
  store ptr %t143, ptr %l12, !tbaa !29
  %t144 = load ptr, ptr %l1, !tbaa !29
  store ptr %t144, ptr %l73, !tbaa !29
  %t145 = load ptr, ptr %l73, !tbaa !29
  %t146 = getelementptr { i64, [5 x i64] }, ptr %t145, i32 0, i32 1
  %t147 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t146, i32 0, i32 3
  %t148 = load ptr, ptr %t147
  store ptr %t148, ptr %l74, !tbaa !29
  %t149 = load ptr, ptr %l74, !tbaa !29
  store ptr %t149, ptr %l13, !tbaa !29
  br label %bb33
bb32:
  br label %bb35
bb33:
  store %olang.scope zeroinitializer, ptr %s5
  %t150 = load ptr, ptr %l0, !tbaa !29
  store ptr %t150, ptr %l75, !tbaa !29
  %t151 = load %"compiler/source:Span", ptr %l10
  store %"compiler/source:Span" %t151, ptr %l76
  %t152 = load i32, ptr %l11
  store i32 %t152, ptr %l77
  %t153 = load ptr, ptr %l12, !tbaa !29
  store ptr %t153, ptr %l78, !tbaa !29
  %t154 = load ptr, ptr %l13, !tbaa !29
  store ptr %t154, ptr %l79, !tbaa !29
  %t155 = load ptr, ptr %l75, !tbaa !29
  %t156 = load %"compiler/source:Span", ptr %l76
  %t157 = load i32, ptr %l77
  %t158 = load ptr, ptr %l78, !tbaa !29
  %t159 = load ptr, ptr %l79, !tbaa !29
  %t160 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2ebinary(ptr %v0, ptr %v1, ptr %v1, ptr %t155, %"compiler/source:Span" %t156, i32 %t157, ptr %t158, ptr %t159)
  store %"compiler/cond:Value" %t160, ptr %l80
  br label %bb34
bb34:
  %t161 = load %"compiler/cond:Value", ptr %l80
  store %"compiler/cond:Value" %t161, ptr %l14
  call void @__olang_scope_close(ptr %s5)
  br label %bb42
bb35:
  br i1 true, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb41
bb38:
  store %olang.scope zeroinitializer, ptr %s6
  %t162 = load ptr, ptr %l0, !tbaa !29
  store ptr %t162, ptr %l81, !tbaa !29
  %t163 = load ptr, ptr %l0, !tbaa !29
  store ptr %t163, ptr %l82, !tbaa !29
  %t164 = load ptr, ptr %l1, !tbaa !29
  store ptr %t164, ptr %l83, !tbaa !29
  %t165 = load ptr, ptr %l82, !tbaa !29
  %t166 = load ptr, ptr %l83, !tbaa !29
  %t167 = call %"compiler/source:Span" @compiler_2fcond_2ecompiler_2fcond_3aEval_2efirst(ptr %v0, ptr %v1, ptr %t165, ptr %t166)
  store %"compiler/source:Span" %t167, ptr %l84
  br label %bb39
bb39:
  %t168 = load ptr, ptr %l81, !tbaa !29
  %t169 = load %"compiler/source:Span", ptr %l84
  %t170 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t168, %"compiler/source:Span" %t169)
  store %"compiler/cond:Value" %t170, ptr %l85
  br label %bb40
bb40:
  %t171 = load %"compiler/cond:Value", ptr %l85
  store %"compiler/cond:Value" %t171, ptr %l14
  call void @__olang_scope_close(ptr %s6)
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @.c33)
  unreachable
bb42:
  call void @__olang_scope_close(ptr %s0)
  %t172 = load %"compiler/cond:Value", ptr %l14
  store %"compiler/cond:Value" %t172, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cond:Value", ptr %rv
  ret %"compiler/cond:Value" %rr
}

define dso_local %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2efail(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/msgs:Msg" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/msgs:Msg"
  %l3 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca ptr
  %l10 = alloca %"compiler/msgs:Msg"
  %l11 = alloca %"compiler/cond:Value"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca %"compiler/cond:Value"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/msgs:Msg" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = getelementptr %"compiler/cond:Eval", ptr %t2, i32 0, i32 4
  %t4 = load i1, ptr %t3, !tbaa !21
  store i1 %t4, ptr %l4, !tbaa !21
  %t5 = load i1, ptr %l4, !tbaa !21
  %t6 = xor i1 %t5, true
  store i1 %t6, ptr %l5, !tbaa !21
  %t7 = load i1, ptr %l5, !tbaa !21
  br i1 %t7, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l6, !tbaa !29
  %t9 = load ptr, ptr %l6, !tbaa !29
  %t10 = getelementptr %"compiler/cond:Eval", ptr %t9, i32 0, i32 4
  store i1 true, ptr %t10, !tbaa !21
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l7, !tbaa !29
  %t12 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t12, ptr %l8
  %t13 = load %"compiler/source:Span", ptr %l8
  %t14 = load ptr, ptr %l7, !tbaa !29
  %t15 = getelementptr %"compiler/cond:Eval", ptr %t14, i32 0, i32 7
  store %"compiler/source:Span" %t13, ptr %t15
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l9, !tbaa !29
  %t17 = load %"compiler/msgs:Msg", ptr %l2
  store %"compiler/msgs:Msg" %t17, ptr %l10
  %t18 = load %"compiler/msgs:Msg", ptr %l10
  %t19 = load ptr, ptr %l9, !tbaa !29
  %t20 = getelementptr %"compiler/cond:Eval", ptr %t19, i32 0, i32 8
  store %"compiler/msgs:Msg" %t18, ptr %t20
  call void @__olang_scope_close(ptr %s1)
  br label %bb3
bb2:
  br label %bb3
bb3:
  %t21 = call %"compiler/cond:Value" @compiler_2fcond_2enone()
  store %"compiler/cond:Value" %t21, ptr %l11
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t22 = load %"compiler/cond:Value", ptr %l11
  store %"compiler/cond:Value" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cond:Value", ptr %rv
  ret %"compiler/cond:Value" %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcond_2ecompiler_2fcond_3aEval_2efirst(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca ptr
  %l10 = alloca i1
  %l11 = alloca i1
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca %"compiler/source:Span"
  %l18 = alloca ptr
  %l19 = alloca i1
  %l20 = alloca i1
  %l21 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca { i64, ptr }
  %l27 = alloca ptr
  %l28 = alloca %"compiler/source:Span"
  %l29 = alloca ptr
  %l30 = alloca i1
  %l31 = alloca i1
  %l32 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca %"compiler/source:Span"
  %l38 = alloca ptr
  %l39 = alloca i1
  %l40 = alloca i1
  %l41 = alloca i64
  %l42 = alloca ptr
  %l43 = alloca ptr
  %l44 = alloca ptr
  %l45 = alloca i1
  %l46 = alloca i1
  %l47 = alloca i64
  %l48 = alloca ptr
  %l49 = alloca ptr
  %l50 = alloca ptr
  %l51 = alloca i1
  %l52 = alloca i1
  %l53 = alloca i64
  %l54 = alloca ptr
  %l55 = alloca ptr
  %l56 = alloca ptr
  %l57 = alloca ptr
  %l58 = alloca %"compiler/source:Span"
  %l59 = alloca ptr
  %l60 = alloca i1
  %l61 = alloca i1
  %l62 = alloca i64
  %l63 = alloca ptr
  %l64 = alloca ptr
  %l65 = alloca ptr
  %l66 = alloca i1
  %l67 = alloca i1
  %l68 = alloca i64
  %l69 = alloca ptr
  %l70 = alloca ptr
  %l71 = alloca ptr
  %l72 = alloca i1
  %l73 = alloca i1
  %l74 = alloca i64
  %l75 = alloca ptr
  %l76 = alloca ptr
  %l77 = alloca ptr
  %l78 = alloca ptr
  %l79 = alloca %"compiler/source:Span"
  %l80 = alloca ptr
  %l81 = alloca i1
  %l82 = alloca i1
  %l83 = alloca i64
  %l84 = alloca ptr
  %l85 = alloca %"compiler/source:Span"
  %l86 = alloca ptr
  %l87 = alloca i1
  %l88 = alloca i1
  %l89 = alloca i64
  %l90 = alloca ptr
  %l91 = alloca %"compiler/source:Span"
  %l92 = alloca %"compiler/source:Span"
  %l93 = alloca ptr
  %l94 = alloca ptr
  %l95 = alloca %"compiler/source:Span"
  %l96 = alloca i32
  %l97 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  store i1 %t3, ptr %l11, !tbaa !21
  %t4 = load i1, ptr %l11, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5
  store i64 %t6, ptr %l12, !tbaa !24
  %t7 = load i64, ptr %l12, !tbaa !24
  %t8 = icmp eq i64 %t7, 5
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l13, !tbaa !29
  %t11 = load ptr, ptr %l13, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t11, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l14, !tbaa !29
  %t15 = load ptr, ptr %l14, !tbaa !29
  store ptr %t15, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l15, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  store ptr %t17, ptr %l16, !tbaa !29
  %t18 = load ptr, ptr %l15, !tbaa !29
  %t19 = load ptr, ptr %l16, !tbaa !29
  %t20 = call %"compiler/source:Span" @compiler_2fcond_2ecompiler_2fcond_3aEval_2efirst(ptr %v0, ptr %v1, ptr %t18, ptr %t19)
  store %"compiler/source:Span" %t20, ptr %l17
  br label %bb6
bb6:
  %t21 = load %"compiler/source:Span", ptr %l17
  store %"compiler/source:Span" %t21, ptr %l8
  call void @__olang_scope_close(ptr %s1)
  br label %bb68
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t23 = load ptr, ptr %l18, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  store i1 %t24, ptr %l20, !tbaa !21
  %t25 = load i1, ptr %l20, !tbaa !21
  br i1 %t25, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l18, !tbaa !29
  %t27 = load i64, ptr %t26
  store i64 %t27, ptr %l21, !tbaa !24
  %t28 = load i64, ptr %l21, !tbaa !24
  %t29 = icmp eq i64 %t28, 7
  store i1 %t29, ptr %l19, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l19, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  store ptr %t31, ptr %l22, !tbaa !29
  %t32 = load ptr, ptr %l22, !tbaa !29
  %t33 = getelementptr { i64, [5 x i64] }, ptr %t32, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", ptr }, ptr %t33, i32 0, i32 1
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l23, !tbaa !29
  %t36 = load ptr, ptr %l23, !tbaa !29
  store ptr %t36, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t37 = load ptr, ptr %l0, !tbaa !29
  store ptr %t37, ptr %l24, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  store ptr %t38, ptr %l25, !tbaa !29
  %t39 = load ptr, ptr %l25, !tbaa !29
  %t40 = getelementptr %"compiler/ast:Chain", ptr %t39, i32 0, i32 1
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  store { i64, ptr } %t41, ptr %l26, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr ptr, ptr %t43, i64 0
  %t45 = load ptr, ptr %t44, !tbaa !39
  store ptr %t45, ptr %l27, !tbaa !29
  %t46 = load ptr, ptr %l24, !tbaa !29
  %t47 = load ptr, ptr %l27, !tbaa !29
  %t48 = call %"compiler/source:Span" @compiler_2fcond_2ecompiler_2fcond_3aEval_2efirst(ptr %v0, ptr %v1, ptr %t46, ptr %t47)
  store %"compiler/source:Span" %t48, ptr %l28
  br label %bb13
bb13:
  %t49 = load %"compiler/source:Span", ptr %l28
  store %"compiler/source:Span" %t49, ptr %l8
  call void @__olang_scope_close(ptr %s2)
  br label %bb68
bb14:
  %t50 = load ptr, ptr %l1, !tbaa !29
  store ptr %t50, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t51 = load ptr, ptr %l29, !tbaa !29
  %t52 = icmp ne ptr %t51, null
  store i1 %t52, ptr %l31, !tbaa !21
  %t53 = load i1, ptr %l31, !tbaa !21
  br i1 %t53, label %bb15, label %bb16
bb15:
  %t54 = load ptr, ptr %l29, !tbaa !29
  %t55 = load i64, ptr %t54
  store i64 %t55, ptr %l32, !tbaa !24
  %t56 = load i64, ptr %l32, !tbaa !24
  %t57 = icmp eq i64 %t56, 8
  store i1 %t57, ptr %l30, !tbaa !21
  br label %bb16
bb16:
  %t58 = load i1, ptr %l30, !tbaa !21
  br i1 %t58, label %bb17, label %bb18
bb17:
  %t59 = load ptr, ptr %l1, !tbaa !29
  store ptr %t59, ptr %l33, !tbaa !29
  %t60 = load ptr, ptr %l33, !tbaa !29
  %t61 = getelementptr { i64, [5 x i64] }, ptr %t60, i32 0, i32 1
  %t62 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t61, i32 0, i32 1
  %t63 = load ptr, ptr %t62
  store ptr %t63, ptr %l34, !tbaa !29
  %t64 = load ptr, ptr %l34, !tbaa !29
  store ptr %t64, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l35, !tbaa !29
  %t66 = load ptr, ptr %l4, !tbaa !29
  store ptr %t66, ptr %l36, !tbaa !29
  %t67 = load ptr, ptr %l35, !tbaa !29
  %t68 = load ptr, ptr %l36, !tbaa !29
  %t69 = call %"compiler/source:Span" @compiler_2fcond_2ecompiler_2fcond_3aEval_2efirst(ptr %v0, ptr %v1, ptr %t67, ptr %t68)
  store %"compiler/source:Span" %t69, ptr %l37
  br label %bb20
bb20:
  %t70 = load %"compiler/source:Span", ptr %l37
  store %"compiler/source:Span" %t70, ptr %l8
  call void @__olang_scope_close(ptr %s3)
  br label %bb68
bb21:
  %t71 = load ptr, ptr %l1, !tbaa !29
  store ptr %t71, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t72 = load ptr, ptr %l38, !tbaa !29
  %t73 = icmp ne ptr %t72, null
  store i1 %t73, ptr %l40, !tbaa !21
  %t74 = load i1, ptr %l40, !tbaa !21
  br i1 %t74, label %bb22, label %bb23
bb22:
  %t75 = load ptr, ptr %l38, !tbaa !29
  %t76 = load i64, ptr %t75
  store i64 %t76, ptr %l41, !tbaa !24
  %t77 = load i64, ptr %l41, !tbaa !24
  %t78 = icmp eq i64 %t77, 12
  store i1 %t78, ptr %l39, !tbaa !21
  br label %bb23
bb23:
  %t79 = load i1, ptr %l39, !tbaa !21
  br i1 %t79, label %bb24, label %bb25
bb24:
  %t80 = load ptr, ptr %l1, !tbaa !29
  store ptr %t80, ptr %l42, !tbaa !29
  %t81 = load ptr, ptr %l42, !tbaa !29
  %t82 = getelementptr { i64, [5 x i64] }, ptr %t81, i32 0, i32 1
  %t83 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t82, i32 0, i32 1
  %t84 = load ptr, ptr %t83
  store ptr %t84, ptr %l43, !tbaa !29
  %t85 = load ptr, ptr %l43, !tbaa !29
  store ptr %t85, ptr %l5, !tbaa !29
  br label %bb34
bb25:
  %t86 = load ptr, ptr %l1, !tbaa !29
  store ptr %t86, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t87 = load ptr, ptr %l44, !tbaa !29
  %t88 = icmp ne ptr %t87, null
  store i1 %t88, ptr %l46, !tbaa !21
  %t89 = load i1, ptr %l46, !tbaa !21
  br i1 %t89, label %bb26, label %bb27
bb26:
  %t90 = load ptr, ptr %l44, !tbaa !29
  %t91 = load i64, ptr %t90
  store i64 %t91, ptr %l47, !tbaa !24
  %t92 = load i64, ptr %l47, !tbaa !24
  %t93 = icmp eq i64 %t92, 15
  store i1 %t93, ptr %l45, !tbaa !21
  br label %bb27
bb27:
  %t94 = load i1, ptr %l45, !tbaa !21
  br i1 %t94, label %bb28, label %bb29
bb28:
  %t95 = load ptr, ptr %l1, !tbaa !29
  store ptr %t95, ptr %l48, !tbaa !29
  %t96 = load ptr, ptr %l48, !tbaa !29
  %t97 = getelementptr { i64, [5 x i64] }, ptr %t96, i32 0, i32 1
  %t98 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t97, i32 0, i32 1
  %t99 = load ptr, ptr %t98
  store ptr %t99, ptr %l49, !tbaa !29
  %t100 = load ptr, ptr %l49, !tbaa !29
  store ptr %t100, ptr %l5, !tbaa !29
  br label %bb34
bb29:
  %t101 = load ptr, ptr %l1, !tbaa !29
  store ptr %t101, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t102 = load ptr, ptr %l50, !tbaa !29
  %t103 = icmp ne ptr %t102, null
  store i1 %t103, ptr %l52, !tbaa !21
  %t104 = load i1, ptr %l52, !tbaa !21
  br i1 %t104, label %bb30, label %bb31
bb30:
  %t105 = load ptr, ptr %l50, !tbaa !29
  %t106 = load i64, ptr %t105
  store i64 %t106, ptr %l53, !tbaa !24
  %t107 = load i64, ptr %l53, !tbaa !24
  %t108 = icmp eq i64 %t107, 16
  store i1 %t108, ptr %l51, !tbaa !21
  br label %bb31
bb31:
  %t109 = load i1, ptr %l51, !tbaa !21
  br i1 %t109, label %bb32, label %bb33
bb32:
  %t110 = load ptr, ptr %l1, !tbaa !29
  store ptr %t110, ptr %l54, !tbaa !29
  %t111 = load ptr, ptr %l54, !tbaa !29
  %t112 = getelementptr { i64, [5 x i64] }, ptr %t111, i32 0, i32 1
  %t113 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t112, i32 0, i32 1
  %t114 = load ptr, ptr %t113
  store ptr %t114, ptr %l55, !tbaa !29
  %t115 = load ptr, ptr %l55, !tbaa !29
  store ptr %t115, ptr %l5, !tbaa !29
  br label %bb34
bb33:
  br label %bb36
bb34:
  store %olang.scope zeroinitializer, ptr %s4
  %t116 = load ptr, ptr %l0, !tbaa !29
  store ptr %t116, ptr %l56, !tbaa !29
  %t117 = load ptr, ptr %l5, !tbaa !29
  store ptr %t117, ptr %l57, !tbaa !29
  %t118 = load ptr, ptr %l56, !tbaa !29
  %t119 = load ptr, ptr %l57, !tbaa !29
  %t120 = call %"compiler/source:Span" @compiler_2fcond_2ecompiler_2fcond_3aEval_2efirst(ptr %v0, ptr %v1, ptr %t118, ptr %t119)
  store %"compiler/source:Span" %t120, ptr %l58
  br label %bb35
bb35:
  %t121 = load %"compiler/source:Span", ptr %l58
  store %"compiler/source:Span" %t121, ptr %l8
  call void @__olang_scope_close(ptr %s4)
  br label %bb68
bb36:
  %t122 = load ptr, ptr %l1, !tbaa !29
  store ptr %t122, ptr %l59, !tbaa !29
  store i1 false, ptr %l60, !tbaa !21
  %t123 = load ptr, ptr %l59, !tbaa !29
  %t124 = icmp ne ptr %t123, null
  store i1 %t124, ptr %l61, !tbaa !21
  %t125 = load i1, ptr %l61, !tbaa !21
  br i1 %t125, label %bb37, label %bb38
bb37:
  %t126 = load ptr, ptr %l59, !tbaa !29
  %t127 = load i64, ptr %t126
  store i64 %t127, ptr %l62, !tbaa !24
  %t128 = load i64, ptr %l62, !tbaa !24
  %t129 = icmp eq i64 %t128, 10
  store i1 %t129, ptr %l60, !tbaa !21
  br label %bb38
bb38:
  %t130 = load i1, ptr %l60, !tbaa !21
  br i1 %t130, label %bb39, label %bb40
bb39:
  %t131 = load ptr, ptr %l1, !tbaa !29
  store ptr %t131, ptr %l63, !tbaa !29
  %t132 = load ptr, ptr %l63, !tbaa !29
  %t133 = getelementptr { i64, [5 x i64] }, ptr %t132, i32 0, i32 1
  %t134 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t133, i32 0, i32 1
  %t135 = load ptr, ptr %t134
  store ptr %t135, ptr %l64, !tbaa !29
  %t136 = load ptr, ptr %l64, !tbaa !29
  store ptr %t136, ptr %l6, !tbaa !29
  br label %bb49
bb40:
  %t137 = load ptr, ptr %l1, !tbaa !29
  store ptr %t137, ptr %l65, !tbaa !29
  store i1 false, ptr %l66, !tbaa !21
  %t138 = load ptr, ptr %l65, !tbaa !29
  %t139 = icmp ne ptr %t138, null
  store i1 %t139, ptr %l67, !tbaa !21
  %t140 = load i1, ptr %l67, !tbaa !21
  br i1 %t140, label %bb41, label %bb42
bb41:
  %t141 = load ptr, ptr %l65, !tbaa !29
  %t142 = load i64, ptr %t141
  store i64 %t142, ptr %l68, !tbaa !24
  %t143 = load i64, ptr %l68, !tbaa !24
  %t144 = icmp eq i64 %t143, 9
  store i1 %t144, ptr %l66, !tbaa !21
  br label %bb42
bb42:
  %t145 = load i1, ptr %l66, !tbaa !21
  br i1 %t145, label %bb43, label %bb44
bb43:
  %t146 = load ptr, ptr %l1, !tbaa !29
  store ptr %t146, ptr %l69, !tbaa !29
  %t147 = load ptr, ptr %l69, !tbaa !29
  %t148 = getelementptr { i64, [5 x i64] }, ptr %t147, i32 0, i32 1
  %t149 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t148, i32 0, i32 1
  %t150 = load ptr, ptr %t149
  store ptr %t150, ptr %l70, !tbaa !29
  %t151 = load ptr, ptr %l70, !tbaa !29
  store ptr %t151, ptr %l6, !tbaa !29
  br label %bb49
bb44:
  %t152 = load ptr, ptr %l1, !tbaa !29
  store ptr %t152, ptr %l71, !tbaa !29
  store i1 false, ptr %l72, !tbaa !21
  %t153 = load ptr, ptr %l71, !tbaa !29
  %t154 = icmp ne ptr %t153, null
  store i1 %t154, ptr %l73, !tbaa !21
  %t155 = load i1, ptr %l73, !tbaa !21
  br i1 %t155, label %bb45, label %bb46
bb45:
  %t156 = load ptr, ptr %l71, !tbaa !29
  %t157 = load i64, ptr %t156
  store i64 %t157, ptr %l74, !tbaa !24
  %t158 = load i64, ptr %l74, !tbaa !24
  %t159 = icmp eq i64 %t158, 11
  store i1 %t159, ptr %l72, !tbaa !21
  br label %bb46
bb46:
  %t160 = load i1, ptr %l72, !tbaa !21
  br i1 %t160, label %bb47, label %bb48
bb47:
  %t161 = load ptr, ptr %l1, !tbaa !29
  store ptr %t161, ptr %l75, !tbaa !29
  %t162 = load ptr, ptr %l75, !tbaa !29
  %t163 = getelementptr { i64, [5 x i64] }, ptr %t162, i32 0, i32 1
  %t164 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t163, i32 0, i32 1
  %t165 = load ptr, ptr %t164
  store ptr %t165, ptr %l76, !tbaa !29
  %t166 = load ptr, ptr %l76, !tbaa !29
  store ptr %t166, ptr %l6, !tbaa !29
  br label %bb49
bb48:
  br label %bb51
bb49:
  store %olang.scope zeroinitializer, ptr %s5
  %t167 = load ptr, ptr %l0, !tbaa !29
  store ptr %t167, ptr %l77, !tbaa !29
  %t168 = load ptr, ptr %l6, !tbaa !29
  store ptr %t168, ptr %l78, !tbaa !29
  %t169 = load ptr, ptr %l77, !tbaa !29
  %t170 = load ptr, ptr %l78, !tbaa !29
  %t171 = call %"compiler/source:Span" @compiler_2fcond_2ecompiler_2fcond_3aEval_2efirst(ptr %v0, ptr %v1, ptr %t169, ptr %t170)
  store %"compiler/source:Span" %t171, ptr %l79
  br label %bb50
bb50:
  %t172 = load %"compiler/source:Span", ptr %l79
  store %"compiler/source:Span" %t172, ptr %l8
  call void @__olang_scope_close(ptr %s5)
  br label %bb68
bb51:
  %t173 = load ptr, ptr %l1, !tbaa !29
  store ptr %t173, ptr %l80, !tbaa !29
  store i1 false, ptr %l81, !tbaa !21
  %t174 = load ptr, ptr %l80, !tbaa !29
  %t175 = icmp ne ptr %t174, null
  store i1 %t175, ptr %l82, !tbaa !21
  %t176 = load i1, ptr %l82, !tbaa !21
  br i1 %t176, label %bb52, label %bb53
bb52:
  %t177 = load ptr, ptr %l80, !tbaa !29
  %t178 = load i64, ptr %t177
  store i64 %t178, ptr %l83, !tbaa !24
  %t179 = load i64, ptr %l83, !tbaa !24
  %t180 = icmp eq i64 %t179, 1
  store i1 %t180, ptr %l81, !tbaa !21
  br label %bb53
bb53:
  %t181 = load i1, ptr %l81, !tbaa !21
  br i1 %t181, label %bb54, label %bb55
bb54:
  %t182 = load ptr, ptr %l1, !tbaa !29
  store ptr %t182, ptr %l84, !tbaa !29
  %t183 = load ptr, ptr %l84, !tbaa !29
  %t184 = getelementptr { i64, [5 x i64] }, ptr %t183, i32 0, i32 1
  %t185 = getelementptr { %"compiler/source:Span", i32 }, ptr %t184, i32 0, i32 0
  %t186 = load %"compiler/source:Span", ptr %t185
  store %"compiler/source:Span" %t186, ptr %l85
  %t187 = load %"compiler/source:Span", ptr %l85
  store %"compiler/source:Span" %t187, ptr %l7
  br label %bb60
bb55:
  %t188 = load ptr, ptr %l1, !tbaa !29
  store ptr %t188, ptr %l86, !tbaa !29
  store i1 false, ptr %l87, !tbaa !21
  %t189 = load ptr, ptr %l86, !tbaa !29
  %t190 = icmp ne ptr %t189, null
  store i1 %t190, ptr %l88, !tbaa !21
  %t191 = load i1, ptr %l88, !tbaa !21
  br i1 %t191, label %bb56, label %bb57
bb56:
  %t192 = load ptr, ptr %l86, !tbaa !29
  %t193 = load i64, ptr %t192
  store i64 %t193, ptr %l89, !tbaa !24
  %t194 = load i64, ptr %l89, !tbaa !24
  %t195 = icmp eq i64 %t194, 0
  store i1 %t195, ptr %l87, !tbaa !21
  br label %bb57
bb57:
  %t196 = load i1, ptr %l87, !tbaa !21
  br i1 %t196, label %bb58, label %bb59
bb58:
  %t197 = load ptr, ptr %l1, !tbaa !29
  store ptr %t197, ptr %l90, !tbaa !29
  %t198 = load ptr, ptr %l90, !tbaa !29
  %t199 = getelementptr { i64, [5 x i64] }, ptr %t198, i32 0, i32 1
  %t200 = getelementptr { %"compiler/source:Span", i32 }, ptr %t199, i32 0, i32 0
  %t201 = load %"compiler/source:Span", ptr %t200
  store %"compiler/source:Span" %t201, ptr %l91
  %t202 = load %"compiler/source:Span", ptr %l91
  store %"compiler/source:Span" %t202, ptr %l7
  br label %bb60
bb59:
  br label %bb61
bb60:
  store %olang.scope zeroinitializer, ptr %s6
  %t203 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t203, ptr %l92
  %t204 = load %"compiler/source:Span", ptr %l92
  store %"compiler/source:Span" %t204, ptr %l8
  call void @__olang_scope_close(ptr %s6)
  br label %bb68
bb61:
  br i1 true, label %bb62, label %bb63
bb62:
  br label %bb64
bb63:
  br label %bb67
bb64:
  store %olang.scope zeroinitializer, ptr %s7
  %t205 = load ptr, ptr %l0, !tbaa !29
  store ptr %t205, ptr %l93, !tbaa !29
  %t206 = load ptr, ptr %l1, !tbaa !29
  store ptr %t206, ptr %l94, !tbaa !29
  %t207 = load ptr, ptr %l94, !tbaa !29
  %t208 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t207)
  store %"compiler/source:Span" %t208, ptr %l95
  br label %bb65
bb65:
  %t209 = getelementptr %"compiler/source:Span", ptr %l95, i32 0, i32 0
  %t210 = load i32, ptr %t209, !tbaa !23
  store i32 %t210, ptr %l96, !tbaa !23
  %t211 = load ptr, ptr %l93, !tbaa !29
  %t212 = load i32, ptr %l96, !tbaa !23
  %t213 = call %"compiler/source:Span" @compiler_2fcond_2ecompiler_2fcond_3aEval_2etokenAt(ptr %v0, ptr %t211, i32 %t212)
  store %"compiler/source:Span" %t213, ptr %l97
  br label %bb66
bb66:
  %t214 = load %"compiler/source:Span", ptr %l97
  store %"compiler/source:Span" %t214, ptr %l8
  call void @__olang_scope_close(ptr %s7)
  br label %bb68
bb67:
  call void @__olang_check_failed(ptr @.c34)
  unreachable
bb68:
  call void @__olang_scope_close(ptr %s0)
  %t215 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t215, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2efloatDeclared(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/cond:Value" %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/cond:Value"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca %"compiler/cond:Value"
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca ptr
  %l13 = alloca i1
  %l14 = alloca i64
  %l15 = alloca i1
  %l16 = alloca i1
  %l17 = alloca i64
  %l18 = alloca i1
  %l19 = alloca i1
  %l20 = alloca i64
  %l21 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca %"compiler/source:Span"
  %l24 = alloca %"compiler/cond:Value"
  %l25 = alloca i32
  %l26 = alloca i64
  %l27 = alloca double
  %l28 = alloca %"compiler/cond:Value"
  %l29 = alloca i32
  %l30 = alloca ptr
  %l31 = alloca i32
  %l32 = alloca ptr
  %l33 = alloca i1
  %l34 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca %"compiler/source:Span"
  %l37 = alloca %"compiler/cond:Value"
  %l38 = alloca i32
  %l39 = alloca double
  %l40 = alloca %"compiler/cond:Value"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca %"compiler/cond:Value"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/cond:Value" %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l3, !tbaa !24
  store i64 %t1, ptr %l4, !tbaa !24
  %t2 = load i64, ptr %l4, !tbaa !24
  %t3 = icmp ne i64 %t2, 64
  store i1 %t3, ptr %l5, !tbaa !21
  %t4 = load i1, ptr %l5, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l6, !tbaa !29
  %t6 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t6, ptr %l7
  %t7 = load ptr, ptr %l6, !tbaa !29
  %t8 = load %"compiler/source:Span", ptr %l7
  %t9 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t7, %"compiler/source:Span" %t8)
  store %"compiler/cond:Value" %t9, ptr %l8
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t10 = load %"compiler/cond:Value", ptr %l8
  store %"compiler/cond:Value" %t10, ptr %rv
  br label %ret
bb4:
  %t11 = getelementptr %"compiler/cond:Value", ptr %l2, i32 0, i32 0
  %t12 = load i32, ptr %t11
  store i32 %t12, ptr %l9
  store ptr %l9, ptr %l10, !tbaa !29
  store i32 2, ptr %l11
  store ptr %l11, ptr %l12, !tbaa !29
  %t13 = load ptr, ptr %l10, !tbaa !29
  %t14 = load ptr, ptr %l12, !tbaa !29
  %t15 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %t13, ptr %t14)
  store i1 %t15, ptr %l13
  br label %bb5
bb5:
  %t16 = load i1, ptr %l13, !tbaa !21
  br i1 %t16, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t17 = getelementptr %"compiler/cond:Value", ptr %l2, i32 0, i32 4
  %t18 = load i64, ptr %t17, !tbaa !24
  store i64 %t18, ptr %l14, !tbaa !24
  %t19 = load i64, ptr %l14, !tbaa !24
  %t20 = icmp ne i64 %t19, 0
  store i1 %t20, ptr %l15, !tbaa !21
  %t21 = load i1, ptr %l15, !tbaa !21
  br i1 %t21, label %bb8, label %bb9
bb7:
  br label %bb19
bb8:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb10
bb9:
  %t22 = getelementptr %"compiler/cond:Value", ptr %l2, i32 0, i32 1
  %t23 = load i64, ptr %t22, !tbaa !24
  store i64 %t23, ptr %l17, !tbaa !24
  %t24 = load i64, ptr %l17, !tbaa !24
  %t25 = icmp sgt i64 %t24, 9007199254740992
  store i1 %t25, ptr %l18, !tbaa !21
  %t26 = load i1, ptr %l18, !tbaa !21
  store i1 %t26, ptr %l16, !tbaa !21
  br label %bb10
bb10:
  %t27 = load i1, ptr %l16, !tbaa !21
  br i1 %t27, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb13
bb12:
  %t28 = getelementptr %"compiler/cond:Value", ptr %l2, i32 0, i32 1
  %t29 = load i64, ptr %t28, !tbaa !24
  store i64 %t29, ptr %l20, !tbaa !24
  %t30 = load i64, ptr %l20, !tbaa !24
  %t31 = icmp slt i64 %t30, -9007199254740992
  store i1 %t31, ptr %l21, !tbaa !21
  %t32 = load i1, ptr %l21, !tbaa !21
  store i1 %t32, ptr %l19, !tbaa !21
  br label %bb13
bb13:
  %t33 = load i1, ptr %l19, !tbaa !21
  br i1 %t33, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l22, !tbaa !29
  %t35 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t35, ptr %l23
  %t36 = load ptr, ptr %l22, !tbaa !29
  %t37 = load %"compiler/source:Span", ptr %l23
  %t38 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t36, %"compiler/source:Span" %t37)
  store %"compiler/cond:Value" %t38, ptr %l24
  br label %bb16
bb15:
  br label %bb17
bb16:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t39 = load %"compiler/cond:Value", ptr %l24
  store %"compiler/cond:Value" %t39, ptr %rv
  br label %ret
bb17:
  store i32 3, ptr %l25
  %t40 = getelementptr %"compiler/cond:Value", ptr %l2, i32 0, i32 1
  %t41 = load i64, ptr %t40, !tbaa !24
  store i64 %t41, ptr %l26, !tbaa !24
  %t42 = load i64, ptr %l26, !tbaa !24
  %t43 = sitofp i64 %t42 to double
  store double %t43, ptr %l27, !tbaa !26
  %t44 = load i32, ptr %l25
  %t45 = load double, ptr %l27, !tbaa !26
  %t46 = call %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %s2, i32 %t44, i64 0, double %t45, i64 0, i64 64, i1 false)
  store %"compiler/cond:Value" %t46, ptr %l28
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t47 = load %"compiler/cond:Value", ptr %l28
  store %"compiler/cond:Value" %t47, ptr %rv
  br label %ret
bb19:
  %t48 = getelementptr %"compiler/cond:Value", ptr %l2, i32 0, i32 0
  %t49 = load i32, ptr %t48
  store i32 %t49, ptr %l29
  store ptr %l29, ptr %l30, !tbaa !29
  store i32 3, ptr %l31
  store ptr %l31, ptr %l32, !tbaa !29
  %t50 = load ptr, ptr %l30, !tbaa !29
  %t51 = load ptr, ptr %l32, !tbaa !29
  %t52 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %t50, ptr %t51)
  store i1 %t52, ptr %l33
  br label %bb20
bb20:
  %t53 = load i1, ptr %l33, !tbaa !21
  %t54 = xor i1 %t53, true
  store i1 %t54, ptr %l34, !tbaa !21
  %t55 = load i1, ptr %l34, !tbaa !21
  br i1 %t55, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s4
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l35, !tbaa !29
  %t57 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t57, ptr %l36
  %t58 = load ptr, ptr %l35, !tbaa !29
  %t59 = load %"compiler/source:Span", ptr %l36
  %t60 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t58, %"compiler/source:Span" %t59)
  store %"compiler/cond:Value" %t60, ptr %l37
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t61 = load %"compiler/cond:Value", ptr %l37
  store %"compiler/cond:Value" %t61, ptr %rv
  br label %ret
bb24:
  store i32 3, ptr %l38
  %t62 = getelementptr %"compiler/cond:Value", ptr %l2, i32 0, i32 2
  %t63 = load double, ptr %t62, !tbaa !26
  store double %t63, ptr %l39, !tbaa !26
  %t64 = load i32, ptr %l38
  %t65 = load double, ptr %l39, !tbaa !26
  %t66 = call %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %s0, i32 %t64, i64 0, double %t65, i64 0, i64 64, i1 false)
  store %"compiler/cond:Value" %t66, ptr %l40
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s0)
  %t67 = load %"compiler/cond:Value", ptr %l40
  store %"compiler/cond:Value" %t67, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cond:Value", ptr %rv
  ret %"compiler/cond:Value" %rr
}

define dso_local %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eglobal(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca { i32, i64, i1 }
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i1
  %l8 = alloca i1
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca %"compiler/source:Span"
  %l12 = alloca %"compiler/msgs:Msg"
  %l13 = alloca i1
  %l14 = alloca i1
  %l15 = alloca i1
  %l16 = alloca %"compiler/cond:Value"
  %l17 = alloca i1
  %l18 = alloca i1
  %l19 = alloca %"compiler/msgs:Msg"
  %l20 = alloca i1
  %l21 = alloca i1
  %l22 = alloca i1
  %l23 = alloca %"compiler/source:Span"
  %l24 = alloca %"compiler/msgs:Msg"
  %l25 = alloca i1
  %l26 = alloca %"compiler/cond:Value"
  %l27 = alloca %"compiler/cond:Value"
  %l28 = alloca ptr
  %l29 = alloca i64
  %l30 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca %"compiler/source:Span"
  %l33 = alloca ptr
  %l34 = alloca %"compiler/source:Span"
  %l35 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l37 = alloca %"compiler/msgs:Msg"
  %l38 = alloca %"compiler/cond:Value"
  %l39 = alloca ptr
  %l40 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca %"compiler/source:Span"
  %l43 = alloca ptr
  %l44 = alloca %"compiler/source:Span"
  %l45 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l47 = alloca %"compiler/msgs:Msg"
  %l48 = alloca %"compiler/cond:Value"
  %l49 = alloca ptr
  %l50 = alloca ptr
  %l51 = alloca i1
  %l52 = alloca i1
  %l53 = alloca i1
  %l54 = alloca ptr
  %l55 = alloca ptr
  %l56 = alloca ptr
  %l57 = alloca { i64, ptr }
  %l58 = alloca i1
  %l59 = alloca ptr
  %l60 = alloca { i64, ptr }
  %l61 = alloca { i32, i64, i1 }
  %l62 = alloca i32
  %l63 = alloca i64
  %l64 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca ptr
  %l67 = alloca i1
  %l68 = alloca i1
  %l69 = alloca i1
  %l70 = alloca ptr
  %l71 = alloca { i64, ptr }
  %l72 = alloca i1
  %l73 = alloca i1
  %l74 = alloca i1
  %l75 = alloca i32
  %l76 = alloca ptr
  %l77 = alloca i32
  %l78 = alloca ptr
  %l79 = alloca i1
  %l80 = alloca i1
  %l81 = alloca i32
  %l82 = alloca i64
  %l83 = alloca i1
  %l84 = alloca %"compiler/cond:Value"
  %l85 = alloca i1
  %l86 = alloca ptr
  %l87 = alloca i64
  %l88 = alloca i1
  %l89 = alloca ptr
  %l90 = alloca i1
  %l91 = alloca ptr
  %l92 = alloca %"compiler/source:Span"
  %l93 = alloca ptr
  %l94 = alloca ptr
  %l95 = alloca %"compiler/source:Span"
  %l96 = alloca ptr
  %l97 = alloca { i64, ptr }
  %l98 = alloca %"compiler/cond:Value"
  %l99 = alloca %"compiler/cond:Value"
  %l100 = alloca ptr
  %l101 = alloca i1
  %l102 = alloca ptr
  %l103 = alloca i1
  %l104 = alloca ptr
  %l105 = alloca i1
  %l106 = alloca ptr
  %l107 = alloca %"compiler/source:Span"
  %l108 = alloca ptr
  %l109 = alloca %"compiler/msgs:Msg"
  %l110 = alloca ptr
  %l111 = alloca i1
  %l112 = alloca ptr
  %l113 = alloca i1
  %l114 = alloca ptr
  %l115 = alloca i1
  %l116 = alloca ptr
  %l117 = alloca i64
  %l118 = alloca i64
  %l119 = alloca ptr
  %l120 = alloca ptr
  %l121 = alloca ptr
  %l122 = alloca %"compiler/cond:Value"
  %l123 = alloca ptr
  %l124 = alloca i64
  %l125 = alloca i64
  %l126 = alloca ptr
  %l127 = alloca i1
  %l128 = alloca ptr
  %l129 = alloca i1
  %l130 = alloca ptr
  %l131 = alloca %"compiler/msgs:Msg"
  %l132 = alloca i1
  %l133 = alloca i1
  %l134 = alloca i1
  %l135 = alloca %"compiler/source:Span"
  %l136 = alloca %"compiler/msgs:Msg"
  %l137 = alloca ptr
  %l138 = alloca i1
  %l139 = alloca ptr
  %l140 = alloca i1
  %l141 = alloca ptr
  %l142 = alloca i1
  %l143 = alloca ptr
  %l144 = alloca %"compiler/source:Span"
  %l145 = alloca ptr
  %l146 = alloca %"compiler/msgs:Msg"
  %l147 = alloca i1
  %l148 = alloca ptr
  %l149 = alloca i1
  %l150 = alloca i1
  %l151 = alloca ptr
  %l152 = alloca i64
  %l153 = alloca i1
  %l154 = alloca %"compiler/cond:Value"
  %l155 = alloca i32
  %l156 = alloca ptr
  %l157 = alloca i32
  %l158 = alloca ptr
  %l159 = alloca i1
  %l160 = alloca ptr
  %l161 = alloca %"compiler/source:Span"
  %l162 = alloca i1
  %l163 = alloca %"compiler/msgs:Msg"
  %l164 = alloca ptr
  %l165 = alloca %"compiler/source:Span"
  %l166 = alloca { i64, ptr }
  %l167 = alloca { i64, ptr }
  %l168 = alloca %"compiler/msgs:Msg"
  %l169 = alloca ptr
  %l170 = alloca %"compiler/source:Span"
  %l171 = alloca { i64, ptr }
  %l172 = alloca { i64, ptr }
  %l173 = alloca %"compiler/msgs:Msg"
  %l174 = alloca %"compiler/cond:Value"
  %l175 = alloca ptr
  %l176 = alloca i1
  %l177 = alloca %"compiler/cond:Value"
  %l178 = alloca ptr
  %l179 = alloca i1
  %l180 = alloca i1
  %l181 = alloca ptr
  %l182 = alloca %"compiler/source:Span"
  %l183 = alloca %"compiler/cond:Value"
  %l184 = alloca ptr
  %l185 = alloca %"compiler/source:Span"
  %l186 = alloca ptr
  %l187 = alloca %"compiler/cond:Value"
  %l188 = alloca %"compiler/cond:Value"
  %l189 = alloca ptr
  %l190 = alloca ptr
  %l191 = alloca i1
  %l192 = alloca i1
  %l193 = alloca i1
  %l194 = alloca ptr
  %l195 = alloca { i64, ptr }
  %l196 = alloca i1
  %l197 = alloca i1
  %l198 = alloca %"compiler/cond:Value"
  %l199 = alloca i1
  %l200 = alloca ptr
  %l201 = alloca i64
  %l202 = alloca i1
  %l203 = alloca ptr
  %l204 = alloca i1
  %l205 = alloca ptr
  %l206 = alloca %"compiler/source:Span"
  %l207 = alloca ptr
  %l208 = alloca { i64, ptr }
  %l209 = alloca %"compiler/cond:Value"
  %l210 = alloca i32
  %l211 = alloca ptr
  %l212 = alloca i32
  %l213 = alloca ptr
  %l214 = alloca i1
  %l215 = alloca %"compiler/cond:Value"
  %l216 = alloca i32
  %l217 = alloca ptr
  %l218 = alloca i32
  %l219 = alloca ptr
  %l220 = alloca i1
  %l221 = alloca i1
  %l222 = alloca i32
  %l223 = alloca ptr
  %l224 = alloca i32
  %l225 = alloca ptr
  %l226 = alloca i1
  %l227 = alloca i64
  %l228 = alloca i1
  %l229 = alloca i1
  %l230 = alloca i64
  %l231 = alloca i1
  %l232 = alloca i1
  %l233 = alloca i64
  %l234 = alloca i1
  %l235 = alloca ptr
  %l236 = alloca %"compiler/source:Span"
  %l237 = alloca %"compiler/cond:Value"
  %l238 = alloca i32
  %l239 = alloca i64
  %l240 = alloca double
  %l241 = alloca %"compiler/cond:Value"
  %l242 = alloca i32
  %l243 = alloca ptr
  %l244 = alloca i32
  %l245 = alloca ptr
  %l246 = alloca i1
  %l247 = alloca i1
  %l248 = alloca ptr
  %l249 = alloca %"compiler/source:Span"
  %l250 = alloca %"compiler/cond:Value"
  %l251 = alloca i32
  %l252 = alloca ptr
  %l253 = alloca i32
  %l254 = alloca ptr
  %l255 = alloca i1
  %l256 = alloca i1
  %l257 = alloca i64
  %l258 = alloca i64
  %l259 = alloca i1
  %l260 = alloca i1
  %l261 = alloca i1
  %l262 = alloca ptr
  %l263 = alloca %"compiler/source:Span"
  %l264 = alloca %"compiler/cond:Value"
  %l265 = alloca i32
  %l266 = alloca i64
  %l267 = alloca double
  %l268 = alloca i64
  %l269 = alloca i64
  %l270 = alloca i1
  %l271 = alloca %"compiler/cond:Value"
  %l272 = alloca %"compiler/cond:Value"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %rv = alloca %"compiler/cond:Value"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l28, !tbaa !29
  %t2 = load ptr, ptr %l28, !tbaa !29
  %t3 = getelementptr %"compiler/cond:Eval", ptr %t2, i32 0, i32 9
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %l29, !tbaa !24
  %t5 = load i64, ptr %l29, !tbaa !24
  %t6 = icmp sgt i64 %t5, 64
  store i1 %t6, ptr %l30, !tbaa !21
  %t7 = load i1, ptr %l30, !tbaa !21
  br i1 %t7, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l31, !tbaa !29
  %t9 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t9, ptr %l32
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l33, !tbaa !29
  %t11 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t11, ptr %l34
  %t12 = load ptr, ptr %l33, !tbaa !29
  %t13 = load %"compiler/source:Span", ptr %l34
  %t14 = call { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aEval_2etokText(ptr %v0, ptr %v0, ptr %t12, %"compiler/source:Span" %t13)
  store { i64, ptr } %t14, ptr %l35
  br label %bb3
bb2:
  br label %bb6
bb3:
  %t15 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l36, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t23 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondCycle(ptr %v0, ptr %v0, { i64, ptr } %t22)
  store %"compiler/msgs:Msg" %t23, ptr %l37
  br label %bb4
bb4:
  %t24 = load ptr, ptr %l31, !tbaa !29
  %t25 = load %"compiler/source:Span", ptr %l32
  %t26 = load %"compiler/msgs:Msg", ptr %l37
  %t27 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2efail(ptr %v0, ptr %v0, ptr %t24, %"compiler/source:Span" %t25, %"compiler/msgs:Msg" %t26)
  store %"compiler/cond:Value" %t27, ptr %l38
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t28 = load %"compiler/cond:Value", ptr %l38
  store %"compiler/cond:Value" %t28, ptr %rv
  br label %ret
bb6:
  %t29 = load ptr, ptr %l2, !tbaa !29
  store ptr %t29, ptr %l39, !tbaa !29
  %t30 = load ptr, ptr %l39, !tbaa !29
  %t31 = getelementptr %"compiler/cond:Global", ptr %t30, i32 0, i32 2
  %t32 = load i1, ptr %t31, !tbaa !21
  store i1 %t32, ptr %l40, !tbaa !21
  %t33 = load i1, ptr %l40, !tbaa !21
  br i1 %t33, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l41, !tbaa !29
  %t35 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t35, ptr %l42
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l43, !tbaa !29
  %t37 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t37, ptr %l44
  %t38 = load ptr, ptr %l43, !tbaa !29
  %t39 = load %"compiler/source:Span", ptr %l44
  %t40 = call { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aEval_2etokText(ptr %v0, ptr %v0, ptr %t38, %"compiler/source:Span" %t39)
  store { i64, ptr } %t40, ptr %l45
  br label %bb9
bb8:
  br label %bb12
bb9:
  %t41 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t41, 0
  %t43 = extractvalue { i64, ptr } %t41, 1
  %t44 = mul i64 %t42, 1
  %t45 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t44)
  call void @llvm.memcpy.p0.p0.i64(ptr %t45, ptr %t43, i64 %t44, i1 false)
  %t46 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  store { i64, ptr } %t47, ptr %l46, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t49 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondMutable(ptr %v0, ptr %v0, { i64, ptr } %t48)
  store %"compiler/msgs:Msg" %t49, ptr %l47
  br label %bb10
bb10:
  %t50 = load ptr, ptr %l41, !tbaa !29
  %t51 = load %"compiler/source:Span", ptr %l42
  %t52 = load %"compiler/msgs:Msg", ptr %l47
  %t53 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eruntimeValue(ptr %v0, ptr %v0, ptr %t50, %"compiler/source:Span" %t51, %"compiler/msgs:Msg" %t52, i1 false)
  store %"compiler/cond:Value" %t53, ptr %l48
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t54 = load %"compiler/cond:Value", ptr %l48
  store %"compiler/cond:Value" %t54, ptr %rv
  br label %ret
bb12:
  %t55 = load ptr, ptr %l0, !tbaa !29
  store ptr %t55, ptr %l49, !tbaa !29
  %t56 = load ptr, ptr %l49, !tbaa !29
  %t57 = getelementptr %"compiler/cond:Eval", ptr %t56, i32 0, i32 2
  %t58 = load ptr, ptr %t57, !tbaa !29
  store ptr %t58, ptr %l50, !tbaa !29
  %t59 = load ptr, ptr %l50, !tbaa !29
  %t60 = getelementptr %"compiler/cond:Scope", ptr %t59, i32 0, i32 0
  %t61 = load i1, ptr %t60, !tbaa !21
  store i1 %t61, ptr %l51, !tbaa !21
  %t62 = load i1, ptr %l51, !tbaa !21
  %t63 = xor i1 %t62, true
  store i1 %t63, ptr %l52, !tbaa !21
  %t64 = load i1, ptr %l52, !tbaa !21
  br i1 %t64, label %bb13, label %bb14
bb13:
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l54, !tbaa !29
  %t66 = load ptr, ptr %l54, !tbaa !29
  %t67 = getelementptr %"compiler/cond:Eval", ptr %t66, i32 0, i32 3
  %t68 = load ptr, ptr %t67, !tbaa !29
  store ptr %t68, ptr %l55, !tbaa !29
  %t69 = load ptr, ptr %l2, !tbaa !29
  store ptr %t69, ptr %l56, !tbaa !29
  %t70 = load ptr, ptr %l56, !tbaa !29
  %t71 = getelementptr %"compiler/cond:Global", ptr %t70, i32 0, i32 0
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !27
  store { i64, ptr } %t72, ptr %l57, !tbaa !27
  %t73 = load ptr, ptr %l55, !tbaa !29
  %t74 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t75 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eDefined(ptr %v0, ptr %v1, ptr %t73, { i64, ptr } %t74)
  store i1 %t75, ptr %l58
  br label %bb15
bb14:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb16
bb15:
  %t76 = load i1, ptr %l58, !tbaa !21
  store i1 %t76, ptr %l53, !tbaa !21
  br label %bb16
bb16:
  %t77 = load i1, ptr %l53, !tbaa !21
  store i1 %t77, ptr %l3, !tbaa !21
  %t78 = load ptr, ptr %l2, !tbaa !29
  store ptr %t78, ptr %l59, !tbaa !29
  %t79 = load ptr, ptr %l59, !tbaa !29
  %t80 = getelementptr %"compiler/cond:Global", ptr %t79, i32 0, i32 3
  %t81 = load { i64, ptr }, ptr %t80, !tbaa !27
  store { i64, ptr } %t81, ptr %l60, !tbaa !27
  %t82 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t83 = call { i32, i64, i1 } @compiler_2fcond_2edeclaredKind(ptr %v1, { i64, ptr } %t82)
  store { i32, i64, i1 } %t83, ptr %l61
  br label %bb17
bb17:
  %t84 = load { i32, i64, i1 }, ptr %l61
  store { i32, i64, i1 } %t84, ptr %l4
  %t85 = getelementptr { i32, i64, i1 }, ptr %l4, i32 0, i32 0
  %t86 = load i32, ptr %t85
  store i32 %t86, ptr %l62
  %t87 = load i32, ptr %l62
  store i32 %t87, ptr %l5
  %t88 = getelementptr { i32, i64, i1 }, ptr %l4, i32 0, i32 1
  %t89 = load i64, ptr %t88, !tbaa !24
  store i64 %t89, ptr %l63, !tbaa !24
  %t90 = load i64, ptr %l63, !tbaa !24
  store i64 %t90, ptr %l6, !tbaa !24
  %t91 = getelementptr { i32, i64, i1 }, ptr %l4, i32 0, i32 2
  %t92 = load i1, ptr %t91, !tbaa !21
  store i1 %t92, ptr %l64, !tbaa !21
  %t93 = load i1, ptr %l64, !tbaa !21
  store i1 %t93, ptr %l7, !tbaa !21
  %t94 = load ptr, ptr %l0, !tbaa !29
  store ptr %t94, ptr %l65, !tbaa !29
  %t95 = load ptr, ptr %l65, !tbaa !29
  %t96 = getelementptr %"compiler/cond:Eval", ptr %t95, i32 0, i32 2
  %t97 = load ptr, ptr %t96, !tbaa !29
  store ptr %t97, ptr %l66, !tbaa !29
  %t98 = load ptr, ptr %l66, !tbaa !29
  %t99 = getelementptr %"compiler/cond:Scope", ptr %t98, i32 0, i32 0
  %t100 = load i1, ptr %t99, !tbaa !21
  store i1 %t100, ptr %l67, !tbaa !21
  %t101 = load i1, ptr %l67, !tbaa !21
  %t102 = xor i1 %t101, true
  store i1 %t102, ptr %l68, !tbaa !21
  %t103 = load i1, ptr %l68, !tbaa !21
  br i1 %t103, label %bb18, label %bb19
bb18:
  %t104 = load ptr, ptr %l2, !tbaa !29
  store ptr %t104, ptr %l70, !tbaa !29
  %t105 = load ptr, ptr %l70, !tbaa !29
  %t106 = getelementptr %"compiler/cond:Global", ptr %t105, i32 0, i32 3
  %t107 = load { i64, ptr }, ptr %t106, !tbaa !27
  store { i64, ptr } %t107, ptr %l71, !tbaa !27
  %t108 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t109 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t108, { i64, ptr } { i64 0, ptr @.d35 })
  store i1 %t109, ptr %l72
  br label %bb20
bb19:
  store i1 false, ptr %l69, !tbaa !21
  br label %bb21
bb20:
  %t110 = load i1, ptr %l72, !tbaa !21
  %t111 = xor i1 %t110, true
  store i1 %t111, ptr %l73, !tbaa !21
  %t112 = load i1, ptr %l73, !tbaa !21
  store i1 %t112, ptr %l69, !tbaa !21
  br label %bb21
bb21:
  %t113 = load i1, ptr %l69, !tbaa !21
  br i1 %t113, label %bb22, label %bb23
bb22:
  %t114 = load i32, ptr %l5
  store i32 %t114, ptr %l75
  store ptr %l75, ptr %l76, !tbaa !29
  store i32 0, ptr %l77
  store ptr %l77, ptr %l78, !tbaa !29
  %t115 = load ptr, ptr %l76, !tbaa !29
  %t116 = load ptr, ptr %l78, !tbaa !29
  %t117 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %t115, ptr %t116)
  store i1 %t117, ptr %l79
  br label %bb24
bb23:
  store i1 false, ptr %l74, !tbaa !21
  br label %bb25
bb24:
  %t118 = load i1, ptr %l79, !tbaa !21
  %t119 = xor i1 %t118, true
  store i1 %t119, ptr %l80, !tbaa !21
  %t120 = load i1, ptr %l80, !tbaa !21
  store i1 %t120, ptr %l74, !tbaa !21
  br label %bb25
bb25:
  %t121 = load i1, ptr %l74, !tbaa !21
  br i1 %t121, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s3
  %t122 = load i32, ptr %l5
  store i32 %t122, ptr %l81
  %t123 = load i64, ptr %l6, !tbaa !24
  store i64 %t123, ptr %l82, !tbaa !24
  %t124 = load i1, ptr %l7, !tbaa !21
  store i1 %t124, ptr %l83, !tbaa !21
  %t125 = load i32, ptr %l81
  %t126 = load i64, ptr %l82, !tbaa !24
  %t127 = load i1, ptr %l83, !tbaa !21
  %t128 = call %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %s3, i32 %t125, i64 0, double 0x0000000000000000, i64 0, i64 %t126, i1 %t127)
  store %"compiler/cond:Value" %t128, ptr %l84
  br label %bb28
bb27:
  br label %bb41
bb28:
  %t129 = load %"compiler/cond:Value", ptr %l84
  %t130 = call i1 @compiler_2fcond_2ebuildType(%"compiler/cond:Value" %t129)
  store i1 %t130, ptr %l85
  br label %bb29
bb29:
  %t131 = load i1, ptr %l85, !tbaa !21
  br i1 %t131, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s4
  %t132 = load ptr, ptr %l0, !tbaa !29
  store ptr %t132, ptr %l86, !tbaa !29
  %t133 = load ptr, ptr %l86, !tbaa !29
  %t134 = getelementptr %"compiler/cond:Eval", ptr %t133, i32 0, i32 10
  %t135 = load i64, ptr %t134, !tbaa !24
  store i64 %t135, ptr %l87, !tbaa !24
  %t136 = load i64, ptr %l87, !tbaa !24
  %t137 = icmp eq i64 %t136, 0
  store i1 %t137, ptr %l88, !tbaa !21
  %t138 = load i1, ptr %l88, !tbaa !21
  br i1 %t138, label %bb32, label %bb33
bb31:
  br label %bb40
bb32:
  store %olang.scope zeroinitializer, ptr %s5
  %t139 = load ptr, ptr %l0, !tbaa !29
  store ptr %t139, ptr %l89, !tbaa !29
  %t140 = load ptr, ptr %l89, !tbaa !29
  %t141 = getelementptr %"compiler/cond:Eval", ptr %t140, i32 0, i32 11
  store i1 true, ptr %t141, !tbaa !21
  call void @__olang_scope_close(ptr %s5)
  br label %bb34
bb33:
  br label %bb34
bb34:
  %t142 = load i1, ptr %l3, !tbaa !21
  store i1 %t142, ptr %l90, !tbaa !21
  %t143 = load i1, ptr %l90, !tbaa !21
  br i1 %t143, label %bb35, label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s6
  %t144 = load ptr, ptr %l0, !tbaa !29
  store ptr %t144, ptr %l91, !tbaa !29
  %t145 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t145, ptr %l92
  %t146 = load ptr, ptr %l2, !tbaa !29
  store ptr %t146, ptr %l93, !tbaa !29
  %t147 = load ptr, ptr %l0, !tbaa !29
  store ptr %t147, ptr %l94, !tbaa !29
  %t148 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t148, ptr %l95
  %t149 = load ptr, ptr %l2, !tbaa !29
  store ptr %t149, ptr %l96, !tbaa !29
  %t150 = load ptr, ptr %l96, !tbaa !29
  %t151 = getelementptr %"compiler/cond:Global", ptr %t150, i32 0, i32 0
  %t152 = load { i64, ptr }, ptr %t151, !tbaa !27
  store { i64, ptr } %t152, ptr %l97, !tbaa !27
  %t153 = load ptr, ptr %l94, !tbaa !29
  %t154 = load %"compiler/source:Span", ptr %l95
  %t155 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t156 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefinedValue(ptr %v0, ptr %v1, ptr %t153, %"compiler/source:Span" %t154, { i64, ptr } %t155)
  store %"compiler/cond:Value" %t156, ptr %l98
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t157 = load ptr, ptr %l91, !tbaa !29
  %t158 = load %"compiler/source:Span", ptr %l92
  %t159 = load ptr, ptr %l93, !tbaa !29
  %t160 = load %"compiler/cond:Value", ptr %l98
  %t161 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2easDeclared(ptr %v0, ptr %v1, ptr %t157, %"compiler/source:Span" %t158, ptr %t159, %"compiler/cond:Value" %t160)
  store %"compiler/cond:Value" %t161, ptr %l99
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t162 = load %"compiler/cond:Value", ptr %l99
  store %"compiler/cond:Value" %t162, ptr %rv
  br label %ret
bb39:
  call void @__olang_scope_close(ptr %s4)
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s3)
  br label %bb41
bb41:
  %t163 = load ptr, ptr %l0, !tbaa !29
  store ptr %t163, ptr %l100, !tbaa !29
  %t164 = load ptr, ptr %l100, !tbaa !29
  %t165 = getelementptr %"compiler/cond:Eval", ptr %t164, i32 0, i32 4
  %t166 = load i1, ptr %t165, !tbaa !21
  store i1 %t166, ptr %l101, !tbaa !21
  %t167 = load i1, ptr %l101, !tbaa !21
  store i1 %t167, ptr %l8, !tbaa !21
  %t168 = load ptr, ptr %l0, !tbaa !29
  store ptr %t168, ptr %l102, !tbaa !29
  %t169 = load ptr, ptr %l102, !tbaa !29
  %t170 = getelementptr %"compiler/cond:Eval", ptr %t169, i32 0, i32 5
  %t171 = load i1, ptr %t170, !tbaa !21
  store i1 %t171, ptr %l103, !tbaa !21
  %t172 = load i1, ptr %l103, !tbaa !21
  store i1 %t172, ptr %l9, !tbaa !21
  %t173 = load ptr, ptr %l0, !tbaa !29
  store ptr %t173, ptr %l104, !tbaa !29
  %t174 = load ptr, ptr %l104, !tbaa !29
  %t175 = getelementptr %"compiler/cond:Eval", ptr %t174, i32 0, i32 6
  %t176 = load i1, ptr %t175, !tbaa !21
  store i1 %t176, ptr %l105, !tbaa !21
  %t177 = load i1, ptr %l105, !tbaa !21
  store i1 %t177, ptr %l10, !tbaa !21
  %t178 = load ptr, ptr %l0, !tbaa !29
  store ptr %t178, ptr %l106, !tbaa !29
  %t179 = load ptr, ptr %l106, !tbaa !29
  %t180 = getelementptr %"compiler/cond:Eval", ptr %t179, i32 0, i32 7
  %t181 = load %"compiler/source:Span", ptr %t180
  store %"compiler/source:Span" %t181, ptr %l107
  %t182 = load %"compiler/source:Span", ptr %l107
  store %"compiler/source:Span" %t182, ptr %l11
  %t183 = load ptr, ptr %l0, !tbaa !29
  store ptr %t183, ptr %l108, !tbaa !29
  %t184 = load ptr, ptr %l108, !tbaa !29
  %t185 = getelementptr %"compiler/cond:Eval", ptr %t184, i32 0, i32 8
  %t186 = load %"compiler/msgs:Msg", ptr %t185
  store %"compiler/msgs:Msg" %t186, ptr %l109
  %t187 = load %"compiler/msgs:Msg", ptr %l109
  store %"compiler/msgs:Msg" %t187, ptr %l12
  store i1 false, ptr %l13, !tbaa !21
  store i1 false, ptr %l14, !tbaa !21
  store i1 false, ptr %l15, !tbaa !21
  %t188 = load ptr, ptr %l0, !tbaa !29
  store ptr %t188, ptr %l110, !tbaa !29
  %t189 = load i1, ptr %l13, !tbaa !21
  store i1 %t189, ptr %l111, !tbaa !21
  %t190 = load i1, ptr %l111, !tbaa !21
  %t191 = load ptr, ptr %l110, !tbaa !29
  %t192 = getelementptr %"compiler/cond:Eval", ptr %t191, i32 0, i32 4
  store i1 %t190, ptr %t192, !tbaa !21
  %t193 = load ptr, ptr %l0, !tbaa !29
  store ptr %t193, ptr %l112, !tbaa !29
  %t194 = load i1, ptr %l14, !tbaa !21
  store i1 %t194, ptr %l113, !tbaa !21
  %t195 = load i1, ptr %l113, !tbaa !21
  %t196 = load ptr, ptr %l112, !tbaa !29
  %t197 = getelementptr %"compiler/cond:Eval", ptr %t196, i32 0, i32 5
  store i1 %t195, ptr %t197, !tbaa !21
  %t198 = load ptr, ptr %l0, !tbaa !29
  store ptr %t198, ptr %l114, !tbaa !29
  %t199 = load i1, ptr %l15, !tbaa !21
  store i1 %t199, ptr %l115, !tbaa !21
  %t200 = load i1, ptr %l115, !tbaa !21
  %t201 = load ptr, ptr %l114, !tbaa !29
  %t202 = getelementptr %"compiler/cond:Eval", ptr %t201, i32 0, i32 6
  store i1 %t200, ptr %t202, !tbaa !21
  %t203 = load ptr, ptr %l0, !tbaa !29
  store ptr %t203, ptr %l116, !tbaa !29
  %t204 = load ptr, ptr %l116, !tbaa !29
  %t205 = getelementptr %"compiler/cond:Eval", ptr %t204, i32 0, i32 9
  %t206 = load i64, ptr %t205, !tbaa !24
  store i64 %t206, ptr %l117, !tbaa !24
  %t207 = load i64, ptr %l117, !tbaa !24
  %t208 = add i64 %t207, 1
  store i64 %t208, ptr %l118, !tbaa !24
  %t209 = load i64, ptr %l118, !tbaa !24
  %t210 = load ptr, ptr %l116, !tbaa !29
  %t211 = getelementptr %"compiler/cond:Eval", ptr %t210, i32 0, i32 9
  store i64 %t209, ptr %t211, !tbaa !24
  %t212 = load ptr, ptr %l0, !tbaa !29
  store ptr %t212, ptr %l119, !tbaa !29
  %t213 = load ptr, ptr %l2, !tbaa !29
  store ptr %t213, ptr %l120, !tbaa !29
  %t214 = load ptr, ptr %l120, !tbaa !29
  %t215 = getelementptr %"compiler/cond:Global", ptr %t214, i32 0, i32 4
  %t216 = load ptr, ptr %t215, !tbaa !29
  store ptr %t216, ptr %l121, !tbaa !29
  %t217 = load ptr, ptr %l119, !tbaa !29
  %t218 = load ptr, ptr %l121, !tbaa !29
  %t219 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eexpr(ptr %v0, ptr %v1, ptr %t217, ptr %t218)
  store %"compiler/cond:Value" %t219, ptr %l122
  br label %bb42
bb42:
  %t220 = load %"compiler/cond:Value", ptr %l122
  store %"compiler/cond:Value" %t220, ptr %l16
  %t221 = load ptr, ptr %l0, !tbaa !29
  store ptr %t221, ptr %l123, !tbaa !29
  %t222 = load ptr, ptr %l123, !tbaa !29
  %t223 = getelementptr %"compiler/cond:Eval", ptr %t222, i32 0, i32 9
  %t224 = load i64, ptr %t223, !tbaa !24
  store i64 %t224, ptr %l124, !tbaa !24
  %t225 = load i64, ptr %l124, !tbaa !24
  %t226 = sub i64 %t225, 1
  store i64 %t226, ptr %l125, !tbaa !24
  %t227 = load i64, ptr %l125, !tbaa !24
  %t228 = load ptr, ptr %l123, !tbaa !29
  %t229 = getelementptr %"compiler/cond:Eval", ptr %t228, i32 0, i32 9
  store i64 %t227, ptr %t229, !tbaa !24
  %t230 = load ptr, ptr %l0, !tbaa !29
  store ptr %t230, ptr %l126, !tbaa !29
  %t231 = load ptr, ptr %l126, !tbaa !29
  %t232 = getelementptr %"compiler/cond:Eval", ptr %t231, i32 0, i32 4
  %t233 = load i1, ptr %t232, !tbaa !21
  store i1 %t233, ptr %l127, !tbaa !21
  %t234 = load i1, ptr %l127, !tbaa !21
  store i1 %t234, ptr %l17, !tbaa !21
  %t235 = load ptr, ptr %l0, !tbaa !29
  store ptr %t235, ptr %l128, !tbaa !29
  %t236 = load ptr, ptr %l128, !tbaa !29
  %t237 = getelementptr %"compiler/cond:Eval", ptr %t236, i32 0, i32 5
  %t238 = load i1, ptr %t237, !tbaa !21
  store i1 %t238, ptr %l129, !tbaa !21
  %t239 = load i1, ptr %l129, !tbaa !21
  store i1 %t239, ptr %l18, !tbaa !21
  %t240 = load ptr, ptr %l0, !tbaa !29
  store ptr %t240, ptr %l130, !tbaa !29
  %t241 = load ptr, ptr %l130, !tbaa !29
  %t242 = getelementptr %"compiler/cond:Eval", ptr %t241, i32 0, i32 8
  %t243 = load %"compiler/msgs:Msg", ptr %t242
  store %"compiler/msgs:Msg" %t243, ptr %l131
  %t244 = load %"compiler/msgs:Msg", ptr %l131
  store %"compiler/msgs:Msg" %t244, ptr %l19
  %t245 = load i1, ptr %l8, !tbaa !21
  store i1 %t245, ptr %l132, !tbaa !21
  %t246 = load i1, ptr %l132, !tbaa !21
  store i1 %t246, ptr %l20, !tbaa !21
  %t247 = load i1, ptr %l9, !tbaa !21
  store i1 %t247, ptr %l133, !tbaa !21
  %t248 = load i1, ptr %l133, !tbaa !21
  store i1 %t248, ptr %l21, !tbaa !21
  %t249 = load i1, ptr %l10, !tbaa !21
  store i1 %t249, ptr %l134, !tbaa !21
  %t250 = load i1, ptr %l134, !tbaa !21
  store i1 %t250, ptr %l22, !tbaa !21
  %t251 = load %"compiler/source:Span", ptr %l11
  store %"compiler/source:Span" %t251, ptr %l135
  %t252 = load %"compiler/source:Span", ptr %l135
  store %"compiler/source:Span" %t252, ptr %l23
  %t253 = load %"compiler/msgs:Msg", ptr %l12
  store %"compiler/msgs:Msg" %t253, ptr %l136
  %t254 = load %"compiler/msgs:Msg", ptr %l136
  store %"compiler/msgs:Msg" %t254, ptr %l24
  %t255 = load ptr, ptr %l0, !tbaa !29
  store ptr %t255, ptr %l137, !tbaa !29
  %t256 = load i1, ptr %l20, !tbaa !21
  store i1 %t256, ptr %l138, !tbaa !21
  %t257 = load i1, ptr %l138, !tbaa !21
  %t258 = load ptr, ptr %l137, !tbaa !29
  %t259 = getelementptr %"compiler/cond:Eval", ptr %t258, i32 0, i32 4
  store i1 %t257, ptr %t259, !tbaa !21
  %t260 = load ptr, ptr %l0, !tbaa !29
  store ptr %t260, ptr %l139, !tbaa !29
  %t261 = load i1, ptr %l21, !tbaa !21
  store i1 %t261, ptr %l140, !tbaa !21
  %t262 = load i1, ptr %l140, !tbaa !21
  %t263 = load ptr, ptr %l139, !tbaa !29
  %t264 = getelementptr %"compiler/cond:Eval", ptr %t263, i32 0, i32 5
  store i1 %t262, ptr %t264, !tbaa !21
  %t265 = load ptr, ptr %l0, !tbaa !29
  store ptr %t265, ptr %l141, !tbaa !29
  %t266 = load i1, ptr %l22, !tbaa !21
  store i1 %t266, ptr %l142, !tbaa !21
  %t267 = load i1, ptr %l142, !tbaa !21
  %t268 = load ptr, ptr %l141, !tbaa !29
  %t269 = getelementptr %"compiler/cond:Eval", ptr %t268, i32 0, i32 6
  store i1 %t267, ptr %t269, !tbaa !21
  %t270 = load ptr, ptr %l0, !tbaa !29
  store ptr %t270, ptr %l143, !tbaa !29
  %t271 = load %"compiler/source:Span", ptr %l23
  store %"compiler/source:Span" %t271, ptr %l144
  %t272 = load %"compiler/source:Span", ptr %l144
  %t273 = load ptr, ptr %l143, !tbaa !29
  %t274 = getelementptr %"compiler/cond:Eval", ptr %t273, i32 0, i32 7
  store %"compiler/source:Span" %t272, ptr %t274
  %t275 = load ptr, ptr %l0, !tbaa !29
  store ptr %t275, ptr %l145, !tbaa !29
  %t276 = load %"compiler/msgs:Msg", ptr %l24
  store %"compiler/msgs:Msg" %t276, ptr %l146
  %t277 = load %"compiler/msgs:Msg", ptr %l146
  %t278 = load ptr, ptr %l145, !tbaa !29
  %t279 = getelementptr %"compiler/cond:Eval", ptr %t278, i32 0, i32 8
  store %"compiler/msgs:Msg" %t277, ptr %t279
  %t280 = load i1, ptr %l17, !tbaa !21
  store i1 %t280, ptr %l147, !tbaa !21
  %t281 = load i1, ptr %l147, !tbaa !21
  br i1 %t281, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s7
  %t282 = load ptr, ptr %l0, !tbaa !29
  store ptr %t282, ptr %l148, !tbaa !29
  %t283 = load ptr, ptr %l148, !tbaa !29
  %t284 = getelementptr %"compiler/cond:Eval", ptr %t283, i32 0, i32 4
  %t285 = load i1, ptr %t284, !tbaa !21
  store i1 %t285, ptr %l149, !tbaa !21
  %t286 = load i1, ptr %l149, !tbaa !21
  br i1 %t286, label %bb45, label %bb46
bb44:
  br label %bb62
bb45:
  store i1 true, ptr %l150, !tbaa !21
  br label %bb47
bb46:
  %t287 = load ptr, ptr %l0, !tbaa !29
  store ptr %t287, ptr %l151, !tbaa !29
  %t288 = load ptr, ptr %l151, !tbaa !29
  %t289 = getelementptr %"compiler/cond:Eval", ptr %t288, i32 0, i32 10
  %t290 = load i64, ptr %t289, !tbaa !24
  store i64 %t290, ptr %l152, !tbaa !24
  %t291 = load i64, ptr %l152, !tbaa !24
  %t292 = icmp sgt i64 %t291, 0
  store i1 %t292, ptr %l153, !tbaa !21
  %t293 = load i1, ptr %l153, !tbaa !21
  store i1 %t293, ptr %l150, !tbaa !21
  br label %bb47
bb47:
  %t294 = load i1, ptr %l150, !tbaa !21
  br i1 %t294, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s8
  %t295 = call %"compiler/cond:Value" @compiler_2fcond_2enone()
  store %"compiler/cond:Value" %t295, ptr %l154
  br label %bb50
bb49:
  br label %bb51
bb50:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  %t296 = load %"compiler/cond:Value", ptr %l154
  store %"compiler/cond:Value" %t296, ptr %rv
  br label %ret
bb51:
  %t297 = getelementptr %"compiler/msgs:Msg", ptr %l19, i32 0, i32 0
  %t298 = load i32, ptr %t297
  store i32 %t298, ptr %l155
  store ptr %l155, ptr %l156, !tbaa !29
  store i32 77, ptr %l157
  store ptr %l157, ptr %l158, !tbaa !29
  %t299 = load ptr, ptr %l156, !tbaa !29
  %t300 = load ptr, ptr %l158, !tbaa !29
  %t301 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmsgs_3aDiag(ptr %t299, ptr %t300)
  store i1 %t301, ptr %l159
  br label %bb52
bb52:
  %t302 = load i1, ptr %l159, !tbaa !21
  store i1 %t302, ptr %l25, !tbaa !21
  %t303 = load ptr, ptr %l0, !tbaa !29
  store ptr %t303, ptr %l160, !tbaa !29
  %t304 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t304, ptr %l161
  %t305 = load i1, ptr %l25, !tbaa !21
  store i1 %t305, ptr %l162, !tbaa !21
  %t306 = load i1, ptr %l162, !tbaa !21
  br i1 %t306, label %bb53, label %bb54
bb53:
  %t307 = load ptr, ptr %l0, !tbaa !29
  store ptr %t307, ptr %l164, !tbaa !29
  %t308 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t308, ptr %l165
  %t309 = load ptr, ptr %l164, !tbaa !29
  %t310 = load %"compiler/source:Span", ptr %l165
  %t311 = call { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aEval_2etokText(ptr %v0, ptr %v0, ptr %t309, %"compiler/source:Span" %t310)
  store { i64, ptr } %t311, ptr %l166
  br label %bb55
bb54:
  %t312 = load ptr, ptr %l0, !tbaa !29
  store ptr %t312, ptr %l169, !tbaa !29
  %t313 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t313, ptr %l170
  %t314 = load ptr, ptr %l169, !tbaa !29
  %t315 = load %"compiler/source:Span", ptr %l170
  %t316 = call { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aEval_2etokText(ptr %v0, ptr %v0, ptr %t314, %"compiler/source:Span" %t315)
  store { i64, ptr } %t316, ptr %l171
  br label %bb57
bb55:
  %t317 = load { i64, ptr }, ptr %l166, !tbaa !27
  %t318 = extractvalue { i64, ptr } %t317, 0
  %t319 = extractvalue { i64, ptr } %t317, 1
  %t320 = mul i64 %t318, 1
  %t321 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t320)
  call void @llvm.memcpy.p0.p0.i64(ptr %t321, ptr %t319, i64 %t320, i1 false)
  %t322 = insertvalue { i64, ptr } undef, i64 %t318, 0
  %t323 = insertvalue { i64, ptr } %t322, ptr %t321, 1
  store { i64, ptr } %t323, ptr %l167, !tbaa !27
  %t324 = load { i64, ptr }, ptr %l167, !tbaa !27
  %t325 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondCycle(ptr %v0, ptr %v0, { i64, ptr } %t324)
  store %"compiler/msgs:Msg" %t325, ptr %l168
  br label %bb56
bb56:
  %t326 = load %"compiler/msgs:Msg", ptr %l168
  store %"compiler/msgs:Msg" %t326, ptr %l163
  br label %bb59
bb57:
  %t327 = load { i64, ptr }, ptr %l171, !tbaa !27
  %t328 = extractvalue { i64, ptr } %t327, 0
  %t329 = extractvalue { i64, ptr } %t327, 1
  %t330 = mul i64 %t328, 1
  %t331 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t330)
  call void @llvm.memcpy.p0.p0.i64(ptr %t331, ptr %t329, i64 %t330, i1 false)
  %t332 = insertvalue { i64, ptr } undef, i64 %t328, 0
  %t333 = insertvalue { i64, ptr } %t332, ptr %t331, 1
  store { i64, ptr } %t333, ptr %l172, !tbaa !27
  %t334 = load { i64, ptr }, ptr %l172, !tbaa !27
  %t335 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondGlobalInit(ptr %v0, ptr %v0, { i64, ptr } %t334)
  store %"compiler/msgs:Msg" %t335, ptr %l173
  br label %bb58
bb58:
  %t336 = load %"compiler/msgs:Msg", ptr %l173
  store %"compiler/msgs:Msg" %t336, ptr %l163
  br label %bb59
bb59:
  %t337 = load ptr, ptr %l160, !tbaa !29
  %t338 = load %"compiler/source:Span", ptr %l161
  %t339 = load %"compiler/msgs:Msg", ptr %l163
  %t340 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2efail(ptr %v0, ptr %v0, ptr %t337, %"compiler/source:Span" %t338, %"compiler/msgs:Msg" %t339)
  store %"compiler/cond:Value" %t340, ptr %l174
  br label %bb60
bb60:
  %t341 = load ptr, ptr %l0, !tbaa !29
  store ptr %t341, ptr %l175, !tbaa !29
  %t342 = load i1, ptr %l18, !tbaa !21
  store i1 %t342, ptr %l176, !tbaa !21
  %t343 = load i1, ptr %l176, !tbaa !21
  %t344 = load ptr, ptr %l175, !tbaa !29
  %t345 = getelementptr %"compiler/cond:Eval", ptr %t344, i32 0, i32 5
  store i1 %t343, ptr %t345, !tbaa !21
  %t346 = call %"compiler/cond:Value" @compiler_2fcond_2enone()
  store %"compiler/cond:Value" %t346, ptr %l177
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  %t347 = load %"compiler/cond:Value", ptr %l177
  store %"compiler/cond:Value" %t347, ptr %rv
  br label %ret
bb62:
  %t348 = load ptr, ptr %l2, !tbaa !29
  store ptr %t348, ptr %l178, !tbaa !29
  %t349 = load ptr, ptr %l178, !tbaa !29
  %t350 = getelementptr %"compiler/cond:Global", ptr %t349, i32 0, i32 5
  %t351 = load i1, ptr %t350, !tbaa !21
  store i1 %t351, ptr %l179, !tbaa !21
  %t352 = load i1, ptr %l179, !tbaa !21
  %t353 = xor i1 %t352, true
  store i1 %t353, ptr %l180, !tbaa !21
  %t354 = load i1, ptr %l180, !tbaa !21
  br i1 %t354, label %bb63, label %bb64
bb63:
  store %olang.scope zeroinitializer, ptr %s9
  %t355 = load ptr, ptr %l0, !tbaa !29
  store ptr %t355, ptr %l181, !tbaa !29
  %t356 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t356, ptr %l182
  %t357 = load ptr, ptr %l181, !tbaa !29
  %t358 = load %"compiler/source:Span", ptr %l182
  %t359 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t357, %"compiler/source:Span" %t358)
  store %"compiler/cond:Value" %t359, ptr %l183
  br label %bb65
bb64:
  br label %bb66
bb65:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  %t360 = load %"compiler/cond:Value", ptr %l183
  store %"compiler/cond:Value" %t360, ptr %rv
  br label %ret
bb66:
  %t361 = load ptr, ptr %l0, !tbaa !29
  store ptr %t361, ptr %l184, !tbaa !29
  %t362 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t362, ptr %l185
  %t363 = load ptr, ptr %l2, !tbaa !29
  store ptr %t363, ptr %l186, !tbaa !29
  %t364 = load %"compiler/cond:Value", ptr %l16
  store %"compiler/cond:Value" %t364, ptr %l187
  %t365 = load ptr, ptr %l184, !tbaa !29
  %t366 = load %"compiler/source:Span", ptr %l185
  %t367 = load ptr, ptr %l186, !tbaa !29
  %t368 = load %"compiler/cond:Value", ptr %l187
  %t369 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2easDeclared(ptr %v0, ptr %v1, ptr %t365, %"compiler/source:Span" %t366, ptr %t367, %"compiler/cond:Value" %t368)
  store %"compiler/cond:Value" %t369, ptr %l188
  br label %bb67
bb67:
  %t370 = load %"compiler/cond:Value", ptr %l188
  store %"compiler/cond:Value" %t370, ptr %l26
  %t371 = load ptr, ptr %l0, !tbaa !29
  store ptr %t371, ptr %l189, !tbaa !29
  %t372 = load ptr, ptr %l189, !tbaa !29
  %t373 = getelementptr %"compiler/cond:Eval", ptr %t372, i32 0, i32 2
  %t374 = load ptr, ptr %t373, !tbaa !29
  store ptr %t374, ptr %l190, !tbaa !29
  %t375 = load ptr, ptr %l190, !tbaa !29
  %t376 = getelementptr %"compiler/cond:Scope", ptr %t375, i32 0, i32 0
  %t377 = load i1, ptr %t376, !tbaa !21
  store i1 %t377, ptr %l191, !tbaa !21
  %t378 = load i1, ptr %l191, !tbaa !21
  %t379 = xor i1 %t378, true
  store i1 %t379, ptr %l192, !tbaa !21
  %t380 = load i1, ptr %l192, !tbaa !21
  br i1 %t380, label %bb68, label %bb69
bb68:
  %t381 = load ptr, ptr %l2, !tbaa !29
  store ptr %t381, ptr %l194, !tbaa !29
  %t382 = load ptr, ptr %l194, !tbaa !29
  %t383 = getelementptr %"compiler/cond:Global", ptr %t382, i32 0, i32 3
  %t384 = load { i64, ptr }, ptr %t383, !tbaa !27
  store { i64, ptr } %t384, ptr %l195, !tbaa !27
  %t385 = load { i64, ptr }, ptr %l195, !tbaa !27
  %t386 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t385, { i64, ptr } { i64 0, ptr @.d36 })
  store i1 %t386, ptr %l196
  br label %bb70
bb69:
  store i1 false, ptr %l193, !tbaa !21
  br label %bb71
bb70:
  %t387 = load i1, ptr %l196, !tbaa !21
  store i1 %t387, ptr %l193, !tbaa !21
  br label %bb71
bb71:
  %t388 = load i1, ptr %l193, !tbaa !21
  br i1 %t388, label %bb72, label %bb73
bb72:
  %t389 = load %"compiler/cond:Value", ptr %l26
  store %"compiler/cond:Value" %t389, ptr %l198
  %t390 = load %"compiler/cond:Value", ptr %l198
  %t391 = call i1 @compiler_2fcond_2ebuildType(%"compiler/cond:Value" %t390)
  store i1 %t391, ptr %l199
  br label %bb74
bb73:
  store i1 false, ptr %l197, !tbaa !21
  br label %bb75
bb74:
  %t392 = load i1, ptr %l199, !tbaa !21
  store i1 %t392, ptr %l197, !tbaa !21
  br label %bb75
bb75:
  %t393 = load i1, ptr %l197, !tbaa !21
  br i1 %t393, label %bb76, label %bb77
bb76:
  store %olang.scope zeroinitializer, ptr %s10
  %t394 = load ptr, ptr %l0, !tbaa !29
  store ptr %t394, ptr %l200, !tbaa !29
  %t395 = load ptr, ptr %l200, !tbaa !29
  %t396 = getelementptr %"compiler/cond:Eval", ptr %t395, i32 0, i32 10
  %t397 = load i64, ptr %t396, !tbaa !24
  store i64 %t397, ptr %l201, !tbaa !24
  %t398 = load i64, ptr %l201, !tbaa !24
  %t399 = icmp eq i64 %t398, 0
  store i1 %t399, ptr %l202, !tbaa !21
  %t400 = load i1, ptr %l202, !tbaa !21
  br i1 %t400, label %bb78, label %bb79
bb77:
  br label %bb123
bb78:
  store %olang.scope zeroinitializer, ptr %s11
  %t401 = load ptr, ptr %l0, !tbaa !29
  store ptr %t401, ptr %l203, !tbaa !29
  %t402 = load ptr, ptr %l203, !tbaa !29
  %t403 = getelementptr %"compiler/cond:Eval", ptr %t402, i32 0, i32 11
  store i1 true, ptr %t403, !tbaa !21
  call void @__olang_scope_close(ptr %s11)
  br label %bb80
bb79:
  br label %bb80
bb80:
  %t404 = load i1, ptr %l3, !tbaa !21
  store i1 %t404, ptr %l204, !tbaa !21
  %t405 = load i1, ptr %l204, !tbaa !21
  br i1 %t405, label %bb81, label %bb82
bb81:
  store %olang.scope zeroinitializer, ptr %s12
  %t406 = load ptr, ptr %l0, !tbaa !29
  store ptr %t406, ptr %l205, !tbaa !29
  %t407 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t407, ptr %l206
  %t408 = load ptr, ptr %l2, !tbaa !29
  store ptr %t408, ptr %l207, !tbaa !29
  %t409 = load ptr, ptr %l207, !tbaa !29
  %t410 = getelementptr %"compiler/cond:Global", ptr %t409, i32 0, i32 0
  %t411 = load { i64, ptr }, ptr %t410, !tbaa !27
  store { i64, ptr } %t411, ptr %l208, !tbaa !27
  %t412 = load ptr, ptr %l205, !tbaa !29
  %t413 = load %"compiler/source:Span", ptr %l206
  %t414 = load { i64, ptr }, ptr %l208, !tbaa !27
  %t415 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefinedValue(ptr %v0, ptr %v1, ptr %t412, %"compiler/source:Span" %t413, { i64, ptr } %t414)
  store %"compiler/cond:Value" %t415, ptr %l209
  br label %bb83
bb82:
  br label %bb122
bb83:
  %t416 = load %"compiler/cond:Value", ptr %l209
  store %"compiler/cond:Value" %t416, ptr %l27
  %t417 = getelementptr %"compiler/cond:Value", ptr %l27, i32 0, i32 0
  %t418 = load i32, ptr %t417
  store i32 %t418, ptr %l210
  store ptr %l210, ptr %l211, !tbaa !29
  store i32 0, ptr %l212
  store ptr %l212, ptr %l213, !tbaa !29
  %t419 = load ptr, ptr %l211, !tbaa !29
  %t420 = load ptr, ptr %l213, !tbaa !29
  %t421 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %t419, ptr %t420)
  store i1 %t421, ptr %l214
  br label %bb84
bb84:
  %t422 = load i1, ptr %l214, !tbaa !21
  br i1 %t422, label %bb85, label %bb86
bb85:
  store %olang.scope zeroinitializer, ptr %s13
  %t423 = load %"compiler/cond:Value", ptr %l27
  store %"compiler/cond:Value" %t423, ptr %l215
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  %t424 = load %"compiler/cond:Value", ptr %l215
  store %"compiler/cond:Value" %t424, ptr %rv
  br label %ret
bb86:
  br label %bb87
bb87:
  %t425 = getelementptr %"compiler/cond:Value", ptr %l26, i32 0, i32 0
  %t426 = load i32, ptr %t425
  store i32 %t426, ptr %l216
  store ptr %l216, ptr %l217, !tbaa !29
  store i32 3, ptr %l218
  store ptr %l218, ptr %l219, !tbaa !29
  %t427 = load ptr, ptr %l217, !tbaa !29
  %t428 = load ptr, ptr %l219, !tbaa !29
  %t429 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %t427, ptr %t428)
  store i1 %t429, ptr %l220
  br label %bb88
bb88:
  %t430 = load i1, ptr %l220, !tbaa !21
  br i1 %t430, label %bb89, label %bb90
bb89:
  %t431 = getelementptr %"compiler/cond:Value", ptr %l27, i32 0, i32 0
  %t432 = load i32, ptr %t431
  store i32 %t432, ptr %l222
  store ptr %l222, ptr %l223, !tbaa !29
  store i32 2, ptr %l224
  store ptr %l224, ptr %l225, !tbaa !29
  %t433 = load ptr, ptr %l223, !tbaa !29
  %t434 = load ptr, ptr %l225, !tbaa !29
  %t435 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %t433, ptr %t434)
  store i1 %t435, ptr %l226
  br label %bb91
bb90:
  store i1 false, ptr %l221, !tbaa !21
  br label %bb92
bb91:
  %t436 = load i1, ptr %l226, !tbaa !21
  store i1 %t436, ptr %l221, !tbaa !21
  br label %bb92
bb92:
  %t437 = load i1, ptr %l221, !tbaa !21
  br i1 %t437, label %bb93, label %bb94
bb93:
  store %olang.scope zeroinitializer, ptr %s14
  %t438 = getelementptr %"compiler/cond:Value", ptr %l27, i32 0, i32 4
  %t439 = load i64, ptr %t438, !tbaa !24
  store i64 %t439, ptr %l227, !tbaa !24
  %t440 = load i64, ptr %l227, !tbaa !24
  %t441 = icmp eq i64 %t440, 0
  store i1 %t441, ptr %l228, !tbaa !21
  %t442 = load i1, ptr %l228, !tbaa !21
  br i1 %t442, label %bb95, label %bb96
bb94:
  br label %bb106
bb95:
  %t443 = getelementptr %"compiler/cond:Value", ptr %l27, i32 0, i32 1
  %t444 = load i64, ptr %t443, !tbaa !24
  store i64 %t444, ptr %l230, !tbaa !24
  %t445 = load i64, ptr %l230, !tbaa !24
  %t446 = icmp sgt i64 %t445, 9007199254740992
  store i1 %t446, ptr %l231, !tbaa !21
  %t447 = load i1, ptr %l231, !tbaa !21
  br i1 %t447, label %bb97, label %bb98
bb96:
  store i1 false, ptr %l229, !tbaa !21
  br label %bb100
bb97:
  store i1 true, ptr %l232, !tbaa !21
  br label %bb99
bb98:
  %t448 = getelementptr %"compiler/cond:Value", ptr %l27, i32 0, i32 1
  %t449 = load i64, ptr %t448, !tbaa !24
  store i64 %t449, ptr %l233, !tbaa !24
  %t450 = load i64, ptr %l233, !tbaa !24
  %t451 = icmp slt i64 %t450, -9007199254740992
  store i1 %t451, ptr %l234, !tbaa !21
  %t452 = load i1, ptr %l234, !tbaa !21
  store i1 %t452, ptr %l232, !tbaa !21
  br label %bb99
bb99:
  %t453 = load i1, ptr %l232, !tbaa !21
  store i1 %t453, ptr %l229, !tbaa !21
  br label %bb100
bb100:
  %t454 = load i1, ptr %l229, !tbaa !21
  br i1 %t454, label %bb101, label %bb102
bb101:
  store %olang.scope zeroinitializer, ptr %s15
  %t455 = load ptr, ptr %l0, !tbaa !29
  store ptr %t455, ptr %l235, !tbaa !29
  %t456 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t456, ptr %l236
  %t457 = load ptr, ptr %l235, !tbaa !29
  %t458 = load %"compiler/source:Span", ptr %l236
  %t459 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t457, %"compiler/source:Span" %t458)
  store %"compiler/cond:Value" %t459, ptr %l237
  br label %bb103
bb102:
  br label %bb104
bb103:
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  %t460 = load %"compiler/cond:Value", ptr %l237
  store %"compiler/cond:Value" %t460, ptr %rv
  br label %ret
bb104:
  store i32 3, ptr %l238
  %t461 = getelementptr %"compiler/cond:Value", ptr %l27, i32 0, i32 1
  %t462 = load i64, ptr %t461, !tbaa !24
  store i64 %t462, ptr %l239, !tbaa !24
  %t463 = load i64, ptr %l239, !tbaa !24
  %t464 = sitofp i64 %t463 to double
  store double %t464, ptr %l240, !tbaa !26
  %t465 = load i32, ptr %l238
  %t466 = load double, ptr %l240, !tbaa !26
  %t467 = call %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %s14, i32 %t465, i64 0, double %t466, i64 0, i64 0, i1 false)
  store %"compiler/cond:Value" %t467, ptr %l241
  br label %bb105
bb105:
  %t468 = load %"compiler/cond:Value", ptr %l241
  store %"compiler/cond:Value" %t468, ptr %l27
  call void @__olang_scope_close(ptr %s14)
  br label %bb106
bb106:
  %t469 = getelementptr %"compiler/cond:Value", ptr %l27, i32 0, i32 0
  %t470 = load i32, ptr %t469
  store i32 %t470, ptr %l242
  store ptr %l242, ptr %l243, !tbaa !29
  %t471 = getelementptr %"compiler/cond:Value", ptr %l26, i32 0, i32 0
  %t472 = load i32, ptr %t471
  store i32 %t472, ptr %l244
  store ptr %l244, ptr %l245, !tbaa !29
  %t473 = load ptr, ptr %l243, !tbaa !29
  %t474 = load ptr, ptr %l245, !tbaa !29
  %t475 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %t473, ptr %t474)
  store i1 %t475, ptr %l246
  br label %bb107
bb107:
  %t476 = load i1, ptr %l246, !tbaa !21
  %t477 = xor i1 %t476, true
  store i1 %t477, ptr %l247, !tbaa !21
  %t478 = load i1, ptr %l247, !tbaa !21
  br i1 %t478, label %bb108, label %bb109
bb108:
  store %olang.scope zeroinitializer, ptr %s16
  %t479 = load ptr, ptr %l0, !tbaa !29
  store ptr %t479, ptr %l248, !tbaa !29
  %t480 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t480, ptr %l249
  %t481 = load ptr, ptr %l248, !tbaa !29
  %t482 = load %"compiler/source:Span", ptr %l249
  %t483 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t481, %"compiler/source:Span" %t482)
  store %"compiler/cond:Value" %t483, ptr %l250
  br label %bb110
bb109:
  br label %bb111
bb110:
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  %t484 = load %"compiler/cond:Value", ptr %l250
  store %"compiler/cond:Value" %t484, ptr %rv
  br label %ret
bb111:
  %t485 = getelementptr %"compiler/cond:Value", ptr %l27, i32 0, i32 0
  %t486 = load i32, ptr %t485
  store i32 %t486, ptr %l251
  store ptr %l251, ptr %l252, !tbaa !29
  store i32 2, ptr %l253
  store ptr %l253, ptr %l254, !tbaa !29
  %t487 = load ptr, ptr %l252, !tbaa !29
  %t488 = load ptr, ptr %l254, !tbaa !29
  %t489 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %t487, ptr %t488)
  store i1 %t489, ptr %l255
  br label %bb112
bb112:
  %t490 = load i1, ptr %l255, !tbaa !21
  br i1 %t490, label %bb113, label %bb114
bb113:
  %t491 = getelementptr %"compiler/cond:Value", ptr %l27, i32 0, i32 1
  %t492 = load i64, ptr %t491, !tbaa !24
  store i64 %t492, ptr %l257, !tbaa !24
  %t493 = getelementptr %"compiler/cond:Value", ptr %l26, i32 0, i32 4
  %t494 = load i64, ptr %t493, !tbaa !24
  store i64 %t494, ptr %l258, !tbaa !24
  %t495 = getelementptr %"compiler/cond:Value", ptr %l26, i32 0, i32 5
  %t496 = load i1, ptr %t495, !tbaa !21
  store i1 %t496, ptr %l259, !tbaa !21
  %t497 = load i64, ptr %l257, !tbaa !24
  %t498 = load i64, ptr %l258, !tbaa !24
  %t499 = load i1, ptr %l259, !tbaa !21
  %t500 = call i1 @compiler_2fcond_2efits(i64 %t497, i64 %t498, i1 %t499)
  store i1 %t500, ptr %l260
  br label %bb115
bb114:
  store i1 false, ptr %l256, !tbaa !21
  br label %bb116
bb115:
  %t501 = load i1, ptr %l260, !tbaa !21
  %t502 = xor i1 %t501, true
  store i1 %t502, ptr %l261, !tbaa !21
  %t503 = load i1, ptr %l261, !tbaa !21
  store i1 %t503, ptr %l256, !tbaa !21
  br label %bb116
bb116:
  %t504 = load i1, ptr %l256, !tbaa !21
  br i1 %t504, label %bb117, label %bb118
bb117:
  store %olang.scope zeroinitializer, ptr %s17
  %t505 = load ptr, ptr %l0, !tbaa !29
  store ptr %t505, ptr %l262, !tbaa !29
  %t506 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t506, ptr %l263
  %t507 = load ptr, ptr %l262, !tbaa !29
  %t508 = load %"compiler/source:Span", ptr %l263
  %t509 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t507, %"compiler/source:Span" %t508)
  store %"compiler/cond:Value" %t509, ptr %l264
  br label %bb119
bb118:
  br label %bb120
bb119:
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  %t510 = load %"compiler/cond:Value", ptr %l264
  store %"compiler/cond:Value" %t510, ptr %rv
  br label %ret
bb120:
  %t511 = getelementptr %"compiler/cond:Value", ptr %l27, i32 0, i32 0
  %t512 = load i32, ptr %t511
  store i32 %t512, ptr %l265
  %t513 = getelementptr %"compiler/cond:Value", ptr %l27, i32 0, i32 1
  %t514 = load i64, ptr %t513, !tbaa !24
  store i64 %t514, ptr %l266, !tbaa !24
  %t515 = getelementptr %"compiler/cond:Value", ptr %l27, i32 0, i32 2
  %t516 = load double, ptr %t515, !tbaa !26
  store double %t516, ptr %l267, !tbaa !26
  %t517 = getelementptr %"compiler/cond:Value", ptr %l27, i32 0, i32 3
  %t518 = load i64, ptr %t517, !tbaa !24
  store i64 %t518, ptr %l268, !tbaa !24
  %t519 = getelementptr %"compiler/cond:Value", ptr %l26, i32 0, i32 4
  %t520 = load i64, ptr %t519, !tbaa !24
  store i64 %t520, ptr %l269, !tbaa !24
  %t521 = getelementptr %"compiler/cond:Value", ptr %l26, i32 0, i32 5
  %t522 = load i1, ptr %t521, !tbaa !21
  store i1 %t522, ptr %l270, !tbaa !21
  %t523 = load i32, ptr %l265
  %t524 = load i64, ptr %l266, !tbaa !24
  %t525 = load double, ptr %l267, !tbaa !26
  %t526 = load i64, ptr %l268, !tbaa !24
  %t527 = load i64, ptr %l269, !tbaa !24
  %t528 = load i1, ptr %l270, !tbaa !21
  %t529 = call %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %s12, i32 %t523, i64 %t524, double %t525, i64 %t526, i64 %t527, i1 %t528)
  store %"compiler/cond:Value" %t529, ptr %l271
  br label %bb121
bb121:
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  %t530 = load %"compiler/cond:Value", ptr %l271
  store %"compiler/cond:Value" %t530, ptr %rv
  br label %ret
bb122:
  call void @__olang_scope_close(ptr %s10)
  br label %bb123
bb123:
  %t531 = load %"compiler/cond:Value", ptr %l26
  store %"compiler/cond:Value" %t531, ptr %l272
  call void @__olang_scope_close(ptr %s0)
  %t532 = load %"compiler/cond:Value", ptr %l272
  store %"compiler/cond:Value" %t532, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cond:Value", ptr %rv
  ret %"compiler/cond:Value" %rr
}

define dso_local %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eintDeclared(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/cond:Value" %a2, i64 %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/cond:Value"
  %l3 = alloca i64
  %l4 = alloca i1
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca i1
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i1
  %l15 = alloca i1
  %l16 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca %"compiler/source:Span"
  %l19 = alloca %"compiler/cond:Value"
  %l20 = alloca i32
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i1
  %l24 = alloca %"compiler/cond:Value"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca %"compiler/cond:Value"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/cond:Value" %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i1 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/cond:Value", ptr %l2, i32 0, i32 0
  %t2 = load i32, ptr %t1
  store i32 %t2, ptr %l5
  store ptr %l5, ptr %l6, !tbaa !29
  store i32 2, ptr %l7
  store ptr %l7, ptr %l8, !tbaa !29
  %t3 = load ptr, ptr %l6, !tbaa !29
  %t4 = load ptr, ptr %l8, !tbaa !29
  %t5 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %t3, ptr %t4)
  store i1 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i1, ptr %l9, !tbaa !21
  %t7 = xor i1 %t6, true
  store i1 %t7, ptr %l10, !tbaa !21
  %t8 = load i1, ptr %l10, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb5
bb3:
  %t9 = getelementptr %"compiler/cond:Value", ptr %l2, i32 0, i32 1
  %t10 = load i64, ptr %t9, !tbaa !24
  store i64 %t10, ptr %l12, !tbaa !24
  %t11 = load i64, ptr %l3, !tbaa !24
  store i64 %t11, ptr %l13, !tbaa !24
  %t12 = load i1, ptr %l4, !tbaa !21
  store i1 %t12, ptr %l14, !tbaa !21
  %t13 = load i64, ptr %l12, !tbaa !24
  %t14 = load i64, ptr %l13, !tbaa !24
  %t15 = load i1, ptr %l14, !tbaa !21
  %t16 = call i1 @compiler_2fcond_2efits(i64 %t13, i64 %t14, i1 %t15)
  store i1 %t16, ptr %l15
  br label %bb4
bb4:
  %t17 = load i1, ptr %l15, !tbaa !21
  %t18 = xor i1 %t17, true
  store i1 %t18, ptr %l16, !tbaa !21
  %t19 = load i1, ptr %l16, !tbaa !21
  store i1 %t19, ptr %l11, !tbaa !21
  br label %bb5
bb5:
  %t20 = load i1, ptr %l11, !tbaa !21
  br i1 %t20, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l17, !tbaa !29
  %t22 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t22, ptr %l18
  %t23 = load ptr, ptr %l17, !tbaa !29
  %t24 = load %"compiler/source:Span", ptr %l18
  %t25 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t23, %"compiler/source:Span" %t24)
  store %"compiler/cond:Value" %t25, ptr %l19
  br label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t26 = load %"compiler/cond:Value", ptr %l19
  store %"compiler/cond:Value" %t26, ptr %rv
  br label %ret
bb9:
  store i32 2, ptr %l20
  %t27 = getelementptr %"compiler/cond:Value", ptr %l2, i32 0, i32 1
  %t28 = load i64, ptr %t27, !tbaa !24
  store i64 %t28, ptr %l21, !tbaa !24
  %t29 = load i64, ptr %l3, !tbaa !24
  store i64 %t29, ptr %l22, !tbaa !24
  %t30 = load i1, ptr %l4, !tbaa !21
  store i1 %t30, ptr %l23, !tbaa !21
  %t31 = load i32, ptr %l20
  %t32 = load i64, ptr %l21, !tbaa !24
  %t33 = load i64, ptr %l22, !tbaa !24
  %t34 = load i1, ptr %l23, !tbaa !21
  %t35 = call %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %s0, i32 %t31, i64 %t32, double 0x0000000000000000, i64 0, i64 %t33, i1 %t34)
  store %"compiler/cond:Value" %t35, ptr %l24
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t36 = load %"compiler/cond:Value", ptr %l24
  store %"compiler/cond:Value" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cond:Value", ptr %rv
  ret %"compiler/cond:Value" %rr
}

define dso_local i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2eisFixed(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca i1
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i1
  %l23 = alloca i1
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i32
  %l27 = alloca i32
  %l28 = alloca i32
  %l29 = alloca i1
  %l30 = alloca i1
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = getelementptr %"compiler/cond:Eval", ptr %t2, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l9, !tbaa !29
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = getelementptr %"compiler/cond:Scope", ptr %t5, i32 0, i32 3
  store ptr %t6, ptr %l10, !tbaa !29
  %t7 = load ptr, ptr %l10, !tbaa !29
  store ptr %t7, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t8 = load ptr, ptr %l2, !tbaa !29
  store ptr %t8, ptr %l12, !tbaa !29
  %t9 = load i64, ptr %l3, !tbaa !24
  store i64 %t9, ptr %l13, !tbaa !24
  %t10 = load ptr, ptr %l12, !tbaa !29
  %t11 = load i64, ptr %l13, !tbaa !24
  %t12 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2eRun_H660dd195b8dfbe46b01e30313ba3abe1(ptr %v0, ptr %t10, i64 %t11)
  %t13 = extractvalue { i32, { i64, ptr } } %t12, 1
  %t14 = extractvalue { i32, { i64, ptr } } %t12, 0
  store i32 %t14, ptr %l15
  %t15 = icmp ne i32 %t14, 0
  br i1 %t15, label %bb3, label %ok.16
ok.16:
  store { i64, ptr } %t13, ptr %l14
  br label %bb2
bb2:
  %t17 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t17, ptr %l11, !tbaa !27
  br label %bb7
bb3:
  %t18 = load i32, ptr %l15, !tbaa !23
  %t19 = ashr i32 %t18, 16
  store i32 %t19, ptr %l16, !tbaa !23
  %t20 = load i32, ptr %l16, !tbaa !23
  %t21 = icmp eq i32 %t20, 1
  store i1 %t21, ptr %l17, !tbaa !21
  %t22 = load i1, ptr %l17, !tbaa !21
  br i1 %t22, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @.c37)
  unreachable
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb7:
  %t23 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t23, ptr %l4, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t24, ptr %l18, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t25, 0
  store i64 %t26, ptr %l19, !tbaa !24
  %t27 = load i64, ptr %l19, !tbaa !24
  store i64 %t27, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t28 = load i64, ptr %l6, !tbaa !24
  store i64 %t28, ptr %l20, !tbaa !24
  %t29 = load i64, ptr %l5, !tbaa !24
  store i64 %t29, ptr %l21, !tbaa !24
  %t30 = load i64, ptr %l20, !tbaa !24
  %t31 = load i64, ptr %l21, !tbaa !24
  %t32 = icmp slt i64 %t30, %t31
  store i1 %t32, ptr %l22, !tbaa !21
  %t33 = load i1, ptr %l22, !tbaa !21
  %t34 = xor i1 %t33, true
  store i1 %t34, ptr %l23, !tbaa !21
  %t35 = load i1, ptr %l23, !tbaa !21
  br i1 %t35, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb10:
  br label %bb11
bb11:
  %t36 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t36, ptr %l24, !tbaa !27
  %t37 = load i64, ptr %l6, !tbaa !24
  store i64 %t37, ptr %l25, !tbaa !24
  %t38 = load i64, ptr %l25, !tbaa !24
  %t39 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr i32, ptr %t40, i64 %t38
  %t42 = load i32, ptr %t41, !tbaa !33
  store i32 %t42, ptr %l26, !tbaa !23
  %t43 = load i32, ptr %l26, !tbaa !23
  store i32 %t43, ptr %l7, !tbaa !23
  %t44 = load i32, ptr %l7, !tbaa !23
  store i32 %t44, ptr %l27, !tbaa !23
  %t45 = load i32, ptr %l1, !tbaa !23
  store i32 %t45, ptr %l28, !tbaa !23
  %t46 = load i32, ptr %l27, !tbaa !23
  %t47 = load i32, ptr %l28, !tbaa !23
  %t48 = icmp eq i32 %t46, %t47
  store i1 %t48, ptr %l29, !tbaa !21
  %t49 = load i1, ptr %l29, !tbaa !21
  br i1 %t49, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s4
  store i1 true, ptr %l30, !tbaa !21
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t50 = load i1, ptr %l30, !tbaa !21
  store i1 %t50, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s5
  %t51 = load i64, ptr %l6, !tbaa !24
  store i64 %t51, ptr %l31, !tbaa !24
  %t52 = load i64, ptr %l31, !tbaa !24
  %t53 = add i64 %t52, 1
  store i64 %t53, ptr %l32, !tbaa !24
  %t54 = load i64, ptr %l32, !tbaa !24
  store i64 %t54, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb8
bb16:
  %t55 = load i64, ptr %l3, !tbaa !24
  store i64 %t55, ptr %l33, !tbaa !24
  %t56 = load i64, ptr %l5, !tbaa !24
  store i64 %t56, ptr %l34, !tbaa !24
  %t57 = load i64, ptr %l33, !tbaa !24
  %t58 = load i64, ptr %l34, !tbaa !24
  %t59 = add i64 %t57, %t58
  store i64 %t59, ptr %l35, !tbaa !24
  %t60 = load i64, ptr %l35, !tbaa !24
  store i64 %t60, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  br label %bb1
bb18:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %l36, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  %t61 = load i1, ptr %l36, !tbaa !21
  store i1 %t61, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2eisLocal(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca i1
  %l11 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca i32
  %l20 = alloca i32
  %l21 = alloca i1
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i1
  %l27 = alloca i1
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca i32
  %l31 = alloca i32
  %l32 = alloca i32
  %l33 = alloca i1
  %l34 = alloca i1
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  store i32 %t2, ptr %l9, !tbaa !23
  %t3 = load ptr, ptr %l8, !tbaa !29
  %t4 = load i32, ptr %l9, !tbaa !23
  %t5 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2eisFixed(ptr %v0, ptr %t3, i32 %t4)
  store i1 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i1, ptr %l10, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  store i1 false, ptr %l11, !tbaa !21
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t7 = load i1, ptr %l11, !tbaa !21
  store i1 %t7, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l12, !tbaa !29
  %t9 = load ptr, ptr %l12, !tbaa !29
  %t10 = getelementptr %"compiler/cond:Eval", ptr %t9, i32 0, i32 2
  %t11 = load ptr, ptr %t10, !tbaa !29
  store ptr %t11, ptr %l13, !tbaa !29
  %t12 = load ptr, ptr %l13, !tbaa !29
  %t13 = getelementptr %"compiler/cond:Scope", ptr %t12, i32 0, i32 2
  store ptr %t13, ptr %l14, !tbaa !29
  %t14 = load ptr, ptr %l14, !tbaa !29
  store ptr %t14, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t15 = load ptr, ptr %l2, !tbaa !29
  store ptr %t15, ptr %l16, !tbaa !29
  %t16 = load i64, ptr %l3, !tbaa !24
  store i64 %t16, ptr %l17, !tbaa !24
  %t17 = load ptr, ptr %l16, !tbaa !29
  %t18 = load i64, ptr %l17, !tbaa !24
  %t19 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2eRun_H660dd195b8dfbe46b01e30313ba3abe1(ptr %v0, ptr %t17, i64 %t18)
  %t20 = extractvalue { i32, { i64, ptr } } %t19, 1
  %t21 = extractvalue { i32, { i64, ptr } } %t19, 0
  store i32 %t21, ptr %l19
  %t22 = icmp ne i32 %t21, 0
  br i1 %t22, label %bb7, label %ok.23
ok.23:
  store { i64, ptr } %t20, ptr %l18
  br label %bb6
bb6:
  %t24 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t24, ptr %l15, !tbaa !27
  br label %bb11
bb7:
  %t25 = load i32, ptr %l19, !tbaa !23
  %t26 = ashr i32 %t25, 16
  store i32 %t26, ptr %l20, !tbaa !23
  %t27 = load i32, ptr %l20, !tbaa !23
  %t28 = icmp eq i32 %t27, 1
  store i1 %t28, ptr %l21, !tbaa !21
  %t29 = load i1, ptr %l21, !tbaa !21
  br i1 %t29, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @.c38)
  unreachable
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb22
bb11:
  %t30 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t30, ptr %l4, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t31, ptr %l22, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t32, 0
  store i64 %t33, ptr %l23, !tbaa !24
  %t34 = load i64, ptr %l23, !tbaa !24
  store i64 %t34, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s4
  %t35 = load i64, ptr %l6, !tbaa !24
  store i64 %t35, ptr %l24, !tbaa !24
  %t36 = load i64, ptr %l5, !tbaa !24
  store i64 %t36, ptr %l25, !tbaa !24
  %t37 = load i64, ptr %l24, !tbaa !24
  %t38 = load i64, ptr %l25, !tbaa !24
  %t39 = icmp slt i64 %t37, %t38
  store i1 %t39, ptr %l26, !tbaa !21
  %t40 = load i1, ptr %l26, !tbaa !21
  %t41 = xor i1 %t40, true
  store i1 %t41, ptr %l27, !tbaa !21
  %t42 = load i1, ptr %l27, !tbaa !21
  br i1 %t42, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s4)
  br label %bb20
bb14:
  br label %bb15
bb15:
  %t43 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t43, ptr %l28, !tbaa !27
  %t44 = load i64, ptr %l6, !tbaa !24
  store i64 %t44, ptr %l29, !tbaa !24
  %t45 = load i64, ptr %l29, !tbaa !24
  %t46 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr i32, ptr %t47, i64 %t45
  %t49 = load i32, ptr %t48, !tbaa !33
  store i32 %t49, ptr %l30, !tbaa !23
  %t50 = load i32, ptr %l30, !tbaa !23
  store i32 %t50, ptr %l7, !tbaa !23
  %t51 = load i32, ptr %l7, !tbaa !23
  store i32 %t51, ptr %l31, !tbaa !23
  %t52 = load i32, ptr %l1, !tbaa !23
  store i32 %t52, ptr %l32, !tbaa !23
  %t53 = load i32, ptr %l31, !tbaa !23
  %t54 = load i32, ptr %l32, !tbaa !23
  %t55 = icmp eq i32 %t53, %t54
  store i1 %t55, ptr %l33, !tbaa !21
  %t56 = load i1, ptr %l33, !tbaa !21
  br i1 %t56, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s5
  store i1 true, ptr %l34, !tbaa !21
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t57 = load i1, ptr %l34, !tbaa !21
  store i1 %t57, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s4)
  br label %bb19
bb19:
  store %olang.scope zeroinitializer, ptr %s6
  %t58 = load i64, ptr %l6, !tbaa !24
  store i64 %t58, ptr %l35, !tbaa !24
  %t59 = load i64, ptr %l35, !tbaa !24
  %t60 = add i64 %t59, 1
  store i64 %t60, ptr %l36, !tbaa !24
  %t61 = load i64, ptr %l36, !tbaa !24
  store i64 %t61, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb12
bb20:
  %t62 = load i64, ptr %l3, !tbaa !24
  store i64 %t62, ptr %l37, !tbaa !24
  %t63 = load i64, ptr %l5, !tbaa !24
  store i64 %t63, ptr %l38, !tbaa !24
  %t64 = load i64, ptr %l37, !tbaa !24
  %t65 = load i64, ptr %l38, !tbaa !24
  %t66 = add i64 %t64, %t65
  store i64 %t66, ptr %l39, !tbaa !24
  %t67 = load i64, ptr %l39, !tbaa !24
  store i64 %t67, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb21:
  br label %bb5
bb22:
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %l40, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  %t68 = load i1, ptr %l40, !tbaa !21
  store i1 %t68, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eliteral(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i1
  %l6 = alloca double
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca i32
  %l10 = alloca i64
  %l11 = alloca i32
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i1
  %l15 = alloca i1
  %l16 = alloca i1
  %l17 = alloca { i64, ptr }
  %l18 = alloca i32
  %l19 = alloca i1
  %l20 = alloca { i64, ptr }
  %l21 = alloca i1
  %l22 = alloca %"compiler/cond:Value"
  %l23 = alloca i32
  %l24 = alloca i1
  %l25 = alloca i64
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca i32
  %l29 = alloca i64
  %l30 = alloca i32
  %l31 = alloca ptr
  %l32 = alloca %"compiler/source:Span"
  %l33 = alloca %"compiler/cond:Value"
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca i1
  %l37 = alloca i1
  %l38 = alloca { i64, ptr }
  %l39 = alloca i8
  %l40 = alloca i1
  %l41 = alloca i1
  %l42 = alloca { i64, ptr }
  %l43 = alloca i8
  %l44 = alloca i1
  %l45 = alloca i1
  %l46 = alloca { i64, ptr }
  %l47 = alloca i8
  %l48 = alloca i1
  %l49 = alloca i1
  %l50 = alloca i1
  %l51 = alloca i1
  %l52 = alloca i1
  %l53 = alloca i64
  %l54 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca %"compiler/source:Span"
  %l57 = alloca %"compiler/cond:Value"
  %l58 = alloca i32
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca %"compiler/cond:Value"
  %l62 = alloca i32
  %l63 = alloca i1
  %l64 = alloca double
  %l65 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l68 = alloca double
  %l69 = alloca i32
  %l70 = alloca ptr
  %l71 = alloca %"compiler/source:Span"
  %l72 = alloca %"compiler/cond:Value"
  %l73 = alloca double
  %l74 = alloca double
  %l75 = alloca double
  %l76 = alloca i1
  %l77 = alloca ptr
  %l78 = alloca %"compiler/source:Span"
  %l79 = alloca %"compiler/cond:Value"
  %l80 = alloca i32
  %l81 = alloca double
  %l82 = alloca %"compiler/cond:Value"
  %l83 = alloca i32
  %l84 = alloca i1
  %l85 = alloca i32
  %l86 = alloca ptr
  %l87 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l90 = alloca i64
  %l91 = alloca %"compiler/cond:Value"
  %l92 = alloca ptr
  %l93 = alloca %"compiler/source:Span"
  %l94 = alloca %"compiler/cond:Value"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca %"compiler/cond:Value"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = getelementptr %"compiler/cond:Eval", ptr %t2, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l8, !tbaa !27
  %t5 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t6 = load i32, ptr %t5, !tbaa !23
  store i32 %t6, ptr %l9, !tbaa !23
  %t7 = load i32, ptr %l9, !tbaa !23
  %t8 = sext i32 %t7 to i64
  store i64 %t8, ptr %l10, !tbaa !24
  %t9 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t10 = load i32, ptr %t9, !tbaa !23
  store i32 %t10, ptr %l11, !tbaa !23
  %t11 = load i32, ptr %l11, !tbaa !23
  %t12 = sext i32 %t11 to i64
  store i64 %t12, ptr %l12, !tbaa !24
  %t13 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t13, 0
  store i64 %t14, ptr %l13, !tbaa !24
  %t15 = load i64, ptr %l10, !tbaa !24
  %t16 = icmp sge i64 %t15, 0
  store i1 %t16, ptr %l14, !tbaa !21
  %t17 = load i1, ptr %l14, !tbaa !21
  br i1 %t17, label %bb1, label %bb2
bb1:
  %t18 = load i64, ptr %l10, !tbaa !24
  %t19 = load i64, ptr %l12, !tbaa !24
  %t20 = icmp sle i64 %t18, %t19
  store i1 %t20, ptr %l15, !tbaa !21
  %t21 = load i1, ptr %l15, !tbaa !21
  br i1 %t21, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @.c39)
  unreachable
bb3:
  %t22 = load i64, ptr %l12, !tbaa !24
  %t23 = load i64, ptr %l13, !tbaa !24
  %t24 = icmp sle i64 %t22, %t23
  store i1 %t24, ptr %l16, !tbaa !21
  %t25 = load i1, ptr %l16, !tbaa !21
  br i1 %t25, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @.c39)
  unreachable
bb5:
  %t26 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = load i64, ptr %l10, !tbaa !24
  %t29 = load i64, ptr %l12, !tbaa !24
  %t30 = getelementptr i8, ptr %t27, i64 %t28
  %t31 = sub i64 %t29, %t28
  %t32 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t30, 1
  store { i64, ptr } %t33, ptr %l17, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t34, ptr %l3, !tbaa !27
  %t35 = load i32, ptr %l2
  store i32 %t35, ptr %l18
  %t36 = load i32, ptr %l18
  %t37 = trunc i64 6 to i32
  %t38 = icmp eq i32 %t36, %t37
  store i1 %t38, ptr %l19, !tbaa !21
  %t39 = load i1, ptr %l19, !tbaa !21
  br i1 %t39, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @.c39)
  unreachable
bb7:
  br label %bb9
bb8:
  br label %bb12
bb9:
  store %olang.scope zeroinitializer, ptr %s1
  %t40 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t40, ptr %l20, !tbaa !27
  %t41 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t42 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t41, { i64, ptr } { i64 4, ptr @.d40 })
  store i1 %t42, ptr %l21
  br label %bb10
bb10:
  %t43 = load i1, ptr %l21, !tbaa !21
  %t44 = call %"compiler/cond:Value" @compiler_2fcond_2eboolValue(i1 %t43)
  store %"compiler/cond:Value" %t44, ptr %l22
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t45 = load %"compiler/cond:Value", ptr %l22
  store %"compiler/cond:Value" %t45, ptr %rv
  br label %ret
bb12:
  %t46 = load i32, ptr %l2
  store i32 %t46, ptr %l23
  %t47 = load i32, ptr %l23
  %t48 = trunc i64 2 to i32
  %t49 = icmp eq i32 %t47, %t48
  store i1 %t49, ptr %l24, !tbaa !21
  %t50 = load i1, ptr %l24, !tbaa !21
  br i1 %t50, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb41
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  %t51 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t51, ptr %l26, !tbaa !27
  %t52 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s2, i64 0)
  %t53 = extractvalue { i32, i64 } %t52, 1
  %t54 = extractvalue { i32, i64 } %t52, 0
  store i32 %t54, ptr %l28
  %t55 = icmp ne i32 %t54, 0
  br i1 %t55, label %bb17, label %ok.56
ok.56:
  store i64 %t53, ptr %l27
  br label %bb16
bb16:
  %t57 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t58 = load i64, ptr %l27, !tbaa !24
  %t59 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseUint(ptr %v0, { i64, ptr } %t57, i64 %t58)
  %t60 = extractvalue { i32, i64 } %t59, 1
  %t61 = extractvalue { i32, i64 } %t59, 0
  store i32 %t61, ptr %l30
  %t62 = icmp ne i32 %t61, 0
  br i1 %t62, label %bb20, label %ok.63
ok.63:
  store i64 %t60, ptr %l29
  br label %bb19
bb17:
  br label %bb18
bb18:
  store %olang.scope zeroinitializer, ptr %s3
  %t64 = load ptr, ptr %l0, !tbaa !29
  store ptr %t64, ptr %l31, !tbaa !29
  %t65 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t65, ptr %l32
  %t66 = load ptr, ptr %l31, !tbaa !29
  %t67 = load %"compiler/source:Span", ptr %l32
  %t68 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t66, %"compiler/source:Span" %t67)
  store %"compiler/cond:Value" %t68, ptr %l33
  br label %bb21
bb19:
  %t69 = load i64, ptr %l29, !tbaa !65
  store i64 %t69, ptr %l25, !tbaa !65
  br label %bb22
bb20:
  br label %bb18
bb21:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t70 = load %"compiler/cond:Value", ptr %l33
  store %"compiler/cond:Value" %t70, ptr %rv
  br label %ret
bb22:
  %t71 = load i64, ptr %l25, !tbaa !65
  store i64 %t71, ptr %l4, !tbaa !65
  %t72 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t72, ptr %l34, !tbaa !27
  %t73 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t74 = extractvalue { i64, ptr } %t73, 0
  store i64 %t74, ptr %l35, !tbaa !24
  %t75 = load i64, ptr %l35, !tbaa !24
  %t76 = icmp sgt i64 %t75, 2
  store i1 %t76, ptr %l36, !tbaa !21
  %t77 = load i1, ptr %l36, !tbaa !21
  br i1 %t77, label %bb23, label %bb24
bb23:
  %t78 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t78, ptr %l38, !tbaa !27
  %t79 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr i8, ptr %t80, i64 0
  %t82 = load i8, ptr %t81, !tbaa !32
  store i8 %t82, ptr %l39, !tbaa !22
  %t83 = load i8, ptr %l39, !tbaa !22
  %t84 = icmp eq i8 %t83, 48
  store i1 %t84, ptr %l40, !tbaa !21
  %t85 = load i1, ptr %l40, !tbaa !21
  store i1 %t85, ptr %l37, !tbaa !21
  br label %bb25
bb24:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb25
bb25:
  %t86 = load i1, ptr %l37, !tbaa !21
  br i1 %t86, label %bb26, label %bb27
bb26:
  %t87 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t87, ptr %l42, !tbaa !27
  %t88 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !27
  %t90 = getelementptr i8, ptr %t89, i64 1
  %t91 = load i8, ptr %t90, !tbaa !32
  store i8 %t91, ptr %l43, !tbaa !22
  %t92 = load i8, ptr %l43, !tbaa !22
  %t93 = icmp ne i8 %t92, 46
  store i1 %t93, ptr %l44, !tbaa !21
  %t94 = load i1, ptr %l44, !tbaa !21
  store i1 %t94, ptr %l41, !tbaa !21
  br label %bb28
bb27:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb28
bb28:
  %t95 = load i1, ptr %l41, !tbaa !21
  br i1 %t95, label %bb29, label %bb30
bb29:
  %t96 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t96, ptr %l46, !tbaa !27
  %t97 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = getelementptr i8, ptr %t98, i64 1
  %t100 = load i8, ptr %t99, !tbaa !32
  store i8 %t100, ptr %l47, !tbaa !22
  %t101 = load i8, ptr %l47, !tbaa !22
  %t102 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t101)
  store i1 %t102, ptr %l48
  br label %bb31
bb30:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb32
bb31:
  %t103 = load i1, ptr %l48, !tbaa !21
  %t104 = xor i1 %t103, true
  store i1 %t104, ptr %l49, !tbaa !21
  %t105 = load i1, ptr %l49, !tbaa !21
  store i1 %t105, ptr %l45, !tbaa !21
  br label %bb32
bb32:
  %t106 = load i1, ptr %l45, !tbaa !21
  store i1 %t106, ptr %l5, !tbaa !21
  %t107 = load i1, ptr %l5, !tbaa !21
  store i1 %t107, ptr %l50, !tbaa !21
  %t108 = load i1, ptr %l50, !tbaa !21
  %t109 = xor i1 %t108, true
  store i1 %t109, ptr %l51, !tbaa !21
  %t110 = load i1, ptr %l51, !tbaa !21
  br i1 %t110, label %bb33, label %bb34
bb33:
  %t111 = load i64, ptr %l4, !tbaa !65
  store i64 %t111, ptr %l53, !tbaa !65
  %t112 = load i64, ptr %l53, !tbaa !65
  %t113 = icmp ugt i64 %t112, 9223372036854775807
  store i1 %t113, ptr %l54, !tbaa !21
  %t114 = load i1, ptr %l54, !tbaa !21
  store i1 %t114, ptr %l52, !tbaa !21
  br label %bb35
bb34:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb35
bb35:
  %t115 = load i1, ptr %l52, !tbaa !21
  br i1 %t115, label %bb36, label %bb37
bb36:
  store %olang.scope zeroinitializer, ptr %s4
  %t116 = load ptr, ptr %l0, !tbaa !29
  store ptr %t116, ptr %l55, !tbaa !29
  %t117 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t117, ptr %l56
  %t118 = load ptr, ptr %l55, !tbaa !29
  %t119 = load %"compiler/source:Span", ptr %l56
  %t120 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t118, %"compiler/source:Span" %t119)
  store %"compiler/cond:Value" %t120, ptr %l57
  br label %bb38
bb37:
  br label %bb39
bb38:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t121 = load %"compiler/cond:Value", ptr %l57
  store %"compiler/cond:Value" %t121, ptr %rv
  br label %ret
bb39:
  store i32 2, ptr %l58
  %t122 = load i64, ptr %l4, !tbaa !65
  store i64 %t122, ptr %l59, !tbaa !65
  %t123 = load i64, ptr %l59, !tbaa !65
  store i64 %t123, ptr %l60, !tbaa !24
  %t124 = load i32, ptr %l58
  %t125 = load i64, ptr %l60, !tbaa !24
  %t126 = call %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %s2, i32 %t124, i64 %t125, double 0x0000000000000000, i64 0, i64 0, i1 false)
  store %"compiler/cond:Value" %t126, ptr %l61
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t127 = load %"compiler/cond:Value", ptr %l61
  store %"compiler/cond:Value" %t127, ptr %rv
  br label %ret
bb41:
  %t128 = load i32, ptr %l2
  store i32 %t128, ptr %l62
  %t129 = load i32, ptr %l62
  %t130 = trunc i64 3 to i32
  %t131 = icmp eq i32 %t129, %t130
  store i1 %t131, ptr %l63, !tbaa !21
  %t132 = load i1, ptr %l63, !tbaa !21
  br i1 %t132, label %bb42, label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb56
bb44:
  store %olang.scope zeroinitializer, ptr %s5
  %t133 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t133, ptr %l65, !tbaa !27
  %t134 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t135 = call { i64, ptr } @compiler_2fcond_2estripped(ptr %v0, ptr %s5, { i64, ptr } %t134)
  store { i64, ptr } %t135, ptr %l66
  br label %bb45
bb45:
  %t136 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t136, 0
  %t138 = extractvalue { i64, ptr } %t136, 1
  %t139 = mul i64 %t137, 1
  %t140 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t139)
  call void @llvm.memcpy.p0.p0.i64(ptr %t140, ptr %t138, i64 %t139, i1 false)
  %t141 = insertvalue { i64, ptr } undef, i64 %t137, 0
  %t142 = insertvalue { i64, ptr } %t141, ptr %t140, 1
  store { i64, ptr } %t142, ptr %l67, !tbaa !27
  %t143 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t144 = call { i32, double } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseFloat(ptr %s5, { i64, ptr } %t143)
  %t145 = extractvalue { i32, double } %t144, 1
  %t146 = extractvalue { i32, double } %t144, 0
  store i32 %t146, ptr %l69
  %t147 = icmp ne i32 %t146, 0
  br i1 %t147, label %bb47, label %ok.148
ok.148:
  store double %t145, ptr %l68
  br label %bb46
bb46:
  %t149 = load double, ptr %l68, !tbaa !26
  store double %t149, ptr %l64, !tbaa !26
  br label %bb50
bb47:
  br label %bb48
bb48:
  store %olang.scope zeroinitializer, ptr %s6
  %t150 = load ptr, ptr %l0, !tbaa !29
  store ptr %t150, ptr %l70, !tbaa !29
  %t151 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t151, ptr %l71
  %t152 = load ptr, ptr %l70, !tbaa !29
  %t153 = load %"compiler/source:Span", ptr %l71
  %t154 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t152, %"compiler/source:Span" %t153)
  store %"compiler/cond:Value" %t154, ptr %l72
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t155 = load %"compiler/cond:Value", ptr %l72
  store %"compiler/cond:Value" %t155, ptr %rv
  br label %ret
bb50:
  %t156 = load double, ptr %l64, !tbaa !26
  store double %t156, ptr %l6, !tbaa !26
  %t157 = load double, ptr %l6, !tbaa !26
  store double %t157, ptr %l73, !tbaa !26
  %t158 = load double, ptr %l6, !tbaa !26
  store double %t158, ptr %l74, !tbaa !26
  %t159 = load double, ptr %l73, !tbaa !26
  %t160 = load double, ptr %l74, !tbaa !26
  %t161 = fsub double %t159, %t160
  store double %t161, ptr %l75, !tbaa !26
  %t162 = load double, ptr %l75, !tbaa !26
  %t163 = fcmp une double %t162, 0x0000000000000000
  store i1 %t163, ptr %l76, !tbaa !21
  %t164 = load i1, ptr %l76, !tbaa !21
  br i1 %t164, label %bb51, label %bb52
bb51:
  store %olang.scope zeroinitializer, ptr %s7
  %t165 = load ptr, ptr %l0, !tbaa !29
  store ptr %t165, ptr %l77, !tbaa !29
  %t166 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t166, ptr %l78
  %t167 = load ptr, ptr %l77, !tbaa !29
  %t168 = load %"compiler/source:Span", ptr %l78
  %t169 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t167, %"compiler/source:Span" %t168)
  store %"compiler/cond:Value" %t169, ptr %l79
  br label %bb53
bb52:
  br label %bb54
bb53:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t170 = load %"compiler/cond:Value", ptr %l79
  store %"compiler/cond:Value" %t170, ptr %rv
  br label %ret
bb54:
  store i32 3, ptr %l80
  %t171 = load double, ptr %l6, !tbaa !26
  store double %t171, ptr %l81, !tbaa !26
  %t172 = load i32, ptr %l80
  %t173 = load double, ptr %l81, !tbaa !26
  %t174 = call %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %s5, i32 %t172, i64 0, double %t173, i64 0, i64 0, i1 false)
  store %"compiler/cond:Value" %t174, ptr %l82
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t175 = load %"compiler/cond:Value", ptr %l82
  store %"compiler/cond:Value" %t175, ptr %rv
  br label %ret
bb56:
  %t176 = load i32, ptr %l2
  store i32 %t176, ptr %l83
  %t177 = load i32, ptr %l83
  %t178 = trunc i64 5 to i32
  %t179 = icmp eq i32 %t177, %t178
  store i1 %t179, ptr %l84, !tbaa !21
  %t180 = load i1, ptr %l84, !tbaa !21
  br i1 %t180, label %bb57, label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb63
bb59:
  store %olang.scope zeroinitializer, ptr %s8
  store i32 4, ptr %l85
  %t181 = load ptr, ptr %l0, !tbaa !29
  store ptr %t181, ptr %l86, !tbaa !29
  %t182 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t182, ptr %l87, !tbaa !27
  %t183 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t184 = call { i64, ptr } @compiler_2fcond_2edecode(ptr %v0, ptr %s8, { i64, ptr } %t183)
  store { i64, ptr } %t184, ptr %l88
  br label %bb60
bb60:
  %t185 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t186 = extractvalue { i64, ptr } %t185, 0
  %t187 = extractvalue { i64, ptr } %t185, 1
  %t188 = mul i64 %t186, 1
  %t189 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t188)
  call void @llvm.memcpy.p0.p0.i64(ptr %t189, ptr %t187, i64 %t188, i1 false)
  %t190 = insertvalue { i64, ptr } undef, i64 %t186, 0
  %t191 = insertvalue { i64, ptr } %t190, ptr %t189, 1
  store { i64, ptr } %t191, ptr %l89, !tbaa !27
  %t192 = load ptr, ptr %l86, !tbaa !29
  %t193 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t194 = call i64 @compiler_2fcond_2ecompiler_2fcond_3aEval_2eaddText(ptr %v0, ptr %s8, ptr %t192, { i64, ptr } %t193)
  store i64 %t194, ptr %l90
  br label %bb61
bb61:
  %t195 = load i32, ptr %l85
  %t196 = load i64, ptr %l90, !tbaa !24
  %t197 = call %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %s8, i32 %t195, i64 0, double 0x0000000000000000, i64 %t196, i64 0, i1 false)
  store %"compiler/cond:Value" %t197, ptr %l91
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t198 = load %"compiler/cond:Value", ptr %l91
  store %"compiler/cond:Value" %t198, ptr %rv
  br label %ret
bb63:
  store %olang.scope zeroinitializer, ptr %s9
  %t199 = load ptr, ptr %l0, !tbaa !29
  store ptr %t199, ptr %l92, !tbaa !29
  %t200 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t200, ptr %l93
  %t201 = load ptr, ptr %l92, !tbaa !29
  %t202 = load %"compiler/source:Span", ptr %l93
  %t203 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t201, %"compiler/source:Span" %t202)
  store %"compiler/cond:Value" %t203, ptr %l94
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  %t204 = load %"compiler/cond:Value", ptr %l94
  store %"compiler/cond:Value" %t204, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cond:Value", ptr %rv
  ret %"compiler/cond:Value" %rr
}

define dso_local %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2elogic(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca %"compiler/cond:Value"
  %l6 = alloca i1
  %l7 = alloca %"compiler/cond:Value"
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca %"compiler/cond:Value"
  %l11 = alloca ptr
  %l12 = alloca i1
  %l13 = alloca i1
  %l14 = alloca i1
  %l15 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca i32
  %l18 = alloca ptr
  %l19 = alloca i1
  %l20 = alloca i1
  %l21 = alloca i64
  %l22 = alloca i32
  %l23 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca ptr
  %l26 = alloca i1
  %l27 = alloca i64
  %l28 = alloca i1
  %l29 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca ptr
  %l35 = alloca %"compiler/cond:Value"
  %l36 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca %"compiler/cond:Value"
  %l41 = alloca i32
  %l42 = alloca ptr
  %l43 = alloca i32
  %l44 = alloca ptr
  %l45 = alloca i1
  %l46 = alloca i1
  %l47 = alloca i1
  %l48 = alloca i32
  %l49 = alloca ptr
  %l50 = alloca i32
  %l51 = alloca ptr
  %l52 = alloca i1
  %l53 = alloca i1
  %l54 = alloca i1
  %l55 = alloca i32
  %l56 = alloca ptr
  %l57 = alloca i32
  %l58 = alloca ptr
  %l59 = alloca i1
  %l60 = alloca i1
  %l61 = alloca i1
  %l62 = alloca i32
  %l63 = alloca ptr
  %l64 = alloca i32
  %l65 = alloca ptr
  %l66 = alloca i1
  %l67 = alloca i1
  %l68 = alloca ptr
  %l69 = alloca %"compiler/source:Span"
  %l70 = alloca ptr
  %l71 = alloca %"compiler/source:Span"
  %l72 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l74 = alloca %"compiler/msgs:Msg"
  %l75 = alloca %"compiler/cond:Value"
  %l76 = alloca i32
  %l77 = alloca ptr
  %l78 = alloca i32
  %l79 = alloca ptr
  %l80 = alloca i1
  %l81 = alloca i1
  %l82 = alloca i32
  %l83 = alloca ptr
  %l84 = alloca i32
  %l85 = alloca ptr
  %l86 = alloca i1
  %l87 = alloca %"compiler/cond:Value"
  %l88 = alloca i32
  %l89 = alloca ptr
  %l90 = alloca i32
  %l91 = alloca ptr
  %l92 = alloca i1
  %l93 = alloca i64
  %l94 = alloca i1
  %l95 = alloca i1
  %l96 = alloca i64
  %l97 = alloca i1
  %l98 = alloca %"compiler/cond:Value"
  %l99 = alloca i64
  %l100 = alloca i1
  %l101 = alloca i1
  %l102 = alloca i64
  %l103 = alloca i1
  %l104 = alloca %"compiler/cond:Value"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca %"compiler/cond:Value"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  %t2 = load ptr, ptr %l3, !tbaa !29
  store ptr %t2, ptr %l9, !tbaa !29
  %t3 = load ptr, ptr %l8, !tbaa !29
  %t4 = load ptr, ptr %l9, !tbaa !29
  %t5 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eexpr(ptr %v0, ptr %v1, ptr %t3, ptr %t4)
  store %"compiler/cond:Value" %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load %"compiler/cond:Value", ptr %l10
  store %"compiler/cond:Value" %t6, ptr %l5
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l11, !tbaa !29
  %t8 = load ptr, ptr %l11, !tbaa !29
  %t9 = getelementptr %"compiler/cond:Eval", ptr %t8, i32 0, i32 4
  %t10 = load i1, ptr %t9, !tbaa !21
  store i1 %t10, ptr %l12, !tbaa !21
  %t11 = load i1, ptr %l12, !tbaa !21
  %t12 = xor i1 %t11, true
  store i1 %t12, ptr %l13, !tbaa !21
  %t13 = load i1, ptr %l13, !tbaa !21
  br i1 %t13, label %bb2, label %bb3
bb2:
  %t14 = getelementptr %"compiler/cond:Value", ptr %l5, i32 0, i32 0
  %t15 = load i32, ptr %t14
  store i32 %t15, ptr %l15
  store ptr %l15, ptr %l16, !tbaa !29
  store i32 1, ptr %l17
  store ptr %l17, ptr %l18, !tbaa !29
  %t16 = load ptr, ptr %l16, !tbaa !29
  %t17 = load ptr, ptr %l18, !tbaa !29
  %t18 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %t16, ptr %t17)
  store i1 %t18, ptr %l19
  br label %bb4
bb3:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb5
bb4:
  %t19 = load i1, ptr %l19, !tbaa !21
  store i1 %t19, ptr %l14, !tbaa !21
  br label %bb5
bb5:
  %t20 = load i1, ptr %l14, !tbaa !21
  br i1 %t20, label %bb6, label %bb7
bb6:
  %t21 = getelementptr %"compiler/cond:Value", ptr %l5, i32 0, i32 1
  %t22 = load i64, ptr %t21, !tbaa !24
  store i64 %t22, ptr %l21, !tbaa !24
  %t23 = load i32, ptr %l2
  store i32 %t23, ptr %l22
  store ptr %l22, ptr %l23, !tbaa !29
  store i32 48, ptr %l24
  store ptr %l24, ptr %l25, !tbaa !29
  %t24 = load ptr, ptr %l23, !tbaa !29
  %t25 = load ptr, ptr %l25, !tbaa !29
  %t26 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t24, ptr %t25)
  store i1 %t26, ptr %l26
  br label %bb8
bb7:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb12
bb8:
  %t27 = load i1, ptr %l26, !tbaa !21
  br i1 %t27, label %bb9, label %bb10
bb9:
  store i64 1, ptr %l27, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb11
bb11:
  %t28 = load i64, ptr %l21, !tbaa !24
  %t29 = load i64, ptr %l27, !tbaa !24
  %t30 = icmp eq i64 %t28, %t29
  store i1 %t30, ptr %l28, !tbaa !21
  %t31 = load i1, ptr %l28, !tbaa !21
  store i1 %t31, ptr %l20, !tbaa !21
  br label %bb12
bb12:
  %t32 = load i1, ptr %l20, !tbaa !21
  store i1 %t32, ptr %l6, !tbaa !21
  %t33 = load i1, ptr %l6, !tbaa !21
  store i1 %t33, ptr %l29, !tbaa !21
  %t34 = load i1, ptr %l29, !tbaa !21
  br i1 %t34, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s1
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l30, !tbaa !29
  %t36 = load ptr, ptr %l30, !tbaa !29
  %t37 = getelementptr %"compiler/cond:Eval", ptr %t36, i32 0, i32 10
  %t38 = load i64, ptr %t37, !tbaa !24
  store i64 %t38, ptr %l31, !tbaa !24
  %t39 = load i64, ptr %l31, !tbaa !24
  %t40 = add i64 %t39, 1
  store i64 %t40, ptr %l32, !tbaa !24
  %t41 = load i64, ptr %l32, !tbaa !24
  %t42 = load ptr, ptr %l30, !tbaa !29
  %t43 = getelementptr %"compiler/cond:Eval", ptr %t42, i32 0, i32 10
  store i64 %t41, ptr %t43, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb15
bb14:
  br label %bb15
bb15:
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l33, !tbaa !29
  %t45 = load ptr, ptr %l4, !tbaa !29
  store ptr %t45, ptr %l34, !tbaa !29
  %t46 = load ptr, ptr %l33, !tbaa !29
  %t47 = load ptr, ptr %l34, !tbaa !29
  %t48 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eexpr(ptr %v0, ptr %v2, ptr %t46, ptr %t47)
  store %"compiler/cond:Value" %t48, ptr %l35
  br label %bb16
bb16:
  %t49 = load %"compiler/cond:Value", ptr %l35
  store %"compiler/cond:Value" %t49, ptr %l7
  %t50 = load i1, ptr %l6, !tbaa !21
  store i1 %t50, ptr %l36, !tbaa !21
  %t51 = load i1, ptr %l36, !tbaa !21
  br i1 %t51, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s2
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %l37, !tbaa !29
  %t53 = load ptr, ptr %l37, !tbaa !29
  %t54 = getelementptr %"compiler/cond:Eval", ptr %t53, i32 0, i32 10
  %t55 = load i64, ptr %t54, !tbaa !24
  store i64 %t55, ptr %l38, !tbaa !24
  %t56 = load i64, ptr %l38, !tbaa !24
  %t57 = sub i64 %t56, 1
  store i64 %t57, ptr %l39, !tbaa !24
  %t58 = load i64, ptr %l39, !tbaa !24
  %t59 = load ptr, ptr %l37, !tbaa !29
  %t60 = getelementptr %"compiler/cond:Eval", ptr %t59, i32 0, i32 10
  store i64 %t58, ptr %t60, !tbaa !24
  %t61 = load %"compiler/cond:Value", ptr %l5
  store %"compiler/cond:Value" %t61, ptr %l40
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t62 = load %"compiler/cond:Value", ptr %l40
  store %"compiler/cond:Value" %t62, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t63 = getelementptr %"compiler/cond:Value", ptr %l5, i32 0, i32 0
  %t64 = load i32, ptr %t63
  store i32 %t64, ptr %l41
  store ptr %l41, ptr %l42, !tbaa !29
  store i32 0, ptr %l43
  store ptr %l43, ptr %l44, !tbaa !29
  %t65 = load ptr, ptr %l42, !tbaa !29
  %t66 = load ptr, ptr %l44, !tbaa !29
  %t67 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %t65, ptr %t66)
  store i1 %t67, ptr %l45
  br label %bb20
bb20:
  %t68 = load i1, ptr %l45, !tbaa !21
  %t69 = xor i1 %t68, true
  store i1 %t69, ptr %l46, !tbaa !21
  %t70 = load i1, ptr %l46, !tbaa !21
  br i1 %t70, label %bb21, label %bb22
bb21:
  %t71 = getelementptr %"compiler/cond:Value", ptr %l5, i32 0, i32 0
  %t72 = load i32, ptr %t71
  store i32 %t72, ptr %l48
  store ptr %l48, ptr %l49, !tbaa !29
  store i32 1, ptr %l50
  store ptr %l50, ptr %l51, !tbaa !29
  %t73 = load ptr, ptr %l49, !tbaa !29
  %t74 = load ptr, ptr %l51, !tbaa !29
  %t75 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %t73, ptr %t74)
  store i1 %t75, ptr %l52
  br label %bb23
bb22:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb24
bb23:
  %t76 = load i1, ptr %l52, !tbaa !21
  %t77 = xor i1 %t76, true
  store i1 %t77, ptr %l53, !tbaa !21
  %t78 = load i1, ptr %l53, !tbaa !21
  store i1 %t78, ptr %l47, !tbaa !21
  br label %bb24
bb24:
  %t79 = load i1, ptr %l47, !tbaa !21
  br i1 %t79, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l54, !tbaa !21
  br label %bb32
bb26:
  %t80 = getelementptr %"compiler/cond:Value", ptr %l7, i32 0, i32 0
  %t81 = load i32, ptr %t80
  store i32 %t81, ptr %l55
  store ptr %l55, ptr %l56, !tbaa !29
  store i32 0, ptr %l57
  store ptr %l57, ptr %l58, !tbaa !29
  %t82 = load ptr, ptr %l56, !tbaa !29
  %t83 = load ptr, ptr %l58, !tbaa !29
  %t84 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %t82, ptr %t83)
  store i1 %t84, ptr %l59
  br label %bb27
bb27:
  %t85 = load i1, ptr %l59, !tbaa !21
  %t86 = xor i1 %t85, true
  store i1 %t86, ptr %l60, !tbaa !21
  %t87 = load i1, ptr %l60, !tbaa !21
  br i1 %t87, label %bb28, label %bb29
bb28:
  %t88 = getelementptr %"compiler/cond:Value", ptr %l7, i32 0, i32 0
  %t89 = load i32, ptr %t88
  store i32 %t89, ptr %l62
  store ptr %l62, ptr %l63, !tbaa !29
  store i32 1, ptr %l64
  store ptr %l64, ptr %l65, !tbaa !29
  %t90 = load ptr, ptr %l63, !tbaa !29
  %t91 = load ptr, ptr %l65, !tbaa !29
  %t92 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %t90, ptr %t91)
  store i1 %t92, ptr %l66
  br label %bb30
bb29:
  store i1 false, ptr %l61, !tbaa !21
  br label %bb31
bb30:
  %t93 = load i1, ptr %l66, !tbaa !21
  %t94 = xor i1 %t93, true
  store i1 %t94, ptr %l67, !tbaa !21
  %t95 = load i1, ptr %l67, !tbaa !21
  store i1 %t95, ptr %l61, !tbaa !21
  br label %bb31
bb31:
  %t96 = load i1, ptr %l61, !tbaa !21
  store i1 %t96, ptr %l54, !tbaa !21
  br label %bb32
bb32:
  %t97 = load i1, ptr %l54, !tbaa !21
  br i1 %t97, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s3
  %t98 = load ptr, ptr %l0, !tbaa !29
  store ptr %t98, ptr %l68, !tbaa !29
  %t99 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t99, ptr %l69
  %t100 = load ptr, ptr %l0, !tbaa !29
  store ptr %t100, ptr %l70, !tbaa !29
  %t101 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t101, ptr %l71
  %t102 = load ptr, ptr %l70, !tbaa !29
  %t103 = load %"compiler/source:Span", ptr %l71
  %t104 = call { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aEval_2etokText(ptr %v0, ptr %v0, ptr %t102, %"compiler/source:Span" %t103)
  store { i64, ptr } %t104, ptr %l72
  br label %bb35
bb34:
  br label %bb38
bb35:
  %t105 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t105, 0
  %t107 = extractvalue { i64, ptr } %t105, 1
  %t108 = mul i64 %t106, 1
  %t109 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t108)
  call void @llvm.memcpy.p0.p0.i64(ptr %t109, ptr %t107, i64 %t108, i1 false)
  %t110 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t109, 1
  store { i64, ptr } %t111, ptr %l73, !tbaa !27
  %t112 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t113 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondTypes(ptr %v0, ptr %v0, { i64, ptr } %t112)
  store %"compiler/msgs:Msg" %t113, ptr %l74
  br label %bb36
bb36:
  %t114 = load ptr, ptr %l68, !tbaa !29
  %t115 = load %"compiler/source:Span", ptr %l69
  %t116 = load %"compiler/msgs:Msg", ptr %l74
  %t117 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2efail(ptr %v0, ptr %v0, ptr %t114, %"compiler/source:Span" %t115, %"compiler/msgs:Msg" %t116)
  store %"compiler/cond:Value" %t117, ptr %l75
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t118 = load %"compiler/cond:Value", ptr %l75
  store %"compiler/cond:Value" %t118, ptr %rv
  br label %ret
bb38:
  %t119 = getelementptr %"compiler/cond:Value", ptr %l5, i32 0, i32 0
  %t120 = load i32, ptr %t119
  store i32 %t120, ptr %l76
  store ptr %l76, ptr %l77, !tbaa !29
  store i32 0, ptr %l78
  store ptr %l78, ptr %l79, !tbaa !29
  %t121 = load ptr, ptr %l77, !tbaa !29
  %t122 = load ptr, ptr %l79, !tbaa !29
  %t123 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %t121, ptr %t122)
  store i1 %t123, ptr %l80
  br label %bb39
bb39:
  %t124 = load i1, ptr %l80, !tbaa !21
  br i1 %t124, label %bb40, label %bb41
bb40:
  store i1 true, ptr %l81, !tbaa !21
  br label %bb43
bb41:
  %t125 = getelementptr %"compiler/cond:Value", ptr %l7, i32 0, i32 0
  %t126 = load i32, ptr %t125
  store i32 %t126, ptr %l82
  store ptr %l82, ptr %l83, !tbaa !29
  store i32 0, ptr %l84
  store ptr %l84, ptr %l85, !tbaa !29
  %t127 = load ptr, ptr %l83, !tbaa !29
  %t128 = load ptr, ptr %l85, !tbaa !29
  %t129 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %t127, ptr %t128)
  store i1 %t129, ptr %l86
  br label %bb42
bb42:
  %t130 = load i1, ptr %l86, !tbaa !21
  store i1 %t130, ptr %l81, !tbaa !21
  br label %bb43
bb43:
  %t131 = load i1, ptr %l81, !tbaa !21
  br i1 %t131, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s4
  %t132 = call %"compiler/cond:Value" @compiler_2fcond_2enone()
  store %"compiler/cond:Value" %t132, ptr %l87
  br label %bb46
bb45:
  br label %bb47
bb46:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t133 = load %"compiler/cond:Value", ptr %l87
  store %"compiler/cond:Value" %t133, ptr %rv
  br label %ret
bb47:
  %t134 = load i32, ptr %l2
  store i32 %t134, ptr %l88
  store ptr %l88, ptr %l89, !tbaa !29
  store i32 48, ptr %l90
  store ptr %l90, ptr %l91, !tbaa !29
  %t135 = load ptr, ptr %l89, !tbaa !29
  %t136 = load ptr, ptr %l91, !tbaa !29
  %t137 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t135, ptr %t136)
  store i1 %t137, ptr %l92
  br label %bb48
bb48:
  %t138 = load i1, ptr %l92, !tbaa !21
  br i1 %t138, label %bb49, label %bb50
bb49:
  store %olang.scope zeroinitializer, ptr %s5
  %t139 = getelementptr %"compiler/cond:Value", ptr %l5, i32 0, i32 1
  %t140 = load i64, ptr %t139, !tbaa !24
  store i64 %t140, ptr %l93, !tbaa !24
  %t141 = load i64, ptr %l93, !tbaa !24
  %t142 = icmp ne i64 %t141, 0
  store i1 %t142, ptr %l94, !tbaa !21
  %t143 = load i1, ptr %l94, !tbaa !21
  br i1 %t143, label %bb51, label %bb52
bb50:
  br label %bb55
bb51:
  store i1 true, ptr %l95, !tbaa !21
  br label %bb53
bb52:
  %t144 = getelementptr %"compiler/cond:Value", ptr %l7, i32 0, i32 1
  %t145 = load i64, ptr %t144, !tbaa !24
  store i64 %t145, ptr %l96, !tbaa !24
  %t146 = load i64, ptr %l96, !tbaa !24
  %t147 = icmp ne i64 %t146, 0
  store i1 %t147, ptr %l97, !tbaa !21
  %t148 = load i1, ptr %l97, !tbaa !21
  store i1 %t148, ptr %l95, !tbaa !21
  br label %bb53
bb53:
  %t149 = load i1, ptr %l95, !tbaa !21
  %t150 = call %"compiler/cond:Value" @compiler_2fcond_2eboolValue(i1 %t149)
  store %"compiler/cond:Value" %t150, ptr %l98
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t151 = load %"compiler/cond:Value", ptr %l98
  store %"compiler/cond:Value" %t151, ptr %rv
  br label %ret
bb55:
  %t152 = getelementptr %"compiler/cond:Value", ptr %l5, i32 0, i32 1
  %t153 = load i64, ptr %t152, !tbaa !24
  store i64 %t153, ptr %l99, !tbaa !24
  %t154 = load i64, ptr %l99, !tbaa !24
  %t155 = icmp ne i64 %t154, 0
  store i1 %t155, ptr %l100, !tbaa !21
  %t156 = load i1, ptr %l100, !tbaa !21
  br i1 %t156, label %bb56, label %bb57
bb56:
  %t157 = getelementptr %"compiler/cond:Value", ptr %l7, i32 0, i32 1
  %t158 = load i64, ptr %t157, !tbaa !24
  store i64 %t158, ptr %l102, !tbaa !24
  %t159 = load i64, ptr %l102, !tbaa !24
  %t160 = icmp ne i64 %t159, 0
  store i1 %t160, ptr %l103, !tbaa !21
  %t161 = load i1, ptr %l103, !tbaa !21
  store i1 %t161, ptr %l101, !tbaa !21
  br label %bb58
bb57:
  store i1 false, ptr %l101, !tbaa !21
  br label %bb58
bb58:
  %t162 = load i1, ptr %l101, !tbaa !21
  %t163 = call %"compiler/cond:Value" @compiler_2fcond_2eboolValue(i1 %t162)
  store %"compiler/cond:Value" %t163, ptr %l104
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s0)
  %t164 = load %"compiler/cond:Value", ptr %l104
  store %"compiler/cond:Value" %t164, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cond:Value", ptr %rv
  ret %"compiler/cond:Value" %rr
}

define dso_local i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2ementionsLocal(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l23 = alloca ptr
  %l24 = alloca i1
  %l25 = alloca i1
  %l26 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i1
  %l29 = alloca i1
  %l30 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca i32
  %l33 = alloca ptr
  %l34 = alloca i32
  %l35 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca i1
  %l38 = alloca i1
  %l39 = alloca i64
  %l40 = alloca ptr
  %l41 = alloca ptr
  %l42 = alloca ptr
  %l43 = alloca i1
  %l44 = alloca i1
  %l45 = alloca i64
  %l46 = alloca ptr
  %l47 = alloca ptr
  %l48 = alloca ptr
  %l49 = alloca i1
  %l50 = alloca i1
  %l51 = alloca i64
  %l52 = alloca ptr
  %l53 = alloca ptr
  %l54 = alloca ptr
  %l55 = alloca ptr
  %l56 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca i1
  %l59 = alloca i1
  %l60 = alloca i64
  %l61 = alloca ptr
  %l62 = alloca ptr
  %l63 = alloca ptr
  %l64 = alloca ptr
  %l65 = alloca ptr
  %l66 = alloca ptr
  %l67 = alloca i1
  %l68 = alloca i1
  %l69 = alloca ptr
  %l70 = alloca ptr
  %l71 = alloca i1
  %l72 = alloca ptr
  %l73 = alloca i1
  %l74 = alloca i1
  %l75 = alloca i64
  %l76 = alloca ptr
  %l77 = alloca ptr
  %l78 = alloca ptr
  %l79 = alloca { i64, ptr }
  %l80 = alloca ptr
  %l81 = alloca ptr
  %l82 = alloca i1
  %l83 = alloca i1
  %l84 = alloca ptr
  %l85 = alloca { i64, ptr }
  %l86 = alloca i1
  %l87 = alloca ptr
  %l88 = alloca i1
  %l89 = alloca i1
  %l90 = alloca i64
  %l91 = alloca ptr
  %l92 = alloca ptr
  %l93 = alloca ptr
  %l94 = alloca { i64, ptr }
  %l95 = alloca ptr
  %l96 = alloca ptr
  %l97 = alloca i1
  %l98 = alloca i1
  %l99 = alloca ptr
  %l100 = alloca { i64, ptr }
  %l101 = alloca i1
  %l102 = alloca ptr
  %l103 = alloca i1
  %l104 = alloca i1
  %l105 = alloca i64
  %l106 = alloca ptr
  %l107 = alloca ptr
  %l108 = alloca ptr
  %l109 = alloca ptr
  %l110 = alloca { i64, ptr }
  %l111 = alloca i1
  %l112 = alloca ptr
  %l113 = alloca i1
  %l114 = alloca i1
  %l115 = alloca i64
  %l116 = alloca ptr
  %l117 = alloca ptr
  %l118 = alloca ptr
  %l119 = alloca ptr
  %l120 = alloca ptr
  %l121 = alloca ptr
  %l122 = alloca ptr
  %l123 = alloca ptr
  %l124 = alloca i1
  %l125 = alloca i1
  %l126 = alloca ptr
  %l127 = alloca ptr
  %l128 = alloca i1
  %l129 = alloca i1
  %l130 = alloca ptr
  %l131 = alloca ptr
  %l132 = alloca i1
  %l133 = alloca ptr
  %l134 = alloca i1
  %l135 = alloca i1
  %l136 = alloca i64
  %l137 = alloca ptr
  %l138 = alloca ptr
  %l139 = alloca ptr
  %l140 = alloca i1
  %l141 = alloca i1
  %l142 = alloca i64
  %l143 = alloca ptr
  %l144 = alloca ptr
  %l145 = alloca ptr
  %l146 = alloca i1
  %l147 = alloca i1
  %l148 = alloca i64
  %l149 = alloca ptr
  %l150 = alloca ptr
  %l151 = alloca ptr
  %l152 = alloca i1
  %l153 = alloca i1
  %l154 = alloca i64
  %l155 = alloca ptr
  %l156 = alloca ptr
  %l157 = alloca ptr
  %l158 = alloca i1
  %l159 = alloca i1
  %l160 = alloca i64
  %l161 = alloca ptr
  %l162 = alloca ptr
  %l163 = alloca ptr
  %l164 = alloca ptr
  %l165 = alloca i1
  %l166 = alloca ptr
  %l167 = alloca i1
  %l168 = alloca i1
  %l169 = alloca i64
  %l170 = alloca ptr
  %l171 = alloca ptr
  %l172 = alloca ptr
  %l173 = alloca ptr
  %l174 = alloca ptr
  %l175 = alloca i1
  %l176 = alloca i1
  %l177 = alloca i64
  %l178 = alloca ptr
  %l179 = alloca ptr
  %l180 = alloca ptr
  %l181 = alloca ptr
  %l182 = alloca ptr
  %l183 = alloca ptr
  %l184 = alloca i1
  %l185 = alloca i1
  %l186 = alloca ptr
  %l187 = alloca ptr
  %l188 = alloca i1
  %l189 = alloca ptr
  %l190 = alloca i1
  %l191 = alloca i1
  %l192 = alloca i64
  %l193 = alloca ptr
  %l194 = alloca ptr
  %l195 = alloca ptr
  %l196 = alloca { i64, ptr }
  %l197 = alloca ptr
  %l198 = alloca ptr
  %l199 = alloca i1
  %l200 = alloca i1
  %l201 = alloca ptr
  %l202 = alloca { i64, ptr }
  %l203 = alloca i1
  %l204 = alloca ptr
  %l205 = alloca i1
  %l206 = alloca i1
  %l207 = alloca i64
  %l208 = alloca ptr
  %l209 = alloca ptr
  %l210 = alloca ptr
  %l211 = alloca ptr
  %l212 = alloca ptr
  %l213 = alloca ptr
  %l214 = alloca ptr
  %l215 = alloca ptr
  %l216 = alloca i1
  %l217 = alloca i1
  %l218 = alloca ptr
  %l219 = alloca ptr
  %l220 = alloca i1
  %l221 = alloca i1
  %l222 = alloca ptr
  %l223 = alloca ptr
  %l224 = alloca i1
  %l225 = alloca ptr
  %l226 = alloca i1
  %l227 = alloca i1
  %l228 = alloca i64
  %l229 = alloca ptr
  %l230 = alloca { i64, ptr }
  %l231 = alloca ptr
  %l232 = alloca i1
  %l233 = alloca i1
  %l234 = alloca i64
  %l235 = alloca ptr
  %l236 = alloca { i64, ptr }
  %l237 = alloca ptr
  %l238 = alloca i1
  %l239 = alloca i1
  %l240 = alloca i64
  %l241 = alloca ptr
  %l242 = alloca { i64, ptr }
  %l243 = alloca ptr
  %l244 = alloca { i64, ptr }
  %l245 = alloca i1
  %l246 = alloca ptr
  %l247 = alloca i1
  %l248 = alloca i1
  %l249 = alloca i64
  %l250 = alloca ptr
  %l251 = alloca i1
  %l252 = alloca i1
  %l253 = alloca i64
  %l254 = alloca ptr
  %l255 = alloca i1
  %l256 = alloca i1
  %l257 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l23, !tbaa !29
  %t2 = load ptr, ptr %l23, !tbaa !29
  %t3 = icmp eq ptr %t2, null
  store i1 %t3, ptr %l24, !tbaa !21
  %t4 = load i1, ptr %l24, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  store i1 false, ptr %l25, !tbaa !21
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t5 = load i1, ptr %l25, !tbaa !21
  store i1 %t5, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t7 = load ptr, ptr %l27, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  store i1 %t8, ptr %l29, !tbaa !21
  %t9 = load i1, ptr %l29, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l27, !tbaa !29
  %t11 = load i64, ptr %t10
  store i64 %t11, ptr %l30, !tbaa !24
  %t12 = load i64, ptr %l30, !tbaa !24
  %t13 = icmp eq i64 %t12, 0
  store i1 %t13, ptr %l28, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l28, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l1, !tbaa !29
  store ptr %t15, ptr %l31, !tbaa !29
  %t16 = load ptr, ptr %l31, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32 }, ptr %t17, i32 0, i32 1
  %t19 = load i32, ptr %t18
  store i32 %t19, ptr %l32, !tbaa !23
  %t20 = load i32, ptr %l32, !tbaa !23
  store i32 %t20, ptr %l2, !tbaa !23
  br label %bb8
bb7:
  br label %bb10
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l33, !tbaa !29
  %t22 = load i32, ptr %l2, !tbaa !23
  store i32 %t22, ptr %l34, !tbaa !23
  %t23 = load ptr, ptr %l33, !tbaa !29
  %t24 = load i32, ptr %l34, !tbaa !23
  %t25 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2eisLocal(ptr %v0, ptr %t23, i32 %t24)
  store i1 %t25, ptr %l35
  br label %bb9
bb9:
  %t26 = load i1, ptr %l35, !tbaa !21
  store i1 %t26, ptr %l26, !tbaa !21
  call void @__olang_scope_close(ptr %s2)
  br label %bb178
bb10:
  %t27 = load ptr, ptr %l1, !tbaa !29
  store ptr %t27, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t28 = load ptr, ptr %l36, !tbaa !29
  %t29 = icmp ne ptr %t28, null
  store i1 %t29, ptr %l38, !tbaa !21
  %t30 = load i1, ptr %l38, !tbaa !21
  br i1 %t30, label %bb11, label %bb12
bb11:
  %t31 = load ptr, ptr %l36, !tbaa !29
  %t32 = load i64, ptr %t31
  store i64 %t32, ptr %l39, !tbaa !24
  %t33 = load i64, ptr %l39, !tbaa !24
  %t34 = icmp eq i64 %t33, 2
  store i1 %t34, ptr %l37, !tbaa !21
  br label %bb12
bb12:
  %t35 = load i1, ptr %l37, !tbaa !21
  br i1 %t35, label %bb13, label %bb14
bb13:
  %t36 = load ptr, ptr %l1, !tbaa !29
  store ptr %t36, ptr %l40, !tbaa !29
  %t37 = load ptr, ptr %l40, !tbaa !29
  %t38 = getelementptr { i64, [5 x i64] }, ptr %t37, i32 0, i32 1
  %t39 = getelementptr { %"compiler/source:Span", ptr }, ptr %t38, i32 0, i32 1
  %t40 = load ptr, ptr %t39
  store ptr %t40, ptr %l41, !tbaa !29
  %t41 = load ptr, ptr %l41, !tbaa !29
  store ptr %t41, ptr %l3, !tbaa !29
  br label %bb23
bb14:
  %t42 = load ptr, ptr %l1, !tbaa !29
  store ptr %t42, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t43 = load ptr, ptr %l42, !tbaa !29
  %t44 = icmp ne ptr %t43, null
  store i1 %t44, ptr %l44, !tbaa !21
  %t45 = load i1, ptr %l44, !tbaa !21
  br i1 %t45, label %bb15, label %bb16
bb15:
  %t46 = load ptr, ptr %l42, !tbaa !29
  %t47 = load i64, ptr %t46
  store i64 %t47, ptr %l45, !tbaa !24
  %t48 = load i64, ptr %l45, !tbaa !24
  %t49 = icmp eq i64 %t48, 3
  store i1 %t49, ptr %l43, !tbaa !21
  br label %bb16
bb16:
  %t50 = load i1, ptr %l43, !tbaa !21
  br i1 %t50, label %bb17, label %bb18
bb17:
  %t51 = load ptr, ptr %l1, !tbaa !29
  store ptr %t51, ptr %l46, !tbaa !29
  %t52 = load ptr, ptr %l46, !tbaa !29
  %t53 = getelementptr { i64, [5 x i64] }, ptr %t52, i32 0, i32 1
  %t54 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t53, i32 0, i32 2
  %t55 = load ptr, ptr %t54
  store ptr %t55, ptr %l47, !tbaa !29
  %t56 = load ptr, ptr %l47, !tbaa !29
  store ptr %t56, ptr %l3, !tbaa !29
  br label %bb23
bb18:
  %t57 = load ptr, ptr %l1, !tbaa !29
  store ptr %t57, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t58 = load ptr, ptr %l48, !tbaa !29
  %t59 = icmp ne ptr %t58, null
  store i1 %t59, ptr %l50, !tbaa !21
  %t60 = load i1, ptr %l50, !tbaa !21
  br i1 %t60, label %bb19, label %bb20
bb19:
  %t61 = load ptr, ptr %l48, !tbaa !29
  %t62 = load i64, ptr %t61
  store i64 %t62, ptr %l51, !tbaa !24
  %t63 = load i64, ptr %l51, !tbaa !24
  %t64 = icmp eq i64 %t63, 15
  store i1 %t64, ptr %l49, !tbaa !21
  br label %bb20
bb20:
  %t65 = load i1, ptr %l49, !tbaa !21
  br i1 %t65, label %bb21, label %bb22
bb21:
  %t66 = load ptr, ptr %l1, !tbaa !29
  store ptr %t66, ptr %l52, !tbaa !29
  %t67 = load ptr, ptr %l52, !tbaa !29
  %t68 = getelementptr { i64, [5 x i64] }, ptr %t67, i32 0, i32 1
  %t69 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t68, i32 0, i32 1
  %t70 = load ptr, ptr %t69
  store ptr %t70, ptr %l53, !tbaa !29
  %t71 = load ptr, ptr %l53, !tbaa !29
  store ptr %t71, ptr %l3, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  store %olang.scope zeroinitializer, ptr %s3
  %t72 = load ptr, ptr %l0, !tbaa !29
  store ptr %t72, ptr %l54, !tbaa !29
  %t73 = load ptr, ptr %l3, !tbaa !29
  store ptr %t73, ptr %l55, !tbaa !29
  %t74 = load ptr, ptr %l54, !tbaa !29
  %t75 = load ptr, ptr %l55, !tbaa !29
  %t76 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2ementionsLocal(ptr %v0, ptr %v1, ptr %t74, ptr %t75)
  store i1 %t76, ptr %l56
  br label %bb24
bb24:
  %t77 = load i1, ptr %l56, !tbaa !21
  store i1 %t77, ptr %l26, !tbaa !21
  call void @__olang_scope_close(ptr %s3)
  br label %bb178
bb25:
  %t78 = load ptr, ptr %l1, !tbaa !29
  store ptr %t78, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t79 = load ptr, ptr %l57, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  store i1 %t80, ptr %l59, !tbaa !21
  %t81 = load i1, ptr %l59, !tbaa !21
  br i1 %t81, label %bb26, label %bb27
bb26:
  %t82 = load ptr, ptr %l57, !tbaa !29
  %t83 = load i64, ptr %t82
  store i64 %t83, ptr %l60, !tbaa !24
  %t84 = load i64, ptr %l60, !tbaa !24
  %t85 = icmp eq i64 %t84, 5
  store i1 %t85, ptr %l58, !tbaa !21
  br label %bb27
bb27:
  %t86 = load i1, ptr %l58, !tbaa !21
  br i1 %t86, label %bb28, label %bb29
bb28:
  %t87 = load ptr, ptr %l1, !tbaa !29
  store ptr %t87, ptr %l61, !tbaa !29
  %t88 = load ptr, ptr %l61, !tbaa !29
  %t89 = getelementptr { i64, [5 x i64] }, ptr %t88, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t89, i32 0, i32 2
  %t91 = load ptr, ptr %t90
  store ptr %t91, ptr %l62, !tbaa !29
  %t92 = load ptr, ptr %l62, !tbaa !29
  store ptr %t92, ptr %l4, !tbaa !29
  %t93 = load ptr, ptr %l1, !tbaa !29
  store ptr %t93, ptr %l63, !tbaa !29
  %t94 = load ptr, ptr %l63, !tbaa !29
  %t95 = getelementptr { i64, [5 x i64] }, ptr %t94, i32 0, i32 1
  %t96 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t95, i32 0, i32 3
  %t97 = load ptr, ptr %t96
  store ptr %t97, ptr %l64, !tbaa !29
  %t98 = load ptr, ptr %l64, !tbaa !29
  store ptr %t98, ptr %l5, !tbaa !29
  br label %bb30
bb29:
  br label %bb36
bb30:
  store %olang.scope zeroinitializer, ptr %s4
  %t99 = load ptr, ptr %l0, !tbaa !29
  store ptr %t99, ptr %l65, !tbaa !29
  %t100 = load ptr, ptr %l4, !tbaa !29
  store ptr %t100, ptr %l66, !tbaa !29
  %t101 = load ptr, ptr %l65, !tbaa !29
  %t102 = load ptr, ptr %l66, !tbaa !29
  %t103 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2ementionsLocal(ptr %v0, ptr %v1, ptr %t101, ptr %t102)
  store i1 %t103, ptr %l67
  br label %bb31
bb31:
  %t104 = load i1, ptr %l67, !tbaa !21
  br i1 %t104, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l68, !tbaa !21
  br label %bb35
bb33:
  %t105 = load ptr, ptr %l0, !tbaa !29
  store ptr %t105, ptr %l69, !tbaa !29
  %t106 = load ptr, ptr %l5, !tbaa !29
  store ptr %t106, ptr %l70, !tbaa !29
  %t107 = load ptr, ptr %l69, !tbaa !29
  %t108 = load ptr, ptr %l70, !tbaa !29
  %t109 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2ementionsLocal(ptr %v0, ptr %v1, ptr %t107, ptr %t108)
  store i1 %t109, ptr %l71
  br label %bb34
bb34:
  %t110 = load i1, ptr %l71, !tbaa !21
  store i1 %t110, ptr %l68, !tbaa !21
  br label %bb35
bb35:
  %t111 = load i1, ptr %l68, !tbaa !21
  store i1 %t111, ptr %l26, !tbaa !21
  call void @__olang_scope_close(ptr %s4)
  br label %bb178
bb36:
  %t112 = load ptr, ptr %l1, !tbaa !29
  store ptr %t112, ptr %l72, !tbaa !29
  store i1 false, ptr %l73, !tbaa !21
  %t113 = load ptr, ptr %l72, !tbaa !29
  %t114 = icmp ne ptr %t113, null
  store i1 %t114, ptr %l74, !tbaa !21
  %t115 = load i1, ptr %l74, !tbaa !21
  br i1 %t115, label %bb37, label %bb38
bb37:
  %t116 = load ptr, ptr %l72, !tbaa !29
  %t117 = load i64, ptr %t116
  store i64 %t117, ptr %l75, !tbaa !24
  %t118 = load i64, ptr %l75, !tbaa !24
  %t119 = icmp eq i64 %t118, 12
  store i1 %t119, ptr %l73, !tbaa !21
  br label %bb38
bb38:
  %t120 = load i1, ptr %l73, !tbaa !21
  br i1 %t120, label %bb39, label %bb40
bb39:
  %t121 = load ptr, ptr %l1, !tbaa !29
  store ptr %t121, ptr %l76, !tbaa !29
  %t122 = load ptr, ptr %l76, !tbaa !29
  %t123 = getelementptr { i64, [5 x i64] }, ptr %t122, i32 0, i32 1
  %t124 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t123, i32 0, i32 1
  %t125 = load ptr, ptr %t124
  store ptr %t125, ptr %l77, !tbaa !29
  %t126 = load ptr, ptr %l77, !tbaa !29
  store ptr %t126, ptr %l6, !tbaa !29
  %t127 = load ptr, ptr %l1, !tbaa !29
  store ptr %t127, ptr %l78, !tbaa !29
  %t128 = load ptr, ptr %l78, !tbaa !29
  %t129 = getelementptr { i64, [5 x i64] }, ptr %t128, i32 0, i32 1
  %t130 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t129, i32 0, i32 2
  %t131 = load { i64, ptr }, ptr %t130
  store { i64, ptr } %t131, ptr %l79, !tbaa !27
  %t132 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t132, ptr %l7, !tbaa !27
  br label %bb41
bb40:
  br label %bb47
bb41:
  store %olang.scope zeroinitializer, ptr %s5
  %t133 = load ptr, ptr %l0, !tbaa !29
  store ptr %t133, ptr %l80, !tbaa !29
  %t134 = load ptr, ptr %l6, !tbaa !29
  store ptr %t134, ptr %l81, !tbaa !29
  %t135 = load ptr, ptr %l80, !tbaa !29
  %t136 = load ptr, ptr %l81, !tbaa !29
  %t137 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2ementionsLocal(ptr %v0, ptr %v1, ptr %t135, ptr %t136)
  store i1 %t137, ptr %l82
  br label %bb42
bb42:
  %t138 = load i1, ptr %l82, !tbaa !21
  br i1 %t138, label %bb43, label %bb44
bb43:
  store i1 true, ptr %l83, !tbaa !21
  br label %bb46
bb44:
  %t139 = load ptr, ptr %l0, !tbaa !29
  store ptr %t139, ptr %l84, !tbaa !29
  %t140 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t140, ptr %l85, !tbaa !27
  %t141 = load ptr, ptr %l84, !tbaa !29
  %t142 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t143 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2eanyLocal(ptr %v0, ptr %v1, ptr %t141, { i64, ptr } %t142)
  store i1 %t143, ptr %l86
  br label %bb45
bb45:
  %t144 = load i1, ptr %l86, !tbaa !21
  store i1 %t144, ptr %l83, !tbaa !21
  br label %bb46
bb46:
  %t145 = load i1, ptr %l83, !tbaa !21
  store i1 %t145, ptr %l26, !tbaa !21
  call void @__olang_scope_close(ptr %s5)
  br label %bb178
bb47:
  %t146 = load ptr, ptr %l1, !tbaa !29
  store ptr %t146, ptr %l87, !tbaa !29
  store i1 false, ptr %l88, !tbaa !21
  %t147 = load ptr, ptr %l87, !tbaa !29
  %t148 = icmp ne ptr %t147, null
  store i1 %t148, ptr %l89, !tbaa !21
  %t149 = load i1, ptr %l89, !tbaa !21
  br i1 %t149, label %bb48, label %bb49
bb48:
  %t150 = load ptr, ptr %l87, !tbaa !29
  %t151 = load i64, ptr %t150
  store i64 %t151, ptr %l90, !tbaa !24
  %t152 = load i64, ptr %l90, !tbaa !24
  %t153 = icmp eq i64 %t152, 16
  store i1 %t153, ptr %l88, !tbaa !21
  br label %bb49
bb49:
  %t154 = load i1, ptr %l88, !tbaa !21
  br i1 %t154, label %bb50, label %bb51
bb50:
  %t155 = load ptr, ptr %l1, !tbaa !29
  store ptr %t155, ptr %l91, !tbaa !29
  %t156 = load ptr, ptr %l91, !tbaa !29
  %t157 = getelementptr { i64, [5 x i64] }, ptr %t156, i32 0, i32 1
  %t158 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t157, i32 0, i32 1
  %t159 = load ptr, ptr %t158
  store ptr %t159, ptr %l92, !tbaa !29
  %t160 = load ptr, ptr %l92, !tbaa !29
  store ptr %t160, ptr %l8, !tbaa !29
  %t161 = load ptr, ptr %l1, !tbaa !29
  store ptr %t161, ptr %l93, !tbaa !29
  %t162 = load ptr, ptr %l93, !tbaa !29
  %t163 = getelementptr { i64, [5 x i64] }, ptr %t162, i32 0, i32 1
  %t164 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t163, i32 0, i32 2
  %t165 = load { i64, ptr }, ptr %t164
  store { i64, ptr } %t165, ptr %l94, !tbaa !27
  %t166 = load { i64, ptr }, ptr %l94, !tbaa !27
  store { i64, ptr } %t166, ptr %l9, !tbaa !27
  br label %bb52
bb51:
  br label %bb58
bb52:
  store %olang.scope zeroinitializer, ptr %s6
  %t167 = load ptr, ptr %l0, !tbaa !29
  store ptr %t167, ptr %l95, !tbaa !29
  %t168 = load ptr, ptr %l8, !tbaa !29
  store ptr %t168, ptr %l96, !tbaa !29
  %t169 = load ptr, ptr %l95, !tbaa !29
  %t170 = load ptr, ptr %l96, !tbaa !29
  %t171 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2ementionsLocal(ptr %v0, ptr %v1, ptr %t169, ptr %t170)
  store i1 %t171, ptr %l97
  br label %bb53
bb53:
  %t172 = load i1, ptr %l97, !tbaa !21
  br i1 %t172, label %bb54, label %bb55
bb54:
  store i1 true, ptr %l98, !tbaa !21
  br label %bb57
bb55:
  %t173 = load ptr, ptr %l0, !tbaa !29
  store ptr %t173, ptr %l99, !tbaa !29
  %t174 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t174, ptr %l100, !tbaa !27
  %t175 = load ptr, ptr %l99, !tbaa !29
  %t176 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t177 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2eanyLocal(ptr %v0, ptr %v1, ptr %t175, { i64, ptr } %t176)
  store i1 %t177, ptr %l101
  br label %bb56
bb56:
  %t178 = load i1, ptr %l101, !tbaa !21
  store i1 %t178, ptr %l98, !tbaa !21
  br label %bb57
bb57:
  %t179 = load i1, ptr %l98, !tbaa !21
  store i1 %t179, ptr %l26, !tbaa !21
  call void @__olang_scope_close(ptr %s6)
  br label %bb178
bb58:
  %t180 = load ptr, ptr %l1, !tbaa !29
  store ptr %t180, ptr %l102, !tbaa !29
  store i1 false, ptr %l103, !tbaa !21
  %t181 = load ptr, ptr %l102, !tbaa !29
  %t182 = icmp ne ptr %t181, null
  store i1 %t182, ptr %l104, !tbaa !21
  %t183 = load i1, ptr %l104, !tbaa !21
  br i1 %t183, label %bb59, label %bb60
bb59:
  %t184 = load ptr, ptr %l102, !tbaa !29
  %t185 = load i64, ptr %t184
  store i64 %t185, ptr %l105, !tbaa !24
  %t186 = load i64, ptr %l105, !tbaa !24
  %t187 = icmp eq i64 %t186, 7
  store i1 %t187, ptr %l103, !tbaa !21
  br label %bb60
bb60:
  %t188 = load i1, ptr %l103, !tbaa !21
  br i1 %t188, label %bb61, label %bb62
bb61:
  %t189 = load ptr, ptr %l1, !tbaa !29
  store ptr %t189, ptr %l106, !tbaa !29
  %t190 = load ptr, ptr %l106, !tbaa !29
  %t191 = getelementptr { i64, [5 x i64] }, ptr %t190, i32 0, i32 1
  %t192 = getelementptr { %"compiler/source:Span", ptr }, ptr %t191, i32 0, i32 1
  %t193 = load ptr, ptr %t192
  store ptr %t193, ptr %l107, !tbaa !29
  %t194 = load ptr, ptr %l107, !tbaa !29
  store ptr %t194, ptr %l10, !tbaa !29
  br label %bb63
bb62:
  br label %bb65
bb63:
  store %olang.scope zeroinitializer, ptr %s7
  %t195 = load ptr, ptr %l0, !tbaa !29
  store ptr %t195, ptr %l108, !tbaa !29
  %t196 = load ptr, ptr %l10, !tbaa !29
  store ptr %t196, ptr %l109, !tbaa !29
  %t197 = load ptr, ptr %l109, !tbaa !29
  %t198 = getelementptr %"compiler/ast:Chain", ptr %t197, i32 0, i32 1
  %t199 = load { i64, ptr }, ptr %t198, !tbaa !27
  store { i64, ptr } %t199, ptr %l110, !tbaa !27
  %t200 = load ptr, ptr %l108, !tbaa !29
  %t201 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t202 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2eanyLocal(ptr %v0, ptr %v1, ptr %t200, { i64, ptr } %t201)
  store i1 %t202, ptr %l111
  br label %bb64
bb64:
  %t203 = load i1, ptr %l111, !tbaa !21
  store i1 %t203, ptr %l26, !tbaa !21
  call void @__olang_scope_close(ptr %s7)
  br label %bb178
bb65:
  %t204 = load ptr, ptr %l1, !tbaa !29
  store ptr %t204, ptr %l112, !tbaa !29
  store i1 false, ptr %l113, !tbaa !21
  %t205 = load ptr, ptr %l112, !tbaa !29
  %t206 = icmp ne ptr %t205, null
  store i1 %t206, ptr %l114, !tbaa !21
  %t207 = load i1, ptr %l114, !tbaa !21
  br i1 %t207, label %bb66, label %bb67
bb66:
  %t208 = load ptr, ptr %l112, !tbaa !29
  %t209 = load i64, ptr %t208
  store i64 %t209, ptr %l115, !tbaa !24
  %t210 = load i64, ptr %l115, !tbaa !24
  %t211 = icmp eq i64 %t210, 8
  store i1 %t211, ptr %l113, !tbaa !21
  br label %bb67
bb67:
  %t212 = load i1, ptr %l113, !tbaa !21
  br i1 %t212, label %bb68, label %bb69
bb68:
  %t213 = load ptr, ptr %l1, !tbaa !29
  store ptr %t213, ptr %l116, !tbaa !29
  %t214 = load ptr, ptr %l116, !tbaa !29
  %t215 = getelementptr { i64, [5 x i64] }, ptr %t214, i32 0, i32 1
  %t216 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t215, i32 0, i32 1
  %t217 = load ptr, ptr %t216
  store ptr %t217, ptr %l117, !tbaa !29
  %t218 = load ptr, ptr %l117, !tbaa !29
  store ptr %t218, ptr %l11, !tbaa !29
  %t219 = load ptr, ptr %l1, !tbaa !29
  store ptr %t219, ptr %l118, !tbaa !29
  %t220 = load ptr, ptr %l118, !tbaa !29
  %t221 = getelementptr { i64, [5 x i64] }, ptr %t220, i32 0, i32 1
  %t222 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t221, i32 0, i32 2
  %t223 = load ptr, ptr %t222
  store ptr %t223, ptr %l119, !tbaa !29
  %t224 = load ptr, ptr %l119, !tbaa !29
  store ptr %t224, ptr %l12, !tbaa !29
  %t225 = load ptr, ptr %l1, !tbaa !29
  store ptr %t225, ptr %l120, !tbaa !29
  %t226 = load ptr, ptr %l120, !tbaa !29
  %t227 = getelementptr { i64, [5 x i64] }, ptr %t226, i32 0, i32 1
  %t228 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t227, i32 0, i32 3
  %t229 = load ptr, ptr %t228
  store ptr %t229, ptr %l121, !tbaa !29
  %t230 = load ptr, ptr %l121, !tbaa !29
  store ptr %t230, ptr %l13, !tbaa !29
  br label %bb70
bb69:
  br label %bb80
bb70:
  store %olang.scope zeroinitializer, ptr %s8
  %t231 = load ptr, ptr %l0, !tbaa !29
  store ptr %t231, ptr %l122, !tbaa !29
  %t232 = load ptr, ptr %l11, !tbaa !29
  store ptr %t232, ptr %l123, !tbaa !29
  %t233 = load ptr, ptr %l122, !tbaa !29
  %t234 = load ptr, ptr %l123, !tbaa !29
  %t235 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2ementionsLocal(ptr %v0, ptr %v1, ptr %t233, ptr %t234)
  store i1 %t235, ptr %l124
  br label %bb71
bb71:
  %t236 = load i1, ptr %l124, !tbaa !21
  br i1 %t236, label %bb72, label %bb73
bb72:
  store i1 true, ptr %l125, !tbaa !21
  br label %bb75
bb73:
  %t237 = load ptr, ptr %l0, !tbaa !29
  store ptr %t237, ptr %l126, !tbaa !29
  %t238 = load ptr, ptr %l12, !tbaa !29
  store ptr %t238, ptr %l127, !tbaa !29
  %t239 = load ptr, ptr %l126, !tbaa !29
  %t240 = load ptr, ptr %l127, !tbaa !29
  %t241 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2ementionsLocal(ptr %v0, ptr %v1, ptr %t239, ptr %t240)
  store i1 %t241, ptr %l128
  br label %bb74
bb74:
  %t242 = load i1, ptr %l128, !tbaa !21
  store i1 %t242, ptr %l125, !tbaa !21
  br label %bb75
bb75:
  %t243 = load i1, ptr %l125, !tbaa !21
  br i1 %t243, label %bb76, label %bb77
bb76:
  store i1 true, ptr %l129, !tbaa !21
  br label %bb79
bb77:
  %t244 = load ptr, ptr %l0, !tbaa !29
  store ptr %t244, ptr %l130, !tbaa !29
  %t245 = load ptr, ptr %l13, !tbaa !29
  store ptr %t245, ptr %l131, !tbaa !29
  %t246 = load ptr, ptr %l130, !tbaa !29
  %t247 = load ptr, ptr %l131, !tbaa !29
  %t248 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2ementionsLocal(ptr %v0, ptr %v1, ptr %t246, ptr %t247)
  store i1 %t248, ptr %l132
  br label %bb78
bb78:
  %t249 = load i1, ptr %l132, !tbaa !21
  store i1 %t249, ptr %l129, !tbaa !21
  br label %bb79
bb79:
  %t250 = load i1, ptr %l129, !tbaa !21
  store i1 %t250, ptr %l26, !tbaa !21
  call void @__olang_scope_close(ptr %s8)
  br label %bb178
bb80:
  %t251 = load ptr, ptr %l1, !tbaa !29
  store ptr %t251, ptr %l133, !tbaa !29
  store i1 false, ptr %l134, !tbaa !21
  %t252 = load ptr, ptr %l133, !tbaa !29
  %t253 = icmp ne ptr %t252, null
  store i1 %t253, ptr %l135, !tbaa !21
  %t254 = load i1, ptr %l135, !tbaa !21
  br i1 %t254, label %bb81, label %bb82
bb81:
  %t255 = load ptr, ptr %l133, !tbaa !29
  %t256 = load i64, ptr %t255
  store i64 %t256, ptr %l136, !tbaa !24
  %t257 = load i64, ptr %l136, !tbaa !24
  %t258 = icmp eq i64 %t257, 4
  store i1 %t258, ptr %l134, !tbaa !21
  br label %bb82
bb82:
  %t259 = load i1, ptr %l134, !tbaa !21
  br i1 %t259, label %bb83, label %bb84
bb83:
  %t260 = load ptr, ptr %l1, !tbaa !29
  store ptr %t260, ptr %l137, !tbaa !29
  %t261 = load ptr, ptr %l137, !tbaa !29
  %t262 = getelementptr { i64, [5 x i64] }, ptr %t261, i32 0, i32 1
  %t263 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t262, i32 0, i32 2
  %t264 = load ptr, ptr %t263
  store ptr %t264, ptr %l138, !tbaa !29
  %t265 = load ptr, ptr %l138, !tbaa !29
  store ptr %t265, ptr %l14, !tbaa !29
  br label %bb101
bb84:
  %t266 = load ptr, ptr %l1, !tbaa !29
  store ptr %t266, ptr %l139, !tbaa !29
  store i1 false, ptr %l140, !tbaa !21
  %t267 = load ptr, ptr %l139, !tbaa !29
  %t268 = icmp ne ptr %t267, null
  store i1 %t268, ptr %l141, !tbaa !21
  %t269 = load i1, ptr %l141, !tbaa !21
  br i1 %t269, label %bb85, label %bb86
bb85:
  %t270 = load ptr, ptr %l139, !tbaa !29
  %t271 = load i64, ptr %t270
  store i64 %t271, ptr %l142, !tbaa !24
  %t272 = load i64, ptr %l142, !tbaa !24
  %t273 = icmp eq i64 %t272, 9
  store i1 %t273, ptr %l140, !tbaa !21
  br label %bb86
bb86:
  %t274 = load i1, ptr %l140, !tbaa !21
  br i1 %t274, label %bb87, label %bb88
bb87:
  %t275 = load ptr, ptr %l1, !tbaa !29
  store ptr %t275, ptr %l143, !tbaa !29
  %t276 = load ptr, ptr %l143, !tbaa !29
  %t277 = getelementptr { i64, [5 x i64] }, ptr %t276, i32 0, i32 1
  %t278 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t277, i32 0, i32 1
  %t279 = load ptr, ptr %t278
  store ptr %t279, ptr %l144, !tbaa !29
  %t280 = load ptr, ptr %l144, !tbaa !29
  store ptr %t280, ptr %l14, !tbaa !29
  br label %bb101
bb88:
  %t281 = load ptr, ptr %l1, !tbaa !29
  store ptr %t281, ptr %l145, !tbaa !29
  store i1 false, ptr %l146, !tbaa !21
  %t282 = load ptr, ptr %l145, !tbaa !29
  %t283 = icmp ne ptr %t282, null
  store i1 %t283, ptr %l147, !tbaa !21
  %t284 = load i1, ptr %l147, !tbaa !21
  br i1 %t284, label %bb89, label %bb90
bb89:
  %t285 = load ptr, ptr %l145, !tbaa !29
  %t286 = load i64, ptr %t285
  store i64 %t286, ptr %l148, !tbaa !24
  %t287 = load i64, ptr %l148, !tbaa !24
  %t288 = icmp eq i64 %t287, 11
  store i1 %t288, ptr %l146, !tbaa !21
  br label %bb90
bb90:
  %t289 = load i1, ptr %l146, !tbaa !21
  br i1 %t289, label %bb91, label %bb92
bb91:
  %t290 = load ptr, ptr %l1, !tbaa !29
  store ptr %t290, ptr %l149, !tbaa !29
  %t291 = load ptr, ptr %l149, !tbaa !29
  %t292 = getelementptr { i64, [5 x i64] }, ptr %t291, i32 0, i32 1
  %t293 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t292, i32 0, i32 1
  %t294 = load ptr, ptr %t293
  store ptr %t294, ptr %l150, !tbaa !29
  %t295 = load ptr, ptr %l150, !tbaa !29
  store ptr %t295, ptr %l14, !tbaa !29
  br label %bb101
bb92:
  %t296 = load ptr, ptr %l1, !tbaa !29
  store ptr %t296, ptr %l151, !tbaa !29
  store i1 false, ptr %l152, !tbaa !21
  %t297 = load ptr, ptr %l151, !tbaa !29
  %t298 = icmp ne ptr %t297, null
  store i1 %t298, ptr %l153, !tbaa !21
  %t299 = load i1, ptr %l153, !tbaa !21
  br i1 %t299, label %bb93, label %bb94
bb93:
  %t300 = load ptr, ptr %l151, !tbaa !29
  %t301 = load i64, ptr %t300
  store i64 %t301, ptr %l154, !tbaa !24
  %t302 = load i64, ptr %l154, !tbaa !24
  %t303 = icmp eq i64 %t302, 14
  store i1 %t303, ptr %l152, !tbaa !21
  br label %bb94
bb94:
  %t304 = load i1, ptr %l152, !tbaa !21
  br i1 %t304, label %bb95, label %bb96
bb95:
  %t305 = load ptr, ptr %l1, !tbaa !29
  store ptr %t305, ptr %l155, !tbaa !29
  %t306 = load ptr, ptr %l155, !tbaa !29
  %t307 = getelementptr { i64, [5 x i64] }, ptr %t306, i32 0, i32 1
  %t308 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t307, i32 0, i32 1
  %t309 = load ptr, ptr %t308
  store ptr %t309, ptr %l156, !tbaa !29
  %t310 = load ptr, ptr %l156, !tbaa !29
  store ptr %t310, ptr %l14, !tbaa !29
  br label %bb101
bb96:
  %t311 = load ptr, ptr %l1, !tbaa !29
  store ptr %t311, ptr %l157, !tbaa !29
  store i1 false, ptr %l158, !tbaa !21
  %t312 = load ptr, ptr %l157, !tbaa !29
  %t313 = icmp ne ptr %t312, null
  store i1 %t313, ptr %l159, !tbaa !21
  %t314 = load i1, ptr %l159, !tbaa !21
  br i1 %t314, label %bb97, label %bb98
bb97:
  %t315 = load ptr, ptr %l157, !tbaa !29
  %t316 = load i64, ptr %t315
  store i64 %t316, ptr %l160, !tbaa !24
  %t317 = load i64, ptr %l160, !tbaa !24
  %t318 = icmp eq i64 %t317, 22
  store i1 %t318, ptr %l158, !tbaa !21
  br label %bb98
bb98:
  %t319 = load i1, ptr %l158, !tbaa !21
  br i1 %t319, label %bb99, label %bb100
bb99:
  %t320 = load ptr, ptr %l1, !tbaa !29
  store ptr %t320, ptr %l161, !tbaa !29
  %t321 = load ptr, ptr %l161, !tbaa !29
  %t322 = getelementptr { i64, [5 x i64] }, ptr %t321, i32 0, i32 1
  %t323 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr }, i1 }, ptr %t322, i32 0, i32 1
  %t324 = load ptr, ptr %t323
  store ptr %t324, ptr %l162, !tbaa !29
  %t325 = load ptr, ptr %l162, !tbaa !29
  store ptr %t325, ptr %l14, !tbaa !29
  br label %bb101
bb100:
  br label %bb103
bb101:
  store %olang.scope zeroinitializer, ptr %s9
  %t326 = load ptr, ptr %l0, !tbaa !29
  store ptr %t326, ptr %l163, !tbaa !29
  %t327 = load ptr, ptr %l14, !tbaa !29
  store ptr %t327, ptr %l164, !tbaa !29
  %t328 = load ptr, ptr %l163, !tbaa !29
  %t329 = load ptr, ptr %l164, !tbaa !29
  %t330 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2ementionsLocal(ptr %v0, ptr %v1, ptr %t328, ptr %t329)
  store i1 %t330, ptr %l165
  br label %bb102
bb102:
  %t331 = load i1, ptr %l165, !tbaa !21
  store i1 %t331, ptr %l26, !tbaa !21
  call void @__olang_scope_close(ptr %s9)
  br label %bb178
bb103:
  %t332 = load ptr, ptr %l1, !tbaa !29
  store ptr %t332, ptr %l166, !tbaa !29
  store i1 false, ptr %l167, !tbaa !21
  %t333 = load ptr, ptr %l166, !tbaa !29
  %t334 = icmp ne ptr %t333, null
  store i1 %t334, ptr %l168, !tbaa !21
  %t335 = load i1, ptr %l168, !tbaa !21
  br i1 %t335, label %bb104, label %bb105
bb104:
  %t336 = load ptr, ptr %l166, !tbaa !29
  %t337 = load i64, ptr %t336
  store i64 %t337, ptr %l169, !tbaa !24
  %t338 = load i64, ptr %l169, !tbaa !24
  %t339 = icmp eq i64 %t338, 6
  store i1 %t339, ptr %l167, !tbaa !21
  br label %bb105
bb105:
  %t340 = load i1, ptr %l167, !tbaa !21
  br i1 %t340, label %bb106, label %bb107
bb106:
  %t341 = load ptr, ptr %l1, !tbaa !29
  store ptr %t341, ptr %l170, !tbaa !29
  %t342 = load ptr, ptr %l170, !tbaa !29
  %t343 = getelementptr { i64, [5 x i64] }, ptr %t342, i32 0, i32 1
  %t344 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t343, i32 0, i32 1
  %t345 = load ptr, ptr %t344
  store ptr %t345, ptr %l171, !tbaa !29
  %t346 = load ptr, ptr %l171, !tbaa !29
  store ptr %t346, ptr %l15, !tbaa !29
  %t347 = load ptr, ptr %l1, !tbaa !29
  store ptr %t347, ptr %l172, !tbaa !29
  %t348 = load ptr, ptr %l172, !tbaa !29
  %t349 = getelementptr { i64, [5 x i64] }, ptr %t348, i32 0, i32 1
  %t350 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t349, i32 0, i32 2
  %t351 = load ptr, ptr %t350
  store ptr %t351, ptr %l173, !tbaa !29
  %t352 = load ptr, ptr %l173, !tbaa !29
  store ptr %t352, ptr %l16, !tbaa !29
  br label %bb112
bb107:
  %t353 = load ptr, ptr %l1, !tbaa !29
  store ptr %t353, ptr %l174, !tbaa !29
  store i1 false, ptr %l175, !tbaa !21
  %t354 = load ptr, ptr %l174, !tbaa !29
  %t355 = icmp ne ptr %t354, null
  store i1 %t355, ptr %l176, !tbaa !21
  %t356 = load i1, ptr %l176, !tbaa !21
  br i1 %t356, label %bb108, label %bb109
bb108:
  %t357 = load ptr, ptr %l174, !tbaa !29
  %t358 = load i64, ptr %t357
  store i64 %t358, ptr %l177, !tbaa !24
  %t359 = load i64, ptr %l177, !tbaa !24
  %t360 = icmp eq i64 %t359, 10
  store i1 %t360, ptr %l175, !tbaa !21
  br label %bb109
bb109:
  %t361 = load i1, ptr %l175, !tbaa !21
  br i1 %t361, label %bb110, label %bb111
bb110:
  %t362 = load ptr, ptr %l1, !tbaa !29
  store ptr %t362, ptr %l178, !tbaa !29
  %t363 = load ptr, ptr %l178, !tbaa !29
  %t364 = getelementptr { i64, [5 x i64] }, ptr %t363, i32 0, i32 1
  %t365 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t364, i32 0, i32 1
  %t366 = load ptr, ptr %t365
  store ptr %t366, ptr %l179, !tbaa !29
  %t367 = load ptr, ptr %l179, !tbaa !29
  store ptr %t367, ptr %l15, !tbaa !29
  %t368 = load ptr, ptr %l1, !tbaa !29
  store ptr %t368, ptr %l180, !tbaa !29
  %t369 = load ptr, ptr %l180, !tbaa !29
  %t370 = getelementptr { i64, [5 x i64] }, ptr %t369, i32 0, i32 1
  %t371 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t370, i32 0, i32 2
  %t372 = load ptr, ptr %t371
  store ptr %t372, ptr %l181, !tbaa !29
  %t373 = load ptr, ptr %l181, !tbaa !29
  store ptr %t373, ptr %l16, !tbaa !29
  br label %bb112
bb111:
  br label %bb118
bb112:
  store %olang.scope zeroinitializer, ptr %s10
  %t374 = load ptr, ptr %l0, !tbaa !29
  store ptr %t374, ptr %l182, !tbaa !29
  %t375 = load ptr, ptr %l15, !tbaa !29
  store ptr %t375, ptr %l183, !tbaa !29
  %t376 = load ptr, ptr %l182, !tbaa !29
  %t377 = load ptr, ptr %l183, !tbaa !29
  %t378 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2ementionsLocal(ptr %v0, ptr %v1, ptr %t376, ptr %t377)
  store i1 %t378, ptr %l184
  br label %bb113
bb113:
  %t379 = load i1, ptr %l184, !tbaa !21
  br i1 %t379, label %bb114, label %bb115
bb114:
  store i1 true, ptr %l185, !tbaa !21
  br label %bb117
bb115:
  %t380 = load ptr, ptr %l0, !tbaa !29
  store ptr %t380, ptr %l186, !tbaa !29
  %t381 = load ptr, ptr %l16, !tbaa !29
  store ptr %t381, ptr %l187, !tbaa !29
  %t382 = load ptr, ptr %l186, !tbaa !29
  %t383 = load ptr, ptr %l187, !tbaa !29
  %t384 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2ementionsLocal(ptr %v0, ptr %v1, ptr %t382, ptr %t383)
  store i1 %t384, ptr %l188
  br label %bb116
bb116:
  %t385 = load i1, ptr %l188, !tbaa !21
  store i1 %t385, ptr %l185, !tbaa !21
  br label %bb117
bb117:
  %t386 = load i1, ptr %l185, !tbaa !21
  store i1 %t386, ptr %l26, !tbaa !21
  call void @__olang_scope_close(ptr %s10)
  br label %bb178
bb118:
  %t387 = load ptr, ptr %l1, !tbaa !29
  store ptr %t387, ptr %l189, !tbaa !29
  store i1 false, ptr %l190, !tbaa !21
  %t388 = load ptr, ptr %l189, !tbaa !29
  %t389 = icmp ne ptr %t388, null
  store i1 %t389, ptr %l191, !tbaa !21
  %t390 = load i1, ptr %l191, !tbaa !21
  br i1 %t390, label %bb119, label %bb120
bb119:
  %t391 = load ptr, ptr %l189, !tbaa !29
  %t392 = load i64, ptr %t391
  store i64 %t392, ptr %l192, !tbaa !24
  %t393 = load i64, ptr %l192, !tbaa !24
  %t394 = icmp eq i64 %t393, 13
  store i1 %t394, ptr %l190, !tbaa !21
  br label %bb120
bb120:
  %t395 = load i1, ptr %l190, !tbaa !21
  br i1 %t395, label %bb121, label %bb122
bb121:
  %t396 = load ptr, ptr %l1, !tbaa !29
  store ptr %t396, ptr %l193, !tbaa !29
  %t397 = load ptr, ptr %l193, !tbaa !29
  %t398 = getelementptr { i64, [5 x i64] }, ptr %t397, i32 0, i32 1
  %t399 = getelementptr { %"compiler/source:Span", ptr, i32, { i64, ptr } }, ptr %t398, i32 0, i32 1
  %t400 = load ptr, ptr %t399
  store ptr %t400, ptr %l194, !tbaa !29
  %t401 = load ptr, ptr %l194, !tbaa !29
  store ptr %t401, ptr %l17, !tbaa !29
  %t402 = load ptr, ptr %l1, !tbaa !29
  store ptr %t402, ptr %l195, !tbaa !29
  %t403 = load ptr, ptr %l195, !tbaa !29
  %t404 = getelementptr { i64, [5 x i64] }, ptr %t403, i32 0, i32 1
  %t405 = getelementptr { %"compiler/source:Span", ptr, i32, { i64, ptr } }, ptr %t404, i32 0, i32 3
  %t406 = load { i64, ptr }, ptr %t405
  store { i64, ptr } %t406, ptr %l196, !tbaa !27
  %t407 = load { i64, ptr }, ptr %l196, !tbaa !27
  store { i64, ptr } %t407, ptr %l18, !tbaa !27
  br label %bb123
bb122:
  br label %bb129
bb123:
  store %olang.scope zeroinitializer, ptr %s11
  %t408 = load ptr, ptr %l0, !tbaa !29
  store ptr %t408, ptr %l197, !tbaa !29
  %t409 = load ptr, ptr %l17, !tbaa !29
  store ptr %t409, ptr %l198, !tbaa !29
  %t410 = load ptr, ptr %l197, !tbaa !29
  %t411 = load ptr, ptr %l198, !tbaa !29
  %t412 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2ementionsLocal(ptr %v0, ptr %v1, ptr %t410, ptr %t411)
  store i1 %t412, ptr %l199
  br label %bb124
bb124:
  %t413 = load i1, ptr %l199, !tbaa !21
  br i1 %t413, label %bb125, label %bb126
bb125:
  store i1 true, ptr %l200, !tbaa !21
  br label %bb128
bb126:
  %t414 = load ptr, ptr %l0, !tbaa !29
  store ptr %t414, ptr %l201, !tbaa !29
  %t415 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t415, ptr %l202, !tbaa !27
  %t416 = load ptr, ptr %l201, !tbaa !29
  %t417 = load { i64, ptr }, ptr %l202, !tbaa !27
  %t418 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2eanyLocal(ptr %v0, ptr %v1, ptr %t416, { i64, ptr } %t417)
  store i1 %t418, ptr %l203
  br label %bb127
bb127:
  %t419 = load i1, ptr %l203, !tbaa !21
  store i1 %t419, ptr %l200, !tbaa !21
  br label %bb128
bb128:
  %t420 = load i1, ptr %l200, !tbaa !21
  store i1 %t420, ptr %l26, !tbaa !21
  call void @__olang_scope_close(ptr %s11)
  br label %bb178
bb129:
  %t421 = load ptr, ptr %l1, !tbaa !29
  store ptr %t421, ptr %l204, !tbaa !29
  store i1 false, ptr %l205, !tbaa !21
  %t422 = load ptr, ptr %l204, !tbaa !29
  %t423 = icmp ne ptr %t422, null
  store i1 %t423, ptr %l206, !tbaa !21
  %t424 = load i1, ptr %l206, !tbaa !21
  br i1 %t424, label %bb130, label %bb131
bb130:
  %t425 = load ptr, ptr %l204, !tbaa !29
  %t426 = load i64, ptr %t425
  store i64 %t426, ptr %l207, !tbaa !24
  %t427 = load i64, ptr %l207, !tbaa !24
  %t428 = icmp eq i64 %t427, 17
  store i1 %t428, ptr %l205, !tbaa !21
  br label %bb131
bb131:
  %t429 = load i1, ptr %l205, !tbaa !21
  br i1 %t429, label %bb132, label %bb133
bb132:
  %t430 = load ptr, ptr %l1, !tbaa !29
  store ptr %t430, ptr %l208, !tbaa !29
  %t431 = load ptr, ptr %l208, !tbaa !29
  %t432 = getelementptr { i64, [5 x i64] }, ptr %t431, i32 0, i32 1
  %t433 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t432, i32 0, i32 1
  %t434 = load ptr, ptr %t433
  store ptr %t434, ptr %l209, !tbaa !29
  %t435 = load ptr, ptr %l209, !tbaa !29
  store ptr %t435, ptr %l19, !tbaa !29
  %t436 = load ptr, ptr %l1, !tbaa !29
  store ptr %t436, ptr %l210, !tbaa !29
  %t437 = load ptr, ptr %l210, !tbaa !29
  %t438 = getelementptr { i64, [5 x i64] }, ptr %t437, i32 0, i32 1
  %t439 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t438, i32 0, i32 2
  %t440 = load ptr, ptr %t439
  store ptr %t440, ptr %l211, !tbaa !29
  %t441 = load ptr, ptr %l211, !tbaa !29
  store ptr %t441, ptr %l20, !tbaa !29
  %t442 = load ptr, ptr %l1, !tbaa !29
  store ptr %t442, ptr %l212, !tbaa !29
  %t443 = load ptr, ptr %l212, !tbaa !29
  %t444 = getelementptr { i64, [5 x i64] }, ptr %t443, i32 0, i32 1
  %t445 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t444, i32 0, i32 3
  %t446 = load ptr, ptr %t445
  store ptr %t446, ptr %l213, !tbaa !29
  %t447 = load ptr, ptr %l213, !tbaa !29
  store ptr %t447, ptr %l21, !tbaa !29
  br label %bb134
bb133:
  br label %bb144
bb134:
  store %olang.scope zeroinitializer, ptr %s12
  %t448 = load ptr, ptr %l0, !tbaa !29
  store ptr %t448, ptr %l214, !tbaa !29
  %t449 = load ptr, ptr %l19, !tbaa !29
  store ptr %t449, ptr %l215, !tbaa !29
  %t450 = load ptr, ptr %l214, !tbaa !29
  %t451 = load ptr, ptr %l215, !tbaa !29
  %t452 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2ementionsLocal(ptr %v0, ptr %v1, ptr %t450, ptr %t451)
  store i1 %t452, ptr %l216
  br label %bb135
bb135:
  %t453 = load i1, ptr %l216, !tbaa !21
  br i1 %t453, label %bb136, label %bb137
bb136:
  store i1 true, ptr %l217, !tbaa !21
  br label %bb139
bb137:
  %t454 = load ptr, ptr %l0, !tbaa !29
  store ptr %t454, ptr %l218, !tbaa !29
  %t455 = load ptr, ptr %l20, !tbaa !29
  store ptr %t455, ptr %l219, !tbaa !29
  %t456 = load ptr, ptr %l218, !tbaa !29
  %t457 = load ptr, ptr %l219, !tbaa !29
  %t458 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2ementionsLocal(ptr %v0, ptr %v1, ptr %t456, ptr %t457)
  store i1 %t458, ptr %l220
  br label %bb138
bb138:
  %t459 = load i1, ptr %l220, !tbaa !21
  store i1 %t459, ptr %l217, !tbaa !21
  br label %bb139
bb139:
  %t460 = load i1, ptr %l217, !tbaa !21
  br i1 %t460, label %bb140, label %bb141
bb140:
  store i1 true, ptr %l221, !tbaa !21
  br label %bb143
bb141:
  %t461 = load ptr, ptr %l0, !tbaa !29
  store ptr %t461, ptr %l222, !tbaa !29
  %t462 = load ptr, ptr %l21, !tbaa !29
  store ptr %t462, ptr %l223, !tbaa !29
  %t463 = load ptr, ptr %l222, !tbaa !29
  %t464 = load ptr, ptr %l223, !tbaa !29
  %t465 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2ementionsLocal(ptr %v0, ptr %v1, ptr %t463, ptr %t464)
  store i1 %t465, ptr %l224
  br label %bb142
bb142:
  %t466 = load i1, ptr %l224, !tbaa !21
  store i1 %t466, ptr %l221, !tbaa !21
  br label %bb143
bb143:
  %t467 = load i1, ptr %l221, !tbaa !21
  store i1 %t467, ptr %l26, !tbaa !21
  call void @__olang_scope_close(ptr %s12)
  br label %bb178
bb144:
  %t468 = load ptr, ptr %l1, !tbaa !29
  store ptr %t468, ptr %l225, !tbaa !29
  store i1 false, ptr %l226, !tbaa !21
  %t469 = load ptr, ptr %l225, !tbaa !29
  %t470 = icmp ne ptr %t469, null
  store i1 %t470, ptr %l227, !tbaa !21
  %t471 = load i1, ptr %l227, !tbaa !21
  br i1 %t471, label %bb145, label %bb146
bb145:
  %t472 = load ptr, ptr %l225, !tbaa !29
  %t473 = load i64, ptr %t472
  store i64 %t473, ptr %l228, !tbaa !24
  %t474 = load i64, ptr %l228, !tbaa !24
  %t475 = icmp eq i64 %t474, 18
  store i1 %t475, ptr %l226, !tbaa !21
  br label %bb146
bb146:
  %t476 = load i1, ptr %l226, !tbaa !21
  br i1 %t476, label %bb147, label %bb148
bb147:
  %t477 = load ptr, ptr %l1, !tbaa !29
  store ptr %t477, ptr %l229, !tbaa !29
  %t478 = load ptr, ptr %l229, !tbaa !29
  %t479 = getelementptr { i64, [5 x i64] }, ptr %t478, i32 0, i32 1
  %t480 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t479, i32 0, i32 2
  %t481 = load { i64, ptr }, ptr %t480
  store { i64, ptr } %t481, ptr %l230, !tbaa !27
  %t482 = load { i64, ptr }, ptr %l230, !tbaa !27
  store { i64, ptr } %t482, ptr %l22, !tbaa !27
  br label %bb157
bb148:
  %t483 = load ptr, ptr %l1, !tbaa !29
  store ptr %t483, ptr %l231, !tbaa !29
  store i1 false, ptr %l232, !tbaa !21
  %t484 = load ptr, ptr %l231, !tbaa !29
  %t485 = icmp ne ptr %t484, null
  store i1 %t485, ptr %l233, !tbaa !21
  %t486 = load i1, ptr %l233, !tbaa !21
  br i1 %t486, label %bb149, label %bb150
bb149:
  %t487 = load ptr, ptr %l231, !tbaa !29
  %t488 = load i64, ptr %t487
  store i64 %t488, ptr %l234, !tbaa !24
  %t489 = load i64, ptr %l234, !tbaa !24
  %t490 = icmp eq i64 %t489, 19
  store i1 %t490, ptr %l232, !tbaa !21
  br label %bb150
bb150:
  %t491 = load i1, ptr %l232, !tbaa !21
  br i1 %t491, label %bb151, label %bb152
bb151:
  %t492 = load ptr, ptr %l1, !tbaa !29
  store ptr %t492, ptr %l235, !tbaa !29
  %t493 = load ptr, ptr %l235, !tbaa !29
  %t494 = getelementptr { i64, [5 x i64] }, ptr %t493, i32 0, i32 1
  %t495 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t494, i32 0, i32 1
  %t496 = load { i64, ptr }, ptr %t495
  store { i64, ptr } %t496, ptr %l236, !tbaa !27
  %t497 = load { i64, ptr }, ptr %l236, !tbaa !27
  store { i64, ptr } %t497, ptr %l22, !tbaa !27
  br label %bb157
bb152:
  %t498 = load ptr, ptr %l1, !tbaa !29
  store ptr %t498, ptr %l237, !tbaa !29
  store i1 false, ptr %l238, !tbaa !21
  %t499 = load ptr, ptr %l237, !tbaa !29
  %t500 = icmp ne ptr %t499, null
  store i1 %t500, ptr %l239, !tbaa !21
  %t501 = load i1, ptr %l239, !tbaa !21
  br i1 %t501, label %bb153, label %bb154
bb153:
  %t502 = load ptr, ptr %l237, !tbaa !29
  %t503 = load i64, ptr %t502
  store i64 %t503, ptr %l240, !tbaa !24
  %t504 = load i64, ptr %l240, !tbaa !24
  %t505 = icmp eq i64 %t504, 21
  store i1 %t505, ptr %l238, !tbaa !21
  br label %bb154
bb154:
  %t506 = load i1, ptr %l238, !tbaa !21
  br i1 %t506, label %bb155, label %bb156
bb155:
  %t507 = load ptr, ptr %l1, !tbaa !29
  store ptr %t507, ptr %l241, !tbaa !29
  %t508 = load ptr, ptr %l241, !tbaa !29
  %t509 = getelementptr { i64, [5 x i64] }, ptr %t508, i32 0, i32 1
  %t510 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t509, i32 0, i32 1
  %t511 = load { i64, ptr }, ptr %t510
  store { i64, ptr } %t511, ptr %l242, !tbaa !27
  %t512 = load { i64, ptr }, ptr %l242, !tbaa !27
  store { i64, ptr } %t512, ptr %l22, !tbaa !27
  br label %bb157
bb156:
  br label %bb159
bb157:
  store %olang.scope zeroinitializer, ptr %s13
  %t513 = load ptr, ptr %l0, !tbaa !29
  store ptr %t513, ptr %l243, !tbaa !29
  %t514 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t514, ptr %l244, !tbaa !27
  %t515 = load ptr, ptr %l243, !tbaa !29
  %t516 = load { i64, ptr }, ptr %l244, !tbaa !27
  %t517 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2eanyLocal(ptr %v0, ptr %v1, ptr %t515, { i64, ptr } %t516)
  store i1 %t517, ptr %l245
  br label %bb158
bb158:
  %t518 = load i1, ptr %l245, !tbaa !21
  store i1 %t518, ptr %l26, !tbaa !21
  call void @__olang_scope_close(ptr %s13)
  br label %bb178
bb159:
  %t519 = load ptr, ptr %l1, !tbaa !29
  store ptr %t519, ptr %l246, !tbaa !29
  store i1 false, ptr %l247, !tbaa !21
  %t520 = load ptr, ptr %l246, !tbaa !29
  %t521 = icmp ne ptr %t520, null
  store i1 %t521, ptr %l248, !tbaa !21
  %t522 = load i1, ptr %l248, !tbaa !21
  br i1 %t522, label %bb160, label %bb161
bb160:
  %t523 = load ptr, ptr %l246, !tbaa !29
  %t524 = load i64, ptr %t523
  store i64 %t524, ptr %l249, !tbaa !24
  %t525 = load i64, ptr %l249, !tbaa !24
  %t526 = icmp eq i64 %t525, 20
  store i1 %t526, ptr %l247, !tbaa !21
  br label %bb161
bb161:
  %t527 = load i1, ptr %l247, !tbaa !21
  br i1 %t527, label %bb162, label %bb163
bb162:
  br label %bb172
bb163:
  %t528 = load ptr, ptr %l1, !tbaa !29
  store ptr %t528, ptr %l250, !tbaa !29
  store i1 false, ptr %l251, !tbaa !21
  %t529 = load ptr, ptr %l250, !tbaa !29
  %t530 = icmp ne ptr %t529, null
  store i1 %t530, ptr %l252, !tbaa !21
  %t531 = load i1, ptr %l252, !tbaa !21
  br i1 %t531, label %bb164, label %bb165
bb164:
  %t532 = load ptr, ptr %l250, !tbaa !29
  %t533 = load i64, ptr %t532
  store i64 %t533, ptr %l253, !tbaa !24
  %t534 = load i64, ptr %l253, !tbaa !24
  %t535 = icmp eq i64 %t534, 23
  store i1 %t535, ptr %l251, !tbaa !21
  br label %bb165
bb165:
  %t536 = load i1, ptr %l251, !tbaa !21
  br i1 %t536, label %bb166, label %bb167
bb166:
  br label %bb172
bb167:
  %t537 = load ptr, ptr %l1, !tbaa !29
  store ptr %t537, ptr %l254, !tbaa !29
  store i1 false, ptr %l255, !tbaa !21
  %t538 = load ptr, ptr %l254, !tbaa !29
  %t539 = icmp ne ptr %t538, null
  store i1 %t539, ptr %l256, !tbaa !21
  %t540 = load i1, ptr %l256, !tbaa !21
  br i1 %t540, label %bb168, label %bb169
bb168:
  %t541 = load ptr, ptr %l254, !tbaa !29
  %t542 = load i64, ptr %t541
  store i64 %t542, ptr %l257, !tbaa !24
  %t543 = load i64, ptr %l257, !tbaa !24
  %t544 = icmp eq i64 %t543, 24
  store i1 %t544, ptr %l255, !tbaa !21
  br label %bb169
bb169:
  %t545 = load i1, ptr %l255, !tbaa !21
  br i1 %t545, label %bb170, label %bb171
bb170:
  br label %bb172
bb171:
  br label %bb173
bb172:
  store %olang.scope zeroinitializer, ptr %s14
  store i1 true, ptr %l26, !tbaa !21
  call void @__olang_scope_close(ptr %s14)
  br label %bb178
bb173:
  br i1 true, label %bb174, label %bb175
bb174:
  br label %bb176
bb175:
  br label %bb177
bb176:
  store %olang.scope zeroinitializer, ptr %s15
  store i1 false, ptr %l26, !tbaa !21
  call void @__olang_scope_close(ptr %s15)
  br label %bb178
bb177:
  call void @__olang_check_failed(ptr @.c41)
  unreachable
bb178:
  call void @__olang_scope_close(ptr %s0)
  %t546 = load i1, ptr %l26, !tbaa !21
  store i1 %t546, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2ename(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"compiler/cond:Value"
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca %"compiler/source:Span"
  %l12 = alloca %"compiler/cond:Value"
  %l13 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca %"compiler/source:Span"
  %l18 = alloca ptr
  %l19 = alloca %"compiler/source:Span"
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca %"compiler/msgs:Msg"
  %l23 = alloca %"compiler/cond:Value"
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca i32
  %l27 = alloca { i64, ptr }
  %l28 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l32 = alloca ptr
  %l33 = alloca i32
  %l34 = alloca ptr
  %l35 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca %"compiler/source:Span"
  %l38 = alloca ptr
  %l39 = alloca %"compiler/cond:Value"
  %l40 = alloca i64
  %l41 = alloca ptr
  %l42 = alloca ptr
  %l43 = alloca { i64, ptr }
  %l44 = alloca i64
  %l45 = alloca i32
  %l46 = alloca i64
  %l47 = alloca i1
  %l48 = alloca ptr
  %l49 = alloca ptr
  %l50 = alloca ptr
  %l51 = alloca i64
  %l52 = alloca i1
  %l53 = alloca i1
  %l54 = alloca ptr
  %l55 = alloca ptr
  %l56 = alloca ptr
  %l57 = alloca i64
  %l58 = alloca i1
  %l59 = alloca i1
  %l60 = alloca ptr
  %l61 = alloca %"compiler/source:Span"
  %l62 = alloca %"compiler/cond:Value"
  %l63 = alloca ptr
  %l64 = alloca i64
  %l65 = alloca %"compiler/cond:Value"
  %l66 = alloca ptr
  %l67 = alloca i64
  %l68 = alloca i1
  %l69 = alloca ptr
  %l70 = alloca %"compiler/cond:Value"
  %l71 = alloca ptr
  %l72 = alloca %"compiler/source:Span"
  %l73 = alloca %"compiler/cond:Value"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca %"compiler/cond:Value"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  store i32 %t2, ptr %l8, !tbaa !23
  %t3 = load ptr, ptr %l7, !tbaa !29
  %t4 = load i32, ptr %l8, !tbaa !23
  %t5 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2eisFixed(ptr %v0, ptr %t3, i32 %t4)
  store i1 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i1, ptr %l9, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l10, !tbaa !29
  %t8 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t8, ptr %l11
  %t9 = load ptr, ptr %l10, !tbaa !29
  %t10 = load %"compiler/source:Span", ptr %l11
  %t11 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t9, %"compiler/source:Span" %t10)
  store %"compiler/cond:Value" %t11, ptr %l12
  br label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t12 = load %"compiler/cond:Value", ptr %l12
  store %"compiler/cond:Value" %t12, ptr %rv
  br label %ret
bb5:
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l13, !tbaa !29
  %t14 = load i32, ptr %l2, !tbaa !23
  store i32 %t14, ptr %l14, !tbaa !23
  %t15 = load ptr, ptr %l13, !tbaa !29
  %t16 = load i32, ptr %l14, !tbaa !23
  %t17 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aEval_2eisLocal(ptr %v0, ptr %t15, i32 %t16)
  store i1 %t17, ptr %l15
  br label %bb6
bb6:
  %t18 = load i1, ptr %l15, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l16, !tbaa !29
  %t20 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t20, ptr %l17
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l18, !tbaa !29
  %t22 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t22, ptr %l19
  %t23 = load ptr, ptr %l18, !tbaa !29
  %t24 = load %"compiler/source:Span", ptr %l19
  %t25 = call { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aEval_2etokText(ptr %v0, ptr %v0, ptr %t23, %"compiler/source:Span" %t24)
  store { i64, ptr } %t25, ptr %l20
  br label %bb9
bb8:
  br label %bb12
bb9:
  %t26 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t26, 0
  %t28 = extractvalue { i64, ptr } %t26, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  store { i64, ptr } %t32, ptr %l21, !tbaa !27
  %t33 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t34 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondName(ptr %v0, ptr %v0, { i64, ptr } %t33)
  store %"compiler/msgs:Msg" %t34, ptr %l22
  br label %bb10
bb10:
  %t35 = load ptr, ptr %l16, !tbaa !29
  %t36 = load %"compiler/source:Span", ptr %l17
  %t37 = load %"compiler/msgs:Msg", ptr %l22
  %t38 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eruntimeValue(ptr %v0, ptr %v0, ptr %t35, %"compiler/source:Span" %t36, %"compiler/msgs:Msg" %t37, i1 true)
  store %"compiler/cond:Value" %t38, ptr %l23
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t39 = load %"compiler/cond:Value", ptr %l23
  store %"compiler/cond:Value" %t39, ptr %rv
  br label %ret
bb12:
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l24, !tbaa !29
  %t41 = load ptr, ptr %l24, !tbaa !29
  %t42 = getelementptr %"compiler/cond:Eval", ptr %t41, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !29
  store ptr %t43, ptr %l25, !tbaa !29
  %t44 = load i32, ptr %l2, !tbaa !23
  store i32 %t44, ptr %l26, !tbaa !23
  %t45 = load ptr, ptr %l25, !tbaa !29
  %t46 = load i32, ptr %l26, !tbaa !23
  %t47 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t45, i32 %t46)
  store { i64, ptr } %t47, ptr %l27
  br label %bb13
bb13:
  %t48 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t48, ptr %l3, !tbaa !27
  %t49 = load ptr, ptr %l0, !tbaa !29
  store ptr %t49, ptr %l29, !tbaa !29
  %t50 = load ptr, ptr %l29, !tbaa !29
  %t51 = getelementptr %"compiler/cond:Eval", ptr %t50, i32 0, i32 2
  %t52 = load ptr, ptr %t51, !tbaa !29
  store ptr %t52, ptr %l30, !tbaa !29
  %t53 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t53, ptr %l31, !tbaa !27
  %t54 = load ptr, ptr %l30, !tbaa !29
  %t55 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t56 = call { i32, ptr } @compiler_2fcond_2ecompiler_2fcond_3aScope_2efind(ptr %v0, ptr %v0, ptr %t54, { i64, ptr } %t55)
  %t57 = extractvalue { i32, ptr } %t56, 1
  %t58 = extractvalue { i32, ptr } %t56, 0
  store i32 %t58, ptr %l33
  %t59 = icmp ne i32 %t58, 0
  br i1 %t59, label %bb15, label %ok.60
ok.60:
  store ptr %t57, ptr %l32
  br label %bb14
bb14:
  %t61 = load ptr, ptr %l32, !tbaa !29
  store ptr %t61, ptr %l28, !tbaa !29
  br label %bb17
bb15:
  br label %bb16
bb16:
  store ptr null, ptr %l28, !tbaa !29
  br label %bb17
bb17:
  %t62 = load ptr, ptr %l28, !tbaa !29
  store ptr %t62, ptr %l4, !tbaa !29
  %t63 = load ptr, ptr %l4, !tbaa !29
  store ptr %t63, ptr %l34, !tbaa !29
  %t64 = load ptr, ptr %l34, !tbaa !29
  %t65 = icmp ne ptr %t64, null
  store i1 %t65, ptr %l35, !tbaa !21
  %t66 = load i1, ptr %l35, !tbaa !21
  br i1 %t66, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s3
  %t67 = load ptr, ptr %l0, !tbaa !29
  store ptr %t67, ptr %l36, !tbaa !29
  %t68 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t68, ptr %l37
  %t69 = load ptr, ptr %l4, !tbaa !29
  store ptr %t69, ptr %l38, !tbaa !29
  %t70 = load ptr, ptr %l36, !tbaa !29
  %t71 = load %"compiler/source:Span", ptr %l37
  %t72 = load ptr, ptr %l38, !tbaa !29
  %t73 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eglobal(ptr %v0, ptr %v0, ptr %t70, %"compiler/source:Span" %t71, ptr %t72)
  store %"compiler/cond:Value" %t73, ptr %l39
  br label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t74 = load %"compiler/cond:Value", ptr %l39
  store %"compiler/cond:Value" %t74, ptr %rv
  br label %ret
bb21:
  %t75 = load ptr, ptr %l0, !tbaa !29
  store ptr %t75, ptr %l41, !tbaa !29
  %t76 = load ptr, ptr %l41, !tbaa !29
  %t77 = getelementptr %"compiler/cond:Eval", ptr %t76, i32 0, i32 3
  %t78 = load ptr, ptr %t77, !tbaa !29
  store ptr %t78, ptr %l42, !tbaa !29
  %t79 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t79, ptr %l43, !tbaa !27
  %t80 = load ptr, ptr %l42, !tbaa !29
  %t81 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t82 = call { i32, i64 } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2efind(ptr %v0, ptr %v0, ptr %t80, { i64, ptr } %t81)
  %t83 = extractvalue { i32, i64 } %t82, 1
  %t84 = extractvalue { i32, i64 } %t82, 0
  store i32 %t84, ptr %l45
  %t85 = icmp ne i32 %t84, 0
  br i1 %t85, label %bb23, label %ok.86
ok.86:
  store i64 %t83, ptr %l44
  br label %bb22
bb22:
  %t87 = load i64, ptr %l44, !tbaa !24
  store i64 %t87, ptr %l40, !tbaa !24
  br label %bb25
bb23:
  br label %bb24
bb24:
  store i64 -1, ptr %l40, !tbaa !24
  br label %bb25
bb25:
  %t88 = load i64, ptr %l40, !tbaa !24
  store i64 %t88, ptr %l5, !tbaa !24
  %t89 = load i64, ptr %l5, !tbaa !24
  store i64 %t89, ptr %l46, !tbaa !24
  %t90 = load i64, ptr %l46, !tbaa !24
  %t91 = icmp sge i64 %t90, 0
  store i1 %t91, ptr %l47, !tbaa !21
  %t92 = load i1, ptr %l47, !tbaa !21
  br i1 %t92, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s4
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l48, !tbaa !29
  %t94 = load ptr, ptr %l48, !tbaa !29
  %t95 = getelementptr %"compiler/cond:Eval", ptr %t94, i32 0, i32 3
  %t96 = load ptr, ptr %t95, !tbaa !29
  store ptr %t96, ptr %l49, !tbaa !29
  %t97 = load ptr, ptr %l49, !tbaa !29
  %t98 = getelementptr %"compiler/cond:Consts", ptr %t97, i32 0, i32 3
  store ptr %t98, ptr %l50, !tbaa !29
  %t99 = load i64, ptr %l5, !tbaa !24
  store i64 %t99, ptr %l51, !tbaa !24
  %t100 = load ptr, ptr %l50, !tbaa !29
  %t101 = load i64, ptr %l51, !tbaa !24
  %t102 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t100, i64 %t101)
  store i1 %t102, ptr %l52
  br label %bb28
bb27:
  br label %bb41
bb28:
  %t103 = load i1, ptr %l52, !tbaa !21
  br i1 %t103, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l53, !tbaa !21
  br label %bb32
bb30:
  %t104 = load ptr, ptr %l0, !tbaa !29
  store ptr %t104, ptr %l54, !tbaa !29
  %t105 = load ptr, ptr %l54, !tbaa !29
  %t106 = getelementptr %"compiler/cond:Eval", ptr %t105, i32 0, i32 3
  %t107 = load ptr, ptr %t106, !tbaa !29
  store ptr %t107, ptr %l55, !tbaa !29
  %t108 = load ptr, ptr %l55, !tbaa !29
  %t109 = getelementptr %"compiler/cond:Consts", ptr %t108, i32 0, i32 4
  store ptr %t109, ptr %l56, !tbaa !29
  %t110 = load i64, ptr %l5, !tbaa !24
  store i64 %t110, ptr %l57, !tbaa !24
  %t111 = load ptr, ptr %l56, !tbaa !29
  %t112 = load i64, ptr %l57, !tbaa !24
  %t113 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t111, i64 %t112)
  store i1 %t113, ptr %l58
  br label %bb31
bb31:
  %t114 = load i1, ptr %l58, !tbaa !21
  %t115 = xor i1 %t114, true
  store i1 %t115, ptr %l59, !tbaa !21
  %t116 = load i1, ptr %l59, !tbaa !21
  store i1 %t116, ptr %l53, !tbaa !21
  br label %bb32
bb32:
  %t117 = load i1, ptr %l53, !tbaa !21
  br i1 %t117, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s5
  %t118 = load ptr, ptr %l0, !tbaa !29
  store ptr %t118, ptr %l60, !tbaa !29
  %t119 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t119, ptr %l61
  %t120 = load ptr, ptr %l60, !tbaa !29
  %t121 = load %"compiler/source:Span", ptr %l61
  %t122 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t120, %"compiler/source:Span" %t121)
  store %"compiler/cond:Value" %t122, ptr %l62
  br label %bb35
bb34:
  br label %bb36
bb35:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t123 = load %"compiler/cond:Value", ptr %l62
  store %"compiler/cond:Value" %t123, ptr %rv
  br label %ret
bb36:
  %t124 = load ptr, ptr %l0, !tbaa !29
  store ptr %t124, ptr %l63, !tbaa !29
  %t125 = load i64, ptr %l5, !tbaa !24
  store i64 %t125, ptr %l64, !tbaa !24
  %t126 = load ptr, ptr %l63, !tbaa !29
  %t127 = load i64, ptr %l64, !tbaa !24
  %t128 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2econstValue(ptr %v0, ptr %t126, i64 %t127)
  store %"compiler/cond:Value" %t128, ptr %l65
  br label %bb37
bb37:
  %t129 = load %"compiler/cond:Value", ptr %l65
  store %"compiler/cond:Value" %t129, ptr %l6
  %t130 = load ptr, ptr %l0, !tbaa !29
  store ptr %t130, ptr %l66, !tbaa !29
  %t131 = load ptr, ptr %l66, !tbaa !29
  %t132 = getelementptr %"compiler/cond:Eval", ptr %t131, i32 0, i32 10
  %t133 = load i64, ptr %t132, !tbaa !24
  store i64 %t133, ptr %l67, !tbaa !24
  %t134 = load i64, ptr %l67, !tbaa !24
  %t135 = icmp eq i64 %t134, 0
  store i1 %t135, ptr %l68, !tbaa !21
  %t136 = load i1, ptr %l68, !tbaa !21
  br i1 %t136, label %bb38, label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s6
  %t137 = load ptr, ptr %l0, !tbaa !29
  store ptr %t137, ptr %l69, !tbaa !29
  %t138 = load ptr, ptr %l69, !tbaa !29
  %t139 = getelementptr %"compiler/cond:Eval", ptr %t138, i32 0, i32 11
  store i1 true, ptr %t139, !tbaa !21
  call void @__olang_scope_close(ptr %s6)
  br label %bb40
bb39:
  br label %bb40
bb40:
  %t140 = load %"compiler/cond:Value", ptr %l6
  store %"compiler/cond:Value" %t140, ptr %l70
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t141 = load %"compiler/cond:Value", ptr %l70
  store %"compiler/cond:Value" %t141, ptr %rv
  br label %ret
bb41:
  %t142 = load ptr, ptr %l0, !tbaa !29
  store ptr %t142, ptr %l71, !tbaa !29
  %t143 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t143, ptr %l72
  %t144 = load ptr, ptr %l71, !tbaa !29
  %t145 = load %"compiler/source:Span", ptr %l72
  %t146 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t144, %"compiler/source:Span" %t145)
  store %"compiler/cond:Value" %t146, ptr %l73
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s0)
  %t147 = load %"compiler/cond:Value", ptr %l73
  store %"compiler/cond:Value" %t147, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cond:Value", ptr %rv
  ret %"compiler/cond:Value" %rr
}

define dso_local %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eruntimeValue(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/msgs:Msg" %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/msgs:Msg"
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i1
  %l7 = alloca %"compiler/cond:Value"
  %l8 = alloca i1
  %l9 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %l12 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca %"compiler/source:Span"
  %l16 = alloca %"compiler/msgs:Msg"
  %l17 = alloca %"compiler/cond:Value"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca %"compiler/cond:Value"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/msgs:Msg" %a2, ptr %l2
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = getelementptr %"compiler/cond:Eval", ptr %t2, i32 0, i32 10
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %l5, !tbaa !24
  %t5 = load i64, ptr %l5, !tbaa !24
  %t6 = icmp sgt i64 %t5, 0
  store i1 %t6, ptr %l6, !tbaa !21
  %t7 = load i1, ptr %l6, !tbaa !21
  br i1 %t7, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = call %"compiler/cond:Value" @compiler_2fcond_2enone()
  store %"compiler/cond:Value" %t8, ptr %l7
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t9 = load %"compiler/cond:Value", ptr %l7
  store %"compiler/cond:Value" %t9, ptr %rv
  br label %ret
bb4:
  %t10 = load i1, ptr %l3, !tbaa !21
  store i1 %t10, ptr %l8, !tbaa !21
  %t11 = load i1, ptr %l8, !tbaa !21
  br i1 %t11, label %bb5, label %bb6
bb5:
  %t12 = load ptr, ptr %l0, !tbaa !29
  store ptr %t12, ptr %l10, !tbaa !29
  %t13 = load ptr, ptr %l10, !tbaa !29
  %t14 = getelementptr %"compiler/cond:Eval", ptr %t13, i32 0, i32 4
  %t15 = load i1, ptr %t14, !tbaa !21
  store i1 %t15, ptr %l11, !tbaa !21
  %t16 = load i1, ptr %l11, !tbaa !21
  %t17 = xor i1 %t16, true
  store i1 %t17, ptr %l12, !tbaa !21
  %t18 = load i1, ptr %l12, !tbaa !21
  store i1 %t18, ptr %l9, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb7
bb7:
  %t19 = load i1, ptr %l9, !tbaa !21
  br i1 %t19, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l13, !tbaa !29
  %t21 = load ptr, ptr %l13, !tbaa !29
  %t22 = getelementptr %"compiler/cond:Eval", ptr %t21, i32 0, i32 6
  store i1 true, ptr %t22, !tbaa !21
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb9:
  br label %bb10
bb10:
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l14, !tbaa !29
  %t24 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t24, ptr %l15
  %t25 = load %"compiler/msgs:Msg", ptr %l2
  store %"compiler/msgs:Msg" %t25, ptr %l16
  %t26 = load ptr, ptr %l14, !tbaa !29
  %t27 = load %"compiler/source:Span", ptr %l15
  %t28 = load %"compiler/msgs:Msg", ptr %l16
  %t29 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2efail(ptr %v0, ptr %v1, ptr %t26, %"compiler/source:Span" %t27, %"compiler/msgs:Msg" %t28)
  store %"compiler/cond:Value" %t29, ptr %l17
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t30 = load %"compiler/cond:Value", ptr %l17
  store %"compiler/cond:Value" %t30, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cond:Value", ptr %rv
  ret %"compiler/cond:Value" %rr
}

define dso_local { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aEval_2etokText(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca i1
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/cond:Eval", ptr %t2, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l3, !tbaa !27
  %t5 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t6 = load i32, ptr %t5, !tbaa !23
  store i32 %t6, ptr %l4, !tbaa !23
  %t7 = load i32, ptr %l4, !tbaa !23
  %t8 = sext i32 %t7 to i64
  store i64 %t8, ptr %l5, !tbaa !24
  %t9 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t10 = load i32, ptr %t9, !tbaa !23
  store i32 %t10, ptr %l6, !tbaa !23
  %t11 = load i32, ptr %l6, !tbaa !23
  %t12 = sext i32 %t11 to i64
  store i64 %t12, ptr %l7, !tbaa !24
  %t13 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t13, 0
  store i64 %t14, ptr %l8, !tbaa !24
  %t15 = load i64, ptr %l5, !tbaa !24
  %t16 = icmp sge i64 %t15, 0
  store i1 %t16, ptr %l9, !tbaa !21
  %t17 = load i1, ptr %l9, !tbaa !21
  br i1 %t17, label %bb1, label %bb2
bb1:
  %t18 = load i64, ptr %l5, !tbaa !24
  %t19 = load i64, ptr %l7, !tbaa !24
  %t20 = icmp sle i64 %t18, %t19
  store i1 %t20, ptr %l10, !tbaa !21
  %t21 = load i1, ptr %l10, !tbaa !21
  br i1 %t21, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @.c42)
  unreachable
bb3:
  %t22 = load i64, ptr %l7, !tbaa !24
  %t23 = load i64, ptr %l8, !tbaa !24
  %t24 = icmp sle i64 %t22, %t23
  store i1 %t24, ptr %l11, !tbaa !21
  %t25 = load i1, ptr %l11, !tbaa !21
  br i1 %t25, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @.c42)
  unreachable
bb5:
  %t26 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = load i64, ptr %l5, !tbaa !24
  %t29 = load i64, ptr %l7, !tbaa !24
  %t30 = getelementptr i8, ptr %t27, i64 %t28
  %t31 = sub i64 %t29, %t28
  %t32 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t30, 1
  store { i64, ptr } %t33, ptr %l12, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t35 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %t34)
  store { i64, ptr } %t35, ptr %l13
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @.c42)
  unreachable
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t36 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t36, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcond_2ecompiler_2fcond_3aEval_2etokenAt(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i1
  %l11 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i8
  %l16 = alloca i1
  %l17 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i8
  %l22 = alloca i1
  %l23 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i8
  %l28 = alloca i1
  %l29 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca i8
  %l34 = alloca i1
  %l35 = alloca i1
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca ptr
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca i1
  %l44 = alloca i1
  %l45 = alloca ptr
  %l46 = alloca { i64, ptr }
  %l47 = alloca i64
  %l48 = alloca i8
  %l49 = alloca i1
  %l50 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca { i64, ptr }
  %l53 = alloca i64
  %l54 = alloca i8
  %l55 = alloca i1
  %l56 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca { i64, ptr }
  %l59 = alloca i64
  %l60 = alloca i8
  %l61 = alloca i1
  %l62 = alloca i64
  %l63 = alloca ptr
  %l64 = alloca { i64, ptr }
  %l65 = alloca i64
  %l66 = alloca i1
  %l67 = alloca i1
  %l68 = alloca ptr
  %l69 = alloca { i64, ptr }
  %l70 = alloca i64
  %l71 = alloca i8
  %l72 = alloca i1
  %l73 = alloca i1
  %l74 = alloca ptr
  %l75 = alloca { i64, ptr }
  %l76 = alloca i64
  %l77 = alloca i8
  %l78 = alloca i1
  %l79 = alloca i1
  %l80 = alloca ptr
  %l81 = alloca { i64, ptr }
  %l82 = alloca i64
  %l83 = alloca i8
  %l84 = alloca i1
  %l85 = alloca i1
  %l86 = alloca i64
  %l87 = alloca i64
  %l88 = alloca i64
  %l89 = alloca ptr
  %l90 = alloca { i64, ptr }
  %l91 = alloca i64
  %l92 = alloca i1
  %l93 = alloca i1
  %l94 = alloca i64
  %l95 = alloca i64
  %l96 = alloca i64
  %l97 = alloca i1
  %l98 = alloca i1
  %l99 = alloca { i64, ptr }
  %l100 = alloca ptr
  %l101 = alloca { i64, ptr }
  %l102 = alloca i64
  %l103 = alloca i64
  %l104 = alloca i64
  %l105 = alloca i64
  %l106 = alloca i1
  %l107 = alloca i1
  %l108 = alloca i1
  %l109 = alloca { i64, ptr }
  %l110 = alloca { i64, ptr }
  %l111 = alloca i1
  %l112 = alloca i1
  %l113 = alloca i64
  %l114 = alloca i64
  %l115 = alloca i64
  %l116 = alloca i64
  %l117 = alloca i1
  %l118 = alloca i64
  %l119 = alloca i64
  %l120 = alloca i64
  %l121 = alloca i32
  %l122 = alloca i64
  %l123 = alloca i32
  %l124 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l1, !tbaa !23
  store i32 %t1, ptr %l4, !tbaa !23
  %t2 = load i32, ptr %l4, !tbaa !23
  %t3 = sext i32 %t2 to i64
  store i64 %t3, ptr %l5, !tbaa !24
  %t4 = load i64, ptr %l5, !tbaa !24
  store i64 %t4, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = load i64, ptr %l2, !tbaa !24
  store i64 %t5, ptr %l6, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l7, !tbaa !29
  %t7 = load ptr, ptr %l7, !tbaa !29
  %t8 = getelementptr %"compiler/cond:Eval", ptr %t7, i32 0, i32 0
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  store { i64, ptr } %t9, ptr %l8, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t10, 0
  store i64 %t11, ptr %l9, !tbaa !24
  %t12 = load i64, ptr %l6, !tbaa !24
  %t13 = load i64, ptr %l9, !tbaa !24
  %t14 = icmp slt i64 %t12, %t13
  store i1 %t14, ptr %l10, !tbaa !21
  %t15 = load i1, ptr %l10, !tbaa !21
  br i1 %t15, label %bb2, label %bb3
bb2:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l12, !tbaa !29
  %t17 = load ptr, ptr %l12, !tbaa !29
  %t18 = getelementptr %"compiler/cond:Eval", ptr %t17, i32 0, i32 0
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !27
  store { i64, ptr } %t19, ptr %l13, !tbaa !27
  %t20 = load i64, ptr %l2, !tbaa !24
  store i64 %t20, ptr %l14, !tbaa !24
  %t21 = load i64, ptr %l14, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i8, ptr %t23, i64 %t21
  %t25 = load i8, ptr %t24, !tbaa !32
  store i8 %t25, ptr %l15, !tbaa !22
  %t26 = load i8, ptr %l15, !tbaa !22
  %t27 = icmp eq i8 %t26, 32
  store i1 %t27, ptr %l16, !tbaa !21
  %t28 = load i1, ptr %l16, !tbaa !21
  br i1 %t28, label %bb4, label %bb5
bb3:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb13
bb4:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb6
bb5:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l18, !tbaa !29
  %t30 = load ptr, ptr %l18, !tbaa !29
  %t31 = getelementptr %"compiler/cond:Eval", ptr %t30, i32 0, i32 0
  %t32 = load { i64, ptr }, ptr %t31, !tbaa !27
  store { i64, ptr } %t32, ptr %l19, !tbaa !27
  %t33 = load i64, ptr %l2, !tbaa !24
  store i64 %t33, ptr %l20, !tbaa !24
  %t34 = load i64, ptr %l20, !tbaa !24
  %t35 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr i8, ptr %t36, i64 %t34
  %t38 = load i8, ptr %t37, !tbaa !32
  store i8 %t38, ptr %l21, !tbaa !22
  %t39 = load i8, ptr %l21, !tbaa !22
  %t40 = icmp eq i8 %t39, 9
  store i1 %t40, ptr %l22, !tbaa !21
  %t41 = load i1, ptr %l22, !tbaa !21
  store i1 %t41, ptr %l17, !tbaa !21
  br label %bb6
bb6:
  %t42 = load i1, ptr %l17, !tbaa !21
  br i1 %t42, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb9
bb8:
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l24, !tbaa !29
  %t44 = load ptr, ptr %l24, !tbaa !29
  %t45 = getelementptr %"compiler/cond:Eval", ptr %t44, i32 0, i32 0
  %t46 = load { i64, ptr }, ptr %t45, !tbaa !27
  store { i64, ptr } %t46, ptr %l25, !tbaa !27
  %t47 = load i64, ptr %l2, !tbaa !24
  store i64 %t47, ptr %l26, !tbaa !24
  %t48 = load i64, ptr %l26, !tbaa !24
  %t49 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr i8, ptr %t50, i64 %t48
  %t52 = load i8, ptr %t51, !tbaa !32
  store i8 %t52, ptr %l27, !tbaa !22
  %t53 = load i8, ptr %l27, !tbaa !22
  %t54 = icmp eq i8 %t53, 10
  store i1 %t54, ptr %l28, !tbaa !21
  %t55 = load i1, ptr %l28, !tbaa !21
  store i1 %t55, ptr %l23, !tbaa !21
  br label %bb9
bb9:
  %t56 = load i1, ptr %l23, !tbaa !21
  br i1 %t56, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb12
bb11:
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l30, !tbaa !29
  %t58 = load ptr, ptr %l30, !tbaa !29
  %t59 = getelementptr %"compiler/cond:Eval", ptr %t58, i32 0, i32 0
  %t60 = load { i64, ptr }, ptr %t59, !tbaa !27
  store { i64, ptr } %t60, ptr %l31, !tbaa !27
  %t61 = load i64, ptr %l2, !tbaa !24
  store i64 %t61, ptr %l32, !tbaa !24
  %t62 = load i64, ptr %l32, !tbaa !24
  %t63 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr i8, ptr %t64, i64 %t62
  %t66 = load i8, ptr %t65, !tbaa !32
  store i8 %t66, ptr %l33, !tbaa !22
  %t67 = load i8, ptr %l33, !tbaa !22
  %t68 = icmp eq i8 %t67, 40
  store i1 %t68, ptr %l34, !tbaa !21
  %t69 = load i1, ptr %l34, !tbaa !21
  store i1 %t69, ptr %l29, !tbaa !21
  br label %bb12
bb12:
  %t70 = load i1, ptr %l29, !tbaa !21
  store i1 %t70, ptr %l11, !tbaa !21
  br label %bb13
bb13:
  %t71 = load i1, ptr %l11, !tbaa !21
  %t72 = xor i1 %t71, true
  store i1 %t72, ptr %l35, !tbaa !21
  %t73 = load i1, ptr %l35, !tbaa !21
  br i1 %t73, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s1)
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t74 = load i64, ptr %l2, !tbaa !24
  store i64 %t74, ptr %l36, !tbaa !24
  %t75 = load i64, ptr %l36, !tbaa !24
  %t76 = add i64 %t75, 1
  store i64 %t76, ptr %l37, !tbaa !24
  %t77 = load i64, ptr %l37, !tbaa !24
  store i64 %t77, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb17
bb17:
  br label %bb1
bb18:
  %t78 = load i64, ptr %l2, !tbaa !24
  store i64 %t78, ptr %l38, !tbaa !24
  %t79 = load i64, ptr %l38, !tbaa !24
  store i64 %t79, ptr %l3, !tbaa !24
  %t80 = load i64, ptr %l3, !tbaa !24
  store i64 %t80, ptr %l39, !tbaa !24
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l40, !tbaa !29
  %t82 = load ptr, ptr %l40, !tbaa !29
  %t83 = getelementptr %"compiler/cond:Eval", ptr %t82, i32 0, i32 0
  %t84 = load { i64, ptr }, ptr %t83, !tbaa !27
  store { i64, ptr } %t84, ptr %l41, !tbaa !27
  %t85 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t85, 0
  store i64 %t86, ptr %l42, !tbaa !24
  %t87 = load i64, ptr %l39, !tbaa !24
  %t88 = load i64, ptr %l42, !tbaa !24
  %t89 = icmp slt i64 %t87, %t88
  store i1 %t89, ptr %l43, !tbaa !21
  %t90 = load i1, ptr %l43, !tbaa !21
  br i1 %t90, label %bb19, label %bb20
bb19:
  %t91 = load ptr, ptr %l0, !tbaa !29
  store ptr %t91, ptr %l45, !tbaa !29
  %t92 = load ptr, ptr %l45, !tbaa !29
  %t93 = getelementptr %"compiler/cond:Eval", ptr %t92, i32 0, i32 0
  %t94 = load { i64, ptr }, ptr %t93, !tbaa !27
  store { i64, ptr } %t94, ptr %l46, !tbaa !27
  %t95 = load i64, ptr %l3, !tbaa !24
  store i64 %t95, ptr %l47, !tbaa !24
  %t96 = load i64, ptr %l47, !tbaa !24
  %t97 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = getelementptr i8, ptr %t98, i64 %t96
  %t100 = load i8, ptr %t99, !tbaa !32
  store i8 %t100, ptr %l48, !tbaa !22
  %t101 = load i8, ptr %l48, !tbaa !22
  %t102 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t101)
  store i1 %t102, ptr %l49
  br label %bb21
bb20:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb29
bb21:
  %t103 = load i1, ptr %l49, !tbaa !21
  br i1 %t103, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb25
bb23:
  %t104 = load ptr, ptr %l0, !tbaa !29
  store ptr %t104, ptr %l51, !tbaa !29
  %t105 = load ptr, ptr %l51, !tbaa !29
  %t106 = getelementptr %"compiler/cond:Eval", ptr %t105, i32 0, i32 0
  %t107 = load { i64, ptr }, ptr %t106, !tbaa !27
  store { i64, ptr } %t107, ptr %l52, !tbaa !27
  %t108 = load i64, ptr %l3, !tbaa !24
  store i64 %t108, ptr %l53, !tbaa !24
  %t109 = load i64, ptr %l53, !tbaa !24
  %t110 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr i8, ptr %t111, i64 %t109
  %t113 = load i8, ptr %t112, !tbaa !32
  store i8 %t113, ptr %l54, !tbaa !22
  %t114 = load i8, ptr %l54, !tbaa !22
  %t115 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t114)
  store i1 %t115, ptr %l55
  br label %bb24
bb24:
  %t116 = load i1, ptr %l55, !tbaa !21
  store i1 %t116, ptr %l50, !tbaa !21
  br label %bb25
bb25:
  %t117 = load i1, ptr %l50, !tbaa !21
  br i1 %t117, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l56, !tbaa !21
  br label %bb28
bb27:
  %t118 = load ptr, ptr %l0, !tbaa !29
  store ptr %t118, ptr %l57, !tbaa !29
  %t119 = load ptr, ptr %l57, !tbaa !29
  %t120 = getelementptr %"compiler/cond:Eval", ptr %t119, i32 0, i32 0
  %t121 = load { i64, ptr }, ptr %t120, !tbaa !27
  store { i64, ptr } %t121, ptr %l58, !tbaa !27
  %t122 = load i64, ptr %l3, !tbaa !24
  store i64 %t122, ptr %l59, !tbaa !24
  %t123 = load i64, ptr %l59, !tbaa !24
  %t124 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr i8, ptr %t125, i64 %t123
  %t127 = load i8, ptr %t126, !tbaa !32
  store i8 %t127, ptr %l60, !tbaa !22
  %t128 = load i8, ptr %l60, !tbaa !22
  %t129 = icmp eq i8 %t128, 95
  store i1 %t129, ptr %l61, !tbaa !21
  %t130 = load i1, ptr %l61, !tbaa !21
  store i1 %t130, ptr %l56, !tbaa !21
  br label %bb28
bb28:
  %t131 = load i1, ptr %l56, !tbaa !21
  store i1 %t131, ptr %l44, !tbaa !21
  br label %bb29
bb29:
  %t132 = load i1, ptr %l44, !tbaa !21
  br i1 %t132, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s2
  br label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s4
  br label %bb49
bb32:
  store %olang.scope zeroinitializer, ptr %s3
  %t133 = load i64, ptr %l3, !tbaa !24
  store i64 %t133, ptr %l62, !tbaa !24
  %t134 = load ptr, ptr %l0, !tbaa !29
  store ptr %t134, ptr %l63, !tbaa !29
  %t135 = load ptr, ptr %l63, !tbaa !29
  %t136 = getelementptr %"compiler/cond:Eval", ptr %t135, i32 0, i32 0
  %t137 = load { i64, ptr }, ptr %t136, !tbaa !27
  store { i64, ptr } %t137, ptr %l64, !tbaa !27
  %t138 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t139 = extractvalue { i64, ptr } %t138, 0
  store i64 %t139, ptr %l65, !tbaa !24
  %t140 = load i64, ptr %l62, !tbaa !24
  %t141 = load i64, ptr %l65, !tbaa !24
  %t142 = icmp slt i64 %t140, %t141
  store i1 %t142, ptr %l66, !tbaa !21
  %t143 = load i1, ptr %l66, !tbaa !21
  br i1 %t143, label %bb33, label %bb34
bb33:
  %t144 = load ptr, ptr %l0, !tbaa !29
  store ptr %t144, ptr %l68, !tbaa !29
  %t145 = load ptr, ptr %l68, !tbaa !29
  %t146 = getelementptr %"compiler/cond:Eval", ptr %t145, i32 0, i32 0
  %t147 = load { i64, ptr }, ptr %t146, !tbaa !27
  store { i64, ptr } %t147, ptr %l69, !tbaa !27
  %t148 = load i64, ptr %l3, !tbaa !24
  store i64 %t148, ptr %l70, !tbaa !24
  %t149 = load i64, ptr %l70, !tbaa !24
  %t150 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !27
  %t152 = getelementptr i8, ptr %t151, i64 %t149
  %t153 = load i8, ptr %t152, !tbaa !32
  store i8 %t153, ptr %l71, !tbaa !22
  %t154 = load i8, ptr %l71, !tbaa !22
  %t155 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t154)
  store i1 %t155, ptr %l72
  br label %bb35
bb34:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb43
bb35:
  %t156 = load i1, ptr %l72, !tbaa !21
  br i1 %t156, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l73, !tbaa !21
  br label %bb39
bb37:
  %t157 = load ptr, ptr %l0, !tbaa !29
  store ptr %t157, ptr %l74, !tbaa !29
  %t158 = load ptr, ptr %l74, !tbaa !29
  %t159 = getelementptr %"compiler/cond:Eval", ptr %t158, i32 0, i32 0
  %t160 = load { i64, ptr }, ptr %t159, !tbaa !27
  store { i64, ptr } %t160, ptr %l75, !tbaa !27
  %t161 = load i64, ptr %l3, !tbaa !24
  store i64 %t161, ptr %l76, !tbaa !24
  %t162 = load i64, ptr %l76, !tbaa !24
  %t163 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t164 = load ptr, ptr %t163, !tbaa !27
  %t165 = getelementptr i8, ptr %t164, i64 %t162
  %t166 = load i8, ptr %t165, !tbaa !32
  store i8 %t166, ptr %l77, !tbaa !22
  %t167 = load i8, ptr %l77, !tbaa !22
  %t168 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t167)
  store i1 %t168, ptr %l78
  br label %bb38
bb38:
  %t169 = load i1, ptr %l78, !tbaa !21
  store i1 %t169, ptr %l73, !tbaa !21
  br label %bb39
bb39:
  %t170 = load i1, ptr %l73, !tbaa !21
  br i1 %t170, label %bb40, label %bb41
bb40:
  store i1 true, ptr %l79, !tbaa !21
  br label %bb42
bb41:
  %t171 = load ptr, ptr %l0, !tbaa !29
  store ptr %t171, ptr %l80, !tbaa !29
  %t172 = load ptr, ptr %l80, !tbaa !29
  %t173 = getelementptr %"compiler/cond:Eval", ptr %t172, i32 0, i32 0
  %t174 = load { i64, ptr }, ptr %t173, !tbaa !27
  store { i64, ptr } %t174, ptr %l81, !tbaa !27
  %t175 = load i64, ptr %l3, !tbaa !24
  store i64 %t175, ptr %l82, !tbaa !24
  %t176 = load i64, ptr %l82, !tbaa !24
  %t177 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !27
  %t179 = getelementptr i8, ptr %t178, i64 %t176
  %t180 = load i8, ptr %t179, !tbaa !32
  store i8 %t180, ptr %l83, !tbaa !22
  %t181 = load i8, ptr %l83, !tbaa !22
  %t182 = icmp eq i8 %t181, 95
  store i1 %t182, ptr %l84, !tbaa !21
  %t183 = load i1, ptr %l84, !tbaa !21
  store i1 %t183, ptr %l79, !tbaa !21
  br label %bb42
bb42:
  %t184 = load i1, ptr %l79, !tbaa !21
  store i1 %t184, ptr %l67, !tbaa !21
  br label %bb43
bb43:
  %t185 = load i1, ptr %l67, !tbaa !21
  %t186 = xor i1 %t185, true
  store i1 %t186, ptr %l85, !tbaa !21
  %t187 = load i1, ptr %l85, !tbaa !21
  br i1 %t187, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s3)
  br label %bb48
bb45:
  br label %bb46
bb46:
  %t188 = load i64, ptr %l3, !tbaa !24
  store i64 %t188, ptr %l86, !tbaa !24
  %t189 = load i64, ptr %l86, !tbaa !24
  %t190 = add i64 %t189, 1
  store i64 %t190, ptr %l87, !tbaa !24
  %t191 = load i64, ptr %l87, !tbaa !24
  store i64 %t191, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb47
bb47:
  br label %bb32
bb48:
  call void @__olang_scope_close(ptr %s2)
  br label %bb71
bb49:
  store %olang.scope zeroinitializer, ptr %s5
  %t192 = load i64, ptr %l3, !tbaa !24
  store i64 %t192, ptr %l88, !tbaa !24
  %t193 = load ptr, ptr %l0, !tbaa !29
  store ptr %t193, ptr %l89, !tbaa !29
  %t194 = load ptr, ptr %l89, !tbaa !29
  %t195 = getelementptr %"compiler/cond:Eval", ptr %t194, i32 0, i32 0
  %t196 = load { i64, ptr }, ptr %t195, !tbaa !27
  store { i64, ptr } %t196, ptr %l90, !tbaa !27
  %t197 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t198 = extractvalue { i64, ptr } %t197, 0
  store i64 %t198, ptr %l91, !tbaa !24
  %t199 = load i64, ptr %l88, !tbaa !24
  %t200 = load i64, ptr %l91, !tbaa !24
  %t201 = icmp slt i64 %t199, %t200
  store i1 %t201, ptr %l92, !tbaa !21
  %t202 = load i1, ptr %l92, !tbaa !21
  br i1 %t202, label %bb50, label %bb51
bb50:
  %t203 = load i64, ptr %l3, !tbaa !24
  store i64 %t203, ptr %l94, !tbaa !24
  %t204 = load i64, ptr %l2, !tbaa !24
  store i64 %t204, ptr %l95, !tbaa !24
  %t205 = load i64, ptr %l95, !tbaa !24
  %t206 = add i64 %t205, 2
  store i64 %t206, ptr %l96, !tbaa !24
  %t207 = load i64, ptr %l94, !tbaa !24
  %t208 = load i64, ptr %l96, !tbaa !24
  %t209 = icmp slt i64 %t207, %t208
  store i1 %t209, ptr %l97, !tbaa !21
  %t210 = load i1, ptr %l97, !tbaa !21
  store i1 %t210, ptr %l93, !tbaa !21
  br label %bb52
bb51:
  store i1 false, ptr %l93, !tbaa !21
  br label %bb52
bb52:
  %t211 = load i1, ptr %l93, !tbaa !21
  br i1 %t211, label %bb53, label %bb54
bb53:
  store { i64, ptr } { i64 9, ptr @.d43 }, ptr %l99, !tbaa !27
  %t212 = load ptr, ptr %l0, !tbaa !29
  store ptr %t212, ptr %l100, !tbaa !29
  %t213 = load ptr, ptr %l100, !tbaa !29
  %t214 = getelementptr %"compiler/cond:Eval", ptr %t213, i32 0, i32 0
  %t215 = load { i64, ptr }, ptr %t214, !tbaa !27
  store { i64, ptr } %t215, ptr %l101, !tbaa !27
  %t216 = load i64, ptr %l3, !tbaa !24
  store i64 %t216, ptr %l102, !tbaa !24
  %t217 = load i64, ptr %l3, !tbaa !24
  store i64 %t217, ptr %l103, !tbaa !24
  %t218 = load i64, ptr %l103, !tbaa !24
  %t219 = add i64 %t218, 1
  store i64 %t219, ptr %l104, !tbaa !24
  %t220 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t221 = extractvalue { i64, ptr } %t220, 0
  store i64 %t221, ptr %l105, !tbaa !24
  %t222 = load i64, ptr %l102, !tbaa !24
  %t223 = icmp sge i64 %t222, 0
  store i1 %t223, ptr %l106, !tbaa !21
  %t224 = load i1, ptr %l106, !tbaa !21
  br i1 %t224, label %bb55, label %bb56
bb54:
  store i1 false, ptr %l98, !tbaa !21
  br label %bb62
bb55:
  %t225 = load i64, ptr %l102, !tbaa !24
  %t226 = load i64, ptr %l104, !tbaa !24
  %t227 = icmp sle i64 %t225, %t226
  store i1 %t227, ptr %l107, !tbaa !21
  %t228 = load i1, ptr %l107, !tbaa !21
  br i1 %t228, label %bb57, label %bb58
bb56:
  call void @__olang_check_failed(ptr @.c44)
  unreachable
bb57:
  %t229 = load i64, ptr %l104, !tbaa !24
  %t230 = load i64, ptr %l105, !tbaa !24
  %t231 = icmp sle i64 %t229, %t230
  store i1 %t231, ptr %l108, !tbaa !21
  %t232 = load i1, ptr %l108, !tbaa !21
  br i1 %t232, label %bb59, label %bb60
bb58:
  call void @__olang_check_failed(ptr @.c44)
  unreachable
bb59:
  %t233 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t234 = load ptr, ptr %t233, !tbaa !27
  %t235 = load i64, ptr %l102, !tbaa !24
  %t236 = load i64, ptr %l104, !tbaa !24
  %t237 = getelementptr i8, ptr %t234, i64 %t235
  %t238 = sub i64 %t236, %t235
  %t239 = insertvalue { i64, ptr } undef, i64 %t238, 0
  %t240 = insertvalue { i64, ptr } %t239, ptr %t237, 1
  store { i64, ptr } %t240, ptr %l109, !tbaa !27
  %t241 = load { i64, ptr }, ptr %l109, !tbaa !27
  store { i64, ptr } %t241, ptr %l110, !tbaa !27
  %t242 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t243 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t244 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %s5, ptr %v0, { i64, ptr } %t242, { i64, ptr } %t243)
  store i1 %t244, ptr %l111
  br label %bb61
bb60:
  call void @__olang_check_failed(ptr @.c44)
  unreachable
bb61:
  %t245 = load i1, ptr %l111, !tbaa !21
  store i1 %t245, ptr %l98, !tbaa !21
  br label %bb62
bb62:
  %t246 = load i1, ptr %l98, !tbaa !21
  %t247 = xor i1 %t246, true
  store i1 %t247, ptr %l112, !tbaa !21
  %t248 = load i1, ptr %l112, !tbaa !21
  br i1 %t248, label %bb63, label %bb64
bb63:
  call void @__olang_scope_close(ptr %s5)
  br label %bb67
bb64:
  br label %bb65
bb65:
  %t249 = load i64, ptr %l3, !tbaa !24
  store i64 %t249, ptr %l113, !tbaa !24
  %t250 = load i64, ptr %l113, !tbaa !24
  %t251 = add i64 %t250, 1
  store i64 %t251, ptr %l114, !tbaa !24
  %t252 = load i64, ptr %l114, !tbaa !24
  store i64 %t252, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb66
bb66:
  br label %bb49
bb67:
  %t253 = load i64, ptr %l3, !tbaa !24
  store i64 %t253, ptr %l115, !tbaa !24
  %t254 = load i64, ptr %l2, !tbaa !24
  store i64 %t254, ptr %l116, !tbaa !24
  %t255 = load i64, ptr %l115, !tbaa !24
  %t256 = load i64, ptr %l116, !tbaa !24
  %t257 = icmp eq i64 %t255, %t256
  store i1 %t257, ptr %l117, !tbaa !21
  %t258 = load i1, ptr %l117, !tbaa !21
  br i1 %t258, label %bb68, label %bb69
bb68:
  store %olang.scope zeroinitializer, ptr %s6
  %t259 = load i64, ptr %l2, !tbaa !24
  store i64 %t259, ptr %l118, !tbaa !24
  %t260 = load i64, ptr %l118, !tbaa !24
  %t261 = add i64 %t260, 1
  store i64 %t261, ptr %l119, !tbaa !24
  %t262 = load i64, ptr %l119, !tbaa !24
  store i64 %t262, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb70
bb69:
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s4)
  br label %bb71
bb71:
  %t263 = load i64, ptr %l2, !tbaa !24
  store i64 %t263, ptr %l120, !tbaa !24
  %t264 = load i64, ptr %l120, !tbaa !24
  %t265 = trunc i64 %t264 to i32
  store i32 %t265, ptr %l121, !tbaa !23
  %t266 = load i64, ptr %l3, !tbaa !24
  store i64 %t266, ptr %l122, !tbaa !24
  %t267 = load i64, ptr %l122, !tbaa !24
  %t268 = trunc i64 %t267 to i32
  store i32 %t268, ptr %l123, !tbaa !23
  %t269 = load i32, ptr %l121, !tbaa !23
  %t270 = load i32, ptr %l123, !tbaa !23
  %t271 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t269, i32 %t270)
  store %"compiler/source:Span" %t271, ptr %l124
  br label %bb72
bb72:
  call void @__olang_scope_close(ptr %s0)
  %t272 = load %"compiler/source:Span", ptr %l124
  store %"compiler/source:Span" %t272, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eunary(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca %"compiler/cond:Value"
  %l6 = alloca %"compiler/cond:Value"
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca ptr
  %l13 = alloca i1
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca %"compiler/source:Span"
  %l17 = alloca i32
  %l18 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca ptr
  %l21 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca %"compiler/cond:Value"
  %l25 = alloca i32
  %l26 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca ptr
  %l29 = alloca i1
  %l30 = alloca %"compiler/cond:Value"
  %l31 = alloca i32
  %l32 = alloca ptr
  %l33 = alloca i32
  %l34 = alloca ptr
  %l35 = alloca i1
  %l36 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca %"compiler/source:Span"
  %l39 = alloca ptr
  %l40 = alloca %"compiler/source:Span"
  %l41 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l43 = alloca %"compiler/msgs:Msg"
  %l44 = alloca %"compiler/cond:Value"
  %l45 = alloca i64
  %l46 = alloca i1
  %l47 = alloca %"compiler/cond:Value"
  %l48 = alloca i32
  %l49 = alloca ptr
  %l50 = alloca i32
  %l51 = alloca ptr
  %l52 = alloca i1
  %l53 = alloca i1
  %l54 = alloca ptr
  %l55 = alloca %"compiler/source:Span"
  %l56 = alloca %"compiler/cond:Value"
  %l57 = alloca ptr
  %l58 = alloca ptr
  %l59 = alloca %"compiler/cond:Value"
  %l60 = alloca i32
  %l61 = alloca ptr
  %l62 = alloca i32
  %l63 = alloca ptr
  %l64 = alloca i1
  %l65 = alloca %"compiler/cond:Value"
  %l66 = alloca i32
  %l67 = alloca ptr
  %l68 = alloca i32
  %l69 = alloca ptr
  %l70 = alloca i1
  %l71 = alloca i32
  %l72 = alloca double
  %l73 = alloca double
  %l74 = alloca i64
  %l75 = alloca %"compiler/cond:Value"
  %l76 = alloca i32
  %l77 = alloca ptr
  %l78 = alloca i32
  %l79 = alloca ptr
  %l80 = alloca i1
  %l81 = alloca i1
  %l82 = alloca ptr
  %l83 = alloca %"compiler/source:Span"
  %l84 = alloca ptr
  %l85 = alloca %"compiler/source:Span"
  %l86 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %l88 = alloca %"compiler/msgs:Msg"
  %l89 = alloca %"compiler/cond:Value"
  %l90 = alloca i64
  %l91 = alloca i1
  %l92 = alloca i1
  %l93 = alloca i64
  %l94 = alloca i64
  %l95 = alloca i64
  %l96 = alloca i1
  %l97 = alloca i1
  %l98 = alloca i1
  %l99 = alloca ptr
  %l100 = alloca %"compiler/source:Span"
  %l101 = alloca %"compiler/cond:Value"
  %l102 = alloca i32
  %l103 = alloca i64
  %l104 = alloca i64
  %l105 = alloca i64
  %l106 = alloca i1
  %l107 = alloca %"compiler/cond:Value"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca %"compiler/cond:Value"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t2 = load i32, ptr %t1, !tbaa !23
  store i32 %t2, ptr %l7, !tbaa !23
  %t3 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t4 = load i32, ptr %t3, !tbaa !23
  store i32 %t4, ptr %l8, !tbaa !23
  %t5 = load i32, ptr %l2
  store i32 %t5, ptr %l9
  store ptr %l9, ptr %l10, !tbaa !29
  store i32 50, ptr %l11
  store ptr %l11, ptr %l12, !tbaa !29
  %t6 = load ptr, ptr %l10, !tbaa !29
  %t7 = load ptr, ptr %l12, !tbaa !29
  %t8 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t6, ptr %t7)
  store i1 %t8, ptr %l13
  br label %bb1
bb1:
  %t9 = load i1, ptr %l13, !tbaa !21
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i32 3, ptr %l14, !tbaa !23
  br label %bb4
bb3:
  store i32 1, ptr %l14, !tbaa !23
  br label %bb4
bb4:
  %t10 = load i32, ptr %l8, !tbaa !23
  %t11 = load i32, ptr %l14, !tbaa !23
  %t12 = add i32 %t10, %t11
  store i32 %t12, ptr %l15, !tbaa !23
  %t13 = load i32, ptr %l7, !tbaa !23
  %t14 = load i32, ptr %l15, !tbaa !23
  %t15 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t13, i32 %t14)
  store %"compiler/source:Span" %t15, ptr %l16
  br label %bb5
bb5:
  %t16 = load %"compiler/source:Span", ptr %l16
  store %"compiler/source:Span" %t16, ptr %l4
  %t17 = load i32, ptr %l2
  store i32 %t17, ptr %l17
  store ptr %l17, ptr %l18, !tbaa !29
  store i32 50, ptr %l19
  store ptr %l19, ptr %l20, !tbaa !29
  %t18 = load ptr, ptr %l18, !tbaa !29
  %t19 = load ptr, ptr %l20, !tbaa !29
  %t20 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t18, ptr %t19)
  store i1 %t20, ptr %l21
  br label %bb6
bb6:
  %t21 = load i1, ptr %l21, !tbaa !21
  br i1 %t21, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l22, !tbaa !29
  %t23 = load ptr, ptr %l3, !tbaa !29
  store ptr %t23, ptr %l23, !tbaa !29
  %t24 = load ptr, ptr %l22, !tbaa !29
  %t25 = load ptr, ptr %l23, !tbaa !29
  %t26 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eexpr(ptr %v0, ptr %v1, ptr %t24, ptr %t25)
  store %"compiler/cond:Value" %t26, ptr %l24
  br label %bb9
bb8:
  br label %bb22
bb9:
  %t27 = load %"compiler/cond:Value", ptr %l24
  store %"compiler/cond:Value" %t27, ptr %l5
  %t28 = getelementptr %"compiler/cond:Value", ptr %l5, i32 0, i32 0
  %t29 = load i32, ptr %t28
  store i32 %t29, ptr %l25
  store ptr %l25, ptr %l26, !tbaa !29
  store i32 0, ptr %l27
  store ptr %l27, ptr %l28, !tbaa !29
  %t30 = load ptr, ptr %l26, !tbaa !29
  %t31 = load ptr, ptr %l28, !tbaa !29
  %t32 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %t30, ptr %t31)
  store i1 %t32, ptr %l29
  br label %bb10
bb10:
  %t33 = load i1, ptr %l29, !tbaa !21
  br i1 %t33, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t34 = load %"compiler/cond:Value", ptr %l5
  store %"compiler/cond:Value" %t34, ptr %l30
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t35 = load %"compiler/cond:Value", ptr %l30
  store %"compiler/cond:Value" %t35, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t36 = getelementptr %"compiler/cond:Value", ptr %l5, i32 0, i32 0
  %t37 = load i32, ptr %t36
  store i32 %t37, ptr %l31
  store ptr %l31, ptr %l32, !tbaa !29
  store i32 1, ptr %l33
  store ptr %l33, ptr %l34, !tbaa !29
  %t38 = load ptr, ptr %l32, !tbaa !29
  %t39 = load ptr, ptr %l34, !tbaa !29
  %t40 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %t38, ptr %t39)
  store i1 %t40, ptr %l35
  br label %bb14
bb14:
  %t41 = load i1, ptr %l35, !tbaa !21
  %t42 = xor i1 %t41, true
  store i1 %t42, ptr %l36, !tbaa !21
  %t43 = load i1, ptr %l36, !tbaa !21
  br i1 %t43, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l37, !tbaa !29
  %t45 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t45, ptr %l38
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l39, !tbaa !29
  %t47 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t47, ptr %l40
  %t48 = load ptr, ptr %l39, !tbaa !29
  %t49 = load %"compiler/source:Span", ptr %l40
  %t50 = call { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aEval_2etokText(ptr %v0, ptr %v0, ptr %t48, %"compiler/source:Span" %t49)
  store { i64, ptr } %t50, ptr %l41
  br label %bb17
bb16:
  br label %bb20
bb17:
  %t51 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t51, 0
  %t53 = extractvalue { i64, ptr } %t51, 1
  %t54 = mul i64 %t52, 1
  %t55 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t54)
  call void @llvm.memcpy.p0.p0.i64(ptr %t55, ptr %t53, i64 %t54, i1 false)
  %t56 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  store { i64, ptr } %t57, ptr %l42, !tbaa !27
  %t58 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t59 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondTypes(ptr %v0, ptr %v0, { i64, ptr } %t58)
  store %"compiler/msgs:Msg" %t59, ptr %l43
  br label %bb18
bb18:
  %t60 = load ptr, ptr %l37, !tbaa !29
  %t61 = load %"compiler/source:Span", ptr %l38
  %t62 = load %"compiler/msgs:Msg", ptr %l43
  %t63 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2efail(ptr %v0, ptr %v0, ptr %t60, %"compiler/source:Span" %t61, %"compiler/msgs:Msg" %t62)
  store %"compiler/cond:Value" %t63, ptr %l44
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t64 = load %"compiler/cond:Value", ptr %l44
  store %"compiler/cond:Value" %t64, ptr %rv
  br label %ret
bb20:
  %t65 = getelementptr %"compiler/cond:Value", ptr %l5, i32 0, i32 1
  %t66 = load i64, ptr %t65, !tbaa !24
  store i64 %t66, ptr %l45, !tbaa !24
  %t67 = load i64, ptr %l45, !tbaa !24
  %t68 = icmp eq i64 %t67, 0
  store i1 %t68, ptr %l46, !tbaa !21
  %t69 = load i1, ptr %l46, !tbaa !21
  %t70 = call %"compiler/cond:Value" @compiler_2fcond_2eboolValue(i1 %t69)
  store %"compiler/cond:Value" %t70, ptr %l47
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t71 = load %"compiler/cond:Value", ptr %l47
  store %"compiler/cond:Value" %t71, ptr %rv
  br label %ret
bb22:
  %t72 = load i32, ptr %l2
  store i32 %t72, ptr %l48
  store ptr %l48, ptr %l49, !tbaa !29
  store i32 52, ptr %l50
  store ptr %l50, ptr %l51, !tbaa !29
  %t73 = load ptr, ptr %l49, !tbaa !29
  %t74 = load ptr, ptr %l51, !tbaa !29
  %t75 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t73, ptr %t74)
  store i1 %t75, ptr %l52
  br label %bb23
bb23:
  %t76 = load i1, ptr %l52, !tbaa !21
  %t77 = xor i1 %t76, true
  store i1 %t77, ptr %l53, !tbaa !21
  %t78 = load i1, ptr %l53, !tbaa !21
  br i1 %t78, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s4
  %t79 = load ptr, ptr %l0, !tbaa !29
  store ptr %t79, ptr %l54, !tbaa !29
  %t80 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t80, ptr %l55
  %t81 = load ptr, ptr %l54, !tbaa !29
  %t82 = load %"compiler/source:Span", ptr %l55
  %t83 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t81, %"compiler/source:Span" %t82)
  store %"compiler/cond:Value" %t83, ptr %l56
  br label %bb26
bb25:
  br label %bb27
bb26:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t84 = load %"compiler/cond:Value", ptr %l56
  store %"compiler/cond:Value" %t84, ptr %rv
  br label %ret
bb27:
  %t85 = load ptr, ptr %l0, !tbaa !29
  store ptr %t85, ptr %l57, !tbaa !29
  %t86 = load ptr, ptr %l3, !tbaa !29
  store ptr %t86, ptr %l58, !tbaa !29
  %t87 = load ptr, ptr %l57, !tbaa !29
  %t88 = load ptr, ptr %l58, !tbaa !29
  %t89 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eexpr(ptr %v0, ptr %v1, ptr %t87, ptr %t88)
  store %"compiler/cond:Value" %t89, ptr %l59
  br label %bb28
bb28:
  %t90 = load %"compiler/cond:Value", ptr %l59
  store %"compiler/cond:Value" %t90, ptr %l6
  %t91 = getelementptr %"compiler/cond:Value", ptr %l6, i32 0, i32 0
  %t92 = load i32, ptr %t91
  store i32 %t92, ptr %l60
  store ptr %l60, ptr %l61, !tbaa !29
  store i32 0, ptr %l62
  store ptr %l62, ptr %l63, !tbaa !29
  %t93 = load ptr, ptr %l61, !tbaa !29
  %t94 = load ptr, ptr %l63, !tbaa !29
  %t95 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %t93, ptr %t94)
  store i1 %t95, ptr %l64
  br label %bb29
bb29:
  %t96 = load i1, ptr %l64, !tbaa !21
  br i1 %t96, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s5
  %t97 = load %"compiler/cond:Value", ptr %l6
  store %"compiler/cond:Value" %t97, ptr %l65
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t98 = load %"compiler/cond:Value", ptr %l65
  store %"compiler/cond:Value" %t98, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  %t99 = getelementptr %"compiler/cond:Value", ptr %l6, i32 0, i32 0
  %t100 = load i32, ptr %t99
  store i32 %t100, ptr %l66
  store ptr %l66, ptr %l67, !tbaa !29
  store i32 3, ptr %l68
  store ptr %l68, ptr %l69, !tbaa !29
  %t101 = load ptr, ptr %l67, !tbaa !29
  %t102 = load ptr, ptr %l69, !tbaa !29
  %t103 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %t101, ptr %t102)
  store i1 %t103, ptr %l70
  br label %bb33
bb33:
  %t104 = load i1, ptr %l70, !tbaa !21
  br i1 %t104, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s6
  store i32 3, ptr %l71
  %t105 = getelementptr %"compiler/cond:Value", ptr %l6, i32 0, i32 2
  %t106 = load double, ptr %t105, !tbaa !26
  store double %t106, ptr %l72, !tbaa !26
  %t107 = load double, ptr %l72, !tbaa !26
  %t108 = fneg double %t107
  store double %t108, ptr %l73, !tbaa !26
  %t109 = getelementptr %"compiler/cond:Value", ptr %l6, i32 0, i32 4
  %t110 = load i64, ptr %t109, !tbaa !24
  store i64 %t110, ptr %l74, !tbaa !24
  %t111 = load i32, ptr %l71
  %t112 = load double, ptr %l73, !tbaa !26
  %t113 = load i64, ptr %l74, !tbaa !24
  %t114 = call %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %s6, i32 %t111, i64 0, double %t112, i64 0, i64 %t113, i1 false)
  store %"compiler/cond:Value" %t114, ptr %l75
  br label %bb36
bb35:
  br label %bb37
bb36:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t115 = load %"compiler/cond:Value", ptr %l75
  store %"compiler/cond:Value" %t115, ptr %rv
  br label %ret
bb37:
  %t116 = getelementptr %"compiler/cond:Value", ptr %l6, i32 0, i32 0
  %t117 = load i32, ptr %t116
  store i32 %t117, ptr %l76
  store ptr %l76, ptr %l77, !tbaa !29
  store i32 2, ptr %l78
  store ptr %l78, ptr %l79, !tbaa !29
  %t118 = load ptr, ptr %l77, !tbaa !29
  %t119 = load ptr, ptr %l79, !tbaa !29
  %t120 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %t118, ptr %t119)
  store i1 %t120, ptr %l80
  br label %bb38
bb38:
  %t121 = load i1, ptr %l80, !tbaa !21
  %t122 = xor i1 %t121, true
  store i1 %t122, ptr %l81, !tbaa !21
  %t123 = load i1, ptr %l81, !tbaa !21
  br i1 %t123, label %bb39, label %bb40
bb39:
  store %olang.scope zeroinitializer, ptr %s7
  %t124 = load ptr, ptr %l0, !tbaa !29
  store ptr %t124, ptr %l82, !tbaa !29
  %t125 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t125, ptr %l83
  %t126 = load ptr, ptr %l0, !tbaa !29
  store ptr %t126, ptr %l84, !tbaa !29
  %t127 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t127, ptr %l85
  %t128 = load ptr, ptr %l84, !tbaa !29
  %t129 = load %"compiler/source:Span", ptr %l85
  %t130 = call { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aEval_2etokText(ptr %v0, ptr %v0, ptr %t128, %"compiler/source:Span" %t129)
  store { i64, ptr } %t130, ptr %l86
  br label %bb41
bb40:
  br label %bb44
bb41:
  %t131 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t131, 0
  %t133 = extractvalue { i64, ptr } %t131, 1
  %t134 = mul i64 %t132, 1
  %t135 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t134)
  call void @llvm.memcpy.p0.p0.i64(ptr %t135, ptr %t133, i64 %t134, i1 false)
  %t136 = insertvalue { i64, ptr } undef, i64 %t132, 0
  %t137 = insertvalue { i64, ptr } %t136, ptr %t135, 1
  store { i64, ptr } %t137, ptr %l87, !tbaa !27
  %t138 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t139 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondTypes(ptr %v0, ptr %v0, { i64, ptr } %t138)
  store %"compiler/msgs:Msg" %t139, ptr %l88
  br label %bb42
bb42:
  %t140 = load ptr, ptr %l82, !tbaa !29
  %t141 = load %"compiler/source:Span", ptr %l83
  %t142 = load %"compiler/msgs:Msg", ptr %l88
  %t143 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2efail(ptr %v0, ptr %v0, ptr %t140, %"compiler/source:Span" %t141, %"compiler/msgs:Msg" %t142)
  store %"compiler/cond:Value" %t143, ptr %l89
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  %t144 = load %"compiler/cond:Value", ptr %l89
  store %"compiler/cond:Value" %t144, ptr %rv
  br label %ret
bb44:
  %t145 = getelementptr %"compiler/cond:Value", ptr %l6, i32 0, i32 1
  %t146 = load i64, ptr %t145, !tbaa !24
  store i64 %t146, ptr %l90, !tbaa !24
  %t147 = load i64, ptr %l90, !tbaa !24
  %t148 = icmp eq i64 %t147, -9223372036854775808
  store i1 %t148, ptr %l91, !tbaa !21
  %t149 = load i1, ptr %l91, !tbaa !21
  br i1 %t149, label %bb45, label %bb46
bb45:
  store i1 true, ptr %l92, !tbaa !21
  br label %bb48
bb46:
  %t150 = getelementptr %"compiler/cond:Value", ptr %l6, i32 0, i32 1
  %t151 = load i64, ptr %t150, !tbaa !24
  store i64 %t151, ptr %l93, !tbaa !24
  %t152 = load i64, ptr %l93, !tbaa !24
  %t153 = sub i64 0, %t152
  store i64 %t153, ptr %l94, !tbaa !24
  %t154 = getelementptr %"compiler/cond:Value", ptr %l6, i32 0, i32 4
  %t155 = load i64, ptr %t154, !tbaa !24
  store i64 %t155, ptr %l95, !tbaa !24
  %t156 = getelementptr %"compiler/cond:Value", ptr %l6, i32 0, i32 5
  %t157 = load i1, ptr %t156, !tbaa !21
  store i1 %t157, ptr %l96, !tbaa !21
  %t158 = load i64, ptr %l94, !tbaa !24
  %t159 = load i64, ptr %l95, !tbaa !24
  %t160 = load i1, ptr %l96, !tbaa !21
  %t161 = call i1 @compiler_2fcond_2efits(i64 %t158, i64 %t159, i1 %t160)
  store i1 %t161, ptr %l97
  br label %bb47
bb47:
  %t162 = load i1, ptr %l97, !tbaa !21
  %t163 = xor i1 %t162, true
  store i1 %t163, ptr %l98, !tbaa !21
  %t164 = load i1, ptr %l98, !tbaa !21
  store i1 %t164, ptr %l92, !tbaa !21
  br label %bb48
bb48:
  %t165 = load i1, ptr %l92, !tbaa !21
  br i1 %t165, label %bb49, label %bb50
bb49:
  store %olang.scope zeroinitializer, ptr %s8
  %t166 = load ptr, ptr %l0, !tbaa !29
  store ptr %t166, ptr %l99, !tbaa !29
  %t167 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t167, ptr %l100
  %t168 = load ptr, ptr %l99, !tbaa !29
  %t169 = load %"compiler/source:Span", ptr %l100
  %t170 = call %"compiler/cond:Value" @compiler_2fcond_2ecompiler_2fcond_3aEval_2edefer(ptr %v0, ptr %t168, %"compiler/source:Span" %t169)
  store %"compiler/cond:Value" %t170, ptr %l101
  br label %bb51
bb50:
  br label %bb52
bb51:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t171 = load %"compiler/cond:Value", ptr %l101
  store %"compiler/cond:Value" %t171, ptr %rv
  br label %ret
bb52:
  store i32 2, ptr %l102
  %t172 = getelementptr %"compiler/cond:Value", ptr %l6, i32 0, i32 1
  %t173 = load i64, ptr %t172, !tbaa !24
  store i64 %t173, ptr %l103, !tbaa !24
  %t174 = load i64, ptr %l103, !tbaa !24
  %t175 = sub i64 0, %t174
  store i64 %t175, ptr %l104, !tbaa !24
  %t176 = getelementptr %"compiler/cond:Value", ptr %l6, i32 0, i32 4
  %t177 = load i64, ptr %t176, !tbaa !24
  store i64 %t177, ptr %l105, !tbaa !24
  %t178 = getelementptr %"compiler/cond:Value", ptr %l6, i32 0, i32 5
  %t179 = load i1, ptr %t178, !tbaa !21
  store i1 %t179, ptr %l106, !tbaa !21
  %t180 = load i32, ptr %l102
  %t181 = load i64, ptr %l104, !tbaa !24
  %t182 = load i64, ptr %l105, !tbaa !24
  %t183 = load i1, ptr %l106, !tbaa !21
  %t184 = call %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %s0, i32 %t180, i64 %t181, double 0x0000000000000000, i64 0, i64 %t182, i1 %t183)
  store %"compiler/cond:Value" %t184, ptr %l107
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s0)
  %t185 = load %"compiler/cond:Value", ptr %l107
  store %"compiler/cond:Value" %t185, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cond:Value", ptr %rv
  ret %"compiler/cond:Value" %rr
}

define dso_local void @compiler_2fcond_2ecompiler_2fcond_3aScope_2eAdd(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i1
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i1
  %l22 = alloca i1
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l28 = alloca ptr
  %l29 = alloca { i64, ptr }
  %l30 = alloca i1
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca ptr
  %l37 = alloca ptr
  %l38 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = getelementptr %"compiler/cond:Scope", ptr %t2, i32 0, i32 1
  store ptr %t3, ptr %l9, !tbaa !29
  %t4 = load ptr, ptr %l9, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load ptr, ptr %l2, !tbaa !29
  store ptr %t5, ptr %l11, !tbaa !29
  %t6 = load i64, ptr %l3, !tbaa !24
  store i64 %t6, ptr %l12, !tbaa !24
  %t7 = load ptr, ptr %l11, !tbaa !29
  %t8 = load i64, ptr %l12, !tbaa !24
  %t9 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcond_3aGlobal_26_3e_2eRu_Hdae492cbfddb0b6a70eec6865333e543(ptr %v0, ptr %t7, i64 %t8)
  %t10 = extractvalue { i32, { i64, ptr } } %t9, 1
  %t11 = extractvalue { i32, { i64, ptr } } %t9, 0
  store i32 %t11, ptr %l14
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb3, label %ok.13
ok.13:
  store { i64, ptr } %t10, ptr %l13
  br label %bb2
bb2:
  %t14 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t14, ptr %l10, !tbaa !27
  br label %bb7
bb3:
  %t15 = load i32, ptr %l14, !tbaa !23
  %t16 = ashr i32 %t15, 16
  store i32 %t16, ptr %l15, !tbaa !23
  %t17 = load i32, ptr %l15, !tbaa !23
  %t18 = icmp eq i32 %t17, 1
  store i1 %t18, ptr %l16, !tbaa !21
  %t19 = load i1, ptr %l16, !tbaa !21
  br i1 %t19, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @.c45)
  unreachable
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb7:
  %t20 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t20, ptr %l4, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t21, ptr %l17, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l18, !tbaa !24
  %t24 = load i64, ptr %l18, !tbaa !24
  store i64 %t24, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t25 = load i64, ptr %l6, !tbaa !24
  store i64 %t25, ptr %l19, !tbaa !24
  %t26 = load i64, ptr %l5, !tbaa !24
  store i64 %t26, ptr %l20, !tbaa !24
  %t27 = load i64, ptr %l19, !tbaa !24
  %t28 = load i64, ptr %l20, !tbaa !24
  %t29 = icmp slt i64 %t27, %t28
  store i1 %t29, ptr %l21, !tbaa !21
  %t30 = load i1, ptr %l21, !tbaa !21
  %t31 = xor i1 %t30, true
  store i1 %t31, ptr %l22, !tbaa !21
  %t32 = load i1, ptr %l22, !tbaa !21
  br i1 %t32, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb10:
  br label %bb11
bb11:
  %t33 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t33, ptr %l23, !tbaa !27
  %t34 = load i64, ptr %l6, !tbaa !24
  store i64 %t34, ptr %l24, !tbaa !24
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr ptr, ptr %t37, i64 %t35
  %t39 = load ptr, ptr %t38, !tbaa !39
  store ptr %t39, ptr %l25, !tbaa !29
  %t40 = load ptr, ptr %l25, !tbaa !29
  store ptr %t40, ptr %l7, !tbaa !29
  %t41 = load ptr, ptr %l7, !tbaa !29
  store ptr %t41, ptr %l26, !tbaa !29
  %t42 = load ptr, ptr %l26, !tbaa !29
  %t43 = getelementptr %"compiler/cond:Global", ptr %t42, i32 0, i32 0
  %t44 = load { i64, ptr }, ptr %t43, !tbaa !27
  store { i64, ptr } %t44, ptr %l27, !tbaa !27
  %t45 = load ptr, ptr %l1, !tbaa !29
  store ptr %t45, ptr %l28, !tbaa !29
  %t46 = load ptr, ptr %l28, !tbaa !29
  %t47 = getelementptr %"compiler/cond:Global", ptr %t46, i32 0, i32 0
  %t48 = load { i64, ptr }, ptr %t47, !tbaa !27
  store { i64, ptr } %t48, ptr %l29, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t50 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t51 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t49, { i64, ptr } %t50)
  store i1 %t51, ptr %l30
  br label %bb12
bb12:
  %t52 = load i1, ptr %l30, !tbaa !21
  br i1 %t52, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s4
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb16:
  store %olang.scope zeroinitializer, ptr %s5
  %t53 = load i64, ptr %l6, !tbaa !24
  store i64 %t53, ptr %l31, !tbaa !24
  %t54 = load i64, ptr %l31, !tbaa !24
  %t55 = add i64 %t54, 1
  store i64 %t55, ptr %l32, !tbaa !24
  %t56 = load i64, ptr %l32, !tbaa !24
  store i64 %t56, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb8
bb17:
  %t57 = load i64, ptr %l3, !tbaa !24
  store i64 %t57, ptr %l33, !tbaa !24
  %t58 = load i64, ptr %l5, !tbaa !24
  store i64 %t58, ptr %l34, !tbaa !24
  %t59 = load i64, ptr %l33, !tbaa !24
  %t60 = load i64, ptr %l34, !tbaa !24
  %t61 = add i64 %t59, %t60
  store i64 %t61, ptr %l35, !tbaa !24
  %t62 = load i64, ptr %l35, !tbaa !24
  store i64 %t62, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  br label %bb1
bb19:
  call void @__olang_scope_close(ptr %s1)
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l36, !tbaa !29
  %t64 = load ptr, ptr %l36, !tbaa !29
  %t65 = getelementptr %"compiler/cond:Scope", ptr %t64, i32 0, i32 1
  store ptr %t65, ptr %l37, !tbaa !29
  %t66 = load ptr, ptr %l1, !tbaa !29
  store ptr %t66, ptr %l38, !tbaa !29
  %t67 = load ptr, ptr %l37, !tbaa !29
  %t68 = load ptr, ptr %l38, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcond_3aGlobal_26_3e_2ePu_H886a66ffa23940650f82c48d9485539c(ptr %v0, ptr %v1, ptr %t67, ptr %t68)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i32, ptr } @compiler_2fcond_2ecompiler_2fcond_3aScope_2efind(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i1
  %l17 = alloca i32
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i1
  %l23 = alloca i1
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = getelementptr %"compiler/cond:Scope", ptr %t2, i32 0, i32 1
  store ptr %t3, ptr %l9, !tbaa !29
  %t4 = load ptr, ptr %l9, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load ptr, ptr %l2, !tbaa !29
  store ptr %t5, ptr %l11, !tbaa !29
  %t6 = load i64, ptr %l3, !tbaa !24
  store i64 %t6, ptr %l12, !tbaa !24
  %t7 = load ptr, ptr %l11, !tbaa !29
  %t8 = load i64, ptr %l12, !tbaa !24
  %t9 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcond_3aGlobal_26_3e_2eRu_Hdae492cbfddb0b6a70eec6865333e543(ptr %v0, ptr %t7, i64 %t8)
  %t10 = extractvalue { i32, { i64, ptr } } %t9, 1
  %t11 = extractvalue { i32, { i64, ptr } } %t9, 0
  store i32 %t11, ptr %l14
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb3, label %ok.13
ok.13:
  store { i64, ptr } %t10, ptr %l13
  br label %bb2
bb2:
  %t14 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t14, ptr %l10, !tbaa !27
  br label %bb7
bb3:
  %t15 = load i32, ptr %l14, !tbaa !23
  %t16 = ashr i32 %t15, 16
  store i32 %t16, ptr %l15, !tbaa !23
  %t17 = load i32, ptr %l15, !tbaa !23
  %t18 = icmp eq i32 %t17, 1
  store i1 %t18, ptr %l16, !tbaa !21
  %t19 = load i1, ptr %l16, !tbaa !21
  br i1 %t19, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  %t20 = load i32, ptr %l14, !tbaa !23
  %t21 = lshr i32 %t20, 16
  %t22 = and i32 %t20, 65535
  %t23 = icmp eq i32 %t21, 1
  %t24 = select i1 %t23, i32 0, i32 0
  %t25 = icmp eq i32 %t20, 0
  %t26 = shl i32 %t24, 16
  %t27 = or i32 %t26, %t22
  %t28 = select i1 %t25, i32 0, i32 %t27
  store i32 %t28, ptr %l17, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t29 = load i32, ptr %l17, !tbaa !23
  %t30 = insertvalue { i32, ptr } zeroinitializer, i32 %t29, 0
  store { i32, ptr } %t30, ptr %rv
  br label %ret
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb7:
  %t31 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t31, ptr %l4, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t32, ptr %l18, !tbaa !27
  %t33 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 0
  store i64 %t34, ptr %l19, !tbaa !24
  %t35 = load i64, ptr %l19, !tbaa !24
  store i64 %t35, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t36 = load i64, ptr %l6, !tbaa !24
  store i64 %t36, ptr %l20, !tbaa !24
  %t37 = load i64, ptr %l5, !tbaa !24
  store i64 %t37, ptr %l21, !tbaa !24
  %t38 = load i64, ptr %l20, !tbaa !24
  %t39 = load i64, ptr %l21, !tbaa !24
  %t40 = icmp slt i64 %t38, %t39
  store i1 %t40, ptr %l22, !tbaa !21
  %t41 = load i1, ptr %l22, !tbaa !21
  %t42 = xor i1 %t41, true
  store i1 %t42, ptr %l23, !tbaa !21
  %t43 = load i1, ptr %l23, !tbaa !21
  br i1 %t43, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb10:
  br label %bb11
bb11:
  %t44 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t44, ptr %l24, !tbaa !27
  %t45 = load i64, ptr %l6, !tbaa !24
  store i64 %t45, ptr %l25, !tbaa !24
  %t46 = load i64, ptr %l25, !tbaa !24
  %t47 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr ptr, ptr %t48, i64 %t46
  %t50 = load ptr, ptr %t49, !tbaa !39
  store ptr %t50, ptr %l26, !tbaa !29
  %t51 = load ptr, ptr %l26, !tbaa !29
  store ptr %t51, ptr %l7, !tbaa !29
  %t52 = load ptr, ptr %l7, !tbaa !29
  store ptr %t52, ptr %l27, !tbaa !29
  %t53 = load ptr, ptr %l27, !tbaa !29
  %t54 = getelementptr %"compiler/cond:Global", ptr %t53, i32 0, i32 0
  %t55 = load { i64, ptr }, ptr %t54, !tbaa !27
  store { i64, ptr } %t55, ptr %l28, !tbaa !27
  %t56 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t56, ptr %l29, !tbaa !27
  %t57 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t58 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t59 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t57, { i64, ptr } %t58)
  store i1 %t59, ptr %l30
  br label %bb12
bb12:
  %t60 = load i1, ptr %l30, !tbaa !21
  br i1 %t60, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s4
  %t61 = load ptr, ptr %l7, !tbaa !29
  store ptr %t61, ptr %l31, !tbaa !29
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t62 = load ptr, ptr %l31, !tbaa !29
  %t63 = insertvalue { i32, ptr } zeroinitializer, ptr %t62, 1
  store { i32, ptr } %t63, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb16:
  store %olang.scope zeroinitializer, ptr %s5
  %t64 = load i64, ptr %l6, !tbaa !24
  store i64 %t64, ptr %l32, !tbaa !24
  %t65 = load i64, ptr %l32, !tbaa !24
  %t66 = add i64 %t65, 1
  store i64 %t66, ptr %l33, !tbaa !24
  %t67 = load i64, ptr %l33, !tbaa !24
  store i64 %t67, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb8
bb17:
  %t68 = load i64, ptr %l3, !tbaa !24
  store i64 %t68, ptr %l34, !tbaa !24
  %t69 = load i64, ptr %l5, !tbaa !24
  store i64 %t69, ptr %l35, !tbaa !24
  %t70 = load i64, ptr %l34, !tbaa !24
  %t71 = load i64, ptr %l35, !tbaa !24
  %t72 = add i64 %t70, %t71
  store i64 %t72, ptr %l36, !tbaa !24
  %t73 = load i64, ptr %l36, !tbaa !24
  store i64 %t73, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  br label %bb1
bb19:
  call void @__olang_scope_close(ptr %s1)
  store i32 65536, ptr %l37, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t74 = load i32, ptr %l37, !tbaa !23
  %t75 = insertvalue { i32, ptr } zeroinitializer, i32 %t74, 0
  store { i32, ptr } %t75, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, i64, i1 } @compiler_2fcond_2edeclaredKind(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca i32
  %l4 = alloca { i32, i64, i1 }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i1
  %l7 = alloca i32
  %l8 = alloca { i32, i64, i1 }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i1
  %l11 = alloca i32
  %l12 = alloca { i32, i64, i1 }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i1
  %l15 = alloca i32
  %l16 = alloca { i32, i64, i1 }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i1
  %l19 = alloca i32
  %l20 = alloca { i32, i64, i1 }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i1
  %l23 = alloca i32
  %l24 = alloca { i32, i64, i1 }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i1
  %l27 = alloca i32
  %l28 = alloca { i32, i64, i1 }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i1
  %l31 = alloca i32
  %l32 = alloca { i32, i64, i1 }
  %l33 = alloca { i64, ptr }
  %l34 = alloca i1
  %l35 = alloca i1
  %l36 = alloca { i64, ptr }
  %l37 = alloca i1
  %l38 = alloca i32
  %l39 = alloca { i32, i64, i1 }
  %l40 = alloca { i64, ptr }
  %l41 = alloca i1
  %l42 = alloca i32
  %l43 = alloca { i32, i64, i1 }
  %l44 = alloca { i64, ptr }
  %l45 = alloca i1
  %l46 = alloca i32
  %l47 = alloca { i32, i64, i1 }
  %l48 = alloca { i64, ptr }
  %l49 = alloca i1
  %l50 = alloca i32
  %l51 = alloca { i32, i64, i1 }
  %l52 = alloca { i64, ptr }
  %l53 = alloca i1
  %l54 = alloca i32
  %l55 = alloca { i32, i64, i1 }
  %l56 = alloca i32
  %l57 = alloca { i32, i64, i1 }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %rv = alloca { i32, i64, i1 }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l1, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t2, { i64, ptr } { i64 2, ptr @.d46 })
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  store i32 2, ptr %l3
  %t5 = load i32, ptr %l3
  %t6 = insertvalue { i32, i64, i1 } undef, i32 %t5, 0
  %t7 = insertvalue { i32, i64, i1 } %t6, i64 8, 1
  %t8 = insertvalue { i32, i64, i1 } %t7, i1 false, 2
  store { i32, i64, i1 } %t8, ptr %l4
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t9 = load { i32, i64, i1 }, ptr %l4
  store { i32, i64, i1 } %t9, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t10, ptr %l5, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t12 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t11, { i64, ptr } { i64 3, ptr @.d47 })
  store i1 %t12, ptr %l6
  br label %bb5
bb5:
  %t13 = load i1, ptr %l6, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  store i32 2, ptr %l7
  %t14 = load i32, ptr %l7
  %t15 = insertvalue { i32, i64, i1 } undef, i32 %t14, 0
  %t16 = insertvalue { i32, i64, i1 } %t15, i64 16, 1
  %t17 = insertvalue { i32, i64, i1 } %t16, i1 false, 2
  store { i32, i64, i1 } %t17, ptr %l8
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t18 = load { i32, i64, i1 }, ptr %l8
  store { i32, i64, i1 } %t18, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t19 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t19, ptr %l9, !tbaa !27
  %t20 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t21 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t20, { i64, ptr } { i64 3, ptr @.d48 })
  store i1 %t21, ptr %l10
  br label %bb9
bb9:
  %t22 = load i1, ptr %l10, !tbaa !21
  br i1 %t22, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  store i32 2, ptr %l11
  %t23 = load i32, ptr %l11
  %t24 = insertvalue { i32, i64, i1 } undef, i32 %t23, 0
  %t25 = insertvalue { i32, i64, i1 } %t24, i64 32, 1
  %t26 = insertvalue { i32, i64, i1 } %t25, i1 false, 2
  store { i32, i64, i1 } %t26, ptr %l12
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t27 = load { i32, i64, i1 }, ptr %l12
  store { i32, i64, i1 } %t27, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t28 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t28, ptr %l13, !tbaa !27
  %t29 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t30 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t29, { i64, ptr } { i64 3, ptr @.d49 })
  store i1 %t30, ptr %l14
  br label %bb13
bb13:
  %t31 = load i1, ptr %l14, !tbaa !21
  br i1 %t31, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s4
  store i32 2, ptr %l15
  %t32 = load i32, ptr %l15
  %t33 = insertvalue { i32, i64, i1 } undef, i32 %t32, 0
  %t34 = insertvalue { i32, i64, i1 } %t33, i64 64, 1
  %t35 = insertvalue { i32, i64, i1 } %t34, i1 false, 2
  store { i32, i64, i1 } %t35, ptr %l16
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t36 = load { i32, i64, i1 }, ptr %l16
  store { i32, i64, i1 } %t36, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t37 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t37, ptr %l17, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t39 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t38, { i64, ptr } { i64 2, ptr @.d50 })
  store i1 %t39, ptr %l18
  br label %bb17
bb17:
  %t40 = load i1, ptr %l18, !tbaa !21
  br i1 %t40, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s5
  store i32 2, ptr %l19
  %t41 = load i32, ptr %l19
  %t42 = insertvalue { i32, i64, i1 } undef, i32 %t41, 0
  %t43 = insertvalue { i32, i64, i1 } %t42, i64 8, 1
  %t44 = insertvalue { i32, i64, i1 } %t43, i1 true, 2
  store { i32, i64, i1 } %t44, ptr %l20
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t45 = load { i32, i64, i1 }, ptr %l20
  store { i32, i64, i1 } %t45, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t46 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t46, ptr %l21, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t48 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t47, { i64, ptr } { i64 3, ptr @.d51 })
  store i1 %t48, ptr %l22
  br label %bb21
bb21:
  %t49 = load i1, ptr %l22, !tbaa !21
  br i1 %t49, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s6
  store i32 2, ptr %l23
  %t50 = load i32, ptr %l23
  %t51 = insertvalue { i32, i64, i1 } undef, i32 %t50, 0
  %t52 = insertvalue { i32, i64, i1 } %t51, i64 16, 1
  %t53 = insertvalue { i32, i64, i1 } %t52, i1 true, 2
  store { i32, i64, i1 } %t53, ptr %l24
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t54 = load { i32, i64, i1 }, ptr %l24
  store { i32, i64, i1 } %t54, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  %t55 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t55, ptr %l25, !tbaa !27
  %t56 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t57 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t56, { i64, ptr } { i64 3, ptr @.d52 })
  store i1 %t57, ptr %l26
  br label %bb25
bb25:
  %t58 = load i1, ptr %l26, !tbaa !21
  br i1 %t58, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s7
  store i32 2, ptr %l27
  %t59 = load i32, ptr %l27
  %t60 = insertvalue { i32, i64, i1 } undef, i32 %t59, 0
  %t61 = insertvalue { i32, i64, i1 } %t60, i64 32, 1
  %t62 = insertvalue { i32, i64, i1 } %t61, i1 true, 2
  store { i32, i64, i1 } %t62, ptr %l28
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  %t63 = load { i32, i64, i1 }, ptr %l28
  store { i32, i64, i1 } %t63, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t64 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t64, ptr %l29, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t66 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t65, { i64, ptr } { i64 3, ptr @.d53 })
  store i1 %t66, ptr %l30
  br label %bb29
bb29:
  %t67 = load i1, ptr %l30, !tbaa !21
  br i1 %t67, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s8
  store i32 2, ptr %l31
  %t68 = load i32, ptr %l31
  %t69 = insertvalue { i32, i64, i1 } undef, i32 %t68, 0
  %t70 = insertvalue { i32, i64, i1 } %t69, i64 64, 1
  %t71 = insertvalue { i32, i64, i1 } %t70, i1 true, 2
  store { i32, i64, i1 } %t71, ptr %l32
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t72 = load { i32, i64, i1 }, ptr %l32
  store { i32, i64, i1 } %t72, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  %t73 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t73, ptr %l33, !tbaa !27
  %t74 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t75 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t74, { i64, ptr } { i64 3, ptr @.d54 })
  store i1 %t75, ptr %l34
  br label %bb33
bb33:
  %t76 = load i1, ptr %l34, !tbaa !21
  br i1 %t76, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb37
bb35:
  %t77 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t77, ptr %l36, !tbaa !27
  %t78 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t79 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t78, { i64, ptr } { i64 4, ptr @.d55 })
  store i1 %t79, ptr %l37
  br label %bb36
bb36:
  %t80 = load i1, ptr %l37, !tbaa !21
  store i1 %t80, ptr %l35, !tbaa !21
  br label %bb37
bb37:
  %t81 = load i1, ptr %l35, !tbaa !21
  br i1 %t81, label %bb38, label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s9
  store i32 3, ptr %l38
  %t82 = load i32, ptr %l38
  %t83 = insertvalue { i32, i64, i1 } undef, i32 %t82, 0
  %t84 = insertvalue { i32, i64, i1 } %t83, i64 16, 1
  %t85 = insertvalue { i32, i64, i1 } %t84, i1 false, 2
  store { i32, i64, i1 } %t85, ptr %l39
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  %t86 = load { i32, i64, i1 }, ptr %l39
  store { i32, i64, i1 } %t86, ptr %rv
  br label %ret
bb39:
  br label %bb40
bb40:
  %t87 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t87, ptr %l40, !tbaa !27
  %t88 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t89 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t88, { i64, ptr } { i64 3, ptr @.d56 })
  store i1 %t89, ptr %l41
  br label %bb41
bb41:
  %t90 = load i1, ptr %l41, !tbaa !21
  br i1 %t90, label %bb42, label %bb43
bb42:
  store %olang.scope zeroinitializer, ptr %s10
  store i32 3, ptr %l42
  %t91 = load i32, ptr %l42
  %t92 = insertvalue { i32, i64, i1 } undef, i32 %t91, 0
  %t93 = insertvalue { i32, i64, i1 } %t92, i64 32, 1
  %t94 = insertvalue { i32, i64, i1 } %t93, i1 false, 2
  store { i32, i64, i1 } %t94, ptr %l43
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  %t95 = load { i32, i64, i1 }, ptr %l43
  store { i32, i64, i1 } %t95, ptr %rv
  br label %ret
bb43:
  br label %bb44
bb44:
  %t96 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t96, ptr %l44, !tbaa !27
  %t97 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t98 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t97, { i64, ptr } { i64 3, ptr @.d57 })
  store i1 %t98, ptr %l45
  br label %bb45
bb45:
  %t99 = load i1, ptr %l45, !tbaa !21
  br i1 %t99, label %bb46, label %bb47
bb46:
  store %olang.scope zeroinitializer, ptr %s11
  store i32 3, ptr %l46
  %t100 = load i32, ptr %l46
  %t101 = insertvalue { i32, i64, i1 } undef, i32 %t100, 0
  %t102 = insertvalue { i32, i64, i1 } %t101, i64 64, 1
  %t103 = insertvalue { i32, i64, i1 } %t102, i1 false, 2
  store { i32, i64, i1 } %t103, ptr %l47
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  %t104 = load { i32, i64, i1 }, ptr %l47
  store { i32, i64, i1 } %t104, ptr %rv
  br label %ret
bb47:
  br label %bb48
bb48:
  %t105 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t105, ptr %l48, !tbaa !27
  %t106 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t107 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t106, { i64, ptr } { i64 4, ptr @.d58 })
  store i1 %t107, ptr %l49
  br label %bb49
bb49:
  %t108 = load i1, ptr %l49, !tbaa !21
  br i1 %t108, label %bb50, label %bb51
bb50:
  store %olang.scope zeroinitializer, ptr %s12
  store i32 1, ptr %l50
  %t109 = load i32, ptr %l50
  %t110 = insertvalue { i32, i64, i1 } undef, i32 %t109, 0
  %t111 = insertvalue { i32, i64, i1 } %t110, i64 0, 1
  %t112 = insertvalue { i32, i64, i1 } %t111, i1 false, 2
  store { i32, i64, i1 } %t112, ptr %l51
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s0)
  %t113 = load { i32, i64, i1 }, ptr %l51
  store { i32, i64, i1 } %t113, ptr %rv
  br label %ret
bb51:
  br label %bb52
bb52:
  %t114 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t114, ptr %l52, !tbaa !27
  %t115 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t116 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t115, { i64, ptr } { i64 6, ptr @.d59 })
  store i1 %t116, ptr %l53
  br label %bb53
bb53:
  %t117 = load i1, ptr %l53, !tbaa !21
  br i1 %t117, label %bb54, label %bb55
bb54:
  store %olang.scope zeroinitializer, ptr %s13
  store i32 4, ptr %l54
  %t118 = load i32, ptr %l54
  %t119 = insertvalue { i32, i64, i1 } undef, i32 %t118, 0
  %t120 = insertvalue { i32, i64, i1 } %t119, i64 0, 1
  %t121 = insertvalue { i32, i64, i1 } %t120, i1 false, 2
  store { i32, i64, i1 } %t121, ptr %l55
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s0)
  %t122 = load { i32, i64, i1 }, ptr %l55
  store { i32, i64, i1 } %t122, ptr %rv
  br label %ret
bb55:
  br label %bb56
bb56:
  store i32 0, ptr %l56
  %t123 = load i32, ptr %l56
  %t124 = insertvalue { i32, i64, i1 } undef, i32 %t123, 0
  %t125 = insertvalue { i32, i64, i1 } %t124, i64 0, 1
  %t126 = insertvalue { i32, i64, i1 } %t125, i1 false, 2
  store { i32, i64, i1 } %t126, ptr %l57
  call void @__olang_scope_close(ptr %s0)
  %t127 = load { i32, i64, i1 }, ptr %l57
  store { i32, i64, i1 } %t127, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64, i1 }, ptr %rv
  ret { i32, i64, i1 } %rr
}

define dso_local { i64, ptr } @compiler_2fcond_2edecode(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca i64
  %l3 = alloca i8
  %l4 = alloca i8
  %l5 = alloca %"std/prelude/text:StringBuilder"
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i1
  %l11 = alloca i1
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i8
  %l15 = alloca i8
  %l16 = alloca i1
  %l17 = alloca i1
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i1
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca i8
  %l29 = alloca i8
  %l30 = alloca i1
  %l31 = alloca i8
  %l32 = alloca i8
  %l33 = alloca i1
  %l34 = alloca i8
  %l35 = alloca i8
  %l36 = alloca i1
  %l37 = alloca i8
  %l38 = alloca i8
  %l39 = alloca i1
  %l40 = alloca i8
  %l41 = alloca i8
  %l42 = alloca ptr
  %l43 = alloca i8
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca ptr
  %l47 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l49 = alloca i64
  %l50 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l5
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l5
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  store i64 1, ptr %l2, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = load i64, ptr %l2, !tbaa !24
  store i64 %t3, ptr %l6, !tbaa !24
  %t4 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t4, ptr %l7, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l8, !tbaa !24
  %t7 = load i64, ptr %l8, !tbaa !24
  %t8 = sub i64 %t7, 1
  store i64 %t8, ptr %l9, !tbaa !24
  %t9 = load i64, ptr %l6, !tbaa !24
  %t10 = load i64, ptr %l9, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  store i1 %t11, ptr %l10, !tbaa !21
  %t12 = load i1, ptr %l10, !tbaa !21
  %t13 = xor i1 %t12, true
  store i1 %t13, ptr %l11, !tbaa !21
  %t14 = load i1, ptr %l11, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  br label %bb26
bb4:
  br label %bb5
bb5:
  %t15 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t15, ptr %l12, !tbaa !27
  %t16 = load i64, ptr %l2, !tbaa !24
  store i64 %t16, ptr %l13, !tbaa !24
  %t17 = load i64, ptr %l13, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i8, ptr %t19, i64 %t17
  %t21 = load i8, ptr %t20, !tbaa !32
  store i8 %t21, ptr %l14, !tbaa !22
  %t22 = load i8, ptr %l14, !tbaa !22
  store i8 %t22, ptr %l3, !tbaa !22
  %t23 = load i8, ptr %l3, !tbaa !22
  store i8 %t23, ptr %l15, !tbaa !22
  %t24 = load i8, ptr %l15, !tbaa !22
  %t25 = icmp eq i8 %t24, 92
  store i1 %t25, ptr %l16, !tbaa !21
  %t26 = load i1, ptr %l16, !tbaa !21
  br i1 %t26, label %bb6, label %bb7
bb6:
  %t27 = load i64, ptr %l2, !tbaa !24
  store i64 %t27, ptr %l18, !tbaa !24
  %t28 = load i64, ptr %l18, !tbaa !24
  %t29 = add i64 %t28, 1
  store i64 %t29, ptr %l19, !tbaa !24
  %t30 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t30, ptr %l20, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l21, !tbaa !24
  %t33 = load i64, ptr %l21, !tbaa !24
  %t34 = sub i64 %t33, 1
  store i64 %t34, ptr %l22, !tbaa !24
  %t35 = load i64, ptr %l19, !tbaa !24
  %t36 = load i64, ptr %l22, !tbaa !24
  %t37 = icmp slt i64 %t35, %t36
  store i1 %t37, ptr %l23, !tbaa !21
  %t38 = load i1, ptr %l23, !tbaa !21
  store i1 %t38, ptr %l17, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb8
bb8:
  %t39 = load i1, ptr %l17, !tbaa !21
  br i1 %t39, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t40 = load i64, ptr %l2, !tbaa !24
  store i64 %t40, ptr %l24, !tbaa !24
  %t41 = load i64, ptr %l24, !tbaa !24
  %t42 = add i64 %t41, 1
  store i64 %t42, ptr %l25, !tbaa !24
  %t43 = load i64, ptr %l25, !tbaa !24
  store i64 %t43, ptr %l2, !tbaa !24
  %t44 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t44, ptr %l26, !tbaa !27
  %t45 = load i64, ptr %l2, !tbaa !24
  store i64 %t45, ptr %l27, !tbaa !24
  %t46 = load i64, ptr %l27, !tbaa !24
  %t47 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr i8, ptr %t48, i64 %t46
  %t50 = load i8, ptr %t49, !tbaa !32
  store i8 %t50, ptr %l28, !tbaa !22
  %t51 = load i8, ptr %l28, !tbaa !22
  store i8 %t51, ptr %l4, !tbaa !22
  %t52 = load i8, ptr %l4, !tbaa !22
  store i8 %t52, ptr %l29, !tbaa !22
  %t53 = load i8, ptr %l29, !tbaa !22
  %t54 = icmp eq i8 %t53, 110
  store i1 %t54, ptr %l30, !tbaa !21
  %t55 = load i1, ptr %l30, !tbaa !21
  br i1 %t55, label %bb11, label %bb12
bb10:
  br label %bb23
bb11:
  store i8 10, ptr %l31, !tbaa !22
  br label %bb22
bb12:
  %t56 = load i8, ptr %l4, !tbaa !22
  store i8 %t56, ptr %l32, !tbaa !22
  %t57 = load i8, ptr %l32, !tbaa !22
  %t58 = icmp eq i8 %t57, 116
  store i1 %t58, ptr %l33, !tbaa !21
  %t59 = load i1, ptr %l33, !tbaa !21
  br i1 %t59, label %bb13, label %bb14
bb13:
  store i8 9, ptr %l34, !tbaa !22
  br label %bb21
bb14:
  %t60 = load i8, ptr %l4, !tbaa !22
  store i8 %t60, ptr %l35, !tbaa !22
  %t61 = load i8, ptr %l35, !tbaa !22
  %t62 = icmp eq i8 %t61, 114
  store i1 %t62, ptr %l36, !tbaa !21
  %t63 = load i1, ptr %l36, !tbaa !21
  br i1 %t63, label %bb15, label %bb16
bb15:
  store i8 13, ptr %l37, !tbaa !22
  br label %bb20
bb16:
  %t64 = load i8, ptr %l4, !tbaa !22
  store i8 %t64, ptr %l38, !tbaa !22
  %t65 = load i8, ptr %l38, !tbaa !22
  %t66 = icmp eq i8 %t65, 48
  store i1 %t66, ptr %l39, !tbaa !21
  %t67 = load i1, ptr %l39, !tbaa !21
  br i1 %t67, label %bb17, label %bb18
bb17:
  store i8 0, ptr %l40, !tbaa !22
  br label %bb19
bb18:
  %t68 = load i8, ptr %l4, !tbaa !22
  store i8 %t68, ptr %l41, !tbaa !22
  %t69 = load i8, ptr %l41, !tbaa !22
  store i8 %t69, ptr %l40, !tbaa !22
  br label %bb19
bb19:
  %t70 = load i8, ptr %l40, !tbaa !22
  store i8 %t70, ptr %l37, !tbaa !22
  br label %bb20
bb20:
  %t71 = load i8, ptr %l37, !tbaa !22
  store i8 %t71, ptr %l34, !tbaa !22
  br label %bb21
bb21:
  %t72 = load i8, ptr %l34, !tbaa !22
  store i8 %t72, ptr %l31, !tbaa !22
  br label %bb22
bb22:
  %t73 = load i8, ptr %l31, !tbaa !22
  store i8 %t73, ptr %l3, !tbaa !22
  call void @__olang_scope_close(ptr %s2)
  br label %bb23
bb23:
  store ptr %l1, ptr %l42, !tbaa !29
  %t74 = load i8, ptr %l3, !tbaa !22
  store i8 %t74, ptr %l43, !tbaa !22
  %t75 = load ptr, ptr %l42, !tbaa !29
  %t76 = load i8, ptr %l43, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t75, i8 %t76)
  br label %bb24
bb24:
  %t77 = load i64, ptr %l2, !tbaa !24
  store i64 %t77, ptr %l44, !tbaa !24
  %t78 = load i64, ptr %l44, !tbaa !24
  %t79 = add i64 %t78, 1
  store i64 %t79, ptr %l45, !tbaa !24
  %t80 = load i64, ptr %l45, !tbaa !24
  store i64 %t80, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb25
bb25:
  br label %bb2
bb26:
  store ptr %l1, ptr %l46, !tbaa !29
  %t81 = load ptr, ptr %l46, !tbaa !29
  %t82 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %t81)
  store { i64, ptr } %t82, ptr %l47
  br label %bb27
bb27:
  %t83 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t83, ptr %l48, !tbaa !27
  %t84 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t84, 0
  store i64 %t85, ptr %l49, !tbaa !24
  %t86 = load i64, ptr %l49, !tbaa !24
  %t87 = mul i64 %t86, 1
  %t88 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t87)
  %t89 = insertvalue { i64, ptr } undef, i64 %t86, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  store { i64, ptr } %t90, ptr %l50, !tbaa !27
  %t91 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = load i64, ptr %l49, !tbaa !24
  %t96 = mul i64 %t95, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t92, ptr %t94, i64 %t96, i1 false)
  %t97 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t97, ptr %l48, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t98 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t98, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fcond_2efits(i64 %a0, i64 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca i1
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i1
  %l6 = alloca i1
  %l7 = alloca i1
  %l8 = alloca i64
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca i64
  %l12 = alloca i1
  %l13 = alloca i1
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i1
  %l18 = alloca i64
  %l19 = alloca i1
  %l20 = alloca i1
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i1
  %l28 = alloca i1
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  store i64 %t1, ptr %l4, !tbaa !24
  %t2 = load i64, ptr %l4, !tbaa !24
  %t3 = icmp eq i64 %t2, 0
  store i1 %t3, ptr %l5, !tbaa !21
  %t4 = load i1, ptr %l5, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  store i1 true, ptr %l6, !tbaa !21
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t5 = load i1, ptr %l6, !tbaa !21
  store i1 %t5, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load i1, ptr %l2, !tbaa !21
  store i1 %t6, ptr %l7, !tbaa !21
  %t7 = load i1, ptr %l7, !tbaa !21
  br i1 %t7, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t8 = load i64, ptr %l0, !tbaa !24
  store i64 %t8, ptr %l8, !tbaa !24
  %t9 = load i64, ptr %l8, !tbaa !24
  %t10 = icmp sge i64 %t9, 0
  store i1 %t10, ptr %l9, !tbaa !21
  %t11 = load i1, ptr %l9, !tbaa !21
  br i1 %t11, label %bb6, label %bb7
bb5:
  br label %bb12
bb6:
  %t12 = load i64, ptr %l1, !tbaa !24
  store i64 %t12, ptr %l11, !tbaa !24
  %t13 = load i64, ptr %l11, !tbaa !24
  %t14 = icmp eq i64 %t13, 64
  store i1 %t14, ptr %l12, !tbaa !21
  %t15 = load i1, ptr %l12, !tbaa !21
  br i1 %t15, label %bb8, label %bb9
bb7:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb11
bb8:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb10
bb9:
  %t16 = load i64, ptr %l0, !tbaa !24
  store i64 %t16, ptr %l14, !tbaa !24
  %t17 = load i64, ptr %l1, !tbaa !24
  store i64 %t17, ptr %l15, !tbaa !24
  %t18 = load i64, ptr %l15, !tbaa !24
  %t19 = load i64, ptr %l15, !tbaa !24
  %t20 = shl i64 1, %t19
  store i64 %t20, ptr %l16, !tbaa !24
  %t21 = load i64, ptr %l14, !tbaa !24
  %t22 = load i64, ptr %l16, !tbaa !24
  %t23 = icmp slt i64 %t21, %t22
  store i1 %t23, ptr %l17, !tbaa !21
  %t24 = load i1, ptr %l17, !tbaa !21
  store i1 %t24, ptr %l13, !tbaa !21
  br label %bb10
bb10:
  %t25 = load i1, ptr %l13, !tbaa !21
  store i1 %t25, ptr %l10, !tbaa !21
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t26 = load i1, ptr %l10, !tbaa !21
  store i1 %t26, ptr %rv
  br label %ret
bb12:
  %t27 = load i64, ptr %l1, !tbaa !24
  store i64 %t27, ptr %l18, !tbaa !24
  %t28 = load i64, ptr %l18, !tbaa !24
  %t29 = icmp eq i64 %t28, 64
  store i1 %t29, ptr %l19, !tbaa !21
  %t30 = load i1, ptr %l19, !tbaa !21
  br i1 %t30, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  store i1 true, ptr %l20, !tbaa !21
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t31 = load i1, ptr %l20, !tbaa !21
  store i1 %t31, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t32 = load i64, ptr %l1, !tbaa !24
  store i64 %t32, ptr %l21, !tbaa !24
  %t33 = load i64, ptr %l21, !tbaa !24
  %t34 = sub i64 %t33, 1
  store i64 %t34, ptr %l22, !tbaa !24
  %t35 = load i64, ptr %l22, !tbaa !24
  %t36 = load i64, ptr %l22, !tbaa !24
  %t37 = shl i64 1, %t36
  store i64 %t37, ptr %l23, !tbaa !24
  %t38 = load i64, ptr %l23, !tbaa !24
  store i64 %t38, ptr %l3, !tbaa !24
  %t39 = load i64, ptr %l0, !tbaa !24
  store i64 %t39, ptr %l24, !tbaa !24
  %t40 = load i64, ptr %l3, !tbaa !24
  store i64 %t40, ptr %l25, !tbaa !24
  %t41 = load i64, ptr %l25, !tbaa !24
  %t42 = sub i64 0, %t41
  store i64 %t42, ptr %l26, !tbaa !24
  %t43 = load i64, ptr %l24, !tbaa !24
  %t44 = load i64, ptr %l26, !tbaa !24
  %t45 = icmp sge i64 %t43, %t44
  store i1 %t45, ptr %l27, !tbaa !21
  %t46 = load i1, ptr %l27, !tbaa !21
  br i1 %t46, label %bb16, label %bb17
bb16:
  %t47 = load i64, ptr %l0, !tbaa !24
  store i64 %t47, ptr %l29, !tbaa !24
  %t48 = load i64, ptr %l3, !tbaa !24
  store i64 %t48, ptr %l30, !tbaa !24
  %t49 = load i64, ptr %l29, !tbaa !24
  %t50 = load i64, ptr %l30, !tbaa !24
  %t51 = icmp slt i64 %t49, %t50
  store i1 %t51, ptr %l31, !tbaa !21
  %t52 = load i1, ptr %l31, !tbaa !21
  store i1 %t52, ptr %l28, !tbaa !21
  br label %bb18
bb17:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s0)
  %t53 = load i1, ptr %l28, !tbaa !21
  store i1 %t53, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcond_2eflows(i64 %a0, i1 %a1, i64 %a2, i1 %a3) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i1
  %l2 = alloca i64
  %l3 = alloca i1
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i1
  %l7 = alloca i1
  %l8 = alloca i1
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca i1
  %l12 = alloca i1
  %l13 = alloca i1
  %l14 = alloca i1
  %l15 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca i1
  store i64 %a0, ptr %l0
  store i1 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l0, !tbaa !24
  store i64 %t1, ptr %l4, !tbaa !24
  %t2 = load i64, ptr %l2, !tbaa !24
  store i64 %t2, ptr %l5, !tbaa !24
  %t3 = load i64, ptr %l4, !tbaa !24
  %t4 = load i64, ptr %l5, !tbaa !24
  %t5 = icmp sge i64 %t3, %t4
  store i1 %t5, ptr %l6, !tbaa !21
  %t6 = load i1, ptr %l6, !tbaa !21
  br i1 %t6, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  store i1 false, ptr %l7, !tbaa !21
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t7 = load i1, ptr %l7, !tbaa !21
  store i1 %t7, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load i1, ptr %l1, !tbaa !21
  store i1 %t8, ptr %l8, !tbaa !21
  %t9 = load i1, ptr %l3, !tbaa !21
  store i1 %t9, ptr %l9, !tbaa !21
  %t10 = load i1, ptr %l8, !tbaa !21
  %t11 = load i1, ptr %l9, !tbaa !21
  %t12 = icmp eq i1 %t10, %t11
  store i1 %t12, ptr %l10, !tbaa !21
  %t13 = load i1, ptr %l10, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb9
bb5:
  %t14 = load i1, ptr %l1, !tbaa !21
  store i1 %t14, ptr %l12, !tbaa !21
  %t15 = load i1, ptr %l12, !tbaa !21
  br i1 %t15, label %bb6, label %bb7
bb6:
  %t16 = load i1, ptr %l3, !tbaa !21
  store i1 %t16, ptr %l14, !tbaa !21
  %t17 = load i1, ptr %l14, !tbaa !21
  %t18 = xor i1 %t17, true
  store i1 %t18, ptr %l15, !tbaa !21
  %t19 = load i1, ptr %l15, !tbaa !21
  store i1 %t19, ptr %l13, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb8
bb8:
  %t20 = load i1, ptr %l13, !tbaa !21
  store i1 %t20, ptr %l11, !tbaa !21
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t21 = load i1, ptr %l11, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcond_2eisName(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i8
  %l6 = alloca i1
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i1
  %l17 = alloca i1
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i8
  %l22 = alloca i8
  %l23 = alloca i1
  %l24 = alloca i1
  %l25 = alloca i8
  %l26 = alloca i1
  %l27 = alloca i1
  %l28 = alloca i1
  %l29 = alloca i1
  %l30 = alloca i64
  %l31 = alloca i1
  %l32 = alloca i1
  %l33 = alloca i8
  %l34 = alloca i1
  %l35 = alloca i1
  %l36 = alloca i1
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca i32
  %l43 = alloca ptr
  %l44 = alloca i32
  %l45 = alloca ptr
  %l46 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l7, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t2, 0
  store i64 %t3, ptr %l8, !tbaa !24
  %t4 = load i64, ptr %l8, !tbaa !24
  %t5 = icmp eq i64 %t4, 0
  store i1 %t5, ptr %l9, !tbaa !21
  %t6 = load i1, ptr %l9, !tbaa !21
  br i1 %t6, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  store i1 false, ptr %l10, !tbaa !21
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t7 = load i1, ptr %l10, !tbaa !21
  store i1 %t7, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t8 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t8, ptr %l11, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t9, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t10, ptr %l12, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t11, 0
  store i64 %t12, ptr %l13, !tbaa !24
  %t13 = load i64, ptr %l13, !tbaa !24
  store i64 %t13, ptr %l3, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t14 = load i64, ptr %l2, !tbaa !24
  store i64 %t14, ptr %l14, !tbaa !24
  %t15 = load i64, ptr %l3, !tbaa !24
  store i64 %t15, ptr %l15, !tbaa !24
  %t16 = load i64, ptr %l14, !tbaa !24
  %t17 = load i64, ptr %l15, !tbaa !24
  %t18 = icmp slt i64 %t16, %t17
  store i1 %t18, ptr %l16, !tbaa !21
  %t19 = load i1, ptr %l16, !tbaa !21
  %t20 = xor i1 %t19, true
  store i1 %t20, ptr %l17, !tbaa !21
  %t21 = load i1, ptr %l17, !tbaa !21
  br i1 %t21, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb6:
  br label %bb7
bb7:
  %t22 = load i64, ptr %l2, !tbaa !24
  store i64 %t22, ptr %l18, !tbaa !24
  %t23 = load i64, ptr %l18, !tbaa !24
  store i64 %t23, ptr %l4, !tbaa !24
  %t24 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t24, ptr %l19, !tbaa !27
  %t25 = load i64, ptr %l2, !tbaa !24
  store i64 %t25, ptr %l20, !tbaa !24
  %t26 = load i64, ptr %l20, !tbaa !24
  %t27 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i8, ptr %t28, i64 %t26
  %t30 = load i8, ptr %t29, !tbaa !32
  store i8 %t30, ptr %l21, !tbaa !22
  %t31 = load i8, ptr %l21, !tbaa !22
  store i8 %t31, ptr %l5, !tbaa !22
  %t32 = load i8, ptr %l5, !tbaa !22
  store i8 %t32, ptr %l22, !tbaa !22
  %t33 = load i8, ptr %l22, !tbaa !22
  %t34 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t33)
  store i1 %t34, ptr %l23
  br label %bb8
bb8:
  %t35 = load i1, ptr %l23, !tbaa !21
  br i1 %t35, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb11
bb10:
  %t36 = load i8, ptr %l5, !tbaa !22
  store i8 %t36, ptr %l25, !tbaa !22
  %t37 = load i8, ptr %l25, !tbaa !22
  %t38 = icmp eq i8 %t37, 95
  store i1 %t38, ptr %l26, !tbaa !21
  %t39 = load i1, ptr %l26, !tbaa !21
  store i1 %t39, ptr %l24, !tbaa !21
  br label %bb11
bb11:
  %t40 = load i1, ptr %l24, !tbaa !21
  store i1 %t40, ptr %l6, !tbaa !21
  %t41 = load i1, ptr %l6, !tbaa !21
  store i1 %t41, ptr %l27, !tbaa !21
  %t42 = load i1, ptr %l27, !tbaa !21
  %t43 = xor i1 %t42, true
  store i1 %t43, ptr %l28, !tbaa !21
  %t44 = load i1, ptr %l28, !tbaa !21
  br i1 %t44, label %bb12, label %bb13
bb12:
  %t45 = load i64, ptr %l4, !tbaa !24
  store i64 %t45, ptr %l30, !tbaa !24
  %t46 = load i64, ptr %l30, !tbaa !24
  %t47 = icmp sgt i64 %t46, 0
  store i1 %t47, ptr %l31, !tbaa !21
  %t48 = load i1, ptr %l31, !tbaa !21
  br i1 %t48, label %bb14, label %bb15
bb13:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb18
bb14:
  %t49 = load i8, ptr %l5, !tbaa !22
  store i8 %t49, ptr %l33, !tbaa !22
  %t50 = load i8, ptr %l33, !tbaa !22
  %t51 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t50)
  store i1 %t51, ptr %l34
  br label %bb16
bb15:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb17
bb16:
  %t52 = load i1, ptr %l34, !tbaa !21
  store i1 %t52, ptr %l32, !tbaa !21
  br label %bb17
bb17:
  %t53 = load i1, ptr %l32, !tbaa !21
  %t54 = xor i1 %t53, true
  store i1 %t54, ptr %l35, !tbaa !21
  %t55 = load i1, ptr %l35, !tbaa !21
  store i1 %t55, ptr %l29, !tbaa !21
  br label %bb18
bb18:
  %t56 = load i1, ptr %l29, !tbaa !21
  br i1 %t56, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s4
  store i1 false, ptr %l36, !tbaa !21
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t57 = load i1, ptr %l36, !tbaa !21
  store i1 %t57, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s3)
  br label %bb22
bb22:
  store %olang.scope zeroinitializer, ptr %s5
  %t58 = load i64, ptr %l2, !tbaa !24
  store i64 %t58, ptr %l37, !tbaa !24
  %t59 = load i64, ptr %l37, !tbaa !24
  %t60 = add i64 %t59, 1
  store i64 %t60, ptr %l38, !tbaa !24
  %t61 = load i64, ptr %l38, !tbaa !24
  store i64 %t61, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb4
bb23:
  call void @__olang_scope_close(ptr %s2)
  %t62 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t62, ptr %l39, !tbaa !27
  %t63 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t63, ptr %l40, !tbaa !27
  %t64 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l41, !tbaa !24
  %t66 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t67 = load i64, ptr %l41, !tbaa !24
  %t68 = call i32 @compiler_2ftoken_2eKeyword(ptr %v0, { i64, ptr } %t66, i64 0, i64 %t67)
  store i32 %t68, ptr %l42
  br label %bb24
bb24:
  store ptr %l42, ptr %l43, !tbaa !29
  store i32 1, ptr %l44
  store ptr %l44, ptr %l45, !tbaa !29
  %t69 = load ptr, ptr %l43, !tbaa !29
  %t70 = load ptr, ptr %l45, !tbaa !29
  %t71 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t69, ptr %t70)
  store i1 %t71, ptr %l46
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s0)
  %t72 = load i1, ptr %l46, !tbaa !21
  store i1 %t72, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i1, i64, i1 } @compiler_2fcond_2emeet(%"compiler/cond:Value" %a0, %"compiler/cond:Value" %a1) #0 {
entry:
  %l0 = alloca %"compiler/cond:Value"
  %l1 = alloca %"compiler/cond:Value"
  %l2 = alloca %"compiler/cond:Value"
  %l3 = alloca %"compiler/cond:Value"
  %l4 = alloca i64
  %l5 = alloca i1
  %l6 = alloca i1
  %l7 = alloca i64
  %l8 = alloca i1
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i1
  %l12 = alloca i1
  %l13 = alloca i1
  %l14 = alloca i1
  %l15 = alloca i1
  %l16 = alloca i64
  %l17 = alloca i1
  %l18 = alloca { i1, i64, i1 }
  %l19 = alloca i64
  %l20 = alloca i1
  %l21 = alloca i64
  %l22 = alloca i1
  %l23 = alloca i1
  %l24 = alloca i64
  %l25 = alloca i1
  %l26 = alloca { i1, i64, i1 }
  %l27 = alloca i64
  %l28 = alloca i1
  %l29 = alloca i64
  %l30 = alloca i1
  %l31 = alloca i1
  %l32 = alloca i64
  %l33 = alloca i1
  %l34 = alloca { i1, i64, i1 }
  %l35 = alloca { i1, i64, i1 }
  %l36 = alloca i64
  %l37 = alloca i1
  %l38 = alloca i1
  %l39 = alloca i64
  %l40 = alloca i1
  %l41 = alloca i64
  %l42 = alloca i1
  %l43 = alloca %"compiler/cond:Value"
  %l44 = alloca %"compiler/cond:Value"
  %l45 = alloca %"compiler/cond:Value"
  %l46 = alloca i64
  %l47 = alloca i1
  %l48 = alloca %"compiler/cond:Value"
  %l49 = alloca %"compiler/cond:Value"
  %l50 = alloca %"compiler/cond:Value"
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i1
  %l54 = alloca i1
  %l55 = alloca i64
  %l56 = alloca i1
  %l57 = alloca { i1, i64, i1 }
  %l58 = alloca i64
  %l59 = alloca i1
  %l60 = alloca i64
  %l61 = alloca i1
  %l62 = alloca i1
  %l63 = alloca i1
  %l64 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i1
  %l67 = alloca i1
  %l68 = alloca i1
  %l69 = alloca i1
  %l70 = alloca i1
  %l71 = alloca { i1, i64, i1 }
  %l72 = alloca i64
  %l73 = alloca { i1, i64, i1 }
  %l74 = alloca { i1, i64, i1 }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca { i1, i64, i1 }
  store %"compiler/cond:Value" %a0, ptr %l0
  store %"compiler/cond:Value" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/cond:Value", ptr %l0, i32 0, i32 4
  %t2 = load i64, ptr %t1, !tbaa !24
  store i64 %t2, ptr %l4, !tbaa !24
  %t3 = load i64, ptr %l4, !tbaa !24
  %t4 = icmp ne i64 %t3, 0
  store i1 %t4, ptr %l5, !tbaa !21
  %t5 = load i1, ptr %l5, !tbaa !21
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t6 = getelementptr %"compiler/cond:Value", ptr %l1, i32 0, i32 4
  %t7 = load i64, ptr %t6, !tbaa !24
  store i64 %t7, ptr %l7, !tbaa !24
  %t8 = load i64, ptr %l7, !tbaa !24
  %t9 = icmp ne i64 %t8, 0
  store i1 %t9, ptr %l8, !tbaa !21
  %t10 = load i1, ptr %l8, !tbaa !21
  store i1 %t10, ptr %l6, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l6, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t12 = getelementptr %"compiler/cond:Value", ptr %l0, i32 0, i32 4
  %t13 = load i64, ptr %t12, !tbaa !24
  store i64 %t13, ptr %l9, !tbaa !24
  %t14 = getelementptr %"compiler/cond:Value", ptr %l1, i32 0, i32 4
  %t15 = load i64, ptr %t14, !tbaa !24
  store i64 %t15, ptr %l10, !tbaa !24
  %t16 = load i64, ptr %l9, !tbaa !24
  %t17 = load i64, ptr %l10, !tbaa !24
  %t18 = icmp eq i64 %t16, %t17
  store i1 %t18, ptr %l11, !tbaa !21
  %t19 = load i1, ptr %l11, !tbaa !21
  br i1 %t19, label %bb6, label %bb7
bb5:
  br label %bb20
bb6:
  %t20 = getelementptr %"compiler/cond:Value", ptr %l0, i32 0, i32 5
  %t21 = load i1, ptr %t20, !tbaa !21
  store i1 %t21, ptr %l13, !tbaa !21
  %t22 = getelementptr %"compiler/cond:Value", ptr %l1, i32 0, i32 5
  %t23 = load i1, ptr %t22, !tbaa !21
  store i1 %t23, ptr %l14, !tbaa !21
  %t24 = load i1, ptr %l13, !tbaa !21
  %t25 = load i1, ptr %l14, !tbaa !21
  %t26 = icmp eq i1 %t24, %t25
  store i1 %t26, ptr %l15, !tbaa !21
  %t27 = load i1, ptr %l15, !tbaa !21
  store i1 %t27, ptr %l12, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb8
bb8:
  %t28 = load i1, ptr %l12, !tbaa !21
  br i1 %t28, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t29 = getelementptr %"compiler/cond:Value", ptr %l0, i32 0, i32 4
  %t30 = load i64, ptr %t29, !tbaa !24
  store i64 %t30, ptr %l16, !tbaa !24
  %t31 = getelementptr %"compiler/cond:Value", ptr %l0, i32 0, i32 5
  %t32 = load i1, ptr %t31, !tbaa !21
  store i1 %t32, ptr %l17, !tbaa !21
  %t33 = insertvalue { i1, i64, i1 } undef, i1 true, 0
  %t34 = load i64, ptr %l16, !tbaa !24
  %t35 = insertvalue { i1, i64, i1 } %t33, i64 %t34, 1
  %t36 = load i1, ptr %l17, !tbaa !21
  %t37 = insertvalue { i1, i64, i1 } %t35, i1 %t36, 2
  store { i1, i64, i1 } %t37, ptr %l18
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t38 = load { i1, i64, i1 }, ptr %l18
  store { i1, i64, i1 } %t38, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t39 = getelementptr %"compiler/cond:Value", ptr %l0, i32 0, i32 4
  %t40 = load i64, ptr %t39, !tbaa !24
  store i64 %t40, ptr %l19, !tbaa !24
  %t41 = getelementptr %"compiler/cond:Value", ptr %l0, i32 0, i32 5
  %t42 = load i1, ptr %t41, !tbaa !21
  store i1 %t42, ptr %l20, !tbaa !21
  %t43 = getelementptr %"compiler/cond:Value", ptr %l1, i32 0, i32 4
  %t44 = load i64, ptr %t43, !tbaa !24
  store i64 %t44, ptr %l21, !tbaa !24
  %t45 = getelementptr %"compiler/cond:Value", ptr %l1, i32 0, i32 5
  %t46 = load i1, ptr %t45, !tbaa !21
  store i1 %t46, ptr %l22, !tbaa !21
  %t47 = load i64, ptr %l19, !tbaa !24
  %t48 = load i1, ptr %l20, !tbaa !21
  %t49 = load i64, ptr %l21, !tbaa !24
  %t50 = load i1, ptr %l22, !tbaa !21
  %t51 = call i1 @compiler_2fcond_2eflows(i64 %t47, i1 %t48, i64 %t49, i1 %t50)
  store i1 %t51, ptr %l23
  br label %bb12
bb12:
  %t52 = load i1, ptr %l23, !tbaa !21
  br i1 %t52, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t53 = getelementptr %"compiler/cond:Value", ptr %l1, i32 0, i32 4
  %t54 = load i64, ptr %t53, !tbaa !24
  store i64 %t54, ptr %l24, !tbaa !24
  %t55 = getelementptr %"compiler/cond:Value", ptr %l1, i32 0, i32 5
  %t56 = load i1, ptr %t55, !tbaa !21
  store i1 %t56, ptr %l25, !tbaa !21
  %t57 = insertvalue { i1, i64, i1 } undef, i1 true, 0
  %t58 = load i64, ptr %l24, !tbaa !24
  %t59 = insertvalue { i1, i64, i1 } %t57, i64 %t58, 1
  %t60 = load i1, ptr %l25, !tbaa !21
  %t61 = insertvalue { i1, i64, i1 } %t59, i1 %t60, 2
  store { i1, i64, i1 } %t61, ptr %l26
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t62 = load { i1, i64, i1 }, ptr %l26
  store { i1, i64, i1 } %t62, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t63 = getelementptr %"compiler/cond:Value", ptr %l1, i32 0, i32 4
  %t64 = load i64, ptr %t63, !tbaa !24
  store i64 %t64, ptr %l27, !tbaa !24
  %t65 = getelementptr %"compiler/cond:Value", ptr %l1, i32 0, i32 5
  %t66 = load i1, ptr %t65, !tbaa !21
  store i1 %t66, ptr %l28, !tbaa !21
  %t67 = getelementptr %"compiler/cond:Value", ptr %l0, i32 0, i32 4
  %t68 = load i64, ptr %t67, !tbaa !24
  store i64 %t68, ptr %l29, !tbaa !24
  %t69 = getelementptr %"compiler/cond:Value", ptr %l0, i32 0, i32 5
  %t70 = load i1, ptr %t69, !tbaa !21
  store i1 %t70, ptr %l30, !tbaa !21
  %t71 = load i64, ptr %l27, !tbaa !24
  %t72 = load i1, ptr %l28, !tbaa !21
  %t73 = load i64, ptr %l29, !tbaa !24
  %t74 = load i1, ptr %l30, !tbaa !21
  %t75 = call i1 @compiler_2fcond_2eflows(i64 %t71, i1 %t72, i64 %t73, i1 %t74)
  store i1 %t75, ptr %l31
  br label %bb16
bb16:
  %t76 = load i1, ptr %l31, !tbaa !21
  br i1 %t76, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s4
  %t77 = getelementptr %"compiler/cond:Value", ptr %l0, i32 0, i32 4
  %t78 = load i64, ptr %t77, !tbaa !24
  store i64 %t78, ptr %l32, !tbaa !24
  %t79 = getelementptr %"compiler/cond:Value", ptr %l0, i32 0, i32 5
  %t80 = load i1, ptr %t79, !tbaa !21
  store i1 %t80, ptr %l33, !tbaa !21
  %t81 = insertvalue { i1, i64, i1 } undef, i1 true, 0
  %t82 = load i64, ptr %l32, !tbaa !24
  %t83 = insertvalue { i1, i64, i1 } %t81, i64 %t82, 1
  %t84 = load i1, ptr %l33, !tbaa !21
  %t85 = insertvalue { i1, i64, i1 } %t83, i1 %t84, 2
  store { i1, i64, i1 } %t85, ptr %l34
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t86 = load { i1, i64, i1 }, ptr %l34
  store { i1, i64, i1 } %t86, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t87 = insertvalue { i1, i64, i1 } undef, i1 false, 0
  %t88 = insertvalue { i1, i64, i1 } %t87, i64 0, 1
  %t89 = insertvalue { i1, i64, i1 } %t88, i1 false, 2
  store { i1, i64, i1 } %t89, ptr %l35
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t90 = load { i1, i64, i1 }, ptr %l35
  store { i1, i64, i1 } %t90, ptr %rv
  br label %ret
bb20:
  %t91 = getelementptr %"compiler/cond:Value", ptr %l0, i32 0, i32 4
  %t92 = load i64, ptr %t91, !tbaa !24
  store i64 %t92, ptr %l36, !tbaa !24
  %t93 = load i64, ptr %l36, !tbaa !24
  %t94 = icmp ne i64 %t93, 0
  store i1 %t94, ptr %l37, !tbaa !21
  %t95 = load i1, ptr %l37, !tbaa !21
  br i1 %t95, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb23
bb22:
  %t96 = getelementptr %"compiler/cond:Value", ptr %l1, i32 0, i32 4
  %t97 = load i64, ptr %t96, !tbaa !24
  store i64 %t97, ptr %l39, !tbaa !24
  %t98 = load i64, ptr %l39, !tbaa !24
  %t99 = icmp ne i64 %t98, 0
  store i1 %t99, ptr %l40, !tbaa !21
  %t100 = load i1, ptr %l40, !tbaa !21
  store i1 %t100, ptr %l38, !tbaa !21
  br label %bb23
bb23:
  %t101 = load i1, ptr %l38, !tbaa !21
  br i1 %t101, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s5
  %t102 = getelementptr %"compiler/cond:Value", ptr %l0, i32 0, i32 4
  %t103 = load i64, ptr %t102, !tbaa !24
  store i64 %t103, ptr %l41, !tbaa !24
  %t104 = load i64, ptr %l41, !tbaa !24
  %t105 = icmp ne i64 %t104, 0
  store i1 %t105, ptr %l42, !tbaa !21
  %t106 = load i1, ptr %l42, !tbaa !21
  br i1 %t106, label %bb26, label %bb27
bb25:
  br label %bb46
bb26:
  %t107 = load %"compiler/cond:Value", ptr %l0
  store %"compiler/cond:Value" %t107, ptr %l44
  %t108 = load %"compiler/cond:Value", ptr %l44
  store %"compiler/cond:Value" %t108, ptr %l43
  br label %bb28
bb27:
  %t109 = load %"compiler/cond:Value", ptr %l1
  store %"compiler/cond:Value" %t109, ptr %l45
  %t110 = load %"compiler/cond:Value", ptr %l45
  store %"compiler/cond:Value" %t110, ptr %l43
  br label %bb28
bb28:
  %t111 = load %"compiler/cond:Value", ptr %l43
  store %"compiler/cond:Value" %t111, ptr %l2
  %t112 = getelementptr %"compiler/cond:Value", ptr %l0, i32 0, i32 4
  %t113 = load i64, ptr %t112, !tbaa !24
  store i64 %t113, ptr %l46, !tbaa !24
  %t114 = load i64, ptr %l46, !tbaa !24
  %t115 = icmp ne i64 %t114, 0
  store i1 %t115, ptr %l47, !tbaa !21
  %t116 = load i1, ptr %l47, !tbaa !21
  br i1 %t116, label %bb29, label %bb30
bb29:
  %t117 = load %"compiler/cond:Value", ptr %l1
  store %"compiler/cond:Value" %t117, ptr %l49
  %t118 = load %"compiler/cond:Value", ptr %l49
  store %"compiler/cond:Value" %t118, ptr %l48
  br label %bb31
bb30:
  %t119 = load %"compiler/cond:Value", ptr %l0
  store %"compiler/cond:Value" %t119, ptr %l50
  %t120 = load %"compiler/cond:Value", ptr %l50
  store %"compiler/cond:Value" %t120, ptr %l48
  br label %bb31
bb31:
  %t121 = load %"compiler/cond:Value", ptr %l48
  store %"compiler/cond:Value" %t121, ptr %l3
  %t122 = getelementptr %"compiler/cond:Value", ptr %l3, i32 0, i32 1
  %t123 = load i64, ptr %t122, !tbaa !24
  store i64 %t123, ptr %l51, !tbaa !24
  %t124 = getelementptr %"compiler/cond:Value", ptr %l2, i32 0, i32 4
  %t125 = load i64, ptr %t124, !tbaa !24
  store i64 %t125, ptr %l52, !tbaa !24
  %t126 = getelementptr %"compiler/cond:Value", ptr %l2, i32 0, i32 5
  %t127 = load i1, ptr %t126, !tbaa !21
  store i1 %t127, ptr %l53, !tbaa !21
  %t128 = load i64, ptr %l51, !tbaa !24
  %t129 = load i64, ptr %l52, !tbaa !24
  %t130 = load i1, ptr %l53, !tbaa !21
  %t131 = call i1 @compiler_2fcond_2efits(i64 %t128, i64 %t129, i1 %t130)
  store i1 %t131, ptr %l54
  br label %bb32
bb32:
  %t132 = load i1, ptr %l54, !tbaa !21
  br i1 %t132, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s6
  %t133 = getelementptr %"compiler/cond:Value", ptr %l2, i32 0, i32 4
  %t134 = load i64, ptr %t133, !tbaa !24
  store i64 %t134, ptr %l55, !tbaa !24
  %t135 = getelementptr %"compiler/cond:Value", ptr %l2, i32 0, i32 5
  %t136 = load i1, ptr %t135, !tbaa !21
  store i1 %t136, ptr %l56, !tbaa !21
  %t137 = insertvalue { i1, i64, i1 } undef, i1 true, 0
  %t138 = load i64, ptr %l55, !tbaa !24
  %t139 = insertvalue { i1, i64, i1 } %t137, i64 %t138, 1
  %t140 = load i1, ptr %l56, !tbaa !21
  %t141 = insertvalue { i1, i64, i1 } %t139, i1 %t140, 2
  store { i1, i64, i1 } %t141, ptr %l57
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t142 = load { i1, i64, i1 }, ptr %l57
  store { i1, i64, i1 } %t142, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  %t143 = getelementptr %"compiler/cond:Value", ptr %l2, i32 0, i32 4
  %t144 = load i64, ptr %t143, !tbaa !24
  store i64 %t144, ptr %l58, !tbaa !24
  %t145 = getelementptr %"compiler/cond:Value", ptr %l2, i32 0, i32 5
  %t146 = load i1, ptr %t145, !tbaa !21
  store i1 %t146, ptr %l59, !tbaa !21
  %t147 = load i64, ptr @G_2ecompiler_2fcond_2eLiteralIntBits, !tbaa !24
  store i64 %t147, ptr %l60, !tbaa !24
  %t148 = load i64, ptr %l58, !tbaa !24
  %t149 = load i1, ptr %l59, !tbaa !21
  %t150 = load i64, ptr %l60, !tbaa !24
  %t151 = call i1 @compiler_2fcond_2eflows(i64 %t148, i1 %t149, i64 %t150, i1 false)
  store i1 %t151, ptr %l61
  br label %bb36
bb36:
  %t152 = load i1, ptr %l61, !tbaa !21
  %t153 = xor i1 %t152, true
  store i1 %t153, ptr %l62, !tbaa !21
  %t154 = load i1, ptr %l62, !tbaa !21
  br i1 %t154, label %bb37, label %bb38
bb37:
  %t155 = getelementptr %"compiler/cond:Value", ptr %l2, i32 0, i32 4
  %t156 = load i64, ptr %t155, !tbaa !24
  store i64 %t156, ptr %l64, !tbaa !24
  %t157 = load i64, ptr @G_2ecompiler_2fcond_2eLiteralIntBits, !tbaa !24
  store i64 %t157, ptr %l65, !tbaa !24
  %t158 = load i64, ptr %l64, !tbaa !24
  %t159 = load i64, ptr %l65, !tbaa !24
  %t160 = icmp eq i64 %t158, %t159
  store i1 %t160, ptr %l66, !tbaa !21
  %t161 = load i1, ptr %l66, !tbaa !21
  br i1 %t161, label %bb39, label %bb40
bb38:
  store i1 false, ptr %l63, !tbaa !21
  br label %bb42
bb39:
  %t162 = getelementptr %"compiler/cond:Value", ptr %l2, i32 0, i32 5
  %t163 = load i1, ptr %t162, !tbaa !21
  store i1 %t163, ptr %l68, !tbaa !21
  %t164 = load i1, ptr %l68, !tbaa !21
  %t165 = xor i1 %t164, true
  store i1 %t165, ptr %l69, !tbaa !21
  %t166 = load i1, ptr %l69, !tbaa !21
  store i1 %t166, ptr %l67, !tbaa !21
  br label %bb41
bb40:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb41
bb41:
  %t167 = load i1, ptr %l67, !tbaa !21
  %t168 = xor i1 %t167, true
  store i1 %t168, ptr %l70, !tbaa !21
  %t169 = load i1, ptr %l70, !tbaa !21
  store i1 %t169, ptr %l63, !tbaa !21
  br label %bb42
bb42:
  %t170 = load i1, ptr %l63, !tbaa !21
  br i1 %t170, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s7
  %t171 = insertvalue { i1, i64, i1 } undef, i1 false, 0
  %t172 = insertvalue { i1, i64, i1 } %t171, i64 0, 1
  %t173 = insertvalue { i1, i64, i1 } %t172, i1 false, 2
  store { i1, i64, i1 } %t173, ptr %l71
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t174 = load { i1, i64, i1 }, ptr %l71
  store { i1, i64, i1 } %t174, ptr %rv
  br label %ret
bb44:
  br label %bb45
bb45:
  %t175 = load i64, ptr @G_2ecompiler_2fcond_2eLiteralIntBits, !tbaa !24
  store i64 %t175, ptr %l72, !tbaa !24
  %t176 = insertvalue { i1, i64, i1 } undef, i1 true, 0
  %t177 = load i64, ptr %l72, !tbaa !24
  %t178 = insertvalue { i1, i64, i1 } %t176, i64 %t177, 1
  %t179 = insertvalue { i1, i64, i1 } %t178, i1 false, 2
  store { i1, i64, i1 } %t179, ptr %l73
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t180 = load { i1, i64, i1 }, ptr %l73
  store { i1, i64, i1 } %t180, ptr %rv
  br label %ret
bb46:
  %t181 = insertvalue { i1, i64, i1 } undef, i1 true, 0
  %t182 = insertvalue { i1, i64, i1 } %t181, i64 0, 1
  %t183 = insertvalue { i1, i64, i1 } %t182, i1 false, 2
  store { i1, i64, i1 } %t183, ptr %l74
  call void @__olang_scope_close(ptr %s0)
  %t184 = load { i1, i64, i1 }, ptr %l74
  store { i1, i64, i1 } %t184, ptr %rv
  br label %ret
ret:
  %rr = load { i1, i64, i1 }, ptr %rv
  ret { i1, i64, i1 } %rr
}

define dso_local %"compiler/cond:Value" @compiler_2fcond_2enone() #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/cond:Value"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/cond:Value"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 0, ptr %l0
  %t1 = load i32, ptr %l0
  %t2 = call %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %s0, i32 %t1, i64 0, double 0x0000000000000000, i64 0, i64 0, i1 false)
  store %"compiler/cond:Value" %t2, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"compiler/cond:Value", ptr %l1
  store %"compiler/cond:Value" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cond:Value", ptr %rv
  ret %"compiler/cond:Value" %rr
}

define dso_local i1 @compiler_2fcond_2enumeric(%"compiler/cond:Value" %a0) #0 {
entry:
  %l0 = alloca %"compiler/cond:Value"
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i1
  %l6 = alloca i1
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store %"compiler/cond:Value" %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/cond:Value", ptr %l0, i32 0, i32 0
  %t2 = load i32, ptr %t1
  store i32 %t2, ptr %l1
  store ptr %l1, ptr %l2, !tbaa !29
  store i32 2, ptr %l3
  store ptr %l3, ptr %l4, !tbaa !29
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t4 = load ptr, ptr %l4, !tbaa !29
  %t5 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %t3, ptr %t4)
  store i1 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i1, ptr %l5, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb5
bb3:
  %t7 = getelementptr %"compiler/cond:Value", ptr %l0, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l7
  store ptr %l7, ptr %l8, !tbaa !29
  store i32 3, ptr %l9
  store ptr %l9, ptr %l10, !tbaa !29
  %t9 = load ptr, ptr %l8, !tbaa !29
  %t10 = load ptr, ptr %l10, !tbaa !29
  %t11 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %t9, ptr %t10)
  store i1 %t11, ptr %l11
  br label %bb4
bb4:
  %t12 = load i1, ptr %l11, !tbaa !21
  store i1 %t12, ptr %l6, !tbaa !21
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t13 = load i1, ptr %l6, !tbaa !21
  store i1 %t13, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fcond_2estripped(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i8
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i1
  %l13 = alloca i1
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i8
  %l17 = alloca i8
  %l18 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i8
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l6
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t3, ptr %l7, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t5, ptr %l8, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 0
  store i64 %t7, ptr %l9, !tbaa !24
  %t8 = load i64, ptr %l9, !tbaa !24
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t9 = load i64, ptr %l3, !tbaa !24
  store i64 %t9, ptr %l10, !tbaa !24
  %t10 = load i64, ptr %l4, !tbaa !24
  store i64 %t10, ptr %l11, !tbaa !24
  %t11 = load i64, ptr %l10, !tbaa !24
  %t12 = load i64, ptr %l11, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  store i1 %t13, ptr %l12, !tbaa !21
  %t14 = load i1, ptr %l12, !tbaa !21
  %t15 = xor i1 %t14, true
  store i1 %t15, ptr %l13, !tbaa !21
  %t16 = load i1, ptr %l13, !tbaa !21
  br i1 %t16, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t17, ptr %l14, !tbaa !27
  %t18 = load i64, ptr %l3, !tbaa !24
  store i64 %t18, ptr %l15, !tbaa !24
  %t19 = load i64, ptr %l15, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr i8, ptr %t21, i64 %t19
  %t23 = load i8, ptr %t22, !tbaa !32
  store i8 %t23, ptr %l16, !tbaa !22
  %t24 = load i8, ptr %l16, !tbaa !22
  store i8 %t24, ptr %l5, !tbaa !22
  %t25 = load i8, ptr %l5, !tbaa !22
  store i8 %t25, ptr %l17, !tbaa !22
  %t26 = load i8, ptr %l17, !tbaa !22
  %t27 = icmp ne i8 %t26, 95
  store i1 %t27, ptr %l18, !tbaa !21
  %t28 = load i1, ptr %l18, !tbaa !21
  br i1 %t28, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  store ptr %l1, ptr %l19, !tbaa !29
  %t29 = load i8, ptr %l5, !tbaa !22
  store i8 %t29, ptr %l20, !tbaa !22
  %t30 = load ptr, ptr %l19, !tbaa !29
  %t31 = load i8, ptr %l20, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t30, i8 %t31)
  br label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_scope_close(ptr %s3)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s4
  %t32 = load i64, ptr %l3, !tbaa !24
  store i64 %t32, ptr %l21, !tbaa !24
  %t33 = load i64, ptr %l21, !tbaa !24
  %t34 = add i64 %t33, 1
  store i64 %t34, ptr %l22, !tbaa !24
  %t35 = load i64, ptr %l22, !tbaa !24
  store i64 %t35, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb2
bb11:
  call void @__olang_scope_close(ptr %s1)
  store ptr %l1, ptr %l23, !tbaa !29
  %t36 = load ptr, ptr %l23, !tbaa !29
  %t37 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %t36)
  store { i64, ptr } %t37, ptr %l24
  br label %bb12
bb12:
  %t38 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t38, ptr %l25, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  store i64 %t40, ptr %l26, !tbaa !24
  %t41 = load i64, ptr %l26, !tbaa !24
  %t42 = mul i64 %t41, 1
  %t43 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t42)
  %t44 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  store { i64, ptr } %t45, ptr %l27, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = load i64, ptr %l26, !tbaa !24
  %t51 = mul i64 %t50, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t47, ptr %t49, i64 %t51, i1 false)
  %t52 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t52, ptr %l25, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t53 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t53, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/cond:Consts" @compiler_2fcond_3aConsts_2ector(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l1 = alloca %"std/prelude/list:List<compiler/cond:Value>"
  %l2 = alloca %"std/prelude/list:List<Bool>"
  %l3 = alloca %"std/prelude/list:List<Bool>"
  %l4 = alloca %"std/prelude/list:List<Bool>"
  %l5 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l6 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l7 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l8 = alloca %"std/prelude/list:List<compiler/cond:Value>"
  %l9 = alloca %"std/prelude/list:List<Bool>"
  %l10 = alloca %"std/prelude/list:List<Bool>"
  %l11 = alloca %"std/prelude/list:List<Bool>"
  %l12 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l13 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l14 = alloca %"compiler/cond:Consts"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/cond:Consts"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<std/prelude/text:String&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t1)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t2, ptr %l7
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l7
  store %"std/prelude/list:List<std/prelude/text:String&>" %t3, ptr %l0
  %t4 = load ptr, ptr @__olang_prog_scope
  %t5 = call %"std/prelude/list:List<compiler/cond:Value>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fcond_3aValue_3e(ptr %t4)
  store %"std/prelude/list:List<compiler/cond:Value>" %t5, ptr %l8
  br label %bb2
bb2:
  %t6 = load %"std/prelude/list:List<compiler/cond:Value>", ptr %l8
  store %"std/prelude/list:List<compiler/cond:Value>" %t6, ptr %l1
  %t7 = load ptr, ptr @__olang_prog_scope
  %t8 = call %"std/prelude/list:List<Bool>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cBool_3e(ptr %t7)
  store %"std/prelude/list:List<Bool>" %t8, ptr %l9
  br label %bb3
bb3:
  %t9 = load %"std/prelude/list:List<Bool>", ptr %l9
  store %"std/prelude/list:List<Bool>" %t9, ptr %l2
  %t10 = load ptr, ptr @__olang_prog_scope
  %t11 = call %"std/prelude/list:List<Bool>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cBool_3e(ptr %t10)
  store %"std/prelude/list:List<Bool>" %t11, ptr %l10
  br label %bb4
bb4:
  %t12 = load %"std/prelude/list:List<Bool>", ptr %l10
  store %"std/prelude/list:List<Bool>" %t12, ptr %l3
  %t13 = load ptr, ptr @__olang_prog_scope
  %t14 = call %"std/prelude/list:List<Bool>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cBool_3e(ptr %t13)
  store %"std/prelude/list:List<Bool>" %t14, ptr %l11
  br label %bb5
bb5:
  %t15 = load %"std/prelude/list:List<Bool>", ptr %l11
  store %"std/prelude/list:List<Bool>" %t15, ptr %l4
  %t16 = load ptr, ptr @__olang_prog_scope
  %t17 = call %"std/prelude/list:List<std/prelude/text:String&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t16)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t17, ptr %l12
  br label %bb6
bb6:
  %t18 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l12
  store %"std/prelude/list:List<std/prelude/text:String&>" %t18, ptr %l5
  %t19 = load ptr, ptr @__olang_prog_scope
  %t20 = call %"std/prelude/list:List<std/prelude/text:String&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t19)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t20, ptr %l13
  br label %bb7
bb7:
  %t21 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l13
  store %"std/prelude/list:List<std/prelude/text:String&>" %t21, ptr %l6
  %t22 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l0
  %t23 = insertvalue %"compiler/cond:Consts" undef, %"std/prelude/list:List<std/prelude/text:String&>" %t22, 0
  %t24 = load %"std/prelude/list:List<compiler/cond:Value>", ptr %l1
  %t25 = insertvalue %"compiler/cond:Consts" %t23, %"std/prelude/list:List<compiler/cond:Value>" %t24, 1
  %t26 = load %"std/prelude/list:List<Bool>", ptr %l2
  %t27 = insertvalue %"compiler/cond:Consts" %t25, %"std/prelude/list:List<Bool>" %t26, 2
  %t28 = load %"std/prelude/list:List<Bool>", ptr %l3
  %t29 = insertvalue %"compiler/cond:Consts" %t27, %"std/prelude/list:List<Bool>" %t28, 3
  %t30 = load %"std/prelude/list:List<Bool>", ptr %l4
  %t31 = insertvalue %"compiler/cond:Consts" %t29, %"std/prelude/list:List<Bool>" %t30, 4
  %t32 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l5
  %t33 = insertvalue %"compiler/cond:Consts" %t31, %"std/prelude/list:List<std/prelude/text:String&>" %t32, 5
  %t34 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l6
  %t35 = insertvalue %"compiler/cond:Consts" %t33, %"std/prelude/list:List<std/prelude/text:String&>" %t34, 6
  store %"compiler/cond:Consts" %t35, ptr %l14
  call void @__olang_scope_close(ptr %s0)
  %t36 = load %"compiler/cond:Consts", ptr %l14
  store %"compiler/cond:Consts" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cond:Consts", ptr %rv
  ret %"compiler/cond:Consts" %rr
}

define dso_local %"compiler/cond:Eval" @compiler_2fcond_3aEval_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i1
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca %"compiler/source:Span"
  %l12 = alloca %"compiler/msgs:Msg"
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i1
  %l16 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l17 = alloca { i64, ptr }
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca %"compiler/source:Span"
  %l22 = alloca %"compiler/msgs:Msg"
  %l23 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l24 = alloca %"compiler/cond:Eval"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/cond:Eval"
  store { i64, ptr } %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l17, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t2, ptr %l4, !tbaa !27
  %t3 = load ptr, ptr %l1, !tbaa !29
  store ptr %t3, ptr %l18, !tbaa !29
  %t4 = load ptr, ptr %l18, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  store ptr %t5, ptr %l19, !tbaa !29
  %t6 = load ptr, ptr %l19, !tbaa !29
  store ptr %t6, ptr %l6, !tbaa !29
  %t7 = load ptr, ptr %l3, !tbaa !29
  store ptr %t7, ptr %l20, !tbaa !29
  %t8 = load ptr, ptr %l20, !tbaa !29
  store ptr %t8, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  store i1 false, ptr %l9, !tbaa !21
  store i1 false, ptr %l10, !tbaa !21
  %t9 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v4, i32 0, i32 0)
  store %"compiler/source:Span" %t9, ptr %l21
  br label %bb1
bb1:
  %t10 = load %"compiler/source:Span", ptr %l21
  store %"compiler/source:Span" %t10, ptr %l11
  %t11 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondNotBool(ptr %v4, ptr %v4, { i64, ptr } { i64 0, ptr @.d60 })
  store %"compiler/msgs:Msg" %t11, ptr %l22
  br label %bb2
bb2:
  %t12 = load %"compiler/msgs:Msg", ptr %l22
  store %"compiler/msgs:Msg" %t12, ptr %l12
  store i64 0, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  store i1 false, ptr %l15, !tbaa !21
  %t13 = load ptr, ptr @__olang_prog_scope
  %t14 = call %"std/prelude/list:List<std/prelude/text:String&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t13)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t14, ptr %l23
  br label %bb3
bb3:
  %t15 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l23
  store %"std/prelude/list:List<std/prelude/text:String&>" %t15, ptr %l16
  %t16 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t17 = insertvalue %"compiler/cond:Eval" undef, { i64, ptr } %t16, 0
  %t18 = load ptr, ptr %l5, !tbaa !29
  %t19 = insertvalue %"compiler/cond:Eval" %t17, ptr %t18, 1
  %t20 = load ptr, ptr %l6, !tbaa !29
  %t21 = insertvalue %"compiler/cond:Eval" %t19, ptr %t20, 2
  %t22 = load ptr, ptr %l7, !tbaa !29
  %t23 = insertvalue %"compiler/cond:Eval" %t21, ptr %t22, 3
  %t24 = load i1, ptr %l8, !tbaa !21
  %t25 = insertvalue %"compiler/cond:Eval" %t23, i1 %t24, 4
  %t26 = load i1, ptr %l9, !tbaa !21
  %t27 = insertvalue %"compiler/cond:Eval" %t25, i1 %t26, 5
  %t28 = load i1, ptr %l10, !tbaa !21
  %t29 = insertvalue %"compiler/cond:Eval" %t27, i1 %t28, 6
  %t30 = load %"compiler/source:Span", ptr %l11
  %t31 = insertvalue %"compiler/cond:Eval" %t29, %"compiler/source:Span" %t30, 7
  %t32 = load %"compiler/msgs:Msg", ptr %l12
  %t33 = insertvalue %"compiler/cond:Eval" %t31, %"compiler/msgs:Msg" %t32, 8
  %t34 = load i64, ptr %l13, !tbaa !24
  %t35 = insertvalue %"compiler/cond:Eval" %t33, i64 %t34, 9
  %t36 = load i64, ptr %l14, !tbaa !24
  %t37 = insertvalue %"compiler/cond:Eval" %t35, i64 %t36, 10
  %t38 = load i1, ptr %l15, !tbaa !21
  %t39 = insertvalue %"compiler/cond:Eval" %t37, i1 %t38, 11
  %t40 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l16
  %t41 = insertvalue %"compiler/cond:Eval" %t39, %"std/prelude/list:List<std/prelude/text:String&>" %t40, 12
  store %"compiler/cond:Eval" %t41, ptr %l24
  call void @__olang_scope_close(ptr %s0)
  %t42 = load %"compiler/cond:Eval", ptr %l24
  store %"compiler/cond:Eval" %t42, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cond:Eval", ptr %rv
  ret %"compiler/cond:Eval" %rr
}

define dso_local %"compiler/cond:Global" @compiler_2fcond_3aGlobal_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, %"compiler/source:Span" %a1, i1 %a2, { i64, ptr } %a3, ptr %a4, i1 %a5) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca i1
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca i1
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l11 = alloca i1
  %l12 = alloca { i64, ptr }
  %l13 = alloca %"compiler/source:Span"
  %l14 = alloca i1
  %l15 = alloca { i64, ptr }
  %l16 = alloca ptr
  %l17 = alloca i1
  %l18 = alloca %"compiler/cond:Global"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/cond:Global"
  store { i64, ptr } %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i1 %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store ptr %a4, ptr %l4
  store i1 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l12, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t2, ptr %l6, !tbaa !27
  %t3 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t3, ptr %l13
  %t4 = load %"compiler/source:Span", ptr %l13
  store %"compiler/source:Span" %t4, ptr %l7
  %t5 = load i1, ptr %l2, !tbaa !21
  store i1 %t5, ptr %l14, !tbaa !21
  %t6 = load i1, ptr %l14, !tbaa !21
  store i1 %t6, ptr %l8, !tbaa !21
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t7, ptr %l15, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t8, ptr %l9, !tbaa !27
  %t9 = load ptr, ptr %l4, !tbaa !29
  store ptr %t9, ptr %l16, !tbaa !29
  %t10 = load ptr, ptr %l16, !tbaa !29
  store ptr %t10, ptr %l10, !tbaa !29
  %t11 = load i1, ptr %l5, !tbaa !21
  store i1 %t11, ptr %l17, !tbaa !21
  %t12 = load i1, ptr %l17, !tbaa !21
  store i1 %t12, ptr %l11, !tbaa !21
  %t13 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t14 = insertvalue %"compiler/cond:Global" undef, { i64, ptr } %t13, 0
  %t15 = load %"compiler/source:Span", ptr %l7
  %t16 = insertvalue %"compiler/cond:Global" %t14, %"compiler/source:Span" %t15, 1
  %t17 = load i1, ptr %l8, !tbaa !21
  %t18 = insertvalue %"compiler/cond:Global" %t16, i1 %t17, 2
  %t19 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t20 = insertvalue %"compiler/cond:Global" %t18, { i64, ptr } %t19, 3
  %t21 = load ptr, ptr %l10, !tbaa !29
  %t22 = insertvalue %"compiler/cond:Global" %t20, ptr %t21, 4
  %t23 = load i1, ptr %l11, !tbaa !21
  %t24 = insertvalue %"compiler/cond:Global" %t22, i1 %t23, 5
  store %"compiler/cond:Global" %t24, ptr %l18
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/cond:Global", ptr %l18
  store %"compiler/cond:Global" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cond:Global", ptr %rv
  ret %"compiler/cond:Global" %rr
}

define dso_local %"compiler/cond:Scope" @compiler_2fcond_3aScope_2ector(ptr %v0, i1 %a0) #0 {
entry:
  %l0 = alloca i1
  %l1 = alloca i1
  %l2 = alloca %"std/prelude/list:List<compiler/cond:Global&>"
  %l3 = alloca %"std/prelude/list:List<compiler/source:NameId>"
  %l4 = alloca %"std/prelude/list:List<compiler/source:NameId>"
  %l5 = alloca i1
  %l6 = alloca %"std/prelude/list:List<compiler/cond:Global&>"
  %l7 = alloca %"std/prelude/list:List<compiler/source:NameId>"
  %l8 = alloca %"std/prelude/list:List<compiler/source:NameId>"
  %l9 = alloca %"compiler/cond:Scope"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/cond:Scope"
  store i1 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i1, ptr %l0, !tbaa !21
  store i1 %t1, ptr %l5, !tbaa !21
  %t2 = load i1, ptr %l5, !tbaa !21
  store i1 %t2, ptr %l1, !tbaa !21
  %t3 = load ptr, ptr @__olang_prog_scope
  %t4 = call %"std/prelude/list:List<compiler/cond:Global&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fcond_3aGlobal_26_3e(ptr %t3)
  store %"std/prelude/list:List<compiler/cond:Global&>" %t4, ptr %l6
  br label %bb1
bb1:
  %t5 = load %"std/prelude/list:List<compiler/cond:Global&>", ptr %l6
  store %"std/prelude/list:List<compiler/cond:Global&>" %t5, ptr %l2
  %t6 = load ptr, ptr @__olang_prog_scope
  %t7 = call %"std/prelude/list:List<compiler/source:NameId>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e(ptr %t6)
  store %"std/prelude/list:List<compiler/source:NameId>" %t7, ptr %l7
  br label %bb2
bb2:
  %t8 = load %"std/prelude/list:List<compiler/source:NameId>", ptr %l7
  store %"std/prelude/list:List<compiler/source:NameId>" %t8, ptr %l3
  %t9 = load ptr, ptr @__olang_prog_scope
  %t10 = call %"std/prelude/list:List<compiler/source:NameId>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e(ptr %t9)
  store %"std/prelude/list:List<compiler/source:NameId>" %t10, ptr %l8
  br label %bb3
bb3:
  %t11 = load %"std/prelude/list:List<compiler/source:NameId>", ptr %l8
  store %"std/prelude/list:List<compiler/source:NameId>" %t11, ptr %l4
  %t12 = load i1, ptr %l1, !tbaa !21
  %t13 = insertvalue %"compiler/cond:Scope" undef, i1 %t12, 0
  %t14 = load %"std/prelude/list:List<compiler/cond:Global&>", ptr %l2
  %t15 = insertvalue %"compiler/cond:Scope" %t13, %"std/prelude/list:List<compiler/cond:Global&>" %t14, 1
  %t16 = load %"std/prelude/list:List<compiler/source:NameId>", ptr %l3
  %t17 = insertvalue %"compiler/cond:Scope" %t15, %"std/prelude/list:List<compiler/source:NameId>" %t16, 2
  %t18 = load %"std/prelude/list:List<compiler/source:NameId>", ptr %l4
  %t19 = insertvalue %"compiler/cond:Scope" %t17, %"std/prelude/list:List<compiler/source:NameId>" %t18, 3
  store %"compiler/cond:Scope" %t19, ptr %l9
  call void @__olang_scope_close(ptr %s0)
  %t20 = load %"compiler/cond:Scope", ptr %l9
  store %"compiler/cond:Scope" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cond:Scope", ptr %rv
  ret %"compiler/cond:Scope" %rr
}

define dso_local %"compiler/cond:Value" @compiler_2fcond_3aValue_2ector(ptr %v0, i32 %a0, i64 %a1, double %a2, i64 %a3, i64 %a4, i1 %a5) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i64
  %l2 = alloca double
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i1
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca double
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i1
  %l12 = alloca i32
  %l13 = alloca i64
  %l14 = alloca double
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i1
  %l18 = alloca %"compiler/cond:Value"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/cond:Value"
  store i32 %a0, ptr %l0
  store i64 %a1, ptr %l1
  store double %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i64 %a4, ptr %l4
  store i1 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l0
  store i32 %t1, ptr %l12
  %t2 = load i32, ptr %l12
  store i32 %t2, ptr %l6
  %t3 = load i64, ptr %l1, !tbaa !24
  store i64 %t3, ptr %l13, !tbaa !24
  %t4 = load i64, ptr %l13, !tbaa !24
  store i64 %t4, ptr %l7, !tbaa !24
  %t5 = load double, ptr %l2, !tbaa !26
  store double %t5, ptr %l14, !tbaa !26
  %t6 = load double, ptr %l14, !tbaa !26
  store double %t6, ptr %l8, !tbaa !26
  %t7 = load i64, ptr %l3, !tbaa !24
  store i64 %t7, ptr %l15, !tbaa !24
  %t8 = load i64, ptr %l15, !tbaa !24
  store i64 %t8, ptr %l9, !tbaa !24
  %t9 = load i64, ptr %l4, !tbaa !24
  store i64 %t9, ptr %l16, !tbaa !24
  %t10 = load i64, ptr %l16, !tbaa !24
  store i64 %t10, ptr %l10, !tbaa !24
  %t11 = load i1, ptr %l5, !tbaa !21
  store i1 %t11, ptr %l17, !tbaa !21
  %t12 = load i1, ptr %l17, !tbaa !21
  store i1 %t12, ptr %l11, !tbaa !21
  %t13 = load i32, ptr %l6
  %t14 = insertvalue %"compiler/cond:Value" undef, i32 %t13, 0
  %t15 = load i64, ptr %l7, !tbaa !24
  %t16 = insertvalue %"compiler/cond:Value" %t14, i64 %t15, 1
  %t17 = load double, ptr %l8, !tbaa !26
  %t18 = insertvalue %"compiler/cond:Value" %t16, double %t17, 2
  %t19 = load i64, ptr %l9, !tbaa !24
  %t20 = insertvalue %"compiler/cond:Value" %t18, i64 %t19, 3
  %t21 = load i64, ptr %l10, !tbaa !24
  %t22 = insertvalue %"compiler/cond:Value" %t20, i64 %t21, 4
  %t23 = load i1, ptr %l11, !tbaa !21
  %t24 = insertvalue %"compiler/cond:Value" %t22, i1 %t23, 5
  store %"compiler/cond:Value" %t24, ptr %l18
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/cond:Value", ptr %l18
  store %"compiler/cond:Value" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cond:Value", ptr %rv
  ret %"compiler/cond:Value" %rr
}

define dso_local void @olang_2einit_2ecompiler_2fcond() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  call void @compiler_2fcond_2eLiteralIntBits_2einit()
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_check_failed(ptr)
@.c0 = private unnamed_addr constant [51 x i8] c"compiler/cond.olang:512: reached unreachable code\0A\00"
@.d1 = private constant [0 x i8] c""
@.d2 = private constant [8 x i8] c"TargetOs"
@.d3 = private constant [0 x i8] c""
@.d4 = private constant [10 x i8] c"TargetArch"
@.d5 = private constant [0 x i8] c""
@.d6 = private constant [9 x i8] c"TargetCpu"
@.d7 = private constant [16 x i8] c"TargetVectorBits"
@.d8 = private constant [12 x i8] c"TargetHasFma"
@.d9 = private constant [10 x i8] c"DebugBuild"
@.d10 = private constant [9 x i8] c"RaceBuild"
@.d11 = private constant [9 x i8] c"TestBuild"
@.c12 = private unnamed_addr constant [52 x i8] c"compiler/cond.olang:133: slice bounds out of range\0A\00"
@.c13 = private unnamed_addr constant [52 x i8] c"compiler/cond.olang:134: slice bounds out of range\0A\00"
@.d14 = private constant [4 x i8] c"Bool"
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aValueKind(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %t1
  %t3 = sext i32 %t2 to i64
  store i64 %t3, ptr %l3, !tbaa !24
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t5 = load i32, ptr %t4
  %t6 = sext i32 %t5 to i64
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t9 = icmp eq i64 %t7, %t8
  store i1 %t9, ptr %l5, !tbaa !21
  %t10 = load i1, ptr %l5, !tbaa !21
  br i1 %t10, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb3
bb2:
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t11 = load i1, ptr %l2, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d15 = private constant [6 x i8] c"String"
@.d16 = private constant [3 x i8] c"I32"
@.d17 = private constant [3 x i8] c"I64"
@.d18 = private constant [3 x i8] c"U64"
@.d19 = private constant [3 x i8] c"F64"
@.c20 = private unnamed_addr constant [51 x i8] c"compiler/cond.olang:185: reached unreachable code\0A\00"
@.d21 = private constant [0 x i8] c""
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @__olang_sb_put(ptr, ptr, i64)
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare void @__olang_sb_done(ptr)
@.d22 = private constant [0 x i8] c""
@.c23 = private unnamed_addr constant [52 x i8] c"compiler/cond.olang:154: slice bounds out of range\0A\00"
@.c24 = private unnamed_addr constant [52 x i8] c"compiler/cond.olang:155: slice bounds out of range\0A\00"
@.d25 = private constant [4 x i8] c"true"
@.d26 = private constant [5 x i8] c"false"
@.d27 = private constant [4 x i8] c"true"
@.c28 = private unnamed_addr constant [52 x i8] c"compiler/cond.olang:210: slice bounds out of range\0A\00"
@.c29 = private unnamed_addr constant [52 x i8] c"compiler/cond.olang:213: slice bounds out of range\0A\00"
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %t1
  %t3 = sext i32 %t2 to i64
  store i64 %t3, ptr %l3, !tbaa !24
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t5 = load i32, ptr %t4
  %t6 = sext i32 %t5 to i64
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t9 = icmp eq i64 %t7, %t8
  store i1 %t9, ptr %l5, !tbaa !21
  %t10 = load i1, ptr %l5, !tbaa !21
  br i1 %t10, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb3
bb2:
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t11 = load i1, ptr %l2, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d30 = private constant [0 x i8] c""
@.c31 = private unnamed_addr constant [51 x i8] c"compiler/cond.olang:601: reached unreachable code\0A\00"
@.c32 = private unnamed_addr constant [51 x i8] c"compiler/cond.olang:808: reached unreachable code\0A\00"
@.c33 = private unnamed_addr constant [51 x i8] c"compiler/cond.olang:438: reached unreachable code\0A\00"
@.c34 = private unnamed_addr constant [51 x i8] c"compiler/cond.olang:426: reached unreachable code\0A\00"
@.d35 = private constant [0 x i8] c""
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmsgs_3aDiag(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %t1
  %t3 = sext i32 %t2 to i64
  store i64 %t3, ptr %l3, !tbaa !24
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t5 = load i32, ptr %t4
  %t6 = sext i32 %t5 to i64
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t9 = icmp eq i64 %t7, %t8
  store i1 %t9, ptr %l5, !tbaa !21
  %t10 = load i1, ptr %l5, !tbaa !21
  br i1 %t10, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb3
bb2:
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t11 = load i1, ptr %l2, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d36 = private constant [0 x i8] c""
@.c37 = private unnamed_addr constant [51 x i8] c"compiler/cond.olang:487: reached unreachable code\0A\00"
@.c38 = private unnamed_addr constant [51 x i8] c"compiler/cond.olang:387: reached unreachable code\0A\00"
@.c39 = private unnamed_addr constant [52 x i8] c"compiler/cond.olang:449: slice bounds out of range\0A\00"
@.d40 = private constant [4 x i8] c"true"
@.c41 = private unnamed_addr constant [51 x i8] c"compiler/cond.olang:397: reached unreachable code\0A\00"
@.c42 = private unnamed_addr constant [52 x i8] c"compiler/cond.olang:326: slice bounds out of range\0A\00"
@.d43 = private constant [9 x i8] c"=!<>+-*/%"
@.c44 = private unnamed_addr constant [52 x i8] c"compiler/cond.olang:336: slice bounds out of range\0A\00"
@.c45 = private unnamed_addr constant [51 x i8] c"compiler/cond.olang:274: reached unreachable code\0A\00"
@.d46 = private constant [2 x i8] c"I8"
@.d47 = private constant [3 x i8] c"I16"
@.d48 = private constant [3 x i8] c"I32"
@.d49 = private constant [3 x i8] c"I64"
@.d50 = private constant [2 x i8] c"U8"
@.d51 = private constant [3 x i8] c"U16"
@.d52 = private constant [3 x i8] c"U32"
@.d53 = private constant [3 x i8] c"U64"
@.d54 = private constant [3 x i8] c"F16"
@.d55 = private constant [4 x i8] c"BF16"
@.d56 = private constant [3 x i8] c"F32"
@.d57 = private constant [3 x i8] c"F64"
@.d58 = private constant [4 x i8] c"Bool"
@.d59 = private constant [6 x i8] c"String"
@__olang_prog_scope = external thread_local(initialexec) global ptr
define linkonce_odr %"std/prelude/list:List<std/prelude/text:String&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<std/prelude/text:String&>" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l0
  store %"std/prelude/list:List<std/prelude/text:String&>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %rv
  ret %"std/prelude/list:List<std/prelude/text:String&>" %rr
}

define linkonce_odr %"std/prelude/list:List<compiler/cond:Value>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fcond_3aValue_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List<compiler/cond:Value>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List<compiler/cond:Value>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<compiler/cond:Value>" @std_2fprelude_2flist_3aList_3ccompiler_2fcond_3aValue_3e_2ector(ptr %t1)
  store %"std/prelude/list:List<compiler/cond:Value>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/list:List<compiler/cond:Value>", ptr %l0
  store %"std/prelude/list:List<compiler/cond:Value>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List<compiler/cond:Value>", ptr %rv
  ret %"std/prelude/list:List<compiler/cond:Value>" %rr
}

define linkonce_odr %"std/prelude/list:List<Bool>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cBool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List<Bool>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List<Bool>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<Bool>" @std_2fprelude_2flist_3aList_3cBool_3e_2ector(ptr %t1)
  store %"std/prelude/list:List<Bool>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/list:List<Bool>", ptr %l0
  store %"std/prelude/list:List<Bool>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List<Bool>", ptr %rv
  ret %"std/prelude/list:List<Bool>" %rr
}

@.d60 = private constant [0 x i8] c""
define linkonce_odr %"std/prelude/list:List<compiler/cond:Global&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fcond_3aGlobal_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List<compiler/cond:Global&>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List<compiler/cond:Global&>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<compiler/cond:Global&>" @std_2fprelude_2flist_3aList_3ccompiler_2fcond_3aGlobal_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List<compiler/cond:Global&>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/list:List<compiler/cond:Global&>", ptr %l0
  store %"std/prelude/list:List<compiler/cond:Global&>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List<compiler/cond:Global&>", ptr %rv
  ret %"std/prelude/list:List<compiler/cond:Global&>" %rr
}

define linkonce_odr %"std/prelude/list:List<compiler/source:NameId>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List<compiler/source:NameId>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List<compiler/source:NameId>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<compiler/source:NameId>" @std_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %t1)
  store %"std/prelude/list:List<compiler/source:NameId>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/list:List<compiler/source:NameId>", ptr %l0
  store %"std/prelude/list:List<compiler/source:NameId>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List<compiler/source:NameId>", ptr %rv
  ret %"std/prelude/list:List<compiler/source:NameId>" %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %a0, i8 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefineShape(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefineNotName(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefineTwice(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefineBuiltin(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefineBadNumber(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefineIntRange(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefineNegRange(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefineFloatRange(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/cond:Value" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcond_3aValue_3e_2eAt_3ccompiler_2fcond_3aValue_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcond_3aValue_3e_2ePush_3ccompiler_2fcond_3aValue_3e(ptr %v0, ptr %a0, %"compiler/cond:Value" %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H6b12c12825efdaf6153dbfa8fc9a5aca(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare %"compiler/scan:Tokens" @compiler_2fscan_2eScan(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, double } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseFloat(ptr %v0, { i64, ptr } %a0)
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseUint(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondNotBool(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondTypes(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondNoMeet(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondName(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondCycle(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondMutable(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondGlobalInit(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2eRun_H660dd195b8dfbe46b01e30313ba3abe1(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcond_3aGlobal_26_3e_2eRu_Hdae492cbfddb0b6a70eec6865333e543(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcond_3aGlobal_26_3e_2ePu_H886a66ffa23940650f82c48d9485539c(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2ftoken_2eKeyword(ptr %v0, { i64, ptr } %a0, i64 %a1, i64 %a2)
declare %"std/prelude/list:List<std/prelude/text:String&>" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List<compiler/cond:Value>" @std_2fprelude_2flist_3aList_3ccompiler_2fcond_3aValue_3e_2ector(ptr %v0)
declare %"std/prelude/list:List<Bool>" @std_2fprelude_2flist_3aList_3cBool_3e_2ector(ptr %v0)
declare %"std/prelude/list:List<compiler/cond:Global&>" @std_2fprelude_2flist_3aList_3ccompiler_2fcond_3aGlobal_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List<compiler/source:NameId>" @std_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
