; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_1bf68c28770a2f08_2201243288b20e7c = weak_odr constant [55 x i8] c"std/prelude/list.olang:526: array length out of range\0A\00"
@olang_loc_f88bc59f8def7175_291a834f1a3a1ac9 = weak_odr constant [55 x i8] c"std/prelude/list.olang:525: array length out of range\0A\00"
