; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_a3ff380a9eca2097_1acf7a30771e05f3 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: array length out of range\0A\00"
