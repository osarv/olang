; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_25246b652f4a5e5f_8082d2328fcb0323 = weak_odr constant [55 x i8] c"std/prelude/list.olang:110: array length out of range\0A\00"
@olang_loc_40a9ab4c5473c0fc_a568f7a3476f3980 = weak_odr constant [55 x i8] c"std/prelude/list.olang:108: array length out of range\0A\00"
@olang_loc_47c30a68e5fbcd49_c5897444b2980ad = weak_odr constant [55 x i8] c"std/prelude/list.olang:103: array length out of range\0A\00"
@olang_loc_48203ba2e6403fb0_e9d59565409c394 = weak_odr constant [55 x i8] c"std/prelude/list.olang:516: slice bounds out of range\0A\00"
@olang_loc_591801d769d990b2_2897619c3505a2f6 = weak_odr constant [55 x i8] c"std/prelude/list.olang:522: slice bounds out of range\0A\00"
@olang_loc_c24dd3b3eefb508a_d4ce94f57928a6ae = weak_odr constant [55 x i8] c"std/prelude/list.olang:114: array length out of range\0A\00"
@olang_loc_c3ef0384544b092f_d8fa6ce0e4d35353 = weak_odr constant [55 x i8] c"std/prelude/list.olang:523: slice bounds out of range\0A\00"
