; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%"std/prelude/list:List<std/prelude/text:String&>" = type { ptr }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List<std/prelude/text:Char>" }
%"std/prelude/list:List<std/prelude/text:Char>" = type { ptr }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/list:List<mut compiler/load:Module&>", %"std/prelude/list:List<std/prelude/text:String&>", i64, { i64, ptr }, { i64, ptr } }
%"std/prelude/list:List<mut compiler/load:Module&>" = type { ptr }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, ptr, ptr, { i64, ptr }, %"std/prelude/list:List<std/prelude/text:String&>", %"std/prelude/list:List<compiler/load:Import>", ptr, ptr, %"std/prelude/list:List<I32>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<Bool>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", ptr, ptr, ptr, i1, i1, %"std/prelude/list:List<I64>" }
%"std/prelude/list:List<compiler/load:Import>" = type { ptr }
%"std/prelude/list:List<I32>" = type { ptr }
%"std/prelude/list:List<I64>" = type { ptr }
%"std/prelude/list:List<Bool>" = type { ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/diag:Diagnostics" = type { i1, %"std/prelude/list:List<std/prelude/text:String&>", %"std/prelude/list:List<std/prelude/text:String&>", %"std/prelude/list:List<Bool>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<compiler/diag:record>", %"std/prelude/list:List<compiler/diag:note>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<compiler/diag:context>", i64, i1, i1, { i64, [3 x i64] }, { i64, ptr }, { i64, ptr }, i1 }
%"std/prelude/list:List<compiler/diag:record>" = type { ptr }
%"std/prelude/list:List<compiler/diag:note>" = type { ptr }
%"std/prelude/list:List<compiler/diag:context>" = type { ptr }
%"compiler/parse:Parser" = type { ptr, ptr, ptr, ptr, ptr, i64, i64, i32, i32, i32, i32, i1, i1, i1, i64, i1, i64, i1, i64, i1, i32, %"std/prelude/list:List<I32>", %"std/prelude/list:List<Bool>", %"std/prelude/map:Map<I32, I64>", %"std/prelude/list:List<compiler/source:NameId>", %"std/prelude/list:List<compiler/ast:Expr&>", %"std/prelude/list:List<compiler/ast:Stmt&>", %"std/prelude/list:List<compiler/ast:TypeRef&>", %"std/prelude/list:List<compiler/ast:Param&>", %"std/prelude/list:List<compiler/ast:Pattern&>", %"std/prelude/list:List<compiler/source:NameId>", %"std/prelude/list:List<compiler/source:Span>", %"std/prelude/list:List<compiler/ast:Decl&>", %"std/prelude/list:List<compiler/ast:Decl&>", { i64, ptr }, %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>" }
%"std/prelude/map:Map<I32, I64>" = type { ptr }
%"std/prelude/list:List<compiler/source:NameId>" = type { ptr }
%"std/prelude/list:List<compiler/ast:Expr&>" = type { ptr }
%"std/prelude/list:List<compiler/ast:Stmt&>" = type { ptr }
%"std/prelude/list:List<compiler/ast:TypeRef&>" = type { ptr }
%"std/prelude/list:List<compiler/ast:Param&>" = type { ptr }
%"std/prelude/list:List<compiler/ast:Pattern&>" = type { ptr }
%"std/prelude/list:List<compiler/source:Span>" = type { ptr }
%"std/prelude/list:List<compiler/ast:Decl&>" = type { ptr }
%"compiler/cond:Scope" = type { i1, %"std/prelude/list:List<compiler/cond:Global&>", %"std/prelude/list:List<compiler/source:NameId>" }
%"std/prelude/list:List<compiler/cond:Global&>" = type { ptr }
%"compiler/cond:Global" = type { { i64, ptr }, %"compiler/source:Span", i1, { i64, ptr }, ptr, i1 }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/scan:Tokens" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/token:Token" = type { i32, i8, i32, i32 }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"std/prelude/list:List<std/pair:Pair<I64, I32>>" = type { ptr }
%"std/pair:Pair<I64, I32>" = type { i64, i32 }
%"compiler/ast:TopBranch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/ast:TopIf" = type { ptr, ptr, ptr, ptr }
%"compiler/load:Import" = type { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, { i64, ptr }, i64, i64 }
%"compiler/cond:Eval" = type { { i64, ptr }, ptr, ptr, ptr, i1, i1, i1, %"compiler/source:Span", %"compiler/msgs:Msg", i64, i64, i1, %"std/prelude/list:List<std/prelude/text:String&>" }
%"compiler/scan:Diag" = type { i32, i32, i32, i8 }
%"compiler/parse:Oracle" = type { %"std/prelude/map:Map<compiler/source:NameId, Bool>", %"std/prelude/map:Map<std/prelude/text:String&, Bool>" }
%"std/prelude/map:Map<compiler/source:NameId, Bool>" = type { ptr }
%"std/prelude/map:Map<std/prelude/text:String&, Bool>" = type { ptr }
@G_2ecompiler_2fload_2eNoBranch = global i64 zeroinitializer
@G_2ecompiler_2fload_2eNotYet = global i64 zeroinitializer
@G_2ecompiler_2fload_2ePending = global i64 zeroinitializer
define dso_local i1 @compiler_2fload_2eAliasShape(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i8
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i1
  %l8 = alloca i1
  %l9 = alloca { i64, ptr }
  %l10 = alloca i8
  %l11 = alloca i1
  %l12 = alloca i1
  %l13 = alloca { i64, ptr }
  %l14 = alloca i8
  %l15 = alloca i1
  %l16 = alloca i1
  %l17 = alloca i1
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i1
  %l24 = alloca i1
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i8
  %l28 = alloca i8
  %l29 = alloca i1
  %l30 = alloca i1
  %l31 = alloca i8
  %l32 = alloca i1
  %l33 = alloca i1
  %l34 = alloca i8
  %l35 = alloca i1
  %l36 = alloca i1
  %l37 = alloca i1
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l5
  %t2 = load { i64, ptr }, ptr %l5
  %t3 = extractvalue { i64, ptr } %t2, 0
  store i64 %t3, ptr %l6
  %t4 = load i64, ptr %l6
  %t5 = icmp eq i64 %t4, 0
  store i1 %t5, ptr %l7
  %t6 = load i1, ptr %l7
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l8
  br label %bb7
bb2:
  %t7 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t7, ptr %l9
  %t8 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t9 = load ptr, ptr %t8
  %t10 = getelementptr i8, ptr %t9, i64 0
  %t11 = load i8, ptr %t10
  store i8 %t11, ptr %l10
  %t12 = load i8, ptr %l10
  %t13 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t12)
  store i1 %t13, ptr %l11
  br label %bb3
bb3:
  %t14 = load i1, ptr %l11
  br i1 %t14, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l12
  br label %bb6
bb5:
  %t15 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t15, ptr %l13
  %t16 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t17 = load ptr, ptr %t16
  %t18 = getelementptr i8, ptr %t17, i64 0
  %t19 = load i8, ptr %t18
  store i8 %t19, ptr %l14
  %t20 = load i8, ptr %l14
  %t21 = icmp eq i8 %t20, 95
  store i1 %t21, ptr %l15
  %t22 = load i1, ptr %l15
  store i1 %t22, ptr %l12
  br label %bb6
bb6:
  %t23 = load i1, ptr %l12
  %t24 = xor i1 %t23, true
  store i1 %t24, ptr %l16
  %t25 = load i1, ptr %l16
  store i1 %t25, ptr %l8
  br label %bb7
bb7:
  %t26 = load i1, ptr %l8
  br i1 %t26, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s1
  store i1 false, ptr %l17
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t27 = load i1, ptr %l17
  store i1 %t27, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t28 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t28, ptr %l18
  %t29 = load { i64, ptr }, ptr %l18
  store { i64, ptr } %t29, ptr %l1
  store i64 0, ptr %l2
  %t30 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t30, ptr %l19
  %t31 = load { i64, ptr }, ptr %l19
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l20
  %t33 = load i64, ptr %l20
  store i64 %t33, ptr %l3
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t34 = load i64, ptr %l2
  store i64 %t34, ptr %l21
  %t35 = load i64, ptr %l3
  store i64 %t35, ptr %l22
  %t36 = load i64, ptr %l21
  %t37 = load i64, ptr %l22
  %t38 = icmp slt i64 %t36, %t37
  store i1 %t38, ptr %l23
  %t39 = load i1, ptr %l23
  %t40 = xor i1 %t39, true
  store i1 %t40, ptr %l24
  %t41 = load i1, ptr %l24
  br i1 %t41, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb27
bb13:
  br label %bb14
bb14:
  %t42 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t42, ptr %l25
  %t43 = load i64, ptr %l2
  store i64 %t43, ptr %l26
  %t44 = load i64, ptr %l26
  %t45 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t46 = load ptr, ptr %t45
  %t47 = getelementptr i8, ptr %t46, i64 %t44
  %t48 = load i8, ptr %t47
  store i8 %t48, ptr %l27
  %t49 = load i8, ptr %l27
  store i8 %t49, ptr %l4
  %t50 = load i8, ptr %l4
  store i8 %t50, ptr %l28
  %t51 = load i8, ptr %l28
  %t52 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t51)
  store i1 %t52, ptr %l29
  br label %bb15
bb15:
  %t53 = load i1, ptr %l29
  br i1 %t53, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l30
  br label %bb19
bb17:
  %t54 = load i8, ptr %l4
  store i8 %t54, ptr %l31
  %t55 = load i8, ptr %l31
  %t56 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t55)
  store i1 %t56, ptr %l32
  br label %bb18
bb18:
  %t57 = load i1, ptr %l32
  store i1 %t57, ptr %l30
  br label %bb19
bb19:
  %t58 = load i1, ptr %l30
  br i1 %t58, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l33
  br label %bb22
bb21:
  %t59 = load i8, ptr %l4
  store i8 %t59, ptr %l34
  %t60 = load i8, ptr %l34
  %t61 = icmp eq i8 %t60, 95
  store i1 %t61, ptr %l35
  %t62 = load i1, ptr %l35
  store i1 %t62, ptr %l33
  br label %bb22
bb22:
  %t63 = load i1, ptr %l33
  %t64 = xor i1 %t63, true
  store i1 %t64, ptr %l36
  %t65 = load i1, ptr %l36
  br i1 %t65, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s4
  store i1 false, ptr %l37
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t66 = load i1, ptr %l37
  store i1 %t66, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s3)
  br label %bb26
bb26:
  store %olang.scope zeroinitializer, ptr %s5
  %t67 = load i64, ptr %l2
  store i64 %t67, ptr %l38
  %t68 = load i64, ptr %l38
  %t69 = add i64 %t68, 1
  store i64 %t69, ptr %l39
  %t70 = load i64, ptr %l39
  store i64 %t70, ptr %l2
  call void @__olang_scope_close(ptr %s5)
  br label %bb11
bb27:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %l40
  call void @__olang_scope_close(ptr %s0)
  %t71 = load i1, ptr %l40
  store i1 %t71, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fload_2eDeriveAlias(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i1
  %l14 = alloca i1
  %l15 = alloca { i64, ptr }
  %l16 = alloca i1
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i1
  %l24 = alloca i1
  %l25 = alloca i1
  %l26 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l4
  %t2 = load { i64, ptr }, ptr %l4
  %t3 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %s0, { i64, ptr } %t2, { i64, ptr } { i64 1, ptr @.d0 })
  %t4 = extractvalue { i32, i64 } %t3, 1
  %t5 = extractvalue { i32, i64 } %t3, 0
  store i32 %t5, ptr %l6
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store i64 %t4, ptr %l5
  br label %bb1
bb1:
  %t8 = load i64, ptr %l5
  store i64 %t8, ptr %l3
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 -1, ptr %l3
  br label %bb4
bb4:
  %t9 = load i64, ptr %l3
  %t10 = add i64 %t9, 1
  store i64 %t10, ptr %l7
  %t11 = load i64, ptr %l7
  store i64 %t11, ptr %l1
  %t12 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t12, ptr %l8
  %t13 = load { i64, ptr }, ptr %l8
  %t14 = extractvalue { i64, ptr } %t13, 0
  store i64 %t14, ptr %l9
  %t15 = load i64, ptr %l9
  store i64 %t15, ptr %l2
  %t16 = load i64, ptr %l2
  store i64 %t16, ptr %l10
  %t17 = load i64, ptr %l1
  store i64 %t17, ptr %l11
  %t18 = load i64, ptr %l10
  %t19 = load i64, ptr %l11
  %t20 = sub i64 %t18, %t19
  store i64 %t20, ptr %l12
  %t21 = load i64, ptr %l12
  %t22 = icmp sge i64 %t21, 6
  store i1 %t22, ptr %l13
  %t23 = load i1, ptr %l13
  br i1 %t23, label %bb5, label %bb6
bb5:
  %t24 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t24, ptr %l15
  %t25 = load { i64, ptr }, ptr %l15
  %t26 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %s0, { i64, ptr } %t25, { i64, ptr } { i64 6, ptr @.d1 })
  store i1 %t26, ptr %l16
  br label %bb7
bb6:
  store i1 false, ptr %l14
  br label %bb8
bb7:
  %t27 = load i1, ptr %l16
  store i1 %t27, ptr %l14
  br label %bb8
bb8:
  %t28 = load i1, ptr %l14
  br i1 %t28, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s1
  %t29 = load i64, ptr %l2
  store i64 %t29, ptr %l17
  %t30 = load i64, ptr %l17
  %t31 = sub i64 %t30, 6
  store i64 %t31, ptr %l18
  %t32 = load i64, ptr %l18
  store i64 %t32, ptr %l2
  call void @__olang_scope_close(ptr %s1)
  br label %bb11
bb10:
  br label %bb11
bb11:
  %t33 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t33, ptr %l19
  %t34 = load i64, ptr %l1
  store i64 %t34, ptr %l20
  %t35 = load i64, ptr %l2
  store i64 %t35, ptr %l21
  %t36 = load { i64, ptr }, ptr %l19
  %t37 = extractvalue { i64, ptr } %t36, 0
  store i64 %t37, ptr %l22
  %t38 = load i64, ptr %l20
  %t39 = icmp sge i64 %t38, 0
  store i1 %t39, ptr %l23
  %t40 = load i1, ptr %l23
  br i1 %t40, label %bb12, label %bb13
bb12:
  %t41 = load i64, ptr %l20
  %t42 = load i64, ptr %l21
  %t43 = icmp sle i64 %t41, %t42
  store i1 %t43, ptr %l24
  %t44 = load i1, ptr %l24
  br i1 %t44, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @.c2)
  unreachable
bb14:
  %t45 = load i64, ptr %l21
  %t46 = load i64, ptr %l22
  %t47 = icmp sle i64 %t45, %t46
  store i1 %t47, ptr %l25
  %t48 = load i1, ptr %l25
  br i1 %t48, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @.c2)
  unreachable
bb16:
  %t49 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t50 = load ptr, ptr %t49
  %t51 = load i64, ptr %l20
  %t52 = load i64, ptr %l21
  %t53 = getelementptr i8, ptr %t50, i64 %t51
  %t54 = sub i64 %t52, %t51
  %t55 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t53, 1
  store { i64, ptr } %t56, ptr %l26
  call void @__olang_scope_close(ptr %s0)
  %t57 = load { i64, ptr }, ptr %l26
  store { i64, ptr } %t57, ptr %rv
  br label %ret
bb17:
  call void @__olang_check_failed(ptr @.c2)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fload_2eLockPath(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l1
  %t2 = load { i64, ptr }, ptr %l1
  %t3 = call { i64, ptr } @std_2ffilepath_2eDir(ptr %v0, { i64, ptr } %t2)
  store { i64, ptr } %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %v0, ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t4, { i64, ptr } { i64 10, ptr @.d3 }, { i64, ptr } { i64 0, ptr @.d4 }, { i64, ptr } { i64 0, ptr @.d5 }, { i64, ptr } { i64 0, ptr @.d6 }, { i64, ptr } { i64 0, ptr @.d7 })
  store { i64, ptr } %t5, ptr %l3
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t6 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t6, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fload_2eNoBranch_2einit() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 -1, ptr @G_2ecompiler_2fload_2eNoBranch
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fload_2eNormalize(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i1
  %l21 = alloca i1
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i1
  %l27 = alloca i1
  %l28 = alloca { i64, ptr }
  %l29 = alloca i1
  %l30 = alloca { i64, ptr }
  %l31 = alloca i1
  %l32 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca i64
  %l35 = alloca i1
  %l36 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca ptr
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %l42 = alloca i1
  %l43 = alloca i1
  %l44 = alloca { i64, ptr }
  %l45 = alloca ptr
  %l46 = alloca { i64, ptr }
  %l47 = alloca i32
  %l48 = alloca ptr
  %l49 = alloca { i64, ptr }
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca %"std/prelude/text:StringBuilder"
  %l53 = alloca { i64, ptr }
  %l54 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca ptr
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i1
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i1
  %l64 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca i64
  %l68 = alloca i64
  %l69 = alloca i64
  %l70 = alloca i64
  %l71 = alloca i64
  %l72 = alloca i64
  %l73 = alloca i64
  %l74 = alloca i64
  %l75 = alloca i1
  %l76 = alloca i1
  %l77 = alloca i64
  %l78 = alloca i64
  %l79 = alloca i64
  %l80 = alloca i64
  %l81 = alloca i64
  %l82 = alloca i64
  %l83 = alloca i1
  %l84 = alloca ptr
  %l85 = alloca ptr
  %l86 = alloca ptr
  %l87 = alloca i64
  %l88 = alloca { i64, ptr }
  %l89 = alloca i64
  %l90 = alloca i64
  %l91 = alloca ptr
  %l92 = alloca i64
  %l93 = alloca i1
  %l94 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l97 = alloca ptr
  %l98 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<std/prelude/text:String&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t1)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t2, ptr %l13
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l13
  store %"std/prelude/list:List<std/prelude/text:String&>" %t3, ptr %l1
  store %olang.scope zeroinitializer, ptr %s1
  %t4 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t4, ptr %l14
  %t5 = load { i64, ptr }, ptr %l14
  %t6 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %s1, { i64, ptr } %t5, { i64, ptr } { i64 1, ptr @.d8 })
  store { i64, ptr } %t6, ptr %l15
  br label %bb2
bb2:
  %t7 = load { i64, ptr }, ptr %l15
  store { i64, ptr } %t7, ptr %l2
  store i64 0, ptr %l3
  %t8 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t8, ptr %l16
  %t9 = load { i64, ptr }, ptr %l16
  %t10 = extractvalue { i64, ptr } %t9, 0
  store i64 %t10, ptr %l17
  %t11 = load i64, ptr %l17
  store i64 %t11, ptr %l4
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t12 = load i64, ptr %l3
  store i64 %t12, ptr %l18
  %t13 = load i64, ptr %l4
  store i64 %t13, ptr %l19
  %t14 = load i64, ptr %l18
  %t15 = load i64, ptr %l19
  %t16 = icmp slt i64 %t14, %t15
  store i1 %t16, ptr %l20
  %t17 = load i1, ptr %l20
  %t18 = xor i1 %t17, true
  store i1 %t18, ptr %l21
  %t19 = load i1, ptr %l21
  br i1 %t19, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb35
bb5:
  br label %bb6
bb6:
  %t20 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t20, ptr %l22
  %t21 = load i64, ptr %l3
  store i64 %t21, ptr %l23
  %t22 = load i64, ptr %l23
  %t23 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t24 = load ptr, ptr %t23
  %t25 = getelementptr { i64, ptr }, ptr %t24, i64 %t22
  %t26 = load { i64, ptr }, ptr %t25
  store { i64, ptr } %t26, ptr %l24
  %t27 = load { i64, ptr }, ptr %l24
  store { i64, ptr } %t27, ptr %l5
  %t28 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t28, ptr %l25
  %t29 = load { i64, ptr }, ptr %l25
  %t30 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t29, { i64, ptr } { i64 0, ptr @.d9 })
  store i1 %t30, ptr %l26
  br label %bb7
bb7:
  %t31 = load i1, ptr %l26
  br i1 %t31, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l27
  br label %bb11
bb9:
  %t32 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t32, ptr %l28
  %t33 = load { i64, ptr }, ptr %l28
  %t34 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t33, { i64, ptr } { i64 1, ptr @.d10 })
  store i1 %t34, ptr %l29
  br label %bb10
bb10:
  %t35 = load i1, ptr %l29
  store i1 %t35, ptr %l27
  br label %bb11
bb11:
  %t36 = load i1, ptr %l27
  br i1 %t36, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  br label %bb34
bb13:
  br label %bb14
bb14:
  %t37 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t37, ptr %l30
  %t38 = load { i64, ptr }, ptr %l30
  %t39 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t38, { i64, ptr } { i64 2, ptr @.d11 })
  store i1 %t39, ptr %l31
  br label %bb15
bb15:
  %t40 = load i1, ptr %l31
  br i1 %t40, label %bb16, label %bb17
bb16:
  store ptr %l1, ptr %l33
  %t41 = load ptr, ptr %l33
  %t42 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %s0, ptr %t41)
  store i64 %t42, ptr %l34
  br label %bb18
bb17:
  store i1 false, ptr %l32
  br label %bb19
bb18:
  %t43 = load i64, ptr %l34
  %t44 = icmp sgt i64 %t43, 0
  store i1 %t44, ptr %l35
  %t45 = load i1, ptr %l35
  store i1 %t45, ptr %l32
  br label %bb19
bb19:
  %t46 = load i1, ptr %l32
  br i1 %t46, label %bb20, label %bb21
bb20:
  store ptr %l1, ptr %l37
  store ptr %l1, ptr %l38
  %t47 = load ptr, ptr %l38
  %t48 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %s0, ptr %t47)
  store i64 %t48, ptr %l39
  br label %bb22
bb21:
  store i1 false, ptr %l36
  br label %bb25
bb22:
  %t49 = load i64, ptr %l39
  %t50 = sub i64 %t49, 1
  store i64 %t50, ptr %l40
  %t51 = load ptr, ptr %l37
  %t52 = load i64, ptr %l40
  %t53 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %s0, ptr %s0, ptr %t51, i64 %t52)
  store { i64, ptr } %t53, ptr %l41
  br label %bb23
bb23:
  %t54 = load { i64, ptr }, ptr %l41
  %t55 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s2, { i64, ptr } %t54, { i64, ptr } { i64 2, ptr @.d12 })
  store i1 %t55, ptr %l42
  br label %bb24
bb24:
  %t56 = load i1, ptr %l42
  %t57 = xor i1 %t56, true
  store i1 %t57, ptr %l43
  %t58 = load i1, ptr %l43
  store i1 %t58, ptr %l36
  br label %bb25
bb25:
  %t59 = load i1, ptr %l36
  br i1 %t59, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s4
  store ptr %l1, ptr %l45
  %t60 = load ptr, ptr %l45
  %t61 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hd1f680ecc7a3e4b4dd91667eaf6a5223(ptr %s0, ptr %s4, ptr %t60)
  %t62 = extractvalue { i32, { i64, ptr } } %t61, 1
  %t63 = extractvalue { i32, { i64, ptr } } %t61, 0
  store i32 %t63, ptr %l47
  %t64 = icmp ne i32 %t63, 0
  br i1 %t64, label %bb29, label %ok.65
ok.65:
  store { i64, ptr } %t62, ptr %l46
  br label %bb28
bb27:
  br label %bb32
bb28:
  %t66 = load { i64, ptr }, ptr %l46
  store { i64, ptr } %t66, ptr %l44
  br label %bb31
bb29:
  br label %bb30
bb30:
  store %olang.scope zeroinitializer, ptr %s5
  call void @__olang_scope_close(ptr %s5)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  br label %bb34
bb32:
  store ptr %l1, ptr %l48
  %t67 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t67, ptr %l49
  %t68 = load ptr, ptr %l48
  %t69 = load { i64, ptr }, ptr %l49
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %v0, ptr %t68, { i64, ptr } %t69)
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s2)
  br label %bb34
bb34:
  store %olang.scope zeroinitializer, ptr %s6
  %t70 = load i64, ptr %l3
  store i64 %t70, ptr %l50
  %t71 = load i64, ptr %l50
  %t72 = add i64 %t71, 1
  store i64 %t72, ptr %l51
  %t73 = load i64, ptr %l51
  store i64 %t73, ptr %l3
  call void @__olang_scope_close(ptr %s6)
  br label %bb3
bb35:
  call void @__olang_scope_close(ptr %s1)
  %t74 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t74, ptr %l52
  br label %bb36
bb36:
  %t75 = load %"std/prelude/text:StringBuilder", ptr %l52
  store %"std/prelude/text:StringBuilder" %t75, ptr %l6
  %t76 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t76, ptr %l53
  %t77 = load { i64, ptr }, ptr %l53
  %t78 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t77, { i64, ptr } { i64 1, ptr @.d13 })
  store i1 %t78, ptr %l54
  br label %bb37
bb37:
  %t79 = load i1, ptr %l54
  br i1 %t79, label %bb38, label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s7
  store ptr %l6, ptr %l55
  %t80 = load ptr, ptr %l55
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t80, i8 47)
  br label %bb40
bb39:
  br label %bb41
bb40:
  call void @__olang_scope_close(ptr %s7)
  br label %bb41
bb41:
  store %olang.scope zeroinitializer, ptr %s8
  store i64 0, ptr %l7
  store ptr %l1, ptr %l56
  %t81 = load ptr, ptr %l56
  %t82 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %s0, ptr %t81)
  store i64 %t82, ptr %l57
  br label %bb42
bb42:
  %t83 = load i64, ptr %l57
  store i64 %t83, ptr %l8
  store i64 1, ptr %l9
  %t84 = load i64, ptr %l8
  store i64 %t84, ptr %l58
  %t85 = load i64, ptr %l7
  store i64 %t85, ptr %l59
  %t86 = load i64, ptr %l58
  %t87 = load i64, ptr %l59
  %t88 = icmp sgt i64 %t86, %t87
  store i1 %t88, ptr %l60
  %t89 = load i1, ptr %l60
  br i1 %t89, label %bb43, label %bb44
bb43:
  %t90 = load i64, ptr %l9
  store i64 %t90, ptr %l62
  %t91 = load i64, ptr %l62
  %t92 = icmp sgt i64 %t91, 0
  store i1 %t92, ptr %l63
  %t93 = load i1, ptr %l63
  br i1 %t93, label %bb45, label %bb46
bb44:
  store i64 0, ptr %l61
  br label %bb48
bb45:
  %t94 = load i64, ptr %l8
  store i64 %t94, ptr %l65
  %t95 = load i64, ptr %l7
  store i64 %t95, ptr %l66
  %t96 = load i64, ptr %l65
  %t97 = load i64, ptr %l66
  %t98 = sub i64 %t96, %t97
  store i64 %t98, ptr %l67
  %t99 = load i64, ptr %l9
  store i64 %t99, ptr %l68
  %t100 = load i64, ptr %l67
  %t101 = load i64, ptr %l68
  %t102 = add i64 %t100, %t101
  store i64 %t102, ptr %l69
  %t103 = load i64, ptr %l69
  %t104 = sub i64 %t103, 1
  store i64 %t104, ptr %l70
  %t105 = load i64, ptr %l9
  store i64 %t105, ptr %l71
  %t106 = load i64, ptr %l70
  %t107 = load i64, ptr %l71
  %t108 = sdiv i64 %t106, %t107
  store i64 %t108, ptr %l72
  %t109 = load i64, ptr %l72
  store i64 %t109, ptr %l64
  br label %bb47
bb46:
  store i64 0, ptr %l64
  br label %bb47
bb47:
  %t110 = load i64, ptr %l64
  store i64 %t110, ptr %l61
  br label %bb48
bb48:
  %t111 = load i64, ptr %l61
  store i64 %t111, ptr %l10
  store i64 0, ptr %l11
  br label %bb49
bb49:
  store %olang.scope zeroinitializer, ptr %s9
  %t112 = load i64, ptr %l11
  store i64 %t112, ptr %l73
  %t113 = load i64, ptr %l10
  store i64 %t113, ptr %l74
  %t114 = load i64, ptr %l73
  %t115 = load i64, ptr %l74
  %t116 = icmp slt i64 %t114, %t115
  store i1 %t116, ptr %l75
  %t117 = load i1, ptr %l75
  %t118 = xor i1 %t117, true
  store i1 %t118, ptr %l76
  %t119 = load i1, ptr %l76
  br i1 %t119, label %bb50, label %bb51
bb50:
  call void @__olang_scope_close(ptr %s9)
  br label %bb60
bb51:
  br label %bb52
bb52:
  %t120 = load i64, ptr %l7
  store i64 %t120, ptr %l77
  %t121 = load i64, ptr %l11
  store i64 %t121, ptr %l78
  %t122 = load i64, ptr %l9
  store i64 %t122, ptr %l79
  %t123 = load i64, ptr %l78
  %t124 = load i64, ptr %l79
  %t125 = mul i64 %t123, %t124
  store i64 %t125, ptr %l80
  %t126 = load i64, ptr %l77
  %t127 = load i64, ptr %l80
  %t128 = add i64 %t126, %t127
  store i64 %t128, ptr %l81
  %t129 = load i64, ptr %l81
  store i64 %t129, ptr %l12
  %t130 = load i64, ptr %l12
  store i64 %t130, ptr %l82
  %t131 = load i64, ptr %l82
  %t132 = icmp sgt i64 %t131, 0
  store i1 %t132, ptr %l83
  %t133 = load i1, ptr %l83
  br i1 %t133, label %bb53, label %bb54
bb53:
  store %olang.scope zeroinitializer, ptr %s10
  store ptr %l6, ptr %l84
  %t134 = load ptr, ptr %l84
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t134, i8 47)
  br label %bb55
bb54:
  br label %bb56
bb55:
  call void @__olang_scope_close(ptr %s10)
  br label %bb56
bb56:
  store ptr %l6, ptr %l85
  store ptr %l1, ptr %l86
  %t135 = load i64, ptr %l12
  store i64 %t135, ptr %l87
  %t136 = load ptr, ptr %l86
  %t137 = load i64, ptr %l87
  %t138 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %s0, ptr %s0, ptr %t136, i64 %t137)
  store { i64, ptr } %t138, ptr %l88
  br label %bb57
bb57:
  %t139 = load ptr, ptr %l85
  %t140 = load { i64, ptr }, ptr %l88
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t139, { i64, ptr } %t140)
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s9)
  br label %bb59
bb59:
  store %olang.scope zeroinitializer, ptr %s11
  %t141 = load i64, ptr %l11
  store i64 %t141, ptr %l89
  %t142 = load i64, ptr %l89
  %t143 = add i64 %t142, 1
  store i64 %t143, ptr %l90
  %t144 = load i64, ptr %l90
  store i64 %t144, ptr %l11
  call void @__olang_scope_close(ptr %s11)
  br label %bb49
bb60:
  call void @__olang_scope_close(ptr %s8)
  store ptr %l6, ptr %l91
  %t145 = load ptr, ptr %l91
  %t146 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %s0, ptr %t145)
  store i64 %t146, ptr %l92
  br label %bb61
bb61:
  %t147 = load i64, ptr %l92
  %t148 = icmp eq i64 %t147, 0
  store i1 %t148, ptr %l93
  %t149 = load i1, ptr %l93
  br i1 %t149, label %bb62, label %bb63
bb62:
  store { i64, ptr } { i64 1, ptr @.d14 }, ptr %l95
  %t150 = load { i64, ptr }, ptr %l95
  store { i64, ptr } %t150, ptr %l96
  %t151 = load { i64, ptr }, ptr %l96
  store { i64, ptr } %t151, ptr %l94
  br label %bb65
bb63:
  store ptr %l6, ptr %l97
  %t152 = load ptr, ptr %l97
  %t153 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %t152)
  store { i64, ptr } %t153, ptr %l98
  br label %bb64
bb64:
  %t154 = load { i64, ptr }, ptr %l98
  store { i64, ptr } %t154, ptr %l99
  %t155 = load { i64, ptr }, ptr %l99
  store { i64, ptr } %t155, ptr %l94
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s0)
  %t156 = load { i64, ptr }, ptr %l94
  store { i64, ptr } %t156, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fload_2eNotYet_2einit() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 -2, ptr @G_2ecompiler_2fload_2eNotYet
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fload_2ePending_2einit() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 -3, ptr @G_2ecompiler_2fload_2ePending
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fload_2ePublic(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i1
  %l4 = alloca i1
  %l5 = alloca { i64, ptr }
  %l6 = alloca i8
  %l7 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l1
  %t2 = load { i64, ptr }, ptr %l1
  %t3 = extractvalue { i64, ptr } %t2, 0
  store i64 %t3, ptr %l2
  %t4 = load i64, ptr %l2
  %t5 = icmp sgt i64 %t4, 0
  store i1 %t5, ptr %l3
  %t6 = load i1, ptr %l3
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t7 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t7, ptr %l5
  %t8 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t9 = load ptr, ptr %t8
  %t10 = getelementptr i8, ptr %t9, i64 0
  %t11 = load i8, ptr %t10
  store i8 %t11, ptr %l6
  %t12 = load i8, ptr %l6
  %t13 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t12)
  store i1 %t13, ptr %l7
  br label %bb3
bb2:
  store i1 false, ptr %l4
  br label %bb4
bb3:
  %t14 = load i1, ptr %l7
  store i1 %t14, ptr %l4
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t15 = load i1, ptr %l4
  store i1 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fload_2eStdDir(ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca i1
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.builder
  %s2room = alloca [64 x i8], align 8
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.builder
  %s4room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 9, ptr @.d15 })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l4
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  store { i64, ptr } %t2, ptr %l3
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t6, ptr %l2
  br label %bb4
bb2:
  br label %bb3
bb3:
  store { i64, ptr } { i64 0, ptr @.d16 }, ptr %l5
  %t7 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t7, ptr %l6
  %t8 = load { i64, ptr }, ptr %l6
  %t9 = extractvalue { i64, ptr } %t8, 0
  %t10 = extractvalue { i64, ptr } %t8, 1
  %t11 = mul i64 %t9, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t10, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l7
  %t15 = load { i64, ptr }, ptr %l7
  store { i64, ptr } %t15, ptr %l2
  br label %bb4
bb4:
  %t16 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t16, ptr %l0
  %t17 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t17, ptr %l8
  %t18 = load { i64, ptr }, ptr %l8
  %t19 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t18, { i64, ptr } { i64 0, ptr @.d17 })
  store i1 %t19, ptr %l9
  br label %bb5
bb5:
  %t20 = load i1, ptr %l9
  %t21 = xor i1 %t20, true
  store i1 %t21, ptr %l10
  %t22 = load i1, ptr %l10
  br i1 %t22, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t23 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t23, ptr %l11
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s2
  store ptr %s2room, ptr %s2
  %t24 = load { i64, ptr }, ptr %l11
  %t25 = extractvalue { i64, ptr } %t24, 1
  %t26 = extractvalue { i64, ptr } %t24, 0
  call void @__olang_sb_put(ptr %s2, ptr %t25, i64 %t26)
  %t27 = load ptr, ptr %s2
  %t28 = getelementptr %olang.builder, ptr %s2, i32 0, i32 1
  %t29 = load i64, ptr %t28
  %t30 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t27, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  store { i64, ptr } %t32, ptr %l12
  call void @__olang_sb_done(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t33 = load { i64, ptr }, ptr %l12
  store { i64, ptr } %t33, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t34 = call { i32, { i64, ptr } } @std_2fos_2eReadLink(ptr %s0, ptr %s0, { i64, ptr } { i64 14, ptr @.d18 })
  %t35 = extractvalue { i32, { i64, ptr } } %t34, 1
  %t36 = extractvalue { i32, { i64, ptr } } %t34, 0
  store i32 %t36, ptr %l15
  %t37 = icmp ne i32 %t36, 0
  br i1 %t37, label %bb10, label %ok.38
ok.38:
  store { i64, ptr } %t35, ptr %l14
  br label %bb9
bb9:
  %t39 = load { i64, ptr }, ptr %l14
  store { i64, ptr } %t39, ptr %l13
  br label %bb14
bb10:
  %t40 = load i32, ptr %l15
  %t41 = ashr i32 %t40, 16
  store i32 %t41, ptr %l16
  %t42 = load i32, ptr %l16
  %t43 = icmp eq i32 %t42, 1
  store i1 %t43, ptr %l17
  %t44 = load i1, ptr %l17
  br i1 %t44, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @.c19)
  unreachable
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  store { i64, ptr } { i64 3, ptr @.d20 }, ptr %l18
  %t45 = load { i64, ptr }, ptr %l18
  store { i64, ptr } %t45, ptr %l19
  %t46 = load { i64, ptr }, ptr %l19
  %t47 = extractvalue { i64, ptr } %t46, 0
  store i64 %t47, ptr %l20
  %t48 = load i64, ptr %l20
  %t49 = mul i64 %t48, 1
  %t50 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t49)
  %t51 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  store { i64, ptr } %t52, ptr %l21
  %t53 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t54 = load ptr, ptr %t53
  %t55 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t56 = load ptr, ptr %t55
  %t57 = load i64, ptr %l20
  %t58 = mul i64 %t57, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t54, ptr %t56, i64 %t58, i1 false)
  %t59 = load { i64, ptr }, ptr %l21
  store { i64, ptr } %t59, ptr %l19
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t60 = load { i64, ptr }, ptr %l19
  store { i64, ptr } %t60, ptr %rv
  br label %ret
bb14:
  %t61 = load { i64, ptr }, ptr %l13
  store { i64, ptr } %t61, ptr %l1
  %t62 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t62, ptr %l22
  %t63 = load { i64, ptr }, ptr %l22
  %t64 = call { i64, ptr } @std_2ffilepath_2eDir(ptr %s0, { i64, ptr } %t63)
  store { i64, ptr } %t64, ptr %l23
  br label %bb15
bb15:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s4
  store ptr %s4room, ptr %s4
  %t65 = load { i64, ptr }, ptr %l23
  %t66 = extractvalue { i64, ptr } %t65, 1
  %t67 = extractvalue { i64, ptr } %t65, 0
  call void @__olang_sb_put(ptr %s4, ptr %t66, i64 %t67)
  %t68 = extractvalue { i64, ptr } { i64 7, ptr @.d21 }, 1
  %t69 = extractvalue { i64, ptr } { i64 7, ptr @.d21 }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t68, i64 %t69)
  %t70 = load ptr, ptr %s4
  %t71 = getelementptr %olang.builder, ptr %s4, i32 0, i32 1
  %t72 = load i64, ptr %t71
  %t73 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t72)
  call void @llvm.memcpy.p0.p0.i64(ptr %t73, ptr %t70, i64 %t72, i1 false)
  %t74 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  store { i64, ptr } %t75, ptr %l24
  call void @__olang_sb_done(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t76 = load { i64, ptr }, ptr %l24
  store { i64, ptr } %t76, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eChosen(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i1
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i1
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i1
  %l35 = alloca i1
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca ptr
  %l42 = alloca ptr
  %l43 = alloca i64
  %l44 = alloca i32
  %l45 = alloca i32
  %l46 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca ptr
  %l51 = alloca ptr
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l10
  %t2 = load ptr, ptr %l10
  %t3 = getelementptr %"compiler/load:Loader", ptr %t2, i32 0, i32 5
  store ptr %t3, ptr %l11
  %t4 = load i64, ptr %l1
  store i64 %t4, ptr %l12
  %t5 = load ptr, ptr %l11
  %t6 = load i64, ptr %l12
  %t7 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t5, i64 %t6)
  store ptr %t7, ptr %l13
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l13
  store ptr %t8, ptr %l3
  store %olang.scope zeroinitializer, ptr %s1
  store i64 0, ptr %l4
  %t9 = load ptr, ptr %l3
  store ptr %t9, ptr %l14
  %t10 = load ptr, ptr %l14
  %t11 = getelementptr %"compiler/load:Module", ptr %t10, i32 0, i32 12
  store ptr %t11, ptr %l15
  %t12 = load ptr, ptr %l15
  %t13 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2eLen_3cI32_3e(ptr %v0, ptr %t12)
  store i64 %t13, ptr %l16
  br label %bb2
bb2:
  %t14 = load i64, ptr %l16
  store i64 %t14, ptr %l5
  store i64 1, ptr %l6
  %t15 = load i64, ptr %l5
  store i64 %t15, ptr %l17
  %t16 = load i64, ptr %l4
  store i64 %t16, ptr %l18
  %t17 = load i64, ptr %l17
  %t18 = load i64, ptr %l18
  %t19 = icmp sgt i64 %t17, %t18
  store i1 %t19, ptr %l19
  %t20 = load i1, ptr %l19
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t21 = load i64, ptr %l6
  store i64 %t21, ptr %l21
  %t22 = load i64, ptr %l21
  %t23 = icmp sgt i64 %t22, 0
  store i1 %t23, ptr %l22
  %t24 = load i1, ptr %l22
  br i1 %t24, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l20
  br label %bb8
bb5:
  %t25 = load i64, ptr %l5
  store i64 %t25, ptr %l24
  %t26 = load i64, ptr %l4
  store i64 %t26, ptr %l25
  %t27 = load i64, ptr %l24
  %t28 = load i64, ptr %l25
  %t29 = sub i64 %t27, %t28
  store i64 %t29, ptr %l26
  %t30 = load i64, ptr %l6
  store i64 %t30, ptr %l27
  %t31 = load i64, ptr %l26
  %t32 = load i64, ptr %l27
  %t33 = add i64 %t31, %t32
  store i64 %t33, ptr %l28
  %t34 = load i64, ptr %l28
  %t35 = sub i64 %t34, 1
  store i64 %t35, ptr %l29
  %t36 = load i64, ptr %l6
  store i64 %t36, ptr %l30
  %t37 = load i64, ptr %l29
  %t38 = load i64, ptr %l30
  %t39 = sdiv i64 %t37, %t38
  store i64 %t39, ptr %l31
  %t40 = load i64, ptr %l31
  store i64 %t40, ptr %l23
  br label %bb7
bb6:
  store i64 0, ptr %l23
  br label %bb7
bb7:
  %t41 = load i64, ptr %l23
  store i64 %t41, ptr %l20
  br label %bb8
bb8:
  %t42 = load i64, ptr %l20
  store i64 %t42, ptr %l7
  store i64 0, ptr %l8
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t43 = load i64, ptr %l8
  store i64 %t43, ptr %l32
  %t44 = load i64, ptr %l7
  store i64 %t44, ptr %l33
  %t45 = load i64, ptr %l32
  %t46 = load i64, ptr %l33
  %t47 = icmp slt i64 %t45, %t46
  store i1 %t47, ptr %l34
  %t48 = load i1, ptr %l34
  %t49 = xor i1 %t48, true
  store i1 %t49, ptr %l35
  %t50 = load i1, ptr %l35
  br i1 %t50, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb11:
  br label %bb12
bb12:
  %t51 = load i64, ptr %l4
  store i64 %t51, ptr %l36
  %t52 = load i64, ptr %l8
  store i64 %t52, ptr %l37
  %t53 = load i64, ptr %l6
  store i64 %t53, ptr %l38
  %t54 = load i64, ptr %l37
  %t55 = load i64, ptr %l38
  %t56 = mul i64 %t54, %t55
  store i64 %t56, ptr %l39
  %t57 = load i64, ptr %l36
  %t58 = load i64, ptr %l39
  %t59 = add i64 %t57, %t58
  store i64 %t59, ptr %l40
  %t60 = load i64, ptr %l40
  store i64 %t60, ptr %l9
  %t61 = load ptr, ptr %l3
  store ptr %t61, ptr %l41
  %t62 = load ptr, ptr %l41
  %t63 = getelementptr %"compiler/load:Module", ptr %t62, i32 0, i32 12
  store ptr %t63, ptr %l42
  %t64 = load i64, ptr %l9
  store i64 %t64, ptr %l43
  %t65 = load ptr, ptr %l42
  %t66 = load i64, ptr %l43
  %t67 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2eAt_3cI32_3e(ptr %v0, ptr %t65, i64 %t66)
  store i32 %t67, ptr %l44
  br label %bb13
bb13:
  %t68 = load i32, ptr %l2
  store i32 %t68, ptr %l45
  %t69 = load i32, ptr %l44
  %t70 = load i32, ptr %l45
  %t71 = icmp eq i32 %t69, %t70
  store i1 %t71, ptr %l46
  %t72 = load i1, ptr %l46
  br i1 %t72, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t73 = load ptr, ptr %l0
  store ptr %t73, ptr %l47
  %t74 = load i64, ptr %l1
  store i64 %t74, ptr %l48
  %t75 = load i64, ptr %l9
  store i64 %t75, ptr %l49
  %t76 = load ptr, ptr %l47
  %t77 = load i64, ptr %l48
  %t78 = load i64, ptr %l49
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2edecide(ptr %v0, ptr %t76, i64 %t77, i64 %t78)
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t79 = load ptr, ptr %l3
  store ptr %t79, ptr %l50
  %t80 = load ptr, ptr %l50
  %t81 = getelementptr %"compiler/load:Module", ptr %t80, i32 0, i32 14
  store ptr %t81, ptr %l51
  %t82 = load i64, ptr %l9
  store i64 %t82, ptr %l52
  %t83 = load ptr, ptr %l51
  %t84 = load i64, ptr %l52
  %t85 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t83, i64 %t84)
  store i64 %t85, ptr %l53
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t86 = load i64, ptr %l53
  store i64 %t86, ptr %rv
  br label %ret
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  store %olang.scope zeroinitializer, ptr %s4
  %t87 = load i64, ptr %l8
  store i64 %t87, ptr %l54
  %t88 = load i64, ptr %l54
  %t89 = add i64 %t88, 1
  store i64 %t89, ptr %l55
  %t90 = load i64, ptr %l55
  store i64 %t90, ptr %l8
  call void @__olang_scope_close(ptr %s4)
  br label %bb9
bb20:
  call void @__olang_scope_close(ptr %s1)
  %t91 = load i64, ptr @G_2ecompiler_2fload_2ePending
  store i64 %t91, ptr %l56
  call void @__olang_scope_close(ptr %s0)
  %t92 = load i64, ptr %l56
  store i64 %t92, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fload_2ecompiler_2fload_3aLoader_2eCondParser(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i1
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca { i64, ptr }
  %l18 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca i1
  %l21 = alloca %"compiler/source:Span"
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca %"compiler/diag:Diagnostics"
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l32 = alloca ptr
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca ptr
  %l37 = alloca ptr
  %l38 = alloca ptr
  %l39 = alloca ptr
  %l40 = alloca ptr
  %l41 = alloca ptr
  %l42 = alloca ptr
  %l43 = alloca ptr
  %l44 = alloca ptr
  %l45 = alloca ptr
  %l46 = alloca ptr
  %l47 = alloca i64
  %l48 = alloca %"compiler/parse:Parser"
  %l49 = alloca ptr
  %l50 = alloca ptr
  %l51 = alloca ptr
  %l52 = alloca { i64, ptr }
  %l53 = alloca i1
  %l54 = alloca %"compiler/cond:Scope"
  %l55 = alloca ptr
  %l56 = alloca ptr
  %l57 = alloca ptr
  %l58 = alloca { i64, ptr }
  %l59 = alloca ptr
  %l60 = alloca ptr
  %l61 = alloca { i64, ptr }
  %l62 = alloca ptr
  %l63 = alloca i64
  %l64 = alloca { i64, ptr }
  %l65 = alloca i32
  %l66 = alloca i32
  %l67 = alloca i1
  %l68 = alloca { i64, ptr }
  %l69 = alloca i64
  %l70 = alloca i64
  %l71 = alloca i64
  %l72 = alloca i1
  %l73 = alloca i1
  %l74 = alloca { i64, ptr }
  %l75 = alloca i64
  %l76 = alloca i64
  %l77 = alloca i64
  %l78 = alloca i64
  %l79 = alloca { i64, ptr }
  %l80 = alloca i64
  %l81 = alloca i32
  %l82 = alloca i32
  %l83 = alloca ptr
  %l84 = alloca i32
  %l85 = alloca ptr
  %l86 = alloca i1
  %l87 = alloca i1
  %l88 = alloca i32
  %l89 = alloca ptr
  %l90 = alloca i32
  %l91 = alloca ptr
  %l92 = alloca i1
  %l93 = alloca i1
  %l94 = alloca i32
  %l95 = alloca ptr
  %l96 = alloca i32
  %l97 = alloca ptr
  %l98 = alloca i1
  %l99 = alloca i64
  %l100 = alloca i1
  %l101 = alloca i1
  %l102 = alloca i32
  %l103 = alloca ptr
  %l104 = alloca i32
  %l105 = alloca ptr
  %l106 = alloca i1
  %l107 = alloca i1
  %l108 = alloca i32
  %l109 = alloca ptr
  %l110 = alloca i32
  %l111 = alloca ptr
  %l112 = alloca i1
  %l113 = alloca i32
  %l114 = alloca ptr
  %l115 = alloca i32
  %l116 = alloca ptr
  %l117 = alloca i1
  %l118 = alloca i1
  %l119 = alloca i32
  %l120 = alloca ptr
  %l121 = alloca i32
  %l122 = alloca ptr
  %l123 = alloca i1
  %l124 = alloca i64
  %l125 = alloca i64
  %l126 = alloca i32
  %l127 = alloca ptr
  %l128 = alloca i32
  %l129 = alloca ptr
  %l130 = alloca i1
  %l131 = alloca i1
  %l132 = alloca i32
  %l133 = alloca ptr
  %l134 = alloca i32
  %l135 = alloca ptr
  %l136 = alloca i1
  %l137 = alloca i64
  %l138 = alloca i64
  %l139 = alloca i32
  %l140 = alloca ptr
  %l141 = alloca i32
  %l142 = alloca ptr
  %l143 = alloca i1
  %l144 = alloca i64
  %l145 = alloca i64
  %l146 = alloca i64
  %l147 = alloca i64
  %l148 = alloca i64
  %l149 = alloca { i64, ptr }
  %l150 = alloca i64
  %l151 = alloca i32
  %l152 = alloca i32
  %l153 = alloca ptr
  %l154 = alloca i32
  %l155 = alloca ptr
  %l156 = alloca i1
  %l157 = alloca i1
  %l158 = alloca i1
  %l159 = alloca i32
  %l160 = alloca ptr
  %l161 = alloca i32
  %l162 = alloca ptr
  %l163 = alloca i1
  %l164 = alloca i1
  %l165 = alloca { i64, ptr }
  %l166 = alloca { i64, ptr }
  %l167 = alloca i64
  %l168 = alloca { i64, ptr }
  %l169 = alloca i64
  %l170 = alloca i1
  %l171 = alloca i1
  %l172 = alloca { i64, ptr }
  %l173 = alloca i64
  %l174 = alloca i32
  %l175 = alloca ptr
  %l176 = alloca i32
  %l177 = alloca ptr
  %l178 = alloca i1
  %l179 = alloca ptr
  %l180 = alloca ptr
  %l181 = alloca { i64, ptr }
  %l182 = alloca { i64, ptr }
  %l183 = alloca i64
  %l184 = alloca i32
  %l185 = alloca i64
  %l186 = alloca { i64, ptr }
  %l187 = alloca i64
  %l188 = alloca i32
  %l189 = alloca i64
  %l190 = alloca i64
  %l191 = alloca i1
  %l192 = alloca i1
  %l193 = alloca i1
  %l194 = alloca { i64, ptr }
  %l195 = alloca { i64, ptr }
  %l196 = alloca i64
  %l197 = alloca i64
  %l198 = alloca i1
  %l199 = alloca i64
  %l200 = alloca i1
  %l201 = alloca { i64, ptr }
  %l202 = alloca { i64, ptr }
  %l203 = alloca i64
  %l204 = alloca i64
  %l205 = alloca i1
  %l206 = alloca i64
  %l207 = alloca { i64, ptr }
  %l208 = alloca ptr
  %l209 = alloca ptr
  %l210 = alloca ptr
  %l211 = alloca i64
  %l212 = alloca i64
  %l213 = alloca ptr
  %l214 = alloca i32
  %l215 = alloca { i64, ptr }
  %l216 = alloca ptr
  %l217 = alloca ptr
  %l218 = alloca i64
  %l219 = alloca i32
  %l220 = alloca i32
  %l221 = alloca ptr
  %l222 = alloca i32
  %l223 = alloca ptr
  %l224 = alloca i1
  %l225 = alloca i1
  %l226 = alloca i32
  %l227 = alloca ptr
  %l228 = alloca i32
  %l229 = alloca ptr
  %l230 = alloca i1
  %l231 = alloca { i64, ptr }
  %l232 = alloca i64
  %l233 = alloca i32
  %l234 = alloca { i64, ptr }
  %l235 = alloca i64
  %l236 = alloca i32
  %l237 = alloca %"compiler/source:Span"
  %l238 = alloca ptr
  %l239 = alloca ptr
  %l240 = alloca ptr
  %l241 = alloca ptr
  %l242 = alloca { i64, ptr }
  %l243 = alloca i32
  %l244 = alloca i64
  %l245 = alloca i32
  %l246 = alloca i64
  %l247 = alloca i64
  %l248 = alloca i1
  %l249 = alloca i1
  %l250 = alloca i1
  %l251 = alloca { i64, ptr }
  %l252 = alloca { i64, ptr }
  %l253 = alloca { i64, ptr }
  %l254 = alloca %"compiler/source:Span"
  %l255 = alloca i1
  %l256 = alloca { i64, ptr }
  %l257 = alloca { i64, ptr }
  %l258 = alloca { i64, ptr }
  %l259 = alloca ptr
  %l260 = alloca i1
  %l261 = alloca %"compiler/cond:Global"
  %l262 = alloca ptr
  %l263 = alloca i64
  %l264 = alloca i64
  %l265 = alloca i64
  %l266 = alloca i64
  %l267 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.builder
  %s14room = alloca [64 x i8], align 8
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.builder
  %s18room = alloca [64 x i8], align 8
  %s19 = alloca %olang.builder
  %s19room = alloca [64 x i8], align 8
  %s20 = alloca %olang.scope
  %t9 = alloca %"compiler/diag:Diagnostics", align 8
  %t58 = alloca %"compiler/parse:Parser", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1
  store ptr %t1, ptr %l22
  %t2 = load ptr, ptr %l22
  %t3 = getelementptr %"compiler/load:Module", ptr %t2, i32 0, i32 22
  %t4 = load ptr, ptr %t3
  store ptr %t4, ptr %l23
  %t5 = load ptr, ptr %l23
  %t6 = icmp ne ptr %t5, null
  store i1 %t6, ptr %l24
  %t7 = load i1, ptr %l24
  br i1 %t7, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l1
  store ptr %t8, ptr %l25
  call void @compiler_2fdiag_3aDiagnostics_2ector(ptr %t9, ptr %v1, i1 false)
  %t10 = load %"compiler/diag:Diagnostics", ptr %t9
  store %"compiler/diag:Diagnostics" %t10, ptr %l26
  br label %bb4
bb4:
  %t11 = load %"compiler/diag:Diagnostics", ptr %l26
  %t12 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 192, i64 8)
  store %"compiler/diag:Diagnostics" %t11, ptr %t12
  store ptr %t12, ptr %l27
  %t13 = load ptr, ptr %l27
  %t14 = load ptr, ptr %l25
  %t15 = getelementptr %"compiler/load:Module", ptr %t14, i32 0, i32 23
  store ptr %t13, ptr %t15
  %t16 = load ptr, ptr %l1
  store ptr %t16, ptr %l28
  %t17 = load ptr, ptr %l28
  %t18 = getelementptr %"compiler/load:Module", ptr %t17, i32 0, i32 23
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l29
  %t20 = load ptr, ptr %l1
  store ptr %t20, ptr %l30
  %t21 = load ptr, ptr %l30
  %t22 = getelementptr %"compiler/load:Module", ptr %t21, i32 0, i32 0
  %t23 = load { i64, ptr }, ptr %t22
  store { i64, ptr } %t23, ptr %l31
  %t24 = load ptr, ptr %l1
  store ptr %t24, ptr %l32
  %t25 = load ptr, ptr %l32
  %t26 = getelementptr %"compiler/load:Module", ptr %t25, i32 0, i32 5
  %t27 = load ptr, ptr %t26
  store ptr %t27, ptr %l33
  %t28 = load ptr, ptr %l33
  %t29 = getelementptr %"compiler/source:Source", ptr %t28, i32 0, i32 1
  %t30 = load { i64, ptr }, ptr %t29
  store { i64, ptr } %t30, ptr %l34
  %t31 = load ptr, ptr %l29
  %t32 = load { i64, ptr }, ptr %l31
  %t33 = load { i64, ptr }, ptr %l34
  %t34 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAddFile(ptr %v1, ptr %v1, ptr %v1, ptr %t31, { i64, ptr } %t32, { i64, ptr } %t33, i1 false)
  store i64 %t34, ptr %l35
  br label %bb5
bb5:
  %t35 = load i64, ptr %l35
  store i64 %t35, ptr %l2
  %t36 = load ptr, ptr %l1
  store ptr %t36, ptr %l36
  %t37 = load ptr, ptr %l1
  store ptr %t37, ptr %l37
  %t38 = load ptr, ptr %l37
  %t39 = getelementptr %"compiler/load:Module", ptr %t38, i32 0, i32 5
  %t40 = load ptr, ptr %t39
  store ptr %t40, ptr %l38
  %t41 = load ptr, ptr %l1
  store ptr %t41, ptr %l39
  %t42 = load ptr, ptr %l39
  %t43 = getelementptr %"compiler/load:Module", ptr %t42, i32 0, i32 6
  %t44 = load ptr, ptr %t43
  store ptr %t44, ptr %l40
  %t45 = load ptr, ptr %l0
  store ptr %t45, ptr %l41
  %t46 = load ptr, ptr %l41
  %t47 = getelementptr %"compiler/load:Loader", ptr %t46, i32 0, i32 3
  %t48 = load ptr, ptr %t47
  store ptr %t48, ptr %l42
  %t49 = load ptr, ptr %l1
  store ptr %t49, ptr %l43
  %t50 = load ptr, ptr %l43
  %t51 = getelementptr %"compiler/load:Module", ptr %t50, i32 0, i32 10
  %t52 = load ptr, ptr %t51
  store ptr %t52, ptr %l44
  %t53 = load ptr, ptr %l1
  store ptr %t53, ptr %l45
  %t54 = load ptr, ptr %l45
  %t55 = getelementptr %"compiler/load:Module", ptr %t54, i32 0, i32 23
  %t56 = load ptr, ptr %t55
  store ptr %t56, ptr %l46
  %t57 = load i64, ptr %l2
  store i64 %t57, ptr %l47
  %t59 = load ptr, ptr %l38
  %t60 = load ptr, ptr %l40
  %t61 = load ptr, ptr %l42
  %t62 = load ptr, ptr %l44
  %t63 = load ptr, ptr %l46
  %t64 = load i64, ptr %l47
  call void @compiler_2fparse_3aParser_2ector(ptr %t58, ptr %v1, ptr %v1, ptr %v0, ptr %v1, ptr %v1, ptr %v1, ptr %t59, ptr %t60, ptr %t61, ptr %t62, ptr %t63, i64 %t64)
  %t65 = load %"compiler/parse:Parser", ptr %t58
  store %"compiler/parse:Parser" %t65, ptr %l48
  br label %bb6
bb6:
  %t66 = load %"compiler/parse:Parser", ptr %l48
  %t67 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 264, i64 8)
  store %"compiler/parse:Parser" %t66, ptr %t67
  store ptr %t67, ptr %l49
  %t68 = load ptr, ptr %l49
  %t69 = load ptr, ptr %l36
  %t70 = getelementptr %"compiler/load:Module", ptr %t69, i32 0, i32 22
  store ptr %t68, ptr %t70
  %t71 = load ptr, ptr %l1
  store ptr %t71, ptr %l50
  %t72 = load ptr, ptr %l1
  store ptr %t72, ptr %l51
  %t73 = load ptr, ptr %l51
  %t74 = getelementptr %"compiler/load:Module", ptr %t73, i32 0, i32 2
  %t75 = load { i64, ptr }, ptr %t74
  store { i64, ptr } %t75, ptr %l52
  %t76 = load { i64, ptr }, ptr %l52
  %t77 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s0, { i64, ptr } %t76, { i64, ptr } { i64 4, ptr @.d22 })
  store i1 %t77, ptr %l53
  br label %bb7
bb7:
  %t78 = load i1, ptr %l53
  %t79 = call %"compiler/cond:Scope" @compiler_2fcond_3aScope_2ector(ptr %v1, i1 %t78)
  store %"compiler/cond:Scope" %t79, ptr %l54
  br label %bb8
bb8:
  %t80 = load %"compiler/cond:Scope", ptr %l54
  %t81 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 24, i64 8)
  store %"compiler/cond:Scope" %t80, ptr %t81
  store ptr %t81, ptr %l55
  %t82 = load ptr, ptr %l55
  %t83 = load ptr, ptr %l50
  %t84 = getelementptr %"compiler/load:Module", ptr %t83, i32 0, i32 21
  store ptr %t82, ptr %t84
  %t85 = load ptr, ptr %l1
  store ptr %t85, ptr %l56
  %t86 = load ptr, ptr %l56
  %t87 = getelementptr %"compiler/load:Module", ptr %t86, i32 0, i32 6
  %t88 = load ptr, ptr %t87
  store ptr %t88, ptr %l57
  %t89 = load ptr, ptr %l57
  %t90 = getelementptr %"compiler/scan:Tokens", ptr %t89, i32 0, i32 0
  %t91 = load { i64, ptr }, ptr %t90
  store { i64, ptr } %t91, ptr %l58
  %t92 = load { i64, ptr }, ptr %l58
  store { i64, ptr } %t92, ptr %l3
  store %olang.scope zeroinitializer, ptr %s2
  %t93 = load ptr, ptr %l1
  store ptr %t93, ptr %l59
  %t94 = load ptr, ptr %l59
  %t95 = getelementptr %"compiler/load:Module", ptr %t94, i32 0, i32 20
  store ptr %t95, ptr %l60
  %t96 = load ptr, ptr %l60
  store ptr %t96, ptr %l4
  store i64 0, ptr %l5
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t97 = load ptr, ptr %l4
  store ptr %t97, ptr %l62
  %t98 = load i64, ptr %l5
  store i64 %t98, ptr %l63
  %t99 = load ptr, ptr %l62
  %t100 = load i64, ptr %l63
  %t101 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v1, ptr %t99, i64 %t100)
  %t102 = extractvalue { i32, { i64, ptr } } %t101, 1
  %t103 = extractvalue { i32, { i64, ptr } } %t101, 0
  store i32 %t103, ptr %l65
  %t104 = icmp ne i32 %t103, 0
  br i1 %t104, label %bb11, label %ok.105
ok.105:
  store { i64, ptr } %t102, ptr %l64
  br label %bb10
bb10:
  %t106 = load { i64, ptr }, ptr %l64
  store { i64, ptr } %t106, ptr %l61
  br label %bb15
bb11:
  %t107 = load i32, ptr %l65
  %t108 = ashr i32 %t107, 16
  store i32 %t108, ptr %l66
  %t109 = load i32, ptr %l66
  %t110 = icmp eq i32 %t109, 1
  store i1 %t110, ptr %l67
  %t111 = load i1, ptr %l67
  br i1 %t111, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @.c23)
  unreachable
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb118
bb15:
  %t112 = load { i64, ptr }, ptr %l61
  store { i64, ptr } %t112, ptr %l6
  %t113 = load { i64, ptr }, ptr %l6
  store { i64, ptr } %t113, ptr %l68
  %t114 = load { i64, ptr }, ptr %l68
  %t115 = extractvalue { i64, ptr } %t114, 0
  store i64 %t115, ptr %l69
  %t116 = load i64, ptr %l69
  store i64 %t116, ptr %l7
  store i64 0, ptr %l8
  br label %bb16
bb16:
  store %olang.scope zeroinitializer, ptr %s4
  %t117 = load i64, ptr %l8
  store i64 %t117, ptr %l70
  %t118 = load i64, ptr %l7
  store i64 %t118, ptr %l71
  %t119 = load i64, ptr %l70
  %t120 = load i64, ptr %l71
  %t121 = icmp slt i64 %t119, %t120
  store i1 %t121, ptr %l72
  %t122 = load i1, ptr %l72
  %t123 = xor i1 %t122, true
  store i1 %t123, ptr %l73
  %t124 = load i1, ptr %l73
  br i1 %t124, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s4)
  br label %bb116
bb18:
  br label %bb19
bb19:
  %t125 = load { i64, ptr }, ptr %l6
  store { i64, ptr } %t125, ptr %l74
  %t126 = load i64, ptr %l8
  store i64 %t126, ptr %l75
  %t127 = load i64, ptr %l75
  %t128 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t129 = load ptr, ptr %t128
  %t130 = getelementptr i64, ptr %t129, i64 %t127
  %t131 = load i64, ptr %t130
  store i64 %t131, ptr %l76
  %t132 = load i64, ptr %l76
  store i64 %t132, ptr %l9
  %t133 = load i64, ptr %l9
  store i64 %t133, ptr %l77
  %t134 = load i64, ptr %l77
  %t135 = add i64 %t134, 1
  store i64 %t135, ptr %l78
  %t136 = load i64, ptr %l78
  store i64 %t136, ptr %l10
  store i1 false, ptr %l11
  store i64 0, ptr %l12
  store i64 -1, ptr %l13
  store i64 0, ptr %l14
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s5
  %t137 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t137, ptr %l79
  %t138 = load i64, ptr %l10
  store i64 %t138, ptr %l80
  %t139 = load i64, ptr %l80
  %t140 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t141 = load ptr, ptr %t140
  %t142 = getelementptr %"compiler/token:Token", ptr %t141, i64 %t139
  %t143 = getelementptr %"compiler/token:Token", ptr %t142, i32 0, i32 0
  %t144 = load i32, ptr %t143
  store i32 %t144, ptr %l81
  %t145 = load i32, ptr %l81
  store i32 %t145, ptr %l15
  %t146 = load i32, ptr %l15
  store i32 %t146, ptr %l82
  store ptr %l82, ptr %l83
  store i32 0, ptr %l84
  store ptr %l84, ptr %l85
  %t147 = load ptr, ptr %l83
  %t148 = load ptr, ptr %l85
  %t149 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t147, ptr %t148)
  store i1 %t149, ptr %l86
  br label %bb21
bb21:
  %t150 = load i1, ptr %l86
  br i1 %t150, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l87
  br label %bb25
bb23:
  %t151 = load i32, ptr %l15
  store i32 %t151, ptr %l88
  store ptr %l88, ptr %l89
  store i32 8, ptr %l90
  store ptr %l90, ptr %l91
  %t152 = load ptr, ptr %l89
  %t153 = load ptr, ptr %l91
  %t154 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t152, ptr %t153)
  store i1 %t154, ptr %l92
  br label %bb24
bb24:
  %t155 = load i1, ptr %l92
  store i1 %t155, ptr %l87
  br label %bb25
bb25:
  %t156 = load i1, ptr %l87
  br i1 %t156, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l93
  br label %bb29
bb27:
  %t157 = load i32, ptr %l15
  store i32 %t157, ptr %l94
  store ptr %l94, ptr %l95
  store i32 94, ptr %l96
  store ptr %l96, ptr %l97
  %t158 = load ptr, ptr %l95
  %t159 = load ptr, ptr %l97
  %t160 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t158, ptr %t159)
  store i1 %t160, ptr %l98
  br label %bb28
bb28:
  %t161 = load i1, ptr %l98
  store i1 %t161, ptr %l93
  br label %bb29
bb29:
  %t162 = load i1, ptr %l93
  br i1 %t162, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s6
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  br label %bb65
bb31:
  br label %bb32
bb32:
  %t163 = load i64, ptr %l14
  store i64 %t163, ptr %l99
  %t164 = load i64, ptr %l99
  %t165 = icmp eq i64 %t164, 0
  store i1 %t165, ptr %l100
  %t166 = load i1, ptr %l100
  br i1 %t166, label %bb33, label %bb34
bb33:
  %t167 = load i32, ptr %l15
  store i32 %t167, ptr %l102
  store ptr %l102, ptr %l103
  store i32 60, ptr %l104
  store ptr %l104, ptr %l105
  %t168 = load ptr, ptr %l103
  %t169 = load ptr, ptr %l105
  %t170 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t168, ptr %t169)
  store i1 %t170, ptr %l106
  br label %bb35
bb34:
  store i1 false, ptr %l101
  br label %bb40
bb35:
  %t171 = load i1, ptr %l106
  br i1 %t171, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l107
  br label %bb39
bb37:
  %t172 = load i32, ptr %l15
  store i32 %t172, ptr %l108
  store ptr %l108, ptr %l109
  store i32 62, ptr %l110
  store ptr %l110, ptr %l111
  %t173 = load ptr, ptr %l109
  %t174 = load ptr, ptr %l111
  %t175 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t173, ptr %t174)
  store i1 %t175, ptr %l112
  br label %bb38
bb38:
  %t176 = load i1, ptr %l112
  store i1 %t176, ptr %l107
  br label %bb39
bb39:
  %t177 = load i1, ptr %l107
  store i1 %t177, ptr %l101
  br label %bb40
bb40:
  %t178 = load i1, ptr %l101
  br i1 %t178, label %bb41, label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s7
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s5)
  br label %bb65
bb42:
  br label %bb43
bb43:
  %t179 = load i32, ptr %l15
  store i32 %t179, ptr %l113
  store ptr %l113, ptr %l114
  store i32 90, ptr %l115
  store ptr %l115, ptr %l116
  %t180 = load ptr, ptr %l114
  %t181 = load ptr, ptr %l116
  %t182 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t180, ptr %t181)
  store i1 %t182, ptr %l117
  br label %bb44
bb44:
  %t183 = load i1, ptr %l117
  br i1 %t183, label %bb45, label %bb46
bb45:
  store i1 true, ptr %l118
  br label %bb48
bb46:
  %t184 = load i32, ptr %l15
  store i32 %t184, ptr %l119
  store ptr %l119, ptr %l120
  store i32 92, ptr %l121
  store ptr %l121, ptr %l122
  %t185 = load ptr, ptr %l120
  %t186 = load ptr, ptr %l122
  %t187 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t185, ptr %t186)
  store i1 %t187, ptr %l123
  br label %bb47
bb47:
  %t188 = load i1, ptr %l123
  store i1 %t188, ptr %l118
  br label %bb48
bb48:
  %t189 = load i1, ptr %l118
  br i1 %t189, label %bb49, label %bb50
bb49:
  store %olang.scope zeroinitializer, ptr %s8
  %t190 = load i64, ptr %l14
  store i64 %t190, ptr %l124
  %t191 = load i64, ptr %l124
  %t192 = add i64 %t191, 1
  store i64 %t192, ptr %l125
  %t193 = load i64, ptr %l125
  store i64 %t193, ptr %l14
  call void @__olang_scope_close(ptr %s8)
  br label %bb51
bb50:
  br label %bb51
bb51:
  %t194 = load i32, ptr %l15
  store i32 %t194, ptr %l126
  store ptr %l126, ptr %l127
  store i32 91, ptr %l128
  store ptr %l128, ptr %l129
  %t195 = load ptr, ptr %l127
  %t196 = load ptr, ptr %l129
  %t197 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t195, ptr %t196)
  store i1 %t197, ptr %l130
  br label %bb52
bb52:
  %t198 = load i1, ptr %l130
  br i1 %t198, label %bb53, label %bb54
bb53:
  store i1 true, ptr %l131
  br label %bb56
bb54:
  %t199 = load i32, ptr %l15
  store i32 %t199, ptr %l132
  store ptr %l132, ptr %l133
  store i32 93, ptr %l134
  store ptr %l134, ptr %l135
  %t200 = load ptr, ptr %l133
  %t201 = load ptr, ptr %l135
  %t202 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t200, ptr %t201)
  store i1 %t202, ptr %l136
  br label %bb55
bb55:
  %t203 = load i1, ptr %l136
  store i1 %t203, ptr %l131
  br label %bb56
bb56:
  %t204 = load i1, ptr %l131
  br i1 %t204, label %bb57, label %bb58
bb57:
  store %olang.scope zeroinitializer, ptr %s9
  %t205 = load i64, ptr %l14
  store i64 %t205, ptr %l137
  %t206 = load i64, ptr %l137
  %t207 = sub i64 %t206, 1
  store i64 %t207, ptr %l138
  %t208 = load i64, ptr %l138
  store i64 %t208, ptr %l14
  call void @__olang_scope_close(ptr %s9)
  br label %bb59
bb58:
  br label %bb59
bb59:
  %t209 = load i32, ptr %l15
  store i32 %t209, ptr %l139
  store ptr %l139, ptr %l140
  store i32 39, ptr %l141
  store ptr %l141, ptr %l142
  %t210 = load ptr, ptr %l140
  %t211 = load ptr, ptr %l142
  %t212 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t210, ptr %t211)
  store i1 %t212, ptr %l143
  br label %bb60
bb60:
  %t213 = load i1, ptr %l143
  br i1 %t213, label %bb61, label %bb62
bb61:
  store %olang.scope zeroinitializer, ptr %s10
  store i1 true, ptr %l11
  call void @__olang_scope_close(ptr %s10)
  br label %bb63
bb62:
  store %olang.scope zeroinitializer, ptr %s11
  %t214 = load i64, ptr %l12
  store i64 %t214, ptr %l144
  %t215 = load i64, ptr %l144
  %t216 = add i64 %t215, 1
  store i64 %t216, ptr %l145
  %t217 = load i64, ptr %l145
  store i64 %t217, ptr %l12
  %t218 = load i64, ptr %l10
  store i64 %t218, ptr %l146
  %t219 = load i64, ptr %l146
  store i64 %t219, ptr %l13
  call void @__olang_scope_close(ptr %s11)
  br label %bb63
bb63:
  %t220 = load i64, ptr %l10
  store i64 %t220, ptr %l147
  %t221 = load i64, ptr %l147
  %t222 = add i64 %t221, 1
  store i64 %t222, ptr %l148
  %t223 = load i64, ptr %l148
  store i64 %t223, ptr %l10
  call void @__olang_scope_close(ptr %s5)
  br label %bb64
bb64:
  br label %bb20
bb65:
  %t224 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t224, ptr %l149
  %t225 = load i64, ptr %l10
  store i64 %t225, ptr %l150
  %t226 = load i64, ptr %l150
  %t227 = getelementptr { i64, ptr }, ptr %l149, i32 0, i32 1
  %t228 = load ptr, ptr %t227
  %t229 = getelementptr %"compiler/token:Token", ptr %t228, i64 %t226
  %t230 = getelementptr %"compiler/token:Token", ptr %t229, i32 0, i32 0
  %t231 = load i32, ptr %t230
  store i32 %t231, ptr %l151
  %t232 = load i32, ptr %l151
  store i32 %t232, ptr %l16
  %t233 = load i32, ptr %l16
  store i32 %t233, ptr %l152
  store ptr %l152, ptr %l153
  store i32 60, ptr %l154
  store ptr %l154, ptr %l155
  %t234 = load ptr, ptr %l153
  %t235 = load ptr, ptr %l155
  %t236 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t234, ptr %t235)
  store i1 %t236, ptr %l156
  br label %bb66
bb66:
  %t237 = load i1, ptr %l156
  %t238 = xor i1 %t237, true
  store i1 %t238, ptr %l157
  %t239 = load i1, ptr %l157
  br i1 %t239, label %bb67, label %bb68
bb67:
  %t240 = load i32, ptr %l16
  store i32 %t240, ptr %l159
  store ptr %l159, ptr %l160
  store i32 62, ptr %l161
  store ptr %l161, ptr %l162
  %t241 = load ptr, ptr %l160
  %t242 = load ptr, ptr %l162
  %t243 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t241, ptr %t242)
  store i1 %t243, ptr %l163
  br label %bb69
bb68:
  store i1 false, ptr %l158
  br label %bb70
bb69:
  %t244 = load i1, ptr %l163
  %t245 = xor i1 %t244, true
  store i1 %t245, ptr %l164
  %t246 = load i1, ptr %l164
  store i1 %t246, ptr %l158
  br label %bb70
bb70:
  %t247 = load i1, ptr %l158
  br i1 %t247, label %bb71, label %bb72
bb71:
  store %olang.scope zeroinitializer, ptr %s12
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s4)
  br label %bb115
bb72:
  br label %bb73
bb73:
  store { i64, ptr } { i64 0, ptr @.d24 }, ptr %l165
  %t248 = load { i64, ptr }, ptr %l165
  store { i64, ptr } %t248, ptr %l166
  %t249 = load { i64, ptr }, ptr %l166
  %t250 = extractvalue { i64, ptr } %t249, 0
  store i64 %t250, ptr %l167
  %t251 = load i64, ptr %l167
  %t252 = mul i64 %t251, 1
  %t253 = call ptr @__olang_scope_alloc_zeroed(ptr %s4, i64 %t252)
  %t254 = insertvalue { i64, ptr } undef, i64 %t251, 0
  %t255 = insertvalue { i64, ptr } %t254, ptr %t253, 1
  store { i64, ptr } %t255, ptr %l168
  %t256 = getelementptr { i64, ptr }, ptr %l168, i32 0, i32 1
  %t257 = load ptr, ptr %t256
  %t258 = getelementptr { i64, ptr }, ptr %l166, i32 0, i32 1
  %t259 = load ptr, ptr %t258
  %t260 = load i64, ptr %l167
  %t261 = mul i64 %t260, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t257, ptr %t259, i64 %t261, i1 false)
  %t262 = load { i64, ptr }, ptr %l168
  store { i64, ptr } %t262, ptr %l17
  %t263 = load i64, ptr %l12
  store i64 %t263, ptr %l169
  %t264 = load i64, ptr %l169
  %t265 = icmp eq i64 %t264, 1
  store i1 %t265, ptr %l170
  %t266 = load i1, ptr %l170
  br i1 %t266, label %bb74, label %bb75
bb74:
  %t267 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t267, ptr %l172
  %t268 = load i64, ptr %l13
  store i64 %t268, ptr %l173
  %t269 = load i64, ptr %l173
  %t270 = getelementptr { i64, ptr }, ptr %l172, i32 0, i32 1
  %t271 = load ptr, ptr %t270
  %t272 = getelementptr %"compiler/token:Token", ptr %t271, i64 %t269
  %t273 = getelementptr %"compiler/token:Token", ptr %t272, i32 0, i32 0
  %t274 = load i32, ptr %t273
  store i32 %t274, ptr %l174
  store ptr %l174, ptr %l175
  store i32 1, ptr %l176
  store ptr %l176, ptr %l177
  %t275 = load ptr, ptr %l175
  %t276 = load ptr, ptr %l177
  %t277 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t275, ptr %t276)
  store i1 %t277, ptr %l178
  br label %bb76
bb75:
  store i1 false, ptr %l171
  br label %bb77
bb76:
  %t278 = load i1, ptr %l178
  store i1 %t278, ptr %l171
  br label %bb77
bb77:
  %t279 = load i1, ptr %l171
  br i1 %t279, label %bb78, label %bb79
bb78:
  store %olang.scope zeroinitializer, ptr %s13
  %t280 = load ptr, ptr %l1
  store ptr %t280, ptr %l179
  %t281 = load ptr, ptr %l179
  %t282 = getelementptr %"compiler/load:Module", ptr %t281, i32 0, i32 5
  %t283 = load ptr, ptr %t282
  store ptr %t283, ptr %l180
  %t284 = load ptr, ptr %l180
  %t285 = getelementptr %"compiler/source:Source", ptr %t284, i32 0, i32 1
  %t286 = load { i64, ptr }, ptr %t285
  store { i64, ptr } %t286, ptr %l181
  %t287 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t287, ptr %l182
  %t288 = load i64, ptr %l13
  store i64 %t288, ptr %l183
  %t289 = load i64, ptr %l183
  %t290 = getelementptr { i64, ptr }, ptr %l182, i32 0, i32 1
  %t291 = load ptr, ptr %t290
  %t292 = getelementptr %"compiler/token:Token", ptr %t291, i64 %t289
  %t293 = getelementptr %"compiler/token:Token", ptr %t292, i32 0, i32 2
  %t294 = load i32, ptr %t293
  store i32 %t294, ptr %l184
  %t295 = load i32, ptr %l184
  %t296 = sext i32 %t295 to i64
  store i64 %t296, ptr %l185
  %t297 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t297, ptr %l186
  %t298 = load i64, ptr %l13
  store i64 %t298, ptr %l187
  %t299 = load i64, ptr %l187
  %t300 = getelementptr { i64, ptr }, ptr %l186, i32 0, i32 1
  %t301 = load ptr, ptr %t300
  %t302 = getelementptr %"compiler/token:Token", ptr %t301, i64 %t299
  %t303 = getelementptr %"compiler/token:Token", ptr %t302, i32 0, i32 3
  %t304 = load i32, ptr %t303
  store i32 %t304, ptr %l188
  %t305 = load i32, ptr %l188
  %t306 = sext i32 %t305 to i64
  store i64 %t306, ptr %l189
  %t307 = load { i64, ptr }, ptr %l181
  %t308 = extractvalue { i64, ptr } %t307, 0
  store i64 %t308, ptr %l190
  %t309 = load i64, ptr %l185
  %t310 = icmp sge i64 %t309, 0
  store i1 %t310, ptr %l191
  %t311 = load i1, ptr %l191
  br i1 %t311, label %bb80, label %bb81
bb79:
  store %olang.scope zeroinitializer, ptr %s15
  %t312 = load i64, ptr %l12
  store i64 %t312, ptr %l199
  %t313 = load i64, ptr %l199
  %t314 = icmp sgt i64 %t313, 0
  store i1 %t314, ptr %l200
  %t315 = load i1, ptr %l200
  br i1 %t315, label %bb89, label %bb90
bb80:
  %t316 = load i64, ptr %l185
  %t317 = load i64, ptr %l189
  %t318 = icmp sle i64 %t316, %t317
  store i1 %t318, ptr %l192
  %t319 = load i1, ptr %l192
  br i1 %t319, label %bb82, label %bb83
bb81:
  call void @__olang_check_failed(ptr @.c25)
  unreachable
bb82:
  %t320 = load i64, ptr %l189
  %t321 = load i64, ptr %l190
  %t322 = icmp sle i64 %t320, %t321
  store i1 %t322, ptr %l193
  %t323 = load i1, ptr %l193
  br i1 %t323, label %bb84, label %bb85
bb83:
  call void @__olang_check_failed(ptr @.c25)
  unreachable
bb84:
  %t324 = getelementptr { i64, ptr }, ptr %l181, i32 0, i32 1
  %t325 = load ptr, ptr %t324
  %t326 = load i64, ptr %l185
  %t327 = load i64, ptr %l189
  %t328 = getelementptr i8, ptr %t325, i64 %t326
  %t329 = sub i64 %t327, %t326
  %t330 = insertvalue { i64, ptr } undef, i64 %t329, 0
  %t331 = insertvalue { i64, ptr } %t330, ptr %t328, 1
  store { i64, ptr } %t331, ptr %l194
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s14
  store ptr %s14room, ptr %s14
  %t332 = load { i64, ptr }, ptr %l194
  %t333 = extractvalue { i64, ptr } %t332, 1
  %t334 = extractvalue { i64, ptr } %t332, 0
  call void @__olang_sb_put(ptr %s14, ptr %t333, i64 %t334)
  %t335 = load ptr, ptr %s14
  %t336 = getelementptr %olang.builder, ptr %s14, i32 0, i32 1
  %t337 = load i64, ptr %t336
  %t338 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t337)
  call void @llvm.memcpy.p0.p0.i64(ptr %t338, ptr %t335, i64 %t337, i1 false)
  %t339 = insertvalue { i64, ptr } undef, i64 %t337, 0
  %t340 = insertvalue { i64, ptr } %t339, ptr %t338, 1
  store { i64, ptr } %t340, ptr %l195
  call void @__olang_sb_done(ptr %s14)
  %t341 = load { i64, ptr }, ptr %l17
  %t342 = extractvalue { i64, ptr } %t341, 0
  store i64 %t342, ptr %l196
  %t343 = load { i64, ptr }, ptr %l195
  %t344 = extractvalue { i64, ptr } %t343, 0
  store i64 %t344, ptr %l197
  %t345 = load i64, ptr %l196
  %t346 = load i64, ptr %l197
  %t347 = icmp eq i64 %t345, %t346
  store i1 %t347, ptr %l198
  %t348 = load i1, ptr %l198
  br i1 %t348, label %bb86, label %bb87
bb85:
  call void @__olang_check_failed(ptr @.c25)
  unreachable
bb86:
  %t349 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t350 = load ptr, ptr %t349
  %t351 = getelementptr { i64, ptr }, ptr %l195, i32 0, i32 1
  %t352 = load ptr, ptr %t351
  %t353 = load i64, ptr %l197
  %t354 = mul i64 %t353, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t350, ptr %t352, i64 %t354, i1 false)
  br label %bb88
bb87:
  %t355 = load { i64, ptr }, ptr %l195
  store { i64, ptr } %t355, ptr %l17
  br label %bb88
bb88:
  call void @__olang_scope_close(ptr %s13)
  br label %bb95
bb89:
  store %olang.scope zeroinitializer, ptr %s16
  store { i64, ptr } { i64 1, ptr @.d26 }, ptr %l201
  %t356 = load { i64, ptr }, ptr %l201
  store { i64, ptr } %t356, ptr %l202
  %t357 = load { i64, ptr }, ptr %l17
  %t358 = extractvalue { i64, ptr } %t357, 0
  store i64 %t358, ptr %l203
  %t359 = load { i64, ptr }, ptr %l202
  %t360 = extractvalue { i64, ptr } %t359, 0
  store i64 %t360, ptr %l204
  %t361 = load i64, ptr %l203
  %t362 = load i64, ptr %l204
  %t363 = icmp eq i64 %t361, %t362
  store i1 %t363, ptr %l205
  %t364 = load i1, ptr %l205
  br i1 %t364, label %bb91, label %bb92
bb90:
  br label %bb94
bb91:
  %t365 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t366 = load ptr, ptr %t365
  %t367 = getelementptr { i64, ptr }, ptr %l202, i32 0, i32 1
  %t368 = load ptr, ptr %t367
  %t369 = load i64, ptr %l204
  %t370 = mul i64 %t369, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t366, ptr %t368, i64 %t370, i1 false)
  br label %bb93
bb92:
  %t371 = load { i64, ptr }, ptr %l202
  %t372 = extractvalue { i64, ptr } %t371, 0
  store i64 %t372, ptr %l206
  %t373 = load i64, ptr %l206
  %t374 = mul i64 %t373, 1
  %t375 = call ptr @__olang_scope_alloc_zeroed(ptr %s4, i64 %t374)
  %t376 = insertvalue { i64, ptr } undef, i64 %t373, 0
  %t377 = insertvalue { i64, ptr } %t376, ptr %t375, 1
  store { i64, ptr } %t377, ptr %l207
  %t378 = getelementptr { i64, ptr }, ptr %l207, i32 0, i32 1
  %t379 = load ptr, ptr %t378
  %t380 = getelementptr { i64, ptr }, ptr %l202, i32 0, i32 1
  %t381 = load ptr, ptr %t380
  %t382 = load i64, ptr %l206
  %t383 = mul i64 %t382, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t379, ptr %t381, i64 %t383, i1 false)
  %t384 = load { i64, ptr }, ptr %l207
  store { i64, ptr } %t384, ptr %l17
  br label %bb93
bb93:
  call void @__olang_scope_close(ptr %s16)
  br label %bb94
bb94:
  call void @__olang_scope_close(ptr %s15)
  br label %bb95
bb95:
  %t385 = load ptr, ptr %l1
  store ptr %t385, ptr %l209
  %t386 = load ptr, ptr %l209
  %t387 = getelementptr %"compiler/load:Module", ptr %t386, i32 0, i32 22
  %t388 = load ptr, ptr %t387
  store ptr %t388, ptr %l210
  %t389 = load i64, ptr %l10
  store i64 %t389, ptr %l211
  %t390 = load i64, ptr %l211
  %t391 = add i64 %t390, 1
  store i64 %t391, ptr %l212
  %t392 = load ptr, ptr %l210
  %t393 = load i64, ptr %l212
  %t394 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eExprAt(ptr %v1, ptr %t392, i64 %t393)
  %t395 = extractvalue { i32, ptr } %t394, 1
  %t396 = extractvalue { i32, ptr } %t394, 0
  store i32 %t396, ptr %l214
  %t397 = icmp ne i32 %t396, 0
  br i1 %t397, label %bb97, label %ok.398
ok.398:
  store ptr %t395, ptr %l213
  br label %bb96
bb96:
  %t399 = load ptr, ptr %l213
  store ptr %t399, ptr %l208
  br label %bb99
bb97:
  br label %bb98
bb98:
  store %olang.scope zeroinitializer, ptr %s17
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s4)
  br label %bb115
bb99:
  %t400 = load ptr, ptr %l208
  store ptr %t400, ptr %l18
  %t401 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t401, ptr %l215
  %t402 = load ptr, ptr %l1
  store ptr %t402, ptr %l216
  %t403 = load ptr, ptr %l216
  %t404 = getelementptr %"compiler/load:Module", ptr %t403, i32 0, i32 22
  %t405 = load ptr, ptr %t404
  store ptr %t405, ptr %l217
  %t406 = load ptr, ptr %l217
  %t407 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ePos(ptr %v1, ptr %t406)
  store i64 %t407, ptr %l218
  br label %bb100
bb100:
  %t408 = load i64, ptr %l218
  %t409 = getelementptr { i64, ptr }, ptr %l215, i32 0, i32 1
  %t410 = load ptr, ptr %t409
  %t411 = getelementptr %"compiler/token:Token", ptr %t410, i64 %t408
  %t412 = getelementptr %"compiler/token:Token", ptr %t411, i32 0, i32 0
  %t413 = load i32, ptr %t412
  store i32 %t413, ptr %l219
  %t414 = load i32, ptr %l219
  store i32 %t414, ptr %l19
  %t415 = load i32, ptr %l19
  store i32 %t415, ptr %l220
  store ptr %l220, ptr %l221
  store i32 8, ptr %l222
  store ptr %l222, ptr %l223
  %t416 = load ptr, ptr %l221
  %t417 = load ptr, ptr %l223
  %t418 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t416, ptr %t417)
  store i1 %t418, ptr %l224
  br label %bb101
bb101:
  %t419 = load i1, ptr %l224
  br i1 %t419, label %bb102, label %bb103
bb102:
  store i1 true, ptr %l225
  br label %bb105
bb103:
  %t420 = load i32, ptr %l19
  store i32 %t420, ptr %l226
  store ptr %l226, ptr %l227
  store i32 0, ptr %l228
  store ptr %l228, ptr %l229
  %t421 = load ptr, ptr %l227
  %t422 = load ptr, ptr %l229
  %t423 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t421, ptr %t422)
  store i1 %t423, ptr %l230
  br label %bb104
bb104:
  %t424 = load i1, ptr %l230
  store i1 %t424, ptr %l225
  br label %bb105
bb105:
  %t425 = load i1, ptr %l225
  store i1 %t425, ptr %l20
  %t426 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t426, ptr %l231
  %t427 = load i64, ptr %l9
  store i64 %t427, ptr %l232
  %t428 = load i64, ptr %l232
  %t429 = getelementptr { i64, ptr }, ptr %l231, i32 0, i32 1
  %t430 = load ptr, ptr %t429
  %t431 = getelementptr %"compiler/token:Token", ptr %t430, i64 %t428
  %t432 = getelementptr %"compiler/token:Token", ptr %t431, i32 0, i32 2
  %t433 = load i32, ptr %t432
  store i32 %t433, ptr %l233
  %t434 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t434, ptr %l234
  %t435 = load i64, ptr %l9
  store i64 %t435, ptr %l235
  %t436 = load i64, ptr %l235
  %t437 = getelementptr { i64, ptr }, ptr %l234, i32 0, i32 1
  %t438 = load ptr, ptr %t437
  %t439 = getelementptr %"compiler/token:Token", ptr %t438, i64 %t436
  %t440 = getelementptr %"compiler/token:Token", ptr %t439, i32 0, i32 3
  %t441 = load i32, ptr %t440
  store i32 %t441, ptr %l236
  %t442 = load i32, ptr %l233
  %t443 = load i32, ptr %l236
  %t444 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s4, i32 %t442, i32 %t443)
  store %"compiler/source:Span" %t444, ptr %l237
  br label %bb106
bb106:
  %t445 = load %"compiler/source:Span", ptr %l237
  store %"compiler/source:Span" %t445, ptr %l21
  %t446 = load ptr, ptr %l1
  store ptr %t446, ptr %l238
  %t447 = load ptr, ptr %l238
  %t448 = getelementptr %"compiler/load:Module", ptr %t447, i32 0, i32 21
  %t449 = load ptr, ptr %t448
  store ptr %t449, ptr %l239
  %t450 = load ptr, ptr %l1
  store ptr %t450, ptr %l240
  %t451 = load ptr, ptr %l240
  %t452 = getelementptr %"compiler/load:Module", ptr %t451, i32 0, i32 5
  %t453 = load ptr, ptr %t452
  store ptr %t453, ptr %l241
  %t454 = load ptr, ptr %l241
  %t455 = getelementptr %"compiler/source:Source", ptr %t454, i32 0, i32 1
  %t456 = load { i64, ptr }, ptr %t455
  store { i64, ptr } %t456, ptr %l242
  %t457 = getelementptr %"compiler/source:Span", ptr %l21, i32 0, i32 0
  %t458 = load i32, ptr %t457
  store i32 %t458, ptr %l243
  %t459 = load i32, ptr %l243
  %t460 = sext i32 %t459 to i64
  store i64 %t460, ptr %l244
  %t461 = getelementptr %"compiler/source:Span", ptr %l21, i32 0, i32 1
  %t462 = load i32, ptr %t461
  store i32 %t462, ptr %l245
  %t463 = load i32, ptr %l245
  %t464 = sext i32 %t463 to i64
  store i64 %t464, ptr %l246
  %t465 = load { i64, ptr }, ptr %l242
  %t466 = extractvalue { i64, ptr } %t465, 0
  store i64 %t466, ptr %l247
  %t467 = load i64, ptr %l244
  %t468 = icmp sge i64 %t467, 0
  store i1 %t468, ptr %l248
  %t469 = load i1, ptr %l248
  br i1 %t469, label %bb107, label %bb108
bb107:
  %t470 = load i64, ptr %l244
  %t471 = load i64, ptr %l246
  %t472 = icmp sle i64 %t470, %t471
  store i1 %t472, ptr %l249
  %t473 = load i1, ptr %l249
  br i1 %t473, label %bb109, label %bb110
bb108:
  call void @__olang_check_failed(ptr @.c27)
  unreachable
bb109:
  %t474 = load i64, ptr %l246
  %t475 = load i64, ptr %l247
  %t476 = icmp sle i64 %t474, %t475
  store i1 %t476, ptr %l250
  %t477 = load i1, ptr %l250
  br i1 %t477, label %bb111, label %bb112
bb110:
  call void @__olang_check_failed(ptr @.c27)
  unreachable
bb111:
  %t478 = getelementptr { i64, ptr }, ptr %l242, i32 0, i32 1
  %t479 = load ptr, ptr %t478
  %t480 = load i64, ptr %l244
  %t481 = load i64, ptr %l246
  %t482 = getelementptr i8, ptr %t479, i64 %t480
  %t483 = sub i64 %t481, %t480
  %t484 = insertvalue { i64, ptr } undef, i64 %t483, 0
  %t485 = insertvalue { i64, ptr } %t484, ptr %t482, 1
  store { i64, ptr } %t485, ptr %l251
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s18
  store ptr %s18room, ptr %s18
  %t486 = load { i64, ptr }, ptr %l251
  %t487 = extractvalue { i64, ptr } %t486, 1
  %t488 = extractvalue { i64, ptr } %t486, 0
  call void @__olang_sb_put(ptr %s18, ptr %t487, i64 %t488)
  %t489 = load ptr, ptr %s18
  %t490 = getelementptr %olang.builder, ptr %s18, i32 0, i32 1
  %t491 = load i64, ptr %t490
  %t492 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t491)
  call void @llvm.memcpy.p0.p0.i64(ptr %t492, ptr %t489, i64 %t491, i1 false)
  %t493 = insertvalue { i64, ptr } undef, i64 %t491, 0
  %t494 = insertvalue { i64, ptr } %t493, ptr %t492, 1
  store { i64, ptr } %t494, ptr %l252
  call void @__olang_sb_done(ptr %s18)
  %t495 = load { i64, ptr }, ptr %l252
  %t496 = extractvalue { i64, ptr } %t495, 0
  %t497 = extractvalue { i64, ptr } %t495, 1
  %t498 = mul i64 %t496, 1
  %t499 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t498)
  call void @llvm.memcpy.p0.p0.i64(ptr %t499, ptr %t497, i64 %t498, i1 false)
  %t500 = insertvalue { i64, ptr } undef, i64 %t496, 0
  %t501 = insertvalue { i64, ptr } %t500, ptr %t499, 1
  store { i64, ptr } %t501, ptr %l253
  %t502 = load %"compiler/source:Span", ptr %l21
  store %"compiler/source:Span" %t502, ptr %l254
  %t503 = load i1, ptr %l11
  store i1 %t503, ptr %l255
  %t504 = load { i64, ptr }, ptr %l17
  store { i64, ptr } %t504, ptr %l256
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s19
  store ptr %s19room, ptr %s19
  %t505 = load { i64, ptr }, ptr %l256
  %t506 = extractvalue { i64, ptr } %t505, 1
  %t507 = extractvalue { i64, ptr } %t505, 0
  call void @__olang_sb_put(ptr %s19, ptr %t506, i64 %t507)
  %t508 = load ptr, ptr %s19
  %t509 = getelementptr %olang.builder, ptr %s19, i32 0, i32 1
  %t510 = load i64, ptr %t509
  %t511 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t510)
  call void @llvm.memcpy.p0.p0.i64(ptr %t511, ptr %t508, i64 %t510, i1 false)
  %t512 = insertvalue { i64, ptr } undef, i64 %t510, 0
  %t513 = insertvalue { i64, ptr } %t512, ptr %t511, 1
  store { i64, ptr } %t513, ptr %l257
  call void @__olang_sb_done(ptr %s19)
  %t514 = load { i64, ptr }, ptr %l257
  %t515 = extractvalue { i64, ptr } %t514, 0
  %t516 = extractvalue { i64, ptr } %t514, 1
  %t517 = mul i64 %t515, 1
  %t518 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t517)
  call void @llvm.memcpy.p0.p0.i64(ptr %t518, ptr %t516, i64 %t517, i1 false)
  %t519 = insertvalue { i64, ptr } undef, i64 %t515, 0
  %t520 = insertvalue { i64, ptr } %t519, ptr %t518, 1
  store { i64, ptr } %t520, ptr %l258
  %t521 = load ptr, ptr %l18
  store ptr %t521, ptr %l259
  %t522 = load i1, ptr %l20
  store i1 %t522, ptr %l260
  %t523 = load { i64, ptr }, ptr %l253
  %t524 = load %"compiler/source:Span", ptr %l254
  %t525 = load i1, ptr %l255
  %t526 = load { i64, ptr }, ptr %l258
  %t527 = load ptr, ptr %l259
  %t528 = load i1, ptr %l260
  %t529 = call %"compiler/cond:Global" @compiler_2fcond_3aGlobal_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t523, %"compiler/source:Span" %t524, i1 %t525, { i64, ptr } %t526, ptr %t527, i1 %t528)
  store %"compiler/cond:Global" %t529, ptr %l261
  br label %bb113
bb112:
  call void @__olang_check_failed(ptr @.c27)
  unreachable
bb113:
  %t530 = load %"compiler/cond:Global", ptr %l261
  %t531 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 64, i64 8)
  store %"compiler/cond:Global" %t530, ptr %t531
  store ptr %t531, ptr %l262
  %t532 = load ptr, ptr %l239
  %t533 = load ptr, ptr %l262
  call void @compiler_2fcond_2ecompiler_2fcond_3aScope_2eAdd(ptr %v1, ptr %v1, ptr %t532, ptr %t533)
  br label %bb114
bb114:
  call void @__olang_scope_close(ptr %s4)
  br label %bb115
bb115:
  store %olang.scope zeroinitializer, ptr %s20
  %t534 = load i64, ptr %l8
  store i64 %t534, ptr %l263
  %t535 = load i64, ptr %l263
  %t536 = add i64 %t535, 1
  store i64 %t536, ptr %l264
  %t537 = load i64, ptr %l264
  store i64 %t537, ptr %l8
  call void @__olang_scope_close(ptr %s20)
  br label %bb16
bb116:
  %t538 = load i64, ptr %l5
  store i64 %t538, ptr %l265
  %t539 = load i64, ptr %l7
  store i64 %t539, ptr %l266
  %t540 = load i64, ptr %l265
  %t541 = load i64, ptr %l266
  %t542 = add i64 %t540, %t541
  store i64 %t542, ptr %l267
  %t543 = load i64, ptr %l267
  store i64 %t543, ptr %l5
  call void @__olang_scope_close(ptr %s3)
  br label %bb117
bb117:
  br label %bb9
bb118:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fload_2ecompiler_2fload_3aLoader_2eDecide(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i1
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i1
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i1
  %l43 = alloca i1
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca ptr
  %l50 = alloca ptr
  %l51 = alloca i64
  %l52 = alloca i32
  %l53 = alloca i32
  %l54 = alloca i1
  %l55 = alloca i1
  %l56 = alloca ptr
  %l57 = alloca ptr
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca i1
  %l62 = alloca ptr
  %l63 = alloca ptr
  %l64 = alloca i64
  %l65 = alloca i64
  %l66 = alloca ptr
  %l67 = alloca ptr
  %l68 = alloca i64
  %l69 = alloca i64
  %l70 = alloca i64
  %l71 = alloca i1
  %l72 = alloca i64
  %l73 = alloca i64
  %l74 = alloca i1
  %l75 = alloca i64
  %l76 = alloca i64
  %l77 = alloca i64
  %l78 = alloca i64
  %l79 = alloca i64
  %l80 = alloca i64
  %l81 = alloca i64
  %l82 = alloca i64
  %l83 = alloca i64
  %l84 = alloca i64
  %l85 = alloca i64
  %l86 = alloca i1
  %l87 = alloca i1
  %l88 = alloca i64
  %l89 = alloca i64
  %l90 = alloca i64
  %l91 = alloca i64
  %l92 = alloca i64
  %l93 = alloca ptr
  %l94 = alloca ptr
  %l95 = alloca i64
  %l96 = alloca i64
  %l97 = alloca i64
  %l98 = alloca i1
  %l99 = alloca i1
  %l100 = alloca ptr
  %l101 = alloca ptr
  %l102 = alloca i64
  %l103 = alloca i64
  %l104 = alloca i1
  %l105 = alloca ptr
  %l106 = alloca ptr
  %l107 = alloca i64
  %l108 = alloca i64
  %l109 = alloca i64
  %l110 = alloca i64
  %l111 = alloca i64
  %l112 = alloca i64
  %l113 = alloca ptr
  %l114 = alloca ptr
  %l115 = alloca i64
  %l116 = alloca ptr
  %l117 = alloca i64
  %l118 = alloca ptr
  %l119 = alloca i64
  %l120 = alloca ptr
  %l121 = alloca { i64, ptr }
  %l122 = alloca ptr
  %l123 = alloca ptr
  %l124 = alloca i64
  %l125 = alloca i64
  %l126 = alloca i1
  %l127 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l18
  %t2 = load ptr, ptr %l18
  %t3 = getelementptr %"compiler/load:Loader", ptr %t2, i32 0, i32 5
  store ptr %t3, ptr %l19
  %t4 = load i64, ptr %l1
  store i64 %t4, ptr %l20
  %t5 = load ptr, ptr %l19
  %t6 = load i64, ptr %l20
  %t7 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t5, i64 %t6)
  store ptr %t7, ptr %l21
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l21
  store ptr %t8, ptr %l4
  store %olang.scope zeroinitializer, ptr %s1
  store i64 0, ptr %l5
  %t9 = load ptr, ptr %l4
  store ptr %t9, ptr %l22
  %t10 = load ptr, ptr %l22
  %t11 = getelementptr %"compiler/load:Module", ptr %t10, i32 0, i32 12
  store ptr %t11, ptr %l23
  %t12 = load ptr, ptr %l23
  %t13 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2eLen_3cI32_3e(ptr %v0, ptr %t12)
  store i64 %t13, ptr %l24
  br label %bb2
bb2:
  %t14 = load i64, ptr %l24
  store i64 %t14, ptr %l6
  store i64 1, ptr %l7
  %t15 = load i64, ptr %l6
  store i64 %t15, ptr %l25
  %t16 = load i64, ptr %l5
  store i64 %t16, ptr %l26
  %t17 = load i64, ptr %l25
  %t18 = load i64, ptr %l26
  %t19 = icmp sgt i64 %t17, %t18
  store i1 %t19, ptr %l27
  %t20 = load i1, ptr %l27
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t21 = load i64, ptr %l7
  store i64 %t21, ptr %l29
  %t22 = load i64, ptr %l29
  %t23 = icmp sgt i64 %t22, 0
  store i1 %t23, ptr %l30
  %t24 = load i1, ptr %l30
  br i1 %t24, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l28
  br label %bb8
bb5:
  %t25 = load i64, ptr %l6
  store i64 %t25, ptr %l32
  %t26 = load i64, ptr %l5
  store i64 %t26, ptr %l33
  %t27 = load i64, ptr %l32
  %t28 = load i64, ptr %l33
  %t29 = sub i64 %t27, %t28
  store i64 %t29, ptr %l34
  %t30 = load i64, ptr %l7
  store i64 %t30, ptr %l35
  %t31 = load i64, ptr %l34
  %t32 = load i64, ptr %l35
  %t33 = add i64 %t31, %t32
  store i64 %t33, ptr %l36
  %t34 = load i64, ptr %l36
  %t35 = sub i64 %t34, 1
  store i64 %t35, ptr %l37
  %t36 = load i64, ptr %l7
  store i64 %t36, ptr %l38
  %t37 = load i64, ptr %l37
  %t38 = load i64, ptr %l38
  %t39 = sdiv i64 %t37, %t38
  store i64 %t39, ptr %l39
  %t40 = load i64, ptr %l39
  store i64 %t40, ptr %l31
  br label %bb7
bb6:
  store i64 0, ptr %l31
  br label %bb7
bb7:
  %t41 = load i64, ptr %l31
  store i64 %t41, ptr %l28
  br label %bb8
bb8:
  %t42 = load i64, ptr %l28
  store i64 %t42, ptr %l8
  store i64 0, ptr %l9
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t43 = load i64, ptr %l9
  store i64 %t43, ptr %l40
  %t44 = load i64, ptr %l8
  store i64 %t44, ptr %l41
  %t45 = load i64, ptr %l40
  %t46 = load i64, ptr %l41
  %t47 = icmp slt i64 %t45, %t46
  store i1 %t47, ptr %l42
  %t48 = load i1, ptr %l42
  %t49 = xor i1 %t48, true
  store i1 %t49, ptr %l43
  %t50 = load i1, ptr %l43
  br i1 %t50, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb45
bb11:
  br label %bb12
bb12:
  %t51 = load i64, ptr %l5
  store i64 %t51, ptr %l44
  %t52 = load i64, ptr %l9
  store i64 %t52, ptr %l45
  %t53 = load i64, ptr %l7
  store i64 %t53, ptr %l46
  %t54 = load i64, ptr %l45
  %t55 = load i64, ptr %l46
  %t56 = mul i64 %t54, %t55
  store i64 %t56, ptr %l47
  %t57 = load i64, ptr %l44
  %t58 = load i64, ptr %l47
  %t59 = add i64 %t57, %t58
  store i64 %t59, ptr %l48
  %t60 = load i64, ptr %l48
  store i64 %t60, ptr %l10
  %t61 = load ptr, ptr %l4
  store ptr %t61, ptr %l49
  %t62 = load ptr, ptr %l49
  %t63 = getelementptr %"compiler/load:Module", ptr %t62, i32 0, i32 12
  store ptr %t63, ptr %l50
  %t64 = load i64, ptr %l10
  store i64 %t64, ptr %l51
  %t65 = load ptr, ptr %l50
  %t66 = load i64, ptr %l51
  %t67 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2eAt_3cI32_3e(ptr %v0, ptr %t65, i64 %t66)
  store i32 %t67, ptr %l52
  br label %bb13
bb13:
  %t68 = load i32, ptr %l2
  store i32 %t68, ptr %l53
  %t69 = load i32, ptr %l52
  %t70 = load i32, ptr %l53
  %t71 = icmp ne i32 %t69, %t70
  store i1 %t71, ptr %l54
  %t72 = load i1, ptr %l54
  br i1 %t72, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l55
  br label %bb17
bb15:
  %t73 = load ptr, ptr %l4
  store ptr %t73, ptr %l56
  %t74 = load ptr, ptr %l56
  %t75 = getelementptr %"compiler/load:Module", ptr %t74, i32 0, i32 14
  store ptr %t75, ptr %l57
  %t76 = load i64, ptr %l10
  store i64 %t76, ptr %l58
  %t77 = load ptr, ptr %l57
  %t78 = load i64, ptr %l58
  %t79 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t77, i64 %t78)
  store i64 %t79, ptr %l59
  br label %bb16
bb16:
  %t80 = load i64, ptr @G_2ecompiler_2fload_2ePending
  store i64 %t80, ptr %l60
  %t81 = load i64, ptr %l59
  %t82 = load i64, ptr %l60
  %t83 = icmp ne i64 %t81, %t82
  store i1 %t83, ptr %l61
  %t84 = load i1, ptr %l61
  store i1 %t84, ptr %l55
  br label %bb17
bb17:
  %t85 = load i1, ptr %l55
  br i1 %t85, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s3
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  br label %bb44
bb19:
  br label %bb20
bb20:
  %t86 = load ptr, ptr %l4
  store ptr %t86, ptr %l62
  %t87 = load ptr, ptr %l62
  %t88 = getelementptr %"compiler/load:Module", ptr %t87, i32 0, i32 14
  store ptr %t88, ptr %l63
  %t89 = load i64, ptr %l10
  store i64 %t89, ptr %l64
  %t90 = load i64, ptr %l3
  store i64 %t90, ptr %l65
  %t91 = load ptr, ptr %l63
  %t92 = load i64, ptr %l64
  %t93 = load i64, ptr %l65
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t91, i64 %t92, i64 %t93)
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s4
  store i64 0, ptr %l11
  %t94 = load ptr, ptr %l4
  store ptr %t94, ptr %l66
  %t95 = load ptr, ptr %l66
  %t96 = getelementptr %"compiler/load:Module", ptr %t95, i32 0, i32 12
  store ptr %t96, ptr %l67
  %t97 = load ptr, ptr %l67
  %t98 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2eLen_3cI32_3e(ptr %v0, ptr %t97)
  store i64 %t98, ptr %l68
  br label %bb22
bb22:
  %t99 = load i64, ptr %l68
  store i64 %t99, ptr %l12
  store i64 1, ptr %l13
  %t100 = load i64, ptr %l12
  store i64 %t100, ptr %l69
  %t101 = load i64, ptr %l11
  store i64 %t101, ptr %l70
  %t102 = load i64, ptr %l69
  %t103 = load i64, ptr %l70
  %t104 = icmp sgt i64 %t102, %t103
  store i1 %t104, ptr %l71
  %t105 = load i1, ptr %l71
  br i1 %t105, label %bb23, label %bb24
bb23:
  %t106 = load i64, ptr %l13
  store i64 %t106, ptr %l73
  %t107 = load i64, ptr %l73
  %t108 = icmp sgt i64 %t107, 0
  store i1 %t108, ptr %l74
  %t109 = load i1, ptr %l74
  br i1 %t109, label %bb25, label %bb26
bb24:
  store i64 0, ptr %l72
  br label %bb28
bb25:
  %t110 = load i64, ptr %l12
  store i64 %t110, ptr %l76
  %t111 = load i64, ptr %l11
  store i64 %t111, ptr %l77
  %t112 = load i64, ptr %l76
  %t113 = load i64, ptr %l77
  %t114 = sub i64 %t112, %t113
  store i64 %t114, ptr %l78
  %t115 = load i64, ptr %l13
  store i64 %t115, ptr %l79
  %t116 = load i64, ptr %l78
  %t117 = load i64, ptr %l79
  %t118 = add i64 %t116, %t117
  store i64 %t118, ptr %l80
  %t119 = load i64, ptr %l80
  %t120 = sub i64 %t119, 1
  store i64 %t120, ptr %l81
  %t121 = load i64, ptr %l13
  store i64 %t121, ptr %l82
  %t122 = load i64, ptr %l81
  %t123 = load i64, ptr %l82
  %t124 = sdiv i64 %t122, %t123
  store i64 %t124, ptr %l83
  %t125 = load i64, ptr %l83
  store i64 %t125, ptr %l75
  br label %bb27
bb26:
  store i64 0, ptr %l75
  br label %bb27
bb27:
  %t126 = load i64, ptr %l75
  store i64 %t126, ptr %l72
  br label %bb28
bb28:
  %t127 = load i64, ptr %l72
  store i64 %t127, ptr %l14
  store i64 0, ptr %l15
  br label %bb29
bb29:
  store %olang.scope zeroinitializer, ptr %s5
  %t128 = load i64, ptr %l15
  store i64 %t128, ptr %l84
  %t129 = load i64, ptr %l14
  store i64 %t129, ptr %l85
  %t130 = load i64, ptr %l84
  %t131 = load i64, ptr %l85
  %t132 = icmp slt i64 %t130, %t131
  store i1 %t132, ptr %l86
  %t133 = load i1, ptr %l86
  %t134 = xor i1 %t133, true
  store i1 %t134, ptr %l87
  %t135 = load i1, ptr %l87
  br i1 %t135, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s5)
  br label %bb43
bb31:
  br label %bb32
bb32:
  %t136 = load i64, ptr %l11
  store i64 %t136, ptr %l88
  %t137 = load i64, ptr %l15
  store i64 %t137, ptr %l89
  %t138 = load i64, ptr %l13
  store i64 %t138, ptr %l90
  %t139 = load i64, ptr %l89
  %t140 = load i64, ptr %l90
  %t141 = mul i64 %t139, %t140
  store i64 %t141, ptr %l91
  %t142 = load i64, ptr %l88
  %t143 = load i64, ptr %l91
  %t144 = add i64 %t142, %t143
  store i64 %t144, ptr %l92
  %t145 = load i64, ptr %l92
  store i64 %t145, ptr %l16
  %t146 = load ptr, ptr %l4
  store ptr %t146, ptr %l93
  %t147 = load ptr, ptr %l93
  %t148 = getelementptr %"compiler/load:Module", ptr %t147, i32 0, i32 14
  store ptr %t148, ptr %l94
  %t149 = load i64, ptr %l16
  store i64 %t149, ptr %l95
  %t150 = load ptr, ptr %l94
  %t151 = load i64, ptr %l95
  %t152 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t150, i64 %t151)
  store i64 %t152, ptr %l96
  br label %bb33
bb33:
  %t153 = load i64, ptr @G_2ecompiler_2fload_2ePending
  store i64 %t153, ptr %l97
  %t154 = load i64, ptr %l96
  %t155 = load i64, ptr %l97
  %t156 = icmp eq i64 %t154, %t155
  store i1 %t156, ptr %l98
  %t157 = load i1, ptr %l98
  br i1 %t157, label %bb34, label %bb35
bb34:
  %t158 = load ptr, ptr %l4
  store ptr %t158, ptr %l100
  %t159 = load ptr, ptr %l100
  %t160 = getelementptr %"compiler/load:Module", ptr %t159, i32 0, i32 13
  store ptr %t160, ptr %l101
  %t161 = load i64, ptr %l16
  store i64 %t161, ptr %l102
  %t162 = load ptr, ptr %l101
  %t163 = load i64, ptr %l102
  %t164 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t162, i64 %t163)
  store i64 %t164, ptr %l103
  br label %bb36
bb35:
  store i1 false, ptr %l99
  br label %bb37
bb36:
  %t165 = load i64, ptr %l103
  %t166 = icmp sge i64 %t165, 0
  store i1 %t166, ptr %l104
  %t167 = load i1, ptr %l104
  store i1 %t167, ptr %l99
  br label %bb37
bb37:
  %t168 = load i1, ptr %l99
  br i1 %t168, label %bb38, label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s6
  %t169 = load ptr, ptr %l4
  store ptr %t169, ptr %l105
  %t170 = load ptr, ptr %l105
  %t171 = getelementptr %"compiler/load:Module", ptr %t170, i32 0, i32 14
  store ptr %t171, ptr %l106
  %t172 = load i64, ptr %l16
  store i64 %t172, ptr %l107
  %t173 = load i64, ptr @G_2ecompiler_2fload_2eNotYet
  store i64 %t173, ptr %l108
  %t174 = load ptr, ptr %l106
  %t175 = load i64, ptr %l107
  %t176 = load i64, ptr %l108
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t174, i64 %t175, i64 %t176)
  br label %bb40
bb39:
  br label %bb41
bb40:
  call void @__olang_scope_close(ptr %s6)
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s5)
  br label %bb42
bb42:
  store %olang.scope zeroinitializer, ptr %s7
  %t177 = load i64, ptr %l15
  store i64 %t177, ptr %l109
  %t178 = load i64, ptr %l109
  %t179 = add i64 %t178, 1
  store i64 %t179, ptr %l110
  %t180 = load i64, ptr %l110
  store i64 %t180, ptr %l15
  call void @__olang_scope_close(ptr %s7)
  br label %bb29
bb43:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  br label %bb44
bb44:
  store %olang.scope zeroinitializer, ptr %s8
  %t181 = load i64, ptr %l9
  store i64 %t181, ptr %l111
  %t182 = load i64, ptr %l111
  %t183 = add i64 %t182, 1
  store i64 %t183, ptr %l112
  %t184 = load i64, ptr %l112
  store i64 %t184, ptr %l9
  call void @__olang_scope_close(ptr %s8)
  br label %bb9
bb45:
  call void @__olang_scope_close(ptr %s1)
  %t185 = load ptr, ptr %l0
  store ptr %t185, ptr %l113
  %t186 = load ptr, ptr %l113
  %t187 = getelementptr %"compiler/load:Loader", ptr %t186, i32 0, i32 5
  store ptr %t187, ptr %l114
  %t188 = load ptr, ptr %l114
  %t189 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v0, ptr %t188)
  store i64 %t189, ptr %l115
  br label %bb46
bb46:
  %t190 = load i64, ptr %l115
  store i64 %t190, ptr %l17
  %t191 = load ptr, ptr %l0
  store ptr %t191, ptr %l116
  %t192 = load i64, ptr %l1
  store i64 %t192, ptr %l117
  %t193 = load ptr, ptr %l116
  %t194 = load i64, ptr %l117
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2eloadImports(ptr %v0, ptr %t193, i64 %t194)
  br label %bb47
bb47:
  %t195 = load ptr, ptr %l0
  store ptr %t195, ptr %l118
  %t196 = load i64, ptr %l1
  store i64 %t196, ptr %l119
  %t197 = load ptr, ptr %l4
  store ptr %t197, ptr %l120
  %t198 = load ptr, ptr %l120
  %t199 = getelementptr %"compiler/load:Module", ptr %t198, i32 0, i32 7
  %t200 = load { i64, ptr }, ptr %t199
  store { i64, ptr } %t200, ptr %l121
  %t201 = load ptr, ptr %l118
  %t202 = load i64, ptr %l119
  %t203 = load { i64, ptr }, ptr %l121
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2egroups(ptr %v0, ptr %v0, ptr %t201, i64 %t202, { i64, ptr } %t203)
  br label %bb48
bb48:
  %t204 = load ptr, ptr %l0
  store ptr %t204, ptr %l122
  %t205 = load ptr, ptr %l122
  %t206 = getelementptr %"compiler/load:Loader", ptr %t205, i32 0, i32 5
  store ptr %t206, ptr %l123
  %t207 = load ptr, ptr %l123
  %t208 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v0, ptr %t207)
  store i64 %t208, ptr %l124
  br label %bb49
bb49:
  %t209 = load i64, ptr %l17
  store i64 %t209, ptr %l125
  %t210 = load i64, ptr %l124
  %t211 = load i64, ptr %l125
  %t212 = icmp sgt i64 %t210, %t211
  store i1 %t212, ptr %l126
  %t213 = load i1, ptr %l126
  br i1 %t213, label %bb50, label %bb51
bb50:
  store %olang.scope zeroinitializer, ptr %s9
  %t214 = load ptr, ptr %l0
  store ptr %t214, ptr %l127
  %t215 = load ptr, ptr %l127
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2echeckReach(ptr %v0, ptr %t215)
  br label %bb52
bb51:
  br label %bb53
bb52:
  call void @__olang_scope_close(ptr %s9)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eLoad(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i32
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca i1
  %l14 = alloca i1
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca ptr
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i32
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l32 = alloca ptr
  %l33 = alloca { i64, ptr }
  %l34 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca { i64, [3 x i64] }
  %l38 = alloca %"compiler/msgs:Msg"
  %l39 = alloca i64
  %l40 = alloca ptr
  %l41 = alloca ptr
  %l42 = alloca { i64, ptr }
  %l43 = alloca ptr
  %l44 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l47 = alloca i64
  %l48 = alloca ptr
  %l49 = alloca ptr
  %l50 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %s2 = alloca %olang.builder
  %s2room = alloca [64 x i8], align 8
  %s3 = alloca %olang.builder
  %s3room = alloca [64 x i8], align 8
  %s4 = alloca %olang.scope
  %rv = alloca i64
  %t116 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l4
  %t2 = load ptr, ptr %l4
  %t3 = getelementptr %"compiler/load:Loader", ptr %t2, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3
  store { i64, ptr } %t4, ptr %l5
  %t5 = load { i64, ptr }, ptr %l5
  %t6 = call { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v0, ptr %s0, { i64, ptr } %t5)
  %t7 = extractvalue { i32, { i64, ptr } } %t6, 1
  %t8 = extractvalue { i32, { i64, ptr } } %t6, 0
  store i32 %t8, ptr %l7
  %t9 = icmp ne i32 %t8, 0
  br i1 %t9, label %bb2, label %ok.10
ok.10:
  store { i64, ptr } %t7, ptr %l6
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l6
  store { i64, ptr } %t11, ptr %l3
  br label %bb4
bb2:
  br label %bb3
bb3:
  store { i64, ptr } { i64 0, ptr @.d28 }, ptr %l8
  %t12 = load { i64, ptr }, ptr %l8
  store { i64, ptr } %t12, ptr %l9
  %t13 = load { i64, ptr }, ptr %l9
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l10
  %t20 = load { i64, ptr }, ptr %l10
  store { i64, ptr } %t20, ptr %l3
  br label %bb4
bb4:
  %t21 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t21, ptr %l2
  %t22 = load ptr, ptr %l0
  store ptr %t22, ptr %l11
  %t23 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t23, ptr %l12
  %t24 = load { i64, ptr }, ptr %l12
  %t25 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t24, { i64, ptr } { i64 0, ptr @.d29 })
  store i1 %t25, ptr %l13
  br label %bb5
bb5:
  %t26 = load i1, ptr %l13
  %t27 = xor i1 %t26, true
  store i1 %t27, ptr %l14
  %t28 = load i1, ptr %l14
  br i1 %t28, label %bb6, label %bb7
bb6:
  %t29 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t29, ptr %l16
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t30 = load { i64, ptr }, ptr %l16
  %t31 = extractvalue { i64, ptr } %t30, 1
  %t32 = extractvalue { i64, ptr } %t30, 0
  call void @__olang_sb_put(ptr %s1, ptr %t31, i64 %t32)
  %t33 = load ptr, ptr %s1
  %t34 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t35 = load i64, ptr %t34
  %t36 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t35)
  call void @llvm.memcpy.p0.p0.i64(ptr %t36, ptr %t33, i64 %t35, i1 false)
  %t37 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  store { i64, ptr } %t38, ptr %l17
  call void @__olang_sb_done(ptr %s1)
  %t39 = load { i64, ptr }, ptr %l17
  %t40 = extractvalue { i64, ptr } %t39, 0
  %t41 = extractvalue { i64, ptr } %t39, 1
  %t42 = mul i64 %t40, 1
  %t43 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t42)
  call void @llvm.memcpy.p0.p0.i64(ptr %t43, ptr %t41, i64 %t42, i1 false)
  %t44 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  store { i64, ptr } %t45, ptr %l18
  %t46 = load { i64, ptr }, ptr %l18
  store { i64, ptr } %t46, ptr %l15
  br label %bb8
bb7:
  %t47 = load ptr, ptr %l0
  store ptr %t47, ptr %l19
  %t48 = load ptr, ptr %l19
  %t49 = getelementptr %"compiler/load:Loader", ptr %t48, i32 0, i32 0
  %t50 = load { i64, ptr }, ptr %t49
  store { i64, ptr } %t50, ptr %l20
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s2
  store ptr %s2room, ptr %s2
  %t51 = load { i64, ptr }, ptr %l20
  %t52 = extractvalue { i64, ptr } %t51, 1
  %t53 = extractvalue { i64, ptr } %t51, 0
  call void @__olang_sb_put(ptr %s2, ptr %t52, i64 %t53)
  %t54 = load ptr, ptr %s2
  %t55 = getelementptr %olang.builder, ptr %s2, i32 0, i32 1
  %t56 = load i64, ptr %t55
  %t57 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t56)
  call void @llvm.memcpy.p0.p0.i64(ptr %t57, ptr %t54, i64 %t56, i1 false)
  %t58 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t57, 1
  store { i64, ptr } %t59, ptr %l21
  call void @__olang_sb_done(ptr %s2)
  %t60 = load { i64, ptr }, ptr %l21
  %t61 = extractvalue { i64, ptr } %t60, 0
  %t62 = extractvalue { i64, ptr } %t60, 1
  %t63 = mul i64 %t61, 1
  %t64 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t63)
  call void @llvm.memcpy.p0.p0.i64(ptr %t64, ptr %t62, i64 %t63, i1 false)
  %t65 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t64, 1
  store { i64, ptr } %t66, ptr %l22
  %t67 = load { i64, ptr }, ptr %l22
  store { i64, ptr } %t67, ptr %l15
  br label %bb8
bb8:
  %t68 = load { i64, ptr }, ptr %l15
  %t69 = load ptr, ptr %l11
  %t70 = getelementptr %"compiler/load:Loader", ptr %t69, i32 0, i32 8
  store { i64, ptr } %t68, ptr %t70
  %t71 = load ptr, ptr %l0
  store ptr %t71, ptr %l23
  %t72 = call { i32, { i64, ptr } } @std_2fos_2eCwd(ptr %s0)
  %t73 = extractvalue { i32, { i64, ptr } } %t72, 1
  %t74 = extractvalue { i32, { i64, ptr } } %t72, 0
  store i32 %t74, ptr %l26
  %t75 = icmp ne i32 %t74, 0
  br i1 %t75, label %bb10, label %ok.76
ok.76:
  store { i64, ptr } %t73, ptr %l25
  br label %bb9
bb9:
  %t77 = load { i64, ptr }, ptr %l25
  store { i64, ptr } %t77, ptr %l24
  br label %bb12
bb10:
  br label %bb11
bb11:
  store { i64, ptr } { i64 1, ptr @.d30 }, ptr %l27
  %t78 = load { i64, ptr }, ptr %l27
  store { i64, ptr } %t78, ptr %l28
  %t79 = load { i64, ptr }, ptr %l28
  %t80 = extractvalue { i64, ptr } %t79, 0
  %t81 = extractvalue { i64, ptr } %t79, 1
  %t82 = mul i64 %t80, 1
  %t83 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t82)
  call void @llvm.memcpy.p0.p0.i64(ptr %t83, ptr %t81, i64 %t82, i1 false)
  %t84 = insertvalue { i64, ptr } undef, i64 %t80, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t83, 1
  store { i64, ptr } %t85, ptr %l29
  %t86 = load { i64, ptr }, ptr %l29
  store { i64, ptr } %t86, ptr %l24
  br label %bb12
bb12:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s3
  store ptr %s3room, ptr %s3
  %t87 = load { i64, ptr }, ptr %l24
  %t88 = extractvalue { i64, ptr } %t87, 1
  %t89 = extractvalue { i64, ptr } %t87, 0
  call void @__olang_sb_put(ptr %s3, ptr %t88, i64 %t89)
  %t90 = load ptr, ptr %s3
  %t91 = getelementptr %olang.builder, ptr %s3, i32 0, i32 1
  %t92 = load i64, ptr %t91
  %t93 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t92)
  call void @llvm.memcpy.p0.p0.i64(ptr %t93, ptr %t90, i64 %t92, i1 false)
  %t94 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t93, 1
  store { i64, ptr } %t95, ptr %l30
  call void @__olang_sb_done(ptr %s3)
  %t96 = load { i64, ptr }, ptr %l30
  %t97 = extractvalue { i64, ptr } %t96, 0
  %t98 = extractvalue { i64, ptr } %t96, 1
  %t99 = mul i64 %t97, 1
  %t100 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t99)
  call void @llvm.memcpy.p0.p0.i64(ptr %t100, ptr %t98, i64 %t99, i1 false)
  %t101 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t100, 1
  store { i64, ptr } %t102, ptr %l31
  %t103 = load { i64, ptr }, ptr %l31
  %t104 = load ptr, ptr %l23
  %t105 = getelementptr %"compiler/load:Loader", ptr %t104, i32 0, i32 9
  store { i64, ptr } %t103, ptr %t105
  %t106 = load ptr, ptr %l0
  store ptr %t106, ptr %l32
  %t107 = load ptr, ptr %l32
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2eLoadPrelude(ptr %v0, ptr %t107)
  br label %bb13
bb13:
  %t108 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t108, ptr %l33
  %t109 = load { i64, ptr }, ptr %l33
  %t110 = call i1 @std_2fos_2eIsDir(ptr %v1, { i64, ptr } %t109)
  store i1 %t110, ptr %l34
  br label %bb14
bb14:
  %t111 = load i1, ptr %l34
  br i1 %t111, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s4
  %t112 = load ptr, ptr %l0
  store ptr %t112, ptr %l35
  %t113 = load ptr, ptr %l35
  %t114 = getelementptr %"compiler/load:Loader", ptr %t113, i32 0, i32 4
  %t115 = load ptr, ptr %t114
  store ptr %t115, ptr %l36
  store { i64, [3 x i64] } zeroinitializer, ptr %t116
  %t117 = getelementptr { i64, [3 x i64] }, ptr %t116, i32 0, i32 0
  store i64 0, ptr %t117
  %t118 = load { i64, [3 x i64] }, ptr %t116
  store { i64, [3 x i64] } %t118, ptr %l37
  %t119 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eIsDirectory(ptr %s4)
  store %"compiler/msgs:Msg" %t119, ptr %l38
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t120 = load ptr, ptr %l36
  %t121 = load { i64, [3 x i64] }, ptr %l37
  %t122 = load %"compiler/msgs:Msg", ptr %l38
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v0, ptr %s4, ptr %t120, { i64, [3 x i64] } %t121, %"compiler/msgs:Msg" %t122)
  br label %bb18
bb18:
  store i64 -1, ptr %l39
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t123 = load i64, ptr %l39
  store i64 %t123, ptr %rv
  br label %ret
bb19:
  %t124 = load ptr, ptr %l0
  store ptr %t124, ptr %l40
  %t125 = load ptr, ptr %l0
  store ptr %t125, ptr %l41
  %t126 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t126, ptr %l42
  %t127 = load ptr, ptr %l0
  store ptr %t127, ptr %l43
  %t128 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t128, ptr %l44
  %t129 = load ptr, ptr %l43
  %t130 = load { i64, ptr }, ptr %l44
  %t131 = call { i64, ptr } @compiler_2fload_2ecompiler_2fload_3aLoader_2erootIdentity(ptr %v0, ptr %v1, ptr %s0, ptr %t129, { i64, ptr } %t130)
  store { i64, ptr } %t131, ptr %l45
  br label %bb20
bb20:
  %t132 = load { i64, ptr }, ptr %l45
  %t133 = extractvalue { i64, ptr } %t132, 0
  %t134 = extractvalue { i64, ptr } %t132, 1
  %t135 = mul i64 %t133, 1
  %t136 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t135)
  call void @llvm.memcpy.p0.p0.i64(ptr %t136, ptr %t134, i64 %t135, i1 false)
  %t137 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %t136, 1
  store { i64, ptr } %t138, ptr %l46
  %t139 = load ptr, ptr %l41
  %t140 = load { i64, ptr }, ptr %l42
  %t141 = load { i64, ptr }, ptr %l46
  %t142 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eload(ptr %v0, ptr %v1, ptr %s0, ptr %t139, { i64, ptr } %t140, { i64, ptr } %t141, i1 false)
  store i64 %t142, ptr %l47
  br label %bb21
bb21:
  %t143 = load i64, ptr %l47
  %t144 = load ptr, ptr %l40
  %t145 = getelementptr %"compiler/load:Loader", ptr %t144, i32 0, i32 7
  store i64 %t143, ptr %t145
  %t146 = load ptr, ptr %l0
  store ptr %t146, ptr %l48
  %t147 = load ptr, ptr %l48
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2echeckReach(ptr %v0, ptr %t147)
  br label %bb22
bb22:
  %t148 = load ptr, ptr %l0
  store ptr %t148, ptr %l49
  %t149 = load ptr, ptr %l49
  %t150 = getelementptr %"compiler/load:Loader", ptr %t149, i32 0, i32 7
  %t151 = load i64, ptr %t150
  store i64 %t151, ptr %l50
  call void @__olang_scope_close(ptr %s0)
  %t152 = load i64, ptr %l50
  store i64 %t152, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fload_2ecompiler_2fload_3aLoader_2eLoadPrelude(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca %"compiler/scan:Tokens"
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca { i64, ptr }
  %l29 = alloca ptr
  %l30 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca i32
  %l36 = alloca i32
  %l37 = alloca i1
  %l38 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l39 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i1
  %l45 = alloca i1
  %l46 = alloca { i64, ptr }
  %l47 = alloca i64
  %l48 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l53 = alloca i1
  %l54 = alloca ptr
  %l55 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca ptr
  %l61 = alloca { i64, ptr }
  %l62 = alloca ptr
  %l63 = alloca i64
  %l64 = alloca { i64, ptr }
  %l65 = alloca i32
  %l66 = alloca i32
  %l67 = alloca i1
  %l68 = alloca { i64, ptr }
  %l69 = alloca i64
  %l70 = alloca i64
  %l71 = alloca i64
  %l72 = alloca i1
  %l73 = alloca i1
  %l74 = alloca { i64, ptr }
  %l75 = alloca i64
  %l76 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l80 = alloca i32
  %l81 = alloca i32
  %l82 = alloca i1
  %l83 = alloca { i64, ptr }
  %l84 = alloca %"compiler/scan:Tokens"
  %l85 = alloca { i64, ptr }
  %l86 = alloca ptr
  %l87 = alloca ptr
  %l88 = alloca { i64, ptr }
  %l89 = alloca ptr
  %l90 = alloca i64
  %l91 = alloca { i64, ptr }
  %l92 = alloca i32
  %l93 = alloca i32
  %l94 = alloca i1
  %l95 = alloca { i64, ptr }
  %l96 = alloca i64
  %l97 = alloca i64
  %l98 = alloca i64
  %l99 = alloca i1
  %l100 = alloca i1
  %l101 = alloca { i64, ptr }
  %l102 = alloca i64
  %l103 = alloca { i64, ptr }
  %l104 = alloca ptr
  %l105 = alloca ptr
  %l106 = alloca { i64, ptr }
  %l107 = alloca { i64, ptr }
  %l108 = alloca { i64, ptr }
  %l109 = alloca i64
  %l110 = alloca i64
  %l111 = alloca i64
  %l112 = alloca i64
  %l113 = alloca i64
  %l114 = alloca i64
  %l115 = alloca i64
  %l116 = alloca i64
  %l117 = alloca i64
  %l118 = alloca i64
  %l119 = alloca ptr
  %l120 = alloca { i64, ptr }
  %l121 = alloca ptr
  %l122 = alloca i64
  %l123 = alloca { i64, ptr }
  %l124 = alloca i32
  %l125 = alloca i32
  %l126 = alloca i1
  %l127 = alloca { i64, ptr }
  %l128 = alloca i64
  %l129 = alloca i64
  %l130 = alloca i64
  %l131 = alloca i1
  %l132 = alloca i1
  %l133 = alloca { i64, ptr }
  %l134 = alloca i64
  %l135 = alloca { i64, ptr }
  %l136 = alloca ptr
  %l137 = alloca { i64, ptr }
  %l138 = alloca ptr
  %l139 = alloca { i64, ptr }
  %l140 = alloca { i64, ptr }
  %l141 = alloca { i64, ptr }
  %l142 = alloca i64
  %l143 = alloca i64
  %l144 = alloca i64
  %l145 = alloca i64
  %l146 = alloca i64
  %l147 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.builder
  %s5room = alloca [64 x i8], align 8
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.builder
  %s14room = alloca [64 x i8], align 8
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l29
  %t2 = load ptr, ptr %l29
  %t3 = getelementptr %"compiler/load:Loader", ptr %t2, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3
  store { i64, ptr } %t4, ptr %l30
  %t5 = load { i64, ptr }, ptr %l30
  %t6 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t5, { i64, ptr } { i64 7, ptr @.d31 }, { i64, ptr } { i64 0, ptr @.d4 }, { i64, ptr } { i64 0, ptr @.d5 }, { i64, ptr } { i64 0, ptr @.d6 }, { i64, ptr } { i64 0, ptr @.d7 })
  store { i64, ptr } %t6, ptr %l31
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l31
  store { i64, ptr } %t7, ptr %l1
  %t8 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t8, ptr %l33
  %t9 = load { i64, ptr }, ptr %l33
  %t10 = call { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %s0, ptr %s0, { i64, ptr } %t9)
  %t11 = extractvalue { i32, { i64, ptr } } %t10, 1
  %t12 = extractvalue { i32, { i64, ptr } } %t10, 0
  store i32 %t12, ptr %l35
  %t13 = icmp ne i32 %t12, 0
  br i1 %t13, label %bb3, label %ok.14
ok.14:
  store { i64, ptr } %t11, ptr %l34
  br label %bb2
bb2:
  %t15 = load { i64, ptr }, ptr %l34
  store { i64, ptr } %t15, ptr %l32
  br label %bb7
bb3:
  %t16 = load i32, ptr %l35
  %t17 = ashr i32 %t16, 16
  store i32 %t17, ptr %l36
  %t18 = load i32, ptr %l36
  %t19 = icmp eq i32 %t18, 1
  store i1 %t19, ptr %l37
  %t20 = load i1, ptr %l37
  br i1 %t20, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @.c32)
  unreachable
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb7:
  %t21 = load { i64, ptr }, ptr %l32
  store { i64, ptr } %t21, ptr %l2
  %t22 = load ptr, ptr @__olang_prog_scope
  %t23 = call %"std/prelude/list:List<std/prelude/text:String&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t22)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t23, ptr %l38
  br label %bb8
bb8:
  %t24 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l38
  store %"std/prelude/list:List<std/prelude/text:String&>" %t24, ptr %l3
  store %olang.scope zeroinitializer, ptr %s2
  %t25 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t25, ptr %l39
  %t26 = load { i64, ptr }, ptr %l39
  store { i64, ptr } %t26, ptr %l4
  store i64 0, ptr %l5
  %t27 = load { i64, ptr }, ptr %l4
  store { i64, ptr } %t27, ptr %l40
  %t28 = load { i64, ptr }, ptr %l40
  %t29 = extractvalue { i64, ptr } %t28, 0
  store i64 %t29, ptr %l41
  %t30 = load i64, ptr %l41
  store i64 %t30, ptr %l6
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t31 = load i64, ptr %l5
  store i64 %t31, ptr %l42
  %t32 = load i64, ptr %l6
  store i64 %t32, ptr %l43
  %t33 = load i64, ptr %l42
  %t34 = load i64, ptr %l43
  %t35 = icmp slt i64 %t33, %t34
  store i1 %t35, ptr %l44
  %t36 = load i1, ptr %l44
  %t37 = xor i1 %t36, true
  store i1 %t37, ptr %l45
  %t38 = load i1, ptr %l45
  br i1 %t38, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb11:
  br label %bb12
bb12:
  %t39 = load { i64, ptr }, ptr %l4
  store { i64, ptr } %t39, ptr %l46
  %t40 = load i64, ptr %l5
  store i64 %t40, ptr %l47
  %t41 = load i64, ptr %l47
  %t42 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t43 = load ptr, ptr %t42
  %t44 = getelementptr { i64, ptr }, ptr %t43, i64 %t41
  %t45 = load { i64, ptr }, ptr %t44
  store { i64, ptr } %t45, ptr %l48
  %t46 = load { i64, ptr }, ptr %l48
  store { i64, ptr } %t46, ptr %l7
  %t47 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t47, ptr %l49
  %t48 = load { i64, ptr }, ptr %l7
  store { i64, ptr } %t48, ptr %l50
  %t49 = load { i64, ptr }, ptr %l49
  %t50 = load { i64, ptr }, ptr %l50
  %t51 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %s0, ptr %s3, ptr %s3, ptr %s3, ptr %s3, ptr %s3, { i64, ptr } %t49, { i64, ptr } %t50, { i64, ptr } { i64 0, ptr @.d33 }, { i64, ptr } { i64 0, ptr @.d34 }, { i64, ptr } { i64 0, ptr @.d35 }, { i64, ptr } { i64 0, ptr @.d36 })
  store { i64, ptr } %t51, ptr %l51
  br label %bb13
bb13:
  %t52 = load { i64, ptr }, ptr %l51
  store { i64, ptr } %t52, ptr %l8
  %t53 = load { i64, ptr }, ptr %l7
  store { i64, ptr } %t53, ptr %l52
  %t54 = load { i64, ptr }, ptr %l52
  %t55 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s0, ptr %s3, { i64, ptr } %t54, { i64, ptr } { i64 6, ptr @.d37 })
  store i1 %t55, ptr %l53
  br label %bb14
bb14:
  %t56 = load i1, ptr %l53
  br i1 %t56, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s4
  store ptr %l3, ptr %l54
  %t57 = load { i64, ptr }, ptr %l8
  store { i64, ptr } %t57, ptr %l55
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s5
  store ptr %s5room, ptr %s5
  %t58 = load { i64, ptr }, ptr %l55
  %t59 = extractvalue { i64, ptr } %t58, 1
  %t60 = extractvalue { i64, ptr } %t58, 0
  call void @__olang_sb_put(ptr %s5, ptr %t59, i64 %t60)
  %t61 = load ptr, ptr %s5
  %t62 = getelementptr %olang.builder, ptr %s5, i32 0, i32 1
  %t63 = load i64, ptr %t62
  %t64 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t63)
  call void @llvm.memcpy.p0.p0.i64(ptr %t64, ptr %t61, i64 %t63, i1 false)
  %t65 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t64, 1
  store { i64, ptr } %t66, ptr %l56
  call void @__olang_sb_done(ptr %s5)
  %t67 = load { i64, ptr }, ptr %l56
  %t68 = extractvalue { i64, ptr } %t67, 0
  %t69 = extractvalue { i64, ptr } %t67, 1
  %t70 = mul i64 %t68, 1
  %t71 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t70)
  call void @llvm.memcpy.p0.p0.i64(ptr %t71, ptr %t69, i64 %t70, i1 false)
  %t72 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t71, 1
  store { i64, ptr } %t73, ptr %l57
  %t74 = load ptr, ptr %l54
  %t75 = load { i64, ptr }, ptr %l57
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %t74, { i64, ptr } %t75)
  br label %bb17
bb16:
  br label %bb18
bb17:
  call void @__olang_scope_close(ptr %s4)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb19:
  store %olang.scope zeroinitializer, ptr %s6
  %t76 = load i64, ptr %l5
  store i64 %t76, ptr %l58
  %t77 = load i64, ptr %l58
  %t78 = add i64 %t77, 1
  store i64 %t78, ptr %l59
  %t79 = load i64, ptr %l59
  store i64 %t79, ptr %l5
  call void @__olang_scope_close(ptr %s6)
  br label %bb9
bb20:
  call void @__olang_scope_close(ptr %s2)
  store %olang.scope zeroinitializer, ptr %s7
  store ptr %l3, ptr %l60
  %t80 = load ptr, ptr %l60
  store ptr %t80, ptr %l9
  store i64 0, ptr %l10
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s8
  %t81 = load ptr, ptr %l9
  store ptr %t81, ptr %l62
  %t82 = load i64, ptr %l10
  store i64 %t82, ptr %l63
  %t83 = load ptr, ptr %l62
  %t84 = load i64, ptr %l63
  %t85 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %s0, ptr %t83, i64 %t84)
  %t86 = extractvalue { i32, { i64, ptr } } %t85, 1
  %t87 = extractvalue { i32, { i64, ptr } } %t85, 0
  store i32 %t87, ptr %l65
  %t88 = icmp ne i32 %t87, 0
  br i1 %t88, label %bb23, label %ok.89
ok.89:
  store { i64, ptr } %t86, ptr %l64
  br label %bb22
bb22:
  %t90 = load { i64, ptr }, ptr %l64
  store { i64, ptr } %t90, ptr %l61
  br label %bb27
bb23:
  %t91 = load i32, ptr %l65
  %t92 = ashr i32 %t91, 16
  store i32 %t92, ptr %l66
  %t93 = load i32, ptr %l66
  %t94 = icmp eq i32 %t93, 1
  store i1 %t94, ptr %l67
  %t95 = load i1, ptr %l67
  br i1 %t95, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @.c38)
  unreachable
bb26:
  call void @__olang_scope_close(ptr %s8)
  br label %bb59
bb27:
  %t96 = load { i64, ptr }, ptr %l61
  store { i64, ptr } %t96, ptr %l11
  %t97 = load { i64, ptr }, ptr %l11
  store { i64, ptr } %t97, ptr %l68
  %t98 = load { i64, ptr }, ptr %l68
  %t99 = extractvalue { i64, ptr } %t98, 0
  store i64 %t99, ptr %l69
  %t100 = load i64, ptr %l69
  store i64 %t100, ptr %l12
  store i64 0, ptr %l13
  br label %bb28
bb28:
  store %olang.scope zeroinitializer, ptr %s9
  %t101 = load i64, ptr %l13
  store i64 %t101, ptr %l70
  %t102 = load i64, ptr %l12
  store i64 %t102, ptr %l71
  %t103 = load i64, ptr %l70
  %t104 = load i64, ptr %l71
  %t105 = icmp slt i64 %t103, %t104
  store i1 %t105, ptr %l72
  %t106 = load i1, ptr %l72
  %t107 = xor i1 %t106, true
  store i1 %t107, ptr %l73
  %t108 = load i1, ptr %l73
  br i1 %t108, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s9)
  br label %bb57
bb30:
  br label %bb31
bb31:
  %t109 = load { i64, ptr }, ptr %l11
  store { i64, ptr } %t109, ptr %l74
  %t110 = load i64, ptr %l13
  store i64 %t110, ptr %l75
  %t111 = load i64, ptr %l75
  %t112 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t113 = load ptr, ptr %t112
  %t114 = getelementptr { i64, ptr }, ptr %t113, i64 %t111
  %t115 = load { i64, ptr }, ptr %t114
  store { i64, ptr } %t115, ptr %l76
  %t116 = load { i64, ptr }, ptr %l76
  store { i64, ptr } %t116, ptr %l14
  %t117 = load { i64, ptr }, ptr %l14
  store { i64, ptr } %t117, ptr %l78
  %t118 = load { i64, ptr }, ptr %l78
  %t119 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s9, { i64, ptr } %t118)
  %t120 = extractvalue { i32, { i64, ptr } } %t119, 1
  %t121 = extractvalue { i32, { i64, ptr } } %t119, 0
  store i32 %t121, ptr %l80
  %t122 = icmp ne i32 %t121, 0
  br i1 %t122, label %bb33, label %ok.123
ok.123:
  store { i64, ptr } %t120, ptr %l79
  br label %bb32
bb32:
  %t124 = load { i64, ptr }, ptr %l79
  store { i64, ptr } %t124, ptr %l77
  br label %bb37
bb33:
  %t125 = load i32, ptr %l80
  %t126 = ashr i32 %t125, 16
  store i32 %t126, ptr %l81
  %t127 = load i32, ptr %l81
  %t128 = icmp eq i32 %t127, 1
  store i1 %t128, ptr %l82
  %t129 = load i1, ptr %l82
  br i1 %t129, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  call void @__olang_check_failed(ptr @.c39)
  unreachable
bb36:
  store %olang.scope zeroinitializer, ptr %s10
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s9)
  br label %bb56
bb37:
  %t130 = load { i64, ptr }, ptr %l77
  store { i64, ptr } %t130, ptr %l15
  %t131 = load { i64, ptr }, ptr %l15
  store { i64, ptr } %t131, ptr %l83
  %t132 = load { i64, ptr }, ptr %l83
  %t133 = call %"compiler/scan:Tokens" @compiler_2fscan_2eScan(ptr %s9, ptr %s9, { i64, ptr } %t132)
  store %"compiler/scan:Tokens" %t133, ptr %l84
  br label %bb38
bb38:
  %t134 = load %"compiler/scan:Tokens", ptr %l84
  store %"compiler/scan:Tokens" %t134, ptr %l16
  store %olang.scope zeroinitializer, ptr %s11
  %t135 = load { i64, ptr }, ptr %l15
  store { i64, ptr } %t135, ptr %l85
  store ptr %l16, ptr %l86
  %t136 = load { i64, ptr }, ptr %l85
  %t137 = load ptr, ptr %l86
  %t138 = call ptr @compiler_2fload_2etypeNames(ptr %s9, ptr %s9, { i64, ptr } %t136, ptr %t137)
  store ptr %t138, ptr %l87
  br label %bb39
bb39:
  %t139 = load ptr, ptr %l87
  store ptr %t139, ptr %l17
  store i64 0, ptr %l18
  br label %bb40
bb40:
  store %olang.scope zeroinitializer, ptr %s12
  %t140 = load ptr, ptr %l17
  store ptr %t140, ptr %l89
  %t141 = load i64, ptr %l18
  store i64 %t141, ptr %l90
  %t142 = load ptr, ptr %l89
  %t143 = load i64, ptr %l90
  %t144 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %s9, ptr %t142, i64 %t143)
  %t145 = extractvalue { i32, { i64, ptr } } %t144, 1
  %t146 = extractvalue { i32, { i64, ptr } } %t144, 0
  store i32 %t146, ptr %l92
  %t147 = icmp ne i32 %t146, 0
  br i1 %t147, label %bb42, label %ok.148
ok.148:
  store { i64, ptr } %t145, ptr %l91
  br label %bb41
bb41:
  %t149 = load { i64, ptr }, ptr %l91
  store { i64, ptr } %t149, ptr %l88
  br label %bb46
bb42:
  %t150 = load i32, ptr %l92
  %t151 = ashr i32 %t150, 16
  store i32 %t151, ptr %l93
  %t152 = load i32, ptr %l93
  %t153 = icmp eq i32 %t152, 1
  store i1 %t153, ptr %l94
  %t154 = load i1, ptr %l94
  br i1 %t154, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  call void @__olang_check_failed(ptr @.c40)
  unreachable
bb45:
  call void @__olang_scope_close(ptr %s12)
  br label %bb55
bb46:
  %t155 = load { i64, ptr }, ptr %l88
  store { i64, ptr } %t155, ptr %l19
  %t156 = load { i64, ptr }, ptr %l19
  store { i64, ptr } %t156, ptr %l95
  %t157 = load { i64, ptr }, ptr %l95
  %t158 = extractvalue { i64, ptr } %t157, 0
  store i64 %t158, ptr %l96
  %t159 = load i64, ptr %l96
  store i64 %t159, ptr %l20
  store i64 0, ptr %l21
  br label %bb47
bb47:
  store %olang.scope zeroinitializer, ptr %s13
  %t160 = load i64, ptr %l21
  store i64 %t160, ptr %l97
  %t161 = load i64, ptr %l20
  store i64 %t161, ptr %l98
  %t162 = load i64, ptr %l97
  %t163 = load i64, ptr %l98
  %t164 = icmp slt i64 %t162, %t163
  store i1 %t164, ptr %l99
  %t165 = load i1, ptr %l99
  %t166 = xor i1 %t165, true
  store i1 %t166, ptr %l100
  %t167 = load i1, ptr %l100
  br i1 %t167, label %bb48, label %bb49
bb48:
  call void @__olang_scope_close(ptr %s13)
  br label %bb53
bb49:
  br label %bb50
bb50:
  %t168 = load { i64, ptr }, ptr %l19
  store { i64, ptr } %t168, ptr %l101
  %t169 = load i64, ptr %l21
  store i64 %t169, ptr %l102
  %t170 = load i64, ptr %l102
  %t171 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t172 = load ptr, ptr %t171
  %t173 = getelementptr { i64, ptr }, ptr %t172, i64 %t170
  %t174 = load { i64, ptr }, ptr %t173
  store { i64, ptr } %t174, ptr %l103
  %t175 = load { i64, ptr }, ptr %l103
  store { i64, ptr } %t175, ptr %l22
  %t176 = load ptr, ptr %l0
  store ptr %t176, ptr %l104
  %t177 = load ptr, ptr %l104
  %t178 = getelementptr %"compiler/load:Loader", ptr %t177, i32 0, i32 6
  store ptr %t178, ptr %l105
  %t179 = load { i64, ptr }, ptr %l22
  store { i64, ptr } %t179, ptr %l106
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s14
  store ptr %s14room, ptr %s14
  %t180 = load { i64, ptr }, ptr %l106
  %t181 = extractvalue { i64, ptr } %t180, 1
  %t182 = extractvalue { i64, ptr } %t180, 0
  call void @__olang_sb_put(ptr %s14, ptr %t181, i64 %t182)
  %t183 = load ptr, ptr %s14
  %t184 = getelementptr %olang.builder, ptr %s14, i32 0, i32 1
  %t185 = load i64, ptr %t184
  %t186 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t185)
  call void @llvm.memcpy.p0.p0.i64(ptr %t186, ptr %t183, i64 %t185, i1 false)
  %t187 = insertvalue { i64, ptr } undef, i64 %t185, 0
  %t188 = insertvalue { i64, ptr } %t187, ptr %t186, 1
  store { i64, ptr } %t188, ptr %l107
  call void @__olang_sb_done(ptr %s14)
  %t189 = load { i64, ptr }, ptr %l107
  %t190 = extractvalue { i64, ptr } %t189, 0
  %t191 = extractvalue { i64, ptr } %t189, 1
  %t192 = mul i64 %t190, 1
  %t193 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t192)
  call void @llvm.memcpy.p0.p0.i64(ptr %t193, ptr %t191, i64 %t192, i1 false)
  %t194 = insertvalue { i64, ptr } undef, i64 %t190, 0
  %t195 = insertvalue { i64, ptr } %t194, ptr %t193, 1
  store { i64, ptr } %t195, ptr %l108
  %t196 = load ptr, ptr %l105
  %t197 = load { i64, ptr }, ptr %l108
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v0, ptr %t196, { i64, ptr } %t197)
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s13)
  br label %bb52
bb52:
  store %olang.scope zeroinitializer, ptr %s15
  %t198 = load i64, ptr %l21
  store i64 %t198, ptr %l109
  %t199 = load i64, ptr %l109
  %t200 = add i64 %t199, 1
  store i64 %t200, ptr %l110
  %t201 = load i64, ptr %l110
  store i64 %t201, ptr %l21
  call void @__olang_scope_close(ptr %s15)
  br label %bb47
bb53:
  %t202 = load i64, ptr %l18
  store i64 %t202, ptr %l111
  %t203 = load i64, ptr %l20
  store i64 %t203, ptr %l112
  %t204 = load i64, ptr %l111
  %t205 = load i64, ptr %l112
  %t206 = add i64 %t204, %t205
  store i64 %t206, ptr %l113
  %t207 = load i64, ptr %l113
  store i64 %t207, ptr %l18
  call void @__olang_scope_close(ptr %s12)
  br label %bb54
bb54:
  br label %bb40
bb55:
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s9)
  br label %bb56
bb56:
  store %olang.scope zeroinitializer, ptr %s16
  %t208 = load i64, ptr %l13
  store i64 %t208, ptr %l114
  %t209 = load i64, ptr %l114
  %t210 = add i64 %t209, 1
  store i64 %t210, ptr %l115
  %t211 = load i64, ptr %l115
  store i64 %t211, ptr %l13
  call void @__olang_scope_close(ptr %s16)
  br label %bb28
bb57:
  %t212 = load i64, ptr %l10
  store i64 %t212, ptr %l116
  %t213 = load i64, ptr %l12
  store i64 %t213, ptr %l117
  %t214 = load i64, ptr %l116
  %t215 = load i64, ptr %l117
  %t216 = add i64 %t214, %t215
  store i64 %t216, ptr %l118
  %t217 = load i64, ptr %l118
  store i64 %t217, ptr %l10
  call void @__olang_scope_close(ptr %s8)
  br label %bb58
bb58:
  br label %bb21
bb59:
  call void @__olang_scope_close(ptr %s7)
  store %olang.scope zeroinitializer, ptr %s17
  store ptr %l3, ptr %l119
  %t218 = load ptr, ptr %l119
  store ptr %t218, ptr %l23
  store i64 0, ptr %l24
  br label %bb60
bb60:
  store %olang.scope zeroinitializer, ptr %s18
  %t219 = load ptr, ptr %l23
  store ptr %t219, ptr %l121
  %t220 = load i64, ptr %l24
  store i64 %t220, ptr %l122
  %t221 = load ptr, ptr %l121
  %t222 = load i64, ptr %l122
  %t223 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %s0, ptr %t221, i64 %t222)
  %t224 = extractvalue { i32, { i64, ptr } } %t223, 1
  %t225 = extractvalue { i32, { i64, ptr } } %t223, 0
  store i32 %t225, ptr %l124
  %t226 = icmp ne i32 %t225, 0
  br i1 %t226, label %bb62, label %ok.227
ok.227:
  store { i64, ptr } %t224, ptr %l123
  br label %bb61
bb61:
  %t228 = load { i64, ptr }, ptr %l123
  store { i64, ptr } %t228, ptr %l120
  br label %bb66
bb62:
  %t229 = load i32, ptr %l124
  %t230 = ashr i32 %t229, 16
  store i32 %t230, ptr %l125
  %t231 = load i32, ptr %l125
  %t232 = icmp eq i32 %t231, 1
  store i1 %t232, ptr %l126
  %t233 = load i1, ptr %l126
  br i1 %t233, label %bb63, label %bb64
bb63:
  br label %bb65
bb64:
  call void @__olang_check_failed(ptr @.c41)
  unreachable
bb65:
  call void @__olang_scope_close(ptr %s18)
  br label %bb76
bb66:
  %t234 = load { i64, ptr }, ptr %l120
  store { i64, ptr } %t234, ptr %l25
  %t235 = load { i64, ptr }, ptr %l25
  store { i64, ptr } %t235, ptr %l127
  %t236 = load { i64, ptr }, ptr %l127
  %t237 = extractvalue { i64, ptr } %t236, 0
  store i64 %t237, ptr %l128
  %t238 = load i64, ptr %l128
  store i64 %t238, ptr %l26
  store i64 0, ptr %l27
  br label %bb67
bb67:
  store %olang.scope zeroinitializer, ptr %s19
  %t239 = load i64, ptr %l27
  store i64 %t239, ptr %l129
  %t240 = load i64, ptr %l26
  store i64 %t240, ptr %l130
  %t241 = load i64, ptr %l129
  %t242 = load i64, ptr %l130
  %t243 = icmp slt i64 %t241, %t242
  store i1 %t243, ptr %l131
  %t244 = load i1, ptr %l131
  %t245 = xor i1 %t244, true
  store i1 %t245, ptr %l132
  %t246 = load i1, ptr %l132
  br i1 %t246, label %bb68, label %bb69
bb68:
  call void @__olang_scope_close(ptr %s19)
  br label %bb74
bb69:
  br label %bb70
bb70:
  %t247 = load { i64, ptr }, ptr %l25
  store { i64, ptr } %t247, ptr %l133
  %t248 = load i64, ptr %l27
  store i64 %t248, ptr %l134
  %t249 = load i64, ptr %l134
  %t250 = getelementptr { i64, ptr }, ptr %l133, i32 0, i32 1
  %t251 = load ptr, ptr %t250
  %t252 = getelementptr { i64, ptr }, ptr %t251, i64 %t249
  %t253 = load { i64, ptr }, ptr %t252
  store { i64, ptr } %t253, ptr %l135
  %t254 = load { i64, ptr }, ptr %l135
  store { i64, ptr } %t254, ptr %l28
  %t255 = load ptr, ptr %l0
  store ptr %t255, ptr %l136
  %t256 = load { i64, ptr }, ptr %l28
  store { i64, ptr } %t256, ptr %l137
  %t257 = load ptr, ptr %l0
  store ptr %t257, ptr %l138
  %t258 = load { i64, ptr }, ptr %l28
  store { i64, ptr } %t258, ptr %l139
  %t259 = load ptr, ptr %l138
  %t260 = load { i64, ptr }, ptr %l139
  %t261 = call { i64, ptr } @compiler_2fload_2ecompiler_2fload_3aLoader_2erootIdentity(ptr %v0, ptr %s0, ptr %s19, ptr %t259, { i64, ptr } %t260)
  store { i64, ptr } %t261, ptr %l140
  br label %bb71
bb71:
  %t262 = load { i64, ptr }, ptr %l140
  %t263 = extractvalue { i64, ptr } %t262, 0
  %t264 = extractvalue { i64, ptr } %t262, 1
  %t265 = mul i64 %t263, 1
  %t266 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t265)
  call void @llvm.memcpy.p0.p0.i64(ptr %t266, ptr %t264, i64 %t265, i1 false)
  %t267 = insertvalue { i64, ptr } undef, i64 %t263, 0
  %t268 = insertvalue { i64, ptr } %t267, ptr %t266, 1
  store { i64, ptr } %t268, ptr %l141
  %t269 = load ptr, ptr %l136
  %t270 = load { i64, ptr }, ptr %l137
  %t271 = load { i64, ptr }, ptr %l141
  %t272 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eload(ptr %v0, ptr %s0, ptr %s19, ptr %t269, { i64, ptr } %t270, { i64, ptr } %t271, i1 true)
  store i64 %t272, ptr %l142
  br label %bb72
bb72:
  call void @__olang_scope_close(ptr %s19)
  br label %bb73
bb73:
  store %olang.scope zeroinitializer, ptr %s20
  %t273 = load i64, ptr %l27
  store i64 %t273, ptr %l143
  %t274 = load i64, ptr %l143
  %t275 = add i64 %t274, 1
  store i64 %t275, ptr %l144
  %t276 = load i64, ptr %l144
  store i64 %t276, ptr %l27
  call void @__olang_scope_close(ptr %s20)
  br label %bb67
bb74:
  %t277 = load i64, ptr %l24
  store i64 %t277, ptr %l145
  %t278 = load i64, ptr %l26
  store i64 %t278, ptr %l146
  %t279 = load i64, ptr %l145
  %t280 = load i64, ptr %l146
  %t281 = add i64 %t279, %t280
  store i64 %t281, ptr %l147
  %t282 = load i64, ptr %l147
  store i64 %t282, ptr %l24
  call void @__olang_scope_close(ptr %s18)
  br label %bb75
bb75:
  br label %bb60
bb76:
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/list:List<std/pair:Pair<I64, I32>>" @compiler_2fload_2ecompiler_2fload_3aLoader_2ePendingIfs(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca %"std/prelude/list:List<std/pair:Pair<I64, I32>>"
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i1
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i1
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i1
  %l37 = alloca i1
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca ptr
  %l44 = alloca ptr
  %l45 = alloca i64
  %l46 = alloca ptr
  %l47 = alloca ptr
  %l48 = alloca ptr
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i1
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i1
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca i1
  %l68 = alloca i1
  %l69 = alloca i64
  %l70 = alloca i64
  %l71 = alloca i64
  %l72 = alloca i64
  %l73 = alloca i64
  %l74 = alloca ptr
  %l75 = alloca i64
  %l76 = alloca i64
  %l77 = alloca ptr
  %l78 = alloca ptr
  %l79 = alloca i64
  %l80 = alloca i64
  %l81 = alloca i64
  %l82 = alloca i1
  %l83 = alloca i1
  %l84 = alloca ptr
  %l85 = alloca i64
  %l86 = alloca ptr
  %l87 = alloca ptr
  %l88 = alloca i64
  %l89 = alloca i64
  %l90 = alloca i64
  %l91 = alloca i1
  %l92 = alloca ptr
  %l93 = alloca i64
  %l94 = alloca ptr
  %l95 = alloca ptr
  %l96 = alloca i64
  %l97 = alloca i32
  %l98 = alloca %"std/pair:Pair<I64, I32>"
  %l99 = alloca i64
  %l100 = alloca i64
  %l101 = alloca i64
  %l102 = alloca i64
  %l103 = alloca %"std/prelude/list:List<std/pair:Pair<I64, I32>>"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List<std/pair:Pair<I64, I32>>"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<std/pair:Pair<I64, I32>>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20I32_3e_3e(ptr %t1)
  store %"std/prelude/list:List<std/pair:Pair<I64, I32>>" %t2, ptr %l15
  br label %bb1
bb1:
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t3, ptr %lp1
  %t4 = load %"std/prelude/list:List<std/pair:Pair<I64, I32>>", ptr %l15
  %t5 = load ptr, ptr %lp1
  store %"std/prelude/list:List<std/pair:Pair<I64, I32>>" %t4, ptr %t5
  store %olang.scope zeroinitializer, ptr %s1
  store i64 0, ptr %l2
  %t6 = load ptr, ptr %l0
  store ptr %t6, ptr %l16
  %t7 = load ptr, ptr %l16
  %t8 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 5
  store ptr %t8, ptr %l17
  %t9 = load ptr, ptr %l17
  %t10 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v0, ptr %t9)
  store i64 %t10, ptr %l18
  br label %bb2
bb2:
  %t11 = load i64, ptr %l18
  store i64 %t11, ptr %l3
  store i64 1, ptr %l4
  %t12 = load i64, ptr %l3
  store i64 %t12, ptr %l19
  %t13 = load i64, ptr %l2
  store i64 %t13, ptr %l20
  %t14 = load i64, ptr %l19
  %t15 = load i64, ptr %l20
  %t16 = icmp sgt i64 %t14, %t15
  store i1 %t16, ptr %l21
  %t17 = load i1, ptr %l21
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t18 = load i64, ptr %l4
  store i64 %t18, ptr %l23
  %t19 = load i64, ptr %l23
  %t20 = icmp sgt i64 %t19, 0
  store i1 %t20, ptr %l24
  %t21 = load i1, ptr %l24
  br i1 %t21, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l22
  br label %bb8
bb5:
  %t22 = load i64, ptr %l3
  store i64 %t22, ptr %l26
  %t23 = load i64, ptr %l2
  store i64 %t23, ptr %l27
  %t24 = load i64, ptr %l26
  %t25 = load i64, ptr %l27
  %t26 = sub i64 %t24, %t25
  store i64 %t26, ptr %l28
  %t27 = load i64, ptr %l4
  store i64 %t27, ptr %l29
  %t28 = load i64, ptr %l28
  %t29 = load i64, ptr %l29
  %t30 = add i64 %t28, %t29
  store i64 %t30, ptr %l30
  %t31 = load i64, ptr %l30
  %t32 = sub i64 %t31, 1
  store i64 %t32, ptr %l31
  %t33 = load i64, ptr %l4
  store i64 %t33, ptr %l32
  %t34 = load i64, ptr %l31
  %t35 = load i64, ptr %l32
  %t36 = sdiv i64 %t34, %t35
  store i64 %t36, ptr %l33
  %t37 = load i64, ptr %l33
  store i64 %t37, ptr %l25
  br label %bb7
bb6:
  store i64 0, ptr %l25
  br label %bb7
bb7:
  %t38 = load i64, ptr %l25
  store i64 %t38, ptr %l22
  br label %bb8
bb8:
  %t39 = load i64, ptr %l22
  store i64 %t39, ptr %l5
  store i64 0, ptr %l6
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t40 = load i64, ptr %l6
  store i64 %t40, ptr %l34
  %t41 = load i64, ptr %l5
  store i64 %t41, ptr %l35
  %t42 = load i64, ptr %l34
  %t43 = load i64, ptr %l35
  %t44 = icmp slt i64 %t42, %t43
  store i1 %t44, ptr %l36
  %t45 = load i1, ptr %l36
  %t46 = xor i1 %t45, true
  store i1 %t46, ptr %l37
  %t47 = load i1, ptr %l37
  br i1 %t47, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb41
bb11:
  br label %bb12
bb12:
  %t48 = load i64, ptr %l2
  store i64 %t48, ptr %l38
  %t49 = load i64, ptr %l6
  store i64 %t49, ptr %l39
  %t50 = load i64, ptr %l4
  store i64 %t50, ptr %l40
  %t51 = load i64, ptr %l39
  %t52 = load i64, ptr %l40
  %t53 = mul i64 %t51, %t52
  store i64 %t53, ptr %l41
  %t54 = load i64, ptr %l38
  %t55 = load i64, ptr %l41
  %t56 = add i64 %t54, %t55
  store i64 %t56, ptr %l42
  %t57 = load i64, ptr %l42
  store i64 %t57, ptr %l7
  %t58 = load ptr, ptr %l0
  store ptr %t58, ptr %l43
  %t59 = load ptr, ptr %l43
  %t60 = getelementptr %"compiler/load:Loader", ptr %t59, i32 0, i32 5
  store ptr %t60, ptr %l44
  %t61 = load i64, ptr %l7
  store i64 %t61, ptr %l45
  %t62 = load ptr, ptr %l44
  %t63 = load i64, ptr %l45
  %t64 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t62, i64 %t63)
  store ptr %t64, ptr %l46
  br label %bb13
bb13:
  %t65 = load ptr, ptr %l46
  store ptr %t65, ptr %l8
  store %olang.scope zeroinitializer, ptr %s3
  store i64 0, ptr %l9
  %t66 = load ptr, ptr %l8
  store ptr %t66, ptr %l47
  %t67 = load ptr, ptr %l47
  %t68 = getelementptr %"compiler/load:Module", ptr %t67, i32 0, i32 12
  store ptr %t68, ptr %l48
  %t69 = load ptr, ptr %l48
  %t70 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2eLen_3cI32_3e(ptr %v0, ptr %t69)
  store i64 %t70, ptr %l49
  br label %bb14
bb14:
  %t71 = load i64, ptr %l49
  store i64 %t71, ptr %l10
  store i64 1, ptr %l11
  %t72 = load i64, ptr %l10
  store i64 %t72, ptr %l50
  %t73 = load i64, ptr %l9
  store i64 %t73, ptr %l51
  %t74 = load i64, ptr %l50
  %t75 = load i64, ptr %l51
  %t76 = icmp sgt i64 %t74, %t75
  store i1 %t76, ptr %l52
  %t77 = load i1, ptr %l52
  br i1 %t77, label %bb15, label %bb16
bb15:
  %t78 = load i64, ptr %l11
  store i64 %t78, ptr %l54
  %t79 = load i64, ptr %l54
  %t80 = icmp sgt i64 %t79, 0
  store i1 %t80, ptr %l55
  %t81 = load i1, ptr %l55
  br i1 %t81, label %bb17, label %bb18
bb16:
  store i64 0, ptr %l53
  br label %bb20
bb17:
  %t82 = load i64, ptr %l10
  store i64 %t82, ptr %l57
  %t83 = load i64, ptr %l9
  store i64 %t83, ptr %l58
  %t84 = load i64, ptr %l57
  %t85 = load i64, ptr %l58
  %t86 = sub i64 %t84, %t85
  store i64 %t86, ptr %l59
  %t87 = load i64, ptr %l11
  store i64 %t87, ptr %l60
  %t88 = load i64, ptr %l59
  %t89 = load i64, ptr %l60
  %t90 = add i64 %t88, %t89
  store i64 %t90, ptr %l61
  %t91 = load i64, ptr %l61
  %t92 = sub i64 %t91, 1
  store i64 %t92, ptr %l62
  %t93 = load i64, ptr %l11
  store i64 %t93, ptr %l63
  %t94 = load i64, ptr %l62
  %t95 = load i64, ptr %l63
  %t96 = sdiv i64 %t94, %t95
  store i64 %t96, ptr %l64
  %t97 = load i64, ptr %l64
  store i64 %t97, ptr %l56
  br label %bb19
bb18:
  store i64 0, ptr %l56
  br label %bb19
bb19:
  %t98 = load i64, ptr %l56
  store i64 %t98, ptr %l53
  br label %bb20
bb20:
  %t99 = load i64, ptr %l53
  store i64 %t99, ptr %l12
  store i64 0, ptr %l13
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s4
  %t100 = load i64, ptr %l13
  store i64 %t100, ptr %l65
  %t101 = load i64, ptr %l12
  store i64 %t101, ptr %l66
  %t102 = load i64, ptr %l65
  %t103 = load i64, ptr %l66
  %t104 = icmp slt i64 %t102, %t103
  store i1 %t104, ptr %l67
  %t105 = load i1, ptr %l67
  %t106 = xor i1 %t105, true
  store i1 %t106, ptr %l68
  %t107 = load i1, ptr %l68
  br i1 %t107, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s4)
  br label %bb39
bb23:
  br label %bb24
bb24:
  %t108 = load i64, ptr %l9
  store i64 %t108, ptr %l69
  %t109 = load i64, ptr %l13
  store i64 %t109, ptr %l70
  %t110 = load i64, ptr %l11
  store i64 %t110, ptr %l71
  %t111 = load i64, ptr %l70
  %t112 = load i64, ptr %l71
  %t113 = mul i64 %t111, %t112
  store i64 %t113, ptr %l72
  %t114 = load i64, ptr %l69
  %t115 = load i64, ptr %l72
  %t116 = add i64 %t114, %t115
  store i64 %t116, ptr %l73
  %t117 = load i64, ptr %l73
  store i64 %t117, ptr %l14
  %t118 = load ptr, ptr %l0
  store ptr %t118, ptr %l74
  %t119 = load i64, ptr %l7
  store i64 %t119, ptr %l75
  %t120 = load i64, ptr %l14
  store i64 %t120, ptr %l76
  %t121 = load ptr, ptr %l74
  %t122 = load i64, ptr %l75
  %t123 = load i64, ptr %l76
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2edecide(ptr %v0, ptr %t121, i64 %t122, i64 %t123)
  br label %bb25
bb25:
  %t124 = load ptr, ptr %l8
  store ptr %t124, ptr %l77
  %t125 = load ptr, ptr %l77
  %t126 = getelementptr %"compiler/load:Module", ptr %t125, i32 0, i32 14
  store ptr %t126, ptr %l78
  %t127 = load i64, ptr %l14
  store i64 %t127, ptr %l79
  %t128 = load ptr, ptr %l78
  %t129 = load i64, ptr %l79
  %t130 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t128, i64 %t129)
  store i64 %t130, ptr %l80
  br label %bb26
bb26:
  %t131 = load i64, ptr @G_2ecompiler_2fload_2ePending
  store i64 %t131, ptr %l81
  %t132 = load i64, ptr %l80
  %t133 = load i64, ptr %l81
  %t134 = icmp eq i64 %t132, %t133
  store i1 %t134, ptr %l82
  %t135 = load i1, ptr %l82
  br i1 %t135, label %bb27, label %bb28
bb27:
  %t136 = load ptr, ptr %l0
  store ptr %t136, ptr %l84
  %t137 = load i64, ptr %l7
  store i64 %t137, ptr %l85
  %t138 = load ptr, ptr %l8
  store ptr %t138, ptr %l86
  %t139 = load ptr, ptr %l86
  %t140 = getelementptr %"compiler/load:Module", ptr %t139, i32 0, i32 13
  store ptr %t140, ptr %l87
  %t141 = load i64, ptr %l14
  store i64 %t141, ptr %l88
  %t142 = load ptr, ptr %l87
  %t143 = load i64, ptr %l88
  %t144 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t142, i64 %t143)
  store i64 %t144, ptr %l89
  br label %bb29
bb28:
  store i1 false, ptr %l83
  br label %bb31
bb29:
  %t145 = load ptr, ptr %l84
  %t146 = load i64, ptr %l85
  %t147 = load i64, ptr %l89
  %t148 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2etaken(ptr %v0, ptr %t145, i64 %t146, i64 %t147)
  store i64 %t148, ptr %l90
  br label %bb30
bb30:
  %t149 = load i64, ptr %l90
  %t150 = icmp eq i64 %t149, 1
  store i1 %t150, ptr %l91
  %t151 = load i1, ptr %l91
  store i1 %t151, ptr %l83
  br label %bb31
bb31:
  %t152 = load i1, ptr %l83
  br i1 %t152, label %bb32, label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s5
  %t153 = load ptr, ptr %lp1
  store ptr %t153, ptr %l92
  %t154 = load i64, ptr %l7
  store i64 %t154, ptr %l93
  %t155 = load ptr, ptr %l8
  store ptr %t155, ptr %l94
  %t156 = load ptr, ptr %l94
  %t157 = getelementptr %"compiler/load:Module", ptr %t156, i32 0, i32 12
  store ptr %t157, ptr %l95
  %t158 = load i64, ptr %l14
  store i64 %t158, ptr %l96
  %t159 = load ptr, ptr %l95
  %t160 = load i64, ptr %l96
  %t161 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2eAt_3cI32_3e(ptr %v0, ptr %t159, i64 %t160)
  store i32 %t161, ptr %l97
  br label %bb34
bb33:
  br label %bb37
bb34:
  %t162 = load i64, ptr %l93
  %t163 = load i32, ptr %l97
  %t164 = call %"std/pair:Pair<I64, I32>" @std_2fpair_3aPair_3cI64_2c_20I32_3e_2ector(ptr %s5, i64 %t162, i32 %t163)
  store %"std/pair:Pair<I64, I32>" %t164, ptr %l98
  br label %bb35
bb35:
  %t165 = load ptr, ptr %l92
  %t166 = load %"std/pair:Pair<I64, I32>", ptr %l98
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20I32_3e_Hd7be20793e0d40c909f29debacc96a43(ptr %v1, ptr %t165, %"std/pair:Pair<I64, I32>" %t166)
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s5)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s4)
  br label %bb38
bb38:
  store %olang.scope zeroinitializer, ptr %s6
  %t167 = load i64, ptr %l13
  store i64 %t167, ptr %l99
  %t168 = load i64, ptr %l99
  %t169 = add i64 %t168, 1
  store i64 %t169, ptr %l100
  %t170 = load i64, ptr %l100
  store i64 %t170, ptr %l13
  call void @__olang_scope_close(ptr %s6)
  br label %bb21
bb39:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  br label %bb40
bb40:
  store %olang.scope zeroinitializer, ptr %s7
  %t171 = load i64, ptr %l6
  store i64 %t171, ptr %l101
  %t172 = load i64, ptr %l101
  %t173 = add i64 %t172, 1
  store i64 %t173, ptr %l102
  %t174 = load i64, ptr %l102
  store i64 %t174, ptr %l6
  call void @__olang_scope_close(ptr %s7)
  br label %bb9
bb41:
  call void @__olang_scope_close(ptr %s1)
  %t175 = load ptr, ptr %lp1
  %t176 = load %"std/prelude/list:List<std/pair:Pair<I64, I32>>", ptr %t175
  store %"std/prelude/list:List<std/pair:Pair<I64, I32>>" %t176, ptr %l103
  call void @__olang_scope_close(ptr %s0)
  %t177 = load %"std/prelude/list:List<std/pair:Pair<I64, I32>>", ptr %l103
  store %"std/prelude/list:List<std/pair:Pair<I64, I32>>" %t177, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List<std/pair:Pair<I64, I32>>", ptr %rv
  ret %"std/prelude/list:List<std/pair:Pair<I64, I32>>" %rr
}

define dso_local { i64, [3 x i64] } @compiler_2fload_2ecompiler_2fload_3aLoader_2eat(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca { i64, [3 x i64] }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [3 x i64] }
  %t13 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1
  store ptr %t1, ptr %l3
  %t2 = load ptr, ptr %l3
  %t3 = getelementptr %"compiler/load:Module", ptr %t2, i32 0, i32 4
  %t4 = load i64, ptr %t3
  store i64 %t4, ptr %l4
  %t5 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t6 = load i32, ptr %t5
  store i32 %t6, ptr %l5
  %t7 = load i32, ptr %l5
  %t8 = sext i32 %t7 to i64
  store i64 %t8, ptr %l6
  %t9 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 1
  %t10 = load i32, ptr %t9
  store i32 %t10, ptr %l7
  %t11 = load i32, ptr %l7
  %t12 = sext i32 %t11 to i64
  store i64 %t12, ptr %l8
  store { i64, [3 x i64] } zeroinitializer, ptr %t13
  %t14 = getelementptr { i64, [3 x i64] }, ptr %t13, i32 0, i32 0
  store i64 3, ptr %t14
  %t15 = load i64, ptr %l4
  %t16 = insertvalue { i64, i64, i64 } undef, i64 %t15, 0
  %t17 = load i64, ptr %l6
  %t18 = insertvalue { i64, i64, i64 } %t16, i64 %t17, 1
  %t19 = load i64, ptr %l8
  %t20 = insertvalue { i64, i64, i64 } %t18, i64 %t19, 2
  %t21 = getelementptr { i64, [3 x i64] }, ptr %t13, i32 0, i32 1
  store { i64, i64, i64 } %t20, ptr %t21
  %t22 = load { i64, [3 x i64] }, ptr %t13
  store { i64, [3 x i64] } %t22, ptr %l9
  call void @__olang_scope_close(ptr %s0)
  %t23 = load { i64, [3 x i64] }, ptr %l9
  store { i64, [3 x i64] } %t23, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [3 x i64] }, ptr %rv
  ret { i64, [3 x i64] } %rr
}

define dso_local i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2ebranch(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1
  store ptr %t1, ptr %l4
  %t2 = load ptr, ptr %l4
  %t3 = getelementptr %"compiler/load:Module", ptr %t2, i32 0, i32 18
  store ptr %t3, ptr %l5
  %t4 = load i64, ptr %l2
  store i64 %t4, ptr %l6
  %t5 = load ptr, ptr %l5
  %t6 = load i64, ptr %l6
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t5, i64 %t6)
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l1
  store ptr %t7, ptr %l7
  %t8 = load ptr, ptr %l7
  %t9 = getelementptr %"compiler/load:Module", ptr %t8, i32 0, i32 19
  store ptr %t9, ptr %l8
  %t10 = load i64, ptr %l3
  store i64 %t10, ptr %l9
  %t11 = load ptr, ptr %l8
  %t12 = load i64, ptr %l9
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t11, i64 %t12)
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l1
  store ptr %t13, ptr %l10
  %t14 = load ptr, ptr %l10
  %t15 = getelementptr %"compiler/load:Module", ptr %t14, i32 0, i32 18
  store ptr %t15, ptr %l11
  %t16 = load ptr, ptr %l11
  %t17 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t16)
  store i64 %t17, ptr %l12
  br label %bb3
bb3:
  %t18 = load i64, ptr %l12
  %t19 = sub i64 %t18, 1
  store i64 %t19, ptr %l13
  call void @__olang_scope_close(ptr %s0)
  %t20 = load i64, ptr %l13
  store i64 %t20, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fload_2ecompiler_2fload_3aLoader_2ebranchGroup(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i1
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l3
  store i64 %t1, ptr %l5
  %t2 = load i64, ptr @G_2ecompiler_2fload_2ePending
  store i64 %t2, ptr %l6
  %t3 = load i64, ptr %l5
  %t4 = load i64, ptr %l6
  %t5 = icmp eq i64 %t3, %t4
  store i1 %t5, ptr %l7
  %t6 = load i1, ptr %l7
  br i1 %t6, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load i64, ptr %l3
  store i64 %t7, ptr %l8
  %t8 = load i64, ptr %l4
  store i64 %t8, ptr %l9
  %t9 = load i64, ptr %l8
  %t10 = load i64, ptr %l9
  %t11 = icmp eq i64 %t9, %t10
  store i1 %t11, ptr %l10
  %t12 = load i1, ptr %l10
  br i1 %t12, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t13 = load ptr, ptr %l0
  store ptr %t13, ptr %l11
  %t14 = load ptr, ptr %l11
  %t15 = getelementptr %"compiler/load:Loader", ptr %t14, i32 0, i32 4
  %t16 = load ptr, ptr %t15
  store ptr %t16, ptr %l12
  %t17 = load ptr, ptr %l2
  store ptr %t17, ptr %l13
  %t18 = load ptr, ptr %l13
  %t19 = getelementptr %"compiler/ast:TopBranch", ptr %t18, i32 0, i32 2
  %t20 = load i64, ptr %t19
  store i64 %t20, ptr %l14
  %t21 = load ptr, ptr %l12
  %t22 = load i64, ptr %l14
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eChoose(ptr %v0, ptr %t21, i64 %t22)
  br label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s4
  %t23 = load ptr, ptr %l0
  store ptr %t23, ptr %l22
  %t24 = load ptr, ptr %l22
  %t25 = getelementptr %"compiler/load:Loader", ptr %t24, i32 0, i32 4
  %t26 = load ptr, ptr %t25
  store ptr %t26, ptr %l23
  %t27 = load ptr, ptr %l2
  store ptr %t27, ptr %l24
  %t28 = load ptr, ptr %l24
  %t29 = getelementptr %"compiler/ast:TopBranch", ptr %t28, i32 0, i32 2
  %t30 = load i64, ptr %t29
  store i64 %t30, ptr %l25
  %t31 = load ptr, ptr %l23
  %t32 = load i64, ptr %l25
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eDrop(ptr %v0, ptr %t31, i64 %t32)
  br label %bb11
bb6:
  %t33 = load ptr, ptr %l2
  store ptr %t33, ptr %l15
  %t34 = load ptr, ptr %l15
  %t35 = getelementptr %"compiler/ast:TopBranch", ptr %t34, i32 0, i32 1
  %t36 = load { i64, ptr }, ptr %t35
  store { i64, ptr } %t36, ptr %l16
  %t37 = load { i64, ptr }, ptr %l16
  %t38 = extractvalue { i64, ptr } %t37, 0
  %t39 = extractvalue { i64, ptr } zeroinitializer, 0
  %t40 = icmp eq i64 %t38, %t39
  %t41 = extractvalue { i64, ptr } %t37, 1
  %t42 = extractvalue { i64, ptr } zeroinitializer, 1
  %t43 = icmp eq ptr %t41, %t42
  %t44 = and i1 %t40, %t43
  %t45 = xor i1 %t44, true
  store i1 %t45, ptr %l17
  %t46 = load i1, ptr %l17
  br i1 %t46, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  %t47 = load ptr, ptr %l0
  store ptr %t47, ptr %l18
  %t48 = load i64, ptr %l1
  store i64 %t48, ptr %l19
  %t49 = load ptr, ptr %l2
  store ptr %t49, ptr %l20
  %t50 = load ptr, ptr %l20
  %t51 = getelementptr %"compiler/ast:TopBranch", ptr %t50, i32 0, i32 1
  %t52 = load { i64, ptr }, ptr %t51
  store { i64, ptr } %t52, ptr %l21
  %t53 = load ptr, ptr %l18
  %t54 = load i64, ptr %l19
  %t55 = load { i64, ptr }, ptr %l21
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2egroups(ptr %v0, ptr %v1, ptr %t53, i64 %t54, { i64, ptr } %t55)
  br label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb11:
  call void @__olang_scope_close(ptr %s4)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fload_2ecompiler_2fload_3aLoader_2echainGroups(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l5
  %t2 = load i64, ptr %l1
  store i64 %t2, ptr %l6
  %t3 = load ptr, ptr %l2
  store ptr %t3, ptr %l7
  %t4 = load ptr, ptr %l7
  %t5 = getelementptr %"compiler/ast:TopIf", ptr %t4, i32 0, i32 1
  %t6 = load ptr, ptr %t5
  store ptr %t6, ptr %l8
  %t7 = load i64, ptr %l3
  store i64 %t7, ptr %l9
  %t8 = load i64, ptr %l4
  store i64 %t8, ptr %l10
  %t9 = load ptr, ptr %l5
  %t10 = load i64, ptr %l6
  %t11 = load ptr, ptr %l8
  %t12 = load i64, ptr %l9
  %t13 = load i64, ptr %l10
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2ebranchGroup(ptr %v0, ptr %v1, ptr %t9, i64 %t10, ptr %t11, i64 %t12, i64 %t13)
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l2
  store ptr %t14, ptr %l11
  %t15 = load ptr, ptr %l11
  %t16 = getelementptr %"compiler/ast:TopIf", ptr %t15, i32 0, i32 2
  %t17 = load ptr, ptr %t16
  store ptr %t17, ptr %l12
  %t18 = load ptr, ptr %l12
  %t19 = icmp ne ptr %t18, null
  store i1 %t19, ptr %l13
  %t20 = load i1, ptr %l13
  br i1 %t20, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t21 = load ptr, ptr %l0
  store ptr %t21, ptr %l14
  %t22 = load i64, ptr %l1
  store i64 %t22, ptr %l15
  %t23 = load ptr, ptr %l2
  store ptr %t23, ptr %l16
  %t24 = load ptr, ptr %l16
  %t25 = getelementptr %"compiler/ast:TopIf", ptr %t24, i32 0, i32 2
  %t26 = load ptr, ptr %t25
  store ptr %t26, ptr %l17
  %t27 = load i64, ptr %l3
  store i64 %t27, ptr %l18
  %t28 = load i64, ptr %l4
  store i64 %t28, ptr %l19
  %t29 = load i64, ptr %l19
  %t30 = add i64 %t29, 1
  store i64 %t30, ptr %l20
  %t31 = load ptr, ptr %l14
  %t32 = load i64, ptr %l15
  %t33 = load ptr, ptr %l17
  %t34 = load i64, ptr %l18
  %t35 = load i64, ptr %l20
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2echainGroups(ptr %v0, ptr %v1, ptr %t31, i64 %t32, ptr %t33, i64 %t34, i64 %t35)
  br label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_scope_close(ptr %s1)
  br label %bb5
bb5:
  %t36 = load ptr, ptr %l2
  store ptr %t36, ptr %l21
  %t37 = load ptr, ptr %l21
  %t38 = getelementptr %"compiler/ast:TopIf", ptr %t37, i32 0, i32 3
  %t39 = load ptr, ptr %t38
  store ptr %t39, ptr %l22
  %t40 = load ptr, ptr %l22
  %t41 = icmp ne ptr %t40, null
  store i1 %t41, ptr %l23
  %t42 = load i1, ptr %l23
  br i1 %t42, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t43 = load ptr, ptr %l0
  store ptr %t43, ptr %l24
  %t44 = load i64, ptr %l1
  store i64 %t44, ptr %l25
  %t45 = load ptr, ptr %l2
  store ptr %t45, ptr %l26
  %t46 = load ptr, ptr %l26
  %t47 = getelementptr %"compiler/ast:TopIf", ptr %t46, i32 0, i32 3
  %t48 = load ptr, ptr %t47
  store ptr %t48, ptr %l27
  %t49 = load i64, ptr %l3
  store i64 %t49, ptr %l28
  %t50 = load i64, ptr %l4
  store i64 %t50, ptr %l29
  %t51 = load i64, ptr %l29
  %t52 = add i64 %t51, 1
  store i64 %t52, ptr %l30
  %t53 = load ptr, ptr %l24
  %t54 = load i64, ptr %l25
  %t55 = load ptr, ptr %l27
  %t56 = load i64, ptr %l28
  %t57 = load i64, ptr %l30
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2ebranchGroup(ptr %v0, ptr %v1, ptr %t53, i64 %t54, ptr %t55, i64 %t56, i64 %t57)
  br label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fload_2ecompiler_2fload_3aLoader_2echains(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2, { i64, ptr } %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"compiler/load:Import"
  %l11 = alloca { i64, ptr }
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca { i64, ptr }
  %l27 = alloca ptr
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %l30 = alloca i32
  %l31 = alloca i32
  %l32 = alloca i1
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i1
  %l38 = alloca i1
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca %"compiler/load:Import"
  %l42 = alloca i64
  %l43 = alloca i1
  %l44 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l47 = alloca ptr
  %l48 = alloca ptr
  %l49 = alloca i64
  %l50 = alloca ptr
  %l51 = alloca ptr
  %l52 = alloca ptr
  %l53 = alloca { i64, ptr }
  %l54 = alloca ptr
  %l55 = alloca i64
  %l56 = alloca { i64, ptr }
  %l57 = alloca i32
  %l58 = alloca i32
  %l59 = alloca i1
  %l60 = alloca { i64, ptr }
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i64
  %l64 = alloca i1
  %l65 = alloca i1
  %l66 = alloca { i64, ptr }
  %l67 = alloca i64
  %l68 = alloca { i64, ptr }
  %l69 = alloca ptr
  %l70 = alloca ptr
  %l71 = alloca ptr
  %l72 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l74 = alloca i64
  %l75 = alloca i64
  %l76 = alloca i64
  %l77 = alloca i64
  %l78 = alloca i64
  %l79 = alloca ptr
  %l80 = alloca ptr
  %l81 = alloca i64
  %l82 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l85 = alloca i64
  %l86 = alloca i64
  %l87 = alloca i64
  %l88 = alloca i64
  %l89 = alloca i64
  %l90 = alloca i64
  %l91 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.builder
  %s6room = alloca [64 x i8], align 8
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.builder
  %s11room = alloca [64 x i8], align 8
  %s12 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l4
  store i64 %t1, ptr %l18
  %t2 = load i64, ptr %l18
  %t3 = icmp sge i64 %t2, 4
  store i1 %t3, ptr %l19
  %t4 = load i1, ptr %l19
  br i1 %t4, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load ptr, ptr %l0
  store ptr %t5, ptr %l20
  %t6 = load ptr, ptr %l20
  %t7 = getelementptr %"compiler/load:Loader", ptr %t6, i32 0, i32 5
  store ptr %t7, ptr %l21
  %t8 = load i64, ptr %l2
  store i64 %t8, ptr %l22
  %t9 = load ptr, ptr %l21
  %t10 = load i64, ptr %l22
  %t11 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t9, i64 %t10)
  store ptr %t11, ptr %l23
  br label %bb4
bb4:
  %t12 = load ptr, ptr %l23
  store ptr %t12, ptr %l24
  %t13 = load ptr, ptr %l24
  %t14 = getelementptr %"compiler/load:Module", ptr %t13, i32 0, i32 9
  store ptr %t14, ptr %l25
  %t15 = load ptr, ptr %l25
  store ptr %t15, ptr %l5
  store i64 0, ptr %l6
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t16 = load ptr, ptr %l5
  store ptr %t16, ptr %l27
  %t17 = load i64, ptr %l6
  store i64 %t17, ptr %l28
  %t18 = load ptr, ptr %l27
  %t19 = load i64, ptr %l28
  %t20 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2eRunFrom_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %t18, i64 %t19)
  %t21 = extractvalue { i32, { i64, ptr } } %t20, 1
  %t22 = extractvalue { i32, { i64, ptr } } %t20, 0
  store i32 %t22, ptr %l30
  %t23 = icmp ne i32 %t22, 0
  br i1 %t23, label %bb7, label %ok.24
ok.24:
  store { i64, ptr } %t21, ptr %l29
  br label %bb6
bb6:
  %t25 = load { i64, ptr }, ptr %l29
  store { i64, ptr } %t25, ptr %l26
  br label %bb11
bb7:
  %t26 = load i32, ptr %l30
  %t27 = ashr i32 %t26, 16
  store i32 %t27, ptr %l31
  %t28 = load i32, ptr %l31
  %t29 = icmp eq i32 %t28, 1
  store i1 %t29, ptr %l32
  %t30 = load i1, ptr %l32
  br i1 %t30, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @.c42)
  unreachable
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb40
bb11:
  %t31 = load { i64, ptr }, ptr %l26
  store { i64, ptr } %t31, ptr %l7
  %t32 = load { i64, ptr }, ptr %l7
  store { i64, ptr } %t32, ptr %l33
  %t33 = load { i64, ptr }, ptr %l33
  %t34 = extractvalue { i64, ptr } %t33, 0
  store i64 %t34, ptr %l34
  %t35 = load i64, ptr %l34
  store i64 %t35, ptr %l8
  store i64 0, ptr %l9
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s4
  %t36 = load i64, ptr %l9
  store i64 %t36, ptr %l35
  %t37 = load i64, ptr %l8
  store i64 %t37, ptr %l36
  %t38 = load i64, ptr %l35
  %t39 = load i64, ptr %l36
  %t40 = icmp slt i64 %t38, %t39
  store i1 %t40, ptr %l37
  %t41 = load i1, ptr %l37
  %t42 = xor i1 %t41, true
  store i1 %t42, ptr %l38
  %t43 = load i1, ptr %l38
  br i1 %t43, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s4)
  br label %bb38
bb14:
  br label %bb15
bb15:
  %t44 = load { i64, ptr }, ptr %l7
  store { i64, ptr } %t44, ptr %l39
  %t45 = load i64, ptr %l9
  store i64 %t45, ptr %l40
  %t46 = load i64, ptr %l40
  %t47 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t48 = load ptr, ptr %t47
  %t49 = getelementptr %"compiler/load:Import", ptr %t48, i64 %t46
  %t50 = load %"compiler/load:Import", ptr %t49
  store %"compiler/load:Import" %t50, ptr %l41
  %t51 = load %"compiler/load:Import", ptr %l41
  store %"compiler/load:Import" %t51, ptr %l10
  %t52 = getelementptr %"compiler/load:Import", ptr %l10, i32 0, i32 5
  %t53 = load i64, ptr %t52
  store i64 %t53, ptr %l42
  %t54 = load i64, ptr %l42
  %t55 = icmp slt i64 %t54, 0
  store i1 %t55, ptr %l43
  %t56 = load i1, ptr %l43
  br i1 %t56, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s5
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  br label %bb37
bb17:
  br label %bb18
bb18:
  %t57 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t57, ptr %l44
  %t58 = getelementptr %"compiler/load:Import", ptr %l10, i32 0, i32 2
  %t59 = load { i64, ptr }, ptr %t58
  store { i64, ptr } %t59, ptr %l45
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s6
  store ptr %s6room, ptr %s6
  %t60 = load { i64, ptr }, ptr %l44
  %t61 = extractvalue { i64, ptr } %t60, 1
  %t62 = extractvalue { i64, ptr } %t60, 0
  call void @__olang_sb_put(ptr %s6, ptr %t61, i64 %t62)
  %t63 = load { i64, ptr }, ptr %l45
  %t64 = extractvalue { i64, ptr } %t63, 1
  %t65 = extractvalue { i64, ptr } %t63, 0
  call void @__olang_sb_put(ptr %s6, ptr %t64, i64 %t65)
  %t66 = load ptr, ptr %s6
  %t67 = getelementptr %olang.builder, ptr %s6, i32 0, i32 1
  %t68 = load i64, ptr %t67
  %t69 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t68)
  call void @llvm.memcpy.p0.p0.i64(ptr %t69, ptr %t66, i64 %t68, i1 false)
  %t70 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t69, 1
  store { i64, ptr } %t71, ptr %l46
  call void @__olang_sb_done(ptr %s6)
  %t72 = load { i64, ptr }, ptr %l46
  store { i64, ptr } %t72, ptr %l11
  store %olang.scope zeroinitializer, ptr %s7
  %t73 = load ptr, ptr %l0
  store ptr %t73, ptr %l47
  %t74 = load ptr, ptr %l47
  %t75 = getelementptr %"compiler/load:Loader", ptr %t74, i32 0, i32 5
  store ptr %t75, ptr %l48
  %t76 = getelementptr %"compiler/load:Import", ptr %l10, i32 0, i32 5
  %t77 = load i64, ptr %t76
  store i64 %t77, ptr %l49
  %t78 = load ptr, ptr %l48
  %t79 = load i64, ptr %l49
  %t80 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t78, i64 %t79)
  store ptr %t80, ptr %l50
  br label %bb19
bb19:
  %t81 = load ptr, ptr %l50
  store ptr %t81, ptr %l51
  %t82 = load ptr, ptr %l51
  %t83 = getelementptr %"compiler/load:Module", ptr %t82, i32 0, i32 8
  store ptr %t83, ptr %l52
  %t84 = load ptr, ptr %l52
  store ptr %t84, ptr %l12
  store i64 0, ptr %l13
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s8
  %t85 = load ptr, ptr %l12
  store ptr %t85, ptr %l54
  %t86 = load i64, ptr %l13
  store i64 %t86, ptr %l55
  %t87 = load ptr, ptr %l54
  %t88 = load i64, ptr %l55
  %t89 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v0, ptr %t87, i64 %t88)
  %t90 = extractvalue { i32, { i64, ptr } } %t89, 1
  %t91 = extractvalue { i32, { i64, ptr } } %t89, 0
  store i32 %t91, ptr %l57
  %t92 = icmp ne i32 %t91, 0
  br i1 %t92, label %bb22, label %ok.93
ok.93:
  store { i64, ptr } %t90, ptr %l56
  br label %bb21
bb21:
  %t94 = load { i64, ptr }, ptr %l56
  store { i64, ptr } %t94, ptr %l53
  br label %bb26
bb22:
  %t95 = load i32, ptr %l57
  %t96 = ashr i32 %t95, 16
  store i32 %t96, ptr %l58
  %t97 = load i32, ptr %l58
  %t98 = icmp eq i32 %t97, 1
  store i1 %t98, ptr %l59
  %t99 = load i1, ptr %l59
  br i1 %t99, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @.c43)
  unreachable
bb25:
  call void @__olang_scope_close(ptr %s8)
  br label %bb35
bb26:
  %t100 = load { i64, ptr }, ptr %l53
  store { i64, ptr } %t100, ptr %l14
  %t101 = load { i64, ptr }, ptr %l14
  store { i64, ptr } %t101, ptr %l60
  %t102 = load { i64, ptr }, ptr %l60
  %t103 = extractvalue { i64, ptr } %t102, 0
  store i64 %t103, ptr %l61
  %t104 = load i64, ptr %l61
  store i64 %t104, ptr %l15
  store i64 0, ptr %l16
  br label %bb27
bb27:
  store %olang.scope zeroinitializer, ptr %s9
  %t105 = load i64, ptr %l16
  store i64 %t105, ptr %l62
  %t106 = load i64, ptr %l15
  store i64 %t106, ptr %l63
  %t107 = load i64, ptr %l62
  %t108 = load i64, ptr %l63
  %t109 = icmp slt i64 %t107, %t108
  store i1 %t109, ptr %l64
  %t110 = load i1, ptr %l64
  %t111 = xor i1 %t110, true
  store i1 %t111, ptr %l65
  %t112 = load i1, ptr %l65
  br i1 %t112, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s9)
  br label %bb33
bb29:
  br label %bb30
bb30:
  %t113 = load { i64, ptr }, ptr %l14
  store { i64, ptr } %t113, ptr %l66
  %t114 = load i64, ptr %l16
  store i64 %t114, ptr %l67
  %t115 = load i64, ptr %l67
  %t116 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t117 = load ptr, ptr %t116
  %t118 = getelementptr { i64, ptr }, ptr %t117, i64 %t115
  %t119 = load { i64, ptr }, ptr %t118
  store { i64, ptr } %t119, ptr %l68
  %t120 = load { i64, ptr }, ptr %l68
  store { i64, ptr } %t120, ptr %l17
  %t121 = load ptr, ptr %l1
  store ptr %t121, ptr %l69
  %t122 = load ptr, ptr %l0
  store ptr %t122, ptr %l70
  %t123 = load ptr, ptr %l70
  %t124 = getelementptr %"compiler/load:Loader", ptr %t123, i32 0, i32 3
  %t125 = load ptr, ptr %t124
  store ptr %t125, ptr %l71
  %t126 = load { i64, ptr }, ptr %l11
  store { i64, ptr } %t126, ptr %l72
  %t127 = load { i64, ptr }, ptr %l17
  store { i64, ptr } %t127, ptr %l73
  %t128 = load ptr, ptr %l69
  %t129 = load ptr, ptr %l71
  %t130 = load { i64, ptr }, ptr %l72
  %t131 = load { i64, ptr }, ptr %l73
  call void @compiler_2fparse_2ecompiler_2fparse_3aOracle_2eAdd(ptr %v1, ptr %v0, ptr %s4, ptr %v0, ptr %t128, ptr %t129, { i64, ptr } %t130, { i64, ptr } %t131)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s9)
  br label %bb32
bb32:
  store %olang.scope zeroinitializer, ptr %s10
  %t132 = load i64, ptr %l16
  store i64 %t132, ptr %l74
  %t133 = load i64, ptr %l74
  %t134 = add i64 %t133, 1
  store i64 %t134, ptr %l75
  %t135 = load i64, ptr %l75
  store i64 %t135, ptr %l16
  call void @__olang_scope_close(ptr %s10)
  br label %bb27
bb33:
  %t136 = load i64, ptr %l13
  store i64 %t136, ptr %l76
  %t137 = load i64, ptr %l15
  store i64 %t137, ptr %l77
  %t138 = load i64, ptr %l76
  %t139 = load i64, ptr %l77
  %t140 = add i64 %t138, %t139
  store i64 %t140, ptr %l78
  %t141 = load i64, ptr %l78
  store i64 %t141, ptr %l13
  call void @__olang_scope_close(ptr %s8)
  br label %bb34
bb34:
  br label %bb20
bb35:
  call void @__olang_scope_close(ptr %s7)
  %t142 = load ptr, ptr %l0
  store ptr %t142, ptr %l79
  %t143 = load ptr, ptr %l1
  store ptr %t143, ptr %l80
  %t144 = getelementptr %"compiler/load:Import", ptr %l10, i32 0, i32 5
  %t145 = load i64, ptr %t144
  store i64 %t145, ptr %l81
  %t146 = load { i64, ptr }, ptr %l11
  store { i64, ptr } %t146, ptr %l82
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s11
  store ptr %s11room, ptr %s11
  %t147 = load { i64, ptr }, ptr %l82
  %t148 = extractvalue { i64, ptr } %t147, 1
  %t149 = extractvalue { i64, ptr } %t147, 0
  call void @__olang_sb_put(ptr %s11, ptr %t148, i64 %t149)
  %t150 = extractvalue { i64, ptr } { i64 1, ptr @.d44 }, 1
  %t151 = extractvalue { i64, ptr } { i64 1, ptr @.d44 }, 0
  call void @__olang_sb_put(ptr %s11, ptr %t150, i64 %t151)
  %t152 = load ptr, ptr %s11
  %t153 = getelementptr %olang.builder, ptr %s11, i32 0, i32 1
  %t154 = load i64, ptr %t153
  %t155 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t154)
  call void @llvm.memcpy.p0.p0.i64(ptr %t155, ptr %t152, i64 %t154, i1 false)
  %t156 = insertvalue { i64, ptr } undef, i64 %t154, 0
  %t157 = insertvalue { i64, ptr } %t156, ptr %t155, 1
  store { i64, ptr } %t157, ptr %l83
  call void @__olang_sb_done(ptr %s11)
  %t158 = load { i64, ptr }, ptr %l83
  %t159 = extractvalue { i64, ptr } %t158, 0
  %t160 = extractvalue { i64, ptr } %t158, 1
  %t161 = mul i64 %t159, 1
  %t162 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t161)
  call void @llvm.memcpy.p0.p0.i64(ptr %t162, ptr %t160, i64 %t161, i1 false)
  %t163 = insertvalue { i64, ptr } undef, i64 %t159, 0
  %t164 = insertvalue { i64, ptr } %t163, ptr %t162, 1
  store { i64, ptr } %t164, ptr %l84
  %t165 = load i64, ptr %l4
  store i64 %t165, ptr %l85
  %t166 = load i64, ptr %l85
  %t167 = add i64 %t166, 1
  store i64 %t167, ptr %l86
  %t168 = load ptr, ptr %l79
  %t169 = load ptr, ptr %l80
  %t170 = load i64, ptr %l81
  %t171 = load { i64, ptr }, ptr %l84
  %t172 = load i64, ptr %l86
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2echains(ptr %v0, ptr %v1, ptr %s4, ptr %t168, ptr %t169, i64 %t170, { i64, ptr } %t171, i64 %t172)
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s4)
  br label %bb37
bb37:
  store %olang.scope zeroinitializer, ptr %s12
  %t173 = load i64, ptr %l9
  store i64 %t173, ptr %l87
  %t174 = load i64, ptr %l87
  %t175 = add i64 %t174, 1
  store i64 %t175, ptr %l88
  %t176 = load i64, ptr %l88
  store i64 %t176, ptr %l9
  call void @__olang_scope_close(ptr %s12)
  br label %bb12
bb38:
  %t177 = load i64, ptr %l6
  store i64 %t177, ptr %l89
  %t178 = load i64, ptr %l8
  store i64 %t178, ptr %l90
  %t179 = load i64, ptr %l89
  %t180 = load i64, ptr %l90
  %t181 = add i64 %t179, %t180
  store i64 %t181, ptr %l91
  %t182 = load i64, ptr %l91
  store i64 %t182, ptr %l6
  call void @__olang_scope_close(ptr %s3)
  br label %bb39
bb39:
  br label %bb5
bb40:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fload_2ecompiler_2fload_3aLoader_2echeckReach(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca %"std/prelude/list:List<I64>"
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca %"compiler/load:Import"
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i1
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i1
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i1
  %l43 = alloca i1
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca %"std/prelude/list:List<I64>"
  %l50 = alloca ptr
  %l51 = alloca ptr
  %l52 = alloca i64
  %l53 = alloca ptr
  %l54 = alloca ptr
  %l55 = alloca ptr
  %l56 = alloca { i64, ptr }
  %l57 = alloca ptr
  %l58 = alloca i64
  %l59 = alloca { i64, ptr }
  %l60 = alloca i32
  %l61 = alloca i32
  %l62 = alloca i1
  %l63 = alloca { i64, ptr }
  %l64 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca i1
  %l68 = alloca i1
  %l69 = alloca { i64, ptr }
  %l70 = alloca i64
  %l71 = alloca %"compiler/load:Import"
  %l72 = alloca i64
  %l73 = alloca i1
  %l74 = alloca ptr
  %l75 = alloca i64
  %l76 = alloca ptr
  %l77 = alloca ptr
  %l78 = alloca i64
  %l79 = alloca ptr
  %l80 = alloca ptr
  %l81 = alloca ptr
  %l82 = alloca { i64, ptr }
  %l83 = alloca ptr
  %l84 = alloca i64
  %l85 = alloca { i64, ptr }
  %l86 = alloca i32
  %l87 = alloca i32
  %l88 = alloca i1
  %l89 = alloca { i64, ptr }
  %l90 = alloca i64
  %l91 = alloca i64
  %l92 = alloca i64
  %l93 = alloca i1
  %l94 = alloca i1
  %l95 = alloca { i64, ptr }
  %l96 = alloca i64
  %l97 = alloca i64
  %l98 = alloca i64
  %l99 = alloca ptr
  %l100 = alloca i64
  %l101 = alloca i1
  %l102 = alloca ptr
  %l103 = alloca ptr
  %l104 = alloca ptr
  %l105 = alloca ptr
  %l106 = alloca %"compiler/source:Span"
  %l107 = alloca { i64, [3 x i64] }
  %l108 = alloca { i64, ptr }
  %l109 = alloca { i64, ptr }
  %l110 = alloca { i64, ptr }
  %l111 = alloca %"compiler/msgs:Msg"
  %l112 = alloca i64
  %l113 = alloca ptr
  %l114 = alloca i64
  %l115 = alloca i64
  %l116 = alloca i64
  %l117 = alloca i64
  %l118 = alloca i64
  %l119 = alloca i64
  %l120 = alloca i64
  %l121 = alloca i64
  %l122 = alloca i64
  %l123 = alloca i64
  %l124 = alloca i64
  %l125 = alloca i64
  %l126 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store %olang.scope zeroinitializer, ptr %s1
  store i64 0, ptr %l1
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l22
  %t2 = load ptr, ptr %l22
  %t3 = getelementptr %"compiler/load:Loader", ptr %t2, i32 0, i32 5
  store ptr %t3, ptr %l23
  %t4 = load ptr, ptr %l23
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v0, ptr %t4)
  store i64 %t5, ptr %l24
  br label %bb1
bb1:
  %t6 = load i64, ptr %l24
  store i64 %t6, ptr %l2
  store i64 1, ptr %l3
  %t7 = load i64, ptr %l2
  store i64 %t7, ptr %l25
  %t8 = load i64, ptr %l1
  store i64 %t8, ptr %l26
  %t9 = load i64, ptr %l25
  %t10 = load i64, ptr %l26
  %t11 = icmp sgt i64 %t9, %t10
  store i1 %t11, ptr %l27
  %t12 = load i1, ptr %l27
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l3
  store i64 %t13, ptr %l29
  %t14 = load i64, ptr %l29
  %t15 = icmp sgt i64 %t14, 0
  store i1 %t15, ptr %l30
  %t16 = load i1, ptr %l30
  br i1 %t16, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l28
  br label %bb7
bb4:
  %t17 = load i64, ptr %l2
  store i64 %t17, ptr %l32
  %t18 = load i64, ptr %l1
  store i64 %t18, ptr %l33
  %t19 = load i64, ptr %l32
  %t20 = load i64, ptr %l33
  %t21 = sub i64 %t19, %t20
  store i64 %t21, ptr %l34
  %t22 = load i64, ptr %l3
  store i64 %t22, ptr %l35
  %t23 = load i64, ptr %l34
  %t24 = load i64, ptr %l35
  %t25 = add i64 %t23, %t24
  store i64 %t25, ptr %l36
  %t26 = load i64, ptr %l36
  %t27 = sub i64 %t26, 1
  store i64 %t27, ptr %l37
  %t28 = load i64, ptr %l3
  store i64 %t28, ptr %l38
  %t29 = load i64, ptr %l37
  %t30 = load i64, ptr %l38
  %t31 = sdiv i64 %t29, %t30
  store i64 %t31, ptr %l39
  %t32 = load i64, ptr %l39
  store i64 %t32, ptr %l31
  br label %bb6
bb5:
  store i64 0, ptr %l31
  br label %bb6
bb6:
  %t33 = load i64, ptr %l31
  store i64 %t33, ptr %l28
  br label %bb7
bb7:
  %t34 = load i64, ptr %l28
  store i64 %t34, ptr %l4
  store i64 0, ptr %l5
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load i64, ptr %l5
  store i64 %t35, ptr %l40
  %t36 = load i64, ptr %l4
  store i64 %t36, ptr %l41
  %t37 = load i64, ptr %l40
  %t38 = load i64, ptr %l41
  %t39 = icmp slt i64 %t37, %t38
  store i1 %t39, ptr %l42
  %t40 = load i1, ptr %l42
  %t41 = xor i1 %t40, true
  store i1 %t41, ptr %l43
  %t42 = load i1, ptr %l43
  br i1 %t42, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb59
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l1
  store i64 %t43, ptr %l44
  %t44 = load i64, ptr %l5
  store i64 %t44, ptr %l45
  %t45 = load i64, ptr %l3
  store i64 %t45, ptr %l46
  %t46 = load i64, ptr %l45
  %t47 = load i64, ptr %l46
  %t48 = mul i64 %t46, %t47
  store i64 %t48, ptr %l47
  %t49 = load i64, ptr %l44
  %t50 = load i64, ptr %l47
  %t51 = add i64 %t49, %t50
  store i64 %t51, ptr %l48
  %t52 = load i64, ptr %l48
  store i64 %t52, ptr %l6
  %t53 = load ptr, ptr @__olang_prog_scope
  %t54 = call %"std/prelude/list:List<I64>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t53)
  store %"std/prelude/list:List<I64>" %t54, ptr %l49
  br label %bb12
bb12:
  %t55 = load %"std/prelude/list:List<I64>", ptr %l49
  store %"std/prelude/list:List<I64>" %t55, ptr %l7
  %t56 = load ptr, ptr %l0
  store ptr %t56, ptr %l50
  %t57 = load ptr, ptr %l50
  %t58 = getelementptr %"compiler/load:Loader", ptr %t57, i32 0, i32 5
  store ptr %t58, ptr %l51
  %t59 = load i64, ptr %l6
  store i64 %t59, ptr %l52
  %t60 = load ptr, ptr %l51
  %t61 = load i64, ptr %l52
  %t62 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t60, i64 %t61)
  store ptr %t62, ptr %l53
  br label %bb13
bb13:
  %t63 = load ptr, ptr %l53
  store ptr %t63, ptr %l8
  store %olang.scope zeroinitializer, ptr %s3
  %t64 = load ptr, ptr %l8
  store ptr %t64, ptr %l54
  %t65 = load ptr, ptr %l54
  %t66 = getelementptr %"compiler/load:Module", ptr %t65, i32 0, i32 9
  store ptr %t66, ptr %l55
  %t67 = load ptr, ptr %l55
  store ptr %t67, ptr %l9
  store i64 0, ptr %l10
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s4
  %t68 = load ptr, ptr %l9
  store ptr %t68, ptr %l57
  %t69 = load i64, ptr %l10
  store i64 %t69, ptr %l58
  %t70 = load ptr, ptr %l57
  %t71 = load i64, ptr %l58
  %t72 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2eRunFrom_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %t70, i64 %t71)
  %t73 = extractvalue { i32, { i64, ptr } } %t72, 1
  %t74 = extractvalue { i32, { i64, ptr } } %t72, 0
  store i32 %t74, ptr %l60
  %t75 = icmp ne i32 %t74, 0
  br i1 %t75, label %bb16, label %ok.76
ok.76:
  store { i64, ptr } %t73, ptr %l59
  br label %bb15
bb15:
  %t77 = load { i64, ptr }, ptr %l59
  store { i64, ptr } %t77, ptr %l56
  br label %bb20
bb16:
  %t78 = load i32, ptr %l60
  %t79 = ashr i32 %t78, 16
  store i32 %t79, ptr %l61
  %t80 = load i32, ptr %l61
  %t81 = icmp eq i32 %t80, 1
  store i1 %t81, ptr %l62
  %t82 = load i1, ptr %l62
  br i1 %t82, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @.c45)
  unreachable
bb19:
  call void @__olang_scope_close(ptr %s4)
  br label %bb57
bb20:
  %t83 = load { i64, ptr }, ptr %l56
  store { i64, ptr } %t83, ptr %l11
  %t84 = load { i64, ptr }, ptr %l11
  store { i64, ptr } %t84, ptr %l63
  %t85 = load { i64, ptr }, ptr %l63
  %t86 = extractvalue { i64, ptr } %t85, 0
  store i64 %t86, ptr %l64
  %t87 = load i64, ptr %l64
  store i64 %t87, ptr %l12
  store i64 0, ptr %l13
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s5
  %t88 = load i64, ptr %l13
  store i64 %t88, ptr %l65
  %t89 = load i64, ptr %l12
  store i64 %t89, ptr %l66
  %t90 = load i64, ptr %l65
  %t91 = load i64, ptr %l66
  %t92 = icmp slt i64 %t90, %t91
  store i1 %t92, ptr %l67
  %t93 = load i1, ptr %l67
  %t94 = xor i1 %t93, true
  store i1 %t94, ptr %l68
  %t95 = load i1, ptr %l68
  br i1 %t95, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s5)
  br label %bb55
bb23:
  br label %bb24
bb24:
  %t96 = load { i64, ptr }, ptr %l11
  store { i64, ptr } %t96, ptr %l69
  %t97 = load i64, ptr %l13
  store i64 %t97, ptr %l70
  %t98 = load i64, ptr %l70
  %t99 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t100 = load ptr, ptr %t99
  %t101 = getelementptr %"compiler/load:Import", ptr %t100, i64 %t98
  %t102 = load %"compiler/load:Import", ptr %t101
  store %"compiler/load:Import" %t102, ptr %l71
  %t103 = load %"compiler/load:Import", ptr %l71
  store %"compiler/load:Import" %t103, ptr %l14
  %t104 = getelementptr %"compiler/load:Import", ptr %l14, i32 0, i32 5
  %t105 = load i64, ptr %t104
  store i64 %t105, ptr %l72
  %t106 = load i64, ptr %l72
  %t107 = icmp slt i64 %t106, 0
  store i1 %t107, ptr %l73
  %t108 = load i1, ptr %l73
  br i1 %t108, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s6
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  br label %bb54
bb26:
  br label %bb27
bb27:
  %t109 = load ptr, ptr %l0
  store ptr %t109, ptr %l74
  %t110 = getelementptr %"compiler/load:Import", ptr %l14, i32 0, i32 5
  %t111 = load i64, ptr %t110
  store i64 %t111, ptr %l75
  %t112 = load ptr, ptr %l74
  %t113 = load i64, ptr %l75
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2eclosure(ptr %v0, ptr %t112, i64 %t113)
  br label %bb28
bb28:
  store %olang.scope zeroinitializer, ptr %s7
  %t114 = load ptr, ptr %l0
  store ptr %t114, ptr %l76
  %t115 = load ptr, ptr %l76
  %t116 = getelementptr %"compiler/load:Loader", ptr %t115, i32 0, i32 5
  store ptr %t116, ptr %l77
  %t117 = getelementptr %"compiler/load:Import", ptr %l14, i32 0, i32 5
  %t118 = load i64, ptr %t117
  store i64 %t118, ptr %l78
  %t119 = load ptr, ptr %l77
  %t120 = load i64, ptr %l78
  %t121 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t119, i64 %t120)
  store ptr %t121, ptr %l79
  br label %bb29
bb29:
  %t122 = load ptr, ptr %l79
  store ptr %t122, ptr %l80
  %t123 = load ptr, ptr %l80
  %t124 = getelementptr %"compiler/load:Module", ptr %t123, i32 0, i32 26
  store ptr %t124, ptr %l81
  %t125 = load ptr, ptr %l81
  store ptr %t125, ptr %l15
  store i64 0, ptr %l16
  br label %bb30
bb30:
  store %olang.scope zeroinitializer, ptr %s8
  %t126 = load ptr, ptr %l15
  store ptr %t126, ptr %l83
  %t127 = load i64, ptr %l16
  store i64 %t127, ptr %l84
  %t128 = load ptr, ptr %l83
  %t129 = load i64, ptr %l84
  %t130 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %t128, i64 %t129)
  %t131 = extractvalue { i32, { i64, ptr } } %t130, 1
  %t132 = extractvalue { i32, { i64, ptr } } %t130, 0
  store i32 %t132, ptr %l86
  %t133 = icmp ne i32 %t132, 0
  br i1 %t133, label %bb32, label %ok.134
ok.134:
  store { i64, ptr } %t131, ptr %l85
  br label %bb31
bb31:
  %t135 = load { i64, ptr }, ptr %l85
  store { i64, ptr } %t135, ptr %l82
  br label %bb36
bb32:
  %t136 = load i32, ptr %l86
  %t137 = ashr i32 %t136, 16
  store i32 %t137, ptr %l87
  %t138 = load i32, ptr %l87
  %t139 = icmp eq i32 %t138, 1
  store i1 %t139, ptr %l88
  %t140 = load i1, ptr %l88
  br i1 %t140, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @.c46)
  unreachable
bb35:
  call void @__olang_scope_close(ptr %s8)
  br label %bb53
bb36:
  %t141 = load { i64, ptr }, ptr %l82
  store { i64, ptr } %t141, ptr %l17
  %t142 = load { i64, ptr }, ptr %l17
  store { i64, ptr } %t142, ptr %l89
  %t143 = load { i64, ptr }, ptr %l89
  %t144 = extractvalue { i64, ptr } %t143, 0
  store i64 %t144, ptr %l90
  %t145 = load i64, ptr %l90
  store i64 %t145, ptr %l18
  store i64 0, ptr %l19
  br label %bb37
bb37:
  store %olang.scope zeroinitializer, ptr %s9
  %t146 = load i64, ptr %l19
  store i64 %t146, ptr %l91
  %t147 = load i64, ptr %l18
  store i64 %t147, ptr %l92
  %t148 = load i64, ptr %l91
  %t149 = load i64, ptr %l92
  %t150 = icmp slt i64 %t148, %t149
  store i1 %t150, ptr %l93
  %t151 = load i1, ptr %l93
  %t152 = xor i1 %t151, true
  store i1 %t152, ptr %l94
  %t153 = load i1, ptr %l94
  br i1 %t153, label %bb38, label %bb39
bb38:
  call void @__olang_scope_close(ptr %s9)
  br label %bb51
bb39:
  br label %bb40
bb40:
  %t154 = load { i64, ptr }, ptr %l17
  store { i64, ptr } %t154, ptr %l95
  %t155 = load i64, ptr %l19
  store i64 %t155, ptr %l96
  %t156 = load i64, ptr %l96
  %t157 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t158 = load ptr, ptr %t157
  %t159 = getelementptr i64, ptr %t158, i64 %t156
  %t160 = load i64, ptr %t159
  store i64 %t160, ptr %l97
  %t161 = load i64, ptr %l97
  store i64 %t161, ptr %l20
  %t162 = load i64, ptr %l20
  store i64 %t162, ptr %l98
  %t163 = load i64, ptr %l98
  store i64 %t163, ptr %l21
  store ptr %l7, ptr %l99
  %t164 = load i64, ptr %l21
  store i64 %t164, ptr %l100
  %t165 = load ptr, ptr %l99
  %t166 = load i64, ptr %l100
  %t167 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eHas_3cI64_3e(ptr %s2, ptr %t165, i64 %t166)
  store i1 %t167, ptr %l101
  br label %bb41
bb41:
  %t168 = load i1, ptr %l101
  br i1 %t168, label %bb42, label %bb43
bb42:
  store %olang.scope zeroinitializer, ptr %s10
  %t169 = load ptr, ptr %l0
  store ptr %t169, ptr %l102
  %t170 = load ptr, ptr %l102
  %t171 = getelementptr %"compiler/load:Loader", ptr %t170, i32 0, i32 4
  %t172 = load ptr, ptr %t171
  store ptr %t172, ptr %l103
  %t173 = load ptr, ptr %l0
  store ptr %t173, ptr %l104
  %t174 = load ptr, ptr %l8
  store ptr %t174, ptr %l105
  %t175 = getelementptr %"compiler/load:Import", ptr %l14, i32 0, i32 1
  %t176 = load %"compiler/source:Span", ptr %t175
  store %"compiler/source:Span" %t176, ptr %l106
  %t177 = load ptr, ptr %l104
  %t178 = load ptr, ptr %l105
  %t179 = load %"compiler/source:Span", ptr %l106
  %t180 = call { i64, [3 x i64] } @compiler_2fload_2ecompiler_2fload_3aLoader_2eat(ptr %v0, ptr %v0, ptr %t177, ptr %t178, %"compiler/source:Span" %t179)
  store { i64, [3 x i64] } %t180, ptr %l107
  br label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s11
  store ptr %l7, ptr %l113
  %t181 = load i64, ptr %l20
  store i64 %t181, ptr %l114
  %t182 = load ptr, ptr %l113
  %t183 = load i64, ptr %l114
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s2, ptr %t182, i64 %t183)
  br label %bb48
bb44:
  %t184 = getelementptr %"compiler/load:Import", ptr %l14, i32 0, i32 2
  %t185 = load { i64, ptr }, ptr %t184
  store { i64, ptr } %t185, ptr %l108
  %t186 = load { i64, ptr }, ptr %l108
  %t187 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %s10, { i64, ptr } %t186)
  store { i64, ptr } %t187, ptr %l109
  br label %bb45
bb45:
  %t188 = load { i64, ptr }, ptr %l109
  %t189 = extractvalue { i64, ptr } %t188, 0
  %t190 = extractvalue { i64, ptr } %t188, 1
  %t191 = mul i64 %t189, 1
  %t192 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t191)
  call void @llvm.memcpy.p0.p0.i64(ptr %t192, ptr %t190, i64 %t191, i1 false)
  %t193 = insertvalue { i64, ptr } undef, i64 %t189, 0
  %t194 = insertvalue { i64, ptr } %t193, ptr %t192, 1
  store { i64, ptr } %t194, ptr %l110
  %t195 = load { i64, ptr }, ptr %l110
  %t196 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportReachedTwice(ptr %s10, ptr %s10, { i64, ptr } %t195)
  store %"compiler/msgs:Msg" %t196, ptr %l111
  br label %bb46
bb46:
  %t197 = load ptr, ptr %l103
  %t198 = load { i64, [3 x i64] }, ptr %l107
  %t199 = load %"compiler/msgs:Msg", ptr %l111
  %t200 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s10, ptr %t197, { i64, [3 x i64] } %t198, %"compiler/msgs:Msg" %t199)
  store i64 %t200, ptr %l112
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s10)
  br label %bb49
bb48:
  call void @__olang_scope_close(ptr %s11)
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s9)
  br label %bb50
bb50:
  store %olang.scope zeroinitializer, ptr %s12
  %t201 = load i64, ptr %l19
  store i64 %t201, ptr %l115
  %t202 = load i64, ptr %l115
  %t203 = add i64 %t202, 1
  store i64 %t203, ptr %l116
  %t204 = load i64, ptr %l116
  store i64 %t204, ptr %l19
  call void @__olang_scope_close(ptr %s12)
  br label %bb37
bb51:
  %t205 = load i64, ptr %l16
  store i64 %t205, ptr %l117
  %t206 = load i64, ptr %l18
  store i64 %t206, ptr %l118
  %t207 = load i64, ptr %l117
  %t208 = load i64, ptr %l118
  %t209 = add i64 %t207, %t208
  store i64 %t209, ptr %l119
  %t210 = load i64, ptr %l119
  store i64 %t210, ptr %l16
  call void @__olang_scope_close(ptr %s8)
  br label %bb52
bb52:
  br label %bb30
bb53:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s5)
  br label %bb54
bb54:
  store %olang.scope zeroinitializer, ptr %s13
  %t211 = load i64, ptr %l13
  store i64 %t211, ptr %l120
  %t212 = load i64, ptr %l120
  %t213 = add i64 %t212, 1
  store i64 %t213, ptr %l121
  %t214 = load i64, ptr %l121
  store i64 %t214, ptr %l13
  call void @__olang_scope_close(ptr %s13)
  br label %bb21
bb55:
  %t215 = load i64, ptr %l10
  store i64 %t215, ptr %l122
  %t216 = load i64, ptr %l12
  store i64 %t216, ptr %l123
  %t217 = load i64, ptr %l122
  %t218 = load i64, ptr %l123
  %t219 = add i64 %t217, %t218
  store i64 %t219, ptr %l124
  %t220 = load i64, ptr %l124
  store i64 %t220, ptr %l10
  call void @__olang_scope_close(ptr %s4)
  br label %bb56
bb56:
  br label %bb14
bb57:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  br label %bb58
bb58:
  store %olang.scope zeroinitializer, ptr %s14
  %t221 = load i64, ptr %l5
  store i64 %t221, ptr %l125
  %t222 = load i64, ptr %l125
  %t223 = add i64 %t222, 1
  store i64 %t223, ptr %l126
  %t224 = load i64, ptr %l126
  store i64 %t224, ptr %l5
  call void @__olang_scope_close(ptr %s14)
  br label %bb8
bb59:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fload_2ecompiler_2fload_3aLoader_2eclosure(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"compiler/load:Import"
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca i1
  %l22 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca i64
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l32 = alloca ptr
  %l33 = alloca i64
  %l34 = alloca { i64, ptr }
  %l35 = alloca i32
  %l36 = alloca i32
  %l37 = alloca i1
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i1
  %l43 = alloca i1
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l46 = alloca %"compiler/load:Import"
  %l47 = alloca i64
  %l48 = alloca i1
  %l49 = alloca i1
  %l50 = alloca { i64, ptr }
  %l51 = alloca i1
  %l52 = alloca i1
  %l53 = alloca ptr
  %l54 = alloca ptr
  %l55 = alloca i64
  %l56 = alloca ptr
  %l57 = alloca ptr
  %l58 = alloca i1
  %l59 = alloca ptr
  %l60 = alloca ptr
  %l61 = alloca ptr
  %l62 = alloca ptr
  %l63 = alloca %"compiler/source:Span"
  %l64 = alloca { i64, [3 x i64] }
  %l65 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l68 = alloca %"compiler/msgs:Msg"
  %l69 = alloca i64
  %l70 = alloca ptr
  %l71 = alloca i64
  %l72 = alloca ptr
  %l73 = alloca ptr
  %l74 = alloca i64
  %l75 = alloca ptr
  %l76 = alloca ptr
  %l77 = alloca ptr
  %l78 = alloca { i64, ptr }
  %l79 = alloca ptr
  %l80 = alloca i64
  %l81 = alloca { i64, ptr }
  %l82 = alloca i32
  %l83 = alloca i32
  %l84 = alloca i1
  %l85 = alloca { i64, ptr }
  %l86 = alloca i64
  %l87 = alloca i64
  %l88 = alloca i64
  %l89 = alloca i1
  %l90 = alloca i1
  %l91 = alloca { i64, ptr }
  %l92 = alloca i64
  %l93 = alloca i64
  %l94 = alloca i64
  %l95 = alloca ptr
  %l96 = alloca ptr
  %l97 = alloca i64
  %l98 = alloca i1
  %l99 = alloca i1
  %l100 = alloca ptr
  %l101 = alloca ptr
  %l102 = alloca i64
  %l103 = alloca i64
  %l104 = alloca i64
  %l105 = alloca i64
  %l106 = alloca i64
  %l107 = alloca i64
  %l108 = alloca i64
  %l109 = alloca i64
  %l110 = alloca i64
  %l111 = alloca i64
  %l112 = alloca i64
  %l113 = alloca ptr
  %l114 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l16
  %t2 = load ptr, ptr %l16
  %t3 = getelementptr %"compiler/load:Loader", ptr %t2, i32 0, i32 5
  store ptr %t3, ptr %l17
  %t4 = load i64, ptr %l1
  store i64 %t4, ptr %l18
  %t5 = load ptr, ptr %l17
  %t6 = load i64, ptr %l18
  %t7 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t5, i64 %t6)
  store ptr %t7, ptr %l19
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l19
  store ptr %t8, ptr %l2
  %t9 = load ptr, ptr %l2
  store ptr %t9, ptr %l20
  %t10 = load ptr, ptr %l20
  %t11 = getelementptr %"compiler/load:Module", ptr %t10, i32 0, i32 24
  %t12 = load i1, ptr %t11
  store i1 %t12, ptr %l21
  %t13 = load i1, ptr %l21
  br i1 %t13, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l22
  br label %bb4
bb3:
  %t14 = load ptr, ptr %l2
  store ptr %t14, ptr %l23
  %t15 = load ptr, ptr %l23
  %t16 = getelementptr %"compiler/load:Module", ptr %t15, i32 0, i32 25
  %t17 = load i1, ptr %t16
  store i1 %t17, ptr %l24
  %t18 = load i1, ptr %l24
  store i1 %t18, ptr %l22
  br label %bb4
bb4:
  %t19 = load i1, ptr %l22
  br i1 %t19, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb6:
  br label %bb7
bb7:
  %t20 = load ptr, ptr %l2
  store ptr %t20, ptr %l25
  %t21 = load ptr, ptr %l25
  %t22 = getelementptr %"compiler/load:Module", ptr %t21, i32 0, i32 25
  store i1 true, ptr %t22
  %t23 = load ptr, ptr %l2
  store ptr %t23, ptr %l26
  %t24 = load ptr, ptr %l26
  %t25 = getelementptr %"compiler/load:Module", ptr %t24, i32 0, i32 26
  store ptr %t25, ptr %l27
  %t26 = load i64, ptr %l1
  store i64 %t26, ptr %l28
  %t27 = load ptr, ptr %l27
  %t28 = load i64, ptr %l28
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t27, i64 %t28)
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t29 = load ptr, ptr %l2
  store ptr %t29, ptr %l29
  %t30 = load ptr, ptr %l29
  %t31 = getelementptr %"compiler/load:Module", ptr %t30, i32 0, i32 9
  store ptr %t31, ptr %l30
  %t32 = load ptr, ptr %l30
  store ptr %t32, ptr %l3
  store i64 0, ptr %l4
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t33 = load ptr, ptr %l3
  store ptr %t33, ptr %l32
  %t34 = load i64, ptr %l4
  store i64 %t34, ptr %l33
  %t35 = load ptr, ptr %l32
  %t36 = load i64, ptr %l33
  %t37 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2eRunFrom_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %t35, i64 %t36)
  %t38 = extractvalue { i32, { i64, ptr } } %t37, 1
  %t39 = extractvalue { i32, { i64, ptr } } %t37, 0
  store i32 %t39, ptr %l35
  %t40 = icmp ne i32 %t39, 0
  br i1 %t40, label %bb11, label %ok.41
ok.41:
  store { i64, ptr } %t38, ptr %l34
  br label %bb10
bb10:
  %t42 = load { i64, ptr }, ptr %l34
  store { i64, ptr } %t42, ptr %l31
  br label %bb15
bb11:
  %t43 = load i32, ptr %l35
  %t44 = ashr i32 %t43, 16
  store i32 %t44, ptr %l36
  %t45 = load i32, ptr %l36
  %t46 = icmp eq i32 %t45, 1
  store i1 %t46, ptr %l37
  %t47 = load i1, ptr %l37
  br i1 %t47, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @.c47)
  unreachable
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb60
bb15:
  %t48 = load { i64, ptr }, ptr %l31
  store { i64, ptr } %t48, ptr %l5
  %t49 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t49, ptr %l38
  %t50 = load { i64, ptr }, ptr %l38
  %t51 = extractvalue { i64, ptr } %t50, 0
  store i64 %t51, ptr %l39
  %t52 = load i64, ptr %l39
  store i64 %t52, ptr %l6
  store i64 0, ptr %l7
  br label %bb16
bb16:
  store %olang.scope zeroinitializer, ptr %s4
  %t53 = load i64, ptr %l7
  store i64 %t53, ptr %l40
  %t54 = load i64, ptr %l6
  store i64 %t54, ptr %l41
  %t55 = load i64, ptr %l40
  %t56 = load i64, ptr %l41
  %t57 = icmp slt i64 %t55, %t56
  store i1 %t57, ptr %l42
  %t58 = load i1, ptr %l42
  %t59 = xor i1 %t58, true
  store i1 %t59, ptr %l43
  %t60 = load i1, ptr %l43
  br i1 %t60, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s4)
  br label %bb58
bb18:
  br label %bb19
bb19:
  %t61 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t61, ptr %l44
  %t62 = load i64, ptr %l7
  store i64 %t62, ptr %l45
  %t63 = load i64, ptr %l45
  %t64 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t65 = load ptr, ptr %t64
  %t66 = getelementptr %"compiler/load:Import", ptr %t65, i64 %t63
  %t67 = load %"compiler/load:Import", ptr %t66
  store %"compiler/load:Import" %t67, ptr %l46
  %t68 = load %"compiler/load:Import", ptr %l46
  store %"compiler/load:Import" %t68, ptr %l8
  %t69 = getelementptr %"compiler/load:Import", ptr %l8, i32 0, i32 5
  %t70 = load i64, ptr %t69
  store i64 %t70, ptr %l47
  %t71 = load i64, ptr %l47
  %t72 = icmp slt i64 %t71, 0
  store i1 %t72, ptr %l48
  %t73 = load i1, ptr %l48
  br i1 %t73, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l49
  br label %bb23
bb21:
  %t74 = getelementptr %"compiler/load:Import", ptr %l8, i32 0, i32 2
  %t75 = load { i64, ptr }, ptr %t74
  store { i64, ptr } %t75, ptr %l50
  %t76 = load { i64, ptr }, ptr %l50
  %t77 = call i1 @compiler_2fload_2ePublic(ptr %v0, { i64, ptr } %t76)
  store i1 %t77, ptr %l51
  br label %bb22
bb22:
  %t78 = load i1, ptr %l51
  %t79 = xor i1 %t78, true
  store i1 %t79, ptr %l52
  %t80 = load i1, ptr %l52
  store i1 %t80, ptr %l49
  br label %bb23
bb23:
  %t81 = load i1, ptr %l49
  br i1 %t81, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s5
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  br label %bb57
bb25:
  br label %bb26
bb26:
  %t82 = load ptr, ptr %l0
  store ptr %t82, ptr %l53
  %t83 = load ptr, ptr %l53
  %t84 = getelementptr %"compiler/load:Loader", ptr %t83, i32 0, i32 5
  store ptr %t84, ptr %l54
  %t85 = getelementptr %"compiler/load:Import", ptr %l8, i32 0, i32 5
  %t86 = load i64, ptr %t85
  store i64 %t86, ptr %l55
  %t87 = load ptr, ptr %l54
  %t88 = load i64, ptr %l55
  %t89 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t87, i64 %t88)
  store ptr %t89, ptr %l56
  br label %bb27
bb27:
  %t90 = load ptr, ptr %l56
  store ptr %t90, ptr %l57
  %t91 = load ptr, ptr %l57
  %t92 = getelementptr %"compiler/load:Module", ptr %t91, i32 0, i32 25
  %t93 = load i1, ptr %t92
  store i1 %t93, ptr %l58
  %t94 = load i1, ptr %l58
  br i1 %t94, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s6
  %t95 = load ptr, ptr %l0
  store ptr %t95, ptr %l59
  %t96 = load ptr, ptr %l59
  %t97 = getelementptr %"compiler/load:Loader", ptr %t96, i32 0, i32 4
  %t98 = load ptr, ptr %t97
  store ptr %t98, ptr %l60
  %t99 = load ptr, ptr %l0
  store ptr %t99, ptr %l61
  %t100 = load ptr, ptr %l2
  store ptr %t100, ptr %l62
  %t101 = getelementptr %"compiler/load:Import", ptr %l8, i32 0, i32 1
  %t102 = load %"compiler/source:Span", ptr %t101
  store %"compiler/source:Span" %t102, ptr %l63
  %t103 = load ptr, ptr %l61
  %t104 = load ptr, ptr %l62
  %t105 = load %"compiler/source:Span", ptr %l63
  %t106 = call { i64, [3 x i64] } @compiler_2fload_2ecompiler_2fload_3aLoader_2eat(ptr %v0, ptr %v0, ptr %t103, ptr %t104, %"compiler/source:Span" %t105)
  store { i64, [3 x i64] } %t106, ptr %l64
  br label %bb30
bb29:
  br label %bb34
bb30:
  %t107 = getelementptr %"compiler/load:Import", ptr %l8, i32 0, i32 2
  %t108 = load { i64, ptr }, ptr %t107
  store { i64, ptr } %t108, ptr %l65
  %t109 = load { i64, ptr }, ptr %l65
  %t110 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %s6, { i64, ptr } %t109)
  store { i64, ptr } %t110, ptr %l66
  br label %bb31
bb31:
  %t111 = load { i64, ptr }, ptr %l66
  %t112 = extractvalue { i64, ptr } %t111, 0
  %t113 = extractvalue { i64, ptr } %t111, 1
  %t114 = mul i64 %t112, 1
  %t115 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t114)
  call void @llvm.memcpy.p0.p0.i64(ptr %t115, ptr %t113, i64 %t114, i1 false)
  %t116 = insertvalue { i64, ptr } undef, i64 %t112, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr %t115, 1
  store { i64, ptr } %t117, ptr %l67
  %t118 = load { i64, ptr }, ptr %l67
  %t119 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReexportCycle(ptr %s6, ptr %s6, { i64, ptr } %t118)
  store %"compiler/msgs:Msg" %t119, ptr %l68
  br label %bb32
bb32:
  %t120 = load ptr, ptr %l60
  %t121 = load { i64, [3 x i64] }, ptr %l64
  %t122 = load %"compiler/msgs:Msg", ptr %l68
  %t123 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s6, ptr %t120, { i64, [3 x i64] } %t121, %"compiler/msgs:Msg" %t122)
  store i64 %t123, ptr %l69
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s4)
  br label %bb57
bb34:
  %t124 = load ptr, ptr %l0
  store ptr %t124, ptr %l70
  %t125 = getelementptr %"compiler/load:Import", ptr %l8, i32 0, i32 5
  %t126 = load i64, ptr %t125
  store i64 %t126, ptr %l71
  %t127 = load ptr, ptr %l70
  %t128 = load i64, ptr %l71
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2eclosure(ptr %v0, ptr %t127, i64 %t128)
  br label %bb35
bb35:
  store %olang.scope zeroinitializer, ptr %s7
  %t129 = load ptr, ptr %l0
  store ptr %t129, ptr %l72
  %t130 = load ptr, ptr %l72
  %t131 = getelementptr %"compiler/load:Loader", ptr %t130, i32 0, i32 5
  store ptr %t131, ptr %l73
  %t132 = getelementptr %"compiler/load:Import", ptr %l8, i32 0, i32 5
  %t133 = load i64, ptr %t132
  store i64 %t133, ptr %l74
  %t134 = load ptr, ptr %l73
  %t135 = load i64, ptr %l74
  %t136 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t134, i64 %t135)
  store ptr %t136, ptr %l75
  br label %bb36
bb36:
  %t137 = load ptr, ptr %l75
  store ptr %t137, ptr %l76
  %t138 = load ptr, ptr %l76
  %t139 = getelementptr %"compiler/load:Module", ptr %t138, i32 0, i32 26
  store ptr %t139, ptr %l77
  %t140 = load ptr, ptr %l77
  store ptr %t140, ptr %l9
  store i64 0, ptr %l10
  br label %bb37
bb37:
  store %olang.scope zeroinitializer, ptr %s8
  %t141 = load ptr, ptr %l9
  store ptr %t141, ptr %l79
  %t142 = load i64, ptr %l10
  store i64 %t142, ptr %l80
  %t143 = load ptr, ptr %l79
  %t144 = load i64, ptr %l80
  %t145 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %t143, i64 %t144)
  %t146 = extractvalue { i32, { i64, ptr } } %t145, 1
  %t147 = extractvalue { i32, { i64, ptr } } %t145, 0
  store i32 %t147, ptr %l82
  %t148 = icmp ne i32 %t147, 0
  br i1 %t148, label %bb39, label %ok.149
ok.149:
  store { i64, ptr } %t146, ptr %l81
  br label %bb38
bb38:
  %t150 = load { i64, ptr }, ptr %l81
  store { i64, ptr } %t150, ptr %l78
  br label %bb43
bb39:
  %t151 = load i32, ptr %l82
  %t152 = ashr i32 %t151, 16
  store i32 %t152, ptr %l83
  %t153 = load i32, ptr %l83
  %t154 = icmp eq i32 %t153, 1
  store i1 %t154, ptr %l84
  %t155 = load i1, ptr %l84
  br i1 %t155, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @.c48)
  unreachable
bb42:
  call void @__olang_scope_close(ptr %s8)
  br label %bb56
bb43:
  %t156 = load { i64, ptr }, ptr %l78
  store { i64, ptr } %t156, ptr %l11
  %t157 = load { i64, ptr }, ptr %l11
  store { i64, ptr } %t157, ptr %l85
  %t158 = load { i64, ptr }, ptr %l85
  %t159 = extractvalue { i64, ptr } %t158, 0
  store i64 %t159, ptr %l86
  %t160 = load i64, ptr %l86
  store i64 %t160, ptr %l12
  store i64 0, ptr %l13
  br label %bb44
bb44:
  store %olang.scope zeroinitializer, ptr %s9
  %t161 = load i64, ptr %l13
  store i64 %t161, ptr %l87
  %t162 = load i64, ptr %l12
  store i64 %t162, ptr %l88
  %t163 = load i64, ptr %l87
  %t164 = load i64, ptr %l88
  %t165 = icmp slt i64 %t163, %t164
  store i1 %t165, ptr %l89
  %t166 = load i1, ptr %l89
  %t167 = xor i1 %t166, true
  store i1 %t167, ptr %l90
  %t168 = load i1, ptr %l90
  br i1 %t168, label %bb45, label %bb46
bb45:
  call void @__olang_scope_close(ptr %s9)
  br label %bb54
bb46:
  br label %bb47
bb47:
  %t169 = load { i64, ptr }, ptr %l11
  store { i64, ptr } %t169, ptr %l91
  %t170 = load i64, ptr %l13
  store i64 %t170, ptr %l92
  %t171 = load i64, ptr %l92
  %t172 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t173 = load ptr, ptr %t172
  %t174 = getelementptr i64, ptr %t173, i64 %t171
  %t175 = load i64, ptr %t174
  store i64 %t175, ptr %l93
  %t176 = load i64, ptr %l93
  store i64 %t176, ptr %l14
  %t177 = load i64, ptr %l14
  store i64 %t177, ptr %l94
  %t178 = load i64, ptr %l94
  store i64 %t178, ptr %l15
  %t179 = load ptr, ptr %l2
  store ptr %t179, ptr %l95
  %t180 = load ptr, ptr %l95
  %t181 = getelementptr %"compiler/load:Module", ptr %t180, i32 0, i32 26
  store ptr %t181, ptr %l96
  %t182 = load i64, ptr %l15
  store i64 %t182, ptr %l97
  %t183 = load ptr, ptr %l96
  %t184 = load i64, ptr %l97
  %t185 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %t183, i64 %t184)
  store i1 %t185, ptr %l98
  br label %bb48
bb48:
  %t186 = load i1, ptr %l98
  %t187 = xor i1 %t186, true
  store i1 %t187, ptr %l99
  %t188 = load i1, ptr %l99
  br i1 %t188, label %bb49, label %bb50
bb49:
  store %olang.scope zeroinitializer, ptr %s10
  %t189 = load ptr, ptr %l2
  store ptr %t189, ptr %l100
  %t190 = load ptr, ptr %l100
  %t191 = getelementptr %"compiler/load:Module", ptr %t190, i32 0, i32 26
  store ptr %t191, ptr %l101
  %t192 = load i64, ptr %l14
  store i64 %t192, ptr %l102
  %t193 = load ptr, ptr %l101
  %t194 = load i64, ptr %l102
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t193, i64 %t194)
  br label %bb51
bb50:
  br label %bb52
bb51:
  call void @__olang_scope_close(ptr %s10)
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s9)
  br label %bb53
bb53:
  store %olang.scope zeroinitializer, ptr %s11
  %t195 = load i64, ptr %l13
  store i64 %t195, ptr %l103
  %t196 = load i64, ptr %l103
  %t197 = add i64 %t196, 1
  store i64 %t197, ptr %l104
  %t198 = load i64, ptr %l104
  store i64 %t198, ptr %l13
  call void @__olang_scope_close(ptr %s11)
  br label %bb44
bb54:
  %t199 = load i64, ptr %l10
  store i64 %t199, ptr %l105
  %t200 = load i64, ptr %l12
  store i64 %t200, ptr %l106
  %t201 = load i64, ptr %l105
  %t202 = load i64, ptr %l106
  %t203 = add i64 %t201, %t202
  store i64 %t203, ptr %l107
  %t204 = load i64, ptr %l107
  store i64 %t204, ptr %l10
  call void @__olang_scope_close(ptr %s8)
  br label %bb55
bb55:
  br label %bb37
bb56:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s4)
  br label %bb57
bb57:
  store %olang.scope zeroinitializer, ptr %s12
  %t205 = load i64, ptr %l7
  store i64 %t205, ptr %l108
  %t206 = load i64, ptr %l108
  %t207 = add i64 %t206, 1
  store i64 %t207, ptr %l109
  %t208 = load i64, ptr %l109
  store i64 %t208, ptr %l7
  call void @__olang_scope_close(ptr %s12)
  br label %bb16
bb58:
  %t209 = load i64, ptr %l4
  store i64 %t209, ptr %l110
  %t210 = load i64, ptr %l6
  store i64 %t210, ptr %l111
  %t211 = load i64, ptr %l110
  %t212 = load i64, ptr %l111
  %t213 = add i64 %t211, %t212
  store i64 %t213, ptr %l112
  %t214 = load i64, ptr %l112
  store i64 %t214, ptr %l4
  call void @__olang_scope_close(ptr %s3)
  br label %bb59
bb59:
  br label %bb9
bb60:
  call void @__olang_scope_close(ptr %s2)
  %t215 = load ptr, ptr %l2
  store ptr %t215, ptr %l113
  %t216 = load ptr, ptr %l113
  %t217 = getelementptr %"compiler/load:Module", ptr %t216, i32 0, i32 25
  store i1 false, ptr %t217
  %t218 = load ptr, ptr %l2
  store ptr %t218, ptr %l114
  %t219 = load ptr, ptr %l114
  %t220 = getelementptr %"compiler/load:Module", ptr %t219, i32 0, i32 24
  store i1 true, ptr %t220
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2econdEnd(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i1
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i1
  %l17 = alloca i1
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i32
  %l21 = alloca i32
  %l22 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca ptr
  %l25 = alloca i1
  %l26 = alloca i1
  %l27 = alloca i32
  %l28 = alloca ptr
  %l29 = alloca i32
  %l30 = alloca ptr
  %l31 = alloca i1
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i32
  %l35 = alloca ptr
  %l36 = alloca i32
  %l37 = alloca ptr
  %l38 = alloca i1
  %l39 = alloca i1
  %l40 = alloca i32
  %l41 = alloca ptr
  %l42 = alloca i32
  %l43 = alloca ptr
  %l44 = alloca i1
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i32
  %l48 = alloca ptr
  %l49 = alloca i32
  %l50 = alloca ptr
  %l51 = alloca i1
  %l52 = alloca i1
  %l53 = alloca i32
  %l54 = alloca ptr
  %l55 = alloca i32
  %l56 = alloca ptr
  %l57 = alloca i1
  %l58 = alloca i1
  %l59 = alloca i32
  %l60 = alloca ptr
  %l61 = alloca i32
  %l62 = alloca ptr
  %l63 = alloca i1
  %l64 = alloca i32
  %l65 = alloca ptr
  %l66 = alloca i32
  %l67 = alloca ptr
  %l68 = alloca i1
  %l69 = alloca i64
  %l70 = alloca i1
  %l71 = alloca i1
  %l72 = alloca i1
  %l73 = alloca i1
  %l74 = alloca i64
  %l75 = alloca ptr
  %l76 = alloca ptr
  %l77 = alloca i64
  %l78 = alloca i32
  %l79 = alloca i32
  %l80 = alloca i64
  %l81 = alloca i64
  %l82 = alloca i1
  %l83 = alloca i64
  %l84 = alloca i64
  %l85 = alloca i64
  %l86 = alloca i64
  %l87 = alloca i1
  %l88 = alloca i1
  %l89 = alloca i32
  %l90 = alloca ptr
  %l91 = alloca i32
  %l92 = alloca ptr
  %l93 = alloca i1
  %l94 = alloca i1
  %l95 = alloca i32
  %l96 = alloca ptr
  %l97 = alloca i32
  %l98 = alloca ptr
  %l99 = alloca i1
  %l100 = alloca i64
  %l101 = alloca i64
  %l102 = alloca i64
  %l103 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1
  store ptr %t1, ptr %l10
  %t2 = load ptr, ptr %l10
  %t3 = getelementptr %"compiler/load:Module", ptr %t2, i32 0, i32 6
  %t4 = load ptr, ptr %t3
  store ptr %t4, ptr %l11
  %t5 = load ptr, ptr %l11
  %t6 = getelementptr %"compiler/scan:Tokens", ptr %t5, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6
  store { i64, ptr } %t7, ptr %l12
  %t8 = load { i64, ptr }, ptr %l12
  store { i64, ptr } %t8, ptr %l4
  store i64 0, ptr %l5
  store i1 false, ptr %l6
  %t9 = load i64, ptr %l2
  store i64 %t9, ptr %l13
  %t10 = load i64, ptr %l13
  store i64 %t10, ptr %l7
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = load i64, ptr %l7
  store i64 %t11, ptr %l14
  %t12 = load i64, ptr %l3
  store i64 %t12, ptr %l15
  %t13 = load i64, ptr %l14
  %t14 = load i64, ptr %l15
  %t15 = icmp slt i64 %t13, %t14
  store i1 %t15, ptr %l16
  %t16 = load i1, ptr %l16
  %t17 = xor i1 %t16, true
  store i1 %t17, ptr %l17
  %t18 = load i1, ptr %l17
  br i1 %t18, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s1)
  br label %bb59
bb3:
  br label %bb4
bb4:
  %t19 = load { i64, ptr }, ptr %l4
  store { i64, ptr } %t19, ptr %l18
  %t20 = load i64, ptr %l7
  store i64 %t20, ptr %l19
  %t21 = load i64, ptr %l19
  %t22 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t23 = load ptr, ptr %t22
  %t24 = getelementptr %"compiler/token:Token", ptr %t23, i64 %t21
  %t25 = getelementptr %"compiler/token:Token", ptr %t24, i32 0, i32 0
  %t26 = load i32, ptr %t25
  store i32 %t26, ptr %l20
  %t27 = load i32, ptr %l20
  store i32 %t27, ptr %l8
  %t28 = load i32, ptr %l8
  store i32 %t28, ptr %l21
  store ptr %l21, ptr %l22
  store i32 90, ptr %l23
  store ptr %l23, ptr %l24
  %t29 = load ptr, ptr %l22
  %t30 = load ptr, ptr %l24
  %t31 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t29, ptr %t30)
  store i1 %t31, ptr %l25
  br label %bb5
bb5:
  %t32 = load i1, ptr %l25
  br i1 %t32, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l26
  br label %bb9
bb7:
  %t33 = load i32, ptr %l8
  store i32 %t33, ptr %l27
  store ptr %l27, ptr %l28
  store i32 92, ptr %l29
  store ptr %l29, ptr %l30
  %t34 = load ptr, ptr %l28
  %t35 = load ptr, ptr %l30
  %t36 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t34, ptr %t35)
  store i1 %t36, ptr %l31
  br label %bb8
bb8:
  %t37 = load i1, ptr %l31
  store i1 %t37, ptr %l26
  br label %bb9
bb9:
  %t38 = load i1, ptr %l26
  br i1 %t38, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t39 = load i64, ptr %l5
  store i64 %t39, ptr %l32
  %t40 = load i64, ptr %l32
  %t41 = add i64 %t40, 1
  store i64 %t41, ptr %l33
  %t42 = load i64, ptr %l33
  store i64 %t42, ptr %l5
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t43 = load i32, ptr %l8
  store i32 %t43, ptr %l34
  store ptr %l34, ptr %l35
  store i32 91, ptr %l36
  store ptr %l36, ptr %l37
  %t44 = load ptr, ptr %l35
  %t45 = load ptr, ptr %l37
  %t46 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t44, ptr %t45)
  store i1 %t46, ptr %l38
  br label %bb13
bb13:
  %t47 = load i1, ptr %l38
  br i1 %t47, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l39
  br label %bb17
bb15:
  %t48 = load i32, ptr %l8
  store i32 %t48, ptr %l40
  store ptr %l40, ptr %l41
  store i32 93, ptr %l42
  store ptr %l42, ptr %l43
  %t49 = load ptr, ptr %l41
  %t50 = load ptr, ptr %l43
  %t51 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t49, ptr %t50)
  store i1 %t51, ptr %l44
  br label %bb16
bb16:
  %t52 = load i1, ptr %l44
  store i1 %t52, ptr %l39
  br label %bb17
bb17:
  %t53 = load i1, ptr %l39
  br i1 %t53, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s3
  %t54 = load i64, ptr %l5
  store i64 %t54, ptr %l45
  %t55 = load i64, ptr %l45
  %t56 = sub i64 %t55, 1
  store i64 %t56, ptr %l46
  %t57 = load i64, ptr %l46
  store i64 %t57, ptr %l5
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb19:
  br label %bb20
bb20:
  %t58 = load i32, ptr %l8
  store i32 %t58, ptr %l47
  store ptr %l47, ptr %l48
  store i32 30, ptr %l49
  store ptr %l49, ptr %l50
  %t59 = load ptr, ptr %l48
  %t60 = load ptr, ptr %l50
  %t61 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t59, ptr %t60)
  store i1 %t61, ptr %l51
  br label %bb21
bb21:
  %t62 = load i1, ptr %l51
  br i1 %t62, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l52
  br label %bb25
bb23:
  %t63 = load i32, ptr %l8
  store i32 %t63, ptr %l53
  store ptr %l53, ptr %l54
  store i32 37, ptr %l55
  store ptr %l55, ptr %l56
  %t64 = load ptr, ptr %l54
  %t65 = load ptr, ptr %l56
  %t66 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t64, ptr %t65)
  store i1 %t66, ptr %l57
  br label %bb24
bb24:
  %t67 = load i1, ptr %l57
  store i1 %t67, ptr %l52
  br label %bb25
bb25:
  %t68 = load i1, ptr %l52
  br i1 %t68, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l58
  br label %bb29
bb27:
  %t69 = load i32, ptr %l8
  store i32 %t69, ptr %l59
  store ptr %l59, ptr %l60
  store i32 13, ptr %l61
  store ptr %l61, ptr %l62
  %t70 = load ptr, ptr %l60
  %t71 = load ptr, ptr %l62
  %t72 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t70, ptr %t71)
  store i1 %t72, ptr %l63
  br label %bb28
bb28:
  %t73 = load i1, ptr %l63
  store i1 %t73, ptr %l58
  br label %bb29
bb29:
  %t74 = load i1, ptr %l58
  br i1 %t74, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s4
  store i1 true, ptr %l6
  call void @__olang_scope_close(ptr %s4)
  br label %bb32
bb31:
  br label %bb32
bb32:
  %t75 = load i32, ptr %l8
  store i32 %t75, ptr %l64
  store ptr %l64, ptr %l65
  store i32 94, ptr %l66
  store ptr %l66, ptr %l67
  %t76 = load ptr, ptr %l65
  %t77 = load ptr, ptr %l67
  %t78 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t76, ptr %t77)
  store i1 %t78, ptr %l68
  br label %bb33
bb33:
  %t79 = load i1, ptr %l68
  br i1 %t79, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s5
  %t80 = load i64, ptr %l5
  store i64 %t80, ptr %l69
  %t81 = load i64, ptr %l69
  %t82 = icmp eq i64 %t81, 0
  store i1 %t82, ptr %l70
  %t83 = load i1, ptr %l70
  br i1 %t83, label %bb36, label %bb37
bb35:
  br label %bb46
bb36:
  %t84 = load i1, ptr %l6
  store i1 %t84, ptr %l72
  %t85 = load i1, ptr %l72
  %t86 = xor i1 %t85, true
  store i1 %t86, ptr %l73
  %t87 = load i1, ptr %l73
  store i1 %t87, ptr %l71
  br label %bb38
bb37:
  store i1 false, ptr %l71
  br label %bb38
bb38:
  %t88 = load i1, ptr %l71
  br i1 %t88, label %bb39, label %bb40
bb39:
  store %olang.scope zeroinitializer, ptr %s6
  %t89 = load i64, ptr %l7
  store i64 %t89, ptr %l74
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t90 = load i64, ptr %l74
  store i64 %t90, ptr %rv
  br label %ret
bb40:
  br label %bb41
bb41:
  %t91 = load ptr, ptr %l1
  store ptr %t91, ptr %l75
  %t92 = load ptr, ptr %l75
  %t93 = getelementptr %"compiler/load:Module", ptr %t92, i32 0, i32 6
  %t94 = load ptr, ptr %t93
  store ptr %t94, ptr %l76
  %t95 = load i64, ptr %l7
  store i64 %t95, ptr %l77
  %t96 = load i64, ptr %l77
  %t97 = trunc i64 %t96 to i32
  store i32 %t97, ptr %l78
  %t98 = load ptr, ptr %l76
  %t99 = load i32, ptr %l78
  %t100 = call i32 @compiler_2fscan_2ecompiler_2fscan_3aTokens_2eMatch(ptr %v1, ptr %t98, i32 %t99)
  store i32 %t100, ptr %l79
  br label %bb42
bb42:
  %t101 = load i32, ptr %l79
  %t102 = sext i32 %t101 to i64
  store i64 %t102, ptr %l80
  %t103 = load i64, ptr %l80
  store i64 %t103, ptr %l9
  %t104 = load i64, ptr %l9
  store i64 %t104, ptr %l81
  %t105 = load i64, ptr %l81
  %t106 = icmp slt i64 %t105, 0
  store i1 %t106, ptr %l82
  %t107 = load i1, ptr %l82
  br i1 %t107, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s7
  store i64 -1, ptr %l83
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t108 = load i64, ptr %l83
  store i64 %t108, ptr %rv
  br label %ret
bb44:
  br label %bb45
bb45:
  store i1 false, ptr %l6
  %t109 = load i64, ptr %l9
  store i64 %t109, ptr %l84
  %t110 = load i64, ptr %l84
  %t111 = add i64 %t110, 1
  store i64 %t111, ptr %l85
  %t112 = load i64, ptr %l85
  store i64 %t112, ptr %l7
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s1)
  br label %bb58
bb46:
  %t113 = load i64, ptr %l5
  store i64 %t113, ptr %l86
  %t114 = load i64, ptr %l86
  %t115 = icmp sle i64 %t114, 0
  store i1 %t115, ptr %l87
  %t116 = load i1, ptr %l87
  br i1 %t116, label %bb47, label %bb48
bb47:
  %t117 = load i32, ptr %l8
  store i32 %t117, ptr %l89
  store ptr %l89, ptr %l90
  store i32 8, ptr %l91
  store ptr %l91, ptr %l92
  %t118 = load ptr, ptr %l90
  %t119 = load ptr, ptr %l92
  %t120 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t118, ptr %t119)
  store i1 %t120, ptr %l93
  br label %bb49
bb48:
  store i1 false, ptr %l88
  br label %bb54
bb49:
  %t121 = load i1, ptr %l93
  br i1 %t121, label %bb50, label %bb51
bb50:
  store i1 true, ptr %l94
  br label %bb53
bb51:
  %t122 = load i32, ptr %l8
  store i32 %t122, ptr %l95
  store ptr %l95, ptr %l96
  store i32 0, ptr %l97
  store ptr %l97, ptr %l98
  %t123 = load ptr, ptr %l96
  %t124 = load ptr, ptr %l98
  %t125 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t123, ptr %t124)
  store i1 %t125, ptr %l99
  br label %bb52
bb52:
  %t126 = load i1, ptr %l99
  store i1 %t126, ptr %l94
  br label %bb53
bb53:
  %t127 = load i1, ptr %l94
  store i1 %t127, ptr %l88
  br label %bb54
bb54:
  %t128 = load i1, ptr %l88
  br i1 %t128, label %bb55, label %bb56
bb55:
  store %olang.scope zeroinitializer, ptr %s8
  store i64 -1, ptr %l100
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t129 = load i64, ptr %l100
  store i64 %t129, ptr %rv
  br label %ret
bb56:
  br label %bb57
bb57:
  %t130 = load i64, ptr %l7
  store i64 %t130, ptr %l101
  %t131 = load i64, ptr %l101
  %t132 = add i64 %t131, 1
  store i64 %t132, ptr %l102
  %t133 = load i64, ptr %l102
  store i64 %t133, ptr %l7
  call void @__olang_scope_close(ptr %s1)
  br label %bb58
bb58:
  br label %bb1
bb59:
  store i64 -1, ptr %l103
  call void @__olang_scope_close(ptr %s0)
  %t134 = load i64, ptr %l103
  store i64 %t134, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fload_2ecompiler_2fload_3aLoader_2edecide(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca { i32, i1 }
  %l14 = alloca i32
  %l15 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca ptr
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca ptr
  %l46 = alloca ptr
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca ptr
  %l52 = alloca ptr
  %l53 = alloca i64
  %l54 = alloca i1
  %l55 = alloca i64
  %l56 = alloca ptr
  %l57 = alloca ptr
  %l58 = alloca i64
  %l59 = alloca ptr
  %l60 = alloca ptr
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca i64
  %l68 = alloca i1
  %l69 = alloca i64
  %l70 = alloca i64
  %l71 = alloca i1
  %l72 = alloca i64
  %l73 = alloca i64
  %l74 = alloca i64
  %l75 = alloca i64
  %l76 = alloca i64
  %l77 = alloca i64
  %l78 = alloca i64
  %l79 = alloca i64
  %l80 = alloca i64
  %l81 = alloca i64
  %l82 = alloca i64
  %l83 = alloca i1
  %l84 = alloca i1
  %l85 = alloca i64
  %l86 = alloca i64
  %l87 = alloca i64
  %l88 = alloca i64
  %l89 = alloca i64
  %l90 = alloca ptr
  %l91 = alloca i64
  %l92 = alloca ptr
  %l93 = alloca ptr
  %l94 = alloca i64
  %l95 = alloca i64
  %l96 = alloca { i32, i1 }
  %l97 = alloca i32
  %l98 = alloca i1
  %l99 = alloca i32
  %l100 = alloca ptr
  %l101 = alloca i32
  %l102 = alloca ptr
  %l103 = alloca i1
  %l104 = alloca ptr
  %l105 = alloca ptr
  %l106 = alloca i64
  %l107 = alloca i64
  %l108 = alloca i32
  %l109 = alloca ptr
  %l110 = alloca i32
  %l111 = alloca ptr
  %l112 = alloca i1
  %l113 = alloca i1
  %l114 = alloca i1
  %l115 = alloca ptr
  %l116 = alloca ptr
  %l117 = alloca i64
  %l118 = alloca i64
  %l119 = alloca i64
  %l120 = alloca i64
  %l121 = alloca i64
  %l122 = alloca i64
  %l123 = alloca ptr
  %l124 = alloca ptr
  %l125 = alloca i64
  %l126 = alloca ptr
  %l127 = alloca ptr
  %l128 = alloca i64
  %l129 = alloca i1
  %l130 = alloca i64
  %l131 = alloca i64
  %l132 = alloca i64
  %l133 = alloca i64
  %l134 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l16
  %t2 = load ptr, ptr %l16
  %t3 = getelementptr %"compiler/load:Loader", ptr %t2, i32 0, i32 5
  store ptr %t3, ptr %l17
  %t4 = load i64, ptr %l1
  store i64 %t4, ptr %l18
  %t5 = load ptr, ptr %l17
  %t6 = load i64, ptr %l18
  %t7 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t5, i64 %t6)
  store ptr %t7, ptr %l19
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l19
  store ptr %t8, ptr %l3
  %t9 = load ptr, ptr %l3
  store ptr %t9, ptr %l20
  %t10 = load ptr, ptr %l20
  %t11 = getelementptr %"compiler/load:Module", ptr %t10, i32 0, i32 14
  store ptr %t11, ptr %l21
  %t12 = load i64, ptr %l2
  store i64 %t12, ptr %l22
  %t13 = load ptr, ptr %l21
  %t14 = load i64, ptr %l22
  %t15 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t13, i64 %t14)
  store i64 %t15, ptr %l23
  br label %bb2
bb2:
  %t16 = load i64, ptr @G_2ecompiler_2fload_2eNotYet
  store i64 %t16, ptr %l24
  %t17 = load i64, ptr %l23
  %t18 = load i64, ptr %l24
  %t19 = icmp ne i64 %t17, %t18
  store i1 %t19, ptr %l25
  %t20 = load i1, ptr %l25
  br i1 %t20, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb4:
  br label %bb5
bb5:
  %t21 = load ptr, ptr %l0
  store ptr %t21, ptr %l26
  %t22 = load i64, ptr %l1
  store i64 %t22, ptr %l27
  %t23 = load ptr, ptr %l3
  store ptr %t23, ptr %l28
  %t24 = load ptr, ptr %l28
  %t25 = getelementptr %"compiler/load:Module", ptr %t24, i32 0, i32 13
  store ptr %t25, ptr %l29
  %t26 = load i64, ptr %l2
  store i64 %t26, ptr %l30
  %t27 = load ptr, ptr %l29
  %t28 = load i64, ptr %l30
  %t29 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t27, i64 %t28)
  store i64 %t29, ptr %l31
  br label %bb6
bb6:
  %t30 = load ptr, ptr %l26
  %t31 = load i64, ptr %l27
  %t32 = load i64, ptr %l31
  %t33 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2etaken(ptr %v0, ptr %t30, i64 %t31, i64 %t32)
  store i64 %t33, ptr %l32
  br label %bb7
bb7:
  %t34 = load i64, ptr %l32
  store i64 %t34, ptr %l4
  %t35 = load i64, ptr %l4
  store i64 %t35, ptr %l33
  %t36 = load i64, ptr %l33
  %t37 = icmp eq i64 %t36, 0
  store i1 %t37, ptr %l34
  %t38 = load i1, ptr %l34
  br i1 %t38, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t39 = load ptr, ptr %l3
  store ptr %t39, ptr %l35
  %t40 = load ptr, ptr %l35
  %t41 = getelementptr %"compiler/load:Module", ptr %t40, i32 0, i32 14
  store ptr %t41, ptr %l36
  %t42 = load i64, ptr %l2
  store i64 %t42, ptr %l37
  %t43 = load i64, ptr @G_2ecompiler_2fload_2eNoBranch
  store i64 %t43, ptr %l38
  %t44 = load ptr, ptr %l36
  %t45 = load i64, ptr %l37
  %t46 = load i64, ptr %l38
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t44, i64 %t45, i64 %t46)
  br label %bb10
bb9:
  br label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb11:
  %t47 = load i64, ptr %l4
  store i64 %t47, ptr %l39
  %t48 = load i64, ptr %l39
  %t49 = icmp slt i64 %t48, 0
  store i1 %t49, ptr %l40
  %t50 = load i1, ptr %l40
  br i1 %t50, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t51 = load ptr, ptr %l3
  store ptr %t51, ptr %l41
  %t52 = load ptr, ptr %l41
  %t53 = getelementptr %"compiler/load:Module", ptr %t52, i32 0, i32 14
  store ptr %t53, ptr %l42
  %t54 = load i64, ptr %l2
  store i64 %t54, ptr %l43
  %t55 = load i64, ptr @G_2ecompiler_2fload_2ePending
  store i64 %t55, ptr %l44
  %t56 = load ptr, ptr %l42
  %t57 = load i64, ptr %l43
  %t58 = load i64, ptr %l44
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t56, i64 %t57, i64 %t58)
  br label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb15:
  %t59 = load ptr, ptr %l3
  store ptr %t59, ptr %l45
  %t60 = load ptr, ptr %l45
  %t61 = getelementptr %"compiler/load:Module", ptr %t60, i32 0, i32 16
  store ptr %t61, ptr %l46
  %t62 = load i64, ptr %l2
  store i64 %t62, ptr %l47
  %t63 = load ptr, ptr %l46
  %t64 = load i64, ptr %l47
  %t65 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t63, i64 %t64)
  store i64 %t65, ptr %l48
  br label %bb16
bb16:
  %t66 = load i64, ptr %l48
  store i64 %t66, ptr %l5
  %t67 = load i64, ptr %l2
  store i64 %t67, ptr %l49
  %t68 = load i64, ptr %l49
  %t69 = add i64 %t68, 1
  store i64 %t69, ptr %l50
  %t70 = load ptr, ptr %l3
  store ptr %t70, ptr %l51
  %t71 = load ptr, ptr %l51
  %t72 = getelementptr %"compiler/load:Module", ptr %t71, i32 0, i32 16
  store ptr %t72, ptr %l52
  %t73 = load ptr, ptr %l52
  %t74 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t73)
  store i64 %t74, ptr %l53
  br label %bb17
bb17:
  %t75 = load i64, ptr %l50
  %t76 = load i64, ptr %l53
  %t77 = icmp eq i64 %t75, %t76
  store i1 %t77, ptr %l54
  %t78 = load i1, ptr %l54
  br i1 %t78, label %bb18, label %bb19
bb18:
  %t79 = load ptr, ptr %l3
  store ptr %t79, ptr %l56
  %t80 = load ptr, ptr %l56
  %t81 = getelementptr %"compiler/load:Module", ptr %t80, i32 0, i32 17
  store ptr %t81, ptr %l57
  %t82 = load ptr, ptr %l57
  %t83 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t82)
  store i64 %t83, ptr %l58
  br label %bb20
bb19:
  %t84 = load ptr, ptr %l3
  store ptr %t84, ptr %l59
  %t85 = load ptr, ptr %l59
  %t86 = getelementptr %"compiler/load:Module", ptr %t85, i32 0, i32 16
  store ptr %t86, ptr %l60
  %t87 = load i64, ptr %l2
  store i64 %t87, ptr %l61
  %t88 = load i64, ptr %l61
  %t89 = add i64 %t88, 1
  store i64 %t89, ptr %l62
  %t90 = load ptr, ptr %l60
  %t91 = load i64, ptr %l62
  %t92 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t90, i64 %t91)
  store i64 %t92, ptr %l63
  br label %bb21
bb20:
  %t93 = load i64, ptr %l58
  store i64 %t93, ptr %l55
  br label %bb22
bb21:
  %t94 = load i64, ptr %l63
  store i64 %t94, ptr %l55
  br label %bb22
bb22:
  %t95 = load i64, ptr %l55
  store i64 %t95, ptr %l6
  store %olang.scope zeroinitializer, ptr %s4
  %t96 = load i64, ptr %l5
  store i64 %t96, ptr %l64
  %t97 = load i64, ptr %l64
  store i64 %t97, ptr %l7
  %t98 = load i64, ptr %l6
  store i64 %t98, ptr %l65
  %t99 = load i64, ptr %l65
  store i64 %t99, ptr %l8
  store i64 1, ptr %l9
  %t100 = load i64, ptr %l8
  store i64 %t100, ptr %l66
  %t101 = load i64, ptr %l7
  store i64 %t101, ptr %l67
  %t102 = load i64, ptr %l66
  %t103 = load i64, ptr %l67
  %t104 = icmp sgt i64 %t102, %t103
  store i1 %t104, ptr %l68
  %t105 = load i1, ptr %l68
  br i1 %t105, label %bb23, label %bb24
bb23:
  %t106 = load i64, ptr %l9
  store i64 %t106, ptr %l70
  %t107 = load i64, ptr %l70
  %t108 = icmp sgt i64 %t107, 0
  store i1 %t108, ptr %l71
  %t109 = load i1, ptr %l71
  br i1 %t109, label %bb25, label %bb26
bb24:
  store i64 0, ptr %l69
  br label %bb28
bb25:
  %t110 = load i64, ptr %l8
  store i64 %t110, ptr %l73
  %t111 = load i64, ptr %l7
  store i64 %t111, ptr %l74
  %t112 = load i64, ptr %l73
  %t113 = load i64, ptr %l74
  %t114 = sub i64 %t112, %t113
  store i64 %t114, ptr %l75
  %t115 = load i64, ptr %l9
  store i64 %t115, ptr %l76
  %t116 = load i64, ptr %l75
  %t117 = load i64, ptr %l76
  %t118 = add i64 %t116, %t117
  store i64 %t118, ptr %l77
  %t119 = load i64, ptr %l77
  %t120 = sub i64 %t119, 1
  store i64 %t120, ptr %l78
  %t121 = load i64, ptr %l9
  store i64 %t121, ptr %l79
  %t122 = load i64, ptr %l78
  %t123 = load i64, ptr %l79
  %t124 = sdiv i64 %t122, %t123
  store i64 %t124, ptr %l80
  %t125 = load i64, ptr %l80
  store i64 %t125, ptr %l72
  br label %bb27
bb26:
  store i64 0, ptr %l72
  br label %bb27
bb27:
  %t126 = load i64, ptr %l72
  store i64 %t126, ptr %l69
  br label %bb28
bb28:
  %t127 = load i64, ptr %l69
  store i64 %t127, ptr %l10
  store i64 0, ptr %l11
  br label %bb29
bb29:
  store %olang.scope zeroinitializer, ptr %s5
  %t128 = load i64, ptr %l11
  store i64 %t128, ptr %l81
  %t129 = load i64, ptr %l10
  store i64 %t129, ptr %l82
  %t130 = load i64, ptr %l81
  %t131 = load i64, ptr %l82
  %t132 = icmp slt i64 %t130, %t131
  store i1 %t132, ptr %l83
  %t133 = load i1, ptr %l83
  %t134 = xor i1 %t133, true
  store i1 %t134, ptr %l84
  %t135 = load i1, ptr %l84
  br i1 %t135, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s5)
  br label %bb49
bb31:
  br label %bb32
bb32:
  %t136 = load i64, ptr %l7
  store i64 %t136, ptr %l85
  %t137 = load i64, ptr %l11
  store i64 %t137, ptr %l86
  %t138 = load i64, ptr %l9
  store i64 %t138, ptr %l87
  %t139 = load i64, ptr %l86
  %t140 = load i64, ptr %l87
  %t141 = mul i64 %t139, %t140
  store i64 %t141, ptr %l88
  %t142 = load i64, ptr %l85
  %t143 = load i64, ptr %l88
  %t144 = add i64 %t142, %t143
  store i64 %t144, ptr %l89
  %t145 = load i64, ptr %l89
  store i64 %t145, ptr %l12
  %t146 = load ptr, ptr %l0
  store ptr %t146, ptr %l90
  %t147 = load i64, ptr %l1
  store i64 %t147, ptr %l91
  %t148 = load ptr, ptr %l3
  store ptr %t148, ptr %l92
  %t149 = load ptr, ptr %l92
  %t150 = getelementptr %"compiler/load:Module", ptr %t149, i32 0, i32 17
  store ptr %t150, ptr %l93
  %t151 = load i64, ptr %l12
  store i64 %t151, ptr %l94
  %t152 = load ptr, ptr %l93
  %t153 = load i64, ptr %l94
  %t154 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t152, i64 %t153)
  store i64 %t154, ptr %l95
  br label %bb33
bb33:
  %t155 = load ptr, ptr %l90
  %t156 = load i64, ptr %l91
  %t157 = load i64, ptr %l95
  %t158 = call { i32, i1 } @compiler_2fload_2ecompiler_2fload_3aLoader_2eevalCond(ptr %v0, ptr %t155, i64 %t156, i64 %t157)
  store { i32, i1 } %t158, ptr %l96
  br label %bb34
bb34:
  %t159 = load { i32, i1 }, ptr %l96
  store { i32, i1 } %t159, ptr %l13
  %t160 = getelementptr { i32, i1 }, ptr %l13, i32 0, i32 0
  %t161 = load i32, ptr %t160
  store i32 %t161, ptr %l97
  %t162 = load i32, ptr %l97
  store i32 %t162, ptr %l14
  %t163 = getelementptr { i32, i1 }, ptr %l13, i32 0, i32 1
  %t164 = load i1, ptr %t163
  store i1 %t164, ptr %l98
  %t165 = load i1, ptr %l98
  store i1 %t165, ptr %l15
  %t166 = load i32, ptr %l14
  store i32 %t166, ptr %l99
  store ptr %l99, ptr %l100
  store i32 1, ptr %l101
  store ptr %l101, ptr %l102
  %t167 = load ptr, ptr %l100
  %t168 = load ptr, ptr %l102
  %t169 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aOutcome(ptr %t167, ptr %t168)
  store i1 %t169, ptr %l103
  br label %bb35
bb35:
  %t170 = load i1, ptr %l103
  br i1 %t170, label %bb36, label %bb37
bb36:
  store %olang.scope zeroinitializer, ptr %s6
  %t171 = load ptr, ptr %l3
  store ptr %t171, ptr %l104
  %t172 = load ptr, ptr %l104
  %t173 = getelementptr %"compiler/load:Module", ptr %t172, i32 0, i32 14
  store ptr %t173, ptr %l105
  %t174 = load i64, ptr %l2
  store i64 %t174, ptr %l106
  %t175 = load i64, ptr @G_2ecompiler_2fload_2ePending
  store i64 %t175, ptr %l107
  %t176 = load ptr, ptr %l105
  %t177 = load i64, ptr %l106
  %t178 = load i64, ptr %l107
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t176, i64 %t177, i64 %t178)
  br label %bb38
bb37:
  br label %bb39
bb38:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb39:
  %t179 = load i32, ptr %l14
  store i32 %t179, ptr %l108
  store ptr %l108, ptr %l109
  store i32 0, ptr %l110
  store ptr %l110, ptr %l111
  %t180 = load ptr, ptr %l109
  %t181 = load ptr, ptr %l111
  %t182 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aOutcome(ptr %t180, ptr %t181)
  store i1 %t182, ptr %l112
  br label %bb40
bb40:
  %t183 = load i1, ptr %l112
  br i1 %t183, label %bb41, label %bb42
bb41:
  %t184 = load i1, ptr %l15
  store i1 %t184, ptr %l114
  %t185 = load i1, ptr %l114
  store i1 %t185, ptr %l113
  br label %bb43
bb42:
  store i1 false, ptr %l113
  br label %bb43
bb43:
  %t186 = load i1, ptr %l113
  br i1 %t186, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s7
  %t187 = load ptr, ptr %l3
  store ptr %t187, ptr %l115
  %t188 = load ptr, ptr %l115
  %t189 = getelementptr %"compiler/load:Module", ptr %t188, i32 0, i32 14
  store ptr %t189, ptr %l116
  %t190 = load i64, ptr %l2
  store i64 %t190, ptr %l117
  %t191 = load i64, ptr %l12
  store i64 %t191, ptr %l118
  %t192 = load i64, ptr %l5
  store i64 %t192, ptr %l119
  %t193 = load i64, ptr %l118
  %t194 = load i64, ptr %l119
  %t195 = sub i64 %t193, %t194
  store i64 %t195, ptr %l120
  %t196 = load ptr, ptr %l116
  %t197 = load i64, ptr %l117
  %t198 = load i64, ptr %l120
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t196, i64 %t197, i64 %t198)
  br label %bb46
bb45:
  br label %bb47
bb46:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb47:
  call void @__olang_scope_close(ptr %s5)
  br label %bb48
bb48:
  store %olang.scope zeroinitializer, ptr %s8
  %t199 = load i64, ptr %l11
  store i64 %t199, ptr %l121
  %t200 = load i64, ptr %l121
  %t201 = add i64 %t200, 1
  store i64 %t201, ptr %l122
  %t202 = load i64, ptr %l122
  store i64 %t202, ptr %l11
  call void @__olang_scope_close(ptr %s8)
  br label %bb29
bb49:
  call void @__olang_scope_close(ptr %s4)
  %t203 = load ptr, ptr %l3
  store ptr %t203, ptr %l123
  %t204 = load ptr, ptr %l123
  %t205 = getelementptr %"compiler/load:Module", ptr %t204, i32 0, i32 14
  store ptr %t205, ptr %l124
  %t206 = load i64, ptr %l2
  store i64 %t206, ptr %l125
  %t207 = load ptr, ptr %l3
  store ptr %t207, ptr %l126
  %t208 = load ptr, ptr %l126
  %t209 = getelementptr %"compiler/load:Module", ptr %t208, i32 0, i32 15
  store ptr %t209, ptr %l127
  %t210 = load i64, ptr %l2
  store i64 %t210, ptr %l128
  %t211 = load ptr, ptr %l127
  %t212 = load i64, ptr %l128
  %t213 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t211, i64 %t212)
  store i1 %t213, ptr %l129
  br label %bb50
bb50:
  %t214 = load i1, ptr %l129
  br i1 %t214, label %bb51, label %bb52
bb51:
  %t215 = load i64, ptr %l6
  store i64 %t215, ptr %l131
  %t216 = load i64, ptr %l5
  store i64 %t216, ptr %l132
  %t217 = load i64, ptr %l131
  %t218 = load i64, ptr %l132
  %t219 = sub i64 %t217, %t218
  store i64 %t219, ptr %l133
  %t220 = load i64, ptr %l133
  store i64 %t220, ptr %l130
  br label %bb53
bb52:
  %t221 = load i64, ptr @G_2ecompiler_2fload_2eNoBranch
  store i64 %t221, ptr %l134
  %t222 = load i64, ptr %l134
  store i64 %t222, ptr %l130
  br label %bb53
bb53:
  %t223 = load ptr, ptr %l124
  %t224 = load i64, ptr %l125
  %t225 = load i64, ptr %l130
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t223, i64 %t224, i64 %t225)
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i32, i1 } @compiler_2fload_2ecompiler_2fload_3aLoader_2eevalCond(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca { i32, i1 }
  %l7 = alloca i32
  %l8 = alloca i1
  %l9 = alloca { %"compiler/source:Span", %"compiler/msgs:Msg" }
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca %"compiler/msgs:Msg"
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca i32
  %l25 = alloca { i32, i1 }
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca { i64, ptr }
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca i64
  %l32 = alloca i32
  %l33 = alloca ptr
  %l34 = alloca i32
  %l35 = alloca ptr
  %l36 = alloca i1
  %l37 = alloca i1
  %l38 = alloca i32
  %l39 = alloca { i32, i1 }
  %l40 = alloca ptr
  %l41 = alloca ptr
  %l42 = alloca { i64, ptr }
  %l43 = alloca ptr
  %l44 = alloca ptr
  %l45 = alloca ptr
  %l46 = alloca ptr
  %l47 = alloca ptr
  %l48 = alloca ptr
  %l49 = alloca %"compiler/cond:Eval"
  %l50 = alloca ptr
  %l51 = alloca ptr
  %l52 = alloca ptr
  %l53 = alloca { i32, i1 }
  %l54 = alloca i32
  %l55 = alloca i1
  %l56 = alloca i32
  %l57 = alloca ptr
  %l58 = alloca i32
  %l59 = alloca ptr
  %l60 = alloca i1
  %l61 = alloca ptr
  %l62 = alloca { %"compiler/source:Span", %"compiler/msgs:Msg" }
  %l63 = alloca %"compiler/source:Span"
  %l64 = alloca %"compiler/msgs:Msg"
  %l65 = alloca ptr
  %l66 = alloca ptr
  %l67 = alloca ptr
  %l68 = alloca ptr
  %l69 = alloca %"compiler/source:Span"
  %l70 = alloca { i64, [3 x i64] }
  %l71 = alloca %"compiler/msgs:Msg"
  %l72 = alloca i64
  %l73 = alloca i32
  %l74 = alloca i1
  %l75 = alloca { i32, i1 }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i32, i1 }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l12
  %t2 = load ptr, ptr %l12
  %t3 = getelementptr %"compiler/load:Loader", ptr %t2, i32 0, i32 5
  store ptr %t3, ptr %l13
  %t4 = load i64, ptr %l1
  store i64 %t4, ptr %l14
  %t5 = load ptr, ptr %l13
  %t6 = load i64, ptr %l14
  %t7 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t5, i64 %t6)
  store ptr %t7, ptr %l15
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l15
  store ptr %t8, ptr %l3
  %t9 = load ptr, ptr %l0
  store ptr %t9, ptr %l16
  %t10 = load ptr, ptr %l3
  store ptr %t10, ptr %l17
  %t11 = load ptr, ptr %l16
  %t12 = load ptr, ptr %l17
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2eCondParser(ptr %v0, ptr %v0, ptr %t11, ptr %t12)
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l3
  store ptr %t13, ptr %l19
  %t14 = load ptr, ptr %l19
  %t15 = getelementptr %"compiler/load:Module", ptr %t14, i32 0, i32 22
  %t16 = load ptr, ptr %t15
  store ptr %t16, ptr %l20
  %t17 = load i64, ptr %l2
  store i64 %t17, ptr %l21
  %t18 = load ptr, ptr %l20
  %t19 = load i64, ptr %l21
  %t20 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eExprAt(ptr %v0, ptr %t18, i64 %t19)
  %t21 = extractvalue { i32, ptr } %t20, 1
  %t22 = extractvalue { i32, ptr } %t20, 0
  store i32 %t22, ptr %l23
  %t23 = icmp ne i32 %t22, 0
  br i1 %t23, label %bb4, label %ok.24
ok.24:
  store ptr %t21, ptr %l22
  br label %bb3
bb3:
  %t25 = load ptr, ptr %l22
  store ptr %t25, ptr %l18
  br label %bb6
bb4:
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  store i32 2, ptr %l24
  %t26 = load i32, ptr %l24
  %t27 = insertvalue { i32, i1 } undef, i32 %t26, 0
  %t28 = insertvalue { i32, i1 } %t27, i1 false, 1
  store { i32, i1 } %t28, ptr %l25
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t29 = load { i32, i1 }, ptr %l25
  store { i32, i1 } %t29, ptr %rv
  br label %ret
bb6:
  %t30 = load ptr, ptr %l18
  store ptr %t30, ptr %l4
  %t31 = load ptr, ptr %l3
  store ptr %t31, ptr %l26
  %t32 = load ptr, ptr %l26
  %t33 = getelementptr %"compiler/load:Module", ptr %t32, i32 0, i32 6
  %t34 = load ptr, ptr %t33
  store ptr %t34, ptr %l27
  %t35 = load ptr, ptr %l27
  %t36 = getelementptr %"compiler/scan:Tokens", ptr %t35, i32 0, i32 0
  %t37 = load { i64, ptr }, ptr %t36
  store { i64, ptr } %t37, ptr %l28
  %t38 = load ptr, ptr %l3
  store ptr %t38, ptr %l29
  %t39 = load ptr, ptr %l29
  %t40 = getelementptr %"compiler/load:Module", ptr %t39, i32 0, i32 22
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l30
  %t42 = load ptr, ptr %l30
  %t43 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ePos(ptr %v0, ptr %t42)
  store i64 %t43, ptr %l31
  br label %bb7
bb7:
  %t44 = load i64, ptr %l31
  %t45 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t46 = load ptr, ptr %t45
  %t47 = getelementptr %"compiler/token:Token", ptr %t46, i64 %t44
  %t48 = getelementptr %"compiler/token:Token", ptr %t47, i32 0, i32 0
  %t49 = load i32, ptr %t48
  store i32 %t49, ptr %l32
  store ptr %l32, ptr %l33
  store i32 94, ptr %l34
  store ptr %l34, ptr %l35
  %t50 = load ptr, ptr %l33
  %t51 = load ptr, ptr %l35
  %t52 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t50, ptr %t51)
  store i1 %t52, ptr %l36
  br label %bb8
bb8:
  %t53 = load i1, ptr %l36
  %t54 = xor i1 %t53, true
  store i1 %t54, ptr %l37
  %t55 = load i1, ptr %l37
  br i1 %t55, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  store i32 1, ptr %l38
  %t56 = load i32, ptr %l38
  %t57 = insertvalue { i32, i1 } undef, i32 %t56, 0
  %t58 = insertvalue { i32, i1 } %t57, i1 false, 1
  store { i32, i1 } %t58, ptr %l39
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t59 = load { i32, i1 }, ptr %l39
  store { i32, i1 } %t59, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t60 = load ptr, ptr %l3
  store ptr %t60, ptr %l40
  %t61 = load ptr, ptr %l40
  %t62 = getelementptr %"compiler/load:Module", ptr %t61, i32 0, i32 5
  %t63 = load ptr, ptr %t62
  store ptr %t63, ptr %l41
  %t64 = load ptr, ptr %l41
  %t65 = getelementptr %"compiler/source:Source", ptr %t64, i32 0, i32 1
  %t66 = load { i64, ptr }, ptr %t65
  store { i64, ptr } %t66, ptr %l42
  %t67 = load ptr, ptr %l0
  store ptr %t67, ptr %l43
  %t68 = load ptr, ptr %l43
  %t69 = getelementptr %"compiler/load:Loader", ptr %t68, i32 0, i32 3
  %t70 = load ptr, ptr %t69
  store ptr %t70, ptr %l44
  %t71 = load ptr, ptr %l3
  store ptr %t71, ptr %l45
  %t72 = load ptr, ptr %l45
  %t73 = getelementptr %"compiler/load:Module", ptr %t72, i32 0, i32 21
  %t74 = load ptr, ptr %t73
  store ptr %t74, ptr %l46
  %t75 = load ptr, ptr %l0
  store ptr %t75, ptr %l47
  %t76 = load ptr, ptr %l47
  %t77 = getelementptr %"compiler/load:Loader", ptr %t76, i32 0, i32 1
  %t78 = load ptr, ptr %t77
  store ptr %t78, ptr %l48
  %t79 = load { i64, ptr }, ptr %l42
  %t80 = load ptr, ptr %l44
  %t81 = load ptr, ptr %l46
  %t82 = load ptr, ptr %l48
  %t83 = call %"compiler/cond:Eval" @compiler_2fcond_3aEval_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t79, ptr %t80, ptr %t81, ptr %t82)
  store %"compiler/cond:Eval" %t83, ptr %l49
  br label %bb12
bb12:
  %t84 = load %"compiler/cond:Eval", ptr %l49
  %t85 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 128, i64 8)
  store %"compiler/cond:Eval" %t84, ptr %t85
  store ptr %t85, ptr %l50
  %t86 = load ptr, ptr %l50
  store ptr %t86, ptr %l5
  %t87 = load ptr, ptr %l5
  store ptr %t87, ptr %l51
  %t88 = load ptr, ptr %l4
  store ptr %t88, ptr %l52
  %t89 = load ptr, ptr %l51
  %t90 = load ptr, ptr %l52
  %t91 = call { i32, i1 } @compiler_2fcond_2ecompiler_2fcond_3aEval_2eTop(ptr %v0, ptr %v0, ptr %t89, ptr %t90)
  store { i32, i1 } %t91, ptr %l53
  br label %bb13
bb13:
  %t92 = load { i32, i1 }, ptr %l53
  store { i32, i1 } %t92, ptr %l6
  %t93 = getelementptr { i32, i1 }, ptr %l6, i32 0, i32 0
  %t94 = load i32, ptr %t93
  store i32 %t94, ptr %l54
  %t95 = load i32, ptr %l54
  store i32 %t95, ptr %l7
  %t96 = getelementptr { i32, i1 }, ptr %l6, i32 0, i32 1
  %t97 = load i1, ptr %t96
  store i1 %t97, ptr %l55
  %t98 = load i1, ptr %l55
  store i1 %t98, ptr %l8
  %t99 = load i32, ptr %l7
  store i32 %t99, ptr %l56
  store ptr %l56, ptr %l57
  store i32 2, ptr %l58
  store ptr %l58, ptr %l59
  %t100 = load ptr, ptr %l57
  %t101 = load ptr, ptr %l59
  %t102 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aOutcome(ptr %t100, ptr %t101)
  store i1 %t102, ptr %l60
  br label %bb14
bb14:
  %t103 = load i1, ptr %l60
  br i1 %t103, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t104 = load ptr, ptr %l5
  store ptr %t104, ptr %l61
  %t105 = load ptr, ptr %l61
  %t106 = call { %"compiler/source:Span", %"compiler/msgs:Msg" } @compiler_2fcond_2ecompiler_2fcond_3aEval_2eError(ptr %v0, ptr %s3, ptr %t105)
  store { %"compiler/source:Span", %"compiler/msgs:Msg" } %t106, ptr %l62
  br label %bb17
bb16:
  br label %bb20
bb17:
  %t107 = load { %"compiler/source:Span", %"compiler/msgs:Msg" }, ptr %l62
  store { %"compiler/source:Span", %"compiler/msgs:Msg" } %t107, ptr %l9
  %t108 = getelementptr { %"compiler/source:Span", %"compiler/msgs:Msg" }, ptr %l9, i32 0, i32 0
  %t109 = load %"compiler/source:Span", ptr %t108
  store %"compiler/source:Span" %t109, ptr %l63
  %t110 = load %"compiler/source:Span", ptr %l63
  store %"compiler/source:Span" %t110, ptr %l10
  %t111 = getelementptr { %"compiler/source:Span", %"compiler/msgs:Msg" }, ptr %l9, i32 0, i32 1
  %t112 = load %"compiler/msgs:Msg", ptr %t111
  store %"compiler/msgs:Msg" %t112, ptr %l64
  %t113 = load %"compiler/msgs:Msg", ptr %l64
  store %"compiler/msgs:Msg" %t113, ptr %l11
  %t114 = load ptr, ptr %l0
  store ptr %t114, ptr %l65
  %t115 = load ptr, ptr %l65
  %t116 = getelementptr %"compiler/load:Loader", ptr %t115, i32 0, i32 4
  %t117 = load ptr, ptr %t116
  store ptr %t117, ptr %l66
  %t118 = load ptr, ptr %l0
  store ptr %t118, ptr %l67
  %t119 = load ptr, ptr %l3
  store ptr %t119, ptr %l68
  %t120 = load %"compiler/source:Span", ptr %l10
  store %"compiler/source:Span" %t120, ptr %l69
  %t121 = load ptr, ptr %l67
  %t122 = load ptr, ptr %l68
  %t123 = load %"compiler/source:Span", ptr %l69
  %t124 = call { i64, [3 x i64] } @compiler_2fload_2ecompiler_2fload_3aLoader_2eat(ptr %v0, ptr %v0, ptr %t121, ptr %t122, %"compiler/source:Span" %t123)
  store { i64, [3 x i64] } %t124, ptr %l70
  br label %bb18
bb18:
  %t125 = load %"compiler/msgs:Msg", ptr %l11
  store %"compiler/msgs:Msg" %t125, ptr %l71
  %t126 = load ptr, ptr %l66
  %t127 = load { i64, [3 x i64] }, ptr %l70
  %t128 = load %"compiler/msgs:Msg", ptr %l71
  %t129 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s3, ptr %t126, { i64, [3 x i64] } %t127, %"compiler/msgs:Msg" %t128)
  store i64 %t129, ptr %l72
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb20:
  %t130 = load i32, ptr %l7
  store i32 %t130, ptr %l73
  %t131 = load i1, ptr %l8
  store i1 %t131, ptr %l74
  %t132 = load i32, ptr %l73
  %t133 = insertvalue { i32, i1 } undef, i32 %t132, 0
  %t134 = load i1, ptr %l74
  %t135 = insertvalue { i32, i1 } %t133, i1 %t134, 1
  store { i32, i1 } %t135, ptr %l75
  call void @__olang_scope_close(ptr %s0)
  %t136 = load { i32, i1 }, ptr %l75
  store { i32, i1 } %t136, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i1 }, ptr %rv
  ret { i32, i1 } %rr
}

define dso_local void @compiler_2fload_2ecompiler_2fload_3aLoader_2egroups(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i1
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca i1
  %l21 = alloca i1
  %l22 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca %"compiler/source:Span"
  %l30 = alloca i32
  %l31 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca i64
  %l34 = alloca ptr
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t1, ptr %l9
  %t2 = load { i64, ptr }, ptr %l9
  store { i64, ptr } %t2, ptr %l3
  store i64 0, ptr %l4
  %t3 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t3, ptr %l10
  %t4 = load { i64, ptr }, ptr %l10
  %t5 = extractvalue { i64, ptr } %t4, 0
  store i64 %t5, ptr %l11
  %t6 = load i64, ptr %l11
  store i64 %t6, ptr %l5
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l4
  store i64 %t7, ptr %l12
  %t8 = load i64, ptr %l5
  store i64 %t8, ptr %l13
  %t9 = load i64, ptr %l12
  %t10 = load i64, ptr %l13
  %t11 = icmp slt i64 %t9, %t10
  store i1 %t11, ptr %l14
  %t12 = load i1, ptr %l14
  %t13 = xor i1 %t12, true
  store i1 %t13, ptr %l15
  %t14 = load i1, ptr %l15
  br i1 %t14, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t15, ptr %l16
  %t16 = load i64, ptr %l4
  store i64 %t16, ptr %l17
  %t17 = load i64, ptr %l17
  %t18 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t19 = load ptr, ptr %t18
  %t20 = getelementptr ptr, ptr %t19, i64 %t17
  %t21 = load ptr, ptr %t20
  store ptr %t21, ptr %l18
  %t22 = load ptr, ptr %l18
  store ptr %t22, ptr %l6
  %t23 = load ptr, ptr %l6
  store ptr %t23, ptr %l19
  store i1 false, ptr %l20
  %t24 = load ptr, ptr %l19
  %t25 = icmp ne ptr %t24, null
  store i1 %t25, ptr %l21
  %t26 = load i1, ptr %l21
  br i1 %t26, label %bb5, label %bb6
bb5:
  %t27 = load ptr, ptr %l19
  %t28 = load i64, ptr %t27
  store i64 %t28, ptr %l22
  %t29 = load i64, ptr %l22
  %t30 = icmp eq i64 %t29, 7
  store i1 %t30, ptr %l20
  br label %bb6
bb6:
  %t31 = load i1, ptr %l20
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t32 = load ptr, ptr %l6
  store ptr %t32, ptr %l23
  %t33 = load ptr, ptr %l23
  %t34 = getelementptr { i64, [4 x i64] }, ptr %t33, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", ptr }, ptr %t34, i32 0, i32 1
  %t36 = load ptr, ptr %t35
  store ptr %t36, ptr %l24
  %t37 = load ptr, ptr %l24
  store ptr %t37, ptr %l7
  br label %bb9
bb8:
  br label %bb13
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t38 = load ptr, ptr %l0
  store ptr %t38, ptr %l25
  %t39 = load i64, ptr %l1
  store i64 %t39, ptr %l26
  %t40 = load ptr, ptr %l7
  store ptr %t40, ptr %l27
  %t41 = load ptr, ptr %l27
  %t42 = getelementptr %"compiler/ast:TopIf", ptr %t41, i32 0, i32 0
  %t43 = load ptr, ptr %t42
  store ptr %t43, ptr %l28
  %t44 = load ptr, ptr %l28
  %t45 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t44)
  store %"compiler/source:Span" %t45, ptr %l29
  br label %bb10
bb10:
  %t46 = getelementptr %"compiler/source:Span", ptr %l29, i32 0, i32 0
  %t47 = load i32, ptr %t46
  store i32 %t47, ptr %l30
  %t48 = load ptr, ptr %l25
  %t49 = load i64, ptr %l26
  %t50 = load i32, ptr %l30
  %t51 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eChosen(ptr %v0, ptr %t48, i64 %t49, i32 %t50)
  store i64 %t51, ptr %l31
  br label %bb11
bb11:
  %t52 = load i64, ptr %l31
  store i64 %t52, ptr %l8
  %t53 = load ptr, ptr %l0
  store ptr %t53, ptr %l32
  %t54 = load i64, ptr %l1
  store i64 %t54, ptr %l33
  %t55 = load ptr, ptr %l7
  store ptr %t55, ptr %l34
  %t56 = load i64, ptr %l8
  store i64 %t56, ptr %l35
  %t57 = load ptr, ptr %l32
  %t58 = load i64, ptr %l33
  %t59 = load ptr, ptr %l34
  %t60 = load i64, ptr %l35
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2echainGroups(ptr %v0, ptr %v1, ptr %t57, i64 %t58, ptr %t59, i64 %t60, i64 0)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s4
  call void @__olang_scope_close(ptr %s4)
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s5
  %t61 = load i64, ptr %l4
  store i64 %t61, ptr %l36
  %t62 = load i64, ptr %l36
  %t63 = add i64 %t62, 1
  store i64 %t63, ptr %l37
  %t64 = load i64, ptr %l37
  store i64 %t64, ptr %l4
  call void @__olang_scope_close(ptr %s5)
  br label %bb1
bb16:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fload_2ecompiler_2fload_3aLoader_2eimportAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca %"compiler/source:Span"
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i32
  %l23 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca ptr
  %l26 = alloca i1
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca i32
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca i32
  %l33 = alloca %"compiler/source:Span"
  %l34 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca i32
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca i32
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i1
  %l47 = alloca i1
  %l48 = alloca i1
  %l49 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i1
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca { i64, ptr }
  %l57 = alloca i64
  %l58 = alloca i32
  %l59 = alloca ptr
  %l60 = alloca i32
  %l61 = alloca ptr
  %l62 = alloca i1
  %l63 = alloca i1
  %l64 = alloca { i64, ptr }
  %l65 = alloca i64
  %l66 = alloca i32
  %l67 = alloca { i64, ptr }
  %l68 = alloca i64
  %l69 = alloca i32
  %l70 = alloca %"compiler/source:Span"
  %l71 = alloca ptr
  %l72 = alloca ptr
  %l73 = alloca { i64, ptr }
  %l74 = alloca i32
  %l75 = alloca i32
  %l76 = alloca i64
  %l77 = alloca i32
  %l78 = alloca i32
  %l79 = alloca i64
  %l80 = alloca i64
  %l81 = alloca i1
  %l82 = alloca i1
  %l83 = alloca i1
  %l84 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l86 = alloca i1
  %l87 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l90 = alloca i64
  %l91 = alloca i64
  %l92 = alloca i1
  %l93 = alloca %"compiler/source:Span"
  %l94 = alloca ptr
  %l95 = alloca ptr
  %l96 = alloca %"compiler/source:Span"
  %l97 = alloca %"compiler/source:Span"
  %l98 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %l100 = alloca { i64, ptr }
  %l101 = alloca { i64, ptr }
  %l102 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %l104 = alloca i64
  %l105 = alloca %"compiler/load:Import"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.builder
  %s2room = alloca [64 x i8], align 8
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.builder
  %s5room = alloca [64 x i8], align 8
  %s6 = alloca %olang.builder
  %s6room = alloca [64 x i8], align 8
  %s7 = alloca %olang.builder
  %s7room = alloca [64 x i8], align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1
  store ptr %t1, ptr %l10
  %t2 = load ptr, ptr %l10
  %t3 = getelementptr %"compiler/load:Module", ptr %t2, i32 0, i32 6
  %t4 = load ptr, ptr %t3
  store ptr %t4, ptr %l11
  %t5 = load ptr, ptr %l11
  %t6 = getelementptr %"compiler/scan:Tokens", ptr %t5, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6
  store { i64, ptr } %t7, ptr %l12
  %t8 = load { i64, ptr }, ptr %l12
  store { i64, ptr } %t8, ptr %l4
  %t9 = load i64, ptr %l2
  store i64 %t9, ptr %l13
  %t10 = load i64, ptr %l13
  %t11 = add i64 %t10, 1
  store i64 %t11, ptr %l14
  %t12 = load i64, ptr %l14
  store i64 %t12, ptr %l5
  store { i64, ptr } { i64 0, ptr @.d49 }, ptr %l15
  %t13 = load { i64, ptr }, ptr %l15
  store { i64, ptr } %t13, ptr %l16
  %t14 = load { i64, ptr }, ptr %l16
  %t15 = extractvalue { i64, ptr } %t14, 0
  store i64 %t15, ptr %l17
  %t16 = load i64, ptr %l17
  %t17 = mul i64 %t16, 1
  %t18 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t17)
  %t19 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l18
  %t21 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t22 = load ptr, ptr %t21
  %t23 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t24 = load ptr, ptr %t23
  %t25 = load i64, ptr %l17
  %t26 = mul i64 %t25, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t22, ptr %t24, i64 %t26, i1 false)
  %t27 = load { i64, ptr }, ptr %l18
  store { i64, ptr } %t27, ptr %l6
  %t28 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 0, i32 0)
  store %"compiler/source:Span" %t28, ptr %l19
  br label %bb1
bb1:
  %t29 = load %"compiler/source:Span", ptr %l19
  store %"compiler/source:Span" %t29, ptr %l7
  %t30 = load { i64, ptr }, ptr %l4
  store { i64, ptr } %t30, ptr %l20
  %t31 = load i64, ptr %l5
  store i64 %t31, ptr %l21
  %t32 = load i64, ptr %l21
  %t33 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t34 = load ptr, ptr %t33
  %t35 = getelementptr %"compiler/token:Token", ptr %t34, i64 %t32
  %t36 = getelementptr %"compiler/token:Token", ptr %t35, i32 0, i32 0
  %t37 = load i32, ptr %t36
  store i32 %t37, ptr %l22
  store ptr %l22, ptr %l23
  store i32 1, ptr %l24
  store ptr %l24, ptr %l25
  %t38 = load ptr, ptr %l23
  %t39 = load ptr, ptr %l25
  %t40 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t38, ptr %t39)
  store i1 %t40, ptr %l26
  br label %bb2
bb2:
  %t41 = load i1, ptr %l26
  br i1 %t41, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t42 = load { i64, ptr }, ptr %l4
  store { i64, ptr } %t42, ptr %l27
  %t43 = load i64, ptr %l5
  store i64 %t43, ptr %l28
  %t44 = load i64, ptr %l28
  %t45 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t46 = load ptr, ptr %t45
  %t47 = getelementptr %"compiler/token:Token", ptr %t46, i64 %t44
  %t48 = getelementptr %"compiler/token:Token", ptr %t47, i32 0, i32 2
  %t49 = load i32, ptr %t48
  store i32 %t49, ptr %l29
  %t50 = load { i64, ptr }, ptr %l4
  store { i64, ptr } %t50, ptr %l30
  %t51 = load i64, ptr %l5
  store i64 %t51, ptr %l31
  %t52 = load i64, ptr %l31
  %t53 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t54 = load ptr, ptr %t53
  %t55 = getelementptr %"compiler/token:Token", ptr %t54, i64 %t52
  %t56 = getelementptr %"compiler/token:Token", ptr %t55, i32 0, i32 3
  %t57 = load i32, ptr %t56
  store i32 %t57, ptr %l32
  %t58 = load i32, ptr %l29
  %t59 = load i32, ptr %l32
  %t60 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s1, i32 %t58, i32 %t59)
  store %"compiler/source:Span" %t60, ptr %l33
  br label %bb5
bb4:
  br label %bb15
bb5:
  %t61 = load %"compiler/source:Span", ptr %l33
  store %"compiler/source:Span" %t61, ptr %l7
  %t62 = load ptr, ptr %l1
  store ptr %t62, ptr %l34
  %t63 = load ptr, ptr %l34
  %t64 = getelementptr %"compiler/load:Module", ptr %t63, i32 0, i32 5
  %t65 = load ptr, ptr %t64
  store ptr %t65, ptr %l35
  %t66 = load ptr, ptr %l35
  %t67 = getelementptr %"compiler/source:Source", ptr %t66, i32 0, i32 1
  %t68 = load { i64, ptr }, ptr %t67
  store { i64, ptr } %t68, ptr %l36
  %t69 = load { i64, ptr }, ptr %l4
  store { i64, ptr } %t69, ptr %l37
  %t70 = load i64, ptr %l5
  store i64 %t70, ptr %l38
  %t71 = load i64, ptr %l38
  %t72 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t73 = load ptr, ptr %t72
  %t74 = getelementptr %"compiler/token:Token", ptr %t73, i64 %t71
  %t75 = getelementptr %"compiler/token:Token", ptr %t74, i32 0, i32 2
  %t76 = load i32, ptr %t75
  store i32 %t76, ptr %l39
  %t77 = load i32, ptr %l39
  %t78 = sext i32 %t77 to i64
  store i64 %t78, ptr %l40
  %t79 = load { i64, ptr }, ptr %l4
  store { i64, ptr } %t79, ptr %l41
  %t80 = load i64, ptr %l5
  store i64 %t80, ptr %l42
  %t81 = load i64, ptr %l42
  %t82 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t83 = load ptr, ptr %t82
  %t84 = getelementptr %"compiler/token:Token", ptr %t83, i64 %t81
  %t85 = getelementptr %"compiler/token:Token", ptr %t84, i32 0, i32 3
  %t86 = load i32, ptr %t85
  store i32 %t86, ptr %l43
  %t87 = load i32, ptr %l43
  %t88 = sext i32 %t87 to i64
  store i64 %t88, ptr %l44
  %t89 = load { i64, ptr }, ptr %l36
  %t90 = extractvalue { i64, ptr } %t89, 0
  store i64 %t90, ptr %l45
  %t91 = load i64, ptr %l40
  %t92 = icmp sge i64 %t91, 0
  store i1 %t92, ptr %l46
  %t93 = load i1, ptr %l46
  br i1 %t93, label %bb6, label %bb7
bb6:
  %t94 = load i64, ptr %l40
  %t95 = load i64, ptr %l44
  %t96 = icmp sle i64 %t94, %t95
  store i1 %t96, ptr %l47
  %t97 = load i1, ptr %l47
  br i1 %t97, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @.c50)
  unreachable
bb8:
  %t98 = load i64, ptr %l44
  %t99 = load i64, ptr %l45
  %t100 = icmp sle i64 %t98, %t99
  store i1 %t100, ptr %l48
  %t101 = load i1, ptr %l48
  br i1 %t101, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @.c50)
  unreachable
bb10:
  %t102 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t103 = load ptr, ptr %t102
  %t104 = load i64, ptr %l40
  %t105 = load i64, ptr %l44
  %t106 = getelementptr i8, ptr %t103, i64 %t104
  %t107 = sub i64 %t105, %t104
  %t108 = insertvalue { i64, ptr } undef, i64 %t107, 0
  %t109 = insertvalue { i64, ptr } %t108, ptr %t106, 1
  store { i64, ptr } %t109, ptr %l49
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s2
  store ptr %s2room, ptr %s2
  %t110 = load { i64, ptr }, ptr %l49
  %t111 = extractvalue { i64, ptr } %t110, 1
  %t112 = extractvalue { i64, ptr } %t110, 0
  call void @__olang_sb_put(ptr %s2, ptr %t111, i64 %t112)
  %t113 = load ptr, ptr %s2
  %t114 = getelementptr %olang.builder, ptr %s2, i32 0, i32 1
  %t115 = load i64, ptr %t114
  %t116 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t115)
  call void @llvm.memcpy.p0.p0.i64(ptr %t116, ptr %t113, i64 %t115, i1 false)
  %t117 = insertvalue { i64, ptr } undef, i64 %t115, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t116, 1
  store { i64, ptr } %t118, ptr %l50
  call void @__olang_sb_done(ptr %s2)
  %t119 = load { i64, ptr }, ptr %l6
  %t120 = extractvalue { i64, ptr } %t119, 0
  store i64 %t120, ptr %l51
  %t121 = load { i64, ptr }, ptr %l50
  %t122 = extractvalue { i64, ptr } %t121, 0
  store i64 %t122, ptr %l52
  %t123 = load i64, ptr %l51
  %t124 = load i64, ptr %l52
  %t125 = icmp eq i64 %t123, %t124
  store i1 %t125, ptr %l53
  %t126 = load i1, ptr %l53
  br i1 %t126, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @.c50)
  unreachable
bb12:
  %t127 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t128 = load ptr, ptr %t127
  %t129 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t130 = load ptr, ptr %t129
  %t131 = load i64, ptr %l52
  %t132 = mul i64 %t131, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t128, ptr %t130, i64 %t132, i1 false)
  br label %bb14
bb13:
  %t133 = load { i64, ptr }, ptr %l50
  store { i64, ptr } %t133, ptr %l6
  br label %bb14
bb14:
  %t134 = load i64, ptr %l5
  store i64 %t134, ptr %l54
  %t135 = load i64, ptr %l54
  %t136 = add i64 %t135, 1
  store i64 %t136, ptr %l55
  %t137 = load i64, ptr %l55
  store i64 %t137, ptr %l5
  call void @__olang_scope_close(ptr %s1)
  br label %bb15
bb15:
  %t138 = load { i64, ptr }, ptr %l4
  store { i64, ptr } %t138, ptr %l56
  %t139 = load i64, ptr %l5
  store i64 %t139, ptr %l57
  %t140 = load i64, ptr %l57
  %t141 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t142 = load ptr, ptr %t141
  %t143 = getelementptr %"compiler/token:Token", ptr %t142, i64 %t140
  %t144 = getelementptr %"compiler/token:Token", ptr %t143, i32 0, i32 0
  %t145 = load i32, ptr %t144
  store i32 %t145, ptr %l58
  store ptr %l58, ptr %l59
  store i32 5, ptr %l60
  store ptr %l60, ptr %l61
  %t146 = load ptr, ptr %l59
  %t147 = load ptr, ptr %l61
  %t148 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t146, ptr %t147)
  store i1 %t148, ptr %l62
  br label %bb16
bb16:
  %t149 = load i1, ptr %l62
  %t150 = xor i1 %t149, true
  store i1 %t150, ptr %l63
  %t151 = load i1, ptr %l63
  br i1 %t151, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s3
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb18:
  br label %bb19
bb19:
  %t152 = load { i64, ptr }, ptr %l4
  store { i64, ptr } %t152, ptr %l64
  %t153 = load i64, ptr %l5
  store i64 %t153, ptr %l65
  %t154 = load i64, ptr %l65
  %t155 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t156 = load ptr, ptr %t155
  %t157 = getelementptr %"compiler/token:Token", ptr %t156, i64 %t154
  %t158 = getelementptr %"compiler/token:Token", ptr %t157, i32 0, i32 2
  %t159 = load i32, ptr %t158
  store i32 %t159, ptr %l66
  %t160 = load { i64, ptr }, ptr %l4
  store { i64, ptr } %t160, ptr %l67
  %t161 = load i64, ptr %l5
  store i64 %t161, ptr %l68
  %t162 = load i64, ptr %l68
  %t163 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t164 = load ptr, ptr %t163
  %t165 = getelementptr %"compiler/token:Token", ptr %t164, i64 %t162
  %t166 = getelementptr %"compiler/token:Token", ptr %t165, i32 0, i32 3
  %t167 = load i32, ptr %t166
  store i32 %t167, ptr %l69
  %t168 = load i32, ptr %l66
  %t169 = load i32, ptr %l69
  %t170 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t168, i32 %t169)
  store %"compiler/source:Span" %t170, ptr %l70
  br label %bb20
bb20:
  %t171 = load %"compiler/source:Span", ptr %l70
  store %"compiler/source:Span" %t171, ptr %l8
  %t172 = load ptr, ptr %l1
  store ptr %t172, ptr %l71
  %t173 = load ptr, ptr %l71
  %t174 = getelementptr %"compiler/load:Module", ptr %t173, i32 0, i32 5
  %t175 = load ptr, ptr %t174
  store ptr %t175, ptr %l72
  %t176 = load ptr, ptr %l72
  %t177 = getelementptr %"compiler/source:Source", ptr %t176, i32 0, i32 1
  %t178 = load { i64, ptr }, ptr %t177
  store { i64, ptr } %t178, ptr %l73
  %t179 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 0
  %t180 = load i32, ptr %t179
  store i32 %t180, ptr %l74
  %t181 = load i32, ptr %l74
  %t182 = add i32 %t181, 1
  store i32 %t182, ptr %l75
  %t183 = load i32, ptr %l75
  %t184 = sext i32 %t183 to i64
  store i64 %t184, ptr %l76
  %t185 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 1
  %t186 = load i32, ptr %t185
  store i32 %t186, ptr %l77
  %t187 = load i32, ptr %l77
  %t188 = sub i32 %t187, 1
  store i32 %t188, ptr %l78
  %t189 = load i32, ptr %l78
  %t190 = sext i32 %t189 to i64
  store i64 %t190, ptr %l79
  %t191 = load { i64, ptr }, ptr %l73
  %t192 = extractvalue { i64, ptr } %t191, 0
  store i64 %t192, ptr %l80
  %t193 = load i64, ptr %l76
  %t194 = icmp sge i64 %t193, 0
  store i1 %t194, ptr %l81
  %t195 = load i1, ptr %l81
  br i1 %t195, label %bb21, label %bb22
bb21:
  %t196 = load i64, ptr %l76
  %t197 = load i64, ptr %l79
  %t198 = icmp sle i64 %t196, %t197
  store i1 %t198, ptr %l82
  %t199 = load i1, ptr %l82
  br i1 %t199, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @.c51)
  unreachable
bb23:
  %t200 = load i64, ptr %l79
  %t201 = load i64, ptr %l80
  %t202 = icmp sle i64 %t200, %t201
  store i1 %t202, ptr %l83
  %t203 = load i1, ptr %l83
  br i1 %t203, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @.c51)
  unreachable
bb25:
  %t204 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t205 = load ptr, ptr %t204
  %t206 = load i64, ptr %l76
  %t207 = load i64, ptr %l79
  %t208 = getelementptr i8, ptr %t205, i64 %t206
  %t209 = sub i64 %t207, %t206
  %t210 = insertvalue { i64, ptr } undef, i64 %t209, 0
  %t211 = insertvalue { i64, ptr } %t210, ptr %t208, 1
  store { i64, ptr } %t211, ptr %l84
  %t212 = load { i64, ptr }, ptr %l84
  store { i64, ptr } %t212, ptr %l9
  %t213 = load { i64, ptr }, ptr %l6
  store { i64, ptr } %t213, ptr %l85
  %t214 = load { i64, ptr }, ptr %l85
  %t215 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t214, { i64, ptr } { i64 0, ptr @.d52 })
  store i1 %t215, ptr %l86
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @.c51)
  unreachable
bb27:
  %t216 = load i1, ptr %l86
  br i1 %t216, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s4
  %t217 = load { i64, ptr }, ptr %l9
  store { i64, ptr } %t217, ptr %l87
  %t218 = load { i64, ptr }, ptr %l87
  %t219 = call { i64, ptr } @compiler_2fload_2eDeriveAlias(ptr %v1, { i64, ptr } %t218)
  store { i64, ptr } %t219, ptr %l88
  br label %bb30
bb29:
  br label %bb34
bb30:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s5
  store ptr %s5room, ptr %s5
  %t220 = load { i64, ptr }, ptr %l88
  %t221 = extractvalue { i64, ptr } %t220, 1
  %t222 = extractvalue { i64, ptr } %t220, 0
  call void @__olang_sb_put(ptr %s5, ptr %t221, i64 %t222)
  %t223 = load ptr, ptr %s5
  %t224 = getelementptr %olang.builder, ptr %s5, i32 0, i32 1
  %t225 = load i64, ptr %t224
  %t226 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t225)
  call void @llvm.memcpy.p0.p0.i64(ptr %t226, ptr %t223, i64 %t225, i1 false)
  %t227 = insertvalue { i64, ptr } undef, i64 %t225, 0
  %t228 = insertvalue { i64, ptr } %t227, ptr %t226, 1
  store { i64, ptr } %t228, ptr %l89
  call void @__olang_sb_done(ptr %s5)
  %t229 = load { i64, ptr }, ptr %l6
  %t230 = extractvalue { i64, ptr } %t229, 0
  store i64 %t230, ptr %l90
  %t231 = load { i64, ptr }, ptr %l89
  %t232 = extractvalue { i64, ptr } %t231, 0
  store i64 %t232, ptr %l91
  %t233 = load i64, ptr %l90
  %t234 = load i64, ptr %l91
  %t235 = icmp eq i64 %t233, %t234
  store i1 %t235, ptr %l92
  %t236 = load i1, ptr %l92
  br i1 %t236, label %bb31, label %bb32
bb31:
  %t237 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t238 = load ptr, ptr %t237
  %t239 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t240 = load ptr, ptr %t239
  %t241 = load i64, ptr %l91
  %t242 = mul i64 %t241, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t238, ptr %t240, i64 %t242, i1 false)
  br label %bb33
bb32:
  %t243 = load { i64, ptr }, ptr %l89
  store { i64, ptr } %t243, ptr %l6
  br label %bb33
bb33:
  %t244 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t244, ptr %l93
  %t245 = load %"compiler/source:Span", ptr %l93
  store %"compiler/source:Span" %t245, ptr %l7
  call void @__olang_scope_close(ptr %s4)
  br label %bb34
bb34:
  %t246 = load ptr, ptr %l1
  store ptr %t246, ptr %l94
  %t247 = load ptr, ptr %l94
  %t248 = getelementptr %"compiler/load:Module", ptr %t247, i32 0, i32 9
  store ptr %t248, ptr %l95
  %t249 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t249, ptr %l96
  %t250 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t250, ptr %l97
  %t251 = load { i64, ptr }, ptr %l6
  store { i64, ptr } %t251, ptr %l98
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s6
  store ptr %s6room, ptr %s6
  %t252 = load { i64, ptr }, ptr %l98
  %t253 = extractvalue { i64, ptr } %t252, 1
  %t254 = extractvalue { i64, ptr } %t252, 0
  call void @__olang_sb_put(ptr %s6, ptr %t253, i64 %t254)
  %t255 = load ptr, ptr %s6
  %t256 = getelementptr %olang.builder, ptr %s6, i32 0, i32 1
  %t257 = load i64, ptr %t256
  %t258 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t257)
  call void @llvm.memcpy.p0.p0.i64(ptr %t258, ptr %t255, i64 %t257, i1 false)
  %t259 = insertvalue { i64, ptr } undef, i64 %t257, 0
  %t260 = insertvalue { i64, ptr } %t259, ptr %t258, 1
  store { i64, ptr } %t260, ptr %l99
  call void @__olang_sb_done(ptr %s6)
  %t261 = load { i64, ptr }, ptr %l99
  %t262 = extractvalue { i64, ptr } %t261, 0
  %t263 = extractvalue { i64, ptr } %t261, 1
  %t264 = mul i64 %t262, 1
  %t265 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t264)
  call void @llvm.memcpy.p0.p0.i64(ptr %t265, ptr %t263, i64 %t264, i1 false)
  %t266 = insertvalue { i64, ptr } undef, i64 %t262, 0
  %t267 = insertvalue { i64, ptr } %t266, ptr %t265, 1
  store { i64, ptr } %t267, ptr %l100
  %t268 = load { i64, ptr }, ptr %l9
  store { i64, ptr } %t268, ptr %l101
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s7
  store ptr %s7room, ptr %s7
  %t269 = load { i64, ptr }, ptr %l101
  %t270 = extractvalue { i64, ptr } %t269, 1
  %t271 = extractvalue { i64, ptr } %t269, 0
  call void @__olang_sb_put(ptr %s7, ptr %t270, i64 %t271)
  %t272 = load ptr, ptr %s7
  %t273 = getelementptr %olang.builder, ptr %s7, i32 0, i32 1
  %t274 = load i64, ptr %t273
  %t275 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t274)
  call void @llvm.memcpy.p0.p0.i64(ptr %t275, ptr %t272, i64 %t274, i1 false)
  %t276 = insertvalue { i64, ptr } undef, i64 %t274, 0
  %t277 = insertvalue { i64, ptr } %t276, ptr %t275, 1
  store { i64, ptr } %t277, ptr %l102
  call void @__olang_sb_done(ptr %s7)
  %t278 = load { i64, ptr }, ptr %l102
  %t279 = extractvalue { i64, ptr } %t278, 0
  %t280 = extractvalue { i64, ptr } %t278, 1
  %t281 = mul i64 %t279, 1
  %t282 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t281)
  call void @llvm.memcpy.p0.p0.i64(ptr %t282, ptr %t280, i64 %t281, i1 false)
  %t283 = insertvalue { i64, ptr } undef, i64 %t279, 0
  %t284 = insertvalue { i64, ptr } %t283, ptr %t282, 1
  store { i64, ptr } %t284, ptr %l103
  %t285 = load i64, ptr %l3
  store i64 %t285, ptr %l104
  %t286 = load %"compiler/source:Span", ptr %l96
  %t287 = load %"compiler/source:Span", ptr %l97
  %t288 = load { i64, ptr }, ptr %l100
  %t289 = load { i64, ptr }, ptr %l103
  %t290 = load i64, ptr %l104
  %t291 = call %"compiler/load:Import" @compiler_2fload_3aImport_2ector(ptr %v1, ptr %v1, ptr %v1, %"compiler/source:Span" %t286, %"compiler/source:Span" %t287, { i64, ptr } %t288, { i64, ptr } %t289, i64 %t290)
  store %"compiler/load:Import" %t291, ptr %l105
  br label %bb35
bb35:
  %t292 = load ptr, ptr %l95
  %t293 = load %"compiler/load:Import", ptr %l105
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2ePush_3ccompiler_2fload_3aImport_3e(ptr %v1, ptr %v1, ptr %t292, %"compiler/load:Import" %t293)
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eload(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i1
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca %"compiler/scan:Diag"
  %l19 = alloca i32
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca i32
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca i1
  %l29 = alloca i1
  %l30 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i1
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i1
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i1
  %l56 = alloca i1
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca ptr
  %l63 = alloca ptr
  %l64 = alloca i64
  %l65 = alloca ptr
  %l66 = alloca ptr
  %l67 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l69 = alloca i1
  %l70 = alloca i64
  %l71 = alloca i64
  %l72 = alloca i64
  %l73 = alloca ptr
  %l74 = alloca ptr
  %l75 = alloca i64
  %l76 = alloca ptr
  %l77 = alloca ptr
  %l78 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l87 = alloca i1
  %l88 = alloca %"compiler/load:Module"
  %l89 = alloca ptr
  %l90 = alloca ptr
  %l91 = alloca ptr
  %l92 = alloca i64
  %l93 = alloca ptr
  %l94 = alloca ptr
  %l95 = alloca %"compiler/source:Source"
  %l96 = alloca ptr
  %l97 = alloca { i64, ptr }
  %l98 = alloca %"compiler/source:Source"
  %l99 = alloca i32
  %l100 = alloca i32
  %l101 = alloca i1
  %l102 = alloca ptr
  %l103 = alloca ptr
  %l104 = alloca ptr
  %l105 = alloca { i64, ptr }
  %l106 = alloca i64
  %l107 = alloca ptr
  %l108 = alloca ptr
  %l109 = alloca i64
  %l110 = alloca { i64, [3 x i64] }
  %l111 = alloca %"compiler/msgs:Msg"
  %l112 = alloca i64
  %l113 = alloca ptr
  %l114 = alloca ptr
  %l115 = alloca ptr
  %l116 = alloca ptr
  %l117 = alloca i32
  %l118 = alloca i64
  %l119 = alloca ptr
  %l120 = alloca ptr
  %l121 = alloca ptr
  %l122 = alloca ptr
  %l123 = alloca ptr
  %l124 = alloca { i64, ptr }
  %l125 = alloca ptr
  %l126 = alloca ptr
  %l127 = alloca { i64, ptr }
  %l128 = alloca ptr
  %l129 = alloca { i64, ptr }
  %l130 = alloca i1
  %l131 = alloca i64
  %l132 = alloca ptr
  %l133 = alloca ptr
  %l134 = alloca ptr
  %l135 = alloca { i64, ptr }
  %l136 = alloca %"compiler/scan:Tokens"
  %l137 = alloca ptr
  %l138 = alloca ptr
  %l139 = alloca ptr
  %l140 = alloca { i64, ptr }
  %l141 = alloca { i64, ptr }
  %l142 = alloca i64
  %l143 = alloca i64
  %l144 = alloca i64
  %l145 = alloca i1
  %l146 = alloca i1
  %l147 = alloca { i64, ptr }
  %l148 = alloca i64
  %l149 = alloca %"compiler/scan:Diag"
  %l150 = alloca i32
  %l151 = alloca ptr
  %l152 = alloca ptr
  %l153 = alloca ptr
  %l154 = alloca i64
  %l155 = alloca i32
  %l156 = alloca i64
  %l157 = alloca i32
  %l158 = alloca i64
  %l159 = alloca { i64, [3 x i64] }
  %l160 = alloca i32
  %l161 = alloca %"compiler/scan:Diag"
  %l162 = alloca { i64, ptr }
  %l163 = alloca %"compiler/scan:Diag"
  %l164 = alloca { i64, ptr }
  %l165 = alloca { i64, ptr }
  %l166 = alloca %"compiler/msgs:Msg"
  %l167 = alloca i64
  %l168 = alloca i64
  %l169 = alloca i64
  %l170 = alloca ptr
  %l171 = alloca ptr
  %l172 = alloca ptr
  %l173 = alloca %"compiler/parse:Oracle"
  %l174 = alloca ptr
  %l175 = alloca ptr
  %l176 = alloca ptr
  %l177 = alloca ptr
  %l178 = alloca i64
  %l179 = alloca ptr
  %l180 = alloca i64
  %l181 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %s2 = alloca %olang.builder
  %s2room = alloca [64 x i8], align 8
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.builder
  %s7room = alloca [64 x i8], align 8
  %s8 = alloca %olang.builder
  %s8room = alloca [64 x i8], align 8
  %s9 = alloca %olang.builder
  %s9room = alloca [64 x i8], align 8
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %rv = alloca i64
  %t183 = alloca %"compiler/load:Module", align 8
  %t235 = alloca { i64, [3 x i64] }, align 8
  %t353 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t1, ptr %l21
  %t2 = load { i64, ptr }, ptr %l21
  %t3 = call { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v1, ptr %s0, { i64, ptr } %t2)
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l23
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store { i64, ptr } %t4, ptr %l22
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l22
  store { i64, ptr } %t8, ptr %l20
  br label %bb4
bb2:
  br label %bb3
bb3:
  store { i64, ptr } { i64 0, ptr @.d53 }, ptr %l24
  %t9 = load { i64, ptr }, ptr %l24
  store { i64, ptr } %t9, ptr %l25
  %t10 = load { i64, ptr }, ptr %l25
  %t11 = extractvalue { i64, ptr } %t10, 0
  %t12 = extractvalue { i64, ptr } %t10, 1
  %t13 = mul i64 %t11, 1
  %t14 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t13)
  call void @llvm.memcpy.p0.p0.i64(ptr %t14, ptr %t12, i64 %t13, i1 false)
  %t15 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l26
  %t17 = load { i64, ptr }, ptr %l26
  store { i64, ptr } %t17, ptr %l20
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l20
  store { i64, ptr } %t18, ptr %l4
  %t19 = load { i64, ptr }, ptr %l4
  store { i64, ptr } %t19, ptr %l27
  %t20 = load { i64, ptr }, ptr %l27
  %t21 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t20, { i64, ptr } { i64 0, ptr @.d54 })
  store i1 %t21, ptr %l28
  br label %bb5
bb5:
  %t22 = load i1, ptr %l28
  %t23 = xor i1 %t22, true
  store i1 %t23, ptr %l29
  %t24 = load i1, ptr %l29
  br i1 %t24, label %bb6, label %bb7
bb6:
  %t25 = load { i64, ptr }, ptr %l4
  store { i64, ptr } %t25, ptr %l31
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t26 = load { i64, ptr }, ptr %l31
  %t27 = extractvalue { i64, ptr } %t26, 1
  %t28 = extractvalue { i64, ptr } %t26, 0
  call void @__olang_sb_put(ptr %s1, ptr %t27, i64 %t28)
  %t29 = load ptr, ptr %s1
  %t30 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t31 = load i64, ptr %t30
  %t32 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t31)
  call void @llvm.memcpy.p0.p0.i64(ptr %t32, ptr %t29, i64 %t31, i1 false)
  %t33 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  store { i64, ptr } %t34, ptr %l32
  call void @__olang_sb_done(ptr %s1)
  %t35 = load { i64, ptr }, ptr %l32
  store { i64, ptr } %t35, ptr %l30
  br label %bb8
bb7:
  %t36 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t36, ptr %l33
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s2
  store ptr %s2room, ptr %s2
  %t37 = load { i64, ptr }, ptr %l33
  %t38 = extractvalue { i64, ptr } %t37, 1
  %t39 = extractvalue { i64, ptr } %t37, 0
  call void @__olang_sb_put(ptr %s2, ptr %t38, i64 %t39)
  %t40 = load ptr, ptr %s2
  %t41 = getelementptr %olang.builder, ptr %s2, i32 0, i32 1
  %t42 = load i64, ptr %t41
  %t43 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t42)
  call void @llvm.memcpy.p0.p0.i64(ptr %t43, ptr %t40, i64 %t42, i1 false)
  %t44 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  store { i64, ptr } %t45, ptr %l34
  call void @__olang_sb_done(ptr %s2)
  %t46 = load { i64, ptr }, ptr %l34
  store { i64, ptr } %t46, ptr %l30
  br label %bb8
bb8:
  %t47 = load { i64, ptr }, ptr %l30
  store { i64, ptr } %t47, ptr %l5
  store %olang.scope zeroinitializer, ptr %s3
  store i64 0, ptr %l6
  %t48 = load ptr, ptr %l0
  store ptr %t48, ptr %l35
  %t49 = load ptr, ptr %l35
  %t50 = getelementptr %"compiler/load:Loader", ptr %t49, i32 0, i32 5
  store ptr %t50, ptr %l36
  %t51 = load ptr, ptr %l36
  %t52 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v0, ptr %t51)
  store i64 %t52, ptr %l37
  br label %bb9
bb9:
  %t53 = load i64, ptr %l37
  store i64 %t53, ptr %l7
  store i64 1, ptr %l8
  %t54 = load i64, ptr %l7
  store i64 %t54, ptr %l38
  %t55 = load i64, ptr %l6
  store i64 %t55, ptr %l39
  %t56 = load i64, ptr %l38
  %t57 = load i64, ptr %l39
  %t58 = icmp sgt i64 %t56, %t57
  store i1 %t58, ptr %l40
  %t59 = load i1, ptr %l40
  br i1 %t59, label %bb10, label %bb11
bb10:
  %t60 = load i64, ptr %l8
  store i64 %t60, ptr %l42
  %t61 = load i64, ptr %l42
  %t62 = icmp sgt i64 %t61, 0
  store i1 %t62, ptr %l43
  %t63 = load i1, ptr %l43
  br i1 %t63, label %bb12, label %bb13
bb11:
  store i64 0, ptr %l41
  br label %bb15
bb12:
  %t64 = load i64, ptr %l7
  store i64 %t64, ptr %l45
  %t65 = load i64, ptr %l6
  store i64 %t65, ptr %l46
  %t66 = load i64, ptr %l45
  %t67 = load i64, ptr %l46
  %t68 = sub i64 %t66, %t67
  store i64 %t68, ptr %l47
  %t69 = load i64, ptr %l8
  store i64 %t69, ptr %l48
  %t70 = load i64, ptr %l47
  %t71 = load i64, ptr %l48
  %t72 = add i64 %t70, %t71
  store i64 %t72, ptr %l49
  %t73 = load i64, ptr %l49
  %t74 = sub i64 %t73, 1
  store i64 %t74, ptr %l50
  %t75 = load i64, ptr %l8
  store i64 %t75, ptr %l51
  %t76 = load i64, ptr %l50
  %t77 = load i64, ptr %l51
  %t78 = sdiv i64 %t76, %t77
  store i64 %t78, ptr %l52
  %t79 = load i64, ptr %l52
  store i64 %t79, ptr %l44
  br label %bb14
bb13:
  store i64 0, ptr %l44
  br label %bb14
bb14:
  %t80 = load i64, ptr %l44
  store i64 %t80, ptr %l41
  br label %bb15
bb15:
  %t81 = load i64, ptr %l41
  store i64 %t81, ptr %l9
  store i64 0, ptr %l10
  br label %bb16
bb16:
  store %olang.scope zeroinitializer, ptr %s4
  %t82 = load i64, ptr %l10
  store i64 %t82, ptr %l53
  %t83 = load i64, ptr %l9
  store i64 %t83, ptr %l54
  %t84 = load i64, ptr %l53
  %t85 = load i64, ptr %l54
  %t86 = icmp slt i64 %t84, %t85
  store i1 %t86, ptr %l55
  %t87 = load i1, ptr %l55
  %t88 = xor i1 %t87, true
  store i1 %t88, ptr %l56
  %t89 = load i1, ptr %l56
  br i1 %t89, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s4)
  br label %bb26
bb18:
  br label %bb19
bb19:
  %t90 = load i64, ptr %l6
  store i64 %t90, ptr %l57
  %t91 = load i64, ptr %l10
  store i64 %t91, ptr %l58
  %t92 = load i64, ptr %l8
  store i64 %t92, ptr %l59
  %t93 = load i64, ptr %l58
  %t94 = load i64, ptr %l59
  %t95 = mul i64 %t93, %t94
  store i64 %t95, ptr %l60
  %t96 = load i64, ptr %l57
  %t97 = load i64, ptr %l60
  %t98 = add i64 %t96, %t97
  store i64 %t98, ptr %l61
  %t99 = load i64, ptr %l61
  store i64 %t99, ptr %l11
  %t100 = load ptr, ptr %l0
  store ptr %t100, ptr %l62
  %t101 = load ptr, ptr %l62
  %t102 = getelementptr %"compiler/load:Loader", ptr %t101, i32 0, i32 5
  store ptr %t102, ptr %l63
  %t103 = load i64, ptr %l11
  store i64 %t103, ptr %l64
  %t104 = load ptr, ptr %l63
  %t105 = load i64, ptr %l64
  %t106 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t104, i64 %t105)
  store ptr %t106, ptr %l65
  br label %bb20
bb20:
  %t107 = load ptr, ptr %l65
  store ptr %t107, ptr %l66
  %t108 = load ptr, ptr %l66
  %t109 = getelementptr %"compiler/load:Module", ptr %t108, i32 0, i32 1
  %t110 = load { i64, ptr }, ptr %t109
  store { i64, ptr } %t110, ptr %l67
  %t111 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t111, ptr %l68
  %t112 = load { i64, ptr }, ptr %l67
  %t113 = load { i64, ptr }, ptr %l68
  %t114 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t112, { i64, ptr } %t113)
  store i1 %t114, ptr %l69
  br label %bb21
bb21:
  %t115 = load i1, ptr %l69
  br i1 %t115, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s5
  %t116 = load i64, ptr %l11
  store i64 %t116, ptr %l70
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t117 = load i64, ptr %l70
  store i64 %t117, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s4)
  br label %bb25
bb25:
  store %olang.scope zeroinitializer, ptr %s6
  %t118 = load i64, ptr %l10
  store i64 %t118, ptr %l71
  %t119 = load i64, ptr %l71
  %t120 = add i64 %t119, 1
  store i64 %t120, ptr %l72
  %t121 = load i64, ptr %l72
  store i64 %t121, ptr %l10
  call void @__olang_scope_close(ptr %s6)
  br label %bb16
bb26:
  call void @__olang_scope_close(ptr %s3)
  %t122 = load ptr, ptr %l0
  store ptr %t122, ptr %l73
  %t123 = load ptr, ptr %l73
  %t124 = getelementptr %"compiler/load:Loader", ptr %t123, i32 0, i32 5
  store ptr %t124, ptr %l74
  %t125 = load ptr, ptr %l74
  %t126 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v0, ptr %t125)
  store i64 %t126, ptr %l75
  br label %bb27
bb27:
  %t127 = load i64, ptr %l75
  store i64 %t127, ptr %l12
  %t128 = load ptr, ptr %l0
  store ptr %t128, ptr %l76
  %t129 = load ptr, ptr %l76
  %t130 = getelementptr %"compiler/load:Loader", ptr %t129, i32 0, i32 5
  store ptr %t130, ptr %l77
  %t131 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t131, ptr %l78
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s7
  store ptr %s7room, ptr %s7
  %t132 = load { i64, ptr }, ptr %l78
  %t133 = extractvalue { i64, ptr } %t132, 1
  %t134 = extractvalue { i64, ptr } %t132, 0
  call void @__olang_sb_put(ptr %s7, ptr %t133, i64 %t134)
  %t135 = load ptr, ptr %s7
  %t136 = getelementptr %olang.builder, ptr %s7, i32 0, i32 1
  %t137 = load i64, ptr %t136
  %t138 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t137)
  call void @llvm.memcpy.p0.p0.i64(ptr %t138, ptr %t135, i64 %t137, i1 false)
  %t139 = insertvalue { i64, ptr } undef, i64 %t137, 0
  %t140 = insertvalue { i64, ptr } %t139, ptr %t138, 1
  store { i64, ptr } %t140, ptr %l79
  call void @__olang_sb_done(ptr %s7)
  %t141 = load { i64, ptr }, ptr %l79
  %t142 = extractvalue { i64, ptr } %t141, 0
  %t143 = extractvalue { i64, ptr } %t141, 1
  %t144 = mul i64 %t142, 1
  %t145 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t144)
  call void @llvm.memcpy.p0.p0.i64(ptr %t145, ptr %t143, i64 %t144, i1 false)
  %t146 = insertvalue { i64, ptr } undef, i64 %t142, 0
  %t147 = insertvalue { i64, ptr } %t146, ptr %t145, 1
  store { i64, ptr } %t147, ptr %l80
  %t148 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t148, ptr %l81
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s8
  store ptr %s8room, ptr %s8
  %t149 = load { i64, ptr }, ptr %l81
  %t150 = extractvalue { i64, ptr } %t149, 1
  %t151 = extractvalue { i64, ptr } %t149, 0
  call void @__olang_sb_put(ptr %s8, ptr %t150, i64 %t151)
  %t152 = load ptr, ptr %s8
  %t153 = getelementptr %olang.builder, ptr %s8, i32 0, i32 1
  %t154 = load i64, ptr %t153
  %t155 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t154)
  call void @llvm.memcpy.p0.p0.i64(ptr %t155, ptr %t152, i64 %t154, i1 false)
  %t156 = insertvalue { i64, ptr } undef, i64 %t154, 0
  %t157 = insertvalue { i64, ptr } %t156, ptr %t155, 1
  store { i64, ptr } %t157, ptr %l82
  call void @__olang_sb_done(ptr %s8)
  %t158 = load { i64, ptr }, ptr %l82
  %t159 = extractvalue { i64, ptr } %t158, 0
  %t160 = extractvalue { i64, ptr } %t158, 1
  %t161 = mul i64 %t159, 1
  %t162 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t161)
  call void @llvm.memcpy.p0.p0.i64(ptr %t162, ptr %t160, i64 %t161, i1 false)
  %t163 = insertvalue { i64, ptr } undef, i64 %t159, 0
  %t164 = insertvalue { i64, ptr } %t163, ptr %t162, 1
  store { i64, ptr } %t164, ptr %l83
  %t165 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t165, ptr %l84
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s9
  store ptr %s9room, ptr %s9
  %t166 = load { i64, ptr }, ptr %l84
  %t167 = extractvalue { i64, ptr } %t166, 1
  %t168 = extractvalue { i64, ptr } %t166, 0
  call void @__olang_sb_put(ptr %s9, ptr %t167, i64 %t168)
  %t169 = load ptr, ptr %s9
  %t170 = getelementptr %olang.builder, ptr %s9, i32 0, i32 1
  %t171 = load i64, ptr %t170
  %t172 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t171)
  call void @llvm.memcpy.p0.p0.i64(ptr %t172, ptr %t169, i64 %t171, i1 false)
  %t173 = insertvalue { i64, ptr } undef, i64 %t171, 0
  %t174 = insertvalue { i64, ptr } %t173, ptr %t172, 1
  store { i64, ptr } %t174, ptr %l85
  call void @__olang_sb_done(ptr %s9)
  %t175 = load { i64, ptr }, ptr %l85
  %t176 = extractvalue { i64, ptr } %t175, 0
  %t177 = extractvalue { i64, ptr } %t175, 1
  %t178 = mul i64 %t176, 1
  %t179 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t178)
  call void @llvm.memcpy.p0.p0.i64(ptr %t179, ptr %t177, i64 %t178, i1 false)
  %t180 = insertvalue { i64, ptr } undef, i64 %t176, 0
  %t181 = insertvalue { i64, ptr } %t180, ptr %t179, 1
  store { i64, ptr } %t181, ptr %l86
  %t182 = load i1, ptr %l3
  store i1 %t182, ptr %l87
  %t184 = load { i64, ptr }, ptr %l80
  %t185 = load { i64, ptr }, ptr %l83
  %t186 = load { i64, ptr }, ptr %l86
  %t187 = load i1, ptr %l87
  call void @compiler_2fload_3aModule_2ector(ptr %t183, ptr %v0, ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t184, { i64, ptr } %t185, { i64, ptr } %t186, i1 %t187)
  %t188 = load %"compiler/load:Module", ptr %t183
  store %"compiler/load:Module" %t188, ptr %l88
  br label %bb28
bb28:
  %t189 = load %"compiler/load:Module", ptr %l88
  %t190 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 240, i64 8)
  store %"compiler/load:Module" %t189, ptr %t190
  store ptr %t190, ptr %l89
  %t191 = load ptr, ptr %l77
  %t192 = load ptr, ptr %l89
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H4773d10fc8d77771a2093e7ac76ab6ea(ptr %v0, ptr %v0, ptr %t191, ptr %t192)
  br label %bb29
bb29:
  %t193 = load ptr, ptr %l0
  store ptr %t193, ptr %l90
  %t194 = load ptr, ptr %l90
  %t195 = getelementptr %"compiler/load:Loader", ptr %t194, i32 0, i32 5
  store ptr %t195, ptr %l91
  %t196 = load i64, ptr %l12
  store i64 %t196, ptr %l92
  %t197 = load ptr, ptr %l91
  %t198 = load i64, ptr %l92
  %t199 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t197, i64 %t198)
  store ptr %t199, ptr %l93
  br label %bb30
bb30:
  %t200 = load ptr, ptr %l93
  store ptr %t200, ptr %l13
  %t201 = load ptr, ptr %l13
  store ptr %t201, ptr %l94
  %t202 = load ptr, ptr %l13
  store ptr %t202, ptr %l96
  %t203 = load ptr, ptr %l96
  %t204 = getelementptr %"compiler/load:Module", ptr %t203, i32 0, i32 0
  %t205 = load { i64, ptr }, ptr %t204
  store { i64, ptr } %t205, ptr %l97
  %t206 = load { i64, ptr }, ptr %l97
  %t207 = call { i32, %"compiler/source:Source" } @compiler_2fsource_2eRead(ptr %v0, ptr %v0, { i64, ptr } %t206)
  %t208 = extractvalue { i32, %"compiler/source:Source" } %t207, 1
  %t209 = extractvalue { i32, %"compiler/source:Source" } %t207, 0
  store i32 %t209, ptr %l99
  %t210 = icmp ne i32 %t209, 0
  br i1 %t210, label %bb32, label %ok.211
ok.211:
  store %"compiler/source:Source" %t208, ptr %l98
  br label %bb31
bb31:
  %t212 = load %"compiler/source:Source", ptr %l98
  store %"compiler/source:Source" %t212, ptr %l95
  br label %bb43
bb32:
  %t213 = load i32, ptr %l99
  %t214 = ashr i32 %t213, 16
  store i32 %t214, ptr %l100
  %t215 = load i32, ptr %l100
  %t216 = icmp eq i32 %t215, 1
  store i1 %t216, ptr %l101
  %t217 = load i1, ptr %l101
  br i1 %t217, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @.c55)
  unreachable
bb35:
  store %olang.scope zeroinitializer, ptr %s10
  %t218 = load ptr, ptr %l0
  store ptr %t218, ptr %l102
  %t219 = load ptr, ptr %l102
  %t220 = getelementptr %"compiler/load:Loader", ptr %t219, i32 0, i32 4
  %t221 = load ptr, ptr %t220
  store ptr %t221, ptr %l103
  %t222 = load ptr, ptr %l13
  store ptr %t222, ptr %l104
  %t223 = load ptr, ptr %l104
  %t224 = getelementptr %"compiler/load:Module", ptr %t223, i32 0, i32 0
  %t225 = load { i64, ptr }, ptr %t224
  store { i64, ptr } %t225, ptr %l105
  %t226 = load ptr, ptr %l103
  %t227 = load { i64, ptr }, ptr %l105
  %t228 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAddFile(ptr %v0, ptr %v0, ptr %v0, ptr %t226, { i64, ptr } %t227, { i64, ptr } { i64 0, ptr @.d56 }, i1 false)
  store i64 %t228, ptr %l106
  br label %bb36
bb36:
  %t229 = load i64, ptr %l106
  store i64 %t229, ptr %l14
  %t230 = load ptr, ptr %l0
  store ptr %t230, ptr %l107
  %t231 = load ptr, ptr %l107
  %t232 = getelementptr %"compiler/load:Loader", ptr %t231, i32 0, i32 4
  %t233 = load ptr, ptr %t232
  store ptr %t233, ptr %l108
  %t234 = load i64, ptr %l14
  store i64 %t234, ptr %l109
  store { i64, [3 x i64] } zeroinitializer, ptr %t235
  %t236 = getelementptr { i64, [3 x i64] }, ptr %t235, i32 0, i32 0
  store i64 1, ptr %t236
  %t237 = load i64, ptr %l109
  %t238 = insertvalue { i64 } undef, i64 %t237, 0
  %t239 = getelementptr { i64, [3 x i64] }, ptr %t235, i32 0, i32 1
  store { i64 } %t238, ptr %t239
  %t240 = load { i64, [3 x i64] }, ptr %t235
  store { i64, [3 x i64] } %t240, ptr %l110
  %t241 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %s10)
  store %"compiler/msgs:Msg" %t241, ptr %l111
  br label %bb37
bb37:
  %t242 = load ptr, ptr %l108
  %t243 = load { i64, [3 x i64] }, ptr %l110
  %t244 = load %"compiler/msgs:Msg", ptr %l111
  %t245 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s10, ptr %t242, { i64, [3 x i64] } %t243, %"compiler/msgs:Msg" %t244)
  store i64 %t245, ptr %l112
  br label %bb38
bb38:
  %t246 = load ptr, ptr %l0
  store ptr %t246, ptr %l114
  %t247 = load ptr, ptr %l114
  %t248 = getelementptr %"compiler/load:Loader", ptr %t247, i32 0, i32 5
  store ptr %t248, ptr %l115
  %t249 = load ptr, ptr %l115
  %t250 = call { i32, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H78ccce95e6ef2f62693281865bce11fb(ptr %v0, ptr %v0, ptr %t249)
  %t251 = extractvalue { i32, ptr } %t250, 1
  %t252 = extractvalue { i32, ptr } %t250, 0
  store i32 %t252, ptr %l117
  %t253 = icmp ne i32 %t252, 0
  br i1 %t253, label %bb40, label %ok.254
ok.254:
  store ptr %t251, ptr %l116
  br label %bb39
bb39:
  %t255 = load ptr, ptr %l116
  store ptr %t255, ptr %l113
  br label %bb42
bb40:
  br label %bb41
bb41:
  store %olang.scope zeroinitializer, ptr %s11
  call void @__olang_scope_close(ptr %s11)
  br label %bb42
bb42:
  store i64 -1, ptr %l118
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  %t256 = load i64, ptr %l118
  store i64 %t256, ptr %rv
  br label %ret
bb43:
  %t257 = load %"compiler/source:Source", ptr %l95
  %t258 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store %"compiler/source:Source" %t257, ptr %t258
  store ptr %t258, ptr %l119
  %t259 = load ptr, ptr %l119
  %t260 = load ptr, ptr %l94
  %t261 = getelementptr %"compiler/load:Module", ptr %t260, i32 0, i32 5
  store ptr %t259, ptr %t261
  %t262 = load ptr, ptr %l13
  store ptr %t262, ptr %l120
  %t263 = load ptr, ptr %l0
  store ptr %t263, ptr %l121
  %t264 = load ptr, ptr %l121
  %t265 = getelementptr %"compiler/load:Loader", ptr %t264, i32 0, i32 4
  %t266 = load ptr, ptr %t265
  store ptr %t266, ptr %l122
  %t267 = load ptr, ptr %l13
  store ptr %t267, ptr %l123
  %t268 = load ptr, ptr %l123
  %t269 = getelementptr %"compiler/load:Module", ptr %t268, i32 0, i32 0
  %t270 = load { i64, ptr }, ptr %t269
  store { i64, ptr } %t270, ptr %l124
  %t271 = load ptr, ptr %l13
  store ptr %t271, ptr %l125
  %t272 = load ptr, ptr %l125
  %t273 = getelementptr %"compiler/load:Module", ptr %t272, i32 0, i32 5
  %t274 = load ptr, ptr %t273
  store ptr %t274, ptr %l126
  %t275 = load ptr, ptr %l126
  %t276 = getelementptr %"compiler/source:Source", ptr %t275, i32 0, i32 1
  %t277 = load { i64, ptr }, ptr %t276
  store { i64, ptr } %t277, ptr %l127
  %t278 = load ptr, ptr %l13
  store ptr %t278, ptr %l128
  %t279 = load ptr, ptr %l128
  %t280 = getelementptr %"compiler/load:Module", ptr %t279, i32 0, i32 2
  %t281 = load { i64, ptr }, ptr %t280
  store { i64, ptr } %t281, ptr %l129
  %t282 = load { i64, ptr }, ptr %l129
  %t283 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t282, { i64, ptr } { i64 4, ptr @.d57 })
  store i1 %t283, ptr %l130
  br label %bb44
bb44:
  %t284 = load ptr, ptr %l122
  %t285 = load { i64, ptr }, ptr %l124
  %t286 = load { i64, ptr }, ptr %l127
  %t287 = load i1, ptr %l130
  %t288 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAddFile(ptr %v0, ptr %v0, ptr %v0, ptr %t284, { i64, ptr } %t285, { i64, ptr } %t286, i1 %t287)
  store i64 %t288, ptr %l131
  br label %bb45
bb45:
  %t289 = load i64, ptr %l131
  %t290 = load ptr, ptr %l120
  %t291 = getelementptr %"compiler/load:Module", ptr %t290, i32 0, i32 4
  store i64 %t289, ptr %t291
  %t292 = load ptr, ptr %l13
  store ptr %t292, ptr %l132
  %t293 = load ptr, ptr %l13
  store ptr %t293, ptr %l133
  %t294 = load ptr, ptr %l133
  %t295 = getelementptr %"compiler/load:Module", ptr %t294, i32 0, i32 5
  %t296 = load ptr, ptr %t295
  store ptr %t296, ptr %l134
  %t297 = load ptr, ptr %l134
  %t298 = getelementptr %"compiler/source:Source", ptr %t297, i32 0, i32 1
  %t299 = load { i64, ptr }, ptr %t298
  store { i64, ptr } %t299, ptr %l135
  %t300 = load { i64, ptr }, ptr %l135
  %t301 = call %"compiler/scan:Tokens" @compiler_2fscan_2eScan(ptr %v0, ptr %v0, { i64, ptr } %t300)
  store %"compiler/scan:Tokens" %t301, ptr %l136
  br label %bb46
bb46:
  %t302 = load %"compiler/scan:Tokens", ptr %l136
  %t303 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 64, i64 8)
  store %"compiler/scan:Tokens" %t302, ptr %t303
  store ptr %t303, ptr %l137
  %t304 = load ptr, ptr %l137
  %t305 = load ptr, ptr %l132
  %t306 = getelementptr %"compiler/load:Module", ptr %t305, i32 0, i32 6
  store ptr %t304, ptr %t306
  store %olang.scope zeroinitializer, ptr %s12
  %t307 = load ptr, ptr %l13
  store ptr %t307, ptr %l138
  %t308 = load ptr, ptr %l138
  %t309 = getelementptr %"compiler/load:Module", ptr %t308, i32 0, i32 6
  %t310 = load ptr, ptr %t309
  store ptr %t310, ptr %l139
  %t311 = load ptr, ptr %l139
  %t312 = getelementptr %"compiler/scan:Tokens", ptr %t311, i32 0, i32 3
  %t313 = load { i64, ptr }, ptr %t312
  store { i64, ptr } %t313, ptr %l140
  %t314 = load { i64, ptr }, ptr %l140
  store { i64, ptr } %t314, ptr %l15
  store i64 0, ptr %l16
  %t315 = load { i64, ptr }, ptr %l15
  store { i64, ptr } %t315, ptr %l141
  %t316 = load { i64, ptr }, ptr %l141
  %t317 = extractvalue { i64, ptr } %t316, 0
  store i64 %t317, ptr %l142
  %t318 = load i64, ptr %l142
  store i64 %t318, ptr %l17
  br label %bb47
bb47:
  store %olang.scope zeroinitializer, ptr %s13
  %t319 = load i64, ptr %l16
  store i64 %t319, ptr %l143
  %t320 = load i64, ptr %l17
  store i64 %t320, ptr %l144
  %t321 = load i64, ptr %l143
  %t322 = load i64, ptr %l144
  %t323 = icmp slt i64 %t321, %t322
  store i1 %t323, ptr %l145
  %t324 = load i1, ptr %l145
  %t325 = xor i1 %t324, true
  store i1 %t325, ptr %l146
  %t326 = load i1, ptr %l146
  br i1 %t326, label %bb48, label %bb49
bb48:
  call void @__olang_scope_close(ptr %s13)
  br label %bb56
bb49:
  br label %bb50
bb50:
  %t327 = load { i64, ptr }, ptr %l15
  store { i64, ptr } %t327, ptr %l147
  %t328 = load i64, ptr %l16
  store i64 %t328, ptr %l148
  %t329 = load i64, ptr %l148
  %t330 = getelementptr { i64, ptr }, ptr %l147, i32 0, i32 1
  %t331 = load ptr, ptr %t330
  %t332 = getelementptr %"compiler/scan:Diag", ptr %t331, i64 %t329
  %t333 = load %"compiler/scan:Diag", ptr %t332
  store %"compiler/scan:Diag" %t333, ptr %l149
  %t334 = load %"compiler/scan:Diag", ptr %l149
  store %"compiler/scan:Diag" %t334, ptr %l18
  %t335 = getelementptr %"compiler/scan:Diag", ptr %l18, i32 0, i32 1
  %t336 = load i32, ptr %t335
  store i32 %t336, ptr %l150
  %t337 = load i32, ptr %l150
  store i32 %t337, ptr %l19
  %t338 = load ptr, ptr %l0
  store ptr %t338, ptr %l151
  %t339 = load ptr, ptr %l151
  %t340 = getelementptr %"compiler/load:Loader", ptr %t339, i32 0, i32 4
  %t341 = load ptr, ptr %t340
  store ptr %t341, ptr %l152
  %t342 = load ptr, ptr %l13
  store ptr %t342, ptr %l153
  %t343 = load ptr, ptr %l153
  %t344 = getelementptr %"compiler/load:Module", ptr %t343, i32 0, i32 4
  %t345 = load i64, ptr %t344
  store i64 %t345, ptr %l154
  %t346 = load i32, ptr %l19
  store i32 %t346, ptr %l155
  %t347 = load i32, ptr %l155
  %t348 = sext i32 %t347 to i64
  store i64 %t348, ptr %l156
  %t349 = getelementptr %"compiler/scan:Diag", ptr %l18, i32 0, i32 2
  %t350 = load i32, ptr %t349
  store i32 %t350, ptr %l157
  %t351 = load i32, ptr %l157
  %t352 = sext i32 %t351 to i64
  store i64 %t352, ptr %l158
  store { i64, [3 x i64] } zeroinitializer, ptr %t353
  %t354 = getelementptr { i64, [3 x i64] }, ptr %t353, i32 0, i32 0
  store i64 3, ptr %t354
  %t355 = load i64, ptr %l154
  %t356 = insertvalue { i64, i64, i64 } undef, i64 %t355, 0
  %t357 = load i64, ptr %l156
  %t358 = insertvalue { i64, i64, i64 } %t356, i64 %t357, 1
  %t359 = load i64, ptr %l158
  %t360 = insertvalue { i64, i64, i64 } %t358, i64 %t359, 2
  %t361 = getelementptr { i64, [3 x i64] }, ptr %t353, i32 0, i32 1
  store { i64, i64, i64 } %t360, ptr %t361
  %t362 = load { i64, [3 x i64] }, ptr %t353
  store { i64, [3 x i64] } %t362, ptr %l159
  store i32 42, ptr %l160
  %t363 = load %"compiler/scan:Diag", ptr %l18
  store %"compiler/scan:Diag" %t363, ptr %l161
  %t364 = load %"compiler/scan:Diag", ptr %l161
  %t365 = call { i64, ptr } @compiler_2fscan_2ecompiler_2fscan_3aDiag_2eRule(ptr %s13, %"compiler/scan:Diag" %t364)
  store { i64, ptr } %t365, ptr %l162
  br label %bb51
bb51:
  %t366 = load %"compiler/scan:Diag", ptr %l18
  store %"compiler/scan:Diag" %t366, ptr %l163
  %t367 = load %"compiler/scan:Diag", ptr %l163
  %t368 = call { i64, ptr } @compiler_2fscan_2ecompiler_2fscan_3aDiag_2eMessage(ptr %s13, %"compiler/scan:Diag" %t367)
  store { i64, ptr } %t368, ptr %l164
  br label %bb52
bb52:
  %t369 = load { i64, ptr }, ptr %l164
  %t370 = extractvalue { i64, ptr } %t369, 0
  %t371 = extractvalue { i64, ptr } %t369, 1
  %t372 = mul i64 %t370, 1
  %t373 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t372)
  call void @llvm.memcpy.p0.p0.i64(ptr %t373, ptr %t371, i64 %t372, i1 false)
  %t374 = insertvalue { i64, ptr } undef, i64 %t370, 0
  %t375 = insertvalue { i64, ptr } %t374, ptr %t373, 1
  store { i64, ptr } %t375, ptr %l165
  %t376 = load i32, ptr %l160
  %t377 = load { i64, ptr }, ptr %l162
  %t378 = load { i64, ptr }, ptr %l165
  %t379 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %s13, ptr %s13, ptr %s13, i32 %t376, { i64, ptr } %t377, { i64, ptr } %t378)
  store %"compiler/msgs:Msg" %t379, ptr %l166
  br label %bb53
bb53:
  %t380 = load ptr, ptr %l152
  %t381 = load { i64, [3 x i64] }, ptr %l159
  %t382 = load %"compiler/msgs:Msg", ptr %l166
  %t383 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s13, ptr %t380, { i64, [3 x i64] } %t381, %"compiler/msgs:Msg" %t382)
  store i64 %t383, ptr %l167
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s13)
  br label %bb55
bb55:
  store %olang.scope zeroinitializer, ptr %s14
  %t384 = load i64, ptr %l16
  store i64 %t384, ptr %l168
  %t385 = load i64, ptr %l168
  %t386 = add i64 %t385, 1
  store i64 %t386, ptr %l169
  %t387 = load i64, ptr %l169
  store i64 %t387, ptr %l16
  call void @__olang_scope_close(ptr %s14)
  br label %bb47
bb56:
  call void @__olang_scope_close(ptr %s12)
  %t388 = load ptr, ptr %l0
  store ptr %t388, ptr %l170
  %t389 = load ptr, ptr %l13
  store ptr %t389, ptr %l171
  %t390 = load ptr, ptr %l170
  %t391 = load ptr, ptr %l171
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2eprescan(ptr %v0, ptr %v0, ptr %t390, ptr %t391)
  br label %bb57
bb57:
  %t392 = load ptr, ptr %l13
  store ptr %t392, ptr %l172
  %t393 = call %"compiler/parse:Oracle" @compiler_2fparse_3aOracle_2ector(ptr %v0)
  store %"compiler/parse:Oracle" %t393, ptr %l173
  br label %bb58
bb58:
  %t394 = load %"compiler/parse:Oracle", ptr %l173
  %t395 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store %"compiler/parse:Oracle" %t394, ptr %t395
  store ptr %t395, ptr %l174
  %t396 = load ptr, ptr %l174
  %t397 = load ptr, ptr %l172
  %t398 = getelementptr %"compiler/load:Module", ptr %t397, i32 0, i32 10
  store ptr %t396, ptr %t398
  %t399 = load ptr, ptr %l0
  store ptr %t399, ptr %l175
  %t400 = load ptr, ptr %l13
  store ptr %t400, ptr %l176
  %t401 = load ptr, ptr %l175
  %t402 = load ptr, ptr %l176
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2eownNames(ptr %v0, ptr %v0, ptr %t401, ptr %t402)
  br label %bb59
bb59:
  %t403 = load ptr, ptr %l0
  store ptr %t403, ptr %l177
  %t404 = load i64, ptr %l12
  store i64 %t404, ptr %l178
  %t405 = load ptr, ptr %l177
  %t406 = load i64, ptr %l178
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2eloadImports(ptr %v0, ptr %t405, i64 %t406)
  br label %bb60
bb60:
  %t407 = load ptr, ptr %l0
  store ptr %t407, ptr %l179
  %t408 = load i64, ptr %l12
  store i64 %t408, ptr %l180
  %t409 = load ptr, ptr %l179
  %t410 = load i64, ptr %l180
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2eparse(ptr %v0, ptr %t409, i64 %t410)
  br label %bb61
bb61:
  %t411 = load i64, ptr %l12
  store i64 %t411, ptr %l181
  call void @__olang_scope_close(ptr %s0)
  %t412 = load i64, ptr %l181
  store i64 %t412, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fload_2ecompiler_2fload_3aLoader_2eloadImports(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"compiler/load:Import"
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca %"compiler/load:Import"
  %l13 = alloca { { i64, ptr }, { i64, ptr } }
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i1
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca %"compiler/load:Import"
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca i64
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca ptr
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i1
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i1
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i1
  %l51 = alloca i1
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i64
  %l57 = alloca ptr
  %l58 = alloca ptr
  %l59 = alloca i64
  %l60 = alloca %"compiler/load:Import"
  %l61 = alloca i64
  %l62 = alloca i1
  %l63 = alloca i1
  %l64 = alloca i64
  %l65 = alloca i1
  %l66 = alloca ptr
  %l67 = alloca i64
  %l68 = alloca i64
  %l69 = alloca i64
  %l70 = alloca i1
  %l71 = alloca i64
  %l72 = alloca ptr
  %l73 = alloca ptr
  %l74 = alloca i64
  %l75 = alloca %"compiler/load:Import"
  %l76 = alloca i64
  %l77 = alloca ptr
  %l78 = alloca ptr
  %l79 = alloca i64
  %l80 = alloca %"compiler/load:Import"
  %l81 = alloca { i64, ptr }
  %l82 = alloca i1
  %l83 = alloca i1
  %l84 = alloca ptr
  %l85 = alloca ptr
  %l86 = alloca ptr
  %l87 = alloca ptr
  %l88 = alloca %"compiler/source:Span"
  %l89 = alloca { i64, [3 x i64] }
  %l90 = alloca { i64, ptr }
  %l91 = alloca %"compiler/msgs:Msg"
  %l92 = alloca i64
  %l93 = alloca { { i64, ptr }, { i64, ptr } }
  %l94 = alloca ptr
  %l95 = alloca i64
  %l96 = alloca %"compiler/load:Import"
  %l97 = alloca { { i64, ptr }, { i64, ptr } }
  %l98 = alloca i32
  %l99 = alloca { i64, ptr }
  %l100 = alloca i64
  %l101 = alloca { i64, ptr }
  %l102 = alloca { i64, ptr }
  %l103 = alloca i64
  %l104 = alloca { i64, ptr }
  %l105 = alloca ptr
  %l106 = alloca { i64, ptr }
  %l107 = alloca { i64, ptr }
  %l108 = alloca i64
  %l109 = alloca i64
  %l110 = alloca i1
  %l111 = alloca ptr
  %l112 = alloca ptr
  %l113 = alloca i64
  %l114 = alloca i64
  %l115 = alloca i64
  %l116 = alloca i1
  %l117 = alloca i64
  %l118 = alloca i64
  %l119 = alloca i1
  %l120 = alloca i64
  %l121 = alloca i64
  %l122 = alloca i64
  %l123 = alloca i64
  %l124 = alloca i64
  %l125 = alloca i64
  %l126 = alloca i64
  %l127 = alloca i64
  %l128 = alloca i64
  %l129 = alloca i64
  %l130 = alloca i64
  %l131 = alloca i1
  %l132 = alloca i1
  %l133 = alloca i64
  %l134 = alloca i64
  %l135 = alloca i64
  %l136 = alloca i64
  %l137 = alloca i64
  %l138 = alloca i64
  %l139 = alloca i64
  %l140 = alloca i1
  %l141 = alloca i1
  %l142 = alloca ptr
  %l143 = alloca ptr
  %l144 = alloca i64
  %l145 = alloca %"compiler/load:Import"
  %l146 = alloca i64
  %l147 = alloca i1
  %l148 = alloca i1
  %l149 = alloca ptr
  %l150 = alloca ptr
  %l151 = alloca i64
  %l152 = alloca %"compiler/load:Import"
  %l153 = alloca { i64, ptr }
  %l154 = alloca { i64, ptr }
  %l155 = alloca i1
  %l156 = alloca i64
  %l157 = alloca i64
  %l158 = alloca i1
  %l159 = alloca ptr
  %l160 = alloca ptr
  %l161 = alloca ptr
  %l162 = alloca ptr
  %l163 = alloca %"compiler/source:Span"
  %l164 = alloca { i64, [3 x i64] }
  %l165 = alloca { i64, ptr }
  %l166 = alloca %"compiler/msgs:Msg"
  %l167 = alloca i64
  %l168 = alloca i64
  %l169 = alloca ptr
  %l170 = alloca ptr
  %l171 = alloca i64
  %l172 = alloca %"compiler/load:Import"
  %l173 = alloca i64
  %l174 = alloca ptr
  %l175 = alloca ptr
  %l176 = alloca i64
  %l177 = alloca %"compiler/load:Import"
  %l178 = alloca i64
  %l179 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l26
  %t2 = load ptr, ptr %l26
  %t3 = getelementptr %"compiler/load:Loader", ptr %t2, i32 0, i32 5
  store ptr %t3, ptr %l27
  %t4 = load i64, ptr %l1
  store i64 %t4, ptr %l28
  %t5 = load ptr, ptr %l27
  %t6 = load i64, ptr %l28
  %t7 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t5, i64 %t6)
  store ptr %t7, ptr %l29
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l29
  store ptr %t8, ptr %l2
  store %olang.scope zeroinitializer, ptr %s1
  store i64 0, ptr %l3
  %t9 = load ptr, ptr %l2
  store ptr %t9, ptr %l30
  %t10 = load ptr, ptr %l30
  %t11 = getelementptr %"compiler/load:Module", ptr %t10, i32 0, i32 9
  store ptr %t11, ptr %l31
  %t12 = load ptr, ptr %l31
  %t13 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2eLen_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %t12)
  store i64 %t13, ptr %l32
  br label %bb2
bb2:
  %t14 = load i64, ptr %l32
  store i64 %t14, ptr %l4
  store i64 1, ptr %l5
  %t15 = load i64, ptr %l4
  store i64 %t15, ptr %l33
  %t16 = load i64, ptr %l3
  store i64 %t16, ptr %l34
  %t17 = load i64, ptr %l33
  %t18 = load i64, ptr %l34
  %t19 = icmp sgt i64 %t17, %t18
  store i1 %t19, ptr %l35
  %t20 = load i1, ptr %l35
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t21 = load i64, ptr %l5
  store i64 %t21, ptr %l37
  %t22 = load i64, ptr %l37
  %t23 = icmp sgt i64 %t22, 0
  store i1 %t23, ptr %l38
  %t24 = load i1, ptr %l38
  br i1 %t24, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l36
  br label %bb8
bb5:
  %t25 = load i64, ptr %l4
  store i64 %t25, ptr %l40
  %t26 = load i64, ptr %l3
  store i64 %t26, ptr %l41
  %t27 = load i64, ptr %l40
  %t28 = load i64, ptr %l41
  %t29 = sub i64 %t27, %t28
  store i64 %t29, ptr %l42
  %t30 = load i64, ptr %l5
  store i64 %t30, ptr %l43
  %t31 = load i64, ptr %l42
  %t32 = load i64, ptr %l43
  %t33 = add i64 %t31, %t32
  store i64 %t33, ptr %l44
  %t34 = load i64, ptr %l44
  %t35 = sub i64 %t34, 1
  store i64 %t35, ptr %l45
  %t36 = load i64, ptr %l5
  store i64 %t36, ptr %l46
  %t37 = load i64, ptr %l45
  %t38 = load i64, ptr %l46
  %t39 = sdiv i64 %t37, %t38
  store i64 %t39, ptr %l47
  %t40 = load i64, ptr %l47
  store i64 %t40, ptr %l39
  br label %bb7
bb6:
  store i64 0, ptr %l39
  br label %bb7
bb7:
  %t41 = load i64, ptr %l39
  store i64 %t41, ptr %l36
  br label %bb8
bb8:
  %t42 = load i64, ptr %l36
  store i64 %t42, ptr %l6
  store i64 0, ptr %l7
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t43 = load i64, ptr %l7
  store i64 %t43, ptr %l48
  %t44 = load i64, ptr %l6
  store i64 %t44, ptr %l49
  %t45 = load i64, ptr %l48
  %t46 = load i64, ptr %l49
  %t47 = icmp slt i64 %t45, %t46
  store i1 %t47, ptr %l50
  %t48 = load i1, ptr %l50
  %t49 = xor i1 %t48, true
  store i1 %t49, ptr %l51
  %t50 = load i1, ptr %l51
  br i1 %t50, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb75
bb11:
  br label %bb12
bb12:
  %t51 = load i64, ptr %l3
  store i64 %t51, ptr %l52
  %t52 = load i64, ptr %l7
  store i64 %t52, ptr %l53
  %t53 = load i64, ptr %l5
  store i64 %t53, ptr %l54
  %t54 = load i64, ptr %l53
  %t55 = load i64, ptr %l54
  %t56 = mul i64 %t54, %t55
  store i64 %t56, ptr %l55
  %t57 = load i64, ptr %l52
  %t58 = load i64, ptr %l55
  %t59 = add i64 %t57, %t58
  store i64 %t59, ptr %l56
  %t60 = load i64, ptr %l56
  store i64 %t60, ptr %l8
  %t61 = load ptr, ptr %l2
  store ptr %t61, ptr %l57
  %t62 = load ptr, ptr %l57
  %t63 = getelementptr %"compiler/load:Module", ptr %t62, i32 0, i32 9
  store ptr %t63, ptr %l58
  %t64 = load i64, ptr %l8
  store i64 %t64, ptr %l59
  %t65 = load ptr, ptr %l58
  %t66 = load i64, ptr %l59
  %t67 = call %"compiler/load:Import" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2eAt_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v0, ptr %t65, i64 %t66)
  store %"compiler/load:Import" %t67, ptr %l60
  br label %bb13
bb13:
  %t68 = load %"compiler/load:Import", ptr %l60
  store %"compiler/load:Import" %t68, ptr %l9
  %t69 = getelementptr %"compiler/load:Import", ptr %l9, i32 0, i32 5
  %t70 = load i64, ptr %t69
  store i64 %t70, ptr %l61
  %t71 = load i64, ptr %l61
  %t72 = icmp sge i64 %t71, 0
  store i1 %t72, ptr %l62
  %t73 = load i1, ptr %l62
  br i1 %t73, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l63
  br label %bb16
bb15:
  %t74 = getelementptr %"compiler/load:Import", ptr %l9, i32 0, i32 5
  %t75 = load i64, ptr %t74
  store i64 %t75, ptr %l64
  %t76 = load i64, ptr %l64
  %t77 = icmp eq i64 %t76, -2
  store i1 %t77, ptr %l65
  %t78 = load i1, ptr %l65
  store i1 %t78, ptr %l63
  br label %bb16
bb16:
  %t79 = load i1, ptr %l63
  br i1 %t79, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s3
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  br label %bb74
bb18:
  br label %bb19
bb19:
  %t80 = load ptr, ptr %l0
  store ptr %t80, ptr %l66
  %t81 = load i64, ptr %l1
  store i64 %t81, ptr %l67
  %t82 = getelementptr %"compiler/load:Import", ptr %l9, i32 0, i32 4
  %t83 = load i64, ptr %t82
  store i64 %t83, ptr %l68
  %t84 = load ptr, ptr %l66
  %t85 = load i64, ptr %l67
  %t86 = load i64, ptr %l68
  %t87 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2etaken(ptr %v0, ptr %t84, i64 %t85, i64 %t86)
  store i64 %t87, ptr %l69
  br label %bb20
bb20:
  %t88 = load i64, ptr %l69
  %t89 = icmp ne i64 %t88, 1
  store i1 %t89, ptr %l70
  %t90 = load i1, ptr %l70
  br i1 %t90, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s4
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  br label %bb74
bb22:
  br label %bb23
bb23:
  %t91 = load i64, ptr %l8
  store i64 %t91, ptr %l71
  %t92 = load i64, ptr %l71
  store i64 %t92, ptr %l10
  store i64 -2, ptr %l11
  %t93 = load ptr, ptr %l2
  store ptr %t93, ptr %l72
  %t94 = load ptr, ptr %l72
  %t95 = getelementptr %"compiler/load:Module", ptr %t94, i32 0, i32 9
  store ptr %t95, ptr %l73
  %t96 = load i64, ptr %l10
  store i64 %t96, ptr %l74
  %t97 = load ptr, ptr %l73
  %t98 = load i64, ptr %l74
  %t99 = call %"compiler/load:Import" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2eAt_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v0, ptr %t97, i64 %t98)
  store %"compiler/load:Import" %t99, ptr %l75
  br label %bb24
bb24:
  %t100 = load %"compiler/load:Import", ptr %l75
  store %"compiler/load:Import" %t100, ptr %l12
  %t101 = load i64, ptr %l11
  store i64 %t101, ptr %l76
  %t102 = load i64, ptr %l76
  %t103 = getelementptr %"compiler/load:Import", ptr %l12, i32 0, i32 5
  store i64 %t102, ptr %t103
  %t104 = load ptr, ptr %l2
  store ptr %t104, ptr %l77
  %t105 = load ptr, ptr %l77
  %t106 = getelementptr %"compiler/load:Module", ptr %t105, i32 0, i32 9
  store ptr %t106, ptr %l78
  %t107 = load i64, ptr %l10
  store i64 %t107, ptr %l79
  %t108 = load %"compiler/load:Import", ptr %l12
  store %"compiler/load:Import" %t108, ptr %l80
  %t109 = load ptr, ptr %l78
  %t110 = load i64, ptr %l79
  %t111 = load %"compiler/load:Import", ptr %l80
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2eSetAt_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v0, ptr %t109, i64 %t110, %"compiler/load:Import" %t111)
  br label %bb25
bb25:
  %t112 = getelementptr %"compiler/load:Import", ptr %l9, i32 0, i32 2
  %t113 = load { i64, ptr }, ptr %t112
  store { i64, ptr } %t113, ptr %l81
  %t114 = load { i64, ptr }, ptr %l81
  %t115 = call i1 @compiler_2fload_2eAliasShape(ptr %v0, { i64, ptr } %t114)
  store i1 %t115, ptr %l82
  br label %bb26
bb26:
  %t116 = load i1, ptr %l82
  %t117 = xor i1 %t116, true
  store i1 %t117, ptr %l83
  %t118 = load i1, ptr %l83
  br i1 %t118, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s5
  %t119 = load ptr, ptr %l0
  store ptr %t119, ptr %l84
  %t120 = load ptr, ptr %l84
  %t121 = getelementptr %"compiler/load:Loader", ptr %t120, i32 0, i32 4
  %t122 = load ptr, ptr %t121
  store ptr %t122, ptr %l85
  %t123 = load ptr, ptr %l0
  store ptr %t123, ptr %l86
  %t124 = load ptr, ptr %l2
  store ptr %t124, ptr %l87
  %t125 = getelementptr %"compiler/load:Import", ptr %l9, i32 0, i32 1
  %t126 = load %"compiler/source:Span", ptr %t125
  store %"compiler/source:Span" %t126, ptr %l88
  %t127 = load ptr, ptr %l86
  %t128 = load ptr, ptr %l87
  %t129 = load %"compiler/source:Span", ptr %l88
  %t130 = call { i64, [3 x i64] } @compiler_2fload_2ecompiler_2fload_3aLoader_2eat(ptr %v0, ptr %v0, ptr %t127, ptr %t128, %"compiler/source:Span" %t129)
  store { i64, [3 x i64] } %t130, ptr %l89
  br label %bb29
bb28:
  br label %bb32
bb29:
  %t131 = getelementptr %"compiler/load:Import", ptr %l9, i32 0, i32 2
  %t132 = load { i64, ptr }, ptr %t131
  store { i64, ptr } %t132, ptr %l90
  %t133 = load { i64, ptr }, ptr %l90
  %t134 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportAliasInvalid(ptr %v0, ptr %s5, { i64, ptr } %t133)
  store %"compiler/msgs:Msg" %t134, ptr %l91
  br label %bb30
bb30:
  %t135 = load ptr, ptr %l85
  %t136 = load { i64, [3 x i64] }, ptr %l89
  %t137 = load %"compiler/msgs:Msg", ptr %l91
  %t138 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s5, ptr %t135, { i64, [3 x i64] } %t136, %"compiler/msgs:Msg" %t137)
  store i64 %t138, ptr %l92
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s2)
  br label %bb74
bb32:
  %t139 = load ptr, ptr %l0
  store ptr %t139, ptr %l94
  %t140 = load i64, ptr %l1
  store i64 %t140, ptr %l95
  %t141 = load %"compiler/load:Import", ptr %l9
  store %"compiler/load:Import" %t141, ptr %l96
  %t142 = load ptr, ptr %l94
  %t143 = load i64, ptr %l95
  %t144 = load %"compiler/load:Import", ptr %l96
  %t145 = call { i32, { { i64, ptr }, { i64, ptr } } } @compiler_2fload_2ecompiler_2fload_3aLoader_2eresolve(ptr %v0, ptr %v0, ptr %s2, ptr %t142, i64 %t143, %"compiler/load:Import" %t144)
  %t146 = extractvalue { i32, { { i64, ptr }, { i64, ptr } } } %t145, 1
  %t147 = extractvalue { i32, { { i64, ptr }, { i64, ptr } } } %t145, 0
  store i32 %t147, ptr %l98
  %t148 = icmp ne i32 %t147, 0
  br i1 %t148, label %bb34, label %ok.149
ok.149:
  store { { i64, ptr }, { i64, ptr } } %t146, ptr %l97
  br label %bb33
bb33:
  %t150 = load { { i64, ptr }, { i64, ptr } }, ptr %l97
  store { { i64, ptr }, { i64, ptr } } %t150, ptr %l93
  br label %bb36
bb34:
  br label %bb35
bb35:
  store %olang.scope zeroinitializer, ptr %s6
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s2)
  br label %bb74
bb36:
  %t151 = load { { i64, ptr }, { i64, ptr } }, ptr %l93
  store { { i64, ptr }, { i64, ptr } } %t151, ptr %l13
  %t152 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l13, i32 0, i32 0
  %t153 = load { i64, ptr }, ptr %t152
  store { i64, ptr } %t153, ptr %l99
  %t154 = load { i64, ptr }, ptr %l99
  %t155 = extractvalue { i64, ptr } %t154, 0
  store i64 %t155, ptr %l100
  %t156 = load i64, ptr %l100
  %t157 = mul i64 %t156, 1
  %t158 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t157)
  %t159 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t160 = insertvalue { i64, ptr } %t159, ptr %t158, 1
  store { i64, ptr } %t160, ptr %l101
  %t161 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t162 = load ptr, ptr %t161
  %t163 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t164 = load ptr, ptr %t163
  %t165 = load i64, ptr %l100
  %t166 = mul i64 %t165, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t162, ptr %t164, i64 %t166, i1 false)
  %t167 = load { i64, ptr }, ptr %l101
  store { i64, ptr } %t167, ptr %l14
  %t168 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l13, i32 0, i32 1
  %t169 = load { i64, ptr }, ptr %t168
  store { i64, ptr } %t169, ptr %l102
  %t170 = load { i64, ptr }, ptr %l102
  %t171 = extractvalue { i64, ptr } %t170, 0
  store i64 %t171, ptr %l103
  %t172 = load i64, ptr %l103
  %t173 = mul i64 %t172, 1
  %t174 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t173)
  %t175 = insertvalue { i64, ptr } undef, i64 %t172, 0
  %t176 = insertvalue { i64, ptr } %t175, ptr %t174, 1
  store { i64, ptr } %t176, ptr %l104
  %t177 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t178 = load ptr, ptr %t177
  %t179 = getelementptr { i64, ptr }, ptr %l102, i32 0, i32 1
  %t180 = load ptr, ptr %t179
  %t181 = load i64, ptr %l103
  %t182 = mul i64 %t181, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t178, ptr %t180, i64 %t182, i1 false)
  %t183 = load { i64, ptr }, ptr %l104
  store { i64, ptr } %t183, ptr %l15
  %t184 = load ptr, ptr %l0
  store ptr %t184, ptr %l105
  %t185 = load { i64, ptr }, ptr %l14
  store { i64, ptr } %t185, ptr %l106
  %t186 = load { i64, ptr }, ptr %l15
  store { i64, ptr } %t186, ptr %l107
  %t187 = load ptr, ptr %l105
  %t188 = load { i64, ptr }, ptr %l106
  %t189 = load { i64, ptr }, ptr %l107
  %t190 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eload(ptr %v0, ptr %s2, ptr %s2, ptr %t187, { i64, ptr } %t188, { i64, ptr } %t189, i1 false)
  store i64 %t190, ptr %l108
  br label %bb37
bb37:
  %t191 = load i64, ptr %l108
  store i64 %t191, ptr %l16
  %t192 = load i64, ptr %l16
  store i64 %t192, ptr %l109
  %t193 = load i64, ptr %l109
  %t194 = icmp slt i64 %t193, 0
  store i1 %t194, ptr %l110
  %t195 = load i1, ptr %l110
  br i1 %t195, label %bb38, label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s7
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s2)
  br label %bb74
bb39:
  br label %bb40
bb40:
  store i1 false, ptr %l17
  store %olang.scope zeroinitializer, ptr %s8
  store i64 0, ptr %l18
  %t196 = load ptr, ptr %l2
  store ptr %t196, ptr %l111
  %t197 = load ptr, ptr %l111
  %t198 = getelementptr %"compiler/load:Module", ptr %t197, i32 0, i32 9
  store ptr %t198, ptr %l112
  %t199 = load ptr, ptr %l112
  %t200 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2eLen_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %t199)
  store i64 %t200, ptr %l113
  br label %bb41
bb41:
  %t201 = load i64, ptr %l113
  store i64 %t201, ptr %l19
  store i64 1, ptr %l20
  %t202 = load i64, ptr %l19
  store i64 %t202, ptr %l114
  %t203 = load i64, ptr %l18
  store i64 %t203, ptr %l115
  %t204 = load i64, ptr %l114
  %t205 = load i64, ptr %l115
  %t206 = icmp sgt i64 %t204, %t205
  store i1 %t206, ptr %l116
  %t207 = load i1, ptr %l116
  br i1 %t207, label %bb42, label %bb43
bb42:
  %t208 = load i64, ptr %l20
  store i64 %t208, ptr %l118
  %t209 = load i64, ptr %l118
  %t210 = icmp sgt i64 %t209, 0
  store i1 %t210, ptr %l119
  %t211 = load i1, ptr %l119
  br i1 %t211, label %bb44, label %bb45
bb43:
  store i64 0, ptr %l117
  br label %bb47
bb44:
  %t212 = load i64, ptr %l19
  store i64 %t212, ptr %l121
  %t213 = load i64, ptr %l18
  store i64 %t213, ptr %l122
  %t214 = load i64, ptr %l121
  %t215 = load i64, ptr %l122
  %t216 = sub i64 %t214, %t215
  store i64 %t216, ptr %l123
  %t217 = load i64, ptr %l20
  store i64 %t217, ptr %l124
  %t218 = load i64, ptr %l123
  %t219 = load i64, ptr %l124
  %t220 = add i64 %t218, %t219
  store i64 %t220, ptr %l125
  %t221 = load i64, ptr %l125
  %t222 = sub i64 %t221, 1
  store i64 %t222, ptr %l126
  %t223 = load i64, ptr %l20
  store i64 %t223, ptr %l127
  %t224 = load i64, ptr %l126
  %t225 = load i64, ptr %l127
  %t226 = sdiv i64 %t224, %t225
  store i64 %t226, ptr %l128
  %t227 = load i64, ptr %l128
  store i64 %t227, ptr %l120
  br label %bb46
bb45:
  store i64 0, ptr %l120
  br label %bb46
bb46:
  %t228 = load i64, ptr %l120
  store i64 %t228, ptr %l117
  br label %bb47
bb47:
  %t229 = load i64, ptr %l117
  store i64 %t229, ptr %l21
  store i64 0, ptr %l22
  br label %bb48
bb48:
  store %olang.scope zeroinitializer, ptr %s9
  %t230 = load i64, ptr %l22
  store i64 %t230, ptr %l129
  %t231 = load i64, ptr %l21
  store i64 %t231, ptr %l130
  %t232 = load i64, ptr %l129
  %t233 = load i64, ptr %l130
  %t234 = icmp slt i64 %t232, %t233
  store i1 %t234, ptr %l131
  %t235 = load i1, ptr %l131
  %t236 = xor i1 %t235, true
  store i1 %t236, ptr %l132
  %t237 = load i1, ptr %l132
  br i1 %t237, label %bb49, label %bb50
bb49:
  call void @__olang_scope_close(ptr %s9)
  br label %bb65
bb50:
  br label %bb51
bb51:
  %t238 = load i64, ptr %l18
  store i64 %t238, ptr %l133
  %t239 = load i64, ptr %l22
  store i64 %t239, ptr %l134
  %t240 = load i64, ptr %l20
  store i64 %t240, ptr %l135
  %t241 = load i64, ptr %l134
  %t242 = load i64, ptr %l135
  %t243 = mul i64 %t241, %t242
  store i64 %t243, ptr %l136
  %t244 = load i64, ptr %l133
  %t245 = load i64, ptr %l136
  %t246 = add i64 %t244, %t245
  store i64 %t246, ptr %l137
  %t247 = load i64, ptr %l137
  store i64 %t247, ptr %l23
  %t248 = load i64, ptr %l23
  store i64 %t248, ptr %l138
  %t249 = load i64, ptr %l8
  store i64 %t249, ptr %l139
  %t250 = load i64, ptr %l138
  %t251 = load i64, ptr %l139
  %t252 = icmp ne i64 %t250, %t251
  store i1 %t252, ptr %l140
  %t253 = load i1, ptr %l140
  br i1 %t253, label %bb52, label %bb53
bb52:
  %t254 = load ptr, ptr %l2
  store ptr %t254, ptr %l142
  %t255 = load ptr, ptr %l142
  %t256 = getelementptr %"compiler/load:Module", ptr %t255, i32 0, i32 9
  store ptr %t256, ptr %l143
  %t257 = load i64, ptr %l23
  store i64 %t257, ptr %l144
  %t258 = load ptr, ptr %l143
  %t259 = load i64, ptr %l144
  %t260 = call %"compiler/load:Import" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2eAt_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v0, ptr %t258, i64 %t259)
  store %"compiler/load:Import" %t260, ptr %l145
  br label %bb54
bb53:
  store i1 false, ptr %l141
  br label %bb55
bb54:
  %t261 = getelementptr %"compiler/load:Import", ptr %l145, i32 0, i32 5
  %t262 = load i64, ptr %t261
  store i64 %t262, ptr %l146
  %t263 = load i64, ptr %l146
  %t264 = icmp sge i64 %t263, 0
  store i1 %t264, ptr %l147
  %t265 = load i1, ptr %l147
  store i1 %t265, ptr %l141
  br label %bb55
bb55:
  %t266 = load i1, ptr %l141
  br i1 %t266, label %bb56, label %bb57
bb56:
  %t267 = load ptr, ptr %l2
  store ptr %t267, ptr %l149
  %t268 = load ptr, ptr %l149
  %t269 = getelementptr %"compiler/load:Module", ptr %t268, i32 0, i32 9
  store ptr %t269, ptr %l150
  %t270 = load i64, ptr %l23
  store i64 %t270, ptr %l151
  %t271 = load ptr, ptr %l150
  %t272 = load i64, ptr %l151
  %t273 = call %"compiler/load:Import" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2eAt_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v0, ptr %t271, i64 %t272)
  store %"compiler/load:Import" %t273, ptr %l152
  br label %bb58
bb57:
  store i1 false, ptr %l148
  br label %bb60
bb58:
  %t274 = getelementptr %"compiler/load:Import", ptr %l152, i32 0, i32 2
  %t275 = load { i64, ptr }, ptr %t274
  store { i64, ptr } %t275, ptr %l153
  %t276 = getelementptr %"compiler/load:Import", ptr %l9, i32 0, i32 2
  %t277 = load { i64, ptr }, ptr %t276
  store { i64, ptr } %t277, ptr %l154
  %t278 = load { i64, ptr }, ptr %l153
  %t279 = load { i64, ptr }, ptr %l154
  %t280 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v0, { i64, ptr } %t278, { i64, ptr } %t279)
  store i1 %t280, ptr %l155
  br label %bb59
bb59:
  %t281 = load i1, ptr %l155
  store i1 %t281, ptr %l148
  br label %bb60
bb60:
  %t282 = load i1, ptr %l148
  br i1 %t282, label %bb61, label %bb62
bb61:
  store %olang.scope zeroinitializer, ptr %s10
  store i1 true, ptr %l17
  call void @__olang_scope_close(ptr %s10)
  br label %bb63
bb62:
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s9)
  br label %bb64
bb64:
  store %olang.scope zeroinitializer, ptr %s11
  %t283 = load i64, ptr %l22
  store i64 %t283, ptr %l156
  %t284 = load i64, ptr %l156
  %t285 = add i64 %t284, 1
  store i64 %t285, ptr %l157
  %t286 = load i64, ptr %l157
  store i64 %t286, ptr %l22
  call void @__olang_scope_close(ptr %s11)
  br label %bb48
bb65:
  call void @__olang_scope_close(ptr %s8)
  %t287 = load i1, ptr %l17
  store i1 %t287, ptr %l158
  %t288 = load i1, ptr %l158
  br i1 %t288, label %bb66, label %bb67
bb66:
  store %olang.scope zeroinitializer, ptr %s12
  %t289 = load ptr, ptr %l0
  store ptr %t289, ptr %l159
  %t290 = load ptr, ptr %l159
  %t291 = getelementptr %"compiler/load:Loader", ptr %t290, i32 0, i32 4
  %t292 = load ptr, ptr %t291
  store ptr %t292, ptr %l160
  %t293 = load ptr, ptr %l0
  store ptr %t293, ptr %l161
  %t294 = load ptr, ptr %l2
  store ptr %t294, ptr %l162
  %t295 = getelementptr %"compiler/load:Import", ptr %l9, i32 0, i32 1
  %t296 = load %"compiler/source:Span", ptr %t295
  store %"compiler/source:Span" %t296, ptr %l163
  %t297 = load ptr, ptr %l161
  %t298 = load ptr, ptr %l162
  %t299 = load %"compiler/source:Span", ptr %l163
  %t300 = call { i64, [3 x i64] } @compiler_2fload_2ecompiler_2fload_3aLoader_2eat(ptr %v0, ptr %v0, ptr %t297, ptr %t298, %"compiler/source:Span" %t299)
  store { i64, [3 x i64] } %t300, ptr %l164
  br label %bb68
bb67:
  br label %bb71
bb68:
  %t301 = getelementptr %"compiler/load:Import", ptr %l9, i32 0, i32 2
  %t302 = load { i64, ptr }, ptr %t301
  store { i64, ptr } %t302, ptr %l165
  %t303 = load { i64, ptr }, ptr %l165
  %t304 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportAliasConflict(ptr %v0, ptr %s12, { i64, ptr } %t303)
  store %"compiler/msgs:Msg" %t304, ptr %l166
  br label %bb69
bb69:
  %t305 = load ptr, ptr %l160
  %t306 = load { i64, [3 x i64] }, ptr %l164
  %t307 = load %"compiler/msgs:Msg", ptr %l166
  %t308 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s12, ptr %t305, { i64, [3 x i64] } %t306, %"compiler/msgs:Msg" %t307)
  store i64 %t308, ptr %l167
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s2)
  br label %bb74
bb71:
  %t309 = load i64, ptr %l8
  store i64 %t309, ptr %l168
  %t310 = load i64, ptr %l168
  store i64 %t310, ptr %l24
  %t311 = load ptr, ptr %l2
  store ptr %t311, ptr %l169
  %t312 = load ptr, ptr %l169
  %t313 = getelementptr %"compiler/load:Module", ptr %t312, i32 0, i32 9
  store ptr %t313, ptr %l170
  %t314 = load i64, ptr %l24
  store i64 %t314, ptr %l171
  %t315 = load ptr, ptr %l170
  %t316 = load i64, ptr %l171
  %t317 = call %"compiler/load:Import" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2eAt_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v0, ptr %t315, i64 %t316)
  store %"compiler/load:Import" %t317, ptr %l172
  br label %bb72
bb72:
  %t318 = load %"compiler/load:Import", ptr %l172
  store %"compiler/load:Import" %t318, ptr %l25
  %t319 = load i64, ptr %l16
  store i64 %t319, ptr %l173
  %t320 = load i64, ptr %l173
  %t321 = getelementptr %"compiler/load:Import", ptr %l25, i32 0, i32 5
  store i64 %t320, ptr %t321
  %t322 = load ptr, ptr %l2
  store ptr %t322, ptr %l174
  %t323 = load ptr, ptr %l174
  %t324 = getelementptr %"compiler/load:Module", ptr %t323, i32 0, i32 9
  store ptr %t324, ptr %l175
  %t325 = load i64, ptr %l24
  store i64 %t325, ptr %l176
  %t326 = load %"compiler/load:Import", ptr %l25
  store %"compiler/load:Import" %t326, ptr %l177
  %t327 = load ptr, ptr %l175
  %t328 = load i64, ptr %l176
  %t329 = load %"compiler/load:Import", ptr %l177
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2eSetAt_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v0, ptr %t327, i64 %t328, %"compiler/load:Import" %t329)
  br label %bb73
bb73:
  call void @__olang_scope_close(ptr %s2)
  br label %bb74
bb74:
  store %olang.scope zeroinitializer, ptr %s13
  %t330 = load i64, ptr %l7
  store i64 %t330, ptr %l178
  %t331 = load i64, ptr %l178
  %t332 = add i64 %t331, 1
  store i64 %t332, ptr %l179
  %t333 = load i64, ptr %l179
  store i64 %t333, ptr %l7
  call void @__olang_scope_close(ptr %s13)
  br label %bb9
bb75:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fload_2ecompiler_2fload_3aLoader_2eownNames(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca i32
  %l21 = alloca i32
  %l22 = alloca i1
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i1
  %l28 = alloca i1
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca { i64, ptr }
  %l32 = alloca ptr
  %l33 = alloca ptr
  %l34 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca ptr
  %l43 = alloca ptr
  %l44 = alloca { i64, ptr }
  %l45 = alloca ptr
  %l46 = alloca i64
  %l47 = alloca { i64, ptr }
  %l48 = alloca i32
  %l49 = alloca i32
  %l50 = alloca i1
  %l51 = alloca { i64, ptr }
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i1
  %l56 = alloca i1
  %l57 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l61 = alloca i8
  %l62 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca ptr
  %l65 = alloca ptr
  %l66 = alloca ptr
  %l67 = alloca { i64, ptr }
  %l68 = alloca i64
  %l69 = alloca i64
  %l70 = alloca i64
  %l71 = alloca i64
  %l72 = alloca i64
  %l73 = alloca ptr
  %l74 = alloca ptr
  %l75 = alloca ptr
  %l76 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load ptr, ptr %l1
  store ptr %t1, ptr %l14
  %t2 = load ptr, ptr %l14
  %t3 = getelementptr %"compiler/load:Module", ptr %t2, i32 0, i32 8
  store ptr %t3, ptr %l15
  %t4 = load ptr, ptr %l15
  store ptr %t4, ptr %l2
  store i64 0, ptr %l3
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load ptr, ptr %l2
  store ptr %t5, ptr %l17
  %t6 = load i64, ptr %l3
  store i64 %t6, ptr %l18
  %t7 = load ptr, ptr %l17
  %t8 = load i64, ptr %l18
  %t9 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v1, ptr %t7, i64 %t8)
  %t10 = extractvalue { i32, { i64, ptr } } %t9, 1
  %t11 = extractvalue { i32, { i64, ptr } } %t9, 0
  store i32 %t11, ptr %l20
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb3, label %ok.13
ok.13:
  store { i64, ptr } %t10, ptr %l19
  br label %bb2
bb2:
  %t14 = load { i64, ptr }, ptr %l19
  store { i64, ptr } %t14, ptr %l16
  br label %bb7
bb3:
  %t15 = load i32, ptr %l20
  %t16 = ashr i32 %t15, 16
  store i32 %t16, ptr %l21
  %t17 = load i32, ptr %l21
  %t18 = icmp eq i32 %t17, 1
  store i1 %t18, ptr %l22
  %t19 = load i1, ptr %l22
  br i1 %t19, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @.c58)
  unreachable
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb7:
  %t20 = load { i64, ptr }, ptr %l16
  store { i64, ptr } %t20, ptr %l4
  %t21 = load { i64, ptr }, ptr %l4
  store { i64, ptr } %t21, ptr %l23
  %t22 = load { i64, ptr }, ptr %l23
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l24
  %t24 = load i64, ptr %l24
  store i64 %t24, ptr %l5
  store i64 0, ptr %l6
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t25 = load i64, ptr %l6
  store i64 %t25, ptr %l25
  %t26 = load i64, ptr %l5
  store i64 %t26, ptr %l26
  %t27 = load i64, ptr %l25
  %t28 = load i64, ptr %l26
  %t29 = icmp slt i64 %t27, %t28
  store i1 %t29, ptr %l27
  %t30 = load i1, ptr %l27
  %t31 = xor i1 %t30, true
  store i1 %t31, ptr %l28
  %t32 = load i1, ptr %l28
  br i1 %t32, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb14
bb10:
  br label %bb11
bb11:
  %t33 = load { i64, ptr }, ptr %l4
  store { i64, ptr } %t33, ptr %l29
  %t34 = load i64, ptr %l6
  store i64 %t34, ptr %l30
  %t35 = load i64, ptr %l30
  %t36 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t37 = load ptr, ptr %t36
  %t38 = getelementptr { i64, ptr }, ptr %t37, i64 %t35
  %t39 = load { i64, ptr }, ptr %t38
  store { i64, ptr } %t39, ptr %l31
  %t40 = load { i64, ptr }, ptr %l31
  store { i64, ptr } %t40, ptr %l7
  %t41 = load ptr, ptr %l1
  store ptr %t41, ptr %l32
  %t42 = load ptr, ptr %l32
  %t43 = getelementptr %"compiler/load:Module", ptr %t42, i32 0, i32 10
  %t44 = load ptr, ptr %t43
  store ptr %t44, ptr %l33
  %t45 = load ptr, ptr %l0
  store ptr %t45, ptr %l34
  %t46 = load ptr, ptr %l34
  %t47 = getelementptr %"compiler/load:Loader", ptr %t46, i32 0, i32 3
  %t48 = load ptr, ptr %t47
  store ptr %t48, ptr %l35
  %t49 = load { i64, ptr }, ptr %l7
  store { i64, ptr } %t49, ptr %l36
  %t50 = load ptr, ptr %l33
  %t51 = load ptr, ptr %l35
  %t52 = load { i64, ptr }, ptr %l36
  call void @compiler_2fparse_2ecompiler_2fparse_3aOracle_2eAdd(ptr %v1, ptr %v0, ptr %s3, ptr %v1, ptr %t50, ptr %t51, { i64, ptr } { i64 0, ptr @.d59 }, { i64, ptr } %t52)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s4
  %t53 = load i64, ptr %l6
  store i64 %t53, ptr %l37
  %t54 = load i64, ptr %l37
  %t55 = add i64 %t54, 1
  store i64 %t55, ptr %l38
  %t56 = load i64, ptr %l38
  store i64 %t56, ptr %l6
  call void @__olang_scope_close(ptr %s4)
  br label %bb8
bb14:
  %t57 = load i64, ptr %l3
  store i64 %t57, ptr %l39
  %t58 = load i64, ptr %l5
  store i64 %t58, ptr %l40
  %t59 = load i64, ptr %l39
  %t60 = load i64, ptr %l40
  %t61 = add i64 %t59, %t60
  store i64 %t61, ptr %l41
  %t62 = load i64, ptr %l41
  store i64 %t62, ptr %l3
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb15:
  br label %bb1
bb16:
  call void @__olang_scope_close(ptr %s1)
  store %olang.scope zeroinitializer, ptr %s5
  %t63 = load ptr, ptr %l0
  store ptr %t63, ptr %l42
  %t64 = load ptr, ptr %l42
  %t65 = getelementptr %"compiler/load:Loader", ptr %t64, i32 0, i32 6
  store ptr %t65, ptr %l43
  %t66 = load ptr, ptr %l43
  store ptr %t66, ptr %l8
  store i64 0, ptr %l9
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s6
  %t67 = load ptr, ptr %l8
  store ptr %t67, ptr %l45
  %t68 = load i64, ptr %l9
  store i64 %t68, ptr %l46
  %t69 = load ptr, ptr %l45
  %t70 = load i64, ptr %l46
  %t71 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v0, ptr %t69, i64 %t70)
  %t72 = extractvalue { i32, { i64, ptr } } %t71, 1
  %t73 = extractvalue { i32, { i64, ptr } } %t71, 0
  store i32 %t73, ptr %l48
  %t74 = icmp ne i32 %t73, 0
  br i1 %t74, label %bb19, label %ok.75
ok.75:
  store { i64, ptr } %t72, ptr %l47
  br label %bb18
bb18:
  %t76 = load { i64, ptr }, ptr %l47
  store { i64, ptr } %t76, ptr %l44
  br label %bb23
bb19:
  %t77 = load i32, ptr %l48
  %t78 = ashr i32 %t77, 16
  store i32 %t78, ptr %l49
  %t79 = load i32, ptr %l49
  %t80 = icmp eq i32 %t79, 1
  store i1 %t80, ptr %l50
  %t81 = load i1, ptr %l50
  br i1 %t81, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @.c60)
  unreachable
bb22:
  call void @__olang_scope_close(ptr %s6)
  br label %bb36
bb23:
  %t82 = load { i64, ptr }, ptr %l44
  store { i64, ptr } %t82, ptr %l10
  %t83 = load { i64, ptr }, ptr %l10
  store { i64, ptr } %t83, ptr %l51
  %t84 = load { i64, ptr }, ptr %l51
  %t85 = extractvalue { i64, ptr } %t84, 0
  store i64 %t85, ptr %l52
  %t86 = load i64, ptr %l52
  store i64 %t86, ptr %l11
  store i64 0, ptr %l12
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s7
  %t87 = load i64, ptr %l12
  store i64 %t87, ptr %l53
  %t88 = load i64, ptr %l11
  store i64 %t88, ptr %l54
  %t89 = load i64, ptr %l53
  %t90 = load i64, ptr %l54
  %t91 = icmp slt i64 %t89, %t90
  store i1 %t91, ptr %l55
  %t92 = load i1, ptr %l55
  %t93 = xor i1 %t92, true
  store i1 %t93, ptr %l56
  %t94 = load i1, ptr %l56
  br i1 %t94, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s7)
  br label %bb34
bb26:
  br label %bb27
bb27:
  %t95 = load { i64, ptr }, ptr %l10
  store { i64, ptr } %t95, ptr %l57
  %t96 = load i64, ptr %l12
  store i64 %t96, ptr %l58
  %t97 = load i64, ptr %l58
  %t98 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t99 = load ptr, ptr %t98
  %t100 = getelementptr { i64, ptr }, ptr %t99, i64 %t97
  %t101 = load { i64, ptr }, ptr %t100
  store { i64, ptr } %t101, ptr %l59
  %t102 = load { i64, ptr }, ptr %l59
  store { i64, ptr } %t102, ptr %l13
  %t103 = load { i64, ptr }, ptr %l13
  store { i64, ptr } %t103, ptr %l60
  %t104 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t105 = load ptr, ptr %t104
  %t106 = getelementptr i8, ptr %t105, i64 0
  %t107 = load i8, ptr %t106
  store i8 %t107, ptr %l61
  %t108 = load i8, ptr %l61
  %t109 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t108)
  store i1 %t109, ptr %l62
  br label %bb28
bb28:
  %t110 = load i1, ptr %l62
  br i1 %t110, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s8
  %t111 = load ptr, ptr %l1
  store ptr %t111, ptr %l63
  %t112 = load ptr, ptr %l63
  %t113 = getelementptr %"compiler/load:Module", ptr %t112, i32 0, i32 10
  %t114 = load ptr, ptr %t113
  store ptr %t114, ptr %l64
  %t115 = load ptr, ptr %l0
  store ptr %t115, ptr %l65
  %t116 = load ptr, ptr %l65
  %t117 = getelementptr %"compiler/load:Loader", ptr %t116, i32 0, i32 3
  %t118 = load ptr, ptr %t117
  store ptr %t118, ptr %l66
  %t119 = load { i64, ptr }, ptr %l13
  store { i64, ptr } %t119, ptr %l67
  %t120 = load ptr, ptr %l64
  %t121 = load ptr, ptr %l66
  %t122 = load { i64, ptr }, ptr %l67
  call void @compiler_2fparse_2ecompiler_2fparse_3aOracle_2eAdd(ptr %v1, ptr %v0, ptr %s8, ptr %v0, ptr %t120, ptr %t121, { i64, ptr } { i64 0, ptr @.d61 }, { i64, ptr } %t122)
  br label %bb31
bb30:
  br label %bb32
bb31:
  call void @__olang_scope_close(ptr %s8)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s7)
  br label %bb33
bb33:
  store %olang.scope zeroinitializer, ptr %s9
  %t123 = load i64, ptr %l12
  store i64 %t123, ptr %l68
  %t124 = load i64, ptr %l68
  %t125 = add i64 %t124, 1
  store i64 %t125, ptr %l69
  %t126 = load i64, ptr %l69
  store i64 %t126, ptr %l12
  call void @__olang_scope_close(ptr %s9)
  br label %bb24
bb34:
  %t127 = load i64, ptr %l9
  store i64 %t127, ptr %l70
  %t128 = load i64, ptr %l11
  store i64 %t128, ptr %l71
  %t129 = load i64, ptr %l70
  %t130 = load i64, ptr %l71
  %t131 = add i64 %t129, %t130
  store i64 %t131, ptr %l72
  %t132 = load i64, ptr %l72
  store i64 %t132, ptr %l9
  call void @__olang_scope_close(ptr %s6)
  br label %bb35
bb35:
  br label %bb17
bb36:
  call void @__olang_scope_close(ptr %s5)
  %t133 = load ptr, ptr %l1
  store ptr %t133, ptr %l73
  %t134 = load ptr, ptr %l73
  %t135 = getelementptr %"compiler/load:Module", ptr %t134, i32 0, i32 10
  %t136 = load ptr, ptr %t135
  store ptr %t136, ptr %l74
  %t137 = load ptr, ptr %l0
  store ptr %t137, ptr %l75
  %t138 = load ptr, ptr %l75
  %t139 = getelementptr %"compiler/load:Loader", ptr %t138, i32 0, i32 3
  %t140 = load ptr, ptr %t139
  store ptr %t140, ptr %l76
  %t141 = load ptr, ptr %l74
  %t142 = load ptr, ptr %l76
  call void @compiler_2fparse_2ecompiler_2fparse_3aOracle_2eAdd(ptr %v1, ptr %v0, ptr %s0, ptr %s0, ptr %t141, ptr %t142, { i64, ptr } { i64 0, ptr @.d62 }, { i64, ptr } { i64 5, ptr @.d63 })
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fload_2ecompiler_2fload_3aLoader_2eparse(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca %"compiler/parse:Parser"
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca { i64, ptr }
  %l30 = alloca ptr
  %l31 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %t43 = alloca %"compiler/parse:Parser", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l3
  %t2 = load ptr, ptr %l3
  %t3 = getelementptr %"compiler/load:Loader", ptr %t2, i32 0, i32 5
  store ptr %t3, ptr %l4
  %t4 = load i64, ptr %l1
  store i64 %t4, ptr %l5
  %t5 = load ptr, ptr %l4
  %t6 = load i64, ptr %l5
  %t7 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t5, i64 %t6)
  store ptr %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l6
  store ptr %t8, ptr %l2
  %t9 = load ptr, ptr %l0
  store ptr %t9, ptr %l7
  %t10 = load ptr, ptr %l2
  store ptr %t10, ptr %l8
  %t11 = load ptr, ptr %l8
  %t12 = getelementptr %"compiler/load:Module", ptr %t11, i32 0, i32 10
  %t13 = load ptr, ptr %t12
  store ptr %t13, ptr %l9
  %t14 = load i64, ptr %l1
  store i64 %t14, ptr %l10
  %t15 = load ptr, ptr %l7
  %t16 = load ptr, ptr %l9
  %t17 = load i64, ptr %l10
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2echains(ptr %v0, ptr %v0, ptr %s0, ptr %t15, ptr %t16, i64 %t17, { i64, ptr } { i64 0, ptr @.d64 }, i64 0)
  br label %bb2
bb2:
  %t18 = load ptr, ptr %l2
  store ptr %t18, ptr %l11
  %t19 = load ptr, ptr %l2
  store ptr %t19, ptr %l12
  %t20 = load ptr, ptr %l12
  %t21 = getelementptr %"compiler/load:Module", ptr %t20, i32 0, i32 5
  %t22 = load ptr, ptr %t21
  store ptr %t22, ptr %l13
  %t23 = load ptr, ptr %l2
  store ptr %t23, ptr %l14
  %t24 = load ptr, ptr %l14
  %t25 = getelementptr %"compiler/load:Module", ptr %t24, i32 0, i32 6
  %t26 = load ptr, ptr %t25
  store ptr %t26, ptr %l15
  %t27 = load ptr, ptr %l0
  store ptr %t27, ptr %l16
  %t28 = load ptr, ptr %l16
  %t29 = getelementptr %"compiler/load:Loader", ptr %t28, i32 0, i32 3
  %t30 = load ptr, ptr %t29
  store ptr %t30, ptr %l17
  %t31 = load ptr, ptr %l2
  store ptr %t31, ptr %l18
  %t32 = load ptr, ptr %l18
  %t33 = getelementptr %"compiler/load:Module", ptr %t32, i32 0, i32 10
  %t34 = load ptr, ptr %t33
  store ptr %t34, ptr %l19
  %t35 = load ptr, ptr %l0
  store ptr %t35, ptr %l20
  %t36 = load ptr, ptr %l20
  %t37 = getelementptr %"compiler/load:Loader", ptr %t36, i32 0, i32 4
  %t38 = load ptr, ptr %t37
  store ptr %t38, ptr %l21
  %t39 = load ptr, ptr %l2
  store ptr %t39, ptr %l22
  %t40 = load ptr, ptr %l22
  %t41 = getelementptr %"compiler/load:Module", ptr %t40, i32 0, i32 4
  %t42 = load i64, ptr %t41
  store i64 %t42, ptr %l23
  %t44 = load ptr, ptr %l13
  %t45 = load ptr, ptr %l15
  %t46 = load ptr, ptr %l17
  %t47 = load ptr, ptr %l19
  %t48 = load ptr, ptr %l21
  %t49 = load i64, ptr %l23
  call void @compiler_2fparse_3aParser_2ector(ptr %t43, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t44, ptr %t45, ptr %t46, ptr %t47, ptr %t48, i64 %t49)
  %t50 = load %"compiler/parse:Parser", ptr %t43
  store %"compiler/parse:Parser" %t50, ptr %l24
  br label %bb3
bb3:
  %t51 = load %"compiler/parse:Parser", ptr %l24
  %t52 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 264, i64 8)
  store %"compiler/parse:Parser" %t51, ptr %t52
  store ptr %t52, ptr %l25
  %t53 = load ptr, ptr %l25
  %t54 = load ptr, ptr %l11
  %t55 = getelementptr %"compiler/load:Module", ptr %t54, i32 0, i32 11
  store ptr %t53, ptr %t55
  %t56 = load ptr, ptr %l2
  store ptr %t56, ptr %l26
  %t57 = load ptr, ptr %l2
  store ptr %t57, ptr %l27
  %t58 = load ptr, ptr %l27
  %t59 = getelementptr %"compiler/load:Module", ptr %t58, i32 0, i32 11
  %t60 = load ptr, ptr %t59
  store ptr %t60, ptr %l28
  %t61 = load ptr, ptr %l28
  %t62 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eFile(ptr %v0, ptr %t61)
  store { i64, ptr } %t62, ptr %l29
  br label %bb4
bb4:
  %t63 = load { i64, ptr }, ptr %l29
  %t64 = load ptr, ptr %l26
  %t65 = getelementptr %"compiler/load:Module", ptr %t64, i32 0, i32 7
  store { i64, ptr } %t63, ptr %t65
  %t66 = load ptr, ptr %l0
  store ptr %t66, ptr %l30
  %t67 = load i64, ptr %l1
  store i64 %t67, ptr %l31
  %t68 = load ptr, ptr %l2
  store ptr %t68, ptr %l32
  %t69 = load ptr, ptr %l32
  %t70 = getelementptr %"compiler/load:Module", ptr %t69, i32 0, i32 7
  %t71 = load { i64, ptr }, ptr %t70
  store { i64, ptr } %t71, ptr %l33
  %t72 = load ptr, ptr %l30
  %t73 = load i64, ptr %l31
  %t74 = load { i64, ptr }, ptr %l33
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2egroups(ptr %v0, ptr %v0, ptr %t72, i64 %t73, { i64, ptr } %t74)
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fload_2ecompiler_2fload_3aLoader_2eprescan(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca i32
  %l19 = alloca i32
  %l20 = alloca i1
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i1
  %l26 = alloca i1
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %l30 = alloca ptr
  %l31 = alloca ptr
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca ptr
  %l41 = alloca ptr
  %l42 = alloca ptr
  %l43 = alloca ptr
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l46 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.builder
  %s4room = alloca [64 x i8], align 8
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load ptr, ptr %l1
  store ptr %t1, ptr %l8
  %t2 = load ptr, ptr %l8
  %t3 = getelementptr %"compiler/load:Module", ptr %t2, i32 0, i32 5
  %t4 = load ptr, ptr %t3
  store ptr %t4, ptr %l9
  %t5 = load ptr, ptr %l9
  %t6 = getelementptr %"compiler/source:Source", ptr %t5, i32 0, i32 1
  %t7 = load { i64, ptr }, ptr %t6
  store { i64, ptr } %t7, ptr %l10
  %t8 = load ptr, ptr %l1
  store ptr %t8, ptr %l11
  %t9 = load ptr, ptr %l11
  %t10 = getelementptr %"compiler/load:Module", ptr %t9, i32 0, i32 6
  %t11 = load ptr, ptr %t10
  store ptr %t11, ptr %l12
  %t12 = load { i64, ptr }, ptr %l10
  %t13 = load ptr, ptr %l12
  %t14 = call ptr @compiler_2fload_2etypeNames(ptr %v1, ptr %v1, { i64, ptr } %t12, ptr %t13)
  store ptr %t14, ptr %l13
  br label %bb1
bb1:
  %t15 = load ptr, ptr %l13
  store ptr %t15, ptr %l2
  store i64 0, ptr %l3
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t16 = load ptr, ptr %l2
  store ptr %t16, ptr %l15
  %t17 = load i64, ptr %l3
  store i64 %t17, ptr %l16
  %t18 = load ptr, ptr %l15
  %t19 = load i64, ptr %l16
  %t20 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v1, ptr %t18, i64 %t19)
  %t21 = extractvalue { i32, { i64, ptr } } %t20, 1
  %t22 = extractvalue { i32, { i64, ptr } } %t20, 0
  store i32 %t22, ptr %l18
  %t23 = icmp ne i32 %t22, 0
  br i1 %t23, label %bb4, label %ok.24
ok.24:
  store { i64, ptr } %t21, ptr %l17
  br label %bb3
bb3:
  %t25 = load { i64, ptr }, ptr %l17
  store { i64, ptr } %t25, ptr %l14
  br label %bb8
bb4:
  %t26 = load i32, ptr %l18
  %t27 = ashr i32 %t26, 16
  store i32 %t27, ptr %l19
  %t28 = load i32, ptr %l19
  %t29 = icmp eq i32 %t28, 1
  store i1 %t29, ptr %l20
  %t30 = load i1, ptr %l20
  br i1 %t30, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @.c65)
  unreachable
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb8:
  %t31 = load { i64, ptr }, ptr %l14
  store { i64, ptr } %t31, ptr %l4
  %t32 = load { i64, ptr }, ptr %l4
  store { i64, ptr } %t32, ptr %l21
  %t33 = load { i64, ptr }, ptr %l21
  %t34 = extractvalue { i64, ptr } %t33, 0
  store i64 %t34, ptr %l22
  %t35 = load i64, ptr %l22
  store i64 %t35, ptr %l5
  store i64 0, ptr %l6
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t36 = load i64, ptr %l6
  store i64 %t36, ptr %l23
  %t37 = load i64, ptr %l5
  store i64 %t37, ptr %l24
  %t38 = load i64, ptr %l23
  %t39 = load i64, ptr %l24
  %t40 = icmp slt i64 %t38, %t39
  store i1 %t40, ptr %l25
  %t41 = load i1, ptr %l25
  %t42 = xor i1 %t41, true
  store i1 %t42, ptr %l26
  %t43 = load i1, ptr %l26
  br i1 %t43, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb11:
  br label %bb12
bb12:
  %t44 = load { i64, ptr }, ptr %l4
  store { i64, ptr } %t44, ptr %l27
  %t45 = load i64, ptr %l6
  store i64 %t45, ptr %l28
  %t46 = load i64, ptr %l28
  %t47 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t48 = load ptr, ptr %t47
  %t49 = getelementptr { i64, ptr }, ptr %t48, i64 %t46
  %t50 = load { i64, ptr }, ptr %t49
  store { i64, ptr } %t50, ptr %l29
  %t51 = load { i64, ptr }, ptr %l29
  store { i64, ptr } %t51, ptr %l7
  %t52 = load ptr, ptr %l1
  store ptr %t52, ptr %l30
  %t53 = load ptr, ptr %l30
  %t54 = getelementptr %"compiler/load:Module", ptr %t53, i32 0, i32 8
  store ptr %t54, ptr %l31
  %t55 = load { i64, ptr }, ptr %l7
  store { i64, ptr } %t55, ptr %l32
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s4
  store ptr %s4room, ptr %s4
  %t56 = load { i64, ptr }, ptr %l32
  %t57 = extractvalue { i64, ptr } %t56, 1
  %t58 = extractvalue { i64, ptr } %t56, 0
  call void @__olang_sb_put(ptr %s4, ptr %t57, i64 %t58)
  %t59 = load ptr, ptr %s4
  %t60 = getelementptr %olang.builder, ptr %s4, i32 0, i32 1
  %t61 = load i64, ptr %t60
  %t62 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t61)
  call void @llvm.memcpy.p0.p0.i64(ptr %t62, ptr %t59, i64 %t61, i1 false)
  %t63 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t62, 1
  store { i64, ptr } %t64, ptr %l33
  call void @__olang_sb_done(ptr %s4)
  %t65 = load { i64, ptr }, ptr %l33
  %t66 = extractvalue { i64, ptr } %t65, 0
  %t67 = extractvalue { i64, ptr } %t65, 1
  %t68 = mul i64 %t66, 1
  %t69 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t68)
  call void @llvm.memcpy.p0.p0.i64(ptr %t69, ptr %t67, i64 %t68, i1 false)
  %t70 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t69, 1
  store { i64, ptr } %t71, ptr %l34
  %t72 = load ptr, ptr %l31
  %t73 = load { i64, ptr }, ptr %l34
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t72, { i64, ptr } %t73)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s5
  %t74 = load i64, ptr %l6
  store i64 %t74, ptr %l35
  %t75 = load i64, ptr %l35
  %t76 = add i64 %t75, 1
  store i64 %t76, ptr %l36
  %t77 = load i64, ptr %l36
  store i64 %t77, ptr %l6
  call void @__olang_scope_close(ptr %s5)
  br label %bb9
bb15:
  %t78 = load i64, ptr %l3
  store i64 %t78, ptr %l37
  %t79 = load i64, ptr %l5
  store i64 %t79, ptr %l38
  %t80 = load i64, ptr %l37
  %t81 = load i64, ptr %l38
  %t82 = add i64 %t80, %t81
  store i64 %t82, ptr %l39
  %t83 = load i64, ptr %l39
  store i64 %t83, ptr %l3
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  br label %bb2
bb17:
  call void @__olang_scope_close(ptr %s1)
  %t84 = load ptr, ptr %l0
  store ptr %t84, ptr %l40
  %t85 = load ptr, ptr %l1
  store ptr %t85, ptr %l41
  %t86 = load ptr, ptr %l1
  store ptr %t86, ptr %l42
  %t87 = load ptr, ptr %l42
  %t88 = getelementptr %"compiler/load:Module", ptr %t87, i32 0, i32 6
  %t89 = load ptr, ptr %t88
  store ptr %t89, ptr %l43
  %t90 = load ptr, ptr %l43
  %t91 = getelementptr %"compiler/scan:Tokens", ptr %t90, i32 0, i32 0
  %t92 = load { i64, ptr }, ptr %t91
  store { i64, ptr } %t92, ptr %l44
  %t93 = load { i64, ptr }, ptr %l44
  %t94 = extractvalue { i64, ptr } %t93, 0
  store i64 %t94, ptr %l45
  %t95 = load i64, ptr %l45
  %t96 = sub i64 %t95, 1
  store i64 %t96, ptr %l46
  %t97 = load ptr, ptr %l40
  %t98 = load ptr, ptr %l41
  %t99 = load i64, ptr %l46
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2eregion(ptr %v0, ptr %v1, ptr %t97, ptr %t98, i64 0, i64 %t99, i64 -1)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fload_2ecompiler_2fload_3aLoader_2eregion(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i1
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i1
  %l18 = alloca i1
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i32
  %l22 = alloca i32
  %l23 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca ptr
  %l26 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca i64
  %l30 = alloca i32
  %l31 = alloca i32
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i1
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i32
  %l38 = alloca ptr
  %l39 = alloca i32
  %l40 = alloca ptr
  %l41 = alloca i1
  %l42 = alloca i1
  %l43 = alloca i32
  %l44 = alloca ptr
  %l45 = alloca i32
  %l46 = alloca ptr
  %l47 = alloca i1
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i1
  %l51 = alloca i32
  %l52 = alloca ptr
  %l53 = alloca i32
  %l54 = alloca ptr
  %l55 = alloca i1
  %l56 = alloca i1
  %l57 = alloca i1
  %l58 = alloca ptr
  %l59 = alloca ptr
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i64
  %l64 = alloca i32
  %l65 = alloca ptr
  %l66 = alloca i32
  %l67 = alloca ptr
  %l68 = alloca i1
  %l69 = alloca ptr
  %l70 = alloca ptr
  %l71 = alloca i64
  %l72 = alloca i64
  %l73 = alloca i32
  %l74 = alloca ptr
  %l75 = alloca i32
  %l76 = alloca ptr
  %l77 = alloca i1
  %l78 = alloca i1
  %l79 = alloca i1
  %l80 = alloca i1
  %l81 = alloca i64
  %l82 = alloca i1
  %l83 = alloca ptr
  %l84 = alloca ptr
  %l85 = alloca i64
  %l86 = alloca i64
  %l87 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1
  store ptr %t1, ptr %l11
  %t2 = load ptr, ptr %l11
  %t3 = getelementptr %"compiler/load:Module", ptr %t2, i32 0, i32 6
  %t4 = load ptr, ptr %t3
  store ptr %t4, ptr %l12
  %t5 = load ptr, ptr %l12
  %t6 = getelementptr %"compiler/scan:Tokens", ptr %t5, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6
  store { i64, ptr } %t7, ptr %l13
  %t8 = load { i64, ptr }, ptr %l13
  store { i64, ptr } %t8, ptr %l5
  %t9 = load i64, ptr %l2
  store i64 %t9, ptr %l14
  %t10 = load i64, ptr %l14
  store i64 %t10, ptr %l6
  store i1 true, ptr %l7
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = load i64, ptr %l6
  store i64 %t11, ptr %l15
  %t12 = load i64, ptr %l3
  store i64 %t12, ptr %l16
  %t13 = load i64, ptr %l15
  %t14 = load i64, ptr %l16
  %t15 = icmp slt i64 %t13, %t14
  store i1 %t15, ptr %l17
  %t16 = load i1, ptr %l17
  %t17 = xor i1 %t16, true
  store i1 %t17, ptr %l18
  %t18 = load i1, ptr %l18
  br i1 %t18, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s1)
  br label %bb46
bb3:
  br label %bb4
bb4:
  %t19 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t19, ptr %l19
  %t20 = load i64, ptr %l6
  store i64 %t20, ptr %l20
  %t21 = load i64, ptr %l20
  %t22 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t23 = load ptr, ptr %t22
  %t24 = getelementptr %"compiler/token:Token", ptr %t23, i64 %t21
  %t25 = getelementptr %"compiler/token:Token", ptr %t24, i32 0, i32 0
  %t26 = load i32, ptr %t25
  store i32 %t26, ptr %l21
  %t27 = load i32, ptr %l21
  store i32 %t27, ptr %l8
  %t28 = load i32, ptr %l8
  store i32 %t28, ptr %l22
  store ptr %l22, ptr %l23
  store i32 94, ptr %l24
  store ptr %l24, ptr %l25
  %t29 = load ptr, ptr %l23
  %t30 = load ptr, ptr %l25
  %t31 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t29, ptr %t30)
  store i1 %t31, ptr %l26
  br label %bb5
bb5:
  %t32 = load i1, ptr %l26
  br i1 %t32, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t33 = load ptr, ptr %l1
  store ptr %t33, ptr %l27
  %t34 = load ptr, ptr %l27
  %t35 = getelementptr %"compiler/load:Module", ptr %t34, i32 0, i32 6
  %t36 = load ptr, ptr %t35
  store ptr %t36, ptr %l28
  %t37 = load i64, ptr %l6
  store i64 %t37, ptr %l29
  %t38 = load i64, ptr %l29
  %t39 = trunc i64 %t38 to i32
  store i32 %t39, ptr %l30
  %t40 = load ptr, ptr %l28
  %t41 = load i32, ptr %l30
  %t42 = call i32 @compiler_2fscan_2ecompiler_2fscan_3aTokens_2eMatch(ptr %v1, ptr %t40, i32 %t41)
  store i32 %t42, ptr %l31
  br label %bb8
bb7:
  br label %bb12
bb8:
  %t43 = load i32, ptr %l31
  %t44 = sext i32 %t43 to i64
  store i64 %t44, ptr %l32
  %t45 = load i64, ptr %l32
  store i64 %t45, ptr %l9
  %t46 = load i64, ptr %l9
  store i64 %t46, ptr %l33
  %t47 = load i64, ptr %l33
  %t48 = icmp slt i64 %t47, 0
  store i1 %t48, ptr %l34
  %t49 = load i1, ptr %l34
  br i1 %t49, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb10:
  br label %bb11
bb11:
  %t50 = load i64, ptr %l9
  store i64 %t50, ptr %l35
  %t51 = load i64, ptr %l35
  %t52 = add i64 %t51, 1
  store i64 %t52, ptr %l36
  %t53 = load i64, ptr %l36
  store i64 %t53, ptr %l6
  store i1 true, ptr %l7
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  br label %bb45
bb12:
  %t54 = load i32, ptr %l8
  store i32 %t54, ptr %l37
  store ptr %l37, ptr %l38
  store i32 8, ptr %l39
  store ptr %l39, ptr %l40
  %t55 = load ptr, ptr %l38
  %t56 = load ptr, ptr %l40
  %t57 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t55, ptr %t56)
  store i1 %t57, ptr %l41
  br label %bb13
bb13:
  %t58 = load i1, ptr %l41
  br i1 %t58, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l42
  br label %bb17
bb15:
  %t59 = load i32, ptr %l8
  store i32 %t59, ptr %l43
  store ptr %l43, ptr %l44
  store i32 95, ptr %l45
  store ptr %l45, ptr %l46
  %t60 = load ptr, ptr %l44
  %t61 = load ptr, ptr %l46
  %t62 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t60, ptr %t61)
  store i1 %t62, ptr %l47
  br label %bb16
bb16:
  %t63 = load i1, ptr %l47
  store i1 %t63, ptr %l42
  br label %bb17
bb17:
  %t64 = load i1, ptr %l42
  br i1 %t64, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s4
  store i1 true, ptr %l7
  %t65 = load i64, ptr %l6
  store i64 %t65, ptr %l48
  %t66 = load i64, ptr %l48
  %t67 = add i64 %t66, 1
  store i64 %t67, ptr %l49
  %t68 = load i64, ptr %l49
  store i64 %t68, ptr %l6
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s1)
  br label %bb45
bb19:
  br label %bb20
bb20:
  %t69 = load i1, ptr %l7
  store i1 %t69, ptr %l50
  %t70 = load i1, ptr %l50
  store i1 %t70, ptr %l10
  store i1 false, ptr %l7
  %t71 = load i32, ptr %l8
  store i32 %t71, ptr %l51
  store ptr %l51, ptr %l52
  store i32 9, ptr %l53
  store ptr %l53, ptr %l54
  %t72 = load ptr, ptr %l52
  %t73 = load ptr, ptr %l54
  %t74 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t72, ptr %t73)
  store i1 %t74, ptr %l55
  br label %bb21
bb21:
  %t75 = load i1, ptr %l55
  br i1 %t75, label %bb22, label %bb23
bb22:
  %t76 = load i1, ptr %l10
  store i1 %t76, ptr %l57
  %t77 = load i1, ptr %l57
  store i1 %t77, ptr %l56
  br label %bb24
bb23:
  store i1 false, ptr %l56
  br label %bb24
bb24:
  %t78 = load i1, ptr %l56
  br i1 %t78, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s5
  %t79 = load ptr, ptr %l0
  store ptr %t79, ptr %l58
  %t80 = load ptr, ptr %l1
  store ptr %t80, ptr %l59
  %t81 = load i64, ptr %l6
  store i64 %t81, ptr %l60
  %t82 = load i64, ptr %l3
  store i64 %t82, ptr %l61
  %t83 = load i64, ptr %l4
  store i64 %t83, ptr %l62
  %t84 = load ptr, ptr %l58
  %t85 = load ptr, ptr %l59
  %t86 = load i64, ptr %l60
  %t87 = load i64, ptr %l61
  %t88 = load i64, ptr %l62
  %t89 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2etopIf(ptr %v0, ptr %v1, ptr %t84, ptr %t85, i64 %t86, i64 %t87, i64 %t88)
  store i64 %t89, ptr %l63
  br label %bb27
bb26:
  br label %bb28
bb27:
  %t90 = load i64, ptr %l63
  store i64 %t90, ptr %l6
  store i1 true, ptr %l7
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s1)
  br label %bb45
bb28:
  %t91 = load i32, ptr %l8
  store i32 %t91, ptr %l64
  store ptr %l64, ptr %l65
  store i32 42, ptr %l66
  store ptr %l66, ptr %l67
  %t92 = load ptr, ptr %l65
  %t93 = load ptr, ptr %l67
  %t94 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t92, ptr %t93)
  store i1 %t94, ptr %l68
  br label %bb29
bb29:
  %t95 = load i1, ptr %l68
  br i1 %t95, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s6
  %t96 = load ptr, ptr %l0
  store ptr %t96, ptr %l69
  %t97 = load ptr, ptr %l1
  store ptr %t97, ptr %l70
  %t98 = load i64, ptr %l6
  store i64 %t98, ptr %l71
  %t99 = load i64, ptr %l4
  store i64 %t99, ptr %l72
  %t100 = load ptr, ptr %l69
  %t101 = load ptr, ptr %l70
  %t102 = load i64, ptr %l71
  %t103 = load i64, ptr %l72
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2eimportAt(ptr %v0, ptr %v1, ptr %t100, ptr %t101, i64 %t102, i64 %t103)
  br label %bb32
bb31:
  br label %bb33
bb32:
  call void @__olang_scope_close(ptr %s6)
  br label %bb33
bb33:
  %t104 = load i32, ptr %l8
  store i32 %t104, ptr %l73
  store ptr %l73, ptr %l74
  store i32 1, ptr %l75
  store ptr %l75, ptr %l76
  %t105 = load ptr, ptr %l74
  %t106 = load ptr, ptr %l76
  %t107 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t105, ptr %t106)
  store i1 %t107, ptr %l77
  br label %bb34
bb34:
  %t108 = load i1, ptr %l77
  br i1 %t108, label %bb35, label %bb36
bb35:
  %t109 = load i1, ptr %l10
  store i1 %t109, ptr %l79
  %t110 = load i1, ptr %l79
  store i1 %t110, ptr %l78
  br label %bb37
bb36:
  store i1 false, ptr %l78
  br label %bb37
bb37:
  %t111 = load i1, ptr %l78
  br i1 %t111, label %bb38, label %bb39
bb38:
  %t112 = load i64, ptr %l4
  store i64 %t112, ptr %l81
  %t113 = load i64, ptr %l81
  %t114 = icmp slt i64 %t113, 0
  store i1 %t114, ptr %l82
  %t115 = load i1, ptr %l82
  store i1 %t115, ptr %l80
  br label %bb40
bb39:
  store i1 false, ptr %l80
  br label %bb40
bb40:
  %t116 = load i1, ptr %l80
  br i1 %t116, label %bb41, label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s7
  %t117 = load ptr, ptr %l1
  store ptr %t117, ptr %l83
  %t118 = load ptr, ptr %l83
  %t119 = getelementptr %"compiler/load:Module", ptr %t118, i32 0, i32 20
  store ptr %t119, ptr %l84
  %t120 = load i64, ptr %l6
  store i64 %t120, ptr %l85
  %t121 = load ptr, ptr %l84
  %t122 = load i64, ptr %l85
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t121, i64 %t122)
  br label %bb43
bb42:
  br label %bb44
bb43:
  call void @__olang_scope_close(ptr %s7)
  br label %bb44
bb44:
  %t123 = load i64, ptr %l6
  store i64 %t123, ptr %l86
  %t124 = load i64, ptr %l86
  %t125 = add i64 %t124, 1
  store i64 %t125, ptr %l87
  %t126 = load i64, ptr %l87
  store i64 %t126, ptr %l6
  call void @__olang_scope_close(ptr %s1)
  br label %bb45
bb45:
  br label %bb1
bb46:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i32, { { i64, ptr }, { i64, ptr } } } @compiler_2fload_2ecompiler_2fload_3aLoader_2eresolve(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, %"compiler/load:Import" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/load:Import"
  %l3 = alloca ptr
  %l4 = alloca { i64, [3 x i64] }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %lp8 = alloca ptr
  %lp9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca %"std/prelude/text:StringBuilder"
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca %"compiler/source:Span"
  %l31 = alloca { i64, [3 x i64] }
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l35 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca ptr
  %l38 = alloca { i64, [3 x i64] }
  %l39 = alloca %"compiler/msgs:Msg"
  %l40 = alloca i64
  %l41 = alloca i32
  %l42 = alloca { i64, ptr }
  %l43 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca ptr
  %l46 = alloca { i64, [3 x i64] }
  %l47 = alloca %"compiler/msgs:Msg"
  %l48 = alloca i64
  %l49 = alloca i32
  %l50 = alloca i64
  %l51 = alloca { i64, ptr }
  %l52 = alloca i8
  %l53 = alloca i64
  %l54 = alloca i32
  %l55 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i1
  %l61 = alloca i1
  %l62 = alloca i1
  %l63 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l66 = alloca i64
  %l67 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l70 = alloca i64
  %l71 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l73 = alloca i1
  %l74 = alloca ptr
  %l75 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %l79 = alloca i64
  %l80 = alloca i64
  %l81 = alloca i1
  %l82 = alloca i1
  %l83 = alloca i1
  %l84 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %l89 = alloca i64
  %l90 = alloca i64
  %l91 = alloca i1
  %l92 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l95 = alloca i64
  %l96 = alloca i64
  %l97 = alloca i1
  %l98 = alloca { i64, ptr }
  %l99 = alloca i1
  %l100 = alloca i1
  %l101 = alloca ptr
  %l102 = alloca ptr
  %l103 = alloca { i64, [3 x i64] }
  %l104 = alloca %"compiler/msgs:Msg"
  %l105 = alloca i64
  %l106 = alloca i32
  %l107 = alloca { i64, ptr }
  %l108 = alloca { i64, ptr }
  %l109 = alloca { i64, ptr }
  %l110 = alloca i1
  %l111 = alloca i1
  %l112 = alloca { i64, ptr }
  %l113 = alloca i1
  %l114 = alloca i1
  %l115 = alloca i1
  %l116 = alloca { i64, ptr }
  %l117 = alloca i1
  %l118 = alloca i1
  %l119 = alloca { i64, ptr }
  %l120 = alloca { i64, ptr }
  %l121 = alloca { i64, ptr }
  %l122 = alloca i64
  %l123 = alloca i1
  %l124 = alloca ptr
  %l125 = alloca ptr
  %l126 = alloca { i64, [3 x i64] }
  %l127 = alloca %"compiler/msgs:Msg"
  %l128 = alloca i64
  %l129 = alloca i32
  %l130 = alloca { i64, ptr }
  %l131 = alloca ptr
  %l132 = alloca ptr
  %l133 = alloca { i64, ptr }
  %l134 = alloca { i64, ptr }
  %l135 = alloca { i64, ptr }
  %l136 = alloca { i64, ptr }
  %l137 = alloca { i64, ptr }
  %l138 = alloca { i64, ptr }
  %l139 = alloca { i64, ptr }
  %l140 = alloca i32
  %l141 = alloca i1
  %l142 = alloca i1
  %l143 = alloca i1
  %l144 = alloca i1
  %l145 = alloca i32
  %l146 = alloca ptr
  %l147 = alloca ptr
  %l148 = alloca { i64, [3 x i64] }
  %l149 = alloca %"compiler/msgs:Msg"
  %l150 = alloca i64
  %l151 = alloca { i64, ptr }
  %l152 = alloca { i64, ptr }
  %l153 = alloca ptr
  %l154 = alloca ptr
  %l155 = alloca { i64, [3 x i64] }
  %l156 = alloca { i64, ptr }
  %l157 = alloca { i64, ptr }
  %l158 = alloca { i64, ptr }
  %l159 = alloca %"compiler/msgs:Msg"
  %l160 = alloca i64
  %l161 = alloca { i64, ptr }
  %l162 = alloca { i64, ptr }
  %l163 = alloca ptr
  %l164 = alloca ptr
  %l165 = alloca { i64, [3 x i64] }
  %l166 = alloca { i64, ptr }
  %l167 = alloca { i64, ptr }
  %l168 = alloca { i64, ptr }
  %l169 = alloca %"compiler/msgs:Msg"
  %l170 = alloca i64
  %l171 = alloca { i64, ptr }
  %l172 = alloca { i64, ptr }
  %l173 = alloca ptr
  %l174 = alloca ptr
  %l175 = alloca { i64, [3 x i64] }
  %l176 = alloca { i64, ptr }
  %l177 = alloca { i64, ptr }
  %l178 = alloca { i64, ptr }
  %l179 = alloca %"compiler/msgs:Msg"
  %l180 = alloca i64
  %l181 = alloca { i64, ptr }
  %l182 = alloca { i64, ptr }
  %l183 = alloca { i64, ptr }
  %l184 = alloca i1
  %l185 = alloca i32
  %l186 = alloca %"std/prelude/text:StringBuilder"
  %l187 = alloca ptr
  %l188 = alloca { i64, ptr }
  %l189 = alloca { i64, ptr }
  %l190 = alloca i64
  %l191 = alloca i64
  %l192 = alloca i64
  %l193 = alloca i1
  %l194 = alloca i64
  %l195 = alloca i64
  %l196 = alloca i1
  %l197 = alloca i64
  %l198 = alloca i64
  %l199 = alloca i64
  %l200 = alloca i64
  %l201 = alloca i64
  %l202 = alloca i64
  %l203 = alloca i64
  %l204 = alloca i64
  %l205 = alloca i64
  %l206 = alloca i64
  %l207 = alloca i64
  %l208 = alloca i1
  %l209 = alloca i1
  %l210 = alloca i64
  %l211 = alloca i64
  %l212 = alloca i64
  %l213 = alloca i64
  %l214 = alloca i64
  %l215 = alloca ptr
  %l216 = alloca ptr
  %l217 = alloca { i64, ptr }
  %l218 = alloca i64
  %l219 = alloca { i64, ptr }
  %l220 = alloca i64
  %l221 = alloca i64
  %l222 = alloca ptr
  %l223 = alloca ptr
  %l224 = alloca { i64, ptr }
  %l225 = alloca { i64, ptr }
  %l226 = alloca { i64, ptr }
  %l227 = alloca i64
  %l228 = alloca i64
  %l229 = alloca i1
  %l230 = alloca { i64, ptr }
  %l231 = alloca { i64, ptr }
  %l232 = alloca { i64, ptr }
  %l233 = alloca i64
  %l234 = alloca i64
  %l235 = alloca i1
  %l236 = alloca { i64, ptr }
  %l237 = alloca { i64, ptr }
  %l238 = alloca { i64, ptr }
  %l239 = alloca { i64, ptr }
  %l240 = alloca { i64, ptr }
  %l241 = alloca { i64, ptr }
  %l242 = alloca i1
  %l243 = alloca i1
  %l244 = alloca ptr
  %l245 = alloca ptr
  %l246 = alloca { i64, [3 x i64] }
  %l247 = alloca { i64, ptr }
  %l248 = alloca %"compiler/msgs:Msg"
  %l249 = alloca i64
  %l250 = alloca i32
  %l251 = alloca ptr
  %l252 = alloca { i64, ptr }
  %l253 = alloca { i64, ptr }
  %l254 = alloca { i64, ptr }
  %l255 = alloca i1
  %l256 = alloca i1
  %l257 = alloca { i64, ptr }
  %l258 = alloca i1
  %l259 = alloca { i64, ptr }
  %l260 = alloca { i64, ptr }
  %l261 = alloca { i64, ptr }
  %l262 = alloca { i64, ptr }
  %l263 = alloca { i64, ptr }
  %l264 = alloca i64
  %l265 = alloca i64
  %l266 = alloca i1
  %l267 = alloca { i64, ptr }
  %l268 = alloca { i64, ptr }
  %l269 = alloca { i64, ptr }
  %l270 = alloca { i64, ptr }
  %l271 = alloca { i64, ptr }
  %l272 = alloca { i64, ptr }
  %l273 = alloca i64
  %l274 = alloca i64
  %l275 = alloca i1
  %l276 = alloca { i64, ptr }
  %l277 = alloca i1
  %l278 = alloca { i64, ptr }
  %l279 = alloca { i64, ptr }
  %l280 = alloca { i64, ptr }
  %l281 = alloca { i64, ptr }
  %l282 = alloca ptr
  %l283 = alloca { i64, ptr }
  %l284 = alloca { i64, ptr }
  %l285 = alloca { i64, ptr }
  %l286 = alloca { i64, ptr }
  %l287 = alloca i64
  %l288 = alloca i64
  %l289 = alloca i1
  %l290 = alloca { i64, ptr }
  %l291 = alloca { i64, ptr }
  %l292 = alloca i64
  %l293 = alloca { i64, ptr }
  %l294 = alloca ptr
  %l295 = alloca { i64, ptr }
  %l296 = alloca i64
  %l297 = alloca ptr
  %l298 = alloca { i64, ptr }
  %l299 = alloca i8
  %l300 = alloca i64
  %l301 = alloca i32
  %l302 = alloca ptr
  %l303 = alloca { i64, ptr }
  %l304 = alloca i64
  %l305 = alloca i64
  %l306 = alloca i1
  %l307 = alloca i1
  %l308 = alloca i1
  %l309 = alloca { i64, ptr }
  %l310 = alloca { i64, ptr }
  %l311 = alloca { i64, ptr }
  %l312 = alloca { i64, ptr }
  %l313 = alloca i1
  %l314 = alloca i1
  %l315 = alloca { i64, ptr }
  %l316 = alloca i1
  %l317 = alloca i1
  %l318 = alloca i1
  %l319 = alloca { i64, ptr }
  %l320 = alloca i1
  %l321 = alloca i1
  %l322 = alloca ptr
  %l323 = alloca { i64, ptr }
  %l324 = alloca i1
  %l325 = alloca { i64, ptr }
  %l326 = alloca { i64, ptr }
  %l327 = alloca i64
  %l328 = alloca i64
  %l329 = alloca i1
  %l330 = alloca i64
  %l331 = alloca { i64, ptr }
  %l332 = alloca i1
  %l333 = alloca i1
  %l334 = alloca ptr
  %l335 = alloca { i64, ptr }
  %l336 = alloca { i64, ptr }
  %l337 = alloca { i64, ptr }
  %l338 = alloca i1
  %l339 = alloca ptr
  %l340 = alloca { i64, ptr }
  %l341 = alloca { i64, ptr }
  %l342 = alloca { i64, ptr }
  %l343 = alloca i64
  %l344 = alloca i64
  %l345 = alloca i1
  %l346 = alloca { i64, ptr }
  %l347 = alloca i1
  %l348 = alloca i1
  %l349 = alloca i1
  %l350 = alloca { i64, ptr }
  %l351 = alloca { i64, ptr }
  %l352 = alloca { i64, ptr }
  %l353 = alloca { i64, ptr }
  %l354 = alloca i1
  %l355 = alloca i1
  %l356 = alloca ptr
  %l357 = alloca ptr
  %l358 = alloca { i64, [3 x i64] }
  %l359 = alloca { i64, ptr }
  %l360 = alloca %"compiler/msgs:Msg"
  %l361 = alloca i64
  %l362 = alloca i32
  %l363 = alloca { i64, ptr }
  %l364 = alloca i1
  %l365 = alloca i1
  %l366 = alloca i1
  %l367 = alloca { i64, ptr }
  %l368 = alloca i1
  %l369 = alloca ptr
  %l370 = alloca ptr
  %l371 = alloca { i64, [3 x i64] }
  %l372 = alloca { i64, ptr }
  %l373 = alloca %"compiler/msgs:Msg"
  %l374 = alloca i64
  %l375 = alloca i32
  %l376 = alloca { i64, ptr }
  %l377 = alloca { i64, ptr }
  %l378 = alloca { { i64, ptr }, { i64, ptr } }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.builder
  %s4room = alloca [64 x i8], align 8
  %s5 = alloca %olang.builder
  %s5room = alloca [64 x i8], align 8
  %s6 = alloca %olang.builder
  %s6room = alloca [64 x i8], align 8
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.builder
  %s19room = alloca [64 x i8], align 8
  %s20 = alloca %olang.builder
  %s20room = alloca [64 x i8], align 8
  %s21 = alloca %olang.builder
  %s21room = alloca [64 x i8], align 8
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s25 = alloca %olang.builder
  %s25room = alloca [64 x i8], align 8
  %s26 = alloca %olang.builder
  %s26room = alloca [64 x i8], align 8
  %s27 = alloca %olang.scope
  %s28 = alloca %olang.builder
  %s28room = alloca [64 x i8], align 8
  %s29 = alloca %olang.builder
  %s29room = alloca [64 x i8], align 8
  %s30 = alloca %olang.builder
  %s30room = alloca [64 x i8], align 8
  %s31 = alloca %olang.builder
  %s31room = alloca [64 x i8], align 8
  %s32 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %s35 = alloca %olang.builder
  %s35room = alloca [64 x i8], align 8
  %s36 = alloca %olang.builder
  %s36room = alloca [64 x i8], align 8
  %s37 = alloca %olang.scope
  %s38 = alloca %olang.scope
  %rv = alloca { i32, { { i64, ptr }, { i64, ptr } } }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/load:Import" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l24
  %t2 = load ptr, ptr %l24
  %t3 = getelementptr %"compiler/load:Loader", ptr %t2, i32 0, i32 5
  store ptr %t3, ptr %l25
  %t4 = load i64, ptr %l1
  store i64 %t4, ptr %l26
  %t5 = load ptr, ptr %l25
  %t6 = load i64, ptr %l26
  %t7 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t5, i64 %t6)
  store ptr %t7, ptr %l27
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l27
  store ptr %t8, ptr %l3
  %t9 = load ptr, ptr %l0
  store ptr %t9, ptr %l28
  %t10 = load ptr, ptr %l3
  store ptr %t10, ptr %l29
  %t11 = getelementptr %"compiler/load:Import", ptr %l2, i32 0, i32 0
  %t12 = load %"compiler/source:Span", ptr %t11
  store %"compiler/source:Span" %t12, ptr %l30
  %t13 = load ptr, ptr %l28
  %t14 = load ptr, ptr %l29
  %t15 = load %"compiler/source:Span", ptr %l30
  %t16 = call { i64, [3 x i64] } @compiler_2fload_2ecompiler_2fload_3aLoader_2eat(ptr %v0, ptr %v0, ptr %t13, ptr %t14, %"compiler/source:Span" %t15)
  store { i64, [3 x i64] } %t16, ptr %l31
  br label %bb2
bb2:
  %t17 = load { i64, [3 x i64] }, ptr %l31
  store { i64, [3 x i64] } %t17, ptr %l4
  %t18 = getelementptr %"compiler/load:Import", ptr %l2, i32 0, i32 3
  %t19 = load { i64, ptr }, ptr %t18
  store { i64, ptr } %t19, ptr %l32
  %t20 = load { i64, ptr }, ptr %l32
  store { i64, ptr } %t20, ptr %l5
  %t21 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t21, ptr %l33
  %t22 = load { i64, ptr }, ptr %l33
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l34
  %t24 = load i64, ptr %l34
  %t25 = icmp sge i64 %t24, 4096
  store i1 %t25, ptr %l35
  %t26 = load i1, ptr %l35
  br i1 %t26, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t27 = load ptr, ptr %l0
  store ptr %t27, ptr %l36
  %t28 = load ptr, ptr %l36
  %t29 = getelementptr %"compiler/load:Loader", ptr %t28, i32 0, i32 4
  %t30 = load ptr, ptr %t29
  store ptr %t30, ptr %l37
  %t31 = load { i64, [3 x i64] }, ptr %l4
  store { i64, [3 x i64] } %t31, ptr %l38
  %t32 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportPathTooLong(ptr %s1)
  store %"compiler/msgs:Msg" %t32, ptr %l39
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t33 = load ptr, ptr %l37
  %t34 = load { i64, [3 x i64] }, ptr %l38
  %t35 = load %"compiler/msgs:Msg", ptr %l39
  %t36 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s1, ptr %t33, { i64, [3 x i64] } %t34, %"compiler/msgs:Msg" %t35)
  store i64 %t36, ptr %l40
  br label %bb6
bb6:
  store i32 65536, ptr %l41
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t37 = load i32, ptr %l41
  %t38 = insertvalue { i32, { { i64, ptr }, { i64, ptr } } } zeroinitializer, i32 %t37, 0
  store { i32, { { i64, ptr }, { i64, ptr } } } %t38, ptr %rv
  br label %ret
bb7:
  %t39 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t39, ptr %l42
  %t40 = load { i64, ptr }, ptr %l42
  %t41 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v1, ptr %s0, { i64, ptr } %t40, { i64, ptr } { i64 6, ptr @.d66 })
  store i1 %t41, ptr %l43
  br label %bb8
bb8:
  %t42 = load i1, ptr %l43
  br i1 %t42, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t43 = load ptr, ptr %l0
  store ptr %t43, ptr %l44
  %t44 = load ptr, ptr %l44
  %t45 = getelementptr %"compiler/load:Loader", ptr %t44, i32 0, i32 4
  %t46 = load ptr, ptr %t45
  store ptr %t46, ptr %l45
  %t47 = load { i64, [3 x i64] }, ptr %l4
  store { i64, [3 x i64] } %t47, ptr %l46
  %t48 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportHasExtension(ptr %s2)
  store %"compiler/msgs:Msg" %t48, ptr %l47
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t49 = load ptr, ptr %l45
  %t50 = load { i64, [3 x i64] }, ptr %l46
  %t51 = load %"compiler/msgs:Msg", ptr %l47
  %t52 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s2, ptr %t49, { i64, [3 x i64] } %t50, %"compiler/msgs:Msg" %t51)
  store i64 %t52, ptr %l48
  br label %bb12
bb12:
  store i32 65536, ptr %l49
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t53 = load i32, ptr %l49
  %t54 = insertvalue { i32, { { i64, ptr }, { i64, ptr } } } zeroinitializer, i32 %t53, 0
  store { i32, { { i64, ptr }, { i64, ptr } } } %t54, ptr %rv
  br label %ret
bb13:
  %t55 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t55, ptr %l51
  store i8 47, ptr %l52
  %t56 = load { i64, ptr }, ptr %l51
  %t57 = load i8, ptr %l52
  %t58 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v1, { i64, ptr } %t56, i8 %t57)
  %t59 = extractvalue { i32, i64 } %t58, 1
  %t60 = extractvalue { i32, i64 } %t58, 0
  store i32 %t60, ptr %l54
  %t61 = icmp ne i32 %t60, 0
  br i1 %t61, label %bb15, label %ok.62
ok.62:
  store i64 %t59, ptr %l53
  br label %bb14
bb14:
  %t63 = load i64, ptr %l53
  store i64 %t63, ptr %l50
  br label %bb17
bb15:
  br label %bb16
bb16:
  %t64 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t64, ptr %l55
  %t65 = load { i64, ptr }, ptr %l55
  %t66 = extractvalue { i64, ptr } %t65, 0
  store i64 %t66, ptr %l56
  %t67 = load i64, ptr %l56
  store i64 %t67, ptr %l50
  br label %bb17
bb17:
  %t68 = load i64, ptr %l50
  store i64 %t68, ptr %l6
  %t69 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t69, ptr %l57
  %t70 = load i64, ptr %l6
  store i64 %t70, ptr %l58
  %t71 = load { i64, ptr }, ptr %l57
  %t72 = extractvalue { i64, ptr } %t71, 0
  store i64 %t72, ptr %l59
  %t73 = icmp sge i64 0, 0
  store i1 %t73, ptr %l60
  %t74 = load i1, ptr %l60
  br i1 %t74, label %bb18, label %bb19
bb18:
  %t75 = load i64, ptr %l58
  %t76 = icmp sle i64 0, %t75
  store i1 %t76, ptr %l61
  %t77 = load i1, ptr %l61
  br i1 %t77, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @.c67)
  unreachable
bb20:
  %t78 = load i64, ptr %l58
  %t79 = load i64, ptr %l59
  %t80 = icmp sle i64 %t78, %t79
  store i1 %t80, ptr %l62
  %t81 = load i1, ptr %l62
  br i1 %t81, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @.c67)
  unreachable
bb22:
  %t82 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t83 = load ptr, ptr %t82
  %t84 = load i64, ptr %l58
  %t85 = getelementptr i8, ptr %t83, i64 0
  %t86 = sub i64 %t84, 0
  %t87 = insertvalue { i64, ptr } undef, i64 %t86, 0
  %t88 = insertvalue { i64, ptr } %t87, ptr %t85, 1
  store { i64, ptr } %t88, ptr %l63
  %t89 = load { i64, ptr }, ptr %l63
  store { i64, ptr } %t89, ptr %l7
  store { i64, ptr } { i64 0, ptr @.d68 }, ptr %l64
  %t90 = load { i64, ptr }, ptr %l64
  store { i64, ptr } %t90, ptr %l65
  %t91 = load { i64, ptr }, ptr %l65
  %t92 = extractvalue { i64, ptr } %t91, 0
  store i64 %t92, ptr %l66
  %t93 = load i64, ptr %l66
  %t94 = mul i64 %t93, 1
  %t95 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t94)
  %t96 = insertvalue { i64, ptr } undef, i64 %t93, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t95, 1
  store { i64, ptr } %t97, ptr %l67
  %t98 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t99 = load ptr, ptr %t98
  %t100 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t101 = load ptr, ptr %t100
  %t102 = load i64, ptr %l66
  %t103 = mul i64 %t102, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t99, ptr %t101, i64 %t103, i1 false)
  %t104 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t104, ptr %lp8
  %t105 = load { i64, ptr }, ptr %l67
  %t106 = load ptr, ptr %lp8
  store { i64, ptr } %t105, ptr %t106
  store { i64, ptr } { i64 0, ptr @.d69 }, ptr %l68
  %t107 = load { i64, ptr }, ptr %l68
  store { i64, ptr } %t107, ptr %l69
  %t108 = load { i64, ptr }, ptr %l69
  %t109 = extractvalue { i64, ptr } %t108, 0
  store i64 %t109, ptr %l70
  %t110 = load i64, ptr %l70
  %t111 = mul i64 %t110, 1
  %t112 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t111)
  %t113 = insertvalue { i64, ptr } undef, i64 %t110, 0
  %t114 = insertvalue { i64, ptr } %t113, ptr %t112, 1
  store { i64, ptr } %t114, ptr %l71
  %t115 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t116 = load ptr, ptr %t115
  %t117 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t118 = load ptr, ptr %t117
  %t119 = load i64, ptr %l70
  %t120 = mul i64 %t119, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t116, ptr %t118, i64 %t120, i1 false)
  %t121 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t121, ptr %lp9
  %t122 = load { i64, ptr }, ptr %l71
  %t123 = load ptr, ptr %lp9
  store { i64, ptr } %t122, ptr %t123
  %t124 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t124, ptr %l72
  %t125 = load { i64, ptr }, ptr %l72
  %t126 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s0, { i64, ptr } %t125, { i64, ptr } { i64 4, ptr @.d70 })
  store i1 %t126, ptr %l73
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @.c67)
  unreachable
bb24:
  %t127 = load i1, ptr %l73
  br i1 %t127, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s3
  %t128 = load ptr, ptr %l0
  store ptr %t128, ptr %l74
  %t129 = load ptr, ptr %l74
  %t130 = getelementptr %"compiler/load:Loader", ptr %t129, i32 0, i32 0
  %t131 = load { i64, ptr }, ptr %t130
  store { i64, ptr } %t131, ptr %l75
  %t132 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t132, ptr %l76
  %t133 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t133, ptr %l77
  %t134 = load { i64, ptr }, ptr %l77
  store { i64, ptr } %t134, ptr %l78
  %t135 = load { i64, ptr }, ptr %l78
  %t136 = extractvalue { i64, ptr } %t135, 0
  store i64 %t136, ptr %l79
  %t137 = load { i64, ptr }, ptr %l76
  %t138 = extractvalue { i64, ptr } %t137, 0
  store i64 %t138, ptr %l80
  %t139 = icmp sge i64 4, 0
  store i1 %t139, ptr %l81
  %t140 = load i1, ptr %l81
  br i1 %t140, label %bb27, label %bb28
bb26:
  store %olang.scope zeroinitializer, ptr %s8
  %t141 = load { i64, ptr }, ptr %l7
  store { i64, ptr } %t141, ptr %l107
  %t142 = load { i64, ptr }, ptr %l107
  store { i64, ptr } %t142, ptr %l108
  store { i64, ptr } { i64 1, ptr @.d71 }, ptr %l109
  %t143 = load { i64, ptr }, ptr %l108
  %t144 = load { i64, ptr }, ptr %l109
  %t145 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s8, { i64, ptr } %t143, { i64, ptr } %t144)
  store i1 %t145, ptr %l110
  br label %bb47
bb27:
  %t146 = load i64, ptr %l79
  %t147 = icmp sle i64 4, %t146
  store i1 %t147, ptr %l82
  %t148 = load i1, ptr %l82
  br i1 %t148, label %bb29, label %bb30
bb28:
  call void @__olang_check_failed(ptr @.c72)
  unreachable
bb29:
  %t149 = load i64, ptr %l79
  %t150 = load i64, ptr %l80
  %t151 = icmp sle i64 %t149, %t150
  store i1 %t151, ptr %l83
  %t152 = load i1, ptr %l83
  br i1 %t152, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @.c72)
  unreachable
bb31:
  %t153 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t154 = load ptr, ptr %t153
  %t155 = load i64, ptr %l79
  %t156 = getelementptr i8, ptr %t154, i64 4
  %t157 = sub i64 %t155, 4
  %t158 = insertvalue { i64, ptr } undef, i64 %t157, 0
  %t159 = insertvalue { i64, ptr } %t158, ptr %t156, 1
  store { i64, ptr } %t159, ptr %l84
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s4
  store ptr %s4room, ptr %s4
  %t160 = load { i64, ptr }, ptr %l75
  %t161 = extractvalue { i64, ptr } %t160, 1
  %t162 = extractvalue { i64, ptr } %t160, 0
  call void @__olang_sb_put(ptr %s4, ptr %t161, i64 %t162)
  %t163 = extractvalue { i64, ptr } { i64 1, ptr @.d73 }, 1
  %t164 = extractvalue { i64, ptr } { i64 1, ptr @.d73 }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t163, i64 %t164)
  %t165 = load { i64, ptr }, ptr %l84
  %t166 = extractvalue { i64, ptr } %t165, 1
  %t167 = extractvalue { i64, ptr } %t165, 0
  call void @__olang_sb_put(ptr %s4, ptr %t166, i64 %t167)
  %t168 = extractvalue { i64, ptr } { i64 6, ptr @.d74 }, 1
  %t169 = extractvalue { i64, ptr } { i64 6, ptr @.d74 }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t168, i64 %t169)
  %t170 = load ptr, ptr %s4
  %t171 = getelementptr %olang.builder, ptr %s4, i32 0, i32 1
  %t172 = load i64, ptr %t171
  %t173 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t172)
  call void @llvm.memcpy.p0.p0.i64(ptr %t173, ptr %t170, i64 %t172, i1 false)
  %t174 = insertvalue { i64, ptr } undef, i64 %t172, 0
  %t175 = insertvalue { i64, ptr } %t174, ptr %t173, 1
  store { i64, ptr } %t175, ptr %l85
  call void @__olang_sb_done(ptr %s4)
  %t176 = load { i64, ptr }, ptr %l85
  %t177 = extractvalue { i64, ptr } %t176, 0
  %t178 = extractvalue { i64, ptr } %t176, 1
  %t179 = mul i64 %t177, 1
  %t180 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t179)
  call void @llvm.memcpy.p0.p0.i64(ptr %t180, ptr %t178, i64 %t179, i1 false)
  %t181 = insertvalue { i64, ptr } undef, i64 %t177, 0
  %t182 = insertvalue { i64, ptr } %t181, ptr %t180, 1
  store { i64, ptr } %t182, ptr %l86
  %t183 = load { i64, ptr }, ptr %l86
  %t184 = call { i64, ptr } @compiler_2fload_2eNormalize(ptr %s3, ptr %s3, { i64, ptr } %t183)
  store { i64, ptr } %t184, ptr %l87
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @.c72)
  unreachable
bb33:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s5
  store ptr %s5room, ptr %s5
  %t185 = load { i64, ptr }, ptr %l87
  %t186 = extractvalue { i64, ptr } %t185, 1
  %t187 = extractvalue { i64, ptr } %t185, 0
  call void @__olang_sb_put(ptr %s5, ptr %t186, i64 %t187)
  %t188 = load ptr, ptr %s5
  %t189 = getelementptr %olang.builder, ptr %s5, i32 0, i32 1
  %t190 = load i64, ptr %t189
  %t191 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t190)
  call void @llvm.memcpy.p0.p0.i64(ptr %t191, ptr %t188, i64 %t190, i1 false)
  %t192 = insertvalue { i64, ptr } undef, i64 %t190, 0
  %t193 = insertvalue { i64, ptr } %t192, ptr %t191, 1
  store { i64, ptr } %t193, ptr %l88
  call void @__olang_sb_done(ptr %s5)
  %t194 = load ptr, ptr %lp8
  %t195 = load { i64, ptr }, ptr %t194
  %t196 = extractvalue { i64, ptr } %t195, 0
  store i64 %t196, ptr %l89
  %t197 = load { i64, ptr }, ptr %l88
  %t198 = extractvalue { i64, ptr } %t197, 0
  store i64 %t198, ptr %l90
  %t199 = load i64, ptr %l89
  %t200 = load i64, ptr %l90
  %t201 = icmp eq i64 %t199, %t200
  store i1 %t201, ptr %l91
  %t202 = load i1, ptr %l91
  br i1 %t202, label %bb34, label %bb35
bb34:
  %t203 = load ptr, ptr %lp8
  %t204 = getelementptr { i64, ptr }, ptr %t203, i32 0, i32 1
  %t205 = load ptr, ptr %t204
  %t206 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t207 = load ptr, ptr %t206
  %t208 = load i64, ptr %l90
  %t209 = mul i64 %t208, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t205, ptr %t207, i64 %t209, i1 false)
  br label %bb36
bb35:
  %t210 = load { i64, ptr }, ptr %l88
  %t211 = load ptr, ptr %lp8
  store { i64, ptr } %t210, ptr %t211
  br label %bb36
bb36:
  %t212 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t212, ptr %l92
  %t213 = load { i64, ptr }, ptr %l92
  %t214 = call { i64, ptr } @compiler_2fload_2eNormalize(ptr %v1, ptr %s3, { i64, ptr } %t213)
  store { i64, ptr } %t214, ptr %l93
  br label %bb37
bb37:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s6
  store ptr %s6room, ptr %s6
  %t215 = load { i64, ptr }, ptr %l93
  %t216 = extractvalue { i64, ptr } %t215, 1
  %t217 = extractvalue { i64, ptr } %t215, 0
  call void @__olang_sb_put(ptr %s6, ptr %t216, i64 %t217)
  %t218 = load ptr, ptr %s6
  %t219 = getelementptr %olang.builder, ptr %s6, i32 0, i32 1
  %t220 = load i64, ptr %t219
  %t221 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t220)
  call void @llvm.memcpy.p0.p0.i64(ptr %t221, ptr %t218, i64 %t220, i1 false)
  %t222 = insertvalue { i64, ptr } undef, i64 %t220, 0
  %t223 = insertvalue { i64, ptr } %t222, ptr %t221, 1
  store { i64, ptr } %t223, ptr %l94
  call void @__olang_sb_done(ptr %s6)
  %t224 = load ptr, ptr %lp9
  %t225 = load { i64, ptr }, ptr %t224
  %t226 = extractvalue { i64, ptr } %t225, 0
  store i64 %t226, ptr %l95
  %t227 = load { i64, ptr }, ptr %l94
  %t228 = extractvalue { i64, ptr } %t227, 0
  store i64 %t228, ptr %l96
  %t229 = load i64, ptr %l95
  %t230 = load i64, ptr %l96
  %t231 = icmp eq i64 %t229, %t230
  store i1 %t231, ptr %l97
  %t232 = load i1, ptr %l97
  br i1 %t232, label %bb38, label %bb39
bb38:
  %t233 = load ptr, ptr %lp9
  %t234 = getelementptr { i64, ptr }, ptr %t233, i32 0, i32 1
  %t235 = load ptr, ptr %t234
  %t236 = getelementptr { i64, ptr }, ptr %l94, i32 0, i32 1
  %t237 = load ptr, ptr %t236
  %t238 = load i64, ptr %l96
  %t239 = mul i64 %t238, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t235, ptr %t237, i64 %t239, i1 false)
  br label %bb40
bb39:
  %t240 = load { i64, ptr }, ptr %l94
  %t241 = load ptr, ptr %lp9
  store { i64, ptr } %t240, ptr %t241
  br label %bb40
bb40:
  %t242 = load ptr, ptr %lp9
  %t243 = load { i64, ptr }, ptr %t242
  store { i64, ptr } %t243, ptr %l98
  %t244 = load { i64, ptr }, ptr %l98
  %t245 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v2, ptr %s3, { i64, ptr } %t244, { i64, ptr } { i64 4, ptr @.d75 })
  store i1 %t245, ptr %l99
  br label %bb41
bb41:
  %t246 = load i1, ptr %l99
  %t247 = xor i1 %t246, true
  store i1 %t247, ptr %l100
  %t248 = load i1, ptr %l100
  br i1 %t248, label %bb42, label %bb43
bb42:
  store %olang.scope zeroinitializer, ptr %s7
  %t249 = load ptr, ptr %l0
  store ptr %t249, ptr %l101
  %t250 = load ptr, ptr %l101
  %t251 = getelementptr %"compiler/load:Loader", ptr %t250, i32 0, i32 4
  %t252 = load ptr, ptr %t251
  store ptr %t252, ptr %l102
  %t253 = load { i64, [3 x i64] }, ptr %l4
  store { i64, [3 x i64] } %t253, ptr %l103
  %t254 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportLeavesRoot(ptr %s7, ptr %s7, { i64, ptr } { i64 3, ptr @.d76 })
  store %"compiler/msgs:Msg" %t254, ptr %l104
  br label %bb44
bb43:
  br label %bb46
bb44:
  %t255 = load ptr, ptr %l102
  %t256 = load { i64, [3 x i64] }, ptr %l103
  %t257 = load %"compiler/msgs:Msg", ptr %l104
  %t258 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s7, ptr %t255, { i64, [3 x i64] } %t256, %"compiler/msgs:Msg" %t257)
  store i64 %t258, ptr %l105
  br label %bb45
bb45:
  store i32 65536, ptr %l106
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t259 = load i32, ptr %l106
  %t260 = insertvalue { i32, { { i64, ptr }, { i64, ptr } } } zeroinitializer, i32 %t259, 0
  store { i32, { { i64, ptr }, { i64, ptr } } } %t260, ptr %rv
  br label %ret
bb46:
  call void @__olang_scope_close(ptr %s3)
  br label %bb201
bb47:
  %t261 = load i1, ptr %l110
  br i1 %t261, label %bb48, label %bb49
bb48:
  %t262 = load { i64, ptr }, ptr %l7
  store { i64, ptr } %t262, ptr %l112
  %t263 = load { i64, ptr }, ptr %l112
  %t264 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s8, { i64, ptr } %t263, { i64, ptr } { i64 1, ptr @.d77 })
  store i1 %t264, ptr %l113
  br label %bb50
bb49:
  store i1 false, ptr %l111
  br label %bb51
bb50:
  %t265 = load i1, ptr %l113
  %t266 = xor i1 %t265, true
  store i1 %t266, ptr %l114
  %t267 = load i1, ptr %l114
  store i1 %t267, ptr %l111
  br label %bb51
bb51:
  %t268 = load i1, ptr %l111
  br i1 %t268, label %bb52, label %bb53
bb52:
  %t269 = load { i64, ptr }, ptr %l7
  store { i64, ptr } %t269, ptr %l116
  %t270 = load { i64, ptr }, ptr %l116
  %t271 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s8, { i64, ptr } %t270, { i64, ptr } { i64 2, ptr @.d78 })
  store i1 %t271, ptr %l117
  br label %bb54
bb53:
  store i1 false, ptr %l115
  br label %bb55
bb54:
  %t272 = load i1, ptr %l117
  %t273 = xor i1 %t272, true
  store i1 %t273, ptr %l118
  %t274 = load i1, ptr %l118
  store i1 %t274, ptr %l115
  br label %bb55
bb55:
  %t275 = load i1, ptr %l115
  br i1 %t275, label %bb56, label %bb57
bb56:
  store %olang.scope zeroinitializer, ptr %s9
  %t276 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t276, ptr %l119
  %t277 = load { i64, ptr }, ptr %l119
  %t278 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v1, ptr %s9, { i64, ptr } %t277, { i64, ptr } { i64 1, ptr @.d79 })
  store { i64, ptr } %t278, ptr %l120
  br label %bb58
bb57:
  store %olang.scope zeroinitializer, ptr %s23
  %t279 = load ptr, ptr %l3
  store ptr %t279, ptr %l251
  %t280 = load ptr, ptr %l251
  %t281 = getelementptr %"compiler/load:Module", ptr %t280, i32 0, i32 0
  %t282 = load { i64, ptr }, ptr %t281
  store { i64, ptr } %t282, ptr %l252
  %t283 = load { i64, ptr }, ptr %l252
  %t284 = call { i64, ptr } @compiler_2fload_2emoduleDir(ptr %v0, ptr %s23, { i64, ptr } %t283)
  store { i64, ptr } %t284, ptr %l253
  br label %bb127
bb58:
  %t285 = load { i64, ptr }, ptr %l120
  store { i64, ptr } %t285, ptr %l10
  %t286 = load { i64, ptr }, ptr %l10
  store { i64, ptr } %t286, ptr %l121
  %t287 = load { i64, ptr }, ptr %l121
  %t288 = extractvalue { i64, ptr } %t287, 0
  store i64 %t288, ptr %l122
  %t289 = load i64, ptr %l122
  %t290 = icmp slt i64 %t289, 4
  store i1 %t290, ptr %l123
  %t291 = load i1, ptr %l123
  br i1 %t291, label %bb59, label %bb60
bb59:
  store %olang.scope zeroinitializer, ptr %s10
  %t292 = load ptr, ptr %l0
  store ptr %t292, ptr %l124
  %t293 = load ptr, ptr %l124
  %t294 = getelementptr %"compiler/load:Loader", ptr %t293, i32 0, i32 4
  %t295 = load ptr, ptr %t294
  store ptr %t295, ptr %l125
  %t296 = load { i64, [3 x i64] }, ptr %l4
  store { i64, [3 x i64] } %t296, ptr %l126
  %t297 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportRemoteNeedsFile(ptr %s10)
  store %"compiler/msgs:Msg" %t297, ptr %l127
  br label %bb61
bb60:
  br label %bb63
bb61:
  %t298 = load ptr, ptr %l125
  %t299 = load { i64, [3 x i64] }, ptr %l126
  %t300 = load %"compiler/msgs:Msg", ptr %l127
  %t301 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s10, ptr %t298, { i64, [3 x i64] } %t299, %"compiler/msgs:Msg" %t300)
  store i64 %t301, ptr %l128
  br label %bb62
bb62:
  store i32 65536, ptr %l129
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t302 = load i32, ptr %l129
  %t303 = insertvalue { i32, { { i64, ptr }, { i64, ptr } } } zeroinitializer, i32 %t302, 0
  store { i32, { { i64, ptr }, { i64, ptr } } } %t303, ptr %rv
  br label %ret
bb63:
  %t304 = load ptr, ptr %l0
  store ptr %t304, ptr %l131
  %t305 = load ptr, ptr %l131
  %t306 = getelementptr %"compiler/load:Loader", ptr %t305, i32 0, i32 2
  %t307 = load ptr, ptr %t306
  store ptr %t307, ptr %l132
  %t308 = load { i64, ptr }, ptr %l10
  store { i64, ptr } %t308, ptr %l133
  %t309 = getelementptr { i64, ptr }, ptr %l133, i32 0, i32 1
  %t310 = load ptr, ptr %t309
  %t311 = getelementptr { i64, ptr }, ptr %t310, i64 0
  %t312 = load { i64, ptr }, ptr %t311
  store { i64, ptr } %t312, ptr %l134
  %t313 = load { i64, ptr }, ptr %l10
  store { i64, ptr } %t313, ptr %l135
  %t314 = getelementptr { i64, ptr }, ptr %l135, i32 0, i32 1
  %t315 = load ptr, ptr %t314
  %t316 = getelementptr { i64, ptr }, ptr %t315, i64 1
  %t317 = load { i64, ptr }, ptr %t316
  store { i64, ptr } %t317, ptr %l136
  %t318 = load { i64, ptr }, ptr %l10
  store { i64, ptr } %t318, ptr %l137
  %t319 = getelementptr { i64, ptr }, ptr %l137, i32 0, i32 1
  %t320 = load ptr, ptr %t319
  %t321 = getelementptr { i64, ptr }, ptr %t320, i64 2
  %t322 = load { i64, ptr }, ptr %t321
  store { i64, ptr } %t322, ptr %l138
  %t323 = load ptr, ptr %l132
  %t324 = load { i64, ptr }, ptr %l134
  %t325 = load { i64, ptr }, ptr %l136
  %t326 = load { i64, ptr }, ptr %l138
  %t327 = call { i32, { i64, ptr } } @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2eFetch(ptr %v0, ptr %v1, ptr %v1, ptr %v1, ptr %s9, ptr %t323, { i64, ptr } %t324, { i64, ptr } %t325, { i64, ptr } %t326)
  %t328 = extractvalue { i32, { i64, ptr } } %t327, 1
  %t329 = extractvalue { i32, { i64, ptr } } %t327, 0
  store i32 %t329, ptr %l140
  %t330 = icmp ne i32 %t329, 0
  br i1 %t330, label %bb65, label %ok.331
ok.331:
  store { i64, ptr } %t328, ptr %l139
  br label %bb64
bb64:
  %t332 = load { i64, ptr }, ptr %l139
  store { i64, ptr } %t332, ptr %l130
  br label %bb89
bb65:
  %t333 = load i32, ptr %l140
  %t334 = icmp eq i32 %t333, 65536
  store i1 %t334, ptr %l141
  %t335 = load i1, ptr %l141
  br i1 %t335, label %bb66, label %bb67
bb66:
  br label %bb68
bb67:
  %t336 = load i32, ptr %l140
  %t337 = icmp eq i32 %t336, 65537
  store i1 %t337, ptr %l142
  %t338 = load i1, ptr %l142
  br i1 %t338, label %bb69, label %bb70
bb68:
  store %olang.scope zeroinitializer, ptr %s11
  %t339 = load ptr, ptr %l0
  store ptr %t339, ptr %l146
  %t340 = load ptr, ptr %l146
  %t341 = getelementptr %"compiler/load:Loader", ptr %t340, i32 0, i32 4
  %t342 = load ptr, ptr %t341
  store ptr %t342, ptr %l147
  %t343 = load { i64, [3 x i64] }, ptr %l4
  store { i64, [3 x i64] } %t343, ptr %l148
  %t344 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportRemoteBadName(ptr %s11)
  store %"compiler/msgs:Msg" %t344, ptr %l149
  br label %bb78
bb69:
  br label %bb71
bb70:
  %t345 = load i32, ptr %l140
  %t346 = icmp eq i32 %t345, 65538
  store i1 %t346, ptr %l143
  %t347 = load i1, ptr %l143
  br i1 %t347, label %bb72, label %bb73
bb71:
  store %olang.scope zeroinitializer, ptr %s12
  %t348 = load ptr, ptr %l0
  store ptr %t348, ptr %l153
  %t349 = load ptr, ptr %l153
  %t350 = getelementptr %"compiler/load:Loader", ptr %t349, i32 0, i32 4
  %t351 = load ptr, ptr %t350
  store ptr %t351, ptr %l154
  %t352 = load { i64, [3 x i64] }, ptr %l4
  store { i64, [3 x i64] } %t352, ptr %l155
  %t353 = load { i64, ptr }, ptr %l10
  store { i64, ptr } %t353, ptr %l156
  %t354 = load { i64, ptr }, ptr %l156
  %t355 = call { i64, ptr } @compiler_2fload_2ekey(ptr %v1, ptr %s12, { i64, ptr } %t354)
  store { i64, ptr } %t355, ptr %l157
  br label %bb80
bb72:
  br label %bb74
bb73:
  %t356 = load i32, ptr %l140
  %t357 = icmp eq i32 %t356, 65539
  store i1 %t357, ptr %l144
  %t358 = load i1, ptr %l144
  br i1 %t358, label %bb75, label %bb76
bb74:
  store %olang.scope zeroinitializer, ptr %s13
  %t359 = load ptr, ptr %l0
  store ptr %t359, ptr %l163
  %t360 = load ptr, ptr %l163
  %t361 = getelementptr %"compiler/load:Loader", ptr %t360, i32 0, i32 4
  %t362 = load ptr, ptr %t361
  store ptr %t362, ptr %l164
  %t363 = load { i64, [3 x i64] }, ptr %l4
  store { i64, [3 x i64] } %t363, ptr %l165
  %t364 = load { i64, ptr }, ptr %l10
  store { i64, ptr } %t364, ptr %l166
  %t365 = load { i64, ptr }, ptr %l166
  %t366 = call { i64, ptr } @compiler_2fload_2ekey(ptr %v1, ptr %s13, { i64, ptr } %t365)
  store { i64, ptr } %t366, ptr %l167
  br label %bb83
bb75:
  br label %bb77
bb76:
  %t367 = load i32, ptr %l140
  %t368 = lshr i32 %t367, 16
  %t369 = and i32 %t367, 65535
  %t370 = icmp eq i32 %t368, 1
  %t371 = select i1 %t370, i32 0, i32 0
  %t372 = icmp eq i32 %t367, 0
  %t373 = shl i32 %t371, 16
  %t374 = or i32 %t373, %t369
  %t375 = select i1 %t372, i32 0, i32 %t374
  store i32 %t375, ptr %l145
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t376 = load i32, ptr %l145
  %t377 = insertvalue { i32, { { i64, ptr }, { i64, ptr } } } zeroinitializer, i32 %t376, 0
  store { i32, { { i64, ptr }, { i64, ptr } } } %t377, ptr %rv
  br label %ret
bb77:
  store %olang.scope zeroinitializer, ptr %s14
  %t378 = load ptr, ptr %l0
  store ptr %t378, ptr %l173
  %t379 = load ptr, ptr %l173
  %t380 = getelementptr %"compiler/load:Loader", ptr %t379, i32 0, i32 4
  %t381 = load ptr, ptr %t380
  store ptr %t381, ptr %l174
  %t382 = load { i64, [3 x i64] }, ptr %l4
  store { i64, [3 x i64] } %t382, ptr %l175
  %t383 = load { i64, ptr }, ptr %l10
  store { i64, ptr } %t383, ptr %l176
  %t384 = load { i64, ptr }, ptr %l176
  %t385 = call { i64, ptr } @compiler_2fload_2ekey(ptr %v1, ptr %s14, { i64, ptr } %t384)
  store { i64, ptr } %t385, ptr %l177
  br label %bb86
bb78:
  %t386 = load ptr, ptr %l147
  %t387 = load { i64, [3 x i64] }, ptr %l148
  %t388 = load %"compiler/msgs:Msg", ptr %l149
  %t389 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s11, ptr %t386, { i64, [3 x i64] } %t387, %"compiler/msgs:Msg" %t388)
  store i64 %t389, ptr %l150
  br label %bb79
bb79:
  call void @__olang_scope_close(ptr %s11)
  store { i64, ptr } { i64 0, ptr @.d80 }, ptr %l151
  %t390 = load { i64, ptr }, ptr %l151
  store { i64, ptr } %t390, ptr %l152
  %t391 = load { i64, ptr }, ptr %l152
  store { i64, ptr } %t391, ptr %l130
  br label %bb89
bb80:
  %t392 = load { i64, ptr }, ptr %l157
  %t393 = extractvalue { i64, ptr } %t392, 0
  %t394 = extractvalue { i64, ptr } %t392, 1
  %t395 = mul i64 %t393, 1
  %t396 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t395)
  call void @llvm.memcpy.p0.p0.i64(ptr %t396, ptr %t394, i64 %t395, i1 false)
  %t397 = insertvalue { i64, ptr } undef, i64 %t393, 0
  %t398 = insertvalue { i64, ptr } %t397, ptr %t396, 1
  store { i64, ptr } %t398, ptr %l158
  %t399 = load { i64, ptr }, ptr %l158
  %t400 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportLockNotACommit(ptr %s12, ptr %s12, { i64, ptr } %t399)
  store %"compiler/msgs:Msg" %t400, ptr %l159
  br label %bb81
bb81:
  %t401 = load ptr, ptr %l154
  %t402 = load { i64, [3 x i64] }, ptr %l155
  %t403 = load %"compiler/msgs:Msg", ptr %l159
  %t404 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s12, ptr %t401, { i64, [3 x i64] } %t402, %"compiler/msgs:Msg" %t403)
  store i64 %t404, ptr %l160
  br label %bb82
bb82:
  call void @__olang_scope_close(ptr %s12)
  store { i64, ptr } { i64 0, ptr @.d81 }, ptr %l161
  %t405 = load { i64, ptr }, ptr %l161
  store { i64, ptr } %t405, ptr %l162
  %t406 = load { i64, ptr }, ptr %l162
  store { i64, ptr } %t406, ptr %l130
  br label %bb89
bb83:
  %t407 = load { i64, ptr }, ptr %l167
  %t408 = extractvalue { i64, ptr } %t407, 0
  %t409 = extractvalue { i64, ptr } %t407, 1
  %t410 = mul i64 %t408, 1
  %t411 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t410)
  call void @llvm.memcpy.p0.p0.i64(ptr %t411, ptr %t409, i64 %t410, i1 false)
  %t412 = insertvalue { i64, ptr } undef, i64 %t408, 0
  %t413 = insertvalue { i64, ptr } %t412, ptr %t411, 1
  store { i64, ptr } %t413, ptr %l168
  %t414 = load { i64, ptr }, ptr %l168
  %t415 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportFetchFailed(ptr %s13, ptr %s13, { i64, ptr } %t414)
  store %"compiler/msgs:Msg" %t415, ptr %l169
  br label %bb84
bb84:
  %t416 = load ptr, ptr %l164
  %t417 = load { i64, [3 x i64] }, ptr %l165
  %t418 = load %"compiler/msgs:Msg", ptr %l169
  %t419 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s13, ptr %t416, { i64, [3 x i64] } %t417, %"compiler/msgs:Msg" %t418)
  store i64 %t419, ptr %l170
  br label %bb85
bb85:
  call void @__olang_scope_close(ptr %s13)
  store { i64, ptr } { i64 0, ptr @.d82 }, ptr %l171
  %t420 = load { i64, ptr }, ptr %l171
  store { i64, ptr } %t420, ptr %l172
  %t421 = load { i64, ptr }, ptr %l172
  store { i64, ptr } %t421, ptr %l130
  br label %bb89
bb86:
  %t422 = load { i64, ptr }, ptr %l177
  %t423 = extractvalue { i64, ptr } %t422, 0
  %t424 = extractvalue { i64, ptr } %t422, 1
  %t425 = mul i64 %t423, 1
  %t426 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t425)
  call void @llvm.memcpy.p0.p0.i64(ptr %t426, ptr %t424, i64 %t425, i1 false)
  %t427 = insertvalue { i64, ptr } undef, i64 %t423, 0
  %t428 = insertvalue { i64, ptr } %t427, ptr %t426, 1
  store { i64, ptr } %t428, ptr %l178
  %t429 = load { i64, ptr }, ptr %l178
  %t430 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportLockedFetchFailed(ptr %s14, ptr %s14, { i64, ptr } %t429)
  store %"compiler/msgs:Msg" %t430, ptr %l179
  br label %bb87
bb87:
  %t431 = load ptr, ptr %l174
  %t432 = load { i64, [3 x i64] }, ptr %l175
  %t433 = load %"compiler/msgs:Msg", ptr %l179
  %t434 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s14, ptr %t431, { i64, [3 x i64] } %t432, %"compiler/msgs:Msg" %t433)
  store i64 %t434, ptr %l180
  br label %bb88
bb88:
  call void @__olang_scope_close(ptr %s14)
  store { i64, ptr } { i64 0, ptr @.d83 }, ptr %l181
  %t435 = load { i64, ptr }, ptr %l181
  store { i64, ptr } %t435, ptr %l182
  %t436 = load { i64, ptr }, ptr %l182
  store { i64, ptr } %t436, ptr %l130
  br label %bb89
bb89:
  %t437 = load { i64, ptr }, ptr %l130
  store { i64, ptr } %t437, ptr %l11
  %t438 = load { i64, ptr }, ptr %l11
  store { i64, ptr } %t438, ptr %l183
  %t439 = load { i64, ptr }, ptr %l183
  %t440 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s9, ptr %s9, { i64, ptr } %t439, { i64, ptr } { i64 0, ptr @.d84 })
  store i1 %t440, ptr %l184
  br label %bb90
bb90:
  %t441 = load i1, ptr %l184
  br i1 %t441, label %bb91, label %bb92
bb91:
  store %olang.scope zeroinitializer, ptr %s15
  store i32 65536, ptr %l185
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t442 = load i32, ptr %l185
  %t443 = insertvalue { i32, { { i64, ptr }, { i64, ptr } } } zeroinitializer, i32 %t442, 0
  store { i32, { { i64, ptr }, { i64, ptr } } } %t443, ptr %rv
  br label %ret
bb92:
  br label %bb93
bb93:
  %t444 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s9)
  store %"std/prelude/text:StringBuilder" %t444, ptr %l186
  br label %bb94
bb94:
  %t445 = load %"std/prelude/text:StringBuilder", ptr %l186
  store %"std/prelude/text:StringBuilder" %t445, ptr %l12
  store ptr %l12, ptr %l187
  %t446 = load { i64, ptr }, ptr %l11
  store { i64, ptr } %t446, ptr %l188
  %t447 = load ptr, ptr %l187
  %t448 = load { i64, ptr }, ptr %l188
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s9, ptr %s9, ptr %t447, { i64, ptr } %t448)
  br label %bb95
bb95:
  store %olang.scope zeroinitializer, ptr %s16
  store i64 3, ptr %l13
  %t449 = load { i64, ptr }, ptr %l10
  store { i64, ptr } %t449, ptr %l189
  %t450 = load { i64, ptr }, ptr %l189
  %t451 = extractvalue { i64, ptr } %t450, 0
  store i64 %t451, ptr %l190
  %t452 = load i64, ptr %l190
  store i64 %t452, ptr %l14
  store i64 1, ptr %l15
  %t453 = load i64, ptr %l14
  store i64 %t453, ptr %l191
  %t454 = load i64, ptr %l13
  store i64 %t454, ptr %l192
  %t455 = load i64, ptr %l191
  %t456 = load i64, ptr %l192
  %t457 = icmp sgt i64 %t455, %t456
  store i1 %t457, ptr %l193
  %t458 = load i1, ptr %l193
  br i1 %t458, label %bb96, label %bb97
bb96:
  %t459 = load i64, ptr %l15
  store i64 %t459, ptr %l195
  %t460 = load i64, ptr %l195
  %t461 = icmp sgt i64 %t460, 0
  store i1 %t461, ptr %l196
  %t462 = load i1, ptr %l196
  br i1 %t462, label %bb98, label %bb99
bb97:
  store i64 0, ptr %l194
  br label %bb101
bb98:
  %t463 = load i64, ptr %l14
  store i64 %t463, ptr %l198
  %t464 = load i64, ptr %l13
  store i64 %t464, ptr %l199
  %t465 = load i64, ptr %l198
  %t466 = load i64, ptr %l199
  %t467 = sub i64 %t465, %t466
  store i64 %t467, ptr %l200
  %t468 = load i64, ptr %l15
  store i64 %t468, ptr %l201
  %t469 = load i64, ptr %l200
  %t470 = load i64, ptr %l201
  %t471 = add i64 %t469, %t470
  store i64 %t471, ptr %l202
  %t472 = load i64, ptr %l202
  %t473 = sub i64 %t472, 1
  store i64 %t473, ptr %l203
  %t474 = load i64, ptr %l15
  store i64 %t474, ptr %l204
  %t475 = load i64, ptr %l203
  %t476 = load i64, ptr %l204
  %t477 = sdiv i64 %t475, %t476
  store i64 %t477, ptr %l205
  %t478 = load i64, ptr %l205
  store i64 %t478, ptr %l197
  br label %bb100
bb99:
  store i64 0, ptr %l197
  br label %bb100
bb100:
  %t479 = load i64, ptr %l197
  store i64 %t479, ptr %l194
  br label %bb101
bb101:
  %t480 = load i64, ptr %l194
  store i64 %t480, ptr %l16
  store i64 0, ptr %l17
  br label %bb102
bb102:
  store %olang.scope zeroinitializer, ptr %s17
  %t481 = load i64, ptr %l17
  store i64 %t481, ptr %l206
  %t482 = load i64, ptr %l16
  store i64 %t482, ptr %l207
  %t483 = load i64, ptr %l206
  %t484 = load i64, ptr %l207
  %t485 = icmp slt i64 %t483, %t484
  store i1 %t485, ptr %l208
  %t486 = load i1, ptr %l208
  %t487 = xor i1 %t486, true
  store i1 %t487, ptr %l209
  %t488 = load i1, ptr %l209
  br i1 %t488, label %bb103, label %bb104
bb103:
  call void @__olang_scope_close(ptr %s17)
  br label %bb109
bb104:
  br label %bb105
bb105:
  %t489 = load i64, ptr %l13
  store i64 %t489, ptr %l210
  %t490 = load i64, ptr %l17
  store i64 %t490, ptr %l211
  %t491 = load i64, ptr %l15
  store i64 %t491, ptr %l212
  %t492 = load i64, ptr %l211
  %t493 = load i64, ptr %l212
  %t494 = mul i64 %t492, %t493
  store i64 %t494, ptr %l213
  %t495 = load i64, ptr %l210
  %t496 = load i64, ptr %l213
  %t497 = add i64 %t495, %t496
  store i64 %t497, ptr %l214
  %t498 = load i64, ptr %l214
  store i64 %t498, ptr %l18
  store ptr %l12, ptr %l215
  %t499 = load ptr, ptr %l215
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s9, ptr %t499, i8 47)
  br label %bb106
bb106:
  store ptr %l12, ptr %l216
  %t500 = load { i64, ptr }, ptr %l10
  store { i64, ptr } %t500, ptr %l217
  %t501 = load i64, ptr %l18
  store i64 %t501, ptr %l218
  %t502 = load i64, ptr %l218
  %t503 = getelementptr { i64, ptr }, ptr %l217, i32 0, i32 1
  %t504 = load ptr, ptr %t503
  %t505 = getelementptr { i64, ptr }, ptr %t504, i64 %t502
  %t506 = load { i64, ptr }, ptr %t505
  store { i64, ptr } %t506, ptr %l219
  %t507 = load ptr, ptr %l216
  %t508 = load { i64, ptr }, ptr %l219
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s9, ptr %v1, ptr %t507, { i64, ptr } %t508)
  br label %bb107
bb107:
  call void @__olang_scope_close(ptr %s17)
  br label %bb108
bb108:
  store %olang.scope zeroinitializer, ptr %s18
  %t509 = load i64, ptr %l17
  store i64 %t509, ptr %l220
  %t510 = load i64, ptr %l220
  %t511 = add i64 %t510, 1
  store i64 %t511, ptr %l221
  %t512 = load i64, ptr %l221
  store i64 %t512, ptr %l17
  call void @__olang_scope_close(ptr %s18)
  br label %bb102
bb109:
  call void @__olang_scope_close(ptr %s16)
  store ptr %l12, ptr %l222
  %t513 = load ptr, ptr %l222
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s9, ptr %s9, ptr %t513, { i64, ptr } { i64 6, ptr @.d85 })
  br label %bb110
bb110:
  store ptr %l12, ptr %l223
  %t514 = load ptr, ptr %l223
  %t515 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s9, ptr %s9, ptr %t514)
  store { i64, ptr } %t515, ptr %l224
  br label %bb111
bb111:
  %t516 = load { i64, ptr }, ptr %l224
  %t517 = call { i64, ptr } @compiler_2fload_2eNormalize(ptr %s9, ptr %s9, { i64, ptr } %t516)
  store { i64, ptr } %t517, ptr %l225
  br label %bb112
bb112:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s19
  store ptr %s19room, ptr %s19
  %t518 = load { i64, ptr }, ptr %l225
  %t519 = extractvalue { i64, ptr } %t518, 1
  %t520 = extractvalue { i64, ptr } %t518, 0
  call void @__olang_sb_put(ptr %s19, ptr %t519, i64 %t520)
  %t521 = load ptr, ptr %s19
  %t522 = getelementptr %olang.builder, ptr %s19, i32 0, i32 1
  %t523 = load i64, ptr %t522
  %t524 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t523)
  call void @llvm.memcpy.p0.p0.i64(ptr %t524, ptr %t521, i64 %t523, i1 false)
  %t525 = insertvalue { i64, ptr } undef, i64 %t523, 0
  %t526 = insertvalue { i64, ptr } %t525, ptr %t524, 1
  store { i64, ptr } %t526, ptr %l226
  call void @__olang_sb_done(ptr %s19)
  %t527 = load ptr, ptr %lp8
  %t528 = load { i64, ptr }, ptr %t527
  %t529 = extractvalue { i64, ptr } %t528, 0
  store i64 %t529, ptr %l227
  %t530 = load { i64, ptr }, ptr %l226
  %t531 = extractvalue { i64, ptr } %t530, 0
  store i64 %t531, ptr %l228
  %t532 = load i64, ptr %l227
  %t533 = load i64, ptr %l228
  %t534 = icmp eq i64 %t532, %t533
  store i1 %t534, ptr %l229
  %t535 = load i1, ptr %l229
  br i1 %t535, label %bb113, label %bb114
bb113:
  %t536 = load ptr, ptr %lp8
  %t537 = getelementptr { i64, ptr }, ptr %t536, i32 0, i32 1
  %t538 = load ptr, ptr %t537
  %t539 = getelementptr { i64, ptr }, ptr %l226, i32 0, i32 1
  %t540 = load ptr, ptr %t539
  %t541 = load i64, ptr %l228
  %t542 = mul i64 %t541, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t538, ptr %t540, i64 %t542, i1 false)
  br label %bb115
bb114:
  %t543 = load { i64, ptr }, ptr %l226
  %t544 = load ptr, ptr %lp8
  store { i64, ptr } %t543, ptr %t544
  br label %bb115
bb115:
  %t545 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t545, ptr %l230
  %t546 = load { i64, ptr }, ptr %l230
  %t547 = call { i64, ptr } @compiler_2fload_2eNormalize(ptr %v1, ptr %s9, { i64, ptr } %t546)
  store { i64, ptr } %t547, ptr %l231
  br label %bb116
bb116:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s20
  store ptr %s20room, ptr %s20
  %t548 = load { i64, ptr }, ptr %l231
  %t549 = extractvalue { i64, ptr } %t548, 1
  %t550 = extractvalue { i64, ptr } %t548, 0
  call void @__olang_sb_put(ptr %s20, ptr %t549, i64 %t550)
  %t551 = load ptr, ptr %s20
  %t552 = getelementptr %olang.builder, ptr %s20, i32 0, i32 1
  %t553 = load i64, ptr %t552
  %t554 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t553)
  call void @llvm.memcpy.p0.p0.i64(ptr %t554, ptr %t551, i64 %t553, i1 false)
  %t555 = insertvalue { i64, ptr } undef, i64 %t553, 0
  %t556 = insertvalue { i64, ptr } %t555, ptr %t554, 1
  store { i64, ptr } %t556, ptr %l232
  call void @__olang_sb_done(ptr %s20)
  %t557 = load ptr, ptr %lp9
  %t558 = load { i64, ptr }, ptr %t557
  %t559 = extractvalue { i64, ptr } %t558, 0
  store i64 %t559, ptr %l233
  %t560 = load { i64, ptr }, ptr %l232
  %t561 = extractvalue { i64, ptr } %t560, 0
  store i64 %t561, ptr %l234
  %t562 = load i64, ptr %l233
  %t563 = load i64, ptr %l234
  %t564 = icmp eq i64 %t562, %t563
  store i1 %t564, ptr %l235
  %t565 = load i1, ptr %l235
  br i1 %t565, label %bb117, label %bb118
bb117:
  %t566 = load ptr, ptr %lp9
  %t567 = getelementptr { i64, ptr }, ptr %t566, i32 0, i32 1
  %t568 = load ptr, ptr %t567
  %t569 = getelementptr { i64, ptr }, ptr %l232, i32 0, i32 1
  %t570 = load ptr, ptr %t569
  %t571 = load i64, ptr %l234
  %t572 = mul i64 %t571, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t568, ptr %t570, i64 %t572, i1 false)
  br label %bb119
bb118:
  %t573 = load { i64, ptr }, ptr %l232
  %t574 = load ptr, ptr %lp9
  store { i64, ptr } %t573, ptr %t574
  br label %bb119
bb119:
  %t575 = load { i64, ptr }, ptr %l10
  store { i64, ptr } %t575, ptr %l236
  %t576 = load { i64, ptr }, ptr %l236
  %t577 = call { i64, ptr } @compiler_2fload_2ekey(ptr %v1, ptr %s9, { i64, ptr } %t576)
  store { i64, ptr } %t577, ptr %l237
  br label %bb120
bb120:
  %t578 = load { i64, ptr }, ptr %l237
  store { i64, ptr } %t578, ptr %l19
  %t579 = load ptr, ptr %lp9
  %t580 = load { i64, ptr }, ptr %t579
  store { i64, ptr } %t580, ptr %l238
  %t581 = load { i64, ptr }, ptr %l19
  store { i64, ptr } %t581, ptr %l239
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s21
  store ptr %s21room, ptr %s21
  %t582 = load { i64, ptr }, ptr %l239
  %t583 = extractvalue { i64, ptr } %t582, 1
  %t584 = extractvalue { i64, ptr } %t582, 0
  call void @__olang_sb_put(ptr %s21, ptr %t583, i64 %t584)
  %t585 = extractvalue { i64, ptr } { i64 1, ptr @.d86 }, 1
  %t586 = extractvalue { i64, ptr } { i64 1, ptr @.d86 }, 0
  call void @__olang_sb_put(ptr %s21, ptr %t585, i64 %t586)
  %t587 = load ptr, ptr %s21
  %t588 = getelementptr %olang.builder, ptr %s21, i32 0, i32 1
  %t589 = load i64, ptr %t588
  %t590 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t589)
  call void @llvm.memcpy.p0.p0.i64(ptr %t590, ptr %t587, i64 %t589, i1 false)
  %t591 = insertvalue { i64, ptr } undef, i64 %t589, 0
  %t592 = insertvalue { i64, ptr } %t591, ptr %t590, 1
  store { i64, ptr } %t592, ptr %l240
  call void @__olang_sb_done(ptr %s21)
  %t593 = load { i64, ptr }, ptr %l240
  %t594 = extractvalue { i64, ptr } %t593, 0
  %t595 = extractvalue { i64, ptr } %t593, 1
  %t596 = mul i64 %t594, 1
  %t597 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t596)
  call void @llvm.memcpy.p0.p0.i64(ptr %t597, ptr %t595, i64 %t596, i1 false)
  %t598 = insertvalue { i64, ptr } undef, i64 %t594, 0
  %t599 = insertvalue { i64, ptr } %t598, ptr %t597, 1
  store { i64, ptr } %t599, ptr %l241
  %t600 = load { i64, ptr }, ptr %l238
  %t601 = load { i64, ptr }, ptr %l241
  %t602 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v2, ptr %s9, { i64, ptr } %t600, { i64, ptr } %t601)
  store i1 %t602, ptr %l242
  br label %bb121
bb121:
  %t603 = load i1, ptr %l242
  %t604 = xor i1 %t603, true
  store i1 %t604, ptr %l243
  %t605 = load i1, ptr %l243
  br i1 %t605, label %bb122, label %bb123
bb122:
  store %olang.scope zeroinitializer, ptr %s22
  %t606 = load ptr, ptr %l0
  store ptr %t606, ptr %l244
  %t607 = load ptr, ptr %l244
  %t608 = getelementptr %"compiler/load:Loader", ptr %t607, i32 0, i32 4
  %t609 = load ptr, ptr %t608
  store ptr %t609, ptr %l245
  %t610 = load { i64, [3 x i64] }, ptr %l4
  store { i64, [3 x i64] } %t610, ptr %l246
  %t611 = load { i64, ptr }, ptr %l19
  store { i64, ptr } %t611, ptr %l247
  %t612 = load { i64, ptr }, ptr %l247
  %t613 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportLeavesRoot(ptr %s9, ptr %s22, { i64, ptr } %t612)
  store %"compiler/msgs:Msg" %t613, ptr %l248
  br label %bb124
bb123:
  br label %bb126
bb124:
  %t614 = load ptr, ptr %l245
  %t615 = load { i64, [3 x i64] }, ptr %l246
  %t616 = load %"compiler/msgs:Msg", ptr %l248
  %t617 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s22, ptr %t614, { i64, [3 x i64] } %t615, %"compiler/msgs:Msg" %t616)
  store i64 %t617, ptr %l249
  br label %bb125
bb125:
  store i32 65536, ptr %l250
  call void @__olang_scope_close(ptr %s22)
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t618 = load i32, ptr %l250
  %t619 = insertvalue { i32, { { i64, ptr }, { i64, ptr } } } zeroinitializer, i32 %t618, 0
  store { i32, { { i64, ptr }, { i64, ptr } } } %t619, ptr %rv
  br label %ret
bb126:
  call void @__olang_scope_close(ptr %s9)
  br label %bb200
bb127:
  %t620 = load { i64, ptr }, ptr %l253
  store { i64, ptr } %t620, ptr %l20
  %t621 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t621, ptr %l254
  %t622 = load { i64, ptr }, ptr %l254
  %t623 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s23, { i64, ptr } %t622, { i64, ptr } { i64 1, ptr @.d87 })
  store i1 %t623, ptr %l255
  br label %bb128
bb128:
  %t624 = load i1, ptr %l255
  br i1 %t624, label %bb129, label %bb130
bb129:
  store i1 true, ptr %l256
  br label %bb132
bb130:
  %t625 = load { i64, ptr }, ptr %l20
  store { i64, ptr } %t625, ptr %l257
  %t626 = load { i64, ptr }, ptr %l257
  %t627 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s23, ptr %s23, { i64, ptr } %t626, { i64, ptr } { i64 1, ptr @.d88 })
  store i1 %t627, ptr %l258
  br label %bb131
bb131:
  %t628 = load i1, ptr %l258
  store i1 %t628, ptr %l256
  br label %bb132
bb132:
  %t629 = load i1, ptr %l256
  br i1 %t629, label %bb133, label %bb134
bb133:
  store %olang.scope zeroinitializer, ptr %s24
  %t630 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t630, ptr %l259
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s25
  store ptr %s25room, ptr %s25
  %t631 = load { i64, ptr }, ptr %l259
  %t632 = extractvalue { i64, ptr } %t631, 1
  %t633 = extractvalue { i64, ptr } %t631, 0
  call void @__olang_sb_put(ptr %s25, ptr %t632, i64 %t633)
  %t634 = extractvalue { i64, ptr } { i64 6, ptr @.d89 }, 1
  %t635 = extractvalue { i64, ptr } { i64 6, ptr @.d89 }, 0
  call void @__olang_sb_put(ptr %s25, ptr %t634, i64 %t635)
  %t636 = load ptr, ptr %s25
  %t637 = getelementptr %olang.builder, ptr %s25, i32 0, i32 1
  %t638 = load i64, ptr %t637
  %t639 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t638)
  call void @llvm.memcpy.p0.p0.i64(ptr %t639, ptr %t636, i64 %t638, i1 false)
  %t640 = insertvalue { i64, ptr } undef, i64 %t638, 0
  %t641 = insertvalue { i64, ptr } %t640, ptr %t639, 1
  store { i64, ptr } %t641, ptr %l260
  call void @__olang_sb_done(ptr %s25)
  %t642 = load { i64, ptr }, ptr %l260
  %t643 = extractvalue { i64, ptr } %t642, 0
  %t644 = extractvalue { i64, ptr } %t642, 1
  %t645 = mul i64 %t643, 1
  %t646 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t645)
  call void @llvm.memcpy.p0.p0.i64(ptr %t646, ptr %t644, i64 %t645, i1 false)
  %t647 = insertvalue { i64, ptr } undef, i64 %t643, 0
  %t648 = insertvalue { i64, ptr } %t647, ptr %t646, 1
  store { i64, ptr } %t648, ptr %l261
  %t649 = load { i64, ptr }, ptr %l261
  %t650 = call { i64, ptr } @compiler_2fload_2eNormalize(ptr %s24, ptr %s24, { i64, ptr } %t649)
  store { i64, ptr } %t650, ptr %l262
  br label %bb135
bb134:
  store %olang.scope zeroinitializer, ptr %s27
  %t651 = load { i64, ptr }, ptr %l20
  store { i64, ptr } %t651, ptr %l267
  %t652 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t652, ptr %l268
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s28
  store ptr %s28room, ptr %s28
  %t653 = load { i64, ptr }, ptr %l267
  %t654 = extractvalue { i64, ptr } %t653, 1
  %t655 = extractvalue { i64, ptr } %t653, 0
  call void @__olang_sb_put(ptr %s28, ptr %t654, i64 %t655)
  %t656 = extractvalue { i64, ptr } { i64 1, ptr @.d90 }, 1
  %t657 = extractvalue { i64, ptr } { i64 1, ptr @.d90 }, 0
  call void @__olang_sb_put(ptr %s28, ptr %t656, i64 %t657)
  %t658 = load { i64, ptr }, ptr %l268
  %t659 = extractvalue { i64, ptr } %t658, 1
  %t660 = extractvalue { i64, ptr } %t658, 0
  call void @__olang_sb_put(ptr %s28, ptr %t659, i64 %t660)
  %t661 = extractvalue { i64, ptr } { i64 6, ptr @.d91 }, 1
  %t662 = extractvalue { i64, ptr } { i64 6, ptr @.d91 }, 0
  call void @__olang_sb_put(ptr %s28, ptr %t661, i64 %t662)
  %t663 = load ptr, ptr %s28
  %t664 = getelementptr %olang.builder, ptr %s28, i32 0, i32 1
  %t665 = load i64, ptr %t664
  %t666 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t665)
  call void @llvm.memcpy.p0.p0.i64(ptr %t666, ptr %t663, i64 %t665, i1 false)
  %t667 = insertvalue { i64, ptr } undef, i64 %t665, 0
  %t668 = insertvalue { i64, ptr } %t667, ptr %t666, 1
  store { i64, ptr } %t668, ptr %l269
  call void @__olang_sb_done(ptr %s28)
  %t669 = load { i64, ptr }, ptr %l269
  %t670 = extractvalue { i64, ptr } %t669, 0
  %t671 = extractvalue { i64, ptr } %t669, 1
  %t672 = mul i64 %t670, 1
  %t673 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t672)
  call void @llvm.memcpy.p0.p0.i64(ptr %t673, ptr %t671, i64 %t672, i1 false)
  %t674 = insertvalue { i64, ptr } undef, i64 %t670, 0
  %t675 = insertvalue { i64, ptr } %t674, ptr %t673, 1
  store { i64, ptr } %t675, ptr %l270
  %t676 = load { i64, ptr }, ptr %l270
  %t677 = call { i64, ptr } @compiler_2fload_2eNormalize(ptr %s27, ptr %s27, { i64, ptr } %t676)
  store { i64, ptr } %t677, ptr %l271
  br label %bb139
bb135:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s26
  store ptr %s26room, ptr %s26
  %t678 = load { i64, ptr }, ptr %l262
  %t679 = extractvalue { i64, ptr } %t678, 1
  %t680 = extractvalue { i64, ptr } %t678, 0
  call void @__olang_sb_put(ptr %s26, ptr %t679, i64 %t680)
  %t681 = load ptr, ptr %s26
  %t682 = getelementptr %olang.builder, ptr %s26, i32 0, i32 1
  %t683 = load i64, ptr %t682
  %t684 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t683)
  call void @llvm.memcpy.p0.p0.i64(ptr %t684, ptr %t681, i64 %t683, i1 false)
  %t685 = insertvalue { i64, ptr } undef, i64 %t683, 0
  %t686 = insertvalue { i64, ptr } %t685, ptr %t684, 1
  store { i64, ptr } %t686, ptr %l263
  call void @__olang_sb_done(ptr %s26)
  %t687 = load ptr, ptr %lp8
  %t688 = load { i64, ptr }, ptr %t687
  %t689 = extractvalue { i64, ptr } %t688, 0
  store i64 %t689, ptr %l264
  %t690 = load { i64, ptr }, ptr %l263
  %t691 = extractvalue { i64, ptr } %t690, 0
  store i64 %t691, ptr %l265
  %t692 = load i64, ptr %l264
  %t693 = load i64, ptr %l265
  %t694 = icmp eq i64 %t692, %t693
  store i1 %t694, ptr %l266
  %t695 = load i1, ptr %l266
  br i1 %t695, label %bb136, label %bb137
bb136:
  %t696 = load ptr, ptr %lp8
  %t697 = getelementptr { i64, ptr }, ptr %t696, i32 0, i32 1
  %t698 = load ptr, ptr %t697
  %t699 = getelementptr { i64, ptr }, ptr %l263, i32 0, i32 1
  %t700 = load ptr, ptr %t699
  %t701 = load i64, ptr %l265
  %t702 = mul i64 %t701, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t698, ptr %t700, i64 %t702, i1 false)
  br label %bb138
bb137:
  %t703 = load { i64, ptr }, ptr %l263
  %t704 = load ptr, ptr %lp8
  store { i64, ptr } %t703, ptr %t704
  br label %bb138
bb138:
  call void @__olang_scope_close(ptr %s24)
  br label %bb143
bb139:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s29
  store ptr %s29room, ptr %s29
  %t705 = load { i64, ptr }, ptr %l271
  %t706 = extractvalue { i64, ptr } %t705, 1
  %t707 = extractvalue { i64, ptr } %t705, 0
  call void @__olang_sb_put(ptr %s29, ptr %t706, i64 %t707)
  %t708 = load ptr, ptr %s29
  %t709 = getelementptr %olang.builder, ptr %s29, i32 0, i32 1
  %t710 = load i64, ptr %t709
  %t711 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t710)
  call void @llvm.memcpy.p0.p0.i64(ptr %t711, ptr %t708, i64 %t710, i1 false)
  %t712 = insertvalue { i64, ptr } undef, i64 %t710, 0
  %t713 = insertvalue { i64, ptr } %t712, ptr %t711, 1
  store { i64, ptr } %t713, ptr %l272
  call void @__olang_sb_done(ptr %s29)
  %t714 = load ptr, ptr %lp8
  %t715 = load { i64, ptr }, ptr %t714
  %t716 = extractvalue { i64, ptr } %t715, 0
  store i64 %t716, ptr %l273
  %t717 = load { i64, ptr }, ptr %l272
  %t718 = extractvalue { i64, ptr } %t717, 0
  store i64 %t718, ptr %l274
  %t719 = load i64, ptr %l273
  %t720 = load i64, ptr %l274
  %t721 = icmp eq i64 %t719, %t720
  store i1 %t721, ptr %l275
  %t722 = load i1, ptr %l275
  br i1 %t722, label %bb140, label %bb141
bb140:
  %t723 = load ptr, ptr %lp8
  %t724 = getelementptr { i64, ptr }, ptr %t723, i32 0, i32 1
  %t725 = load ptr, ptr %t724
  %t726 = getelementptr { i64, ptr }, ptr %l272, i32 0, i32 1
  %t727 = load ptr, ptr %t726
  %t728 = load i64, ptr %l274
  %t729 = mul i64 %t728, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t725, ptr %t727, i64 %t729, i1 false)
  br label %bb142
bb141:
  %t730 = load { i64, ptr }, ptr %l272
  %t731 = load ptr, ptr %lp8
  store { i64, ptr } %t730, ptr %t731
  br label %bb142
bb142:
  call void @__olang_scope_close(ptr %s27)
  br label %bb143
bb143:
  %t732 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t732, ptr %l276
  %t733 = load { i64, ptr }, ptr %l276
  %t734 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s23, { i64, ptr } %t733, { i64, ptr } { i64 1, ptr @.d92 })
  store i1 %t734, ptr %l277
  br label %bb144
bb144:
  %t735 = load i1, ptr %l277
  br i1 %t735, label %bb145, label %bb146
bb145:
  %t736 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t736, ptr %l279
  %t737 = load { i64, ptr }, ptr %l279
  %t738 = call { i64, ptr } @std_2ffilepath_2eBase(ptr %v1, { i64, ptr } %t737)
  store { i64, ptr } %t738, ptr %l280
  br label %bb147
bb146:
  %t739 = load ptr, ptr %l3
  store ptr %t739, ptr %l282
  %t740 = load ptr, ptr %l282
  %t741 = getelementptr %"compiler/load:Module", ptr %t740, i32 0, i32 2
  %t742 = load { i64, ptr }, ptr %t741
  store { i64, ptr } %t742, ptr %l283
  %t743 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t743, ptr %l284
  %t744 = load { i64, ptr }, ptr %l283
  %t745 = load { i64, ptr }, ptr %l284
  %t746 = call { i64, ptr } @compiler_2fload_2erelativeIdentity(ptr %v0, ptr %v1, ptr %s23, { i64, ptr } %t744, { i64, ptr } %t745)
  store { i64, ptr } %t746, ptr %l285
  br label %bb148
bb147:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s30
  store ptr %s30room, ptr %s30
  %t747 = load { i64, ptr }, ptr %l280
  %t748 = extractvalue { i64, ptr } %t747, 1
  %t749 = extractvalue { i64, ptr } %t747, 0
  call void @__olang_sb_put(ptr %s30, ptr %t748, i64 %t749)
  %t750 = load ptr, ptr %s30
  %t751 = getelementptr %olang.builder, ptr %s30, i32 0, i32 1
  %t752 = load i64, ptr %t751
  %t753 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t752)
  call void @llvm.memcpy.p0.p0.i64(ptr %t753, ptr %t750, i64 %t752, i1 false)
  %t754 = insertvalue { i64, ptr } undef, i64 %t752, 0
  %t755 = insertvalue { i64, ptr } %t754, ptr %t753, 1
  store { i64, ptr } %t755, ptr %l281
  call void @__olang_sb_done(ptr %s30)
  %t756 = load { i64, ptr }, ptr %l281
  store { i64, ptr } %t756, ptr %l278
  br label %bb149
bb148:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s31
  store ptr %s31room, ptr %s31
  %t757 = load { i64, ptr }, ptr %l285
  %t758 = extractvalue { i64, ptr } %t757, 1
  %t759 = extractvalue { i64, ptr } %t757, 0
  call void @__olang_sb_put(ptr %s31, ptr %t758, i64 %t759)
  %t760 = load ptr, ptr %s31
  %t761 = getelementptr %olang.builder, ptr %s31, i32 0, i32 1
  %t762 = load i64, ptr %t761
  %t763 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t762)
  call void @llvm.memcpy.p0.p0.i64(ptr %t763, ptr %t760, i64 %t762, i1 false)
  %t764 = insertvalue { i64, ptr } undef, i64 %t762, 0
  %t765 = insertvalue { i64, ptr } %t764, ptr %t763, 1
  store { i64, ptr } %t765, ptr %l286
  call void @__olang_sb_done(ptr %s31)
  %t766 = load { i64, ptr }, ptr %l286
  store { i64, ptr } %t766, ptr %l278
  br label %bb149
bb149:
  %t767 = load ptr, ptr %lp9
  %t768 = load { i64, ptr }, ptr %t767
  %t769 = extractvalue { i64, ptr } %t768, 0
  store i64 %t769, ptr %l287
  %t770 = load { i64, ptr }, ptr %l278
  %t771 = extractvalue { i64, ptr } %t770, 0
  store i64 %t771, ptr %l288
  %t772 = load i64, ptr %l287
  %t773 = load i64, ptr %l288
  %t774 = icmp eq i64 %t772, %t773
  store i1 %t774, ptr %l289
  %t775 = load i1, ptr %l289
  br i1 %t775, label %bb150, label %bb151
bb150:
  %t776 = load ptr, ptr %lp9
  %t777 = getelementptr { i64, ptr }, ptr %t776, i32 0, i32 1
  %t778 = load ptr, ptr %t777
  %t779 = getelementptr { i64, ptr }, ptr %l278, i32 0, i32 1
  %t780 = load ptr, ptr %t779
  %t781 = load i64, ptr %l288
  %t782 = mul i64 %t781, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t778, ptr %t780, i64 %t782, i1 false)
  br label %bb152
bb151:
  %t783 = load { i64, ptr }, ptr %l278
  %t784 = load ptr, ptr %lp9
  store { i64, ptr } %t783, ptr %t784
  br label %bb152
bb152:
  store { i64, ptr } { i64 0, ptr @.d93 }, ptr %l290
  %t785 = load { i64, ptr }, ptr %l290
  store { i64, ptr } %t785, ptr %l291
  %t786 = load { i64, ptr }, ptr %l291
  %t787 = extractvalue { i64, ptr } %t786, 0
  store i64 %t787, ptr %l292
  %t788 = load i64, ptr %l292
  %t789 = mul i64 %t788, 1
  %t790 = call ptr @__olang_scope_alloc_zeroed(ptr %s23, i64 %t789)
  %t791 = insertvalue { i64, ptr } undef, i64 %t788, 0
  %t792 = insertvalue { i64, ptr } %t791, ptr %t790, 1
  store { i64, ptr } %t792, ptr %l293
  %t793 = getelementptr { i64, ptr }, ptr %l293, i32 0, i32 1
  %t794 = load ptr, ptr %t793
  %t795 = getelementptr { i64, ptr }, ptr %l291, i32 0, i32 1
  %t796 = load ptr, ptr %t795
  %t797 = load i64, ptr %l292
  %t798 = mul i64 %t797, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t794, ptr %t796, i64 %t798, i1 false)
  %t799 = load { i64, ptr }, ptr %l293
  store { i64, ptr } %t799, ptr %l21
  %t800 = load ptr, ptr %l3
  store ptr %t800, ptr %l294
  %t801 = load ptr, ptr %l294
  %t802 = getelementptr %"compiler/load:Module", ptr %t801, i32 0, i32 2
  %t803 = load { i64, ptr }, ptr %t802
  store { i64, ptr } %t803, ptr %l295
  %t804 = load ptr, ptr %l3
  store ptr %t804, ptr %l297
  %t805 = load ptr, ptr %l297
  %t806 = getelementptr %"compiler/load:Module", ptr %t805, i32 0, i32 2
  %t807 = load { i64, ptr }, ptr %t806
  store { i64, ptr } %t807, ptr %l298
  store i8 47, ptr %l299
  %t808 = load { i64, ptr }, ptr %l298
  %t809 = load i8, ptr %l299
  %t810 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %t808, i8 %t809)
  %t811 = extractvalue { i32, i64 } %t810, 1
  %t812 = extractvalue { i32, i64 } %t810, 0
  store i32 %t812, ptr %l301
  %t813 = icmp ne i32 %t812, 0
  br i1 %t813, label %bb154, label %ok.814
ok.814:
  store i64 %t811, ptr %l300
  br label %bb153
bb153:
  %t815 = load i64, ptr %l300
  store i64 %t815, ptr %l296
  br label %bb156
bb154:
  br label %bb155
bb155:
  %t816 = load ptr, ptr %l3
  store ptr %t816, ptr %l302
  %t817 = load ptr, ptr %l302
  %t818 = getelementptr %"compiler/load:Module", ptr %t817, i32 0, i32 2
  %t819 = load { i64, ptr }, ptr %t818
  store { i64, ptr } %t819, ptr %l303
  %t820 = load { i64, ptr }, ptr %l303
  %t821 = extractvalue { i64, ptr } %t820, 0
  store i64 %t821, ptr %l304
  %t822 = load i64, ptr %l304
  store i64 %t822, ptr %l296
  br label %bb156
bb156:
  %t823 = load { i64, ptr }, ptr %l295
  %t824 = extractvalue { i64, ptr } %t823, 0
  store i64 %t824, ptr %l305
  %t825 = icmp sge i64 0, 0
  store i1 %t825, ptr %l306
  %t826 = load i1, ptr %l306
  br i1 %t826, label %bb157, label %bb158
bb157:
  %t827 = load i64, ptr %l296
  %t828 = icmp sle i64 0, %t827
  store i1 %t828, ptr %l307
  %t829 = load i1, ptr %l307
  br i1 %t829, label %bb159, label %bb160
bb158:
  call void @__olang_check_failed(ptr @.c94)
  unreachable
bb159:
  %t830 = load i64, ptr %l296
  %t831 = load i64, ptr %l305
  %t832 = icmp sle i64 %t830, %t831
  store i1 %t832, ptr %l308
  %t833 = load i1, ptr %l308
  br i1 %t833, label %bb161, label %bb162
bb160:
  call void @__olang_check_failed(ptr @.c94)
  unreachable
bb161:
  %t834 = getelementptr { i64, ptr }, ptr %l295, i32 0, i32 1
  %t835 = load ptr, ptr %t834
  %t836 = load i64, ptr %l296
  %t837 = getelementptr i8, ptr %t835, i64 0
  %t838 = sub i64 %t836, 0
  %t839 = insertvalue { i64, ptr } undef, i64 %t838, 0
  %t840 = insertvalue { i64, ptr } %t839, ptr %t837, 1
  store { i64, ptr } %t840, ptr %l309
  %t841 = load { i64, ptr }, ptr %l309
  store { i64, ptr } %t841, ptr %l22
  %t842 = load { i64, ptr }, ptr %l22
  store { i64, ptr } %t842, ptr %l310
  %t843 = load { i64, ptr }, ptr %l310
  store { i64, ptr } %t843, ptr %l311
  store { i64, ptr } { i64 1, ptr @.d95 }, ptr %l312
  %t844 = load { i64, ptr }, ptr %l311
  %t845 = load { i64, ptr }, ptr %l312
  %t846 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s23, { i64, ptr } %t844, { i64, ptr } %t845)
  store i1 %t846, ptr %l313
  br label %bb163
bb162:
  call void @__olang_check_failed(ptr @.c94)
  unreachable
bb163:
  %t847 = load i1, ptr %l313
  br i1 %t847, label %bb164, label %bb165
bb164:
  %t848 = load { i64, ptr }, ptr %l22
  store { i64, ptr } %t848, ptr %l315
  %t849 = load { i64, ptr }, ptr %l315
  %t850 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s23, { i64, ptr } %t849, { i64, ptr } { i64 1, ptr @.d96 })
  store i1 %t850, ptr %l316
  br label %bb166
bb165:
  store i1 false, ptr %l314
  br label %bb167
bb166:
  %t851 = load i1, ptr %l316
  %t852 = xor i1 %t851, true
  store i1 %t852, ptr %l317
  %t853 = load i1, ptr %l317
  store i1 %t853, ptr %l314
  br label %bb167
bb167:
  %t854 = load i1, ptr %l314
  br i1 %t854, label %bb168, label %bb169
bb168:
  %t855 = load { i64, ptr }, ptr %l22
  store { i64, ptr } %t855, ptr %l319
  %t856 = load { i64, ptr }, ptr %l319
  %t857 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s23, { i64, ptr } %t856, { i64, ptr } { i64 2, ptr @.d97 })
  store i1 %t857, ptr %l320
  br label %bb170
bb169:
  store i1 false, ptr %l318
  br label %bb171
bb170:
  %t858 = load i1, ptr %l320
  %t859 = xor i1 %t858, true
  store i1 %t859, ptr %l321
  %t860 = load i1, ptr %l321
  store i1 %t860, ptr %l318
  br label %bb171
bb171:
  %t861 = load i1, ptr %l318
  store i1 %t861, ptr %l23
  %t862 = load ptr, ptr %l3
  store ptr %t862, ptr %l322
  %t863 = load ptr, ptr %l322
  %t864 = getelementptr %"compiler/load:Module", ptr %t863, i32 0, i32 2
  %t865 = load { i64, ptr }, ptr %t864
  store { i64, ptr } %t865, ptr %l323
  %t866 = load { i64, ptr }, ptr %l323
  %t867 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s23, { i64, ptr } %t866, { i64, ptr } { i64 4, ptr @.d98 })
  store i1 %t867, ptr %l324
  br label %bb172
bb172:
  %t868 = load i1, ptr %l324
  br i1 %t868, label %bb173, label %bb174
bb173:
  store %olang.scope zeroinitializer, ptr %s32
  store { i64, ptr } { i64 3, ptr @.d99 }, ptr %l325
  %t869 = load { i64, ptr }, ptr %l325
  store { i64, ptr } %t869, ptr %l326
  %t870 = load { i64, ptr }, ptr %l21
  %t871 = extractvalue { i64, ptr } %t870, 0
  store i64 %t871, ptr %l327
  %t872 = load { i64, ptr }, ptr %l326
  %t873 = extractvalue { i64, ptr } %t872, 0
  store i64 %t873, ptr %l328
  %t874 = load i64, ptr %l327
  %t875 = load i64, ptr %l328
  %t876 = icmp eq i64 %t874, %t875
  store i1 %t876, ptr %l329
  %t877 = load i1, ptr %l329
  br i1 %t877, label %bb175, label %bb176
bb174:
  store %olang.scope zeroinitializer, ptr %s33
  %t878 = load i1, ptr %l23
  store i1 %t878, ptr %l332
  %t879 = load i1, ptr %l332
  br i1 %t879, label %bb178, label %bb179
bb175:
  %t880 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t881 = load ptr, ptr %t880
  %t882 = getelementptr { i64, ptr }, ptr %l326, i32 0, i32 1
  %t883 = load ptr, ptr %t882
  %t884 = load i64, ptr %l328
  %t885 = mul i64 %t884, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t881, ptr %t883, i64 %t885, i1 false)
  br label %bb177
bb176:
  %t886 = load { i64, ptr }, ptr %l326
  %t887 = extractvalue { i64, ptr } %t886, 0
  store i64 %t887, ptr %l330
  %t888 = load i64, ptr %l330
  %t889 = mul i64 %t888, 1
  %t890 = call ptr @__olang_scope_alloc_zeroed(ptr %s23, i64 %t889)
  %t891 = insertvalue { i64, ptr } undef, i64 %t888, 0
  %t892 = insertvalue { i64, ptr } %t891, ptr %t890, 1
  store { i64, ptr } %t892, ptr %l331
  %t893 = getelementptr { i64, ptr }, ptr %l331, i32 0, i32 1
  %t894 = load ptr, ptr %t893
  %t895 = getelementptr { i64, ptr }, ptr %l326, i32 0, i32 1
  %t896 = load ptr, ptr %t895
  %t897 = load i64, ptr %l330
  %t898 = mul i64 %t897, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t894, ptr %t896, i64 %t898, i1 false)
  %t899 = load { i64, ptr }, ptr %l331
  store { i64, ptr } %t899, ptr %l21
  br label %bb177
bb177:
  call void @__olang_scope_close(ptr %s32)
  br label %bb189
bb178:
  %t900 = load ptr, ptr %l3
  store ptr %t900, ptr %l334
  %t901 = load ptr, ptr %l334
  %t902 = getelementptr %"compiler/load:Module", ptr %t901, i32 0, i32 2
  %t903 = load { i64, ptr }, ptr %t902
  store { i64, ptr } %t903, ptr %l335
  %t904 = load { i64, ptr }, ptr %l335
  store { i64, ptr } %t904, ptr %l336
  store { i64, ptr } { i64 1, ptr @.d100 }, ptr %l337
  %t905 = load { i64, ptr }, ptr %l336
  %t906 = load { i64, ptr }, ptr %l337
  %t907 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s33, { i64, ptr } %t905, { i64, ptr } %t906)
  store i1 %t907, ptr %l338
  br label %bb180
bb179:
  store i1 false, ptr %l333
  br label %bb181
bb180:
  %t908 = load i1, ptr %l338
  store i1 %t908, ptr %l333
  br label %bb181
bb181:
  %t909 = load i1, ptr %l333
  br i1 %t909, label %bb182, label %bb183
bb182:
  store %olang.scope zeroinitializer, ptr %s34
  %t910 = load ptr, ptr %l3
  store ptr %t910, ptr %l339
  %t911 = load ptr, ptr %l339
  %t912 = getelementptr %"compiler/load:Module", ptr %t911, i32 0, i32 2
  %t913 = load { i64, ptr }, ptr %t912
  store { i64, ptr } %t913, ptr %l340
  %t914 = load { i64, ptr }, ptr %l340
  %t915 = call { i64, ptr } @compiler_2fload_2efirstElems(ptr %v0, { i64, ptr } %t914, i64 3)
  store { i64, ptr } %t915, ptr %l341
  br label %bb184
bb183:
  br label %bb188
bb184:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s35
  store ptr %s35room, ptr %s35
  %t916 = load { i64, ptr }, ptr %l341
  %t917 = extractvalue { i64, ptr } %t916, 1
  %t918 = extractvalue { i64, ptr } %t916, 0
  call void @__olang_sb_put(ptr %s35, ptr %t917, i64 %t918)
  %t919 = load ptr, ptr %s35
  %t920 = getelementptr %olang.builder, ptr %s35, i32 0, i32 1
  %t921 = load i64, ptr %t920
  %t922 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t921)
  call void @llvm.memcpy.p0.p0.i64(ptr %t922, ptr %t919, i64 %t921, i1 false)
  %t923 = insertvalue { i64, ptr } undef, i64 %t921, 0
  %t924 = insertvalue { i64, ptr } %t923, ptr %t922, 1
  store { i64, ptr } %t924, ptr %l342
  call void @__olang_sb_done(ptr %s35)
  %t925 = load { i64, ptr }, ptr %l21
  %t926 = extractvalue { i64, ptr } %t925, 0
  store i64 %t926, ptr %l343
  %t927 = load { i64, ptr }, ptr %l342
  %t928 = extractvalue { i64, ptr } %t927, 0
  store i64 %t928, ptr %l344
  %t929 = load i64, ptr %l343
  %t930 = load i64, ptr %l344
  %t931 = icmp eq i64 %t929, %t930
  store i1 %t931, ptr %l345
  %t932 = load i1, ptr %l345
  br i1 %t932, label %bb185, label %bb186
bb185:
  %t933 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t934 = load ptr, ptr %t933
  %t935 = getelementptr { i64, ptr }, ptr %l342, i32 0, i32 1
  %t936 = load ptr, ptr %t935
  %t937 = load i64, ptr %l344
  %t938 = mul i64 %t937, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t934, ptr %t936, i64 %t938, i1 false)
  br label %bb187
bb186:
  %t939 = load { i64, ptr }, ptr %l342
  store { i64, ptr } %t939, ptr %l21
  br label %bb187
bb187:
  call void @__olang_scope_close(ptr %s34)
  br label %bb188
bb188:
  call void @__olang_scope_close(ptr %s33)
  br label %bb189
bb189:
  %t940 = load { i64, ptr }, ptr %l21
  store { i64, ptr } %t940, ptr %l346
  %t941 = load { i64, ptr }, ptr %l346
  %t942 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s23, ptr %s23, { i64, ptr } %t941, { i64, ptr } { i64 0, ptr @.d101 })
  store i1 %t942, ptr %l347
  br label %bb190
bb190:
  %t943 = load i1, ptr %l347
  %t944 = xor i1 %t943, true
  store i1 %t944, ptr %l348
  %t945 = load i1, ptr %l348
  br i1 %t945, label %bb191, label %bb192
bb191:
  %t946 = load ptr, ptr %lp9
  %t947 = load { i64, ptr }, ptr %t946
  store { i64, ptr } %t947, ptr %l350
  %t948 = load { i64, ptr }, ptr %l21
  store { i64, ptr } %t948, ptr %l351
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s36
  store ptr %s36room, ptr %s36
  %t949 = load { i64, ptr }, ptr %l351
  %t950 = extractvalue { i64, ptr } %t949, 1
  %t951 = extractvalue { i64, ptr } %t949, 0
  call void @__olang_sb_put(ptr %s36, ptr %t950, i64 %t951)
  %t952 = extractvalue { i64, ptr } { i64 1, ptr @.d102 }, 1
  %t953 = extractvalue { i64, ptr } { i64 1, ptr @.d102 }, 0
  call void @__olang_sb_put(ptr %s36, ptr %t952, i64 %t953)
  %t954 = load ptr, ptr %s36
  %t955 = getelementptr %olang.builder, ptr %s36, i32 0, i32 1
  %t956 = load i64, ptr %t955
  %t957 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t956)
  call void @llvm.memcpy.p0.p0.i64(ptr %t957, ptr %t954, i64 %t956, i1 false)
  %t958 = insertvalue { i64, ptr } undef, i64 %t956, 0
  %t959 = insertvalue { i64, ptr } %t958, ptr %t957, 1
  store { i64, ptr } %t959, ptr %l352
  call void @__olang_sb_done(ptr %s36)
  %t960 = load { i64, ptr }, ptr %l352
  %t961 = extractvalue { i64, ptr } %t960, 0
  %t962 = extractvalue { i64, ptr } %t960, 1
  %t963 = mul i64 %t961, 1
  %t964 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t963)
  call void @llvm.memcpy.p0.p0.i64(ptr %t964, ptr %t962, i64 %t963, i1 false)
  %t965 = insertvalue { i64, ptr } undef, i64 %t961, 0
  %t966 = insertvalue { i64, ptr } %t965, ptr %t964, 1
  store { i64, ptr } %t966, ptr %l353
  %t967 = load { i64, ptr }, ptr %l350
  %t968 = load { i64, ptr }, ptr %l353
  %t969 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v2, ptr %s23, { i64, ptr } %t967, { i64, ptr } %t968)
  store i1 %t969, ptr %l354
  br label %bb193
bb192:
  store i1 false, ptr %l349
  br label %bb194
bb193:
  %t970 = load i1, ptr %l354
  %t971 = xor i1 %t970, true
  store i1 %t971, ptr %l355
  %t972 = load i1, ptr %l355
  store i1 %t972, ptr %l349
  br label %bb194
bb194:
  %t973 = load i1, ptr %l349
  br i1 %t973, label %bb195, label %bb196
bb195:
  store %olang.scope zeroinitializer, ptr %s37
  %t974 = load ptr, ptr %l0
  store ptr %t974, ptr %l356
  %t975 = load ptr, ptr %l356
  %t976 = getelementptr %"compiler/load:Loader", ptr %t975, i32 0, i32 4
  %t977 = load ptr, ptr %t976
  store ptr %t977, ptr %l357
  %t978 = load { i64, [3 x i64] }, ptr %l4
  store { i64, [3 x i64] } %t978, ptr %l358
  %t979 = load { i64, ptr }, ptr %l21
  store { i64, ptr } %t979, ptr %l359
  %t980 = load { i64, ptr }, ptr %l359
  %t981 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportLeavesRoot(ptr %s23, ptr %s37, { i64, ptr } %t980)
  store %"compiler/msgs:Msg" %t981, ptr %l360
  br label %bb197
bb196:
  br label %bb199
bb197:
  %t982 = load ptr, ptr %l357
  %t983 = load { i64, [3 x i64] }, ptr %l358
  %t984 = load %"compiler/msgs:Msg", ptr %l360
  %t985 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s37, ptr %t982, { i64, [3 x i64] } %t983, %"compiler/msgs:Msg" %t984)
  store i64 %t985, ptr %l361
  br label %bb198
bb198:
  store i32 65536, ptr %l362
  call void @__olang_scope_close(ptr %s37)
  call void @__olang_scope_close(ptr %s23)
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t986 = load i32, ptr %l362
  %t987 = insertvalue { i32, { { i64, ptr }, { i64, ptr } } } zeroinitializer, i32 %t986, 0
  store { i32, { { i64, ptr }, { i64, ptr } } } %t987, ptr %rv
  br label %ret
bb199:
  call void @__olang_scope_close(ptr %s23)
  br label %bb200
bb200:
  call void @__olang_scope_close(ptr %s8)
  br label %bb201
bb201:
  %t988 = load ptr, ptr %lp8
  %t989 = load { i64, ptr }, ptr %t988
  store { i64, ptr } %t989, ptr %l363
  %t990 = load { i64, ptr }, ptr %l363
  %t991 = call i1 @std_2fos_2eExists(ptr %v2, { i64, ptr } %t990)
  store i1 %t991, ptr %l364
  br label %bb202
bb202:
  %t992 = load i1, ptr %l364
  %t993 = xor i1 %t992, true
  store i1 %t993, ptr %l365
  %t994 = load i1, ptr %l365
  br i1 %t994, label %bb203, label %bb204
bb203:
  store i1 true, ptr %l366
  br label %bb206
bb204:
  %t995 = load ptr, ptr %lp8
  %t996 = load { i64, ptr }, ptr %t995
  store { i64, ptr } %t996, ptr %l367
  %t997 = load { i64, ptr }, ptr %l367
  %t998 = call i1 @std_2fos_2eIsDir(ptr %v2, { i64, ptr } %t997)
  store i1 %t998, ptr %l368
  br label %bb205
bb205:
  %t999 = load i1, ptr %l368
  store i1 %t999, ptr %l366
  br label %bb206
bb206:
  %t1000 = load i1, ptr %l366
  br i1 %t1000, label %bb207, label %bb208
bb207:
  store %olang.scope zeroinitializer, ptr %s38
  %t1001 = load ptr, ptr %l0
  store ptr %t1001, ptr %l369
  %t1002 = load ptr, ptr %l369
  %t1003 = getelementptr %"compiler/load:Loader", ptr %t1002, i32 0, i32 4
  %t1004 = load ptr, ptr %t1003
  store ptr %t1004, ptr %l370
  %t1005 = load { i64, [3 x i64] }, ptr %l4
  store { i64, [3 x i64] } %t1005, ptr %l371
  %t1006 = load ptr, ptr %lp8
  %t1007 = load { i64, ptr }, ptr %t1006
  store { i64, ptr } %t1007, ptr %l372
  %t1008 = load { i64, ptr }, ptr %l372
  %t1009 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportFileNotFound(ptr %v2, ptr %s38, { i64, ptr } %t1008)
  store %"compiler/msgs:Msg" %t1009, ptr %l373
  br label %bb209
bb208:
  br label %bb211
bb209:
  %t1010 = load ptr, ptr %l370
  %t1011 = load { i64, [3 x i64] }, ptr %l371
  %t1012 = load %"compiler/msgs:Msg", ptr %l373
  %t1013 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s38, ptr %t1010, { i64, [3 x i64] } %t1011, %"compiler/msgs:Msg" %t1012)
  store i64 %t1013, ptr %l374
  br label %bb210
bb210:
  store i32 65536, ptr %l375
  call void @__olang_scope_close(ptr %s38)
  call void @__olang_scope_close(ptr %s0)
  %t1014 = load i32, ptr %l375
  %t1015 = insertvalue { i32, { { i64, ptr }, { i64, ptr } } } zeroinitializer, i32 %t1014, 0
  store { i32, { { i64, ptr }, { i64, ptr } } } %t1015, ptr %rv
  br label %ret
bb211:
  %t1016 = load ptr, ptr %lp8
  %t1017 = load { i64, ptr }, ptr %t1016
  store { i64, ptr } %t1017, ptr %l376
  %t1018 = load ptr, ptr %lp9
  %t1019 = load { i64, ptr }, ptr %t1018
  store { i64, ptr } %t1019, ptr %l377
  %t1020 = load { i64, ptr }, ptr %l376
  %t1021 = insertvalue { { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t1020, 0
  %t1022 = load { i64, ptr }, ptr %l377
  %t1023 = insertvalue { { i64, ptr }, { i64, ptr } } %t1021, { i64, ptr } %t1022, 1
  store { { i64, ptr }, { i64, ptr } } %t1023, ptr %l378
  call void @__olang_scope_close(ptr %s0)
  %t1024 = load { { i64, ptr }, { i64, ptr } }, ptr %l378
  %t1025 = insertvalue { i32, { { i64, ptr }, { i64, ptr } } } zeroinitializer, { { i64, ptr }, { i64, ptr } } %t1024, 1
  store { i32, { { i64, ptr }, { i64, ptr } } } %t1025, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { { i64, ptr }, { i64, ptr } } }, ptr %rv
  ret { i32, { { i64, ptr }, { i64, ptr } } } %rr
}

define dso_local { i64, ptr } @compiler_2fload_2ecompiler_2fload_3aLoader_2erootIdentity(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i1
  %l16 = alloca i1
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l31 = alloca ptr
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i1
  %l44 = alloca i1
  %l45 = alloca i1
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i1
  %l51 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i1
  %l56 = alloca i64
  %l57 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l59 = alloca ptr
  %l60 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l63 = alloca i1
  %l64 = alloca ptr
  %l65 = alloca { i64, ptr }
  %l66 = alloca i64
  %l67 = alloca i64
  %l68 = alloca { i64, ptr }
  %l69 = alloca i64
  %l70 = alloca i64
  %l71 = alloca i1
  %l72 = alloca i1
  %l73 = alloca i1
  %l74 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %l76 = alloca i64
  %l77 = alloca i64
  %l78 = alloca i1
  %l79 = alloca { i64, ptr }
  %l80 = alloca i1
  %l81 = alloca i1
  %l82 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l90 = alloca i1
  %l91 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l93 = alloca i64
  %l94 = alloca i64
  %l95 = alloca i64
  %l96 = alloca i1
  %l97 = alloca i1
  %l98 = alloca i1
  %l99 = alloca { i64, ptr }
  %l100 = alloca { i64, ptr }
  %l101 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %s2 = alloca %olang.builder
  %s2room = alloca [64 x i8], align 8
  %s3 = alloca %olang.builder
  %s3room = alloca [64 x i8], align 8
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.builder
  %s5room = alloca [64 x i8], align 8
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.builder
  %s7room = alloca [64 x i8], align 8
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.builder
  %s9room = alloca [64 x i8], align 8
  %s10 = alloca %olang.builder
  %s10room = alloca [64 x i8], align 8
  %s11 = alloca %olang.builder
  %s11room = alloca [64 x i8], align 8
  %s12 = alloca %olang.builder
  %s12room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t1, ptr %l8
  %t2 = load { i64, ptr }, ptr %l8
  %t3 = call { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v1, ptr %s0, { i64, ptr } %t2)
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l10
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store { i64, ptr } %t4, ptr %l9
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l9
  store { i64, ptr } %t8, ptr %l7
  br label %bb4
bb2:
  br label %bb3
bb3:
  store { i64, ptr } { i64 0, ptr @.d103 }, ptr %l11
  %t9 = load { i64, ptr }, ptr %l11
  store { i64, ptr } %t9, ptr %l12
  %t10 = load { i64, ptr }, ptr %l12
  %t11 = extractvalue { i64, ptr } %t10, 0
  %t12 = extractvalue { i64, ptr } %t10, 1
  %t13 = mul i64 %t11, 1
  %t14 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t13)
  call void @llvm.memcpy.p0.p0.i64(ptr %t14, ptr %t12, i64 %t13, i1 false)
  %t15 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l13
  %t17 = load { i64, ptr }, ptr %l13
  store { i64, ptr } %t17, ptr %l7
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l7
  store { i64, ptr } %t18, ptr %l2
  %t19 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t19, ptr %l14
  %t20 = load { i64, ptr }, ptr %l14
  %t21 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t20, { i64, ptr } { i64 0, ptr @.d104 })
  store i1 %t21, ptr %l15
  br label %bb5
bb5:
  %t22 = load i1, ptr %l15
  %t23 = xor i1 %t22, true
  store i1 %t23, ptr %l16
  %t24 = load i1, ptr %l16
  br i1 %t24, label %bb6, label %bb7
bb6:
  %t25 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t25, ptr %l18
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t26 = load { i64, ptr }, ptr %l18
  %t27 = extractvalue { i64, ptr } %t26, 1
  %t28 = extractvalue { i64, ptr } %t26, 0
  call void @__olang_sb_put(ptr %s1, ptr %t27, i64 %t28)
  %t29 = load ptr, ptr %s1
  %t30 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t31 = load i64, ptr %t30
  %t32 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t31)
  call void @llvm.memcpy.p0.p0.i64(ptr %t32, ptr %t29, i64 %t31, i1 false)
  %t33 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  store { i64, ptr } %t34, ptr %l19
  call void @__olang_sb_done(ptr %s1)
  %t35 = load { i64, ptr }, ptr %l19
  store { i64, ptr } %t35, ptr %l17
  br label %bb8
bb7:
  %t36 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t36, ptr %l20
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s2
  store ptr %s2room, ptr %s2
  %t37 = load { i64, ptr }, ptr %l20
  %t38 = extractvalue { i64, ptr } %t37, 1
  %t39 = extractvalue { i64, ptr } %t37, 0
  call void @__olang_sb_put(ptr %s2, ptr %t38, i64 %t39)
  %t40 = load ptr, ptr %s2
  %t41 = getelementptr %olang.builder, ptr %s2, i32 0, i32 1
  %t42 = load i64, ptr %t41
  %t43 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t42)
  call void @llvm.memcpy.p0.p0.i64(ptr %t43, ptr %t40, i64 %t42, i1 false)
  %t44 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  store { i64, ptr } %t45, ptr %l21
  call void @__olang_sb_done(ptr %s2)
  %t46 = load { i64, ptr }, ptr %l21
  store { i64, ptr } %t46, ptr %l17
  br label %bb8
bb8:
  %t47 = load { i64, ptr }, ptr %l17
  store { i64, ptr } %t47, ptr %l3
  store { i64, ptr } { i64 0, ptr @.d105 }, ptr %l22
  %t48 = load { i64, ptr }, ptr %l22
  store { i64, ptr } %t48, ptr %l23
  %t49 = load { i64, ptr }, ptr %l23
  %t50 = extractvalue { i64, ptr } %t49, 0
  store i64 %t50, ptr %l24
  %t51 = load i64, ptr %l24
  %t52 = mul i64 %t51, 1
  %t53 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t52)
  %t54 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t53, 1
  store { i64, ptr } %t55, ptr %l25
  %t56 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t57 = load ptr, ptr %t56
  %t58 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t59 = load ptr, ptr %t58
  %t60 = load i64, ptr %l24
  %t61 = mul i64 %t60, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t57, ptr %t59, i64 %t61, i1 false)
  %t62 = load { i64, ptr }, ptr %l25
  store { i64, ptr } %t62, ptr %l4
  store { i64, ptr } { i64 0, ptr @.d106 }, ptr %l26
  %t63 = load { i64, ptr }, ptr %l26
  store { i64, ptr } %t63, ptr %l27
  %t64 = load { i64, ptr }, ptr %l27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l28
  %t66 = load i64, ptr %l28
  %t67 = mul i64 %t66, 1
  %t68 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t67)
  %t69 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t70 = insertvalue { i64, ptr } %t69, ptr %t68, 1
  store { i64, ptr } %t70, ptr %l29
  %t71 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t72 = load ptr, ptr %t71
  %t73 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t74 = load ptr, ptr %t73
  %t75 = load i64, ptr %l28
  %t76 = mul i64 %t75, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t72, ptr %t74, i64 %t76, i1 false)
  %t77 = load { i64, ptr }, ptr %l29
  store { i64, ptr } %t77, ptr %l5
  %t78 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t78, ptr %l30
  %t79 = load ptr, ptr %l0
  store ptr %t79, ptr %l31
  %t80 = load ptr, ptr %l31
  %t81 = getelementptr %"compiler/load:Loader", ptr %t80, i32 0, i32 8
  %t82 = load { i64, ptr }, ptr %t81
  store { i64, ptr } %t82, ptr %l32
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s3
  store ptr %s3room, ptr %s3
  %t83 = load { i64, ptr }, ptr %l32
  %t84 = extractvalue { i64, ptr } %t83, 1
  %t85 = extractvalue { i64, ptr } %t83, 0
  call void @__olang_sb_put(ptr %s3, ptr %t84, i64 %t85)
  %t86 = extractvalue { i64, ptr } { i64 1, ptr @.d107 }, 1
  %t87 = extractvalue { i64, ptr } { i64 1, ptr @.d107 }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t86, i64 %t87)
  %t88 = load ptr, ptr %s3
  %t89 = getelementptr %olang.builder, ptr %s3, i32 0, i32 1
  %t90 = load i64, ptr %t89
  %t91 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t90)
  call void @llvm.memcpy.p0.p0.i64(ptr %t91, ptr %t88, i64 %t90, i1 false)
  %t92 = insertvalue { i64, ptr } undef, i64 %t90, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t91, 1
  store { i64, ptr } %t93, ptr %l33
  call void @__olang_sb_done(ptr %s3)
  %t94 = load { i64, ptr }, ptr %l33
  %t95 = extractvalue { i64, ptr } %t94, 0
  %t96 = extractvalue { i64, ptr } %t94, 1
  %t97 = mul i64 %t95, 1
  %t98 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t97)
  call void @llvm.memcpy.p0.p0.i64(ptr %t98, ptr %t96, i64 %t97, i1 false)
  %t99 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t98, 1
  store { i64, ptr } %t100, ptr %l34
  %t101 = load { i64, ptr }, ptr %l30
  %t102 = load { i64, ptr }, ptr %l34
  %t103 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s0, { i64, ptr } %t101, { i64, ptr } %t102)
  store i1 %t103, ptr %l35
  br label %bb9
bb9:
  %t104 = load i1, ptr %l35
  br i1 %t104, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s4
  %t105 = load ptr, ptr %l0
  store ptr %t105, ptr %l36
  %t106 = load ptr, ptr %l36
  %t107 = getelementptr %"compiler/load:Loader", ptr %t106, i32 0, i32 8
  %t108 = load { i64, ptr }, ptr %t107
  store { i64, ptr } %t108, ptr %l37
  %t109 = load { i64, ptr }, ptr %l37
  %t110 = extractvalue { i64, ptr } %t109, 0
  store i64 %t110, ptr %l38
  %t111 = load i64, ptr %l38
  %t112 = add i64 %t111, 1
  store i64 %t112, ptr %l39
  %t113 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t113, ptr %l40
  %t114 = load { i64, ptr }, ptr %l40
  %t115 = extractvalue { i64, ptr } %t114, 0
  store i64 %t115, ptr %l41
  %t116 = load { i64, ptr }, ptr %l3
  %t117 = extractvalue { i64, ptr } %t116, 0
  store i64 %t117, ptr %l42
  %t118 = load i64, ptr %l39
  %t119 = icmp sge i64 %t118, 0
  store i1 %t119, ptr %l43
  %t120 = load i1, ptr %l43
  br i1 %t120, label %bb12, label %bb13
bb11:
  store %olang.scope zeroinitializer, ptr %s6
  %t121 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t121, ptr %l58
  %t122 = load ptr, ptr %l0
  store ptr %t122, ptr %l59
  %t123 = load ptr, ptr %l59
  %t124 = getelementptr %"compiler/load:Loader", ptr %t123, i32 0, i32 9
  %t125 = load { i64, ptr }, ptr %t124
  store { i64, ptr } %t125, ptr %l60
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s7
  store ptr %s7room, ptr %s7
  %t126 = load { i64, ptr }, ptr %l60
  %t127 = extractvalue { i64, ptr } %t126, 1
  %t128 = extractvalue { i64, ptr } %t126, 0
  call void @__olang_sb_put(ptr %s7, ptr %t127, i64 %t128)
  %t129 = extractvalue { i64, ptr } { i64 1, ptr @.d108 }, 1
  %t130 = extractvalue { i64, ptr } { i64 1, ptr @.d108 }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t129, i64 %t130)
  %t131 = load ptr, ptr %s7
  %t132 = getelementptr %olang.builder, ptr %s7, i32 0, i32 1
  %t133 = load i64, ptr %t132
  %t134 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t133)
  call void @llvm.memcpy.p0.p0.i64(ptr %t134, ptr %t131, i64 %t133, i1 false)
  %t135 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t136 = insertvalue { i64, ptr } %t135, ptr %t134, 1
  store { i64, ptr } %t136, ptr %l61
  call void @__olang_sb_done(ptr %s7)
  %t137 = load { i64, ptr }, ptr %l61
  %t138 = extractvalue { i64, ptr } %t137, 0
  %t139 = extractvalue { i64, ptr } %t137, 1
  %t140 = mul i64 %t138, 1
  %t141 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t140)
  call void @llvm.memcpy.p0.p0.i64(ptr %t141, ptr %t139, i64 %t140, i1 false)
  %t142 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t143 = insertvalue { i64, ptr } %t142, ptr %t141, 1
  store { i64, ptr } %t143, ptr %l62
  %t144 = load { i64, ptr }, ptr %l58
  %t145 = load { i64, ptr }, ptr %l62
  %t146 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s6, { i64, ptr } %t144, { i64, ptr } %t145)
  store i1 %t146, ptr %l63
  br label %bb24
bb12:
  %t147 = load i64, ptr %l39
  %t148 = load i64, ptr %l41
  %t149 = icmp sle i64 %t147, %t148
  store i1 %t149, ptr %l44
  %t150 = load i1, ptr %l44
  br i1 %t150, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @.c109)
  unreachable
bb14:
  %t151 = load i64, ptr %l41
  %t152 = load i64, ptr %l42
  %t153 = icmp sle i64 %t151, %t152
  store i1 %t153, ptr %l45
  %t154 = load i1, ptr %l45
  br i1 %t154, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @.c109)
  unreachable
bb16:
  %t155 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t156 = load ptr, ptr %t155
  %t157 = load i64, ptr %l39
  %t158 = load i64, ptr %l41
  %t159 = getelementptr i8, ptr %t156, i64 %t157
  %t160 = sub i64 %t158, %t157
  %t161 = insertvalue { i64, ptr } undef, i64 %t160, 0
  %t162 = insertvalue { i64, ptr } %t161, ptr %t159, 1
  store { i64, ptr } %t162, ptr %l46
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s5
  store ptr %s5room, ptr %s5
  %t163 = load { i64, ptr }, ptr %l46
  %t164 = extractvalue { i64, ptr } %t163, 1
  %t165 = extractvalue { i64, ptr } %t163, 0
  call void @__olang_sb_put(ptr %s5, ptr %t164, i64 %t165)
  %t166 = load ptr, ptr %s5
  %t167 = getelementptr %olang.builder, ptr %s5, i32 0, i32 1
  %t168 = load i64, ptr %t167
  %t169 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t168)
  call void @llvm.memcpy.p0.p0.i64(ptr %t169, ptr %t166, i64 %t168, i1 false)
  %t170 = insertvalue { i64, ptr } undef, i64 %t168, 0
  %t171 = insertvalue { i64, ptr } %t170, ptr %t169, 1
  store { i64, ptr } %t171, ptr %l47
  call void @__olang_sb_done(ptr %s5)
  %t172 = load { i64, ptr }, ptr %l4
  %t173 = extractvalue { i64, ptr } %t172, 0
  store i64 %t173, ptr %l48
  %t174 = load { i64, ptr }, ptr %l47
  %t175 = extractvalue { i64, ptr } %t174, 0
  store i64 %t175, ptr %l49
  %t176 = load i64, ptr %l48
  %t177 = load i64, ptr %l49
  %t178 = icmp eq i64 %t176, %t177
  store i1 %t178, ptr %l50
  %t179 = load i1, ptr %l50
  br i1 %t179, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @.c109)
  unreachable
bb18:
  %t180 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t181 = load ptr, ptr %t180
  %t182 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t183 = load ptr, ptr %t182
  %t184 = load i64, ptr %l49
  %t185 = mul i64 %t184, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t181, ptr %t183, i64 %t185, i1 false)
  br label %bb20
bb19:
  %t186 = load { i64, ptr }, ptr %l47
  store { i64, ptr } %t186, ptr %l4
  br label %bb20
bb20:
  store { i64, ptr } { i64 4, ptr @.d110 }, ptr %l51
  %t187 = load { i64, ptr }, ptr %l51
  store { i64, ptr } %t187, ptr %l52
  %t188 = load { i64, ptr }, ptr %l5
  %t189 = extractvalue { i64, ptr } %t188, 0
  store i64 %t189, ptr %l53
  %t190 = load { i64, ptr }, ptr %l52
  %t191 = extractvalue { i64, ptr } %t190, 0
  store i64 %t191, ptr %l54
  %t192 = load i64, ptr %l53
  %t193 = load i64, ptr %l54
  %t194 = icmp eq i64 %t192, %t193
  store i1 %t194, ptr %l55
  %t195 = load i1, ptr %l55
  br i1 %t195, label %bb21, label %bb22
bb21:
  %t196 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t197 = load ptr, ptr %t196
  %t198 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t199 = load ptr, ptr %t198
  %t200 = load i64, ptr %l54
  %t201 = mul i64 %t200, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t197, ptr %t199, i64 %t201, i1 false)
  br label %bb23
bb22:
  %t202 = load { i64, ptr }, ptr %l52
  %t203 = extractvalue { i64, ptr } %t202, 0
  store i64 %t203, ptr %l56
  %t204 = load i64, ptr %l56
  %t205 = mul i64 %t204, 1
  %t206 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t205)
  %t207 = insertvalue { i64, ptr } undef, i64 %t204, 0
  %t208 = insertvalue { i64, ptr } %t207, ptr %t206, 1
  store { i64, ptr } %t208, ptr %l57
  %t209 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t210 = load ptr, ptr %t209
  %t211 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t212 = load ptr, ptr %t211
  %t213 = load i64, ptr %l56
  %t214 = mul i64 %t213, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t210, ptr %t212, i64 %t214, i1 false)
  %t215 = load { i64, ptr }, ptr %l57
  store { i64, ptr } %t215, ptr %l5
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s4)
  br label %bb37
bb24:
  %t216 = load i1, ptr %l63
  br i1 %t216, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s8
  %t217 = load ptr, ptr %l0
  store ptr %t217, ptr %l64
  %t218 = load ptr, ptr %l64
  %t219 = getelementptr %"compiler/load:Loader", ptr %t218, i32 0, i32 9
  %t220 = load { i64, ptr }, ptr %t219
  store { i64, ptr } %t220, ptr %l65
  %t221 = load { i64, ptr }, ptr %l65
  %t222 = extractvalue { i64, ptr } %t221, 0
  store i64 %t222, ptr %l66
  %t223 = load i64, ptr %l66
  %t224 = add i64 %t223, 1
  store i64 %t224, ptr %l67
  %t225 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t225, ptr %l68
  %t226 = load { i64, ptr }, ptr %l68
  %t227 = extractvalue { i64, ptr } %t226, 0
  store i64 %t227, ptr %l69
  %t228 = load { i64, ptr }, ptr %l3
  %t229 = extractvalue { i64, ptr } %t228, 0
  store i64 %t229, ptr %l70
  %t230 = load i64, ptr %l67
  %t231 = icmp sge i64 %t230, 0
  store i1 %t231, ptr %l71
  %t232 = load i1, ptr %l71
  br i1 %t232, label %bb27, label %bb28
bb26:
  br label %bb36
bb27:
  %t233 = load i64, ptr %l67
  %t234 = load i64, ptr %l69
  %t235 = icmp sle i64 %t233, %t234
  store i1 %t235, ptr %l72
  %t236 = load i1, ptr %l72
  br i1 %t236, label %bb29, label %bb30
bb28:
  call void @__olang_check_failed(ptr @.c111)
  unreachable
bb29:
  %t237 = load i64, ptr %l69
  %t238 = load i64, ptr %l70
  %t239 = icmp sle i64 %t237, %t238
  store i1 %t239, ptr %l73
  %t240 = load i1, ptr %l73
  br i1 %t240, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @.c111)
  unreachable
bb31:
  %t241 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t242 = load ptr, ptr %t241
  %t243 = load i64, ptr %l67
  %t244 = load i64, ptr %l69
  %t245 = getelementptr i8, ptr %t242, i64 %t243
  %t246 = sub i64 %t244, %t243
  %t247 = insertvalue { i64, ptr } undef, i64 %t246, 0
  %t248 = insertvalue { i64, ptr } %t247, ptr %t245, 1
  store { i64, ptr } %t248, ptr %l74
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s9
  store ptr %s9room, ptr %s9
  %t249 = load { i64, ptr }, ptr %l74
  %t250 = extractvalue { i64, ptr } %t249, 1
  %t251 = extractvalue { i64, ptr } %t249, 0
  call void @__olang_sb_put(ptr %s9, ptr %t250, i64 %t251)
  %t252 = load ptr, ptr %s9
  %t253 = getelementptr %olang.builder, ptr %s9, i32 0, i32 1
  %t254 = load i64, ptr %t253
  %t255 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t254)
  call void @llvm.memcpy.p0.p0.i64(ptr %t255, ptr %t252, i64 %t254, i1 false)
  %t256 = insertvalue { i64, ptr } undef, i64 %t254, 0
  %t257 = insertvalue { i64, ptr } %t256, ptr %t255, 1
  store { i64, ptr } %t257, ptr %l75
  call void @__olang_sb_done(ptr %s9)
  %t258 = load { i64, ptr }, ptr %l4
  %t259 = extractvalue { i64, ptr } %t258, 0
  store i64 %t259, ptr %l76
  %t260 = load { i64, ptr }, ptr %l75
  %t261 = extractvalue { i64, ptr } %t260, 0
  store i64 %t261, ptr %l77
  %t262 = load i64, ptr %l76
  %t263 = load i64, ptr %l77
  %t264 = icmp eq i64 %t262, %t263
  store i1 %t264, ptr %l78
  %t265 = load i1, ptr %l78
  br i1 %t265, label %bb33, label %bb34
bb32:
  call void @__olang_check_failed(ptr @.c111)
  unreachable
bb33:
  %t266 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t267 = load ptr, ptr %t266
  %t268 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t269 = load ptr, ptr %t268
  %t270 = load i64, ptr %l77
  %t271 = mul i64 %t270, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t267, ptr %t269, i64 %t271, i1 false)
  br label %bb35
bb34:
  %t272 = load { i64, ptr }, ptr %l75
  store { i64, ptr } %t272, ptr %l4
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s8)
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s6)
  br label %bb37
bb37:
  %t273 = load { i64, ptr }, ptr %l4
  store { i64, ptr } %t273, ptr %l79
  %t274 = load { i64, ptr }, ptr %l79
  %t275 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t274, { i64, ptr } { i64 0, ptr @.d112 })
  store i1 %t275, ptr %l80
  br label %bb38
bb38:
  %t276 = load i1, ptr %l80
  %t277 = xor i1 %t276, true
  store i1 %t277, ptr %l81
  %t278 = load i1, ptr %l81
  br i1 %t278, label %bb39, label %bb40
bb39:
  %t279 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t279, ptr %l83
  %t280 = load { i64, ptr }, ptr %l4
  store { i64, ptr } %t280, ptr %l84
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s10
  store ptr %s10room, ptr %s10
  %t281 = load { i64, ptr }, ptr %l83
  %t282 = extractvalue { i64, ptr } %t281, 1
  %t283 = extractvalue { i64, ptr } %t281, 0
  call void @__olang_sb_put(ptr %s10, ptr %t282, i64 %t283)
  %t284 = load { i64, ptr }, ptr %l84
  %t285 = extractvalue { i64, ptr } %t284, 1
  %t286 = extractvalue { i64, ptr } %t284, 0
  call void @__olang_sb_put(ptr %s10, ptr %t285, i64 %t286)
  %t287 = load ptr, ptr %s10
  %t288 = getelementptr %olang.builder, ptr %s10, i32 0, i32 1
  %t289 = load i64, ptr %t288
  %t290 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t289)
  call void @llvm.memcpy.p0.p0.i64(ptr %t290, ptr %t287, i64 %t289, i1 false)
  %t291 = insertvalue { i64, ptr } undef, i64 %t289, 0
  %t292 = insertvalue { i64, ptr } %t291, ptr %t290, 1
  store { i64, ptr } %t292, ptr %l85
  call void @__olang_sb_done(ptr %s10)
  %t293 = load { i64, ptr }, ptr %l85
  store { i64, ptr } %t293, ptr %l82
  br label %bb42
bb40:
  %t294 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t294, ptr %l86
  %t295 = load { i64, ptr }, ptr %l86
  %t296 = call { i64, ptr } @std_2ffilepath_2eBase(ptr %s0, { i64, ptr } %t295)
  store { i64, ptr } %t296, ptr %l87
  br label %bb41
bb41:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s11
  store ptr %s11room, ptr %s11
  %t297 = load { i64, ptr }, ptr %l87
  %t298 = extractvalue { i64, ptr } %t297, 1
  %t299 = extractvalue { i64, ptr } %t297, 0
  call void @__olang_sb_put(ptr %s11, ptr %t298, i64 %t299)
  %t300 = load ptr, ptr %s11
  %t301 = getelementptr %olang.builder, ptr %s11, i32 0, i32 1
  %t302 = load i64, ptr %t301
  %t303 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t302)
  call void @llvm.memcpy.p0.p0.i64(ptr %t303, ptr %t300, i64 %t302, i1 false)
  %t304 = insertvalue { i64, ptr } undef, i64 %t302, 0
  %t305 = insertvalue { i64, ptr } %t304, ptr %t303, 1
  store { i64, ptr } %t305, ptr %l88
  call void @__olang_sb_done(ptr %s11)
  %t306 = load { i64, ptr }, ptr %l88
  store { i64, ptr } %t306, ptr %l82
  br label %bb42
bb42:
  %t307 = load { i64, ptr }, ptr %l82
  store { i64, ptr } %t307, ptr %l6
  %t308 = load { i64, ptr }, ptr %l6
  store { i64, ptr } %t308, ptr %l89
  %t309 = load { i64, ptr }, ptr %l89
  %t310 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s0, ptr %s0, { i64, ptr } %t309, { i64, ptr } { i64 6, ptr @.d113 })
  store i1 %t310, ptr %l90
  br label %bb43
bb43:
  %t311 = load i1, ptr %l90
  br i1 %t311, label %bb44, label %bb45
bb44:
  %t312 = load { i64, ptr }, ptr %l6
  store { i64, ptr } %t312, ptr %l92
  %t313 = load { i64, ptr }, ptr %l92
  %t314 = extractvalue { i64, ptr } %t313, 0
  store i64 %t314, ptr %l93
  %t315 = load i64, ptr %l93
  %t316 = sub i64 %t315, 6
  store i64 %t316, ptr %l94
  %t317 = load { i64, ptr }, ptr %l6
  %t318 = extractvalue { i64, ptr } %t317, 0
  store i64 %t318, ptr %l95
  %t319 = icmp sge i64 0, 0
  store i1 %t319, ptr %l96
  %t320 = load i1, ptr %l96
  br i1 %t320, label %bb46, label %bb47
bb45:
  %t321 = load { i64, ptr }, ptr %l6
  store { i64, ptr } %t321, ptr %l101
  %t322 = load { i64, ptr }, ptr %l101
  store { i64, ptr } %t322, ptr %l91
  br label %bb52
bb46:
  %t323 = load i64, ptr %l94
  %t324 = icmp sle i64 0, %t323
  store i1 %t324, ptr %l97
  %t325 = load i1, ptr %l97
  br i1 %t325, label %bb48, label %bb49
bb47:
  call void @__olang_check_failed(ptr @.c114)
  unreachable
bb48:
  %t326 = load i64, ptr %l94
  %t327 = load i64, ptr %l95
  %t328 = icmp sle i64 %t326, %t327
  store i1 %t328, ptr %l98
  %t329 = load i1, ptr %l98
  br i1 %t329, label %bb50, label %bb51
bb49:
  call void @__olang_check_failed(ptr @.c114)
  unreachable
bb50:
  %t330 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t331 = load ptr, ptr %t330
  %t332 = load i64, ptr %l94
  %t333 = getelementptr i8, ptr %t331, i64 0
  %t334 = sub i64 %t332, 0
  %t335 = insertvalue { i64, ptr } undef, i64 %t334, 0
  %t336 = insertvalue { i64, ptr } %t335, ptr %t333, 1
  store { i64, ptr } %t336, ptr %l99
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s12
  store ptr %s12room, ptr %s12
  %t337 = load { i64, ptr }, ptr %l99
  %t338 = extractvalue { i64, ptr } %t337, 1
  %t339 = extractvalue { i64, ptr } %t337, 0
  call void @__olang_sb_put(ptr %s12, ptr %t338, i64 %t339)
  %t340 = load ptr, ptr %s12
  %t341 = getelementptr %olang.builder, ptr %s12, i32 0, i32 1
  %t342 = load i64, ptr %t341
  %t343 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t342)
  call void @llvm.memcpy.p0.p0.i64(ptr %t343, ptr %t340, i64 %t342, i1 false)
  %t344 = insertvalue { i64, ptr } undef, i64 %t342, 0
  %t345 = insertvalue { i64, ptr } %t344, ptr %t343, 1
  store { i64, ptr } %t345, ptr %l100
  call void @__olang_sb_done(ptr %s12)
  %t346 = load { i64, ptr }, ptr %l100
  store { i64, ptr } %t346, ptr %l91
  br label %bb52
bb51:
  call void @__olang_check_failed(ptr @.c114)
  unreachable
bb52:
  call void @__olang_scope_close(ptr %s0)
  %t347 = load { i64, ptr }, ptr %l91
  store { i64, ptr } %t347, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2etaken(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i1
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i1
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i1
  %l34 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l2
  store i64 %t1, ptr %l6
  %t2 = load i64, ptr %l6
  %t3 = icmp slt i64 %t2, 0
  store i1 %t3, ptr %l7
  %t4 = load i1, ptr %l7
  br i1 %t4, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  store i64 1, ptr %l8
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t5 = load i64, ptr %l8
  store i64 %t5, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0
  store ptr %t6, ptr %l9
  %t7 = load ptr, ptr %l9
  %t8 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 5
  store ptr %t8, ptr %l10
  %t9 = load i64, ptr %l1
  store i64 %t9, ptr %l11
  %t10 = load ptr, ptr %l10
  %t11 = load i64, ptr %l11
  %t12 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t10, i64 %t11)
  store ptr %t12, ptr %l12
  br label %bb4
bb4:
  %t13 = load ptr, ptr %l12
  store ptr %t13, ptr %l3
  %t14 = load ptr, ptr %l3
  store ptr %t14, ptr %l13
  %t15 = load ptr, ptr %l13
  %t16 = getelementptr %"compiler/load:Module", ptr %t15, i32 0, i32 18
  store ptr %t16, ptr %l14
  %t17 = load i64, ptr %l2
  store i64 %t17, ptr %l15
  %t18 = load ptr, ptr %l14
  %t19 = load i64, ptr %l15
  %t20 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t18, i64 %t19)
  store i64 %t20, ptr %l16
  br label %bb5
bb5:
  %t21 = load i64, ptr %l16
  store i64 %t21, ptr %l4
  %t22 = load ptr, ptr %l0
  store ptr %t22, ptr %l17
  %t23 = load i64, ptr %l1
  store i64 %t23, ptr %l18
  %t24 = load i64, ptr %l4
  store i64 %t24, ptr %l19
  %t25 = load ptr, ptr %l17
  %t26 = load i64, ptr %l18
  %t27 = load i64, ptr %l19
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2edecide(ptr %v0, ptr %t25, i64 %t26, i64 %t27)
  br label %bb6
bb6:
  %t28 = load ptr, ptr %l3
  store ptr %t28, ptr %l20
  %t29 = load ptr, ptr %l20
  %t30 = getelementptr %"compiler/load:Module", ptr %t29, i32 0, i32 14
  store ptr %t30, ptr %l21
  %t31 = load i64, ptr %l4
  store i64 %t31, ptr %l22
  %t32 = load ptr, ptr %l21
  %t33 = load i64, ptr %l22
  %t34 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t32, i64 %t33)
  store i64 %t34, ptr %l23
  br label %bb7
bb7:
  %t35 = load i64, ptr %l23
  store i64 %t35, ptr %l5
  %t36 = load i64, ptr %l5
  store i64 %t36, ptr %l24
  %t37 = load i64, ptr @G_2ecompiler_2fload_2ePending
  store i64 %t37, ptr %l25
  %t38 = load i64, ptr %l24
  %t39 = load i64, ptr %l25
  %t40 = icmp eq i64 %t38, %t39
  store i1 %t40, ptr %l26
  %t41 = load i1, ptr %l26
  br i1 %t41, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  store i64 -1, ptr %l27
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t42 = load i64, ptr %l27
  store i64 %t42, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t43 = load i64, ptr %l5
  store i64 %t43, ptr %l28
  %t44 = load ptr, ptr %l3
  store ptr %t44, ptr %l29
  %t45 = load ptr, ptr %l29
  %t46 = getelementptr %"compiler/load:Module", ptr %t45, i32 0, i32 19
  store ptr %t46, ptr %l30
  %t47 = load i64, ptr %l2
  store i64 %t47, ptr %l31
  %t48 = load ptr, ptr %l30
  %t49 = load i64, ptr %l31
  %t50 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t48, i64 %t49)
  store i64 %t50, ptr %l32
  br label %bb11
bb11:
  %t51 = load i64, ptr %l28
  %t52 = load i64, ptr %l32
  %t53 = icmp eq i64 %t51, %t52
  store i1 %t53, ptr %l33
  %t54 = load i1, ptr %l33
  br i1 %t54, label %bb12, label %bb13
bb12:
  store i64 1, ptr %l34
  br label %bb14
bb13:
  store i64 0, ptr %l34
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s0)
  %t55 = load i64, ptr %l34
  store i64 %t55, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2etopIf(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i32
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca i64
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca ptr
  %l34 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca ptr
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca ptr
  %l41 = alloca ptr
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i1
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca ptr
  %l51 = alloca ptr
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca ptr
  %l55 = alloca ptr
  %l56 = alloca i64
  %l57 = alloca i32
  %l58 = alloca i32
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca i1
  %l62 = alloca i64
  %l63 = alloca ptr
  %l64 = alloca ptr
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca i64
  %l68 = alloca ptr
  %l69 = alloca ptr
  %l70 = alloca i64
  %l71 = alloca i64
  %l72 = alloca i64
  %l73 = alloca i64
  %l74 = alloca i64
  %l75 = alloca i64
  %l76 = alloca { i64, ptr }
  %l77 = alloca i64
  %l78 = alloca i32
  %l79 = alloca ptr
  %l80 = alloca i32
  %l81 = alloca ptr
  %l82 = alloca i1
  %l83 = alloca i1
  %l84 = alloca i64
  %l85 = alloca i64
  %l86 = alloca i64
  %l87 = alloca { i64, ptr }
  %l88 = alloca i64
  %l89 = alloca i64
  %l90 = alloca i32
  %l91 = alloca ptr
  %l92 = alloca i32
  %l93 = alloca ptr
  %l94 = alloca i1
  %l95 = alloca i64
  %l96 = alloca i64
  %l97 = alloca { i64, ptr }
  %l98 = alloca i64
  %l99 = alloca i64
  %l100 = alloca i32
  %l101 = alloca ptr
  %l102 = alloca i32
  %l103 = alloca ptr
  %l104 = alloca i1
  %l105 = alloca i1
  %l106 = alloca i64
  %l107 = alloca i64
  %l108 = alloca ptr
  %l109 = alloca ptr
  %l110 = alloca i64
  %l111 = alloca i64
  %l112 = alloca i32
  %l113 = alloca i32
  %l114 = alloca i64
  %l115 = alloca i64
  %l116 = alloca i1
  %l117 = alloca i64
  %l118 = alloca ptr
  %l119 = alloca ptr
  %l120 = alloca i64
  %l121 = alloca ptr
  %l122 = alloca ptr
  %l123 = alloca i64
  %l124 = alloca i64
  %l125 = alloca i64
  %l126 = alloca ptr
  %l127 = alloca ptr
  %l128 = alloca i64
  %l129 = alloca i64
  %l130 = alloca i64
  %l131 = alloca i64
  %l132 = alloca i64
  %l133 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1
  store ptr %t1, ptr %l14
  %t2 = load ptr, ptr %l14
  %t3 = getelementptr %"compiler/load:Module", ptr %t2, i32 0, i32 6
  %t4 = load ptr, ptr %t3
  store ptr %t4, ptr %l15
  %t5 = load ptr, ptr %l15
  %t6 = getelementptr %"compiler/scan:Tokens", ptr %t5, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6
  store { i64, ptr } %t7, ptr %l16
  %t8 = load { i64, ptr }, ptr %l16
  store { i64, ptr } %t8, ptr %l5
  %t9 = load ptr, ptr %l1
  store ptr %t9, ptr %l17
  %t10 = load ptr, ptr %l17
  %t11 = getelementptr %"compiler/load:Module", ptr %t10, i32 0, i32 12
  store ptr %t11, ptr %l18
  %t12 = load ptr, ptr %l18
  %t13 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2eLen_3cI32_3e(ptr %v1, ptr %t12)
  store i64 %t13, ptr %l19
  br label %bb1
bb1:
  %t14 = load i64, ptr %l19
  store i64 %t14, ptr %l6
  %t15 = load ptr, ptr %l1
  store ptr %t15, ptr %l20
  %t16 = load ptr, ptr %l20
  %t17 = getelementptr %"compiler/load:Module", ptr %t16, i32 0, i32 12
  store ptr %t17, ptr %l21
  %t18 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t18, ptr %l22
  %t19 = load i64, ptr %l2
  store i64 %t19, ptr %l23
  %t20 = load i64, ptr %l23
  %t21 = add i64 %t20, 1
  store i64 %t21, ptr %l24
  %t22 = load i64, ptr %l24
  %t23 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t24 = load ptr, ptr %t23
  %t25 = getelementptr %"compiler/token:Token", ptr %t24, i64 %t22
  %t26 = getelementptr %"compiler/token:Token", ptr %t25, i32 0, i32 2
  %t27 = load i32, ptr %t26
  store i32 %t27, ptr %l25
  %t28 = load ptr, ptr %l21
  %t29 = load i32, ptr %l25
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2ePush_3cI32_3e(ptr %v1, ptr %t28, i32 %t29)
  br label %bb2
bb2:
  %t30 = load ptr, ptr %l1
  store ptr %t30, ptr %l26
  %t31 = load ptr, ptr %l26
  %t32 = getelementptr %"compiler/load:Module", ptr %t31, i32 0, i32 13
  store ptr %t32, ptr %l27
  %t33 = load i64, ptr %l4
  store i64 %t33, ptr %l28
  %t34 = load ptr, ptr %l27
  %t35 = load i64, ptr %l28
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t34, i64 %t35)
  br label %bb3
bb3:
  %t36 = load ptr, ptr %l1
  store ptr %t36, ptr %l29
  %t37 = load ptr, ptr %l29
  %t38 = getelementptr %"compiler/load:Module", ptr %t37, i32 0, i32 14
  store ptr %t38, ptr %l30
  %t39 = load i64, ptr @G_2ecompiler_2fload_2eNotYet
  store i64 %t39, ptr %l31
  %t40 = load ptr, ptr %l30
  %t41 = load i64, ptr %l31
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t40, i64 %t41)
  br label %bb4
bb4:
  %t42 = load ptr, ptr %l1
  store ptr %t42, ptr %l32
  %t43 = load ptr, ptr %l32
  %t44 = getelementptr %"compiler/load:Module", ptr %t43, i32 0, i32 15
  store ptr %t44, ptr %l33
  %t45 = load ptr, ptr %l33
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %v1, ptr %t45, i1 false)
  br label %bb5
bb5:
  %t46 = load ptr, ptr %l1
  store ptr %t46, ptr %l34
  %t47 = load ptr, ptr %l34
  %t48 = getelementptr %"compiler/load:Module", ptr %t47, i32 0, i32 16
  store ptr %t48, ptr %l35
  %t49 = load ptr, ptr %l1
  store ptr %t49, ptr %l36
  %t50 = load ptr, ptr %l36
  %t51 = getelementptr %"compiler/load:Module", ptr %t50, i32 0, i32 17
  store ptr %t51, ptr %l37
  %t52 = load ptr, ptr %l37
  %t53 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t52)
  store i64 %t53, ptr %l38
  br label %bb6
bb6:
  %t54 = load ptr, ptr %l35
  %t55 = load i64, ptr %l38
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t54, i64 %t55)
  br label %bb7
bb7:
  %t56 = load i64, ptr %l2
  store i64 %t56, ptr %l39
  %t57 = load i64, ptr %l39
  store i64 %t57, ptr %l7
  store i64 0, ptr %l8
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s1
  %t58 = load ptr, ptr %l0
  store ptr %t58, ptr %l40
  %t59 = load ptr, ptr %l1
  store ptr %t59, ptr %l41
  %t60 = load i64, ptr %l7
  store i64 %t60, ptr %l42
  %t61 = load i64, ptr %l42
  %t62 = add i64 %t61, 1
  store i64 %t62, ptr %l43
  %t63 = load i64, ptr %l3
  store i64 %t63, ptr %l44
  %t64 = load ptr, ptr %l40
  %t65 = load ptr, ptr %l41
  %t66 = load i64, ptr %l43
  %t67 = load i64, ptr %l44
  %t68 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2econdEnd(ptr %v0, ptr %v1, ptr %t64, ptr %t65, i64 %t66, i64 %t67)
  store i64 %t68, ptr %l45
  br label %bb9
bb9:
  %t69 = load i64, ptr %l45
  store i64 %t69, ptr %l9
  %t70 = load i64, ptr %l9
  store i64 %t70, ptr %l46
  %t71 = load i64, ptr %l46
  %t72 = icmp slt i64 %t71, 0
  store i1 %t72, ptr %l47
  %t73 = load i1, ptr %l47
  br i1 %t73, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t74 = load i64, ptr %l7
  store i64 %t74, ptr %l48
  %t75 = load i64, ptr %l48
  %t76 = add i64 %t75, 1
  store i64 %t76, ptr %l49
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t77 = load i64, ptr %l49
  store i64 %t77, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t78 = load ptr, ptr %l1
  store ptr %t78, ptr %l50
  %t79 = load ptr, ptr %l50
  %t80 = getelementptr %"compiler/load:Module", ptr %t79, i32 0, i32 17
  store ptr %t80, ptr %l51
  %t81 = load i64, ptr %l7
  store i64 %t81, ptr %l52
  %t82 = load i64, ptr %l52
  %t83 = add i64 %t82, 1
  store i64 %t83, ptr %l53
  %t84 = load ptr, ptr %l51
  %t85 = load i64, ptr %l53
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t84, i64 %t85)
  br label %bb13
bb13:
  %t86 = load ptr, ptr %l1
  store ptr %t86, ptr %l54
  %t87 = load ptr, ptr %l54
  %t88 = getelementptr %"compiler/load:Module", ptr %t87, i32 0, i32 6
  %t89 = load ptr, ptr %t88
  store ptr %t89, ptr %l55
  %t90 = load i64, ptr %l9
  store i64 %t90, ptr %l56
  %t91 = load i64, ptr %l56
  %t92 = trunc i64 %t91 to i32
  store i32 %t92, ptr %l57
  %t93 = load ptr, ptr %l55
  %t94 = load i32, ptr %l57
  %t95 = call i32 @compiler_2fscan_2ecompiler_2fscan_3aTokens_2eMatch(ptr %v1, ptr %t93, i32 %t94)
  store i32 %t95, ptr %l58
  br label %bb14
bb14:
  %t96 = load i32, ptr %l58
  %t97 = sext i32 %t96 to i64
  store i64 %t97, ptr %l59
  %t98 = load i64, ptr %l59
  store i64 %t98, ptr %l10
  %t99 = load i64, ptr %l10
  store i64 %t99, ptr %l60
  %t100 = load i64, ptr %l60
  %t101 = icmp slt i64 %t100, 0
  store i1 %t101, ptr %l61
  %t102 = load i1, ptr %l61
  br i1 %t102, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t103 = load i64, ptr %l3
  store i64 %t103, ptr %l62
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t104 = load i64, ptr %l62
  store i64 %t104, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t105 = load ptr, ptr %l0
  store ptr %t105, ptr %l63
  %t106 = load ptr, ptr %l1
  store ptr %t106, ptr %l64
  %t107 = load i64, ptr %l6
  store i64 %t107, ptr %l65
  %t108 = load i64, ptr %l8
  store i64 %t108, ptr %l66
  %t109 = load ptr, ptr %l63
  %t110 = load ptr, ptr %l64
  %t111 = load i64, ptr %l65
  %t112 = load i64, ptr %l66
  %t113 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2ebranch(ptr %v0, ptr %v1, ptr %t109, ptr %t110, i64 %t111, i64 %t112)
  store i64 %t113, ptr %l67
  br label %bb18
bb18:
  %t114 = load i64, ptr %l67
  store i64 %t114, ptr %l11
  %t115 = load ptr, ptr %l0
  store ptr %t115, ptr %l68
  %t116 = load ptr, ptr %l1
  store ptr %t116, ptr %l69
  %t117 = load i64, ptr %l9
  store i64 %t117, ptr %l70
  %t118 = load i64, ptr %l70
  %t119 = add i64 %t118, 1
  store i64 %t119, ptr %l71
  %t120 = load i64, ptr %l10
  store i64 %t120, ptr %l72
  %t121 = load i64, ptr %l11
  store i64 %t121, ptr %l73
  %t122 = load ptr, ptr %l68
  %t123 = load ptr, ptr %l69
  %t124 = load i64, ptr %l71
  %t125 = load i64, ptr %l72
  %t126 = load i64, ptr %l73
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2eregion(ptr %v0, ptr %v1, ptr %t122, ptr %t123, i64 %t124, i64 %t125, i64 %t126)
  br label %bb19
bb19:
  %t127 = load i64, ptr %l10
  store i64 %t127, ptr %l74
  %t128 = load i64, ptr %l74
  %t129 = add i64 %t128, 1
  store i64 %t129, ptr %l75
  %t130 = load i64, ptr %l75
  store i64 %t130, ptr %l7
  %t131 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t131, ptr %l76
  %t132 = load i64, ptr %l7
  store i64 %t132, ptr %l77
  %t133 = load i64, ptr %l77
  %t134 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t135 = load ptr, ptr %t134
  %t136 = getelementptr %"compiler/token:Token", ptr %t135, i64 %t133
  %t137 = getelementptr %"compiler/token:Token", ptr %t136, i32 0, i32 0
  %t138 = load i32, ptr %t137
  store i32 %t138, ptr %l78
  store ptr %l78, ptr %l79
  store i32 10, ptr %l80
  store ptr %l80, ptr %l81
  %t139 = load ptr, ptr %l79
  %t140 = load ptr, ptr %l81
  %t141 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t139, ptr %t140)
  store i1 %t141, ptr %l82
  br label %bb20
bb20:
  %t142 = load i1, ptr %l82
  %t143 = xor i1 %t142, true
  store i1 %t143, ptr %l83
  %t144 = load i1, ptr %l83
  br i1 %t144, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s4
  %t145 = load i64, ptr %l7
  store i64 %t145, ptr %l84
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t146 = load i64, ptr %l84
  store i64 %t146, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t147 = load i64, ptr %l8
  store i64 %t147, ptr %l85
  %t148 = load i64, ptr %l85
  %t149 = add i64 %t148, 1
  store i64 %t149, ptr %l86
  %t150 = load i64, ptr %l86
  store i64 %t150, ptr %l8
  %t151 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t151, ptr %l87
  %t152 = load i64, ptr %l7
  store i64 %t152, ptr %l88
  %t153 = load i64, ptr %l88
  %t154 = add i64 %t153, 1
  store i64 %t154, ptr %l89
  %t155 = load i64, ptr %l89
  %t156 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t157 = load ptr, ptr %t156
  %t158 = getelementptr %"compiler/token:Token", ptr %t157, i64 %t155
  %t159 = getelementptr %"compiler/token:Token", ptr %t158, i32 0, i32 0
  %t160 = load i32, ptr %t159
  store i32 %t160, ptr %l90
  store ptr %l90, ptr %l91
  store i32 9, ptr %l92
  store ptr %l92, ptr %l93
  %t161 = load ptr, ptr %l91
  %t162 = load ptr, ptr %l93
  %t163 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t161, ptr %t162)
  store i1 %t163, ptr %l94
  br label %bb24
bb24:
  %t164 = load i1, ptr %l94
  br i1 %t164, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s5
  %t165 = load i64, ptr %l7
  store i64 %t165, ptr %l95
  %t166 = load i64, ptr %l95
  %t167 = add i64 %t166, 1
  store i64 %t167, ptr %l96
  %t168 = load i64, ptr %l96
  store i64 %t168, ptr %l7
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s1)
  br label %bb39
bb26:
  br label %bb27
bb27:
  %t169 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t169, ptr %l97
  %t170 = load i64, ptr %l7
  store i64 %t170, ptr %l98
  %t171 = load i64, ptr %l98
  %t172 = add i64 %t171, 1
  store i64 %t172, ptr %l99
  %t173 = load i64, ptr %l99
  %t174 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t175 = load ptr, ptr %t174
  %t176 = getelementptr %"compiler/token:Token", ptr %t175, i64 %t173
  %t177 = getelementptr %"compiler/token:Token", ptr %t176, i32 0, i32 0
  %t178 = load i32, ptr %t177
  store i32 %t178, ptr %l100
  store ptr %l100, ptr %l101
  store i32 94, ptr %l102
  store ptr %l102, ptr %l103
  %t179 = load ptr, ptr %l101
  %t180 = load ptr, ptr %l103
  %t181 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t179, ptr %t180)
  store i1 %t181, ptr %l104
  br label %bb28
bb28:
  %t182 = load i1, ptr %l104
  %t183 = xor i1 %t182, true
  store i1 %t183, ptr %l105
  %t184 = load i1, ptr %l105
  br i1 %t184, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s6
  %t185 = load i64, ptr %l7
  store i64 %t185, ptr %l106
  %t186 = load i64, ptr %l106
  %t187 = add i64 %t186, 1
  store i64 %t187, ptr %l107
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t188 = load i64, ptr %l107
  store i64 %t188, ptr %rv
  br label %ret
bb30:
  br label %bb31
bb31:
  %t189 = load ptr, ptr %l1
  store ptr %t189, ptr %l108
  %t190 = load ptr, ptr %l108
  %t191 = getelementptr %"compiler/load:Module", ptr %t190, i32 0, i32 6
  %t192 = load ptr, ptr %t191
  store ptr %t192, ptr %l109
  %t193 = load i64, ptr %l7
  store i64 %t193, ptr %l110
  %t194 = load i64, ptr %l110
  %t195 = add i64 %t194, 1
  store i64 %t195, ptr %l111
  %t196 = load i64, ptr %l111
  %t197 = trunc i64 %t196 to i32
  store i32 %t197, ptr %l112
  %t198 = load ptr, ptr %l109
  %t199 = load i32, ptr %l112
  %t200 = call i32 @compiler_2fscan_2ecompiler_2fscan_3aTokens_2eMatch(ptr %v1, ptr %t198, i32 %t199)
  store i32 %t200, ptr %l113
  br label %bb32
bb32:
  %t201 = load i32, ptr %l113
  %t202 = sext i32 %t201 to i64
  store i64 %t202, ptr %l114
  %t203 = load i64, ptr %l114
  store i64 %t203, ptr %l12
  %t204 = load i64, ptr %l12
  store i64 %t204, ptr %l115
  %t205 = load i64, ptr %l115
  %t206 = icmp slt i64 %t205, 0
  store i1 %t206, ptr %l116
  %t207 = load i1, ptr %l116
  br i1 %t207, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s7
  %t208 = load i64, ptr %l3
  store i64 %t208, ptr %l117
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t209 = load i64, ptr %l117
  store i64 %t209, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  %t210 = load ptr, ptr %l1
  store ptr %t210, ptr %l118
  %t211 = load ptr, ptr %l118
  %t212 = getelementptr %"compiler/load:Module", ptr %t211, i32 0, i32 15
  store ptr %t212, ptr %l119
  %t213 = load i64, ptr %l6
  store i64 %t213, ptr %l120
  %t214 = load ptr, ptr %l119
  %t215 = load i64, ptr %l120
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eSetAt_3cBool_3e(ptr %v1, ptr %t214, i64 %t215, i1 true)
  br label %bb36
bb36:
  %t216 = load ptr, ptr %l0
  store ptr %t216, ptr %l121
  %t217 = load ptr, ptr %l1
  store ptr %t217, ptr %l122
  %t218 = load i64, ptr %l6
  store i64 %t218, ptr %l123
  %t219 = load i64, ptr %l8
  store i64 %t219, ptr %l124
  %t220 = load ptr, ptr %l121
  %t221 = load ptr, ptr %l122
  %t222 = load i64, ptr %l123
  %t223 = load i64, ptr %l124
  %t224 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2ebranch(ptr %v0, ptr %v1, ptr %t220, ptr %t221, i64 %t222, i64 %t223)
  store i64 %t224, ptr %l125
  br label %bb37
bb37:
  %t225 = load i64, ptr %l125
  store i64 %t225, ptr %l13
  %t226 = load ptr, ptr %l0
  store ptr %t226, ptr %l126
  %t227 = load ptr, ptr %l1
  store ptr %t227, ptr %l127
  %t228 = load i64, ptr %l7
  store i64 %t228, ptr %l128
  %t229 = load i64, ptr %l128
  %t230 = add i64 %t229, 2
  store i64 %t230, ptr %l129
  %t231 = load i64, ptr %l12
  store i64 %t231, ptr %l130
  %t232 = load i64, ptr %l13
  store i64 %t232, ptr %l131
  %t233 = load ptr, ptr %l126
  %t234 = load ptr, ptr %l127
  %t235 = load i64, ptr %l129
  %t236 = load i64, ptr %l130
  %t237 = load i64, ptr %l131
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2eregion(ptr %v0, ptr %v1, ptr %t233, ptr %t234, i64 %t235, i64 %t236, i64 %t237)
  br label %bb38
bb38:
  %t238 = load i64, ptr %l12
  store i64 %t238, ptr %l132
  %t239 = load i64, ptr %l132
  %t240 = add i64 %t239, 1
  store i64 %t240, ptr %l133
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t241 = load i64, ptr %l133
  store i64 %t241, ptr %rv
  br label %ret
bb39:
  br label %bb8
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2fload_2efirstElems(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i8
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i1
  %l14 = alloca i1
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i8
  %l19 = alloca i8
  %l20 = alloca i1
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i1
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i1
  %l30 = alloca i1
  %l31 = alloca i1
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i1
  %l41 = alloca i1
  %l42 = alloca i1
  %l43 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 0, ptr %l2
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l8
  %t2 = load { i64, ptr }, ptr %l8
  store { i64, ptr } %t2, ptr %l3
  store i64 0, ptr %l4
  %t3 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t3, ptr %l9
  %t4 = load { i64, ptr }, ptr %l9
  %t5 = extractvalue { i64, ptr } %t4, 0
  store i64 %t5, ptr %l10
  %t6 = load i64, ptr %l10
  store i64 %t6, ptr %l5
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l4
  store i64 %t7, ptr %l11
  %t8 = load i64, ptr %l5
  store i64 %t8, ptr %l12
  %t9 = load i64, ptr %l11
  %t10 = load i64, ptr %l12
  %t11 = icmp slt i64 %t9, %t10
  store i1 %t11, ptr %l13
  %t12 = load i1, ptr %l13
  %t13 = xor i1 %t12, true
  store i1 %t13, ptr %l14
  %t14 = load i1, ptr %l14
  br i1 %t14, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb3:
  br label %bb4
bb4:
  %t15 = load i64, ptr %l4
  store i64 %t15, ptr %l15
  %t16 = load i64, ptr %l15
  store i64 %t16, ptr %l6
  %t17 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t17, ptr %l16
  %t18 = load i64, ptr %l4
  store i64 %t18, ptr %l17
  %t19 = load i64, ptr %l17
  %t20 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t21 = load ptr, ptr %t20
  %t22 = getelementptr i8, ptr %t21, i64 %t19
  %t23 = load i8, ptr %t22
  store i8 %t23, ptr %l18
  %t24 = load i8, ptr %l18
  store i8 %t24, ptr %l7
  %t25 = load i8, ptr %l7
  store i8 %t25, ptr %l19
  %t26 = load i8, ptr %l19
  %t27 = icmp eq i8 %t26, 47
  store i1 %t27, ptr %l20
  %t28 = load i1, ptr %l20
  br i1 %t28, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t29 = load i64, ptr %l2
  store i64 %t29, ptr %l21
  %t30 = load i64, ptr %l21
  %t31 = add i64 %t30, 1
  store i64 %t31, ptr %l22
  %t32 = load i64, ptr %l22
  store i64 %t32, ptr %l2
  %t33 = load i64, ptr %l2
  store i64 %t33, ptr %l23
  %t34 = load i64, ptr %l1
  store i64 %t34, ptr %l24
  %t35 = load i64, ptr %l23
  %t36 = load i64, ptr %l24
  %t37 = icmp eq i64 %t35, %t36
  store i1 %t37, ptr %l25
  %t38 = load i1, ptr %l25
  br i1 %t38, label %bb7, label %bb8
bb6:
  br label %bb16
bb7:
  store %olang.scope zeroinitializer, ptr %s4
  %t39 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t39, ptr %l26
  %t40 = load i64, ptr %l6
  store i64 %t40, ptr %l27
  %t41 = load { i64, ptr }, ptr %l26
  %t42 = extractvalue { i64, ptr } %t41, 0
  store i64 %t42, ptr %l28
  %t43 = icmp sge i64 0, 0
  store i1 %t43, ptr %l29
  %t44 = load i1, ptr %l29
  br i1 %t44, label %bb9, label %bb10
bb8:
  br label %bb15
bb9:
  %t45 = load i64, ptr %l27
  %t46 = icmp sle i64 0, %t45
  store i1 %t46, ptr %l30
  %t47 = load i1, ptr %l30
  br i1 %t47, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @.c115)
  unreachable
bb11:
  %t48 = load i64, ptr %l27
  %t49 = load i64, ptr %l28
  %t50 = icmp sle i64 %t48, %t49
  store i1 %t50, ptr %l31
  %t51 = load i1, ptr %l31
  br i1 %t51, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @.c115)
  unreachable
bb13:
  %t52 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t53 = load ptr, ptr %t52
  %t54 = load i64, ptr %l27
  %t55 = getelementptr i8, ptr %t53, i64 0
  %t56 = sub i64 %t54, 0
  %t57 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t55, 1
  store { i64, ptr } %t58, ptr %l32
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t59 = load { i64, ptr }, ptr %l32
  store { i64, ptr } %t59, ptr %rv
  br label %ret
bb14:
  call void @__olang_check_failed(ptr @.c115)
  unreachable
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s5
  %t60 = load i64, ptr %l4
  store i64 %t60, ptr %l33
  %t61 = load i64, ptr %l33
  %t62 = add i64 %t61, 1
  store i64 %t62, ptr %l34
  %t63 = load i64, ptr %l34
  store i64 %t63, ptr %l4
  call void @__olang_scope_close(ptr %s5)
  br label %bb1
bb18:
  call void @__olang_scope_close(ptr %s1)
  %t64 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t64, ptr %l35
  %t65 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t65, ptr %l36
  %t66 = load { i64, ptr }, ptr %l36
  store { i64, ptr } %t66, ptr %l37
  %t67 = load { i64, ptr }, ptr %l37
  %t68 = extractvalue { i64, ptr } %t67, 0
  store i64 %t68, ptr %l38
  %t69 = load { i64, ptr }, ptr %l35
  %t70 = extractvalue { i64, ptr } %t69, 0
  store i64 %t70, ptr %l39
  %t71 = icmp sge i64 0, 0
  store i1 %t71, ptr %l40
  %t72 = load i1, ptr %l40
  br i1 %t72, label %bb19, label %bb20
bb19:
  %t73 = load i64, ptr %l38
  %t74 = icmp sle i64 0, %t73
  store i1 %t74, ptr %l41
  %t75 = load i1, ptr %l41
  br i1 %t75, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @.c116)
  unreachable
bb21:
  %t76 = load i64, ptr %l38
  %t77 = load i64, ptr %l39
  %t78 = icmp sle i64 %t76, %t77
  store i1 %t78, ptr %l42
  %t79 = load i1, ptr %l42
  br i1 %t79, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @.c116)
  unreachable
bb23:
  %t80 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t81 = load ptr, ptr %t80
  %t82 = load i64, ptr %l38
  %t83 = getelementptr i8, ptr %t81, i64 0
  %t84 = sub i64 %t82, 0
  %t85 = insertvalue { i64, ptr } undef, i64 %t84, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t83, 1
  store { i64, ptr } %t86, ptr %l43
  call void @__olang_scope_close(ptr %s0)
  %t87 = load { i64, ptr }, ptr %l43
  store { i64, ptr } %t87, ptr %rv
  br label %ret
bb24:
  call void @__olang_check_failed(ptr @.c116)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fload_2ekey(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l1
  %t2 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t3 = load ptr, ptr %t2
  %t4 = getelementptr { i64, ptr }, ptr %t3, i64 0
  %t5 = load { i64, ptr }, ptr %t4
  store { i64, ptr } %t5, ptr %l2
  %t6 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t6, ptr %l3
  %t7 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t8 = load ptr, ptr %t7
  %t9 = getelementptr { i64, ptr }, ptr %t8, i64 1
  %t10 = load { i64, ptr }, ptr %t9
  store { i64, ptr } %t10, ptr %l4
  %t11 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t11, ptr %l5
  %t12 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t13 = load ptr, ptr %t12
  %t14 = getelementptr { i64, ptr }, ptr %t13, i64 2
  %t15 = load { i64, ptr }, ptr %t14
  store { i64, ptr } %t15, ptr %l6
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t16 = load { i64, ptr }, ptr %l2
  %t17 = extractvalue { i64, ptr } %t16, 1
  %t18 = extractvalue { i64, ptr } %t16, 0
  call void @__olang_sb_put(ptr %s1, ptr %t17, i64 %t18)
  %t19 = extractvalue { i64, ptr } { i64 1, ptr @.d117 }, 1
  %t20 = extractvalue { i64, ptr } { i64 1, ptr @.d117 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t19, i64 %t20)
  %t21 = load { i64, ptr }, ptr %l4
  %t22 = extractvalue { i64, ptr } %t21, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  call void @__olang_sb_put(ptr %s1, ptr %t22, i64 %t23)
  %t24 = extractvalue { i64, ptr } { i64 1, ptr @.d118 }, 1
  %t25 = extractvalue { i64, ptr } { i64 1, ptr @.d118 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t24, i64 %t25)
  %t26 = load { i64, ptr }, ptr %l6
  %t27 = extractvalue { i64, ptr } %t26, 1
  %t28 = extractvalue { i64, ptr } %t26, 0
  call void @__olang_sb_put(ptr %s1, ptr %t27, i64 %t28)
  %t29 = load ptr, ptr %s1
  %t30 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t31 = load i64, ptr %t30
  %t32 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t31)
  call void @llvm.memcpy.p0.p0.i64(ptr %t32, ptr %t29, i64 %t31, i1 false)
  %t33 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  store { i64, ptr } %t34, ptr %l7
  call void @__olang_sb_done(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t35 = load { i64, ptr }, ptr %l7
  store { i64, ptr } %t35, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fload_2emoduleDir(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i1
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i1
  %l20 = alloca i1
  %l21 = alloca i1
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.builder
  %s3room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l3
  %t2 = load { i64, ptr }, ptr %l3
  %t3 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %s0, { i64, ptr } %t2, { i64, ptr } { i64 1, ptr @.d119 })
  %t4 = extractvalue { i32, i64 } %t3, 1
  %t5 = extractvalue { i32, i64 } %t3, 0
  store i32 %t5, ptr %l5
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store i64 %t4, ptr %l4
  br label %bb1
bb1:
  %t8 = load i64, ptr %l4
  store i64 %t8, ptr %l2
  br label %bb4
bb2:
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  store { i64, ptr } { i64 1, ptr @.d120 }, ptr %l6
  %t9 = load { i64, ptr }, ptr %l6
  store { i64, ptr } %t9, ptr %l7
  %t10 = load { i64, ptr }, ptr %l7
  %t11 = extractvalue { i64, ptr } %t10, 0
  store i64 %t11, ptr %l8
  %t12 = load i64, ptr %l8
  %t13 = mul i64 %t12, 1
  %t14 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t13)
  %t15 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l9
  %t17 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t18 = load ptr, ptr %t17
  %t19 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t20 = load ptr, ptr %t19
  %t21 = load i64, ptr %l8
  %t22 = mul i64 %t21, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t18, ptr %t20, i64 %t22, i1 false)
  %t23 = load { i64, ptr }, ptr %l9
  store { i64, ptr } %t23, ptr %l7
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t24 = load { i64, ptr }, ptr %l7
  store { i64, ptr } %t24, ptr %rv
  br label %ret
bb4:
  %t25 = load i64, ptr %l2
  store i64 %t25, ptr %l1
  %t26 = load i64, ptr %l1
  store i64 %t26, ptr %l10
  %t27 = load i64, ptr %l10
  %t28 = icmp eq i64 %t27, 0
  store i1 %t28, ptr %l11
  %t29 = load i1, ptr %l11
  br i1 %t29, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  store { i64, ptr } { i64 1, ptr @.d121 }, ptr %l12
  %t30 = load { i64, ptr }, ptr %l12
  store { i64, ptr } %t30, ptr %l13
  %t31 = load { i64, ptr }, ptr %l13
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l14
  %t33 = load i64, ptr %l14
  %t34 = mul i64 %t33, 1
  %t35 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t34)
  %t36 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t35, 1
  store { i64, ptr } %t37, ptr %l15
  %t38 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t39 = load ptr, ptr %t38
  %t40 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t41 = load ptr, ptr %t40
  %t42 = load i64, ptr %l14
  %t43 = mul i64 %t42, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t39, ptr %t41, i64 %t43, i1 false)
  %t44 = load { i64, ptr }, ptr %l15
  store { i64, ptr } %t44, ptr %l13
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t45 = load { i64, ptr }, ptr %l13
  store { i64, ptr } %t45, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t46 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t46, ptr %l16
  %t47 = load i64, ptr %l1
  store i64 %t47, ptr %l17
  %t48 = load { i64, ptr }, ptr %l16
  %t49 = extractvalue { i64, ptr } %t48, 0
  store i64 %t49, ptr %l18
  %t50 = icmp sge i64 0, 0
  store i1 %t50, ptr %l19
  %t51 = load i1, ptr %l19
  br i1 %t51, label %bb8, label %bb9
bb8:
  %t52 = load i64, ptr %l17
  %t53 = icmp sle i64 0, %t52
  store i1 %t53, ptr %l20
  %t54 = load i1, ptr %l20
  br i1 %t54, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @.c122)
  unreachable
bb10:
  %t55 = load i64, ptr %l17
  %t56 = load i64, ptr %l18
  %t57 = icmp sle i64 %t55, %t56
  store i1 %t57, ptr %l21
  %t58 = load i1, ptr %l21
  br i1 %t58, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @.c122)
  unreachable
bb12:
  %t59 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t60 = load ptr, ptr %t59
  %t61 = load i64, ptr %l17
  %t62 = getelementptr i8, ptr %t60, i64 0
  %t63 = sub i64 %t61, 0
  %t64 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t62, 1
  store { i64, ptr } %t65, ptr %l22
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s3
  store ptr %s3room, ptr %s3
  %t66 = load { i64, ptr }, ptr %l22
  %t67 = extractvalue { i64, ptr } %t66, 1
  %t68 = extractvalue { i64, ptr } %t66, 0
  call void @__olang_sb_put(ptr %s3, ptr %t67, i64 %t68)
  %t69 = load ptr, ptr %s3
  %t70 = getelementptr %olang.builder, ptr %s3, i32 0, i32 1
  %t71 = load i64, ptr %t70
  %t72 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t71)
  call void @llvm.memcpy.p0.p0.i64(ptr %t72, ptr %t69, i64 %t71, i1 false)
  %t73 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  store { i64, ptr } %t74, ptr %l23
  call void @__olang_sb_done(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t75 = load { i64, ptr }, ptr %l23
  store { i64, ptr } %t75, ptr %rv
  br label %ret
bb13:
  call void @__olang_check_failed(ptr @.c122)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fload_2erelativeIdentity(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca i1
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i1
  %l15 = alloca i1
  %l16 = alloca i1
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.builder
  %s2room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l4
  %t2 = load { i64, ptr }, ptr %l4
  %t3 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %s0, { i64, ptr } %t2, { i64, ptr } { i64 1, ptr @.d123 })
  %t4 = extractvalue { i32, i64 } %t3, 1
  %t5 = extractvalue { i32, i64 } %t3, 0
  store i32 %t5, ptr %l6
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store i64 %t4, ptr %l5
  br label %bb1
bb1:
  %t8 = load i64, ptr %l5
  store i64 %t8, ptr %l3
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 -1, ptr %l3
  br label %bb4
bb4:
  %t9 = load i64, ptr %l3
  store i64 %t9, ptr %l2
  %t10 = load i64, ptr %l2
  store i64 %t10, ptr %l7
  %t11 = load i64, ptr %l7
  %t12 = icmp slt i64 %t11, 0
  store i1 %t12, ptr %l8
  %t13 = load i1, ptr %l8
  br i1 %t13, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t14 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t14, ptr %l9
  %t15 = load { i64, ptr }, ptr %l9
  %t16 = call { i64, ptr } @compiler_2fload_2eNormalize(ptr %v1, ptr %v2, { i64, ptr } %t15)
  store { i64, ptr } %t16, ptr %l10
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t17 = load { i64, ptr }, ptr %l10
  store { i64, ptr } %t17, ptr %rv
  br label %ret
bb8:
  %t18 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t18, ptr %l11
  %t19 = load i64, ptr %l2
  store i64 %t19, ptr %l12
  %t20 = load { i64, ptr }, ptr %l11
  %t21 = extractvalue { i64, ptr } %t20, 0
  store i64 %t21, ptr %l13
  %t22 = icmp sge i64 0, 0
  store i1 %t22, ptr %l14
  %t23 = load i1, ptr %l14
  br i1 %t23, label %bb9, label %bb10
bb9:
  %t24 = load i64, ptr %l12
  %t25 = icmp sle i64 0, %t24
  store i1 %t25, ptr %l15
  %t26 = load i1, ptr %l15
  br i1 %t26, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @.c124)
  unreachable
bb11:
  %t27 = load i64, ptr %l12
  %t28 = load i64, ptr %l13
  %t29 = icmp sle i64 %t27, %t28
  store i1 %t29, ptr %l16
  %t30 = load i1, ptr %l16
  br i1 %t30, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @.c124)
  unreachable
bb13:
  %t31 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t32 = load ptr, ptr %t31
  %t33 = load i64, ptr %l12
  %t34 = getelementptr i8, ptr %t32, i64 0
  %t35 = sub i64 %t33, 0
  %t36 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t34, 1
  store { i64, ptr } %t37, ptr %l17
  %t38 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t38, ptr %l18
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s2
  store ptr %s2room, ptr %s2
  %t39 = load { i64, ptr }, ptr %l17
  %t40 = extractvalue { i64, ptr } %t39, 1
  %t41 = extractvalue { i64, ptr } %t39, 0
  call void @__olang_sb_put(ptr %s2, ptr %t40, i64 %t41)
  %t42 = extractvalue { i64, ptr } { i64 1, ptr @.d125 }, 1
  %t43 = extractvalue { i64, ptr } { i64 1, ptr @.d125 }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t42, i64 %t43)
  %t44 = load { i64, ptr }, ptr %l18
  %t45 = extractvalue { i64, ptr } %t44, 1
  %t46 = extractvalue { i64, ptr } %t44, 0
  call void @__olang_sb_put(ptr %s2, ptr %t45, i64 %t46)
  %t47 = load ptr, ptr %s2
  %t48 = getelementptr %olang.builder, ptr %s2, i32 0, i32 1
  %t49 = load i64, ptr %t48
  %t50 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t49)
  call void @llvm.memcpy.p0.p0.i64(ptr %t50, ptr %t47, i64 %t49, i1 false)
  %t51 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  store { i64, ptr } %t52, ptr %l19
  call void @__olang_sb_done(ptr %s2)
  %t53 = load { i64, ptr }, ptr %l19
  %t54 = extractvalue { i64, ptr } %t53, 0
  %t55 = extractvalue { i64, ptr } %t53, 1
  %t56 = mul i64 %t54, 1
  %t57 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t56)
  call void @llvm.memcpy.p0.p0.i64(ptr %t57, ptr %t55, i64 %t56, i1 false)
  %t58 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t57, 1
  store { i64, ptr } %t59, ptr %l20
  %t60 = load { i64, ptr }, ptr %l20
  %t61 = call { i64, ptr } @compiler_2fload_2eNormalize(ptr %v2, ptr %v2, { i64, ptr } %t60)
  store { i64, ptr } %t61, ptr %l21
  br label %bb15
bb14:
  call void @__olang_check_failed(ptr @.c124)
  unreachable
bb15:
  call void @__olang_scope_close(ptr %s0)
  %t62 = load { i64, ptr }, ptr %l21
  store { i64, ptr } %t62, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local ptr @compiler_2fload_2etypeNames(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i1
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i1
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i1
  %l36 = alloca i1
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l44 = alloca i32
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i32
  %l49 = alloca ptr
  %l50 = alloca i32
  %l51 = alloca ptr
  %l52 = alloca i1
  %l53 = alloca i1
  %l54 = alloca i32
  %l55 = alloca ptr
  %l56 = alloca i32
  %l57 = alloca ptr
  %l58 = alloca i1
  %l59 = alloca i1
  %l60 = alloca i32
  %l61 = alloca ptr
  %l62 = alloca i32
  %l63 = alloca ptr
  %l64 = alloca i1
  %l65 = alloca i1
  %l66 = alloca { i64, ptr }
  %l67 = alloca i64
  %l68 = alloca i64
  %l69 = alloca i32
  %l70 = alloca ptr
  %l71 = alloca i32
  %l72 = alloca ptr
  %l73 = alloca i1
  %l74 = alloca ptr
  %l75 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l77 = alloca i64
  %l78 = alloca i64
  %l79 = alloca i32
  %l80 = alloca i64
  %l81 = alloca { i64, ptr }
  %l82 = alloca i64
  %l83 = alloca i64
  %l84 = alloca i32
  %l85 = alloca i64
  %l86 = alloca i64
  %l87 = alloca i1
  %l88 = alloca i1
  %l89 = alloca i1
  %l90 = alloca { i64, ptr }
  %l91 = alloca i64
  %l92 = alloca i64
  %l93 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca ptr
  store { i64, ptr } %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/list:List<std/prelude/text:String&>" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l11
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t2, ptr %t3
  store ptr %t3, ptr %l12
  %t4 = load ptr, ptr %l12
  store ptr %t4, ptr %l2
  %t5 = load ptr, ptr %l1
  store ptr %t5, ptr %l13
  %t6 = load ptr, ptr %l13
  %t7 = getelementptr %"compiler/scan:Tokens", ptr %t6, i32 0, i32 0
  %t8 = load { i64, ptr }, ptr %t7
  store { i64, ptr } %t8, ptr %l14
  %t9 = load { i64, ptr }, ptr %l14
  store { i64, ptr } %t9, ptr %l3
  store %olang.scope zeroinitializer, ptr %s1
  store i64 0, ptr %l4
  %t10 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t10, ptr %l15
  %t11 = load { i64, ptr }, ptr %l15
  %t12 = extractvalue { i64, ptr } %t11, 0
  store i64 %t12, ptr %l16
  %t13 = load i64, ptr %l16
  %t14 = sub i64 %t13, 2
  store i64 %t14, ptr %l17
  %t15 = load i64, ptr %l17
  store i64 %t15, ptr %l5
  store i64 1, ptr %l6
  %t16 = load i64, ptr %l5
  store i64 %t16, ptr %l18
  %t17 = load i64, ptr %l4
  store i64 %t17, ptr %l19
  %t18 = load i64, ptr %l18
  %t19 = load i64, ptr %l19
  %t20 = icmp sgt i64 %t18, %t19
  store i1 %t20, ptr %l20
  %t21 = load i1, ptr %l20
  br i1 %t21, label %bb2, label %bb3
bb2:
  %t22 = load i64, ptr %l6
  store i64 %t22, ptr %l22
  %t23 = load i64, ptr %l22
  %t24 = icmp sgt i64 %t23, 0
  store i1 %t24, ptr %l23
  %t25 = load i1, ptr %l23
  br i1 %t25, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l21
  br label %bb7
bb4:
  %t26 = load i64, ptr %l5
  store i64 %t26, ptr %l25
  %t27 = load i64, ptr %l4
  store i64 %t27, ptr %l26
  %t28 = load i64, ptr %l25
  %t29 = load i64, ptr %l26
  %t30 = sub i64 %t28, %t29
  store i64 %t30, ptr %l27
  %t31 = load i64, ptr %l6
  store i64 %t31, ptr %l28
  %t32 = load i64, ptr %l27
  %t33 = load i64, ptr %l28
  %t34 = add i64 %t32, %t33
  store i64 %t34, ptr %l29
  %t35 = load i64, ptr %l29
  %t36 = sub i64 %t35, 1
  store i64 %t36, ptr %l30
  %t37 = load i64, ptr %l6
  store i64 %t37, ptr %l31
  %t38 = load i64, ptr %l30
  %t39 = load i64, ptr %l31
  %t40 = sdiv i64 %t38, %t39
  store i64 %t40, ptr %l32
  %t41 = load i64, ptr %l32
  store i64 %t41, ptr %l24
  br label %bb6
bb5:
  store i64 0, ptr %l24
  br label %bb6
bb6:
  %t42 = load i64, ptr %l24
  store i64 %t42, ptr %l21
  br label %bb7
bb7:
  %t43 = load i64, ptr %l21
  store i64 %t43, ptr %l7
  store i64 0, ptr %l8
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t44 = load i64, ptr %l8
  store i64 %t44, ptr %l33
  %t45 = load i64, ptr %l7
  store i64 %t45, ptr %l34
  %t46 = load i64, ptr %l33
  %t47 = load i64, ptr %l34
  %t48 = icmp slt i64 %t46, %t47
  store i1 %t48, ptr %l35
  %t49 = load i1, ptr %l35
  %t50 = xor i1 %t49, true
  store i1 %t50, ptr %l36
  %t51 = load i1, ptr %l36
  br i1 %t51, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb36
bb10:
  br label %bb11
bb11:
  %t52 = load i64, ptr %l4
  store i64 %t52, ptr %l37
  %t53 = load i64, ptr %l8
  store i64 %t53, ptr %l38
  %t54 = load i64, ptr %l6
  store i64 %t54, ptr %l39
  %t55 = load i64, ptr %l38
  %t56 = load i64, ptr %l39
  %t57 = mul i64 %t55, %t56
  store i64 %t57, ptr %l40
  %t58 = load i64, ptr %l37
  %t59 = load i64, ptr %l40
  %t60 = add i64 %t58, %t59
  store i64 %t60, ptr %l41
  %t61 = load i64, ptr %l41
  store i64 %t61, ptr %l9
  %t62 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t62, ptr %l42
  %t63 = load i64, ptr %l9
  store i64 %t63, ptr %l43
  %t64 = load i64, ptr %l43
  %t65 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t66 = load ptr, ptr %t65
  %t67 = getelementptr %"compiler/token:Token", ptr %t66, i64 %t64
  %t68 = getelementptr %"compiler/token:Token", ptr %t67, i32 0, i32 0
  %t69 = load i32, ptr %t68
  store i32 %t69, ptr %l44
  %t70 = load i32, ptr %l44
  store i32 %t70, ptr %l10
  %t71 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t71, ptr %l45
  %t72 = load i64, ptr %l9
  store i64 %t72, ptr %l46
  %t73 = load i64, ptr %l46
  %t74 = add i64 %t73, 1
  store i64 %t74, ptr %l47
  %t75 = load i64, ptr %l47
  %t76 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t77 = load ptr, ptr %t76
  %t78 = getelementptr %"compiler/token:Token", ptr %t77, i64 %t75
  %t79 = getelementptr %"compiler/token:Token", ptr %t78, i32 0, i32 0
  %t80 = load i32, ptr %t79
  store i32 %t80, ptr %l48
  store ptr %l48, ptr %l49
  store i32 1, ptr %l50
  store ptr %l50, ptr %l51
  %t81 = load ptr, ptr %l49
  %t82 = load ptr, ptr %l51
  %t83 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t81, ptr %t82)
  store i1 %t83, ptr %l52
  br label %bb12
bb12:
  %t84 = load i1, ptr %l52
  %t85 = xor i1 %t84, true
  store i1 %t85, ptr %l53
  %t86 = load i1, ptr %l53
  br i1 %t86, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  br label %bb35
bb14:
  br label %bb15
bb15:
  %t87 = load i32, ptr %l10
  store i32 %t87, ptr %l54
  store ptr %l54, ptr %l55
  store i32 33, ptr %l56
  store ptr %l56, ptr %l57
  %t88 = load ptr, ptr %l55
  %t89 = load ptr, ptr %l57
  %t90 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t88, ptr %t89)
  store i1 %t90, ptr %l58
  br label %bb16
bb16:
  %t91 = load i1, ptr %l58
  br i1 %t91, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l59
  br label %bb24
bb18:
  %t92 = load i32, ptr %l10
  store i32 %t92, ptr %l60
  store ptr %l60, ptr %l61
  store i32 38, ptr %l62
  store ptr %l62, ptr %l63
  %t93 = load ptr, ptr %l61
  %t94 = load ptr, ptr %l63
  %t95 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t93, ptr %t94)
  store i1 %t95, ptr %l64
  br label %bb19
bb19:
  %t96 = load i1, ptr %l64
  br i1 %t96, label %bb20, label %bb21
bb20:
  %t97 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t97, ptr %l66
  %t98 = load i64, ptr %l9
  store i64 %t98, ptr %l67
  %t99 = load i64, ptr %l67
  %t100 = add i64 %t99, 2
  store i64 %t100, ptr %l68
  %t101 = load i64, ptr %l68
  %t102 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t103 = load ptr, ptr %t102
  %t104 = getelementptr %"compiler/token:Token", ptr %t103, i64 %t101
  %t105 = getelementptr %"compiler/token:Token", ptr %t104, i32 0, i32 0
  %t106 = load i32, ptr %t105
  store i32 %t106, ptr %l69
  store ptr %l69, ptr %l70
  store i32 94, ptr %l71
  store ptr %l71, ptr %l72
  %t107 = load ptr, ptr %l70
  %t108 = load ptr, ptr %l72
  %t109 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t107, ptr %t108)
  store i1 %t109, ptr %l73
  br label %bb22
bb21:
  store i1 false, ptr %l65
  br label %bb23
bb22:
  %t110 = load i1, ptr %l73
  store i1 %t110, ptr %l65
  br label %bb23
bb23:
  %t111 = load i1, ptr %l65
  store i1 %t111, ptr %l59
  br label %bb24
bb24:
  %t112 = load i1, ptr %l59
  br i1 %t112, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s4
  %t113 = load ptr, ptr %l2
  store ptr %t113, ptr %l74
  %t114 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t114, ptr %l75
  %t115 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t115, ptr %l76
  %t116 = load i64, ptr %l9
  store i64 %t116, ptr %l77
  %t117 = load i64, ptr %l77
  %t118 = add i64 %t117, 1
  store i64 %t118, ptr %l78
  %t119 = load i64, ptr %l78
  %t120 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t121 = load ptr, ptr %t120
  %t122 = getelementptr %"compiler/token:Token", ptr %t121, i64 %t119
  %t123 = getelementptr %"compiler/token:Token", ptr %t122, i32 0, i32 2
  %t124 = load i32, ptr %t123
  store i32 %t124, ptr %l79
  %t125 = load i32, ptr %l79
  %t126 = sext i32 %t125 to i64
  store i64 %t126, ptr %l80
  %t127 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t127, ptr %l81
  %t128 = load i64, ptr %l9
  store i64 %t128, ptr %l82
  %t129 = load i64, ptr %l82
  %t130 = add i64 %t129, 1
  store i64 %t130, ptr %l83
  %t131 = load i64, ptr %l83
  %t132 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t133 = load ptr, ptr %t132
  %t134 = getelementptr %"compiler/token:Token", ptr %t133, i64 %t131
  %t135 = getelementptr %"compiler/token:Token", ptr %t134, i32 0, i32 3
  %t136 = load i32, ptr %t135
  store i32 %t136, ptr %l84
  %t137 = load i32, ptr %l84
  %t138 = sext i32 %t137 to i64
  store i64 %t138, ptr %l85
  %t139 = load { i64, ptr }, ptr %l75
  %t140 = extractvalue { i64, ptr } %t139, 0
  store i64 %t140, ptr %l86
  %t141 = load i64, ptr %l80
  %t142 = icmp sge i64 %t141, 0
  store i1 %t142, ptr %l87
  %t143 = load i1, ptr %l87
  br i1 %t143, label %bb27, label %bb28
bb26:
  br label %bb34
bb27:
  %t144 = load i64, ptr %l80
  %t145 = load i64, ptr %l85
  %t146 = icmp sle i64 %t144, %t145
  store i1 %t146, ptr %l88
  %t147 = load i1, ptr %l88
  br i1 %t147, label %bb29, label %bb30
bb28:
  call void @__olang_check_failed(ptr @.c126)
  unreachable
bb29:
  %t148 = load i64, ptr %l85
  %t149 = load i64, ptr %l86
  %t150 = icmp sle i64 %t148, %t149
  store i1 %t150, ptr %l89
  %t151 = load i1, ptr %l89
  br i1 %t151, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @.c126)
  unreachable
bb31:
  %t152 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t153 = load ptr, ptr %t152
  %t154 = load i64, ptr %l80
  %t155 = load i64, ptr %l85
  %t156 = getelementptr i8, ptr %t153, i64 %t154
  %t157 = sub i64 %t155, %t154
  %t158 = insertvalue { i64, ptr } undef, i64 %t157, 0
  %t159 = insertvalue { i64, ptr } %t158, ptr %t156, 1
  store { i64, ptr } %t159, ptr %l90
  %t160 = load ptr, ptr %l74
  %t161 = load { i64, ptr }, ptr %l90
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v0, ptr %t160, { i64, ptr } %t161)
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @.c126)
  unreachable
bb33:
  call void @__olang_scope_close(ptr %s4)
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s2)
  br label %bb35
bb35:
  store %olang.scope zeroinitializer, ptr %s5
  %t162 = load i64, ptr %l8
  store i64 %t162, ptr %l91
  %t163 = load i64, ptr %l91
  %t164 = add i64 %t163, 1
  store i64 %t164, ptr %l92
  %t165 = load i64, ptr %l92
  store i64 %t165, ptr %l8
  call void @__olang_scope_close(ptr %s5)
  br label %bb8
bb36:
  call void @__olang_scope_close(ptr %s1)
  %t166 = load ptr, ptr %l2
  store ptr %t166, ptr %l93
  call void @__olang_scope_close(ptr %s0)
  %t167 = load ptr, ptr %l93
  store ptr %t167, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"compiler/load:Import" @compiler_2fload_3aImport_2ector(ptr %v0, ptr %v1, ptr %v2, %"compiler/source:Span" %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2, { i64, ptr } %a3, i64 %a4) #0 {
entry:
  %l0 = alloca %"compiler/source:Span"
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"compiler/source:Span"
  %l12 = alloca %"compiler/source:Span"
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca %"compiler/load:Import"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/load:Import"
  store %"compiler/source:Span" %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load %"compiler/source:Span", ptr %l0
  store %"compiler/source:Span" %t1, ptr %l11
  %t2 = load %"compiler/source:Span", ptr %l11
  store %"compiler/source:Span" %t2, ptr %l5
  %t3 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t3, ptr %l12
  %t4 = load %"compiler/source:Span", ptr %l12
  store %"compiler/source:Span" %t4, ptr %l6
  %t5 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t5, ptr %l13
  %t6 = load { i64, ptr }, ptr %l13
  store { i64, ptr } %t6, ptr %l7
  %t7 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t7, ptr %l14
  %t8 = load { i64, ptr }, ptr %l14
  store { i64, ptr } %t8, ptr %l8
  %t9 = load i64, ptr %l4
  store i64 %t9, ptr %l15
  %t10 = load i64, ptr %l15
  store i64 %t10, ptr %l9
  store i64 -1, ptr %l10
  %t11 = load %"compiler/source:Span", ptr %l5
  %t12 = insertvalue %"compiler/load:Import" undef, %"compiler/source:Span" %t11, 0
  %t13 = load %"compiler/source:Span", ptr %l6
  %t14 = insertvalue %"compiler/load:Import" %t12, %"compiler/source:Span" %t13, 1
  %t15 = load { i64, ptr }, ptr %l7
  %t16 = insertvalue %"compiler/load:Import" %t14, { i64, ptr } %t15, 2
  %t17 = load { i64, ptr }, ptr %l8
  %t18 = insertvalue %"compiler/load:Import" %t16, { i64, ptr } %t17, 3
  %t19 = load i64, ptr %l9
  %t20 = insertvalue %"compiler/load:Import" %t18, i64 %t19, 4
  %t21 = load i64, ptr %l10
  %t22 = insertvalue %"compiler/load:Import" %t20, i64 %t21, 5
  store %"compiler/load:Import" %t22, ptr %l16
  call void @__olang_scope_close(ptr %s0)
  %t23 = load %"compiler/load:Import", ptr %l16
  store %"compiler/load:Import" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/load:Import", ptr %rv
  ret %"compiler/load:Import" %rr
}

define dso_local %"compiler/load:Loader" @compiler_2fload_3aLoader_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca %"std/prelude/list:List<mut compiler/load:Module&>"
  %l11 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca %"std/prelude/list:List<mut compiler/load:Module&>"
  %l21 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l22 = alloca %"compiler/load:Loader"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/load:Loader"
  store { i64, ptr } %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l15
  %t2 = load { i64, ptr }, ptr %l15
  store { i64, ptr } %t2, ptr %l5
  %t3 = load ptr, ptr %l1
  store ptr %t3, ptr %l16
  %t4 = load ptr, ptr %l16
  store ptr %t4, ptr %l6
  %t5 = load ptr, ptr %l2
  store ptr %t5, ptr %l17
  %t6 = load ptr, ptr %l17
  store ptr %t6, ptr %l7
  %t7 = load ptr, ptr %l3
  store ptr %t7, ptr %l18
  %t8 = load ptr, ptr %l18
  store ptr %t8, ptr %l8
  %t9 = load ptr, ptr %l4
  store ptr %t9, ptr %l19
  %t10 = load ptr, ptr %l19
  store ptr %t10, ptr %l9
  %t11 = load ptr, ptr @__olang_prog_scope
  %t12 = call %"std/prelude/list:List<mut compiler/load:Module&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3e(ptr %t11)
  store %"std/prelude/list:List<mut compiler/load:Module&>" %t12, ptr %l20
  br label %bb1
bb1:
  %t13 = load %"std/prelude/list:List<mut compiler/load:Module&>", ptr %l20
  store %"std/prelude/list:List<mut compiler/load:Module&>" %t13, ptr %l10
  %t14 = load ptr, ptr @__olang_prog_scope
  %t15 = call %"std/prelude/list:List<std/prelude/text:String&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t14)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t15, ptr %l21
  br label %bb2
bb2:
  %t16 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l21
  store %"std/prelude/list:List<std/prelude/text:String&>" %t16, ptr %l11
  store i64 -1, ptr %l12
  store { i64, ptr } { i64 0, ptr @.d127 }, ptr %l13
  store { i64, ptr } { i64 0, ptr @.d128 }, ptr %l14
  %t17 = load { i64, ptr }, ptr %l5
  %t18 = insertvalue %"compiler/load:Loader" undef, { i64, ptr } %t17, 0
  %t19 = load ptr, ptr %l6
  %t20 = insertvalue %"compiler/load:Loader" %t18, ptr %t19, 1
  %t21 = load ptr, ptr %l7
  %t22 = insertvalue %"compiler/load:Loader" %t20, ptr %t21, 2
  %t23 = load ptr, ptr %l8
  %t24 = insertvalue %"compiler/load:Loader" %t22, ptr %t23, 3
  %t25 = load ptr, ptr %l9
  %t26 = insertvalue %"compiler/load:Loader" %t24, ptr %t25, 4
  %t27 = load %"std/prelude/list:List<mut compiler/load:Module&>", ptr %l10
  %t28 = insertvalue %"compiler/load:Loader" %t26, %"std/prelude/list:List<mut compiler/load:Module&>" %t27, 5
  %t29 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l11
  %t30 = insertvalue %"compiler/load:Loader" %t28, %"std/prelude/list:List<std/prelude/text:String&>" %t29, 6
  %t31 = load i64, ptr %l12
  %t32 = insertvalue %"compiler/load:Loader" %t30, i64 %t31, 7
  %t33 = load { i64, ptr }, ptr %l13
  %t34 = insertvalue %"compiler/load:Loader" %t32, { i64, ptr } %t33, 8
  %t35 = load { i64, ptr }, ptr %l14
  %t36 = insertvalue %"compiler/load:Loader" %t34, { i64, ptr } %t35, 9
  store %"compiler/load:Loader" %t36, ptr %l22
  call void @__olang_scope_close(ptr %s0)
  %t37 = load %"compiler/load:Loader", ptr %l22
  store %"compiler/load:Loader" %t37, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/load:Loader", ptr %rv
  ret %"compiler/load:Loader" %rr
}

define dso_local void @compiler_2fload_3aModule_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i1
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i1
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l13 = alloca %"std/prelude/list:List<compiler/load:Import>"
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca %"std/prelude/list:List<I32>"
  %l17 = alloca %"std/prelude/list:List<I64>"
  %l18 = alloca %"std/prelude/list:List<I64>"
  %l19 = alloca %"std/prelude/list:List<Bool>"
  %l20 = alloca %"std/prelude/list:List<I64>"
  %l21 = alloca %"std/prelude/list:List<I64>"
  %l22 = alloca %"std/prelude/list:List<I64>"
  %l23 = alloca %"std/prelude/list:List<I64>"
  %l24 = alloca %"std/prelude/list:List<I64>"
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca i1
  %l29 = alloca i1
  %l30 = alloca %"std/prelude/list:List<I64>"
  %l31 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca i1
  %l35 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l36 = alloca %"std/prelude/list:List<compiler/load:Import>"
  %l37 = alloca %"std/prelude/list:List<I32>"
  %l38 = alloca %"std/prelude/list:List<I64>"
  %l39 = alloca %"std/prelude/list:List<I64>"
  %l40 = alloca %"std/prelude/list:List<Bool>"
  %l41 = alloca %"std/prelude/list:List<I64>"
  %l42 = alloca %"std/prelude/list:List<I64>"
  %l43 = alloca %"std/prelude/list:List<I64>"
  %l44 = alloca %"std/prelude/list:List<I64>"
  %l45 = alloca %"std/prelude/list:List<I64>"
  %l46 = alloca %"std/prelude/list:List<I64>"
  %l47 = alloca %"compiler/load:Module"
  %s0 = alloca %olang.scope
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l31
  %t2 = load { i64, ptr }, ptr %l31
  store { i64, ptr } %t2, ptr %l4
  %t3 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t3, ptr %l32
  %t4 = load { i64, ptr }, ptr %l32
  store { i64, ptr } %t4, ptr %l5
  %t5 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t5, ptr %l33
  %t6 = load { i64, ptr }, ptr %l33
  store { i64, ptr } %t6, ptr %l6
  %t7 = load i1, ptr %l3
  store i1 %t7, ptr %l34
  %t8 = load i1, ptr %l34
  store i1 %t8, ptr %l7
  store i64 -1, ptr %l8
  store ptr null, ptr %l9
  store ptr null, ptr %l10
  store { i64, ptr } zeroinitializer, ptr %l11
  %t9 = load ptr, ptr @__olang_prog_scope
  %t10 = call %"std/prelude/list:List<std/prelude/text:String&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t9)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t10, ptr %l35
  br label %bb1
bb1:
  %t11 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l35
  store %"std/prelude/list:List<std/prelude/text:String&>" %t11, ptr %l12
  %t12 = load ptr, ptr @__olang_prog_scope
  %t13 = call %"std/prelude/list:List<compiler/load:Import>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e(ptr %t12)
  store %"std/prelude/list:List<compiler/load:Import>" %t13, ptr %l36
  br label %bb2
bb2:
  %t14 = load %"std/prelude/list:List<compiler/load:Import>", ptr %l36
  store %"std/prelude/list:List<compiler/load:Import>" %t14, ptr %l13
  store ptr null, ptr %l14
  store ptr null, ptr %l15
  %t15 = load ptr, ptr @__olang_prog_scope
  %t16 = call %"std/prelude/list:List<I32>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI32_3e(ptr %t15)
  store %"std/prelude/list:List<I32>" %t16, ptr %l37
  br label %bb3
bb3:
  %t17 = load %"std/prelude/list:List<I32>", ptr %l37
  store %"std/prelude/list:List<I32>" %t17, ptr %l16
  %t18 = load ptr, ptr @__olang_prog_scope
  %t19 = call %"std/prelude/list:List<I64>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t18)
  store %"std/prelude/list:List<I64>" %t19, ptr %l38
  br label %bb4
bb4:
  %t20 = load %"std/prelude/list:List<I64>", ptr %l38
  store %"std/prelude/list:List<I64>" %t20, ptr %l17
  %t21 = load ptr, ptr @__olang_prog_scope
  %t22 = call %"std/prelude/list:List<I64>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t21)
  store %"std/prelude/list:List<I64>" %t22, ptr %l39
  br label %bb5
bb5:
  %t23 = load %"std/prelude/list:List<I64>", ptr %l39
  store %"std/prelude/list:List<I64>" %t23, ptr %l18
  %t24 = load ptr, ptr @__olang_prog_scope
  %t25 = call %"std/prelude/list:List<Bool>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cBool_3e(ptr %t24)
  store %"std/prelude/list:List<Bool>" %t25, ptr %l40
  br label %bb6
bb6:
  %t26 = load %"std/prelude/list:List<Bool>", ptr %l40
  store %"std/prelude/list:List<Bool>" %t26, ptr %l19
  %t27 = load ptr, ptr @__olang_prog_scope
  %t28 = call %"std/prelude/list:List<I64>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t27)
  store %"std/prelude/list:List<I64>" %t28, ptr %l41
  br label %bb7
bb7:
  %t29 = load %"std/prelude/list:List<I64>", ptr %l41
  store %"std/prelude/list:List<I64>" %t29, ptr %l20
  %t30 = load ptr, ptr @__olang_prog_scope
  %t31 = call %"std/prelude/list:List<I64>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t30)
  store %"std/prelude/list:List<I64>" %t31, ptr %l42
  br label %bb8
bb8:
  %t32 = load %"std/prelude/list:List<I64>", ptr %l42
  store %"std/prelude/list:List<I64>" %t32, ptr %l21
  %t33 = load ptr, ptr @__olang_prog_scope
  %t34 = call %"std/prelude/list:List<I64>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t33)
  store %"std/prelude/list:List<I64>" %t34, ptr %l43
  br label %bb9
bb9:
  %t35 = load %"std/prelude/list:List<I64>", ptr %l43
  store %"std/prelude/list:List<I64>" %t35, ptr %l22
  %t36 = load ptr, ptr @__olang_prog_scope
  %t37 = call %"std/prelude/list:List<I64>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t36)
  store %"std/prelude/list:List<I64>" %t37, ptr %l44
  br label %bb10
bb10:
  %t38 = load %"std/prelude/list:List<I64>", ptr %l44
  store %"std/prelude/list:List<I64>" %t38, ptr %l23
  %t39 = load ptr, ptr @__olang_prog_scope
  %t40 = call %"std/prelude/list:List<I64>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t39)
  store %"std/prelude/list:List<I64>" %t40, ptr %l45
  br label %bb11
bb11:
  %t41 = load %"std/prelude/list:List<I64>", ptr %l45
  store %"std/prelude/list:List<I64>" %t41, ptr %l24
  store ptr null, ptr %l25
  store ptr null, ptr %l26
  store ptr null, ptr %l27
  store i1 false, ptr %l28
  store i1 false, ptr %l29
  %t42 = load ptr, ptr @__olang_prog_scope
  %t43 = call %"std/prelude/list:List<I64>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t42)
  store %"std/prelude/list:List<I64>" %t43, ptr %l46
  br label %bb12
bb12:
  %t44 = load %"std/prelude/list:List<I64>", ptr %l46
  store %"std/prelude/list:List<I64>" %t44, ptr %l30
  %t45 = load { i64, ptr }, ptr %l4
  %t46 = insertvalue %"compiler/load:Module" undef, { i64, ptr } %t45, 0
  %t47 = load { i64, ptr }, ptr %l5
  %t48 = insertvalue %"compiler/load:Module" %t46, { i64, ptr } %t47, 1
  %t49 = load { i64, ptr }, ptr %l6
  %t50 = insertvalue %"compiler/load:Module" %t48, { i64, ptr } %t49, 2
  %t51 = load i1, ptr %l7
  %t52 = insertvalue %"compiler/load:Module" %t50, i1 %t51, 3
  %t53 = load i64, ptr %l8
  %t54 = insertvalue %"compiler/load:Module" %t52, i64 %t53, 4
  %t55 = load ptr, ptr %l9
  %t56 = insertvalue %"compiler/load:Module" %t54, ptr %t55, 5
  %t57 = load ptr, ptr %l10
  %t58 = insertvalue %"compiler/load:Module" %t56, ptr %t57, 6
  %t59 = load { i64, ptr }, ptr %l11
  %t60 = insertvalue %"compiler/load:Module" %t58, { i64, ptr } %t59, 7
  %t61 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l12
  %t62 = insertvalue %"compiler/load:Module" %t60, %"std/prelude/list:List<std/prelude/text:String&>" %t61, 8
  %t63 = load %"std/prelude/list:List<compiler/load:Import>", ptr %l13
  %t64 = insertvalue %"compiler/load:Module" %t62, %"std/prelude/list:List<compiler/load:Import>" %t63, 9
  %t65 = load ptr, ptr %l14
  %t66 = insertvalue %"compiler/load:Module" %t64, ptr %t65, 10
  %t67 = load ptr, ptr %l15
  %t68 = insertvalue %"compiler/load:Module" %t66, ptr %t67, 11
  %t69 = load %"std/prelude/list:List<I32>", ptr %l16
  %t70 = insertvalue %"compiler/load:Module" %t68, %"std/prelude/list:List<I32>" %t69, 12
  %t71 = load %"std/prelude/list:List<I64>", ptr %l17
  %t72 = insertvalue %"compiler/load:Module" %t70, %"std/prelude/list:List<I64>" %t71, 13
  %t73 = load %"std/prelude/list:List<I64>", ptr %l18
  %t74 = insertvalue %"compiler/load:Module" %t72, %"std/prelude/list:List<I64>" %t73, 14
  %t75 = load %"std/prelude/list:List<Bool>", ptr %l19
  %t76 = insertvalue %"compiler/load:Module" %t74, %"std/prelude/list:List<Bool>" %t75, 15
  %t77 = load %"std/prelude/list:List<I64>", ptr %l20
  %t78 = insertvalue %"compiler/load:Module" %t76, %"std/prelude/list:List<I64>" %t77, 16
  %t79 = load %"std/prelude/list:List<I64>", ptr %l21
  %t80 = insertvalue %"compiler/load:Module" %t78, %"std/prelude/list:List<I64>" %t79, 17
  %t81 = load %"std/prelude/list:List<I64>", ptr %l22
  %t82 = insertvalue %"compiler/load:Module" %t80, %"std/prelude/list:List<I64>" %t81, 18
  %t83 = load %"std/prelude/list:List<I64>", ptr %l23
  %t84 = insertvalue %"compiler/load:Module" %t82, %"std/prelude/list:List<I64>" %t83, 19
  %t85 = load %"std/prelude/list:List<I64>", ptr %l24
  %t86 = insertvalue %"compiler/load:Module" %t84, %"std/prelude/list:List<I64>" %t85, 20
  %t87 = load ptr, ptr %l25
  %t88 = insertvalue %"compiler/load:Module" %t86, ptr %t87, 21
  %t89 = load ptr, ptr %l26
  %t90 = insertvalue %"compiler/load:Module" %t88, ptr %t89, 22
  %t91 = load ptr, ptr %l27
  %t92 = insertvalue %"compiler/load:Module" %t90, ptr %t91, 23
  %t93 = load i1, ptr %l28
  %t94 = insertvalue %"compiler/load:Module" %t92, i1 %t93, 24
  %t95 = load i1, ptr %l29
  %t96 = insertvalue %"compiler/load:Module" %t94, i1 %t95, 25
  %t97 = load %"std/prelude/list:List<I64>", ptr %l30
  %t98 = insertvalue %"compiler/load:Module" %t96, %"std/prelude/list:List<I64>" %t97, 26
  store %"compiler/load:Module" %t98, ptr %l47
  call void @__olang_scope_close(ptr %s0)
  %t99 = load %"compiler/load:Module", ptr %l47
  store %"compiler/load:Module" %t99, ptr %out
  br label %ret
ret:
  ret void
}

define dso_local void @olang_2einit_2ecompiler_2fload() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  call void @compiler_2fload_2eNotYet_2einit()
  br label %bb1
bb1:
  call void @compiler_2fload_2ePending_2einit()
  br label %bb2
bb2:
  call void @compiler_2fload_2eNoBranch_2einit()
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

declare void @__olang_scope_close(ptr)
@.d0 = private constant [1 x i8] c"/"
@.d1 = private constant [6 x i8] c".olang"
declare void @__olang_check_failed(ptr)
@.c2 = private unnamed_addr constant [52 x i8] c"compiler/load.olang:269: slice bounds out of range\0A\00"
@.d3 = private constant [10 x i8] c"olang.lock"
@.d4 = private constant [0 x i8] c""
@.d5 = private constant [0 x i8] c""
@.d6 = private constant [0 x i8] c""
@.d7 = private constant [0 x i8] c""
@__olang_prog_scope = external thread_local(initialexec) global ptr
define linkonce_odr %"std/prelude/list:List<std/prelude/text:String&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<std/prelude/text:String&>" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l0
  store %"std/prelude/list:List<std/prelude/text:String&>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %rv
  ret %"std/prelude/list:List<std/prelude/text:String&>" %rr
}

@.d8 = private constant [1 x i8] c"/"
@.d9 = private constant [0 x i8] c""
@.d10 = private constant [1 x i8] c"."
@.d11 = private constant [2 x i8] c".."
@.d12 = private constant [2 x i8] c".."
@.d13 = private constant [1 x i8] c"/"
@.d14 = private constant [1 x i8] c"."
@.d15 = private constant [9 x i8] c"OLANG_STD"
@.d16 = private constant [0 x i8] c""
declare ptr @__olang_scope_alloc(ptr, i64)
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d17 = private constant [0 x i8] c""
declare void @__olang_sb_put(ptr, ptr, i64)
declare void @__olang_sb_done(ptr)
@.d18 = private constant [14 x i8] c"/proc/self/exe"
@.c19 = private unnamed_addr constant [50 x i8] c"compiler/load.olang:98: reached unreachable code\0A\00"
@.d20 = private constant [3 x i8] c"std"
declare ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d21 = private constant [7 x i8] c"/../std"
declare ptr @__olang_scope_alloc_a(ptr, i64, i64)
@.d22 = private constant [4 x i8] c"std/"
@.c23 = private unnamed_addr constant [51 x i8] c"compiler/load.olang:416: reached unreachable code\0A\00"
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i1 true, ptr %l2
  %t1 = load ptr, ptr %l0
  %t2 = load i32, ptr %t1
  %t3 = sext i32 %t2 to i64
  store i64 %t3, ptr %l3
  %t4 = load ptr, ptr %l1
  %t5 = load i32, ptr %t4
  %t6 = sext i32 %t5 to i64
  store i64 %t6, ptr %l4
  %t7 = load i64, ptr %l3
  %t8 = load i64, ptr %l4
  %t9 = icmp eq i64 %t7, %t8
  store i1 %t9, ptr %l5
  %t10 = load i1, ptr %l5
  br i1 %t10, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2
  br label %bb3
bb2:
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t11 = load i1, ptr %l2
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d24 = private constant [0 x i8] c""
@.c25 = private unnamed_addr constant [52 x i8] c"compiler/load.olang:440: slice bounds out of range\0A\00"
@.d26 = private constant [1 x i8] c"?"
@.c27 = private unnamed_addr constant [52 x i8] c"compiler/load.olang:448: slice bounds out of range\0A\00"
@.d28 = private constant [0 x i8] c""
@.d29 = private constant [0 x i8] c""
@.d30 = private constant [1 x i8] c"."
@.d31 = private constant [7 x i8] c"prelude"
@.c32 = private unnamed_addr constant [51 x i8] c"compiler/load.olang:145: reached unreachable code\0A\00"
@.d33 = private constant [0 x i8] c""
@.d34 = private constant [0 x i8] c""
@.d35 = private constant [0 x i8] c""
@.d36 = private constant [0 x i8] c""
@.d37 = private constant [6 x i8] c".olang"
@.c38 = private unnamed_addr constant [51 x i8] c"compiler/load.olang:151: reached unreachable code\0A\00"
@.c39 = private unnamed_addr constant [51 x i8] c"compiler/load.olang:152: reached unreachable code\0A\00"
@.c40 = private unnamed_addr constant [51 x i8] c"compiler/load.olang:154: reached unreachable code\0A\00"
@.c41 = private unnamed_addr constant [51 x i8] c"compiler/load.olang:156: reached unreachable code\0A\00"
define linkonce_odr %"std/prelude/list:List<std/pair:Pair<I64, I32>>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20I32_3e_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List<std/pair:Pair<I64, I32>>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List<std/pair:Pair<I64, I32>>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<std/pair:Pair<I64, I32>>" @std_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20I32_3e_3e_2ector(ptr %t1)
  store %"std/prelude/list:List<std/pair:Pair<I64, I32>>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/list:List<std/pair:Pair<I64, I32>>", ptr %l0
  store %"std/prelude/list:List<std/pair:Pair<I64, I32>>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List<std/pair:Pair<I64, I32>>", ptr %rv
  ret %"std/prelude/list:List<std/pair:Pair<I64, I32>>" %rr
}

@.c42 = private unnamed_addr constant [51 x i8] c"compiler/load.olang:675: reached unreachable code\0A\00"
@.c43 = private unnamed_addr constant [51 x i8] c"compiler/load.olang:678: reached unreachable code\0A\00"
@.d44 = private constant [1 x i8] c"."
define linkonce_odr %"std/prelude/list:List<I64>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List<I64>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List<I64>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<I64>" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %t1)
  store %"std/prelude/list:List<I64>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/list:List<I64>", ptr %l0
  store %"std/prelude/list:List<I64>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List<I64>", ptr %rv
  ret %"std/prelude/list:List<I64>" %rr
}

@.c45 = private unnamed_addr constant [51 x i8] c"compiler/load.olang:647: reached unreachable code\0A\00"
@.c46 = private unnamed_addr constant [51 x i8] c"compiler/load.olang:650: reached unreachable code\0A\00"
@.c47 = private unnamed_addr constant [51 x i8] c"compiler/load.olang:627: reached unreachable code\0A\00"
@.c48 = private unnamed_addr constant [51 x i8] c"compiler/load.olang:634: reached unreachable code\0A\00"
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fcond_3aOutcome(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i1 true, ptr %l2
  %t1 = load ptr, ptr %l0
  %t2 = load i32, ptr %t1
  %t3 = sext i32 %t2 to i64
  store i64 %t3, ptr %l3
  %t4 = load ptr, ptr %l1
  %t5 = load i32, ptr %t4
  %t6 = sext i32 %t5 to i64
  store i64 %t6, ptr %l4
  %t7 = load i64, ptr %l3
  %t8 = load i64, ptr %l4
  %t9 = icmp eq i64 %t7, %t8
  store i1 %t9, ptr %l5
  %t10 = load i1, ptr %l5
  br i1 %t10, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2
  br label %bb3
bb2:
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t11 = load i1, ptr %l2
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d49 = private constant [0 x i8] c""
@.c50 = private unnamed_addr constant [52 x i8] c"compiler/load.olang:251: slice bounds out of range\0A\00"
@.c51 = private unnamed_addr constant [52 x i8] c"compiler/load.olang:256: slice bounds out of range\0A\00"
@.d52 = private constant [0 x i8] c""
@.d53 = private constant [0 x i8] c""
@.d54 = private constant [0 x i8] c""
@.c55 = private unnamed_addr constant [51 x i8] c"compiler/load.olang:183: reached unreachable code\0A\00"
@.d56 = private constant [0 x i8] c""
@.d57 = private constant [4 x i8] c"std/"
@.c58 = private unnamed_addr constant [51 x i8] c"compiler/load.olang:665: reached unreachable code\0A\00"
@.d59 = private constant [0 x i8] c""
@.c60 = private unnamed_addr constant [51 x i8] c"compiler/load.olang:666: reached unreachable code\0A\00"
@.d61 = private constant [0 x i8] c""
@.d62 = private constant [0 x i8] c""
@.d63 = private constant [5 x i8] c"Array"
@.d64 = private constant [0 x i8] c""
@.c65 = private unnamed_addr constant [51 x i8] c"compiler/load.olang:206: reached unreachable code\0A\00"
@.d66 = private constant [6 x i8] c".olang"
@.c67 = private unnamed_addr constant [52 x i8] c"compiler/load.olang:501: slice bounds out of range\0A\00"
@.d68 = private constant [0 x i8] c""
@.d69 = private constant [0 x i8] c""
@.d70 = private constant [4 x i8] c"std/"
@.d71 = private constant [1 x i8] c"."
@.c72 = private unnamed_addr constant [52 x i8] c"compiler/load.olang:505: slice bounds out of range\0A\00"
@.d73 = private constant [1 x i8] c"/"
@.d74 = private constant [6 x i8] c".olang"
@.d75 = private constant [4 x i8] c"std/"
@.d76 = private constant [3 x i8] c"std"
@.d77 = private constant [1 x i8] c"."
@.d78 = private constant [2 x i8] c".."
@.d79 = private constant [1 x i8] c"/"
@.d80 = private constant [0 x i8] c""
@.d81 = private constant [0 x i8] c""
@.d82 = private constant [0 x i8] c""
@.d83 = private constant [0 x i8] c""
@.d84 = private constant [0 x i8] c""
@.d85 = private constant [6 x i8] c".olang"
@.d86 = private constant [1 x i8] c"/"
@.d87 = private constant [1 x i8] c"/"
@.d88 = private constant [1 x i8] c"."
@.d89 = private constant [6 x i8] c".olang"
@.d90 = private constant [1 x i8] c"/"
@.d91 = private constant [6 x i8] c".olang"
@.d92 = private constant [1 x i8] c"/"
@.d93 = private constant [0 x i8] c""
@.c94 = private unnamed_addr constant [52 x i8] c"compiler/load.olang:548: slice bounds out of range\0A\00"
@.d95 = private constant [1 x i8] c"."
@.d96 = private constant [1 x i8] c"."
@.d97 = private constant [2 x i8] c".."
@.d98 = private constant [4 x i8] c"std/"
@.d99 = private constant [3 x i8] c"std"
@.d100 = private constant [1 x i8] c"/"
@.d101 = private constant [0 x i8] c""
@.d102 = private constant [1 x i8] c"/"
@.d103 = private constant [0 x i8] c""
@.d104 = private constant [0 x i8] c""
@.d105 = private constant [0 x i8] c""
@.d106 = private constant [0 x i8] c""
@.d107 = private constant [1 x i8] c"/"
@.d108 = private constant [1 x i8] c"/"
@.c109 = private unnamed_addr constant [52 x i8] c"compiler/load.olang:132: slice bounds out of range\0A\00"
@.d110 = private constant [4 x i8] c"std/"
@.c111 = private unnamed_addr constant [52 x i8] c"compiler/load.olang:135: slice bounds out of range\0A\00"
@.d112 = private constant [0 x i8] c""
@.d113 = private constant [6 x i8] c".olang"
@.c114 = private unnamed_addr constant [52 x i8] c"compiler/load.olang:138: slice bounds out of range\0A\00"
@.c115 = private unnamed_addr constant [52 x i8] c"compiler/load.olang:575: slice bounds out of range\0A\00"
@.c116 = private unnamed_addr constant [52 x i8] c"compiler/load.olang:578: slice bounds out of range\0A\00"
@.d117 = private constant [1 x i8] c"/"
@.d118 = private constant [1 x i8] c"/"
@.d119 = private constant [1 x i8] c"/"
@.d120 = private constant [1 x i8] c"."
@.d121 = private constant [1 x i8] c"/"
@.c122 = private unnamed_addr constant [52 x i8] c"compiler/load.olang:585: slice bounds out of range\0A\00"
@.d123 = private constant [1 x i8] c"/"
@.c124 = private unnamed_addr constant [52 x i8] c"compiler/load.olang:592: slice bounds out of range\0A\00"
@.d125 = private constant [1 x i8] c"/"
@.c126 = private unnamed_addr constant [52 x i8] c"compiler/load.olang:167: slice bounds out of range\0A\00"
define linkonce_odr %"std/prelude/list:List<mut compiler/load:Module&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List<mut compiler/load:Module&>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List<mut compiler/load:Module&>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<mut compiler/load:Module&>" @std_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List<mut compiler/load:Module&>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/list:List<mut compiler/load:Module&>", ptr %l0
  store %"std/prelude/list:List<mut compiler/load:Module&>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List<mut compiler/load:Module&>", ptr %rv
  ret %"std/prelude/list:List<mut compiler/load:Module&>" %rr
}

@.d127 = private constant [0 x i8] c""
@.d128 = private constant [0 x i8] c""
define linkonce_odr %"std/prelude/list:List<compiler/load:Import>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List<compiler/load:Import>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List<compiler/load:Import>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<compiler/load:Import>" @std_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2ector(ptr %t1)
  store %"std/prelude/list:List<compiler/load:Import>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/list:List<compiler/load:Import>", ptr %l0
  store %"std/prelude/list:List<compiler/load:Import>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List<compiler/load:Import>", ptr %rv
  ret %"std/prelude/list:List<compiler/load:Import>" %rr
}

define linkonce_odr %"std/prelude/list:List<I32>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI32_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List<I32>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List<I32>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<I32>" @std_2fprelude_2flist_3aList_3cI32_3e_2ector(ptr %t1)
  store %"std/prelude/list:List<I32>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/list:List<I32>", ptr %l0
  store %"std/prelude/list:List<I32>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List<I32>", ptr %rv
  ret %"std/prelude/list:List<I32>" %rr
}

define linkonce_odr %"std/prelude/list:List<Bool>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cBool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List<Bool>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List<Bool>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<Bool>" @std_2fprelude_2flist_3aList_3cBool_3e_2ector(ptr %t1)
  store %"std/prelude/list:List<Bool>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/list:List<Bool>", ptr %l0
  store %"std/prelude/list:List<Bool>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List<Bool>", ptr %rv
  ret %"std/prelude/list:List<Bool>" %rr
}

declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2ffilepath_2eDir(ptr %v0, { i64, ptr } %a0)
declare { i64, ptr } @std_2ffilepath_2eJoin(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4, { i64, ptr } %a5)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hd1f680ecc7a3e4b4dd91667eaf6a5223(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %a0)
declare { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fos_2eReadLink(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2eLen_3cI32_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2eAt_3cI32_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fdiag_3aDiagnostics_2ector(ptr %out, ptr %v0, i1 %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAddFile(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3)
declare void @compiler_2fparse_3aParser_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, i64 %a5)
declare %"compiler/cond:Scope" @compiler_2fcond_3aScope_2ector(ptr %v0, i1 %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eExprAt(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ePos(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare %"compiler/cond:Global" @compiler_2fcond_3aGlobal_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, %"compiler/source:Span" %a1, i1 %a2, { i64, ptr } %a3, ptr %a4, i1 %a5)
declare void @compiler_2fcond_2ecompiler_2fcond_3aScope_2eAdd(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v0, ptr %a0)
declare { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fos_2eCwd(ptr %v0)
declare i1 @std_2fos_2eIsDir(ptr %v0, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eIsDirectory(ptr %v0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v0, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/scan:Tokens" @compiler_2fscan_2eScan(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/pair:Pair<I64, I32>" @std_2fpair_3aPair_3cI64_2c_20I32_3e_2ector(ptr %v0, i64 %a0, i32 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20I32_3e_Hd7be20793e0d40c909f29debacc96a43(ptr %v0, ptr %a0, %"std/pair:Pair<I64, I32>" %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eChoose(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eDrop(ptr %v0, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2eRunFrom_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fparse_2ecompiler_2fparse_3aOracle_2eAdd(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportReachedTwice(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReexportCycle(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2fscan_2ecompiler_2fscan_3aTokens_2eMatch(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/cond:Eval" @compiler_2fcond_3aEval_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, ptr %a1, ptr %a2, ptr %a3)
declare { i32, i1 } @compiler_2fcond_2ecompiler_2fcond_3aEval_2eTop(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { %"compiler/source:Span", %"compiler/msgs:Msg" } @compiler_2fcond_2ecompiler_2fcond_3aEval_2eError(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2ePush_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/load:Import" %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H4773d10fc8d77771a2093e7ac76ab6ea(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, %"compiler/source:Source" } @compiler_2fsource_2eRead(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %v0)
declare { i32, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H78ccce95e6ef2f62693281865bce11fb(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2fscan_2ecompiler_2fscan_3aDiag_2eRule(ptr %v0, %"compiler/scan:Diag" %a0)
declare { i64, ptr } @compiler_2fscan_2ecompiler_2fscan_3aDiag_2eMessage(ptr %v0, %"compiler/scan:Diag" %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"compiler/parse:Oracle" @compiler_2fparse_3aOracle_2ector(ptr %v0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2eLen_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %a0)
declare %"compiler/load:Import" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2eAt_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2eSetAt_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/load:Import" %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportAliasInvalid(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportAliasConflict(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eFile(ptr %v0, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportPathTooLong(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportHasExtension(ptr %v0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %a0, i8 %a1)
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportLeavesRoot(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportRemoteNeedsFile(ptr %v0)
declare { i32, { i64, ptr } } @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2eFetch(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportRemoteBadName(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportLockNotACommit(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportFetchFailed(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportLockedFetchFailed(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2ffilepath_2eBase(ptr %v0, { i64, ptr } %a0)
declare i1 @std_2fos_2eExists(ptr %v0, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportFileNotFound(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2ePush_3cI32_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare %"std/prelude/list:List<std/prelude/text:String&>" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List<std/pair:Pair<I64, I32>>" @std_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20I32_3e_3e_2ector(ptr %v0)
declare %"std/prelude/list:List<I64>" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
declare %"std/prelude/list:List<mut compiler/load:Module&>" @std_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List<compiler/load:Import>" @std_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2ector(ptr %v0)
declare %"std/prelude/list:List<I32>" @std_2fprelude_2flist_3aList_3cI32_3e_2ector(ptr %v0)
declare %"std/prelude/list:List<Bool>" @std_2fprelude_2flist_3aList_3cBool_3e_2ector(ptr %v0)
attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
