; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr } }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, ptr, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/diag:Diagnostics" = type { i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, [3 x i64] }, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/parse:Parser" = type { ptr, ptr, ptr, ptr, ptr, i64, i64, i32, i32, i32, i32, i1, i1, i1, i1, i64, i1, i1, i64, i1, i64, i1, i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/cond:Scope" = type { i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/cond:Global" = type { { i64, ptr }, %"compiler/source:Span", i1, { i64, ptr }, ptr, i1 }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/scan:Tokens" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/token:Token" = type { i32, i8, i32, i32 }
%"compiler/load:Import" = type { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, { i64, ptr }, i64, i64 }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" = type { i64, i32 }
%"compiler/ast:TopBranch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/ast:TopIf" = type { ptr, ptr, ptr, ptr }
%"compiler/cond:Eval" = type { { i64, ptr }, ptr, ptr, ptr, i1, i1, i1, %"compiler/source:Span", %"compiler/msgs:Msg", i64, i64, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/scan:Diag" = type { i32, i32, i32, i8 }
%"compiler/parse:Oracle" = type { %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/os:Output" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/diag:Said" = type { { i64, ptr }, i64, i64, { i64, ptr } }
%"compiler/cond:Consts" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/fetch:Fetcher" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/source:Names" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
@G_2ecompiler_2fload_2eNoBranch = constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2fload_2eNotYet = constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2fload_2ePending = constant <{ [8 x i8] }> <{ [8 x i8] c"\FD\FF\FF\FF\FF\FF\FF\FF" }>, align 8
define dso_local i1 @compiler_2fload_2eAliasShape(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i8
  %l8 = alloca i1
  %l9 = alloca { i64, ptr }
  %l11 = alloca i1
  %l12 = alloca i1
  %l13 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l29 = alloca i1
  %l30 = alloca i1
  %l32 = alloca i1
  %l33 = alloca i1
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb7
bb2:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t7, ptr %l9, !tbaa !27
  %t8 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !27
  %t10 = getelementptr i8, ptr %t9, i64 0
  %t11 = load i8, ptr %t10, !tbaa !32
  %t13 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t11)
  store i1 %t13, ptr %l11
  br label %bb3
bb3:
  %t14 = load i1, ptr %l11, !tbaa !21
  br i1 %t14, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb6
bb5:
  %t15 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t15, ptr %l13, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr i8, ptr %t17, i64 0
  %t19 = load i8, ptr %t18, !tbaa !32
  %t21 = icmp eq i8 %t19, 95
  store i1 %t21, ptr %l12, !tbaa !21
  br label %bb6
bb6:
  %t23 = load i1, ptr %l12, !tbaa !21
  %t24 = xor i1 %t23, true
  store i1 %t24, ptr %l8, !tbaa !21
  br label %bb7
bb7:
  %t26 = load i1, ptr %l8, !tbaa !21
  br i1 %t26, label %bb8, label %bb9
bb8:
  store i1 false, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t28 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t28, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t30 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t30, 0
  store i64 %t32, ptr %l3, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t34 = load i64, ptr %l2, !tbaa !24
  %t35 = load i64, ptr %l3, !tbaa !24
  %t38 = icmp slt i64 %t34, %t35
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb27
bb13:
  br label %bb14
bb14:
  %t42 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t42, ptr %l25, !tbaa !27
  %t43 = load i64, ptr %l2, !tbaa !24
  %t45 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr i8, ptr %t46, i64 %t43
  %t48 = load i8, ptr %t47, !tbaa !32
  store i8 %t48, ptr %l4, !tbaa !22
  %t50 = load i8, ptr %l4, !tbaa !22
  %t52 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t50)
  store i1 %t52, ptr %l29
  br label %bb15
bb15:
  %t53 = load i1, ptr %l29, !tbaa !21
  br i1 %t53, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb19
bb17:
  %t54 = load i8, ptr %l4, !tbaa !22
  %t56 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t54)
  store i1 %t56, ptr %l32
  br label %bb18
bb18:
  %t57 = load i1, ptr %l32, !tbaa !21
  store i1 %t57, ptr %l30, !tbaa !21
  br label %bb19
bb19:
  %t58 = load i1, ptr %l30, !tbaa !21
  br i1 %t58, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb22
bb21:
  %t59 = load i8, ptr %l4, !tbaa !22
  %t61 = icmp eq i8 %t59, 95
  store i1 %t61, ptr %l33, !tbaa !21
  br label %bb22
bb22:
  %t63 = load i1, ptr %l33, !tbaa !21
  %t64 = xor i1 %t63, true
  br i1 %t64, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s3)
  store i1 false, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s3)
  br label %bb26
bb26:
  %t67 = load i64, ptr %l2, !tbaa !24
  %t69 = add i64 %t67, 1
  store i64 %t69, ptr %l2, !tbaa !24
  br label %bb11
bb27:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fload_2eDeriveAlias(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l14 = alloca i1
  %l16 = alloca i1
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 1, ptr @.d0 })
  %t4 = extractvalue { i32, i64 } %t3, 1
  %t5 = extractvalue { i32, i64 } %t3, 0
  store i32 %t5, ptr %l6
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store i64 %t4, ptr %l5
  br label %bb1
bb1:
  %t8 = load i64, ptr %l5, !tbaa !24
  store i64 %t8, ptr %l3, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 -1, ptr %l3, !tbaa !24
  br label %bb4
bb4:
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = add i64 %t9, 1
  store i64 %t10, ptr %l1, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  store i64 %t14, ptr %l2, !tbaa !24
  %t16 = load i64, ptr %l2, !tbaa !24
  %t17 = load i64, ptr %l1, !tbaa !24
  %t20 = sub i64 %t16, %t17
  %t22 = icmp sge i64 %t20, 6
  br i1 %t22, label %bb5, label %bb6
bb5:
  %t24 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t26 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %s0, { i64, ptr } %t24, { i64, ptr } { i64 6, ptr @.d1 })
  store i1 %t26, ptr %l16
  br label %bb7
bb6:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb8
bb7:
  %t27 = load i1, ptr %l16, !tbaa !21
  store i1 %t27, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t28 = load i1, ptr %l14, !tbaa !21
  br i1 %t28, label %bb9, label %bb10
bb9:
  %t29 = load i64, ptr %l2, !tbaa !24
  %t31 = sub i64 %t29, 6
  store i64 %t31, ptr %l2, !tbaa !24
  br label %bb11
bb10:
  br label %bb11
bb11:
  %t33 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t33, ptr %l19, !tbaa !27
  %t34 = load i64, ptr %l1, !tbaa !24
  store i64 %t34, ptr %l20, !tbaa !24
  %t35 = load i64, ptr %l2, !tbaa !24
  store i64 %t35, ptr %l21, !tbaa !24
  %t36 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t36, 0
  store i64 %t37, ptr %l22, !tbaa !24
  %t38 = load i64, ptr %l20, !tbaa !24
  %t39 = icmp sge i64 %t38, 0
  br i1 %t39, label %bb12, label %bb13
bb12:
  %t41 = load i64, ptr %l20, !tbaa !24
  %t42 = load i64, ptr %l21, !tbaa !24
  %t43 = icmp sle i64 %t41, %t42
  br i1 %t43, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_30f594fd977814cf_401937ed3e69cedb)
  unreachable
bb14:
  %t45 = load i64, ptr %l21, !tbaa !24
  %t46 = load i64, ptr %l22, !tbaa !24
  %t47 = icmp sle i64 %t45, %t46
  br i1 %t47, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_30f594fd977814cf_401937ed3e69cedb)
  unreachable
bb16:
  %t49 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = load i64, ptr %l20, !tbaa !24
  %t52 = load i64, ptr %l21, !tbaa !24
  %t53 = getelementptr i8, ptr %t50, i64 %t51
  %t54 = sub i64 %t52, %t51
  %t55 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t53, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t56, ptr %rv
  br label %ret
bb17:
  call void @__olang_check_failed(ptr @olang_loc_30f594fd977814cf_401937ed3e69cedb)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fload_2eLockPath(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call { i64, ptr } @std_2ffilepath_2eDir(ptr %v0, { i64, ptr } %a0)
  store { i64, ptr } %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %v0, ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t4, { i64, ptr } { i64 10, ptr @.d2 }, { i64, ptr } { i64 0, ptr @.d3 }, { i64, ptr } { i64 0, ptr @.d4 }, { i64, ptr } { i64 0, ptr @.d5 }, { i64, ptr } { i64 0, ptr @.d6 })
  store { i64, ptr } %t5, ptr %l3
  br label %bb2
bb2:
  %t6 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t6, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fload_2eNoBranch_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 -1, ptr @G_2ecompiler_2fload_2eNoBranch, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fload_2eNormalize(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l15 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l26 = alloca i1
  %l27 = alloca i1
  %l29 = alloca i1
  %l31 = alloca i1
  %l32 = alloca i1
  %l34 = alloca i64
  %l36 = alloca i1
  %l37 = alloca ptr
  %l39 = alloca i64
  %l41 = alloca { i64, ptr }
  %l42 = alloca i1
  %l44 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l47 = alloca i32
  %l52 = alloca %"std/prelude/text:StringBuilder"
  %l54 = alloca i1
  %l57 = alloca i64
  %l61 = alloca i64
  %l64 = alloca i64
  %l85 = alloca ptr
  %l88 = alloca { i64, ptr }
  %l92 = alloca i64
  %l94 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %l100 = alloca i64
  %l101 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l13
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l1
  store %olang.scope zeroinitializer, ptr %s1
  %t4 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t6 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %s1, { i64, ptr } %t4, { i64, ptr } { i64 1, ptr @.d7 })
  store { i64, ptr } %t6, ptr %l15
  br label %bb2
bb2:
  %t7 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t8 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  store i64 %t10, ptr %l4, !tbaa !24
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = load i64, ptr %l4, !tbaa !24
  %t16 = icmp slt i64 %t12, %t13
  %t18 = xor i1 %t16, true
  br i1 %t18, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb35
bb5:
  br label %bb6
bb6:
  %t20 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t20, ptr %l22, !tbaa !27
  %t21 = load i64, ptr %l3, !tbaa !24
  %t23 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr { i64, ptr }, ptr %t24, i64 %t21
  %t26 = load { i64, ptr }, ptr %t25, !tbaa !37
  store { i64, ptr } %t26, ptr %l5, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t30 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t28, { i64, ptr } { i64 0, ptr @.d8 })
  store i1 %t30, ptr %l26
  br label %bb7
bb7:
  %t31 = load i1, ptr %l26, !tbaa !21
  br i1 %t31, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb11
bb9:
  %t32 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t34 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t32, { i64, ptr } { i64 1, ptr @.d9 })
  store i1 %t34, ptr %l29
  br label %bb10
bb10:
  %t35 = load i1, ptr %l29, !tbaa !21
  store i1 %t35, ptr %l27, !tbaa !21
  br label %bb11
bb11:
  %t36 = load i1, ptr %l27, !tbaa !21
  br i1 %t36, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb34
bb13:
  br label %bb14
bb14:
  %t37 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t39 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t37, { i64, ptr } { i64 2, ptr @.d10 })
  store i1 %t39, ptr %l31
  br label %bb15
bb15:
  %t40 = load i1, ptr %l31, !tbaa !21
  br i1 %t40, label %bb16, label %bb17
bb16:
  %t42 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %s0, ptr %l1)
  store i64 %t42, ptr %l34
  br label %bb18
bb17:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb19
bb18:
  %t43 = load i64, ptr %l34, !tbaa !24
  %t44 = icmp sgt i64 %t43, 0
  store i1 %t44, ptr %l32, !tbaa !21
  br label %bb19
bb19:
  %t46 = load i1, ptr %l32, !tbaa !21
  br i1 %t46, label %bb20, label %bb21
bb20:
  store ptr %l1, ptr %l37, !tbaa !29
  %t48 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %s0, ptr %l1)
  store i64 %t48, ptr %l39
  br label %bb22
bb21:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb25
bb22:
  %t49 = load i64, ptr %l39, !tbaa !24
  %t50 = sub i64 %t49, 1
  %t51 = load ptr, ptr %l37, !tbaa !29
  %t53 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %s0, ptr %s0, ptr %t51, i64 %t50)
  store { i64, ptr } %t53, ptr %l41
  br label %bb23
bb23:
  %t54 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t55 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s2, { i64, ptr } %t54, { i64, ptr } { i64 2, ptr @.d11 })
  store i1 %t55, ptr %l42
  br label %bb24
bb24:
  %t56 = load i1, ptr %l42, !tbaa !21
  %t57 = xor i1 %t56, true
  store i1 %t57, ptr %l36, !tbaa !21
  br label %bb25
bb25:
  %t59 = load i1, ptr %l36, !tbaa !21
  br i1 %t59, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s4
  %t61 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hd1f680ecc7a3e4b4dd91667eaf6a5223(ptr %s0, ptr %s4, ptr %l1)
  %t62 = extractvalue { i32, { i64, ptr } } %t61, 1
  %t63 = extractvalue { i32, { i64, ptr } } %t61, 0
  store i32 %t63, ptr %l47
  %t64 = icmp ne i32 %t63, 0
  br i1 %t64, label %bb29, label %ok.65
ok.65:
  store { i64, ptr } %t62, ptr %l46
  br label %bb28
bb27:
  br label %bb32
bb28:
  %t66 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t66, ptr %l44, !tbaa !27
  br label %bb31
bb29:
  br label %bb30
bb30:
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  br label %bb34
bb32:
  %t67 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %v0, ptr %l1, { i64, ptr } %t67)
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s2)
  br label %bb34
bb34:
  %t70 = load i64, ptr %l3, !tbaa !24
  %t72 = add i64 %t70, 1
  store i64 %t72, ptr %l3, !tbaa !24
  br label %bb3
bb35:
  call void @__olang_scope_close(ptr %s1)
  %t74 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t74, ptr %l52
  br label %bb36
bb36:
  %t75 = load %"std/prelude/text:StringBuilder", ptr %l52
  store %"std/prelude/text:StringBuilder" %t75, ptr %l6
  %t76 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t78 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t76, { i64, ptr } { i64 1, ptr @.d12 })
  store i1 %t78, ptr %l54
  br label %bb37
bb37:
  %t79 = load i1, ptr %l54, !tbaa !21
  br i1 %t79, label %bb38, label %bb39
bb38:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l6, i8 47)
  br label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb41
bb41:
  store i64 0, ptr %l7, !tbaa !24
  %t82 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %s0, ptr %l1)
  store i64 %t82, ptr %l57
  br label %bb42
bb42:
  %t83 = load i64, ptr %l57, !tbaa !24
  store i64 %t83, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t84 = load i64, ptr %l8, !tbaa !24
  %t85 = load i64, ptr %l7, !tbaa !24
  %t88 = icmp sgt i64 %t84, %t85
  br i1 %t88, label %bb43, label %bb44
bb43:
  %t90 = load i64, ptr %l9, !tbaa !24
  %t92 = icmp sgt i64 %t90, 0
  br i1 %t92, label %bb45, label %bb46
bb44:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb48
bb45:
  %t94 = load i64, ptr %l8, !tbaa !24
  %t95 = load i64, ptr %l7, !tbaa !24
  %t98 = sub i64 %t94, %t95
  %t99 = load i64, ptr %l9, !tbaa !24
  %t102 = add i64 %t98, %t99
  %t104 = sub i64 %t102, 1
  %t105 = load i64, ptr %l9, !tbaa !24
  %t108 = sdiv i64 %t104, %t105
  store i64 %t108, ptr %l64, !tbaa !24
  br label %bb47
bb46:
  store i64 0, ptr %l64, !tbaa !24
  br label %bb47
bb47:
  %t110 = load i64, ptr %l64, !tbaa !24
  store i64 %t110, ptr %l61, !tbaa !24
  br label %bb48
bb48:
  %t111 = load i64, ptr %l61, !tbaa !24
  store i64 %t111, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb49
bb49:
  store %olang.scope zeroinitializer, ptr %s9
  %t112 = load i64, ptr %l11, !tbaa !24
  %t113 = load i64, ptr %l10, !tbaa !24
  %t116 = icmp slt i64 %t112, %t113
  %t118 = xor i1 %t116, true
  br i1 %t118, label %bb50, label %bb51
bb50:
  call void @__olang_scope_close(ptr %s9)
  br label %bb60
bb51:
  br label %bb52
bb52:
  %t120 = load i64, ptr %l7, !tbaa !24
  %t121 = load i64, ptr %l11, !tbaa !24
  %t122 = load i64, ptr %l9, !tbaa !24
  %t125 = mul i64 %t121, %t122
  %t128 = add i64 %t120, %t125
  store i64 %t128, ptr %l12, !tbaa !24
  %t130 = load i64, ptr %l12, !tbaa !24
  %t132 = icmp sgt i64 %t130, 0
  br i1 %t132, label %bb53, label %bb54
bb53:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l6, i8 47)
  br label %bb55
bb54:
  br label %bb56
bb55:
  br label %bb56
bb56:
  store ptr %l6, ptr %l85, !tbaa !29
  %t135 = load i64, ptr %l12, !tbaa !24
  %t138 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %s0, ptr %s0, ptr %l1, i64 %t135)
  store { i64, ptr } %t138, ptr %l88
  br label %bb57
bb57:
  %t139 = load ptr, ptr %l85, !tbaa !29
  %t140 = load { i64, ptr }, ptr %l88, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t139, { i64, ptr } %t140)
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s9)
  br label %bb59
bb59:
  %t141 = load i64, ptr %l11, !tbaa !24
  %t143 = add i64 %t141, 1
  store i64 %t143, ptr %l11, !tbaa !24
  br label %bb49
bb60:
  %t146 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %s0, ptr %l6)
  store i64 %t146, ptr %l92
  br label %bb61
bb61:
  %t147 = load i64, ptr %l92, !tbaa !24
  %t148 = icmp eq i64 %t147, 0
  br i1 %t148, label %bb62, label %bb63
bb62:
  store { i64, ptr } { i64 1, ptr @.d13 }, ptr %l95, !tbaa !27
  %t150 = load { i64, ptr }, ptr %l95, !tbaa !27
  store { i64, ptr } %t150, ptr %l94, !tbaa !27
  br label %bb65
bb63:
  %t153 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l6)
  store { i64, ptr } %t153, ptr %l98
  br label %bb64
bb64:
  %t154 = load { i64, ptr }, ptr %l98, !tbaa !27
  store { i64, ptr } %t154, ptr %l94, !tbaa !27
  br label %bb65
bb65:
  %t156 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t157 = extractvalue { i64, ptr } %t156, 0
  store i64 %t157, ptr %l100, !tbaa !24
  %t158 = load i64, ptr %l100, !tbaa !24
  %t159 = mul i64 %t158, 1
  %t160 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t159)
  %t161 = insertvalue { i64, ptr } undef, i64 %t158, 0
  %t162 = insertvalue { i64, ptr } %t161, ptr %t160, 1
  store { i64, ptr } %t162, ptr %l101, !tbaa !27
  %t163 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t164 = load ptr, ptr %t163, !tbaa !27
  %t165 = getelementptr { i64, ptr }, ptr %l94, i32 0, i32 1
  %t166 = load ptr, ptr %t165, !tbaa !27
  %t167 = load i64, ptr %l100, !tbaa !24
  %t168 = mul i64 %t167, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t164, ptr %t166, i64 %t168, i1 false)
  %t169 = load { i64, ptr }, ptr %l101, !tbaa !27
  store { i64, ptr } %t169, ptr %l94, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t170 = load { i64, ptr }, ptr %l94, !tbaa !27
  store { i64, ptr } %t170, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fload_2eNotYet_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 -2, ptr @G_2ecompiler_2fload_2eNotYet, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fload_2ePending_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 -3, ptr @G_2ecompiler_2fload_2ePending, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fload_2ePublic(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca { i64, ptr }
  %l7 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp sgt i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t7, ptr %l5, !tbaa !27
  %t8 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !27
  %t10 = getelementptr i8, ptr %t9, i64 0
  %t11 = load i8, ptr %t10, !tbaa !32
  %t13 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t11)
  store i1 %t13, ptr %l7
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb4
bb3:
  %t14 = load i1, ptr %l7, !tbaa !21
  store i1 %t14, ptr %l4, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l4, !tbaa !21
  store i1 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fload_2eStdDir(ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l9 = alloca i1
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i32
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 9, ptr @.d14 })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l4
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  store { i64, ptr } %t2, ptr %l3
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  br label %bb4
bb2:
  br label %bb3
bb3:
  store { i64, ptr } { i64 0, ptr @.d15 }, ptr %l5, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t10 = extractvalue { i64, ptr } %t7, 1
  %t11 = mul i64 %t9, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t10, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l2, !tbaa !27
  br label %bb4
bb4:
  %t16 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t16, ptr %l0, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t19 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t17, { i64, ptr } { i64 0, ptr @.d16 })
  store i1 %t19, ptr %l9
  br label %bb5
bb5:
  %t20 = load i1, ptr %l9, !tbaa !21
  %t21 = xor i1 %t20, true
  br i1 %t21, label %bb6, label %bb7
bb6:
  %t23 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 1
  %t26 = extractvalue { i64, ptr } %t23, 0
  %t27 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t25, i64 %t26)
  %t28 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t29, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t31 = call { i32, { i64, ptr } } @std_2fos_2eReadLink(ptr %s0, ptr %s0, { i64, ptr } { i64 14, ptr @.d17 })
  %t32 = extractvalue { i32, { i64, ptr } } %t31, 1
  %t33 = extractvalue { i32, { i64, ptr } } %t31, 0
  store i32 %t33, ptr %l15
  %t34 = icmp ne i32 %t33, 0
  br i1 %t34, label %bb10, label %ok.35
ok.35:
  store { i64, ptr } %t32, ptr %l14
  br label %bb9
bb9:
  %t36 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t36, ptr %l13, !tbaa !27
  br label %bb14
bb10:
  %t37 = load i32, ptr %l15, !tbaa !23
  %t38 = ashr i32 %t37, 16
  %t40 = icmp eq i32 %t38, 1
  br i1 %t40, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_dd45d0afc1e93de5_b21ed3f58d77ee79)
  unreachable
bb13:
  store { i64, ptr } { i64 3, ptr @.d18 }, ptr %l18, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t42, ptr %l19, !tbaa !27
  %t43 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t43, 0
  store i64 %t44, ptr %l20, !tbaa !24
  %t45 = load i64, ptr %l20, !tbaa !24
  %t46 = mul i64 %t45, 1
  %t47 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t46)
  %t48 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t47, 1
  store { i64, ptr } %t49, ptr %l21, !tbaa !27
  %t50 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = load i64, ptr %l20, !tbaa !24
  %t55 = mul i64 %t54, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t51, ptr %t53, i64 %t55, i1 false)
  %t56 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t56, ptr %l19, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t57 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t57, ptr %rv
  br label %ret
bb14:
  %t58 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t61 = call { i64, ptr } @std_2ffilepath_2eDir(ptr %s0, { i64, ptr } %t58)
  store { i64, ptr } %t61, ptr %l23
  br label %bb15
bb15:
  %t62 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t62, 1
  %t64 = extractvalue { i64, ptr } %t62, 0
  %t65 = extractvalue { i64, ptr } { i64 7, ptr @.d19 }, 1
  %t66 = extractvalue { i64, ptr } { i64 7, ptr @.d19 }, 0
  %t67 = add i64 %t64, %t66
  %t68 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t67)
  call void @olang_textcopy(ptr %t68, ptr %t63, i64 %t64)
  %t69 = getelementptr i8, ptr %t68, i64 %t64
  call void @olang_textcopy(ptr %t69, ptr %t65, i64 %t66)
  %t70 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t68, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t71, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eChosen(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l13 = alloca ptr
  %l16 = alloca i64
  %l20 = alloca i64
  %l23 = alloca i64
  %l44 = alloca i32
  %l53 = alloca i64
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/load:Loader", ptr %t1, i32 0, i32 5
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l13
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l13, !tbaa !29
  store ptr %t8, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t11 = getelementptr %"compiler/load:Module", ptr %t9, i32 0, i32 14
  %t13 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2eLen_3cI32_3e(ptr %v0, ptr %t11)
  store i64 %t13, ptr %l16
  br label %bb2
bb2:
  %t14 = load i64, ptr %l16, !tbaa !24
  store i64 %t14, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t15 = load i64, ptr %l5, !tbaa !24
  %t16 = load i64, ptr %l4, !tbaa !24
  %t19 = icmp sgt i64 %t15, %t16
  br i1 %t19, label %bb3, label %bb4
bb3:
  %t21 = load i64, ptr %l6, !tbaa !24
  %t23 = icmp sgt i64 %t21, 0
  br i1 %t23, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb8
bb5:
  %t25 = load i64, ptr %l5, !tbaa !24
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = sub i64 %t25, %t26
  %t30 = load i64, ptr %l6, !tbaa !24
  %t33 = add i64 %t29, %t30
  %t35 = sub i64 %t33, 1
  %t36 = load i64, ptr %l6, !tbaa !24
  %t39 = sdiv i64 %t35, %t36
  store i64 %t39, ptr %l23, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb7
bb7:
  %t41 = load i64, ptr %l23, !tbaa !24
  store i64 %t41, ptr %l20, !tbaa !24
  br label %bb8
bb8:
  %t42 = load i64, ptr %l20, !tbaa !24
  store i64 %t42, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t43 = load i64, ptr %l8, !tbaa !24
  %t44 = load i64, ptr %l7, !tbaa !24
  %t47 = icmp slt i64 %t43, %t44
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb11:
  br label %bb12
bb12:
  %t51 = load i64, ptr %l4, !tbaa !24
  %t52 = load i64, ptr %l8, !tbaa !24
  %t53 = load i64, ptr %l6, !tbaa !24
  %t56 = mul i64 %t52, %t53
  %t59 = add i64 %t51, %t56
  store i64 %t59, ptr %l9, !tbaa !24
  %t61 = load ptr, ptr %l3, !tbaa !29
  %t63 = getelementptr %"compiler/load:Module", ptr %t61, i32 0, i32 14
  %t64 = load i64, ptr %l9, !tbaa !24
  %t67 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2eAt_3cI32_3e(ptr %v0, ptr %t63, i64 %t64)
  store i32 %t67, ptr %l44
  br label %bb13
bb13:
  %t69 = load i32, ptr %l44, !tbaa !23
  %t71 = icmp eq i32 %t69, %a2
  br i1 %t71, label %bb14, label %bb15
bb14:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load i64, ptr %l1, !tbaa !24
  %t75 = load i64, ptr %l9, !tbaa !24
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2edecide(ptr %v0, ptr %t73, i64 %t74, i64 %t75)
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t79 = load ptr, ptr %l3, !tbaa !29
  %t81 = getelementptr %"compiler/load:Module", ptr %t79, i32 0, i32 16
  %t82 = load i64, ptr %l9, !tbaa !24
  %t85 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t81, i64 %t82)
  store i64 %t85, ptr %l53
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s2)
  %t86 = load i64, ptr %l53, !tbaa !24
  store i64 %t86, ptr %rv
  br label %ret
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  %t87 = load i64, ptr %l8, !tbaa !24
  %t89 = add i64 %t87, 1
  store i64 %t89, ptr %l8, !tbaa !24
  br label %bb9
bb20:
  %t91 = load i64, ptr @G_2ecompiler_2fload_2ePending, !tbaa !24
  store i64 %t91, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fload_2ecompiler_2fload_3aLoader_2eCondParser(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i1
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca { i64, ptr }
  %l18 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca i1
  %l21 = alloca %"compiler/source:Span"
  %l26 = alloca ptr
  %l27 = alloca %"compiler/diag:Diagnostics"
  %l33 = alloca ptr
  %l35 = alloca { i64, ptr }
  %l43 = alloca i64
  %l44 = alloca ptr
  %l49 = alloca ptr
  %l54 = alloca ptr
  %l56 = alloca ptr
  %l61 = alloca ptr
  %l68 = alloca %"compiler/parse:Parser"
  %l70 = alloca ptr
  %l73 = alloca i1
  %l74 = alloca %"compiler/cond:Scope"
  %l85 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %l89 = alloca i32
  %l98 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %l108 = alloca i1
  %l111 = alloca i1
  %l116 = alloca i1
  %l119 = alloca i1
  %l124 = alloca i1
  %l131 = alloca i1
  %l143 = alloca { i64, ptr }
  %l149 = alloca i1
  %l153 = alloca { i64, ptr }
  %l154 = alloca { i64, ptr }
  %l155 = alloca i64
  %l156 = alloca { i64, ptr }
  %l159 = alloca i1
  %l160 = alloca { i64, ptr }
  %l170 = alloca { i64, ptr }
  %l171 = alloca { i64, ptr }
  %l174 = alloca i64
  %l175 = alloca { i64, ptr }
  %l178 = alloca i64
  %l179 = alloca i64
  %l184 = alloca { i64, ptr }
  %l186 = alloca i64
  %l190 = alloca { i64, ptr }
  %l191 = alloca { i64, ptr }
  %l193 = alloca i64
  %l195 = alloca i64
  %l196 = alloca { i64, ptr }
  %l197 = alloca ptr
  %l205 = alloca ptr
  %l206 = alloca i32
  %l207 = alloca { i64, ptr }
  %l213 = alloca i64
  %l217 = alloca i1
  %l220 = alloca { i64, ptr }
  %l223 = alloca { i64, ptr }
  %l226 = alloca %"compiler/source:Span"
  %l231 = alloca ptr
  %l238 = alloca { i64, ptr }
  %l240 = alloca i64
  %l242 = alloca i64
  %l243 = alloca i64
  %l257 = alloca %"compiler/cond:Global"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %t11 = alloca %"compiler/diag:Diagnostics", align 8
  %t101 = alloca %"compiler/parse:Parser", align 8
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/load:Module", ptr %t1, i32 0, i32 24
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  %t8 = xor i1 %t6, true
  br i1 %t8, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l26, !tbaa !29
  call void @compiler_2fdiag_3aDiagnostics_2ector(ptr %t11, ptr %v1, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l27, ptr %t11, i64 200, i1 false)
  br label %bb4
bb4:
  %t12 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 200, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t12, ptr %l27, i64 200, i1 false)
  %t14 = load ptr, ptr %l26, !tbaa !29
  %t15 = getelementptr %"compiler/load:Module", ptr %t14, i32 0, i32 25
  store ptr %t12, ptr %t15, !tbaa !29
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/load:Module", ptr %t16, i32 0, i32 25
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = icmp eq ptr %t19, null
  br i1 %t21, label %bb5, label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_5d2941245b0f1fa7_46eb30867ff7b79b)
  unreachable
bb6:
  br label %bb7
bb7:
  %t23 = load ptr, ptr %l1, !tbaa !29
  %t25 = getelementptr %"compiler/load:Module", ptr %t23, i32 0, i32 25
  %t26 = load ptr, ptr %t25, !tbaa !29
  store ptr %t26, ptr %l33, !tbaa !29
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = getelementptr %"compiler/load:Module", ptr %t27, i32 0, i32 0
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !27
  store { i64, ptr } %t30, ptr %l35, !tbaa !27
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr %"compiler/load:Module", ptr %t31, i32 0, i32 6
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = icmp eq ptr %t34, null
  br i1 %t36, label %bb8, label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_5d2941245b0f1fa7_46eb30867ff7b79b)
  unreachable
bb9:
  br label %bb10
bb10:
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr %"compiler/load:Module", ptr %t38, i32 0, i32 6
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t44 = getelementptr %"compiler/source:Source", ptr %t41, i32 0, i32 1
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !27
  %t46 = load ptr, ptr %l33, !tbaa !29
  %t47 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t49 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAddFile(ptr %v1, ptr %v1, ptr %v1, ptr %t46, { i64, ptr } %t47, { i64, ptr } %t45, i1 false)
  store i64 %t49, ptr %l43
  br label %bb11
bb11:
  %t50 = load i64, ptr %l43, !tbaa !24
  store i64 %t50, ptr %l2, !tbaa !24
  %t51 = load ptr, ptr %l1, !tbaa !29
  store ptr %t51, ptr %l44, !tbaa !29
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t54 = getelementptr %"compiler/load:Module", ptr %t52, i32 0, i32 6
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = icmp eq ptr %t55, null
  br i1 %t57, label %bb12, label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_59c39bf8bbcbf188_f14f86d27dc81ac)
  unreachable
bb13:
  br label %bb14
bb14:
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr %"compiler/load:Module", ptr %t59, i32 0, i32 6
  %t62 = load ptr, ptr %t61, !tbaa !29
  store ptr %t62, ptr %l49, !tbaa !29
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t65 = getelementptr %"compiler/load:Module", ptr %t63, i32 0, i32 7
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = icmp eq ptr %t66, null
  br i1 %t68, label %bb15, label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_59c39bf8bbcbf188_f14f86d27dc81ac)
  unreachable
bb16:
  br label %bb17
bb17:
  %t70 = load ptr, ptr %l1, !tbaa !29
  %t72 = getelementptr %"compiler/load:Module", ptr %t70, i32 0, i32 7
  %t73 = load ptr, ptr %t72, !tbaa !29
  store ptr %t73, ptr %l54, !tbaa !29
  %t76 = getelementptr %"compiler/load:Loader", ptr %a0, i32 0, i32 3
  %t77 = load ptr, ptr %t76, !tbaa !29
  store ptr %t77, ptr %l56, !tbaa !29
  %t78 = load ptr, ptr %l1, !tbaa !29
  %t80 = getelementptr %"compiler/load:Module", ptr %t78, i32 0, i32 12
  %t81 = load ptr, ptr %t80, !tbaa !29
  %t83 = icmp eq ptr %t81, null
  br i1 %t83, label %bb18, label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_59c39bf8bbcbf188_f14f86d27dc81ac)
  unreachable
bb19:
  br label %bb20
bb20:
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t87 = getelementptr %"compiler/load:Module", ptr %t85, i32 0, i32 12
  %t88 = load ptr, ptr %t87, !tbaa !29
  store ptr %t88, ptr %l61, !tbaa !29
  %t89 = load ptr, ptr %l1, !tbaa !29
  %t91 = getelementptr %"compiler/load:Module", ptr %t89, i32 0, i32 25
  %t92 = load ptr, ptr %t91, !tbaa !29
  %t94 = icmp eq ptr %t92, null
  br i1 %t94, label %bb21, label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_59c39bf8bbcbf188_f14f86d27dc81ac)
  unreachable
bb22:
  br label %bb23
bb23:
  %t96 = load ptr, ptr %l1, !tbaa !29
  %t98 = getelementptr %"compiler/load:Module", ptr %t96, i32 0, i32 25
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t100 = load i64, ptr %l2, !tbaa !24
  %t102 = load ptr, ptr %l49, !tbaa !29
  %t103 = load ptr, ptr %l54, !tbaa !29
  %t104 = load ptr, ptr %l56, !tbaa !29
  %t105 = load ptr, ptr %l61, !tbaa !29
  call void @compiler_2fparse_3aParser_2ector(ptr %t101, ptr %v1, ptr %v1, ptr %v0, ptr %v1, ptr %v1, ptr %v1, ptr %t102, ptr %t103, ptr %t104, ptr %t105, ptr %t99, i64 %t100)
  call void @llvm.memmove.p0.p0.i64(ptr %l68, ptr %t101, i64 272, i1 false)
  br label %bb24
bb24:
  %t108 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 272, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t108, ptr %l68, i64 272, i1 false)
  %t110 = load ptr, ptr %l44, !tbaa !29
  %t111 = getelementptr %"compiler/load:Module", ptr %t110, i32 0, i32 24
  store ptr %t108, ptr %t111, !tbaa !29
  %t112 = load ptr, ptr %l1, !tbaa !29
  store ptr %t112, ptr %l70, !tbaa !29
  %t113 = load ptr, ptr %l1, !tbaa !29
  %t115 = getelementptr %"compiler/load:Module", ptr %t113, i32 0, i32 2
  %t116 = load { i64, ptr }, ptr %t115, !tbaa !27
  %t118 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s0, { i64, ptr } %t116, { i64, ptr } { i64 4, ptr @.d20 })
  store i1 %t118, ptr %l73
  br label %bb25
bb25:
  %t119 = load i1, ptr %l73, !tbaa !21
  %t120 = call %"compiler/cond:Scope" @compiler_2fcond_3aScope_2ector(ptr %v1, i1 %t119)
  store %"compiler/cond:Scope" %t120, ptr %l74
  br label %bb26
bb26:
  %t121 = load %"compiler/cond:Scope", ptr %l74
  %t122 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store %"compiler/cond:Scope" %t121, ptr %t122
  %t124 = load ptr, ptr %l70, !tbaa !29
  %t125 = getelementptr %"compiler/load:Module", ptr %t124, i32 0, i32 23
  store ptr %t122, ptr %t125, !tbaa !29
  %t126 = load ptr, ptr %l1, !tbaa !29
  %t128 = getelementptr %"compiler/load:Module", ptr %t126, i32 0, i32 7
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t131 = icmp eq ptr %t129, null
  br i1 %t131, label %bb27, label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_4d8cd44e3790675d_2617b874cf4b9361)
  unreachable
bb28:
  br label %bb29
bb29:
  %t133 = load ptr, ptr %l1, !tbaa !29
  %t135 = getelementptr %"compiler/load:Module", ptr %t133, i32 0, i32 7
  %t136 = load ptr, ptr %t135, !tbaa !29
  %t139 = getelementptr %"compiler/scan:Tokens", ptr %t136, i32 0, i32 0
  %t140 = load { i64, ptr }, ptr %t139, !tbaa !27
  store { i64, ptr } %t140, ptr %l3, !tbaa !27
  %t142 = load ptr, ptr %l1, !tbaa !29
  %t144 = getelementptr %"compiler/load:Module", ptr %t142, i32 0, i32 22
  store ptr %t144, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb30
bb30:
  store %olang.scope zeroinitializer, ptr %s3
  %t146 = load ptr, ptr %l4, !tbaa !29
  %t147 = load i64, ptr %l5, !tbaa !24
  %t150 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v1, ptr %t146, i64 %t147)
  %t151 = extractvalue { i32, { i64, ptr } } %t150, 1
  %t152 = extractvalue { i32, { i64, ptr } } %t150, 0
  store i32 %t152, ptr %l89
  %t153 = icmp ne i32 %t152, 0
  br i1 %t153, label %bb32, label %ok.154
ok.154:
  store { i64, ptr } %t151, ptr %l88
  br label %bb31
bb31:
  %t155 = load { i64, ptr }, ptr %l88, !tbaa !27
  store { i64, ptr } %t155, ptr %l85, !tbaa !27
  br label %bb36
bb32:
  %t156 = load i32, ptr %l89, !tbaa !23
  %t157 = ashr i32 %t156, 16
  %t159 = icmp eq i32 %t157, 1
  br i1 %t159, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_fa9a52c457f0fb75_22f5bb1b6c86fb39)
  unreachable
bb35:
  call void @__olang_scope_close(ptr %s3)
  br label %bb139
bb36:
  %t161 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t161, ptr %l6, !tbaa !27
  %t162 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t164 = extractvalue { i64, ptr } %t162, 0
  store i64 %t164, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb37
bb37:
  store %olang.scope zeroinitializer, ptr %s4
  %t166 = load i64, ptr %l8, !tbaa !24
  %t167 = load i64, ptr %l7, !tbaa !24
  %t170 = icmp slt i64 %t166, %t167
  %t172 = xor i1 %t170, true
  br i1 %t172, label %bb38, label %bb39
bb38:
  call void @__olang_scope_close(ptr %s4)
  br label %bb137
bb39:
  br label %bb40
bb40:
  %t174 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t174, ptr %l98, !tbaa !27
  %t175 = load i64, ptr %l8, !tbaa !24
  %t177 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !27
  %t179 = getelementptr i64, ptr %t178, i64 %t175
  %t180 = load i64, ptr %t179, !tbaa !34
  store i64 %t180, ptr %l9, !tbaa !24
  %t182 = load i64, ptr %l9, !tbaa !24
  %t184 = add i64 %t182, 1
  store i64 %t184, ptr %l10, !tbaa !24
  store i1 false, ptr %l11, !tbaa !21
  store i64 0, ptr %l12, !tbaa !24
  store i64 -1, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb41
bb41:
  store %olang.scope zeroinitializer, ptr %s5
  %t186 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t186, ptr %l103, !tbaa !27
  %t187 = load i64, ptr %l10, !tbaa !24
  %t189 = getelementptr { i64, ptr }, ptr %l103, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !27
  %t191 = getelementptr %"compiler/token:Token", ptr %t190, i64 %t187
  %t192 = getelementptr %"compiler/token:Token", ptr %t191, i32 0, i32 0
  %t193 = load i32, ptr %t192
  store i32 %t193, ptr %l15
  %t195 = load i32, ptr %l15
  %t197 = trunc i64 0 to i32
  %t198 = icmp eq i32 %t195, %t197
  br i1 %t198, label %bb42, label %bb43
bb42:
  store i1 true, ptr %l108, !tbaa !21
  br label %bb44
bb43:
  %t200 = load i32, ptr %l15
  %t202 = trunc i64 8 to i32
  %t203 = icmp eq i32 %t200, %t202
  store i1 %t203, ptr %l108, !tbaa !21
  br label %bb44
bb44:
  %t205 = load i1, ptr %l108, !tbaa !21
  br i1 %t205, label %bb45, label %bb46
bb45:
  store i1 true, ptr %l111, !tbaa !21
  br label %bb47
bb46:
  %t206 = load i32, ptr %l15
  %t208 = trunc i64 92 to i32
  %t209 = icmp eq i32 %t206, %t208
  store i1 %t209, ptr %l111, !tbaa !21
  br label %bb47
bb47:
  %t211 = load i1, ptr %l111, !tbaa !21
  br i1 %t211, label %bb48, label %bb49
bb48:
  call void @__olang_scope_close(ptr %s5)
  br label %bb76
bb49:
  br label %bb50
bb50:
  %t212 = load i64, ptr %l14, !tbaa !24
  %t214 = icmp eq i64 %t212, 0
  br i1 %t214, label %bb51, label %bb52
bb51:
  %t216 = load i32, ptr %l15
  %t218 = trunc i64 58 to i32
  %t219 = icmp eq i32 %t216, %t218
  br i1 %t219, label %bb53, label %bb54
bb52:
  store i1 false, ptr %l116, !tbaa !21
  br label %bb56
bb53:
  store i1 true, ptr %l119, !tbaa !21
  br label %bb55
bb54:
  %t221 = load i32, ptr %l15
  %t223 = trunc i64 60 to i32
  %t224 = icmp eq i32 %t221, %t223
  store i1 %t224, ptr %l119, !tbaa !21
  br label %bb55
bb55:
  %t226 = load i1, ptr %l119, !tbaa !21
  store i1 %t226, ptr %l116, !tbaa !21
  br label %bb56
bb56:
  %t227 = load i1, ptr %l116, !tbaa !21
  br i1 %t227, label %bb57, label %bb58
bb57:
  call void @__olang_scope_close(ptr %s5)
  br label %bb76
bb58:
  br label %bb59
bb59:
  %t228 = load i32, ptr %l15
  %t230 = trunc i64 88 to i32
  %t231 = icmp eq i32 %t228, %t230
  br i1 %t231, label %bb60, label %bb61
bb60:
  store i1 true, ptr %l124, !tbaa !21
  br label %bb62
bb61:
  %t233 = load i32, ptr %l15
  %t235 = trunc i64 90 to i32
  %t236 = icmp eq i32 %t233, %t235
  store i1 %t236, ptr %l124, !tbaa !21
  br label %bb62
bb62:
  %t238 = load i1, ptr %l124, !tbaa !21
  br i1 %t238, label %bb63, label %bb64
bb63:
  %t239 = load i64, ptr %l14, !tbaa !24
  %t241 = add i64 %t239, 1
  store i64 %t241, ptr %l14, !tbaa !24
  br label %bb65
bb64:
  br label %bb65
bb65:
  %t243 = load i32, ptr %l15
  %t245 = trunc i64 89 to i32
  %t246 = icmp eq i32 %t243, %t245
  br i1 %t246, label %bb66, label %bb67
bb66:
  store i1 true, ptr %l131, !tbaa !21
  br label %bb68
bb67:
  %t248 = load i32, ptr %l15
  %t250 = trunc i64 91 to i32
  %t251 = icmp eq i32 %t248, %t250
  store i1 %t251, ptr %l131, !tbaa !21
  br label %bb68
bb68:
  %t253 = load i1, ptr %l131, !tbaa !21
  br i1 %t253, label %bb69, label %bb70
bb69:
  %t254 = load i64, ptr %l14, !tbaa !24
  %t256 = sub i64 %t254, 1
  store i64 %t256, ptr %l14, !tbaa !24
  br label %bb71
bb70:
  br label %bb71
bb71:
  %t258 = load i32, ptr %l15
  %t260 = trunc i64 39 to i32
  %t261 = icmp eq i32 %t258, %t260
  br i1 %t261, label %bb72, label %bb73
bb72:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb74
bb73:
  %t263 = load i64, ptr %l12, !tbaa !24
  %t265 = add i64 %t263, 1
  store i64 %t265, ptr %l12, !tbaa !24
  %t267 = load i64, ptr %l10, !tbaa !24
  store i64 %t267, ptr %l13, !tbaa !24
  br label %bb74
bb74:
  %t269 = load i64, ptr %l10, !tbaa !24
  %t271 = add i64 %t269, 1
  store i64 %t271, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb75
bb75:
  br label %bb41
bb76:
  %t273 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t273, ptr %l143, !tbaa !27
  %t274 = load i64, ptr %l10, !tbaa !24
  %t276 = getelementptr { i64, ptr }, ptr %l143, i32 0, i32 1
  %t277 = load ptr, ptr %t276, !tbaa !27
  %t278 = getelementptr %"compiler/token:Token", ptr %t277, i64 %t274
  %t279 = getelementptr %"compiler/token:Token", ptr %t278, i32 0, i32 0
  %t280 = load i32, ptr %t279
  store i32 %t280, ptr %l16
  %t282 = load i32, ptr %l16
  %t284 = trunc i64 58 to i32
  %t285 = icmp eq i32 %t282, %t284
  %t287 = xor i1 %t285, true
  br i1 %t287, label %bb77, label %bb78
bb77:
  %t289 = load i32, ptr %l16
  %t291 = trunc i64 60 to i32
  %t292 = icmp eq i32 %t289, %t291
  %t294 = xor i1 %t292, true
  store i1 %t294, ptr %l149, !tbaa !21
  br label %bb79
bb78:
  store i1 false, ptr %l149, !tbaa !21
  br label %bb79
bb79:
  %t296 = load i1, ptr %l149, !tbaa !21
  br i1 %t296, label %bb80, label %bb81
bb80:
  call void @__olang_scope_close(ptr %s4)
  br label %bb136
bb81:
  br label %bb82
bb82:
  store { i64, ptr } { i64 0, ptr @.d21 }, ptr %l153, !tbaa !27
  %t297 = load { i64, ptr }, ptr %l153, !tbaa !27
  store { i64, ptr } %t297, ptr %l154, !tbaa !27
  %t298 = load { i64, ptr }, ptr %l154, !tbaa !27
  %t299 = extractvalue { i64, ptr } %t298, 0
  store i64 %t299, ptr %l155, !tbaa !24
  %t300 = load i64, ptr %l155, !tbaa !24
  %t301 = mul i64 %t300, 1
  %t302 = call ptr @__olang_scope_alloc_zeroed(ptr %s4, i64 %t301)
  %t303 = insertvalue { i64, ptr } undef, i64 %t300, 0
  %t304 = insertvalue { i64, ptr } %t303, ptr %t302, 1
  store { i64, ptr } %t304, ptr %l156, !tbaa !27
  %t305 = getelementptr { i64, ptr }, ptr %l156, i32 0, i32 1
  %t306 = load ptr, ptr %t305, !tbaa !27
  %t307 = getelementptr { i64, ptr }, ptr %l154, i32 0, i32 1
  %t308 = load ptr, ptr %t307, !tbaa !27
  %t309 = load i64, ptr %l155, !tbaa !24
  %t310 = mul i64 %t309, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t306, ptr %t308, i64 %t310, i1 false)
  %t311 = load { i64, ptr }, ptr %l156, !tbaa !27
  store { i64, ptr } %t311, ptr %l17, !tbaa !27
  %t312 = load i64, ptr %l12, !tbaa !24
  %t314 = icmp eq i64 %t312, 1
  br i1 %t314, label %bb83, label %bb84
bb83:
  %t316 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t316, ptr %l160, !tbaa !27
  %t317 = load i64, ptr %l13, !tbaa !24
  %t319 = getelementptr { i64, ptr }, ptr %l160, i32 0, i32 1
  %t320 = load ptr, ptr %t319, !tbaa !27
  %t321 = getelementptr %"compiler/token:Token", ptr %t320, i64 %t317
  %t322 = getelementptr %"compiler/token:Token", ptr %t321, i32 0, i32 0
  %t323 = load i32, ptr %t322
  %t325 = trunc i64 1 to i32
  %t326 = icmp eq i32 %t323, %t325
  store i1 %t326, ptr %l159, !tbaa !21
  br label %bb85
bb84:
  store i1 false, ptr %l159, !tbaa !21
  br label %bb85
bb85:
  %t328 = load i1, ptr %l159, !tbaa !21
  br i1 %t328, label %bb86, label %bb87
bb86:
  %t329 = load ptr, ptr %l1, !tbaa !29
  %t331 = getelementptr %"compiler/load:Module", ptr %t329, i32 0, i32 6
  %t332 = load ptr, ptr %t331, !tbaa !29
  %t334 = icmp eq ptr %t332, null
  br i1 %t334, label %bb88, label %bb89
bb87:
  %t336 = load i64, ptr %l12, !tbaa !24
  %t338 = icmp sgt i64 %t336, 0
  br i1 %t338, label %bb100, label %bb101
bb88:
  call void @__olang_check_failed(ptr @olang_loc_d075f0de9750727b_8d30bef36920d0c7)
  unreachable
bb89:
  br label %bb90
bb90:
  %t340 = load ptr, ptr %l1, !tbaa !29
  %t342 = getelementptr %"compiler/load:Module", ptr %t340, i32 0, i32 6
  %t343 = load ptr, ptr %t342, !tbaa !29
  %t346 = getelementptr %"compiler/source:Source", ptr %t343, i32 0, i32 1
  %t347 = load { i64, ptr }, ptr %t346, !tbaa !27
  store { i64, ptr } %t347, ptr %l170, !tbaa !27
  %t348 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t348, ptr %l171, !tbaa !27
  %t349 = load i64, ptr %l13, !tbaa !24
  %t351 = getelementptr { i64, ptr }, ptr %l171, i32 0, i32 1
  %t352 = load ptr, ptr %t351, !tbaa !27
  %t353 = getelementptr %"compiler/token:Token", ptr %t352, i64 %t349
  %t354 = getelementptr %"compiler/token:Token", ptr %t353, i32 0, i32 2
  %t355 = load i32, ptr %t354, !tbaa !23
  %t357 = sext i32 %t355 to i64
  store i64 %t357, ptr %l174, !tbaa !24
  %t358 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t358, ptr %l175, !tbaa !27
  %t359 = load i64, ptr %l13, !tbaa !24
  %t361 = getelementptr { i64, ptr }, ptr %l175, i32 0, i32 1
  %t362 = load ptr, ptr %t361, !tbaa !27
  %t363 = getelementptr %"compiler/token:Token", ptr %t362, i64 %t359
  %t364 = getelementptr %"compiler/token:Token", ptr %t363, i32 0, i32 3
  %t365 = load i32, ptr %t364, !tbaa !23
  %t367 = sext i32 %t365 to i64
  store i64 %t367, ptr %l178, !tbaa !24
  %t368 = load { i64, ptr }, ptr %l170, !tbaa !27
  %t369 = extractvalue { i64, ptr } %t368, 0
  store i64 %t369, ptr %l179, !tbaa !24
  %t370 = load i64, ptr %l174, !tbaa !24
  %t371 = icmp sge i64 %t370, 0
  br i1 %t371, label %bb91, label %bb92
bb91:
  %t373 = load i64, ptr %l174, !tbaa !24
  %t374 = load i64, ptr %l178, !tbaa !24
  %t375 = icmp sle i64 %t373, %t374
  br i1 %t375, label %bb93, label %bb94
bb92:
  call void @__olang_check_failed(ptr @olang_loc_3e505cf2918dad64_849156d88841e490)
  unreachable
bb93:
  %t377 = load i64, ptr %l178, !tbaa !24
  %t378 = load i64, ptr %l179, !tbaa !24
  %t379 = icmp sle i64 %t377, %t378
  br i1 %t379, label %bb95, label %bb96
bb94:
  call void @__olang_check_failed(ptr @olang_loc_3e505cf2918dad64_849156d88841e490)
  unreachable
bb95:
  %t381 = getelementptr { i64, ptr }, ptr %l170, i32 0, i32 1
  %t382 = load ptr, ptr %t381, !tbaa !27
  %t383 = load i64, ptr %l174, !tbaa !24
  %t384 = load i64, ptr %l178, !tbaa !24
  %t385 = getelementptr i8, ptr %t382, i64 %t383
  %t386 = sub i64 %t384, %t383
  %t387 = insertvalue { i64, ptr } undef, i64 %t386, 0
  %t388 = insertvalue { i64, ptr } %t387, ptr %t385, 1
  %t390 = extractvalue { i64, ptr } %t388, 1
  %t391 = extractvalue { i64, ptr } %t388, 0
  %t392 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t391)
  call void @olang_textcopy(ptr %t392, ptr %t390, i64 %t391)
  %t393 = insertvalue { i64, ptr } undef, i64 %t391, 0
  %t394 = insertvalue { i64, ptr } %t393, ptr %t392, 1
  store { i64, ptr } %t394, ptr %l184, !tbaa !27
  %t395 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t396 = extractvalue { i64, ptr } %t395, 0
  %t397 = load { i64, ptr }, ptr %l184, !tbaa !27
  %t398 = extractvalue { i64, ptr } %t397, 0
  store i64 %t398, ptr %l186, !tbaa !24
  %t400 = load i64, ptr %l186, !tbaa !24
  %t401 = icmp eq i64 %t396, %t400
  br i1 %t401, label %bb97, label %bb98
bb96:
  call void @__olang_check_failed(ptr @olang_loc_3e505cf2918dad64_849156d88841e490)
  unreachable
bb97:
  %t403 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t404 = load ptr, ptr %t403, !tbaa !27
  %t405 = getelementptr { i64, ptr }, ptr %l184, i32 0, i32 1
  %t406 = load ptr, ptr %t405, !tbaa !27
  %t407 = load i64, ptr %l186, !tbaa !24
  %t408 = mul i64 %t407, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t404, ptr %t406, i64 %t408, i1 false)
  br label %bb99
bb98:
  %t409 = load { i64, ptr }, ptr %l184, !tbaa !27
  store { i64, ptr } %t409, ptr %l17, !tbaa !27
  br label %bb99
bb99:
  br label %bb106
bb100:
  store { i64, ptr } { i64 1, ptr @.d22 }, ptr %l190, !tbaa !27
  %t410 = load { i64, ptr }, ptr %l190, !tbaa !27
  store { i64, ptr } %t410, ptr %l191, !tbaa !27
  %t411 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t412 = extractvalue { i64, ptr } %t411, 0
  %t413 = load { i64, ptr }, ptr %l191, !tbaa !27
  %t414 = extractvalue { i64, ptr } %t413, 0
  store i64 %t414, ptr %l193, !tbaa !24
  %t416 = load i64, ptr %l193, !tbaa !24
  %t417 = icmp eq i64 %t412, %t416
  br i1 %t417, label %bb102, label %bb103
bb101:
  br label %bb105
bb102:
  %t419 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t420 = load ptr, ptr %t419, !tbaa !27
  %t421 = getelementptr { i64, ptr }, ptr %l191, i32 0, i32 1
  %t422 = load ptr, ptr %t421, !tbaa !27
  %t423 = load i64, ptr %l193, !tbaa !24
  %t424 = mul i64 %t423, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t420, ptr %t422, i64 %t424, i1 false)
  br label %bb104
bb103:
  %t425 = load { i64, ptr }, ptr %l191, !tbaa !27
  %t426 = extractvalue { i64, ptr } %t425, 0
  store i64 %t426, ptr %l195, !tbaa !24
  %t427 = load i64, ptr %l195, !tbaa !24
  %t428 = mul i64 %t427, 1
  %t429 = call ptr @__olang_scope_alloc_zeroed(ptr %s4, i64 %t428)
  %t430 = insertvalue { i64, ptr } undef, i64 %t427, 0
  %t431 = insertvalue { i64, ptr } %t430, ptr %t429, 1
  store { i64, ptr } %t431, ptr %l196, !tbaa !27
  %t432 = getelementptr { i64, ptr }, ptr %l196, i32 0, i32 1
  %t433 = load ptr, ptr %t432, !tbaa !27
  %t434 = getelementptr { i64, ptr }, ptr %l191, i32 0, i32 1
  %t435 = load ptr, ptr %t434, !tbaa !27
  %t436 = load i64, ptr %l195, !tbaa !24
  %t437 = mul i64 %t436, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t433, ptr %t435, i64 %t437, i1 false)
  %t438 = load { i64, ptr }, ptr %l196, !tbaa !27
  store { i64, ptr } %t438, ptr %l17, !tbaa !27
  br label %bb104
bb104:
  br label %bb105
bb105:
  br label %bb106
bb106:
  %t439 = load ptr, ptr %l1, !tbaa !29
  %t441 = getelementptr %"compiler/load:Module", ptr %t439, i32 0, i32 24
  %t442 = load ptr, ptr %t441, !tbaa !29
  %t444 = icmp eq ptr %t442, null
  br i1 %t444, label %bb107, label %bb108
bb107:
  call void @__olang_check_failed(ptr @olang_loc_64a34b454640941_8ed0e4b282ed07d)
  unreachable
bb108:
  br label %bb109
bb109:
  %t446 = load ptr, ptr %l1, !tbaa !29
  %t448 = getelementptr %"compiler/load:Module", ptr %t446, i32 0, i32 24
  %t449 = load ptr, ptr %t448, !tbaa !29
  %t450 = load i64, ptr %l10, !tbaa !24
  %t452 = add i64 %t450, 1
  %t455 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eExprAt(ptr %v1, ptr %t449, i64 %t452)
  %t456 = extractvalue { i32, ptr } %t455, 1
  %t457 = extractvalue { i32, ptr } %t455, 0
  store i32 %t457, ptr %l206
  %t458 = icmp ne i32 %t457, 0
  br i1 %t458, label %bb111, label %ok.459
ok.459:
  store ptr %t456, ptr %l205
  br label %bb110
bb110:
  %t460 = load ptr, ptr %l205, !tbaa !29
  store ptr %t460, ptr %l197, !tbaa !29
  br label %bb113
bb111:
  br label %bb112
bb112:
  call void @__olang_scope_close(ptr %s4)
  br label %bb136
bb113:
  %t461 = load ptr, ptr %l197, !tbaa !29
  store ptr %t461, ptr %l18, !tbaa !29
  %t462 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t462, ptr %l207, !tbaa !27
  %t463 = load ptr, ptr %l1, !tbaa !29
  %t465 = getelementptr %"compiler/load:Module", ptr %t463, i32 0, i32 24
  %t466 = load ptr, ptr %t465, !tbaa !29
  %t468 = icmp eq ptr %t466, null
  br i1 %t468, label %bb114, label %bb115
bb114:
  call void @__olang_check_failed(ptr @olang_loc_64e62a75e1515ba_854f46de0e9c2096)
  unreachable
bb115:
  br label %bb116
bb116:
  %t470 = load ptr, ptr %l1, !tbaa !29
  %t472 = getelementptr %"compiler/load:Module", ptr %t470, i32 0, i32 24
  %t473 = load ptr, ptr %t472, !tbaa !29
  %t475 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ePos(ptr %v1, ptr %t473)
  store i64 %t475, ptr %l213
  br label %bb117
bb117:
  %t476 = load i64, ptr %l213, !tbaa !24
  %t477 = getelementptr { i64, ptr }, ptr %l207, i32 0, i32 1
  %t478 = load ptr, ptr %t477, !tbaa !27
  %t479 = getelementptr %"compiler/token:Token", ptr %t478, i64 %t476
  %t480 = getelementptr %"compiler/token:Token", ptr %t479, i32 0, i32 0
  %t481 = load i32, ptr %t480
  store i32 %t481, ptr %l19
  %t483 = load i32, ptr %l19
  %t485 = trunc i64 8 to i32
  %t486 = icmp eq i32 %t483, %t485
  br i1 %t486, label %bb118, label %bb119
bb118:
  store i1 true, ptr %l217, !tbaa !21
  br label %bb120
bb119:
  %t488 = load i32, ptr %l19
  %t490 = trunc i64 0 to i32
  %t491 = icmp eq i32 %t488, %t490
  store i1 %t491, ptr %l217, !tbaa !21
  br label %bb120
bb120:
  %t493 = load i1, ptr %l217, !tbaa !21
  store i1 %t493, ptr %l20, !tbaa !21
  %t494 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t494, ptr %l220, !tbaa !27
  %t495 = load i64, ptr %l9, !tbaa !24
  %t497 = getelementptr { i64, ptr }, ptr %l220, i32 0, i32 1
  %t498 = load ptr, ptr %t497, !tbaa !27
  %t499 = getelementptr %"compiler/token:Token", ptr %t498, i64 %t495
  %t500 = getelementptr %"compiler/token:Token", ptr %t499, i32 0, i32 2
  %t501 = load i32, ptr %t500, !tbaa !23
  %t502 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t502, ptr %l223, !tbaa !27
  %t503 = load i64, ptr %l9, !tbaa !24
  %t505 = getelementptr { i64, ptr }, ptr %l223, i32 0, i32 1
  %t506 = load ptr, ptr %t505, !tbaa !27
  %t507 = getelementptr %"compiler/token:Token", ptr %t506, i64 %t503
  %t508 = getelementptr %"compiler/token:Token", ptr %t507, i32 0, i32 3
  %t509 = load i32, ptr %t508, !tbaa !23
  %t512 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s4, i32 %t501, i32 %t509)
  store %"compiler/source:Span" %t512, ptr %l226
  br label %bb121
bb121:
  %t513 = load %"compiler/source:Span", ptr %l226
  store %"compiler/source:Span" %t513, ptr %l21
  %t514 = load ptr, ptr %l1, !tbaa !29
  %t516 = getelementptr %"compiler/load:Module", ptr %t514, i32 0, i32 23
  %t517 = load ptr, ptr %t516, !tbaa !29
  %t519 = icmp eq ptr %t517, null
  br i1 %t519, label %bb122, label %bb123
bb122:
  call void @__olang_check_failed(ptr @olang_loc_fd9aced5b5816aaf_8929f8e14d5b5303)
  unreachable
bb123:
  br label %bb124
bb124:
  %t521 = load ptr, ptr %l1, !tbaa !29
  %t523 = getelementptr %"compiler/load:Module", ptr %t521, i32 0, i32 23
  %t524 = load ptr, ptr %t523, !tbaa !29
  store ptr %t524, ptr %l231, !tbaa !29
  %t525 = load ptr, ptr %l1, !tbaa !29
  %t527 = getelementptr %"compiler/load:Module", ptr %t525, i32 0, i32 6
  %t528 = load ptr, ptr %t527, !tbaa !29
  %t530 = icmp eq ptr %t528, null
  br i1 %t530, label %bb125, label %bb126
bb125:
  call void @__olang_check_failed(ptr @olang_loc_fd9aced5b5816aaf_8929f8e14d5b5303)
  unreachable
bb126:
  br label %bb127
bb127:
  %t532 = load ptr, ptr %l1, !tbaa !29
  %t534 = getelementptr %"compiler/load:Module", ptr %t532, i32 0, i32 6
  %t535 = load ptr, ptr %t534, !tbaa !29
  %t538 = getelementptr %"compiler/source:Source", ptr %t535, i32 0, i32 1
  %t539 = load { i64, ptr }, ptr %t538, !tbaa !27
  store { i64, ptr } %t539, ptr %l238, !tbaa !27
  %t540 = getelementptr %"compiler/source:Span", ptr %l21, i32 0, i32 0
  %t541 = load i32, ptr %t540, !tbaa !23
  %t543 = sext i32 %t541 to i64
  store i64 %t543, ptr %l240, !tbaa !24
  %t544 = getelementptr %"compiler/source:Span", ptr %l21, i32 0, i32 1
  %t545 = load i32, ptr %t544, !tbaa !23
  %t547 = sext i32 %t545 to i64
  store i64 %t547, ptr %l242, !tbaa !24
  %t548 = load { i64, ptr }, ptr %l238, !tbaa !27
  %t549 = extractvalue { i64, ptr } %t548, 0
  store i64 %t549, ptr %l243, !tbaa !24
  %t550 = load i64, ptr %l240, !tbaa !24
  %t551 = icmp sge i64 %t550, 0
  br i1 %t551, label %bb128, label %bb129
bb128:
  %t553 = load i64, ptr %l240, !tbaa !24
  %t554 = load i64, ptr %l242, !tbaa !24
  %t555 = icmp sle i64 %t553, %t554
  br i1 %t555, label %bb130, label %bb131
bb129:
  call void @__olang_check_failed(ptr @olang_loc_cbb673ffd51f0578_6485c9eddb6ebeac)
  unreachable
bb130:
  %t557 = load i64, ptr %l242, !tbaa !24
  %t558 = load i64, ptr %l243, !tbaa !24
  %t559 = icmp sle i64 %t557, %t558
  br i1 %t559, label %bb132, label %bb133
bb131:
  call void @__olang_check_failed(ptr @olang_loc_cbb673ffd51f0578_6485c9eddb6ebeac)
  unreachable
bb132:
  %t561 = getelementptr { i64, ptr }, ptr %l238, i32 0, i32 1
  %t562 = load ptr, ptr %t561, !tbaa !27
  %t563 = load i64, ptr %l240, !tbaa !24
  %t564 = load i64, ptr %l242, !tbaa !24
  %t565 = getelementptr i8, ptr %t562, i64 %t563
  %t566 = sub i64 %t564, %t563
  %t567 = insertvalue { i64, ptr } undef, i64 %t566, 0
  %t568 = insertvalue { i64, ptr } %t567, ptr %t565, 1
  %t570 = extractvalue { i64, ptr } %t568, 1
  %t571 = extractvalue { i64, ptr } %t568, 0
  %t572 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t571)
  call void @olang_textcopy(ptr %t572, ptr %t570, i64 %t571)
  %t573 = insertvalue { i64, ptr } undef, i64 %t571, 0
  %t574 = insertvalue { i64, ptr } %t573, ptr %t572, 1
  %t576 = extractvalue { i64, ptr } %t574, 0
  %t577 = extractvalue { i64, ptr } %t574, 1
  %t578 = mul i64 %t576, 1
  %t579 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t578)
  call void @llvm.memcpy.p0.p0.i64(ptr %t579, ptr %t577, i64 %t578, i1 false)
  %t580 = insertvalue { i64, ptr } undef, i64 %t576, 0
  %t581 = insertvalue { i64, ptr } %t580, ptr %t579, 1
  %t582 = load %"compiler/source:Span", ptr %l21
  %t583 = load i1, ptr %l11, !tbaa !21
  %t584 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t586 = extractvalue { i64, ptr } %t584, 1
  %t587 = extractvalue { i64, ptr } %t584, 0
  %t588 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t587)
  call void @olang_textcopy(ptr %t588, ptr %t586, i64 %t587)
  %t589 = insertvalue { i64, ptr } undef, i64 %t587, 0
  %t590 = insertvalue { i64, ptr } %t589, ptr %t588, 1
  %t592 = extractvalue { i64, ptr } %t590, 0
  %t593 = extractvalue { i64, ptr } %t590, 1
  %t594 = mul i64 %t592, 1
  %t595 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t594)
  call void @llvm.memcpy.p0.p0.i64(ptr %t595, ptr %t593, i64 %t594, i1 false)
  %t596 = insertvalue { i64, ptr } undef, i64 %t592, 0
  %t597 = insertvalue { i64, ptr } %t596, ptr %t595, 1
  %t598 = load ptr, ptr %l18, !tbaa !29
  %t599 = load i1, ptr %l20, !tbaa !21
  %t606 = call %"compiler/cond:Global" @compiler_2fcond_3aGlobal_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t581, %"compiler/source:Span" %t582, i1 %t583, { i64, ptr } %t597, ptr %t598, i1 %t599)
  store %"compiler/cond:Global" %t606, ptr %l257
  br label %bb134
bb133:
  call void @__olang_check_failed(ptr @olang_loc_cbb673ffd51f0578_6485c9eddb6ebeac)
  unreachable
bb134:
  %t607 = load %"compiler/cond:Global", ptr %l257
  %t608 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 64, i64 8)
  store %"compiler/cond:Global" %t607, ptr %t608
  %t609 = load ptr, ptr %l231, !tbaa !29
  call void @compiler_2fcond_2ecompiler_2fcond_3aScope_2eAdd(ptr %v1, ptr %v1, ptr %t609, ptr %t608)
  br label %bb135
bb135:
  call void @__olang_scope_close(ptr %s4)
  br label %bb136
bb136:
  %t611 = load i64, ptr %l8, !tbaa !24
  %t613 = add i64 %t611, 1
  store i64 %t613, ptr %l8, !tbaa !24
  br label %bb37
bb137:
  %t615 = load i64, ptr %l5, !tbaa !24
  %t616 = load i64, ptr %l7, !tbaa !24
  %t619 = add i64 %t615, %t616
  store i64 %t619, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb138
bb138:
  br label %bb30
bb139:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fload_2ecompiler_2fload_3aLoader_2eDecide(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l21 = alloca ptr
  %l24 = alloca i64
  %l28 = alloca i64
  %l31 = alloca i64
  %l52 = alloca i32
  %l55 = alloca i1
  %l59 = alloca i64
  %l68 = alloca i64
  %l72 = alloca i64
  %l75 = alloca i64
  %l96 = alloca i64
  %l99 = alloca i1
  %l103 = alloca i64
  %l115 = alloca i64
  %l124 = alloca i64
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/load:Loader", ptr %t1, i32 0, i32 5
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l21
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l21, !tbaa !29
  store ptr %t8, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  %t9 = load ptr, ptr %l4, !tbaa !29
  %t11 = getelementptr %"compiler/load:Module", ptr %t9, i32 0, i32 14
  %t13 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2eLen_3cI32_3e(ptr %v0, ptr %t11)
  store i64 %t13, ptr %l24
  br label %bb2
bb2:
  %t14 = load i64, ptr %l24, !tbaa !24
  store i64 %t14, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t15 = load i64, ptr %l6, !tbaa !24
  %t16 = load i64, ptr %l5, !tbaa !24
  %t19 = icmp sgt i64 %t15, %t16
  br i1 %t19, label %bb3, label %bb4
bb3:
  %t21 = load i64, ptr %l7, !tbaa !24
  %t23 = icmp sgt i64 %t21, 0
  br i1 %t23, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb8
bb5:
  %t25 = load i64, ptr %l6, !tbaa !24
  %t26 = load i64, ptr %l5, !tbaa !24
  %t29 = sub i64 %t25, %t26
  %t30 = load i64, ptr %l7, !tbaa !24
  %t33 = add i64 %t29, %t30
  %t35 = sub i64 %t33, 1
  %t36 = load i64, ptr %l7, !tbaa !24
  %t39 = sdiv i64 %t35, %t36
  store i64 %t39, ptr %l31, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb7
bb7:
  %t41 = load i64, ptr %l31, !tbaa !24
  store i64 %t41, ptr %l28, !tbaa !24
  br label %bb8
bb8:
  %t42 = load i64, ptr %l28, !tbaa !24
  store i64 %t42, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t43 = load i64, ptr %l9, !tbaa !24
  %t44 = load i64, ptr %l8, !tbaa !24
  %t47 = icmp slt i64 %t43, %t44
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb45
bb11:
  br label %bb12
bb12:
  %t51 = load i64, ptr %l5, !tbaa !24
  %t52 = load i64, ptr %l9, !tbaa !24
  %t53 = load i64, ptr %l7, !tbaa !24
  %t56 = mul i64 %t52, %t53
  %t59 = add i64 %t51, %t56
  store i64 %t59, ptr %l10, !tbaa !24
  %t61 = load ptr, ptr %l4, !tbaa !29
  %t63 = getelementptr %"compiler/load:Module", ptr %t61, i32 0, i32 14
  %t64 = load i64, ptr %l10, !tbaa !24
  %t67 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2eAt_3cI32_3e(ptr %v0, ptr %t63, i64 %t64)
  store i32 %t67, ptr %l52
  br label %bb13
bb13:
  %t69 = load i32, ptr %l52, !tbaa !23
  %t71 = icmp ne i32 %t69, %a2
  br i1 %t71, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l55, !tbaa !21
  br label %bb17
bb15:
  %t73 = load ptr, ptr %l4, !tbaa !29
  %t75 = getelementptr %"compiler/load:Module", ptr %t73, i32 0, i32 16
  %t76 = load i64, ptr %l10, !tbaa !24
  %t79 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t75, i64 %t76)
  store i64 %t79, ptr %l59
  br label %bb16
bb16:
  %t80 = load i64, ptr @G_2ecompiler_2fload_2ePending, !tbaa !24
  %t81 = load i64, ptr %l59, !tbaa !24
  %t83 = icmp ne i64 %t81, %t80
  store i1 %t83, ptr %l55, !tbaa !21
  br label %bb17
bb17:
  %t85 = load i1, ptr %l55, !tbaa !21
  br i1 %t85, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb44
bb19:
  br label %bb20
bb20:
  %t86 = load ptr, ptr %l4, !tbaa !29
  %t88 = getelementptr %"compiler/load:Module", ptr %t86, i32 0, i32 16
  %t89 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t88, i64 %t89, i64 %a3)
  br label %bb21
bb21:
  store i64 0, ptr %l11, !tbaa !24
  %t94 = load ptr, ptr %l4, !tbaa !29
  %t96 = getelementptr %"compiler/load:Module", ptr %t94, i32 0, i32 14
  %t98 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2eLen_3cI32_3e(ptr %v0, ptr %t96)
  store i64 %t98, ptr %l68
  br label %bb22
bb22:
  %t99 = load i64, ptr %l68, !tbaa !24
  store i64 %t99, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t100 = load i64, ptr %l12, !tbaa !24
  %t101 = load i64, ptr %l11, !tbaa !24
  %t104 = icmp sgt i64 %t100, %t101
  br i1 %t104, label %bb23, label %bb24
bb23:
  %t106 = load i64, ptr %l13, !tbaa !24
  %t108 = icmp sgt i64 %t106, 0
  br i1 %t108, label %bb25, label %bb26
bb24:
  store i64 0, ptr %l72, !tbaa !24
  br label %bb28
bb25:
  %t110 = load i64, ptr %l12, !tbaa !24
  %t111 = load i64, ptr %l11, !tbaa !24
  %t114 = sub i64 %t110, %t111
  %t115 = load i64, ptr %l13, !tbaa !24
  %t118 = add i64 %t114, %t115
  %t120 = sub i64 %t118, 1
  %t121 = load i64, ptr %l13, !tbaa !24
  %t124 = sdiv i64 %t120, %t121
  store i64 %t124, ptr %l75, !tbaa !24
  br label %bb27
bb26:
  store i64 0, ptr %l75, !tbaa !24
  br label %bb27
bb27:
  %t126 = load i64, ptr %l75, !tbaa !24
  store i64 %t126, ptr %l72, !tbaa !24
  br label %bb28
bb28:
  %t127 = load i64, ptr %l72, !tbaa !24
  store i64 %t127, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb29
bb29:
  store %olang.scope zeroinitializer, ptr %s5
  %t128 = load i64, ptr %l15, !tbaa !24
  %t129 = load i64, ptr %l14, !tbaa !24
  %t132 = icmp slt i64 %t128, %t129
  %t134 = xor i1 %t132, true
  br i1 %t134, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s5)
  br label %bb43
bb31:
  br label %bb32
bb32:
  %t136 = load i64, ptr %l11, !tbaa !24
  %t137 = load i64, ptr %l15, !tbaa !24
  %t138 = load i64, ptr %l13, !tbaa !24
  %t141 = mul i64 %t137, %t138
  %t144 = add i64 %t136, %t141
  store i64 %t144, ptr %l16, !tbaa !24
  %t146 = load ptr, ptr %l4, !tbaa !29
  %t148 = getelementptr %"compiler/load:Module", ptr %t146, i32 0, i32 16
  %t149 = load i64, ptr %l16, !tbaa !24
  %t152 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t148, i64 %t149)
  store i64 %t152, ptr %l96
  br label %bb33
bb33:
  %t153 = load i64, ptr @G_2ecompiler_2fload_2ePending, !tbaa !24
  %t154 = load i64, ptr %l96, !tbaa !24
  %t156 = icmp eq i64 %t154, %t153
  br i1 %t156, label %bb34, label %bb35
bb34:
  %t158 = load ptr, ptr %l4, !tbaa !29
  %t160 = getelementptr %"compiler/load:Module", ptr %t158, i32 0, i32 15
  %t161 = load i64, ptr %l16, !tbaa !24
  %t164 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t160, i64 %t161)
  store i64 %t164, ptr %l103
  br label %bb36
bb35:
  store i1 false, ptr %l99, !tbaa !21
  br label %bb37
bb36:
  %t165 = load i64, ptr %l103, !tbaa !24
  %t166 = icmp sge i64 %t165, 0
  store i1 %t166, ptr %l99, !tbaa !21
  br label %bb37
bb37:
  %t168 = load i1, ptr %l99, !tbaa !21
  br i1 %t168, label %bb38, label %bb39
bb38:
  %t169 = load ptr, ptr %l4, !tbaa !29
  %t171 = getelementptr %"compiler/load:Module", ptr %t169, i32 0, i32 16
  %t172 = load i64, ptr %l16, !tbaa !24
  %t173 = load i64, ptr @G_2ecompiler_2fload_2eNotYet, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t171, i64 %t172, i64 %t173)
  br label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s5)
  br label %bb42
bb42:
  %t177 = load i64, ptr %l15, !tbaa !24
  %t179 = add i64 %t177, 1
  store i64 %t179, ptr %l15, !tbaa !24
  br label %bb29
bb43:
  call void @__olang_scope_close(ptr %s2)
  br label %bb44
bb44:
  %t181 = load i64, ptr %l9, !tbaa !24
  %t183 = add i64 %t181, 1
  store i64 %t183, ptr %l9, !tbaa !24
  br label %bb9
bb45:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/load:Loader", ptr %t185, i32 0, i32 5
  %t189 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v0, ptr %t187)
  store i64 %t189, ptr %l115
  br label %bb46
bb46:
  %t190 = load i64, ptr %l115, !tbaa !24
  store i64 %t190, ptr %l17, !tbaa !24
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t192 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2eloadImports(ptr %v0, ptr %t191, i64 %t192)
  br label %bb47
bb47:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t196 = load i64, ptr %l1, !tbaa !24
  %t197 = load ptr, ptr %l4, !tbaa !29
  %t199 = getelementptr %"compiler/load:Module", ptr %t197, i32 0, i32 8
  %t200 = load { i64, ptr }, ptr %t199, !tbaa !27
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2egroups(ptr %v0, ptr %v0, ptr %t195, i64 %t196, { i64, ptr } %t200)
  br label %bb48
bb48:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t206 = getelementptr %"compiler/load:Loader", ptr %t204, i32 0, i32 5
  %t208 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v0, ptr %t206)
  store i64 %t208, ptr %l124
  br label %bb49
bb49:
  %t209 = load i64, ptr %l17, !tbaa !24
  %t210 = load i64, ptr %l124, !tbaa !24
  %t212 = icmp sgt i64 %t210, %t209
  br i1 %t212, label %bb50, label %bb51
bb50:
  %t214 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2echeckReach(ptr %v0, ptr %t214)
  br label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb53
bb53:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fload_2ecompiler_2fload_3aLoader_2eGraph(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"std/prelude/text:StringBuilder"
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca %"compiler/load:Import"
  %l21 = alloca ptr
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l29 = alloca i64
  %l38 = alloca i64
  %l41 = alloca i64
  %l66 = alloca %"std/prelude/text:StringBuilder"
  %l74 = alloca { i64, ptr }
  %l80 = alloca ptr
  %l86 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l89 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l93 = alloca i32
  %l102 = alloca { i64, ptr }
  %l107 = alloca ptr
  %l108 = alloca { i64, ptr }
  %l112 = alloca ptr
  %l125 = alloca { i64, ptr }
  %l128 = alloca { i64, ptr }
  %l129 = alloca i32
  %l138 = alloca { i64, ptr }
  %l151 = alloca { i64, ptr }
  %l152 = alloca { i64, ptr }
  %l153 = alloca i64
  %l154 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t83 = alloca { ptr, ptr }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/load:Loader", ptr %t1, i32 0, i32 5
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l29
  br label %bb1
bb1:
  %t6 = load i64, ptr %l29, !tbaa !24
  %t7 = icmp sge i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load i64, ptr %l29, !tbaa !24
  %t10 = icmp sle i64 %t9, 1152921504606846975
  br i1 %t10, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @olang_loc_53eff658f30813a6_f347cd1231cef772)
  unreachable
bb4:
  %t12 = load i64, ptr %l29, !tbaa !24
  %t13 = mul i64 %t12, 8
  %t14 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t13)
  %t15 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t18 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t18, 0
  store i64 %t20, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t22 = load i64, ptr %l3, !tbaa !24
  %t23 = load i64, ptr %l2, !tbaa !24
  %t26 = icmp sgt i64 %t22, %t23
  br i1 %t26, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_53eff658f30813a6_f347cd1231cef772)
  unreachable
bb6:
  %t28 = load i64, ptr %l4, !tbaa !24
  %t30 = icmp sgt i64 %t28, 0
  br i1 %t30, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l38, !tbaa !24
  br label %bb11
bb8:
  %t32 = load i64, ptr %l3, !tbaa !24
  %t33 = load i64, ptr %l2, !tbaa !24
  %t36 = sub i64 %t32, %t33
  %t37 = load i64, ptr %l4, !tbaa !24
  %t40 = add i64 %t36, %t37
  %t42 = sub i64 %t40, 1
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = sdiv i64 %t42, %t43
  store i64 %t46, ptr %l41, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l41, !tbaa !24
  br label %bb10
bb10:
  %t48 = load i64, ptr %l41, !tbaa !24
  store i64 %t48, ptr %l38, !tbaa !24
  br label %bb11
bb11:
  %t49 = load i64, ptr %l38, !tbaa !24
  store i64 %t49, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t50 = load i64, ptr %l6, !tbaa !24
  %t51 = load i64, ptr %l5, !tbaa !24
  %t54 = icmp slt i64 %t50, %t51
  %t56 = xor i1 %t54, true
  br i1 %t56, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb14:
  br label %bb15
bb15:
  %t58 = load i64, ptr %l2, !tbaa !24
  %t59 = load i64, ptr %l6, !tbaa !24
  %t60 = load i64, ptr %l4, !tbaa !24
  %t63 = mul i64 %t59, %t60
  %t66 = add i64 %t58, %t63
  store i64 %t66, ptr %l7, !tbaa !24
  %t68 = load i64, ptr %l7, !tbaa !24
  %t69 = load i64, ptr %l7, !tbaa !24
  %t72 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr i64, ptr %t73, i64 %t68
  store i64 %t69, ptr %t74, !tbaa !34
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  %t75 = load i64, ptr %l6, !tbaa !24
  %t77 = add i64 %t75, 1
  store i64 %t77, ptr %l6, !tbaa !24
  br label %bb12
bb17:
  %t79 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr { ptr, ptr }, ptr null, i32 1
  %t82 = ptrtoint ptr %t81 to i64
  %t84 = getelementptr { ptr, ptr }, ptr %t83, i32 0, i32 0
  store ptr %t80, ptr %t84, !tbaa !28
  call void @__olang_scope_escape(ptr %v0)
  %t86 = getelementptr { ptr, ptr }, ptr %t83, i32 0, i32 1
  store ptr %v0, ptr %t86, !tbaa !28
  %t87 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_23, 0
  %t88 = insertvalue { ptr, ptr } %t87, ptr %t83, 1
  %t91 = extractvalue { ptr, ptr } %t88, 0
  %t92 = extractvalue { ptr, ptr } %t88, 1
  call void @std_2fprelude_2farray_2eArray_3cI64_3e_2eSort_3cI64_3e(ptr %s0, ptr %s0, { i64, ptr } %t79, ptr %t91, ptr %t92)
  br label %bb18
bb18:
  %t93 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t93, ptr %l66
  br label %bb19
bb19:
  %t94 = load %"std/prelude/text:StringBuilder", ptr %l66
  store %"std/prelude/text:StringBuilder" %t94, ptr %l8
  %t95 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t95, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t97 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t97, 0
  store i64 %t99, ptr %l11, !tbaa !24
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s5
  %t101 = load i64, ptr %l10, !tbaa !24
  %t102 = load i64, ptr %l11, !tbaa !24
  %t105 = icmp slt i64 %t101, %t102
  %t107 = xor i1 %t105, true
  br i1 %t107, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s5)
  br label %bb65
bb22:
  br label %bb23
bb23:
  %t109 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t109, ptr %l74, !tbaa !27
  %t110 = load i64, ptr %l10, !tbaa !24
  %t112 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr i64, ptr %t113, i64 %t110
  %t115 = load i64, ptr %t114, !tbaa !34
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/load:Loader", ptr %t117, i32 0, i32 5
  %t123 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t119, i64 %t115)
  store ptr %t123, ptr %l80
  br label %bb24
bb24:
  %t124 = load ptr, ptr %l80, !tbaa !29
  store ptr %t124, ptr %l13, !tbaa !29
  %t125 = load ptr, ptr %l13, !tbaa !29
  %t127 = getelementptr %"compiler/load:Module", ptr %t125, i32 0, i32 2
  %t128 = load { i64, ptr }, ptr %t127, !tbaa !27
  %t129 = extractvalue { i64, ptr } { i64 7, ptr @.d24 }, 1
  %t130 = extractvalue { i64, ptr } { i64 7, ptr @.d24 }, 0
  %t132 = extractvalue { i64, ptr } %t128, 1
  %t133 = extractvalue { i64, ptr } %t128, 0
  %t134 = add i64 %t130, %t133
  %t135 = extractvalue { i64, ptr } { i64 1, ptr @.d25 }, 1
  %t136 = extractvalue { i64, ptr } { i64 1, ptr @.d25 }, 0
  %t137 = add i64 %t134, %t136
  %t138 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t137)
  call void @olang_textcopy(ptr %t138, ptr %t129, i64 %t130)
  %t139 = getelementptr i8, ptr %t138, i64 %t130
  call void @olang_textcopy(ptr %t139, ptr %t132, i64 %t133)
  %t140 = getelementptr i8, ptr %t139, i64 %t133
  call void @olang_textcopy(ptr %t140, ptr %t135, i64 %t136)
  %t141 = insertvalue { i64, ptr } undef, i64 %t137, 0
  %t142 = insertvalue { i64, ptr } %t141, ptr %t138, 1
  %t144 = extractvalue { i64, ptr } %t142, 0
  %t145 = extractvalue { i64, ptr } %t142, 1
  %t146 = mul i64 %t144, 1
  %t147 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t146)
  call void @llvm.memcpy.p0.p0.i64(ptr %t147, ptr %t145, i64 %t146, i1 false)
  %t148 = insertvalue { i64, ptr } undef, i64 %t144, 0
  %t149 = insertvalue { i64, ptr } %t148, ptr %t147, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %l8, { i64, ptr } %t149)
  br label %bb25
bb25:
  %t152 = load ptr, ptr @__olang_prog_scope
  %t153 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t152)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t153, ptr %l86
  br label %bb26
bb26:
  %t154 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l86
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t154, ptr %l14
  %t155 = load ptr, ptr %l13, !tbaa !29
  %t157 = getelementptr %"compiler/load:Module", ptr %t155, i32 0, i32 11
  store ptr %t157, ptr %l15, !tbaa !29
  store i64 0, ptr %l16, !tbaa !24
  br label %bb27
bb27:
  store %olang.scope zeroinitializer, ptr %s8
  %t159 = load ptr, ptr %l15, !tbaa !29
  %t160 = load i64, ptr %l16, !tbaa !24
  %t163 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2eRunFrom_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %t159, i64 %t160)
  %t164 = extractvalue { i32, { i64, ptr } } %t163, 1
  %t165 = extractvalue { i32, { i64, ptr } } %t163, 0
  store i32 %t165, ptr %l93
  %t166 = icmp ne i32 %t165, 0
  br i1 %t166, label %bb29, label %ok.167
ok.167:
  store { i64, ptr } %t164, ptr %l92
  br label %bb28
bb28:
  %t168 = load { i64, ptr }, ptr %l92, !tbaa !27
  store { i64, ptr } %t168, ptr %l89, !tbaa !27
  br label %bb33
bb29:
  %t169 = load i32, ptr %l93, !tbaa !23
  %t170 = ashr i32 %t169, 16
  %t172 = icmp eq i32 %t170, 1
  br i1 %t172, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_62b70330b5a932c_215a88d5ae52afb0)
  unreachable
bb32:
  call void @__olang_scope_close(ptr %s8)
  br label %bb46
bb33:
  %t174 = load { i64, ptr }, ptr %l89, !tbaa !27
  store { i64, ptr } %t174, ptr %l17, !tbaa !27
  %t175 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t177 = extractvalue { i64, ptr } %t175, 0
  store i64 %t177, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb34
bb34:
  store %olang.scope zeroinitializer, ptr %s9
  %t179 = load i64, ptr %l19, !tbaa !24
  %t180 = load i64, ptr %l18, !tbaa !24
  %t183 = icmp slt i64 %t179, %t180
  %t185 = xor i1 %t183, true
  br i1 %t185, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s9)
  br label %bb44
bb36:
  br label %bb37
bb37:
  %t187 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t187, ptr %l102, !tbaa !27
  %t188 = load i64, ptr %l19, !tbaa !24
  %t190 = getelementptr { i64, ptr }, ptr %l102, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !27
  %t192 = getelementptr %"compiler/load:Import", ptr %t191, i64 %t188
  %t193 = load %"compiler/load:Import", ptr %t192
  store %"compiler/load:Import" %t193, ptr %l20
  %t195 = getelementptr %"compiler/load:Import", ptr %l20, i32 0, i32 5
  %t196 = load i64, ptr %t195, !tbaa !24
  %t198 = icmp sge i64 %t196, 0
  br i1 %t198, label %bb38, label %bb39
bb38:
  store ptr %l14, ptr %l107, !tbaa !29
  %t200 = getelementptr %"compiler/load:Import", ptr %l20, i32 0, i32 2
  %t201 = load { i64, ptr }, ptr %t200, !tbaa !27
  store { i64, ptr } %t201, ptr %l108, !tbaa !27
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t204 = getelementptr %"compiler/load:Loader", ptr %t202, i32 0, i32 5
  %t205 = getelementptr %"compiler/load:Import", ptr %l20, i32 0, i32 5
  %t206 = load i64, ptr %t205, !tbaa !24
  %t209 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t204, i64 %t206)
  store ptr %t209, ptr %l112
  br label %bb40
bb39:
  br label %bb42
bb40:
  %t210 = load ptr, ptr %l112, !tbaa !29
  %t212 = getelementptr %"compiler/load:Module", ptr %t210, i32 0, i32 2
  %t213 = load { i64, ptr }, ptr %t212, !tbaa !27
  %t214 = extractvalue { i64, ptr } { i64 2, ptr @.d26 }, 1
  %t215 = extractvalue { i64, ptr } { i64 2, ptr @.d26 }, 0
  %t216 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t217 = extractvalue { i64, ptr } %t216, 1
  %t218 = extractvalue { i64, ptr } %t216, 0
  %t219 = add i64 %t215, %t218
  %t220 = extractvalue { i64, ptr } { i64 1, ptr @.d27 }, 1
  %t221 = extractvalue { i64, ptr } { i64 1, ptr @.d27 }, 0
  %t222 = add i64 %t219, %t221
  %t224 = extractvalue { i64, ptr } %t213, 1
  %t225 = extractvalue { i64, ptr } %t213, 0
  %t226 = add i64 %t222, %t225
  %t227 = extractvalue { i64, ptr } { i64 1, ptr @.d28 }, 1
  %t228 = extractvalue { i64, ptr } { i64 1, ptr @.d28 }, 0
  %t229 = add i64 %t226, %t228
  %t230 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t229)
  call void @olang_textcopy(ptr %t230, ptr %t214, i64 %t215)
  %t231 = getelementptr i8, ptr %t230, i64 %t215
  call void @olang_textcopy(ptr %t231, ptr %t217, i64 %t218)
  %t232 = getelementptr i8, ptr %t231, i64 %t218
  call void @olang_textcopy(ptr %t232, ptr %t220, i64 %t221)
  %t233 = getelementptr i8, ptr %t232, i64 %t221
  call void @olang_textcopy(ptr %t233, ptr %t224, i64 %t225)
  %t234 = getelementptr i8, ptr %t233, i64 %t225
  call void @olang_textcopy(ptr %t234, ptr %t227, i64 %t228)
  %t235 = insertvalue { i64, ptr } undef, i64 %t229, 0
  %t236 = insertvalue { i64, ptr } %t235, ptr %t230, 1
  %t238 = extractvalue { i64, ptr } %t236, 0
  %t239 = extractvalue { i64, ptr } %t236, 1
  %t240 = mul i64 %t238, 1
  %t241 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t240)
  call void @llvm.memcpy.p0.p0.i64(ptr %t241, ptr %t239, i64 %t240, i1 false)
  %t242 = insertvalue { i64, ptr } undef, i64 %t238, 0
  %t243 = insertvalue { i64, ptr } %t242, ptr %t241, 1
  %t244 = load ptr, ptr %l107, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s5, ptr %s5, ptr %t244, { i64, ptr } %t243)
  br label %bb41
bb41:
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s9)
  br label %bb43
bb43:
  %t246 = load i64, ptr %l19, !tbaa !24
  %t248 = add i64 %t246, 1
  store i64 %t248, ptr %l19, !tbaa !24
  br label %bb34
bb44:
  %t250 = load i64, ptr %l16, !tbaa !24
  %t251 = load i64, ptr %l18, !tbaa !24
  %t254 = add i64 %t250, %t251
  store i64 %t254, ptr %l16, !tbaa !24
  call void @__olang_scope_close(ptr %s8)
  br label %bb45
bb45:
  br label %bb27
bb46:
  %t256 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_29, 0
  %t257 = insertvalue { ptr, ptr } %t256, ptr null, 1
  %t260 = extractvalue { ptr, ptr } %t257, 0
  %t261 = extractvalue { ptr, ptr } %t257, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H16703ab81466b1a1027ed0782af113ea(ptr %s5, ptr %s5, ptr %l14, ptr %t260, ptr %t261)
  br label %bb47
bb47:
  store ptr %l14, ptr %l21, !tbaa !29
  store i64 0, ptr %l22, !tbaa !24
  br label %bb48
bb48:
  store %olang.scope zeroinitializer, ptr %s14
  %t263 = load ptr, ptr %l21, !tbaa !29
  %t264 = load i64, ptr %l22, !tbaa !24
  %t267 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %s5, ptr %t263, i64 %t264)
  %t268 = extractvalue { i32, { i64, ptr } } %t267, 1
  %t269 = extractvalue { i32, { i64, ptr } } %t267, 0
  store i32 %t269, ptr %l129
  %t270 = icmp ne i32 %t269, 0
  br i1 %t270, label %bb50, label %ok.271
ok.271:
  store { i64, ptr } %t268, ptr %l128
  br label %bb49
bb49:
  %t272 = load { i64, ptr }, ptr %l128, !tbaa !27
  store { i64, ptr } %t272, ptr %l125, !tbaa !27
  br label %bb54
bb50:
  %t273 = load i32, ptr %l129, !tbaa !23
  %t274 = ashr i32 %t273, 16
  %t276 = icmp eq i32 %t274, 1
  br i1 %t276, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  call void @__olang_check_failed(ptr @olang_loc_1c47cd2d61f1a0a7_ff925f8d23313feb)
  unreachable
bb53:
  call void @__olang_scope_close(ptr %s14)
  br label %bb63
bb54:
  %t278 = load { i64, ptr }, ptr %l125, !tbaa !27
  store { i64, ptr } %t278, ptr %l23, !tbaa !27
  %t279 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t281 = extractvalue { i64, ptr } %t279, 0
  store i64 %t281, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  br label %bb55
bb55:
  store %olang.scope zeroinitializer, ptr %s15
  %t283 = load i64, ptr %l25, !tbaa !24
  %t284 = load i64, ptr %l24, !tbaa !24
  %t287 = icmp slt i64 %t283, %t284
  %t289 = xor i1 %t287, true
  br i1 %t289, label %bb56, label %bb57
bb56:
  call void @__olang_scope_close(ptr %s15)
  br label %bb61
bb57:
  br label %bb58
bb58:
  %t291 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t291, ptr %l138, !tbaa !27
  %t292 = load i64, ptr %l25, !tbaa !24
  %t294 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t295 = load ptr, ptr %t294, !tbaa !27
  %t296 = getelementptr { i64, ptr }, ptr %t295, i64 %t292
  %t297 = load { i64, ptr }, ptr %t296, !tbaa !37
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %l8, { i64, ptr } %t297)
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s15)
  br label %bb60
bb60:
  %t302 = load i64, ptr %l25, !tbaa !24
  %t304 = add i64 %t302, 1
  store i64 %t304, ptr %l25, !tbaa !24
  br label %bb55
bb61:
  %t306 = load i64, ptr %l22, !tbaa !24
  %t307 = load i64, ptr %l24, !tbaa !24
  %t310 = add i64 %t306, %t307
  store i64 %t310, ptr %l22, !tbaa !24
  call void @__olang_scope_close(ptr %s14)
  br label %bb62
bb62:
  br label %bb48
bb63:
  call void @__olang_scope_close(ptr %s5)
  br label %bb64
bb64:
  %t312 = load i64, ptr %l10, !tbaa !24
  %t314 = add i64 %t312, 1
  store i64 %t314, ptr %l10, !tbaa !24
  br label %bb20
bb65:
  %t317 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l8)
  store { i64, ptr } %t317, ptr %l151
  br label %bb66
bb66:
  %t318 = load { i64, ptr }, ptr %l151, !tbaa !27
  store { i64, ptr } %t318, ptr %l152, !tbaa !27
  %t319 = load { i64, ptr }, ptr %l152, !tbaa !27
  %t320 = extractvalue { i64, ptr } %t319, 0
  store i64 %t320, ptr %l153, !tbaa !24
  %t321 = load i64, ptr %l153, !tbaa !24
  %t322 = mul i64 %t321, 1
  %t323 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t322)
  %t324 = insertvalue { i64, ptr } undef, i64 %t321, 0
  %t325 = insertvalue { i64, ptr } %t324, ptr %t323, 1
  store { i64, ptr } %t325, ptr %l154, !tbaa !27
  %t326 = getelementptr { i64, ptr }, ptr %l154, i32 0, i32 1
  %t327 = load ptr, ptr %t326, !tbaa !27
  %t328 = getelementptr { i64, ptr }, ptr %l152, i32 0, i32 1
  %t329 = load ptr, ptr %t328, !tbaa !27
  %t330 = load i64, ptr %l153, !tbaa !24
  %t331 = mul i64 %t330, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t327, ptr %t329, i64 %t331, i1 false)
  %t332 = load { i64, ptr }, ptr %l154, !tbaa !27
  store { i64, ptr } %t332, ptr %l152, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t333 = load { i64, ptr }, ptr %l152, !tbaa !27
  store { i64, ptr } %t333, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eLoad(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i32
  %l8 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l13 = alloca i1
  %l15 = alloca { i64, ptr }
  %l23 = alloca ptr
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i32
  %l27 = alloca { i64, ptr }
  %l34 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca { i64, [3 x i64] }
  %l38 = alloca %"compiler/msgs:Msg"
  %l40 = alloca ptr
  %l41 = alloca ptr
  %l42 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l47 = alloca i64
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i64
  %t107 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/load:Loader", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v0, ptr %s0, { i64, ptr } %t4)
  %t7 = extractvalue { i32, { i64, ptr } } %t6, 1
  %t8 = extractvalue { i32, { i64, ptr } } %t6, 0
  store i32 %t8, ptr %l7
  %t9 = icmp ne i32 %t8, 0
  br i1 %t9, label %bb2, label %ok.10
ok.10:
  store { i64, ptr } %t7, ptr %l6
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t11, ptr %l3, !tbaa !27
  br label %bb4
bb2:
  br label %bb3
bb3:
  store { i64, ptr } { i64 0, ptr @.d30 }, ptr %l8, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t15 = extractvalue { i64, ptr } %t12, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l3, !tbaa !27
  br label %bb4
bb4:
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t21, ptr %l2, !tbaa !27
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l11, !tbaa !29
  %t23 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t25 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t23, { i64, ptr } { i64 0, ptr @.d31 })
  store i1 %t25, ptr %l13
  br label %bb5
bb5:
  %t26 = load i1, ptr %l13, !tbaa !21
  %t27 = xor i1 %t26, true
  br i1 %t27, label %bb6, label %bb7
bb6:
  %t29 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t29, 1
  %t32 = extractvalue { i64, ptr } %t29, 0
  %t33 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t32)
  call void @olang_textcopy(ptr %t33, ptr %t31, i64 %t32)
  %t34 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t33, 1
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t38 = extractvalue { i64, ptr } %t35, 1
  %t39 = mul i64 %t37, 1
  %t40 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t39)
  call void @llvm.memcpy.p0.p0.i64(ptr %t40, ptr %t38, i64 %t39, i1 false)
  %t41 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  store { i64, ptr } %t42, ptr %l15, !tbaa !27
  br label %bb8
bb7:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/load:Loader", ptr %t44, i32 0, i32 0
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t47, 1
  %t50 = extractvalue { i64, ptr } %t47, 0
  %t51 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t50)
  call void @olang_textcopy(ptr %t51, ptr %t49, i64 %t50)
  %t52 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t51, 1
  %t55 = extractvalue { i64, ptr } %t53, 0
  %t56 = extractvalue { i64, ptr } %t53, 1
  %t57 = mul i64 %t55, 1
  %t58 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t57)
  call void @llvm.memcpy.p0.p0.i64(ptr %t58, ptr %t56, i64 %t57, i1 false)
  %t59 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t58, 1
  store { i64, ptr } %t60, ptr %l15, !tbaa !27
  br label %bb8
bb8:
  %t62 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t63 = load ptr, ptr %l11, !tbaa !29
  %t64 = getelementptr %"compiler/load:Loader", ptr %t63, i32 0, i32 9
  store { i64, ptr } %t62, ptr %t64, !tbaa !27
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l23, !tbaa !29
  %t66 = call { i32, { i64, ptr } } @std_2fos_2eCwd(ptr %s0)
  %t67 = extractvalue { i32, { i64, ptr } } %t66, 1
  %t68 = extractvalue { i32, { i64, ptr } } %t66, 0
  store i32 %t68, ptr %l26
  %t69 = icmp ne i32 %t68, 0
  br i1 %t69, label %bb10, label %ok.70
ok.70:
  store { i64, ptr } %t67, ptr %l25
  br label %bb9
bb9:
  %t71 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t71, ptr %l24, !tbaa !27
  br label %bb12
bb10:
  br label %bb11
bb11:
  store { i64, ptr } { i64 1, ptr @.d32 }, ptr %l27, !tbaa !27
  %t72 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t74 = extractvalue { i64, ptr } %t72, 0
  %t75 = extractvalue { i64, ptr } %t72, 1
  %t76 = mul i64 %t74, 1
  %t77 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t76)
  call void @llvm.memcpy.p0.p0.i64(ptr %t77, ptr %t75, i64 %t76, i1 false)
  %t78 = insertvalue { i64, ptr } undef, i64 %t74, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t77, 1
  store { i64, ptr } %t79, ptr %l24, !tbaa !27
  br label %bb12
bb12:
  %t81 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t81, 1
  %t83 = extractvalue { i64, ptr } %t81, 0
  %t84 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t83)
  call void @olang_textcopy(ptr %t84, ptr %t82, i64 %t83)
  %t85 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t84, 1
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t89 = extractvalue { i64, ptr } %t86, 1
  %t90 = mul i64 %t88, 1
  %t91 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t90)
  call void @llvm.memcpy.p0.p0.i64(ptr %t91, ptr %t89, i64 %t90, i1 false)
  %t92 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t91, 1
  %t95 = load ptr, ptr %l23, !tbaa !29
  %t96 = getelementptr %"compiler/load:Loader", ptr %t95, i32 0, i32 10
  store { i64, ptr } %t93, ptr %t96, !tbaa !27
  %t97 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2eLoadPrelude(ptr %v0, ptr %t97)
  br label %bb13
bb13:
  %t99 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t101 = call i1 @std_2fos_2eIsDir(ptr %v1, { i64, ptr } %t99)
  store i1 %t101, ptr %l34
  br label %bb14
bb14:
  %t102 = load i1, ptr %l34, !tbaa !21
  br i1 %t102, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s4
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/load:Loader", ptr %t103, i32 0, i32 4
  %t106 = load ptr, ptr %t105, !tbaa !29
  store ptr %t106, ptr %l36, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t107
  %t108 = getelementptr { i64, [3 x i64] }, ptr %t107, i32 0, i32 0
  store i64 0, ptr %t108
  %t109 = load { i64, [3 x i64] }, ptr %t107
  store { i64, [3 x i64] } %t109, ptr %l37
  %t110 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eIsDirectory(ptr %s4)
  store %"compiler/msgs:Msg" %t110, ptr %l38
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t111 = load ptr, ptr %l36, !tbaa !29
  %t112 = load { i64, [3 x i64] }, ptr %l37
  %t113 = load %"compiler/msgs:Msg", ptr %l38
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v0, ptr %s4, ptr %t111, { i64, [3 x i64] } %t112, %"compiler/msgs:Msg" %t113)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb19:
  %t115 = load ptr, ptr %l0, !tbaa !29
  store ptr %t115, ptr %l40, !tbaa !29
  %t116 = load ptr, ptr %l0, !tbaa !29
  store ptr %t116, ptr %l41, !tbaa !29
  %t117 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t117, ptr %l42, !tbaa !27
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t122 = call { i64, ptr } @compiler_2fload_2ecompiler_2fload_3aLoader_2erootIdentity(ptr %v0, ptr %v1, ptr %s0, ptr %t118, { i64, ptr } %t119)
  store { i64, ptr } %t122, ptr %l45
  br label %bb20
bb20:
  %t123 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t123, 0
  %t125 = extractvalue { i64, ptr } %t123, 1
  %t126 = mul i64 %t124, 1
  %t127 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t126)
  call void @llvm.memcpy.p0.p0.i64(ptr %t127, ptr %t125, i64 %t126, i1 false)
  %t128 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t127, 1
  %t130 = load ptr, ptr %l41, !tbaa !29
  %t131 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t133 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eload(ptr %v0, ptr %v1, ptr %s0, ptr %t130, { i64, ptr } %t131, { i64, ptr } %t129, i1 false)
  store i64 %t133, ptr %l47
  br label %bb21
bb21:
  %t134 = load i64, ptr %l47, !tbaa !24
  %t135 = load ptr, ptr %l40, !tbaa !29
  %t136 = getelementptr %"compiler/load:Loader", ptr %t135, i32 0, i32 7
  store i64 %t134, ptr %t136, !tbaa !24
  %t137 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2echeckReach(ptr %v0, ptr %t137)
  br label %bb22
bb22:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/load:Loader", ptr %t139, i32 0, i32 7
  %t142 = load i64, ptr %t141, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t142, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fload_2ecompiler_2fload_3aLoader_2eLoadPrelude(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca %"compiler/scan:Tokens"
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca i32
  %l38 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l46 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l53 = alloca i1
  %l61 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l65 = alloca i32
  %l74 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l80 = alloca i32
  %l84 = alloca %"compiler/scan:Tokens"
  %l87 = alloca ptr
  %l88 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l92 = alloca i32
  %l101 = alloca { i64, ptr }
  %l120 = alloca { i64, ptr }
  %l123 = alloca { i64, ptr }
  %l124 = alloca i32
  %l133 = alloca { i64, ptr }
  %l136 = alloca ptr
  %l137 = alloca { i64, ptr }
  %l140 = alloca { i64, ptr }
  %l142 = alloca i64
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/load:Loader", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t4, { i64, ptr } { i64 7, ptr @.d33 }, { i64, ptr } { i64 0, ptr @.d3 }, { i64, ptr } { i64 0, ptr @.d4 }, { i64, ptr } { i64 0, ptr @.d5 }, { i64, ptr } { i64 0, ptr @.d6 })
  store { i64, ptr } %t6, ptr %l31
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t7, ptr %l1, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t10 = call { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %s0, ptr %s0, { i64, ptr } %t8)
  %t11 = extractvalue { i32, { i64, ptr } } %t10, 1
  %t12 = extractvalue { i32, { i64, ptr } } %t10, 0
  store i32 %t12, ptr %l35
  %t13 = icmp ne i32 %t12, 0
  br i1 %t13, label %bb3, label %ok.14
ok.14:
  store { i64, ptr } %t11, ptr %l34
  br label %bb2
bb2:
  %t15 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t15, ptr %l32, !tbaa !27
  br label %bb7
bb3:
  %t16 = load i32, ptr %l35, !tbaa !23
  %t17 = ashr i32 %t16, 16
  %t19 = icmp eq i32 %t17, 1
  br i1 %t19, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_73959507986a80b6_81fabf4f7ad77b72)
  unreachable
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb7:
  %t21 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t21, ptr %l2, !tbaa !27
  %t22 = load ptr, ptr @__olang_prog_scope
  %t23 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t22)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t23, ptr %l38
  br label %bb8
bb8:
  %t24 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l38
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t24, ptr %l3
  %t25 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t25, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t27 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  store i64 %t29, ptr %l6, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t31 = load i64, ptr %l5, !tbaa !24
  %t32 = load i64, ptr %l6, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb11:
  br label %bb12
bb12:
  %t39 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t39, ptr %l46, !tbaa !27
  %t40 = load i64, ptr %l5, !tbaa !24
  %t42 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr { i64, ptr }, ptr %t43, i64 %t40
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !37
  store { i64, ptr } %t45, ptr %l7, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t51 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %s0, ptr %s3, ptr %s3, ptr %s3, ptr %s3, ptr %s3, { i64, ptr } %t47, { i64, ptr } %t48, { i64, ptr } { i64 0, ptr @.d34 }, { i64, ptr } { i64 0, ptr @.d35 }, { i64, ptr } { i64 0, ptr @.d36 }, { i64, ptr } { i64 0, ptr @.d37 })
  store { i64, ptr } %t51, ptr %l51
  br label %bb13
bb13:
  %t52 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t52, ptr %l8, !tbaa !27
  %t53 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t55 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s0, ptr %s3, { i64, ptr } %t53, { i64, ptr } { i64 6, ptr @.d38 })
  store i1 %t55, ptr %l53
  br label %bb14
bb14:
  %t56 = load i1, ptr %l53, !tbaa !21
  br i1 %t56, label %bb15, label %bb16
bb15:
  %t57 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t57, 1
  %t60 = extractvalue { i64, ptr } %t57, 0
  %t61 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t60)
  call void @olang_textcopy(ptr %t61, ptr %t59, i64 %t60)
  %t62 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t61, 1
  %t65 = extractvalue { i64, ptr } %t63, 0
  %t66 = extractvalue { i64, ptr } %t63, 1
  %t67 = mul i64 %t65, 1
  %t68 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t67)
  call void @llvm.memcpy.p0.p0.i64(ptr %t68, ptr %t66, i64 %t67, i1 false)
  %t69 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t70 = insertvalue { i64, ptr } %t69, ptr %t68, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l3, { i64, ptr } %t70)
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb19:
  %t73 = load i64, ptr %l5, !tbaa !24
  %t75 = add i64 %t73, 1
  store i64 %t75, ptr %l5, !tbaa !24
  br label %bb9
bb20:
  store ptr %l3, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s8
  %t78 = load ptr, ptr %l9, !tbaa !29
  %t79 = load i64, ptr %l10, !tbaa !24
  %t82 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %s0, ptr %t78, i64 %t79)
  %t83 = extractvalue { i32, { i64, ptr } } %t82, 1
  %t84 = extractvalue { i32, { i64, ptr } } %t82, 0
  store i32 %t84, ptr %l65
  %t85 = icmp ne i32 %t84, 0
  br i1 %t85, label %bb23, label %ok.86
ok.86:
  store { i64, ptr } %t83, ptr %l64
  br label %bb22
bb22:
  %t87 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t87, ptr %l61, !tbaa !27
  br label %bb27
bb23:
  %t88 = load i32, ptr %l65, !tbaa !23
  %t89 = ashr i32 %t88, 16
  %t91 = icmp eq i32 %t89, 1
  br i1 %t91, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_568c45cfad451457_e2631f8594a96ff3)
  unreachable
bb26:
  call void @__olang_scope_close(ptr %s8)
  br label %bb59
bb27:
  %t93 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t93, ptr %l11, !tbaa !27
  %t94 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t96 = extractvalue { i64, ptr } %t94, 0
  store i64 %t96, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb28
bb28:
  store %olang.scope zeroinitializer, ptr %s9
  %t98 = load i64, ptr %l13, !tbaa !24
  %t99 = load i64, ptr %l12, !tbaa !24
  %t102 = icmp slt i64 %t98, %t99
  %t104 = xor i1 %t102, true
  br i1 %t104, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s9)
  br label %bb57
bb30:
  br label %bb31
bb31:
  %t106 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t106, ptr %l74, !tbaa !27
  %t107 = load i64, ptr %l13, !tbaa !24
  %t109 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = getelementptr { i64, ptr }, ptr %t110, i64 %t107
  %t112 = load { i64, ptr }, ptr %t111, !tbaa !37
  %t116 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s9, { i64, ptr } %t112)
  %t117 = extractvalue { i32, { i64, ptr } } %t116, 1
  %t118 = extractvalue { i32, { i64, ptr } } %t116, 0
  store i32 %t118, ptr %l80
  %t119 = icmp ne i32 %t118, 0
  br i1 %t119, label %bb33, label %ok.120
ok.120:
  store { i64, ptr } %t117, ptr %l79
  br label %bb32
bb32:
  %t121 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t121, ptr %l77, !tbaa !27
  br label %bb37
bb33:
  %t122 = load i32, ptr %l80, !tbaa !23
  %t123 = ashr i32 %t122, 16
  %t125 = icmp eq i32 %t123, 1
  br i1 %t125, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_155d5a878ef69f1c_357df84449aa70d8)
  unreachable
bb36:
  call void @__olang_scope_close(ptr %s9)
  br label %bb56
bb37:
  %t127 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t127, ptr %l15, !tbaa !27
  %t128 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t130 = call %"compiler/scan:Tokens" @compiler_2fscan_2eScan(ptr %s9, ptr %s9, { i64, ptr } %t128)
  store %"compiler/scan:Tokens" %t130, ptr %l84
  br label %bb38
bb38:
  %t131 = load %"compiler/scan:Tokens", ptr %l84
  store %"compiler/scan:Tokens" %t131, ptr %l16
  %t132 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t135 = call ptr @compiler_2fload_2etypeNames(ptr %s9, ptr %s9, { i64, ptr } %t132, ptr %l16)
  store ptr %t135, ptr %l87
  br label %bb39
bb39:
  %t136 = load ptr, ptr %l87, !tbaa !29
  store ptr %t136, ptr %l17, !tbaa !29
  store i64 0, ptr %l18, !tbaa !24
  br label %bb40
bb40:
  store %olang.scope zeroinitializer, ptr %s12
  %t137 = load ptr, ptr %l17, !tbaa !29
  %t138 = load i64, ptr %l18, !tbaa !24
  %t141 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %s9, ptr %t137, i64 %t138)
  %t142 = extractvalue { i32, { i64, ptr } } %t141, 1
  %t143 = extractvalue { i32, { i64, ptr } } %t141, 0
  store i32 %t143, ptr %l92
  %t144 = icmp ne i32 %t143, 0
  br i1 %t144, label %bb42, label %ok.145
ok.145:
  store { i64, ptr } %t142, ptr %l91
  br label %bb41
bb41:
  %t146 = load { i64, ptr }, ptr %l91, !tbaa !27
  store { i64, ptr } %t146, ptr %l88, !tbaa !27
  br label %bb46
bb42:
  %t147 = load i32, ptr %l92, !tbaa !23
  %t148 = ashr i32 %t147, 16
  %t150 = icmp eq i32 %t148, 1
  br i1 %t150, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  call void @__olang_check_failed(ptr @olang_loc_c5ef9e9b040d874d_a4c08c1d690343a9)
  unreachable
bb45:
  call void @__olang_scope_close(ptr %s12)
  br label %bb55
bb46:
  %t152 = load { i64, ptr }, ptr %l88, !tbaa !27
  store { i64, ptr } %t152, ptr %l19, !tbaa !27
  %t153 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t155 = extractvalue { i64, ptr } %t153, 0
  store i64 %t155, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb47
bb47:
  store %olang.scope zeroinitializer, ptr %s13
  %t157 = load i64, ptr %l21, !tbaa !24
  %t158 = load i64, ptr %l20, !tbaa !24
  %t161 = icmp slt i64 %t157, %t158
  %t163 = xor i1 %t161, true
  br i1 %t163, label %bb48, label %bb49
bb48:
  call void @__olang_scope_close(ptr %s13)
  br label %bb53
bb49:
  br label %bb50
bb50:
  %t165 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t165, ptr %l101, !tbaa !27
  %t166 = load i64, ptr %l21, !tbaa !24
  %t168 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !27
  %t170 = getelementptr { i64, ptr }, ptr %t169, i64 %t166
  %t171 = load { i64, ptr }, ptr %t170, !tbaa !37
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr %"compiler/load:Loader", ptr %t173, i32 0, i32 6
  %t178 = extractvalue { i64, ptr } %t171, 1
  %t179 = extractvalue { i64, ptr } %t171, 0
  %t180 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t179)
  call void @olang_textcopy(ptr %t180, ptr %t178, i64 %t179)
  %t181 = insertvalue { i64, ptr } undef, i64 %t179, 0
  %t182 = insertvalue { i64, ptr } %t181, ptr %t180, 1
  %t184 = extractvalue { i64, ptr } %t182, 0
  %t185 = extractvalue { i64, ptr } %t182, 1
  %t186 = mul i64 %t184, 1
  %t187 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t186)
  call void @llvm.memcpy.p0.p0.i64(ptr %t187, ptr %t185, i64 %t186, i1 false)
  %t188 = insertvalue { i64, ptr } undef, i64 %t184, 0
  %t189 = insertvalue { i64, ptr } %t188, ptr %t187, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v0, ptr %t175, { i64, ptr } %t189)
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s13)
  br label %bb52
bb52:
  %t192 = load i64, ptr %l21, !tbaa !24
  %t194 = add i64 %t192, 1
  store i64 %t194, ptr %l21, !tbaa !24
  br label %bb47
bb53:
  %t196 = load i64, ptr %l18, !tbaa !24
  %t197 = load i64, ptr %l20, !tbaa !24
  %t200 = add i64 %t196, %t197
  store i64 %t200, ptr %l18, !tbaa !24
  call void @__olang_scope_close(ptr %s12)
  br label %bb54
bb54:
  br label %bb40
bb55:
  call void @__olang_scope_close(ptr %s9)
  br label %bb56
bb56:
  %t202 = load i64, ptr %l13, !tbaa !24
  %t204 = add i64 %t202, 1
  store i64 %t204, ptr %l13, !tbaa !24
  br label %bb28
bb57:
  %t206 = load i64, ptr %l10, !tbaa !24
  %t207 = load i64, ptr %l12, !tbaa !24
  %t210 = add i64 %t206, %t207
  store i64 %t210, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s8)
  br label %bb58
bb58:
  br label %bb21
bb59:
  store ptr %l3, ptr %l23, !tbaa !29
  store i64 0, ptr %l24, !tbaa !24
  br label %bb60
bb60:
  store %olang.scope zeroinitializer, ptr %s18
  %t213 = load ptr, ptr %l23, !tbaa !29
  %t214 = load i64, ptr %l24, !tbaa !24
  %t217 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %s0, ptr %t213, i64 %t214)
  %t218 = extractvalue { i32, { i64, ptr } } %t217, 1
  %t219 = extractvalue { i32, { i64, ptr } } %t217, 0
  store i32 %t219, ptr %l124
  %t220 = icmp ne i32 %t219, 0
  br i1 %t220, label %bb62, label %ok.221
ok.221:
  store { i64, ptr } %t218, ptr %l123
  br label %bb61
bb61:
  %t222 = load { i64, ptr }, ptr %l123, !tbaa !27
  store { i64, ptr } %t222, ptr %l120, !tbaa !27
  br label %bb66
bb62:
  %t223 = load i32, ptr %l124, !tbaa !23
  %t224 = ashr i32 %t223, 16
  %t226 = icmp eq i32 %t224, 1
  br i1 %t226, label %bb63, label %bb64
bb63:
  br label %bb65
bb64:
  call void @__olang_check_failed(ptr @olang_loc_766341541344483a_b19cf45a67b9d8ce)
  unreachable
bb65:
  call void @__olang_scope_close(ptr %s18)
  br label %bb76
bb66:
  %t228 = load { i64, ptr }, ptr %l120, !tbaa !27
  store { i64, ptr } %t228, ptr %l25, !tbaa !27
  %t229 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t231 = extractvalue { i64, ptr } %t229, 0
  store i64 %t231, ptr %l26, !tbaa !24
  store i64 0, ptr %l27, !tbaa !24
  br label %bb67
bb67:
  store %olang.scope zeroinitializer, ptr %s19
  %t233 = load i64, ptr %l27, !tbaa !24
  %t234 = load i64, ptr %l26, !tbaa !24
  %t237 = icmp slt i64 %t233, %t234
  %t239 = xor i1 %t237, true
  br i1 %t239, label %bb68, label %bb69
bb68:
  call void @__olang_scope_close(ptr %s19)
  br label %bb74
bb69:
  br label %bb70
bb70:
  %t241 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t241, ptr %l133, !tbaa !27
  %t242 = load i64, ptr %l27, !tbaa !24
  %t244 = getelementptr { i64, ptr }, ptr %l133, i32 0, i32 1
  %t245 = load ptr, ptr %t244, !tbaa !27
  %t246 = getelementptr { i64, ptr }, ptr %t245, i64 %t242
  %t247 = load { i64, ptr }, ptr %t246, !tbaa !37
  store { i64, ptr } %t247, ptr %l28, !tbaa !27
  %t249 = load ptr, ptr %l0, !tbaa !29
  store ptr %t249, ptr %l136, !tbaa !29
  %t250 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t250, ptr %l137, !tbaa !27
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t252 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t255 = call { i64, ptr } @compiler_2fload_2ecompiler_2fload_3aLoader_2erootIdentity(ptr %v0, ptr %s0, ptr %s19, ptr %t251, { i64, ptr } %t252)
  store { i64, ptr } %t255, ptr %l140
  br label %bb71
bb71:
  %t256 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t257 = extractvalue { i64, ptr } %t256, 0
  %t258 = extractvalue { i64, ptr } %t256, 1
  %t259 = mul i64 %t257, 1
  %t260 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t259)
  call void @llvm.memcpy.p0.p0.i64(ptr %t260, ptr %t258, i64 %t259, i1 false)
  %t261 = insertvalue { i64, ptr } undef, i64 %t257, 0
  %t262 = insertvalue { i64, ptr } %t261, ptr %t260, 1
  %t263 = load ptr, ptr %l136, !tbaa !29
  %t264 = load { i64, ptr }, ptr %l137, !tbaa !27
  %t266 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eload(ptr %v0, ptr %s0, ptr %s19, ptr %t263, { i64, ptr } %t264, { i64, ptr } %t262, i1 true)
  store i64 %t266, ptr %l142
  br label %bb72
bb72:
  call void @__olang_scope_close(ptr %s19)
  br label %bb73
bb73:
  %t267 = load i64, ptr %l27, !tbaa !24
  %t269 = add i64 %t267, 1
  store i64 %t269, ptr %l27, !tbaa !24
  br label %bb67
bb74:
  %t271 = load i64, ptr %l24, !tbaa !24
  %t272 = load i64, ptr %l26, !tbaa !24
  %t275 = add i64 %t271, %t272
  store i64 %t275, ptr %l24, !tbaa !24
  call void @__olang_scope_close(ptr %s18)
  br label %bb75
bb75:
  br label %bb60
bb76:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fload_2ecompiler_2fload_3aLoader_2ePendingIfs(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l18 = alloca i64
  %l22 = alloca i64
  %l25 = alloca i64
  %l46 = alloca ptr
  %l49 = alloca i64
  %l53 = alloca i64
  %l56 = alloca i64
  %l80 = alloca i64
  %l83 = alloca i1
  %l84 = alloca ptr
  %l85 = alloca i64
  %l89 = alloca i64
  %l90 = alloca i64
  %l92 = alloca ptr
  %l93 = alloca i64
  %l97 = alloca i32
  %l98 = alloca %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20"
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20I32_3e_3e(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l15
  br label %bb1
bb1:
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t3, ptr %lp1
  %t4 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l15
  %t5 = load ptr, ptr %lp1
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %t5
  store i64 0, ptr %l2, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/load:Loader", ptr %t6, i32 0, i32 5
  %t10 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l18
  br label %bb2
bb2:
  %t11 = load i64, ptr %l18, !tbaa !24
  store i64 %t11, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = load i64, ptr %l2, !tbaa !24
  %t16 = icmp sgt i64 %t12, %t13
  br i1 %t16, label %bb3, label %bb4
bb3:
  %t18 = load i64, ptr %l4, !tbaa !24
  %t20 = icmp sgt i64 %t18, 0
  br i1 %t20, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb8
bb5:
  %t22 = load i64, ptr %l3, !tbaa !24
  %t23 = load i64, ptr %l2, !tbaa !24
  %t26 = sub i64 %t22, %t23
  %t27 = load i64, ptr %l4, !tbaa !24
  %t30 = add i64 %t26, %t27
  %t32 = sub i64 %t30, 1
  %t33 = load i64, ptr %l4, !tbaa !24
  %t36 = sdiv i64 %t32, %t33
  store i64 %t36, ptr %l25, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb7
bb7:
  %t38 = load i64, ptr %l25, !tbaa !24
  store i64 %t38, ptr %l22, !tbaa !24
  br label %bb8
bb8:
  %t39 = load i64, ptr %l22, !tbaa !24
  store i64 %t39, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t40 = load i64, ptr %l6, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = icmp slt i64 %t40, %t41
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb41
bb11:
  br label %bb12
bb12:
  %t48 = load i64, ptr %l2, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  %t50 = load i64, ptr %l4, !tbaa !24
  %t53 = mul i64 %t49, %t50
  %t56 = add i64 %t48, %t53
  store i64 %t56, ptr %l7, !tbaa !24
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/load:Loader", ptr %t58, i32 0, i32 5
  %t61 = load i64, ptr %l7, !tbaa !24
  %t64 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t60, i64 %t61)
  store ptr %t64, ptr %l46
  br label %bb13
bb13:
  %t65 = load ptr, ptr %l46, !tbaa !29
  store ptr %t65, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  %t66 = load ptr, ptr %l8, !tbaa !29
  %t68 = getelementptr %"compiler/load:Module", ptr %t66, i32 0, i32 14
  %t70 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2eLen_3cI32_3e(ptr %v0, ptr %t68)
  store i64 %t70, ptr %l49
  br label %bb14
bb14:
  %t71 = load i64, ptr %l49, !tbaa !24
  store i64 %t71, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t72 = load i64, ptr %l10, !tbaa !24
  %t73 = load i64, ptr %l9, !tbaa !24
  %t76 = icmp sgt i64 %t72, %t73
  br i1 %t76, label %bb15, label %bb16
bb15:
  %t78 = load i64, ptr %l11, !tbaa !24
  %t80 = icmp sgt i64 %t78, 0
  br i1 %t80, label %bb17, label %bb18
bb16:
  store i64 0, ptr %l53, !tbaa !24
  br label %bb20
bb17:
  %t82 = load i64, ptr %l10, !tbaa !24
  %t83 = load i64, ptr %l9, !tbaa !24
  %t86 = sub i64 %t82, %t83
  %t87 = load i64, ptr %l11, !tbaa !24
  %t90 = add i64 %t86, %t87
  %t92 = sub i64 %t90, 1
  %t93 = load i64, ptr %l11, !tbaa !24
  %t96 = sdiv i64 %t92, %t93
  store i64 %t96, ptr %l56, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l56, !tbaa !24
  br label %bb19
bb19:
  %t98 = load i64, ptr %l56, !tbaa !24
  store i64 %t98, ptr %l53, !tbaa !24
  br label %bb20
bb20:
  %t99 = load i64, ptr %l53, !tbaa !24
  store i64 %t99, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s4
  %t100 = load i64, ptr %l13, !tbaa !24
  %t101 = load i64, ptr %l12, !tbaa !24
  %t104 = icmp slt i64 %t100, %t101
  %t106 = xor i1 %t104, true
  br i1 %t106, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s4)
  br label %bb39
bb23:
  br label %bb24
bb24:
  %t108 = load i64, ptr %l9, !tbaa !24
  %t109 = load i64, ptr %l13, !tbaa !24
  %t110 = load i64, ptr %l11, !tbaa !24
  %t113 = mul i64 %t109, %t110
  %t116 = add i64 %t108, %t113
  store i64 %t116, ptr %l14, !tbaa !24
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load i64, ptr %l7, !tbaa !24
  %t120 = load i64, ptr %l14, !tbaa !24
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2edecide(ptr %v0, ptr %t118, i64 %t119, i64 %t120)
  br label %bb25
bb25:
  %t124 = load ptr, ptr %l8, !tbaa !29
  %t126 = getelementptr %"compiler/load:Module", ptr %t124, i32 0, i32 16
  %t127 = load i64, ptr %l14, !tbaa !24
  %t130 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t126, i64 %t127)
  store i64 %t130, ptr %l80
  br label %bb26
bb26:
  %t131 = load i64, ptr @G_2ecompiler_2fload_2ePending, !tbaa !24
  %t132 = load i64, ptr %l80, !tbaa !24
  %t134 = icmp eq i64 %t132, %t131
  br i1 %t134, label %bb27, label %bb28
bb27:
  %t136 = load ptr, ptr %l0, !tbaa !29
  store ptr %t136, ptr %l84, !tbaa !29
  %t137 = load i64, ptr %l7, !tbaa !24
  store i64 %t137, ptr %l85, !tbaa !24
  %t138 = load ptr, ptr %l8, !tbaa !29
  %t140 = getelementptr %"compiler/load:Module", ptr %t138, i32 0, i32 15
  %t141 = load i64, ptr %l14, !tbaa !24
  %t144 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t140, i64 %t141)
  store i64 %t144, ptr %l89
  br label %bb29
bb28:
  store i1 false, ptr %l83, !tbaa !21
  br label %bb31
bb29:
  %t145 = load ptr, ptr %l84, !tbaa !29
  %t146 = load i64, ptr %l85, !tbaa !24
  %t147 = load i64, ptr %l89, !tbaa !24
  %t148 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2etaken(ptr %v0, ptr %t145, i64 %t146, i64 %t147)
  store i64 %t148, ptr %l90
  br label %bb30
bb30:
  %t149 = load i64, ptr %l90, !tbaa !24
  %t150 = icmp eq i64 %t149, 1
  store i1 %t150, ptr %l83, !tbaa !21
  br label %bb31
bb31:
  %t152 = load i1, ptr %l83, !tbaa !21
  br i1 %t152, label %bb32, label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s5
  %t153 = load ptr, ptr %lp1
  store ptr %t153, ptr %l92, !tbaa !29
  %t154 = load i64, ptr %l7, !tbaa !24
  store i64 %t154, ptr %l93, !tbaa !24
  %t155 = load ptr, ptr %l8, !tbaa !29
  %t157 = getelementptr %"compiler/load:Module", ptr %t155, i32 0, i32 14
  %t158 = load i64, ptr %l14, !tbaa !24
  %t161 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2eAt_3cI32_3e(ptr %v0, ptr %t157, i64 %t158)
  store i32 %t161, ptr %l97
  br label %bb34
bb33:
  br label %bb37
bb34:
  %t162 = load i64, ptr %l93, !tbaa !24
  %t163 = load i32, ptr %l97, !tbaa !23
  %t164 = call %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" @std_2fpair_3aPair_3cI64_2c_20I32_3e_2ector(ptr %s5, i64 %t162, i32 %t163)
  store %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" %t164, ptr %l98
  br label %bb35
bb35:
  %t165 = load ptr, ptr %l92, !tbaa !29
  %t166 = load %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l98
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20I32_3e_Hd7be20793e0d40c909f29debacc96a43(ptr %v1, ptr %t165, %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" %t166)
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s5)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s4)
  br label %bb38
bb38:
  %t167 = load i64, ptr %l13, !tbaa !24
  %t169 = add i64 %t167, 1
  store i64 %t169, ptr %l13, !tbaa !24
  br label %bb21
bb39:
  call void @__olang_scope_close(ptr %s2)
  br label %bb40
bb40:
  %t171 = load i64, ptr %l6, !tbaa !24
  %t173 = add i64 %t171, 1
  store i64 %t173, ptr %l6, !tbaa !24
  br label %bb9
bb41:
  %t175 = load ptr, ptr %lp1
  %t176 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t175
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t176, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local { i64, [3 x i64] } @compiler_2fload_2ecompiler_2fload_3aLoader_2eat(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %rv = alloca { i64, [3 x i64] }
  %t13 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/load:Module", ptr %a1, i32 0, i32 4
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t6 = load i32, ptr %t5, !tbaa !23
  %t8 = sext i32 %t6 to i64
  %t9 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 1
  %t10 = load i32, ptr %t9, !tbaa !23
  %t12 = sext i32 %t10 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t13
  %t14 = getelementptr { i64, [3 x i64] }, ptr %t13, i32 0, i32 0
  store i64 3, ptr %t14
  %t16 = insertvalue { i64, i64, i64 } undef, i64 %t4, 0
  %t18 = insertvalue { i64, i64, i64 } %t16, i64 %t8, 1
  %t20 = insertvalue { i64, i64, i64 } %t18, i64 %t12, 2
  %t21 = getelementptr { i64, [3 x i64] }, ptr %t13, i32 0, i32 1
  store { i64, i64, i64 } %t20, ptr %t21
  %t22 = load { i64, [3 x i64] }, ptr %t13
  store { i64, [3 x i64] } %t22, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [3 x i64] }, ptr %rv
  ret { i64, [3 x i64] } %rr
}

define dso_local i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2ebranch(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l12 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/load:Module", ptr %t1, i32 0, i32 20
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t3, i64 %a2)
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t9 = getelementptr %"compiler/load:Module", ptr %t7, i32 0, i32 21
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t9, i64 %a3)
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"compiler/load:Module", ptr %t13, i32 0, i32 20
  %t17 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t15)
  store i64 %t17, ptr %l12
  br label %bb3
bb3:
  %t18 = load i64, ptr %l12, !tbaa !24
  %t19 = sub i64 %t18, 1
  store i64 %t19, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fload_2ecompiler_2fload_3aLoader_2ebranchGroup(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t2 = load i64, ptr @G_2ecompiler_2fload_2ePending, !tbaa !24
  %t5 = icmp eq i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp eq i64 %t7, %a4
  br i1 %t11, label %bb4, label %bb5
bb4:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/load:Loader", ptr %t13, i32 0, i32 4
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t19 = getelementptr %"compiler/ast:TopBranch", ptr %t17, i32 0, i32 2
  %t20 = load i64, ptr %t19, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eChoose(ptr %v0, ptr %t16, i64 %t20)
  br label %bb6
bb5:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/load:Loader", ptr %t23, i32 0, i32 4
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t29 = getelementptr %"compiler/ast:TopBranch", ptr %t27, i32 0, i32 2
  %t30 = load i64, ptr %t29, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eDrop(ptr %v0, ptr %t26, i64 %t30)
  br label %bb11
bb6:
  %t33 = load ptr, ptr %l2, !tbaa !29
  %t35 = getelementptr %"compiler/ast:TopBranch", ptr %t33, i32 0, i32 1
  %t36 = load { i64, ptr }, ptr %t35, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t36, 0
  %t40 = icmp sgt i64 %t38, 0
  br i1 %t40, label %bb7, label %bb8
bb7:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = load ptr, ptr %l2, !tbaa !29
  %t46 = getelementptr %"compiler/ast:TopBranch", ptr %t44, i32 0, i32 1
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !27
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2egroups(ptr %v0, ptr %v1, ptr %t42, i64 %a1, { i64, ptr } %t47)
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb10
bb10:
  br label %bb12
bb11:
  br label %bb12
bb12:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fload_2ecompiler_2fload_3aLoader_2echainGroups(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  store i64 %t2, ptr %l6, !tbaa !24
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t5 = getelementptr %"compiler/ast:TopIf", ptr %t3, i32 0, i32 1
  %t6 = load ptr, ptr %t5, !tbaa !29
  %t8 = icmp eq ptr %t6, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_c7262fe51519f763_af68021c51d3e65f)
  unreachable
bb2:
  br label %bb3
bb3:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"compiler/ast:TopIf", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t16 = load ptr, ptr %l5, !tbaa !29
  %t17 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2ebranchGroup(ptr %v0, ptr %v1, ptr %t16, i64 %t17, ptr %t13, i64 %t14, i64 %t15)
  br label %bb4
bb4:
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"compiler/ast:TopIf", ptr %t21, i32 0, i32 2
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = icmp eq ptr %t24, null
  %t28 = xor i1 %t26, true
  br i1 %t28, label %bb5, label %bb6
bb5:
  %t30 = load ptr, ptr %l0, !tbaa !29
  store ptr %t30, ptr %l18, !tbaa !29
  %t31 = load i64, ptr %l1, !tbaa !24
  store i64 %t31, ptr %l19, !tbaa !24
  %t32 = load ptr, ptr %l2, !tbaa !29
  %t34 = getelementptr %"compiler/ast:TopIf", ptr %t32, i32 0, i32 2
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = icmp eq ptr %t35, null
  br i1 %t37, label %bb7, label %bb8
bb6:
  br label %bb11
bb7:
  call void @__olang_check_failed(ptr @olang_loc_5374637873936654_bf4b9d38f6a4cac0)
  unreachable
bb8:
  br label %bb9
bb9:
  %t39 = load ptr, ptr %l2, !tbaa !29
  %t41 = getelementptr %"compiler/ast:TopIf", ptr %t39, i32 0, i32 2
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t43 = load i64, ptr %l3, !tbaa !24
  %t44 = load i64, ptr %l4, !tbaa !24
  %t46 = add i64 %t44, 1
  %t47 = load ptr, ptr %l18, !tbaa !29
  %t48 = load i64, ptr %l19, !tbaa !24
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2echainGroups(ptr %v0, ptr %v1, ptr %t47, i64 %t48, ptr %t42, i64 %t43, i64 %t46)
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t52 = load ptr, ptr %l2, !tbaa !29
  %t54 = getelementptr %"compiler/ast:TopIf", ptr %t52, i32 0, i32 3
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = icmp eq ptr %t55, null
  %t59 = xor i1 %t57, true
  br i1 %t59, label %bb12, label %bb13
bb12:
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l32, !tbaa !29
  %t62 = load i64, ptr %l1, !tbaa !24
  store i64 %t62, ptr %l33, !tbaa !24
  %t63 = load ptr, ptr %l2, !tbaa !29
  %t65 = getelementptr %"compiler/ast:TopIf", ptr %t63, i32 0, i32 3
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = icmp eq ptr %t66, null
  br i1 %t68, label %bb14, label %bb15
bb13:
  br label %bb18
bb14:
  call void @__olang_check_failed(ptr @olang_loc_a9d5346f51b5ce49_2177b031869164d5)
  unreachable
bb15:
  br label %bb16
bb16:
  %t70 = load ptr, ptr %l2, !tbaa !29
  %t72 = getelementptr %"compiler/ast:TopIf", ptr %t70, i32 0, i32 3
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t74 = load i64, ptr %l3, !tbaa !24
  %t75 = load i64, ptr %l4, !tbaa !24
  %t77 = add i64 %t75, 1
  %t78 = load ptr, ptr %l32, !tbaa !29
  %t79 = load i64, ptr %l33, !tbaa !24
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2ebranchGroup(ptr %v0, ptr %v1, ptr %t78, i64 %t79, ptr %t73, i64 %t74, i64 %t77)
  br label %bb17
bb17:
  br label %bb18
bb18:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fload_2ecompiler_2fload_3aLoader_2echains(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2, { i64, ptr } %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"compiler/load:Import"
  %l11 = alloca { i64, ptr }
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l29 = alloca ptr
  %l32 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca i32
  %l45 = alloca { i64, ptr }
  %l56 = alloca ptr
  %l59 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l63 = alloca i32
  %l72 = alloca { i64, ptr }
  %l88 = alloca ptr
  %l91 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l95 = alloca i32
  %l104 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l4, !tbaa !24
  %t3 = icmp sge i64 %t1, 4
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/load:Loader", ptr %t5, i32 0, i32 5
  %t11 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t7, i64 %a2)
  store ptr %t11, ptr %l29
  br label %bb4
bb4:
  %t12 = load ptr, ptr %l29, !tbaa !29
  %t14 = getelementptr %"compiler/load:Module", ptr %t12, i32 0, i32 11
  store ptr %t14, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t16 = load ptr, ptr %l5, !tbaa !29
  %t17 = load i64, ptr %l6, !tbaa !24
  %t20 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2eRunFrom_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %t16, i64 %t17)
  %t21 = extractvalue { i32, { i64, ptr } } %t20, 1
  %t22 = extractvalue { i32, { i64, ptr } } %t20, 0
  store i32 %t22, ptr %l36
  %t23 = icmp ne i32 %t22, 0
  br i1 %t23, label %bb7, label %ok.24
ok.24:
  store { i64, ptr } %t21, ptr %l35
  br label %bb6
bb6:
  %t25 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t25, ptr %l32, !tbaa !27
  br label %bb11
bb7:
  %t26 = load i32, ptr %l36, !tbaa !23
  %t27 = ashr i32 %t26, 16
  %t29 = icmp eq i32 %t27, 1
  br i1 %t29, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_a4899dfb2f47d10d_f1c9b32274c1c5d9)
  unreachable
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb57
bb11:
  %t31 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t31, ptr %l7, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t32, 0
  store i64 %t34, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s4
  %t36 = load i64, ptr %l9, !tbaa !24
  %t37 = load i64, ptr %l8, !tbaa !24
  %t40 = icmp slt i64 %t36, %t37
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s4)
  br label %bb55
bb14:
  br label %bb15
bb15:
  %t44 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t44, ptr %l45, !tbaa !27
  %t45 = load i64, ptr %l9, !tbaa !24
  %t47 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr %"compiler/load:Import", ptr %t48, i64 %t45
  %t50 = load %"compiler/load:Import", ptr %t49
  store %"compiler/load:Import" %t50, ptr %l10
  %t52 = getelementptr %"compiler/load:Import", ptr %l10, i32 0, i32 5
  %t53 = load i64, ptr %t52, !tbaa !24
  %t55 = icmp slt i64 %t53, 0
  br i1 %t55, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s4)
  br label %bb54
bb17:
  br label %bb18
bb18:
  %t58 = getelementptr %"compiler/load:Import", ptr %l10, i32 0, i32 2
  %t59 = load { i64, ptr }, ptr %t58, !tbaa !27
  %t61 = extractvalue { i64, ptr } %a3, 1
  %t62 = extractvalue { i64, ptr } %a3, 0
  %t64 = extractvalue { i64, ptr } %t59, 1
  %t65 = extractvalue { i64, ptr } %t59, 0
  %t66 = add i64 %t62, %t65
  %t67 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t66)
  call void @olang_textcopy(ptr %t67, ptr %t61, i64 %t62)
  %t68 = getelementptr i8, ptr %t67, i64 %t62
  call void @olang_textcopy(ptr %t68, ptr %t64, i64 %t65)
  %t69 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t70 = insertvalue { i64, ptr } %t69, ptr %t67, 1
  store { i64, ptr } %t70, ptr %l11, !tbaa !27
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/load:Loader", ptr %t72, i32 0, i32 5
  %t75 = getelementptr %"compiler/load:Import", ptr %l10, i32 0, i32 5
  %t76 = load i64, ptr %t75, !tbaa !24
  %t79 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t74, i64 %t76)
  store ptr %t79, ptr %l56
  br label %bb19
bb19:
  %t80 = load ptr, ptr %l56, !tbaa !29
  %t82 = getelementptr %"compiler/load:Module", ptr %t80, i32 0, i32 9
  store ptr %t82, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s8
  %t84 = load ptr, ptr %l12, !tbaa !29
  %t85 = load i64, ptr %l13, !tbaa !24
  %t88 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v0, ptr %t84, i64 %t85)
  %t89 = extractvalue { i32, { i64, ptr } } %t88, 1
  %t90 = extractvalue { i32, { i64, ptr } } %t88, 0
  store i32 %t90, ptr %l63
  %t91 = icmp ne i32 %t90, 0
  br i1 %t91, label %bb22, label %ok.92
ok.92:
  store { i64, ptr } %t89, ptr %l62
  br label %bb21
bb21:
  %t93 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t93, ptr %l59, !tbaa !27
  br label %bb26
bb22:
  %t94 = load i32, ptr %l63, !tbaa !23
  %t95 = ashr i32 %t94, 16
  %t97 = icmp eq i32 %t95, 1
  br i1 %t97, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_d68b219fa2f37dc_2c4a1c709d04c08)
  unreachable
bb25:
  call void @__olang_scope_close(ptr %s8)
  br label %bb35
bb26:
  %t99 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t99, ptr %l14, !tbaa !27
  %t100 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t100, 0
  store i64 %t102, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb27
bb27:
  store %olang.scope zeroinitializer, ptr %s9
  %t104 = load i64, ptr %l16, !tbaa !24
  %t105 = load i64, ptr %l15, !tbaa !24
  %t108 = icmp slt i64 %t104, %t105
  %t110 = xor i1 %t108, true
  br i1 %t110, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s9)
  br label %bb33
bb29:
  br label %bb30
bb30:
  %t112 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t112, ptr %l72, !tbaa !27
  %t113 = load i64, ptr %l16, !tbaa !24
  %t115 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = getelementptr { i64, ptr }, ptr %t116, i64 %t113
  %t118 = load { i64, ptr }, ptr %t117, !tbaa !37
  %t120 = load ptr, ptr %l1, !tbaa !29
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/load:Loader", ptr %t121, i32 0, i32 3
  %t124 = load ptr, ptr %t123, !tbaa !29
  %t125 = load { i64, ptr }, ptr %l11, !tbaa !27
  call void @compiler_2fparse_2ecompiler_2fparse_3aOracle_2eAdd(ptr %v1, ptr %v0, ptr %s4, ptr %v0, ptr %t120, ptr %t124, { i64, ptr } %t125, { i64, ptr } %t118)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s9)
  br label %bb32
bb32:
  %t131 = load i64, ptr %l16, !tbaa !24
  %t133 = add i64 %t131, 1
  store i64 %t133, ptr %l16, !tbaa !24
  br label %bb27
bb33:
  %t135 = load i64, ptr %l13, !tbaa !24
  %t136 = load i64, ptr %l15, !tbaa !24
  %t139 = add i64 %t135, %t136
  store i64 %t139, ptr %l13, !tbaa !24
  call void @__olang_scope_close(ptr %s8)
  br label %bb34
bb34:
  br label %bb20
bb35:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/load:Loader", ptr %t141, i32 0, i32 5
  %t144 = getelementptr %"compiler/load:Import", ptr %l10, i32 0, i32 5
  %t145 = load i64, ptr %t144, !tbaa !24
  %t148 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t143, i64 %t145)
  store ptr %t148, ptr %l88
  br label %bb36
bb36:
  %t149 = load ptr, ptr %l88, !tbaa !29
  %t151 = getelementptr %"compiler/load:Module", ptr %t149, i32 0, i32 10
  store ptr %t151, ptr %l18, !tbaa !29
  store i64 0, ptr %l19, !tbaa !24
  br label %bb37
bb37:
  store %olang.scope zeroinitializer, ptr %s12
  %t153 = load ptr, ptr %l18, !tbaa !29
  %t154 = load i64, ptr %l19, !tbaa !24
  %t157 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v0, ptr %t153, i64 %t154)
  %t158 = extractvalue { i32, { i64, ptr } } %t157, 1
  %t159 = extractvalue { i32, { i64, ptr } } %t157, 0
  store i32 %t159, ptr %l95
  %t160 = icmp ne i32 %t159, 0
  br i1 %t160, label %bb39, label %ok.161
ok.161:
  store { i64, ptr } %t158, ptr %l94
  br label %bb38
bb38:
  %t162 = load { i64, ptr }, ptr %l94, !tbaa !27
  store { i64, ptr } %t162, ptr %l91, !tbaa !27
  br label %bb43
bb39:
  %t163 = load i32, ptr %l95, !tbaa !23
  %t164 = ashr i32 %t163, 16
  %t166 = icmp eq i32 %t164, 1
  br i1 %t166, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_495643cfc2e17017_d12bcc0a4d818fe3)
  unreachable
bb42:
  call void @__olang_scope_close(ptr %s12)
  br label %bb52
bb43:
  %t168 = load { i64, ptr }, ptr %l91, !tbaa !27
  store { i64, ptr } %t168, ptr %l20, !tbaa !27
  %t169 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t171 = extractvalue { i64, ptr } %t169, 0
  store i64 %t171, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb44
bb44:
  store %olang.scope zeroinitializer, ptr %s13
  %t173 = load i64, ptr %l22, !tbaa !24
  %t174 = load i64, ptr %l21, !tbaa !24
  %t177 = icmp slt i64 %t173, %t174
  %t179 = xor i1 %t177, true
  br i1 %t179, label %bb45, label %bb46
bb45:
  call void @__olang_scope_close(ptr %s13)
  br label %bb50
bb46:
  br label %bb47
bb47:
  %t181 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t181, ptr %l104, !tbaa !27
  %t182 = load i64, ptr %l22, !tbaa !24
  %t184 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t185 = load ptr, ptr %t184, !tbaa !27
  %t186 = getelementptr { i64, ptr }, ptr %t185, i64 %t182
  %t187 = load { i64, ptr }, ptr %t186, !tbaa !37
  %t189 = load ptr, ptr %l1, !tbaa !29
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t192 = getelementptr %"compiler/load:Loader", ptr %t190, i32 0, i32 3
  %t193 = load ptr, ptr %t192, !tbaa !29
  %t194 = load { i64, ptr }, ptr %l11, !tbaa !27
  call void @compiler_2fparse_2ecompiler_2fparse_3aOracle_2eAddFn(ptr %v1, ptr %v0, ptr %s4, ptr %v0, ptr %t189, ptr %t193, { i64, ptr } %t194, { i64, ptr } %t187)
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s13)
  br label %bb49
bb49:
  %t200 = load i64, ptr %l22, !tbaa !24
  %t202 = add i64 %t200, 1
  store i64 %t202, ptr %l22, !tbaa !24
  br label %bb44
bb50:
  %t204 = load i64, ptr %l19, !tbaa !24
  %t205 = load i64, ptr %l21, !tbaa !24
  %t208 = add i64 %t204, %t205
  store i64 %t208, ptr %l19, !tbaa !24
  call void @__olang_scope_close(ptr %s12)
  br label %bb51
bb51:
  br label %bb37
bb52:
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t211 = load ptr, ptr %l1, !tbaa !29
  %t212 = getelementptr %"compiler/load:Import", ptr %l10, i32 0, i32 5
  %t213 = load i64, ptr %t212, !tbaa !24
  %t214 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t216 = extractvalue { i64, ptr } %t214, 1
  %t217 = extractvalue { i64, ptr } %t214, 0
  %t218 = extractvalue { i64, ptr } { i64 1, ptr @.d39 }, 1
  %t219 = extractvalue { i64, ptr } { i64 1, ptr @.d39 }, 0
  %t220 = add i64 %t217, %t219
  %t221 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t220)
  call void @olang_textcopy(ptr %t221, ptr %t216, i64 %t217)
  %t222 = getelementptr i8, ptr %t221, i64 %t217
  call void @olang_textcopy(ptr %t222, ptr %t218, i64 %t219)
  %t223 = insertvalue { i64, ptr } undef, i64 %t220, 0
  %t224 = insertvalue { i64, ptr } %t223, ptr %t221, 1
  %t226 = extractvalue { i64, ptr } %t224, 0
  %t227 = extractvalue { i64, ptr } %t224, 1
  %t228 = mul i64 %t226, 1
  %t229 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t228)
  call void @llvm.memcpy.p0.p0.i64(ptr %t229, ptr %t227, i64 %t228, i1 false)
  %t230 = insertvalue { i64, ptr } undef, i64 %t226, 0
  %t231 = insertvalue { i64, ptr } %t230, ptr %t229, 1
  %t232 = load i64, ptr %l4, !tbaa !24
  %t234 = add i64 %t232, 1
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2echains(ptr %v0, ptr %v1, ptr %s4, ptr %t210, ptr %t211, i64 %t213, { i64, ptr } %t231, i64 %t234)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s4)
  br label %bb54
bb54:
  %t240 = load i64, ptr %l9, !tbaa !24
  %t242 = add i64 %t240, 1
  store i64 %t242, ptr %l9, !tbaa !24
  br label %bb12
bb55:
  %t244 = load i64, ptr %l6, !tbaa !24
  %t245 = load i64, ptr %l8, !tbaa !24
  %t248 = add i64 %t244, %t245
  store i64 %t248, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb56
bb56:
  br label %bb5
bb57:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fload_2ecompiler_2fload_3aLoader_2echeckReach(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca %"compiler/load:Import"
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l24 = alloca i64
  %l28 = alloca i64
  %l31 = alloca i64
  %l49 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l53 = alloca ptr
  %l56 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l60 = alloca i32
  %l69 = alloca { i64, ptr }
  %l79 = alloca ptr
  %l82 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l86 = alloca i32
  %l95 = alloca { i64, ptr }
  %l101 = alloca i1
  %l103 = alloca ptr
  %l107 = alloca { i64, [3 x i64] }
  %l109 = alloca { i64, ptr }
  %l111 = alloca %"compiler/msgs:Msg"
  %l112 = alloca i64
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/load:Loader", ptr %t1, i32 0, i32 5
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l24
  br label %bb1
bb1:
  %t6 = load i64, ptr %l24, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t8 = load i64, ptr %l1, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l3, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l2, !tbaa !24
  %t18 = load i64, ptr %l1, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l31, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l31, !tbaa !24
  store i64 %t33, ptr %l28, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l28, !tbaa !24
  store i64 %t34, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load i64, ptr %l5, !tbaa !24
  %t36 = load i64, ptr %l4, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb59
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l1, !tbaa !24
  %t44 = load i64, ptr %l5, !tbaa !24
  %t45 = load i64, ptr %l3, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l6, !tbaa !24
  %t53 = load ptr, ptr @__olang_prog_scope
  %t54 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t53)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t54, ptr %l49
  br label %bb12
bb12:
  %t55 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l49
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t55, ptr %l7
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/load:Loader", ptr %t56, i32 0, i32 5
  %t59 = load i64, ptr %l6, !tbaa !24
  %t62 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t58, i64 %t59)
  store ptr %t62, ptr %l53
  br label %bb13
bb13:
  %t63 = load ptr, ptr %l53, !tbaa !29
  store ptr %t63, ptr %l8, !tbaa !29
  %t64 = load ptr, ptr %l8, !tbaa !29
  %t66 = getelementptr %"compiler/load:Module", ptr %t64, i32 0, i32 11
  store ptr %t66, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s4
  %t68 = load ptr, ptr %l9, !tbaa !29
  %t69 = load i64, ptr %l10, !tbaa !24
  %t72 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2eRunFrom_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %t68, i64 %t69)
  %t73 = extractvalue { i32, { i64, ptr } } %t72, 1
  %t74 = extractvalue { i32, { i64, ptr } } %t72, 0
  store i32 %t74, ptr %l60
  %t75 = icmp ne i32 %t74, 0
  br i1 %t75, label %bb16, label %ok.76
ok.76:
  store { i64, ptr } %t73, ptr %l59
  br label %bb15
bb15:
  %t77 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t77, ptr %l56, !tbaa !27
  br label %bb20
bb16:
  %t78 = load i32, ptr %l60, !tbaa !23
  %t79 = ashr i32 %t78, 16
  %t81 = icmp eq i32 %t79, 1
  br i1 %t81, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_555f64ce3e1e7c9a_21848c58e72b35ee)
  unreachable
bb19:
  call void @__olang_scope_close(ptr %s4)
  br label %bb57
bb20:
  %t83 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t83, ptr %l11, !tbaa !27
  %t84 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t84, 0
  store i64 %t86, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s5
  %t88 = load i64, ptr %l13, !tbaa !24
  %t89 = load i64, ptr %l12, !tbaa !24
  %t92 = icmp slt i64 %t88, %t89
  %t94 = xor i1 %t92, true
  br i1 %t94, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s5)
  br label %bb55
bb23:
  br label %bb24
bb24:
  %t96 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t96, ptr %l69, !tbaa !27
  %t97 = load i64, ptr %l13, !tbaa !24
  %t99 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !27
  %t101 = getelementptr %"compiler/load:Import", ptr %t100, i64 %t97
  %t102 = load %"compiler/load:Import", ptr %t101
  store %"compiler/load:Import" %t102, ptr %l14
  %t104 = getelementptr %"compiler/load:Import", ptr %l14, i32 0, i32 5
  %t105 = load i64, ptr %t104, !tbaa !24
  %t107 = icmp slt i64 %t105, 0
  br i1 %t107, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s5)
  br label %bb54
bb26:
  br label %bb27
bb27:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/load:Import", ptr %l14, i32 0, i32 5
  %t111 = load i64, ptr %t110, !tbaa !24
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2eclosure(ptr %v0, ptr %t109, i64 %t111)
  br label %bb28
bb28:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/load:Loader", ptr %t114, i32 0, i32 5
  %t117 = getelementptr %"compiler/load:Import", ptr %l14, i32 0, i32 5
  %t118 = load i64, ptr %t117, !tbaa !24
  %t121 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t116, i64 %t118)
  store ptr %t121, ptr %l79
  br label %bb29
bb29:
  %t122 = load ptr, ptr %l79, !tbaa !29
  %t124 = getelementptr %"compiler/load:Module", ptr %t122, i32 0, i32 28
  store ptr %t124, ptr %l15, !tbaa !29
  store i64 0, ptr %l16, !tbaa !24
  br label %bb30
bb30:
  store %olang.scope zeroinitializer, ptr %s8
  %t126 = load ptr, ptr %l15, !tbaa !29
  %t127 = load i64, ptr %l16, !tbaa !24
  %t130 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %t126, i64 %t127)
  %t131 = extractvalue { i32, { i64, ptr } } %t130, 1
  %t132 = extractvalue { i32, { i64, ptr } } %t130, 0
  store i32 %t132, ptr %l86
  %t133 = icmp ne i32 %t132, 0
  br i1 %t133, label %bb32, label %ok.134
ok.134:
  store { i64, ptr } %t131, ptr %l85
  br label %bb31
bb31:
  %t135 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t135, ptr %l82, !tbaa !27
  br label %bb36
bb32:
  %t136 = load i32, ptr %l86, !tbaa !23
  %t137 = ashr i32 %t136, 16
  %t139 = icmp eq i32 %t137, 1
  br i1 %t139, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_91e287b3951b969b_9736b657bc6cd6af)
  unreachable
bb35:
  call void @__olang_scope_close(ptr %s8)
  br label %bb53
bb36:
  %t141 = load { i64, ptr }, ptr %l82, !tbaa !27
  store { i64, ptr } %t141, ptr %l17, !tbaa !27
  %t142 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t144 = extractvalue { i64, ptr } %t142, 0
  store i64 %t144, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb37
bb37:
  store %olang.scope zeroinitializer, ptr %s9
  %t146 = load i64, ptr %l19, !tbaa !24
  %t147 = load i64, ptr %l18, !tbaa !24
  %t150 = icmp slt i64 %t146, %t147
  %t152 = xor i1 %t150, true
  br i1 %t152, label %bb38, label %bb39
bb38:
  call void @__olang_scope_close(ptr %s9)
  br label %bb51
bb39:
  br label %bb40
bb40:
  %t154 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t154, ptr %l95, !tbaa !27
  %t155 = load i64, ptr %l19, !tbaa !24
  %t157 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !27
  %t159 = getelementptr i64, ptr %t158, i64 %t155
  %t160 = load i64, ptr %t159, !tbaa !34
  store i64 %t160, ptr %l20, !tbaa !24
  %t162 = load i64, ptr %l20, !tbaa !24
  %t167 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eHas_3cI64_3e(ptr %s2, ptr %l7, i64 %t162)
  store i1 %t167, ptr %l101
  br label %bb41
bb41:
  %t168 = load i1, ptr %l101, !tbaa !21
  br i1 %t168, label %bb42, label %bb43
bb42:
  store %olang.scope zeroinitializer, ptr %s10
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/load:Loader", ptr %t169, i32 0, i32 4
  %t172 = load ptr, ptr %t171, !tbaa !29
  store ptr %t172, ptr %l103, !tbaa !29
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load ptr, ptr %l8, !tbaa !29
  %t175 = getelementptr %"compiler/load:Import", ptr %l14, i32 0, i32 1
  %t176 = load %"compiler/source:Span", ptr %t175
  %t180 = call { i64, [3 x i64] } @compiler_2fload_2ecompiler_2fload_3aLoader_2eat(ptr %v0, ptr %v0, ptr %t173, ptr %t174, %"compiler/source:Span" %t176)
  store { i64, [3 x i64] } %t180, ptr %l107
  br label %bb44
bb43:
  %t181 = load i64, ptr %l20, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s2, ptr %l7, i64 %t181)
  br label %bb48
bb44:
  %t184 = getelementptr %"compiler/load:Import", ptr %l14, i32 0, i32 2
  %t185 = load { i64, ptr }, ptr %t184, !tbaa !27
  %t187 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %s10, { i64, ptr } %t185)
  store { i64, ptr } %t187, ptr %l109
  br label %bb45
bb45:
  %t188 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t189 = extractvalue { i64, ptr } %t188, 0
  %t190 = extractvalue { i64, ptr } %t188, 1
  %t191 = mul i64 %t189, 1
  %t192 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t191)
  call void @llvm.memcpy.p0.p0.i64(ptr %t192, ptr %t190, i64 %t191, i1 false)
  %t193 = insertvalue { i64, ptr } undef, i64 %t189, 0
  %t194 = insertvalue { i64, ptr } %t193, ptr %t192, 1
  %t196 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportReachedTwice(ptr %s10, ptr %s10, { i64, ptr } %t194)
  store %"compiler/msgs:Msg" %t196, ptr %l111
  br label %bb46
bb46:
  %t197 = load ptr, ptr %l103, !tbaa !29
  %t198 = load { i64, [3 x i64] }, ptr %l107
  %t199 = load %"compiler/msgs:Msg", ptr %l111
  %t200 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s10, ptr %t197, { i64, [3 x i64] } %t198, %"compiler/msgs:Msg" %t199)
  store i64 %t200, ptr %l112
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s10)
  br label %bb49
bb48:
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s9)
  br label %bb50
bb50:
  %t201 = load i64, ptr %l19, !tbaa !24
  %t203 = add i64 %t201, 1
  store i64 %t203, ptr %l19, !tbaa !24
  br label %bb37
bb51:
  %t205 = load i64, ptr %l16, !tbaa !24
  %t206 = load i64, ptr %l18, !tbaa !24
  %t209 = add i64 %t205, %t206
  store i64 %t209, ptr %l16, !tbaa !24
  call void @__olang_scope_close(ptr %s8)
  br label %bb52
bb52:
  br label %bb30
bb53:
  call void @__olang_scope_close(ptr %s5)
  br label %bb54
bb54:
  %t211 = load i64, ptr %l13, !tbaa !24
  %t213 = add i64 %t211, 1
  store i64 %t213, ptr %l13, !tbaa !24
  br label %bb21
bb55:
  %t215 = load i64, ptr %l10, !tbaa !24
  %t216 = load i64, ptr %l12, !tbaa !24
  %t219 = add i64 %t215, %t216
  store i64 %t219, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb56
bb56:
  br label %bb14
bb57:
  call void @__olang_scope_close(ptr %s2)
  br label %bb58
bb58:
  %t221 = load i64, ptr %l5, !tbaa !24
  %t223 = add i64 %t221, 1
  store i64 %t223, ptr %l5, !tbaa !24
  br label %bb8
bb59:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fload_2ecompiler_2fload_3aLoader_2eclosure(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"compiler/load:Import"
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l19 = alloca ptr
  %l22 = alloca i1
  %l31 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca i32
  %l44 = alloca { i64, ptr }
  %l49 = alloca i1
  %l51 = alloca i1
  %l56 = alloca ptr
  %l60 = alloca ptr
  %l64 = alloca { i64, [3 x i64] }
  %l66 = alloca { i64, ptr }
  %l68 = alloca %"compiler/msgs:Msg"
  %l69 = alloca i64
  %l75 = alloca ptr
  %l78 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l82 = alloca i32
  %l91 = alloca { i64, ptr }
  %l98 = alloca i1
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/load:Loader", ptr %t1, i32 0, i32 5
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l19
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l19, !tbaa !29
  store ptr %t8, ptr %l2, !tbaa !29
  %t9 = load ptr, ptr %l2, !tbaa !29
  %t11 = getelementptr %"compiler/load:Module", ptr %t9, i32 0, i32 26
  %t12 = load i1, ptr %t11, !tbaa !21
  br i1 %t12, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb4
bb3:
  %t14 = load ptr, ptr %l2, !tbaa !29
  %t16 = getelementptr %"compiler/load:Module", ptr %t14, i32 0, i32 27
  %t17 = load i1, ptr %t16, !tbaa !21
  store i1 %t17, ptr %l22, !tbaa !21
  br label %bb4
bb4:
  %t19 = load i1, ptr %l22, !tbaa !21
  br i1 %t19, label %bb5, label %bb6
bb5:
  br label %ret
bb6:
  br label %bb7
bb7:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t22 = getelementptr %"compiler/load:Module", ptr %t20, i32 0, i32 27
  store i1 true, ptr %t22, !tbaa !21
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t25 = getelementptr %"compiler/load:Module", ptr %t23, i32 0, i32 28
  %t26 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t25, i64 %t26)
  br label %bb8
bb8:
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t31 = getelementptr %"compiler/load:Module", ptr %t29, i32 0, i32 11
  store ptr %t31, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t33 = load ptr, ptr %l3, !tbaa !29
  %t34 = load i64, ptr %l4, !tbaa !24
  %t37 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2eRunFrom_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %t33, i64 %t34)
  %t38 = extractvalue { i32, { i64, ptr } } %t37, 1
  %t39 = extractvalue { i32, { i64, ptr } } %t37, 0
  store i32 %t39, ptr %l35
  %t40 = icmp ne i32 %t39, 0
  br i1 %t40, label %bb11, label %ok.41
ok.41:
  store { i64, ptr } %t38, ptr %l34
  br label %bb10
bb10:
  %t42 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t42, ptr %l31, !tbaa !27
  br label %bb15
bb11:
  %t43 = load i32, ptr %l35, !tbaa !23
  %t44 = ashr i32 %t43, 16
  %t46 = icmp eq i32 %t44, 1
  br i1 %t46, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_bac1e628134637d6_1fc79dd263e480a2)
  unreachable
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb60
bb15:
  %t48 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t48, ptr %l5, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t49, 0
  store i64 %t51, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb16
bb16:
  store %olang.scope zeroinitializer, ptr %s4
  %t53 = load i64, ptr %l7, !tbaa !24
  %t54 = load i64, ptr %l6, !tbaa !24
  %t57 = icmp slt i64 %t53, %t54
  %t59 = xor i1 %t57, true
  br i1 %t59, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s4)
  br label %bb58
bb18:
  br label %bb19
bb19:
  %t61 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t61, ptr %l44, !tbaa !27
  %t62 = load i64, ptr %l7, !tbaa !24
  %t64 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = getelementptr %"compiler/load:Import", ptr %t65, i64 %t62
  %t67 = load %"compiler/load:Import", ptr %t66
  store %"compiler/load:Import" %t67, ptr %l8
  %t69 = getelementptr %"compiler/load:Import", ptr %l8, i32 0, i32 5
  %t70 = load i64, ptr %t69, !tbaa !24
  %t72 = icmp slt i64 %t70, 0
  br i1 %t72, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l49, !tbaa !21
  br label %bb23
bb21:
  %t74 = getelementptr %"compiler/load:Import", ptr %l8, i32 0, i32 2
  %t75 = load { i64, ptr }, ptr %t74, !tbaa !27
  %t77 = call i1 @compiler_2fload_2ePublic(ptr %v0, { i64, ptr } %t75)
  store i1 %t77, ptr %l51
  br label %bb22
bb22:
  %t78 = load i1, ptr %l51, !tbaa !21
  %t79 = xor i1 %t78, true
  store i1 %t79, ptr %l49, !tbaa !21
  br label %bb23
bb23:
  %t81 = load i1, ptr %l49, !tbaa !21
  br i1 %t81, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s4)
  br label %bb57
bb25:
  br label %bb26
bb26:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/load:Loader", ptr %t82, i32 0, i32 5
  %t85 = getelementptr %"compiler/load:Import", ptr %l8, i32 0, i32 5
  %t86 = load i64, ptr %t85, !tbaa !24
  %t89 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t84, i64 %t86)
  store ptr %t89, ptr %l56
  br label %bb27
bb27:
  %t90 = load ptr, ptr %l56, !tbaa !29
  %t92 = getelementptr %"compiler/load:Module", ptr %t90, i32 0, i32 27
  %t93 = load i1, ptr %t92, !tbaa !21
  br i1 %t93, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s6
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/load:Loader", ptr %t95, i32 0, i32 4
  %t98 = load ptr, ptr %t97, !tbaa !29
  store ptr %t98, ptr %l60, !tbaa !29
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load ptr, ptr %l2, !tbaa !29
  %t101 = getelementptr %"compiler/load:Import", ptr %l8, i32 0, i32 1
  %t102 = load %"compiler/source:Span", ptr %t101
  %t106 = call { i64, [3 x i64] } @compiler_2fload_2ecompiler_2fload_3aLoader_2eat(ptr %v0, ptr %v0, ptr %t99, ptr %t100, %"compiler/source:Span" %t102)
  store { i64, [3 x i64] } %t106, ptr %l64
  br label %bb30
bb29:
  br label %bb34
bb30:
  %t107 = getelementptr %"compiler/load:Import", ptr %l8, i32 0, i32 2
  %t108 = load { i64, ptr }, ptr %t107, !tbaa !27
  %t110 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %s6, { i64, ptr } %t108)
  store { i64, ptr } %t110, ptr %l66
  br label %bb31
bb31:
  %t111 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t111, 0
  %t113 = extractvalue { i64, ptr } %t111, 1
  %t114 = mul i64 %t112, 1
  %t115 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t114)
  call void @llvm.memcpy.p0.p0.i64(ptr %t115, ptr %t113, i64 %t114, i1 false)
  %t116 = insertvalue { i64, ptr } undef, i64 %t112, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr %t115, 1
  %t119 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReexportCycle(ptr %s6, ptr %s6, { i64, ptr } %t117)
  store %"compiler/msgs:Msg" %t119, ptr %l68
  br label %bb32
bb32:
  %t120 = load ptr, ptr %l60, !tbaa !29
  %t121 = load { i64, [3 x i64] }, ptr %l64
  %t122 = load %"compiler/msgs:Msg", ptr %l68
  %t123 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s6, ptr %t120, { i64, [3 x i64] } %t121, %"compiler/msgs:Msg" %t122)
  store i64 %t123, ptr %l69
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s4)
  br label %bb57
bb34:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/load:Import", ptr %l8, i32 0, i32 5
  %t126 = load i64, ptr %t125, !tbaa !24
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2eclosure(ptr %v0, ptr %t124, i64 %t126)
  br label %bb35
bb35:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/load:Loader", ptr %t129, i32 0, i32 5
  %t132 = getelementptr %"compiler/load:Import", ptr %l8, i32 0, i32 5
  %t133 = load i64, ptr %t132, !tbaa !24
  %t136 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t131, i64 %t133)
  store ptr %t136, ptr %l75
  br label %bb36
bb36:
  %t137 = load ptr, ptr %l75, !tbaa !29
  %t139 = getelementptr %"compiler/load:Module", ptr %t137, i32 0, i32 28
  store ptr %t139, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb37
bb37:
  store %olang.scope zeroinitializer, ptr %s8
  %t141 = load ptr, ptr %l9, !tbaa !29
  %t142 = load i64, ptr %l10, !tbaa !24
  %t145 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %t141, i64 %t142)
  %t146 = extractvalue { i32, { i64, ptr } } %t145, 1
  %t147 = extractvalue { i32, { i64, ptr } } %t145, 0
  store i32 %t147, ptr %l82
  %t148 = icmp ne i32 %t147, 0
  br i1 %t148, label %bb39, label %ok.149
ok.149:
  store { i64, ptr } %t146, ptr %l81
  br label %bb38
bb38:
  %t150 = load { i64, ptr }, ptr %l81, !tbaa !27
  store { i64, ptr } %t150, ptr %l78, !tbaa !27
  br label %bb43
bb39:
  %t151 = load i32, ptr %l82, !tbaa !23
  %t152 = ashr i32 %t151, 16
  %t154 = icmp eq i32 %t152, 1
  br i1 %t154, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_9b991ce6afd49bf7_d331ab4ffe40a1a3)
  unreachable
bb42:
  call void @__olang_scope_close(ptr %s8)
  br label %bb56
bb43:
  %t156 = load { i64, ptr }, ptr %l78, !tbaa !27
  store { i64, ptr } %t156, ptr %l11, !tbaa !27
  %t157 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t159 = extractvalue { i64, ptr } %t157, 0
  store i64 %t159, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb44
bb44:
  store %olang.scope zeroinitializer, ptr %s9
  %t161 = load i64, ptr %l13, !tbaa !24
  %t162 = load i64, ptr %l12, !tbaa !24
  %t165 = icmp slt i64 %t161, %t162
  %t167 = xor i1 %t165, true
  br i1 %t167, label %bb45, label %bb46
bb45:
  call void @__olang_scope_close(ptr %s9)
  br label %bb54
bb46:
  br label %bb47
bb47:
  %t169 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t169, ptr %l91, !tbaa !27
  %t170 = load i64, ptr %l13, !tbaa !24
  %t172 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t173 = load ptr, ptr %t172, !tbaa !27
  %t174 = getelementptr i64, ptr %t173, i64 %t170
  %t175 = load i64, ptr %t174, !tbaa !34
  store i64 %t175, ptr %l14, !tbaa !24
  %t177 = load i64, ptr %l14, !tbaa !24
  %t179 = load ptr, ptr %l2, !tbaa !29
  %t181 = getelementptr %"compiler/load:Module", ptr %t179, i32 0, i32 28
  %t185 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %t181, i64 %t177)
  store i1 %t185, ptr %l98
  br label %bb48
bb48:
  %t186 = load i1, ptr %l98, !tbaa !21
  %t187 = xor i1 %t186, true
  br i1 %t187, label %bb49, label %bb50
bb49:
  %t189 = load ptr, ptr %l2, !tbaa !29
  %t191 = getelementptr %"compiler/load:Module", ptr %t189, i32 0, i32 28
  %t192 = load i64, ptr %l14, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t191, i64 %t192)
  br label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s9)
  br label %bb53
bb53:
  %t195 = load i64, ptr %l13, !tbaa !24
  %t197 = add i64 %t195, 1
  store i64 %t197, ptr %l13, !tbaa !24
  br label %bb44
bb54:
  %t199 = load i64, ptr %l10, !tbaa !24
  %t200 = load i64, ptr %l12, !tbaa !24
  %t203 = add i64 %t199, %t200
  store i64 %t203, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s8)
  br label %bb55
bb55:
  br label %bb37
bb56:
  call void @__olang_scope_close(ptr %s4)
  br label %bb57
bb57:
  %t205 = load i64, ptr %l7, !tbaa !24
  %t207 = add i64 %t205, 1
  store i64 %t207, ptr %l7, !tbaa !24
  br label %bb16
bb58:
  %t209 = load i64, ptr %l4, !tbaa !24
  %t210 = load i64, ptr %l6, !tbaa !24
  %t213 = add i64 %t209, %t210
  store i64 %t213, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb59
bb59:
  br label %bb9
bb60:
  %t215 = load ptr, ptr %l2, !tbaa !29
  %t217 = getelementptr %"compiler/load:Module", ptr %t215, i32 0, i32 27
  store i1 false, ptr %t217, !tbaa !21
  %t218 = load ptr, ptr %l2, !tbaa !29
  %t220 = getelementptr %"compiler/load:Module", ptr %t218, i32 0, i32 26
  store i1 true, ptr %t220, !tbaa !21
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2econdEnd(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i1
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca i64
  %l22 = alloca { i64, ptr }
  %l27 = alloca i1
  %l34 = alloca i1
  %l41 = alloca i1
  %l44 = alloca i1
  %l51 = alloca i1
  %l62 = alloca i32
  %l71 = alloca i1
  %l74 = alloca i1
  %s1 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/load:Module", ptr %t1, i32 0, i32 7
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_f27e16b36a34913f_9730f0a664aef8cb)
  unreachable
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t10 = getelementptr %"compiler/load:Module", ptr %t8, i32 0, i32 7
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t14 = getelementptr %"compiler/scan:Tokens", ptr %t11, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  store { i64, ptr } %t15, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  store i1 false, ptr %l6, !tbaa !21
  store i64 %a2, ptr %l7, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t19 = load i64, ptr %l7, !tbaa !24
  %t23 = icmp slt i64 %t19, %a3
  %t25 = xor i1 %t23, true
  br i1 %t25, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s1)
  br label %bb55
bb6:
  br label %bb7
bb7:
  %t27 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t27, ptr %l22, !tbaa !27
  %t28 = load i64, ptr %l7, !tbaa !24
  %t30 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr %"compiler/token:Token", ptr %t31, i64 %t28
  %t33 = getelementptr %"compiler/token:Token", ptr %t32, i32 0, i32 0
  %t34 = load i32, ptr %t33
  store i32 %t34, ptr %l8
  %t36 = load i32, ptr %l8
  %t38 = trunc i64 88 to i32
  %t39 = icmp eq i32 %t36, %t38
  br i1 %t39, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb10
bb9:
  %t41 = load i32, ptr %l8
  %t43 = trunc i64 90 to i32
  %t44 = icmp eq i32 %t41, %t43
  store i1 %t44, ptr %l27, !tbaa !21
  br label %bb10
bb10:
  %t46 = load i1, ptr %l27, !tbaa !21
  br i1 %t46, label %bb11, label %bb12
bb11:
  %t47 = load i64, ptr %l5, !tbaa !24
  %t49 = add i64 %t47, 1
  store i64 %t49, ptr %l5, !tbaa !24
  br label %bb13
bb12:
  br label %bb13
bb13:
  %t51 = load i32, ptr %l8
  %t53 = trunc i64 89 to i32
  %t54 = icmp eq i32 %t51, %t53
  br i1 %t54, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb16
bb15:
  %t56 = load i32, ptr %l8
  %t58 = trunc i64 91 to i32
  %t59 = icmp eq i32 %t56, %t58
  store i1 %t59, ptr %l34, !tbaa !21
  br label %bb16
bb16:
  %t61 = load i1, ptr %l34, !tbaa !21
  br i1 %t61, label %bb17, label %bb18
bb17:
  %t62 = load i64, ptr %l5, !tbaa !24
  %t64 = sub i64 %t62, 1
  store i64 %t64, ptr %l5, !tbaa !24
  br label %bb19
bb18:
  br label %bb19
bb19:
  %t66 = load i32, ptr %l8
  %t68 = trunc i64 30 to i32
  %t69 = icmp eq i32 %t66, %t68
  br i1 %t69, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l41, !tbaa !21
  br label %bb22
bb21:
  %t71 = load i32, ptr %l8
  %t73 = trunc i64 37 to i32
  %t74 = icmp eq i32 %t71, %t73
  store i1 %t74, ptr %l41, !tbaa !21
  br label %bb22
bb22:
  %t76 = load i1, ptr %l41, !tbaa !21
  br i1 %t76, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l44, !tbaa !21
  br label %bb25
bb24:
  %t77 = load i32, ptr %l8
  %t79 = trunc i64 13 to i32
  %t80 = icmp eq i32 %t77, %t79
  store i1 %t80, ptr %l44, !tbaa !21
  br label %bb25
bb25:
  %t82 = load i1, ptr %l44, !tbaa !21
  br i1 %t82, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb28
bb27:
  br label %bb28
bb28:
  %t83 = load i32, ptr %l8
  %t85 = trunc i64 92 to i32
  %t86 = icmp eq i32 %t83, %t85
  br i1 %t86, label %bb29, label %bb30
bb29:
  %t88 = load i64, ptr %l5, !tbaa !24
  %t90 = icmp eq i64 %t88, 0
  br i1 %t90, label %bb31, label %bb32
bb30:
  br label %bb44
bb31:
  %t92 = load i1, ptr %l6, !tbaa !21
  %t94 = xor i1 %t92, true
  store i1 %t94, ptr %l51, !tbaa !21
  br label %bb33
bb32:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb33
bb33:
  %t96 = load i1, ptr %l51, !tbaa !21
  br i1 %t96, label %bb34, label %bb35
bb34:
  %t97 = load i64, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  store i64 %t97, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  %t99 = load ptr, ptr %l1, !tbaa !29
  %t101 = getelementptr %"compiler/load:Module", ptr %t99, i32 0, i32 7
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t104 = icmp eq ptr %t102, null
  br i1 %t104, label %bb37, label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_f6bd06efaafe5f20_6d37165570c63ddc)
  unreachable
bb38:
  br label %bb39
bb39:
  %t106 = load ptr, ptr %l1, !tbaa !29
  %t108 = getelementptr %"compiler/load:Module", ptr %t106, i32 0, i32 7
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t110 = load i64, ptr %l7, !tbaa !24
  %t112 = trunc i64 %t110 to i32
  %t115 = call i32 @compiler_2fscan_2ecompiler_2fscan_3aTokens_2eMatch(ptr %v1, ptr %t109, i32 %t112)
  store i32 %t115, ptr %l62
  br label %bb40
bb40:
  %t116 = load i32, ptr %l62, !tbaa !23
  %t117 = sext i32 %t116 to i64
  store i64 %t117, ptr %l9, !tbaa !24
  %t119 = load i64, ptr %l9, !tbaa !24
  %t121 = icmp slt i64 %t119, 0
  br i1 %t121, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s1)
  store i64 -1, ptr %rv
  br label %ret
bb42:
  br label %bb43
bb43:
  store i1 false, ptr %l6, !tbaa !21
  %t124 = load i64, ptr %l9, !tbaa !24
  %t126 = add i64 %t124, 1
  store i64 %t126, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb54
bb44:
  %t128 = load i64, ptr %l5, !tbaa !24
  %t130 = icmp sle i64 %t128, 0
  br i1 %t130, label %bb45, label %bb46
bb45:
  %t132 = load i32, ptr %l8
  %t134 = trunc i64 8 to i32
  %t135 = icmp eq i32 %t132, %t134
  br i1 %t135, label %bb47, label %bb48
bb46:
  store i1 false, ptr %l71, !tbaa !21
  br label %bb50
bb47:
  store i1 true, ptr %l74, !tbaa !21
  br label %bb49
bb48:
  %t137 = load i32, ptr %l8
  %t139 = trunc i64 0 to i32
  %t140 = icmp eq i32 %t137, %t139
  store i1 %t140, ptr %l74, !tbaa !21
  br label %bb49
bb49:
  %t142 = load i1, ptr %l74, !tbaa !21
  store i1 %t142, ptr %l71, !tbaa !21
  br label %bb50
bb50:
  %t143 = load i1, ptr %l71, !tbaa !21
  br i1 %t143, label %bb51, label %bb52
bb51:
  call void @__olang_scope_close(ptr %s1)
  store i64 -1, ptr %rv
  br label %ret
bb52:
  br label %bb53
bb53:
  %t145 = load i64, ptr %l7, !tbaa !24
  %t147 = add i64 %t145, 1
  store i64 %t147, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb54
bb54:
  br label %bb4
bb55:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fload_2ecompiler_2fload_3aLoader_2edecide(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca { i32, i1 }
  %l14 = alloca i32
  %l15 = alloca i1
  %l19 = alloca ptr
  %l23 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l48 = alloca i64
  %l50 = alloca i64
  %l53 = alloca i64
  %l55 = alloca i64
  %l58 = alloca i64
  %l63 = alloca i64
  %l69 = alloca i64
  %l72 = alloca i64
  %l90 = alloca ptr
  %l91 = alloca i64
  %l95 = alloca i64
  %l96 = alloca { i32, i1 }
  %l107 = alloca i1
  %l118 = alloca ptr
  %l119 = alloca i64
  %l123 = alloca i1
  %l124 = alloca i64
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/load:Loader", ptr %t1, i32 0, i32 5
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l19
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l19, !tbaa !29
  store ptr %t8, ptr %l3, !tbaa !29
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t11 = getelementptr %"compiler/load:Module", ptr %t9, i32 0, i32 16
  %t12 = load i64, ptr %l2, !tbaa !24
  %t15 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t11, i64 %t12)
  store i64 %t15, ptr %l23
  br label %bb2
bb2:
  %t16 = load i64, ptr @G_2ecompiler_2fload_2eNotYet, !tbaa !24
  %t17 = load i64, ptr %l23, !tbaa !24
  %t19 = icmp ne i64 %t17, %t16
  br i1 %t19, label %bb3, label %bb4
bb3:
  br label %ret
bb4:
  br label %bb5
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l26, !tbaa !29
  %t22 = load i64, ptr %l1, !tbaa !24
  store i64 %t22, ptr %l27, !tbaa !24
  %t23 = load ptr, ptr %l3, !tbaa !29
  %t25 = getelementptr %"compiler/load:Module", ptr %t23, i32 0, i32 15
  %t26 = load i64, ptr %l2, !tbaa !24
  %t29 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t25, i64 %t26)
  store i64 %t29, ptr %l31
  br label %bb6
bb6:
  %t30 = load ptr, ptr %l26, !tbaa !29
  %t31 = load i64, ptr %l27, !tbaa !24
  %t32 = load i64, ptr %l31, !tbaa !24
  %t33 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2etaken(ptr %v0, ptr %t30, i64 %t31, i64 %t32)
  store i64 %t33, ptr %l32
  br label %bb7
bb7:
  %t34 = load i64, ptr %l32, !tbaa !24
  store i64 %t34, ptr %l4, !tbaa !24
  %t35 = load i64, ptr %l4, !tbaa !24
  %t37 = icmp eq i64 %t35, 0
  br i1 %t37, label %bb8, label %bb9
bb8:
  %t39 = load ptr, ptr %l3, !tbaa !29
  %t41 = getelementptr %"compiler/load:Module", ptr %t39, i32 0, i32 16
  %t42 = load i64, ptr %l2, !tbaa !24
  %t43 = load i64, ptr @G_2ecompiler_2fload_2eNoBranch, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t41, i64 %t42, i64 %t43)
  br label %bb10
bb9:
  br label %bb11
bb10:
  br label %ret
bb11:
  %t47 = load i64, ptr %l4, !tbaa !24
  %t49 = icmp slt i64 %t47, 0
  br i1 %t49, label %bb12, label %bb13
bb12:
  %t51 = load ptr, ptr %l3, !tbaa !29
  %t53 = getelementptr %"compiler/load:Module", ptr %t51, i32 0, i32 16
  %t54 = load i64, ptr %l2, !tbaa !24
  %t55 = load i64, ptr @G_2ecompiler_2fload_2ePending, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t53, i64 %t54, i64 %t55)
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %ret
bb15:
  %t59 = load ptr, ptr %l3, !tbaa !29
  %t61 = getelementptr %"compiler/load:Module", ptr %t59, i32 0, i32 18
  %t62 = load i64, ptr %l2, !tbaa !24
  %t65 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t61, i64 %t62)
  store i64 %t65, ptr %l48
  br label %bb16
bb16:
  %t66 = load i64, ptr %l48, !tbaa !24
  store i64 %t66, ptr %l5, !tbaa !24
  %t67 = load i64, ptr %l2, !tbaa !24
  %t69 = add i64 %t67, 1
  store i64 %t69, ptr %l50, !tbaa !24
  %t70 = load ptr, ptr %l3, !tbaa !29
  %t72 = getelementptr %"compiler/load:Module", ptr %t70, i32 0, i32 18
  %t74 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t72)
  store i64 %t74, ptr %l53
  br label %bb17
bb17:
  %t75 = load i64, ptr %l50, !tbaa !24
  %t76 = load i64, ptr %l53, !tbaa !24
  %t77 = icmp eq i64 %t75, %t76
  br i1 %t77, label %bb18, label %bb19
bb18:
  %t79 = load ptr, ptr %l3, !tbaa !29
  %t81 = getelementptr %"compiler/load:Module", ptr %t79, i32 0, i32 19
  %t83 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t81)
  store i64 %t83, ptr %l58
  br label %bb20
bb19:
  %t84 = load ptr, ptr %l3, !tbaa !29
  %t86 = getelementptr %"compiler/load:Module", ptr %t84, i32 0, i32 18
  %t87 = load i64, ptr %l2, !tbaa !24
  %t89 = add i64 %t87, 1
  %t92 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t86, i64 %t89)
  store i64 %t92, ptr %l63
  br label %bb21
bb20:
  %t93 = load i64, ptr %l58, !tbaa !24
  store i64 %t93, ptr %l55, !tbaa !24
  br label %bb22
bb21:
  %t94 = load i64, ptr %l63, !tbaa !24
  store i64 %t94, ptr %l55, !tbaa !24
  br label %bb22
bb22:
  %t95 = load i64, ptr %l55, !tbaa !24
  store i64 %t95, ptr %l6, !tbaa !24
  %t96 = load i64, ptr %l5, !tbaa !24
  store i64 %t96, ptr %l7, !tbaa !24
  %t98 = load i64, ptr %l6, !tbaa !24
  store i64 %t98, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t100 = load i64, ptr %l8, !tbaa !24
  %t101 = load i64, ptr %l7, !tbaa !24
  %t104 = icmp sgt i64 %t100, %t101
  br i1 %t104, label %bb23, label %bb24
bb23:
  %t106 = load i64, ptr %l9, !tbaa !24
  %t108 = icmp sgt i64 %t106, 0
  br i1 %t108, label %bb25, label %bb26
bb24:
  store i64 0, ptr %l69, !tbaa !24
  br label %bb28
bb25:
  %t110 = load i64, ptr %l8, !tbaa !24
  %t111 = load i64, ptr %l7, !tbaa !24
  %t114 = sub i64 %t110, %t111
  %t115 = load i64, ptr %l9, !tbaa !24
  %t118 = add i64 %t114, %t115
  %t120 = sub i64 %t118, 1
  %t121 = load i64, ptr %l9, !tbaa !24
  %t124 = sdiv i64 %t120, %t121
  store i64 %t124, ptr %l72, !tbaa !24
  br label %bb27
bb26:
  store i64 0, ptr %l72, !tbaa !24
  br label %bb27
bb27:
  %t126 = load i64, ptr %l72, !tbaa !24
  store i64 %t126, ptr %l69, !tbaa !24
  br label %bb28
bb28:
  %t127 = load i64, ptr %l69, !tbaa !24
  store i64 %t127, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb29
bb29:
  store %olang.scope zeroinitializer, ptr %s5
  %t128 = load i64, ptr %l11, !tbaa !24
  %t129 = load i64, ptr %l10, !tbaa !24
  %t132 = icmp slt i64 %t128, %t129
  %t134 = xor i1 %t132, true
  br i1 %t134, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s5)
  br label %bb47
bb31:
  br label %bb32
bb32:
  %t136 = load i64, ptr %l7, !tbaa !24
  %t137 = load i64, ptr %l11, !tbaa !24
  %t138 = load i64, ptr %l9, !tbaa !24
  %t141 = mul i64 %t137, %t138
  %t144 = add i64 %t136, %t141
  store i64 %t144, ptr %l12, !tbaa !24
  %t146 = load ptr, ptr %l0, !tbaa !29
  store ptr %t146, ptr %l90, !tbaa !29
  %t147 = load i64, ptr %l1, !tbaa !24
  store i64 %t147, ptr %l91, !tbaa !24
  %t148 = load ptr, ptr %l3, !tbaa !29
  %t150 = getelementptr %"compiler/load:Module", ptr %t148, i32 0, i32 19
  %t151 = load i64, ptr %l12, !tbaa !24
  %t154 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t150, i64 %t151)
  store i64 %t154, ptr %l95
  br label %bb33
bb33:
  %t155 = load ptr, ptr %l90, !tbaa !29
  %t156 = load i64, ptr %l91, !tbaa !24
  %t157 = load i64, ptr %l95, !tbaa !24
  %t158 = call { i32, i1 } @compiler_2fload_2ecompiler_2fload_3aLoader_2eevalCond(ptr %v0, ptr %t155, i64 %t156, i64 %t157)
  store { i32, i1 } %t158, ptr %l96
  br label %bb34
bb34:
  %t159 = load { i32, i1 }, ptr %l96
  store { i32, i1 } %t159, ptr %l13
  %t160 = getelementptr { i32, i1 }, ptr %l13, i32 0, i32 0
  %t161 = load i32, ptr %t160
  store i32 %t161, ptr %l14
  %t163 = getelementptr { i32, i1 }, ptr %l13, i32 0, i32 1
  %t164 = load i1, ptr %t163, !tbaa !21
  store i1 %t164, ptr %l15, !tbaa !21
  %t166 = load i32, ptr %l14
  %t168 = trunc i64 1 to i32
  %t169 = icmp eq i32 %t166, %t168
  br i1 %t169, label %bb35, label %bb36
bb35:
  %t171 = load ptr, ptr %l3, !tbaa !29
  %t173 = getelementptr %"compiler/load:Module", ptr %t171, i32 0, i32 16
  %t174 = load i64, ptr %l2, !tbaa !24
  %t175 = load i64, ptr @G_2ecompiler_2fload_2ePending, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t173, i64 %t174, i64 %t175)
  br label %bb37
bb36:
  br label %bb38
bb37:
  call void @__olang_scope_close(ptr %s5)
  br label %ret
bb38:
  %t179 = load i32, ptr %l14
  %t181 = trunc i64 0 to i32
  %t182 = icmp eq i32 %t179, %t181
  br i1 %t182, label %bb39, label %bb40
bb39:
  %t184 = load i1, ptr %l15, !tbaa !21
  store i1 %t184, ptr %l107, !tbaa !21
  br label %bb41
bb40:
  store i1 false, ptr %l107, !tbaa !21
  br label %bb41
bb41:
  %t186 = load i1, ptr %l107, !tbaa !21
  br i1 %t186, label %bb42, label %bb43
bb42:
  %t187 = load ptr, ptr %l3, !tbaa !29
  %t189 = getelementptr %"compiler/load:Module", ptr %t187, i32 0, i32 16
  %t190 = load i64, ptr %l2, !tbaa !24
  %t191 = load i64, ptr %l12, !tbaa !24
  %t192 = load i64, ptr %l5, !tbaa !24
  %t195 = sub i64 %t191, %t192
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t189, i64 %t190, i64 %t195)
  br label %bb44
bb43:
  br label %bb45
bb44:
  call void @__olang_scope_close(ptr %s5)
  br label %ret
bb45:
  call void @__olang_scope_close(ptr %s5)
  br label %bb46
bb46:
  %t199 = load i64, ptr %l11, !tbaa !24
  %t201 = add i64 %t199, 1
  store i64 %t201, ptr %l11, !tbaa !24
  br label %bb29
bb47:
  %t203 = load ptr, ptr %l3, !tbaa !29
  %t205 = getelementptr %"compiler/load:Module", ptr %t203, i32 0, i32 16
  store ptr %t205, ptr %l118, !tbaa !29
  %t206 = load i64, ptr %l2, !tbaa !24
  store i64 %t206, ptr %l119, !tbaa !24
  %t207 = load ptr, ptr %l3, !tbaa !29
  %t209 = getelementptr %"compiler/load:Module", ptr %t207, i32 0, i32 17
  %t210 = load i64, ptr %l2, !tbaa !24
  %t213 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t209, i64 %t210)
  store i1 %t213, ptr %l123
  br label %bb48
bb48:
  %t214 = load i1, ptr %l123, !tbaa !21
  br i1 %t214, label %bb49, label %bb50
bb49:
  %t215 = load i64, ptr %l6, !tbaa !24
  %t216 = load i64, ptr %l5, !tbaa !24
  %t219 = sub i64 %t215, %t216
  store i64 %t219, ptr %l124, !tbaa !24
  br label %bb51
bb50:
  %t221 = load i64, ptr @G_2ecompiler_2fload_2eNoBranch, !tbaa !24
  store i64 %t221, ptr %l124, !tbaa !24
  br label %bb51
bb51:
  %t223 = load ptr, ptr %l118, !tbaa !29
  %t224 = load i64, ptr %l119, !tbaa !24
  %t225 = load i64, ptr %l124, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t223, i64 %t224, i64 %t225)
  br label %bb52
bb52:
  br label %ret
ret:
  ret void
}

define dso_local { i32, i1 } @compiler_2fload_2ecompiler_2fload_3aLoader_2eevalCond(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca { i32, i1 }
  %l7 = alloca i32
  %l8 = alloca i1
  %l9 = alloca { %"compiler/source:Span", %"compiler/msgs:Msg" }
  %l11 = alloca %"compiler/msgs:Msg"
  %l15 = alloca ptr
  %l18 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca i32
  %l35 = alloca { i64, ptr }
  %l41 = alloca i64
  %l53 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l63 = alloca %"compiler/cond:Eval"
  %l67 = alloca { i32, i1 }
  %l73 = alloca { %"compiler/source:Span", %"compiler/msgs:Msg" }
  %l77 = alloca ptr
  %l81 = alloca { i64, [3 x i64] }
  %l83 = alloca i64
  %s3 = alloca %olang.scope
  %rv = alloca { i32, i1 }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/load:Loader", ptr %t1, i32 0, i32 5
  %t7 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l15
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l15, !tbaa !29
  store ptr %t8, ptr %l3, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2eCondParser(ptr %v0, ptr %v0, ptr %t9, ptr %t10)
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l3, !tbaa !29
  %t15 = getelementptr %"compiler/load:Module", ptr %t13, i32 0, i32 24
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = icmp eq ptr %t16, null
  br i1 %t18, label %bb3, label %bb4
bb3:
  call void @__olang_check_failed(ptr @olang_loc_10115782cae2d59a_b13624e5abc6764e)
  unreachable
bb4:
  br label %bb5
bb5:
  %t20 = load ptr, ptr %l3, !tbaa !29
  %t22 = getelementptr %"compiler/load:Module", ptr %t20, i32 0, i32 24
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t27 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eExprAt(ptr %v0, ptr %t23, i64 %a2)
  %t28 = extractvalue { i32, ptr } %t27, 1
  %t29 = extractvalue { i32, ptr } %t27, 0
  store i32 %t29, ptr %l26
  %t30 = icmp ne i32 %t29, 0
  br i1 %t30, label %bb7, label %ok.31
ok.31:
  store ptr %t28, ptr %l25
  br label %bb6
bb6:
  %t32 = load ptr, ptr %l25, !tbaa !29
  store ptr %t32, ptr %l18, !tbaa !29
  br label %bb9
bb7:
  br label %bb8
bb8:
  %t34 = insertvalue { i32, i1 } undef, i32 2, 0
  %t35 = insertvalue { i32, i1 } %t34, i1 false, 1
  store { i32, i1 } %t35, ptr %rv
  br label %ret
bb9:
  %t37 = load ptr, ptr %l18, !tbaa !29
  store ptr %t37, ptr %l4, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t40 = getelementptr %"compiler/load:Module", ptr %t38, i32 0, i32 7
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = icmp eq ptr %t41, null
  br i1 %t43, label %bb10, label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_c8cfdf98ee3f2b21_1207f6627874c5f5)
  unreachable
bb11:
  br label %bb12
bb12:
  %t45 = load ptr, ptr %l3, !tbaa !29
  %t47 = getelementptr %"compiler/load:Module", ptr %t45, i32 0, i32 7
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t51 = getelementptr %"compiler/scan:Tokens", ptr %t48, i32 0, i32 0
  %t52 = load { i64, ptr }, ptr %t51, !tbaa !27
  store { i64, ptr } %t52, ptr %l35, !tbaa !27
  %t53 = load ptr, ptr %l3, !tbaa !29
  %t55 = getelementptr %"compiler/load:Module", ptr %t53, i32 0, i32 24
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = icmp eq ptr %t56, null
  br i1 %t58, label %bb13, label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_c8cfdf98ee3f2b21_1207f6627874c5f5)
  unreachable
bb14:
  br label %bb15
bb15:
  %t60 = load ptr, ptr %l3, !tbaa !29
  %t62 = getelementptr %"compiler/load:Module", ptr %t60, i32 0, i32 24
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ePos(ptr %v0, ptr %t63)
  store i64 %t65, ptr %l41
  br label %bb16
bb16:
  %t66 = load i64, ptr %l41, !tbaa !24
  %t67 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !27
  %t69 = getelementptr %"compiler/token:Token", ptr %t68, i64 %t66
  %t70 = getelementptr %"compiler/token:Token", ptr %t69, i32 0, i32 0
  %t71 = load i32, ptr %t70
  %t73 = trunc i64 92 to i32
  %t74 = icmp eq i32 %t71, %t73
  %t76 = xor i1 %t74, true
  br i1 %t76, label %bb17, label %bb18
bb17:
  %t79 = insertvalue { i32, i1 } undef, i32 1, 0
  %t80 = insertvalue { i32, i1 } %t79, i1 false, 1
  store { i32, i1 } %t80, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t82 = load ptr, ptr %l3, !tbaa !29
  %t84 = getelementptr %"compiler/load:Module", ptr %t82, i32 0, i32 6
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t87 = icmp eq ptr %t85, null
  br i1 %t87, label %bb20, label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_b990dbcfbe082b6c_e09e9a90e433de0)
  unreachable
bb21:
  br label %bb22
bb22:
  %t89 = load ptr, ptr %l3, !tbaa !29
  %t91 = getelementptr %"compiler/load:Module", ptr %t89, i32 0, i32 6
  %t92 = load ptr, ptr %t91, !tbaa !29
  %t95 = getelementptr %"compiler/source:Source", ptr %t92, i32 0, i32 1
  %t96 = load { i64, ptr }, ptr %t95, !tbaa !27
  store { i64, ptr } %t96, ptr %l53, !tbaa !27
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/load:Loader", ptr %t97, i32 0, i32 3
  %t100 = load ptr, ptr %t99, !tbaa !29
  store ptr %t100, ptr %l55, !tbaa !29
  %t101 = load ptr, ptr %l3, !tbaa !29
  %t103 = getelementptr %"compiler/load:Module", ptr %t101, i32 0, i32 23
  %t104 = load ptr, ptr %t103, !tbaa !29
  %t106 = icmp eq ptr %t104, null
  br i1 %t106, label %bb23, label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_b990dbcfbe082b6c_e09e9a90e433de0)
  unreachable
bb24:
  br label %bb25
bb25:
  %t108 = load ptr, ptr %l3, !tbaa !29
  %t110 = getelementptr %"compiler/load:Module", ptr %t108, i32 0, i32 23
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/load:Loader", ptr %t112, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !29
  %t116 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t117 = load ptr, ptr %l55, !tbaa !29
  %t120 = call %"compiler/cond:Eval" @compiler_2fcond_3aEval_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t116, ptr %t117, ptr %t111, ptr %t115)
  store %"compiler/cond:Eval" %t120, ptr %l63
  br label %bb26
bb26:
  %t121 = load %"compiler/cond:Eval", ptr %l63
  %t122 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 128, i64 8)
  store %"compiler/cond:Eval" %t121, ptr %t122
  store ptr %t122, ptr %l5, !tbaa !29
  %t124 = load ptr, ptr %l5, !tbaa !29
  %t125 = load ptr, ptr %l4, !tbaa !29
  %t128 = call { i32, i1 } @compiler_2fcond_2ecompiler_2fcond_3aEval_2eTop(ptr %v0, ptr %v0, ptr %t124, ptr %t125)
  store { i32, i1 } %t128, ptr %l67
  br label %bb27
bb27:
  %t129 = load { i32, i1 }, ptr %l67
  store { i32, i1 } %t129, ptr %l6
  %t130 = getelementptr { i32, i1 }, ptr %l6, i32 0, i32 0
  %t131 = load i32, ptr %t130
  store i32 %t131, ptr %l7
  %t133 = getelementptr { i32, i1 }, ptr %l6, i32 0, i32 1
  %t134 = load i1, ptr %t133, !tbaa !21
  store i1 %t134, ptr %l8, !tbaa !21
  %t136 = load i32, ptr %l7
  %t138 = trunc i64 2 to i32
  %t139 = icmp eq i32 %t136, %t138
  br i1 %t139, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s3
  %t141 = load ptr, ptr %l5, !tbaa !29
  %t143 = call { %"compiler/source:Span", %"compiler/msgs:Msg" } @compiler_2fcond_2ecompiler_2fcond_3aEval_2eError(ptr %v0, ptr %s3, ptr %t141)
  store { %"compiler/source:Span", %"compiler/msgs:Msg" } %t143, ptr %l73
  br label %bb30
bb29:
  br label %bb33
bb30:
  %t144 = load { %"compiler/source:Span", %"compiler/msgs:Msg" }, ptr %l73
  store { %"compiler/source:Span", %"compiler/msgs:Msg" } %t144, ptr %l9
  %t145 = getelementptr { %"compiler/source:Span", %"compiler/msgs:Msg" }, ptr %l9, i32 0, i32 0
  %t146 = load %"compiler/source:Span", ptr %t145
  %t148 = getelementptr { %"compiler/source:Span", %"compiler/msgs:Msg" }, ptr %l9, i32 0, i32 1
  %t149 = load %"compiler/msgs:Msg", ptr %t148
  store %"compiler/msgs:Msg" %t149, ptr %l11
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = getelementptr %"compiler/load:Loader", ptr %t151, i32 0, i32 4
  %t154 = load ptr, ptr %t153, !tbaa !29
  store ptr %t154, ptr %l77, !tbaa !29
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load ptr, ptr %l3, !tbaa !29
  %t161 = call { i64, [3 x i64] } @compiler_2fload_2ecompiler_2fload_3aLoader_2eat(ptr %v0, ptr %v0, ptr %t155, ptr %t156, %"compiler/source:Span" %t146)
  store { i64, [3 x i64] } %t161, ptr %l81
  br label %bb31
bb31:
  %t162 = load %"compiler/msgs:Msg", ptr %l11
  %t163 = load ptr, ptr %l77, !tbaa !29
  %t164 = load { i64, [3 x i64] }, ptr %l81
  %t166 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s3, ptr %t163, { i64, [3 x i64] } %t164, %"compiler/msgs:Msg" %t162)
  store i64 %t166, ptr %l83
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s3)
  br label %bb33
bb33:
  %t167 = load i32, ptr %l7
  %t168 = load i1, ptr %l8, !tbaa !21
  %t170 = insertvalue { i32, i1 } undef, i32 %t167, 0
  %t172 = insertvalue { i32, i1 } %t170, i1 %t168, 1
  store { i32, i1 } %t172, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i1 }, ptr %rv
  ret { i32, i1 } %rr
}

define dso_local void @compiler_2fload_2ecompiler_2fload_3aLoader_2egroups(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l19 = alloca ptr
  %l20 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i64
  %l32 = alloca %"compiler/source:Span"
  %l34 = alloca i64
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a2, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t15, ptr %l16, !tbaa !27
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l6, !tbaa !29
  %t23 = load ptr, ptr %l6, !tbaa !29
  store ptr %t23, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t24 = load ptr, ptr %l19, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb5, label %bb6
bb5:
  %t27 = load ptr, ptr %l19, !tbaa !29
  %t28 = load i64, ptr %t27
  %t30 = icmp eq i64 %t28, 7
  store i1 %t30, ptr %l20, !tbaa !21
  br label %bb6
bb6:
  %t31 = load i1, ptr %l20, !tbaa !21
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t32 = load ptr, ptr %l6, !tbaa !29
  %t34 = getelementptr { i64, [4 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", ptr }, ptr %t34, i32 0, i32 1
  %t36 = load ptr, ptr %t35
  store ptr %t36, ptr %l7, !tbaa !29
  br label %bb9
bb8:
  br label %bb16
bb9:
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l25, !tbaa !29
  %t39 = load i64, ptr %l1, !tbaa !24
  store i64 %t39, ptr %l26, !tbaa !24
  %t40 = load ptr, ptr %l7, !tbaa !29
  %t42 = getelementptr %"compiler/ast:TopIf", ptr %t40, i32 0, i32 0
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = icmp eq ptr %t43, null
  br i1 %t45, label %bb10, label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_e0f283e125550868_38a74932bc9801b4)
  unreachable
bb11:
  br label %bb12
bb12:
  %t47 = load ptr, ptr %l7, !tbaa !29
  %t49 = getelementptr %"compiler/ast:TopIf", ptr %t47, i32 0, i32 0
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t50)
  store %"compiler/source:Span" %t52, ptr %l32
  br label %bb13
bb13:
  %t53 = getelementptr %"compiler/source:Span", ptr %l32, i32 0, i32 0
  %t54 = load i32, ptr %t53, !tbaa !23
  %t55 = load ptr, ptr %l25, !tbaa !29
  %t56 = load i64, ptr %l26, !tbaa !24
  %t58 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eChosen(ptr %v0, ptr %t55, i64 %t56, i32 %t54)
  store i64 %t58, ptr %l34
  br label %bb14
bb14:
  %t59 = load i64, ptr %l34, !tbaa !24
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load i64, ptr %l1, !tbaa !24
  %t62 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2echainGroups(ptr %v0, ptr %v1, ptr %t60, i64 %t61, ptr %t62, i64 %t59, i64 0)
  br label %bb15
bb15:
  br label %bb17
bb16:
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  %t68 = load i64, ptr %l4, !tbaa !24
  %t70 = add i64 %t68, 1
  store i64 %t70, ptr %l4, !tbaa !24
  br label %bb1
bb19:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fload_2ecompiler_2fload_3aLoader_2eimportAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca %"compiler/source:Span"
  %l24 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l34 = alloca %"compiler/source:Span"
  %l41 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l45 = alloca i64
  %l46 = alloca { i64, ptr }
  %l49 = alloca i64
  %l50 = alloca i64
  %l55 = alloca { i64, ptr }
  %l57 = alloca i64
  %l61 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l72 = alloca %"compiler/source:Span"
  %l79 = alloca { i64, ptr }
  %l82 = alloca i64
  %l85 = alloca i64
  %l86 = alloca i64
  %l92 = alloca i1
  %l94 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l97 = alloca i64
  %l101 = alloca ptr
  %l111 = alloca %"compiler/load:Import"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/load:Module", ptr %t1, i32 0, i32 7
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_88eba3596c4d138c_c1530d55fa80a9b0)
  unreachable
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t10 = getelementptr %"compiler/load:Module", ptr %t8, i32 0, i32 7
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t14 = getelementptr %"compiler/scan:Tokens", ptr %t11, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  store { i64, ptr } %t15, ptr %l4, !tbaa !27
  %t19 = add i64 %a2, 1
  store i64 %t19, ptr %l5, !tbaa !24
  store { i64, ptr } { i64 0, ptr @.d40 }, ptr %l19, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t21, ptr %l20, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l21, !tbaa !24
  %t24 = load i64, ptr %l21, !tbaa !24
  %t25 = mul i64 %t24, 1
  %t26 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l22, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l21, !tbaa !24
  %t34 = mul i64 %t33, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %t32, i64 %t34, i1 false)
  %t35 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t35, ptr %l6, !tbaa !27
  %t36 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 0, i32 0)
  store %"compiler/source:Span" %t36, ptr %l23
  br label %bb4
bb4:
  %t37 = load %"compiler/source:Span", ptr %l23
  store %"compiler/source:Span" %t37, ptr %l7
  %t38 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t38, ptr %l24, !tbaa !27
  %t39 = load i64, ptr %l5, !tbaa !24
  %t41 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = getelementptr %"compiler/token:Token", ptr %t42, i64 %t39
  %t44 = getelementptr %"compiler/token:Token", ptr %t43, i32 0, i32 0
  %t45 = load i32, ptr %t44
  %t47 = trunc i64 1 to i32
  %t48 = icmp eq i32 %t45, %t47
  br i1 %t48, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t50 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t50, ptr %l28, !tbaa !27
  %t51 = load i64, ptr %l5, !tbaa !24
  %t53 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr %"compiler/token:Token", ptr %t54, i64 %t51
  %t56 = getelementptr %"compiler/token:Token", ptr %t55, i32 0, i32 2
  %t57 = load i32, ptr %t56, !tbaa !23
  %t58 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t58, ptr %l31, !tbaa !27
  %t59 = load i64, ptr %l5, !tbaa !24
  %t61 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr %"compiler/token:Token", ptr %t62, i64 %t59
  %t64 = getelementptr %"compiler/token:Token", ptr %t63, i32 0, i32 3
  %t65 = load i32, ptr %t64, !tbaa !23
  %t68 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s1, i32 %t57, i32 %t65)
  store %"compiler/source:Span" %t68, ptr %l34
  br label %bb7
bb6:
  br label %bb20
bb7:
  %t69 = load %"compiler/source:Span", ptr %l34
  store %"compiler/source:Span" %t69, ptr %l7
  %t70 = load ptr, ptr %l1, !tbaa !29
  %t72 = getelementptr %"compiler/load:Module", ptr %t70, i32 0, i32 6
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = icmp eq ptr %t73, null
  br i1 %t75, label %bb8, label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_17f5e01691795fb_80a050950937648f)
  unreachable
bb9:
  br label %bb10
bb10:
  %t77 = load ptr, ptr %l1, !tbaa !29
  %t79 = getelementptr %"compiler/load:Module", ptr %t77, i32 0, i32 6
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t83 = getelementptr %"compiler/source:Source", ptr %t80, i32 0, i32 1
  %t84 = load { i64, ptr }, ptr %t83, !tbaa !27
  store { i64, ptr } %t84, ptr %l41, !tbaa !27
  %t85 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t85, ptr %l42, !tbaa !27
  %t86 = load i64, ptr %l5, !tbaa !24
  %t88 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !27
  %t90 = getelementptr %"compiler/token:Token", ptr %t89, i64 %t86
  %t91 = getelementptr %"compiler/token:Token", ptr %t90, i32 0, i32 2
  %t92 = load i32, ptr %t91, !tbaa !23
  %t94 = sext i32 %t92 to i64
  store i64 %t94, ptr %l45, !tbaa !24
  %t95 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t95, ptr %l46, !tbaa !27
  %t96 = load i64, ptr %l5, !tbaa !24
  %t98 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr %"compiler/token:Token", ptr %t99, i64 %t96
  %t101 = getelementptr %"compiler/token:Token", ptr %t100, i32 0, i32 3
  %t102 = load i32, ptr %t101, !tbaa !23
  %t104 = sext i32 %t102 to i64
  store i64 %t104, ptr %l49, !tbaa !24
  %t105 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t105, 0
  store i64 %t106, ptr %l50, !tbaa !24
  %t107 = load i64, ptr %l45, !tbaa !24
  %t108 = icmp sge i64 %t107, 0
  br i1 %t108, label %bb11, label %bb12
bb11:
  %t110 = load i64, ptr %l45, !tbaa !24
  %t111 = load i64, ptr %l49, !tbaa !24
  %t112 = icmp sle i64 %t110, %t111
  br i1 %t112, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_fd1d115e36d277d2_104a63438b39a3d6)
  unreachable
bb13:
  %t114 = load i64, ptr %l49, !tbaa !24
  %t115 = load i64, ptr %l50, !tbaa !24
  %t116 = icmp sle i64 %t114, %t115
  br i1 %t116, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_fd1d115e36d277d2_104a63438b39a3d6)
  unreachable
bb15:
  %t118 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !27
  %t120 = load i64, ptr %l45, !tbaa !24
  %t121 = load i64, ptr %l49, !tbaa !24
  %t122 = getelementptr i8, ptr %t119, i64 %t120
  %t123 = sub i64 %t121, %t120
  %t124 = insertvalue { i64, ptr } undef, i64 %t123, 0
  %t125 = insertvalue { i64, ptr } %t124, ptr %t122, 1
  %t127 = extractvalue { i64, ptr } %t125, 1
  %t128 = extractvalue { i64, ptr } %t125, 0
  %t129 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t128)
  call void @olang_textcopy(ptr %t129, ptr %t127, i64 %t128)
  %t130 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t131 = insertvalue { i64, ptr } %t130, ptr %t129, 1
  store { i64, ptr } %t131, ptr %l55, !tbaa !27
  %t132 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t132, 0
  %t134 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t135 = extractvalue { i64, ptr } %t134, 0
  store i64 %t135, ptr %l57, !tbaa !24
  %t137 = load i64, ptr %l57, !tbaa !24
  %t138 = icmp eq i64 %t133, %t137
  br i1 %t138, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_fd1d115e36d277d2_104a63438b39a3d6)
  unreachable
bb17:
  %t140 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !27
  %t142 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !27
  %t144 = load i64, ptr %l57, !tbaa !24
  %t145 = mul i64 %t144, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t141, ptr %t143, i64 %t145, i1 false)
  br label %bb19
bb18:
  %t146 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t146, ptr %l6, !tbaa !27
  br label %bb19
bb19:
  %t147 = load i64, ptr %l5, !tbaa !24
  %t149 = add i64 %t147, 1
  store i64 %t149, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb20
bb20:
  %t151 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t151, ptr %l61, !tbaa !27
  %t152 = load i64, ptr %l5, !tbaa !24
  %t154 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !27
  %t156 = getelementptr %"compiler/token:Token", ptr %t155, i64 %t152
  %t157 = getelementptr %"compiler/token:Token", ptr %t156, i32 0, i32 0
  %t158 = load i32, ptr %t157
  %t160 = trunc i64 5 to i32
  %t161 = icmp eq i32 %t158, %t160
  %t163 = xor i1 %t161, true
  br i1 %t163, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb22:
  br label %bb23
bb23:
  %t165 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t165, ptr %l66, !tbaa !27
  %t166 = load i64, ptr %l5, !tbaa !24
  %t168 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !27
  %t170 = getelementptr %"compiler/token:Token", ptr %t169, i64 %t166
  %t171 = getelementptr %"compiler/token:Token", ptr %t170, i32 0, i32 2
  %t172 = load i32, ptr %t171, !tbaa !23
  %t173 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t173, ptr %l69, !tbaa !27
  %t174 = load i64, ptr %l5, !tbaa !24
  %t176 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = getelementptr %"compiler/token:Token", ptr %t177, i64 %t174
  %t179 = getelementptr %"compiler/token:Token", ptr %t178, i32 0, i32 3
  %t180 = load i32, ptr %t179, !tbaa !23
  %t183 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t172, i32 %t180)
  store %"compiler/source:Span" %t183, ptr %l72
  br label %bb24
bb24:
  %t184 = load %"compiler/source:Span", ptr %l72
  store %"compiler/source:Span" %t184, ptr %l8
  %t185 = load ptr, ptr %l1, !tbaa !29
  %t187 = getelementptr %"compiler/load:Module", ptr %t185, i32 0, i32 6
  %t188 = load ptr, ptr %t187, !tbaa !29
  %t190 = icmp eq ptr %t188, null
  br i1 %t190, label %bb25, label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_3753a1d7262b2cc1_bd09a853d1b85305)
  unreachable
bb26:
  br label %bb27
bb27:
  %t192 = load ptr, ptr %l1, !tbaa !29
  %t194 = getelementptr %"compiler/load:Module", ptr %t192, i32 0, i32 6
  %t195 = load ptr, ptr %t194, !tbaa !29
  %t198 = getelementptr %"compiler/source:Source", ptr %t195, i32 0, i32 1
  %t199 = load { i64, ptr }, ptr %t198, !tbaa !27
  store { i64, ptr } %t199, ptr %l79, !tbaa !27
  %t200 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 0
  %t201 = load i32, ptr %t200, !tbaa !23
  %t203 = add i32 %t201, 1
  %t205 = sext i32 %t203 to i64
  store i64 %t205, ptr %l82, !tbaa !24
  %t206 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 1
  %t207 = load i32, ptr %t206, !tbaa !23
  %t209 = sub i32 %t207, 1
  %t211 = sext i32 %t209 to i64
  store i64 %t211, ptr %l85, !tbaa !24
  %t212 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t213 = extractvalue { i64, ptr } %t212, 0
  store i64 %t213, ptr %l86, !tbaa !24
  %t214 = load i64, ptr %l82, !tbaa !24
  %t215 = icmp sge i64 %t214, 0
  br i1 %t215, label %bb28, label %bb29
bb28:
  %t217 = load i64, ptr %l82, !tbaa !24
  %t218 = load i64, ptr %l85, !tbaa !24
  %t219 = icmp sle i64 %t217, %t218
  br i1 %t219, label %bb30, label %bb31
bb29:
  call void @__olang_check_failed(ptr @olang_loc_a7b0777888cd5d70_d2e13e44ce4d5eec)
  unreachable
bb30:
  %t221 = load i64, ptr %l85, !tbaa !24
  %t222 = load i64, ptr %l86, !tbaa !24
  %t223 = icmp sle i64 %t221, %t222
  br i1 %t223, label %bb32, label %bb33
bb31:
  call void @__olang_check_failed(ptr @olang_loc_a7b0777888cd5d70_d2e13e44ce4d5eec)
  unreachable
bb32:
  %t225 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t226 = load ptr, ptr %t225, !tbaa !27
  %t227 = load i64, ptr %l82, !tbaa !24
  %t228 = load i64, ptr %l85, !tbaa !24
  %t229 = getelementptr i8, ptr %t226, i64 %t227
  %t230 = sub i64 %t228, %t227
  %t231 = insertvalue { i64, ptr } undef, i64 %t230, 0
  %t232 = insertvalue { i64, ptr } %t231, ptr %t229, 1
  store { i64, ptr } %t232, ptr %l9, !tbaa !27
  %t234 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t236 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t234, { i64, ptr } { i64 0, ptr @.d41 })
  store i1 %t236, ptr %l92
  br label %bb34
bb33:
  call void @__olang_check_failed(ptr @olang_loc_a7b0777888cd5d70_d2e13e44ce4d5eec)
  unreachable
bb34:
  %t237 = load i1, ptr %l92, !tbaa !21
  br i1 %t237, label %bb35, label %bb36
bb35:
  %t238 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t240 = call { i64, ptr } @compiler_2fload_2eDeriveAlias(ptr %v1, { i64, ptr } %t238)
  store { i64, ptr } %t240, ptr %l94
  br label %bb37
bb36:
  br label %bb41
bb37:
  %t241 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t242 = extractvalue { i64, ptr } %t241, 1
  %t243 = extractvalue { i64, ptr } %t241, 0
  %t244 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t243)
  call void @olang_textcopy(ptr %t244, ptr %t242, i64 %t243)
  %t245 = insertvalue { i64, ptr } undef, i64 %t243, 0
  %t246 = insertvalue { i64, ptr } %t245, ptr %t244, 1
  store { i64, ptr } %t246, ptr %l95, !tbaa !27
  %t247 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t248 = extractvalue { i64, ptr } %t247, 0
  %t249 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t250 = extractvalue { i64, ptr } %t249, 0
  store i64 %t250, ptr %l97, !tbaa !24
  %t252 = load i64, ptr %l97, !tbaa !24
  %t253 = icmp eq i64 %t248, %t252
  br i1 %t253, label %bb38, label %bb39
bb38:
  %t255 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t256 = load ptr, ptr %t255, !tbaa !27
  %t257 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t258 = load ptr, ptr %t257, !tbaa !27
  %t259 = load i64, ptr %l97, !tbaa !24
  %t260 = mul i64 %t259, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t256, ptr %t258, i64 %t260, i1 false)
  br label %bb40
bb39:
  %t261 = load { i64, ptr }, ptr %l95, !tbaa !27
  store { i64, ptr } %t261, ptr %l6, !tbaa !27
  br label %bb40
bb40:
  %t262 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t262, ptr %l7
  br label %bb41
bb41:
  %t264 = load ptr, ptr %l1, !tbaa !29
  %t266 = getelementptr %"compiler/load:Module", ptr %t264, i32 0, i32 11
  store ptr %t266, ptr %l101, !tbaa !29
  %t267 = load %"compiler/source:Span", ptr %l8
  %t268 = load %"compiler/source:Span", ptr %l7
  %t269 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t271 = extractvalue { i64, ptr } %t269, 1
  %t272 = extractvalue { i64, ptr } %t269, 0
  %t273 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t272)
  call void @olang_textcopy(ptr %t273, ptr %t271, i64 %t272)
  %t274 = insertvalue { i64, ptr } undef, i64 %t272, 0
  %t275 = insertvalue { i64, ptr } %t274, ptr %t273, 1
  %t277 = extractvalue { i64, ptr } %t275, 0
  %t278 = extractvalue { i64, ptr } %t275, 1
  %t279 = mul i64 %t277, 1
  %t280 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t279)
  call void @llvm.memcpy.p0.p0.i64(ptr %t280, ptr %t278, i64 %t279, i1 false)
  %t281 = insertvalue { i64, ptr } undef, i64 %t277, 0
  %t282 = insertvalue { i64, ptr } %t281, ptr %t280, 1
  %t283 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t285 = extractvalue { i64, ptr } %t283, 1
  %t286 = extractvalue { i64, ptr } %t283, 0
  %t287 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t286)
  call void @olang_textcopy(ptr %t287, ptr %t285, i64 %t286)
  %t288 = insertvalue { i64, ptr } undef, i64 %t286, 0
  %t289 = insertvalue { i64, ptr } %t288, ptr %t287, 1
  %t291 = extractvalue { i64, ptr } %t289, 0
  %t292 = extractvalue { i64, ptr } %t289, 1
  %t293 = mul i64 %t291, 1
  %t294 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t293)
  call void @llvm.memcpy.p0.p0.i64(ptr %t294, ptr %t292, i64 %t293, i1 false)
  %t295 = insertvalue { i64, ptr } undef, i64 %t291, 0
  %t296 = insertvalue { i64, ptr } %t295, ptr %t294, 1
  %t303 = call %"compiler/load:Import" @compiler_2fload_3aImport_2ector(ptr %v1, ptr %v1, ptr %v1, %"compiler/source:Span" %t267, %"compiler/source:Span" %t268, { i64, ptr } %t282, { i64, ptr } %t296, i64 %a3)
  store %"compiler/load:Import" %t303, ptr %l111
  br label %bb42
bb42:
  %t304 = load ptr, ptr %l101, !tbaa !29
  %t305 = load %"compiler/load:Import", ptr %l111
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2ePush_3ccompiler_2fload_3aImport_3e(ptr %v1, ptr %v1, ptr %t304, %"compiler/load:Import" %t305)
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eload(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca %"compiler/scan:Diag"
  %l21 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i32
  %l25 = alloca { i64, ptr }
  %l29 = alloca i1
  %l31 = alloca { i64, ptr }
  %l38 = alloca i64
  %l42 = alloca i64
  %l45 = alloca i64
  %l66 = alloca ptr
  %l70 = alloca i1
  %l76 = alloca i64
  %l78 = alloca ptr
  %l89 = alloca %"compiler/load:Module"
  %l94 = alloca ptr
  %l95 = alloca { i64, ptr }
  %l96 = alloca i64
  %l97 = alloca { i64, ptr }
  %l101 = alloca i1
  %l102 = alloca ptr
  %l106 = alloca { i64, ptr }
  %l107 = alloca { i64, ptr }
  %l111 = alloca { i64, ptr }
  %l112 = alloca i32
  %l114 = alloca %"compiler/source:Source"
  %l116 = alloca ptr
  %l117 = alloca %"compiler/source:Source"
  %l120 = alloca %"compiler/source:Source"
  %l121 = alloca i32
  %l128 = alloca i64
  %l130 = alloca ptr
  %l132 = alloca { i64, [3 x i64] }
  %l133 = alloca %"compiler/msgs:Msg"
  %l134 = alloca i64
  %l135 = alloca ptr
  %l138 = alloca ptr
  %l139 = alloca i32
  %l142 = alloca ptr
  %l144 = alloca ptr
  %l146 = alloca { i64, ptr }
  %l153 = alloca { i64, ptr }
  %l156 = alloca i1
  %l157 = alloca i64
  %l158 = alloca ptr
  %l166 = alloca %"compiler/scan:Tokens"
  %l181 = alloca { i64, ptr }
  %l186 = alloca ptr
  %l193 = alloca { i64, [3 x i64] }
  %l194 = alloca i32
  %l196 = alloca { i64, ptr }
  %l198 = alloca { i64, ptr }
  %l200 = alloca %"compiler/msgs:Msg"
  %l201 = alloca i64
  %l206 = alloca ptr
  %l207 = alloca %"compiler/parse:Oracle"
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %rv = alloca i64
  %t168 = alloca %"compiler/load:Module", align 8
  %t282 = alloca { i64, [3 x i64] }, align 8
  %t424 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = call { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v1, ptr %s0, { i64, ptr } %t1)
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l24
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store { i64, ptr } %t4, ptr %l23
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t8, ptr %l21, !tbaa !27
  br label %bb4
bb2:
  br label %bb3
bb3:
  store { i64, ptr } { i64 0, ptr @.d42 }, ptr %l25, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  %t12 = extractvalue { i64, ptr } %t9, 1
  %t13 = mul i64 %t11, 1
  %t14 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t13)
  call void @llvm.memcpy.p0.p0.i64(ptr %t14, ptr %t12, i64 %t13, i1 false)
  %t15 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l21, !tbaa !27
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t18, ptr %l4, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t21 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t19, { i64, ptr } { i64 0, ptr @.d43 })
  store i1 %t21, ptr %l29
  br label %bb5
bb5:
  %t22 = load i1, ptr %l29, !tbaa !21
  %t23 = xor i1 %t22, true
  br i1 %t23, label %bb6, label %bb7
bb6:
  %t25 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t25, 1
  %t28 = extractvalue { i64, ptr } %t25, 0
  %t29 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t28)
  call void @olang_textcopy(ptr %t29, ptr %t27, i64 %t28)
  %t30 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t29, 1
  store { i64, ptr } %t31, ptr %l31, !tbaa !27
  br label %bb8
bb7:
  %t33 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 1
  %t36 = extractvalue { i64, ptr } %t33, 0
  %t37 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t36)
  call void @olang_textcopy(ptr %t37, ptr %t35, i64 %t36)
  %t38 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  store { i64, ptr } %t39, ptr %l31, !tbaa !27
  br label %bb8
bb8:
  %t41 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t41, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/load:Loader", ptr %t42, i32 0, i32 5
  %t46 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v0, ptr %t44)
  store i64 %t46, ptr %l38
  br label %bb9
bb9:
  %t47 = load i64, ptr %l38, !tbaa !24
  store i64 %t47, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t48 = load i64, ptr %l7, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  %t52 = icmp sgt i64 %t48, %t49
  br i1 %t52, label %bb10, label %bb11
bb10:
  %t54 = load i64, ptr %l8, !tbaa !24
  %t56 = icmp sgt i64 %t54, 0
  br i1 %t56, label %bb12, label %bb13
bb11:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb15
bb12:
  %t58 = load i64, ptr %l7, !tbaa !24
  %t59 = load i64, ptr %l6, !tbaa !24
  %t62 = sub i64 %t58, %t59
  %t63 = load i64, ptr %l8, !tbaa !24
  %t66 = add i64 %t62, %t63
  %t68 = sub i64 %t66, 1
  %t69 = load i64, ptr %l8, !tbaa !24
  %t72 = sdiv i64 %t68, %t69
  store i64 %t72, ptr %l45, !tbaa !24
  br label %bb14
bb13:
  store i64 0, ptr %l45, !tbaa !24
  br label %bb14
bb14:
  %t74 = load i64, ptr %l45, !tbaa !24
  store i64 %t74, ptr %l42, !tbaa !24
  br label %bb15
bb15:
  %t75 = load i64, ptr %l42, !tbaa !24
  store i64 %t75, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb16
bb16:
  store %olang.scope zeroinitializer, ptr %s4
  %t76 = load i64, ptr %l10, !tbaa !24
  %t77 = load i64, ptr %l9, !tbaa !24
  %t80 = icmp slt i64 %t76, %t77
  %t82 = xor i1 %t80, true
  br i1 %t82, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s4)
  br label %bb26
bb18:
  br label %bb19
bb19:
  %t84 = load i64, ptr %l6, !tbaa !24
  %t85 = load i64, ptr %l10, !tbaa !24
  %t86 = load i64, ptr %l8, !tbaa !24
  %t89 = mul i64 %t85, %t86
  %t92 = add i64 %t84, %t89
  store i64 %t92, ptr %l11, !tbaa !24
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/load:Loader", ptr %t94, i32 0, i32 5
  %t97 = load i64, ptr %l11, !tbaa !24
  %t100 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t96, i64 %t97)
  store ptr %t100, ptr %l66
  br label %bb20
bb20:
  %t101 = load ptr, ptr %l66, !tbaa !29
  %t103 = getelementptr %"compiler/load:Module", ptr %t101, i32 0, i32 1
  %t104 = load { i64, ptr }, ptr %t103, !tbaa !27
  %t105 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t108 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t104, { i64, ptr } %t105)
  store i1 %t108, ptr %l70
  br label %bb21
bb21:
  %t109 = load i1, ptr %l70, !tbaa !21
  br i1 %t109, label %bb22, label %bb23
bb22:
  %t110 = load i64, ptr %l11, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store i64 %t110, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s4)
  br label %bb25
bb25:
  %t112 = load i64, ptr %l10, !tbaa !24
  %t114 = add i64 %t112, 1
  store i64 %t114, ptr %l10, !tbaa !24
  br label %bb16
bb26:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/load:Loader", ptr %t116, i32 0, i32 5
  %t120 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v0, ptr %t118)
  store i64 %t120, ptr %l76
  br label %bb27
bb27:
  %t121 = load i64, ptr %l76, !tbaa !24
  store i64 %t121, ptr %l12, !tbaa !24
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/load:Loader", ptr %t122, i32 0, i32 5
  store ptr %t124, ptr %l78, !tbaa !29
  %t125 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t127 = extractvalue { i64, ptr } %t125, 1
  %t128 = extractvalue { i64, ptr } %t125, 0
  %t129 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t128)
  call void @olang_textcopy(ptr %t129, ptr %t127, i64 %t128)
  %t130 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t131 = insertvalue { i64, ptr } %t130, ptr %t129, 1
  %t133 = extractvalue { i64, ptr } %t131, 0
  %t134 = extractvalue { i64, ptr } %t131, 1
  %t135 = mul i64 %t133, 1
  %t136 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t135)
  call void @llvm.memcpy.p0.p0.i64(ptr %t136, ptr %t134, i64 %t135, i1 false)
  %t137 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %t136, 1
  %t139 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t141 = extractvalue { i64, ptr } %t139, 1
  %t142 = extractvalue { i64, ptr } %t139, 0
  %t143 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t142)
  call void @olang_textcopy(ptr %t143, ptr %t141, i64 %t142)
  %t144 = insertvalue { i64, ptr } undef, i64 %t142, 0
  %t145 = insertvalue { i64, ptr } %t144, ptr %t143, 1
  %t147 = extractvalue { i64, ptr } %t145, 0
  %t148 = extractvalue { i64, ptr } %t145, 1
  %t149 = mul i64 %t147, 1
  %t150 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t149)
  call void @llvm.memcpy.p0.p0.i64(ptr %t150, ptr %t148, i64 %t149, i1 false)
  %t151 = insertvalue { i64, ptr } undef, i64 %t147, 0
  %t152 = insertvalue { i64, ptr } %t151, ptr %t150, 1
  %t155 = extractvalue { i64, ptr } %a2, 1
  %t156 = extractvalue { i64, ptr } %a2, 0
  %t157 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t156)
  call void @olang_textcopy(ptr %t157, ptr %t155, i64 %t156)
  %t158 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t159 = insertvalue { i64, ptr } %t158, ptr %t157, 1
  %t161 = extractvalue { i64, ptr } %t159, 0
  %t162 = extractvalue { i64, ptr } %t159, 1
  %t163 = mul i64 %t161, 1
  %t164 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t163)
  call void @llvm.memcpy.p0.p0.i64(ptr %t164, ptr %t162, i64 %t163, i1 false)
  %t165 = insertvalue { i64, ptr } undef, i64 %t161, 0
  %t166 = insertvalue { i64, ptr } %t165, ptr %t164, 1
  call void @compiler_2fload_3aModule_2ector(ptr %t168, ptr %v0, ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t138, { i64, ptr } %t152, { i64, ptr } %t166, i1 %a3)
  call void @llvm.memmove.p0.p0.i64(ptr %l89, ptr %t168, i64 256, i1 false)
  br label %bb28
bb28:
  %t173 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 256, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t173, ptr %l89, i64 256, i1 false)
  %t174 = load ptr, ptr %l78, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H4773d10fc8d77771a2093e7ac76ab6ea(ptr %v0, ptr %v0, ptr %t174, ptr %t173)
  br label %bb29
bb29:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = getelementptr %"compiler/load:Loader", ptr %t176, i32 0, i32 5
  %t179 = load i64, ptr %l12, !tbaa !24
  %t182 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t178, i64 %t179)
  store ptr %t182, ptr %l94
  br label %bb30
bb30:
  %t183 = load ptr, ptr %l94, !tbaa !29
  store ptr %t183, ptr %l13, !tbaa !29
  %t184 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t184, ptr %l95, !tbaa !27
  %t185 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t186 = extractvalue { i64, ptr } %t185, 0
  store i64 %t186, ptr %l96, !tbaa !24
  %t187 = load i64, ptr %l96, !tbaa !24
  %t188 = mul i64 %t187, 1
  %t189 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t188)
  %t190 = insertvalue { i64, ptr } undef, i64 %t187, 0
  %t191 = insertvalue { i64, ptr } %t190, ptr %t189, 1
  store { i64, ptr } %t191, ptr %l97, !tbaa !27
  %t192 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t193 = load ptr, ptr %t192, !tbaa !27
  %t194 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t195 = load ptr, ptr %t194, !tbaa !27
  %t196 = load i64, ptr %l96, !tbaa !24
  %t197 = mul i64 %t196, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t193, ptr %t195, i64 %t197, i1 false)
  %t198 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t201 = getelementptr %"compiler/load:Loader", ptr %t199, i32 0, i32 8
  %t205 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_He27db0a1785588531472bfd2db42574f(ptr %v0, ptr %s0, ptr %t201, { i64, ptr } %t198)
  store i1 %t205, ptr %l101
  br label %bb31
bb31:
  %t206 = load i1, ptr %l101, !tbaa !21
  br i1 %t206, label %bb32, label %bb33
bb32:
  %t207 = load ptr, ptr %l13, !tbaa !29
  store ptr %t207, ptr %l102, !tbaa !29
  %t208 = load ptr, ptr %l13, !tbaa !29
  %t210 = getelementptr %"compiler/load:Module", ptr %t208, i32 0, i32 0
  %t211 = load { i64, ptr }, ptr %t210, !tbaa !27
  %t213 = extractvalue { i64, ptr } %t211, 1
  %t214 = extractvalue { i64, ptr } %t211, 0
  %t215 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t214)
  call void @olang_textcopy(ptr %t215, ptr %t213, i64 %t214)
  %t216 = insertvalue { i64, ptr } undef, i64 %t214, 0
  %t217 = insertvalue { i64, ptr } %t216, ptr %t215, 1
  %t219 = extractvalue { i64, ptr } %t217, 0
  %t220 = extractvalue { i64, ptr } %t217, 1
  %t221 = mul i64 %t219, 1
  %t222 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t221)
  call void @llvm.memcpy.p0.p0.i64(ptr %t222, ptr %t220, i64 %t221, i1 false)
  %t223 = insertvalue { i64, ptr } undef, i64 %t219, 0
  %t224 = insertvalue { i64, ptr } %t223, ptr %t222, 1
  store { i64, ptr } %t224, ptr %l106, !tbaa !27
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t227 = getelementptr %"compiler/load:Loader", ptr %t225, i32 0, i32 8
  %t228 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t231 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha4444909f5ef14f7626d25b8f59e6ba2(ptr %v0, ptr %s0, ptr %v0, ptr %t227, { i64, ptr } %t228)
  %t232 = extractvalue { i32, { i64, ptr } } %t231, 1
  %t233 = extractvalue { i32, { i64, ptr } } %t231, 0
  store i32 %t233, ptr %l112
  %t234 = icmp ne i32 %t233, 0
  br i1 %t234, label %bb35, label %ok.235
ok.235:
  store { i64, ptr } %t232, ptr %l111
  br label %bb34
bb33:
  %t236 = load ptr, ptr %l13, !tbaa !29
  store ptr %t236, ptr %l116, !tbaa !29
  %t237 = load ptr, ptr %l13, !tbaa !29
  %t239 = getelementptr %"compiler/load:Module", ptr %t237, i32 0, i32 0
  %t240 = load { i64, ptr }, ptr %t239, !tbaa !27
  %t242 = call { i32, %"compiler/source:Source" } @compiler_2fsource_2eRead(ptr %v0, ptr %v0, { i64, ptr } %t240)
  %t243 = extractvalue { i32, %"compiler/source:Source" } %t242, 1
  %t244 = extractvalue { i32, %"compiler/source:Source" } %t242, 0
  store i32 %t244, ptr %l121
  %t245 = icmp ne i32 %t244, 0
  br i1 %t245, label %bb41, label %ok.246
ok.246:
  store %"compiler/source:Source" %t243, ptr %l120
  br label %bb40
bb34:
  %t247 = load { i64, ptr }, ptr %l111, !tbaa !27
  store { i64, ptr } %t247, ptr %l107, !tbaa !27
  br label %bb38
bb35:
  %t248 = load i32, ptr %l112, !tbaa !23
  %t249 = icmp eq i32 %t248, 65536
  br i1 %t249, label %bb36, label %bb37
bb36:
  call void @__olang_bang_failed(ptr @olang_loc_e403cb93f671e1d2_e7fcc79a06633816)
  unreachable
bb37:
  call void @__olang_bang_failed(ptr @olang_loc_664a4422ae98fea4_a167a9a7a681bc90)
  unreachable
bb38:
  %t251 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t252 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t253 = call %"compiler/source:Source" @compiler_2fsource_3aSource_2ector(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t251, { i64, ptr } %t252)
  store %"compiler/source:Source" %t253, ptr %l114
  br label %bb39
bb39:
  %t254 = load %"compiler/source:Source", ptr %l114
  %t255 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store %"compiler/source:Source" %t254, ptr %t255
  %t257 = load ptr, ptr %l102, !tbaa !29
  %t258 = getelementptr %"compiler/load:Module", ptr %t257, i32 0, i32 6
  store ptr %t255, ptr %t258, !tbaa !29
  br label %bb53
bb40:
  %t259 = load %"compiler/source:Source", ptr %l120
  store %"compiler/source:Source" %t259, ptr %l117
  br label %bb52
bb41:
  %t260 = load i32, ptr %l121, !tbaa !23
  %t261 = ashr i32 %t260, 16
  %t263 = icmp eq i32 %t261, 1
  br i1 %t263, label %bb42, label %bb43
bb42:
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_9fb00b21f6ee0659_5158dcd84d792d55)
  unreachable
bb44:
  store %olang.scope zeroinitializer, ptr %s13
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t267 = getelementptr %"compiler/load:Loader", ptr %t265, i32 0, i32 4
  %t268 = load ptr, ptr %t267, !tbaa !29
  %t269 = load ptr, ptr %l13, !tbaa !29
  %t271 = getelementptr %"compiler/load:Module", ptr %t269, i32 0, i32 0
  %t272 = load { i64, ptr }, ptr %t271, !tbaa !27
  %t275 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAddFile(ptr %v0, ptr %v0, ptr %v0, ptr %t268, { i64, ptr } %t272, { i64, ptr } { i64 0, ptr @.d44 }, i1 false)
  store i64 %t275, ptr %l128
  br label %bb45
bb45:
  %t276 = load i64, ptr %l128, !tbaa !24
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t279 = getelementptr %"compiler/load:Loader", ptr %t277, i32 0, i32 4
  %t280 = load ptr, ptr %t279, !tbaa !29
  store ptr %t280, ptr %l130, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t282
  %t283 = getelementptr { i64, [3 x i64] }, ptr %t282, i32 0, i32 0
  store i64 1, ptr %t283
  %t285 = insertvalue { i64 } undef, i64 %t276, 0
  %t286 = getelementptr { i64, [3 x i64] }, ptr %t282, i32 0, i32 1
  store { i64 } %t285, ptr %t286
  %t287 = load { i64, [3 x i64] }, ptr %t282
  store { i64, [3 x i64] } %t287, ptr %l132
  %t288 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %s13)
  store %"compiler/msgs:Msg" %t288, ptr %l133
  br label %bb46
bb46:
  %t289 = load ptr, ptr %l130, !tbaa !29
  %t290 = load { i64, [3 x i64] }, ptr %l132
  %t291 = load %"compiler/msgs:Msg", ptr %l133
  %t292 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s13, ptr %t289, { i64, [3 x i64] } %t290, %"compiler/msgs:Msg" %t291)
  store i64 %t292, ptr %l134
  br label %bb47
bb47:
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t295 = getelementptr %"compiler/load:Loader", ptr %t293, i32 0, i32 5
  %t297 = call { i32, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H78ccce95e6ef2f62693281865bce11fb(ptr %v0, ptr %v0, ptr %t295)
  %t298 = extractvalue { i32, ptr } %t297, 1
  %t299 = extractvalue { i32, ptr } %t297, 0
  store i32 %t299, ptr %l139
  %t300 = icmp ne i32 %t299, 0
  br i1 %t300, label %bb49, label %ok.301
ok.301:
  store ptr %t298, ptr %l138
  br label %bb48
bb48:
  %t302 = load ptr, ptr %l138, !tbaa !29
  store ptr %t302, ptr %l135, !tbaa !29
  br label %bb51
bb49:
  br label %bb50
bb50:
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb52:
  %t304 = load %"compiler/source:Source", ptr %l117
  %t305 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store %"compiler/source:Source" %t304, ptr %t305
  %t307 = load ptr, ptr %l116, !tbaa !29
  %t308 = getelementptr %"compiler/load:Module", ptr %t307, i32 0, i32 6
  store ptr %t305, ptr %t308, !tbaa !29
  br label %bb53
bb53:
  %t309 = load ptr, ptr %l13, !tbaa !29
  store ptr %t309, ptr %l142, !tbaa !29
  %t310 = load ptr, ptr %l0, !tbaa !29
  %t312 = getelementptr %"compiler/load:Loader", ptr %t310, i32 0, i32 4
  %t313 = load ptr, ptr %t312, !tbaa !29
  store ptr %t313, ptr %l144, !tbaa !29
  %t314 = load ptr, ptr %l13, !tbaa !29
  %t316 = getelementptr %"compiler/load:Module", ptr %t314, i32 0, i32 0
  %t317 = load { i64, ptr }, ptr %t316, !tbaa !27
  store { i64, ptr } %t317, ptr %l146, !tbaa !27
  %t318 = load ptr, ptr %l13, !tbaa !29
  %t320 = getelementptr %"compiler/load:Module", ptr %t318, i32 0, i32 6
  %t321 = load ptr, ptr %t320, !tbaa !29
  %t323 = icmp eq ptr %t321, null
  br i1 %t323, label %bb54, label %bb55
bb54:
  call void @__olang_check_failed(ptr @olang_loc_97fda29c929b9401_a297b77e137a783d)
  unreachable
bb55:
  br label %bb56
bb56:
  %t325 = load ptr, ptr %l13, !tbaa !29
  %t327 = getelementptr %"compiler/load:Module", ptr %t325, i32 0, i32 6
  %t328 = load ptr, ptr %t327, !tbaa !29
  %t331 = getelementptr %"compiler/source:Source", ptr %t328, i32 0, i32 1
  %t332 = load { i64, ptr }, ptr %t331, !tbaa !27
  store { i64, ptr } %t332, ptr %l153, !tbaa !27
  %t333 = load ptr, ptr %l13, !tbaa !29
  %t335 = getelementptr %"compiler/load:Module", ptr %t333, i32 0, i32 2
  %t336 = load { i64, ptr }, ptr %t335, !tbaa !27
  %t338 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t336, { i64, ptr } { i64 4, ptr @.d45 })
  store i1 %t338, ptr %l156
  br label %bb57
bb57:
  %t339 = load ptr, ptr %l144, !tbaa !29
  %t340 = load { i64, ptr }, ptr %l146, !tbaa !27
  %t341 = load { i64, ptr }, ptr %l153, !tbaa !27
  %t342 = load i1, ptr %l156, !tbaa !21
  %t343 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAddFile(ptr %v0, ptr %v0, ptr %v0, ptr %t339, { i64, ptr } %t340, { i64, ptr } %t341, i1 %t342)
  store i64 %t343, ptr %l157
  br label %bb58
bb58:
  %t344 = load i64, ptr %l157, !tbaa !24
  %t345 = load ptr, ptr %l142, !tbaa !29
  %t346 = getelementptr %"compiler/load:Module", ptr %t345, i32 0, i32 4
  store i64 %t344, ptr %t346, !tbaa !24
  %t347 = load ptr, ptr %l13, !tbaa !29
  store ptr %t347, ptr %l158, !tbaa !29
  %t348 = load ptr, ptr %l13, !tbaa !29
  %t350 = getelementptr %"compiler/load:Module", ptr %t348, i32 0, i32 6
  %t351 = load ptr, ptr %t350, !tbaa !29
  %t353 = icmp eq ptr %t351, null
  br i1 %t353, label %bb59, label %bb60
bb59:
  call void @__olang_check_failed(ptr @olang_loc_8eb73d0fe26fae48_56cde13f0d79d76c)
  unreachable
bb60:
  br label %bb61
bb61:
  %t355 = load ptr, ptr %l13, !tbaa !29
  %t357 = getelementptr %"compiler/load:Module", ptr %t355, i32 0, i32 6
  %t358 = load ptr, ptr %t357, !tbaa !29
  %t361 = getelementptr %"compiler/source:Source", ptr %t358, i32 0, i32 1
  %t362 = load { i64, ptr }, ptr %t361, !tbaa !27
  %t364 = call %"compiler/scan:Tokens" @compiler_2fscan_2eScan(ptr %v0, ptr %v0, { i64, ptr } %t362)
  store %"compiler/scan:Tokens" %t364, ptr %l166
  br label %bb62
bb62:
  %t365 = load %"compiler/scan:Tokens", ptr %l166
  %t366 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 64, i64 8)
  store %"compiler/scan:Tokens" %t365, ptr %t366
  %t368 = load ptr, ptr %l158, !tbaa !29
  %t369 = getelementptr %"compiler/load:Module", ptr %t368, i32 0, i32 7
  store ptr %t366, ptr %t369, !tbaa !29
  %t370 = load ptr, ptr %l13, !tbaa !29
  %t372 = getelementptr %"compiler/load:Module", ptr %t370, i32 0, i32 7
  %t373 = load ptr, ptr %t372, !tbaa !29
  %t375 = icmp eq ptr %t373, null
  br i1 %t375, label %bb63, label %bb64
bb63:
  call void @__olang_check_failed(ptr @olang_loc_ec0a8ee137cfd267_208c661d4674a25b)
  unreachable
bb64:
  br label %bb65
bb65:
  %t377 = load ptr, ptr %l13, !tbaa !29
  %t379 = getelementptr %"compiler/load:Module", ptr %t377, i32 0, i32 7
  %t380 = load ptr, ptr %t379, !tbaa !29
  %t383 = getelementptr %"compiler/scan:Tokens", ptr %t380, i32 0, i32 3
  %t384 = load { i64, ptr }, ptr %t383, !tbaa !27
  store { i64, ptr } %t384, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t386 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t388 = extractvalue { i64, ptr } %t386, 0
  store i64 %t388, ptr %l18, !tbaa !24
  br label %bb66
bb66:
  store %olang.scope zeroinitializer, ptr %s16
  %t390 = load i64, ptr %l17, !tbaa !24
  %t391 = load i64, ptr %l18, !tbaa !24
  %t394 = icmp slt i64 %t390, %t391
  %t396 = xor i1 %t394, true
  br i1 %t396, label %bb67, label %bb68
bb67:
  call void @__olang_scope_close(ptr %s16)
  br label %bb75
bb68:
  br label %bb69
bb69:
  %t398 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t398, ptr %l181, !tbaa !27
  %t399 = load i64, ptr %l17, !tbaa !24
  %t401 = getelementptr { i64, ptr }, ptr %l181, i32 0, i32 1
  %t402 = load ptr, ptr %t401, !tbaa !27
  %t403 = getelementptr %"compiler/scan:Diag", ptr %t402, i64 %t399
  %t404 = load %"compiler/scan:Diag", ptr %t403
  store %"compiler/scan:Diag" %t404, ptr %l19
  %t406 = getelementptr %"compiler/scan:Diag", ptr %l19, i32 0, i32 1
  %t407 = load i32, ptr %t406, !tbaa !23
  %t409 = load ptr, ptr %l0, !tbaa !29
  %t411 = getelementptr %"compiler/load:Loader", ptr %t409, i32 0, i32 4
  %t412 = load ptr, ptr %t411, !tbaa !29
  store ptr %t412, ptr %l186, !tbaa !29
  %t413 = load ptr, ptr %l13, !tbaa !29
  %t415 = getelementptr %"compiler/load:Module", ptr %t413, i32 0, i32 4
  %t416 = load i64, ptr %t415, !tbaa !24
  %t419 = sext i32 %t407 to i64
  %t420 = getelementptr %"compiler/scan:Diag", ptr %l19, i32 0, i32 2
  %t421 = load i32, ptr %t420, !tbaa !23
  %t423 = sext i32 %t421 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t424
  %t425 = getelementptr { i64, [3 x i64] }, ptr %t424, i32 0, i32 0
  store i64 3, ptr %t425
  %t427 = insertvalue { i64, i64, i64 } undef, i64 %t416, 0
  %t429 = insertvalue { i64, i64, i64 } %t427, i64 %t419, 1
  %t431 = insertvalue { i64, i64, i64 } %t429, i64 %t423, 2
  %t432 = getelementptr { i64, [3 x i64] }, ptr %t424, i32 0, i32 1
  store { i64, i64, i64 } %t431, ptr %t432
  %t433 = load { i64, [3 x i64] }, ptr %t424
  store { i64, [3 x i64] } %t433, ptr %l193
  store i32 50, ptr %l194
  %t434 = load %"compiler/scan:Diag", ptr %l19
  %t436 = call { i64, ptr } @compiler_2fscan_2ecompiler_2fscan_3aDiag_2eRule(ptr %s16, %"compiler/scan:Diag" %t434)
  store { i64, ptr } %t436, ptr %l196
  br label %bb70
bb70:
  %t437 = load %"compiler/scan:Diag", ptr %l19
  %t439 = call { i64, ptr } @compiler_2fscan_2ecompiler_2fscan_3aDiag_2eMessage(ptr %s16, %"compiler/scan:Diag" %t437)
  store { i64, ptr } %t439, ptr %l198
  br label %bb71
bb71:
  %t440 = load { i64, ptr }, ptr %l198, !tbaa !27
  %t441 = extractvalue { i64, ptr } %t440, 0
  %t442 = extractvalue { i64, ptr } %t440, 1
  %t443 = mul i64 %t441, 1
  %t444 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t443)
  call void @llvm.memcpy.p0.p0.i64(ptr %t444, ptr %t442, i64 %t443, i1 false)
  %t445 = insertvalue { i64, ptr } undef, i64 %t441, 0
  %t446 = insertvalue { i64, ptr } %t445, ptr %t444, 1
  %t447 = load i32, ptr %l194
  %t448 = load { i64, ptr }, ptr %l196, !tbaa !27
  %t450 = call %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %s16, ptr %s16, ptr %s16, i32 %t447, { i64, ptr } %t448, { i64, ptr } %t446)
  store %"compiler/msgs:Msg" %t450, ptr %l200
  br label %bb72
bb72:
  %t451 = load ptr, ptr %l186, !tbaa !29
  %t452 = load { i64, [3 x i64] }, ptr %l193
  %t453 = load %"compiler/msgs:Msg", ptr %l200
  %t454 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s16, ptr %t451, { i64, [3 x i64] } %t452, %"compiler/msgs:Msg" %t453)
  store i64 %t454, ptr %l201
  br label %bb73
bb73:
  call void @__olang_scope_close(ptr %s16)
  br label %bb74
bb74:
  %t455 = load i64, ptr %l17, !tbaa !24
  %t457 = add i64 %t455, 1
  store i64 %t457, ptr %l17, !tbaa !24
  br label %bb66
bb75:
  %t459 = load ptr, ptr %l0, !tbaa !29
  %t460 = load ptr, ptr %l13, !tbaa !29
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2eprescan(ptr %v0, ptr %v0, ptr %t459, ptr %t460)
  br label %bb76
bb76:
  %t463 = load ptr, ptr %l13, !tbaa !29
  store ptr %t463, ptr %l206, !tbaa !29
  %t464 = call %"compiler/parse:Oracle" @compiler_2fparse_3aOracle_2ector(ptr %v0)
  store %"compiler/parse:Oracle" %t464, ptr %l207
  br label %bb77
bb77:
  %t465 = load %"compiler/parse:Oracle", ptr %l207
  %t466 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/parse:Oracle" %t465, ptr %t466
  %t468 = load ptr, ptr %l206, !tbaa !29
  %t469 = getelementptr %"compiler/load:Module", ptr %t468, i32 0, i32 12
  store ptr %t466, ptr %t469, !tbaa !29
  %t470 = load ptr, ptr %l0, !tbaa !29
  %t471 = load ptr, ptr %l13, !tbaa !29
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2eownNames(ptr %v0, ptr %v0, ptr %t470, ptr %t471)
  br label %bb78
bb78:
  %t474 = load ptr, ptr %l0, !tbaa !29
  %t475 = load i64, ptr %l12, !tbaa !24
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2eloadImports(ptr %v0, ptr %t474, i64 %t475)
  br label %bb79
bb79:
  %t478 = load ptr, ptr %l0, !tbaa !29
  %t479 = load i64, ptr %l12, !tbaa !24
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2eparse(ptr %v0, ptr %t478, i64 %t479)
  br label %bb80
bb80:
  %t482 = load i64, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t482, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fload_2ecompiler_2fload_3aLoader_2eloadImports(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"compiler/load:Import"
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca %"compiler/load:Import"
  %l13 = alloca { { i64, ptr }, { i64, ptr } }
  %l16 = alloca i64
  %l17 = alloca i1
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca %"compiler/load:Import"
  %l29 = alloca ptr
  %l32 = alloca i64
  %l36 = alloca i64
  %l39 = alloca i64
  %l60 = alloca %"compiler/load:Import"
  %l63 = alloca i1
  %l69 = alloca i64
  %l75 = alloca %"compiler/load:Import"
  %l82 = alloca i1
  %l85 = alloca ptr
  %l89 = alloca { i64, [3 x i64] }
  %l91 = alloca %"compiler/msgs:Msg"
  %l92 = alloca i64
  %l93 = alloca { { i64, ptr }, { i64, ptr } }
  %l97 = alloca { { i64, ptr }, { i64, ptr } }
  %l98 = alloca i32
  %l99 = alloca { i64, ptr }
  %l100 = alloca i64
  %l101 = alloca { i64, ptr }
  %l102 = alloca { i64, ptr }
  %l103 = alloca i64
  %l104 = alloca { i64, ptr }
  %l108 = alloca i64
  %l113 = alloca i64
  %l117 = alloca i64
  %l120 = alloca i64
  %l141 = alloca i1
  %l145 = alloca %"compiler/load:Import"
  %l148 = alloca i1
  %l152 = alloca %"compiler/load:Import"
  %l155 = alloca i1
  %l160 = alloca ptr
  %l164 = alloca { i64, [3 x i64] }
  %l166 = alloca %"compiler/msgs:Msg"
  %l167 = alloca i64
  %l172 = alloca %"compiler/load:Import"
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s12 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/load:Loader", ptr %t1, i32 0, i32 5
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l29
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l29, !tbaa !29
  store ptr %t8, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  %t9 = load ptr, ptr %l2, !tbaa !29
  %t11 = getelementptr %"compiler/load:Module", ptr %t9, i32 0, i32 11
  %t13 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2eLen_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %t11)
  store i64 %t13, ptr %l32
  br label %bb2
bb2:
  %t14 = load i64, ptr %l32, !tbaa !24
  store i64 %t14, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = icmp sgt i64 %t15, %t16
  br i1 %t19, label %bb3, label %bb4
bb3:
  %t21 = load i64, ptr %l5, !tbaa !24
  %t23 = icmp sgt i64 %t21, 0
  br i1 %t23, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l36, !tbaa !24
  br label %bb8
bb5:
  %t25 = load i64, ptr %l4, !tbaa !24
  %t26 = load i64, ptr %l3, !tbaa !24
  %t29 = sub i64 %t25, %t26
  %t30 = load i64, ptr %l5, !tbaa !24
  %t33 = add i64 %t29, %t30
  %t35 = sub i64 %t33, 1
  %t36 = load i64, ptr %l5, !tbaa !24
  %t39 = sdiv i64 %t35, %t36
  store i64 %t39, ptr %l39, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l39, !tbaa !24
  br label %bb7
bb7:
  %t41 = load i64, ptr %l39, !tbaa !24
  store i64 %t41, ptr %l36, !tbaa !24
  br label %bb8
bb8:
  %t42 = load i64, ptr %l36, !tbaa !24
  store i64 %t42, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t43 = load i64, ptr %l7, !tbaa !24
  %t44 = load i64, ptr %l6, !tbaa !24
  %t47 = icmp slt i64 %t43, %t44
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb75
bb11:
  br label %bb12
bb12:
  %t51 = load i64, ptr %l3, !tbaa !24
  %t52 = load i64, ptr %l7, !tbaa !24
  %t53 = load i64, ptr %l5, !tbaa !24
  %t56 = mul i64 %t52, %t53
  %t59 = add i64 %t51, %t56
  store i64 %t59, ptr %l8, !tbaa !24
  %t61 = load ptr, ptr %l2, !tbaa !29
  %t63 = getelementptr %"compiler/load:Module", ptr %t61, i32 0, i32 11
  %t64 = load i64, ptr %l8, !tbaa !24
  %t67 = call %"compiler/load:Import" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2eAt_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v0, ptr %t63, i64 %t64)
  store %"compiler/load:Import" %t67, ptr %l60
  br label %bb13
bb13:
  %t68 = load %"compiler/load:Import", ptr %l60
  store %"compiler/load:Import" %t68, ptr %l9
  %t69 = getelementptr %"compiler/load:Import", ptr %l9, i32 0, i32 5
  %t70 = load i64, ptr %t69, !tbaa !24
  %t72 = icmp sge i64 %t70, 0
  br i1 %t72, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l63, !tbaa !21
  br label %bb16
bb15:
  %t74 = getelementptr %"compiler/load:Import", ptr %l9, i32 0, i32 5
  %t75 = load i64, ptr %t74, !tbaa !24
  %t77 = icmp eq i64 %t75, -2
  store i1 %t77, ptr %l63, !tbaa !21
  br label %bb16
bb16:
  %t79 = load i1, ptr %l63, !tbaa !21
  br i1 %t79, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb74
bb18:
  br label %bb19
bb19:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load i64, ptr %l1, !tbaa !24
  %t82 = getelementptr %"compiler/load:Import", ptr %l9, i32 0, i32 4
  %t83 = load i64, ptr %t82, !tbaa !24
  %t87 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2etaken(ptr %v0, ptr %t80, i64 %t81, i64 %t83)
  store i64 %t87, ptr %l69
  br label %bb20
bb20:
  %t88 = load i64, ptr %l69, !tbaa !24
  %t89 = icmp ne i64 %t88, 1
  br i1 %t89, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb74
bb22:
  br label %bb23
bb23:
  %t91 = load i64, ptr %l8, !tbaa !24
  store i64 %t91, ptr %l10, !tbaa !24
  store i64 -2, ptr %l11, !tbaa !24
  %t93 = load ptr, ptr %l2, !tbaa !29
  %t95 = getelementptr %"compiler/load:Module", ptr %t93, i32 0, i32 11
  %t96 = load i64, ptr %l10, !tbaa !24
  %t99 = call %"compiler/load:Import" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2eAt_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v0, ptr %t95, i64 %t96)
  store %"compiler/load:Import" %t99, ptr %l75
  br label %bb24
bb24:
  %t100 = load %"compiler/load:Import", ptr %l75
  store %"compiler/load:Import" %t100, ptr %l12
  %t101 = load i64, ptr %l11, !tbaa !24
  %t103 = getelementptr %"compiler/load:Import", ptr %l12, i32 0, i32 5
  store i64 %t101, ptr %t103, !tbaa !24
  %t104 = load ptr, ptr %l2, !tbaa !29
  %t106 = getelementptr %"compiler/load:Module", ptr %t104, i32 0, i32 11
  %t107 = load i64, ptr %l10, !tbaa !24
  %t108 = load %"compiler/load:Import", ptr %l12
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2eSetAt_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v0, ptr %t106, i64 %t107, %"compiler/load:Import" %t108)
  br label %bb25
bb25:
  %t112 = getelementptr %"compiler/load:Import", ptr %l9, i32 0, i32 2
  %t113 = load { i64, ptr }, ptr %t112, !tbaa !27
  %t115 = call i1 @compiler_2fload_2eAliasShape(ptr %v0, { i64, ptr } %t113)
  store i1 %t115, ptr %l82
  br label %bb26
bb26:
  %t116 = load i1, ptr %l82, !tbaa !21
  %t117 = xor i1 %t116, true
  br i1 %t117, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s5
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/load:Loader", ptr %t119, i32 0, i32 4
  %t122 = load ptr, ptr %t121, !tbaa !29
  store ptr %t122, ptr %l85, !tbaa !29
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load ptr, ptr %l2, !tbaa !29
  %t125 = getelementptr %"compiler/load:Import", ptr %l9, i32 0, i32 1
  %t126 = load %"compiler/source:Span", ptr %t125
  %t130 = call { i64, [3 x i64] } @compiler_2fload_2ecompiler_2fload_3aLoader_2eat(ptr %v0, ptr %v0, ptr %t123, ptr %t124, %"compiler/source:Span" %t126)
  store { i64, [3 x i64] } %t130, ptr %l89
  br label %bb29
bb28:
  br label %bb32
bb29:
  %t131 = getelementptr %"compiler/load:Import", ptr %l9, i32 0, i32 2
  %t132 = load { i64, ptr }, ptr %t131, !tbaa !27
  %t134 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportAliasInvalid(ptr %v0, ptr %s5, { i64, ptr } %t132)
  store %"compiler/msgs:Msg" %t134, ptr %l91
  br label %bb30
bb30:
  %t135 = load ptr, ptr %l85, !tbaa !29
  %t136 = load { i64, [3 x i64] }, ptr %l89
  %t137 = load %"compiler/msgs:Msg", ptr %l91
  %t138 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s5, ptr %t135, { i64, [3 x i64] } %t136, %"compiler/msgs:Msg" %t137)
  store i64 %t138, ptr %l92
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s2)
  br label %bb74
bb32:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load i64, ptr %l1, !tbaa !24
  %t141 = load %"compiler/load:Import", ptr %l9
  %t145 = call { i32, { { i64, ptr }, { i64, ptr } } } @compiler_2fload_2ecompiler_2fload_3aLoader_2eresolve(ptr %v0, ptr %v0, ptr %s2, ptr %t139, i64 %t140, %"compiler/load:Import" %t141)
  %t146 = extractvalue { i32, { { i64, ptr }, { i64, ptr } } } %t145, 1
  %t147 = extractvalue { i32, { { i64, ptr }, { i64, ptr } } } %t145, 0
  store i32 %t147, ptr %l98
  %t148 = icmp ne i32 %t147, 0
  br i1 %t148, label %bb34, label %ok.149
ok.149:
  store { { i64, ptr }, { i64, ptr } } %t146, ptr %l97
  br label %bb33
bb33:
  %t150 = load { { i64, ptr }, { i64, ptr } }, ptr %l97
  store { { i64, ptr }, { i64, ptr } } %t150, ptr %l93
  br label %bb36
bb34:
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s2)
  br label %bb74
bb36:
  %t151 = load { { i64, ptr }, { i64, ptr } }, ptr %l93
  store { { i64, ptr }, { i64, ptr } } %t151, ptr %l13
  %t152 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l13, i32 0, i32 0
  %t153 = load { i64, ptr }, ptr %t152, !tbaa !27
  store { i64, ptr } %t153, ptr %l99, !tbaa !27
  %t154 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t155 = extractvalue { i64, ptr } %t154, 0
  store i64 %t155, ptr %l100, !tbaa !24
  %t156 = load i64, ptr %l100, !tbaa !24
  %t157 = mul i64 %t156, 1
  %t158 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t157)
  %t159 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t160 = insertvalue { i64, ptr } %t159, ptr %t158, 1
  store { i64, ptr } %t160, ptr %l101, !tbaa !27
  %t161 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t162 = load ptr, ptr %t161, !tbaa !27
  %t163 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t164 = load ptr, ptr %t163, !tbaa !27
  %t165 = load i64, ptr %l100, !tbaa !24
  %t166 = mul i64 %t165, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t162, ptr %t164, i64 %t166, i1 false)
  %t167 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t168 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l13, i32 0, i32 1
  %t169 = load { i64, ptr }, ptr %t168, !tbaa !27
  store { i64, ptr } %t169, ptr %l102, !tbaa !27
  %t170 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t171 = extractvalue { i64, ptr } %t170, 0
  store i64 %t171, ptr %l103, !tbaa !24
  %t172 = load i64, ptr %l103, !tbaa !24
  %t173 = mul i64 %t172, 1
  %t174 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t173)
  %t175 = insertvalue { i64, ptr } undef, i64 %t172, 0
  %t176 = insertvalue { i64, ptr } %t175, ptr %t174, 1
  store { i64, ptr } %t176, ptr %l104, !tbaa !27
  %t177 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !27
  %t179 = getelementptr { i64, ptr }, ptr %l102, i32 0, i32 1
  %t180 = load ptr, ptr %t179, !tbaa !27
  %t181 = load i64, ptr %l103, !tbaa !24
  %t182 = mul i64 %t181, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t178, ptr %t180, i64 %t182, i1 false)
  %t183 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t190 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eload(ptr %v0, ptr %s2, ptr %s2, ptr %t184, { i64, ptr } %t167, { i64, ptr } %t183, i1 false)
  store i64 %t190, ptr %l108
  br label %bb37
bb37:
  %t191 = load i64, ptr %l108, !tbaa !24
  store i64 %t191, ptr %l16, !tbaa !24
  %t192 = load i64, ptr %l16, !tbaa !24
  %t194 = icmp slt i64 %t192, 0
  br i1 %t194, label %bb38, label %bb39
bb38:
  call void @__olang_scope_close(ptr %s2)
  br label %bb74
bb39:
  br label %bb40
bb40:
  store i1 false, ptr %l17, !tbaa !21
  store i64 0, ptr %l18, !tbaa !24
  %t196 = load ptr, ptr %l2, !tbaa !29
  %t198 = getelementptr %"compiler/load:Module", ptr %t196, i32 0, i32 11
  %t200 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2eLen_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %t198)
  store i64 %t200, ptr %l113
  br label %bb41
bb41:
  %t201 = load i64, ptr %l113, !tbaa !24
  store i64 %t201, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t202 = load i64, ptr %l19, !tbaa !24
  %t203 = load i64, ptr %l18, !tbaa !24
  %t206 = icmp sgt i64 %t202, %t203
  br i1 %t206, label %bb42, label %bb43
bb42:
  %t208 = load i64, ptr %l20, !tbaa !24
  %t210 = icmp sgt i64 %t208, 0
  br i1 %t210, label %bb44, label %bb45
bb43:
  store i64 0, ptr %l117, !tbaa !24
  br label %bb47
bb44:
  %t212 = load i64, ptr %l19, !tbaa !24
  %t213 = load i64, ptr %l18, !tbaa !24
  %t216 = sub i64 %t212, %t213
  %t217 = load i64, ptr %l20, !tbaa !24
  %t220 = add i64 %t216, %t217
  %t222 = sub i64 %t220, 1
  %t223 = load i64, ptr %l20, !tbaa !24
  %t226 = sdiv i64 %t222, %t223
  store i64 %t226, ptr %l120, !tbaa !24
  br label %bb46
bb45:
  store i64 0, ptr %l120, !tbaa !24
  br label %bb46
bb46:
  %t228 = load i64, ptr %l120, !tbaa !24
  store i64 %t228, ptr %l117, !tbaa !24
  br label %bb47
bb47:
  %t229 = load i64, ptr %l117, !tbaa !24
  store i64 %t229, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb48
bb48:
  store %olang.scope zeroinitializer, ptr %s9
  %t230 = load i64, ptr %l22, !tbaa !24
  %t231 = load i64, ptr %l21, !tbaa !24
  %t234 = icmp slt i64 %t230, %t231
  %t236 = xor i1 %t234, true
  br i1 %t236, label %bb49, label %bb50
bb49:
  call void @__olang_scope_close(ptr %s9)
  br label %bb65
bb50:
  br label %bb51
bb51:
  %t238 = load i64, ptr %l18, !tbaa !24
  %t239 = load i64, ptr %l22, !tbaa !24
  %t240 = load i64, ptr %l20, !tbaa !24
  %t243 = mul i64 %t239, %t240
  %t246 = add i64 %t238, %t243
  store i64 %t246, ptr %l23, !tbaa !24
  %t248 = load i64, ptr %l23, !tbaa !24
  %t249 = load i64, ptr %l8, !tbaa !24
  %t252 = icmp ne i64 %t248, %t249
  br i1 %t252, label %bb52, label %bb53
bb52:
  %t254 = load ptr, ptr %l2, !tbaa !29
  %t256 = getelementptr %"compiler/load:Module", ptr %t254, i32 0, i32 11
  %t257 = load i64, ptr %l23, !tbaa !24
  %t260 = call %"compiler/load:Import" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2eAt_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %s9, ptr %t256, i64 %t257)
  store %"compiler/load:Import" %t260, ptr %l145
  br label %bb54
bb53:
  store i1 false, ptr %l141, !tbaa !21
  br label %bb55
bb54:
  %t261 = getelementptr %"compiler/load:Import", ptr %l145, i32 0, i32 5
  %t262 = load i64, ptr %t261, !tbaa !24
  %t264 = icmp sge i64 %t262, 0
  store i1 %t264, ptr %l141, !tbaa !21
  br label %bb55
bb55:
  %t266 = load i1, ptr %l141, !tbaa !21
  br i1 %t266, label %bb56, label %bb57
bb56:
  %t267 = load ptr, ptr %l2, !tbaa !29
  %t269 = getelementptr %"compiler/load:Module", ptr %t267, i32 0, i32 11
  %t270 = load i64, ptr %l23, !tbaa !24
  %t273 = call %"compiler/load:Import" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2eAt_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v0, ptr %t269, i64 %t270)
  store %"compiler/load:Import" %t273, ptr %l152
  br label %bb58
bb57:
  store i1 false, ptr %l148, !tbaa !21
  br label %bb60
bb58:
  %t274 = getelementptr %"compiler/load:Import", ptr %l152, i32 0, i32 2
  %t275 = load { i64, ptr }, ptr %t274, !tbaa !27
  %t276 = getelementptr %"compiler/load:Import", ptr %l9, i32 0, i32 2
  %t277 = load { i64, ptr }, ptr %t276, !tbaa !27
  %t280 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v0, { i64, ptr } %t275, { i64, ptr } %t277)
  store i1 %t280, ptr %l155
  br label %bb59
bb59:
  %t281 = load i1, ptr %l155, !tbaa !21
  store i1 %t281, ptr %l148, !tbaa !21
  br label %bb60
bb60:
  %t282 = load i1, ptr %l148, !tbaa !21
  br i1 %t282, label %bb61, label %bb62
bb61:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb63
bb62:
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s9)
  br label %bb64
bb64:
  %t283 = load i64, ptr %l22, !tbaa !24
  %t285 = add i64 %t283, 1
  store i64 %t285, ptr %l22, !tbaa !24
  br label %bb48
bb65:
  %t287 = load i1, ptr %l17, !tbaa !21
  br i1 %t287, label %bb66, label %bb67
bb66:
  store %olang.scope zeroinitializer, ptr %s12
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t291 = getelementptr %"compiler/load:Loader", ptr %t289, i32 0, i32 4
  %t292 = load ptr, ptr %t291, !tbaa !29
  store ptr %t292, ptr %l160, !tbaa !29
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t294 = load ptr, ptr %l2, !tbaa !29
  %t295 = getelementptr %"compiler/load:Import", ptr %l9, i32 0, i32 1
  %t296 = load %"compiler/source:Span", ptr %t295
  %t300 = call { i64, [3 x i64] } @compiler_2fload_2ecompiler_2fload_3aLoader_2eat(ptr %v0, ptr %v0, ptr %t293, ptr %t294, %"compiler/source:Span" %t296)
  store { i64, [3 x i64] } %t300, ptr %l164
  br label %bb68
bb67:
  br label %bb71
bb68:
  %t301 = getelementptr %"compiler/load:Import", ptr %l9, i32 0, i32 2
  %t302 = load { i64, ptr }, ptr %t301, !tbaa !27
  %t304 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportAliasConflict(ptr %v0, ptr %s12, { i64, ptr } %t302)
  store %"compiler/msgs:Msg" %t304, ptr %l166
  br label %bb69
bb69:
  %t305 = load ptr, ptr %l160, !tbaa !29
  %t306 = load { i64, [3 x i64] }, ptr %l164
  %t307 = load %"compiler/msgs:Msg", ptr %l166
  %t308 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s12, ptr %t305, { i64, [3 x i64] } %t306, %"compiler/msgs:Msg" %t307)
  store i64 %t308, ptr %l167
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s2)
  br label %bb74
bb71:
  %t309 = load i64, ptr %l8, !tbaa !24
  store i64 %t309, ptr %l24, !tbaa !24
  %t311 = load ptr, ptr %l2, !tbaa !29
  %t313 = getelementptr %"compiler/load:Module", ptr %t311, i32 0, i32 11
  %t314 = load i64, ptr %l24, !tbaa !24
  %t317 = call %"compiler/load:Import" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2eAt_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v0, ptr %t313, i64 %t314)
  store %"compiler/load:Import" %t317, ptr %l172
  br label %bb72
bb72:
  %t318 = load %"compiler/load:Import", ptr %l172
  store %"compiler/load:Import" %t318, ptr %l25
  %t319 = load i64, ptr %l16, !tbaa !24
  %t321 = getelementptr %"compiler/load:Import", ptr %l25, i32 0, i32 5
  store i64 %t319, ptr %t321, !tbaa !24
  %t322 = load ptr, ptr %l2, !tbaa !29
  %t324 = getelementptr %"compiler/load:Module", ptr %t322, i32 0, i32 11
  %t325 = load i64, ptr %l24, !tbaa !24
  %t326 = load %"compiler/load:Import", ptr %l25
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2eSetAt_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v0, ptr %t324, i64 %t325, %"compiler/load:Import" %t326)
  br label %bb73
bb73:
  call void @__olang_scope_close(ptr %s2)
  br label %bb74
bb74:
  %t330 = load i64, ptr %l7, !tbaa !24
  %t332 = add i64 %t330, 1
  store i64 %t332, ptr %l7, !tbaa !24
  br label %bb9
bb75:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fload_2ecompiler_2fload_3aLoader_2eownNames(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i32
  %l35 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l57 = alloca i32
  %l66 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %l88 = alloca i32
  %l97 = alloca { i64, ptr }
  %l100 = alloca { i64, ptr }
  %l102 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/load:Module", ptr %t1, i32 0, i32 9
  store ptr %t3, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %l3, !tbaa !24
  %t9 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v1, ptr %t5, i64 %t6)
  %t10 = extractvalue { i32, { i64, ptr } } %t9, 1
  %t11 = extractvalue { i32, { i64, ptr } } %t9, 0
  store i32 %t11, ptr %l26
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb3, label %ok.13
ok.13:
  store { i64, ptr } %t10, ptr %l25
  br label %bb2
bb2:
  %t14 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t14, ptr %l22, !tbaa !27
  br label %bb7
bb3:
  %t15 = load i32, ptr %l26, !tbaa !23
  %t16 = ashr i32 %t15, 16
  %t18 = icmp eq i32 %t16, 1
  br i1 %t18, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_49cedf3031712b7_3bc4f9aaebc3779b)
  unreachable
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb7:
  %t20 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t20, ptr %l4, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t25 = load i64, ptr %l6, !tbaa !24
  %t26 = load i64, ptr %l5, !tbaa !24
  %t29 = icmp slt i64 %t25, %t26
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb10:
  br label %bb11
bb11:
  %t33 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t33, ptr %l35, !tbaa !27
  %t34 = load i64, ptr %l6, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %t37, i64 %t34
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !37
  store { i64, ptr } %t39, ptr %l7, !tbaa !27
  %t41 = load ptr, ptr %l1, !tbaa !29
  %t43 = getelementptr %"compiler/load:Module", ptr %t41, i32 0, i32 12
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = icmp eq ptr %t44, null
  br i1 %t46, label %bb12, label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_4820d8be822def4f_666b99eead9f0f03)
  unreachable
bb13:
  br label %bb14
bb14:
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t50 = getelementptr %"compiler/load:Module", ptr %t48, i32 0, i32 12
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/load:Loader", ptr %t52, i32 0, i32 3
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t56 = load { i64, ptr }, ptr %l7, !tbaa !27
  call void @compiler_2fparse_2ecompiler_2fparse_3aOracle_2eAdd(ptr %v1, ptr %v0, ptr %s3, ptr %v1, ptr %t51, ptr %t55, { i64, ptr } { i64 0, ptr @.d46 }, { i64, ptr } %t56)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb16:
  %t60 = load i64, ptr %l6, !tbaa !24
  %t62 = add i64 %t60, 1
  store i64 %t62, ptr %l6, !tbaa !24
  br label %bb8
bb17:
  %t64 = load i64, ptr %l3, !tbaa !24
  %t65 = load i64, ptr %l5, !tbaa !24
  %t68 = add i64 %t64, %t65
  store i64 %t68, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  br label %bb1
bb19:
  %t70 = load ptr, ptr %l1, !tbaa !29
  %t72 = getelementptr %"compiler/load:Module", ptr %t70, i32 0, i32 10
  store ptr %t72, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s6
  %t74 = load ptr, ptr %l8, !tbaa !29
  %t75 = load i64, ptr %l9, !tbaa !24
  %t78 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v1, ptr %t74, i64 %t75)
  %t79 = extractvalue { i32, { i64, ptr } } %t78, 1
  %t80 = extractvalue { i32, { i64, ptr } } %t78, 0
  store i32 %t80, ptr %l57
  %t81 = icmp ne i32 %t80, 0
  br i1 %t81, label %bb22, label %ok.82
ok.82:
  store { i64, ptr } %t79, ptr %l56
  br label %bb21
bb21:
  %t83 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t83, ptr %l53, !tbaa !27
  br label %bb26
bb22:
  %t84 = load i32, ptr %l57, !tbaa !23
  %t85 = ashr i32 %t84, 16
  %t87 = icmp eq i32 %t85, 1
  br i1 %t87, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_86fa1f93e6420cad_823198da66b83db1)
  unreachable
bb25:
  call void @__olang_scope_close(ptr %s6)
  br label %bb38
bb26:
  %t89 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t89, ptr %l10, !tbaa !27
  %t90 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t90, 0
  store i64 %t92, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb27
bb27:
  store %olang.scope zeroinitializer, ptr %s7
  %t94 = load i64, ptr %l12, !tbaa !24
  %t95 = load i64, ptr %l11, !tbaa !24
  %t98 = icmp slt i64 %t94, %t95
  %t100 = xor i1 %t98, true
  br i1 %t100, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s7)
  br label %bb36
bb29:
  br label %bb30
bb30:
  %t102 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t102, ptr %l66, !tbaa !27
  %t103 = load i64, ptr %l12, !tbaa !24
  %t105 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !27
  %t107 = getelementptr { i64, ptr }, ptr %t106, i64 %t103
  %t108 = load { i64, ptr }, ptr %t107, !tbaa !37
  store { i64, ptr } %t108, ptr %l13, !tbaa !27
  %t110 = load ptr, ptr %l1, !tbaa !29
  %t112 = getelementptr %"compiler/load:Module", ptr %t110, i32 0, i32 12
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t115 = icmp eq ptr %t113, null
  br i1 %t115, label %bb31, label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_2ca78ec550b059c5_f5cdcad03c843269)
  unreachable
bb32:
  br label %bb33
bb33:
  %t117 = load ptr, ptr %l1, !tbaa !29
  %t119 = getelementptr %"compiler/load:Module", ptr %t117, i32 0, i32 12
  %t120 = load ptr, ptr %t119, !tbaa !29
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/load:Loader", ptr %t121, i32 0, i32 3
  %t124 = load ptr, ptr %t123, !tbaa !29
  %t125 = load { i64, ptr }, ptr %l13, !tbaa !27
  call void @compiler_2fparse_2ecompiler_2fparse_3aOracle_2eAddFn(ptr %v1, ptr %v0, ptr %s7, ptr %v1, ptr %t120, ptr %t124, { i64, ptr } { i64 0, ptr @.d47 }, { i64, ptr } %t125)
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s7)
  br label %bb35
bb35:
  %t129 = load i64, ptr %l12, !tbaa !24
  %t131 = add i64 %t129, 1
  store i64 %t131, ptr %l12, !tbaa !24
  br label %bb27
bb36:
  %t133 = load i64, ptr %l9, !tbaa !24
  %t134 = load i64, ptr %l11, !tbaa !24
  %t137 = add i64 %t133, %t134
  store i64 %t137, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb37
bb37:
  br label %bb20
bb38:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/load:Loader", ptr %t139, i32 0, i32 6
  store ptr %t141, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb39
bb39:
  store %olang.scope zeroinitializer, ptr %s10
  %t143 = load ptr, ptr %l14, !tbaa !29
  %t144 = load i64, ptr %l15, !tbaa !24
  %t147 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v0, ptr %t143, i64 %t144)
  %t148 = extractvalue { i32, { i64, ptr } } %t147, 1
  %t149 = extractvalue { i32, { i64, ptr } } %t147, 0
  store i32 %t149, ptr %l88
  %t150 = icmp ne i32 %t149, 0
  br i1 %t150, label %bb41, label %ok.151
ok.151:
  store { i64, ptr } %t148, ptr %l87
  br label %bb40
bb40:
  %t152 = load { i64, ptr }, ptr %l87, !tbaa !27
  store { i64, ptr } %t152, ptr %l84, !tbaa !27
  br label %bb45
bb41:
  %t153 = load i32, ptr %l88, !tbaa !23
  %t154 = ashr i32 %t153, 16
  %t156 = icmp eq i32 %t154, 1
  br i1 %t156, label %bb42, label %bb43
bb42:
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_648a5599090fec1b_dbd79204e5ca9e37)
  unreachable
bb44:
  call void @__olang_scope_close(ptr %s10)
  br label %bb61
bb45:
  %t158 = load { i64, ptr }, ptr %l84, !tbaa !27
  store { i64, ptr } %t158, ptr %l16, !tbaa !27
  %t159 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t161 = extractvalue { i64, ptr } %t159, 0
  store i64 %t161, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb46
bb46:
  store %olang.scope zeroinitializer, ptr %s11
  %t163 = load i64, ptr %l18, !tbaa !24
  %t164 = load i64, ptr %l17, !tbaa !24
  %t167 = icmp slt i64 %t163, %t164
  %t169 = xor i1 %t167, true
  br i1 %t169, label %bb47, label %bb48
bb47:
  call void @__olang_scope_close(ptr %s11)
  br label %bb59
bb48:
  br label %bb49
bb49:
  %t171 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t171, ptr %l97, !tbaa !27
  %t172 = load i64, ptr %l18, !tbaa !24
  %t174 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t175 = load ptr, ptr %t174, !tbaa !27
  %t176 = getelementptr { i64, ptr }, ptr %t175, i64 %t172
  %t177 = load { i64, ptr }, ptr %t176, !tbaa !37
  store { i64, ptr } %t177, ptr %l19, !tbaa !27
  %t179 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t179, ptr %l100, !tbaa !27
  %t180 = getelementptr { i64, ptr }, ptr %l100, i32 0, i32 1
  %t181 = load ptr, ptr %t180, !tbaa !27
  %t182 = getelementptr i8, ptr %t181, i64 0
  %t183 = load i8, ptr %t182, !tbaa !32
  %t185 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t183)
  store i1 %t185, ptr %l102
  br label %bb50
bb50:
  %t186 = load i1, ptr %l102, !tbaa !21
  br i1 %t186, label %bb51, label %bb52
bb51:
  store %olang.scope zeroinitializer, ptr %s12
  %t187 = load ptr, ptr %l1, !tbaa !29
  %t189 = getelementptr %"compiler/load:Module", ptr %t187, i32 0, i32 12
  %t190 = load ptr, ptr %t189, !tbaa !29
  %t192 = icmp eq ptr %t190, null
  br i1 %t192, label %bb53, label %bb54
bb52:
  br label %bb57
bb53:
  call void @__olang_check_failed(ptr @olang_loc_b3a4ea8dfaa95483_fae7881f3523a9cf)
  unreachable
bb54:
  br label %bb55
bb55:
  %t194 = load ptr, ptr %l1, !tbaa !29
  %t196 = getelementptr %"compiler/load:Module", ptr %t194, i32 0, i32 12
  %t197 = load ptr, ptr %t196, !tbaa !29
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t200 = getelementptr %"compiler/load:Loader", ptr %t198, i32 0, i32 3
  %t201 = load ptr, ptr %t200, !tbaa !29
  %t202 = load { i64, ptr }, ptr %l19, !tbaa !27
  call void @compiler_2fparse_2ecompiler_2fparse_3aOracle_2eAdd(ptr %v1, ptr %v0, ptr %s12, ptr %v0, ptr %t197, ptr %t201, { i64, ptr } { i64 0, ptr @.d48 }, { i64, ptr } %t202)
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s12)
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s11)
  br label %bb58
bb58:
  %t206 = load i64, ptr %l18, !tbaa !24
  %t208 = add i64 %t206, 1
  store i64 %t208, ptr %l18, !tbaa !24
  br label %bb46
bb59:
  %t210 = load i64, ptr %l15, !tbaa !24
  %t211 = load i64, ptr %l17, !tbaa !24
  %t214 = add i64 %t210, %t211
  store i64 %t214, ptr %l15, !tbaa !24
  call void @__olang_scope_close(ptr %s10)
  br label %bb60
bb60:
  br label %bb39
bb61:
  %t216 = load ptr, ptr %l1, !tbaa !29
  %t218 = getelementptr %"compiler/load:Module", ptr %t216, i32 0, i32 12
  %t219 = load ptr, ptr %t218, !tbaa !29
  %t221 = icmp eq ptr %t219, null
  br i1 %t221, label %bb62, label %bb63
bb62:
  call void @__olang_check_failed(ptr @olang_loc_eb05c210d74cf102_8c07a8e6e119cf9e)
  unreachable
bb63:
  br label %bb64
bb64:
  %t223 = load ptr, ptr %l1, !tbaa !29
  %t225 = getelementptr %"compiler/load:Module", ptr %t223, i32 0, i32 12
  %t226 = load ptr, ptr %t225, !tbaa !29
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t229 = getelementptr %"compiler/load:Loader", ptr %t227, i32 0, i32 3
  %t230 = load ptr, ptr %t229, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aOracle_2eAdd(ptr %v1, ptr %v0, ptr %s0, ptr %s0, ptr %t226, ptr %t230, { i64, ptr } { i64 0, ptr @.d49 }, { i64, ptr } { i64 5, ptr @.d50 })
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fload_2ecompiler_2fload_3aLoader_2eparse(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l14 = alloca ptr
  %l19 = alloca ptr
  %l24 = alloca ptr
  %l26 = alloca ptr
  %l36 = alloca %"compiler/parse:Parser"
  %l38 = alloca ptr
  %l44 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %t71 = alloca %"compiler/parse:Parser", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/load:Loader", ptr %t1, i32 0, i32 5
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l6, !tbaa !29
  store ptr %t8, ptr %l2, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l7, !tbaa !29
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"compiler/load:Module", ptr %t10, i32 0, i32 12
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = icmp eq ptr %t13, null
  br i1 %t15, label %bb2, label %bb3
bb2:
  call void @__olang_check_failed(ptr @olang_loc_8f863f78ae5527a5_d98381c5cf71b659)
  unreachable
bb3:
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t19 = getelementptr %"compiler/load:Module", ptr %t17, i32 0, i32 12
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t21 = load i64, ptr %l1, !tbaa !24
  %t22 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2echains(ptr %v0, ptr %v0, ptr %s0, ptr %t22, ptr %t20, i64 %t21, { i64, ptr } { i64 0, ptr @.d51 }, i64 0)
  br label %bb5
bb5:
  %t25 = load ptr, ptr %l2, !tbaa !29
  store ptr %t25, ptr %l14, !tbaa !29
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t28 = getelementptr %"compiler/load:Module", ptr %t26, i32 0, i32 6
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = icmp eq ptr %t29, null
  br i1 %t31, label %bb6, label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_d1a77ba1d5054afe_d44f3bbb44d4a532)
  unreachable
bb7:
  br label %bb8
bb8:
  %t33 = load ptr, ptr %l2, !tbaa !29
  %t35 = getelementptr %"compiler/load:Module", ptr %t33, i32 0, i32 6
  %t36 = load ptr, ptr %t35, !tbaa !29
  store ptr %t36, ptr %l19, !tbaa !29
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t39 = getelementptr %"compiler/load:Module", ptr %t37, i32 0, i32 7
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = icmp eq ptr %t40, null
  br i1 %t42, label %bb9, label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_d1a77ba1d5054afe_d44f3bbb44d4a532)
  unreachable
bb10:
  br label %bb11
bb11:
  %t44 = load ptr, ptr %l2, !tbaa !29
  %t46 = getelementptr %"compiler/load:Module", ptr %t44, i32 0, i32 7
  %t47 = load ptr, ptr %t46, !tbaa !29
  store ptr %t47, ptr %l24, !tbaa !29
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/load:Loader", ptr %t48, i32 0, i32 3
  %t51 = load ptr, ptr %t50, !tbaa !29
  store ptr %t51, ptr %l26, !tbaa !29
  %t52 = load ptr, ptr %l2, !tbaa !29
  %t54 = getelementptr %"compiler/load:Module", ptr %t52, i32 0, i32 12
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = icmp eq ptr %t55, null
  br i1 %t57, label %bb12, label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_d1a77ba1d5054afe_d44f3bbb44d4a532)
  unreachable
bb13:
  br label %bb14
bb14:
  %t59 = load ptr, ptr %l2, !tbaa !29
  %t61 = getelementptr %"compiler/load:Module", ptr %t59, i32 0, i32 12
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/load:Loader", ptr %t63, i32 0, i32 4
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t67 = load ptr, ptr %l2, !tbaa !29
  %t69 = getelementptr %"compiler/load:Module", ptr %t67, i32 0, i32 4
  %t70 = load i64, ptr %t69, !tbaa !24
  %t72 = load ptr, ptr %l19, !tbaa !29
  %t73 = load ptr, ptr %l24, !tbaa !29
  %t74 = load ptr, ptr %l26, !tbaa !29
  call void @compiler_2fparse_3aParser_2ector(ptr %t71, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t72, ptr %t73, ptr %t74, ptr %t62, ptr %t66, i64 %t70)
  call void @llvm.memmove.p0.p0.i64(ptr %l36, ptr %t71, i64 272, i1 false)
  br label %bb15
bb15:
  %t78 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 272, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t78, ptr %l36, i64 272, i1 false)
  %t80 = load ptr, ptr %l14, !tbaa !29
  %t81 = getelementptr %"compiler/load:Module", ptr %t80, i32 0, i32 13
  store ptr %t78, ptr %t81, !tbaa !29
  %t82 = load ptr, ptr %l2, !tbaa !29
  store ptr %t82, ptr %l38, !tbaa !29
  %t83 = load ptr, ptr %l2, !tbaa !29
  %t85 = getelementptr %"compiler/load:Module", ptr %t83, i32 0, i32 13
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = icmp eq ptr %t86, null
  br i1 %t88, label %bb16, label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_ae9d746b68f04eaf_c5efeab384942473)
  unreachable
bb17:
  br label %bb18
bb18:
  %t90 = load ptr, ptr %l2, !tbaa !29
  %t92 = getelementptr %"compiler/load:Module", ptr %t90, i32 0, i32 13
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t95 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eFile(ptr %v0, ptr %t93)
  store { i64, ptr } %t95, ptr %l44
  br label %bb19
bb19:
  %t96 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t97 = load ptr, ptr %l38, !tbaa !29
  %t98 = getelementptr %"compiler/load:Module", ptr %t97, i32 0, i32 8
  store { i64, ptr } %t96, ptr %t98, !tbaa !27
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load i64, ptr %l1, !tbaa !24
  %t101 = load ptr, ptr %l2, !tbaa !29
  %t103 = getelementptr %"compiler/load:Module", ptr %t101, i32 0, i32 8
  %t104 = load { i64, ptr }, ptr %t103, !tbaa !27
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2egroups(ptr %v0, ptr %v0, ptr %t99, i64 %t100, { i64, ptr } %t104)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fload_2ecompiler_2fload_3aLoader_2eprescan(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l20 = alloca { i64, ptr }
  %l26 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l31 = alloca i32
  %l40 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l65 = alloca ptr
  %l66 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l70 = alloca i32
  %l79 = alloca { i64, ptr }
  %l92 = alloca ptr
  %l93 = alloca ptr
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/load:Module", ptr %t1, i32 0, i32 6
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_2753d2bb7793a0fa_e1a4644f7c04bcf6)
  unreachable
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t10 = getelementptr %"compiler/load:Module", ptr %t8, i32 0, i32 6
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t14 = getelementptr %"compiler/source:Source", ptr %t11, i32 0, i32 1
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  store { i64, ptr } %t15, ptr %l20, !tbaa !27
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/load:Module", ptr %t16, i32 0, i32 7
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = icmp eq ptr %t19, null
  br i1 %t21, label %bb4, label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_2753d2bb7793a0fa_e1a4644f7c04bcf6)
  unreachable
bb5:
  br label %bb6
bb6:
  %t23 = load ptr, ptr %l1, !tbaa !29
  %t25 = getelementptr %"compiler/load:Module", ptr %t23, i32 0, i32 7
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t27 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t29 = call ptr @compiler_2fload_2etypeNames(ptr %v1, ptr %v1, { i64, ptr } %t27, ptr %t26)
  store ptr %t29, ptr %l26
  br label %bb7
bb7:
  %t30 = load ptr, ptr %l26, !tbaa !29
  store ptr %t30, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t32 = load i64, ptr %l3, !tbaa !24
  %t35 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v1, ptr %t31, i64 %t32)
  %t36 = extractvalue { i32, { i64, ptr } } %t35, 1
  %t37 = extractvalue { i32, { i64, ptr } } %t35, 0
  store i32 %t37, ptr %l31
  %t38 = icmp ne i32 %t37, 0
  br i1 %t38, label %bb10, label %ok.39
ok.39:
  store { i64, ptr } %t36, ptr %l30
  br label %bb9
bb9:
  %t40 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t40, ptr %l27, !tbaa !27
  br label %bb14
bb10:
  %t41 = load i32, ptr %l31, !tbaa !23
  %t42 = ashr i32 %t41, 16
  %t44 = icmp eq i32 %t42, 1
  br i1 %t44, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_d655d44f6833c308_c4bdadfd628b0d84)
  unreachable
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb23
bb14:
  %t46 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t46, ptr %l4, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t47, 0
  store i64 %t49, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t51 = load i64, ptr %l6, !tbaa !24
  %t52 = load i64, ptr %l5, !tbaa !24
  %t55 = icmp slt i64 %t51, %t52
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb17:
  br label %bb18
bb18:
  %t59 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t59, ptr %l40, !tbaa !27
  %t60 = load i64, ptr %l6, !tbaa !24
  %t62 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr { i64, ptr }, ptr %t63, i64 %t60
  %t65 = load { i64, ptr }, ptr %t64, !tbaa !37
  %t67 = load ptr, ptr %l1, !tbaa !29
  %t69 = getelementptr %"compiler/load:Module", ptr %t67, i32 0, i32 9
  %t72 = extractvalue { i64, ptr } %t65, 1
  %t73 = extractvalue { i64, ptr } %t65, 0
  %t74 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t73)
  call void @olang_textcopy(ptr %t74, ptr %t72, i64 %t73)
  %t75 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t76 = insertvalue { i64, ptr } %t75, ptr %t74, 1
  %t78 = extractvalue { i64, ptr } %t76, 0
  %t79 = extractvalue { i64, ptr } %t76, 1
  %t80 = mul i64 %t78, 1
  %t81 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t80)
  call void @llvm.memcpy.p0.p0.i64(ptr %t81, ptr %t79, i64 %t80, i1 false)
  %t82 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t83 = insertvalue { i64, ptr } %t82, ptr %t81, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t69, { i64, ptr } %t83)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb20:
  %t86 = load i64, ptr %l6, !tbaa !24
  %t88 = add i64 %t86, 1
  store i64 %t88, ptr %l6, !tbaa !24
  br label %bb15
bb21:
  %t90 = load i64, ptr %l3, !tbaa !24
  %t91 = load i64, ptr %l5, !tbaa !24
  %t94 = add i64 %t90, %t91
  store i64 %t94, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb22:
  br label %bb8
bb23:
  %t96 = load ptr, ptr %l1, !tbaa !29
  %t98 = getelementptr %"compiler/load:Module", ptr %t96, i32 0, i32 6
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t101 = icmp eq ptr %t99, null
  br i1 %t101, label %bb24, label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_75be0ecbfd40364c_3ba616ba9e8cb88)
  unreachable
bb25:
  br label %bb26
bb26:
  %t103 = load ptr, ptr %l1, !tbaa !29
  %t105 = getelementptr %"compiler/load:Module", ptr %t103, i32 0, i32 6
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t109 = getelementptr %"compiler/source:Source", ptr %t106, i32 0, i32 1
  %t110 = load { i64, ptr }, ptr %t109, !tbaa !27
  store { i64, ptr } %t110, ptr %l59, !tbaa !27
  %t111 = load ptr, ptr %l1, !tbaa !29
  %t113 = getelementptr %"compiler/load:Module", ptr %t111, i32 0, i32 7
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t116 = icmp eq ptr %t114, null
  br i1 %t116, label %bb27, label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_75be0ecbfd40364c_3ba616ba9e8cb88)
  unreachable
bb28:
  br label %bb29
bb29:
  %t118 = load ptr, ptr %l1, !tbaa !29
  %t120 = getelementptr %"compiler/load:Module", ptr %t118, i32 0, i32 7
  %t121 = load ptr, ptr %t120, !tbaa !29
  %t122 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t124 = call ptr @compiler_2fparse_2eGenericFnNames(ptr %v1, ptr %v1, { i64, ptr } %t122, ptr %t121)
  store ptr %t124, ptr %l65
  br label %bb30
bb30:
  %t125 = load ptr, ptr %l65, !tbaa !29
  store ptr %t125, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb31
bb31:
  store %olang.scope zeroinitializer, ptr %s7
  %t126 = load ptr, ptr %l8, !tbaa !29
  %t127 = load i64, ptr %l9, !tbaa !24
  %t130 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v1, ptr %t126, i64 %t127)
  %t131 = extractvalue { i32, { i64, ptr } } %t130, 1
  %t132 = extractvalue { i32, { i64, ptr } } %t130, 0
  store i32 %t132, ptr %l70
  %t133 = icmp ne i32 %t132, 0
  br i1 %t133, label %bb33, label %ok.134
ok.134:
  store { i64, ptr } %t131, ptr %l69
  br label %bb32
bb32:
  %t135 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t135, ptr %l66, !tbaa !27
  br label %bb37
bb33:
  %t136 = load i32, ptr %l70, !tbaa !23
  %t137 = ashr i32 %t136, 16
  %t139 = icmp eq i32 %t137, 1
  br i1 %t139, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_898dab7725428e2_be0644f7b8b38fbe)
  unreachable
bb36:
  call void @__olang_scope_close(ptr %s7)
  br label %bb46
bb37:
  %t141 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t141, ptr %l10, !tbaa !27
  %t142 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t144 = extractvalue { i64, ptr } %t142, 0
  store i64 %t144, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb38
bb38:
  store %olang.scope zeroinitializer, ptr %s8
  %t146 = load i64, ptr %l12, !tbaa !24
  %t147 = load i64, ptr %l11, !tbaa !24
  %t150 = icmp slt i64 %t146, %t147
  %t152 = xor i1 %t150, true
  br i1 %t152, label %bb39, label %bb40
bb39:
  call void @__olang_scope_close(ptr %s8)
  br label %bb44
bb40:
  br label %bb41
bb41:
  %t154 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t154, ptr %l79, !tbaa !27
  %t155 = load i64, ptr %l12, !tbaa !24
  %t157 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !27
  %t159 = getelementptr { i64, ptr }, ptr %t158, i64 %t155
  %t160 = load { i64, ptr }, ptr %t159, !tbaa !37
  %t162 = load ptr, ptr %l1, !tbaa !29
  %t164 = getelementptr %"compiler/load:Module", ptr %t162, i32 0, i32 10
  %t167 = extractvalue { i64, ptr } %t160, 1
  %t168 = extractvalue { i64, ptr } %t160, 0
  %t169 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t168)
  call void @olang_textcopy(ptr %t169, ptr %t167, i64 %t168)
  %t170 = insertvalue { i64, ptr } undef, i64 %t168, 0
  %t171 = insertvalue { i64, ptr } %t170, ptr %t169, 1
  %t173 = extractvalue { i64, ptr } %t171, 0
  %t174 = extractvalue { i64, ptr } %t171, 1
  %t175 = mul i64 %t173, 1
  %t176 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t175)
  call void @llvm.memcpy.p0.p0.i64(ptr %t176, ptr %t174, i64 %t175, i1 false)
  %t177 = insertvalue { i64, ptr } undef, i64 %t173, 0
  %t178 = insertvalue { i64, ptr } %t177, ptr %t176, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t164, { i64, ptr } %t178)
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s8)
  br label %bb43
bb43:
  %t181 = load i64, ptr %l12, !tbaa !24
  %t183 = add i64 %t181, 1
  store i64 %t183, ptr %l12, !tbaa !24
  br label %bb38
bb44:
  %t185 = load i64, ptr %l9, !tbaa !24
  %t186 = load i64, ptr %l11, !tbaa !24
  %t189 = add i64 %t185, %t186
  store i64 %t189, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s7)
  br label %bb45
bb45:
  br label %bb31
bb46:
  store ptr %a0, ptr %l92, !tbaa !29
  %t192 = load ptr, ptr %l1, !tbaa !29
  store ptr %t192, ptr %l93, !tbaa !29
  %t193 = load ptr, ptr %l1, !tbaa !29
  %t195 = getelementptr %"compiler/load:Module", ptr %t193, i32 0, i32 7
  %t196 = load ptr, ptr %t195, !tbaa !29
  %t198 = icmp eq ptr %t196, null
  br i1 %t198, label %bb47, label %bb48
bb47:
  call void @__olang_check_failed(ptr @olang_loc_b5bc6b986ac34f36_b045281a4c31efba)
  unreachable
bb48:
  br label %bb49
bb49:
  %t200 = load ptr, ptr %l1, !tbaa !29
  %t202 = getelementptr %"compiler/load:Module", ptr %t200, i32 0, i32 7
  %t203 = load ptr, ptr %t202, !tbaa !29
  %t206 = getelementptr %"compiler/scan:Tokens", ptr %t203, i32 0, i32 0
  %t207 = load { i64, ptr }, ptr %t206, !tbaa !27
  %t209 = extractvalue { i64, ptr } %t207, 0
  %t211 = sub i64 %t209, 1
  %t212 = load ptr, ptr %l92, !tbaa !29
  %t213 = load ptr, ptr %l93, !tbaa !29
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2eregion(ptr %v0, ptr %v1, ptr %t212, ptr %t213, i64 0, i64 %t211, i64 -1)
  br label %bb50
bb50:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fload_2ecompiler_2fload_3aLoader_2eregion(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i1
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca i1
  %l23 = alloca { i64, ptr }
  %l35 = alloca i32
  %l43 = alloca i1
  %l51 = alloca i1
  %l58 = alloca i64
  %l67 = alloca i1
  %l69 = alloca i1
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/load:Module", ptr %t1, i32 0, i32 7
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_d161242c40b74370_507871439a6630a4)
  unreachable
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t10 = getelementptr %"compiler/load:Module", ptr %t8, i32 0, i32 7
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t14 = getelementptr %"compiler/scan:Tokens", ptr %t11, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  store { i64, ptr } %t15, ptr %l5, !tbaa !27
  store i64 %a2, ptr %l6, !tbaa !24
  store i1 true, ptr %l7, !tbaa !21
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t19 = load i64, ptr %l6, !tbaa !24
  %t20 = load i64, ptr %l3, !tbaa !24
  %t23 = icmp slt i64 %t19, %t20
  %t25 = xor i1 %t23, true
  br i1 %t25, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s1)
  br label %bb46
bb6:
  br label %bb7
bb7:
  %t27 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t27, ptr %l23, !tbaa !27
  %t28 = load i64, ptr %l6, !tbaa !24
  %t30 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr %"compiler/token:Token", ptr %t31, i64 %t28
  %t33 = getelementptr %"compiler/token:Token", ptr %t32, i32 0, i32 0
  %t34 = load i32, ptr %t33
  store i32 %t34, ptr %l8
  %t36 = load i32, ptr %l8
  %t38 = trunc i64 92 to i32
  %t39 = icmp eq i32 %t36, %t38
  br i1 %t39, label %bb8, label %bb9
bb8:
  %t41 = load ptr, ptr %l1, !tbaa !29
  %t43 = getelementptr %"compiler/load:Module", ptr %t41, i32 0, i32 7
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = icmp eq ptr %t44, null
  br i1 %t46, label %bb10, label %bb11
bb9:
  br label %bb17
bb10:
  call void @__olang_check_failed(ptr @olang_loc_9cda1922aec704f_35a4007cf0fda73)
  unreachable
bb11:
  br label %bb12
bb12:
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t50 = getelementptr %"compiler/load:Module", ptr %t48, i32 0, i32 7
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t52 = load i64, ptr %l6, !tbaa !24
  %t54 = trunc i64 %t52 to i32
  %t57 = call i32 @compiler_2fscan_2ecompiler_2fscan_3aTokens_2eMatch(ptr %v1, ptr %t51, i32 %t54)
  store i32 %t57, ptr %l35
  br label %bb13
bb13:
  %t58 = load i32, ptr %l35, !tbaa !23
  %t59 = sext i32 %t58 to i64
  store i64 %t59, ptr %l9, !tbaa !24
  %t61 = load i64, ptr %l9, !tbaa !24
  %t63 = icmp slt i64 %t61, 0
  br i1 %t63, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb15:
  br label %bb16
bb16:
  %t65 = load i64, ptr %l9, !tbaa !24
  %t67 = add i64 %t65, 1
  store i64 %t67, ptr %l6, !tbaa !24
  store i1 true, ptr %l7, !tbaa !21
  call void @__olang_scope_close(ptr %s1)
  br label %bb45
bb17:
  %t69 = load i32, ptr %l8
  %t71 = trunc i64 8 to i32
  %t72 = icmp eq i32 %t69, %t71
  br i1 %t72, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb20
bb19:
  %t74 = load i32, ptr %l8
  %t76 = trunc i64 93 to i32
  %t77 = icmp eq i32 %t74, %t76
  store i1 %t77, ptr %l43, !tbaa !21
  br label %bb20
bb20:
  %t79 = load i1, ptr %l43, !tbaa !21
  br i1 %t79, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l7, !tbaa !21
  %t80 = load i64, ptr %l6, !tbaa !24
  %t82 = add i64 %t80, 1
  store i64 %t82, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb45
bb22:
  br label %bb23
bb23:
  %t84 = load i1, ptr %l7, !tbaa !21
  store i1 %t84, ptr %l10, !tbaa !21
  store i1 false, ptr %l7, !tbaa !21
  %t86 = load i32, ptr %l8
  %t88 = trunc i64 9 to i32
  %t89 = icmp eq i32 %t86, %t88
  br i1 %t89, label %bb24, label %bb25
bb24:
  %t91 = load i1, ptr %l10, !tbaa !21
  store i1 %t91, ptr %l51, !tbaa !21
  br label %bb26
bb25:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb26
bb26:
  %t93 = load i1, ptr %l51, !tbaa !21
  br i1 %t93, label %bb27, label %bb28
bb27:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load ptr, ptr %l1, !tbaa !29
  %t96 = load i64, ptr %l6, !tbaa !24
  %t97 = load i64, ptr %l3, !tbaa !24
  %t98 = load i64, ptr %l4, !tbaa !24
  %t104 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2etopIf(ptr %v0, ptr %v1, ptr %t94, ptr %t95, i64 %t96, i64 %t97, i64 %t98)
  store i64 %t104, ptr %l58
  br label %bb29
bb28:
  br label %bb30
bb29:
  %t105 = load i64, ptr %l58, !tbaa !24
  store i64 %t105, ptr %l6, !tbaa !24
  store i1 true, ptr %l7, !tbaa !21
  call void @__olang_scope_close(ptr %s1)
  br label %bb45
bb30:
  %t106 = load i32, ptr %l8
  %t108 = trunc i64 40 to i32
  %t109 = icmp eq i32 %t106, %t108
  br i1 %t109, label %bb31, label %bb32
bb31:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = load ptr, ptr %l1, !tbaa !29
  %t113 = load i64, ptr %l6, !tbaa !24
  %t114 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2eimportAt(ptr %v0, ptr %v1, ptr %t111, ptr %t112, i64 %t113, i64 %t114)
  br label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb34
bb34:
  %t119 = load i32, ptr %l8
  %t121 = trunc i64 1 to i32
  %t122 = icmp eq i32 %t119, %t121
  br i1 %t122, label %bb35, label %bb36
bb35:
  %t124 = load i1, ptr %l10, !tbaa !21
  store i1 %t124, ptr %l67, !tbaa !21
  br label %bb37
bb36:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb37
bb37:
  %t126 = load i1, ptr %l67, !tbaa !21
  br i1 %t126, label %bb38, label %bb39
bb38:
  %t127 = load i64, ptr %l4, !tbaa !24
  %t129 = icmp slt i64 %t127, 0
  store i1 %t129, ptr %l69, !tbaa !21
  br label %bb40
bb39:
  store i1 false, ptr %l69, !tbaa !21
  br label %bb40
bb40:
  %t131 = load i1, ptr %l69, !tbaa !21
  br i1 %t131, label %bb41, label %bb42
bb41:
  %t132 = load ptr, ptr %l1, !tbaa !29
  %t134 = getelementptr %"compiler/load:Module", ptr %t132, i32 0, i32 22
  %t135 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t134, i64 %t135)
  br label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb44
bb44:
  %t138 = load i64, ptr %l6, !tbaa !24
  %t140 = add i64 %t138, 1
  store i64 %t140, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb45
bb45:
  br label %bb4
bb46:
  br label %ret
ret:
  ret void
}

define dso_local { i32, { { i64, ptr }, { i64, ptr } } } @compiler_2fload_2ecompiler_2fload_3aLoader_2eresolve(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, %"compiler/load:Import" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/load:Import"
  %l3 = alloca ptr
  %l4 = alloca { i64, [3 x i64] }
  %l5 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %lp8 = alloca ptr
  %lp9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca %"std/prelude/text:StringBuilder"
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca i1
  %l27 = alloca ptr
  %l31 = alloca { i64, [3 x i64] }
  %l37 = alloca ptr
  %l38 = alloca { i64, [3 x i64] }
  %l39 = alloca %"compiler/msgs:Msg"
  %l40 = alloca i64
  %l43 = alloca i1
  %l45 = alloca ptr
  %l46 = alloca { i64, [3 x i64] }
  %l47 = alloca %"compiler/msgs:Msg"
  %l48 = alloca i64
  %l50 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i32
  %l57 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca i64
  %l64 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l66 = alloca i64
  %l67 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l70 = alloca i64
  %l71 = alloca { i64, ptr }
  %l73 = alloca i1
  %l75 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l79 = alloca i64
  %l80 = alloca i64
  %l87 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %l90 = alloca i64
  %l93 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l96 = alloca i64
  %l99 = alloca i1
  %l102 = alloca ptr
  %l103 = alloca { i64, [3 x i64] }
  %l104 = alloca %"compiler/msgs:Msg"
  %l105 = alloca i64
  %l109 = alloca { i64, ptr }
  %l110 = alloca i1
  %l111 = alloca i1
  %l113 = alloca i1
  %l115 = alloca i1
  %l117 = alloca i1
  %l120 = alloca { i64, ptr }
  %l125 = alloca ptr
  %l126 = alloca { i64, [3 x i64] }
  %l127 = alloca %"compiler/msgs:Msg"
  %l128 = alloca i64
  %l130 = alloca { i64, ptr }
  %l133 = alloca { i64, ptr }
  %l135 = alloca { i64, ptr }
  %l137 = alloca { i64, ptr }
  %l139 = alloca { i64, ptr }
  %l140 = alloca i32
  %l147 = alloca ptr
  %l148 = alloca { i64, [3 x i64] }
  %l149 = alloca %"compiler/msgs:Msg"
  %l150 = alloca i64
  %l151 = alloca { i64, ptr }
  %l154 = alloca ptr
  %l155 = alloca { i64, [3 x i64] }
  %l157 = alloca { i64, ptr }
  %l159 = alloca %"compiler/msgs:Msg"
  %l160 = alloca i64
  %l161 = alloca { i64, ptr }
  %l164 = alloca ptr
  %l165 = alloca { i64, [3 x i64] }
  %l167 = alloca { i64, ptr }
  %l169 = alloca %"compiler/msgs:Msg"
  %l170 = alloca i64
  %l171 = alloca { i64, ptr }
  %l174 = alloca ptr
  %l175 = alloca { i64, [3 x i64] }
  %l177 = alloca { i64, ptr }
  %l179 = alloca %"compiler/msgs:Msg"
  %l180 = alloca i64
  %l181 = alloca { i64, ptr }
  %l184 = alloca i1
  %l186 = alloca %"std/prelude/text:StringBuilder"
  %l194 = alloca i64
  %l197 = alloca i64
  %l217 = alloca { i64, ptr }
  %l224 = alloca { i64, ptr }
  %l225 = alloca { i64, ptr }
  %l226 = alloca { i64, ptr }
  %l228 = alloca i64
  %l231 = alloca { i64, ptr }
  %l232 = alloca { i64, ptr }
  %l234 = alloca i64
  %l237 = alloca { i64, ptr }
  %l242 = alloca i1
  %l245 = alloca ptr
  %l246 = alloca { i64, [3 x i64] }
  %l248 = alloca %"compiler/msgs:Msg"
  %l249 = alloca i64
  %l253 = alloca { i64, ptr }
  %l255 = alloca i1
  %l256 = alloca i1
  %l258 = alloca i1
  %l262 = alloca { i64, ptr }
  %l263 = alloca { i64, ptr }
  %l265 = alloca i64
  %l271 = alloca { i64, ptr }
  %l272 = alloca { i64, ptr }
  %l274 = alloca i64
  %l277 = alloca i1
  %l278 = alloca { i64, ptr }
  %l280 = alloca { i64, ptr }
  %l285 = alloca { i64, ptr }
  %l288 = alloca i64
  %l290 = alloca { i64, ptr }
  %l291 = alloca { i64, ptr }
  %l292 = alloca i64
  %l293 = alloca { i64, ptr }
  %l295 = alloca { i64, ptr }
  %l296 = alloca i64
  %l300 = alloca i64
  %l301 = alloca i32
  %l305 = alloca i64
  %l312 = alloca { i64, ptr }
  %l313 = alloca i1
  %l314 = alloca i1
  %l316 = alloca i1
  %l318 = alloca i1
  %l320 = alloca i1
  %l324 = alloca i1
  %l325 = alloca { i64, ptr }
  %l326 = alloca { i64, ptr }
  %l328 = alloca i64
  %l330 = alloca i64
  %l331 = alloca { i64, ptr }
  %l333 = alloca i1
  %l337 = alloca { i64, ptr }
  %l338 = alloca i1
  %l341 = alloca { i64, ptr }
  %l342 = alloca { i64, ptr }
  %l344 = alloca i64
  %l347 = alloca i1
  %l349 = alloca i1
  %l354 = alloca i1
  %l357 = alloca ptr
  %l358 = alloca { i64, [3 x i64] }
  %l360 = alloca %"compiler/msgs:Msg"
  %l361 = alloca i64
  %l364 = alloca i1
  %l366 = alloca i1
  %l368 = alloca i1
  %l370 = alloca ptr
  %l371 = alloca { i64, [3 x i64] }
  %l373 = alloca %"compiler/msgs:Msg"
  %l374 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s37 = alloca %olang.scope
  %s38 = alloca %olang.scope
  %rv = alloca { i32, { { i64, ptr }, { i64, ptr } } }
  store ptr %a0, ptr %l0
  store %"compiler/load:Import" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/load:Loader", ptr %t1, i32 0, i32 5
  %t7 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l27
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l27, !tbaa !29
  store ptr %t8, ptr %l3, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t11 = getelementptr %"compiler/load:Import", ptr %l2, i32 0, i32 0
  %t12 = load %"compiler/source:Span", ptr %t11
  %t16 = call { i64, [3 x i64] } @compiler_2fload_2ecompiler_2fload_3aLoader_2eat(ptr %v0, ptr %v0, ptr %t9, ptr %t10, %"compiler/source:Span" %t12)
  store { i64, [3 x i64] } %t16, ptr %l31
  br label %bb2
bb2:
  %t17 = load { i64, [3 x i64] }, ptr %l31
  store { i64, [3 x i64] } %t17, ptr %l4
  %t18 = getelementptr %"compiler/load:Import", ptr %l2, i32 0, i32 3
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !27
  store { i64, ptr } %t19, ptr %l5, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t25 = icmp sge i64 %t23, 4096
  br i1 %t25, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/load:Loader", ptr %t27, i32 0, i32 4
  %t30 = load ptr, ptr %t29, !tbaa !29
  store ptr %t30, ptr %l37, !tbaa !29
  %t31 = load { i64, [3 x i64] }, ptr %l4
  store { i64, [3 x i64] } %t31, ptr %l38
  %t32 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportPathTooLong(ptr %s1)
  store %"compiler/msgs:Msg" %t32, ptr %l39
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t33 = load ptr, ptr %l37, !tbaa !29
  %t34 = load { i64, [3 x i64] }, ptr %l38
  %t35 = load %"compiler/msgs:Msg", ptr %l39
  %t36 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s1, ptr %t33, { i64, [3 x i64] } %t34, %"compiler/msgs:Msg" %t35)
  store i64 %t36, ptr %l40
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t38 = insertvalue { i32, { { i64, ptr }, { i64, ptr } } } zeroinitializer, i32 65536, 0
  store { i32, { { i64, ptr }, { i64, ptr } } } %t38, ptr %rv
  br label %ret
bb7:
  %t39 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t41 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v1, ptr %s0, { i64, ptr } %t39, { i64, ptr } { i64 6, ptr @.d52 })
  store i1 %t41, ptr %l43
  br label %bb8
bb8:
  %t42 = load i1, ptr %l43, !tbaa !21
  br i1 %t42, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/load:Loader", ptr %t43, i32 0, i32 4
  %t46 = load ptr, ptr %t45, !tbaa !29
  store ptr %t46, ptr %l45, !tbaa !29
  %t47 = load { i64, [3 x i64] }, ptr %l4
  store { i64, [3 x i64] } %t47, ptr %l46
  %t48 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportHasExtension(ptr %s2)
  store %"compiler/msgs:Msg" %t48, ptr %l47
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t49 = load ptr, ptr %l45, !tbaa !29
  %t50 = load { i64, [3 x i64] }, ptr %l46
  %t51 = load %"compiler/msgs:Msg", ptr %l47
  %t52 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s2, ptr %t49, { i64, [3 x i64] } %t50, %"compiler/msgs:Msg" %t51)
  store i64 %t52, ptr %l48
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t54 = insertvalue { i32, { { i64, ptr }, { i64, ptr } } } zeroinitializer, i32 65536, 0
  store { i32, { { i64, ptr }, { i64, ptr } } } %t54, ptr %rv
  br label %ret
bb13:
  %t55 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t58 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v1, { i64, ptr } %t55, i8 47)
  %t59 = extractvalue { i32, i64 } %t58, 1
  %t60 = extractvalue { i32, i64 } %t58, 0
  store i32 %t60, ptr %l54
  %t61 = icmp ne i32 %t60, 0
  br i1 %t61, label %bb15, label %ok.62
ok.62:
  store i64 %t59, ptr %l53
  br label %bb14
bb14:
  %t63 = load i64, ptr %l53, !tbaa !24
  store i64 %t63, ptr %l50, !tbaa !24
  br label %bb17
bb15:
  br label %bb16
bb16:
  %t64 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t64, 0
  store i64 %t66, ptr %l50, !tbaa !24
  br label %bb17
bb17:
  %t68 = load i64, ptr %l50, !tbaa !24
  %t69 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t69, ptr %l57, !tbaa !27
  store i64 %t68, ptr %l58, !tbaa !24
  %t71 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t71, 0
  store i64 %t72, ptr %l59, !tbaa !24
  %t73 = icmp sge i64 0, 0
  br i1 %t73, label %bb18, label %bb19
bb18:
  %t75 = load i64, ptr %l58, !tbaa !24
  %t76 = icmp sle i64 0, %t75
  br i1 %t76, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_6772f502359d02a_1b697b2141371efe)
  unreachable
bb20:
  %t78 = load i64, ptr %l58, !tbaa !24
  %t79 = load i64, ptr %l59, !tbaa !24
  %t80 = icmp sle i64 %t78, %t79
  br i1 %t80, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_6772f502359d02a_1b697b2141371efe)
  unreachable
bb22:
  %t82 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = load i64, ptr %l58, !tbaa !24
  %t85 = getelementptr i8, ptr %t83, i64 0
  %t86 = sub i64 %t84, 0
  %t87 = insertvalue { i64, ptr } undef, i64 %t86, 0
  %t88 = insertvalue { i64, ptr } %t87, ptr %t85, 1
  store { i64, ptr } %t88, ptr %l7, !tbaa !27
  store { i64, ptr } { i64 0, ptr @.d53 }, ptr %l64, !tbaa !27
  %t90 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t90, ptr %l65, !tbaa !27
  %t91 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t91, 0
  store i64 %t92, ptr %l66, !tbaa !24
  %t93 = load i64, ptr %l66, !tbaa !24
  %t94 = mul i64 %t93, 1
  %t95 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t94)
  %t96 = insertvalue { i64, ptr } undef, i64 %t93, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t95, 1
  store { i64, ptr } %t97, ptr %l67, !tbaa !27
  %t98 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = load i64, ptr %l66, !tbaa !24
  %t103 = mul i64 %t102, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t99, ptr %t101, i64 %t103, i1 false)
  %t104 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t104, ptr %lp8
  %t105 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t106 = load ptr, ptr %lp8
  store { i64, ptr } %t105, ptr %t106, !tbaa !27
  store { i64, ptr } { i64 0, ptr @.d54 }, ptr %l68, !tbaa !27
  %t107 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t107, ptr %l69, !tbaa !27
  %t108 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t108, 0
  store i64 %t109, ptr %l70, !tbaa !24
  %t110 = load i64, ptr %l70, !tbaa !24
  %t111 = mul i64 %t110, 1
  %t112 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t111)
  %t113 = insertvalue { i64, ptr } undef, i64 %t110, 0
  %t114 = insertvalue { i64, ptr } %t113, ptr %t112, 1
  store { i64, ptr } %t114, ptr %l71, !tbaa !27
  %t115 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !27
  %t119 = load i64, ptr %l70, !tbaa !24
  %t120 = mul i64 %t119, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t116, ptr %t118, i64 %t120, i1 false)
  %t121 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t121, ptr %lp9
  %t122 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t123 = load ptr, ptr %lp9
  store { i64, ptr } %t122, ptr %t123, !tbaa !27
  %t124 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t126 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s0, { i64, ptr } %t124, { i64, ptr } { i64 4, ptr @.d55 })
  store i1 %t126, ptr %l73
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_6772f502359d02a_1b697b2141371efe)
  unreachable
bb24:
  %t127 = load i1, ptr %l73, !tbaa !21
  br i1 %t127, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s3
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/load:Loader", ptr %t128, i32 0, i32 0
  %t131 = load { i64, ptr }, ptr %t130, !tbaa !27
  store { i64, ptr } %t131, ptr %l75, !tbaa !27
  %t132 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t132, ptr %l76, !tbaa !27
  %t133 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t133, 0
  store i64 %t136, ptr %l79, !tbaa !24
  %t137 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t137, 0
  store i64 %t138, ptr %l80, !tbaa !24
  %t139 = icmp sge i64 4, 0
  br i1 %t139, label %bb27, label %bb28
bb26:
  store %olang.scope zeroinitializer, ptr %s8
  %t141 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } { i64 1, ptr @.d56 }, ptr %l109, !tbaa !27
  %t144 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t145 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s8, { i64, ptr } %t141, { i64, ptr } %t144)
  store i1 %t145, ptr %l110
  br label %bb47
bb27:
  %t146 = load i64, ptr %l79, !tbaa !24
  %t147 = icmp sle i64 4, %t146
  br i1 %t147, label %bb29, label %bb30
bb28:
  call void @__olang_check_failed(ptr @olang_loc_c7e55e824de13607_c088d15fef4da17b)
  unreachable
bb29:
  %t149 = load i64, ptr %l79, !tbaa !24
  %t150 = load i64, ptr %l80, !tbaa !24
  %t151 = icmp sle i64 %t149, %t150
  br i1 %t151, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_c7e55e824de13607_c088d15fef4da17b)
  unreachable
bb31:
  %t153 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !27
  %t155 = load i64, ptr %l79, !tbaa !24
  %t156 = getelementptr i8, ptr %t154, i64 4
  %t157 = sub i64 %t155, 4
  %t158 = insertvalue { i64, ptr } undef, i64 %t157, 0
  %t159 = insertvalue { i64, ptr } %t158, ptr %t156, 1
  %t160 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t161 = extractvalue { i64, ptr } %t160, 1
  %t162 = extractvalue { i64, ptr } %t160, 0
  %t163 = extractvalue { i64, ptr } { i64 1, ptr @.d57 }, 1
  %t164 = extractvalue { i64, ptr } { i64 1, ptr @.d57 }, 0
  %t165 = add i64 %t162, %t164
  %t167 = extractvalue { i64, ptr } %t159, 1
  %t168 = extractvalue { i64, ptr } %t159, 0
  %t169 = add i64 %t165, %t168
  %t170 = extractvalue { i64, ptr } { i64 6, ptr @.d58 }, 1
  %t171 = extractvalue { i64, ptr } { i64 6, ptr @.d58 }, 0
  %t172 = add i64 %t169, %t171
  %t173 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t172)
  call void @olang_textcopy(ptr %t173, ptr %t161, i64 %t162)
  %t174 = getelementptr i8, ptr %t173, i64 %t162
  call void @olang_textcopy(ptr %t174, ptr %t163, i64 %t164)
  %t175 = getelementptr i8, ptr %t174, i64 %t164
  call void @olang_textcopy(ptr %t175, ptr %t167, i64 %t168)
  %t176 = getelementptr i8, ptr %t175, i64 %t168
  call void @olang_textcopy(ptr %t176, ptr %t170, i64 %t171)
  %t177 = insertvalue { i64, ptr } undef, i64 %t172, 0
  %t178 = insertvalue { i64, ptr } %t177, ptr %t173, 1
  %t180 = extractvalue { i64, ptr } %t178, 0
  %t181 = extractvalue { i64, ptr } %t178, 1
  %t182 = mul i64 %t180, 1
  %t183 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t182)
  call void @llvm.memcpy.p0.p0.i64(ptr %t183, ptr %t181, i64 %t182, i1 false)
  %t184 = insertvalue { i64, ptr } undef, i64 %t180, 0
  %t185 = insertvalue { i64, ptr } %t184, ptr %t183, 1
  %t187 = call { i64, ptr } @compiler_2fload_2eNormalize(ptr %s3, ptr %s3, { i64, ptr } %t185)
  store { i64, ptr } %t187, ptr %l87
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_c7e55e824de13607_c088d15fef4da17b)
  unreachable
bb33:
  %t188 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t189 = extractvalue { i64, ptr } %t188, 1
  %t190 = extractvalue { i64, ptr } %t188, 0
  %t191 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t190)
  call void @olang_textcopy(ptr %t191, ptr %t189, i64 %t190)
  %t192 = insertvalue { i64, ptr } undef, i64 %t190, 0
  %t193 = insertvalue { i64, ptr } %t192, ptr %t191, 1
  store { i64, ptr } %t193, ptr %l88, !tbaa !27
  %t194 = load ptr, ptr %lp8
  %t195 = load { i64, ptr }, ptr %t194, !tbaa !27
  %t196 = extractvalue { i64, ptr } %t195, 0
  %t197 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t198 = extractvalue { i64, ptr } %t197, 0
  store i64 %t198, ptr %l90, !tbaa !24
  %t200 = load i64, ptr %l90, !tbaa !24
  %t201 = icmp eq i64 %t196, %t200
  br i1 %t201, label %bb34, label %bb35
bb34:
  %t203 = load ptr, ptr %lp8
  %t204 = getelementptr { i64, ptr }, ptr %t203, i32 0, i32 1
  %t205 = load ptr, ptr %t204, !tbaa !27
  %t206 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t207 = load ptr, ptr %t206, !tbaa !27
  %t208 = load i64, ptr %l90, !tbaa !24
  %t209 = mul i64 %t208, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t205, ptr %t207, i64 %t209, i1 false)
  br label %bb36
bb35:
  %t210 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t211 = load ptr, ptr %lp8
  store { i64, ptr } %t210, ptr %t211, !tbaa !27
  br label %bb36
bb36:
  %t212 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t214 = call { i64, ptr } @compiler_2fload_2eNormalize(ptr %v1, ptr %s3, { i64, ptr } %t212)
  store { i64, ptr } %t214, ptr %l93
  br label %bb37
bb37:
  %t215 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t216 = extractvalue { i64, ptr } %t215, 1
  %t217 = extractvalue { i64, ptr } %t215, 0
  %t218 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t217)
  call void @olang_textcopy(ptr %t218, ptr %t216, i64 %t217)
  %t219 = insertvalue { i64, ptr } undef, i64 %t217, 0
  %t220 = insertvalue { i64, ptr } %t219, ptr %t218, 1
  store { i64, ptr } %t220, ptr %l94, !tbaa !27
  %t221 = load ptr, ptr %lp9
  %t222 = load { i64, ptr }, ptr %t221, !tbaa !27
  %t223 = extractvalue { i64, ptr } %t222, 0
  %t224 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t225 = extractvalue { i64, ptr } %t224, 0
  store i64 %t225, ptr %l96, !tbaa !24
  %t227 = load i64, ptr %l96, !tbaa !24
  %t228 = icmp eq i64 %t223, %t227
  br i1 %t228, label %bb38, label %bb39
bb38:
  %t230 = load ptr, ptr %lp9
  %t231 = getelementptr { i64, ptr }, ptr %t230, i32 0, i32 1
  %t232 = load ptr, ptr %t231, !tbaa !27
  %t233 = getelementptr { i64, ptr }, ptr %l94, i32 0, i32 1
  %t234 = load ptr, ptr %t233, !tbaa !27
  %t235 = load i64, ptr %l96, !tbaa !24
  %t236 = mul i64 %t235, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t232, ptr %t234, i64 %t236, i1 false)
  br label %bb40
bb39:
  %t237 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t238 = load ptr, ptr %lp9
  store { i64, ptr } %t237, ptr %t238, !tbaa !27
  br label %bb40
bb40:
  %t239 = load ptr, ptr %lp9
  %t240 = load { i64, ptr }, ptr %t239, !tbaa !27
  %t242 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v2, ptr %s3, { i64, ptr } %t240, { i64, ptr } { i64 4, ptr @.d59 })
  store i1 %t242, ptr %l99
  br label %bb41
bb41:
  %t243 = load i1, ptr %l99, !tbaa !21
  %t244 = xor i1 %t243, true
  br i1 %t244, label %bb42, label %bb43
bb42:
  store %olang.scope zeroinitializer, ptr %s7
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t248 = getelementptr %"compiler/load:Loader", ptr %t246, i32 0, i32 4
  %t249 = load ptr, ptr %t248, !tbaa !29
  store ptr %t249, ptr %l102, !tbaa !29
  %t250 = load { i64, [3 x i64] }, ptr %l4
  store { i64, [3 x i64] } %t250, ptr %l103
  %t251 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportLeavesRoot(ptr %s7, ptr %s7, { i64, ptr } { i64 3, ptr @.d60 })
  store %"compiler/msgs:Msg" %t251, ptr %l104
  br label %bb44
bb43:
  br label %bb46
bb44:
  %t252 = load ptr, ptr %l102, !tbaa !29
  %t253 = load { i64, [3 x i64] }, ptr %l103
  %t254 = load %"compiler/msgs:Msg", ptr %l104
  %t255 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s7, ptr %t252, { i64, [3 x i64] } %t253, %"compiler/msgs:Msg" %t254)
  store i64 %t255, ptr %l105
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t257 = insertvalue { i32, { { i64, ptr }, { i64, ptr } } } zeroinitializer, i32 65536, 0
  store { i32, { { i64, ptr }, { i64, ptr } } } %t257, ptr %rv
  br label %ret
bb46:
  call void @__olang_scope_close(ptr %s3)
  br label %bb201
bb47:
  %t258 = load i1, ptr %l110, !tbaa !21
  br i1 %t258, label %bb48, label %bb49
bb48:
  %t259 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t261 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s8, { i64, ptr } %t259, { i64, ptr } { i64 1, ptr @.d61 })
  store i1 %t261, ptr %l113
  br label %bb50
bb49:
  store i1 false, ptr %l111, !tbaa !21
  br label %bb51
bb50:
  %t262 = load i1, ptr %l113, !tbaa !21
  %t263 = xor i1 %t262, true
  store i1 %t263, ptr %l111, !tbaa !21
  br label %bb51
bb51:
  %t265 = load i1, ptr %l111, !tbaa !21
  br i1 %t265, label %bb52, label %bb53
bb52:
  %t266 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t268 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s8, { i64, ptr } %t266, { i64, ptr } { i64 2, ptr @.d62 })
  store i1 %t268, ptr %l117
  br label %bb54
bb53:
  store i1 false, ptr %l115, !tbaa !21
  br label %bb55
bb54:
  %t269 = load i1, ptr %l117, !tbaa !21
  %t270 = xor i1 %t269, true
  store i1 %t270, ptr %l115, !tbaa !21
  br label %bb55
bb55:
  %t272 = load i1, ptr %l115, !tbaa !21
  br i1 %t272, label %bb56, label %bb57
bb56:
  store %olang.scope zeroinitializer, ptr %s9
  %t273 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t275 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v1, ptr %s9, { i64, ptr } %t273, { i64, ptr } { i64 1, ptr @.d63 })
  store { i64, ptr } %t275, ptr %l120
  br label %bb58
bb57:
  store %olang.scope zeroinitializer, ptr %s23
  %t276 = load ptr, ptr %l3, !tbaa !29
  %t278 = getelementptr %"compiler/load:Module", ptr %t276, i32 0, i32 0
  %t279 = load { i64, ptr }, ptr %t278, !tbaa !27
  %t281 = call { i64, ptr } @compiler_2fload_2emoduleDir(ptr %v0, ptr %s23, { i64, ptr } %t279)
  store { i64, ptr } %t281, ptr %l253
  br label %bb127
bb58:
  %t282 = load { i64, ptr }, ptr %l120, !tbaa !27
  store { i64, ptr } %t282, ptr %l10, !tbaa !27
  %t283 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t285 = extractvalue { i64, ptr } %t283, 0
  %t287 = icmp slt i64 %t285, 4
  br i1 %t287, label %bb59, label %bb60
bb59:
  store %olang.scope zeroinitializer, ptr %s10
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t291 = getelementptr %"compiler/load:Loader", ptr %t289, i32 0, i32 4
  %t292 = load ptr, ptr %t291, !tbaa !29
  store ptr %t292, ptr %l125, !tbaa !29
  %t293 = load { i64, [3 x i64] }, ptr %l4
  store { i64, [3 x i64] } %t293, ptr %l126
  %t294 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportRemoteNeedsFile(ptr %s10)
  store %"compiler/msgs:Msg" %t294, ptr %l127
  br label %bb61
bb60:
  br label %bb63
bb61:
  %t295 = load ptr, ptr %l125, !tbaa !29
  %t296 = load { i64, [3 x i64] }, ptr %l126
  %t297 = load %"compiler/msgs:Msg", ptr %l127
  %t298 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s10, ptr %t295, { i64, [3 x i64] } %t296, %"compiler/msgs:Msg" %t297)
  store i64 %t298, ptr %l128
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t300 = insertvalue { i32, { { i64, ptr }, { i64, ptr } } } zeroinitializer, i32 65536, 0
  store { i32, { { i64, ptr }, { i64, ptr } } } %t300, ptr %rv
  br label %ret
bb63:
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t303 = getelementptr %"compiler/load:Loader", ptr %t301, i32 0, i32 2
  %t304 = load ptr, ptr %t303, !tbaa !29
  %t305 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t305, ptr %l133, !tbaa !27
  %t306 = getelementptr { i64, ptr }, ptr %l133, i32 0, i32 1
  %t307 = load ptr, ptr %t306, !tbaa !27
  %t308 = getelementptr { i64, ptr }, ptr %t307, i64 0
  %t309 = load { i64, ptr }, ptr %t308, !tbaa !37
  %t310 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t310, ptr %l135, !tbaa !27
  %t311 = getelementptr { i64, ptr }, ptr %l135, i32 0, i32 1
  %t312 = load ptr, ptr %t311, !tbaa !27
  %t313 = getelementptr { i64, ptr }, ptr %t312, i64 1
  %t314 = load { i64, ptr }, ptr %t313, !tbaa !37
  %t315 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t315, ptr %l137, !tbaa !27
  %t316 = getelementptr { i64, ptr }, ptr %l137, i32 0, i32 1
  %t317 = load ptr, ptr %t316, !tbaa !27
  %t318 = getelementptr { i64, ptr }, ptr %t317, i64 2
  %t319 = load { i64, ptr }, ptr %t318, !tbaa !37
  %t324 = call { i32, { i64, ptr } } @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2eFetch(ptr %v0, ptr %v1, ptr %v1, ptr %v1, ptr %s9, ptr %t304, { i64, ptr } %t309, { i64, ptr } %t314, { i64, ptr } %t319)
  %t325 = extractvalue { i32, { i64, ptr } } %t324, 1
  %t326 = extractvalue { i32, { i64, ptr } } %t324, 0
  store i32 %t326, ptr %l140
  %t327 = icmp ne i32 %t326, 0
  br i1 %t327, label %bb65, label %ok.328
ok.328:
  store { i64, ptr } %t325, ptr %l139
  br label %bb64
bb64:
  %t329 = load { i64, ptr }, ptr %l139, !tbaa !27
  store { i64, ptr } %t329, ptr %l130, !tbaa !27
  br label %bb89
bb65:
  %t330 = load i32, ptr %l140, !tbaa !23
  %t331 = icmp eq i32 %t330, 65536
  br i1 %t331, label %bb66, label %bb67
bb66:
  br label %bb68
bb67:
  %t333 = load i32, ptr %l140, !tbaa !23
  %t334 = icmp eq i32 %t333, 65537
  br i1 %t334, label %bb69, label %bb70
bb68:
  store %olang.scope zeroinitializer, ptr %s11
  %t336 = load ptr, ptr %l0, !tbaa !29
  %t338 = getelementptr %"compiler/load:Loader", ptr %t336, i32 0, i32 4
  %t339 = load ptr, ptr %t338, !tbaa !29
  store ptr %t339, ptr %l147, !tbaa !29
  %t340 = load { i64, [3 x i64] }, ptr %l4
  store { i64, [3 x i64] } %t340, ptr %l148
  %t341 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportRemoteBadName(ptr %s11)
  store %"compiler/msgs:Msg" %t341, ptr %l149
  br label %bb78
bb69:
  br label %bb71
bb70:
  %t342 = load i32, ptr %l140, !tbaa !23
  %t343 = icmp eq i32 %t342, 65538
  br i1 %t343, label %bb72, label %bb73
bb71:
  store %olang.scope zeroinitializer, ptr %s12
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t347 = getelementptr %"compiler/load:Loader", ptr %t345, i32 0, i32 4
  %t348 = load ptr, ptr %t347, !tbaa !29
  store ptr %t348, ptr %l154, !tbaa !29
  %t349 = load { i64, [3 x i64] }, ptr %l4
  store { i64, [3 x i64] } %t349, ptr %l155
  %t350 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t352 = call { i64, ptr } @compiler_2fload_2ekey(ptr %v1, ptr %s12, { i64, ptr } %t350)
  store { i64, ptr } %t352, ptr %l157
  br label %bb80
bb72:
  br label %bb74
bb73:
  %t353 = load i32, ptr %l140, !tbaa !23
  %t354 = icmp eq i32 %t353, 65539
  br i1 %t354, label %bb75, label %bb76
bb74:
  store %olang.scope zeroinitializer, ptr %s13
  %t356 = load ptr, ptr %l0, !tbaa !29
  %t358 = getelementptr %"compiler/load:Loader", ptr %t356, i32 0, i32 4
  %t359 = load ptr, ptr %t358, !tbaa !29
  store ptr %t359, ptr %l164, !tbaa !29
  %t360 = load { i64, [3 x i64] }, ptr %l4
  store { i64, [3 x i64] } %t360, ptr %l165
  %t361 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t363 = call { i64, ptr } @compiler_2fload_2ekey(ptr %v1, ptr %s13, { i64, ptr } %t361)
  store { i64, ptr } %t363, ptr %l167
  br label %bb83
bb75:
  br label %bb77
bb76:
  %t364 = load i32, ptr %l140, !tbaa !23
  %t365 = lshr i32 %t364, 16
  %t366 = and i32 %t364, 65535
  %t367 = icmp eq i32 %t365, 1
  %t368 = select i1 %t367, i32 0, i32 0
  %t369 = icmp eq i32 %t364, 0
  %t370 = shl i32 %t368, 16
  %t371 = or i32 %t370, %t366
  %t372 = select i1 %t369, i32 0, i32 %t371
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t374 = insertvalue { i32, { { i64, ptr }, { i64, ptr } } } zeroinitializer, i32 %t372, 0
  store { i32, { { i64, ptr }, { i64, ptr } } } %t374, ptr %rv
  br label %ret
bb77:
  store %olang.scope zeroinitializer, ptr %s14
  %t375 = load ptr, ptr %l0, !tbaa !29
  %t377 = getelementptr %"compiler/load:Loader", ptr %t375, i32 0, i32 4
  %t378 = load ptr, ptr %t377, !tbaa !29
  store ptr %t378, ptr %l174, !tbaa !29
  %t379 = load { i64, [3 x i64] }, ptr %l4
  store { i64, [3 x i64] } %t379, ptr %l175
  %t380 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t382 = call { i64, ptr } @compiler_2fload_2ekey(ptr %v1, ptr %s14, { i64, ptr } %t380)
  store { i64, ptr } %t382, ptr %l177
  br label %bb86
bb78:
  %t383 = load ptr, ptr %l147, !tbaa !29
  %t384 = load { i64, [3 x i64] }, ptr %l148
  %t385 = load %"compiler/msgs:Msg", ptr %l149
  %t386 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s11, ptr %t383, { i64, [3 x i64] } %t384, %"compiler/msgs:Msg" %t385)
  store i64 %t386, ptr %l150
  br label %bb79
bb79:
  call void @__olang_scope_close(ptr %s11)
  store { i64, ptr } { i64 0, ptr @.d64 }, ptr %l151, !tbaa !27
  %t387 = load { i64, ptr }, ptr %l151, !tbaa !27
  store { i64, ptr } %t387, ptr %l130, !tbaa !27
  br label %bb89
bb80:
  %t389 = load { i64, ptr }, ptr %l157, !tbaa !27
  %t390 = extractvalue { i64, ptr } %t389, 0
  %t391 = extractvalue { i64, ptr } %t389, 1
  %t392 = mul i64 %t390, 1
  %t393 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t392)
  call void @llvm.memcpy.p0.p0.i64(ptr %t393, ptr %t391, i64 %t392, i1 false)
  %t394 = insertvalue { i64, ptr } undef, i64 %t390, 0
  %t395 = insertvalue { i64, ptr } %t394, ptr %t393, 1
  %t397 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportLockNotACommit(ptr %s12, ptr %s12, { i64, ptr } %t395)
  store %"compiler/msgs:Msg" %t397, ptr %l159
  br label %bb81
bb81:
  %t398 = load ptr, ptr %l154, !tbaa !29
  %t399 = load { i64, [3 x i64] }, ptr %l155
  %t400 = load %"compiler/msgs:Msg", ptr %l159
  %t401 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s12, ptr %t398, { i64, [3 x i64] } %t399, %"compiler/msgs:Msg" %t400)
  store i64 %t401, ptr %l160
  br label %bb82
bb82:
  call void @__olang_scope_close(ptr %s12)
  store { i64, ptr } { i64 0, ptr @.d65 }, ptr %l161, !tbaa !27
  %t402 = load { i64, ptr }, ptr %l161, !tbaa !27
  store { i64, ptr } %t402, ptr %l130, !tbaa !27
  br label %bb89
bb83:
  %t404 = load { i64, ptr }, ptr %l167, !tbaa !27
  %t405 = extractvalue { i64, ptr } %t404, 0
  %t406 = extractvalue { i64, ptr } %t404, 1
  %t407 = mul i64 %t405, 1
  %t408 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t407)
  call void @llvm.memcpy.p0.p0.i64(ptr %t408, ptr %t406, i64 %t407, i1 false)
  %t409 = insertvalue { i64, ptr } undef, i64 %t405, 0
  %t410 = insertvalue { i64, ptr } %t409, ptr %t408, 1
  %t412 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportFetchFailed(ptr %s13, ptr %s13, { i64, ptr } %t410)
  store %"compiler/msgs:Msg" %t412, ptr %l169
  br label %bb84
bb84:
  %t413 = load ptr, ptr %l164, !tbaa !29
  %t414 = load { i64, [3 x i64] }, ptr %l165
  %t415 = load %"compiler/msgs:Msg", ptr %l169
  %t416 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s13, ptr %t413, { i64, [3 x i64] } %t414, %"compiler/msgs:Msg" %t415)
  store i64 %t416, ptr %l170
  br label %bb85
bb85:
  call void @__olang_scope_close(ptr %s13)
  store { i64, ptr } { i64 0, ptr @.d66 }, ptr %l171, !tbaa !27
  %t417 = load { i64, ptr }, ptr %l171, !tbaa !27
  store { i64, ptr } %t417, ptr %l130, !tbaa !27
  br label %bb89
bb86:
  %t419 = load { i64, ptr }, ptr %l177, !tbaa !27
  %t420 = extractvalue { i64, ptr } %t419, 0
  %t421 = extractvalue { i64, ptr } %t419, 1
  %t422 = mul i64 %t420, 1
  %t423 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t422)
  call void @llvm.memcpy.p0.p0.i64(ptr %t423, ptr %t421, i64 %t422, i1 false)
  %t424 = insertvalue { i64, ptr } undef, i64 %t420, 0
  %t425 = insertvalue { i64, ptr } %t424, ptr %t423, 1
  %t427 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportLockedFetchFailed(ptr %s14, ptr %s14, { i64, ptr } %t425)
  store %"compiler/msgs:Msg" %t427, ptr %l179
  br label %bb87
bb87:
  %t428 = load ptr, ptr %l174, !tbaa !29
  %t429 = load { i64, [3 x i64] }, ptr %l175
  %t430 = load %"compiler/msgs:Msg", ptr %l179
  %t431 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s14, ptr %t428, { i64, [3 x i64] } %t429, %"compiler/msgs:Msg" %t430)
  store i64 %t431, ptr %l180
  br label %bb88
bb88:
  call void @__olang_scope_close(ptr %s14)
  store { i64, ptr } { i64 0, ptr @.d67 }, ptr %l181, !tbaa !27
  %t432 = load { i64, ptr }, ptr %l181, !tbaa !27
  store { i64, ptr } %t432, ptr %l130, !tbaa !27
  br label %bb89
bb89:
  %t434 = load { i64, ptr }, ptr %l130, !tbaa !27
  store { i64, ptr } %t434, ptr %l11, !tbaa !27
  %t435 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t437 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s9, ptr %s9, { i64, ptr } %t435, { i64, ptr } { i64 0, ptr @.d68 })
  store i1 %t437, ptr %l184
  br label %bb90
bb90:
  %t438 = load i1, ptr %l184, !tbaa !21
  br i1 %t438, label %bb91, label %bb92
bb91:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t440 = insertvalue { i32, { { i64, ptr }, { i64, ptr } } } zeroinitializer, i32 65536, 0
  store { i32, { { i64, ptr }, { i64, ptr } } } %t440, ptr %rv
  br label %ret
bb92:
  br label %bb93
bb93:
  %t441 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s9)
  store %"std/prelude/text:StringBuilder" %t441, ptr %l186
  br label %bb94
bb94:
  %t442 = load %"std/prelude/text:StringBuilder", ptr %l186
  store %"std/prelude/text:StringBuilder" %t442, ptr %l12
  %t443 = load { i64, ptr }, ptr %l11, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s9, ptr %s9, ptr %l12, { i64, ptr } %t443)
  br label %bb95
bb95:
  store i64 3, ptr %l13, !tbaa !24
  %t446 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t448 = extractvalue { i64, ptr } %t446, 0
  store i64 %t448, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t450 = load i64, ptr %l14, !tbaa !24
  %t451 = load i64, ptr %l13, !tbaa !24
  %t454 = icmp sgt i64 %t450, %t451
  br i1 %t454, label %bb96, label %bb97
bb96:
  %t456 = load i64, ptr %l15, !tbaa !24
  %t458 = icmp sgt i64 %t456, 0
  br i1 %t458, label %bb98, label %bb99
bb97:
  store i64 0, ptr %l194, !tbaa !24
  br label %bb101
bb98:
  %t460 = load i64, ptr %l14, !tbaa !24
  %t461 = load i64, ptr %l13, !tbaa !24
  %t464 = sub i64 %t460, %t461
  %t465 = load i64, ptr %l15, !tbaa !24
  %t468 = add i64 %t464, %t465
  %t470 = sub i64 %t468, 1
  %t471 = load i64, ptr %l15, !tbaa !24
  %t474 = sdiv i64 %t470, %t471
  store i64 %t474, ptr %l197, !tbaa !24
  br label %bb100
bb99:
  store i64 0, ptr %l197, !tbaa !24
  br label %bb100
bb100:
  %t476 = load i64, ptr %l197, !tbaa !24
  store i64 %t476, ptr %l194, !tbaa !24
  br label %bb101
bb101:
  %t477 = load i64, ptr %l194, !tbaa !24
  store i64 %t477, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb102
bb102:
  store %olang.scope zeroinitializer, ptr %s17
  %t478 = load i64, ptr %l17, !tbaa !24
  %t479 = load i64, ptr %l16, !tbaa !24
  %t482 = icmp slt i64 %t478, %t479
  %t484 = xor i1 %t482, true
  br i1 %t484, label %bb103, label %bb104
bb103:
  call void @__olang_scope_close(ptr %s17)
  br label %bb109
bb104:
  br label %bb105
bb105:
  %t486 = load i64, ptr %l13, !tbaa !24
  %t487 = load i64, ptr %l17, !tbaa !24
  %t488 = load i64, ptr %l15, !tbaa !24
  %t491 = mul i64 %t487, %t488
  %t494 = add i64 %t486, %t491
  store i64 %t494, ptr %l18, !tbaa !24
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s9, ptr %l12, i8 47)
  br label %bb106
bb106:
  %t497 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t497, ptr %l217, !tbaa !27
  %t498 = load i64, ptr %l18, !tbaa !24
  %t500 = getelementptr { i64, ptr }, ptr %l217, i32 0, i32 1
  %t501 = load ptr, ptr %t500, !tbaa !27
  %t502 = getelementptr { i64, ptr }, ptr %t501, i64 %t498
  %t503 = load { i64, ptr }, ptr %t502, !tbaa !37
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s9, ptr %v1, ptr %l12, { i64, ptr } %t503)
  br label %bb107
bb107:
  call void @__olang_scope_close(ptr %s17)
  br label %bb108
bb108:
  %t506 = load i64, ptr %l17, !tbaa !24
  %t508 = add i64 %t506, 1
  store i64 %t508, ptr %l17, !tbaa !24
  br label %bb102
bb109:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s9, ptr %s9, ptr %l12, { i64, ptr } { i64 6, ptr @.d69 })
  br label %bb110
bb110:
  %t512 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s9, ptr %s9, ptr %l12)
  store { i64, ptr } %t512, ptr %l224
  br label %bb111
bb111:
  %t513 = load { i64, ptr }, ptr %l224, !tbaa !27
  %t514 = call { i64, ptr } @compiler_2fload_2eNormalize(ptr %s9, ptr %s9, { i64, ptr } %t513)
  store { i64, ptr } %t514, ptr %l225
  br label %bb112
bb112:
  %t515 = load { i64, ptr }, ptr %l225, !tbaa !27
  %t516 = extractvalue { i64, ptr } %t515, 1
  %t517 = extractvalue { i64, ptr } %t515, 0
  %t518 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t517)
  call void @olang_textcopy(ptr %t518, ptr %t516, i64 %t517)
  %t519 = insertvalue { i64, ptr } undef, i64 %t517, 0
  %t520 = insertvalue { i64, ptr } %t519, ptr %t518, 1
  store { i64, ptr } %t520, ptr %l226, !tbaa !27
  %t521 = load ptr, ptr %lp8
  %t522 = load { i64, ptr }, ptr %t521, !tbaa !27
  %t523 = extractvalue { i64, ptr } %t522, 0
  %t524 = load { i64, ptr }, ptr %l226, !tbaa !27
  %t525 = extractvalue { i64, ptr } %t524, 0
  store i64 %t525, ptr %l228, !tbaa !24
  %t527 = load i64, ptr %l228, !tbaa !24
  %t528 = icmp eq i64 %t523, %t527
  br i1 %t528, label %bb113, label %bb114
bb113:
  %t530 = load ptr, ptr %lp8
  %t531 = getelementptr { i64, ptr }, ptr %t530, i32 0, i32 1
  %t532 = load ptr, ptr %t531, !tbaa !27
  %t533 = getelementptr { i64, ptr }, ptr %l226, i32 0, i32 1
  %t534 = load ptr, ptr %t533, !tbaa !27
  %t535 = load i64, ptr %l228, !tbaa !24
  %t536 = mul i64 %t535, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t532, ptr %t534, i64 %t536, i1 false)
  br label %bb115
bb114:
  %t537 = load { i64, ptr }, ptr %l226, !tbaa !27
  %t538 = load ptr, ptr %lp8
  store { i64, ptr } %t537, ptr %t538, !tbaa !27
  br label %bb115
bb115:
  %t539 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t541 = call { i64, ptr } @compiler_2fload_2eNormalize(ptr %v1, ptr %s9, { i64, ptr } %t539)
  store { i64, ptr } %t541, ptr %l231
  br label %bb116
bb116:
  %t542 = load { i64, ptr }, ptr %l231, !tbaa !27
  %t543 = extractvalue { i64, ptr } %t542, 1
  %t544 = extractvalue { i64, ptr } %t542, 0
  %t545 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t544)
  call void @olang_textcopy(ptr %t545, ptr %t543, i64 %t544)
  %t546 = insertvalue { i64, ptr } undef, i64 %t544, 0
  %t547 = insertvalue { i64, ptr } %t546, ptr %t545, 1
  store { i64, ptr } %t547, ptr %l232, !tbaa !27
  %t548 = load ptr, ptr %lp9
  %t549 = load { i64, ptr }, ptr %t548, !tbaa !27
  %t550 = extractvalue { i64, ptr } %t549, 0
  %t551 = load { i64, ptr }, ptr %l232, !tbaa !27
  %t552 = extractvalue { i64, ptr } %t551, 0
  store i64 %t552, ptr %l234, !tbaa !24
  %t554 = load i64, ptr %l234, !tbaa !24
  %t555 = icmp eq i64 %t550, %t554
  br i1 %t555, label %bb117, label %bb118
bb117:
  %t557 = load ptr, ptr %lp9
  %t558 = getelementptr { i64, ptr }, ptr %t557, i32 0, i32 1
  %t559 = load ptr, ptr %t558, !tbaa !27
  %t560 = getelementptr { i64, ptr }, ptr %l232, i32 0, i32 1
  %t561 = load ptr, ptr %t560, !tbaa !27
  %t562 = load i64, ptr %l234, !tbaa !24
  %t563 = mul i64 %t562, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t559, ptr %t561, i64 %t563, i1 false)
  br label %bb119
bb118:
  %t564 = load { i64, ptr }, ptr %l232, !tbaa !27
  %t565 = load ptr, ptr %lp9
  store { i64, ptr } %t564, ptr %t565, !tbaa !27
  br label %bb119
bb119:
  %t566 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t568 = call { i64, ptr } @compiler_2fload_2ekey(ptr %v1, ptr %s9, { i64, ptr } %t566)
  store { i64, ptr } %t568, ptr %l237
  br label %bb120
bb120:
  %t569 = load { i64, ptr }, ptr %l237, !tbaa !27
  store { i64, ptr } %t569, ptr %l19, !tbaa !27
  %t570 = load ptr, ptr %lp9
  %t571 = load { i64, ptr }, ptr %t570, !tbaa !27
  %t572 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t574 = extractvalue { i64, ptr } %t572, 1
  %t575 = extractvalue { i64, ptr } %t572, 0
  %t576 = extractvalue { i64, ptr } { i64 1, ptr @.d70 }, 1
  %t577 = extractvalue { i64, ptr } { i64 1, ptr @.d70 }, 0
  %t578 = add i64 %t575, %t577
  %t579 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t578)
  call void @olang_textcopy(ptr %t579, ptr %t574, i64 %t575)
  %t580 = getelementptr i8, ptr %t579, i64 %t575
  call void @olang_textcopy(ptr %t580, ptr %t576, i64 %t577)
  %t581 = insertvalue { i64, ptr } undef, i64 %t578, 0
  %t582 = insertvalue { i64, ptr } %t581, ptr %t579, 1
  %t584 = extractvalue { i64, ptr } %t582, 0
  %t585 = extractvalue { i64, ptr } %t582, 1
  %t586 = mul i64 %t584, 1
  %t587 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t586)
  call void @llvm.memcpy.p0.p0.i64(ptr %t587, ptr %t585, i64 %t586, i1 false)
  %t588 = insertvalue { i64, ptr } undef, i64 %t584, 0
  %t589 = insertvalue { i64, ptr } %t588, ptr %t587, 1
  %t592 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v2, ptr %s9, { i64, ptr } %t571, { i64, ptr } %t589)
  store i1 %t592, ptr %l242
  br label %bb121
bb121:
  %t593 = load i1, ptr %l242, !tbaa !21
  %t594 = xor i1 %t593, true
  br i1 %t594, label %bb122, label %bb123
bb122:
  store %olang.scope zeroinitializer, ptr %s22
  %t596 = load ptr, ptr %l0, !tbaa !29
  %t598 = getelementptr %"compiler/load:Loader", ptr %t596, i32 0, i32 4
  %t599 = load ptr, ptr %t598, !tbaa !29
  store ptr %t599, ptr %l245, !tbaa !29
  %t600 = load { i64, [3 x i64] }, ptr %l4
  store { i64, [3 x i64] } %t600, ptr %l246
  %t601 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t603 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportLeavesRoot(ptr %s9, ptr %s22, { i64, ptr } %t601)
  store %"compiler/msgs:Msg" %t603, ptr %l248
  br label %bb124
bb123:
  br label %bb126
bb124:
  %t604 = load ptr, ptr %l245, !tbaa !29
  %t605 = load { i64, [3 x i64] }, ptr %l246
  %t606 = load %"compiler/msgs:Msg", ptr %l248
  %t607 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s22, ptr %t604, { i64, [3 x i64] } %t605, %"compiler/msgs:Msg" %t606)
  store i64 %t607, ptr %l249
  br label %bb125
bb125:
  call void @__olang_scope_close(ptr %s22)
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t609 = insertvalue { i32, { { i64, ptr }, { i64, ptr } } } zeroinitializer, i32 65536, 0
  store { i32, { { i64, ptr }, { i64, ptr } } } %t609, ptr %rv
  br label %ret
bb126:
  call void @__olang_scope_close(ptr %s9)
  br label %bb200
bb127:
  %t610 = load { i64, ptr }, ptr %l253, !tbaa !27
  store { i64, ptr } %t610, ptr %l20, !tbaa !27
  %t611 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t613 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s23, { i64, ptr } %t611, { i64, ptr } { i64 1, ptr @.d71 })
  store i1 %t613, ptr %l255
  br label %bb128
bb128:
  %t614 = load i1, ptr %l255, !tbaa !21
  br i1 %t614, label %bb129, label %bb130
bb129:
  store i1 true, ptr %l256, !tbaa !21
  br label %bb132
bb130:
  %t615 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t617 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s23, ptr %s23, { i64, ptr } %t615, { i64, ptr } { i64 1, ptr @.d72 })
  store i1 %t617, ptr %l258
  br label %bb131
bb131:
  %t618 = load i1, ptr %l258, !tbaa !21
  store i1 %t618, ptr %l256, !tbaa !21
  br label %bb132
bb132:
  %t619 = load i1, ptr %l256, !tbaa !21
  br i1 %t619, label %bb133, label %bb134
bb133:
  store %olang.scope zeroinitializer, ptr %s24
  %t620 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t622 = extractvalue { i64, ptr } %t620, 1
  %t623 = extractvalue { i64, ptr } %t620, 0
  %t624 = extractvalue { i64, ptr } { i64 6, ptr @.d73 }, 1
  %t625 = extractvalue { i64, ptr } { i64 6, ptr @.d73 }, 0
  %t626 = add i64 %t623, %t625
  %t627 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t626)
  call void @olang_textcopy(ptr %t627, ptr %t622, i64 %t623)
  %t628 = getelementptr i8, ptr %t627, i64 %t623
  call void @olang_textcopy(ptr %t628, ptr %t624, i64 %t625)
  %t629 = insertvalue { i64, ptr } undef, i64 %t626, 0
  %t630 = insertvalue { i64, ptr } %t629, ptr %t627, 1
  %t632 = extractvalue { i64, ptr } %t630, 0
  %t633 = extractvalue { i64, ptr } %t630, 1
  %t634 = mul i64 %t632, 1
  %t635 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t634)
  call void @llvm.memcpy.p0.p0.i64(ptr %t635, ptr %t633, i64 %t634, i1 false)
  %t636 = insertvalue { i64, ptr } undef, i64 %t632, 0
  %t637 = insertvalue { i64, ptr } %t636, ptr %t635, 1
  %t639 = call { i64, ptr } @compiler_2fload_2eNormalize(ptr %s24, ptr %s24, { i64, ptr } %t637)
  store { i64, ptr } %t639, ptr %l262
  br label %bb135
bb134:
  store %olang.scope zeroinitializer, ptr %s27
  %t640 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t641 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t643 = extractvalue { i64, ptr } %t640, 1
  %t644 = extractvalue { i64, ptr } %t640, 0
  %t645 = extractvalue { i64, ptr } { i64 1, ptr @.d74 }, 1
  %t646 = extractvalue { i64, ptr } { i64 1, ptr @.d74 }, 0
  %t647 = add i64 %t644, %t646
  %t649 = extractvalue { i64, ptr } %t641, 1
  %t650 = extractvalue { i64, ptr } %t641, 0
  %t651 = add i64 %t647, %t650
  %t652 = extractvalue { i64, ptr } { i64 6, ptr @.d75 }, 1
  %t653 = extractvalue { i64, ptr } { i64 6, ptr @.d75 }, 0
  %t654 = add i64 %t651, %t653
  %t655 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t654)
  call void @olang_textcopy(ptr %t655, ptr %t643, i64 %t644)
  %t656 = getelementptr i8, ptr %t655, i64 %t644
  call void @olang_textcopy(ptr %t656, ptr %t645, i64 %t646)
  %t657 = getelementptr i8, ptr %t656, i64 %t646
  call void @olang_textcopy(ptr %t657, ptr %t649, i64 %t650)
  %t658 = getelementptr i8, ptr %t657, i64 %t650
  call void @olang_textcopy(ptr %t658, ptr %t652, i64 %t653)
  %t659 = insertvalue { i64, ptr } undef, i64 %t654, 0
  %t660 = insertvalue { i64, ptr } %t659, ptr %t655, 1
  %t662 = extractvalue { i64, ptr } %t660, 0
  %t663 = extractvalue { i64, ptr } %t660, 1
  %t664 = mul i64 %t662, 1
  %t665 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t664)
  call void @llvm.memcpy.p0.p0.i64(ptr %t665, ptr %t663, i64 %t664, i1 false)
  %t666 = insertvalue { i64, ptr } undef, i64 %t662, 0
  %t667 = insertvalue { i64, ptr } %t666, ptr %t665, 1
  %t669 = call { i64, ptr } @compiler_2fload_2eNormalize(ptr %s27, ptr %s27, { i64, ptr } %t667)
  store { i64, ptr } %t669, ptr %l271
  br label %bb139
bb135:
  %t670 = load { i64, ptr }, ptr %l262, !tbaa !27
  %t671 = extractvalue { i64, ptr } %t670, 1
  %t672 = extractvalue { i64, ptr } %t670, 0
  %t673 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t672)
  call void @olang_textcopy(ptr %t673, ptr %t671, i64 %t672)
  %t674 = insertvalue { i64, ptr } undef, i64 %t672, 0
  %t675 = insertvalue { i64, ptr } %t674, ptr %t673, 1
  store { i64, ptr } %t675, ptr %l263, !tbaa !27
  %t676 = load ptr, ptr %lp8
  %t677 = load { i64, ptr }, ptr %t676, !tbaa !27
  %t678 = extractvalue { i64, ptr } %t677, 0
  %t679 = load { i64, ptr }, ptr %l263, !tbaa !27
  %t680 = extractvalue { i64, ptr } %t679, 0
  store i64 %t680, ptr %l265, !tbaa !24
  %t682 = load i64, ptr %l265, !tbaa !24
  %t683 = icmp eq i64 %t678, %t682
  br i1 %t683, label %bb136, label %bb137
bb136:
  %t685 = load ptr, ptr %lp8
  %t686 = getelementptr { i64, ptr }, ptr %t685, i32 0, i32 1
  %t687 = load ptr, ptr %t686, !tbaa !27
  %t688 = getelementptr { i64, ptr }, ptr %l263, i32 0, i32 1
  %t689 = load ptr, ptr %t688, !tbaa !27
  %t690 = load i64, ptr %l265, !tbaa !24
  %t691 = mul i64 %t690, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t687, ptr %t689, i64 %t691, i1 false)
  br label %bb138
bb137:
  %t692 = load { i64, ptr }, ptr %l263, !tbaa !27
  %t693 = load ptr, ptr %lp8
  store { i64, ptr } %t692, ptr %t693, !tbaa !27
  br label %bb138
bb138:
  call void @__olang_scope_close(ptr %s24)
  br label %bb143
bb139:
  %t694 = load { i64, ptr }, ptr %l271, !tbaa !27
  %t695 = extractvalue { i64, ptr } %t694, 1
  %t696 = extractvalue { i64, ptr } %t694, 0
  %t697 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t696)
  call void @olang_textcopy(ptr %t697, ptr %t695, i64 %t696)
  %t698 = insertvalue { i64, ptr } undef, i64 %t696, 0
  %t699 = insertvalue { i64, ptr } %t698, ptr %t697, 1
  store { i64, ptr } %t699, ptr %l272, !tbaa !27
  %t700 = load ptr, ptr %lp8
  %t701 = load { i64, ptr }, ptr %t700, !tbaa !27
  %t702 = extractvalue { i64, ptr } %t701, 0
  %t703 = load { i64, ptr }, ptr %l272, !tbaa !27
  %t704 = extractvalue { i64, ptr } %t703, 0
  store i64 %t704, ptr %l274, !tbaa !24
  %t706 = load i64, ptr %l274, !tbaa !24
  %t707 = icmp eq i64 %t702, %t706
  br i1 %t707, label %bb140, label %bb141
bb140:
  %t709 = load ptr, ptr %lp8
  %t710 = getelementptr { i64, ptr }, ptr %t709, i32 0, i32 1
  %t711 = load ptr, ptr %t710, !tbaa !27
  %t712 = getelementptr { i64, ptr }, ptr %l272, i32 0, i32 1
  %t713 = load ptr, ptr %t712, !tbaa !27
  %t714 = load i64, ptr %l274, !tbaa !24
  %t715 = mul i64 %t714, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t711, ptr %t713, i64 %t715, i1 false)
  br label %bb142
bb141:
  %t716 = load { i64, ptr }, ptr %l272, !tbaa !27
  %t717 = load ptr, ptr %lp8
  store { i64, ptr } %t716, ptr %t717, !tbaa !27
  br label %bb142
bb142:
  call void @__olang_scope_close(ptr %s27)
  br label %bb143
bb143:
  %t718 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t720 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s23, { i64, ptr } %t718, { i64, ptr } { i64 1, ptr @.d76 })
  store i1 %t720, ptr %l277
  br label %bb144
bb144:
  %t721 = load i1, ptr %l277, !tbaa !21
  br i1 %t721, label %bb145, label %bb146
bb145:
  %t722 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t724 = call { i64, ptr } @std_2ffilepath_2eBase(ptr %v1, { i64, ptr } %t722)
  store { i64, ptr } %t724, ptr %l280
  br label %bb147
bb146:
  %t725 = load ptr, ptr %l3, !tbaa !29
  %t727 = getelementptr %"compiler/load:Module", ptr %t725, i32 0, i32 2
  %t728 = load { i64, ptr }, ptr %t727, !tbaa !27
  %t729 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t732 = call { i64, ptr } @compiler_2fload_2erelativeIdentity(ptr %v0, ptr %v1, ptr %s23, { i64, ptr } %t728, { i64, ptr } %t729)
  store { i64, ptr } %t732, ptr %l285
  br label %bb148
bb147:
  %t733 = load { i64, ptr }, ptr %l280, !tbaa !27
  %t734 = extractvalue { i64, ptr } %t733, 1
  %t735 = extractvalue { i64, ptr } %t733, 0
  %t736 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t735)
  call void @olang_textcopy(ptr %t736, ptr %t734, i64 %t735)
  %t737 = insertvalue { i64, ptr } undef, i64 %t735, 0
  %t738 = insertvalue { i64, ptr } %t737, ptr %t736, 1
  store { i64, ptr } %t738, ptr %l278, !tbaa !27
  br label %bb149
bb148:
  %t740 = load { i64, ptr }, ptr %l285, !tbaa !27
  %t741 = extractvalue { i64, ptr } %t740, 1
  %t742 = extractvalue { i64, ptr } %t740, 0
  %t743 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t742)
  call void @olang_textcopy(ptr %t743, ptr %t741, i64 %t742)
  %t744 = insertvalue { i64, ptr } undef, i64 %t742, 0
  %t745 = insertvalue { i64, ptr } %t744, ptr %t743, 1
  store { i64, ptr } %t745, ptr %l278, !tbaa !27
  br label %bb149
bb149:
  %t747 = load ptr, ptr %lp9
  %t748 = load { i64, ptr }, ptr %t747, !tbaa !27
  %t749 = extractvalue { i64, ptr } %t748, 0
  %t750 = load { i64, ptr }, ptr %l278, !tbaa !27
  %t751 = extractvalue { i64, ptr } %t750, 0
  store i64 %t751, ptr %l288, !tbaa !24
  %t753 = load i64, ptr %l288, !tbaa !24
  %t754 = icmp eq i64 %t749, %t753
  br i1 %t754, label %bb150, label %bb151
bb150:
  %t756 = load ptr, ptr %lp9
  %t757 = getelementptr { i64, ptr }, ptr %t756, i32 0, i32 1
  %t758 = load ptr, ptr %t757, !tbaa !27
  %t759 = getelementptr { i64, ptr }, ptr %l278, i32 0, i32 1
  %t760 = load ptr, ptr %t759, !tbaa !27
  %t761 = load i64, ptr %l288, !tbaa !24
  %t762 = mul i64 %t761, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t758, ptr %t760, i64 %t762, i1 false)
  br label %bb152
bb151:
  %t763 = load { i64, ptr }, ptr %l278, !tbaa !27
  %t764 = load ptr, ptr %lp9
  store { i64, ptr } %t763, ptr %t764, !tbaa !27
  br label %bb152
bb152:
  store { i64, ptr } { i64 0, ptr @.d77 }, ptr %l290, !tbaa !27
  %t765 = load { i64, ptr }, ptr %l290, !tbaa !27
  store { i64, ptr } %t765, ptr %l291, !tbaa !27
  %t766 = load { i64, ptr }, ptr %l291, !tbaa !27
  %t767 = extractvalue { i64, ptr } %t766, 0
  store i64 %t767, ptr %l292, !tbaa !24
  %t768 = load i64, ptr %l292, !tbaa !24
  %t769 = mul i64 %t768, 1
  %t770 = call ptr @__olang_scope_alloc_zeroed(ptr %s23, i64 %t769)
  %t771 = insertvalue { i64, ptr } undef, i64 %t768, 0
  %t772 = insertvalue { i64, ptr } %t771, ptr %t770, 1
  store { i64, ptr } %t772, ptr %l293, !tbaa !27
  %t773 = getelementptr { i64, ptr }, ptr %l293, i32 0, i32 1
  %t774 = load ptr, ptr %t773, !tbaa !27
  %t775 = getelementptr { i64, ptr }, ptr %l291, i32 0, i32 1
  %t776 = load ptr, ptr %t775, !tbaa !27
  %t777 = load i64, ptr %l292, !tbaa !24
  %t778 = mul i64 %t777, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t774, ptr %t776, i64 %t778, i1 false)
  %t779 = load { i64, ptr }, ptr %l293, !tbaa !27
  store { i64, ptr } %t779, ptr %l21, !tbaa !27
  %t780 = load ptr, ptr %l3, !tbaa !29
  %t782 = getelementptr %"compiler/load:Module", ptr %t780, i32 0, i32 2
  %t783 = load { i64, ptr }, ptr %t782, !tbaa !27
  store { i64, ptr } %t783, ptr %l295, !tbaa !27
  %t784 = load ptr, ptr %l3, !tbaa !29
  %t786 = getelementptr %"compiler/load:Module", ptr %t784, i32 0, i32 2
  %t787 = load { i64, ptr }, ptr %t786, !tbaa !27
  %t790 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %t787, i8 47)
  %t791 = extractvalue { i32, i64 } %t790, 1
  %t792 = extractvalue { i32, i64 } %t790, 0
  store i32 %t792, ptr %l301
  %t793 = icmp ne i32 %t792, 0
  br i1 %t793, label %bb154, label %ok.794
ok.794:
  store i64 %t791, ptr %l300
  br label %bb153
bb153:
  %t795 = load i64, ptr %l300, !tbaa !24
  store i64 %t795, ptr %l296, !tbaa !24
  br label %bb156
bb154:
  br label %bb155
bb155:
  %t796 = load ptr, ptr %l3, !tbaa !29
  %t798 = getelementptr %"compiler/load:Module", ptr %t796, i32 0, i32 2
  %t799 = load { i64, ptr }, ptr %t798, !tbaa !27
  %t801 = extractvalue { i64, ptr } %t799, 0
  store i64 %t801, ptr %l296, !tbaa !24
  br label %bb156
bb156:
  %t803 = load { i64, ptr }, ptr %l295, !tbaa !27
  %t804 = extractvalue { i64, ptr } %t803, 0
  store i64 %t804, ptr %l305, !tbaa !24
  %t805 = icmp sge i64 0, 0
  br i1 %t805, label %bb157, label %bb158
bb157:
  %t807 = load i64, ptr %l296, !tbaa !24
  %t808 = icmp sle i64 0, %t807
  br i1 %t808, label %bb159, label %bb160
bb158:
  call void @__olang_check_failed(ptr @olang_loc_91ed1932ac5cd85c_f28264288e99980)
  unreachable
bb159:
  %t810 = load i64, ptr %l296, !tbaa !24
  %t811 = load i64, ptr %l305, !tbaa !24
  %t812 = icmp sle i64 %t810, %t811
  br i1 %t812, label %bb161, label %bb162
bb160:
  call void @__olang_check_failed(ptr @olang_loc_91ed1932ac5cd85c_f28264288e99980)
  unreachable
bb161:
  %t814 = getelementptr { i64, ptr }, ptr %l295, i32 0, i32 1
  %t815 = load ptr, ptr %t814, !tbaa !27
  %t816 = load i64, ptr %l296, !tbaa !24
  %t817 = getelementptr i8, ptr %t815, i64 0
  %t818 = sub i64 %t816, 0
  %t819 = insertvalue { i64, ptr } undef, i64 %t818, 0
  %t820 = insertvalue { i64, ptr } %t819, ptr %t817, 1
  store { i64, ptr } %t820, ptr %l22, !tbaa !27
  %t822 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } { i64 1, ptr @.d78 }, ptr %l312, !tbaa !27
  %t825 = load { i64, ptr }, ptr %l312, !tbaa !27
  %t826 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s23, { i64, ptr } %t822, { i64, ptr } %t825)
  store i1 %t826, ptr %l313
  br label %bb163
bb162:
  call void @__olang_check_failed(ptr @olang_loc_91ed1932ac5cd85c_f28264288e99980)
  unreachable
bb163:
  %t827 = load i1, ptr %l313, !tbaa !21
  br i1 %t827, label %bb164, label %bb165
bb164:
  %t828 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t830 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s23, { i64, ptr } %t828, { i64, ptr } { i64 1, ptr @.d79 })
  store i1 %t830, ptr %l316
  br label %bb166
bb165:
  store i1 false, ptr %l314, !tbaa !21
  br label %bb167
bb166:
  %t831 = load i1, ptr %l316, !tbaa !21
  %t832 = xor i1 %t831, true
  store i1 %t832, ptr %l314, !tbaa !21
  br label %bb167
bb167:
  %t834 = load i1, ptr %l314, !tbaa !21
  br i1 %t834, label %bb168, label %bb169
bb168:
  %t835 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t837 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s23, { i64, ptr } %t835, { i64, ptr } { i64 2, ptr @.d80 })
  store i1 %t837, ptr %l320
  br label %bb170
bb169:
  store i1 false, ptr %l318, !tbaa !21
  br label %bb171
bb170:
  %t838 = load i1, ptr %l320, !tbaa !21
  %t839 = xor i1 %t838, true
  store i1 %t839, ptr %l318, !tbaa !21
  br label %bb171
bb171:
  %t841 = load i1, ptr %l318, !tbaa !21
  store i1 %t841, ptr %l23, !tbaa !21
  %t842 = load ptr, ptr %l3, !tbaa !29
  %t844 = getelementptr %"compiler/load:Module", ptr %t842, i32 0, i32 2
  %t845 = load { i64, ptr }, ptr %t844, !tbaa !27
  %t847 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s23, { i64, ptr } %t845, { i64, ptr } { i64 4, ptr @.d81 })
  store i1 %t847, ptr %l324
  br label %bb172
bb172:
  %t848 = load i1, ptr %l324, !tbaa !21
  br i1 %t848, label %bb173, label %bb174
bb173:
  store { i64, ptr } { i64 3, ptr @.d82 }, ptr %l325, !tbaa !27
  %t849 = load { i64, ptr }, ptr %l325, !tbaa !27
  store { i64, ptr } %t849, ptr %l326, !tbaa !27
  %t850 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t851 = extractvalue { i64, ptr } %t850, 0
  %t852 = load { i64, ptr }, ptr %l326, !tbaa !27
  %t853 = extractvalue { i64, ptr } %t852, 0
  store i64 %t853, ptr %l328, !tbaa !24
  %t855 = load i64, ptr %l328, !tbaa !24
  %t856 = icmp eq i64 %t851, %t855
  br i1 %t856, label %bb175, label %bb176
bb174:
  store %olang.scope zeroinitializer, ptr %s33
  %t858 = load i1, ptr %l23, !tbaa !21
  br i1 %t858, label %bb178, label %bb179
bb175:
  %t860 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t861 = load ptr, ptr %t860, !tbaa !27
  %t862 = getelementptr { i64, ptr }, ptr %l326, i32 0, i32 1
  %t863 = load ptr, ptr %t862, !tbaa !27
  %t864 = load i64, ptr %l328, !tbaa !24
  %t865 = mul i64 %t864, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t861, ptr %t863, i64 %t865, i1 false)
  br label %bb177
bb176:
  %t866 = load { i64, ptr }, ptr %l326, !tbaa !27
  %t867 = extractvalue { i64, ptr } %t866, 0
  store i64 %t867, ptr %l330, !tbaa !24
  %t868 = load i64, ptr %l330, !tbaa !24
  %t869 = mul i64 %t868, 1
  %t870 = call ptr @__olang_scope_alloc_zeroed(ptr %s23, i64 %t869)
  %t871 = insertvalue { i64, ptr } undef, i64 %t868, 0
  %t872 = insertvalue { i64, ptr } %t871, ptr %t870, 1
  store { i64, ptr } %t872, ptr %l331, !tbaa !27
  %t873 = getelementptr { i64, ptr }, ptr %l331, i32 0, i32 1
  %t874 = load ptr, ptr %t873, !tbaa !27
  %t875 = getelementptr { i64, ptr }, ptr %l326, i32 0, i32 1
  %t876 = load ptr, ptr %t875, !tbaa !27
  %t877 = load i64, ptr %l330, !tbaa !24
  %t878 = mul i64 %t877, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t874, ptr %t876, i64 %t878, i1 false)
  %t879 = load { i64, ptr }, ptr %l331, !tbaa !27
  store { i64, ptr } %t879, ptr %l21, !tbaa !27
  br label %bb177
bb177:
  br label %bb189
bb178:
  %t880 = load ptr, ptr %l3, !tbaa !29
  %t882 = getelementptr %"compiler/load:Module", ptr %t880, i32 0, i32 2
  %t883 = load { i64, ptr }, ptr %t882, !tbaa !27
  store { i64, ptr } { i64 1, ptr @.d83 }, ptr %l337, !tbaa !27
  %t886 = load { i64, ptr }, ptr %l337, !tbaa !27
  %t887 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s33, { i64, ptr } %t883, { i64, ptr } %t886)
  store i1 %t887, ptr %l338
  br label %bb180
bb179:
  store i1 false, ptr %l333, !tbaa !21
  br label %bb181
bb180:
  %t888 = load i1, ptr %l338, !tbaa !21
  store i1 %t888, ptr %l333, !tbaa !21
  br label %bb181
bb181:
  %t889 = load i1, ptr %l333, !tbaa !21
  br i1 %t889, label %bb182, label %bb183
bb182:
  %t890 = load ptr, ptr %l3, !tbaa !29
  %t892 = getelementptr %"compiler/load:Module", ptr %t890, i32 0, i32 2
  %t893 = load { i64, ptr }, ptr %t892, !tbaa !27
  %t895 = call { i64, ptr } @compiler_2fload_2efirstElems(ptr %v0, { i64, ptr } %t893, i64 3)
  store { i64, ptr } %t895, ptr %l341
  br label %bb184
bb183:
  br label %bb188
bb184:
  %t896 = load { i64, ptr }, ptr %l341, !tbaa !27
  %t897 = extractvalue { i64, ptr } %t896, 1
  %t898 = extractvalue { i64, ptr } %t896, 0
  %t899 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t898)
  call void @olang_textcopy(ptr %t899, ptr %t897, i64 %t898)
  %t900 = insertvalue { i64, ptr } undef, i64 %t898, 0
  %t901 = insertvalue { i64, ptr } %t900, ptr %t899, 1
  store { i64, ptr } %t901, ptr %l342, !tbaa !27
  %t902 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t903 = extractvalue { i64, ptr } %t902, 0
  %t904 = load { i64, ptr }, ptr %l342, !tbaa !27
  %t905 = extractvalue { i64, ptr } %t904, 0
  store i64 %t905, ptr %l344, !tbaa !24
  %t907 = load i64, ptr %l344, !tbaa !24
  %t908 = icmp eq i64 %t903, %t907
  br i1 %t908, label %bb185, label %bb186
bb185:
  %t910 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t911 = load ptr, ptr %t910, !tbaa !27
  %t912 = getelementptr { i64, ptr }, ptr %l342, i32 0, i32 1
  %t913 = load ptr, ptr %t912, !tbaa !27
  %t914 = load i64, ptr %l344, !tbaa !24
  %t915 = mul i64 %t914, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t911, ptr %t913, i64 %t915, i1 false)
  br label %bb187
bb186:
  %t916 = load { i64, ptr }, ptr %l342, !tbaa !27
  store { i64, ptr } %t916, ptr %l21, !tbaa !27
  br label %bb187
bb187:
  br label %bb188
bb188:
  call void @__olang_scope_close(ptr %s33)
  br label %bb189
bb189:
  %t917 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t919 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s23, ptr %s23, { i64, ptr } %t917, { i64, ptr } { i64 0, ptr @.d84 })
  store i1 %t919, ptr %l347
  br label %bb190
bb190:
  %t920 = load i1, ptr %l347, !tbaa !21
  %t921 = xor i1 %t920, true
  br i1 %t921, label %bb191, label %bb192
bb191:
  %t923 = load ptr, ptr %lp9
  %t924 = load { i64, ptr }, ptr %t923, !tbaa !27
  %t925 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t927 = extractvalue { i64, ptr } %t925, 1
  %t928 = extractvalue { i64, ptr } %t925, 0
  %t929 = extractvalue { i64, ptr } { i64 1, ptr @.d85 }, 1
  %t930 = extractvalue { i64, ptr } { i64 1, ptr @.d85 }, 0
  %t931 = add i64 %t928, %t930
  %t932 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t931)
  call void @olang_textcopy(ptr %t932, ptr %t927, i64 %t928)
  %t933 = getelementptr i8, ptr %t932, i64 %t928
  call void @olang_textcopy(ptr %t933, ptr %t929, i64 %t930)
  %t934 = insertvalue { i64, ptr } undef, i64 %t931, 0
  %t935 = insertvalue { i64, ptr } %t934, ptr %t932, 1
  %t937 = extractvalue { i64, ptr } %t935, 0
  %t938 = extractvalue { i64, ptr } %t935, 1
  %t939 = mul i64 %t937, 1
  %t940 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t939)
  call void @llvm.memcpy.p0.p0.i64(ptr %t940, ptr %t938, i64 %t939, i1 false)
  %t941 = insertvalue { i64, ptr } undef, i64 %t937, 0
  %t942 = insertvalue { i64, ptr } %t941, ptr %t940, 1
  %t945 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v2, ptr %s23, { i64, ptr } %t924, { i64, ptr } %t942)
  store i1 %t945, ptr %l354
  br label %bb193
bb192:
  store i1 false, ptr %l349, !tbaa !21
  br label %bb194
bb193:
  %t946 = load i1, ptr %l354, !tbaa !21
  %t947 = xor i1 %t946, true
  store i1 %t947, ptr %l349, !tbaa !21
  br label %bb194
bb194:
  %t949 = load i1, ptr %l349, !tbaa !21
  br i1 %t949, label %bb195, label %bb196
bb195:
  store %olang.scope zeroinitializer, ptr %s37
  %t950 = load ptr, ptr %l0, !tbaa !29
  %t952 = getelementptr %"compiler/load:Loader", ptr %t950, i32 0, i32 4
  %t953 = load ptr, ptr %t952, !tbaa !29
  store ptr %t953, ptr %l357, !tbaa !29
  %t954 = load { i64, [3 x i64] }, ptr %l4
  store { i64, [3 x i64] } %t954, ptr %l358
  %t955 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t957 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportLeavesRoot(ptr %s23, ptr %s37, { i64, ptr } %t955)
  store %"compiler/msgs:Msg" %t957, ptr %l360
  br label %bb197
bb196:
  br label %bb199
bb197:
  %t958 = load ptr, ptr %l357, !tbaa !29
  %t959 = load { i64, [3 x i64] }, ptr %l358
  %t960 = load %"compiler/msgs:Msg", ptr %l360
  %t961 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s37, ptr %t958, { i64, [3 x i64] } %t959, %"compiler/msgs:Msg" %t960)
  store i64 %t961, ptr %l361
  br label %bb198
bb198:
  call void @__olang_scope_close(ptr %s37)
  call void @__olang_scope_close(ptr %s23)
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t963 = insertvalue { i32, { { i64, ptr }, { i64, ptr } } } zeroinitializer, i32 65536, 0
  store { i32, { { i64, ptr }, { i64, ptr } } } %t963, ptr %rv
  br label %ret
bb199:
  call void @__olang_scope_close(ptr %s23)
  br label %bb200
bb200:
  call void @__olang_scope_close(ptr %s8)
  br label %bb201
bb201:
  %t964 = load ptr, ptr %lp8
  %t965 = load { i64, ptr }, ptr %t964, !tbaa !27
  %t967 = call i1 @std_2fos_2eExists(ptr %v2, { i64, ptr } %t965)
  store i1 %t967, ptr %l364
  br label %bb202
bb202:
  %t968 = load i1, ptr %l364, !tbaa !21
  %t969 = xor i1 %t968, true
  br i1 %t969, label %bb203, label %bb204
bb203:
  store i1 true, ptr %l366, !tbaa !21
  br label %bb206
bb204:
  %t971 = load ptr, ptr %lp8
  %t972 = load { i64, ptr }, ptr %t971, !tbaa !27
  %t974 = call i1 @std_2fos_2eIsDir(ptr %v2, { i64, ptr } %t972)
  store i1 %t974, ptr %l368
  br label %bb205
bb205:
  %t975 = load i1, ptr %l368, !tbaa !21
  store i1 %t975, ptr %l366, !tbaa !21
  br label %bb206
bb206:
  %t976 = load i1, ptr %l366, !tbaa !21
  br i1 %t976, label %bb207, label %bb208
bb207:
  store %olang.scope zeroinitializer, ptr %s38
  %t977 = load ptr, ptr %l0, !tbaa !29
  %t979 = getelementptr %"compiler/load:Loader", ptr %t977, i32 0, i32 4
  %t980 = load ptr, ptr %t979, !tbaa !29
  store ptr %t980, ptr %l370, !tbaa !29
  %t981 = load { i64, [3 x i64] }, ptr %l4
  store { i64, [3 x i64] } %t981, ptr %l371
  %t982 = load ptr, ptr %lp8
  %t983 = load { i64, ptr }, ptr %t982, !tbaa !27
  %t985 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportFileNotFound(ptr %v2, ptr %s38, { i64, ptr } %t983)
  store %"compiler/msgs:Msg" %t985, ptr %l373
  br label %bb209
bb208:
  br label %bb211
bb209:
  %t986 = load ptr, ptr %l370, !tbaa !29
  %t987 = load { i64, [3 x i64] }, ptr %l371
  %t988 = load %"compiler/msgs:Msg", ptr %l373
  %t989 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s38, ptr %t986, { i64, [3 x i64] } %t987, %"compiler/msgs:Msg" %t988)
  store i64 %t989, ptr %l374
  br label %bb210
bb210:
  call void @__olang_scope_close(ptr %s38)
  call void @__olang_scope_close(ptr %s0)
  %t991 = insertvalue { i32, { { i64, ptr }, { i64, ptr } } } zeroinitializer, i32 65536, 0
  store { i32, { { i64, ptr }, { i64, ptr } } } %t991, ptr %rv
  br label %ret
bb211:
  %t992 = load ptr, ptr %lp8
  %t993 = load { i64, ptr }, ptr %t992, !tbaa !27
  %t994 = load ptr, ptr %lp9
  %t995 = load { i64, ptr }, ptr %t994, !tbaa !27
  %t997 = insertvalue { { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t993, 0
  %t999 = insertvalue { { i64, ptr }, { i64, ptr } } %t997, { i64, ptr } %t995, 1
  call void @__olang_scope_close(ptr %s0)
  %t1001 = insertvalue { i32, { { i64, ptr }, { i64, ptr } } } zeroinitializer, { { i64, ptr }, { i64, ptr } } %t999, 1
  store { i32, { { i64, ptr }, { i64, ptr } } } %t1001, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { { i64, ptr }, { i64, ptr } } }, ptr %rv
  ret { i32, { { i64, ptr }, { i64, ptr } } } %rr
}

define dso_local { i64, ptr } @compiler_2fload_2ecompiler_2fload_3aLoader_2erootIdentity(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %lp6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l11 = alloca { i64, ptr }
  %l15 = alloca i1
  %l17 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %l35 = alloca i1
  %l39 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l47 = alloca { i64, ptr }
  %l49 = alloca i64
  %l51 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l54 = alloca i64
  %l56 = alloca i64
  %l57 = alloca { i64, ptr }
  %l63 = alloca i1
  %l67 = alloca i64
  %l69 = alloca i64
  %l70 = alloca i64
  %l75 = alloca { i64, ptr }
  %l77 = alloca i64
  %l80 = alloca i1
  %l82 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %l90 = alloca i1
  %l91 = alloca { i64, ptr }
  %l94 = alloca i64
  %l95 = alloca i64
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = call { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v1, ptr %s0, { i64, ptr } %t1)
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l10
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store { i64, ptr } %t4, ptr %l9
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t8, ptr %l7, !tbaa !27
  br label %bb4
bb2:
  br label %bb3
bb3:
  store { i64, ptr } { i64 0, ptr @.d86 }, ptr %l11, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  %t12 = extractvalue { i64, ptr } %t9, 1
  %t13 = mul i64 %t11, 1
  %t14 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t13)
  call void @llvm.memcpy.p0.p0.i64(ptr %t14, ptr %t12, i64 %t13, i1 false)
  %t15 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l7, !tbaa !27
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t18, ptr %l2, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t21 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t19, { i64, ptr } { i64 0, ptr @.d87 })
  store i1 %t21, ptr %l15
  br label %bb5
bb5:
  %t22 = load i1, ptr %l15, !tbaa !21
  %t23 = xor i1 %t22, true
  br i1 %t23, label %bb6, label %bb7
bb6:
  %t25 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t25, 1
  %t28 = extractvalue { i64, ptr } %t25, 0
  %t29 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t28)
  call void @olang_textcopy(ptr %t29, ptr %t27, i64 %t28)
  %t30 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t29, 1
  store { i64, ptr } %t31, ptr %l17, !tbaa !27
  br label %bb8
bb7:
  %t33 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 1
  %t36 = extractvalue { i64, ptr } %t33, 0
  %t37 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t36)
  call void @olang_textcopy(ptr %t37, ptr %t35, i64 %t36)
  %t38 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  store { i64, ptr } %t39, ptr %l17, !tbaa !27
  br label %bb8
bb8:
  %t41 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t41, ptr %l3, !tbaa !27
  store { i64, ptr } { i64 0, ptr @.d88 }, ptr %l22, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t42, ptr %l23, !tbaa !27
  %t43 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t43, 0
  store i64 %t44, ptr %l24, !tbaa !24
  %t45 = load i64, ptr %l24, !tbaa !24
  %t46 = mul i64 %t45, 1
  %t47 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t46)
  %t48 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t47, 1
  store { i64, ptr } %t49, ptr %l25, !tbaa !27
  %t50 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = load i64, ptr %l24, !tbaa !24
  %t55 = mul i64 %t54, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t51, ptr %t53, i64 %t55, i1 false)
  %t56 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t56, ptr %l4, !tbaa !27
  store { i64, ptr } { i64 0, ptr @.d89 }, ptr %l26, !tbaa !27
  %t57 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t57, ptr %l27, !tbaa !27
  %t58 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t58, 0
  store i64 %t59, ptr %l28, !tbaa !24
  %t60 = load i64, ptr %l28, !tbaa !24
  %t61 = mul i64 %t60, 1
  %t62 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t61)
  %t63 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t62, 1
  store { i64, ptr } %t64, ptr %l29, !tbaa !27
  %t65 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !27
  %t69 = load i64, ptr %l28, !tbaa !24
  %t70 = mul i64 %t69, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t66, ptr %t68, i64 %t70, i1 false)
  %t71 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t71, ptr %l5, !tbaa !27
  %t72 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/load:Loader", ptr %t73, i32 0, i32 9
  %t76 = load { i64, ptr }, ptr %t75, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t76, 1
  %t79 = extractvalue { i64, ptr } %t76, 0
  %t80 = extractvalue { i64, ptr } { i64 1, ptr @.d90 }, 1
  %t81 = extractvalue { i64, ptr } { i64 1, ptr @.d90 }, 0
  %t82 = add i64 %t79, %t81
  %t83 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t82)
  call void @olang_textcopy(ptr %t83, ptr %t78, i64 %t79)
  %t84 = getelementptr i8, ptr %t83, i64 %t79
  call void @olang_textcopy(ptr %t84, ptr %t80, i64 %t81)
  %t85 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t83, 1
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t89 = extractvalue { i64, ptr } %t86, 1
  %t90 = mul i64 %t88, 1
  %t91 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t90)
  call void @llvm.memcpy.p0.p0.i64(ptr %t91, ptr %t89, i64 %t90, i1 false)
  %t92 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t91, 1
  %t96 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s0, { i64, ptr } %t72, { i64, ptr } %t93)
  store i1 %t96, ptr %l35
  br label %bb9
bb9:
  %t97 = load i1, ptr %l35, !tbaa !21
  br i1 %t97, label %bb10, label %bb11
bb10:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/load:Loader", ptr %t98, i32 0, i32 9
  %t101 = load { i64, ptr }, ptr %t100, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t101, 0
  %t105 = add i64 %t103, 1
  store i64 %t105, ptr %l39, !tbaa !24
  %t106 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t108 = extractvalue { i64, ptr } %t106, 0
  store i64 %t108, ptr %l41, !tbaa !24
  %t109 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t109, 0
  store i64 %t110, ptr %l42, !tbaa !24
  %t111 = load i64, ptr %l39, !tbaa !24
  %t112 = icmp sge i64 %t111, 0
  br i1 %t112, label %bb12, label %bb13
bb11:
  store %olang.scope zeroinitializer, ptr %s6
  %t114 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/load:Loader", ptr %t115, i32 0, i32 10
  %t118 = load { i64, ptr }, ptr %t117, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t118, 1
  %t121 = extractvalue { i64, ptr } %t118, 0
  %t122 = extractvalue { i64, ptr } { i64 1, ptr @.d91 }, 1
  %t123 = extractvalue { i64, ptr } { i64 1, ptr @.d91 }, 0
  %t124 = add i64 %t121, %t123
  %t125 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t124)
  call void @olang_textcopy(ptr %t125, ptr %t120, i64 %t121)
  %t126 = getelementptr i8, ptr %t125, i64 %t121
  call void @olang_textcopy(ptr %t126, ptr %t122, i64 %t123)
  %t127 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t128 = insertvalue { i64, ptr } %t127, ptr %t125, 1
  %t130 = extractvalue { i64, ptr } %t128, 0
  %t131 = extractvalue { i64, ptr } %t128, 1
  %t132 = mul i64 %t130, 1
  %t133 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t132)
  call void @llvm.memcpy.p0.p0.i64(ptr %t133, ptr %t131, i64 %t132, i1 false)
  %t134 = insertvalue { i64, ptr } undef, i64 %t130, 0
  %t135 = insertvalue { i64, ptr } %t134, ptr %t133, 1
  %t138 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s6, { i64, ptr } %t114, { i64, ptr } %t135)
  store i1 %t138, ptr %l63
  br label %bb24
bb12:
  %t139 = load i64, ptr %l39, !tbaa !24
  %t140 = load i64, ptr %l41, !tbaa !24
  %t141 = icmp sle i64 %t139, %t140
  br i1 %t141, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_d9612e2b18e8b492_6662b34d58c1f606)
  unreachable
bb14:
  %t143 = load i64, ptr %l41, !tbaa !24
  %t144 = load i64, ptr %l42, !tbaa !24
  %t145 = icmp sle i64 %t143, %t144
  br i1 %t145, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_d9612e2b18e8b492_6662b34d58c1f606)
  unreachable
bb16:
  %t147 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t148 = load ptr, ptr %t147, !tbaa !27
  %t149 = load i64, ptr %l39, !tbaa !24
  %t150 = load i64, ptr %l41, !tbaa !24
  %t151 = getelementptr i8, ptr %t148, i64 %t149
  %t152 = sub i64 %t150, %t149
  %t153 = insertvalue { i64, ptr } undef, i64 %t152, 0
  %t154 = insertvalue { i64, ptr } %t153, ptr %t151, 1
  %t156 = extractvalue { i64, ptr } %t154, 1
  %t157 = extractvalue { i64, ptr } %t154, 0
  %t158 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t157)
  call void @olang_textcopy(ptr %t158, ptr %t156, i64 %t157)
  %t159 = insertvalue { i64, ptr } undef, i64 %t157, 0
  %t160 = insertvalue { i64, ptr } %t159, ptr %t158, 1
  store { i64, ptr } %t160, ptr %l47, !tbaa !27
  %t161 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t162 = extractvalue { i64, ptr } %t161, 0
  %t163 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t164 = extractvalue { i64, ptr } %t163, 0
  store i64 %t164, ptr %l49, !tbaa !24
  %t166 = load i64, ptr %l49, !tbaa !24
  %t167 = icmp eq i64 %t162, %t166
  br i1 %t167, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_d9612e2b18e8b492_6662b34d58c1f606)
  unreachable
bb18:
  %t169 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !27
  %t171 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t172 = load ptr, ptr %t171, !tbaa !27
  %t173 = load i64, ptr %l49, !tbaa !24
  %t174 = mul i64 %t173, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t170, ptr %t172, i64 %t174, i1 false)
  br label %bb20
bb19:
  %t175 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t175, ptr %l4, !tbaa !27
  br label %bb20
bb20:
  store { i64, ptr } { i64 4, ptr @.d92 }, ptr %l51, !tbaa !27
  %t176 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t176, ptr %l52, !tbaa !27
  %t177 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t177, 0
  %t179 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t180 = extractvalue { i64, ptr } %t179, 0
  store i64 %t180, ptr %l54, !tbaa !24
  %t182 = load i64, ptr %l54, !tbaa !24
  %t183 = icmp eq i64 %t178, %t182
  br i1 %t183, label %bb21, label %bb22
bb21:
  %t185 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t186 = load ptr, ptr %t185, !tbaa !27
  %t187 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t188 = load ptr, ptr %t187, !tbaa !27
  %t189 = load i64, ptr %l54, !tbaa !24
  %t190 = mul i64 %t189, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t186, ptr %t188, i64 %t190, i1 false)
  br label %bb23
bb22:
  %t191 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t192 = extractvalue { i64, ptr } %t191, 0
  store i64 %t192, ptr %l56, !tbaa !24
  %t193 = load i64, ptr %l56, !tbaa !24
  %t194 = mul i64 %t193, 1
  %t195 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t194)
  %t196 = insertvalue { i64, ptr } undef, i64 %t193, 0
  %t197 = insertvalue { i64, ptr } %t196, ptr %t195, 1
  store { i64, ptr } %t197, ptr %l57, !tbaa !27
  %t198 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t199 = load ptr, ptr %t198, !tbaa !27
  %t200 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t201 = load ptr, ptr %t200, !tbaa !27
  %t202 = load i64, ptr %l56, !tbaa !24
  %t203 = mul i64 %t202, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t199, ptr %t201, i64 %t203, i1 false)
  %t204 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t204, ptr %l5, !tbaa !27
  br label %bb23
bb23:
  br label %bb37
bb24:
  %t205 = load i1, ptr %l63, !tbaa !21
  br i1 %t205, label %bb25, label %bb26
bb25:
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t208 = getelementptr %"compiler/load:Loader", ptr %t206, i32 0, i32 10
  %t209 = load { i64, ptr }, ptr %t208, !tbaa !27
  %t211 = extractvalue { i64, ptr } %t209, 0
  %t213 = add i64 %t211, 1
  store i64 %t213, ptr %l67, !tbaa !24
  %t214 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t216 = extractvalue { i64, ptr } %t214, 0
  store i64 %t216, ptr %l69, !tbaa !24
  %t217 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t218 = extractvalue { i64, ptr } %t217, 0
  store i64 %t218, ptr %l70, !tbaa !24
  %t219 = load i64, ptr %l67, !tbaa !24
  %t220 = icmp sge i64 %t219, 0
  br i1 %t220, label %bb27, label %bb28
bb26:
  br label %bb36
bb27:
  %t222 = load i64, ptr %l67, !tbaa !24
  %t223 = load i64, ptr %l69, !tbaa !24
  %t224 = icmp sle i64 %t222, %t223
  br i1 %t224, label %bb29, label %bb30
bb28:
  call void @__olang_check_failed(ptr @olang_loc_e481e3499ae60e8f_66ba2a1e23e9a0e3)
  unreachable
bb29:
  %t226 = load i64, ptr %l69, !tbaa !24
  %t227 = load i64, ptr %l70, !tbaa !24
  %t228 = icmp sle i64 %t226, %t227
  br i1 %t228, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_e481e3499ae60e8f_66ba2a1e23e9a0e3)
  unreachable
bb31:
  %t230 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t231 = load ptr, ptr %t230, !tbaa !27
  %t232 = load i64, ptr %l67, !tbaa !24
  %t233 = load i64, ptr %l69, !tbaa !24
  %t234 = getelementptr i8, ptr %t231, i64 %t232
  %t235 = sub i64 %t233, %t232
  %t236 = insertvalue { i64, ptr } undef, i64 %t235, 0
  %t237 = insertvalue { i64, ptr } %t236, ptr %t234, 1
  %t239 = extractvalue { i64, ptr } %t237, 1
  %t240 = extractvalue { i64, ptr } %t237, 0
  %t241 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t240)
  call void @olang_textcopy(ptr %t241, ptr %t239, i64 %t240)
  %t242 = insertvalue { i64, ptr } undef, i64 %t240, 0
  %t243 = insertvalue { i64, ptr } %t242, ptr %t241, 1
  store { i64, ptr } %t243, ptr %l75, !tbaa !27
  %t244 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t245 = extractvalue { i64, ptr } %t244, 0
  %t246 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t247 = extractvalue { i64, ptr } %t246, 0
  store i64 %t247, ptr %l77, !tbaa !24
  %t249 = load i64, ptr %l77, !tbaa !24
  %t250 = icmp eq i64 %t245, %t249
  br i1 %t250, label %bb33, label %bb34
bb32:
  call void @__olang_check_failed(ptr @olang_loc_e481e3499ae60e8f_66ba2a1e23e9a0e3)
  unreachable
bb33:
  %t252 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t253 = load ptr, ptr %t252, !tbaa !27
  %t254 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t255 = load ptr, ptr %t254, !tbaa !27
  %t256 = load i64, ptr %l77, !tbaa !24
  %t257 = mul i64 %t256, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t253, ptr %t255, i64 %t257, i1 false)
  br label %bb35
bb34:
  %t258 = load { i64, ptr }, ptr %l75, !tbaa !27
  store { i64, ptr } %t258, ptr %l4, !tbaa !27
  br label %bb35
bb35:
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s6)
  br label %bb37
bb37:
  %t259 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t261 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t259, { i64, ptr } { i64 0, ptr @.d93 })
  store i1 %t261, ptr %l80
  br label %bb38
bb38:
  %t262 = load i1, ptr %l80, !tbaa !21
  %t263 = xor i1 %t262, true
  br i1 %t263, label %bb39, label %bb40
bb39:
  %t265 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t266 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t268 = extractvalue { i64, ptr } %t265, 1
  %t269 = extractvalue { i64, ptr } %t265, 0
  %t271 = extractvalue { i64, ptr } %t266, 1
  %t272 = extractvalue { i64, ptr } %t266, 0
  %t273 = add i64 %t269, %t272
  %t274 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t273)
  call void @olang_textcopy(ptr %t274, ptr %t268, i64 %t269)
  %t275 = getelementptr i8, ptr %t274, i64 %t269
  call void @olang_textcopy(ptr %t275, ptr %t271, i64 %t272)
  %t276 = insertvalue { i64, ptr } undef, i64 %t273, 0
  %t277 = insertvalue { i64, ptr } %t276, ptr %t274, 1
  store { i64, ptr } %t277, ptr %l82, !tbaa !27
  br label %bb42
bb40:
  %t279 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t281 = call { i64, ptr } @std_2ffilepath_2eBase(ptr %s0, { i64, ptr } %t279)
  store { i64, ptr } %t281, ptr %l87
  br label %bb41
bb41:
  %t282 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t283 = extractvalue { i64, ptr } %t282, 1
  %t284 = extractvalue { i64, ptr } %t282, 0
  %t285 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t284)
  call void @olang_textcopy(ptr %t285, ptr %t283, i64 %t284)
  %t286 = insertvalue { i64, ptr } undef, i64 %t284, 0
  %t287 = insertvalue { i64, ptr } %t286, ptr %t285, 1
  store { i64, ptr } %t287, ptr %l82, !tbaa !27
  br label %bb42
bb42:
  %t289 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t289, ptr %lp6
  %t290 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t291 = load ptr, ptr %lp6
  store { i64, ptr } %t290, ptr %t291, !tbaa !27
  %t292 = load ptr, ptr %lp6
  %t293 = load { i64, ptr }, ptr %t292, !tbaa !27
  %t295 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v2, ptr %s0, { i64, ptr } %t293, { i64, ptr } { i64 6, ptr @.d94 })
  store i1 %t295, ptr %l90
  br label %bb43
bb43:
  %t296 = load i1, ptr %l90, !tbaa !21
  br i1 %t296, label %bb44, label %bb45
bb44:
  %t297 = load ptr, ptr %lp6
  %t298 = load { i64, ptr }, ptr %t297, !tbaa !27
  %t300 = extractvalue { i64, ptr } %t298, 0
  %t302 = sub i64 %t300, 6
  store i64 %t302, ptr %l94, !tbaa !24
  %t303 = load ptr, ptr %lp6
  %t304 = load { i64, ptr }, ptr %t303, !tbaa !27
  %t305 = extractvalue { i64, ptr } %t304, 0
  store i64 %t305, ptr %l95, !tbaa !24
  %t306 = icmp sge i64 0, 0
  br i1 %t306, label %bb46, label %bb47
bb45:
  %t308 = load ptr, ptr %lp6
  %t309 = load { i64, ptr }, ptr %t308, !tbaa !27
  store { i64, ptr } %t309, ptr %l91, !tbaa !27
  br label %bb52
bb46:
  %t311 = load i64, ptr %l94, !tbaa !24
  %t312 = icmp sle i64 0, %t311
  br i1 %t312, label %bb48, label %bb49
bb47:
  call void @__olang_check_failed(ptr @olang_loc_281d6687dd267da4_55752feab9766ac8)
  unreachable
bb48:
  %t314 = load i64, ptr %l94, !tbaa !24
  %t315 = load i64, ptr %l95, !tbaa !24
  %t316 = icmp sle i64 %t314, %t315
  br i1 %t316, label %bb50, label %bb51
bb49:
  call void @__olang_check_failed(ptr @olang_loc_281d6687dd267da4_55752feab9766ac8)
  unreachable
bb50:
  %t318 = load ptr, ptr %lp6
  %t319 = getelementptr { i64, ptr }, ptr %t318, i32 0, i32 1
  %t320 = load ptr, ptr %t319, !tbaa !27
  %t321 = load i64, ptr %l94, !tbaa !24
  %t322 = getelementptr i8, ptr %t320, i64 0
  %t323 = sub i64 %t321, 0
  %t324 = insertvalue { i64, ptr } undef, i64 %t323, 0
  %t325 = insertvalue { i64, ptr } %t324, ptr %t322, 1
  %t327 = extractvalue { i64, ptr } %t325, 1
  %t328 = extractvalue { i64, ptr } %t325, 0
  %t329 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t328)
  call void @olang_textcopy(ptr %t329, ptr %t327, i64 %t328)
  %t330 = insertvalue { i64, ptr } undef, i64 %t328, 0
  %t331 = insertvalue { i64, ptr } %t330, ptr %t329, 1
  store { i64, ptr } %t331, ptr %l91, !tbaa !27
  br label %bb52
bb51:
  call void @__olang_check_failed(ptr @olang_loc_281d6687dd267da4_55752feab9766ac8)
  unreachable
bb52:
  call void @__olang_scope_close(ptr %s0)
  %t333 = load { i64, ptr }, ptr %l91, !tbaa !27
  store { i64, ptr } %t333, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2etaken(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l12 = alloca ptr
  %l16 = alloca i64
  %l23 = alloca i64
  %l28 = alloca i64
  %l32 = alloca i64
  %l34 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i64 1, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/load:Loader", ptr %t6, i32 0, i32 5
  %t9 = load i64, ptr %l1, !tbaa !24
  %t12 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t8, i64 %t9)
  store ptr %t12, ptr %l12
  br label %bb4
bb4:
  %t13 = load ptr, ptr %l12, !tbaa !29
  store ptr %t13, ptr %l3, !tbaa !29
  %t14 = load ptr, ptr %l3, !tbaa !29
  %t16 = getelementptr %"compiler/load:Module", ptr %t14, i32 0, i32 20
  %t17 = load i64, ptr %l2, !tbaa !24
  %t20 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t16, i64 %t17)
  store i64 %t20, ptr %l16
  br label %bb5
bb5:
  %t21 = load i64, ptr %l16, !tbaa !24
  store i64 %t21, ptr %l4, !tbaa !24
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i64, ptr %l1, !tbaa !24
  %t24 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2edecide(ptr %v0, ptr %t22, i64 %t23, i64 %t24)
  br label %bb6
bb6:
  %t28 = load ptr, ptr %l3, !tbaa !29
  %t30 = getelementptr %"compiler/load:Module", ptr %t28, i32 0, i32 16
  %t31 = load i64, ptr %l4, !tbaa !24
  %t34 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t30, i64 %t31)
  store i64 %t34, ptr %l23
  br label %bb7
bb7:
  %t35 = load i64, ptr %l23, !tbaa !24
  store i64 %t35, ptr %l5, !tbaa !24
  %t36 = load i64, ptr %l5, !tbaa !24
  %t37 = load i64, ptr @G_2ecompiler_2fload_2ePending, !tbaa !24
  %t40 = icmp eq i64 %t36, %t37
  br i1 %t40, label %bb8, label %bb9
bb8:
  store i64 -1, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t43 = load i64, ptr %l5, !tbaa !24
  store i64 %t43, ptr %l28, !tbaa !24
  %t44 = load ptr, ptr %l3, !tbaa !29
  %t46 = getelementptr %"compiler/load:Module", ptr %t44, i32 0, i32 21
  %t47 = load i64, ptr %l2, !tbaa !24
  %t50 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t46, i64 %t47)
  store i64 %t50, ptr %l32
  br label %bb11
bb11:
  %t51 = load i64, ptr %l28, !tbaa !24
  %t52 = load i64, ptr %l32, !tbaa !24
  %t53 = icmp eq i64 %t51, %t52
  br i1 %t53, label %bb12, label %bb13
bb12:
  store i64 1, ptr %l34, !tbaa !24
  br label %bb14
bb13:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb14
bb14:
  %t55 = load i64, ptr %l34, !tbaa !24
  store i64 %t55, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2etopIf(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i64
  %l23 = alloca i64
  %l26 = alloca { i64, ptr }
  %l39 = alloca ptr
  %l42 = alloca i64
  %l49 = alloca i64
  %l65 = alloca i32
  %l74 = alloca i64
  %l83 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %l114 = alloca i32
  %l126 = alloca i64
  %s1 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/load:Module", ptr %t1, i32 0, i32 7
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_f33836f530001f0a_3e5ddd8b9e2e63ae)
  unreachable
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t10 = getelementptr %"compiler/load:Module", ptr %t8, i32 0, i32 7
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t14 = getelementptr %"compiler/scan:Tokens", ptr %t11, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  store { i64, ptr } %t15, ptr %l5, !tbaa !27
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t19 = getelementptr %"compiler/load:Module", ptr %t17, i32 0, i32 14
  %t21 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2eLen_3cI32_3e(ptr %v1, ptr %t19)
  store i64 %t21, ptr %l23
  br label %bb4
bb4:
  %t22 = load i64, ptr %l23, !tbaa !24
  store i64 %t22, ptr %l6, !tbaa !24
  %t23 = load ptr, ptr %l1, !tbaa !29
  %t25 = getelementptr %"compiler/load:Module", ptr %t23, i32 0, i32 14
  %t26 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t26, ptr %l26, !tbaa !27
  %t27 = load i64, ptr %l2, !tbaa !24
  %t29 = add i64 %t27, 1
  %t31 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr %"compiler/token:Token", ptr %t32, i64 %t29
  %t34 = getelementptr %"compiler/token:Token", ptr %t33, i32 0, i32 2
  %t35 = load i32, ptr %t34, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2ePush_3cI32_3e(ptr %v1, ptr %t25, i32 %t35)
  br label %bb5
bb5:
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr %"compiler/load:Module", ptr %t38, i32 0, i32 15
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t40, i64 %a4)
  br label %bb6
bb6:
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t46 = getelementptr %"compiler/load:Module", ptr %t44, i32 0, i32 16
  %t47 = load i64, ptr @G_2ecompiler_2fload_2eNotYet, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t46, i64 %t47)
  br label %bb7
bb7:
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t52 = getelementptr %"compiler/load:Module", ptr %t50, i32 0, i32 17
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %v1, ptr %t52, i1 false)
  br label %bb8
bb8:
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = getelementptr %"compiler/load:Module", ptr %t54, i32 0, i32 18
  store ptr %t56, ptr %l39, !tbaa !29
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr %"compiler/load:Module", ptr %t57, i32 0, i32 19
  %t61 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t59)
  store i64 %t61, ptr %l42
  br label %bb9
bb9:
  %t62 = load ptr, ptr %l39, !tbaa !29
  %t63 = load i64, ptr %l42, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t62, i64 %t63)
  br label %bb10
bb10:
  %t64 = load i64, ptr %l2, !tbaa !24
  store i64 %t64, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s1
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load ptr, ptr %l1, !tbaa !29
  %t68 = load i64, ptr %l7, !tbaa !24
  %t70 = add i64 %t68, 1
  %t71 = load i64, ptr %l3, !tbaa !24
  %t76 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2econdEnd(ptr %v0, ptr %v1, ptr %t66, ptr %t67, i64 %t70, i64 %t71)
  store i64 %t76, ptr %l49
  br label %bb12
bb12:
  %t77 = load i64, ptr %l49, !tbaa !24
  store i64 %t77, ptr %l9, !tbaa !24
  %t78 = load i64, ptr %l9, !tbaa !24
  %t80 = icmp slt i64 %t78, 0
  br i1 %t80, label %bb13, label %bb14
bb13:
  %t82 = load i64, ptr %l7, !tbaa !24
  %t84 = add i64 %t82, 1
  call void @__olang_scope_close(ptr %s1)
  store i64 %t84, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t86 = load ptr, ptr %l1, !tbaa !29
  %t88 = getelementptr %"compiler/load:Module", ptr %t86, i32 0, i32 19
  %t89 = load i64, ptr %l7, !tbaa !24
  %t91 = add i64 %t89, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t88, i64 %t91)
  br label %bb16
bb16:
  %t94 = load ptr, ptr %l1, !tbaa !29
  %t96 = getelementptr %"compiler/load:Module", ptr %t94, i32 0, i32 7
  %t97 = load ptr, ptr %t96, !tbaa !29
  %t99 = icmp eq ptr %t97, null
  br i1 %t99, label %bb17, label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_e83704c0903811_d990170ae1d54355)
  unreachable
bb18:
  br label %bb19
bb19:
  %t101 = load ptr, ptr %l1, !tbaa !29
  %t103 = getelementptr %"compiler/load:Module", ptr %t101, i32 0, i32 7
  %t104 = load ptr, ptr %t103, !tbaa !29
  %t105 = load i64, ptr %l9, !tbaa !24
  %t107 = trunc i64 %t105 to i32
  %t110 = call i32 @compiler_2fscan_2ecompiler_2fscan_3aTokens_2eMatch(ptr %v1, ptr %t104, i32 %t107)
  store i32 %t110, ptr %l65
  br label %bb20
bb20:
  %t111 = load i32, ptr %l65, !tbaa !23
  %t112 = sext i32 %t111 to i64
  store i64 %t112, ptr %l10, !tbaa !24
  %t114 = load i64, ptr %l10, !tbaa !24
  %t116 = icmp slt i64 %t114, 0
  br i1 %t116, label %bb21, label %bb22
bb21:
  %t118 = load i64, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  store i64 %t118, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load ptr, ptr %l1, !tbaa !29
  %t122 = load i64, ptr %l6, !tbaa !24
  %t123 = load i64, ptr %l8, !tbaa !24
  %t128 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2ebranch(ptr %v0, ptr %v1, ptr %t120, ptr %t121, i64 %t122, i64 %t123)
  store i64 %t128, ptr %l74
  br label %bb24
bb24:
  %t129 = load i64, ptr %l74, !tbaa !24
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t131 = load ptr, ptr %l1, !tbaa !29
  %t132 = load i64, ptr %l9, !tbaa !24
  %t134 = add i64 %t132, 1
  %t135 = load i64, ptr %l10, !tbaa !24
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2eregion(ptr %v0, ptr %v1, ptr %t130, ptr %t131, i64 %t134, i64 %t135, i64 %t129)
  br label %bb25
bb25:
  %t142 = load i64, ptr %l10, !tbaa !24
  %t144 = add i64 %t142, 1
  store i64 %t144, ptr %l7, !tbaa !24
  %t146 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t146, ptr %l83, !tbaa !27
  %t147 = load i64, ptr %l7, !tbaa !24
  %t149 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !27
  %t151 = getelementptr %"compiler/token:Token", ptr %t150, i64 %t147
  %t152 = getelementptr %"compiler/token:Token", ptr %t151, i32 0, i32 0
  %t153 = load i32, ptr %t152
  %t155 = trunc i64 10 to i32
  %t156 = icmp eq i32 %t153, %t155
  %t158 = xor i1 %t156, true
  br i1 %t158, label %bb26, label %bb27
bb26:
  %t160 = load i64, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  store i64 %t160, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t162 = load i64, ptr %l8, !tbaa !24
  %t164 = add i64 %t162, 1
  store i64 %t164, ptr %l8, !tbaa !24
  %t166 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t166, ptr %l91, !tbaa !27
  %t167 = load i64, ptr %l7, !tbaa !24
  %t169 = add i64 %t167, 1
  %t171 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t172 = load ptr, ptr %t171, !tbaa !27
  %t173 = getelementptr %"compiler/token:Token", ptr %t172, i64 %t169
  %t174 = getelementptr %"compiler/token:Token", ptr %t173, i32 0, i32 0
  %t175 = load i32, ptr %t174
  %t177 = trunc i64 9 to i32
  %t178 = icmp eq i32 %t175, %t177
  br i1 %t178, label %bb29, label %bb30
bb29:
  %t180 = load i64, ptr %l7, !tbaa !24
  %t182 = add i64 %t180, 1
  store i64 %t182, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb45
bb30:
  br label %bb31
bb31:
  %t184 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t184, ptr %l98, !tbaa !27
  %t185 = load i64, ptr %l7, !tbaa !24
  %t187 = add i64 %t185, 1
  %t189 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !27
  %t191 = getelementptr %"compiler/token:Token", ptr %t190, i64 %t187
  %t192 = getelementptr %"compiler/token:Token", ptr %t191, i32 0, i32 0
  %t193 = load i32, ptr %t192
  %t195 = trunc i64 92 to i32
  %t196 = icmp eq i32 %t193, %t195
  %t198 = xor i1 %t196, true
  br i1 %t198, label %bb32, label %bb33
bb32:
  %t200 = load i64, ptr %l7, !tbaa !24
  %t202 = add i64 %t200, 1
  call void @__olang_scope_close(ptr %s1)
  store i64 %t202, ptr %rv
  br label %ret
bb33:
  br label %bb34
bb34:
  %t204 = load ptr, ptr %l1, !tbaa !29
  %t206 = getelementptr %"compiler/load:Module", ptr %t204, i32 0, i32 7
  %t207 = load ptr, ptr %t206, !tbaa !29
  %t209 = icmp eq ptr %t207, null
  br i1 %t209, label %bb35, label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_766ae0e3e1f9b91c_7764041251e8a940)
  unreachable
bb36:
  br label %bb37
bb37:
  %t211 = load ptr, ptr %l1, !tbaa !29
  %t213 = getelementptr %"compiler/load:Module", ptr %t211, i32 0, i32 7
  %t214 = load ptr, ptr %t213, !tbaa !29
  %t215 = load i64, ptr %l7, !tbaa !24
  %t217 = add i64 %t215, 1
  %t219 = trunc i64 %t217 to i32
  %t222 = call i32 @compiler_2fscan_2ecompiler_2fscan_3aTokens_2eMatch(ptr %v1, ptr %t214, i32 %t219)
  store i32 %t222, ptr %l114
  br label %bb38
bb38:
  %t223 = load i32, ptr %l114, !tbaa !23
  %t224 = sext i32 %t223 to i64
  store i64 %t224, ptr %l12, !tbaa !24
  %t226 = load i64, ptr %l12, !tbaa !24
  %t228 = icmp slt i64 %t226, 0
  br i1 %t228, label %bb39, label %bb40
bb39:
  %t230 = load i64, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  store i64 %t230, ptr %rv
  br label %ret
bb40:
  br label %bb41
bb41:
  %t232 = load ptr, ptr %l1, !tbaa !29
  %t234 = getelementptr %"compiler/load:Module", ptr %t232, i32 0, i32 17
  %t235 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eSetAt_3cBool_3e(ptr %v1, ptr %t234, i64 %t235, i1 true)
  br label %bb42
bb42:
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t239 = load ptr, ptr %l1, !tbaa !29
  %t240 = load i64, ptr %l6, !tbaa !24
  %t241 = load i64, ptr %l8, !tbaa !24
  %t246 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2ebranch(ptr %v0, ptr %v1, ptr %t238, ptr %t239, i64 %t240, i64 %t241)
  store i64 %t246, ptr %l126
  br label %bb43
bb43:
  %t247 = load i64, ptr %l126, !tbaa !24
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t249 = load ptr, ptr %l1, !tbaa !29
  %t250 = load i64, ptr %l7, !tbaa !24
  %t252 = add i64 %t250, 2
  %t253 = load i64, ptr %l12, !tbaa !24
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2eregion(ptr %v0, ptr %v1, ptr %t248, ptr %t249, i64 %t252, i64 %t253, i64 %t247)
  br label %bb44
bb44:
  %t260 = load i64, ptr %l12, !tbaa !24
  %t262 = add i64 %t260, 1
  call void @__olang_scope_close(ptr %s1)
  store i64 %t262, ptr %rv
  br label %ret
bb45:
  br label %bb11
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2fload_2efirstElems(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l16 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca i64
  %l35 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca i64
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb3:
  br label %bb4
bb4:
  %t15 = load i64, ptr %l4, !tbaa !24
  store i64 %t15, ptr %l6, !tbaa !24
  %t17 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t17, ptr %l16, !tbaa !27
  %t18 = load i64, ptr %l4, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr i8, ptr %t21, i64 %t18
  %t23 = load i8, ptr %t22, !tbaa !32
  %t27 = icmp eq i8 %t23, 47
  br i1 %t27, label %bb5, label %bb6
bb5:
  %t29 = load i64, ptr %l2, !tbaa !24
  %t31 = add i64 %t29, 1
  store i64 %t31, ptr %l2, !tbaa !24
  %t33 = load i64, ptr %l2, !tbaa !24
  %t37 = icmp eq i64 %t33, %a1
  br i1 %t37, label %bb7, label %bb8
bb6:
  br label %bb16
bb7:
  %t39 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t39, ptr %l26, !tbaa !27
  %t40 = load i64, ptr %l6, !tbaa !24
  store i64 %t40, ptr %l27, !tbaa !24
  %t41 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t41, 0
  store i64 %t42, ptr %l28, !tbaa !24
  %t43 = icmp sge i64 0, 0
  br i1 %t43, label %bb9, label %bb10
bb8:
  br label %bb15
bb9:
  %t45 = load i64, ptr %l27, !tbaa !24
  %t46 = icmp sle i64 0, %t45
  br i1 %t46, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_4f7ff751eb66f618_e3b0711c9f747694)
  unreachable
bb11:
  %t48 = load i64, ptr %l27, !tbaa !24
  %t49 = load i64, ptr %l28, !tbaa !24
  %t50 = icmp sle i64 %t48, %t49
  br i1 %t50, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_4f7ff751eb66f618_e3b0711c9f747694)
  unreachable
bb13:
  %t52 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = load i64, ptr %l27, !tbaa !24
  %t55 = getelementptr i8, ptr %t53, i64 0
  %t56 = sub i64 %t54, 0
  %t57 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t55, 1
  call void @__olang_scope_close(ptr %s2)
  store { i64, ptr } %t58, ptr %rv
  br label %ret
bb14:
  call void @__olang_check_failed(ptr @olang_loc_4f7ff751eb66f618_e3b0711c9f747694)
  unreachable
bb15:
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  %t60 = load i64, ptr %l4, !tbaa !24
  %t62 = add i64 %t60, 1
  store i64 %t62, ptr %l4, !tbaa !24
  br label %bb1
bb18:
  %t64 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t64, ptr %l35, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t65, 0
  store i64 %t68, ptr %l38, !tbaa !24
  %t69 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t69, 0
  store i64 %t70, ptr %l39, !tbaa !24
  %t71 = icmp sge i64 0, 0
  br i1 %t71, label %bb19, label %bb20
bb19:
  %t73 = load i64, ptr %l38, !tbaa !24
  %t74 = icmp sle i64 0, %t73
  br i1 %t74, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_4fa7c22e4d470d75_c9a9030dc047401)
  unreachable
bb21:
  %t76 = load i64, ptr %l38, !tbaa !24
  %t77 = load i64, ptr %l39, !tbaa !24
  %t78 = icmp sle i64 %t76, %t77
  br i1 %t78, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_4fa7c22e4d470d75_c9a9030dc047401)
  unreachable
bb23:
  %t80 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = load i64, ptr %l38, !tbaa !24
  %t83 = getelementptr i8, ptr %t81, i64 0
  %t84 = sub i64 %t82, 0
  %t85 = insertvalue { i64, ptr } undef, i64 %t84, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t83, 1
  store { i64, ptr } %t86, ptr %rv
  br label %ret
bb24:
  call void @__olang_check_failed(ptr @olang_loc_4fa7c22e4d470d75_c9a9030dc047401)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fload_2egit(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca %"std/os:Output"
  %l3 = alloca %"std/os:Output"
  %l5 = alloca { i64, ptr }
  %l7 = alloca %"std/os:Output"
  %l8 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store { i64, ptr } { i64 0, ptr @.d95 }, ptr %l5, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t6 = call { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %v1, ptr %s0, ptr %v0, ptr %s0, { i64, ptr } %a1, { i64, ptr } %t4, i1 true, { i64, ptr } %a0)
  %t7 = extractvalue { i32, %"std/os:Output" } %t6, 1
  %t8 = extractvalue { i32, %"std/os:Output" } %t6, 0
  store i32 %t8, ptr %l8
  %t9 = icmp ne i32 %t8, 0
  br i1 %t9, label %bb2, label %ok.10
ok.10:
  store %"std/os:Output" %t7, ptr %l7
  br label %bb1
bb1:
  %t11 = load %"std/os:Output", ptr %l7
  store %"std/os:Output" %t11, ptr %l3
  br label %bb6
bb2:
  %t12 = load i32, ptr %l8, !tbaa !23
  %t13 = ashr i32 %t12, 16
  %t15 = icmp eq i32 %t13, 1
  br i1 %t15, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_e1450843369e7a83_4c1990cf53114c27)
  unreachable
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb6:
  %t18 = load %"std/os:Output", ptr %l3
  store %"std/os:Output" %t18, ptr %l2
  %t19 = getelementptr %"std/os:Output", ptr %l2, i32 0, i32 0
  %t20 = load i32, ptr %t19, !tbaa !23
  %t22 = icmp eq i32 %t20, 0
  call void @__olang_scope_close(ptr %s0)
  store i1 %t22, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fload_2ekey(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l1, !tbaa !27
  %t2 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t3 = load ptr, ptr %t2, !tbaa !27
  %t4 = getelementptr { i64, ptr }, ptr %t3, i64 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !37
  %t6 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t6, ptr %l3, !tbaa !27
  %t7 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !27
  %t9 = getelementptr { i64, ptr }, ptr %t8, i64 1
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !37
  %t11 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t11, ptr %l5, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %t13, i64 2
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !37
  %t17 = extractvalue { i64, ptr } %t5, 1
  %t18 = extractvalue { i64, ptr } %t5, 0
  %t19 = extractvalue { i64, ptr } { i64 1, ptr @.d96 }, 1
  %t20 = extractvalue { i64, ptr } { i64 1, ptr @.d96 }, 0
  %t21 = add i64 %t18, %t20
  %t23 = extractvalue { i64, ptr } %t10, 1
  %t24 = extractvalue { i64, ptr } %t10, 0
  %t25 = add i64 %t21, %t24
  %t26 = extractvalue { i64, ptr } { i64 1, ptr @.d97 }, 1
  %t27 = extractvalue { i64, ptr } { i64 1, ptr @.d97 }, 0
  %t28 = add i64 %t25, %t27
  %t30 = extractvalue { i64, ptr } %t15, 1
  %t31 = extractvalue { i64, ptr } %t15, 0
  %t32 = add i64 %t28, %t31
  %t33 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t32)
  call void @olang_textcopy(ptr %t33, ptr %t17, i64 %t18)
  %t34 = getelementptr i8, ptr %t33, i64 %t18
  call void @olang_textcopy(ptr %t34, ptr %t19, i64 %t20)
  %t35 = getelementptr i8, ptr %t34, i64 %t20
  call void @olang_textcopy(ptr %t35, ptr %t23, i64 %t24)
  %t36 = getelementptr i8, ptr %t35, i64 %t24
  call void @olang_textcopy(ptr %t36, ptr %t26, i64 %t27)
  %t37 = getelementptr i8, ptr %t36, i64 %t27
  call void @olang_textcopy(ptr %t37, ptr %t30, i64 %t31)
  %t38 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t33, 1
  store { i64, ptr } %t39, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fload_2emoduleDir(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 1, ptr @.d98 })
  %t4 = extractvalue { i32, i64 } %t3, 1
  %t5 = extractvalue { i32, i64 } %t3, 0
  store i32 %t5, ptr %l5
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store i64 %t4, ptr %l4
  br label %bb1
bb1:
  %t8 = load i64, ptr %l4, !tbaa !24
  store i64 %t8, ptr %l2, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store { i64, ptr } { i64 1, ptr @.d99 }, ptr %l6, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t9, ptr %l7, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t10, 0
  store i64 %t11, ptr %l8, !tbaa !24
  %t12 = load i64, ptr %l8, !tbaa !24
  %t13 = mul i64 %t12, 1
  %t14 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t13)
  %t15 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l9, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = load i64, ptr %l8, !tbaa !24
  %t22 = mul i64 %t21, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t18, ptr %t20, i64 %t22, i1 false)
  %t23 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t23, ptr %l7, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t24 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t24, ptr %rv
  br label %ret
bb4:
  %t25 = load i64, ptr %l2, !tbaa !24
  store i64 %t25, ptr %l1, !tbaa !24
  %t26 = load i64, ptr %l1, !tbaa !24
  %t28 = icmp eq i64 %t26, 0
  br i1 %t28, label %bb5, label %bb6
bb5:
  store { i64, ptr } { i64 1, ptr @.d100 }, ptr %l12, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t30, ptr %l13, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l14, !tbaa !24
  %t33 = load i64, ptr %l14, !tbaa !24
  %t34 = mul i64 %t33, 1
  %t35 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t34)
  %t36 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t35, 1
  store { i64, ptr } %t37, ptr %l15, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = load i64, ptr %l14, !tbaa !24
  %t43 = mul i64 %t42, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t39, ptr %t41, i64 %t43, i1 false)
  %t44 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t44, ptr %l13, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t45 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t45, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t46 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t46, ptr %l16, !tbaa !27
  %t47 = load i64, ptr %l1, !tbaa !24
  store i64 %t47, ptr %l17, !tbaa !24
  %t48 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t48, 0
  store i64 %t49, ptr %l18, !tbaa !24
  %t50 = icmp sge i64 0, 0
  br i1 %t50, label %bb8, label %bb9
bb8:
  %t52 = load i64, ptr %l17, !tbaa !24
  %t53 = icmp sle i64 0, %t52
  br i1 %t53, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_9a4e1e4457f2709_31a5a56895743715)
  unreachable
bb10:
  %t55 = load i64, ptr %l17, !tbaa !24
  %t56 = load i64, ptr %l18, !tbaa !24
  %t57 = icmp sle i64 %t55, %t56
  br i1 %t57, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_9a4e1e4457f2709_31a5a56895743715)
  unreachable
bb12:
  %t59 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = load i64, ptr %l17, !tbaa !24
  %t62 = getelementptr i8, ptr %t60, i64 0
  %t63 = sub i64 %t61, 0
  %t64 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t62, 1
  %t67 = extractvalue { i64, ptr } %t65, 1
  %t68 = extractvalue { i64, ptr } %t65, 0
  %t69 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t68)
  call void @olang_textcopy(ptr %t69, ptr %t67, i64 %t68)
  %t70 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t69, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t71, ptr %rv
  br label %ret
bb13:
  call void @__olang_check_failed(ptr @olang_loc_9a4e1e4457f2709_31a5a56895743715)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fload_2erelativeIdentity(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l21 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 1, ptr @.d101 })
  %t4 = extractvalue { i32, i64 } %t3, 1
  %t5 = extractvalue { i32, i64 } %t3, 0
  store i32 %t5, ptr %l6
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store i64 %t4, ptr %l5
  br label %bb1
bb1:
  %t8 = load i64, ptr %l5, !tbaa !24
  store i64 %t8, ptr %l3, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 -1, ptr %l3, !tbaa !24
  br label %bb4
bb4:
  %t9 = load i64, ptr %l3, !tbaa !24
  store i64 %t9, ptr %l2, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t12 = icmp slt i64 %t10, 0
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t16 = call { i64, ptr } @compiler_2fload_2eNormalize(ptr %v1, ptr %v2, { i64, ptr } %t14)
  store { i64, ptr } %t16, ptr %l10
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t17 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t17, ptr %rv
  br label %ret
bb8:
  %t18 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t18, ptr %l11, !tbaa !27
  %t19 = load i64, ptr %l2, !tbaa !24
  store i64 %t19, ptr %l12, !tbaa !24
  %t20 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t20, 0
  store i64 %t21, ptr %l13, !tbaa !24
  %t22 = icmp sge i64 0, 0
  br i1 %t22, label %bb9, label %bb10
bb9:
  %t24 = load i64, ptr %l12, !tbaa !24
  %t25 = icmp sle i64 0, %t24
  br i1 %t25, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_738c5ab5e9ce8338_c044a83eb6fe7eb4)
  unreachable
bb11:
  %t27 = load i64, ptr %l12, !tbaa !24
  %t28 = load i64, ptr %l13, !tbaa !24
  %t29 = icmp sle i64 %t27, %t28
  br i1 %t29, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_738c5ab5e9ce8338_c044a83eb6fe7eb4)
  unreachable
bb13:
  %t31 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l12, !tbaa !24
  %t34 = getelementptr i8, ptr %t32, i64 0
  %t35 = sub i64 %t33, 0
  %t36 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t34, 1
  %t38 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t37, 1
  %t41 = extractvalue { i64, ptr } %t37, 0
  %t42 = extractvalue { i64, ptr } { i64 1, ptr @.d102 }, 1
  %t43 = extractvalue { i64, ptr } { i64 1, ptr @.d102 }, 0
  %t44 = add i64 %t41, %t43
  %t46 = extractvalue { i64, ptr } %t38, 1
  %t47 = extractvalue { i64, ptr } %t38, 0
  %t48 = add i64 %t44, %t47
  %t49 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t48)
  call void @olang_textcopy(ptr %t49, ptr %t40, i64 %t41)
  %t50 = getelementptr i8, ptr %t49, i64 %t41
  call void @olang_textcopy(ptr %t50, ptr %t42, i64 %t43)
  %t51 = getelementptr i8, ptr %t50, i64 %t43
  call void @olang_textcopy(ptr %t51, ptr %t46, i64 %t47)
  %t52 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t49, 1
  %t55 = extractvalue { i64, ptr } %t53, 0
  %t56 = extractvalue { i64, ptr } %t53, 1
  %t57 = mul i64 %t55, 1
  %t58 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t57)
  call void @llvm.memcpy.p0.p0.i64(ptr %t58, ptr %t56, i64 %t57, i1 false)
  %t59 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t58, 1
  %t62 = call { i64, ptr } @compiler_2fload_2eNormalize(ptr %v2, ptr %v2, { i64, ptr } %t60)
  store { i64, ptr } %t62, ptr %l21
  br label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_738c5ab5e9ce8338_c044a83eb6fe7eb4)
  unreachable
bb15:
  call void @__olang_scope_close(ptr %s0)
  %t63 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t63, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fload_2erules(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca %"compiler/diag:Said"
  %l8 = alloca %"std/prelude/text:StringBuilder"
  %l11 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l13 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i32
  %l26 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l8
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l8
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = getelementptr %"compiler/load:Loader", ptr %a0, i32 0, i32 4
  %t6 = load ptr, ptr %t5, !tbaa !29
  %t8 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAllSaid(ptr %v0, ptr %s1, ptr %t6)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %l11
  br label %bb2
bb2:
  %t9 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  %t10 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t9, ptr %t10
  store ptr %t10, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t13 = load i64, ptr %l3, !tbaa !24
  %t16 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3aSaid_3e_2eRunFrom_3ccompiler_2fdiag_3aSaid_3e(ptr %s1, ptr %t12, i64 %t13)
  %t17 = extractvalue { i32, { i64, ptr } } %t16, 1
  %t18 = extractvalue { i32, { i64, ptr } } %t16, 0
  store i32 %t18, ptr %l17
  %t19 = icmp ne i32 %t18, 0
  br i1 %t19, label %bb5, label %ok.20
ok.20:
  store { i64, ptr } %t17, ptr %l16
  br label %bb4
bb4:
  %t21 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t21, ptr %l13, !tbaa !27
  br label %bb9
bb5:
  %t22 = load i32, ptr %l17, !tbaa !23
  %t23 = ashr i32 %t22, 16
  %t25 = icmp eq i32 %t23, 1
  br i1 %t25, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_79b6b74230fc653e_a4ca48bccf53fe5a)
  unreachable
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb9:
  %t27 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t27, ptr %l4, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  store i64 %t30, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t32 = load i64, ptr %l6, !tbaa !24
  %t33 = load i64, ptr %l5, !tbaa !24
  %t36 = icmp slt i64 %t32, %t33
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb12:
  br label %bb13
bb13:
  %t40 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t40, ptr %l26, !tbaa !27
  %t41 = load i64, ptr %l6, !tbaa !24
  %t43 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr %"compiler/diag:Said", ptr %t44, i64 %t41
  %t46 = load %"compiler/diag:Said", ptr %t45
  store %"compiler/diag:Said" %t46, ptr %l7
  %t48 = getelementptr %"compiler/diag:Said", ptr %l7, i32 0, i32 0
  %t49 = load { i64, ptr }, ptr %t48, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t49, 1
  %t52 = extractvalue { i64, ptr } %t49, 0
  %t53 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t52)
  call void @olang_textcopy(ptr %t53, ptr %t51, i64 %t52)
  %t54 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t53, 1
  %t57 = extractvalue { i64, ptr } %t55, 0
  %t58 = extractvalue { i64, ptr } %t55, 1
  %t59 = mul i64 %t57, 1
  %t60 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t59)
  call void @llvm.memcpy.p0.p0.i64(ptr %t60, ptr %t58, i64 %t59, i1 false)
  %t61 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t60, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l1, { i64, ptr } %t62)
  br label %bb14
bb14:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 32)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb16:
  %t66 = load i64, ptr %l6, !tbaa !24
  %t68 = add i64 %t66, 1
  store i64 %t68, ptr %l6, !tbaa !24
  br label %bb10
bb17:
  %t70 = load i64, ptr %l3, !tbaa !24
  %t71 = load i64, ptr %l5, !tbaa !24
  %t74 = add i64 %t70, %t71
  store i64 %t74, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  br label %bb3
bb19:
  call void @__olang_scope_close(ptr %s1)
  %t77 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t77, ptr %l40
  br label %bb20
bb20:
  %t78 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t78, ptr %l41, !tbaa !27
  %t79 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t79, 0
  store i64 %t80, ptr %l42, !tbaa !24
  %t81 = load i64, ptr %l42, !tbaa !24
  %t82 = mul i64 %t81, 1
  %t83 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t82)
  %t84 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t83, 1
  store { i64, ptr } %t85, ptr %l43, !tbaa !27
  %t86 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !27
  %t88 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !27
  %t90 = load i64, ptr %l42, !tbaa !24
  %t91 = mul i64 %t90, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t87, ptr %t89, i64 %t91, i1 false)
  %t92 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t92, ptr %l41, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t93 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t93, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/load:Loader" @compiler_2fload_2etestLoader(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %lp1 = alloca ptr
  %l2 = alloca %"compiler/cond:Consts"
  %l4 = alloca ptr
  %l9 = alloca %"compiler/fetch:Fetcher"
  %l10 = alloca ptr
  %l11 = alloca %"compiler/source:Names"
  %l12 = alloca ptr
  %l13 = alloca %"compiler/diag:Diagnostics"
  %l15 = alloca %"compiler/load:Loader"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/load:Loader"
  %t35 = alloca %"compiler/diag:Diagnostics", align 8
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"compiler/cond:Consts" @compiler_2fcond_3aConsts_2ector(ptr %v1)
  store %"compiler/cond:Consts" %t1, ptr %l2
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 56, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"compiler/cond:Consts", ptr %l2
  %t4 = load ptr, ptr %lp1
  store %"compiler/cond:Consts" %t3, ptr %t4
  %t5 = load ptr, ptr %lp1
  call void @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eBuiltins(ptr %v1, ptr %s0, ptr %s0, ptr %s0, ptr %t5, { i64, ptr } { i64 5, ptr @.d103 }, { i64, ptr } { i64 6, ptr @.d104 }, { i64, ptr } { i64 6, ptr @.d105 }, i64 128, i64 0, i1 false, i1 false, i1 false)
  br label %bb2
bb2:
  %t7 = load ptr, ptr %lp1
  store ptr %t7, ptr %l4, !tbaa !29
  %t8 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 1
  %t12 = extractvalue { i64, ptr } %t9, 0
  %t13 = extractvalue { i64, ptr } { i64 6, ptr @.d106 }, 1
  %t14 = extractvalue { i64, ptr } { i64 6, ptr @.d106 }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t11, i64 %t12)
  %t17 = getelementptr i8, ptr %t16, i64 %t12
  call void @olang_textcopy(ptr %t17, ptr %t13, i64 %t14)
  %t18 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t16, 1
  %t21 = extractvalue { i64, ptr } %t19, 0
  %t22 = extractvalue { i64, ptr } %t19, 1
  %t23 = mul i64 %t21, 1
  %t24 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t23)
  call void @llvm.memcpy.p0.p0.i64(ptr %t24, ptr %t22, i64 %t23, i1 false)
  %t25 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t24, 1
  %t29 = call %"compiler/fetch:Fetcher" @compiler_2ffetch_3aFetcher_2ector(ptr %v0, ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t8, { i64, ptr } %t26, { i64, ptr } { i64 16, ptr @.d107 }, i1 false, i1 true)
  store %"compiler/fetch:Fetcher" %t29, ptr %l9
  br label %bb3
bb3:
  %t30 = load %"compiler/fetch:Fetcher", ptr %l9
  %t31 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 88, i64 8)
  store %"compiler/fetch:Fetcher" %t30, ptr %t31
  store ptr %t31, ptr %l10, !tbaa !29
  %t32 = call %"compiler/source:Names" @compiler_2fsource_3aNames_2ector(ptr %v1)
  store %"compiler/source:Names" %t32, ptr %l11
  br label %bb4
bb4:
  %t33 = load %"compiler/source:Names", ptr %l11
  %t34 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store %"compiler/source:Names" %t33, ptr %t34
  store ptr %t34, ptr %l12, !tbaa !29
  call void @compiler_2fdiag_3aDiagnostics_2ector(ptr %t35, ptr %v1, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l13, ptr %t35, i64 200, i1 false)
  br label %bb5
bb5:
  %t36 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 200, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t36, ptr %l13, i64 200, i1 false)
  %t37 = load ptr, ptr %l4, !tbaa !29
  %t38 = load ptr, ptr %l10, !tbaa !29
  %t39 = load ptr, ptr %l12, !tbaa !29
  %t41 = call %"compiler/load:Loader" @compiler_2fload_3aLoader_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, { i64, ptr } { i64 3, ptr @.d108 }, ptr %t37, ptr %t38, ptr %t39, ptr %t36)
  store %"compiler/load:Loader" %t41, ptr %l15
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t42 = load %"compiler/load:Loader", ptr %l15
  store %"compiler/load:Loader" %t42, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/load:Loader", ptr %rv
  ret %"compiler/load:Loader" %rr
}

define dso_local ptr @compiler_2fload_2etypeNames(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l21 = alloca i64
  %l24 = alloca i64
  %l42 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l53 = alloca i1
  %l56 = alloca i1
  %l57 = alloca { i64, ptr }
  %l62 = alloca ptr
  %l63 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l68 = alloca i64
  %l69 = alloca { i64, ptr }
  %l73 = alloca i64
  %l74 = alloca i64
  %s2 = alloca %olang.scope
  %rv = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %t3
  store ptr %t3, ptr %l2, !tbaa !29
  %t7 = getelementptr %"compiler/scan:Tokens", ptr %a1, i32 0, i32 0
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  %t14 = sub i64 %t12, 2
  store i64 %t14, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t16 = load i64, ptr %l5, !tbaa !24
  %t17 = load i64, ptr %l4, !tbaa !24
  %t20 = icmp sgt i64 %t16, %t17
  br i1 %t20, label %bb2, label %bb3
bb2:
  %t22 = load i64, ptr %l6, !tbaa !24
  %t24 = icmp sgt i64 %t22, 0
  br i1 %t24, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb7
bb4:
  %t26 = load i64, ptr %l5, !tbaa !24
  %t27 = load i64, ptr %l4, !tbaa !24
  %t30 = sub i64 %t26, %t27
  %t31 = load i64, ptr %l6, !tbaa !24
  %t34 = add i64 %t30, %t31
  %t36 = sub i64 %t34, 1
  %t37 = load i64, ptr %l6, !tbaa !24
  %t40 = sdiv i64 %t36, %t37
  store i64 %t40, ptr %l24, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb6
bb6:
  %t42 = load i64, ptr %l24, !tbaa !24
  store i64 %t42, ptr %l21, !tbaa !24
  br label %bb7
bb7:
  %t43 = load i64, ptr %l21, !tbaa !24
  store i64 %t43, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t44 = load i64, ptr %l8, !tbaa !24
  %t45 = load i64, ptr %l7, !tbaa !24
  %t48 = icmp slt i64 %t44, %t45
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb32
bb10:
  br label %bb11
bb11:
  %t52 = load i64, ptr %l4, !tbaa !24
  %t53 = load i64, ptr %l8, !tbaa !24
  %t54 = load i64, ptr %l6, !tbaa !24
  %t57 = mul i64 %t53, %t54
  %t60 = add i64 %t52, %t57
  store i64 %t60, ptr %l9, !tbaa !24
  %t62 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t62, ptr %l42, !tbaa !27
  %t63 = load i64, ptr %l9, !tbaa !24
  %t65 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = getelementptr %"compiler/token:Token", ptr %t66, i64 %t63
  %t68 = getelementptr %"compiler/token:Token", ptr %t67, i32 0, i32 0
  %t69 = load i32, ptr %t68
  store i32 %t69, ptr %l10
  %t71 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t71, ptr %l45, !tbaa !27
  %t72 = load i64, ptr %l9, !tbaa !24
  %t74 = add i64 %t72, 1
  %t76 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = getelementptr %"compiler/token:Token", ptr %t77, i64 %t74
  %t79 = getelementptr %"compiler/token:Token", ptr %t78, i32 0, i32 0
  %t80 = load i32, ptr %t79
  %t82 = trunc i64 1 to i32
  %t83 = icmp eq i32 %t80, %t82
  %t85 = xor i1 %t83, true
  br i1 %t85, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb31
bb13:
  br label %bb14
bb14:
  %t87 = load i32, ptr %l10
  %t89 = trunc i64 33 to i32
  %t90 = icmp eq i32 %t87, %t89
  br i1 %t90, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l53, !tbaa !21
  br label %bb20
bb16:
  %t92 = load i32, ptr %l10
  %t94 = trunc i64 38 to i32
  %t95 = icmp eq i32 %t92, %t94
  br i1 %t95, label %bb17, label %bb18
bb17:
  %t97 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t97, ptr %l57, !tbaa !27
  %t98 = load i64, ptr %l9, !tbaa !24
  %t100 = add i64 %t98, 2
  %t102 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = getelementptr %"compiler/token:Token", ptr %t103, i64 %t100
  %t105 = getelementptr %"compiler/token:Token", ptr %t104, i32 0, i32 0
  %t106 = load i32, ptr %t105
  %t108 = trunc i64 92 to i32
  %t109 = icmp eq i32 %t106, %t108
  store i1 %t109, ptr %l56, !tbaa !21
  br label %bb19
bb18:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb19
bb19:
  %t111 = load i1, ptr %l56, !tbaa !21
  store i1 %t111, ptr %l53, !tbaa !21
  br label %bb20
bb20:
  %t112 = load i1, ptr %l53, !tbaa !21
  br i1 %t112, label %bb21, label %bb22
bb21:
  %t113 = load ptr, ptr %l2, !tbaa !29
  store ptr %t113, ptr %l62, !tbaa !29
  store { i64, ptr } %a0, ptr %l63, !tbaa !27
  %t115 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t115, ptr %l64, !tbaa !27
  %t116 = load i64, ptr %l9, !tbaa !24
  %t118 = add i64 %t116, 1
  %t120 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !27
  %t122 = getelementptr %"compiler/token:Token", ptr %t121, i64 %t118
  %t123 = getelementptr %"compiler/token:Token", ptr %t122, i32 0, i32 2
  %t124 = load i32, ptr %t123, !tbaa !23
  %t126 = sext i32 %t124 to i64
  store i64 %t126, ptr %l68, !tbaa !24
  %t127 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t127, ptr %l69, !tbaa !27
  %t128 = load i64, ptr %l9, !tbaa !24
  %t130 = add i64 %t128, 1
  %t132 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = getelementptr %"compiler/token:Token", ptr %t133, i64 %t130
  %t135 = getelementptr %"compiler/token:Token", ptr %t134, i32 0, i32 3
  %t136 = load i32, ptr %t135, !tbaa !23
  %t138 = sext i32 %t136 to i64
  store i64 %t138, ptr %l73, !tbaa !24
  %t139 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t139, 0
  store i64 %t140, ptr %l74, !tbaa !24
  %t141 = load i64, ptr %l68, !tbaa !24
  %t142 = icmp sge i64 %t141, 0
  br i1 %t142, label %bb23, label %bb24
bb22:
  br label %bb30
bb23:
  %t144 = load i64, ptr %l68, !tbaa !24
  %t145 = load i64, ptr %l73, !tbaa !24
  %t146 = icmp sle i64 %t144, %t145
  br i1 %t146, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_61485bf8b9fa4014_95a81608270a26e0)
  unreachable
bb25:
  %t148 = load i64, ptr %l73, !tbaa !24
  %t149 = load i64, ptr %l74, !tbaa !24
  %t150 = icmp sle i64 %t148, %t149
  br i1 %t150, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_61485bf8b9fa4014_95a81608270a26e0)
  unreachable
bb27:
  %t152 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = load i64, ptr %l68, !tbaa !24
  %t155 = load i64, ptr %l73, !tbaa !24
  %t156 = getelementptr i8, ptr %t153, i64 %t154
  %t157 = sub i64 %t155, %t154
  %t158 = insertvalue { i64, ptr } undef, i64 %t157, 0
  %t159 = insertvalue { i64, ptr } %t158, ptr %t156, 1
  %t160 = load ptr, ptr %l62, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v0, ptr %t160, { i64, ptr } %t159)
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_61485bf8b9fa4014_95a81608270a26e0)
  unreachable
bb29:
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s2)
  br label %bb31
bb31:
  %t162 = load i64, ptr %l8, !tbaa !24
  %t164 = add i64 %t162, 1
  store i64 %t164, ptr %l8, !tbaa !24
  br label %bb8
bb32:
  %t166 = load ptr, ptr %l2, !tbaa !29
  store ptr %t166, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fload_2ewrite(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i32
  %l15 = alloca i32
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 1, ptr @.d109 }, 1
  %t7 = extractvalue { i64, ptr } { i64 1, ptr @.d109 }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t4, i64 %t5)
  %t14 = getelementptr i8, ptr %t13, i64 %t5
  call void @olang_textcopy(ptr %t14, ptr %t6, i64 %t7)
  %t15 = getelementptr i8, ptr %t14, i64 %t7
  call void @olang_textcopy(ptr %t15, ptr %t10, i64 %t11)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t13, 1
  store { i64, ptr } %t17, ptr %l3, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t21 = call { i64, ptr } @std_2ffilepath_2eDir(ptr %s0, { i64, ptr } %t19)
  store { i64, ptr } %t21, ptr %l8
  br label %bb1
bb1:
  %t22 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t23 = call i32 @std_2fos_2eMkDirAll(ptr %s0, { i64, ptr } %t22)
  store i32 %t23, ptr %l9
  %t24 = icmp ne i32 %t23, 0
  br i1 %t24, label %bb3, label %ok.25
ok.25:
  br label %bb2
bb2:
  br label %bb7
bb3:
  %t26 = load i32, ptr %l9, !tbaa !23
  %t27 = ashr i32 %t26, 16
  %t29 = icmp eq i32 %t27, 1
  br i1 %t29, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_f3717e107a40142_435ff7dc0227b85e)
  unreachable
bb6:
  br label %bb7
bb7:
  %t31 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t36 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %v2, { i64, ptr } %t31, { i64, ptr } %a2)
  store i32 %t36, ptr %l15
  %t37 = icmp ne i32 %t36, 0
  br i1 %t37, label %bb9, label %ok.38
ok.38:
  br label %bb8
bb8:
  br label %bb13
bb9:
  %t39 = load i32, ptr %l15, !tbaa !23
  %t40 = ashr i32 %t39, 16
  %t42 = icmp eq i32 %t40, 1
  br i1 %t42, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_4b33bdfcd35448c3_5fe01124ee6584df)
  unreachable
bb12:
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/load:Import" @compiler_2fload_3aImport_2ector(ptr %v0, ptr %v1, ptr %v2, %"compiler/source:Span" %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2, { i64, ptr } %a3, i64 %a4) #0 {
entry:
  %rv = alloca %"compiler/load:Import"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/load:Import" undef, %"compiler/source:Span" %a0, 0
  %t14 = insertvalue %"compiler/load:Import" %t12, %"compiler/source:Span" %a1, 1
  %t16 = insertvalue %"compiler/load:Import" %t14, { i64, ptr } %a2, 2
  %t18 = insertvalue %"compiler/load:Import" %t16, { i64, ptr } %a3, 3
  %t20 = insertvalue %"compiler/load:Import" %t18, i64 %a4, 4
  %t22 = insertvalue %"compiler/load:Import" %t20, i64 -1, 5
  store %"compiler/load:Import" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/load:Import", ptr %rv
  ret %"compiler/load:Import" %rr
}

define dso_local %"compiler/load:Loader" @compiler_2fload_3aLoader_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l5 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l11 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l21 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l22 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l23 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/load:Loader"
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a0, ptr %l5, !tbaa !27
  store ptr %a1, ptr %l6, !tbaa !29
  store ptr %a2, ptr %l7, !tbaa !29
  store ptr %a3, ptr %l8, !tbaa !29
  store ptr %a4, ptr %l9, !tbaa !29
  %t11 = load ptr, ptr @__olang_prog_scope
  %t12 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3e(ptr %t11)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, ptr %l21
  br label %bb1
bb1:
  %t13 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l21
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, ptr %l10
  %t14 = load ptr, ptr @__olang_prog_scope
  %t15 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t14)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, ptr %l22
  br label %bb2
bb2:
  %t16 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l22
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t16, ptr %l11
  store i64 -1, ptr %l12, !tbaa !24
  %t17 = load ptr, ptr @__olang_prog_scope
  %t18 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_Hf48d6d4096e547b8075d5a903caa3d54(ptr %t17)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t18, ptr %l23
  br label %bb3
bb3:
  %t19 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l23
  store { i64, ptr } { i64 0, ptr @.d110 }, ptr %l14, !tbaa !27
  store { i64, ptr } { i64 0, ptr @.d111 }, ptr %l15, !tbaa !27
  %t20 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t21 = insertvalue %"compiler/load:Loader" undef, { i64, ptr } %t20, 0
  %t22 = load ptr, ptr %l6, !tbaa !29
  %t23 = insertvalue %"compiler/load:Loader" %t21, ptr %t22, 1
  %t24 = load ptr, ptr %l7, !tbaa !29
  %t25 = insertvalue %"compiler/load:Loader" %t23, ptr %t24, 2
  %t26 = load ptr, ptr %l8, !tbaa !29
  %t27 = insertvalue %"compiler/load:Loader" %t25, ptr %t26, 3
  %t28 = load ptr, ptr %l9, !tbaa !29
  %t29 = insertvalue %"compiler/load:Loader" %t27, ptr %t28, 4
  %t30 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  %t31 = insertvalue %"compiler/load:Loader" %t29, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t30, 5
  %t32 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  %t33 = insertvalue %"compiler/load:Loader" %t31, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t32, 6
  %t34 = load i64, ptr %l12, !tbaa !24
  %t35 = insertvalue %"compiler/load:Loader" %t33, i64 %t34, 7
  %t37 = insertvalue %"compiler/load:Loader" %t35, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t19, 8
  %t38 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t39 = insertvalue %"compiler/load:Loader" %t37, { i64, ptr } %t38, 9
  %t40 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t41 = insertvalue %"compiler/load:Loader" %t39, { i64, ptr } %t40, 10
  store %"compiler/load:Loader" %t41, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/load:Loader", ptr %rv
  ret %"compiler/load:Loader" %rr
}

define dso_local void @compiler_2fload_3aModule_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i1
  %l8 = alloca i64
  %l9 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l15 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l19 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l20 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l21 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l22 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l23 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l24 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l25 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l26 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca i1
  %l31 = alloca i1
  %l40 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l41 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l42 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l43 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l44 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l45 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l46 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l47 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l48 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l49 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l50 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l51 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l52 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l53 = alloca %"compiler/load:Module"
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a0, ptr %l4, !tbaa !27
  store { i64, ptr } %a1, ptr %l5, !tbaa !27
  store { i64, ptr } %a2, ptr %l6, !tbaa !27
  store i1 %a3, ptr %l7, !tbaa !21
  store i64 -1, ptr %l8, !tbaa !24
  store i1 false, ptr %l9, !tbaa !21
  store ptr null, ptr %l10, !tbaa !29
  store ptr null, ptr %l11, !tbaa !29
  %t9 = icmp sge i64 0, 0
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = icmp sle i64 0, 1152921504606846975
  br i1 %t11, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_ddd103a03d6047bb_df8a4b94c4d7f62f)
  unreachable
bb3:
  %t13 = mul i64 0, 8
  %t14 = call ptr @__olang_scope_alloc_zeroed(ptr %v3, i64 %t13)
  %t15 = insertvalue { i64, ptr } undef, i64 0, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l12, !tbaa !27
  %t18 = load ptr, ptr @__olang_prog_scope
  %t19 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t18)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t19, ptr %l40
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_ddd103a03d6047bb_df8a4b94c4d7f62f)
  unreachable
bb5:
  %t20 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l40
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t20, ptr %l13
  %t21 = load ptr, ptr @__olang_prog_scope
  %t22 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t21)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t22, ptr %l41
  br label %bb6
bb6:
  %t23 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l41
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t23, ptr %l14
  %t24 = load ptr, ptr @__olang_prog_scope
  %t25 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e(ptr %t24)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %l42
  br label %bb7
bb7:
  %t26 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l42
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t26, ptr %l15
  store ptr null, ptr %l16, !tbaa !29
  store ptr null, ptr %l17, !tbaa !29
  %t27 = load ptr, ptr @__olang_prog_scope
  %t28 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI32_3e(ptr %t27)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t28, ptr %l43
  br label %bb8
bb8:
  %t29 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l43
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t29, ptr %l18
  %t30 = load ptr, ptr @__olang_prog_scope
  %t31 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t30)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t31, ptr %l44
  br label %bb9
bb9:
  %t32 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l44
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t32, ptr %l19
  %t33 = load ptr, ptr @__olang_prog_scope
  %t34 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t33)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t34, ptr %l45
  br label %bb10
bb10:
  %t35 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l45
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t35, ptr %l20
  %t36 = load ptr, ptr @__olang_prog_scope
  %t37 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cBool_3e(ptr %t36)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t37, ptr %l46
  br label %bb11
bb11:
  %t38 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l46
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t38, ptr %l21
  %t39 = load ptr, ptr @__olang_prog_scope
  %t40 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t39)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t40, ptr %l47
  br label %bb12
bb12:
  %t41 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l47
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t41, ptr %l22
  %t42 = load ptr, ptr @__olang_prog_scope
  %t43 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t42)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t43, ptr %l48
  br label %bb13
bb13:
  %t44 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l48
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t44, ptr %l23
  %t45 = load ptr, ptr @__olang_prog_scope
  %t46 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t45)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t46, ptr %l49
  br label %bb14
bb14:
  %t47 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l49
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t47, ptr %l24
  %t48 = load ptr, ptr @__olang_prog_scope
  %t49 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t48)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t49, ptr %l50
  br label %bb15
bb15:
  %t50 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l50
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t50, ptr %l25
  %t51 = load ptr, ptr @__olang_prog_scope
  %t52 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t51)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t52, ptr %l51
  br label %bb16
bb16:
  %t53 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l51
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t53, ptr %l26
  store ptr null, ptr %l27, !tbaa !29
  store ptr null, ptr %l28, !tbaa !29
  store ptr null, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  store i1 false, ptr %l31, !tbaa !21
  %t54 = load ptr, ptr @__olang_prog_scope
  %t55 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t54)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t55, ptr %l52
  br label %bb17
bb17:
  %t56 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l52
  %t57 = getelementptr %"compiler/load:Module", ptr %l53, i32 0, i32 0
  %t58 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t58, ptr %t57, !tbaa !27
  %t59 = getelementptr %"compiler/load:Module", ptr %l53, i32 0, i32 1
  %t60 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t60, ptr %t59, !tbaa !27
  %t61 = getelementptr %"compiler/load:Module", ptr %l53, i32 0, i32 2
  %t62 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t62, ptr %t61, !tbaa !27
  %t63 = getelementptr %"compiler/load:Module", ptr %l53, i32 0, i32 3
  %t64 = load i1, ptr %l7, !tbaa !21
  store i1 %t64, ptr %t63, !tbaa !21
  %t65 = getelementptr %"compiler/load:Module", ptr %l53, i32 0, i32 4
  %t66 = load i64, ptr %l8, !tbaa !24
  store i64 %t66, ptr %t65, !tbaa !24
  %t67 = getelementptr %"compiler/load:Module", ptr %l53, i32 0, i32 5
  %t68 = load i1, ptr %l9, !tbaa !21
  store i1 %t68, ptr %t67, !tbaa !21
  %t69 = getelementptr %"compiler/load:Module", ptr %l53, i32 0, i32 6
  %t70 = load ptr, ptr %l10, !tbaa !29
  store ptr %t70, ptr %t69, !tbaa !29
  %t71 = getelementptr %"compiler/load:Module", ptr %l53, i32 0, i32 7
  %t72 = load ptr, ptr %l11, !tbaa !29
  store ptr %t72, ptr %t71, !tbaa !29
  %t73 = getelementptr %"compiler/load:Module", ptr %l53, i32 0, i32 8
  %t74 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t74, ptr %t73, !tbaa !27
  %t75 = getelementptr %"compiler/load:Module", ptr %l53, i32 0, i32 9
  %t76 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t76, ptr %t75
  %t77 = getelementptr %"compiler/load:Module", ptr %l53, i32 0, i32 10
  %t78 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l14
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t78, ptr %t77
  %t79 = getelementptr %"compiler/load:Module", ptr %l53, i32 0, i32 11
  %t80 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l15
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t80, ptr %t79
  %t81 = getelementptr %"compiler/load:Module", ptr %l53, i32 0, i32 12
  %t82 = load ptr, ptr %l16, !tbaa !29
  store ptr %t82, ptr %t81, !tbaa !29
  %t83 = getelementptr %"compiler/load:Module", ptr %l53, i32 0, i32 13
  %t84 = load ptr, ptr %l17, !tbaa !29
  store ptr %t84, ptr %t83, !tbaa !29
  %t85 = getelementptr %"compiler/load:Module", ptr %l53, i32 0, i32 14
  %t86 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l18
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t86, ptr %t85
  %t87 = getelementptr %"compiler/load:Module", ptr %l53, i32 0, i32 15
  %t88 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l19
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t88, ptr %t87
  %t89 = getelementptr %"compiler/load:Module", ptr %l53, i32 0, i32 16
  %t90 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l20
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t90, ptr %t89
  %t91 = getelementptr %"compiler/load:Module", ptr %l53, i32 0, i32 17
  %t92 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l21
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t92, ptr %t91
  %t93 = getelementptr %"compiler/load:Module", ptr %l53, i32 0, i32 18
  %t94 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l22
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t94, ptr %t93
  %t95 = getelementptr %"compiler/load:Module", ptr %l53, i32 0, i32 19
  %t96 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l23
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t96, ptr %t95
  %t97 = getelementptr %"compiler/load:Module", ptr %l53, i32 0, i32 20
  %t98 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l24
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t98, ptr %t97
  %t99 = getelementptr %"compiler/load:Module", ptr %l53, i32 0, i32 21
  %t100 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l25
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t100, ptr %t99
  %t101 = getelementptr %"compiler/load:Module", ptr %l53, i32 0, i32 22
  %t102 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l26
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t102, ptr %t101
  %t103 = getelementptr %"compiler/load:Module", ptr %l53, i32 0, i32 23
  %t104 = load ptr, ptr %l27, !tbaa !29
  store ptr %t104, ptr %t103, !tbaa !29
  %t105 = getelementptr %"compiler/load:Module", ptr %l53, i32 0, i32 24
  %t106 = load ptr, ptr %l28, !tbaa !29
  store ptr %t106, ptr %t105, !tbaa !29
  %t107 = getelementptr %"compiler/load:Module", ptr %l53, i32 0, i32 25
  %t108 = load ptr, ptr %l29, !tbaa !29
  store ptr %t108, ptr %t107, !tbaa !29
  %t109 = getelementptr %"compiler/load:Module", ptr %l53, i32 0, i32 26
  %t110 = load i1, ptr %l30, !tbaa !21
  store i1 %t110, ptr %t109, !tbaa !21
  %t111 = getelementptr %"compiler/load:Module", ptr %l53, i32 0, i32 27
  %t112 = load i1, ptr %l31, !tbaa !21
  store i1 %t112, ptr %t111, !tbaa !21
  %t113 = getelementptr %"compiler/load:Module", ptr %l53, i32 0, i32 28
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t56, ptr %t113
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l53, i64 256, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @olang_2einit_2ecompiler_2fload() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2fload_2eNotYet_2einit()
  br label %bb1
bb1:
  call void @compiler_2fload_2ePending_2einit()
  br label %bb2
bb2:
  call void @compiler_2fload_2eNoBranch_2einit()
  br label %bb3
bb3:
  br label %ret
ret:
  ret void
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d0 = private constant [1 x i8] c"/"
@.d1 = private constant [6 x i8] c".olang"
declare void @__olang_check_failed(ptr)
@.d2 = private constant [10 x i8] c"olang.lock"
@.d3 = private constant [0 x i8] c""
@.d4 = private constant [0 x i8] c""
@.d5 = private constant [0 x i8] c""
@.d6 = private constant [0 x i8] c""
@__olang_prog_scope = external thread_local(initialexec) global ptr
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d7 = private constant [1 x i8] c"/"
@.d8 = private constant [0 x i8] c""
@.d9 = private constant [1 x i8] c"."
@.d10 = private constant [2 x i8] c".."
@.d11 = private constant [2 x i8] c".."
@.d12 = private constant [1 x i8] c"/"
@.d13 = private constant [1 x i8] c"."
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d14 = private constant [9 x i8] c"OLANG_STD"
@.d15 = private constant [0 x i8] c""
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d16 = private constant [0 x i8] c""
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d17 = private constant [14 x i8] c"/proc/self/exe"
@.d18 = private constant [3 x i8] c"std"
@.d19 = private constant [7 x i8] c"/../std"
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
@.d20 = private constant [4 x i8] c"std/"
@.d21 = private constant [0 x i8] c""
@.d22 = private constant [1 x i8] c"?"
define available_externally void @__olang_scope_escape(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %un = icmp eq ptr %o, null
  br i1 %un, label %claim, label %done
claim:
  %me = load ptr, ptr @__olang_self
  store atomic ptr %me, ptr %op monotonic, align 8
  br label %done
done:
  ret void
}
define internal i1 @olang_lambda_23(ptr %env, i64 %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l6 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l12 = alloca ptr
  %l15 = alloca i1
  %rv = alloca i1
  %cp0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  store ptr %cv0, ptr %l2
  %vq0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/load:Loader", ptr %t1, i32 0, i32 5
  %t7 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %vc0, ptr %vc0, ptr %t3, i64 %a0)
  store ptr %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l6, !tbaa !29
  %t10 = getelementptr %"compiler/load:Module", ptr %t8, i32 0, i32 2
  %t11 = load { i64, ptr }, ptr %t10, !tbaa !27
  store { i64, ptr } %t11, ptr %l8, !tbaa !27
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t14 = getelementptr %"compiler/load:Loader", ptr %t12, i32 0, i32 5
  %t18 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %vc0, ptr %vc0, ptr %t14, i64 %a1)
  store ptr %t18, ptr %l12
  br label %bb2
bb2:
  %t19 = load ptr, ptr %l12, !tbaa !29
  %t21 = getelementptr %"compiler/load:Module", ptr %t19, i32 0, i32 2
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t25 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %vc0, ptr %vc0, { i64, ptr } %t23, { i64, ptr } %t22)
  store i1 %t25, ptr %l15
  br label %bb3
bb3:
  %t26 = load i1, ptr %l15, !tbaa !21
  store i1 %t26, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d24 = private constant [7 x i8] c"module "
@.d25 = private constant [1 x i8] c"\0A"
@.d26 = private constant [2 x i8] c"  "
@.d27 = private constant [1 x i8] c" "
@.d28 = private constant [1 x i8] c"\0A"
define internal i1 @olang_lambda_29(ptr %env, ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l4 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  store i1 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d30 = private constant [0 x i8] c""
@.d31 = private constant [0 x i8] c""
@.d32 = private constant [1 x i8] c"."
@.d33 = private constant [7 x i8] c"prelude"
@.d34 = private constant [0 x i8] c""
@.d35 = private constant [0 x i8] c""
@.d36 = private constant [0 x i8] c""
@.d37 = private constant [0 x i8] c""
@.d38 = private constant [6 x i8] c".olang"
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20I32_3e_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20I32_3e_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d39 = private constant [1 x i8] c"."
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d40 = private constant [0 x i8] c""
@.d41 = private constant [0 x i8] c""
@.d42 = private constant [0 x i8] c""
@.d43 = private constant [0 x i8] c""
declare void @__olang_bang_failed(ptr)
@.d44 = private constant [0 x i8] c""
@.d45 = private constant [4 x i8] c"std/"
@.d46 = private constant [0 x i8] c""
@.d47 = private constant [0 x i8] c""
@.d48 = private constant [0 x i8] c""
@.d49 = private constant [0 x i8] c""
@.d50 = private constant [5 x i8] c"Array"
@.d51 = private constant [0 x i8] c""
@.d52 = private constant [6 x i8] c".olang"
@.d53 = private constant [0 x i8] c""
@.d54 = private constant [0 x i8] c""
@.d55 = private constant [4 x i8] c"std/"
@.d56 = private constant [1 x i8] c"."
@.d57 = private constant [1 x i8] c"/"
@.d58 = private constant [6 x i8] c".olang"
@.d59 = private constant [4 x i8] c"std/"
@.d60 = private constant [3 x i8] c"std"
@.d61 = private constant [1 x i8] c"."
@.d62 = private constant [2 x i8] c".."
@.d63 = private constant [1 x i8] c"/"
@.d64 = private constant [0 x i8] c""
@.d65 = private constant [0 x i8] c""
@.d66 = private constant [0 x i8] c""
@.d67 = private constant [0 x i8] c""
@.d68 = private constant [0 x i8] c""
@.d69 = private constant [6 x i8] c".olang"
@.d70 = private constant [1 x i8] c"/"
@.d71 = private constant [1 x i8] c"/"
@.d72 = private constant [1 x i8] c"."
@.d73 = private constant [6 x i8] c".olang"
@.d74 = private constant [1 x i8] c"/"
@.d75 = private constant [6 x i8] c".olang"
@.d76 = private constant [1 x i8] c"/"
@.d77 = private constant [0 x i8] c""
@.d78 = private constant [1 x i8] c"."
@.d79 = private constant [1 x i8] c"."
@.d80 = private constant [2 x i8] c".."
@.d81 = private constant [4 x i8] c"std/"
@.d82 = private constant [3 x i8] c"std"
@.d83 = private constant [1 x i8] c"/"
@.d84 = private constant [0 x i8] c""
@.d85 = private constant [1 x i8] c"/"
@.d86 = private constant [0 x i8] c""
@.d87 = private constant [0 x i8] c""
@.d88 = private constant [0 x i8] c""
@.d89 = private constant [0 x i8] c""
@.d90 = private constant [1 x i8] c"/"
@.d91 = private constant [1 x i8] c"/"
@.d92 = private constant [4 x i8] c"std/"
@.d93 = private constant [0 x i8] c""
@.d94 = private constant [6 x i8] c".olang"
@.d95 = private constant [0 x i8] c""
@.d96 = private constant [1 x i8] c"/"
@.d97 = private constant [1 x i8] c"/"
@.d98 = private constant [1 x i8] c"/"
@.d99 = private constant [1 x i8] c"."
@.d100 = private constant [1 x i8] c"/"
@.d101 = private constant [1 x i8] c"/"
@.d102 = private constant [1 x i8] c"/"
@.d103 = private constant [5 x i8] c"linux"
@.d104 = private constant [6 x i8] c"x86_64"
@.d105 = private constant [6 x i8] c"x86-64"
@.d106 = private constant [6 x i8] c".cache"
@.d107 = private constant [16 x i8] c"file:///nowhere/"
@.d108 = private constant [3 x i8] c"std"
@.d109 = private constant [1 x i8] c"/"
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_Hf48d6d4096e547b8075d5a903caa3d54(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d110 = private constant [0 x i8] c""
@.d111 = private constant [0 x i8] c""
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI32_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI32_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cBool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cBool_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@__olang_self = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
declare ptr @__olang_scope_mine_slow(ptr) noinline
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_30f594fd977814cf_401937ed3e69cedb = external constant [0 x i8]
declare { i64, ptr } @std_2ffilepath_2eDir(ptr %v0, { i64, ptr } %a0)
declare { i64, ptr } @std_2ffilepath_2eJoin(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4, { i64, ptr } %a5)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hd1f680ecc7a3e4b4dd91667eaf6a5223(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %a0)
declare { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fos_2eReadLink(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_dd45d0afc1e93de5_b21ed3f58d77ee79 = external constant [0 x i8]
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2eLen_3cI32_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2eAt_3cI32_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fdiag_3aDiagnostics_2ector(ptr %out, ptr %v0, i1 %a0)
@olang_loc_5d2941245b0f1fa7_46eb30867ff7b79b = external constant [0 x i8]
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAddFile(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3)
@olang_loc_59c39bf8bbcbf188_f14f86d27dc81ac = external constant [0 x i8]
declare void @compiler_2fparse_3aParser_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, i64 %a5)
declare %"compiler/cond:Scope" @compiler_2fcond_3aScope_2ector(ptr %v0, i1 %a0)
@olang_loc_4d8cd44e3790675d_2617b874cf4b9361 = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_fa9a52c457f0fb75_22f5bb1b6c86fb39 = external constant [0 x i8]
@olang_loc_d075f0de9750727b_8d30bef36920d0c7 = external constant [0 x i8]
@olang_loc_3e505cf2918dad64_849156d88841e490 = external constant [0 x i8]
@olang_loc_64a34b454640941_8ed0e4b282ed07d = external constant [0 x i8]
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eExprAt(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_64e62a75e1515ba_854f46de0e9c2096 = external constant [0 x i8]
declare i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ePos(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
@olang_loc_fd9aced5b5816aaf_8929f8e14d5b5303 = external constant [0 x i8]
@olang_loc_cbb673ffd51f0578_6485c9eddb6ebeac = external constant [0 x i8]
declare %"compiler/cond:Global" @compiler_2fcond_3aGlobal_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, %"compiler/source:Span" %a1, i1 %a2, { i64, ptr } %a3, ptr %a4, i1 %a5)
declare void @compiler_2fcond_2ecompiler_2fcond_3aScope_2eAdd(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v0, ptr %a0)
@olang_loc_53eff658f30813a6_f347cd1231cef772 = external constant [0 x i8]
declare void @std_2fprelude_2farray_2eArray_3cI64_3e_2eSort_3cI64_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1c, ptr %a1e)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2eRunFrom_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_62b70330b5a932c_215a88d5ae52afb0 = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H16703ab81466b1a1027ed0782af113ea(ptr %v0, ptr %v1, ptr %a0, ptr %a1c, ptr %a1e)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_1c47cd2d61f1a0a7_ff925f8d23313feb = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fos_2eCwd(ptr %v0)
declare i1 @std_2fos_2eIsDir(ptr %v0, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eIsDirectory(ptr %v0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_73959507986a80b6_81fabf4f7ad77b72 = external constant [0 x i8]
@olang_loc_568c45cfad451457_e2631f8594a96ff3 = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_155d5a878ef69f1c_357df84449aa70d8 = external constant [0 x i8]
declare %"compiler/scan:Tokens" @compiler_2fscan_2eScan(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_c5ef9e9b040d874d_a4c08c1d690343a9 = external constant [0 x i8]
@olang_loc_766341541344483a_b19cf45a67b9d8ce = external constant [0 x i8]
declare %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" @std_2fpair_3aPair_3cI64_2c_20I32_3e_2ector(ptr %v0, i64 %a0, i32 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20I32_3e_Hd7be20793e0d40c909f29debacc96a43(ptr %v0, ptr %a0, %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eChoose(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eDrop(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_c7262fe51519f763_af68021c51d3e65f = external constant [0 x i8]
@olang_loc_5374637873936654_bf4b9d38f6a4cac0 = external constant [0 x i8]
@olang_loc_a9d5346f51b5ce49_2177b031869164d5 = external constant [0 x i8]
@olang_loc_a4899dfb2f47d10d_f1c9b32274c1c5d9 = external constant [0 x i8]
@olang_loc_d68b219fa2f37dc_2c4a1c709d04c08 = external constant [0 x i8]
declare void @compiler_2fparse_2ecompiler_2fparse_3aOracle_2eAdd(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3)
@olang_loc_495643cfc2e17017_d12bcc0a4d818fe3 = external constant [0 x i8]
declare void @compiler_2fparse_2ecompiler_2fparse_3aOracle_2eAddFn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3)
@olang_loc_555f64ce3e1e7c9a_21848c58e72b35ee = external constant [0 x i8]
@olang_loc_91e287b3951b969b_9736b657bc6cd6af = external constant [0 x i8]
declare i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportReachedTwice(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
@olang_loc_bac1e628134637d6_1fc79dd263e480a2 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReexportCycle(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_9b991ce6afd49bf7_d331ab4ffe40a1a3 = external constant [0 x i8]
@olang_loc_f27e16b36a34913f_9730f0a664aef8cb = external constant [0 x i8]
@olang_loc_f6bd06efaafe5f20_6d37165570c63ddc = external constant [0 x i8]
declare i32 @compiler_2fscan_2ecompiler_2fscan_3aTokens_2eMatch(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_10115782cae2d59a_b13624e5abc6764e = external constant [0 x i8]
@olang_loc_c8cfdf98ee3f2b21_1207f6627874c5f5 = external constant [0 x i8]
@olang_loc_b990dbcfbe082b6c_e09e9a90e433de0 = external constant [0 x i8]
declare %"compiler/cond:Eval" @compiler_2fcond_3aEval_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, ptr %a1, ptr %a2, ptr %a3)
declare { i32, i1 } @compiler_2fcond_2ecompiler_2fcond_3aEval_2eTop(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { %"compiler/source:Span", %"compiler/msgs:Msg" } @compiler_2fcond_2ecompiler_2fcond_3aEval_2eError(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_e0f283e125550868_38a74932bc9801b4 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
@olang_loc_88eba3596c4d138c_c1530d55fa80a9b0 = external constant [0 x i8]
@olang_loc_17f5e01691795fb_80a050950937648f = external constant [0 x i8]
@olang_loc_fd1d115e36d277d2_104a63438b39a3d6 = external constant [0 x i8]
@olang_loc_3753a1d7262b2cc1_bd09a853d1b85305 = external constant [0 x i8]
@olang_loc_a7b0777888cd5d70_d2e13e44ce4d5eec = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2ePush_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/load:Import" %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H4773d10fc8d77771a2093e7ac76ab6ea(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_He27db0a1785588531472bfd2db42574f(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha4444909f5ef14f7626d25b8f59e6ba2(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare { i32, %"compiler/source:Source" } @compiler_2fsource_2eRead(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_e403cb93f671e1d2_e7fcc79a06633816 = external constant [0 x i8]
@olang_loc_664a4422ae98fea4_a167a9a7a681bc90 = external constant [0 x i8]
declare %"compiler/source:Source" @compiler_2fsource_3aSource_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_9fb00b21f6ee0659_5158dcd84d792d55 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %v0)
declare { i32, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H78ccce95e6ef2f62693281865bce11fb(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_97fda29c929b9401_a297b77e137a783d = external constant [0 x i8]
@olang_loc_8eb73d0fe26fae48_56cde13f0d79d76c = external constant [0 x i8]
@olang_loc_ec0a8ee137cfd267_208c661d4674a25b = external constant [0 x i8]
declare { i64, ptr } @compiler_2fscan_2ecompiler_2fscan_3aDiag_2eRule(ptr %v0, %"compiler/scan:Diag" %a0)
declare { i64, ptr } @compiler_2fscan_2ecompiler_2fscan_3aDiag_2eMessage(ptr %v0, %"compiler/scan:Diag" %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_3aMsg_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"compiler/parse:Oracle" @compiler_2fparse_3aOracle_2ector(ptr %v0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2eLen_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %a0)
declare %"compiler/load:Import" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2eAt_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2eSetAt_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/load:Import" %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportAliasInvalid(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportAliasConflict(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_49cedf3031712b7_3bc4f9aaebc3779b = external constant [0 x i8]
@olang_loc_4820d8be822def4f_666b99eead9f0f03 = external constant [0 x i8]
@olang_loc_86fa1f93e6420cad_823198da66b83db1 = external constant [0 x i8]
@olang_loc_2ca78ec550b059c5_f5cdcad03c843269 = external constant [0 x i8]
@olang_loc_648a5599090fec1b_dbd79204e5ca9e37 = external constant [0 x i8]
@olang_loc_b3a4ea8dfaa95483_fae7881f3523a9cf = external constant [0 x i8]
@olang_loc_eb05c210d74cf102_8c07a8e6e119cf9e = external constant [0 x i8]
@olang_loc_8f863f78ae5527a5_d98381c5cf71b659 = external constant [0 x i8]
@olang_loc_d1a77ba1d5054afe_d44f3bbb44d4a532 = external constant [0 x i8]
@olang_loc_ae9d746b68f04eaf_c5efeab384942473 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eFile(ptr %v0, ptr %a0)
@olang_loc_2753d2bb7793a0fa_e1a4644f7c04bcf6 = external constant [0 x i8]
@olang_loc_d655d44f6833c308_c4bdadfd628b0d84 = external constant [0 x i8]
@olang_loc_75be0ecbfd40364c_3ba616ba9e8cb88 = external constant [0 x i8]
declare ptr @compiler_2fparse_2eGenericFnNames(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1)
@olang_loc_898dab7725428e2_be0644f7b8b38fbe = external constant [0 x i8]
@olang_loc_b5bc6b986ac34f36_b045281a4c31efba = external constant [0 x i8]
@olang_loc_d161242c40b74370_507871439a6630a4 = external constant [0 x i8]
@olang_loc_9cda1922aec704f_35a4007cf0fda73 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportPathTooLong(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportHasExtension(ptr %v0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %a0, i8 %a1)
@olang_loc_6772f502359d02a_1b697b2141371efe = external constant [0 x i8]
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_c7e55e824de13607_c088d15fef4da17b = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportLeavesRoot(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportRemoteNeedsFile(ptr %v0)
declare { i32, { i64, ptr } } @compiler_2ffetch_2ecompiler_2ffetch_3aFetcher_2eFetch(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportRemoteBadName(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportLockNotACommit(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportFetchFailed(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportLockedFetchFailed(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2ffilepath_2eBase(ptr %v0, { i64, ptr } %a0)
@olang_loc_91ed1932ac5cd85c_f28264288e99980 = external constant [0 x i8]
declare i1 @std_2fos_2eExists(ptr %v0, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eImportFileNotFound(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_d9612e2b18e8b492_6662b34d58c1f606 = external constant [0 x i8]
@olang_loc_e481e3499ae60e8f_66ba2a1e23e9a0e3 = external constant [0 x i8]
@olang_loc_281d6687dd267da4_55752feab9766ac8 = external constant [0 x i8]
@olang_loc_f33836f530001f0a_3e5ddd8b9e2e63ae = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2ePush_3cI32_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
@olang_loc_e83704c0903811_d990170ae1d54355 = external constant [0 x i8]
@olang_loc_766ae0e3e1f9b91c_7764041251e8a940 = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
@olang_loc_4f7ff751eb66f618_e3b0711c9f747694 = external constant [0 x i8]
@olang_loc_4fa7c22e4d470d75_c9a9030dc047401 = external constant [0 x i8]
declare { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3)
@olang_loc_e1450843369e7a83_4c1990cf53114c27 = external constant [0 x i8]
@olang_loc_9a4e1e4457f2709_31a5a56895743715 = external constant [0 x i8]
@olang_loc_738c5ab5e9ce8338_c044a83eb6fe7eb4 = external constant [0 x i8]
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAllSaid(ptr %v0, ptr %v1, ptr %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3aSaid_3e_2eRunFrom_3ccompiler_2fdiag_3aSaid_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_79b6b74230fc653e_a4ca48bccf53fe5a = external constant [0 x i8]
declare %"compiler/cond:Consts" @compiler_2fcond_3aConsts_2ector(ptr %v0)
declare void @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eBuiltins(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, i64 %a4, i64 %a5, i1 %a6, i1 %a7, i1 %a8)
declare %"compiler/fetch:Fetcher" @compiler_2ffetch_3aFetcher_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3, i1 %a4)
declare %"compiler/source:Names" @compiler_2fsource_3aNames_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
@olang_loc_61485bf8b9fa4014_95a81608270a26e0 = external constant [0 x i8]
declare i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %a0)
@olang_loc_f3717e107a40142_435ff7dc0227b85e = external constant [0 x i8]
declare i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_4b33bdfcd35448c3_5fe01124ee6584df = external constant [0 x i8]
@olang_loc_ddd103a03d6047bb_df8a4b94c4d7f62f = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20I32_3e_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI32_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cBool_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
