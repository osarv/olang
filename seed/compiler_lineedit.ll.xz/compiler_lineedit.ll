; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/lineedit:Editor" = type { i1, i1, i64, { i64, ptr }, i64, i1, %"std/prelude/text:StringBuilder", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, { i64, ptr }, i64, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i1, i1, i1, i1, i1, { i64, ptr }, { i64, ptr }, i64, i1, { i64, ptr }, i64, i64, i64, i8, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/lineedit:snap" = type { { i64, ptr }, i64 }
@G_2ecompiler_2flineedit_2eKeep = constant <{ [8 x i8] }> <{ [8 x i8] c"\E8\03\00\00\00\00\00\00" }>, align 8
define dso_local i32 @compiler_2flineedit_2eChoose(i1 %a0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l12 = alloca i32
  %l14 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i64, ptr } @compiler_2flineedit_2eConfigPath(ptr %s0)
  store { i64, ptr } %t1, ptr %l2
  br label %bb1
bb1:
  %t2 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t2, ptr %l1, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  %t6 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d0, i32 0, i32 1) }, 0
  %t9 = sub i64 %t5, %t6
  store i64 %t9, ptr %l6, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t10, 0
  store i64 %t11, ptr %l7, !tbaa !24
  %t12 = icmp sge i64 0, 0
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t14 = load i64, ptr %l6, !tbaa !24
  %t15 = icmp sle i64 0, %t14
  br i1 %t15, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @olang_loc_6d8e321d50b20c8b_e1e5724559d494c7)
  unreachable
bb4:
  %t17 = load i64, ptr %l6, !tbaa !24
  %t18 = load i64, ptr %l7, !tbaa !24
  %t19 = icmp sle i64 %t17, %t18
  br i1 %t19, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_6d8e321d50b20c8b_e1e5724559d494c7)
  unreachable
bb6:
  %t21 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = load i64, ptr %l6, !tbaa !24
  %t24 = getelementptr i8, ptr %t22, i64 0
  %t25 = sub i64 %t23, 0
  %t26 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t24, 1
  %t29 = call i32 @std_2fos_2eMkDirAll(ptr %s0, { i64, ptr } %t27)
  store i32 %t29, ptr %l12
  %t30 = icmp ne i32 %t29, 0
  br i1 %t30, label %bb9, label %ok.31, !prof !99
ok.31:
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_6d8e321d50b20c8b_e1e5724559d494c7)
  unreachable
bb8:
  br label %bb10
bb9:
  %t32 = load i32, ptr %l12, !tbaa !23
  %t33 = lshr i32 %t32, 16
  %t34 = and i32 %t32, 65535
  %t35 = icmp eq i32 %t33, 1
  %t36 = select i1 %t35, i32 1, i32 0
  %t37 = icmp eq i32 %t32, 0
  %t38 = shl i32 %t36, 16
  %t39 = or i32 %t38, %t34
  %t40 = select i1 %t37, i32 0, i32 %t39
  call void @__olang_scope_close(ptr %s0)
  store i32 %t40, ptr %rv
  br label %ret
bb10:
  %t42 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t42, ptr %l14, !tbaa !27
  br i1 %a0, label %bb11, label %bb12
bb11:
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d1, i32 0, i32 1) }, ptr %l17, !tbaa !27
  %t45 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t45, ptr %l16, !tbaa !27
  br label %bb13
bb12:
  store { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d2, i32 0, i32 1) }, ptr %l18, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t46, ptr %l16, !tbaa !27
  br label %bb13
bb13:
  %t47 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t49 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %s0, { i64, ptr } %t47, { i64, ptr } %t48)
  store i32 %t49, ptr %l19
  %t50 = icmp ne i32 %t49, 0
  br i1 %t50, label %bb15, label %ok.51, !prof !99
ok.51:
  br label %bb14
bb14:
  br label %bb16
bb15:
  %t52 = load i32, ptr %l19, !tbaa !23
  %t53 = lshr i32 %t52, 16
  %t54 = and i32 %t52, 65535
  %t55 = icmp eq i32 %t53, 1
  %t56 = select i1 %t55, i32 1, i32 0
  %t57 = icmp eq i32 %t52, 0
  %t58 = shl i32 %t56, 16
  %t59 = or i32 %t58, %t54
  %t60 = select i1 %t57, i32 0, i32 %t59
  call void @__olang_scope_close(ptr %s0)
  store i32 %t60, ptr %rv
  br label %ret
bb16:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2flineedit_2eConfigPath(ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l7 = alloca i1
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d3, i32 0, i32 1) })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l3
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5, !prof !99
ok.5:
  store { i64, ptr } %t2, ptr %l2
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t6, ptr %l1, !tbaa !27
  br label %bb6
bb2:
  %t7 = load i32, ptr %l3, !tbaa !23
  %t8 = ashr i32 %t7, 16
  %t10 = icmp eq i32 %t8, 1
  br i1 %t10, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d4, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb6
bb6:
  %t12 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t12, ptr %l0, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t15 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t13, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d5, i32 0, i32 1) })
  store i1 %t15, ptr %l7
  br label %bb7
bb7:
  %t16 = load i1, ptr %l7, !tbaa !21
  br i1 %t16, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s1
  %t17 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s1, ptr %s1, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d6, i32 0, i32 1) })
  %t18 = extractvalue { i32, { i64, ptr } } %t17, 1
  %t19 = extractvalue { i32, { i64, ptr } } %t17, 0
  store i32 %t19, ptr %l10
  %t20 = icmp ne i32 %t19, 0
  br i1 %t20, label %bb11, label %ok.21, !prof !99
ok.21:
  store { i64, ptr } %t18, ptr %l9
  br label %bb10
bb9:
  br label %bb16
bb10:
  %t22 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t22, ptr %l8, !tbaa !27
  br label %bb15
bb11:
  %t23 = load i32, ptr %l10, !tbaa !23
  %t24 = ashr i32 %t23, 16
  %t26 = icmp eq i32 %t24, 1
  br i1 %t26, label %bb12, label %bb13
bb12:
  call void @__olang_errpay_pop()
  br label %bb13
bb13:
  br label %bb14
bb14:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d7, i32 0, i32 1) }, ptr %l8, !tbaa !27
  br label %bb15
bb15:
  %t28 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 1
  %t30 = extractvalue { i64, ptr } %t28, 0
  %t31 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t32 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t33 = add i64 %t30, %t32
  %t34 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t33)
  call void @olang_textcopy(ptr %t34, ptr %t29, i64 %t30)
  %t35 = getelementptr i8, ptr %t34, i64 %t30
  call void @olang_textcopy(ptr %t35, ptr %t31, i64 %t32)
  %t36 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t34, 1
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t37, ptr %rv
  br label %ret
bb16:
  %t39 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 1
  %t42 = extractvalue { i64, ptr } %t39, 0
  %t43 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t44 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t45 = add i64 %t42, %t44
  %t46 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t45)
  call void @olang_textcopy(ptr %t46, ptr %t41, i64 %t42)
  %t47 = getelementptr i8, ptr %t46, i64 %t42
  call void @olang_textcopy(ptr %t47, ptr %t43, i64 %t44)
  %t48 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t46, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t49, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2flineedit_2eEditor_2etesting(ptr %out, ptr %v0, i1 %a0) #0 {
entry:
  %lp1 = alloca ptr
  %l3 = alloca %"compiler/lineedit:Editor"
  %l6 = alloca %"compiler/lineedit:Editor"
  %t2 = alloca %"compiler/lineedit:Editor", align 8
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2flineedit_3aEditor_2ector(ptr %t2, ptr %v0, i1 %a0, i1 false, i64 80)
  call void @llvm.memmove.p0.p0.i64(ptr %l3, ptr %t2, i64 432, i1 false)
  br label %bb1
bb1:
  %t4 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 432, i64 8)
  store ptr %t4, ptr %lp1
  %t5 = load ptr, ptr %lp1
  call void @llvm.memmove.p0.p0.i64(ptr %t5, ptr %l3, i64 432, i1 false)
  %t6 = load ptr, ptr %lp1
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eBegin(ptr %v0, ptr %t6)
  br label %bb2
bb2:
  %t8 = load ptr, ptr %lp1
  %t9 = getelementptr %"compiler/lineedit:Editor", ptr %t8, i32 0, i32 6
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eClear(ptr %v0, ptr %t9)
  br label %bb3
bb3:
  %t11 = load ptr, ptr %lp1
  call void @llvm.memmove.p0.p0.i64(ptr %l6, ptr %t11, i64 432, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l6, i64 432, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2flineedit_2eHistoryPath(ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l7 = alloca i1
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d10, i32 0, i32 1) })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l3
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5, !prof !99
ok.5:
  store { i64, ptr } %t2, ptr %l2
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t6, ptr %l1, !tbaa !27
  br label %bb6
bb2:
  %t7 = load i32, ptr %l3, !tbaa !23
  %t8 = ashr i32 %t7, 16
  %t10 = icmp eq i32 %t8, 1
  br i1 %t10, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d11, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb6
bb6:
  %t12 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t12, ptr %l0, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t15 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t13, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d12, i32 0, i32 1) })
  store i1 %t15, ptr %l7
  br label %bb7
bb7:
  %t16 = load i1, ptr %l7, !tbaa !21
  br i1 %t16, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s1
  %t17 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s1, ptr %s1, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d13, i32 0, i32 1) })
  %t18 = extractvalue { i32, { i64, ptr } } %t17, 1
  %t19 = extractvalue { i32, { i64, ptr } } %t17, 0
  store i32 %t19, ptr %l10
  %t20 = icmp ne i32 %t19, 0
  br i1 %t20, label %bb11, label %ok.21, !prof !99
ok.21:
  store { i64, ptr } %t18, ptr %l9
  br label %bb10
bb9:
  br label %bb16
bb10:
  %t22 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t22, ptr %l8, !tbaa !27
  br label %bb15
bb11:
  %t23 = load i32, ptr %l10, !tbaa !23
  %t24 = ashr i32 %t23, 16
  %t26 = icmp eq i32 %t24, 1
  br i1 %t26, label %bb12, label %bb13
bb12:
  call void @__olang_errpay_pop()
  br label %bb13
bb13:
  br label %bb14
bb14:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, ptr %l8, !tbaa !27
  br label %bb15
bb15:
  %t28 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 1
  %t30 = extractvalue { i64, ptr } %t28, 0
  %t31 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t32 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  %t33 = add i64 %t30, %t32
  %t34 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t33)
  call void @olang_textcopy(ptr %t34, ptr %t29, i64 %t30)
  %t35 = getelementptr i8, ptr %t34, i64 %t30
  call void @olang_textcopy(ptr %t35, ptr %t31, i64 %t32)
  %t36 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t34, 1
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t37, ptr %rv
  br label %ret
bb16:
  %t39 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 1
  %t42 = extractvalue { i64, ptr } %t39, 0
  %t43 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t44 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t45 = add i64 %t42, %t44
  %t46 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t45)
  call void @olang_textcopy(ptr %t46, ptr %t41, i64 %t42)
  %t47 = getelementptr i8, ptr %t46, i64 %t42
  call void @olang_textcopy(ptr %t47, ptr %t43, i64 %t44)
  %t48 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t46, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t49, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2flineedit_2eViChosen() #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i32
  %l12 = alloca i1
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i32
  %l24 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d17, i32 0, i32 1) })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l8
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5, !prof !99
ok.5:
  store { i64, ptr } %t2, ptr %l7
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t6, ptr %l6, !tbaa !27
  br label %bb6
bb2:
  %t7 = load i32, ptr %l8, !tbaa !23
  %t8 = ashr i32 %t7, 16
  %t10 = icmp eq i32 %t8, 1
  br i1 %t10, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d18, i32 0, i32 1) }, ptr %l6, !tbaa !27
  br label %bb6
bb6:
  %t12 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t12, ptr %l0, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t15 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t13, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d19, i32 0, i32 1) })
  store i1 %t15, ptr %l12
  br label %bb7
bb7:
  %t16 = load i1, ptr %l12, !tbaa !21
  %t17 = xor i1 %t16, true
  br i1 %t17, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s1
  %t19 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t21 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s1, { i64, ptr } %t19, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d20, i32 0, i32 1) })
  store i1 %t21, ptr %l15
  br label %bb10
bb9:
  br label %bb11
bb10:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t22 = load i1, ptr %l15, !tbaa !21
  store i1 %t22, ptr %rv
  br label %ret
bb11:
  %t23 = call { i64, ptr } @compiler_2flineedit_2eConfigPath(ptr %s0)
  store { i64, ptr } %t23, ptr %l17
  br label %bb12
bb12:
  %t24 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t26 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s0, { i64, ptr } %t24)
  %t27 = extractvalue { i32, { i64, ptr } } %t26, 1
  %t28 = extractvalue { i32, { i64, ptr } } %t26, 0
  store i32 %t28, ptr %l20
  %t29 = icmp ne i32 %t28, 0
  br i1 %t29, label %bb14, label %ok.30, !prof !99
ok.30:
  store { i64, ptr } %t27, ptr %l19
  br label %bb13
bb13:
  %t31 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t31, ptr %l16, !tbaa !27
  br label %bb18
bb14:
  %t32 = load i32, ptr %l20, !tbaa !23
  %t33 = ashr i32 %t32, 16
  %t35 = icmp eq i32 %t33, 1
  br i1 %t35, label %bb15, label %bb16
bb15:
  call void @__olang_errpay_pop()
  br label %bb16
bb16:
  br label %bb17
bb17:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d21, i32 0, i32 1) }, ptr %l16, !tbaa !27
  br label %bb18
bb18:
  %t37 = load { i64, ptr }, ptr %l16, !tbaa !27
  store %olang.scope zeroinitializer, ptr %s2
  %t40 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %s0, ptr %s2, ptr %s2, { i64, ptr } %t37, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d22, i32 0, i32 1) })
  store { i64, ptr } %t40, ptr %l24
  br label %bb19
bb19:
  %t41 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t41, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t42 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  store i64 %t44, ptr %l4, !tbaa !24
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s3
  %t46 = load i64, ptr %l3, !tbaa !24
  %t47 = load i64, ptr %l4, !tbaa !24
  %t50 = icmp slt i64 %t46, %t47
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s3)
  br label %bb30
bb22:
  br label %bb23
bb23:
  %t54 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t54, ptr %l31, !tbaa !27
  %t55 = load i64, ptr %l3, !tbaa !24
  %t57 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr { i64, ptr }, ptr %t58, i64 %t55
  %t60 = load { i64, ptr }, ptr %t59, !tbaa !37
  %t64 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %s2, ptr %s2, { i64, ptr } %t60)
  store { i64, ptr } %t64, ptr %l35
  br label %bb24
bb24:
  %t65 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t66 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s3, { i64, ptr } %t65, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d23, i32 0, i32 1) })
  store i1 %t66, ptr %l36
  br label %bb25
bb25:
  %t67 = load i1, ptr %l36, !tbaa !21
  br i1 %t67, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s3)
  br label %bb29
bb29:
  %t69 = load i64, ptr %l3, !tbaa !24
  %t72 = add i64 %t69, 1
  store i64 %t72, ptr %l3, !tbaa !24
  br label %bb20
bb30:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2flineedit_2ecells(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l13 = alloca { i64, ptr }
  %l17 = alloca i1
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l13, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i8, ptr %t19, i64 %t16
  %t21 = load i8, ptr %t20, !tbaa !32
  %t25 = call i1 @compiler_2flineedit_2eisCont(i8 %t21)
  store i1 %t25, ptr %l17
  br label %bb5
bb5:
  %t26 = load i1, ptr %l17, !tbaa !21
  %t27 = xor i1 %t26, true
  br i1 %t27, label %bb6, label %bb7
bb6:
  %t29 = load i64, ptr %l1, !tbaa !24
  %t32 = add i64 %t29, 1
  store i64 %t32, ptr %l1, !tbaa !24
  br label %bb8
bb7:
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t34 = load i64, ptr %l3, !tbaa !24
  %t37 = add i64 %t34, 1
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb1
bb10:
  %t39 = load i64, ptr %l1, !tbaa !24
  store i64 %t39, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2flineedit_2eclass(i8 %a0) #0 {
entry:
  %l0 = alloca i8
  %l3 = alloca i1
  %l6 = alloca i1
  %l12 = alloca i1
  %l15 = alloca i1
  %l18 = alloca i1
  %l21 = alloca i1
  %l24 = alloca i1
  %l27 = alloca i1
  %l30 = alloca i1
  %rv = alloca i64
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i8, ptr %l0, !tbaa !22
  %t3 = icmp eq i8 %t1, 32
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i8, ptr %l0, !tbaa !22
  %t7 = icmp eq i8 %t5, 9
  store i1 %t7, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb6
bb5:
  %t10 = load i8, ptr %l0, !tbaa !22
  %t12 = icmp eq i8 %t10, 10
  store i1 %t12, ptr %l6, !tbaa !21
  br label %bb6
bb6:
  %t14 = load i1, ptr %l6, !tbaa !21
  br i1 %t14, label %bb7, label %bb8
bb7:
  store i64 0, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t16 = load i8, ptr %l0, !tbaa !22
  %t18 = icmp uge i8 %t16, 97
  br i1 %t18, label %bb10, label %bb11
bb10:
  %t20 = load i8, ptr %l0, !tbaa !22
  %t22 = icmp ule i8 %t20, 122
  store i1 %t22, ptr %l12, !tbaa !21
  br label %bb12
bb11:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb12
bb12:
  %t24 = load i1, ptr %l12, !tbaa !21
  br i1 %t24, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb18
bb14:
  %t25 = load i8, ptr %l0, !tbaa !22
  %t27 = icmp uge i8 %t25, 65
  br i1 %t27, label %bb15, label %bb16
bb15:
  %t29 = load i8, ptr %l0, !tbaa !22
  %t31 = icmp ule i8 %t29, 90
  store i1 %t31, ptr %l18, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb17
bb17:
  %t33 = load i1, ptr %l18, !tbaa !21
  store i1 %t33, ptr %l15, !tbaa !21
  br label %bb18
bb18:
  %t34 = load i1, ptr %l15, !tbaa !21
  br i1 %t34, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb24
bb20:
  %t35 = load i8, ptr %l0, !tbaa !22
  %t37 = icmp uge i8 %t35, 48
  br i1 %t37, label %bb21, label %bb22
bb21:
  %t39 = load i8, ptr %l0, !tbaa !22
  %t41 = icmp ule i8 %t39, 57
  store i1 %t41, ptr %l24, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb23
bb23:
  %t43 = load i1, ptr %l24, !tbaa !21
  store i1 %t43, ptr %l21, !tbaa !21
  br label %bb24
bb24:
  %t44 = load i1, ptr %l21, !tbaa !21
  br i1 %t44, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb27
bb26:
  %t45 = load i8, ptr %l0, !tbaa !22
  %t47 = icmp eq i8 %t45, 95
  store i1 %t47, ptr %l27, !tbaa !21
  br label %bb27
bb27:
  %t49 = load i1, ptr %l27, !tbaa !21
  br i1 %t49, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb30
bb29:
  %t50 = load i8, ptr %l0, !tbaa !22
  %t52 = icmp uge i8 %t50, -128
  store i1 %t52, ptr %l30, !tbaa !21
  br label %bb30
bb30:
  %t54 = load i1, ptr %l30, !tbaa !21
  br i1 %t54, label %bb31, label %bb32
bb31:
  store i64 1, ptr %rv
  br label %ret
bb32:
  br label %bb33
bb33:
  store i64 2, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eBegin(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2ereset(ptr %v0, ptr %t1)
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2edraw(ptr %v0, ptr %t3)
  br label %bb2
bb2:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eFeed(ptr %v0, ptr %a0, i8 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l8 = alloca i32
  %l15 = alloca i1
  %l18 = alloca i1
  %l21 = alloca i1
  %l22 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lineedit:Editor", ptr %t1, i32 0, i32 19
  store i1 false, ptr %t3, !tbaa !21
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/lineedit:Editor", ptr %t4, i32 0, i32 20
  store i1 false, ptr %t6, !tbaa !21
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t12 = call i32 @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2estep(ptr %v0, ptr %t7, i8 %a1)
  store i32 %t12, ptr %l8
  br label %bb1
bb1:
  %t13 = load i32, ptr %l8, !range !{i32 0, i32 4}
  store i32 %t13, ptr %l2
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/lineedit:Editor", ptr %t14, i32 0, i32 19
  %t17 = load i1, ptr %t16, !tbaa !21
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb2, label %bb3
bb2:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/lineedit:Editor", ptr %t21, i32 0, i32 18
  store i64 0, ptr %t23, !tbaa !24
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t24 = load i32, ptr %l2, !range !{i32 0, i32 4}
  %t26 = trunc i64 0 to i32
  %t27 = icmp eq i32 %t24, %t26
  br i1 %t27, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb7
bb6:
  %t29 = load i32, ptr %l2, !range !{i32 0, i32 4}
  %t31 = trunc i64 2 to i32
  %t32 = icmp eq i32 %t29, %t31
  store i1 %t32, ptr %l15, !tbaa !21
  br label %bb7
bb7:
  %t34 = load i1, ptr %l15, !tbaa !21
  br i1 %t34, label %bb8, label %bb9
bb8:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/lineedit:Editor", ptr %t35, i32 0, i32 15
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  %t40 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t38, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d24, i32 0, i32 1) })
  store i1 %t40, ptr %l21
  br label %bb10
bb9:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb11
bb10:
  %t41 = load i1, ptr %l21, !tbaa !21
  store i1 %t41, ptr %l18, !tbaa !21
  br label %bb11
bb11:
  %t42 = load i1, ptr %l18, !tbaa !21
  br i1 %t42, label %bb12, label %bb13
bb12:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/lineedit:Editor", ptr %t43, i32 0, i32 20
  %t46 = load i1, ptr %t45, !tbaa !21
  %t48 = xor i1 %t46, true
  store i1 %t48, ptr %l22, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb14
bb14:
  %t50 = load i1, ptr %l22, !tbaa !21
  br i1 %t50, label %bb15, label %bb16
bb15:
  %t51 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2edraw(ptr %v0, ptr %t51)
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb18
bb18:
  %t53 = load i32, ptr %l2, !range !{i32 0, i32 4}
  call void @__olang_scope_close(ptr %s0)
  store i32 %t53, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eacceptSearch(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i1
  %l6 = alloca ptr
  %l9 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lineedit:Editor", ptr %t1, i32 0, i32 21
  store i1 false, ptr %t3, !tbaa !21
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/lineedit:Editor", ptr %t4, i32 0, i32 25
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  %t9 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t7, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d25, i32 0, i32 1) })
  store i1 %t9, ptr %l4
  br label %bb1
bb1:
  %t10 = load i1, ptr %l4, !tbaa !21
  %t11 = xor i1 %t10, true
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l6, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/lineedit:Editor", ptr %t14, i32 0, i32 25
  %t17 = load { i64, ptr }, ptr %t16, !tbaa !27
  %t18 = load ptr, ptr %l6, !tbaa !29
  %t19 = getelementptr %"compiler/lineedit:Editor", ptr %t18, i32 0, i32 26
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  store { i64, ptr } %t20, ptr %l9, !tbaa !27
  %t22 = load ptr, ptr %l6, !tbaa !29
  %t23 = getelementptr %"compiler/lineedit:Editor", ptr %t22, i32 0, i32 26
  store { i64, ptr } %t17, ptr %t23, !tbaa !27
  %t24 = load i1, ptr @olang_2esole_2ecompiler_2flineedit_3aEditor_2e26
  br i1 %t24, label %bb4, label %bb5
bb3:
  br label %bb6
bb4:
  %t26 = load { i64, ptr }, ptr %l9
  %t27 = extractvalue { i64, ptr } %t26, 1
  call void @__olang_region_release(ptr %t27)
  store { i64, ptr } zeroinitializer, ptr %l9
  br label %bb5
bb5:
  br label %bb6
bb6:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/lineedit:Editor", ptr %t28, i32 0, i32 5
  %t31 = load i1, ptr %t30, !tbaa !21
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t33 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eclamp(ptr %v0, ptr %t33)
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2ebeginSearch(ptr %v0, ptr %a0, i1 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l21 = alloca ptr
  %l23 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lineedit:Editor", ptr %t1, i32 0, i32 21
  store i1 true, ptr %t3, !tbaa !21
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lineedit:Editor", ptr %t4, i32 0, i32 23
  store i1 %a2, ptr %t8, !tbaa !21
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/lineedit:Editor", ptr %t9, i32 0, i32 24
  store i1 %a1, ptr %t13, !tbaa !21
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l11, !tbaa !29
  %t15 = load ptr, ptr %l11, !tbaa !29
  %t16 = getelementptr %"compiler/lineedit:Editor", ptr %t15, i32 0, i32 25
  %t17 = load { i64, ptr }, ptr %t16, !tbaa !27
  store { i64, ptr } %t17, ptr %l12, !tbaa !27
  %t18 = load ptr, ptr %l11, !tbaa !29
  %t19 = getelementptr %"compiler/lineedit:Editor", ptr %t18, i32 0, i32 25
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d26, i32 0, i32 1) }, ptr %t19, !tbaa !27
  %t20 = load i1, ptr @olang_2esole_2ecompiler_2flineedit_3aEditor_2e25
  br i1 %t20, label %bb1, label %bb2
bb1:
  %t22 = load { i64, ptr }, ptr %l12
  %t23 = extractvalue { i64, ptr } %t22, 1
  call void @__olang_region_release(ptr %t23)
  store { i64, ptr } zeroinitializer, ptr %l12
  br label %bb2
bb2:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/lineedit:Editor", ptr %t24, i32 0, i32 28
  store i1 false, ptr %t26, !tbaa !21
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/lineedit:Editor", ptr %t27, i32 0, i32 3
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !27
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/lineedit:Editor", ptr %t32, i32 0, i32 4
  %t35 = load i64, ptr %t34, !tbaa !24
  store i64 %t35, ptr %l4, !tbaa !24
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/lineedit:Editor", ptr %t37, i32 0, i32 12
  %t40 = load i64, ptr %t39, !tbaa !24
  store i64 %t40, ptr %l5, !tbaa !24
  %t42 = load ptr, ptr %l0, !tbaa !29
  store ptr %t42, ptr %l21, !tbaa !29
  %t44 = load ptr, ptr %l21, !tbaa !29
  %t45 = getelementptr %"compiler/lineedit:Editor", ptr %t44, i32 0, i32 29
  %t46 = load { i64, ptr }, ptr %t45, !tbaa !27
  store { i64, ptr } %t46, ptr %l23, !tbaa !27
  %t48 = load ptr, ptr %l21, !tbaa !29
  %t49 = getelementptr %"compiler/lineedit:Editor", ptr %t48, i32 0, i32 29
  store { i64, ptr } %t30, ptr %t49, !tbaa !27
  %t50 = load i1, ptr @olang_2esole_2ecompiler_2flineedit_3aEditor_2e29
  br i1 %t50, label %bb3, label %bb4
bb3:
  %t52 = load { i64, ptr }, ptr %l23
  %t53 = extractvalue { i64, ptr } %t52, 1
  call void @__olang_region_release(ptr %t53)
  store { i64, ptr } zeroinitializer, ptr %l23
  br label %bb4
bb4:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load i64, ptr %l4, !tbaa !24
  %t58 = getelementptr %"compiler/lineedit:Editor", ptr %t54, i32 0, i32 30
  store i64 %t55, ptr %t58, !tbaa !24
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load i64, ptr %l5, !tbaa !24
  %t63 = getelementptr %"compiler/lineedit:Editor", ptr %t59, i32 0, i32 31
  store i64 %t60, ptr %t63, !tbaa !24
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/lineedit:Editor", ptr %t65, i32 0, i32 12
  %t68 = load i64, ptr %t67, !tbaa !24
  %t71 = getelementptr %"compiler/lineedit:Editor", ptr %t64, i32 0, i32 27
  store i64 %t68, ptr %t71, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eclamp(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l7 = alloca i64
  %l9 = alloca i1
  %l11 = alloca i64
  %l16 = alloca i64
  %l18 = alloca ptr
  %l23 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lineedit:Editor", ptr %t1, i32 0, i32 4
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %l2, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/lineedit:Editor", ptr %t5, i32 0, i32 3
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/lineedit:Editor", ptr %t9, i32 0, i32 4
  %t12 = load i64, ptr %t11, !tbaa !24
  %t15 = call i64 @compiler_2flineedit_2elineEnd(ptr %v0, { i64, ptr } %t8, i64 %t12)
  store i64 %t15, ptr %l7
  br label %bb1
bb1:
  %t16 = load i64, ptr %l2, !tbaa !24
  %t17 = load i64, ptr %l7, !tbaa !24
  %t18 = icmp eq i64 %t16, %t17
  br i1 %t18, label %bb2, label %bb3
bb2:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/lineedit:Editor", ptr %t20, i32 0, i32 4
  %t23 = load i64, ptr %t22, !tbaa !24
  store i64 %t23, ptr %l11, !tbaa !24
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/lineedit:Editor", ptr %t24, i32 0, i32 3
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/lineedit:Editor", ptr %t28, i32 0, i32 4
  %t31 = load i64, ptr %t30, !tbaa !24
  %t34 = call i64 @compiler_2flineedit_2elineStart(ptr %v0, { i64, ptr } %t27, i64 %t31)
  store i64 %t34, ptr %l16
  br label %bb4
bb3:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb5
bb4:
  %t35 = load i64, ptr %l11, !tbaa !24
  %t36 = load i64, ptr %l16, !tbaa !24
  %t37 = icmp sgt i64 %t35, %t36
  store i1 %t37, ptr %l9, !tbaa !21
  br label %bb5
bb5:
  %t39 = load i1, ptr %l9, !tbaa !21
  br i1 %t39, label %bb6, label %bb7
bb6:
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l18, !tbaa !29
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/lineedit:Editor", ptr %t41, i32 0, i32 3
  %t44 = load { i64, ptr }, ptr %t43, !tbaa !27
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/lineedit:Editor", ptr %t45, i32 0, i32 4
  %t48 = load i64, ptr %t47, !tbaa !24
  %t51 = call i64 @compiler_2flineedit_2eprevAt(ptr %v0, { i64, ptr } %t44, i64 %t48)
  store i64 %t51, ptr %l23
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t52 = load i64, ptr %l23, !tbaa !24
  %t53 = load ptr, ptr %l18, !tbaa !29
  %t54 = getelementptr %"compiler/lineedit:Editor", ptr %t53, i32 0, i32 4
  store i64 %t52, ptr %t54, !tbaa !24
  br label %bb9
bb9:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2econtrol(ptr %v0, ptr %a0, i8 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i8
  %l2 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l11 = alloca i64
  %l14 = alloca ptr
  %l18 = alloca i64
  %l21 = alloca ptr
  %l23 = alloca i64
  %l26 = alloca ptr
  %l28 = alloca i64
  %l37 = alloca ptr
  %l39 = alloca i64
  %l43 = alloca i64
  %l46 = alloca i1
  %l49 = alloca ptr
  %l53 = alloca i64
  %l58 = alloca ptr
  %l60 = alloca i64
  %l64 = alloca i64
  %l67 = alloca ptr
  %l71 = alloca i64
  %l76 = alloca ptr
  %l80 = alloca i64
  %s15 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i8 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lineedit:Editor", ptr %t1, i32 0, i32 3
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t6 = load i8, ptr %l1, !tbaa !22
  %t8 = icmp eq i8 %t6, 1
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l7, !tbaa !29
  %t11 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/lineedit:Editor", ptr %t12, i32 0, i32 4
  %t15 = load i64, ptr %t14, !tbaa !24
  %t18 = call i64 @compiler_2flineedit_2elineStart(ptr %v0, { i64, ptr } %t11, i64 %t15)
  store i64 %t18, ptr %l11
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t19 = load i64, ptr %l11, !tbaa !24
  %t20 = load ptr, ptr %l7, !tbaa !29
  %t21 = getelementptr %"compiler/lineedit:Editor", ptr %t20, i32 0, i32 4
  store i64 %t19, ptr %t21, !tbaa !24
  br label %bb4
bb4:
  %t22 = load i8, ptr %l1, !tbaa !22
  %t24 = icmp eq i8 %t22, 5
  br i1 %t24, label %bb5, label %bb6
bb5:
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l14, !tbaa !29
  %t27 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/lineedit:Editor", ptr %t28, i32 0, i32 4
  %t31 = load i64, ptr %t30, !tbaa !24
  %t34 = call i64 @compiler_2flineedit_2elineEnd(ptr %v0, { i64, ptr } %t27, i64 %t31)
  store i64 %t34, ptr %l18
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t35 = load i64, ptr %l18, !tbaa !24
  %t36 = load ptr, ptr %l14, !tbaa !29
  %t37 = getelementptr %"compiler/lineedit:Editor", ptr %t36, i32 0, i32 4
  store i64 %t35, ptr %t37, !tbaa !24
  br label %bb8
bb8:
  %t38 = load i8, ptr %l1, !tbaa !22
  %t40 = icmp eq i8 %t38, 2
  br i1 %t40, label %bb9, label %bb10
bb9:
  %t42 = load ptr, ptr %l0, !tbaa !29
  store ptr %t42, ptr %l21, !tbaa !29
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = call i64 @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eleft(ptr %v0, ptr %t43)
  store i64 %t45, ptr %l23
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t46 = load i64, ptr %l23, !tbaa !24
  %t47 = load ptr, ptr %l21, !tbaa !29
  %t48 = getelementptr %"compiler/lineedit:Editor", ptr %t47, i32 0, i32 4
  store i64 %t46, ptr %t48, !tbaa !24
  br label %bb12
bb12:
  %t49 = load i8, ptr %l1, !tbaa !22
  %t51 = icmp eq i8 %t49, 6
  br i1 %t51, label %bb13, label %bb14
bb13:
  %t53 = load ptr, ptr %l0, !tbaa !29
  store ptr %t53, ptr %l26, !tbaa !29
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = call i64 @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eright(ptr %v0, ptr %t54)
  store i64 %t56, ptr %l28
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t57 = load i64, ptr %l28, !tbaa !24
  %t58 = load ptr, ptr %l26, !tbaa !29
  %t59 = getelementptr %"compiler/lineedit:Editor", ptr %t58, i32 0, i32 4
  store i64 %t57, ptr %t59, !tbaa !24
  br label %bb16
bb16:
  %t60 = load i8, ptr %l1, !tbaa !22
  %t62 = icmp eq i8 %t60, 16
  br i1 %t62, label %bb17, label %bb18
bb17:
  %t64 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eup(ptr %v0, ptr %t64)
  br label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb20
bb20:
  %t66 = load i8, ptr %l1, !tbaa !22
  %t68 = icmp eq i8 %t66, 14
  br i1 %t68, label %bb21, label %bb22
bb21:
  %t70 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2edown(ptr %v0, ptr %t70)
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb24
bb24:
  %t72 = load i8, ptr %l1, !tbaa !22
  %t74 = icmp eq i8 %t72, 4
  br i1 %t74, label %bb25, label %bb26
bb25:
  %t76 = load ptr, ptr %l0, !tbaa !29
  store ptr %t76, ptr %l37, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/lineedit:Editor", ptr %t77, i32 0, i32 4
  %t80 = load i64, ptr %t79, !tbaa !24
  store i64 %t80, ptr %l39, !tbaa !24
  %t81 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/lineedit:Editor", ptr %t82, i32 0, i32 4
  %t85 = load i64, ptr %t84, !tbaa !24
  %t88 = call i64 @compiler_2flineedit_2enextAt(ptr %v0, { i64, ptr } %t81, i64 %t85)
  store i64 %t88, ptr %l43
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t89 = load ptr, ptr %l37, !tbaa !29
  %t90 = load i64, ptr %l39, !tbaa !24
  %t91 = load i64, ptr %l43, !tbaa !24
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eremove(ptr %v0, ptr %t89, i64 %t90, i64 %t91, i1 false)
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t92 = load i8, ptr %l1, !tbaa !22
  %t94 = icmp eq i8 %t92, 8
  br i1 %t94, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb32
bb31:
  %t96 = load i8, ptr %l1, !tbaa !22
  %t98 = icmp eq i8 %t96, 127
  store i1 %t98, ptr %l46, !tbaa !21
  br label %bb32
bb32:
  %t100 = load i1, ptr %l46, !tbaa !21
  br i1 %t100, label %bb33, label %bb34
bb33:
  %t101 = load ptr, ptr %l0, !tbaa !29
  store ptr %t101, ptr %l49, !tbaa !29
  %t102 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/lineedit:Editor", ptr %t103, i32 0, i32 4
  %t106 = load i64, ptr %t105, !tbaa !24
  %t109 = call i64 @compiler_2flineedit_2eprevAt(ptr %v0, { i64, ptr } %t102, i64 %t106)
  store i64 %t109, ptr %l53
  br label %bb35
bb34:
  br label %bb37
bb35:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/lineedit:Editor", ptr %t110, i32 0, i32 4
  %t113 = load i64, ptr %t112, !tbaa !24
  %t114 = load ptr, ptr %l49, !tbaa !29
  %t115 = load i64, ptr %l53, !tbaa !24
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eremove(ptr %v0, ptr %t114, i64 %t115, i64 %t113, i1 false)
  br label %bb36
bb36:
  br label %bb37
bb37:
  %t117 = load i8, ptr %l1, !tbaa !22
  %t119 = icmp eq i8 %t117, 11
  br i1 %t119, label %bb38, label %bb39
bb38:
  %t121 = load ptr, ptr %l0, !tbaa !29
  store ptr %t121, ptr %l58, !tbaa !29
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/lineedit:Editor", ptr %t122, i32 0, i32 4
  %t125 = load i64, ptr %t124, !tbaa !24
  store i64 %t125, ptr %l60, !tbaa !24
  %t126 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/lineedit:Editor", ptr %t127, i32 0, i32 4
  %t130 = load i64, ptr %t129, !tbaa !24
  %t133 = call i64 @compiler_2flineedit_2elineEnd(ptr %v0, { i64, ptr } %t126, i64 %t130)
  store i64 %t133, ptr %l64
  br label %bb40
bb39:
  br label %bb42
bb40:
  %t134 = load ptr, ptr %l58, !tbaa !29
  %t135 = load i64, ptr %l60, !tbaa !24
  %t136 = load i64, ptr %l64, !tbaa !24
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eremove(ptr %v0, ptr %t134, i64 %t135, i64 %t136, i1 true)
  br label %bb41
bb41:
  br label %bb42
bb42:
  %t137 = load i8, ptr %l1, !tbaa !22
  %t139 = icmp eq i8 %t137, 21
  br i1 %t139, label %bb43, label %bb44
bb43:
  %t141 = load ptr, ptr %l0, !tbaa !29
  store ptr %t141, ptr %l67, !tbaa !29
  %t142 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/lineedit:Editor", ptr %t143, i32 0, i32 4
  %t146 = load i64, ptr %t145, !tbaa !24
  %t149 = call i64 @compiler_2flineedit_2elineStart(ptr %v0, { i64, ptr } %t142, i64 %t146)
  store i64 %t149, ptr %l71
  br label %bb45
bb44:
  br label %bb47
bb45:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/lineedit:Editor", ptr %t150, i32 0, i32 4
  %t153 = load i64, ptr %t152, !tbaa !24
  %t154 = load ptr, ptr %l67, !tbaa !29
  %t155 = load i64, ptr %l71, !tbaa !24
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eremove(ptr %v0, ptr %t154, i64 %t155, i64 %t153, i1 true)
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t157 = load i8, ptr %l1, !tbaa !22
  %t159 = icmp eq i8 %t157, 23
  br i1 %t159, label %bb48, label %bb49
bb48:
  %t161 = load ptr, ptr %l0, !tbaa !29
  store ptr %t161, ptr %l76, !tbaa !29
  %t162 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t165 = getelementptr %"compiler/lineedit:Editor", ptr %t163, i32 0, i32 4
  %t166 = load i64, ptr %t165, !tbaa !24
  %t169 = call i64 @compiler_2flineedit_2ewordBack(ptr %v0, { i64, ptr } %t162, i64 %t166)
  store i64 %t169, ptr %l80
  br label %bb50
bb49:
  br label %bb52
bb50:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/lineedit:Editor", ptr %t170, i32 0, i32 4
  %t173 = load i64, ptr %t172, !tbaa !24
  %t174 = load ptr, ptr %l76, !tbaa !29
  %t175 = load i64, ptr %l80, !tbaa !24
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eremove(ptr %v0, ptr %t174, i64 %t175, i64 %t173, i1 true)
  br label %bb51
bb51:
  br label %bb52
bb52:
  %t177 = load i8, ptr %l1, !tbaa !22
  %t179 = icmp eq i8 %t177, 25
  br i1 %t179, label %bb53, label %bb54
bb53:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr %"compiler/lineedit:Editor", ptr %t182, i32 0, i32 16
  %t185 = load { i64, ptr }, ptr %t184, !tbaa !27
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2einsert(ptr %v0, ptr %v0, ptr %t181, { i64, ptr } %t185)
  br label %bb55
bb54:
  br label %bb56
bb55:
  br label %bb56
bb56:
  %t188 = load i8, ptr %l1, !tbaa !22
  %t190 = icmp eq i8 %t188, 31
  br i1 %t190, label %bb57, label %bb58
bb57:
  %t192 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eundo(ptr %v0, ptr %t192)
  br label %bb59
bb58:
  br label %bb60
bb59:
  br label %bb60
bb60:
  %t194 = load i8, ptr %l1, !tbaa !22
  %t196 = icmp eq i8 %t194, 18
  br i1 %t196, label %bb61, label %bb62
bb61:
  %t198 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2ebeginSearch(ptr %v0, ptr %t198, i1 true, i1 false)
  br label %bb63
bb62:
  br label %bb64
bb63:
  br label %bb64
bb64:
  %t200 = load i8, ptr %l1, !tbaa !22
  %t202 = icmp eq i8 %t200, 12
  br i1 %t202, label %bb65, label %bb66
bb65:
  store %olang.scope zeroinitializer, ptr %s15
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t206 = getelementptr %"compiler/lineedit:Editor", ptr %t204, i32 0, i32 6
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s15, ptr %t206, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d27, i32 0, i32 1) })
  br label %bb67
bb66:
  br label %bb68
bb67:
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/lineedit:Editor", ptr %t208, i32 0, i32 14
  store i64 0, ptr %t210, !tbaa !24
  call void @__olang_scope_close(ptr %s15)
  br label %bb68
bb68:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2edown(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l8 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l17 = alloca i64
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l26 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lineedit:Editor", ptr %t1, i32 0, i32 3
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l1, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/lineedit:Editor", ptr %t7, i32 0, i32 4
  %t10 = load i64, ptr %t9, !tbaa !24
  %t13 = call i64 @compiler_2flineedit_2elineEnd(ptr %v0, { i64, ptr } %t6, i64 %t10)
  store i64 %t13, ptr %l8
  br label %bb1
bb1:
  %t14 = load i64, ptr %l8, !tbaa !24
  store i64 %t14, ptr %l2, !tbaa !24
  %t15 = load i64, ptr %l2, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  %t21 = icmp eq i64 %t15, %t18
  br i1 %t21, label %bb2, label %bb3
bb2:
  %t23 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2enewer(ptr %v0, ptr %t23)
  br label %bb4
bb3:
  br label %bb5
bb4:
  br label %ret
bb5:
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l14, !tbaa !29
  %t26 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t26, ptr %l15, !tbaa !27
  %t27 = load i64, ptr %l2, !tbaa !24
  %t29 = add i64 %t27, 1
  store i64 %t29, ptr %l17, !tbaa !24
  %t30 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t31 = load i64, ptr %l2, !tbaa !24
  %t33 = add i64 %t31, 1
  %t36 = call i64 @compiler_2flineedit_2elineEnd(ptr %v0, { i64, ptr } %t30, i64 %t33)
  store i64 %t36, ptr %l21
  br label %bb6
bb6:
  %t37 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t37, ptr %l22, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/lineedit:Editor", ptr %t39, i32 0, i32 4
  %t42 = load i64, ptr %t41, !tbaa !24
  %t45 = call i64 @compiler_2flineedit_2elineStart(ptr %v0, { i64, ptr } %t38, i64 %t42)
  store i64 %t45, ptr %l26
  br label %bb7
bb7:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/lineedit:Editor", ptr %t46, i32 0, i32 4
  %t49 = load i64, ptr %t48, !tbaa !24
  store i64 %t49, ptr %l28, !tbaa !24
  %t50 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t50, 0
  store i64 %t51, ptr %l29, !tbaa !24
  %t52 = load i64, ptr %l26, !tbaa !24
  %t53 = icmp sge i64 %t52, 0
  br i1 %t53, label %bb8, label %bb9
bb8:
  %t55 = load i64, ptr %l26, !tbaa !24
  %t56 = load i64, ptr %l28, !tbaa !24
  %t57 = icmp sle i64 %t55, %t56
  br i1 %t57, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_22a9a5775aa8f43a_f3d22121f345f80e)
  unreachable
bb10:
  %t59 = load i64, ptr %l28, !tbaa !24
  %t60 = load i64, ptr %l29, !tbaa !24
  %t61 = icmp sle i64 %t59, %t60
  br i1 %t61, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_22a9a5775aa8f43a_f3d22121f345f80e)
  unreachable
bb12:
  %t63 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = load i64, ptr %l26, !tbaa !24
  %t66 = load i64, ptr %l28, !tbaa !24
  %t67 = getelementptr i8, ptr %t64, i64 %t65
  %t68 = sub i64 %t66, %t65
  %t69 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t70 = insertvalue { i64, ptr } %t69, ptr %t67, 1
  %t72 = call i64 @compiler_2flineedit_2ecells(ptr %v0, { i64, ptr } %t70)
  store i64 %t72, ptr %l34
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_22a9a5775aa8f43a_f3d22121f345f80e)
  unreachable
bb14:
  %t73 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t74 = load i64, ptr %l17, !tbaa !24
  %t75 = load i64, ptr %l21, !tbaa !24
  %t76 = load i64, ptr %l34, !tbaa !24
  %t77 = call i64 @compiler_2flineedit_2eoffsetOf(ptr %v0, { i64, ptr } %t73, i64 %t74, i64 %t75, i64 %t76)
  store i64 %t77, ptr %l35
  br label %bb15
bb15:
  %t78 = load i64, ptr %l35, !tbaa !24
  %t79 = load ptr, ptr %l14, !tbaa !29
  %t80 = getelementptr %"compiler/lineedit:Editor", ptr %t79, i32 0, i32 4
  store i64 %t78, ptr %t80, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eescape(ptr %v0, ptr %a0, i8 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i8
  %l2 = alloca { i64, ptr }
  %l5 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l17 = alloca i32
  %l18 = alloca ptr
  %l19 = alloca i64
  %l22 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l33 = alloca i1
  %l36 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca { i64, ptr }
  %l50 = alloca ptr
  %l51 = alloca { i64, ptr }
  %l58 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i8 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lineedit:Editor", ptr %t1, i32 0, i32 15
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t4, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) })
  store i1 %t6, ptr %l5
  br label %bb1
bb1:
  %t7 = load i1, ptr %l5, !tbaa !21
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t8 = load i8, ptr %l1, !tbaa !22
  %t10 = icmp ne i8 %t8, 91
  store i1 %t10, ptr %l6, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb4
bb4:
  %t12 = load i1, ptr %l6, !tbaa !21
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t13 = load i8, ptr %l1, !tbaa !22
  %t15 = icmp ne i8 %t13, 79
  store i1 %t15, ptr %l9, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb7
bb7:
  %t17 = load i1, ptr %l9, !tbaa !21
  br i1 %t17, label %bb8, label %bb9
bb8:
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %l12, !tbaa !29
  %t19 = load ptr, ptr %l12, !tbaa !29
  %t20 = getelementptr %"compiler/lineedit:Editor", ptr %t19, i32 0, i32 15
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l13, !tbaa !27
  %t22 = load ptr, ptr %l12, !tbaa !29
  %t23 = getelementptr %"compiler/lineedit:Editor", ptr %t22, i32 0, i32 15
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d29, i32 0, i32 1) }, ptr %t23, !tbaa !27
  %t24 = load i1, ptr @olang_2esole_2ecompiler_2flineedit_3aEditor_2e15
  br i1 %t24, label %bb10, label %bb11
bb9:
  br label %bb13
bb10:
  %t26 = load { i64, ptr }, ptr %l13
  %t27 = extractvalue { i64, ptr } %t26, 1
  call void @__olang_region_release(ptr %t27)
  store { i64, ptr } zeroinitializer, ptr %l13
  br label %bb11
bb11:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i8, ptr %l1, !tbaa !22
  %t32 = call i32 @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2emeta(ptr %v0, ptr %t28, i8 %t29)
  store i32 %t32, ptr %l17
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s0)
  %t33 = load i32, ptr %l17, !range !{i32 0, i32 4}
  store i32 %t33, ptr %rv
  br label %ret
bb13:
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l18, !tbaa !29
  %t35 = call ptr @__olang_scope_hold(ptr %v0)
  %t36 = ptrtoint ptr %t35 to i64
  store i64 %t36, ptr %l19, !tbaa !24
  %t37 = load i1, ptr @olang_2esole_2ecompiler_2flineedit_3aEditor_2e15
  br i1 %t37, label %bb14, label %bb15
bb14:
  %t39 = call ptr @__olang_region_make(ptr %v0)
  %t40 = ptrtoint ptr %t39 to i64
  store i64 %t40, ptr %l19, !tbaa !24
  br label %bb15
bb15:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/lineedit:Editor", ptr %t41, i32 0, i32 15
  %t44 = load { i64, ptr }, ptr %t43, !tbaa !27
  store { i64, ptr } %t44, ptr %l22, !tbaa !27
  %t45 = load i8, ptr %l1, !tbaa !22
  %t47 = call { i64, ptr } @compiler_2flineedit_2eone(ptr %s0, i8 %t45)
  store { i64, ptr } %t47, ptr %l24
  br label %bb16
bb16:
  %t48 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t48, 1
  %t50 = extractvalue { i64, ptr } %t48, 0
  %t51 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t51, 1
  %t53 = extractvalue { i64, ptr } %t51, 0
  %t54 = add i64 %t50, %t53
  %t55 = load i64, ptr %l19
  %t56 = inttoptr i64 %t55 to ptr
  %t57 = call ptr @__olang_held_alloc(ptr %t56, i64 %t54)
  call void @olang_textcopy(ptr %t57, ptr %t49, i64 %t50)
  %t58 = getelementptr i8, ptr %t57, i64 %t50
  call void @olang_textcopy(ptr %t58, ptr %t52, i64 %t53)
  %t59 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t57, 1
  %t62 = load ptr, ptr %l18, !tbaa !29
  %t63 = getelementptr %"compiler/lineedit:Editor", ptr %t62, i32 0, i32 15
  %t64 = load { i64, ptr }, ptr %t63, !tbaa !27
  store { i64, ptr } %t64, ptr %l27, !tbaa !27
  %t66 = load ptr, ptr %l18, !tbaa !29
  %t67 = getelementptr %"compiler/lineedit:Editor", ptr %t66, i32 0, i32 15
  store { i64, ptr } %t60, ptr %t67, !tbaa !27
  %t68 = load i1, ptr @olang_2esole_2ecompiler_2flineedit_3aEditor_2e15
  br i1 %t68, label %bb17, label %bb18
bb17:
  %t70 = load { i64, ptr }, ptr %l27
  %t71 = extractvalue { i64, ptr } %t70, 1
  call void @__olang_region_release(ptr %t71)
  store { i64, ptr } zeroinitializer, ptr %l27
  br label %bb18
bb18:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/lineedit:Editor", ptr %t72, i32 0, i32 15
  %t75 = load { i64, ptr }, ptr %t74, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t75, 0
  %t79 = icmp sle i64 %t77, 2
  br i1 %t79, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb21
bb20:
  %t81 = load i8, ptr %l1, !tbaa !22
  %t83 = icmp ult i8 %t81, 64
  store i1 %t83, ptr %l33, !tbaa !21
  br label %bb21
bb21:
  %t85 = load i1, ptr %l33, !tbaa !21
  br i1 %t85, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb24
bb23:
  %t86 = load i8, ptr %l1, !tbaa !22
  %t88 = icmp ugt i8 %t86, 126
  store i1 %t88, ptr %l36, !tbaa !21
  br label %bb24
bb24:
  %t90 = load i1, ptr %l36, !tbaa !21
  br i1 %t90, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/lineedit:Editor", ptr %t92, i32 0, i32 15
  %t95 = load { i64, ptr }, ptr %t94, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t95, 0
  %t99 = icmp sgt i64 %t97, 16
  br i1 %t99, label %bb28, label %bb29
bb28:
  %t101 = load ptr, ptr %l0, !tbaa !29
  store ptr %t101, ptr %l44, !tbaa !29
  %t102 = load ptr, ptr %l44, !tbaa !29
  %t103 = getelementptr %"compiler/lineedit:Editor", ptr %t102, i32 0, i32 15
  %t104 = load { i64, ptr }, ptr %t103, !tbaa !27
  store { i64, ptr } %t104, ptr %l45, !tbaa !27
  %t105 = load ptr, ptr %l44, !tbaa !29
  %t106 = getelementptr %"compiler/lineedit:Editor", ptr %t105, i32 0, i32 15
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d30, i32 0, i32 1) }, ptr %t106, !tbaa !27
  %t107 = load i1, ptr @olang_2esole_2ecompiler_2flineedit_3aEditor_2e15
  br i1 %t107, label %bb30, label %bb31
bb29:
  br label %bb32
bb30:
  %t109 = load { i64, ptr }, ptr %l45
  %t110 = extractvalue { i64, ptr } %t109, 1
  call void @__olang_region_release(ptr %t110)
  store { i64, ptr } zeroinitializer, ptr %l45
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb32:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/lineedit:Editor", ptr %t112, i32 0, i32 15
  %t115 = load { i64, ptr }, ptr %t114, !tbaa !27
  store { i64, ptr } %t115, ptr %l2, !tbaa !27
  %t117 = load ptr, ptr %l0, !tbaa !29
  store ptr %t117, ptr %l50, !tbaa !29
  %t118 = load ptr, ptr %l50, !tbaa !29
  %t119 = getelementptr %"compiler/lineedit:Editor", ptr %t118, i32 0, i32 15
  %t120 = load { i64, ptr }, ptr %t119, !tbaa !27
  store { i64, ptr } %t120, ptr %l51, !tbaa !27
  %t121 = load ptr, ptr %l50, !tbaa !29
  %t122 = getelementptr %"compiler/lineedit:Editor", ptr %t121, i32 0, i32 15
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d31, i32 0, i32 1) }, ptr %t122, !tbaa !27
  %t123 = load i1, ptr @olang_2esole_2ecompiler_2flineedit_3aEditor_2e15
  br i1 %t123, label %bb33, label %bb34
bb33:
  %t125 = load { i64, ptr }, ptr %l51
  %t126 = extractvalue { i64, ptr } %t125, 1
  call void @__olang_region_release(ptr %t126)
  store { i64, ptr } zeroinitializer, ptr %l51
  br label %bb34
bb34:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/lineedit:Editor", ptr %t127, i32 0, i32 21
  %t130 = load i1, ptr %t129, !tbaa !21
  br i1 %t130, label %bb35, label %bb36
bb35:
  %t132 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eacceptSearch(ptr %v0, ptr %t132)
  br label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb38
bb38:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t138 = call i32 @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2esequence(ptr %v0, ptr %v0, ptr %t134, { i64, ptr } %t135)
  store i32 %t138, ptr %l58
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s0)
  %t139 = load i32, ptr %l58, !range !{i32 0, i32 4}
  store i32 %t139, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2efind(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l9 = alloca i1
  %l10 = alloca i64
  %l13 = alloca i64
  %l19 = alloca { i64, ptr }
  %l22 = alloca i64
  %l31 = alloca ptr
  %l35 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l42 = alloca i64
  %l45 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a1, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l2, !tbaa !24
  %t5 = icmp sge i64 %t3, 0
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t7 = load i64, ptr %l2, !tbaa !24
  store i64 %t7, ptr %l10, !tbaa !24
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/lineedit:Editor", ptr %t8, i32 0, i32 7
  %t12 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t10)
  store i64 %t12, ptr %l13
  br label %bb4
bb3:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb5
bb4:
  %t13 = load i64, ptr %l10, !tbaa !24
  %t14 = load i64, ptr %l13, !tbaa !24
  %t15 = icmp slt i64 %t13, %t14
  store i1 %t15, ptr %l9, !tbaa !21
  br label %bb5
bb5:
  %t17 = load i1, ptr %l9, !tbaa !21
  %t18 = xor i1 %t17, true
  br i1 %t18, label %bb6, label %bb7
bb6:
  br label %bb21
bb7:
  br label %bb8
bb8:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/lineedit:Editor", ptr %t20, i32 0, i32 7
  %t23 = load i64, ptr %l2, !tbaa !24
  %t26 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t22, i64 %t23)
  store { i64, ptr } %t26, ptr %l19
  br label %bb9
bb9:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/lineedit:Editor", ptr %t27, i32 0, i32 25
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t33 = call i64 @compiler_2flineedit_2eindexOf(ptr %v0, ptr %v0, { i64, ptr } %t31, { i64, ptr } %t30)
  store i64 %t33, ptr %l22
  br label %bb10
bb10:
  %t34 = load i64, ptr %l22, !tbaa !24
  store i64 %t34, ptr %l3, !tbaa !24
  %t35 = load i64, ptr %l3, !tbaa !24
  %t37 = icmp sge i64 %t35, 0
  br i1 %t37, label %bb11, label %bb12
bb11:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t41 = load i64, ptr %l2, !tbaa !24
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/lineedit:Editor", ptr %t43, i32 0, i32 27
  store i64 %t39, ptr %t47, !tbaa !24
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/lineedit:Editor", ptr %t48, i32 0, i32 12
  store i64 %t41, ptr %t52, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  store ptr %t53, ptr %l31, !tbaa !29
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/lineedit:Editor", ptr %t54, i32 0, i32 7
  %t57 = load i64, ptr %l2, !tbaa !24
  %t60 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t56, i64 %t57)
  store { i64, ptr } %t60, ptr %l35
  br label %bb13
bb12:
  br label %bb16
bb13:
  %t61 = load ptr, ptr %l31, !tbaa !29
  %t62 = getelementptr %"compiler/lineedit:Editor", ptr %t61, i32 0, i32 3
  %t63 = load { i64, ptr }, ptr %t62, !tbaa !27
  store { i64, ptr } %t63, ptr %l36, !tbaa !27
  %t64 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t65 = load ptr, ptr %l31, !tbaa !29
  %t66 = getelementptr %"compiler/lineedit:Editor", ptr %t65, i32 0, i32 3
  store { i64, ptr } %t64, ptr %t66, !tbaa !27
  %t67 = load i1, ptr @olang_2esole_2ecompiler_2flineedit_3aEditor_2e3
  br i1 %t67, label %bb14, label %bb15
bb14:
  %t69 = load { i64, ptr }, ptr %l36
  %t70 = extractvalue { i64, ptr } %t69, 1
  call void @__olang_region_release(ptr %t70)
  store { i64, ptr } zeroinitializer, ptr %l36
  br label %bb15
bb15:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load i64, ptr %l3, !tbaa !24
  %t75 = getelementptr %"compiler/lineedit:Editor", ptr %t71, i32 0, i32 4
  store i64 %t72, ptr %t75, !tbaa !24
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/lineedit:Editor", ptr %t76, i32 0, i32 28
  store i1 false, ptr %t78, !tbaa !21
  br label %ret
bb16:
  %t79 = load i64, ptr %l2, !tbaa !24
  store i64 %t79, ptr %l42, !tbaa !24
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/lineedit:Editor", ptr %t81, i32 0, i32 24
  %t84 = load i1, ptr %t83, !tbaa !21
  br i1 %t84, label %bb17, label %bb18
bb17:
  store i64 -1, ptr %l45, !tbaa !24
  br label %bb19
bb18:
  store i64 1, ptr %l45, !tbaa !24
  br label %bb19
bb19:
  %t86 = load i64, ptr %l42, !tbaa !24
  %t87 = load i64, ptr %l45, !tbaa !24
  %t88 = add i64 %t86, %t87
  store i64 %t88, ptr %l2, !tbaa !24
  br label %bb20
bb20:
  br label %bb1
bb21:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/lineedit:Editor", ptr %t90, i32 0, i32 28
  store i1 true, ptr %t92, !tbaa !21
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eflush(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l7 = alloca { i64, ptr }
  %l10 = alloca i32
  %l12 = alloca i1
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lineedit:Editor", ptr %t1, i32 0, i32 6
  %t5 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/lineedit:Editor", ptr %t9, i32 0, i32 6
  %t13 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %s0, ptr %t11)
  store { i64, ptr } %t13, ptr %l7
  br label %bb5
bb5:
  %t14 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 0
  %t17 = extractvalue { i64, ptr } %t14, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  %t23 = call i32 @std_2fio_2eWrite(ptr %s0, i32 1, { i64, ptr } %t21)
  store i32 %t23, ptr %l10
  %t24 = icmp ne i32 %t23, 0
  br i1 %t24, label %bb7, label %ok.25, !prof !99
ok.25:
  br label %bb6
bb6:
  br label %bb11
bb7:
  %t26 = load i32, ptr %l10, !tbaa !23
  %t27 = ashr i32 %t26, 16
  %t29 = icmp eq i32 %t27, 1
  store i1 %t29, ptr %l12, !tbaa !21
  %t30 = load i32, ptr %l10, !tbaa !23
  %t31 = ashr i32 %t30, 16
  %t33 = icmp eq i32 %t31, 1
  br i1 %t33, label %bb8, label %bb9
bb8:
  call void @__olang_errpay_pop()
  br label %bb9
bb9:
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/lineedit:Editor", ptr %t35, i32 0, i32 6
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eClear(ptr %v0, ptr %t37)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2einterrupt(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lineedit:Editor", ptr %t1, i32 0, i32 21
  store i1 false, ptr %t3, !tbaa !21
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/lineedit:Editor", ptr %t5, i32 0, i32 3
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t13 = getelementptr %"compiler/lineedit:Editor", ptr %t4, i32 0, i32 4
  store i64 %t10, ptr %t13, !tbaa !24
  %t14 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2edraw(ptr %v0, ptr %t14)
  br label %bb1
bb1:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/lineedit:Editor", ptr %t16, i32 0, i32 6
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t18, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d32, i32 0, i32 1) })
  br label %bb2
bb2:
  %t20 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2ereset(ptr %v0, ptr %t20)
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2ekey(ptr %v0, ptr %a0, i8 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i8
  %l4 = alloca i1
  %l11 = alloca i32
  %l14 = alloca i1
  %l17 = alloca i1
  %l23 = alloca i1
  %l26 = alloca ptr
  %l28 = alloca { i64, ptr }
  %l30 = alloca ptr
  %l35 = alloca i1
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i8 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i8, ptr %l1, !tbaa !22
  %t3 = icmp eq i8 %t1, 13
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i8, ptr %l1, !tbaa !22
  %t7 = icmp eq i8 %t5, 10
  store i1 %t7, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t11 = load i8, ptr %l1, !tbaa !22
  %t13 = icmp eq i8 %t11, 3
  br i1 %t13, label %bb7, label %bb8
bb7:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = call i32 @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2einterrupt(ptr %v0, ptr %t15)
  store i32 %t17, ptr %l11
  br label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t18 = load i32, ptr %l11, !range !{i32 0, i32 4}
  store i32 %t18, ptr %rv
  br label %ret
bb10:
  %t19 = load i8, ptr %l1, !tbaa !22
  %t21 = icmp eq i8 %t19, 4
  br i1 %t21, label %bb11, label %bb12
bb11:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/lineedit:Editor", ptr %t23, i32 0, i32 3
  %t26 = load { i64, ptr }, ptr %t25, !tbaa !27
  %t28 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t26, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d33, i32 0, i32 1) })
  store i1 %t28, ptr %l17
  br label %bb13
bb12:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb14
bb13:
  %t29 = load i1, ptr %l17, !tbaa !21
  store i1 %t29, ptr %l14, !tbaa !21
  br label %bb14
bb14:
  %t30 = load i1, ptr %l14, !tbaa !21
  br i1 %t30, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s0)
  store i32 3, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t32 = load i8, ptr %l1, !tbaa !22
  %t34 = icmp eq i8 %t32, 9
  br i1 %t34, label %bb18, label %bb19
bb18:
  store i8 32, ptr %l1, !tbaa !22
  br label %bb20
bb19:
  br label %bb20
bb20:
  %t36 = load i8, ptr %l1, !tbaa !22
  %t38 = icmp uge i8 %t36, 32
  br i1 %t38, label %bb21, label %bb22
bb21:
  %t40 = load i8, ptr %l1, !tbaa !22
  %t42 = icmp ne i8 %t40, 127
  store i1 %t42, ptr %l23, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb23
bb23:
  %t44 = load i1, ptr %l23, !tbaa !21
  br i1 %t44, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s5
  %t45 = load ptr, ptr %l0, !tbaa !29
  store ptr %t45, ptr %l26, !tbaa !29
  %t46 = load i8, ptr %l1, !tbaa !22
  %t48 = call { i64, ptr } @compiler_2flineedit_2eone(ptr %s5, i8 %t46)
  store { i64, ptr } %t48, ptr %l28
  br label %bb26
bb25:
  br label %bb29
bb26:
  %t49 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t50 = load ptr, ptr %l26, !tbaa !29
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2einsert(ptr %v0, ptr %s5, ptr %t50, { i64, ptr } %t49)
  br label %bb27
bb27:
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %l30, !tbaa !29
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/lineedit:Editor", ptr %t53, i32 0, i32 3
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/lineedit:Editor", ptr %t57, i32 0, i32 4
  %t60 = load i64, ptr %t59, !tbaa !24
  %t63 = call i1 @compiler_2flineedit_2eincomplete(ptr %v0, { i64, ptr } %t56, i64 %t60)
  store i1 %t63, ptr %l35
  br label %bb28
bb28:
  %t64 = load i1, ptr %l35, !tbaa !21
  %t65 = load ptr, ptr %l30, !tbaa !29
  %t66 = getelementptr %"compiler/lineedit:Editor", ptr %t65, i32 0, i32 20
  store i1 %t64, ptr %t66, !tbaa !21
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb29:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i8, ptr %l1, !tbaa !22
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2econtrol(ptr %v0, ptr %t68, i8 %t69)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eleft(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l7 = alloca i64
  %l9 = alloca i64
  %l14 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lineedit:Editor", ptr %t1, i32 0, i32 4
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %l2, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/lineedit:Editor", ptr %t5, i32 0, i32 3
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/lineedit:Editor", ptr %t9, i32 0, i32 4
  %t12 = load i64, ptr %t11, !tbaa !24
  %t15 = call i64 @compiler_2flineedit_2elineStart(ptr %v0, { i64, ptr } %t8, i64 %t12)
  store i64 %t15, ptr %l7
  br label %bb1
bb1:
  %t16 = load i64, ptr %l2, !tbaa !24
  %t17 = load i64, ptr %l7, !tbaa !24
  %t18 = icmp sgt i64 %t16, %t17
  br i1 %t18, label %bb2, label %bb3
bb2:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/lineedit:Editor", ptr %t20, i32 0, i32 3
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/lineedit:Editor", ptr %t24, i32 0, i32 4
  %t27 = load i64, ptr %t26, !tbaa !24
  %t30 = call i64 @compiler_2flineedit_2eprevAt(ptr %v0, { i64, ptr } %t23, i64 %t27)
  store i64 %t30, ptr %l14
  br label %bb4
bb3:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/lineedit:Editor", ptr %t31, i32 0, i32 4
  %t34 = load i64, ptr %t33, !tbaa !24
  store i64 %t34, ptr %l9, !tbaa !24
  br label %bb5
bb4:
  %t36 = load i64, ptr %l14, !tbaa !24
  store i64 %t36, ptr %l9, !tbaa !24
  br label %bb5
bb5:
  %t37 = load i64, ptr %l9, !tbaa !24
  store i64 %t37, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2emeta(ptr %v0, ptr %a0, i8 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i8
  %l7 = alloca i1
  %l16 = alloca i32
  %l19 = alloca ptr
  %l24 = alloca i64
  %l27 = alloca ptr
  %l32 = alloca i64
  %l35 = alloca ptr
  %l37 = alloca i64
  %l42 = alloca i64
  %l45 = alloca i1
  %l48 = alloca ptr
  %l53 = alloca i64
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i8 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lineedit:Editor", ptr %t1, i32 0, i32 21
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eacceptSearch(ptr %v0, ptr %t6)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/lineedit:Editor", ptr %t8, i32 0, i32 0
  %t11 = load i1, ptr %t10, !tbaa !21
  br i1 %t11, label %bb5, label %bb6
bb5:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/lineedit:Editor", ptr %t13, i32 0, i32 5
  %t16 = load i1, ptr %t15, !tbaa !21
  %t18 = xor i1 %t16, true
  store i1 %t18, ptr %l7, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb7
bb7:
  %t20 = load i1, ptr %l7, !tbaa !21
  br i1 %t20, label %bb8, label %bb9
bb8:
  %t21 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2etoNormal(ptr %v0, ptr %t21)
  br label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb11
bb11:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/lineedit:Editor", ptr %t23, i32 0, i32 0
  %t26 = load i1, ptr %t25, !tbaa !21
  br i1 %t26, label %bb12, label %bb13
bb12:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i8, ptr %l1, !tbaa !22
  %t32 = call i32 @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2estep(ptr %v0, ptr %t28, i8 %t29)
  store i32 %t32, ptr %l16
  br label %bb14
bb13:
  br label %bb15
bb14:
  %t33 = load i32, ptr %l16, !range !{i32 0, i32 4}
  store i32 %t33, ptr %rv
  br label %ret
bb15:
  %t34 = load i8, ptr %l1, !tbaa !22
  %t36 = icmp eq i8 %t34, 98
  br i1 %t36, label %bb16, label %bb17
bb16:
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l19, !tbaa !29
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/lineedit:Editor", ptr %t39, i32 0, i32 3
  %t42 = load { i64, ptr }, ptr %t41, !tbaa !27
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/lineedit:Editor", ptr %t43, i32 0, i32 4
  %t46 = load i64, ptr %t45, !tbaa !24
  %t49 = call i64 @compiler_2flineedit_2ewordBack(ptr %v0, { i64, ptr } %t42, i64 %t46)
  store i64 %t49, ptr %l24
  br label %bb18
bb17:
  br label %bb19
bb18:
  %t50 = load i64, ptr %l24, !tbaa !24
  %t51 = load ptr, ptr %l19, !tbaa !29
  %t52 = getelementptr %"compiler/lineedit:Editor", ptr %t51, i32 0, i32 4
  store i64 %t50, ptr %t52, !tbaa !24
  br label %bb19
bb19:
  %t53 = load i8, ptr %l1, !tbaa !22
  %t55 = icmp eq i8 %t53, 102
  br i1 %t55, label %bb20, label %bb21
bb20:
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l27, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/lineedit:Editor", ptr %t58, i32 0, i32 3
  %t61 = load { i64, ptr }, ptr %t60, !tbaa !27
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/lineedit:Editor", ptr %t62, i32 0, i32 4
  %t65 = load i64, ptr %t64, !tbaa !24
  %t68 = call i64 @compiler_2flineedit_2ewordEnd(ptr %v0, { i64, ptr } %t61, i64 %t65)
  store i64 %t68, ptr %l32
  br label %bb22
bb21:
  br label %bb23
bb22:
  %t69 = load i64, ptr %l32, !tbaa !24
  %t70 = load ptr, ptr %l27, !tbaa !29
  %t71 = getelementptr %"compiler/lineedit:Editor", ptr %t70, i32 0, i32 4
  store i64 %t69, ptr %t71, !tbaa !24
  br label %bb23
bb23:
  %t72 = load i8, ptr %l1, !tbaa !22
  %t74 = icmp eq i8 %t72, 100
  br i1 %t74, label %bb24, label %bb25
bb24:
  %t76 = load ptr, ptr %l0, !tbaa !29
  store ptr %t76, ptr %l35, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/lineedit:Editor", ptr %t77, i32 0, i32 4
  %t80 = load i64, ptr %t79, !tbaa !24
  store i64 %t80, ptr %l37, !tbaa !24
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/lineedit:Editor", ptr %t81, i32 0, i32 3
  %t84 = load { i64, ptr }, ptr %t83, !tbaa !27
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/lineedit:Editor", ptr %t85, i32 0, i32 4
  %t88 = load i64, ptr %t87, !tbaa !24
  %t91 = call i64 @compiler_2flineedit_2ewordEnd(ptr %v0, { i64, ptr } %t84, i64 %t88)
  store i64 %t91, ptr %l42
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t92 = load ptr, ptr %l35, !tbaa !29
  %t93 = load i64, ptr %l37, !tbaa !24
  %t94 = load i64, ptr %l42, !tbaa !24
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eremove(ptr %v0, ptr %t92, i64 %t93, i64 %t94, i1 true)
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t95 = load i8, ptr %l1, !tbaa !22
  %t97 = icmp eq i8 %t95, 127
  br i1 %t97, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l45, !tbaa !21
  br label %bb31
bb30:
  %t99 = load i8, ptr %l1, !tbaa !22
  %t101 = icmp eq i8 %t99, 8
  store i1 %t101, ptr %l45, !tbaa !21
  br label %bb31
bb31:
  %t103 = load i1, ptr %l45, !tbaa !21
  br i1 %t103, label %bb32, label %bb33
bb32:
  %t104 = load ptr, ptr %l0, !tbaa !29
  store ptr %t104, ptr %l48, !tbaa !29
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/lineedit:Editor", ptr %t105, i32 0, i32 3
  %t108 = load { i64, ptr }, ptr %t107, !tbaa !27
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/lineedit:Editor", ptr %t109, i32 0, i32 4
  %t112 = load i64, ptr %t111, !tbaa !24
  %t115 = call i64 @compiler_2flineedit_2ewordBack(ptr %v0, { i64, ptr } %t108, i64 %t112)
  store i64 %t115, ptr %l53
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/lineedit:Editor", ptr %t116, i32 0, i32 4
  %t119 = load i64, ptr %t118, !tbaa !24
  %t120 = load ptr, ptr %l48, !tbaa !29
  %t121 = load i64, ptr %l53, !tbaa !24
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eremove(ptr %v0, ptr %t120, i64 %t121, i64 %t119, i1 true)
  br label %bb35
bb35:
  br label %bb36
bb36:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, i64 } @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2emoved(ptr %v0, ptr %a0, i8 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l16 = alloca i64
  %l19 = alloca i64
  %l37 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i32
  %rv = alloca { i32, i64 }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lineedit:Editor", ptr %t1, i32 0, i32 4
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  store i64 %a2, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t9 = load i64, ptr %l4, !tbaa !24
  %t12 = icmp sgt i64 %t8, %t9
  br i1 %t12, label %bb1, label %bb2
bb1:
  %t14 = load i64, ptr %l6, !tbaa !24
  %t16 = icmp sgt i64 %t14, 0
  br i1 %t16, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb6
bb3:
  %t18 = load i64, ptr %l5, !tbaa !24
  %t19 = load i64, ptr %l4, !tbaa !24
  %t22 = sub i64 %t18, %t19
  %t23 = load i64, ptr %l6, !tbaa !24
  %t26 = add i64 %t22, %t23
  %t28 = sub i64 %t26, 1
  %t29 = load i64, ptr %l6, !tbaa !24
  %t32 = sdiv i64 %t28, %t29
  store i64 %t32, ptr %l19, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb5
bb5:
  %t34 = load i64, ptr %l19, !tbaa !24
  store i64 %t34, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t35 = load i64, ptr %l16, !tbaa !24
  store i64 %t35, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb7
bb7:
  %t36 = load i64, ptr %l8, !tbaa !24
  %t37 = load i64, ptr %l7, !tbaa !24
  %t40 = icmp slt i64 %t36, %t37
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb8, label %bb9
bb8:
  br label %bb15
bb9:
  br label %bb10
bb10:
  %t44 = load i64, ptr %l4, !tbaa !24
  %t45 = load i64, ptr %l8, !tbaa !24
  %t46 = load i64, ptr %l6, !tbaa !24
  %t49 = mul i64 %t45, %t46
  %t52 = add i64 %t44, %t49
  store i64 %t52, ptr %l9, !tbaa !24
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = load i64, ptr %l3, !tbaa !24
  %t60 = call { i32, i64 } @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2etarget(ptr %v0, ptr %t54, i8 %a1, i64 %t56)
  %t61 = extractvalue { i32, i64 } %t60, 1
  %t62 = extractvalue { i32, i64 } %t60, 0
  store i32 %t62, ptr %l42
  %t63 = icmp ne i32 %t62, 0
  br i1 %t63, label %bb12, label %ok.64, !prof !99
ok.64:
  store i64 %t61, ptr %l41
  br label %bb11
bb11:
  %t65 = load i64, ptr %l41, !tbaa !24
  store i64 %t65, ptr %l37, !tbaa !24
  br label %bb13
bb12:
  %t66 = load i32, ptr %l42, !tbaa !23
  %t67 = lshr i32 %t66, 16
  %t68 = and i32 %t66, 65535
  %t69 = icmp eq i32 %t67, 1
  %t70 = select i1 %t69, i32 1, i32 0
  %t71 = icmp eq i32 %t66, 0
  %t72 = shl i32 %t70, 16
  %t73 = or i32 %t72, %t68
  %t74 = select i1 %t71, i32 0, i32 %t73
  %t76 = insertvalue { i32, i64 } zeroinitializer, i32 %t74, 0
  store { i32, i64 } %t76, ptr %rv
  br label %ret
bb13:
  %t77 = load i64, ptr %l37, !tbaa !24
  store i64 %t77, ptr %l3, !tbaa !24
  br label %bb14
bb14:
  %t78 = load i64, ptr %l8, !tbaa !24
  %t81 = add i64 %t78, 1
  store i64 %t81, ptr %l8, !tbaa !24
  br label %bb7
bb15:
  %t83 = load i64, ptr %l3, !tbaa !24
  %t85 = insertvalue { i32, i64 } zeroinitializer, i64 %t83, 1
  store { i32, i64 } %t85, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2enewer(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l5 = alloca i64
  %l7 = alloca ptr
  %l11 = alloca ptr
  %l13 = alloca i64
  %l16 = alloca i64
  %l18 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l28 = alloca ptr
  %l30 = alloca i64
  %l33 = alloca i64
  %l35 = alloca i64
  %l41 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lineedit:Editor", ptr %t1, i32 0, i32 12
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %l2, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/lineedit:Editor", ptr %t5, i32 0, i32 7
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l5
  br label %bb1
bb1:
  %t10 = load i64, ptr %l2, !tbaa !24
  %t11 = load i64, ptr %l5, !tbaa !24
  %t12 = icmp sge i64 %t10, %t11
  br i1 %t12, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l7, !tbaa !29
  %t15 = load ptr, ptr %l7, !tbaa !29
  %t16 = getelementptr %"compiler/lineedit:Editor", ptr %t15, i32 0, i32 12
  %t17 = load i64, ptr %t16, !tbaa !24
  %t20 = add i64 %t17, 1
  %t22 = load ptr, ptr %l7, !tbaa !29
  %t23 = getelementptr %"compiler/lineedit:Editor", ptr %t22, i32 0, i32 12
  store i64 %t20, ptr %t23, !tbaa !24
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l11, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/lineedit:Editor", ptr %t25, i32 0, i32 12
  %t28 = load i64, ptr %t27, !tbaa !24
  store i64 %t28, ptr %l13, !tbaa !24
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/lineedit:Editor", ptr %t29, i32 0, i32 7
  %t33 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t31)
  store i64 %t33, ptr %l16
  br label %bb5
bb5:
  %t34 = load i64, ptr %l13, !tbaa !24
  %t35 = load i64, ptr %l16, !tbaa !24
  %t36 = icmp eq i64 %t34, %t35
  br i1 %t36, label %bb6, label %bb7
bb6:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/lineedit:Editor", ptr %t38, i32 0, i32 13
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  store { i64, ptr } %t41, ptr %l18, !tbaa !27
  br label %bb9
bb7:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/lineedit:Editor", ptr %t43, i32 0, i32 7
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/lineedit:Editor", ptr %t46, i32 0, i32 12
  %t49 = load i64, ptr %t48, !tbaa !24
  %t52 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t45, i64 %t49)
  store { i64, ptr } %t52, ptr %l25
  br label %bb8
bb8:
  %t53 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t53, ptr %l18, !tbaa !27
  br label %bb9
bb9:
  %t54 = load ptr, ptr %l11, !tbaa !29
  %t55 = getelementptr %"compiler/lineedit:Editor", ptr %t54, i32 0, i32 3
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l26, !tbaa !27
  %t57 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t58 = load ptr, ptr %l11, !tbaa !29
  %t59 = getelementptr %"compiler/lineedit:Editor", ptr %t58, i32 0, i32 3
  store { i64, ptr } %t57, ptr %t59, !tbaa !27
  %t60 = load i1, ptr @olang_2esole_2ecompiler_2flineedit_3aEditor_2e3
  br i1 %t60, label %bb10, label %bb11
bb10:
  %t62 = load { i64, ptr }, ptr %l26
  %t63 = extractvalue { i64, ptr } %t62, 1
  call void @__olang_region_release(ptr %t63)
  store { i64, ptr } zeroinitializer, ptr %l26
  br label %bb11
bb11:
  %t64 = load ptr, ptr %l0, !tbaa !29
  store ptr %t64, ptr %l28, !tbaa !29
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/lineedit:Editor", ptr %t65, i32 0, i32 12
  %t68 = load i64, ptr %t67, !tbaa !24
  store i64 %t68, ptr %l30, !tbaa !24
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/lineedit:Editor", ptr %t69, i32 0, i32 7
  %t73 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t71)
  store i64 %t73, ptr %l33
  br label %bb12
bb12:
  %t74 = load i64, ptr %l30, !tbaa !24
  %t75 = load i64, ptr %l33, !tbaa !24
  %t76 = icmp eq i64 %t74, %t75
  br i1 %t76, label %bb13, label %bb14
bb13:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/lineedit:Editor", ptr %t78, i32 0, i32 3
  %t81 = load { i64, ptr }, ptr %t80, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t81, 0
  store i64 %t83, ptr %l35, !tbaa !24
  br label %bb16
bb14:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/lineedit:Editor", ptr %t85, i32 0, i32 3
  %t88 = load { i64, ptr }, ptr %t87, !tbaa !27
  %t90 = call i64 @compiler_2flineedit_2elineEnd(ptr %v0, { i64, ptr } %t88, i64 0)
  store i64 %t90, ptr %l41
  br label %bb15
bb15:
  %t91 = load i64, ptr %l41, !tbaa !24
  store i64 %t91, ptr %l35, !tbaa !24
  br label %bb16
bb16:
  %t92 = load i64, ptr %l35, !tbaa !24
  %t93 = load ptr, ptr %l28, !tbaa !29
  %t94 = getelementptr %"compiler/lineedit:Editor", ptr %t93, i32 0, i32 4
  store i64 %t92, ptr %t94, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2enormalKey(ptr %v0, ptr %a0, i8 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i8
  %l2 = alloca i64
  %l6 = alloca i1
  %l13 = alloca i32
  %l16 = alloca i1
  %l19 = alloca i1
  %l26 = alloca i32
  %l29 = alloca i1
  %l32 = alloca i1
  %l35 = alloca i1
  %l39 = alloca ptr
  %l51 = alloca i64
  %l64 = alloca i32
  %l65 = alloca i64
  %l69 = alloca i64
  %l70 = alloca i32
  %l72 = alloca i1
  %l76 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i8 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i8, ptr %l1, !tbaa !22
  %t3 = icmp eq i8 %t1, 13
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i8, ptr %l1, !tbaa !22
  %t7 = icmp eq i8 %t5, 10
  store i1 %t7, ptr %l6, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t11 = load i8, ptr %l1, !tbaa !22
  %t13 = icmp eq i8 %t11, 3
  br i1 %t13, label %bb7, label %bb8
bb7:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = call i32 @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2einterrupt(ptr %v0, ptr %t15)
  store i32 %t17, ptr %l13
  br label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t18 = load i32, ptr %l13, !range !{i32 0, i32 4}
  store i32 %t18, ptr %rv
  br label %ret
bb10:
  %t19 = load i8, ptr %l1, !tbaa !22
  %t21 = icmp eq i8 %t19, 4
  br i1 %t21, label %bb11, label %bb12
bb11:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/lineedit:Editor", ptr %t23, i32 0, i32 3
  %t26 = load { i64, ptr }, ptr %t25, !tbaa !27
  %t28 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t26, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d34, i32 0, i32 1) })
  store i1 %t28, ptr %l19
  br label %bb13
bb12:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb14
bb13:
  %t29 = load i1, ptr %l19, !tbaa !21
  store i1 %t29, ptr %l16, !tbaa !21
  br label %bb14
bb14:
  %t30 = load i1, ptr %l16, !tbaa !21
  br i1 %t30, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s0)
  store i32 3, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/lineedit:Editor", ptr %t32, i32 0, i32 33
  %t35 = load i8, ptr %t34, !tbaa !22
  %t37 = icmp eq i8 %t35, 114
  br i1 %t37, label %bb18, label %bb19
bb18:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load i8, ptr %l1, !tbaa !22
  %t43 = call i32 @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2ereplace(ptr %v0, ptr %t39, i8 %t40)
  store i32 %t43, ptr %l26
  br label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t44 = load i32, ptr %l26, !range !{i32 0, i32 4}
  store i32 %t44, ptr %rv
  br label %ret
bb21:
  %t45 = load i8, ptr %l1, !tbaa !22
  %t47 = icmp uge i8 %t45, 49
  br i1 %t47, label %bb22, label %bb23
bb22:
  %t49 = load i8, ptr %l1, !tbaa !22
  %t51 = icmp ule i8 %t49, 57
  store i1 %t51, ptr %l29, !tbaa !21
  br label %bb24
bb23:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb24
bb24:
  %t53 = load i1, ptr %l29, !tbaa !21
  br i1 %t53, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb30
bb26:
  %t54 = load i8, ptr %l1, !tbaa !22
  %t56 = icmp eq i8 %t54, 48
  br i1 %t56, label %bb27, label %bb28
bb27:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/lineedit:Editor", ptr %t58, i32 0, i32 32
  %t61 = load i64, ptr %t60, !tbaa !24
  %t63 = icmp sgt i64 %t61, 0
  store i1 %t63, ptr %l35, !tbaa !21
  br label %bb29
bb28:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb29
bb29:
  %t65 = load i1, ptr %l35, !tbaa !21
  store i1 %t65, ptr %l32, !tbaa !21
  br label %bb30
bb30:
  %t66 = load i1, ptr %l32, !tbaa !21
  br i1 %t66, label %bb31, label %bb32
bb31:
  %t67 = load ptr, ptr %l0, !tbaa !29
  store ptr %t67, ptr %l39, !tbaa !29
  %t68 = load ptr, ptr %l39, !tbaa !29
  %t69 = getelementptr %"compiler/lineedit:Editor", ptr %t68, i32 0, i32 32
  %t70 = load i64, ptr %t69, !tbaa !24
  %t73 = mul i64 %t70, 10
  %t74 = load i8, ptr %l1, !tbaa !22
  %t76 = sub i8 %t74, 48
  %t78 = zext i8 %t76 to i64
  %t81 = add i64 %t73, %t78
  %t83 = load ptr, ptr %l39, !tbaa !29
  %t84 = getelementptr %"compiler/lineedit:Editor", ptr %t83, i32 0, i32 32
  store i64 %t81, ptr %t84, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb32:
  br label %bb33
bb33:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/lineedit:Editor", ptr %t86, i32 0, i32 32
  %t89 = load i64, ptr %t88, !tbaa !24
  %t91 = icmp sgt i64 %t89, 0
  br i1 %t91, label %bb34, label %bb35
bb34:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/lineedit:Editor", ptr %t93, i32 0, i32 32
  %t96 = load i64, ptr %t95, !tbaa !24
  store i64 %t96, ptr %l51, !tbaa !24
  br label %bb36
bb35:
  store i64 1, ptr %l51, !tbaa !24
  br label %bb36
bb36:
  %t98 = load i64, ptr %l51, !tbaa !24
  store i64 %t98, ptr %l2, !tbaa !24
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/lineedit:Editor", ptr %t99, i32 0, i32 32
  store i64 0, ptr %t101, !tbaa !24
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/lineedit:Editor", ptr %t102, i32 0, i32 33
  %t105 = load i8, ptr %t104, !tbaa !22
  %t107 = icmp ne i8 %t105, 0
  br i1 %t107, label %bb37, label %bb38
bb37:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load i8, ptr %l1, !tbaa !22
  %t111 = load i64, ptr %l2, !tbaa !24
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/lineedit:Editor", ptr %t112, i32 0, i32 34
  %t115 = load i64, ptr %t114, !tbaa !24
  %t118 = mul i64 %t111, %t115
  %t122 = call i32 @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eoperate(ptr %v0, ptr %t109, i8 %t110, i64 %t118)
  store i32 %t122, ptr %l64
  br label %bb39
bb38:
  br label %bb40
bb39:
  call void @__olang_scope_close(ptr %s0)
  %t123 = load i32, ptr %l64, !range !{i32 0, i32 4}
  store i32 %t123, ptr %rv
  br label %ret
bb40:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load i8, ptr %l1, !tbaa !22
  %t126 = load i64, ptr %l2, !tbaa !24
  %t130 = call { i32, i64 } @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2emoved(ptr %v0, ptr %t124, i8 %t125, i64 %t126)
  %t131 = extractvalue { i32, i64 } %t130, 1
  %t132 = extractvalue { i32, i64 } %t130, 0
  store i32 %t132, ptr %l70
  %t133 = icmp ne i32 %t132, 0
  br i1 %t133, label %bb42, label %ok.134, !prof !99
ok.134:
  store i64 %t131, ptr %l69
  br label %bb41
bb41:
  %t135 = load i64, ptr %l69, !tbaa !24
  store i64 %t135, ptr %l65, !tbaa !24
  br label %bb45
bb42:
  %t136 = load i32, ptr %l70, !tbaa !23
  %t137 = ashr i32 %t136, 16
  %t139 = icmp eq i32 %t137, 1
  store i1 %t139, ptr %l72, !tbaa !21
  br label %bb43
bb43:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load i8, ptr %l1, !tbaa !22
  %t142 = load i64, ptr %l2, !tbaa !24
  %t146 = call i32 @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2ecommand(ptr %v0, ptr %t140, i8 %t141, i64 %t142)
  store i32 %t146, ptr %l76
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s0)
  %t147 = load i32, ptr %l76, !range !{i32 0, i32 4}
  store i32 %t147, ptr %rv
  br label %ret
bb45:
  %t148 = load i64, ptr %l65, !tbaa !24
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t153 = getelementptr %"compiler/lineedit:Editor", ptr %t149, i32 0, i32 4
  store i64 %t148, ptr %t153, !tbaa !24
  %t154 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eclamp(ptr %v0, ptr %t154)
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eolder(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca i64
  %l8 = alloca i64
  %l10 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l15 = alloca ptr
  %l19 = alloca ptr
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lineedit:Editor", ptr %t1, i32 0, i32 12
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp eq i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/lineedit:Editor", ptr %t8, i32 0, i32 12
  %t11 = load i64, ptr %t10, !tbaa !24
  store i64 %t11, ptr %l5, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/lineedit:Editor", ptr %t12, i32 0, i32 7
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t14)
  store i64 %t16, ptr %l8
  br label %bb4
bb4:
  %t17 = load i64, ptr %l5, !tbaa !24
  %t18 = load i64, ptr %l8, !tbaa !24
  %t19 = icmp eq i64 %t17, %t18
  br i1 %t19, label %bb5, label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l10, !tbaa !29
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/lineedit:Editor", ptr %t22, i32 0, i32 3
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  %t26 = load ptr, ptr %l10, !tbaa !29
  %t27 = getelementptr %"compiler/lineedit:Editor", ptr %t26, i32 0, i32 13
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  store { i64, ptr } %t28, ptr %l13, !tbaa !27
  %t30 = load ptr, ptr %l10, !tbaa !29
  %t31 = getelementptr %"compiler/lineedit:Editor", ptr %t30, i32 0, i32 13
  store { i64, ptr } %t25, ptr %t31, !tbaa !27
  %t32 = load i1, ptr @olang_2esole_2ecompiler_2flineedit_3aEditor_2e13
  br i1 %t32, label %bb7, label %bb8
bb6:
  br label %bb9
bb7:
  %t34 = load { i64, ptr }, ptr %l13
  %t35 = extractvalue { i64, ptr } %t34, 1
  call void @__olang_region_release(ptr %t35)
  store { i64, ptr } zeroinitializer, ptr %l13
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l15, !tbaa !29
  %t37 = load ptr, ptr %l15, !tbaa !29
  %t38 = getelementptr %"compiler/lineedit:Editor", ptr %t37, i32 0, i32 12
  %t39 = load i64, ptr %t38, !tbaa !24
  %t42 = sub i64 %t39, 1
  %t44 = load ptr, ptr %l15, !tbaa !29
  %t45 = getelementptr %"compiler/lineedit:Editor", ptr %t44, i32 0, i32 12
  store i64 %t42, ptr %t45, !tbaa !24
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l19, !tbaa !29
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/lineedit:Editor", ptr %t47, i32 0, i32 7
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/lineedit:Editor", ptr %t50, i32 0, i32 12
  %t53 = load i64, ptr %t52, !tbaa !24
  %t56 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t49, i64 %t53)
  store { i64, ptr } %t56, ptr %l24
  br label %bb10
bb10:
  %t57 = load ptr, ptr %l19, !tbaa !29
  %t58 = getelementptr %"compiler/lineedit:Editor", ptr %t57, i32 0, i32 3
  %t59 = load { i64, ptr }, ptr %t58, !tbaa !27
  store { i64, ptr } %t59, ptr %l25, !tbaa !27
  %t60 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t61 = load ptr, ptr %l19, !tbaa !29
  %t62 = getelementptr %"compiler/lineedit:Editor", ptr %t61, i32 0, i32 3
  store { i64, ptr } %t60, ptr %t62, !tbaa !27
  %t63 = load i1, ptr @olang_2esole_2ecompiler_2flineedit_3aEditor_2e3
  br i1 %t63, label %bb11, label %bb12
bb11:
  %t65 = load { i64, ptr }, ptr %l25
  %t66 = extractvalue { i64, ptr } %t65, 1
  call void @__olang_region_release(ptr %t66)
  store { i64, ptr } zeroinitializer, ptr %l25
  br label %bb12
bb12:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/lineedit:Editor", ptr %t68, i32 0, i32 3
  %t71 = load { i64, ptr }, ptr %t70, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t71, 0
  %t76 = getelementptr %"compiler/lineedit:Editor", ptr %t67, i32 0, i32 4
  store i64 %t73, ptr %t76, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eoperate(ptr %v0, ptr %a0, i8 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i8
  %l2 = alloca i64
  %l3 = alloca i8
  %l4 = alloca i1
  %l5 = alloca i8
  %l6 = alloca i64
  %l7 = alloca i64
  %l17 = alloca i32
  %l20 = alloca i1
  %l23 = alloca i1
  %l30 = alloca i1
  %l32 = alloca { i64, ptr }
  %l36 = alloca i64
  %l39 = alloca i8
  %l41 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i32
  %l48 = alloca i1
  %l53 = alloca i64
  %l59 = alloca i64
  %l64 = alloca i64
  %l72 = alloca i64
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i8 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lineedit:Editor", ptr %t1, i32 0, i32 33
  %t4 = load i8, ptr %t3, !tbaa !22
  store i8 %t4, ptr %l3, !tbaa !22
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lineedit:Editor", ptr %t6, i32 0, i32 33
  store i8 0, ptr %t8, !tbaa !22
  %t9 = load i8, ptr %l1, !tbaa !22
  %t10 = load i8, ptr %l3, !tbaa !22
  %t13 = icmp eq i8 %t9, %t10
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i8, ptr %l3, !tbaa !22
  %t19 = call i32 @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2ewholeLine(ptr %v0, ptr %t15, i8 %t16)
  store i32 %t19, ptr %l17
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t20 = load i32, ptr %l17, !range !{i32 0, i32 4}
  store i32 %t20, ptr %rv
  br label %ret
bb4:
  %t21 = load i8, ptr %l3, !tbaa !22
  %t23 = icmp eq i8 %t21, 99
  br i1 %t23, label %bb5, label %bb6
bb5:
  %t25 = load i8, ptr %l1, !tbaa !22
  %t27 = icmp eq i8 %t25, 119
  store i1 %t27, ptr %l20, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb7
bb7:
  %t29 = load i1, ptr %l20, !tbaa !21
  br i1 %t29, label %bb8, label %bb9
bb8:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/lineedit:Editor", ptr %t30, i32 0, i32 4
  %t33 = load i64, ptr %t32, !tbaa !24
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/lineedit:Editor", ptr %t34, i32 0, i32 3
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t37, 0
  %t42 = icmp slt i64 %t33, %t39
  store i1 %t42, ptr %l23, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb10
bb10:
  %t44 = load i1, ptr %l23, !tbaa !21
  br i1 %t44, label %bb11, label %bb12
bb11:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/lineedit:Editor", ptr %t45, i32 0, i32 3
  %t48 = load { i64, ptr }, ptr %t47, !tbaa !27
  store { i64, ptr } %t48, ptr %l32, !tbaa !27
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/lineedit:Editor", ptr %t49, i32 0, i32 4
  %t52 = load i64, ptr %t51, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr i8, ptr %t55, i64 %t52
  %t57 = load i8, ptr %t56, !tbaa !32
  %t59 = call i64 @compiler_2flineedit_2eclass(i8 %t57)
  store i64 %t59, ptr %l36
  br label %bb13
bb12:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb14
bb13:
  %t60 = load i64, ptr %l36, !tbaa !24
  %t61 = icmp ne i64 %t60, 0
  store i1 %t61, ptr %l30, !tbaa !21
  br label %bb14
bb14:
  %t63 = load i1, ptr %l30, !tbaa !21
  store i1 %t63, ptr %l4, !tbaa !21
  %t64 = load i1, ptr %l4, !tbaa !21
  br i1 %t64, label %bb15, label %bb16
bb15:
  store i8 101, ptr %l39, !tbaa !22
  br label %bb17
bb16:
  %t66 = load i8, ptr %l1, !tbaa !22
  store i8 %t66, ptr %l39, !tbaa !22
  br label %bb17
bb17:
  %t68 = load i8, ptr %l39, !tbaa !22
  store i8 %t68, ptr %l5, !tbaa !22
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load i8, ptr %l5, !tbaa !22
  %t71 = load i64, ptr %l2, !tbaa !24
  %t75 = call { i32, i64 } @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2emoved(ptr %v0, ptr %t69, i8 %t70, i64 %t71)
  %t76 = extractvalue { i32, i64 } %t75, 1
  %t77 = extractvalue { i32, i64 } %t75, 0
  store i32 %t77, ptr %l46
  %t78 = icmp ne i32 %t77, 0
  br i1 %t78, label %bb19, label %ok.79, !prof !99
ok.79:
  store i64 %t76, ptr %l45
  br label %bb18
bb18:
  %t80 = load i64, ptr %l45, !tbaa !24
  store i64 %t80, ptr %l41, !tbaa !24
  br label %bb21
bb19:
  %t81 = load i32, ptr %l46, !tbaa !23
  %t82 = ashr i32 %t81, 16
  %t84 = icmp eq i32 %t82, 1
  store i1 %t84, ptr %l48, !tbaa !21
  br label %bb20
bb20:
  store i32 0, ptr %rv
  br label %ret
bb21:
  %t86 = load i64, ptr %l41, !tbaa !24
  store i64 %t86, ptr %l6, !tbaa !24
  %t87 = load i1, ptr %l4, !tbaa !21
  br i1 %t87, label %bb22, label %bb23
bb22:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load i64, ptr %l2, !tbaa !24
  %t93 = call i64 @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2ewordsHere(ptr %v0, ptr %t89, i64 %t90)
  store i64 %t93, ptr %l53
  br label %bb24
bb23:
  br label %bb25
bb24:
  %t94 = load i64, ptr %l53, !tbaa !24
  store i64 %t94, ptr %l6, !tbaa !24
  br label %bb25
bb25:
  %t95 = load i8, ptr %l5, !tbaa !22
  %t97 = icmp eq i8 %t95, 101
  br i1 %t97, label %bb26, label %bb27
bb26:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/lineedit:Editor", ptr %t99, i32 0, i32 3
  %t102 = load { i64, ptr }, ptr %t101, !tbaa !27
  %t103 = load i64, ptr %l6, !tbaa !24
  %t106 = call i64 @compiler_2flineedit_2enextAt(ptr %v0, { i64, ptr } %t102, i64 %t103)
  store i64 %t106, ptr %l59
  br label %bb28
bb27:
  br label %bb29
bb28:
  %t107 = load i64, ptr %l59, !tbaa !24
  store i64 %t107, ptr %l6, !tbaa !24
  br label %bb29
bb29:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/lineedit:Editor", ptr %t108, i32 0, i32 4
  %t111 = load i64, ptr %t110, !tbaa !24
  %t112 = load i64, ptr %l6, !tbaa !24
  %t115 = icmp slt i64 %t111, %t112
  br i1 %t115, label %bb30, label %bb31
bb30:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/lineedit:Editor", ptr %t117, i32 0, i32 4
  %t120 = load i64, ptr %t119, !tbaa !24
  store i64 %t120, ptr %l64, !tbaa !24
  br label %bb32
bb31:
  %t122 = load i64, ptr %l6, !tbaa !24
  store i64 %t122, ptr %l64, !tbaa !24
  br label %bb32
bb32:
  %t124 = load i64, ptr %l64, !tbaa !24
  store i64 %t124, ptr %l7, !tbaa !24
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/lineedit:Editor", ptr %t125, i32 0, i32 4
  %t128 = load i64, ptr %t127, !tbaa !24
  %t129 = load i64, ptr %l6, !tbaa !24
  %t132 = icmp slt i64 %t128, %t129
  br i1 %t132, label %bb33, label %bb34
bb33:
  %t134 = load i64, ptr %l6, !tbaa !24
  store i64 %t134, ptr %l72, !tbaa !24
  br label %bb35
bb34:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/lineedit:Editor", ptr %t136, i32 0, i32 4
  %t139 = load i64, ptr %t138, !tbaa !24
  store i64 %t139, ptr %l72, !tbaa !24
  br label %bb35
bb35:
  %t141 = load i64, ptr %l72, !tbaa !24
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t143 = load i64, ptr %l7, !tbaa !24
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eremove(ptr %v0, ptr %t142, i64 %t143, i64 %t141, i1 true)
  br label %bb36
bb36:
  %t148 = load i8, ptr %l3, !tbaa !22
  %t150 = icmp eq i8 %t148, 99
  br i1 %t150, label %bb37, label %bb38
bb37:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/lineedit:Editor", ptr %t152, i32 0, i32 5
  store i1 false, ptr %t154, !tbaa !21
  br label %bb39
bb38:
  br label %bb39
bb39:
  %t155 = load i8, ptr %l3, !tbaa !22
  %t157 = icmp eq i8 %t155, 100
  br i1 %t157, label %bb40, label %bb41
bb40:
  %t159 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eclamp(ptr %v0, ptr %t159)
  br label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb43
bb43:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2epasted(ptr %v0, ptr %a0, i8 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i8
  %l5 = alloca i1
  %l14 = alloca i1
  %l17 = alloca ptr
  %l19 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i8 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lineedit:Editor", ptr %t1, i32 0, i32 20
  store i1 true, ptr %t3, !tbaa !21
  %t4 = load i8, ptr %l1, !tbaa !22
  %t6 = icmp eq i8 %t4, 13
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb3
bb2:
  %t8 = load i8, ptr %l1, !tbaa !22
  %t10 = icmp eq i8 %t8, 10
  store i1 %t10, ptr %l5, !tbaa !21
  br label %bb3
bb3:
  %t12 = load i1, ptr %l5, !tbaa !21
  br i1 %t12, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t13 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2einsert(ptr %v0, ptr %s1, ptr %t13, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d35, i32 0, i32 1) })
  br label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb7
bb7:
  %t15 = load i8, ptr %l1, !tbaa !22
  %t17 = icmp eq i8 %t15, 9
  br i1 %t17, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t19 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2einsert(ptr %v0, ptr %s2, ptr %t19, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d36, i32 0, i32 1) })
  br label %bb10
bb9:
  br label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb11:
  %t21 = load i8, ptr %l1, !tbaa !22
  %t23 = icmp uge i8 %t21, 32
  br i1 %t23, label %bb12, label %bb13
bb12:
  %t25 = load i8, ptr %l1, !tbaa !22
  %t27 = icmp ne i8 %t25, 127
  store i1 %t27, ptr %l14, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb14
bb14:
  %t29 = load i1, ptr %l14, !tbaa !21
  br i1 %t29, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t30 = load ptr, ptr %l0, !tbaa !29
  store ptr %t30, ptr %l17, !tbaa !29
  %t31 = load i8, ptr %l1, !tbaa !22
  %t33 = call { i64, ptr } @compiler_2flineedit_2eone(ptr %s3, i8 %t31)
  store { i64, ptr } %t33, ptr %l19
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t34 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t35 = load ptr, ptr %l17, !tbaa !29
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2einsert(ptr %v0, ptr %s3, ptr %t35, { i64, ptr } %t34)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb19:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2ereplace(ptr %v0, ptr %a0, i8 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i8
  %l2 = alloca i64
  %l6 = alloca i1
  %l8 = alloca i64
  %l13 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca i64
  %l23 = alloca i64
  %l24 = alloca ptr
  %l26 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i8 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lineedit:Editor", ptr %t1, i32 0, i32 33
  store i8 0, ptr %t3, !tbaa !22
  %t4 = load i8, ptr %l1, !tbaa !22
  %t6 = icmp ult i8 %t4, 32
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb4
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/lineedit:Editor", ptr %t8, i32 0, i32 4
  %t11 = load i64, ptr %t10, !tbaa !24
  store i64 %t11, ptr %l8, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/lineedit:Editor", ptr %t12, i32 0, i32 3
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/lineedit:Editor", ptr %t16, i32 0, i32 4
  %t19 = load i64, ptr %t18, !tbaa !24
  %t22 = call i64 @compiler_2flineedit_2elineEnd(ptr %v0, { i64, ptr } %t15, i64 %t19)
  store i64 %t22, ptr %l13
  br label %bb3
bb3:
  %t23 = load i64, ptr %l8, !tbaa !24
  %t24 = load i64, ptr %l13, !tbaa !24
  %t25 = icmp sge i64 %t23, %t24
  store i1 %t25, ptr %l6, !tbaa !21
  br label %bb4
bb4:
  %t27 = load i1, ptr %l6, !tbaa !21
  br i1 %t27, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/lineedit:Editor", ptr %t29, i32 0, i32 4
  %t32 = load i64, ptr %t31, !tbaa !24
  store i64 %t32, ptr %l2, !tbaa !24
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l18, !tbaa !29
  %t35 = load i64, ptr %l2, !tbaa !24
  store i64 %t35, ptr %l19, !tbaa !24
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/lineedit:Editor", ptr %t36, i32 0, i32 3
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !27
  %t40 = load i64, ptr %l2, !tbaa !24
  %t43 = call i64 @compiler_2flineedit_2enextAt(ptr %v0, { i64, ptr } %t39, i64 %t40)
  store i64 %t43, ptr %l23
  br label %bb8
bb8:
  %t44 = load ptr, ptr %l18, !tbaa !29
  %t45 = load i64, ptr %l19, !tbaa !24
  %t46 = load i64, ptr %l23, !tbaa !24
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eremove(ptr %v0, ptr %t44, i64 %t45, i64 %t46, i1 false)
  br label %bb9
bb9:
  %t47 = load ptr, ptr %l0, !tbaa !29
  store ptr %t47, ptr %l24, !tbaa !29
  %t48 = load i8, ptr %l1, !tbaa !22
  %t50 = call { i64, ptr } @compiler_2flineedit_2eone(ptr %s0, i8 %t48)
  store { i64, ptr } %t50, ptr %l26
  br label %bb10
bb10:
  %t51 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t52 = load ptr, ptr %l24, !tbaa !29
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2einsert(ptr %v0, ptr %s0, ptr %t52, { i64, ptr } %t51)
  br label %bb11
bb11:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load i64, ptr %l2, !tbaa !24
  %t58 = getelementptr %"compiler/lineedit:Editor", ptr %t54, i32 0, i32 4
  store i64 %t55, ptr %t58, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2ereset(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l9 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l1, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/lineedit:Editor", ptr %t2, i32 0, i32 3
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t6 = getelementptr %"compiler/lineedit:Editor", ptr %t5, i32 0, i32 3
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d37, i32 0, i32 1) }, ptr %t6, !tbaa !27
  %t7 = load i1, ptr @olang_2esole_2ecompiler_2flineedit_3aEditor_2e3
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load { i64, ptr }, ptr %l2
  %t10 = extractvalue { i64, ptr } %t9, 1
  call void @__olang_region_release(ptr %t10)
  store { i64, ptr } zeroinitializer, ptr %l2
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/lineedit:Editor", ptr %t11, i32 0, i32 4
  store i64 0, ptr %t13, !tbaa !24
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/lineedit:Editor", ptr %t14, i32 0, i32 14
  store i64 0, ptr %t16, !tbaa !24
  %t17 = load ptr, ptr %l0, !tbaa !29
  store ptr %t17, ptr %l6, !tbaa !29
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/lineedit:Editor", ptr %t18, i32 0, i32 7
  %t22 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t20)
  store i64 %t22, ptr %l9
  br label %bb3
bb3:
  %t23 = load i64, ptr %l9, !tbaa !24
  %t24 = load ptr, ptr %l6, !tbaa !29
  %t25 = getelementptr %"compiler/lineedit:Editor", ptr %t24, i32 0, i32 12
  store i64 %t23, ptr %t25, !tbaa !24
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/lineedit:Editor", ptr %t26, i32 0, i32 17
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flineedit_3asnap_3e_2eClear_3ccompiler_2flineedit_3asnap_3e(ptr %v0, ptr %t28)
  br label %bb4
bb4:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/lineedit:Editor", ptr %t30, i32 0, i32 5
  store i1 false, ptr %t32, !tbaa !21
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/lineedit:Editor", ptr %t33, i32 0, i32 21
  store i1 false, ptr %t35, !tbaa !21
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/lineedit:Editor", ptr %t36, i32 0, i32 32
  store i64 0, ptr %t38, !tbaa !24
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/lineedit:Editor", ptr %t39, i32 0, i32 33
  store i8 0, ptr %t41, !tbaa !22
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eright(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l7 = alloca i64
  %l9 = alloca i64
  %l14 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lineedit:Editor", ptr %t1, i32 0, i32 4
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %l2, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/lineedit:Editor", ptr %t5, i32 0, i32 3
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/lineedit:Editor", ptr %t9, i32 0, i32 4
  %t12 = load i64, ptr %t11, !tbaa !24
  %t15 = call i64 @compiler_2flineedit_2elineEnd(ptr %v0, { i64, ptr } %t8, i64 %t12)
  store i64 %t15, ptr %l7
  br label %bb1
bb1:
  %t16 = load i64, ptr %l2, !tbaa !24
  %t17 = load i64, ptr %l7, !tbaa !24
  %t18 = icmp slt i64 %t16, %t17
  br i1 %t18, label %bb2, label %bb3
bb2:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/lineedit:Editor", ptr %t20, i32 0, i32 3
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/lineedit:Editor", ptr %t24, i32 0, i32 4
  %t27 = load i64, ptr %t26, !tbaa !24
  %t30 = call i64 @compiler_2flineedit_2enextAt(ptr %v0, { i64, ptr } %t23, i64 %t27)
  store i64 %t30, ptr %l14
  br label %bb4
bb3:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/lineedit:Editor", ptr %t31, i32 0, i32 4
  %t34 = load i64, ptr %t33, !tbaa !24
  store i64 %t34, ptr %l9, !tbaa !24
  br label %bb5
bb4:
  %t36 = load i64, ptr %l14, !tbaa !24
  store i64 %t36, ptr %l9, !tbaa !24
  br label %bb5
bb5:
  %t37 = load i64, ptr %l9, !tbaa !24
  store i64 %t37, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2esave(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i1
  %l10 = alloca ptr
  %l15 = alloca %"compiler/lineedit:snap"
  %l18 = alloca i64
  %l22 = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp eq i64 %t1, 1
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/lineedit:Editor", ptr %t5, i32 0, i32 18
  %t8 = load i64, ptr %t7, !tbaa !24
  %t10 = icmp eq i64 %t8, 1
  store i1 %t10, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  %t12 = load i1, ptr %l4, !tbaa !21
  %t13 = xor i1 %t12, true
  br i1 %t13, label %bb4, label %bb5
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/lineedit:Editor", ptr %t15, i32 0, i32 17
  store ptr %t17, ptr %l10, !tbaa !29
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/lineedit:Editor", ptr %t18, i32 0, i32 3
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/lineedit:Editor", ptr %t22, i32 0, i32 4
  %t25 = load i64, ptr %t24, !tbaa !24
  %t28 = call %"compiler/lineedit:snap" @compiler_2flineedit_3asnap_2ector(ptr %v0, ptr %v0, { i64, ptr } %t21, i64 %t25)
  store %"compiler/lineedit:snap" %t28, ptr %l15
  br label %bb6
bb5:
  br label %bb8
bb6:
  %t29 = load ptr, ptr %l10, !tbaa !29
  %t30 = load %"compiler/lineedit:snap", ptr %l15
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flineedit_3asnap_3e_2ePush_3ccompiler_2flineedit_3asnap_3e(ptr %v0, ptr %v0, ptr %t29, %"compiler/lineedit:snap" %t30)
  br label %bb7
bb7:
  br label %bb8
bb8:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/lineedit:Editor", ptr %t31, i32 0, i32 17
  %t35 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flineedit_3asnap_3e_2eLen_3ccompiler_2flineedit_3asnap_3e(ptr %v0, ptr %t33)
  store i64 %t35, ptr %l18
  br label %bb9
bb9:
  %t36 = load i64, ptr %l18, !tbaa !24
  %t37 = icmp sgt i64 %t36, 100
  br i1 %t37, label %bb10, label %bb11
bb10:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/lineedit:Editor", ptr %t39, i32 0, i32 17
  %t43 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flineedit_3asnap_3e_2eRemove_Hd9d3bd958740eb540dbca2377fffdf85(ptr %v0, ptr %t41, i64 0)
  store i32 %t43, ptr %l22
  %t44 = icmp ne i32 %t43, 0
  br i1 %t44, label %bb13, label %ok.45, !prof !99
ok.45:
  br label %bb12
bb11:
  br label %bb16
bb12:
  br label %bb15
bb13:
  br label %bb14
bb14:
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load i64, ptr %l1, !tbaa !24
  %t50 = getelementptr %"compiler/lineedit:Editor", ptr %t46, i32 0, i32 18
  store i64 %t47, ptr %t50, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2estep(ptr %v0, ptr %a0, i8 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i8
  %l4 = alloca i1
  %l8 = alloca i32
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l19 = alloca i32
  %l24 = alloca i32
  %l27 = alloca i1
  %l32 = alloca i32
  %l35 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i8 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lineedit:Editor", ptr %t1, i32 0, i32 15
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t4, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d38, i32 0, i32 1) })
  store i1 %t6, ptr %l4
  br label %bb1
bb1:
  %t7 = load i1, ptr %l4, !tbaa !21
  %t8 = xor i1 %t7, true
  br i1 %t8, label %bb2, label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i8, ptr %l1, !tbaa !22
  %t14 = call i32 @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eescape(ptr %v0, ptr %t10, i8 %t11)
  store i32 %t14, ptr %l8
  br label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t15 = load i32, ptr %l8, !range !{i32 0, i32 4}
  store i32 %t15, ptr %rv
  br label %ret
bb5:
  %t16 = load i8, ptr %l1, !tbaa !22
  %t18 = icmp eq i8 %t16, 27
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l11, !tbaa !29
  %t21 = load ptr, ptr %l11, !tbaa !29
  %t22 = getelementptr %"compiler/lineedit:Editor", ptr %t21, i32 0, i32 15
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  store { i64, ptr } %t23, ptr %l12, !tbaa !27
  %t24 = load ptr, ptr %l11, !tbaa !29
  %t25 = getelementptr %"compiler/lineedit:Editor", ptr %t24, i32 0, i32 15
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d39, i32 0, i32 1) }, ptr %t25, !tbaa !27
  %t26 = load i1, ptr @olang_2esole_2ecompiler_2flineedit_3aEditor_2e15
  br i1 %t26, label %bb8, label %bb9
bb7:
  br label %bb10
bb8:
  %t28 = load { i64, ptr }, ptr %l12
  %t29 = extractvalue { i64, ptr } %t28, 1
  call void @__olang_region_release(ptr %t29)
  store { i64, ptr } zeroinitializer, ptr %l12
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb10:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/lineedit:Editor", ptr %t31, i32 0, i32 22
  %t34 = load i1, ptr %t33, !tbaa !21
  br i1 %t34, label %bb11, label %bb12
bb11:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load i8, ptr %l1, !tbaa !22
  %t40 = call i32 @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2epasted(ptr %v0, ptr %t36, i8 %t37)
  store i32 %t40, ptr %l19
  br label %bb13
bb12:
  br label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  %t41 = load i32, ptr %l19, !range !{i32 0, i32 4}
  store i32 %t41, ptr %rv
  br label %ret
bb14:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/lineedit:Editor", ptr %t42, i32 0, i32 21
  %t45 = load i1, ptr %t44, !tbaa !21
  br i1 %t45, label %bb15, label %bb16
bb15:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load i8, ptr %l1, !tbaa !22
  %t51 = call i32 @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2esearchKey(ptr %v0, ptr %t47, i8 %t48)
  store i32 %t51, ptr %l24
  br label %bb17
bb16:
  br label %bb18
bb17:
  call void @__olang_scope_close(ptr %s0)
  %t52 = load i32, ptr %l24, !range !{i32 0, i32 4}
  store i32 %t52, ptr %rv
  br label %ret
bb18:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/lineedit:Editor", ptr %t53, i32 0, i32 0
  %t56 = load i1, ptr %t55, !tbaa !21
  br i1 %t56, label %bb19, label %bb20
bb19:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/lineedit:Editor", ptr %t58, i32 0, i32 5
  %t61 = load i1, ptr %t60, !tbaa !21
  store i1 %t61, ptr %l27, !tbaa !21
  br label %bb21
bb20:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb21
bb21:
  %t63 = load i1, ptr %l27, !tbaa !21
  br i1 %t63, label %bb22, label %bb23
bb22:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load i8, ptr %l1, !tbaa !22
  %t68 = call i32 @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2enormalKey(ptr %v0, ptr %t64, i8 %t65)
  store i32 %t68, ptr %l32
  br label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_scope_close(ptr %s0)
  %t69 = load i32, ptr %l32, !range !{i32 0, i32 4}
  store i32 %t69, ptr %rv
  br label %ret
bb25:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load i8, ptr %l1, !tbaa !22
  %t74 = call i32 @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2ekey(ptr %v0, ptr %t70, i8 %t71)
  store i32 %t74, ptr %l35
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s0)
  %t75 = load i32, ptr %l35, !range !{i32 0, i32 4}
  store i32 %t75, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, i64 } @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2etarget(ptr %v0, ptr %a0, i8 %a1, i64 %a2) #0 {
entry:
  %l1 = alloca i8
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l8 = alloca i64
  %l11 = alloca i64
  %l13 = alloca i64
  %l16 = alloca i64
  %l20 = alloca i64
  %l23 = alloca i64
  %l25 = alloca i64
  %l28 = alloca i64
  %l34 = alloca i64
  %l39 = alloca i64
  %l44 = alloca i64
  %l49 = alloca i64
  %l54 = alloca i64
  %l59 = alloca i64
  %rv = alloca { i32, i64 }
  store i8 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/lineedit:Editor", ptr %a0, i32 0, i32 3
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l3, !tbaa !27
  %t6 = load i8, ptr %l1, !tbaa !22
  %t8 = icmp eq i8 %t6, 104
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load i64, ptr %l2, !tbaa !24
  store i64 %t10, ptr %l8, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t12 = load i64, ptr %l2, !tbaa !24
  %t15 = call i64 @compiler_2flineedit_2elineStart(ptr %v0, { i64, ptr } %t11, i64 %t12)
  store i64 %t15, ptr %l11
  br label %bb3
bb2:
  br label %bb8
bb3:
  %t16 = load i64, ptr %l8, !tbaa !24
  %t17 = load i64, ptr %l11, !tbaa !24
  %t18 = icmp sgt i64 %t16, %t17
  br i1 %t18, label %bb4, label %bb5
bb4:
  %t20 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t21 = load i64, ptr %l2, !tbaa !24
  %t24 = call i64 @compiler_2flineedit_2eprevAt(ptr %v0, { i64, ptr } %t20, i64 %t21)
  store i64 %t24, ptr %l16
  br label %bb6
bb5:
  %t25 = load i64, ptr %l2, !tbaa !24
  store i64 %t25, ptr %l13, !tbaa !24
  br label %bb7
bb6:
  %t27 = load i64, ptr %l16, !tbaa !24
  store i64 %t27, ptr %l13, !tbaa !24
  br label %bb7
bb7:
  %t28 = load i64, ptr %l13, !tbaa !24
  %t29 = insertvalue { i32, i64 } zeroinitializer, i64 %t28, 1
  store { i32, i64 } %t29, ptr %rv
  br label %ret
bb8:
  %t30 = load i8, ptr %l1, !tbaa !22
  %t32 = icmp eq i8 %t30, 108
  br i1 %t32, label %bb9, label %bb10
bb9:
  %t34 = load i64, ptr %l2, !tbaa !24
  store i64 %t34, ptr %l20, !tbaa !24
  %t35 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t36 = load i64, ptr %l2, !tbaa !24
  %t39 = call i64 @compiler_2flineedit_2elineEnd(ptr %v0, { i64, ptr } %t35, i64 %t36)
  store i64 %t39, ptr %l23
  br label %bb11
bb10:
  br label %bb16
bb11:
  %t40 = load i64, ptr %l20, !tbaa !24
  %t41 = load i64, ptr %l23, !tbaa !24
  %t42 = icmp slt i64 %t40, %t41
  br i1 %t42, label %bb12, label %bb13
bb12:
  %t44 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t45 = load i64, ptr %l2, !tbaa !24
  %t48 = call i64 @compiler_2flineedit_2enextAt(ptr %v0, { i64, ptr } %t44, i64 %t45)
  store i64 %t48, ptr %l28
  br label %bb14
bb13:
  %t49 = load i64, ptr %l2, !tbaa !24
  store i64 %t49, ptr %l25, !tbaa !24
  br label %bb15
bb14:
  %t51 = load i64, ptr %l28, !tbaa !24
  store i64 %t51, ptr %l25, !tbaa !24
  br label %bb15
bb15:
  %t52 = load i64, ptr %l25, !tbaa !24
  %t53 = insertvalue { i32, i64 } zeroinitializer, i64 %t52, 1
  store { i32, i64 } %t53, ptr %rv
  br label %ret
bb16:
  %t54 = load i8, ptr %l1, !tbaa !22
  %t56 = icmp eq i8 %t54, 119
  br i1 %t56, label %bb17, label %bb18
bb17:
  %t58 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t59 = load i64, ptr %l2, !tbaa !24
  %t62 = call i64 @compiler_2flineedit_2ewordNext(ptr %v0, { i64, ptr } %t58, i64 %t59)
  store i64 %t62, ptr %l34
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t63 = load i64, ptr %l34, !tbaa !24
  %t64 = insertvalue { i32, i64 } zeroinitializer, i64 %t63, 1
  store { i32, i64 } %t64, ptr %rv
  br label %ret
bb20:
  %t65 = load i8, ptr %l1, !tbaa !22
  %t67 = icmp eq i8 %t65, 98
  br i1 %t67, label %bb21, label %bb22
bb21:
  %t69 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t70 = load i64, ptr %l2, !tbaa !24
  %t73 = call i64 @compiler_2flineedit_2ewordBack(ptr %v0, { i64, ptr } %t69, i64 %t70)
  store i64 %t73, ptr %l39
  br label %bb23
bb22:
  br label %bb24
bb23:
  %t74 = load i64, ptr %l39, !tbaa !24
  %t75 = insertvalue { i32, i64 } zeroinitializer, i64 %t74, 1
  store { i32, i64 } %t75, ptr %rv
  br label %ret
bb24:
  %t76 = load i8, ptr %l1, !tbaa !22
  %t78 = icmp eq i8 %t76, 101
  br i1 %t78, label %bb25, label %bb26
bb25:
  %t80 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t81 = load i64, ptr %l2, !tbaa !24
  %t84 = call i64 @compiler_2flineedit_2ewordLast(ptr %v0, { i64, ptr } %t80, i64 %t81)
  store i64 %t84, ptr %l44
  br label %bb27
bb26:
  br label %bb28
bb27:
  %t85 = load i64, ptr %l44, !tbaa !24
  %t86 = insertvalue { i32, i64 } zeroinitializer, i64 %t85, 1
  store { i32, i64 } %t86, ptr %rv
  br label %ret
bb28:
  %t87 = load i8, ptr %l1, !tbaa !22
  %t89 = icmp eq i8 %t87, 48
  br i1 %t89, label %bb29, label %bb30
bb29:
  %t91 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t92 = load i64, ptr %l2, !tbaa !24
  %t95 = call i64 @compiler_2flineedit_2elineStart(ptr %v0, { i64, ptr } %t91, i64 %t92)
  store i64 %t95, ptr %l49
  br label %bb31
bb30:
  br label %bb32
bb31:
  %t96 = load i64, ptr %l49, !tbaa !24
  %t97 = insertvalue { i32, i64 } zeroinitializer, i64 %t96, 1
  store { i32, i64 } %t97, ptr %rv
  br label %ret
bb32:
  %t98 = load i8, ptr %l1, !tbaa !22
  %t100 = icmp eq i8 %t98, 36
  br i1 %t100, label %bb33, label %bb34
bb33:
  %t102 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t103 = load i64, ptr %l2, !tbaa !24
  %t106 = call i64 @compiler_2flineedit_2elineEnd(ptr %v0, { i64, ptr } %t102, i64 %t103)
  store i64 %t106, ptr %l54
  br label %bb35
bb34:
  br label %bb36
bb35:
  %t107 = load i64, ptr %l54, !tbaa !24
  %t108 = insertvalue { i32, i64 } zeroinitializer, i64 %t107, 1
  store { i32, i64 } %t108, ptr %rv
  br label %ret
bb36:
  %t109 = load i8, ptr %l1, !tbaa !22
  %t111 = icmp eq i8 %t109, 94
  br i1 %t111, label %bb37, label %bb38
bb37:
  %t113 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t114 = load i64, ptr %l2, !tbaa !24
  %t117 = call i64 @compiler_2flineedit_2efirstWord(ptr %v0, { i64, ptr } %t113, i64 %t114)
  store i64 %t117, ptr %l59
  br label %bb39
bb38:
  br label %bb40
bb39:
  %t118 = load i64, ptr %l59, !tbaa !24
  %t119 = insertvalue { i32, i64 } zeroinitializer, i64 %t118, 1
  store { i32, i64 } %t119, ptr %rv
  br label %ret
bb40:
  %t121 = insertvalue { i32, i64 } zeroinitializer, i32 65536, 0
  store { i32, i64 } %t121, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2etoNormal(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca i64
  %l10 = alloca i64
  %l12 = alloca ptr
  %l17 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lineedit:Editor", ptr %t1, i32 0, i32 5
  store i1 true, ptr %t3, !tbaa !21
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/lineedit:Editor", ptr %t4, i32 0, i32 32
  store i64 0, ptr %t6, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/lineedit:Editor", ptr %t7, i32 0, i32 33
  store i8 0, ptr %t9, !tbaa !22
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/lineedit:Editor", ptr %t10, i32 0, i32 4
  %t13 = load i64, ptr %t12, !tbaa !24
  store i64 %t13, ptr %l5, !tbaa !24
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/lineedit:Editor", ptr %t14, i32 0, i32 3
  %t17 = load { i64, ptr }, ptr %t16, !tbaa !27
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/lineedit:Editor", ptr %t18, i32 0, i32 4
  %t21 = load i64, ptr %t20, !tbaa !24
  %t24 = call i64 @compiler_2flineedit_2elineStart(ptr %v0, { i64, ptr } %t17, i64 %t21)
  store i64 %t24, ptr %l10
  br label %bb1
bb1:
  %t25 = load i64, ptr %l5, !tbaa !24
  %t26 = load i64, ptr %l10, !tbaa !24
  %t27 = icmp sgt i64 %t25, %t26
  br i1 %t27, label %bb2, label %bb3
bb2:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l12, !tbaa !29
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/lineedit:Editor", ptr %t30, i32 0, i32 3
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/lineedit:Editor", ptr %t34, i32 0, i32 4
  %t37 = load i64, ptr %t36, !tbaa !24
  %t40 = call i64 @compiler_2flineedit_2eprevAt(ptr %v0, { i64, ptr } %t33, i64 %t37)
  store i64 %t40, ptr %l17
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t41 = load i64, ptr %l17, !tbaa !24
  %t42 = load ptr, ptr %l12, !tbaa !29
  %t43 = getelementptr %"compiler/lineedit:Editor", ptr %t42, i32 0, i32 4
  store i64 %t41, ptr %t43, !tbaa !24
  br label %bb5
bb5:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2etyped(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l15 = alloca { i64, ptr }
  %l21 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store i32 0, ptr %l2
  store { i64, ptr } %a1, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t4 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  store i64 %t6, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l4, !tbaa !24
  %t9 = load i64, ptr %l5, !tbaa !24
  %t12 = icmp slt i64 %t8, %t9
  %t14 = xor i1 %t12, true
  br i1 %t14, label %bb2, label %bb3
bb2:
  br label %bb7
bb3:
  br label %bb4
bb4:
  %t16 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t16, ptr %l15, !tbaa !27
  %t17 = load i64, ptr %l4, !tbaa !24
  %t19 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr i8, ptr %t20, i64 %t17
  %t22 = load i8, ptr %t21, !tbaa !32
  %t29 = call i32 @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eFeed(ptr %v0, ptr %a0, i8 %t22)
  store i32 %t29, ptr %l21
  br label %bb5
bb5:
  %t30 = load i32, ptr %l21, !range !{i32 0, i32 4}
  store i32 %t30, ptr %l2
  br label %bb6
bb6:
  %t31 = load i64, ptr %l4, !tbaa !24
  %t34 = add i64 %t31, 1
  store i64 %t34, ptr %l4, !tbaa !24
  br label %bb1
bb7:
  %t36 = load i32, ptr %l2, !range !{i32 0, i32 4}
  store i32 %t36, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eundo(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/lineedit:snap"
  %l2 = alloca %"compiler/lineedit:snap"
  %l5 = alloca %"compiler/lineedit:snap"
  %l6 = alloca i32
  %l7 = alloca ptr
  %l9 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lineedit:Editor", ptr %t1, i32 0, i32 17
  %t5 = call { i32, %"compiler/lineedit:snap" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flineedit_3asnap_3e_2ePop_3ccompiler_2flineedit_3asnap_3e(ptr %v0, ptr %v0, ptr %t3)
  %t6 = extractvalue { i32, %"compiler/lineedit:snap" } %t5, 1
  %t7 = extractvalue { i32, %"compiler/lineedit:snap" } %t5, 0
  store i32 %t7, ptr %l6
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9, !prof !99
ok.9:
  store %"compiler/lineedit:snap" %t6, ptr %l5
  br label %bb1
bb1:
  %t10 = load %"compiler/lineedit:snap", ptr %l5
  store %"compiler/lineedit:snap" %t10, ptr %l2
  br label %bb4
bb2:
  br label %bb3
bb3:
  br label %ret
bb4:
  %t11 = load %"compiler/lineedit:snap", ptr %l2
  store %"compiler/lineedit:snap" %t11, ptr %l1
  %t12 = load ptr, ptr %l0, !tbaa !29
  store ptr %t12, ptr %l7, !tbaa !29
  %t13 = getelementptr %"compiler/lineedit:snap", ptr %l1, i32 0, i32 0
  %t14 = load { i64, ptr }, ptr %t13, !tbaa !27
  %t15 = load ptr, ptr %l7, !tbaa !29
  %t16 = getelementptr %"compiler/lineedit:Editor", ptr %t15, i32 0, i32 3
  %t17 = load { i64, ptr }, ptr %t16, !tbaa !27
  store { i64, ptr } %t17, ptr %l9, !tbaa !27
  %t19 = load ptr, ptr %l7, !tbaa !29
  %t20 = getelementptr %"compiler/lineedit:Editor", ptr %t19, i32 0, i32 3
  store { i64, ptr } %t14, ptr %t20, !tbaa !27
  %t21 = load i1, ptr @olang_2esole_2ecompiler_2flineedit_3aEditor_2e3
  br i1 %t21, label %bb5, label %bb6
bb5:
  %t23 = load { i64, ptr }, ptr %l9
  %t24 = extractvalue { i64, ptr } %t23, 1
  call void @__olang_region_release(ptr %t24)
  store { i64, ptr } zeroinitializer, ptr %l9
  br label %bb6
bb6:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/lineedit:snap", ptr %l1, i32 0, i32 1
  %t27 = load i64, ptr %t26, !tbaa !24
  %t30 = getelementptr %"compiler/lineedit:Editor", ptr %t25, i32 0, i32 4
  store i64 %t27, ptr %t30, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eup(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l8 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l17 = alloca i64
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lineedit:Editor", ptr %t1, i32 0, i32 3
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l1, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/lineedit:Editor", ptr %t7, i32 0, i32 4
  %t10 = load i64, ptr %t9, !tbaa !24
  %t13 = call i64 @compiler_2flineedit_2elineStart(ptr %v0, { i64, ptr } %t6, i64 %t10)
  store i64 %t13, ptr %l8
  br label %bb1
bb1:
  %t14 = load i64, ptr %l8, !tbaa !24
  store i64 %t14, ptr %l2, !tbaa !24
  %t15 = load i64, ptr %l2, !tbaa !24
  %t17 = icmp eq i64 %t15, 0
  br i1 %t17, label %bb2, label %bb3
bb2:
  %t19 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eolder(ptr %v0, ptr %t19)
  br label %bb4
bb3:
  br label %bb5
bb4:
  br label %ret
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l12, !tbaa !29
  %t22 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t22, ptr %l13, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t24 = load i64, ptr %l2, !tbaa !24
  %t26 = sub i64 %t24, 1
  %t29 = call i64 @compiler_2flineedit_2elineStart(ptr %v0, { i64, ptr } %t23, i64 %t26)
  store i64 %t29, ptr %l17
  br label %bb6
bb6:
  %t30 = load i64, ptr %l2, !tbaa !24
  %t32 = sub i64 %t30, 1
  store i64 %t32, ptr %l19, !tbaa !24
  %t33 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t33, ptr %l20, !tbaa !27
  %t34 = load i64, ptr %l2, !tbaa !24
  store i64 %t34, ptr %l21, !tbaa !24
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/lineedit:Editor", ptr %t35, i32 0, i32 4
  %t38 = load i64, ptr %t37, !tbaa !24
  store i64 %t38, ptr %l23, !tbaa !24
  %t39 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  store i64 %t40, ptr %l24, !tbaa !24
  %t41 = load i64, ptr %l21, !tbaa !24
  %t42 = icmp sge i64 %t41, 0
  br i1 %t42, label %bb7, label %bb8
bb7:
  %t44 = load i64, ptr %l21, !tbaa !24
  %t45 = load i64, ptr %l23, !tbaa !24
  %t46 = icmp sle i64 %t44, %t45
  br i1 %t46, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_576d906cf1a69575_2b5fe4737c0e1301)
  unreachable
bb9:
  %t48 = load i64, ptr %l23, !tbaa !24
  %t49 = load i64, ptr %l24, !tbaa !24
  %t50 = icmp sle i64 %t48, %t49
  br i1 %t50, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_576d906cf1a69575_2b5fe4737c0e1301)
  unreachable
bb11:
  %t52 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = load i64, ptr %l21, !tbaa !24
  %t55 = load i64, ptr %l23, !tbaa !24
  %t56 = getelementptr i8, ptr %t53, i64 %t54
  %t57 = sub i64 %t55, %t54
  %t58 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t56, 1
  %t61 = call i64 @compiler_2flineedit_2ecells(ptr %v0, { i64, ptr } %t59)
  store i64 %t61, ptr %l29
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_576d906cf1a69575_2b5fe4737c0e1301)
  unreachable
bb13:
  %t62 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t63 = load i64, ptr %l17, !tbaa !24
  %t64 = load i64, ptr %l19, !tbaa !24
  %t65 = load i64, ptr %l29, !tbaa !24
  %t66 = call i64 @compiler_2flineedit_2eoffsetOf(ptr %v0, { i64, ptr } %t62, i64 %t63, i64 %t64, i64 %t65)
  store i64 %t66, ptr %l30
  br label %bb14
bb14:
  %t67 = load i64, ptr %l30, !tbaa !24
  %t68 = load ptr, ptr %l12, !tbaa !29
  %t69 = getelementptr %"compiler/lineedit:Editor", ptr %t68, i32 0, i32 4
  store i64 %t67, ptr %t69, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2ewordsHere(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l13 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l43 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lineedit:Editor", ptr %t1, i32 0, i32 3
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/lineedit:Editor", ptr %t5, i32 0, i32 4
  %t8 = load i64, ptr %t7, !tbaa !24
  %t11 = call i64 @compiler_2flineedit_2ewordHere(ptr %v0, { i64, ptr } %t4, i64 %t8)
  store i64 %t11, ptr %l13
  br label %bb1
bb1:
  %t12 = load i64, ptr %l13, !tbaa !24
  store i64 %t12, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  %t15 = sub i64 %a1, 1
  store i64 %t15, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t17 = load i64, ptr %l4, !tbaa !24
  %t18 = load i64, ptr %l3, !tbaa !24
  %t21 = icmp sgt i64 %t17, %t18
  br i1 %t21, label %bb2, label %bb3
bb2:
  %t23 = load i64, ptr %l5, !tbaa !24
  %t25 = icmp sgt i64 %t23, 0
  br i1 %t25, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb7
bb4:
  %t27 = load i64, ptr %l4, !tbaa !24
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = sub i64 %t27, %t28
  %t32 = load i64, ptr %l5, !tbaa !24
  %t35 = add i64 %t31, %t32
  %t37 = sub i64 %t35, 1
  %t38 = load i64, ptr %l5, !tbaa !24
  %t41 = sdiv i64 %t37, %t38
  store i64 %t41, ptr %l22, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb6
bb6:
  %t43 = load i64, ptr %l22, !tbaa !24
  store i64 %t43, ptr %l19, !tbaa !24
  br label %bb7
bb7:
  %t44 = load i64, ptr %l19, !tbaa !24
  store i64 %t44, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  %t45 = load i64, ptr %l7, !tbaa !24
  %t46 = load i64, ptr %l6, !tbaa !24
  %t49 = icmp slt i64 %t45, %t46
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb9, label %bb10
bb9:
  br label %bb14
bb10:
  br label %bb11
bb11:
  %t53 = load i64, ptr %l3, !tbaa !24
  %t54 = load i64, ptr %l7, !tbaa !24
  %t55 = load i64, ptr %l5, !tbaa !24
  %t58 = mul i64 %t54, %t55
  %t61 = add i64 %t53, %t58
  store i64 %t61, ptr %l8, !tbaa !24
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/lineedit:Editor", ptr %t63, i32 0, i32 3
  %t66 = load { i64, ptr }, ptr %t65, !tbaa !27
  %t67 = load i64, ptr %l2, !tbaa !24
  %t70 = call i64 @compiler_2flineedit_2ewordLast(ptr %v0, { i64, ptr } %t66, i64 %t67)
  store i64 %t70, ptr %l43
  br label %bb12
bb12:
  %t71 = load i64, ptr %l43, !tbaa !24
  store i64 %t71, ptr %l2, !tbaa !24
  br label %bb13
bb13:
  %t72 = load i64, ptr %l7, !tbaa !24
  %t75 = add i64 %t72, 1
  store i64 %t75, ptr %l7, !tbaa !24
  br label %bb8
bb14:
  %t77 = load i64, ptr %l2, !tbaa !24
  store i64 %t77, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2flineedit_2eencode(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d40, i32 0, i32 1) }, ptr %l3, !tbaa !27
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d41, i32 0, i32 1) }, ptr %l4, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t6 = call { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %a0, { i64, ptr } %t4, { i64, ptr } %t5)
  store { i64, ptr } %t6, ptr %l5
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t7, 0
  %t11 = extractvalue { i64, ptr } %t7, 1
  %t12 = mul i64 %t10, 1
  %t13 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t12)
  call void @llvm.memcpy.p0.p0.i64(ptr %t13, ptr %t11, i64 %t12, i1 false)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d42, i32 0, i32 1) }, ptr %l9, !tbaa !27
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d43, i32 0, i32 1) }, ptr %l10, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t18 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t19 = call { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %s0, ptr %s0, ptr %s0, ptr %v1, { i64, ptr } %t15, { i64, ptr } %t17, { i64, ptr } %t18)
  store { i64, ptr } %t19, ptr %l11
  br label %bb2
bb2:
  %t20 = load { i64, ptr }, ptr %l11, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t20, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2flineedit_2efirstWord(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l9 = alloca i64
  %l11 = alloca i1
  %l12 = alloca { i64, ptr }
  %l15 = alloca i64
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i64 @compiler_2flineedit_2elineStart(ptr %v0, { i64, ptr } %t1, i64 %t2)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  br label %bb2
bb2:
  %t7 = load i64, ptr %l2, !tbaa !24
  store i64 %t7, ptr %l6, !tbaa !24
  %t8 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t9 = load i64, ptr %l1, !tbaa !24
  %t12 = call i64 @compiler_2flineedit_2elineEnd(ptr %v0, { i64, ptr } %t8, i64 %t9)
  store i64 %t12, ptr %l9
  br label %bb3
bb3:
  %t13 = load i64, ptr %l6, !tbaa !24
  %t14 = load i64, ptr %l9, !tbaa !24
  %t15 = icmp slt i64 %t13, %t14
  br i1 %t15, label %bb4, label %bb5
bb4:
  %t17 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t17, ptr %l12, !tbaa !27
  %t18 = load i64, ptr %l2, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr i8, ptr %t21, i64 %t18
  %t23 = load i8, ptr %t22, !tbaa !32
  %t25 = call i64 @compiler_2flineedit_2eclass(i8 %t23)
  store i64 %t25, ptr %l15
  br label %bb6
bb5:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb7
bb6:
  %t26 = load i64, ptr %l15, !tbaa !24
  %t27 = icmp eq i64 %t26, 0
  store i1 %t27, ptr %l11, !tbaa !21
  br label %bb7
bb7:
  %t29 = load i1, ptr %l11, !tbaa !21
  %t30 = xor i1 %t29, true
  br i1 %t30, label %bb8, label %bb9
bb8:
  br label %bb12
bb9:
  br label %bb10
bb10:
  %t32 = load i64, ptr %l2, !tbaa !24
  %t35 = add i64 %t32, 1
  store i64 %t35, ptr %l2, !tbaa !24
  br label %bb11
bb11:
  br label %bb2
bb12:
  %t37 = load i64, ptr %l2, !tbaa !24
  store i64 %t37, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2flineedit_2eincomplete(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l8 = alloca i1
  %l9 = alloca { i64, ptr }
  %l12 = alloca i1
  %l19 = alloca i1
  %l20 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca { i64, ptr }
  %l34 = alloca i64
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = sub i64 %t1, 1
  store i64 %t3, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l2, !tbaa !24
  %t7 = icmp sgt i64 %t5, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t9, ptr %l9, !tbaa !27
  %t10 = load i64, ptr %l2, !tbaa !24
  %t12 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr i8, ptr %t13, i64 %t10
  %t15 = load i8, ptr %t14, !tbaa !32
  %t17 = call i1 @compiler_2flineedit_2eisCont(i8 %t15)
  store i1 %t17, ptr %l12
  br label %bb4
bb3:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb5
bb4:
  %t18 = load i1, ptr %l12, !tbaa !21
  store i1 %t18, ptr %l8, !tbaa !21
  br label %bb5
bb5:
  %t19 = load i1, ptr %l8, !tbaa !21
  %t20 = xor i1 %t19, true
  br i1 %t20, label %bb6, label %bb7
bb6:
  br label %bb10
bb7:
  br label %bb8
bb8:
  %t22 = load i64, ptr %l2, !tbaa !24
  %t25 = sub i64 %t22, 1
  store i64 %t25, ptr %l2, !tbaa !24
  br label %bb9
bb9:
  br label %bb1
bb10:
  %t27 = load i64, ptr %l2, !tbaa !24
  %t29 = icmp slt i64 %t27, 0
  br i1 %t29, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb13
bb12:
  %t31 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t31, ptr %l20, !tbaa !27
  %t32 = load i64, ptr %l2, !tbaa !24
  %t34 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr i8, ptr %t35, i64 %t32
  %t37 = load i8, ptr %t36, !tbaa !32
  %t39 = icmp ult i8 %t37, -64
  store i1 %t39, ptr %l19, !tbaa !21
  br label %bb13
bb13:
  %t41 = load i1, ptr %l19, !tbaa !21
  br i1 %t41, label %bb14, label %bb15
bb14:
  store i1 false, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t43 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t43, ptr %l25, !tbaa !27
  %t44 = load i64, ptr %l2, !tbaa !24
  %t46 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr i8, ptr %t47, i64 %t44
  %t49 = load i8, ptr %t48, !tbaa !32
  %t51 = icmp ult i8 %t49, -32
  br i1 %t51, label %bb17, label %bb18
bb17:
  store i64 2, ptr %l29, !tbaa !24
  br label %bb22
bb18:
  %t53 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t53, ptr %l30, !tbaa !27
  %t54 = load i64, ptr %l2, !tbaa !24
  %t56 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = getelementptr i8, ptr %t57, i64 %t54
  %t59 = load i8, ptr %t58, !tbaa !32
  %t61 = icmp ult i8 %t59, -16
  br i1 %t61, label %bb19, label %bb20
bb19:
  store i64 3, ptr %l34, !tbaa !24
  br label %bb21
bb20:
  store i64 4, ptr %l34, !tbaa !24
  br label %bb21
bb21:
  %t63 = load i64, ptr %l34, !tbaa !24
  store i64 %t63, ptr %l29, !tbaa !24
  br label %bb22
bb22:
  %t64 = load i64, ptr %l29, !tbaa !24
  %t65 = load i64, ptr %l1, !tbaa !24
  %t66 = load i64, ptr %l2, !tbaa !24
  %t69 = sub i64 %t65, %t66
  %t73 = icmp slt i64 %t69, %t64
  store i1 %t73, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2flineedit_2eindexOf(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l18 = alloca i64
  %l21 = alloca i64
  %l30 = alloca i64
  %l33 = alloca i1
  %l47 = alloca i1
  %l48 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t4 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t9 = sub i64 %t3, %t6
  %t11 = add i64 %t9, 1
  store i64 %t11, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t13 = load i64, ptr %l3, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t17 = icmp sgt i64 %t13, %t14
  br i1 %t17, label %bb1, label %bb2
bb1:
  %t19 = load i64, ptr %l4, !tbaa !24
  %t21 = icmp sgt i64 %t19, 0
  br i1 %t21, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb6
bb3:
  %t23 = load i64, ptr %l3, !tbaa !24
  %t24 = load i64, ptr %l2, !tbaa !24
  %t27 = sub i64 %t23, %t24
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = add i64 %t27, %t28
  %t33 = sub i64 %t31, 1
  %t34 = load i64, ptr %l4, !tbaa !24
  %t37 = sdiv i64 %t33, %t34
  store i64 %t37, ptr %l21, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb5
bb5:
  %t39 = load i64, ptr %l21, !tbaa !24
  store i64 %t39, ptr %l18, !tbaa !24
  br label %bb6
bb6:
  %t40 = load i64, ptr %l18, !tbaa !24
  store i64 %t40, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  %t42 = sub i64 %t41, 1
  store i64 %t42, ptr %l30, !tbaa !24
  %t43 = load i64, ptr %l5, !tbaa !24
  %t44 = icmp slt i64 %t43, 2147483648
  %t45 = load i64, ptr %l6, !tbaa !24
  %t46 = icmp sge i64 %t45, 0
  %t49 = and i1 %t44, %t46
  store i1 %t49, ptr %l33, !tbaa !21
  br label %bb7
bb7:
  %t50 = load i64, ptr %l6, !tbaa !24
  %t51 = load i64, ptr %l5, !tbaa !24
  %t54 = icmp slt i64 %t50, %t51
  %t56 = xor i1 %t54, true
  br i1 %t56, label %bb8, label %bb9
bb8:
  br label %bb24
bb9:
  br label %bb10
bb10:
  %t58 = load i64, ptr %l2, !tbaa !24
  %t59 = load i64, ptr %l6, !tbaa !24
  %t60 = load i64, ptr %l4, !tbaa !24
  %t63 = mul i64 %t59, %t60
  %t66 = add i64 %t58, %t63
  store i64 %t66, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb11
bb11:
  %t68 = load i64, ptr %l8, !tbaa !24
  %t69 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t69, 0
  %t74 = icmp slt i64 %t68, %t71
  br i1 %t74, label %bb12, label %bb13
bb12:
  %t76 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t76, ptr %l48, !tbaa !27
  %t77 = load i64, ptr %l7, !tbaa !24
  %t78 = load i64, ptr %l8, !tbaa !24
  %t81 = add i64 %t77, %t78
  %t83 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !27
  %t85 = getelementptr i8, ptr %t84, i64 %t81
  %t86 = load i8, ptr %t85, !tbaa !32
  %t87 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t87, ptr %l53, !tbaa !27
  %t88 = load i64, ptr %l8, !tbaa !24
  %t90 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr i8, ptr %t91, i64 %t88
  %t93 = load i8, ptr %t92, !tbaa !32
  %t96 = icmp eq i8 %t86, %t93
  store i1 %t96, ptr %l47, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb14
bb14:
  %t98 = load i1, ptr %l47, !tbaa !21
  %t99 = xor i1 %t98, true
  br i1 %t99, label %bb15, label %bb16
bb15:
  br label %bb19
bb16:
  br label %bb17
bb17:
  %t101 = load i64, ptr %l8, !tbaa !24
  %t104 = add i64 %t101, 1
  store i64 %t104, ptr %l8, !tbaa !24
  br label %bb18
bb18:
  br label %bb11
bb19:
  %t106 = load i64, ptr %l8, !tbaa !24
  %t107 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t107, 0
  %t112 = icmp eq i64 %t106, %t109
  br i1 %t112, label %bb20, label %bb21
bb20:
  %t114 = load i64, ptr %l7, !tbaa !24
  store i64 %t114, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t116 = load i64, ptr %l6, !tbaa !24
  %t119 = add i64 %t116, 1
  store i64 %t119, ptr %l6, !tbaa !24
  br label %bb7
bb24:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2flineedit_2eisCont(i8 %a0) #0 {
entry:
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = and i8 %a0, -64
  %t5 = icmp eq i8 %t3, -128
  store i1 %t5, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2flineedit_2elineEnd(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i64
  %l8 = alloca i1
  %l9 = alloca { i64, ptr }
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a1, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l2, !tbaa !24
  %t4 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t9 = icmp slt i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t11, ptr %l9, !tbaa !27
  %t12 = load i64, ptr %l2, !tbaa !24
  %t14 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr i8, ptr %t15, i64 %t12
  %t17 = load i8, ptr %t16, !tbaa !32
  %t19 = icmp ne i8 %t17, 10
  store i1 %t19, ptr %l8, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb4
bb4:
  %t21 = load i1, ptr %l8, !tbaa !21
  %t22 = xor i1 %t21, true
  br i1 %t22, label %bb5, label %bb6
bb5:
  br label %bb9
bb6:
  br label %bb7
bb7:
  %t24 = load i64, ptr %l2, !tbaa !24
  %t27 = add i64 %t24, 1
  store i64 %t27, ptr %l2, !tbaa !24
  br label %bb8
bb8:
  br label %bb1
bb9:
  %t29 = load i64, ptr %l2, !tbaa !24
  store i64 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2flineedit_2elineStart(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l2 = alloca i64
  %l6 = alloca i1
  %l7 = alloca { i64, ptr }
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a1, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l2, !tbaa !24
  %t5 = icmp sgt i64 %t3, 0
  br i1 %t5, label %bb2, label %bb3
bb2:
  store { i64, ptr } %a0, ptr %l7, !tbaa !27
  %t8 = load i64, ptr %l2, !tbaa !24
  %t10 = sub i64 %t8, 1
  %t12 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr i8, ptr %t13, i64 %t10
  %t15 = load i8, ptr %t14, !tbaa !32
  %t17 = icmp ne i8 %t15, 10
  store i1 %t17, ptr %l6, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb4
bb4:
  %t19 = load i1, ptr %l6, !tbaa !21
  %t20 = xor i1 %t19, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb9
bb6:
  br label %bb7
bb7:
  %t22 = load i64, ptr %l2, !tbaa !24
  %t25 = sub i64 %t22, 1
  store i64 %t25, ptr %l2, !tbaa !24
  br label %bb8
bb8:
  br label %bb1
bb9:
  %t27 = load i64, ptr %l2, !tbaa !24
  store i64 %t27, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2flineedit_2enextAt(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l14 = alloca i1
  %l15 = alloca { i64, ptr }
  %l18 = alloca i1
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t2, 0
  %t7 = icmp sge i64 %t1, %t4
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l1, !tbaa !24
  store i64 %t9, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t11 = load i64, ptr %l1, !tbaa !24
  %t13 = add i64 %t11, 1
  store i64 %t13, ptr %l2, !tbaa !24
  br label %bb4
bb4:
  %t15 = load i64, ptr %l2, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  %t21 = icmp slt i64 %t15, %t18
  br i1 %t21, label %bb5, label %bb6
bb5:
  %t23 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t23, ptr %l15, !tbaa !27
  %t24 = load i64, ptr %l2, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr i8, ptr %t27, i64 %t24
  %t29 = load i8, ptr %t28, !tbaa !32
  %t31 = call i1 @compiler_2flineedit_2eisCont(i8 %t29)
  store i1 %t31, ptr %l18
  br label %bb7
bb6:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb8
bb7:
  %t32 = load i1, ptr %l18, !tbaa !21
  store i1 %t32, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t33 = load i1, ptr %l14, !tbaa !21
  %t34 = xor i1 %t33, true
  br i1 %t34, label %bb9, label %bb10
bb9:
  br label %bb13
bb10:
  br label %bb11
bb11:
  %t36 = load i64, ptr %l2, !tbaa !24
  %t39 = add i64 %t36, 1
  store i64 %t39, ptr %l2, !tbaa !24
  br label %bb12
bb12:
  br label %bb4
bb13:
  %t41 = load i64, ptr %l2, !tbaa !24
  store i64 %t41, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2flineedit_2eoffsetOf(ptr %v0, { i64, ptr } %a0, i64 %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l2 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l16 = alloca i64
  %l19 = alloca i64
  %l42 = alloca i64
  %l49 = alloca i64
  %rv = alloca i64
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a1, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  store i64 %a3, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t5 = load i64, ptr %l6, !tbaa !24
  %t6 = load i64, ptr %l5, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l7, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb6
bb3:
  %t15 = load i64, ptr %l6, !tbaa !24
  %t16 = load i64, ptr %l5, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l7, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l7, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l19, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb5
bb5:
  %t31 = load i64, ptr %l19, !tbaa !24
  store i64 %t31, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l16, !tbaa !24
  store i64 %t32, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb7
bb7:
  %t33 = load i64, ptr %l9, !tbaa !24
  %t34 = load i64, ptr %l8, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  br label %bb16
bb9:
  br label %bb10
bb10:
  %t41 = load i64, ptr %l5, !tbaa !24
  %t42 = load i64, ptr %l9, !tbaa !24
  %t43 = load i64, ptr %l7, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l10, !tbaa !24
  %t51 = load i64, ptr %l4, !tbaa !24
  %t52 = load i64, ptr %l2, !tbaa !24
  %t55 = icmp sge i64 %t51, %t52
  br i1 %t55, label %bb11, label %bb12
bb11:
  br label %bb16
bb12:
  br label %bb13
bb13:
  %t58 = load i64, ptr %l4, !tbaa !24
  %t61 = call i64 @compiler_2flineedit_2enextAt(ptr %v0, { i64, ptr } %a0, i64 %t58)
  store i64 %t61, ptr %l42
  br label %bb14
bb14:
  %t62 = load i64, ptr %l42, !tbaa !24
  store i64 %t62, ptr %l4, !tbaa !24
  br label %bb15
bb15:
  %t63 = load i64, ptr %l9, !tbaa !24
  %t66 = add i64 %t63, 1
  store i64 %t66, ptr %l9, !tbaa !24
  br label %bb7
bb16:
  %t68 = load i64, ptr %l4, !tbaa !24
  %t69 = load i64, ptr %l2, !tbaa !24
  %t72 = icmp slt i64 %t68, %t69
  br i1 %t72, label %bb17, label %bb18
bb17:
  %t74 = load i64, ptr %l4, !tbaa !24
  store i64 %t74, ptr %l49, !tbaa !24
  br label %bb19
bb18:
  %t76 = load i64, ptr %l2, !tbaa !24
  store i64 %t76, ptr %l49, !tbaa !24
  br label %bb19
bb19:
  %t78 = load i64, ptr %l49, !tbaa !24
  store i64 %t78, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2flineedit_2eone(ptr %v0, i8 %a0) #0 {
entry:
  %l2 = alloca [1 x i8]
  %l3 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = insertvalue [1 x i8] undef, i8 %a0, 0
  store [1 x i8] %t3, ptr %l2
  %t4 = mul i64 1, 1
  %t5 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 1, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  store { i64, ptr } %t7, ptr %l3, !tbaa !27
  %t8 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !27
  %t10 = mul i64 1, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t9, ptr %l2, i64 %t10, i1 false)
  %t11 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t11, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2flineedit_2eprevAt(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca i64
  %l10 = alloca i1
  %l11 = alloca { i64, ptr }
  %l14 = alloca i1
  %rv = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp sle i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i64 0, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load i64, ptr %l1, !tbaa !24
  %t8 = sub i64 %t6, 1
  store i64 %t8, ptr %l2, !tbaa !24
  br label %bb4
bb4:
  %t10 = load i64, ptr %l2, !tbaa !24
  %t12 = icmp sgt i64 %t10, 0
  br i1 %t12, label %bb5, label %bb6
bb5:
  store { i64, ptr } %a0, ptr %l11, !tbaa !27
  %t15 = load i64, ptr %l2, !tbaa !24
  %t17 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = getelementptr i8, ptr %t18, i64 %t15
  %t20 = load i8, ptr %t19, !tbaa !32
  %t22 = call i1 @compiler_2flineedit_2eisCont(i8 %t20)
  store i1 %t22, ptr %l14
  br label %bb7
bb6:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb8
bb7:
  %t23 = load i1, ptr %l14, !tbaa !21
  store i1 %t23, ptr %l10, !tbaa !21
  br label %bb8
bb8:
  %t24 = load i1, ptr %l10, !tbaa !21
  %t25 = xor i1 %t24, true
  br i1 %t25, label %bb9, label %bb10
bb9:
  br label %bb13
bb10:
  br label %bb11
bb11:
  %t27 = load i64, ptr %l2, !tbaa !24
  %t30 = sub i64 %t27, 1
  store i64 %t30, ptr %l2, !tbaa !24
  br label %bb12
bb12:
  br label %bb4
bb13:
  %t32 = load i64, ptr %l2, !tbaa !24
  store i64 %t32, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2flineedit_2ewordBack(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l7 = alloca i1
  %l8 = alloca { i64, ptr }
  %l12 = alloca i64
  %l21 = alloca { i64, ptr }
  %l25 = alloca i64
  %l28 = alloca i1
  %l29 = alloca { i64, ptr }
  %l33 = alloca i64
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a1, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l2, !tbaa !24
  %t5 = icmp sgt i64 %t3, 0
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t7, ptr %l8, !tbaa !27
  %t8 = load i64, ptr %l2, !tbaa !24
  %t10 = sub i64 %t8, 1
  %t12 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr i8, ptr %t13, i64 %t10
  %t15 = load i8, ptr %t14, !tbaa !32
  %t17 = call i64 @compiler_2flineedit_2eclass(i8 %t15)
  store i64 %t17, ptr %l12
  br label %bb4
bb3:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb5
bb4:
  %t18 = load i64, ptr %l12, !tbaa !24
  %t19 = icmp eq i64 %t18, 0
  store i1 %t19, ptr %l7, !tbaa !21
  br label %bb5
bb5:
  %t21 = load i1, ptr %l7, !tbaa !21
  %t22 = xor i1 %t21, true
  br i1 %t22, label %bb6, label %bb7
bb6:
  br label %bb10
bb7:
  br label %bb8
bb8:
  %t24 = load i64, ptr %l2, !tbaa !24
  %t27 = sub i64 %t24, 1
  store i64 %t27, ptr %l2, !tbaa !24
  br label %bb9
bb9:
  br label %bb1
bb10:
  %t29 = load i64, ptr %l2, !tbaa !24
  %t31 = icmp eq i64 %t29, 0
  br i1 %t31, label %bb11, label %bb12
bb11:
  store i64 0, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t34 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t34, ptr %l21, !tbaa !27
  %t35 = load i64, ptr %l2, !tbaa !24
  %t37 = sub i64 %t35, 1
  %t39 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr i8, ptr %t40, i64 %t37
  %t42 = load i8, ptr %t41, !tbaa !32
  %t44 = call i64 @compiler_2flineedit_2eclass(i8 %t42)
  store i64 %t44, ptr %l25
  br label %bb14
bb14:
  %t45 = load i64, ptr %l25, !tbaa !24
  store i64 %t45, ptr %l3, !tbaa !24
  br label %bb15
bb15:
  %t46 = load i64, ptr %l2, !tbaa !24
  %t48 = icmp sgt i64 %t46, 0
  br i1 %t48, label %bb16, label %bb17
bb16:
  %t50 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t50, ptr %l29, !tbaa !27
  %t51 = load i64, ptr %l2, !tbaa !24
  %t53 = sub i64 %t51, 1
  %t55 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = getelementptr i8, ptr %t56, i64 %t53
  %t58 = load i8, ptr %t57, !tbaa !32
  %t60 = call i64 @compiler_2flineedit_2eclass(i8 %t58)
  store i64 %t60, ptr %l33
  br label %bb18
bb17:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb19
bb18:
  %t61 = load i64, ptr %l3, !tbaa !24
  %t62 = load i64, ptr %l33, !tbaa !24
  %t64 = icmp eq i64 %t62, %t61
  store i1 %t64, ptr %l28, !tbaa !21
  br label %bb19
bb19:
  %t66 = load i1, ptr %l28, !tbaa !21
  %t67 = xor i1 %t66, true
  br i1 %t67, label %bb20, label %bb21
bb20:
  br label %bb24
bb21:
  br label %bb22
bb22:
  %t69 = load i64, ptr %l2, !tbaa !24
  %t72 = sub i64 %t69, 1
  store i64 %t72, ptr %l2, !tbaa !24
  br label %bb23
bb23:
  br label %bb15
bb24:
  %t74 = load i64, ptr %l2, !tbaa !24
  store i64 %t74, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2flineedit_2ewordEnd(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i64
  %l8 = alloca i1
  %l9 = alloca { i64, ptr }
  %l12 = alloca i64
  %l22 = alloca i1
  %l23 = alloca { i64, ptr }
  %l26 = alloca i64
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a1, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l2, !tbaa !24
  %t4 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t9 = icmp slt i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t11, ptr %l9, !tbaa !27
  %t12 = load i64, ptr %l2, !tbaa !24
  %t14 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr i8, ptr %t15, i64 %t12
  %t17 = load i8, ptr %t16, !tbaa !32
  %t19 = call i64 @compiler_2flineedit_2eclass(i8 %t17)
  store i64 %t19, ptr %l12
  br label %bb4
bb3:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb5
bb4:
  %t20 = load i64, ptr %l12, !tbaa !24
  %t21 = icmp ne i64 %t20, 1
  store i1 %t21, ptr %l8, !tbaa !21
  br label %bb5
bb5:
  %t23 = load i1, ptr %l8, !tbaa !21
  %t24 = xor i1 %t23, true
  br i1 %t24, label %bb6, label %bb7
bb6:
  br label %bb10
bb7:
  br label %bb8
bb8:
  %t26 = load i64, ptr %l2, !tbaa !24
  %t29 = add i64 %t26, 1
  store i64 %t29, ptr %l2, !tbaa !24
  br label %bb9
bb9:
  br label %bb1
bb10:
  br label %bb11
bb11:
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t32, 0
  %t37 = icmp slt i64 %t31, %t34
  br i1 %t37, label %bb12, label %bb13
bb12:
  %t39 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t39, ptr %l23, !tbaa !27
  %t40 = load i64, ptr %l2, !tbaa !24
  %t42 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr i8, ptr %t43, i64 %t40
  %t45 = load i8, ptr %t44, !tbaa !32
  %t47 = call i64 @compiler_2flineedit_2eclass(i8 %t45)
  store i64 %t47, ptr %l26
  br label %bb14
bb13:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb15
bb14:
  %t48 = load i64, ptr %l26, !tbaa !24
  %t49 = icmp eq i64 %t48, 1
  store i1 %t49, ptr %l22, !tbaa !21
  br label %bb15
bb15:
  %t51 = load i1, ptr %l22, !tbaa !21
  %t52 = xor i1 %t51, true
  br i1 %t52, label %bb16, label %bb17
bb16:
  br label %bb20
bb17:
  br label %bb18
bb18:
  %t54 = load i64, ptr %l2, !tbaa !24
  %t57 = add i64 %t54, 1
  store i64 %t57, ptr %l2, !tbaa !24
  br label %bb19
bb19:
  br label %bb11
bb20:
  %t59 = load i64, ptr %l2, !tbaa !24
  store i64 %t59, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2flineedit_2ewordHere(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l5 = alloca { i64, ptr }
  %l8 = alloca i64
  %l14 = alloca i1
  %l15 = alloca { i64, ptr }
  %l19 = alloca i64
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a1, ptr %l2, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t3, ptr %l5, !tbaa !27
  %t4 = load i64, ptr %l2, !tbaa !24
  %t6 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !27
  %t8 = getelementptr i8, ptr %t7, i64 %t4
  %t9 = load i8, ptr %t8, !tbaa !32
  %t11 = call i64 @compiler_2flineedit_2eclass(i8 %t9)
  store i64 %t11, ptr %l8
  br label %bb1
bb1:
  %t12 = load i64, ptr %l8, !tbaa !24
  store i64 %t12, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t13 = load i64, ptr %l2, !tbaa !24
  %t15 = add i64 %t13, 1
  %t16 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  %t21 = icmp slt i64 %t15, %t18
  br i1 %t21, label %bb3, label %bb4
bb3:
  %t23 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t23, ptr %l15, !tbaa !27
  %t24 = load i64, ptr %l2, !tbaa !24
  %t26 = add i64 %t24, 1
  %t28 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr i8, ptr %t29, i64 %t26
  %t31 = load i8, ptr %t30, !tbaa !32
  %t33 = call i64 @compiler_2flineedit_2eclass(i8 %t31)
  store i64 %t33, ptr %l19
  br label %bb5
bb4:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb6
bb5:
  %t34 = load i64, ptr %l3, !tbaa !24
  %t35 = load i64, ptr %l19, !tbaa !24
  %t37 = icmp eq i64 %t35, %t34
  store i1 %t37, ptr %l14, !tbaa !21
  br label %bb6
bb6:
  %t39 = load i1, ptr %l14, !tbaa !21
  %t40 = xor i1 %t39, true
  br i1 %t40, label %bb7, label %bb8
bb7:
  br label %bb11
bb8:
  br label %bb9
bb9:
  %t42 = load i64, ptr %l2, !tbaa !24
  %t45 = add i64 %t42, 1
  store i64 %t45, ptr %l2, !tbaa !24
  br label %bb10
bb10:
  br label %bb2
bb11:
  %t47 = load i64, ptr %l2, !tbaa !24
  store i64 %t47, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2flineedit_2ewordLast(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l6 = alloca i64
  %l11 = alloca i1
  %l12 = alloca { i64, ptr }
  %l15 = alloca i64
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %l32 = alloca i64
  %l38 = alloca i1
  %l39 = alloca { i64, ptr }
  %l43 = alloca i64
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t5 = call i64 @compiler_2flineedit_2enextAt(ptr %v0, { i64, ptr } %t1, i64 %a1)
  store i64 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i64, ptr %l6, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  br label %bb2
bb2:
  %t7 = load i64, ptr %l2, !tbaa !24
  %t8 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t13 = icmp slt i64 %t7, %t10
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t15, ptr %l12, !tbaa !27
  %t16 = load i64, ptr %l2, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i8, ptr %t19, i64 %t16
  %t21 = load i8, ptr %t20, !tbaa !32
  %t23 = call i64 @compiler_2flineedit_2eclass(i8 %t21)
  store i64 %t23, ptr %l15
  br label %bb5
bb4:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb6
bb5:
  %t24 = load i64, ptr %l15, !tbaa !24
  %t25 = icmp eq i64 %t24, 0
  store i1 %t25, ptr %l11, !tbaa !21
  br label %bb6
bb6:
  %t27 = load i1, ptr %l11, !tbaa !21
  %t28 = xor i1 %t27, true
  br i1 %t28, label %bb7, label %bb8
bb7:
  br label %bb11
bb8:
  br label %bb9
bb9:
  %t30 = load i64, ptr %l2, !tbaa !24
  %t33 = add i64 %t30, 1
  store i64 %t33, ptr %l2, !tbaa !24
  br label %bb10
bb10:
  br label %bb2
bb11:
  %t35 = load i64, ptr %l2, !tbaa !24
  %t36 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t36, 0
  %t41 = icmp sge i64 %t35, %t38
  br i1 %t41, label %bb12, label %bb13
bb12:
  %t43 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t44 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 0
  %t49 = call i64 @compiler_2flineedit_2eprevAt(ptr %v0, { i64, ptr } %t43, i64 %t46)
  store i64 %t49, ptr %l28
  br label %bb14
bb13:
  br label %bb15
bb14:
  %t50 = load i64, ptr %l28, !tbaa !24
  store i64 %t50, ptr %rv
  br label %ret
bb15:
  %t51 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t51, ptr %l29, !tbaa !27
  %t52 = load i64, ptr %l2, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr i8, ptr %t55, i64 %t52
  %t57 = load i8, ptr %t56, !tbaa !32
  %t59 = call i64 @compiler_2flineedit_2eclass(i8 %t57)
  store i64 %t59, ptr %l32
  br label %bb16
bb16:
  %t60 = load i64, ptr %l32, !tbaa !24
  store i64 %t60, ptr %l3, !tbaa !24
  br label %bb17
bb17:
  %t61 = load i64, ptr %l2, !tbaa !24
  %t63 = add i64 %t61, 1
  %t64 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t64, 0
  %t69 = icmp slt i64 %t63, %t66
  br i1 %t69, label %bb18, label %bb19
bb18:
  %t71 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t71, ptr %l39, !tbaa !27
  %t72 = load i64, ptr %l2, !tbaa !24
  %t74 = add i64 %t72, 1
  %t76 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = getelementptr i8, ptr %t77, i64 %t74
  %t79 = load i8, ptr %t78, !tbaa !32
  %t81 = call i64 @compiler_2flineedit_2eclass(i8 %t79)
  store i64 %t81, ptr %l43
  br label %bb20
bb19:
  store i1 false, ptr %l38, !tbaa !21
  br label %bb21
bb20:
  %t82 = load i64, ptr %l3, !tbaa !24
  %t83 = load i64, ptr %l43, !tbaa !24
  %t85 = icmp eq i64 %t83, %t82
  store i1 %t85, ptr %l38, !tbaa !21
  br label %bb21
bb21:
  %t87 = load i1, ptr %l38, !tbaa !21
  %t88 = xor i1 %t87, true
  br i1 %t88, label %bb22, label %bb23
bb22:
  br label %bb26
bb23:
  br label %bb24
bb24:
  %t90 = load i64, ptr %l2, !tbaa !24
  %t93 = add i64 %t90, 1
  store i64 %t93, ptr %l2, !tbaa !24
  br label %bb25
bb25:
  br label %bb17
bb26:
  %t95 = load i64, ptr %l2, !tbaa !24
  store i64 %t95, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2flineedit_2ewordNext(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l9 = alloca { i64, ptr }
  %l12 = alloca i64
  %l17 = alloca i1
  %l20 = alloca i1
  %l21 = alloca { i64, ptr }
  %l24 = alloca i64
  %l35 = alloca i1
  %l36 = alloca { i64, ptr }
  %l39 = alloca i64
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a1, ptr %l2, !tbaa !24
  %t3 = load i64, ptr %l2, !tbaa !24
  %t4 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t9 = icmp slt i64 %t3, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t11, ptr %l9, !tbaa !27
  %t12 = load i64, ptr %l2, !tbaa !24
  %t14 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr i8, ptr %t15, i64 %t12
  %t17 = load i8, ptr %t16, !tbaa !32
  %t19 = call i64 @compiler_2flineedit_2eclass(i8 %t17)
  store i64 %t19, ptr %l12
  br label %bb3
bb2:
  br label %bb17
bb3:
  %t20 = load i64, ptr %l12, !tbaa !24
  store i64 %t20, ptr %l3, !tbaa !24
  br label %bb4
bb4:
  %t21 = load i64, ptr %l2, !tbaa !24
  %t22 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t22, 0
  %t27 = icmp slt i64 %t21, %t24
  br i1 %t27, label %bb5, label %bb6
bb5:
  %t29 = load i64, ptr %l3, !tbaa !24
  %t31 = icmp ne i64 %t29, 0
  store i1 %t31, ptr %l17, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb7
bb7:
  %t33 = load i1, ptr %l17, !tbaa !21
  br i1 %t33, label %bb8, label %bb9
bb8:
  %t34 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t34, ptr %l21, !tbaa !27
  %t35 = load i64, ptr %l2, !tbaa !24
  %t37 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = getelementptr i8, ptr %t38, i64 %t35
  %t40 = load i8, ptr %t39, !tbaa !32
  %t42 = call i64 @compiler_2flineedit_2eclass(i8 %t40)
  store i64 %t42, ptr %l24
  br label %bb10
bb9:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb11
bb10:
  %t43 = load i64, ptr %l3, !tbaa !24
  %t44 = load i64, ptr %l24, !tbaa !24
  %t46 = icmp eq i64 %t44, %t43
  store i1 %t46, ptr %l20, !tbaa !21
  br label %bb11
bb11:
  %t48 = load i1, ptr %l20, !tbaa !21
  %t49 = xor i1 %t48, true
  br i1 %t49, label %bb12, label %bb13
bb12:
  br label %bb16
bb13:
  br label %bb14
bb14:
  %t51 = load i64, ptr %l2, !tbaa !24
  %t54 = add i64 %t51, 1
  store i64 %t54, ptr %l2, !tbaa !24
  br label %bb15
bb15:
  br label %bb4
bb16:
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t56 = load i64, ptr %l2, !tbaa !24
  %t57 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t57, 0
  %t62 = icmp slt i64 %t56, %t59
  br i1 %t62, label %bb19, label %bb20
bb19:
  %t64 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t64, ptr %l36, !tbaa !27
  %t65 = load i64, ptr %l2, !tbaa !24
  %t67 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !27
  %t69 = getelementptr i8, ptr %t68, i64 %t65
  %t70 = load i8, ptr %t69, !tbaa !32
  %t72 = call i64 @compiler_2flineedit_2eclass(i8 %t70)
  store i64 %t72, ptr %l39
  br label %bb21
bb20:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb22
bb21:
  %t73 = load i64, ptr %l39, !tbaa !24
  %t74 = icmp eq i64 %t73, 0
  store i1 %t74, ptr %l35, !tbaa !21
  br label %bb22
bb22:
  %t76 = load i1, ptr %l35, !tbaa !21
  %t77 = xor i1 %t76, true
  br i1 %t77, label %bb23, label %bb24
bb23:
  br label %bb27
bb24:
  br label %bb25
bb25:
  %t79 = load i64, ptr %l2, !tbaa !24
  %t82 = add i64 %t79, 1
  store i64 %t82, ptr %l2, !tbaa !24
  br label %bb26
bb26:
  br label %bb18
bb27:
  %t84 = load i64, ptr %l2, !tbaa !24
  store i64 %t84, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/lineedit:snap" @compiler_2flineedit_3asnap_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %rv = alloca %"compiler/lineedit:snap"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/lineedit:snap" undef, { i64, ptr } %a0, 0
  %t8 = insertvalue %"compiler/lineedit:snap" %t6, i64 %a1, 1
  store %"compiler/lineedit:snap" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lineedit:snap", ptr %rv
  ret %"compiler/lineedit:snap" %rr
}

@.d0 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"/prompt" }>, align 8
declare void @__olang_check_failed(ptr) cold noreturn
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d1 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"edit vi\0A" }>, align 8
@.d2 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"edit emacs\0A" }>, align 8
@.d3 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"XDG_CONFIG_HOME" }>, align 8
declare void @__olang_errpay_pop()
@.d4 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d5 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d6 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"HOME" }>, align 8
@.d7 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d8 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"/.config/olang/prompt" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d9 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"/olang/prompt" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@.d10 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"XDG_STATE_HOME" }>, align 8
@.d11 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d12 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d13 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"HOME" }>, align 8
@.d14 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d15 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"/.local/state/olang/history" }>, align 8
@.d16 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"/olang/history" }>, align 8
@.d17 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"OLANG_EDIT" }>, align 8
@.d18 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d19 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d20 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"vi" }>, align 8
@.d21 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d22 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d23 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"edit vi" }>, align 8
@.d24 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d25 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2flineedit_3aEditor_2e26 = weak hidden constant i1 false
declare void @__olang_region_release(ptr) noinline
@.d26 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2flineedit_3aEditor_2e25 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2flineedit_3aEditor_2e29 = weak hidden constant i1 false
@.d27 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"\1B[H\1B[2J" }>, align 8
@.d28 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\1B" }>, align 8
@.d29 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2flineedit_3aEditor_2e15 = weak hidden constant i1 false
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
declare ptr @__olang_region_make(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@.d30 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d31 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2flineedit_3aEditor_2e3 = weak hidden constant i1 false
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d32 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"^C\0D\0A" }>, align 8
@.d33 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d34 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2flineedit_3aEditor_2e13 = weak hidden constant i1 false
@.d35 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d36 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d37 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d38 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d39 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\1B" }>, align 8
@.d40 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\5C" }>, align 8
@.d41 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\5C\5C" }>, align 8
@.d42 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d43 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\5Cn" }>, align 8
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
@olang_loc_6d8e321d50b20c8b_e1e5724559d494c7 = external constant [0 x i8]
declare i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %a0)
declare i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2flineedit_3aEditor_2ector(ptr %out, ptr %v0, i1 %a0, i1 %a1, i64 %a2)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eClear(ptr %v0, ptr %a0)
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2edraw(ptr %v0, ptr %a0)
declare void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2eremove(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i1 %a3)
declare void @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2einsert(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_22a9a5775aa8f43a_f3d22121f345f80e = external constant [0 x i8]
declare i32 @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2esequence(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i32 @std_2fio_2eWrite(ptr %v0, i32 %a0, { i64, ptr } %a1)
declare i32 @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2ecommand(ptr %v0, ptr %a0, i8 %a1, i64 %a2)
declare i32 @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2ewholeLine(ptr %v0, ptr %a0, i8 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flineedit_3asnap_3e_2eClear_3ccompiler_2flineedit_3asnap_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flineedit_3asnap_3e_2ePush_3ccompiler_2flineedit_3asnap_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/lineedit:snap" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flineedit_3asnap_3e_2eLen_3ccompiler_2flineedit_3asnap_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flineedit_3asnap_3e_2eRemove_Hd9d3bd958740eb540dbca2377fffdf85(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2flineedit_2ecompiler_2flineedit_3aEditor_2esearchKey(ptr %v0, ptr %a0, i8 %a1)
declare { i32, %"compiler/lineedit:snap" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flineedit_3asnap_3e_2ePop_3ccompiler_2flineedit_3asnap_3e(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_576d906cf1a69575_2b5fe4737c0e1301 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
