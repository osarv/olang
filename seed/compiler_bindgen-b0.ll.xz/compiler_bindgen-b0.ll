; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/bindgen:cx" = type { { i64, ptr }, i64, i64, { i64, ptr } }
%"compiler/bindgen:cparse" = type { { i64, ptr }, { i64, ptr }, i64 }
%"std/os:Output" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/bindgen:gen" = type { { i64, ptr }, i1, i1, { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/text:StringBuilder", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, i64 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/bindgen:cMacro" = type { { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, i1, i1 }
%"compiler/bindgen:ctype" = type { i32, { i64, ptr }, i64, i1, i64, i64 }
%"compiler/bindgen:record" = type { { i64, ptr }, i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, i1, i64, i1, { i64, ptr }, i1, i64, i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/bindgen:cFunc" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, { i64, ptr } }
%"std/json:Object" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"std/prelude/text:LineIter" = type { { i64, ptr }, i64 }
define dso_local { i64, ptr } @compiler_2fbindgen_2eaccessors(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, i64 %a4, i64 %a5) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca %"std/prelude/text:StringBuilder"
  %l8 = alloca %"std/prelude/text:StringBuilder"
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca %"std/prelude/text:StringBuilder"
  %l34 = alloca %"std/prelude/text:StringBuilder"
  %l48 = alloca i64
  %l51 = alloca i64
  %l70 = alloca i64
  %l73 = alloca i64
  %l80 = alloca { i64, ptr }
  %l91 = alloca i64
  %l96 = alloca { i64, ptr }
  %l100 = alloca { i64, ptr }
  %l104 = alloca i64
  %l109 = alloca { i64, ptr }
  %l113 = alloca { i64, ptr }
  %l120 = alloca i64
  %l123 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l130 = alloca i64
  %l132 = alloca { i64, ptr }
  %l134 = alloca { i64, ptr }
  %l135 = alloca { i64, ptr }
  %l139 = alloca { i64, ptr }
  %l148 = alloca ptr
  %l151 = alloca { i64, ptr }
  %l154 = alloca ptr
  %l155 = alloca { i64, ptr }
  %l156 = alloca { i64, ptr }
  %l157 = alloca { i64, ptr }
  %l160 = alloca { i64, ptr }
  %l176 = alloca i64
  %l179 = alloca i64
  %l202 = alloca { i64, ptr }
  %l206 = alloca i64
  %l210 = alloca { i64, ptr }
  %l214 = alloca { i64, ptr }
  %l218 = alloca i64
  %l222 = alloca { i64, ptr }
  %l226 = alloca { i64, ptr }
  %l233 = alloca i64
  %l242 = alloca i64
  %l248 = alloca i1
  %l252 = alloca ptr
  %l253 = alloca { i64, ptr }
  %l256 = alloca { i64, ptr }
  %l259 = alloca { i64, ptr }
  %l263 = alloca i64
  %l267 = alloca { i64, ptr }
  %l271 = alloca { i64, ptr }
  %l275 = alloca i1
  %l279 = alloca i64
  %l282 = alloca { i64, ptr }
  %l286 = alloca { i64, ptr }
  %l291 = alloca i64
  %l293 = alloca { i64, ptr }
  %l297 = alloca { i64, ptr }
  %l298 = alloca { i64, ptr }
  %l302 = alloca { i64, ptr }
  %l306 = alloca { i64, ptr }
  %l307 = alloca { i64, ptr }
  %l308 = alloca { i64, ptr }
  %l312 = alloca { i64, ptr }
  %l314 = alloca ptr
  %l315 = alloca { i64, ptr }
  %l318 = alloca { i64, ptr }
  %l326 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store i64 %a4, ptr %l4
  store i64 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = call i64 @compiler_2fbindgen_2enumBytes(ptr %v2, { i64, ptr } %t1)
  store i64 %t3, ptr %l32
  br label %bb1
bb1:
  %t4 = load i64, ptr %l32, !tbaa !24
  store i64 %t4, ptr %l6, !tbaa !24
  %t5 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t5, ptr %l33
  br label %bb2
bb2:
  %t6 = load %"std/prelude/text:StringBuilder", ptr %l33
  store %"std/prelude/text:StringBuilder" %t6, ptr %l7
  %t7 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t7, ptr %l34
  br label %bb3
bb3:
  %t8 = load %"std/prelude/text:StringBuilder", ptr %l34
  store %"std/prelude/text:StringBuilder" %t8, ptr %l8
  %t9 = load i64, ptr %l5, !tbaa !24
  %t10 = load i64, ptr %l4, !tbaa !24
  %t13 = sdiv i64 %t9, %t10
  store i64 %t13, ptr %l9, !tbaa !24
  %t15 = load i64, ptr %l5, !tbaa !24
  %t16 = load i64, ptr %l6, !tbaa !24
  %t19 = add i64 %t15, %t16
  %t21 = sub i64 %t19, 1
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = sdiv i64 %t21, %t22
  %t27 = add i64 %t25, 1
  store i64 %t27, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t29 = load i64, ptr %l10, !tbaa !24
  %t30 = load i64, ptr %l9, !tbaa !24
  %t33 = icmp sgt i64 %t29, %t30
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = load i64, ptr %l11, !tbaa !24
  %t37 = icmp sgt i64 %t35, 0
  br i1 %t37, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l48, !tbaa !24
  br label %bb9
bb6:
  %t39 = load i64, ptr %l10, !tbaa !24
  %t40 = load i64, ptr %l9, !tbaa !24
  %t43 = sub i64 %t39, %t40
  %t44 = load i64, ptr %l11, !tbaa !24
  %t47 = add i64 %t43, %t44
  %t49 = sub i64 %t47, 1
  %t50 = load i64, ptr %l11, !tbaa !24
  %t53 = sdiv i64 %t49, %t50
  store i64 %t53, ptr %l51, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb8
bb8:
  %t55 = load i64, ptr %l51, !tbaa !24
  store i64 %t55, ptr %l48, !tbaa !24
  br label %bb9
bb9:
  %t56 = load i64, ptr %l48, !tbaa !24
  store i64 %t56, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t57 = load i64, ptr %l13, !tbaa !24
  %t58 = load i64, ptr %l12, !tbaa !24
  %t61 = icmp slt i64 %t57, %t58
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb50
bb12:
  br label %bb13
bb13:
  %t65 = load i64, ptr %l9, !tbaa !24
  %t66 = load i64, ptr %l13, !tbaa !24
  %t67 = load i64, ptr %l11, !tbaa !24
  %t70 = mul i64 %t66, %t67
  %t73 = add i64 %t65, %t70
  store i64 %t73, ptr %l14, !tbaa !24
  %t76 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %s0, ptr %l8)
  store i64 %t76, ptr %l70
  br label %bb14
bb14:
  %t77 = load i64, ptr %l70, !tbaa !24
  %t78 = icmp sgt i64 %t77, 0
  br i1 %t78, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l8, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d0, i32 0, i32 1) })
  br label %bb17
bb16:
  br label %bb18
bb17:
  call void @__olang_scope_close(ptr %s3)
  br label %bb18
bb18:
  %t81 = call ptr @__olang_scope_hold(ptr %s2)
  %t82 = ptrtoint ptr %t81 to i64
  store i64 %t82, ptr %l73, !tbaa !24
  %t83 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2eaccessors_2elocal_2e15
  br i1 %t83, label %bb19, label %bb20
bb19:
  %t85 = call ptr @__olang_region_make(ptr %s2)
  %t86 = ptrtoint ptr %t85 to i64
  store i64 %t86, ptr %l73, !tbaa !24
  br label %bb20
bb20:
  %t87 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t88 = load i64, ptr %l14, !tbaa !24
  %t89 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d1, i32 0, i32 1) }, 1
  %t90 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d1, i32 0, i32 1) }, 0
  %t92 = extractvalue { i64, ptr } %t87, 1
  %t93 = extractvalue { i64, ptr } %t87, 0
  %t94 = add i64 %t90, %t93
  %t95 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t96 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t97 = add i64 %t94, %t96
  %t99 = call i64 @__olang_fmt_i64(ptr null, i64 %t88)
  %t100 = add i64 %t97, %t99
  %t101 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t102 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t103 = add i64 %t100, %t102
  %t104 = load i64, ptr %l73
  %t105 = inttoptr i64 %t104 to ptr
  %t106 = call ptr @__olang_held_alloc(ptr %t105, i64 %t103)
  call void @olang_textcopy(ptr %t106, ptr %t89, i64 %t90)
  %t107 = getelementptr i8, ptr %t106, i64 %t90
  call void @olang_textcopy(ptr %t107, ptr %t92, i64 %t93)
  %t108 = getelementptr i8, ptr %t107, i64 %t93
  call void @olang_textcopy(ptr %t108, ptr %t95, i64 %t96)
  %t109 = getelementptr i8, ptr %t108, i64 %t96
  %t110 = call i64 @__olang_fmt_i64(ptr %t109, i64 %t88)
  %t111 = getelementptr i8, ptr %t109, i64 %t99
  call void @olang_textcopy(ptr %t111, ptr %t101, i64 %t102)
  %t112 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t106, 1
  %t115 = load i64, ptr %l4, !tbaa !24
  %t116 = load i64, ptr %l73
  %t117 = inttoptr i64 %t116 to ptr
  %t118 = load i64, ptr %l73
  %t119 = inttoptr i64 %t118 to ptr
  %t122 = call { i64, ptr } @compiler_2fbindgen_2ewordBits(ptr %t117, ptr %t119, { i64, ptr } %t113, i64 %t115)
  store { i64, ptr } %t122, ptr %l80
  br label %bb21
bb21:
  %t123 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2eaccessors_2elocal_2e15
  br i1 %t123, label %bb22, label %bb23
bb22:
  %t125 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t125, 0
  %t128 = icmp eq i64 %t126, 0
  br i1 %t128, label %bb24, label %bb25
bb23:
  %t130 = load { i64, ptr }, ptr %l80, !tbaa !27
  store { i64, ptr } %t130, ptr %l15, !tbaa !27
  %t131 = load i64, ptr %l14, !tbaa !24
  %t132 = load i64, ptr %l4, !tbaa !24
  %t135 = mul i64 %t131, %t132
  %t136 = load i64, ptr %l5, !tbaa !24
  %t139 = sub i64 %t135, %t136
  store i64 %t139, ptr %l16, !tbaa !24
  %t141 = load i64, ptr %l16, !tbaa !24
  %t143 = icmp sgt i64 %t141, 0
  br i1 %t143, label %bb26, label %bb27
bb24:
  store { i64, ptr } zeroinitializer, ptr %l80, !tbaa !27
  br label %bb25
bb25:
  %t145 = load i64, ptr %l73
  %t146 = inttoptr i64 %t145 to ptr
  %t147 = load { i64, ptr }, ptr %l80
  %t148 = extractvalue { i64, ptr } %t147, 1
  %t149 = call ptr @__olang_region_or(ptr %t148, ptr null)
  %t150 = icmp ne ptr %t149, null
  %t151 = select i1 %t150, ptr %t149, ptr null
  call void @__olang_region_settle_in(ptr %t146, ptr %t151)
  br label %bb23
bb26:
  %t152 = call ptr @__olang_scope_hold(ptr %s2)
  %t153 = ptrtoint ptr %t152 to i64
  store i64 %t153, ptr %l91, !tbaa !24
  %t154 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2eaccessors_2elocal_2e15
  br i1 %t154, label %bb28, label %bb29
bb27:
  br label %bb36
bb28:
  %t156 = call ptr @__olang_region_make(ptr %s2)
  %t157 = ptrtoint ptr %t156 to i64
  store i64 %t157, ptr %l91, !tbaa !24
  br label %bb29
bb29:
  %t158 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t159 = load i64, ptr %l16, !tbaa !24
  %t161 = mul i64 8, %t159
  %t162 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t163 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t165 = extractvalue { i64, ptr } %t158, 1
  %t166 = extractvalue { i64, ptr } %t158, 0
  %t167 = add i64 %t163, %t166
  %t168 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t169 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t170 = add i64 %t167, %t169
  %t172 = call i64 @__olang_fmt_i64(ptr null, i64 %t161)
  %t173 = add i64 %t170, %t172
  %t174 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t175 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t176 = add i64 %t173, %t175
  %t177 = load i64, ptr %l91
  %t178 = inttoptr i64 %t177 to ptr
  %t179 = call ptr @__olang_held_alloc(ptr %t178, i64 %t176)
  call void @olang_textcopy(ptr %t179, ptr %t162, i64 %t163)
  %t180 = getelementptr i8, ptr %t179, i64 %t163
  call void @olang_textcopy(ptr %t180, ptr %t165, i64 %t166)
  %t181 = getelementptr i8, ptr %t180, i64 %t166
  call void @olang_textcopy(ptr %t181, ptr %t168, i64 %t169)
  %t182 = getelementptr i8, ptr %t181, i64 %t169
  %t183 = call i64 @__olang_fmt_i64(ptr %t182, i64 %t161)
  %t184 = getelementptr i8, ptr %t182, i64 %t172
  call void @olang_textcopy(ptr %t184, ptr %t174, i64 %t175)
  %t185 = insertvalue { i64, ptr } undef, i64 %t176, 0
  %t186 = insertvalue { i64, ptr } %t185, ptr %t179, 1
  store { i64, ptr } %t186, ptr %l96, !tbaa !27
  %t187 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2eaccessors_2elocal_2e15
  br i1 %t187, label %bb30, label %bb31
bb30:
  %t189 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t190 = extractvalue { i64, ptr } %t189, 0
  %t192 = icmp eq i64 %t190, 0
  br i1 %t192, label %bb32, label %bb33
bb31:
  %t194 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t194, ptr %l100, !tbaa !27
  %t195 = load { i64, ptr }, ptr %l96, !tbaa !27
  store { i64, ptr } %t195, ptr %l15, !tbaa !27
  %t196 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2eaccessors_2elocal_2e15
  br i1 %t196, label %bb34, label %bb35
bb32:
  store { i64, ptr } zeroinitializer, ptr %l96, !tbaa !27
  br label %bb33
bb33:
  %t198 = load i64, ptr %l91
  %t199 = inttoptr i64 %t198 to ptr
  %t200 = load { i64, ptr }, ptr %l96
  %t201 = extractvalue { i64, ptr } %t200, 1
  %t202 = call ptr @__olang_region_or(ptr %t201, ptr null)
  %t203 = icmp ne ptr %t202, null
  %t204 = select i1 %t203, ptr %t202, ptr null
  call void @__olang_region_settle_in(ptr %t199, ptr %t204)
  br label %bb31
bb34:
  %t205 = load { i64, ptr }, ptr %l100
  %t206 = extractvalue { i64, ptr } %t205, 1
  call void @__olang_region_release(ptr %t206)
  store { i64, ptr } zeroinitializer, ptr %l100
  br label %bb35
bb35:
  br label %bb36
bb36:
  %t207 = load i64, ptr %l16, !tbaa !24
  %t209 = icmp slt i64 %t207, 0
  br i1 %t209, label %bb37, label %bb38
bb37:
  %t211 = call ptr @__olang_scope_hold(ptr %s2)
  %t212 = ptrtoint ptr %t211 to i64
  store i64 %t212, ptr %l104, !tbaa !24
  %t213 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2eaccessors_2elocal_2e15
  br i1 %t213, label %bb39, label %bb40
bb38:
  br label %bb47
bb39:
  %t215 = call ptr @__olang_region_make(ptr %s2)
  %t216 = ptrtoint ptr %t215 to i64
  store i64 %t216, ptr %l104, !tbaa !24
  br label %bb40
bb40:
  %t217 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t218 = load i64, ptr %l16, !tbaa !24
  %t220 = mul i64 -8, %t218
  %t221 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t222 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t224 = extractvalue { i64, ptr } %t217, 1
  %t225 = extractvalue { i64, ptr } %t217, 0
  %t226 = add i64 %t222, %t225
  %t227 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t228 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t229 = add i64 %t226, %t228
  %t231 = call i64 @__olang_fmt_i64(ptr null, i64 %t220)
  %t232 = add i64 %t229, %t231
  %t233 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t234 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t235 = add i64 %t232, %t234
  %t236 = load i64, ptr %l104
  %t237 = inttoptr i64 %t236 to ptr
  %t238 = call ptr @__olang_held_alloc(ptr %t237, i64 %t235)
  call void @olang_textcopy(ptr %t238, ptr %t221, i64 %t222)
  %t239 = getelementptr i8, ptr %t238, i64 %t222
  call void @olang_textcopy(ptr %t239, ptr %t224, i64 %t225)
  %t240 = getelementptr i8, ptr %t239, i64 %t225
  call void @olang_textcopy(ptr %t240, ptr %t227, i64 %t228)
  %t241 = getelementptr i8, ptr %t240, i64 %t228
  %t242 = call i64 @__olang_fmt_i64(ptr %t241, i64 %t220)
  %t243 = getelementptr i8, ptr %t241, i64 %t231
  call void @olang_textcopy(ptr %t243, ptr %t233, i64 %t234)
  %t244 = insertvalue { i64, ptr } undef, i64 %t235, 0
  %t245 = insertvalue { i64, ptr } %t244, ptr %t238, 1
  store { i64, ptr } %t245, ptr %l109, !tbaa !27
  %t246 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2eaccessors_2elocal_2e15
  br i1 %t246, label %bb41, label %bb42
bb41:
  %t248 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t249 = extractvalue { i64, ptr } %t248, 0
  %t251 = icmp eq i64 %t249, 0
  br i1 %t251, label %bb43, label %bb44
bb42:
  %t253 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t253, ptr %l113, !tbaa !27
  %t254 = load { i64, ptr }, ptr %l109, !tbaa !27
  store { i64, ptr } %t254, ptr %l15, !tbaa !27
  %t255 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2eaccessors_2elocal_2e15
  br i1 %t255, label %bb45, label %bb46
bb43:
  store { i64, ptr } zeroinitializer, ptr %l109, !tbaa !27
  br label %bb44
bb44:
  %t257 = load i64, ptr %l104
  %t258 = inttoptr i64 %t257 to ptr
  %t259 = load { i64, ptr }, ptr %l109
  %t260 = extractvalue { i64, ptr } %t259, 1
  %t261 = call ptr @__olang_region_or(ptr %t260, ptr null)
  %t262 = icmp ne ptr %t261, null
  %t263 = select i1 %t262, ptr %t261, ptr null
  call void @__olang_region_settle_in(ptr %t258, ptr %t263)
  br label %bb42
bb45:
  %t264 = load { i64, ptr }, ptr %l113
  %t265 = extractvalue { i64, ptr } %t264, 1
  call void @__olang_region_release(ptr %t265)
  store { i64, ptr } zeroinitializer, ptr %l113
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t266 = load { i64, ptr }, ptr %l15, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %l8, { i64, ptr } %t266)
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s2)
  br label %bb49
bb49:
  %t269 = load i64, ptr %l13, !tbaa !24
  %t272 = add i64 %t269, 1
  store i64 %t272, ptr %l13, !tbaa !24
  br label %bb10
bb50:
  %t274 = call ptr @__olang_scope_hold(ptr %s0)
  %t275 = ptrtoint ptr %t274 to i64
  store i64 %t275, ptr %l120, !tbaa !24
  %t276 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2eaccessors_2elocal_2e17
  br i1 %t276, label %bb51, label %bb52
bb51:
  %t278 = call ptr @__olang_region_make(ptr %s0)
  %t279 = ptrtoint ptr %t278 to i64
  store i64 %t279, ptr %l120, !tbaa !24
  br label %bb52
bb52:
  %t281 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l8)
  store { i64, ptr } %t281, ptr %l123
  br label %bb53
bb53:
  %t282 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t283 = extractvalue { i64, ptr } %t282, 1
  %t284 = extractvalue { i64, ptr } %t282, 0
  %t285 = load i64, ptr %l120
  %t286 = inttoptr i64 %t285 to ptr
  %t287 = call ptr @__olang_held_alloc(ptr %t286, i64 %t284)
  call void @olang_textcopy(ptr %t287, ptr %t283, i64 %t284)
  %t288 = insertvalue { i64, ptr } undef, i64 %t284, 0
  %t289 = insertvalue { i64, ptr } %t288, ptr %t287, 1
  store { i64, ptr } %t289, ptr %l124, !tbaa !27
  %t290 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2eaccessors_2elocal_2e17
  br i1 %t290, label %bb54, label %bb55
bb54:
  %t292 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t293 = extractvalue { i64, ptr } %t292, 0
  %t295 = icmp eq i64 %t293, 0
  br i1 %t295, label %bb56, label %bb57
bb55:
  %t297 = load { i64, ptr }, ptr %l124, !tbaa !27
  store { i64, ptr } %t297, ptr %l17, !tbaa !27
  %t298 = load i64, ptr %l6, !tbaa !24
  %t300 = icmp slt i64 %t298, 8
  br i1 %t300, label %bb58, label %bb59
bb56:
  store { i64, ptr } zeroinitializer, ptr %l124, !tbaa !27
  br label %bb57
bb57:
  %t302 = load i64, ptr %l120
  %t303 = inttoptr i64 %t302 to ptr
  %t304 = load { i64, ptr }, ptr %l124
  %t305 = extractvalue { i64, ptr } %t304, 1
  %t306 = call ptr @__olang_region_or(ptr %t305, ptr null)
  %t307 = icmp ne ptr %t306, null
  %t308 = select i1 %t307, ptr %t306, ptr null
  call void @__olang_region_settle_in(ptr %t303, ptr %t308)
  br label %bb55
bb58:
  store %olang.scope zeroinitializer, ptr %s11
  %t309 = call ptr @__olang_scope_hold(ptr %s0)
  %t310 = ptrtoint ptr %t309 to i64
  store i64 %t310, ptr %l130, !tbaa !24
  %t311 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2eaccessors_2elocal_2e17
  br i1 %t311, label %bb60, label %bb61
bb59:
  br label %bb69
bb60:
  %t313 = call ptr @__olang_region_make(ptr %s0)
  %t314 = ptrtoint ptr %t313 to i64
  store i64 %t314, ptr %l130, !tbaa !24
  br label %bb61
bb61:
  %t315 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t315, ptr %l132, !tbaa !27
  %t316 = load i64, ptr %l6, !tbaa !24
  %t318 = call { i64, ptr } @compiler_2fbindgen_2ebyteMask(ptr %s11, i64 0, i64 %t316, i64 8)
  store { i64, ptr } %t318, ptr %l134
  br label %bb62
bb62:
  %t319 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t320 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t321 = load { i64, ptr }, ptr %l132, !tbaa !27
  %t322 = extractvalue { i64, ptr } %t321, 1
  %t323 = extractvalue { i64, ptr } %t321, 0
  %t324 = add i64 %t320, %t323
  %t325 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t326 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t327 = add i64 %t324, %t326
  %t328 = load { i64, ptr }, ptr %l134, !tbaa !27
  %t329 = extractvalue { i64, ptr } %t328, 1
  %t330 = extractvalue { i64, ptr } %t328, 0
  %t331 = add i64 %t327, %t330
  %t332 = load i64, ptr %l130
  %t333 = inttoptr i64 %t332 to ptr
  %t334 = call ptr @__olang_held_alloc(ptr %t333, i64 %t331)
  call void @olang_textcopy(ptr %t334, ptr %t319, i64 %t320)
  %t335 = getelementptr i8, ptr %t334, i64 %t320
  call void @olang_textcopy(ptr %t335, ptr %t322, i64 %t323)
  %t336 = getelementptr i8, ptr %t335, i64 %t323
  call void @olang_textcopy(ptr %t336, ptr %t325, i64 %t326)
  %t337 = getelementptr i8, ptr %t336, i64 %t326
  call void @olang_textcopy(ptr %t337, ptr %t329, i64 %t330)
  %t338 = insertvalue { i64, ptr } undef, i64 %t331, 0
  %t339 = insertvalue { i64, ptr } %t338, ptr %t334, 1
  store { i64, ptr } %t339, ptr %l135, !tbaa !27
  %t340 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2eaccessors_2elocal_2e17
  br i1 %t340, label %bb63, label %bb64
bb63:
  %t342 = load { i64, ptr }, ptr %l135, !tbaa !27
  %t343 = extractvalue { i64, ptr } %t342, 0
  %t345 = icmp eq i64 %t343, 0
  br i1 %t345, label %bb65, label %bb66
bb64:
  %t347 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t347, ptr %l139, !tbaa !27
  %t348 = load { i64, ptr }, ptr %l135, !tbaa !27
  store { i64, ptr } %t348, ptr %l17, !tbaa !27
  %t349 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2eaccessors_2elocal_2e17
  br i1 %t349, label %bb67, label %bb68
bb65:
  store { i64, ptr } zeroinitializer, ptr %l135, !tbaa !27
  br label %bb66
bb66:
  %t351 = load i64, ptr %l130
  %t352 = inttoptr i64 %t351 to ptr
  %t353 = load { i64, ptr }, ptr %l135
  %t354 = extractvalue { i64, ptr } %t353, 1
  %t355 = call ptr @__olang_region_or(ptr %t354, ptr null)
  %t356 = icmp ne ptr %t355, null
  %t357 = select i1 %t356, ptr %t355, ptr null
  call void @__olang_region_settle_in(ptr %t352, ptr %t357)
  br label %bb64
bb67:
  %t358 = load { i64, ptr }, ptr %l139
  %t359 = extractvalue { i64, ptr } %t358, 1
  call void @__olang_region_release(ptr %t359)
  store { i64, ptr } zeroinitializer, ptr %l139
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s11)
  br label %bb69
bb69:
  %t360 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t361 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t362 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t363 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t364 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t365 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  %t367 = extractvalue { i64, ptr } %t360, 1
  %t368 = extractvalue { i64, ptr } %t360, 0
  %t369 = add i64 %t365, %t368
  %t370 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t371 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t372 = add i64 %t369, %t371
  %t374 = extractvalue { i64, ptr } %t361, 1
  %t375 = extractvalue { i64, ptr } %t361, 0
  %t376 = add i64 %t372, %t375
  %t377 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t378 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t379 = add i64 %t376, %t378
  %t381 = extractvalue { i64, ptr } %t362, 1
  %t382 = extractvalue { i64, ptr } %t362, 0
  %t383 = add i64 %t379, %t382
  %t384 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t385 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  %t386 = add i64 %t383, %t385
  %t388 = extractvalue { i64, ptr } %t363, 1
  %t389 = extractvalue { i64, ptr } %t363, 0
  %t390 = add i64 %t386, %t389
  %t391 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t392 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t393 = add i64 %t390, %t392
  %t394 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t393)
  call void @olang_textcopy(ptr %t394, ptr %t364, i64 %t365)
  %t395 = getelementptr i8, ptr %t394, i64 %t365
  call void @olang_textcopy(ptr %t395, ptr %t367, i64 %t368)
  %t396 = getelementptr i8, ptr %t395, i64 %t368
  call void @olang_textcopy(ptr %t396, ptr %t370, i64 %t371)
  %t397 = getelementptr i8, ptr %t396, i64 %t371
  call void @olang_textcopy(ptr %t397, ptr %t374, i64 %t375)
  %t398 = getelementptr i8, ptr %t397, i64 %t375
  call void @olang_textcopy(ptr %t398, ptr %t377, i64 %t378)
  %t399 = getelementptr i8, ptr %t398, i64 %t378
  call void @olang_textcopy(ptr %t399, ptr %t381, i64 %t382)
  %t400 = getelementptr i8, ptr %t399, i64 %t382
  call void @olang_textcopy(ptr %t400, ptr %t384, i64 %t385)
  %t401 = getelementptr i8, ptr %t400, i64 %t385
  call void @olang_textcopy(ptr %t401, ptr %t388, i64 %t389)
  %t402 = getelementptr i8, ptr %t401, i64 %t389
  call void @olang_textcopy(ptr %t402, ptr %t391, i64 %t392)
  %t403 = insertvalue { i64, ptr } undef, i64 %t393, 0
  %t404 = insertvalue { i64, ptr } %t403, ptr %t394, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l7, { i64, ptr } %t404)
  br label %bb70
bb70:
  store ptr %l7, ptr %l148, !tbaa !29
  %t408 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t409 = load i64, ptr %l6, !tbaa !24
  %t412 = call { i64, ptr } @compiler_2fbindgen_2efromBits(ptr %v2, ptr %s0, { i64, ptr } %t408, i64 %t409)
  store { i64, ptr } %t412, ptr %l151
  br label %bb71
bb71:
  %t413 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t414 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  %t415 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t416 = extractvalue { i64, ptr } %t415, 1
  %t417 = extractvalue { i64, ptr } %t415, 0
  %t418 = add i64 %t414, %t417
  %t419 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t420 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t421 = add i64 %t418, %t420
  %t422 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t421)
  call void @olang_textcopy(ptr %t422, ptr %t413, i64 %t414)
  %t423 = getelementptr i8, ptr %t422, i64 %t414
  call void @olang_textcopy(ptr %t423, ptr %t416, i64 %t417)
  %t424 = getelementptr i8, ptr %t423, i64 %t417
  call void @olang_textcopy(ptr %t424, ptr %t419, i64 %t420)
  %t425 = insertvalue { i64, ptr } undef, i64 %t421, 0
  %t426 = insertvalue { i64, ptr } %t425, ptr %t422, 1
  %t428 = load ptr, ptr %l148, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t428, { i64, ptr } %t426)
  br label %bb72
bb72:
  store ptr %l7, ptr %l154, !tbaa !29
  %t430 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t430, ptr %l155, !tbaa !27
  %t431 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t431, ptr %l156, !tbaa !27
  %t432 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t432, ptr %l157, !tbaa !27
  %t433 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t434 = load i64, ptr %l6, !tbaa !24
  %t437 = call { i64, ptr } @compiler_2fbindgen_2etoBits(ptr %v2, ptr %s0, { i64, ptr } %t433, i64 %t434)
  store { i64, ptr } %t437, ptr %l160
  br label %bb73
bb73:
  %t438 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t439 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t440 = load { i64, ptr }, ptr %l155, !tbaa !27
  %t441 = extractvalue { i64, ptr } %t440, 1
  %t442 = extractvalue { i64, ptr } %t440, 0
  %t443 = add i64 %t439, %t442
  %t444 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t445 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t446 = add i64 %t443, %t445
  %t447 = load { i64, ptr }, ptr %l156, !tbaa !27
  %t448 = extractvalue { i64, ptr } %t447, 1
  %t449 = extractvalue { i64, ptr } %t447, 0
  %t450 = add i64 %t446, %t449
  %t451 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t452 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  %t453 = add i64 %t450, %t452
  %t454 = load { i64, ptr }, ptr %l157, !tbaa !27
  %t455 = extractvalue { i64, ptr } %t454, 1
  %t456 = extractvalue { i64, ptr } %t454, 0
  %t457 = add i64 %t453, %t456
  %t458 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t459 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t460 = add i64 %t457, %t459
  %t461 = load { i64, ptr }, ptr %l160, !tbaa !27
  %t462 = extractvalue { i64, ptr } %t461, 1
  %t463 = extractvalue { i64, ptr } %t461, 0
  %t464 = add i64 %t460, %t463
  %t465 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d23, i32 0, i32 1) }, 1
  %t466 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d23, i32 0, i32 1) }, 0
  %t467 = add i64 %t464, %t466
  %t468 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t467)
  call void @olang_textcopy(ptr %t468, ptr %t438, i64 %t439)
  %t469 = getelementptr i8, ptr %t468, i64 %t439
  call void @olang_textcopy(ptr %t469, ptr %t441, i64 %t442)
  %t470 = getelementptr i8, ptr %t469, i64 %t442
  call void @olang_textcopy(ptr %t470, ptr %t444, i64 %t445)
  %t471 = getelementptr i8, ptr %t470, i64 %t445
  call void @olang_textcopy(ptr %t471, ptr %t448, i64 %t449)
  %t472 = getelementptr i8, ptr %t471, i64 %t449
  call void @olang_textcopy(ptr %t472, ptr %t451, i64 %t452)
  %t473 = getelementptr i8, ptr %t472, i64 %t452
  call void @olang_textcopy(ptr %t473, ptr %t455, i64 %t456)
  %t474 = getelementptr i8, ptr %t473, i64 %t456
  call void @olang_textcopy(ptr %t474, ptr %t458, i64 %t459)
  %t475 = getelementptr i8, ptr %t474, i64 %t459
  call void @olang_textcopy(ptr %t475, ptr %t462, i64 %t463)
  %t476 = getelementptr i8, ptr %t475, i64 %t463
  call void @olang_textcopy(ptr %t476, ptr %t465, i64 %t466)
  %t477 = insertvalue { i64, ptr } undef, i64 %t467, 0
  %t478 = insertvalue { i64, ptr } %t477, ptr %t468, 1
  %t480 = load ptr, ptr %l154, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t480, { i64, ptr } %t478)
  br label %bb74
bb74:
  %t482 = load i64, ptr %l5, !tbaa !24
  %t483 = load i64, ptr %l4, !tbaa !24
  %t486 = sdiv i64 %t482, %t483
  store i64 %t486, ptr %l18, !tbaa !24
  %t488 = load i64, ptr %l5, !tbaa !24
  %t489 = load i64, ptr %l6, !tbaa !24
  %t492 = add i64 %t488, %t489
  %t494 = sub i64 %t492, 1
  %t495 = load i64, ptr %l4, !tbaa !24
  %t498 = sdiv i64 %t494, %t495
  %t500 = add i64 %t498, 1
  store i64 %t500, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t502 = load i64, ptr %l19, !tbaa !24
  %t503 = load i64, ptr %l18, !tbaa !24
  %t506 = icmp sgt i64 %t502, %t503
  br i1 %t506, label %bb75, label %bb76
bb75:
  %t508 = load i64, ptr %l20, !tbaa !24
  %t510 = icmp sgt i64 %t508, 0
  br i1 %t510, label %bb77, label %bb78
bb76:
  store i64 0, ptr %l176, !tbaa !24
  br label %bb80
bb77:
  %t512 = load i64, ptr %l19, !tbaa !24
  %t513 = load i64, ptr %l18, !tbaa !24
  %t516 = sub i64 %t512, %t513
  %t517 = load i64, ptr %l20, !tbaa !24
  %t520 = add i64 %t516, %t517
  %t522 = sub i64 %t520, 1
  %t523 = load i64, ptr %l20, !tbaa !24
  %t526 = sdiv i64 %t522, %t523
  store i64 %t526, ptr %l179, !tbaa !24
  br label %bb79
bb78:
  store i64 0, ptr %l179, !tbaa !24
  br label %bb79
bb79:
  %t528 = load i64, ptr %l179, !tbaa !24
  store i64 %t528, ptr %l176, !tbaa !24
  br label %bb80
bb80:
  %t529 = load i64, ptr %l176, !tbaa !24
  store i64 %t529, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb81
bb81:
  store %olang.scope zeroinitializer, ptr %s17
  %t530 = load i64, ptr %l22, !tbaa !24
  %t531 = load i64, ptr %l21, !tbaa !24
  %t534 = icmp slt i64 %t530, %t531
  %t536 = xor i1 %t534, true
  br i1 %t536, label %bb82, label %bb83
bb82:
  call void @__olang_scope_close(ptr %s17)
  br label %bb160
bb83:
  br label %bb84
bb84:
  %t538 = load i64, ptr %l18, !tbaa !24
  %t539 = load i64, ptr %l22, !tbaa !24
  %t540 = load i64, ptr %l20, !tbaa !24
  %t543 = mul i64 %t539, %t540
  %t546 = add i64 %t538, %t543
  store i64 %t546, ptr %l23, !tbaa !24
  %t548 = load i64, ptr %l23, !tbaa !24
  %t549 = load i64, ptr %l4, !tbaa !24
  %t552 = mul i64 %t548, %t549
  %t553 = load i64, ptr %l5, !tbaa !24
  %t556 = sub i64 %t552, %t553
  store i64 %t556, ptr %l24, !tbaa !24
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d24, i32 0, i32 1) }, ptr %l202, !tbaa !27
  %t558 = load { i64, ptr }, ptr %l202, !tbaa !27
  store { i64, ptr } %t558, ptr %l25, !tbaa !27
  %t560 = load i64, ptr %l24, !tbaa !24
  %t562 = icmp sgt i64 %t560, 0
  br i1 %t562, label %bb85, label %bb86
bb85:
  %t564 = call ptr @__olang_scope_hold(ptr %s17)
  %t565 = ptrtoint ptr %t564 to i64
  store i64 %t565, ptr %l206, !tbaa !24
  %t566 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2eaccessors_2elocal_2e25
  br i1 %t566, label %bb87, label %bb88
bb86:
  br label %bb95
bb87:
  %t568 = call ptr @__olang_region_make(ptr %s17)
  %t569 = ptrtoint ptr %t568 to i64
  store i64 %t569, ptr %l206, !tbaa !24
  br label %bb88
bb88:
  %t570 = load i64, ptr %l24, !tbaa !24
  %t572 = mul i64 8, %t570
  %t573 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t574 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t576 = call i64 @__olang_fmt_i64(ptr null, i64 %t572)
  %t577 = add i64 %t574, %t576
  %t578 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t579 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  %t580 = add i64 %t577, %t579
  %t581 = load i64, ptr %l206
  %t582 = inttoptr i64 %t581 to ptr
  %t583 = call ptr @__olang_held_alloc(ptr %t582, i64 %t580)
  call void @olang_textcopy(ptr %t583, ptr %t573, i64 %t574)
  %t584 = getelementptr i8, ptr %t583, i64 %t574
  %t585 = call i64 @__olang_fmt_i64(ptr %t584, i64 %t572)
  %t586 = getelementptr i8, ptr %t584, i64 %t576
  call void @olang_textcopy(ptr %t586, ptr %t578, i64 %t579)
  %t587 = insertvalue { i64, ptr } undef, i64 %t580, 0
  %t588 = insertvalue { i64, ptr } %t587, ptr %t583, 1
  store { i64, ptr } %t588, ptr %l210, !tbaa !27
  %t589 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2eaccessors_2elocal_2e25
  br i1 %t589, label %bb89, label %bb90
bb89:
  %t591 = load { i64, ptr }, ptr %l210, !tbaa !27
  %t592 = extractvalue { i64, ptr } %t591, 0
  %t594 = icmp eq i64 %t592, 0
  br i1 %t594, label %bb91, label %bb92
bb90:
  %t596 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t596, ptr %l214, !tbaa !27
  %t597 = load { i64, ptr }, ptr %l210, !tbaa !27
  store { i64, ptr } %t597, ptr %l25, !tbaa !27
  %t598 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2eaccessors_2elocal_2e25
  br i1 %t598, label %bb93, label %bb94
bb91:
  store { i64, ptr } zeroinitializer, ptr %l210, !tbaa !27
  br label %bb92
bb92:
  %t600 = load i64, ptr %l206
  %t601 = inttoptr i64 %t600 to ptr
  %t602 = load { i64, ptr }, ptr %l210
  %t603 = extractvalue { i64, ptr } %t602, 1
  %t604 = call ptr @__olang_region_or(ptr %t603, ptr null)
  %t605 = icmp ne ptr %t604, null
  %t606 = select i1 %t605, ptr %t604, ptr null
  call void @__olang_region_settle_in(ptr %t601, ptr %t606)
  br label %bb90
bb93:
  %t607 = load { i64, ptr }, ptr %l214
  %t608 = extractvalue { i64, ptr } %t607, 1
  call void @__olang_region_release(ptr %t608)
  store { i64, ptr } zeroinitializer, ptr %l214
  br label %bb94
bb94:
  br label %bb95
bb95:
  %t609 = load i64, ptr %l24, !tbaa !24
  %t611 = icmp slt i64 %t609, 0
  br i1 %t611, label %bb96, label %bb97
bb96:
  %t613 = call ptr @__olang_scope_hold(ptr %s17)
  %t614 = ptrtoint ptr %t613 to i64
  store i64 %t614, ptr %l218, !tbaa !24
  %t615 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2eaccessors_2elocal_2e25
  br i1 %t615, label %bb98, label %bb99
bb97:
  br label %bb106
bb98:
  %t617 = call ptr @__olang_region_make(ptr %s17)
  %t618 = ptrtoint ptr %t617 to i64
  store i64 %t618, ptr %l218, !tbaa !24
  br label %bb99
bb99:
  %t619 = load i64, ptr %l24, !tbaa !24
  %t621 = mul i64 -8, %t619
  %t622 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t623 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  %t625 = call i64 @__olang_fmt_i64(ptr null, i64 %t621)
  %t626 = add i64 %t623, %t625
  %t627 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t628 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  %t629 = add i64 %t626, %t628
  %t630 = load i64, ptr %l218
  %t631 = inttoptr i64 %t630 to ptr
  %t632 = call ptr @__olang_held_alloc(ptr %t631, i64 %t629)
  call void @olang_textcopy(ptr %t632, ptr %t622, i64 %t623)
  %t633 = getelementptr i8, ptr %t632, i64 %t623
  %t634 = call i64 @__olang_fmt_i64(ptr %t633, i64 %t621)
  %t635 = getelementptr i8, ptr %t633, i64 %t625
  call void @olang_textcopy(ptr %t635, ptr %t627, i64 %t628)
  %t636 = insertvalue { i64, ptr } undef, i64 %t629, 0
  %t637 = insertvalue { i64, ptr } %t636, ptr %t632, 1
  store { i64, ptr } %t637, ptr %l222, !tbaa !27
  %t638 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2eaccessors_2elocal_2e25
  br i1 %t638, label %bb100, label %bb101
bb100:
  %t640 = load { i64, ptr }, ptr %l222, !tbaa !27
  %t641 = extractvalue { i64, ptr } %t640, 0
  %t643 = icmp eq i64 %t641, 0
  br i1 %t643, label %bb102, label %bb103
bb101:
  %t645 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t645, ptr %l226, !tbaa !27
  %t646 = load { i64, ptr }, ptr %l222, !tbaa !27
  store { i64, ptr } %t646, ptr %l25, !tbaa !27
  %t647 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2eaccessors_2elocal_2e25
  br i1 %t647, label %bb104, label %bb105
bb102:
  store { i64, ptr } zeroinitializer, ptr %l222, !tbaa !27
  br label %bb103
bb103:
  %t649 = load i64, ptr %l218
  %t650 = inttoptr i64 %t649 to ptr
  %t651 = load { i64, ptr }, ptr %l222
  %t652 = extractvalue { i64, ptr } %t651, 1
  %t653 = call ptr @__olang_region_or(ptr %t652, ptr null)
  %t654 = icmp ne ptr %t653, null
  %t655 = select i1 %t654, ptr %t653, ptr null
  call void @__olang_region_settle_in(ptr %t650, ptr %t655)
  br label %bb101
bb104:
  %t656 = load { i64, ptr }, ptr %l226
  %t657 = extractvalue { i64, ptr } %t656, 1
  call void @__olang_region_release(ptr %t657)
  store { i64, ptr } zeroinitializer, ptr %l226
  br label %bb105
bb105:
  br label %bb106
bb106:
  %t658 = load i64, ptr %l5, !tbaa !24
  %t659 = load i64, ptr %l23, !tbaa !24
  %t660 = load i64, ptr %l4, !tbaa !24
  %t663 = mul i64 %t659, %t660
  %t666 = sub i64 %t658, %t663
  %t668 = call i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %t666, i64 0)
  store i64 %t668, ptr %l233
  br label %bb107
bb107:
  %t669 = load i64, ptr %l233, !tbaa !24
  store i64 %t669, ptr %l26, !tbaa !24
  %t670 = load i64, ptr %l5, !tbaa !24
  %t671 = load i64, ptr %l6, !tbaa !24
  %t674 = add i64 %t670, %t671
  %t675 = load i64, ptr %l23, !tbaa !24
  %t676 = load i64, ptr %l4, !tbaa !24
  %t679 = mul i64 %t675, %t676
  %t682 = sub i64 %t674, %t679
  %t683 = load i64, ptr %l4, !tbaa !24
  %t686 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t682, i64 %t683)
  store i64 %t686, ptr %l242
  br label %bb108
bb108:
  %t687 = load i64, ptr %l242, !tbaa !24
  store i64 %t687, ptr %l27, !tbaa !24
  %t688 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t689 = load i64, ptr %l23, !tbaa !24
  %t690 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t691 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  %t693 = extractvalue { i64, ptr } %t688, 1
  %t694 = extractvalue { i64, ptr } %t688, 0
  %t695 = add i64 %t691, %t694
  %t696 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d30, i32 0, i32 1) }, 1
  %t697 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d30, i32 0, i32 1) }, 0
  %t698 = add i64 %t695, %t697
  %t700 = call i64 @__olang_fmt_i64(ptr null, i64 %t689)
  %t701 = add i64 %t698, %t700
  %t702 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t703 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  %t704 = add i64 %t701, %t703
  %t705 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t704)
  call void @olang_textcopy(ptr %t705, ptr %t690, i64 %t691)
  %t706 = getelementptr i8, ptr %t705, i64 %t691
  call void @olang_textcopy(ptr %t706, ptr %t693, i64 %t694)
  %t707 = getelementptr i8, ptr %t706, i64 %t694
  call void @olang_textcopy(ptr %t707, ptr %t696, i64 %t697)
  %t708 = getelementptr i8, ptr %t707, i64 %t697
  %t709 = call i64 @__olang_fmt_i64(ptr %t708, i64 %t689)
  %t710 = getelementptr i8, ptr %t708, i64 %t700
  call void @olang_textcopy(ptr %t710, ptr %t702, i64 %t703)
  %t711 = insertvalue { i64, ptr } undef, i64 %t704, 0
  %t712 = insertvalue { i64, ptr } %t711, ptr %t705, 1
  store { i64, ptr } %t712, ptr %l28, !tbaa !27
  %t714 = load i64, ptr %l26, !tbaa !24
  %t716 = icmp eq i64 %t714, 0
  br i1 %t716, label %bb109, label %bb110
bb109:
  %t718 = load i64, ptr %l27, !tbaa !24
  %t719 = load i64, ptr %l4, !tbaa !24
  %t722 = icmp eq i64 %t718, %t719
  store i1 %t722, ptr %l248, !tbaa !21
  br label %bb111
bb110:
  store i1 false, ptr %l248, !tbaa !21
  br label %bb111
bb111:
  %t724 = load i1, ptr %l248, !tbaa !21
  br i1 %t724, label %bb112, label %bb113
bb112:
  store %olang.scope zeroinitializer, ptr %s23
  store ptr %l7, ptr %l252, !tbaa !29
  %t725 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t725, ptr %l253, !tbaa !27
  %t726 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t727 = load i64, ptr %l4, !tbaa !24
  %t730 = call { i64, ptr } @compiler_2fbindgen_2ewordOf(ptr %s17, ptr %s23, { i64, ptr } %t726, i64 %t727)
  store { i64, ptr } %t730, ptr %l256
  br label %bb114
bb113:
  br label %bb116
bb114:
  %t731 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t732 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  %t733 = load { i64, ptr }, ptr %l253, !tbaa !27
  %t734 = extractvalue { i64, ptr } %t733, 1
  %t735 = extractvalue { i64, ptr } %t733, 0
  %t736 = add i64 %t732, %t735
  %t737 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d33, i32 0, i32 1) }, 1
  %t738 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d33, i32 0, i32 1) }, 0
  %t739 = add i64 %t736, %t738
  %t740 = load { i64, ptr }, ptr %l256, !tbaa !27
  %t741 = extractvalue { i64, ptr } %t740, 1
  %t742 = extractvalue { i64, ptr } %t740, 0
  %t743 = add i64 %t739, %t742
  %t744 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  %t745 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d34, i32 0, i32 1) }, 0
  %t746 = add i64 %t743, %t745
  %t747 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t746)
  call void @olang_textcopy(ptr %t747, ptr %t731, i64 %t732)
  %t748 = getelementptr i8, ptr %t747, i64 %t732
  call void @olang_textcopy(ptr %t748, ptr %t734, i64 %t735)
  %t749 = getelementptr i8, ptr %t748, i64 %t735
  call void @olang_textcopy(ptr %t749, ptr %t737, i64 %t738)
  %t750 = getelementptr i8, ptr %t749, i64 %t738
  call void @olang_textcopy(ptr %t750, ptr %t741, i64 %t742)
  %t751 = getelementptr i8, ptr %t750, i64 %t742
  call void @olang_textcopy(ptr %t751, ptr %t744, i64 %t745)
  %t752 = insertvalue { i64, ptr } undef, i64 %t746, 0
  %t753 = insertvalue { i64, ptr } %t752, ptr %t747, 1
  %t755 = load ptr, ptr %l252, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s23, ptr %t755, { i64, ptr } %t753)
  br label %bb115
bb115:
  call void @__olang_scope_close(ptr %s23)
  call void @__olang_scope_close(ptr %s17)
  br label %bb159
bb116:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d35, i32 0, i32 1) }, ptr %l259, !tbaa !27
  %t757 = load { i64, ptr }, ptr %l259, !tbaa !27
  store { i64, ptr } %t757, ptr %l29, !tbaa !27
  %t759 = load i64, ptr %l26, !tbaa !24
  %t761 = icmp sgt i64 %t759, 0
  br i1 %t761, label %bb117, label %bb118
bb117:
  %t763 = call ptr @__olang_scope_hold(ptr %s17)
  %t764 = ptrtoint ptr %t763 to i64
  store i64 %t764, ptr %l263, !tbaa !24
  %t765 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2eaccessors_2elocal_2e29
  br i1 %t765, label %bb119, label %bb120
bb118:
  br label %bb128
bb119:
  %t767 = call ptr @__olang_region_make(ptr %s17)
  %t768 = ptrtoint ptr %t767 to i64
  store i64 %t768, ptr %l263, !tbaa !24
  br label %bb120
bb120:
  %t769 = load i64, ptr %l26, !tbaa !24
  %t770 = load i64, ptr %l4, !tbaa !24
  %t771 = load i64, ptr %l263
  %t772 = inttoptr i64 %t771 to ptr
  %t775 = call { i64, ptr } @compiler_2fbindgen_2ebyteMask(ptr %t772, i64 0, i64 %t769, i64 %t770)
  store { i64, ptr } %t775, ptr %l267
  br label %bb121
bb121:
  %t776 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2eaccessors_2elocal_2e29
  br i1 %t776, label %bb122, label %bb123
bb122:
  %t778 = load { i64, ptr }, ptr %l267, !tbaa !27
  %t779 = extractvalue { i64, ptr } %t778, 0
  %t781 = icmp eq i64 %t779, 0
  br i1 %t781, label %bb124, label %bb125
bb123:
  %t783 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t783, ptr %l271, !tbaa !27
  %t784 = load { i64, ptr }, ptr %l267, !tbaa !27
  store { i64, ptr } %t784, ptr %l29, !tbaa !27
  %t785 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2eaccessors_2elocal_2e29
  br i1 %t785, label %bb126, label %bb127
bb124:
  store { i64, ptr } zeroinitializer, ptr %l267, !tbaa !27
  br label %bb125
bb125:
  %t787 = load i64, ptr %l263
  %t788 = inttoptr i64 %t787 to ptr
  %t789 = load { i64, ptr }, ptr %l267
  %t790 = extractvalue { i64, ptr } %t789, 1
  %t791 = call ptr @__olang_region_or(ptr %t790, ptr null)
  %t792 = icmp ne ptr %t791, null
  %t793 = select i1 %t792, ptr %t791, ptr null
  call void @__olang_region_settle_in(ptr %t788, ptr %t793)
  br label %bb123
bb126:
  %t794 = load { i64, ptr }, ptr %l271
  %t795 = extractvalue { i64, ptr } %t794, 1
  call void @__olang_region_release(ptr %t795)
  store { i64, ptr } zeroinitializer, ptr %l271
  br label %bb127
bb127:
  br label %bb128
bb128:
  %t796 = load i64, ptr %l26, !tbaa !24
  %t798 = icmp sgt i64 %t796, 0
  br i1 %t798, label %bb129, label %bb130
bb129:
  %t800 = load i64, ptr %l27, !tbaa !24
  %t801 = load i64, ptr %l4, !tbaa !24
  %t804 = icmp slt i64 %t800, %t801
  store i1 %t804, ptr %l275, !tbaa !21
  br label %bb131
bb130:
  store i1 false, ptr %l275, !tbaa !21
  br label %bb131
bb131:
  %t806 = load i1, ptr %l275, !tbaa !21
  br i1 %t806, label %bb132, label %bb133
bb132:
  %t807 = call ptr @__olang_scope_hold(ptr %s17)
  %t808 = ptrtoint ptr %t807 to i64
  store i64 %t808, ptr %l279, !tbaa !24
  %t809 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2eaccessors_2elocal_2e29
  br i1 %t809, label %bb134, label %bb135
bb133:
  br label %bb142
bb134:
  %t811 = call ptr @__olang_region_make(ptr %s17)
  %t812 = ptrtoint ptr %t811 to i64
  store i64 %t812, ptr %l279, !tbaa !24
  br label %bb135
bb135:
  %t813 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t815 = extractvalue { i64, ptr } %t813, 1
  %t816 = extractvalue { i64, ptr } %t813, 0
  %t817 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t818 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  %t819 = add i64 %t816, %t818
  %t820 = load i64, ptr %l279
  %t821 = inttoptr i64 %t820 to ptr
  %t822 = call ptr @__olang_held_alloc(ptr %t821, i64 %t819)
  call void @olang_textcopy(ptr %t822, ptr %t815, i64 %t816)
  %t823 = getelementptr i8, ptr %t822, i64 %t816
  call void @olang_textcopy(ptr %t823, ptr %t817, i64 %t818)
  %t824 = insertvalue { i64, ptr } undef, i64 %t819, 0
  %t825 = insertvalue { i64, ptr } %t824, ptr %t822, 1
  store { i64, ptr } %t825, ptr %l282, !tbaa !27
  %t826 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2eaccessors_2elocal_2e29
  br i1 %t826, label %bb136, label %bb137
bb136:
  %t828 = load { i64, ptr }, ptr %l282, !tbaa !27
  %t829 = extractvalue { i64, ptr } %t828, 0
  %t831 = icmp eq i64 %t829, 0
  br i1 %t831, label %bb138, label %bb139
bb137:
  %t833 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t833, ptr %l286, !tbaa !27
  %t834 = load { i64, ptr }, ptr %l282, !tbaa !27
  store { i64, ptr } %t834, ptr %l29, !tbaa !27
  %t835 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2eaccessors_2elocal_2e29
  br i1 %t835, label %bb140, label %bb141
bb138:
  store { i64, ptr } zeroinitializer, ptr %l282, !tbaa !27
  br label %bb139
bb139:
  %t837 = load i64, ptr %l279
  %t838 = inttoptr i64 %t837 to ptr
  %t839 = load { i64, ptr }, ptr %l282
  %t840 = extractvalue { i64, ptr } %t839, 1
  %t841 = call ptr @__olang_region_or(ptr %t840, ptr null)
  %t842 = icmp ne ptr %t841, null
  %t843 = select i1 %t842, ptr %t841, ptr null
  call void @__olang_region_settle_in(ptr %t838, ptr %t843)
  br label %bb137
bb140:
  %t844 = load { i64, ptr }, ptr %l286
  %t845 = extractvalue { i64, ptr } %t844, 1
  call void @__olang_region_release(ptr %t845)
  store { i64, ptr } zeroinitializer, ptr %l286
  br label %bb141
bb141:
  br label %bb142
bb142:
  %t846 = load i64, ptr %l27, !tbaa !24
  %t847 = load i64, ptr %l4, !tbaa !24
  %t850 = icmp slt i64 %t846, %t847
  br i1 %t850, label %bb143, label %bb144
bb143:
  store %olang.scope zeroinitializer, ptr %s28
  %t852 = call ptr @__olang_scope_hold(ptr %s17)
  %t853 = ptrtoint ptr %t852 to i64
  store i64 %t853, ptr %l291, !tbaa !24
  %t854 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2eaccessors_2elocal_2e29
  br i1 %t854, label %bb145, label %bb146
bb144:
  br label %bb154
bb145:
  %t856 = call ptr @__olang_region_make(ptr %s17)
  %t857 = ptrtoint ptr %t856 to i64
  store i64 %t857, ptr %l291, !tbaa !24
  br label %bb146
bb146:
  %t858 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t858, ptr %l293, !tbaa !27
  %t859 = load i64, ptr %l27, !tbaa !24
  %t860 = load i64, ptr %l4, !tbaa !24
  %t861 = load i64, ptr %l4, !tbaa !24
  %t865 = call { i64, ptr } @compiler_2fbindgen_2ebyteMask(ptr %s28, i64 %t859, i64 %t860, i64 %t861)
  store { i64, ptr } %t865, ptr %l297
  br label %bb147
bb147:
  %t866 = load { i64, ptr }, ptr %l293, !tbaa !27
  %t867 = extractvalue { i64, ptr } %t866, 1
  %t868 = extractvalue { i64, ptr } %t866, 0
  %t869 = load { i64, ptr }, ptr %l297, !tbaa !27
  %t870 = extractvalue { i64, ptr } %t869, 1
  %t871 = extractvalue { i64, ptr } %t869, 0
  %t872 = add i64 %t868, %t871
  %t873 = load i64, ptr %l291
  %t874 = inttoptr i64 %t873 to ptr
  %t875 = call ptr @__olang_held_alloc(ptr %t874, i64 %t872)
  call void @olang_textcopy(ptr %t875, ptr %t867, i64 %t868)
  %t876 = getelementptr i8, ptr %t875, i64 %t868
  call void @olang_textcopy(ptr %t876, ptr %t870, i64 %t871)
  %t877 = insertvalue { i64, ptr } undef, i64 %t872, 0
  %t878 = insertvalue { i64, ptr } %t877, ptr %t875, 1
  store { i64, ptr } %t878, ptr %l298, !tbaa !27
  %t879 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2eaccessors_2elocal_2e29
  br i1 %t879, label %bb148, label %bb149
bb148:
  %t881 = load { i64, ptr }, ptr %l298, !tbaa !27
  %t882 = extractvalue { i64, ptr } %t881, 0
  %t884 = icmp eq i64 %t882, 0
  br i1 %t884, label %bb150, label %bb151
bb149:
  %t886 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t886, ptr %l302, !tbaa !27
  %t887 = load { i64, ptr }, ptr %l298, !tbaa !27
  store { i64, ptr } %t887, ptr %l29, !tbaa !27
  %t888 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2eaccessors_2elocal_2e29
  br i1 %t888, label %bb152, label %bb153
bb150:
  store { i64, ptr } zeroinitializer, ptr %l298, !tbaa !27
  br label %bb151
bb151:
  %t890 = load i64, ptr %l291
  %t891 = inttoptr i64 %t890 to ptr
  %t892 = load { i64, ptr }, ptr %l298
  %t893 = extractvalue { i64, ptr } %t892, 1
  %t894 = call ptr @__olang_region_or(ptr %t893, ptr null)
  %t895 = icmp ne ptr %t894, null
  %t896 = select i1 %t895, ptr %t894, ptr null
  call void @__olang_region_settle_in(ptr %t891, ptr %t896)
  br label %bb149
bb152:
  %t897 = load { i64, ptr }, ptr %l302
  %t898 = extractvalue { i64, ptr } %t897, 1
  call void @__olang_region_release(ptr %t898)
  store { i64, ptr } zeroinitializer, ptr %l302
  br label %bb153
bb153:
  call void @__olang_scope_close(ptr %s28)
  br label %bb154
bb154:
  %t899 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t900 = load i64, ptr %l4, !tbaa !24
  %t903 = call { i64, ptr } @compiler_2fbindgen_2ewordBits(ptr %s17, ptr %s17, { i64, ptr } %t899, i64 %t900)
  store { i64, ptr } %t903, ptr %l306
  br label %bb155
bb155:
  %t904 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t904, ptr %l307, !tbaa !27
  %t905 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t905, ptr %l308, !tbaa !27
  %t906 = load i64, ptr %l26, !tbaa !24
  %t907 = load i64, ptr %l27, !tbaa !24
  %t908 = load i64, ptr %l4, !tbaa !24
  %t912 = call { i64, ptr } @compiler_2fbindgen_2ebyteMask(ptr %s17, i64 %t906, i64 %t907, i64 %t908)
  store { i64, ptr } %t912, ptr %l312
  br label %bb156
bb156:
  %t913 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t914 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  %t915 = load { i64, ptr }, ptr %l306, !tbaa !27
  %t916 = extractvalue { i64, ptr } %t915, 1
  %t917 = extractvalue { i64, ptr } %t915, 0
  %t918 = add i64 %t914, %t917
  %t919 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d38, i32 0, i32 1) }, 1
  %t920 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d38, i32 0, i32 1) }, 0
  %t921 = add i64 %t918, %t920
  %t922 = load { i64, ptr }, ptr %l307, !tbaa !27
  %t923 = extractvalue { i64, ptr } %t922, 1
  %t924 = extractvalue { i64, ptr } %t922, 0
  %t925 = add i64 %t921, %t924
  %t926 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d39, i32 0, i32 1) }, 1
  %t927 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d39, i32 0, i32 1) }, 0
  %t928 = add i64 %t925, %t927
  %t929 = load { i64, ptr }, ptr %l308, !tbaa !27
  %t930 = extractvalue { i64, ptr } %t929, 1
  %t931 = extractvalue { i64, ptr } %t929, 0
  %t932 = add i64 %t928, %t931
  %t933 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d40, i32 0, i32 1) }, 1
  %t934 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d40, i32 0, i32 1) }, 0
  %t935 = add i64 %t932, %t934
  %t936 = load { i64, ptr }, ptr %l312, !tbaa !27
  %t937 = extractvalue { i64, ptr } %t936, 1
  %t938 = extractvalue { i64, ptr } %t936, 0
  %t939 = add i64 %t935, %t938
  %t940 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d41, i32 0, i32 1) }, 1
  %t941 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d41, i32 0, i32 1) }, 0
  %t942 = add i64 %t939, %t941
  %t943 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t942)
  call void @olang_textcopy(ptr %t943, ptr %t913, i64 %t914)
  %t944 = getelementptr i8, ptr %t943, i64 %t914
  call void @olang_textcopy(ptr %t944, ptr %t916, i64 %t917)
  %t945 = getelementptr i8, ptr %t944, i64 %t917
  call void @olang_textcopy(ptr %t945, ptr %t919, i64 %t920)
  %t946 = getelementptr i8, ptr %t945, i64 %t920
  call void @olang_textcopy(ptr %t946, ptr %t923, i64 %t924)
  %t947 = getelementptr i8, ptr %t946, i64 %t924
  call void @olang_textcopy(ptr %t947, ptr %t926, i64 %t927)
  %t948 = getelementptr i8, ptr %t947, i64 %t927
  call void @olang_textcopy(ptr %t948, ptr %t930, i64 %t931)
  %t949 = getelementptr i8, ptr %t948, i64 %t931
  call void @olang_textcopy(ptr %t949, ptr %t933, i64 %t934)
  %t950 = getelementptr i8, ptr %t949, i64 %t934
  call void @olang_textcopy(ptr %t950, ptr %t937, i64 %t938)
  %t951 = getelementptr i8, ptr %t950, i64 %t938
  call void @olang_textcopy(ptr %t951, ptr %t940, i64 %t941)
  %t952 = insertvalue { i64, ptr } undef, i64 %t942, 0
  %t953 = insertvalue { i64, ptr } %t952, ptr %t943, 1
  store ptr %l7, ptr %l314, !tbaa !29
  %t955 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t955, ptr %l315, !tbaa !27
  %t957 = load i64, ptr %l4, !tbaa !24
  %t960 = call { i64, ptr } @compiler_2fbindgen_2ewordOf(ptr %s17, ptr %s17, { i64, ptr } %t953, i64 %t957)
  store { i64, ptr } %t960, ptr %l318
  br label %bb157
bb157:
  %t961 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d42, i32 0, i32 1) }, 1
  %t962 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d42, i32 0, i32 1) }, 0
  %t963 = load { i64, ptr }, ptr %l315, !tbaa !27
  %t964 = extractvalue { i64, ptr } %t963, 1
  %t965 = extractvalue { i64, ptr } %t963, 0
  %t966 = add i64 %t962, %t965
  %t967 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t968 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d43, i32 0, i32 1) }, 0
  %t969 = add i64 %t966, %t968
  %t970 = load { i64, ptr }, ptr %l318, !tbaa !27
  %t971 = extractvalue { i64, ptr } %t970, 1
  %t972 = extractvalue { i64, ptr } %t970, 0
  %t973 = add i64 %t969, %t972
  %t974 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t975 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  %t976 = add i64 %t973, %t975
  %t977 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t976)
  call void @olang_textcopy(ptr %t977, ptr %t961, i64 %t962)
  %t978 = getelementptr i8, ptr %t977, i64 %t962
  call void @olang_textcopy(ptr %t978, ptr %t964, i64 %t965)
  %t979 = getelementptr i8, ptr %t978, i64 %t965
  call void @olang_textcopy(ptr %t979, ptr %t967, i64 %t968)
  %t980 = getelementptr i8, ptr %t979, i64 %t968
  call void @olang_textcopy(ptr %t980, ptr %t971, i64 %t972)
  %t981 = getelementptr i8, ptr %t980, i64 %t972
  call void @olang_textcopy(ptr %t981, ptr %t974, i64 %t975)
  %t982 = insertvalue { i64, ptr } undef, i64 %t976, 0
  %t983 = insertvalue { i64, ptr } %t982, ptr %t977, 1
  %t985 = load ptr, ptr %l314, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s17, ptr %t985, { i64, ptr } %t983)
  br label %bb158
bb158:
  call void @__olang_scope_close(ptr %s17)
  br label %bb159
bb159:
  %t987 = load i64, ptr %l22, !tbaa !24
  %t990 = add i64 %t987, 1
  store i64 %t990, ptr %l22, !tbaa !24
  br label %bb81
bb160:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l7, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d45, i32 0, i32 1) })
  br label %bb161
bb161:
  %t994 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v4, ptr %l7)
  store { i64, ptr } %t994, ptr %l326
  br label %bb162
bb162:
  call void @__olang_scope_close(ptr %s0)
  %t995 = load { i64, ptr }, ptr %l326, !tbaa !27
  store { i64, ptr } %t995, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fbindgen_2ebyteMask(ptr %v0, i64 %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l2 = alloca i64
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"std/prelude/text:StringBuilder"
  %l17 = alloca i64
  %l20 = alloca i64
  %l42 = alloca ptr
  %l46 = alloca i1
  %l50 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l11
  store %"std/prelude/text:StringBuilder" %t2, ptr %l3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l3, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d46, i32 0, i32 1) })
  br label %bb2
bb2:
  store i64 0, ptr %l4, !tbaa !24
  %t4 = load i64, ptr %l2, !tbaa !24
  store i64 %t4, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t6 = load i64, ptr %l5, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  %t10 = icmp sgt i64 %t6, %t7
  br i1 %t10, label %bb3, label %bb4
bb3:
  %t12 = load i64, ptr %l6, !tbaa !24
  %t14 = icmp sgt i64 %t12, 0
  br i1 %t14, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb8
bb5:
  %t16 = load i64, ptr %l5, !tbaa !24
  %t17 = load i64, ptr %l4, !tbaa !24
  %t20 = sub i64 %t16, %t17
  %t21 = load i64, ptr %l6, !tbaa !24
  %t24 = add i64 %t20, %t21
  %t26 = sub i64 %t24, 1
  %t27 = load i64, ptr %l6, !tbaa !24
  %t30 = sdiv i64 %t26, %t27
  store i64 %t30, ptr %l20, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb7
bb7:
  %t32 = load i64, ptr %l20, !tbaa !24
  store i64 %t32, ptr %l17, !tbaa !24
  br label %bb8
bb8:
  %t33 = load i64, ptr %l17, !tbaa !24
  store i64 %t33, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t34 = load i64, ptr %l8, !tbaa !24
  %t35 = load i64, ptr %l7, !tbaa !24
  %t38 = icmp slt i64 %t34, %t35
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb11:
  br label %bb12
bb12:
  %t42 = load i64, ptr %l4, !tbaa !24
  %t43 = load i64, ptr %l8, !tbaa !24
  %t44 = load i64, ptr %l6, !tbaa !24
  %t47 = mul i64 %t43, %t44
  %t50 = add i64 %t42, %t47
  %t52 = load i64, ptr %l2, !tbaa !24
  %t54 = sub i64 %t52, 1
  %t58 = sub i64 %t54, %t50
  store i64 %t58, ptr %l10, !tbaa !24
  store ptr %l3, ptr %l42, !tbaa !29
  %t60 = load i64, ptr %l10, !tbaa !24
  %t64 = icmp sge i64 %t60, %a0
  br i1 %t64, label %bb13, label %bb14
bb13:
  %t66 = load i64, ptr %l10, !tbaa !24
  %t70 = icmp slt i64 %t66, %a1
  store i1 %t70, ptr %l46, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l46, !tbaa !21
  br label %bb15
bb15:
  %t72 = load i1, ptr %l46, !tbaa !21
  br i1 %t72, label %bb16, label %bb17
bb16:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d47, i32 0, i32 1) }, ptr %l50, !tbaa !27
  br label %bb18
bb17:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d48, i32 0, i32 1) }, ptr %l50, !tbaa !27
  br label %bb18
bb18:
  %t73 = load ptr, ptr %l42, !tbaa !29
  %t74 = load { i64, ptr }, ptr %l50, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t73, { i64, ptr } %t74)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb20:
  %t75 = load i64, ptr %l8, !tbaa !24
  %t78 = add i64 %t75, 1
  store i64 %t78, ptr %l8, !tbaa !24
  br label %bb9
bb21:
  %t81 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v0, ptr %l3)
  store { i64, ptr } %t81, ptr %l55
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t82 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t82, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local ptr @compiler_2fbindgen_2ecLex(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i8
  %l4 = alloca i64
  %l6 = alloca i8
  %l7 = alloca i8
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca { i64, ptr }
  %l24 = alloca i1
  %l27 = alloca i1
  %l30 = alloca i1
  %l40 = alloca i1
  %l47 = alloca i1
  %l48 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l68 = alloca i64
  %l74 = alloca i1
  %l75 = alloca i1
  %l82 = alloca i1
  %l83 = alloca { i64, ptr }
  %l86 = alloca i1
  %l87 = alloca i1
  %l88 = alloca { i64, ptr }
  %l91 = alloca i1
  %l92 = alloca i1
  %l93 = alloca { i64, ptr }
  %l105 = alloca i1
  %l106 = alloca { i64, ptr }
  %l110 = alloca i1
  %l111 = alloca { i64, ptr }
  %l115 = alloca i1
  %l116 = alloca { i64, ptr }
  %l117 = alloca i64
  %l118 = alloca i64
  %l119 = alloca i64
  %l125 = alloca i1
  %l126 = alloca { i64, ptr }
  %l136 = alloca i1
  %l137 = alloca { i64, ptr }
  %l143 = alloca { i64, ptr }
  %l157 = alloca i64
  %l163 = alloca i1
  %l164 = alloca i1
  %l167 = alloca i1
  %l173 = alloca i1
  %l174 = alloca { i64, ptr }
  %l178 = alloca i1
  %l184 = alloca { i64, ptr }
  %l189 = alloca i1
  %l192 = alloca i1
  %l193 = alloca { i64, ptr }
  %l198 = alloca i1
  %l199 = alloca { i64, ptr }
  %l204 = alloca i1
  %l205 = alloca { i64, ptr }
  %l210 = alloca i1
  %l211 = alloca { i64, ptr }
  %l220 = alloca i1
  %l221 = alloca i1
  %l223 = alloca i1
  %l224 = alloca i1
  %l227 = alloca i1
  %l234 = alloca [15 x { i64, ptr }]
  %l252 = alloca i1
  %l253 = alloca { i64, ptr }
  %l254 = alloca i64
  %l258 = alloca i64
  %l259 = alloca i64
  %l265 = alloca i1
  %l273 = alloca ptr
  %l274 = alloca { i64, ptr }
  %l275 = alloca i64
  %l276 = alloca i64
  %l277 = alloca i64
  %s7 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %rv = alloca ptr
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l12
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %t3
  store ptr %t3, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  br label %bb2
bb2:
  %t5 = load i64, ptr %l2, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  %t11 = icmp slt i64 %t5, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb176
bb4:
  br label %bb5
bb5:
  %t15 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t15, ptr %l19, !tbaa !27
  %t16 = load i64, ptr %l2, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i8, ptr %t19, i64 %t16
  %t21 = load i8, ptr %t20, !tbaa !32
  store i8 %t21, ptr %l3, !tbaa !22
  %t23 = load i8, ptr %l3, !tbaa !22
  %t25 = icmp eq i8 %t23, 32
  br i1 %t25, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb8
bb7:
  %t27 = load i8, ptr %l3, !tbaa !22
  %t29 = icmp eq i8 %t27, 9
  store i1 %t29, ptr %l24, !tbaa !21
  br label %bb8
bb8:
  %t31 = load i1, ptr %l24, !tbaa !21
  br i1 %t31, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb11
bb10:
  %t32 = load i8, ptr %l3, !tbaa !22
  %t34 = icmp eq i8 %t32, 10
  store i1 %t34, ptr %l27, !tbaa !21
  br label %bb11
bb11:
  %t36 = load i1, ptr %l27, !tbaa !21
  br i1 %t36, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb14
bb13:
  %t37 = load i8, ptr %l3, !tbaa !22
  %t39 = icmp eq i8 %t37, 13
  store i1 %t39, ptr %l30, !tbaa !21
  br label %bb14
bb14:
  %t41 = load i1, ptr %l30, !tbaa !21
  br i1 %t41, label %bb15, label %bb16
bb15:
  %t42 = load i64, ptr %l2, !tbaa !24
  %t45 = add i64 %t42, 1
  store i64 %t45, ptr %l2, !tbaa !24
  br label %bb175
bb16:
  br label %bb17
bb17:
  %t47 = load i64, ptr %l2, !tbaa !24
  %t49 = add i64 %t47, 1
  store i64 %t49, ptr %l4, !tbaa !24
  %t51 = load i8, ptr %l3, !tbaa !22
  %t53 = icmp eq i8 %t51, 34
  br i1 %t53, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb20
bb19:
  %t55 = load i8, ptr %l3, !tbaa !22
  %t57 = icmp eq i8 %t55, 39
  store i1 %t57, ptr %l40, !tbaa !21
  br label %bb20
bb20:
  %t59 = load i1, ptr %l40, !tbaa !21
  br i1 %t59, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  %t60 = load i8, ptr %l3, !tbaa !22
  %t62 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t60)
  store i1 %t62, ptr %l74
  br label %bb38
bb23:
  %t63 = load i64, ptr %l4, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t64, 0
  %t69 = icmp slt i64 %t63, %t66
  br i1 %t69, label %bb24, label %bb25
bb24:
  %t71 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t71, ptr %l48, !tbaa !27
  %t72 = load i64, ptr %l4, !tbaa !24
  %t74 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = getelementptr i8, ptr %t75, i64 %t72
  %t77 = load i8, ptr %t76, !tbaa !32
  %t78 = load i8, ptr %l3, !tbaa !22
  %t81 = icmp ne i8 %t77, %t78
  store i1 %t81, ptr %l47, !tbaa !21
  br label %bb26
bb25:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb26
bb26:
  %t83 = load i1, ptr %l47, !tbaa !21
  %t84 = xor i1 %t83, true
  br i1 %t84, label %bb27, label %bb28
bb27:
  br label %bb34
bb28:
  br label %bb29
bb29:
  %t86 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t86, ptr %l54, !tbaa !27
  %t87 = load i64, ptr %l4, !tbaa !24
  %t89 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !27
  %t91 = getelementptr i8, ptr %t90, i64 %t87
  %t92 = load i8, ptr %t91, !tbaa !32
  %t94 = icmp eq i8 %t92, 92
  br i1 %t94, label %bb30, label %bb31
bb30:
  %t96 = load i64, ptr %l4, !tbaa !24
  %t99 = add i64 %t96, 1
  store i64 %t99, ptr %l4, !tbaa !24
  br label %bb32
bb31:
  br label %bb32
bb32:
  %t101 = load i64, ptr %l4, !tbaa !24
  %t104 = add i64 %t101, 1
  store i64 %t104, ptr %l4, !tbaa !24
  br label %bb33
bb33:
  br label %bb23
bb34:
  %t106 = load i64, ptr %l4, !tbaa !24
  %t107 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t107, 0
  %t112 = icmp slt i64 %t106, %t109
  br i1 %t112, label %bb35, label %bb36
bb35:
  %t114 = load i64, ptr %l4, !tbaa !24
  %t116 = add i64 %t114, 1
  store i64 %t116, ptr %l68, !tbaa !24
  br label %bb37
bb36:
  %t118 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t118, 0
  store i64 %t120, ptr %l68, !tbaa !24
  br label %bb37
bb37:
  %t122 = load i64, ptr %l68, !tbaa !24
  store i64 %t122, ptr %l4, !tbaa !24
  br label %bb167
bb38:
  %t123 = load i1, ptr %l74, !tbaa !21
  br i1 %t123, label %bb39, label %bb40
bb39:
  store i1 true, ptr %l75, !tbaa !21
  br label %bb41
bb40:
  %t124 = load i8, ptr %l3, !tbaa !22
  %t126 = icmp eq i8 %t124, 95
  store i1 %t126, ptr %l75, !tbaa !21
  br label %bb41
bb41:
  %t128 = load i1, ptr %l75, !tbaa !21
  br i1 %t128, label %bb42, label %bb43
bb42:
  store %olang.scope zeroinitializer, ptr %s7
  br label %bb44
bb43:
  %t129 = load i8, ptr %l3, !tbaa !22
  %t131 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t129)
  store i1 %t131, ptr %l163
  br label %bb95
bb44:
  %t132 = load i64, ptr %l4, !tbaa !24
  %t133 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t135 = extractvalue { i64, ptr } %t133, 0
  %t138 = icmp slt i64 %t132, %t135
  br i1 %t138, label %bb45, label %bb46
bb45:
  %t140 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t140, ptr %l83, !tbaa !27
  %t141 = load i64, ptr %l4, !tbaa !24
  %t143 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !27
  %t145 = getelementptr i8, ptr %t144, i64 %t141
  %t146 = load i8, ptr %t145, !tbaa !32
  %t148 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t146)
  store i1 %t148, ptr %l86
  br label %bb47
bb46:
  store i1 false, ptr %l82, !tbaa !21
  br label %bb55
bb47:
  %t149 = load i1, ptr %l86, !tbaa !21
  br i1 %t149, label %bb48, label %bb49
bb48:
  store i1 true, ptr %l87, !tbaa !21
  br label %bb51
bb49:
  %t150 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t150, ptr %l88, !tbaa !27
  %t151 = load i64, ptr %l4, !tbaa !24
  %t153 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !27
  %t155 = getelementptr i8, ptr %t154, i64 %t151
  %t156 = load i8, ptr %t155, !tbaa !32
  %t158 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t156)
  store i1 %t158, ptr %l91
  br label %bb50
bb50:
  %t159 = load i1, ptr %l91, !tbaa !21
  store i1 %t159, ptr %l87, !tbaa !21
  br label %bb51
bb51:
  %t160 = load i1, ptr %l87, !tbaa !21
  br i1 %t160, label %bb52, label %bb53
bb52:
  store i1 true, ptr %l92, !tbaa !21
  br label %bb54
bb53:
  %t161 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t161, ptr %l93, !tbaa !27
  %t162 = load i64, ptr %l4, !tbaa !24
  %t164 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t165 = load ptr, ptr %t164, !tbaa !27
  %t166 = getelementptr i8, ptr %t165, i64 %t162
  %t167 = load i8, ptr %t166, !tbaa !32
  %t169 = icmp eq i8 %t167, 95
  store i1 %t169, ptr %l92, !tbaa !21
  br label %bb54
bb54:
  %t171 = load i1, ptr %l92, !tbaa !21
  store i1 %t171, ptr %l82, !tbaa !21
  br label %bb55
bb55:
  %t172 = load i1, ptr %l82, !tbaa !21
  %t173 = xor i1 %t172, true
  br i1 %t173, label %bb56, label %bb57
bb56:
  br label %bb60
bb57:
  br label %bb58
bb58:
  %t175 = load i64, ptr %l4, !tbaa !24
  %t178 = add i64 %t175, 1
  store i64 %t178, ptr %l4, !tbaa !24
  br label %bb59
bb59:
  br label %bb44
bb60:
  %t180 = load i64, ptr %l4, !tbaa !24
  %t181 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t183 = extractvalue { i64, ptr } %t181, 0
  %t186 = icmp slt i64 %t180, %t183
  br i1 %t186, label %bb61, label %bb62
bb61:
  %t188 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t188, ptr %l106, !tbaa !27
  %t189 = load i64, ptr %l4, !tbaa !24
  %t191 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t192 = load ptr, ptr %t191, !tbaa !27
  %t193 = getelementptr i8, ptr %t192, i64 %t189
  %t194 = load i8, ptr %t193, !tbaa !32
  %t196 = icmp eq i8 %t194, 34
  br i1 %t196, label %bb63, label %bb64
bb62:
  store i1 false, ptr %l105, !tbaa !21
  br label %bb66
bb63:
  store i1 true, ptr %l110, !tbaa !21
  br label %bb65
bb64:
  %t198 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t198, ptr %l111, !tbaa !27
  %t199 = load i64, ptr %l4, !tbaa !24
  %t201 = getelementptr { i64, ptr }, ptr %l111, i32 0, i32 1
  %t202 = load ptr, ptr %t201, !tbaa !27
  %t203 = getelementptr i8, ptr %t202, i64 %t199
  %t204 = load i8, ptr %t203, !tbaa !32
  %t206 = icmp eq i8 %t204, 39
  store i1 %t206, ptr %l110, !tbaa !21
  br label %bb65
bb65:
  %t208 = load i1, ptr %l110, !tbaa !21
  store i1 %t208, ptr %l105, !tbaa !21
  br label %bb66
bb66:
  %t209 = load i1, ptr %l105, !tbaa !21
  br i1 %t209, label %bb67, label %bb68
bb67:
  %t210 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t210, ptr %l116, !tbaa !27
  %t211 = load i64, ptr %l2, !tbaa !24
  store i64 %t211, ptr %l117, !tbaa !24
  %t212 = load i64, ptr %l4, !tbaa !24
  store i64 %t212, ptr %l118, !tbaa !24
  %t213 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t214 = extractvalue { i64, ptr } %t213, 0
  store i64 %t214, ptr %l119, !tbaa !24
  %t215 = load i64, ptr %l117, !tbaa !24
  %t216 = icmp sge i64 %t215, 0
  br i1 %t216, label %bb69, label %bb70
bb68:
  store i1 false, ptr %l115, !tbaa !21
  br label %bb76
bb69:
  %t218 = load i64, ptr %l117, !tbaa !24
  %t219 = load i64, ptr %l118, !tbaa !24
  %t220 = icmp sle i64 %t218, %t219
  br i1 %t220, label %bb71, label %bb72
bb70:
  call void @__olang_check_failed(ptr @olang_loc_4691cb288a833ba5_dfaa9dffbec0c2d9)
  unreachable
bb71:
  %t222 = load i64, ptr %l118, !tbaa !24
  %t223 = load i64, ptr %l119, !tbaa !24
  %t224 = icmp sle i64 %t222, %t223
  br i1 %t224, label %bb73, label %bb74
bb72:
  call void @__olang_check_failed(ptr @olang_loc_4691cb288a833ba5_dfaa9dffbec0c2d9)
  unreachable
bb73:
  %t226 = getelementptr { i64, ptr }, ptr %l116, i32 0, i32 1
  %t227 = load ptr, ptr %t226, !tbaa !27
  %t228 = load i64, ptr %l117, !tbaa !24
  %t229 = load i64, ptr %l118, !tbaa !24
  %t230 = getelementptr i8, ptr %t227, i64 %t228
  %t231 = sub i64 %t229, %t228
  %t232 = insertvalue { i64, ptr } undef, i64 %t231, 0
  %t233 = insertvalue { i64, ptr } %t232, ptr %t230, 1
  %t237 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eHas_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %s7, ptr %v0, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x { i64, ptr }] }>, ptr @.d49, i32 0, i32 1) }, { i64, ptr } %t233)
  store i1 %t237, ptr %l125
  br label %bb75
bb74:
  call void @__olang_check_failed(ptr @olang_loc_4691cb288a833ba5_dfaa9dffbec0c2d9)
  unreachable
bb75:
  %t238 = load i1, ptr %l125, !tbaa !21
  store i1 %t238, ptr %l115, !tbaa !21
  br label %bb76
bb76:
  %t239 = load i1, ptr %l115, !tbaa !21
  br i1 %t239, label %bb77, label %bb78
bb77:
  %t240 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t240, ptr %l126, !tbaa !27
  %t241 = load i64, ptr %l4, !tbaa !24
  %t243 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t244 = load ptr, ptr %t243, !tbaa !27
  %t245 = getelementptr i8, ptr %t244, i64 %t241
  %t246 = load i8, ptr %t245, !tbaa !32
  store i8 %t246, ptr %l6, !tbaa !22
  %t248 = load i64, ptr %l4, !tbaa !24
  %t251 = add i64 %t248, 1
  store i64 %t251, ptr %l4, !tbaa !24
  br label %bb79
bb78:
  br label %bb94
bb79:
  %t253 = load i64, ptr %l4, !tbaa !24
  %t254 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t256 = extractvalue { i64, ptr } %t254, 0
  %t259 = icmp slt i64 %t253, %t256
  br i1 %t259, label %bb80, label %bb81
bb80:
  %t261 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t261, ptr %l137, !tbaa !27
  %t262 = load i64, ptr %l4, !tbaa !24
  %t264 = getelementptr { i64, ptr }, ptr %l137, i32 0, i32 1
  %t265 = load ptr, ptr %t264, !tbaa !27
  %t266 = getelementptr i8, ptr %t265, i64 %t262
  %t267 = load i8, ptr %t266, !tbaa !32
  %t268 = load i8, ptr %l6, !tbaa !22
  %t271 = icmp ne i8 %t267, %t268
  store i1 %t271, ptr %l136, !tbaa !21
  br label %bb82
bb81:
  store i1 false, ptr %l136, !tbaa !21
  br label %bb82
bb82:
  %t273 = load i1, ptr %l136, !tbaa !21
  %t274 = xor i1 %t273, true
  br i1 %t274, label %bb83, label %bb84
bb83:
  br label %bb90
bb84:
  br label %bb85
bb85:
  %t276 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t276, ptr %l143, !tbaa !27
  %t277 = load i64, ptr %l4, !tbaa !24
  %t279 = getelementptr { i64, ptr }, ptr %l143, i32 0, i32 1
  %t280 = load ptr, ptr %t279, !tbaa !27
  %t281 = getelementptr i8, ptr %t280, i64 %t277
  %t282 = load i8, ptr %t281, !tbaa !32
  %t284 = icmp eq i8 %t282, 92
  br i1 %t284, label %bb86, label %bb87
bb86:
  %t286 = load i64, ptr %l4, !tbaa !24
  %t289 = add i64 %t286, 1
  store i64 %t289, ptr %l4, !tbaa !24
  br label %bb88
bb87:
  br label %bb88
bb88:
  %t291 = load i64, ptr %l4, !tbaa !24
  %t294 = add i64 %t291, 1
  store i64 %t294, ptr %l4, !tbaa !24
  br label %bb89
bb89:
  br label %bb79
bb90:
  %t296 = load i64, ptr %l4, !tbaa !24
  %t297 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t299 = extractvalue { i64, ptr } %t297, 0
  %t302 = icmp slt i64 %t296, %t299
  br i1 %t302, label %bb91, label %bb92
bb91:
  %t304 = load i64, ptr %l4, !tbaa !24
  %t306 = add i64 %t304, 1
  store i64 %t306, ptr %l157, !tbaa !24
  br label %bb93
bb92:
  %t308 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t310 = extractvalue { i64, ptr } %t308, 0
  store i64 %t310, ptr %l157, !tbaa !24
  br label %bb93
bb93:
  %t312 = load i64, ptr %l157, !tbaa !24
  store i64 %t312, ptr %l4, !tbaa !24
  br label %bb94
bb94:
  call void @__olang_scope_close(ptr %s7)
  br label %bb166
bb95:
  %t313 = load i1, ptr %l163, !tbaa !21
  br i1 %t313, label %bb96, label %bb97
bb96:
  store i1 true, ptr %l164, !tbaa !21
  br label %bb105
bb97:
  %t314 = load i8, ptr %l3, !tbaa !22
  %t316 = icmp eq i8 %t314, 46
  br i1 %t316, label %bb98, label %bb99
bb98:
  %t318 = load i64, ptr %l2, !tbaa !24
  %t320 = add i64 %t318, 1
  %t321 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t323 = extractvalue { i64, ptr } %t321, 0
  %t326 = icmp slt i64 %t320, %t323
  store i1 %t326, ptr %l167, !tbaa !21
  br label %bb100
bb99:
  store i1 false, ptr %l167, !tbaa !21
  br label %bb100
bb100:
  %t328 = load i1, ptr %l167, !tbaa !21
  br i1 %t328, label %bb101, label %bb102
bb101:
  %t329 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t329, ptr %l174, !tbaa !27
  %t330 = load i64, ptr %l2, !tbaa !24
  %t332 = add i64 %t330, 1
  %t334 = getelementptr { i64, ptr }, ptr %l174, i32 0, i32 1
  %t335 = load ptr, ptr %t334, !tbaa !27
  %t336 = getelementptr i8, ptr %t335, i64 %t332
  %t337 = load i8, ptr %t336, !tbaa !32
  %t339 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t337)
  store i1 %t339, ptr %l178
  br label %bb103
bb102:
  store i1 false, ptr %l173, !tbaa !21
  br label %bb104
bb103:
  %t340 = load i1, ptr %l178, !tbaa !21
  store i1 %t340, ptr %l173, !tbaa !21
  br label %bb104
bb104:
  %t341 = load i1, ptr %l173, !tbaa !21
  store i1 %t341, ptr %l164, !tbaa !21
  br label %bb105
bb105:
  %t342 = load i1, ptr %l164, !tbaa !21
  br i1 %t342, label %bb106, label %bb107
bb106:
  br label %bb108
bb107:
  store %olang.scope zeroinitializer, ptr %s18
  %t343 = getelementptr [15 x { i64, ptr }], ptr %l234, i64 0, i64 0
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d50, i32 0, i32 1) }, ptr %t343, !tbaa !37
  %t344 = getelementptr [15 x { i64, ptr }], ptr %l234, i64 0, i64 1
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d51, i32 0, i32 1) }, ptr %t344, !tbaa !37
  %t345 = getelementptr [15 x { i64, ptr }], ptr %l234, i64 0, i64 2
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d52, i32 0, i32 1) }, ptr %t345, !tbaa !37
  %t346 = getelementptr [15 x { i64, ptr }], ptr %l234, i64 0, i64 3
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d53, i32 0, i32 1) }, ptr %t346, !tbaa !37
  %t347 = getelementptr [15 x { i64, ptr }], ptr %l234, i64 0, i64 4
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d54, i32 0, i32 1) }, ptr %t347, !tbaa !37
  %t348 = getelementptr [15 x { i64, ptr }], ptr %l234, i64 0, i64 5
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d55, i32 0, i32 1) }, ptr %t348, !tbaa !37
  %t349 = getelementptr [15 x { i64, ptr }], ptr %l234, i64 0, i64 6
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d56, i32 0, i32 1) }, ptr %t349, !tbaa !37
  %t350 = getelementptr [15 x { i64, ptr }], ptr %l234, i64 0, i64 7
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d57, i32 0, i32 1) }, ptr %t350, !tbaa !37
  %t351 = getelementptr [15 x { i64, ptr }], ptr %l234, i64 0, i64 8
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d58, i32 0, i32 1) }, ptr %t351, !tbaa !37
  %t352 = getelementptr [15 x { i64, ptr }], ptr %l234, i64 0, i64 9
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d59, i32 0, i32 1) }, ptr %t352, !tbaa !37
  %t353 = getelementptr [15 x { i64, ptr }], ptr %l234, i64 0, i64 10
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d60, i32 0, i32 1) }, ptr %t353, !tbaa !37
  %t354 = getelementptr [15 x { i64, ptr }], ptr %l234, i64 0, i64 11
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d61, i32 0, i32 1) }, ptr %t354, !tbaa !37
  %t355 = getelementptr [15 x { i64, ptr }], ptr %l234, i64 0, i64 12
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d62, i32 0, i32 1) }, ptr %t355, !tbaa !37
  %t356 = getelementptr [15 x { i64, ptr }], ptr %l234, i64 0, i64 13
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d63, i32 0, i32 1) }, ptr %t356, !tbaa !37
  %t357 = getelementptr [15 x { i64, ptr }], ptr %l234, i64 0, i64 14
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d64, i32 0, i32 1) }, ptr %t357, !tbaa !37
  %t358 = call ptr @__olang_scope_alloc_a(ptr %s18, i64 240, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t358, ptr %l234, i64 240, i1 false)
  store ptr %t358, ptr %l8
  store i64 0, ptr %l9, !tbaa !24
  %t360 = load ptr, ptr %l8
  store i64 15, ptr %l10, !tbaa !24
  br label %bb146
bb108:
  %t363 = load i64, ptr %l4, !tbaa !24
  %t364 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t366 = extractvalue { i64, ptr } %t364, 0
  %t369 = icmp slt i64 %t363, %t366
  %t371 = xor i1 %t369, true
  br i1 %t371, label %bb109, label %bb110
bb109:
  br label %bb145
bb110:
  br label %bb111
bb111:
  %t373 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t373, ptr %l184, !tbaa !27
  %t374 = load i64, ptr %l4, !tbaa !24
  %t376 = getelementptr { i64, ptr }, ptr %l184, i32 0, i32 1
  %t377 = load ptr, ptr %t376, !tbaa !27
  %t378 = getelementptr i8, ptr %t377, i64 %t374
  %t379 = load i8, ptr %t378, !tbaa !32
  store i8 %t379, ptr %l7, !tbaa !22
  %t381 = load i8, ptr %l7, !tbaa !22
  %t383 = icmp eq i8 %t381, 43
  br i1 %t383, label %bb112, label %bb113
bb112:
  store i1 true, ptr %l189, !tbaa !21
  br label %bb114
bb113:
  %t385 = load i8, ptr %l7, !tbaa !22
  %t387 = icmp eq i8 %t385, 45
  store i1 %t387, ptr %l189, !tbaa !21
  br label %bb114
bb114:
  %t389 = load i1, ptr %l189, !tbaa !21
  br i1 %t389, label %bb115, label %bb116
bb115:
  %t390 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t390, ptr %l193, !tbaa !27
  %t391 = load i64, ptr %l4, !tbaa !24
  %t393 = sub i64 %t391, 1
  %t395 = getelementptr { i64, ptr }, ptr %l193, i32 0, i32 1
  %t396 = load ptr, ptr %t395, !tbaa !27
  %t397 = getelementptr i8, ptr %t396, i64 %t393
  %t398 = load i8, ptr %t397, !tbaa !32
  %t400 = icmp eq i8 %t398, 101
  br i1 %t400, label %bb117, label %bb118
bb116:
  store i1 false, ptr %l192, !tbaa !21
  br label %bb126
bb117:
  store i1 true, ptr %l198, !tbaa !21
  br label %bb119
bb118:
  %t402 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t402, ptr %l199, !tbaa !27
  %t403 = load i64, ptr %l4, !tbaa !24
  %t405 = sub i64 %t403, 1
  %t407 = getelementptr { i64, ptr }, ptr %l199, i32 0, i32 1
  %t408 = load ptr, ptr %t407, !tbaa !27
  %t409 = getelementptr i8, ptr %t408, i64 %t405
  %t410 = load i8, ptr %t409, !tbaa !32
  %t412 = icmp eq i8 %t410, 69
  store i1 %t412, ptr %l198, !tbaa !21
  br label %bb119
bb119:
  %t414 = load i1, ptr %l198, !tbaa !21
  br i1 %t414, label %bb120, label %bb121
bb120:
  store i1 true, ptr %l204, !tbaa !21
  br label %bb122
bb121:
  %t415 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t415, ptr %l205, !tbaa !27
  %t416 = load i64, ptr %l4, !tbaa !24
  %t418 = sub i64 %t416, 1
  %t420 = getelementptr { i64, ptr }, ptr %l205, i32 0, i32 1
  %t421 = load ptr, ptr %t420, !tbaa !27
  %t422 = getelementptr i8, ptr %t421, i64 %t418
  %t423 = load i8, ptr %t422, !tbaa !32
  %t425 = icmp eq i8 %t423, 112
  store i1 %t425, ptr %l204, !tbaa !21
  br label %bb122
bb122:
  %t427 = load i1, ptr %l204, !tbaa !21
  br i1 %t427, label %bb123, label %bb124
bb123:
  store i1 true, ptr %l210, !tbaa !21
  br label %bb125
bb124:
  %t428 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t428, ptr %l211, !tbaa !27
  %t429 = load i64, ptr %l4, !tbaa !24
  %t431 = sub i64 %t429, 1
  %t433 = getelementptr { i64, ptr }, ptr %l211, i32 0, i32 1
  %t434 = load ptr, ptr %t433, !tbaa !27
  %t435 = getelementptr i8, ptr %t434, i64 %t431
  %t436 = load i8, ptr %t435, !tbaa !32
  %t438 = icmp eq i8 %t436, 80
  store i1 %t438, ptr %l210, !tbaa !21
  br label %bb125
bb125:
  %t440 = load i1, ptr %l210, !tbaa !21
  store i1 %t440, ptr %l192, !tbaa !21
  br label %bb126
bb126:
  %t441 = load i1, ptr %l192, !tbaa !21
  br i1 %t441, label %bb127, label %bb128
bb127:
  %t442 = load i64, ptr %l4, !tbaa !24
  %t445 = add i64 %t442, 1
  store i64 %t445, ptr %l4, !tbaa !24
  br label %bb144
bb128:
  br label %bb129
bb129:
  %t447 = load i8, ptr %l7, !tbaa !22
  %t449 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t447)
  store i1 %t449, ptr %l220
  br label %bb130
bb130:
  %t450 = load i1, ptr %l220, !tbaa !21
  br i1 %t450, label %bb131, label %bb132
bb131:
  store i1 true, ptr %l221, !tbaa !21
  br label %bb134
bb132:
  %t451 = load i8, ptr %l7, !tbaa !22
  %t453 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t451)
  store i1 %t453, ptr %l223
  br label %bb133
bb133:
  %t454 = load i1, ptr %l223, !tbaa !21
  store i1 %t454, ptr %l221, !tbaa !21
  br label %bb134
bb134:
  %t455 = load i1, ptr %l221, !tbaa !21
  br i1 %t455, label %bb135, label %bb136
bb135:
  store i1 true, ptr %l224, !tbaa !21
  br label %bb137
bb136:
  %t456 = load i8, ptr %l7, !tbaa !22
  %t458 = icmp eq i8 %t456, 95
  store i1 %t458, ptr %l224, !tbaa !21
  br label %bb137
bb137:
  %t460 = load i1, ptr %l224, !tbaa !21
  br i1 %t460, label %bb138, label %bb139
bb138:
  store i1 true, ptr %l227, !tbaa !21
  br label %bb140
bb139:
  %t461 = load i8, ptr %l7, !tbaa !22
  %t463 = icmp eq i8 %t461, 46
  store i1 %t463, ptr %l227, !tbaa !21
  br label %bb140
bb140:
  %t465 = load i1, ptr %l227, !tbaa !21
  %t466 = xor i1 %t465, true
  br i1 %t466, label %bb141, label %bb142
bb141:
  br label %bb145
bb142:
  br label %bb143
bb143:
  %t468 = load i64, ptr %l4, !tbaa !24
  %t471 = add i64 %t468, 1
  store i64 %t471, ptr %l4, !tbaa !24
  br label %bb144
bb144:
  br label %bb108
bb145:
  br label %bb165
bb146:
  %t473 = load i64, ptr %l9, !tbaa !24
  %t474 = load i64, ptr %l10, !tbaa !24
  %t477 = icmp slt i64 %t473, %t474
  %t479 = xor i1 %t477, true
  br i1 %t479, label %bb147, label %bb148
bb147:
  br label %bb164
bb148:
  br label %bb149
bb149:
  %t481 = load ptr, ptr %l8
  %t482 = load i64, ptr %l9, !tbaa !24
  %t485 = getelementptr [15 x { i64, ptr }], ptr %t481, i64 0, i64 %t482
  %t486 = load { i64, ptr }, ptr %t485, !tbaa !37
  store { i64, ptr } %t486, ptr %l11, !tbaa !27
  %t488 = load i64, ptr %l2, !tbaa !24
  %t489 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t491 = extractvalue { i64, ptr } %t489, 0
  %t494 = add i64 %t488, %t491
  %t495 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t497 = extractvalue { i64, ptr } %t495, 0
  %t500 = icmp sle i64 %t494, %t497
  br i1 %t500, label %bb150, label %bb151
bb150:
  %t502 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t502, ptr %l253, !tbaa !27
  %t503 = load i64, ptr %l2, !tbaa !24
  store i64 %t503, ptr %l254, !tbaa !24
  %t504 = load i64, ptr %l2, !tbaa !24
  %t505 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t507 = extractvalue { i64, ptr } %t505, 0
  %t510 = add i64 %t504, %t507
  store i64 %t510, ptr %l258, !tbaa !24
  %t511 = load { i64, ptr }, ptr %l253, !tbaa !27
  %t512 = extractvalue { i64, ptr } %t511, 0
  store i64 %t512, ptr %l259, !tbaa !24
  %t513 = load i64, ptr %l254, !tbaa !24
  %t514 = icmp sge i64 %t513, 0
  br i1 %t514, label %bb152, label %bb153
bb151:
  store i1 false, ptr %l252, !tbaa !21
  br label %bb159
bb152:
  %t516 = load i64, ptr %l254, !tbaa !24
  %t517 = load i64, ptr %l258, !tbaa !24
  %t518 = icmp sle i64 %t516, %t517
  br i1 %t518, label %bb154, label %bb155
bb153:
  call void @__olang_check_failed(ptr @olang_loc_8de001e7a64c0b48_1a9d06562d43232c)
  unreachable
bb154:
  %t520 = load i64, ptr %l258, !tbaa !24
  %t521 = load i64, ptr %l259, !tbaa !24
  %t522 = icmp sle i64 %t520, %t521
  br i1 %t522, label %bb156, label %bb157
bb155:
  call void @__olang_check_failed(ptr @olang_loc_8de001e7a64c0b48_1a9d06562d43232c)
  unreachable
bb156:
  %t524 = getelementptr { i64, ptr }, ptr %l253, i32 0, i32 1
  %t525 = load ptr, ptr %t524, !tbaa !27
  %t526 = load i64, ptr %l254, !tbaa !24
  %t527 = load i64, ptr %l258, !tbaa !24
  %t528 = getelementptr i8, ptr %t525, i64 %t526
  %t529 = sub i64 %t527, %t526
  %t530 = insertvalue { i64, ptr } undef, i64 %t529, 0
  %t531 = insertvalue { i64, ptr } %t530, ptr %t528, 1
  %t532 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t533 = load ptr, ptr @__olang_prog_scope
  %t536 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %t533, { i64, ptr } %t531, { i64, ptr } %t532)
  store i1 %t536, ptr %l265
  br label %bb158
bb157:
  call void @__olang_check_failed(ptr @olang_loc_8de001e7a64c0b48_1a9d06562d43232c)
  unreachable
bb158:
  %t537 = load i1, ptr %l265, !tbaa !21
  store i1 %t537, ptr %l252, !tbaa !21
  br label %bb159
bb159:
  %t538 = load i1, ptr %l252, !tbaa !21
  br i1 %t538, label %bb160, label %bb161
bb160:
  %t539 = load i64, ptr %l2, !tbaa !24
  %t540 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t542 = extractvalue { i64, ptr } %t540, 0
  %t545 = add i64 %t539, %t542
  store i64 %t545, ptr %l4, !tbaa !24
  br label %bb164
bb161:
  br label %bb162
bb162:
  br label %bb163
bb163:
  %t547 = load i64, ptr %l9, !tbaa !24
  %t550 = add i64 %t547, 1
  store i64 %t550, ptr %l9, !tbaa !24
  br label %bb146
bb164:
  call void @__olang_scope_close(ptr %s18)
  br label %bb165
bb165:
  br label %bb166
bb166:
  br label %bb167
bb167:
  %t552 = load ptr, ptr %l1, !tbaa !29
  store ptr %t552, ptr %l273, !tbaa !29
  %t553 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t553, ptr %l274, !tbaa !27
  %t554 = load i64, ptr %l2, !tbaa !24
  store i64 %t554, ptr %l275, !tbaa !24
  %t555 = load i64, ptr %l4, !tbaa !24
  store i64 %t555, ptr %l276, !tbaa !24
  %t556 = load { i64, ptr }, ptr %l274, !tbaa !27
  %t557 = extractvalue { i64, ptr } %t556, 0
  store i64 %t557, ptr %l277, !tbaa !24
  %t558 = load i64, ptr %l275, !tbaa !24
  %t559 = icmp sge i64 %t558, 0
  br i1 %t559, label %bb168, label %bb169
bb168:
  %t561 = load i64, ptr %l275, !tbaa !24
  %t562 = load i64, ptr %l276, !tbaa !24
  %t563 = icmp sle i64 %t561, %t562
  br i1 %t563, label %bb170, label %bb171
bb169:
  call void @__olang_check_failed(ptr @olang_loc_9f24fc1b10bf4163_f387df93e06eee97)
  unreachable
bb170:
  %t565 = load i64, ptr %l276, !tbaa !24
  %t566 = load i64, ptr %l277, !tbaa !24
  %t567 = icmp sle i64 %t565, %t566
  br i1 %t567, label %bb172, label %bb173
bb171:
  call void @__olang_check_failed(ptr @olang_loc_9f24fc1b10bf4163_f387df93e06eee97)
  unreachable
bb172:
  %t569 = getelementptr { i64, ptr }, ptr %l274, i32 0, i32 1
  %t570 = load ptr, ptr %t569, !tbaa !27
  %t571 = load i64, ptr %l275, !tbaa !24
  %t572 = load i64, ptr %l276, !tbaa !24
  %t573 = getelementptr i8, ptr %t570, i64 %t571
  %t574 = sub i64 %t572, %t571
  %t575 = insertvalue { i64, ptr } undef, i64 %t574, 0
  %t576 = insertvalue { i64, ptr } %t575, ptr %t573, 1
  %t577 = load ptr, ptr %l273, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v0, ptr %t577, { i64, ptr } %t576)
  br label %bb174
bb173:
  call void @__olang_check_failed(ptr @olang_loc_9f24fc1b10bf4163_f387df93e06eee97)
  unreachable
bb174:
  %t579 = load i64, ptr %l4, !tbaa !24
  store i64 %t579, ptr %l2, !tbaa !24
  br label %bb175
bb175:
  br label %bb2
bb176:
  %t581 = load ptr, ptr %l1, !tbaa !29
  store ptr %t581, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2fbindgen_2ecPrec(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l3 = alloca i1
  %l5 = alloca i1
  %l7 = alloca i1
  %l9 = alloca i1
  %l11 = alloca i1
  %l13 = alloca i1
  %l15 = alloca i1
  %l17 = alloca i1
  %l19 = alloca i1
  %l21 = alloca i1
  %l23 = alloca i1
  %l25 = alloca i1
  %l27 = alloca i1
  %l29 = alloca i1
  %l31 = alloca i1
  %l33 = alloca i1
  %l35 = alloca i1
  %l37 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d65, i32 0, i32 1) })
  store i1 %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load i1, ptr %l3, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb5
bb4:
  store i64 1, ptr %l1, !tbaa !24
  br label %bb79
bb5:
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t5, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d66, i32 0, i32 1) })
  store i1 %t7, ptr %l5
  br label %bb6
bb6:
  %t8 = load i1, ptr %l5, !tbaa !21
  br i1 %t8, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i64 2, ptr %l1, !tbaa !24
  br label %bb79
bb10:
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t11 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t9, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d67, i32 0, i32 1) })
  store i1 %t11, ptr %l7
  br label %bb11
bb11:
  %t12 = load i1, ptr %l7, !tbaa !21
  br i1 %t12, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i64 3, ptr %l1, !tbaa !24
  br label %bb79
bb15:
  %t13 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t15 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t13, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d68, i32 0, i32 1) })
  store i1 %t15, ptr %l9
  br label %bb16
bb16:
  %t16 = load i1, ptr %l9, !tbaa !21
  br i1 %t16, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i64 4, ptr %l1, !tbaa !24
  br label %bb79
bb20:
  %t17 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t19 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t17, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d69, i32 0, i32 1) })
  store i1 %t19, ptr %l11
  br label %bb21
bb21:
  %t20 = load i1, ptr %l11, !tbaa !21
  br i1 %t20, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  store i64 5, ptr %l1, !tbaa !24
  br label %bb79
bb25:
  %t21 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t23 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t21, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d70, i32 0, i32 1) })
  store i1 %t23, ptr %l13
  br label %bb26
bb26:
  %t24 = load i1, ptr %l13, !tbaa !21
  br i1 %t24, label %bb27, label %bb28
bb27:
  br label %bb32
bb28:
  %t25 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t27 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t25, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d71, i32 0, i32 1) })
  store i1 %t27, ptr %l15
  br label %bb29
bb29:
  %t28 = load i1, ptr %l15, !tbaa !21
  br i1 %t28, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  store i64 6, ptr %l1, !tbaa !24
  br label %bb79
bb33:
  %t29 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t31 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t29, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d72, i32 0, i32 1) })
  store i1 %t31, ptr %l17
  br label %bb34
bb34:
  %t32 = load i1, ptr %l17, !tbaa !21
  br i1 %t32, label %bb35, label %bb36
bb35:
  br label %bb46
bb36:
  %t33 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t35 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t33, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d73, i32 0, i32 1) })
  store i1 %t35, ptr %l19
  br label %bb37
bb37:
  %t36 = load i1, ptr %l19, !tbaa !21
  br i1 %t36, label %bb38, label %bb39
bb38:
  br label %bb46
bb39:
  %t37 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t39 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t37, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d74, i32 0, i32 1) })
  store i1 %t39, ptr %l21
  br label %bb40
bb40:
  %t40 = load i1, ptr %l21, !tbaa !21
  br i1 %t40, label %bb41, label %bb42
bb41:
  br label %bb46
bb42:
  %t41 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t43 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t41, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d75, i32 0, i32 1) })
  store i1 %t43, ptr %l23
  br label %bb43
bb43:
  %t44 = load i1, ptr %l23, !tbaa !21
  br i1 %t44, label %bb44, label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb47
bb46:
  store i64 7, ptr %l1, !tbaa !24
  br label %bb79
bb47:
  %t45 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t47 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t45, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d76, i32 0, i32 1) })
  store i1 %t47, ptr %l25
  br label %bb48
bb48:
  %t48 = load i1, ptr %l25, !tbaa !21
  br i1 %t48, label %bb49, label %bb50
bb49:
  br label %bb54
bb50:
  %t49 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t51 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t49, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d77, i32 0, i32 1) })
  store i1 %t51, ptr %l27
  br label %bb51
bb51:
  %t52 = load i1, ptr %l27, !tbaa !21
  br i1 %t52, label %bb52, label %bb53
bb52:
  br label %bb54
bb53:
  br label %bb55
bb54:
  store i64 8, ptr %l1, !tbaa !24
  br label %bb79
bb55:
  %t53 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t55 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t53, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d78, i32 0, i32 1) })
  store i1 %t55, ptr %l29
  br label %bb56
bb56:
  %t56 = load i1, ptr %l29, !tbaa !21
  br i1 %t56, label %bb57, label %bb58
bb57:
  br label %bb62
bb58:
  %t57 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t59 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t57, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d79, i32 0, i32 1) })
  store i1 %t59, ptr %l31
  br label %bb59
bb59:
  %t60 = load i1, ptr %l31, !tbaa !21
  br i1 %t60, label %bb60, label %bb61
bb60:
  br label %bb62
bb61:
  br label %bb63
bb62:
  store i64 9, ptr %l1, !tbaa !24
  br label %bb79
bb63:
  %t61 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t63 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t61, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d80, i32 0, i32 1) })
  store i1 %t63, ptr %l33
  br label %bb64
bb64:
  %t64 = load i1, ptr %l33, !tbaa !21
  br i1 %t64, label %bb65, label %bb66
bb65:
  br label %bb73
bb66:
  %t65 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t67 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t65, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d81, i32 0, i32 1) })
  store i1 %t67, ptr %l35
  br label %bb67
bb67:
  %t68 = load i1, ptr %l35, !tbaa !21
  br i1 %t68, label %bb68, label %bb69
bb68:
  br label %bb73
bb69:
  %t69 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t71 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t69, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d82, i32 0, i32 1) })
  store i1 %t71, ptr %l37
  br label %bb70
bb70:
  %t72 = load i1, ptr %l37, !tbaa !21
  br i1 %t72, label %bb71, label %bb72
bb71:
  br label %bb73
bb72:
  br label %bb74
bb73:
  store i64 10, ptr %l1, !tbaa !24
  br label %bb79
bb74:
  br i1 true, label %bb75, label %bb76
bb75:
  br label %bb77
bb76:
  br label %bb78
bb77:
  store i64 0, ptr %l1, !tbaa !24
  br label %bb79
bb78:
  call void @__olang_check_failed(ptr @olang_loc_760c7c7ac1a62521_16c6052ca99c0395)
  unreachable
bb79:
  call void @__olang_scope_close(ptr %s0)
  %t73 = load i64, ptr %l1, !tbaa !24
  store i64 %t73, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i32, %"compiler/bindgen:cx" } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecBinary(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %lp3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %lp6 = alloca ptr
  %l7 = alloca %"compiler/bindgen:cx"
  %l8 = alloca %"compiler/bindgen:cx"
  %lp9 = alloca ptr
  %lp10 = alloca ptr
  %l11 = alloca %"compiler/bindgen:cx"
  %l12 = alloca %"compiler/bindgen:cx"
  %l15 = alloca %"compiler/bindgen:cx"
  %l16 = alloca i32
  %l19 = alloca { i64, ptr }
  %l21 = alloca i64
  %l24 = alloca i1
  %l28 = alloca ptr
  %l32 = alloca %"compiler/bindgen:cx"
  %l37 = alloca %"compiler/bindgen:cx"
  %l38 = alloca i32
  %l41 = alloca i1
  %l42 = alloca i1
  %l44 = alloca i1
  %l45 = alloca i64
  %l49 = alloca %"compiler/bindgen:cx"
  %l50 = alloca { i64, ptr }
  %l52 = alloca i1
  %l53 = alloca { i64, ptr }
  %l56 = alloca %"compiler/bindgen:cx"
  %l61 = alloca %"compiler/bindgen:cx"
  %l62 = alloca %"compiler/bindgen:cx"
  %l67 = alloca i1
  %l72 = alloca %"compiler/bindgen:cx"
  %l75 = alloca %"compiler/bindgen:cx"
  %l76 = alloca i64
  %l84 = alloca %"compiler/bindgen:cx"
  %l85 = alloca %"compiler/bindgen:cx"
  %l90 = alloca %"compiler/bindgen:cx"
  %l93 = alloca %"compiler/bindgen:cx"
  %l96 = alloca %"compiler/bindgen:cx"
  %l101 = alloca %"compiler/bindgen:cx"
  %l104 = alloca i1
  %l108 = alloca i1
  %l113 = alloca %"compiler/bindgen:cx"
  %l114 = alloca %"compiler/bindgen:cx"
  %l117 = alloca i64
  %l127 = alloca %"compiler/bindgen:cx"
  %l128 = alloca %"compiler/bindgen:cx"
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i32, %"compiler/bindgen:cx" }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call { i32, %"compiler/bindgen:cx" } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecUnary(ptr %v0, ptr %v1, ptr %v2, ptr %t1, ptr %t2)
  %t6 = extractvalue { i32, %"compiler/bindgen:cx" } %t5, 1
  %t7 = extractvalue { i32, %"compiler/bindgen:cx" } %t5, 0
  store i32 %t7, ptr %l16
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9, !prof !99
ok.9:
  store %"compiler/bindgen:cx" %t6, ptr %l15
  br label %bb1
bb1:
  %t10 = load %"compiler/bindgen:cx", ptr %l15
  store %"compiler/bindgen:cx" %t10, ptr %l12
  br label %bb3
bb2:
  %t11 = load i32, ptr %l16, !tbaa !23
  %t12 = lshr i32 %t11, 16
  %t13 = and i32 %t11, 65535
  %t14 = icmp eq i32 %t12, 1
  %t15 = select i1 %t14, i32 1, i32 0
  %t16 = icmp eq i32 %t11, 0
  %t17 = shl i32 %t15, 16
  %t18 = or i32 %t17, %t13
  %t19 = select i1 %t16, i32 0, i32 %t18
  %t21 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, i32 %t19, 0
  store { i32, %"compiler/bindgen:cx" } %t21, ptr %rv
  br label %ret
bb3:
  %t22 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store ptr %t22, ptr %lp3
  %t23 = load %"compiler/bindgen:cx", ptr %l12
  %t24 = load ptr, ptr %lp3
  store %"compiler/bindgen:cx" %t23, ptr %t24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3acparse_2eat(ptr %v1, ptr %s1, ptr %t25)
  store { i64, ptr } %t27, ptr %l19
  br label %bb5
bb5:
  %t28 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t28, ptr %l4, !tbaa !27
  %t29 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t31 = call i64 @compiler_2fbindgen_2ecPrec(ptr %s1, { i64, ptr } %t29)
  store i64 %t31, ptr %l21
  br label %bb6
bb6:
  %t32 = load i64, ptr %l21, !tbaa !24
  store i64 %t32, ptr %l5, !tbaa !24
  %t33 = load i64, ptr %l5, !tbaa !24
  %t35 = icmp eq i64 %t33, 0
  br i1 %t35, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb9
bb8:
  %t37 = load i64, ptr %l5, !tbaa !24
  %t41 = icmp slt i64 %t37, %a2
  store i1 %t41, ptr %l24, !tbaa !21
  br label %bb9
bb9:
  %t43 = load i1, ptr %l24, !tbaa !21
  br i1 %t43, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s1)
  br label %bb80
bb11:
  br label %bb12
bb12:
  %t44 = load ptr, ptr %l1, !tbaa !29
  store ptr %t44, ptr %l28, !tbaa !29
  %t45 = load ptr, ptr %l28, !tbaa !29
  %t46 = getelementptr %"compiler/bindgen:cparse", ptr %t45, i32 0, i32 2
  %t47 = load i64, ptr %t46, !tbaa !24
  %t50 = add i64 %t47, 1
  %t52 = load ptr, ptr %l28, !tbaa !29
  %t53 = getelementptr %"compiler/bindgen:cparse", ptr %t52, i32 0, i32 2
  store i64 %t50, ptr %t53, !tbaa !24
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t56 = load i64, ptr %l5, !tbaa !24
  %t58 = add i64 %t56, 1
  %t62 = call { i32, %"compiler/bindgen:cx" } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecBinary(ptr %v0, ptr %v1, ptr %v2, ptr %t54, ptr %t55, i64 %t58)
  %t63 = extractvalue { i32, %"compiler/bindgen:cx" } %t62, 1
  %t64 = extractvalue { i32, %"compiler/bindgen:cx" } %t62, 0
  store i32 %t64, ptr %l38
  %t65 = icmp ne i32 %t64, 0
  br i1 %t65, label %bb14, label %ok.66, !prof !99
ok.66:
  store %"compiler/bindgen:cx" %t63, ptr %l37
  br label %bb13
bb13:
  %t67 = load %"compiler/bindgen:cx", ptr %l37
  store %"compiler/bindgen:cx" %t67, ptr %l32
  br label %bb15
bb14:
  %t68 = load i32, ptr %l38, !tbaa !23
  %t69 = lshr i32 %t68, 16
  %t70 = and i32 %t68, 65535
  %t71 = icmp eq i32 %t69, 1
  %t72 = select i1 %t71, i32 1, i32 0
  %t73 = icmp eq i32 %t68, 0
  %t74 = shl i32 %t72, 16
  %t75 = or i32 %t74, %t70
  %t76 = select i1 %t73, i32 0, i32 %t75
  call void @__olang_scope_close(ptr %s1)
  %t78 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, i32 %t76, 0
  store { i32, %"compiler/bindgen:cx" } %t78, ptr %rv
  br label %ret
bb15:
  %t79 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store ptr %t79, ptr %lp6
  %t80 = load %"compiler/bindgen:cx", ptr %l32
  %t81 = load ptr, ptr %lp6
  store %"compiler/bindgen:cx" %t80, ptr %t81
  %t82 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t84 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s1, ptr %s1, { i64, ptr } %t82, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d83, i32 0, i32 1) })
  store i1 %t84, ptr %l41
  br label %bb16
bb16:
  %t85 = load i1, ptr %l41, !tbaa !21
  br i1 %t85, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l42, !tbaa !21
  br label %bb20
bb18:
  %t86 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t88 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s1, ptr %s1, { i64, ptr } %t86, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d84, i32 0, i32 1) })
  store i1 %t88, ptr %l44
  br label %bb19
bb19:
  %t89 = load i1, ptr %l44, !tbaa !21
  store i1 %t89, ptr %l42, !tbaa !21
  br label %bb20
bb20:
  %t90 = load i1, ptr %l42, !tbaa !21
  br i1 %t90, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s3
  %t91 = call ptr @__olang_scope_hold(ptr %v2)
  %t92 = ptrtoint ptr %t91 to i64
  store i64 %t92, ptr %l45, !tbaa !24
  %t93 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3acx_2e0
  br i1 %t93, label %bb23, label %bb24
bb22:
  %t95 = load i64, ptr %l5, !tbaa !24
  %t97 = icmp eq i64 %t95, 6
  br i1 %t97, label %bb36, label %bb37
bb23:
  %t99 = call ptr @__olang_region_make(ptr %v2)
  %t100 = ptrtoint ptr %t99 to i64
  store i64 %t100, ptr %l45, !tbaa !24
  br label %bb24
bb24:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load ptr, ptr %lp3
  %t103 = load %"compiler/bindgen:cx", ptr %t102
  %t106 = call %"compiler/bindgen:cx" @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecBool(ptr %v0, ptr %v2, ptr %v2, ptr %t101, %"compiler/bindgen:cx" %t103)
  store %"compiler/bindgen:cx" %t106, ptr %l49
  br label %bb25
bb25:
  %t107 = getelementptr %"compiler/bindgen:cx", ptr %l49, i32 0, i32 0
  %t108 = load { i64, ptr }, ptr %t107, !tbaa !27
  store { i64, ptr } %t108, ptr %l50, !tbaa !27
  %t109 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t111 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s1, ptr %s3, { i64, ptr } %t109, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d85, i32 0, i32 1) })
  store i1 %t111, ptr %l52
  br label %bb26
bb26:
  %t112 = load i1, ptr %l52, !tbaa !21
  br i1 %t112, label %bb27, label %bb28
bb27:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d86, i32 0, i32 1) }, ptr %l53, !tbaa !27
  br label %bb29
bb28:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d87, i32 0, i32 1) }, ptr %l53, !tbaa !27
  br label %bb29
bb29:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load ptr, ptr %lp6
  %t115 = load %"compiler/bindgen:cx", ptr %t114
  %t118 = call %"compiler/bindgen:cx" @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecBool(ptr %v0, ptr %v2, ptr %v2, ptr %t113, %"compiler/bindgen:cx" %t115)
  store %"compiler/bindgen:cx" %t118, ptr %l56
  br label %bb30
bb30:
  %t119 = getelementptr %"compiler/bindgen:cx", ptr %l56, i32 0, i32 0
  %t120 = load { i64, ptr }, ptr %t119, !tbaa !27
  %t121 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d88, i32 0, i32 1) }, 1
  %t122 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d88, i32 0, i32 1) }, 0
  %t123 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t123, 1
  %t125 = extractvalue { i64, ptr } %t123, 0
  %t126 = add i64 %t122, %t125
  %t127 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t127, 1
  %t129 = extractvalue { i64, ptr } %t127, 0
  %t130 = add i64 %t126, %t129
  %t132 = extractvalue { i64, ptr } %t120, 1
  %t133 = extractvalue { i64, ptr } %t120, 0
  %t134 = add i64 %t130, %t133
  %t135 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d89, i32 0, i32 1) }, 1
  %t136 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d89, i32 0, i32 1) }, 0
  %t137 = add i64 %t134, %t136
  %t138 = load i64, ptr %l45
  %t139 = inttoptr i64 %t138 to ptr
  %t140 = call ptr @__olang_held_alloc(ptr %t139, i64 %t137)
  call void @olang_textcopy(ptr %t140, ptr %t121, i64 %t122)
  %t141 = getelementptr i8, ptr %t140, i64 %t122
  call void @olang_textcopy(ptr %t141, ptr %t124, i64 %t125)
  %t142 = getelementptr i8, ptr %t141, i64 %t125
  call void @olang_textcopy(ptr %t142, ptr %t128, i64 %t129)
  %t143 = getelementptr i8, ptr %t142, i64 %t129
  call void @olang_textcopy(ptr %t143, ptr %t132, i64 %t133)
  %t144 = getelementptr i8, ptr %t143, i64 %t133
  call void @olang_textcopy(ptr %t144, ptr %t135, i64 %t136)
  %t145 = insertvalue { i64, ptr } undef, i64 %t137, 0
  %t146 = insertvalue { i64, ptr } %t145, ptr %t140, 1
  %t148 = load i64, ptr @G_2ecompiler_2fbindgen_2eKBool, !tbaa !24
  %t151 = call %"compiler/bindgen:cx" @compiler_2fbindgen_3acx_2ector(ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t146, i64 %t148, i64 -1, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d90, i32 0, i32 1) })
  store %"compiler/bindgen:cx" %t151, ptr %l61
  br label %bb31
bb31:
  %t152 = load ptr, ptr %lp3
  %t153 = load %"compiler/bindgen:cx", ptr %t152
  store %"compiler/bindgen:cx" %t153, ptr %l62
  %t154 = load %"compiler/bindgen:cx", ptr %l61
  %t155 = load ptr, ptr %lp3
  store %"compiler/bindgen:cx" %t154, ptr %t155
  %t156 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3acx_2e0
  br i1 %t156, label %bb32, label %bb33
bb32:
  %t158 = getelementptr %"compiler/bindgen:cx", ptr %l62, i32 0, i32 0
  %t159 = load { i64, ptr }, ptr %t158
  %t160 = extractvalue { i64, ptr } %t159, 1
  call void @__olang_region_release(ptr %t160)
  store { i64, ptr } zeroinitializer, ptr %t158
  br label %bb33
bb33:
  %t161 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3acx_2e3
  br i1 %t161, label %bb34, label %bb35
bb34:
  %t163 = getelementptr %"compiler/bindgen:cx", ptr %l62, i32 0, i32 3
  %t164 = load { i64, ptr }, ptr %t163
  %t165 = extractvalue { i64, ptr } %t164, 1
  call void @__olang_region_release(ptr %t165)
  store { i64, ptr } zeroinitializer, ptr %t163
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s3)
  br label %bb78
bb36:
  store i1 true, ptr %l67, !tbaa !21
  br label %bb38
bb37:
  %t166 = load i64, ptr %l5, !tbaa !24
  %t168 = icmp eq i64 %t166, 7
  store i1 %t168, ptr %l67, !tbaa !21
  br label %bb38
bb38:
  %t170 = load i1, ptr %l67, !tbaa !21
  br i1 %t170, label %bb39, label %bb40
bb39:
  store %olang.scope zeroinitializer, ptr %s6
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load ptr, ptr %lp3
  %t173 = load %"compiler/bindgen:cx", ptr %t172
  %t176 = call %"compiler/bindgen:cx" @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecNum(ptr %v0, ptr %v2, ptr %s6, ptr %t171, %"compiler/bindgen:cx" %t173)
  store %"compiler/bindgen:cx" %t176, ptr %l72
  br label %bb41
bb40:
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t178 = load ptr, ptr %lp3
  %t179 = load %"compiler/bindgen:cx", ptr %t178
  %t182 = call %"compiler/bindgen:cx" @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecNum(ptr %v0, ptr %v2, ptr %v2, ptr %t177, %"compiler/bindgen:cx" %t179)
  store %"compiler/bindgen:cx" %t182, ptr %l90
  br label %bb50
bb41:
  %t183 = load %"compiler/bindgen:cx", ptr %l72
  store %"compiler/bindgen:cx" %t183, ptr %l7
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t185 = load ptr, ptr %lp6
  %t186 = load %"compiler/bindgen:cx", ptr %t185
  %t189 = call %"compiler/bindgen:cx" @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecNum(ptr %v0, ptr %v2, ptr %s6, ptr %t184, %"compiler/bindgen:cx" %t186)
  store %"compiler/bindgen:cx" %t189, ptr %l75
  br label %bb42
bb42:
  %t190 = load %"compiler/bindgen:cx", ptr %l75
  store %"compiler/bindgen:cx" %t190, ptr %l8
  %t191 = call ptr @__olang_scope_hold(ptr %v2)
  %t192 = ptrtoint ptr %t191 to i64
  store i64 %t192, ptr %l76, !tbaa !24
  %t193 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3acx_2e0
  br i1 %t193, label %bb43, label %bb44
bb43:
  %t195 = call ptr @__olang_region_make(ptr %v2)
  %t196 = ptrtoint ptr %t195 to i64
  store i64 %t196, ptr %l76, !tbaa !24
  br label %bb44
bb44:
  %t197 = getelementptr %"compiler/bindgen:cx", ptr %l7, i32 0, i32 0
  %t198 = load { i64, ptr }, ptr %t197, !tbaa !27
  %t199 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t200 = getelementptr %"compiler/bindgen:cx", ptr %l8, i32 0, i32 0
  %t201 = load { i64, ptr }, ptr %t200, !tbaa !27
  %t202 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d91, i32 0, i32 1) }, 1
  %t203 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d91, i32 0, i32 1) }, 0
  %t205 = extractvalue { i64, ptr } %t198, 1
  %t206 = extractvalue { i64, ptr } %t198, 0
  %t207 = add i64 %t203, %t206
  %t208 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d92, i32 0, i32 1) }, 1
  %t209 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d92, i32 0, i32 1) }, 0
  %t210 = add i64 %t207, %t209
  %t212 = extractvalue { i64, ptr } %t199, 1
  %t213 = extractvalue { i64, ptr } %t199, 0
  %t214 = add i64 %t210, %t213
  %t215 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d92, i32 0, i32 1) }, 1
  %t216 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d92, i32 0, i32 1) }, 0
  %t217 = add i64 %t214, %t216
  %t219 = extractvalue { i64, ptr } %t201, 1
  %t220 = extractvalue { i64, ptr } %t201, 0
  %t221 = add i64 %t217, %t220
  %t222 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d93, i32 0, i32 1) }, 1
  %t223 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d93, i32 0, i32 1) }, 0
  %t224 = add i64 %t221, %t223
  %t225 = load i64, ptr %l76
  %t226 = inttoptr i64 %t225 to ptr
  %t227 = call ptr @__olang_held_alloc(ptr %t226, i64 %t224)
  call void @olang_textcopy(ptr %t227, ptr %t202, i64 %t203)
  %t228 = getelementptr i8, ptr %t227, i64 %t203
  call void @olang_textcopy(ptr %t228, ptr %t205, i64 %t206)
  %t229 = getelementptr i8, ptr %t228, i64 %t206
  call void @olang_textcopy(ptr %t229, ptr %t208, i64 %t209)
  %t230 = getelementptr i8, ptr %t229, i64 %t209
  call void @olang_textcopy(ptr %t230, ptr %t212, i64 %t213)
  %t231 = getelementptr i8, ptr %t230, i64 %t213
  call void @olang_textcopy(ptr %t231, ptr %t215, i64 %t216)
  %t232 = getelementptr i8, ptr %t231, i64 %t216
  call void @olang_textcopy(ptr %t232, ptr %t219, i64 %t220)
  %t233 = getelementptr i8, ptr %t232, i64 %t220
  call void @olang_textcopy(ptr %t233, ptr %t222, i64 %t223)
  %t234 = insertvalue { i64, ptr } undef, i64 %t224, 0
  %t235 = insertvalue { i64, ptr } %t234, ptr %t227, 1
  %t237 = load i64, ptr @G_2ecompiler_2fbindgen_2eKBool, !tbaa !24
  %t240 = call %"compiler/bindgen:cx" @compiler_2fbindgen_3acx_2ector(ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t235, i64 %t237, i64 -1, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d94, i32 0, i32 1) })
  store %"compiler/bindgen:cx" %t240, ptr %l84
  br label %bb45
bb45:
  %t241 = load ptr, ptr %lp3
  %t242 = load %"compiler/bindgen:cx", ptr %t241
  store %"compiler/bindgen:cx" %t242, ptr %l85
  %t243 = load %"compiler/bindgen:cx", ptr %l84
  %t244 = load ptr, ptr %lp3
  store %"compiler/bindgen:cx" %t243, ptr %t244
  %t245 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3acx_2e0
  br i1 %t245, label %bb46, label %bb47
bb46:
  %t247 = getelementptr %"compiler/bindgen:cx", ptr %l85, i32 0, i32 0
  %t248 = load { i64, ptr }, ptr %t247
  %t249 = extractvalue { i64, ptr } %t248, 1
  call void @__olang_region_release(ptr %t249)
  store { i64, ptr } zeroinitializer, ptr %t247
  br label %bb47
bb47:
  %t250 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3acx_2e3
  br i1 %t250, label %bb48, label %bb49
bb48:
  %t252 = getelementptr %"compiler/bindgen:cx", ptr %l85, i32 0, i32 3
  %t253 = load { i64, ptr }, ptr %t252
  %t254 = extractvalue { i64, ptr } %t253, 1
  call void @__olang_region_release(ptr %t254)
  store { i64, ptr } zeroinitializer, ptr %t252
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s6)
  br label %bb77
bb50:
  %t255 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store ptr %t255, ptr %lp9
  %t256 = load %"compiler/bindgen:cx", ptr %l90
  %t257 = load ptr, ptr %lp9
  store %"compiler/bindgen:cx" %t256, ptr %t257
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t259 = load ptr, ptr %lp6
  %t260 = load %"compiler/bindgen:cx", ptr %t259
  %t263 = call %"compiler/bindgen:cx" @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecNum(ptr %v0, ptr %v2, ptr %v2, ptr %t258, %"compiler/bindgen:cx" %t260)
  store %"compiler/bindgen:cx" %t263, ptr %l93
  br label %bb51
bb51:
  %t264 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store ptr %t264, ptr %lp10
  %t265 = load %"compiler/bindgen:cx", ptr %l93
  %t266 = load ptr, ptr %lp10
  store %"compiler/bindgen:cx" %t265, ptr %t266
  %t267 = load i64, ptr %l5, !tbaa !24
  %t269 = icmp eq i64 %t267, 8
  br i1 %t269, label %bb52, label %bb53
bb52:
  %t271 = load ptr, ptr %lp9
  %t272 = load %"compiler/bindgen:cx", ptr %t271
  store %"compiler/bindgen:cx" %t272, ptr %l96
  br label %bb55
bb53:
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t275 = load ptr, ptr %lp9
  %t276 = load %"compiler/bindgen:cx", ptr %t275
  %t277 = load ptr, ptr %lp10
  %t278 = load %"compiler/bindgen:cx", ptr %t277
  %t282 = call %"compiler/bindgen:cx" @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecLead(ptr %v0, ptr %v2, ptr %v2, ptr %v2, ptr %t274, %"compiler/bindgen:cx" %t276, %"compiler/bindgen:cx" %t278)
  store %"compiler/bindgen:cx" %t282, ptr %l101
  br label %bb54
bb54:
  %t283 = load %"compiler/bindgen:cx", ptr %l101
  store %"compiler/bindgen:cx" %t283, ptr %l96
  br label %bb55
bb55:
  %t284 = load %"compiler/bindgen:cx", ptr %l96
  store %"compiler/bindgen:cx" %t284, ptr %l11
  %t285 = load i64, ptr %l5, !tbaa !24
  %t287 = icmp eq i64 %t285, 8
  br i1 %t287, label %bb56, label %bb57
bb56:
  %t289 = load ptr, ptr %lp9
  %t290 = getelementptr %"compiler/bindgen:cx", ptr %t289, i32 0, i32 1
  %t291 = load i64, ptr %t290, !tbaa !24
  %t292 = load i64, ptr @G_2ecompiler_2fbindgen_2eKInt, !tbaa !24
  %t295 = icmp eq i64 %t291, %t292
  store i1 %t295, ptr %l104, !tbaa !21
  br label %bb58
bb57:
  store i1 false, ptr %l104, !tbaa !21
  br label %bb58
bb58:
  %t297 = load i1, ptr %l104, !tbaa !21
  br i1 %t297, label %bb59, label %bb60
bb59:
  %t298 = load ptr, ptr %lp10
  %t299 = getelementptr %"compiler/bindgen:cx", ptr %t298, i32 0, i32 1
  %t300 = load i64, ptr %t299, !tbaa !24
  %t301 = load i64, ptr @G_2ecompiler_2fbindgen_2eKInt, !tbaa !24
  %t304 = icmp ne i64 %t300, %t301
  store i1 %t304, ptr %l108, !tbaa !21
  br label %bb61
bb60:
  store i1 false, ptr %l108, !tbaa !21
  br label %bb61
bb61:
  %t306 = load i1, ptr %l108, !tbaa !21
  br i1 %t306, label %bb62, label %bb63
bb62:
  %t307 = load i64, ptr @G_2ecompiler_2fbindgen_2eKInt, !tbaa !24
  %t309 = call %"compiler/bindgen:cx" @compiler_2fbindgen_2ecx_2elit(ptr %v2, ptr %v2, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d95, i32 0, i32 1) }, i64 %t307)
  store %"compiler/bindgen:cx" %t309, ptr %l113
  br label %bb64
bb63:
  br label %bb69
bb64:
  %t310 = load %"compiler/bindgen:cx", ptr %l11
  store %"compiler/bindgen:cx" %t310, ptr %l114
  %t311 = load %"compiler/bindgen:cx", ptr %l113
  store %"compiler/bindgen:cx" %t311, ptr %l11
  %t312 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3acx_2e0
  br i1 %t312, label %bb65, label %bb66
bb65:
  %t314 = getelementptr %"compiler/bindgen:cx", ptr %l114, i32 0, i32 0
  %t315 = load { i64, ptr }, ptr %t314
  %t316 = extractvalue { i64, ptr } %t315, 1
  call void @__olang_region_release(ptr %t316)
  store { i64, ptr } zeroinitializer, ptr %t314
  br label %bb66
bb66:
  %t317 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3acx_2e3
  br i1 %t317, label %bb67, label %bb68
bb67:
  %t319 = getelementptr %"compiler/bindgen:cx", ptr %l114, i32 0, i32 3
  %t320 = load { i64, ptr }, ptr %t319
  %t321 = extractvalue { i64, ptr } %t320, 1
  call void @__olang_region_release(ptr %t321)
  store { i64, ptr } zeroinitializer, ptr %t319
  br label %bb68
bb68:
  br label %bb69
bb69:
  %t322 = call ptr @__olang_scope_hold(ptr %v2)
  %t323 = ptrtoint ptr %t322 to i64
  store i64 %t323, ptr %l117, !tbaa !24
  %t324 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3acx_2e0
  br i1 %t324, label %bb70, label %bb71
bb70:
  %t326 = call ptr @__olang_region_make(ptr %v2)
  %t327 = ptrtoint ptr %t326 to i64
  store i64 %t327, ptr %l117, !tbaa !24
  br label %bb71
bb71:
  %t328 = load ptr, ptr %lp9
  %t329 = getelementptr %"compiler/bindgen:cx", ptr %t328, i32 0, i32 0
  %t330 = load { i64, ptr }, ptr %t329, !tbaa !27
  %t331 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t332 = load ptr, ptr %lp10
  %t333 = getelementptr %"compiler/bindgen:cx", ptr %t332, i32 0, i32 0
  %t334 = load { i64, ptr }, ptr %t333, !tbaa !27
  %t335 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d96, i32 0, i32 1) }, 1
  %t336 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d96, i32 0, i32 1) }, 0
  %t338 = extractvalue { i64, ptr } %t330, 1
  %t339 = extractvalue { i64, ptr } %t330, 0
  %t340 = add i64 %t336, %t339
  %t341 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d97, i32 0, i32 1) }, 1
  %t342 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d97, i32 0, i32 1) }, 0
  %t343 = add i64 %t340, %t342
  %t345 = extractvalue { i64, ptr } %t331, 1
  %t346 = extractvalue { i64, ptr } %t331, 0
  %t347 = add i64 %t343, %t346
  %t348 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d97, i32 0, i32 1) }, 1
  %t349 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d97, i32 0, i32 1) }, 0
  %t350 = add i64 %t347, %t349
  %t352 = extractvalue { i64, ptr } %t334, 1
  %t353 = extractvalue { i64, ptr } %t334, 0
  %t354 = add i64 %t350, %t353
  %t355 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d98, i32 0, i32 1) }, 1
  %t356 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d98, i32 0, i32 1) }, 0
  %t357 = add i64 %t354, %t356
  %t358 = load i64, ptr %l117
  %t359 = inttoptr i64 %t358 to ptr
  %t360 = call ptr @__olang_held_alloc(ptr %t359, i64 %t357)
  call void @olang_textcopy(ptr %t360, ptr %t335, i64 %t336)
  %t361 = getelementptr i8, ptr %t360, i64 %t336
  call void @olang_textcopy(ptr %t361, ptr %t338, i64 %t339)
  %t362 = getelementptr i8, ptr %t361, i64 %t339
  call void @olang_textcopy(ptr %t362, ptr %t341, i64 %t342)
  %t363 = getelementptr i8, ptr %t362, i64 %t342
  call void @olang_textcopy(ptr %t363, ptr %t345, i64 %t346)
  %t364 = getelementptr i8, ptr %t363, i64 %t346
  call void @olang_textcopy(ptr %t364, ptr %t348, i64 %t349)
  %t365 = getelementptr i8, ptr %t364, i64 %t349
  call void @olang_textcopy(ptr %t365, ptr %t352, i64 %t353)
  %t366 = getelementptr i8, ptr %t365, i64 %t353
  call void @olang_textcopy(ptr %t366, ptr %t355, i64 %t356)
  %t367 = insertvalue { i64, ptr } undef, i64 %t357, 0
  %t368 = insertvalue { i64, ptr } %t367, ptr %t360, 1
  %t370 = getelementptr %"compiler/bindgen:cx", ptr %l11, i32 0, i32 1
  %t371 = load i64, ptr %t370, !tbaa !24
  %t372 = getelementptr %"compiler/bindgen:cx", ptr %l11, i32 0, i32 2
  %t373 = load i64, ptr %t372, !tbaa !24
  %t374 = getelementptr %"compiler/bindgen:cx", ptr %l11, i32 0, i32 3
  %t375 = load { i64, ptr }, ptr %t374, !tbaa !27
  %t380 = call %"compiler/bindgen:cx" @compiler_2fbindgen_3acx_2ector(ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t368, i64 %t371, i64 %t373, { i64, ptr } %t375)
  store %"compiler/bindgen:cx" %t380, ptr %l127
  br label %bb72
bb72:
  %t381 = load ptr, ptr %lp3
  %t382 = load %"compiler/bindgen:cx", ptr %t381
  store %"compiler/bindgen:cx" %t382, ptr %l128
  %t383 = load %"compiler/bindgen:cx", ptr %l127
  %t384 = load ptr, ptr %lp3
  store %"compiler/bindgen:cx" %t383, ptr %t384
  %t385 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3acx_2e0
  br i1 %t385, label %bb73, label %bb74
bb73:
  %t387 = getelementptr %"compiler/bindgen:cx", ptr %l128, i32 0, i32 0
  %t388 = load { i64, ptr }, ptr %t387
  %t389 = extractvalue { i64, ptr } %t388, 1
  call void @__olang_region_release(ptr %t389)
  store { i64, ptr } zeroinitializer, ptr %t387
  br label %bb74
bb74:
  %t390 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3acx_2e3
  br i1 %t390, label %bb75, label %bb76
bb75:
  %t392 = getelementptr %"compiler/bindgen:cx", ptr %l128, i32 0, i32 3
  %t393 = load { i64, ptr }, ptr %t392
  %t394 = extractvalue { i64, ptr } %t393, 1
  call void @__olang_region_release(ptr %t394)
  store { i64, ptr } zeroinitializer, ptr %t392
  br label %bb76
bb76:
  br label %bb77
bb77:
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s1)
  br label %bb79
bb79:
  br label %bb4
bb80:
  %t395 = load ptr, ptr %lp3
  %t396 = load %"compiler/bindgen:cx", ptr %t395
  %t398 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, %"compiler/bindgen:cx" %t396, 1
  store { i32, %"compiler/bindgen:cx" } %t398, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/bindgen:cx" }, ptr %rv
  ret { i32, %"compiler/bindgen:cx" } %rr
}

define dso_local { i32, %"compiler/bindgen:cx" } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecExpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/bindgen:cx"
  %lp3 = alloca ptr
  %lp4 = alloca ptr
  %lp5 = alloca ptr
  %lp6 = alloca ptr
  %lp7 = alloca ptr
  %l8 = alloca %"compiler/bindgen:cx"
  %l11 = alloca %"compiler/bindgen:cx"
  %l12 = alloca i32
  %l15 = alloca { i64, ptr }
  %l17 = alloca i1
  %l20 = alloca ptr
  %l24 = alloca %"compiler/bindgen:cx"
  %l27 = alloca %"compiler/bindgen:cx"
  %l28 = alloca i32
  %l31 = alloca { i64, ptr }
  %l33 = alloca i1
  %l36 = alloca i32
  %l38 = alloca ptr
  %l42 = alloca %"compiler/bindgen:cx"
  %l45 = alloca %"compiler/bindgen:cx"
  %l46 = alloca i32
  %l51 = alloca i1
  %l55 = alloca i64
  %l57 = alloca { i64, ptr }
  %l60 = alloca %"compiler/bindgen:cx"
  %l66 = alloca %"compiler/bindgen:cx"
  %l69 = alloca %"compiler/bindgen:cx"
  %l72 = alloca %"compiler/bindgen:cx"
  %l76 = alloca %"compiler/bindgen:cx"
  %l77 = alloca i64
  %l79 = alloca { i64, ptr }
  %l82 = alloca %"compiler/bindgen:cx"
  %l90 = alloca %"compiler/bindgen:cx"
  %s0 = alloca %olang.scope
  %rv = alloca { i32, %"compiler/bindgen:cx" }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call { i32, %"compiler/bindgen:cx" } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecBinary(ptr %v0, ptr %v1, ptr %v2, ptr %t1, ptr %t2, i64 1)
  %t6 = extractvalue { i32, %"compiler/bindgen:cx" } %t5, 1
  %t7 = extractvalue { i32, %"compiler/bindgen:cx" } %t5, 0
  store i32 %t7, ptr %l12
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9, !prof !99
ok.9:
  store %"compiler/bindgen:cx" %t6, ptr %l11
  br label %bb1
bb1:
  %t10 = load %"compiler/bindgen:cx", ptr %l11
  store %"compiler/bindgen:cx" %t10, ptr %l8
  br label %bb3
bb2:
  %t11 = load i32, ptr %l12, !tbaa !23
  %t12 = lshr i32 %t11, 16
  %t13 = and i32 %t11, 65535
  %t14 = icmp eq i32 %t12, 1
  %t15 = select i1 %t14, i32 1, i32 0
  %t16 = icmp eq i32 %t11, 0
  %t17 = shl i32 %t15, 16
  %t18 = or i32 %t17, %t13
  %t19 = select i1 %t16, i32 0, i32 %t18
  call void @__olang_scope_close(ptr %s0)
  %t21 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, i32 %t19, 0
  store { i32, %"compiler/bindgen:cx" } %t21, ptr %rv
  br label %ret
bb3:
  %t22 = load %"compiler/bindgen:cx", ptr %l8
  store %"compiler/bindgen:cx" %t22, ptr %l2
  %t23 = load ptr, ptr %l1, !tbaa !29
  %t25 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3acparse_2eat(ptr %v1, ptr %s0, ptr %t23)
  store { i64, ptr } %t25, ptr %l15
  br label %bb4
bb4:
  %t26 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t28 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t26, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d99, i32 0, i32 1) })
  store i1 %t28, ptr %l17
  br label %bb5
bb5:
  %t29 = load i1, ptr %l17, !tbaa !21
  %t30 = xor i1 %t29, true
  br i1 %t30, label %bb6, label %bb7
bb6:
  %t32 = load %"compiler/bindgen:cx", ptr %l2
  call void @__olang_scope_close(ptr %s0)
  %t34 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, %"compiler/bindgen:cx" %t32, 1
  store { i32, %"compiler/bindgen:cx" } %t34, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t35 = load ptr, ptr %l1, !tbaa !29
  store ptr %t35, ptr %l20, !tbaa !29
  %t36 = load ptr, ptr %l20, !tbaa !29
  %t37 = getelementptr %"compiler/bindgen:cparse", ptr %t36, i32 0, i32 2
  %t38 = load i64, ptr %t37, !tbaa !24
  %t41 = add i64 %t38, 1
  %t43 = load ptr, ptr %l20, !tbaa !29
  %t44 = getelementptr %"compiler/bindgen:cparse", ptr %t43, i32 0, i32 2
  store i64 %t41, ptr %t44, !tbaa !24
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load ptr, ptr %l1, !tbaa !29
  %t49 = call { i32, %"compiler/bindgen:cx" } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t45, ptr %t46)
  %t50 = extractvalue { i32, %"compiler/bindgen:cx" } %t49, 1
  %t51 = extractvalue { i32, %"compiler/bindgen:cx" } %t49, 0
  store i32 %t51, ptr %l28
  %t52 = icmp ne i32 %t51, 0
  br i1 %t52, label %bb10, label %ok.53, !prof !99
ok.53:
  store %"compiler/bindgen:cx" %t50, ptr %l27
  br label %bb9
bb9:
  %t54 = load %"compiler/bindgen:cx", ptr %l27
  store %"compiler/bindgen:cx" %t54, ptr %l24
  br label %bb11
bb10:
  %t55 = load i32, ptr %l28, !tbaa !23
  %t56 = lshr i32 %t55, 16
  %t57 = and i32 %t55, 65535
  %t58 = icmp eq i32 %t56, 1
  %t59 = select i1 %t58, i32 1, i32 0
  %t60 = icmp eq i32 %t55, 0
  %t61 = shl i32 %t59, 16
  %t62 = or i32 %t61, %t57
  %t63 = select i1 %t60, i32 0, i32 %t62
  call void @__olang_scope_close(ptr %s0)
  %t65 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, i32 %t63, 0
  store { i32, %"compiler/bindgen:cx" } %t65, ptr %rv
  br label %ret
bb11:
  %t66 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store ptr %t66, ptr %lp3
  %t67 = load %"compiler/bindgen:cx", ptr %l24
  %t68 = load ptr, ptr %lp3
  store %"compiler/bindgen:cx" %t67, ptr %t68
  %t69 = load ptr, ptr %l1, !tbaa !29
  %t71 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3acparse_2eat(ptr %v1, ptr %s0, ptr %t69)
  store { i64, ptr } %t71, ptr %l31
  br label %bb12
bb12:
  %t72 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t74 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t72, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d100, i32 0, i32 1) })
  store i1 %t74, ptr %l33
  br label %bb13
bb13:
  %t75 = load i1, ptr %l33, !tbaa !21
  %t76 = xor i1 %t75, true
  br i1 %t76, label %bb14, label %bb15
bb14:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %v0, ptr %t78, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d101, i32 0, i32 1) })
  store i32 %t80, ptr %l36
  %t81 = icmp ne i32 %t80, 0
  br i1 %t81, label %bb17, label %ok.82, !prof !99
ok.82:
  br label %bb16
bb15:
  br label %bb19
bb16:
  br label %bb18
bb17:
  %t83 = load i32, ptr %l36, !tbaa !23
  %t84 = lshr i32 %t83, 16
  %t85 = and i32 %t83, 65535
  %t86 = icmp eq i32 %t84, 1
  %t87 = select i1 %t86, i32 1, i32 0
  %t88 = icmp eq i32 %t83, 0
  %t89 = shl i32 %t87, 16
  %t90 = or i32 %t89, %t85
  %t91 = select i1 %t88, i32 0, i32 %t90
  call void @__olang_scope_close(ptr %s0)
  %t93 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, i32 %t91, 0
  store { i32, %"compiler/bindgen:cx" } %t93, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t94 = load ptr, ptr %l1, !tbaa !29
  store ptr %t94, ptr %l38, !tbaa !29
  %t95 = load ptr, ptr %l38, !tbaa !29
  %t96 = getelementptr %"compiler/bindgen:cparse", ptr %t95, i32 0, i32 2
  %t97 = load i64, ptr %t96, !tbaa !24
  %t100 = add i64 %t97, 1
  %t102 = load ptr, ptr %l38, !tbaa !29
  %t103 = getelementptr %"compiler/bindgen:cparse", ptr %t102, i32 0, i32 2
  store i64 %t100, ptr %t103, !tbaa !24
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load ptr, ptr %l1, !tbaa !29
  %t108 = call { i32, %"compiler/bindgen:cx" } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t104, ptr %t105)
  %t109 = extractvalue { i32, %"compiler/bindgen:cx" } %t108, 1
  %t110 = extractvalue { i32, %"compiler/bindgen:cx" } %t108, 0
  store i32 %t110, ptr %l46
  %t111 = icmp ne i32 %t110, 0
  br i1 %t111, label %bb21, label %ok.112, !prof !99
ok.112:
  store %"compiler/bindgen:cx" %t109, ptr %l45
  br label %bb20
bb20:
  %t113 = load %"compiler/bindgen:cx", ptr %l45
  store %"compiler/bindgen:cx" %t113, ptr %l42
  br label %bb22
bb21:
  %t114 = load i32, ptr %l46, !tbaa !23
  %t115 = lshr i32 %t114, 16
  %t116 = and i32 %t114, 65535
  %t117 = icmp eq i32 %t115, 1
  %t118 = select i1 %t117, i32 1, i32 0
  %t119 = icmp eq i32 %t114, 0
  %t120 = shl i32 %t118, 16
  %t121 = or i32 %t120, %t116
  %t122 = select i1 %t119, i32 0, i32 %t121
  call void @__olang_scope_close(ptr %s0)
  %t124 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, i32 %t122, 0
  store { i32, %"compiler/bindgen:cx" } %t124, ptr %rv
  br label %ret
bb22:
  %t125 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store ptr %t125, ptr %lp4
  %t126 = load %"compiler/bindgen:cx", ptr %l42
  %t127 = load ptr, ptr %lp4
  store %"compiler/bindgen:cx" %t126, ptr %t127
  %t128 = load ptr, ptr %lp3
  %t129 = getelementptr %"compiler/bindgen:cx", ptr %t128, i32 0, i32 1
  %t130 = load i64, ptr %t129, !tbaa !24
  %t131 = load i64, ptr @G_2ecompiler_2fbindgen_2eKBool, !tbaa !24
  %t134 = icmp eq i64 %t130, %t131
  br i1 %t134, label %bb23, label %bb24
bb23:
  %t136 = load ptr, ptr %lp4
  %t137 = getelementptr %"compiler/bindgen:cx", ptr %t136, i32 0, i32 1
  %t138 = load i64, ptr %t137, !tbaa !24
  %t139 = load i64, ptr @G_2ecompiler_2fbindgen_2eKBool, !tbaa !24
  %t142 = icmp eq i64 %t138, %t139
  store i1 %t142, ptr %l51, !tbaa !21
  br label %bb25
bb24:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb25
bb25:
  %t144 = load i1, ptr %l51, !tbaa !21
  br i1 %t144, label %bb26, label %bb27
bb26:
  %t145 = call ptr @__olang_scope_hold(ptr %v2)
  %t146 = ptrtoint ptr %t145 to i64
  store i64 %t146, ptr %l55, !tbaa !24
  %t147 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3acx_2e0
  br i1 %t147, label %bb28, label %bb29
bb27:
  br label %bb32
bb28:
  %t149 = call ptr @__olang_region_make(ptr %v2)
  %t150 = ptrtoint ptr %t149 to i64
  store i64 %t150, ptr %l55, !tbaa !24
  br label %bb29
bb29:
  %t151 = load ptr, ptr %lp3
  %t152 = getelementptr %"compiler/bindgen:cx", ptr %t151, i32 0, i32 0
  %t153 = load { i64, ptr }, ptr %t152, !tbaa !27
  store { i64, ptr } %t153, ptr %l57, !tbaa !27
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t155 = load %"compiler/bindgen:cx", ptr %l2
  %t158 = call %"compiler/bindgen:cx" @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecBool(ptr %v0, ptr %v2, ptr %v2, ptr %t154, %"compiler/bindgen:cx" %t155)
  store %"compiler/bindgen:cx" %t158, ptr %l60
  br label %bb30
bb30:
  %t159 = getelementptr %"compiler/bindgen:cx", ptr %l60, i32 0, i32 0
  %t160 = load { i64, ptr }, ptr %t159, !tbaa !27
  %t161 = load ptr, ptr %lp4
  %t162 = getelementptr %"compiler/bindgen:cx", ptr %t161, i32 0, i32 0
  %t163 = load { i64, ptr }, ptr %t162, !tbaa !27
  %t164 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d102, i32 0, i32 1) }, 1
  %t165 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d102, i32 0, i32 1) }, 0
  %t166 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t167 = extractvalue { i64, ptr } %t166, 1
  %t168 = extractvalue { i64, ptr } %t166, 0
  %t169 = add i64 %t165, %t168
  %t170 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d103, i32 0, i32 1) }, 1
  %t171 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d103, i32 0, i32 1) }, 0
  %t172 = add i64 %t169, %t171
  %t174 = extractvalue { i64, ptr } %t160, 1
  %t175 = extractvalue { i64, ptr } %t160, 0
  %t176 = add i64 %t172, %t175
  %t177 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d104, i32 0, i32 1) }, 1
  %t178 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d104, i32 0, i32 1) }, 0
  %t179 = add i64 %t176, %t178
  %t181 = extractvalue { i64, ptr } %t163, 1
  %t182 = extractvalue { i64, ptr } %t163, 0
  %t183 = add i64 %t179, %t182
  %t184 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d105, i32 0, i32 1) }, 1
  %t185 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d105, i32 0, i32 1) }, 0
  %t186 = add i64 %t183, %t185
  %t187 = load i64, ptr %l55
  %t188 = inttoptr i64 %t187 to ptr
  %t189 = call ptr @__olang_held_alloc(ptr %t188, i64 %t186)
  call void @olang_textcopy(ptr %t189, ptr %t164, i64 %t165)
  %t190 = getelementptr i8, ptr %t189, i64 %t165
  call void @olang_textcopy(ptr %t190, ptr %t167, i64 %t168)
  %t191 = getelementptr i8, ptr %t190, i64 %t168
  call void @olang_textcopy(ptr %t191, ptr %t170, i64 %t171)
  %t192 = getelementptr i8, ptr %t191, i64 %t171
  call void @olang_textcopy(ptr %t192, ptr %t174, i64 %t175)
  %t193 = getelementptr i8, ptr %t192, i64 %t175
  call void @olang_textcopy(ptr %t193, ptr %t177, i64 %t178)
  %t194 = getelementptr i8, ptr %t193, i64 %t178
  call void @olang_textcopy(ptr %t194, ptr %t181, i64 %t182)
  %t195 = getelementptr i8, ptr %t194, i64 %t182
  call void @olang_textcopy(ptr %t195, ptr %t184, i64 %t185)
  %t196 = insertvalue { i64, ptr } undef, i64 %t186, 0
  %t197 = insertvalue { i64, ptr } %t196, ptr %t189, 1
  %t199 = load i64, ptr @G_2ecompiler_2fbindgen_2eKBool, !tbaa !24
  %t202 = call %"compiler/bindgen:cx" @compiler_2fbindgen_3acx_2ector(ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t197, i64 %t199, i64 -1, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d106, i32 0, i32 1) })
  store %"compiler/bindgen:cx" %t202, ptr %l66
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s0)
  %t203 = load %"compiler/bindgen:cx", ptr %l66
  %t204 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, %"compiler/bindgen:cx" %t203, 1
  store { i32, %"compiler/bindgen:cx" } %t204, ptr %rv
  br label %ret
bb32:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t206 = load ptr, ptr %lp3
  %t207 = load %"compiler/bindgen:cx", ptr %t206
  %t210 = call %"compiler/bindgen:cx" @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecNum(ptr %v0, ptr %v2, ptr %v2, ptr %t205, %"compiler/bindgen:cx" %t207)
  store %"compiler/bindgen:cx" %t210, ptr %l69
  br label %bb33
bb33:
  %t211 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store ptr %t211, ptr %lp5
  %t212 = load %"compiler/bindgen:cx", ptr %l69
  %t213 = load ptr, ptr %lp5
  store %"compiler/bindgen:cx" %t212, ptr %t213
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t215 = load ptr, ptr %lp4
  %t216 = load %"compiler/bindgen:cx", ptr %t215
  %t219 = call %"compiler/bindgen:cx" @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecNum(ptr %v0, ptr %v2, ptr %v2, ptr %t214, %"compiler/bindgen:cx" %t216)
  store %"compiler/bindgen:cx" %t219, ptr %l72
  br label %bb34
bb34:
  %t220 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store ptr %t220, ptr %lp6
  %t221 = load %"compiler/bindgen:cx", ptr %l72
  %t222 = load ptr, ptr %lp6
  store %"compiler/bindgen:cx" %t221, ptr %t222
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t224 = load ptr, ptr %lp5
  %t225 = load %"compiler/bindgen:cx", ptr %t224
  %t226 = load ptr, ptr %lp6
  %t227 = load %"compiler/bindgen:cx", ptr %t226
  %t231 = call %"compiler/bindgen:cx" @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecLead(ptr %v0, ptr %v2, ptr %v2, ptr %v2, ptr %t223, %"compiler/bindgen:cx" %t225, %"compiler/bindgen:cx" %t227)
  store %"compiler/bindgen:cx" %t231, ptr %l76
  br label %bb35
bb35:
  %t232 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store ptr %t232, ptr %lp7
  %t233 = load %"compiler/bindgen:cx", ptr %l76
  %t234 = load ptr, ptr %lp7
  store %"compiler/bindgen:cx" %t233, ptr %t234
  %t235 = call ptr @__olang_scope_hold(ptr %v2)
  %t236 = ptrtoint ptr %t235 to i64
  store i64 %t236, ptr %l77, !tbaa !24
  %t237 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3acx_2e0
  br i1 %t237, label %bb36, label %bb37
bb36:
  %t239 = call ptr @__olang_region_make(ptr %v2)
  %t240 = ptrtoint ptr %t239 to i64
  store i64 %t240, ptr %l77, !tbaa !24
  br label %bb37
bb37:
  %t241 = load ptr, ptr %lp5
  %t242 = getelementptr %"compiler/bindgen:cx", ptr %t241, i32 0, i32 0
  %t243 = load { i64, ptr }, ptr %t242, !tbaa !27
  store { i64, ptr } %t243, ptr %l79, !tbaa !27
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t245 = load %"compiler/bindgen:cx", ptr %l2
  %t248 = call %"compiler/bindgen:cx" @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecBool(ptr %v0, ptr %v2, ptr %v2, ptr %t244, %"compiler/bindgen:cx" %t245)
  store %"compiler/bindgen:cx" %t248, ptr %l82
  br label %bb38
bb38:
  %t249 = getelementptr %"compiler/bindgen:cx", ptr %l82, i32 0, i32 0
  %t250 = load { i64, ptr }, ptr %t249, !tbaa !27
  %t251 = load ptr, ptr %lp6
  %t252 = getelementptr %"compiler/bindgen:cx", ptr %t251, i32 0, i32 0
  %t253 = load { i64, ptr }, ptr %t252, !tbaa !27
  %t254 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d107, i32 0, i32 1) }, 1
  %t255 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d107, i32 0, i32 1) }, 0
  %t256 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t257 = extractvalue { i64, ptr } %t256, 1
  %t258 = extractvalue { i64, ptr } %t256, 0
  %t259 = add i64 %t255, %t258
  %t260 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d108, i32 0, i32 1) }, 1
  %t261 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d108, i32 0, i32 1) }, 0
  %t262 = add i64 %t259, %t261
  %t264 = extractvalue { i64, ptr } %t250, 1
  %t265 = extractvalue { i64, ptr } %t250, 0
  %t266 = add i64 %t262, %t265
  %t267 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d109, i32 0, i32 1) }, 1
  %t268 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d109, i32 0, i32 1) }, 0
  %t269 = add i64 %t266, %t268
  %t271 = extractvalue { i64, ptr } %t253, 1
  %t272 = extractvalue { i64, ptr } %t253, 0
  %t273 = add i64 %t269, %t272
  %t274 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d110, i32 0, i32 1) }, 1
  %t275 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d110, i32 0, i32 1) }, 0
  %t276 = add i64 %t273, %t275
  %t277 = load i64, ptr %l77
  %t278 = inttoptr i64 %t277 to ptr
  %t279 = call ptr @__olang_held_alloc(ptr %t278, i64 %t276)
  call void @olang_textcopy(ptr %t279, ptr %t254, i64 %t255)
  %t280 = getelementptr i8, ptr %t279, i64 %t255
  call void @olang_textcopy(ptr %t280, ptr %t257, i64 %t258)
  %t281 = getelementptr i8, ptr %t280, i64 %t258
  call void @olang_textcopy(ptr %t281, ptr %t260, i64 %t261)
  %t282 = getelementptr i8, ptr %t281, i64 %t261
  call void @olang_textcopy(ptr %t282, ptr %t264, i64 %t265)
  %t283 = getelementptr i8, ptr %t282, i64 %t265
  call void @olang_textcopy(ptr %t283, ptr %t267, i64 %t268)
  %t284 = getelementptr i8, ptr %t283, i64 %t268
  call void @olang_textcopy(ptr %t284, ptr %t271, i64 %t272)
  %t285 = getelementptr i8, ptr %t284, i64 %t272
  call void @olang_textcopy(ptr %t285, ptr %t274, i64 %t275)
  %t286 = insertvalue { i64, ptr } undef, i64 %t276, 0
  %t287 = insertvalue { i64, ptr } %t286, ptr %t279, 1
  %t289 = load ptr, ptr %lp7
  %t290 = getelementptr %"compiler/bindgen:cx", ptr %t289, i32 0, i32 1
  %t291 = load i64, ptr %t290, !tbaa !24
  %t292 = load ptr, ptr %lp7
  %t293 = getelementptr %"compiler/bindgen:cx", ptr %t292, i32 0, i32 2
  %t294 = load i64, ptr %t293, !tbaa !24
  %t295 = load ptr, ptr %lp7
  %t296 = getelementptr %"compiler/bindgen:cx", ptr %t295, i32 0, i32 3
  %t297 = load { i64, ptr }, ptr %t296, !tbaa !27
  %t302 = call %"compiler/bindgen:cx" @compiler_2fbindgen_3acx_2ector(ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t287, i64 %t291, i64 %t294, { i64, ptr } %t297)
  store %"compiler/bindgen:cx" %t302, ptr %l90
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s0)
  %t303 = load %"compiler/bindgen:cx", ptr %l90
  %t304 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, %"compiler/bindgen:cx" %t303, 1
  store { i32, %"compiler/bindgen:cx" } %t304, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/bindgen:cx" }, ptr %rv
  ret { i32, %"compiler/bindgen:cx" } %rr
}

define dso_local { i32, %"compiler/bindgen:cx" } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecNumber(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %lp2 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca i1
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"std/prelude/text:StringBuilder"
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca { i64, ptr }
  %l13 = alloca i1
  %l16 = alloca i1
  %l18 = alloca { i64, ptr }
  %l19 = alloca i1
  %l20 = alloca i1
  %l22 = alloca { i64, ptr }
  %l23 = alloca i1
  %l25 = alloca i1
  %l27 = alloca { i64, ptr }
  %l28 = alloca i1
  %l30 = alloca i32
  %l36 = alloca i1
  %l41 = alloca i1
  %l46 = alloca i1
  %l48 = alloca i1
  %l58 = alloca i1
  %l63 = alloca i1
  %l68 = alloca i32
  %l70 = alloca i64
  %l71 = alloca i64
  %l77 = alloca %"std/prelude/text:StringBuilder"
  %l79 = alloca i1
  %l81 = alloca i64
  %l84 = alloca i64
  %l85 = alloca i32
  %l88 = alloca ptr
  %l89 = alloca { i64, ptr }
  %l90 = alloca i64
  %l91 = alloca i64
  %l96 = alloca { i64, ptr }
  %l97 = alloca i64
  %l98 = alloca i64
  %l104 = alloca { i64, ptr }
  %l105 = alloca i1
  %l108 = alloca { i64, ptr }
  %l114 = alloca ptr
  %l115 = alloca { i64, ptr }
  %l116 = alloca i64
  %l119 = alloca i64
  %l120 = alloca i64
  %l125 = alloca i64
  %l128 = alloca { i64, ptr }
  %l131 = alloca %"compiler/bindgen:cx"
  %l133 = alloca i1
  %l135 = alloca i1
  %l136 = alloca i1
  %l138 = alloca i1
  %l139 = alloca i1
  %l141 = alloca i1
  %l145 = alloca %"compiler/bindgen:cx"
  %l146 = alloca i64
  %l147 = alloca { i64, ptr }
  %l150 = alloca i64
  %l151 = alloca i64
  %l155 = alloca { i64, ptr }
  %l156 = alloca i64
  %l157 = alloca i32
  %l158 = alloca i64
  %l159 = alloca i32
  %l160 = alloca ptr
  %l161 = alloca i64
  %l166 = alloca i32
  %l168 = alloca i64
  %l174 = alloca %"compiler/bindgen:cx"
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i32, %"compiler/bindgen:cx" }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eToLower(ptr %v1, ptr %v2, { i64, ptr } %t1)
  store { i64, ptr } %t3, ptr %l11
  br label %bb1
bb1:
  %t4 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t4, ptr %lp2
  %t5 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t6 = load ptr, ptr %lp2
  store { i64, ptr } %t5, ptr %t6, !tbaa !27
  %t7 = load ptr, ptr %lp2
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  %t10 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v2, ptr %s0, { i64, ptr } %t8, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d111, i32 0, i32 1) })
  store i1 %t10, ptr %l13
  br label %bb2
bb2:
  %t11 = load i1, ptr %l13, !tbaa !21
  store i1 %t11, ptr %l3, !tbaa !21
  %t12 = load i1, ptr %l3, !tbaa !21
  %t14 = xor i1 %t12, true
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t16 = load ptr, ptr %lp2
  %t17 = load { i64, ptr }, ptr %t16, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d112, i32 0, i32 1) }, ptr %l18, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t20 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v2, ptr %s0, { i64, ptr } %t17, { i64, ptr } %t19)
  store i1 %t20, ptr %l19
  br label %bb5
bb4:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb10
bb5:
  %t21 = load i1, ptr %l19, !tbaa !21
  br i1 %t21, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb9
bb7:
  %t22 = load ptr, ptr %lp2
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d113, i32 0, i32 1) }, ptr %l22, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t26 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v2, ptr %s0, { i64, ptr } %t23, { i64, ptr } %t25)
  store i1 %t26, ptr %l23
  br label %bb8
bb8:
  %t27 = load i1, ptr %l23, !tbaa !21
  store i1 %t27, ptr %l20, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l20, !tbaa !21
  store i1 %t28, ptr %l16, !tbaa !21
  br label %bb10
bb10:
  %t29 = load i1, ptr %l16, !tbaa !21
  store i1 %t29, ptr %l4, !tbaa !21
  %t30 = load i1, ptr %l3, !tbaa !21
  br i1 %t30, label %bb11, label %bb12
bb11:
  %t32 = load ptr, ptr %lp2
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d114, i32 0, i32 1) }, ptr %l27, !tbaa !27
  %t35 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t36 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v2, ptr %s0, { i64, ptr } %t33, { i64, ptr } %t35)
  store i1 %t36, ptr %l28
  br label %bb13
bb12:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb14
bb13:
  %t37 = load i1, ptr %l28, !tbaa !21
  store i1 %t37, ptr %l25, !tbaa !21
  br label %bb14
bb14:
  %t38 = load i1, ptr %l25, !tbaa !21
  br i1 %t38, label %bb15, label %bb16
bb15:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %v0, ptr %t39, { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d115, i32 0, i32 1) })
  store i32 %t41, ptr %l30
  %t42 = icmp ne i32 %t41, 0
  br i1 %t42, label %bb18, label %ok.43, !prof !99
ok.43:
  br label %bb17
bb16:
  br label %bb20
bb17:
  br label %bb19
bb18:
  %t44 = load i32, ptr %l30, !tbaa !23
  %t45 = lshr i32 %t44, 16
  %t46 = and i32 %t44, 65535
  %t47 = icmp eq i32 %t45, 1
  %t48 = select i1 %t47, i32 1, i32 0
  %t49 = icmp eq i32 %t44, 0
  %t50 = shl i32 %t48, 16
  %t51 = or i32 %t50, %t46
  %t52 = select i1 %t49, i32 0, i32 %t51
  call void @__olang_scope_close(ptr %s0)
  %t54 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, i32 %t52, 0
  store { i32, %"compiler/bindgen:cx" } %t54, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t55 = load ptr, ptr %lp2
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t56, 0
  store i64 %t58, ptr %l5, !tbaa !24
  br label %bb21
bb21:
  %t60 = load i64, ptr %l5, !tbaa !24
  %t62 = icmp sgt i64 %t60, 0
  br i1 %t62, label %bb22, label %bb23
bb22:
  %t64 = load i64, ptr %l5, !tbaa !24
  %t66 = sub i64 %t64, 1
  %t67 = load ptr, ptr %lp2
  %t69 = getelementptr { i64, ptr }, ptr %t67, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr i8, ptr %t70, i64 %t66
  %t72 = load i8, ptr %t71, !tbaa !32
  %t74 = icmp eq i8 %t72, 117
  br i1 %t74, label %bb24, label %bb25
bb23:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb33
bb24:
  store i1 true, ptr %l41, !tbaa !21
  br label %bb26
bb25:
  %t76 = load i64, ptr %l5, !tbaa !24
  %t78 = sub i64 %t76, 1
  %t79 = load ptr, ptr %lp2
  %t81 = getelementptr { i64, ptr }, ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr i8, ptr %t82, i64 %t78
  %t84 = load i8, ptr %t83, !tbaa !32
  %t86 = icmp eq i8 %t84, 108
  store i1 %t86, ptr %l41, !tbaa !21
  br label %bb26
bb26:
  %t88 = load i1, ptr %l41, !tbaa !21
  br i1 %t88, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb32
bb28:
  %t89 = load i1, ptr %l4, !tbaa !21
  br i1 %t89, label %bb29, label %bb30
bb29:
  %t91 = load i64, ptr %l5, !tbaa !24
  %t93 = sub i64 %t91, 1
  %t94 = load ptr, ptr %lp2
  %t96 = getelementptr { i64, ptr }, ptr %t94, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = getelementptr i8, ptr %t97, i64 %t93
  %t99 = load i8, ptr %t98, !tbaa !32
  %t101 = icmp eq i8 %t99, 102
  store i1 %t101, ptr %l48, !tbaa !21
  br label %bb31
bb30:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb31
bb31:
  %t103 = load i1, ptr %l48, !tbaa !21
  store i1 %t103, ptr %l46, !tbaa !21
  br label %bb32
bb32:
  %t104 = load i1, ptr %l46, !tbaa !21
  store i1 %t104, ptr %l36, !tbaa !21
  br label %bb33
bb33:
  %t105 = load i1, ptr %l36, !tbaa !21
  %t106 = xor i1 %t105, true
  br i1 %t106, label %bb34, label %bb35
bb34:
  br label %bb38
bb35:
  br label %bb36
bb36:
  %t108 = load i64, ptr %l5, !tbaa !24
  %t111 = sub i64 %t108, 1
  store i64 %t111, ptr %l5, !tbaa !24
  br label %bb37
bb37:
  br label %bb21
bb38:
  %t113 = load i1, ptr %l4, !tbaa !21
  br i1 %t113, label %bb39, label %bb40
bb39:
  %t115 = load i64, ptr %l5, !tbaa !24
  %t116 = load ptr, ptr %lp2
  %t117 = load { i64, ptr }, ptr %t116, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t117, 0
  %t122 = icmp slt i64 %t115, %t119
  store i1 %t122, ptr %l58, !tbaa !21
  br label %bb41
bb40:
  store i1 false, ptr %l58, !tbaa !21
  br label %bb41
bb41:
  %t124 = load i1, ptr %l58, !tbaa !21
  br i1 %t124, label %bb42, label %bb43
bb42:
  %t125 = load i64, ptr %l5, !tbaa !24
  %t126 = load ptr, ptr %lp2
  %t128 = getelementptr { i64, ptr }, ptr %t126, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = getelementptr i8, ptr %t129, i64 %t125
  %t131 = load i8, ptr %t130, !tbaa !32
  %t133 = icmp eq i8 %t131, 108
  store i1 %t133, ptr %l63, !tbaa !21
  br label %bb44
bb43:
  store i1 false, ptr %l63, !tbaa !21
  br label %bb44
bb44:
  %t135 = load i1, ptr %l63, !tbaa !21
  br i1 %t135, label %bb45, label %bb46
bb45:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %v0, ptr %t136, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d116, i32 0, i32 1) })
  store i32 %t138, ptr %l68
  %t139 = icmp ne i32 %t138, 0
  br i1 %t139, label %bb48, label %ok.140, !prof !99
ok.140:
  br label %bb47
bb46:
  br label %bb50
bb47:
  br label %bb49
bb48:
  %t141 = load i32, ptr %l68, !tbaa !23
  %t142 = lshr i32 %t141, 16
  %t143 = and i32 %t141, 65535
  %t144 = icmp eq i32 %t142, 1
  %t145 = select i1 %t144, i32 1, i32 0
  %t146 = icmp eq i32 %t141, 0
  %t147 = shl i32 %t145, 16
  %t148 = or i32 %t147, %t143
  %t149 = select i1 %t146, i32 0, i32 %t148
  call void @__olang_scope_close(ptr %s0)
  %t151 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, i32 %t149, 0
  store { i32, %"compiler/bindgen:cx" } %t151, ptr %rv
  br label %ret
bb49:
  br label %bb50
bb50:
  %t152 = load i64, ptr %l5, !tbaa !24
  store i64 %t152, ptr %l70, !tbaa !24
  %t153 = load ptr, ptr %lp2
  %t154 = load { i64, ptr }, ptr %t153, !tbaa !27
  %t155 = extractvalue { i64, ptr } %t154, 0
  store i64 %t155, ptr %l71, !tbaa !24
  %t156 = icmp sge i64 0, 0
  br i1 %t156, label %bb51, label %bb52
bb51:
  %t158 = load i64, ptr %l70, !tbaa !24
  %t159 = icmp sle i64 0, %t158
  br i1 %t159, label %bb53, label %bb54
bb52:
  call void @__olang_check_failed(ptr @olang_loc_2281448cce404233_754aa41ddbc9325f)
  unreachable
bb53:
  %t161 = load i64, ptr %l70, !tbaa !24
  %t162 = load i64, ptr %l71, !tbaa !24
  %t163 = icmp sle i64 %t161, %t162
  br i1 %t163, label %bb55, label %bb56
bb54:
  call void @__olang_check_failed(ptr @olang_loc_2281448cce404233_754aa41ddbc9325f)
  unreachable
bb55:
  %t165 = load ptr, ptr %lp2
  %t166 = getelementptr { i64, ptr }, ptr %t165, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !27
  %t168 = load i64, ptr %l70, !tbaa !24
  %t169 = getelementptr i8, ptr %t167, i64 0
  %t170 = sub i64 %t168, 0
  %t171 = insertvalue { i64, ptr } undef, i64 %t170, 0
  %t172 = insertvalue { i64, ptr } %t171, ptr %t169, 1
  store { i64, ptr } %t172, ptr %l6, !tbaa !27
  %t174 = load i1, ptr %l4, !tbaa !21
  br i1 %t174, label %bb57, label %bb58
bb56:
  call void @__olang_check_failed(ptr @olang_loc_2281448cce404233_754aa41ddbc9325f)
  unreachable
bb57:
  store %olang.scope zeroinitializer, ptr %s4
  %t176 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s4)
  store %"std/prelude/text:StringBuilder" %t176, ptr %l77
  br label %bb59
bb58:
  br label %bb102
bb59:
  %t177 = load %"std/prelude/text:StringBuilder", ptr %l77
  store %"std/prelude/text:StringBuilder" %t177, ptr %l7
  %t178 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t180 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v2, ptr %s4, { i64, ptr } %t178, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d117, i32 0, i32 1) })
  store i1 %t180, ptr %l79
  br label %bb60
bb60:
  %t181 = load i1, ptr %l79, !tbaa !21
  br i1 %t181, label %bb61, label %bb62
bb61:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s4, ptr %l7, i8 48)
  br label %bb63
bb62:
  br label %bb64
bb63:
  br label %bb64
bb64:
  %t183 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t186 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v2, { i64, ptr } %t183, i8 101)
  %t187 = extractvalue { i32, i64 } %t186, 1
  %t188 = extractvalue { i32, i64 } %t186, 0
  store i32 %t188, ptr %l85
  %t189 = icmp ne i32 %t188, 0
  br i1 %t189, label %bb66, label %ok.190, !prof !99
ok.190:
  store i64 %t187, ptr %l84
  br label %bb65
bb65:
  %t191 = load i64, ptr %l84, !tbaa !24
  store i64 %t191, ptr %l81, !tbaa !24
  br label %bb68
bb66:
  br label %bb67
bb67:
  %t192 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t194 = extractvalue { i64, ptr } %t192, 0
  store i64 %t194, ptr %l81, !tbaa !24
  br label %bb68
bb68:
  %t196 = load i64, ptr %l81, !tbaa !24
  store i64 %t196, ptr %l8, !tbaa !24
  store ptr %l7, ptr %l88, !tbaa !29
  %t197 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t197, ptr %l89, !tbaa !27
  %t198 = load i64, ptr %l8, !tbaa !24
  store i64 %t198, ptr %l90, !tbaa !24
  %t199 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t200 = extractvalue { i64, ptr } %t199, 0
  store i64 %t200, ptr %l91, !tbaa !24
  %t201 = icmp sge i64 0, 0
  br i1 %t201, label %bb69, label %bb70
bb69:
  %t203 = load i64, ptr %l90, !tbaa !24
  %t204 = icmp sle i64 0, %t203
  br i1 %t204, label %bb71, label %bb72
bb70:
  call void @__olang_check_failed(ptr @olang_loc_231822a9f2b4ccd6_f89b0d7c0520fae2)
  unreachable
bb71:
  %t206 = load i64, ptr %l90, !tbaa !24
  %t207 = load i64, ptr %l91, !tbaa !24
  %t208 = icmp sle i64 %t206, %t207
  br i1 %t208, label %bb73, label %bb74
bb72:
  call void @__olang_check_failed(ptr @olang_loc_231822a9f2b4ccd6_f89b0d7c0520fae2)
  unreachable
bb73:
  %t210 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t211 = load ptr, ptr %t210, !tbaa !27
  %t212 = load i64, ptr %l90, !tbaa !24
  %t213 = getelementptr i8, ptr %t211, i64 0
  %t214 = sub i64 %t212, 0
  %t215 = insertvalue { i64, ptr } undef, i64 %t214, 0
  %t216 = insertvalue { i64, ptr } %t215, ptr %t213, 1
  %t217 = load ptr, ptr %l88, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s4, ptr %v2, ptr %t217, { i64, ptr } %t216)
  br label %bb75
bb74:
  call void @__olang_check_failed(ptr @olang_loc_231822a9f2b4ccd6_f89b0d7c0520fae2)
  unreachable
bb75:
  %t219 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t219, ptr %l96, !tbaa !27
  %t220 = load i64, ptr %l8, !tbaa !24
  store i64 %t220, ptr %l97, !tbaa !24
  %t221 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t222 = extractvalue { i64, ptr } %t221, 0
  store i64 %t222, ptr %l98, !tbaa !24
  %t223 = icmp sge i64 0, 0
  br i1 %t223, label %bb76, label %bb77
bb76:
  %t225 = load i64, ptr %l97, !tbaa !24
  %t226 = icmp sle i64 0, %t225
  br i1 %t226, label %bb78, label %bb79
bb77:
  call void @__olang_check_failed(ptr @olang_loc_3945c858895394b5_b3e6527511891161)
  unreachable
bb78:
  %t228 = load i64, ptr %l97, !tbaa !24
  %t229 = load i64, ptr %l98, !tbaa !24
  %t230 = icmp sle i64 %t228, %t229
  br i1 %t230, label %bb80, label %bb81
bb79:
  call void @__olang_check_failed(ptr @olang_loc_3945c858895394b5_b3e6527511891161)
  unreachable
bb80:
  %t232 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t233 = load ptr, ptr %t232, !tbaa !27
  %t234 = load i64, ptr %l97, !tbaa !24
  %t235 = getelementptr i8, ptr %t233, i64 0
  %t236 = sub i64 %t234, 0
  %t237 = insertvalue { i64, ptr } undef, i64 %t236, 0
  %t238 = insertvalue { i64, ptr } %t237, ptr %t235, 1
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d118, i32 0, i32 1) }, ptr %l104, !tbaa !27
  %t241 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t242 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v2, ptr %s4, { i64, ptr } %t238, { i64, ptr } %t241)
  store i1 %t242, ptr %l105
  br label %bb82
bb81:
  call void @__olang_check_failed(ptr @olang_loc_3945c858895394b5_b3e6527511891161)
  unreachable
bb82:
  %t243 = load i1, ptr %l105, !tbaa !21
  %t244 = xor i1 %t243, true
  br i1 %t244, label %bb83, label %bb84
bb83:
  store %olang.scope zeroinitializer, ptr %s6
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s4, ptr %s6, ptr %l7, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d119, i32 0, i32 1) })
  br label %bb85
bb84:
  %t247 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t247, ptr %l108, !tbaa !27
  %t248 = load i64, ptr %l8, !tbaa !24
  %t250 = sub i64 %t248, 1
  %t252 = getelementptr { i64, ptr }, ptr %l108, i32 0, i32 1
  %t253 = load ptr, ptr %t252, !tbaa !27
  %t254 = getelementptr i8, ptr %t253, i64 %t250
  %t255 = load i8, ptr %t254, !tbaa !32
  %t257 = icmp eq i8 %t255, 46
  br i1 %t257, label %bb86, label %bb87
bb85:
  call void @__olang_scope_close(ptr %s6)
  br label %bb90
bb86:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s4, ptr %l7, i8 48)
  br label %bb88
bb87:
  br label %bb89
bb88:
  br label %bb89
bb89:
  br label %bb90
bb90:
  store ptr %l7, ptr %l114, !tbaa !29
  %t260 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t260, ptr %l115, !tbaa !27
  %t261 = load i64, ptr %l8, !tbaa !24
  store i64 %t261, ptr %l116, !tbaa !24
  %t262 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t265 = extractvalue { i64, ptr } %t262, 0
  store i64 %t265, ptr %l119, !tbaa !24
  %t266 = load { i64, ptr }, ptr %l115, !tbaa !27
  %t267 = extractvalue { i64, ptr } %t266, 0
  store i64 %t267, ptr %l120, !tbaa !24
  %t268 = load i64, ptr %l116, !tbaa !24
  %t269 = icmp sge i64 %t268, 0
  br i1 %t269, label %bb91, label %bb92
bb91:
  %t271 = load i64, ptr %l116, !tbaa !24
  %t272 = load i64, ptr %l119, !tbaa !24
  %t273 = icmp sle i64 %t271, %t272
  br i1 %t273, label %bb93, label %bb94
bb92:
  call void @__olang_check_failed(ptr @olang_loc_5833c224f66d4858_52a9715d8b07374)
  unreachable
bb93:
  %t275 = load i64, ptr %l119, !tbaa !24
  %t276 = load i64, ptr %l120, !tbaa !24
  %t277 = icmp sle i64 %t275, %t276
  br i1 %t277, label %bb95, label %bb96
bb94:
  call void @__olang_check_failed(ptr @olang_loc_5833c224f66d4858_52a9715d8b07374)
  unreachable
bb95:
  %t279 = getelementptr { i64, ptr }, ptr %l115, i32 0, i32 1
  %t280 = load ptr, ptr %t279, !tbaa !27
  %t281 = load i64, ptr %l116, !tbaa !24
  %t282 = load i64, ptr %l119, !tbaa !24
  %t283 = getelementptr i8, ptr %t280, i64 %t281
  %t284 = sub i64 %t282, %t281
  %t285 = insertvalue { i64, ptr } undef, i64 %t284, 0
  %t286 = insertvalue { i64, ptr } %t285, ptr %t283, 1
  %t287 = load ptr, ptr %l114, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s4, ptr %v2, ptr %t287, { i64, ptr } %t286)
  br label %bb97
bb96:
  call void @__olang_check_failed(ptr @olang_loc_5833c224f66d4858_52a9715d8b07374)
  unreachable
bb97:
  %t289 = call ptr @__olang_scope_hold(ptr %v2)
  %t290 = ptrtoint ptr %t289 to i64
  store i64 %t290, ptr %l125, !tbaa !24
  %t291 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3acx_2e0
  br i1 %t291, label %bb98, label %bb99
bb98:
  %t293 = call ptr @__olang_region_make(ptr %v2)
  %t294 = ptrtoint ptr %t293 to i64
  store i64 %t294, ptr %l125, !tbaa !24
  br label %bb99
bb99:
  %t295 = load i64, ptr %l125
  %t296 = inttoptr i64 %t295 to ptr
  %t298 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s4, ptr %t296, ptr %l7)
  store { i64, ptr } %t298, ptr %l128
  br label %bb100
bb100:
  %t299 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t300 = load i64, ptr @G_2ecompiler_2fbindgen_2eKFloat, !tbaa !24
  %t303 = call %"compiler/bindgen:cx" @compiler_2fbindgen_2ecx_2elit(ptr %v2, ptr %v2, { i64, ptr } %t299, i64 %t300)
  store %"compiler/bindgen:cx" %t303, ptr %l131
  br label %bb101
bb101:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t304 = load %"compiler/bindgen:cx", ptr %l131
  %t305 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, %"compiler/bindgen:cx" %t304, 1
  store { i32, %"compiler/bindgen:cx" } %t305, ptr %rv
  br label %ret
bb102:
  %t306 = load i1, ptr %l3, !tbaa !21
  br i1 %t306, label %bb103, label %bb104
bb103:
  store i1 true, ptr %l133, !tbaa !21
  br label %bb106
bb104:
  %t308 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t310 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v2, ptr %s0, { i64, ptr } %t308, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d120, i32 0, i32 1) })
  store i1 %t310, ptr %l135
  br label %bb105
bb105:
  %t311 = load i1, ptr %l135, !tbaa !21
  store i1 %t311, ptr %l133, !tbaa !21
  br label %bb106
bb106:
  %t312 = load i1, ptr %l133, !tbaa !21
  br i1 %t312, label %bb107, label %bb108
bb107:
  store i1 true, ptr %l136, !tbaa !21
  br label %bb110
bb108:
  %t313 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t315 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t313, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d121, i32 0, i32 1) })
  store i1 %t315, ptr %l138
  br label %bb109
bb109:
  %t316 = load i1, ptr %l138, !tbaa !21
  store i1 %t316, ptr %l136, !tbaa !21
  br label %bb110
bb110:
  %t317 = load i1, ptr %l136, !tbaa !21
  br i1 %t317, label %bb111, label %bb112
bb111:
  store i1 true, ptr %l139, !tbaa !21
  br label %bb114
bb112:
  %t318 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t320 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v2, ptr %s0, { i64, ptr } %t318, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d122, i32 0, i32 1) })
  store i1 %t320, ptr %l141
  br label %bb113
bb113:
  %t321 = load i1, ptr %l141, !tbaa !21
  %t322 = xor i1 %t321, true
  store i1 %t322, ptr %l139, !tbaa !21
  br label %bb114
bb114:
  %t324 = load i1, ptr %l139, !tbaa !21
  br i1 %t324, label %bb115, label %bb116
bb115:
  %t325 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t326 = load i64, ptr @G_2ecompiler_2fbindgen_2eKInt, !tbaa !24
  %t329 = call %"compiler/bindgen:cx" @compiler_2fbindgen_2ecx_2elit(ptr %v2, ptr %v2, { i64, ptr } %t325, i64 %t326)
  store %"compiler/bindgen:cx" %t329, ptr %l145
  br label %bb117
bb116:
  br label %bb118
bb117:
  call void @__olang_scope_close(ptr %s0)
  %t330 = load %"compiler/bindgen:cx", ptr %l145
  %t331 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, %"compiler/bindgen:cx" %t330, 1
  store { i32, %"compiler/bindgen:cx" } %t331, ptr %rv
  br label %ret
bb118:
  %t332 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t332, ptr %l147, !tbaa !27
  %t333 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t336 = extractvalue { i64, ptr } %t333, 0
  store i64 %t336, ptr %l150, !tbaa !24
  %t337 = load { i64, ptr }, ptr %l147, !tbaa !27
  %t338 = extractvalue { i64, ptr } %t337, 0
  store i64 %t338, ptr %l151, !tbaa !24
  %t339 = icmp sge i64 1, 0
  br i1 %t339, label %bb119, label %bb120
bb119:
  %t341 = load i64, ptr %l150, !tbaa !24
  %t342 = icmp sle i64 1, %t341
  br i1 %t342, label %bb121, label %bb122
bb120:
  call void @__olang_check_failed(ptr @olang_loc_8ffdd2b799db8b57_8707d2f5a85c3a7b)
  unreachable
bb121:
  %t344 = load i64, ptr %l150, !tbaa !24
  %t345 = load i64, ptr %l151, !tbaa !24
  %t346 = icmp sle i64 %t344, %t345
  br i1 %t346, label %bb123, label %bb124
bb122:
  call void @__olang_check_failed(ptr @olang_loc_8ffdd2b799db8b57_8707d2f5a85c3a7b)
  unreachable
bb123:
  %t348 = getelementptr { i64, ptr }, ptr %l147, i32 0, i32 1
  %t349 = load ptr, ptr %t348, !tbaa !27
  %t350 = load i64, ptr %l150, !tbaa !24
  %t351 = getelementptr i8, ptr %t349, i64 1
  %t352 = sub i64 %t350, 1
  %t353 = insertvalue { i64, ptr } undef, i64 %t352, 0
  %t354 = insertvalue { i64, ptr } %t353, ptr %t351, 1
  store { i64, ptr } %t354, ptr %l155, !tbaa !27
  %t355 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s0, i64 8)
  %t356 = extractvalue { i32, i64 } %t355, 1
  %t357 = extractvalue { i32, i64 } %t355, 0
  store i32 %t357, ptr %l157
  %t358 = icmp ne i32 %t357, 0
  br i1 %t358, label %bb126, label %ok.359, !prof !99
ok.359:
  store i64 %t356, ptr %l156
  br label %bb125
bb124:
  call void @__olang_check_failed(ptr @olang_loc_8ffdd2b799db8b57_8707d2f5a85c3a7b)
  unreachable
bb125:
  %t360 = load { i64, ptr }, ptr %l155, !tbaa !27
  %t361 = load i64, ptr %l156, !tbaa !24
  %t362 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v2, { i64, ptr } %t360, i64 %t361)
  %t363 = extractvalue { i32, i64 } %t362, 1
  %t364 = extractvalue { i32, i64 } %t362, 0
  store i32 %t364, ptr %l159
  %t365 = icmp ne i32 %t364, 0
  br i1 %t365, label %bb129, label %ok.366, !prof !99
ok.366:
  store i64 %t363, ptr %l158
  br label %bb128
bb126:
  br label %bb127
bb127:
  %t367 = load ptr, ptr %l0, !tbaa !29
  store ptr %t367, ptr %l160, !tbaa !29
  %t368 = call ptr @__olang_scope_hold(ptr %v0)
  %t369 = ptrtoint ptr %t368 to i64
  store i64 %t369, ptr %l161, !tbaa !24
  %t370 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3agen_2e26
  br i1 %t370, label %bb130, label %bb131
bb128:
  %t372 = load i64, ptr %l158, !tbaa !24
  store i64 %t372, ptr %l146, !tbaa !24
  br label %bb135
bb129:
  br label %bb127
bb130:
  %t373 = call ptr @__olang_region_make(ptr %v0)
  %t374 = ptrtoint ptr %t373 to i64
  store i64 %t374, ptr %l161, !tbaa !24
  br label %bb131
bb131:
  %t375 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t376 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d123, i32 0, i32 1) }, 1
  %t377 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d123, i32 0, i32 1) }, 0
  %t379 = extractvalue { i64, ptr } %t375, 1
  %t380 = extractvalue { i64, ptr } %t375, 0
  %t381 = add i64 %t377, %t380
  %t382 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d124, i32 0, i32 1) }, 1
  %t383 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d124, i32 0, i32 1) }, 0
  %t384 = add i64 %t381, %t383
  %t385 = load i64, ptr %l161
  %t386 = inttoptr i64 %t385 to ptr
  %t387 = call ptr @__olang_held_alloc(ptr %t386, i64 %t384)
  call void @olang_textcopy(ptr %t387, ptr %t376, i64 %t377)
  %t388 = getelementptr i8, ptr %t387, i64 %t377
  call void @olang_textcopy(ptr %t388, ptr %t379, i64 %t380)
  %t389 = getelementptr i8, ptr %t388, i64 %t380
  call void @olang_textcopy(ptr %t389, ptr %t382, i64 %t383)
  %t390 = insertvalue { i64, ptr } undef, i64 %t384, 0
  %t391 = insertvalue { i64, ptr } %t390, ptr %t387, 1
  %t393 = load ptr, ptr %l160, !tbaa !29
  %t395 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %v0, ptr %t393, { i64, ptr } %t391)
  store i32 %t395, ptr %l166
  %t396 = icmp ne i32 %t395, 0
  br i1 %t396, label %bb133, label %ok.397, !prof !99
ok.397:
  br label %bb132
bb132:
  br label %bb134
bb133:
  %t398 = load i32, ptr %l166, !tbaa !23
  %t399 = lshr i32 %t398, 16
  %t400 = and i32 %t398, 65535
  %t401 = icmp eq i32 %t399, 1
  %t402 = select i1 %t401, i32 1, i32 0
  %t403 = icmp eq i32 %t398, 0
  %t404 = shl i32 %t402, 16
  %t405 = or i32 %t404, %t400
  %t406 = select i1 %t403, i32 0, i32 %t405
  call void @__olang_scope_close(ptr %s0)
  %t408 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, i32 %t406, 0
  store { i32, %"compiler/bindgen:cx" } %t408, ptr %rv
  br label %ret
bb134:
  store i64 0, ptr %l146, !tbaa !24
  br label %bb135
bb135:
  %t409 = load i64, ptr %l146, !tbaa !24
  store i64 %t409, ptr %l9, !tbaa !24
  %t410 = call ptr @__olang_scope_hold(ptr %v2)
  %t411 = ptrtoint ptr %t410 to i64
  store i64 %t411, ptr %l168, !tbaa !24
  %t412 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3acx_2e0
  br i1 %t412, label %bb136, label %bb137
bb136:
  %t414 = call ptr @__olang_region_make(ptr %v2)
  %t415 = ptrtoint ptr %t414 to i64
  store i64 %t415, ptr %l168, !tbaa !24
  br label %bb137
bb137:
  %t416 = load i64, ptr %l9, !tbaa !24
  %t418 = call i64 @__olang_fmt_i64(ptr null, i64 %t416)
  %t419 = load i64, ptr %l168
  %t420 = inttoptr i64 %t419 to ptr
  %t421 = call ptr @__olang_held_alloc(ptr %t420, i64 %t418)
  %t422 = call i64 @__olang_fmt_i64(ptr %t421, i64 %t416)
  %t423 = insertvalue { i64, ptr } undef, i64 %t418, 0
  %t424 = insertvalue { i64, ptr } %t423, ptr %t421, 1
  %t426 = load i64, ptr @G_2ecompiler_2fbindgen_2eKInt, !tbaa !24
  %t429 = call %"compiler/bindgen:cx" @compiler_2fbindgen_2ecx_2elit(ptr %v2, ptr %v2, { i64, ptr } %t424, i64 %t426)
  store %"compiler/bindgen:cx" %t429, ptr %l174
  br label %bb138
bb138:
  call void @__olang_scope_close(ptr %s0)
  %t430 = load %"compiler/bindgen:cx", ptr %l174
  %t431 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, %"compiler/bindgen:cx" %t430, 1
  store { i32, %"compiler/bindgen:cx" } %t431, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/bindgen:cx" }, ptr %rv
  ret { i32, %"compiler/bindgen:cx" } %rr
}

define dso_local { i32, %"compiler/bindgen:cx" } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecUnary(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %lp3 = alloca ptr
  %l4 = alloca %"compiler/bindgen:cx"
  %l5 = alloca i64
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %lp7 = alloca ptr
  %l8 = alloca %"compiler/bindgen:cx"
  %l10 = alloca { i64, ptr }
  %l12 = alloca i1
  %l13 = alloca i1
  %l15 = alloca i1
  %l16 = alloca i1
  %l18 = alloca i1
  %l19 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca %"compiler/bindgen:cx"
  %l27 = alloca %"compiler/bindgen:cx"
  %l28 = alloca i32
  %l30 = alloca %"compiler/bindgen:cx"
  %l32 = alloca i1
  %l34 = alloca i64
  %l43 = alloca %"compiler/bindgen:cx"
  %l45 = alloca i1
  %l46 = alloca ptr
  %l50 = alloca %"compiler/bindgen:cx"
  %l53 = alloca %"compiler/bindgen:cx"
  %l54 = alloca i32
  %l56 = alloca i64
  %l60 = alloca %"compiler/bindgen:cx"
  %l65 = alloca %"compiler/bindgen:cx"
  %l67 = alloca i1
  %l70 = alloca ptr
  %l74 = alloca %"std/prelude/text:StringBuilder"
  %l81 = alloca i1
  %l83 = alloca { i64, ptr }
  %l85 = alloca i1
  %l88 = alloca ptr
  %l90 = alloca { i64, ptr }
  %l93 = alloca ptr
  %l97 = alloca ptr
  %l99 = alloca { i64, ptr }
  %l101 = alloca { i64, ptr }
  %l103 = alloca i1
  %l105 = alloca i1
  %l107 = alloca { i64, ptr }
  %l109 = alloca i1
  %l110 = alloca ptr
  %l114 = alloca ptr
  %l115 = alloca %"compiler/bindgen:cx"
  %l118 = alloca %"compiler/bindgen:cx"
  %l119 = alloca i32
  %l121 = alloca %"compiler/bindgen:cx"
  %l122 = alloca i64
  %l130 = alloca %"compiler/bindgen:cx"
  %l133 = alloca %"compiler/bindgen:cx"
  %l136 = alloca %"compiler/bindgen:cx"
  %l137 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca { i32, %"compiler/bindgen:cx" }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3acparse_2eat(ptr %v1, ptr %s0, ptr %t1)
  store { i64, ptr } %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t5, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d125, i32 0, i32 1) })
  store i1 %t7, ptr %l12
  br label %bb2
bb2:
  %t8 = load i1, ptr %l12, !tbaa !21
  br i1 %t8, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb6
bb4:
  %t9 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t11 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t9, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d126, i32 0, i32 1) })
  store i1 %t11, ptr %l15
  br label %bb5
bb5:
  %t12 = load i1, ptr %l15, !tbaa !21
  store i1 %t12, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t13 = load i1, ptr %l13, !tbaa !21
  br i1 %t13, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb10
bb8:
  %t14 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t16 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t14, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d127, i32 0, i32 1) })
  store i1 %t16, ptr %l18
  br label %bb9
bb9:
  %t17 = load i1, ptr %l18, !tbaa !21
  store i1 %t17, ptr %l16, !tbaa !21
  br label %bb10
bb10:
  %t18 = load i1, ptr %l16, !tbaa !21
  br i1 %t18, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s1
  %t19 = load ptr, ptr %l1, !tbaa !29
  store ptr %t19, ptr %l19, !tbaa !29
  %t20 = load ptr, ptr %l19, !tbaa !29
  %t21 = getelementptr %"compiler/bindgen:cparse", ptr %t20, i32 0, i32 2
  %t22 = load i64, ptr %t21, !tbaa !24
  %t25 = add i64 %t22, 1
  %t27 = load ptr, ptr %l19, !tbaa !29
  %t28 = getelementptr %"compiler/bindgen:cparse", ptr %t27, i32 0, i32 2
  store i64 %t25, ptr %t28, !tbaa !24
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l23, !tbaa !29
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t34 = call { i32, %"compiler/bindgen:cx" } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecUnary(ptr %v0, ptr %v1, ptr %v0, ptr %t30, ptr %t31)
  %t35 = extractvalue { i32, %"compiler/bindgen:cx" } %t34, 1
  %t36 = extractvalue { i32, %"compiler/bindgen:cx" } %t34, 0
  store i32 %t36, ptr %l28
  %t37 = icmp ne i32 %t36, 0
  br i1 %t37, label %bb14, label %ok.38, !prof !99
ok.38:
  store %"compiler/bindgen:cx" %t35, ptr %l27
  br label %bb13
bb12:
  br label %bb24
bb13:
  %t39 = load %"compiler/bindgen:cx", ptr %l27
  store %"compiler/bindgen:cx" %t39, ptr %l24
  br label %bb15
bb14:
  %t40 = load i32, ptr %l28, !tbaa !23
  %t41 = lshr i32 %t40, 16
  %t42 = and i32 %t40, 65535
  %t43 = icmp eq i32 %t41, 1
  %t44 = select i1 %t43, i32 1, i32 0
  %t45 = icmp eq i32 %t40, 0
  %t46 = shl i32 %t44, 16
  %t47 = or i32 %t46, %t42
  %t48 = select i1 %t45, i32 0, i32 %t47
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t50 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, i32 %t48, 0
  store { i32, %"compiler/bindgen:cx" } %t50, ptr %rv
  br label %ret
bb15:
  %t51 = load ptr, ptr %l23, !tbaa !29
  %t52 = load %"compiler/bindgen:cx", ptr %l24
  %t53 = call %"compiler/bindgen:cx" @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecNum(ptr %v0, ptr %v0, ptr %v2, ptr %t51, %"compiler/bindgen:cx" %t52)
  store %"compiler/bindgen:cx" %t53, ptr %l30
  br label %bb16
bb16:
  %t54 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store ptr %t54, ptr %lp3
  %t55 = load %"compiler/bindgen:cx", ptr %l30
  %t56 = load ptr, ptr %lp3
  store %"compiler/bindgen:cx" %t55, ptr %t56
  %t57 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t59 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s1, { i64, ptr } %t57, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d128, i32 0, i32 1) })
  store i1 %t59, ptr %l32
  br label %bb17
bb17:
  %t60 = load i1, ptr %l32, !tbaa !21
  br i1 %t60, label %bb18, label %bb19
bb18:
  %t61 = load ptr, ptr %lp3
  %t62 = load %"compiler/bindgen:cx", ptr %t61
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t64 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, %"compiler/bindgen:cx" %t62, 1
  store { i32, %"compiler/bindgen:cx" } %t64, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t65 = call ptr @__olang_scope_hold(ptr %v2)
  %t66 = ptrtoint ptr %t65 to i64
  store i64 %t66, ptr %l34, !tbaa !24
  %t67 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3acx_2e0
  br i1 %t67, label %bb21, label %bb22
bb21:
  %t69 = call ptr @__olang_region_make(ptr %v2)
  %t70 = ptrtoint ptr %t69 to i64
  store i64 %t70, ptr %l34, !tbaa !24
  br label %bb22
bb22:
  %t71 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t72 = load ptr, ptr %lp3
  %t73 = getelementptr %"compiler/bindgen:cx", ptr %t72, i32 0, i32 0
  %t74 = load { i64, ptr }, ptr %t73, !tbaa !27
  %t75 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d129, i32 0, i32 1) }, 1
  %t76 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d129, i32 0, i32 1) }, 0
  %t78 = extractvalue { i64, ptr } %t71, 1
  %t79 = extractvalue { i64, ptr } %t71, 0
  %t80 = add i64 %t76, %t79
  %t82 = extractvalue { i64, ptr } %t74, 1
  %t83 = extractvalue { i64, ptr } %t74, 0
  %t84 = add i64 %t80, %t83
  %t85 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d130, i32 0, i32 1) }, 1
  %t86 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d130, i32 0, i32 1) }, 0
  %t87 = add i64 %t84, %t86
  %t88 = load i64, ptr %l34
  %t89 = inttoptr i64 %t88 to ptr
  %t90 = call ptr @__olang_held_alloc(ptr %t89, i64 %t87)
  call void @olang_textcopy(ptr %t90, ptr %t75, i64 %t76)
  %t91 = getelementptr i8, ptr %t90, i64 %t76
  call void @olang_textcopy(ptr %t91, ptr %t78, i64 %t79)
  %t92 = getelementptr i8, ptr %t91, i64 %t79
  call void @olang_textcopy(ptr %t92, ptr %t82, i64 %t83)
  %t93 = getelementptr i8, ptr %t92, i64 %t83
  call void @olang_textcopy(ptr %t93, ptr %t85, i64 %t86)
  %t94 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t90, 1
  %t97 = load ptr, ptr %lp3
  %t98 = getelementptr %"compiler/bindgen:cx", ptr %t97, i32 0, i32 1
  %t99 = load i64, ptr %t98, !tbaa !24
  %t100 = load ptr, ptr %lp3
  %t101 = getelementptr %"compiler/bindgen:cx", ptr %t100, i32 0, i32 2
  %t102 = load i64, ptr %t101, !tbaa !24
  %t103 = load ptr, ptr %lp3
  %t104 = getelementptr %"compiler/bindgen:cx", ptr %t103, i32 0, i32 3
  %t105 = load { i64, ptr }, ptr %t104, !tbaa !27
  %t110 = call %"compiler/bindgen:cx" @compiler_2fbindgen_3acx_2ector(ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t95, i64 %t99, i64 %t102, { i64, ptr } %t105)
  store %"compiler/bindgen:cx" %t110, ptr %l43
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t111 = load %"compiler/bindgen:cx", ptr %l43
  %t112 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, %"compiler/bindgen:cx" %t111, 1
  store { i32, %"compiler/bindgen:cx" } %t112, ptr %rv
  br label %ret
bb24:
  %t113 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t115 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t113, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d131, i32 0, i32 1) })
  store i1 %t115, ptr %l45
  br label %bb25
bb25:
  %t116 = load i1, ptr %l45, !tbaa !21
  br i1 %t116, label %bb26, label %bb27
bb26:
  %t117 = load ptr, ptr %l1, !tbaa !29
  store ptr %t117, ptr %l46, !tbaa !29
  %t118 = load ptr, ptr %l46, !tbaa !29
  %t119 = getelementptr %"compiler/bindgen:cparse", ptr %t118, i32 0, i32 2
  %t120 = load i64, ptr %t119, !tbaa !24
  %t123 = add i64 %t120, 1
  %t125 = load ptr, ptr %l46, !tbaa !29
  %t126 = getelementptr %"compiler/bindgen:cparse", ptr %t125, i32 0, i32 2
  store i64 %t123, ptr %t126, !tbaa !24
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load ptr, ptr %l1, !tbaa !29
  %t131 = call { i32, %"compiler/bindgen:cx" } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecUnary(ptr %v0, ptr %v1, ptr %v0, ptr %t127, ptr %t128)
  %t132 = extractvalue { i32, %"compiler/bindgen:cx" } %t131, 1
  %t133 = extractvalue { i32, %"compiler/bindgen:cx" } %t131, 0
  store i32 %t133, ptr %l54
  %t134 = icmp ne i32 %t133, 0
  br i1 %t134, label %bb29, label %ok.135, !prof !99
ok.135:
  store %"compiler/bindgen:cx" %t132, ptr %l53
  br label %bb28
bb27:
  br label %bb35
bb28:
  %t136 = load %"compiler/bindgen:cx", ptr %l53
  store %"compiler/bindgen:cx" %t136, ptr %l50
  br label %bb30
bb29:
  %t137 = load i32, ptr %l54, !tbaa !23
  %t138 = lshr i32 %t137, 16
  %t139 = and i32 %t137, 65535
  %t140 = icmp eq i32 %t138, 1
  %t141 = select i1 %t140, i32 1, i32 0
  %t142 = icmp eq i32 %t137, 0
  %t143 = shl i32 %t141, 16
  %t144 = or i32 %t143, %t139
  %t145 = select i1 %t142, i32 0, i32 %t144
  call void @__olang_scope_close(ptr %s0)
  %t147 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, i32 %t145, 0
  store { i32, %"compiler/bindgen:cx" } %t147, ptr %rv
  br label %ret
bb30:
  %t148 = load %"compiler/bindgen:cx", ptr %l50
  store %"compiler/bindgen:cx" %t148, ptr %l4
  %t149 = call ptr @__olang_scope_hold(ptr %v2)
  %t150 = ptrtoint ptr %t149 to i64
  store i64 %t150, ptr %l56, !tbaa !24
  %t151 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3acx_2e0
  br i1 %t151, label %bb31, label %bb32
bb31:
  %t153 = call ptr @__olang_region_make(ptr %v2)
  %t154 = ptrtoint ptr %t153 to i64
  store i64 %t154, ptr %l56, !tbaa !24
  br label %bb32
bb32:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load %"compiler/bindgen:cx", ptr %l4
  %t159 = call %"compiler/bindgen:cx" @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecBool(ptr %v0, ptr %v0, ptr %v0, ptr %t155, %"compiler/bindgen:cx" %t156)
  store %"compiler/bindgen:cx" %t159, ptr %l60
  br label %bb33
bb33:
  %t160 = getelementptr %"compiler/bindgen:cx", ptr %l60, i32 0, i32 0
  %t161 = load { i64, ptr }, ptr %t160, !tbaa !27
  %t162 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d132, i32 0, i32 1) }, 1
  %t163 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d132, i32 0, i32 1) }, 0
  %t165 = extractvalue { i64, ptr } %t161, 1
  %t166 = extractvalue { i64, ptr } %t161, 0
  %t167 = add i64 %t163, %t166
  %t168 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d133, i32 0, i32 1) }, 1
  %t169 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d133, i32 0, i32 1) }, 0
  %t170 = add i64 %t167, %t169
  %t171 = load i64, ptr %l56
  %t172 = inttoptr i64 %t171 to ptr
  %t173 = call ptr @__olang_held_alloc(ptr %t172, i64 %t170)
  call void @olang_textcopy(ptr %t173, ptr %t162, i64 %t163)
  %t174 = getelementptr i8, ptr %t173, i64 %t163
  call void @olang_textcopy(ptr %t174, ptr %t165, i64 %t166)
  %t175 = getelementptr i8, ptr %t174, i64 %t166
  call void @olang_textcopy(ptr %t175, ptr %t168, i64 %t169)
  %t176 = insertvalue { i64, ptr } undef, i64 %t170, 0
  %t177 = insertvalue { i64, ptr } %t176, ptr %t173, 1
  %t179 = load i64, ptr @G_2ecompiler_2fbindgen_2eKBool, !tbaa !24
  %t182 = call %"compiler/bindgen:cx" @compiler_2fbindgen_3acx_2ector(ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t177, i64 %t179, i64 -1, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d134, i32 0, i32 1) })
  store %"compiler/bindgen:cx" %t182, ptr %l65
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s0)
  %t183 = load %"compiler/bindgen:cx", ptr %l65
  %t184 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, %"compiler/bindgen:cx" %t183, 1
  store { i32, %"compiler/bindgen:cx" } %t184, ptr %rv
  br label %ret
bb35:
  %t185 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t187 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t185, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d135, i32 0, i32 1) })
  store i1 %t187, ptr %l67
  br label %bb36
bb36:
  %t188 = load i1, ptr %l67, !tbaa !21
  br i1 %t188, label %bb37, label %bb38
bb37:
  store %olang.scope zeroinitializer, ptr %s6
  %t189 = load ptr, ptr %l1, !tbaa !29
  %t191 = getelementptr %"compiler/bindgen:cparse", ptr %t189, i32 0, i32 2
  %t192 = load i64, ptr %t191, !tbaa !24
  store i64 %t192, ptr %l5, !tbaa !24
  %t194 = load ptr, ptr %l1, !tbaa !29
  store ptr %t194, ptr %l70, !tbaa !29
  %t195 = load ptr, ptr %l70, !tbaa !29
  %t196 = getelementptr %"compiler/bindgen:cparse", ptr %t195, i32 0, i32 2
  %t197 = load i64, ptr %t196, !tbaa !24
  %t200 = add i64 %t197, 1
  %t202 = load ptr, ptr %l70, !tbaa !29
  %t203 = getelementptr %"compiler/bindgen:cparse", ptr %t202, i32 0, i32 2
  store i64 %t200, ptr %t203, !tbaa !24
  %t204 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s6)
  store %"std/prelude/text:StringBuilder" %t204, ptr %l74
  br label %bb39
bb38:
  br label %bb72
bb39:
  %t205 = load %"std/prelude/text:StringBuilder", ptr %l74
  store %"std/prelude/text:StringBuilder" %t205, ptr %l6
  br label %bb40
bb40:
  store %olang.scope zeroinitializer, ptr %s7
  %t206 = load ptr, ptr %l1, !tbaa !29
  %t208 = getelementptr %"compiler/bindgen:cparse", ptr %t206, i32 0, i32 2
  %t209 = load i64, ptr %t208, !tbaa !24
  %t210 = load ptr, ptr %l1, !tbaa !29
  %t212 = getelementptr %"compiler/bindgen:cparse", ptr %t210, i32 0, i32 0
  %t213 = load { i64, ptr }, ptr %t212, !tbaa !27
  %t215 = extractvalue { i64, ptr } %t213, 0
  %t218 = icmp slt i64 %t209, %t215
  br i1 %t218, label %bb41, label %bb42
bb41:
  %t220 = load ptr, ptr %l1, !tbaa !29
  %t222 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3acparse_2eat(ptr %v1, ptr %s7, ptr %t220)
  store { i64, ptr } %t222, ptr %l83
  br label %bb43
bb42:
  store i1 false, ptr %l81, !tbaa !21
  br label %bb45
bb43:
  %t223 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t225 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s7, ptr %s7, { i64, ptr } %t223, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d136, i32 0, i32 1) })
  store i1 %t225, ptr %l85
  br label %bb44
bb44:
  %t226 = load i1, ptr %l85, !tbaa !21
  %t227 = xor i1 %t226, true
  store i1 %t227, ptr %l81, !tbaa !21
  br label %bb45
bb45:
  %t229 = load i1, ptr %l81, !tbaa !21
  %t230 = xor i1 %t229, true
  br i1 %t230, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s7)
  br label %bb53
bb47:
  br label %bb48
bb48:
  store ptr %l6, ptr %l88, !tbaa !29
  %t232 = load ptr, ptr %l1, !tbaa !29
  %t234 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3acparse_2eat(ptr %v1, ptr %s7, ptr %t232)
  store { i64, ptr } %t234, ptr %l90
  br label %bb49
bb49:
  %t235 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t236 = load ptr, ptr %l88, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s6, ptr %s7, ptr %t236, { i64, ptr } %t235)
  br label %bb50
bb50:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s6, ptr %s7, ptr %l6, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d137, i32 0, i32 1) })
  br label %bb51
bb51:
  %t239 = load ptr, ptr %l1, !tbaa !29
  store ptr %t239, ptr %l93, !tbaa !29
  %t240 = load ptr, ptr %l93, !tbaa !29
  %t241 = getelementptr %"compiler/bindgen:cparse", ptr %t240, i32 0, i32 2
  %t242 = load i64, ptr %t241, !tbaa !24
  %t245 = add i64 %t242, 1
  %t247 = load ptr, ptr %l93, !tbaa !29
  %t248 = getelementptr %"compiler/bindgen:cparse", ptr %t247, i32 0, i32 2
  store i64 %t245, ptr %t248, !tbaa !24
  call void @__olang_scope_close(ptr %s7)
  br label %bb52
bb52:
  br label %bb40
bb53:
  %t249 = load ptr, ptr %l0, !tbaa !29
  store ptr %t249, ptr %l97, !tbaa !29
  %t251 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s6, ptr %s6, ptr %l6)
  store { i64, ptr } %t251, ptr %l99
  br label %bb54
bb54:
  %t252 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t253 = load ptr, ptr %l97, !tbaa !29
  %t255 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecastType(ptr %v0, ptr %s6, ptr %v2, ptr %t253, { i64, ptr } %t252)
  store { i64, ptr } %t255, ptr %l101
  br label %bb55
bb55:
  %t256 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t256, ptr %lp7
  %t257 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t258 = load ptr, ptr %lp7
  store { i64, ptr } %t257, ptr %t258, !tbaa !27
  %t259 = load ptr, ptr %lp7
  %t260 = load { i64, ptr }, ptr %t259, !tbaa !27
  %t262 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s6, { i64, ptr } %t260, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d138, i32 0, i32 1) })
  store i1 %t262, ptr %l103
  br label %bb56
bb56:
  %t263 = load i1, ptr %l103, !tbaa !21
  %t264 = xor i1 %t263, true
  br i1 %t264, label %bb57, label %bb58
bb57:
  %t266 = load ptr, ptr %l1, !tbaa !29
  %t268 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3acparse_2eat(ptr %v1, ptr %s6, ptr %t266)
  store { i64, ptr } %t268, ptr %l107
  br label %bb59
bb58:
  store i1 false, ptr %l105, !tbaa !21
  br label %bb61
bb59:
  %t269 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t271 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s6, ptr %s6, { i64, ptr } %t269, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d139, i32 0, i32 1) })
  store i1 %t271, ptr %l109
  br label %bb60
bb60:
  %t272 = load i1, ptr %l109, !tbaa !21
  store i1 %t272, ptr %l105, !tbaa !21
  br label %bb61
bb61:
  %t273 = load i1, ptr %l105, !tbaa !21
  br i1 %t273, label %bb62, label %bb63
bb62:
  store %olang.scope zeroinitializer, ptr %s8
  %t274 = load ptr, ptr %l1, !tbaa !29
  store ptr %t274, ptr %l110, !tbaa !29
  %t275 = load ptr, ptr %l110, !tbaa !29
  %t276 = getelementptr %"compiler/bindgen:cparse", ptr %t275, i32 0, i32 2
  %t277 = load i64, ptr %t276, !tbaa !24
  %t280 = add i64 %t277, 1
  %t282 = load ptr, ptr %l110, !tbaa !29
  %t283 = getelementptr %"compiler/bindgen:cparse", ptr %t282, i32 0, i32 2
  store i64 %t280, ptr %t283, !tbaa !24
  %t284 = load ptr, ptr %l0, !tbaa !29
  store ptr %t284, ptr %l114, !tbaa !29
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t286 = load ptr, ptr %l1, !tbaa !29
  %t289 = call { i32, %"compiler/bindgen:cx" } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecUnary(ptr %v0, ptr %v1, ptr %v0, ptr %t285, ptr %t286)
  %t290 = extractvalue { i32, %"compiler/bindgen:cx" } %t289, 1
  %t291 = extractvalue { i32, %"compiler/bindgen:cx" } %t289, 0
  store i32 %t291, ptr %l119
  %t292 = icmp ne i32 %t291, 0
  br i1 %t292, label %bb65, label %ok.293, !prof !99
ok.293:
  store %"compiler/bindgen:cx" %t290, ptr %l118
  br label %bb64
bb63:
  br label %bb71
bb64:
  %t294 = load %"compiler/bindgen:cx", ptr %l118
  store %"compiler/bindgen:cx" %t294, ptr %l115
  br label %bb66
bb65:
  %t295 = load i32, ptr %l119, !tbaa !23
  %t296 = lshr i32 %t295, 16
  %t297 = and i32 %t295, 65535
  %t298 = icmp eq i32 %t296, 1
  %t299 = select i1 %t298, i32 1, i32 0
  %t300 = icmp eq i32 %t295, 0
  %t301 = shl i32 %t299, 16
  %t302 = or i32 %t301, %t297
  %t303 = select i1 %t300, i32 0, i32 %t302
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t305 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, i32 %t303, 0
  store { i32, %"compiler/bindgen:cx" } %t305, ptr %rv
  br label %ret
bb66:
  %t306 = load ptr, ptr %l114, !tbaa !29
  %t307 = load %"compiler/bindgen:cx", ptr %l115
  %t308 = call %"compiler/bindgen:cx" @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecNum(ptr %v0, ptr %v0, ptr %s8, ptr %t306, %"compiler/bindgen:cx" %t307)
  store %"compiler/bindgen:cx" %t308, ptr %l121
  br label %bb67
bb67:
  %t309 = load %"compiler/bindgen:cx", ptr %l121
  store %"compiler/bindgen:cx" %t309, ptr %l8
  %t310 = call ptr @__olang_scope_hold(ptr %v2)
  %t311 = ptrtoint ptr %t310 to i64
  store i64 %t311, ptr %l122, !tbaa !24
  %t312 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3acx_2e0
  br i1 %t312, label %bb68, label %bb69
bb68:
  %t314 = call ptr @__olang_region_make(ptr %v2)
  %t315 = ptrtoint ptr %t314 to i64
  store i64 %t315, ptr %l122, !tbaa !24
  br label %bb69
bb69:
  %t316 = load ptr, ptr %lp7
  %t317 = load { i64, ptr }, ptr %t316, !tbaa !27
  %t318 = getelementptr %"compiler/bindgen:cx", ptr %l8, i32 0, i32 0
  %t319 = load { i64, ptr }, ptr %t318, !tbaa !27
  %t321 = extractvalue { i64, ptr } %t317, 1
  %t322 = extractvalue { i64, ptr } %t317, 0
  %t323 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d140, i32 0, i32 1) }, 1
  %t324 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d140, i32 0, i32 1) }, 0
  %t325 = add i64 %t322, %t324
  %t327 = extractvalue { i64, ptr } %t319, 1
  %t328 = extractvalue { i64, ptr } %t319, 0
  %t329 = add i64 %t325, %t328
  %t330 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d141, i32 0, i32 1) }, 1
  %t331 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d141, i32 0, i32 1) }, 0
  %t332 = add i64 %t329, %t331
  %t333 = load i64, ptr %l122
  %t334 = inttoptr i64 %t333 to ptr
  %t335 = call ptr @__olang_held_alloc(ptr %t334, i64 %t332)
  call void @olang_textcopy(ptr %t335, ptr %t321, i64 %t322)
  %t336 = getelementptr i8, ptr %t335, i64 %t322
  call void @olang_textcopy(ptr %t336, ptr %t323, i64 %t324)
  %t337 = getelementptr i8, ptr %t336, i64 %t324
  call void @olang_textcopy(ptr %t337, ptr %t327, i64 %t328)
  %t338 = getelementptr i8, ptr %t337, i64 %t328
  call void @olang_textcopy(ptr %t338, ptr %t330, i64 %t331)
  %t339 = insertvalue { i64, ptr } undef, i64 %t332, 0
  %t340 = insertvalue { i64, ptr } %t339, ptr %t335, 1
  %t342 = load i64, ptr @G_2ecompiler_2fbindgen_2eKType, !tbaa !24
  %t343 = load ptr, ptr %lp7
  %t344 = load { i64, ptr }, ptr %t343, !tbaa !27
  %t348 = call %"compiler/bindgen:cx" @compiler_2fbindgen_3acx_2ector(ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t340, i64 %t342, i64 -1, { i64, ptr } %t344)
  store %"compiler/bindgen:cx" %t348, ptr %l130
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t349 = load %"compiler/bindgen:cx", ptr %l130
  %t350 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, %"compiler/bindgen:cx" %t349, 1
  store { i32, %"compiler/bindgen:cx" } %t350, ptr %rv
  br label %ret
bb71:
  %t351 = load ptr, ptr %l1, !tbaa !29
  %t352 = load i64, ptr %l5, !tbaa !24
  %t355 = getelementptr %"compiler/bindgen:cparse", ptr %t351, i32 0, i32 2
  store i64 %t352, ptr %t355, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb72
bb72:
  %t356 = load ptr, ptr %l0, !tbaa !29
  %t357 = load ptr, ptr %l1, !tbaa !29
  %t360 = call { i32, %"compiler/bindgen:cx" } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecPrimary(ptr %v0, ptr %v1, ptr %v2, ptr %t356, ptr %t357)
  %t361 = extractvalue { i32, %"compiler/bindgen:cx" } %t360, 1
  %t362 = extractvalue { i32, %"compiler/bindgen:cx" } %t360, 0
  store i32 %t362, ptr %l137
  %t363 = icmp ne i32 %t362, 0
  br i1 %t363, label %bb74, label %ok.364, !prof !99
ok.364:
  store %"compiler/bindgen:cx" %t361, ptr %l136
  br label %bb73
bb73:
  %t365 = load %"compiler/bindgen:cx", ptr %l136
  store %"compiler/bindgen:cx" %t365, ptr %l133
  br label %bb75
bb74:
  %t366 = load i32, ptr %l137, !tbaa !23
  %t367 = lshr i32 %t366, 16
  %t368 = and i32 %t366, 65535
  %t369 = icmp eq i32 %t367, 1
  %t370 = select i1 %t369, i32 1, i32 0
  %t371 = icmp eq i32 %t366, 0
  %t372 = shl i32 %t370, 16
  %t373 = or i32 %t372, %t368
  %t374 = select i1 %t371, i32 0, i32 %t373
  call void @__olang_scope_close(ptr %s0)
  %t376 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, i32 %t374, 0
  store { i32, %"compiler/bindgen:cx" } %t376, ptr %rv
  br label %ret
bb75:
  call void @__olang_scope_close(ptr %s0)
  %t377 = load %"compiler/bindgen:cx", ptr %l133
  %t378 = insertvalue { i32, %"compiler/bindgen:cx" } zeroinitializer, %"compiler/bindgen:cx" %t377, 1
  store { i32, %"compiler/bindgen:cx" } %t378, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/bindgen:cx" }, ptr %rv
  ret { i32, %"compiler/bindgen:cx" } %rr
}

define dso_local { i32, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2edump(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca i64
  %lp13 = alloca ptr
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l24 = alloca { i64, ptr }
  %l49 = alloca %"std/os:Output"
  %l51 = alloca { i64, ptr }
  %l52 = alloca %"std/os:Output"
  %l53 = alloca i32
  %l55 = alloca i1
  %l56 = alloca ptr
  %l57 = alloca { i64, ptr }
  %l63 = alloca ptr
  %l64 = alloca i64
  %l67 = alloca { i64, ptr }
  %l69 = alloca i32
  %l71 = alloca ptr
  %l73 = alloca ptr
  %l74 = alloca i32
  %l76 = alloca i1
  %l79 = alloca ptr
  %l80 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l14
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l4
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v1, ptr %l4, { i64, ptr } %a1)
  br label %bb2
bb2:
  store { i64, ptr } %a2, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t8 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  store i64 %t10, ptr %l7, !tbaa !24
  br label %bb3
bb3:
  %t12 = load i64, ptr %l6, !tbaa !24
  %t13 = load i64, ptr %l7, !tbaa !24
  %t16 = icmp slt i64 %t12, %t13
  %t18 = xor i1 %t16, true
  br i1 %t18, label %bb4, label %bb5
bb4:
  br label %bb9
bb5:
  br label %bb6
bb6:
  %t20 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t20, ptr %l24, !tbaa !27
  %t21 = load i64, ptr %l6, !tbaa !24
  %t23 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr { i64, ptr }, ptr %t24, i64 %t21
  %t26 = load { i64, ptr }, ptr %t25, !tbaa !37
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v2, ptr %l4, { i64, ptr } %t26)
  br label %bb7
bb7:
  br label %bb8
bb8:
  %t31 = load i64, ptr %l6, !tbaa !24
  %t34 = add i64 %t31, 1
  store i64 %t34, ptr %l6, !tbaa !24
  br label %bb3
bb9:
  %t37 = insertvalue [8 x { i64, ptr }] undef, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d142, i32 0, i32 1) }, 0
  %t38 = insertvalue [8 x { i64, ptr }] %t37, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d143, i32 0, i32 1) }, 1
  %t39 = insertvalue [8 x { i64, ptr }] %t38, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d144, i32 0, i32 1) }, 2
  %t40 = insertvalue [8 x { i64, ptr }] %t39, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d145, i32 0, i32 1) }, 3
  %t41 = insertvalue [8 x { i64, ptr }] %t40, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d146, i32 0, i32 1) }, 4
  %t42 = insertvalue [8 x { i64, ptr }] %t41, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d147, i32 0, i32 1) }, 5
  %t43 = insertvalue [8 x { i64, ptr }] %t42, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d148, i32 0, i32 1) }, 6
  %t45 = insertvalue [8 x { i64, ptr }] %t43, { i64, ptr } %a3, 7
  %t47 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 128, i64 8)
  store [8 x { i64, ptr }] %t45, ptr %t47
  store ptr %t47, ptr %l9
  store i64 0, ptr %l10, !tbaa !24
  %t49 = load ptr, ptr %l9
  store i64 8, ptr %l11, !tbaa !24
  br label %bb10
bb10:
  %t52 = load i64, ptr %l10, !tbaa !24
  %t53 = load i64, ptr %l11, !tbaa !24
  %t56 = icmp slt i64 %t52, %t53
  %t58 = xor i1 %t56, true
  br i1 %t58, label %bb11, label %bb12
bb11:
  br label %bb16
bb12:
  br label %bb13
bb13:
  %t60 = load ptr, ptr %l9
  %t61 = load i64, ptr %l10, !tbaa !24
  %t64 = getelementptr [8 x { i64, ptr }], ptr %t60, i64 0, i64 %t61
  %t65 = load { i64, ptr }, ptr %t64, !tbaa !37
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l4, { i64, ptr } %t65)
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t70 = load i64, ptr %l10, !tbaa !24
  %t73 = add i64 %t70, 1
  store i64 %t73, ptr %l10, !tbaa !24
  br label %bb10
bb16:
  %t76 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %s0, ptr %s0, ptr %l4)
  store { i64, ptr } %t76, ptr %l51
  br label %bb17
bb17:
  %t77 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t78 = call { i32, %"std/os:Output" } @compiler_2fbindgen_2eclangSays(ptr %s0, ptr %v4, { i64, ptr } %t77)
  %t79 = extractvalue { i32, %"std/os:Output" } %t78, 1
  %t80 = extractvalue { i32, %"std/os:Output" } %t78, 0
  store i32 %t80, ptr %l53
  %t81 = icmp ne i32 %t80, 0
  br i1 %t81, label %bb19, label %ok.82, !prof !99
ok.82:
  store %"std/os:Output" %t79, ptr %l52
  br label %bb18
bb18:
  %t83 = load %"std/os:Output", ptr %l52
  store %"std/os:Output" %t83, ptr %l49
  br label %bb23
bb19:
  %t84 = load i32, ptr %l53, !tbaa !23
  %t85 = ashr i32 %t84, 16
  %t87 = icmp eq i32 %t85, 1
  store i1 %t87, ptr %l55, !tbaa !21
  br label %bb20
bb20:
  %t88 = load ptr, ptr %l0, !tbaa !29
  store ptr %t88, ptr %l56, !tbaa !29
  %t89 = load ptr, ptr %l56, !tbaa !29
  %t90 = getelementptr %"compiler/bindgen:gen", ptr %t89, i32 0, i32 26
  %t91 = load { i64, ptr }, ptr %t90, !tbaa !27
  store { i64, ptr } %t91, ptr %l57, !tbaa !27
  %t92 = load ptr, ptr %l56, !tbaa !29
  %t93 = getelementptr %"compiler/bindgen:gen", ptr %t92, i32 0, i32 26
  store { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d149, i32 0, i32 1) }, ptr %t93, !tbaa !27
  %t94 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3agen_2e26
  br i1 %t94, label %bb21, label %bb22
bb21:
  %t96 = load { i64, ptr }, ptr %l57
  %t97 = extractvalue { i64, ptr } %t96, 1
  call void @__olang_region_release(ptr %t97)
  store { i64, ptr } zeroinitializer, ptr %l57
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t99 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t99, ptr %rv
  br label %ret
bb23:
  %t100 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 40, i64 8)
  store ptr %t100, ptr %lp13
  %t101 = load %"std/os:Output", ptr %l49
  %t102 = load ptr, ptr %lp13
  store %"std/os:Output" %t101, ptr %t102
  %t103 = load ptr, ptr %lp13
  %t104 = getelementptr %"std/os:Output", ptr %t103, i32 0, i32 1
  %t105 = load { i64, ptr }, ptr %t104, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t105, 0
  %t109 = icmp eq i64 %t107, 0
  br i1 %t109, label %bb24, label %bb25
bb24:
  %t111 = load ptr, ptr %l0, !tbaa !29
  store ptr %t111, ptr %l63, !tbaa !29
  %t112 = call ptr @__olang_scope_hold(ptr %v0)
  %t113 = ptrtoint ptr %t112 to i64
  store i64 %t113, ptr %l64, !tbaa !24
  %t114 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3agen_2e26
  br i1 %t114, label %bb26, label %bb27
bb25:
  br label %bb32
bb26:
  %t116 = call ptr @__olang_region_make(ptr %v0)
  %t117 = ptrtoint ptr %t116 to i64
  store i64 %t117, ptr %l64, !tbaa !24
  br label %bb27
bb27:
  %t118 = load ptr, ptr %lp13
  %t119 = getelementptr %"std/os:Output", ptr %t118, i32 0, i32 2
  %t120 = load { i64, ptr }, ptr %t119, !tbaa !27
  %t121 = load i64, ptr %l64
  %t122 = inttoptr i64 %t121 to ptr
  %t124 = call { i64, ptr } @compiler_2fbindgen_2efirstError(ptr %v4, ptr %t122, { i64, ptr } %t120)
  store { i64, ptr } %t124, ptr %l67
  br label %bb28
bb28:
  %t125 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t126 = load ptr, ptr %l63, !tbaa !29
  %t128 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %v0, ptr %t126, { i64, ptr } %t125)
  store i32 %t128, ptr %l69
  %t129 = icmp ne i32 %t128, 0
  br i1 %t129, label %bb30, label %ok.130, !prof !99
ok.130:
  br label %bb29
bb29:
  br label %bb31
bb30:
  %t131 = load i32, ptr %l69, !tbaa !23
  %t132 = lshr i32 %t131, 16
  %t133 = and i32 %t131, 65535
  %t134 = icmp eq i32 %t132, 1
  %t135 = select i1 %t134, i32 1, i32 0
  %t136 = icmp eq i32 %t131, 0
  %t137 = shl i32 %t135, 16
  %t138 = or i32 %t137, %t133
  %t139 = select i1 %t136, i32 0, i32 %t138
  call void @__olang_scope_close(ptr %s0)
  %t141 = insertvalue { i32, ptr } zeroinitializer, i32 %t139, 0
  store { i32, ptr } %t141, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  %t142 = load ptr, ptr %lp13
  %t143 = getelementptr %"std/os:Output", ptr %t142, i32 0, i32 1
  %t144 = load { i64, ptr }, ptr %t143, !tbaa !27
  %t146 = call { i32, ptr } @std_2fjson_2eJson_2eParse(ptr %v4, ptr %v4, { i64, ptr } %t144)
  %t147 = extractvalue { i32, ptr } %t146, 1
  %t148 = extractvalue { i32, ptr } %t146, 0
  store i32 %t148, ptr %l74
  %t149 = icmp ne i32 %t148, 0
  br i1 %t149, label %bb34, label %ok.150, !prof !99
ok.150:
  store ptr %t147, ptr %l73
  br label %bb33
bb33:
  %t151 = load ptr, ptr %l73, !tbaa !29
  store ptr %t151, ptr %l71, !tbaa !29
  br label %bb40
bb34:
  %t152 = load i32, ptr %l74, !tbaa !23
  %t153 = ashr i32 %t152, 16
  %t155 = icmp eq i32 %t153, 1
  store i1 %t155, ptr %l76, !tbaa !21
  %t156 = load i32, ptr %l74, !tbaa !23
  %t157 = ashr i32 %t156, 16
  %t159 = icmp eq i32 %t157, 1
  br i1 %t159, label %bb35, label %bb36
bb35:
  call void @__olang_errpay_pop()
  br label %bb36
bb36:
  br label %bb37
bb37:
  %t161 = load ptr, ptr %l0, !tbaa !29
  store ptr %t161, ptr %l79, !tbaa !29
  %t162 = load ptr, ptr %l79, !tbaa !29
  %t163 = getelementptr %"compiler/bindgen:gen", ptr %t162, i32 0, i32 26
  %t164 = load { i64, ptr }, ptr %t163, !tbaa !27
  store { i64, ptr } %t164, ptr %l80, !tbaa !27
  %t165 = load ptr, ptr %l79, !tbaa !29
  %t166 = getelementptr %"compiler/bindgen:gen", ptr %t165, i32 0, i32 26
  store { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d150, i32 0, i32 1) }, ptr %t166, !tbaa !27
  %t167 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3agen_2e26
  br i1 %t167, label %bb38, label %bb39
bb38:
  %t169 = load { i64, ptr }, ptr %l80
  %t170 = extractvalue { i64, ptr } %t169, 1
  call void @__olang_region_release(ptr %t170)
  store { i64, ptr } zeroinitializer, ptr %l80
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s0)
  %t172 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t172, ptr %rv
  br label %ret
bb40:
  call void @__olang_scope_close(ptr %s0)
  %t173 = load ptr, ptr %l71, !tbaa !29
  %t174 = insertvalue { i32, ptr } zeroinitializer, ptr %t173, 1
  store { i32, ptr } %t174, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eexpand(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, ptr %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %lp9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i64
  %lp13 = alloca ptr
  %lp14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %lp18 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca i64
  %l33 = alloca i32
  %l35 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l41 = alloca { i64, ptr }
  %l45 = alloca i1
  %l46 = alloca i1
  %l48 = alloca i1
  %l50 = alloca i32
  %l52 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i32
  %l60 = alloca i1
  %l64 = alloca %"compiler/bindgen:cMacro"
  %l66 = alloca i1
  %l67 = alloca i1
  %l71 = alloca i1
  %l80 = alloca %"compiler/bindgen:cMacro"
  %l90 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l91 = alloca i32
  %l94 = alloca i64
  %l96 = alloca i64
  %l101 = alloca { i64, ptr }
  %l107 = alloca { i64, ptr }
  %l109 = alloca { i64, ptr }
  %l110 = alloca i32
  %l120 = alloca i1
  %l121 = alloca { i64, ptr }
  %l125 = alloca i1
  %l133 = alloca ptr
  %l134 = alloca i64
  %l139 = alloca i32
  %l141 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l142 = alloca i64
  %l144 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l153 = alloca { i64, ptr }
  %l157 = alloca i1
  %l162 = alloca i1
  %l169 = alloca i1
  %l170 = alloca i1
  %l173 = alloca ptr
  %l174 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l176 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l177 = alloca i64
  %l179 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l181 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l193 = alloca ptr
  %l194 = alloca i64
  %l199 = alloca i32
  %l202 = alloca i64
  %l204 = alloca i1
  %l206 = alloca i64
  %l208 = alloca ptr
  %l209 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l211 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l213 = alloca i64
  %l217 = alloca ptr
  %l218 = alloca i64
  %l223 = alloca i32
  %l225 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l233 = alloca { i64, ptr }
  %l236 = alloca i64
  %l240 = alloca i64
  %l241 = alloca i32
  %l247 = alloca ptr
  %l250 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l252 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l254 = alloca { i64, ptr }
  %l258 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l259 = alloca i32
  %l262 = alloca i64
  %l264 = alloca i64
  %l269 = alloca { i64, ptr }
  %l281 = alloca ptr
  %l283 = alloca { i64, ptr }
  %l287 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l288 = alloca i32
  %l291 = alloca i64
  %l293 = alloca i64
  %l298 = alloca { i64, ptr }
  %l304 = alloca { i64, ptr }
  %l306 = alloca { i64, ptr }
  %l307 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %rv = alloca { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
  %t574 = alloca { { i64, ptr }, ptr }, align 8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l3, !tbaa !24
  %t3 = icmp sgt i64 %t1, 64
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %v0, ptr %t5, { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d151, i32 0, i32 1) })
  store i32 %t7, ptr %l33
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb4, label %ok.9, !prof !99
ok.9:
  br label %bb3
bb2:
  br label %bb6
bb3:
  br label %bb5
bb4:
  %t10 = load i32, ptr %l33, !tbaa !23
  %t11 = lshr i32 %t10, 16
  %t12 = and i32 %t10, 65535
  %t13 = icmp eq i32 %t11, 1
  %t14 = select i1 %t13, i32 1, i32 0
  %t15 = icmp eq i32 %t10, 0
  %t16 = shl i32 %t14, 16
  %t17 = or i32 %t16, %t12
  %t18 = select i1 %t15, i32 0, i32 %t17
  call void @__olang_scope_close(ptr %s0)
  %t20 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 %t18, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t20, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t21 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %l35
  br label %bb7
bb7:
  %t22 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l35
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t22, ptr %l4
  store i64 0, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t23 = load i64, ptr %l5, !tbaa !24
  %t24 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t29 = icmp slt i64 %t23, %t26
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb201
bb10:
  br label %bb11
bb11:
  %t33 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t33, ptr %l41, !tbaa !27
  %t34 = load i64, ptr %l5, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %t37, i64 %t34
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !37
  store { i64, ptr } %t39, ptr %l6, !tbaa !27
  %t41 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t43 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s2, { i64, ptr } %t41, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d152, i32 0, i32 1) })
  store i1 %t43, ptr %l45
  br label %bb12
bb12:
  %t44 = load i1, ptr %l45, !tbaa !21
  br i1 %t44, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb16
bb14:
  %t45 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t47 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s2, { i64, ptr } %t45, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d153, i32 0, i32 1) })
  store i1 %t47, ptr %l48
  br label %bb15
bb15:
  %t48 = load i1, ptr %l48, !tbaa !21
  store i1 %t48, ptr %l46, !tbaa !21
  br label %bb16
bb16:
  %t49 = load i1, ptr %l46, !tbaa !21
  br i1 %t49, label %bb17, label %bb18
bb17:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %v0, ptr %t50, { i64, ptr } { i64 58, ptr getelementptr inbounds (<{ i64, [58 x i8] }>, ptr @.d154, i32 0, i32 1) })
  store i32 %t52, ptr %l50
  %t53 = icmp ne i32 %t52, 0
  br i1 %t53, label %bb20, label %ok.54, !prof !99
ok.54:
  br label %bb19
bb18:
  br label %bb22
bb19:
  br label %bb21
bb20:
  %t55 = load i32, ptr %l50, !tbaa !23
  %t56 = lshr i32 %t55, 16
  %t57 = and i32 %t55, 65535
  %t58 = icmp eq i32 %t56, 1
  %t59 = select i1 %t58, i32 1, i32 0
  %t60 = icmp eq i32 %t55, 0
  %t61 = shl i32 %t59, 16
  %t62 = or i32 %t61, %t57
  %t63 = select i1 %t60, i32 0, i32 %t62
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t65 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 %t63, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t65, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/bindgen:gen", ptr %t66, i32 0, i32 14
  %t69 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t72 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v1, ptr %t68, { i64, ptr } %t69)
  %t73 = extractvalue { i32, i64 } %t72, 1
  %t74 = extractvalue { i32, i64 } %t72, 0
  store i32 %t74, ptr %l57
  %t75 = icmp ne i32 %t74, 0
  br i1 %t75, label %bb24, label %ok.76, !prof !99
ok.76:
  store i64 %t73, ptr %l56
  br label %bb23
bb23:
  %t77 = load i64, ptr %l56, !tbaa !24
  store i64 %t77, ptr %l52, !tbaa !24
  br label %bb26
bb24:
  br label %bb25
bb25:
  store i64 -1, ptr %l52, !tbaa !24
  br label %bb26
bb26:
  %t78 = load i64, ptr %l52, !tbaa !24
  store i64 %t78, ptr %l7, !tbaa !24
  %t79 = load i64, ptr %l7, !tbaa !24
  %t81 = icmp slt i64 %t79, 0
  br i1 %t81, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb31
bb28:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/bindgen:gen", ptr %t83, i32 0, i32 13
  %t86 = load i64, ptr %l7, !tbaa !24
  %t89 = call %"compiler/bindgen:cMacro" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acMacro_3e_2eAt_3ccompiler_2fbindgen_3acMacro_3e(ptr %v0, ptr %v0, ptr %t85, i64 %t86)
  store %"compiler/bindgen:cMacro" %t89, ptr %l64
  br label %bb29
bb29:
  %t90 = getelementptr %"compiler/bindgen:cMacro", ptr %l64, i32 0, i32 0
  %t91 = load { i64, ptr }, ptr %t90, !tbaa !27
  %t93 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t91, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d155, i32 0, i32 1) })
  store i1 %t93, ptr %l66
  br label %bb30
bb30:
  %t94 = load i1, ptr %l66, !tbaa !21
  store i1 %t94, ptr %l60, !tbaa !21
  br label %bb31
bb31:
  %t95 = load i1, ptr %l60, !tbaa !21
  br i1 %t95, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l67, !tbaa !21
  br label %bb35
bb33:
  %t96 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t98 = load ptr, ptr %l2, !tbaa !29
  %t102 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H0127831368543eff3b7740d7d3240080(ptr %v2, ptr %v1, ptr %t98, { i64, ptr } %t96)
  store i1 %t102, ptr %l71
  br label %bb34
bb34:
  %t103 = load i1, ptr %l71, !tbaa !21
  store i1 %t103, ptr %l67, !tbaa !21
  br label %bb35
bb35:
  %t104 = load i1, ptr %l67, !tbaa !21
  br i1 %t104, label %bb36, label %bb37
bb36:
  %t105 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v3, ptr %v1, ptr %l4, { i64, ptr } %t105)
  br label %bb38
bb37:
  br label %bb39
bb38:
  %t108 = load i64, ptr %l5, !tbaa !24
  %t111 = add i64 %t108, 1
  store i64 %t111, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb200
bb39:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/bindgen:gen", ptr %t113, i32 0, i32 13
  %t116 = load i64, ptr %l7, !tbaa !24
  %t119 = call %"compiler/bindgen:cMacro" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acMacro_3e_2eAt_3ccompiler_2fbindgen_3acMacro_3e(ptr %v0, ptr %v3, ptr %t115, i64 %t116)
  store %"compiler/bindgen:cMacro" %t119, ptr %l80
  br label %bb40
bb40:
  %t120 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 64, i64 8)
  store ptr %t120, ptr %lp9
  %t121 = load %"compiler/bindgen:cMacro", ptr %l80
  %t122 = load ptr, ptr %lp9
  store %"compiler/bindgen:cMacro" %t121, ptr %t122
  %t123 = load ptr, ptr %lp9
  %t124 = getelementptr %"compiler/bindgen:cMacro", ptr %t123, i32 0, i32 1
  %t125 = load i1, ptr %t124, !tbaa !21
  %t127 = xor i1 %t125, true
  br i1 %t127, label %bb41, label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s5
  %t129 = load ptr, ptr %l2, !tbaa !29
  %t130 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v2, ptr %v1, ptr %t129, { i64, ptr } %t130)
  br label %bb43
bb42:
  br label %bb62
bb43:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load ptr, ptr %lp9
  %t135 = getelementptr %"compiler/bindgen:cMacro", ptr %t134, i32 0, i32 3
  %t136 = load { i64, ptr }, ptr %t135, !tbaa !27
  %t137 = load ptr, ptr %l2, !tbaa !29
  %t138 = load i64, ptr %l3, !tbaa !24
  %t140 = add i64 %t138, 1
  %t145 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eexpand(ptr %v0, ptr %v3, ptr %v2, ptr %v3, ptr %t133, { i64, ptr } %t136, ptr %t137, i64 %t140)
  %t146 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t145, 1
  %t147 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t145, 0
  store i32 %t147, ptr %l91
  %t148 = icmp ne i32 %t147, 0
  br i1 %t148, label %bb45, label %ok.149, !prof !99
ok.149:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t146, ptr %l90
  br label %bb44
bb44:
  %t150 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l90
  %t151 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t150, ptr %t151
  store ptr %t151, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb46
bb45:
  %t153 = load i32, ptr %l91, !tbaa !23
  %t154 = lshr i32 %t153, 16
  %t155 = and i32 %t153, 65535
  %t156 = icmp eq i32 %t154, 1
  %t157 = select i1 %t156, i32 1, i32 0
  %t158 = icmp eq i32 %t153, 0
  %t159 = shl i32 %t157, 16
  %t160 = or i32 %t159, %t155
  %t161 = select i1 %t158, i32 0, i32 %t160
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t163 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 %t161, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t163, ptr %rv
  br label %ret
bb46:
  %t164 = load i64, ptr %l11, !tbaa !24
  store i64 %t164, ptr %l94, !tbaa !24
  %t165 = load ptr, ptr %l10, !tbaa !29
  %t167 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v3, ptr %t165)
  store i64 %t167, ptr %l96
  br label %bb47
bb47:
  %t168 = load i64, ptr %l94, !tbaa !24
  %t169 = load i64, ptr %l96, !tbaa !24
  %t170 = icmp slt i64 %t168, %t169
  %t172 = xor i1 %t170, true
  br i1 %t172, label %bb48, label %bb49
bb48:
  br label %bb54
bb49:
  br label %bb50
bb50:
  %t174 = load ptr, ptr %l10, !tbaa !29
  %t175 = load i64, ptr %l11, !tbaa !24
  %t178 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v3, ptr %v3, ptr %t174, i64 %t175)
  store { i64, ptr } %t178, ptr %l101
  br label %bb51
bb51:
  %t179 = load { i64, ptr }, ptr %l101, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v3, ptr %v3, ptr %l4, { i64, ptr } %t179)
  br label %bb52
bb52:
  br label %bb53
bb53:
  %t183 = load i64, ptr %l11, !tbaa !24
  %t186 = add i64 %t183, 1
  store i64 %t186, ptr %l11, !tbaa !24
  br label %bb46
bb54:
  br label %bb55
bb55:
  %t188 = load ptr, ptr %l2, !tbaa !29
  %t190 = call { i32, { i64, ptr } } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_Hdc04e7543082eec80486670259c0789b(ptr %v2, ptr %s5, ptr %t188)
  %t191 = extractvalue { i32, { i64, ptr } } %t190, 1
  %t192 = extractvalue { i32, { i64, ptr } } %t190, 0
  store i32 %t192, ptr %l110
  %t193 = icmp ne i32 %t192, 0
  br i1 %t193, label %bb57, label %ok.194, !prof !99
ok.194:
  store { i64, ptr } %t191, ptr %l109
  br label %bb56
bb56:
  %t195 = load { i64, ptr }, ptr %l109, !tbaa !27
  store { i64, ptr } %t195, ptr %l107, !tbaa !27
  %t196 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t196, label %bb59, label %bb60
bb57:
  br label %bb58
bb58:
  br label %bb61
bb59:
  %t198 = load { i64, ptr }, ptr %l107
  %t199 = extractvalue { i64, ptr } %t198, 1
  call void @__olang_region_release(ptr %t199)
  store { i64, ptr } zeroinitializer, ptr %l107
  br label %bb60
bb60:
  br label %bb61
bb61:
  %t200 = load i64, ptr %l5, !tbaa !24
  %t203 = add i64 %t200, 1
  store i64 %t203, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s2)
  br label %bb200
bb62:
  %t205 = load i64, ptr %l5, !tbaa !24
  %t207 = add i64 %t205, 1
  %t208 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t210 = extractvalue { i64, ptr } %t208, 0
  %t213 = icmp sge i64 %t207, %t210
  br i1 %t213, label %bb63, label %bb64
bb63:
  store i1 true, ptr %l120, !tbaa !21
  br label %bb66
bb64:
  %t215 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t215, ptr %l121, !tbaa !27
  %t216 = load i64, ptr %l5, !tbaa !24
  %t218 = add i64 %t216, 1
  %t220 = getelementptr { i64, ptr }, ptr %l121, i32 0, i32 1
  %t221 = load ptr, ptr %t220, !tbaa !27
  %t222 = getelementptr { i64, ptr }, ptr %t221, i64 %t218
  %t223 = load { i64, ptr }, ptr %t222, !tbaa !37
  %t225 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s2, { i64, ptr } %t223, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d156, i32 0, i32 1) })
  store i1 %t225, ptr %l125
  br label %bb65
bb65:
  %t226 = load i1, ptr %l125, !tbaa !21
  %t227 = xor i1 %t226, true
  store i1 %t227, ptr %l120, !tbaa !21
  br label %bb66
bb66:
  %t229 = load i1, ptr %l120, !tbaa !21
  br i1 %t229, label %bb67, label %bb68
bb67:
  %t230 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v3, ptr %v1, ptr %l4, { i64, ptr } %t230)
  br label %bb69
bb68:
  br label %bb70
bb69:
  %t233 = load i64, ptr %l5, !tbaa !24
  %t236 = add i64 %t233, 1
  store i64 %t236, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb200
bb70:
  %t238 = load ptr, ptr %lp9
  %t239 = getelementptr %"compiler/bindgen:cMacro", ptr %t238, i32 0, i32 5
  %t240 = load i1, ptr %t239, !tbaa !21
  br i1 %t240, label %bb71, label %bb72
bb71:
  %t242 = load ptr, ptr %l0, !tbaa !29
  store ptr %t242, ptr %l133, !tbaa !29
  %t243 = call ptr @__olang_scope_hold(ptr %v0)
  %t244 = ptrtoint ptr %t243 to i64
  store i64 %t244, ptr %l134, !tbaa !24
  %t245 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3agen_2e26
  br i1 %t245, label %bb73, label %bb74
bb72:
  br label %bb78
bb73:
  %t247 = call ptr @__olang_region_make(ptr %v0)
  %t248 = ptrtoint ptr %t247 to i64
  store i64 %t248, ptr %l134, !tbaa !24
  br label %bb74
bb74:
  %t249 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t250 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d157, i32 0, i32 1) }, 1
  %t251 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d157, i32 0, i32 1) }, 0
  %t253 = extractvalue { i64, ptr } %t249, 1
  %t254 = extractvalue { i64, ptr } %t249, 0
  %t255 = add i64 %t251, %t254
  %t256 = extractvalue { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d158, i32 0, i32 1) }, 1
  %t257 = extractvalue { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d158, i32 0, i32 1) }, 0
  %t258 = add i64 %t255, %t257
  %t259 = load i64, ptr %l134
  %t260 = inttoptr i64 %t259 to ptr
  %t261 = call ptr @__olang_held_alloc(ptr %t260, i64 %t258)
  call void @olang_textcopy(ptr %t261, ptr %t250, i64 %t251)
  %t262 = getelementptr i8, ptr %t261, i64 %t251
  call void @olang_textcopy(ptr %t262, ptr %t253, i64 %t254)
  %t263 = getelementptr i8, ptr %t262, i64 %t254
  call void @olang_textcopy(ptr %t263, ptr %t256, i64 %t257)
  %t264 = insertvalue { i64, ptr } undef, i64 %t258, 0
  %t265 = insertvalue { i64, ptr } %t264, ptr %t261, 1
  %t267 = load ptr, ptr %l133, !tbaa !29
  %t269 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %v0, ptr %t267, { i64, ptr } %t265)
  store i32 %t269, ptr %l139
  %t270 = icmp ne i32 %t269, 0
  br i1 %t270, label %bb76, label %ok.271, !prof !99
ok.271:
  br label %bb75
bb75:
  br label %bb77
bb76:
  %t272 = load i32, ptr %l139, !tbaa !23
  %t273 = lshr i32 %t272, 16
  %t274 = and i32 %t272, 65535
  %t275 = icmp eq i32 %t273, 1
  %t276 = select i1 %t275, i32 1, i32 0
  %t277 = icmp eq i32 %t272, 0
  %t278 = shl i32 %t276, 16
  %t279 = or i32 %t278, %t274
  %t280 = select i1 %t277, i32 0, i32 %t279
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t282 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 %t280, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t282, ptr %rv
  br label %ret
bb77:
  br label %bb78
bb78:
  %t283 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t283, ptr %l141
  br label %bb79
bb79:
  %t284 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 32, i64 8)
  store ptr %t284, ptr %lp13
  %t285 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l141
  %t286 = load ptr, ptr %lp13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t285, ptr %t286
  %t287 = call ptr @__olang_scope_hold(ptr %v3)
  %t288 = ptrtoint ptr %t287 to i64
  store i64 %t288, ptr %l142, !tbaa !24
  %t289 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2ecompiler__2fbindgen__3agen__2eexpand_2elocal_2e14
  br i1 %t289, label %bb80, label %bb81
bb80:
  %t291 = call ptr @__olang_region_make(ptr %v3)
  %t292 = ptrtoint ptr %t291 to i64
  store i64 %t292, ptr %l142, !tbaa !24
  br label %bb81
bb81:
  %t293 = load i64, ptr %l142
  %t294 = inttoptr i64 %t293 to ptr
  %t295 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t294, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t295, ptr %l144
  br label %bb82
bb82:
  %t296 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2ecompiler__2fbindgen__3agen__2eexpand_2elocal_2e14
  br i1 %t296, label %bb83, label %bb84
bb83:
  %t298 = load i64, ptr %l142
  %t299 = inttoptr i64 %t298 to ptr
  %t300 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l144, i32 0, i32 0
  %t301 = load { i64, ptr }, ptr %t300
  %t302 = extractvalue { i64, ptr } %t301, 1
  %t303 = call ptr @__olang_region_or(ptr %t302, ptr null)
  %t304 = call ptr @__olang_region_home(ptr %t303)
  %t305 = icmp ne ptr %t304, null
  %t306 = select i1 %t305, ptr %t304, ptr null
  call void @__olang_region_settle_in(ptr %t299, ptr %t306)
  br label %bb84
bb84:
  %t307 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 32, i64 8)
  store ptr %t307, ptr %lp14
  %t308 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l144
  %t309 = load ptr, ptr %lp14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t308, ptr %t309
  store i64 0, ptr %l15, !tbaa !24
  %t310 = load i64, ptr %l5, !tbaa !24
  %t312 = add i64 %t310, 2
  store i64 %t312, ptr %l16, !tbaa !24
  br label %bb85
bb85:
  store %olang.scope zeroinitializer, ptr %s13
  %t314 = load i64, ptr %l16, !tbaa !24
  %t315 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t317 = extractvalue { i64, ptr } %t315, 0
  %t320 = icmp slt i64 %t314, %t317
  %t322 = xor i1 %t320, true
  br i1 %t322, label %bb86, label %bb87
bb86:
  call void @__olang_scope_close(ptr %s13)
  br label %bb120
bb87:
  br label %bb88
bb88:
  %t324 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t324, ptr %l153, !tbaa !27
  %t325 = load i64, ptr %l16, !tbaa !24
  %t327 = getelementptr { i64, ptr }, ptr %l153, i32 0, i32 1
  %t328 = load ptr, ptr %t327, !tbaa !27
  %t329 = getelementptr { i64, ptr }, ptr %t328, i64 %t325
  %t330 = load { i64, ptr }, ptr %t329, !tbaa !37
  store { i64, ptr } %t330, ptr %l17, !tbaa !27
  %t332 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t334 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s13, { i64, ptr } %t332, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d159, i32 0, i32 1) })
  store i1 %t334, ptr %l157
  br label %bb89
bb89:
  %t335 = load i1, ptr %l157, !tbaa !21
  br i1 %t335, label %bb90, label %bb91
bb90:
  %t336 = load i64, ptr %l15, !tbaa !24
  %t339 = add i64 %t336, 1
  store i64 %t339, ptr %l15, !tbaa !24
  br label %bb92
bb91:
  br label %bb92
bb92:
  %t341 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t343 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s13, { i64, ptr } %t341, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d160, i32 0, i32 1) })
  store i1 %t343, ptr %l162
  br label %bb93
bb93:
  %t344 = load i1, ptr %l162, !tbaa !21
  br i1 %t344, label %bb94, label %bb95
bb94:
  %t345 = load i64, ptr %l15, !tbaa !24
  %t347 = icmp eq i64 %t345, 0
  br i1 %t347, label %bb96, label %bb97
bb95:
  br label %bb99
bb96:
  call void @__olang_scope_close(ptr %s13)
  br label %bb120
bb97:
  br label %bb98
bb98:
  %t349 = load i64, ptr %l15, !tbaa !24
  %t352 = sub i64 %t349, 1
  store i64 %t352, ptr %l15, !tbaa !24
  br label %bb99
bb99:
  %t354 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t356 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s13, { i64, ptr } %t354, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d161, i32 0, i32 1) })
  store i1 %t356, ptr %l169
  br label %bb100
bb100:
  %t357 = load i1, ptr %l169, !tbaa !21
  br i1 %t357, label %bb101, label %bb102
bb101:
  %t358 = load i64, ptr %l15, !tbaa !24
  %t360 = icmp eq i64 %t358, 0
  store i1 %t360, ptr %l170, !tbaa !21
  br label %bb103
bb102:
  store i1 false, ptr %l170, !tbaa !21
  br label %bb103
bb103:
  %t362 = load i1, ptr %l170, !tbaa !21
  br i1 %t362, label %bb104, label %bb105
bb104:
  store %olang.scope zeroinitializer, ptr %s17
  %t363 = load ptr, ptr %lp13
  store ptr %t363, ptr %l173, !tbaa !29
  %t364 = load ptr, ptr %lp14
  %t365 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t364
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t365, ptr %l174
  %t367 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %s17, ptr %l174)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t367, ptr %l176
  br label %bb106
bb105:
  %t368 = load ptr, ptr %lp14
  %t369 = load { i64, ptr }, ptr %l17, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v3, ptr %v1, ptr %t368, { i64, ptr } %t369)
  br label %bb117
bb106:
  %t372 = load ptr, ptr %l173, !tbaa !29
  %t373 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l176
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cstd_2fprel_H40771be639b3022d183b79789a9eab56(ptr %v3, ptr %v3, ptr %t372, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t373)
  br label %bb107
bb107:
  %t374 = call ptr @__olang_scope_hold(ptr %v3)
  %t375 = ptrtoint ptr %t374 to i64
  store i64 %t375, ptr %l177, !tbaa !24
  %t376 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2ecompiler__2fbindgen__3agen__2eexpand_2elocal_2e14
  br i1 %t376, label %bb108, label %bb109
bb108:
  %t378 = call ptr @__olang_region_make(ptr %v3)
  %t379 = ptrtoint ptr %t378 to i64
  store i64 %t379, ptr %l177, !tbaa !24
  br label %bb109
bb109:
  %t380 = load i64, ptr %l177
  %t381 = inttoptr i64 %t380 to ptr
  %t382 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t381, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t382, ptr %l179
  br label %bb110
bb110:
  %t383 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2ecompiler__2fbindgen__3agen__2eexpand_2elocal_2e14
  br i1 %t383, label %bb111, label %bb112
bb111:
  %t385 = load i64, ptr %l177
  %t386 = inttoptr i64 %t385 to ptr
  %t387 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l179, i32 0, i32 0
  %t388 = load { i64, ptr }, ptr %t387
  %t389 = extractvalue { i64, ptr } %t388, 1
  %t390 = call ptr @__olang_region_or(ptr %t389, ptr null)
  %t391 = call ptr @__olang_region_home(ptr %t390)
  %t392 = icmp ne ptr %t391, null
  %t393 = select i1 %t392, ptr %t391, ptr null
  call void @__olang_region_settle_in(ptr %t386, ptr %t393)
  br label %bb112
bb112:
  %t394 = load ptr, ptr %lp14
  %t395 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t394
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t395, ptr %l181
  %t396 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l179
  %t397 = load ptr, ptr %lp14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t396, ptr %t397
  %t398 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2ecompiler__2fbindgen__3agen__2eexpand_2elocal_2e14
  br i1 %t398, label %bb113, label %bb114
bb113:
  %t400 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l181, i32 0, i32 0
  %t401 = load { i64, ptr }, ptr %t400
  %t402 = extractvalue { i64, ptr } %t401, 1
  %t403 = call ptr @__olang_region_or(ptr %t402, ptr null)
  %t404 = call ptr @__olang_region_home(ptr %t403)
  %t405 = icmp ne ptr %t404, null
  %t406 = select i1 %t405, ptr %t404, ptr null
  call void @__olang_region_drop(ptr %t406)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l181
  br label %bb114
bb114:
  %t407 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t407, label %bb115, label %bb116
bb115:
  %t409 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l181, i32 0, i32 0
  %t410 = load { i64, ptr }, ptr %t409
  %t411 = extractvalue { i64, ptr } %t410, 0
  %t412 = extractvalue { i64, ptr } %t410, 1
  call void @__olang_region_release_part(ptr %t412, i64 %t411)
  store { i64, ptr } zeroinitializer, ptr %t409
  br label %bb116
bb116:
  call void @__olang_scope_close(ptr %s17)
  br label %bb118
bb117:
  br label %bb118
bb118:
  %t413 = load i64, ptr %l16, !tbaa !24
  %t416 = add i64 %t413, 1
  store i64 %t416, ptr %l16, !tbaa !24
  call void @__olang_scope_close(ptr %s13)
  br label %bb119
bb119:
  br label %bb85
bb120:
  %t418 = load i64, ptr %l16, !tbaa !24
  %t419 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t421 = extractvalue { i64, ptr } %t419, 0
  %t424 = icmp sge i64 %t418, %t421
  br i1 %t424, label %bb121, label %bb122
bb121:
  %t426 = load ptr, ptr %l0, !tbaa !29
  store ptr %t426, ptr %l193, !tbaa !29
  %t427 = call ptr @__olang_scope_hold(ptr %v0)
  %t428 = ptrtoint ptr %t427 to i64
  store i64 %t428, ptr %l194, !tbaa !24
  %t429 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3agen_2e26
  br i1 %t429, label %bb123, label %bb124
bb122:
  br label %bb128
bb123:
  %t431 = call ptr @__olang_region_make(ptr %v0)
  %t432 = ptrtoint ptr %t431 to i64
  store i64 %t432, ptr %l194, !tbaa !24
  br label %bb124
bb124:
  %t433 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t434 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d162, i32 0, i32 1) }, 1
  %t435 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d162, i32 0, i32 1) }, 0
  %t437 = extractvalue { i64, ptr } %t433, 1
  %t438 = extractvalue { i64, ptr } %t433, 0
  %t439 = add i64 %t435, %t438
  %t440 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d163, i32 0, i32 1) }, 1
  %t441 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d163, i32 0, i32 1) }, 0
  %t442 = add i64 %t439, %t441
  %t443 = load i64, ptr %l194
  %t444 = inttoptr i64 %t443 to ptr
  %t445 = call ptr @__olang_held_alloc(ptr %t444, i64 %t442)
  call void @olang_textcopy(ptr %t445, ptr %t434, i64 %t435)
  %t446 = getelementptr i8, ptr %t445, i64 %t435
  call void @olang_textcopy(ptr %t446, ptr %t437, i64 %t438)
  %t447 = getelementptr i8, ptr %t446, i64 %t438
  call void @olang_textcopy(ptr %t447, ptr %t440, i64 %t441)
  %t448 = insertvalue { i64, ptr } undef, i64 %t442, 0
  %t449 = insertvalue { i64, ptr } %t448, ptr %t445, 1
  %t451 = load ptr, ptr %l193, !tbaa !29
  %t453 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %v0, ptr %t451, { i64, ptr } %t449)
  store i32 %t453, ptr %l199
  %t454 = icmp ne i32 %t453, 0
  br i1 %t454, label %bb126, label %ok.455, !prof !99
ok.455:
  br label %bb125
bb125:
  br label %bb127
bb126:
  %t456 = load i32, ptr %l199, !tbaa !23
  %t457 = lshr i32 %t456, 16
  %t458 = and i32 %t456, 65535
  %t459 = icmp eq i32 %t457, 1
  %t460 = select i1 %t459, i32 1, i32 0
  %t461 = icmp eq i32 %t456, 0
  %t462 = shl i32 %t460, 16
  %t463 = or i32 %t462, %t458
  %t464 = select i1 %t461, i32 0, i32 %t463
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t466 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 %t464, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t466, ptr %rv
  br label %ret
bb127:
  br label %bb128
bb128:
  %t467 = load ptr, ptr %lp14
  %t469 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v3, ptr %t467)
  store i64 %t469, ptr %l202
  br label %bb129
bb129:
  %t470 = load i64, ptr %l202, !tbaa !24
  %t471 = icmp sgt i64 %t470, 0
  br i1 %t471, label %bb130, label %bb131
bb130:
  store i1 true, ptr %l204, !tbaa !21
  br label %bb133
bb131:
  %t473 = load ptr, ptr %lp13
  %t475 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cstd_2fprel_Hbb0b9cf8ae0bb786ffc6cf28ae45ef64(ptr %v3, ptr %t473)
  store i64 %t475, ptr %l206
  br label %bb132
bb132:
  %t476 = load i64, ptr %l206, !tbaa !24
  %t477 = icmp sgt i64 %t476, 0
  store i1 %t477, ptr %l204, !tbaa !21
  br label %bb133
bb133:
  %t479 = load i1, ptr %l204, !tbaa !21
  br i1 %t479, label %bb134, label %bb135
bb134:
  store %olang.scope zeroinitializer, ptr %s21
  %t480 = load ptr, ptr %lp13
  store ptr %t480, ptr %l208, !tbaa !29
  %t481 = load ptr, ptr %lp14
  %t482 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t481
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t482, ptr %l209
  %t484 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %s21, ptr %l209)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t484, ptr %l211
  br label %bb136
bb135:
  br label %bb138
bb136:
  %t485 = load ptr, ptr %l208, !tbaa !29
  %t486 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l211
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cstd_2fprel_H40771be639b3022d183b79789a9eab56(ptr %v3, ptr %v3, ptr %t485, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t486)
  br label %bb137
bb137:
  call void @__olang_scope_close(ptr %s21)
  br label %bb138
bb138:
  %t487 = load ptr, ptr %lp13
  %t489 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cstd_2fprel_Hbb0b9cf8ae0bb786ffc6cf28ae45ef64(ptr %v3, ptr %t487)
  store i64 %t489, ptr %l213
  br label %bb139
bb139:
  %t490 = load ptr, ptr %lp9
  %t491 = getelementptr %"compiler/bindgen:cMacro", ptr %t490, i32 0, i32 2
  %t492 = load { i64, ptr }, ptr %t491, !tbaa !27
  %t494 = extractvalue { i64, ptr } %t492, 0
  %t495 = load i64, ptr %l213, !tbaa !24
  %t497 = icmp ne i64 %t495, %t494
  br i1 %t497, label %bb140, label %bb141
bb140:
  %t499 = load ptr, ptr %l0, !tbaa !29
  store ptr %t499, ptr %l217, !tbaa !29
  %t500 = call ptr @__olang_scope_hold(ptr %v0)
  %t501 = ptrtoint ptr %t500 to i64
  store i64 %t501, ptr %l218, !tbaa !24
  %t502 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3agen_2e26
  br i1 %t502, label %bb142, label %bb143
bb141:
  br label %bb147
bb142:
  %t504 = call ptr @__olang_region_make(ptr %v0)
  %t505 = ptrtoint ptr %t504 to i64
  store i64 %t505, ptr %l218, !tbaa !24
  br label %bb143
bb143:
  %t506 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t507 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d164, i32 0, i32 1) }, 1
  %t508 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d164, i32 0, i32 1) }, 0
  %t510 = extractvalue { i64, ptr } %t506, 1
  %t511 = extractvalue { i64, ptr } %t506, 0
  %t512 = add i64 %t508, %t511
  %t513 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d165, i32 0, i32 1) }, 1
  %t514 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d165, i32 0, i32 1) }, 0
  %t515 = add i64 %t512, %t514
  %t516 = load i64, ptr %l218
  %t517 = inttoptr i64 %t516 to ptr
  %t518 = call ptr @__olang_held_alloc(ptr %t517, i64 %t515)
  call void @olang_textcopy(ptr %t518, ptr %t507, i64 %t508)
  %t519 = getelementptr i8, ptr %t518, i64 %t508
  call void @olang_textcopy(ptr %t519, ptr %t510, i64 %t511)
  %t520 = getelementptr i8, ptr %t519, i64 %t511
  call void @olang_textcopy(ptr %t520, ptr %t513, i64 %t514)
  %t521 = insertvalue { i64, ptr } undef, i64 %t515, 0
  %t522 = insertvalue { i64, ptr } %t521, ptr %t518, 1
  %t524 = load ptr, ptr %l217, !tbaa !29
  %t526 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %v0, ptr %t524, { i64, ptr } %t522)
  store i32 %t526, ptr %l223
  %t527 = icmp ne i32 %t526, 0
  br i1 %t527, label %bb145, label %ok.528, !prof !99
ok.528:
  br label %bb144
bb144:
  br label %bb146
bb145:
  %t529 = load i32, ptr %l223, !tbaa !23
  %t530 = lshr i32 %t529, 16
  %t531 = and i32 %t529, 65535
  %t532 = icmp eq i32 %t530, 1
  %t533 = select i1 %t532, i32 1, i32 0
  %t534 = icmp eq i32 %t529, 0
  %t535 = shl i32 %t533, 16
  %t536 = or i32 %t535, %t531
  %t537 = select i1 %t534, i32 0, i32 %t536
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t539 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 %t537, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t539, ptr %rv
  br label %ret
bb146:
  br label %bb147
bb147:
  %t540 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t540, ptr %l225
  br label %bb148
bb148:
  %t541 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 32, i64 8)
  store ptr %t541, ptr %lp18
  %t542 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l225
  %t543 = load ptr, ptr %lp18
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t542, ptr %t543
  %t544 = load ptr, ptr %lp9
  %t545 = getelementptr %"compiler/bindgen:cMacro", ptr %t544, i32 0, i32 3
  %t546 = load { i64, ptr }, ptr %t545, !tbaa !27
  store { i64, ptr } %t546, ptr %l19, !tbaa !27
  store i64 0, ptr %l20, !tbaa !24
  %t548 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t550 = extractvalue { i64, ptr } %t548, 0
  store i64 %t550, ptr %l21, !tbaa !24
  br label %bb149
bb149:
  store %olang.scope zeroinitializer, ptr %s25
  %t552 = load i64, ptr %l20, !tbaa !24
  %t553 = load i64, ptr %l21, !tbaa !24
  %t556 = icmp slt i64 %t552, %t553
  %t558 = xor i1 %t556, true
  br i1 %t558, label %bb150, label %bb151
bb150:
  call void @__olang_scope_close(ptr %s25)
  br label %bb179
bb151:
  br label %bb152
bb152:
  %t560 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t560, ptr %l233, !tbaa !27
  %t561 = load i64, ptr %l20, !tbaa !24
  %t563 = getelementptr { i64, ptr }, ptr %l233, i32 0, i32 1
  %t564 = load ptr, ptr %t563, !tbaa !27
  %t565 = getelementptr { i64, ptr }, ptr %t564, i64 %t561
  %t566 = load { i64, ptr }, ptr %t565, !tbaa !37
  store { i64, ptr } %t566, ptr %l22, !tbaa !27
  %t568 = load ptr, ptr %lp9
  %t569 = getelementptr %"compiler/bindgen:cMacro", ptr %t568, i32 0, i32 2
  %t570 = load { i64, ptr }, ptr %t569, !tbaa !27
  %t571 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t572 = getelementptr { { i64, ptr }, ptr }, ptr null, i32 1
  %t573 = ptrtoint ptr %t572 to i64
  %t575 = getelementptr { { i64, ptr }, ptr }, ptr %t574, i32 0, i32 0
  store { i64, ptr } %t571, ptr %t575, !tbaa !28
  call void @__olang_scope_escape(ptr %v3)
  %t577 = call ptr @__olang_scope_hold(ptr %v3)
  %t578 = getelementptr { { i64, ptr }, ptr }, ptr %t574, i32 0, i32 1
  store ptr %t577, ptr %t578, !tbaa !28
  %t579 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_166, 0
  %t580 = insertvalue { ptr, ptr } %t579, ptr %t574, 1
  %t583 = extractvalue { ptr, ptr } %t580, 0
  %t584 = extractvalue { ptr, ptr } %t580, 1
  %t585 = call { i32, i64 } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eFindIndex_3cstd_2f_H0cdaf28864c9da4990596b1986b376a0(ptr %v3, ptr %s25, { i64, ptr } %t570, ptr %t583, ptr %t584)
  %t586 = extractvalue { i32, i64 } %t585, 1
  %t587 = extractvalue { i32, i64 } %t585, 0
  store i32 %t587, ptr %l241
  %t588 = icmp ne i32 %t587, 0
  br i1 %t588, label %bb154, label %ok.589, !prof !99
ok.589:
  store i64 %t586, ptr %l240
  br label %bb153
bb153:
  %t590 = load i64, ptr %l240, !tbaa !24
  store i64 %t590, ptr %l236, !tbaa !24
  br label %bb156
bb154:
  br label %bb155
bb155:
  store i64 -1, ptr %l236, !tbaa !24
  br label %bb156
bb156:
  %t591 = load i64, ptr %l236, !tbaa !24
  store i64 %t591, ptr %l23, !tbaa !24
  %t592 = load i64, ptr %l23, !tbaa !24
  %t594 = icmp slt i64 %t592, 0
  br i1 %t594, label %bb157, label %bb158
bb157:
  %t596 = load ptr, ptr %lp18
  %t597 = load { i64, ptr }, ptr %l22, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v3, ptr %v3, ptr %t596, { i64, ptr } %t597)
  br label %bb159
bb158:
  br label %bb160
bb159:
  call void @__olang_scope_close(ptr %s25)
  br label %bb178
bb160:
  %t600 = load ptr, ptr %lp18
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v3, ptr %v3, ptr %t600, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d167, i32 0, i32 1) })
  br label %bb161
bb161:
  store %olang.scope zeroinitializer, ptr %s27
  %t602 = load ptr, ptr %l0, !tbaa !29
  store ptr %t602, ptr %l247, !tbaa !29
  %t603 = load ptr, ptr %lp13
  %t604 = load i64, ptr %l23, !tbaa !24
  %t607 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cstd_2fprel_H21d8db2bdfeb46fab755f8173a35f95e(ptr %v3, ptr %v3, ptr %t603, i64 %t604)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t607, ptr %l250
  br label %bb162
bb162:
  %t609 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v3, ptr %l250)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t609, ptr %l252
  br label %bb163
bb163:
  %t610 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l252
  %t611 = call ptr @__olang_scope_alloc_a(ptr %s27, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t610, ptr %t611
  %t613 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v3, ptr %v3, ptr %t611)
  store { i64, ptr } %t613, ptr %l254
  br label %bb164
bb164:
  %t614 = load ptr, ptr %l2, !tbaa !29
  %t615 = load i64, ptr %l3, !tbaa !24
  %t617 = add i64 %t615, 1
  %t618 = load ptr, ptr %l247, !tbaa !29
  %t619 = load { i64, ptr }, ptr %l254, !tbaa !27
  %t622 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eexpand(ptr %v0, ptr %v3, ptr %v2, ptr %v3, ptr %t618, { i64, ptr } %t619, ptr %t614, i64 %t617)
  %t623 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t622, 1
  %t624 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t622, 0
  store i32 %t624, ptr %l259
  %t625 = icmp ne i32 %t624, 0
  br i1 %t625, label %bb166, label %ok.626, !prof !99
ok.626:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t623, ptr %l258
  br label %bb165
bb165:
  %t627 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l258
  %t628 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t627, ptr %t628
  store ptr %t628, ptr %l24, !tbaa !29
  store i64 0, ptr %l25, !tbaa !24
  br label %bb167
bb166:
  %t630 = load i32, ptr %l259, !tbaa !23
  %t631 = lshr i32 %t630, 16
  %t632 = and i32 %t630, 65535
  %t633 = icmp eq i32 %t631, 1
  %t634 = select i1 %t633, i32 1, i32 0
  %t635 = icmp eq i32 %t630, 0
  %t636 = shl i32 %t634, 16
  %t637 = or i32 %t636, %t632
  %t638 = select i1 %t635, i32 0, i32 %t637
  call void @__olang_scope_close(ptr %s27)
  call void @__olang_scope_close(ptr %s25)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t640 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 %t638, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t640, ptr %rv
  br label %ret
bb167:
  %t641 = load i64, ptr %l25, !tbaa !24
  store i64 %t641, ptr %l262, !tbaa !24
  %t642 = load ptr, ptr %l24, !tbaa !29
  %t644 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v3, ptr %t642)
  store i64 %t644, ptr %l264
  br label %bb168
bb168:
  %t645 = load i64, ptr %l262, !tbaa !24
  %t646 = load i64, ptr %l264, !tbaa !24
  %t647 = icmp slt i64 %t645, %t646
  %t649 = xor i1 %t647, true
  br i1 %t649, label %bb169, label %bb170
bb169:
  br label %bb175
bb170:
  br label %bb171
bb171:
  %t651 = load ptr, ptr %l24, !tbaa !29
  %t652 = load i64, ptr %l25, !tbaa !24
  %t655 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v3, ptr %v3, ptr %t651, i64 %t652)
  store { i64, ptr } %t655, ptr %l269
  br label %bb172
bb172:
  %t656 = load { i64, ptr }, ptr %l269, !tbaa !27
  %t657 = load ptr, ptr %lp18
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v3, ptr %v3, ptr %t657, { i64, ptr } %t656)
  br label %bb173
bb173:
  br label %bb174
bb174:
  %t661 = load i64, ptr %l25, !tbaa !24
  %t664 = add i64 %t661, 1
  store i64 %t664, ptr %l25, !tbaa !24
  br label %bb167
bb175:
  call void @__olang_scope_close(ptr %s27)
  br label %bb176
bb176:
  %t666 = load ptr, ptr %lp18
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v3, ptr %v3, ptr %t666, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d168, i32 0, i32 1) })
  br label %bb177
bb177:
  call void @__olang_scope_close(ptr %s25)
  br label %bb178
bb178:
  %t668 = load i64, ptr %l20, !tbaa !24
  %t671 = add i64 %t668, 1
  store i64 %t671, ptr %l20, !tbaa !24
  br label %bb149
bb179:
  %t673 = load ptr, ptr %l2, !tbaa !29
  %t674 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v2, ptr %v1, ptr %t673, { i64, ptr } %t674)
  br label %bb180
bb180:
  %t677 = load ptr, ptr %l0, !tbaa !29
  store ptr %t677, ptr %l281, !tbaa !29
  %t678 = load ptr, ptr %lp18
  %t680 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v3, ptr %v3, ptr %t678)
  store { i64, ptr } %t680, ptr %l283
  br label %bb181
bb181:
  %t681 = load ptr, ptr %l2, !tbaa !29
  %t682 = load i64, ptr %l3, !tbaa !24
  %t684 = add i64 %t682, 1
  %t685 = load ptr, ptr %l281, !tbaa !29
  %t686 = load { i64, ptr }, ptr %l283, !tbaa !27
  %t689 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eexpand(ptr %v0, ptr %v3, ptr %v2, ptr %v3, ptr %t685, { i64, ptr } %t686, ptr %t681, i64 %t684)
  %t690 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t689, 1
  %t691 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t689, 0
  store i32 %t691, ptr %l288
  %t692 = icmp ne i32 %t691, 0
  br i1 %t692, label %bb183, label %ok.693, !prof !99
ok.693:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t690, ptr %l287
  br label %bb182
bb182:
  %t694 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l287
  %t695 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t694, ptr %t695
  store ptr %t695, ptr %l27, !tbaa !29
  store i64 0, ptr %l28, !tbaa !24
  br label %bb184
bb183:
  %t697 = load i32, ptr %l288, !tbaa !23
  %t698 = lshr i32 %t697, 16
  %t699 = and i32 %t697, 65535
  %t700 = icmp eq i32 %t698, 1
  %t701 = select i1 %t700, i32 1, i32 0
  %t702 = icmp eq i32 %t697, 0
  %t703 = shl i32 %t701, 16
  %t704 = or i32 %t703, %t699
  %t705 = select i1 %t702, i32 0, i32 %t704
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t707 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 %t705, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t707, ptr %rv
  br label %ret
bb184:
  %t708 = load i64, ptr %l28, !tbaa !24
  store i64 %t708, ptr %l291, !tbaa !24
  %t709 = load ptr, ptr %l27, !tbaa !29
  %t711 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v3, ptr %t709)
  store i64 %t711, ptr %l293
  br label %bb185
bb185:
  %t712 = load i64, ptr %l291, !tbaa !24
  %t713 = load i64, ptr %l293, !tbaa !24
  %t714 = icmp slt i64 %t712, %t713
  %t716 = xor i1 %t714, true
  br i1 %t716, label %bb186, label %bb187
bb186:
  br label %bb192
bb187:
  br label %bb188
bb188:
  %t718 = load ptr, ptr %l27, !tbaa !29
  %t719 = load i64, ptr %l28, !tbaa !24
  %t722 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v3, ptr %v3, ptr %t718, i64 %t719)
  store { i64, ptr } %t722, ptr %l298
  br label %bb189
bb189:
  %t723 = load { i64, ptr }, ptr %l298, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v3, ptr %v3, ptr %l4, { i64, ptr } %t723)
  br label %bb190
bb190:
  br label %bb191
bb191:
  %t727 = load i64, ptr %l28, !tbaa !24
  %t730 = add i64 %t727, 1
  store i64 %t730, ptr %l28, !tbaa !24
  br label %bb184
bb192:
  br label %bb193
bb193:
  %t732 = load ptr, ptr %l2, !tbaa !29
  %t734 = call { i32, { i64, ptr } } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_Hdc04e7543082eec80486670259c0789b(ptr %v2, ptr %s2, ptr %t732)
  %t735 = extractvalue { i32, { i64, ptr } } %t734, 1
  %t736 = extractvalue { i32, { i64, ptr } } %t734, 0
  store i32 %t736, ptr %l307
  %t737 = icmp ne i32 %t736, 0
  br i1 %t737, label %bb195, label %ok.738, !prof !99
ok.738:
  store { i64, ptr } %t735, ptr %l306
  br label %bb194
bb194:
  %t739 = load { i64, ptr }, ptr %l306, !tbaa !27
  store { i64, ptr } %t739, ptr %l304, !tbaa !27
  %t740 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t740, label %bb197, label %bb198
bb195:
  br label %bb196
bb196:
  br label %bb199
bb197:
  %t742 = load { i64, ptr }, ptr %l304
  %t743 = extractvalue { i64, ptr } %t742, 1
  call void @__olang_region_release(ptr %t743)
  store { i64, ptr } zeroinitializer, ptr %l304
  br label %bb198
bb198:
  br label %bb199
bb199:
  %t744 = load i64, ptr %l16, !tbaa !24
  %t746 = add i64 %t744, 1
  store i64 %t746, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb200
bb200:
  br label %bb8
bb201:
  %t748 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  call void @__olang_scope_close(ptr %s0)
  %t750 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t748, 1
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t750, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }, ptr %rv
  ret { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %rr
}

define dso_local { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2efieldLine(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca i64
  %l8 = alloca i64
  %l12 = alloca %"compiler/bindgen:ctype"
  %l15 = alloca { i64, ptr }
  %l16 = alloca ptr
  %l20 = alloca %"compiler/bindgen:ctype"
  %l22 = alloca { i64, ptr }
  %l23 = alloca i32
  %l25 = alloca i1
  %l26 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l35 = alloca %"compiler/bindgen:ctype"
  %l38 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca i32
  %l44 = alloca i1
  %l45 = alloca { i64, ptr }
  %l47 = alloca i64
  %l48 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eparseType(ptr %v0, ptr %v2, ptr %t1, { i64, ptr } %a2, i64 0)
  store i64 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i64, ptr %l8, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/bindgen:gen", ptr %t7, i32 0, i32 17
  %t10 = load i64, ptr %l3, !tbaa !24
  %t13 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %s0, ptr %t9, i64 %t10)
  store %"compiler/bindgen:ctype" %t13, ptr %l12
  br label %bb2
bb2:
  %t14 = getelementptr %"compiler/bindgen:ctype", ptr %l12, i32 0, i32 0
  %t15 = load i32, ptr %t14, !range !{i32 0, i32 7}
  %t17 = trunc i64 4 to i32
  %t18 = icmp eq i32 %t15, %t17
  br i1 %t18, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l16, !tbaa !29
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/bindgen:gen", ptr %t21, i32 0, i32 17
  %t24 = load i64, ptr %l3, !tbaa !24
  %t27 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %s1, ptr %t23, i64 %t24)
  store %"compiler/bindgen:ctype" %t27, ptr %l20
  br label %bb5
bb4:
  br label %bb11
bb5:
  %t28 = getelementptr %"compiler/bindgen:ctype", ptr %l20, i32 0, i32 2
  %t29 = load i64, ptr %t28, !tbaa !24
  %t30 = load ptr, ptr %l16, !tbaa !29
  %t32 = call { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2efieldType(ptr %v0, ptr %s1, ptr %t30, i64 %t29)
  %t33 = extractvalue { i32, { i64, ptr } } %t32, 1
  %t34 = extractvalue { i32, { i64, ptr } } %t32, 0
  store i32 %t34, ptr %l23
  %t35 = icmp ne i32 %t34, 0
  br i1 %t35, label %bb7, label %ok.36, !prof !99
ok.36:
  store { i64, ptr } %t33, ptr %l22
  br label %bb6
bb6:
  %t37 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t37, ptr %l15, !tbaa !27
  br label %bb9
bb7:
  %t38 = load i32, ptr %l23, !tbaa !23
  %t39 = ashr i32 %t38, 16
  %t41 = icmp eq i32 %t39, 1
  store i1 %t41, ptr %l25, !tbaa !21
  br label %bb8
bb8:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d169, i32 0, i32 1) }, ptr %l26, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t42, ptr %l15, !tbaa !27
  br label %bb9
bb9:
  %t44 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t44, 0
  store i64 %t45, ptr %l28, !tbaa !24
  %t46 = load i64, ptr %l28, !tbaa !24
  %t47 = mul i64 %t46, 1
  %t48 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t47)
  %t49 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  store { i64, ptr } %t50, ptr %l29, !tbaa !27
  %t51 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = load i64, ptr %l28, !tbaa !24
  %t56 = mul i64 %t55, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t52, ptr %t54, i64 %t56, i1 false)
  %t57 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t58 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t58, ptr %l30, !tbaa !27
  store { i64, ptr } %t57, ptr %l31, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/bindgen:gen", ptr %t60, i32 0, i32 17
  %t63 = load i64, ptr %l3, !tbaa !24
  %t66 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %s1, ptr %t62, i64 %t63)
  store %"compiler/bindgen:ctype" %t66, ptr %l35
  br label %bb10
bb10:
  %t67 = getelementptr %"compiler/bindgen:ctype", ptr %l35, i32 0, i32 4
  %t68 = load i64, ptr %t67, !tbaa !24
  %t69 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d170, i32 0, i32 1) }, 1
  %t70 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d170, i32 0, i32 1) }, 0
  %t71 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t71, 1
  %t73 = extractvalue { i64, ptr } %t71, 0
  %t74 = add i64 %t70, %t73
  %t75 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d171, i32 0, i32 1) }, 1
  %t76 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d171, i32 0, i32 1) }, 0
  %t77 = add i64 %t74, %t76
  %t78 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t78, 1
  %t80 = extractvalue { i64, ptr } %t78, 0
  %t81 = add i64 %t77, %t80
  %t82 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d172, i32 0, i32 1) }, 1
  %t83 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d172, i32 0, i32 1) }, 0
  %t84 = add i64 %t81, %t83
  %t86 = call i64 @__olang_fmt_i64(ptr null, i64 %t68)
  %t87 = add i64 %t84, %t86
  %t88 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d173, i32 0, i32 1) }, 1
  %t89 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d173, i32 0, i32 1) }, 0
  %t90 = add i64 %t87, %t89
  %t91 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t90)
  call void @olang_textcopy(ptr %t91, ptr %t69, i64 %t70)
  %t92 = getelementptr i8, ptr %t91, i64 %t70
  call void @olang_textcopy(ptr %t92, ptr %t72, i64 %t73)
  %t93 = getelementptr i8, ptr %t92, i64 %t73
  call void @olang_textcopy(ptr %t93, ptr %t75, i64 %t76)
  %t94 = getelementptr i8, ptr %t93, i64 %t76
  call void @olang_textcopy(ptr %t94, ptr %t79, i64 %t80)
  %t95 = getelementptr i8, ptr %t94, i64 %t80
  call void @olang_textcopy(ptr %t95, ptr %t82, i64 %t83)
  %t96 = getelementptr i8, ptr %t95, i64 %t83
  %t97 = call i64 @__olang_fmt_i64(ptr %t96, i64 %t68)
  %t98 = getelementptr i8, ptr %t96, i64 %t86
  call void @olang_textcopy(ptr %t98, ptr %t88, i64 %t89)
  %t99 = insertvalue { i64, ptr } undef, i64 %t90, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t91, 1
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t100, ptr %rv
  br label %ret
bb11:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load i64, ptr %l3, !tbaa !24
  %t106 = call { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2efieldType(ptr %v0, ptr %s0, ptr %t102, i64 %t103)
  %t107 = extractvalue { i32, { i64, ptr } } %t106, 1
  %t108 = extractvalue { i32, { i64, ptr } } %t106, 0
  store i32 %t108, ptr %l42
  %t109 = icmp ne i32 %t108, 0
  br i1 %t109, label %bb13, label %ok.110, !prof !99
ok.110:
  store { i64, ptr } %t107, ptr %l41
  br label %bb12
bb12:
  %t111 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t111, ptr %l38, !tbaa !27
  br label %bb15
bb13:
  %t112 = load i32, ptr %l42, !tbaa !23
  %t113 = ashr i32 %t112, 16
  %t115 = icmp eq i32 %t113, 1
  store i1 %t115, ptr %l44, !tbaa !21
  br label %bb14
bb14:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d174, i32 0, i32 1) }, ptr %l45, !tbaa !27
  %t116 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t116, ptr %l38, !tbaa !27
  br label %bb15
bb15:
  %t118 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t118, 0
  store i64 %t119, ptr %l47, !tbaa !24
  %t120 = load i64, ptr %l47, !tbaa !24
  %t121 = mul i64 %t120, 1
  %t122 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t121)
  %t123 = insertvalue { i64, ptr } undef, i64 %t120, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr %t122, 1
  store { i64, ptr } %t124, ptr %l48, !tbaa !27
  %t125 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !27
  %t127 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t128 = load ptr, ptr %t127, !tbaa !27
  %t129 = load i64, ptr %l47, !tbaa !24
  %t130 = mul i64 %t129, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t126, ptr %t128, i64 %t130, i1 false)
  %t131 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t132 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t134 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d175, i32 0, i32 1) }, 1
  %t135 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d175, i32 0, i32 1) }, 0
  %t137 = extractvalue { i64, ptr } %t132, 1
  %t138 = extractvalue { i64, ptr } %t132, 0
  %t139 = add i64 %t135, %t138
  %t140 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d176, i32 0, i32 1) }, 1
  %t141 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d176, i32 0, i32 1) }, 0
  %t142 = add i64 %t139, %t141
  %t144 = extractvalue { i64, ptr } %t131, 1
  %t145 = extractvalue { i64, ptr } %t131, 0
  %t146 = add i64 %t142, %t145
  %t147 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d177, i32 0, i32 1) }, 1
  %t148 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d177, i32 0, i32 1) }, 0
  %t149 = add i64 %t146, %t148
  %t150 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t149)
  call void @olang_textcopy(ptr %t150, ptr %t134, i64 %t135)
  %t151 = getelementptr i8, ptr %t150, i64 %t135
  call void @olang_textcopy(ptr %t151, ptr %t137, i64 %t138)
  %t152 = getelementptr i8, ptr %t151, i64 %t138
  call void @olang_textcopy(ptr %t152, ptr %t140, i64 %t141)
  %t153 = getelementptr i8, ptr %t152, i64 %t141
  call void @olang_textcopy(ptr %t153, ptr %t144, i64 %t145)
  %t154 = getelementptr i8, ptr %t153, i64 %t145
  call void @olang_textcopy(ptr %t154, ptr %t147, i64 %t148)
  %t155 = insertvalue { i64, ptr } undef, i64 %t149, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t150, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t156, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2efieldType(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/bindgen:ctype"
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca %"compiler/bindgen:ctype"
  %l6 = alloca i64
  %l10 = alloca %"compiler/bindgen:ctype"
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l27 = alloca i64
  %l30 = alloca i1
  %l33 = alloca i32
  %l37 = alloca { i64, ptr }
  %l43 = alloca %"compiler/bindgen:ctype"
  %l46 = alloca i1
  %l47 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l49 = alloca i64
  %l50 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l60 = alloca i64
  %l63 = alloca i1
  %l67 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l71 = alloca i64
  %l72 = alloca { i64, ptr }
  %l77 = alloca i32
  %l80 = alloca i32
  %l82 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l84 = alloca i64
  %l85 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/bindgen:gen", ptr %t1, i32 0, i32 17
  %t7 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store %"compiler/bindgen:ctype" %t7, ptr %l10
  br label %bb1
bb1:
  %t8 = load %"compiler/bindgen:ctype", ptr %l10
  store %"compiler/bindgen:ctype" %t8, ptr %l2
  %t9 = getelementptr %"compiler/bindgen:ctype", ptr %l2, i32 0, i32 0
  %t10 = load i32, ptr %t9, !range !{i32 0, i32 7}
  store i32 %t10, ptr %l3
  %t12 = load i32, ptr %l3, !range !{i32 0, i32 7}
  %t14 = trunc i64 1 to i32
  %t15 = icmp eq i32 %t12, %t14
  br i1 %t15, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb9
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t17 = getelementptr %"compiler/bindgen:ctype", ptr %l2, i32 0, i32 1
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  %t20 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t18, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d178, i32 0, i32 1) })
  store i1 %t20, ptr %l15
  br label %bb5
bb5:
  %t21 = load i1, ptr %l15, !tbaa !21
  br i1 %t21, label %bb6, label %bb7
bb6:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d179, i32 0, i32 1) }, ptr %l17, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t22, ptr %l16, !tbaa !27
  br label %bb8
bb7:
  %t24 = getelementptr %"compiler/bindgen:ctype", ptr %l2, i32 0, i32 1
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t25, 1
  %t28 = extractvalue { i64, ptr } %t25, 0
  %t29 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t28)
  call void @olang_textcopy(ptr %t29, ptr %t27, i64 %t28)
  %t30 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t29, 1
  store { i64, ptr } %t31, ptr %l16, !tbaa !27
  br label %bb8
bb8:
  %t33 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 0
  store i64 %t34, ptr %l21, !tbaa !24
  %t35 = load i64, ptr %l21, !tbaa !24
  %t36 = mul i64 %t35, 1
  %t37 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t36)
  %t38 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  store { i64, ptr } %t39, ptr %l22, !tbaa !27
  %t40 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l21, !tbaa !24
  %t45 = mul i64 %t44, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t41, ptr %t43, i64 %t45, i1 false)
  %t46 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t46, ptr %l16, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  %t47 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t48 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t47, 1
  store { i32, { i64, ptr } } %t48, ptr %rv
  br label %ret
bb9:
  %t49 = load i32, ptr %l3, !range !{i32 0, i32 7}
  %t51 = trunc i64 2 to i32
  %t52 = icmp eq i32 %t49, %t51
  br i1 %t52, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb22
bb12:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/bindgen:ctype", ptr %l2, i32 0, i32 1
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t59 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2erecOf(ptr %v0, ptr %v0, ptr %t54, { i64, ptr } %t56)
  store i64 %t59, ptr %l27
  br label %bb13
bb13:
  %t60 = load i64, ptr %l27, !tbaa !24
  store i64 %t60, ptr %l4, !tbaa !24
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load i64, ptr %l4, !tbaa !24
  %t65 = call i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eholdable(ptr %v0, ptr %t61, i64 %t62)
  store i1 %t65, ptr %l30
  br label %bb14
bb14:
  %t66 = load i1, ptr %l30, !tbaa !21
  %t67 = xor i1 %t66, true
  br i1 %t67, label %bb15, label %bb16
bb15:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %v0, ptr %t69, { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d180, i32 0, i32 1) })
  store i32 %t71, ptr %l33
  %t72 = icmp ne i32 %t71, 0
  br i1 %t72, label %bb18, label %ok.73, !prof !99
ok.73:
  br label %bb17
bb16:
  br label %bb20
bb17:
  br label %bb19
bb18:
  %t74 = load i32, ptr %l33, !tbaa !23
  %t75 = lshr i32 %t74, 16
  %t76 = and i32 %t74, 65535
  %t77 = icmp eq i32 %t75, 1
  %t78 = select i1 %t77, i32 1, i32 0
  %t79 = icmp eq i32 %t74, 0
  %t80 = shl i32 %t78, 16
  %t81 = or i32 %t80, %t76
  %t82 = select i1 %t79, i32 0, i32 %t81
  %t84 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t82, 0
  store { i32, { i64, ptr } } %t84, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load i64, ptr %l4, !tbaa !24
  %t89 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ename(ptr %v0, ptr %v1, ptr %t85, i64 %t86)
  store { i64, ptr } %t89, ptr %l37
  br label %bb21
bb21:
  %t90 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t91 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t90, 1
  store { i32, { i64, ptr } } %t91, ptr %rv
  br label %ret
bb22:
  %t92 = load i32, ptr %l3, !range !{i32 0, i32 7}
  %t94 = trunc i64 3 to i32
  %t95 = icmp eq i32 %t92, %t94
  br i1 %t95, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb44
bb25:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/bindgen:gen", ptr %t97, i32 0, i32 17
  %t100 = getelementptr %"compiler/bindgen:ctype", ptr %l2, i32 0, i32 2
  %t101 = load i64, ptr %t100, !tbaa !24
  %t104 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v0, ptr %t99, i64 %t101)
  store %"compiler/bindgen:ctype" %t104, ptr %l43
  br label %bb26
bb26:
  %t105 = load %"compiler/bindgen:ctype", ptr %l43
  store %"compiler/bindgen:ctype" %t105, ptr %l5
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/bindgen:ctype", ptr %l2, i32 0, i32 2
  %t108 = load i64, ptr %t107, !tbaa !24
  %t111 = call i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eisByte(ptr %v0, ptr %t106, i64 %t108)
  store i1 %t111, ptr %l46
  br label %bb27
bb27:
  %t112 = load i1, ptr %l46, !tbaa !21
  br i1 %t112, label %bb28, label %bb29
bb28:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d181, i32 0, i32 1) }, ptr %l47, !tbaa !27
  %t113 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t113, ptr %l48, !tbaa !27
  %t114 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t115 = extractvalue { i64, ptr } %t114, 0
  store i64 %t115, ptr %l49, !tbaa !24
  %t116 = load i64, ptr %l49, !tbaa !24
  %t117 = mul i64 %t116, 1
  %t118 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t117)
  %t119 = insertvalue { i64, ptr } undef, i64 %t116, 0
  %t120 = insertvalue { i64, ptr } %t119, ptr %t118, 1
  store { i64, ptr } %t120, ptr %l50, !tbaa !27
  %t121 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !27
  %t123 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !27
  %t125 = load i64, ptr %l49, !tbaa !24
  %t126 = mul i64 %t125, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t122, ptr %t124, i64 %t126, i1 false)
  %t127 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t127, ptr %l48, !tbaa !27
  %t128 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t129 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t128, 1
  store { i32, { i64, ptr } } %t129, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  %t130 = getelementptr %"compiler/bindgen:ctype", ptr %l5, i32 0, i32 0
  %t131 = load i32, ptr %t130, !range !{i32 0, i32 7}
  %t133 = trunc i64 5 to i32
  %t134 = icmp eq i32 %t131, %t133
  br i1 %t134, label %bb31, label %bb32
bb31:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load %"compiler/bindgen:ctype", ptr %l5
  %t140 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecFunc(ptr %v0, ptr %v0, ptr %v1, ptr %t136, %"compiler/bindgen:ctype" %t137)
  store { i64, ptr } %t140, ptr %l55
  br label %bb33
bb32:
  br label %bb34
bb33:
  %t141 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t142 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t141, 1
  store { i32, { i64, ptr } } %t142, ptr %rv
  br label %ret
bb34:
  %t143 = getelementptr %"compiler/bindgen:ctype", ptr %l5, i32 0, i32 0
  %t144 = load i32, ptr %t143, !range !{i32 0, i32 7}
  %t146 = trunc i64 2 to i32
  %t147 = icmp eq i32 %t144, %t146
  br i1 %t147, label %bb35, label %bb36
bb35:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"compiler/bindgen:ctype", ptr %l5, i32 0, i32 1
  %t151 = load { i64, ptr }, ptr %t150, !tbaa !27
  %t154 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2erecOf(ptr %v0, ptr %v0, ptr %t149, { i64, ptr } %t151)
  store i64 %t154, ptr %l60
  br label %bb37
bb36:
  br label %bb43
bb37:
  %t155 = load i64, ptr %l60, !tbaa !24
  store i64 %t155, ptr %l6, !tbaa !24
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load i64, ptr %l6, !tbaa !24
  %t160 = call i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eholdable(ptr %v0, ptr %t156, i64 %t157)
  store i1 %t160, ptr %l63
  br label %bb38
bb38:
  %t161 = load i1, ptr %l63, !tbaa !21
  %t162 = xor i1 %t161, true
  br i1 %t162, label %bb39, label %bb40
bb39:
  store %olang.scope zeroinitializer, ptr %s9
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = load i64, ptr %l6, !tbaa !24
  %t168 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ename(ptr %v0, ptr %s9, ptr %t164, i64 %t165)
  store { i64, ptr } %t168, ptr %l67
  br label %bb41
bb40:
  br label %bb42
bb41:
  %t169 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t170 = extractvalue { i64, ptr } %t169, 1
  %t171 = extractvalue { i64, ptr } %t169, 0
  %t172 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d182, i32 0, i32 1) }, 1
  %t173 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d182, i32 0, i32 1) }, 0
  %t174 = add i64 %t171, %t173
  %t175 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t174)
  call void @olang_textcopy(ptr %t175, ptr %t170, i64 %t171)
  %t176 = getelementptr i8, ptr %t175, i64 %t171
  call void @olang_textcopy(ptr %t176, ptr %t172, i64 %t173)
  %t177 = insertvalue { i64, ptr } undef, i64 %t174, 0
  %t178 = insertvalue { i64, ptr } %t177, ptr %t175, 1
  call void @__olang_scope_close(ptr %s9)
  %t180 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t178, 1
  store { i32, { i64, ptr } } %t180, ptr %rv
  br label %ret
bb42:
  br label %bb43
bb43:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d183, i32 0, i32 1) }, ptr %l69, !tbaa !27
  %t181 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t181, ptr %l70, !tbaa !27
  %t182 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t183 = extractvalue { i64, ptr } %t182, 0
  store i64 %t183, ptr %l71, !tbaa !24
  %t184 = load i64, ptr %l71, !tbaa !24
  %t185 = mul i64 %t184, 1
  %t186 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t185)
  %t187 = insertvalue { i64, ptr } undef, i64 %t184, 0
  %t188 = insertvalue { i64, ptr } %t187, ptr %t186, 1
  store { i64, ptr } %t188, ptr %l72, !tbaa !27
  %t189 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !27
  %t191 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t192 = load ptr, ptr %t191, !tbaa !27
  %t193 = load i64, ptr %l71, !tbaa !24
  %t194 = mul i64 %t193, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t190, ptr %t192, i64 %t194, i1 false)
  %t195 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t195, ptr %l70, !tbaa !27
  %t196 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t197 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t196, 1
  store { i32, { i64, ptr } } %t197, ptr %rv
  br label %ret
bb44:
  %t198 = load i32, ptr %l3, !range !{i32 0, i32 7}
  %t200 = trunc i64 6 to i32
  %t201 = icmp eq i32 %t198, %t200
  br i1 %t201, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb51
bb47:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = getelementptr %"compiler/bindgen:ctype", ptr %l2, i32 0, i32 1
  %t205 = load { i64, ptr }, ptr %t204, !tbaa !27
  %t208 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %v0, ptr %t203, { i64, ptr } %t205)
  store i32 %t208, ptr %l77
  %t209 = icmp ne i32 %t208, 0
  br i1 %t209, label %bb49, label %ok.210, !prof !99
ok.210:
  br label %bb48
bb48:
  br label %bb50
bb49:
  %t211 = load i32, ptr %l77, !tbaa !23
  %t212 = lshr i32 %t211, 16
  %t213 = and i32 %t211, 65535
  %t214 = icmp eq i32 %t212, 1
  %t215 = select i1 %t214, i32 1, i32 0
  %t216 = icmp eq i32 %t211, 0
  %t217 = shl i32 %t215, 16
  %t218 = or i32 %t217, %t213
  %t219 = select i1 %t216, i32 0, i32 %t218
  %t221 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t219, 0
  store { i32, { i64, ptr } } %t221, ptr %rv
  br label %ret
bb50:
  br label %bb59
bb51:
  br i1 true, label %bb52, label %bb53
bb52:
  br label %bb54
bb53:
  br label %bb58
bb54:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %v0, ptr %t222, { i64, ptr } { i64 45, ptr getelementptr inbounds (<{ i64, [45 x i8] }>, ptr @.d184, i32 0, i32 1) })
  store i32 %t224, ptr %l80
  %t225 = icmp ne i32 %t224, 0
  br i1 %t225, label %bb56, label %ok.226, !prof !99
ok.226:
  br label %bb55
bb55:
  br label %bb57
bb56:
  %t227 = load i32, ptr %l80, !tbaa !23
  %t228 = lshr i32 %t227, 16
  %t229 = and i32 %t227, 65535
  %t230 = icmp eq i32 %t228, 1
  %t231 = select i1 %t230, i32 1, i32 0
  %t232 = icmp eq i32 %t227, 0
  %t233 = shl i32 %t231, 16
  %t234 = or i32 %t233, %t229
  %t235 = select i1 %t232, i32 0, i32 %t234
  %t237 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t235, 0
  store { i32, { i64, ptr } } %t237, ptr %rv
  br label %ret
bb57:
  br label %bb59
bb58:
  call void @__olang_check_failed(ptr @olang_loc_582986fcdf40d11c_2a39a940a03de888)
  unreachable
bb59:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d185, i32 0, i32 1) }, ptr %l82, !tbaa !27
  %t238 = load { i64, ptr }, ptr %l82, !tbaa !27
  store { i64, ptr } %t238, ptr %l83, !tbaa !27
  %t239 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t240 = extractvalue { i64, ptr } %t239, 0
  store i64 %t240, ptr %l84, !tbaa !24
  %t241 = load i64, ptr %l84, !tbaa !24
  %t242 = mul i64 %t241, 1
  %t243 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t242)
  %t244 = insertvalue { i64, ptr } undef, i64 %t241, 0
  %t245 = insertvalue { i64, ptr } %t244, ptr %t243, 1
  store { i64, ptr } %t245, ptr %l85, !tbaa !27
  %t246 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t247 = load ptr, ptr %t246, !tbaa !27
  %t248 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t249 = load ptr, ptr %t248, !tbaa !27
  %t250 = load i64, ptr %l84, !tbaa !24
  %t251 = mul i64 %t250, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t247, ptr %t249, i64 %t251, i1 false)
  %t252 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t252, ptr %l83, !tbaa !27
  %t253 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t254 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t253, 1
  store { i32, { i64, ptr } } %t254, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eflatFields(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca %"std/prelude/text:StringBuilder"
  %l5 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca i32
  %l22 = alloca i1
  %l23 = alloca %"std/prelude/text:StringBuilder"
  %l24 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l26 = alloca i64
  %l30 = alloca i64
  %l33 = alloca i64
  %l54 = alloca %"compiler/bindgen:record"
  %l58 = alloca i64
  %l62 = alloca ptr
  %l63 = alloca i64
  %l66 = alloca i64
  %l70 = alloca %"compiler/bindgen:record"
  %l72 = alloca { i64, ptr }
  %l74 = alloca ptr
  %l75 = alloca ptr
  %l76 = alloca ptr
  %l79 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %l89 = alloca i64
  %l93 = alloca %"compiler/bindgen:record"
  %l98 = alloca i64
  %l106 = alloca %"compiler/bindgen:record"
  %l110 = alloca ptr
  %l111 = alloca i64
  %l115 = alloca %"compiler/bindgen:record"
  %l118 = alloca i64
  %l122 = alloca %"compiler/bindgen:record"
  %l124 = alloca { i64, ptr }
  %l127 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t75 = alloca %"compiler/bindgen:record", align 8
  %t102 = alloca %"compiler/bindgen:record", align 8
  %t149 = alloca %"compiler/bindgen:record", align 8
  %t174 = alloca %"compiler/bindgen:record", align 8
  %t189 = alloca %"compiler/bindgen:record", align 8
  %t202 = alloca %"compiler/bindgen:record", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l14
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l2
  %t3 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l15
  br label %bb2
bb2:
  %t4 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l3
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i64, ptr %l1, !tbaa !24
  %t11 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eflat(ptr %v0, ptr %s0, ptr %s0, ptr %t5, i64 %t6, ptr %l2, ptr %l3)
  store i32 %t11, ptr %l20
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb4, label %ok.13, !prof !99
ok.13:
  br label %bb3
bb3:
  br label %bb6
bb4:
  %t14 = load i32, ptr %l20, !tbaa !23
  %t15 = ashr i32 %t14, 16
  %t17 = icmp eq i32 %t15, 1
  store i1 %t17, ptr %l22, !tbaa !21
  br label %bb5
bb5:
  br label %bb6
bb6:
  %t18 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t18, ptr %l23
  br label %bb7
bb7:
  %t19 = load %"std/prelude/text:StringBuilder", ptr %l23
  store %"std/prelude/text:StringBuilder" %t19, ptr %l4
  %t20 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t20, ptr %l24
  br label %bb8
bb8:
  %t21 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l24
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t21, ptr %l5
  store i64 0, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  %t23 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l2)
  store i64 %t23, ptr %l26
  br label %bb9
bb9:
  %t24 = load i64, ptr %l26, !tbaa !24
  store i64 %t24, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t25 = load i64, ptr %l8, !tbaa !24
  %t26 = load i64, ptr %l7, !tbaa !24
  %t29 = icmp sgt i64 %t25, %t26
  br i1 %t29, label %bb10, label %bb11
bb10:
  %t31 = load i64, ptr %l9, !tbaa !24
  %t33 = icmp sgt i64 %t31, 0
  br i1 %t33, label %bb12, label %bb13
bb11:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb15
bb12:
  %t35 = load i64, ptr %l8, !tbaa !24
  %t36 = load i64, ptr %l7, !tbaa !24
  %t39 = sub i64 %t35, %t36
  %t40 = load i64, ptr %l9, !tbaa !24
  %t43 = add i64 %t39, %t40
  %t45 = sub i64 %t43, 1
  %t46 = load i64, ptr %l9, !tbaa !24
  %t49 = sdiv i64 %t45, %t46
  store i64 %t49, ptr %l33, !tbaa !24
  br label %bb14
bb13:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb14
bb14:
  %t51 = load i64, ptr %l33, !tbaa !24
  store i64 %t51, ptr %l30, !tbaa !24
  br label %bb15
bb15:
  %t52 = load i64, ptr %l30, !tbaa !24
  store i64 %t52, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb16
bb16:
  store %olang.scope zeroinitializer, ptr %s3
  %t53 = load i64, ptr %l11, !tbaa !24
  %t54 = load i64, ptr %l10, !tbaa !24
  %t57 = icmp slt i64 %t53, %t54
  %t59 = xor i1 %t57, true
  br i1 %t59, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s3)
  br label %bb36
bb18:
  br label %bb19
bb19:
  %t61 = load i64, ptr %l7, !tbaa !24
  %t62 = load i64, ptr %l11, !tbaa !24
  %t63 = load i64, ptr %l9, !tbaa !24
  %t66 = mul i64 %t62, %t63
  %t69 = add i64 %t61, %t66
  store i64 %t69, ptr %l12, !tbaa !24
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/bindgen:gen", ptr %t71, i32 0, i32 6
  %t74 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t75, ptr %v0, ptr %v0, ptr %t73, i64 %t74)
  call void @llvm.memmove.p0.p0.i64(ptr %l54, ptr %t75, i64 312, i1 false)
  br label %bb20
bb20:
  %t78 = getelementptr %"compiler/bindgen:record", ptr %l54, i32 0, i32 18
  %t79 = load i64, ptr %l12, !tbaa !24
  %t81 = mul i64 3, %t79
  %t84 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t78, i64 %t81)
  store i64 %t84, ptr %l58
  br label %bb21
bb21:
  %t85 = load i64, ptr %l58, !tbaa !24
  store i64 %t85, ptr %l13, !tbaa !24
  %t86 = load i64, ptr %l13, !tbaa !24
  %t87 = load i64, ptr %l6, !tbaa !24
  %t90 = icmp sgt i64 %t86, %t87
  br i1 %t90, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s4
  store ptr %l4, ptr %l62, !tbaa !29
  %t92 = load i64, ptr %l6, !tbaa !24
  store i64 %t92, ptr %l63, !tbaa !24
  %t93 = load i64, ptr %l13, !tbaa !24
  %t94 = load i64, ptr %l6, !tbaa !24
  %t97 = sub i64 %t93, %t94
  store i64 %t97, ptr %l66, !tbaa !24
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/bindgen:gen", ptr %t98, i32 0, i32 6
  %t101 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t102, ptr %v0, ptr %s4, ptr %t100, i64 %t101)
  call void @llvm.memmove.p0.p0.i64(ptr %l70, ptr %t102, i64 312, i1 false)
  br label %bb24
bb23:
  br label %bb27
bb24:
  %t105 = getelementptr %"compiler/bindgen:record", ptr %l70, i32 0, i32 14
  %t106 = load i64, ptr %t105, !tbaa !24
  %t107 = load i64, ptr %l63, !tbaa !24
  %t108 = load i64, ptr %l66, !tbaa !24
  %t110 = call { i64, ptr } @compiler_2fbindgen_2egapLine(ptr %s4, i64 %t107, i64 %t108, i64 %t106)
  store { i64, ptr } %t110, ptr %l72
  br label %bb25
bb25:
  %t111 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t112 = load ptr, ptr %l62, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %t112, { i64, ptr } %t111)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s4)
  br label %bb27
bb27:
  store ptr %l4, ptr %l74, !tbaa !29
  %t114 = load ptr, ptr %l0, !tbaa !29
  store ptr %t114, ptr %l75, !tbaa !29
  %t115 = load ptr, ptr %l0, !tbaa !29
  store ptr %t115, ptr %l76, !tbaa !29
  %t116 = load i64, ptr %l12, !tbaa !24
  %t119 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l2, i64 %t116)
  store { i64, ptr } %t119, ptr %l79
  br label %bb28
bb28:
  %t120 = load i64, ptr %l12, !tbaa !24
  %t121 = load ptr, ptr %l76, !tbaa !29
  %t122 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t125 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eparamName(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t121, { i64, ptr } %t122, i64 %t120, ptr %l5)
  store { i64, ptr } %t125, ptr %l82
  br label %bb29
bb29:
  %t126 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t127 = extractvalue { i64, ptr } %t126, 0
  %t128 = extractvalue { i64, ptr } %t126, 1
  %t129 = mul i64 %t127, 1
  %t130 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t129)
  call void @llvm.memcpy.p0.p0.i64(ptr %t130, ptr %t128, i64 %t129, i1 false)
  %t131 = insertvalue { i64, ptr } undef, i64 %t127, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr %t130, 1
  store { i64, ptr } %t132, ptr %l83, !tbaa !27
  %t133 = load i64, ptr %l12, !tbaa !24
  %t136 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l3, i64 %t133)
  store { i64, ptr } %t136, ptr %l86
  br label %bb30
bb30:
  %t137 = load ptr, ptr %l75, !tbaa !29
  %t138 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t139 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t140 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2efieldLine(ptr %v0, ptr %s3, ptr %s0, ptr %s3, ptr %t137, { i64, ptr } %t138, { i64, ptr } %t139)
  store { i64, ptr } %t140, ptr %l87
  br label %bb31
bb31:
  %t141 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t142 = load ptr, ptr %l74, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %t142, { i64, ptr } %t141)
  br label %bb32
bb32:
  %t144 = load i64, ptr %l13, !tbaa !24
  store i64 %t144, ptr %l89, !tbaa !24
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/bindgen:gen", ptr %t145, i32 0, i32 6
  %t148 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t149, ptr %v0, ptr %v0, ptr %t147, i64 %t148)
  call void @llvm.memmove.p0.p0.i64(ptr %l93, ptr %t149, i64 312, i1 false)
  br label %bb33
bb33:
  %t152 = getelementptr %"compiler/bindgen:record", ptr %l93, i32 0, i32 18
  %t153 = load i64, ptr %l12, !tbaa !24
  %t155 = mul i64 3, %t153
  %t157 = add i64 %t155, 1
  %t160 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t152, i64 %t157)
  store i64 %t160, ptr %l98
  br label %bb34
bb34:
  %t161 = load i64, ptr %l89, !tbaa !24
  %t162 = load i64, ptr %l98, !tbaa !24
  %t163 = add i64 %t161, %t162
  store i64 %t163, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb35
bb35:
  %t165 = load i64, ptr %l11, !tbaa !24
  %t168 = add i64 %t165, 1
  store i64 %t168, ptr %l11, !tbaa !24
  br label %bb16
bb36:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/bindgen:gen", ptr %t170, i32 0, i32 6
  %t173 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t174, ptr %v0, ptr %s0, ptr %t172, i64 %t173)
  call void @llvm.memmove.p0.p0.i64(ptr %l106, ptr %t174, i64 312, i1 false)
  br label %bb37
bb37:
  %t177 = getelementptr %"compiler/bindgen:record", ptr %l106, i32 0, i32 13
  %t178 = load i64, ptr %t177, !tbaa !24
  %t179 = load i64, ptr %l6, !tbaa !24
  %t182 = icmp sgt i64 %t178, %t179
  br i1 %t182, label %bb38, label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s6
  store ptr %l4, ptr %l110, !tbaa !29
  %t184 = load i64, ptr %l6, !tbaa !24
  store i64 %t184, ptr %l111, !tbaa !24
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/bindgen:gen", ptr %t185, i32 0, i32 6
  %t188 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t189, ptr %v0, ptr %s6, ptr %t187, i64 %t188)
  call void @llvm.memmove.p0.p0.i64(ptr %l115, ptr %t189, i64 312, i1 false)
  br label %bb40
bb39:
  br label %bb44
bb40:
  %t192 = getelementptr %"compiler/bindgen:record", ptr %l115, i32 0, i32 13
  %t193 = load i64, ptr %t192, !tbaa !24
  %t194 = load i64, ptr %l6, !tbaa !24
  %t197 = sub i64 %t193, %t194
  store i64 %t197, ptr %l118, !tbaa !24
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t200 = getelementptr %"compiler/bindgen:gen", ptr %t198, i32 0, i32 6
  %t201 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t202, ptr %v0, ptr %s6, ptr %t200, i64 %t201)
  call void @llvm.memmove.p0.p0.i64(ptr %l122, ptr %t202, i64 312, i1 false)
  br label %bb41
bb41:
  %t205 = getelementptr %"compiler/bindgen:record", ptr %l122, i32 0, i32 14
  %t206 = load i64, ptr %t205, !tbaa !24
  %t207 = load i64, ptr %l111, !tbaa !24
  %t208 = load i64, ptr %l118, !tbaa !24
  %t210 = call { i64, ptr } @compiler_2fbindgen_2egapLine(ptr %s6, i64 %t207, i64 %t208, i64 %t206)
  store { i64, ptr } %t210, ptr %l124
  br label %bb42
bb42:
  %t211 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t212 = load ptr, ptr %l110, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %t212, { i64, ptr } %t211)
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s6)
  br label %bb44
bb44:
  %t215 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l4)
  store { i64, ptr } %t215, ptr %l127
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s0)
  %t216 = load { i64, ptr }, ptr %l127, !tbaa !27
  store { i64, ptr } %t216, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2efunction(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i1
  %l5 = alloca %"compiler/bindgen:ctype"
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l7 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %lp15 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l24 = alloca i1
  %l27 = alloca i64
  %l31 = alloca %"compiler/bindgen:ctype"
  %l36 = alloca i32
  %l42 = alloca i32
  %l44 = alloca %"std/prelude/text:StringBuilder"
  %l50 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l55 = alloca i64
  %l58 = alloca i64
  %l79 = alloca ptr
  %l85 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l93 = alloca ptr
  %l94 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l96 = alloca ptr
  %l102 = alloca i64
  %l103 = alloca { i64, ptr }
  %l104 = alloca i32
  %l112 = alloca i1
  %l113 = alloca ptr
  %l116 = alloca { i64, ptr }
  %l121 = alloca %"compiler/bindgen:ctype"
  %l125 = alloca { i64, ptr }
  %l128 = alloca { i64, ptr }
  %l129 = alloca i32
  %l138 = alloca %"compiler/bindgen:ctype"
  %l141 = alloca i1
  %l144 = alloca i1
  %l153 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/bindgen:cFunc", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i64, ptr } @compiler_2fbindgen_2enoReturnOf(ptr %v1, ptr %s0, { i64, ptr } %t4)
  store { i64, ptr } %t6, ptr %l18
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t7, 0
  store i64 %t8, ptr %l19, !tbaa !24
  %t9 = load i64, ptr %l19, !tbaa !24
  %t10 = mul i64 %t9, 1
  %t11 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t10)
  %t12 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  store { i64, ptr } %t13, ptr %l20, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = load i64, ptr %l19, !tbaa !24
  %t19 = mul i64 %t18, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t15, ptr %t17, i64 %t19, i1 false)
  %t20 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t20, ptr %l2, !tbaa !27
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr %"compiler/bindgen:cFunc", ptr %t21, i32 0, i32 1
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t25 = load { i64, ptr }, ptr @G_2ecompiler_2fbindgen_2eNoReturnAttr, !tbaa !27
  %t26 = load ptr, ptr @__olang_prog_scope
  %t29 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v1, ptr %t26, { i64, ptr } %t24, { i64, ptr } %t25)
  store i1 %t29, ptr %l24
  br label %bb2
bb2:
  %t30 = load i1, ptr %l24, !tbaa !21
  store i1 %t30, ptr %l3, !tbaa !21
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t35 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eparseType(ptr %v0, ptr %s0, ptr %t31, { i64, ptr } %t32, i64 0)
  store i64 %t35, ptr %l27
  br label %bb3
bb3:
  %t36 = load i64, ptr %l27, !tbaa !24
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/bindgen:gen", ptr %t37, i32 0, i32 17
  %t43 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v0, ptr %t39, i64 %t36)
  store %"compiler/bindgen:ctype" %t43, ptr %l31
  br label %bb4
bb4:
  %t44 = load %"compiler/bindgen:ctype", ptr %l31
  store %"compiler/bindgen:ctype" %t44, ptr %l5
  %t45 = getelementptr %"compiler/bindgen:ctype", ptr %l5, i32 0, i32 0
  %t46 = load i32, ptr %t45, !range !{i32 0, i32 7}
  %t48 = trunc i64 6 to i32
  %t49 = icmp eq i32 %t46, %t48
  br i1 %t49, label %bb5, label %bb6
bb5:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/bindgen:ctype", ptr %l5, i32 0, i32 1
  %t53 = load { i64, ptr }, ptr %t52, !tbaa !27
  %t56 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %v0, ptr %t51, { i64, ptr } %t53)
  store i32 %t56, ptr %l36
  %t57 = icmp ne i32 %t56, 0
  br i1 %t57, label %bb8, label %ok.58, !prof !99
ok.58:
  br label %bb7
bb6:
  br label %bb10
bb7:
  br label %bb9
bb8:
  %t59 = load i32, ptr %l36, !tbaa !23
  %t60 = lshr i32 %t59, 16
  %t61 = and i32 %t59, 65535
  %t62 = icmp eq i32 %t60, 1
  %t63 = select i1 %t62, i32 1, i32 0
  %t64 = icmp eq i32 %t59, 0
  %t65 = shl i32 %t63, 16
  %t66 = or i32 %t65, %t61
  %t67 = select i1 %t64, i32 0, i32 %t66
  call void @__olang_scope_close(ptr %s0)
  %t69 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t67, 0
  store { i32, { i64, ptr } } %t69, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t70 = getelementptr %"compiler/bindgen:ctype", ptr %l5, i32 0, i32 0
  %t71 = load i32, ptr %t70, !range !{i32 0, i32 7}
  %t73 = trunc i64 5 to i32
  %t74 = icmp eq i32 %t71, %t73
  %t76 = xor i1 %t74, true
  br i1 %t76, label %bb11, label %bb12
bb11:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %v0, ptr %t78, { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d186, i32 0, i32 1) })
  store i32 %t80, ptr %l42
  %t81 = icmp ne i32 %t80, 0
  br i1 %t81, label %bb14, label %ok.82, !prof !99
ok.82:
  br label %bb13
bb12:
  br label %bb16
bb13:
  br label %bb15
bb14:
  %t83 = load i32, ptr %l42, !tbaa !23
  %t84 = lshr i32 %t83, 16
  %t85 = and i32 %t83, 65535
  %t86 = icmp eq i32 %t84, 1
  %t87 = select i1 %t86, i32 1, i32 0
  %t88 = icmp eq i32 %t83, 0
  %t89 = shl i32 %t87, 16
  %t90 = or i32 %t89, %t85
  %t91 = select i1 %t88, i32 0, i32 %t90
  call void @__olang_scope_close(ptr %s0)
  %t93 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t91, 0
  store { i32, { i64, ptr } } %t93, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t94 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t94, ptr %l44
  br label %bb17
bb17:
  %t95 = load %"std/prelude/text:StringBuilder", ptr %l44
  store %"std/prelude/text:StringBuilder" %t95, ptr %l6
  %t96 = load ptr, ptr %l1, !tbaa !29
  %t98 = getelementptr %"compiler/bindgen:cFunc", ptr %t96, i32 0, i32 0
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !27
  %t100 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d187, i32 0, i32 1) }, 1
  %t101 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d187, i32 0, i32 1) }, 0
  %t103 = extractvalue { i64, ptr } %t99, 1
  %t104 = extractvalue { i64, ptr } %t99, 0
  %t105 = add i64 %t101, %t104
  %t106 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d188, i32 0, i32 1) }, 1
  %t107 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d188, i32 0, i32 1) }, 0
  %t108 = add i64 %t105, %t107
  %t109 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t108)
  call void @olang_textcopy(ptr %t109, ptr %t100, i64 %t101)
  %t110 = getelementptr i8, ptr %t109, i64 %t101
  call void @olang_textcopy(ptr %t110, ptr %t103, i64 %t104)
  %t111 = getelementptr i8, ptr %t110, i64 %t104
  call void @olang_textcopy(ptr %t111, ptr %t106, i64 %t107)
  %t112 = insertvalue { i64, ptr } undef, i64 %t108, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t109, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } %t113)
  br label %bb18
bb18:
  %t117 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t117, ptr %l50
  br label %bb19
bb19:
  %t118 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l50
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t118, ptr %l7
  store i64 0, ptr %l8, !tbaa !24
  %t119 = getelementptr %"compiler/bindgen:ctype", ptr %l5, i32 0, i32 4
  %t120 = load i64, ptr %t119, !tbaa !24
  store i64 %t120, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t122 = load i64, ptr %l9, !tbaa !24
  %t123 = load i64, ptr %l8, !tbaa !24
  %t126 = icmp sgt i64 %t122, %t123
  br i1 %t126, label %bb20, label %bb21
bb20:
  %t128 = load i64, ptr %l10, !tbaa !24
  %t130 = icmp sgt i64 %t128, 0
  br i1 %t130, label %bb22, label %bb23
bb21:
  store i64 0, ptr %l55, !tbaa !24
  br label %bb25
bb22:
  %t132 = load i64, ptr %l9, !tbaa !24
  %t133 = load i64, ptr %l8, !tbaa !24
  %t136 = sub i64 %t132, %t133
  %t137 = load i64, ptr %l10, !tbaa !24
  %t140 = add i64 %t136, %t137
  %t142 = sub i64 %t140, 1
  %t143 = load i64, ptr %l10, !tbaa !24
  %t146 = sdiv i64 %t142, %t143
  store i64 %t146, ptr %l58, !tbaa !24
  br label %bb24
bb23:
  store i64 0, ptr %l58, !tbaa !24
  br label %bb24
bb24:
  %t148 = load i64, ptr %l58, !tbaa !24
  store i64 %t148, ptr %l55, !tbaa !24
  br label %bb25
bb25:
  %t149 = load i64, ptr %l55, !tbaa !24
  store i64 %t149, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb26
bb26:
  store %olang.scope zeroinitializer, ptr %s5
  %t150 = load i64, ptr %l12, !tbaa !24
  %t151 = load i64, ptr %l11, !tbaa !24
  %t154 = icmp slt i64 %t150, %t151
  %t156 = xor i1 %t154, true
  br i1 %t156, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s5)
  br label %bb44
bb28:
  br label %bb29
bb29:
  %t158 = load i64, ptr %l8, !tbaa !24
  %t159 = load i64, ptr %l12, !tbaa !24
  %t160 = load i64, ptr %l10, !tbaa !24
  %t163 = mul i64 %t159, %t160
  %t166 = add i64 %t158, %t163
  store i64 %t166, ptr %l13, !tbaa !24
  %t168 = load i64, ptr %l13, !tbaa !24
  %t170 = icmp sgt i64 %t168, 0
  br i1 %t170, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s6
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %l6, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d189, i32 0, i32 1) })
  br label %bb32
bb31:
  br label %bb33
bb32:
  call void @__olang_scope_close(ptr %s6)
  br label %bb33
bb33:
  %t173 = load ptr, ptr %l0, !tbaa !29
  store ptr %t173, ptr %l79, !tbaa !29
  %t174 = load i64, ptr %l13, !tbaa !24
  %t175 = load ptr, ptr %l1, !tbaa !29
  %t177 = getelementptr %"compiler/bindgen:cFunc", ptr %t175, i32 0, i32 2
  %t178 = load { i64, ptr }, ptr %t177, !tbaa !27
  %t180 = extractvalue { i64, ptr } %t178, 0
  %t183 = icmp slt i64 %t174, %t180
  br i1 %t183, label %bb34, label %bb35
bb34:
  %t185 = load ptr, ptr %l1, !tbaa !29
  %t187 = getelementptr %"compiler/bindgen:cFunc", ptr %t185, i32 0, i32 2
  %t188 = load { i64, ptr }, ptr %t187, !tbaa !27
  store { i64, ptr } %t188, ptr %l87, !tbaa !27
  %t189 = load i64, ptr %l13, !tbaa !24
  %t191 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t192 = load ptr, ptr %t191, !tbaa !27
  %t193 = getelementptr { i64, ptr }, ptr %t192, i64 %t189
  %t194 = load { i64, ptr }, ptr %t193, !tbaa !37
  store { i64, ptr } %t194, ptr %l85, !tbaa !27
  br label %bb36
bb35:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d190, i32 0, i32 1) }, ptr %l85, !tbaa !27
  br label %bb36
bb36:
  %t196 = load i64, ptr %l13, !tbaa !24
  %t197 = load ptr, ptr %l79, !tbaa !29
  %t198 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t201 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eparamName(ptr %v0, ptr %v1, ptr %s0, ptr %s0, ptr %t197, { i64, ptr } %t198, i64 %t196, ptr %l7)
  store { i64, ptr } %t201, ptr %l92
  br label %bb37
bb37:
  %t202 = load { i64, ptr }, ptr %l92, !tbaa !27
  store ptr %l6, ptr %l93, !tbaa !29
  store { i64, ptr } %t202, ptr %l94, !tbaa !27
  %t204 = load ptr, ptr %l0, !tbaa !29
  store ptr %t204, ptr %l96, !tbaa !29
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr %"compiler/bindgen:gen", ptr %t205, i32 0, i32 18
  %t208 = getelementptr %"compiler/bindgen:ctype", ptr %l5, i32 0, i32 5
  %t209 = load i64, ptr %t208, !tbaa !24
  %t210 = load i64, ptr %l13, !tbaa !24
  %t213 = add i64 %t209, %t210
  %t216 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t207, i64 %t213)
  store i64 %t216, ptr %l102
  br label %bb38
bb38:
  %t217 = load ptr, ptr %l96, !tbaa !29
  %t218 = load i64, ptr %l102, !tbaa !24
  %t219 = call { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eparamType(ptr %v0, ptr %s5, ptr %t217, i64 %t218)
  %t220 = extractvalue { i32, { i64, ptr } } %t219, 1
  %t221 = extractvalue { i32, { i64, ptr } } %t219, 0
  store i32 %t221, ptr %l104
  %t222 = icmp ne i32 %t221, 0
  br i1 %t222, label %bb40, label %ok.223, !prof !99
ok.223:
  store { i64, ptr } %t220, ptr %l103
  br label %bb39
bb39:
  %t224 = load { i64, ptr }, ptr %l103, !tbaa !27
  store { i64, ptr } %t224, ptr %l95, !tbaa !27
  br label %bb41
bb40:
  %t225 = load i32, ptr %l104, !tbaa !23
  %t226 = lshr i32 %t225, 16
  %t227 = and i32 %t225, 65535
  %t228 = icmp eq i32 %t226, 1
  %t229 = select i1 %t228, i32 1, i32 0
  %t230 = icmp eq i32 %t225, 0
  %t231 = shl i32 %t229, 16
  %t232 = or i32 %t231, %t227
  %t233 = select i1 %t230, i32 0, i32 %t232
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t235 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t233, 0
  store { i32, { i64, ptr } } %t235, ptr %rv
  br label %ret
bb41:
  %t236 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t237 = extractvalue { i64, ptr } %t236, 1
  %t238 = extractvalue { i64, ptr } %t236, 0
  %t239 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d191, i32 0, i32 1) }, 1
  %t240 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d191, i32 0, i32 1) }, 0
  %t241 = add i64 %t238, %t240
  %t242 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t243 = extractvalue { i64, ptr } %t242, 1
  %t244 = extractvalue { i64, ptr } %t242, 0
  %t245 = add i64 %t241, %t244
  %t246 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t245)
  call void @olang_textcopy(ptr %t246, ptr %t237, i64 %t238)
  %t247 = getelementptr i8, ptr %t246, i64 %t238
  call void @olang_textcopy(ptr %t247, ptr %t239, i64 %t240)
  %t248 = getelementptr i8, ptr %t247, i64 %t240
  call void @olang_textcopy(ptr %t248, ptr %t243, i64 %t244)
  %t249 = insertvalue { i64, ptr } undef, i64 %t245, 0
  %t250 = insertvalue { i64, ptr } %t249, ptr %t246, 1
  %t252 = load ptr, ptr %l93, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %t252, { i64, ptr } %t250)
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s5)
  br label %bb43
bb43:
  %t254 = load i64, ptr %l12, !tbaa !24
  %t257 = add i64 %t254, 1
  store i64 %t257, ptr %l12, !tbaa !24
  br label %bb26
bb44:
  %t259 = getelementptr %"compiler/bindgen:ctype", ptr %l5, i32 0, i32 1
  %t260 = load { i64, ptr }, ptr %t259, !tbaa !27
  %t262 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t260, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d192, i32 0, i32 1) })
  store i1 %t262, ptr %l112
  br label %bb45
bb45:
  %t263 = load i1, ptr %l112, !tbaa !21
  br i1 %t263, label %bb46, label %bb47
bb46:
  store %olang.scope zeroinitializer, ptr %s9
  store ptr %l6, ptr %l113, !tbaa !29
  %t264 = getelementptr %"compiler/bindgen:ctype", ptr %l5, i32 0, i32 4
  %t265 = load i64, ptr %t264, !tbaa !24
  %t267 = icmp sgt i64 %t265, 0
  br i1 %t267, label %bb48, label %bb49
bb47:
  br label %bb52
bb48:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d193, i32 0, i32 1) }, ptr %l116, !tbaa !27
  br label %bb50
bb49:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d194, i32 0, i32 1) }, ptr %l116, !tbaa !27
  br label %bb50
bb50:
  %t269 = load ptr, ptr %l113, !tbaa !29
  %t270 = load { i64, ptr }, ptr %l116, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s9, ptr %t269, { i64, ptr } %t270)
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s9)
  br label %bb52
bb52:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d195, i32 0, i32 1) })
  br label %bb53
bb53:
  %t272 = load ptr, ptr %l0, !tbaa !29
  %t274 = getelementptr %"compiler/bindgen:gen", ptr %t272, i32 0, i32 17
  %t275 = getelementptr %"compiler/bindgen:ctype", ptr %l5, i32 0, i32 2
  %t276 = load i64, ptr %t275, !tbaa !24
  %t279 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %s0, ptr %t274, i64 %t276)
  store %"compiler/bindgen:ctype" %t279, ptr %l121
  br label %bb54
bb54:
  %t280 = getelementptr %"compiler/bindgen:ctype", ptr %l121, i32 0, i32 0
  %t281 = load i32, ptr %t280, !range !{i32 0, i32 7}
  %t283 = trunc i64 0 to i32
  %t284 = icmp eq i32 %t281, %t283
  %t286 = xor i1 %t284, true
  br i1 %t286, label %bb55, label %bb56
bb55:
  store %olang.scope zeroinitializer, ptr %s10
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t289 = getelementptr %"compiler/bindgen:ctype", ptr %l5, i32 0, i32 2
  %t290 = load i64, ptr %t289, !tbaa !24
  %t293 = call { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2evalueType(ptr %v0, ptr %v0, ptr %t288, i64 %t290, i1 false)
  %t294 = extractvalue { i32, { i64, ptr } } %t293, 1
  %t295 = extractvalue { i32, { i64, ptr } } %t293, 0
  store i32 %t295, ptr %l129
  %t296 = icmp ne i32 %t295, 0
  br i1 %t296, label %bb58, label %ok.297, !prof !99
ok.297:
  store { i64, ptr } %t294, ptr %l128
  br label %bb57
bb56:
  %t298 = load i1, ptr %l3, !tbaa !21
  br i1 %t298, label %bb70, label %bb71
bb57:
  %t300 = load { i64, ptr }, ptr %l128, !tbaa !27
  store { i64, ptr } %t300, ptr %l125, !tbaa !27
  br label %bb59
bb58:
  %t301 = load i32, ptr %l129, !tbaa !23
  %t302 = lshr i32 %t301, 16
  %t303 = and i32 %t301, 65535
  %t304 = icmp eq i32 %t302, 1
  %t305 = select i1 %t304, i32 1, i32 0
  %t306 = icmp eq i32 %t301, 0
  %t307 = shl i32 %t305, 16
  %t308 = or i32 %t307, %t303
  %t309 = select i1 %t306, i32 0, i32 %t308
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  %t311 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t309, 0
  store { i32, { i64, ptr } } %t311, ptr %rv
  br label %ret
bb59:
  %t312 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t312, ptr %lp15
  %t313 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t314 = load ptr, ptr %lp15
  store { i64, ptr } %t313, ptr %t314, !tbaa !27
  %t315 = load ptr, ptr %lp15
  %t316 = load { i64, ptr }, ptr %t315, !tbaa !27
  %t317 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d196, i32 0, i32 1) }, 1
  %t318 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d196, i32 0, i32 1) }, 0
  %t320 = extractvalue { i64, ptr } %t316, 1
  %t321 = extractvalue { i64, ptr } %t316, 0
  %t322 = add i64 %t318, %t321
  %t323 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t322)
  call void @olang_textcopy(ptr %t323, ptr %t317, i64 %t318)
  %t324 = getelementptr i8, ptr %t323, i64 %t318
  call void @olang_textcopy(ptr %t324, ptr %t320, i64 %t321)
  %t325 = insertvalue { i64, ptr } undef, i64 %t322, 0
  %t326 = insertvalue { i64, ptr } %t325, ptr %t323, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s10, ptr %l6, { i64, ptr } %t326)
  br label %bb60
bb60:
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t332 = getelementptr %"compiler/bindgen:gen", ptr %t330, i32 0, i32 17
  %t333 = getelementptr %"compiler/bindgen:ctype", ptr %l5, i32 0, i32 2
  %t334 = load i64, ptr %t333, !tbaa !24
  %t337 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %s10, ptr %t332, i64 %t334)
  store %"compiler/bindgen:ctype" %t337, ptr %l138
  br label %bb61
bb61:
  %t338 = getelementptr %"compiler/bindgen:ctype", ptr %l138, i32 0, i32 0
  %t339 = load i32, ptr %t338, !range !{i32 0, i32 7}
  %t341 = trunc i64 1 to i32
  %t342 = icmp eq i32 %t339, %t341
  br i1 %t342, label %bb62, label %bb63
bb62:
  %t344 = load ptr, ptr %l0, !tbaa !29
  %t345 = load %"compiler/bindgen:ctype", ptr %l5
  %t348 = call i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enumbersOnly(ptr %v0, ptr %v0, ptr %t344, %"compiler/bindgen:ctype" %t345)
  store i1 %t348, ptr %l144
  br label %bb64
bb63:
  store i1 false, ptr %l141, !tbaa !21
  br label %bb65
bb64:
  %t349 = load i1, ptr %l144, !tbaa !21
  store i1 %t349, ptr %l141, !tbaa !21
  br label %bb65
bb65:
  %t350 = load i1, ptr %l141, !tbaa !21
  br i1 %t350, label %bb66, label %bb67
bb66:
  %t351 = load ptr, ptr %l0, !tbaa !29
  %t353 = getelementptr %"compiler/bindgen:gen", ptr %t351, i32 0, i32 16
  %t354 = load ptr, ptr %l1, !tbaa !29
  %t356 = getelementptr %"compiler/bindgen:cFunc", ptr %t354, i32 0, i32 0
  %t357 = load { i64, ptr }, ptr %t356, !tbaa !27
  %t358 = load ptr, ptr %lp15
  %t359 = load { i64, ptr }, ptr %t358, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6f7a2f8d839c49b6e7a19c287d4b190c(ptr %v0, ptr %v1, ptr %v0, ptr %t353, { i64, ptr } %t357, { i64, ptr } %t359)
  br label %bb68
bb67:
  br label %bb69
bb68:
  br label %bb69
bb69:
  call void @__olang_scope_close(ptr %s10)
  br label %bb74
bb70:
  store %olang.scope zeroinitializer, ptr %s14
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s14, ptr %l6, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d197, i32 0, i32 1) })
  br label %bb72
bb71:
  br label %bb73
bb72:
  call void @__olang_scope_close(ptr %s14)
  br label %bb73
bb73:
  br label %bb74
bb74:
  %t365 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l6)
  store { i64, ptr } %t365, ptr %l153
  br label %bb75
bb75:
  call void @__olang_scope_close(ptr %s0)
  %t366 = load { i64, ptr }, ptr %l153, !tbaa !27
  %t367 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t366, 1
  store { i32, { i64, ptr } } %t367, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eisChar(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l5 = alloca %"compiler/bindgen:ctype"
  %l8 = alloca i1
  %l12 = alloca %"compiler/bindgen:ctype"
  %l14 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/bindgen:gen", ptr %t1, i32 0, i32 17
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %s0, ptr %t3, i64 %t4)
  store %"compiler/bindgen:ctype" %t7, ptr %l5
  br label %bb1
bb1:
  %t8 = getelementptr %"compiler/bindgen:ctype", ptr %l5, i32 0, i32 0
  %t9 = load i32, ptr %t8, !range !{i32 0, i32 7}
  %t11 = trunc i64 1 to i32
  %t12 = icmp eq i32 %t9, %t11
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/bindgen:gen", ptr %t14, i32 0, i32 17
  %t17 = load i64, ptr %l1, !tbaa !24
  %t20 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v0, ptr %t16, i64 %t17)
  store %"compiler/bindgen:ctype" %t20, ptr %l12
  br label %bb4
bb3:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb6
bb4:
  %t21 = getelementptr %"compiler/bindgen:ctype", ptr %l12, i32 0, i32 1
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  %t24 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t22, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d198, i32 0, i32 1) })
  store i1 %t24, ptr %l14
  br label %bb5
bb5:
  %t25 = load i1, ptr %l14, !tbaa !21
  store i1 %t25, ptr %l8, !tbaa !21
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t26 = load i1, ptr %l8, !tbaa !21
  store i1 %t26, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2elaidOut(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l23 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l28 = alloca i32
  %l30 = alloca i1
  %l33 = alloca i64
  %l39 = alloca %"compiler/bindgen:record"
  %l44 = alloca %"compiler/bindgen:record"
  %l49 = alloca %"compiler/bindgen:record"
  %l51 = alloca i64
  %l53 = alloca i64
  %l56 = alloca i1
  %l59 = alloca i1
  %l64 = alloca i64
  %l68 = alloca i64
  %l71 = alloca i64
  %l89 = alloca ptr
  %l92 = alloca { i64, ptr }
  %l93 = alloca i64
  %l97 = alloca %"compiler/bindgen:ctype"
  %l103 = alloca %"compiler/bindgen:ctype"
  %l105 = alloca { i64, ptr }
  %l108 = alloca { i64, ptr }
  %l109 = alloca i32
  %l111 = alloca i1
  %l117 = alloca i64
  %l121 = alloca i64
  %l124 = alloca i64
  %l145 = alloca %"compiler/bindgen:record"
  %l149 = alloca i64
  %l153 = alloca i1
  %l157 = alloca %"compiler/bindgen:record"
  %l162 = alloca i64
  %l168 = alloca i64
  %l174 = alloca i64
  %l175 = alloca i64
  %l176 = alloca i64
  %l180 = alloca %"compiler/bindgen:record"
  %l185 = alloca i64
  %l187 = alloca i64
  %l191 = alloca %"compiler/bindgen:record"
  %l196 = alloca i64
  %l197 = alloca i64
  %l208 = alloca i64
  %l214 = alloca i64
  %l215 = alloca i64
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca i1
  %t29 = alloca %"compiler/bindgen:record", align 8
  %t39 = alloca %"compiler/bindgen:record", align 8
  %t49 = alloca %"compiler/bindgen:record", align 8
  %t228 = alloca %"compiler/bindgen:record", align 8
  %t249 = alloca %"compiler/bindgen:record", align 8
  %t293 = alloca %"compiler/bindgen:record", align 8
  %t314 = alloca %"compiler/bindgen:record", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l22
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l22
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l2
  %t3 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l23
  br label %bb2
bb2:
  %t4 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l3
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i64, ptr %l1, !tbaa !24
  %t11 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eflat(ptr %v0, ptr %s0, ptr %s0, ptr %t5, i64 %t6, ptr %l2, ptr %l3)
  store i32 %t11, ptr %l28
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb4, label %ok.13, !prof !99
ok.13:
  br label %bb3
bb3:
  br label %bb6
bb4:
  %t14 = load i32, ptr %l28, !tbaa !23
  %t15 = ashr i32 %t14, 16
  %t17 = icmp eq i32 %t15, 1
  store i1 %t17, ptr %l30, !tbaa !21
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb6:
  %t20 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l2)
  store i64 %t20, ptr %l33
  br label %bb7
bb7:
  %t21 = load i64, ptr %l33, !tbaa !24
  %t22 = icmp eq i64 %t21, 0
  br i1 %t22, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/bindgen:gen", ptr %t25, i32 0, i32 6
  %t28 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t29, ptr %v0, ptr %s0, ptr %t27, i64 %t28)
  call void @llvm.memmove.p0.p0.i64(ptr %l39, ptr %t29, i64 312, i1 false)
  br label %bb11
bb11:
  %t32 = getelementptr %"compiler/bindgen:record", ptr %l39, i32 0, i32 13
  %t33 = load i64, ptr %t32, !tbaa !24
  store i64 %t33, ptr %l4, !tbaa !24
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/bindgen:gen", ptr %t35, i32 0, i32 6
  %t38 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t39, ptr %v0, ptr %s0, ptr %t37, i64 %t38)
  call void @llvm.memmove.p0.p0.i64(ptr %l44, ptr %t39, i64 312, i1 false)
  br label %bb12
bb12:
  %t42 = getelementptr %"compiler/bindgen:record", ptr %l44, i32 0, i32 14
  %t43 = load i64, ptr %t42, !tbaa !24
  store i64 %t43, ptr %l5, !tbaa !24
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/bindgen:gen", ptr %t45, i32 0, i32 6
  %t48 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t49, ptr %v0, ptr %v0, ptr %t47, i64 %t48)
  call void @llvm.memmove.p0.p0.i64(ptr %l49, ptr %t49, i64 312, i1 false)
  br label %bb13
bb13:
  %t52 = getelementptr %"compiler/bindgen:record", ptr %l49, i32 0, i32 18
  %t54 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t52)
  store i64 %t54, ptr %l51
  br label %bb14
bb14:
  %t56 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l2)
  store i64 %t56, ptr %l53
  br label %bb15
bb15:
  %t57 = load i64, ptr %l53, !tbaa !24
  %t58 = mul i64 3, %t57
  %t59 = load i64, ptr %l51, !tbaa !24
  %t61 = icmp ne i64 %t59, %t58
  br i1 %t61, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l56, !tbaa !21
  br label %bb18
bb17:
  %t63 = load i64, ptr %l4, !tbaa !24
  %t65 = icmp sle i64 %t63, 0
  store i1 %t65, ptr %l56, !tbaa !21
  br label %bb18
bb18:
  %t67 = load i1, ptr %l56, !tbaa !21
  br i1 %t67, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l59, !tbaa !21
  br label %bb21
bb20:
  %t68 = load i64, ptr %l5, !tbaa !24
  %t70 = icmp sle i64 %t68, 0
  store i1 %t70, ptr %l59, !tbaa !21
  br label %bb21
bb21:
  %t72 = load i1, ptr %l59, !tbaa !21
  br i1 %t72, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  store i64 0, ptr %l6, !tbaa !24
  %t75 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l3)
  store i64 %t75, ptr %l64
  br label %bb25
bb25:
  %t76 = load i64, ptr %l64, !tbaa !24
  store i64 %t76, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t77 = load i64, ptr %l7, !tbaa !24
  %t78 = load i64, ptr %l6, !tbaa !24
  %t81 = icmp sgt i64 %t77, %t78
  br i1 %t81, label %bb26, label %bb27
bb26:
  %t83 = load i64, ptr %l8, !tbaa !24
  %t85 = icmp sgt i64 %t83, 0
  br i1 %t85, label %bb28, label %bb29
bb27:
  store i64 0, ptr %l68, !tbaa !24
  br label %bb31
bb28:
  %t87 = load i64, ptr %l7, !tbaa !24
  %t88 = load i64, ptr %l6, !tbaa !24
  %t91 = sub i64 %t87, %t88
  %t92 = load i64, ptr %l8, !tbaa !24
  %t95 = add i64 %t91, %t92
  %t97 = sub i64 %t95, 1
  %t98 = load i64, ptr %l8, !tbaa !24
  %t101 = sdiv i64 %t97, %t98
  store i64 %t101, ptr %l71, !tbaa !24
  br label %bb30
bb29:
  store i64 0, ptr %l71, !tbaa !24
  br label %bb30
bb30:
  %t103 = load i64, ptr %l71, !tbaa !24
  store i64 %t103, ptr %l68, !tbaa !24
  br label %bb31
bb31:
  %t104 = load i64, ptr %l68, !tbaa !24
  store i64 %t104, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb32
bb32:
  store %olang.scope zeroinitializer, ptr %s5
  %t105 = load i64, ptr %l10, !tbaa !24
  %t106 = load i64, ptr %l9, !tbaa !24
  %t109 = icmp slt i64 %t105, %t106
  %t111 = xor i1 %t109, true
  br i1 %t111, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s5)
  br label %bb48
bb34:
  br label %bb35
bb35:
  %t113 = load i64, ptr %l6, !tbaa !24
  %t114 = load i64, ptr %l10, !tbaa !24
  %t115 = load i64, ptr %l8, !tbaa !24
  %t118 = mul i64 %t114, %t115
  %t121 = add i64 %t113, %t118
  %t123 = load ptr, ptr %l0, !tbaa !29
  store ptr %t123, ptr %l89, !tbaa !29
  %t127 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l3, i64 %t121)
  store { i64, ptr } %t127, ptr %l92
  br label %bb36
bb36:
  %t128 = load ptr, ptr %l89, !tbaa !29
  %t129 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t130 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eparseType(ptr %v0, ptr %s0, ptr %t128, { i64, ptr } %t129, i64 0)
  store i64 %t130, ptr %l93
  br label %bb37
bb37:
  %t131 = load i64, ptr %l93, !tbaa !24
  store i64 %t131, ptr %l12, !tbaa !24
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/bindgen:gen", ptr %t132, i32 0, i32 17
  %t135 = load i64, ptr %l12, !tbaa !24
  %t138 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %s5, ptr %t134, i64 %t135)
  store %"compiler/bindgen:ctype" %t138, ptr %l97
  br label %bb38
bb38:
  %t139 = getelementptr %"compiler/bindgen:ctype", ptr %l97, i32 0, i32 0
  %t140 = load i32, ptr %t139, !range !{i32 0, i32 7}
  %t142 = trunc i64 4 to i32
  %t143 = icmp eq i32 %t140, %t142
  br i1 %t143, label %bb39, label %bb40
bb39:
  store %olang.scope zeroinitializer, ptr %s6
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/bindgen:gen", ptr %t145, i32 0, i32 17
  %t148 = load i64, ptr %l12, !tbaa !24
  %t151 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %s6, ptr %t147, i64 %t148)
  store %"compiler/bindgen:ctype" %t151, ptr %l103
  br label %bb41
bb40:
  br label %bb42
bb41:
  %t152 = getelementptr %"compiler/bindgen:ctype", ptr %l103, i32 0, i32 2
  %t153 = load i64, ptr %t152, !tbaa !24
  store i64 %t153, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb42
bb42:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load i64, ptr %l12, !tbaa !24
  %t159 = call { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2efieldType(ptr %v0, ptr %s5, ptr %t155, i64 %t156)
  %t160 = extractvalue { i32, { i64, ptr } } %t159, 1
  %t161 = extractvalue { i32, { i64, ptr } } %t159, 0
  store i32 %t161, ptr %l109
  %t162 = icmp ne i32 %t161, 0
  br i1 %t162, label %bb44, label %ok.163, !prof !99
ok.163:
  store { i64, ptr } %t160, ptr %l108
  br label %bb43
bb43:
  %t164 = load { i64, ptr }, ptr %l108, !tbaa !27
  store { i64, ptr } %t164, ptr %l105, !tbaa !27
  br label %bb46
bb44:
  %t165 = load i32, ptr %l109, !tbaa !23
  %t166 = ashr i32 %t165, 16
  %t168 = icmp eq i32 %t166, 1
  store i1 %t168, ptr %l111, !tbaa !21
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb46:
  call void @__olang_scope_close(ptr %s5)
  br label %bb47
bb47:
  %t170 = load i64, ptr %l10, !tbaa !24
  %t173 = add i64 %t170, 1
  store i64 %t173, ptr %l10, !tbaa !24
  br label %bb32
bb48:
  store i64 0, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  %t176 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l2)
  store i64 %t176, ptr %l117
  br label %bb49
bb49:
  %t177 = load i64, ptr %l117, !tbaa !24
  store i64 %t177, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t178 = load i64, ptr %l16, !tbaa !24
  %t179 = load i64, ptr %l15, !tbaa !24
  %t182 = icmp sgt i64 %t178, %t179
  br i1 %t182, label %bb50, label %bb51
bb50:
  %t184 = load i64, ptr %l17, !tbaa !24
  %t186 = icmp sgt i64 %t184, 0
  br i1 %t186, label %bb52, label %bb53
bb51:
  store i64 0, ptr %l121, !tbaa !24
  br label %bb55
bb52:
  %t188 = load i64, ptr %l16, !tbaa !24
  %t189 = load i64, ptr %l15, !tbaa !24
  %t192 = sub i64 %t188, %t189
  %t193 = load i64, ptr %l17, !tbaa !24
  %t196 = add i64 %t192, %t193
  %t198 = sub i64 %t196, 1
  %t199 = load i64, ptr %l17, !tbaa !24
  %t202 = sdiv i64 %t198, %t199
  store i64 %t202, ptr %l124, !tbaa !24
  br label %bb54
bb53:
  store i64 0, ptr %l124, !tbaa !24
  br label %bb54
bb54:
  %t204 = load i64, ptr %l124, !tbaa !24
  store i64 %t204, ptr %l121, !tbaa !24
  br label %bb55
bb55:
  %t205 = load i64, ptr %l121, !tbaa !24
  store i64 %t205, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb56
bb56:
  %t206 = load i64, ptr %l19, !tbaa !24
  %t207 = load i64, ptr %l18, !tbaa !24
  %t210 = icmp slt i64 %t206, %t207
  %t212 = xor i1 %t210, true
  br i1 %t212, label %bb57, label %bb58
bb57:
  br label %bb81
bb58:
  br label %bb59
bb59:
  %t214 = load i64, ptr %l15, !tbaa !24
  %t215 = load i64, ptr %l19, !tbaa !24
  %t216 = load i64, ptr %l17, !tbaa !24
  %t219 = mul i64 %t215, %t216
  %t222 = add i64 %t214, %t219
  store i64 %t222, ptr %l20, !tbaa !24
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t226 = getelementptr %"compiler/bindgen:gen", ptr %t224, i32 0, i32 6
  %t227 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t228, ptr %v0, ptr %v0, ptr %t226, i64 %t227)
  call void @llvm.memmove.p0.p0.i64(ptr %l145, ptr %t228, i64 312, i1 false)
  br label %bb60
bb60:
  %t231 = getelementptr %"compiler/bindgen:record", ptr %l145, i32 0, i32 18
  %t232 = load i64, ptr %l20, !tbaa !24
  %t234 = mul i64 3, %t232
  %t237 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t231, i64 %t234)
  store i64 %t237, ptr %l149
  br label %bb61
bb61:
  %t238 = load i64, ptr %l149, !tbaa !24
  store i64 %t238, ptr %l21, !tbaa !24
  %t239 = load i64, ptr %l21, !tbaa !24
  %t240 = load i64, ptr %l13, !tbaa !24
  %t243 = icmp slt i64 %t239, %t240
  br i1 %t243, label %bb62, label %bb63
bb62:
  store i1 true, ptr %l153, !tbaa !21
  br label %bb66
bb63:
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t247 = getelementptr %"compiler/bindgen:gen", ptr %t245, i32 0, i32 6
  %t248 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t249, ptr %v0, ptr %v0, ptr %t247, i64 %t248)
  call void @llvm.memmove.p0.p0.i64(ptr %l157, ptr %t249, i64 312, i1 false)
  br label %bb64
bb64:
  %t252 = getelementptr %"compiler/bindgen:record", ptr %l157, i32 0, i32 18
  %t253 = load i64, ptr %l20, !tbaa !24
  %t255 = mul i64 3, %t253
  %t257 = add i64 %t255, 2
  %t260 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t252, i64 %t257)
  store i64 %t260, ptr %l162
  br label %bb65
bb65:
  %t261 = load i64, ptr %l162, !tbaa !24
  %t262 = icmp sle i64 %t261, 0
  store i1 %t262, ptr %l153, !tbaa !21
  br label %bb66
bb66:
  %t264 = load i1, ptr %l153, !tbaa !21
  br i1 %t264, label %bb67, label %bb68
bb67:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb68:
  br label %bb69
bb69:
  %t266 = load i64, ptr %l21, !tbaa !24
  %t267 = load i64, ptr %l13, !tbaa !24
  %t270 = icmp sgt i64 %t266, %t267
  br i1 %t270, label %bb70, label %bb71
bb70:
  %t272 = load i64, ptr %l14, !tbaa !24
  store i64 %t272, ptr %l168, !tbaa !24
  %t273 = load i64, ptr %l13, !tbaa !24
  %t274 = load i64, ptr %l21, !tbaa !24
  %t275 = load i64, ptr %l13, !tbaa !24
  %t278 = sub i64 %t274, %t275
  %t279 = load i64, ptr %l5, !tbaa !24
  %t283 = call i64 @compiler_2fbindgen_2egapWord(i64 %t273, i64 %t278, i64 %t279)
  store i64 %t283, ptr %l174
  br label %bb72
bb71:
  br label %bb74
bb72:
  %t284 = load i64, ptr %l168, !tbaa !24
  %t285 = load i64, ptr %l174, !tbaa !24
  %t286 = call i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %t284, i64 %t285)
  store i64 %t286, ptr %l175
  br label %bb73
bb73:
  %t287 = load i64, ptr %l175, !tbaa !24
  store i64 %t287, ptr %l14, !tbaa !24
  br label %bb74
bb74:
  %t288 = load i64, ptr %l21, !tbaa !24
  store i64 %t288, ptr %l176, !tbaa !24
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t291 = getelementptr %"compiler/bindgen:gen", ptr %t289, i32 0, i32 6
  %t292 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t293, ptr %v0, ptr %v0, ptr %t291, i64 %t292)
  call void @llvm.memmove.p0.p0.i64(ptr %l180, ptr %t293, i64 312, i1 false)
  br label %bb75
bb75:
  %t296 = getelementptr %"compiler/bindgen:record", ptr %l180, i32 0, i32 18
  %t297 = load i64, ptr %l20, !tbaa !24
  %t299 = mul i64 3, %t297
  %t301 = add i64 %t299, 1
  %t304 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t296, i64 %t301)
  store i64 %t304, ptr %l185
  br label %bb76
bb76:
  %t305 = load i64, ptr %l176, !tbaa !24
  %t306 = load i64, ptr %l185, !tbaa !24
  %t307 = add i64 %t305, %t306
  store i64 %t307, ptr %l13, !tbaa !24
  %t309 = load i64, ptr %l14, !tbaa !24
  store i64 %t309, ptr %l187, !tbaa !24
  %t310 = load ptr, ptr %l0, !tbaa !29
  %t312 = getelementptr %"compiler/bindgen:gen", ptr %t310, i32 0, i32 6
  %t313 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t314, ptr %v0, ptr %v0, ptr %t312, i64 %t313)
  call void @llvm.memmove.p0.p0.i64(ptr %l191, ptr %t314, i64 312, i1 false)
  br label %bb77
bb77:
  %t317 = getelementptr %"compiler/bindgen:record", ptr %l191, i32 0, i32 18
  %t318 = load i64, ptr %l20, !tbaa !24
  %t320 = mul i64 3, %t318
  %t322 = add i64 %t320, 2
  %t325 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t317, i64 %t322)
  store i64 %t325, ptr %l196
  br label %bb78
bb78:
  %t326 = load i64, ptr %l187, !tbaa !24
  %t327 = load i64, ptr %l196, !tbaa !24
  %t328 = call i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %t326, i64 %t327)
  store i64 %t328, ptr %l197
  br label %bb79
bb79:
  %t329 = load i64, ptr %l197, !tbaa !24
  store i64 %t329, ptr %l14, !tbaa !24
  br label %bb80
bb80:
  %t330 = load i64, ptr %l19, !tbaa !24
  %t333 = add i64 %t330, 1
  store i64 %t333, ptr %l19, !tbaa !24
  br label %bb56
bb81:
  %t335 = load i64, ptr %l13, !tbaa !24
  %t336 = load i64, ptr %l4, !tbaa !24
  %t339 = icmp sgt i64 %t335, %t336
  br i1 %t339, label %bb82, label %bb83
bb82:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb83:
  br label %bb84
bb84:
  %t342 = load i64, ptr %l4, !tbaa !24
  %t343 = load i64, ptr %l13, !tbaa !24
  %t346 = icmp sgt i64 %t342, %t343
  br i1 %t346, label %bb85, label %bb86
bb85:
  %t348 = load i64, ptr %l14, !tbaa !24
  store i64 %t348, ptr %l208, !tbaa !24
  %t349 = load i64, ptr %l13, !tbaa !24
  %t350 = load i64, ptr %l4, !tbaa !24
  %t351 = load i64, ptr %l13, !tbaa !24
  %t354 = sub i64 %t350, %t351
  %t355 = load i64, ptr %l5, !tbaa !24
  %t359 = call i64 @compiler_2fbindgen_2egapWord(i64 %t349, i64 %t354, i64 %t355)
  store i64 %t359, ptr %l214
  br label %bb87
bb86:
  br label %bb89
bb87:
  %t360 = load i64, ptr %l208, !tbaa !24
  %t361 = load i64, ptr %l214, !tbaa !24
  %t362 = call i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %t360, i64 %t361)
  store i64 %t362, ptr %l215
  br label %bb88
bb88:
  %t363 = load i64, ptr %l215, !tbaa !24
  store i64 %t363, ptr %l14, !tbaa !24
  br label %bb89
bb89:
  %t364 = load i64, ptr %l14, !tbaa !24
  %t365 = load i64, ptr %l5, !tbaa !24
  %t368 = icmp eq i64 %t364, %t365
  call void @__olang_scope_close(ptr %s0)
  store i1 %t368, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2emacroFn(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca %"compiler/bindgen:cparse"
  %l5 = alloca %"compiler/bindgen:cx"
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l30 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l31 = alloca i32
  %l34 = alloca i64
  %l37 = alloca i32
  %l39 = alloca i64
  %l42 = alloca { i64, ptr }
  %l45 = alloca %"compiler/bindgen:cparse"
  %l46 = alloca %"compiler/bindgen:cx"
  %l49 = alloca %"compiler/bindgen:cx"
  %l50 = alloca i32
  %l52 = alloca i64
  %l54 = alloca i64
  %l56 = alloca ptr
  %l57 = alloca i64
  %l60 = alloca { i64, ptr }
  %l63 = alloca i32
  %l65 = alloca %"std/prelude/text:StringBuilder"
  %l82 = alloca i64
  %l85 = alloca i64
  %l103 = alloca ptr
  %l106 = alloca { i64, ptr }
  %l121 = alloca i64
  %l124 = alloca i64
  %l142 = alloca ptr
  %l145 = alloca { i64, ptr }
  %l155 = alloca { i64, ptr }
  %l169 = alloca { i64, ptr }
  %l174 = alloca { i64, ptr }
  %l176 = alloca { i64, ptr }
  %l178 = alloca i64
  %l179 = alloca { i64, ptr }
  %l186 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l21
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l21
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l2
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"compiler/bindgen:cMacro", ptr %t3, i32 0, i32 0
  %t6 = load { i64, ptr }, ptr %t5, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v1, ptr %l2, { i64, ptr } %t6)
  br label %bb2
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/bindgen:cMacro", ptr %t10, i32 0, i32 3
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t17 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eexpand(ptr %v0, ptr %v1, ptr %s0, ptr %s0, ptr %t9, { i64, ptr } %t13, ptr %l2, i64 0)
  %t18 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t17, 1
  %t19 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t17, 0
  store i32 %t19, ptr %l31
  %t20 = icmp ne i32 %t19, 0
  br i1 %t20, label %bb4, label %ok.21, !prof !99
ok.21:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %l30
  br label %bb3
bb3:
  %t22 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l30
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t22, ptr %l25
  br label %bb5
bb4:
  %t23 = load i32, ptr %l31, !tbaa !23
  %t24 = lshr i32 %t23, 16
  %t25 = and i32 %t23, 65535
  %t26 = icmp eq i32 %t24, 1
  %t27 = select i1 %t26, i32 1, i32 0
  %t28 = icmp eq i32 %t23, 0
  %t29 = shl i32 %t27, 16
  %t30 = or i32 %t29, %t25
  %t31 = select i1 %t28, i32 0, i32 %t30
  call void @__olang_scope_close(ptr %s0)
  %t33 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t31, 0
  store { i32, { i64, ptr } } %t33, ptr %rv
  br label %ret
bb5:
  %t34 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l25
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t34, ptr %l3
  %t36 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l3)
  store i64 %t36, ptr %l34
  br label %bb6
bb6:
  %t37 = load i64, ptr %l34, !tbaa !24
  %t38 = icmp eq i64 %t37, 0
  br i1 %t38, label %bb7, label %bb8
bb7:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %v0, ptr %t40, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d199, i32 0, i32 1) })
  store i32 %t42, ptr %l37
  %t43 = icmp ne i32 %t42, 0
  br i1 %t43, label %bb10, label %ok.44, !prof !99
ok.44:
  br label %bb9
bb8:
  br label %bb12
bb9:
  br label %bb11
bb10:
  %t45 = load i32, ptr %l37, !tbaa !23
  %t46 = lshr i32 %t45, 16
  %t47 = and i32 %t45, 65535
  %t48 = icmp eq i32 %t46, 1
  %t49 = select i1 %t48, i32 1, i32 0
  %t50 = icmp eq i32 %t45, 0
  %t51 = shl i32 %t49, 16
  %t52 = or i32 %t51, %t47
  %t53 = select i1 %t50, i32 0, i32 %t52
  call void @__olang_scope_close(ptr %s0)
  %t55 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t53, 0
  store { i32, { i64, ptr } } %t55, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t56 = call ptr @__olang_scope_hold(ptr %s0)
  %t57 = ptrtoint ptr %t56 to i64
  store i64 %t57, ptr %l39, !tbaa !24
  %t58 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3acparse_2e0
  br i1 %t58, label %bb13, label %bb14
bb13:
  %t60 = call ptr @__olang_region_make(ptr %s0)
  %t61 = ptrtoint ptr %t60 to i64
  store i64 %t61, ptr %l39, !tbaa !24
  br label %bb14
bb14:
  %t62 = load i64, ptr %l39
  %t63 = inttoptr i64 %t62 to ptr
  %t65 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %s0, ptr %t63, ptr %l3)
  store { i64, ptr } %t65, ptr %l42
  br label %bb15
bb15:
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t68 = getelementptr %"compiler/bindgen:cMacro", ptr %t66, i32 0, i32 2
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  %t70 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t72 = call %"compiler/bindgen:cparse" @compiler_2fbindgen_3acparse_2ector(ptr %s0, ptr %v1, ptr %s0, { i64, ptr } %t70, { i64, ptr } %t69)
  store %"compiler/bindgen:cparse" %t72, ptr %l45
  br label %bb16
bb16:
  %t73 = load %"compiler/bindgen:cparse", ptr %l45
  store %"compiler/bindgen:cparse" %t73, ptr %l4
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t77 = call { i32, %"compiler/bindgen:cx" } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecExpr(ptr %v0, ptr %s0, ptr %s0, ptr %t74, ptr %l4)
  %t78 = extractvalue { i32, %"compiler/bindgen:cx" } %t77, 1
  %t79 = extractvalue { i32, %"compiler/bindgen:cx" } %t77, 0
  store i32 %t79, ptr %l50
  %t80 = icmp ne i32 %t79, 0
  br i1 %t80, label %bb18, label %ok.81, !prof !99
ok.81:
  store %"compiler/bindgen:cx" %t78, ptr %l49
  br label %bb17
bb17:
  %t82 = load %"compiler/bindgen:cx", ptr %l49
  store %"compiler/bindgen:cx" %t82, ptr %l46
  br label %bb19
bb18:
  %t83 = load i32, ptr %l50, !tbaa !23
  %t84 = lshr i32 %t83, 16
  %t85 = and i32 %t83, 65535
  %t86 = icmp eq i32 %t84, 1
  %t87 = select i1 %t86, i32 1, i32 0
  %t88 = icmp eq i32 %t83, 0
  %t89 = shl i32 %t87, 16
  %t90 = or i32 %t89, %t85
  %t91 = select i1 %t88, i32 0, i32 %t90
  call void @__olang_scope_close(ptr %s0)
  %t93 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t91, 0
  store { i32, { i64, ptr } } %t93, ptr %rv
  br label %ret
bb19:
  %t94 = load %"compiler/bindgen:cx", ptr %l46
  store %"compiler/bindgen:cx" %t94, ptr %l5
  %t95 = getelementptr %"compiler/bindgen:cparse", ptr %l4, i32 0, i32 2
  %t96 = load i64, ptr %t95, !tbaa !24
  store i64 %t96, ptr %l52, !tbaa !24
  %t98 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l3)
  store i64 %t98, ptr %l54
  br label %bb20
bb20:
  %t99 = load i64, ptr %l52, !tbaa !24
  %t100 = load i64, ptr %l54, !tbaa !24
  %t101 = icmp ne i64 %t99, %t100
  br i1 %t101, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s2
  %t103 = load ptr, ptr %l0, !tbaa !29
  store ptr %t103, ptr %l56, !tbaa !29
  %t104 = call ptr @__olang_scope_hold(ptr %v0)
  %t105 = ptrtoint ptr %t104 to i64
  store i64 %t105, ptr %l57, !tbaa !24
  %t106 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3agen_2e26
  br i1 %t106, label %bb23, label %bb24
bb22:
  br label %bb29
bb23:
  %t108 = call ptr @__olang_region_make(ptr %v0)
  %t109 = ptrtoint ptr %t108 to i64
  store i64 %t109, ptr %l57, !tbaa !24
  br label %bb24
bb24:
  %t111 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3acparse_2eat(ptr %s0, ptr %s2, ptr %l4)
  store { i64, ptr } %t111, ptr %l60
  br label %bb25
bb25:
  %t112 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d200, i32 0, i32 1) }, 1
  %t113 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d200, i32 0, i32 1) }, 0
  %t114 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t115 = extractvalue { i64, ptr } %t114, 1
  %t116 = extractvalue { i64, ptr } %t114, 0
  %t117 = add i64 %t113, %t116
  %t118 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d201, i32 0, i32 1) }, 1
  %t119 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d201, i32 0, i32 1) }, 0
  %t120 = add i64 %t117, %t119
  %t121 = load i64, ptr %l57
  %t122 = inttoptr i64 %t121 to ptr
  %t123 = call ptr @__olang_held_alloc(ptr %t122, i64 %t120)
  call void @olang_textcopy(ptr %t123, ptr %t112, i64 %t113)
  %t124 = getelementptr i8, ptr %t123, i64 %t113
  call void @olang_textcopy(ptr %t124, ptr %t115, i64 %t116)
  %t125 = getelementptr i8, ptr %t124, i64 %t116
  call void @olang_textcopy(ptr %t125, ptr %t118, i64 %t119)
  %t126 = insertvalue { i64, ptr } undef, i64 %t120, 0
  %t127 = insertvalue { i64, ptr } %t126, ptr %t123, 1
  %t129 = load ptr, ptr %l56, !tbaa !29
  %t131 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %v0, ptr %t129, { i64, ptr } %t127)
  store i32 %t131, ptr %l63
  %t132 = icmp ne i32 %t131, 0
  br i1 %t132, label %bb27, label %ok.133, !prof !99
ok.133:
  br label %bb26
bb26:
  br label %bb28
bb27:
  %t134 = load i32, ptr %l63, !tbaa !23
  %t135 = lshr i32 %t134, 16
  %t136 = and i32 %t134, 65535
  %t137 = icmp eq i32 %t135, 1
  %t138 = select i1 %t137, i32 1, i32 0
  %t139 = icmp eq i32 %t134, 0
  %t140 = shl i32 %t138, 16
  %t141 = or i32 %t140, %t136
  %t142 = select i1 %t139, i32 0, i32 %t141
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t144 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t142, 0
  store { i32, { i64, ptr } } %t144, ptr %rv
  br label %ret
bb28:
  call void @__olang_scope_close(ptr %s2)
  br label %bb29
bb29:
  %t145 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t145, ptr %l65
  br label %bb30
bb30:
  %t146 = load %"std/prelude/text:StringBuilder", ptr %l65
  store %"std/prelude/text:StringBuilder" %t146, ptr %l6
  %t147 = load ptr, ptr %l1, !tbaa !29
  %t149 = getelementptr %"compiler/bindgen:cMacro", ptr %t147, i32 0, i32 0
  %t150 = load { i64, ptr }, ptr %t149, !tbaa !27
  %t151 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d202, i32 0, i32 1) }, 1
  %t152 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d202, i32 0, i32 1) }, 0
  %t154 = extractvalue { i64, ptr } %t150, 1
  %t155 = extractvalue { i64, ptr } %t150, 0
  %t156 = add i64 %t152, %t155
  %t157 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t156)
  call void @olang_textcopy(ptr %t157, ptr %t151, i64 %t152)
  %t158 = getelementptr i8, ptr %t157, i64 %t152
  call void @olang_textcopy(ptr %t158, ptr %t154, i64 %t155)
  %t159 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t160 = insertvalue { i64, ptr } %t159, ptr %t157, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } %t160)
  br label %bb31
bb31:
  %t164 = load ptr, ptr %l1, !tbaa !29
  %t166 = getelementptr %"compiler/bindgen:cMacro", ptr %t164, i32 0, i32 2
  %t167 = load { i64, ptr }, ptr %t166, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t167, 0
  %t171 = icmp sgt i64 %t169, 0
  br i1 %t171, label %bb32, label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s5
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %l6, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d203, i32 0, i32 1) })
  br label %bb34
bb33:
  br label %bb52
bb34:
  store i64 0, ptr %l7, !tbaa !24
  %t174 = load ptr, ptr %l1, !tbaa !29
  %t176 = getelementptr %"compiler/bindgen:cMacro", ptr %t174, i32 0, i32 2
  %t177 = load { i64, ptr }, ptr %t176, !tbaa !27
  %t179 = extractvalue { i64, ptr } %t177, 0
  store i64 %t179, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t181 = load i64, ptr %l8, !tbaa !24
  %t182 = load i64, ptr %l7, !tbaa !24
  %t185 = icmp sgt i64 %t181, %t182
  br i1 %t185, label %bb35, label %bb36
bb35:
  %t187 = load i64, ptr %l9, !tbaa !24
  %t189 = icmp sgt i64 %t187, 0
  br i1 %t189, label %bb37, label %bb38
bb36:
  store i64 0, ptr %l82, !tbaa !24
  br label %bb40
bb37:
  %t191 = load i64, ptr %l8, !tbaa !24
  %t192 = load i64, ptr %l7, !tbaa !24
  %t195 = sub i64 %t191, %t192
  %t196 = load i64, ptr %l9, !tbaa !24
  %t199 = add i64 %t195, %t196
  %t201 = sub i64 %t199, 1
  %t202 = load i64, ptr %l9, !tbaa !24
  %t205 = sdiv i64 %t201, %t202
  store i64 %t205, ptr %l85, !tbaa !24
  br label %bb39
bb38:
  store i64 0, ptr %l85, !tbaa !24
  br label %bb39
bb39:
  %t207 = load i64, ptr %l85, !tbaa !24
  store i64 %t207, ptr %l82, !tbaa !24
  br label %bb40
bb40:
  %t208 = load i64, ptr %l82, !tbaa !24
  store i64 %t208, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb41
bb41:
  store %olang.scope zeroinitializer, ptr %s7
  %t209 = load i64, ptr %l11, !tbaa !24
  %t210 = load i64, ptr %l10, !tbaa !24
  %t213 = icmp slt i64 %t209, %t210
  %t215 = xor i1 %t213, true
  br i1 %t215, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s7)
  br label %bb50
bb43:
  br label %bb44
bb44:
  %t217 = load i64, ptr %l7, !tbaa !24
  %t218 = load i64, ptr %l11, !tbaa !24
  %t219 = load i64, ptr %l9, !tbaa !24
  %t222 = mul i64 %t218, %t219
  %t225 = add i64 %t217, %t222
  store i64 %t225, ptr %l12, !tbaa !24
  store ptr %l6, ptr %l103, !tbaa !29
  %t227 = load i64, ptr %l12, !tbaa !24
  %t229 = icmp sgt i64 %t227, 0
  br i1 %t229, label %bb45, label %bb46
bb45:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d204, i32 0, i32 1) }, ptr %l106, !tbaa !27
  br label %bb47
bb46:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d205, i32 0, i32 1) }, ptr %l106, !tbaa !27
  br label %bb47
bb47:
  %t231 = load i64, ptr %l12, !tbaa !24
  %t232 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t233 = extractvalue { i64, ptr } %t232, 1
  %t234 = extractvalue { i64, ptr } %t232, 0
  %t235 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d206, i32 0, i32 1) }, 1
  %t236 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d206, i32 0, i32 1) }, 0
  %t237 = add i64 %t234, %t236
  %t239 = call i64 @__olang_fmt_i64(ptr null, i64 %t231)
  %t240 = add i64 %t237, %t239
  %t241 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t240)
  call void @olang_textcopy(ptr %t241, ptr %t233, i64 %t234)
  %t242 = getelementptr i8, ptr %t241, i64 %t234
  call void @olang_textcopy(ptr %t242, ptr %t235, i64 %t236)
  %t243 = getelementptr i8, ptr %t242, i64 %t236
  %t244 = call i64 @__olang_fmt_i64(ptr %t243, i64 %t231)
  %t245 = insertvalue { i64, ptr } undef, i64 %t240, 0
  %t246 = insertvalue { i64, ptr } %t245, ptr %t241, 1
  %t248 = load ptr, ptr %l103, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %t248, { i64, ptr } %t246)
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s7)
  br label %bb49
bb49:
  %t250 = load i64, ptr %l11, !tbaa !24
  %t253 = add i64 %t250, 1
  store i64 %t253, ptr %l11, !tbaa !24
  br label %bb41
bb50:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %l6, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d207, i32 0, i32 1) })
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s5)
  br label %bb52
bb52:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d208, i32 0, i32 1) })
  br label %bb53
bb53:
  store i64 0, ptr %l13, !tbaa !24
  %t257 = load ptr, ptr %l1, !tbaa !29
  %t259 = getelementptr %"compiler/bindgen:cMacro", ptr %t257, i32 0, i32 2
  %t260 = load { i64, ptr }, ptr %t259, !tbaa !27
  %t262 = extractvalue { i64, ptr } %t260, 0
  store i64 %t262, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t264 = load i64, ptr %l14, !tbaa !24
  %t265 = load i64, ptr %l13, !tbaa !24
  %t268 = icmp sgt i64 %t264, %t265
  br i1 %t268, label %bb54, label %bb55
bb54:
  %t270 = load i64, ptr %l15, !tbaa !24
  %t272 = icmp sgt i64 %t270, 0
  br i1 %t272, label %bb56, label %bb57
bb55:
  store i64 0, ptr %l121, !tbaa !24
  br label %bb59
bb56:
  %t274 = load i64, ptr %l14, !tbaa !24
  %t275 = load i64, ptr %l13, !tbaa !24
  %t278 = sub i64 %t274, %t275
  %t279 = load i64, ptr %l15, !tbaa !24
  %t282 = add i64 %t278, %t279
  %t284 = sub i64 %t282, 1
  %t285 = load i64, ptr %l15, !tbaa !24
  %t288 = sdiv i64 %t284, %t285
  store i64 %t288, ptr %l124, !tbaa !24
  br label %bb58
bb57:
  store i64 0, ptr %l124, !tbaa !24
  br label %bb58
bb58:
  %t290 = load i64, ptr %l124, !tbaa !24
  store i64 %t290, ptr %l121, !tbaa !24
  br label %bb59
bb59:
  %t291 = load i64, ptr %l121, !tbaa !24
  store i64 %t291, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb60
bb60:
  store %olang.scope zeroinitializer, ptr %s11
  %t292 = load i64, ptr %l17, !tbaa !24
  %t293 = load i64, ptr %l16, !tbaa !24
  %t296 = icmp slt i64 %t292, %t293
  %t298 = xor i1 %t296, true
  br i1 %t298, label %bb61, label %bb62
bb61:
  call void @__olang_scope_close(ptr %s11)
  br label %bb69
bb62:
  br label %bb63
bb63:
  %t300 = load i64, ptr %l13, !tbaa !24
  %t301 = load i64, ptr %l17, !tbaa !24
  %t302 = load i64, ptr %l15, !tbaa !24
  %t305 = mul i64 %t301, %t302
  %t308 = add i64 %t300, %t305
  store i64 %t308, ptr %l18, !tbaa !24
  store ptr %l6, ptr %l142, !tbaa !29
  %t310 = load i64, ptr %l18, !tbaa !24
  %t312 = icmp sgt i64 %t310, 0
  br i1 %t312, label %bb64, label %bb65
bb64:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d209, i32 0, i32 1) }, ptr %l145, !tbaa !27
  br label %bb66
bb65:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d210, i32 0, i32 1) }, ptr %l145, !tbaa !27
  br label %bb66
bb66:
  %t314 = load i64, ptr %l18, !tbaa !24
  %t315 = load i64, ptr %l18, !tbaa !24
  %t316 = load { i64, ptr }, ptr %l145, !tbaa !27
  %t317 = extractvalue { i64, ptr } %t316, 1
  %t318 = extractvalue { i64, ptr } %t316, 0
  %t319 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d211, i32 0, i32 1) }, 1
  %t320 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d211, i32 0, i32 1) }, 0
  %t321 = add i64 %t318, %t320
  %t323 = call i64 @__olang_fmt_i64(ptr null, i64 %t314)
  %t324 = add i64 %t321, %t323
  %t325 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d212, i32 0, i32 1) }, 1
  %t326 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d212, i32 0, i32 1) }, 0
  %t327 = add i64 %t324, %t326
  %t329 = call i64 @__olang_fmt_i64(ptr null, i64 %t315)
  %t330 = add i64 %t327, %t329
  %t331 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t330)
  call void @olang_textcopy(ptr %t331, ptr %t317, i64 %t318)
  %t332 = getelementptr i8, ptr %t331, i64 %t318
  call void @olang_textcopy(ptr %t332, ptr %t319, i64 %t320)
  %t333 = getelementptr i8, ptr %t332, i64 %t320
  %t334 = call i64 @__olang_fmt_i64(ptr %t333, i64 %t314)
  %t335 = getelementptr i8, ptr %t333, i64 %t323
  call void @olang_textcopy(ptr %t335, ptr %t325, i64 %t326)
  %t336 = getelementptr i8, ptr %t335, i64 %t326
  %t337 = call i64 @__olang_fmt_i64(ptr %t336, i64 %t315)
  %t338 = insertvalue { i64, ptr } undef, i64 %t330, 0
  %t339 = insertvalue { i64, ptr } %t338, ptr %t331, 1
  %t341 = load ptr, ptr %l142, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s11, ptr %t341, { i64, ptr } %t339)
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s11)
  br label %bb68
bb68:
  %t343 = load i64, ptr %l17, !tbaa !24
  %t346 = add i64 %t343, 1
  store i64 %t346, ptr %l17, !tbaa !24
  br label %bb60
bb69:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d213, i32 0, i32 1) })
  br label %bb70
bb70:
  %t349 = getelementptr %"compiler/bindgen:cx", ptr %l5, i32 0, i32 1
  %t350 = load i64, ptr %t349, !tbaa !24
  store i64 %t350, ptr %l19, !tbaa !24
  %t352 = load i64, ptr %l19, !tbaa !24
  %t353 = load i64, ptr @G_2ecompiler_2fbindgen_2eKVar, !tbaa !24
  %t356 = icmp eq i64 %t352, %t353
  br i1 %t356, label %bb71, label %bb72
bb71:
  br label %bb73
bb72:
  br label %bb74
bb73:
  %t358 = getelementptr %"compiler/bindgen:cx", ptr %l5, i32 0, i32 2
  %t359 = load i64, ptr %t358, !tbaa !24
  %t360 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d214, i32 0, i32 1) }, 1
  %t361 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d214, i32 0, i32 1) }, 0
  %t363 = call i64 @__olang_fmt_i64(ptr null, i64 %t359)
  %t364 = add i64 %t361, %t363
  %t365 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t364)
  call void @olang_textcopy(ptr %t365, ptr %t360, i64 %t361)
  %t366 = getelementptr i8, ptr %t365, i64 %t361
  %t367 = call i64 @__olang_fmt_i64(ptr %t366, i64 %t359)
  %t368 = insertvalue { i64, ptr } undef, i64 %t364, 0
  %t369 = insertvalue { i64, ptr } %t368, ptr %t365, 1
  store { i64, ptr } %t369, ptr %l155, !tbaa !27
  br label %bb91
bb74:
  %t371 = load i64, ptr %l19, !tbaa !24
  %t372 = load i64, ptr @G_2ecompiler_2fbindgen_2eKType, !tbaa !24
  %t375 = icmp eq i64 %t371, %t372
  br i1 %t375, label %bb75, label %bb76
bb75:
  br label %bb77
bb76:
  br label %bb78
bb77:
  %t377 = getelementptr %"compiler/bindgen:cx", ptr %l5, i32 0, i32 3
  %t378 = load { i64, ptr }, ptr %t377, !tbaa !27
  %t380 = extractvalue { i64, ptr } %t378, 1
  %t381 = extractvalue { i64, ptr } %t378, 0
  %t382 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t381)
  call void @olang_textcopy(ptr %t382, ptr %t380, i64 %t381)
  %t383 = insertvalue { i64, ptr } undef, i64 %t381, 0
  %t384 = insertvalue { i64, ptr } %t383, ptr %t382, 1
  store { i64, ptr } %t384, ptr %l155, !tbaa !27
  br label %bb91
bb78:
  %t386 = load i64, ptr %l19, !tbaa !24
  %t387 = load i64, ptr @G_2ecompiler_2fbindgen_2eKBool, !tbaa !24
  %t390 = icmp eq i64 %t386, %t387
  br i1 %t390, label %bb79, label %bb80
bb79:
  br label %bb81
bb80:
  br label %bb82
bb81:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d215, i32 0, i32 1) }, ptr %l169, !tbaa !27
  %t392 = load { i64, ptr }, ptr %l169, !tbaa !27
  store { i64, ptr } %t392, ptr %l155, !tbaa !27
  br label %bb91
bb82:
  %t394 = load i64, ptr %l19, !tbaa !24
  %t395 = load i64, ptr @G_2ecompiler_2fbindgen_2eKFloat, !tbaa !24
  %t398 = icmp eq i64 %t394, %t395
  br i1 %t398, label %bb83, label %bb84
bb83:
  br label %bb85
bb84:
  br label %bb86
bb85:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d216, i32 0, i32 1) }, ptr %l174, !tbaa !27
  %t400 = load { i64, ptr }, ptr %l174, !tbaa !27
  store { i64, ptr } %t400, ptr %l155, !tbaa !27
  br label %bb91
bb86:
  br i1 true, label %bb87, label %bb88
bb87:
  br label %bb89
bb88:
  br label %bb90
bb89:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d217, i32 0, i32 1) }, ptr %l176, !tbaa !27
  %t402 = load { i64, ptr }, ptr %l176, !tbaa !27
  store { i64, ptr } %t402, ptr %l155, !tbaa !27
  br label %bb91
bb90:
  call void @__olang_check_failed(ptr @olang_loc_7ea854ff7e2640a8_63f49c54b749b4b4)
  unreachable
bb91:
  %t404 = load { i64, ptr }, ptr %l155, !tbaa !27
  %t405 = extractvalue { i64, ptr } %t404, 0
  store i64 %t405, ptr %l178, !tbaa !24
  %t406 = load i64, ptr %l178, !tbaa !24
  %t407 = mul i64 %t406, 1
  %t408 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t407)
  %t409 = insertvalue { i64, ptr } undef, i64 %t406, 0
  %t410 = insertvalue { i64, ptr } %t409, ptr %t408, 1
  store { i64, ptr } %t410, ptr %l179, !tbaa !27
  %t411 = getelementptr { i64, ptr }, ptr %l179, i32 0, i32 1
  %t412 = load ptr, ptr %t411, !tbaa !27
  %t413 = getelementptr { i64, ptr }, ptr %l155, i32 0, i32 1
  %t414 = load ptr, ptr %t413, !tbaa !27
  %t415 = load i64, ptr %l178, !tbaa !24
  %t416 = mul i64 %t415, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t412, ptr %t414, i64 %t416, i1 false)
  %t417 = load { i64, ptr }, ptr %l179, !tbaa !27
  %t419 = getelementptr %"compiler/bindgen:cx", ptr %l5, i32 0, i32 0
  %t420 = load { i64, ptr }, ptr %t419, !tbaa !27
  %t422 = extractvalue { i64, ptr } %t417, 1
  %t423 = extractvalue { i64, ptr } %t417, 0
  %t424 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d218, i32 0, i32 1) }, 1
  %t425 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d218, i32 0, i32 1) }, 0
  %t426 = add i64 %t423, %t425
  %t428 = extractvalue { i64, ptr } %t420, 1
  %t429 = extractvalue { i64, ptr } %t420, 0
  %t430 = add i64 %t426, %t429
  %t431 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d219, i32 0, i32 1) }, 1
  %t432 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d219, i32 0, i32 1) }, 0
  %t433 = add i64 %t430, %t432
  %t434 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t433)
  call void @olang_textcopy(ptr %t434, ptr %t422, i64 %t423)
  %t435 = getelementptr i8, ptr %t434, i64 %t423
  call void @olang_textcopy(ptr %t435, ptr %t424, i64 %t425)
  %t436 = getelementptr i8, ptr %t435, i64 %t425
  call void @olang_textcopy(ptr %t436, ptr %t428, i64 %t429)
  %t437 = getelementptr i8, ptr %t436, i64 %t429
  call void @olang_textcopy(ptr %t437, ptr %t431, i64 %t432)
  %t438 = insertvalue { i64, ptr } undef, i64 %t433, 0
  %t439 = insertvalue { i64, ptr } %t438, ptr %t434, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } %t439)
  br label %bb92
bb92:
  %t444 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l6)
  store { i64, ptr } %t444, ptr %l186
  br label %bb93
bb93:
  call void @__olang_scope_close(ptr %s0)
  %t445 = load { i64, ptr }, ptr %l186, !tbaa !27
  %t446 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t445, 1
  store { i32, { i64, ptr } } %t446, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2emember(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l21 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca i32
  %l30 = alloca i64
  %l31 = alloca i32
  %l32 = alloca i64
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca i32
  %l37 = alloca i64
  %l38 = alloca i32
  %l41 = alloca i1
  %l42 = alloca i64
  %l44 = alloca i64
  %l46 = alloca i1
  %l49 = alloca i1
  %l52 = alloca i64
  %l54 = alloca ptr
  %l57 = alloca i64
  %l58 = alloca %"compiler/bindgen:record"
  %l60 = alloca i64
  %l63 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l76 = alloca ptr
  %l79 = alloca i64
  %l80 = alloca ptr
  %l82 = alloca ptr
  %l86 = alloca i64
  %l87 = alloca i64
  %l89 = alloca { i64, ptr }
  %l90 = alloca { i64, ptr }
  %l91 = alloca i64
  %l92 = alloca i32
  %l93 = alloca i64
  %l94 = alloca i32
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %t102 = alloca %"compiler/bindgen:record", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t1, ptr %l12, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t2, 0
  store i64 %t5, ptr %l15, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 0
  store i64 %t7, ptr %l16, !tbaa !24
  %t8 = icmp sge i64 9, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load i64, ptr %l15, !tbaa !24
  %t11 = icmp sle i64 9, %t10
  br i1 %t11, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_a7b3c7a1d63bebad_eca1091badac82d1)
  unreachable
bb3:
  %t13 = load i64, ptr %l15, !tbaa !24
  %t14 = load i64, ptr %l16, !tbaa !24
  %t15 = icmp sle i64 %t13, %t14
  br i1 %t15, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_a7b3c7a1d63bebad_eca1091badac82d1)
  unreachable
bb5:
  %t17 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = load i64, ptr %l15, !tbaa !24
  %t20 = getelementptr i8, ptr %t18, i64 9
  %t21 = sub i64 %t19, 9
  %t22 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t20, 1
  %t25 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v2, ptr %s0, ptr %s0, { i64, ptr } %t23, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d220, i32 0, i32 1) })
  store { i64, ptr } %t25, ptr %l21
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_a7b3c7a1d63bebad_eca1091badac82d1)
  unreachable
bb7:
  %t26 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t26, ptr %l4, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t31 = icmp ne i64 %t29, 2
  br i1 %t31, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb9:
  br label %bb10
bb10:
  %t33 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t33, ptr %l26, !tbaa !27
  %t34 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr { i64, ptr }, ptr %t35, i64 0
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !37
  store { i64, ptr } %t37, ptr %l27, !tbaa !27
  %t38 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s0, i64 10)
  %t39 = extractvalue { i32, i64 } %t38, 1
  %t40 = extractvalue { i32, i64 } %t38, 0
  store i32 %t40, ptr %l29
  %t41 = icmp ne i32 %t40, 0
  br i1 %t41, label %bb12, label %ok.42, !prof !99
ok.42:
  store i64 %t39, ptr %l28
  br label %bb11
bb11:
  %t43 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t44 = load i64, ptr %l28, !tbaa !24
  %t45 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s0, { i64, ptr } %t43, i64 %t44)
  %t46 = extractvalue { i32, i64 } %t45, 1
  %t47 = extractvalue { i32, i64 } %t45, 0
  store i32 %t47, ptr %l31
  %t48 = icmp ne i32 %t47, 0
  br i1 %t48, label %bb15, label %ok.49, !prof !99
ok.49:
  store i64 %t46, ptr %l30
  br label %bb14
bb12:
  br label %bb13
bb13:
  store i64 -1, ptr %l25, !tbaa !24
  br label %bb16
bb14:
  %t50 = load i64, ptr %l30, !tbaa !24
  store i64 %t50, ptr %l25, !tbaa !24
  br label %bb16
bb15:
  br label %bb13
bb16:
  %t51 = load i64, ptr %l25, !tbaa !24
  store i64 %t51, ptr %l5, !tbaa !24
  %t52 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t52, ptr %l33, !tbaa !27
  %t53 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr { i64, ptr }, ptr %t54, i64 1
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !37
  store { i64, ptr } %t56, ptr %l34, !tbaa !27
  %t57 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s0, i64 10)
  %t58 = extractvalue { i32, i64 } %t57, 1
  %t59 = extractvalue { i32, i64 } %t57, 0
  store i32 %t59, ptr %l36
  %t60 = icmp ne i32 %t59, 0
  br i1 %t60, label %bb18, label %ok.61, !prof !99
ok.61:
  store i64 %t58, ptr %l35
  br label %bb17
bb17:
  %t62 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t63 = load i64, ptr %l35, !tbaa !24
  %t64 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s0, { i64, ptr } %t62, i64 %t63)
  %t65 = extractvalue { i32, i64 } %t64, 1
  %t66 = extractvalue { i32, i64 } %t64, 0
  store i32 %t66, ptr %l38
  %t67 = icmp ne i32 %t66, 0
  br i1 %t67, label %bb21, label %ok.68, !prof !99
ok.68:
  store i64 %t65, ptr %l37
  br label %bb20
bb18:
  br label %bb19
bb19:
  store i64 -1, ptr %l32, !tbaa !24
  br label %bb22
bb20:
  %t69 = load i64, ptr %l37, !tbaa !24
  store i64 %t69, ptr %l32, !tbaa !24
  br label %bb22
bb21:
  br label %bb19
bb22:
  %t70 = load i64, ptr %l32, !tbaa !24
  store i64 %t70, ptr %l6, !tbaa !24
  %t71 = load i64, ptr %l5, !tbaa !24
  %t73 = icmp slt i64 %t71, 0
  br i1 %t73, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l41, !tbaa !21
  br label %bb26
bb24:
  %t75 = load i64, ptr %l5, !tbaa !24
  store i64 %t75, ptr %l42, !tbaa !24
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t78 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t76)
  store i64 %t78, ptr %l44
  br label %bb25
bb25:
  %t79 = load i64, ptr %l42, !tbaa !24
  %t80 = load i64, ptr %l44, !tbaa !24
  %t81 = icmp sge i64 %t79, %t80
  store i1 %t81, ptr %l41, !tbaa !21
  br label %bb26
bb26:
  %t83 = load i1, ptr %l41, !tbaa !21
  br i1 %t83, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb29
bb28:
  %t84 = load i64, ptr %l6, !tbaa !24
  %t86 = icmp slt i64 %t84, 0
  store i1 %t86, ptr %l46, !tbaa !21
  br label %bb29
bb29:
  %t88 = load i1, ptr %l46, !tbaa !21
  br i1 %t88, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l49, !tbaa !21
  br label %bb35
bb31:
  %t89 = load i64, ptr %l6, !tbaa !24
  %t91 = mul i64 3, %t89
  %t93 = add i64 %t91, 2
  store i64 %t93, ptr %l52, !tbaa !24
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/bindgen:gen", ptr %t94, i32 0, i32 6
  store ptr %t96, ptr %l54, !tbaa !29
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t98 = load i64, ptr %l5, !tbaa !24
  %t101 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t97, i64 %t98)
  store i64 %t101, ptr %l57
  br label %bb32
bb32:
  %t103 = load ptr, ptr %l54, !tbaa !29
  %t104 = load i64, ptr %l57, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t102, ptr %v0, ptr %v0, ptr %t103, i64 %t104)
  call void @llvm.memmove.p0.p0.i64(ptr %l58, ptr %t102, i64 312, i1 false)
  br label %bb33
bb33:
  %t105 = getelementptr %"compiler/bindgen:record", ptr %l58, i32 0, i32 18
  %t107 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t105)
  store i64 %t107, ptr %l60
  br label %bb34
bb34:
  %t108 = load i64, ptr %l52, !tbaa !24
  %t109 = load i64, ptr %l60, !tbaa !24
  %t110 = icmp sge i64 %t108, %t109
  store i1 %t110, ptr %l49, !tbaa !21
  br label %bb35
bb35:
  %t112 = load i1, ptr %l49, !tbaa !21
  br i1 %t112, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb37:
  br label %bb38
bb38:
  store %olang.scope zeroinitializer, ptr %s3
  %t115 = call { i64, ptr } @compiler_2fbindgen_2einner(ptr %v3, ptr %s3, ptr %a3)
  store { i64, ptr } %t115, ptr %l63
  br label %bb39
bb39:
  %t116 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t116, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t118 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t118, 0
  store i64 %t120, ptr %l9, !tbaa !24
  br label %bb40
bb40:
  store %olang.scope zeroinitializer, ptr %s4
  %t122 = load i64, ptr %l8, !tbaa !24
  %t123 = load i64, ptr %l9, !tbaa !24
  %t126 = icmp slt i64 %t122, %t123
  %t128 = xor i1 %t126, true
  br i1 %t128, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s4)
  br label %bb55
bb42:
  br label %bb43
bb43:
  %t130 = load i64, ptr %l8, !tbaa !24
  store i64 %t130, ptr %l10, !tbaa !24
  %t132 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t132, ptr %l72, !tbaa !27
  %t133 = load i64, ptr %l8, !tbaa !24
  %t135 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !27
  %t137 = getelementptr ptr, ptr %t136, i64 %t133
  %t138 = load ptr, ptr %t137, !tbaa !39
  store ptr %t138, ptr %l11, !tbaa !29
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t142 = getelementptr %"compiler/bindgen:gen", ptr %t140, i32 0, i32 6
  store ptr %t142, ptr %l76, !tbaa !29
  %t143 = load ptr, ptr %l1, !tbaa !29
  %t144 = load i64, ptr %l5, !tbaa !24
  %t147 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t143, i64 %t144)
  store i64 %t147, ptr %l79
  br label %bb44
bb44:
  %t148 = load ptr, ptr %l76, !tbaa !29
  %t149 = load i64, ptr %l79, !tbaa !24
  %t150 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRefMu_Hc21bcd245b67ffb6ee3e145838fcf2cf(ptr %v0, ptr %v0, ptr %t148, i64 %t149)
  store ptr %t150, ptr %l80
  br label %bb45
bb45:
  %t151 = load ptr, ptr %l80, !tbaa !29
  %t153 = getelementptr %"compiler/bindgen:record", ptr %t151, i32 0, i32 18
  store ptr %t153, ptr %l82, !tbaa !29
  %t154 = load i64, ptr %l6, !tbaa !24
  %t156 = mul i64 3, %t154
  %t157 = load i64, ptr %l10, !tbaa !24
  %t160 = add i64 %t156, %t157
  store i64 %t160, ptr %l86, !tbaa !24
  %t161 = load ptr, ptr %l11, !tbaa !29
  %t163 = call { i64, ptr } @compiler_2fbindgen_2econstValue(ptr %s3, ptr %s4, ptr %t161)
  store { i64, ptr } %t163, ptr %l89
  br label %bb46
bb46:
  %t164 = load { i64, ptr }, ptr %l89, !tbaa !27
  store { i64, ptr } %t164, ptr %l90, !tbaa !27
  %t165 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s4, i64 10)
  %t166 = extractvalue { i32, i64 } %t165, 1
  %t167 = extractvalue { i32, i64 } %t165, 0
  store i32 %t167, ptr %l92
  %t168 = icmp ne i32 %t167, 0
  br i1 %t168, label %bb48, label %ok.169, !prof !99
ok.169:
  store i64 %t166, ptr %l91
  br label %bb47
bb47:
  %t170 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t171 = load i64, ptr %l91, !tbaa !24
  %t172 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s4, { i64, ptr } %t170, i64 %t171)
  %t173 = extractvalue { i32, i64 } %t172, 1
  %t174 = extractvalue { i32, i64 } %t172, 0
  store i32 %t174, ptr %l94
  %t175 = icmp ne i32 %t174, 0
  br i1 %t175, label %bb51, label %ok.176, !prof !99
ok.176:
  store i64 %t173, ptr %l93
  br label %bb50
bb48:
  br label %bb49
bb49:
  store i64 -1, ptr %l87, !tbaa !24
  br label %bb52
bb50:
  %t177 = load i64, ptr %l93, !tbaa !24
  store i64 %t177, ptr %l87, !tbaa !24
  br label %bb52
bb51:
  br label %bb49
bb52:
  %t178 = load ptr, ptr %l82, !tbaa !29
  %t179 = load i64, ptr %l86, !tbaa !24
  %t180 = load i64, ptr %l87, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t178, i64 %t179, i64 %t180)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s4)
  br label %bb54
bb54:
  %t181 = load i64, ptr %l8, !tbaa !24
  %t184 = add i64 %t181, 1
  store i64 %t184, ptr %l8, !tbaa !24
  br label %bb40
bb55:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enameRecord(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %lp4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l8 = alloca i64
  %l10 = alloca { i64, ptr }
  %l15 = alloca %"compiler/bindgen:record"
  %l17 = alloca i64
  %l20 = alloca { i64, ptr }
  %l25 = alloca i1
  %l27 = alloca i1
  %l31 = alloca %"compiler/bindgen:record"
  %l33 = alloca i1
  %l35 = alloca i64
  %l43 = alloca ptr
  %l44 = alloca ptr
  %l46 = alloca { i64, ptr }
  %l49 = alloca i1
  %l50 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i32
  %l56 = alloca { i64, ptr }
  %l57 = alloca i64
  %l59 = alloca { i64, ptr }
  %l61 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i64
  %l70 = alloca { i64, ptr }
  %l74 = alloca i64
  %l77 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l84 = alloca i1
  %l86 = alloca i64
  %l89 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l98 = alloca i1
  %l99 = alloca i1
  %l101 = alloca i1
  %l103 = alloca i64
  %l106 = alloca { i64, ptr }
  %l110 = alloca { i64, ptr }
  %l117 = alloca ptr
  %l118 = alloca ptr
  %l120 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %t5 = alloca %"compiler/bindgen:record", align 8
  %t54 = alloca %"compiler/bindgen:record", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/bindgen:gen", ptr %t1, i32 0, i32 6
  %t4 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t5, ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  call void @llvm.memmove.p0.p0.i64(ptr %l15, ptr %t5, i64 312, i1 false)
  br label %bb1
bb1:
  %t8 = getelementptr %"compiler/bindgen:record", ptr %l15, i32 0, i32 0
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  store { i64, ptr } %t9, ptr %l3, !tbaa !27
  %t11 = call ptr @__olang_scope_hold(ptr %v0)
  %t12 = ptrtoint ptr %t11 to i64
  store i64 %t12, ptr %l17, !tbaa !24
  %t13 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2ecompiler__2fbindgen__3agen__2enameRecord_2elocal_2e4
  br i1 %t13, label %bb2, label %bb3
bb2:
  %t15 = call ptr @__olang_region_make(ptr %v0)
  %t16 = ptrtoint ptr %t15 to i64
  store i64 %t16, ptr %l17, !tbaa !24
  br label %bb3
bb3:
  %t19 = extractvalue { i64, ptr } %a2, 1
  %t20 = extractvalue { i64, ptr } %a2, 0
  %t21 = load i64, ptr %l17
  %t22 = inttoptr i64 %t21 to ptr
  %t23 = call ptr @__olang_held_alloc(ptr %t22, i64 %t20)
  call void @olang_textcopy(ptr %t23, ptr %t19, i64 %t20)
  %t24 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  store { i64, ptr } %t25, ptr %l20, !tbaa !27
  %t26 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2ecompiler__2fbindgen__3agen__2enameRecord_2elocal_2e4
  br i1 %t26, label %bb4, label %bb5
bb4:
  %t28 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 0
  %t31 = icmp eq i64 %t29, 0
  br i1 %t31, label %bb6, label %bb7
bb5:
  %t33 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t33, ptr %lp4
  %t34 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t35 = load ptr, ptr %lp4
  store { i64, ptr } %t34, ptr %t35, !tbaa !27
  %t36 = load ptr, ptr %lp4
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  %t39 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t37, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d221, i32 0, i32 1) })
  store i1 %t39, ptr %l25
  br label %bb8
bb6:
  store { i64, ptr } zeroinitializer, ptr %l20, !tbaa !27
  br label %bb7
bb7:
  %t40 = load i64, ptr %l17
  %t41 = inttoptr i64 %t40 to ptr
  %t42 = load { i64, ptr }, ptr %l20
  %t43 = extractvalue { i64, ptr } %t42, 1
  %t44 = call ptr @__olang_region_or(ptr %t43, ptr null)
  %t45 = icmp ne ptr %t44, null
  %t46 = select i1 %t45, ptr %t44, ptr null
  call void @__olang_region_settle_in(ptr %t41, ptr %t46)
  br label %bb5
bb8:
  %t47 = load i1, ptr %l25, !tbaa !21
  %t48 = xor i1 %t47, true
  br i1 %t48, label %bb9, label %bb10
bb9:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/bindgen:gen", ptr %t50, i32 0, i32 6
  %t53 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t54, ptr %v0, ptr %v0, ptr %t52, i64 %t53)
  call void @llvm.memmove.p0.p0.i64(ptr %l31, ptr %t54, i64 312, i1 false)
  br label %bb11
bb10:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb13
bb11:
  %t57 = getelementptr %"compiler/bindgen:record", ptr %l31, i32 0, i32 11
  %t58 = load { i64, ptr }, ptr %t57, !tbaa !27
  %t60 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t58, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d222, i32 0, i32 1) })
  store i1 %t60, ptr %l33
  br label %bb12
bb12:
  %t61 = load i1, ptr %l33, !tbaa !21
  store i1 %t61, ptr %l27, !tbaa !21
  br label %bb13
bb13:
  %t62 = load i1, ptr %l27, !tbaa !21
  br i1 %t62, label %bb14, label %bb15
bb14:
  %t63 = load i64, ptr %l1, !tbaa !24
  store i64 %t63, ptr %l5, !tbaa !24
  %t65 = call ptr @__olang_scope_hold(ptr %v0)
  %t66 = ptrtoint ptr %t65 to i64
  store i64 %t66, ptr %l35, !tbaa !24
  %t67 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3arecord_2e11
  br i1 %t67, label %bb16, label %bb17
bb15:
  br label %bb21
bb16:
  %t69 = call ptr @__olang_region_make(ptr %v0)
  %t70 = ptrtoint ptr %t69 to i64
  store i64 %t70, ptr %l35, !tbaa !24
  br label %bb17
bb17:
  %t71 = load ptr, ptr %lp4
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !27
  %t74 = extractvalue { i64, ptr } %t72, 1
  %t75 = extractvalue { i64, ptr } %t72, 0
  %t76 = load i64, ptr %l35
  %t77 = inttoptr i64 %t76 to ptr
  %t78 = call ptr @__olang_held_alloc(ptr %t77, i64 %t75)
  call void @olang_textcopy(ptr %t78, ptr %t74, i64 %t75)
  %t79 = insertvalue { i64, ptr } undef, i64 %t75, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t78, 1
  store { i64, ptr } %t80, ptr %l6, !tbaa !27
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/bindgen:gen", ptr %t83, i32 0, i32 6
  %t86 = load i64, ptr %l5, !tbaa !24
  %t89 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRefMu_Hc21bcd245b67ffb6ee3e145838fcf2cf(ptr %v0, ptr %v0, ptr %t85, i64 %t86)
  store ptr %t89, ptr %l43
  br label %bb18
bb18:
  %t90 = load ptr, ptr %l43, !tbaa !29
  store ptr %t90, ptr %l44, !tbaa !29
  %t92 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t93 = load ptr, ptr %l44, !tbaa !29
  %t94 = getelementptr %"compiler/bindgen:record", ptr %t93, i32 0, i32 11
  %t95 = load { i64, ptr }, ptr %t94, !tbaa !27
  store { i64, ptr } %t95, ptr %l46, !tbaa !27
  %t97 = load ptr, ptr %l44, !tbaa !29
  %t98 = getelementptr %"compiler/bindgen:record", ptr %t97, i32 0, i32 11
  store { i64, ptr } %t92, ptr %t98, !tbaa !27
  %t99 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3arecord_2e11
  br i1 %t99, label %bb19, label %bb20
bb19:
  %t101 = load { i64, ptr }, ptr %l46
  %t102 = extractvalue { i64, ptr } %t101, 1
  call void @__olang_region_release(ptr %t102)
  store { i64, ptr } zeroinitializer, ptr %l46
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t103 = load ptr, ptr %lp4
  %t104 = load { i64, ptr }, ptr %t103, !tbaa !27
  %t106 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t104, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d223, i32 0, i32 1) })
  store i1 %t106, ptr %l49
  br label %bb22
bb22:
  %t107 = load i1, ptr %l49, !tbaa !21
  br i1 %t107, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s4
  %t108 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t110 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s4, { i64, ptr } %t108, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d224, i32 0, i32 1) })
  %t111 = extractvalue { i32, i64 } %t110, 1
  %t112 = extractvalue { i32, i64 } %t110, 0
  store i32 %t112, ptr %l53
  %t113 = icmp ne i32 %t112, 0
  br i1 %t113, label %bb26, label %ok.114, !prof !99
ok.114:
  store i64 %t111, ptr %l52
  br label %bb25
bb24:
  br label %bb52
bb25:
  %t115 = load i64, ptr %l52, !tbaa !24
  store i64 %t115, ptr %l50, !tbaa !24
  br label %bb28
bb26:
  br label %bb27
bb27:
  store i64 -1, ptr %l50, !tbaa !24
  br label %bb28
bb28:
  %t116 = load i64, ptr %l50, !tbaa !24
  store i64 %t116, ptr %l8, !tbaa !24
  %t117 = load i64, ptr %l8, !tbaa !24
  %t119 = icmp sge i64 %t117, 0
  br i1 %t119, label %bb29, label %bb30
bb29:
  %t121 = call ptr @__olang_scope_hold(ptr %v0)
  %t122 = ptrtoint ptr %t121 to i64
  store i64 %t122, ptr %l57, !tbaa !24
  %t123 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2ecompiler__2fbindgen__3agen__2enameRecord_2elocal_2e4
  br i1 %t123, label %bb31, label %bb32
bb30:
  %t125 = call ptr @__olang_scope_hold(ptr %v0)
  %t126 = ptrtoint ptr %t125 to i64
  store i64 %t126, ptr %l74, !tbaa !24
  %t127 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2ecompiler__2fbindgen__3agen__2enameRecord_2elocal_2e4
  br i1 %t127, label %bb43, label %bb44
bb31:
  %t129 = call ptr @__olang_region_make(ptr %v0)
  %t130 = ptrtoint ptr %t129 to i64
  store i64 %t130, ptr %l57, !tbaa !24
  br label %bb32
bb32:
  %t131 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t131, ptr %l59, !tbaa !27
  %t132 = load i64, ptr %l8, !tbaa !24
  %t134 = add i64 %t132, 1
  store i64 %t134, ptr %l61, !tbaa !24
  %t135 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t135, 0
  store i64 %t138, ptr %l64, !tbaa !24
  %t139 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t139, 0
  store i64 %t140, ptr %l65, !tbaa !24
  %t141 = load i64, ptr %l61, !tbaa !24
  %t142 = icmp sge i64 %t141, 0
  br i1 %t142, label %bb33, label %bb34
bb33:
  %t144 = load i64, ptr %l61, !tbaa !24
  %t145 = load i64, ptr %l64, !tbaa !24
  %t146 = icmp sle i64 %t144, %t145
  br i1 %t146, label %bb35, label %bb36
bb34:
  call void @__olang_check_failed(ptr @olang_loc_7e828aa3d49398bd_dbb08dcf54087001)
  unreachable
bb35:
  %t148 = load i64, ptr %l64, !tbaa !24
  %t149 = load i64, ptr %l65, !tbaa !24
  %t150 = icmp sle i64 %t148, %t149
  br i1 %t150, label %bb37, label %bb38
bb36:
  call void @__olang_check_failed(ptr @olang_loc_7e828aa3d49398bd_dbb08dcf54087001)
  unreachable
bb37:
  %t152 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = load i64, ptr %l61, !tbaa !24
  %t155 = load i64, ptr %l64, !tbaa !24
  %t156 = getelementptr i8, ptr %t153, i64 %t154
  %t157 = sub i64 %t155, %t154
  %t158 = insertvalue { i64, ptr } undef, i64 %t157, 0
  %t159 = insertvalue { i64, ptr } %t158, ptr %t156, 1
  %t161 = extractvalue { i64, ptr } %t159, 1
  %t162 = extractvalue { i64, ptr } %t159, 0
  %t163 = load i64, ptr %l57
  %t164 = inttoptr i64 %t163 to ptr
  %t165 = call ptr @__olang_held_alloc(ptr %t164, i64 %t162)
  call void @olang_textcopy(ptr %t165, ptr %t161, i64 %t162)
  %t166 = insertvalue { i64, ptr } undef, i64 %t162, 0
  %t167 = insertvalue { i64, ptr } %t166, ptr %t165, 1
  store { i64, ptr } %t167, ptr %l70, !tbaa !27
  %t168 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2ecompiler__2fbindgen__3agen__2enameRecord_2elocal_2e4
  br i1 %t168, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @olang_loc_7e828aa3d49398bd_dbb08dcf54087001)
  unreachable
bb39:
  %t170 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t171 = extractvalue { i64, ptr } %t170, 0
  %t173 = icmp eq i64 %t171, 0
  br i1 %t173, label %bb41, label %bb42
bb40:
  %t175 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t175, ptr %l56, !tbaa !27
  br label %bb49
bb41:
  store { i64, ptr } zeroinitializer, ptr %l70, !tbaa !27
  br label %bb42
bb42:
  %t176 = load i64, ptr %l57
  %t177 = inttoptr i64 %t176 to ptr
  %t178 = load { i64, ptr }, ptr %l70
  %t179 = extractvalue { i64, ptr } %t178, 1
  %t180 = call ptr @__olang_region_or(ptr %t179, ptr null)
  %t181 = icmp ne ptr %t180, null
  %t182 = select i1 %t181, ptr %t180, ptr null
  call void @__olang_region_settle_in(ptr %t177, ptr %t182)
  br label %bb40
bb43:
  %t183 = call ptr @__olang_region_make(ptr %v0)
  %t184 = ptrtoint ptr %t183 to i64
  store i64 %t184, ptr %l74, !tbaa !24
  br label %bb44
bb44:
  %t185 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t187 = extractvalue { i64, ptr } %t185, 1
  %t188 = extractvalue { i64, ptr } %t185, 0
  %t189 = load i64, ptr %l74
  %t190 = inttoptr i64 %t189 to ptr
  %t191 = call ptr @__olang_held_alloc(ptr %t190, i64 %t188)
  call void @olang_textcopy(ptr %t191, ptr %t187, i64 %t188)
  %t192 = insertvalue { i64, ptr } undef, i64 %t188, 0
  %t193 = insertvalue { i64, ptr } %t192, ptr %t191, 1
  store { i64, ptr } %t193, ptr %l77, !tbaa !27
  %t194 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2ecompiler__2fbindgen__3agen__2enameRecord_2elocal_2e4
  br i1 %t194, label %bb45, label %bb46
bb45:
  %t196 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t197 = extractvalue { i64, ptr } %t196, 0
  %t199 = icmp eq i64 %t197, 0
  br i1 %t199, label %bb47, label %bb48
bb46:
  %t201 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t201, ptr %l56, !tbaa !27
  br label %bb49
bb47:
  store { i64, ptr } zeroinitializer, ptr %l77, !tbaa !27
  br label %bb48
bb48:
  %t202 = load i64, ptr %l74
  %t203 = inttoptr i64 %t202 to ptr
  %t204 = load { i64, ptr }, ptr %l77
  %t205 = extractvalue { i64, ptr } %t204, 1
  %t206 = call ptr @__olang_region_or(ptr %t205, ptr null)
  %t207 = icmp ne ptr %t206, null
  %t208 = select i1 %t207, ptr %t206, ptr null
  call void @__olang_region_settle_in(ptr %t203, ptr %t208)
  br label %bb46
bb49:
  %t209 = load ptr, ptr %lp4
  %t210 = load { i64, ptr }, ptr %t209, !tbaa !27
  store { i64, ptr } %t210, ptr %l81, !tbaa !27
  %t211 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t212 = load ptr, ptr %lp4
  store { i64, ptr } %t211, ptr %t212, !tbaa !27
  %t213 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2ecompiler__2fbindgen__3agen__2enameRecord_2elocal_2e4
  br i1 %t213, label %bb50, label %bb51
bb50:
  %t215 = load { i64, ptr }, ptr %l81
  %t216 = extractvalue { i64, ptr } %t215, 1
  call void @__olang_region_release(ptr %t216)
  store { i64, ptr } zeroinitializer, ptr %l81
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s4)
  br label %bb52
bb52:
  %t217 = load ptr, ptr %lp4
  %t218 = load { i64, ptr }, ptr %t217, !tbaa !27
  %t220 = call i1 @compiler_2fbindgen_2eusable(ptr %v0, { i64, ptr } %t218)
  store i1 %t220, ptr %l84
  br label %bb53
bb53:
  %t221 = load i1, ptr %l84, !tbaa !21
  %t222 = xor i1 %t221, true
  br i1 %t222, label %bb54, label %bb55
bb54:
  %t224 = call ptr @__olang_scope_hold(ptr %v0)
  %t225 = ptrtoint ptr %t224 to i64
  store i64 %t225, ptr %l86, !tbaa !24
  %t226 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2ecompiler__2fbindgen__3agen__2enameRecord_2elocal_2e4
  br i1 %t226, label %bb56, label %bb57
bb55:
  br label %bb64
bb56:
  %t228 = call ptr @__olang_region_make(ptr %v0)
  %t229 = ptrtoint ptr %t228 to i64
  store i64 %t229, ptr %l86, !tbaa !24
  br label %bb57
bb57:
  %t230 = load ptr, ptr %lp4
  %t231 = load { i64, ptr }, ptr %t230, !tbaa !27
  %t232 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d225, i32 0, i32 1) }, 1
  %t233 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d225, i32 0, i32 1) }, 0
  %t235 = extractvalue { i64, ptr } %t231, 1
  %t236 = extractvalue { i64, ptr } %t231, 0
  %t237 = add i64 %t233, %t236
  %t238 = load i64, ptr %l86
  %t239 = inttoptr i64 %t238 to ptr
  %t240 = call ptr @__olang_held_alloc(ptr %t239, i64 %t237)
  call void @olang_textcopy(ptr %t240, ptr %t232, i64 %t233)
  %t241 = getelementptr i8, ptr %t240, i64 %t233
  call void @olang_textcopy(ptr %t241, ptr %t235, i64 %t236)
  %t242 = insertvalue { i64, ptr } undef, i64 %t237, 0
  %t243 = insertvalue { i64, ptr } %t242, ptr %t240, 1
  store { i64, ptr } %t243, ptr %l89, !tbaa !27
  %t244 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2ecompiler__2fbindgen__3agen__2enameRecord_2elocal_2e4
  br i1 %t244, label %bb58, label %bb59
bb58:
  %t246 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t247 = extractvalue { i64, ptr } %t246, 0
  %t249 = icmp eq i64 %t247, 0
  br i1 %t249, label %bb60, label %bb61
bb59:
  %t251 = load ptr, ptr %lp4
  %t252 = load { i64, ptr }, ptr %t251, !tbaa !27
  store { i64, ptr } %t252, ptr %l93, !tbaa !27
  %t253 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t254 = load ptr, ptr %lp4
  store { i64, ptr } %t253, ptr %t254, !tbaa !27
  %t255 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2ecompiler__2fbindgen__3agen__2enameRecord_2elocal_2e4
  br i1 %t255, label %bb62, label %bb63
bb60:
  store { i64, ptr } zeroinitializer, ptr %l89, !tbaa !27
  br label %bb61
bb61:
  %t257 = load i64, ptr %l86
  %t258 = inttoptr i64 %t257 to ptr
  %t259 = load { i64, ptr }, ptr %l89
  %t260 = extractvalue { i64, ptr } %t259, 1
  %t261 = call ptr @__olang_region_or(ptr %t260, ptr null)
  %t262 = icmp ne ptr %t261, null
  %t263 = select i1 %t262, ptr %t261, ptr null
  call void @__olang_region_settle_in(ptr %t258, ptr %t263)
  br label %bb59
bb62:
  %t264 = load { i64, ptr }, ptr %l93
  %t265 = extractvalue { i64, ptr } %t264, 1
  call void @__olang_region_release(ptr %t265)
  store { i64, ptr } zeroinitializer, ptr %l93
  br label %bb63
bb63:
  br label %bb64
bb64:
  br label %bb65
bb65:
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t268 = getelementptr %"compiler/bindgen:gen", ptr %t266, i32 0, i32 22
  %t269 = load ptr, ptr %lp4
  %t270 = load { i64, ptr }, ptr %t269, !tbaa !27
  %t273 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v0, ptr %v0, ptr %t268, { i64, ptr } %t270)
  store i1 %t273, ptr %l98
  br label %bb66
bb66:
  %t274 = load i1, ptr %l98, !tbaa !21
  br i1 %t274, label %bb67, label %bb68
bb67:
  store i1 true, ptr %l99, !tbaa !21
  br label %bb70
bb68:
  %t275 = load ptr, ptr %lp4
  %t276 = load { i64, ptr }, ptr %t275, !tbaa !27
  %t278 = call i1 @compiler_2fbindgen_2epreludeName(ptr %v0, { i64, ptr } %t276)
  store i1 %t278, ptr %l101
  br label %bb69
bb69:
  %t279 = load i1, ptr %l101, !tbaa !21
  store i1 %t279, ptr %l99, !tbaa !21
  br label %bb70
bb70:
  %t280 = load i1, ptr %l99, !tbaa !21
  %t281 = xor i1 %t280, true
  br i1 %t281, label %bb71, label %bb72
bb71:
  br label %bb83
bb72:
  br label %bb73
bb73:
  %t283 = call ptr @__olang_scope_hold(ptr %v0)
  %t284 = ptrtoint ptr %t283 to i64
  store i64 %t284, ptr %l103, !tbaa !24
  %t285 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2ecompiler__2fbindgen__3agen__2enameRecord_2elocal_2e4
  br i1 %t285, label %bb74, label %bb75
bb74:
  %t287 = call ptr @__olang_region_make(ptr %v0)
  %t288 = ptrtoint ptr %t287 to i64
  store i64 %t288, ptr %l103, !tbaa !24
  br label %bb75
bb75:
  %t289 = load ptr, ptr %lp4
  %t290 = load { i64, ptr }, ptr %t289, !tbaa !27
  %t292 = extractvalue { i64, ptr } %t290, 1
  %t293 = extractvalue { i64, ptr } %t290, 0
  %t294 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d226, i32 0, i32 1) }, 1
  %t295 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d226, i32 0, i32 1) }, 0
  %t296 = add i64 %t293, %t295
  %t297 = load i64, ptr %l103
  %t298 = inttoptr i64 %t297 to ptr
  %t299 = call ptr @__olang_held_alloc(ptr %t298, i64 %t296)
  call void @olang_textcopy(ptr %t299, ptr %t292, i64 %t293)
  %t300 = getelementptr i8, ptr %t299, i64 %t293
  call void @olang_textcopy(ptr %t300, ptr %t294, i64 %t295)
  %t301 = insertvalue { i64, ptr } undef, i64 %t296, 0
  %t302 = insertvalue { i64, ptr } %t301, ptr %t299, 1
  store { i64, ptr } %t302, ptr %l106, !tbaa !27
  %t303 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2ecompiler__2fbindgen__3agen__2enameRecord_2elocal_2e4
  br i1 %t303, label %bb76, label %bb77
bb76:
  %t305 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t306 = extractvalue { i64, ptr } %t305, 0
  %t308 = icmp eq i64 %t306, 0
  br i1 %t308, label %bb78, label %bb79
bb77:
  %t310 = load ptr, ptr %lp4
  %t311 = load { i64, ptr }, ptr %t310, !tbaa !27
  store { i64, ptr } %t311, ptr %l110, !tbaa !27
  %t312 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t313 = load ptr, ptr %lp4
  store { i64, ptr } %t312, ptr %t313, !tbaa !27
  %t314 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2ecompiler__2fbindgen__3agen__2enameRecord_2elocal_2e4
  br i1 %t314, label %bb80, label %bb81
bb78:
  store { i64, ptr } zeroinitializer, ptr %l106, !tbaa !27
  br label %bb79
bb79:
  %t316 = load i64, ptr %l103
  %t317 = inttoptr i64 %t316 to ptr
  %t318 = load { i64, ptr }, ptr %l106
  %t319 = extractvalue { i64, ptr } %t318, 1
  %t320 = call ptr @__olang_region_or(ptr %t319, ptr null)
  %t321 = icmp ne ptr %t320, null
  %t322 = select i1 %t321, ptr %t320, ptr null
  call void @__olang_region_settle_in(ptr %t317, ptr %t322)
  br label %bb77
bb80:
  %t323 = load { i64, ptr }, ptr %l110
  %t324 = extractvalue { i64, ptr } %t323, 1
  call void @__olang_region_release(ptr %t324)
  store { i64, ptr } zeroinitializer, ptr %l110
  br label %bb81
bb81:
  br label %bb82
bb82:
  br label %bb65
bb83:
  %t325 = load i64, ptr %l1, !tbaa !24
  %t327 = load ptr, ptr %lp4
  %t328 = load { i64, ptr }, ptr %t327, !tbaa !27
  store { i64, ptr } %t328, ptr %l10, !tbaa !27
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t332 = getelementptr %"compiler/bindgen:gen", ptr %t330, i32 0, i32 6
  %t336 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRefMu_Hc21bcd245b67ffb6ee3e145838fcf2cf(ptr %v0, ptr %v0, ptr %t332, i64 %t325)
  store ptr %t336, ptr %l117
  br label %bb84
bb84:
  %t337 = load ptr, ptr %l117, !tbaa !29
  store ptr %t337, ptr %l118, !tbaa !29
  %t339 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t340 = load ptr, ptr %l118, !tbaa !29
  %t341 = getelementptr %"compiler/bindgen:record", ptr %t340, i32 0, i32 7
  %t342 = load { i64, ptr }, ptr %t341, !tbaa !27
  store { i64, ptr } %t342, ptr %l120, !tbaa !27
  %t344 = load ptr, ptr %l118, !tbaa !29
  %t345 = getelementptr %"compiler/bindgen:record", ptr %t344, i32 0, i32 7
  store { i64, ptr } %t339, ptr %t345, !tbaa !27
  %t346 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3arecord_2e7
  br i1 %t346, label %bb85, label %bb86
bb85:
  %t348 = load { i64, ptr }, ptr %l120
  %t349 = extractvalue { i64, ptr } %t348, 1
  call void @__olang_region_release(ptr %t349)
  store { i64, ptr } zeroinitializer, ptr %l120
  br label %bb86
bb86:
  %t350 = load ptr, ptr %l0, !tbaa !29
  %t352 = getelementptr %"compiler/bindgen:gen", ptr %t350, i32 0, i32 22
  %t353 = load ptr, ptr %lp4
  %t354 = load { i64, ptr }, ptr %t353, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v0, ptr %t352, { i64, ptr } %t354, i64 0)
  br label %bb87
bb87:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enamedConst(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l5 = alloca i1
  %l7 = alloca i1
  %l12 = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = call i1 @compiler_2fbindgen_2eusable(ptr %v1, { i64, ptr } %t1)
  store i1 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i1, ptr %l5, !tbaa !21
  %t5 = xor i1 %t4, true
  br i1 %t5, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb5
bb3:
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/bindgen:gen", ptr %t9, i32 0, i32 11
  %t15 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v0, ptr %v1, ptr %t11, { i64, ptr } %t7)
  store i1 %t15, ptr %l12
  br label %bb4
bb4:
  %t16 = load i1, ptr %l12, !tbaa !21
  store i1 %t16, ptr %l7, !tbaa !21
  br label %bb5
bb5:
  %t17 = load i1, ptr %l7, !tbaa !21
  br i1 %t17, label %bb6, label %bb7
bb6:
  br label %ret
bb7:
  br label %bb8
bb8:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/bindgen:gen", ptr %t18, i32 0, i32 10
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v2, ptr %t20, { i64, ptr } %a2)
  br label %bb9
bb9:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/bindgen:gen", ptr %t24, i32 0, i32 11
  %t27 = load { i64, ptr }, ptr %l1, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v1, ptr %t26, { i64, ptr } %t27, i64 0)
  br label %bb10
bb10:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/bindgen:gen", ptr %t30, i32 0, i32 22
  %t33 = load { i64, ptr }, ptr %l1, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v1, ptr %t32, { i64, ptr } %t33, i64 0)
  br label %bb11
bb11:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enumbersOnly(ptr %v0, ptr %v1, ptr %a0, %"compiler/bindgen:ctype" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/bindgen:ctype"
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l9 = alloca i1
  %l15 = alloca i64
  %l18 = alloca i64
  %l37 = alloca ptr
  %l43 = alloca i64
  %l44 = alloca %"compiler/bindgen:ctype"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/bindgen:ctype" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/bindgen:ctype", ptr %l1, i32 0, i32 1
  %t2 = load { i64, ptr }, ptr %t1, !tbaa !27
  %t4 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t2, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d227, i32 0, i32 1) })
  store i1 %t4, ptr %l9
  br label %bb1
bb1:
  %t5 = load i1, ptr %l9, !tbaa !21
  br i1 %t5, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  store i64 0, ptr %l2, !tbaa !24
  %t7 = getelementptr %"compiler/bindgen:ctype", ptr %l1, i32 0, i32 4
  %t8 = load i64, ptr %t7, !tbaa !24
  store i64 %t8, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l2, !tbaa !24
  %t14 = icmp sgt i64 %t10, %t11
  br i1 %t14, label %bb5, label %bb6
bb5:
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp sgt i64 %t16, 0
  br i1 %t18, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb10
bb7:
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = load i64, ptr %l2, !tbaa !24
  %t24 = sub i64 %t20, %t21
  %t25 = load i64, ptr %l4, !tbaa !24
  %t28 = add i64 %t24, %t25
  %t30 = sub i64 %t28, 1
  %t31 = load i64, ptr %l4, !tbaa !24
  %t34 = sdiv i64 %t30, %t31
  store i64 %t34, ptr %l18, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb9
bb9:
  %t36 = load i64, ptr %l18, !tbaa !24
  store i64 %t36, ptr %l15, !tbaa !24
  br label %bb10
bb10:
  %t37 = load i64, ptr %l15, !tbaa !24
  store i64 %t37, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t38 = load i64, ptr %l6, !tbaa !24
  %t39 = load i64, ptr %l5, !tbaa !24
  %t42 = icmp slt i64 %t38, %t39
  %t44 = xor i1 %t42, true
  br i1 %t44, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb13:
  br label %bb14
bb14:
  %t46 = load i64, ptr %l2, !tbaa !24
  %t47 = load i64, ptr %l6, !tbaa !24
  %t48 = load i64, ptr %l4, !tbaa !24
  %t51 = mul i64 %t47, %t48
  %t54 = add i64 %t46, %t51
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/bindgen:gen", ptr %t56, i32 0, i32 17
  store ptr %t58, ptr %l37, !tbaa !29
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/bindgen:gen", ptr %t59, i32 0, i32 18
  %t62 = getelementptr %"compiler/bindgen:ctype", ptr %l1, i32 0, i32 5
  %t63 = load i64, ptr %t62, !tbaa !24
  %t67 = add i64 %t63, %t54
  %t70 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t61, i64 %t67)
  store i64 %t70, ptr %l43
  br label %bb15
bb15:
  %t71 = load ptr, ptr %l37, !tbaa !29
  %t72 = load i64, ptr %l43, !tbaa !24
  %t73 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %s3, ptr %t71, i64 %t72)
  store %"compiler/bindgen:ctype" %t73, ptr %l44
  br label %bb16
bb16:
  %t74 = getelementptr %"compiler/bindgen:ctype", ptr %l44, i32 0, i32 0
  %t75 = load i32, ptr %t74, !range !{i32 0, i32 7}
  %t77 = trunc i64 1 to i32
  %t78 = icmp eq i32 %t75, %t77
  %t80 = xor i1 %t78, true
  br i1 %t80, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb20:
  %t83 = load i64, ptr %l6, !tbaa !24
  %t86 = add i64 %t83, 1
  store i64 %t86, ptr %l6, !tbaa !24
  br label %bb11
bb21:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eotherConsts(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/bindgen:cMacro"
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca %"compiler/bindgen:cparse"
  %l11 = alloca %"compiler/bindgen:cx"
  %l12 = alloca i1
  %l15 = alloca i64
  %l17 = alloca i64
  %l22 = alloca %"compiler/bindgen:cMacro"
  %l24 = alloca i1
  %l25 = alloca i1
  %l27 = alloca i1
  %l30 = alloca i1
  %l32 = alloca i1
  %l34 = alloca i1
  %l39 = alloca i1
  %l40 = alloca i1
  %l45 = alloca i1
  %l49 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l52 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l56 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l57 = alloca i32
  %l59 = alloca i1
  %l65 = alloca i64
  %l69 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l72 = alloca i1
  %l75 = alloca ptr
  %l76 = alloca { i64, ptr }
  %l77 = alloca i64
  %l85 = alloca i64
  %l88 = alloca { i64, ptr }
  %l89 = alloca i64
  %l94 = alloca %"compiler/bindgen:cparse"
  %l95 = alloca %"compiler/bindgen:cx"
  %l98 = alloca %"compiler/bindgen:cx"
  %l99 = alloca i32
  %l101 = alloca i1
  %l106 = alloca i64
  %l108 = alloca i64
  %l110 = alloca i1
  %l115 = alloca i64
  %l117 = alloca i1
  %l119 = alloca { i64, ptr }
  %l120 = alloca { i64, ptr }
  %l122 = alloca i1
  %l123 = alloca i1
  %l125 = alloca i64
  %l127 = alloca i1
  %l129 = alloca { i64, ptr }
  %l130 = alloca i1
  %l131 = alloca i1
  %l133 = alloca { i64, ptr }
  %l134 = alloca { i64, ptr }
  %l136 = alloca i1
  %l137 = alloca ptr
  %l138 = alloca { i64, ptr }
  %l139 = alloca i64
  %l141 = alloca { i64, ptr }
  %l143 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/bindgen:gen", ptr %t1, i32 0, i32 13
  store ptr %t3, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load i64, ptr %l2, !tbaa !24
  store i64 %t5, ptr %l15, !tbaa !24
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acMacro_3e_2eLen_3ccompiler_2fbindgen_3acMacro_3e(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l17
  br label %bb2
bb2:
  %t9 = load i64, ptr %l15, !tbaa !24
  %t10 = load i64, ptr %l17, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb108
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = call %"compiler/bindgen:cMacro" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acMacro_3e_2eAt_3ccompiler_2fbindgen_3acMacro_3e(ptr %v0, ptr %v0, ptr %t15, i64 %t16)
  store %"compiler/bindgen:cMacro" %t19, ptr %l22
  br label %bb6
bb6:
  %t20 = load %"compiler/bindgen:cMacro", ptr %l22
  store %"compiler/bindgen:cMacro" %t20, ptr %l3
  %t21 = getelementptr %"compiler/bindgen:cMacro", ptr %l3, i32 0, i32 0
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  %t24 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t22, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d228, i32 0, i32 1) })
  store i1 %t24, ptr %l24
  br label %bb7
bb7:
  %t25 = load i1, ptr %l24, !tbaa !21
  br i1 %t25, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb10
bb9:
  %t26 = getelementptr %"compiler/bindgen:cMacro", ptr %l3, i32 0, i32 1
  %t27 = load i1, ptr %t26, !tbaa !21
  store i1 %t27, ptr %l25, !tbaa !21
  br label %bb10
bb10:
  %t29 = load i1, ptr %l25, !tbaa !21
  br i1 %t29, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb13
bb12:
  %t30 = getelementptr %"compiler/bindgen:cMacro", ptr %l3, i32 0, i32 4
  %t31 = load i1, ptr %t30, !tbaa !21
  %t33 = xor i1 %t31, true
  store i1 %t33, ptr %l27, !tbaa !21
  br label %bb13
bb13:
  %t35 = load i1, ptr %l27, !tbaa !21
  br i1 %t35, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb17
bb15:
  %t36 = getelementptr %"compiler/bindgen:cMacro", ptr %l3, i32 0, i32 0
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  %t39 = call i1 @compiler_2fbindgen_2eusable(ptr %v0, { i64, ptr } %t37)
  store i1 %t39, ptr %l32
  br label %bb16
bb16:
  %t40 = load i1, ptr %l32, !tbaa !21
  %t41 = xor i1 %t40, true
  store i1 %t41, ptr %l30, !tbaa !21
  br label %bb17
bb17:
  %t43 = load i1, ptr %l30, !tbaa !21
  br i1 %t43, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb21
bb19:
  %t44 = getelementptr %"compiler/bindgen:cMacro", ptr %l3, i32 0, i32 0
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !27
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/bindgen:gen", ptr %t47, i32 0, i32 11
  %t53 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v0, ptr %v0, ptr %t49, { i64, ptr } %t45)
  store i1 %t53, ptr %l39
  br label %bb20
bb20:
  %t54 = load i1, ptr %l39, !tbaa !21
  store i1 %t54, ptr %l34, !tbaa !21
  br label %bb21
bb21:
  %t55 = load i1, ptr %l34, !tbaa !21
  br i1 %t55, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb25
bb23:
  %t56 = getelementptr %"compiler/bindgen:cMacro", ptr %l3, i32 0, i32 0
  %t57 = load { i64, ptr }, ptr %t56, !tbaa !27
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/bindgen:gen", ptr %t59, i32 0, i32 22
  %t65 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v0, ptr %v0, ptr %t61, { i64, ptr } %t57)
  store i1 %t65, ptr %l45
  br label %bb24
bb24:
  %t66 = load i1, ptr %l45, !tbaa !21
  store i1 %t66, ptr %l40, !tbaa !21
  br label %bb25
bb25:
  %t67 = load i1, ptr %l40, !tbaa !21
  br i1 %t67, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s2)
  br label %bb107
bb27:
  br label %bb28
bb28:
  %t68 = getelementptr %"compiler/bindgen:cMacro", ptr %l3, i32 0, i32 3
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t69, 0
  %t73 = icmp eq i64 %t71, 0
  br i1 %t73, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s2)
  br label %bb107
bb30:
  br label %bb31
bb31:
  %t75 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t75, ptr %l49
  br label %bb32
bb32:
  %t76 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l49
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t76, ptr %l6
  %t77 = getelementptr %"compiler/bindgen:cMacro", ptr %l3, i32 0, i32 0
  %t78 = load { i64, ptr }, ptr %t77, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s2, ptr %v0, ptr %l6, { i64, ptr } %t78)
  br label %bb33
bb33:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/bindgen:cMacro", ptr %l3, i32 0, i32 3
  %t83 = load { i64, ptr }, ptr %t82, !tbaa !27
  %t87 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eexpand(ptr %v0, ptr %v0, ptr %s2, ptr %v0, ptr %t81, { i64, ptr } %t83, ptr %l6, i64 0)
  %t88 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t87, 1
  %t89 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t87, 0
  store i32 %t89, ptr %l57
  %t90 = icmp ne i32 %t89, 0
  br i1 %t90, label %bb35, label %ok.91, !prof !99
ok.91:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t88, ptr %l56
  br label %bb34
bb34:
  %t92 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l56
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t92, ptr %l52
  br label %bb38
bb35:
  %t93 = load i32, ptr %l57, !tbaa !23
  %t94 = ashr i32 %t93, 16
  %t96 = icmp eq i32 %t94, 1
  store i1 %t96, ptr %l59, !tbaa !21
  br label %bb36
bb36:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/bindgen:cMacro", ptr %l3, i32 0, i32 0
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !27
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/bindgen:gen", ptr %t100, i32 0, i32 26
  %t103 = load { i64, ptr }, ptr %t102, !tbaa !27
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskippedMacro(ptr %v0, ptr %v0, ptr %v0, ptr %t97, { i64, ptr } %t99, { i64, ptr } %t103)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s2)
  br label %bb107
bb38:
  %t107 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l52
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t107, ptr %l7
  %t109 = call i64 @compiler_2fbindgen_2ebodyKind(ptr %v0, ptr %l7)
  store i64 %t109, ptr %l65
  br label %bb39
bb39:
  %t110 = load i64, ptr %l65, !tbaa !24
  store i64 %t110, ptr %l8, !tbaa !24
  %t111 = load i64, ptr %l8, !tbaa !24
  %t113 = icmp eq i64 %t111, 2
  br i1 %t113, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s6
  %t116 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v0, ptr %v0, ptr %l7)
  store { i64, ptr } %t116, ptr %l69
  br label %bb42
bb41:
  br label %bb52
bb42:
  %t117 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t118 = call { i64, ptr } @compiler_2fbindgen_2etextLiteral(ptr %v0, ptr %s6, { i64, ptr } %t117)
  store { i64, ptr } %t118, ptr %l70
  br label %bb43
bb43:
  %t119 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t119, ptr %l9, !tbaa !27
  %t120 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t122 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s6, ptr %s6, { i64, ptr } %t120, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d229, i32 0, i32 1) })
  store i1 %t122, ptr %l72
  br label %bb44
bb44:
  %t123 = load i1, ptr %l72, !tbaa !21
  br i1 %t123, label %bb45, label %bb46
bb45:
  store %olang.scope zeroinitializer, ptr %s7
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/bindgen:cMacro", ptr %l3, i32 0, i32 0
  %t126 = load { i64, ptr }, ptr %t125, !tbaa !27
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskippedMacro(ptr %v0, ptr %v0, ptr %s7, ptr %t124, { i64, ptr } %t126, { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d230, i32 0, i32 1) })
  br label %bb47
bb46:
  %t129 = load ptr, ptr %l0, !tbaa !29
  store ptr %t129, ptr %l75, !tbaa !29
  %t130 = getelementptr %"compiler/bindgen:cMacro", ptr %l3, i32 0, i32 0
  %t131 = load { i64, ptr }, ptr %t130, !tbaa !27
  store { i64, ptr } %t131, ptr %l76, !tbaa !27
  %t132 = call ptr @__olang_scope_hold(ptr %v0)
  %t133 = ptrtoint ptr %t132 to i64
  store i64 %t133, ptr %l77, !tbaa !24
  %t134 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t134, label %bb48, label %bb49
bb47:
  call void @__olang_scope_close(ptr %s7)
  br label %bb51
bb48:
  %t136 = call ptr @__olang_region_make(ptr %v0)
  %t137 = ptrtoint ptr %t136 to i64
  store i64 %t137, ptr %l77, !tbaa !24
  br label %bb49
bb49:
  %t138 = getelementptr %"compiler/bindgen:cMacro", ptr %l3, i32 0, i32 0
  %t139 = load { i64, ptr }, ptr %t138, !tbaa !27
  %t140 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t139, 1
  %t143 = extractvalue { i64, ptr } %t139, 0
  %t144 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d231, i32 0, i32 1) }, 1
  %t145 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d231, i32 0, i32 1) }, 0
  %t146 = add i64 %t143, %t145
  %t148 = extractvalue { i64, ptr } %t140, 1
  %t149 = extractvalue { i64, ptr } %t140, 0
  %t150 = add i64 %t146, %t149
  %t151 = load i64, ptr %l77
  %t152 = inttoptr i64 %t151 to ptr
  %t153 = call ptr @__olang_held_alloc(ptr %t152, i64 %t150)
  call void @olang_textcopy(ptr %t153, ptr %t142, i64 %t143)
  %t154 = getelementptr i8, ptr %t153, i64 %t143
  call void @olang_textcopy(ptr %t154, ptr %t144, i64 %t145)
  %t155 = getelementptr i8, ptr %t154, i64 %t145
  call void @olang_textcopy(ptr %t155, ptr %t148, i64 %t149)
  %t156 = insertvalue { i64, ptr } undef, i64 %t150, 0
  %t157 = insertvalue { i64, ptr } %t156, ptr %t153, 1
  %t159 = load ptr, ptr %l75, !tbaa !29
  %t160 = load { i64, ptr }, ptr %l76, !tbaa !27
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enamedConst(ptr %v0, ptr %v0, ptr %v0, ptr %t159, { i64, ptr } %t160, { i64, ptr } %t157)
  br label %bb50
bb50:
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s2)
  br label %bb107
bb52:
  %t162 = load i64, ptr %l8, !tbaa !24
  %t164 = icmp eq i64 %t162, 1
  br i1 %t164, label %bb53, label %bb54
bb53:
  store %olang.scope zeroinitializer, ptr %s10
  %t166 = call ptr @__olang_scope_hold(ptr %v0)
  %t167 = ptrtoint ptr %t166 to i64
  store i64 %t167, ptr %l85, !tbaa !24
  %t168 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3acparse_2e0
  br i1 %t168, label %bb55, label %bb56
bb54:
  br label %bb105
bb55:
  %t170 = call ptr @__olang_region_make(ptr %v0)
  %t171 = ptrtoint ptr %t170 to i64
  store i64 %t171, ptr %l85, !tbaa !24
  br label %bb56
bb56:
  %t172 = load i64, ptr %l85
  %t173 = inttoptr i64 %t172 to ptr
  %t175 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v0, ptr %t173, ptr %l7)
  store { i64, ptr } %t175, ptr %l88
  br label %bb57
bb57:
  %t176 = call ptr @__olang_scope_hold(ptr %s10)
  %t177 = ptrtoint ptr %t176 to i64
  store i64 %t177, ptr %l89, !tbaa !24
  %t178 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3acparse_2e1
  br i1 %t178, label %bb58, label %bb59
bb58:
  %t180 = call ptr @__olang_region_make(ptr %s10)
  %t181 = ptrtoint ptr %t180 to i64
  store i64 %t181, ptr %l89, !tbaa !24
  br label %bb59
bb59:
  %t182 = icmp sge i64 0, 0
  br i1 %t182, label %bb60, label %bb61
bb60:
  %t184 = icmp sle i64 0, 576460752303423487
  br i1 %t184, label %bb62, label %bb63
bb61:
  call void @__olang_check_failed(ptr @olang_loc_588cbeac7c6acbe1_e04f9e86f435a7f5)
  unreachable
bb62:
  %t186 = mul i64 0, 16
  %t187 = load i64, ptr %l89
  %t188 = inttoptr i64 %t187 to ptr
  %t189 = insertvalue { i64, ptr } undef, i64 0, 0
  %t190 = insertvalue { i64, ptr } %t189, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t191 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t193 = call %"compiler/bindgen:cparse" @compiler_2fbindgen_3acparse_2ector(ptr %v0, ptr %s10, ptr %s10, { i64, ptr } %t191, { i64, ptr } %t190)
  store %"compiler/bindgen:cparse" %t193, ptr %l94
  br label %bb64
bb63:
  call void @__olang_check_failed(ptr @olang_loc_588cbeac7c6acbe1_e04f9e86f435a7f5)
  unreachable
bb64:
  %t194 = load %"compiler/bindgen:cparse", ptr %l94
  store %"compiler/bindgen:cparse" %t194, ptr %l10
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t198 = call { i32, %"compiler/bindgen:cx" } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecExpr(ptr %v0, ptr %s10, ptr %s10, ptr %t195, ptr %l10)
  %t199 = extractvalue { i32, %"compiler/bindgen:cx" } %t198, 1
  %t200 = extractvalue { i32, %"compiler/bindgen:cx" } %t198, 0
  store i32 %t200, ptr %l99
  %t201 = icmp ne i32 %t200, 0
  br i1 %t201, label %bb66, label %ok.202, !prof !99
ok.202:
  store %"compiler/bindgen:cx" %t199, ptr %l98
  br label %bb65
bb65:
  %t203 = load %"compiler/bindgen:cx", ptr %l98
  store %"compiler/bindgen:cx" %t203, ptr %l95
  br label %bb69
bb66:
  %t204 = load i32, ptr %l99, !tbaa !23
  %t205 = ashr i32 %t204, 16
  %t207 = icmp eq i32 %t205, 1
  store i1 %t207, ptr %l101, !tbaa !21
  br label %bb67
bb67:
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t209 = getelementptr %"compiler/bindgen:cMacro", ptr %l3, i32 0, i32 0
  %t210 = load { i64, ptr }, ptr %t209, !tbaa !27
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr %"compiler/bindgen:gen", ptr %t211, i32 0, i32 26
  %t214 = load { i64, ptr }, ptr %t213, !tbaa !27
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskippedMacro(ptr %v0, ptr %v0, ptr %v0, ptr %t208, { i64, ptr } %t210, { i64, ptr } %t214)
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s2)
  br label %bb107
bb69:
  %t218 = load %"compiler/bindgen:cx", ptr %l95
  store %"compiler/bindgen:cx" %t218, ptr %l11
  %t219 = getelementptr %"compiler/bindgen:cparse", ptr %l10, i32 0, i32 2
  %t220 = load i64, ptr %t219, !tbaa !24
  store i64 %t220, ptr %l106, !tbaa !24
  %t222 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %l7)
  store i64 %t222, ptr %l108
  br label %bb70
bb70:
  %t223 = load i64, ptr %l106, !tbaa !24
  %t224 = load i64, ptr %l108, !tbaa !24
  %t225 = icmp eq i64 %t223, %t224
  br i1 %t225, label %bb71, label %bb72
bb71:
  %t227 = getelementptr %"compiler/bindgen:cx", ptr %l11, i32 0, i32 1
  %t228 = load i64, ptr %t227, !tbaa !24
  %t229 = load i64, ptr @G_2ecompiler_2fbindgen_2eKFloat, !tbaa !24
  %t232 = icmp eq i64 %t228, %t229
  store i1 %t232, ptr %l110, !tbaa !21
  br label %bb73
bb72:
  store i1 false, ptr %l110, !tbaa !21
  br label %bb73
bb73:
  %t234 = load i1, ptr %l110, !tbaa !21
  br i1 %t234, label %bb74, label %bb75
bb74:
  store %olang.scope zeroinitializer, ptr %s12
  %t236 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %l7)
  store i64 %t236, ptr %l115
  br label %bb76
bb75:
  br label %bb104
bb76:
  %t237 = load i64, ptr %l115, !tbaa !24
  %t238 = icmp eq i64 %t237, 1
  br i1 %t238, label %bb77, label %bb78
bb77:
  %t241 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %l7, i64 0)
  store { i64, ptr } %t241, ptr %l119
  br label %bb79
bb78:
  store i1 false, ptr %l117, !tbaa !21
  br label %bb82
bb79:
  %t242 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t243 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eToLower(ptr %v0, ptr %s12, { i64, ptr } %t242)
  store { i64, ptr } %t243, ptr %l120
  br label %bb80
bb80:
  %t244 = load { i64, ptr }, ptr %l120, !tbaa !27
  %t246 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s12, ptr %s12, { i64, ptr } %t244, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d232, i32 0, i32 1) })
  store i1 %t246, ptr %l122
  br label %bb81
bb81:
  %t247 = load i1, ptr %l122, !tbaa !21
  store i1 %t247, ptr %l117, !tbaa !21
  br label %bb82
bb82:
  %t248 = load i1, ptr %l117, !tbaa !21
  br i1 %t248, label %bb83, label %bb84
bb83:
  store i1 true, ptr %l123, !tbaa !21
  br label %bb97
bb84:
  %t250 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %l7)
  store i64 %t250, ptr %l125
  br label %bb85
bb85:
  %t251 = load i64, ptr %l125, !tbaa !24
  %t252 = icmp eq i64 %t251, 3
  br i1 %t252, label %bb86, label %bb87
bb86:
  %t255 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %l7, i64 0)
  store { i64, ptr } %t255, ptr %l129
  br label %bb88
bb87:
  store i1 false, ptr %l127, !tbaa !21
  br label %bb90
bb88:
  %t256 = load { i64, ptr }, ptr %l129, !tbaa !27
  %t257 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s12, { i64, ptr } %t256, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d233, i32 0, i32 1) })
  store i1 %t257, ptr %l130
  br label %bb89
bb89:
  %t258 = load i1, ptr %l130, !tbaa !21
  store i1 %t258, ptr %l127, !tbaa !21
  br label %bb90
bb90:
  %t259 = load i1, ptr %l127, !tbaa !21
  br i1 %t259, label %bb91, label %bb92
bb91:
  %t261 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %l7, i64 1)
  store { i64, ptr } %t261, ptr %l133
  br label %bb93
bb92:
  store i1 false, ptr %l131, !tbaa !21
  br label %bb96
bb93:
  %t262 = load { i64, ptr }, ptr %l133, !tbaa !27
  %t263 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eToLower(ptr %v0, ptr %s12, { i64, ptr } %t262)
  store { i64, ptr } %t263, ptr %l134
  br label %bb94
bb94:
  %t264 = load { i64, ptr }, ptr %l134, !tbaa !27
  %t266 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s12, ptr %s12, { i64, ptr } %t264, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d234, i32 0, i32 1) })
  store i1 %t266, ptr %l136
  br label %bb95
bb95:
  %t267 = load i1, ptr %l136, !tbaa !21
  store i1 %t267, ptr %l131, !tbaa !21
  br label %bb96
bb96:
  %t268 = load i1, ptr %l131, !tbaa !21
  store i1 %t268, ptr %l123, !tbaa !21
  br label %bb97
bb97:
  %t269 = load i1, ptr %l123, !tbaa !21
  store i1 %t269, ptr %l12, !tbaa !21
  %t270 = load ptr, ptr %l0, !tbaa !29
  store ptr %t270, ptr %l137, !tbaa !29
  %t271 = getelementptr %"compiler/bindgen:cMacro", ptr %l3, i32 0, i32 0
  %t272 = load { i64, ptr }, ptr %t271, !tbaa !27
  store { i64, ptr } %t272, ptr %l138, !tbaa !27
  %t273 = call ptr @__olang_scope_hold(ptr %v0)
  %t274 = ptrtoint ptr %t273 to i64
  store i64 %t274, ptr %l139, !tbaa !24
  %t275 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t275, label %bb98, label %bb99
bb98:
  %t277 = call ptr @__olang_region_make(ptr %v0)
  %t278 = ptrtoint ptr %t277 to i64
  store i64 %t278, ptr %l139, !tbaa !24
  br label %bb99
bb99:
  %t279 = getelementptr %"compiler/bindgen:cMacro", ptr %l3, i32 0, i32 0
  %t280 = load { i64, ptr }, ptr %t279, !tbaa !27
  store { i64, ptr } %t280, ptr %l141, !tbaa !27
  %t281 = load i1, ptr %l12, !tbaa !21
  br i1 %t281, label %bb100, label %bb101
bb100:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d235, i32 0, i32 1) }, ptr %l143, !tbaa !27
  br label %bb102
bb101:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d236, i32 0, i32 1) }, ptr %l143, !tbaa !27
  br label %bb102
bb102:
  %t283 = getelementptr %"compiler/bindgen:cx", ptr %l11, i32 0, i32 0
  %t284 = load { i64, ptr }, ptr %t283, !tbaa !27
  %t285 = load { i64, ptr }, ptr %l141, !tbaa !27
  %t286 = extractvalue { i64, ptr } %t285, 1
  %t287 = extractvalue { i64, ptr } %t285, 0
  %t288 = load { i64, ptr }, ptr %l143, !tbaa !27
  %t289 = extractvalue { i64, ptr } %t288, 1
  %t290 = extractvalue { i64, ptr } %t288, 0
  %t291 = add i64 %t287, %t290
  %t293 = extractvalue { i64, ptr } %t284, 1
  %t294 = extractvalue { i64, ptr } %t284, 0
  %t295 = add i64 %t291, %t294
  %t296 = load i64, ptr %l139
  %t297 = inttoptr i64 %t296 to ptr
  %t298 = call ptr @__olang_held_alloc(ptr %t297, i64 %t295)
  call void @olang_textcopy(ptr %t298, ptr %t286, i64 %t287)
  %t299 = getelementptr i8, ptr %t298, i64 %t287
  call void @olang_textcopy(ptr %t299, ptr %t289, i64 %t290)
  %t300 = getelementptr i8, ptr %t299, i64 %t290
  call void @olang_textcopy(ptr %t300, ptr %t293, i64 %t294)
  %t301 = insertvalue { i64, ptr } undef, i64 %t295, 0
  %t302 = insertvalue { i64, ptr } %t301, ptr %t298, 1
  %t304 = load ptr, ptr %l137, !tbaa !29
  %t305 = load { i64, ptr }, ptr %l138, !tbaa !27
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2enamedConst(ptr %v0, ptr %v0, ptr %v0, ptr %t304, { i64, ptr } %t305, { i64, ptr } %t302)
  br label %bb103
bb103:
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s2)
  br label %bb107
bb104:
  call void @__olang_scope_close(ptr %s10)
  br label %bb105
bb105:
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t308 = getelementptr %"compiler/bindgen:cMacro", ptr %l3, i32 0, i32 0
  %t309 = load { i64, ptr }, ptr %t308, !tbaa !27
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskippedMacro(ptr %v0, ptr %v0, ptr %s2, ptr %t307, { i64, ptr } %t309, { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d237, i32 0, i32 1) })
  br label %bb106
bb106:
  call void @__olang_scope_close(ptr %s2)
  br label %bb107
bb107:
  %t312 = load i64, ptr %l2, !tbaa !24
  %t315 = add i64 %t312, 1
  store i64 %t315, ptr %l2, !tbaa !24
  br label %bb1
bb108:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eparamName(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca i64
  %lp5 = alloca ptr
  %l12 = alloca i1
  %l13 = alloca { i64, ptr }
  %l21 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l33 = alloca { i64, ptr }
  %l38 = alloca i1
  %l40 = alloca i1
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca { i64, ptr }
  %l47 = alloca i1
  %l48 = alloca i1
  %l49 = alloca { i64, ptr }
  %l50 = alloca i64
  %l51 = alloca { i64, ptr }
  %l54 = alloca i1
  %l55 = alloca i1
  %l57 = alloca i1
  %l58 = alloca i1
  %l60 = alloca i1
  %l61 = alloca i64
  %l64 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l73 = alloca i64
  %l74 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a1, ptr %l1
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 0, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t1 = load i64, ptr %l4, !tbaa !24
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t2, 0
  %t7 = icmp slt i64 %t1, %t4
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t9, ptr %l13, !tbaa !27
  %t10 = load i64, ptr %l4, !tbaa !24
  %t12 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr i8, ptr %t13, i64 %t10
  %t15 = load i8, ptr %t14, !tbaa !32
  %t17 = icmp eq i8 %t15, 95
  store i1 %t17, ptr %l12, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb4
bb4:
  %t19 = load i1, ptr %l12, !tbaa !21
  %t20 = xor i1 %t19, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb9
bb6:
  br label %bb7
bb7:
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = add i64 %t22, 1
  store i64 %t25, ptr %l4, !tbaa !24
  br label %bb8
bb8:
  br label %bb1
bb9:
  %t27 = call ptr @__olang_scope_hold(ptr %v3)
  %t28 = ptrtoint ptr %t27 to i64
  store i64 %t28, ptr %l21, !tbaa !24
  %t29 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2ecompiler__2fbindgen__3agen__2eparamName_2elocal_2e5
  br i1 %t29, label %bb10, label %bb11
bb10:
  %t31 = call ptr @__olang_region_make(ptr %v3)
  %t32 = ptrtoint ptr %t31 to i64
  store i64 %t32, ptr %l21, !tbaa !24
  br label %bb11
bb11:
  %t33 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t33, ptr %l23, !tbaa !27
  %t34 = load i64, ptr %l4, !tbaa !24
  store i64 %t34, ptr %l24, !tbaa !24
  %t35 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t35, 0
  store i64 %t38, ptr %l27, !tbaa !24
  %t39 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  store i64 %t40, ptr %l28, !tbaa !24
  %t41 = load i64, ptr %l24, !tbaa !24
  %t42 = icmp sge i64 %t41, 0
  br i1 %t42, label %bb12, label %bb13
bb12:
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = load i64, ptr %l27, !tbaa !24
  %t46 = icmp sle i64 %t44, %t45
  br i1 %t46, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_76a2c5c4ca94453d_57e44e0801590749)
  unreachable
bb14:
  %t48 = load i64, ptr %l27, !tbaa !24
  %t49 = load i64, ptr %l28, !tbaa !24
  %t50 = icmp sle i64 %t48, %t49
  br i1 %t50, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_76a2c5c4ca94453d_57e44e0801590749)
  unreachable
bb16:
  %t52 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = load i64, ptr %l24, !tbaa !24
  %t55 = load i64, ptr %l27, !tbaa !24
  %t56 = getelementptr i8, ptr %t53, i64 %t54
  %t57 = sub i64 %t55, %t54
  %t58 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t56, 1
  %t61 = extractvalue { i64, ptr } %t59, 1
  %t62 = extractvalue { i64, ptr } %t59, 0
  %t63 = load i64, ptr %l21
  %t64 = inttoptr i64 %t63 to ptr
  %t65 = call ptr @__olang_held_alloc(ptr %t64, i64 %t62)
  call void @olang_textcopy(ptr %t65, ptr %t61, i64 %t62)
  %t66 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %t65, 1
  store { i64, ptr } %t67, ptr %l33, !tbaa !27
  %t68 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2ecompiler__2fbindgen__3agen__2eparamName_2elocal_2e5
  br i1 %t68, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_76a2c5c4ca94453d_57e44e0801590749)
  unreachable
bb18:
  %t70 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t70, 0
  %t73 = icmp eq i64 %t71, 0
  br i1 %t73, label %bb20, label %bb21
bb19:
  %t75 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 16, i64 8)
  store ptr %t75, ptr %lp5
  %t76 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t77 = load ptr, ptr %lp5
  store { i64, ptr } %t76, ptr %t77, !tbaa !27
  %t78 = load ptr, ptr %lp5
  %t79 = load { i64, ptr }, ptr %t78, !tbaa !27
  %t81 = call i1 @compiler_2fbindgen_2eusable(ptr %v3, { i64, ptr } %t79)
  store i1 %t81, ptr %l38
  br label %bb22
bb20:
  store { i64, ptr } zeroinitializer, ptr %l33, !tbaa !27
  br label %bb21
bb21:
  %t82 = load i64, ptr %l21
  %t83 = inttoptr i64 %t82 to ptr
  %t84 = load { i64, ptr }, ptr %l33
  %t85 = extractvalue { i64, ptr } %t84, 1
  %t86 = call ptr @__olang_region_or(ptr %t85, ptr null)
  %t87 = icmp ne ptr %t86, null
  %t88 = select i1 %t87, ptr %t86, ptr null
  call void @__olang_region_settle_in(ptr %t83, ptr %t88)
  br label %bb19
bb22:
  %t89 = load i1, ptr %l38, !tbaa !21
  %t90 = xor i1 %t89, true
  br i1 %t90, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb26
bb24:
  %t92 = load ptr, ptr %lp5
  %t93 = load { i64, ptr }, ptr %t92, !tbaa !27
  store { i64, ptr } %t93, ptr %l41, !tbaa !27
  %t94 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t94, 0
  store i64 %t95, ptr %l42, !tbaa !24
  %t96 = load i64, ptr %l42, !tbaa !24
  %t97 = mul i64 %t96, 1
  %t98 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t97)
  %t99 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t98, 1
  store { i64, ptr } %t100, ptr %l43, !tbaa !27
  %t101 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = load i64, ptr %l42, !tbaa !24
  %t106 = mul i64 %t105, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t102, ptr %t104, i64 %t106, i1 false)
  %t107 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t110 = getelementptr %"compiler/bindgen:gen", ptr %a0, i32 0, i32 22
  %t114 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v0, ptr %s0, ptr %t110, { i64, ptr } %t107)
  store i1 %t114, ptr %l47
  br label %bb25
bb25:
  %t115 = load i1, ptr %l47, !tbaa !21
  store i1 %t115, ptr %l40, !tbaa !21
  br label %bb26
bb26:
  %t116 = load i1, ptr %l40, !tbaa !21
  br i1 %t116, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb30
bb28:
  %t117 = load ptr, ptr %lp5
  %t118 = load { i64, ptr }, ptr %t117, !tbaa !27
  store { i64, ptr } %t118, ptr %l49, !tbaa !27
  %t119 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t119, 0
  store i64 %t120, ptr %l50, !tbaa !24
  %t121 = load i64, ptr %l50, !tbaa !24
  %t122 = mul i64 %t121, 1
  %t123 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t122)
  %t124 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t125 = insertvalue { i64, ptr } %t124, ptr %t123, 1
  store { i64, ptr } %t125, ptr %l51, !tbaa !27
  %t126 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = load i64, ptr %l50, !tbaa !24
  %t131 = mul i64 %t130, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t127, ptr %t129, i64 %t131, i1 false)
  %t132 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t133 = load ptr, ptr %l3, !tbaa !29
  %t137 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v2, ptr %s0, ptr %t133, { i64, ptr } %t132)
  store i1 %t137, ptr %l54
  br label %bb29
bb29:
  %t138 = load i1, ptr %l54, !tbaa !21
  store i1 %t138, ptr %l48, !tbaa !21
  br label %bb30
bb30:
  %t139 = load i1, ptr %l48, !tbaa !21
  br i1 %t139, label %bb31, label %bb32
bb31:
  store i1 true, ptr %l55, !tbaa !21
  br label %bb34
bb32:
  %t140 = load ptr, ptr %lp5
  %t141 = load { i64, ptr }, ptr %t140, !tbaa !27
  %t143 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s0, { i64, ptr } %t141, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d238, i32 0, i32 1) })
  store i1 %t143, ptr %l57
  br label %bb33
bb33:
  %t144 = load i1, ptr %l57, !tbaa !21
  store i1 %t144, ptr %l55, !tbaa !21
  br label %bb34
bb34:
  %t145 = load i1, ptr %l55, !tbaa !21
  br i1 %t145, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l58, !tbaa !21
  br label %bb38
bb36:
  %t146 = load ptr, ptr %lp5
  %t147 = load { i64, ptr }, ptr %t146, !tbaa !27
  %t149 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s0, { i64, ptr } %t147, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d239, i32 0, i32 1) })
  store i1 %t149, ptr %l60
  br label %bb37
bb37:
  %t150 = load i1, ptr %l60, !tbaa !21
  store i1 %t150, ptr %l58, !tbaa !21
  br label %bb38
bb38:
  %t151 = load i1, ptr %l58, !tbaa !21
  br i1 %t151, label %bb39, label %bb40
bb39:
  %t152 = call ptr @__olang_scope_hold(ptr %v3)
  %t153 = ptrtoint ptr %t152 to i64
  store i64 %t153, ptr %l61, !tbaa !24
  %t154 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2ecompiler__2fbindgen__3agen__2eparamName_2elocal_2e5
  br i1 %t154, label %bb41, label %bb42
bb40:
  br label %bb49
bb41:
  %t156 = call ptr @__olang_region_make(ptr %v3)
  %t157 = ptrtoint ptr %t156 to i64
  store i64 %t157, ptr %l61, !tbaa !24
  br label %bb42
bb42:
  %t159 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d240, i32 0, i32 1) }, 1
  %t160 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d240, i32 0, i32 1) }, 0
  %t162 = call i64 @__olang_fmt_i64(ptr null, i64 %a2)
  %t163 = add i64 %t160, %t162
  %t164 = load i64, ptr %l61
  %t165 = inttoptr i64 %t164 to ptr
  %t166 = call ptr @__olang_held_alloc(ptr %t165, i64 %t163)
  call void @olang_textcopy(ptr %t166, ptr %t159, i64 %t160)
  %t167 = getelementptr i8, ptr %t166, i64 %t160
  %t168 = call i64 @__olang_fmt_i64(ptr %t167, i64 %a2)
  %t169 = insertvalue { i64, ptr } undef, i64 %t163, 0
  %t170 = insertvalue { i64, ptr } %t169, ptr %t166, 1
  store { i64, ptr } %t170, ptr %l64, !tbaa !27
  %t171 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2ecompiler__2fbindgen__3agen__2eparamName_2elocal_2e5
  br i1 %t171, label %bb43, label %bb44
bb43:
  %t173 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t174 = extractvalue { i64, ptr } %t173, 0
  %t176 = icmp eq i64 %t174, 0
  br i1 %t176, label %bb45, label %bb46
bb44:
  %t178 = load ptr, ptr %lp5
  %t179 = load { i64, ptr }, ptr %t178, !tbaa !27
  store { i64, ptr } %t179, ptr %l68, !tbaa !27
  %t180 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t181 = load ptr, ptr %lp5
  store { i64, ptr } %t180, ptr %t181, !tbaa !27
  %t182 = load i1, ptr @olang_2esole_2ecompiler__2fbindgen__2ecompiler__2fbindgen__3agen__2eparamName_2elocal_2e5
  br i1 %t182, label %bb47, label %bb48
bb45:
  store { i64, ptr } zeroinitializer, ptr %l64, !tbaa !27
  br label %bb46
bb46:
  %t184 = load i64, ptr %l61
  %t185 = inttoptr i64 %t184 to ptr
  %t186 = load { i64, ptr }, ptr %l64
  %t187 = extractvalue { i64, ptr } %t186, 1
  %t188 = call ptr @__olang_region_or(ptr %t187, ptr null)
  %t189 = icmp ne ptr %t188, null
  %t190 = select i1 %t189, ptr %t188, ptr null
  call void @__olang_region_settle_in(ptr %t185, ptr %t190)
  br label %bb44
bb47:
  %t191 = load { i64, ptr }, ptr %l68
  %t192 = extractvalue { i64, ptr } %t191, 1
  call void @__olang_region_release(ptr %t192)
  store { i64, ptr } zeroinitializer, ptr %l68
  br label %bb48
bb48:
  br label %bb49
bb49:
  %t193 = load ptr, ptr %l3, !tbaa !29
  %t194 = load ptr, ptr %lp5
  %t195 = load { i64, ptr }, ptr %t194, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v2, ptr %v3, ptr %t193, { i64, ptr } %t195, i64 0)
  br label %bb50
bb50:
  %t198 = load ptr, ptr %lp5
  %t199 = load { i64, ptr }, ptr %t198, !tbaa !27
  store { i64, ptr } %t199, ptr %l72, !tbaa !27
  %t200 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t201 = extractvalue { i64, ptr } %t200, 0
  store i64 %t201, ptr %l73, !tbaa !24
  %t202 = load i64, ptr %l73, !tbaa !24
  %t203 = mul i64 %t202, 1
  %t204 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t203)
  %t205 = insertvalue { i64, ptr } undef, i64 %t202, 0
  %t206 = insertvalue { i64, ptr } %t205, ptr %t204, 1
  store { i64, ptr } %t206, ptr %l74, !tbaa !27
  %t207 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !27
  %t209 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t210 = load ptr, ptr %t209, !tbaa !27
  %t211 = load i64, ptr %l73, !tbaa !24
  %t212 = mul i64 %t211, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t208, ptr %t210, i64 %t212, i1 false)
  %t213 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t213, ptr %l72, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t214 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t214, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eplain(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca i64
  %l6 = alloca i1
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l22 = alloca %"compiler/bindgen:record"
  %l34 = alloca ptr
  %l40 = alloca %"compiler/bindgen:record"
  %l44 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l46 = alloca i64
  %l50 = alloca i64
  %l54 = alloca ptr
  %l61 = alloca %"compiler/bindgen:record"
  %l63 = alloca i1
  %l67 = alloca %"compiler/bindgen:record"
  %l70 = alloca i1
  %l74 = alloca %"compiler/bindgen:record"
  %l77 = alloca i1
  %l81 = alloca %"compiler/bindgen:record"
  %l85 = alloca i1
  %l88 = alloca i1
  %l91 = alloca i1
  %l96 = alloca %"compiler/bindgen:record"
  %l98 = alloca %"compiler/bindgen:record"
  %l100 = alloca i64
  %l102 = alloca i64
  %l108 = alloca { i64, ptr }
  %l112 = alloca %"compiler/bindgen:record"
  %l114 = alloca %"compiler/bindgen:record"
  %l117 = alloca { i64, ptr }
  %l118 = alloca i1
  %l121 = alloca i64
  %l125 = alloca %"compiler/bindgen:ctype"
  %l131 = alloca %"compiler/bindgen:ctype"
  %l133 = alloca { i64, ptr }
  %l136 = alloca { i64, ptr }
  %l137 = alloca i32
  %l139 = alloca i1
  %l145 = alloca i64
  %l149 = alloca ptr
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca i1
  %t5 = alloca %"compiler/bindgen:record", align 8
  %t40 = alloca %"compiler/bindgen:record", align 8
  %t80 = alloca %"compiler/bindgen:record", align 8
  %t90 = alloca %"compiler/bindgen:record", align 8
  %t103 = alloca %"compiler/bindgen:record", align 8
  %t116 = alloca %"compiler/bindgen:record", align 8
  %t146 = alloca %"compiler/bindgen:record", align 8
  %t149 = alloca %"compiler/bindgen:record", align 8
  %t175 = alloca %"compiler/bindgen:record", align 8
  %t178 = alloca %"compiler/bindgen:record", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/bindgen:gen", ptr %t1, i32 0, i32 6
  %t4 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t5, ptr %v0, ptr %s0, ptr %t3, i64 %t4)
  call void @llvm.memmove.p0.p0.i64(ptr %l22, ptr %t5, i64 312, i1 false)
  br label %bb1
bb1:
  %t8 = getelementptr %"compiler/bindgen:record", ptr %l22, i32 0, i32 9
  %t9 = load i64, ptr %t8, !tbaa !24
  store i64 %t9, ptr %l2, !tbaa !24
  %t11 = load i64, ptr %l2, !tbaa !24
  %t13 = icmp eq i64 %t11, 0
  br i1 %t13, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t16 = load i64, ptr %l2, !tbaa !24
  %t18 = icmp sge i64 %t16, 1
  br i1 %t18, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t21 = load i64, ptr %l1, !tbaa !24
  store i64 2, ptr %l4, !tbaa !24
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/bindgen:gen", ptr %t23, i32 0, i32 6
  %t29 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRefMu_Hc21bcd245b67ffb6ee3e145838fcf2cf(ptr %v0, ptr %v0, ptr %t25, i64 %t21)
  store ptr %t29, ptr %l34
  br label %bb8
bb8:
  %t30 = load ptr, ptr %l34, !tbaa !29
  %t32 = load i64, ptr %l4, !tbaa !24
  %t35 = getelementptr %"compiler/bindgen:record", ptr %t30, i32 0, i32 9
  store i64 %t32, ptr %t35, !tbaa !24
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/bindgen:gen", ptr %t36, i32 0, i32 6
  %t39 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t40, ptr %v0, ptr %s0, ptr %t38, i64 %t39)
  call void @llvm.memmove.p0.p0.i64(ptr %l40, ptr %t40, i64 312, i1 false)
  br label %bb9
bb9:
  %t43 = getelementptr %"compiler/bindgen:record", ptr %l40, i32 0, i32 15
  %t44 = load i1, ptr %t43, !tbaa !21
  br i1 %t44, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load i64, ptr %l1, !tbaa !24
  %t50 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2epackedFields(ptr %v0, ptr %s3, ptr %t46, i64 %t47)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t50, ptr %l44
  br label %bb12
bb11:
  br label %bb18
bb12:
  %t52 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s3, ptr %l44)
  store i64 %t52, ptr %l46
  br label %bb13
bb13:
  %t53 = load i64, ptr %l46, !tbaa !24
  %t54 = icmp sgt i64 %t53, 0
  store i1 %t54, ptr %l6, !tbaa !21
  %t56 = load i64, ptr %l1, !tbaa !24
  store i64 %t56, ptr %l7, !tbaa !24
  %t58 = load i1, ptr %l6, !tbaa !21
  br i1 %t58, label %bb14, label %bb15
bb14:
  store i64 1, ptr %l50, !tbaa !24
  br label %bb16
bb15:
  store i64 0, ptr %l50, !tbaa !24
  br label %bb16
bb16:
  %t60 = load i64, ptr %l50, !tbaa !24
  store i64 %t60, ptr %l8, !tbaa !24
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/bindgen:gen", ptr %t61, i32 0, i32 6
  %t64 = load i64, ptr %l7, !tbaa !24
  %t67 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRefMu_Hc21bcd245b67ffb6ee3e145838fcf2cf(ptr %v0, ptr %v0, ptr %t63, i64 %t64)
  store ptr %t67, ptr %l54
  br label %bb17
bb17:
  %t68 = load ptr, ptr %l54, !tbaa !29
  %t70 = load i64, ptr %l8, !tbaa !24
  %t73 = getelementptr %"compiler/bindgen:record", ptr %t68, i32 0, i32 9
  store i64 %t70, ptr %t73, !tbaa !24
  %t74 = load i1, ptr %l6, !tbaa !21
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store i1 %t74, ptr %rv
  br label %ret
bb18:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/bindgen:gen", ptr %t76, i32 0, i32 6
  %t79 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t80, ptr %v0, ptr %s0, ptr %t78, i64 %t79)
  call void @llvm.memmove.p0.p0.i64(ptr %l61, ptr %t80, i64 312, i1 false)
  br label %bb19
bb19:
  %t83 = getelementptr %"compiler/bindgen:record", ptr %l61, i32 0, i32 2
  %t84 = load i1, ptr %t83, !tbaa !21
  br i1 %t84, label %bb20, label %bb21
bb20:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/bindgen:gen", ptr %t86, i32 0, i32 6
  %t89 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t90, ptr %v0, ptr %s0, ptr %t88, i64 %t89)
  call void @llvm.memmove.p0.p0.i64(ptr %l67, ptr %t90, i64 312, i1 false)
  br label %bb22
bb21:
  store i1 false, ptr %l63, !tbaa !21
  br label %bb23
bb22:
  %t93 = getelementptr %"compiler/bindgen:record", ptr %l67, i32 0, i32 3
  %t94 = load i1, ptr %t93, !tbaa !21
  %t96 = xor i1 %t94, true
  store i1 %t96, ptr %l63, !tbaa !21
  br label %bb23
bb23:
  %t98 = load i1, ptr %l63, !tbaa !21
  br i1 %t98, label %bb24, label %bb25
bb24:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/bindgen:gen", ptr %t99, i32 0, i32 6
  %t102 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t103, ptr %v0, ptr %s0, ptr %t101, i64 %t102)
  call void @llvm.memmove.p0.p0.i64(ptr %l74, ptr %t103, i64 312, i1 false)
  br label %bb26
bb25:
  store i1 false, ptr %l70, !tbaa !21
  br label %bb27
bb26:
  %t106 = getelementptr %"compiler/bindgen:record", ptr %l74, i32 0, i32 1
  %t107 = load i1, ptr %t106, !tbaa !21
  %t109 = xor i1 %t107, true
  store i1 %t109, ptr %l70, !tbaa !21
  br label %bb27
bb27:
  %t111 = load i1, ptr %l70, !tbaa !21
  br i1 %t111, label %bb28, label %bb29
bb28:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/bindgen:gen", ptr %t112, i32 0, i32 6
  %t115 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t116, ptr %v0, ptr %s0, ptr %t114, i64 %t115)
  call void @llvm.memmove.p0.p0.i64(ptr %l81, ptr %t116, i64 312, i1 false)
  br label %bb30
bb29:
  store i1 false, ptr %l77, !tbaa !21
  br label %bb31
bb30:
  %t119 = getelementptr %"compiler/bindgen:record", ptr %l81, i32 0, i32 10
  %t120 = load i1, ptr %t119, !tbaa !21
  %t122 = xor i1 %t120, true
  store i1 %t122, ptr %l77, !tbaa !21
  br label %bb31
bb31:
  %t124 = load i1, ptr %l77, !tbaa !21
  store i1 %t124, ptr %l10, !tbaa !21
  %t125 = load i1, ptr %l10, !tbaa !21
  br i1 %t125, label %bb32, label %bb33
bb32:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load i64, ptr %l1, !tbaa !24
  %t131 = call i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ehasAnon(ptr %v0, ptr %t127, i64 %t128)
  store i1 %t131, ptr %l88
  br label %bb34
bb33:
  store i1 false, ptr %l85, !tbaa !21
  br label %bb35
bb34:
  %t132 = load i1, ptr %l88, !tbaa !21
  store i1 %t132, ptr %l85, !tbaa !21
  br label %bb35
bb35:
  %t133 = load i1, ptr %l85, !tbaa !21
  br i1 %t133, label %bb36, label %bb37
bb36:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load i64, ptr %l1, !tbaa !24
  %t138 = call i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2elaidOut(ptr %v0, ptr %t134, i64 %t135)
  store i1 %t138, ptr %l91
  br label %bb38
bb37:
  %t139 = load i1, ptr %l10, !tbaa !21
  br i1 %t139, label %bb39, label %bb40
bb38:
  %t141 = load i1, ptr %l91, !tbaa !21
  store i1 %t141, ptr %l10, !tbaa !21
  br label %bb69
bb39:
  store %olang.scope zeroinitializer, ptr %s7
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = getelementptr %"compiler/bindgen:gen", ptr %t142, i32 0, i32 6
  %t145 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t146, ptr %v0, ptr %v0, ptr %t144, i64 %t145)
  call void @llvm.memmove.p0.p0.i64(ptr %l96, ptr %t146, i64 312, i1 false)
  br label %bb41
bb40:
  br label %bb68
bb41:
  call void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fbindgen_3arecord(ptr %t149, ptr %v0, ptr %l96)
  call void @llvm.memmove.p0.p0.i64(ptr %l98, ptr %t149, i64 312, i1 false)
  br label %bb42
bb42:
  %t151 = getelementptr %"compiler/bindgen:record", ptr %l98, i32 0, i32 5
  store ptr %t151, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb43
bb43:
  store %olang.scope zeroinitializer, ptr %s8
  %t153 = load i64, ptr %l12, !tbaa !24
  store i64 %t153, ptr %l100, !tbaa !24
  %t154 = load ptr, ptr %l11, !tbaa !29
  %t156 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s7, ptr %t154)
  store i64 %t156, ptr %l102
  br label %bb44
bb44:
  %t157 = load i64, ptr %l100, !tbaa !24
  %t158 = load i64, ptr %l102, !tbaa !24
  %t159 = icmp slt i64 %t157, %t158
  %t161 = xor i1 %t159, true
  br i1 %t161, label %bb45, label %bb46
bb45:
  call void @__olang_scope_close(ptr %s8)
  br label %bb67
bb46:
  br label %bb47
bb47:
  %t163 = load i64, ptr %l12, !tbaa !24
  store i64 %t163, ptr %l13, !tbaa !24
  %t165 = load ptr, ptr %l11, !tbaa !29
  %t166 = load i64, ptr %l12, !tbaa !24
  %t169 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s7, ptr %s7, ptr %t165, i64 %t166)
  store { i64, ptr } %t169, ptr %l108
  br label %bb48
bb48:
  %t170 = load { i64, ptr }, ptr %l108, !tbaa !27
  store { i64, ptr } %t170, ptr %l14, !tbaa !27
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t173 = getelementptr %"compiler/bindgen:gen", ptr %t171, i32 0, i32 6
  %t174 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t175, ptr %v0, ptr %v0, ptr %t173, i64 %t174)
  call void @llvm.memmove.p0.p0.i64(ptr %l112, ptr %t175, i64 312, i1 false)
  br label %bb49
bb49:
  call void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fbindgen_3arecord(ptr %t178, ptr %s8, ptr %l112)
  call void @llvm.memmove.p0.p0.i64(ptr %l114, ptr %t178, i64 312, i1 false)
  br label %bb50
bb50:
  %t180 = getelementptr %"compiler/bindgen:record", ptr %l114, i32 0, i32 4
  %t181 = load i64, ptr %l13, !tbaa !24
  %t184 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %s8, ptr %t180, i64 %t181)
  store { i64, ptr } %t184, ptr %l117
  br label %bb51
bb51:
  %t185 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t186 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s8, ptr %s8, { i64, ptr } %t185, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d241, i32 0, i32 1) })
  store i1 %t186, ptr %l118
  br label %bb52
bb52:
  %t187 = load i1, ptr %l118, !tbaa !21
  br i1 %t187, label %bb53, label %bb54
bb53:
  store i1 false, ptr %l10, !tbaa !21
  call void @__olang_scope_close(ptr %s8)
  br label %bb67
bb54:
  br label %bb55
bb55:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t189 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t192 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eparseType(ptr %v0, ptr %s7, ptr %t188, { i64, ptr } %t189, i64 0)
  store i64 %t192, ptr %l121
  br label %bb56
bb56:
  %t193 = load i64, ptr %l121, !tbaa !24
  store i64 %t193, ptr %l15, !tbaa !24
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr %"compiler/bindgen:gen", ptr %t194, i32 0, i32 17
  %t197 = load i64, ptr %l15, !tbaa !24
  %t200 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %s8, ptr %t196, i64 %t197)
  store %"compiler/bindgen:ctype" %t200, ptr %l125
  br label %bb57
bb57:
  %t201 = getelementptr %"compiler/bindgen:ctype", ptr %l125, i32 0, i32 0
  %t202 = load i32, ptr %t201, !range !{i32 0, i32 7}
  %t204 = trunc i64 4 to i32
  %t205 = icmp eq i32 %t202, %t204
  br i1 %t205, label %bb58, label %bb59
bb58:
  store %olang.scope zeroinitializer, ptr %s10
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t209 = getelementptr %"compiler/bindgen:gen", ptr %t207, i32 0, i32 17
  %t210 = load i64, ptr %l15, !tbaa !24
  %t213 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %s10, ptr %t209, i64 %t210)
  store %"compiler/bindgen:ctype" %t213, ptr %l131
  br label %bb60
bb59:
  br label %bb61
bb60:
  %t214 = getelementptr %"compiler/bindgen:ctype", ptr %l131, i32 0, i32 2
  %t215 = load i64, ptr %t214, !tbaa !24
  store i64 %t215, ptr %l15, !tbaa !24
  call void @__olang_scope_close(ptr %s10)
  br label %bb61
bb61:
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t218 = load i64, ptr %l15, !tbaa !24
  %t221 = call { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2efieldType(ptr %v0, ptr %s8, ptr %t217, i64 %t218)
  %t222 = extractvalue { i32, { i64, ptr } } %t221, 1
  %t223 = extractvalue { i32, { i64, ptr } } %t221, 0
  store i32 %t223, ptr %l137
  %t224 = icmp ne i32 %t223, 0
  br i1 %t224, label %bb63, label %ok.225, !prof !99
ok.225:
  store { i64, ptr } %t222, ptr %l136
  br label %bb62
bb62:
  %t226 = load { i64, ptr }, ptr %l136, !tbaa !27
  store { i64, ptr } %t226, ptr %l133, !tbaa !27
  br label %bb65
bb63:
  %t227 = load i32, ptr %l137, !tbaa !23
  %t228 = ashr i32 %t227, 16
  %t230 = icmp eq i32 %t228, 1
  store i1 %t230, ptr %l139, !tbaa !21
  br label %bb64
bb64:
  store i1 false, ptr %l10, !tbaa !21
  call void @__olang_scope_close(ptr %s8)
  br label %bb67
bb65:
  call void @__olang_scope_close(ptr %s8)
  br label %bb66
bb66:
  %t231 = load i64, ptr %l12, !tbaa !24
  %t234 = add i64 %t231, 1
  store i64 %t234, ptr %l12, !tbaa !24
  br label %bb43
bb67:
  call void @__olang_scope_close(ptr %s7)
  br label %bb68
bb68:
  br label %bb69
bb69:
  %t236 = load i64, ptr %l1, !tbaa !24
  store i64 %t236, ptr %l16, !tbaa !24
  %t238 = load i1, ptr %l10, !tbaa !21
  br i1 %t238, label %bb70, label %bb71
bb70:
  store i64 1, ptr %l145, !tbaa !24
  br label %bb72
bb71:
  store i64 0, ptr %l145, !tbaa !24
  br label %bb72
bb72:
  %t240 = load i64, ptr %l145, !tbaa !24
  store i64 %t240, ptr %l17, !tbaa !24
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t243 = getelementptr %"compiler/bindgen:gen", ptr %t241, i32 0, i32 6
  %t244 = load i64, ptr %l16, !tbaa !24
  %t247 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRefMu_Hc21bcd245b67ffb6ee3e145838fcf2cf(ptr %v0, ptr %v0, ptr %t243, i64 %t244)
  store ptr %t247, ptr %l149
  br label %bb73
bb73:
  %t248 = load ptr, ptr %l149, !tbaa !29
  %t250 = load i64, ptr %l17, !tbaa !24
  %t253 = getelementptr %"compiler/bindgen:record", ptr %t248, i32 0, i32 9
  store i64 %t250, ptr %t253, !tbaa !24
  %t254 = load i1, ptr %l10, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  store i1 %t254, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2epointerParam(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca %"compiler/bindgen:ctype"
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca %"compiler/bindgen:ctype"
  %l8 = alloca i64
  %l12 = alloca %"compiler/bindgen:ctype"
  %l17 = alloca i1
  %l18 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l32 = alloca i64
  %l34 = alloca i1
  %l37 = alloca i1
  %l39 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l49 = alloca %"compiler/bindgen:ctype"
  %l52 = alloca i1
  %l53 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l55 = alloca i64
  %l56 = alloca { i64, ptr }
  %l61 = alloca i64
  %l64 = alloca i1
  %l68 = alloca { i64, ptr }
  %l72 = alloca i1
  %l75 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l77 = alloca i64
  %l78 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l84 = alloca i1
  %l86 = alloca i32
  %l88 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l92 = alloca i32
  %l98 = alloca i32
  %l101 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/bindgen:gen", ptr %t1, i32 0, i32 17
  %t7 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store %"compiler/bindgen:ctype" %t7, ptr %l12
  br label %bb1
bb1:
  %t8 = load %"compiler/bindgen:ctype", ptr %l12
  store %"compiler/bindgen:ctype" %t8, ptr %l3
  %t9 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 0
  %t10 = load i32, ptr %t9, !range !{i32 0, i32 7}
  store i32 %t10, ptr %l4
  %t12 = load i32, ptr %l4, !range !{i32 0, i32 7}
  %t14 = trunc i64 1 to i32
  %t15 = icmp eq i32 %t12, %t14
  br i1 %t15, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb12
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t17 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 1
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  %t20 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t18, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d242, i32 0, i32 1) })
  store i1 %t20, ptr %l17
  br label %bb5
bb5:
  %t21 = load i1, ptr %l17, !tbaa !21
  br i1 %t21, label %bb6, label %bb7
bb6:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d243, i32 0, i32 1) }, ptr %l18, !tbaa !27
  br label %bb8
bb7:
  %t22 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 1
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 1
  %t26 = extractvalue { i64, ptr } %t23, 0
  %t27 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t25, i64 %t26)
  %t28 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  store { i64, ptr } %t29, ptr %l18, !tbaa !27
  br label %bb8
bb8:
  %t32 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t32, ptr %l5, !tbaa !27
  %t33 = load i1, ptr %l2, !tbaa !21
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t35 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t36 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d244, i32 0, i32 1) }, 1
  %t37 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d244, i32 0, i32 1) }, 0
  %t39 = extractvalue { i64, ptr } %t35, 1
  %t40 = extractvalue { i64, ptr } %t35, 0
  %t41 = add i64 %t37, %t40
  %t42 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d245, i32 0, i32 1) }, 1
  %t43 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d245, i32 0, i32 1) }, 0
  %t44 = add i64 %t41, %t43
  %t45 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t44)
  call void @olang_textcopy(ptr %t45, ptr %t36, i64 %t37)
  %t46 = getelementptr i8, ptr %t45, i64 %t37
  call void @olang_textcopy(ptr %t46, ptr %t39, i64 %t40)
  %t47 = getelementptr i8, ptr %t46, i64 %t40
  call void @olang_textcopy(ptr %t47, ptr %t42, i64 %t43)
  %t48 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t45, 1
  store { i64, ptr } %t49, ptr %l23, !tbaa !27
  br label %bb11
bb10:
  %t51 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t52 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d246, i32 0, i32 1) }, 1
  %t53 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d246, i32 0, i32 1) }, 0
  %t55 = extractvalue { i64, ptr } %t51, 1
  %t56 = extractvalue { i64, ptr } %t51, 0
  %t57 = add i64 %t53, %t56
  %t58 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d247, i32 0, i32 1) }, 1
  %t59 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d247, i32 0, i32 1) }, 0
  %t60 = add i64 %t57, %t59
  %t61 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t60)
  call void @olang_textcopy(ptr %t61, ptr %t52, i64 %t53)
  %t62 = getelementptr i8, ptr %t61, i64 %t53
  call void @olang_textcopy(ptr %t62, ptr %t55, i64 %t56)
  %t63 = getelementptr i8, ptr %t62, i64 %t56
  call void @olang_textcopy(ptr %t63, ptr %t58, i64 %t59)
  %t64 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t61, 1
  store { i64, ptr } %t65, ptr %l23, !tbaa !27
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s1)
  %t67 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t68 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t67, 1
  store { i32, { i64, ptr } } %t68, ptr %rv
  br label %ret
bb12:
  %t69 = load i32, ptr %l4, !range !{i32 0, i32 7}
  %t71 = trunc i64 2 to i32
  %t72 = icmp eq i32 %t69, %t71
  br i1 %t72, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb25
bb15:
  store %olang.scope zeroinitializer, ptr %s5
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 1
  %t76 = load { i64, ptr }, ptr %t75, !tbaa !27
  %t79 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2erecOf(ptr %v0, ptr %v0, ptr %t74, { i64, ptr } %t76)
  store i64 %t79, ptr %l32
  br label %bb16
bb16:
  %t80 = load i64, ptr %l32, !tbaa !24
  store i64 %t80, ptr %l6, !tbaa !24
  %t81 = load i1, ptr %l2, !tbaa !21
  br i1 %t81, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb20
bb18:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load i64, ptr %l6, !tbaa !24
  %t87 = call i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eholdable(ptr %v0, ptr %t83, i64 %t84)
  store i1 %t87, ptr %l37
  br label %bb19
bb19:
  %t88 = load i1, ptr %l37, !tbaa !21
  %t89 = xor i1 %t88, true
  store i1 %t89, ptr %l34, !tbaa !21
  br label %bb20
bb20:
  %t91 = load i1, ptr %l34, !tbaa !21
  br i1 %t91, label %bb21, label %bb22
bb21:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d248, i32 0, i32 1) }, ptr %l39, !tbaa !27
  br label %bb23
bb22:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d249, i32 0, i32 1) }, ptr %l39, !tbaa !27
  br label %bb23
bb23:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load i64, ptr %l6, !tbaa !24
  %t96 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ename(ptr %v0, ptr %s5, ptr %t92, i64 %t93)
  store { i64, ptr } %t96, ptr %l42
  br label %bb24
bb24:
  %t97 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t97, 1
  %t99 = extractvalue { i64, ptr } %t97, 0
  %t100 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 1
  %t102 = extractvalue { i64, ptr } %t100, 0
  %t103 = add i64 %t99, %t102
  %t104 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d250, i32 0, i32 1) }, 1
  %t105 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d250, i32 0, i32 1) }, 0
  %t106 = add i64 %t103, %t105
  %t107 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t106)
  call void @olang_textcopy(ptr %t107, ptr %t98, i64 %t99)
  %t108 = getelementptr i8, ptr %t107, i64 %t99
  call void @olang_textcopy(ptr %t108, ptr %t101, i64 %t102)
  %t109 = getelementptr i8, ptr %t108, i64 %t102
  call void @olang_textcopy(ptr %t109, ptr %t104, i64 %t105)
  %t110 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t107, 1
  call void @__olang_scope_close(ptr %s5)
  %t113 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t111, 1
  store { i32, { i64, ptr } } %t113, ptr %rv
  br label %ret
bb25:
  %t114 = load i32, ptr %l4, !range !{i32 0, i32 7}
  %t116 = trunc i64 3 to i32
  %t117 = icmp eq i32 %t114, %t116
  br i1 %t117, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb50
bb28:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/bindgen:gen", ptr %t119, i32 0, i32 17
  %t122 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 2
  %t123 = load i64, ptr %t122, !tbaa !24
  %t126 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v0, ptr %t121, i64 %t123)
  store %"compiler/bindgen:ctype" %t126, ptr %l49
  br label %bb29
bb29:
  %t127 = load %"compiler/bindgen:ctype", ptr %l49
  store %"compiler/bindgen:ctype" %t127, ptr %l7
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 2
  %t130 = load i64, ptr %t129, !tbaa !24
  %t133 = call i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eisChar(ptr %v0, ptr %t128, i64 %t130)
  store i1 %t133, ptr %l52
  br label %bb30
bb30:
  %t134 = load i1, ptr %l52, !tbaa !21
  br i1 %t134, label %bb31, label %bb32
bb31:
  store { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d251, i32 0, i32 1) }, ptr %l53, !tbaa !27
  %t135 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t135, ptr %l54, !tbaa !27
  %t136 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t136, 0
  store i64 %t137, ptr %l55, !tbaa !24
  %t138 = load i64, ptr %l55, !tbaa !24
  %t139 = mul i64 %t138, 1
  %t140 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t139)
  %t141 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t142 = insertvalue { i64, ptr } %t141, ptr %t140, 1
  store { i64, ptr } %t142, ptr %l56, !tbaa !27
  %t143 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !27
  %t145 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = load i64, ptr %l55, !tbaa !24
  %t148 = mul i64 %t147, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t144, ptr %t146, i64 %t148, i1 false)
  %t149 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t149, ptr %l54, !tbaa !27
  %t150 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t151 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t150, 1
  store { i32, { i64, ptr } } %t151, ptr %rv
  br label %ret
bb32:
  br label %bb33
bb33:
  %t152 = getelementptr %"compiler/bindgen:ctype", ptr %l7, i32 0, i32 0
  %t153 = load i32, ptr %t152, !range !{i32 0, i32 7}
  %t155 = trunc i64 2 to i32
  %t156 = icmp eq i32 %t153, %t155
  br i1 %t156, label %bb34, label %bb35
bb34:
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/bindgen:ctype", ptr %l7, i32 0, i32 1
  %t160 = load { i64, ptr }, ptr %t159, !tbaa !27
  %t163 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2erecOf(ptr %v0, ptr %v0, ptr %t158, { i64, ptr } %t160)
  store i64 %t163, ptr %l61
  br label %bb36
bb35:
  br label %bb42
bb36:
  %t164 = load i64, ptr %l61, !tbaa !24
  store i64 %t164, ptr %l8, !tbaa !24
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t166 = load i64, ptr %l8, !tbaa !24
  %t169 = call i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eholdable(ptr %v0, ptr %t165, i64 %t166)
  store i1 %t169, ptr %l64
  br label %bb37
bb37:
  %t170 = load i1, ptr %l64, !tbaa !21
  %t171 = xor i1 %t170, true
  br i1 %t171, label %bb38, label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s10
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load i64, ptr %l8, !tbaa !24
  %t177 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ename(ptr %v0, ptr %s10, ptr %t173, i64 %t174)
  store { i64, ptr } %t177, ptr %l68
  br label %bb40
bb39:
  br label %bb41
bb40:
  %t178 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d252, i32 0, i32 1) }, 1
  %t179 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d252, i32 0, i32 1) }, 0
  %t180 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t181 = extractvalue { i64, ptr } %t180, 1
  %t182 = extractvalue { i64, ptr } %t180, 0
  %t183 = add i64 %t179, %t182
  %t184 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d253, i32 0, i32 1) }, 1
  %t185 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d253, i32 0, i32 1) }, 0
  %t186 = add i64 %t183, %t185
  %t187 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t186)
  call void @olang_textcopy(ptr %t187, ptr %t178, i64 %t179)
  %t188 = getelementptr i8, ptr %t187, i64 %t179
  call void @olang_textcopy(ptr %t188, ptr %t181, i64 %t182)
  %t189 = getelementptr i8, ptr %t188, i64 %t182
  call void @olang_textcopy(ptr %t189, ptr %t184, i64 %t185)
  %t190 = insertvalue { i64, ptr } undef, i64 %t186, 0
  %t191 = insertvalue { i64, ptr } %t190, ptr %t187, 1
  call void @__olang_scope_close(ptr %s10)
  %t193 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t191, 1
  store { i32, { i64, ptr } } %t193, ptr %rv
  br label %ret
bb41:
  br label %bb42
bb42:
  %t194 = getelementptr %"compiler/bindgen:ctype", ptr %l7, i32 0, i32 0
  %t195 = load i32, ptr %t194, !range !{i32 0, i32 7}
  %t197 = trunc i64 0 to i32
  %t198 = icmp eq i32 %t195, %t197
  br i1 %t198, label %bb43, label %bb44
bb43:
  store i1 true, ptr %l72, !tbaa !21
  br label %bb45
bb44:
  %t200 = getelementptr %"compiler/bindgen:ctype", ptr %l7, i32 0, i32 0
  %t201 = load i32, ptr %t200, !range !{i32 0, i32 7}
  %t203 = trunc i64 2 to i32
  %t204 = icmp eq i32 %t201, %t203
  store i1 %t204, ptr %l72, !tbaa !21
  br label %bb45
bb45:
  %t206 = load i1, ptr %l72, !tbaa !21
  br i1 %t206, label %bb46, label %bb47
bb46:
  store { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d254, i32 0, i32 1) }, ptr %l75, !tbaa !27
  %t207 = load { i64, ptr }, ptr %l75, !tbaa !27
  store { i64, ptr } %t207, ptr %l76, !tbaa !27
  %t208 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t209 = extractvalue { i64, ptr } %t208, 0
  store i64 %t209, ptr %l77, !tbaa !24
  %t210 = load i64, ptr %l77, !tbaa !24
  %t211 = mul i64 %t210, 1
  %t212 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t211)
  %t213 = insertvalue { i64, ptr } undef, i64 %t210, 0
  %t214 = insertvalue { i64, ptr } %t213, ptr %t212, 1
  store { i64, ptr } %t214, ptr %l78, !tbaa !27
  %t215 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t216 = load ptr, ptr %t215, !tbaa !27
  %t217 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t218 = load ptr, ptr %t217, !tbaa !27
  %t219 = load i64, ptr %l77, !tbaa !24
  %t220 = mul i64 %t219, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t216, ptr %t218, i64 %t220, i1 false)
  %t221 = load { i64, ptr }, ptr %l78, !tbaa !27
  store { i64, ptr } %t221, ptr %l76, !tbaa !27
  %t222 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t223 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t222, 1
  store { i32, { i64, ptr } } %t223, ptr %rv
  br label %ret
bb47:
  br label %bb48
bb48:
  %t224 = load i1, ptr %l2, !tbaa !21
  %t226 = call { i64, ptr } @compiler_2fbindgen_2evoidRef(ptr %v1, i1 %t224)
  store { i64, ptr } %t226, ptr %l80
  br label %bb49
bb49:
  %t227 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t228 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t227, 1
  store { i32, { i64, ptr } } %t228, ptr %rv
  br label %ret
bb50:
  %t229 = load i32, ptr %l4, !range !{i32 0, i32 7}
  %t231 = trunc i64 5 to i32
  %t232 = icmp eq i32 %t229, %t231
  br i1 %t232, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb64
bb53:
  store %olang.scope zeroinitializer, ptr %s13
  %t234 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 1
  %t235 = load { i64, ptr }, ptr %t234, !tbaa !27
  %t237 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s13, { i64, ptr } %t235, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d255, i32 0, i32 1) })
  store i1 %t237, ptr %l84
  br label %bb54
bb54:
  %t238 = load i1, ptr %l84, !tbaa !21
  br i1 %t238, label %bb55, label %bb56
bb55:
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t241 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %v0, ptr %t239, { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d256, i32 0, i32 1) })
  store i32 %t241, ptr %l86
  %t242 = icmp ne i32 %t241, 0
  br i1 %t242, label %bb58, label %ok.243, !prof !99
ok.243:
  br label %bb57
bb56:
  br label %bb60
bb57:
  br label %bb59
bb58:
  %t244 = load i32, ptr %l86, !tbaa !23
  %t245 = lshr i32 %t244, 16
  %t246 = and i32 %t244, 65535
  %t247 = icmp eq i32 %t245, 1
  %t248 = select i1 %t247, i32 1, i32 0
  %t249 = icmp eq i32 %t244, 0
  %t250 = shl i32 %t248, 16
  %t251 = or i32 %t250, %t246
  %t252 = select i1 %t249, i32 0, i32 %t251
  call void @__olang_scope_close(ptr %s13)
  %t254 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t252, 0
  store { i32, { i64, ptr } } %t254, ptr %rv
  br label %ret
bb59:
  br label %bb60
bb60:
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t256 = load %"compiler/bindgen:ctype", ptr %l3
  %t259 = call { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2efnSpelled(ptr %v0, ptr %v0, ptr %v1, ptr %t255, %"compiler/bindgen:ctype" %t256)
  %t260 = extractvalue { i32, { i64, ptr } } %t259, 1
  %t261 = extractvalue { i32, { i64, ptr } } %t259, 0
  store i32 %t261, ptr %l92
  %t262 = icmp ne i32 %t261, 0
  br i1 %t262, label %bb62, label %ok.263, !prof !99
ok.263:
  store { i64, ptr } %t260, ptr %l91
  br label %bb61
bb61:
  %t264 = load { i64, ptr }, ptr %l91, !tbaa !27
  store { i64, ptr } %t264, ptr %l88, !tbaa !27
  br label %bb63
bb62:
  %t265 = load i32, ptr %l92, !tbaa !23
  %t266 = lshr i32 %t265, 16
  %t267 = and i32 %t265, 65535
  %t268 = icmp eq i32 %t266, 1
  %t269 = select i1 %t268, i32 1, i32 0
  %t270 = icmp eq i32 %t265, 0
  %t271 = shl i32 %t269, 16
  %t272 = or i32 %t271, %t267
  %t273 = select i1 %t270, i32 0, i32 %t272
  call void @__olang_scope_close(ptr %s13)
  %t275 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t273, 0
  store { i32, { i64, ptr } } %t275, ptr %rv
  br label %ret
bb63:
  call void @__olang_scope_close(ptr %s13)
  %t276 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t277 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t276, 1
  store { i32, { i64, ptr } } %t277, ptr %rv
  br label %ret
bb64:
  %t278 = load i32, ptr %l4, !range !{i32 0, i32 7}
  %t280 = trunc i64 6 to i32
  %t281 = icmp eq i32 %t278, %t280
  br i1 %t281, label %bb65, label %bb66
bb65:
  br label %bb67
bb66:
  br label %bb71
bb67:
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t284 = getelementptr %"compiler/bindgen:ctype", ptr %l3, i32 0, i32 1
  %t285 = load { i64, ptr }, ptr %t284, !tbaa !27
  %t288 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %v0, ptr %t283, { i64, ptr } %t285)
  store i32 %t288, ptr %l98
  %t289 = icmp ne i32 %t288, 0
  br i1 %t289, label %bb69, label %ok.290, !prof !99
ok.290:
  br label %bb68
bb68:
  br label %bb70
bb69:
  %t291 = load i32, ptr %l98, !tbaa !23
  %t292 = lshr i32 %t291, 16
  %t293 = and i32 %t291, 65535
  %t294 = icmp eq i32 %t292, 1
  %t295 = select i1 %t294, i32 1, i32 0
  %t296 = icmp eq i32 %t291, 0
  %t297 = shl i32 %t295, 16
  %t298 = or i32 %t297, %t293
  %t299 = select i1 %t296, i32 0, i32 %t298
  %t301 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t299, 0
  store { i32, { i64, ptr } } %t301, ptr %rv
  br label %ret
bb70:
  br label %bb76
bb71:
  br i1 true, label %bb72, label %bb73
bb72:
  br label %bb74
bb73:
  br label %bb75
bb74:
  br label %bb76
bb75:
  call void @__olang_check_failed(ptr @olang_loc_55ef846781ac27aa_5519550b25564c26)
  unreachable
bb76:
  %t302 = load i1, ptr %l2, !tbaa !21
  %t304 = call { i64, ptr } @compiler_2fbindgen_2evoidRef(ptr %v1, i1 %t302)
  store { i64, ptr } %t304, ptr %l101
  br label %bb77
bb77:
  %t305 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t306 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t305, 1
  store { i32, { i64, ptr } } %t306, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eread(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %lp15 = alloca ptr
  %lp16 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca i64
  %l24 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %lp35 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca ptr
  %l42 = alloca i1
  %l43 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l58 = alloca ptr
  %l80 = alloca ptr
  %l91 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l95 = alloca i1
  %l97 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %l111 = alloca { i64, ptr }
  %l115 = alloca ptr
  %l118 = alloca i64
  %l120 = alloca ptr
  %l122 = alloca { i64, ptr }
  %l124 = alloca i64
  %l125 = alloca i32
  %l128 = alloca i1
  %l130 = alloca i1
  %l131 = alloca i1
  %l133 = alloca i1
  %l143 = alloca ptr
  %l144 = alloca ptr
  %l146 = alloca { i64, ptr }
  %l151 = alloca %"compiler/bindgen:record"
  %l153 = alloca i1
  %l155 = alloca i64
  %l163 = alloca ptr
  %l164 = alloca ptr
  %l166 = alloca { i64, ptr }
  %l172 = alloca i1
  %l173 = alloca ptr
  %l174 = alloca ptr
  %l175 = alloca { i64, ptr }
  %l178 = alloca i1
  %l180 = alloca i1
  %l182 = alloca { i64, ptr }
  %l190 = alloca { i64, ptr }
  %l194 = alloca { i64, ptr }
  %l196 = alloca i1
  %l199 = alloca { i64, ptr }
  %l201 = alloca i1
  %l203 = alloca i64
  %l204 = alloca { i64, ptr }
  %l205 = alloca i64
  %l206 = alloca i32
  %l207 = alloca i64
  %l208 = alloca i32
  %l211 = alloca { i64, ptr }
  %l218 = alloca i1
  %l229 = alloca i1
  %l230 = alloca i1
  %l233 = alloca i1
  %l234 = alloca i1
  %l236 = alloca i1
  %l238 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l240 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l243 = alloca { i64, ptr }
  %l251 = alloca { i64, ptr }
  %l255 = alloca { i64, ptr }
  %l257 = alloca i1
  %l258 = alloca ptr
  %l259 = alloca i64
  %l262 = alloca { i64, ptr }
  %l264 = alloca ptr
  %l265 = alloca i64
  %l268 = alloca { i64, ptr }
  %l274 = alloca { i64, ptr }
  %l276 = alloca i1
  %l277 = alloca i1
  %l279 = alloca i1
  %l282 = alloca i1
  %l288 = alloca { i64, ptr }
  %l290 = alloca i1
  %l291 = alloca i1
  %l294 = alloca i1
  %l295 = alloca { i64, ptr }
  %l300 = alloca ptr
  %l301 = alloca { i64, ptr }
  %l302 = alloca i64
  %l305 = alloca { i64, ptr }
  %l306 = alloca { i64, ptr }
  %l307 = alloca i64
  %l310 = alloca { i64, ptr }
  %l311 = alloca i64
  %l314 = alloca { i64, ptr }
  %l317 = alloca %"compiler/bindgen:cFunc"
  %l319 = alloca i1
  %l320 = alloca i1
  %l323 = alloca i1
  %l324 = alloca i1
  %l326 = alloca i1
  %l327 = alloca i1
  %l329 = alloca { i64, ptr }
  %l331 = alloca i1
  %l334 = alloca ptr
  %l335 = alloca i64
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %t228 = alloca %"compiler/bindgen:record", align 8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = call { i64, ptr } @compiler_2fbindgen_2einner(ptr %v1, ptr %s1, ptr %a1)
  store { i64, ptr } %t3, ptr %l46
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t4, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t10 = load i64, ptr %l4, !tbaa !24
  %t11 = load i64, ptr %l5, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb199
bb4:
  br label %bb5
bb5:
  %t18 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t18, ptr %l54, !tbaa !27
  %t19 = load i64, ptr %l4, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  store ptr %t24, ptr %l6, !tbaa !29
  %t26 = load ptr, ptr %l6, !tbaa !29
  %t28 = call ptr @compiler_2fbindgen_2emember(ptr %s1, ptr %s2, ptr %s1, ptr %t26, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d257, i32 0, i32 1) })
  store ptr %t28, ptr %l58
  br label %bb6
bb6:
  %t29 = load ptr, ptr %l58, !tbaa !29
  store ptr %t29, ptr %l7, !tbaa !29
  %t30 = load ptr, ptr %l7, !tbaa !29
  %t32 = icmp eq ptr %t30, null
  %t34 = xor i1 %t32, true
  br i1 %t34, label %bb7, label %bb8
bb7:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load ptr, ptr %l7, !tbaa !29
  %t38 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2etrack(ptr %v0, ptr %s1, ptr %v2, ptr %t36, ptr %t37, { i64, ptr } %t38)
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb10
bb10:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/bindgen:gen", ptr %t42, i32 0, i32 27
  %t45 = load i64, ptr %t44, !tbaa !24
  store i64 %t45, ptr %l8, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s4
  %t47 = insertvalue [3 x { i64, ptr }] undef, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d258, i32 0, i32 1) }, 0
  %t48 = insertvalue [3 x { i64, ptr }] %t47, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d259, i32 0, i32 1) }, 1
  %t49 = insertvalue [3 x { i64, ptr }] %t48, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d260, i32 0, i32 1) }, 2
  %t51 = call ptr @__olang_scope_alloc_a(ptr %s4, i64 48, i64 8)
  store [3 x { i64, ptr }] %t49, ptr %t51
  store ptr %t51, ptr %l9
  store i64 0, ptr %l10, !tbaa !24
  %t53 = load ptr, ptr %l9
  store i64 3, ptr %l11, !tbaa !24
  br label %bb11
bb11:
  %t56 = load i64, ptr %l10, !tbaa !24
  %t57 = load i64, ptr %l11, !tbaa !24
  %t60 = icmp slt i64 %t56, %t57
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb12, label %bb13
bb12:
  br label %bb21
bb13:
  br label %bb14
bb14:
  %t64 = load ptr, ptr %l9
  %t65 = load i64, ptr %l10, !tbaa !24
  %t68 = getelementptr [3 x { i64, ptr }], ptr %t64, i64 0, i64 %t65
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !37
  %t71 = load ptr, ptr %l6, !tbaa !29
  %t73 = load ptr, ptr @__olang_prog_scope
  %t76 = call ptr @compiler_2fbindgen_2emember(ptr %s1, ptr %t73, ptr %s1, ptr %t71, { i64, ptr } %t69)
  store ptr %t76, ptr %l80
  br label %bb15
bb15:
  %t77 = load ptr, ptr %l80, !tbaa !29
  store ptr %t77, ptr %l13, !tbaa !29
  %t78 = load ptr, ptr %l13, !tbaa !29
  %t80 = icmp eq ptr %t78, null
  %t82 = xor i1 %t80, true
  br i1 %t82, label %bb16, label %bb17
bb16:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load ptr, ptr %l13, !tbaa !29
  %t86 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2etrack(ptr %v0, ptr %s1, ptr %v2, ptr %t84, ptr %t85, { i64, ptr } %t86)
  br label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t90 = load i64, ptr %l10, !tbaa !24
  %t93 = add i64 %t90, 1
  store i64 %t93, ptr %l10, !tbaa !24
  br label %bb11
bb21:
  call void @__olang_scope_close(ptr %s4)
  %t95 = load ptr, ptr %l6, !tbaa !29
  %t97 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %s1, ptr %s2, ptr %s2, ptr %t95, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d261, i32 0, i32 1) })
  store { i64, ptr } %t97, ptr %l91
  br label %bb22
bb22:
  %t98 = load { i64, ptr }, ptr %l91, !tbaa !27
  store { i64, ptr } %t98, ptr %l14, !tbaa !27
  %t99 = load ptr, ptr %l6, !tbaa !29
  %t101 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %s1, ptr %s2, ptr %v0, ptr %t99, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d262, i32 0, i32 1) })
  store { i64, ptr } %t101, ptr %l93
  br label %bb23
bb23:
  %t102 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t102, ptr %lp15
  %t103 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t104 = load ptr, ptr %lp15
  store { i64, ptr } %t103, ptr %t104, !tbaa !27
  %t105 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t107 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t105, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d263, i32 0, i32 1) })
  store i1 %t107, ptr %l95
  br label %bb24
bb24:
  %t108 = load i1, ptr %l95, !tbaa !21
  br i1 %t108, label %bb25, label %bb26
bb25:
  %t109 = load ptr, ptr %l6, !tbaa !29
  %t111 = call { i64, ptr } @compiler_2fbindgen_2etypeOf(ptr %s1, ptr %v0, ptr %t109)
  store { i64, ptr } %t111, ptr %l97
  br label %bb27
bb26:
  br label %bb70
bb27:
  %t112 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t112, ptr %lp16
  %t113 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t114 = load ptr, ptr %lp16
  store { i64, ptr } %t113, ptr %t114, !tbaa !27
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/bindgen:gen", ptr %t115, i32 0, i32 5
  %t118 = load ptr, ptr %lp15
  %t119 = load { i64, ptr }, ptr %t118, !tbaa !27
  %t120 = load ptr, ptr %lp16
  %t121 = load { i64, ptr }, ptr %t120, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6f7a2f8d839c49b6e7a19c287d4b190c(ptr %v0, ptr %v0, ptr %v0, ptr %t117, { i64, ptr } %t119, { i64, ptr } %t121)
  br label %bb28
bb28:
  store %olang.scope zeroinitializer, ptr %s9
  %t125 = load ptr, ptr %l6, !tbaa !29
  %t127 = call { i64, ptr } @compiler_2fbindgen_2einner(ptr %s1, ptr %s9, ptr %t125)
  store { i64, ptr } %t127, ptr %l103
  br label %bb29
bb29:
  %t128 = load { i64, ptr }, ptr %l103, !tbaa !27
  store { i64, ptr } %t128, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  %t130 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t130, 0
  store i64 %t132, ptr %l19, !tbaa !24
  br label %bb30
bb30:
  store %olang.scope zeroinitializer, ptr %s10
  %t134 = load i64, ptr %l18, !tbaa !24
  %t135 = load i64, ptr %l19, !tbaa !24
  %t138 = icmp slt i64 %t134, %t135
  %t140 = xor i1 %t138, true
  br i1 %t140, label %bb31, label %bb32
bb31:
  call void @__olang_scope_close(ptr %s10)
  br label %bb69
bb32:
  br label %bb33
bb33:
  %t142 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t142, ptr %l111, !tbaa !27
  %t143 = load i64, ptr %l18, !tbaa !24
  %t145 = getelementptr { i64, ptr }, ptr %l111, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = getelementptr ptr, ptr %t146, i64 %t143
  %t148 = load ptr, ptr %t147, !tbaa !39
  %t152 = call ptr @compiler_2fbindgen_2emember(ptr %s9, ptr %s10, ptr %s9, ptr %t148, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d264, i32 0, i32 1) })
  store ptr %t152, ptr %l115
  br label %bb34
bb34:
  %t153 = load ptr, ptr %l115, !tbaa !29
  store ptr %t153, ptr %l21, !tbaa !29
  %t154 = load ptr, ptr %l21, !tbaa !29
  %t156 = icmp eq ptr %t154, null
  br i1 %t156, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s10)
  br label %bb68
bb36:
  br label %bb37
bb37:
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/bindgen:gen", ptr %t158, i32 0, i32 8
  store ptr %t160, ptr %l120, !tbaa !29
  %t161 = load ptr, ptr %l21, !tbaa !29
  %t163 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %s9, ptr %s10, ptr %s10, ptr %t161, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d265, i32 0, i32 1) })
  store { i64, ptr } %t163, ptr %l122
  br label %bb38
bb38:
  %t164 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t165 = load ptr, ptr %l120, !tbaa !29
  %t167 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %s10, ptr %t165, { i64, ptr } %t164)
  %t168 = extractvalue { i32, i64 } %t167, 1
  %t169 = extractvalue { i32, i64 } %t167, 0
  store i32 %t169, ptr %l125
  %t170 = icmp ne i32 %t169, 0
  br i1 %t170, label %bb40, label %ok.171, !prof !99
ok.171:
  store i64 %t168, ptr %l124
  br label %bb39
bb39:
  %t172 = load i64, ptr %l124, !tbaa !24
  store i64 %t172, ptr %l118, !tbaa !24
  br label %bb42
bb40:
  br label %bb41
bb41:
  store i64 -1, ptr %l118, !tbaa !24
  br label %bb42
bb42:
  %t173 = load i64, ptr %l118, !tbaa !24
  store i64 %t173, ptr %l22, !tbaa !24
  %t174 = load i64, ptr %l22, !tbaa !24
  %t176 = icmp sge i64 %t174, 0
  br i1 %t176, label %bb43, label %bb44
bb43:
  %t178 = load ptr, ptr %lp16
  %t179 = load { i64, ptr }, ptr %t178, !tbaa !27
  %t181 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s10, { i64, ptr } %t179, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d266, i32 0, i32 1) })
  store i1 %t181, ptr %l130
  br label %bb45
bb44:
  store i1 false, ptr %l128, !tbaa !21
  br label %bb50
bb45:
  %t182 = load i1, ptr %l130, !tbaa !21
  br i1 %t182, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l131, !tbaa !21
  br label %bb49
bb47:
  %t183 = load ptr, ptr %lp16
  %t184 = load { i64, ptr }, ptr %t183, !tbaa !27
  %t186 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s10, { i64, ptr } %t184, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d267, i32 0, i32 1) })
  store i1 %t186, ptr %l133
  br label %bb48
bb48:
  %t187 = load i1, ptr %l133, !tbaa !21
  store i1 %t187, ptr %l131, !tbaa !21
  br label %bb49
bb49:
  %t188 = load i1, ptr %l131, !tbaa !21
  store i1 %t188, ptr %l128, !tbaa !21
  br label %bb50
bb50:
  %t189 = load i1, ptr %l128, !tbaa !21
  br i1 %t189, label %bb51, label %bb52
bb51:
  store %olang.scope zeroinitializer, ptr %s12
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t192 = getelementptr %"compiler/bindgen:gen", ptr %t190, i32 0, i32 7
  %t193 = load ptr, ptr %lp16
  %t194 = load { i64, ptr }, ptr %t193, !tbaa !27
  %t195 = load i64, ptr %l22, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v0, ptr %t192, { i64, ptr } %t194, i64 %t195)
  br label %bb53
bb52:
  br label %bb67
bb53:
  %t199 = load i64, ptr %l22, !tbaa !24
  %t201 = load ptr, ptr %lp16
  %t202 = load { i64, ptr }, ptr %t201, !tbaa !27
  store { i64, ptr } %t202, ptr %l24, !tbaa !27
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t206 = getelementptr %"compiler/bindgen:gen", ptr %t204, i32 0, i32 6
  %t210 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRefMu_Hc21bcd245b67ffb6ee3e145838fcf2cf(ptr %v0, ptr %v0, ptr %t206, i64 %t199)
  store ptr %t210, ptr %l143
  br label %bb54
bb54:
  %t211 = load ptr, ptr %l143, !tbaa !29
  store ptr %t211, ptr %l144, !tbaa !29
  %t213 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t214 = load ptr, ptr %l144, !tbaa !29
  %t215 = getelementptr %"compiler/bindgen:record", ptr %t214, i32 0, i32 0
  %t216 = load { i64, ptr }, ptr %t215, !tbaa !27
  store { i64, ptr } %t216, ptr %l146, !tbaa !27
  %t218 = load ptr, ptr %l144, !tbaa !29
  %t219 = getelementptr %"compiler/bindgen:record", ptr %t218, i32 0, i32 0
  store { i64, ptr } %t213, ptr %t219, !tbaa !27
  %t220 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3arecord_2e0
  br i1 %t220, label %bb55, label %bb56
bb55:
  %t222 = load { i64, ptr }, ptr %l146
  %t223 = extractvalue { i64, ptr } %t222, 1
  call void @__olang_region_release(ptr %t223)
  store { i64, ptr } zeroinitializer, ptr %l146
  br label %bb56
bb56:
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t226 = getelementptr %"compiler/bindgen:gen", ptr %t224, i32 0, i32 6
  %t227 = load i64, ptr %l22, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t228, ptr %v0, ptr %v0, ptr %t226, i64 %t227)
  call void @llvm.memmove.p0.p0.i64(ptr %l151, ptr %t228, i64 312, i1 false)
  br label %bb57
bb57:
  %t231 = getelementptr %"compiler/bindgen:record", ptr %l151, i32 0, i32 11
  %t232 = load { i64, ptr }, ptr %t231, !tbaa !27
  %t234 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s12, { i64, ptr } %t232, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d268, i32 0, i32 1) })
  store i1 %t234, ptr %l153
  br label %bb58
bb58:
  %t235 = load i1, ptr %l153, !tbaa !21
  br i1 %t235, label %bb59, label %bb60
bb59:
  %t236 = load i64, ptr %l22, !tbaa !24
  store i64 %t236, ptr %l26, !tbaa !24
  %t238 = call ptr @__olang_scope_hold(ptr %v0)
  %t239 = ptrtoint ptr %t238 to i64
  store i64 %t239, ptr %l155, !tbaa !24
  %t240 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3arecord_2e11
  br i1 %t240, label %bb61, label %bb62
bb60:
  br label %bb66
bb61:
  %t242 = call ptr @__olang_region_make(ptr %v0)
  %t243 = ptrtoint ptr %t242 to i64
  store i64 %t243, ptr %l155, !tbaa !24
  br label %bb62
bb62:
  %t244 = load ptr, ptr %lp15
  %t245 = load { i64, ptr }, ptr %t244, !tbaa !27
  %t247 = extractvalue { i64, ptr } %t245, 1
  %t248 = extractvalue { i64, ptr } %t245, 0
  %t249 = load i64, ptr %l155
  %t250 = inttoptr i64 %t249 to ptr
  %t251 = call ptr @__olang_held_alloc(ptr %t250, i64 %t248)
  call void @olang_textcopy(ptr %t251, ptr %t247, i64 %t248)
  %t252 = insertvalue { i64, ptr } undef, i64 %t248, 0
  %t253 = insertvalue { i64, ptr } %t252, ptr %t251, 1
  store { i64, ptr } %t253, ptr %l27, !tbaa !27
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = getelementptr %"compiler/bindgen:gen", ptr %t256, i32 0, i32 6
  %t259 = load i64, ptr %l26, !tbaa !24
  %t262 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRefMu_Hc21bcd245b67ffb6ee3e145838fcf2cf(ptr %v0, ptr %v0, ptr %t258, i64 %t259)
  store ptr %t262, ptr %l163
  br label %bb63
bb63:
  %t263 = load ptr, ptr %l163, !tbaa !29
  store ptr %t263, ptr %l164, !tbaa !29
  %t265 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t266 = load ptr, ptr %l164, !tbaa !29
  %t267 = getelementptr %"compiler/bindgen:record", ptr %t266, i32 0, i32 11
  %t268 = load { i64, ptr }, ptr %t267, !tbaa !27
  store { i64, ptr } %t268, ptr %l166, !tbaa !27
  %t270 = load ptr, ptr %l164, !tbaa !29
  %t271 = getelementptr %"compiler/bindgen:record", ptr %t270, i32 0, i32 11
  store { i64, ptr } %t265, ptr %t271, !tbaa !27
  %t272 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3arecord_2e11
  br i1 %t272, label %bb64, label %bb65
bb64:
  %t274 = load { i64, ptr }, ptr %l166
  %t275 = extractvalue { i64, ptr } %t274, 1
  call void @__olang_region_release(ptr %t275)
  store { i64, ptr } zeroinitializer, ptr %l166
  br label %bb65
bb65:
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s12)
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s10)
  br label %bb68
bb68:
  %t276 = load i64, ptr %l18, !tbaa !24
  %t279 = add i64 %t276, 1
  store i64 %t279, ptr %l18, !tbaa !24
  br label %bb30
bb69:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s2)
  br label %bb198
bb70:
  %t281 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t283 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t281, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d269, i32 0, i32 1) })
  store i1 %t283, ptr %l172
  br label %bb71
bb71:
  %t284 = load i1, ptr %l172, !tbaa !21
  br i1 %t284, label %bb72, label %bb73
bb72:
  %t285 = load ptr, ptr %l0, !tbaa !29
  store ptr %t285, ptr %l173, !tbaa !29
  %t286 = load ptr, ptr %l6, !tbaa !29
  store ptr %t286, ptr %l174, !tbaa !29
  %t287 = load ptr, ptr %lp15
  %t288 = load { i64, ptr }, ptr %t287, !tbaa !27
  store { i64, ptr } %t288, ptr %l175, !tbaa !27
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t290 = load i64, ptr %l8, !tbaa !24
  %t293 = call i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ewanted(ptr %v0, ptr %t289, i64 %t290)
  store i1 %t293, ptr %l178
  br label %bb74
bb73:
  br label %bb76
bb74:
  %t294 = load ptr, ptr %l173, !tbaa !29
  %t295 = load ptr, ptr %l174, !tbaa !29
  %t296 = load { i64, ptr }, ptr %l175, !tbaa !27
  %t297 = load i1, ptr %l178, !tbaa !21
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2erecordDecl(ptr %v0, ptr %s1, ptr %v0, ptr %t294, ptr %t295, { i64, ptr } %t296, i1 %t297)
  br label %bb75
bb75:
  call void @__olang_scope_close(ptr %s2)
  br label %bb198
bb76:
  %t298 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t300 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t298, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d270, i32 0, i32 1) })
  store i1 %t300, ptr %l180
  br label %bb77
bb77:
  %t301 = load i1, ptr %l180, !tbaa !21
  br i1 %t301, label %bb78, label %bb79
bb78:
  store i64 0, ptr %l29, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s18
  %t302 = load ptr, ptr %l6, !tbaa !29
  %t304 = call { i64, ptr } @compiler_2fbindgen_2einner(ptr %s1, ptr %s18, ptr %t302)
  store { i64, ptr } %t304, ptr %l182
  br label %bb80
bb79:
  br label %bb110
bb80:
  %t305 = load { i64, ptr }, ptr %l182, !tbaa !27
  store { i64, ptr } %t305, ptr %l30, !tbaa !27
  store i64 0, ptr %l31, !tbaa !24
  %t307 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t309 = extractvalue { i64, ptr } %t307, 0
  store i64 %t309, ptr %l32, !tbaa !24
  br label %bb81
bb81:
  store %olang.scope zeroinitializer, ptr %s19
  %t311 = load i64, ptr %l31, !tbaa !24
  %t312 = load i64, ptr %l32, !tbaa !24
  %t315 = icmp slt i64 %t311, %t312
  %t317 = xor i1 %t315, true
  br i1 %t317, label %bb82, label %bb83
bb82:
  call void @__olang_scope_close(ptr %s19)
  br label %bb109
bb83:
  br label %bb84
bb84:
  %t319 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t319, ptr %l190, !tbaa !27
  %t320 = load i64, ptr %l31, !tbaa !24
  %t322 = getelementptr { i64, ptr }, ptr %l190, i32 0, i32 1
  %t323 = load ptr, ptr %t322, !tbaa !27
  %t324 = getelementptr ptr, ptr %t323, i64 %t320
  %t325 = load ptr, ptr %t324, !tbaa !39
  store ptr %t325, ptr %l33, !tbaa !29
  %t327 = load ptr, ptr %l33, !tbaa !29
  %t329 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %s18, ptr %s19, ptr %s19, ptr %t327, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d271, i32 0, i32 1) })
  store { i64, ptr } %t329, ptr %l194
  br label %bb85
bb85:
  %t330 = load { i64, ptr }, ptr %l194, !tbaa !27
  %t332 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s19, ptr %s19, { i64, ptr } %t330, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d272, i32 0, i32 1) })
  store i1 %t332, ptr %l196
  br label %bb86
bb86:
  %t333 = load i1, ptr %l196, !tbaa !21
  %t334 = xor i1 %t333, true
  br i1 %t334, label %bb87, label %bb88
bb87:
  call void @__olang_scope_close(ptr %s19)
  br label %bb108
bb88:
  br label %bb89
bb89:
  %t336 = load ptr, ptr %l33, !tbaa !29
  %t338 = call { i64, ptr } @compiler_2fbindgen_2econstValue(ptr %s18, ptr %s19, ptr %t336)
  store { i64, ptr } %t338, ptr %l199
  br label %bb90
bb90:
  %t339 = load { i64, ptr }, ptr %l199, !tbaa !27
  store { i64, ptr } %t339, ptr %l34, !tbaa !27
  %t340 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t342 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s19, ptr %s19, { i64, ptr } %t340, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d273, i32 0, i32 1) })
  store i1 %t342, ptr %l201
  br label %bb91
bb91:
  %t343 = load i1, ptr %l201, !tbaa !21
  %t344 = xor i1 %t343, true
  br i1 %t344, label %bb92, label %bb93
bb92:
  store %olang.scope zeroinitializer, ptr %s21
  %t346 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t346, ptr %l204, !tbaa !27
  %t347 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s21, i64 10)
  %t348 = extractvalue { i32, i64 } %t347, 1
  %t349 = extractvalue { i32, i64 } %t347, 0
  store i32 %t349, ptr %l206
  %t350 = icmp ne i32 %t349, 0
  br i1 %t350, label %bb95, label %ok.351, !prof !99
ok.351:
  store i64 %t348, ptr %l205
  br label %bb94
bb93:
  br label %bb100
bb94:
  %t352 = load { i64, ptr }, ptr %l204, !tbaa !27
  %t353 = load i64, ptr %l205, !tbaa !24
  %t354 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s19, { i64, ptr } %t352, i64 %t353)
  %t355 = extractvalue { i32, i64 } %t354, 1
  %t356 = extractvalue { i32, i64 } %t354, 0
  store i32 %t356, ptr %l208
  %t357 = icmp ne i32 %t356, 0
  br i1 %t357, label %bb98, label %ok.358, !prof !99
ok.358:
  store i64 %t355, ptr %l207
  br label %bb97
bb95:
  br label %bb96
bb96:
  %t359 = load i64, ptr %l29, !tbaa !24
  store i64 %t359, ptr %l203, !tbaa !24
  br label %bb99
bb97:
  %t361 = load i64, ptr %l207, !tbaa !24
  store i64 %t361, ptr %l203, !tbaa !24
  br label %bb99
bb98:
  br label %bb96
bb99:
  %t362 = load i64, ptr %l203, !tbaa !24
  store i64 %t362, ptr %l29, !tbaa !24
  call void @__olang_scope_close(ptr %s21)
  br label %bb100
bb100:
  %t363 = load ptr, ptr %l33, !tbaa !29
  %t365 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %s18, ptr %s19, ptr %v0, ptr %t363, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d274, i32 0, i32 1) })
  store { i64, ptr } %t365, ptr %l211
  br label %bb101
bb101:
  %t366 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t366, ptr %lp35
  %t367 = load { i64, ptr }, ptr %l211, !tbaa !27
  %t368 = load ptr, ptr %lp35
  store { i64, ptr } %t367, ptr %t368, !tbaa !27
  %t369 = load ptr, ptr %l0, !tbaa !29
  %t371 = getelementptr %"compiler/bindgen:gen", ptr %t369, i32 0, i32 12
  %t372 = load ptr, ptr %lp35
  %t373 = load { i64, ptr }, ptr %t372, !tbaa !27
  %t374 = load i64, ptr %l29, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v0, ptr %t371, { i64, ptr } %t373, i64 %t374)
  br label %bb102
bb102:
  %t378 = load ptr, ptr %l0, !tbaa !29
  %t379 = load i64, ptr %l8, !tbaa !24
  %t382 = call i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ewanted(ptr %v0, ptr %t378, i64 %t379)
  store i1 %t382, ptr %l218
  br label %bb103
bb103:
  %t383 = load i1, ptr %l218, !tbaa !21
  br i1 %t383, label %bb104, label %bb105
bb104:
  %t384 = load ptr, ptr %l0, !tbaa !29
  %t385 = load ptr, ptr %lp35
  %t386 = load { i64, ptr }, ptr %t385, !tbaa !27
  %t387 = load i64, ptr %l29, !tbaa !24
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2econstant(ptr %v0, ptr %v0, ptr %t384, { i64, ptr } %t386, i64 %t387)
  br label %bb106
bb105:
  br label %bb107
bb106:
  br label %bb107
bb107:
  %t391 = load i64, ptr %l29, !tbaa !24
  %t394 = add i64 %t391, 1
  store i64 %t394, ptr %l29, !tbaa !24
  call void @__olang_scope_close(ptr %s19)
  br label %bb108
bb108:
  %t396 = load i64, ptr %l31, !tbaa !24
  %t399 = add i64 %t396, 1
  store i64 %t399, ptr %l31, !tbaa !24
  br label %bb81
bb109:
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s2)
  br label %bb198
bb110:
  %t401 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t403 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t401, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d275, i32 0, i32 1) })
  store i1 %t403, ptr %l229
  br label %bb111
bb111:
  %t404 = load i1, ptr %l229, !tbaa !21
  br i1 %t404, label %bb112, label %bb113
bb112:
  %t405 = load ptr, ptr %l0, !tbaa !29
  %t406 = load i64, ptr %l8, !tbaa !24
  %t409 = call i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ewanted(ptr %v0, ptr %t405, i64 %t406)
  store i1 %t409, ptr %l233
  br label %bb114
bb113:
  store i1 false, ptr %l230, !tbaa !21
  br label %bb115
bb114:
  %t410 = load i1, ptr %l233, !tbaa !21
  store i1 %t410, ptr %l230, !tbaa !21
  br label %bb115
bb115:
  %t411 = load i1, ptr %l230, !tbaa !21
  br i1 %t411, label %bb116, label %bb117
bb116:
  %t412 = load ptr, ptr %l6, !tbaa !29
  %t414 = call i1 @compiler_2fbindgen_2eflag(ptr %s1, ptr %s2, ptr %t412, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d276, i32 0, i32 1) })
  store i1 %t414, ptr %l236
  br label %bb118
bb117:
  store i1 false, ptr %l234, !tbaa !21
  br label %bb119
bb118:
  %t415 = load i1, ptr %l236, !tbaa !21
  %t416 = xor i1 %t415, true
  store i1 %t416, ptr %l234, !tbaa !21
  br label %bb119
bb119:
  %t418 = load i1, ptr %l234, !tbaa !21
  br i1 %t418, label %bb120, label %bb121
bb120:
  store %olang.scope zeroinitializer, ptr %s24
  %t419 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t419, ptr %l238
  br label %bb122
bb121:
  br label %bb177
bb122:
  %t420 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l238
  %t421 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t420, ptr %t421
  store ptr %t421, ptr %l36, !tbaa !29
  %t423 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t423, ptr %l240
  br label %bb123
bb123:
  %t424 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l240
  %t425 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t424, ptr %t425
  store ptr %t425, ptr %l37, !tbaa !29
  store %olang.scope zeroinitializer, ptr %s25
  %t427 = load ptr, ptr %l6, !tbaa !29
  %t429 = call { i64, ptr } @compiler_2fbindgen_2einner(ptr %s1, ptr %s25, ptr %t427)
  store { i64, ptr } %t429, ptr %l243
  br label %bb124
bb124:
  %t430 = load { i64, ptr }, ptr %l243, !tbaa !27
  store { i64, ptr } %t430, ptr %l38, !tbaa !27
  store i64 0, ptr %l39, !tbaa !24
  %t432 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t434 = extractvalue { i64, ptr } %t432, 0
  store i64 %t434, ptr %l40, !tbaa !24
  br label %bb125
bb125:
  store %olang.scope zeroinitializer, ptr %s26
  %t436 = load i64, ptr %l39, !tbaa !24
  %t437 = load i64, ptr %l40, !tbaa !24
  %t440 = icmp slt i64 %t436, %t437
  %t442 = xor i1 %t440, true
  br i1 %t442, label %bb126, label %bb127
bb126:
  call void @__olang_scope_close(ptr %s26)
  br label %bb143
bb127:
  br label %bb128
bb128:
  %t444 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t444, ptr %l251, !tbaa !27
  %t445 = load i64, ptr %l39, !tbaa !24
  %t447 = getelementptr { i64, ptr }, ptr %l251, i32 0, i32 1
  %t448 = load ptr, ptr %t447, !tbaa !27
  %t449 = getelementptr ptr, ptr %t448, i64 %t445
  %t450 = load ptr, ptr %t449, !tbaa !39
  store ptr %t450, ptr %l41, !tbaa !29
  %t452 = load ptr, ptr %l41, !tbaa !29
  %t454 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %s25, ptr %s26, ptr %s26, ptr %t452, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d277, i32 0, i32 1) })
  store { i64, ptr } %t454, ptr %l255
  br label %bb129
bb129:
  %t455 = load { i64, ptr }, ptr %l255, !tbaa !27
  %t457 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s26, ptr %s26, { i64, ptr } %t455, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d278, i32 0, i32 1) })
  store i1 %t457, ptr %l257
  br label %bb130
bb130:
  %t458 = load i1, ptr %l257, !tbaa !21
  br i1 %t458, label %bb131, label %bb132
bb131:
  store %olang.scope zeroinitializer, ptr %s27
  %t459 = load ptr, ptr %l36, !tbaa !29
  store ptr %t459, ptr %l258, !tbaa !29
  %t460 = call ptr @__olang_scope_hold(ptr %v0)
  %t461 = ptrtoint ptr %t460 to i64
  store i64 %t461, ptr %l259, !tbaa !24
  %t462 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t462, label %bb133, label %bb134
bb132:
  br label %bb141
bb133:
  %t464 = call ptr @__olang_region_make(ptr %v0)
  %t465 = ptrtoint ptr %t464 to i64
  store i64 %t465, ptr %l259, !tbaa !24
  br label %bb134
bb134:
  %t466 = load ptr, ptr %l41, !tbaa !29
  %t467 = load i64, ptr %l259
  %t468 = inttoptr i64 %t467 to ptr
  %t470 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %s25, ptr %s27, ptr %t468, ptr %t466, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d279, i32 0, i32 1) })
  store { i64, ptr } %t470, ptr %l262
  br label %bb135
bb135:
  %t471 = load { i64, ptr }, ptr %l262, !tbaa !27
  %t472 = load i64, ptr %l259
  %t473 = inttoptr i64 %t472 to ptr
  %t474 = extractvalue { i64, ptr } %t471, 0
  %t475 = extractvalue { i64, ptr } %t471, 1
  %t476 = mul i64 %t474, 1
  %t477 = call ptr @__olang_held_alloc(ptr %t473, i64 %t476)
  call void @llvm.memcpy.p0.p0.i64(ptr %t477, ptr %t475, i64 %t476, i1 false)
  %t478 = insertvalue { i64, ptr } undef, i64 %t474, 0
  %t479 = insertvalue { i64, ptr } %t478, ptr %t477, 1
  %t480 = load ptr, ptr %l258, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t480, { i64, ptr } %t479)
  br label %bb136
bb136:
  %t482 = load ptr, ptr %l37, !tbaa !29
  store ptr %t482, ptr %l264, !tbaa !29
  %t483 = call ptr @__olang_scope_hold(ptr %v0)
  %t484 = ptrtoint ptr %t483 to i64
  store i64 %t484, ptr %l265, !tbaa !24
  %t485 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t485, label %bb137, label %bb138
bb137:
  %t487 = call ptr @__olang_region_make(ptr %v0)
  %t488 = ptrtoint ptr %t487 to i64
  store i64 %t488, ptr %l265, !tbaa !24
  br label %bb138
bb138:
  %t489 = load ptr, ptr %l41, !tbaa !29
  %t490 = load i64, ptr %l265
  %t491 = inttoptr i64 %t490 to ptr
  %t493 = call { i64, ptr } @compiler_2fbindgen_2etypeOf(ptr %s25, ptr %t491, ptr %t489)
  store { i64, ptr } %t493, ptr %l268
  br label %bb139
bb139:
  %t494 = load { i64, ptr }, ptr %l268, !tbaa !27
  %t495 = load i64, ptr %l265
  %t496 = inttoptr i64 %t495 to ptr
  %t497 = extractvalue { i64, ptr } %t494, 0
  %t498 = extractvalue { i64, ptr } %t494, 1
  %t499 = mul i64 %t497, 1
  %t500 = call ptr @__olang_held_alloc(ptr %t496, i64 %t499)
  call void @llvm.memcpy.p0.p0.i64(ptr %t500, ptr %t498, i64 %t499, i1 false)
  %t501 = insertvalue { i64, ptr } undef, i64 %t497, 0
  %t502 = insertvalue { i64, ptr } %t501, ptr %t500, 1
  %t503 = load ptr, ptr %l264, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t503, { i64, ptr } %t502)
  br label %bb140
bb140:
  call void @__olang_scope_close(ptr %s27)
  br label %bb141
bb141:
  call void @__olang_scope_close(ptr %s26)
  br label %bb142
bb142:
  %t505 = load i64, ptr %l39, !tbaa !24
  %t508 = add i64 %t505, 1
  store i64 %t508, ptr %l39, !tbaa !24
  br label %bb125
bb143:
  call void @__olang_scope_close(ptr %s25)
  %t510 = load ptr, ptr %l6, !tbaa !29
  %t512 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %s1, ptr %s24, ptr %s24, ptr %t510, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d280, i32 0, i32 1) })
  store { i64, ptr } %t512, ptr %l274
  br label %bb144
bb144:
  %t513 = load { i64, ptr }, ptr %l274, !tbaa !27
  %t515 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s24, ptr %s24, { i64, ptr } %t513, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d281, i32 0, i32 1) })
  store i1 %t515, ptr %l276
  br label %bb145
bb145:
  %t516 = load i1, ptr %l276, !tbaa !21
  br i1 %t516, label %bb146, label %bb147
bb146:
  store i1 true, ptr %l277, !tbaa !21
  br label %bb149
bb147:
  %t517 = load ptr, ptr %l6, !tbaa !29
  %t519 = call i1 @compiler_2fbindgen_2eflag(ptr %s1, ptr %s24, ptr %t517, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d282, i32 0, i32 1) })
  store i1 %t519, ptr %l279
  br label %bb148
bb148:
  %t520 = load i1, ptr %l279, !tbaa !21
  store i1 %t520, ptr %l277, !tbaa !21
  br label %bb149
bb149:
  %t521 = load i1, ptr %l277, !tbaa !21
  store i1 %t521, ptr %l42, !tbaa !21
  %t522 = load i64, ptr %l8, !tbaa !24
  %t524 = icmp eq i64 %t522, 1
  br i1 %t524, label %bb150, label %bb151
bb150:
  %t526 = load i1, ptr %l42, !tbaa !21
  store i1 %t526, ptr %l282, !tbaa !21
  br label %bb152
bb151:
  store i1 false, ptr %l282, !tbaa !21
  br label %bb152
bb152:
  %t528 = load i1, ptr %l282, !tbaa !21
  br i1 %t528, label %bb153, label %bb154
bb153:
  %t529 = load ptr, ptr %l0, !tbaa !29
  %t531 = getelementptr %"compiler/bindgen:gen", ptr %t529, i32 0, i32 25
  %t532 = load ptr, ptr %lp15
  %t533 = load { i64, ptr }, ptr %t532, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v0, ptr %t531, { i64, ptr } %t533, i64 0)
  br label %bb155
bb154:
  br label %bb156
bb155:
  br label %bb156
bb156:
  %t536 = load ptr, ptr %l6, !tbaa !29
  %t538 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %s1, ptr %s24, ptr %s24, ptr %t536, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d283, i32 0, i32 1) })
  store { i64, ptr } %t538, ptr %l288
  br label %bb157
bb157:
  %t539 = load { i64, ptr }, ptr %l288, !tbaa !27
  store { i64, ptr } %t539, ptr %l43, !tbaa !27
  %t540 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t542 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s24, ptr %s24, { i64, ptr } %t540, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d284, i32 0, i32 1) })
  store i1 %t542, ptr %l290
  br label %bb158
bb158:
  %t543 = load i1, ptr %l290, !tbaa !21
  br i1 %t543, label %bb159, label %bb160
bb159:
  store i1 true, ptr %l291, !tbaa !21
  br label %bb162
bb160:
  %t544 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t545 = load ptr, ptr %lp15
  %t546 = load { i64, ptr }, ptr %t545, !tbaa !27
  %t549 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s24, ptr %v0, { i64, ptr } %t544, { i64, ptr } %t546)
  store i1 %t549, ptr %l294
  br label %bb161
bb161:
  %t550 = load i1, ptr %l294, !tbaa !21
  store i1 %t550, ptr %l291, !tbaa !21
  br label %bb162
bb162:
  %t551 = load i1, ptr %l291, !tbaa !21
  br i1 %t551, label %bb163, label %bb164
bb163:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d285, i32 0, i32 1) }, ptr %l295, !tbaa !27
  br label %bb165
bb164:
  %t552 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t552, ptr %l295, !tbaa !27
  br label %bb165
bb165:
  %t554 = load { i64, ptr }, ptr %l295, !tbaa !27
  %t555 = extractvalue { i64, ptr } %t554, 1
  %t556 = extractvalue { i64, ptr } %t554, 0
  %t557 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t556)
  call void @olang_textcopy(ptr %t557, ptr %t555, i64 %t556)
  %t558 = insertvalue { i64, ptr } undef, i64 %t556, 0
  %t559 = insertvalue { i64, ptr } %t558, ptr %t557, 1
  store { i64, ptr } %t559, ptr %l44, !tbaa !27
  %t562 = load ptr, ptr %l0, !tbaa !29
  %t564 = getelementptr %"compiler/bindgen:gen", ptr %t562, i32 0, i32 9
  store ptr %t564, ptr %l300, !tbaa !29
  %t565 = load ptr, ptr %lp15
  %t566 = load { i64, ptr }, ptr %t565, !tbaa !27
  store { i64, ptr } %t566, ptr %l301, !tbaa !27
  %t567 = call ptr @__olang_scope_hold(ptr %v0)
  %t568 = ptrtoint ptr %t567 to i64
  store i64 %t568, ptr %l302, !tbaa !24
  %t569 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3acFunc_2e1
  br i1 %t569, label %bb166, label %bb167
bb166:
  %t571 = call ptr @__olang_region_make(ptr %v0)
  %t572 = ptrtoint ptr %t571 to i64
  store i64 %t572, ptr %l302, !tbaa !24
  br label %bb167
bb167:
  %t573 = load ptr, ptr %l6, !tbaa !29
  %t574 = load i64, ptr %l302
  %t575 = inttoptr i64 %t574 to ptr
  %t577 = call { i64, ptr } @compiler_2fbindgen_2etypeOf(ptr %s1, ptr %t575, ptr %t573)
  store { i64, ptr } %t577, ptr %l305
  br label %bb168
bb168:
  %t578 = load { i64, ptr }, ptr %l305, !tbaa !27
  %t579 = load i64, ptr %l302
  %t580 = inttoptr i64 %t579 to ptr
  %t581 = extractvalue { i64, ptr } %t578, 0
  %t582 = extractvalue { i64, ptr } %t578, 1
  %t583 = mul i64 %t581, 1
  %t584 = call ptr @__olang_held_alloc(ptr %t580, i64 %t583)
  call void @llvm.memcpy.p0.p0.i64(ptr %t584, ptr %t582, i64 %t583, i1 false)
  %t585 = insertvalue { i64, ptr } undef, i64 %t581, 0
  %t586 = insertvalue { i64, ptr } %t585, ptr %t584, 1
  store { i64, ptr } %t586, ptr %l306, !tbaa !27
  %t587 = call ptr @__olang_scope_hold(ptr %v0)
  %t588 = ptrtoint ptr %t587 to i64
  store i64 %t588, ptr %l307, !tbaa !24
  %t589 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3acFunc_2e2
  br i1 %t589, label %bb169, label %bb170
bb169:
  %t591 = call ptr @__olang_region_make(ptr %v0)
  %t592 = ptrtoint ptr %t591 to i64
  store i64 %t592, ptr %l307, !tbaa !24
  br label %bb170
bb170:
  %t593 = load ptr, ptr %l36, !tbaa !29
  %t594 = load i64, ptr %l307
  %t595 = inttoptr i64 %t594 to ptr
  %t597 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v0, ptr %t595, ptr %t593)
  store { i64, ptr } %t597, ptr %l310
  br label %bb171
bb171:
  %t598 = call ptr @__olang_scope_hold(ptr %v0)
  %t599 = ptrtoint ptr %t598 to i64
  store i64 %t599, ptr %l311, !tbaa !24
  %t600 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3acFunc_2e3
  br i1 %t600, label %bb172, label %bb173
bb172:
  %t602 = call ptr @__olang_region_make(ptr %v0)
  %t603 = ptrtoint ptr %t602 to i64
  store i64 %t603, ptr %l311, !tbaa !24
  br label %bb173
bb173:
  %t604 = load ptr, ptr %l37, !tbaa !29
  %t605 = load i64, ptr %l311
  %t606 = inttoptr i64 %t605 to ptr
  %t608 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v0, ptr %t606, ptr %t604)
  store { i64, ptr } %t608, ptr %l314
  br label %bb174
bb174:
  %t609 = load i1, ptr %l42, !tbaa !21
  %t610 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t611 = load { i64, ptr }, ptr %l301, !tbaa !27
  %t612 = load { i64, ptr }, ptr %l306, !tbaa !27
  %t613 = load { i64, ptr }, ptr %l310, !tbaa !27
  %t614 = load { i64, ptr }, ptr %l314, !tbaa !27
  %t617 = call %"compiler/bindgen:cFunc" @compiler_2fbindgen_3acFunc_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t611, { i64, ptr } %t612, { i64, ptr } %t613, { i64, ptr } %t614, i1 %t609, { i64, ptr } %t610)
  store %"compiler/bindgen:cFunc" %t617, ptr %l317
  br label %bb175
bb175:
  %t618 = load ptr, ptr %l300, !tbaa !29
  %t619 = load %"compiler/bindgen:cFunc", ptr %l317
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acFunc_3e_2ePush_3ccompiler_2fbindgen_3acFunc_3e(ptr %v0, ptr %v0, ptr %t618, %"compiler/bindgen:cFunc" %t619)
  br label %bb176
bb176:
  call void @__olang_scope_close(ptr %s24)
  call void @__olang_scope_close(ptr %s2)
  br label %bb198
bb177:
  %t620 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t622 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t620, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d286, i32 0, i32 1) })
  store i1 %t622, ptr %l319
  br label %bb178
bb178:
  %t623 = load i1, ptr %l319, !tbaa !21
  br i1 %t623, label %bb179, label %bb180
bb179:
  %t624 = load ptr, ptr %l0, !tbaa !29
  %t625 = load i64, ptr %l8, !tbaa !24
  %t628 = call i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ewanted(ptr %v0, ptr %t624, i64 %t625)
  store i1 %t628, ptr %l323
  br label %bb181
bb180:
  store i1 false, ptr %l320, !tbaa !21
  br label %bb182
bb181:
  %t629 = load i1, ptr %l323, !tbaa !21
  store i1 %t629, ptr %l320, !tbaa !21
  br label %bb182
bb182:
  %t630 = load i1, ptr %l320, !tbaa !21
  br i1 %t630, label %bb183, label %bb184
bb183:
  %t631 = load ptr, ptr %lp15
  %t632 = load { i64, ptr }, ptr %t631, !tbaa !27
  %t634 = call i1 @compiler_2fbindgen_2eusable(ptr %v0, { i64, ptr } %t632)
  store i1 %t634, ptr %l326
  br label %bb185
bb184:
  store i1 false, ptr %l324, !tbaa !21
  br label %bb186
bb185:
  %t635 = load i1, ptr %l326, !tbaa !21
  store i1 %t635, ptr %l324, !tbaa !21
  br label %bb186
bb186:
  %t636 = load i1, ptr %l324, !tbaa !21
  br i1 %t636, label %bb187, label %bb188
bb187:
  %t637 = load ptr, ptr %l6, !tbaa !29
  %t639 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %s1, ptr %s2, ptr %s2, ptr %t637, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d287, i32 0, i32 1) })
  store { i64, ptr } %t639, ptr %l329
  br label %bb189
bb188:
  store i1 false, ptr %l327, !tbaa !21
  br label %bb191
bb189:
  %t640 = load { i64, ptr }, ptr %l329, !tbaa !27
  %t642 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t640, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d288, i32 0, i32 1) })
  store i1 %t642, ptr %l331
  br label %bb190
bb190:
  %t643 = load i1, ptr %l331, !tbaa !21
  %t644 = xor i1 %t643, true
  store i1 %t644, ptr %l327, !tbaa !21
  br label %bb191
bb191:
  %t646 = load i1, ptr %l327, !tbaa !21
  br i1 %t646, label %bb192, label %bb193
bb192:
  %t647 = load ptr, ptr %l0, !tbaa !29
  %t649 = getelementptr %"compiler/bindgen:gen", ptr %t647, i32 0, i32 19
  store ptr %t649, ptr %l334, !tbaa !29
  %t650 = call ptr @__olang_scope_hold(ptr %v0)
  %t651 = ptrtoint ptr %t650 to i64
  store i64 %t651, ptr %l335, !tbaa !24
  %t652 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t652, label %bb194, label %bb195
bb193:
  br label %bb197
bb194:
  %t654 = call ptr @__olang_region_make(ptr %v0)
  %t655 = ptrtoint ptr %t654 to i64
  store i64 %t655, ptr %l335, !tbaa !24
  br label %bb195
bb195:
  %t656 = load ptr, ptr %lp15
  %t657 = load { i64, ptr }, ptr %t656, !tbaa !27
  %t659 = extractvalue { i64, ptr } %t657, 1
  %t660 = extractvalue { i64, ptr } %t657, 0
  %t661 = extractvalue { i64, ptr } { i64 56, ptr getelementptr inbounds (<{ i64, [56 x i8] }>, ptr @.d289, i32 0, i32 1) }, 1
  %t662 = extractvalue { i64, ptr } { i64 56, ptr getelementptr inbounds (<{ i64, [56 x i8] }>, ptr @.d289, i32 0, i32 1) }, 0
  %t663 = add i64 %t660, %t662
  %t664 = load i64, ptr %l335
  %t665 = inttoptr i64 %t664 to ptr
  %t666 = call ptr @__olang_held_alloc(ptr %t665, i64 %t663)
  call void @olang_textcopy(ptr %t666, ptr %t659, i64 %t660)
  %t667 = getelementptr i8, ptr %t666, i64 %t660
  call void @olang_textcopy(ptr %t667, ptr %t661, i64 %t662)
  %t668 = insertvalue { i64, ptr } undef, i64 %t663, 0
  %t669 = insertvalue { i64, ptr } %t668, ptr %t666, 1
  %t671 = load ptr, ptr %l334, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t671, { i64, ptr } %t669)
  br label %bb196
bb196:
  br label %bb197
bb197:
  call void @__olang_scope_close(ptr %s2)
  br label %bb198
bb198:
  %t673 = load i64, ptr %l4, !tbaa !24
  %t676 = add i64 %t673, 1
  store i64 %t676, ptr %l4, !tbaa !24
  br label %bb2
bb199:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2esizes(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"compiler/bindgen:cFunc"
  %l9 = alloca i64
  %l10 = alloca %"compiler/bindgen:ctype"
  %l12 = alloca i1
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca %"std/prelude/text:StringBuilder"
  %l24 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l33 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca ptr
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l47 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l55 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca ptr
  %l59 = alloca { i64, ptr }
  %l60 = alloca i64
  %l61 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l62 = alloca { i64, ptr }
  %l63 = alloca i64
  %l64 = alloca i64
  %l67 = alloca i64
  %l68 = alloca i64
  %l70 = alloca i64
  %l71 = alloca i64
  %l73 = alloca i64
  %l74 = alloca i64
  %l75 = alloca i64
  %l76 = alloca i64
  %l77 = alloca i64
  %l80 = alloca i64
  %l84 = alloca i64
  %l86 = alloca i64
  %l91 = alloca %"compiler/bindgen:cFunc"
  %l93 = alloca { i64, ptr }
  %l94 = alloca i64
  %l95 = alloca { i64, ptr }
  %l98 = alloca i64
  %l102 = alloca %"compiler/bindgen:ctype"
  %l107 = alloca ptr
  %l111 = alloca %"compiler/bindgen:ctype"
  %l113 = alloca %"compiler/bindgen:ctype"
  %l116 = alloca i1
  %l120 = alloca %"compiler/bindgen:ctype"
  %l123 = alloca ptr
  %l127 = alloca %"compiler/bindgen:ctype"
  %l129 = alloca i64
  %l133 = alloca ptr
  %l139 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l142 = alloca i64
  %l146 = alloca i64
  %l149 = alloca i64
  %l170 = alloca ptr
  %l174 = alloca i1
  %l179 = alloca i1
  %l183 = alloca ptr
  %l186 = alloca i1
  %l187 = alloca i1
  %l190 = alloca i1
  %l197 = alloca i64
  %l199 = alloca %"std/prelude/text:StringBuilder"
  %l205 = alloca i64
  %l207 = alloca i64
  %l213 = alloca i64
  %l214 = alloca ptr
  %l215 = alloca i64
  %l216 = alloca i64
  %l219 = alloca { i64, ptr }
  %l220 = alloca i64
  %l223 = alloca { i64, ptr }
  %l230 = alloca i64
  %l232 = alloca i64
  %l238 = alloca i64
  %l241 = alloca i1
  %l243 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l244 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l249 = alloca i32
  %l251 = alloca i1
  %l255 = alloca ptr
  %l259 = alloca i64
  %l263 = alloca i64
  %l266 = alloca i64
  %l287 = alloca ptr
  %l293 = alloca ptr
  %l299 = alloca ptr
  %l304 = alloca { i64, ptr }
  %l307 = alloca { i64, ptr }
  %l312 = alloca ptr
  %l313 = alloca { i64, ptr }
  %l314 = alloca { i64, ptr }
  %l317 = alloca { i64, ptr }
  %l320 = alloca { i64, ptr }
  %l334 = alloca i64
  %l336 = alloca i64
  %l342 = alloca i64
  %l346 = alloca ptr
  %l349 = alloca i1
  %l352 = alloca i1
  %l354 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l355 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l363 = alloca ptr
  %l367 = alloca i64
  %l371 = alloca i64
  %l374 = alloca i64
  %l395 = alloca ptr
  %l398 = alloca ptr
  %l399 = alloca i64
  %l400 = alloca i64
  %l401 = alloca i64
  %l402 = alloca i64
  %l405 = alloca { i64, ptr }
  %l408 = alloca { i64, ptr }
  %l417 = alloca { i64, ptr }
  %l419 = alloca { i64, ptr }
  %l422 = alloca i32
  %l424 = alloca i1
  %l428 = alloca i32
  %l430 = alloca ptr
  %l435 = alloca ptr
  %l436 = alloca i32
  %l439 = alloca { i64, ptr }
  %l447 = alloca { i64, ptr }
  %l451 = alloca { i64, ptr }
  %l453 = alloca { i64, ptr }
  %l455 = alloca i1
  %l456 = alloca i1
  %l458 = alloca i1
  %l464 = alloca { i64, ptr }
  %l466 = alloca i1
  %l467 = alloca i1
  %l469 = alloca i1
  %l475 = alloca { i64, ptr }
  %l477 = alloca i1
  %l479 = alloca i1
  %l481 = alloca i1
  %l483 = alloca i64
  %l485 = alloca i64
  %l486 = alloca i64
  %l490 = alloca { i64, ptr }
  %l491 = alloca i64
  %l492 = alloca i32
  %l493 = alloca i64
  %l494 = alloca i32
  %l497 = alloca i1
  %l498 = alloca i64
  %l500 = alloca i64
  %l502 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l504 = alloca { i64, ptr }
  %l512 = alloca { i64, ptr }
  %l516 = alloca { i64, ptr }
  %l517 = alloca ptr
  %l518 = alloca i64
  %l519 = alloca { i64, ptr }
  %l520 = alloca i64
  %l521 = alloca i32
  %l522 = alloca i64
  %l523 = alloca i32
  %l528 = alloca i64
  %l532 = alloca i64
  %l534 = alloca i64
  %l538 = alloca ptr
  %l543 = alloca i64
  %l545 = alloca i64
  %l549 = alloca ptr
  %l557 = alloca i64
  %l561 = alloca i64
  %l564 = alloca i64
  %l586 = alloca ptr
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s38 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %s44 = alloca %olang.scope
  %s45 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/bindgen:gen", ptr %t1, i32 0, i32 9
  store ptr %t3, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load i64, ptr %l6, !tbaa !24
  store i64 %t5, ptr %l84, !tbaa !24
  %t6 = load ptr, ptr %l5, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acFunc_3e_2eLen_3ccompiler_2fbindgen_3acFunc_3e(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l86
  br label %bb2
bb2:
  %t9 = load i64, ptr %l84, !tbaa !24
  %t10 = load i64, ptr %l86, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb26
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l5, !tbaa !29
  %t16 = load i64, ptr %l6, !tbaa !24
  %t19 = call %"compiler/bindgen:cFunc" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acFunc_3e_2eAt_3ccompiler_2fbindgen_3acFunc_3e(ptr %v0, ptr %v0, ptr %t15, i64 %t16)
  store %"compiler/bindgen:cFunc" %t19, ptr %l91
  br label %bb6
bb6:
  %t20 = load %"compiler/bindgen:cFunc", ptr %l91
  store %"compiler/bindgen:cFunc" %t20, ptr %l7
  %t21 = getelementptr %"compiler/bindgen:cFunc", ptr %l7, i32 0, i32 1
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  %t24 = call { i64, ptr } @compiler_2fbindgen_2enoReturnOf(ptr %v0, ptr %s2, { i64, ptr } %t22)
  store { i64, ptr } %t24, ptr %l93
  br label %bb7
bb7:
  %t25 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t25, 0
  store i64 %t26, ptr %l94, !tbaa !24
  %t27 = load i64, ptr %l94, !tbaa !24
  %t28 = mul i64 %t27, 1
  %t29 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t28)
  %t30 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t29, 1
  store { i64, ptr } %t31, ptr %l95, !tbaa !27
  %t32 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = load i64, ptr %l94, !tbaa !24
  %t37 = mul i64 %t36, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t33, ptr %t35, i64 %t37, i1 false)
  %t38 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t43 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eparseType(ptr %v0, ptr %s2, ptr %t39, { i64, ptr } %t38, i64 0)
  store i64 %t43, ptr %l98
  br label %bb8
bb8:
  %t44 = load i64, ptr %l98, !tbaa !24
  store i64 %t44, ptr %l9, !tbaa !24
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/bindgen:gen", ptr %t45, i32 0, i32 17
  %t48 = load i64, ptr %l9, !tbaa !24
  %t51 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %s2, ptr %t47, i64 %t48)
  store %"compiler/bindgen:ctype" %t51, ptr %l102
  br label %bb9
bb9:
  %t52 = getelementptr %"compiler/bindgen:ctype", ptr %l102, i32 0, i32 0
  %t53 = load i32, ptr %t52, !range !{i32 0, i32 7}
  %t55 = trunc i64 5 to i32
  %t56 = icmp eq i32 %t53, %t55
  %t58 = xor i1 %t56, true
  br i1 %t58, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb11:
  br label %bb12
bb12:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/bindgen:gen", ptr %t60, i32 0, i32 17
  store ptr %t62, ptr %l107, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/bindgen:gen", ptr %t63, i32 0, i32 17
  %t66 = load i64, ptr %l9, !tbaa !24
  %t69 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %s2, ptr %t65, i64 %t66)
  store %"compiler/bindgen:ctype" %t69, ptr %l111
  br label %bb13
bb13:
  %t70 = getelementptr %"compiler/bindgen:ctype", ptr %l111, i32 0, i32 2
  %t71 = load i64, ptr %t70, !tbaa !24
  %t72 = load ptr, ptr %l107, !tbaa !29
  %t74 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v0, ptr %t72, i64 %t71)
  store %"compiler/bindgen:ctype" %t74, ptr %l113
  br label %bb14
bb14:
  %t75 = load %"compiler/bindgen:ctype", ptr %l113
  store %"compiler/bindgen:ctype" %t75, ptr %l10
  %t76 = getelementptr %"compiler/bindgen:ctype", ptr %l10, i32 0, i32 0
  %t77 = load i32, ptr %t76, !range !{i32 0, i32 7}
  %t79 = trunc i64 3 to i32
  %t80 = icmp eq i32 %t77, %t79
  br i1 %t80, label %bb15, label %bb16
bb15:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/bindgen:gen", ptr %t82, i32 0, i32 17
  %t85 = getelementptr %"compiler/bindgen:ctype", ptr %l10, i32 0, i32 2
  %t86 = load i64, ptr %t85, !tbaa !24
  %t89 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %s2, ptr %t84, i64 %t86)
  store %"compiler/bindgen:ctype" %t89, ptr %l120
  br label %bb17
bb16:
  store i1 false, ptr %l116, !tbaa !21
  br label %bb18
bb17:
  %t90 = getelementptr %"compiler/bindgen:ctype", ptr %l120, i32 0, i32 0
  %t91 = load i32, ptr %t90, !range !{i32 0, i32 7}
  %t93 = trunc i64 2 to i32
  %t94 = icmp eq i32 %t91, %t93
  store i1 %t94, ptr %l116, !tbaa !21
  br label %bb18
bb18:
  %t96 = load i1, ptr %l116, !tbaa !21
  br i1 %t96, label %bb19, label %bb20
bb19:
  %t97 = load ptr, ptr %l0, !tbaa !29
  store ptr %t97, ptr %l123, !tbaa !29
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/bindgen:gen", ptr %t98, i32 0, i32 17
  %t101 = getelementptr %"compiler/bindgen:ctype", ptr %l10, i32 0, i32 2
  %t102 = load i64, ptr %t101, !tbaa !24
  %t105 = call %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v0, ptr %t100, i64 %t102)
  store %"compiler/bindgen:ctype" %t105, ptr %l127
  br label %bb21
bb20:
  br label %bb24
bb21:
  %t106 = getelementptr %"compiler/bindgen:ctype", ptr %l127, i32 0, i32 1
  %t107 = load { i64, ptr }, ptr %t106, !tbaa !27
  %t108 = load ptr, ptr %l123, !tbaa !29
  %t110 = call i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2erecordAt(ptr %v0, ptr %v0, ptr %t108, { i64, ptr } %t107)
  store i64 %t110, ptr %l129
  br label %bb22
bb22:
  %t111 = load i64, ptr %l129, !tbaa !24
  store i1 true, ptr %l12, !tbaa !21
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/bindgen:gen", ptr %t112, i32 0, i32 6
  %t118 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRefMu_Hc21bcd245b67ffb6ee3e145838fcf2cf(ptr %v0, ptr %v0, ptr %t114, i64 %t111)
  store ptr %t118, ptr %l133
  br label %bb23
bb23:
  %t119 = load ptr, ptr %l133, !tbaa !29
  %t121 = load i1, ptr %l12, !tbaa !21
  %t124 = getelementptr %"compiler/bindgen:record", ptr %t119, i32 0, i32 10
  store i1 %t121, ptr %t124, !tbaa !21
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb25:
  %t125 = load i64, ptr %l6, !tbaa !24
  %t128 = add i64 %t125, 1
  store i64 %t128, ptr %l6, !tbaa !24
  br label %bb1
bb26:
  %t130 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t130, ptr %l139
  br label %bb27
bb27:
  %t131 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l139
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t131, ptr %l14
  store i64 0, ptr %l15, !tbaa !24
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/bindgen:gen", ptr %t132, i32 0, i32 6
  %t136 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eLen_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %t134)
  store i64 %t136, ptr %l142
  br label %bb28
bb28:
  %t137 = load i64, ptr %l142, !tbaa !24
  store i64 %t137, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t138 = load i64, ptr %l16, !tbaa !24
  %t139 = load i64, ptr %l15, !tbaa !24
  %t142 = icmp sgt i64 %t138, %t139
  br i1 %t142, label %bb29, label %bb30
bb29:
  %t144 = load i64, ptr %l17, !tbaa !24
  %t146 = icmp sgt i64 %t144, 0
  br i1 %t146, label %bb31, label %bb32
bb30:
  store i64 0, ptr %l146, !tbaa !24
  br label %bb34
bb31:
  %t148 = load i64, ptr %l16, !tbaa !24
  %t149 = load i64, ptr %l15, !tbaa !24
  %t152 = sub i64 %t148, %t149
  %t153 = load i64, ptr %l17, !tbaa !24
  %t156 = add i64 %t152, %t153
  %t158 = sub i64 %t156, 1
  %t159 = load i64, ptr %l17, !tbaa !24
  %t162 = sdiv i64 %t158, %t159
  store i64 %t162, ptr %l149, !tbaa !24
  br label %bb33
bb32:
  store i64 0, ptr %l149, !tbaa !24
  br label %bb33
bb33:
  %t164 = load i64, ptr %l149, !tbaa !24
  store i64 %t164, ptr %l146, !tbaa !24
  br label %bb34
bb34:
  %t165 = load i64, ptr %l146, !tbaa !24
  store i64 %t165, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb35
bb35:
  store %olang.scope zeroinitializer, ptr %s7
  %t166 = load i64, ptr %l19, !tbaa !24
  %t167 = load i64, ptr %l18, !tbaa !24
  %t170 = icmp slt i64 %t166, %t167
  %t172 = xor i1 %t170, true
  br i1 %t172, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s7)
  br label %bb61
bb37:
  br label %bb38
bb38:
  %t174 = load i64, ptr %l15, !tbaa !24
  %t175 = load i64, ptr %l19, !tbaa !24
  %t176 = load i64, ptr %l17, !tbaa !24
  %t179 = mul i64 %t175, %t176
  %t182 = add i64 %t174, %t179
  store i64 %t182, ptr %l20, !tbaa !24
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = getelementptr %"compiler/bindgen:gen", ptr %t184, i32 0, i32 6
  %t187 = load i64, ptr %l20, !tbaa !24
  %t190 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRef_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %v0, ptr %t186, i64 %t187)
  store ptr %t190, ptr %l170
  br label %bb39
bb39:
  %t191 = load ptr, ptr %l170, !tbaa !29
  store ptr %t191, ptr %l21, !tbaa !29
  %t192 = load ptr, ptr %l21, !tbaa !29
  %t194 = getelementptr %"compiler/bindgen:record", ptr %t192, i32 0, i32 2
  %t195 = load i1, ptr %t194, !tbaa !21
  %t197 = xor i1 %t195, true
  br i1 %t197, label %bb40, label %bb41
bb40:
  store i1 true, ptr %l174, !tbaa !21
  br label %bb42
bb41:
  %t199 = load ptr, ptr %l21, !tbaa !29
  %t201 = getelementptr %"compiler/bindgen:record", ptr %t199, i32 0, i32 10
  %t202 = load i1, ptr %t201, !tbaa !21
  store i1 %t202, ptr %l174, !tbaa !21
  br label %bb42
bb42:
  %t204 = load i1, ptr %l174, !tbaa !21
  br i1 %t204, label %bb43, label %bb44
bb43:
  call void @__olang_scope_close(ptr %s7)
  br label %bb60
bb44:
  br label %bb45
bb45:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t206 = load i64, ptr %l20, !tbaa !24
  %t209 = call i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eplain(ptr %v0, ptr %t205, i64 %t206)
  store i1 %t209, ptr %l179
  br label %bb46
bb46:
  %t210 = load i1, ptr %l179, !tbaa !21
  br i1 %t210, label %bb47, label %bb48
bb47:
  call void @__olang_scope_close(ptr %s7)
  br label %bb60
bb48:
  br label %bb49
bb49:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr %"compiler/bindgen:gen", ptr %t211, i32 0, i32 6
  %t214 = load i64, ptr %l20, !tbaa !24
  %t217 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRef_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %v0, ptr %t213, i64 %t214)
  store ptr %t217, ptr %l183
  br label %bb50
bb50:
  %t218 = load ptr, ptr %l183, !tbaa !29
  store ptr %t218, ptr %l22, !tbaa !29
  %t219 = load ptr, ptr %l22, !tbaa !29
  %t221 = getelementptr %"compiler/bindgen:record", ptr %t219, i32 0, i32 0
  %t222 = load { i64, ptr }, ptr %t221, !tbaa !27
  %t224 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s7, { i64, ptr } %t222, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d290, i32 0, i32 1) })
  store i1 %t224, ptr %l186
  br label %bb51
bb51:
  %t225 = load i1, ptr %l186, !tbaa !21
  br i1 %t225, label %bb52, label %bb53
bb52:
  %t226 = load ptr, ptr %l22, !tbaa !29
  %t228 = getelementptr %"compiler/bindgen:record", ptr %t226, i32 0, i32 11
  %t229 = load { i64, ptr }, ptr %t228, !tbaa !27
  %t231 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s7, { i64, ptr } %t229, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d291, i32 0, i32 1) })
  store i1 %t231, ptr %l190
  br label %bb54
bb53:
  store i1 false, ptr %l187, !tbaa !21
  br label %bb55
bb54:
  %t232 = load i1, ptr %l190, !tbaa !21
  store i1 %t232, ptr %l187, !tbaa !21
  br label %bb55
bb55:
  %t233 = load i1, ptr %l187, !tbaa !21
  br i1 %t233, label %bb56, label %bb57
bb56:
  call void @__olang_scope_close(ptr %s7)
  br label %bb60
bb57:
  br label %bb58
bb58:
  %t234 = load i64, ptr %l20, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l14, i64 %t234)
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s7)
  br label %bb60
bb60:
  %t237 = load i64, ptr %l19, !tbaa !24
  %t240 = add i64 %t237, 1
  store i64 %t240, ptr %l19, !tbaa !24
  br label %bb35
bb61:
  %t243 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l14)
  store i64 %t243, ptr %l197
  br label %bb62
bb62:
  %t244 = load i64, ptr %l197, !tbaa !24
  %t245 = icmp eq i64 %t244, 0
  br i1 %t245, label %bb63, label %bb64
bb63:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb64:
  br label %bb65
bb65:
  %t247 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t247, ptr %l199
  br label %bb66
bb66:
  %t248 = load %"std/prelude/text:StringBuilder", ptr %l199
  store %"std/prelude/text:StringBuilder" %t248, ptr %l23
  %t251 = extractvalue { i64, ptr } %a4, 1
  %t252 = extractvalue { i64, ptr } %a4, 0
  %t253 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d292, i32 0, i32 1) }, 1
  %t254 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d292, i32 0, i32 1) }, 0
  %t255 = add i64 %t252, %t254
  %t256 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t255)
  call void @olang_textcopy(ptr %t256, ptr %t251, i64 %t252)
  %t257 = getelementptr i8, ptr %t256, i64 %t252
  call void @olang_textcopy(ptr %t257, ptr %t253, i64 %t254)
  %t258 = insertvalue { i64, ptr } undef, i64 %t255, 0
  %t259 = insertvalue { i64, ptr } %t258, ptr %t256, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l23, { i64, ptr } %t259)
  br label %bb67
bb67:
  store ptr %l14, ptr %l24, !tbaa !29
  store i64 0, ptr %l25, !tbaa !24
  br label %bb68
bb68:
  store %olang.scope zeroinitializer, ptr %s15
  %t264 = load i64, ptr %l25, !tbaa !24
  store i64 %t264, ptr %l205, !tbaa !24
  %t265 = load ptr, ptr %l24, !tbaa !29
  %t267 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t265)
  store i64 %t267, ptr %l207
  br label %bb69
bb69:
  %t268 = load i64, ptr %l205, !tbaa !24
  %t269 = load i64, ptr %l207, !tbaa !24
  %t270 = icmp slt i64 %t268, %t269
  %t272 = xor i1 %t270, true
  br i1 %t272, label %bb70, label %bb71
bb70:
  call void @__olang_scope_close(ptr %s15)
  br label %bb78
bb71:
  br label %bb72
bb72:
  %t274 = load i64, ptr %l25, !tbaa !24
  store i64 %t274, ptr %l26, !tbaa !24
  %t276 = load ptr, ptr %l24, !tbaa !29
  %t277 = load i64, ptr %l25, !tbaa !24
  %t280 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t276, i64 %t277)
  store i64 %t280, ptr %l213
  br label %bb73
bb73:
  %t281 = load i64, ptr %l213, !tbaa !24
  store i64 %t281, ptr %l27, !tbaa !24
  store ptr %l23, ptr %l214, !tbaa !29
  %t282 = load i64, ptr %l26, !tbaa !24
  store i64 %t282, ptr %l215, !tbaa !24
  %t283 = load i64, ptr %l26, !tbaa !24
  store i64 %t283, ptr %l216, !tbaa !24
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t285 = load i64, ptr %l27, !tbaa !24
  %t288 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2espell(ptr %v0, ptr %s15, ptr %t284, i64 %t285)
  store { i64, ptr } %t288, ptr %l219
  br label %bb74
bb74:
  %t289 = load i64, ptr %l26, !tbaa !24
  store i64 %t289, ptr %l220, !tbaa !24
  %t290 = load ptr, ptr %l0, !tbaa !29
  %t291 = load i64, ptr %l27, !tbaa !24
  %t294 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2espell(ptr %v0, ptr %s15, ptr %t290, i64 %t291)
  store { i64, ptr } %t294, ptr %l223
  br label %bb75
bb75:
  %t295 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d293, i32 0, i32 1) }, 1
  %t296 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d293, i32 0, i32 1) }, 0
  %t297 = load i64, ptr %l215, !tbaa !24
  %t298 = call i64 @__olang_fmt_i64(ptr null, i64 %t297)
  %t299 = add i64 %t296, %t298
  %t300 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d294, i32 0, i32 1) }, 1
  %t301 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d294, i32 0, i32 1) }, 0
  %t302 = add i64 %t299, %t301
  %t303 = load i64, ptr %l216, !tbaa !24
  %t304 = call i64 @__olang_fmt_i64(ptr null, i64 %t303)
  %t305 = add i64 %t302, %t304
  %t306 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d295, i32 0, i32 1) }, 1
  %t307 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d295, i32 0, i32 1) }, 0
  %t308 = add i64 %t305, %t307
  %t309 = load { i64, ptr }, ptr %l219, !tbaa !27
  %t310 = extractvalue { i64, ptr } %t309, 1
  %t311 = extractvalue { i64, ptr } %t309, 0
  %t312 = add i64 %t308, %t311
  %t313 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d296, i32 0, i32 1) }, 1
  %t314 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d296, i32 0, i32 1) }, 0
  %t315 = add i64 %t312, %t314
  %t316 = load i64, ptr %l220, !tbaa !24
  %t317 = call i64 @__olang_fmt_i64(ptr null, i64 %t316)
  %t318 = add i64 %t315, %t317
  %t319 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d297, i32 0, i32 1) }, 1
  %t320 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d297, i32 0, i32 1) }, 0
  %t321 = add i64 %t318, %t320
  %t322 = load { i64, ptr }, ptr %l223, !tbaa !27
  %t323 = extractvalue { i64, ptr } %t322, 1
  %t324 = extractvalue { i64, ptr } %t322, 0
  %t325 = add i64 %t321, %t324
  %t326 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d298, i32 0, i32 1) }, 1
  %t327 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d298, i32 0, i32 1) }, 0
  %t328 = add i64 %t325, %t327
  %t329 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t328)
  call void @olang_textcopy(ptr %t329, ptr %t295, i64 %t296)
  %t330 = getelementptr i8, ptr %t329, i64 %t296
  %t331 = call i64 @__olang_fmt_i64(ptr %t330, i64 %t297)
  %t332 = getelementptr i8, ptr %t330, i64 %t298
  call void @olang_textcopy(ptr %t332, ptr %t300, i64 %t301)
  %t333 = getelementptr i8, ptr %t332, i64 %t301
  %t334 = call i64 @__olang_fmt_i64(ptr %t333, i64 %t303)
  %t335 = getelementptr i8, ptr %t333, i64 %t304
  call void @olang_textcopy(ptr %t335, ptr %t306, i64 %t307)
  %t336 = getelementptr i8, ptr %t335, i64 %t307
  call void @olang_textcopy(ptr %t336, ptr %t310, i64 %t311)
  %t337 = getelementptr i8, ptr %t336, i64 %t311
  call void @olang_textcopy(ptr %t337, ptr %t313, i64 %t314)
  %t338 = getelementptr i8, ptr %t337, i64 %t314
  %t339 = call i64 @__olang_fmt_i64(ptr %t338, i64 %t316)
  %t340 = getelementptr i8, ptr %t338, i64 %t317
  call void @olang_textcopy(ptr %t340, ptr %t319, i64 %t320)
  %t341 = getelementptr i8, ptr %t340, i64 %t320
  call void @olang_textcopy(ptr %t341, ptr %t323, i64 %t324)
  %t342 = getelementptr i8, ptr %t341, i64 %t324
  call void @olang_textcopy(ptr %t342, ptr %t326, i64 %t327)
  %t343 = insertvalue { i64, ptr } undef, i64 %t328, 0
  %t344 = insertvalue { i64, ptr } %t343, ptr %t329, 1
  %t346 = load ptr, ptr %l214, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s15, ptr %t346, { i64, ptr } %t344)
  br label %bb76
bb76:
  call void @__olang_scope_close(ptr %s15)
  br label %bb77
bb77:
  %t348 = load i64, ptr %l25, !tbaa !24
  %t351 = add i64 %t348, 1
  store i64 %t351, ptr %l25, !tbaa !24
  br label %bb68
bb78:
  store ptr %l14, ptr %l28, !tbaa !29
  store i64 0, ptr %l29, !tbaa !24
  br label %bb79
bb79:
  store %olang.scope zeroinitializer, ptr %s19
  %t354 = load i64, ptr %l29, !tbaa !24
  store i64 %t354, ptr %l230, !tbaa !24
  %t355 = load ptr, ptr %l28, !tbaa !29
  %t357 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t355)
  store i64 %t357, ptr %l232
  br label %bb80
bb80:
  %t358 = load i64, ptr %l230, !tbaa !24
  %t359 = load i64, ptr %l232, !tbaa !24
  %t360 = icmp slt i64 %t358, %t359
  %t362 = xor i1 %t360, true
  br i1 %t362, label %bb81, label %bb82
bb81:
  call void @__olang_scope_close(ptr %s19)
  br label %bb122
bb82:
  br label %bb83
bb83:
  %t364 = load i64, ptr %l29, !tbaa !24
  store i64 %t364, ptr %l30, !tbaa !24
  %t366 = load ptr, ptr %l28, !tbaa !29
  %t367 = load i64, ptr %l29, !tbaa !24
  %t370 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t366, i64 %t367)
  store i64 %t370, ptr %l238
  br label %bb84
bb84:
  %t371 = load i64, ptr %l238, !tbaa !24
  store i64 %t371, ptr %l31, !tbaa !24
  %t372 = load ptr, ptr %l0, !tbaa !29
  %t373 = load i64, ptr %l31, !tbaa !24
  %t376 = call i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ehasAnon(ptr %v0, ptr %t372, i64 %t373)
  store i1 %t376, ptr %l241
  br label %bb85
bb85:
  %t377 = load i1, ptr %l241, !tbaa !21
  %t378 = xor i1 %t377, true
  br i1 %t378, label %bb86, label %bb87
bb86:
  call void @__olang_scope_close(ptr %s19)
  br label %bb121
bb87:
  br label %bb88
bb88:
  %t380 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s19, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t380, ptr %l243
  br label %bb89
bb89:
  %t381 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l243
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t381, ptr %l32
  %t382 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s19, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t382, ptr %l244
  br label %bb90
bb90:
  %t383 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l244
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t383, ptr %l33
  %t384 = load ptr, ptr %l0, !tbaa !29
  %t385 = load i64, ptr %l31, !tbaa !24
  %t390 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eflat(ptr %v0, ptr %s19, ptr %s19, ptr %t384, i64 %t385, ptr %l32, ptr %l33)
  store i32 %t390, ptr %l249
  %t391 = icmp ne i32 %t390, 0
  br i1 %t391, label %bb92, label %ok.392, !prof !99
ok.392:
  br label %bb91
bb91:
  br label %bb94
bb92:
  %t393 = load i32, ptr %l249, !tbaa !23
  %t394 = ashr i32 %t393, 16
  %t396 = icmp eq i32 %t394, 1
  store i1 %t396, ptr %l251, !tbaa !21
  br label %bb93
bb93:
  call void @__olang_scope_close(ptr %s19)
  br label %bb121
bb94:
  %t397 = load ptr, ptr %l0, !tbaa !29
  %t399 = getelementptr %"compiler/bindgen:gen", ptr %t397, i32 0, i32 6
  %t400 = load i64, ptr %l31, !tbaa !24
  %t403 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRefMu_Hc21bcd245b67ffb6ee3e145838fcf2cf(ptr %v0, ptr %v0, ptr %t399, i64 %t400)
  store ptr %t403, ptr %l255
  br label %bb95
bb95:
  %t404 = load ptr, ptr %l255, !tbaa !29
  %t406 = getelementptr %"compiler/bindgen:record", ptr %t404, i32 0, i32 18
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t406)
  br label %bb96
bb96:
  store i64 0, ptr %l34, !tbaa !24
  %t409 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s19, ptr %l32)
  store i64 %t409, ptr %l259
  br label %bb97
bb97:
  %t410 = load i64, ptr %l259, !tbaa !24
  store i64 %t410, ptr %l35, !tbaa !24
  store i64 1, ptr %l36, !tbaa !24
  %t411 = load i64, ptr %l35, !tbaa !24
  %t412 = load i64, ptr %l34, !tbaa !24
  %t415 = icmp sgt i64 %t411, %t412
  br i1 %t415, label %bb98, label %bb99
bb98:
  %t417 = load i64, ptr %l36, !tbaa !24
  %t419 = icmp sgt i64 %t417, 0
  br i1 %t419, label %bb100, label %bb101
bb99:
  store i64 0, ptr %l263, !tbaa !24
  br label %bb103
bb100:
  %t421 = load i64, ptr %l35, !tbaa !24
  %t422 = load i64, ptr %l34, !tbaa !24
  %t425 = sub i64 %t421, %t422
  %t426 = load i64, ptr %l36, !tbaa !24
  %t429 = add i64 %t425, %t426
  %t431 = sub i64 %t429, 1
  %t432 = load i64, ptr %l36, !tbaa !24
  %t435 = sdiv i64 %t431, %t432
  store i64 %t435, ptr %l266, !tbaa !24
  br label %bb102
bb101:
  store i64 0, ptr %l266, !tbaa !24
  br label %bb102
bb102:
  %t437 = load i64, ptr %l266, !tbaa !24
  store i64 %t437, ptr %l263, !tbaa !24
  br label %bb103
bb103:
  %t438 = load i64, ptr %l263, !tbaa !24
  store i64 %t438, ptr %l37, !tbaa !24
  store i64 0, ptr %l38, !tbaa !24
  br label %bb104
bb104:
  store %olang.scope zeroinitializer, ptr %s23
  %t439 = load i64, ptr %l38, !tbaa !24
  %t440 = load i64, ptr %l37, !tbaa !24
  %t443 = icmp slt i64 %t439, %t440
  %t445 = xor i1 %t443, true
  br i1 %t445, label %bb105, label %bb106
bb105:
  call void @__olang_scope_close(ptr %s23)
  br label %bb120
bb106:
  br label %bb107
bb107:
  %t447 = load i64, ptr %l34, !tbaa !24
  %t448 = load i64, ptr %l38, !tbaa !24
  %t449 = load i64, ptr %l36, !tbaa !24
  %t452 = mul i64 %t448, %t449
  %t455 = add i64 %t447, %t452
  store i64 %t455, ptr %l39, !tbaa !24
  %t457 = load ptr, ptr %l0, !tbaa !29
  %t459 = getelementptr %"compiler/bindgen:gen", ptr %t457, i32 0, i32 6
  %t460 = load i64, ptr %l31, !tbaa !24
  %t463 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRefMu_Hc21bcd245b67ffb6ee3e145838fcf2cf(ptr %v0, ptr %v0, ptr %t459, i64 %t460)
  store ptr %t463, ptr %l287
  br label %bb108
bb108:
  %t464 = load ptr, ptr %l287, !tbaa !29
  %t466 = getelementptr %"compiler/bindgen:record", ptr %t464, i32 0, i32 18
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t466, i64 -1)
  br label %bb109
bb109:
  %t468 = load ptr, ptr %l0, !tbaa !29
  %t470 = getelementptr %"compiler/bindgen:gen", ptr %t468, i32 0, i32 6
  %t471 = load i64, ptr %l31, !tbaa !24
  %t474 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRefMu_Hc21bcd245b67ffb6ee3e145838fcf2cf(ptr %v0, ptr %v0, ptr %t470, i64 %t471)
  store ptr %t474, ptr %l293
  br label %bb110
bb110:
  %t475 = load ptr, ptr %l293, !tbaa !29
  %t477 = getelementptr %"compiler/bindgen:record", ptr %t475, i32 0, i32 18
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t477, i64 -1)
  br label %bb111
bb111:
  %t479 = load ptr, ptr %l0, !tbaa !29
  %t481 = getelementptr %"compiler/bindgen:gen", ptr %t479, i32 0, i32 6
  %t482 = load i64, ptr %l31, !tbaa !24
  %t485 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRefMu_Hc21bcd245b67ffb6ee3e145838fcf2cf(ptr %v0, ptr %v0, ptr %t481, i64 %t482)
  store ptr %t485, ptr %l299
  br label %bb112
bb112:
  %t486 = load ptr, ptr %l299, !tbaa !29
  %t488 = getelementptr %"compiler/bindgen:record", ptr %t486, i32 0, i32 18
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t488, i64 -1)
  br label %bb113
bb113:
  %t490 = load ptr, ptr %l0, !tbaa !29
  %t491 = load i64, ptr %l31, !tbaa !24
  %t494 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2espell(ptr %v0, ptr %s23, ptr %t490, i64 %t491)
  store { i64, ptr } %t494, ptr %l304
  br label %bb114
bb114:
  %t495 = load i64, ptr %l39, !tbaa !24
  %t498 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s19, ptr %s23, ptr %l32, i64 %t495)
  store { i64, ptr } %t498, ptr %l307
  br label %bb115
bb115:
  %t499 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d299, i32 0, i32 1) }, 1
  %t500 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d299, i32 0, i32 1) }, 0
  %t501 = load { i64, ptr }, ptr %l304, !tbaa !27
  %t502 = extractvalue { i64, ptr } %t501, 1
  %t503 = extractvalue { i64, ptr } %t501, 0
  %t504 = add i64 %t500, %t503
  %t505 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d300, i32 0, i32 1) }, 1
  %t506 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d300, i32 0, i32 1) }, 0
  %t507 = add i64 %t504, %t506
  %t508 = load { i64, ptr }, ptr %l307, !tbaa !27
  %t509 = extractvalue { i64, ptr } %t508, 1
  %t510 = extractvalue { i64, ptr } %t508, 0
  %t511 = add i64 %t507, %t510
  %t512 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t511)
  call void @olang_textcopy(ptr %t512, ptr %t499, i64 %t500)
  %t513 = getelementptr i8, ptr %t512, i64 %t500
  call void @olang_textcopy(ptr %t513, ptr %t502, i64 %t503)
  %t514 = getelementptr i8, ptr %t513, i64 %t503
  call void @olang_textcopy(ptr %t514, ptr %t505, i64 %t506)
  %t515 = getelementptr i8, ptr %t514, i64 %t506
  call void @olang_textcopy(ptr %t515, ptr %t509, i64 %t510)
  %t516 = insertvalue { i64, ptr } undef, i64 %t511, 0
  %t517 = insertvalue { i64, ptr } %t516, ptr %t512, 1
  store { i64, ptr } %t517, ptr %l40, !tbaa !27
  %t519 = load i64, ptr %l30, !tbaa !24
  %t520 = load i64, ptr %l39, !tbaa !24
  %t522 = call i64 @__olang_fmt_i64(ptr null, i64 %t519)
  %t523 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d301, i32 0, i32 1) }, 1
  %t524 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d301, i32 0, i32 1) }, 0
  %t525 = add i64 %t522, %t524
  %t527 = call i64 @__olang_fmt_i64(ptr null, i64 %t520)
  %t528 = add i64 %t525, %t527
  %t529 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t528)
  %t530 = call i64 @__olang_fmt_i64(ptr %t529, i64 %t519)
  %t531 = getelementptr i8, ptr %t529, i64 %t522
  call void @olang_textcopy(ptr %t531, ptr %t523, i64 %t524)
  %t532 = getelementptr i8, ptr %t531, i64 %t524
  %t533 = call i64 @__olang_fmt_i64(ptr %t532, i64 %t520)
  %t534 = insertvalue { i64, ptr } undef, i64 %t528, 0
  %t535 = insertvalue { i64, ptr } %t534, ptr %t529, 1
  store { i64, ptr } %t535, ptr %l41, !tbaa !27
  store ptr %l23, ptr %l312, !tbaa !29
  %t537 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t537, ptr %l313, !tbaa !27
  %t538 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t538, ptr %l314, !tbaa !27
  %t539 = load ptr, ptr %l0, !tbaa !29
  %t540 = load i64, ptr %l31, !tbaa !24
  %t543 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2espell(ptr %v0, ptr %s23, ptr %t539, i64 %t540)
  store { i64, ptr } %t543, ptr %l317
  br label %bb116
bb116:
  %t544 = load i64, ptr %l39, !tbaa !24
  %t547 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s19, ptr %s23, ptr %l32, i64 %t544)
  store { i64, ptr } %t547, ptr %l320
  br label %bb117
bb117:
  %t548 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t549 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t550 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t551 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t552 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d302, i32 0, i32 1) }, 1
  %t553 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d302, i32 0, i32 1) }, 0
  %t554 = load { i64, ptr }, ptr %l313, !tbaa !27
  %t555 = extractvalue { i64, ptr } %t554, 1
  %t556 = extractvalue { i64, ptr } %t554, 0
  %t557 = add i64 %t553, %t556
  %t558 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d303, i32 0, i32 1) }, 1
  %t559 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d303, i32 0, i32 1) }, 0
  %t560 = add i64 %t557, %t559
  %t561 = load { i64, ptr }, ptr %l314, !tbaa !27
  %t562 = extractvalue { i64, ptr } %t561, 1
  %t563 = extractvalue { i64, ptr } %t561, 0
  %t564 = add i64 %t560, %t563
  %t565 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d304, i32 0, i32 1) }, 1
  %t566 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d304, i32 0, i32 1) }, 0
  %t567 = add i64 %t564, %t566
  %t568 = load { i64, ptr }, ptr %l317, !tbaa !27
  %t569 = extractvalue { i64, ptr } %t568, 1
  %t570 = extractvalue { i64, ptr } %t568, 0
  %t571 = add i64 %t567, %t570
  %t572 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d305, i32 0, i32 1) }, 1
  %t573 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d305, i32 0, i32 1) }, 0
  %t574 = add i64 %t571, %t573
  %t575 = load { i64, ptr }, ptr %l320, !tbaa !27
  %t576 = extractvalue { i64, ptr } %t575, 1
  %t577 = extractvalue { i64, ptr } %t575, 0
  %t578 = add i64 %t574, %t577
  %t579 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d306, i32 0, i32 1) }, 1
  %t580 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d306, i32 0, i32 1) }, 0
  %t581 = add i64 %t578, %t580
  %t583 = extractvalue { i64, ptr } %t548, 1
  %t584 = extractvalue { i64, ptr } %t548, 0
  %t585 = add i64 %t581, %t584
  %t586 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d307, i32 0, i32 1) }, 1
  %t587 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d307, i32 0, i32 1) }, 0
  %t588 = add i64 %t585, %t587
  %t590 = extractvalue { i64, ptr } %t549, 1
  %t591 = extractvalue { i64, ptr } %t549, 0
  %t592 = add i64 %t588, %t591
  %t593 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d308, i32 0, i32 1) }, 1
  %t594 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d308, i32 0, i32 1) }, 0
  %t595 = add i64 %t592, %t594
  %t597 = extractvalue { i64, ptr } %t550, 1
  %t598 = extractvalue { i64, ptr } %t550, 0
  %t599 = add i64 %t595, %t598
  %t600 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d309, i32 0, i32 1) }, 1
  %t601 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d309, i32 0, i32 1) }, 0
  %t602 = add i64 %t599, %t601
  %t604 = extractvalue { i64, ptr } %t551, 1
  %t605 = extractvalue { i64, ptr } %t551, 0
  %t606 = add i64 %t602, %t605
  %t607 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d310, i32 0, i32 1) }, 1
  %t608 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d310, i32 0, i32 1) }, 0
  %t609 = add i64 %t606, %t608
  %t610 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t609)
  call void @olang_textcopy(ptr %t610, ptr %t552, i64 %t553)
  %t611 = getelementptr i8, ptr %t610, i64 %t553
  call void @olang_textcopy(ptr %t611, ptr %t555, i64 %t556)
  %t612 = getelementptr i8, ptr %t611, i64 %t556
  call void @olang_textcopy(ptr %t612, ptr %t558, i64 %t559)
  %t613 = getelementptr i8, ptr %t612, i64 %t559
  call void @olang_textcopy(ptr %t613, ptr %t562, i64 %t563)
  %t614 = getelementptr i8, ptr %t613, i64 %t563
  call void @olang_textcopy(ptr %t614, ptr %t565, i64 %t566)
  %t615 = getelementptr i8, ptr %t614, i64 %t566
  call void @olang_textcopy(ptr %t615, ptr %t569, i64 %t570)
  %t616 = getelementptr i8, ptr %t615, i64 %t570
  call void @olang_textcopy(ptr %t616, ptr %t572, i64 %t573)
  %t617 = getelementptr i8, ptr %t616, i64 %t573
  call void @olang_textcopy(ptr %t617, ptr %t576, i64 %t577)
  %t618 = getelementptr i8, ptr %t617, i64 %t577
  call void @olang_textcopy(ptr %t618, ptr %t579, i64 %t580)
  %t619 = getelementptr i8, ptr %t618, i64 %t580
  call void @olang_textcopy(ptr %t619, ptr %t583, i64 %t584)
  %t620 = getelementptr i8, ptr %t619, i64 %t584
  call void @olang_textcopy(ptr %t620, ptr %t586, i64 %t587)
  %t621 = getelementptr i8, ptr %t620, i64 %t587
  call void @olang_textcopy(ptr %t621, ptr %t590, i64 %t591)
  %t622 = getelementptr i8, ptr %t621, i64 %t591
  call void @olang_textcopy(ptr %t622, ptr %t593, i64 %t594)
  %t623 = getelementptr i8, ptr %t622, i64 %t594
  call void @olang_textcopy(ptr %t623, ptr %t597, i64 %t598)
  %t624 = getelementptr i8, ptr %t623, i64 %t598
  call void @olang_textcopy(ptr %t624, ptr %t600, i64 %t601)
  %t625 = getelementptr i8, ptr %t624, i64 %t601
  call void @olang_textcopy(ptr %t625, ptr %t604, i64 %t605)
  %t626 = getelementptr i8, ptr %t625, i64 %t605
  call void @olang_textcopy(ptr %t626, ptr %t607, i64 %t608)
  %t627 = insertvalue { i64, ptr } undef, i64 %t609, 0
  %t628 = insertvalue { i64, ptr } %t627, ptr %t610, 1
  %t630 = load ptr, ptr %l312, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s23, ptr %t630, { i64, ptr } %t628)
  br label %bb118
bb118:
  call void @__olang_scope_close(ptr %s23)
  br label %bb119
bb119:
  %t632 = load i64, ptr %l38, !tbaa !24
  %t635 = add i64 %t632, 1
  store i64 %t635, ptr %l38, !tbaa !24
  br label %bb104
bb120:
  call void @__olang_scope_close(ptr %s19)
  br label %bb121
bb121:
  %t637 = load i64, ptr %l29, !tbaa !24
  %t640 = add i64 %t637, 1
  store i64 %t640, ptr %l29, !tbaa !24
  br label %bb79
bb122:
  store ptr %l14, ptr %l42, !tbaa !29
  store i64 0, ptr %l43, !tbaa !24
  br label %bb123
bb123:
  store %olang.scope zeroinitializer, ptr %s30
  %t643 = load i64, ptr %l43, !tbaa !24
  store i64 %t643, ptr %l334, !tbaa !24
  %t644 = load ptr, ptr %l42, !tbaa !29
  %t646 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t644)
  store i64 %t646, ptr %l336
  br label %bb124
bb124:
  %t647 = load i64, ptr %l334, !tbaa !24
  %t648 = load i64, ptr %l336, !tbaa !24
  %t649 = icmp slt i64 %t647, %t648
  %t651 = xor i1 %t649, true
  br i1 %t651, label %bb125, label %bb126
bb125:
  call void @__olang_scope_close(ptr %s30)
  br label %bb161
bb126:
  br label %bb127
bb127:
  %t653 = load i64, ptr %l43, !tbaa !24
  store i64 %t653, ptr %l44, !tbaa !24
  %t655 = load ptr, ptr %l42, !tbaa !29
  %t656 = load i64, ptr %l43, !tbaa !24
  %t659 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t655, i64 %t656)
  store i64 %t659, ptr %l342
  br label %bb128
bb128:
  %t660 = load i64, ptr %l342, !tbaa !24
  store i64 %t660, ptr %l45, !tbaa !24
  %t661 = load ptr, ptr %l0, !tbaa !29
  %t663 = getelementptr %"compiler/bindgen:gen", ptr %t661, i32 0, i32 6
  %t664 = load i64, ptr %l45, !tbaa !24
  %t667 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRef_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %s30, ptr %t663, i64 %t664)
  store ptr %t667, ptr %l346
  br label %bb129
bb129:
  %t668 = load ptr, ptr %l346, !tbaa !29
  %t670 = getelementptr %"compiler/bindgen:record", ptr %t668, i32 0, i32 1
  %t671 = load i1, ptr %t670, !tbaa !21
  br i1 %t671, label %bb130, label %bb131
bb130:
  store i1 true, ptr %l349, !tbaa !21
  br label %bb133
bb131:
  %t673 = load ptr, ptr %l0, !tbaa !29
  %t674 = load i64, ptr %l45, !tbaa !24
  %t677 = call i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ehasAnon(ptr %v0, ptr %t673, i64 %t674)
  store i1 %t677, ptr %l352
  br label %bb132
bb132:
  %t678 = load i1, ptr %l352, !tbaa !21
  %t679 = xor i1 %t678, true
  store i1 %t679, ptr %l349, !tbaa !21
  br label %bb133
bb133:
  %t681 = load i1, ptr %l349, !tbaa !21
  br i1 %t681, label %bb134, label %bb135
bb134:
  call void @__olang_scope_close(ptr %s30)
  br label %bb160
bb135:
  br label %bb136
bb136:
  %t682 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s30, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t682, ptr %l354
  br label %bb137
bb137:
  %t683 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l354
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t683, ptr %l46
  %t684 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s30, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t684, ptr %l355
  br label %bb138
bb138:
  %t685 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l355
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t685, ptr %l47
  %t686 = load ptr, ptr %l0, !tbaa !29
  %t687 = load i64, ptr %l45, !tbaa !24
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eunionFlat(ptr %v0, ptr %s30, ptr %s30, ptr %t686, i64 %t687, i1 false, ptr %l46, ptr %l47)
  br label %bb139
bb139:
  %t692 = load ptr, ptr %l0, !tbaa !29
  %t694 = getelementptr %"compiler/bindgen:gen", ptr %t692, i32 0, i32 6
  %t695 = load i64, ptr %l45, !tbaa !24
  %t698 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRefMu_Hc21bcd245b67ffb6ee3e145838fcf2cf(ptr %v0, ptr %v0, ptr %t694, i64 %t695)
  store ptr %t698, ptr %l363
  br label %bb140
bb140:
  %t699 = load ptr, ptr %l363, !tbaa !29
  %t701 = getelementptr %"compiler/bindgen:record", ptr %t699, i32 0, i32 19
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t701)
  br label %bb141
bb141:
  store i64 0, ptr %l48, !tbaa !24
  %t704 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s30, ptr %l46)
  store i64 %t704, ptr %l367
  br label %bb142
bb142:
  %t705 = load i64, ptr %l367, !tbaa !24
  store i64 %t705, ptr %l49, !tbaa !24
  store i64 1, ptr %l50, !tbaa !24
  %t706 = load i64, ptr %l49, !tbaa !24
  %t707 = load i64, ptr %l48, !tbaa !24
  %t710 = icmp sgt i64 %t706, %t707
  br i1 %t710, label %bb143, label %bb144
bb143:
  %t712 = load i64, ptr %l50, !tbaa !24
  %t714 = icmp sgt i64 %t712, 0
  br i1 %t714, label %bb145, label %bb146
bb144:
  store i64 0, ptr %l371, !tbaa !24
  br label %bb148
bb145:
  %t716 = load i64, ptr %l49, !tbaa !24
  %t717 = load i64, ptr %l48, !tbaa !24
  %t720 = sub i64 %t716, %t717
  %t721 = load i64, ptr %l50, !tbaa !24
  %t724 = add i64 %t720, %t721
  %t726 = sub i64 %t724, 1
  %t727 = load i64, ptr %l50, !tbaa !24
  %t730 = sdiv i64 %t726, %t727
  store i64 %t730, ptr %l374, !tbaa !24
  br label %bb147
bb146:
  store i64 0, ptr %l374, !tbaa !24
  br label %bb147
bb147:
  %t732 = load i64, ptr %l374, !tbaa !24
  store i64 %t732, ptr %l371, !tbaa !24
  br label %bb148
bb148:
  %t733 = load i64, ptr %l371, !tbaa !24
  store i64 %t733, ptr %l51, !tbaa !24
  store i64 0, ptr %l52, !tbaa !24
  br label %bb149
bb149:
  store %olang.scope zeroinitializer, ptr %s33
  %t734 = load i64, ptr %l52, !tbaa !24
  %t735 = load i64, ptr %l51, !tbaa !24
  %t738 = icmp slt i64 %t734, %t735
  %t740 = xor i1 %t738, true
  br i1 %t740, label %bb150, label %bb151
bb150:
  call void @__olang_scope_close(ptr %s33)
  br label %bb159
bb151:
  br label %bb152
bb152:
  %t742 = load i64, ptr %l48, !tbaa !24
  %t743 = load i64, ptr %l52, !tbaa !24
  %t744 = load i64, ptr %l50, !tbaa !24
  %t747 = mul i64 %t743, %t744
  %t750 = add i64 %t742, %t747
  store i64 %t750, ptr %l53, !tbaa !24
  %t752 = load ptr, ptr %l0, !tbaa !29
  %t754 = getelementptr %"compiler/bindgen:gen", ptr %t752, i32 0, i32 6
  %t755 = load i64, ptr %l45, !tbaa !24
  %t758 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRefMu_Hc21bcd245b67ffb6ee3e145838fcf2cf(ptr %v0, ptr %v0, ptr %t754, i64 %t755)
  store ptr %t758, ptr %l395
  br label %bb153
bb153:
  %t759 = load ptr, ptr %l395, !tbaa !29
  %t761 = getelementptr %"compiler/bindgen:record", ptr %t759, i32 0, i32 19
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t761, i64 -1)
  br label %bb154
bb154:
  store ptr %l23, ptr %l398, !tbaa !29
  %t763 = load i64, ptr %l44, !tbaa !24
  store i64 %t763, ptr %l399, !tbaa !24
  %t764 = load i64, ptr %l53, !tbaa !24
  store i64 %t764, ptr %l400, !tbaa !24
  %t765 = load i64, ptr %l44, !tbaa !24
  store i64 %t765, ptr %l401, !tbaa !24
  %t766 = load i64, ptr %l53, !tbaa !24
  store i64 %t766, ptr %l402, !tbaa !24
  %t767 = load ptr, ptr %l0, !tbaa !29
  %t768 = load i64, ptr %l45, !tbaa !24
  %t771 = call { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2espell(ptr %v0, ptr %s33, ptr %t767, i64 %t768)
  store { i64, ptr } %t771, ptr %l405
  br label %bb155
bb155:
  %t772 = load i64, ptr %l53, !tbaa !24
  %t775 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s30, ptr %s33, ptr %l46, i64 %t772)
  store { i64, ptr } %t775, ptr %l408
  br label %bb156
bb156:
  %t776 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d311, i32 0, i32 1) }, 1
  %t777 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d311, i32 0, i32 1) }, 0
  %t778 = load i64, ptr %l399, !tbaa !24
  %t779 = call i64 @__olang_fmt_i64(ptr null, i64 %t778)
  %t780 = add i64 %t777, %t779
  %t781 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d312, i32 0, i32 1) }, 1
  %t782 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d312, i32 0, i32 1) }, 0
  %t783 = add i64 %t780, %t782
  %t784 = load i64, ptr %l400, !tbaa !24
  %t785 = call i64 @__olang_fmt_i64(ptr null, i64 %t784)
  %t786 = add i64 %t783, %t785
  %t787 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d313, i32 0, i32 1) }, 1
  %t788 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d313, i32 0, i32 1) }, 0
  %t789 = add i64 %t786, %t788
  %t790 = load i64, ptr %l401, !tbaa !24
  %t791 = call i64 @__olang_fmt_i64(ptr null, i64 %t790)
  %t792 = add i64 %t789, %t791
  %t793 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d312, i32 0, i32 1) }, 1
  %t794 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d312, i32 0, i32 1) }, 0
  %t795 = add i64 %t792, %t794
  %t796 = load i64, ptr %l402, !tbaa !24
  %t797 = call i64 @__olang_fmt_i64(ptr null, i64 %t796)
  %t798 = add i64 %t795, %t797
  %t799 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d314, i32 0, i32 1) }, 1
  %t800 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d314, i32 0, i32 1) }, 0
  %t801 = add i64 %t798, %t800
  %t802 = load { i64, ptr }, ptr %l405, !tbaa !27
  %t803 = extractvalue { i64, ptr } %t802, 1
  %t804 = extractvalue { i64, ptr } %t802, 0
  %t805 = add i64 %t801, %t804
  %t806 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d315, i32 0, i32 1) }, 1
  %t807 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d315, i32 0, i32 1) }, 0
  %t808 = add i64 %t805, %t807
  %t809 = load { i64, ptr }, ptr %l408, !tbaa !27
  %t810 = extractvalue { i64, ptr } %t809, 1
  %t811 = extractvalue { i64, ptr } %t809, 0
  %t812 = add i64 %t808, %t811
  %t813 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d316, i32 0, i32 1) }, 1
  %t814 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d316, i32 0, i32 1) }, 0
  %t815 = add i64 %t812, %t814
  %t816 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t815)
  call void @olang_textcopy(ptr %t816, ptr %t776, i64 %t777)
  %t817 = getelementptr i8, ptr %t816, i64 %t777
  %t818 = call i64 @__olang_fmt_i64(ptr %t817, i64 %t778)
  %t819 = getelementptr i8, ptr %t817, i64 %t779
  call void @olang_textcopy(ptr %t819, ptr %t781, i64 %t782)
  %t820 = getelementptr i8, ptr %t819, i64 %t782
  %t821 = call i64 @__olang_fmt_i64(ptr %t820, i64 %t784)
  %t822 = getelementptr i8, ptr %t820, i64 %t785
  call void @olang_textcopy(ptr %t822, ptr %t787, i64 %t788)
  %t823 = getelementptr i8, ptr %t822, i64 %t788
  %t824 = call i64 @__olang_fmt_i64(ptr %t823, i64 %t790)
  %t825 = getelementptr i8, ptr %t823, i64 %t791
  call void @olang_textcopy(ptr %t825, ptr %t793, i64 %t794)
  %t826 = getelementptr i8, ptr %t825, i64 %t794
  %t827 = call i64 @__olang_fmt_i64(ptr %t826, i64 %t796)
  %t828 = getelementptr i8, ptr %t826, i64 %t797
  call void @olang_textcopy(ptr %t828, ptr %t799, i64 %t800)
  %t829 = getelementptr i8, ptr %t828, i64 %t800
  call void @olang_textcopy(ptr %t829, ptr %t803, i64 %t804)
  %t830 = getelementptr i8, ptr %t829, i64 %t804
  call void @olang_textcopy(ptr %t830, ptr %t806, i64 %t807)
  %t831 = getelementptr i8, ptr %t830, i64 %t807
  call void @olang_textcopy(ptr %t831, ptr %t810, i64 %t811)
  %t832 = getelementptr i8, ptr %t831, i64 %t811
  call void @olang_textcopy(ptr %t832, ptr %t813, i64 %t814)
  %t833 = insertvalue { i64, ptr } undef, i64 %t815, 0
  %t834 = insertvalue { i64, ptr } %t833, ptr %t816, 1
  %t836 = load ptr, ptr %l398, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s33, ptr %t836, { i64, ptr } %t834)
  br label %bb157
bb157:
  call void @__olang_scope_close(ptr %s33)
  br label %bb158
bb158:
  %t838 = load i64, ptr %l52, !tbaa !24
  %t841 = add i64 %t838, 1
  store i64 %t841, ptr %l52, !tbaa !24
  br label %bb149
bb159:
  call void @__olang_scope_close(ptr %s30)
  br label %bb160
bb160:
  %t843 = load i64, ptr %l43, !tbaa !24
  %t846 = add i64 %t843, 1
  store i64 %t846, ptr %l43, !tbaa !24
  br label %bb123
bb161:
  %t848 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t848, ptr %l417, !tbaa !27
  %t850 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l23)
  store { i64, ptr } %t850, ptr %l419
  br label %bb162
bb162:
  %t851 = load { i64, ptr }, ptr %l419, !tbaa !27
  %t853 = extractvalue { i64, ptr } %t851, 0
  %t854 = extractvalue { i64, ptr } %t851, 1
  %t855 = mul i64 %t853, 1
  %t856 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t855)
  call void @llvm.memcpy.p0.p0.i64(ptr %t856, ptr %t854, i64 %t855, i1 false)
  %t857 = insertvalue { i64, ptr } undef, i64 %t853, 0
  %t858 = insertvalue { i64, ptr } %t857, ptr %t856, 1
  %t859 = load { i64, ptr }, ptr %l417, !tbaa !27
  %t861 = call i32 @std_2fos_2eWriteFile(ptr %v3, ptr %s0, { i64, ptr } %t859, { i64, ptr } %t858)
  store i32 %t861, ptr %l422
  %t862 = icmp ne i32 %t861, 0
  br i1 %t862, label %bb164, label %ok.863, !prof !99
ok.863:
  br label %bb163
bb163:
  br label %bb171
bb164:
  %t864 = load i32, ptr %l422, !tbaa !23
  %t865 = ashr i32 %t864, 16
  %t867 = icmp eq i32 %t865, 1
  store i1 %t867, ptr %l424, !tbaa !21
  %t868 = load i32, ptr %l422, !tbaa !23
  %t869 = ashr i32 %t868, 16
  %t871 = icmp eq i32 %t869, 1
  br i1 %t871, label %bb165, label %bb166
bb165:
  call void @__olang_errpay_pop()
  br label %bb166
bb166:
  br label %bb167
bb167:
  %t873 = load ptr, ptr %l0, !tbaa !29
  %t875 = call i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %v0, ptr %t873, { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d317, i32 0, i32 1) })
  store i32 %t875, ptr %l428
  %t876 = icmp ne i32 %t875, 0
  br i1 %t876, label %bb169, label %ok.877, !prof !99
ok.877:
  br label %bb168
bb168:
  br label %bb170
bb169:
  %t878 = load i32, ptr %l428, !tbaa !23
  %t879 = lshr i32 %t878, 16
  %t880 = and i32 %t878, 65535
  %t881 = icmp eq i32 %t879, 1
  %t882 = select i1 %t881, i32 1, i32 0
  %t883 = icmp eq i32 %t878, 0
  %t884 = shl i32 %t882, 16
  %t885 = or i32 %t884, %t880
  %t886 = select i1 %t883, i32 0, i32 %t885
  call void @__olang_scope_close(ptr %s0)
  store i32 %t886, ptr %rv
  br label %ret
bb170:
  br label %bb171
bb171:
  %t888 = load ptr, ptr %l0, !tbaa !29
  %t891 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t896 = call { i32, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2edump(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %s0, ptr %t888, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %t891)
  %t897 = extractvalue { i32, ptr } %t896, 1
  %t898 = extractvalue { i32, ptr } %t896, 0
  store i32 %t898, ptr %l436
  %t899 = icmp ne i32 %t898, 0
  br i1 %t899, label %bb173, label %ok.900, !prof !99
ok.900:
  store ptr %t897, ptr %l435
  br label %bb172
bb172:
  %t901 = load ptr, ptr %l435, !tbaa !29
  store ptr %t901, ptr %l430, !tbaa !29
  br label %bb174
bb173:
  %t902 = load i32, ptr %l436, !tbaa !23
  %t903 = lshr i32 %t902, 16
  %t904 = and i32 %t902, 65535
  %t905 = icmp eq i32 %t903, 1
  %t906 = select i1 %t905, i32 1, i32 0
  %t907 = icmp eq i32 %t902, 0
  %t908 = shl i32 %t906, 16
  %t909 = or i32 %t908, %t904
  %t910 = select i1 %t907, i32 0, i32 %t909
  call void @__olang_scope_close(ptr %s0)
  store i32 %t910, ptr %rv
  br label %ret
bb174:
  %t912 = load ptr, ptr %l430, !tbaa !29
  store %olang.scope zeroinitializer, ptr %s38
  %t915 = call { i64, ptr } @compiler_2fbindgen_2einner(ptr %s0, ptr %s38, ptr %t912)
  store { i64, ptr } %t915, ptr %l439
  br label %bb175
bb175:
  %t916 = load { i64, ptr }, ptr %l439, !tbaa !27
  store { i64, ptr } %t916, ptr %l55, !tbaa !27
  store i64 0, ptr %l56, !tbaa !24
  %t918 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t920 = extractvalue { i64, ptr } %t918, 0
  store i64 %t920, ptr %l57, !tbaa !24
  br label %bb176
bb176:
  store %olang.scope zeroinitializer, ptr %s39
  %t922 = load i64, ptr %l56, !tbaa !24
  %t923 = load i64, ptr %l57, !tbaa !24
  %t926 = icmp slt i64 %t922, %t923
  %t928 = xor i1 %t926, true
  br i1 %t928, label %bb177, label %bb178
bb177:
  call void @__olang_scope_close(ptr %s39)
  br label %bb256
bb178:
  br label %bb179
bb179:
  %t930 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t930, ptr %l447, !tbaa !27
  %t931 = load i64, ptr %l56, !tbaa !24
  %t933 = getelementptr { i64, ptr }, ptr %l447, i32 0, i32 1
  %t934 = load ptr, ptr %t933, !tbaa !27
  %t935 = getelementptr ptr, ptr %t934, i64 %t931
  %t936 = load ptr, ptr %t935, !tbaa !39
  store ptr %t936, ptr %l58, !tbaa !29
  %t938 = load ptr, ptr %l58, !tbaa !29
  %t940 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %s38, ptr %s39, ptr %s39, ptr %t938, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d318, i32 0, i32 1) })
  store { i64, ptr } %t940, ptr %l451
  br label %bb180
bb180:
  %t941 = load { i64, ptr }, ptr %l451, !tbaa !27
  store { i64, ptr } %t941, ptr %l59, !tbaa !27
  %t942 = load ptr, ptr %l58, !tbaa !29
  %t944 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %s38, ptr %s39, ptr %s39, ptr %t942, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d319, i32 0, i32 1) })
  store { i64, ptr } %t944, ptr %l453
  br label %bb181
bb181:
  %t945 = load { i64, ptr }, ptr %l453, !tbaa !27
  %t947 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s39, ptr %s39, { i64, ptr } %t945, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d320, i32 0, i32 1) })
  store i1 %t947, ptr %l455
  br label %bb182
bb182:
  %t948 = load i1, ptr %l455, !tbaa !21
  br i1 %t948, label %bb183, label %bb184
bb183:
  %t949 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t951 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s39, ptr %s39, { i64, ptr } %t949, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d321, i32 0, i32 1) })
  store i1 %t951, ptr %l458
  br label %bb185
bb184:
  store i1 false, ptr %l456, !tbaa !21
  br label %bb186
bb185:
  %t952 = load i1, ptr %l458, !tbaa !21
  store i1 %t952, ptr %l456, !tbaa !21
  br label %bb186
bb186:
  %t953 = load i1, ptr %l456, !tbaa !21
  br i1 %t953, label %bb187, label %bb188
bb187:
  %t954 = load ptr, ptr %l0, !tbaa !29
  %t955 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t956 = load ptr, ptr %l58, !tbaa !29
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2emember(ptr %v0, ptr %s0, ptr %s39, ptr %s38, ptr %t954, ptr %l14, { i64, ptr } %t955, ptr %t956)
  br label %bb189
bb188:
  br label %bb190
bb189:
  br label %bb190
bb190:
  %t961 = load ptr, ptr %l58, !tbaa !29
  %t963 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %s38, ptr %s39, ptr %s39, ptr %t961, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d322, i32 0, i32 1) })
  store { i64, ptr } %t963, ptr %l464
  br label %bb191
bb191:
  %t964 = load { i64, ptr }, ptr %l464, !tbaa !27
  %t966 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s39, ptr %s39, { i64, ptr } %t964, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d323, i32 0, i32 1) })
  store i1 %t966, ptr %l466
  br label %bb192
bb192:
  %t967 = load i1, ptr %l466, !tbaa !21
  br i1 %t967, label %bb193, label %bb194
bb193:
  %t968 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t970 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s39, ptr %s39, { i64, ptr } %t968, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d324, i32 0, i32 1) })
  store i1 %t970, ptr %l469
  br label %bb195
bb194:
  store i1 false, ptr %l467, !tbaa !21
  br label %bb196
bb195:
  %t971 = load i1, ptr %l469, !tbaa !21
  store i1 %t971, ptr %l467, !tbaa !21
  br label %bb196
bb196:
  %t972 = load i1, ptr %l467, !tbaa !21
  br i1 %t972, label %bb197, label %bb198
bb197:
  %t973 = load ptr, ptr %l0, !tbaa !29
  %t974 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t975 = load ptr, ptr %l58, !tbaa !29
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eunionMember(ptr %v0, ptr %s0, ptr %s39, ptr %s38, ptr %t973, ptr %l14, { i64, ptr } %t974, ptr %t975)
  br label %bb199
bb198:
  br label %bb200
bb199:
  br label %bb200
bb200:
  %t980 = load ptr, ptr %l58, !tbaa !29
  %t982 = call { i64, ptr } @compiler_2fbindgen_2etext(ptr %s38, ptr %s39, ptr %s39, ptr %t980, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d325, i32 0, i32 1) })
  store { i64, ptr } %t982, ptr %l475
  br label %bb201
bb201:
  %t983 = load { i64, ptr }, ptr %l475, !tbaa !27
  %t985 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s39, ptr %s39, { i64, ptr } %t983, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d326, i32 0, i32 1) })
  store i1 %t985, ptr %l477
  br label %bb202
bb202:
  %t986 = load i1, ptr %l477, !tbaa !21
  %t987 = xor i1 %t986, true
  br i1 %t987, label %bb203, label %bb204
bb203:
  store i1 true, ptr %l479, !tbaa !21
  br label %bb206
bb204:
  %t989 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t991 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s39, ptr %s39, { i64, ptr } %t989, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d327, i32 0, i32 1) })
  store i1 %t991, ptr %l481
  br label %bb205
bb205:
  %t992 = load i1, ptr %l481, !tbaa !21
  %t993 = xor i1 %t992, true
  store i1 %t993, ptr %l479, !tbaa !21
  br label %bb206
bb206:
  %t995 = load i1, ptr %l479, !tbaa !21
  br i1 %t995, label %bb207, label %bb208
bb207:
  call void @__olang_scope_close(ptr %s39)
  br label %bb255
bb208:
  br label %bb209
bb209:
  %t996 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t998 = extractvalue { i64, ptr } %t996, 0
  store i64 %t998, ptr %l485, !tbaa !24
  %t999 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t1000 = extractvalue { i64, ptr } %t999, 0
  store i64 %t1000, ptr %l486, !tbaa !24
  %t1001 = icmp sge i64 9, 0
  br i1 %t1001, label %bb210, label %bb211
bb210:
  %t1003 = load i64, ptr %l485, !tbaa !24
  %t1004 = icmp sle i64 9, %t1003
  br i1 %t1004, label %bb212, label %bb213
bb211:
  call void @__olang_check_failed(ptr @olang_loc_f6b0d4dcea5d2bc9_16e8d1d827605cbd)
  unreachable
bb212:
  %t1006 = load i64, ptr %l485, !tbaa !24
  %t1007 = load i64, ptr %l486, !tbaa !24
  %t1008 = icmp sle i64 %t1006, %t1007
  br i1 %t1008, label %bb214, label %bb215
bb213:
  call void @__olang_check_failed(ptr @olang_loc_f6b0d4dcea5d2bc9_16e8d1d827605cbd)
  unreachable
bb214:
  %t1010 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t1011 = load ptr, ptr %t1010, !tbaa !27
  %t1012 = load i64, ptr %l485, !tbaa !24
  %t1013 = getelementptr i8, ptr %t1011, i64 9
  %t1014 = sub i64 %t1012, 9
  %t1015 = insertvalue { i64, ptr } undef, i64 %t1014, 0
  %t1016 = insertvalue { i64, ptr } %t1015, ptr %t1013, 1
  store { i64, ptr } %t1016, ptr %l490, !tbaa !27
  %t1017 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s39, i64 10)
  %t1018 = extractvalue { i32, i64 } %t1017, 1
  %t1019 = extractvalue { i32, i64 } %t1017, 0
  store i32 %t1019, ptr %l492
  %t1020 = icmp ne i32 %t1019, 0
  br i1 %t1020, label %bb217, label %ok.1021, !prof !99
ok.1021:
  store i64 %t1018, ptr %l491
  br label %bb216
bb215:
  call void @__olang_check_failed(ptr @olang_loc_f6b0d4dcea5d2bc9_16e8d1d827605cbd)
  unreachable
bb216:
  %t1022 = load { i64, ptr }, ptr %l490, !tbaa !27
  %t1023 = load i64, ptr %l491, !tbaa !24
  %t1024 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s39, { i64, ptr } %t1022, i64 %t1023)
  %t1025 = extractvalue { i32, i64 } %t1024, 1
  %t1026 = extractvalue { i32, i64 } %t1024, 0
  store i32 %t1026, ptr %l494
  %t1027 = icmp ne i32 %t1026, 0
  br i1 %t1027, label %bb220, label %ok.1028, !prof !99
ok.1028:
  store i64 %t1025, ptr %l493
  br label %bb219
bb217:
  br label %bb218
bb218:
  store i64 -1, ptr %l483, !tbaa !24
  br label %bb221
bb219:
  %t1029 = load i64, ptr %l493, !tbaa !24
  store i64 %t1029, ptr %l483, !tbaa !24
  br label %bb221
bb220:
  br label %bb218
bb221:
  %t1030 = load i64, ptr %l483, !tbaa !24
  store i64 %t1030, ptr %l60, !tbaa !24
  %t1031 = load i64, ptr %l60, !tbaa !24
  %t1033 = icmp slt i64 %t1031, 0
  br i1 %t1033, label %bb222, label %bb223
bb222:
  store i1 true, ptr %l497, !tbaa !21
  br label %bb225
bb223:
  %t1035 = load i64, ptr %l60, !tbaa !24
  store i64 %t1035, ptr %l498, !tbaa !24
  %t1037 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l14)
  store i64 %t1037, ptr %l500
  br label %bb224
bb224:
  %t1038 = load i64, ptr %l498, !tbaa !24
  %t1039 = load i64, ptr %l500, !tbaa !24
  %t1040 = icmp sge i64 %t1038, %t1039
  store i1 %t1040, ptr %l497, !tbaa !21
  br label %bb225
bb225:
  %t1042 = load i1, ptr %l497, !tbaa !21
  br i1 %t1042, label %bb226, label %bb227
bb226:
  call void @__olang_scope_close(ptr %s39)
  br label %bb255
bb227:
  br label %bb228
bb228:
  %t1043 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s39, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1043, ptr %l502
  br label %bb229
bb229:
  %t1044 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l502
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1044, ptr %l61
  store %olang.scope zeroinitializer, ptr %s44
  %t1045 = load ptr, ptr %l58, !tbaa !29
  %t1047 = call { i64, ptr } @compiler_2fbindgen_2einner(ptr %s38, ptr %s44, ptr %t1045)
  store { i64, ptr } %t1047, ptr %l504
  br label %bb230
bb230:
  %t1048 = load { i64, ptr }, ptr %l504, !tbaa !27
  store { i64, ptr } %t1048, ptr %l62, !tbaa !27
  store i64 0, ptr %l63, !tbaa !24
  %t1050 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t1052 = extractvalue { i64, ptr } %t1050, 0
  store i64 %t1052, ptr %l64, !tbaa !24
  br label %bb231
bb231:
  store %olang.scope zeroinitializer, ptr %s45
  %t1054 = load i64, ptr %l63, !tbaa !24
  %t1055 = load i64, ptr %l64, !tbaa !24
  %t1058 = icmp slt i64 %t1054, %t1055
  %t1060 = xor i1 %t1058, true
  br i1 %t1060, label %bb232, label %bb233
bb232:
  call void @__olang_scope_close(ptr %s45)
  br label %bb244
bb233:
  br label %bb234
bb234:
  %t1062 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t1062, ptr %l512, !tbaa !27
  %t1063 = load i64, ptr %l63, !tbaa !24
  %t1065 = getelementptr { i64, ptr }, ptr %l512, i32 0, i32 1
  %t1066 = load ptr, ptr %t1065, !tbaa !27
  %t1067 = getelementptr ptr, ptr %t1066, i64 %t1063
  %t1068 = load ptr, ptr %t1067, !tbaa !39
  %t1072 = call { i64, ptr } @compiler_2fbindgen_2econstValue(ptr %s44, ptr %s45, ptr %t1068)
  store { i64, ptr } %t1072, ptr %l516
  br label %bb235
bb235:
  %t1073 = load { i64, ptr }, ptr %l516, !tbaa !27
  store ptr %l61, ptr %l517, !tbaa !29
  store { i64, ptr } %t1073, ptr %l519, !tbaa !27
  %t1075 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s45, i64 10)
  %t1076 = extractvalue { i32, i64 } %t1075, 1
  %t1077 = extractvalue { i32, i64 } %t1075, 0
  store i32 %t1077, ptr %l521
  %t1078 = icmp ne i32 %t1077, 0
  br i1 %t1078, label %bb237, label %ok.1079, !prof !99
ok.1079:
  store i64 %t1076, ptr %l520
  br label %bb236
bb236:
  %t1080 = load { i64, ptr }, ptr %l519, !tbaa !27
  %t1081 = load i64, ptr %l520, !tbaa !24
  %t1082 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s45, { i64, ptr } %t1080, i64 %t1081)
  %t1083 = extractvalue { i32, i64 } %t1082, 1
  %t1084 = extractvalue { i32, i64 } %t1082, 0
  store i32 %t1084, ptr %l523
  %t1085 = icmp ne i32 %t1084, 0
  br i1 %t1085, label %bb240, label %ok.1086, !prof !99
ok.1086:
  store i64 %t1083, ptr %l522
  br label %bb239
bb237:
  br label %bb238
bb238:
  store i64 -1, ptr %l518, !tbaa !24
  br label %bb241
bb239:
  %t1087 = load i64, ptr %l522, !tbaa !24
  store i64 %t1087, ptr %l518, !tbaa !24
  br label %bb241
bb240:
  br label %bb238
bb241:
  %t1088 = load ptr, ptr %l517, !tbaa !29
  %t1089 = load i64, ptr %l518, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s39, ptr %t1088, i64 %t1089)
  br label %bb242
bb242:
  call void @__olang_scope_close(ptr %s45)
  br label %bb243
bb243:
  %t1090 = load i64, ptr %l63, !tbaa !24
  %t1093 = add i64 %t1090, 1
  store i64 %t1093, ptr %l63, !tbaa !24
  br label %bb231
bb244:
  call void @__olang_scope_close(ptr %s44)
  %t1096 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s39, ptr %l61)
  store i64 %t1096, ptr %l528
  br label %bb245
bb245:
  %t1097 = load i64, ptr %l528, !tbaa !24
  %t1098 = icmp eq i64 %t1097, 2
  br i1 %t1098, label %bb246, label %bb247
bb246:
  %t1100 = load i64, ptr %l60, !tbaa !24
  %t1103 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l14, i64 %t1100)
  store i64 %t1103, ptr %l532
  br label %bb248
bb247:
  br label %bb254
bb248:
  %t1104 = load i64, ptr %l532, !tbaa !24
  store i64 %t1104, ptr %l67, !tbaa !24
  %t1106 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s39, ptr %l61, i64 0)
  store i64 %t1106, ptr %l534
  br label %bb249
bb249:
  %t1107 = load i64, ptr %l534, !tbaa !24
  store i64 %t1107, ptr %l68, !tbaa !24
  %t1108 = load ptr, ptr %l0, !tbaa !29
  %t1110 = getelementptr %"compiler/bindgen:gen", ptr %t1108, i32 0, i32 6
  %t1111 = load i64, ptr %l67, !tbaa !24
  %t1114 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRefMu_Hc21bcd245b67ffb6ee3e145838fcf2cf(ptr %v0, ptr %v0, ptr %t1110, i64 %t1111)
  store ptr %t1114, ptr %l538
  br label %bb250
bb250:
  %t1115 = load ptr, ptr %l538, !tbaa !29
  %t1117 = load i64, ptr %l68, !tbaa !24
  %t1120 = getelementptr %"compiler/bindgen:record", ptr %t1115, i32 0, i32 13
  store i64 %t1117, ptr %t1120, !tbaa !24
  %t1121 = load i64, ptr %l60, !tbaa !24
  %t1124 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l14, i64 %t1121)
  store i64 %t1124, ptr %l543
  br label %bb251
bb251:
  %t1125 = load i64, ptr %l543, !tbaa !24
  store i64 %t1125, ptr %l70, !tbaa !24
  %t1127 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s39, ptr %l61, i64 1)
  store i64 %t1127, ptr %l545
  br label %bb252
bb252:
  %t1128 = load i64, ptr %l545, !tbaa !24
  store i64 %t1128, ptr %l71, !tbaa !24
  %t1129 = load ptr, ptr %l0, !tbaa !29
  %t1131 = getelementptr %"compiler/bindgen:gen", ptr %t1129, i32 0, i32 6
  %t1132 = load i64, ptr %l70, !tbaa !24
  %t1135 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRefMu_Hc21bcd245b67ffb6ee3e145838fcf2cf(ptr %v0, ptr %v0, ptr %t1131, i64 %t1132)
  store ptr %t1135, ptr %l549
  br label %bb253
bb253:
  %t1136 = load ptr, ptr %l549, !tbaa !29
  %t1138 = load i64, ptr %l71, !tbaa !24
  %t1141 = getelementptr %"compiler/bindgen:record", ptr %t1136, i32 0, i32 14
  store i64 %t1138, ptr %t1141, !tbaa !24
  br label %bb254
bb254:
  call void @__olang_scope_close(ptr %s39)
  br label %bb255
bb255:
  %t1142 = load i64, ptr %l56, !tbaa !24
  %t1145 = add i64 %t1142, 1
  store i64 %t1145, ptr %l56, !tbaa !24
  br label %bb176
bb256:
  call void @__olang_scope_close(ptr %s38)
  store i64 0, ptr %l73, !tbaa !24
  %t1147 = load ptr, ptr %l0, !tbaa !29
  %t1149 = getelementptr %"compiler/bindgen:gen", ptr %t1147, i32 0, i32 6
  %t1151 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eLen_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %t1149)
  store i64 %t1151, ptr %l557
  br label %bb257
bb257:
  %t1152 = load i64, ptr %l557, !tbaa !24
  store i64 %t1152, ptr %l74, !tbaa !24
  store i64 1, ptr %l75, !tbaa !24
  %t1153 = load i64, ptr %l74, !tbaa !24
  %t1154 = load i64, ptr %l73, !tbaa !24
  %t1157 = icmp sgt i64 %t1153, %t1154
  br i1 %t1157, label %bb258, label %bb259
bb258:
  %t1159 = load i64, ptr %l75, !tbaa !24
  %t1161 = icmp sgt i64 %t1159, 0
  br i1 %t1161, label %bb260, label %bb261
bb259:
  store i64 0, ptr %l561, !tbaa !24
  br label %bb263
bb260:
  %t1163 = load i64, ptr %l74, !tbaa !24
  %t1164 = load i64, ptr %l73, !tbaa !24
  %t1167 = sub i64 %t1163, %t1164
  %t1168 = load i64, ptr %l75, !tbaa !24
  %t1171 = add i64 %t1167, %t1168
  %t1173 = sub i64 %t1171, 1
  %t1174 = load i64, ptr %l75, !tbaa !24
  %t1177 = sdiv i64 %t1173, %t1174
  store i64 %t1177, ptr %l564, !tbaa !24
  br label %bb262
bb261:
  store i64 0, ptr %l564, !tbaa !24
  br label %bb262
bb262:
  %t1179 = load i64, ptr %l564, !tbaa !24
  store i64 %t1179, ptr %l561, !tbaa !24
  br label %bb263
bb263:
  %t1180 = load i64, ptr %l561, !tbaa !24
  store i64 %t1180, ptr %l76, !tbaa !24
  store i64 0, ptr %l77, !tbaa !24
  br label %bb264
bb264:
  %t1181 = load i64, ptr %l77, !tbaa !24
  %t1182 = load i64, ptr %l76, !tbaa !24
  %t1185 = icmp slt i64 %t1181, %t1182
  %t1187 = xor i1 %t1185, true
  br i1 %t1187, label %bb265, label %bb266
bb265:
  br label %bb270
bb266:
  br label %bb267
bb267:
  %t1189 = load i64, ptr %l73, !tbaa !24
  %t1190 = load i64, ptr %l77, !tbaa !24
  %t1191 = load i64, ptr %l75, !tbaa !24
  %t1194 = mul i64 %t1190, %t1191
  %t1197 = add i64 %t1189, %t1194
  store i64 -1, ptr %l80, !tbaa !24
  %t1201 = load ptr, ptr %l0, !tbaa !29
  %t1203 = getelementptr %"compiler/bindgen:gen", ptr %t1201, i32 0, i32 6
  %t1207 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRefMu_Hc21bcd245b67ffb6ee3e145838fcf2cf(ptr %v0, ptr %v0, ptr %t1203, i64 %t1197)
  store ptr %t1207, ptr %l586
  br label %bb268
bb268:
  %t1208 = load ptr, ptr %l586, !tbaa !29
  %t1210 = load i64, ptr %l80, !tbaa !24
  %t1213 = getelementptr %"compiler/bindgen:record", ptr %t1208, i32 0, i32 9
  store i64 %t1210, ptr %t1213, !tbaa !24
  br label %bb269
bb269:
  %t1214 = load i64, ptr %l77, !tbaa !24
  %t1217 = add i64 %t1214, 1
  store i64 %t1217, ptr %l77, !tbaa !24
  br label %bb264
bb270:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2espell(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l6 = alloca ptr
  %l9 = alloca i1
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/bindgen:gen", ptr %a0, i32 0, i32 6
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRef_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l6, !tbaa !29
  store ptr %t8, ptr %l2, !tbaa !29
  %t9 = load ptr, ptr %l2, !tbaa !29
  %t11 = getelementptr %"compiler/bindgen:record", ptr %t9, i32 0, i32 11
  %t12 = load { i64, ptr }, ptr %t11, !tbaa !27
  %t14 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t12, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d328, i32 0, i32 1) })
  store i1 %t14, ptr %l9
  br label %bb2
bb2:
  %t15 = load i1, ptr %l9, !tbaa !21
  %t16 = xor i1 %t15, true
  br i1 %t16, label %bb3, label %bb4
bb3:
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t20 = getelementptr %"compiler/bindgen:record", ptr %t18, i32 0, i32 11
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = extractvalue { i64, ptr } %t21, 0
  %t25 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t24)
  call void @olang_textcopy(ptr %t25, ptr %t23, i64 %t24)
  %t26 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t27, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t31 = getelementptr %"compiler/bindgen:record", ptr %t29, i32 0, i32 0
  %t32 = load { i64, ptr }, ptr %t31, !tbaa !27
  store { i64, ptr } %t32, ptr %l16, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t34, 0
  store i64 %t35, ptr %l17, !tbaa !24
  %t36 = load i64, ptr %l17, !tbaa !24
  %t37 = mul i64 %t36, 1
  %t38 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t37)
  %t39 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  store { i64, ptr } %t40, ptr %l18, !tbaa !27
  %t41 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = load i64, ptr %l17, !tbaa !24
  %t46 = mul i64 %t45, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t42, ptr %t44, i64 %t46, i1 false)
  %t47 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t47, ptr %l16, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t48 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t48, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2etrack(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i1
  %l23 = alloca i64
  %l27 = alloca i64
  %l30 = alloca i64
  %l49 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l56 = alloca i1
  %l58 = alloca { i64, ptr }
  %l61 = alloca i1
  %l71 = alloca ptr
  %l72 = alloca i1
  %l84 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t2 = load ptr, ptr %l16, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l16, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 7
  store i1 %t8, ptr %l17, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l17, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { ptr }, ptr %t12, i32 0, i32 0
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb29
bb5:
  store i64 0, ptr %l4, !tbaa !24
  %t16 = load ptr, ptr %l3, !tbaa !29
  %t18 = call i64 @std_2fjson_2estd_2fjson_3aObject_2eLen(ptr %v1, ptr %t16)
  store i64 %t18, ptr %l23
  br label %bb6
bb6:
  %t19 = load i64, ptr %l23, !tbaa !24
  store i64 %t19, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t20 = load i64, ptr %l5, !tbaa !24
  %t21 = load i64, ptr %l4, !tbaa !24
  %t24 = icmp sgt i64 %t20, %t21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t26 = load i64, ptr %l6, !tbaa !24
  %t28 = icmp sgt i64 %t26, 0
  br i1 %t28, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb12
bb9:
  %t30 = load i64, ptr %l5, !tbaa !24
  %t31 = load i64, ptr %l4, !tbaa !24
  %t34 = sub i64 %t30, %t31
  %t35 = load i64, ptr %l6, !tbaa !24
  %t38 = add i64 %t34, %t35
  %t40 = sub i64 %t38, 1
  %t41 = load i64, ptr %l6, !tbaa !24
  %t44 = sdiv i64 %t40, %t41
  store i64 %t44, ptr %l30, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb11
bb11:
  %t46 = load i64, ptr %l30, !tbaa !24
  store i64 %t46, ptr %l27, !tbaa !24
  br label %bb12
bb12:
  %t47 = load i64, ptr %l27, !tbaa !24
  store i64 %t47, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t48 = load i64, ptr %l8, !tbaa !24
  %t49 = load i64, ptr %l7, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb28
bb15:
  br label %bb16
bb16:
  %t56 = load i64, ptr %l4, !tbaa !24
  %t57 = load i64, ptr %l8, !tbaa !24
  %t58 = load i64, ptr %l6, !tbaa !24
  %t61 = mul i64 %t57, %t58
  %t64 = add i64 %t56, %t61
  store i64 %t64, ptr %l9, !tbaa !24
  %t66 = load ptr, ptr %l3, !tbaa !29
  %t68 = getelementptr %"std/json:Object", ptr %t66, i32 0, i32 1
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  store { i64, ptr } %t69, ptr %l49, !tbaa !27
  %t70 = load i64, ptr %l9, !tbaa !24
  %t72 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr ptr, ptr %t73, i64 %t70
  %t75 = load ptr, ptr %t74, !tbaa !39
  store ptr %t75, ptr %l10, !tbaa !29
  %t77 = load ptr, ptr %l3, !tbaa !29
  %t79 = getelementptr %"std/json:Object", ptr %t77, i32 0, i32 0
  %t80 = load { i64, ptr }, ptr %t79, !tbaa !27
  store { i64, ptr } %t80, ptr %l53, !tbaa !27
  %t81 = load i64, ptr %l9, !tbaa !24
  %t83 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !27
  %t85 = getelementptr { i64, ptr }, ptr %t84, i64 %t81
  %t86 = load { i64, ptr }, ptr %t85, !tbaa !37
  %t88 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s3, { i64, ptr } %t86, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d329, i32 0, i32 1) })
  store i1 %t88, ptr %l56
  br label %bb17
bb17:
  %t89 = load i1, ptr %l56, !tbaa !21
  br i1 %t89, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb27
bb19:
  br label %bb20
bb20:
  %t90 = load ptr, ptr %l3, !tbaa !29
  %t92 = getelementptr %"std/json:Object", ptr %t90, i32 0, i32 0
  %t93 = load { i64, ptr }, ptr %t92, !tbaa !27
  store { i64, ptr } %t93, ptr %l58, !tbaa !27
  %t94 = load i64, ptr %l9, !tbaa !24
  %t96 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = getelementptr { i64, ptr }, ptr %t97, i64 %t94
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !37
  %t101 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s3, { i64, ptr } %t99, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d330, i32 0, i32 1) })
  store i1 %t101, ptr %l61
  br label %bb21
bb21:
  %t102 = load i1, ptr %l61, !tbaa !21
  br i1 %t102, label %bb22, label %bb23
bb22:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load ptr, ptr %l10, !tbaa !29
  %t105 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2etrackFile(ptr %v0, ptr %v1, ptr %v2, ptr %t103, ptr %t104, { i64, ptr } %t105)
  br label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_scope_close(ptr %s3)
  br label %bb27
bb25:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load ptr, ptr %l10, !tbaa !29
  %t111 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2etrack(ptr %v0, ptr %v1, ptr %v2, ptr %t109, ptr %t110, { i64, ptr } %t111)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s3)
  br label %bb27
bb27:
  %t115 = load i64, ptr %l8, !tbaa !24
  %t118 = add i64 %t115, 1
  store i64 %t118, ptr %l8, !tbaa !24
  br label %bb13
bb28:
  br label %bb47
bb29:
  %t120 = load ptr, ptr %l1, !tbaa !29
  store ptr %t120, ptr %l71, !tbaa !29
  store i1 false, ptr %l72, !tbaa !21
  %t121 = load ptr, ptr %l71, !tbaa !29
  %t122 = icmp ne ptr %t121, null
  br i1 %t122, label %bb30, label %bb31
bb30:
  %t124 = load ptr, ptr %l71, !tbaa !29
  %t125 = load i64, ptr %t124, !range !{i64 0, i64 8}
  %t127 = icmp eq i64 %t125, 6
  store i1 %t127, ptr %l72, !tbaa !21
  br label %bb31
bb31:
  %t128 = load i1, ptr %l72, !tbaa !21
  br i1 %t128, label %bb32, label %bb33
bb32:
  %t129 = load ptr, ptr %l1, !tbaa !29
  %t131 = getelementptr { i64, [2 x i64] }, ptr %t129, i32 0, i32 1
  %t132 = getelementptr { { i64, ptr } }, ptr %t131, i32 0, i32 0
  %t133 = load { i64, ptr }, ptr %t132
  store { i64, ptr } %t133, ptr %l11, !tbaa !27
  br label %bb34
bb33:
  br label %bb42
bb34:
  %t135 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t135, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t137 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t139 = extractvalue { i64, ptr } %t137, 0
  store i64 %t139, ptr %l14, !tbaa !24
  br label %bb35
bb35:
  %t141 = load i64, ptr %l13, !tbaa !24
  %t142 = load i64, ptr %l14, !tbaa !24
  %t145 = icmp slt i64 %t141, %t142
  %t147 = xor i1 %t145, true
  br i1 %t147, label %bb36, label %bb37
bb36:
  br label %bb41
bb37:
  br label %bb38
bb38:
  %t149 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t149, ptr %l84, !tbaa !27
  %t150 = load i64, ptr %l13, !tbaa !24
  %t152 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = getelementptr ptr, ptr %t153, i64 %t150
  %t155 = load ptr, ptr %t154, !tbaa !39
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2etrack(ptr %v0, ptr %v1, ptr %v2, ptr %t157, ptr %t155, { i64, ptr } %t159)
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t163 = load i64, ptr %l13, !tbaa !24
  %t166 = add i64 %t163, 1
  store i64 %t166, ptr %l13, !tbaa !24
  br label %bb35
bb41:
  br label %bb47
bb42:
  br i1 true, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb47
bb46:
  call void @__olang_check_failed(ptr @olang_loc_c54e19abcb0a74ad_a74456fc2d527de1)
  unreachable
bb47:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2etrackFile(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca i1
  %l10 = alloca ptr
  %l14 = alloca i1
  %l15 = alloca i64
  %l18 = alloca i1
  %l19 = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 5
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { { i64, ptr } }, ptr %t12, i32 0, i32 0
  %t14 = load { i64, ptr }, ptr %t13
  store { i64, ptr } %t14, ptr %l3, !tbaa !27
  br label %bb5
bb4:
  br label %bb14
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l10, !tbaa !29
  %t17 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/bindgen:gen", ptr %t18, i32 0, i32 0
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  %t24 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %v0, { i64, ptr } %t17, { i64, ptr } %t21)
  store i1 %t24, ptr %l14
  br label %bb6
bb6:
  %t25 = load i1, ptr %l14, !tbaa !21
  br i1 %t25, label %bb7, label %bb8
bb7:
  store i64 1, ptr %l15, !tbaa !24
  br label %bb13
bb8:
  %t26 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t30 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %v2, { i64, ptr } %t26, { i64, ptr } %a2)
  store i1 %t30, ptr %l18
  br label %bb9
bb9:
  %t31 = load i1, ptr %l18, !tbaa !21
  br i1 %t31, label %bb10, label %bb11
bb10:
  store i64 2, ptr %l19, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb12
bb12:
  %t32 = load i64, ptr %l19, !tbaa !24
  store i64 %t32, ptr %l15, !tbaa !24
  br label %bb13
bb13:
  %t33 = load i64, ptr %l15, !tbaa !24
  %t34 = load ptr, ptr %l10, !tbaa !29
  %t35 = getelementptr %"compiler/bindgen:gen", ptr %t34, i32 0, i32 27
  store i64 %t33, ptr %t35, !tbaa !24
  br label %bb19
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_3dee357bb9e78e13_5fc101397bdf658f)
  unreachable
bb19:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eunionFlat(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, i1 %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca %"compiler/bindgen:record"
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l16 = alloca %"compiler/bindgen:record"
  %l17 = alloca %"compiler/bindgen:record"
  %l18 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l26 = alloca i64
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca { i64, ptr }
  %l34 = alloca i64
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca { i64, ptr }
  %l42 = alloca i64
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l46 = alloca { i64, ptr }
  %l50 = alloca i64
  %l52 = alloca { i64, ptr }
  %l53 = alloca i64
  %l54 = alloca { i64, ptr }
  %l58 = alloca i64
  %l60 = alloca { i64, ptr }
  %l61 = alloca i64
  %l62 = alloca { i64, ptr }
  %l67 = alloca i64
  %l71 = alloca i64
  %l74 = alloca i64
  %l92 = alloca i64
  %l94 = alloca i64
  %l96 = alloca i64
  %l99 = alloca i64
  %l102 = alloca { i64, ptr }
  %l103 = alloca i1
  %l105 = alloca i1
  %l107 = alloca ptr
  %l110 = alloca { i64, ptr }
  %l111 = alloca ptr
  %l114 = alloca { i64, ptr }
  %l117 = alloca { i64, ptr }
  %l118 = alloca i1
  %l119 = alloca i1
  %l122 = alloca i1
  %l125 = alloca ptr
  %l126 = alloca i64
  %l130 = alloca %"compiler/bindgen:record"
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %t5 = alloca %"compiler/bindgen:record", align 8
  %t408 = alloca %"compiler/bindgen:record", align 8
  store ptr %a0, ptr %l0
  store i1 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/bindgen:gen", ptr %t1, i32 0, i32 6
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t5, ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  call void @llvm.memmove.p0.p0.i64(ptr %l16, ptr %t5, i64 312, i1 false)
  br label %bb1
bb1:
  call void @llvm.memmove.p0.p0.i64(ptr %l17, ptr %l16, i64 312, i1 false)
  %t8 = call ptr @__olang_scope_hold(ptr %v0)
  %t9 = ptrtoint ptr %t8 to i64
  store i64 %t9, ptr %l18, !tbaa !24
  %t10 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = call ptr @__olang_region_make_part(ptr %v0)
  %t13 = ptrtoint ptr %t12 to i64
  store i64 %t13, ptr %l18, !tbaa !24
  br label %bb3
bb3:
  %t14 = getelementptr %"compiler/bindgen:record", ptr %l17, i32 0, i32 4
  %t15 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t14, i32 0, i32 0
  %t16 = load { i64, ptr }, ptr %t15, !tbaa !27
  store { i64, ptr } %t16, ptr %l20, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t17, 0
  store i64 %t18, ptr %l21, !tbaa !24
  %t19 = load i64, ptr %l21, !tbaa !24
  %t20 = mul i64 %t19, 16
  %t21 = load i64, ptr %l18
  %t22 = inttoptr i64 %t21 to ptr
  %t23 = call ptr @__olang_held_alloc(ptr %t22, i64 %t20)
  %t24 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  store { i64, ptr } %t25, ptr %l22, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = load i64, ptr %l21, !tbaa !24
  %t31 = mul i64 %t30, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t27, ptr %t29, i64 %t31, i1 false)
  %t32 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t33 = getelementptr %"compiler/bindgen:record", ptr %l17, i32 0, i32 4
  %t34 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t33, i32 0, i32 0
  store { i64, ptr } %t32, ptr %t34, !tbaa !27
  %t35 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t35, label %bb4, label %bb5
bb4:
  %t37 = getelementptr %"compiler/bindgen:record", ptr %l17, i32 0, i32 4
  %t38 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t37, i32 0, i32 0
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  %t42 = icmp eq i64 %t40, 0
  br i1 %t42, label %bb6, label %bb7
bb5:
  %t44 = call ptr @__olang_scope_hold(ptr %v0)
  %t45 = ptrtoint ptr %t44 to i64
  store i64 %t45, ptr %l26, !tbaa !24
  %t46 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t46, label %bb8, label %bb9
bb6:
  %t48 = getelementptr %"compiler/bindgen:record", ptr %l17, i32 0, i32 4
  %t49 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t49, !tbaa !27
  br label %bb7
bb7:
  %t50 = getelementptr %"compiler/bindgen:record", ptr %l17, i32 0, i32 4
  %t51 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t50, i32 0, i32 0
  %t52 = load i64, ptr %l18
  %t53 = inttoptr i64 %t52 to ptr
  %t54 = load { i64, ptr }, ptr %t51
  %t55 = extractvalue { i64, ptr } %t54, 1
  %t56 = call ptr @__olang_region_or(ptr %t55, ptr null)
  %t57 = icmp ne ptr %t56, null
  %t58 = select i1 %t57, ptr %t56, ptr null
  call void @__olang_region_settle_in(ptr %t53, ptr %t58)
  br label %bb5
bb8:
  %t59 = call ptr @__olang_region_make_part(ptr %v0)
  %t60 = ptrtoint ptr %t59 to i64
  store i64 %t60, ptr %l26, !tbaa !24
  br label %bb9
bb9:
  %t61 = getelementptr %"compiler/bindgen:record", ptr %l17, i32 0, i32 5
  %t62 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t61, i32 0, i32 0
  %t63 = load { i64, ptr }, ptr %t62, !tbaa !27
  store { i64, ptr } %t63, ptr %l28, !tbaa !27
  %t64 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l29, !tbaa !24
  %t66 = load i64, ptr %l29, !tbaa !24
  %t67 = mul i64 %t66, 16
  %t68 = load i64, ptr %l26
  %t69 = inttoptr i64 %t68 to ptr
  %t70 = call ptr @__olang_held_alloc(ptr %t69, i64 %t67)
  %t71 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t70, 1
  store { i64, ptr } %t72, ptr %l30, !tbaa !27
  %t73 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l29, !tbaa !24
  %t78 = mul i64 %t77, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t74, ptr %t76, i64 %t78, i1 false)
  %t79 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t80 = getelementptr %"compiler/bindgen:record", ptr %l17, i32 0, i32 5
  %t81 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t80, i32 0, i32 0
  store { i64, ptr } %t79, ptr %t81, !tbaa !27
  %t82 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t82, label %bb10, label %bb11
bb10:
  %t84 = getelementptr %"compiler/bindgen:record", ptr %l17, i32 0, i32 5
  %t85 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t84, i32 0, i32 0
  %t86 = load { i64, ptr }, ptr %t85, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t86, 0
  %t89 = icmp eq i64 %t87, 0
  br i1 %t89, label %bb12, label %bb13
bb11:
  %t91 = call ptr @__olang_scope_hold(ptr %v0)
  %t92 = ptrtoint ptr %t91 to i64
  store i64 %t92, ptr %l34, !tbaa !24
  %t93 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t93, label %bb14, label %bb15
bb12:
  %t95 = getelementptr %"compiler/bindgen:record", ptr %l17, i32 0, i32 5
  %t96 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t95, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t96, !tbaa !27
  br label %bb13
bb13:
  %t97 = getelementptr %"compiler/bindgen:record", ptr %l17, i32 0, i32 5
  %t98 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t97, i32 0, i32 0
  %t99 = load i64, ptr %l26
  %t100 = inttoptr i64 %t99 to ptr
  %t101 = load { i64, ptr }, ptr %t98
  %t102 = extractvalue { i64, ptr } %t101, 1
  %t103 = call ptr @__olang_region_or(ptr %t102, ptr null)
  %t104 = icmp ne ptr %t103, null
  %t105 = select i1 %t104, ptr %t103, ptr null
  call void @__olang_region_settle_in(ptr %t100, ptr %t105)
  br label %bb11
bb14:
  %t106 = call ptr @__olang_region_make_part(ptr %v0)
  %t107 = ptrtoint ptr %t106 to i64
  store i64 %t107, ptr %l34, !tbaa !24
  br label %bb15
bb15:
  %t108 = getelementptr %"compiler/bindgen:record", ptr %l17, i32 0, i32 16
  %t109 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t108, i32 0, i32 0
  %t110 = load { i64, ptr }, ptr %t109, !tbaa !27
  store { i64, ptr } %t110, ptr %l36, !tbaa !27
  %t111 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t111, 0
  store i64 %t112, ptr %l37, !tbaa !24
  %t113 = load i64, ptr %l37, !tbaa !24
  %t114 = mul i64 %t113, 8
  %t115 = load i64, ptr %l34
  %t116 = inttoptr i64 %t115 to ptr
  %t117 = call ptr @__olang_held_alloc(ptr %t116, i64 %t114)
  %t118 = insertvalue { i64, ptr } undef, i64 %t113, 0
  %t119 = insertvalue { i64, ptr } %t118, ptr %t117, 1
  store { i64, ptr } %t119, ptr %l38, !tbaa !27
  %t120 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !27
  %t122 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !27
  %t124 = load i64, ptr %l37, !tbaa !24
  %t125 = mul i64 %t124, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t121, ptr %t123, i64 %t125, i1 false)
  %t126 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t127 = getelementptr %"compiler/bindgen:record", ptr %l17, i32 0, i32 16
  %t128 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t127, i32 0, i32 0
  store { i64, ptr } %t126, ptr %t128, !tbaa !27
  %t129 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t129, label %bb16, label %bb17
bb16:
  %t131 = getelementptr %"compiler/bindgen:record", ptr %l17, i32 0, i32 16
  %t132 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t131, i32 0, i32 0
  %t133 = load { i64, ptr }, ptr %t132, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t133, 0
  %t136 = icmp eq i64 %t134, 0
  br i1 %t136, label %bb18, label %bb19
bb17:
  %t138 = call ptr @__olang_scope_hold(ptr %v0)
  %t139 = ptrtoint ptr %t138 to i64
  store i64 %t139, ptr %l42, !tbaa !24
  %t140 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t140, label %bb20, label %bb21
bb18:
  %t142 = getelementptr %"compiler/bindgen:record", ptr %l17, i32 0, i32 16
  %t143 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t142, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t143, !tbaa !27
  br label %bb19
bb19:
  %t144 = getelementptr %"compiler/bindgen:record", ptr %l17, i32 0, i32 16
  %t145 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t144, i32 0, i32 0
  %t146 = load i64, ptr %l34
  %t147 = inttoptr i64 %t146 to ptr
  %t148 = load { i64, ptr }, ptr %t145
  %t149 = extractvalue { i64, ptr } %t148, 1
  %t150 = call ptr @__olang_region_or(ptr %t149, ptr null)
  %t151 = icmp ne ptr %t150, null
  %t152 = select i1 %t151, ptr %t150, ptr null
  call void @__olang_region_settle_in(ptr %t147, ptr %t152)
  br label %bb17
bb20:
  %t153 = call ptr @__olang_region_make_part(ptr %v0)
  %t154 = ptrtoint ptr %t153 to i64
  store i64 %t154, ptr %l42, !tbaa !24
  br label %bb21
bb21:
  %t155 = getelementptr %"compiler/bindgen:record", ptr %l17, i32 0, i32 17
  %t156 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t155, i32 0, i32 0
  %t157 = load { i64, ptr }, ptr %t156, !tbaa !27
  store { i64, ptr } %t157, ptr %l44, !tbaa !27
  %t158 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t159 = extractvalue { i64, ptr } %t158, 0
  store i64 %t159, ptr %l45, !tbaa !24
  %t160 = load i64, ptr %l45, !tbaa !24
  %t161 = mul i64 %t160, 8
  %t162 = load i64, ptr %l42
  %t163 = inttoptr i64 %t162 to ptr
  %t164 = call ptr @__olang_held_alloc(ptr %t163, i64 %t161)
  %t165 = insertvalue { i64, ptr } undef, i64 %t160, 0
  %t166 = insertvalue { i64, ptr } %t165, ptr %t164, 1
  store { i64, ptr } %t166, ptr %l46, !tbaa !27
  %t167 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t168 = load ptr, ptr %t167, !tbaa !27
  %t169 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !27
  %t171 = load i64, ptr %l45, !tbaa !24
  %t172 = mul i64 %t171, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t168, ptr %t170, i64 %t172, i1 false)
  %t173 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t174 = getelementptr %"compiler/bindgen:record", ptr %l17, i32 0, i32 17
  %t175 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t174, i32 0, i32 0
  store { i64, ptr } %t173, ptr %t175, !tbaa !27
  %t176 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t176, label %bb22, label %bb23
bb22:
  %t178 = getelementptr %"compiler/bindgen:record", ptr %l17, i32 0, i32 17
  %t179 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t178, i32 0, i32 0
  %t180 = load { i64, ptr }, ptr %t179, !tbaa !27
  %t181 = extractvalue { i64, ptr } %t180, 0
  %t183 = icmp eq i64 %t181, 0
  br i1 %t183, label %bb24, label %bb25
bb23:
  %t185 = call ptr @__olang_scope_hold(ptr %v0)
  %t186 = ptrtoint ptr %t185 to i64
  store i64 %t186, ptr %l50, !tbaa !24
  %t187 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t187, label %bb26, label %bb27
bb24:
  %t189 = getelementptr %"compiler/bindgen:record", ptr %l17, i32 0, i32 17
  %t190 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t189, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t190, !tbaa !27
  br label %bb25
bb25:
  %t191 = getelementptr %"compiler/bindgen:record", ptr %l17, i32 0, i32 17
  %t192 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t191, i32 0, i32 0
  %t193 = load i64, ptr %l42
  %t194 = inttoptr i64 %t193 to ptr
  %t195 = load { i64, ptr }, ptr %t192
  %t196 = extractvalue { i64, ptr } %t195, 1
  %t197 = call ptr @__olang_region_or(ptr %t196, ptr null)
  %t198 = icmp ne ptr %t197, null
  %t199 = select i1 %t198, ptr %t197, ptr null
  call void @__olang_region_settle_in(ptr %t194, ptr %t199)
  br label %bb23
bb26:
  %t200 = call ptr @__olang_region_make_part(ptr %v0)
  %t201 = ptrtoint ptr %t200 to i64
  store i64 %t201, ptr %l50, !tbaa !24
  br label %bb27
bb27:
  %t202 = getelementptr %"compiler/bindgen:record", ptr %l17, i32 0, i32 18
  %t203 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t202, i32 0, i32 0
  %t204 = load { i64, ptr }, ptr %t203, !tbaa !27
  store { i64, ptr } %t204, ptr %l52, !tbaa !27
  %t205 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t206 = extractvalue { i64, ptr } %t205, 0
  store i64 %t206, ptr %l53, !tbaa !24
  %t207 = load i64, ptr %l53, !tbaa !24
  %t208 = mul i64 %t207, 8
  %t209 = load i64, ptr %l50
  %t210 = inttoptr i64 %t209 to ptr
  %t211 = call ptr @__olang_held_alloc(ptr %t210, i64 %t208)
  %t212 = insertvalue { i64, ptr } undef, i64 %t207, 0
  %t213 = insertvalue { i64, ptr } %t212, ptr %t211, 1
  store { i64, ptr } %t213, ptr %l54, !tbaa !27
  %t214 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !27
  %t216 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t217 = load ptr, ptr %t216, !tbaa !27
  %t218 = load i64, ptr %l53, !tbaa !24
  %t219 = mul i64 %t218, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t215, ptr %t217, i64 %t219, i1 false)
  %t220 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t221 = getelementptr %"compiler/bindgen:record", ptr %l17, i32 0, i32 18
  %t222 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t221, i32 0, i32 0
  store { i64, ptr } %t220, ptr %t222, !tbaa !27
  %t223 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t223, label %bb28, label %bb29
bb28:
  %t225 = getelementptr %"compiler/bindgen:record", ptr %l17, i32 0, i32 18
  %t226 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t225, i32 0, i32 0
  %t227 = load { i64, ptr }, ptr %t226, !tbaa !27
  %t228 = extractvalue { i64, ptr } %t227, 0
  %t230 = icmp eq i64 %t228, 0
  br i1 %t230, label %bb30, label %bb31
bb29:
  %t232 = call ptr @__olang_scope_hold(ptr %v0)
  %t233 = ptrtoint ptr %t232 to i64
  store i64 %t233, ptr %l58, !tbaa !24
  %t234 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t234, label %bb32, label %bb33
bb30:
  %t236 = getelementptr %"compiler/bindgen:record", ptr %l17, i32 0, i32 18
  %t237 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t236, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t237, !tbaa !27
  br label %bb31
bb31:
  %t238 = getelementptr %"compiler/bindgen:record", ptr %l17, i32 0, i32 18
  %t239 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t238, i32 0, i32 0
  %t240 = load i64, ptr %l50
  %t241 = inttoptr i64 %t240 to ptr
  %t242 = load { i64, ptr }, ptr %t239
  %t243 = extractvalue { i64, ptr } %t242, 1
  %t244 = call ptr @__olang_region_or(ptr %t243, ptr null)
  %t245 = icmp ne ptr %t244, null
  %t246 = select i1 %t245, ptr %t244, ptr null
  call void @__olang_region_settle_in(ptr %t241, ptr %t246)
  br label %bb29
bb32:
  %t247 = call ptr @__olang_region_make_part(ptr %v0)
  %t248 = ptrtoint ptr %t247 to i64
  store i64 %t248, ptr %l58, !tbaa !24
  br label %bb33
bb33:
  %t249 = getelementptr %"compiler/bindgen:record", ptr %l17, i32 0, i32 19
  %t250 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t249, i32 0, i32 0
  %t251 = load { i64, ptr }, ptr %t250, !tbaa !27
  store { i64, ptr } %t251, ptr %l60, !tbaa !27
  %t252 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t253 = extractvalue { i64, ptr } %t252, 0
  store i64 %t253, ptr %l61, !tbaa !24
  %t254 = load i64, ptr %l61, !tbaa !24
  %t255 = mul i64 %t254, 8
  %t256 = load i64, ptr %l58
  %t257 = inttoptr i64 %t256 to ptr
  %t258 = call ptr @__olang_held_alloc(ptr %t257, i64 %t255)
  %t259 = insertvalue { i64, ptr } undef, i64 %t254, 0
  %t260 = insertvalue { i64, ptr } %t259, ptr %t258, 1
  store { i64, ptr } %t260, ptr %l62, !tbaa !27
  %t261 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t262 = load ptr, ptr %t261, !tbaa !27
  %t263 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t264 = load ptr, ptr %t263, !tbaa !27
  %t265 = load i64, ptr %l61, !tbaa !24
  %t266 = mul i64 %t265, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t262, ptr %t264, i64 %t266, i1 false)
  %t267 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t268 = getelementptr %"compiler/bindgen:record", ptr %l17, i32 0, i32 19
  %t269 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t268, i32 0, i32 0
  store { i64, ptr } %t267, ptr %t269, !tbaa !27
  %t270 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t270, label %bb34, label %bb35
bb34:
  %t272 = getelementptr %"compiler/bindgen:record", ptr %l17, i32 0, i32 19
  %t273 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t272, i32 0, i32 0
  %t274 = load { i64, ptr }, ptr %t273, !tbaa !27
  %t275 = extractvalue { i64, ptr } %t274, 0
  %t277 = icmp eq i64 %t275, 0
  br i1 %t277, label %bb36, label %bb37
bb35:
  call void @llvm.memmove.p0.p0.i64(ptr %l5, ptr %l17, i64 312, i1 false)
  store i64 0, ptr %l6, !tbaa !24
  %t279 = getelementptr %"compiler/bindgen:record", ptr %l5, i32 0, i32 4
  %t281 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t279)
  store i64 %t281, ptr %l67
  br label %bb38
bb36:
  %t282 = getelementptr %"compiler/bindgen:record", ptr %l17, i32 0, i32 19
  %t283 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t282, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t283, !tbaa !27
  br label %bb37
bb37:
  %t284 = getelementptr %"compiler/bindgen:record", ptr %l17, i32 0, i32 19
  %t285 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t284, i32 0, i32 0
  %t286 = load i64, ptr %l58
  %t287 = inttoptr i64 %t286 to ptr
  %t288 = load { i64, ptr }, ptr %t285
  %t289 = extractvalue { i64, ptr } %t288, 1
  %t290 = call ptr @__olang_region_or(ptr %t289, ptr null)
  %t291 = icmp ne ptr %t290, null
  %t292 = select i1 %t291, ptr %t290, ptr null
  call void @__olang_region_settle_in(ptr %t287, ptr %t292)
  br label %bb35
bb38:
  %t293 = load i64, ptr %l67, !tbaa !24
  store i64 %t293, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t294 = load i64, ptr %l7, !tbaa !24
  %t295 = load i64, ptr %l6, !tbaa !24
  %t298 = icmp sgt i64 %t294, %t295
  br i1 %t298, label %bb39, label %bb40
bb39:
  %t300 = load i64, ptr %l8, !tbaa !24
  %t302 = icmp sgt i64 %t300, 0
  br i1 %t302, label %bb41, label %bb42
bb40:
  store i64 0, ptr %l71, !tbaa !24
  br label %bb44
bb41:
  %t304 = load i64, ptr %l7, !tbaa !24
  %t305 = load i64, ptr %l6, !tbaa !24
  %t308 = sub i64 %t304, %t305
  %t309 = load i64, ptr %l8, !tbaa !24
  %t312 = add i64 %t308, %t309
  %t314 = sub i64 %t312, 1
  %t315 = load i64, ptr %l8, !tbaa !24
  %t318 = sdiv i64 %t314, %t315
  store i64 %t318, ptr %l74, !tbaa !24
  br label %bb43
bb42:
  store i64 0, ptr %l74, !tbaa !24
  br label %bb43
bb43:
  %t320 = load i64, ptr %l74, !tbaa !24
  store i64 %t320, ptr %l71, !tbaa !24
  br label %bb44
bb44:
  %t321 = load i64, ptr %l71, !tbaa !24
  store i64 %t321, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb45
bb45:
  store %olang.scope zeroinitializer, ptr %s2
  %t322 = load i64, ptr %l10, !tbaa !24
  %t323 = load i64, ptr %l9, !tbaa !24
  %t326 = icmp slt i64 %t322, %t323
  %t328 = xor i1 %t326, true
  br i1 %t328, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s2)
  br label %bb80
bb47:
  br label %bb48
bb48:
  %t330 = load i64, ptr %l6, !tbaa !24
  %t331 = load i64, ptr %l10, !tbaa !24
  %t332 = load i64, ptr %l8, !tbaa !24
  %t335 = mul i64 %t331, %t332
  %t338 = add i64 %t330, %t335
  store i64 %t338, ptr %l11, !tbaa !24
  %t340 = load i64, ptr %l11, !tbaa !24
  store i64 %t340, ptr %l92, !tbaa !24
  %t341 = getelementptr %"compiler/bindgen:record", ptr %l5, i32 0, i32 17
  %t343 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t341)
  store i64 %t343, ptr %l94
  br label %bb49
bb49:
  %t344 = load i64, ptr %l92, !tbaa !24
  %t345 = load i64, ptr %l94, !tbaa !24
  %t346 = icmp slt i64 %t344, %t345
  br i1 %t346, label %bb50, label %bb51
bb50:
  %t348 = getelementptr %"compiler/bindgen:record", ptr %l5, i32 0, i32 17
  %t349 = load i64, ptr %l11, !tbaa !24
  %t352 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t348, i64 %t349)
  store i64 %t352, ptr %l99
  br label %bb52
bb51:
  store i64 -1, ptr %l96, !tbaa !24
  br label %bb53
bb52:
  %t353 = load i64, ptr %l99, !tbaa !24
  store i64 %t353, ptr %l96, !tbaa !24
  br label %bb53
bb53:
  %t354 = load i64, ptr %l96, !tbaa !24
  store i64 %t354, ptr %l12, !tbaa !24
  %t355 = getelementptr %"compiler/bindgen:record", ptr %l5, i32 0, i32 4
  %t356 = load i64, ptr %l11, !tbaa !24
  %t359 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t355, i64 %t356)
  store { i64, ptr } %t359, ptr %l102
  br label %bb54
bb54:
  %t360 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t361 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t360, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d331, i32 0, i32 1) })
  store i1 %t361, ptr %l103
  br label %bb55
bb55:
  %t362 = load i1, ptr %l103, !tbaa !21
  %t363 = xor i1 %t362, true
  br i1 %t363, label %bb56, label %bb57
bb56:
  %t365 = load i1, ptr %l2, !tbaa !21
  store i1 %t365, ptr %l105, !tbaa !21
  br label %bb58
bb57:
  store i1 false, ptr %l105, !tbaa !21
  br label %bb58
bb58:
  %t367 = load i1, ptr %l105, !tbaa !21
  br i1 %t367, label %bb59, label %bb60
bb59:
  %t368 = load ptr, ptr %l3, !tbaa !29
  store ptr %t368, ptr %l107, !tbaa !29
  %t369 = getelementptr %"compiler/bindgen:record", ptr %l5, i32 0, i32 4
  %t370 = load i64, ptr %l11, !tbaa !24
  %t373 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t369, i64 %t370)
  store { i64, ptr } %t373, ptr %l110
  br label %bb61
bb60:
  store %olang.scope zeroinitializer, ptr %s4
  %t374 = getelementptr %"compiler/bindgen:record", ptr %l5, i32 0, i32 4
  %t375 = load i64, ptr %l11, !tbaa !24
  %t378 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t374, i64 %t375)
  store { i64, ptr } %t378, ptr %l117
  br label %bb65
bb61:
  %t379 = load ptr, ptr %l107, !tbaa !29
  %t380 = load { i64, ptr }, ptr %l110, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v0, ptr %t379, { i64, ptr } %t380)
  br label %bb62
bb62:
  %t381 = load ptr, ptr %l4, !tbaa !29
  store ptr %t381, ptr %l111, !tbaa !29
  %t382 = getelementptr %"compiler/bindgen:record", ptr %l5, i32 0, i32 5
  %t383 = load i64, ptr %l11, !tbaa !24
  %t386 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t382, i64 %t383)
  store { i64, ptr } %t386, ptr %l114
  br label %bb63
bb63:
  %t387 = load ptr, ptr %l111, !tbaa !29
  %t388 = load { i64, ptr }, ptr %l114, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v2, ptr %v0, ptr %t387, { i64, ptr } %t388)
  br label %bb64
bb64:
  br label %bb78
bb65:
  %t389 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t390 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s4, { i64, ptr } %t389, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d332, i32 0, i32 1) })
  store i1 %t390, ptr %l118
  br label %bb66
bb66:
  %t391 = load i1, ptr %l118, !tbaa !21
  br i1 %t391, label %bb67, label %bb68
bb67:
  %t392 = load i64, ptr %l12, !tbaa !24
  %t394 = icmp sge i64 %t392, 0
  store i1 %t394, ptr %l119, !tbaa !21
  br label %bb69
bb68:
  store i1 false, ptr %l119, !tbaa !21
  br label %bb69
bb69:
  %t396 = load i1, ptr %l119, !tbaa !21
  br i1 %t396, label %bb70, label %bb71
bb70:
  %t397 = load i1, ptr %l2, !tbaa !21
  %t399 = xor i1 %t397, true
  store i1 %t399, ptr %l122, !tbaa !21
  br label %bb72
bb71:
  store i1 false, ptr %l122, !tbaa !21
  br label %bb72
bb72:
  %t401 = load i1, ptr %l122, !tbaa !21
  br i1 %t401, label %bb73, label %bb74
bb73:
  store %olang.scope zeroinitializer, ptr %s5
  %t402 = load ptr, ptr %l0, !tbaa !29
  store ptr %t402, ptr %l125, !tbaa !29
  %t403 = load i64, ptr %l12, !tbaa !24
  store i64 %t403, ptr %l126, !tbaa !24
  %t404 = load ptr, ptr %l0, !tbaa !29
  %t406 = getelementptr %"compiler/bindgen:gen", ptr %t404, i32 0, i32 6
  %t407 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %t408, ptr %v0, ptr %s5, ptr %t406, i64 %t407)
  call void @llvm.memmove.p0.p0.i64(ptr %l130, ptr %t408, i64 312, i1 false)
  br label %bb75
bb74:
  br label %bb77
bb75:
  %t411 = getelementptr %"compiler/bindgen:record", ptr %l130, i32 0, i32 1
  %t412 = load i1, ptr %t411, !tbaa !21
  %t413 = load ptr, ptr %l3, !tbaa !29
  %t414 = load ptr, ptr %l4, !tbaa !29
  %t415 = load ptr, ptr %l125, !tbaa !29
  %t416 = load i64, ptr %l126, !tbaa !24
  call void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eunionFlat(ptr %v0, ptr %v1, ptr %v2, ptr %t415, i64 %t416, i1 %t412, ptr %t413, ptr %t414)
  br label %bb76
bb76:
  call void @__olang_scope_close(ptr %s5)
  br label %bb77
bb77:
  call void @__olang_scope_close(ptr %s4)
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s2)
  br label %bb79
bb79:
  %t420 = load i64, ptr %l10, !tbaa !24
  %t423 = add i64 %t420, 1
  store i64 %t423, ptr %l10, !tbaa !24
  br label %bb45
bb80:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ewanted(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l4 = alloca i1
  %l7 = alloca i1
  %rv = alloca i1
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp eq i64 %t1, 1
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb6
bb2:
  %t7 = getelementptr %"compiler/bindgen:gen", ptr %a0, i32 0, i32 1
  %t8 = load i1, ptr %t7, !tbaa !21
  br i1 %t8, label %bb3, label %bb4
bb3:
  %t10 = load i64, ptr %l1, !tbaa !24
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l7, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l7, !tbaa !21
  store i1 %t14, ptr %l4, !tbaa !21
  br label %bb6
bb6:
  %t15 = load i1, ptr %l4, !tbaa !21
  store i1 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fbindgen_2efirstError(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"std/prelude/text:LineIter"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l5 = alloca %"std/prelude/text:LineIter"
  %l6 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i32
  %l11 = alloca i1
  %l12 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %l18 = alloca { i64, ptr }
  %l20 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l31 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v0, { i64, ptr } %t1)
  store %"std/prelude/text:LineIter" %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load %"std/prelude/text:LineIter", ptr %l5
  store %"std/prelude/text:LineIter" %t4, ptr %l1
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t6 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v0, ptr %l1)
  %t7 = extractvalue { i32, { i64, ptr } } %t6, 1
  %t8 = extractvalue { i32, { i64, ptr } } %t6, 0
  store i32 %t8, ptr %l9
  %t9 = icmp ne i32 %t8, 0
  br i1 %t9, label %bb4, label %ok.10, !prof !99
ok.10:
  store { i64, ptr } %t7, ptr %l8
  br label %bb3
bb3:
  %t11 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t11, ptr %l6, !tbaa !27
  br label %bb6
bb4:
  %t12 = load i32, ptr %l9, !tbaa !23
  %t13 = ashr i32 %t12, 16
  %t15 = icmp eq i32 %t13, 1
  store i1 %t15, ptr %l11, !tbaa !21
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb6:
  %t16 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t16, ptr %l2, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t19 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s2, { i64, ptr } %t17, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d333, i32 0, i32 1) })
  %t20 = extractvalue { i32, i64 } %t19, 1
  %t21 = extractvalue { i32, i64 } %t19, 0
  store i32 %t21, ptr %l15
  %t22 = icmp ne i32 %t21, 0
  br i1 %t22, label %bb8, label %ok.23, !prof !99
ok.23:
  store i64 %t20, ptr %l14
  br label %bb7
bb7:
  %t24 = load i64, ptr %l14, !tbaa !24
  store i64 %t24, ptr %l12, !tbaa !24
  br label %bb10
bb8:
  br label %bb9
bb9:
  store i64 -1, ptr %l12, !tbaa !24
  br label %bb10
bb10:
  %t25 = load i64, ptr %l12, !tbaa !24
  store i64 %t25, ptr %l3, !tbaa !24
  %t26 = load i64, ptr %l3, !tbaa !24
  %t28 = icmp sge i64 %t26, 0
  br i1 %t28, label %bb11, label %bb12
bb11:
  %t30 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t30, ptr %l18, !tbaa !27
  %t31 = load i64, ptr %l3, !tbaa !24
  %t33 = add i64 %t31, 7
  store i64 %t33, ptr %l20, !tbaa !24
  %t34 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t34, 0
  store i64 %t37, ptr %l23, !tbaa !24
  %t38 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 0
  store i64 %t39, ptr %l24, !tbaa !24
  %t40 = load i64, ptr %l20, !tbaa !24
  %t41 = icmp sge i64 %t40, 0
  br i1 %t41, label %bb13, label %bb14
bb12:
  br label %bb19
bb13:
  %t43 = load i64, ptr %l20, !tbaa !24
  %t44 = load i64, ptr %l23, !tbaa !24
  %t45 = icmp sle i64 %t43, %t44
  br i1 %t45, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_b4f4b1f3947eb18f_4b11d328df759133)
  unreachable
bb15:
  %t47 = load i64, ptr %l23, !tbaa !24
  %t48 = load i64, ptr %l24, !tbaa !24
  %t49 = icmp sle i64 %t47, %t48
  br i1 %t49, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_b4f4b1f3947eb18f_4b11d328df759133)
  unreachable
bb17:
  %t51 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = load i64, ptr %l20, !tbaa !24
  %t54 = load i64, ptr %l23, !tbaa !24
  %t55 = getelementptr i8, ptr %t52, i64 %t53
  %t56 = sub i64 %t54, %t53
  %t57 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t55, 1
  %t60 = extractvalue { i64, ptr } %t58, 1
  %t61 = extractvalue { i64, ptr } %t58, 0
  %t62 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t61)
  call void @olang_textcopy(ptr %t62, ptr %t60, i64 %t61)
  %t63 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t62, 1
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t64, ptr %rv
  br label %ret
bb18:
  call void @__olang_check_failed(ptr @olang_loc_b4f4b1f3947eb18f_4b11d328df759133)
  unreachable
bb19:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb20:
  br label %bb2
bb21:
  %t66 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t68 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %s0, { i64, ptr } %t66)
  store { i64, ptr } %t68, ptr %l31
  br label %bb22
bb22:
  %t69 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t69, 1
  %t71 = extractvalue { i64, ptr } %t69, 0
  %t72 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t71)
  call void @olang_textcopy(ptr %t72, ptr %t70, i64 %t71)
  %t73 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t74, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fbindgen_2efromBits(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l3 = alloca i1
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l9 = alloca i1
  %l10 = alloca i1
  %l12 = alloca i1
  %l18 = alloca i1
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l24 = alloca i1
  %l30 = alloca i1
  %l31 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d334, i32 0, i32 1) })
  store i1 %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load i1, ptr %l3, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d335, i32 0, i32 1) }, ptr %l4, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t5, ptr %l5, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 0
  store i64 %t7, ptr %l6, !tbaa !24
  %t8 = load i64, ptr %l6, !tbaa !24
  %t9 = mul i64 %t8, 1
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l7, !tbaa !27
  %t13 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = load i64, ptr %l6, !tbaa !24
  %t18 = mul i64 %t17, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t14, ptr %t16, i64 %t18, i1 false)
  %t19 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t19, ptr %l5, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t20 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t20, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t21 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t23 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t21, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d336, i32 0, i32 1) })
  store i1 %t23, ptr %l9
  br label %bb5
bb5:
  %t24 = load i1, ptr %l9, !tbaa !21
  br i1 %t24, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb9
bb7:
  %t25 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t27 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t25, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d337, i32 0, i32 1) })
  store i1 %t27, ptr %l12
  br label %bb8
bb8:
  %t28 = load i1, ptr %l12, !tbaa !21
  store i1 %t28, ptr %l10, !tbaa !21
  br label %bb9
bb9:
  %t29 = load i1, ptr %l10, !tbaa !21
  br i1 %t29, label %bb10, label %bb11
bb10:
  %t30 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t31 = load i64, ptr %l1, !tbaa !24
  %t33 = mul i64 8, %t31
  %t35 = extractvalue { i64, ptr } %t30, 1
  %t36 = extractvalue { i64, ptr } %t30, 0
  %t37 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d338, i32 0, i32 1) }, 1
  %t38 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d338, i32 0, i32 1) }, 0
  %t39 = add i64 %t36, %t38
  %t41 = call i64 @__olang_fmt_i64(ptr null, i64 %t33)
  %t42 = add i64 %t39, %t41
  %t43 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d339, i32 0, i32 1) }, 1
  %t44 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d339, i32 0, i32 1) }, 0
  %t45 = add i64 %t42, %t44
  %t46 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t45)
  call void @olang_textcopy(ptr %t46, ptr %t35, i64 %t36)
  %t47 = getelementptr i8, ptr %t46, i64 %t36
  call void @olang_textcopy(ptr %t47, ptr %t37, i64 %t38)
  %t48 = getelementptr i8, ptr %t47, i64 %t38
  %t49 = call i64 @__olang_fmt_i64(ptr %t48, i64 %t33)
  %t50 = getelementptr i8, ptr %t48, i64 %t41
  call void @olang_textcopy(ptr %t50, ptr %t43, i64 %t44)
  %t51 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t46, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t52, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t54 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t56 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t54, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d340, i32 0, i32 1) })
  store i1 %t56, ptr %l18
  br label %bb13
bb13:
  %t57 = load i1, ptr %l18, !tbaa !21
  br i1 %t57, label %bb14, label %bb15
bb14:
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d341, i32 0, i32 1) }, ptr %l19, !tbaa !27
  %t58 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t58, ptr %l20, !tbaa !27
  %t59 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t59, 0
  store i64 %t60, ptr %l21, !tbaa !24
  %t61 = load i64, ptr %l21, !tbaa !24
  %t62 = mul i64 %t61, 1
  %t63 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t62)
  %t64 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t63, 1
  store { i64, ptr } %t65, ptr %l22, !tbaa !27
  %t66 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !27
  %t68 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = load i64, ptr %l21, !tbaa !24
  %t71 = mul i64 %t70, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t67, ptr %t69, i64 %t71, i1 false)
  %t72 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t72, ptr %l20, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t73 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t73, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t74 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t76 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t74, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d342, i32 0, i32 1) })
  store i1 %t76, ptr %l24
  br label %bb17
bb17:
  %t77 = load i1, ptr %l24, !tbaa !21
  br i1 %t77, label %bb18, label %bb19
bb18:
  %t78 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t79 = load i64, ptr %l1, !tbaa !24
  %t81 = mul i64 8, %t79
  %t83 = extractvalue { i64, ptr } %t78, 1
  %t84 = extractvalue { i64, ptr } %t78, 0
  %t85 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d343, i32 0, i32 1) }, 1
  %t86 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d343, i32 0, i32 1) }, 0
  %t87 = add i64 %t84, %t86
  %t89 = call i64 @__olang_fmt_i64(ptr null, i64 %t81)
  %t90 = add i64 %t87, %t89
  %t91 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d344, i32 0, i32 1) }, 1
  %t92 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d344, i32 0, i32 1) }, 0
  %t93 = add i64 %t90, %t92
  %t94 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t93)
  call void @olang_textcopy(ptr %t94, ptr %t83, i64 %t84)
  %t95 = getelementptr i8, ptr %t94, i64 %t84
  call void @olang_textcopy(ptr %t95, ptr %t85, i64 %t86)
  %t96 = getelementptr i8, ptr %t95, i64 %t86
  %t97 = call i64 @__olang_fmt_i64(ptr %t96, i64 %t81)
  %t98 = getelementptr i8, ptr %t96, i64 %t89
  call void @olang_textcopy(ptr %t98, ptr %t91, i64 %t92)
  %t99 = insertvalue { i64, ptr } undef, i64 %t93, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t94, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t100, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t102 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t104 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t102, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d345, i32 0, i32 1) })
  store i1 %t104, ptr %l30
  br label %bb21
bb21:
  %t105 = load i1, ptr %l30, !tbaa !21
  br i1 %t105, label %bb22, label %bb23
bb22:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d346, i32 0, i32 1) }, ptr %l32, !tbaa !27
  %t106 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t106, ptr %l31, !tbaa !27
  br label %bb24
bb23:
  %t108 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t108, 1
  %t111 = extractvalue { i64, ptr } %t108, 0
  %t112 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d347, i32 0, i32 1) }, 1
  %t113 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d347, i32 0, i32 1) }, 0
  %t114 = add i64 %t111, %t113
  %t115 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t114)
  call void @olang_textcopy(ptr %t115, ptr %t110, i64 %t111)
  %t116 = getelementptr i8, ptr %t115, i64 %t111
  call void @olang_textcopy(ptr %t116, ptr %t112, i64 %t113)
  %t117 = insertvalue { i64, ptr } undef, i64 %t114, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t115, 1
  store { i64, ptr } %t118, ptr %l31, !tbaa !27
  br label %bb24
bb24:
  %t120 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t120, 0
  store i64 %t121, ptr %l36, !tbaa !24
  %t122 = load i64, ptr %l36, !tbaa !24
  %t123 = mul i64 %t122, 1
  %t124 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t123)
  %t125 = insertvalue { i64, ptr } undef, i64 %t122, 0
  %t126 = insertvalue { i64, ptr } %t125, ptr %t124, 1
  store { i64, ptr } %t126, ptr %l37, !tbaa !27
  %t127 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t128 = load ptr, ptr %t127, !tbaa !27
  %t129 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = load i64, ptr %l36, !tbaa !24
  %t132 = mul i64 %t131, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t128, ptr %t130, i64 %t132, i1 false)
  %t133 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t133, ptr %l31, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t134 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t134, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fbindgen_2egapLine(ptr %v0, i64 %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l3 = alloca i64
  %l8 = alloca i64
  %l11 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !24
  %t2 = load i64, ptr %l1, !tbaa !24
  %t7 = call i64 @compiler_2fbindgen_2egapWord(i64 %t1, i64 %t2, i64 %a2)
  store i64 %t7, ptr %l8
  br label %bb1
bb1:
  %t8 = load i64, ptr %l8, !tbaa !24
  store i64 %t8, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp eq i64 %t9, 8
  br i1 %t11, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d348, i32 0, i32 1) }, ptr %l11, !tbaa !27
  br label %bb10
bb3:
  %t13 = load i64, ptr %l3, !tbaa !24
  %t15 = icmp eq i64 %t13, 4
  br i1 %t15, label %bb4, label %bb5
bb4:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d349, i32 0, i32 1) }, ptr %l14, !tbaa !27
  br label %bb9
bb5:
  %t17 = load i64, ptr %l3, !tbaa !24
  %t19 = icmp eq i64 %t17, 2
  br i1 %t19, label %bb6, label %bb7
bb6:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d350, i32 0, i32 1) }, ptr %l17, !tbaa !27
  br label %bb8
bb7:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d351, i32 0, i32 1) }, ptr %l17, !tbaa !27
  br label %bb8
bb8:
  %t21 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t21, ptr %l14, !tbaa !27
  br label %bb9
bb9:
  %t22 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t22, ptr %l11, !tbaa !27
  br label %bb10
bb10:
  %t23 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t24 = load i64, ptr %l0, !tbaa !24
  %t26 = load i64, ptr %l1, !tbaa !24
  %t27 = load i64, ptr %l3, !tbaa !24
  %t30 = sdiv i64 %t26, %t27
  %t31 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d352, i32 0, i32 1) }, 1
  %t32 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d352, i32 0, i32 1) }, 0
  %t34 = call i64 @__olang_fmt_i64(ptr null, i64 %t24)
  %t35 = add i64 %t32, %t34
  %t36 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d353, i32 0, i32 1) }, 1
  %t37 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d353, i32 0, i32 1) }, 0
  %t38 = add i64 %t35, %t37
  %t40 = extractvalue { i64, ptr } %t23, 1
  %t41 = extractvalue { i64, ptr } %t23, 0
  %t42 = add i64 %t38, %t41
  %t43 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d354, i32 0, i32 1) }, 1
  %t44 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d354, i32 0, i32 1) }, 0
  %t45 = add i64 %t42, %t44
  %t47 = call i64 @__olang_fmt_i64(ptr null, i64 %t30)
  %t48 = add i64 %t45, %t47
  %t49 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d355, i32 0, i32 1) }, 1
  %t50 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d355, i32 0, i32 1) }, 0
  %t51 = add i64 %t48, %t50
  %t52 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t51)
  call void @olang_textcopy(ptr %t52, ptr %t31, i64 %t32)
  %t53 = getelementptr i8, ptr %t52, i64 %t32
  %t54 = call i64 @__olang_fmt_i64(ptr %t53, i64 %t24)
  %t55 = getelementptr i8, ptr %t53, i64 %t34
  call void @olang_textcopy(ptr %t55, ptr %t36, i64 %t37)
  %t56 = getelementptr i8, ptr %t55, i64 %t37
  call void @olang_textcopy(ptr %t56, ptr %t40, i64 %t41)
  %t57 = getelementptr i8, ptr %t56, i64 %t41
  call void @olang_textcopy(ptr %t57, ptr %t43, i64 %t44)
  %t58 = getelementptr i8, ptr %t57, i64 %t44
  %t59 = call i64 @__olang_fmt_i64(ptr %t58, i64 %t30)
  %t60 = getelementptr i8, ptr %t58, i64 %t47
  call void @olang_textcopy(ptr %t60, ptr %t49, i64 %t50)
  %t61 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t52, 1
  store { i64, ptr } %t62, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fbindgen_2eresultText(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l5 = alloca i1
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l44 = alloca i64
  %l49 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l53 = alloca i1
  %l54 = alloca i1
  %l56 = alloca i1
  %l57 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l59 = alloca i64
  %l60 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l63 = alloca i64
  %l64 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d356, i32 0, i32 1) })
  store i1 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i1, ptr %l5, !tbaa !21
  %t5 = xor i1 %t4, true
  br i1 %t5, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d357, i32 0, i32 1) }, ptr %l7, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t7, ptr %l8, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 0
  store i64 %t9, ptr %l9, !tbaa !24
  %t10 = load i64, ptr %l9, !tbaa !24
  %t11 = mul i64 %t10, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l10, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = load i64, ptr %l9, !tbaa !24
  %t20 = mul i64 %t19, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t16, ptr %t18, i64 %t20, i1 false)
  %t21 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t21, ptr %l8, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t22 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t22, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  store i64 0, ptr %l1, !tbaa !24
  %t23 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 0
  %t27 = sub i64 %t25, 1
  store i64 %t27, ptr %l2, !tbaa !24
  br label %bb5
bb5:
  %t29 = load i64, ptr %l2, !tbaa !24
  %t31 = icmp sge i64 %t29, 0
  %t33 = xor i1 %t31, true
  br i1 %t33, label %bb6, label %bb7
bb6:
  br label %bb19
bb7:
  br label %bb8
bb8:
  %t35 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t35, ptr %l17, !tbaa !27
  %t36 = load i64, ptr %l2, !tbaa !24
  %t38 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr i8, ptr %t39, i64 %t36
  %t41 = load i8, ptr %t40, !tbaa !32
  %t43 = icmp eq i8 %t41, 41
  br i1 %t43, label %bb9, label %bb10
bb9:
  %t45 = load i64, ptr %l1, !tbaa !24
  %t48 = add i64 %t45, 1
  store i64 %t48, ptr %l1, !tbaa !24
  br label %bb11
bb10:
  br label %bb11
bb11:
  %t50 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t50, ptr %l24, !tbaa !27
  %t51 = load i64, ptr %l2, !tbaa !24
  %t53 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr i8, ptr %t54, i64 %t51
  %t56 = load i8, ptr %t55, !tbaa !32
  %t58 = icmp eq i8 %t56, 40
  br i1 %t58, label %bb12, label %bb13
bb12:
  %t60 = load i64, ptr %l1, !tbaa !24
  %t63 = sub i64 %t60, 1
  store i64 %t63, ptr %l1, !tbaa !24
  %t65 = load i64, ptr %l1, !tbaa !24
  %t67 = icmp eq i64 %t65, 0
  br i1 %t67, label %bb14, label %bb15
bb13:
  br label %bb17
bb14:
  br label %bb19
bb15:
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t69 = load i64, ptr %l2, !tbaa !24
  %t72 = sub i64 %t69, 1
  store i64 %t72, ptr %l2, !tbaa !24
  br label %bb18
bb18:
  br label %bb5
bb19:
  %t74 = load i64, ptr %l2, !tbaa !24
  %t76 = icmp sle i64 %t74, 0
  br i1 %t76, label %bb20, label %bb21
bb20:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d358, i32 0, i32 1) }, ptr %l38, !tbaa !27
  %t78 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t78, ptr %l39, !tbaa !27
  %t79 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t79, 0
  store i64 %t80, ptr %l40, !tbaa !24
  %t81 = load i64, ptr %l40, !tbaa !24
  %t82 = mul i64 %t81, 1
  %t83 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t82)
  %t84 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t83, 1
  store { i64, ptr } %t85, ptr %l41, !tbaa !27
  %t86 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !27
  %t88 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !27
  %t90 = load i64, ptr %l40, !tbaa !24
  %t91 = mul i64 %t90, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t87, ptr %t89, i64 %t91, i1 false)
  %t92 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t92, ptr %l39, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t93 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t93, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t94 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t94, ptr %l42, !tbaa !27
  %t95 = load i64, ptr %l2, !tbaa !24
  store i64 %t95, ptr %l43, !tbaa !24
  %t96 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t96, 0
  store i64 %t97, ptr %l44, !tbaa !24
  %t98 = icmp sge i64 0, 0
  br i1 %t98, label %bb23, label %bb24
bb23:
  %t100 = load i64, ptr %l43, !tbaa !24
  %t101 = icmp sle i64 0, %t100
  br i1 %t101, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_63a5955120245215_3bb90f7c84aecf01)
  unreachable
bb25:
  %t103 = load i64, ptr %l43, !tbaa !24
  %t104 = load i64, ptr %l44, !tbaa !24
  %t105 = icmp sle i64 %t103, %t104
  br i1 %t105, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_63a5955120245215_3bb90f7c84aecf01)
  unreachable
bb27:
  %t107 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = load i64, ptr %l43, !tbaa !24
  %t110 = getelementptr i8, ptr %t108, i64 0
  %t111 = sub i64 %t109, 0
  %t112 = insertvalue { i64, ptr } undef, i64 %t111, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t110, 1
  %t115 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %v0, { i64, ptr } %t113)
  store { i64, ptr } %t115, ptr %l49
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_63a5955120245215_3bb90f7c84aecf01)
  unreachable
bb29:
  %t116 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t116, ptr %l3, !tbaa !27
  %t117 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d359, i32 0, i32 1) }, ptr %l52, !tbaa !27
  %t120 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t121 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s0, { i64, ptr } %t117, { i64, ptr } %t120)
  store i1 %t121, ptr %l53
  br label %bb30
bb30:
  %t122 = load i1, ptr %l53, !tbaa !21
  br i1 %t122, label %bb31, label %bb32
bb31:
  store i1 true, ptr %l54, !tbaa !21
  br label %bb34
bb32:
  %t123 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t125 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t123, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d360, i32 0, i32 1) })
  store i1 %t125, ptr %l56
  br label %bb33
bb33:
  %t126 = load i1, ptr %l56, !tbaa !21
  store i1 %t126, ptr %l54, !tbaa !21
  br label %bb34
bb34:
  %t127 = load i1, ptr %l54, !tbaa !21
  br i1 %t127, label %bb35, label %bb36
bb35:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d361, i32 0, i32 1) }, ptr %l57, !tbaa !27
  %t128 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t128, ptr %l58, !tbaa !27
  %t129 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t130 = extractvalue { i64, ptr } %t129, 0
  store i64 %t130, ptr %l59, !tbaa !24
  %t131 = load i64, ptr %l59, !tbaa !24
  %t132 = mul i64 %t131, 1
  %t133 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t132)
  %t134 = insertvalue { i64, ptr } undef, i64 %t131, 0
  %t135 = insertvalue { i64, ptr } %t134, ptr %t133, 1
  store { i64, ptr } %t135, ptr %l60, !tbaa !27
  %t136 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !27
  %t138 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !27
  %t140 = load i64, ptr %l59, !tbaa !24
  %t141 = mul i64 %t140, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t137, ptr %t139, i64 %t141, i1 false)
  %t142 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t142, ptr %l58, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t143 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t143, ptr %rv
  br label %ret
bb36:
  br label %bb37
bb37:
  %t144 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t144, ptr %l62, !tbaa !27
  %t146 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t147 = extractvalue { i64, ptr } %t146, 0
  store i64 %t147, ptr %l63, !tbaa !24
  %t148 = load i64, ptr %l63, !tbaa !24
  %t149 = mul i64 %t148, 1
  %t150 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t149)
  %t151 = insertvalue { i64, ptr } undef, i64 %t148, 0
  %t152 = insertvalue { i64, ptr } %t151, ptr %t150, 1
  store { i64, ptr } %t152, ptr %l64, !tbaa !27
  %t153 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !27
  %t155 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t156 = load ptr, ptr %t155, !tbaa !27
  %t157 = load i64, ptr %l63, !tbaa !24
  %t158 = mul i64 %t157, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t154, ptr %t156, i64 %t158, i1 false)
  %t159 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t159, ptr %l62, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t160 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t160, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fbindgen_2etextLiteral(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i8
  %l8 = alloca i8
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca %"std/prelude/text:StringBuilder"
  %l28 = alloca { i64, ptr }
  %l34 = alloca i1
  %l35 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l55 = alloca i1
  %l72 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l74 = alloca i64
  %l75 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l88 = alloca i1
  %l89 = alloca { i64, ptr }
  %l92 = alloca i1
  %l93 = alloca i1
  %l94 = alloca { i64, ptr }
  %l97 = alloca i8
  %l99 = alloca i1
  %l100 = alloca { i64, ptr }
  %l103 = alloca i8
  %l109 = alloca i64
  %l110 = alloca { i64, ptr }
  %l112 = alloca i64
  %l113 = alloca i64
  %l114 = alloca i64
  %l118 = alloca { i64, ptr }
  %l119 = alloca i64
  %l120 = alloca i32
  %l121 = alloca i64
  %l122 = alloca i32
  %l126 = alloca i1
  %l135 = alloca i1
  %l140 = alloca i1
  %l141 = alloca { i64, ptr }
  %l145 = alloca i1
  %l146 = alloca { i64, ptr }
  %l154 = alloca i64
  %l155 = alloca { i64, ptr }
  %l156 = alloca i64
  %l157 = alloca i64
  %l158 = alloca i64
  %l162 = alloca { i64, ptr }
  %l163 = alloca i64
  %l164 = alloca i32
  %l165 = alloca i64
  %l166 = alloca i32
  %l168 = alloca i64
  %l191 = alloca i1
  %l194 = alloca { i64, ptr }
  %l195 = alloca { i64, ptr }
  %l196 = alloca i64
  %l197 = alloca { i64, ptr }
  %l200 = alloca i1
  %l209 = alloca i1
  %l216 = alloca ptr
  %l218 = alloca i8
  %l219 = alloca i64
  %l220 = alloca i32
  %l221 = alloca { i64, ptr }
  %l223 = alloca { i64, ptr }
  %l230 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d362, i32 0, i32 1) }, ptr %l15, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t7, ptr %l16, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 0
  store i64 %t9, ptr %l17, !tbaa !24
  %t10 = load i64, ptr %l17, !tbaa !24
  %t11 = mul i64 %t10, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l18, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = load i64, ptr %l17, !tbaa !24
  %t20 = mul i64 %t19, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t16, ptr %t18, i64 %t20, i1 false)
  %t21 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t21, ptr %l16, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t22 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t22, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t23 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t23, ptr %l19
  br label %bb4
bb4:
  %t24 = load %"std/prelude/text:StringBuilder", ptr %l19
  store %"std/prelude/text:StringBuilder" %t24, ptr %l1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 34)
  br label %bb5
bb5:
  %t26 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t26, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t28 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  store i64 %t30, ptr %l4, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l3, !tbaa !24
  %t33 = load i64, ptr %l4, !tbaa !24
  %t36 = icmp slt i64 %t32, %t33
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb7, label %bb8
bb7:
  br label %bb163
bb8:
  br label %bb9
bb9:
  %t40 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t40, ptr %l28, !tbaa !27
  %t41 = load i64, ptr %l3, !tbaa !24
  %t43 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr { i64, ptr }, ptr %t44, i64 %t41
  %t46 = load { i64, ptr }, ptr %t45, !tbaa !37
  store { i64, ptr } %t46, ptr %l5, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t48, 0
  %t52 = icmp slt i64 %t50, 2
  br i1 %t52, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb12
bb11:
  %t54 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t54, ptr %l35, !tbaa !27
  %t55 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = getelementptr i8, ptr %t56, i64 0
  %t58 = load i8, ptr %t57, !tbaa !32
  %t60 = icmp ne i8 %t58, 34
  store i1 %t60, ptr %l34, !tbaa !21
  br label %bb12
bb12:
  %t62 = load i1, ptr %l34, !tbaa !21
  br i1 %t62, label %bb13, label %bb14
bb13:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d363, i32 0, i32 1) }, ptr %l38, !tbaa !27
  %t63 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t63, ptr %l39, !tbaa !27
  %t64 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l40, !tbaa !24
  %t66 = load i64, ptr %l40, !tbaa !24
  %t67 = mul i64 %t66, 1
  %t68 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t67)
  %t69 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t70 = insertvalue { i64, ptr } %t69, ptr %t68, 1
  store { i64, ptr } %t70, ptr %l41, !tbaa !27
  %t71 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = load i64, ptr %l40, !tbaa !24
  %t76 = mul i64 %t75, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t72, ptr %t74, i64 %t76, i1 false)
  %t77 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t77, ptr %l39, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t78 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t78, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  store i64 1, ptr %l6, !tbaa !24
  br label %bb16
bb16:
  %t79 = load i64, ptr %l6, !tbaa !24
  %t80 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t80, 0
  %t84 = sub i64 %t82, 1
  %t87 = icmp slt i64 %t79, %t84
  %t89 = xor i1 %t87, true
  br i1 %t89, label %bb17, label %bb18
bb17:
  br label %bb161
bb18:
  br label %bb19
bb19:
  %t91 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t91, ptr %l48, !tbaa !27
  %t92 = load i64, ptr %l6, !tbaa !24
  %t94 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = getelementptr i8, ptr %t95, i64 %t92
  %t97 = load i8, ptr %t96, !tbaa !32
  store i8 %t97, ptr %l7, !tbaa !22
  %t99 = load i8, ptr %l7, !tbaa !22
  %t101 = icmp ne i8 %t99, 92
  br i1 %t101, label %bb20, label %bb21
bb20:
  %t103 = load i8, ptr %l7, !tbaa !22
  %t105 = icmp eq i8 %t103, 34
  br i1 %t105, label %bb22, label %bb23
bb21:
  br label %bb30
bb22:
  store i1 true, ptr %l55, !tbaa !21
  br label %bb24
bb23:
  %t107 = load i8, ptr %l7, !tbaa !22
  %t109 = icmp eq i8 %t107, 92
  store i1 %t109, ptr %l55, !tbaa !21
  br label %bb24
bb24:
  %t111 = load i1, ptr %l55, !tbaa !21
  br i1 %t111, label %bb25, label %bb26
bb25:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 92)
  br label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb28
bb28:
  %t113 = load i8, ptr %l7, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 %t113)
  br label %bb29
bb29:
  %t116 = load i64, ptr %l6, !tbaa !24
  %t119 = add i64 %t116, 1
  store i64 %t119, ptr %l6, !tbaa !24
  br label %bb160
bb30:
  %t121 = load i64, ptr %l6, !tbaa !24
  %t124 = add i64 %t121, 1
  store i64 %t124, ptr %l6, !tbaa !24
  %t126 = load i64, ptr %l6, !tbaa !24
  %t127 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t127, 0
  %t131 = sub i64 %t129, 1
  %t134 = icmp sge i64 %t126, %t131
  br i1 %t134, label %bb31, label %bb32
bb31:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d364, i32 0, i32 1) }, ptr %l72, !tbaa !27
  %t136 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t136, ptr %l73, !tbaa !27
  %t137 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t137, 0
  store i64 %t138, ptr %l74, !tbaa !24
  %t139 = load i64, ptr %l74, !tbaa !24
  %t140 = mul i64 %t139, 1
  %t141 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t140)
  %t142 = insertvalue { i64, ptr } undef, i64 %t139, 0
  %t143 = insertvalue { i64, ptr } %t142, ptr %t141, 1
  store { i64, ptr } %t143, ptr %l75, !tbaa !27
  %t144 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !27
  %t146 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = load i64, ptr %l74, !tbaa !24
  %t149 = mul i64 %t148, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t145, ptr %t147, i64 %t149, i1 false)
  %t150 = load { i64, ptr }, ptr %l75, !tbaa !27
  store { i64, ptr } %t150, ptr %l73, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t151 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t151, ptr %rv
  br label %ret
bb32:
  br label %bb33
bb33:
  %t152 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t152, ptr %l76, !tbaa !27
  %t153 = load i64, ptr %l6, !tbaa !24
  %t155 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t156 = load ptr, ptr %t155, !tbaa !27
  %t157 = getelementptr i8, ptr %t156, i64 %t153
  %t158 = load i8, ptr %t157, !tbaa !32
  store i8 %t158, ptr %l8, !tbaa !22
  store i64 -1, ptr %l9, !tbaa !24
  %t160 = load i8, ptr %l8, !tbaa !22
  %t162 = icmp eq i8 %t160, 120
  br i1 %t162, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s9
  %t164 = load i64, ptr %l6, !tbaa !24
  %t166 = add i64 %t164, 1
  store i64 %t166, ptr %l10, !tbaa !24
  br label %bb36
bb35:
  %t168 = load i8, ptr %l8, !tbaa !22
  %t170 = icmp uge i8 %t168, 48
  br i1 %t170, label %bb66, label %bb67
bb36:
  %t172 = load i64, ptr %l10, !tbaa !24
  %t173 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t175 = extractvalue { i64, ptr } %t173, 0
  %t177 = sub i64 %t175, 1
  %t180 = icmp slt i64 %t172, %t177
  br i1 %t180, label %bb37, label %bb38
bb37:
  %t182 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t182, ptr %l89, !tbaa !27
  %t183 = load i64, ptr %l10, !tbaa !24
  %t185 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t186 = load ptr, ptr %t185, !tbaa !27
  %t187 = getelementptr i8, ptr %t186, i64 %t183
  %t188 = load i8, ptr %t187, !tbaa !32
  %t190 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t188)
  store i1 %t190, ptr %l92
  br label %bb39
bb38:
  store i1 false, ptr %l88, !tbaa !21
  br label %bb48
bb39:
  %t191 = load i1, ptr %l92, !tbaa !21
  br i1 %t191, label %bb40, label %bb41
bb40:
  store i1 true, ptr %l93, !tbaa !21
  br label %bb47
bb41:
  %t192 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t192, ptr %l94, !tbaa !27
  %t193 = load i64, ptr %l10, !tbaa !24
  %t195 = getelementptr { i64, ptr }, ptr %l94, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !27
  %t197 = getelementptr i8, ptr %t196, i64 %t193
  %t198 = load i8, ptr %t197, !tbaa !32
  %t200 = call i8 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eToLower(i8 %t198)
  store i8 %t200, ptr %l97
  br label %bb42
bb42:
  %t201 = load i8, ptr %l97, !tbaa !22
  %t202 = icmp uge i8 %t201, 97
  br i1 %t202, label %bb43, label %bb44
bb43:
  %t204 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t204, ptr %l100, !tbaa !27
  %t205 = load i64, ptr %l10, !tbaa !24
  %t207 = getelementptr { i64, ptr }, ptr %l100, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !27
  %t209 = getelementptr i8, ptr %t208, i64 %t205
  %t210 = load i8, ptr %t209, !tbaa !32
  %t212 = call i8 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eToLower(i8 %t210)
  store i8 %t212, ptr %l103
  br label %bb45
bb44:
  store i1 false, ptr %l99, !tbaa !21
  br label %bb46
bb45:
  %t213 = load i8, ptr %l103, !tbaa !22
  %t214 = icmp ule i8 %t213, 102
  store i1 %t214, ptr %l99, !tbaa !21
  br label %bb46
bb46:
  %t216 = load i1, ptr %l99, !tbaa !21
  store i1 %t216, ptr %l93, !tbaa !21
  br label %bb47
bb47:
  %t217 = load i1, ptr %l93, !tbaa !21
  store i1 %t217, ptr %l88, !tbaa !21
  br label %bb48
bb48:
  %t218 = load i1, ptr %l88, !tbaa !21
  %t219 = xor i1 %t218, true
  br i1 %t219, label %bb49, label %bb50
bb49:
  br label %bb53
bb50:
  br label %bb51
bb51:
  %t221 = load i64, ptr %l10, !tbaa !24
  %t224 = add i64 %t221, 1
  store i64 %t224, ptr %l10, !tbaa !24
  br label %bb52
bb52:
  br label %bb36
bb53:
  %t226 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t226, ptr %l110, !tbaa !27
  %t227 = load i64, ptr %l6, !tbaa !24
  %t229 = add i64 %t227, 1
  store i64 %t229, ptr %l112, !tbaa !24
  %t230 = load i64, ptr %l10, !tbaa !24
  store i64 %t230, ptr %l113, !tbaa !24
  %t231 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t232 = extractvalue { i64, ptr } %t231, 0
  store i64 %t232, ptr %l114, !tbaa !24
  %t233 = load i64, ptr %l112, !tbaa !24
  %t234 = icmp sge i64 %t233, 0
  br i1 %t234, label %bb54, label %bb55
bb54:
  %t236 = load i64, ptr %l112, !tbaa !24
  %t237 = load i64, ptr %l113, !tbaa !24
  %t238 = icmp sle i64 %t236, %t237
  br i1 %t238, label %bb56, label %bb57
bb55:
  call void @__olang_check_failed(ptr @olang_loc_d82489adf04aec69_8da73aeba875ea7d)
  unreachable
bb56:
  %t240 = load i64, ptr %l113, !tbaa !24
  %t241 = load i64, ptr %l114, !tbaa !24
  %t242 = icmp sle i64 %t240, %t241
  br i1 %t242, label %bb58, label %bb59
bb57:
  call void @__olang_check_failed(ptr @olang_loc_d82489adf04aec69_8da73aeba875ea7d)
  unreachable
bb58:
  %t244 = getelementptr { i64, ptr }, ptr %l110, i32 0, i32 1
  %t245 = load ptr, ptr %t244, !tbaa !27
  %t246 = load i64, ptr %l112, !tbaa !24
  %t247 = load i64, ptr %l113, !tbaa !24
  %t248 = getelementptr i8, ptr %t245, i64 %t246
  %t249 = sub i64 %t247, %t246
  %t250 = insertvalue { i64, ptr } undef, i64 %t249, 0
  %t251 = insertvalue { i64, ptr } %t250, ptr %t248, 1
  store { i64, ptr } %t251, ptr %l118, !tbaa !27
  %t252 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s9, i64 16)
  %t253 = extractvalue { i32, i64 } %t252, 1
  %t254 = extractvalue { i32, i64 } %t252, 0
  store i32 %t254, ptr %l120
  %t255 = icmp ne i32 %t254, 0
  br i1 %t255, label %bb61, label %ok.256, !prof !99
ok.256:
  store i64 %t253, ptr %l119
  br label %bb60
bb59:
  call void @__olang_check_failed(ptr @olang_loc_d82489adf04aec69_8da73aeba875ea7d)
  unreachable
bb60:
  %t257 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t258 = load i64, ptr %l119, !tbaa !24
  %t259 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %t257, i64 %t258)
  %t260 = extractvalue { i32, i64 } %t259, 1
  %t261 = extractvalue { i32, i64 } %t259, 0
  store i32 %t261, ptr %l122
  %t262 = icmp ne i32 %t261, 0
  br i1 %t262, label %bb64, label %ok.263, !prof !99
ok.263:
  store i64 %t260, ptr %l121
  br label %bb63
bb61:
  br label %bb62
bb62:
  store i64 -1, ptr %l109, !tbaa !24
  br label %bb65
bb63:
  %t264 = load i64, ptr %l121, !tbaa !24
  store i64 %t264, ptr %l109, !tbaa !24
  br label %bb65
bb64:
  br label %bb62
bb65:
  %t265 = load i64, ptr %l109, !tbaa !24
  store i64 %t265, ptr %l9, !tbaa !24
  %t266 = load i64, ptr %l10, !tbaa !24
  store i64 %t266, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  br label %bb132
bb66:
  %t268 = load i8, ptr %l8, !tbaa !22
  %t270 = icmp ule i8 %t268, 55
  store i1 %t270, ptr %l126, !tbaa !21
  br label %bb68
bb67:
  store i1 false, ptr %l126, !tbaa !21
  br label %bb68
bb68:
  %t272 = load i1, ptr %l126, !tbaa !21
  br i1 %t272, label %bb69, label %bb70
bb69:
  store %olang.scope zeroinitializer, ptr %s12
  %t273 = load i64, ptr %l6, !tbaa !24
  store i64 %t273, ptr %l11, !tbaa !24
  br label %bb71
bb70:
  %t275 = load i8, ptr %l8, !tbaa !22
  %t277 = icmp eq i8 %t275, 110
  br i1 %t277, label %bb98, label %bb99
bb71:
  %t279 = load i64, ptr %l11, !tbaa !24
  %t280 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t282 = extractvalue { i64, ptr } %t280, 0
  %t284 = sub i64 %t282, 1
  %t287 = icmp slt i64 %t279, %t284
  br i1 %t287, label %bb72, label %bb73
bb72:
  %t289 = load i64, ptr %l11, !tbaa !24
  %t290 = load i64, ptr %l6, !tbaa !24
  %t292 = add i64 %t290, 3
  %t295 = icmp slt i64 %t289, %t292
  store i1 %t295, ptr %l135, !tbaa !21
  br label %bb74
bb73:
  store i1 false, ptr %l135, !tbaa !21
  br label %bb74
bb74:
  %t297 = load i1, ptr %l135, !tbaa !21
  br i1 %t297, label %bb75, label %bb76
bb75:
  %t298 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t298, ptr %l141, !tbaa !27
  %t299 = load i64, ptr %l11, !tbaa !24
  %t301 = getelementptr { i64, ptr }, ptr %l141, i32 0, i32 1
  %t302 = load ptr, ptr %t301, !tbaa !27
  %t303 = getelementptr i8, ptr %t302, i64 %t299
  %t304 = load i8, ptr %t303, !tbaa !32
  %t306 = icmp uge i8 %t304, 48
  store i1 %t306, ptr %l140, !tbaa !21
  br label %bb77
bb76:
  store i1 false, ptr %l140, !tbaa !21
  br label %bb77
bb77:
  %t308 = load i1, ptr %l140, !tbaa !21
  br i1 %t308, label %bb78, label %bb79
bb78:
  %t309 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t309, ptr %l146, !tbaa !27
  %t310 = load i64, ptr %l11, !tbaa !24
  %t312 = getelementptr { i64, ptr }, ptr %l146, i32 0, i32 1
  %t313 = load ptr, ptr %t312, !tbaa !27
  %t314 = getelementptr i8, ptr %t313, i64 %t310
  %t315 = load i8, ptr %t314, !tbaa !32
  %t317 = icmp ule i8 %t315, 55
  store i1 %t317, ptr %l145, !tbaa !21
  br label %bb80
bb79:
  store i1 false, ptr %l145, !tbaa !21
  br label %bb80
bb80:
  %t319 = load i1, ptr %l145, !tbaa !21
  %t320 = xor i1 %t319, true
  br i1 %t320, label %bb81, label %bb82
bb81:
  br label %bb85
bb82:
  br label %bb83
bb83:
  %t322 = load i64, ptr %l11, !tbaa !24
  %t325 = add i64 %t322, 1
  store i64 %t325, ptr %l11, !tbaa !24
  br label %bb84
bb84:
  br label %bb71
bb85:
  %t327 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t327, ptr %l155, !tbaa !27
  %t328 = load i64, ptr %l6, !tbaa !24
  store i64 %t328, ptr %l156, !tbaa !24
  %t329 = load i64, ptr %l11, !tbaa !24
  store i64 %t329, ptr %l157, !tbaa !24
  %t330 = load { i64, ptr }, ptr %l155, !tbaa !27
  %t331 = extractvalue { i64, ptr } %t330, 0
  store i64 %t331, ptr %l158, !tbaa !24
  %t332 = load i64, ptr %l156, !tbaa !24
  %t333 = icmp sge i64 %t332, 0
  br i1 %t333, label %bb86, label %bb87
bb86:
  %t335 = load i64, ptr %l156, !tbaa !24
  %t336 = load i64, ptr %l157, !tbaa !24
  %t337 = icmp sle i64 %t335, %t336
  br i1 %t337, label %bb88, label %bb89
bb87:
  call void @__olang_check_failed(ptr @olang_loc_e159f608b90be7c_888d447c7b7c1020)
  unreachable
bb88:
  %t339 = load i64, ptr %l157, !tbaa !24
  %t340 = load i64, ptr %l158, !tbaa !24
  %t341 = icmp sle i64 %t339, %t340
  br i1 %t341, label %bb90, label %bb91
bb89:
  call void @__olang_check_failed(ptr @olang_loc_e159f608b90be7c_888d447c7b7c1020)
  unreachable
bb90:
  %t343 = getelementptr { i64, ptr }, ptr %l155, i32 0, i32 1
  %t344 = load ptr, ptr %t343, !tbaa !27
  %t345 = load i64, ptr %l156, !tbaa !24
  %t346 = load i64, ptr %l157, !tbaa !24
  %t347 = getelementptr i8, ptr %t344, i64 %t345
  %t348 = sub i64 %t346, %t345
  %t349 = insertvalue { i64, ptr } undef, i64 %t348, 0
  %t350 = insertvalue { i64, ptr } %t349, ptr %t347, 1
  store { i64, ptr } %t350, ptr %l162, !tbaa !27
  %t351 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s12, i64 8)
  %t352 = extractvalue { i32, i64 } %t351, 1
  %t353 = extractvalue { i32, i64 } %t351, 0
  store i32 %t353, ptr %l164
  %t354 = icmp ne i32 %t353, 0
  br i1 %t354, label %bb93, label %ok.355, !prof !99
ok.355:
  store i64 %t352, ptr %l163
  br label %bb92
bb91:
  call void @__olang_check_failed(ptr @olang_loc_e159f608b90be7c_888d447c7b7c1020)
  unreachable
bb92:
  %t356 = load { i64, ptr }, ptr %l162, !tbaa !27
  %t357 = load i64, ptr %l163, !tbaa !24
  %t358 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %t356, i64 %t357)
  %t359 = extractvalue { i32, i64 } %t358, 1
  %t360 = extractvalue { i32, i64 } %t358, 0
  store i32 %t360, ptr %l166
  %t361 = icmp ne i32 %t360, 0
  br i1 %t361, label %bb96, label %ok.362, !prof !99
ok.362:
  store i64 %t359, ptr %l165
  br label %bb95
bb93:
  br label %bb94
bb94:
  store i64 -1, ptr %l154, !tbaa !24
  br label %bb97
bb95:
  %t363 = load i64, ptr %l165, !tbaa !24
  store i64 %t363, ptr %l154, !tbaa !24
  br label %bb97
bb96:
  br label %bb94
bb97:
  %t364 = load i64, ptr %l154, !tbaa !24
  store i64 %t364, ptr %l9, !tbaa !24
  %t365 = load i64, ptr %l11, !tbaa !24
  store i64 %t365, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s12)
  br label %bb131
bb98:
  br label %bb100
bb99:
  br label %bb101
bb100:
  store i64 10, ptr %l168, !tbaa !24
  br label %bb130
bb101:
  %t367 = load i8, ptr %l8, !tbaa !22
  %t369 = icmp eq i8 %t367, 116
  br i1 %t369, label %bb102, label %bb103
bb102:
  br label %bb104
bb103:
  br label %bb105
bb104:
  store i64 9, ptr %l168, !tbaa !24
  br label %bb130
bb105:
  %t371 = load i8, ptr %l8, !tbaa !22
  %t373 = icmp eq i8 %t371, 114
  br i1 %t373, label %bb106, label %bb107
bb106:
  br label %bb108
bb107:
  br label %bb109
bb108:
  store i64 13, ptr %l168, !tbaa !24
  br label %bb130
bb109:
  %t375 = load i8, ptr %l8, !tbaa !22
  %t377 = icmp eq i8 %t375, 97
  br i1 %t377, label %bb110, label %bb111
bb110:
  br label %bb112
bb111:
  br label %bb113
bb112:
  store i64 7, ptr %l168, !tbaa !24
  br label %bb130
bb113:
  %t379 = load i8, ptr %l8, !tbaa !22
  %t381 = icmp eq i8 %t379, 98
  br i1 %t381, label %bb114, label %bb115
bb114:
  br label %bb116
bb115:
  br label %bb117
bb116:
  store i64 8, ptr %l168, !tbaa !24
  br label %bb130
bb117:
  %t383 = load i8, ptr %l8, !tbaa !22
  %t385 = icmp eq i8 %t383, 102
  br i1 %t385, label %bb118, label %bb119
bb118:
  br label %bb120
bb119:
  br label %bb121
bb120:
  store i64 12, ptr %l168, !tbaa !24
  br label %bb130
bb121:
  %t387 = load i8, ptr %l8, !tbaa !22
  %t389 = icmp eq i8 %t387, 118
  br i1 %t389, label %bb122, label %bb123
bb122:
  br label %bb124
bb123:
  br label %bb125
bb124:
  store i64 11, ptr %l168, !tbaa !24
  br label %bb130
bb125:
  br i1 true, label %bb126, label %bb127
bb126:
  br label %bb128
bb127:
  br label %bb129
bb128:
  %t391 = load i8, ptr %l8, !tbaa !22
  %t394 = zext i8 %t391 to i64
  store i64 %t394, ptr %l168, !tbaa !24
  br label %bb130
bb129:
  call void @__olang_check_failed(ptr @olang_loc_2265f42fe0f29d10_7d9e15ddc2058014)
  unreachable
bb130:
  %t396 = load i64, ptr %l168, !tbaa !24
  store i64 %t396, ptr %l9, !tbaa !24
  %t397 = load i64, ptr %l6, !tbaa !24
  %t400 = add i64 %t397, 1
  store i64 %t400, ptr %l6, !tbaa !24
  br label %bb131
bb131:
  br label %bb132
bb132:
  %t402 = load i64, ptr %l9, !tbaa !24
  %t404 = icmp slt i64 %t402, 0
  br i1 %t404, label %bb133, label %bb134
bb133:
  store i1 true, ptr %l191, !tbaa !21
  br label %bb135
bb134:
  %t406 = load i64, ptr %l9, !tbaa !24
  %t408 = icmp sgt i64 %t406, 255
  store i1 %t408, ptr %l191, !tbaa !21
  br label %bb135
bb135:
  %t410 = load i1, ptr %l191, !tbaa !21
  br i1 %t410, label %bb136, label %bb137
bb136:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d365, i32 0, i32 1) }, ptr %l194, !tbaa !27
  %t411 = load { i64, ptr }, ptr %l194, !tbaa !27
  store { i64, ptr } %t411, ptr %l195, !tbaa !27
  %t412 = load { i64, ptr }, ptr %l195, !tbaa !27
  %t413 = extractvalue { i64, ptr } %t412, 0
  store i64 %t413, ptr %l196, !tbaa !24
  %t414 = load i64, ptr %l196, !tbaa !24
  %t415 = mul i64 %t414, 1
  %t416 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t415)
  %t417 = insertvalue { i64, ptr } undef, i64 %t414, 0
  %t418 = insertvalue { i64, ptr } %t417, ptr %t416, 1
  store { i64, ptr } %t418, ptr %l197, !tbaa !27
  %t419 = getelementptr { i64, ptr }, ptr %l197, i32 0, i32 1
  %t420 = load ptr, ptr %t419, !tbaa !27
  %t421 = getelementptr { i64, ptr }, ptr %l195, i32 0, i32 1
  %t422 = load ptr, ptr %t421, !tbaa !27
  %t423 = load i64, ptr %l196, !tbaa !24
  %t424 = mul i64 %t423, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t420, ptr %t422, i64 %t424, i1 false)
  %t425 = load { i64, ptr }, ptr %l197, !tbaa !27
  store { i64, ptr } %t425, ptr %l195, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t426 = load { i64, ptr }, ptr %l195, !tbaa !27
  store { i64, ptr } %t426, ptr %rv
  br label %ret
bb137:
  br label %bb138
bb138:
  %t427 = load i64, ptr %l9, !tbaa !24
  %t429 = icmp eq i64 %t427, 34
  br i1 %t429, label %bb139, label %bb140
bb139:
  store i1 true, ptr %l200, !tbaa !21
  br label %bb141
bb140:
  %t431 = load i64, ptr %l9, !tbaa !24
  %t433 = icmp eq i64 %t431, 92
  store i1 %t433, ptr %l200, !tbaa !21
  br label %bb141
bb141:
  %t435 = load i1, ptr %l200, !tbaa !21
  br i1 %t435, label %bb142, label %bb143
bb142:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 92)
  br label %bb144
bb143:
  %t437 = load i64, ptr %l9, !tbaa !24
  %t439 = icmp sge i64 %t437, 32
  br i1 %t439, label %bb146, label %bb147
bb144:
  %t441 = load i64, ptr %l9, !tbaa !24
  %t443 = trunc i64 %t441 to i8
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 %t443)
  br label %bb145
bb145:
  br label %bb159
bb146:
  %t446 = load i64, ptr %l9, !tbaa !24
  %t448 = icmp slt i64 %t446, 127
  store i1 %t448, ptr %l209, !tbaa !21
  br label %bb148
bb147:
  store i1 false, ptr %l209, !tbaa !21
  br label %bb148
bb148:
  %t450 = load i1, ptr %l209, !tbaa !21
  br i1 %t450, label %bb149, label %bb150
bb149:
  %t451 = load i64, ptr %l9, !tbaa !24
  %t453 = trunc i64 %t451 to i8
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 %t453)
  br label %bb151
bb150:
  store %olang.scope zeroinitializer, ptr %s27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s27, ptr %l1, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d366, i32 0, i32 1) })
  br label %bb152
bb151:
  br label %bb158
bb152:
  store ptr %l1, ptr %l216, !tbaa !29
  %t457 = load i64, ptr %l9, !tbaa !24
  %t459 = trunc i64 %t457 to i8
  store i8 %t459, ptr %l218, !tbaa !22
  %t460 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s27, i64 16)
  %t461 = extractvalue { i32, i64 } %t460, 1
  %t462 = extractvalue { i32, i64 } %t460, 0
  store i32 %t462, ptr %l220
  %t463 = icmp ne i32 %t462, 0
  br i1 %t463, label %bb154, label %ok.464, !prof !99
ok.464:
  store i64 %t461, ptr %l219
  br label %bb153
bb153:
  %t465 = load i8, ptr %l218, !tbaa !22
  %t466 = load i64, ptr %l219, !tbaa !24
  %t467 = call { i64, ptr } @std_2fprelude_2ftext_2eU8_2eFormat(ptr %s27, i8 %t465, i64 %t466)
  store { i64, ptr } %t467, ptr %l221
  br label %bb155
bb154:
  call void @__olang_check_failed(ptr @olang_loc_6de4e6ae025697a1_ab8e19fa95fbb0c5)
  unreachable
bb155:
  %t468 = load { i64, ptr }, ptr %l221, !tbaa !27
  %t470 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %s27, ptr %s27, { i64, ptr } %t468, i64 2, i8 48)
  store { i64, ptr } %t470, ptr %l223
  br label %bb156
bb156:
  %t471 = load { i64, ptr }, ptr %l223, !tbaa !27
  %t472 = extractvalue { i64, ptr } %t471, 0
  %t473 = extractvalue { i64, ptr } %t471, 1
  %t474 = mul i64 %t472, 1
  %t475 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t474)
  call void @llvm.memcpy.p0.p0.i64(ptr %t475, ptr %t473, i64 %t474, i1 false)
  %t476 = insertvalue { i64, ptr } undef, i64 %t472, 0
  %t477 = insertvalue { i64, ptr } %t476, ptr %t475, 1
  %t478 = load ptr, ptr %l216, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s27, ptr %t478, { i64, ptr } %t477)
  br label %bb157
bb157:
  call void @__olang_scope_close(ptr %s27)
  br label %bb158
bb158:
  br label %bb159
bb159:
  br label %bb160
bb160:
  br label %bb16
bb161:
  br label %bb162
bb162:
  %t480 = load i64, ptr %l3, !tbaa !24
  %t483 = add i64 %t480, 1
  store i64 %t483, ptr %l3, !tbaa !24
  br label %bb6
bb163:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 34)
  br label %bb164
bb164:
  %t487 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t487, ptr %l230
  br label %bb165
bb165:
  call void @__olang_scope_close(ptr %s0)
  %t488 = load { i64, ptr }, ptr %l230, !tbaa !27
  store { i64, ptr } %t488, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fbindgen_2evoidRef(ptr %v0, i1 %a0) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  br i1 %a0, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d367, i32 0, i32 1) }, ptr %l3, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t3, ptr %l2, !tbaa !27
  br label %bb3
bb2:
  store { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d368, i32 0, i32 1) }, ptr %l5, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t5, ptr %l2, !tbaa !27
  br label %bb3
bb3:
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t7, 0
  store i64 %t8, ptr %l7, !tbaa !24
  %t9 = load i64, ptr %l7, !tbaa !24
  %t10 = mul i64 %t9, 1
  %t11 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t10)
  %t12 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  store { i64, ptr } %t13, ptr %l8, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = load i64, ptr %l7, !tbaa !24
  %t19 = mul i64 %t18, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t15, ptr %t17, i64 %t19, i1 false)
  %t20 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t20, ptr %l2, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t21, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fbindgen_2ewordBits(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l4 = alloca i1
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp eq i64 %t1, 8
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i64, ptr %l1, !tbaa !24
  %t7 = icmp eq i64 %t5, 1
  store i1 %t7, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  %t10 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t11 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d369, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d369, i32 0, i32 1) }, 0
  %t14 = extractvalue { i64, ptr } %t10, 1
  %t15 = extractvalue { i64, ptr } %t10, 0
  %t16 = add i64 %t12, %t15
  %t17 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d370, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d370, i32 0, i32 1) }, 0
  %t19 = add i64 %t16, %t18
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @olang_textcopy(ptr %t20, ptr %t11, i64 %t12)
  %t21 = getelementptr i8, ptr %t20, i64 %t12
  call void @olang_textcopy(ptr %t21, ptr %t14, i64 %t15)
  %t22 = getelementptr i8, ptr %t21, i64 %t15
  call void @olang_textcopy(ptr %t22, ptr %t17, i64 %t18)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t20, 1
  store { i64, ptr } %t24, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t26 = load i64, ptr %l1, !tbaa !24
  %t28 = mul i64 8, %t26
  %t29 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t30 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d371, i32 0, i32 1) }, 1
  %t31 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d371, i32 0, i32 1) }, 0
  %t33 = call i64 @__olang_fmt_i64(ptr null, i64 %t28)
  %t34 = add i64 %t31, %t33
  %t35 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d372, i32 0, i32 1) }, 1
  %t36 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d372, i32 0, i32 1) }, 0
  %t37 = add i64 %t34, %t36
  %t39 = extractvalue { i64, ptr } %t29, 1
  %t40 = extractvalue { i64, ptr } %t29, 0
  %t41 = add i64 %t37, %t40
  %t42 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d373, i32 0, i32 1) }, 1
  %t43 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d373, i32 0, i32 1) }, 0
  %t44 = add i64 %t41, %t43
  %t45 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t44)
  call void @olang_textcopy(ptr %t45, ptr %t30, i64 %t31)
  %t46 = getelementptr i8, ptr %t45, i64 %t31
  %t47 = call i64 @__olang_fmt_i64(ptr %t46, i64 %t28)
  %t48 = getelementptr i8, ptr %t46, i64 %t33
  call void @olang_textcopy(ptr %t48, ptr %t35, i64 %t36)
  %t49 = getelementptr i8, ptr %t48, i64 %t36
  call void @olang_textcopy(ptr %t49, ptr %t39, i64 %t40)
  %t50 = getelementptr i8, ptr %t49, i64 %t40
  call void @olang_textcopy(ptr %t50, ptr %t42, i64 %t43)
  %t51 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t45, 1
  store { i64, ptr } %t52, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/bindgen:cFunc" @compiler_2fbindgen_3acFunc_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, i1 %a4, { i64, ptr } %a5) #0 {
entry:
  %rv = alloca %"compiler/bindgen:cFunc"
  br label %start
start:
  br label %bb0
bb0:
  %t14 = insertvalue %"compiler/bindgen:cFunc" undef, { i64, ptr } %a0, 0
  %t16 = insertvalue %"compiler/bindgen:cFunc" %t14, { i64, ptr } %a1, 1
  %t18 = insertvalue %"compiler/bindgen:cFunc" %t16, { i64, ptr } %a2, 2
  %t20 = insertvalue %"compiler/bindgen:cFunc" %t18, { i64, ptr } %a3, 3
  %t22 = insertvalue %"compiler/bindgen:cFunc" %t20, i1 %a4, 4
  %t24 = insertvalue %"compiler/bindgen:cFunc" %t22, { i64, ptr } %a5, 5
  store %"compiler/bindgen:cFunc" %t24, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/bindgen:cFunc", ptr %rv
  ret %"compiler/bindgen:cFunc" %rr
}

define dso_local void @compiler_2fbindgen_3arecord_2ector(ptr %out, ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca i1
  %l4 = alloca i1
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca i1
  %l8 = alloca { i64, ptr }
  %l9 = alloca i1
  %l10 = alloca i64
  %l11 = alloca i1
  %l12 = alloca { i64, ptr }
  %l13 = alloca i1
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i1
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l22 = alloca i64
  %l24 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l26 = alloca i64
  %l28 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l30 = alloca i64
  %l32 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l34 = alloca i64
  %l36 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l38 = alloca i64
  %l40 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l42 = alloca i64
  %l44 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l46 = alloca %"compiler/bindgen:record"
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a0, ptr %l1, !tbaa !27
  store i1 false, ptr %l2, !tbaa !21
  store i1 false, ptr %l3, !tbaa !21
  store i1 false, ptr %l4, !tbaa !21
  %t3 = call ptr @__olang_scope_hold(ptr %v1)
  %t4 = ptrtoint ptr %t3 to i64
  store i64 %t4, ptr %l22, !tbaa !24
  %t5 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3arecord_2e4
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = call ptr @__olang_region_make(ptr %v1)
  %t8 = ptrtoint ptr %t7 to i64
  store i64 %t8, ptr %l22, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l22
  %t10 = inttoptr i64 %t9 to ptr
  %t11 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t10, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t11, ptr %l24
  br label %bb3
bb3:
  %t12 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3arecord_2e4
  br i1 %t12, label %bb4, label %bb5
bb4:
  %t14 = load i64, ptr %l22
  %t15 = inttoptr i64 %t14 to ptr
  %t16 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l24, i32 0, i32 0
  %t17 = load { i64, ptr }, ptr %t16
  %t18 = extractvalue { i64, ptr } %t17, 1
  %t19 = call ptr @__olang_region_or(ptr %t18, ptr null)
  %t20 = call ptr @__olang_region_home(ptr %t19)
  %t21 = icmp ne ptr %t20, null
  %t22 = select i1 %t21, ptr %t20, ptr null
  call void @__olang_region_settle_in(ptr %t15, ptr %t22)
  br label %bb5
bb5:
  %t23 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l24
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t23, ptr %l5
  %t24 = call ptr @__olang_scope_hold(ptr %v1)
  %t25 = ptrtoint ptr %t24 to i64
  store i64 %t25, ptr %l26, !tbaa !24
  %t26 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3arecord_2e5
  br i1 %t26, label %bb6, label %bb7
bb6:
  %t28 = call ptr @__olang_region_make(ptr %v1)
  %t29 = ptrtoint ptr %t28 to i64
  store i64 %t29, ptr %l26, !tbaa !24
  br label %bb7
bb7:
  %t30 = load i64, ptr %l26
  %t31 = inttoptr i64 %t30 to ptr
  %t32 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t31, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t32, ptr %l28
  br label %bb8
bb8:
  %t33 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3arecord_2e5
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t35 = load i64, ptr %l26
  %t36 = inttoptr i64 %t35 to ptr
  %t37 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l28, i32 0, i32 0
  %t38 = load { i64, ptr }, ptr %t37
  %t39 = extractvalue { i64, ptr } %t38, 1
  %t40 = call ptr @__olang_region_or(ptr %t39, ptr null)
  %t41 = call ptr @__olang_region_home(ptr %t40)
  %t42 = icmp ne ptr %t41, null
  %t43 = select i1 %t42, ptr %t41, ptr null
  call void @__olang_region_settle_in(ptr %t36, ptr %t43)
  br label %bb10
bb10:
  %t44 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l28
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t44, ptr %l6
  store i1 false, ptr %l7, !tbaa !21
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d374, i32 0, i32 1) }, ptr %l8, !tbaa !27
  store i1 false, ptr %l9, !tbaa !21
  store i64 -1, ptr %l10, !tbaa !24
  store i1 false, ptr %l11, !tbaa !21
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d375, i32 0, i32 1) }, ptr %l12, !tbaa !27
  store i1 false, ptr %l13, !tbaa !21
  store i64 -1, ptr %l14, !tbaa !24
  store i64 -1, ptr %l15, !tbaa !24
  store i1 false, ptr %l16, !tbaa !21
  %t45 = call ptr @__olang_scope_hold(ptr %v1)
  %t46 = ptrtoint ptr %t45 to i64
  store i64 %t46, ptr %l30, !tbaa !24
  %t47 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3arecord_2e16
  br i1 %t47, label %bb11, label %bb12
bb11:
  %t49 = call ptr @__olang_region_make(ptr %v1)
  %t50 = ptrtoint ptr %t49 to i64
  store i64 %t50, ptr %l30, !tbaa !24
  br label %bb12
bb12:
  %t51 = load i64, ptr %l30
  %t52 = inttoptr i64 %t51 to ptr
  %t53 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t52, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t53, ptr %l32
  br label %bb13
bb13:
  %t54 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3arecord_2e16
  br i1 %t54, label %bb14, label %bb15
bb14:
  %t56 = load i64, ptr %l30
  %t57 = inttoptr i64 %t56 to ptr
  %t58 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l32, i32 0, i32 0
  %t59 = load { i64, ptr }, ptr %t58
  %t60 = extractvalue { i64, ptr } %t59, 1
  %t61 = call ptr @__olang_region_or(ptr %t60, ptr null)
  %t62 = call ptr @__olang_region_home(ptr %t61)
  %t63 = icmp ne ptr %t62, null
  %t64 = select i1 %t63, ptr %t62, ptr null
  call void @__olang_region_settle_in(ptr %t57, ptr %t64)
  br label %bb15
bb15:
  %t65 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l32
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t65, ptr %l17
  %t66 = call ptr @__olang_scope_hold(ptr %v1)
  %t67 = ptrtoint ptr %t66 to i64
  store i64 %t67, ptr %l34, !tbaa !24
  %t68 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3arecord_2e17
  br i1 %t68, label %bb16, label %bb17
bb16:
  %t70 = call ptr @__olang_region_make(ptr %v1)
  %t71 = ptrtoint ptr %t70 to i64
  store i64 %t71, ptr %l34, !tbaa !24
  br label %bb17
bb17:
  %t72 = load i64, ptr %l34
  %t73 = inttoptr i64 %t72 to ptr
  %t74 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t73, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t74, ptr %l36
  br label %bb18
bb18:
  %t75 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3arecord_2e17
  br i1 %t75, label %bb19, label %bb20
bb19:
  %t77 = load i64, ptr %l34
  %t78 = inttoptr i64 %t77 to ptr
  %t79 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l36, i32 0, i32 0
  %t80 = load { i64, ptr }, ptr %t79
  %t81 = extractvalue { i64, ptr } %t80, 1
  %t82 = call ptr @__olang_region_or(ptr %t81, ptr null)
  %t83 = call ptr @__olang_region_home(ptr %t82)
  %t84 = icmp ne ptr %t83, null
  %t85 = select i1 %t84, ptr %t83, ptr null
  call void @__olang_region_settle_in(ptr %t78, ptr %t85)
  br label %bb20
bb20:
  %t86 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l36
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t86, ptr %l18
  %t87 = call ptr @__olang_scope_hold(ptr %v1)
  %t88 = ptrtoint ptr %t87 to i64
  store i64 %t88, ptr %l38, !tbaa !24
  %t89 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3arecord_2e18
  br i1 %t89, label %bb21, label %bb22
bb21:
  %t91 = call ptr @__olang_region_make(ptr %v1)
  %t92 = ptrtoint ptr %t91 to i64
  store i64 %t92, ptr %l38, !tbaa !24
  br label %bb22
bb22:
  %t93 = load i64, ptr %l38
  %t94 = inttoptr i64 %t93 to ptr
  %t95 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t94, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t95, ptr %l40
  br label %bb23
bb23:
  %t96 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3arecord_2e18
  br i1 %t96, label %bb24, label %bb25
bb24:
  %t98 = load i64, ptr %l38
  %t99 = inttoptr i64 %t98 to ptr
  %t100 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l40, i32 0, i32 0
  %t101 = load { i64, ptr }, ptr %t100
  %t102 = extractvalue { i64, ptr } %t101, 1
  %t103 = call ptr @__olang_region_or(ptr %t102, ptr null)
  %t104 = call ptr @__olang_region_home(ptr %t103)
  %t105 = icmp ne ptr %t104, null
  %t106 = select i1 %t105, ptr %t104, ptr null
  call void @__olang_region_settle_in(ptr %t99, ptr %t106)
  br label %bb25
bb25:
  %t107 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l40
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t107, ptr %l19
  %t108 = call ptr @__olang_scope_hold(ptr %v1)
  %t109 = ptrtoint ptr %t108 to i64
  store i64 %t109, ptr %l42, !tbaa !24
  %t110 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3arecord_2e19
  br i1 %t110, label %bb26, label %bb27
bb26:
  %t112 = call ptr @__olang_region_make(ptr %v1)
  %t113 = ptrtoint ptr %t112 to i64
  store i64 %t113, ptr %l42, !tbaa !24
  br label %bb27
bb27:
  %t114 = load i64, ptr %l42
  %t115 = inttoptr i64 %t114 to ptr
  %t116 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t115, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t116, ptr %l44
  br label %bb28
bb28:
  %t117 = load i1, ptr @olang_2esole_2ecompiler_2fbindgen_3arecord_2e19
  br i1 %t117, label %bb29, label %bb30
bb29:
  %t119 = load i64, ptr %l42
  %t120 = inttoptr i64 %t119 to ptr
  %t121 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l44, i32 0, i32 0
  %t122 = load { i64, ptr }, ptr %t121
  %t123 = extractvalue { i64, ptr } %t122, 1
  %t124 = call ptr @__olang_region_or(ptr %t123, ptr null)
  %t125 = call ptr @__olang_region_home(ptr %t124)
  %t126 = icmp ne ptr %t125, null
  %t127 = select i1 %t126, ptr %t125, ptr null
  call void @__olang_region_settle_in(ptr %t120, ptr %t127)
  br label %bb30
bb30:
  %t128 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l44
  %t129 = getelementptr %"compiler/bindgen:record", ptr %l46, i32 0, i32 0
  %t130 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t130, ptr %t129, !tbaa !27
  %t131 = getelementptr %"compiler/bindgen:record", ptr %l46, i32 0, i32 1
  %t132 = load i1, ptr %l2, !tbaa !21
  store i1 %t132, ptr %t131, !tbaa !21
  %t133 = getelementptr %"compiler/bindgen:record", ptr %l46, i32 0, i32 2
  %t134 = load i1, ptr %l3, !tbaa !21
  store i1 %t134, ptr %t133, !tbaa !21
  %t135 = getelementptr %"compiler/bindgen:record", ptr %l46, i32 0, i32 3
  %t136 = load i1, ptr %l4, !tbaa !21
  store i1 %t136, ptr %t135, !tbaa !21
  %t137 = getelementptr %"compiler/bindgen:record", ptr %l46, i32 0, i32 4
  %t138 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t138, ptr %t137
  %t139 = getelementptr %"compiler/bindgen:record", ptr %l46, i32 0, i32 5
  %t140 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t140, ptr %t139
  %t141 = getelementptr %"compiler/bindgen:record", ptr %l46, i32 0, i32 6
  %t142 = load i1, ptr %l7, !tbaa !21
  store i1 %t142, ptr %t141, !tbaa !21
  %t143 = getelementptr %"compiler/bindgen:record", ptr %l46, i32 0, i32 7
  %t144 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t144, ptr %t143, !tbaa !27
  %t145 = getelementptr %"compiler/bindgen:record", ptr %l46, i32 0, i32 8
  %t146 = load i1, ptr %l9, !tbaa !21
  store i1 %t146, ptr %t145, !tbaa !21
  %t147 = getelementptr %"compiler/bindgen:record", ptr %l46, i32 0, i32 9
  %t148 = load i64, ptr %l10, !tbaa !24
  store i64 %t148, ptr %t147, !tbaa !24
  %t149 = getelementptr %"compiler/bindgen:record", ptr %l46, i32 0, i32 10
  %t150 = load i1, ptr %l11, !tbaa !21
  store i1 %t150, ptr %t149, !tbaa !21
  %t151 = getelementptr %"compiler/bindgen:record", ptr %l46, i32 0, i32 11
  %t152 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t152, ptr %t151, !tbaa !27
  %t153 = getelementptr %"compiler/bindgen:record", ptr %l46, i32 0, i32 12
  %t154 = load i1, ptr %l13, !tbaa !21
  store i1 %t154, ptr %t153, !tbaa !21
  %t155 = getelementptr %"compiler/bindgen:record", ptr %l46, i32 0, i32 13
  %t156 = load i64, ptr %l14, !tbaa !24
  store i64 %t156, ptr %t155, !tbaa !24
  %t157 = getelementptr %"compiler/bindgen:record", ptr %l46, i32 0, i32 14
  %t158 = load i64, ptr %l15, !tbaa !24
  store i64 %t158, ptr %t157, !tbaa !24
  %t159 = getelementptr %"compiler/bindgen:record", ptr %l46, i32 0, i32 15
  %t160 = load i1, ptr %l16, !tbaa !21
  store i1 %t160, ptr %t159, !tbaa !21
  %t161 = getelementptr %"compiler/bindgen:record", ptr %l46, i32 0, i32 16
  %t162 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t162, ptr %t161
  %t163 = getelementptr %"compiler/bindgen:record", ptr %l46, i32 0, i32 17
  %t164 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t164, ptr %t163
  %t165 = getelementptr %"compiler/bindgen:record", ptr %l46, i32 0, i32 18
  %t166 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t166, ptr %t165
  %t167 = getelementptr %"compiler/bindgen:record", ptr %l46, i32 0, i32 19
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t128, ptr %t167
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l46, i64 312, i1 false)
  br label %ret
ret:
  ret void
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d0 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" | " }>, align 8
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@olang_2esole_2ecompiler__2fbindgen__2eaccessors_2elocal_2e15 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
@.d1 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"s." }>, align 8
@.d2 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d3 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"]" }>, align 8
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare ptr @__olang_region_or(ptr, ptr)
declare void @__olang_region_settle_in(ptr, ptr)
@.d4 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d5 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" << " }>, align 8
@.d6 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
declare void @__olang_region_release(ptr) noinline
@.d7 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d8 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" >> " }>, align 8
@.d9 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@olang_2esole_2ecompiler__2fbindgen__2eaccessors_2elocal_2e17 = weak hidden constant i1 false
@.d10 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d11 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c") & " }>, align 8
@.d12 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"\0Afn (s " }>, align 8
@.d13 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"&) " }>, align 8
@.d14 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"() " }>, align 8
@.d15 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c" {\0A    bits := " }>, align 8
@.d16 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@.d17 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"    return " }>, align 8
@.d18 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"\0A}\0A" }>, align 8
@.d19 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"\0Afn (s mut " }>, align 8
@.d20 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"&) set_" }>, align 8
@.d21 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"(v " }>, align 8
@.d22 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c") {\0A    bits := " }>, align 8
@.d23 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d24 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"bits" }>, align 8
@olang_2esole_2ecompiler__2fbindgen__2eaccessors_2elocal_2e25 = weak hidden constant i1 false
@.d25 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"(bits >> " }>, align 8
@.d26 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d27 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"(bits << " }>, align 8
@.d28 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d29 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"s." }>, align 8
@.d30 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d31 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"]" }>, align 8
@.d32 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d33 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
@.d34 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d35 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler__2fbindgen__2eaccessors_2elocal_2e29 = weak hidden constant i1 false
@.d36 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" | " }>, align 8
@.d37 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d38 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" & (" }>, align 8
@.d39 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c")) | (" }>, align 8
@.d40 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" & " }>, align 8
@.d41 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d42 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d43 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
@.d44 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d45 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"}\0A" }>, align 8
@.d46 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"0x" }>, align 8
@.d47 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"FF" }>, align 8
@.d48 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"00" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
declare void @__olang_check_failed(ptr) cold noreturn
@.d49 = private constant <{ i64, [4 x { i64, ptr }] }> <{ i64 0, [4 x { i64, ptr }] [{ i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d376, i32 0, i32 1) }, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d377, i32 0, i32 1) }, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d378, i32 0, i32 1) }, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d379, i32 0, i32 1) }] }>, align 8
@.d50 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"<<=" }>, align 8
@.d51 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c">>=" }>, align 8
@.d52 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"..." }>, align 8
@.d53 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"<<" }>, align 8
@.d54 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c">>" }>, align 8
@.d55 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"<=" }>, align 8
@.d56 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c">=" }>, align 8
@.d57 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"==" }>, align 8
@.d58 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"!=" }>, align 8
@.d59 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"&&" }>, align 8
@.d60 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"||" }>, align 8
@.d61 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"##" }>, align 8
@.d62 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"->" }>, align 8
@.d63 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"++" }>, align 8
@.d64 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"--" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d65 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"||" }>, align 8
@.d66 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"&&" }>, align 8
@.d67 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"|" }>, align 8
@.d68 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"^" }>, align 8
@.d69 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"&" }>, align 8
@.d70 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"==" }>, align 8
@.d71 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"!=" }>, align 8
@.d72 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"<" }>, align 8
@.d73 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c">" }>, align 8
@.d74 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"<=" }>, align 8
@.d75 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c">=" }>, align 8
@.d76 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"<<" }>, align 8
@.d77 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c">>" }>, align 8
@.d78 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"+" }>, align 8
@.d79 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"-" }>, align 8
@.d80 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"*" }>, align 8
@.d81 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d82 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"%" }>, align 8
@.d83 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"&&" }>, align 8
@.d84 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"||" }>, align 8
@olang_2esole_2ecompiler_2fbindgen_3acx_2e0 = weak hidden constant i1 false
@.d85 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"&&" }>, align 8
@.d86 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" and " }>, align 8
@.d87 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" or " }>, align 8
@.d88 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d89 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d90 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2fbindgen_3acx_2e3 = weak hidden constant i1 false
@.d91 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d92 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d93 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d94 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d95 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d96 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d97 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d98 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d99 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"?" }>, align 8
@.d100 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d101 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"a ? with no :" }>, align 8
@.d102 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d103 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" if " }>, align 8
@.d104 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" else " }>, align 8
@.d105 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d106 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d107 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d108 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" if " }>, align 8
@.d109 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" else " }>, align 8
@.d110 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d111 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"0x" }>, align 8
@.d112 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d113 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"e" }>, align 8
@.d114 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"p" }>, align 8
@.d115 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"a hexadecimal float" }>, align 8
@.d116 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"a long double" }>, align 8
@.d117 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d118 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d119 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".0" }>, align 8
@.d120 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"0b" }>, align 8
@.d121 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"0" }>, align 8
@.d122 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"0" }>, align 8
@olang_2esole_2ecompiler_2fbindgen_3agen_2e26 = weak hidden constant i1 false
@.d123 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d124 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"', which is no number read here" }>, align 8
@.d125 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"-" }>, align 8
@.d126 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"+" }>, align 8
@.d127 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"~" }>, align 8
@.d128 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"+" }>, align 8
@.d129 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d130 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d131 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"!" }>, align 8
@.d132 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"(not " }>, align 8
@.d133 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d134 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d135 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d136 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d137 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d138 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d139 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d140 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d141 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d142 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-x" }>, align 8
@.d143 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"c" }>, align 8
@.d144 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"-fsyntax-only" }>, align 8
@.d145 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-w" }>, align 8
@.d146 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"-ferror-limit=0" }>, align 8
@.d147 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"-Xclang" }>, align 8
@.d148 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"-ast-dump=json" }>, align 8
@.d149 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"clang could not be run" }>, align 8
declare void @__olang_errpay_pop()
@.d150 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"clang's tree could not be read" }>, align 8
@.d151 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"its expansion is too deep" }>, align 8
@.d152 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"#" }>, align 8
@.d153 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"##" }>, align 8
@.d154 = private constant <{ i64, [58 x i8] }> <{ i64 0, [58 x i8] c"it uses # or ##, which make text rather than an expression" }>, align 8
@.d155 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1 = weak hidden constant i1 false
@.d156 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d157 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"it uses " }>, align 8
@.d158 = private constant <{ i64, [44 x i8] }> <{ i64 0, [44 x i8] c", which takes a variable number of arguments" }>, align 8
@olang_2esole_2ecompiler__2fbindgen__2ecompiler__2fbindgen__3agen__2eexpand_2elocal_2e14 = weak hidden constant i1 false
declare ptr @__olang_region_home(ptr)
@.d159 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d160 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d161 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"," }>, align 8
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

declare void @__olang_region_drop(ptr) noinline
@olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e0 = weak hidden constant i1 false
declare void @__olang_region_release_part(ptr, i64) noinline
@.d162 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"its use of " }>, align 8
@.d163 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c" is not closed" }>, align 8
@.d164 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"it gives " }>, align 8
@.d165 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c" another number of arguments" }>, align 8
define available_externally void @__olang_scope_escape(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %un = icmp eq ptr %o, null
  br i1 %un, label %claim, label %done
claim:
  %me = load ptr, ptr @__olang_self
  store atomic ptr %me, ptr %op monotonic, align 8
  br label %done
done:
  ret void
}
define internal i1 @olang_lambda_166(ptr %env, ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l4 = alloca i1
  %rv = alloca i1
  %cp0 = getelementptr { { i64, ptr }, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load { i64, ptr }, ptr %cp0, !tbaa !28
  %vq0 = getelementptr { { i64, ptr }, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %vc0, { i64, ptr } %a0, { i64, ptr } %cv0)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  store i1 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d167 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d168 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d169 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"U8" }>, align 8
@.d170 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d171 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" := Array<" }>, align 8
@.d172 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c">(" }>, align 8
@.d173 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c")\0A" }>, align 8
@.d174 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"U8" }>, align 8
@.d175 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d176 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d177 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d178 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"char" }>, align 8
@.d179 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"U8" }>, align 8
@.d180 = private constant <{ i64, [51 x i8] }> <{ i64 0, [51 x i8] c"a struct held in place that is not plain data (X11)" }>, align 8
@.d181 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"CStr?&" }>, align 8
@.d182 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"?&" }>, align 8
@.d183 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"CVoid?&" }>, align 8
@.d184 = private constant <{ i64, [45 x i8] }> <{ i64 0, [45 x i8] c"a field of this type, which has no olang form" }>, align 8
@.d185 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d186 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"its type is no function's" }>, align 8
@.d187 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fn " }>, align 8
@.d188 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d189 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d190 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d191 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d192 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"variadic" }>, align 8
@.d193 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c", ..." }>, align 8
@.d194 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"..." }>, align 8
@.d195 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d196 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d197 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" noreturn" }>, align 8
@.d198 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"char" }>, align 8
@.d199 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"its body is empty" }>, align 8
@olang_2esole_2ecompiler_2fbindgen_3acparse_2e0 = weak hidden constant i1 false
@.d200 = private constant <{ i64, [41 x i8] }> <{ i64 0, [41 x i8] c"its body is no expression read here, at '" }>, align 8
@.d201 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d202 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fn " }>, align 8
@.d203 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"<" }>, align 8
@.d204 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d205 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d206 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"T" }>, align 8
@.d207 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c">" }>, align 8
@.d208 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d209 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d210 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d211 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"a" }>, align 8
@.d212 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" T" }>, align 8
@.d213 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c") " }>, align 8
@.d214 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"T" }>, align 8
@.d215 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Bool" }>, align 8
@.d216 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F64" }>, align 8
@.d217 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d218 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" { return " }>, align 8
@.d219 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" }" }>, align 8
@.d220 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@olang_2esole_2ecompiler__2fbindgen__2ecompiler__2fbindgen__3agen__2enameRecord_2elocal_2e4 = weak hidden constant i1 false
@.d221 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d222 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2fbindgen_3arecord_2e11 = weak hidden constant i1 false
@.d223 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d224 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d225 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"c_" }>, align 8
@.d226 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"_t" }>, align 8
@olang_2esole_2ecompiler_2fbindgen_3arecord_2e7 = weak hidden constant i1 false
@.d227 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"variadic" }>, align 8
@.d228 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d229 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d230 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c"its text is no olang text literal" }>, align 8
@.d231 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" String = " }>, align 8
@olang_2esole_2ecompiler_2fbindgen_3acparse_2e1 = weak hidden constant i1 false
@__olang_empty_array = external constant [16 x i64]
@.d232 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"f" }>, align 8
@.d233 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d234 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"f" }>, align 8
@.d235 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" F32 = " }>, align 8
@.d236 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" F64 = " }>, align 8
@.d237 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"its body is no constant" }>, align 8
@olang_2esole_2ecompiler__2fbindgen__2ecompiler__2fbindgen__3agen__2eparamName_2elocal_2e5 = weak hidden constant i1 false
@.d238 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"CVoid" }>, align 8
@.d239 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"CStr" }>, align 8
@.d240 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"a" }>, align 8
define linkonce_odr void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fbindgen_3arecord(ptr %out, ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/bindgen:record"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %a0, i64 312, i1 false)
  %t2 = getelementptr %"compiler/bindgen:record", ptr %l1, i32 0, i32 4
  %t4 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %t2)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t6 = getelementptr %"compiler/bindgen:record", ptr %l1, i32 0, i32 4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %t6
  %t7 = getelementptr %"compiler/bindgen:record", ptr %l1, i32 0, i32 5
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %t7)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l5
  br label %bb2
bb2:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  %t11 = getelementptr %"compiler/bindgen:record", ptr %l1, i32 0, i32 5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %t11
  %t12 = getelementptr %"compiler/bindgen:record", ptr %l1, i32 0, i32 16
  %t14 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t12)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l7
  br label %bb3
bb3:
  %t15 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  %t16 = getelementptr %"compiler/bindgen:record", ptr %l1, i32 0, i32 16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %t16
  %t17 = getelementptr %"compiler/bindgen:record", ptr %l1, i32 0, i32 17
  %t19 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t17)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l9
  br label %bb4
bb4:
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  %t21 = getelementptr %"compiler/bindgen:record", ptr %l1, i32 0, i32 17
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %t21
  %t22 = getelementptr %"compiler/bindgen:record", ptr %l1, i32 0, i32 18
  %t24 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t22)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %l11
  br label %bb5
bb5:
  %t25 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  %t26 = getelementptr %"compiler/bindgen:record", ptr %l1, i32 0, i32 18
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %t26
  %t27 = getelementptr %"compiler/bindgen:record", ptr %l1, i32 0, i32 19
  %t29 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t27)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t29, ptr %l13
  br label %bb6
bb6:
  %t30 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  %t31 = getelementptr %"compiler/bindgen:record", ptr %l1, i32 0, i32 19
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t30, ptr %t31
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l1, i64 312, i1 false)
  br label %ret
ret:
  ret void
}

@.d241 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d242 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"char" }>, align 8
@.d243 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"U8" }>, align 8
@.d244 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Array<" }>, align 8
@.d245 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c">" }>, align 8
@.d246 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"mut Array<" }>, align 8
@.d247 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c">&" }>, align 8
@.d248 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d249 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"mut " }>, align 8
@.d250 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"?&" }>, align 8
@.d251 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"mut Array<CStr?&>&" }>, align 8
@.d252 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"mut Array<" }>, align 8
@.d253 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"?&>&" }>, align 8
@.d254 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"mut Array<CVoid?&>&" }>, align 8
@.d255 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"variadic" }>, align 8
@.d256 = private constant <{ i64, [48 x i8] }> <{ i64 0, [48 x i8] c"a callback taking a variable number of arguments" }>, align 8
@.d257 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"loc" }>, align 8
@.d258 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"range" }>, align 8
@.d259 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"type" }>, align 8
@.d260 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"inner" }>, align 8
@.d261 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"kind" }>, align 8
@.d262 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"name" }>, align 8
@.d263 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"TypedefDecl" }>, align 8
@.d264 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"ownedTagDecl" }>, align 8
@.d265 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"id" }>, align 8
@.d266 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"struct " }>, align 8
@.d267 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"union " }>, align 8
@olang_2esole_2ecompiler_2fbindgen_3arecord_2e0 = weak hidden constant i1 false
@.d268 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d269 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"RecordDecl" }>, align 8
@.d270 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"EnumDecl" }>, align 8
@.d271 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"kind" }>, align 8
@.d272 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"EnumConstantDecl" }>, align 8
@.d273 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d274 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"name" }>, align 8
@.d275 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"FunctionDecl" }>, align 8
@.d276 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"isImplicit" }>, align 8
@.d277 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"kind" }>, align 8
@.d278 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"ParmVarDecl" }>, align 8
@.d279 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"name" }>, align 8
@.d280 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"storageClass" }>, align 8
@.d281 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"static" }>, align 8
@.d282 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"inline" }>, align 8
@.d283 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"mangledName" }>, align 8
@.d284 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d285 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2fbindgen_3acFunc_2e1 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fbindgen_3acFunc_2e2 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fbindgen_3acFunc_2e3 = weak hidden constant i1 false
@.d286 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"VarDecl" }>, align 8
@.d287 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"storageClass" }>, align 8
@.d288 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"static" }>, align 8
@.d289 = private constant <{ i64, [56 x i8] }> <{ i64 0, [56 x i8] c": a variable - an extern variable has no olang form (X1)" }>, align 8
@.d290 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d291 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d292 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d293 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"enum __olang_l" }>, align 8
@.d294 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c" : long long { __olang_z" }>, align 8
@.d295 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" = sizeof(" }>, align 8
@.d296 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"), __olang_a" }>, align 8
@.d297 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c" = _Alignof(" }>, align 8
@.d298 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c") };\0A" }>, align 8
@.d299 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"((" }>, align 8
@.d300 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" *)0)->" }>, align 8
@.d301 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d302 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"enum __olang_m" }>, align 8
@.d303 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c" : long long { __olang_mo" }>, align 8
@.d304 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c" = __builtin_offsetof(" }>, align 8
@.d305 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d306 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"), __olang_ms" }>, align 8
@.d307 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" = sizeof(" }>, align 8
@.d308 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"), __olang_ma" }>, align 8
@.d309 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c" = __alignof__(" }>, align 8
@.d310 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c") };\0A" }>, align 8
@.d311 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"enum __olang_u" }>, align 8
@.d312 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d313 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c" : long long { __olang_uo" }>, align 8
@.d314 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c" = __builtin_offsetof(" }>, align 8
@.d315 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d316 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c") };\0A" }>, align 8
@.d317 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"the probe cannot be written" }>, align 8
@.d318 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"name" }>, align 8
@.d319 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"kind" }>, align 8
@.d320 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"EnumDecl" }>, align 8
@.d321 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"__olang_m" }>, align 8
@.d322 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"kind" }>, align 8
@.d323 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"EnumDecl" }>, align 8
@.d324 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"__olang_u" }>, align 8
@.d325 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"kind" }>, align 8
@.d326 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"EnumDecl" }>, align 8
@.d327 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"__olang_l" }>, align 8
@.d328 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d329 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"includedFrom" }>, align 8
@.d330 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"file" }>, align 8
declare ptr @__olang_region_make_part(ptr) noinline
@olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0 = weak hidden constant i1 false
@.d331 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d332 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d333 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"error: " }>, align 8
@.d334 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Bool" }>, align 8
@.d335 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"bits != 0" }>, align 8
@.d336 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"F" }>, align 8
@.d337 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"BF16" }>, align 8
@.d338 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c".FromBits(U" }>, align 8
@.d339 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"(bits))" }>, align 8
@.d340 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d341 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"I64(bits)" }>, align 8
@.d342 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"I" }>, align 8
@.d343 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"(U" }>, align 8
@.d344 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"(bits))" }>, align 8
@.d345 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U64" }>, align 8
@.d346 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"bits" }>, align 8
@.d347 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"(bits)" }>, align 8
@.d348 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d349 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I32" }>, align 8
@.d350 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I16" }>, align 8
@.d351 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"U8" }>, align 8
@.d352 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"    c_gap" }>, align 8
@.d353 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" := Array<" }>, align 8
@.d354 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c">(" }>, align 8
@.d355 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c")\0A" }>, align 8
@.d356 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d357 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d358 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d359 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d360 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d361 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d362 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d363 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d364 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d365 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d366 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\5Cx" }>, align 8
@.d367 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"CVoid?&" }>, align 8
@.d368 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"mut CVoid?&" }>, align 8
@.d369 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"U64(" }>, align 8
@.d370 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d371 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"U64(U" }>, align 8
@.d372 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d373 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"))" }>, align 8
@olang_2esole_2ecompiler_2fbindgen_3arecord_2e4 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fbindgen_3arecord_2e5 = weak hidden constant i1 false
@.d374 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d375 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2fbindgen_3arecord_2e16 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fbindgen_3arecord_2e17 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fbindgen_3arecord_2e18 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fbindgen_3arecord_2e19 = weak hidden constant i1 false
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@.d376 = private unnamed_addr constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"L" }>, align 8
@.d377 = private unnamed_addr constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"u" }>, align 8
@.d378 = private unnamed_addr constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"U" }>, align 8
@.d379 = private unnamed_addr constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"u8" }>, align 8
@__olang_self = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
declare ptr @__olang_scope_mine_slow(ptr) noinline
declare i64 @compiler_2fbindgen_2enumBytes(ptr %v0, { i64, ptr } %a0)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2fbindgen_2etoBits(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1)
declare i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %a0, i64 %a1)
declare i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %a0, i64 %a1)
declare { i64, ptr } @compiler_2fbindgen_2ewordOf(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
@olang_loc_4691cb288a833ba5_dfaa9dffbec0c2d9 = external constant [0 x i8]
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eHas_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_8de001e7a64c0b48_1a9d06562d43232c = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_9f24fc1b10bf4163_f387df93e06eee97 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_760c7c7ac1a62521_16c6052ca99c0395 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3acparse_2eat(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/bindgen:cx" @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecBool(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/bindgen:cx" %a1)
@G_2ecompiler_2fbindgen_2eKBool = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/bindgen:cx" @compiler_2fbindgen_3acx_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, i64 %a1, i64 %a2, { i64, ptr } %a3)
declare %"compiler/bindgen:cx" @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecNum(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/bindgen:cx" %a1)
declare %"compiler/bindgen:cx" @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecLead(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/bindgen:cx" %a1, %"compiler/bindgen:cx" %a2)
@G_2ecompiler_2fbindgen_2eKInt = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/bindgen:cx" @compiler_2fbindgen_2ecx_2elit(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1)
declare i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskip(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eToLower(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_2281448cce404233_754aa41ddbc9325f = external constant [0 x i8]
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %a0, i8 %a1)
@olang_loc_231822a9f2b4ccd6_f89b0d7c0520fae2 = external constant [0 x i8]
@olang_loc_3945c858895394b5_b3e6527511891161 = external constant [0 x i8]
@olang_loc_5833c224f66d4858_52a9715d8b07374 = external constant [0 x i8]
@G_2ecompiler_2fbindgen_2eKFloat = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@olang_loc_8ffdd2b799db8b57_8707d2f5a85c3a7b = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecastType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2fbindgen_2eKType = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
declare { i32, %"compiler/bindgen:cx" } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecPrimary(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"std/os:Output" } @compiler_2fbindgen_2eclangSays(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, ptr } @std_2fjson_2eJson_2eParse(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/bindgen:cMacro" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acMacro_3e_2eAt_3ccompiler_2fbindgen_3acMacro_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H0127831368543eff3b7740d7d3240080(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_Hdc04e7543082eec80486670259c0789b(ptr %v0, ptr %v1, ptr %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cstd_2fprel_H40771be639b3022d183b79789a9eab56(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cstd_2fprel_Hbb0b9cf8ae0bb786ffc6cf28ae45ef64(ptr %v0, ptr %a0)
declare { i32, i64 } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eFindIndex_3cstd_2f_H0cdaf28864c9da4990596b1986b376a0(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1c, ptr %a1e)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cstd_2fprel_H21d8db2bdfeb46fab755f8173a35f95e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eparseType(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare %"compiler/bindgen:ctype" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3actype_3e_2eAt_3ccompiler_2fbindgen_3actype_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2erecOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eholdable(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ename(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eisByte(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ecFunc(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/bindgen:ctype" %a1)
@olang_loc_582986fcdf40d11c_2a39a940a03de888 = external constant [0 x i8]
declare i32 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eflat(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, ptr %a3)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eAt_3ccompiler_2fbindgen_3arecord_3e(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fbindgen_2enoReturnOf(ptr %v0, ptr %v1, { i64, ptr } %a0)
@G_2ecompiler_2fbindgen_2eNoReturnAttr = external constant <{ [8 x i8], ptr }>
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eparamType(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2evalueType(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i1 %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6f7a2f8d839c49b6e7a19c287d4b190c(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @compiler_2fbindgen_2egapWord(i64 %a0, i64 %a1, i64 %a2)
declare %"compiler/bindgen:cparse" @compiler_2fbindgen_3acparse_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@G_2ecompiler_2fbindgen_2eKVar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@olang_loc_7ea854ff7e2640a8_63f49c54b749b4b4 = external constant [0 x i8]
@olang_loc_a7b3c7a1d63bebad_eca1091badac82d1 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fbindgen_2einner(ptr %v0, ptr %v1, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRefMu_Hc21bcd245b67ffb6ee3e145838fcf2cf(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fbindgen_2econstValue(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_7e828aa3d49398bd_dbb08dcf54087001 = external constant [0 x i8]
declare i1 @compiler_2fbindgen_2eusable(ptr %v0, { i64, ptr } %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2fbindgen_2epreludeName(ptr %v0, { i64, ptr } %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acMacro_3e_2eLen_3ccompiler_2fbindgen_3acMacro_3e(ptr %v0, ptr %a0)
declare void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eskippedMacro(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i64 @compiler_2fbindgen_2ebodyKind(ptr %v0, ptr %a0)
@olang_loc_588cbeac7c6acbe1_e04f9e86f435a7f5 = external constant [0 x i8]
@olang_loc_76a2c5c4ca94453d_57e44e0801590749 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2epackedFields(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2ehasAnon(ptr %v0, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2efnSpelled(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/bindgen:ctype" %a1)
@olang_loc_55ef846781ac27aa_5519550b25564c26 = external constant [0 x i8]
declare ptr @compiler_2fbindgen_2emember(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fbindgen_2etext(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fbindgen_2etypeOf(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2erecordDecl(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2, i1 %a3)
declare void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2econstant(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare i1 @compiler_2fbindgen_2eflag(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acFunc_3e_2ePush_3ccompiler_2fbindgen_3acFunc_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/bindgen:cFunc" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acFunc_3e_2eLen_3ccompiler_2fbindgen_3acFunc_3e(ptr %v0, ptr %a0)
declare %"compiler/bindgen:cFunc" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3acFunc_3e_2eAt_3ccompiler_2fbindgen_3acFunc_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2erecordAt(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eLen_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbindgen_3arecord_3e_2eRef_3ccompiler_2fbindgen_3arecord_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %a0)
declare i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2fbindgen_2ecompiler_2fbindgen_3agen_2eunionMember(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, ptr %a3)
@olang_loc_f6b0d4dcea5d2bc9_16e8d1d827605cbd = external constant [0 x i8]
declare i64 @std_2fjson_2estd_2fjson_3aObject_2eLen(ptr %v0, ptr %a0)
@olang_loc_c54e19abcb0a74ad_a74456fc2d527de1 = external constant [0 x i8]
@olang_loc_3dee357bb9e78e13_5fc101397bdf658f = external constant [0 x i8]
declare %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_b4f4b1f3947eb18f_4b11d328df759133 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_63a5955120245215_3bb90f7c84aecf01 = external constant [0 x i8]
declare i8 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eToLower(i8 %a0)
@olang_loc_d82489adf04aec69_8da73aeba875ea7d = external constant [0 x i8]
@olang_loc_e159f608b90be7c_888d447c7b7c1020 = external constant [0 x i8]
@olang_loc_2265f42fe0f29d10_7d9e15ddc2058014 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2eU8_2eFormat(ptr %v0, i8 %a0, i64 %a1)
@olang_loc_6de4e6ae025697a1_ab8e19fa95fbb0c5 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i8 %a2)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
