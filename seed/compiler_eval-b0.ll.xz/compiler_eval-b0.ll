; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/eval:Ptr" = type { i64, i64 }
%"compiler/eval:gkey" = type { i64, i32 }
%"compiler/eval:global" = type { i64, i1, i64, i64, i64, i1, i1, i1 }
%"compiler/eval:Machine" = type { ptr, i32, i64, { ptr, ptr }, { ptr, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/mir:GenInfo", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/eval:Ptr", i32, { i64, [5 x i64] }, i64, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, i64, { i64, ptr }, { i64, ptr }, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i64, { i64, ptr }, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, i64, { i64, ptr }, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"compiler/source:Span", i32 }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/mir:GenInfo" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/eval:alloc" = type { i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i32, i64, i1, i64, i1 }
%"compiler/eval:Image" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1 }
%"compiler/eval:Blob" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/mir:Fn" = type { { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/mir:BasicBlock" = type { %"compiler/mir:StmtList", { i64, [8 x i64] } }
%"compiler/mir:StmtList" = type { { i64, ptr }, i64 }
%"compiler/eval:frame" = type { i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i1, i1, i1, i64, i64, i1, i64, i32, i32, i64 }
%"compiler/mir:Call" = type { { i64, [7 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Lvalue", i1, i32, i32, i32 }
%"compiler/mir:Range" = type { i32, i32 }
%"compiler/mir:Lvalue" = type { { i64, [2 x i64] }, %"compiler/mir:Range" }
%"compiler/eval:genRec" = type { i64, i64, %"compiler/eval:frame", i64, %"compiler/eval:Ptr", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i64, i64 }
%"compiler/eval:scope" = type { i64, i1, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i1, i64, i64, i1, i1 }
%"compiler/eval:reg" = type { i64, i64, i64, i64, i64, i64, i64, i64 }
%"compiler/eval:task" = type { i64, i64, i64, i64, i64 }
%"compiler/mir:Task" = type { { i64, [7 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/source:Span", %"compiler/mir:Range", i64, i64, %"compiler/mir:Range" }
%"compiler/eval:cfn" = type { i64, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i1, i1, { i64, ptr } }
%"compiler/mir:Local" = type { i32, %"compiler/source:Span", i32, i32, { i64, [1 x i64] } }
%"compiler/mir:TaskClause" = type { %"compiler/mir:Range", i1, { i64, [4 x i64] } }
%"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" = type { ptr, i64 }
%"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/eval:Snapshot" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
define dso_local i64 @compiler_2feval_2ebitOp(i32 %a0, i64 %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l23 = alloca i1
  %l26 = alloca i1
  %l33 = alloca i64
  %l36 = alloca i64
  %l45 = alloca i64
  %l48 = alloca i1
  %l60 = alloca i64
  %l66 = alloca i64
  %l71 = alloca i64
  %l89 = alloca i64
  %l94 = alloca i64
  %l97 = alloca i64
  %l107 = alloca i64
  %l110 = alloca i64
  %l119 = alloca i64
  %l122 = alloca i1
  %l137 = alloca i64
  %l145 = alloca i64
  %l176 = alloca i64
  %l182 = alloca i64
  %rv = alloca i64
  store i32 %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !range !{i32 0, i32 54}
  %t3 = trunc i64 34 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb3
bb2:
  %t6 = load i32, ptr %l0, !range !{i32 0, i32 54}
  %t8 = trunc i64 32 to i32
  %t9 = icmp eq i32 %t6, %t8
  store i1 %t9, ptr %l23, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l23, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb6
bb5:
  %t12 = load i32, ptr %l0, !range !{i32 0, i32 54}
  %t14 = trunc i64 33 to i32
  %t15 = icmp eq i32 %t12, %t14
  store i1 %t15, ptr %l26, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l26, !tbaa !21
  br i1 %t17, label %bb7, label %bb8
bb7:
  store i64 0, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  %t18 = load i64, ptr %l2, !tbaa !24
  store i64 %t18, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t20 = load i64, ptr %l6, !tbaa !24
  %t21 = load i64, ptr %l5, !tbaa !24
  %t24 = icmp sgt i64 %t20, %t21
  br i1 %t24, label %bb9, label %bb10
bb8:
  br label %bb36
bb9:
  %t26 = load i64, ptr %l7, !tbaa !24
  %t28 = icmp sgt i64 %t26, 0
  br i1 %t28, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb14
bb11:
  %t30 = load i64, ptr %l6, !tbaa !24
  %t31 = load i64, ptr %l5, !tbaa !24
  %t34 = sub i64 %t30, %t31
  %t35 = load i64, ptr %l7, !tbaa !24
  %t38 = add i64 %t34, %t35
  %t40 = sub i64 %t38, 1
  %t41 = load i64, ptr %l7, !tbaa !24
  %t44 = sdiv i64 %t40, %t41
  store i64 %t44, ptr %l36, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l36, !tbaa !24
  br label %bb13
bb13:
  %t46 = load i64, ptr %l36, !tbaa !24
  store i64 %t46, ptr %l33, !tbaa !24
  br label %bb14
bb14:
  %t47 = load i64, ptr %l33, !tbaa !24
  store i64 %t47, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  %t48 = load i64, ptr %l8, !tbaa !24
  %t49 = sub i64 %t48, 1
  store i64 %t49, ptr %l45, !tbaa !24
  %t50 = load i64, ptr %l8, !tbaa !24
  %t51 = icmp slt i64 %t50, 2147483648
  %t52 = load i64, ptr %l9, !tbaa !24
  %t53 = icmp sge i64 %t52, 0
  %t56 = and i1 %t51, %t53
  store i1 %t56, ptr %l48, !tbaa !21
  br label %bb15
bb15:
  %t57 = load i64, ptr %l9, !tbaa !24
  %t58 = load i64, ptr %l8, !tbaa !24
  %t61 = icmp slt i64 %t57, %t58
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb16, label %bb17
bb16:
  br label %bb32
bb17:
  br label %bb18
bb18:
  %t65 = load i64, ptr %l5, !tbaa !24
  %t66 = load i64, ptr %l9, !tbaa !24
  %t67 = load i64, ptr %l7, !tbaa !24
  %t70 = mul i64 %t66, %t67
  %t73 = add i64 %t65, %t70
  store i64 %t73, ptr %l10, !tbaa !24
  %t75 = load i32, ptr %l0, !range !{i32 0, i32 54}
  %t77 = trunc i64 32 to i32
  %t78 = icmp eq i32 %t75, %t77
  br i1 %t78, label %bb19, label %bb20
bb19:
  %t80 = load i64, ptr %l1, !tbaa !65
  %t81 = load i64, ptr %l2, !tbaa !24
  %t83 = sub i64 %t81, 1
  %t84 = load i64, ptr %l10, !tbaa !24
  %t87 = sub i64 %t83, %t84
  store i64 %t87, ptr %l66, !tbaa !65
  %t90 = load i64, ptr %l66, !tbaa !65
  %t91 = load i64, ptr %l66, !tbaa !65
  %t92 = lshr i64 %t80, %t91
  %t94 = and i64 %t92, 1
  store i64 %t94, ptr %l60, !tbaa !65
  br label %bb21
bb20:
  %t96 = load i64, ptr %l1, !tbaa !65
  %t97 = load i64, ptr %l10, !tbaa !24
  store i64 %t97, ptr %l71, !tbaa !65
  %t100 = load i64, ptr %l71, !tbaa !65
  %t101 = load i64, ptr %l71, !tbaa !65
  %t102 = lshr i64 %t96, %t101
  %t104 = and i64 %t102, 1
  store i64 %t104, ptr %l60, !tbaa !65
  br label %bb21
bb21:
  %t106 = load i64, ptr %l60, !tbaa !65
  store i64 %t106, ptr %l11, !tbaa !65
  %t107 = load i32, ptr %l0, !range !{i32 0, i32 54}
  %t109 = trunc i64 34 to i32
  %t110 = icmp eq i32 %t107, %t109
  br i1 %t110, label %bb22, label %bb23
bb22:
  %t112 = load i64, ptr %l11, !tbaa !65
  %t114 = icmp eq i64 %t112, 1
  br i1 %t114, label %bb24, label %bb25
bb23:
  %t116 = load i64, ptr %l11, !tbaa !65
  %t118 = icmp eq i64 %t116, 1
  br i1 %t118, label %bb27, label %bb28
bb24:
  %t120 = load i64, ptr %l4, !tbaa !24
  %t123 = add i64 %t120, 1
  store i64 %t123, ptr %l4, !tbaa !24
  br label %bb26
bb25:
  br label %bb26
bb26:
  br label %bb30
bb27:
  %t125 = load i64, ptr %l10, !tbaa !24
  store i64 %t125, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t127 = load i64, ptr %l9, !tbaa !24
  %t130 = add i64 %t127, 1
  store i64 %t130, ptr %l9, !tbaa !24
  br label %bb15
bb32:
  %t132 = load i32, ptr %l0, !range !{i32 0, i32 54}
  %t134 = trunc i64 34 to i32
  %t135 = icmp eq i32 %t132, %t134
  br i1 %t135, label %bb33, label %bb34
bb33:
  %t137 = load i64, ptr %l4, !tbaa !24
  store i64 %t137, ptr %l89, !tbaa !24
  br label %bb35
bb34:
  %t139 = load i64, ptr %l2, !tbaa !24
  store i64 %t139, ptr %l89, !tbaa !24
  br label %bb35
bb35:
  %t141 = load i64, ptr %l89, !tbaa !24
  store i64 %t141, ptr %rv
  br label %ret
bb36:
  %t142 = load i64, ptr %l2, !tbaa !24
  %t144 = icmp eq i64 %t142, 64
  br i1 %t144, label %bb37, label %bb38
bb37:
  %t146 = sub i64 0, 1
  store i64 %t146, ptr %l94, !tbaa !65
  br label %bb39
bb38:
  %t148 = load i64, ptr %l2, !tbaa !24
  store i64 %t148, ptr %l97, !tbaa !65
  %t150 = load i64, ptr %l97, !tbaa !65
  %t151 = load i64, ptr %l97, !tbaa !65
  %t152 = shl i64 1, %t151
  %t154 = sub i64 %t152, 1
  store i64 %t154, ptr %l94, !tbaa !65
  br label %bb39
bb39:
  %t156 = load i64, ptr %l94, !tbaa !65
  store i64 %t156, ptr %l12, !tbaa !65
  %t157 = load i32, ptr %l0, !range !{i32 0, i32 54}
  %t159 = trunc i64 37 to i32
  %t160 = icmp eq i32 %t157, %t159
  br i1 %t160, label %bb40, label %bb41
bb40:
  store i64 0, ptr %l13, !tbaa !65
  store i64 0, ptr %l14, !tbaa !24
  %t162 = load i64, ptr %l2, !tbaa !24
  %t164 = sdiv i64 %t162, 8
  store i64 %t164, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t166 = load i64, ptr %l15, !tbaa !24
  %t167 = load i64, ptr %l14, !tbaa !24
  %t170 = icmp sgt i64 %t166, %t167
  br i1 %t170, label %bb42, label %bb43
bb41:
  br label %bb54
bb42:
  %t172 = load i64, ptr %l16, !tbaa !24
  %t174 = icmp sgt i64 %t172, 0
  br i1 %t174, label %bb44, label %bb45
bb43:
  store i64 0, ptr %l107, !tbaa !24
  br label %bb47
bb44:
  %t176 = load i64, ptr %l15, !tbaa !24
  %t177 = load i64, ptr %l14, !tbaa !24
  %t180 = sub i64 %t176, %t177
  %t181 = load i64, ptr %l16, !tbaa !24
  %t184 = add i64 %t180, %t181
  %t186 = sub i64 %t184, 1
  %t187 = load i64, ptr %l16, !tbaa !24
  %t190 = sdiv i64 %t186, %t187
  store i64 %t190, ptr %l110, !tbaa !24
  br label %bb46
bb45:
  store i64 0, ptr %l110, !tbaa !24
  br label %bb46
bb46:
  %t192 = load i64, ptr %l110, !tbaa !24
  store i64 %t192, ptr %l107, !tbaa !24
  br label %bb47
bb47:
  %t193 = load i64, ptr %l107, !tbaa !24
  store i64 %t193, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  %t194 = load i64, ptr %l17, !tbaa !24
  %t195 = sub i64 %t194, 1
  store i64 %t195, ptr %l119, !tbaa !24
  %t196 = load i64, ptr %l17, !tbaa !24
  %t197 = icmp slt i64 %t196, 2147483648
  %t198 = load i64, ptr %l18, !tbaa !24
  %t199 = icmp sge i64 %t198, 0
  %t202 = and i1 %t197, %t199
  store i1 %t202, ptr %l122, !tbaa !21
  br label %bb48
bb48:
  %t203 = load i64, ptr %l18, !tbaa !24
  %t204 = load i64, ptr %l17, !tbaa !24
  %t207 = icmp slt i64 %t203, %t204
  %t209 = xor i1 %t207, true
  br i1 %t209, label %bb49, label %bb50
bb49:
  br label %bb53
bb50:
  br label %bb51
bb51:
  %t211 = load i64, ptr %l14, !tbaa !24
  %t212 = load i64, ptr %l18, !tbaa !24
  %t213 = load i64, ptr %l16, !tbaa !24
  %t216 = mul i64 %t212, %t213
  %t219 = add i64 %t211, %t216
  store i64 %t219, ptr %l19, !tbaa !24
  %t221 = load i64, ptr %l13, !tbaa !65
  %t223 = load i64, ptr %l1, !tbaa !65
  %t224 = load i64, ptr %l19, !tbaa !24
  %t226 = mul i64 8, %t224
  store i64 %t226, ptr %l137, !tbaa !65
  %t229 = load i64, ptr %l137, !tbaa !65
  %t230 = load i64, ptr %l137, !tbaa !65
  %t231 = lshr i64 %t223, %t230
  %t233 = and i64 %t231, 255
  %t234 = load i64, ptr %l2, !tbaa !24
  %t236 = sub i64 %t234, 8
  %t237 = load i64, ptr %l19, !tbaa !24
  %t239 = mul i64 8, %t237
  %t242 = sub i64 %t236, %t239
  store i64 %t242, ptr %l145, !tbaa !65
  %t245 = load i64, ptr %l145, !tbaa !65
  %t246 = load i64, ptr %l145, !tbaa !65
  %t247 = shl i64 %t233, %t246
  %t250 = or i64 %t221, %t247
  store i64 %t250, ptr %l13, !tbaa !65
  br label %bb52
bb52:
  %t252 = load i64, ptr %l18, !tbaa !24
  %t255 = add i64 %t252, 1
  store i64 %t255, ptr %l18, !tbaa !24
  br label %bb48
bb53:
  %t257 = load i64, ptr %l13, !tbaa !65
  store i64 %t257, ptr %rv
  br label %ret
bb54:
  %t261 = load i64, ptr %l2, !tbaa !24
  %t264 = srem i64 %a3, %t261
  %t265 = load i64, ptr %l2, !tbaa !24
  %t268 = add i64 %t264, %t265
  %t269 = load i64, ptr %l2, !tbaa !24
  %t272 = srem i64 %t268, %t269
  store i64 %t272, ptr %l20, !tbaa !65
  %t275 = load i32, ptr %l0, !range !{i32 0, i32 54}
  %t277 = trunc i64 36 to i32
  %t278 = icmp eq i32 %t275, %t277
  br i1 %t278, label %bb55, label %bb56
bb55:
  %t280 = load i64, ptr %l20, !tbaa !65
  %t281 = load i64, ptr %l2, !tbaa !24
  %t286 = sub i64 %t281, %t280
  %t287 = load i64, ptr %l2, !tbaa !24
  %t291 = urem i64 %t286, %t287
  store i64 %t291, ptr %l20, !tbaa !65
  br label %bb57
bb56:
  br label %bb57
bb57:
  %t293 = load i64, ptr %l20, !tbaa !65
  %t295 = icmp eq i64 %t293, 0
  br i1 %t295, label %bb58, label %bb59
bb58:
  %t297 = load i64, ptr %l1, !tbaa !65
  store i64 %t297, ptr %rv
  br label %ret
bb59:
  br label %bb60
bb60:
  %t300 = load i64, ptr %l1, !tbaa !65
  %t301 = load i64, ptr %l20, !tbaa !65
  store i64 %t301, ptr %l176, !tbaa !65
  %t303 = load i64, ptr %l176, !tbaa !65
  %t304 = load i64, ptr %l176, !tbaa !65
  %t305 = shl i64 %t300, %t304
  %t306 = load i64, ptr %l1, !tbaa !65
  %t307 = load i64, ptr %l2, !tbaa !24
  %t309 = load i64, ptr %l20, !tbaa !65
  %t312 = sub i64 %t307, %t309
  store i64 %t312, ptr %l182, !tbaa !65
  %t314 = load i64, ptr %l182, !tbaa !65
  %t315 = load i64, ptr %l182, !tbaa !65
  %t316 = lshr i64 %t306, %t315
  %t319 = or i64 %t305, %t316
  %t320 = load i64, ptr %l12, !tbaa !65
  %t323 = and i64 %t319, %t320
  store i64 %t323, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eGlobal(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2, i1 %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i1
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca %"compiler/eval:Ptr"
  %l20 = alloca i1
  %l22 = alloca { i64, ptr }
  %l41 = alloca i64
  %l43 = alloca ptr
  %l46 = alloca %"compiler/eval:gkey"
  %l47 = alloca i64
  %l48 = alloca i32
  %l56 = alloca %"compiler/eval:global"
  %l66 = alloca %"compiler/eval:global"
  %l68 = alloca i1
  %l70 = alloca i1
  %l79 = alloca i1
  %l82 = alloca i1
  %l90 = alloca %"compiler/eval:global"
  %l106 = alloca i1
  %l110 = alloca %"compiler/eval:global"
  %l116 = alloca ptr
  %l119 = alloca i64
  %l123 = alloca %"compiler/eval:Ptr"
  %l124 = alloca ptr
  %l125 = alloca %"compiler/eval:Ptr"
  %l129 = alloca %"compiler/eval:global"
  %l131 = alloca %"compiler/eval:Ptr"
  %l134 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [5 x i64] }
  %t5 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 23
  store i1 false, ptr %t3, !tbaa !21
  %t4 = load ptr, ptr %l0, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t5
  %t6 = getelementptr { i64, [5 x i64] }, ptr %t5, i32 0, i32 0
  store i64 0, ptr %t6
  %t7 = load { i64, [5 x i64] }, ptr %t5
  %t10 = getelementptr %"compiler/eval:Machine", ptr %t4, i32 0, i32 21
  store { i64, [5 x i64] } %t7, ptr %t10
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/eval:Machine", ptr %t11, i32 0, i32 15
  store i64 0, ptr %t13, !tbaa !24
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/eval:Machine", ptr %t14, i32 0, i32 19
  %t17 = getelementptr %"compiler/eval:Ptr", ptr %t16, i32 0, i32 0
  %t18 = load i64, ptr %t17, !tbaa !24
  %t20 = icmp ne i64 %t18, 0
  br i1 %t20, label %bb1, label %bb2
bb1:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/eval:Machine", ptr %t22, i32 0, i32 50
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  store { i64, ptr } %t25, ptr %l22, !tbaa !27
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/eval:Machine", ptr %t26, i32 0, i32 19
  %t29 = getelementptr %"compiler/eval:Ptr", ptr %t28, i32 0, i32 0
  %t30 = load i64, ptr %t29, !tbaa !24
  %t31 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t34 = and i64 %t30, %t31
  %t36 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr %"compiler/eval:alloc", ptr %t37, i64 %t34
  %t39 = getelementptr %"compiler/eval:alloc", ptr %t38, i32 0, i32 4
  %t40 = load i64, ptr %t39, !tbaa !24
  %t41 = load i64, ptr @G_2ecompiler_2feval_2eaFree, !tbaa !24
  %t44 = icmp ne i64 %t40, %t41
  store i1 %t44, ptr %l20, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb3
bb3:
  %t46 = load i1, ptr %l20, !tbaa !21
  br i1 %t46, label %bb4, label %bb5
bb4:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/eval:Machine", ptr %t48, i32 0, i32 19
  %t51 = getelementptr %"compiler/eval:Ptr", ptr %t50, i32 0, i32 0
  %t52 = load i64, ptr %t51, !tbaa !24
  %t53 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t56 = and i64 %t52, %t53
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erelease(ptr %v0, ptr %t47, i64 %t56)
  br label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb7
bb7:
  %t59 = load %"compiler/eval:Ptr", ptr @G_2ecompiler_2feval_2eNullPtr
  %t61 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/eval:Machine", ptr %t63, i32 0, i32 19
  store %"compiler/eval:Ptr" %t59, ptr %t67
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/eval:Machine", ptr %t68, i32 0, i32 20
  store i32 %t61, ptr %t72, !tbaa !23
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/eval:Machine", ptr %t73, i32 0, i32 44
  store ptr %t75, ptr %l43, !tbaa !29
  %t80 = call %"compiler/eval:gkey" @compiler_2feval_3agkey_2ector(ptr %s0, i64 %a1, i32 %a2)
  store %"compiler/eval:gkey" %t80, ptr %l46
  br label %bb8
bb8:
  %t81 = load ptr, ptr %l43, !tbaa !29
  %t82 = load %"compiler/eval:gkey", ptr %l46
  %t83 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2feval_3agkey_2c_20I64_3e_2eG_H841bd46d30f67641fdfac3080f15aea1(ptr %v0, ptr %t81, %"compiler/eval:gkey" %t82)
  %t84 = extractvalue { i32, i64 } %t83, 1
  %t85 = extractvalue { i32, i64 } %t83, 0
  store i32 %t85, ptr %l48
  %t86 = icmp ne i32 %t85, 0
  br i1 %t86, label %bb10, label %ok.87, !prof !99
ok.87:
  store i64 %t84, ptr %l47
  br label %bb9
bb9:
  %t88 = load i64, ptr %l47, !tbaa !24
  store i64 %t88, ptr %l41, !tbaa !24
  br label %bb13
bb10:
  br label %bb11
bb11:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNoBody, !tbaa !27
  %t91 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t91, ptr %t89, { i64, ptr } %t90)
  br label %bb12
bb12:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/eval:Machine", ptr %t94, i32 0, i32 21
  %t97 = load { i64, [5 x i64] }, ptr %t96
  call void @__olang_scope_close(ptr %s0)
  store { i64, [5 x i64] } %t97, ptr %rv
  br label %ret
bb13:
  %t99 = load i64, ptr %l41, !tbaa !24
  store i64 %t99, ptr %l7, !tbaa !24
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/eval:Machine", ptr %t100, i32 0, i32 43
  %t103 = load i64, ptr %l7, !tbaa !24
  %t106 = call %"compiler/eval:global" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2eAt_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %t102, i64 %t103)
  store %"compiler/eval:global" %t106, ptr %l56
  br label %bb14
bb14:
  %t107 = getelementptr %"compiler/eval:global", ptr %l56, i32 0, i32 0
  %t108 = load i64, ptr %t107, !tbaa !24
  %t110 = trunc i64 %t108 to i32
  store i32 %t110, ptr %l8, !tbaa !23
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/eval:Machine", ptr %t113, i32 0, i32 1
  %t116 = load i32, ptr %t115, !range !{i32 0, i32 2}
  %t118 = trunc i64 0 to i32
  %t119 = icmp eq i32 %t116, %t118
  br i1 %t119, label %bb15, label %bb16
bb15:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/eval:Machine", ptr %t121, i32 0, i32 43
  %t124 = load i64, ptr %l7, !tbaa !24
  %t127 = call %"compiler/eval:global" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2eAt_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %t123, i64 %t124)
  store %"compiler/eval:global" %t127, ptr %l66
  br label %bb17
bb16:
  br label %bb36
bb17:
  %t128 = getelementptr %"compiler/eval:global", ptr %l66, i32 0, i32 1
  %t129 = load i1, ptr %t128, !tbaa !21
  br i1 %t129, label %bb18, label %bb19
bb18:
  %t131 = load i1, ptr %l3, !tbaa !21
  br i1 %t131, label %bb20, label %bb21
bb19:
  store i1 false, ptr %l68, !tbaa !21
  br label %bb23
bb20:
  store i1 %a4, ptr %l70, !tbaa !21
  br label %bb22
bb21:
  store i1 false, ptr %l70, !tbaa !21
  br label %bb22
bb22:
  %t135 = load i1, ptr %l70, !tbaa !21
  %t136 = xor i1 %t135, true
  store i1 %t136, ptr %l68, !tbaa !21
  br label %bb23
bb23:
  %t138 = load i1, ptr %l68, !tbaa !21
  br i1 %t138, label %bb24, label %bb25
bb24:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyMutableGlobal, !tbaa !27
  %t141 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t141, ptr %t139, { i64, ptr } %t140)
  br label %bb26
bb25:
  br label %bb27
bb26:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t146 = getelementptr %"compiler/eval:Machine", ptr %t144, i32 0, i32 21
  %t147 = load { i64, [5 x i64] }, ptr %t146
  call void @__olang_scope_close(ptr %s0)
  store { i64, [5 x i64] } %t147, ptr %rv
  br label %ret
bb27:
  %t149 = load i1, ptr %l3, !tbaa !21
  %t151 = xor i1 %t149, true
  br i1 %t151, label %bb28, label %bb29
bb28:
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load i32, ptr %l8, !tbaa !23
  %t157 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2ereachesWritable(ptr %v0, ptr %t153, i32 %t154)
  store i1 %t157, ptr %l82
  br label %bb30
bb29:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb31
bb30:
  %t158 = load i1, ptr %l82, !tbaa !21
  store i1 %t158, ptr %l79, !tbaa !21
  br label %bb31
bb31:
  %t159 = load i1, ptr %l79, !tbaa !21
  br i1 %t159, label %bb32, label %bb33
bb32:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t161 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyChangeable, !tbaa !27
  %t162 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t162, ptr %t160, { i64, ptr } %t161)
  br label %bb34
bb33:
  br label %bb35
bb34:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/eval:Machine", ptr %t165, i32 0, i32 21
  %t168 = load { i64, [5 x i64] }, ptr %t167
  call void @__olang_scope_close(ptr %s0)
  store { i64, [5 x i64] } %t168, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/eval:Machine", ptr %t170, i32 0, i32 43
  %t173 = load i64, ptr %l7, !tbaa !24
  %t176 = call %"compiler/eval:global" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2eAt_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %t172, i64 %t173)
  store %"compiler/eval:global" %t176, ptr %l90
  br label %bb37
bb37:
  %t177 = getelementptr %"compiler/eval:global", ptr %l90, i32 0, i32 4
  %t178 = load i64, ptr %t177, !tbaa !24
  %t180 = icmp ne i64 %t178, 2
  br i1 %t180, label %bb38, label %bb39
bb38:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr %"compiler/eval:Machine", ptr %t182, i32 0, i32 60
  %t185 = load i64, ptr %t184, !tbaa !24
  store i64 %t185, ptr %l9, !tbaa !24
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t188 = load i64, ptr %l7, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2estartGlobal(ptr %v0, ptr %t187, i64 %t188)
  br label %bb40
bb39:
  br label %bb46
bb40:
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t192 = load i64, ptr %l9, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eloop(ptr %v0, ptr %t191, i64 %t192)
  br label %bb41
bb41:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t196 = load i64, ptr %l9, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eunwind(ptr %v0, ptr %t195, i64 %t196)
  br label %bb42
bb42:
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t201 = getelementptr %"compiler/eval:Machine", ptr %t199, i32 0, i32 23
  %t202 = load i1, ptr %t201, !tbaa !21
  br i1 %t202, label %bb43, label %bb44
bb43:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t206 = getelementptr %"compiler/eval:Machine", ptr %t204, i32 0, i32 21
  %t207 = load { i64, [5 x i64] }, ptr %t206
  call void @__olang_scope_close(ptr %s0)
  store { i64, [5 x i64] } %t207, ptr %rv
  br label %ret
bb44:
  br label %bb45
bb45:
  br label %bb46
bb46:
  %t209 = load i1, ptr %l3, !tbaa !21
  br i1 %t209, label %bb47, label %bb48
bb47:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr %"compiler/eval:Machine", ptr %t211, i32 0, i32 43
  %t214 = load i64, ptr %l7, !tbaa !24
  %t217 = call %"compiler/eval:global" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2eAt_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %t213, i64 %t214)
  store %"compiler/eval:global" %t217, ptr %l110
  br label %bb49
bb48:
  store i1 false, ptr %l106, !tbaa !21
  br label %bb50
bb49:
  %t218 = getelementptr %"compiler/eval:global", ptr %l110, i32 0, i32 7
  %t219 = load i1, ptr %t218, !tbaa !21
  store i1 %t219, ptr %l106, !tbaa !21
  br label %bb50
bb50:
  %t221 = load i1, ptr %l106, !tbaa !21
  br i1 %t221, label %bb51, label %bb52
bb51:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t223 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyDestructor, !tbaa !27
  %t224 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t224, ptr %t222, { i64, ptr } %t223)
  br label %bb53
bb52:
  br label %bb54
bb53:
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t229 = getelementptr %"compiler/eval:Machine", ptr %t227, i32 0, i32 21
  %t230 = load { i64, [5 x i64] }, ptr %t229
  call void @__olang_scope_close(ptr %s0)
  store { i64, [5 x i64] } %t230, ptr %rv
  br label %ret
bb54:
  %t232 = load ptr, ptr %l0, !tbaa !29
  store ptr %t232, ptr %l116, !tbaa !29
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t234 = load i32, ptr %l8, !tbaa !23
  %t237 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t233, i32 %t234)
  store i64 %t237, ptr %l119
  br label %bb55
bb55:
  %t238 = load i64, ptr @G_2ecompiler_2feval_2eaValue, !tbaa !24
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t241 = getelementptr %"compiler/eval:Machine", ptr %t239, i32 0, i32 71
  %t242 = load i64, ptr %t241, !tbaa !24
  %t243 = load ptr, ptr %l116, !tbaa !29
  %t244 = load i64, ptr %l119, !tbaa !24
  %t247 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eallocate(ptr %v0, ptr %t243, i64 %t244, i64 %t238, i64 %t242)
  store %"compiler/eval:Ptr" %t247, ptr %l123
  br label %bb56
bb56:
  %t248 = load %"compiler/eval:Ptr", ptr %l123
  store %"compiler/eval:Ptr" %t248, ptr %l10
  %t249 = load ptr, ptr %l0, !tbaa !29
  store ptr %t249, ptr %l124, !tbaa !29
  %t250 = load %"compiler/eval:Ptr", ptr %l10
  store %"compiler/eval:Ptr" %t250, ptr %l125
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t253 = getelementptr %"compiler/eval:Machine", ptr %t251, i32 0, i32 43
  %t254 = load i64, ptr %l7, !tbaa !24
  %t257 = call %"compiler/eval:global" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2eAt_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %t253, i64 %t254)
  store %"compiler/eval:global" %t257, ptr %l129
  br label %bb57
bb57:
  %t258 = getelementptr %"compiler/eval:global", ptr %l129, i32 0, i32 3
  %t259 = load i64, ptr %t258, !tbaa !24
  %t261 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s0, i64 %t259, i64 0)
  store %"compiler/eval:Ptr" %t261, ptr %l131
  br label %bb58
bb58:
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t263 = load i32, ptr %l8, !tbaa !23
  %t266 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t262, i32 %t263)
  store i64 %t266, ptr %l134
  br label %bb59
bb59:
  %t267 = load ptr, ptr %l124, !tbaa !29
  %t268 = load %"compiler/eval:Ptr", ptr %l125
  %t269 = load %"compiler/eval:Ptr", ptr %l131
  %t270 = load i64, ptr %l134, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ecopy(ptr %v0, ptr %t267, %"compiler/eval:Ptr" %t268, %"compiler/eval:Ptr" %t269, i64 %t270)
  br label %bb60
bb60:
  %t271 = load %"compiler/eval:Ptr", ptr %l10
  %t273 = load i32, ptr %l8, !tbaa !23
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t279 = getelementptr %"compiler/eval:Machine", ptr %t275, i32 0, i32 19
  store %"compiler/eval:Ptr" %t271, ptr %t279
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t284 = getelementptr %"compiler/eval:Machine", ptr %t280, i32 0, i32 20
  store i32 %t273, ptr %t284, !tbaa !23
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t287 = getelementptr %"compiler/eval:Machine", ptr %t285, i32 0, i32 21
  %t288 = load { i64, [5 x i64] }, ptr %t287
  call void @__olang_scope_close(ptr %s0)
  store { i64, [5 x i64] } %t288, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [5 x i64] }, ptr %rv
  ret { i64, [5 x i64] } %rr
}

define dso_local { i32, %"compiler/eval:Image" } @compiler_2feval_2ecompiler_2feval_3aMachine_2eImage(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l4 = alloca i64
  %lp5 = alloca ptr
  %l6 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"compiler/eval:alloc"
  %l12 = alloca %"compiler/eval:Blob"
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i32
  %l36 = alloca ptr
  %l37 = alloca i64
  %l38 = alloca i64
  %l40 = alloca i1
  %l46 = alloca { i64, [5 x i64] }
  %l51 = alloca i64
  %l53 = alloca ptr
  %l56 = alloca %"compiler/eval:gkey"
  %l57 = alloca i64
  %l58 = alloca i32
  %l60 = alloca %"compiler/eval:Image"
  %l61 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l62 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l66 = alloca %"compiler/eval:global"
  %l71 = alloca { i64, ptr }
  %l80 = alloca i64
  %l82 = alloca i64
  %l87 = alloca i64
  %l89 = alloca { i64, ptr }
  %l92 = alloca %"compiler/eval:Blob"
  %l94 = alloca i1
  %l100 = alloca i64
  %l103 = alloca i64
  %l107 = alloca ptr
  %l111 = alloca %"compiler/eval:global"
  %l115 = alloca i64
  %l124 = alloca i64
  %l127 = alloca i64
  %l145 = alloca ptr
  %l150 = alloca i64
  %l163 = alloca i64
  %l166 = alloca i64
  %l201 = alloca i64
  %l204 = alloca i64
  %l223 = alloca { i64, ptr }
  %l238 = alloca i1
  %l240 = alloca { i64, ptr }
  %l245 = alloca i1
  %l247 = alloca { i64, ptr }
  %l251 = alloca i64
  %l258 = alloca i1
  %l260 = alloca { i64, ptr }
  %l265 = alloca i1
  %l267 = alloca { i64, ptr }
  %l274 = alloca { i64, ptr }
  %l279 = alloca i1
  %l281 = alloca { i64, ptr }
  %l291 = alloca i1
  %l293 = alloca { i64, ptr }
  %l297 = alloca i1
  %l299 = alloca { i64, ptr }
  %l310 = alloca ptr
  %l316 = alloca i64
  %l317 = alloca i64
  %l320 = alloca i64
  %l321 = alloca i32
  %l325 = alloca i64
  %l337 = alloca ptr
  %l343 = alloca i64
  %l347 = alloca ptr
  %l348 = alloca %"compiler/eval:Blob"
  %l350 = alloca %"compiler/eval:Blob"
  %l359 = alloca %"compiler/eval:global"
  %l366 = alloca i1
  %l367 = alloca i1
  %l371 = alloca i64
  %l376 = alloca %"compiler/eval:Blob"
  %l378 = alloca %"compiler/eval:Blob"
  %l380 = alloca i64
  %l382 = alloca i64
  %l387 = alloca i64
  %l390 = alloca i1
  %l393 = alloca %"compiler/eval:Blob"
  %l395 = alloca i64
  %l400 = alloca ptr
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %rv = alloca { i32, %"compiler/eval:Image" }
  %t107 = alloca %"compiler/eval:Blob", align 8
  %t656 = alloca %"compiler/eval:Blob", align 8
  %t659 = alloca %"compiler/eval:Blob", align 8
  %t710 = alloca %"compiler/eval:Blob", align 8
  %t712 = alloca %"compiler/eval:Blob", align 8
  %t739 = alloca %"compiler/eval:Blob", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t3 = load i32, ptr %l2, !tbaa !23
  %t9 = call { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eGlobal(ptr %v0, ptr %v0, ptr %t1, i64 %t2, i32 %t3, i1 true, i1 %a3)
  store { i64, [5 x i64] } %t9, ptr %l46
  br label %bb1
bb1:
  %t10 = load { i64, [5 x i64] }, ptr %l46
  %t12 = extractvalue { i64, [5 x i64] } %t10, 0
  %t13 = icmp eq i64 %t12, 0
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t18 = insertvalue { i32, %"compiler/eval:Image" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/eval:Image" } %t18, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/eval:Machine", ptr %t19, i32 0, i32 44
  store ptr %t21, ptr %l53, !tbaa !29
  %t22 = load i64, ptr %l1, !tbaa !24
  %t23 = load i32, ptr %l2, !tbaa !23
  %t26 = call %"compiler/eval:gkey" @compiler_2feval_3agkey_2ector(ptr %s0, i64 %t22, i32 %t23)
  store %"compiler/eval:gkey" %t26, ptr %l56
  br label %bb5
bb5:
  %t27 = load ptr, ptr %l53, !tbaa !29
  %t28 = load %"compiler/eval:gkey", ptr %l56
  %t29 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2feval_3agkey_2c_20I64_3e_2eG_H841bd46d30f67641fdfac3080f15aea1(ptr %v0, ptr %t27, %"compiler/eval:gkey" %t28)
  %t30 = extractvalue { i32, i64 } %t29, 1
  %t31 = extractvalue { i32, i64 } %t29, 0
  store i32 %t31, ptr %l58
  %t32 = icmp ne i32 %t31, 0
  br i1 %t32, label %bb7, label %ok.33, !prof !99
ok.33:
  store i64 %t30, ptr %l57
  br label %bb6
bb6:
  %t34 = load i64, ptr %l57, !tbaa !24
  store i64 %t34, ptr %l51, !tbaa !24
  br label %bb9
bb7:
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t36 = insertvalue { i32, %"compiler/eval:Image" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/eval:Image" } %t36, ptr %rv
  br label %ret
bb9:
  %t37 = load i64, ptr %l51, !tbaa !24
  store i64 %t37, ptr %l4, !tbaa !24
  %t38 = call %"compiler/eval:Image" @compiler_2feval_3aImage_2ector(ptr %v1)
  store %"compiler/eval:Image" %t38, ptr %l60
  br label %bb10
bb10:
  %t39 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 72, i64 8)
  store ptr %t39, ptr %lp5
  %t40 = load %"compiler/eval:Image", ptr %l60
  %t41 = load ptr, ptr %lp5
  store %"compiler/eval:Image" %t40, ptr %t41
  %t42 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t42, ptr %l61
  br label %bb11
bb11:
  %t43 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l61
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t43, ptr %l6
  %t44 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t44, ptr %l62
  br label %bb12
bb12:
  %t45 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l62
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t45, ptr %l7
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/eval:Machine", ptr %t46, i32 0, i32 43
  %t49 = load i64, ptr %l4, !tbaa !24
  %t52 = call %"compiler/eval:global" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2eAt_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %t48, i64 %t49)
  store %"compiler/eval:global" %t52, ptr %l66
  br label %bb13
bb13:
  %t53 = getelementptr %"compiler/eval:global", ptr %l66, i32 0, i32 3
  %t54 = load i64, ptr %t53, !tbaa !24
  %t55 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t58 = and i64 %t54, %t55
  store i64 %t58, ptr %l8, !tbaa !24
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/eval:Machine", ptr %t60, i32 0, i32 50
  %t63 = load { i64, ptr }, ptr %t62, !tbaa !27
  store { i64, ptr } %t63, ptr %l71, !tbaa !27
  %t64 = load i64, ptr %l8, !tbaa !24
  %t66 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !27
  %t68 = getelementptr %"compiler/eval:alloc", ptr %t67, i64 %t64
  %t69 = getelementptr %"compiler/eval:alloc", ptr %t68, i32 0, i32 1
  %t70 = load i64, ptr %t69, !tbaa !24
  %t72 = icmp eq i64 %t70, 0
  br i1 %t72, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s0)
  %t75 = insertvalue { i32, %"compiler/eval:Image" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/eval:Image" } %t75, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t76 = load i64, ptr %l8, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %s0, ptr %l6, i64 %t76, i64 0)
  br label %bb17
bb17:
  %t79 = load i64, ptr %l8, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l7, i64 %t79)
  br label %bb18
bb18:
  store i64 0, ptr %l9, !tbaa !24
  br label %bb19
bb19:
  store %olang.scope zeroinitializer, ptr %s4
  %t82 = load i64, ptr %l9, !tbaa !24
  store i64 %t82, ptr %l80, !tbaa !24
  %t84 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l7)
  store i64 %t84, ptr %l82
  br label %bb20
bb20:
  %t85 = load i64, ptr %l80, !tbaa !24
  %t86 = load i64, ptr %l82, !tbaa !24
  %t87 = icmp slt i64 %t85, %t86
  %t89 = xor i1 %t87, true
  br i1 %t89, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s4)
  br label %bb149
bb22:
  br label %bb23
bb23:
  %t91 = load i64, ptr %l9, !tbaa !24
  %t94 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l7, i64 %t91)
  store i64 %t94, ptr %l87
  br label %bb24
bb24:
  %t95 = load i64, ptr %l87, !tbaa !24
  store i64 %t95, ptr %l10, !tbaa !24
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/eval:Machine", ptr %t96, i32 0, i32 50
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !27
  store { i64, ptr } %t99, ptr %l89, !tbaa !27
  %t100 = load i64, ptr %l10, !tbaa !24
  %t102 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = getelementptr %"compiler/eval:alloc", ptr %t103, i64 %t100
  %t105 = load %"compiler/eval:alloc", ptr %t104
  store %"compiler/eval:alloc" %t105, ptr %l11
  call void @compiler_2feval_3aBlob_2ector(ptr %t107, ptr %s4)
  call void @llvm.memmove.p0.p0.i64(ptr %l92, ptr %t107, i64 272, i1 false)
  br label %bb25
bb25:
  call void @llvm.memmove.p0.p0.i64(ptr %l12, ptr %l92, i64 272, i1 false)
  %t108 = getelementptr %"compiler/eval:alloc", ptr %l11, i32 0, i32 13
  %t109 = load i1, ptr %t108, !tbaa !21
  br i1 %t109, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l94, !tbaa !21
  br label %bb28
bb27:
  %t111 = getelementptr %"compiler/eval:alloc", ptr %l11, i32 0, i32 4
  %t112 = load i64, ptr %t111, !tbaa !24
  %t113 = load i64, ptr @G_2ecompiler_2feval_2eaData, !tbaa !24
  %t116 = icmp eq i64 %t112, %t113
  store i1 %t116, ptr %l94, !tbaa !21
  br label %bb28
bb28:
  %t118 = load i1, ptr %l94, !tbaa !21
  %t119 = getelementptr %"compiler/eval:Blob", ptr %l12, i32 0, i32 2
  store i1 %t118, ptr %t119, !tbaa !21
  %t120 = getelementptr %"compiler/eval:alloc", ptr %l11, i32 0, i32 1
  %t121 = load i64, ptr %t120, !tbaa !24
  %t123 = icmp sge i64 %t121, 64
  br i1 %t123, label %bb29, label %bb30
bb29:
  store i64 64, ptr %l100, !tbaa !24
  br label %bb34
bb30:
  %t125 = getelementptr %"compiler/eval:alloc", ptr %l11, i32 0, i32 1
  %t126 = load i64, ptr %t125, !tbaa !24
  %t128 = icmp sge i64 %t126, 32
  br i1 %t128, label %bb31, label %bb32
bb31:
  store i64 32, ptr %l103, !tbaa !24
  br label %bb33
bb32:
  store i64 8, ptr %l103, !tbaa !24
  br label %bb33
bb33:
  %t130 = load i64, ptr %l103, !tbaa !24
  store i64 %t130, ptr %l100, !tbaa !24
  br label %bb34
bb34:
  %t131 = load i64, ptr %l100, !tbaa !24
  %t132 = getelementptr %"compiler/eval:Blob", ptr %l12, i32 0, i32 1
  store i64 %t131, ptr %t132, !tbaa !24
  %t133 = load i64, ptr %l9, !tbaa !24
  %t135 = icmp eq i64 %t133, 0
  br i1 %t135, label %bb35, label %bb36
bb35:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"compiler/eval:Machine", ptr %t137, i32 0, i32 0
  %t140 = load ptr, ptr %t139, !tbaa !29
  store ptr %t140, ptr %l107, !tbaa !29
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/eval:Machine", ptr %t141, i32 0, i32 43
  %t144 = load i64, ptr %l4, !tbaa !24
  %t147 = call %"compiler/eval:global" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2eAt_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %t143, i64 %t144)
  store %"compiler/eval:global" %t147, ptr %l111
  br label %bb37
bb36:
  br label %bb42
bb37:
  %t148 = getelementptr %"compiler/eval:global", ptr %l111, i32 0, i32 0
  %t149 = load i64, ptr %t148, !tbaa !24
  %t151 = trunc i64 %t149 to i32
  %t153 = load ptr, ptr %l107, !tbaa !29
  %t155 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAlign(ptr %v0, ptr %t153, i32 %t151)
  store i64 %t155, ptr %l115
  br label %bb38
bb38:
  %t156 = load i64, ptr %l115, !tbaa !24
  store i64 %t156, ptr %l13, !tbaa !24
  %t157 = load i64, ptr %l13, !tbaa !24
  %t158 = getelementptr %"compiler/eval:Blob", ptr %l12, i32 0, i32 1
  %t159 = load i64, ptr %t158, !tbaa !24
  %t162 = icmp sgt i64 %t157, %t159
  br i1 %t162, label %bb39, label %bb40
bb39:
  %t164 = load i64, ptr %l13, !tbaa !24
  %t166 = getelementptr %"compiler/eval:Blob", ptr %l12, i32 0, i32 1
  store i64 %t164, ptr %t166, !tbaa !24
  br label %bb41
bb40:
  br label %bb41
bb41:
  br label %bb42
bb42:
  store i64 0, ptr %l14, !tbaa !24
  %t167 = getelementptr %"compiler/eval:alloc", ptr %l11, i32 0, i32 1
  %t168 = load i64, ptr %t167, !tbaa !24
  store i64 %t168, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t170 = load i64, ptr %l15, !tbaa !24
  %t171 = load i64, ptr %l14, !tbaa !24
  %t174 = icmp sgt i64 %t170, %t171
  br i1 %t174, label %bb43, label %bb44
bb43:
  %t176 = load i64, ptr %l16, !tbaa !24
  %t178 = icmp sgt i64 %t176, 0
  br i1 %t178, label %bb45, label %bb46
bb44:
  store i64 0, ptr %l124, !tbaa !24
  br label %bb48
bb45:
  %t180 = load i64, ptr %l15, !tbaa !24
  %t181 = load i64, ptr %l14, !tbaa !24
  %t184 = sub i64 %t180, %t181
  %t185 = load i64, ptr %l16, !tbaa !24
  %t188 = add i64 %t184, %t185
  %t190 = sub i64 %t188, 1
  %t191 = load i64, ptr %l16, !tbaa !24
  %t194 = sdiv i64 %t190, %t191
  store i64 %t194, ptr %l127, !tbaa !24
  br label %bb47
bb46:
  store i64 0, ptr %l127, !tbaa !24
  br label %bb47
bb47:
  %t196 = load i64, ptr %l127, !tbaa !24
  store i64 %t196, ptr %l124, !tbaa !24
  br label %bb48
bb48:
  %t197 = load i64, ptr %l124, !tbaa !24
  store i64 %t197, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb49
bb49:
  %t198 = load i64, ptr %l18, !tbaa !24
  %t199 = load i64, ptr %l17, !tbaa !24
  %t202 = icmp slt i64 %t198, %t199
  %t204 = xor i1 %t202, true
  br i1 %t204, label %bb50, label %bb51
bb50:
  br label %bb56
bb51:
  br label %bb52
bb52:
  %t206 = load i64, ptr %l14, !tbaa !24
  %t207 = load i64, ptr %l18, !tbaa !24
  %t208 = load i64, ptr %l16, !tbaa !24
  %t211 = mul i64 %t207, %t208
  %t214 = add i64 %t206, %t211
  %t216 = getelementptr %"compiler/eval:Blob", ptr %l12, i32 0, i32 0
  store ptr %t216, ptr %l145, !tbaa !29
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t218 = getelementptr %"compiler/eval:alloc", ptr %l11, i32 0, i32 0
  %t219 = load i64, ptr %t218, !tbaa !24
  %t223 = add i64 %t219, %t214
  %t226 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erdRaw(ptr %v0, ptr %t217, i64 %t223, i64 1)
  store i64 %t226, ptr %l150
  br label %bb53
bb53:
  %t227 = load i64, ptr %l150, !tbaa !24
  %t228 = trunc i64 %t227 to i8
  %t229 = load ptr, ptr %l145, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2ePush_3cU8_3e(ptr %s4, ptr %t229, i8 %t228)
  br label %bb54
bb54:
  br label %bb55
bb55:
  %t231 = load i64, ptr %l18, !tbaa !24
  %t234 = add i64 %t231, 1
  store i64 %t234, ptr %l18, !tbaa !24
  br label %bb49
bb56:
  %t236 = getelementptr %"compiler/eval:alloc", ptr %l11, i32 0, i32 10
  %t237 = load i64, ptr %t236, !tbaa !24
  %t239 = icmp sgt i64 %t237, 0
  br i1 %t239, label %bb57, label %bb58
bb57:
  %t241 = getelementptr %"compiler/eval:alloc", ptr %l11, i32 0, i32 10
  %t242 = load i64, ptr %t241, !tbaa !24
  %t244 = sub i64 %t242, 8
  store i64 %t244, ptr %l20, !tbaa !24
  %t246 = getelementptr %"compiler/eval:alloc", ptr %l11, i32 0, i32 10
  %t247 = load i64, ptr %t246, !tbaa !24
  store i64 %t247, ptr %l21, !tbaa !24
  store i64 1, ptr %l22, !tbaa !24
  %t249 = load i64, ptr %l21, !tbaa !24
  %t250 = load i64, ptr %l20, !tbaa !24
  %t253 = icmp sgt i64 %t249, %t250
  br i1 %t253, label %bb59, label %bb60
bb58:
  br label %bb76
bb59:
  %t255 = load i64, ptr %l22, !tbaa !24
  %t257 = icmp sgt i64 %t255, 0
  br i1 %t257, label %bb61, label %bb62
bb60:
  store i64 0, ptr %l163, !tbaa !24
  br label %bb64
bb61:
  %t259 = load i64, ptr %l21, !tbaa !24
  %t260 = load i64, ptr %l20, !tbaa !24
  %t263 = sub i64 %t259, %t260
  %t264 = load i64, ptr %l22, !tbaa !24
  %t267 = add i64 %t263, %t264
  %t269 = sub i64 %t267, 1
  %t270 = load i64, ptr %l22, !tbaa !24
  %t273 = sdiv i64 %t269, %t270
  store i64 %t273, ptr %l166, !tbaa !24
  br label %bb63
bb62:
  store i64 0, ptr %l166, !tbaa !24
  br label %bb63
bb63:
  %t275 = load i64, ptr %l166, !tbaa !24
  store i64 %t275, ptr %l163, !tbaa !24
  br label %bb64
bb64:
  %t276 = load i64, ptr %l163, !tbaa !24
  store i64 %t276, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb65
bb65:
  %t277 = load i64, ptr %l24, !tbaa !24
  %t278 = load i64, ptr %l23, !tbaa !24
  %t281 = icmp slt i64 %t277, %t278
  %t283 = xor i1 %t281, true
  br i1 %t283, label %bb66, label %bb67
bb66:
  br label %bb71
bb67:
  br label %bb68
bb68:
  %t285 = load i64, ptr %l20, !tbaa !24
  %t286 = load i64, ptr %l24, !tbaa !24
  %t287 = load i64, ptr %l22, !tbaa !24
  %t290 = mul i64 %t286, %t287
  %t293 = add i64 %t285, %t290
  %t295 = getelementptr %"compiler/eval:Blob", ptr %l12, i32 0, i32 0
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eSetAt_3cU8_3e(ptr %s4, ptr %t295, i64 %t293, i8 0)
  br label %bb69
bb69:
  br label %bb70
bb70:
  %t299 = load i64, ptr %l24, !tbaa !24
  %t302 = add i64 %t299, 1
  store i64 %t302, ptr %l24, !tbaa !24
  br label %bb65
bb71:
  %t304 = getelementptr %"compiler/eval:Blob", ptr %l12, i32 0, i32 0
  %t305 = getelementptr %"compiler/eval:alloc", ptr %l11, i32 0, i32 10
  %t306 = load i64, ptr %t305, !tbaa !24
  %t308 = sub i64 %t306, 6
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eSetAt_3cU8_3e(ptr %s4, ptr %t304, i64 %t308, i8 3)
  br label %bb72
bb72:
  %t311 = getelementptr %"compiler/eval:alloc", ptr %l11, i32 0, i32 10
  %t312 = load i64, ptr %t311, !tbaa !24
  %t313 = getelementptr %"compiler/eval:Blob", ptr %l12, i32 0, i32 1
  %t314 = load i64, ptr %t313, !tbaa !24
  %t317 = icmp sgt i64 %t312, %t314
  br i1 %t317, label %bb73, label %bb74
bb73:
  %t319 = getelementptr %"compiler/eval:alloc", ptr %l11, i32 0, i32 10
  %t320 = load i64, ptr %t319, !tbaa !24
  %t322 = getelementptr %"compiler/eval:Blob", ptr %l12, i32 0, i32 1
  store i64 %t320, ptr %t322, !tbaa !24
  br label %bb75
bb74:
  br label %bb75
bb75:
  br label %bb76
bb76:
  store i64 0, ptr %l26, !tbaa !24
  %t323 = getelementptr %"compiler/eval:alloc", ptr %l11, i32 0, i32 1
  %t324 = load i64, ptr %t323, !tbaa !24
  %t326 = sdiv i64 %t324, 8
  store i64 %t326, ptr %l27, !tbaa !24
  store i64 1, ptr %l28, !tbaa !24
  %t328 = load i64, ptr %l27, !tbaa !24
  %t329 = load i64, ptr %l26, !tbaa !24
  %t332 = icmp sgt i64 %t328, %t329
  br i1 %t332, label %bb77, label %bb78
bb77:
  %t334 = load i64, ptr %l28, !tbaa !24
  %t336 = icmp sgt i64 %t334, 0
  br i1 %t336, label %bb79, label %bb80
bb78:
  store i64 0, ptr %l201, !tbaa !24
  br label %bb82
bb79:
  %t338 = load i64, ptr %l27, !tbaa !24
  %t339 = load i64, ptr %l26, !tbaa !24
  %t342 = sub i64 %t338, %t339
  %t343 = load i64, ptr %l28, !tbaa !24
  %t346 = add i64 %t342, %t343
  %t348 = sub i64 %t346, 1
  %t349 = load i64, ptr %l28, !tbaa !24
  %t352 = sdiv i64 %t348, %t349
  store i64 %t352, ptr %l204, !tbaa !24
  br label %bb81
bb80:
  store i64 0, ptr %l204, !tbaa !24
  br label %bb81
bb81:
  %t354 = load i64, ptr %l204, !tbaa !24
  store i64 %t354, ptr %l201, !tbaa !24
  br label %bb82
bb82:
  %t355 = load i64, ptr %l201, !tbaa !24
  store i64 %t355, ptr %l29, !tbaa !24
  store i64 0, ptr %l30, !tbaa !24
  br label %bb83
bb83:
  %t356 = load i64, ptr %l30, !tbaa !24
  %t357 = load i64, ptr %l29, !tbaa !24
  %t360 = icmp slt i64 %t356, %t357
  %t362 = xor i1 %t360, true
  br i1 %t362, label %bb84, label %bb85
bb84:
  br label %bb144
bb85:
  br label %bb86
bb86:
  %t364 = load i64, ptr %l26, !tbaa !24
  %t365 = load i64, ptr %l30, !tbaa !24
  %t366 = load i64, ptr %l28, !tbaa !24
  %t369 = mul i64 %t365, %t366
  %t372 = add i64 %t364, %t369
  store i64 %t372, ptr %l31, !tbaa !24
  %t374 = load ptr, ptr %l0, !tbaa !29
  %t376 = getelementptr %"compiler/eval:Machine", ptr %t374, i32 0, i32 47
  %t377 = load { i64, ptr }, ptr %t376, !tbaa !27
  store { i64, ptr } %t377, ptr %l223, !tbaa !27
  %t378 = getelementptr %"compiler/eval:alloc", ptr %l11, i32 0, i32 0
  %t379 = load i64, ptr %t378, !tbaa !24
  %t381 = sdiv i64 %t379, 8
  %t382 = load i64, ptr %l31, !tbaa !24
  %t385 = add i64 %t381, %t382
  %t387 = getelementptr { i64, ptr }, ptr %l223, i32 0, i32 1
  %t388 = load ptr, ptr %t387, !tbaa !27
  %t389 = getelementptr i64, ptr %t388, i64 %t385
  %t390 = load i64, ptr %t389, !tbaa !34
  store i64 %t390, ptr %l32, !tbaa !24
  %t392 = load i64, ptr %l32, !tbaa !24
  %t394 = icmp eq i64 %t392, 0
  br i1 %t394, label %bb87, label %bb88
bb87:
  br label %bb143
bb88:
  br label %bb89
bb89:
  %t396 = load i64, ptr %l32, !tbaa !24
  %t397 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t400 = and i64 %t396, %t397
  store i64 %t400, ptr %l33, !tbaa !24
  %t402 = load i64, ptr %l33, !tbaa !24
  %t403 = load ptr, ptr %l0, !tbaa !29
  %t405 = getelementptr %"compiler/eval:Machine", ptr %t403, i32 0, i32 51
  %t406 = load i64, ptr %t405, !tbaa !24
  %t409 = icmp sge i64 %t402, %t406
  br i1 %t409, label %bb90, label %bb91
bb90:
  store i1 true, ptr %l238, !tbaa !21
  br label %bb92
bb91:
  %t411 = load ptr, ptr %l0, !tbaa !29
  %t413 = getelementptr %"compiler/eval:Machine", ptr %t411, i32 0, i32 50
  %t414 = load { i64, ptr }, ptr %t413, !tbaa !27
  store { i64, ptr } %t414, ptr %l240, !tbaa !27
  %t415 = load i64, ptr %l33, !tbaa !24
  %t417 = getelementptr { i64, ptr }, ptr %l240, i32 0, i32 1
  %t418 = load ptr, ptr %t417, !tbaa !27
  %t419 = getelementptr %"compiler/eval:alloc", ptr %t418, i64 %t415
  %t420 = getelementptr %"compiler/eval:alloc", ptr %t419, i32 0, i32 4
  %t421 = load i64, ptr %t420, !tbaa !24
  %t422 = load i64, ptr @G_2ecompiler_2feval_2eaFree, !tbaa !24
  %t425 = icmp eq i64 %t421, %t422
  store i1 %t425, ptr %l238, !tbaa !21
  br label %bb92
bb92:
  %t427 = load i1, ptr %l238, !tbaa !21
  br i1 %t427, label %bb93, label %bb94
bb93:
  store i1 true, ptr %l245, !tbaa !21
  br label %bb95
bb94:
  %t428 = load ptr, ptr %l0, !tbaa !29
  %t430 = getelementptr %"compiler/eval:Machine", ptr %t428, i32 0, i32 50
  %t431 = load { i64, ptr }, ptr %t430, !tbaa !27
  store { i64, ptr } %t431, ptr %l247, !tbaa !27
  %t432 = load i64, ptr %l33, !tbaa !24
  %t434 = getelementptr { i64, ptr }, ptr %l247, i32 0, i32 1
  %t435 = load ptr, ptr %t434, !tbaa !27
  %t436 = getelementptr %"compiler/eval:alloc", ptr %t435, i64 %t432
  %t437 = getelementptr %"compiler/eval:alloc", ptr %t436, i32 0, i32 3
  %t438 = load i64, ptr %t437, !tbaa !24
  %t439 = load i64, ptr %l32, !tbaa !24
  %t440 = load i64, ptr @G_2ecompiler_2feval_2eslotBits, !tbaa !24
  store i64 %t440, ptr %l251, !tbaa !24
  %t442 = load i64, ptr %l251, !tbaa !24
  %t443 = load i64, ptr %l251, !tbaa !24
  %t444 = ashr i64 %t439, %t443
  %t447 = icmp ne i64 %t438, %t444
  store i1 %t447, ptr %l245, !tbaa !21
  br label %bb95
bb95:
  %t449 = load i1, ptr %l245, !tbaa !21
  br i1 %t449, label %bb96, label %bb97
bb96:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t451 = insertvalue { i32, %"compiler/eval:Image" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/eval:Image" } %t451, ptr %rv
  br label %ret
bb97:
  br label %bb98
bb98:
  %t452 = load i64, ptr %l33, !tbaa !24
  %t453 = load i64, ptr %l8, !tbaa !24
  %t456 = icmp ne i64 %t452, %t453
  br i1 %t456, label %bb99, label %bb100
bb99:
  %t458 = load ptr, ptr %l0, !tbaa !29
  %t460 = getelementptr %"compiler/eval:Machine", ptr %t458, i32 0, i32 50
  %t461 = load { i64, ptr }, ptr %t460, !tbaa !27
  store { i64, ptr } %t461, ptr %l260, !tbaa !27
  %t462 = load i64, ptr %l33, !tbaa !24
  %t464 = getelementptr { i64, ptr }, ptr %l260, i32 0, i32 1
  %t465 = load ptr, ptr %t464, !tbaa !27
  %t466 = getelementptr %"compiler/eval:alloc", ptr %t465, i64 %t462
  %t467 = getelementptr %"compiler/eval:alloc", ptr %t466, i32 0, i32 4
  %t468 = load i64, ptr %t467, !tbaa !24
  %t469 = load i64, ptr @G_2ecompiler_2feval_2eaValue, !tbaa !24
  %t472 = icmp ne i64 %t468, %t469
  store i1 %t472, ptr %l258, !tbaa !21
  br label %bb101
bb100:
  store i1 false, ptr %l258, !tbaa !21
  br label %bb101
bb101:
  %t474 = load i1, ptr %l258, !tbaa !21
  br i1 %t474, label %bb102, label %bb103
bb102:
  %t475 = load ptr, ptr %l0, !tbaa !29
  %t477 = getelementptr %"compiler/eval:Machine", ptr %t475, i32 0, i32 50
  %t478 = load { i64, ptr }, ptr %t477, !tbaa !27
  store { i64, ptr } %t478, ptr %l267, !tbaa !27
  %t479 = load i64, ptr %l33, !tbaa !24
  %t481 = getelementptr { i64, ptr }, ptr %l267, i32 0, i32 1
  %t482 = load ptr, ptr %t481, !tbaa !27
  %t483 = getelementptr %"compiler/eval:alloc", ptr %t482, i64 %t479
  %t484 = getelementptr %"compiler/eval:alloc", ptr %t483, i32 0, i32 4
  %t485 = load i64, ptr %t484, !tbaa !24
  %t486 = load i64, ptr @G_2ecompiler_2feval_2eaData, !tbaa !24
  %t489 = icmp ne i64 %t485, %t486
  store i1 %t489, ptr %l265, !tbaa !21
  br label %bb104
bb103:
  store i1 false, ptr %l265, !tbaa !21
  br label %bb104
bb104:
  %t491 = load i1, ptr %l265, !tbaa !21
  br i1 %t491, label %bb105, label %bb106
bb105:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t493 = insertvalue { i32, %"compiler/eval:Image" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/eval:Image" } %t493, ptr %rv
  br label %ret
bb106:
  br label %bb107
bb107:
  %t494 = load ptr, ptr %l0, !tbaa !29
  %t496 = getelementptr %"compiler/eval:Machine", ptr %t494, i32 0, i32 50
  %t497 = load { i64, ptr }, ptr %t496, !tbaa !27
  store { i64, ptr } %t497, ptr %l274, !tbaa !27
  %t498 = load i64, ptr %l33, !tbaa !24
  %t500 = getelementptr { i64, ptr }, ptr %l274, i32 0, i32 1
  %t501 = load ptr, ptr %t500, !tbaa !27
  %t502 = getelementptr %"compiler/eval:alloc", ptr %t501, i64 %t498
  %t503 = getelementptr %"compiler/eval:alloc", ptr %t502, i32 0, i32 4
  %t504 = load i64, ptr %t503, !tbaa !24
  %t505 = load i64, ptr @G_2ecompiler_2feval_2eaValue, !tbaa !24
  %t508 = icmp eq i64 %t504, %t505
  br i1 %t508, label %bb108, label %bb109
bb108:
  %t510 = load ptr, ptr %l0, !tbaa !29
  %t512 = getelementptr %"compiler/eval:Machine", ptr %t510, i32 0, i32 50
  %t513 = load { i64, ptr }, ptr %t512, !tbaa !27
  store { i64, ptr } %t513, ptr %l281, !tbaa !27
  %t514 = load i64, ptr %l33, !tbaa !24
  %t516 = getelementptr { i64, ptr }, ptr %l281, i32 0, i32 1
  %t517 = load ptr, ptr %t516, !tbaa !27
  %t518 = getelementptr %"compiler/eval:alloc", ptr %t517, i64 %t514
  %t519 = getelementptr %"compiler/eval:alloc", ptr %t518, i32 0, i32 5
  %t520 = load i64, ptr %t519, !tbaa !24
  %t521 = load ptr, ptr %l0, !tbaa !29
  %t523 = getelementptr %"compiler/eval:Machine", ptr %t521, i32 0, i32 71
  %t524 = load i64, ptr %t523, !tbaa !24
  %t527 = icmp ne i64 %t520, %t524
  store i1 %t527, ptr %l279, !tbaa !21
  br label %bb110
bb109:
  store i1 false, ptr %l279, !tbaa !21
  br label %bb110
bb110:
  %t529 = load i1, ptr %l279, !tbaa !21
  br i1 %t529, label %bb111, label %bb112
bb111:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t531 = insertvalue { i32, %"compiler/eval:Image" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/eval:Image" } %t531, ptr %rv
  br label %ret
bb112:
  br label %bb113
bb113:
  %t532 = load i64, ptr %l33, !tbaa !24
  %t533 = load i64, ptr %l8, !tbaa !24
  %t536 = icmp ne i64 %t532, %t533
  br i1 %t536, label %bb114, label %bb115
bb114:
  %t538 = load ptr, ptr %l0, !tbaa !29
  %t540 = getelementptr %"compiler/eval:Machine", ptr %t538, i32 0, i32 50
  %t541 = load { i64, ptr }, ptr %t540, !tbaa !27
  store { i64, ptr } %t541, ptr %l293, !tbaa !27
  %t542 = load i64, ptr %l33, !tbaa !24
  %t544 = getelementptr { i64, ptr }, ptr %l293, i32 0, i32 1
  %t545 = load ptr, ptr %t544, !tbaa !27
  %t546 = getelementptr %"compiler/eval:alloc", ptr %t545, i64 %t542
  %t547 = getelementptr %"compiler/eval:alloc", ptr %t546, i32 0, i32 8
  %t548 = load i64, ptr %t547, !tbaa !24
  %t550 = icmp sge i64 %t548, 0
  store i1 %t550, ptr %l291, !tbaa !21
  br label %bb116
bb115:
  store i1 false, ptr %l291, !tbaa !21
  br label %bb116
bb116:
  %t552 = load i1, ptr %l291, !tbaa !21
  br i1 %t552, label %bb117, label %bb118
bb117:
  %t553 = load ptr, ptr %l0, !tbaa !29
  %t555 = getelementptr %"compiler/eval:Machine", ptr %t553, i32 0, i32 50
  %t556 = load { i64, ptr }, ptr %t555, !tbaa !27
  store { i64, ptr } %t556, ptr %l299, !tbaa !27
  %t557 = load i64, ptr %l33, !tbaa !24
  %t559 = getelementptr { i64, ptr }, ptr %l299, i32 0, i32 1
  %t560 = load ptr, ptr %t559, !tbaa !27
  %t561 = getelementptr %"compiler/eval:alloc", ptr %t560, i64 %t557
  %t562 = getelementptr %"compiler/eval:alloc", ptr %t561, i32 0, i32 8
  %t563 = load i64, ptr %t562, !tbaa !24
  %t564 = load i64, ptr %l4, !tbaa !24
  %t567 = icmp ne i64 %t563, %t564
  store i1 %t567, ptr %l297, !tbaa !21
  br label %bb119
bb118:
  store i1 false, ptr %l297, !tbaa !21
  br label %bb119
bb119:
  %t569 = load i1, ptr %l297, !tbaa !21
  br i1 %t569, label %bb120, label %bb121
bb120:
  %t570 = getelementptr %"compiler/eval:Blob", ptr %l12, i32 0, i32 3
  %t571 = load i64, ptr %l31, !tbaa !24
  %t573 = mul i64 8, %t571
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s4, ptr %t570, i64 %t573)
  br label %bb122
bb121:
  br label %bb127
bb122:
  %t576 = getelementptr %"compiler/eval:Blob", ptr %l12, i32 0, i32 4
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s4, ptr %t576, i64 -1)
  br label %bb123
bb123:
  %t578 = getelementptr %"compiler/eval:Blob", ptr %l12, i32 0, i32 6
  %t579 = load i64, ptr %l33, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s4, ptr %t578, i64 %t579)
  br label %bb124
bb124:
  %t582 = getelementptr %"compiler/eval:Blob", ptr %l12, i32 0, i32 5
  store ptr %t582, ptr %l310, !tbaa !29
  %t583 = load ptr, ptr %l0, !tbaa !29
  %t584 = getelementptr %"compiler/eval:alloc", ptr %l11, i32 0, i32 0
  %t585 = load i64, ptr %t584, !tbaa !24
  %t586 = load i64, ptr %l31, !tbaa !24
  %t588 = mul i64 8, %t586
  %t591 = add i64 %t585, %t588
  %t594 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erdRaw(ptr %v0, ptr %t583, i64 %t591, i64 8)
  store i64 %t594, ptr %l316
  br label %bb125
bb125:
  %t595 = load ptr, ptr %l310, !tbaa !29
  %t596 = load i64, ptr %l316, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s4, ptr %t595, i64 %t596)
  br label %bb126
bb126:
  br label %bb143
bb127:
  %t597 = load i64, ptr %l33, !tbaa !24
  %t600 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %s0, ptr %l6, i64 %t597)
  %t601 = extractvalue { i32, i64 } %t600, 1
  %t602 = extractvalue { i32, i64 } %t600, 0
  store i32 %t602, ptr %l321
  %t603 = icmp ne i32 %t602, 0
  br i1 %t603, label %bb129, label %ok.604, !prof !99
ok.604:
  store i64 %t601, ptr %l320
  br label %bb128
bb128:
  %t605 = load i64, ptr %l320, !tbaa !24
  store i64 %t605, ptr %l317, !tbaa !24
  br label %bb131
bb129:
  br label %bb130
bb130:
  store i64 -1, ptr %l317, !tbaa !24
  br label %bb131
bb131:
  %t606 = load i64, ptr %l317, !tbaa !24
  store i64 %t606, ptr %l34, !tbaa !24
  %t607 = load i64, ptr %l34, !tbaa !24
  %t609 = icmp slt i64 %t607, 0
  br i1 %t609, label %bb132, label %bb133
bb132:
  %t612 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l7)
  store i64 %t612, ptr %l325
  br label %bb134
bb133:
  br label %bb137
bb134:
  %t613 = load i64, ptr %l325, !tbaa !24
  store i64 %t613, ptr %l34, !tbaa !24
  %t614 = load i64, ptr %l33, !tbaa !24
  %t615 = load i64, ptr %l34, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %s0, ptr %l6, i64 %t614, i64 %t615)
  br label %bb135
bb135:
  %t619 = load i64, ptr %l33, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l7, i64 %t619)
  br label %bb136
bb136:
  br label %bb137
bb137:
  %t622 = getelementptr %"compiler/eval:Blob", ptr %l12, i32 0, i32 3
  %t623 = load i64, ptr %l31, !tbaa !24
  %t625 = mul i64 8, %t623
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s4, ptr %t622, i64 %t625)
  br label %bb138
bb138:
  %t628 = getelementptr %"compiler/eval:Blob", ptr %l12, i32 0, i32 4
  %t629 = load i64, ptr %l34, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s4, ptr %t628, i64 %t629)
  br label %bb139
bb139:
  %t632 = getelementptr %"compiler/eval:Blob", ptr %l12, i32 0, i32 6
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s4, ptr %t632, i64 -1)
  br label %bb140
bb140:
  %t634 = getelementptr %"compiler/eval:Blob", ptr %l12, i32 0, i32 5
  store ptr %t634, ptr %l337, !tbaa !29
  %t635 = load ptr, ptr %l0, !tbaa !29
  %t636 = getelementptr %"compiler/eval:alloc", ptr %l11, i32 0, i32 0
  %t637 = load i64, ptr %t636, !tbaa !24
  %t638 = load i64, ptr %l31, !tbaa !24
  %t640 = mul i64 8, %t638
  %t643 = add i64 %t637, %t640
  %t646 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erdRaw(ptr %v0, ptr %t635, i64 %t643, i64 8)
  store i64 %t646, ptr %l343
  br label %bb141
bb141:
  %t647 = load ptr, ptr %l337, !tbaa !29
  %t648 = load i64, ptr %l343, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s4, ptr %t647, i64 %t648)
  br label %bb142
bb142:
  br label %bb143
bb143:
  %t649 = load i64, ptr %l30, !tbaa !24
  %t652 = add i64 %t649, 1
  store i64 %t652, ptr %l30, !tbaa !24
  br label %bb83
bb144:
  %t654 = load ptr, ptr %lp5
  %t655 = getelementptr %"compiler/eval:Image", ptr %t654, i32 0, i32 0
  store ptr %t655, ptr %l347, !tbaa !29
  call void @llvm.memmove.p0.p0.i64(ptr %l348, ptr %l12, i64 272, i1 false)
  call void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feval_3aBlob(ptr %t656, ptr %s4, ptr %l348)
  call void @llvm.memmove.p0.p0.i64(ptr %l350, ptr %t656, i64 272, i1 false)
  br label %bb145
bb145:
  %t658 = load ptr, ptr %l347, !tbaa !29
  call void @llvm.memmove.p0.p0.i64(ptr %t659, ptr %l350, i64 272, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aBlob_3e_2ePush_3ccompiler_2feval_3aBlob_3e(ptr %v1, ptr %s4, ptr %t658, ptr %t659)
  br label %bb146
bb146:
  %t660 = load ptr, ptr %lp5
  %t661 = getelementptr %"compiler/eval:Image", ptr %t660, i32 0, i32 1
  %t662 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t661, i64 %t662)
  br label %bb147
bb147:
  %t665 = load i64, ptr %l9, !tbaa !24
  %t668 = add i64 %t665, 1
  store i64 %t668, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb148
bb148:
  br label %bb19
bb149:
  %t670 = load ptr, ptr %l0, !tbaa !29
  %t672 = getelementptr %"compiler/eval:Machine", ptr %t670, i32 0, i32 43
  %t673 = load i64, ptr %l4, !tbaa !24
  %t676 = call %"compiler/eval:global" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2eAt_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %t672, i64 %t673)
  store %"compiler/eval:global" %t676, ptr %l359
  br label %bb150
bb150:
  %t677 = getelementptr %"compiler/eval:global", ptr %l359, i32 0, i32 0
  %t678 = load i64, ptr %t677, !tbaa !24
  %t680 = trunc i64 %t678 to i32
  store i32 %t680, ptr %l35, !tbaa !23
  %t683 = load ptr, ptr %l0, !tbaa !29
  %t685 = getelementptr %"compiler/eval:Machine", ptr %t683, i32 0, i32 0
  %t686 = load ptr, ptr %t685, !tbaa !29
  %t687 = load i32, ptr %l35, !tbaa !23
  %t690 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t686, i32 %t687)
  store i1 %t690, ptr %l366
  br label %bb151
bb151:
  %t691 = load i1, ptr %l366, !tbaa !21
  br i1 %t691, label %bb152, label %bb153
bb152:
  %t692 = load ptr, ptr %l0, !tbaa !29
  %t694 = getelementptr %"compiler/eval:Machine", ptr %t692, i32 0, i32 0
  %t695 = load ptr, ptr %t694, !tbaa !29
  %t696 = load i32, ptr %l35, !tbaa !23
  %t699 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t695, i32 %t696)
  store i64 %t699, ptr %l371
  br label %bb154
bb153:
  store i1 false, ptr %l367, !tbaa !21
  br label %bb155
bb154:
  %t700 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t701 = load i64, ptr %l371, !tbaa !24
  %t703 = and i64 %t701, %t700
  %t705 = icmp eq i64 %t703, 0
  store i1 %t705, ptr %l367, !tbaa !21
  br label %bb155
bb155:
  %t707 = load i1, ptr %l367, !tbaa !21
  br i1 %t707, label %bb156, label %bb157
bb156:
  store %olang.scope zeroinitializer, ptr %s25
  %t708 = load ptr, ptr %lp5
  %t709 = getelementptr %"compiler/eval:Image", ptr %t708, i32 0, i32 0
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aBlob_3e_2eAt_3ccompiler_2feval_3aBlob_3e(ptr %t710, ptr %v1, ptr %v1, ptr %t709, i64 0)
  call void @llvm.memmove.p0.p0.i64(ptr %l376, ptr %t710, i64 272, i1 false)
  br label %bb158
bb157:
  br label %bb177
bb158:
  call void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feval_3aBlob(ptr %t712, ptr %v1, ptr %l376)
  call void @llvm.memmove.p0.p0.i64(ptr %l378, ptr %t712, i64 272, i1 false)
  br label %bb159
bb159:
  %t714 = getelementptr %"compiler/eval:Blob", ptr %l378, i32 0, i32 4
  store ptr %t714, ptr %l36, !tbaa !29
  store i64 0, ptr %l37, !tbaa !24
  br label %bb160
bb160:
  %t716 = load i64, ptr %l37, !tbaa !24
  store i64 %t716, ptr %l380, !tbaa !24
  %t717 = load ptr, ptr %l36, !tbaa !29
  %t719 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s25, ptr %t717)
  store i64 %t719, ptr %l382
  br label %bb161
bb161:
  %t720 = load i64, ptr %l380, !tbaa !24
  %t721 = load i64, ptr %l382, !tbaa !24
  %t722 = icmp slt i64 %t720, %t721
  %t724 = xor i1 %t722, true
  br i1 %t724, label %bb162, label %bb163
bb162:
  br label %bb176
bb163:
  br label %bb164
bb164:
  %t726 = load ptr, ptr %l36, !tbaa !29
  %t727 = load i64, ptr %l37, !tbaa !24
  %t730 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s25, ptr %t726, i64 %t727)
  store i64 %t730, ptr %l387
  br label %bb165
bb165:
  %t731 = load i64, ptr %l387, !tbaa !24
  store i64 %t731, ptr %l38, !tbaa !24
  %t732 = load i64, ptr %l38, !tbaa !24
  %t734 = icmp sgt i64 %t732, 0
  br i1 %t734, label %bb166, label %bb167
bb166:
  %t736 = load ptr, ptr %lp5
  %t737 = getelementptr %"compiler/eval:Image", ptr %t736, i32 0, i32 0
  %t738 = load i64, ptr %l38, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aBlob_3e_2eAt_3ccompiler_2feval_3aBlob_3e(ptr %t739, ptr %v1, ptr %v1, ptr %t737, i64 %t738)
  call void @llvm.memmove.p0.p0.i64(ptr %l393, ptr %t739, i64 272, i1 false)
  br label %bb168
bb167:
  store i1 false, ptr %l390, !tbaa !21
  br label %bb170
bb168:
  %t742 = getelementptr %"compiler/eval:Blob", ptr %l393, i32 0, i32 3
  %t744 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t742)
  store i64 %t744, ptr %l395
  br label %bb169
bb169:
  %t745 = load i64, ptr %l395, !tbaa !24
  %t746 = icmp eq i64 %t745, 0
  store i1 %t746, ptr %l390, !tbaa !21
  br label %bb170
bb170:
  %t748 = load i1, ptr %l390, !tbaa !21
  br i1 %t748, label %bb171, label %bb172
bb171:
  %t749 = load i64, ptr %l38, !tbaa !24
  store i1 true, ptr %l40, !tbaa !21
  %t751 = load ptr, ptr %lp5
  %t752 = getelementptr %"compiler/eval:Image", ptr %t751, i32 0, i32 0
  %t756 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aBlob_3e_2eRefMut_3ccompiler_2feval_3aBlob_3e(ptr %v1, ptr %v1, ptr %t752, i64 %t749)
  store ptr %t756, ptr %l400
  br label %bb173
bb172:
  br label %bb174
bb173:
  %t757 = load ptr, ptr %l400, !tbaa !29
  %t759 = load i1, ptr %l40, !tbaa !21
  %t762 = getelementptr %"compiler/eval:Blob", ptr %t757, i32 0, i32 2
  store i1 %t759, ptr %t762, !tbaa !21
  br label %bb174
bb174:
  br label %bb175
bb175:
  %t763 = load i64, ptr %l37, !tbaa !24
  %t766 = add i64 %t763, 1
  store i64 %t766, ptr %l37, !tbaa !24
  br label %bb160
bb176:
  call void @__olang_scope_close(ptr %s25)
  br label %bb177
bb177:
  %t768 = load ptr, ptr %lp5
  %t769 = load %"compiler/eval:Image", ptr %t768
  call void @__olang_scope_close(ptr %s0)
  %t771 = insertvalue { i32, %"compiler/eval:Image" } zeroinitializer, %"compiler/eval:Image" %t769, 1
  store { i32, %"compiler/eval:Image" } %t771, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/eval:Image" }, ptr %rv
  ret { i32, %"compiler/eval:Image" } %rr
}

define dso_local { { i64, ptr }, i64, %"compiler/source:Span" } @compiler_2feval_2ecompiler_2feval_3aMachine_2eWhy(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca { i64, [21 x i64] }
  %l17 = alloca { { i64, ptr }, %"compiler/source:Span" }
  %lp18 = alloca ptr
  %l19 = alloca %"compiler/source:Span"
  %l20 = alloca { { i64, ptr }, %"compiler/source:Span" }
  %lp21 = alloca ptr
  %l22 = alloca %"compiler/source:Span"
  %l23 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l24 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l27 = alloca i64
  %l31 = alloca { i64, ptr }
  %l32 = alloca %"compiler/source:Span"
  %l33 = alloca { { i64, ptr }, i64, %"compiler/source:Span" }
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca { i64, ptr }
  %l42 = alloca i64
  %l45 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i32
  %l52 = alloca ptr
  %l55 = alloca i64
  %l59 = alloca i64
  %l62 = alloca i64
  %l83 = alloca ptr
  %l86 = alloca i64
  %l88 = alloca i64
  %l93 = alloca { i64, [21 x i64] }
  %l96 = alloca { i64, [21 x i64] }
  %l97 = alloca { { i64, ptr }, %"compiler/source:Span" }
  %l98 = alloca { i64, ptr }
  %l99 = alloca i64
  %l100 = alloca { i64, ptr }
  %l103 = alloca i1
  %l119 = alloca { { i64, ptr }, %"compiler/source:Span" }
  %l120 = alloca { i64, ptr }
  %l121 = alloca i64
  %l122 = alloca { i64, ptr }
  %l125 = alloca i1
  %l135 = alloca { i64, ptr }
  %l136 = alloca { i64, ptr }
  %l137 = alloca %"compiler/source:Span"
  %l138 = alloca { { i64, ptr }, i64, %"compiler/source:Span" }
  %l139 = alloca { i64, ptr }
  %l140 = alloca i64
  %l141 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca { { i64, ptr }, i64, %"compiler/source:Span" }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l23
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l23
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l2
  %t3 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l24
  br label %bb2
bb2:
  %t4 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l24
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l3
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t9 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2efnIndex(ptr %v0, ptr %t5, { i64, [2 x i64] } %a1)
  store i64 %t9, ptr %l27
  br label %bb3
bb3:
  %t10 = load i64, ptr %l27, !tbaa !24
  store i64 %t10, ptr %l4, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp slt i64 %t11, 0
  br i1 %t13, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t15 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNoBody, !tbaa !27
  store { i64, ptr } %t15, ptr %l31, !tbaa !27
  %t17 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s1, i32 0, i32 0)
  store %"compiler/source:Span" %t17, ptr %l32
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t18 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t19 = insertvalue { { i64, ptr }, i64, %"compiler/source:Span" } undef, { i64, ptr } %t18, 0
  %t20 = insertvalue { { i64, ptr }, i64, %"compiler/source:Span" } %t19, i64 0, 1
  %t21 = load %"compiler/source:Span", ptr %l32
  %t22 = insertvalue { { i64, ptr }, i64, %"compiler/source:Span" } %t20, %"compiler/source:Span" %t21, 2
  store { { i64, ptr }, i64, %"compiler/source:Span" } %t22, ptr %l33
  %t23 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %l33, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  store { i64, ptr } %t24, ptr %l34, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t25, 0
  store i64 %t26, ptr %l35, !tbaa !24
  %t27 = load i64, ptr %l35, !tbaa !24
  %t28 = mul i64 %t27, 1
  %t29 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t28)
  %t30 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t29, 1
  store { i64, ptr } %t31, ptr %l36, !tbaa !27
  %t32 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = load i64, ptr %l35, !tbaa !24
  %t37 = mul i64 %t36, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t33, ptr %t35, i64 %t37, i1 false)
  %t38 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t39 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %l33, i32 0, i32 0
  store { i64, ptr } %t38, ptr %t39, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t40 = load { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %l33
  store { { i64, ptr }, i64, %"compiler/source:Span" } %t40, ptr %rv
  br label %ret
bb7:
  %t41 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l3, i64 %t41)
  br label %bb8
bb8:
  %t44 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %s0, ptr %l2, i64 %t44, i1 true)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t48 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l3)
  store i64 %t48, ptr %l42
  br label %bb11
bb11:
  %t49 = load i64, ptr %l42, !tbaa !24
  %t50 = icmp sgt i64 %t49, 0
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb12, label %bb13
bb12:
  br label %bb53
bb13:
  br label %bb14
bb14:
  %t55 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %s0, ptr %l3)
  %t56 = extractvalue { i32, i64 } %t55, 1
  %t57 = extractvalue { i32, i64 } %t55, 0
  store i32 %t57, ptr %l48
  %t58 = icmp ne i32 %t57, 0
  br i1 %t58, label %bb16, label %ok.59, !prof !99
ok.59:
  store i64 %t56, ptr %l47
  br label %bb15
bb15:
  %t60 = load i64, ptr %l47, !tbaa !24
  store i64 %t60, ptr %l45, !tbaa !24
  br label %bb18
bb16:
  br label %bb17
bb17:
  br label %bb53
bb18:
  %t61 = load i64, ptr %l45, !tbaa !24
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/eval:Machine", ptr %t62, i32 0, i32 26
  %t68 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_26_3e_2eAt_3ccompiler_2fmir_3aFn_26_3e(ptr %v0, ptr %v0, ptr %t64, i64 %t61)
  store ptr %t68, ptr %l52
  br label %bb19
bb19:
  %t69 = load ptr, ptr %l52, !tbaa !29
  store ptr %t69, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  %t70 = load ptr, ptr %l6, !tbaa !29
  %t72 = getelementptr %"compiler/mir:Fn", ptr %t70, i32 0, i32 9
  %t74 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eLen_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %t72)
  store i64 %t74, ptr %l55
  br label %bb20
bb20:
  %t75 = load i64, ptr %l55, !tbaa !24
  store i64 %t75, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t76 = load i64, ptr %l8, !tbaa !24
  %t77 = load i64, ptr %l7, !tbaa !24
  %t80 = icmp sgt i64 %t76, %t77
  br i1 %t80, label %bb21, label %bb22
bb21:
  %t82 = load i64, ptr %l9, !tbaa !24
  %t84 = icmp sgt i64 %t82, 0
  br i1 %t84, label %bb23, label %bb24
bb22:
  store i64 0, ptr %l59, !tbaa !24
  br label %bb26
bb23:
  %t86 = load i64, ptr %l8, !tbaa !24
  %t87 = load i64, ptr %l7, !tbaa !24
  %t90 = sub i64 %t86, %t87
  %t91 = load i64, ptr %l9, !tbaa !24
  %t94 = add i64 %t90, %t91
  %t96 = sub i64 %t94, 1
  %t97 = load i64, ptr %l9, !tbaa !24
  %t100 = sdiv i64 %t96, %t97
  store i64 %t100, ptr %l62, !tbaa !24
  br label %bb25
bb24:
  store i64 0, ptr %l62, !tbaa !24
  br label %bb25
bb25:
  %t102 = load i64, ptr %l62, !tbaa !24
  store i64 %t102, ptr %l59, !tbaa !24
  br label %bb26
bb26:
  %t103 = load i64, ptr %l59, !tbaa !24
  store i64 %t103, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb27
bb27:
  store %olang.scope zeroinitializer, ptr %s5
  %t104 = load i64, ptr %l11, !tbaa !24
  %t105 = load i64, ptr %l10, !tbaa !24
  %t108 = icmp slt i64 %t104, %t105
  %t110 = xor i1 %t108, true
  br i1 %t110, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s5)
  br label %bb51
bb29:
  br label %bb30
bb30:
  %t112 = load i64, ptr %l7, !tbaa !24
  %t113 = load i64, ptr %l11, !tbaa !24
  %t114 = load i64, ptr %l9, !tbaa !24
  %t117 = mul i64 %t113, %t114
  %t120 = add i64 %t112, %t117
  %t122 = load ptr, ptr %l6, !tbaa !29
  %t124 = getelementptr %"compiler/mir:Fn", ptr %t122, i32 0, i32 9
  %t128 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eRef_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %v0, ptr %t124, i64 %t120)
  store ptr %t128, ptr %l83
  br label %bb31
bb31:
  %t129 = load ptr, ptr %l83, !tbaa !29
  store ptr %t129, ptr %l13, !tbaa !29
  %t130 = load ptr, ptr %l13, !tbaa !29
  %t132 = getelementptr %"compiler/mir:BasicBlock", ptr %t130, i32 0, i32 0
  store ptr %t132, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb32
bb32:
  store %olang.scope zeroinitializer, ptr %s7
  %t134 = load i64, ptr %l15, !tbaa !24
  store i64 %t134, ptr %l86, !tbaa !24
  %t135 = load ptr, ptr %l14, !tbaa !29
  %t137 = call i64 @compiler_2fmir_2ecompiler_2fmir_3aStmtList_2eLen(ptr %v0, ptr %t135)
  store i64 %t137, ptr %l88
  br label %bb33
bb33:
  %t138 = load i64, ptr %l86, !tbaa !24
  %t139 = load i64, ptr %l88, !tbaa !24
  %t140 = icmp slt i64 %t138, %t139
  %t142 = xor i1 %t140, true
  br i1 %t142, label %bb34, label %bb35
bb34:
  call void @__olang_scope_close(ptr %s7)
  br label %bb44
bb35:
  br label %bb36
bb36:
  %t144 = load ptr, ptr %l14, !tbaa !29
  %t145 = load i64, ptr %l15, !tbaa !24
  %t148 = call { i64, [21 x i64] } @compiler_2fmir_2ecompiler_2fmir_3aStmtList_2eAt(ptr %v0, ptr %t144, i64 %t145)
  store { i64, [21 x i64] } %t148, ptr %l93
  br label %bb37
bb37:
  call void @llvm.memmove.p0.p0.i64(ptr %l16, ptr %l93, i64 176, i1 false)
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load ptr, ptr %l6, !tbaa !29
  call void @llvm.memmove.p0.p0.i64(ptr %l96, ptr %l16, i64 176, i1 false)
  %t153 = load { i64, [21 x i64] }, ptr %l96
  %t154 = call { { i64, ptr }, %"compiler/source:Span" } @compiler_2feval_2ecompiler_2feval_3aMachine_2ewhyStmt(ptr %v0, ptr %v0, ptr %v1, ptr %t149, ptr %t150, { i64, [21 x i64] } %t153)
  store { { i64, ptr }, %"compiler/source:Span" } %t154, ptr %l97
  br label %bb38
bb38:
  %t155 = load { { i64, ptr }, %"compiler/source:Span" }, ptr %l97
  store { { i64, ptr }, %"compiler/source:Span" } %t155, ptr %l17
  %t156 = getelementptr { { i64, ptr }, %"compiler/source:Span" }, ptr %l17, i32 0, i32 0
  %t157 = load { i64, ptr }, ptr %t156, !tbaa !27
  store { i64, ptr } %t157, ptr %l98, !tbaa !27
  %t158 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t159 = extractvalue { i64, ptr } %t158, 0
  store i64 %t159, ptr %l99, !tbaa !24
  %t160 = load i64, ptr %l99, !tbaa !24
  %t161 = mul i64 %t160, 1
  %t162 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t161)
  %t163 = insertvalue { i64, ptr } undef, i64 %t160, 0
  %t164 = insertvalue { i64, ptr } %t163, ptr %t162, 1
  store { i64, ptr } %t164, ptr %l100, !tbaa !27
  %t165 = getelementptr { i64, ptr }, ptr %l100, i32 0, i32 1
  %t166 = load ptr, ptr %t165, !tbaa !27
  %t167 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t168 = load ptr, ptr %t167, !tbaa !27
  %t169 = load i64, ptr %l99, !tbaa !24
  %t170 = mul i64 %t169, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t166, ptr %t168, i64 %t170, i1 false)
  %t171 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t171, ptr %lp18
  %t172 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t173 = load ptr, ptr %lp18
  store { i64, ptr } %t172, ptr %t173, !tbaa !27
  %t174 = getelementptr { { i64, ptr }, %"compiler/source:Span" }, ptr %l17, i32 0, i32 1
  %t175 = load %"compiler/source:Span", ptr %t174
  store %"compiler/source:Span" %t175, ptr %l19
  %t177 = load ptr, ptr %lp18
  %t178 = load { i64, ptr }, ptr %t177, !tbaa !27
  %t180 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s7, { i64, ptr } %t178, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store i1 %t180, ptr %l103
  br label %bb39
bb39:
  %t181 = load i1, ptr %l103, !tbaa !21
  %t182 = xor i1 %t181, true
  br i1 %t182, label %bb40, label %bb41
bb40:
  %t184 = load ptr, ptr %lp18
  %t185 = load { i64, ptr }, ptr %t184, !tbaa !27
  %t186 = load ptr, ptr %l6, !tbaa !29
  %t188 = getelementptr %"compiler/mir:Fn", ptr %t186, i32 0, i32 2
  %t189 = load i64, ptr %t188, !tbaa !24
  %t190 = load %"compiler/source:Span", ptr %l19
  %t192 = insertvalue { { i64, ptr }, i64, %"compiler/source:Span" } undef, { i64, ptr } %t185, 0
  %t194 = insertvalue { { i64, ptr }, i64, %"compiler/source:Span" } %t192, i64 %t189, 1
  %t196 = insertvalue { { i64, ptr }, i64, %"compiler/source:Span" } %t194, %"compiler/source:Span" %t190, 2
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, i64, %"compiler/source:Span" } %t196, ptr %rv
  br label %ret
bb41:
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s7)
  br label %bb43
bb43:
  %t198 = load i64, ptr %l15, !tbaa !24
  %t201 = add i64 %t198, 1
  store i64 %t201, ptr %l15, !tbaa !24
  br label %bb32
bb44:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load ptr, ptr %l6, !tbaa !29
  %t205 = load ptr, ptr %l13, !tbaa !29
  %t207 = getelementptr %"compiler/mir:BasicBlock", ptr %t205, i32 0, i32 1
  %t208 = load { i64, [8 x i64] }, ptr %t207
  %t214 = call { { i64, ptr }, %"compiler/source:Span" } @compiler_2feval_2ecompiler_2feval_3aMachine_2ewhyTerm(ptr %v0, ptr %v0, ptr %s0, ptr %s0, ptr %v1, ptr %t203, ptr %t204, { i64, [8 x i64] } %t208, ptr %l2, ptr %l3)
  store { { i64, ptr }, %"compiler/source:Span" } %t214, ptr %l119
  br label %bb45
bb45:
  %t215 = load { { i64, ptr }, %"compiler/source:Span" }, ptr %l119
  store { { i64, ptr }, %"compiler/source:Span" } %t215, ptr %l20
  %t216 = getelementptr { { i64, ptr }, %"compiler/source:Span" }, ptr %l20, i32 0, i32 0
  %t217 = load { i64, ptr }, ptr %t216, !tbaa !27
  store { i64, ptr } %t217, ptr %l120, !tbaa !27
  %t218 = load { i64, ptr }, ptr %l120, !tbaa !27
  %t219 = extractvalue { i64, ptr } %t218, 0
  store i64 %t219, ptr %l121, !tbaa !24
  %t220 = load i64, ptr %l121, !tbaa !24
  %t221 = mul i64 %t220, 1
  %t222 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t221)
  %t223 = insertvalue { i64, ptr } undef, i64 %t220, 0
  %t224 = insertvalue { i64, ptr } %t223, ptr %t222, 1
  store { i64, ptr } %t224, ptr %l122, !tbaa !27
  %t225 = getelementptr { i64, ptr }, ptr %l122, i32 0, i32 1
  %t226 = load ptr, ptr %t225, !tbaa !27
  %t227 = getelementptr { i64, ptr }, ptr %l120, i32 0, i32 1
  %t228 = load ptr, ptr %t227, !tbaa !27
  %t229 = load i64, ptr %l121, !tbaa !24
  %t230 = mul i64 %t229, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t226, ptr %t228, i64 %t230, i1 false)
  %t231 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t231, ptr %lp21
  %t232 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t233 = load ptr, ptr %lp21
  store { i64, ptr } %t232, ptr %t233, !tbaa !27
  %t234 = getelementptr { { i64, ptr }, %"compiler/source:Span" }, ptr %l20, i32 0, i32 1
  %t235 = load %"compiler/source:Span", ptr %t234
  store %"compiler/source:Span" %t235, ptr %l22
  %t237 = load ptr, ptr %lp21
  %t238 = load { i64, ptr }, ptr %t237, !tbaa !27
  %t240 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s5, { i64, ptr } %t238, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store i1 %t240, ptr %l125
  br label %bb46
bb46:
  %t241 = load i1, ptr %l125, !tbaa !21
  %t242 = xor i1 %t241, true
  br i1 %t242, label %bb47, label %bb48
bb47:
  %t244 = load ptr, ptr %lp21
  %t245 = load { i64, ptr }, ptr %t244, !tbaa !27
  %t246 = load ptr, ptr %l6, !tbaa !29
  %t248 = getelementptr %"compiler/mir:Fn", ptr %t246, i32 0, i32 2
  %t249 = load i64, ptr %t248, !tbaa !24
  %t250 = load %"compiler/source:Span", ptr %l22
  %t252 = insertvalue { { i64, ptr }, i64, %"compiler/source:Span" } undef, { i64, ptr } %t245, 0
  %t254 = insertvalue { { i64, ptr }, i64, %"compiler/source:Span" } %t252, i64 %t249, 1
  %t256 = insertvalue { { i64, ptr }, i64, %"compiler/source:Span" } %t254, %"compiler/source:Span" %t250, 2
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, i64, %"compiler/source:Span" } %t256, ptr %rv
  br label %ret
bb48:
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s5)
  br label %bb50
bb50:
  %t258 = load i64, ptr %l11, !tbaa !24
  %t261 = add i64 %t258, 1
  store i64 %t261, ptr %l11, !tbaa !24
  br label %bb27
bb51:
  br label %bb52
bb52:
  br label %bb10
bb53:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d2, i32 0, i32 1) }, ptr %l135, !tbaa !27
  %t263 = load { i64, ptr }, ptr %l135, !tbaa !27
  store { i64, ptr } %t263, ptr %l136, !tbaa !27
  %t264 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 0, i32 0)
  store %"compiler/source:Span" %t264, ptr %l137
  br label %bb54
bb54:
  %t265 = load { i64, ptr }, ptr %l136, !tbaa !27
  %t266 = insertvalue { { i64, ptr }, i64, %"compiler/source:Span" } undef, { i64, ptr } %t265, 0
  %t267 = insertvalue { { i64, ptr }, i64, %"compiler/source:Span" } %t266, i64 0, 1
  %t268 = load %"compiler/source:Span", ptr %l137
  %t269 = insertvalue { { i64, ptr }, i64, %"compiler/source:Span" } %t267, %"compiler/source:Span" %t268, 2
  store { { i64, ptr }, i64, %"compiler/source:Span" } %t269, ptr %l138
  %t270 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %l138, i32 0, i32 0
  %t271 = load { i64, ptr }, ptr %t270, !tbaa !27
  store { i64, ptr } %t271, ptr %l139, !tbaa !27
  %t272 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t273 = extractvalue { i64, ptr } %t272, 0
  store i64 %t273, ptr %l140, !tbaa !24
  %t274 = load i64, ptr %l140, !tbaa !24
  %t275 = mul i64 %t274, 1
  %t276 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t275)
  %t277 = insertvalue { i64, ptr } undef, i64 %t274, 0
  %t278 = insertvalue { i64, ptr } %t277, ptr %t276, 1
  store { i64, ptr } %t278, ptr %l141, !tbaa !27
  %t279 = getelementptr { i64, ptr }, ptr %l141, i32 0, i32 1
  %t280 = load ptr, ptr %t279, !tbaa !27
  %t281 = getelementptr { i64, ptr }, ptr %l139, i32 0, i32 1
  %t282 = load ptr, ptr %t281, !tbaa !27
  %t283 = load i64, ptr %l140, !tbaa !24
  %t284 = mul i64 %t283, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t280, ptr %t282, i64 %t284, i1 false)
  %t285 = load { i64, ptr }, ptr %l141, !tbaa !27
  %t286 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %l138, i32 0, i32 0
  store { i64, ptr } %t285, ptr %t286, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t287 = load { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %l138
  store { { i64, ptr }, i64, %"compiler/source:Span" } %t287, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %rv
  ret { { i64, ptr }, i64, %"compiler/source:Span" } %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eanchorRegion(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca i64
  %l8 = alloca %"compiler/eval:Ptr"
  %l9 = alloca i32
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l22 = alloca i1
  %l26 = alloca ptr
  %l31 = alloca i64
  %l33 = alloca i64
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l53 = alloca i64
  %l54 = alloca i64
  %l58 = alloca i64
  %l60 = alloca %"compiler/eval:Ptr"
  %l64 = alloca i32
  %l68 = alloca ptr
  %l72 = alloca %"compiler/eval:Ptr"
  %l73 = alloca i64
  %l80 = alloca i64
  %l83 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i32, ptr %l2, !tbaa !23
  %t8 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnchors(ptr %v0, ptr %s0, ptr %t4, i32 %t5)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %l18
  br label %bb1
bb1:
  %t9 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l3
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/eval:Machine", ptr %t10, i32 0, i32 0
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t14 = load i32, ptr %l2, !tbaa !23
  %t17 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %v0, ptr %t13, i32 %t14)
  store i1 %t17, ptr %l22
  br label %bb2
bb2:
  %t18 = load i1, ptr %l22, !tbaa !21
  %t19 = xor i1 %t18, true
  store i1 %t19, ptr %l4, !tbaa !21
  %t21 = load i1, ptr %l4, !tbaa !21
  %t23 = xor i1 %t21, true
  br i1 %t23, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  store ptr %l3, ptr %l26, !tbaa !29
  %t25 = icmp sge i64 0, 0
  br i1 %t25, label %bb5, label %bb6
bb4:
  br label %bb10
bb5:
  %t27 = icmp sle i64 0, 1152921504606846975
  br i1 %t27, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_1af190ed0f8ad609_3dab539ded9f1c85)
  unreachable
bb7:
  %t29 = mul i64 0, 8
  %t30 = insertvalue { i64, ptr } undef, i64 0, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t32 = load ptr, ptr %l26, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2ePush_3cArray_3cI64_3e_3e(ptr %s0, ptr %t32, { i64, ptr } %t31)
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_1af190ed0f8ad609_3dab539ded9f1c85)
  unreachable
bb9:
  call void @__olang_scope_close(ptr %s1)
  br label %bb10
bb10:
  store ptr %l3, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t35 = load i64, ptr %l6, !tbaa !24
  store i64 %t35, ptr %l31, !tbaa !24
  %t36 = load ptr, ptr %l5, !tbaa !29
  %t38 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2eLen_3cArray_3cI64_3e_3e(ptr %s0, ptr %t36)
  store i64 %t38, ptr %l33
  br label %bb12
bb12:
  %t39 = load i64, ptr %l31, !tbaa !24
  %t40 = load i64, ptr %l33, !tbaa !24
  %t41 = icmp slt i64 %t39, %t40
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb39
bb14:
  br label %bb15
bb15:
  %t45 = load ptr, ptr %l5, !tbaa !29
  %t46 = load i64, ptr %l6, !tbaa !24
  %t49 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2eAt_3cArray_3cI64_3e_3e(ptr %s0, ptr %s3, ptr %t45, i64 %t46)
  store { i64, ptr } %t49, ptr %l38
  br label %bb16
bb16:
  %t50 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t50, 0
  store i64 %t51, ptr %l39, !tbaa !24
  %t52 = load i64, ptr %l39, !tbaa !24
  %t53 = mul i64 %t52, 8
  %t54 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t53)
  %t55 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t54, 1
  store { i64, ptr } %t56, ptr %l40, !tbaa !27
  %t57 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = load i64, ptr %l39, !tbaa !24
  %t62 = mul i64 %t61, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t58, ptr %t60, i64 %t62, i1 false)
  %t63 = load { i64, ptr }, ptr %l40, !tbaa !27
  store %"compiler/eval:Ptr" %a1, ptr %l8
  %t66 = load i32, ptr %l2, !tbaa !23
  store i32 %t66, ptr %l9, !tbaa !23
  store { i64, ptr } %t63, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t70 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t70, 0
  store i64 %t72, ptr %l12, !tbaa !24
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s5
  %t74 = load i64, ptr %l11, !tbaa !24
  %t75 = load i64, ptr %l12, !tbaa !24
  %t78 = icmp slt i64 %t74, %t75
  %t80 = xor i1 %t78, true
  br i1 %t80, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s5)
  br label %bb25
bb19:
  br label %bb20
bb20:
  %t82 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t82, ptr %l50, !tbaa !27
  %t83 = load i64, ptr %l11, !tbaa !24
  %t85 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = getelementptr i64, ptr %t86, i64 %t83
  %t88 = load i64, ptr %t87, !tbaa !34
  store i64 %t88, ptr %l13, !tbaa !24
  %t90 = getelementptr %"compiler/eval:Ptr", ptr %l8, i32 0, i32 0
  %t91 = load i64, ptr %t90, !tbaa !24
  store i64 %t91, ptr %l53, !tbaa !24
  %t92 = getelementptr %"compiler/eval:Ptr", ptr %l8, i32 0, i32 1
  %t93 = load i64, ptr %t92, !tbaa !24
  store i64 %t93, ptr %l54, !tbaa !24
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load i32, ptr %l9, !tbaa !23
  %t96 = load i64, ptr %l13, !tbaa !24
  %t100 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2epartOffset(ptr %v0, ptr %t94, i32 %t95, i64 %t96)
  store i64 %t100, ptr %l58
  br label %bb21
bb21:
  %t101 = load i64, ptr %l54, !tbaa !24
  %t102 = load i64, ptr %l58, !tbaa !24
  %t103 = add i64 %t101, %t102
  %t104 = load i64, ptr %l53, !tbaa !24
  %t106 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s5, i64 %t104, i64 %t103)
  store %"compiler/eval:Ptr" %t106, ptr %l60
  br label %bb22
bb22:
  %t107 = load %"compiler/eval:Ptr", ptr %l60
  store %"compiler/eval:Ptr" %t107, ptr %l8
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load i32, ptr %l9, !tbaa !23
  %t110 = load i64, ptr %l13, !tbaa !24
  %t114 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2epartType(ptr %v0, ptr %t108, i32 %t109, i64 %t110)
  store i32 %t114, ptr %l64
  br label %bb23
bb23:
  %t115 = load i32, ptr %l64, !tbaa !23
  store i32 %t115, ptr %l9, !tbaa !23
  call void @__olang_scope_close(ptr %s5)
  br label %bb24
bb24:
  %t116 = load i64, ptr %l11, !tbaa !24
  %t119 = add i64 %t116, 1
  store i64 %t119, ptr %l11, !tbaa !24
  br label %bb17
bb25:
  %t121 = load ptr, ptr %l0, !tbaa !29
  store ptr %t121, ptr %l68, !tbaa !29
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load %"compiler/eval:Ptr", ptr %l8
  %t124 = load i32, ptr %l9, !tbaa !23
  %t128 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eobjectAt(ptr %v0, ptr %t122, %"compiler/eval:Ptr" %t123, i32 %t124)
  store %"compiler/eval:Ptr" %t128, ptr %l72
  br label %bb26
bb26:
  %t129 = load ptr, ptr %l68, !tbaa !29
  %t130 = load %"compiler/eval:Ptr", ptr %l72
  %t131 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eregionOfObject(ptr %v0, ptr %t129, %"compiler/eval:Ptr" %t130)
  store i64 %t131, ptr %l73
  br label %bb27
bb27:
  %t132 = load i64, ptr %l73, !tbaa !24
  store i64 %t132, ptr %l14, !tbaa !24
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/eval:Machine", ptr %t133, i32 0, i32 23
  %t136 = load i1, ptr %t135, !tbaa !21
  br i1 %t136, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store i64 0, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  %t139 = load i64, ptr %l14, !tbaa !24
  %t141 = icmp ne i64 %t139, 0
  br i1 %t141, label %bb31, label %bb32
bb31:
  %t143 = load i1, ptr %l4, !tbaa !21
  br i1 %t143, label %bb33, label %bb34
bb32:
  br label %bb37
bb33:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load i64, ptr %l14, !tbaa !24
  %t149 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eregionHomeOf(ptr %v0, ptr %t145, i64 %t146)
  store i64 %t149, ptr %l83
  br label %bb35
bb34:
  %t150 = load i64, ptr %l14, !tbaa !24
  store i64 %t150, ptr %l80, !tbaa !24
  br label %bb36
bb35:
  %t152 = load i64, ptr %l83, !tbaa !24
  store i64 %t152, ptr %l80, !tbaa !24
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t153 = load i64, ptr %l80, !tbaa !24
  store i64 %t153, ptr %rv
  br label %ret
bb37:
  call void @__olang_scope_close(ptr %s3)
  br label %bb38
bb38:
  %t154 = load i64, ptr %l6, !tbaa !24
  %t157 = add i64 %t154, 1
  store i64 %t157, ptr %l6, !tbaa !24
  br label %bb11
bb39:
  call void @__olang_scope_close(ptr %s0)
  store i64 0, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2eappendEscaped(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp eq i64 %t1, 10
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store i64 110, ptr %l5, !tbaa !24
  br label %bb31
bb4:
  %t5 = load i64, ptr %l2, !tbaa !24
  %t7 = icmp eq i64 %t5, 9
  br i1 %t7, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i64 116, ptr %l5, !tbaa !24
  br label %bb31
bb8:
  %t9 = load i64, ptr %l2, !tbaa !24
  %t11 = icmp eq i64 %t9, 13
  br i1 %t11, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i64 114, ptr %l5, !tbaa !24
  br label %bb31
bb12:
  %t13 = load i64, ptr %l2, !tbaa !24
  %t15 = icmp eq i64 %t13, 0
  br i1 %t15, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store i64 48, ptr %l5, !tbaa !24
  br label %bb31
bb16:
  %t17 = load i64, ptr %l2, !tbaa !24
  %t19 = icmp eq i64 %t17, 92
  br i1 %t19, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i64 92, ptr %l5, !tbaa !24
  br label %bb31
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb26
bb23:
  %t21 = load i64, ptr %l2, !tbaa !24
  %t25 = icmp eq i64 %t21, %a3
  br i1 %t25, label %bb24, label %bb25
bb24:
  %t27 = load i64, ptr %l2, !tbaa !24
  store i64 %t27, ptr %l5, !tbaa !24
  br label %bb31
bb25:
  br label %bb26
bb26:
  br i1 true, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  store i64 -1, ptr %l5, !tbaa !24
  br label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_317a6a00a16cca58_813a0e779d592254)
  unreachable
bb31:
  %t29 = load i64, ptr %l5, !tbaa !24
  store i64 %t29, ptr %l4, !tbaa !24
  %t30 = load i64, ptr %l4, !tbaa !24
  %t32 = icmp slt i64 %t30, 0
  br i1 %t32, label %bb32, label %bb33
bb32:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load i64, ptr %l1, !tbaa !24
  %t36 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eappendByte(ptr %v0, ptr %t34, i64 %t35, i64 %t36)
  br label %bb34
bb33:
  br label %bb35
bb34:
  br label %ret
bb35:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eappendByte(ptr %v0, ptr %t40, i64 %t41, i64 92)
  br label %bb36
bb36:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load i64, ptr %l1, !tbaa !24
  %t46 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eappendByte(ptr %v0, ptr %t44, i64 %t45, i64 %t46)
  br label %bb37
bb37:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2eappendText(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l14 = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a2, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb7
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t15, ptr %l14, !tbaa !27
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i8, ptr %t19, i64 %t16
  %t21 = load i8, ptr %t20, !tbaa !32
  %t27 = zext i8 %t21 to i64
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eappendByte(ptr %v0, ptr %a0, i64 %a1, i64 %t27)
  br label %bb5
bb5:
  br label %bb6
bb6:
  %t31 = load i64, ptr %l4, !tbaa !24
  %t34 = add i64 %t31, 1
  store i64 %t34, ptr %l4, !tbaa !24
  br label %bb1
bb7:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2ecallReturned(ptr %v0, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/eval:frame"
  %l2 = alloca i64
  %l3 = alloca %"compiler/mir:Call"
  %l4 = alloca i64
  %l5 = alloca { i64, [4 x i64] }
  %l6 = alloca i32
  %l7 = alloca i32
  %l13 = alloca ptr
  %l17 = alloca %"compiler/mir:Call"
  %l33 = alloca ptr
  %l37 = alloca ptr
  %l40 = alloca i32
  %l42 = alloca ptr
  %l46 = alloca i32
  %l47 = alloca i32
  %l55 = alloca i64
  %l56 = alloca ptr
  %l60 = alloca %"compiler/eval:Ptr"
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %a1, i64 136, i1 false)
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 60
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = sub i64 %t4, 1
  store i64 %t6, ptr %l2, !tbaa !24
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load i64, ptr %l2, !tbaa !24
  %t12 = call ptr @compiler_2feval_2ecompiler_2feval_3aMachine_2efnOfFrame(ptr %v0, ptr %v0, ptr %t8, i64 %t9)
  store ptr %t12, ptr %l13
  br label %bb1
bb1:
  %t13 = load ptr, ptr %l13, !tbaa !29
  %t15 = getelementptr %"compiler/mir:Fn", ptr %t13, i32 0, i32 14
  %t16 = getelementptr %"compiler/eval:frame", ptr %l1, i32 0, i32 8
  %t17 = load i64, ptr %t16, !tbaa !24
  %t20 = call %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %t15, i64 %t17)
  store %"compiler/mir:Call" %t20, ptr %l17
  br label %bb2
bb2:
  %t21 = load %"compiler/mir:Call", ptr %l17
  store %"compiler/mir:Call" %t21, ptr %l3
  %t22 = getelementptr %"compiler/eval:frame", ptr %l1, i32 0, i32 12
  %t23 = load i1, ptr %t22, !tbaa !21
  %t25 = xor i1 %t23, true
  br i1 %t25, label %bb3, label %bb4
bb3:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i64, ptr %l2, !tbaa !24
  %t29 = getelementptr %"compiler/mir:Call", ptr %l3, i32 0, i32 5
  %t30 = load i32, ptr %t29, !tbaa !23
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ejump(ptr %v0, ptr %t27, i64 %t28, i32 %t30)
  br label %bb5
bb4:
  br label %bb6
bb5:
  br label %ret
bb6:
  %t34 = getelementptr %"compiler/mir:Call", ptr %l3, i32 0, i32 7
  %t35 = load i32, ptr %t34, !tbaa !23
  %t36 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t39 = icmp eq i32 %t35, %t36
  br i1 %t39, label %bb7, label %bb8
bb7:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNotModelled, !tbaa !27
  %t43 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t43, ptr %t41, { i64, ptr } %t42)
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %ret
bb10:
  %t46 = getelementptr %"compiler/eval:frame", ptr %l1, i32 0, i32 13
  %t47 = load i64, ptr %t46, !tbaa !24
  store i64 %t47, ptr %l4, !tbaa !24
  %t49 = getelementptr %"compiler/mir:Call", ptr %l3, i32 0, i32 0
  %t50 = load { i64, [7 x i64] }, ptr %t49
  %t52 = extractvalue { i64, [7 x i64] } %t50, 0
  %t53 = icmp eq i64 %t52, 2
  br i1 %t53, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t55 = getelementptr %"compiler/mir:Call", ptr %l3, i32 0, i32 0
  %t56 = getelementptr { i64, [7 x i64] }, ptr %t55, i32 0, i32 1
  %t57 = getelementptr { { i64, [4 x i64] } }, ptr %t56, i32 0, i32 0
  %t58 = load { i64, [4 x i64] }, ptr %t57
  store { i64, [4 x i64] } %t58, ptr %l5
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/eval:Machine", ptr %t60, i32 0, i32 0
  %t63 = load ptr, ptr %t62, !tbaa !29
  store ptr %t63, ptr %l33, !tbaa !29
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/eval:Machine", ptr %t64, i32 0, i32 26
  %t67 = getelementptr %"compiler/eval:frame", ptr %l1, i32 0, i32 0
  %t68 = load i64, ptr %t67, !tbaa !24
  %t71 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_26_3e_2eAt_3ccompiler_2fmir_3aFn_26_3e(ptr %v0, ptr %s3, ptr %t66, i64 %t68)
  store ptr %t71, ptr %l37
  br label %bb13
bb12:
  br label %bb21
bb13:
  %t72 = load ptr, ptr %l37, !tbaa !29
  %t74 = getelementptr %"compiler/mir:Fn", ptr %t72, i32 0, i32 1
  %t75 = load i32, ptr %t74, !tbaa !23
  %t76 = load ptr, ptr %l33, !tbaa !29
  %t78 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t76, i32 %t75)
  store i32 %t78, ptr %l40
  br label %bb14
bb14:
  %t79 = load i32, ptr %l40, !tbaa !23
  store i32 %t79, ptr %l6, !tbaa !23
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/eval:Machine", ptr %t80, i32 0, i32 0
  %t83 = load ptr, ptr %t82, !tbaa !29
  store ptr %t83, ptr %l42, !tbaa !29
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load i64, ptr %l2, !tbaa !24
  %t86 = getelementptr %"compiler/mir:Call", ptr %l3, i32 0, i32 0
  %t87 = load { i64, [7 x i64] }, ptr %t86
  %t91 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2ecalleeType(ptr %v0, ptr %t84, i64 %t85, { i64, [7 x i64] } %t87)
  store i32 %t91, ptr %l46
  br label %bb15
bb15:
  %t92 = load ptr, ptr %l42, !tbaa !29
  %t93 = load i32, ptr %l46, !tbaa !23
  %t94 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t92, i32 %t93)
  store i32 %t94, ptr %l47
  br label %bb16
bb16:
  %t95 = load i32, ptr %l47, !tbaa !23
  store i32 %t95, ptr %l7, !tbaa !23
  %t96 = load i32, ptr %l6, !tbaa !23
  %t97 = load i32, ptr %l7, !tbaa !23
  %t100 = icmp ne i32 %t96, %t97
  br i1 %t100, label %bb17, label %bb18
bb17:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load i64, ptr %l4, !tbaa !24
  %t104 = load i32, ptr %l6, !tbaa !23
  %t105 = load i32, ptr %l7, !tbaa !23
  %t110 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erecode(ptr %v0, ptr %t102, i64 %t103, i32 %t104, i32 %t105)
  store i64 %t110, ptr %l55
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t111 = load i64, ptr %l55, !tbaa !24
  store i64 %t111, ptr %l4, !tbaa !24
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb21:
  %t112 = load ptr, ptr %l0, !tbaa !29
  store ptr %t112, ptr %l56, !tbaa !29
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load i64, ptr %l2, !tbaa !24
  %t115 = getelementptr %"compiler/mir:Call", ptr %l3, i32 0, i32 6
  %t116 = load i32, ptr %t115, !tbaa !23
  %t120 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2elocalPtr(ptr %v0, ptr %t113, i64 %t114, i32 %t116)
  store %"compiler/eval:Ptr" %t120, ptr %l60
  br label %bb22
bb22:
  %t121 = load i64, ptr %l4, !tbaa !24
  %t122 = load ptr, ptr %l56, !tbaa !29
  %t123 = load %"compiler/eval:Ptr", ptr %l60
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t122, %"compiler/eval:Ptr" %t123, i64 4, i64 %t121)
  br label %bb23
bb23:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load i64, ptr %l2, !tbaa !24
  %t127 = load i64, ptr @G_2ecompiler_2feval_2etCall, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2efailedHere(ptr %v0, ptr %t125, i64 %t126, i64 %t127)
  br label %bb24
bb24:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load i64, ptr %l2, !tbaa !24
  %t133 = getelementptr %"compiler/mir:Call", ptr %l3, i32 0, i32 7
  %t134 = load i32, ptr %t133, !tbaa !23
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ejump(ptr %v0, ptr %t131, i64 %t132, i32 %t134)
  br label %bb25
bb25:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2ecloseGen(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/eval:genRec"
  %l4 = alloca i64
  %l5 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i64
  %l14 = alloca %"compiler/eval:genRec"
  %l15 = alloca %"compiler/eval:genRec"
  %l16 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l24 = alloca i64
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca { i64, ptr }
  %l35 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i32
  %l44 = alloca ptr
  %l53 = alloca ptr
  %l54 = alloca i64
  %l55 = alloca %"compiler/eval:genRec"
  %l57 = alloca %"compiler/eval:genRec"
  %l64 = alloca ptr
  %l70 = alloca i64
  %l74 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %t5 = alloca %"compiler/eval:genRec", align 8
  %t152 = alloca %"compiler/eval:genRec", align 8
  %t156 = alloca %"compiler/eval:genRec", align 8
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 64
  %t4 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3agenRec_3e_2eAt_3ccompiler_2feval_3agenRec_3e(ptr %t5, ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  call void @llvm.memmove.p0.p0.i64(ptr %l14, ptr %t5, i64 280, i1 false)
  br label %bb1
bb1:
  call void @llvm.memmove.p0.p0.i64(ptr %l15, ptr %l14, i64 280, i1 false)
  %t8 = call ptr @__olang_scope_hold(ptr %s0)
  %t9 = ptrtoint ptr %t8 to i64
  store i64 %t9, ptr %l16, !tbaa !24
  %t10 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = call ptr @__olang_region_make_part(ptr %s0)
  %t13 = ptrtoint ptr %t12 to i64
  store i64 %t13, ptr %l16, !tbaa !24
  br label %bb3
bb3:
  %t14 = getelementptr %"compiler/eval:genRec", ptr %l15, i32 0, i32 6
  %t15 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t14, i32 0, i32 0
  %t16 = load { i64, ptr }, ptr %t15, !tbaa !27
  store { i64, ptr } %t16, ptr %l18, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t17, 0
  store i64 %t18, ptr %l19, !tbaa !24
  %t19 = load i64, ptr %l19, !tbaa !24
  %t20 = mul i64 %t19, 8
  %t21 = load i64, ptr %l16
  %t22 = inttoptr i64 %t21 to ptr
  %t23 = call ptr @__olang_held_alloc(ptr %t22, i64 %t20)
  %t24 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  store { i64, ptr } %t25, ptr %l20, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = load i64, ptr %l19, !tbaa !24
  %t31 = mul i64 %t30, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t27, ptr %t29, i64 %t31, i1 false)
  %t32 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t33 = getelementptr %"compiler/eval:genRec", ptr %l15, i32 0, i32 6
  %t34 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t33, i32 0, i32 0
  store { i64, ptr } %t32, ptr %t34, !tbaa !27
  %t35 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t35, label %bb4, label %bb5
bb4:
  %t37 = getelementptr %"compiler/eval:genRec", ptr %l15, i32 0, i32 6
  %t38 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t37, i32 0, i32 0
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  %t42 = icmp eq i64 %t40, 0
  br i1 %t42, label %bb6, label %bb7
bb5:
  %t44 = call ptr @__olang_scope_hold(ptr %s0)
  %t45 = ptrtoint ptr %t44 to i64
  store i64 %t45, ptr %l24, !tbaa !24
  %t46 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t46, label %bb8, label %bb9
bb6:
  %t48 = getelementptr %"compiler/eval:genRec", ptr %l15, i32 0, i32 6
  %t49 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t49, !tbaa !27
  br label %bb7
bb7:
  %t50 = getelementptr %"compiler/eval:genRec", ptr %l15, i32 0, i32 6
  %t51 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t50, i32 0, i32 0
  %t52 = load i64, ptr %l16
  %t53 = inttoptr i64 %t52 to ptr
  %t54 = load { i64, ptr }, ptr %t51
  %t55 = extractvalue { i64, ptr } %t54, 1
  %t56 = call ptr @__olang_region_or(ptr %t55, ptr null)
  %t57 = icmp ne ptr %t56, null
  %t58 = select i1 %t57, ptr %t56, ptr null
  call void @__olang_region_settle_in(ptr %t53, ptr %t58)
  br label %bb5
bb8:
  %t59 = call ptr @__olang_region_make_part(ptr %s0)
  %t60 = ptrtoint ptr %t59 to i64
  store i64 %t60, ptr %l24, !tbaa !24
  br label %bb9
bb9:
  %t61 = getelementptr %"compiler/eval:genRec", ptr %l15, i32 0, i32 7
  %t62 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t61, i32 0, i32 0
  %t63 = load { i64, ptr }, ptr %t62, !tbaa !27
  store { i64, ptr } %t63, ptr %l26, !tbaa !27
  %t64 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l27, !tbaa !24
  %t66 = load i64, ptr %l27, !tbaa !24
  %t67 = mul i64 %t66, 8
  %t68 = load i64, ptr %l24
  %t69 = inttoptr i64 %t68 to ptr
  %t70 = call ptr @__olang_held_alloc(ptr %t69, i64 %t67)
  %t71 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t70, 1
  store { i64, ptr } %t72, ptr %l28, !tbaa !27
  %t73 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l27, !tbaa !24
  %t78 = mul i64 %t77, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t74, ptr %t76, i64 %t78, i1 false)
  %t79 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t80 = getelementptr %"compiler/eval:genRec", ptr %l15, i32 0, i32 7
  %t81 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t80, i32 0, i32 0
  store { i64, ptr } %t79, ptr %t81, !tbaa !27
  %t82 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t82, label %bb10, label %bb11
bb10:
  %t84 = getelementptr %"compiler/eval:genRec", ptr %l15, i32 0, i32 7
  %t85 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t84, i32 0, i32 0
  %t86 = load { i64, ptr }, ptr %t85, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t86, 0
  %t89 = icmp eq i64 %t87, 0
  br i1 %t89, label %bb12, label %bb13
bb11:
  call void @llvm.memmove.p0.p0.i64(ptr %l3, ptr %l15, i64 280, i1 false)
  %t91 = getelementptr %"compiler/eval:genRec", ptr %l3, i32 0, i32 0
  %t92 = load i64, ptr %t91, !tbaa !24
  %t94 = icmp ne i64 %t92, 2
  br i1 %t94, label %bb14, label %bb15
bb12:
  %t96 = getelementptr %"compiler/eval:genRec", ptr %l15, i32 0, i32 7
  %t97 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t96, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t97, !tbaa !27
  br label %bb13
bb13:
  %t98 = getelementptr %"compiler/eval:genRec", ptr %l15, i32 0, i32 7
  %t99 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t98, i32 0, i32 0
  %t100 = load i64, ptr %l24
  %t101 = inttoptr i64 %t100 to ptr
  %t102 = load { i64, ptr }, ptr %t99
  %t103 = extractvalue { i64, ptr } %t102, 1
  %t104 = call ptr @__olang_region_or(ptr %t103, ptr null)
  %t105 = icmp ne ptr %t104, null
  %t106 = select i1 %t105, ptr %t104, ptr null
  call void @__olang_region_settle_in(ptr %t101, ptr %t106)
  br label %bb11
bb14:
  %t107 = load i64, ptr %l2, !tbaa !24
  store i64 %t107, ptr %l4, !tbaa !24
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/eval:Machine", ptr %t109, i32 0, i32 65
  %t112 = getelementptr %"compiler/eval:genRec", ptr %l3, i32 0, i32 1
  %t113 = load i64, ptr %t112, !tbaa !24
  %t116 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t111, i64 %t113)
  %t117 = extractvalue { i32, i64 } %t116, 1
  %t118 = extractvalue { i32, i64 } %t116, 0
  store i32 %t118, ptr %l40
  %t119 = icmp ne i32 %t118, 0
  br i1 %t119, label %bb17, label %ok.120, !prof !99
ok.120:
  store i64 %t117, ptr %l39
  br label %bb16
bb15:
  br label %bb22
bb16:
  %t121 = load i64, ptr %l39, !tbaa !24
  store i64 %t121, ptr %l35, !tbaa !24
  br label %bb19
bb17:
  br label %bb18
bb18:
  store i64 -1, ptr %l35, !tbaa !24
  br label %bb19
bb19:
  %t122 = load i64, ptr %l35, !tbaa !24
  store i64 %t122, ptr %l5, !tbaa !24
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/eval:Machine", ptr %t123, i32 0, i32 64
  %t126 = load i64, ptr %l4, !tbaa !24
  %t129 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3agenRec_3e_2eRefMut_3ccompiler_2feval_3agenRec_3e(ptr %v0, ptr %v0, ptr %t125, i64 %t126)
  store ptr %t129, ptr %l44
  br label %bb20
bb20:
  %t130 = load ptr, ptr %l44, !tbaa !29
  %t132 = load i64, ptr %l5, !tbaa !24
  %t135 = getelementptr %"compiler/eval:genRec", ptr %t130, i32 0, i32 11
  store i64 %t132, ptr %t135, !tbaa !24
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/eval:Machine", ptr %t136, i32 0, i32 65
  %t139 = getelementptr %"compiler/eval:genRec", ptr %l3, i32 0, i32 1
  %t140 = load i64, ptr %t139, !tbaa !24
  %t141 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t138, i64 %t140, i64 %t141)
  br label %bb21
bb21:
  br label %bb22
bb22:
  %t145 = getelementptr %"compiler/eval:genRec", ptr %l3, i32 0, i32 0
  %t146 = load i64, ptr %t145, !tbaa !24
  %t148 = icmp eq i64 %t146, 0
  br i1 %t148, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s2
  %t150 = load ptr, ptr %l0, !tbaa !29
  store ptr %t150, ptr %l53, !tbaa !29
  store i64 %a1, ptr %l54, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l55, ptr %l3, i64 280, i1 false)
  call void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feval_3agenRec(ptr %t152, ptr %s2, ptr %l55)
  call void @llvm.memmove.p0.p0.i64(ptr %l57, ptr %t152, i64 280, i1 false)
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t154 = load ptr, ptr %l53, !tbaa !29
  %t155 = load i64, ptr %l54, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %t156, ptr %l57, i64 280, i1 false)
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2efreshDrops(ptr %v0, ptr %s2, ptr %t154, i64 %t155, ptr %t156)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s2)
  br label %bb27
bb27:
  %t157 = getelementptr %"compiler/eval:genRec", ptr %l3, i32 0, i32 0
  %t158 = load i64, ptr %t157, !tbaa !24
  %t160 = icmp ne i64 %t158, 1
  br i1 %t160, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb29:
  br label %bb30
bb30:
  %t162 = load i64, ptr %l2, !tbaa !24
  store i64 3, ptr %l8, !tbaa !24
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/eval:Machine", ptr %t164, i32 0, i32 64
  %t170 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3agenRec_3e_2eRefMut_3ccompiler_2feval_3agenRec_3e(ptr %v0, ptr %v0, ptr %t166, i64 %t162)
  store ptr %t170, ptr %l64
  br label %bb31
bb31:
  %t171 = load ptr, ptr %l64, !tbaa !29
  %t173 = load i64, ptr %l8, !tbaa !24
  %t176 = getelementptr %"compiler/eval:genRec", ptr %t171, i32 0, i32 0
  store i64 %t173, ptr %t176, !tbaa !24
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t178 = load i64, ptr %l2, !tbaa !24
  %t179 = load i64, ptr @G_2ecompiler_2feval_2erDtor, !tbaa !24
  %t183 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erestoreGen(ptr %v0, ptr %t177, i64 %t178, i64 %t179, i64 0)
  store i64 %t183, ptr %l70
  br label %bb32
bb32:
  %t184 = load i64, ptr %l70, !tbaa !24
  store i64 %t184, ptr %l10, !tbaa !24
  %t185 = load i64, ptr %l10, !tbaa !24
  %t187 = icmp slt i64 %t185, 0
  br i1 %t187, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb34:
  br label %bb35
bb35:
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"compiler/eval:Machine", ptr %t189, i32 0, i32 59
  %t192 = load { i64, ptr }, ptr %t191, !tbaa !27
  store { i64, ptr } %t192, ptr %l74, !tbaa !27
  %t193 = load i64, ptr %l10, !tbaa !24
  %t194 = getelementptr %"compiler/eval:genRec", ptr %l3, i32 0, i32 3
  %t195 = load i64, ptr %t194, !tbaa !24
  %t198 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t199 = load ptr, ptr %t198, !tbaa !27
  %t200 = getelementptr %"compiler/eval:frame", ptr %t199, i64 %t193
  %t201 = getelementptr %"compiler/eval:frame", ptr %t200, i32 0, i32 1
  store i64 %t195, ptr %t201, !tbaa !24
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t204 = getelementptr %"compiler/eval:Machine", ptr %t202, i32 0, i32 59
  %t205 = load { i64, ptr }, ptr %t204, !tbaa !27
  store { i64, ptr } %t205, ptr %l78, !tbaa !27
  %t206 = load i64, ptr %l10, !tbaa !24
  %t208 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !27
  %t210 = getelementptr %"compiler/eval:frame", ptr %t209, i64 %t206
  %t211 = getelementptr %"compiler/eval:frame", ptr %t210, i32 0, i32 2
  store i64 0, ptr %t211, !tbaa !24
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = getelementptr %"compiler/eval:Machine", ptr %t212, i32 0, i32 59
  %t215 = load { i64, ptr }, ptr %t214, !tbaa !27
  store { i64, ptr } %t215, ptr %l81, !tbaa !27
  %t216 = load i64, ptr %l10, !tbaa !24
  %t218 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t219 = load ptr, ptr %t218, !tbaa !27
  %t220 = getelementptr %"compiler/eval:frame", ptr %t219, i64 %t216
  %t221 = getelementptr %"compiler/eval:frame", ptr %t220, i32 0, i32 18
  store i32 -1, ptr %t221, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2eclosure(ptr %v0, ptr %a0, i64 %a1, %"compiler/eval:Ptr" %a2, { i64, [2 x i64] } %a3, { i64, [1 x i64] } %a4, %"compiler/mir:Range" %a5, %"compiler/mir:Range" %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/eval:Ptr"
  %l3 = alloca { i64, [2 x i64] }
  %l4 = alloca { i64, [1 x i64] }
  %l5 = alloca %"compiler/mir:Range"
  %l7 = alloca %"compiler/eval:Ptr"
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca { { i64, ptr }, i64 }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca %"compiler/eval:Ptr"
  %l22 = alloca i32
  %l23 = alloca i32
  %l24 = alloca i32
  %l25 = alloca i32
  %l26 = alloca i32
  %l27 = alloca i32
  %l28 = alloca { i64, [4 x i64] }
  %l29 = alloca i64
  %l30 = alloca %"compiler/eval:Ptr"
  %l33 = alloca %"compiler/eval:Ptr"
  %l36 = alloca i64
  %l39 = alloca i1
  %l43 = alloca ptr
  %l58 = alloca ptr
  %l62 = alloca %"compiler/eval:Ptr"
  %l66 = alloca ptr
  %l68 = alloca i64
  %l76 = alloca i32
  %l79 = alloca i32
  %l97 = alloca i32
  %l98 = alloca ptr
  %l99 = alloca i64
  %l107 = alloca { i64, [4 x i64] }
  %l108 = alloca i32
  %l114 = alloca { { i64, ptr }, i64 }
  %l120 = alloca i64
  %l131 = alloca %"compiler/eval:Ptr"
  %l136 = alloca i32
  %l139 = alloca i32
  %l164 = alloca { i64, [4 x i64] }
  %l165 = alloca ptr
  %l166 = alloca i64
  %l170 = alloca %"compiler/eval:Ptr"
  %l178 = alloca i64
  %l181 = alloca i1
  %l185 = alloca i64
  %l188 = alloca ptr
  %l189 = alloca i64
  %l191 = alloca i64
  %l195 = alloca i64
  %l198 = alloca i64
  %l200 = alloca %"compiler/eval:Ptr"
  %l201 = alloca %"compiler/eval:Ptr"
  %l205 = alloca { i64, ptr }
  %l210 = alloca ptr
  %l217 = alloca %"compiler/eval:Ptr"
  %l224 = alloca ptr
  %l225 = alloca i64
  %l226 = alloca %"compiler/eval:Ptr"
  %l227 = alloca i64
  %l231 = alloca ptr
  %l236 = alloca ptr
  %l240 = alloca %"compiler/eval:Ptr"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/eval:Ptr" %a2, ptr %l2
  store { i64, [2 x i64] } %a3, ptr %l3
  store { i64, [1 x i64] } %a4, ptr %l4
  store %"compiler/mir:Range" %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load { i64, [2 x i64] }, ptr %l3
  %t5 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2ecodePtr(ptr %v0, ptr %t1, { i64, [2 x i64] } %t2)
  store %"compiler/eval:Ptr" %t5, ptr %l33
  br label %bb1
bb1:
  %t6 = load %"compiler/eval:Ptr", ptr %l33
  store %"compiler/eval:Ptr" %t6, ptr %l7
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load { i64, [2 x i64] }, ptr %l3
  %t11 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2efnIndex(ptr %v0, ptr %t7, { i64, [2 x i64] } %t8)
  store i64 %t11, ptr %l36
  br label %bb2
bb2:
  %t12 = load i64, ptr %l36, !tbaa !24
  store i64 %t12, ptr %l8, !tbaa !24
  %t13 = load i64, ptr %l8, !tbaa !24
  %t15 = icmp sge i64 %t13, 0
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/eval:Machine", ptr %t17, i32 0, i32 26
  %t20 = load i64, ptr %l8, !tbaa !24
  %t23 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_26_3e_2eAt_3ccompiler_2fmir_3aFn_26_3e(ptr %v0, ptr %s0, ptr %t19, i64 %t20)
  store ptr %t23, ptr %l43
  br label %bb5
bb4:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb6
bb5:
  %t24 = load ptr, ptr %l43, !tbaa !29
  %t26 = getelementptr %"compiler/mir:Fn", ptr %t24, i32 0, i32 25
  %t27 = load i1, ptr %t26, !tbaa !21
  store i1 %t27, ptr %l39, !tbaa !21
  br label %bb6
bb6:
  %t29 = load i1, ptr %l39, !tbaa !21
  br i1 %t29, label %bb7, label %bb8
bb7:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load i64, ptr %l1, !tbaa !24
  %t32 = load %"compiler/eval:Ptr", ptr %l2
  %t33 = load %"compiler/eval:Ptr", ptr %l7
  %t34 = load i64, ptr %l8, !tbaa !24
  %t35 = load { i64, [1 x i64] }, ptr %l4
  %t36 = load %"compiler/mir:Range", ptr %l5
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2egenClosure(ptr %v0, ptr %t30, i64 %t31, %"compiler/eval:Ptr" %t32, %"compiler/eval:Ptr" %t33, i64 %t34, { i64, [1 x i64] } %t35, %"compiler/mir:Range" %t36)
  br label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb10:
  %t44 = getelementptr %"compiler/mir:Range", ptr %l5, i32 0, i32 1
  %t45 = load i32, ptr %t44, !tbaa !23
  %t47 = icmp eq i32 %t45, 0
  br i1 %t47, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load %"compiler/eval:Ptr", ptr %l2
  %t51 = load %"compiler/eval:Ptr", ptr %l7
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrPtr(ptr %v0, ptr %t49, %"compiler/eval:Ptr" %t50, %"compiler/eval:Ptr" %t51)
  br label %bb13
bb12:
  br label %bb16
bb13:
  %t55 = load ptr, ptr %l0, !tbaa !29
  store ptr %t55, ptr %l58, !tbaa !29
  %t56 = getelementptr %"compiler/eval:Ptr", ptr %l2, i32 0, i32 0
  %t57 = load i64, ptr %t56, !tbaa !24
  %t58 = getelementptr %"compiler/eval:Ptr", ptr %l2, i32 0, i32 1
  %t59 = load i64, ptr %t58, !tbaa !24
  %t61 = add i64 %t59, 8
  %t64 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s2, i64 %t57, i64 %t61)
  store %"compiler/eval:Ptr" %t64, ptr %l62
  br label %bb14
bb14:
  %t65 = load %"compiler/eval:Ptr", ptr @G_2ecompiler_2feval_2eNullPtr
  %t66 = load ptr, ptr %l58, !tbaa !29
  %t67 = load %"compiler/eval:Ptr", ptr %l62
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrPtr(ptr %v0, ptr %t66, %"compiler/eval:Ptr" %t67, %"compiler/eval:Ptr" %t65)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb16:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load i64, ptr %l1, !tbaa !24
  %t73 = call ptr @compiler_2feval_2ecompiler_2feval_3aMachine_2efnOfFrame(ptr %v0, ptr %v0, ptr %t69, i64 %t70)
  store ptr %t73, ptr %l66
  br label %bb17
bb17:
  %t74 = load ptr, ptr %l66, !tbaa !29
  store ptr %t74, ptr %l9, !tbaa !29
  %t75 = getelementptr %"compiler/mir:Range", ptr %l5, i32 0, i32 1
  %t76 = load i32, ptr %t75, !tbaa !23
  %t78 = sext i32 %t76 to i64
  store i64 %t78, ptr %l68, !tbaa !24
  %t79 = load i64, ptr %l68, !tbaa !24
  %t80 = icmp sge i64 %t79, 0
  br i1 %t80, label %bb18, label %bb19
bb18:
  %t82 = load i64, ptr %l68, !tbaa !24
  %t83 = icmp sle i64 %t82, 2305843009213693951
  br i1 %t83, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_858a31b75d933e1b_7873e096df41decf)
  unreachable
bb20:
  %t85 = load i64, ptr %l68, !tbaa !24
  %t86 = mul i64 %t85, 4
  %t87 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t86)
  %t88 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t87, 1
  store { i64, ptr } %t89, ptr %l10, !tbaa !27
  store i32 0, ptr %l11, !tbaa !23
  %t91 = getelementptr %"compiler/mir:Range", ptr %l5, i32 0, i32 1
  %t92 = load i32, ptr %t91, !tbaa !23
  store i32 %t92, ptr %l12, !tbaa !23
  store i32 1, ptr %l13, !tbaa !23
  %t94 = load i32, ptr %l12, !tbaa !23
  %t95 = load i32, ptr %l11, !tbaa !23
  %t98 = icmp sgt i32 %t94, %t95
  br i1 %t98, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_858a31b75d933e1b_7873e096df41decf)
  unreachable
bb22:
  %t100 = load i32, ptr %l13, !tbaa !23
  %t102 = icmp sgt i32 %t100, 0
  br i1 %t102, label %bb24, label %bb25
bb23:
  store i32 0, ptr %l76, !tbaa !23
  br label %bb27
bb24:
  %t104 = load i32, ptr %l12, !tbaa !23
  %t105 = load i32, ptr %l11, !tbaa !23
  %t108 = sub i32 %t104, %t105
  %t109 = load i32, ptr %l13, !tbaa !23
  %t112 = add i32 %t108, %t109
  %t114 = sub i32 %t112, 1
  %t115 = load i32, ptr %l13, !tbaa !23
  %t118 = sdiv i32 %t114, %t115
  store i32 %t118, ptr %l79, !tbaa !23
  br label %bb26
bb25:
  store i32 0, ptr %l79, !tbaa !23
  br label %bb26
bb26:
  %t120 = load i32, ptr %l79, !tbaa !23
  store i32 %t120, ptr %l76, !tbaa !23
  br label %bb27
bb27:
  %t121 = load i32, ptr %l76, !tbaa !23
  store i32 %t121, ptr %l14, !tbaa !23
  store i32 0, ptr %l15, !tbaa !23
  br label %bb28
bb28:
  %t122 = load i32, ptr %l15, !tbaa !23
  %t123 = load i32, ptr %l14, !tbaa !23
  %t126 = icmp slt i32 %t122, %t123
  %t128 = xor i1 %t126, true
  br i1 %t128, label %bb29, label %bb30
bb29:
  br label %bb35
bb30:
  br label %bb31
bb31:
  %t130 = load i32, ptr %l11, !tbaa !23
  %t131 = load i32, ptr %l15, !tbaa !23
  %t132 = load i32, ptr %l13, !tbaa !23
  %t135 = mul i32 %t131, %t132
  %t138 = add i32 %t130, %t135
  store i32 %t138, ptr %l16, !tbaa !23
  %t140 = load i32, ptr %l16, !tbaa !23
  store i32 %t140, ptr %l97, !tbaa !23
  %t141 = load ptr, ptr %l0, !tbaa !29
  store ptr %t141, ptr %l98, !tbaa !29
  %t142 = load i64, ptr %l1, !tbaa !24
  store i64 %t142, ptr %l99, !tbaa !24
  %t143 = load ptr, ptr %l9, !tbaa !29
  %t145 = getelementptr %"compiler/mir:Fn", ptr %t143, i32 0, i32 11
  %t146 = getelementptr %"compiler/mir:Range", ptr %l5, i32 0, i32 0
  %t147 = load i32, ptr %t146, !tbaa !23
  %t149 = sext i32 %t147 to i64
  %t150 = load i32, ptr %l16, !tbaa !23
  %t152 = sext i32 %t150 to i64
  %t155 = add i64 %t149, %t152
  %t158 = call { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %t145, i64 %t155)
  store { i64, [4 x i64] } %t158, ptr %l107
  br label %bb32
bb32:
  %t159 = load ptr, ptr %l98, !tbaa !29
  %t160 = load i64, ptr %l99, !tbaa !24
  %t161 = load { i64, [4 x i64] }, ptr %l107
  %t162 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eopType(ptr %v0, ptr %t159, i64 %t160, { i64, [4 x i64] } %t161)
  store i32 %t162, ptr %l108
  br label %bb33
bb33:
  %t163 = load i32, ptr %l108, !tbaa !23
  %t164 = load i32, ptr %l97, !tbaa !23
  %t165 = sext i32 %t164 to i64
  %t166 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !27
  %t168 = getelementptr i32, ptr %t167, i64 %t165
  store i32 %t163, ptr %t168, !tbaa !33
  br label %bb34
bb34:
  %t169 = load i32, ptr %l15, !tbaa !23
  %t172 = add i32 %t169, 1
  store i32 %t172, ptr %l15, !tbaa !23
  br label %bb28
bb35:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t178 = call { { i64, ptr }, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2epack(ptr %v0, ptr %s0, ptr %s0, ptr %t174, { i64, ptr } %t175)
  store { { i64, ptr }, i64 } %t178, ptr %l114
  br label %bb36
bb36:
  %t179 = load { { i64, ptr }, i64 }, ptr %l114
  store { { i64, ptr }, i64 } %t179, ptr %l17
  %t180 = getelementptr { { i64, ptr }, i64 }, ptr %l17, i32 0, i32 0
  %t181 = load { i64, ptr }, ptr %t180, !tbaa !27
  store { i64, ptr } %t181, ptr %l18, !tbaa !27
  %t183 = getelementptr { { i64, ptr }, i64 }, ptr %l17, i32 0, i32 1
  %t184 = load i64, ptr %t183, !tbaa !24
  store i64 %t184, ptr %l19, !tbaa !24
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t187 = load i64, ptr %l1, !tbaa !24
  %t188 = load { i64, [1 x i64] }, ptr %l4
  %t192 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ebuildScope(ptr %v0, ptr %t186, i64 %t187, { i64, [1 x i64] } %t188)
  store i64 %t192, ptr %l120
  br label %bb37
bb37:
  %t193 = load i64, ptr %l120, !tbaa !24
  store i64 %t193, ptr %l20, !tbaa !24
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr %"compiler/eval:Machine", ptr %t194, i32 0, i32 23
  %t197 = load i1, ptr %t196, !tbaa !21
  br i1 %t197, label %bb38, label %bb39
bb38:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb39:
  br label %bb40
bb40:
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t200 = load i64, ptr %l19, !tbaa !24
  %t201 = getelementptr %"compiler/mir:Range", ptr %l5, i32 0, i32 1
  %t202 = load i32, ptr %t201, !tbaa !23
  %t204 = sext i32 %t202 to i64
  %t206 = mul i64 8, %t204
  %t209 = add i64 %t200, %t206
  %t210 = load i64, ptr @G_2ecompiler_2feval_2eaValue, !tbaa !24
  %t211 = load i64, ptr %l20, !tbaa !24
  %t216 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eallocate(ptr %v0, ptr %t199, i64 %t209, i64 %t210, i64 %t211)
  store %"compiler/eval:Ptr" %t216, ptr %l131
  br label %bb41
bb41:
  %t217 = load %"compiler/eval:Ptr", ptr %l131
  store %"compiler/eval:Ptr" %t217, ptr %l21
  store i32 0, ptr %l22, !tbaa !23
  %t218 = getelementptr %"compiler/mir:Range", ptr %l5, i32 0, i32 1
  %t219 = load i32, ptr %t218, !tbaa !23
  store i32 %t219, ptr %l23, !tbaa !23
  store i32 1, ptr %l24, !tbaa !23
  %t221 = load i32, ptr %l23, !tbaa !23
  %t222 = load i32, ptr %l22, !tbaa !23
  %t225 = icmp sgt i32 %t221, %t222
  br i1 %t225, label %bb42, label %bb43
bb42:
  %t227 = load i32, ptr %l24, !tbaa !23
  %t229 = icmp sgt i32 %t227, 0
  br i1 %t229, label %bb44, label %bb45
bb43:
  store i32 0, ptr %l136, !tbaa !23
  br label %bb47
bb44:
  %t231 = load i32, ptr %l23, !tbaa !23
  %t232 = load i32, ptr %l22, !tbaa !23
  %t235 = sub i32 %t231, %t232
  %t236 = load i32, ptr %l24, !tbaa !23
  %t239 = add i32 %t235, %t236
  %t241 = sub i32 %t239, 1
  %t242 = load i32, ptr %l24, !tbaa !23
  %t245 = sdiv i32 %t241, %t242
  store i32 %t245, ptr %l139, !tbaa !23
  br label %bb46
bb45:
  store i32 0, ptr %l139, !tbaa !23
  br label %bb46
bb46:
  %t247 = load i32, ptr %l139, !tbaa !23
  store i32 %t247, ptr %l136, !tbaa !23
  br label %bb47
bb47:
  %t248 = load i32, ptr %l136, !tbaa !23
  store i32 %t248, ptr %l25, !tbaa !23
  store i32 0, ptr %l26, !tbaa !23
  br label %bb48
bb48:
  store %olang.scope zeroinitializer, ptr %s8
  %t249 = load i32, ptr %l26, !tbaa !23
  %t250 = load i32, ptr %l25, !tbaa !23
  %t253 = icmp slt i32 %t249, %t250
  %t255 = xor i1 %t253, true
  br i1 %t255, label %bb49, label %bb50
bb49:
  call void @__olang_scope_close(ptr %s8)
  br label %bb75
bb50:
  br label %bb51
bb51:
  %t257 = load i32, ptr %l22, !tbaa !23
  %t258 = load i32, ptr %l26, !tbaa !23
  %t259 = load i32, ptr %l24, !tbaa !23
  %t262 = mul i32 %t258, %t259
  %t265 = add i32 %t257, %t262
  store i32 %t265, ptr %l27, !tbaa !23
  %t267 = load ptr, ptr %l9, !tbaa !29
  %t269 = getelementptr %"compiler/mir:Fn", ptr %t267, i32 0, i32 11
  %t270 = getelementptr %"compiler/mir:Range", ptr %l5, i32 0, i32 0
  %t271 = load i32, ptr %t270, !tbaa !23
  %t273 = sext i32 %t271 to i64
  %t274 = load i32, ptr %l27, !tbaa !23
  %t276 = sext i32 %t274 to i64
  %t279 = add i64 %t273, %t276
  %t282 = call { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %t269, i64 %t279)
  store { i64, [4 x i64] } %t282, ptr %l164
  br label %bb52
bb52:
  %t283 = load { i64, [4 x i64] }, ptr %l164
  store { i64, [4 x i64] } %t283, ptr %l28
  %t284 = load ptr, ptr %l0, !tbaa !29
  store ptr %t284, ptr %l165, !tbaa !29
  %t285 = load i64, ptr %l1, !tbaa !24
  store i64 %t285, ptr %l166, !tbaa !24
  %t286 = getelementptr %"compiler/eval:Ptr", ptr %l21, i32 0, i32 0
  %t287 = load i64, ptr %t286, !tbaa !24
  %t288 = load i32, ptr %l27, !tbaa !23
  %t290 = sext i32 %t288 to i64
  %t291 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t292 = load ptr, ptr %t291, !tbaa !27
  %t293 = getelementptr i64, ptr %t292, i64 %t290
  %t294 = load i64, ptr %t293, !tbaa !34
  %t297 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s8, i64 %t287, i64 %t294)
  store %"compiler/eval:Ptr" %t297, ptr %l170
  br label %bb53
bb53:
  %t298 = load i32, ptr %l27, !tbaa !23
  %t300 = sext i32 %t298 to i64
  %t301 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t302 = load ptr, ptr %t301, !tbaa !27
  %t303 = getelementptr i32, ptr %t302, i64 %t300
  %t304 = load i32, ptr %t303, !tbaa !33
  %t305 = load { i64, [4 x i64] }, ptr %l28
  %t306 = load ptr, ptr %l165, !tbaa !29
  %t307 = load i64, ptr %l166, !tbaa !24
  %t308 = load %"compiler/eval:Ptr", ptr %l170
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eput(ptr %v0, ptr %t306, i64 %t307, %"compiler/eval:Ptr" %t308, i32 %t304, { i64, [4 x i64] } %t305)
  br label %bb54
bb54:
  %t311 = load i64, ptr %l20, !tbaa !24
  store i64 %t311, ptr %l29, !tbaa !24
  %t313 = load ptr, ptr %l0, !tbaa !29
  %t314 = load i32, ptr %l27, !tbaa !23
  %t316 = sext i32 %t314 to i64
  %t317 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t318 = load ptr, ptr %t317, !tbaa !27
  %t319 = getelementptr i32, ptr %t318, i64 %t316
  %t320 = load i32, ptr %t319, !tbaa !33
  %t323 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t313, i32 %t320)
  store i64 %t323, ptr %l178
  br label %bb55
bb55:
  %t324 = load i64, ptr @G_2ecompiler_2feval_2evPtr, !tbaa !24
  %t325 = load i64, ptr %l178, !tbaa !24
  %t327 = icmp eq i64 %t325, %t324
  br i1 %t327, label %bb56, label %bb57
bb56:
  store i1 true, ptr %l181, !tbaa !21
  br label %bb59
bb57:
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t330 = load i32, ptr %l27, !tbaa !23
  %t332 = sext i32 %t330 to i64
  %t333 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t334 = load ptr, ptr %t333, !tbaa !27
  %t335 = getelementptr i32, ptr %t334, i64 %t332
  %t336 = load i32, ptr %t335, !tbaa !33
  %t339 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t329, i32 %t336)
  store i64 %t339, ptr %l185
  br label %bb58
bb58:
  %t340 = load i64, ptr @G_2ecompiler_2feval_2evPair, !tbaa !24
  %t341 = load i64, ptr %l185, !tbaa !24
  %t343 = icmp eq i64 %t341, %t340
  store i1 %t343, ptr %l181, !tbaa !21
  br label %bb59
bb59:
  %t345 = load i1, ptr %l181, !tbaa !21
  br i1 %t345, label %bb60, label %bb61
bb60:
  store %olang.scope zeroinitializer, ptr %s9
  %t346 = load ptr, ptr %l0, !tbaa !29
  store ptr %t346, ptr %l188, !tbaa !29
  %t347 = getelementptr %"compiler/eval:Ptr", ptr %l21, i32 0, i32 0
  %t348 = load i64, ptr %t347, !tbaa !24
  store i64 %t348, ptr %l189, !tbaa !24
  %t349 = load i32, ptr %l27, !tbaa !23
  %t351 = sext i32 %t349 to i64
  %t352 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t353 = load ptr, ptr %t352, !tbaa !27
  %t354 = getelementptr i64, ptr %t353, i64 %t351
  %t355 = load i64, ptr %t354, !tbaa !34
  store i64 %t355, ptr %l191, !tbaa !24
  %t356 = load ptr, ptr %l0, !tbaa !29
  %t357 = load i32, ptr %l27, !tbaa !23
  %t359 = sext i32 %t357 to i64
  %t360 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t361 = load ptr, ptr %t360, !tbaa !27
  %t362 = getelementptr i32, ptr %t361, i64 %t359
  %t363 = load i32, ptr %t362, !tbaa !33
  %t366 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t356, i32 %t363)
  store i64 %t366, ptr %l195
  br label %bb62
bb61:
  br label %bb71
bb62:
  %t367 = load i64, ptr @G_2ecompiler_2feval_2evPair, !tbaa !24
  %t368 = load i64, ptr %l195, !tbaa !24
  %t370 = icmp eq i64 %t368, %t367
  br i1 %t370, label %bb63, label %bb64
bb63:
  store i64 8, ptr %l198, !tbaa !24
  br label %bb65
bb64:
  store i64 0, ptr %l198, !tbaa !24
  br label %bb65
bb65:
  %t372 = load i64, ptr %l191, !tbaa !24
  %t373 = load i64, ptr %l198, !tbaa !24
  %t374 = add i64 %t372, %t373
  %t375 = load i64, ptr %l189, !tbaa !24
  %t377 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s9, i64 %t375, i64 %t374)
  store %"compiler/eval:Ptr" %t377, ptr %l200
  br label %bb66
bb66:
  %t378 = load ptr, ptr %l188, !tbaa !29
  %t379 = load %"compiler/eval:Ptr", ptr %l200
  %t380 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtr(ptr %v0, ptr %t378, %"compiler/eval:Ptr" %t379)
  store %"compiler/eval:Ptr" %t380, ptr %l201
  br label %bb67
bb67:
  %t381 = load %"compiler/eval:Ptr", ptr %l201
  store %"compiler/eval:Ptr" %t381, ptr %l30
  %t382 = getelementptr %"compiler/eval:Ptr", ptr %l30, i32 0, i32 0
  %t383 = load i64, ptr %t382, !tbaa !24
  %t385 = icmp ne i64 %t383, 0
  br i1 %t385, label %bb68, label %bb69
bb68:
  %t387 = load ptr, ptr %l0, !tbaa !29
  %t389 = getelementptr %"compiler/eval:Machine", ptr %t387, i32 0, i32 50
  %t390 = load { i64, ptr }, ptr %t389, !tbaa !27
  store { i64, ptr } %t390, ptr %l205, !tbaa !27
  %t391 = getelementptr %"compiler/eval:Ptr", ptr %l30, i32 0, i32 0
  %t392 = load i64, ptr %t391, !tbaa !24
  %t393 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t396 = and i64 %t392, %t393
  %t398 = getelementptr { i64, ptr }, ptr %l205, i32 0, i32 1
  %t399 = load ptr, ptr %t398, !tbaa !27
  %t400 = getelementptr %"compiler/eval:alloc", ptr %t399, i64 %t396
  %t401 = getelementptr %"compiler/eval:alloc", ptr %t400, i32 0, i32 5
  %t402 = load i64, ptr %t401, !tbaa !24
  store i64 %t402, ptr %l29, !tbaa !24
  br label %bb70
bb69:
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s9)
  br label %bb71
bb71:
  %t404 = load ptr, ptr %l0, !tbaa !29
  store ptr %t404, ptr %l210, !tbaa !29
  %t405 = getelementptr %"compiler/eval:Ptr", ptr %l21, i32 0, i32 0
  %t406 = load i64, ptr %t405, !tbaa !24
  %t407 = load i64, ptr %l19, !tbaa !24
  %t408 = load i32, ptr %l27, !tbaa !23
  %t410 = mul i32 8, %t408
  %t412 = sext i32 %t410 to i64
  %t415 = add i64 %t407, %t412
  %t418 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s8, i64 %t406, i64 %t415)
  store %"compiler/eval:Ptr" %t418, ptr %l217
  br label %bb72
bb72:
  %t419 = load i64, ptr %l29, !tbaa !24
  %t420 = load ptr, ptr %l210, !tbaa !29
  %t421 = load %"compiler/eval:Ptr", ptr %l217
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t420, %"compiler/eval:Ptr" %t421, i64 8, i64 %t419)
  br label %bb73
bb73:
  call void @__olang_scope_close(ptr %s8)
  br label %bb74
bb74:
  %t423 = load i32, ptr %l26, !tbaa !23
  %t426 = add i32 %t423, 1
  store i32 %t426, ptr %l26, !tbaa !23
  br label %bb48
bb75:
  %t428 = load i64, ptr %l8, !tbaa !24
  %t430 = icmp sge i64 %t428, 0
  br i1 %t430, label %bb76, label %bb77
bb76:
  %t432 = load ptr, ptr %l0, !tbaa !29
  store ptr %t432, ptr %l224, !tbaa !29
  %t433 = load i64, ptr %l1, !tbaa !24
  store i64 %t433, ptr %l225, !tbaa !24
  %t434 = load %"compiler/eval:Ptr", ptr %l21
  store %"compiler/eval:Ptr" %t434, ptr %l226
  %t435 = load i64, ptr %l19, !tbaa !24
  store i64 %t435, ptr %l227, !tbaa !24
  %t436 = load ptr, ptr %l0, !tbaa !29
  %t438 = getelementptr %"compiler/eval:Machine", ptr %t436, i32 0, i32 26
  %t439 = load i64, ptr %l8, !tbaa !24
  %t442 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_26_3e_2eAt_3ccompiler_2fmir_3aFn_26_3e(ptr %v0, ptr %v0, ptr %t438, i64 %t439)
  store ptr %t442, ptr %l231
  br label %bb78
bb77:
  br label %bb80
bb78:
  %t444 = load ptr, ptr %l224, !tbaa !29
  %t445 = load i64, ptr %l225, !tbaa !24
  %t446 = load %"compiler/eval:Ptr", ptr %l226
  %t447 = load i64, ptr %l227, !tbaa !24
  %t448 = load ptr, ptr %l231, !tbaa !29
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eplanCaps(ptr %v0, ptr %v0, ptr %t444, i64 %t445, %"compiler/eval:Ptr" %t446, i64 %t447, ptr %t448, %"compiler/mir:Range" %a6)
  br label %bb79
bb79:
  br label %bb80
bb80:
  %t450 = load ptr, ptr %l0, !tbaa !29
  %t451 = load %"compiler/eval:Ptr", ptr %l2
  %t452 = load %"compiler/eval:Ptr", ptr %l7
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrPtr(ptr %v0, ptr %t450, %"compiler/eval:Ptr" %t451, %"compiler/eval:Ptr" %t452)
  br label %bb81
bb81:
  %t456 = load ptr, ptr %l0, !tbaa !29
  store ptr %t456, ptr %l236, !tbaa !29
  %t457 = getelementptr %"compiler/eval:Ptr", ptr %l2, i32 0, i32 0
  %t458 = load i64, ptr %t457, !tbaa !24
  %t459 = getelementptr %"compiler/eval:Ptr", ptr %l2, i32 0, i32 1
  %t460 = load i64, ptr %t459, !tbaa !24
  %t462 = add i64 %t460, 8
  %t465 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s0, i64 %t458, i64 %t462)
  store %"compiler/eval:Ptr" %t465, ptr %l240
  br label %bb82
bb82:
  %t466 = load %"compiler/eval:Ptr", ptr %l21
  %t467 = load ptr, ptr %l236, !tbaa !29
  %t468 = load %"compiler/eval:Ptr", ptr %l240
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrPtr(ptr %v0, ptr %t467, %"compiler/eval:Ptr" %t468, %"compiler/eval:Ptr" %t466)
  br label %bb83
bb83:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2edropScope(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca i64
  %l12 = alloca %"compiler/eval:scope"
  %l19 = alloca %"compiler/eval:scope"
  %l26 = alloca %"compiler/eval:scope"
  %l32 = alloca %"compiler/eval:reg"
  %l37 = alloca ptr
  %l46 = alloca %"compiler/eval:scope"
  %l53 = alloca %"compiler/eval:scope"
  %l59 = alloca %"compiler/eval:task"
  %l64 = alloca ptr
  %l72 = alloca i1
  %l76 = alloca %"compiler/eval:scope"
  %l81 = alloca %"compiler/eval:scope"
  %l89 = alloca { i64, ptr }
  %l92 = alloca i64
  %l97 = alloca { i64, ptr }
  %l103 = alloca %"compiler/eval:scope"
  %l107 = alloca ptr
  %l111 = alloca %"compiler/eval:scope"
  %l116 = alloca %"compiler/eval:scope"
  %l124 = alloca %"compiler/eval:scope"
  %t11 = alloca %"compiler/eval:scope", align 8
  %t25 = alloca %"compiler/eval:scope", align 8
  %t66 = alloca %"compiler/eval:scope", align 8
  %t80 = alloca %"compiler/eval:scope", align 8
  %t126 = alloca %"compiler/eval:scope", align 8
  %t137 = alloca %"compiler/eval:scope", align 8
  %t190 = alloca %"compiler/eval:scope", align 8
  %t205 = alloca %"compiler/eval:scope", align 8
  %t216 = alloca %"compiler/eval:scope", align 8
  %t237 = alloca %"compiler/eval:scope", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t5 = and i64 %a1, %t2
  store i64 %t5, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/eval:Machine", ptr %t7, i32 0, i32 53
  %t10 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t11, ptr %v0, ptr %t9, i64 %t10)
  call void @llvm.memmove.p0.p0.i64(ptr %l19, ptr %t11, i64 152, i1 false)
  br label %bb2
bb2:
  %t14 = getelementptr %"compiler/eval:scope", ptr %l19, i32 0, i32 4
  %t15 = load i64, ptr %t14, !tbaa !24
  %t17 = icmp sge i64 %t15, 0
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/eval:Machine", ptr %t21, i32 0, i32 53
  %t24 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t25, ptr %v0, ptr %t23, i64 %t24)
  call void @llvm.memmove.p0.p0.i64(ptr %l26, ptr %t25, i64 152, i1 false)
  br label %bb6
bb6:
  %t28 = getelementptr %"compiler/eval:scope", ptr %l26, i32 0, i32 4
  %t29 = load i64, ptr %t28, !tbaa !24
  store i64 %t29, ptr %l3, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  store i64 %t31, ptr %l4, !tbaa !24
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/eval:Machine", ptr %t33, i32 0, i32 55
  %t36 = load i64, ptr %l3, !tbaa !24
  %t39 = call %"compiler/eval:reg" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3areg_3e_2eAt_3ccompiler_2feval_3areg_3e(ptr %v0, ptr %t35, i64 %t36)
  store %"compiler/eval:reg" %t39, ptr %l32
  br label %bb7
bb7:
  %t40 = getelementptr %"compiler/eval:reg", ptr %l32, i32 0, i32 4
  %t41 = load i64, ptr %t40, !tbaa !24
  store i64 %t41, ptr %l5, !tbaa !24
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/eval:Machine", ptr %t43, i32 0, i32 53
  %t46 = load i64, ptr %l4, !tbaa !24
  %t49 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eRefMut_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %v0, ptr %t45, i64 %t46)
  store ptr %t49, ptr %l37
  br label %bb8
bb8:
  %t50 = load ptr, ptr %l37, !tbaa !29
  %t52 = load i64, ptr %l5, !tbaa !24
  %t55 = getelementptr %"compiler/eval:scope", ptr %t50, i32 0, i32 4
  store i64 %t52, ptr %t55, !tbaa !24
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/eval:Machine", ptr %t56, i32 0, i32 56
  %t59 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t58, i64 %t59)
  br label %bb9
bb9:
  br label %bb10
bb10:
  br label %bb1
bb11:
  br label %bb12
bb12:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/eval:Machine", ptr %t62, i32 0, i32 53
  %t65 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t66, ptr %v0, ptr %t64, i64 %t65)
  call void @llvm.memmove.p0.p0.i64(ptr %l46, ptr %t66, i64 152, i1 false)
  br label %bb13
bb13:
  %t69 = getelementptr %"compiler/eval:scope", ptr %l46, i32 0, i32 10
  %t70 = load i64, ptr %t69, !tbaa !24
  %t72 = icmp sge i64 %t70, 0
  %t74 = xor i1 %t72, true
  br i1 %t74, label %bb14, label %bb15
bb14:
  br label %bb22
bb15:
  br label %bb16
bb16:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/eval:Machine", ptr %t76, i32 0, i32 53
  %t79 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t80, ptr %v0, ptr %t78, i64 %t79)
  call void @llvm.memmove.p0.p0.i64(ptr %l53, ptr %t80, i64 152, i1 false)
  br label %bb17
bb17:
  %t83 = getelementptr %"compiler/eval:scope", ptr %l53, i32 0, i32 10
  %t84 = load i64, ptr %t83, !tbaa !24
  store i64 %t84, ptr %l7, !tbaa !24
  %t86 = load i64, ptr %l2, !tbaa !24
  store i64 %t86, ptr %l8, !tbaa !24
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/eval:Machine", ptr %t88, i32 0, i32 57
  %t91 = load i64, ptr %l7, !tbaa !24
  %t94 = call %"compiler/eval:task" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3atask_3e_2eAt_3ccompiler_2feval_3atask_3e(ptr %v0, ptr %t90, i64 %t91)
  store %"compiler/eval:task" %t94, ptr %l59
  br label %bb18
bb18:
  %t95 = getelementptr %"compiler/eval:task", ptr %l59, i32 0, i32 3
  %t96 = load i64, ptr %t95, !tbaa !24
  store i64 %t96, ptr %l9, !tbaa !24
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/eval:Machine", ptr %t98, i32 0, i32 53
  %t101 = load i64, ptr %l8, !tbaa !24
  %t104 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eRefMut_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %v0, ptr %t100, i64 %t101)
  store ptr %t104, ptr %l64
  br label %bb19
bb19:
  %t105 = load ptr, ptr %l64, !tbaa !29
  %t107 = load i64, ptr %l9, !tbaa !24
  %t110 = getelementptr %"compiler/eval:scope", ptr %t105, i32 0, i32 10
  store i64 %t107, ptr %t110, !tbaa !24
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/eval:Machine", ptr %t111, i32 0, i32 58
  %t114 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t113, i64 %t114)
  br label %bb20
bb20:
  br label %bb21
bb21:
  br label %bb12
bb22:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/eval:Machine", ptr %t117, i32 0, i32 17
  %t120 = load i1, ptr %t119, !tbaa !21
  br i1 %t120, label %bb23, label %bb24
bb23:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/eval:Machine", ptr %t122, i32 0, i32 53
  %t125 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t126, ptr %v0, ptr %t124, i64 %t125)
  call void @llvm.memmove.p0.p0.i64(ptr %l76, ptr %t126, i64 152, i1 false)
  br label %bb25
bb24:
  store i1 false, ptr %l72, !tbaa !21
  br label %bb26
bb25:
  %t129 = getelementptr %"compiler/eval:scope", ptr %l76, i32 0, i32 15
  %t130 = load i1, ptr %t129, !tbaa !21
  store i1 %t130, ptr %l72, !tbaa !21
  br label %bb26
bb26:
  %t132 = load i1, ptr %l72, !tbaa !21
  br i1 %t132, label %bb27, label %bb28
bb27:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/eval:Machine", ptr %t133, i32 0, i32 53
  %t136 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t137, ptr %v0, ptr %t135, i64 %t136)
  call void @llvm.memmove.p0.p0.i64(ptr %l81, ptr %t137, i64 152, i1 false)
  br label %bb29
bb28:
  br label %bb37
bb29:
  %t140 = getelementptr %"compiler/eval:scope", ptr %l81, i32 0, i32 3
  %t141 = load i64, ptr %t140, !tbaa !24
  store i64 %t141, ptr %l11, !tbaa !24
  br label %bb30
bb30:
  %t143 = load i64, ptr %l11, !tbaa !24
  %t145 = icmp ne i64 %t143, 0
  %t147 = xor i1 %t145, true
  br i1 %t147, label %bb31, label %bb32
bb31:
  br label %bb36
bb32:
  br label %bb33
bb33:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/eval:Machine", ptr %t149, i32 0, i32 18
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/eval:Machine", ptr %t152, i32 0, i32 50
  %t155 = load { i64, ptr }, ptr %t154, !tbaa !27
  store { i64, ptr } %t155, ptr %l89, !tbaa !27
  %t156 = load i64, ptr %l11, !tbaa !24
  %t158 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t159 = load ptr, ptr %t158, !tbaa !27
  %t160 = getelementptr %"compiler/eval:alloc", ptr %t159, i64 %t156
  %t161 = getelementptr %"compiler/eval:alloc", ptr %t160, i32 0, i32 3
  %t162 = load i64, ptr %t161, !tbaa !24
  %t163 = load i64, ptr @G_2ecompiler_2feval_2eslotBits, !tbaa !24
  store i64 %t163, ptr %l92, !tbaa !24
  %t165 = load i64, ptr %l92, !tbaa !24
  %t166 = load i64, ptr %l92, !tbaa !24
  %t167 = shl i64 %t162, %t166
  %t168 = load i64, ptr %l11, !tbaa !24
  %t171 = or i64 %t167, %t168
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t151, i64 %t171, i1 true)
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"compiler/eval:Machine", ptr %t174, i32 0, i32 50
  %t177 = load { i64, ptr }, ptr %t176, !tbaa !27
  store { i64, ptr } %t177, ptr %l97, !tbaa !27
  %t178 = load i64, ptr %l11, !tbaa !24
  %t180 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t181 = load ptr, ptr %t180, !tbaa !27
  %t182 = getelementptr %"compiler/eval:alloc", ptr %t181, i64 %t178
  %t183 = getelementptr %"compiler/eval:alloc", ptr %t182, i32 0, i32 7
  %t184 = load i64, ptr %t183, !tbaa !24
  store i64 %t184, ptr %l11, !tbaa !24
  br label %bb30
bb36:
  br label %bb37
bb37:
  br label %bb38
bb38:
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t188 = getelementptr %"compiler/eval:Machine", ptr %t186, i32 0, i32 53
  %t189 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t190, ptr %v0, ptr %t188, i64 %t189)
  call void @llvm.memmove.p0.p0.i64(ptr %l103, ptr %t190, i64 152, i1 false)
  br label %bb39
bb39:
  %t193 = getelementptr %"compiler/eval:scope", ptr %l103, i32 0, i32 3
  %t194 = load i64, ptr %t193, !tbaa !24
  %t196 = icmp ne i64 %t194, 0
  %t198 = xor i1 %t196, true
  br i1 %t198, label %bb40, label %bb41
bb40:
  br label %bb46
bb41:
  br label %bb42
bb42:
  %t200 = load ptr, ptr %l0, !tbaa !29
  store ptr %t200, ptr %l107, !tbaa !29
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t203 = getelementptr %"compiler/eval:Machine", ptr %t201, i32 0, i32 53
  %t204 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t205, ptr %v0, ptr %t203, i64 %t204)
  call void @llvm.memmove.p0.p0.i64(ptr %l111, ptr %t205, i64 152, i1 false)
  br label %bb43
bb43:
  %t208 = getelementptr %"compiler/eval:scope", ptr %l111, i32 0, i32 3
  %t209 = load i64, ptr %t208, !tbaa !24
  %t210 = load ptr, ptr %l107, !tbaa !29
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erelease(ptr %v0, ptr %t210, i64 %t209)
  br label %bb44
bb44:
  br label %bb45
bb45:
  br label %bb38
bb46:
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = getelementptr %"compiler/eval:Machine", ptr %t212, i32 0, i32 53
  %t215 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t216, ptr %v0, ptr %t214, i64 %t215)
  call void @llvm.memmove.p0.p0.i64(ptr %l116, ptr %t216, i64 152, i1 false)
  br label %bb47
bb47:
  call void @llvm.memmove.p0.p0.i64(ptr %l12, ptr %l116, i64 152, i1 false)
  %t219 = getelementptr %"compiler/eval:scope", ptr %l12, i32 0, i32 1
  store i1 false, ptr %t219, !tbaa !21
  %t220 = getelementptr %"compiler/eval:scope", ptr %l12, i32 0, i32 15
  store i1 false, ptr %t220, !tbaa !21
  %t221 = getelementptr %"compiler/eval:scope", ptr %l12, i32 0, i32 0
  %t222 = load i64, ptr %t221, !tbaa !24
  %t225 = add i64 %t222, 1
  %t227 = and i64 %t225, 274877906943
  %t229 = getelementptr %"compiler/eval:scope", ptr %l12, i32 0, i32 0
  store i64 %t227, ptr %t229, !tbaa !24
  %t230 = getelementptr %"compiler/eval:scope", ptr %l12, i32 0, i32 11
  store i64 -1, ptr %t230, !tbaa !24
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t233 = getelementptr %"compiler/eval:Machine", ptr %t231, i32 0, i32 53
  %t234 = load i64, ptr %l2, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l124, ptr %l12, i64 152, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %t237, ptr %l124, i64 152, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eSetAt_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %t233, i64 %t234, ptr %t237)
  br label %bb48
bb48:
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t240 = getelementptr %"compiler/eval:Machine", ptr %t238, i32 0, i32 54
  %t241 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t240, i64 %t241)
  br label %bb49
bb49:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eendsProgram(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/eval:task"
  %l6 = alloca %"compiler/eval:task"
  %l10 = alloca ptr
  %l14 = alloca %"compiler/mir:Task"
  %rv = alloca i1
  %t22 = alloca %"compiler/mir:Task", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 57
  %t7 = call %"compiler/eval:task" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3atask_3e_2eAt_3ccompiler_2feval_3atask_3e(ptr %v0, ptr %t3, i64 %a1)
  store %"compiler/eval:task" %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load %"compiler/eval:task", ptr %l6
  store %"compiler/eval:task" %t8, ptr %l2
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/eval:Machine", ptr %t9, i32 0, i32 26
  %t12 = getelementptr %"compiler/eval:task", ptr %l2, i32 0, i32 0
  %t13 = load i64, ptr %t12, !tbaa !24
  %t16 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_26_3e_2eAt_3ccompiler_2fmir_3aFn_26_3e(ptr %v0, ptr %v0, ptr %t11, i64 %t13)
  store ptr %t16, ptr %l10
  br label %bb2
bb2:
  %t17 = load ptr, ptr %l10, !tbaa !29
  %t19 = getelementptr %"compiler/mir:Fn", ptr %t17, i32 0, i32 16
  %t20 = getelementptr %"compiler/eval:task", ptr %l2, i32 0, i32 1
  %t21 = load i64, ptr %t20, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e_2eAt_3ccompiler_2fmir_3aTask_3e(ptr %t22, ptr %v0, ptr %t19, i64 %t21)
  call void @llvm.memmove.p0.p0.i64(ptr %l14, ptr %t22, i64 144, i1 false)
  br label %bb3
bb3:
  %t25 = getelementptr %"compiler/mir:Task", ptr %l14, i32 0, i32 5
  %t26 = getelementptr %"compiler/mir:Range", ptr %t25, i32 0, i32 1
  %t27 = load i32, ptr %t26, !tbaa !23
  %t29 = icmp sgt i32 %t27, 0
  store i1 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2eflat(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { %"compiler/eval:Ptr", i32 }
  %l9 = alloca %"compiler/eval:Ptr"
  %l10 = alloca i64
  %l11 = alloca { %"compiler/eval:Ptr", i32 }
  %l12 = alloca %"compiler/eval:Ptr"
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l19 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l44 = alloca ptr
  %l47 = alloca { i64, ptr }
  %l53 = alloca %"compiler/eval:Ptr"
  %l54 = alloca { i64, ptr }
  %l59 = alloca i32
  %l64 = alloca i64
  %l65 = alloca { %"compiler/eval:Ptr", i32 }
  %l69 = alloca ptr
  %l70 = alloca %"compiler/eval:Ptr"
  %l71 = alloca i64
  %l77 = alloca i64
  %l81 = alloca i1
  %l90 = alloca i64
  %l94 = alloca ptr
  %l97 = alloca { i64, ptr }
  %l103 = alloca %"compiler/eval:Ptr"
  %l104 = alloca { i64, ptr }
  %l109 = alloca i32
  %l114 = alloca i64
  %l115 = alloca { %"compiler/eval:Ptr", i32 }
  %l122 = alloca i64
  %l124 = alloca { i64, ptr }
  %l126 = alloca { i64, ptr }
  %l129 = alloca { i64, ptr }
  %l140 = alloca i64
  %l144 = alloca ptr
  %l145 = alloca i32
  %l146 = alloca i64
  %l147 = alloca i32
  %l150 = alloca i64
  %l151 = alloca i64
  %l157 = alloca i64
  %l160 = alloca { i64, ptr }
  %l165 = alloca i64
  %l169 = alloca i64
  %l170 = alloca ptr
  %l171 = alloca i32
  %l172 = alloca i64
  %l173 = alloca i64
  %l174 = alloca i32
  %l175 = alloca { i64, ptr }
  %l180 = alloca i32
  %l183 = alloca i64
  %l184 = alloca i64
  %l189 = alloca { i64, ptr }
  %l194 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 27
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l19, !tbaa !27
  %t5 = load i64, ptr %l2, !tbaa !24
  %t7 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !27
  %t9 = getelementptr %"compiler/eval:cfn", ptr %t8, i64 %t5
  %t10 = getelementptr %"compiler/eval:cfn", ptr %t9, i32 0, i32 13
  %t11 = load { i64, ptr }, ptr %t10, !tbaa !27
  store { i64, ptr } %t11, ptr %l5, !tbaa !27
  %t13 = load i64, ptr %l3, !tbaa !24
  %t14 = load i64, ptr @G_2ecompiler_2feval_2efastStride, !tbaa !24
  %t17 = mul i64 %t13, %t14
  store i64 %t17, ptr %l6, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/eval:Machine", ptr %t20, i32 0, i32 27
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  store { i64, ptr } %t23, ptr %l27, !tbaa !27
  %t24 = load i64, ptr %l2, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr %"compiler/eval:cfn", ptr %t27, i64 %t24
  %t29 = getelementptr %"compiler/eval:cfn", ptr %t28, i32 0, i32 0
  %t30 = load i64, ptr %t29, !tbaa !24
  %t33 = getelementptr %"compiler/eval:Machine", ptr %t19, i32 0, i32 78
  store i64 %t30, ptr %t33, !tbaa !24
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/eval:Machine", ptr %t35, i32 0, i32 27
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l32, !tbaa !27
  %t39 = load i64, ptr %l2, !tbaa !24
  %t41 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = getelementptr %"compiler/eval:cfn", ptr %t42, i64 %t39
  %t44 = getelementptr %"compiler/eval:cfn", ptr %t43, i32 0, i32 18
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !27
  store { i64, ptr } %t45, ptr %l34, !tbaa !27
  %t46 = load i64, ptr %l3, !tbaa !24
  %t48 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = getelementptr %"compiler/source:Span", ptr %t49, i64 %t46
  %t51 = load %"compiler/source:Span", ptr %t50
  %t54 = getelementptr %"compiler/eval:Machine", ptr %t34, i32 0, i32 79
  store %"compiler/source:Span" %t51, ptr %t54
  %t55 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t55, ptr %l37, !tbaa !27
  %t56 = load i64, ptr %l6, !tbaa !24
  %t58 = add i64 %t56, 2
  %t60 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr i64, ptr %t61, i64 %t58
  %t63 = load i64, ptr %t62, !tbaa !34
  store i64 %t63, ptr %l7, !tbaa !24
  %t65 = load i64, ptr %l4, !tbaa !24
  %t66 = load i64, ptr @G_2ecompiler_2feval_2efStore, !tbaa !24
  %t69 = icmp eq i64 %t65, %t66
  br i1 %t69, label %bb1, label %bb2
bb1:
  %t71 = load ptr, ptr %l0, !tbaa !29
  store ptr %t71, ptr %l44, !tbaa !29
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load i64, ptr %l1, !tbaa !24
  %t74 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t74, ptr %l47, !tbaa !27
  %t75 = load i64, ptr %l6, !tbaa !24
  %t77 = add i64 %t75, 1
  %t79 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr i64, ptr %t80, i64 %t77
  %t82 = load i64, ptr %t81, !tbaa !34
  %t84 = trunc i64 %t82 to i32
  %t89 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2elocalPtr(ptr %v0, ptr %t72, i64 %t73, i32 %t84)
  store %"compiler/eval:Ptr" %t89, ptr %l53
  br label %bb3
bb2:
  br label %bb11
bb3:
  %t90 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t90, ptr %l54, !tbaa !27
  %t91 = load i64, ptr %l6, !tbaa !24
  %t93 = add i64 %t91, 7
  %t95 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = getelementptr i64, ptr %t96, i64 %t93
  %t98 = load i64, ptr %t97, !tbaa !34
  %t100 = trunc i64 %t98 to i32
  store i32 %t100, ptr %l59, !tbaa !23
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load i64, ptr %l1, !tbaa !24
  %t104 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t105 = load i64, ptr %l6, !tbaa !24
  %t110 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eflatIndex(ptr %v0, ptr %v0, ptr %t102, i64 %t103, { i64, ptr } %t104, i64 %t105)
  store i64 %t110, ptr %l64
  br label %bb4
bb4:
  %t111 = load ptr, ptr %l44, !tbaa !29
  %t112 = load %"compiler/eval:Ptr", ptr %l53
  %t113 = load i32, ptr %l59, !tbaa !23
  %t114 = load i64, ptr %l64, !tbaa !24
  %t115 = call { %"compiler/eval:Ptr", i32 } @compiler_2feval_2ecompiler_2feval_3aMachine_2eelement(ptr %v0, ptr %t111, %"compiler/eval:Ptr" %t112, i32 %t113, i64 %t114)
  store { %"compiler/eval:Ptr", i32 } %t115, ptr %l65
  br label %bb5
bb5:
  %t116 = load { %"compiler/eval:Ptr", i32 }, ptr %l65
  store { %"compiler/eval:Ptr", i32 } %t116, ptr %l8
  %t117 = getelementptr { %"compiler/eval:Ptr", i32 }, ptr %l8, i32 0, i32 0
  %t118 = load %"compiler/eval:Ptr", ptr %t117
  store %"compiler/eval:Ptr" %t118, ptr %l9
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/eval:Machine", ptr %t120, i32 0, i32 23
  %t123 = load i1, ptr %t122, !tbaa !21
  br i1 %t123, label %bb6, label %bb7
bb6:
  br label %ret
bb7:
  br label %bb8
bb8:
  %t125 = load ptr, ptr %l0, !tbaa !29
  store ptr %t125, ptr %l69, !tbaa !29
  %t126 = load %"compiler/eval:Ptr", ptr %l9
  store %"compiler/eval:Ptr" %t126, ptr %l70
  %t127 = load i64, ptr %l7, !tbaa !24
  store i64 %t127, ptr %l71, !tbaa !24
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load i64, ptr %l1, !tbaa !24
  %t130 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t131 = load i64, ptr %l6, !tbaa !24
  %t133 = add i64 %t131, 3
  %t138 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eflatValue(ptr %v0, ptr %v0, ptr %t128, i64 %t129, { i64, ptr } %t130, i64 %t133)
  store i64 %t138, ptr %l77
  br label %bb9
bb9:
  %t139 = load ptr, ptr %l69, !tbaa !29
  %t140 = load %"compiler/eval:Ptr", ptr %l70
  %t141 = load i64, ptr %l71, !tbaa !24
  %t142 = load i64, ptr %l77, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t139, %"compiler/eval:Ptr" %t140, i64 %t141, i64 %t142)
  br label %bb10
bb10:
  br label %ret
bb11:
  store i64 0, ptr %l10, !tbaa !24
  %t143 = load i64, ptr %l4, !tbaa !24
  %t144 = load i64, ptr @G_2ecompiler_2feval_2efCopy, !tbaa !24
  %t147 = icmp eq i64 %t143, %t144
  br i1 %t147, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l81, !tbaa !21
  br label %bb14
bb13:
  %t149 = load i64, ptr %l4, !tbaa !24
  %t150 = load i64, ptr @G_2ecompiler_2feval_2efConst, !tbaa !24
  %t153 = icmp eq i64 %t149, %t150
  store i1 %t153, ptr %l81, !tbaa !21
  br label %bb14
bb14:
  %t155 = load i1, ptr %l81, !tbaa !21
  br i1 %t155, label %bb15, label %bb16
bb15:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load i64, ptr %l1, !tbaa !24
  %t158 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t159 = load i64, ptr %l6, !tbaa !24
  %t161 = add i64 %t159, 3
  %t166 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eflatValue(ptr %v0, ptr %v0, ptr %t156, i64 %t157, { i64, ptr } %t158, i64 %t161)
  store i64 %t166, ptr %l90
  br label %bb17
bb16:
  %t167 = load i64, ptr %l4, !tbaa !24
  %t168 = load i64, ptr @G_2ecompiler_2feval_2efLoad, !tbaa !24
  %t171 = icmp eq i64 %t167, %t168
  br i1 %t171, label %bb18, label %bb19
bb17:
  %t173 = load i64, ptr %l90, !tbaa !24
  store i64 %t173, ptr %l10, !tbaa !24
  br label %bb44
bb18:
  %t174 = load ptr, ptr %l0, !tbaa !29
  store ptr %t174, ptr %l94, !tbaa !29
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t176 = load i64, ptr %l1, !tbaa !24
  %t177 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t177, ptr %l97, !tbaa !27
  %t178 = load i64, ptr %l6, !tbaa !24
  %t180 = add i64 %t178, 3
  %t182 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t183 = load ptr, ptr %t182, !tbaa !27
  %t184 = getelementptr i64, ptr %t183, i64 %t180
  %t185 = load i64, ptr %t184, !tbaa !34
  %t187 = trunc i64 %t185 to i32
  %t192 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2elocalPtr(ptr %v0, ptr %t175, i64 %t176, i32 %t187)
  store %"compiler/eval:Ptr" %t192, ptr %l103
  br label %bb20
bb19:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t195 = getelementptr %"compiler/eval:Machine", ptr %t193, i32 0, i32 27
  %t196 = load { i64, ptr }, ptr %t195, !tbaa !27
  store { i64, ptr } %t196, ptr %l124, !tbaa !27
  %t197 = load i64, ptr %l2, !tbaa !24
  %t199 = getelementptr { i64, ptr }, ptr %l124, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !27
  %t201 = getelementptr %"compiler/eval:cfn", ptr %t200, i64 %t197
  %t202 = getelementptr %"compiler/eval:cfn", ptr %t201, i32 0, i32 14
  %t203 = load { i64, ptr }, ptr %t202, !tbaa !27
  store { i64, ptr } %t203, ptr %l126, !tbaa !27
  %t204 = load i64, ptr %l3, !tbaa !24
  %t206 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t207 = load ptr, ptr %t206, !tbaa !27
  %t208 = getelementptr i32, ptr %t207, i64 %t204
  %t209 = load i32, ptr %t208, !range !{i32 0, i32 54}
  store i32 %t209, ptr %l13
  %t211 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t211, ptr %l129, !tbaa !27
  %t212 = load i64, ptr %l6, !tbaa !24
  %t214 = add i64 %t212, 7
  %t216 = getelementptr { i64, ptr }, ptr %l129, i32 0, i32 1
  %t217 = load ptr, ptr %t216, !tbaa !27
  %t218 = getelementptr i64, ptr %t217, i64 %t214
  %t219 = load i64, ptr %t218, !tbaa !34
  %t221 = trunc i64 %t219 to i32
  store i32 %t221, ptr %l14, !tbaa !23
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t225 = load i64, ptr %l1, !tbaa !24
  %t226 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t227 = load i64, ptr %l6, !tbaa !24
  %t229 = add i64 %t227, 3
  %t234 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eflatValue(ptr %v0, ptr %v0, ptr %t224, i64 %t225, { i64, ptr } %t226, i64 %t229)
  store i64 %t234, ptr %l140
  br label %bb27
bb20:
  %t235 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t235, ptr %l104, !tbaa !27
  %t236 = load i64, ptr %l6, !tbaa !24
  %t238 = add i64 %t236, 7
  %t240 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t241 = load ptr, ptr %t240, !tbaa !27
  %t242 = getelementptr i64, ptr %t241, i64 %t238
  %t243 = load i64, ptr %t242, !tbaa !34
  %t245 = trunc i64 %t243 to i32
  store i32 %t245, ptr %l109, !tbaa !23
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t248 = load i64, ptr %l1, !tbaa !24
  %t249 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t250 = load i64, ptr %l6, !tbaa !24
  %t255 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eflatIndex(ptr %v0, ptr %v0, ptr %t247, i64 %t248, { i64, ptr } %t249, i64 %t250)
  store i64 %t255, ptr %l114
  br label %bb21
bb21:
  %t256 = load ptr, ptr %l94, !tbaa !29
  %t257 = load %"compiler/eval:Ptr", ptr %l103
  %t258 = load i32, ptr %l109, !tbaa !23
  %t259 = load i64, ptr %l114, !tbaa !24
  %t260 = call { %"compiler/eval:Ptr", i32 } @compiler_2feval_2ecompiler_2feval_3aMachine_2eelement(ptr %v0, ptr %t256, %"compiler/eval:Ptr" %t257, i32 %t258, i64 %t259)
  store { %"compiler/eval:Ptr", i32 } %t260, ptr %l115
  br label %bb22
bb22:
  %t261 = load { %"compiler/eval:Ptr", i32 }, ptr %l115
  store { %"compiler/eval:Ptr", i32 } %t261, ptr %l11
  %t262 = getelementptr { %"compiler/eval:Ptr", i32 }, ptr %l11, i32 0, i32 0
  %t263 = load %"compiler/eval:Ptr", ptr %t262
  store %"compiler/eval:Ptr" %t263, ptr %l12
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t267 = getelementptr %"compiler/eval:Machine", ptr %t265, i32 0, i32 23
  %t268 = load i1, ptr %t267, !tbaa !21
  br i1 %t268, label %bb23, label %bb24
bb23:
  br label %ret
bb24:
  br label %bb25
bb25:
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t271 = load %"compiler/eval:Ptr", ptr %l12
  %t272 = load i64, ptr %l7, !tbaa !24
  %t276 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t270, %"compiler/eval:Ptr" %t271, i64 %t272)
  store i64 %t276, ptr %l122
  br label %bb26
bb26:
  %t277 = load i64, ptr %l122, !tbaa !24
  store i64 %t277, ptr %l10, !tbaa !24
  br label %bb43
bb27:
  %t278 = load i64, ptr %l140, !tbaa !24
  store i64 %t278, ptr %l15, !tbaa !24
  %t279 = load i64, ptr %l4, !tbaa !24
  %t280 = load i64, ptr @G_2ecompiler_2feval_2efUn, !tbaa !24
  %t283 = icmp eq i64 %t279, %t280
  br i1 %t283, label %bb28, label %bb29
bb28:
  %t285 = load ptr, ptr %l0, !tbaa !29
  store ptr %t285, ptr %l144, !tbaa !29
  %t286 = load i32, ptr %l13, !range !{i32 0, i32 54}
  store i32 %t286, ptr %l145
  %t287 = load i64, ptr %l15, !tbaa !24
  store i64 %t287, ptr %l146, !tbaa !24
  %t288 = load i32, ptr %l14, !tbaa !23
  store i32 %t288, ptr %l147, !tbaa !23
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t290 = load i32, ptr %l14, !tbaa !23
  %t293 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t289, i32 %t290)
  store i64 %t293, ptr %l150
  br label %bb30
bb29:
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t295 = load i64, ptr %l1, !tbaa !24
  %t296 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t297 = load i64, ptr %l6, !tbaa !24
  %t299 = add i64 %t297, 5
  %t304 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eflatValue(ptr %v0, ptr %v0, ptr %t294, i64 %t295, { i64, ptr } %t296, i64 %t299)
  store i64 %t304, ptr %l157
  br label %bb32
bb30:
  %t305 = load ptr, ptr %l144, !tbaa !29
  %t306 = load i32, ptr %l145, !range !{i32 0, i32 54}
  %t307 = load i64, ptr %l146, !tbaa !24
  %t308 = load i32, ptr %l147, !tbaa !23
  %t309 = load i64, ptr %l150, !tbaa !24
  %t310 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eunary(ptr %v0, ptr %t305, i32 %t306, i64 %t307, i32 %t308, i64 %t309)
  store i64 %t310, ptr %l151
  br label %bb31
bb31:
  %t311 = load i64, ptr %l151, !tbaa !24
  store i64 %t311, ptr %l10, !tbaa !24
  br label %bb42
bb32:
  %t312 = load i64, ptr %l157, !tbaa !24
  store i64 %t312, ptr %l16, !tbaa !24
  %t313 = load ptr, ptr %l0, !tbaa !29
  %t315 = getelementptr %"compiler/eval:Machine", ptr %t313, i32 0, i32 23
  %t316 = load i1, ptr %t315, !tbaa !21
  br i1 %t316, label %bb33, label %bb34
bb33:
  br label %ret
bb34:
  br label %bb35
bb35:
  %t318 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t318, ptr %l160, !tbaa !27
  %t319 = load i64, ptr %l6, !tbaa !24
  %t321 = add i64 %t319, 10
  %t323 = getelementptr { i64, ptr }, ptr %l160, i32 0, i32 1
  %t324 = load ptr, ptr %t323, !tbaa !27
  %t325 = getelementptr i64, ptr %t324, i64 %t321
  %t326 = load i64, ptr %t325, !tbaa !34
  %t328 = icmp eq i64 %t326, 1
  br i1 %t328, label %bb36, label %bb37
bb36:
  %t330 = load i32, ptr %l13, !range !{i32 0, i32 54}
  %t331 = load i64, ptr %l15, !tbaa !24
  %t332 = load i64, ptr %l16, !tbaa !24
  %t336 = call i64 @compiler_2feval_2ewordValue(i32 %t330, i64 %t331, i64 %t332)
  store i64 %t336, ptr %l169
  br label %bb38
bb37:
  %t337 = load ptr, ptr %l0, !tbaa !29
  store ptr %t337, ptr %l170, !tbaa !29
  %t338 = load i32, ptr %l13, !range !{i32 0, i32 54}
  store i32 %t338, ptr %l171
  %t339 = load i64, ptr %l15, !tbaa !24
  store i64 %t339, ptr %l172, !tbaa !24
  %t340 = load i64, ptr %l16, !tbaa !24
  store i64 %t340, ptr %l173, !tbaa !24
  %t341 = load i32, ptr %l14, !tbaa !23
  store i32 %t341, ptr %l174, !tbaa !23
  %t342 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t342, ptr %l175, !tbaa !27
  %t343 = load i64, ptr %l6, !tbaa !24
  %t345 = add i64 %t343, 8
  %t347 = getelementptr { i64, ptr }, ptr %l175, i32 0, i32 1
  %t348 = load ptr, ptr %t347, !tbaa !27
  %t349 = getelementptr i64, ptr %t348, i64 %t345
  %t350 = load i64, ptr %t349, !tbaa !34
  %t352 = trunc i64 %t350 to i32
  store i32 %t352, ptr %l180, !tbaa !23
  %t354 = load ptr, ptr %l0, !tbaa !29
  %t355 = load i32, ptr %l14, !tbaa !23
  %t358 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t354, i32 %t355)
  store i64 %t358, ptr %l183
  br label %bb39
bb38:
  %t359 = load i64, ptr %l169, !tbaa !24
  store i64 %t359, ptr %l165, !tbaa !24
  br label %bb41
bb39:
  %t360 = load ptr, ptr %l170, !tbaa !29
  %t361 = load i32, ptr %l171, !range !{i32 0, i32 54}
  %t362 = load i64, ptr %l172, !tbaa !24
  %t363 = load i64, ptr %l173, !tbaa !24
  %t364 = load i32, ptr %l174, !tbaa !23
  %t365 = load i32, ptr %l180, !tbaa !23
  %t366 = load i64, ptr %l183, !tbaa !24
  %t367 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2enumOp(ptr %v0, ptr %t360, i32 %t361, i64 %t362, i64 %t363, i32 %t364, i32 %t365, i64 %t366)
  store i64 %t367, ptr %l184
  br label %bb40
bb40:
  %t368 = load i64, ptr %l184, !tbaa !24
  store i64 %t368, ptr %l165, !tbaa !24
  br label %bb41
bb41:
  %t369 = load i64, ptr %l165, !tbaa !24
  store i64 %t369, ptr %l10, !tbaa !24
  br label %bb42
bb42:
  br label %bb43
bb43:
  br label %bb44
bb44:
  %t370 = load ptr, ptr %l0, !tbaa !29
  %t372 = getelementptr %"compiler/eval:Machine", ptr %t370, i32 0, i32 23
  %t373 = load i1, ptr %t372, !tbaa !21
  br i1 %t373, label %bb45, label %bb46
bb45:
  br label %ret
bb46:
  br label %bb47
bb47:
  %t375 = load ptr, ptr %l0, !tbaa !29
  %t376 = load i64, ptr %l1, !tbaa !24
  %t377 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t377, ptr %l189, !tbaa !27
  %t378 = load i64, ptr %l6, !tbaa !24
  %t380 = add i64 %t378, 1
  %t382 = getelementptr { i64, ptr }, ptr %l189, i32 0, i32 1
  %t383 = load ptr, ptr %t382, !tbaa !27
  %t384 = getelementptr i64, ptr %t383, i64 %t380
  %t385 = load i64, ptr %t384, !tbaa !34
  %t386 = load i64, ptr %l7, !tbaa !24
  %t391 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2elocalAt(ptr %v0, ptr %t375, i64 %t376, i64 %t385, i64 %t386, i1 true)
  store i64 %t391, ptr %l194
  br label %bb48
bb48:
  %t392 = load i64, ptr %l194, !tbaa !24
  store i64 %t392, ptr %l17, !tbaa !24
  %t393 = load i64, ptr %l17, !tbaa !24
  %t395 = icmp slt i64 %t393, 0
  br i1 %t395, label %bb49, label %bb50
bb49:
  br label %ret
bb50:
  br label %bb51
bb51:
  %t397 = load ptr, ptr %l0, !tbaa !29
  %t398 = load i64, ptr %l17, !tbaa !24
  %t399 = load i64, ptr %l7, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eunmark(ptr %v0, ptr %t397, i64 %t398, i64 %t399)
  br label %bb52
bb52:
  %t403 = load ptr, ptr %l0, !tbaa !29
  %t404 = load i64, ptr %l17, !tbaa !24
  %t405 = load i64, ptr %l7, !tbaa !24
  %t406 = load i64, ptr %l10, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrRaw(ptr %v0, ptr %t403, i64 %t404, i64 %t405, i64 %t406)
  br label %bb53
bb53:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eflatIndex(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l21 = alloca %"compiler/eval:Ptr"
  %l24 = alloca i64
  %l25 = alloca i64
  %l27 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t1, ptr %l5, !tbaa !27
  %t2 = load i64, ptr %l3, !tbaa !24
  %t4 = add i64 %t2, 8
  %t6 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !27
  %t8 = getelementptr i64, ptr %t7, i64 %t4
  %t9 = load i64, ptr %t8, !tbaa !34
  %t11 = trunc i64 %t9 to i32
  store i32 %t11, ptr %l4, !tbaa !23
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l11, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l12, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l15, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = add i64 %t19, 5
  %t23 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr i64, ptr %t24, i64 %t21
  %t26 = load i64, ptr %t25, !tbaa !34
  %t28 = trunc i64 %t26 to i32
  %t33 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2elocalPtr(ptr %v0, ptr %t16, i64 %a1, i32 %t28)
  store %"compiler/eval:Ptr" %t33, ptr %l21
  br label %bb1
bb1:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load i32, ptr %l4, !tbaa !23
  %t38 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewidth(ptr %v0, ptr %t34, i32 %t35)
  store i64 %t38, ptr %l24
  br label %bb2
bb2:
  %t39 = load ptr, ptr %l12, !tbaa !29
  %t40 = load %"compiler/eval:Ptr", ptr %l21
  %t41 = load i64, ptr %l24, !tbaa !24
  %t42 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t39, %"compiler/eval:Ptr" %t40, i64 %t41)
  store i64 %t42, ptr %l25
  br label %bb3
bb3:
  %t43 = load i32, ptr %l4, !tbaa !23
  %t44 = load ptr, ptr %l11, !tbaa !29
  %t45 = load i64, ptr %l25, !tbaa !24
  %t47 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintValue(ptr %v0, ptr %t44, i64 %t45, i32 %t43)
  store i64 %t47, ptr %l27
  br label %bb4
bb4:
  %t48 = load i64, ptr %l27, !tbaa !24
  store i64 %t48, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eflatValue(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l22 = alloca i64
  %l28 = alloca { i64, ptr }
  %l32 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t1, ptr %l6, !tbaa !27
  %t2 = load i64, ptr %l3, !tbaa !24
  %t4 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t5 = load ptr, ptr %t4, !tbaa !27
  %t6 = getelementptr i64, ptr %t5, i64 %t2
  %t7 = load i64, ptr %t6, !tbaa !34
  store i64 %t7, ptr %l4, !tbaa !24
  %t9 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t9, 0
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t13, ptr %l11, !tbaa !27
  %t14 = load i64, ptr %l3, !tbaa !24
  %t16 = add i64 %t14, 1
  %t18 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i64, ptr %t19, i64 %t16
  %t21 = load i64, ptr %t20, !tbaa !34
  store i64 %t21, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = load i64, ptr %l4, !tbaa !24
  %t26 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t26, ptr %l18, !tbaa !27
  %t27 = load i64, ptr %l3, !tbaa !24
  %t29 = add i64 %t27, 1
  %t31 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr i64, ptr %t32, i64 %t29
  %t34 = load i64, ptr %t33, !tbaa !34
  %t39 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2elocalAt(ptr %v0, ptr %t23, i64 %a1, i64 %t25, i64 %t34, i1 false)
  store i64 %t39, ptr %l22
  br label %bb4
bb4:
  %t40 = load i64, ptr %l22, !tbaa !24
  store i64 %t40, ptr %l5, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  %t43 = icmp slt i64 %t41, 0
  br i1 %t43, label %bb5, label %bb6
bb5:
  store i64 0, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load i64, ptr %l5, !tbaa !24
  %t48 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t48, ptr %l28, !tbaa !27
  %t49 = load i64, ptr %l3, !tbaa !24
  %t51 = add i64 %t49, 1
  %t53 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr i64, ptr %t54, i64 %t51
  %t56 = load i64, ptr %t55, !tbaa !34
  %t60 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erdRaw(ptr %v0, ptr %t46, i64 %t47, i64 %t56)
  store i64 %t60, ptr %l32
  br label %bb8
bb8:
  %t61 = load i64, ptr %l32, !tbaa !24
  store i64 %t61, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2eflattenToElem(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/mir:Lvalue" %a2, { i64, [15 x i64] } %a3, ptr %a4, i64 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/mir:Lvalue"
  %l3 = alloca { i64, [15 x i64] }
  %l4 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca { i64, [1 x i64] }
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca i64
  %l13 = alloca { i64, [4 x i64] }
  %l14 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l29 = alloca { i64, [1 x i64] }
  %l36 = alloca ptr
  %l40 = alloca %"compiler/mir:Local"
  %l42 = alloca i32
  %l45 = alloca i1
  %l47 = alloca i1
  %l50 = alloca i64
  %l53 = alloca i64
  %l57 = alloca i64
  %l66 = alloca i1
  %l81 = alloca i32
  %l84 = alloca { i64, ptr }
  %l90 = alloca i64
  %l93 = alloca ptr
  %l97 = alloca %"compiler/mir:Local"
  %l99 = alloca i1
  %l106 = alloca { i64, ptr }
  %l110 = alloca { i64, ptr }
  %l115 = alloca { i64, ptr }
  %l120 = alloca { i64, ptr }
  %l127 = alloca %"compiler/mir:Local"
  %l133 = alloca %"compiler/mir:Local"
  %l137 = alloca { i64, ptr }
  %l142 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store %"compiler/mir:Lvalue" %a2, ptr %l2
  store { i64, [15 x i64] } %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load %"compiler/mir:Lvalue", ptr %l2
  %t3 = call i64 @compiler_2feval_2eplainLocal(%"compiler/mir:Lvalue" %t1)
  store i64 %t3, ptr %l22
  br label %bb1
bb1:
  %t4 = load i64, ptr %l22, !tbaa !24
  store i64 %t4, ptr %l6, !tbaa !24
  %t5 = load i64, ptr %l6, !tbaa !24
  %t7 = icmp slt i64 %t5, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = getelementptr %"compiler/mir:Fn", ptr %t9, i32 0, i32 10
  %t12 = getelementptr %"compiler/mir:Lvalue", ptr %l2, i32 0, i32 1
  %t13 = getelementptr %"compiler/mir:Range", ptr %t12, i32 0, i32 0
  %t14 = load i32, ptr %t13, !tbaa !23
  %t16 = sext i32 %t14 to i64
  %t19 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eAt_3ccompiler_2fmir_3aProj_3e(ptr %v1, ptr %t11, i64 %t16)
  store { i64, [1 x i64] } %t19, ptr %l29
  br label %bb5
bb5:
  %t20 = load { i64, [1 x i64] }, ptr %l29
  store { i64, [1 x i64] } %t20, ptr %l7
  %t21 = load { i64, [1 x i64] }, ptr %l7
  %t23 = extractvalue { i64, [1 x i64] } %t21, 0
  %t24 = icmp eq i64 %t23, 1
  %t26 = xor i1 %t24, true
  br i1 %t26, label %bb6, label %bb7
bb6:
  br label %ret
bb7:
  br label %bb8
bb8:
  %t28 = getelementptr { i64, [1 x i64] }, ptr %l7, i32 0, i32 1
  %t29 = getelementptr { i32 }, ptr %t28, i32 0, i32 0
  %t30 = load i32, ptr %t29
  %t34 = sext i32 %t30 to i64
  store i64 %t34, ptr %l9, !tbaa !24
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l36, !tbaa !29
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr %"compiler/mir:Fn", ptr %t37, i32 0, i32 7
  %t40 = load i64, ptr %l6, !tbaa !24
  %t43 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v1, ptr %t39, i64 %t40)
  store %"compiler/mir:Local" %t43, ptr %l40
  br label %bb9
bb9:
  %t44 = getelementptr %"compiler/mir:Local", ptr %l40, i32 0, i32 2
  %t45 = load i32, ptr %t44, !tbaa !23
  %t46 = load ptr, ptr %l36, !tbaa !29
  %t48 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eelemOf(ptr %v0, ptr %t46, i32 %t45)
  store i32 %t48, ptr %l42
  br label %bb10
bb10:
  %t49 = load i32, ptr %l42, !tbaa !23
  store i32 %t49, ptr %l10, !tbaa !23
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load i32, ptr %l10, !tbaa !23
  %t54 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2enumber(ptr %v0, ptr %t50, i32 %t51)
  store i1 %t54, ptr %l45
  br label %bb11
bb11:
  %t55 = load i1, ptr %l45, !tbaa !21
  %t56 = xor i1 %t55, true
  br i1 %t56, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l47, !tbaa !21
  br label %bb16
bb13:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i32, ptr %l10, !tbaa !23
  %t62 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t58, i32 %t59)
  store i64 %t62, ptr %l50
  br label %bb14
bb14:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load i32, ptr %l10, !tbaa !23
  %t67 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewidth(ptr %v0, ptr %t63, i32 %t64)
  store i64 %t67, ptr %l53
  br label %bb15
bb15:
  %t68 = load i64, ptr %l50, !tbaa !24
  %t69 = load i64, ptr %l53, !tbaa !24
  %t70 = icmp ne i64 %t68, %t69
  store i1 %t70, ptr %l47, !tbaa !21
  br label %bb16
bb16:
  %t72 = load i1, ptr %l47, !tbaa !21
  br i1 %t72, label %bb17, label %bb18
bb17:
  br label %ret
bb18:
  br label %bb19
bb19:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load i32, ptr %l10, !tbaa !23
  %t77 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewidth(ptr %v0, ptr %t73, i32 %t74)
  store i64 %t77, ptr %l57
  br label %bb20
bb20:
  %t78 = load i64, ptr %l57, !tbaa !24
  store i64 %t78, ptr %l11, !tbaa !24
  %t79 = load { i64, [15 x i64] }, ptr %l3
  %t81 = extractvalue { i64, [15 x i64] } %t79, 0
  %t82 = icmp eq i64 %t81, 0
  %t84 = xor i1 %t82, true
  br i1 %t84, label %bb21, label %bb22
bb21:
  br label %ret
bb22:
  br label %bb23
bb23:
  %t86 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t87 = getelementptr { { i64, [4 x i64] } }, ptr %t86, i32 0, i32 0
  %t88 = load { i64, [4 x i64] }, ptr %t87
  store { i64, [4 x i64] } %t88, ptr %l13
  %t92 = load { i64, [4 x i64] }, ptr %l13
  %t94 = extractvalue { i64, [4 x i64] } %t92, 0
  %t95 = icmp eq i64 %t94, 2
  %t97 = xor i1 %t95, true
  br i1 %t97, label %bb24, label %bb25
bb24:
  %t99 = load { i64, [4 x i64] }, ptr %l13
  %t101 = extractvalue { i64, [4 x i64] } %t99, 0
  %t102 = icmp eq i64 %t101, 1
  %t104 = xor i1 %t102, true
  store i1 %t104, ptr %l66, !tbaa !21
  br label %bb26
bb25:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb26
bb26:
  %t106 = load i1, ptr %l66, !tbaa !21
  br i1 %t106, label %bb27, label %bb28
bb27:
  br label %ret
bb28:
  br label %bb29
bb29:
  %t108 = load i64, ptr @G_2ecompiler_2feval_2efastStride, !tbaa !24
  %t111 = mul i64 %a5, %t108
  store i64 %t111, ptr %l14, !tbaa !24
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load ptr, ptr %l1, !tbaa !29
  %t115 = load { i64, [4 x i64] }, ptr %l13
  %t116 = load ptr, ptr %l4, !tbaa !29
  %t117 = load i64, ptr %l14, !tbaa !24
  %t119 = add i64 %t117, 3
  %t120 = load i64, ptr %l14, !tbaa !24
  %t122 = add i64 %t120, 9
  %t129 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eflatOperand(ptr %v0, ptr %v1, ptr %v2, ptr %t113, ptr %t114, { i64, [4 x i64] } %t115, ptr %t116, i64 %t119, i64 %t122)
  store i32 %t129, ptr %l81
  %t130 = icmp ne i32 %t129, 0
  br i1 %t130, label %bb31, label %ok.131, !prof !99
ok.131:
  br label %bb30
bb30:
  br label %bb33
bb31:
  br label %bb32
bb32:
  br label %ret
bb33:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load ptr, ptr %l4, !tbaa !29
  %t135 = getelementptr %"compiler/eval:cfn", ptr %t133, i32 0, i32 13
  %t136 = load { i64, ptr }, ptr %t135, !tbaa !27
  store { i64, ptr } %t136, ptr %l84, !tbaa !27
  %t137 = load i64, ptr %l14, !tbaa !24
  %t139 = add i64 %t137, 9
  %t141 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !27
  %t143 = getelementptr i64, ptr %t142, i64 %t139
  %t144 = load i64, ptr %t143, !tbaa !34
  %t146 = trunc i64 %t144 to i32
  %t150 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewidth(ptr %v0, ptr %t132, i32 %t146)
  store i64 %t150, ptr %l90
  br label %bb34
bb34:
  %t151 = load i64, ptr %l11, !tbaa !24
  %t152 = load i64, ptr %l90, !tbaa !24
  %t154 = icmp ne i64 %t152, %t151
  br i1 %t154, label %bb35, label %bb36
bb35:
  br label %ret
bb36:
  br label %bb37
bb37:
  %t156 = load ptr, ptr %l0, !tbaa !29
  store ptr %t156, ptr %l93, !tbaa !29
  %t157 = load ptr, ptr %l1, !tbaa !29
  %t159 = getelementptr %"compiler/mir:Fn", ptr %t157, i32 0, i32 7
  %t160 = load i64, ptr %l9, !tbaa !24
  %t163 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v1, ptr %t159, i64 %t160)
  store %"compiler/mir:Local" %t163, ptr %l97
  br label %bb38
bb38:
  %t164 = getelementptr %"compiler/mir:Local", ptr %l97, i32 0, i32 2
  %t165 = load i32, ptr %t164, !tbaa !23
  %t166 = load ptr, ptr %l93, !tbaa !29
  %t168 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2enumber(ptr %v0, ptr %t166, i32 %t165)
  store i1 %t168, ptr %l99
  br label %bb39
bb39:
  %t169 = load i1, ptr %l99, !tbaa !21
  %t170 = xor i1 %t169, true
  br i1 %t170, label %bb40, label %bb41
bb40:
  br label %ret
bb41:
  br label %bb42
bb42:
  %t172 = load i64, ptr @G_2ecompiler_2feval_2efStore, !tbaa !24
  %t174 = load i64, ptr %l6, !tbaa !24
  %t176 = load i64, ptr %l11, !tbaa !24
  %t178 = load i64, ptr %l9, !tbaa !24
  %t180 = load ptr, ptr %l4, !tbaa !29
  %t182 = getelementptr %"compiler/eval:cfn", ptr %t180, i32 0, i32 13
  %t183 = load { i64, ptr }, ptr %t182, !tbaa !27
  store { i64, ptr } %t183, ptr %l106, !tbaa !27
  %t184 = load i64, ptr %l14, !tbaa !24
  %t188 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t189 = load ptr, ptr %t188, !tbaa !27
  %t190 = getelementptr i64, ptr %t189, i64 %t184
  store i64 %t172, ptr %t190, !tbaa !34
  %t191 = load ptr, ptr %l4, !tbaa !29
  %t193 = getelementptr %"compiler/eval:cfn", ptr %t191, i32 0, i32 13
  %t194 = load { i64, ptr }, ptr %t193, !tbaa !27
  store { i64, ptr } %t194, ptr %l110, !tbaa !27
  %t195 = load i64, ptr %l14, !tbaa !24
  %t197 = add i64 %t195, 1
  %t201 = getelementptr { i64, ptr }, ptr %l110, i32 0, i32 1
  %t202 = load ptr, ptr %t201, !tbaa !27
  %t203 = getelementptr i64, ptr %t202, i64 %t197
  store i64 %t174, ptr %t203, !tbaa !34
  %t204 = load ptr, ptr %l4, !tbaa !29
  %t206 = getelementptr %"compiler/eval:cfn", ptr %t204, i32 0, i32 13
  %t207 = load { i64, ptr }, ptr %t206, !tbaa !27
  store { i64, ptr } %t207, ptr %l115, !tbaa !27
  %t208 = load i64, ptr %l14, !tbaa !24
  %t210 = add i64 %t208, 2
  %t214 = getelementptr { i64, ptr }, ptr %l115, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !27
  %t216 = getelementptr i64, ptr %t215, i64 %t210
  store i64 %t176, ptr %t216, !tbaa !34
  %t217 = load ptr, ptr %l4, !tbaa !29
  %t219 = getelementptr %"compiler/eval:cfn", ptr %t217, i32 0, i32 13
  %t220 = load { i64, ptr }, ptr %t219, !tbaa !27
  store { i64, ptr } %t220, ptr %l120, !tbaa !27
  %t221 = load i64, ptr %l14, !tbaa !24
  %t223 = add i64 %t221, 5
  %t227 = getelementptr { i64, ptr }, ptr %l120, i32 0, i32 1
  %t228 = load ptr, ptr %t227, !tbaa !27
  %t229 = getelementptr i64, ptr %t228, i64 %t223
  store i64 %t178, ptr %t229, !tbaa !34
  %t230 = load ptr, ptr %l1, !tbaa !29
  %t232 = getelementptr %"compiler/mir:Fn", ptr %t230, i32 0, i32 7
  %t233 = load i64, ptr %l6, !tbaa !24
  %t236 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v1, ptr %t232, i64 %t233)
  store %"compiler/mir:Local" %t236, ptr %l127
  br label %bb43
bb43:
  %t237 = getelementptr %"compiler/mir:Local", ptr %l127, i32 0, i32 2
  %t238 = load i32, ptr %t237, !tbaa !23
  %t240 = sext i32 %t238 to i64
  store i64 %t240, ptr %l19, !tbaa !24
  %t242 = load ptr, ptr %l1, !tbaa !29
  %t244 = getelementptr %"compiler/mir:Fn", ptr %t242, i32 0, i32 7
  %t245 = load i64, ptr %l9, !tbaa !24
  %t248 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v1, ptr %t244, i64 %t245)
  store %"compiler/mir:Local" %t248, ptr %l133
  br label %bb44
bb44:
  %t249 = getelementptr %"compiler/mir:Local", ptr %l133, i32 0, i32 2
  %t250 = load i32, ptr %t249, !tbaa !23
  %t252 = sext i32 %t250 to i64
  %t254 = load ptr, ptr %l4, !tbaa !29
  %t256 = getelementptr %"compiler/eval:cfn", ptr %t254, i32 0, i32 13
  %t257 = load { i64, ptr }, ptr %t256, !tbaa !27
  store { i64, ptr } %t257, ptr %l137, !tbaa !27
  %t258 = load i64, ptr %l14, !tbaa !24
  %t260 = add i64 %t258, 7
  %t261 = load i64, ptr %l19, !tbaa !24
  %t264 = getelementptr { i64, ptr }, ptr %l137, i32 0, i32 1
  %t265 = load ptr, ptr %t264, !tbaa !27
  %t266 = getelementptr i64, ptr %t265, i64 %t260
  store i64 %t261, ptr %t266, !tbaa !34
  %t267 = load ptr, ptr %l4, !tbaa !29
  %t269 = getelementptr %"compiler/eval:cfn", ptr %t267, i32 0, i32 13
  %t270 = load { i64, ptr }, ptr %t269, !tbaa !27
  store { i64, ptr } %t270, ptr %l142, !tbaa !27
  %t271 = load i64, ptr %l14, !tbaa !24
  %t273 = add i64 %t271, 8
  %t277 = getelementptr { i64, ptr }, ptr %l142, i32 0, i32 1
  %t278 = load ptr, ptr %t277, !tbaa !27
  %t279 = getelementptr i64, ptr %t278, i64 %t273
  store i64 %t252, ptr %t279, !tbaa !34
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2egenClosure(ptr %v0, ptr %a0, i64 %a1, %"compiler/eval:Ptr" %a2, %"compiler/eval:Ptr" %a3, i64 %a4, { i64, [1 x i64] } %a5, %"compiler/mir:Range" %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/eval:Ptr"
  %l4 = alloca i64
  %l6 = alloca %"compiler/mir:Range"
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca { { i64, ptr }, i64 }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca %"compiler/eval:Ptr"
  %l20 = alloca i32
  %l21 = alloca i32
  %l22 = alloca i32
  %l23 = alloca i32
  %l24 = alloca i32
  %l25 = alloca i32
  %l26 = alloca { i64, [4 x i64] }
  %l27 = alloca i64
  %l28 = alloca %"compiler/eval:Ptr"
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l40 = alloca ptr
  %l42 = alloca i64
  %l50 = alloca i32
  %l53 = alloca i32
  %l71 = alloca i32
  %l72 = alloca ptr
  %l73 = alloca i64
  %l81 = alloca { i64, [4 x i64] }
  %l82 = alloca i32
  %l88 = alloca { { i64, ptr }, i64 }
  %l94 = alloca i64
  %l106 = alloca %"compiler/eval:Ptr"
  %l111 = alloca i32
  %l114 = alloca i32
  %l139 = alloca { i64, [4 x i64] }
  %l140 = alloca ptr
  %l141 = alloca i64
  %l145 = alloca %"compiler/eval:Ptr"
  %l153 = alloca i64
  %l156 = alloca i1
  %l160 = alloca i64
  %l163 = alloca ptr
  %l164 = alloca i64
  %l166 = alloca i64
  %l170 = alloca i64
  %l173 = alloca i64
  %l175 = alloca %"compiler/eval:Ptr"
  %l176 = alloca %"compiler/eval:Ptr"
  %l180 = alloca { i64, ptr }
  %l185 = alloca ptr
  %l192 = alloca %"compiler/eval:Ptr"
  %l197 = alloca i64
  %l201 = alloca i64
  %l202 = alloca i32
  %l208 = alloca %"compiler/eval:genRec"
  %l219 = alloca i1
  %l223 = alloca %"compiler/eval:genRec"
  %l226 = alloca ptr
  %l227 = alloca i64
  %l228 = alloca %"compiler/eval:genRec"
  %l233 = alloca ptr
  %l237 = alloca ptr
  %l238 = alloca %"compiler/eval:genRec"
  %l241 = alloca i64
  %l247 = alloca ptr
  %l254 = alloca ptr
  %l257 = alloca ptr
  %l264 = alloca %"compiler/eval:Ptr"
  %l274 = alloca ptr
  %l278 = alloca %"compiler/eval:Ptr"
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %t383 = alloca %"compiler/eval:genRec", align 8
  %t389 = alloca %"compiler/eval:genRec", align 8
  %t416 = alloca %"compiler/eval:genRec", align 8
  %t426 = alloca %"compiler/eval:genRec", align 8
  %t429 = alloca %"compiler/eval:genRec", align 8
  %t446 = alloca %"compiler/eval:genRec", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/eval:Ptr" %a2, ptr %l2
  store i64 %a4, ptr %l4
  store %"compiler/mir:Range" %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call ptr @compiler_2feval_2ecompiler_2feval_3aMachine_2efnOfFrame(ptr %v0, ptr %v0, ptr %t1, i64 %t2)
  store ptr %t5, ptr %l40
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l40, !tbaa !29
  store ptr %t6, ptr %l7, !tbaa !29
  %t7 = getelementptr %"compiler/mir:Range", ptr %l6, i32 0, i32 1
  %t8 = load i32, ptr %t7, !tbaa !23
  %t10 = sext i32 %t8 to i64
  store i64 %t10, ptr %l42, !tbaa !24
  %t11 = load i64, ptr %l42, !tbaa !24
  %t12 = icmp sge i64 %t11, 0
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t14 = load i64, ptr %l42, !tbaa !24
  %t15 = icmp sle i64 %t14, 2305843009213693951
  br i1 %t15, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @olang_loc_b3c5db2f6a543f4f_ebedfa57413dac3)
  unreachable
bb4:
  %t17 = load i64, ptr %l42, !tbaa !24
  %t18 = mul i64 %t17, 4
  %t19 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t18)
  %t20 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l8, !tbaa !27
  store i32 0, ptr %l9, !tbaa !23
  %t23 = getelementptr %"compiler/mir:Range", ptr %l6, i32 0, i32 1
  %t24 = load i32, ptr %t23, !tbaa !23
  store i32 %t24, ptr %l10, !tbaa !23
  store i32 1, ptr %l11, !tbaa !23
  %t26 = load i32, ptr %l10, !tbaa !23
  %t27 = load i32, ptr %l9, !tbaa !23
  %t30 = icmp sgt i32 %t26, %t27
  br i1 %t30, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_b3c5db2f6a543f4f_ebedfa57413dac3)
  unreachable
bb6:
  %t32 = load i32, ptr %l11, !tbaa !23
  %t34 = icmp sgt i32 %t32, 0
  br i1 %t34, label %bb8, label %bb9
bb7:
  store i32 0, ptr %l50, !tbaa !23
  br label %bb11
bb8:
  %t36 = load i32, ptr %l10, !tbaa !23
  %t37 = load i32, ptr %l9, !tbaa !23
  %t40 = sub i32 %t36, %t37
  %t41 = load i32, ptr %l11, !tbaa !23
  %t44 = add i32 %t40, %t41
  %t46 = sub i32 %t44, 1
  %t47 = load i32, ptr %l11, !tbaa !23
  %t50 = sdiv i32 %t46, %t47
  store i32 %t50, ptr %l53, !tbaa !23
  br label %bb10
bb9:
  store i32 0, ptr %l53, !tbaa !23
  br label %bb10
bb10:
  %t52 = load i32, ptr %l53, !tbaa !23
  store i32 %t52, ptr %l50, !tbaa !23
  br label %bb11
bb11:
  %t53 = load i32, ptr %l50, !tbaa !23
  store i32 %t53, ptr %l12, !tbaa !23
  store i32 0, ptr %l13, !tbaa !23
  br label %bb12
bb12:
  %t54 = load i32, ptr %l13, !tbaa !23
  %t55 = load i32, ptr %l12, !tbaa !23
  %t58 = icmp slt i32 %t54, %t55
  %t60 = xor i1 %t58, true
  br i1 %t60, label %bb13, label %bb14
bb13:
  br label %bb19
bb14:
  br label %bb15
bb15:
  %t62 = load i32, ptr %l9, !tbaa !23
  %t63 = load i32, ptr %l13, !tbaa !23
  %t64 = load i32, ptr %l11, !tbaa !23
  %t67 = mul i32 %t63, %t64
  %t70 = add i32 %t62, %t67
  store i32 %t70, ptr %l14, !tbaa !23
  %t72 = load i32, ptr %l14, !tbaa !23
  store i32 %t72, ptr %l71, !tbaa !23
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l72, !tbaa !29
  %t74 = load i64, ptr %l1, !tbaa !24
  store i64 %t74, ptr %l73, !tbaa !24
  %t75 = load ptr, ptr %l7, !tbaa !29
  %t77 = getelementptr %"compiler/mir:Fn", ptr %t75, i32 0, i32 11
  %t78 = getelementptr %"compiler/mir:Range", ptr %l6, i32 0, i32 0
  %t79 = load i32, ptr %t78, !tbaa !23
  %t81 = sext i32 %t79 to i64
  %t82 = load i32, ptr %l14, !tbaa !23
  %t84 = sext i32 %t82 to i64
  %t87 = add i64 %t81, %t84
  %t90 = call { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %t77, i64 %t87)
  store { i64, [4 x i64] } %t90, ptr %l81
  br label %bb16
bb16:
  %t91 = load ptr, ptr %l72, !tbaa !29
  %t92 = load i64, ptr %l73, !tbaa !24
  %t93 = load { i64, [4 x i64] }, ptr %l81
  %t94 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eopType(ptr %v0, ptr %t91, i64 %t92, { i64, [4 x i64] } %t93)
  store i32 %t94, ptr %l82
  br label %bb17
bb17:
  %t95 = load i32, ptr %l82, !tbaa !23
  %t96 = load i32, ptr %l71, !tbaa !23
  %t97 = sext i32 %t96 to i64
  %t98 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr i32, ptr %t99, i64 %t97
  store i32 %t95, ptr %t100, !tbaa !33
  br label %bb18
bb18:
  %t101 = load i32, ptr %l13, !tbaa !23
  %t104 = add i32 %t101, 1
  store i32 %t104, ptr %l13, !tbaa !23
  br label %bb12
bb19:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t110 = call { { i64, ptr }, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2epack(ptr %v0, ptr %s0, ptr %s0, ptr %t106, { i64, ptr } %t107)
  store { { i64, ptr }, i64 } %t110, ptr %l88
  br label %bb20
bb20:
  %t111 = load { { i64, ptr }, i64 }, ptr %l88
  store { { i64, ptr }, i64 } %t111, ptr %l15
  %t112 = getelementptr { { i64, ptr }, i64 }, ptr %l15, i32 0, i32 0
  %t113 = load { i64, ptr }, ptr %t112, !tbaa !27
  store { i64, ptr } %t113, ptr %l16, !tbaa !27
  %t115 = getelementptr { { i64, ptr }, i64 }, ptr %l15, i32 0, i32 1
  %t116 = load i64, ptr %t115, !tbaa !24
  store i64 %t116, ptr %l17, !tbaa !24
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load i64, ptr %l1, !tbaa !24
  %t124 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ebuildScope(ptr %v0, ptr %t118, i64 %t119, { i64, [1 x i64] } %a5)
  store i64 %t124, ptr %l94
  br label %bb21
bb21:
  %t125 = load i64, ptr %l94, !tbaa !24
  store i64 %t125, ptr %l18, !tbaa !24
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/eval:Machine", ptr %t126, i32 0, i32 23
  %t129 = load i1, ptr %t128, !tbaa !21
  br i1 %t129, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb23:
  br label %bb24
bb24:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load i64, ptr %l17, !tbaa !24
  %t133 = getelementptr %"compiler/mir:Range", ptr %l6, i32 0, i32 1
  %t134 = load i32, ptr %t133, !tbaa !23
  %t136 = sext i32 %t134 to i64
  %t138 = mul i64 8, %t136
  %t141 = add i64 %t132, %t138
  %t143 = add i64 %t141, 8
  %t144 = load i64, ptr @G_2ecompiler_2feval_2eaValue, !tbaa !24
  %t145 = load i64, ptr %l18, !tbaa !24
  %t150 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eallocate(ptr %v0, ptr %t131, i64 %t143, i64 %t144, i64 %t145)
  store %"compiler/eval:Ptr" %t150, ptr %l106
  br label %bb25
bb25:
  %t151 = load %"compiler/eval:Ptr", ptr %l106
  store %"compiler/eval:Ptr" %t151, ptr %l19
  store i32 0, ptr %l20, !tbaa !23
  %t152 = getelementptr %"compiler/mir:Range", ptr %l6, i32 0, i32 1
  %t153 = load i32, ptr %t152, !tbaa !23
  store i32 %t153, ptr %l21, !tbaa !23
  store i32 1, ptr %l22, !tbaa !23
  %t155 = load i32, ptr %l21, !tbaa !23
  %t156 = load i32, ptr %l20, !tbaa !23
  %t159 = icmp sgt i32 %t155, %t156
  br i1 %t159, label %bb26, label %bb27
bb26:
  %t161 = load i32, ptr %l22, !tbaa !23
  %t163 = icmp sgt i32 %t161, 0
  br i1 %t163, label %bb28, label %bb29
bb27:
  store i32 0, ptr %l111, !tbaa !23
  br label %bb31
bb28:
  %t165 = load i32, ptr %l21, !tbaa !23
  %t166 = load i32, ptr %l20, !tbaa !23
  %t169 = sub i32 %t165, %t166
  %t170 = load i32, ptr %l22, !tbaa !23
  %t173 = add i32 %t169, %t170
  %t175 = sub i32 %t173, 1
  %t176 = load i32, ptr %l22, !tbaa !23
  %t179 = sdiv i32 %t175, %t176
  store i32 %t179, ptr %l114, !tbaa !23
  br label %bb30
bb29:
  store i32 0, ptr %l114, !tbaa !23
  br label %bb30
bb30:
  %t181 = load i32, ptr %l114, !tbaa !23
  store i32 %t181, ptr %l111, !tbaa !23
  br label %bb31
bb31:
  %t182 = load i32, ptr %l111, !tbaa !23
  store i32 %t182, ptr %l23, !tbaa !23
  store i32 0, ptr %l24, !tbaa !23
  br label %bb32
bb32:
  store %olang.scope zeroinitializer, ptr %s6
  %t183 = load i32, ptr %l24, !tbaa !23
  %t184 = load i32, ptr %l23, !tbaa !23
  %t187 = icmp slt i32 %t183, %t184
  %t189 = xor i1 %t187, true
  br i1 %t189, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s6)
  br label %bb59
bb34:
  br label %bb35
bb35:
  %t191 = load i32, ptr %l20, !tbaa !23
  %t192 = load i32, ptr %l24, !tbaa !23
  %t193 = load i32, ptr %l22, !tbaa !23
  %t196 = mul i32 %t192, %t193
  %t199 = add i32 %t191, %t196
  store i32 %t199, ptr %l25, !tbaa !23
  %t201 = load ptr, ptr %l7, !tbaa !29
  %t203 = getelementptr %"compiler/mir:Fn", ptr %t201, i32 0, i32 11
  %t204 = getelementptr %"compiler/mir:Range", ptr %l6, i32 0, i32 0
  %t205 = load i32, ptr %t204, !tbaa !23
  %t207 = sext i32 %t205 to i64
  %t208 = load i32, ptr %l25, !tbaa !23
  %t210 = sext i32 %t208 to i64
  %t213 = add i64 %t207, %t210
  %t216 = call { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %t203, i64 %t213)
  store { i64, [4 x i64] } %t216, ptr %l139
  br label %bb36
bb36:
  %t217 = load { i64, [4 x i64] }, ptr %l139
  store { i64, [4 x i64] } %t217, ptr %l26
  %t218 = load ptr, ptr %l0, !tbaa !29
  store ptr %t218, ptr %l140, !tbaa !29
  %t219 = load i64, ptr %l1, !tbaa !24
  store i64 %t219, ptr %l141, !tbaa !24
  %t220 = getelementptr %"compiler/eval:Ptr", ptr %l19, i32 0, i32 0
  %t221 = load i64, ptr %t220, !tbaa !24
  %t222 = load i32, ptr %l25, !tbaa !23
  %t224 = sext i32 %t222 to i64
  %t225 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t226 = load ptr, ptr %t225, !tbaa !27
  %t227 = getelementptr i64, ptr %t226, i64 %t224
  %t228 = load i64, ptr %t227, !tbaa !34
  %t231 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s6, i64 %t221, i64 %t228)
  store %"compiler/eval:Ptr" %t231, ptr %l145
  br label %bb37
bb37:
  %t232 = load i32, ptr %l25, !tbaa !23
  %t234 = sext i32 %t232 to i64
  %t235 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t236 = load ptr, ptr %t235, !tbaa !27
  %t237 = getelementptr i32, ptr %t236, i64 %t234
  %t238 = load i32, ptr %t237, !tbaa !33
  %t239 = load { i64, [4 x i64] }, ptr %l26
  %t240 = load ptr, ptr %l140, !tbaa !29
  %t241 = load i64, ptr %l141, !tbaa !24
  %t242 = load %"compiler/eval:Ptr", ptr %l145
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eput(ptr %v0, ptr %t240, i64 %t241, %"compiler/eval:Ptr" %t242, i32 %t238, { i64, [4 x i64] } %t239)
  br label %bb38
bb38:
  %t245 = load i64, ptr %l18, !tbaa !24
  store i64 %t245, ptr %l27, !tbaa !24
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t248 = load i32, ptr %l25, !tbaa !23
  %t250 = sext i32 %t248 to i64
  %t251 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t252 = load ptr, ptr %t251, !tbaa !27
  %t253 = getelementptr i32, ptr %t252, i64 %t250
  %t254 = load i32, ptr %t253, !tbaa !33
  %t257 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t247, i32 %t254)
  store i64 %t257, ptr %l153
  br label %bb39
bb39:
  %t258 = load i64, ptr @G_2ecompiler_2feval_2evPtr, !tbaa !24
  %t259 = load i64, ptr %l153, !tbaa !24
  %t261 = icmp eq i64 %t259, %t258
  br i1 %t261, label %bb40, label %bb41
bb40:
  store i1 true, ptr %l156, !tbaa !21
  br label %bb43
bb41:
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t264 = load i32, ptr %l25, !tbaa !23
  %t266 = sext i32 %t264 to i64
  %t267 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t268 = load ptr, ptr %t267, !tbaa !27
  %t269 = getelementptr i32, ptr %t268, i64 %t266
  %t270 = load i32, ptr %t269, !tbaa !33
  %t273 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t263, i32 %t270)
  store i64 %t273, ptr %l160
  br label %bb42
bb42:
  %t274 = load i64, ptr @G_2ecompiler_2feval_2evPair, !tbaa !24
  %t275 = load i64, ptr %l160, !tbaa !24
  %t277 = icmp eq i64 %t275, %t274
  store i1 %t277, ptr %l156, !tbaa !21
  br label %bb43
bb43:
  %t279 = load i1, ptr %l156, !tbaa !21
  br i1 %t279, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s7
  %t280 = load ptr, ptr %l0, !tbaa !29
  store ptr %t280, ptr %l163, !tbaa !29
  %t281 = getelementptr %"compiler/eval:Ptr", ptr %l19, i32 0, i32 0
  %t282 = load i64, ptr %t281, !tbaa !24
  store i64 %t282, ptr %l164, !tbaa !24
  %t283 = load i32, ptr %l25, !tbaa !23
  %t285 = sext i32 %t283 to i64
  %t286 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t287 = load ptr, ptr %t286, !tbaa !27
  %t288 = getelementptr i64, ptr %t287, i64 %t285
  %t289 = load i64, ptr %t288, !tbaa !34
  store i64 %t289, ptr %l166, !tbaa !24
  %t290 = load ptr, ptr %l0, !tbaa !29
  %t291 = load i32, ptr %l25, !tbaa !23
  %t293 = sext i32 %t291 to i64
  %t294 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t295 = load ptr, ptr %t294, !tbaa !27
  %t296 = getelementptr i32, ptr %t295, i64 %t293
  %t297 = load i32, ptr %t296, !tbaa !33
  %t300 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t290, i32 %t297)
  store i64 %t300, ptr %l170
  br label %bb46
bb45:
  br label %bb55
bb46:
  %t301 = load i64, ptr @G_2ecompiler_2feval_2evPair, !tbaa !24
  %t302 = load i64, ptr %l170, !tbaa !24
  %t304 = icmp eq i64 %t302, %t301
  br i1 %t304, label %bb47, label %bb48
bb47:
  store i64 8, ptr %l173, !tbaa !24
  br label %bb49
bb48:
  store i64 0, ptr %l173, !tbaa !24
  br label %bb49
bb49:
  %t306 = load i64, ptr %l166, !tbaa !24
  %t307 = load i64, ptr %l173, !tbaa !24
  %t308 = add i64 %t306, %t307
  %t309 = load i64, ptr %l164, !tbaa !24
  %t311 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s7, i64 %t309, i64 %t308)
  store %"compiler/eval:Ptr" %t311, ptr %l175
  br label %bb50
bb50:
  %t312 = load ptr, ptr %l163, !tbaa !29
  %t313 = load %"compiler/eval:Ptr", ptr %l175
  %t314 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtr(ptr %v0, ptr %t312, %"compiler/eval:Ptr" %t313)
  store %"compiler/eval:Ptr" %t314, ptr %l176
  br label %bb51
bb51:
  %t315 = load %"compiler/eval:Ptr", ptr %l176
  store %"compiler/eval:Ptr" %t315, ptr %l28
  %t316 = getelementptr %"compiler/eval:Ptr", ptr %l28, i32 0, i32 0
  %t317 = load i64, ptr %t316, !tbaa !24
  %t319 = icmp ne i64 %t317, 0
  br i1 %t319, label %bb52, label %bb53
bb52:
  %t321 = load ptr, ptr %l0, !tbaa !29
  %t323 = getelementptr %"compiler/eval:Machine", ptr %t321, i32 0, i32 50
  %t324 = load { i64, ptr }, ptr %t323, !tbaa !27
  store { i64, ptr } %t324, ptr %l180, !tbaa !27
  %t325 = getelementptr %"compiler/eval:Ptr", ptr %l28, i32 0, i32 0
  %t326 = load i64, ptr %t325, !tbaa !24
  %t327 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t330 = and i64 %t326, %t327
  %t332 = getelementptr { i64, ptr }, ptr %l180, i32 0, i32 1
  %t333 = load ptr, ptr %t332, !tbaa !27
  %t334 = getelementptr %"compiler/eval:alloc", ptr %t333, i64 %t330
  %t335 = getelementptr %"compiler/eval:alloc", ptr %t334, i32 0, i32 5
  %t336 = load i64, ptr %t335, !tbaa !24
  store i64 %t336, ptr %l27, !tbaa !24
  br label %bb54
bb53:
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s7)
  br label %bb55
bb55:
  %t338 = load ptr, ptr %l0, !tbaa !29
  store ptr %t338, ptr %l185, !tbaa !29
  %t339 = getelementptr %"compiler/eval:Ptr", ptr %l19, i32 0, i32 0
  %t340 = load i64, ptr %t339, !tbaa !24
  %t341 = load i64, ptr %l17, !tbaa !24
  %t342 = load i32, ptr %l25, !tbaa !23
  %t344 = mul i32 8, %t342
  %t346 = sext i32 %t344 to i64
  %t349 = add i64 %t341, %t346
  %t352 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s6, i64 %t340, i64 %t349)
  store %"compiler/eval:Ptr" %t352, ptr %l192
  br label %bb56
bb56:
  %t353 = load i64, ptr %l27, !tbaa !24
  %t354 = load ptr, ptr %l185, !tbaa !29
  %t355 = load %"compiler/eval:Ptr", ptr %l192
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t354, %"compiler/eval:Ptr" %t355, i64 8, i64 %t353)
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s6)
  br label %bb58
bb58:
  %t357 = load i32, ptr %l24, !tbaa !23
  %t360 = add i32 %t357, 1
  store i32 %t360, ptr %l24, !tbaa !23
  br label %bb32
bb59:
  store i64 -1, ptr %l29, !tbaa !24
  %t362 = load ptr, ptr %l0, !tbaa !29
  %t364 = getelementptr %"compiler/eval:Machine", ptr %t362, i32 0, i32 65
  %t365 = load i64, ptr %l4, !tbaa !24
  %t368 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t364, i64 %t365)
  %t369 = extractvalue { i32, i64 } %t368, 1
  %t370 = extractvalue { i32, i64 } %t368, 0
  store i32 %t370, ptr %l202
  %t371 = icmp ne i32 %t370, 0
  br i1 %t371, label %bb61, label %ok.372, !prof !99
ok.372:
  store i64 %t369, ptr %l201
  br label %bb60
bb60:
  %t373 = load i64, ptr %l201, !tbaa !24
  store i64 %t373, ptr %l197, !tbaa !24
  br label %bb63
bb61:
  br label %bb62
bb62:
  store i64 -1, ptr %l197, !tbaa !24
  br label %bb63
bb63:
  %t374 = load i64, ptr %l197, !tbaa !24
  store i64 %t374, ptr %l29, !tbaa !24
  %t375 = load i64, ptr %l29, !tbaa !24
  %t377 = icmp sge i64 %t375, 0
  br i1 %t377, label %bb64, label %bb65
bb64:
  store %olang.scope zeroinitializer, ptr %s10
  %t379 = load ptr, ptr %l0, !tbaa !29
  %t381 = getelementptr %"compiler/eval:Machine", ptr %t379, i32 0, i32 64
  %t382 = load i64, ptr %l29, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3agenRec_3e_2eAt_3ccompiler_2feval_3agenRec_3e(ptr %t383, ptr %v0, ptr %s10, ptr %t381, i64 %t382)
  call void @llvm.memmove.p0.p0.i64(ptr %l208, ptr %t383, i64 280, i1 false)
  br label %bb66
bb65:
  store %olang.scope zeroinitializer, ptr %s13
  %t386 = load ptr, ptr %l0, !tbaa !29
  %t388 = getelementptr %"compiler/eval:Machine", ptr %t386, i32 0, i32 64
  store ptr %t388, ptr %l237, !tbaa !29
  call void @compiler_2feval_3agenRec_2ector(ptr %t389, ptr %s13)
  call void @llvm.memmove.p0.p0.i64(ptr %l238, ptr %t389, i64 280, i1 false)
  br label %bb76
bb66:
  %t390 = getelementptr %"compiler/eval:genRec", ptr %l208, i32 0, i32 11
  %t391 = load i64, ptr %t390, !tbaa !24
  store i64 %t391, ptr %l30, !tbaa !24
  %t393 = load i64, ptr %l30, !tbaa !24
  %t395 = icmp sge i64 %t393, 0
  br i1 %t395, label %bb67, label %bb68
bb67:
  %t397 = load ptr, ptr %l0, !tbaa !29
  %t399 = getelementptr %"compiler/eval:Machine", ptr %t397, i32 0, i32 65
  %t400 = load i64, ptr %l4, !tbaa !24
  %t401 = load i64, ptr %l30, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t399, i64 %t400, i64 %t401)
  br label %bb69
bb68:
  %t405 = load ptr, ptr %l0, !tbaa !29
  %t407 = getelementptr %"compiler/eval:Machine", ptr %t405, i32 0, i32 65
  %t408 = load i64, ptr %l4, !tbaa !24
  %t411 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eRemove_3cI64_2c_20I64_3e(ptr %v0, ptr %t407, i64 %t408)
  store i1 %t411, ptr %l219
  br label %bb70
bb69:
  br label %bb71
bb70:
  br label %bb71
bb71:
  %t412 = load ptr, ptr %l0, !tbaa !29
  %t414 = getelementptr %"compiler/eval:Machine", ptr %t412, i32 0, i32 64
  %t415 = load i64, ptr %l29, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3agenRec_3e_2eAt_3ccompiler_2feval_3agenRec_3e(ptr %t416, ptr %v0, ptr %s10, ptr %t414, i64 %t415)
  call void @llvm.memmove.p0.p0.i64(ptr %l223, ptr %t416, i64 280, i1 false)
  br label %bb72
bb72:
  %t419 = getelementptr %"compiler/eval:genRec", ptr %l223, i32 0, i32 8
  %t420 = load i64, ptr %t419, !tbaa !24
  store i64 %t420, ptr %l31, !tbaa !24
  %t422 = load ptr, ptr %l0, !tbaa !29
  %t424 = getelementptr %"compiler/eval:Machine", ptr %t422, i32 0, i32 64
  store ptr %t424, ptr %l226, !tbaa !29
  %t425 = load i64, ptr %l29, !tbaa !24
  store i64 %t425, ptr %l227, !tbaa !24
  call void @compiler_2feval_3agenRec_2ector(ptr %t426, ptr %s10)
  call void @llvm.memmove.p0.p0.i64(ptr %l228, ptr %t426, i64 280, i1 false)
  br label %bb73
bb73:
  %t427 = load ptr, ptr %l226, !tbaa !29
  %t428 = load i64, ptr %l227, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %t429, ptr %l228, i64 280, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3agenRec_3e_2eSetAt_3ccompiler_2feval_3agenRec_3e(ptr %v0, ptr %s10, ptr %t427, i64 %t428, ptr %t429)
  br label %bb74
bb74:
  %t430 = load i64, ptr %l29, !tbaa !24
  %t432 = load ptr, ptr %l0, !tbaa !29
  %t434 = getelementptr %"compiler/eval:Machine", ptr %t432, i32 0, i32 64
  %t438 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3agenRec_3e_2eRefMut_3ccompiler_2feval_3agenRec_3e(ptr %v0, ptr %v0, ptr %t434, i64 %t430)
  store ptr %t438, ptr %l233
  br label %bb75
bb75:
  %t439 = load ptr, ptr %l233, !tbaa !29
  %t441 = load i64, ptr %l31, !tbaa !24
  %t444 = getelementptr %"compiler/eval:genRec", ptr %t439, i32 0, i32 8
  store i64 %t441, ptr %t444, !tbaa !24
  call void @__olang_scope_close(ptr %s10)
  br label %bb79
bb76:
  %t445 = load ptr, ptr %l237, !tbaa !29
  call void @llvm.memmove.p0.p0.i64(ptr %t446, ptr %l238, i64 280, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3agenRec_3e_2ePush_3ccompiler_2feval_3agenRec_3e(ptr %v0, ptr %s13, ptr %t445, ptr %t446)
  br label %bb77
bb77:
  %t447 = load ptr, ptr %l0, !tbaa !29
  %t449 = getelementptr %"compiler/eval:Machine", ptr %t447, i32 0, i32 64
  %t451 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3agenRec_3e_2eLen_3ccompiler_2feval_3agenRec_3e(ptr %v0, ptr %t449)
  store i64 %t451, ptr %l241
  br label %bb78
bb78:
  %t452 = load i64, ptr %l241, !tbaa !24
  %t453 = sub i64 %t452, 1
  store i64 %t453, ptr %l29, !tbaa !24
  call void @__olang_scope_close(ptr %s13)
  br label %bb79
bb79:
  %t455 = load i64, ptr %l29, !tbaa !24
  %t457 = load ptr, ptr %l0, !tbaa !29
  %t459 = getelementptr %"compiler/eval:Machine", ptr %t457, i32 0, i32 64
  %t463 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3agenRec_3e_2eRefMut_3ccompiler_2feval_3agenRec_3e(ptr %v0, ptr %v0, ptr %t459, i64 %t455)
  store ptr %t463, ptr %l247
  br label %bb80
bb80:
  %t464 = load ptr, ptr %l247, !tbaa !29
  %t466 = load i64, ptr %l4, !tbaa !24
  %t469 = getelementptr %"compiler/eval:genRec", ptr %t464, i32 0, i32 1
  store i64 %t466, ptr %t469, !tbaa !24
  %t470 = load i64, ptr %l29, !tbaa !24
  %t472 = load ptr, ptr %l0, !tbaa !29
  %t474 = getelementptr %"compiler/eval:Machine", ptr %t472, i32 0, i32 64
  %t478 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3agenRec_3e_2eRefMut_3ccompiler_2feval_3agenRec_3e(ptr %v0, ptr %v0, ptr %t474, i64 %t470)
  store ptr %t478, ptr %l254
  br label %bb81
bb81:
  %t479 = load ptr, ptr %l254, !tbaa !29
  %t481 = load %"compiler/eval:Ptr", ptr %l19
  %t484 = getelementptr %"compiler/eval:genRec", ptr %t479, i32 0, i32 4
  store %"compiler/eval:Ptr" %t481, ptr %t484
  %t485 = load ptr, ptr %l0, !tbaa !29
  store ptr %t485, ptr %l257, !tbaa !29
  %t486 = getelementptr %"compiler/eval:Ptr", ptr %l19, i32 0, i32 0
  %t487 = load i64, ptr %t486, !tbaa !24
  %t488 = load i64, ptr %l17, !tbaa !24
  %t489 = getelementptr %"compiler/mir:Range", ptr %l6, i32 0, i32 1
  %t490 = load i32, ptr %t489, !tbaa !23
  %t492 = sext i32 %t490 to i64
  %t494 = mul i64 8, %t492
  %t497 = add i64 %t488, %t494
  %t500 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s0, i64 %t487, i64 %t497)
  store %"compiler/eval:Ptr" %t500, ptr %l264
  br label %bb82
bb82:
  %t501 = load i64, ptr %l29, !tbaa !24
  %t502 = load ptr, ptr %l257, !tbaa !29
  %t503 = load %"compiler/eval:Ptr", ptr %l264
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t502, %"compiler/eval:Ptr" %t503, i64 8, i64 %t501)
  br label %bb83
bb83:
  %t505 = load ptr, ptr %l0, !tbaa !29
  %t506 = load i64, ptr %l18, !tbaa !24
  %t507 = load i64, ptr @G_2ecompiler_2feval_2egGen, !tbaa !24
  %t508 = load i64, ptr %l29, !tbaa !24
  %t509 = load %"compiler/eval:Ptr", ptr @G_2ecompiler_2feval_2eNullPtr
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddReg(ptr %v0, ptr %t505, i64 %t506, i64 %t507, i64 %t508, %"compiler/eval:Ptr" %t509)
  br label %bb84
bb84:
  %t515 = load ptr, ptr %l0, !tbaa !29
  %t516 = load %"compiler/eval:Ptr", ptr %l2
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrPtr(ptr %v0, ptr %t515, %"compiler/eval:Ptr" %t516, %"compiler/eval:Ptr" %a3)
  br label %bb85
bb85:
  %t521 = load ptr, ptr %l0, !tbaa !29
  store ptr %t521, ptr %l274, !tbaa !29
  %t522 = getelementptr %"compiler/eval:Ptr", ptr %l2, i32 0, i32 0
  %t523 = load i64, ptr %t522, !tbaa !24
  %t524 = getelementptr %"compiler/eval:Ptr", ptr %l2, i32 0, i32 1
  %t525 = load i64, ptr %t524, !tbaa !24
  %t527 = add i64 %t525, 8
  %t530 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s0, i64 %t523, i64 %t527)
  store %"compiler/eval:Ptr" %t530, ptr %l278
  br label %bb86
bb86:
  %t531 = load %"compiler/eval:Ptr", ptr %l19
  %t532 = load ptr, ptr %l274, !tbaa !29
  %t533 = load %"compiler/eval:Ptr", ptr %l278
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrPtr(ptr %v0, ptr %t532, %"compiler/eval:Ptr" %t533, %"compiler/eval:Ptr" %t531)
  br label %bb87
bb87:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2egenWalk(ptr %v0, ptr %v1, ptr %a0, %"compiler/eval:Ptr" %a1, i32 %a2, i1 %a3, ptr %a4c, ptr %a4e) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/eval:Ptr"
  %l4 = alloca { ptr, ptr }
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca { %"compiler/eval:Ptr", i64 }
  %l9 = alloca %"compiler/eval:Ptr"
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i32
  %l30 = alloca i32
  %l33 = alloca i1
  %l38 = alloca i1
  %l42 = alloca i32
  %l45 = alloca { ptr, ptr }
  %l48 = alloca %"compiler/eval:Ptr"
  %l53 = alloca i32
  %l55 = alloca i1
  %l61 = alloca { %"compiler/eval:Ptr", i64 }
  %l64 = alloca ptr
  %l67 = alloca i32
  %l68 = alloca i64
  %l73 = alloca i64
  %l76 = alloca i64
  %l94 = alloca ptr
  %l101 = alloca %"compiler/eval:Ptr"
  %l104 = alloca i32
  %l111 = alloca i1
  %l112 = alloca ptr
  %l115 = alloca i32
  %l116 = alloca { i64, ptr }
  %l122 = alloca i64
  %l125 = alloca i64
  %l148 = alloca i1
  %l150 = alloca ptr
  %l151 = alloca i64
  %l152 = alloca i64
  %l156 = alloca i64
  %l158 = alloca %"compiler/eval:Ptr"
  %l159 = alloca { i64, ptr }
  %l168 = alloca i1
  %l170 = alloca ptr
  %l171 = alloca i32
  %l174 = alloca i64
  %l175 = alloca i32
  %l178 = alloca ptr
  %l182 = alloca %"compiler/eval:Ptr"
  %s6 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s14 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/eval:Ptr" %a1, ptr %l1
  %pf4 = insertvalue { ptr, ptr } undef, ptr %a4c, 0
  %pg4 = insertvalue { ptr, ptr } %pf4, ptr %a4e, 1
  store { ptr, ptr } %pg4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l5, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a2)
  store i32 %t10, ptr %l30
  br label %bb1
bb1:
  %t11 = load i32, ptr %l30, !tbaa !23
  store i32 %t11, ptr %l6, !tbaa !23
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/eval:Machine", ptr %t12, i32 0, i32 23
  %t15 = load i1, ptr %t14, !tbaa !21
  br i1 %t15, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb5
bb3:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/eval:Machine", ptr %t17, i32 0, i32 6
  %t20 = load ptr, ptr %l5, !tbaa !29
  %t21 = load i32, ptr %l6, !tbaa !23
  %t25 = call i1 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eHoldsGen(ptr %v0, ptr %v0, ptr %t19, ptr %t20, i32 %t21)
  store i1 %t25, ptr %l38
  br label %bb4
bb4:
  %t26 = load i1, ptr %l38, !tbaa !21
  %t27 = xor i1 %t26, true
  store i1 %t27, ptr %l33, !tbaa !21
  br label %bb5
bb5:
  %t29 = load i1, ptr %l33, !tbaa !21
  br i1 %t29, label %bb6, label %bb7
bb6:
  br label %ret
bb7:
  br label %bb8
bb8:
  %t30 = load ptr, ptr %l5, !tbaa !29
  %t31 = load i32, ptr %l6, !tbaa !23
  %t34 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t30, i32 %t31)
  store i32 %t34, ptr %l42
  br label %bb9
bb9:
  %t35 = load i32, ptr %l42, !range !{i32 0, i32 33}
  store i32 %t35, ptr %l7
  %t36 = load i32, ptr %l7, !range !{i32 0, i32 33}
  %t38 = trunc i64 20 to i32
  %t39 = icmp eq i32 %t36, %t38
  br i1 %t39, label %bb10, label %bb11
bb10:
  %t41 = load { ptr, ptr }, ptr %l4
  store { ptr, ptr } %t41, ptr %l45
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load %"compiler/eval:Ptr", ptr %l1
  %t46 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtr(ptr %v0, ptr %t42, %"compiler/eval:Ptr" %t43)
  store %"compiler/eval:Ptr" %t46, ptr %l48
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t47 = load { ptr, ptr }, ptr %l45
  %t48 = extractvalue { ptr, ptr } %t47, 0
  %t49 = extractvalue { ptr, ptr } %t47, 1
  %t50 = load %"compiler/eval:Ptr", ptr %l48
  call void %t48(ptr %t49, %"compiler/eval:Ptr" %t50)
  br label %bb13
bb13:
  br label %ret
bb14:
  %t51 = load i32, ptr %l7, !range !{i32 0, i32 33}
  %t53 = trunc i64 19 to i32
  %t54 = icmp eq i32 %t51, %t53
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t56 = load ptr, ptr %l5, !tbaa !29
  %t57 = load i32, ptr %l6, !tbaa !23
  %t60 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t56, i32 %t57)
  store i32 %t60, ptr %l53
  br label %bb17
bb16:
  br label %bb42
bb17:
  %t61 = load i32, ptr %l53, !tbaa !23
  %t62 = icmp eq i32 %t61, 0
  br i1 %t62, label %bb18, label %bb19
bb18:
  %t66 = xor i1 %a3, true
  store i1 %t66, ptr %l55, !tbaa !21
  br label %bb20
bb19:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb20
bb20:
  %t68 = load i1, ptr %l55, !tbaa !21
  br i1 %t68, label %bb21, label %bb22
bb21:
  br label %ret
bb22:
  br label %bb23
bb23:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load %"compiler/eval:Ptr", ptr %l1
  %t71 = load i32, ptr %l6, !tbaa !23
  %t75 = call { %"compiler/eval:Ptr", i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2earrayView(ptr %v0, ptr %t69, %"compiler/eval:Ptr" %t70, i32 %t71)
  store { %"compiler/eval:Ptr", i64 } %t75, ptr %l61
  br label %bb24
bb24:
  %t76 = load { %"compiler/eval:Ptr", i64 }, ptr %l61
  store { %"compiler/eval:Ptr", i64 } %t76, ptr %l8
  %t77 = getelementptr { %"compiler/eval:Ptr", i64 }, ptr %l8, i32 0, i32 0
  %t78 = load %"compiler/eval:Ptr", ptr %t77
  store %"compiler/eval:Ptr" %t78, ptr %l9
  %t80 = getelementptr { %"compiler/eval:Ptr", i64 }, ptr %l8, i32 0, i32 1
  %t81 = load i64, ptr %t80, !tbaa !24
  store i64 %t81, ptr %l10, !tbaa !24
  %t83 = load ptr, ptr %l0, !tbaa !29
  store ptr %t83, ptr %l64, !tbaa !29
  %t84 = load ptr, ptr %l5, !tbaa !29
  %t85 = load i32, ptr %l6, !tbaa !23
  %t88 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t84, i32 %t85)
  store i32 %t88, ptr %l67
  br label %bb25
bb25:
  %t89 = load ptr, ptr %l64, !tbaa !29
  %t90 = load i32, ptr %l67, !tbaa !23
  %t91 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t89, i32 %t90)
  store i64 %t91, ptr %l68
  br label %bb26
bb26:
  %t92 = load i64, ptr %l68, !tbaa !24
  store i64 %t92, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  %t93 = load i64, ptr %l10, !tbaa !24
  store i64 %t93, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t95 = load i64, ptr %l13, !tbaa !24
  %t96 = load i64, ptr %l12, !tbaa !24
  %t99 = icmp sgt i64 %t95, %t96
  br i1 %t99, label %bb27, label %bb28
bb27:
  %t101 = load i64, ptr %l14, !tbaa !24
  %t103 = icmp sgt i64 %t101, 0
  br i1 %t103, label %bb29, label %bb30
bb28:
  store i64 0, ptr %l73, !tbaa !24
  br label %bb32
bb29:
  %t105 = load i64, ptr %l13, !tbaa !24
  %t106 = load i64, ptr %l12, !tbaa !24
  %t109 = sub i64 %t105, %t106
  %t110 = load i64, ptr %l14, !tbaa !24
  %t113 = add i64 %t109, %t110
  %t115 = sub i64 %t113, 1
  %t116 = load i64, ptr %l14, !tbaa !24
  %t119 = sdiv i64 %t115, %t116
  store i64 %t119, ptr %l76, !tbaa !24
  br label %bb31
bb30:
  store i64 0, ptr %l76, !tbaa !24
  br label %bb31
bb31:
  %t121 = load i64, ptr %l76, !tbaa !24
  store i64 %t121, ptr %l73, !tbaa !24
  br label %bb32
bb32:
  %t122 = load i64, ptr %l73, !tbaa !24
  store i64 %t122, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb33
bb33:
  store %olang.scope zeroinitializer, ptr %s6
  %t123 = load i64, ptr %l16, !tbaa !24
  %t124 = load i64, ptr %l15, !tbaa !24
  %t127 = icmp slt i64 %t123, %t124
  %t129 = xor i1 %t127, true
  br i1 %t129, label %bb34, label %bb35
bb34:
  call void @__olang_scope_close(ptr %s6)
  br label %bb41
bb35:
  br label %bb36
bb36:
  %t131 = load i64, ptr %l12, !tbaa !24
  %t132 = load i64, ptr %l16, !tbaa !24
  %t133 = load i64, ptr %l14, !tbaa !24
  %t136 = mul i64 %t132, %t133
  %t139 = add i64 %t131, %t136
  %t141 = load ptr, ptr %l0, !tbaa !29
  store ptr %t141, ptr %l94, !tbaa !29
  %t142 = getelementptr %"compiler/eval:Ptr", ptr %l9, i32 0, i32 0
  %t143 = load i64, ptr %t142, !tbaa !24
  %t144 = getelementptr %"compiler/eval:Ptr", ptr %l9, i32 0, i32 1
  %t145 = load i64, ptr %t144, !tbaa !24
  %t147 = load i64, ptr %l11, !tbaa !24
  %t150 = mul i64 %t139, %t147
  %t153 = add i64 %t145, %t150
  %t156 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s6, i64 %t143, i64 %t153)
  store %"compiler/eval:Ptr" %t156, ptr %l101
  br label %bb37
bb37:
  %t157 = load ptr, ptr %l5, !tbaa !29
  %t158 = load i32, ptr %l6, !tbaa !23
  %t161 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t157, i32 %t158)
  store i32 %t161, ptr %l104
  br label %bb38
bb38:
  %t162 = load { ptr, ptr }, ptr %l4
  %t163 = load ptr, ptr %l94, !tbaa !29
  %t164 = load %"compiler/eval:Ptr", ptr %l101
  %t165 = load i32, ptr %l104, !tbaa !23
  %t167 = extractvalue { ptr, ptr } %t162, 0
  %t168 = extractvalue { ptr, ptr } %t162, 1
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2egenWalk(ptr %v0, ptr %v1, ptr %t163, %"compiler/eval:Ptr" %t164, i32 %t165, i1 false, ptr %t167, ptr %t168)
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s6)
  br label %bb40
bb40:
  %t169 = load i64, ptr %l16, !tbaa !24
  %t172 = add i64 %t169, 1
  store i64 %t172, ptr %l16, !tbaa !24
  br label %bb33
bb41:
  br label %ret
bb42:
  %t174 = load ptr, ptr %l5, !tbaa !29
  %t175 = load i32, ptr %l6, !tbaa !23
  %t178 = call i1 @compiler_2fmir_2eHasFields(ptr %v0, ptr %t174, i32 %t175)
  store i1 %t178, ptr %l111
  br label %bb43
bb43:
  %t179 = load i1, ptr %l111, !tbaa !21
  br i1 %t179, label %bb44, label %bb45
bb44:
  %t180 = load ptr, ptr %l5, !tbaa !29
  store ptr %t180, ptr %l112, !tbaa !29
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t182 = load i32, ptr %l6, !tbaa !23
  %t185 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2epartList(ptr %v0, ptr %t181, i32 %t182)
  store i32 %t185, ptr %l115
  br label %bb46
bb45:
  br label %bb67
bb46:
  %t186 = load ptr, ptr %l112, !tbaa !29
  %t187 = load i32, ptr %l115, !tbaa !23
  %t188 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t186, i32 %t187)
  store { i64, ptr } %t188, ptr %l116
  br label %bb47
bb47:
  %t189 = load { i64, ptr }, ptr %l116, !tbaa !27
  store { i64, ptr } %t189, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t190 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t192 = extractvalue { i64, ptr } %t190, 0
  store i64 %t192, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t194 = load i64, ptr %l20, !tbaa !24
  %t195 = load i64, ptr %l19, !tbaa !24
  %t198 = icmp sgt i64 %t194, %t195
  br i1 %t198, label %bb48, label %bb49
bb48:
  %t200 = load i64, ptr %l21, !tbaa !24
  %t202 = icmp sgt i64 %t200, 0
  br i1 %t202, label %bb50, label %bb51
bb49:
  store i64 0, ptr %l122, !tbaa !24
  br label %bb53
bb50:
  %t204 = load i64, ptr %l20, !tbaa !24
  %t205 = load i64, ptr %l19, !tbaa !24
  %t208 = sub i64 %t204, %t205
  %t209 = load i64, ptr %l21, !tbaa !24
  %t212 = add i64 %t208, %t209
  %t214 = sub i64 %t212, 1
  %t215 = load i64, ptr %l21, !tbaa !24
  %t218 = sdiv i64 %t214, %t215
  store i64 %t218, ptr %l125, !tbaa !24
  br label %bb52
bb51:
  store i64 0, ptr %l125, !tbaa !24
  br label %bb52
bb52:
  %t220 = load i64, ptr %l125, !tbaa !24
  store i64 %t220, ptr %l122, !tbaa !24
  br label %bb53
bb53:
  %t221 = load i64, ptr %l122, !tbaa !24
  store i64 %t221, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb54
bb54:
  %t222 = load i64, ptr %l23, !tbaa !24
  %t223 = load i64, ptr %l22, !tbaa !24
  %t226 = icmp slt i64 %t222, %t223
  %t228 = xor i1 %t226, true
  br i1 %t228, label %bb55, label %bb56
bb55:
  br label %bb66
bb56:
  br label %bb57
bb57:
  %t230 = load i64, ptr %l19, !tbaa !24
  %t231 = load i64, ptr %l23, !tbaa !24
  %t232 = load i64, ptr %l21, !tbaa !24
  %t235 = mul i64 %t231, %t232
  %t238 = add i64 %t230, %t235
  store i64 %t238, ptr %l24, !tbaa !24
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t242 = getelementptr %"compiler/eval:Machine", ptr %t240, i32 0, i32 6
  %t243 = load ptr, ptr %l5, !tbaa !29
  %t244 = load i32, ptr %l6, !tbaa !23
  %t245 = load i64, ptr %l24, !tbaa !24
  %t250 = call i1 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eWeakField(ptr %v0, ptr %v0, ptr %t242, ptr %t243, i32 %t244, i64 %t245)
  store i1 %t250, ptr %l148
  br label %bb58
bb58:
  %t251 = load i1, ptr %l148, !tbaa !21
  %t252 = xor i1 %t251, true
  br i1 %t252, label %bb59, label %bb60
bb59:
  store %olang.scope zeroinitializer, ptr %s11
  %t254 = load ptr, ptr %l0, !tbaa !29
  store ptr %t254, ptr %l150, !tbaa !29
  %t255 = getelementptr %"compiler/eval:Ptr", ptr %l1, i32 0, i32 0
  %t256 = load i64, ptr %t255, !tbaa !24
  store i64 %t256, ptr %l151, !tbaa !24
  %t257 = getelementptr %"compiler/eval:Ptr", ptr %l1, i32 0, i32 1
  %t258 = load i64, ptr %t257, !tbaa !24
  store i64 %t258, ptr %l152, !tbaa !24
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t260 = load i32, ptr %l6, !tbaa !23
  %t261 = load i64, ptr %l24, !tbaa !24
  %t265 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2epartOffset(ptr %v0, ptr %t259, i32 %t260, i64 %t261)
  store i64 %t265, ptr %l156
  br label %bb61
bb60:
  br label %bb64
bb61:
  %t266 = load i64, ptr %l152, !tbaa !24
  %t267 = load i64, ptr %l156, !tbaa !24
  %t268 = add i64 %t266, %t267
  %t269 = load i64, ptr %l151, !tbaa !24
  %t271 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s11, i64 %t269, i64 %t268)
  store %"compiler/eval:Ptr" %t271, ptr %l158
  br label %bb62
bb62:
  %t272 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t272, ptr %l159, !tbaa !27
  %t273 = load i64, ptr %l24, !tbaa !24
  %t275 = getelementptr { i64, ptr }, ptr %l159, i32 0, i32 1
  %t276 = load ptr, ptr %t275, !tbaa !27
  %t277 = getelementptr i32, ptr %t276, i64 %t273
  %t278 = load i32, ptr %t277, !tbaa !33
  %t279 = load { ptr, ptr }, ptr %l4
  %t280 = load ptr, ptr %l150, !tbaa !29
  %t281 = load %"compiler/eval:Ptr", ptr %l158
  %t284 = extractvalue { ptr, ptr } %t279, 0
  %t285 = extractvalue { ptr, ptr } %t279, 1
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2egenWalk(ptr %v0, ptr %v1, ptr %t280, %"compiler/eval:Ptr" %t281, i32 %t278, i1 false, ptr %t284, ptr %t285)
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s11)
  br label %bb64
bb64:
  br label %bb65
bb65:
  %t286 = load i64, ptr %l23, !tbaa !24
  %t289 = add i64 %t286, 1
  store i64 %t289, ptr %l23, !tbaa !24
  br label %bb54
bb66:
  br label %ret
bb67:
  %t291 = load ptr, ptr %l5, !tbaa !29
  %t292 = load i32, ptr %l6, !tbaa !23
  %t295 = call i1 @compiler_2fmir_2eHasCases(ptr %v0, ptr %t291, i32 %t292)
  store i1 %t295, ptr %l168
  br label %bb68
bb68:
  %t296 = load i1, ptr %l168, !tbaa !21
  %t297 = xor i1 %t296, true
  br i1 %t297, label %bb69, label %bb70
bb69:
  br label %ret
bb70:
  br label %bb71
bb71:
  %t299 = load ptr, ptr %l0, !tbaa !29
  store ptr %t299, ptr %l170, !tbaa !29
  %t300 = load i32, ptr %l6, !tbaa !23
  store i32 %t300, ptr %l171, !tbaa !23
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t302 = load %"compiler/eval:Ptr", ptr %l1
  %t305 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t301, %"compiler/eval:Ptr" %t302, i64 8)
  store i64 %t305, ptr %l174
  br label %bb72
bb72:
  %t306 = load ptr, ptr %l170, !tbaa !29
  %t307 = load i32, ptr %l171, !tbaa !23
  %t308 = load i64, ptr %l174, !tbaa !24
  %t309 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2epayloadType(ptr %v0, ptr %t306, i32 %t307, i64 %t308)
  store i32 %t309, ptr %l175
  br label %bb73
bb73:
  %t310 = load i32, ptr %l175, !tbaa !23
  store i32 %t310, ptr %l25, !tbaa !23
  %t311 = load i32, ptr %l25, !tbaa !23
  %t313 = icmp ne i32 %t311, 0
  br i1 %t313, label %bb74, label %bb75
bb74:
  store %olang.scope zeroinitializer, ptr %s14
  %t315 = load ptr, ptr %l0, !tbaa !29
  store ptr %t315, ptr %l178, !tbaa !29
  %t316 = getelementptr %"compiler/eval:Ptr", ptr %l1, i32 0, i32 0
  %t317 = load i64, ptr %t316, !tbaa !24
  %t318 = getelementptr %"compiler/eval:Ptr", ptr %l1, i32 0, i32 1
  %t319 = load i64, ptr %t318, !tbaa !24
  %t321 = add i64 %t319, 8
  %t324 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s14, i64 %t317, i64 %t321)
  store %"compiler/eval:Ptr" %t324, ptr %l182
  br label %bb76
bb75:
  br label %bb78
bb76:
  %t325 = load i32, ptr %l25, !tbaa !23
  %t326 = load { ptr, ptr }, ptr %l4
  %t327 = load ptr, ptr %l178, !tbaa !29
  %t328 = load %"compiler/eval:Ptr", ptr %l182
  %t331 = extractvalue { ptr, ptr } %t326, 0
  %t332 = extractvalue { ptr, ptr } %t326, 1
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2egenWalk(ptr %v0, ptr %v1, ptr %t327, %"compiler/eval:Ptr" %t328, i32 %t325, i1 false, ptr %t331, ptr %t332)
  br label %bb77
bb77:
  call void @__olang_scope_close(ptr %s14)
  br label %bb78
bb78:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintOp(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i64 %a3, i32 %a4, i32 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i1
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l20 = alloca i64
  %l26 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l33 = alloca i64
  %l36 = alloca i64
  %l38 = alloca i64
  %l42 = alloca i64
  %l70 = alloca i1
  %l79 = alloca i64
  %l88 = alloca i64
  %l104 = alloca i64
  %l107 = alloca i64
  %l110 = alloca i1
  %l113 = alloca i64
  %l115 = alloca i1
  %l120 = alloca i1
  %l130 = alloca i64
  %l134 = alloca i64
  %l138 = alloca i64
  %l161 = alloca i64
  %l167 = alloca i64
  %l171 = alloca i1
  %l178 = alloca i64
  %l182 = alloca i1
  %l189 = alloca i64
  %l193 = alloca i1
  %l200 = alloca i64
  %l204 = alloca i1
  %l211 = alloca i64
  %l213 = alloca i64
  %l214 = alloca i64
  %l216 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i32 %a4, ptr %l4
  store i32 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l4, !tbaa !23
  %t5 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eibits(ptr %v0, ptr %t1, i32 %t2)
  store i64 %t5, ptr %l17
  br label %bb1
bb1:
  %t6 = load i64, ptr %l17, !tbaa !24
  store i64 %t6, ptr %l6, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l4, !tbaa !23
  %t11 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t7, i32 %t8)
  store i64 %t11, ptr %l20
  br label %bb2
bb2:
  %t12 = load i64, ptr @G_2ecompiler_2feval_2evInt, !tbaa !24
  %t13 = load i64, ptr %l20, !tbaa !24
  %t15 = icmp eq i64 %t13, %t12
  store i1 %t15, ptr %l7, !tbaa !21
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load i64, ptr %l2, !tbaa !24
  %t19 = load i32, ptr %l4, !tbaa !23
  %t23 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintValue(ptr %v0, ptr %t17, i64 %t18, i32 %t19)
  store i64 %t23, ptr %l26
  br label %bb3
bb3:
  %t24 = load i64, ptr %l26, !tbaa !24
  store i64 %t24, ptr %l8, !tbaa !24
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i64, ptr %l3, !tbaa !24
  %t27 = load i32, ptr %l4, !tbaa !23
  %t31 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintValue(ptr %v0, ptr %t25, i64 %t26, i32 %t27)
  store i64 %t31, ptr %l30
  br label %bb4
bb4:
  %t32 = load i64, ptr %l30, !tbaa !24
  store i64 %t32, ptr %l9, !tbaa !24
  %t33 = load i64, ptr %l2, !tbaa !24
  store i64 %t33, ptr %l31, !tbaa !24
  %t34 = load i64, ptr %l6, !tbaa !24
  %t36 = call i64 @compiler_2feval_2ebmask(i64 %t34)
  store i64 %t36, ptr %l33
  br label %bb5
bb5:
  %t37 = load i64, ptr %l31, !tbaa !24
  %t38 = load i64, ptr %l33, !tbaa !24
  %t39 = and i64 %t37, %t38
  store i64 %t39, ptr %l10, !tbaa !65
  %t42 = load i64, ptr %l3, !tbaa !24
  store i64 %t42, ptr %l36, !tbaa !24
  %t43 = load i64, ptr %l6, !tbaa !24
  %t45 = call i64 @compiler_2feval_2ebmask(i64 %t43)
  store i64 %t45, ptr %l38
  br label %bb6
bb6:
  %t46 = load i64, ptr %l36, !tbaa !24
  %t47 = load i64, ptr %l38, !tbaa !24
  %t48 = and i64 %t46, %t47
  store i64 %t48, ptr %l11, !tbaa !65
  %t51 = load i64, ptr %l6, !tbaa !24
  %t53 = call i64 @compiler_2feval_2eminBits(i64 %t51)
  store i64 %t53, ptr %l42
  br label %bb7
bb7:
  %t54 = load i64, ptr %l42, !tbaa !24
  store i64 %t54, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  %t55 = load i32, ptr %l1, !range !{i32 0, i32 54}
  %t57 = trunc i64 3 to i32
  %t58 = icmp eq i32 %t55, %t57
  br i1 %t58, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t60 = load i64, ptr %l8, !tbaa !24
  %t61 = load i64, ptr %l9, !tbaa !24
  %t64 = add i64 %t60, %t61
  store i64 %t64, ptr %l13, !tbaa !24
  br label %bb148
bb11:
  %t66 = load i32, ptr %l1, !range !{i32 0, i32 54}
  %t68 = trunc i64 4 to i32
  %t69 = icmp eq i32 %t66, %t68
  br i1 %t69, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  %t71 = load i64, ptr %l8, !tbaa !24
  %t72 = load i64, ptr %l9, !tbaa !24
  %t75 = sub i64 %t71, %t72
  store i64 %t75, ptr %l13, !tbaa !24
  br label %bb148
bb15:
  %t77 = load i32, ptr %l1, !range !{i32 0, i32 54}
  %t79 = trunc i64 5 to i32
  %t80 = icmp eq i32 %t77, %t79
  br i1 %t80, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  %t82 = load i64, ptr %l8, !tbaa !24
  %t83 = load i64, ptr %l9, !tbaa !24
  %t86 = mul i64 %t82, %t83
  store i64 %t86, ptr %l13, !tbaa !24
  br label %bb148
bb19:
  %t88 = load i32, ptr %l1, !range !{i32 0, i32 54}
  %t90 = trunc i64 6 to i32
  %t91 = icmp eq i32 %t88, %t90
  br i1 %t91, label %bb20, label %bb21
bb20:
  br label %bb24
bb21:
  %t93 = load i32, ptr %l1, !range !{i32 0, i32 54}
  %t95 = trunc i64 7 to i32
  %t96 = icmp eq i32 %t93, %t95
  br i1 %t96, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb45
bb24:
  %t98 = load i64, ptr %l9, !tbaa !24
  %t100 = icmp eq i64 %t98, 0
  br i1 %t100, label %bb25, label %bb26
bb25:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyDivZero, !tbaa !27
  %t104 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t104, ptr %t102, { i64, ptr } %t103)
  br label %bb27
bb26:
  br label %bb28
bb27:
  store i64 0, ptr %rv
  br label %ret
bb28:
  %t108 = load i1, ptr %l7, !tbaa !21
  br i1 %t108, label %bb29, label %bb30
bb29:
  %t110 = load i64, ptr %l9, !tbaa !24
  %t112 = icmp eq i64 %t110, -1
  br i1 %t112, label %bb31, label %bb32
bb30:
  %t114 = load i32, ptr %l1, !range !{i32 0, i32 54}
  %t116 = trunc i64 6 to i32
  %t117 = icmp eq i32 %t114, %t116
  br i1 %t117, label %bb41, label %bb42
bb31:
  %t119 = load i64, ptr %l8, !tbaa !24
  %t120 = load i64, ptr %l12, !tbaa !24
  %t123 = icmp eq i64 %t119, %t120
  store i1 %t123, ptr %l70, !tbaa !21
  br label %bb33
bb32:
  store i1 false, ptr %l70, !tbaa !21
  br label %bb33
bb33:
  %t125 = load i1, ptr %l70, !tbaa !21
  br i1 %t125, label %bb34, label %bb35
bb34:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyDivMin, !tbaa !27
  %t128 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t128, ptr %t126, { i64, ptr } %t127)
  br label %bb36
bb35:
  br label %bb37
bb36:
  store i64 0, ptr %rv
  br label %ret
bb37:
  %t132 = load i32, ptr %l1, !range !{i32 0, i32 54}
  %t134 = trunc i64 6 to i32
  %t135 = icmp eq i32 %t132, %t134
  br i1 %t135, label %bb38, label %bb39
bb38:
  %t137 = load i64, ptr %l8, !tbaa !24
  %t138 = load i64, ptr %l9, !tbaa !24
  %t141 = sdiv i64 %t137, %t138
  store i64 %t141, ptr %l79, !tbaa !24
  br label %bb40
bb39:
  %t143 = load i64, ptr %l8, !tbaa !24
  %t144 = load i64, ptr %l9, !tbaa !24
  %t147 = srem i64 %t143, %t144
  store i64 %t147, ptr %l79, !tbaa !24
  br label %bb40
bb40:
  %t149 = load i64, ptr %l79, !tbaa !24
  store i64 %t149, ptr %l13, !tbaa !24
  br label %bb44
bb41:
  %t150 = load i64, ptr %l10, !tbaa !65
  %t151 = load i64, ptr %l11, !tbaa !65
  %t154 = udiv i64 %t150, %t151
  store i64 %t154, ptr %l88, !tbaa !24
  br label %bb43
bb42:
  %t157 = load i64, ptr %l10, !tbaa !65
  %t158 = load i64, ptr %l11, !tbaa !65
  %t161 = urem i64 %t157, %t158
  store i64 %t161, ptr %l88, !tbaa !24
  br label %bb43
bb43:
  %t164 = load i64, ptr %l88, !tbaa !24
  store i64 %t164, ptr %l13, !tbaa !24
  br label %bb44
bb44:
  br label %bb148
bb45:
  %t165 = load i32, ptr %l1, !range !{i32 0, i32 54}
  %t167 = trunc i64 8 to i32
  %t168 = icmp eq i32 %t165, %t167
  br i1 %t168, label %bb46, label %bb47
bb46:
  br label %bb50
bb47:
  %t170 = load i32, ptr %l1, !range !{i32 0, i32 54}
  %t172 = trunc i64 9 to i32
  %t173 = icmp eq i32 %t170, %t172
  br i1 %t173, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb76
bb50:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t176 = load i64, ptr %l3, !tbaa !24
  %t177 = load i32, ptr %l5, !tbaa !23
  %t181 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintValue(ptr %v0, ptr %t175, i64 %t176, i32 %t177)
  store i64 %t181, ptr %l104
  br label %bb51
bb51:
  %t182 = load i64, ptr %l104, !tbaa !24
  store i64 %t182, ptr %l14, !tbaa !24
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t184 = load i32, ptr %l5, !tbaa !23
  %t187 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t183, i32 %t184)
  store i64 %t187, ptr %l107
  br label %bb52
bb52:
  %t188 = load i64, ptr @G_2ecompiler_2feval_2evUint, !tbaa !24
  %t189 = load i64, ptr %l107, !tbaa !24
  %t191 = icmp eq i64 %t189, %t188
  br i1 %t191, label %bb53, label %bb54
bb53:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = load i32, ptr %l5, !tbaa !23
  %t197 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eibits(ptr %v0, ptr %t193, i32 %t194)
  store i64 %t197, ptr %l113
  br label %bb55
bb54:
  store i1 false, ptr %l110, !tbaa !21
  br label %bb56
bb55:
  %t198 = load i64, ptr %l113, !tbaa !24
  %t199 = icmp eq i64 %t198, 64
  store i1 %t199, ptr %l110, !tbaa !21
  br label %bb56
bb56:
  %t201 = load i1, ptr %l110, !tbaa !21
  br i1 %t201, label %bb57, label %bb58
bb57:
  %t202 = load i64, ptr %l3, !tbaa !24
  %t204 = icmp slt i64 %t202, 0
  store i1 %t204, ptr %l115, !tbaa !21
  br label %bb59
bb58:
  store i1 false, ptr %l115, !tbaa !21
  br label %bb59
bb59:
  %t206 = load i1, ptr %l115, !tbaa !21
  br i1 %t206, label %bb60, label %bb61
bb60:
  store i64 64, ptr %l14, !tbaa !24
  br label %bb62
bb61:
  br label %bb62
bb62:
  %t207 = load i64, ptr %l14, !tbaa !24
  %t209 = icmp slt i64 %t207, 0
  br i1 %t209, label %bb63, label %bb64
bb63:
  store i1 true, ptr %l120, !tbaa !21
  br label %bb65
bb64:
  %t211 = load i64, ptr %l14, !tbaa !24
  %t212 = load i64, ptr %l6, !tbaa !24
  %t215 = icmp sge i64 %t211, %t212
  store i1 %t215, ptr %l120, !tbaa !21
  br label %bb65
bb65:
  %t217 = load i1, ptr %l120, !tbaa !21
  br i1 %t217, label %bb66, label %bb67
bb66:
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t219 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyShift, !tbaa !27
  %t220 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t220, ptr %t218, { i64, ptr } %t219)
  br label %bb68
bb67:
  br label %bb69
bb68:
  store i64 0, ptr %rv
  br label %ret
bb69:
  %t224 = load i32, ptr %l1, !range !{i32 0, i32 54}
  %t226 = trunc i64 8 to i32
  %t227 = icmp eq i32 %t224, %t226
  br i1 %t227, label %bb70, label %bb71
bb70:
  %t229 = load i64, ptr %l8, !tbaa !24
  %t230 = load i64, ptr %l14, !tbaa !24
  store i64 %t230, ptr %l130, !tbaa !24
  %t232 = load i64, ptr %l130, !tbaa !24
  %t233 = load i64, ptr %l130, !tbaa !24
  %t234 = shl i64 %t229, %t233
  store i64 %t234, ptr %l13, !tbaa !24
  br label %bb75
bb71:
  %t236 = load i1, ptr %l7, !tbaa !21
  br i1 %t236, label %bb72, label %bb73
bb72:
  %t238 = load i64, ptr %l8, !tbaa !24
  %t239 = load i64, ptr %l14, !tbaa !24
  store i64 %t239, ptr %l134, !tbaa !24
  %t241 = load i64, ptr %l134, !tbaa !24
  %t242 = load i64, ptr %l134, !tbaa !24
  %t243 = ashr i64 %t238, %t242
  store i64 %t243, ptr %l13, !tbaa !24
  br label %bb74
bb73:
  %t245 = load i64, ptr %l10, !tbaa !65
  %t246 = load i64, ptr %l14, !tbaa !24
  store i64 %t246, ptr %l138, !tbaa !65
  %t249 = load i64, ptr %l138, !tbaa !65
  %t250 = load i64, ptr %l138, !tbaa !65
  %t251 = lshr i64 %t245, %t250
  store i64 %t251, ptr %l13, !tbaa !24
  br label %bb74
bb74:
  br label %bb75
bb75:
  br label %bb148
bb76:
  %t254 = load i32, ptr %l1, !range !{i32 0, i32 54}
  %t256 = trunc i64 10 to i32
  %t257 = icmp eq i32 %t254, %t256
  br i1 %t257, label %bb77, label %bb78
bb77:
  br label %bb79
bb78:
  br label %bb80
bb79:
  %t259 = load i64, ptr %l8, !tbaa !24
  %t260 = load i64, ptr %l9, !tbaa !24
  %t263 = and i64 %t259, %t260
  store i64 %t263, ptr %l13, !tbaa !24
  br label %bb148
bb80:
  %t265 = load i32, ptr %l1, !range !{i32 0, i32 54}
  %t267 = trunc i64 11 to i32
  %t268 = icmp eq i32 %t265, %t267
  br i1 %t268, label %bb81, label %bb82
bb81:
  br label %bb83
bb82:
  br label %bb84
bb83:
  %t270 = load i64, ptr %l8, !tbaa !24
  %t271 = load i64, ptr %l9, !tbaa !24
  %t274 = or i64 %t270, %t271
  store i64 %t274, ptr %l13, !tbaa !24
  br label %bb148
bb84:
  %t276 = load i32, ptr %l1, !range !{i32 0, i32 54}
  %t278 = trunc i64 12 to i32
  %t279 = icmp eq i32 %t276, %t278
  br i1 %t279, label %bb85, label %bb86
bb85:
  br label %bb87
bb86:
  br label %bb88
bb87:
  %t281 = load i64, ptr %l8, !tbaa !24
  %t282 = load i64, ptr %l9, !tbaa !24
  %t285 = xor i64 %t281, %t282
  store i64 %t285, ptr %l13, !tbaa !24
  br label %bb148
bb88:
  %t287 = load i32, ptr %l1, !range !{i32 0, i32 54}
  %t289 = trunc i64 13 to i32
  %t290 = icmp eq i32 %t287, %t289
  br i1 %t290, label %bb89, label %bb90
bb89:
  br label %bb91
bb90:
  br label %bb95
bb91:
  %t292 = load i64, ptr %l8, !tbaa !24
  %t293 = load i64, ptr %l9, !tbaa !24
  %t296 = icmp eq i64 %t292, %t293
  br i1 %t296, label %bb92, label %bb93
bb92:
  store i64 1, ptr %l161, !tbaa !24
  br label %bb94
bb93:
  store i64 0, ptr %l161, !tbaa !24
  br label %bb94
bb94:
  %t298 = load i64, ptr %l161, !tbaa !24
  store i64 %t298, ptr %rv
  br label %ret
bb95:
  %t299 = load i32, ptr %l1, !range !{i32 0, i32 54}
  %t301 = trunc i64 14 to i32
  %t302 = icmp eq i32 %t299, %t301
  br i1 %t302, label %bb96, label %bb97
bb96:
  br label %bb98
bb97:
  br label %bb102
bb98:
  %t304 = load i64, ptr %l8, !tbaa !24
  %t305 = load i64, ptr %l9, !tbaa !24
  %t308 = icmp ne i64 %t304, %t305
  br i1 %t308, label %bb99, label %bb100
bb99:
  store i64 1, ptr %l167, !tbaa !24
  br label %bb101
bb100:
  store i64 0, ptr %l167, !tbaa !24
  br label %bb101
bb101:
  %t310 = load i64, ptr %l167, !tbaa !24
  store i64 %t310, ptr %rv
  br label %ret
bb102:
  %t311 = load i32, ptr %l1, !range !{i32 0, i32 54}
  %t313 = trunc i64 15 to i32
  %t314 = icmp eq i32 %t311, %t313
  br i1 %t314, label %bb103, label %bb104
bb103:
  br label %bb105
bb104:
  br label %bb112
bb105:
  %t316 = load i1, ptr %l7, !tbaa !21
  br i1 %t316, label %bb106, label %bb107
bb106:
  %t318 = load i64, ptr %l8, !tbaa !24
  %t319 = load i64, ptr %l9, !tbaa !24
  %t322 = icmp slt i64 %t318, %t319
  store i1 %t322, ptr %l171, !tbaa !21
  br label %bb108
bb107:
  %t324 = load i64, ptr %l10, !tbaa !65
  %t325 = load i64, ptr %l11, !tbaa !65
  %t328 = icmp ult i64 %t324, %t325
  store i1 %t328, ptr %l171, !tbaa !21
  br label %bb108
bb108:
  %t330 = load i1, ptr %l171, !tbaa !21
  br i1 %t330, label %bb109, label %bb110
bb109:
  store i64 1, ptr %l178, !tbaa !24
  br label %bb111
bb110:
  store i64 0, ptr %l178, !tbaa !24
  br label %bb111
bb111:
  %t331 = load i64, ptr %l178, !tbaa !24
  store i64 %t331, ptr %rv
  br label %ret
bb112:
  %t332 = load i32, ptr %l1, !range !{i32 0, i32 54}
  %t334 = trunc i64 16 to i32
  %t335 = icmp eq i32 %t332, %t334
  br i1 %t335, label %bb113, label %bb114
bb113:
  br label %bb115
bb114:
  br label %bb122
bb115:
  %t337 = load i1, ptr %l7, !tbaa !21
  br i1 %t337, label %bb116, label %bb117
bb116:
  %t339 = load i64, ptr %l8, !tbaa !24
  %t340 = load i64, ptr %l9, !tbaa !24
  %t343 = icmp sle i64 %t339, %t340
  store i1 %t343, ptr %l182, !tbaa !21
  br label %bb118
bb117:
  %t345 = load i64, ptr %l10, !tbaa !65
  %t346 = load i64, ptr %l11, !tbaa !65
  %t349 = icmp ule i64 %t345, %t346
  store i1 %t349, ptr %l182, !tbaa !21
  br label %bb118
bb118:
  %t351 = load i1, ptr %l182, !tbaa !21
  br i1 %t351, label %bb119, label %bb120
bb119:
  store i64 1, ptr %l189, !tbaa !24
  br label %bb121
bb120:
  store i64 0, ptr %l189, !tbaa !24
  br label %bb121
bb121:
  %t352 = load i64, ptr %l189, !tbaa !24
  store i64 %t352, ptr %rv
  br label %ret
bb122:
  %t353 = load i32, ptr %l1, !range !{i32 0, i32 54}
  %t355 = trunc i64 17 to i32
  %t356 = icmp eq i32 %t353, %t355
  br i1 %t356, label %bb123, label %bb124
bb123:
  br label %bb125
bb124:
  br label %bb132
bb125:
  %t358 = load i1, ptr %l7, !tbaa !21
  br i1 %t358, label %bb126, label %bb127
bb126:
  %t360 = load i64, ptr %l8, !tbaa !24
  %t361 = load i64, ptr %l9, !tbaa !24
  %t364 = icmp sgt i64 %t360, %t361
  store i1 %t364, ptr %l193, !tbaa !21
  br label %bb128
bb127:
  %t366 = load i64, ptr %l10, !tbaa !65
  %t367 = load i64, ptr %l11, !tbaa !65
  %t370 = icmp ugt i64 %t366, %t367
  store i1 %t370, ptr %l193, !tbaa !21
  br label %bb128
bb128:
  %t372 = load i1, ptr %l193, !tbaa !21
  br i1 %t372, label %bb129, label %bb130
bb129:
  store i64 1, ptr %l200, !tbaa !24
  br label %bb131
bb130:
  store i64 0, ptr %l200, !tbaa !24
  br label %bb131
bb131:
  %t373 = load i64, ptr %l200, !tbaa !24
  store i64 %t373, ptr %rv
  br label %ret
bb132:
  %t374 = load i32, ptr %l1, !range !{i32 0, i32 54}
  %t376 = trunc i64 18 to i32
  %t377 = icmp eq i32 %t374, %t376
  br i1 %t377, label %bb133, label %bb134
bb133:
  br label %bb135
bb134:
  br label %bb142
bb135:
  %t379 = load i1, ptr %l7, !tbaa !21
  br i1 %t379, label %bb136, label %bb137
bb136:
  %t381 = load i64, ptr %l8, !tbaa !24
  %t382 = load i64, ptr %l9, !tbaa !24
  %t385 = icmp sge i64 %t381, %t382
  store i1 %t385, ptr %l204, !tbaa !21
  br label %bb138
bb137:
  %t387 = load i64, ptr %l10, !tbaa !65
  %t388 = load i64, ptr %l11, !tbaa !65
  %t391 = icmp uge i64 %t387, %t388
  store i1 %t391, ptr %l204, !tbaa !21
  br label %bb138
bb138:
  %t393 = load i1, ptr %l204, !tbaa !21
  br i1 %t393, label %bb139, label %bb140
bb139:
  store i64 1, ptr %l211, !tbaa !24
  br label %bb141
bb140:
  store i64 0, ptr %l211, !tbaa !24
  br label %bb141
bb141:
  %t394 = load i64, ptr %l211, !tbaa !24
  store i64 %t394, ptr %rv
  br label %ret
bb142:
  br i1 true, label %bb143, label %bb144
bb143:
  br label %bb145
bb144:
  br label %bb147
bb145:
  %t395 = load ptr, ptr %l0, !tbaa !29
  %t397 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2enotModelled(ptr %v0, ptr %t395)
  store i64 %t397, ptr %l213
  br label %bb146
bb146:
  %t398 = load i64, ptr %l213, !tbaa !24
  store i64 %t398, ptr %rv
  br label %ret
bb147:
  call void @__olang_check_failed(ptr @olang_loc_cc4a112acbde7ca1_19be4f90a96d28f5)
  unreachable
bb148:
  %t399 = load i64, ptr %l13, !tbaa !24
  store i64 %t399, ptr %l214, !tbaa !24
  %t400 = load i64, ptr %l6, !tbaa !24
  %t402 = call i64 @compiler_2feval_2ebmask(i64 %t400)
  store i64 %t402, ptr %l216
  br label %bb149
bb149:
  %t403 = load i64, ptr %l214, !tbaa !24
  %t404 = load i64, ptr %l216, !tbaa !24
  %t405 = and i64 %t403, %t404
  store i64 %t405, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2elaneDot(ptr %v0, ptr %a0, i64 %a1, %"compiler/mir:Range" %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/mir:Range"
  %l4 = alloca { i64, [4 x i64] }
  %l5 = alloca { i64, [4 x i64] }
  %l6 = alloca %"compiler/eval:Ptr"
  %l7 = alloca %"compiler/eval:Ptr"
  %l8 = alloca i64
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l23 = alloca { i64, [4 x i64] }
  %l27 = alloca { i64, [4 x i64] }
  %l28 = alloca ptr
  %l32 = alloca %"compiler/eval:Ptr"
  %l33 = alloca %"compiler/eval:Ptr"
  %l34 = alloca ptr
  %l38 = alloca %"compiler/eval:Ptr"
  %l39 = alloca %"compiler/eval:Ptr"
  %l40 = alloca ptr
  %l41 = alloca i64
  %l45 = alloca { i64, [4 x i64] }
  %l46 = alloca i64
  %l48 = alloca ptr
  %l50 = alloca ptr
  %l52 = alloca ptr
  %l56 = alloca i32
  %l57 = alloca i32
  %l58 = alloca i32
  %l59 = alloca i32
  %l61 = alloca ptr
  %l63 = alloca ptr
  %l65 = alloca ptr
  %l69 = alloca i32
  %l70 = alloca i32
  %l71 = alloca i32
  %l72 = alloca i32
  %l77 = alloca i64
  %l80 = alloca i64
  %l98 = alloca ptr
  %l99 = alloca ptr
  %l104 = alloca %"compiler/eval:Ptr"
  %l105 = alloca i64
  %l107 = alloca i64
  %l108 = alloca ptr
  %l109 = alloca ptr
  %l114 = alloca %"compiler/eval:Ptr"
  %l115 = alloca i64
  %l117 = alloca i64
  %l130 = alloca i64
  %l133 = alloca i64
  %l134 = alloca i64
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/mir:Range" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t3 = load %"compiler/mir:Range", ptr %l2
  %t7 = call { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %t1, i64 %t2, %"compiler/mir:Range" %t3, i64 0)
  store { i64, [4 x i64] } %t7, ptr %l23
  br label %bb1
bb1:
  %t8 = load { i64, [4 x i64] }, ptr %l23
  store { i64, [4 x i64] } %t8, ptr %l4
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i64, ptr %l1, !tbaa !24
  %t11 = load %"compiler/mir:Range", ptr %l2
  %t15 = call { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %t9, i64 %t10, %"compiler/mir:Range" %t11, i64 1)
  store { i64, [4 x i64] } %t15, ptr %l27
  br label %bb2
bb2:
  %t16 = load { i64, [4 x i64] }, ptr %l27
  store { i64, [4 x i64] } %t16, ptr %l5
  %t17 = load ptr, ptr %l0, !tbaa !29
  store ptr %t17, ptr %l28, !tbaa !29
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i64, ptr %l1, !tbaa !24
  %t20 = load { i64, [4 x i64] }, ptr %l4
  %t24 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddr(ptr %v0, ptr %t18, i64 %t19, { i64, [4 x i64] } %t20, i64 1)
  store %"compiler/eval:Ptr" %t24, ptr %l32
  br label %bb3
bb3:
  %t25 = load ptr, ptr %l28, !tbaa !29
  %t26 = load %"compiler/eval:Ptr", ptr %l32
  %t27 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtr(ptr %v0, ptr %t25, %"compiler/eval:Ptr" %t26)
  store %"compiler/eval:Ptr" %t27, ptr %l33
  br label %bb4
bb4:
  %t28 = load %"compiler/eval:Ptr", ptr %l33
  store %"compiler/eval:Ptr" %t28, ptr %l6
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l34, !tbaa !29
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load i64, ptr %l1, !tbaa !24
  %t32 = load { i64, [4 x i64] }, ptr %l5
  %t36 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddr(ptr %v0, ptr %t30, i64 %t31, { i64, [4 x i64] } %t32, i64 2)
  store %"compiler/eval:Ptr" %t36, ptr %l38
  br label %bb5
bb5:
  %t37 = load ptr, ptr %l34, !tbaa !29
  %t38 = load %"compiler/eval:Ptr", ptr %l38
  %t39 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtr(ptr %v0, ptr %t37, %"compiler/eval:Ptr" %t38)
  store %"compiler/eval:Ptr" %t39, ptr %l39
  br label %bb6
bb6:
  %t40 = load %"compiler/eval:Ptr", ptr %l39
  store %"compiler/eval:Ptr" %t40, ptr %l7
  %t41 = load ptr, ptr %l0, !tbaa !29
  store ptr %t41, ptr %l40, !tbaa !29
  %t42 = load i64, ptr %l1, !tbaa !24
  store i64 %t42, ptr %l41, !tbaa !24
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load i64, ptr %l1, !tbaa !24
  %t45 = load %"compiler/mir:Range", ptr %l2
  %t49 = call { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %t43, i64 %t44, %"compiler/mir:Range" %t45, i64 2)
  store { i64, [4 x i64] } %t49, ptr %l45
  br label %bb7
bb7:
  %t50 = load ptr, ptr %l40, !tbaa !29
  %t51 = load i64, ptr %l41, !tbaa !24
  %t52 = load { i64, [4 x i64] }, ptr %l45
  %t53 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %t50, i64 %t51, { i64, [4 x i64] } %t52)
  store i64 %t53, ptr %l46
  br label %bb8
bb8:
  %t54 = load i64, ptr %l46, !tbaa !24
  store i64 %t54, ptr %l8, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/eval:Machine", ptr %t55, i32 0, i32 0
  %t58 = load ptr, ptr %t57, !tbaa !29
  store ptr %t58, ptr %l48, !tbaa !29
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/eval:Machine", ptr %t59, i32 0, i32 0
  %t62 = load ptr, ptr %t61, !tbaa !29
  store ptr %t62, ptr %l50, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/eval:Machine", ptr %t63, i32 0, i32 0
  %t66 = load ptr, ptr %t65, !tbaa !29
  store ptr %t66, ptr %l52, !tbaa !29
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load i64, ptr %l1, !tbaa !24
  %t69 = load { i64, [4 x i64] }, ptr %l4
  %t73 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eopType(ptr %v0, ptr %t67, i64 %t68, { i64, [4 x i64] } %t69)
  store i32 %t73, ptr %l56
  br label %bb9
bb9:
  %t74 = load ptr, ptr %l52, !tbaa !29
  %t75 = load i32, ptr %l56, !tbaa !23
  %t76 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t74, i32 %t75)
  store i32 %t76, ptr %l57
  br label %bb10
bb10:
  %t77 = load ptr, ptr %l50, !tbaa !29
  %t78 = load i32, ptr %l57, !tbaa !23
  %t79 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t77, i32 %t78)
  store i32 %t79, ptr %l58
  br label %bb11
bb11:
  %t80 = load ptr, ptr %l48, !tbaa !29
  %t81 = load i32, ptr %l58, !tbaa !23
  %t82 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t80, i32 %t81)
  store i32 %t82, ptr %l59
  br label %bb12
bb12:
  %t83 = load i32, ptr %l59, !tbaa !23
  store i32 %t83, ptr %l9, !tbaa !23
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/eval:Machine", ptr %t84, i32 0, i32 0
  %t87 = load ptr, ptr %t86, !tbaa !29
  store ptr %t87, ptr %l61, !tbaa !29
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/eval:Machine", ptr %t88, i32 0, i32 0
  %t91 = load ptr, ptr %t90, !tbaa !29
  store ptr %t91, ptr %l63, !tbaa !29
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/eval:Machine", ptr %t92, i32 0, i32 0
  %t95 = load ptr, ptr %t94, !tbaa !29
  store ptr %t95, ptr %l65, !tbaa !29
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load i64, ptr %l1, !tbaa !24
  %t98 = load { i64, [4 x i64] }, ptr %l5
  %t102 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eopType(ptr %v0, ptr %t96, i64 %t97, { i64, [4 x i64] } %t98)
  store i32 %t102, ptr %l69
  br label %bb13
bb13:
  %t103 = load ptr, ptr %l65, !tbaa !29
  %t104 = load i32, ptr %l69, !tbaa !23
  %t105 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t103, i32 %t104)
  store i32 %t105, ptr %l70
  br label %bb14
bb14:
  %t106 = load ptr, ptr %l63, !tbaa !29
  %t107 = load i32, ptr %l70, !tbaa !23
  %t108 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t106, i32 %t107)
  store i32 %t108, ptr %l71
  br label %bb15
bb15:
  %t109 = load ptr, ptr %l61, !tbaa !29
  %t110 = load i32, ptr %l71, !tbaa !23
  %t111 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t109, i32 %t110)
  store i32 %t111, ptr %l72
  br label %bb16
bb16:
  %t112 = load i32, ptr %l72, !tbaa !23
  store i32 %t112, ptr %l10, !tbaa !23
  store i64 0, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  %t113 = load i64, ptr %l8, !tbaa !24
  store i64 %t113, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t115 = load i64, ptr %l13, !tbaa !24
  %t116 = load i64, ptr %l12, !tbaa !24
  %t119 = icmp sgt i64 %t115, %t116
  br i1 %t119, label %bb17, label %bb18
bb17:
  %t121 = load i64, ptr %l14, !tbaa !24
  %t123 = icmp sgt i64 %t121, 0
  br i1 %t123, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l77, !tbaa !24
  br label %bb22
bb19:
  %t125 = load i64, ptr %l13, !tbaa !24
  %t126 = load i64, ptr %l12, !tbaa !24
  %t129 = sub i64 %t125, %t126
  %t130 = load i64, ptr %l14, !tbaa !24
  %t133 = add i64 %t129, %t130
  %t135 = sub i64 %t133, 1
  %t136 = load i64, ptr %l14, !tbaa !24
  %t139 = sdiv i64 %t135, %t136
  store i64 %t139, ptr %l80, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l80, !tbaa !24
  br label %bb21
bb21:
  %t141 = load i64, ptr %l80, !tbaa !24
  store i64 %t141, ptr %l77, !tbaa !24
  br label %bb22
bb22:
  %t142 = load i64, ptr %l77, !tbaa !24
  store i64 %t142, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s2
  %t143 = load i64, ptr %l16, !tbaa !24
  %t144 = load i64, ptr %l15, !tbaa !24
  %t147 = icmp slt i64 %t143, %t144
  %t149 = xor i1 %t147, true
  br i1 %t149, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s2)
  br label %bb37
bb25:
  br label %bb26
bb26:
  %t151 = load i64, ptr %l12, !tbaa !24
  %t152 = load i64, ptr %l16, !tbaa !24
  %t153 = load i64, ptr %l14, !tbaa !24
  %t156 = mul i64 %t152, %t153
  %t159 = add i64 %t151, %t156
  store i64 %t159, ptr %l17, !tbaa !24
  %t161 = load ptr, ptr %l0, !tbaa !29
  store ptr %t161, ptr %l98, !tbaa !29
  %t162 = load ptr, ptr %l0, !tbaa !29
  store ptr %t162, ptr %l99, !tbaa !29
  %t163 = getelementptr %"compiler/eval:Ptr", ptr %l6, i32 0, i32 0
  %t164 = load i64, ptr %t163, !tbaa !24
  %t165 = getelementptr %"compiler/eval:Ptr", ptr %l6, i32 0, i32 1
  %t166 = load i64, ptr %t165, !tbaa !24
  %t167 = load i64, ptr %l17, !tbaa !24
  %t170 = add i64 %t166, %t167
  %t173 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s2, i64 %t164, i64 %t170)
  store %"compiler/eval:Ptr" %t173, ptr %l104
  br label %bb27
bb27:
  %t174 = load ptr, ptr %l99, !tbaa !29
  %t175 = load %"compiler/eval:Ptr", ptr %l104
  %t176 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t174, %"compiler/eval:Ptr" %t175, i64 1)
  store i64 %t176, ptr %l105
  br label %bb28
bb28:
  %t177 = load i32, ptr %l9, !tbaa !23
  %t178 = load ptr, ptr %l98, !tbaa !29
  %t179 = load i64, ptr %l105, !tbaa !24
  %t181 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintValue(ptr %v0, ptr %t178, i64 %t179, i32 %t177)
  store i64 %t181, ptr %l107
  br label %bb29
bb29:
  %t182 = load i64, ptr %l107, !tbaa !24
  store i64 %t182, ptr %l18, !tbaa !24
  %t183 = load ptr, ptr %l0, !tbaa !29
  store ptr %t183, ptr %l108, !tbaa !29
  %t184 = load ptr, ptr %l0, !tbaa !29
  store ptr %t184, ptr %l109, !tbaa !29
  %t185 = getelementptr %"compiler/eval:Ptr", ptr %l7, i32 0, i32 0
  %t186 = load i64, ptr %t185, !tbaa !24
  %t187 = getelementptr %"compiler/eval:Ptr", ptr %l7, i32 0, i32 1
  %t188 = load i64, ptr %t187, !tbaa !24
  %t189 = load i64, ptr %l17, !tbaa !24
  %t192 = add i64 %t188, %t189
  %t195 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s2, i64 %t186, i64 %t192)
  store %"compiler/eval:Ptr" %t195, ptr %l114
  br label %bb30
bb30:
  %t196 = load ptr, ptr %l109, !tbaa !29
  %t197 = load %"compiler/eval:Ptr", ptr %l114
  %t198 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t196, %"compiler/eval:Ptr" %t197, i64 1)
  store i64 %t198, ptr %l115
  br label %bb31
bb31:
  %t199 = load i32, ptr %l10, !tbaa !23
  %t200 = load ptr, ptr %l108, !tbaa !29
  %t201 = load i64, ptr %l115, !tbaa !24
  %t203 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintValue(ptr %v0, ptr %t200, i64 %t201, i32 %t199)
  store i64 %t203, ptr %l117
  br label %bb32
bb32:
  %t204 = load i64, ptr %l117, !tbaa !24
  store i64 %t204, ptr %l19, !tbaa !24
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr %"compiler/eval:Machine", ptr %t205, i32 0, i32 23
  %t208 = load i1, ptr %t207, !tbaa !21
  br i1 %t208, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s2)
  store i64 0, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  %t211 = load i64, ptr %l11, !tbaa !24
  %t213 = load i64, ptr %l18, !tbaa !24
  %t214 = load i64, ptr %l19, !tbaa !24
  %t217 = mul i64 %t213, %t214
  %t220 = add i64 %t211, %t217
  store i64 %t220, ptr %l11, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb36
bb36:
  %t222 = load i64, ptr %l16, !tbaa !24
  %t225 = add i64 %t222, 1
  store i64 %t225, ptr %l16, !tbaa !24
  br label %bb23
bb37:
  %t227 = load i64, ptr %l11, !tbaa !24
  store i64 %t227, ptr %l130, !tbaa !24
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t232 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eibits(ptr %v0, ptr %t228, i32 %a3)
  store i64 %t232, ptr %l133
  br label %bb38
bb38:
  %t233 = load i64, ptr %l133, !tbaa !24
  %t234 = call i64 @compiler_2feval_2ebmask(i64 %t233)
  store i64 %t234, ptr %l134
  br label %bb39
bb39:
  %t235 = load i64, ptr %l130, !tbaa !24
  %t236 = load i64, ptr %l134, !tbaa !24
  %t237 = and i64 %t235, %t236
  store i64 %t237, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2emove(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l45 = alloca i1
  %l64 = alloca i64
  %l67 = alloca i64
  %l76 = alloca i64
  %l79 = alloca i1
  %l90 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l101 = alloca { i64, ptr }
  %l106 = alloca { i64, ptr }
  %l116 = alloca ptr
  %l120 = alloca i64
  %l121 = alloca i64
  %l128 = alloca i64
  %l130 = alloca { i64, ptr }
  %l141 = alloca i64
  %l144 = alloca i64
  %l153 = alloca i64
  %l156 = alloca i1
  %l171 = alloca { i64, ptr }
  %l176 = alloca { i64, ptr }
  %l182 = alloca { i64, ptr }
  %l187 = alloca { i64, ptr }
  %l202 = alloca i64
  %l205 = alloca i64
  %l223 = alloca ptr
  %l226 = alloca i64
  %l231 = alloca i64
  %l239 = alloca i64
  %l242 = alloca i64
  %l260 = alloca ptr
  %l266 = alloca i64
  %l274 = alloca i64
  %l289 = alloca i64
  %l292 = alloca i64
  %l301 = alloca i64
  %l304 = alloca i1
  %l315 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load i64, ptr %l2, !tbaa !24
  %t5 = icmp eq i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load i64, ptr %l1, !tbaa !24
  %t9 = srem i64 %t7, 8
  %t11 = icmp eq i64 %t9, 0
  br i1 %t11, label %bb4, label %bb5
bb4:
  %t13 = load i64, ptr %l2, !tbaa !24
  %t15 = srem i64 %t13, 8
  %t17 = icmp eq i64 %t15, 0
  store i1 %t17, ptr %l45, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb6
bb6:
  %t19 = load i1, ptr %l45, !tbaa !21
  br i1 %t19, label %bb7, label %bb8
bb7:
  %t20 = load i64, ptr %l3, !tbaa !24
  %t22 = sdiv i64 %t20, 8
  store i64 %t22, ptr %l4, !tbaa !24
  %t24 = load i64, ptr %l3, !tbaa !24
  %t26 = srem i64 %t24, 8
  store i64 %t26, ptr %l5, !tbaa !24
  %t28 = load i64, ptr %l1, !tbaa !24
  %t30 = sdiv i64 %t28, 8
  store i64 %t30, ptr %l6, !tbaa !24
  %t32 = load i64, ptr %l2, !tbaa !24
  %t34 = sdiv i64 %t32, 8
  store i64 %t34, ptr %l7, !tbaa !24
  %t36 = load i64, ptr %l1, !tbaa !24
  %t37 = load i64, ptr %l2, !tbaa !24
  %t40 = icmp slt i64 %t36, %t37
  br i1 %t40, label %bb9, label %bb10
bb8:
  br label %bb44
bb9:
  store i64 0, ptr %l8, !tbaa !24
  %t42 = load i64, ptr %l4, !tbaa !24
  store i64 %t42, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t44 = load i64, ptr %l9, !tbaa !24
  %t45 = load i64, ptr %l8, !tbaa !24
  %t48 = icmp sgt i64 %t44, %t45
  br i1 %t48, label %bb11, label %bb12
bb10:
  br label %bb23
bb11:
  %t50 = load i64, ptr %l10, !tbaa !24
  %t52 = icmp sgt i64 %t50, 0
  br i1 %t52, label %bb13, label %bb14
bb12:
  store i64 0, ptr %l64, !tbaa !24
  br label %bb16
bb13:
  %t54 = load i64, ptr %l9, !tbaa !24
  %t55 = load i64, ptr %l8, !tbaa !24
  %t58 = sub i64 %t54, %t55
  %t59 = load i64, ptr %l10, !tbaa !24
  %t62 = add i64 %t58, %t59
  %t64 = sub i64 %t62, 1
  %t65 = load i64, ptr %l10, !tbaa !24
  %t68 = sdiv i64 %t64, %t65
  store i64 %t68, ptr %l67, !tbaa !24
  br label %bb15
bb14:
  store i64 0, ptr %l67, !tbaa !24
  br label %bb15
bb15:
  %t70 = load i64, ptr %l67, !tbaa !24
  store i64 %t70, ptr %l64, !tbaa !24
  br label %bb16
bb16:
  %t71 = load i64, ptr %l64, !tbaa !24
  store i64 %t71, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  %t72 = load i64, ptr %l11, !tbaa !24
  %t73 = sub i64 %t72, 1
  store i64 %t73, ptr %l76, !tbaa !24
  %t74 = load i64, ptr %l11, !tbaa !24
  %t75 = icmp slt i64 %t74, 2147483648
  %t76 = load i64, ptr %l12, !tbaa !24
  %t77 = icmp sge i64 %t76, 0
  %t80 = and i1 %t75, %t77
  store i1 %t80, ptr %l79, !tbaa !21
  br label %bb17
bb17:
  %t81 = load i64, ptr %l12, !tbaa !24
  %t82 = load i64, ptr %l11, !tbaa !24
  %t85 = icmp slt i64 %t81, %t82
  %t87 = xor i1 %t85, true
  br i1 %t87, label %bb18, label %bb19
bb18:
  br label %bb22
bb19:
  br label %bb20
bb20:
  %t89 = load i64, ptr %l8, !tbaa !24
  %t90 = load i64, ptr %l12, !tbaa !24
  %t91 = load i64, ptr %l10, !tbaa !24
  %t94 = mul i64 %t90, %t91
  %t97 = add i64 %t89, %t94
  store i64 %t97, ptr %l13, !tbaa !24
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/eval:Machine", ptr %t99, i32 0, i32 46
  %t102 = load { i64, ptr }, ptr %t101, !tbaa !27
  store { i64, ptr } %t102, ptr %l90, !tbaa !27
  %t103 = load i64, ptr %l6, !tbaa !24
  %t104 = load i64, ptr %l13, !tbaa !24
  %t107 = add i64 %t103, %t104
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/eval:Machine", ptr %t108, i32 0, i32 46
  %t111 = load { i64, ptr }, ptr %t110, !tbaa !27
  store { i64, ptr } %t111, ptr %l95, !tbaa !27
  %t112 = load i64, ptr %l7, !tbaa !24
  %t113 = load i64, ptr %l13, !tbaa !24
  %t116 = add i64 %t112, %t113
  %t118 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !27
  %t120 = getelementptr i64, ptr %t119, i64 %t116
  %t121 = load i64, ptr %t120, !tbaa !34
  %t124 = getelementptr { i64, ptr }, ptr %l90, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr i64, ptr %t125, i64 %t107
  store i64 %t121, ptr %t126, !tbaa !34
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/eval:Machine", ptr %t127, i32 0, i32 47
  %t130 = load { i64, ptr }, ptr %t129, !tbaa !27
  store { i64, ptr } %t130, ptr %l101, !tbaa !27
  %t131 = load i64, ptr %l6, !tbaa !24
  %t132 = load i64, ptr %l13, !tbaa !24
  %t135 = add i64 %t131, %t132
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/eval:Machine", ptr %t136, i32 0, i32 47
  %t139 = load { i64, ptr }, ptr %t138, !tbaa !27
  store { i64, ptr } %t139, ptr %l106, !tbaa !27
  %t140 = load i64, ptr %l7, !tbaa !24
  %t141 = load i64, ptr %l13, !tbaa !24
  %t144 = add i64 %t140, %t141
  %t146 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = getelementptr i64, ptr %t147, i64 %t144
  %t149 = load i64, ptr %t148, !tbaa !34
  %t152 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = getelementptr i64, ptr %t153, i64 %t135
  store i64 %t149, ptr %t154, !tbaa !34
  br label %bb21
bb21:
  %t155 = load i64, ptr %l12, !tbaa !24
  %t158 = add i64 %t155, 1
  store i64 %t158, ptr %l12, !tbaa !24
  br label %bb17
bb22:
  br label %bb23
bb23:
  %t160 = load i64, ptr %l5, !tbaa !24
  %t162 = icmp sgt i64 %t160, 0
  br i1 %t162, label %bb24, label %bb25
bb24:
  %t164 = load ptr, ptr %l0, !tbaa !29
  store ptr %t164, ptr %l116, !tbaa !29
  %t165 = load i64, ptr %l1, !tbaa !24
  %t166 = load i64, ptr %l4, !tbaa !24
  %t168 = mul i64 8, %t166
  %t171 = add i64 %t165, %t168
  store i64 %t171, ptr %l120, !tbaa !24
  %t172 = load i64, ptr %l5, !tbaa !24
  store i64 %t172, ptr %l121, !tbaa !24
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load i64, ptr %l2, !tbaa !24
  %t175 = load i64, ptr %l4, !tbaa !24
  %t177 = mul i64 8, %t175
  %t180 = add i64 %t174, %t177
  %t181 = load i64, ptr %l5, !tbaa !24
  %t185 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erdRaw(ptr %v0, ptr %t173, i64 %t180, i64 %t181)
  store i64 %t185, ptr %l128
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t186 = load ptr, ptr %l116, !tbaa !29
  %t187 = load i64, ptr %l120, !tbaa !24
  %t188 = load i64, ptr %l121, !tbaa !24
  %t189 = load i64, ptr %l128, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrRaw(ptr %v0, ptr %t186, i64 %t187, i64 %t188, i64 %t189)
  br label %bb27
bb27:
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t192 = getelementptr %"compiler/eval:Machine", ptr %t190, i32 0, i32 47
  %t193 = load { i64, ptr }, ptr %t192, !tbaa !27
  store { i64, ptr } %t193, ptr %l130, !tbaa !27
  %t194 = load i64, ptr %l6, !tbaa !24
  %t195 = load i64, ptr %l4, !tbaa !24
  %t198 = add i64 %t194, %t195
  %t200 = getelementptr { i64, ptr }, ptr %l130, i32 0, i32 1
  %t201 = load ptr, ptr %t200, !tbaa !27
  %t202 = getelementptr i64, ptr %t201, i64 %t198
  store i64 0, ptr %t202, !tbaa !34
  br label %bb28
bb28:
  %t203 = load i64, ptr %l1, !tbaa !24
  %t204 = load i64, ptr %l2, !tbaa !24
  %t207 = icmp sgt i64 %t203, %t204
  br i1 %t207, label %bb29, label %bb30
bb29:
  store i64 0, ptr %l14, !tbaa !24
  %t209 = load i64, ptr %l4, !tbaa !24
  store i64 %t209, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t211 = load i64, ptr %l15, !tbaa !24
  %t212 = load i64, ptr %l14, !tbaa !24
  %t215 = icmp sgt i64 %t211, %t212
  br i1 %t215, label %bb31, label %bb32
bb30:
  br label %bb43
bb31:
  %t217 = load i64, ptr %l16, !tbaa !24
  %t219 = icmp sgt i64 %t217, 0
  br i1 %t219, label %bb33, label %bb34
bb32:
  store i64 0, ptr %l141, !tbaa !24
  br label %bb36
bb33:
  %t221 = load i64, ptr %l15, !tbaa !24
  %t222 = load i64, ptr %l14, !tbaa !24
  %t225 = sub i64 %t221, %t222
  %t226 = load i64, ptr %l16, !tbaa !24
  %t229 = add i64 %t225, %t226
  %t231 = sub i64 %t229, 1
  %t232 = load i64, ptr %l16, !tbaa !24
  %t235 = sdiv i64 %t231, %t232
  store i64 %t235, ptr %l144, !tbaa !24
  br label %bb35
bb34:
  store i64 0, ptr %l144, !tbaa !24
  br label %bb35
bb35:
  %t237 = load i64, ptr %l144, !tbaa !24
  store i64 %t237, ptr %l141, !tbaa !24
  br label %bb36
bb36:
  %t238 = load i64, ptr %l141, !tbaa !24
  store i64 %t238, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  %t239 = load i64, ptr %l17, !tbaa !24
  %t240 = sub i64 %t239, 1
  store i64 %t240, ptr %l153, !tbaa !24
  %t241 = load i64, ptr %l17, !tbaa !24
  %t242 = icmp slt i64 %t241, 2147483648
  %t243 = load i64, ptr %l18, !tbaa !24
  %t244 = icmp sge i64 %t243, 0
  %t247 = and i1 %t242, %t244
  store i1 %t247, ptr %l156, !tbaa !21
  br label %bb37
bb37:
  %t248 = load i64, ptr %l18, !tbaa !24
  %t249 = load i64, ptr %l17, !tbaa !24
  %t252 = icmp slt i64 %t248, %t249
  %t254 = xor i1 %t252, true
  br i1 %t254, label %bb38, label %bb39
bb38:
  br label %bb42
bb39:
  br label %bb40
bb40:
  %t256 = load i64, ptr %l14, !tbaa !24
  %t257 = load i64, ptr %l18, !tbaa !24
  %t258 = load i64, ptr %l16, !tbaa !24
  %t261 = mul i64 %t257, %t258
  %t264 = add i64 %t256, %t261
  %t266 = load i64, ptr %l4, !tbaa !24
  %t268 = sub i64 %t266, 1
  %t272 = sub i64 %t268, %t264
  store i64 %t272, ptr %l20, !tbaa !24
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t276 = getelementptr %"compiler/eval:Machine", ptr %t274, i32 0, i32 46
  %t277 = load { i64, ptr }, ptr %t276, !tbaa !27
  store { i64, ptr } %t277, ptr %l171, !tbaa !27
  %t278 = load i64, ptr %l6, !tbaa !24
  %t279 = load i64, ptr %l20, !tbaa !24
  %t282 = add i64 %t278, %t279
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t285 = getelementptr %"compiler/eval:Machine", ptr %t283, i32 0, i32 46
  %t286 = load { i64, ptr }, ptr %t285, !tbaa !27
  store { i64, ptr } %t286, ptr %l176, !tbaa !27
  %t287 = load i64, ptr %l7, !tbaa !24
  %t288 = load i64, ptr %l20, !tbaa !24
  %t291 = add i64 %t287, %t288
  %t293 = getelementptr { i64, ptr }, ptr %l176, i32 0, i32 1
  %t294 = load ptr, ptr %t293, !tbaa !27
  %t295 = getelementptr i64, ptr %t294, i64 %t291
  %t296 = load i64, ptr %t295, !tbaa !34
  %t299 = getelementptr { i64, ptr }, ptr %l171, i32 0, i32 1
  %t300 = load ptr, ptr %t299, !tbaa !27
  %t301 = getelementptr i64, ptr %t300, i64 %t282
  store i64 %t296, ptr %t301, !tbaa !34
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t304 = getelementptr %"compiler/eval:Machine", ptr %t302, i32 0, i32 47
  %t305 = load { i64, ptr }, ptr %t304, !tbaa !27
  store { i64, ptr } %t305, ptr %l182, !tbaa !27
  %t306 = load i64, ptr %l6, !tbaa !24
  %t307 = load i64, ptr %l20, !tbaa !24
  %t310 = add i64 %t306, %t307
  %t311 = load ptr, ptr %l0, !tbaa !29
  %t313 = getelementptr %"compiler/eval:Machine", ptr %t311, i32 0, i32 47
  %t314 = load { i64, ptr }, ptr %t313, !tbaa !27
  store { i64, ptr } %t314, ptr %l187, !tbaa !27
  %t315 = load i64, ptr %l7, !tbaa !24
  %t316 = load i64, ptr %l20, !tbaa !24
  %t319 = add i64 %t315, %t316
  %t321 = getelementptr { i64, ptr }, ptr %l187, i32 0, i32 1
  %t322 = load ptr, ptr %t321, !tbaa !27
  %t323 = getelementptr i64, ptr %t322, i64 %t319
  %t324 = load i64, ptr %t323, !tbaa !34
  %t327 = getelementptr { i64, ptr }, ptr %l182, i32 0, i32 1
  %t328 = load ptr, ptr %t327, !tbaa !27
  %t329 = getelementptr i64, ptr %t328, i64 %t310
  store i64 %t324, ptr %t329, !tbaa !34
  br label %bb41
bb41:
  %t330 = load i64, ptr %l18, !tbaa !24
  %t333 = add i64 %t330, 1
  store i64 %t333, ptr %l18, !tbaa !24
  br label %bb37
bb42:
  br label %bb43
bb43:
  br label %ret
bb44:
  %t335 = load i64, ptr %l1, !tbaa !24
  %t336 = load i64, ptr %l2, !tbaa !24
  %t339 = icmp slt i64 %t335, %t336
  br i1 %t339, label %bb45, label %bb46
bb45:
  store i64 0, ptr %l21, !tbaa !24
  %t341 = load i64, ptr %l3, !tbaa !24
  store i64 %t341, ptr %l22, !tbaa !24
  store i64 1, ptr %l23, !tbaa !24
  %t343 = load i64, ptr %l22, !tbaa !24
  %t344 = load i64, ptr %l21, !tbaa !24
  %t347 = icmp sgt i64 %t343, %t344
  br i1 %t347, label %bb47, label %bb48
bb46:
  store i64 0, ptr %l27, !tbaa !24
  %t349 = load i64, ptr %l3, !tbaa !24
  store i64 %t349, ptr %l28, !tbaa !24
  store i64 1, ptr %l29, !tbaa !24
  %t351 = load i64, ptr %l28, !tbaa !24
  %t352 = load i64, ptr %l27, !tbaa !24
  %t355 = icmp sgt i64 %t351, %t352
  br i1 %t355, label %bb61, label %bb62
bb47:
  %t357 = load i64, ptr %l23, !tbaa !24
  %t359 = icmp sgt i64 %t357, 0
  br i1 %t359, label %bb49, label %bb50
bb48:
  store i64 0, ptr %l202, !tbaa !24
  br label %bb52
bb49:
  %t361 = load i64, ptr %l22, !tbaa !24
  %t362 = load i64, ptr %l21, !tbaa !24
  %t365 = sub i64 %t361, %t362
  %t366 = load i64, ptr %l23, !tbaa !24
  %t369 = add i64 %t365, %t366
  %t371 = sub i64 %t369, 1
  %t372 = load i64, ptr %l23, !tbaa !24
  %t375 = sdiv i64 %t371, %t372
  store i64 %t375, ptr %l205, !tbaa !24
  br label %bb51
bb50:
  store i64 0, ptr %l205, !tbaa !24
  br label %bb51
bb51:
  %t377 = load i64, ptr %l205, !tbaa !24
  store i64 %t377, ptr %l202, !tbaa !24
  br label %bb52
bb52:
  %t378 = load i64, ptr %l202, !tbaa !24
  store i64 %t378, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  br label %bb53
bb53:
  %t379 = load i64, ptr %l25, !tbaa !24
  %t380 = load i64, ptr %l24, !tbaa !24
  %t383 = icmp slt i64 %t379, %t380
  %t385 = xor i1 %t383, true
  br i1 %t385, label %bb54, label %bb55
bb54:
  br label %bb60
bb55:
  br label %bb56
bb56:
  %t387 = load i64, ptr %l21, !tbaa !24
  %t388 = load i64, ptr %l25, !tbaa !24
  %t389 = load i64, ptr %l23, !tbaa !24
  %t392 = mul i64 %t388, %t389
  %t395 = add i64 %t387, %t392
  store i64 %t395, ptr %l26, !tbaa !24
  %t397 = load ptr, ptr %l0, !tbaa !29
  store ptr %t397, ptr %l223, !tbaa !29
  %t398 = load i64, ptr %l1, !tbaa !24
  %t399 = load i64, ptr %l26, !tbaa !24
  %t402 = add i64 %t398, %t399
  store i64 %t402, ptr %l226, !tbaa !24
  %t403 = load ptr, ptr %l0, !tbaa !29
  %t404 = load i64, ptr %l2, !tbaa !24
  %t405 = load i64, ptr %l26, !tbaa !24
  %t408 = add i64 %t404, %t405
  %t411 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erdRaw(ptr %v0, ptr %t403, i64 %t408, i64 1)
  store i64 %t411, ptr %l231
  br label %bb57
bb57:
  %t412 = load ptr, ptr %l223, !tbaa !29
  %t413 = load i64, ptr %l226, !tbaa !24
  %t414 = load i64, ptr %l231, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrRaw(ptr %v0, ptr %t412, i64 %t413, i64 1, i64 %t414)
  br label %bb58
bb58:
  br label %bb59
bb59:
  %t415 = load i64, ptr %l25, !tbaa !24
  %t418 = add i64 %t415, 1
  store i64 %t418, ptr %l25, !tbaa !24
  br label %bb53
bb60:
  br label %bb75
bb61:
  %t420 = load i64, ptr %l29, !tbaa !24
  %t422 = icmp sgt i64 %t420, 0
  br i1 %t422, label %bb63, label %bb64
bb62:
  store i64 0, ptr %l239, !tbaa !24
  br label %bb66
bb63:
  %t424 = load i64, ptr %l28, !tbaa !24
  %t425 = load i64, ptr %l27, !tbaa !24
  %t428 = sub i64 %t424, %t425
  %t429 = load i64, ptr %l29, !tbaa !24
  %t432 = add i64 %t428, %t429
  %t434 = sub i64 %t432, 1
  %t435 = load i64, ptr %l29, !tbaa !24
  %t438 = sdiv i64 %t434, %t435
  store i64 %t438, ptr %l242, !tbaa !24
  br label %bb65
bb64:
  store i64 0, ptr %l242, !tbaa !24
  br label %bb65
bb65:
  %t440 = load i64, ptr %l242, !tbaa !24
  store i64 %t440, ptr %l239, !tbaa !24
  br label %bb66
bb66:
  %t441 = load i64, ptr %l239, !tbaa !24
  store i64 %t441, ptr %l30, !tbaa !24
  store i64 0, ptr %l31, !tbaa !24
  br label %bb67
bb67:
  %t442 = load i64, ptr %l31, !tbaa !24
  %t443 = load i64, ptr %l30, !tbaa !24
  %t446 = icmp slt i64 %t442, %t443
  %t448 = xor i1 %t446, true
  br i1 %t448, label %bb68, label %bb69
bb68:
  br label %bb74
bb69:
  br label %bb70
bb70:
  %t450 = load i64, ptr %l27, !tbaa !24
  %t451 = load i64, ptr %l31, !tbaa !24
  %t452 = load i64, ptr %l29, !tbaa !24
  %t455 = mul i64 %t451, %t452
  %t458 = add i64 %t450, %t455
  store i64 %t458, ptr %l32, !tbaa !24
  %t460 = load ptr, ptr %l0, !tbaa !29
  store ptr %t460, ptr %l260, !tbaa !29
  %t461 = load i64, ptr %l1, !tbaa !24
  %t462 = load i64, ptr %l3, !tbaa !24
  %t465 = add i64 %t461, %t462
  %t467 = sub i64 %t465, 1
  %t468 = load i64, ptr %l32, !tbaa !24
  %t471 = sub i64 %t467, %t468
  store i64 %t471, ptr %l266, !tbaa !24
  %t472 = load ptr, ptr %l0, !tbaa !29
  %t473 = load i64, ptr %l2, !tbaa !24
  %t474 = load i64, ptr %l3, !tbaa !24
  %t477 = add i64 %t473, %t474
  %t479 = sub i64 %t477, 1
  %t480 = load i64, ptr %l32, !tbaa !24
  %t483 = sub i64 %t479, %t480
  %t486 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erdRaw(ptr %v0, ptr %t472, i64 %t483, i64 1)
  store i64 %t486, ptr %l274
  br label %bb71
bb71:
  %t487 = load ptr, ptr %l260, !tbaa !29
  %t488 = load i64, ptr %l266, !tbaa !24
  %t489 = load i64, ptr %l274, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrRaw(ptr %v0, ptr %t487, i64 %t488, i64 1, i64 %t489)
  br label %bb72
bb72:
  br label %bb73
bb73:
  %t490 = load i64, ptr %l31, !tbaa !24
  %t493 = add i64 %t490, 1
  store i64 %t493, ptr %l31, !tbaa !24
  br label %bb67
bb74:
  br label %bb75
bb75:
  %t495 = load i64, ptr %l1, !tbaa !24
  %t497 = sdiv i64 %t495, 8
  store i64 %t497, ptr %l33, !tbaa !24
  %t499 = load i64, ptr %l1, !tbaa !24
  %t500 = load i64, ptr %l3, !tbaa !24
  %t503 = add i64 %t499, %t500
  %t505 = sub i64 %t503, 1
  %t507 = sdiv i64 %t505, 8
  %t509 = add i64 %t507, 1
  store i64 %t509, ptr %l34, !tbaa !24
  store i64 1, ptr %l35, !tbaa !24
  %t511 = load i64, ptr %l34, !tbaa !24
  %t512 = load i64, ptr %l33, !tbaa !24
  %t515 = icmp sgt i64 %t511, %t512
  br i1 %t515, label %bb76, label %bb77
bb76:
  %t517 = load i64, ptr %l35, !tbaa !24
  %t519 = icmp sgt i64 %t517, 0
  br i1 %t519, label %bb78, label %bb79
bb77:
  store i64 0, ptr %l289, !tbaa !24
  br label %bb81
bb78:
  %t521 = load i64, ptr %l34, !tbaa !24
  %t522 = load i64, ptr %l33, !tbaa !24
  %t525 = sub i64 %t521, %t522
  %t526 = load i64, ptr %l35, !tbaa !24
  %t529 = add i64 %t525, %t526
  %t531 = sub i64 %t529, 1
  %t532 = load i64, ptr %l35, !tbaa !24
  %t535 = sdiv i64 %t531, %t532
  store i64 %t535, ptr %l292, !tbaa !24
  br label %bb80
bb79:
  store i64 0, ptr %l292, !tbaa !24
  br label %bb80
bb80:
  %t537 = load i64, ptr %l292, !tbaa !24
  store i64 %t537, ptr %l289, !tbaa !24
  br label %bb81
bb81:
  %t538 = load i64, ptr %l289, !tbaa !24
  store i64 %t538, ptr %l36, !tbaa !24
  store i64 0, ptr %l37, !tbaa !24
  %t539 = load i64, ptr %l36, !tbaa !24
  %t540 = sub i64 %t539, 1
  store i64 %t540, ptr %l301, !tbaa !24
  %t541 = load i64, ptr %l36, !tbaa !24
  %t542 = icmp slt i64 %t541, 2147483648
  %t543 = load i64, ptr %l37, !tbaa !24
  %t544 = icmp sge i64 %t543, 0
  %t547 = and i1 %t542, %t544
  store i1 %t547, ptr %l304, !tbaa !21
  br label %bb82
bb82:
  %t548 = load i64, ptr %l37, !tbaa !24
  %t549 = load i64, ptr %l36, !tbaa !24
  %t552 = icmp slt i64 %t548, %t549
  %t554 = xor i1 %t552, true
  br i1 %t554, label %bb83, label %bb84
bb83:
  br label %bb87
bb84:
  br label %bb85
bb85:
  %t556 = load i64, ptr %l33, !tbaa !24
  %t557 = load i64, ptr %l37, !tbaa !24
  %t558 = load i64, ptr %l35, !tbaa !24
  %t561 = mul i64 %t557, %t558
  %t564 = add i64 %t556, %t561
  %t566 = load ptr, ptr %l0, !tbaa !29
  %t568 = getelementptr %"compiler/eval:Machine", ptr %t566, i32 0, i32 47
  %t569 = load { i64, ptr }, ptr %t568, !tbaa !27
  store { i64, ptr } %t569, ptr %l315, !tbaa !27
  %t572 = getelementptr { i64, ptr }, ptr %l315, i32 0, i32 1
  %t573 = load ptr, ptr %t572, !tbaa !27
  %t574 = getelementptr i64, ptr %t573, i64 %t564
  store i64 0, ptr %t574, !tbaa !34
  br label %bb86
bb86:
  %t575 = load i64, ptr %l37, !tbaa !24
  %t578 = add i64 %t575, 1
  store i64 %t578, ptr %l37, !tbaa !24
  br label %bb82
bb87:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2enewTaskSlot(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/eval:task"
  %l6 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 57
  store ptr %t3, ptr %l2, !tbaa !29
  %t4 = call %"compiler/eval:task" @compiler_2feval_3atask_2ector(ptr %s0)
  store %"compiler/eval:task" %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load %"compiler/eval:task", ptr %l3
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3atask_3e_2ePush_3ccompiler_2feval_3atask_3e(ptr %v0, ptr %t5, %"compiler/eval:task" %t6)
  br label %bb2
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/eval:Machine", ptr %t7, i32 0, i32 57
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3atask_3e_2eLen_3ccompiler_2feval_3atask_3e(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l6
  br label %bb3
bb3:
  %t12 = load i64, ptr %l6, !tbaa !24
  %t13 = sub i64 %t12, 1
  call void @__olang_scope_close(ptr %s0)
  store i64 %t13, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eoverflows(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i32 %a3, %"compiler/mir:Range" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca %"compiler/mir:Range"
  %l5 = alloca { i64, [4 x i64] }
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i1
  %l10 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l20 = alloca { i64, [4 x i64] }
  %l24 = alloca i32
  %l28 = alloca i64
  %l31 = alloca i64
  %l34 = alloca i64
  %l41 = alloca i64
  %l47 = alloca double
  %l50 = alloca i1
  %l55 = alloca i64
  %l58 = alloca i64
  %l61 = alloca i1
  %l64 = alloca i64
  %l66 = alloca i1
  %l73 = alloca i1
  %l78 = alloca i64
  %l82 = alloca i1
  %l83 = alloca i64
  %l85 = alloca i64
  %l89 = alloca ptr
  %l90 = alloca ptr
  %l91 = alloca i64
  %l95 = alloca { i64, [4 x i64] }
  %l96 = alloca i64
  %l98 = alloca i64
  %l101 = alloca i64
  %l103 = alloca i64
  %l106 = alloca i64
  %l108 = alloca i64
  %l111 = alloca i1
  %l116 = alloca i64
  %l118 = alloca i64
  %l123 = alloca i1
  %l126 = alloca i1
  %l141 = alloca i1
  %l149 = alloca i1
  %l152 = alloca i1
  %l155 = alloca i64
  %l157 = alloca i64
  %l162 = alloca i64
  %l164 = alloca i64
  %l166 = alloca i1
  %l173 = alloca i1
  %l177 = alloca i1
  %l179 = alloca i64
  %l195 = alloca i64
  %l197 = alloca i64
  %l199 = alloca i1
  %l200 = alloca i64
  %l202 = alloca i64
  %l209 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i32 %a3, ptr %l3
  store %"compiler/mir:Range" %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t3 = load %"compiler/mir:Range", ptr %l4
  %t7 = call { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %t1, i64 %t2, %"compiler/mir:Range" %t3, i64 0)
  store { i64, [4 x i64] } %t7, ptr %l20
  br label %bb1
bb1:
  %t8 = load { i64, [4 x i64] }, ptr %l20
  store { i64, [4 x i64] } %t8, ptr %l5
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i64, ptr %l1, !tbaa !24
  %t11 = load { i64, [4 x i64] }, ptr %l5
  %t15 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eopType(ptr %v0, ptr %t9, i64 %t10, { i64, [4 x i64] } %t11)
  store i32 %t15, ptr %l24
  br label %bb2
bb2:
  %t16 = load i32, ptr %l24, !tbaa !23
  store i32 %t16, ptr %l6, !tbaa !23
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load i64, ptr %l1, !tbaa !24
  %t19 = load { i64, [4 x i64] }, ptr %l5
  %t23 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %t17, i64 %t18, { i64, [4 x i64] } %t19)
  store i64 %t23, ptr %l28
  br label %bb3
bb3:
  %t24 = load i64, ptr %l28, !tbaa !24
  store i64 %t24, ptr %l7, !tbaa !24
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i32, ptr %l3, !tbaa !23
  %t29 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eibits(ptr %v0, ptr %t25, i32 %t26)
  store i64 %t29, ptr %l31
  br label %bb4
bb4:
  %t30 = load i64, ptr %l31, !tbaa !24
  store i64 %t30, ptr %l8, !tbaa !24
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l3, !tbaa !23
  %t35 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t31, i32 %t32)
  store i64 %t35, ptr %l34
  br label %bb5
bb5:
  %t36 = load i64, ptr @G_2ecompiler_2feval_2evInt, !tbaa !24
  %t37 = load i64, ptr %l34, !tbaa !24
  %t39 = icmp eq i64 %t37, %t36
  store i1 %t39, ptr %l9, !tbaa !21
  %t41 = load i32, ptr %l2, !range !{i32 0, i32 54}
  %t43 = trunc i64 20 to i32
  %t44 = icmp eq i32 %t41, %t43
  br i1 %t44, label %bb6, label %bb7
bb6:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load i32, ptr %l6, !tbaa !23
  %t50 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t46, i32 %t47)
  store i64 %t50, ptr %l41
  br label %bb8
bb7:
  br label %bb24
bb8:
  %t51 = load i64, ptr @G_2ecompiler_2feval_2evFloat, !tbaa !24
  %t52 = load i64, ptr %l41, !tbaa !24
  %t54 = icmp eq i64 %t52, %t51
  br i1 %t54, label %bb9, label %bb10
bb9:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load i64, ptr %l7, !tbaa !24
  %t58 = load i32, ptr %l6, !tbaa !23
  %t62 = call double @compiler_2feval_2ecompiler_2feval_3aMachine_2etoF64(ptr %v0, ptr %t56, i64 %t57, i32 %t58)
  store double %t62, ptr %l47
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t63 = load i64, ptr %l8, !tbaa !24
  %t64 = load i1, ptr %l9, !tbaa !21
  %t65 = load double, ptr %l47, !tbaa !26
  %t68 = call i1 @compiler_2feval_2efloatFits(double %t65, i64 %t63, i1 %t64)
  store i1 %t68, ptr %l50
  br label %bb12
bb12:
  %t69 = load i1, ptr %l50, !tbaa !21
  %t70 = xor i1 %t69, true
  store i1 %t70, ptr %rv
  br label %ret
bb13:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load i64, ptr %l7, !tbaa !24
  %t74 = load i32, ptr %l6, !tbaa !23
  %t78 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintValue(ptr %v0, ptr %t72, i64 %t73, i32 %t74)
  store i64 %t78, ptr %l55
  br label %bb14
bb14:
  %t79 = load i64, ptr %l55, !tbaa !24
  store i64 %t79, ptr %l10, !tbaa !24
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load i32, ptr %l6, !tbaa !23
  %t84 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t80, i32 %t81)
  store i64 %t84, ptr %l58
  br label %bb15
bb15:
  %t85 = load i64, ptr @G_2ecompiler_2feval_2evUint, !tbaa !24
  %t86 = load i64, ptr %l58, !tbaa !24
  %t88 = icmp eq i64 %t86, %t85
  br i1 %t88, label %bb16, label %bb17
bb16:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load i32, ptr %l6, !tbaa !23
  %t94 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eibits(ptr %v0, ptr %t90, i32 %t91)
  store i64 %t94, ptr %l64
  br label %bb18
bb17:
  store i1 false, ptr %l61, !tbaa !21
  br label %bb19
bb18:
  %t95 = load i64, ptr %l64, !tbaa !24
  %t96 = icmp eq i64 %t95, 64
  store i1 %t96, ptr %l61, !tbaa !21
  br label %bb19
bb19:
  %t98 = load i1, ptr %l61, !tbaa !21
  br i1 %t98, label %bb20, label %bb21
bb20:
  %t99 = load i64, ptr %l10, !tbaa !24
  %t101 = icmp slt i64 %t99, 0
  store i1 %t101, ptr %l66, !tbaa !21
  br label %bb22
bb21:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb22
bb22:
  %t103 = load i1, ptr %l66, !tbaa !21
  %t104 = load i64, ptr %l10, !tbaa !24
  %t106 = load i64, ptr %l8, !tbaa !24
  %t107 = load i1, ptr %l9, !tbaa !21
  %t112 = call i1 @compiler_2feval_2efitsBits(i64 %t104, i1 %t103, i64 %t106, i1 %t107)
  store i1 %t112, ptr %l73
  br label %bb23
bb23:
  %t113 = load i1, ptr %l73, !tbaa !21
  %t114 = xor i1 %t113, true
  store i1 %t114, ptr %rv
  br label %ret
bb24:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load i64, ptr %l7, !tbaa !24
  %t118 = load i32, ptr %l3, !tbaa !23
  %t122 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintValue(ptr %v0, ptr %t116, i64 %t117, i32 %t118)
  store i64 %t122, ptr %l78
  br label %bb25
bb25:
  %t123 = load i64, ptr %l78, !tbaa !24
  store i64 %t123, ptr %l12, !tbaa !24
  %t124 = load i32, ptr %l2, !range !{i32 0, i32 54}
  %t126 = trunc i64 0 to i32
  %t127 = icmp eq i32 %t124, %t126
  br i1 %t127, label %bb26, label %bb27
bb26:
  %t129 = load i1, ptr %l9, !tbaa !21
  br i1 %t129, label %bb28, label %bb29
bb27:
  br label %bb32
bb28:
  %t131 = load i64, ptr %l12, !tbaa !24
  store i64 %t131, ptr %l83, !tbaa !24
  %t132 = load i64, ptr %l8, !tbaa !24
  %t134 = call i64 @compiler_2feval_2eminBits(i64 %t132)
  store i64 %t134, ptr %l85
  br label %bb30
bb29:
  %t135 = load i64, ptr %l12, !tbaa !24
  %t137 = icmp ne i64 %t135, 0
  store i1 %t137, ptr %l82, !tbaa !21
  br label %bb31
bb30:
  %t139 = load i64, ptr %l83, !tbaa !24
  %t140 = load i64, ptr %l85, !tbaa !24
  %t141 = icmp eq i64 %t139, %t140
  store i1 %t141, ptr %l82, !tbaa !21
  br label %bb31
bb31:
  %t143 = load i1, ptr %l82, !tbaa !21
  store i1 %t143, ptr %rv
  br label %ret
bb32:
  %t144 = load ptr, ptr %l0, !tbaa !29
  store ptr %t144, ptr %l89, !tbaa !29
  %t145 = load ptr, ptr %l0, !tbaa !29
  store ptr %t145, ptr %l90, !tbaa !29
  %t146 = load i64, ptr %l1, !tbaa !24
  store i64 %t146, ptr %l91, !tbaa !24
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t148 = load i64, ptr %l1, !tbaa !24
  %t149 = load %"compiler/mir:Range", ptr %l4
  %t153 = call { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %t147, i64 %t148, %"compiler/mir:Range" %t149, i64 1)
  store { i64, [4 x i64] } %t153, ptr %l95
  br label %bb33
bb33:
  %t154 = load ptr, ptr %l90, !tbaa !29
  %t155 = load i64, ptr %l91, !tbaa !24
  %t156 = load { i64, [4 x i64] }, ptr %l95
  %t157 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %t154, i64 %t155, { i64, [4 x i64] } %t156)
  store i64 %t157, ptr %l96
  br label %bb34
bb34:
  %t158 = load i32, ptr %l3, !tbaa !23
  %t159 = load ptr, ptr %l89, !tbaa !29
  %t160 = load i64, ptr %l96, !tbaa !24
  %t162 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintValue(ptr %v0, ptr %t159, i64 %t160, i32 %t158)
  store i64 %t162, ptr %l98
  br label %bb35
bb35:
  %t163 = load i64, ptr %l98, !tbaa !24
  store i64 %t163, ptr %l13, !tbaa !24
  %t164 = load i1, ptr %l9, !tbaa !21
  %t166 = xor i1 %t164, true
  br i1 %t166, label %bb36, label %bb37
bb36:
  %t168 = load i64, ptr %l7, !tbaa !24
  store i64 %t168, ptr %l101, !tbaa !24
  %t169 = load i64, ptr %l8, !tbaa !24
  %t171 = call i64 @compiler_2feval_2ebmask(i64 %t169)
  store i64 %t171, ptr %l103
  br label %bb38
bb37:
  br label %bb74
bb38:
  %t172 = load i64, ptr %l101, !tbaa !24
  %t173 = load i64, ptr %l103, !tbaa !24
  %t174 = and i64 %t172, %t173
  store i64 %t174, ptr %l14, !tbaa !65
  %t177 = load i64, ptr %l13, !tbaa !24
  store i64 %t177, ptr %l106, !tbaa !24
  %t178 = load i64, ptr %l8, !tbaa !24
  %t180 = call i64 @compiler_2feval_2ebmask(i64 %t178)
  store i64 %t180, ptr %l108
  br label %bb39
bb39:
  %t181 = load i64, ptr %l106, !tbaa !24
  %t182 = load i64, ptr %l108, !tbaa !24
  %t183 = and i64 %t181, %t182
  store i64 %t183, ptr %l15, !tbaa !65
  %t186 = load i32, ptr %l2, !range !{i32 0, i32 54}
  %t188 = trunc i64 3 to i32
  %t189 = icmp eq i32 %t186, %t188
  br i1 %t189, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb50
bb42:
  %t191 = load i64, ptr %l14, !tbaa !65
  %t192 = load i64, ptr %l15, !tbaa !65
  %t195 = add i64 %t191, %t192
  store i64 %t195, ptr %l116, !tbaa !65
  %t196 = load i64, ptr %l8, !tbaa !24
  %t198 = call i64 @compiler_2feval_2ebmask(i64 %t196)
  store i64 %t198, ptr %l118
  br label %bb43
bb43:
  %t199 = load i64, ptr %l118, !tbaa !24
  %t200 = load i64, ptr %l116, !tbaa !65
  %t202 = and i64 %t200, %t199
  %t203 = load i64, ptr %l14, !tbaa !65
  %t206 = icmp ult i64 %t202, %t203
  br i1 %t206, label %bb44, label %bb45
bb44:
  store i1 true, ptr %l123, !tbaa !21
  br label %bb49
bb45:
  %t208 = load i64, ptr %l8, !tbaa !24
  %t210 = icmp eq i64 %t208, 64
  br i1 %t210, label %bb46, label %bb47
bb46:
  %t212 = load i64, ptr %l14, !tbaa !65
  %t213 = load i64, ptr %l15, !tbaa !65
  %t216 = add i64 %t212, %t213
  %t217 = load i64, ptr %l14, !tbaa !65
  %t220 = icmp ult i64 %t216, %t217
  store i1 %t220, ptr %l126, !tbaa !21
  br label %bb48
bb47:
  store i1 false, ptr %l126, !tbaa !21
  br label %bb48
bb48:
  %t222 = load i1, ptr %l126, !tbaa !21
  store i1 %t222, ptr %l123, !tbaa !21
  br label %bb49
bb49:
  %t223 = load i1, ptr %l123, !tbaa !21
  store i1 %t223, ptr %l111, !tbaa !21
  br label %bb73
bb50:
  %t224 = load i32, ptr %l2, !range !{i32 0, i32 54}
  %t226 = trunc i64 4 to i32
  %t227 = icmp eq i32 %t224, %t226
  br i1 %t227, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb54
bb53:
  %t229 = load i64, ptr %l14, !tbaa !65
  %t230 = load i64, ptr %l15, !tbaa !65
  %t233 = icmp ult i64 %t229, %t230
  store i1 %t233, ptr %l111, !tbaa !21
  br label %bb73
bb54:
  %t235 = load i32, ptr %l2, !range !{i32 0, i32 54}
  %t237 = trunc i64 5 to i32
  %t238 = icmp eq i32 %t235, %t237
  br i1 %t238, label %bb55, label %bb56
bb55:
  br label %bb57
bb56:
  br label %bb68
bb57:
  %t240 = load i64, ptr %l14, !tbaa !65
  %t242 = icmp ne i64 %t240, 0
  br i1 %t242, label %bb58, label %bb59
bb58:
  %t244 = load i64, ptr %l14, !tbaa !65
  %t245 = load i64, ptr %l15, !tbaa !65
  %t248 = mul i64 %t244, %t245
  %t249 = load i64, ptr %l14, !tbaa !65
  %t252 = udiv i64 %t248, %t249
  %t253 = load i64, ptr %l15, !tbaa !65
  %t256 = icmp ne i64 %t252, %t253
  br i1 %t256, label %bb60, label %bb61
bb59:
  store i1 false, ptr %l141, !tbaa !21
  br label %bb67
bb60:
  store i1 true, ptr %l149, !tbaa !21
  br label %bb66
bb61:
  %t258 = load i64, ptr %l8, !tbaa !24
  %t260 = icmp slt i64 %t258, 64
  br i1 %t260, label %bb62, label %bb63
bb62:
  %t262 = load i64, ptr %l14, !tbaa !65
  %t263 = load i64, ptr %l15, !tbaa !65
  %t266 = mul i64 %t262, %t263
  store i64 %t266, ptr %l155, !tbaa !65
  %t267 = load i64, ptr %l8, !tbaa !24
  %t269 = call i64 @compiler_2feval_2ebmask(i64 %t267)
  store i64 %t269, ptr %l157
  br label %bb64
bb63:
  store i1 false, ptr %l152, !tbaa !21
  br label %bb65
bb64:
  %t270 = load i64, ptr %l157, !tbaa !24
  %t271 = load i64, ptr %l155, !tbaa !65
  %t273 = icmp ugt i64 %t271, %t270
  store i1 %t273, ptr %l152, !tbaa !21
  br label %bb65
bb65:
  %t275 = load i1, ptr %l152, !tbaa !21
  store i1 %t275, ptr %l149, !tbaa !21
  br label %bb66
bb66:
  %t276 = load i1, ptr %l149, !tbaa !21
  store i1 %t276, ptr %l141, !tbaa !21
  br label %bb67
bb67:
  %t277 = load i1, ptr %l141, !tbaa !21
  store i1 %t277, ptr %l111, !tbaa !21
  br label %bb73
bb68:
  br i1 true, label %bb69, label %bb70
bb69:
  br label %bb71
bb70:
  br label %bb72
bb71:
  store i1 false, ptr %l111, !tbaa !21
  br label %bb73
bb72:
  call void @__olang_check_failed(ptr @olang_loc_63a030dc495bebe2_de58b898255fa7b6)
  unreachable
bb73:
  %t278 = load i1, ptr %l111, !tbaa !21
  store i1 %t278, ptr %rv
  br label %ret
bb74:
  %t279 = load i32, ptr %l2, !range !{i32 0, i32 54}
  %t281 = trunc i64 6 to i32
  %t282 = icmp eq i32 %t279, %t281
  br i1 %t282, label %bb75, label %bb76
bb75:
  %t284 = load i64, ptr %l12, !tbaa !24
  store i64 %t284, ptr %l162, !tbaa !24
  %t285 = load i64, ptr %l8, !tbaa !24
  %t287 = call i64 @compiler_2feval_2eminBits(i64 %t285)
  store i64 %t287, ptr %l164
  br label %bb77
bb76:
  br label %bb81
bb77:
  %t288 = load i64, ptr %l162, !tbaa !24
  %t289 = load i64, ptr %l164, !tbaa !24
  %t290 = icmp eq i64 %t288, %t289
  br i1 %t290, label %bb78, label %bb79
bb78:
  %t292 = load i64, ptr %l13, !tbaa !24
  %t294 = icmp eq i64 %t292, -1
  store i1 %t294, ptr %l166, !tbaa !21
  br label %bb80
bb79:
  store i1 false, ptr %l166, !tbaa !21
  br label %bb80
bb80:
  %t296 = load i1, ptr %l166, !tbaa !21
  store i1 %t296, ptr %rv
  br label %ret
bb81:
  %t297 = load i64, ptr %l8, !tbaa !24
  %t299 = icmp slt i64 %t297, 64
  br i1 %t299, label %bb82, label %bb83
bb82:
  %t301 = load i32, ptr %l2, !range !{i32 0, i32 54}
  %t303 = trunc i64 5 to i32
  %t304 = icmp eq i32 %t301, %t303
  br i1 %t304, label %bb84, label %bb85
bb83:
  br label %bb113
bb84:
  %t306 = load i32, ptr %l2, !range !{i32 0, i32 54}
  %t307 = load i64, ptr %l12, !tbaa !24
  %t308 = load i64, ptr %l13, !tbaa !24
  %t312 = call i1 @compiler_2feval_2eoverflows64(i32 %t306, i64 %t307, i64 %t308, i1 true)
  store i1 %t312, ptr %l177
  br label %bb86
bb85:
  store i1 false, ptr %l173, !tbaa !21
  br label %bb87
bb86:
  %t313 = load i1, ptr %l177, !tbaa !21
  store i1 %t313, ptr %l173, !tbaa !21
  br label %bb87
bb87:
  %t314 = load i1, ptr %l173, !tbaa !21
  br i1 %t314, label %bb88, label %bb89
bb88:
  store i1 true, ptr %rv
  br label %ret
bb89:
  br label %bb90
bb90:
  %t316 = load i32, ptr %l2, !range !{i32 0, i32 54}
  %t318 = trunc i64 3 to i32
  %t319 = icmp eq i32 %t316, %t318
  br i1 %t319, label %bb91, label %bb92
bb91:
  br label %bb93
bb92:
  br label %bb94
bb93:
  %t321 = load i64, ptr %l12, !tbaa !24
  %t322 = load i64, ptr %l13, !tbaa !24
  %t325 = add i64 %t321, %t322
  store i64 %t325, ptr %l179, !tbaa !24
  br label %bb107
bb94:
  %t327 = load i32, ptr %l2, !range !{i32 0, i32 54}
  %t329 = trunc i64 4 to i32
  %t330 = icmp eq i32 %t327, %t329
  br i1 %t330, label %bb95, label %bb96
bb95:
  br label %bb97
bb96:
  br label %bb98
bb97:
  %t332 = load i64, ptr %l12, !tbaa !24
  %t333 = load i64, ptr %l13, !tbaa !24
  %t336 = sub i64 %t332, %t333
  store i64 %t336, ptr %l179, !tbaa !24
  br label %bb107
bb98:
  %t338 = load i32, ptr %l2, !range !{i32 0, i32 54}
  %t340 = trunc i64 5 to i32
  %t341 = icmp eq i32 %t338, %t340
  br i1 %t341, label %bb99, label %bb100
bb99:
  br label %bb101
bb100:
  br label %bb102
bb101:
  %t343 = load i64, ptr %l12, !tbaa !24
  %t344 = load i64, ptr %l13, !tbaa !24
  %t347 = mul i64 %t343, %t344
  store i64 %t347, ptr %l179, !tbaa !24
  br label %bb107
bb102:
  br i1 true, label %bb103, label %bb104
bb103:
  br label %bb105
bb104:
  br label %bb106
bb105:
  store i64 0, ptr %l179, !tbaa !24
  br label %bb107
bb106:
  call void @__olang_check_failed(ptr @olang_loc_ffc454b782ecc9e3_c14f69603a3a3b57)
  unreachable
bb107:
  %t349 = load i64, ptr %l179, !tbaa !24
  store i64 %t349, ptr %l16, !tbaa !24
  %t350 = load i64, ptr %l16, !tbaa !24
  store i64 %t350, ptr %l195, !tbaa !24
  %t351 = load i64, ptr %l8, !tbaa !24
  %t353 = call i64 @compiler_2feval_2eminBits(i64 %t351)
  store i64 %t353, ptr %l197
  br label %bb108
bb108:
  %t354 = load i64, ptr %l195, !tbaa !24
  %t355 = load i64, ptr %l197, !tbaa !24
  %t356 = icmp slt i64 %t354, %t355
  br i1 %t356, label %bb109, label %bb110
bb109:
  store i1 true, ptr %l199, !tbaa !21
  br label %bb112
bb110:
  %t358 = load i64, ptr %l16, !tbaa !24
  store i64 %t358, ptr %l200, !tbaa !24
  %t359 = load i64, ptr %l8, !tbaa !24
  %t361 = call i64 @compiler_2feval_2eminBits(i64 %t359)
  store i64 %t361, ptr %l202
  br label %bb111
bb111:
  %t362 = load i64, ptr %l202, !tbaa !24
  %t363 = add i64 %t362, 1
  %t365 = sub i64 0, %t363
  %t366 = load i64, ptr %l200, !tbaa !24
  %t368 = icmp sgt i64 %t366, %t365
  store i1 %t368, ptr %l199, !tbaa !21
  br label %bb112
bb112:
  %t370 = load i1, ptr %l199, !tbaa !21
  store i1 %t370, ptr %rv
  br label %ret
bb113:
  %t371 = load i32, ptr %l2, !range !{i32 0, i32 54}
  %t372 = load i64, ptr %l12, !tbaa !24
  %t373 = load i64, ptr %l13, !tbaa !24
  %t377 = call i1 @compiler_2feval_2eoverflows64(i32 %t371, i64 %t372, i64 %t373, i1 true)
  store i1 %t377, ptr %l209
  br label %bb114
bb114:
  %t378 = load i1, ptr %l209, !tbaa !21
  store i1 %t378, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2epairDots(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, %"compiler/eval:Ptr" %a2, %"compiler/eval:Ptr" %a3, i64 %a4, i64 %a5, i64 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/eval:Ptr"
  %l2 = alloca %"compiler/eval:Ptr"
  %l3 = alloca %"compiler/eval:Ptr"
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca %"compiler/eval:Ptr"
  %l14 = alloca float
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca float
  %l25 = alloca i64
  %l28 = alloca i64
  %l51 = alloca %"compiler/eval:Ptr"
  %l54 = alloca i64
  %l58 = alloca float
  %l70 = alloca ptr
  %l80 = alloca %"compiler/eval:Ptr"
  %l81 = alloca i64
  %l84 = alloca float
  %l85 = alloca ptr
  %l95 = alloca %"compiler/eval:Ptr"
  %l96 = alloca i64
  %l99 = alloca float
  %l103 = alloca float
  %l104 = alloca float
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/eval:Ptr" %a1, ptr %l1
  store %"compiler/eval:Ptr" %a2, ptr %l2
  store %"compiler/eval:Ptr" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l7, !tbaa !24
  store i64 %a4, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t3 = load i64, ptr %l8, !tbaa !24
  %t4 = load i64, ptr %l7, !tbaa !24
  %t7 = icmp sgt i64 %t3, %t4
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l9, !tbaa !24
  %t11 = icmp sgt i64 %t9, 0
  br i1 %t11, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb6
bb3:
  %t13 = load i64, ptr %l8, !tbaa !24
  %t14 = load i64, ptr %l7, !tbaa !24
  %t17 = sub i64 %t13, %t14
  %t18 = load i64, ptr %l9, !tbaa !24
  %t21 = add i64 %t17, %t18
  %t23 = sub i64 %t21, 1
  %t24 = load i64, ptr %l9, !tbaa !24
  %t27 = sdiv i64 %t23, %t24
  store i64 %t27, ptr %l28, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb5
bb5:
  %t29 = load i64, ptr %l28, !tbaa !24
  store i64 %t29, ptr %l25, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l25, !tbaa !24
  store i64 %t30, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t31 = load i64, ptr %l11, !tbaa !24
  %t32 = load i64, ptr %l10, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb33
bb9:
  br label %bb10
bb10:
  %t39 = load i64, ptr %l7, !tbaa !24
  %t40 = load i64, ptr %l11, !tbaa !24
  %t41 = load i64, ptr %l9, !tbaa !24
  %t44 = mul i64 %t40, %t41
  %t47 = add i64 %t39, %t44
  store i64 %t47, ptr %l12, !tbaa !24
  %t49 = getelementptr %"compiler/eval:Ptr", ptr %l1, i32 0, i32 0
  %t50 = load i64, ptr %t49, !tbaa !24
  %t51 = getelementptr %"compiler/eval:Ptr", ptr %l1, i32 0, i32 1
  %t52 = load i64, ptr %t51, !tbaa !24
  %t53 = load i64, ptr %l12, !tbaa !24
  %t55 = mul i64 4, %t53
  %t58 = add i64 %t52, %t55
  %t61 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s2, i64 %t50, i64 %t58)
  store %"compiler/eval:Ptr" %t61, ptr %l51
  br label %bb11
bb11:
  %t62 = load %"compiler/eval:Ptr", ptr %l51
  store %"compiler/eval:Ptr" %t62, ptr %l13
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load %"compiler/eval:Ptr", ptr %l13
  %t67 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t63, %"compiler/eval:Ptr" %t64, i64 4)
  store i64 %t67, ptr %l54
  br label %bb12
bb12:
  %t68 = load i64, ptr %l54, !tbaa !24
  %t69 = and i64 %t68, 4294967295
  %t71 = trunc i64 %t69 to i32
  %t73 = bitcast i32 %t71 to float
  %t75 = call float @compiler_2feval_2eflushF32(float %t73)
  store float %t75, ptr %l58
  br label %bb13
bb13:
  %t76 = load float, ptr %l58, !tbaa !25
  store float %t76, ptr %l14, !tbaa !25
  store %olang.scope zeroinitializer, ptr %s3
  %t77 = insertvalue [2 x i64] undef, i64 1, 0
  %t78 = insertvalue [2 x i64] %t77, i64 0, 1
  %t80 = call ptr @__olang_scope_alloc_a(ptr %s3, i64 16, i64 8)
  store [2 x i64] %t78, ptr %t80
  store ptr %t80, ptr %l15
  store i64 0, ptr %l16, !tbaa !24
  %t82 = load ptr, ptr %l15
  store i64 2, ptr %l17, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s4
  %t85 = load i64, ptr %l16, !tbaa !24
  %t86 = load i64, ptr %l17, !tbaa !24
  %t89 = icmp slt i64 %t85, %t86
  %t91 = xor i1 %t89, true
  br i1 %t91, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s4)
  br label %bb27
bb16:
  br label %bb17
bb17:
  %t93 = load ptr, ptr %l15
  %t94 = load i64, ptr %l16, !tbaa !24
  %t97 = getelementptr [2 x i64], ptr %t93, i64 0, i64 %t94
  %t98 = load i64, ptr %t97, !tbaa !34
  store i64 %t98, ptr %l18, !tbaa !24
  %t100 = load ptr, ptr %l0, !tbaa !29
  store ptr %t100, ptr %l70, !tbaa !29
  %t101 = getelementptr %"compiler/eval:Ptr", ptr %l2, i32 0, i32 0
  %t102 = load i64, ptr %t101, !tbaa !24
  %t103 = getelementptr %"compiler/eval:Ptr", ptr %l2, i32 0, i32 1
  %t104 = load i64, ptr %t103, !tbaa !24
  %t105 = load i64, ptr %l12, !tbaa !24
  %t109 = mul i64 %t105, %a5
  %t110 = load i64, ptr %l18, !tbaa !24
  %t113 = add i64 %t109, %t110
  %t115 = mul i64 2, %t113
  %t118 = add i64 %t104, %t115
  %t121 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s4, i64 %t102, i64 %t118)
  store %"compiler/eval:Ptr" %t121, ptr %l80
  br label %bb18
bb18:
  %t122 = load ptr, ptr %l70, !tbaa !29
  %t123 = load %"compiler/eval:Ptr", ptr %l80
  %t124 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t122, %"compiler/eval:Ptr" %t123, i64 2)
  store i64 %t124, ptr %l81
  br label %bb19
bb19:
  %t125 = load i64, ptr %l81, !tbaa !24
  %t126 = and i64 %t125, 65535
  %t128 = trunc i64 %t126 to i16
  %t130 = call float @compiler_2feval_2eflushBF16(i16 %t128)
  store float %t130, ptr %l84
  br label %bb20
bb20:
  %t131 = load float, ptr %l84, !tbaa !25
  store float %t131, ptr %l19, !tbaa !25
  %t132 = load ptr, ptr %l0, !tbaa !29
  store ptr %t132, ptr %l85, !tbaa !29
  %t133 = getelementptr %"compiler/eval:Ptr", ptr %l3, i32 0, i32 0
  %t134 = load i64, ptr %t133, !tbaa !24
  %t135 = getelementptr %"compiler/eval:Ptr", ptr %l3, i32 0, i32 1
  %t136 = load i64, ptr %t135, !tbaa !24
  %t137 = load i64, ptr %l12, !tbaa !24
  %t141 = mul i64 %t137, %a6
  %t142 = load i64, ptr %l18, !tbaa !24
  %t145 = add i64 %t141, %t142
  %t147 = mul i64 2, %t145
  %t150 = add i64 %t136, %t147
  %t153 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s4, i64 %t134, i64 %t150)
  store %"compiler/eval:Ptr" %t153, ptr %l95
  br label %bb21
bb21:
  %t154 = load ptr, ptr %l85, !tbaa !29
  %t155 = load %"compiler/eval:Ptr", ptr %l95
  %t156 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t154, %"compiler/eval:Ptr" %t155, i64 2)
  store i64 %t156, ptr %l96
  br label %bb22
bb22:
  %t157 = load i64, ptr %l96, !tbaa !24
  %t158 = and i64 %t157, 65535
  %t160 = trunc i64 %t158 to i16
  %t162 = call float @compiler_2feval_2eflushBF16(i16 %t160)
  store float %t162, ptr %l99
  br label %bb23
bb23:
  %t163 = load float, ptr %l99, !tbaa !25
  %t164 = load float, ptr %l19, !tbaa !25
  %t166 = load float, ptr %l14, !tbaa !25
  %t170 = call float @std_2fprelude_2fnumber_2eF32_2eFma_3cF32_3e(float %t164, float %t163, float %t166)
  store float %t170, ptr %l103
  br label %bb24
bb24:
  %t171 = load float, ptr %l103, !tbaa !25
  %t172 = call float @compiler_2feval_2eflushF32(float %t171)
  store float %t172, ptr %l104
  br label %bb25
bb25:
  %t173 = load float, ptr %l104, !tbaa !25
  store float %t173, ptr %l14, !tbaa !25
  call void @__olang_scope_close(ptr %s4)
  br label %bb26
bb26:
  %t174 = load i64, ptr %l16, !tbaa !24
  %t177 = add i64 %t174, 1
  store i64 %t177, ptr %l16, !tbaa !24
  br label %bb14
bb27:
  call void @__olang_scope_close(ptr %s3)
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr %"compiler/eval:Machine", ptr %t179, i32 0, i32 23
  %t182 = load i1, ptr %t181, !tbaa !21
  br i1 %t182, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb29:
  br label %bb30
bb30:
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t185 = load %"compiler/eval:Ptr", ptr %l13
  %t186 = load float, ptr %l14, !tbaa !25
  %t188 = bitcast float %t186 to i32
  %t190 = zext i32 %t188 to i64
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t184, %"compiler/eval:Ptr" %t185, i64 4, i64 %t190)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s2)
  br label %bb32
bb32:
  %t194 = load i64, ptr %l11, !tbaa !24
  %t197 = add i64 %t194, 1
  store i64 %t197, ptr %l11, !tbaa !24
  br label %bb7
bb33:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2eplanCaps(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/eval:Ptr" %a2, i64 %a3, ptr %a4, %"compiler/mir:Range" %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/eval:Ptr"
  %l4 = alloca ptr
  %l5 = alloca %"compiler/mir:Range"
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca { i64, [1 x i64] }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca { i64, [1 x i64] }
  %l16 = alloca ptr
  %l19 = alloca i64
  %l21 = alloca i64
  %l26 = alloca { i64, [1 x i64] }
  %l27 = alloca i64
  %l44 = alloca { i64, [1 x i64] }
  %l48 = alloca i64
  %l51 = alloca i64
  %l53 = alloca ptr
  %l59 = alloca %"compiler/eval:Ptr"
  %l63 = alloca i64
  %s7 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/eval:Ptr" %a2, ptr %l2
  store ptr %a4, ptr %l4
  store %"compiler/mir:Range" %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call ptr @compiler_2feval_2ecompiler_2feval_3aMachine_2efnOfFrame(ptr %v0, ptr %v0, ptr %t1, i64 %t2)
  store ptr %t5, ptr %l16
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l16, !tbaa !29
  store ptr %t6, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  %t7 = load ptr, ptr %l4, !tbaa !29
  %t9 = getelementptr %"compiler/mir:Fn", ptr %t7, i32 0, i32 6
  store ptr %t9, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb2
bb2:
  %t11 = load i64, ptr %l9, !tbaa !24
  store i64 %t11, ptr %l19, !tbaa !24
  %t12 = load ptr, ptr %l8, !tbaa !29
  %t14 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eLen_3ccompiler_2fmir_3aVarKind_3e(ptr %v1, ptr %t12)
  store i64 %t14, ptr %l21
  br label %bb3
bb3:
  %t15 = load i64, ptr %l19, !tbaa !24
  %t16 = load i64, ptr %l21, !tbaa !24
  %t17 = icmp slt i64 %t15, %t16
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb4, label %bb5
bb4:
  br label %bb32
bb5:
  br label %bb6
bb6:
  %t21 = load ptr, ptr %l8, !tbaa !29
  %t22 = load i64, ptr %l9, !tbaa !24
  %t25 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eAt_3ccompiler_2fmir_3aVarKind_3e(ptr %v1, ptr %t21, i64 %t22)
  store { i64, [1 x i64] } %t25, ptr %l26
  br label %bb7
bb7:
  %t26 = load { i64, [1 x i64] }, ptr %l26
  store { i64, [1 x i64] } %t26, ptr %l10
  %t27 = load { i64, [1 x i64] }, ptr %l10
  %t29 = extractvalue { i64, [1 x i64] } %t27, 0
  %t30 = icmp eq i64 %t29, 4
  br i1 %t30, label %bb8, label %bb9
bb8:
  %t32 = getelementptr { i64, [1 x i64] }, ptr %l10, i32 0, i32 1
  %t33 = getelementptr { i64 }, ptr %t32, i32 0, i32 0
  %t34 = load i64, ptr %t33
  store i64 %t34, ptr %l11, !tbaa !24
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t36 = load i64, ptr %l11, !tbaa !24
  store i64 %t36, ptr %l27, !tbaa !24
  br label %bb16
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i64 -1, ptr %l27, !tbaa !24
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_6e4848ba4497940f_2fc0910286fcd483)
  unreachable
bb16:
  %t38 = load i64, ptr %l27, !tbaa !24
  store i64 %t38, ptr %l12, !tbaa !24
  %t39 = load i64, ptr %l12, !tbaa !24
  %t41 = icmp slt i64 %t39, 0
  br i1 %t41, label %bb17, label %bb18
bb17:
  br label %bb31
bb18:
  br label %bb19
bb19:
  %t43 = load i64, ptr %l7, !tbaa !24
  %t44 = getelementptr %"compiler/mir:Range", ptr %l5, i32 0, i32 1
  %t45 = load i32, ptr %t44, !tbaa !23
  %t47 = sext i32 %t45 to i64
  %t50 = icmp sge i64 %t43, %t47
  br i1 %t50, label %bb20, label %bb21
bb20:
  br label %ret
bb21:
  br label %bb22
bb22:
  %t52 = load ptr, ptr %l6, !tbaa !29
  %t54 = getelementptr %"compiler/mir:Fn", ptr %t52, i32 0, i32 12
  %t55 = getelementptr %"compiler/mir:Range", ptr %l5, i32 0, i32 0
  %t56 = load i32, ptr %t55, !tbaa !23
  %t58 = sext i32 %t56 to i64
  %t59 = load i64, ptr %l7, !tbaa !24
  %t62 = add i64 %t58, %t59
  %t65 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %t54, i64 %t62)
  store { i64, [1 x i64] } %t65, ptr %l44
  br label %bb23
bb23:
  %t66 = load { i64, [1 x i64] }, ptr %l44
  store { i64, [1 x i64] } %t66, ptr %l13
  %t67 = load i64, ptr %l7, !tbaa !24
  %t70 = add i64 %t67, 1
  store i64 %t70, ptr %l7, !tbaa !24
  %t72 = load i64, ptr %l12, !tbaa !24
  store i64 %t72, ptr %l48, !tbaa !24
  %t73 = load ptr, ptr %l4, !tbaa !29
  %t75 = getelementptr %"compiler/mir:Fn", ptr %t73, i32 0, i32 5
  %t77 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %v1, ptr %t75)
  store i64 %t77, ptr %l51
  br label %bb24
bb24:
  %t78 = load i64, ptr %l48, !tbaa !24
  %t79 = load i64, ptr %l51, !tbaa !24
  %t80 = icmp slt i64 %t78, %t79
  br i1 %t80, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s7
  %t82 = load ptr, ptr %l0, !tbaa !29
  store ptr %t82, ptr %l53, !tbaa !29
  %t83 = getelementptr %"compiler/eval:Ptr", ptr %l2, i32 0, i32 0
  %t84 = load i64, ptr %t83, !tbaa !24
  %t86 = load i64, ptr %l12, !tbaa !24
  %t88 = mul i64 8, %t86
  %t91 = add i64 %a3, %t88
  %t94 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s7, i64 %t84, i64 %t91)
  store %"compiler/eval:Ptr" %t94, ptr %l59
  br label %bb27
bb26:
  br label %bb30
bb27:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load i64, ptr %l1, !tbaa !24
  %t97 = load { i64, [1 x i64] }, ptr %l13
  %t101 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escopeOf(ptr %v0, ptr %t95, i64 %t96, { i64, [1 x i64] } %t97)
  store i64 %t101, ptr %l63
  br label %bb28
bb28:
  %t102 = load ptr, ptr %l53, !tbaa !29
  %t103 = load %"compiler/eval:Ptr", ptr %l59
  %t104 = load i64, ptr %l63, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t102, %"compiler/eval:Ptr" %t103, i64 8, i64 %t104)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s7)
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t105 = load i64, ptr %l9, !tbaa !24
  %t108 = add i64 %t105, 1
  store i64 %t108, ptr %l9, !tbaa !24
  br label %bb2
bb32:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2eprimWide(ptr %v0, ptr %a0, i64 %a1, %"compiler/eval:Ptr" %a2, i32 %a3, i32 %a4, %"compiler/mir:Range" %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/eval:Ptr"
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca %"compiler/mir:Range"
  %l6 = alloca { i64, [4 x i64] }
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i1
  %l11 = alloca { i64, i64 }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca double
  %l15 = alloca { i64, i64 }
  %l18 = alloca { i64, i64 }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i1
  %l22 = alloca i64
  %l23 = alloca { i64, i64 }
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca { i64, i64 }
  %l29 = alloca { i64, i64 }
  %l30 = alloca i64
  %l31 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca { i64, i64 }
  %l43 = alloca { i64, i64 }
  %l49 = alloca i64
  %l50 = alloca { i64, i64 }
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca { i64, i64 }
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca { i64, i64 }
  %l60 = alloca { i64, i64 }
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca { i64, i64 }
  %l66 = alloca { i64, i64 }
  %l67 = alloca { i64, i64 }
  %l68 = alloca { i64, i64 }
  %l69 = alloca i64
  %l70 = alloca i64
  %l71 = alloca { i64, i64, i64, i64 }
  %l74 = alloca i64
  %l75 = alloca i64
  %l80 = alloca { i64, i64, i64, i64 }
  %l83 = alloca i64
  %l84 = alloca i64
  %l89 = alloca { i64, i64 }
  %l90 = alloca { i64, i64 }
  %l97 = alloca i64
  %l102 = alloca { i64, [4 x i64] }
  %l106 = alloca i32
  %l109 = alloca i64
  %l112 = alloca i64
  %l114 = alloca ptr
  %l118 = alloca i32
  %l119 = alloca i1
  %l125 = alloca i64
  %l131 = alloca { i64, i64 }
  %l136 = alloca ptr
  %l137 = alloca %"compiler/eval:Ptr"
  %l140 = alloca i64
  %l141 = alloca ptr
  %l142 = alloca i64
  %l143 = alloca i64
  %l147 = alloca i1
  %l149 = alloca ptr
  %l153 = alloca i32
  %l154 = alloca i1
  %l157 = alloca i64
  %l161 = alloca ptr
  %l165 = alloca i64
  %l167 = alloca double
  %l171 = alloca i1
  %l176 = alloca { i64, i64 }
  %l187 = alloca { i64, i64 }
  %l200 = alloca i1
  %l202 = alloca ptr
  %l206 = alloca i32
  %l207 = alloca i1
  %l211 = alloca i64
  %l215 = alloca { i64, i64 }
  %l224 = alloca { i64, i64 }
  %l250 = alloca { i64, i64 }
  %l255 = alloca i64
  %l259 = alloca i64
  %l265 = alloca i64
  %l276 = alloca i64
  %l279 = alloca i64
  %l301 = alloca { i64, i64 }
  %l310 = alloca { i64, i64 }
  %l333 = alloca ptr
  %l334 = alloca ptr
  %l335 = alloca i64
  %l339 = alloca { i64, [4 x i64] }
  %l340 = alloca i64
  %l341 = alloca ptr
  %l342 = alloca i64
  %l346 = alloca { i64, [4 x i64] }
  %l347 = alloca i32
  %l348 = alloca i64
  %l367 = alloca { i64, i64 }
  %l380 = alloca { i64, i64 }
  %l388 = alloca { i64, i64 }
  %l403 = alloca { i64, [4 x i64] }
  %l407 = alloca { i64, i64 }
  %l418 = alloca { i64, i64 }
  %l427 = alloca { i64, i64 }
  %l436 = alloca { i64, i64 }
  %l445 = alloca i1
  %l452 = alloca { i64, i64 }
  %l457 = alloca i1
  %l460 = alloca i1
  %l464 = alloca i1
  %l474 = alloca { i64, i64, i64, i64 }
  %l493 = alloca { i64, i64, i64, i64 }
  %l514 = alloca i1
  %l517 = alloca i1
  %l526 = alloca { i64, i64 }
  %l533 = alloca { i64, i64 }
  %l583 = alloca i64
  %l584 = alloca i1
  %l607 = alloca ptr
  %l608 = alloca %"compiler/eval:Ptr"
  %l610 = alloca i64
  %l612 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/eval:Ptr" %a2, ptr %l2
  store i32 %a3, ptr %l3
  store i32 %a4, ptr %l4
  store %"compiler/mir:Range" %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t3 = load %"compiler/mir:Range", ptr %l5
  %t7 = call { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %t1, i64 %t2, %"compiler/mir:Range" %t3, i64 0)
  store { i64, [4 x i64] } %t7, ptr %l102
  br label %bb1
bb1:
  %t8 = load { i64, [4 x i64] }, ptr %l102
  store { i64, [4 x i64] } %t8, ptr %l6
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i64, ptr %l1, !tbaa !24
  %t11 = load { i64, [4 x i64] }, ptr %l6
  %t15 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eopType(ptr %v0, ptr %t9, i64 %t10, { i64, [4 x i64] } %t11)
  store i32 %t15, ptr %l106
  br label %bb2
bb2:
  %t16 = load i32, ptr %l106, !tbaa !23
  store i32 %t16, ptr %l7, !tbaa !23
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load i32, ptr %l7, !tbaa !23
  %t21 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t17, i32 %t18)
  store i64 %t21, ptr %l109
  br label %bb3
bb3:
  %t22 = load i64, ptr %l109, !tbaa !24
  store i64 %t22, ptr %l8, !tbaa !24
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i32, ptr %l4, !tbaa !23
  %t27 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eibits(ptr %v0, ptr %t23, i32 %t24)
  store i64 %t27, ptr %l112
  br label %bb4
bb4:
  %t28 = load i64, ptr %l112, !tbaa !24
  store i64 %t28, ptr %l9, !tbaa !24
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/eval:Machine", ptr %t29, i32 0, i32 0
  %t32 = load ptr, ptr %t31, !tbaa !29
  store ptr %t32, ptr %l114, !tbaa !29
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/eval:Machine", ptr %t33, i32 0, i32 0
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t37 = load i32, ptr %l4, !tbaa !23
  %t40 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t36, i32 %t37)
  store i32 %t40, ptr %l118
  br label %bb5
bb5:
  %t41 = load ptr, ptr %l114, !tbaa !29
  %t42 = load i32, ptr %l118, !tbaa !23
  %t43 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t41, i32 %t42)
  store i1 %t43, ptr %l119
  br label %bb6
bb6:
  %t44 = load i1, ptr %l119, !tbaa !21
  %t45 = xor i1 %t44, true
  store i1 %t45, ptr %l10, !tbaa !21
  %t47 = load i32, ptr %l3, !range !{i32 0, i32 54}
  %t49 = trunc i64 20 to i32
  %t50 = icmp eq i32 %t47, %t49
  br i1 %t50, label %bb7, label %bb8
bb7:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load i32, ptr %l4, !tbaa !23
  %t56 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t52, i32 %t53)
  store i64 %t56, ptr %l125
  br label %bb9
bb8:
  br label %bb42
bb9:
  %t57 = load i64, ptr @G_2ecompiler_2feval_2evFloat, !tbaa !24
  %t58 = load i64, ptr %l125, !tbaa !24
  %t60 = icmp eq i64 %t58, %t57
  br i1 %t60, label %bb10, label %bb11
bb10:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load i64, ptr %l1, !tbaa !24
  %t64 = load { i64, [4 x i64] }, ptr %l6
  %t68 = call { i64, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2ewideOf(ptr %v0, ptr %t62, i64 %t63, { i64, [4 x i64] } %t64)
  store { i64, i64 } %t68, ptr %l131
  br label %bb12
bb11:
  br label %bb24
bb12:
  %t69 = load { i64, i64 }, ptr %l131
  store { i64, i64 } %t69, ptr %l11
  %t70 = getelementptr { i64, i64 }, ptr %l11, i32 0, i32 0
  %t71 = load i64, ptr %t70, !tbaa !24
  store i64 %t71, ptr %l12, !tbaa !24
  %t73 = getelementptr { i64, i64 }, ptr %l11, i32 0, i32 1
  %t74 = load i64, ptr %t73, !tbaa !24
  store i64 %t74, ptr %l13, !tbaa !24
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/eval:Machine", ptr %t76, i32 0, i32 23
  %t79 = load i1, ptr %t78, !tbaa !21
  br i1 %t79, label %bb13, label %bb14
bb13:
  br label %ret
bb14:
  br label %bb15
bb15:
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l136, !tbaa !29
  %t82 = load %"compiler/eval:Ptr", ptr %l2
  store %"compiler/eval:Ptr" %t82, ptr %l137
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load i32, ptr %l4, !tbaa !23
  %t87 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewidth(ptr %v0, ptr %t83, i32 %t84)
  store i64 %t87, ptr %l140
  br label %bb16
bb16:
  %t88 = load ptr, ptr %l0, !tbaa !29
  store ptr %t88, ptr %l141, !tbaa !29
  %t89 = load i64, ptr %l12, !tbaa !24
  store i64 %t89, ptr %l142, !tbaa !24
  %t90 = load i64, ptr %l13, !tbaa !24
  store i64 %t90, ptr %l143, !tbaa !24
  %t91 = load i64, ptr %l8, !tbaa !24
  %t92 = load i64, ptr @G_2ecompiler_2feval_2evUint, !tbaa !24
  %t95 = icmp ne i64 %t91, %t92
  br i1 %t95, label %bb17, label %bb18
bb17:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/eval:Machine", ptr %t97, i32 0, i32 0
  %t100 = load ptr, ptr %t99, !tbaa !29
  store ptr %t100, ptr %l149, !tbaa !29
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/eval:Machine", ptr %t101, i32 0, i32 0
  %t104 = load ptr, ptr %t103, !tbaa !29
  %t105 = load i32, ptr %l7, !tbaa !23
  %t108 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t104, i32 %t105)
  store i32 %t108, ptr %l153
  br label %bb19
bb18:
  store i1 false, ptr %l147, !tbaa !21
  br label %bb21
bb19:
  %t109 = load ptr, ptr %l149, !tbaa !29
  %t110 = load i32, ptr %l153, !tbaa !23
  %t111 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t109, i32 %t110)
  store i1 %t111, ptr %l154
  br label %bb20
bb20:
  %t112 = load i1, ptr %l154, !tbaa !21
  %t113 = xor i1 %t112, true
  store i1 %t113, ptr %l147, !tbaa !21
  br label %bb21
bb21:
  %t115 = load i32, ptr %l4, !tbaa !23
  %t116 = load ptr, ptr %l141, !tbaa !29
  %t117 = load i64, ptr %l142, !tbaa !24
  %t118 = load i64, ptr %l143, !tbaa !24
  %t119 = load i1, ptr %l147, !tbaa !21
  %t121 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewideToFloat(ptr %v0, ptr %t116, i64 %t117, i64 %t118, i1 %t119, i32 %t115)
  store i64 %t121, ptr %l157
  br label %bb22
bb22:
  %t122 = load ptr, ptr %l136, !tbaa !29
  %t123 = load %"compiler/eval:Ptr", ptr %l137
  %t124 = load i64, ptr %l140, !tbaa !24
  %t125 = load i64, ptr %l157, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t122, %"compiler/eval:Ptr" %t123, i64 %t124, i64 %t125)
  br label %bb23
bb23:
  br label %ret
bb24:
  %t126 = load i64, ptr %l8, !tbaa !24
  %t127 = load i64, ptr @G_2ecompiler_2feval_2evFloat, !tbaa !24
  %t130 = icmp eq i64 %t126, %t127
  br i1 %t130, label %bb25, label %bb26
bb25:
  %t132 = load ptr, ptr %l0, !tbaa !29
  store ptr %t132, ptr %l161, !tbaa !29
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load i64, ptr %l1, !tbaa !24
  %t135 = load { i64, [4 x i64] }, ptr %l6
  %t139 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %t133, i64 %t134, { i64, [4 x i64] } %t135)
  store i64 %t139, ptr %l165
  br label %bb27
bb26:
  br label %bb36
bb27:
  %t140 = load i32, ptr %l7, !tbaa !23
  %t141 = load ptr, ptr %l161, !tbaa !29
  %t142 = load i64, ptr %l165, !tbaa !24
  %t144 = call double @compiler_2feval_2ecompiler_2feval_3aMachine_2etoF64(ptr %v0, ptr %t141, i64 %t142, i32 %t140)
  store double %t144, ptr %l167
  br label %bb28
bb28:
  %t145 = load double, ptr %l167, !tbaa !26
  store double %t145, ptr %l14, !tbaa !26
  %t146 = load double, ptr %l14, !tbaa !26
  %t147 = load i64, ptr %l9, !tbaa !24
  %t148 = load i1, ptr %l10, !tbaa !21
  %t152 = call i1 @compiler_2feval_2efloatFits(double %t146, i64 %t147, i1 %t148)
  store i1 %t152, ptr %l171
  br label %bb29
bb29:
  %t153 = load i1, ptr %l171, !tbaa !21
  %t154 = xor i1 %t153, true
  br i1 %t154, label %bb30, label %bb31
bb30:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyConvert, !tbaa !27
  %t158 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t158, ptr %t156, { i64, ptr } %t157)
  br label %bb32
bb31:
  br label %bb33
bb32:
  br label %ret
bb33:
  %t161 = load double, ptr %l14, !tbaa !26
  %t163 = call { i64, i64 } @compiler_2feval_2efloatToWide(double %t161)
  store { i64, i64 } %t163, ptr %l176
  br label %bb34
bb34:
  %t164 = load { i64, i64 }, ptr %l176
  store { i64, i64 } %t164, ptr %l15
  %t165 = getelementptr { i64, i64 }, ptr %l15, i32 0, i32 0
  %t166 = load i64, ptr %t165, !tbaa !24
  %t168 = getelementptr { i64, i64 }, ptr %l15, i32 0, i32 1
  %t169 = load i64, ptr %t168, !tbaa !24
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load %"compiler/eval:Ptr", ptr %l2
  %t173 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eputInt(ptr %v0, ptr %t171, %"compiler/eval:Ptr" %t172, i32 %t173, i64 %t166, i64 %t169)
  br label %bb35
bb35:
  br label %ret
bb36:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t182 = load i64, ptr %l1, !tbaa !24
  %t183 = load { i64, [4 x i64] }, ptr %l6
  %t187 = call { i64, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2ewideOf(ptr %v0, ptr %t181, i64 %t182, { i64, [4 x i64] } %t183)
  store { i64, i64 } %t187, ptr %l187
  br label %bb37
bb37:
  %t188 = load { i64, i64 }, ptr %l187
  store { i64, i64 } %t188, ptr %l18
  %t189 = getelementptr { i64, i64 }, ptr %l18, i32 0, i32 0
  %t190 = load i64, ptr %t189, !tbaa !24
  store i64 %t190, ptr %l19, !tbaa !24
  %t192 = getelementptr { i64, i64 }, ptr %l18, i32 0, i32 1
  %t193 = load i64, ptr %t192, !tbaa !24
  store i64 %t193, ptr %l20, !tbaa !24
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/eval:Machine", ptr %t195, i32 0, i32 23
  %t198 = load i1, ptr %t197, !tbaa !21
  br i1 %t198, label %bb38, label %bb39
bb38:
  br label %ret
bb39:
  br label %bb40
bb40:
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t201 = load %"compiler/eval:Ptr", ptr %l2
  %t202 = load i32, ptr %l4, !tbaa !23
  %t203 = load i64, ptr %l19, !tbaa !24
  %t204 = load i64, ptr %l20, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eputInt(ptr %v0, ptr %t200, %"compiler/eval:Ptr" %t201, i32 %t202, i64 %t203, i64 %t204)
  br label %bb41
bb41:
  br label %ret
bb42:
  %t210 = load i64, ptr %l8, !tbaa !24
  %t211 = load i64, ptr @G_2ecompiler_2feval_2evUint, !tbaa !24
  %t214 = icmp ne i64 %t210, %t211
  br i1 %t214, label %bb43, label %bb44
bb43:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t218 = getelementptr %"compiler/eval:Machine", ptr %t216, i32 0, i32 0
  %t219 = load ptr, ptr %t218, !tbaa !29
  store ptr %t219, ptr %l202, !tbaa !29
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t222 = getelementptr %"compiler/eval:Machine", ptr %t220, i32 0, i32 0
  %t223 = load ptr, ptr %t222, !tbaa !29
  %t224 = load i32, ptr %l7, !tbaa !23
  %t227 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t223, i32 %t224)
  store i32 %t227, ptr %l206
  br label %bb45
bb44:
  store i1 false, ptr %l200, !tbaa !21
  br label %bb47
bb45:
  %t228 = load ptr, ptr %l202, !tbaa !29
  %t229 = load i32, ptr %l206, !tbaa !23
  %t230 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t228, i32 %t229)
  store i1 %t230, ptr %l207
  br label %bb46
bb46:
  %t231 = load i1, ptr %l207, !tbaa !21
  %t232 = xor i1 %t231, true
  store i1 %t232, ptr %l200, !tbaa !21
  br label %bb47
bb47:
  %t234 = load i1, ptr %l200, !tbaa !21
  store i1 %t234, ptr %l21, !tbaa !21
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t236 = load i32, ptr %l7, !tbaa !23
  %t239 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eibits(ptr %v0, ptr %t235, i32 %t236)
  store i64 %t239, ptr %l211
  br label %bb48
bb48:
  %t240 = load i64, ptr %l211, !tbaa !24
  store i64 %t240, ptr %l22, !tbaa !24
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t242 = load i64, ptr %l1, !tbaa !24
  %t243 = load { i64, [4 x i64] }, ptr %l6
  %t247 = call { i64, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2ewideOf(ptr %v0, ptr %t241, i64 %t242, { i64, [4 x i64] } %t243)
  store { i64, i64 } %t247, ptr %l215
  br label %bb49
bb49:
  %t248 = load { i64, i64 }, ptr %l215
  store { i64, i64 } %t248, ptr %l23
  %t249 = getelementptr { i64, i64 }, ptr %l23, i32 0, i32 0
  %t250 = load i64, ptr %t249, !tbaa !24
  store i64 %t250, ptr %l24, !tbaa !24
  %t252 = getelementptr { i64, i64 }, ptr %l23, i32 0, i32 1
  %t253 = load i64, ptr %t252, !tbaa !24
  store i64 %t253, ptr %l25, !tbaa !24
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t257 = getelementptr %"compiler/eval:Machine", ptr %t255, i32 0, i32 23
  %t258 = load i1, ptr %t257, !tbaa !21
  br i1 %t258, label %bb50, label %bb51
bb50:
  br label %ret
bb51:
  br label %bb52
bb52:
  %t260 = load i32, ptr %l3, !range !{i32 0, i32 54}
  %t262 = trunc i64 0 to i32
  %t263 = icmp eq i32 %t260, %t262
  br i1 %t263, label %bb53, label %bb54
bb53:
  br label %bb55
bb54:
  br label %bb58
bb55:
  %t265 = load i64, ptr %l24, !tbaa !24
  %t266 = load i64, ptr %l25, !tbaa !24
  %t269 = call { i64, i64 } @compiler_2feval_2eneg128(i64 %t265, i64 %t266)
  store { i64, i64 } %t269, ptr %l224
  br label %bb56
bb56:
  %t270 = load { i64, i64 }, ptr %l224
  store { i64, i64 } %t270, ptr %l26
  %t271 = getelementptr { i64, i64 }, ptr %l26, i32 0, i32 0
  %t272 = load i64, ptr %t271, !tbaa !24
  %t274 = getelementptr { i64, i64 }, ptr %l26, i32 0, i32 1
  %t275 = load i64, ptr %t274, !tbaa !24
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t278 = load %"compiler/eval:Ptr", ptr %l2
  %t279 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eputInt(ptr %v0, ptr %t277, %"compiler/eval:Ptr" %t278, i32 %t279, i64 %t272, i64 %t275)
  br label %bb57
bb57:
  br label %ret
bb58:
  %t287 = load i32, ptr %l3, !range !{i32 0, i32 54}
  %t289 = trunc i64 1 to i32
  %t290 = icmp eq i32 %t287, %t289
  br i1 %t290, label %bb59, label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb63
bb61:
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t293 = load %"compiler/eval:Ptr", ptr %l2
  %t294 = load i32, ptr %l4, !tbaa !23
  %t295 = load i64, ptr %l24, !tbaa !24
  %t297 = xor i64 %t295, -1
  %t298 = load i64, ptr %l25, !tbaa !24
  %t300 = xor i64 %t298, -1
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eputInt(ptr %v0, ptr %t292, %"compiler/eval:Ptr" %t293, i32 %t294, i64 %t297, i64 %t300)
  br label %bb62
bb62:
  br label %ret
bb63:
  %t306 = load i32, ptr %l3, !range !{i32 0, i32 54}
  %t308 = trunc i64 32 to i32
  %t309 = icmp eq i32 %t306, %t308
  br i1 %t309, label %bb64, label %bb65
bb64:
  br label %bb70
bb65:
  %t311 = load i32, ptr %l3, !range !{i32 0, i32 54}
  %t313 = trunc i64 33 to i32
  %t314 = icmp eq i32 %t311, %t313
  br i1 %t314, label %bb66, label %bb67
bb66:
  br label %bb70
bb67:
  %t316 = load i32, ptr %l3, !range !{i32 0, i32 54}
  %t318 = trunc i64 34 to i32
  %t319 = icmp eq i32 %t316, %t318
  br i1 %t319, label %bb68, label %bb69
bb68:
  br label %bb70
bb69:
  br label %bb78
bb70:
  %t321 = load i64, ptr %l24, !tbaa !24
  %t322 = load i64, ptr %l25, !tbaa !24
  %t323 = load i64, ptr %l22, !tbaa !24
  %t327 = call { i64, i64 } @compiler_2feval_2eextend128(i64 %t321, i64 %t322, i64 %t323, i1 false)
  store { i64, i64 } %t327, ptr %l250
  br label %bb71
bb71:
  %t328 = load { i64, i64 }, ptr %l250
  store { i64, i64 } %t328, ptr %l29
  %t329 = getelementptr { i64, i64 }, ptr %l29, i32 0, i32 0
  %t330 = load i64, ptr %t329, !tbaa !24
  store i64 %t330, ptr %l30, !tbaa !24
  %t332 = getelementptr { i64, i64 }, ptr %l29, i32 0, i32 1
  %t333 = load i64, ptr %t332, !tbaa !24
  store i64 %t333, ptr %l31, !tbaa !24
  %t335 = load i32, ptr %l3, !range !{i32 0, i32 54}
  %t337 = trunc i64 32 to i32
  %t338 = icmp eq i32 %t335, %t337
  br i1 %t338, label %bb72, label %bb73
bb72:
  %t340 = load i64, ptr %l30, !tbaa !24
  %t341 = load i64, ptr %l31, !tbaa !24
  %t342 = load i64, ptr %l22, !tbaa !24
  %t346 = call i64 @compiler_2feval_2elz128(i64 %t340, i64 %t341, i64 %t342)
  store i64 %t346, ptr %l259
  br label %bb74
bb73:
  %t347 = load i32, ptr %l3, !range !{i32 0, i32 54}
  %t349 = trunc i64 34 to i32
  %t350 = icmp eq i32 %t347, %t349
  %t351 = load i64, ptr %l30, !tbaa !24
  %t352 = load i64, ptr %l31, !tbaa !24
  %t353 = load i64, ptr %l22, !tbaa !24
  %t358 = call i64 @compiler_2feval_2ecountBits128(i1 %t350, i64 %t351, i64 %t352, i64 %t353)
  store i64 %t358, ptr %l265
  br label %bb75
bb74:
  %t359 = load i64, ptr %l259, !tbaa !24
  store i64 %t359, ptr %l255, !tbaa !24
  br label %bb76
bb75:
  %t360 = load i64, ptr %l265, !tbaa !24
  store i64 %t360, ptr %l255, !tbaa !24
  br label %bb76
bb76:
  %t361 = load i64, ptr %l255, !tbaa !24
  %t362 = load ptr, ptr %l0, !tbaa !29
  %t363 = load %"compiler/eval:Ptr", ptr %l2
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t362, %"compiler/eval:Ptr" %t363, i64 8, i64 %t361)
  br label %bb77
bb77:
  br label %ret
bb78:
  %t368 = load i32, ptr %l3, !range !{i32 0, i32 54}
  %t370 = trunc i64 37 to i32
  %t371 = icmp eq i32 %t368, %t370
  br i1 %t371, label %bb79, label %bb80
bb79:
  br label %bb81
bb80:
  br label %bb97
bb81:
  store i64 0, ptr %l33, !tbaa !24
  store i64 0, ptr %l34, !tbaa !24
  store i64 0, ptr %l35, !tbaa !24
  %t373 = load i64, ptr %l22, !tbaa !24
  %t375 = sdiv i64 %t373, 8
  store i64 %t375, ptr %l36, !tbaa !24
  store i64 1, ptr %l37, !tbaa !24
  %t377 = load i64, ptr %l36, !tbaa !24
  %t378 = load i64, ptr %l35, !tbaa !24
  %t381 = icmp sgt i64 %t377, %t378
  br i1 %t381, label %bb82, label %bb83
bb82:
  %t383 = load i64, ptr %l37, !tbaa !24
  %t385 = icmp sgt i64 %t383, 0
  br i1 %t385, label %bb84, label %bb85
bb83:
  store i64 0, ptr %l276, !tbaa !24
  br label %bb87
bb84:
  %t387 = load i64, ptr %l36, !tbaa !24
  %t388 = load i64, ptr %l35, !tbaa !24
  %t391 = sub i64 %t387, %t388
  %t392 = load i64, ptr %l37, !tbaa !24
  %t395 = add i64 %t391, %t392
  %t397 = sub i64 %t395, 1
  %t398 = load i64, ptr %l37, !tbaa !24
  %t401 = sdiv i64 %t397, %t398
  store i64 %t401, ptr %l279, !tbaa !24
  br label %bb86
bb85:
  store i64 0, ptr %l279, !tbaa !24
  br label %bb86
bb86:
  %t403 = load i64, ptr %l279, !tbaa !24
  store i64 %t403, ptr %l276, !tbaa !24
  br label %bb87
bb87:
  %t404 = load i64, ptr %l276, !tbaa !24
  store i64 %t404, ptr %l38, !tbaa !24
  store i64 0, ptr %l39, !tbaa !24
  br label %bb88
bb88:
  %t405 = load i64, ptr %l39, !tbaa !24
  %t406 = load i64, ptr %l38, !tbaa !24
  %t409 = icmp slt i64 %t405, %t406
  %t411 = xor i1 %t409, true
  br i1 %t411, label %bb89, label %bb90
bb89:
  br label %bb95
bb90:
  br label %bb91
bb91:
  %t413 = load i64, ptr %l35, !tbaa !24
  %t414 = load i64, ptr %l39, !tbaa !24
  %t415 = load i64, ptr %l37, !tbaa !24
  %t418 = mul i64 %t414, %t415
  %t421 = add i64 %t413, %t418
  store i64 %t421, ptr %l40, !tbaa !24
  %t423 = load i64, ptr %l24, !tbaa !24
  %t424 = load i64, ptr %l25, !tbaa !24
  %t425 = load i64, ptr %l40, !tbaa !24
  %t427 = mul i64 8, %t425
  %t431 = call { i64, i64 } @compiler_2feval_2eshr128(i64 %t423, i64 %t424, i64 %t427, i1 false)
  store { i64, i64 } %t431, ptr %l301
  br label %bb92
bb92:
  %t432 = load { i64, i64 }, ptr %l301
  store { i64, i64 } %t432, ptr %l41
  %t433 = getelementptr { i64, i64 }, ptr %l41, i32 0, i32 0
  %t434 = load i64, ptr %t433, !tbaa !24
  %t438 = and i64 %t434, 255
  %t439 = load i64, ptr %l22, !tbaa !24
  %t441 = sub i64 %t439, 8
  %t442 = load i64, ptr %l40, !tbaa !24
  %t444 = mul i64 8, %t442
  %t447 = sub i64 %t441, %t444
  %t450 = call { i64, i64 } @compiler_2feval_2eshl128(i64 %t438, i64 0, i64 %t447)
  store { i64, i64 } %t450, ptr %l310
  br label %bb93
bb93:
  %t451 = load { i64, i64 }, ptr %l310
  store { i64, i64 } %t451, ptr %l43
  %t452 = getelementptr { i64, i64 }, ptr %l43, i32 0, i32 0
  %t453 = load i64, ptr %t452, !tbaa !24
  %t455 = getelementptr { i64, i64 }, ptr %l43, i32 0, i32 1
  %t456 = load i64, ptr %t455, !tbaa !24
  %t458 = load i64, ptr %l33, !tbaa !24
  %t462 = or i64 %t458, %t453
  %t464 = load i64, ptr %l34, !tbaa !24
  %t468 = or i64 %t464, %t456
  store i64 %t462, ptr %l33, !tbaa !24
  store i64 %t468, ptr %l34, !tbaa !24
  br label %bb94
bb94:
  %t474 = load i64, ptr %l39, !tbaa !24
  %t477 = add i64 %t474, 1
  store i64 %t477, ptr %l39, !tbaa !24
  br label %bb88
bb95:
  %t479 = load ptr, ptr %l0, !tbaa !29
  %t480 = load %"compiler/eval:Ptr", ptr %l2
  %t481 = load i32, ptr %l4, !tbaa !23
  %t482 = load i64, ptr %l33, !tbaa !24
  %t483 = load i64, ptr %l34, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eputInt(ptr %v0, ptr %t479, %"compiler/eval:Ptr" %t480, i32 %t481, i64 %t482, i64 %t483)
  br label %bb96
bb96:
  br label %ret
bb97:
  %t489 = load i32, ptr %l3, !range !{i32 0, i32 54}
  %t491 = trunc i64 35 to i32
  %t492 = icmp eq i32 %t489, %t491
  br i1 %t492, label %bb98, label %bb99
bb98:
  br label %bb102
bb99:
  %t494 = load i32, ptr %l3, !range !{i32 0, i32 54}
  %t496 = trunc i64 36 to i32
  %t497 = icmp eq i32 %t494, %t496
  br i1 %t497, label %bb100, label %bb101
bb100:
  br label %bb102
bb101:
  br label %bb119
bb102:
  %t499 = load ptr, ptr %l0, !tbaa !29
  store ptr %t499, ptr %l333, !tbaa !29
  %t500 = load ptr, ptr %l0, !tbaa !29
  store ptr %t500, ptr %l334, !tbaa !29
  %t501 = load i64, ptr %l1, !tbaa !24
  store i64 %t501, ptr %l335, !tbaa !24
  %t502 = load ptr, ptr %l0, !tbaa !29
  %t503 = load i64, ptr %l1, !tbaa !24
  %t504 = load %"compiler/mir:Range", ptr %l5
  %t508 = call { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %t502, i64 %t503, %"compiler/mir:Range" %t504, i64 1)
  store { i64, [4 x i64] } %t508, ptr %l339
  br label %bb103
bb103:
  %t509 = load ptr, ptr %l334, !tbaa !29
  %t510 = load i64, ptr %l335, !tbaa !24
  %t511 = load { i64, [4 x i64] }, ptr %l339
  %t512 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %t509, i64 %t510, { i64, [4 x i64] } %t511)
  store i64 %t512, ptr %l340
  br label %bb104
bb104:
  %t513 = load ptr, ptr %l0, !tbaa !29
  store ptr %t513, ptr %l341, !tbaa !29
  %t514 = load i64, ptr %l1, !tbaa !24
  store i64 %t514, ptr %l342, !tbaa !24
  %t515 = load ptr, ptr %l0, !tbaa !29
  %t516 = load i64, ptr %l1, !tbaa !24
  %t517 = load %"compiler/mir:Range", ptr %l5
  %t521 = call { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %t515, i64 %t516, %"compiler/mir:Range" %t517, i64 1)
  store { i64, [4 x i64] } %t521, ptr %l346
  br label %bb105
bb105:
  %t522 = load ptr, ptr %l341, !tbaa !29
  %t523 = load i64, ptr %l342, !tbaa !24
  %t524 = load { i64, [4 x i64] }, ptr %l346
  %t525 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eopType(ptr %v0, ptr %t522, i64 %t523, { i64, [4 x i64] } %t524)
  store i32 %t525, ptr %l347
  br label %bb106
bb106:
  %t526 = load ptr, ptr %l333, !tbaa !29
  %t527 = load i64, ptr %l340, !tbaa !24
  %t528 = load i32, ptr %l347, !tbaa !23
  %t529 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintValue(ptr %v0, ptr %t526, i64 %t527, i32 %t528)
  store i64 %t529, ptr %l348
  br label %bb107
bb107:
  %t530 = load i64, ptr %l348, !tbaa !24
  %t532 = load i64, ptr %l22, !tbaa !24
  %t535 = srem i64 %t530, %t532
  %t536 = load i64, ptr %l22, !tbaa !24
  %t539 = add i64 %t535, %t536
  %t540 = load i64, ptr %l22, !tbaa !24
  %t543 = srem i64 %t539, %t540
  store i64 %t543, ptr %l49, !tbaa !24
  %t545 = load i32, ptr %l3, !range !{i32 0, i32 54}
  %t547 = trunc i64 36 to i32
  %t548 = icmp eq i32 %t545, %t547
  br i1 %t548, label %bb108, label %bb109
bb108:
  %t550 = load i64, ptr %l49, !tbaa !24
  %t551 = load i64, ptr %l22, !tbaa !24
  %t555 = sub i64 %t551, %t550
  %t556 = load i64, ptr %l22, !tbaa !24
  %t559 = srem i64 %t555, %t556
  store i64 %t559, ptr %l49, !tbaa !24
  br label %bb110
bb109:
  br label %bb110
bb110:
  %t561 = load i64, ptr %l24, !tbaa !24
  %t562 = load i64, ptr %l25, !tbaa !24
  %t563 = load i64, ptr %l22, !tbaa !24
  %t567 = call { i64, i64 } @compiler_2feval_2eextend128(i64 %t561, i64 %t562, i64 %t563, i1 false)
  store { i64, i64 } %t567, ptr %l367
  br label %bb111
bb111:
  %t568 = load { i64, i64 }, ptr %l367
  store { i64, i64 } %t568, ptr %l50
  %t569 = getelementptr { i64, i64 }, ptr %l50, i32 0, i32 0
  %t570 = load i64, ptr %t569, !tbaa !24
  store i64 %t570, ptr %l51, !tbaa !24
  %t572 = getelementptr { i64, i64 }, ptr %l50, i32 0, i32 1
  %t573 = load i64, ptr %t572, !tbaa !24
  store i64 %t573, ptr %l52, !tbaa !24
  %t575 = load i64, ptr %l49, !tbaa !24
  %t577 = icmp eq i64 %t575, 0
  br i1 %t577, label %bb112, label %bb113
bb112:
  %t579 = load ptr, ptr %l0, !tbaa !29
  %t580 = load %"compiler/eval:Ptr", ptr %l2
  %t581 = load i32, ptr %l4, !tbaa !23
  %t582 = load i64, ptr %l51, !tbaa !24
  %t583 = load i64, ptr %l52, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eputInt(ptr %v0, ptr %t579, %"compiler/eval:Ptr" %t580, i32 %t581, i64 %t582, i64 %t583)
  br label %bb114
bb113:
  br label %bb115
bb114:
  br label %ret
bb115:
  %t589 = load i64, ptr %l51, !tbaa !24
  %t590 = load i64, ptr %l52, !tbaa !24
  %t591 = load i64, ptr %l49, !tbaa !24
  %t595 = call { i64, i64 } @compiler_2feval_2eshl128(i64 %t589, i64 %t590, i64 %t591)
  store { i64, i64 } %t595, ptr %l380
  br label %bb116
bb116:
  %t596 = load { i64, i64 }, ptr %l380
  store { i64, i64 } %t596, ptr %l53
  %t597 = getelementptr { i64, i64 }, ptr %l53, i32 0, i32 0
  %t598 = load i64, ptr %t597, !tbaa !24
  store i64 %t598, ptr %l54, !tbaa !24
  %t600 = getelementptr { i64, i64 }, ptr %l53, i32 0, i32 1
  %t601 = load i64, ptr %t600, !tbaa !24
  store i64 %t601, ptr %l55, !tbaa !24
  %t603 = load i64, ptr %l51, !tbaa !24
  %t604 = load i64, ptr %l52, !tbaa !24
  %t605 = load i64, ptr %l22, !tbaa !24
  %t606 = load i64, ptr %l49, !tbaa !24
  %t609 = sub i64 %t605, %t606
  %t613 = call { i64, i64 } @compiler_2feval_2eshr128(i64 %t603, i64 %t604, i64 %t609, i1 false)
  store { i64, i64 } %t613, ptr %l388
  br label %bb117
bb117:
  %t614 = load { i64, i64 }, ptr %l388
  store { i64, i64 } %t614, ptr %l56
  %t615 = getelementptr { i64, i64 }, ptr %l56, i32 0, i32 0
  %t616 = load i64, ptr %t615, !tbaa !24
  %t618 = getelementptr { i64, i64 }, ptr %l56, i32 0, i32 1
  %t619 = load i64, ptr %t618, !tbaa !24
  %t621 = load ptr, ptr %l0, !tbaa !29
  %t622 = load %"compiler/eval:Ptr", ptr %l2
  %t623 = load i32, ptr %l4, !tbaa !23
  %t624 = load i64, ptr %l54, !tbaa !24
  %t628 = or i64 %t624, %t616
  %t629 = load i64, ptr %l55, !tbaa !24
  %t633 = or i64 %t629, %t619
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eputInt(ptr %v0, ptr %t621, %"compiler/eval:Ptr" %t622, i32 %t623, i64 %t628, i64 %t633)
  br label %bb118
bb118:
  br label %ret
bb119:
  br i1 true, label %bb120, label %bb121
bb120:
  br label %bb122
bb121:
  br label %bb123
bb122:
  br label %bb124
bb123:
  call void @__olang_check_failed(ptr @olang_loc_90562c53bc58bb00_b398839a3bffbdf4)
  unreachable
bb124:
  %t639 = load ptr, ptr %l0, !tbaa !29
  %t640 = load i64, ptr %l1, !tbaa !24
  %t641 = load %"compiler/mir:Range", ptr %l5
  %t645 = call { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %t639, i64 %t640, %"compiler/mir:Range" %t641, i64 1)
  store { i64, [4 x i64] } %t645, ptr %l403
  br label %bb125
bb125:
  %t646 = load { i64, [4 x i64] }, ptr %l403
  %t647 = load ptr, ptr %l0, !tbaa !29
  %t648 = load i64, ptr %l1, !tbaa !24
  %t653 = call { i64, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2ewideOf(ptr %v0, ptr %t647, i64 %t648, { i64, [4 x i64] } %t646)
  store { i64, i64 } %t653, ptr %l407
  br label %bb126
bb126:
  %t654 = load { i64, i64 }, ptr %l407
  store { i64, i64 } %t654, ptr %l60
  %t655 = getelementptr { i64, i64 }, ptr %l60, i32 0, i32 0
  %t656 = load i64, ptr %t655, !tbaa !24
  store i64 %t656, ptr %l61, !tbaa !24
  %t658 = getelementptr { i64, i64 }, ptr %l60, i32 0, i32 1
  %t659 = load i64, ptr %t658, !tbaa !24
  store i64 %t659, ptr %l62, !tbaa !24
  %t661 = load ptr, ptr %l0, !tbaa !29
  %t663 = getelementptr %"compiler/eval:Machine", ptr %t661, i32 0, i32 23
  %t664 = load i1, ptr %t663, !tbaa !21
  br i1 %t664, label %bb127, label %bb128
bb127:
  br label %ret
bb128:
  br label %bb129
bb129:
  store i64 0, ptr %l63, !tbaa !24
  store i64 0, ptr %l64, !tbaa !24
  %t666 = load i32, ptr %l3, !range !{i32 0, i32 54}
  %t668 = trunc i64 3 to i32
  %t669 = icmp eq i32 %t666, %t668
  br i1 %t669, label %bb130, label %bb131
bb130:
  br label %bb132
bb131:
  br label %bb134
bb132:
  %t671 = load i64, ptr %l24, !tbaa !24
  %t672 = load i64, ptr %l25, !tbaa !24
  %t673 = load i64, ptr %l61, !tbaa !24
  %t674 = load i64, ptr %l62, !tbaa !24
  %t679 = call { i64, i64 } @compiler_2feval_2eadd128(i64 %t671, i64 %t672, i64 %t673, i64 %t674)
  store { i64, i64 } %t679, ptr %l418
  br label %bb133
bb133:
  %t680 = load { i64, i64 }, ptr %l418
  store { i64, i64 } %t680, ptr %l65
  %t681 = getelementptr { i64, i64 }, ptr %l65, i32 0, i32 0
  %t682 = load i64, ptr %t681, !tbaa !24
  store i64 %t682, ptr %l63, !tbaa !24
  %t684 = getelementptr { i64, i64 }, ptr %l65, i32 0, i32 1
  %t685 = load i64, ptr %t684, !tbaa !24
  store i64 %t685, ptr %l64, !tbaa !24
  br label %bb263
bb134:
  %t687 = load i32, ptr %l3, !range !{i32 0, i32 54}
  %t689 = trunc i64 4 to i32
  %t690 = icmp eq i32 %t687, %t689
  br i1 %t690, label %bb135, label %bb136
bb135:
  br label %bb137
bb136:
  br label %bb139
bb137:
  %t692 = load i64, ptr %l24, !tbaa !24
  %t693 = load i64, ptr %l25, !tbaa !24
  %t694 = load i64, ptr %l61, !tbaa !24
  %t695 = load i64, ptr %l62, !tbaa !24
  %t700 = call { i64, i64 } @compiler_2feval_2esub128(i64 %t692, i64 %t693, i64 %t694, i64 %t695)
  store { i64, i64 } %t700, ptr %l427
  br label %bb138
bb138:
  %t701 = load { i64, i64 }, ptr %l427
  store { i64, i64 } %t701, ptr %l66
  %t702 = getelementptr { i64, i64 }, ptr %l66, i32 0, i32 0
  %t703 = load i64, ptr %t702, !tbaa !24
  store i64 %t703, ptr %l63, !tbaa !24
  %t705 = getelementptr { i64, i64 }, ptr %l66, i32 0, i32 1
  %t706 = load i64, ptr %t705, !tbaa !24
  store i64 %t706, ptr %l64, !tbaa !24
  br label %bb263
bb139:
  %t708 = load i32, ptr %l3, !range !{i32 0, i32 54}
  %t710 = trunc i64 5 to i32
  %t711 = icmp eq i32 %t708, %t710
  br i1 %t711, label %bb140, label %bb141
bb140:
  br label %bb142
bb141:
  br label %bb144
bb142:
  %t713 = load i64, ptr %l24, !tbaa !24
  %t714 = load i64, ptr %l25, !tbaa !24
  %t715 = load i64, ptr %l61, !tbaa !24
  %t716 = load i64, ptr %l62, !tbaa !24
  %t721 = call { i64, i64 } @compiler_2feval_2emul128(i64 %t713, i64 %t714, i64 %t715, i64 %t716)
  store { i64, i64 } %t721, ptr %l436
  br label %bb143
bb143:
  %t722 = load { i64, i64 }, ptr %l436
  store { i64, i64 } %t722, ptr %l67
  %t723 = getelementptr { i64, i64 }, ptr %l67, i32 0, i32 0
  %t724 = load i64, ptr %t723, !tbaa !24
  store i64 %t724, ptr %l63, !tbaa !24
  %t726 = getelementptr { i64, i64 }, ptr %l67, i32 0, i32 1
  %t727 = load i64, ptr %t726, !tbaa !24
  store i64 %t727, ptr %l64, !tbaa !24
  br label %bb263
bb144:
  %t729 = load i32, ptr %l3, !range !{i32 0, i32 54}
  %t731 = trunc i64 6 to i32
  %t732 = icmp eq i32 %t729, %t731
  br i1 %t732, label %bb145, label %bb146
bb145:
  br label %bb149
bb146:
  %t734 = load i32, ptr %l3, !range !{i32 0, i32 54}
  %t736 = trunc i64 7 to i32
  %t737 = icmp eq i32 %t734, %t736
  br i1 %t737, label %bb147, label %bb148
bb147:
  br label %bb149
bb148:
  br label %bb182
bb149:
  %t739 = load i64, ptr %l61, !tbaa !24
  %t741 = icmp eq i64 %t739, 0
  br i1 %t741, label %bb150, label %bb151
bb150:
  %t743 = load i64, ptr %l62, !tbaa !24
  %t745 = icmp eq i64 %t743, 0
  store i1 %t745, ptr %l445, !tbaa !21
  br label %bb152
bb151:
  store i1 false, ptr %l445, !tbaa !21
  br label %bb152
bb152:
  %t747 = load i1, ptr %l445, !tbaa !21
  br i1 %t747, label %bb153, label %bb154
bb153:
  %t748 = load ptr, ptr %l0, !tbaa !29
  %t749 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyDivZero, !tbaa !27
  %t750 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t750, ptr %t748, { i64, ptr } %t749)
  br label %bb155
bb154:
  br label %bb156
bb155:
  br label %ret
bb156:
  %t753 = load i1, ptr %l21, !tbaa !21
  br i1 %t753, label %bb157, label %bb158
bb157:
  %t755 = load i64, ptr %l22, !tbaa !24
  %t757 = call { i64, i64 } @compiler_2feval_2ewideMin(i64 %t755)
  store { i64, i64 } %t757, ptr %l452
  br label %bb159
bb158:
  %t758 = load i64, ptr %l24, !tbaa !24
  %t759 = load i64, ptr %l25, !tbaa !24
  %t760 = load i64, ptr %l61, !tbaa !24
  %t761 = load i64, ptr %l62, !tbaa !24
  %t766 = call { i64, i64, i64, i64 } @compiler_2feval_2eudivmod128(i64 %t758, i64 %t759, i64 %t760, i64 %t761)
  store { i64, i64, i64, i64 } %t766, ptr %l493
  br label %bb177
bb159:
  %t767 = load { i64, i64 }, ptr %l452
  store { i64, i64 } %t767, ptr %l68
  %t768 = getelementptr { i64, i64 }, ptr %l68, i32 0, i32 0
  %t769 = load i64, ptr %t768, !tbaa !24
  store i64 %t769, ptr %l69, !tbaa !24
  %t771 = getelementptr { i64, i64 }, ptr %l68, i32 0, i32 1
  %t772 = load i64, ptr %t771, !tbaa !24
  store i64 %t772, ptr %l70, !tbaa !24
  %t774 = load i64, ptr %l61, !tbaa !24
  %t776 = icmp eq i64 %t774, -1
  br i1 %t776, label %bb160, label %bb161
bb160:
  %t778 = load i64, ptr %l62, !tbaa !24
  %t780 = icmp eq i64 %t778, -1
  store i1 %t780, ptr %l457, !tbaa !21
  br label %bb162
bb161:
  store i1 false, ptr %l457, !tbaa !21
  br label %bb162
bb162:
  %t782 = load i1, ptr %l457, !tbaa !21
  br i1 %t782, label %bb163, label %bb164
bb163:
  %t783 = load i64, ptr %l24, !tbaa !24
  %t784 = load i64, ptr %l69, !tbaa !24
  %t787 = icmp eq i64 %t783, %t784
  store i1 %t787, ptr %l460, !tbaa !21
  br label %bb165
bb164:
  store i1 false, ptr %l460, !tbaa !21
  br label %bb165
bb165:
  %t789 = load i1, ptr %l460, !tbaa !21
  br i1 %t789, label %bb166, label %bb167
bb166:
  %t790 = load i64, ptr %l25, !tbaa !24
  %t791 = load i64, ptr %l70, !tbaa !24
  %t794 = icmp eq i64 %t790, %t791
  store i1 %t794, ptr %l464, !tbaa !21
  br label %bb168
bb167:
  store i1 false, ptr %l464, !tbaa !21
  br label %bb168
bb168:
  %t796 = load i1, ptr %l464, !tbaa !21
  br i1 %t796, label %bb169, label %bb170
bb169:
  %t797 = load ptr, ptr %l0, !tbaa !29
  %t798 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyDivMin, !tbaa !27
  %t799 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t799, ptr %t797, { i64, ptr } %t798)
  br label %bb171
bb170:
  br label %bb172
bb171:
  br label %ret
bb172:
  %t802 = load i64, ptr %l24, !tbaa !24
  %t803 = load i64, ptr %l25, !tbaa !24
  %t804 = load i64, ptr %l61, !tbaa !24
  %t805 = load i64, ptr %l62, !tbaa !24
  %t810 = call { i64, i64, i64, i64 } @compiler_2feval_2esdivmod128(i64 %t802, i64 %t803, i64 %t804, i64 %t805)
  store { i64, i64, i64, i64 } %t810, ptr %l474
  br label %bb173
bb173:
  %t811 = load { i64, i64, i64, i64 }, ptr %l474
  store { i64, i64, i64, i64 } %t811, ptr %l71
  %t812 = getelementptr { i64, i64, i64, i64 }, ptr %l71, i32 0, i32 0
  %t813 = load i64, ptr %t812, !tbaa !24
  %t815 = getelementptr { i64, i64, i64, i64 }, ptr %l71, i32 0, i32 1
  %t816 = load i64, ptr %t815, !tbaa !24
  %t818 = getelementptr { i64, i64, i64, i64 }, ptr %l71, i32 0, i32 2
  %t819 = load i64, ptr %t818, !tbaa !24
  store i64 %t819, ptr %l74, !tbaa !24
  %t821 = getelementptr { i64, i64, i64, i64 }, ptr %l71, i32 0, i32 3
  %t822 = load i64, ptr %t821, !tbaa !24
  store i64 %t822, ptr %l75, !tbaa !24
  store i64 %t813, ptr %l63, !tbaa !24
  store i64 %t816, ptr %l64, !tbaa !24
  %t832 = load i32, ptr %l3, !range !{i32 0, i32 54}
  %t834 = trunc i64 7 to i32
  %t835 = icmp eq i32 %t832, %t834
  br i1 %t835, label %bb174, label %bb175
bb174:
  %t837 = load i64, ptr %l74, !tbaa !24
  %t839 = load i64, ptr %l75, !tbaa !24
  store i64 %t837, ptr %l63, !tbaa !24
  store i64 %t839, ptr %l64, !tbaa !24
  br label %bb176
bb175:
  br label %bb176
bb176:
  br label %bb181
bb177:
  %t845 = load { i64, i64, i64, i64 }, ptr %l493
  store { i64, i64, i64, i64 } %t845, ptr %l80
  %t846 = getelementptr { i64, i64, i64, i64 }, ptr %l80, i32 0, i32 0
  %t847 = load i64, ptr %t846, !tbaa !24
  %t849 = getelementptr { i64, i64, i64, i64 }, ptr %l80, i32 0, i32 1
  %t850 = load i64, ptr %t849, !tbaa !24
  %t852 = getelementptr { i64, i64, i64, i64 }, ptr %l80, i32 0, i32 2
  %t853 = load i64, ptr %t852, !tbaa !24
  store i64 %t853, ptr %l83, !tbaa !24
  %t855 = getelementptr { i64, i64, i64, i64 }, ptr %l80, i32 0, i32 3
  %t856 = load i64, ptr %t855, !tbaa !24
  store i64 %t856, ptr %l84, !tbaa !24
  store i64 %t847, ptr %l63, !tbaa !24
  store i64 %t850, ptr %l64, !tbaa !24
  %t866 = load i32, ptr %l3, !range !{i32 0, i32 54}
  %t868 = trunc i64 7 to i32
  %t869 = icmp eq i32 %t866, %t868
  br i1 %t869, label %bb178, label %bb179
bb178:
  %t871 = load i64, ptr %l83, !tbaa !24
  %t873 = load i64, ptr %l84, !tbaa !24
  store i64 %t871, ptr %l63, !tbaa !24
  store i64 %t873, ptr %l64, !tbaa !24
  br label %bb180
bb179:
  br label %bb180
bb180:
  br label %bb181
bb181:
  br label %bb263
bb182:
  %t879 = load i32, ptr %l3, !range !{i32 0, i32 54}
  %t881 = trunc i64 8 to i32
  %t882 = icmp eq i32 %t879, %t881
  br i1 %t882, label %bb183, label %bb184
bb183:
  br label %bb187
bb184:
  %t884 = load i32, ptr %l3, !range !{i32 0, i32 54}
  %t886 = trunc i64 9 to i32
  %t887 = icmp eq i32 %t884, %t886
  br i1 %t887, label %bb185, label %bb186
bb185:
  br label %bb187
bb186:
  br label %bb201
bb187:
  %t889 = load i64, ptr %l62, !tbaa !24
  %t891 = icmp ne i64 %t889, 0
  br i1 %t891, label %bb188, label %bb189
bb188:
  store i1 true, ptr %l514, !tbaa !21
  br label %bb191
bb189:
  %t893 = load i64, ptr %l61, !tbaa !24
  %t894 = load i64, ptr %l22, !tbaa !24
  %t897 = call i1 @compiler_2feval_2eult64(i64 %t893, i64 %t894)
  store i1 %t897, ptr %l517
  br label %bb190
bb190:
  %t898 = load i1, ptr %l517, !tbaa !21
  %t899 = xor i1 %t898, true
  store i1 %t899, ptr %l514, !tbaa !21
  br label %bb191
bb191:
  %t901 = load i1, ptr %l514, !tbaa !21
  br i1 %t901, label %bb192, label %bb193
bb192:
  %t902 = load ptr, ptr %l0, !tbaa !29
  %t903 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyShift, !tbaa !27
  %t904 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t904, ptr %t902, { i64, ptr } %t903)
  br label %bb194
bb193:
  br label %bb195
bb194:
  br label %ret
bb195:
  %t907 = load i32, ptr %l3, !range !{i32 0, i32 54}
  %t909 = trunc i64 8 to i32
  %t910 = icmp eq i32 %t907, %t909
  br i1 %t910, label %bb196, label %bb197
bb196:
  %t912 = load i64, ptr %l24, !tbaa !24
  %t913 = load i64, ptr %l25, !tbaa !24
  %t914 = load i64, ptr %l61, !tbaa !24
  %t918 = call { i64, i64 } @compiler_2feval_2eshl128(i64 %t912, i64 %t913, i64 %t914)
  store { i64, i64 } %t918, ptr %l526
  br label %bb198
bb197:
  %t919 = load i64, ptr %l24, !tbaa !24
  %t920 = load i64, ptr %l25, !tbaa !24
  %t921 = load i64, ptr %l61, !tbaa !24
  %t922 = load i1, ptr %l21, !tbaa !21
  %t927 = call { i64, i64 } @compiler_2feval_2eshr128(i64 %t919, i64 %t920, i64 %t921, i1 %t922)
  store { i64, i64 } %t927, ptr %l533
  br label %bb199
bb198:
  %t928 = load { i64, i64 }, ptr %l526
  store { i64, i64 } %t928, ptr %l89
  %t929 = getelementptr { i64, i64 }, ptr %l89, i32 0, i32 0
  %t930 = load i64, ptr %t929, !tbaa !24
  store i64 %t930, ptr %l63, !tbaa !24
  %t932 = getelementptr { i64, i64 }, ptr %l89, i32 0, i32 1
  %t933 = load i64, ptr %t932, !tbaa !24
  store i64 %t933, ptr %l64, !tbaa !24
  br label %bb200
bb199:
  %t935 = load { i64, i64 }, ptr %l533
  store { i64, i64 } %t935, ptr %l90
  %t936 = getelementptr { i64, i64 }, ptr %l90, i32 0, i32 0
  %t937 = load i64, ptr %t936, !tbaa !24
  store i64 %t937, ptr %l63, !tbaa !24
  %t939 = getelementptr { i64, i64 }, ptr %l90, i32 0, i32 1
  %t940 = load i64, ptr %t939, !tbaa !24
  store i64 %t940, ptr %l64, !tbaa !24
  br label %bb200
bb200:
  br label %bb263
bb201:
  %t942 = load i32, ptr %l3, !range !{i32 0, i32 54}
  %t944 = trunc i64 10 to i32
  %t945 = icmp eq i32 %t942, %t944
  br i1 %t945, label %bb202, label %bb203
bb202:
  br label %bb204
bb203:
  br label %bb205
bb204:
  %t947 = load i64, ptr %l24, !tbaa !24
  %t948 = load i64, ptr %l61, !tbaa !24
  %t951 = and i64 %t947, %t948
  %t953 = load i64, ptr %l25, !tbaa !24
  %t954 = load i64, ptr %l62, !tbaa !24
  %t957 = and i64 %t953, %t954
  store i64 %t951, ptr %l63, !tbaa !24
  store i64 %t957, ptr %l64, !tbaa !24
  br label %bb263
bb205:
  %t963 = load i32, ptr %l3, !range !{i32 0, i32 54}
  %t965 = trunc i64 11 to i32
  %t966 = icmp eq i32 %t963, %t965
  br i1 %t966, label %bb206, label %bb207
bb206:
  br label %bb208
bb207:
  br label %bb209
bb208:
  %t968 = load i64, ptr %l24, !tbaa !24
  %t969 = load i64, ptr %l61, !tbaa !24
  %t972 = or i64 %t968, %t969
  %t974 = load i64, ptr %l25, !tbaa !24
  %t975 = load i64, ptr %l62, !tbaa !24
  %t978 = or i64 %t974, %t975
  store i64 %t972, ptr %l63, !tbaa !24
  store i64 %t978, ptr %l64, !tbaa !24
  br label %bb263
bb209:
  %t984 = load i32, ptr %l3, !range !{i32 0, i32 54}
  %t986 = trunc i64 12 to i32
  %t987 = icmp eq i32 %t984, %t986
  br i1 %t987, label %bb210, label %bb211
bb210:
  br label %bb212
bb211:
  br label %bb213
bb212:
  %t989 = load i64, ptr %l24, !tbaa !24
  %t990 = load i64, ptr %l61, !tbaa !24
  %t993 = xor i64 %t989, %t990
  %t995 = load i64, ptr %l25, !tbaa !24
  %t996 = load i64, ptr %l62, !tbaa !24
  %t999 = xor i64 %t995, %t996
  store i64 %t993, ptr %l63, !tbaa !24
  store i64 %t999, ptr %l64, !tbaa !24
  br label %bb263
bb213:
  %t1005 = load i32, ptr %l3, !range !{i32 0, i32 54}
  %t1007 = trunc i64 13 to i32
  %t1008 = icmp eq i32 %t1005, %t1007
  br i1 %t1008, label %bb214, label %bb215
bb214:
  br label %bb226
bb215:
  %t1010 = load i32, ptr %l3, !range !{i32 0, i32 54}
  %t1012 = trunc i64 14 to i32
  %t1013 = icmp eq i32 %t1010, %t1012
  br i1 %t1013, label %bb216, label %bb217
bb216:
  br label %bb226
bb217:
  %t1015 = load i32, ptr %l3, !range !{i32 0, i32 54}
  %t1017 = trunc i64 15 to i32
  %t1018 = icmp eq i32 %t1015, %t1017
  br i1 %t1018, label %bb218, label %bb219
bb218:
  br label %bb226
bb219:
  %t1020 = load i32, ptr %l3, !range !{i32 0, i32 54}
  %t1022 = trunc i64 16 to i32
  %t1023 = icmp eq i32 %t1020, %t1022
  br i1 %t1023, label %bb220, label %bb221
bb220:
  br label %bb226
bb221:
  %t1025 = load i32, ptr %l3, !range !{i32 0, i32 54}
  %t1027 = trunc i64 17 to i32
  %t1028 = icmp eq i32 %t1025, %t1027
  br i1 %t1028, label %bb222, label %bb223
bb222:
  br label %bb226
bb223:
  %t1030 = load i32, ptr %l3, !range !{i32 0, i32 54}
  %t1032 = trunc i64 18 to i32
  %t1033 = icmp eq i32 %t1030, %t1032
  br i1 %t1033, label %bb224, label %bb225
bb224:
  br label %bb226
bb225:
  br label %bb257
bb226:
  %t1035 = load i64, ptr %l24, !tbaa !24
  %t1036 = load i64, ptr %l25, !tbaa !24
  %t1037 = load i64, ptr %l61, !tbaa !24
  %t1038 = load i64, ptr %l62, !tbaa !24
  %t1039 = load i1, ptr %l21, !tbaa !21
  %t1045 = call i64 @compiler_2feval_2ecmp128(i64 %t1035, i64 %t1036, i64 %t1037, i64 %t1038, i1 %t1039)
  store i64 %t1045, ptr %l583
  br label %bb227
bb227:
  %t1046 = load i64, ptr %l583, !tbaa !24
  store i64 %t1046, ptr %l97, !tbaa !24
  %t1047 = load i32, ptr %l3, !range !{i32 0, i32 54}
  %t1049 = trunc i64 13 to i32
  %t1050 = icmp eq i32 %t1047, %t1049
  br i1 %t1050, label %bb228, label %bb229
bb228:
  br label %bb230
bb229:
  br label %bb231
bb230:
  %t1052 = load i64, ptr %l97, !tbaa !24
  %t1054 = icmp eq i64 %t1052, 0
  store i1 %t1054, ptr %l584, !tbaa !21
  br label %bb252
bb231:
  %t1056 = load i32, ptr %l3, !range !{i32 0, i32 54}
  %t1058 = trunc i64 14 to i32
  %t1059 = icmp eq i32 %t1056, %t1058
  br i1 %t1059, label %bb232, label %bb233
bb232:
  br label %bb234
bb233:
  br label %bb235
bb234:
  %t1061 = load i64, ptr %l97, !tbaa !24
  %t1063 = icmp ne i64 %t1061, 0
  store i1 %t1063, ptr %l584, !tbaa !21
  br label %bb252
bb235:
  %t1065 = load i32, ptr %l3, !range !{i32 0, i32 54}
  %t1067 = trunc i64 15 to i32
  %t1068 = icmp eq i32 %t1065, %t1067
  br i1 %t1068, label %bb236, label %bb237
bb236:
  br label %bb238
bb237:
  br label %bb239
bb238:
  %t1070 = load i64, ptr %l97, !tbaa !24
  %t1072 = icmp slt i64 %t1070, 0
  store i1 %t1072, ptr %l584, !tbaa !21
  br label %bb252
bb239:
  %t1074 = load i32, ptr %l3, !range !{i32 0, i32 54}
  %t1076 = trunc i64 16 to i32
  %t1077 = icmp eq i32 %t1074, %t1076
  br i1 %t1077, label %bb240, label %bb241
bb240:
  br label %bb242
bb241:
  br label %bb243
bb242:
  %t1079 = load i64, ptr %l97, !tbaa !24
  %t1081 = icmp sle i64 %t1079, 0
  store i1 %t1081, ptr %l584, !tbaa !21
  br label %bb252
bb243:
  %t1083 = load i32, ptr %l3, !range !{i32 0, i32 54}
  %t1085 = trunc i64 17 to i32
  %t1086 = icmp eq i32 %t1083, %t1085
  br i1 %t1086, label %bb244, label %bb245
bb244:
  br label %bb246
bb245:
  br label %bb247
bb246:
  %t1088 = load i64, ptr %l97, !tbaa !24
  %t1090 = icmp sgt i64 %t1088, 0
  store i1 %t1090, ptr %l584, !tbaa !21
  br label %bb252
bb247:
  br i1 true, label %bb248, label %bb249
bb248:
  br label %bb250
bb249:
  br label %bb251
bb250:
  %t1092 = load i64, ptr %l97, !tbaa !24
  %t1094 = icmp sge i64 %t1092, 0
  store i1 %t1094, ptr %l584, !tbaa !21
  br label %bb252
bb251:
  call void @__olang_check_failed(ptr @olang_loc_124d877554f39b91_abf5664d02ded825)
  unreachable
bb252:
  %t1096 = load i1, ptr %l584, !tbaa !21
  %t1097 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1097, ptr %l607, !tbaa !29
  %t1098 = load %"compiler/eval:Ptr", ptr %l2
  store %"compiler/eval:Ptr" %t1098, ptr %l608
  br i1 %t1096, label %bb253, label %bb254
bb253:
  store i64 1, ptr %l610, !tbaa !24
  br label %bb255
bb254:
  store i64 0, ptr %l610, !tbaa !24
  br label %bb255
bb255:
  %t1101 = load ptr, ptr %l607, !tbaa !29
  %t1102 = load %"compiler/eval:Ptr", ptr %l608
  %t1103 = load i64, ptr %l610, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t1101, %"compiler/eval:Ptr" %t1102, i64 1, i64 %t1103)
  br label %bb256
bb256:
  br label %ret
bb257:
  br i1 true, label %bb258, label %bb259
bb258:
  br label %bb260
bb259:
  br label %bb262
bb260:
  %t1104 = load ptr, ptr %l0, !tbaa !29
  %t1106 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2enotModelled(ptr %v0, ptr %t1104)
  store i64 %t1106, ptr %l612
  br label %bb261
bb261:
  br label %ret
bb262:
  call void @__olang_check_failed(ptr @olang_loc_e0c215207c57b9fa_758d150e3c60fc6e)
  unreachable
bb263:
  %t1107 = load ptr, ptr %l0, !tbaa !29
  %t1108 = load %"compiler/eval:Ptr", ptr %l2
  %t1109 = load i32, ptr %l4, !tbaa !23
  %t1110 = load i64, ptr %l63, !tbaa !24
  %t1111 = load i64, ptr %l64, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eputInt(ptr %v0, ptr %t1107, %"compiler/eval:Ptr" %t1108, i32 %t1109, i64 %t1110, i64 %t1111)
  br label %bb264
bb264:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2erangeMutable(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/mir:Range" %a2) #0 {
entry:
  %l2 = alloca %"compiler/mir:Range"
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l9 = alloca { i64, [4 x i64] }
  %l10 = alloca %"compiler/mir:Lvalue"
  %l15 = alloca i32
  %l18 = alloca i32
  %l43 = alloca { i64, [4 x i64] }
  %l49 = alloca i1
  %rv = alloca i1
  store %"compiler/mir:Range" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i32 0, ptr %l3, !tbaa !23
  %t1 = getelementptr %"compiler/mir:Range", ptr %l2, i32 0, i32 1
  %t2 = load i32, ptr %t1, !tbaa !23
  store i32 %t2, ptr %l4, !tbaa !23
  store i32 1, ptr %l5, !tbaa !23
  %t4 = load i32, ptr %l4, !tbaa !23
  %t5 = load i32, ptr %l3, !tbaa !23
  %t8 = icmp sgt i32 %t4, %t5
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load i32, ptr %l5, !tbaa !23
  %t12 = icmp sgt i32 %t10, 0
  br i1 %t12, label %bb3, label %bb4
bb2:
  store i32 0, ptr %l15, !tbaa !23
  br label %bb6
bb3:
  %t14 = load i32, ptr %l4, !tbaa !23
  %t15 = load i32, ptr %l3, !tbaa !23
  %t18 = sub i32 %t14, %t15
  %t19 = load i32, ptr %l5, !tbaa !23
  %t22 = add i32 %t18, %t19
  %t24 = sub i32 %t22, 1
  %t25 = load i32, ptr %l5, !tbaa !23
  %t28 = sdiv i32 %t24, %t25
  store i32 %t28, ptr %l18, !tbaa !23
  br label %bb5
bb4:
  store i32 0, ptr %l18, !tbaa !23
  br label %bb5
bb5:
  %t30 = load i32, ptr %l18, !tbaa !23
  store i32 %t30, ptr %l15, !tbaa !23
  br label %bb6
bb6:
  %t31 = load i32, ptr %l15, !tbaa !23
  store i32 %t31, ptr %l6, !tbaa !23
  store i32 0, ptr %l7, !tbaa !23
  br label %bb7
bb7:
  %t32 = load i32, ptr %l7, !tbaa !23
  %t33 = load i32, ptr %l6, !tbaa !23
  %t36 = icmp slt i32 %t32, %t33
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb8, label %bb9
bb8:
  br label %bb26
bb9:
  br label %bb10
bb10:
  %t40 = load i32, ptr %l3, !tbaa !23
  %t41 = load i32, ptr %l7, !tbaa !23
  %t42 = load i32, ptr %l5, !tbaa !23
  %t45 = mul i32 %t41, %t42
  %t48 = add i32 %t40, %t45
  %t52 = getelementptr %"compiler/mir:Fn", ptr %a1, i32 0, i32 11
  %t53 = getelementptr %"compiler/mir:Range", ptr %l2, i32 0, i32 0
  %t54 = load i32, ptr %t53, !tbaa !23
  %t56 = sext i32 %t54 to i64
  %t59 = sext i32 %t48 to i64
  %t62 = add i64 %t56, %t59
  %t65 = call { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v1, ptr %t52, i64 %t62)
  store { i64, [4 x i64] } %t65, ptr %l43
  br label %bb11
bb11:
  %t66 = load { i64, [4 x i64] }, ptr %l43
  store { i64, [4 x i64] } %t66, ptr %l9
  %t67 = load { i64, [4 x i64] }, ptr %l9
  %t69 = extractvalue { i64, [4 x i64] } %t67, 0
  %t70 = icmp eq i64 %t69, 1
  br i1 %t70, label %bb12, label %bb13
bb12:
  %t72 = getelementptr { i64, [4 x i64] }, ptr %l9, i32 0, i32 1
  %t73 = getelementptr { %"compiler/mir:Lvalue" }, ptr %t72, i32 0, i32 0
  %t74 = load %"compiler/mir:Lvalue", ptr %t73
  store %"compiler/mir:Lvalue" %t74, ptr %l10
  br label %bb14
bb13:
  br label %bb19
bb14:
  %t77 = load %"compiler/mir:Lvalue", ptr %l10
  %t80 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2emutableGlobal(ptr %v0, ptr %a0, %"compiler/mir:Lvalue" %t77)
  store i1 %t80, ptr %l49
  br label %bb15
bb15:
  %t81 = load i1, ptr %l49, !tbaa !21
  br i1 %t81, label %bb16, label %bb17
bb16:
  store i1 true, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  br label %bb24
bb19:
  br i1 true, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_4b87b113311cbcf6_8401054b0e12d93a)
  unreachable
bb24:
  br label %bb25
bb25:
  %t83 = load i32, ptr %l7, !tbaa !23
  %t86 = add i32 %t83, 1
  store i32 %t86, ptr %l7, !tbaa !23
  br label %bb7
bb26:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2ereachesWritable(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %l22 = alloca i1
  %l23 = alloca i1
  %l27 = alloca i1
  %l28 = alloca i32
  %l34 = alloca i32
  %l37 = alloca i32
  %l42 = alloca i64
  %l46 = alloca i1
  %l47 = alloca ptr
  %l50 = alloca i32
  %l51 = alloca i1
  %l54 = alloca ptr
  %l57 = alloca i32
  %l58 = alloca i1
  %l67 = alloca ptr
  %l70 = alloca i32
  %l71 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %l82 = alloca i1
  %l85 = alloca i1
  %l91 = alloca i32
  %l94 = alloca i1
  %l97 = alloca i32
  %l100 = alloca i1
  %l101 = alloca ptr
  %l104 = alloca i32
  %l105 = alloca i32
  %l110 = alloca i32
  %l113 = alloca i32
  %l116 = alloca i32
  %l119 = alloca i32
  %l122 = alloca { i64, ptr }
  %l129 = alloca { i64, ptr }
  %l135 = alloca i1
  %l138 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load i32, ptr %l1, !tbaa !23
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/eval:Machine", ptr %t8, i32 0, i32 77
  %t14 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_Hb3133f486435530b533aaf49461c92b5(ptr %v0, ptr %t10, i32 %t6)
  store i1 %t14, ptr %l22
  br label %bb1
bb1:
  %t15 = load i1, ptr %l22, !tbaa !21
  br i1 %t15, label %bb2, label %bb3
bb2:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/eval:Machine", ptr %t16, i32 0, i32 77
  %t19 = load i32, ptr %l1, !tbaa !23
  %t22 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_H257d83b06934604763b32ef91c51c1d2(ptr %v0, ptr %t18, i32 %t19)
  %t23 = extractvalue { i32, i1 } %t22, 1
  %t24 = extractvalue { i32, i1 } %t22, 0
  store i32 %t24, ptr %l28
  %t25 = icmp ne i32 %t24, 0
  br i1 %t25, label %bb5, label %ok.26, !prof !99
ok.26:
  store i1 %t23, ptr %l27
  br label %bb4
bb3:
  br label %bb8
bb4:
  %t27 = load i1, ptr %l27, !tbaa !21
  store i1 %t27, ptr %l23, !tbaa !21
  br label %bb7
bb5:
  br label %bb6
bb6:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb7
bb7:
  %t28 = load i1, ptr %l23, !tbaa !21
  store i1 %t28, ptr %rv
  br label %ret
bb8:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/eval:Machine", ptr %t29, i32 0, i32 77
  %t32 = load i32, ptr %l1, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_H64d9be73b6c9bed004c541bdf7f0ca0a(ptr %v0, ptr %t31, i32 %t32, i1 false)
  br label %bb9
bb9:
  store i1 false, ptr %l4, !tbaa !21
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t36 = load i32, ptr %l1, !tbaa !23
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t35, i32 %t36)
  store i32 %t39, ptr %l34
  br label %bb10
bb10:
  %t40 = load i32, ptr %l34, !tbaa !23
  store i32 %t40, ptr %l5, !tbaa !23
  %t41 = load ptr, ptr %l2, !tbaa !29
  %t42 = load i32, ptr %l5, !tbaa !23
  %t45 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t41, i32 %t42)
  store i32 %t45, ptr %l37
  br label %bb11
bb11:
  %t46 = load i32, ptr %l37, !range !{i32 0, i32 33}
  store i32 %t46, ptr %l6
  %t47 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t49 = trunc i64 20 to i32
  %t50 = icmp eq i32 %t47, %t49
  br i1 %t50, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb21
bb14:
  %t52 = load ptr, ptr %l2, !tbaa !29
  %t53 = load i32, ptr %l5, !tbaa !23
  %t56 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t52, i32 %t53)
  store i64 %t56, ptr %l42
  br label %bb15
bb15:
  %t57 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t58 = load i64, ptr %l42, !tbaa !24
  %t60 = and i64 %t58, %t57
  %t62 = icmp ne i64 %t60, 0
  br i1 %t62, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb20
bb17:
  %t64 = load ptr, ptr %l0, !tbaa !29
  store ptr %t64, ptr %l47, !tbaa !29
  %t65 = load ptr, ptr %l2, !tbaa !29
  %t66 = load i32, ptr %l5, !tbaa !23
  %t69 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t65, i32 %t66)
  store i32 %t69, ptr %l50
  br label %bb18
bb18:
  %t70 = load ptr, ptr %l47, !tbaa !29
  %t71 = load i32, ptr %l50, !tbaa !23
  %t72 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2ereachesWritable(ptr %v0, ptr %t70, i32 %t71)
  store i1 %t72, ptr %l51
  br label %bb19
bb19:
  %t73 = load i1, ptr %l51, !tbaa !21
  store i1 %t73, ptr %l46, !tbaa !21
  br label %bb20
bb20:
  %t74 = load i1, ptr %l46, !tbaa !21
  store i1 %t74, ptr %l4, !tbaa !21
  br label %bb87
bb21:
  %t75 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t77 = trunc i64 19 to i32
  %t78 = icmp eq i32 %t75, %t77
  br i1 %t78, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb27
bb24:
  %t80 = load ptr, ptr %l0, !tbaa !29
  store ptr %t80, ptr %l54, !tbaa !29
  %t81 = load ptr, ptr %l2, !tbaa !29
  %t82 = load i32, ptr %l5, !tbaa !23
  %t85 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t81, i32 %t82)
  store i32 %t85, ptr %l57
  br label %bb25
bb25:
  %t86 = load ptr, ptr %l54, !tbaa !29
  %t87 = load i32, ptr %l57, !tbaa !23
  %t88 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2ereachesWritable(ptr %v0, ptr %t86, i32 %t87)
  store i1 %t88, ptr %l58
  br label %bb26
bb26:
  %t89 = load i1, ptr %l58, !tbaa !21
  store i1 %t89, ptr %l4, !tbaa !21
  br label %bb87
bb27:
  %t90 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t92 = trunc i64 22 to i32
  %t93 = icmp eq i32 %t90, %t92
  br i1 %t93, label %bb28, label %bb29
bb28:
  br label %bb36
bb29:
  %t95 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t97 = trunc i64 23 to i32
  %t98 = icmp eq i32 %t95, %t97
  br i1 %t98, label %bb30, label %bb31
bb30:
  br label %bb36
bb31:
  %t100 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t102 = trunc i64 18 to i32
  %t103 = icmp eq i32 %t100, %t102
  br i1 %t103, label %bb32, label %bb33
bb32:
  br label %bb36
bb33:
  %t105 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t107 = trunc i64 24 to i32
  %t108 = icmp eq i32 %t105, %t107
  br i1 %t108, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb82
bb36:
  %t110 = load ptr, ptr %l2, !tbaa !29
  store ptr %t110, ptr %l67, !tbaa !29
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = load i32, ptr %l5, !tbaa !23
  %t115 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2epartList(ptr %v0, ptr %t111, i32 %t112)
  store i32 %t115, ptr %l70
  br label %bb37
bb37:
  %t116 = load ptr, ptr %l67, !tbaa !29
  %t117 = load i32, ptr %l70, !tbaa !23
  %t118 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t116, i32 %t117)
  store { i64, ptr } %t118, ptr %l71
  br label %bb38
bb38:
  %t119 = load { i64, ptr }, ptr %l71, !tbaa !27
  store { i64, ptr } %t119, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t120 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t122 = extractvalue { i64, ptr } %t120, 0
  store i64 %t122, ptr %l9, !tbaa !24
  br label %bb39
bb39:
  %t124 = load i64, ptr %l8, !tbaa !24
  %t125 = load i64, ptr %l9, !tbaa !24
  %t128 = icmp slt i64 %t124, %t125
  %t130 = xor i1 %t128, true
  br i1 %t130, label %bb40, label %bb41
bb40:
  br label %bb48
bb41:
  br label %bb42
bb42:
  %t132 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t132, ptr %l78, !tbaa !27
  %t133 = load i64, ptr %l8, !tbaa !24
  %t135 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !27
  %t137 = getelementptr i32, ptr %t136, i64 %t133
  %t138 = load i32, ptr %t137, !tbaa !33
  store i32 %t138, ptr %l10, !tbaa !23
  %t140 = load i1, ptr %l4, !tbaa !21
  br i1 %t140, label %bb43, label %bb44
bb43:
  store i1 true, ptr %l82, !tbaa !21
  br label %bb46
bb44:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t143 = load i32, ptr %l10, !tbaa !23
  %t146 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2ereachesWritable(ptr %v0, ptr %t142, i32 %t143)
  store i1 %t146, ptr %l85
  br label %bb45
bb45:
  %t147 = load i1, ptr %l85, !tbaa !21
  store i1 %t147, ptr %l82, !tbaa !21
  br label %bb46
bb46:
  %t148 = load i1, ptr %l82, !tbaa !21
  store i1 %t148, ptr %l4, !tbaa !21
  br label %bb47
bb47:
  %t149 = load i64, ptr %l8, !tbaa !24
  %t152 = add i64 %t149, 1
  store i64 %t152, ptr %l8, !tbaa !24
  br label %bb39
bb48:
  %t154 = load ptr, ptr %l2, !tbaa !29
  %t155 = load i32, ptr %l5, !tbaa !23
  %t158 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t154, i32 %t155)
  store i32 %t158, ptr %l91
  br label %bb49
bb49:
  %t159 = load i32, ptr %l91, !range !{i32 0, i32 33}
  %t161 = trunc i64 24 to i32
  %t162 = icmp eq i32 %t159, %t161
  br i1 %t162, label %bb50, label %bb51
bb50:
  store i1 true, ptr %l94, !tbaa !21
  br label %bb58
bb51:
  %t164 = load ptr, ptr %l2, !tbaa !29
  %t165 = load i32, ptr %l5, !tbaa !23
  %t168 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t164, i32 %t165)
  store i32 %t168, ptr %l97
  br label %bb52
bb52:
  %t169 = load i32, ptr %l97, !range !{i32 0, i32 33}
  %t171 = trunc i64 18 to i32
  %t172 = icmp eq i32 %t169, %t171
  br i1 %t172, label %bb53, label %bb54
bb53:
  %t174 = load ptr, ptr %l2, !tbaa !29
  store ptr %t174, ptr %l101, !tbaa !29
  %t175 = load ptr, ptr %l2, !tbaa !29
  %t176 = load i32, ptr %l5, !tbaa !23
  %t179 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t175, i32 %t176)
  store i32 %t179, ptr %l104
  br label %bb55
bb54:
  store i1 false, ptr %l100, !tbaa !21
  br label %bb57
bb55:
  %t180 = load ptr, ptr %l101, !tbaa !29
  %t181 = load i32, ptr %l104, !tbaa !23
  %t182 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t180, i32 %t181)
  store i32 %t182, ptr %l105
  br label %bb56
bb56:
  %t183 = load i32, ptr %l105, !range !{i32 0, i32 6}
  %t185 = trunc i64 1 to i32
  %t186 = icmp eq i32 %t183, %t185
  store i1 %t186, ptr %l100, !tbaa !21
  br label %bb57
bb57:
  %t188 = load i1, ptr %l100, !tbaa !21
  store i1 %t188, ptr %l94, !tbaa !21
  br label %bb58
bb58:
  %t189 = load i1, ptr %l94, !tbaa !21
  br i1 %t189, label %bb59, label %bb60
bb59:
  %t190 = load ptr, ptr %l2, !tbaa !29
  %t191 = load i32, ptr %l5, !tbaa !23
  %t194 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t190, i32 %t191)
  store i32 %t194, ptr %l110
  br label %bb61
bb60:
  br label %bb81
bb61:
  %t195 = load i32, ptr %l110, !range !{i32 0, i32 33}
  %t197 = trunc i64 24 to i32
  %t198 = icmp eq i32 %t195, %t197
  br i1 %t198, label %bb62, label %bb63
bb62:
  %t200 = load ptr, ptr %l2, !tbaa !29
  %t201 = load i32, ptr %l5, !tbaa !23
  %t204 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t200, i32 %t201)
  store i32 %t204, ptr %l116
  br label %bb64
bb63:
  %t205 = load ptr, ptr %l2, !tbaa !29
  %t206 = load i32, ptr %l5, !tbaa !23
  %t209 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t205, i32 %t206)
  store i32 %t209, ptr %l119
  br label %bb65
bb64:
  %t210 = load i32, ptr %l116, !tbaa !23
  store i32 %t210, ptr %l113, !tbaa !23
  br label %bb66
bb65:
  %t211 = load i32, ptr %l119, !tbaa !23
  store i32 %t211, ptr %l113, !tbaa !23
  br label %bb66
bb66:
  %t212 = load i32, ptr %l113, !tbaa !23
  %t213 = load ptr, ptr %l2, !tbaa !29
  %t217 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t213, i32 %t212)
  store { i64, ptr } %t217, ptr %l122
  br label %bb67
bb67:
  %t218 = load { i64, ptr }, ptr %l122, !tbaa !27
  store { i64, ptr } %t218, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t219 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t221 = extractvalue { i64, ptr } %t219, 0
  store i64 %t221, ptr %l14, !tbaa !24
  br label %bb68
bb68:
  %t223 = load i64, ptr %l13, !tbaa !24
  %t224 = load i64, ptr %l14, !tbaa !24
  %t227 = icmp slt i64 %t223, %t224
  %t229 = xor i1 %t227, true
  br i1 %t229, label %bb69, label %bb70
bb69:
  br label %bb80
bb70:
  br label %bb71
bb71:
  %t231 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t231, ptr %l129, !tbaa !27
  %t232 = load i64, ptr %l13, !tbaa !24
  %t234 = getelementptr { i64, ptr }, ptr %l129, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !27
  %t236 = getelementptr i32, ptr %t235, i64 %t232
  %t237 = load i32, ptr %t236, !tbaa !33
  store i32 %t237, ptr %l15, !tbaa !23
  %t239 = load i32, ptr %l15, !tbaa !23
  %t241 = icmp ne i32 %t239, 0
  br i1 %t241, label %bb72, label %bb73
bb72:
  %t243 = load i1, ptr %l4, !tbaa !21
  br i1 %t243, label %bb74, label %bb75
bb73:
  br label %bb78
bb74:
  store i1 true, ptr %l135, !tbaa !21
  br label %bb77
bb75:
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t246 = load i32, ptr %l15, !tbaa !23
  %t249 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2ereachesWritable(ptr %v0, ptr %t245, i32 %t246)
  store i1 %t249, ptr %l138
  br label %bb76
bb76:
  %t250 = load i1, ptr %l138, !tbaa !21
  store i1 %t250, ptr %l135, !tbaa !21
  br label %bb77
bb77:
  %t251 = load i1, ptr %l135, !tbaa !21
  store i1 %t251, ptr %l4, !tbaa !21
  br label %bb78
bb78:
  br label %bb79
bb79:
  %t252 = load i64, ptr %l13, !tbaa !24
  %t255 = add i64 %t252, 1
  store i64 %t255, ptr %l13, !tbaa !24
  br label %bb68
bb80:
  br label %bb81
bb81:
  br label %bb87
bb82:
  br i1 true, label %bb83, label %bb84
bb83:
  br label %bb85
bb84:
  br label %bb86
bb85:
  br label %bb87
bb86:
  call void @__olang_check_failed(ptr @olang_loc_a8af958fc51ac952_dd02768cc282434e)
  unreachable
bb87:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t259 = getelementptr %"compiler/eval:Machine", ptr %t257, i32 0, i32 77
  %t260 = load i32, ptr %l1, !tbaa !23
  %t261 = load i1, ptr %l4, !tbaa !21
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_H64d9be73b6c9bed004c541bdf7f0ca0a(ptr %v0, ptr %t259, i32 %t260, i1 %t261)
  br label %bb88
bb88:
  %t265 = load i1, ptr %l4, !tbaa !21
  store i1 %t265, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2ereadsMutable(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [15 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, [15 x i64] }
  %l3 = alloca %"compiler/mir:Lvalue"
  %l4 = alloca %"compiler/mir:Range"
  %l5 = alloca i1
  %l8 = alloca i1
  %l14 = alloca i1
  %l21 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, [15 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [15 x i64] }, ptr %l2
  %t3 = extractvalue { i64, [15 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [15 x i64] }, ptr %l2, i32 0, i32 1
  %t7 = getelementptr { { i64, [4 x i64] } }, ptr %t6, i32 0, i32 0
  %t8 = load { i64, [4 x i64] }, ptr %t7
  %t10 = extractvalue { i64, [4 x i64] } %t8, 0
  %t11 = icmp eq i64 %t10, 1
  store i1 %t11, ptr %l8, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l8, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  %t14 = getelementptr { i64, [15 x i64] }, ptr %l2, i32 0, i32 1
  %t15 = getelementptr { { i64, [4 x i64] } }, ptr %t14, i32 0, i32 0
  %t16 = getelementptr { i64, [4 x i64] }, ptr %t15, i32 0, i32 1
  %t17 = getelementptr { %"compiler/mir:Lvalue" }, ptr %t16, i32 0, i32 0
  %t18 = load %"compiler/mir:Lvalue", ptr %t17
  store %"compiler/mir:Lvalue" %t18, ptr %l3
  br label %bb6
bb5:
  br label %bb8
bb6:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load %"compiler/mir:Lvalue", ptr %l3
  %t24 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2emutableGlobal(ptr %v0, ptr %t20, %"compiler/mir:Lvalue" %t21)
  store i1 %t24, ptr %l14
  br label %bb7
bb7:
  %t25 = load i1, ptr %l14, !tbaa !21
  store i1 %t25, ptr %l5, !tbaa !21
  br label %bb18
bb8:
  %t26 = load { i64, [15 x i64] }, ptr %l2
  %t28 = extractvalue { i64, [15 x i64] } %t26, 0
  %t29 = icmp eq i64 %t28, 3
  br i1 %t29, label %bb9, label %bb10
bb9:
  %t31 = getelementptr { i64, [15 x i64] }, ptr %l2, i32 0, i32 1
  %t32 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t31, i32 0, i32 2
  %t33 = load %"compiler/mir:Range", ptr %t32
  store %"compiler/mir:Range" %t33, ptr %l4
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = load %"compiler/mir:Range", ptr %l4
  %t41 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2erangeMutable(ptr %v0, ptr %v1, ptr %t35, ptr %a1, %"compiler/mir:Range" %t37)
  store i1 %t41, ptr %l21
  br label %bb12
bb12:
  %t42 = load i1, ptr %l21, !tbaa !21
  store i1 %t42, ptr %l5, !tbaa !21
  br label %bb18
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store i1 false, ptr %l5, !tbaa !21
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_5132488ea4d5a24a_c872bd4e98b932a6)
  unreachable
bb18:
  %t43 = load i1, ptr %l5, !tbaa !21
  store i1 %t43, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eregionHomeOf(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l10 = alloca %"compiler/eval:scope"
  %l18 = alloca %"compiler/eval:scope"
  %l22 = alloca i1
  %l25 = alloca i1
  %l27 = alloca i1
  %l33 = alloca %"compiler/eval:scope"
  %rv = alloca i64
  %t11 = alloca %"compiler/eval:scope", align 8
  %t27 = alloca %"compiler/eval:scope", align 8
  %t54 = alloca %"compiler/eval:scope", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a1, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/eval:Machine", ptr %t3, i32 0, i32 53
  %t6 = load i64, ptr %l2, !tbaa !24
  %t7 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t10 = and i64 %t6, %t7
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t11, ptr %v0, ptr %t5, i64 %t10)
  call void @llvm.memmove.p0.p0.i64(ptr %l10, ptr %t11, i64 152, i1 false)
  br label %bb2
bb2:
  %t14 = getelementptr %"compiler/eval:scope", ptr %l10, i32 0, i32 19
  %t15 = load i1, ptr %t14, !tbaa !21
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb3, label %bb4
bb3:
  br label %bb19
bb4:
  br label %bb5
bb5:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/eval:Machine", ptr %t19, i32 0, i32 53
  %t22 = load i64, ptr %l2, !tbaa !24
  %t23 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t26 = and i64 %t22, %t23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t27, ptr %v0, ptr %t21, i64 %t26)
  call void @llvm.memmove.p0.p0.i64(ptr %l18, ptr %t27, i64 152, i1 false)
  br label %bb6
bb6:
  %t30 = getelementptr %"compiler/eval:scope", ptr %l18, i32 0, i32 5
  %t31 = load i64, ptr %t30, !tbaa !24
  store i64 %t31, ptr %l3, !tbaa !24
  %t33 = load i64, ptr %l3, !tbaa !24
  %t35 = icmp eq i64 %t33, 0
  br i1 %t35, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb10
bb8:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load i64, ptr %l3, !tbaa !24
  %t41 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2elive(ptr %v0, ptr %t37, i64 %t38)
  store i1 %t41, ptr %l25
  br label %bb9
bb9:
  %t42 = load i1, ptr %l25, !tbaa !21
  %t43 = xor i1 %t42, true
  store i1 %t43, ptr %l22, !tbaa !21
  br label %bb10
bb10:
  %t45 = load i1, ptr %l22, !tbaa !21
  br i1 %t45, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb14
bb12:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/eval:Machine", ptr %t46, i32 0, i32 53
  %t49 = load i64, ptr %l3, !tbaa !24
  %t50 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t53 = and i64 %t49, %t50
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t54, ptr %v0, ptr %t48, i64 %t53)
  call void @llvm.memmove.p0.p0.i64(ptr %l33, ptr %t54, i64 152, i1 false)
  br label %bb13
bb13:
  %t57 = getelementptr %"compiler/eval:scope", ptr %l33, i32 0, i32 2
  %t58 = load i64, ptr %t57, !tbaa !24
  %t59 = load i64, ptr @G_2ecompiler_2feval_2esRegion, !tbaa !24
  %t62 = icmp ne i64 %t58, %t59
  store i1 %t62, ptr %l27, !tbaa !21
  br label %bb14
bb14:
  %t64 = load i1, ptr %l27, !tbaa !21
  br i1 %t64, label %bb15, label %bb16
bb15:
  %t65 = load i64, ptr %l2, !tbaa !24
  store i64 %t65, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t67 = load i64, ptr %l3, !tbaa !24
  store i64 %t67, ptr %l2, !tbaa !24
  br label %bb18
bb18:
  br label %bb1
bb19:
  %t69 = load i64, ptr %l2, !tbaa !24
  store i64 %t69, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erestoreGen(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca %"compiler/eval:genRec"
  %l5 = alloca %"compiler/eval:frame"
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l50 = alloca ptr
  %l54 = alloca { i64, ptr }
  %l61 = alloca %"compiler/eval:genRec"
  %l62 = alloca %"compiler/eval:genRec"
  %l63 = alloca i64
  %l65 = alloca { i64, ptr }
  %l66 = alloca i64
  %l67 = alloca { i64, ptr }
  %l71 = alloca i64
  %l73 = alloca { i64, ptr }
  %l74 = alloca i64
  %l75 = alloca { i64, ptr }
  %l79 = alloca %"compiler/eval:frame"
  %l82 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %l111 = alloca ptr
  %l112 = alloca i64
  %l114 = alloca i64
  %l118 = alloca { i64, ptr }
  %l125 = alloca i64
  %l128 = alloca i64
  %l137 = alloca i64
  %l140 = alloca i1
  %l151 = alloca { i64, ptr }
  %l153 = alloca { i64, ptr }
  %l163 = alloca i64
  %l166 = alloca i64
  %l185 = alloca { i64, ptr }
  %l189 = alloca i64
  %l195 = alloca i64
  %l220 = alloca i64
  %l234 = alloca ptr
  %l235 = alloca i64
  %l239 = alloca i64
  %l240 = alloca %"compiler/eval:frame"
  %l242 = alloca %"compiler/eval:frame"
  %l246 = alloca { i64, ptr }
  %l253 = alloca i64
  %l256 = alloca i64
  %l275 = alloca { i64, ptr }
  %l277 = alloca { i64, ptr }
  %l279 = alloca %"compiler/eval:frame"
  %l284 = alloca { i64, ptr }
  %l287 = alloca %"compiler/eval:frame"
  %l288 = alloca ptr
  %l293 = alloca i64
  %l297 = alloca i64
  %l300 = alloca i64
  %l324 = alloca ptr
  %l327 = alloca i64
  %l329 = alloca ptr
  %l332 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  %t34 = alloca %"compiler/eval:genRec", align 8
  %t503 = alloca %"compiler/eval:frame", align 8
  %t515 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 60
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/eval:Machine", ptr %t5, i32 0, i32 11
  %t8 = load i64, ptr %t7, !tbaa !24
  %t11 = icmp sge i64 %t4, %t8
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l50, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/eval:Machine", ptr %t14, i32 0, i32 1
  %t17 = load i32, ptr %t16, !range !{i32 0, i32 2}
  %t19 = trunc i64 0 to i32
  %t20 = icmp eq i32 %t17, %t19
  br i1 %t20, label %bb3, label %bb4
bb2:
  br label %bb7
bb3:
  %t22 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyDepth, !tbaa !27
  store { i64, ptr } %t22, ptr %l54, !tbaa !27
  br label %bb5
bb4:
  %t24 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyRunDepth, !tbaa !27
  store { i64, ptr } %t24, ptr %l54, !tbaa !27
  br label %bb5
bb5:
  %t26 = load ptr, ptr @__olang_prog_scope
  %t27 = load ptr, ptr %l50, !tbaa !29
  %t28 = load { i64, ptr }, ptr %l54, !tbaa !27
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t26, ptr %t27, { i64, ptr } %t28)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb7:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/eval:Machine", ptr %t30, i32 0, i32 64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3agenRec_3e_2eAt_3ccompiler_2feval_3agenRec_3e(ptr %t34, ptr %v0, ptr %v0, ptr %t32, i64 %a1)
  call void @llvm.memmove.p0.p0.i64(ptr %l61, ptr %t34, i64 280, i1 false)
  br label %bb8
bb8:
  call void @llvm.memmove.p0.p0.i64(ptr %l62, ptr %l61, i64 280, i1 false)
  %t37 = call ptr @__olang_scope_hold(ptr %s0)
  %t38 = ptrtoint ptr %t37 to i64
  store i64 %t38, ptr %l63, !tbaa !24
  %t39 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t39, label %bb9, label %bb10
bb9:
  %t41 = call ptr @__olang_region_make_part(ptr %s0)
  %t42 = ptrtoint ptr %t41 to i64
  store i64 %t42, ptr %l63, !tbaa !24
  br label %bb10
bb10:
  %t43 = getelementptr %"compiler/eval:genRec", ptr %l62, i32 0, i32 6
  %t44 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t43, i32 0, i32 0
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !27
  store { i64, ptr } %t45, ptr %l65, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t46, 0
  store i64 %t47, ptr %l66, !tbaa !24
  %t48 = load i64, ptr %l66, !tbaa !24
  %t49 = mul i64 %t48, 8
  %t50 = load i64, ptr %l63
  %t51 = inttoptr i64 %t50 to ptr
  %t52 = call ptr @__olang_held_alloc(ptr %t51, i64 %t49)
  %t53 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t52, 1
  store { i64, ptr } %t54, ptr %l67, !tbaa !27
  %t55 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = load i64, ptr %l66, !tbaa !24
  %t60 = mul i64 %t59, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t56, ptr %t58, i64 %t60, i1 false)
  %t61 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t62 = getelementptr %"compiler/eval:genRec", ptr %l62, i32 0, i32 6
  %t63 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t62, i32 0, i32 0
  store { i64, ptr } %t61, ptr %t63, !tbaa !27
  %t64 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t64, label %bb11, label %bb12
bb11:
  %t66 = getelementptr %"compiler/eval:genRec", ptr %l62, i32 0, i32 6
  %t67 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t66, i32 0, i32 0
  %t68 = load { i64, ptr }, ptr %t67, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 0
  %t71 = icmp eq i64 %t69, 0
  br i1 %t71, label %bb13, label %bb14
bb12:
  %t73 = call ptr @__olang_scope_hold(ptr %s0)
  %t74 = ptrtoint ptr %t73 to i64
  store i64 %t74, ptr %l71, !tbaa !24
  %t75 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t75, label %bb15, label %bb16
bb13:
  %t77 = getelementptr %"compiler/eval:genRec", ptr %l62, i32 0, i32 6
  %t78 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t77, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t78, !tbaa !27
  br label %bb14
bb14:
  %t79 = getelementptr %"compiler/eval:genRec", ptr %l62, i32 0, i32 6
  %t80 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t79, i32 0, i32 0
  %t81 = load i64, ptr %l63
  %t82 = inttoptr i64 %t81 to ptr
  %t83 = load { i64, ptr }, ptr %t80
  %t84 = extractvalue { i64, ptr } %t83, 1
  %t85 = call ptr @__olang_region_or(ptr %t84, ptr null)
  %t86 = icmp ne ptr %t85, null
  %t87 = select i1 %t86, ptr %t85, ptr null
  call void @__olang_region_settle_in(ptr %t82, ptr %t87)
  br label %bb12
bb15:
  %t88 = call ptr @__olang_region_make_part(ptr %s0)
  %t89 = ptrtoint ptr %t88 to i64
  store i64 %t89, ptr %l71, !tbaa !24
  br label %bb16
bb16:
  %t90 = getelementptr %"compiler/eval:genRec", ptr %l62, i32 0, i32 7
  %t91 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t90, i32 0, i32 0
  %t92 = load { i64, ptr }, ptr %t91, !tbaa !27
  store { i64, ptr } %t92, ptr %l73, !tbaa !27
  %t93 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t93, 0
  store i64 %t94, ptr %l74, !tbaa !24
  %t95 = load i64, ptr %l74, !tbaa !24
  %t96 = mul i64 %t95, 8
  %t97 = load i64, ptr %l71
  %t98 = inttoptr i64 %t97 to ptr
  %t99 = call ptr @__olang_held_alloc(ptr %t98, i64 %t96)
  %t100 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t101 = insertvalue { i64, ptr } %t100, ptr %t99, 1
  store { i64, ptr } %t101, ptr %l75, !tbaa !27
  %t102 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = load i64, ptr %l74, !tbaa !24
  %t107 = mul i64 %t106, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t103, ptr %t105, i64 %t107, i1 false)
  %t108 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t109 = getelementptr %"compiler/eval:genRec", ptr %l62, i32 0, i32 7
  %t110 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t109, i32 0, i32 0
  store { i64, ptr } %t108, ptr %t110, !tbaa !27
  %t111 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t111, label %bb17, label %bb18
bb17:
  %t113 = getelementptr %"compiler/eval:genRec", ptr %l62, i32 0, i32 7
  %t114 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t113, i32 0, i32 0
  %t115 = load { i64, ptr }, ptr %t114, !tbaa !27
  %t116 = extractvalue { i64, ptr } %t115, 0
  %t118 = icmp eq i64 %t116, 0
  br i1 %t118, label %bb19, label %bb20
bb18:
  call void @llvm.memmove.p0.p0.i64(ptr %l4, ptr %l62, i64 280, i1 false)
  %t120 = getelementptr %"compiler/eval:genRec", ptr %l4, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %l79, ptr %t120, i64 136, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l5, ptr %l79, i64 136, i1 false)
  %t121 = getelementptr %"compiler/eval:frame", ptr %l5, i32 0, i32 0
  %t122 = load i64, ptr %t121, !tbaa !24
  store i64 %t122, ptr %l6, !tbaa !24
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/eval:Machine", ptr %t124, i32 0, i32 27
  %t127 = load { i64, ptr }, ptr %t126, !tbaa !27
  store { i64, ptr } %t127, ptr %l82, !tbaa !27
  %t128 = load i64, ptr %l6, !tbaa !24
  %t130 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr %"compiler/eval:cfn", ptr %t131, i64 %t128
  %t133 = getelementptr %"compiler/eval:cfn", ptr %t132, i32 0, i32 1
  %t134 = load { i64, ptr }, ptr %t133, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t134, 0
  store i64 %t136, ptr %l7, !tbaa !24
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"compiler/eval:Machine", ptr %t138, i32 0, i32 27
  %t141 = load { i64, ptr }, ptr %t140, !tbaa !27
  store { i64, ptr } %t141, ptr %l87, !tbaa !27
  %t142 = load i64, ptr %l6, !tbaa !24
  %t144 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !27
  %t146 = getelementptr %"compiler/eval:cfn", ptr %t145, i64 %t142
  %t147 = getelementptr %"compiler/eval:cfn", ptr %t146, i32 0, i32 2
  %t148 = load { i64, ptr }, ptr %t147, !tbaa !27
  %t150 = extractvalue { i64, ptr } %t148, 0
  store i64 %t150, ptr %l8, !tbaa !24
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/eval:Machine", ptr %t152, i32 0, i32 62
  %t155 = load i64, ptr %t154, !tbaa !24
  %t156 = getelementptr %"compiler/eval:genRec", ptr %l4, i32 0, i32 9
  %t157 = load i64, ptr %t156, !tbaa !24
  %t160 = add i64 %t155, %t157
  store i64 %t160, ptr %l9, !tbaa !24
  %t162 = load i64, ptr %l9, !tbaa !24
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t165 = getelementptr %"compiler/eval:Machine", ptr %t163, i32 0, i32 61
  %t166 = load { i64, ptr }, ptr %t165, !tbaa !27
  %t168 = extractvalue { i64, ptr } %t166, 0
  %t171 = icmp sgt i64 %t162, %t168
  br i1 %t171, label %bb21, label %bb22
bb19:
  %t173 = getelementptr %"compiler/eval:genRec", ptr %l62, i32 0, i32 7
  %t174 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t173, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t174, !tbaa !27
  br label %bb20
bb20:
  %t175 = getelementptr %"compiler/eval:genRec", ptr %l62, i32 0, i32 7
  %t176 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t175, i32 0, i32 0
  %t177 = load i64, ptr %l71
  %t178 = inttoptr i64 %t177 to ptr
  %t179 = load { i64, ptr }, ptr %t176
  %t180 = extractvalue { i64, ptr } %t179, 1
  %t181 = call ptr @__olang_region_or(ptr %t180, ptr null)
  %t182 = icmp ne ptr %t181, null
  %t183 = select i1 %t182, ptr %t181, ptr null
  call void @__olang_region_settle_in(ptr %t178, ptr %t183)
  br label %bb18
bb21:
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = getelementptr %"compiler/eval:Machine", ptr %t184, i32 0, i32 61
  %t187 = load { i64, ptr }, ptr %t186, !tbaa !27
  store { i64, ptr } %t187, ptr %l10, !tbaa !27
  %t189 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t191 = extractvalue { i64, ptr } %t189, 0
  store i64 %t191, ptr %l11, !tbaa !24
  br label %bb23
bb22:
  br label %bb49
bb23:
  %t193 = load i64, ptr %l11, !tbaa !24
  %t194 = load i64, ptr %l9, !tbaa !24
  %t197 = icmp slt i64 %t193, %t194
  %t199 = xor i1 %t197, true
  br i1 %t199, label %bb24, label %bb25
bb24:
  br label %bb28
bb25:
  br label %bb26
bb26:
  %t201 = load i64, ptr %l11, !tbaa !24
  %t204 = mul i64 %t201, 2
  store i64 %t204, ptr %l11, !tbaa !24
  br label %bb27
bb27:
  br label %bb23
bb28:
  %t206 = load ptr, ptr %l0, !tbaa !29
  store ptr %t206, ptr %l111, !tbaa !29
  %t207 = call ptr @__olang_scope_hold(ptr %v0)
  %t208 = ptrtoint ptr %t207 to i64
  store i64 %t208, ptr %l112, !tbaa !24
  %t209 = load i1, ptr @olang_2esole_2ecompiler_2feval_3aMachine_2e61
  br i1 %t209, label %bb29, label %bb30
bb29:
  %t211 = call ptr @__olang_region_make(ptr %v0)
  %t212 = ptrtoint ptr %t211 to i64
  store i64 %t212, ptr %l112, !tbaa !24
  br label %bb30
bb30:
  %t213 = load i64, ptr %l11, !tbaa !24
  store i64 %t213, ptr %l114, !tbaa !24
  %t214 = load i64, ptr %l114, !tbaa !24
  %t215 = icmp sge i64 %t214, 0
  br i1 %t215, label %bb31, label %bb32
bb31:
  %t217 = load i64, ptr %l114, !tbaa !24
  %t218 = icmp sle i64 %t217, 1152921504606846975
  br i1 %t218, label %bb33, label %bb34
bb32:
  call void @__olang_check_failed(ptr @olang_loc_82f264fd3f63866e_1586045834f1f9b2)
  unreachable
bb33:
  %t220 = load i64, ptr %l114, !tbaa !24
  %t221 = mul i64 %t220, 8
  %t222 = load i64, ptr %l112
  %t223 = inttoptr i64 %t222 to ptr
  %t224 = call ptr @__olang_scope_alloc_zeroed(ptr %t223, i64 %t221)
  %t225 = insertvalue { i64, ptr } undef, i64 %t220, 0
  %t226 = insertvalue { i64, ptr } %t225, ptr %t224, 1
  %t227 = load ptr, ptr %l111, !tbaa !29
  %t228 = getelementptr %"compiler/eval:Machine", ptr %t227, i32 0, i32 61
  %t229 = load { i64, ptr }, ptr %t228, !tbaa !27
  store { i64, ptr } %t229, ptr %l118, !tbaa !27
  %t231 = load ptr, ptr %l111, !tbaa !29
  %t232 = getelementptr %"compiler/eval:Machine", ptr %t231, i32 0, i32 61
  store { i64, ptr } %t226, ptr %t232, !tbaa !27
  %t233 = load i1, ptr @olang_2esole_2ecompiler_2feval_3aMachine_2e61
  br i1 %t233, label %bb35, label %bb36
bb34:
  call void @__olang_check_failed(ptr @olang_loc_82f264fd3f63866e_1586045834f1f9b2)
  unreachable
bb35:
  %t235 = load { i64, ptr }, ptr %l118
  %t236 = extractvalue { i64, ptr } %t235, 1
  call void @__olang_region_release(ptr %t236)
  store { i64, ptr } zeroinitializer, ptr %l118
  br label %bb36
bb36:
  store i64 0, ptr %l12, !tbaa !24
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t239 = getelementptr %"compiler/eval:Machine", ptr %t237, i32 0, i32 62
  %t240 = load i64, ptr %t239, !tbaa !24
  store i64 %t240, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t242 = load i64, ptr %l13, !tbaa !24
  %t243 = load i64, ptr %l12, !tbaa !24
  %t246 = icmp sgt i64 %t242, %t243
  br i1 %t246, label %bb37, label %bb38
bb37:
  %t248 = load i64, ptr %l14, !tbaa !24
  %t250 = icmp sgt i64 %t248, 0
  br i1 %t250, label %bb39, label %bb40
bb38:
  store i64 0, ptr %l125, !tbaa !24
  br label %bb42
bb39:
  %t252 = load i64, ptr %l13, !tbaa !24
  %t253 = load i64, ptr %l12, !tbaa !24
  %t256 = sub i64 %t252, %t253
  %t257 = load i64, ptr %l14, !tbaa !24
  %t260 = add i64 %t256, %t257
  %t262 = sub i64 %t260, 1
  %t263 = load i64, ptr %l14, !tbaa !24
  %t266 = sdiv i64 %t262, %t263
  store i64 %t266, ptr %l128, !tbaa !24
  br label %bb41
bb40:
  store i64 0, ptr %l128, !tbaa !24
  br label %bb41
bb41:
  %t268 = load i64, ptr %l128, !tbaa !24
  store i64 %t268, ptr %l125, !tbaa !24
  br label %bb42
bb42:
  %t269 = load i64, ptr %l125, !tbaa !24
  store i64 %t269, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  %t270 = load i64, ptr %l15, !tbaa !24
  %t271 = sub i64 %t270, 1
  store i64 %t271, ptr %l137, !tbaa !24
  %t272 = load i64, ptr %l15, !tbaa !24
  %t273 = icmp slt i64 %t272, 2147483648
  %t274 = load i64, ptr %l16, !tbaa !24
  %t275 = icmp sge i64 %t274, 0
  %t278 = and i1 %t273, %t275
  store i1 %t278, ptr %l140, !tbaa !21
  br label %bb43
bb43:
  %t279 = load i64, ptr %l16, !tbaa !24
  %t280 = load i64, ptr %l15, !tbaa !24
  %t283 = icmp slt i64 %t279, %t280
  %t285 = xor i1 %t283, true
  br i1 %t285, label %bb44, label %bb45
bb44:
  br label %bb48
bb45:
  br label %bb46
bb46:
  %t287 = load i64, ptr %l12, !tbaa !24
  %t288 = load i64, ptr %l16, !tbaa !24
  %t289 = load i64, ptr %l14, !tbaa !24
  %t292 = mul i64 %t288, %t289
  %t295 = add i64 %t287, %t292
  store i64 %t295, ptr %l17, !tbaa !24
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t299 = getelementptr %"compiler/eval:Machine", ptr %t297, i32 0, i32 61
  %t300 = load { i64, ptr }, ptr %t299, !tbaa !27
  store { i64, ptr } %t300, ptr %l151, !tbaa !27
  %t301 = load i64, ptr %l17, !tbaa !24
  %t302 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t302, ptr %l153, !tbaa !27
  %t303 = load i64, ptr %l17, !tbaa !24
  %t305 = getelementptr { i64, ptr }, ptr %l153, i32 0, i32 1
  %t306 = load ptr, ptr %t305, !tbaa !27
  %t307 = getelementptr i64, ptr %t306, i64 %t303
  %t308 = load i64, ptr %t307, !tbaa !34
  %t311 = getelementptr { i64, ptr }, ptr %l151, i32 0, i32 1
  %t312 = load ptr, ptr %t311, !tbaa !27
  %t313 = getelementptr i64, ptr %t312, i64 %t301
  store i64 %t308, ptr %t313, !tbaa !34
  br label %bb47
bb47:
  %t314 = load i64, ptr %l16, !tbaa !24
  %t317 = add i64 %t314, 1
  store i64 %t317, ptr %l16, !tbaa !24
  br label %bb43
bb48:
  br label %bb49
bb49:
  store i64 0, ptr %l18, !tbaa !24
  %t319 = getelementptr %"compiler/eval:genRec", ptr %l4, i32 0, i32 9
  %t320 = load i64, ptr %t319, !tbaa !24
  store i64 %t320, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t322 = load i64, ptr %l19, !tbaa !24
  %t323 = load i64, ptr %l18, !tbaa !24
  %t326 = icmp sgt i64 %t322, %t323
  br i1 %t326, label %bb50, label %bb51
bb50:
  %t328 = load i64, ptr %l20, !tbaa !24
  %t330 = icmp sgt i64 %t328, 0
  br i1 %t330, label %bb52, label %bb53
bb51:
  store i64 0, ptr %l163, !tbaa !24
  br label %bb55
bb52:
  %t332 = load i64, ptr %l19, !tbaa !24
  %t333 = load i64, ptr %l18, !tbaa !24
  %t336 = sub i64 %t332, %t333
  %t337 = load i64, ptr %l20, !tbaa !24
  %t340 = add i64 %t336, %t337
  %t342 = sub i64 %t340, 1
  %t343 = load i64, ptr %l20, !tbaa !24
  %t346 = sdiv i64 %t342, %t343
  store i64 %t346, ptr %l166, !tbaa !24
  br label %bb54
bb53:
  store i64 0, ptr %l166, !tbaa !24
  br label %bb54
bb54:
  %t348 = load i64, ptr %l166, !tbaa !24
  store i64 %t348, ptr %l163, !tbaa !24
  br label %bb55
bb55:
  %t349 = load i64, ptr %l163, !tbaa !24
  store i64 %t349, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb56
bb56:
  %t350 = load i64, ptr %l22, !tbaa !24
  %t351 = load i64, ptr %l21, !tbaa !24
  %t354 = icmp slt i64 %t350, %t351
  %t356 = xor i1 %t354, true
  br i1 %t356, label %bb57, label %bb58
bb57:
  br label %bb62
bb58:
  br label %bb59
bb59:
  %t358 = load i64, ptr %l18, !tbaa !24
  %t359 = load i64, ptr %l22, !tbaa !24
  %t360 = load i64, ptr %l20, !tbaa !24
  %t363 = mul i64 %t359, %t360
  %t366 = add i64 %t358, %t363
  store i64 %t366, ptr %l23, !tbaa !24
  %t368 = load ptr, ptr %l0, !tbaa !29
  %t370 = getelementptr %"compiler/eval:Machine", ptr %t368, i32 0, i32 61
  %t371 = load { i64, ptr }, ptr %t370, !tbaa !27
  store { i64, ptr } %t371, ptr %l185, !tbaa !27
  %t372 = load ptr, ptr %l0, !tbaa !29
  %t374 = getelementptr %"compiler/eval:Machine", ptr %t372, i32 0, i32 62
  %t375 = load i64, ptr %t374, !tbaa !24
  %t376 = load i64, ptr %l23, !tbaa !24
  %t379 = add i64 %t375, %t376
  store i64 %t379, ptr %l189, !tbaa !24
  %t380 = load ptr, ptr %l0, !tbaa !29
  %t382 = getelementptr %"compiler/eval:Machine", ptr %t380, i32 0, i32 66
  %t383 = getelementptr %"compiler/eval:genRec", ptr %l4, i32 0, i32 8
  %t384 = load i64, ptr %t383, !tbaa !24
  %t385 = load i64, ptr %l23, !tbaa !24
  %t388 = add i64 %t384, %t385
  %t391 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t382, i64 %t388)
  store i64 %t391, ptr %l195
  br label %bb60
bb60:
  %t392 = load i64, ptr %l195, !tbaa !24
  %t393 = load i64, ptr %l189, !tbaa !24
  %t394 = getelementptr { i64, ptr }, ptr %l185, i32 0, i32 1
  %t395 = load ptr, ptr %t394, !tbaa !27
  %t396 = getelementptr i64, ptr %t395, i64 %t393
  store i64 %t392, ptr %t396, !tbaa !34
  br label %bb61
bb61:
  %t397 = load i64, ptr %l22, !tbaa !24
  %t400 = add i64 %t397, 1
  store i64 %t400, ptr %l22, !tbaa !24
  br label %bb56
bb62:
  %t402 = load ptr, ptr %l0, !tbaa !29
  %t404 = getelementptr %"compiler/eval:Machine", ptr %t402, i32 0, i32 62
  %t405 = load i64, ptr %t404, !tbaa !24
  %t407 = load ptr, ptr %l0, !tbaa !29
  %t409 = getelementptr %"compiler/eval:Machine", ptr %t407, i32 0, i32 62
  %t410 = load i64, ptr %t409, !tbaa !24
  %t411 = load i64, ptr %l7, !tbaa !24
  %t414 = add i64 %t410, %t411
  %t416 = load ptr, ptr %l0, !tbaa !29
  %t418 = getelementptr %"compiler/eval:Machine", ptr %t416, i32 0, i32 62
  %t419 = load i64, ptr %t418, !tbaa !24
  %t420 = load i64, ptr %l7, !tbaa !24
  %t423 = add i64 %t419, %t420
  %t424 = load i64, ptr %l8, !tbaa !24
  %t427 = add i64 %t423, %t424
  %t431 = getelementptr %"compiler/eval:frame", ptr %l5, i32 0, i32 3
  store i64 %t405, ptr %t431, !tbaa !24
  %t434 = getelementptr %"compiler/eval:frame", ptr %l5, i32 0, i32 4
  store i64 %t414, ptr %t434, !tbaa !24
  %t437 = getelementptr %"compiler/eval:frame", ptr %l5, i32 0, i32 5
  store i64 %t427, ptr %t437, !tbaa !24
  %t444 = getelementptr %"compiler/eval:frame", ptr %l5, i32 0, i32 7
  store i64 %a2, ptr %t444, !tbaa !24
  %t447 = getelementptr %"compiler/eval:frame", ptr %l5, i32 0, i32 8
  store i64 %a3, ptr %t447, !tbaa !24
  %t448 = load ptr, ptr %l0, !tbaa !29
  %t450 = getelementptr %"compiler/eval:Machine", ptr %t448, i32 0, i32 63
  %t452 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t450)
  store i64 %t452, ptr %l220
  br label %bb63
bb63:
  %t453 = load i64, ptr %l220, !tbaa !24
  %t454 = getelementptr %"compiler/eval:frame", ptr %l5, i32 0, i32 9
  store i64 %t453, ptr %t454, !tbaa !24
  %t457 = getelementptr %"compiler/eval:frame", ptr %l5, i32 0, i32 10
  store i1 false, ptr %t457, !tbaa !21
  %t460 = getelementptr %"compiler/eval:frame", ptr %l5, i32 0, i32 11
  store i1 false, ptr %t460, !tbaa !21
  %t463 = getelementptr %"compiler/eval:frame", ptr %l5, i32 0, i32 12
  store i1 false, ptr %t463, !tbaa !21
  %t464 = load ptr, ptr %l0, !tbaa !29
  %t465 = load i64, ptr %l9, !tbaa !24
  %t468 = getelementptr %"compiler/eval:Machine", ptr %t464, i32 0, i32 62
  store i64 %t465, ptr %t468, !tbaa !24
  %t469 = load ptr, ptr %l0, !tbaa !29
  %t471 = getelementptr %"compiler/eval:Machine", ptr %t469, i32 0, i32 60
  %t472 = load i64, ptr %t471, !tbaa !24
  %t473 = load ptr, ptr %l0, !tbaa !29
  %t475 = getelementptr %"compiler/eval:Machine", ptr %t473, i32 0, i32 59
  %t476 = load { i64, ptr }, ptr %t475, !tbaa !27
  %t478 = extractvalue { i64, ptr } %t476, 0
  %t481 = icmp sge i64 %t472, %t478
  br i1 %t481, label %bb64, label %bb65
bb64:
  %t483 = load ptr, ptr %l0, !tbaa !29
  %t485 = getelementptr %"compiler/eval:Machine", ptr %t483, i32 0, i32 59
  %t486 = load { i64, ptr }, ptr %t485, !tbaa !27
  store { i64, ptr } %t486, ptr %l32, !tbaa !27
  %t488 = load ptr, ptr %l0, !tbaa !29
  store ptr %t488, ptr %l234, !tbaa !29
  %t489 = call ptr @__olang_scope_hold(ptr %v0)
  %t490 = ptrtoint ptr %t489 to i64
  store i64 %t490, ptr %l235, !tbaa !24
  %t491 = load i1, ptr @olang_2esole_2ecompiler_2feval_3aMachine_2e59
  br i1 %t491, label %bb66, label %bb67
bb65:
  br label %bb89
bb66:
  %t493 = call ptr @__olang_region_make(ptr %v0)
  %t494 = ptrtoint ptr %t493 to i64
  store i64 %t494, ptr %l235, !tbaa !24
  br label %bb67
bb67:
  %t495 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t497 = extractvalue { i64, ptr } %t495, 0
  %t499 = mul i64 2, %t497
  store i64 %t499, ptr %l239, !tbaa !24
  call void @llvm.memset.p0.i64(ptr %l240, i8 0, i64 136, i1 false)
  %t500 = load i64, ptr %l239, !tbaa !24
  %t501 = icmp sgt i64 %t500, 0
  br i1 %t501, label %bb68, label %bb69
bb68:
  call void @olang_2emir_2eHelperKind_2eZero_2ecompiler_2feval_3aframe(ptr %t503)
  call void @llvm.memmove.p0.p0.i64(ptr %l242, ptr %t503, i64 136, i1 false)
  br label %bb70
bb69:
  %t504 = load i64, ptr %l239, !tbaa !24
  %t505 = icmp sge i64 %t504, 0
  br i1 %t505, label %bb71, label %bb72
bb70:
  call void @llvm.memmove.p0.p0.i64(ptr %l240, ptr %l242, i64 136, i1 false)
  br label %bb69
bb71:
  %t507 = load i64, ptr %l239, !tbaa !24
  %t508 = icmp sle i64 %t507, 67818912035696880
  br i1 %t508, label %bb73, label %bb74
bb72:
  call void @__olang_check_failed(ptr @olang_loc_9faf736d233c85e3_6ce3cec307115a7)
  unreachable
bb73:
  %t510 = load i64, ptr %l239, !tbaa !24
  %t511 = mul i64 %t510, 136
  %t512 = load i64, ptr %l235
  %t513 = inttoptr i64 %t512 to ptr
  %t514 = call ptr @__olang_held_alloc(ptr %t513, i64 %t511)
  store i64 0, ptr %t515
  br label %fill.516
fill.516:
  %t519 = load i64, ptr %t515
  %t520 = icmp slt i64 %t519, %t510
  br i1 %t520, label %fillb.517, label %filld.518
fillb.517:
  %t521 = getelementptr %"compiler/eval:frame", ptr %t514, i64 %t519
  call void @llvm.memmove.p0.p0.i64(ptr %t521, ptr %l240, i64 136, i1 false)
  %t522 = add i64 %t519, 1
  store i64 %t522, ptr %t515
  br label %fill.516
filld.518:
  %t523 = insertvalue { i64, ptr } undef, i64 %t510, 0
  %t524 = insertvalue { i64, ptr } %t523, ptr %t514, 1
  %t525 = load ptr, ptr %l234, !tbaa !29
  %t526 = getelementptr %"compiler/eval:Machine", ptr %t525, i32 0, i32 59
  %t527 = load { i64, ptr }, ptr %t526, !tbaa !27
  store { i64, ptr } %t527, ptr %l246, !tbaa !27
  %t529 = load ptr, ptr %l234, !tbaa !29
  %t530 = getelementptr %"compiler/eval:Machine", ptr %t529, i32 0, i32 59
  store { i64, ptr } %t524, ptr %t530, !tbaa !27
  %t531 = load i1, ptr @olang_2esole_2ecompiler_2feval_3aMachine_2e59
  br i1 %t531, label %bb75, label %bb76
bb74:
  call void @__olang_check_failed(ptr @olang_loc_9faf736d233c85e3_6ce3cec307115a7)
  unreachable
bb75:
  %t533 = load { i64, ptr }, ptr %l246
  %t534 = extractvalue { i64, ptr } %t533, 1
  call void @__olang_region_release(ptr %t534)
  store { i64, ptr } zeroinitializer, ptr %l246
  br label %bb76
bb76:
  store i64 0, ptr %l33, !tbaa !24
  %t535 = load ptr, ptr %l0, !tbaa !29
  %t537 = getelementptr %"compiler/eval:Machine", ptr %t535, i32 0, i32 60
  %t538 = load i64, ptr %t537, !tbaa !24
  store i64 %t538, ptr %l34, !tbaa !24
  store i64 1, ptr %l35, !tbaa !24
  %t540 = load i64, ptr %l34, !tbaa !24
  %t541 = load i64, ptr %l33, !tbaa !24
  %t544 = icmp sgt i64 %t540, %t541
  br i1 %t544, label %bb77, label %bb78
bb77:
  %t546 = load i64, ptr %l35, !tbaa !24
  %t548 = icmp sgt i64 %t546, 0
  br i1 %t548, label %bb79, label %bb80
bb78:
  store i64 0, ptr %l253, !tbaa !24
  br label %bb82
bb79:
  %t550 = load i64, ptr %l34, !tbaa !24
  %t551 = load i64, ptr %l33, !tbaa !24
  %t554 = sub i64 %t550, %t551
  %t555 = load i64, ptr %l35, !tbaa !24
  %t558 = add i64 %t554, %t555
  %t560 = sub i64 %t558, 1
  %t561 = load i64, ptr %l35, !tbaa !24
  %t564 = sdiv i64 %t560, %t561
  store i64 %t564, ptr %l256, !tbaa !24
  br label %bb81
bb80:
  store i64 0, ptr %l256, !tbaa !24
  br label %bb81
bb81:
  %t566 = load i64, ptr %l256, !tbaa !24
  store i64 %t566, ptr %l253, !tbaa !24
  br label %bb82
bb82:
  %t567 = load i64, ptr %l253, !tbaa !24
  store i64 %t567, ptr %l36, !tbaa !24
  store i64 0, ptr %l37, !tbaa !24
  br label %bb83
bb83:
  %t568 = load i64, ptr %l37, !tbaa !24
  %t569 = load i64, ptr %l36, !tbaa !24
  %t572 = icmp slt i64 %t568, %t569
  %t574 = xor i1 %t572, true
  br i1 %t574, label %bb84, label %bb85
bb84:
  br label %bb88
bb85:
  br label %bb86
bb86:
  %t576 = load i64, ptr %l33, !tbaa !24
  %t577 = load i64, ptr %l37, !tbaa !24
  %t578 = load i64, ptr %l35, !tbaa !24
  %t581 = mul i64 %t577, %t578
  %t584 = add i64 %t576, %t581
  store i64 %t584, ptr %l38, !tbaa !24
  %t586 = load ptr, ptr %l0, !tbaa !29
  %t588 = getelementptr %"compiler/eval:Machine", ptr %t586, i32 0, i32 59
  %t589 = load { i64, ptr }, ptr %t588, !tbaa !27
  store { i64, ptr } %t589, ptr %l275, !tbaa !27
  %t590 = load i64, ptr %l38, !tbaa !24
  %t591 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t591, ptr %l277, !tbaa !27
  %t592 = load i64, ptr %l38, !tbaa !24
  %t594 = getelementptr { i64, ptr }, ptr %l277, i32 0, i32 1
  %t595 = load ptr, ptr %t594, !tbaa !27
  %t596 = getelementptr %"compiler/eval:frame", ptr %t595, i64 %t592
  call void @llvm.memmove.p0.p0.i64(ptr %l279, ptr %t596, i64 136, i1 false)
  %t598 = getelementptr { i64, ptr }, ptr %l275, i32 0, i32 1
  %t599 = load ptr, ptr %t598, !tbaa !27
  %t600 = getelementptr %"compiler/eval:frame", ptr %t599, i64 %t590
  call void @llvm.memmove.p0.p0.i64(ptr %t600, ptr %l279, i64 136, i1 false)
  br label %bb87
bb87:
  %t601 = load i64, ptr %l37, !tbaa !24
  %t604 = add i64 %t601, 1
  store i64 %t604, ptr %l37, !tbaa !24
  br label %bb83
bb88:
  br label %bb89
bb89:
  %t606 = load ptr, ptr %l0, !tbaa !29
  %t608 = getelementptr %"compiler/eval:Machine", ptr %t606, i32 0, i32 59
  %t609 = load { i64, ptr }, ptr %t608, !tbaa !27
  store { i64, ptr } %t609, ptr %l284, !tbaa !27
  %t610 = load ptr, ptr %l0, !tbaa !29
  %t612 = getelementptr %"compiler/eval:Machine", ptr %t610, i32 0, i32 60
  %t613 = load i64, ptr %t612, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l287, ptr %l5, i64 136, i1 false)
  %t615 = getelementptr { i64, ptr }, ptr %l284, i32 0, i32 1
  %t616 = load ptr, ptr %t615, !tbaa !27
  %t617 = getelementptr %"compiler/eval:frame", ptr %t616, i64 %t613
  call void @llvm.memmove.p0.p0.i64(ptr %t617, ptr %l287, i64 136, i1 false)
  %t618 = load ptr, ptr %l0, !tbaa !29
  store ptr %t618, ptr %l288, !tbaa !29
  %t619 = load ptr, ptr %l288, !tbaa !29
  %t620 = getelementptr %"compiler/eval:Machine", ptr %t619, i32 0, i32 60
  %t621 = load i64, ptr %t620, !tbaa !24
  %t624 = add i64 %t621, 1
  %t626 = load ptr, ptr %l288, !tbaa !29
  %t627 = getelementptr %"compiler/eval:Machine", ptr %t626, i32 0, i32 60
  store i64 %t624, ptr %t627, !tbaa !24
  store i64 0, ptr %l39, !tbaa !24
  %t628 = getelementptr %"compiler/eval:genRec", ptr %l4, i32 0, i32 6
  %t630 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t628)
  store i64 %t630, ptr %l293
  br label %bb90
bb90:
  %t631 = load i64, ptr %l293, !tbaa !24
  store i64 %t631, ptr %l40, !tbaa !24
  store i64 1, ptr %l41, !tbaa !24
  %t632 = load i64, ptr %l40, !tbaa !24
  %t633 = load i64, ptr %l39, !tbaa !24
  %t636 = icmp sgt i64 %t632, %t633
  br i1 %t636, label %bb91, label %bb92
bb91:
  %t638 = load i64, ptr %l41, !tbaa !24
  %t640 = icmp sgt i64 %t638, 0
  br i1 %t640, label %bb93, label %bb94
bb92:
  store i64 0, ptr %l297, !tbaa !24
  br label %bb96
bb93:
  %t642 = load i64, ptr %l40, !tbaa !24
  %t643 = load i64, ptr %l39, !tbaa !24
  %t646 = sub i64 %t642, %t643
  %t647 = load i64, ptr %l41, !tbaa !24
  %t650 = add i64 %t646, %t647
  %t652 = sub i64 %t650, 1
  %t653 = load i64, ptr %l41, !tbaa !24
  %t656 = sdiv i64 %t652, %t653
  store i64 %t656, ptr %l300, !tbaa !24
  br label %bb95
bb94:
  store i64 0, ptr %l300, !tbaa !24
  br label %bb95
bb95:
  %t658 = load i64, ptr %l300, !tbaa !24
  store i64 %t658, ptr %l297, !tbaa !24
  br label %bb96
bb96:
  %t659 = load i64, ptr %l297, !tbaa !24
  store i64 %t659, ptr %l42, !tbaa !24
  store i64 0, ptr %l43, !tbaa !24
  br label %bb97
bb97:
  %t660 = load i64, ptr %l43, !tbaa !24
  %t661 = load i64, ptr %l42, !tbaa !24
  %t664 = icmp slt i64 %t660, %t661
  %t666 = xor i1 %t664, true
  br i1 %t666, label %bb98, label %bb99
bb98:
  br label %bb107
bb99:
  br label %bb100
bb100:
  %t668 = load i64, ptr %l39, !tbaa !24
  %t669 = load i64, ptr %l43, !tbaa !24
  %t670 = load i64, ptr %l41, !tbaa !24
  %t673 = mul i64 %t669, %t670
  %t676 = add i64 %t668, %t673
  store i64 %t676, ptr %l44, !tbaa !24
  %t678 = load ptr, ptr %l0, !tbaa !29
  %t680 = getelementptr %"compiler/eval:Machine", ptr %t678, i32 0, i32 67
  %t681 = load ptr, ptr %l0, !tbaa !29
  %t683 = getelementptr %"compiler/eval:Machine", ptr %t681, i32 0, i32 60
  %t684 = load i64, ptr %t683, !tbaa !24
  %t686 = sub i64 %t684, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t680, i64 %t686)
  br label %bb101
bb101:
  %t689 = load ptr, ptr %l0, !tbaa !29
  %t691 = getelementptr %"compiler/eval:Machine", ptr %t689, i32 0, i32 68
  store ptr %t691, ptr %l324, !tbaa !29
  %t692 = getelementptr %"compiler/eval:genRec", ptr %l4, i32 0, i32 6
  %t693 = load i64, ptr %l44, !tbaa !24
  %t696 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t692, i64 %t693)
  store i64 %t696, ptr %l327
  br label %bb102
bb102:
  %t697 = load ptr, ptr %l324, !tbaa !29
  %t698 = load i64, ptr %l327, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t697, i64 %t698)
  br label %bb103
bb103:
  %t699 = load ptr, ptr %l0, !tbaa !29
  %t701 = getelementptr %"compiler/eval:Machine", ptr %t699, i32 0, i32 69
  store ptr %t701, ptr %l329, !tbaa !29
  %t702 = getelementptr %"compiler/eval:genRec", ptr %l4, i32 0, i32 7
  %t703 = load i64, ptr %l44, !tbaa !24
  %t706 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t702, i64 %t703)
  store i64 %t706, ptr %l332
  br label %bb104
bb104:
  %t707 = load ptr, ptr %l329, !tbaa !29
  %t708 = load i64, ptr %l332, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t707, i64 %t708)
  br label %bb105
bb105:
  br label %bb106
bb106:
  %t709 = load i64, ptr %l43, !tbaa !24
  %t712 = add i64 %t709, 1
  store i64 %t712, ptr %l43, !tbaa !24
  br label %bb97
bb107:
  %t714 = load ptr, ptr %l0, !tbaa !29
  %t716 = getelementptr %"compiler/eval:Machine", ptr %t714, i32 0, i32 60
  %t717 = load i64, ptr %t716, !tbaa !24
  %t719 = sub i64 %t717, 1
  call void @__olang_scope_close(ptr %s0)
  store i64 %t719, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2ereturned(ptr %v0, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/eval:frame"
  %l2 = alloca i64
  %l4 = alloca i64
  %l7 = alloca i1
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l22 = alloca %"compiler/eval:frame"
  %l33 = alloca i1
  %l35 = alloca i1
  %l47 = alloca i1
  %l49 = alloca i1
  %l56 = alloca ptr
  %l65 = alloca ptr
  %l68 = alloca ptr
  %l69 = alloca i1
  %l71 = alloca i1
  %l79 = alloca i1
  %l82 = alloca i1
  %l84 = alloca %"compiler/eval:frame"
  %l87 = alloca ptr
  %l88 = alloca i64
  %l91 = alloca i64
  %l92 = alloca i32
  %l93 = alloca i64
  %l96 = alloca i64
  %l97 = alloca i32
  %l100 = alloca i64
  %l107 = alloca i64
  %l110 = alloca i64
  %l129 = alloca ptr
  %l135 = alloca i64
  %l143 = alloca %"compiler/eval:frame"
  %t12 = alloca %"compiler/eval:frame", align 8
  %t25 = alloca { i64, [5 x i64] }, align 8
  %t157 = alloca %"compiler/eval:frame", align 8
  %t274 = alloca %"compiler/eval:frame", align 8
  store ptr %a0, ptr %l0
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %a1, i64 136, i1 false)
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/eval:frame", ptr %l1, i32 0, i32 7
  %t2 = load i64, ptr %t1, !tbaa !24
  store i64 %t2, ptr %l2, !tbaa !24
  %t4 = load i64, ptr %l2, !tbaa !24
  %t5 = load i64, ptr @G_2ecompiler_2feval_2erCall, !tbaa !24
  %t8 = icmp eq i64 %t4, %t5
  br i1 %t8, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  call void @llvm.memmove.p0.p0.i64(ptr %l22, ptr %l1, i64 136, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %t12, ptr %l22, i64 136, i1 false)
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ecallReturned(ptr %v0, ptr %t10, ptr %t12)
  br label %bb4
bb4:
  br label %bb90
bb5:
  %t13 = load i64, ptr %l2, !tbaa !24
  %t14 = load i64, ptr @G_2ecompiler_2feval_2erRequest, !tbaa !24
  %t17 = icmp eq i64 %t13, %t14
  br i1 %t17, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb21
bb8:
  %t19 = getelementptr %"compiler/eval:frame", ptr %l1, i32 0, i32 12
  %t20 = load i1, ptr %t19, !tbaa !21
  br i1 %t20, label %bb9, label %bb10
bb9:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/eval:frame", ptr %l1, i32 0, i32 13
  %t24 = load i64, ptr %t23, !tbaa !24
  store { i64, [5 x i64] } zeroinitializer, ptr %t25
  %t26 = getelementptr { i64, [5 x i64] }, ptr %t25, i32 0, i32 0
  store i64 1, ptr %t26
  %t28 = insertvalue { i64 } undef, i64 %t24, 0
  %t29 = getelementptr { i64, [5 x i64] }, ptr %t25, i32 0, i32 1
  store { i64 } %t28, ptr %t29
  %t30 = load { i64, [5 x i64] }, ptr %t25
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2estop(ptr %v0, ptr %v0, ptr %t22, { i64, [5 x i64] } %t30)
  br label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/eval:Machine", ptr %t33, i32 0, i32 1
  %t36 = load i32, ptr %t35, !range !{i32 0, i32 2}
  %t38 = trunc i64 0 to i32
  %t39 = icmp eq i32 %t36, %t38
  br i1 %t39, label %bb13, label %bb14
bb13:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewalksLetGo(ptr %v0, ptr %t41)
  store i1 %t43, ptr %l35
  br label %bb15
bb14:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb16
bb15:
  %t44 = load i1, ptr %l35, !tbaa !21
  store i1 %t44, ptr %l33, !tbaa !21
  br label %bb16
bb16:
  %t45 = load i1, ptr %l33, !tbaa !21
  br i1 %t45, label %bb17, label %bb18
bb17:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyWalkLetGo, !tbaa !27
  %t48 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t48, ptr %t46, { i64, ptr } %t47)
  br label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb20
bb20:
  br label %bb90
bb21:
  %t51 = load i64, ptr %l2, !tbaa !24
  %t52 = load i64, ptr @G_2ecompiler_2feval_2erGlobal, !tbaa !24
  %t55 = icmp eq i64 %t51, %t52
  br i1 %t55, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb42
bb24:
  %t57 = getelementptr %"compiler/eval:frame", ptr %l1, i32 0, i32 12
  %t58 = load i1, ptr %t57, !tbaa !21
  br i1 %t58, label %bb25, label %bb26
bb25:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNoValue, !tbaa !27
  %t62 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t62, ptr %t60, { i64, ptr } %t61)
  br label %bb27
bb26:
  br label %bb28
bb27:
  br label %ret
bb28:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/eval:Machine", ptr %t65, i32 0, i32 1
  %t68 = load i32, ptr %t67, !range !{i32 0, i32 2}
  %t70 = trunc i64 0 to i32
  %t71 = icmp eq i32 %t68, %t70
  br i1 %t71, label %bb29, label %bb30
bb29:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewalksLetGo(ptr %v0, ptr %t73)
  store i1 %t75, ptr %l49
  br label %bb31
bb30:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb32
bb31:
  %t76 = load i1, ptr %l49, !tbaa !21
  store i1 %t76, ptr %l47, !tbaa !21
  br label %bb32
bb32:
  %t77 = load i1, ptr %l47, !tbaa !21
  br i1 %t77, label %bb33, label %bb34
bb33:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyWalkLetGo, !tbaa !27
  %t80 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t80, ptr %t78, { i64, ptr } %t79)
  br label %bb35
bb34:
  br label %bb36
bb35:
  br label %ret
bb36:
  %t83 = getelementptr %"compiler/eval:frame", ptr %l1, i32 0, i32 8
  %t84 = load i64, ptr %t83, !tbaa !24
  store i64 2, ptr %l4, !tbaa !24
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/eval:Machine", ptr %t86, i32 0, i32 43
  %t92 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2eRefMut_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %v0, ptr %t88, i64 %t84)
  store ptr %t92, ptr %l56
  br label %bb37
bb37:
  %t93 = load ptr, ptr %l56, !tbaa !29
  %t95 = load i64, ptr %l4, !tbaa !24
  %t98 = getelementptr %"compiler/eval:global", ptr %t93, i32 0, i32 4
  store i64 %t95, ptr %t98, !tbaa !24
  %t99 = getelementptr %"compiler/eval:frame", ptr %l1, i32 0, i32 8
  %t100 = load i64, ptr %t99, !tbaa !24
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/eval:Machine", ptr %t102, i32 0, i32 24
  %t105 = load i1, ptr %t104, !tbaa !21
  store i1 %t105, ptr %l7, !tbaa !21
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/eval:Machine", ptr %t107, i32 0, i32 43
  %t113 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2eRefMut_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %v0, ptr %t109, i64 %t100)
  store ptr %t113, ptr %l65
  br label %bb38
bb38:
  %t114 = load ptr, ptr %l65, !tbaa !29
  %t116 = load i1, ptr %l7, !tbaa !21
  %t119 = getelementptr %"compiler/eval:global", ptr %t114, i32 0, i32 6
  store i1 %t116, ptr %t119, !tbaa !21
  %t120 = load ptr, ptr %l0, !tbaa !29
  store ptr %t120, ptr %l68, !tbaa !29
  %t121 = load ptr, ptr %l68, !tbaa !29
  %t122 = getelementptr %"compiler/eval:Machine", ptr %t121, i32 0, i32 24
  %t123 = load i1, ptr %t122, !tbaa !21
  store i1 %t123, ptr %l69, !tbaa !21
  %t124 = getelementptr %"compiler/eval:frame", ptr %l1, i32 0, i32 15
  %t125 = load i1, ptr %t124, !tbaa !21
  br i1 %t125, label %bb39, label %bb40
bb39:
  store i1 true, ptr %l71, !tbaa !21
  br label %bb41
bb40:
  %t127 = load i1, ptr %l69, !tbaa !21
  store i1 %t127, ptr %l71, !tbaa !21
  br label %bb41
bb41:
  %t129 = load i1, ptr %l71, !tbaa !21
  %t130 = load ptr, ptr %l68, !tbaa !29
  %t131 = getelementptr %"compiler/eval:Machine", ptr %t130, i32 0, i32 24
  store i1 %t129, ptr %t131, !tbaa !21
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr %"compiler/eval:frame", ptr %l1, i32 0, i32 14
  %t134 = load i64, ptr %t133, !tbaa !24
  %t137 = getelementptr %"compiler/eval:Machine", ptr %t132, i32 0, i32 74
  store i64 %t134, ptr %t137, !tbaa !24
  br label %bb90
bb42:
  %t138 = load i64, ptr %l2, !tbaa !24
  %t139 = load i64, ptr @G_2ecompiler_2feval_2erTask, !tbaa !24
  %t142 = icmp eq i64 %t138, %t139
  br i1 %t142, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb80
bb45:
  %t144 = getelementptr %"compiler/eval:frame", ptr %l1, i32 0, i32 12
  %t145 = load i1, ptr %t144, !tbaa !21
  br i1 %t145, label %bb46, label %bb47
bb46:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"compiler/eval:frame", ptr %l1, i32 0, i32 8
  %t149 = load i64, ptr %t148, !tbaa !24
  %t152 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eendsProgram(ptr %v0, ptr %t147, i64 %t149)
  store i1 %t152, ptr %l82
  br label %bb48
bb47:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb49
bb48:
  %t153 = load i1, ptr %l82, !tbaa !21
  store i1 %t153, ptr %l79, !tbaa !21
  br label %bb49
bb49:
  %t154 = load i1, ptr %l79, !tbaa !21
  br i1 %t154, label %bb50, label %bb51
bb50:
  %t155 = load ptr, ptr %l0, !tbaa !29
  call void @llvm.memmove.p0.p0.i64(ptr %l84, ptr %l1, i64 136, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %t157, ptr %l84, i64 136, i1 false)
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2etaskEnded(ptr %v0, ptr %t155, ptr %t157)
  br label %bb52
bb51:
  br label %bb53
bb52:
  br label %ret
bb53:
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/eval:Machine", ptr %t158, i32 0, i32 89
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t160)
  br label %bb54
bb54:
  %t162 = load ptr, ptr %l0, !tbaa !29
  store ptr %t162, ptr %l87, !tbaa !29
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t165 = getelementptr %"compiler/eval:Machine", ptr %t163, i32 0, i32 92
  %t167 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t165)
  %t168 = extractvalue { i32, i64 } %t167, 1
  %t169 = extractvalue { i32, i64 } %t167, 0
  store i32 %t169, ptr %l92
  %t170 = icmp ne i32 %t169, 0
  br i1 %t170, label %bb56, label %ok.171, !prof !99
ok.171:
  store i64 %t168, ptr %l91
  br label %bb55
bb55:
  %t172 = load i64, ptr %l91, !tbaa !24
  store i64 %t172, ptr %l88, !tbaa !24
  br label %bb58
bb56:
  br label %bb57
bb57:
  store i64 0, ptr %l88, !tbaa !24
  br label %bb58
bb58:
  %t173 = load i64, ptr %l88, !tbaa !24
  %t174 = load ptr, ptr %l87, !tbaa !29
  %t175 = getelementptr %"compiler/eval:Machine", ptr %t174, i32 0, i32 91
  store i64 %t173, ptr %t175, !tbaa !24
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = getelementptr %"compiler/eval:Machine", ptr %t176, i32 0, i32 92
  %t180 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t178)
  %t181 = extractvalue { i32, i64 } %t180, 1
  %t182 = extractvalue { i32, i64 } %t180, 0
  store i32 %t182, ptr %l97
  %t183 = icmp ne i32 %t182, 0
  br i1 %t183, label %bb60, label %ok.184, !prof !99
ok.184:
  store i64 %t181, ptr %l96
  br label %bb59
bb59:
  %t185 = load i64, ptr %l96, !tbaa !24
  store i64 %t185, ptr %l93, !tbaa !24
  br label %bb62
bb60:
  br label %bb61
bb61:
  store i64 0, ptr %l93, !tbaa !24
  br label %bb62
bb62:
  %t186 = load i64, ptr %l93, !tbaa !24
  store i64 %t186, ptr %l9, !tbaa !24
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr %"compiler/eval:Machine", ptr %t187, i32 0, i32 92
  %t191 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t189)
  store i64 %t191, ptr %l100
  br label %bb63
bb63:
  %t192 = load i64, ptr %l9, !tbaa !24
  %t193 = load i64, ptr %l100, !tbaa !24
  %t195 = sub i64 %t193, %t192
  store i64 %t195, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  %t197 = load i64, ptr %l9, !tbaa !24
  store i64 %t197, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t199 = load i64, ptr %l12, !tbaa !24
  %t200 = load i64, ptr %l11, !tbaa !24
  %t203 = icmp sgt i64 %t199, %t200
  br i1 %t203, label %bb64, label %bb65
bb64:
  %t205 = load i64, ptr %l13, !tbaa !24
  %t207 = icmp sgt i64 %t205, 0
  br i1 %t207, label %bb66, label %bb67
bb65:
  store i64 0, ptr %l107, !tbaa !24
  br label %bb69
bb66:
  %t209 = load i64, ptr %l12, !tbaa !24
  %t210 = load i64, ptr %l11, !tbaa !24
  %t213 = sub i64 %t209, %t210
  %t214 = load i64, ptr %l13, !tbaa !24
  %t217 = add i64 %t213, %t214
  %t219 = sub i64 %t217, 1
  %t220 = load i64, ptr %l13, !tbaa !24
  %t223 = sdiv i64 %t219, %t220
  store i64 %t223, ptr %l110, !tbaa !24
  br label %bb68
bb67:
  store i64 0, ptr %l110, !tbaa !24
  br label %bb68
bb68:
  %t225 = load i64, ptr %l110, !tbaa !24
  store i64 %t225, ptr %l107, !tbaa !24
  br label %bb69
bb69:
  %t226 = load i64, ptr %l107, !tbaa !24
  store i64 %t226, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb70
bb70:
  %t227 = load i64, ptr %l15, !tbaa !24
  %t228 = load i64, ptr %l14, !tbaa !24
  %t231 = icmp slt i64 %t227, %t228
  %t233 = xor i1 %t231, true
  br i1 %t233, label %bb71, label %bb72
bb71:
  br label %bb77
bb72:
  br label %bb73
bb73:
  %t235 = load i64, ptr %l11, !tbaa !24
  %t236 = load i64, ptr %l15, !tbaa !24
  %t237 = load i64, ptr %l13, !tbaa !24
  %t240 = mul i64 %t236, %t237
  %t243 = add i64 %t235, %t240
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t247 = getelementptr %"compiler/eval:Machine", ptr %t245, i32 0, i32 89
  store ptr %t247, ptr %l129, !tbaa !29
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t250 = getelementptr %"compiler/eval:Machine", ptr %t248, i32 0, i32 92
  %t251 = load i64, ptr %l10, !tbaa !24
  %t255 = add i64 %t251, %t243
  %t258 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t250, i64 %t255)
  store i64 %t258, ptr %l135
  br label %bb74
bb74:
  %t259 = load ptr, ptr %l129, !tbaa !29
  %t260 = load i64, ptr %l135, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t259, i64 %t260)
  br label %bb75
bb75:
  br label %bb76
bb76:
  %t261 = load i64, ptr %l15, !tbaa !24
  %t264 = add i64 %t261, 1
  store i64 %t264, ptr %l15, !tbaa !24
  br label %bb70
bb77:
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t268 = getelementptr %"compiler/eval:Machine", ptr %t266, i32 0, i32 92
  %t269 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %t268, i64 %t269)
  br label %bb78
bb78:
  %t272 = load ptr, ptr %l0, !tbaa !29
  call void @llvm.memmove.p0.p0.i64(ptr %l143, ptr %l1, i64 136, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %t274, ptr %l143, i64 136, i1 false)
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2etaskEnded(ptr %v0, ptr %t272, ptr %t274)
  br label %bb79
bb79:
  br label %bb90
bb80:
  %t275 = load i64, ptr %l2, !tbaa !24
  %t276 = load i64, ptr @G_2ecompiler_2feval_2erClause, !tbaa !24
  %t279 = icmp eq i64 %t275, %t276
  br i1 %t279, label %bb81, label %bb82
bb81:
  br label %bb83
bb82:
  br label %bb85
bb83:
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t282 = getelementptr %"compiler/eval:frame", ptr %l1, i32 0, i32 8
  %t283 = load i64, ptr %t282, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2efreeTask(ptr %v0, ptr %t281, i64 %t283)
  br label %bb84
bb84:
  br label %bb90
bb85:
  br i1 true, label %bb86, label %bb87
bb86:
  br label %bb88
bb87:
  br label %bb89
bb88:
  br label %bb90
bb89:
  call void @__olang_check_failed(ptr @olang_loc_cf5f350672f7c138_c751ad896f9a9f0c)
  unreachable
bb90:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2espawn(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca %"compiler/mir:Task"
  %l6 = alloca i64
  %l7 = alloca { { i64, ptr }, i64 }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca %"compiler/eval:Ptr"
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i32
  %l20 = alloca { i64, [4 x i64] }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca { %"compiler/eval:Ptr", i32 }
  %l29 = alloca %"compiler/eval:Ptr"
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca { i64, [4 x i64] }
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca { i64, [7 x i64] }
  %l44 = alloca { i64, [4 x i64] }
  %l45 = alloca i32
  %l46 = alloca i32
  %l47 = alloca i32
  %l48 = alloca i32
  %l49 = alloca i32
  %l50 = alloca i32
  %l51 = alloca { i64, [1 x i64] }
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca %"compiler/eval:task"
  %l59 = alloca i64
  %l68 = alloca ptr
  %l73 = alloca %"compiler/mir:Task"
  %l75 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l86 = alloca i1
  %l92 = alloca %"compiler/mir:Task"
  %l94 = alloca { { i64, ptr }, i64 }
  %l121 = alloca %"compiler/eval:Ptr"
  %l128 = alloca i32
  %l131 = alloca i32
  %l156 = alloca { i64, [4 x i64] }
  %l157 = alloca ptr
  %l158 = alloca i64
  %l162 = alloca %"compiler/eval:Ptr"
  %l166 = alloca i32
  %l176 = alloca i64
  %l179 = alloca i64
  %l197 = alloca ptr
  %l198 = alloca i64
  %l205 = alloca %"compiler/mir:Lvalue"
  %l206 = alloca { %"compiler/eval:Ptr", i32 }
  %l208 = alloca ptr
  %l214 = alloca %"compiler/eval:Ptr"
  %l228 = alloca i64
  %l231 = alloca i64
  %l255 = alloca %"compiler/mir:TaskClause"
  %l260 = alloca ptr
  %l261 = alloca i64
  %l267 = alloca %"compiler/eval:Ptr"
  %l271 = alloca i32
  %l285 = alloca i64
  %l288 = alloca i64
  %l306 = alloca ptr
  %l312 = alloca %"compiler/eval:Ptr"
  %l313 = alloca ptr
  %l314 = alloca i64
  %l321 = alloca { i64, [1 x i64] }
  %l322 = alloca i64
  %l335 = alloca ptr
  %l336 = alloca i64
  %l339 = alloca %"compiler/eval:Ptr"
  %l343 = alloca i32
  %l352 = alloca i32
  %l355 = alloca i32
  %l380 = alloca { i64, [1 x i64] }
  %l387 = alloca i64
  %l388 = alloca ptr
  %l395 = alloca %"compiler/eval:Ptr"
  %l400 = alloca ptr
  %l406 = alloca %"compiler/eval:Ptr"
  %l409 = alloca i64
  %l410 = alloca ptr
  %l411 = alloca i64
  %l416 = alloca { i64, [1 x i64] }
  %l417 = alloca i64
  %l418 = alloca i64
  %l421 = alloca i64
  %l422 = alloca i32
  %l424 = alloca i64
  %l425 = alloca %"compiler/eval:task"
  %l427 = alloca { i64, ptr }
  %l447 = alloca %"compiler/eval:scope"
  %l453 = alloca %"compiler/eval:scope"
  %l458 = alloca ptr
  %l465 = alloca ptr
  %l472 = alloca ptr
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %t13 = alloca %"compiler/mir:Task", align 8
  %t61 = alloca %"compiler/mir:Task", align 8
  %t802 = alloca %"compiler/eval:scope", align 8
  %t814 = alloca %"compiler/eval:scope", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call ptr @compiler_2feval_2ecompiler_2feval_3aMachine_2efnOfFrame(ptr %v0, ptr %v0, ptr %t1, i64 %t2)
  store ptr %t5, ptr %l68
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l68, !tbaa !29
  store ptr %t6, ptr %l4, !tbaa !29
  %t7 = load ptr, ptr %l4, !tbaa !29
  %t9 = getelementptr %"compiler/mir:Fn", ptr %t7, i32 0, i32 16
  %t10 = load i32, ptr %l3, !tbaa !23
  %t12 = sext i32 %t10 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e_2eAt_3ccompiler_2fmir_3aTask_3e(ptr %t13, ptr %v0, ptr %t9, i64 %t12)
  call void @llvm.memmove.p0.p0.i64(ptr %l73, ptr %t13, i64 144, i1 false)
  br label %bb2
bb2:
  call void @llvm.memmove.p0.p0.i64(ptr %l5, ptr %l73, i64 144, i1 false)
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/eval:Machine", ptr %t16, i32 0, i32 61
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !27
  store { i64, ptr } %t19, ptr %l75, !tbaa !27
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/eval:Machine", ptr %t20, i32 0, i32 59
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  store { i64, ptr } %t23, ptr %l77, !tbaa !27
  %t24 = load i64, ptr %l1, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr %"compiler/eval:frame", ptr %t27, i64 %t24
  %t29 = getelementptr %"compiler/eval:frame", ptr %t28, i32 0, i32 4
  %t30 = load i64, ptr %t29, !tbaa !24
  %t33 = sext i32 %a2 to i64
  %t36 = add i64 %t30, %t33
  %t38 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr i64, ptr %t39, i64 %t36
  %t41 = load i64, ptr %t40, !tbaa !34
  store i64 %t41, ptr %l6, !tbaa !24
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load i64, ptr %l6, !tbaa !24
  %t47 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2elive(ptr %v0, ptr %t43, i64 %t44)
  store i1 %t47, ptr %l86
  br label %bb3
bb3:
  %t48 = load i1, ptr %l86, !tbaa !21
  %t49 = xor i1 %t48, true
  br i1 %t49, label %bb4, label %bb5
bb4:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyClosed, !tbaa !27
  %t53 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t53, ptr %t51, { i64, ptr } %t52)
  br label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb7:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load ptr, ptr %l4, !tbaa !29
  call void @llvm.memmove.p0.p0.i64(ptr %l92, ptr %l5, i64 144, i1 false)
  %t58 = load i64, ptr %l1, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %t61, ptr %l92, i64 144, i1 false)
  %t63 = call { { i64, ptr }, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2etaskLayout(ptr %v0, ptr %v0, ptr %s0, ptr %t56, ptr %t57, ptr %t61, i64 %t58)
  store { { i64, ptr }, i64 } %t63, ptr %l94
  br label %bb8
bb8:
  %t64 = load { { i64, ptr }, i64 }, ptr %l94
  store { { i64, ptr }, i64 } %t64, ptr %l7
  %t65 = getelementptr { { i64, ptr }, i64 }, ptr %l7, i32 0, i32 0
  %t66 = load { i64, ptr }, ptr %t65, !tbaa !27
  store { i64, ptr } %t66, ptr %l8, !tbaa !27
  %t68 = getelementptr { { i64, ptr }, i64 }, ptr %l7, i32 0, i32 1
  %t69 = load i64, ptr %t68, !tbaa !24
  store i64 %t69, ptr %l9, !tbaa !24
  %t71 = getelementptr %"compiler/mir:Task", ptr %l5, i32 0, i32 3
  %t72 = getelementptr %"compiler/mir:Range", ptr %t71, i32 0, i32 1
  %t73 = load i32, ptr %t72, !tbaa !23
  %t75 = sext i32 %t73 to i64
  store i64 %t75, ptr %l10, !tbaa !24
  %t77 = getelementptr %"compiler/mir:Task", ptr %l5, i32 0, i32 4
  %t78 = getelementptr %"compiler/mir:Range", ptr %t77, i32 0, i32 1
  %t79 = load i32, ptr %t78, !tbaa !23
  %t81 = sext i32 %t79 to i64
  store i64 %t81, ptr %l11, !tbaa !24
  %t83 = getelementptr %"compiler/mir:Task", ptr %l5, i32 0, i32 2
  %t84 = getelementptr %"compiler/mir:Range", ptr %t83, i32 0, i32 1
  %t85 = load i32, ptr %t84, !tbaa !23
  %t87 = sext i32 %t85 to i64
  store i64 %t87, ptr %l12, !tbaa !24
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load i64, ptr %l9, !tbaa !24
  %t91 = load i64, ptr %l10, !tbaa !24
  %t93 = mul i64 8, %t91
  %t96 = add i64 %t90, %t93
  %t97 = load i64, ptr %l11, !tbaa !24
  %t99 = mul i64 16, %t97
  %t102 = add i64 %t96, %t99
  %t103 = load i64, ptr %l12, !tbaa !24
  %t105 = mul i64 8, %t103
  %t108 = add i64 %t102, %t105
  %t110 = add i64 %t108, 16
  %t111 = load i64, ptr %l10, !tbaa !24
  %t113 = mul i64 8, %t111
  %t116 = add i64 %t110, %t113
  %t118 = add i64 %t116, 8
  %t119 = load i64, ptr @G_2ecompiler_2feval_2eaValue, !tbaa !24
  %t120 = load i64, ptr %l6, !tbaa !24
  %t125 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eallocate(ptr %v0, ptr %t89, i64 %t118, i64 %t119, i64 %t120)
  store %"compiler/eval:Ptr" %t125, ptr %l121
  br label %bb9
bb9:
  %t126 = load %"compiler/eval:Ptr", ptr %l121
  store %"compiler/eval:Ptr" %t126, ptr %l13
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/eval:Machine", ptr %t127, i32 0, i32 23
  %t130 = load i1, ptr %t129, !tbaa !21
  br i1 %t130, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb11:
  br label %bb12
bb12:
  store i32 0, ptr %l14, !tbaa !23
  %t132 = getelementptr %"compiler/mir:Task", ptr %l5, i32 0, i32 1
  %t133 = getelementptr %"compiler/mir:Range", ptr %t132, i32 0, i32 1
  %t134 = load i32, ptr %t133, !tbaa !23
  store i32 %t134, ptr %l15, !tbaa !23
  store i32 1, ptr %l16, !tbaa !23
  %t136 = load i32, ptr %l15, !tbaa !23
  %t137 = load i32, ptr %l14, !tbaa !23
  %t140 = icmp sgt i32 %t136, %t137
  br i1 %t140, label %bb13, label %bb14
bb13:
  %t142 = load i32, ptr %l16, !tbaa !23
  %t144 = icmp sgt i32 %t142, 0
  br i1 %t144, label %bb15, label %bb16
bb14:
  store i32 0, ptr %l128, !tbaa !23
  br label %bb18
bb15:
  %t146 = load i32, ptr %l15, !tbaa !23
  %t147 = load i32, ptr %l14, !tbaa !23
  %t150 = sub i32 %t146, %t147
  %t151 = load i32, ptr %l16, !tbaa !23
  %t154 = add i32 %t150, %t151
  %t156 = sub i32 %t154, 1
  %t157 = load i32, ptr %l16, !tbaa !23
  %t160 = sdiv i32 %t156, %t157
  store i32 %t160, ptr %l131, !tbaa !23
  br label %bb17
bb16:
  store i32 0, ptr %l131, !tbaa !23
  br label %bb17
bb17:
  %t162 = load i32, ptr %l131, !tbaa !23
  store i32 %t162, ptr %l128, !tbaa !23
  br label %bb18
bb18:
  %t163 = load i32, ptr %l128, !tbaa !23
  store i32 %t163, ptr %l17, !tbaa !23
  store i32 0, ptr %l18, !tbaa !23
  br label %bb19
bb19:
  store %olang.scope zeroinitializer, ptr %s4
  %t164 = load i32, ptr %l18, !tbaa !23
  %t165 = load i32, ptr %l17, !tbaa !23
  %t168 = icmp slt i32 %t164, %t165
  %t170 = xor i1 %t168, true
  br i1 %t170, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s4)
  br label %bb28
bb21:
  br label %bb22
bb22:
  %t172 = load i32, ptr %l14, !tbaa !23
  %t173 = load i32, ptr %l18, !tbaa !23
  %t174 = load i32, ptr %l16, !tbaa !23
  %t177 = mul i32 %t173, %t174
  %t180 = add i32 %t172, %t177
  store i32 %t180, ptr %l19, !tbaa !23
  %t182 = load ptr, ptr %l4, !tbaa !29
  %t184 = getelementptr %"compiler/mir:Fn", ptr %t182, i32 0, i32 11
  %t185 = getelementptr %"compiler/mir:Task", ptr %l5, i32 0, i32 1
  %t186 = getelementptr %"compiler/mir:Range", ptr %t185, i32 0, i32 0
  %t187 = load i32, ptr %t186, !tbaa !23
  %t189 = sext i32 %t187 to i64
  %t190 = load i32, ptr %l19, !tbaa !23
  %t192 = sext i32 %t190 to i64
  %t195 = add i64 %t189, %t192
  %t198 = call { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %t184, i64 %t195)
  store { i64, [4 x i64] } %t198, ptr %l156
  br label %bb23
bb23:
  %t199 = load { i64, [4 x i64] }, ptr %l156
  store { i64, [4 x i64] } %t199, ptr %l20
  %t200 = load ptr, ptr %l0, !tbaa !29
  store ptr %t200, ptr %l157, !tbaa !29
  %t201 = load i64, ptr %l1, !tbaa !24
  store i64 %t201, ptr %l158, !tbaa !24
  %t202 = getelementptr %"compiler/eval:Ptr", ptr %l13, i32 0, i32 0
  %t203 = load i64, ptr %t202, !tbaa !24
  %t204 = load i32, ptr %l19, !tbaa !23
  %t206 = sext i32 %t204 to i64
  %t207 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !27
  %t209 = getelementptr i64, ptr %t208, i64 %t206
  %t210 = load i64, ptr %t209, !tbaa !34
  %t213 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s4, i64 %t203, i64 %t210)
  store %"compiler/eval:Ptr" %t213, ptr %l162
  br label %bb24
bb24:
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t215 = load i64, ptr %l1, !tbaa !24
  %t216 = load { i64, [4 x i64] }, ptr %l20
  %t220 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eopType(ptr %v0, ptr %t214, i64 %t215, { i64, [4 x i64] } %t216)
  store i32 %t220, ptr %l166
  br label %bb25
bb25:
  %t221 = load { i64, [4 x i64] }, ptr %l20
  %t222 = load ptr, ptr %l157, !tbaa !29
  %t223 = load i64, ptr %l158, !tbaa !24
  %t224 = load %"compiler/eval:Ptr", ptr %l162
  %t225 = load i32, ptr %l166, !tbaa !23
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eput(ptr %v0, ptr %t222, i64 %t223, %"compiler/eval:Ptr" %t224, i32 %t225, { i64, [4 x i64] } %t221)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s4)
  br label %bb27
bb27:
  %t227 = load i32, ptr %l18, !tbaa !23
  %t230 = add i32 %t227, 1
  store i32 %t230, ptr %l18, !tbaa !23
  br label %bb19
bb28:
  %t232 = load i64, ptr %l9, !tbaa !24
  store i64 %t232, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  %t234 = load i64, ptr %l10, !tbaa !24
  store i64 %t234, ptr %l23, !tbaa !24
  store i64 1, ptr %l24, !tbaa !24
  %t236 = load i64, ptr %l23, !tbaa !24
  %t237 = load i64, ptr %l22, !tbaa !24
  %t240 = icmp sgt i64 %t236, %t237
  br i1 %t240, label %bb29, label %bb30
bb29:
  %t242 = load i64, ptr %l24, !tbaa !24
  %t244 = icmp sgt i64 %t242, 0
  br i1 %t244, label %bb31, label %bb32
bb30:
  store i64 0, ptr %l176, !tbaa !24
  br label %bb34
bb31:
  %t246 = load i64, ptr %l23, !tbaa !24
  %t247 = load i64, ptr %l22, !tbaa !24
  %t250 = sub i64 %t246, %t247
  %t251 = load i64, ptr %l24, !tbaa !24
  %t254 = add i64 %t250, %t251
  %t256 = sub i64 %t254, 1
  %t257 = load i64, ptr %l24, !tbaa !24
  %t260 = sdiv i64 %t256, %t257
  store i64 %t260, ptr %l179, !tbaa !24
  br label %bb33
bb32:
  store i64 0, ptr %l179, !tbaa !24
  br label %bb33
bb33:
  %t262 = load i64, ptr %l179, !tbaa !24
  store i64 %t262, ptr %l176, !tbaa !24
  br label %bb34
bb34:
  %t263 = load i64, ptr %l176, !tbaa !24
  store i64 %t263, ptr %l25, !tbaa !24
  store i64 0, ptr %l26, !tbaa !24
  br label %bb35
bb35:
  store %olang.scope zeroinitializer, ptr %s7
  %t264 = load i64, ptr %l26, !tbaa !24
  %t265 = load i64, ptr %l25, !tbaa !24
  %t268 = icmp slt i64 %t264, %t265
  %t270 = xor i1 %t268, true
  br i1 %t270, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s7)
  br label %bb44
bb37:
  br label %bb38
bb38:
  %t272 = load i64, ptr %l22, !tbaa !24
  %t273 = load i64, ptr %l26, !tbaa !24
  %t274 = load i64, ptr %l24, !tbaa !24
  %t277 = mul i64 %t273, %t274
  %t280 = add i64 %t272, %t277
  store i64 %t280, ptr %l27, !tbaa !24
  %t282 = load ptr, ptr %l0, !tbaa !29
  store ptr %t282, ptr %l197, !tbaa !29
  %t283 = load i64, ptr %l1, !tbaa !24
  store i64 %t283, ptr %l198, !tbaa !24
  %t284 = load ptr, ptr %l4, !tbaa !29
  %t286 = getelementptr %"compiler/mir:Fn", ptr %t284, i32 0, i32 13
  %t287 = getelementptr %"compiler/mir:Task", ptr %l5, i32 0, i32 3
  %t288 = getelementptr %"compiler/mir:Range", ptr %t287, i32 0, i32 0
  %t289 = load i32, ptr %t288, !tbaa !23
  %t291 = sext i32 %t289 to i64
  %t292 = load i64, ptr %l27, !tbaa !24
  %t295 = add i64 %t291, %t292
  %t298 = call %"compiler/mir:Lvalue" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLvalue_3e_2eAt_3ccompiler_2fmir_3aLvalue_3e(ptr %v0, ptr %t286, i64 %t295)
  store %"compiler/mir:Lvalue" %t298, ptr %l205
  br label %bb39
bb39:
  %t299 = load ptr, ptr %l197, !tbaa !29
  %t300 = load i64, ptr %l198, !tbaa !24
  %t301 = load %"compiler/mir:Lvalue", ptr %l205
  %t302 = call { %"compiler/eval:Ptr", i32 } @compiler_2feval_2ecompiler_2feval_3aMachine_2eplace(ptr %v0, ptr %t299, i64 %t300, %"compiler/mir:Lvalue" %t301)
  store { %"compiler/eval:Ptr", i32 } %t302, ptr %l206
  br label %bb40
bb40:
  %t303 = load { %"compiler/eval:Ptr", i32 }, ptr %l206
  store { %"compiler/eval:Ptr", i32 } %t303, ptr %l28
  %t304 = getelementptr { %"compiler/eval:Ptr", i32 }, ptr %l28, i32 0, i32 0
  %t305 = load %"compiler/eval:Ptr", ptr %t304
  store %"compiler/eval:Ptr" %t305, ptr %l29
  %t307 = load ptr, ptr %l0, !tbaa !29
  store ptr %t307, ptr %l208, !tbaa !29
  %t308 = getelementptr %"compiler/eval:Ptr", ptr %l13, i32 0, i32 0
  %t309 = load i64, ptr %t308, !tbaa !24
  %t310 = load i64, ptr %l21, !tbaa !24
  %t311 = load i64, ptr %l27, !tbaa !24
  %t313 = mul i64 8, %t311
  %t316 = add i64 %t310, %t313
  %t319 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s7, i64 %t309, i64 %t316)
  store %"compiler/eval:Ptr" %t319, ptr %l214
  br label %bb41
bb41:
  %t320 = load %"compiler/eval:Ptr", ptr %l29
  %t321 = load ptr, ptr %l208, !tbaa !29
  %t322 = load %"compiler/eval:Ptr", ptr %l214
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrPtr(ptr %v0, ptr %t321, %"compiler/eval:Ptr" %t322, %"compiler/eval:Ptr" %t320)
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s7)
  br label %bb43
bb43:
  %t324 = load i64, ptr %l26, !tbaa !24
  %t327 = add i64 %t324, 1
  store i64 %t327, ptr %l26, !tbaa !24
  br label %bb35
bb44:
  %t329 = load i64, ptr %l21, !tbaa !24
  %t331 = load i64, ptr %l10, !tbaa !24
  %t333 = mul i64 8, %t331
  %t336 = add i64 %t329, %t333
  store i64 %t336, ptr %l21, !tbaa !24
  store i64 0, ptr %l30, !tbaa !24
  %t338 = load i64, ptr %l11, !tbaa !24
  store i64 %t338, ptr %l31, !tbaa !24
  store i64 1, ptr %l32, !tbaa !24
  %t340 = load i64, ptr %l31, !tbaa !24
  %t341 = load i64, ptr %l30, !tbaa !24
  %t344 = icmp sgt i64 %t340, %t341
  br i1 %t344, label %bb45, label %bb46
bb45:
  %t346 = load i64, ptr %l32, !tbaa !24
  %t348 = icmp sgt i64 %t346, 0
  br i1 %t348, label %bb47, label %bb48
bb46:
  store i64 0, ptr %l228, !tbaa !24
  br label %bb50
bb47:
  %t350 = load i64, ptr %l31, !tbaa !24
  %t351 = load i64, ptr %l30, !tbaa !24
  %t354 = sub i64 %t350, %t351
  %t355 = load i64, ptr %l32, !tbaa !24
  %t358 = add i64 %t354, %t355
  %t360 = sub i64 %t358, 1
  %t361 = load i64, ptr %l32, !tbaa !24
  %t364 = sdiv i64 %t360, %t361
  store i64 %t364, ptr %l231, !tbaa !24
  br label %bb49
bb48:
  store i64 0, ptr %l231, !tbaa !24
  br label %bb49
bb49:
  %t366 = load i64, ptr %l231, !tbaa !24
  store i64 %t366, ptr %l228, !tbaa !24
  br label %bb50
bb50:
  %t367 = load i64, ptr %l228, !tbaa !24
  store i64 %t367, ptr %l33, !tbaa !24
  store i64 0, ptr %l34, !tbaa !24
  br label %bb51
bb51:
  %t368 = load i64, ptr %l34, !tbaa !24
  %t369 = load i64, ptr %l33, !tbaa !24
  %t372 = icmp slt i64 %t368, %t369
  %t374 = xor i1 %t372, true
  br i1 %t374, label %bb52, label %bb53
bb52:
  br label %bb63
bb53:
  br label %bb54
bb54:
  %t376 = load i64, ptr %l30, !tbaa !24
  %t377 = load i64, ptr %l34, !tbaa !24
  %t378 = load i64, ptr %l32, !tbaa !24
  %t381 = mul i64 %t377, %t378
  %t384 = add i64 %t376, %t381
  store i64 %t384, ptr %l35, !tbaa !24
  %t386 = load ptr, ptr %l4, !tbaa !29
  %t388 = getelementptr %"compiler/mir:Fn", ptr %t386, i32 0, i32 17
  %t389 = getelementptr %"compiler/mir:Task", ptr %l5, i32 0, i32 4
  %t390 = getelementptr %"compiler/mir:Range", ptr %t389, i32 0, i32 0
  %t391 = load i32, ptr %t390, !tbaa !23
  %t393 = sext i32 %t391 to i64
  %t394 = load i64, ptr %l35, !tbaa !24
  %t397 = add i64 %t393, %t394
  %t400 = call %"compiler/mir:TaskClause" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTaskClause_3e_2eAt_3ccompiler_2fmir_3aTaskClause_3e(ptr %v0, ptr %t388, i64 %t397)
  store %"compiler/mir:TaskClause" %t400, ptr %l255
  br label %bb55
bb55:
  %t401 = getelementptr %"compiler/mir:TaskClause", ptr %l255, i32 0, i32 2
  %t402 = load { i64, [4 x i64] }, ptr %t401
  store { i64, [4 x i64] } %t402, ptr %l36
  %t404 = load { i64, [4 x i64] }, ptr %l36
  %t406 = extractvalue { i64, [4 x i64] } %t404, 0
  %t407 = icmp eq i64 %t406, 0
  %t409 = xor i1 %t407, true
  br i1 %t409, label %bb56, label %bb57
bb56:
  store %olang.scope zeroinitializer, ptr %s11
  %t411 = load ptr, ptr %l0, !tbaa !29
  store ptr %t411, ptr %l260, !tbaa !29
  %t412 = load i64, ptr %l1, !tbaa !24
  store i64 %t412, ptr %l261, !tbaa !24
  %t413 = getelementptr %"compiler/eval:Ptr", ptr %l13, i32 0, i32 0
  %t414 = load i64, ptr %t413, !tbaa !24
  %t415 = load i64, ptr %l21, !tbaa !24
  %t416 = load i64, ptr %l35, !tbaa !24
  %t418 = mul i64 16, %t416
  %t421 = add i64 %t415, %t418
  %t424 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s11, i64 %t414, i64 %t421)
  store %"compiler/eval:Ptr" %t424, ptr %l267
  br label %bb58
bb57:
  br label %bb61
bb58:
  %t425 = load ptr, ptr %l0, !tbaa !29
  %t426 = load i64, ptr %l1, !tbaa !24
  %t427 = load { i64, [4 x i64] }, ptr %l36
  %t431 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eopType(ptr %v0, ptr %t425, i64 %t426, { i64, [4 x i64] } %t427)
  store i32 %t431, ptr %l271
  br label %bb59
bb59:
  %t432 = load { i64, [4 x i64] }, ptr %l36
  %t433 = load ptr, ptr %l260, !tbaa !29
  %t434 = load i64, ptr %l261, !tbaa !24
  %t435 = load %"compiler/eval:Ptr", ptr %l267
  %t436 = load i32, ptr %l271, !tbaa !23
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eput(ptr %v0, ptr %t433, i64 %t434, %"compiler/eval:Ptr" %t435, i32 %t436, { i64, [4 x i64] } %t432)
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s11)
  br label %bb61
bb61:
  br label %bb62
bb62:
  %t438 = load i64, ptr %l34, !tbaa !24
  %t441 = add i64 %t438, 1
  store i64 %t441, ptr %l34, !tbaa !24
  br label %bb51
bb63:
  %t443 = load i64, ptr %l21, !tbaa !24
  %t445 = load i64, ptr %l11, !tbaa !24
  %t447 = mul i64 16, %t445
  %t450 = add i64 %t443, %t447
  store i64 %t450, ptr %l21, !tbaa !24
  store i64 0, ptr %l37, !tbaa !24
  %t452 = load i64, ptr %l12, !tbaa !24
  store i64 %t452, ptr %l38, !tbaa !24
  store i64 1, ptr %l39, !tbaa !24
  %t454 = load i64, ptr %l38, !tbaa !24
  %t455 = load i64, ptr %l37, !tbaa !24
  %t458 = icmp sgt i64 %t454, %t455
  br i1 %t458, label %bb64, label %bb65
bb64:
  %t460 = load i64, ptr %l39, !tbaa !24
  %t462 = icmp sgt i64 %t460, 0
  br i1 %t462, label %bb66, label %bb67
bb65:
  store i64 0, ptr %l285, !tbaa !24
  br label %bb69
bb66:
  %t464 = load i64, ptr %l38, !tbaa !24
  %t465 = load i64, ptr %l37, !tbaa !24
  %t468 = sub i64 %t464, %t465
  %t469 = load i64, ptr %l39, !tbaa !24
  %t472 = add i64 %t468, %t469
  %t474 = sub i64 %t472, 1
  %t475 = load i64, ptr %l39, !tbaa !24
  %t478 = sdiv i64 %t474, %t475
  store i64 %t478, ptr %l288, !tbaa !24
  br label %bb68
bb67:
  store i64 0, ptr %l288, !tbaa !24
  br label %bb68
bb68:
  %t480 = load i64, ptr %l288, !tbaa !24
  store i64 %t480, ptr %l285, !tbaa !24
  br label %bb69
bb69:
  %t481 = load i64, ptr %l285, !tbaa !24
  store i64 %t481, ptr %l40, !tbaa !24
  store i64 0, ptr %l41, !tbaa !24
  br label %bb70
bb70:
  store %olang.scope zeroinitializer, ptr %s14
  %t482 = load i64, ptr %l41, !tbaa !24
  %t483 = load i64, ptr %l40, !tbaa !24
  %t486 = icmp slt i64 %t482, %t483
  %t488 = xor i1 %t486, true
  br i1 %t488, label %bb71, label %bb72
bb71:
  call void @__olang_scope_close(ptr %s14)
  br label %bb79
bb72:
  br label %bb73
bb73:
  %t490 = load i64, ptr %l37, !tbaa !24
  %t491 = load i64, ptr %l41, !tbaa !24
  %t492 = load i64, ptr %l39, !tbaa !24
  %t495 = mul i64 %t491, %t492
  %t498 = add i64 %t490, %t495
  store i64 %t498, ptr %l42, !tbaa !24
  %t500 = load ptr, ptr %l0, !tbaa !29
  store ptr %t500, ptr %l306, !tbaa !29
  %t501 = getelementptr %"compiler/eval:Ptr", ptr %l13, i32 0, i32 0
  %t502 = load i64, ptr %t501, !tbaa !24
  %t503 = load i64, ptr %l21, !tbaa !24
  %t504 = load i64, ptr %l42, !tbaa !24
  %t506 = mul i64 8, %t504
  %t509 = add i64 %t503, %t506
  %t512 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s14, i64 %t502, i64 %t509)
  store %"compiler/eval:Ptr" %t512, ptr %l312
  br label %bb74
bb74:
  %t513 = load ptr, ptr %l0, !tbaa !29
  store ptr %t513, ptr %l313, !tbaa !29
  %t514 = load i64, ptr %l1, !tbaa !24
  store i64 %t514, ptr %l314, !tbaa !24
  %t515 = load ptr, ptr %l4, !tbaa !29
  %t517 = getelementptr %"compiler/mir:Fn", ptr %t515, i32 0, i32 12
  %t518 = getelementptr %"compiler/mir:Task", ptr %l5, i32 0, i32 2
  %t519 = getelementptr %"compiler/mir:Range", ptr %t518, i32 0, i32 0
  %t520 = load i32, ptr %t519, !tbaa !23
  %t522 = sext i32 %t520 to i64
  %t523 = load i64, ptr %l42, !tbaa !24
  %t526 = add i64 %t522, %t523
  %t529 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %t517, i64 %t526)
  store { i64, [1 x i64] } %t529, ptr %l321
  br label %bb75
bb75:
  %t530 = load ptr, ptr %l313, !tbaa !29
  %t531 = load i64, ptr %l314, !tbaa !24
  %t532 = load { i64, [1 x i64] }, ptr %l321
  %t533 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escopeOf(ptr %v0, ptr %t530, i64 %t531, { i64, [1 x i64] } %t532)
  store i64 %t533, ptr %l322
  br label %bb76
bb76:
  %t534 = load ptr, ptr %l306, !tbaa !29
  %t535 = load %"compiler/eval:Ptr", ptr %l312
  %t536 = load i64, ptr %l322, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t534, %"compiler/eval:Ptr" %t535, i64 8, i64 %t536)
  br label %bb77
bb77:
  call void @__olang_scope_close(ptr %s14)
  br label %bb78
bb78:
  %t537 = load i64, ptr %l41, !tbaa !24
  %t540 = add i64 %t537, 1
  store i64 %t540, ptr %l41, !tbaa !24
  br label %bb70
bb79:
  %t542 = load i64, ptr %l21, !tbaa !24
  %t544 = load i64, ptr %l12, !tbaa !24
  %t546 = mul i64 8, %t544
  %t549 = add i64 %t542, %t546
  store i64 %t549, ptr %l21, !tbaa !24
  %t551 = getelementptr %"compiler/mir:Task", ptr %l5, i32 0, i32 0
  %t552 = load { i64, [7 x i64] }, ptr %t551
  store { i64, [7 x i64] } %t552, ptr %l43
  %t554 = load { i64, [7 x i64] }, ptr %l43
  %t556 = extractvalue { i64, [7 x i64] } %t554, 0
  %t557 = icmp eq i64 %t556, 2
  br i1 %t557, label %bb80, label %bb81
bb80:
  %t559 = getelementptr { i64, [7 x i64] }, ptr %l43, i32 0, i32 1
  %t560 = getelementptr { { i64, [4 x i64] } }, ptr %t559, i32 0, i32 0
  %t561 = load { i64, [4 x i64] }, ptr %t560
  store { i64, [4 x i64] } %t561, ptr %l44
  br label %bb82
bb81:
  br label %bb86
bb82:
  store %olang.scope zeroinitializer, ptr %s16
  %t563 = load ptr, ptr %l0, !tbaa !29
  store ptr %t563, ptr %l335, !tbaa !29
  %t564 = load i64, ptr %l1, !tbaa !24
  store i64 %t564, ptr %l336, !tbaa !24
  %t565 = getelementptr %"compiler/eval:Ptr", ptr %l13, i32 0, i32 0
  %t566 = load i64, ptr %t565, !tbaa !24
  %t567 = load i64, ptr %l21, !tbaa !24
  %t570 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s16, i64 %t566, i64 %t567)
  store %"compiler/eval:Ptr" %t570, ptr %l339
  br label %bb83
bb83:
  %t571 = load ptr, ptr %l0, !tbaa !29
  %t572 = load i64, ptr %l1, !tbaa !24
  %t573 = load { i64, [4 x i64] }, ptr %l44
  %t577 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eopType(ptr %v0, ptr %t571, i64 %t572, { i64, [4 x i64] } %t573)
  store i32 %t577, ptr %l343
  br label %bb84
bb84:
  %t578 = load { i64, [4 x i64] }, ptr %l44
  %t579 = load ptr, ptr %l335, !tbaa !29
  %t580 = load i64, ptr %l336, !tbaa !24
  %t581 = load %"compiler/eval:Ptr", ptr %l339
  %t582 = load i32, ptr %l343, !tbaa !23
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eput(ptr %v0, ptr %t579, i64 %t580, %"compiler/eval:Ptr" %t581, i32 %t582, { i64, [4 x i64] } %t578)
  br label %bb85
bb85:
  call void @__olang_scope_close(ptr %s16)
  br label %bb91
bb86:
  br i1 true, label %bb87, label %bb88
bb87:
  br label %bb89
bb88:
  br label %bb90
bb89:
  br label %bb91
bb90:
  call void @__olang_check_failed(ptr @olang_loc_c730e5cddf41927a_cc9c5d5e6e4d10a6)
  unreachable
bb91:
  %t584 = load i64, ptr %l21, !tbaa !24
  %t587 = add i64 %t584, 16
  store i64 %t587, ptr %l21, !tbaa !24
  store i32 0, ptr %l45, !tbaa !23
  %t589 = getelementptr %"compiler/mir:Task", ptr %l5, i32 0, i32 7
  %t590 = getelementptr %"compiler/mir:Range", ptr %t589, i32 0, i32 1
  %t591 = load i32, ptr %t590, !tbaa !23
  store i32 %t591, ptr %l46, !tbaa !23
  store i32 1, ptr %l47, !tbaa !23
  %t593 = load i32, ptr %l46, !tbaa !23
  %t594 = load i32, ptr %l45, !tbaa !23
  %t597 = icmp sgt i32 %t593, %t594
  br i1 %t597, label %bb92, label %bb93
bb92:
  %t599 = load i32, ptr %l47, !tbaa !23
  %t601 = icmp sgt i32 %t599, 0
  br i1 %t601, label %bb94, label %bb95
bb93:
  store i32 0, ptr %l352, !tbaa !23
  br label %bb97
bb94:
  %t603 = load i32, ptr %l46, !tbaa !23
  %t604 = load i32, ptr %l45, !tbaa !23
  %t607 = sub i32 %t603, %t604
  %t608 = load i32, ptr %l47, !tbaa !23
  %t611 = add i32 %t607, %t608
  %t613 = sub i32 %t611, 1
  %t614 = load i32, ptr %l47, !tbaa !23
  %t617 = sdiv i32 %t613, %t614
  store i32 %t617, ptr %l355, !tbaa !23
  br label %bb96
bb95:
  store i32 0, ptr %l355, !tbaa !23
  br label %bb96
bb96:
  %t619 = load i32, ptr %l355, !tbaa !23
  store i32 %t619, ptr %l352, !tbaa !23
  br label %bb97
bb97:
  %t620 = load i32, ptr %l352, !tbaa !23
  store i32 %t620, ptr %l48, !tbaa !23
  store i32 0, ptr %l49, !tbaa !23
  br label %bb98
bb98:
  store %olang.scope zeroinitializer, ptr %s19
  %t621 = load i32, ptr %l49, !tbaa !23
  %t622 = load i32, ptr %l48, !tbaa !23
  %t625 = icmp slt i32 %t621, %t622
  %t627 = xor i1 %t625, true
  br i1 %t627, label %bb99, label %bb100
bb99:
  call void @__olang_scope_close(ptr %s19)
  br label %bb110
bb100:
  br label %bb101
bb101:
  %t629 = load i32, ptr %l45, !tbaa !23
  %t630 = load i32, ptr %l49, !tbaa !23
  %t631 = load i32, ptr %l47, !tbaa !23
  %t634 = mul i32 %t630, %t631
  %t637 = add i32 %t629, %t634
  store i32 %t637, ptr %l50, !tbaa !23
  %t639 = load ptr, ptr %l4, !tbaa !29
  %t641 = getelementptr %"compiler/mir:Fn", ptr %t639, i32 0, i32 12
  %t642 = getelementptr %"compiler/mir:Task", ptr %l5, i32 0, i32 7
  %t643 = getelementptr %"compiler/mir:Range", ptr %t642, i32 0, i32 0
  %t644 = load i32, ptr %t643, !tbaa !23
  %t646 = sext i32 %t644 to i64
  %t647 = load i32, ptr %l50, !tbaa !23
  %t649 = sext i32 %t647 to i64
  %t652 = add i64 %t646, %t649
  %t655 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %t641, i64 %t652)
  store { i64, [1 x i64] } %t655, ptr %l380
  br label %bb102
bb102:
  %t656 = load { i64, [1 x i64] }, ptr %l380
  store { i64, [1 x i64] } %t656, ptr %l51
  store i64 0, ptr %l52, !tbaa !24
  %t657 = load { i64, [1 x i64] }, ptr %l51
  %t659 = extractvalue { i64, [1 x i64] } %t657, 0
  %t660 = icmp eq i64 %t659, 3
  %t662 = xor i1 %t660, true
  br i1 %t662, label %bb103, label %bb104
bb103:
  %t664 = load ptr, ptr %l0, !tbaa !29
  %t665 = load i64, ptr %l1, !tbaa !24
  %t666 = load { i64, [1 x i64] }, ptr %l51
  %t670 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escopeOf(ptr %v0, ptr %t664, i64 %t665, { i64, [1 x i64] } %t666)
  store i64 %t670, ptr %l387
  br label %bb105
bb104:
  br label %bb106
bb105:
  %t671 = load i64, ptr %l387, !tbaa !24
  store i64 %t671, ptr %l52, !tbaa !24
  br label %bb106
bb106:
  %t672 = load ptr, ptr %l0, !tbaa !29
  store ptr %t672, ptr %l388, !tbaa !29
  %t673 = getelementptr %"compiler/eval:Ptr", ptr %l13, i32 0, i32 0
  %t674 = load i64, ptr %t673, !tbaa !24
  %t675 = load i64, ptr %l21, !tbaa !24
  %t676 = load i32, ptr %l50, !tbaa !23
  %t678 = mul i32 8, %t676
  %t680 = sext i32 %t678 to i64
  %t683 = add i64 %t675, %t680
  %t686 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s19, i64 %t674, i64 %t683)
  store %"compiler/eval:Ptr" %t686, ptr %l395
  br label %bb107
bb107:
  %t687 = load i64, ptr %l52, !tbaa !24
  %t688 = load ptr, ptr %l388, !tbaa !29
  %t689 = load %"compiler/eval:Ptr", ptr %l395
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t688, %"compiler/eval:Ptr" %t689, i64 8, i64 %t687)
  br label %bb108
bb108:
  call void @__olang_scope_close(ptr %s19)
  br label %bb109
bb109:
  %t691 = load i32, ptr %l49, !tbaa !23
  %t694 = add i32 %t691, 1
  store i32 %t694, ptr %l49, !tbaa !23
  br label %bb98
bb110:
  %t696 = load ptr, ptr %l0, !tbaa !29
  store ptr %t696, ptr %l400, !tbaa !29
  %t697 = getelementptr %"compiler/eval:Ptr", ptr %l13, i32 0, i32 0
  %t698 = load i64, ptr %t697, !tbaa !24
  %t699 = load i64, ptr %l21, !tbaa !24
  %t700 = load i64, ptr %l10, !tbaa !24
  %t702 = mul i64 8, %t700
  %t705 = add i64 %t699, %t702
  %t708 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s0, i64 %t698, i64 %t705)
  store %"compiler/eval:Ptr" %t708, ptr %l406
  br label %bb111
bb111:
  %t709 = getelementptr %"compiler/mir:Task", ptr %l5, i32 0, i32 10
  %t710 = getelementptr %"compiler/mir:Range", ptr %t709, i32 0, i32 1
  %t711 = load i32, ptr %t710, !tbaa !23
  %t713 = icmp sgt i32 %t711, 0
  br i1 %t713, label %bb112, label %bb113
bb112:
  %t715 = load ptr, ptr %l0, !tbaa !29
  store ptr %t715, ptr %l410, !tbaa !29
  %t716 = load i64, ptr %l1, !tbaa !24
  store i64 %t716, ptr %l411, !tbaa !24
  %t717 = load ptr, ptr %l4, !tbaa !29
  %t719 = getelementptr %"compiler/mir:Fn", ptr %t717, i32 0, i32 12
  %t720 = getelementptr %"compiler/mir:Task", ptr %l5, i32 0, i32 10
  %t721 = getelementptr %"compiler/mir:Range", ptr %t720, i32 0, i32 0
  %t722 = load i32, ptr %t721, !tbaa !23
  %t724 = sext i32 %t722 to i64
  %t727 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %t719, i64 %t724)
  store { i64, [1 x i64] } %t727, ptr %l416
  br label %bb114
bb113:
  store i64 0, ptr %l409, !tbaa !24
  br label %bb116
bb114:
  %t728 = load ptr, ptr %l410, !tbaa !29
  %t729 = load i64, ptr %l411, !tbaa !24
  %t730 = load { i64, [1 x i64] }, ptr %l416
  %t731 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escopeOf(ptr %v0, ptr %t728, i64 %t729, { i64, [1 x i64] } %t730)
  store i64 %t731, ptr %l417
  br label %bb115
bb115:
  %t732 = load i64, ptr %l417, !tbaa !24
  store i64 %t732, ptr %l409, !tbaa !24
  br label %bb116
bb116:
  %t733 = load ptr, ptr %l400, !tbaa !29
  %t734 = load %"compiler/eval:Ptr", ptr %l406
  %t735 = load i64, ptr %l409, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t733, %"compiler/eval:Ptr" %t734, i64 8, i64 %t735)
  br label %bb117
bb117:
  %t736 = load ptr, ptr %l0, !tbaa !29
  %t738 = getelementptr %"compiler/eval:Machine", ptr %t736, i32 0, i32 58
  %t740 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t738)
  %t741 = extractvalue { i32, i64 } %t740, 1
  %t742 = extractvalue { i32, i64 } %t740, 0
  store i32 %t742, ptr %l422
  %t743 = icmp ne i32 %t742, 0
  br i1 %t743, label %bb119, label %ok.744, !prof !99
ok.744:
  store i64 %t741, ptr %l421
  br label %bb118
bb118:
  %t745 = load i64, ptr %l421, !tbaa !24
  store i64 %t745, ptr %l418, !tbaa !24
  br label %bb122
bb119:
  br label %bb120
bb120:
  %t746 = load ptr, ptr %l0, !tbaa !29
  %t748 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2enewTaskSlot(ptr %v0, ptr %t746)
  store i64 %t748, ptr %l424
  br label %bb121
bb121:
  %t749 = load i64, ptr %l424, !tbaa !24
  store i64 %t749, ptr %l418, !tbaa !24
  br label %bb122
bb122:
  %t750 = load i64, ptr %l418, !tbaa !24
  store i64 %t750, ptr %l53, !tbaa !24
  %t751 = call %"compiler/eval:task" @compiler_2feval_3atask_2ector(ptr %s0)
  store %"compiler/eval:task" %t751, ptr %l425
  br label %bb123
bb123:
  %t752 = load %"compiler/eval:task", ptr %l425
  store %"compiler/eval:task" %t752, ptr %l54
  %t753 = load ptr, ptr %l0, !tbaa !29
  %t755 = getelementptr %"compiler/eval:Machine", ptr %t753, i32 0, i32 59
  %t756 = load { i64, ptr }, ptr %t755, !tbaa !27
  store { i64, ptr } %t756, ptr %l427, !tbaa !27
  %t757 = load i64, ptr %l1, !tbaa !24
  %t759 = getelementptr { i64, ptr }, ptr %l427, i32 0, i32 1
  %t760 = load ptr, ptr %t759, !tbaa !27
  %t761 = getelementptr %"compiler/eval:frame", ptr %t760, i64 %t757
  %t762 = getelementptr %"compiler/eval:frame", ptr %t761, i32 0, i32 0
  %t763 = load i64, ptr %t762, !tbaa !24
  %t765 = load i32, ptr %l3, !tbaa !23
  %t767 = sext i32 %t765 to i64
  %t769 = getelementptr %"compiler/eval:Ptr", ptr %l13, i32 0, i32 0
  %t770 = load i64, ptr %t769, !tbaa !24
  %t774 = getelementptr %"compiler/eval:task", ptr %l54, i32 0, i32 0
  store i64 %t763, ptr %t774, !tbaa !24
  %t777 = getelementptr %"compiler/eval:task", ptr %l54, i32 0, i32 1
  store i64 %t767, ptr %t777, !tbaa !24
  %t780 = getelementptr %"compiler/eval:task", ptr %l54, i32 0, i32 2
  store i64 %t770, ptr %t780, !tbaa !24
  %t783 = getelementptr %"compiler/eval:task", ptr %l54, i32 0, i32 3
  store i64 -1, ptr %t783, !tbaa !24
  %t784 = load ptr, ptr %l0, !tbaa !29
  %t786 = getelementptr %"compiler/eval:Machine", ptr %t784, i32 0, i32 57
  %t787 = load i64, ptr %l53, !tbaa !24
  %t788 = load %"compiler/eval:task", ptr %l54
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3atask_3e_2eSetAt_3ccompiler_2feval_3atask_3e(ptr %v0, ptr %t786, i64 %t787, %"compiler/eval:task" %t788)
  br label %bb124
bb124:
  %t792 = load i64, ptr %l6, !tbaa !24
  %t793 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t796 = and i64 %t792, %t793
  store i64 %t796, ptr %l59, !tbaa !24
  %t798 = load ptr, ptr %l0, !tbaa !29
  %t800 = getelementptr %"compiler/eval:Machine", ptr %t798, i32 0, i32 53
  %t801 = load i64, ptr %l59, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t802, ptr %v0, ptr %t800, i64 %t801)
  call void @llvm.memmove.p0.p0.i64(ptr %l447, ptr %t802, i64 152, i1 false)
  br label %bb125
bb125:
  %t805 = getelementptr %"compiler/eval:scope", ptr %l447, i32 0, i32 11
  %t806 = load i64, ptr %t805, !tbaa !24
  %t808 = icmp sge i64 %t806, 0
  br i1 %t808, label %bb126, label %bb127
bb126:
  %t810 = load ptr, ptr %l0, !tbaa !29
  %t812 = getelementptr %"compiler/eval:Machine", ptr %t810, i32 0, i32 53
  %t813 = load i64, ptr %l59, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t814, ptr %v0, ptr %t812, i64 %t813)
  call void @llvm.memmove.p0.p0.i64(ptr %l453, ptr %t814, i64 152, i1 false)
  br label %bb128
bb127:
  %t817 = load i64, ptr %l59, !tbaa !24
  %t819 = load ptr, ptr %l0, !tbaa !29
  %t821 = getelementptr %"compiler/eval:Machine", ptr %t819, i32 0, i32 53
  %t825 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eRefMut_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %v0, ptr %t821, i64 %t817)
  store ptr %t825, ptr %l465
  br label %bb130
bb128:
  %t826 = getelementptr %"compiler/eval:scope", ptr %l453, i32 0, i32 11
  %t827 = load i64, ptr %t826, !tbaa !24
  %t829 = load ptr, ptr %l0, !tbaa !29
  %t831 = getelementptr %"compiler/eval:Machine", ptr %t829, i32 0, i32 57
  %t835 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3atask_3e_2eRefMut_3ccompiler_2feval_3atask_3e(ptr %v0, ptr %v0, ptr %t831, i64 %t827)
  store ptr %t835, ptr %l458
  br label %bb129
bb129:
  %t836 = load ptr, ptr %l458, !tbaa !29
  %t838 = load i64, ptr %l53, !tbaa !24
  %t841 = getelementptr %"compiler/eval:task", ptr %t836, i32 0, i32 3
  store i64 %t838, ptr %t841, !tbaa !24
  br label %bb131
bb130:
  %t842 = load ptr, ptr %l465, !tbaa !29
  %t844 = load i64, ptr %l53, !tbaa !24
  %t847 = getelementptr %"compiler/eval:scope", ptr %t842, i32 0, i32 10
  store i64 %t844, ptr %t847, !tbaa !24
  br label %bb131
bb131:
  %t848 = load i64, ptr %l59, !tbaa !24
  %t850 = load ptr, ptr %l0, !tbaa !29
  %t852 = getelementptr %"compiler/eval:Machine", ptr %t850, i32 0, i32 53
  %t856 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eRefMut_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %v0, ptr %t852, i64 %t848)
  store ptr %t856, ptr %l472
  br label %bb132
bb132:
  %t857 = load ptr, ptr %l472, !tbaa !29
  %t859 = load i64, ptr %l53, !tbaa !24
  %t862 = getelementptr %"compiler/eval:scope", ptr %t857, i32 0, i32 11
  store i64 %t859, ptr %t862, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2estartTask(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca %"compiler/eval:task"
  %l7 = alloca ptr
  %l8 = alloca %"compiler/mir:Task"
  %l9 = alloca { { i64, ptr }, i64 }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca %"compiler/eval:Ptr"
  %l17 = alloca { i64, [7 x i64] }
  %l18 = alloca { i64, [2 x i64] }
  %l19 = alloca %"compiler/eval:Ptr"
  %l20 = alloca %"compiler/eval:Ptr"
  %l21 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca i32
  %l27 = alloca i32
  %l28 = alloca i32
  %l29 = alloca i32
  %l30 = alloca i32
  %l31 = alloca i32
  %l32 = alloca i32
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca ptr
  %l36 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l47 = alloca i64
  %l51 = alloca ptr
  %l57 = alloca %"compiler/eval:task"
  %l61 = alloca ptr
  %l65 = alloca %"compiler/mir:Task"
  %l68 = alloca %"compiler/mir:Task"
  %l70 = alloca { { i64, ptr }, i64 }
  %l86 = alloca i64
  %l100 = alloca %"compiler/eval:Ptr"
  %l103 = alloca %"compiler/eval:Ptr"
  %l104 = alloca ptr
  %l108 = alloca %"compiler/eval:Ptr"
  %l109 = alloca %"compiler/eval:Ptr"
  %l112 = alloca i1
  %l114 = alloca { i64, ptr }
  %l121 = alloca i1
  %l123 = alloca { i64, ptr }
  %l129 = alloca ptr
  %l133 = alloca { i64, ptr }
  %l138 = alloca { i64, [2 x i64] }
  %l139 = alloca i64
  %l148 = alloca i64
  %l153 = alloca i64
  %l155 = alloca i64
  %l160 = alloca i64
  %l168 = alloca ptr
  %l171 = alloca i64
  %l182 = alloca ptr
  %l187 = alloca i32
  %l190 = alloca i32
  %l209 = alloca i64
  %l212 = alloca i64
  %l218 = alloca i32
  %l219 = alloca ptr
  %l223 = alloca %"compiler/eval:Ptr"
  %l227 = alloca %"compiler/eval:Ptr"
  %l228 = alloca ptr
  %l233 = alloca %"compiler/mir:Local"
  %l235 = alloca i64
  %l251 = alloca i64
  %l253 = alloca i64
  %l258 = alloca { i64, [1 x i64] }
  %l271 = alloca i64
  %l274 = alloca i64
  %l293 = alloca { i64, ptr }
  %l295 = alloca { i64, ptr }
  %l299 = alloca i64
  %l303 = alloca i64
  %l304 = alloca ptr
  %l310 = alloca %"compiler/eval:Ptr"
  %l311 = alloca i64
  %l315 = alloca { i64, [1 x i64] }
  %l318 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %t44 = alloca %"compiler/mir:Task", align 8
  %t52 = alloca %"compiler/mir:Task", align 8
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l2, !tbaa !24
  store i64 %t1, ptr %l3, !tbaa !24
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/eval:Machine", ptr %t3, i32 0, i32 13
  %t7 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t5)
  store i64 %t7, ptr %l47
  br label %bb1
bb1:
  %t8 = load i64, ptr %l47, !tbaa !24
  store i64 %t8, ptr %l4, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/eval:Machine", ptr %t9, i32 0, i32 57
  %t12 = load i64, ptr %l3, !tbaa !24
  %t15 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3atask_3e_2eRefMut_3ccompiler_2feval_3atask_3e(ptr %v0, ptr %v0, ptr %t11, i64 %t12)
  store ptr %t15, ptr %l51
  br label %bb2
bb2:
  %t16 = load ptr, ptr %l51, !tbaa !29
  %t18 = load i64, ptr %l4, !tbaa !24
  %t21 = getelementptr %"compiler/eval:task", ptr %t16, i32 0, i32 4
  store i64 %t18, ptr %t21, !tbaa !24
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/eval:Machine", ptr %t22, i32 0, i32 57
  %t25 = load i64, ptr %l2, !tbaa !24
  %t28 = call %"compiler/eval:task" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3atask_3e_2eAt_3ccompiler_2feval_3atask_3e(ptr %v0, ptr %t24, i64 %t25)
  store %"compiler/eval:task" %t28, ptr %l57
  br label %bb3
bb3:
  %t29 = load %"compiler/eval:task", ptr %l57
  store %"compiler/eval:task" %t29, ptr %l6
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/eval:Machine", ptr %t30, i32 0, i32 26
  %t33 = getelementptr %"compiler/eval:task", ptr %l6, i32 0, i32 0
  %t34 = load i64, ptr %t33, !tbaa !24
  %t37 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_26_3e_2eAt_3ccompiler_2fmir_3aFn_26_3e(ptr %v0, ptr %v0, ptr %t32, i64 %t34)
  store ptr %t37, ptr %l61
  br label %bb4
bb4:
  %t38 = load ptr, ptr %l61, !tbaa !29
  store ptr %t38, ptr %l7, !tbaa !29
  %t39 = load ptr, ptr %l7, !tbaa !29
  %t41 = getelementptr %"compiler/mir:Fn", ptr %t39, i32 0, i32 16
  %t42 = getelementptr %"compiler/eval:task", ptr %l6, i32 0, i32 1
  %t43 = load i64, ptr %t42, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e_2eAt_3ccompiler_2fmir_3aTask_3e(ptr %t44, ptr %v0, ptr %t41, i64 %t43)
  call void @llvm.memmove.p0.p0.i64(ptr %l65, ptr %t44, i64 144, i1 false)
  br label %bb5
bb5:
  call void @llvm.memmove.p0.p0.i64(ptr %l8, ptr %l65, i64 144, i1 false)
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load ptr, ptr %l7, !tbaa !29
  call void @llvm.memmove.p0.p0.i64(ptr %l68, ptr %l8, i64 144, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %t52, ptr %l68, i64 144, i1 false)
  %t54 = call { { i64, ptr }, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2etaskLayout(ptr %v0, ptr %v0, ptr %s0, ptr %t47, ptr %t48, ptr %t52, i64 %a1)
  store { { i64, ptr }, i64 } %t54, ptr %l70
  br label %bb6
bb6:
  %t55 = load { { i64, ptr }, i64 }, ptr %l70
  store { { i64, ptr }, i64 } %t55, ptr %l9
  %t56 = getelementptr { { i64, ptr }, i64 }, ptr %l9, i32 0, i32 0
  %t57 = load { i64, ptr }, ptr %t56, !tbaa !27
  store { i64, ptr } %t57, ptr %l10, !tbaa !27
  %t59 = getelementptr { { i64, ptr }, i64 }, ptr %l9, i32 0, i32 1
  %t60 = load i64, ptr %t59, !tbaa !24
  store i64 %t60, ptr %l11, !tbaa !24
  %t62 = getelementptr %"compiler/mir:Task", ptr %l8, i32 0, i32 3
  %t63 = getelementptr %"compiler/mir:Range", ptr %t62, i32 0, i32 1
  %t64 = load i32, ptr %t63, !tbaa !23
  %t66 = sext i32 %t64 to i64
  store i64 %t66, ptr %l12, !tbaa !24
  %t68 = getelementptr %"compiler/mir:Task", ptr %l8, i32 0, i32 4
  %t69 = getelementptr %"compiler/mir:Range", ptr %t68, i32 0, i32 1
  %t70 = load i32, ptr %t69, !tbaa !23
  %t72 = sext i32 %t70 to i64
  store i64 %t72, ptr %l13, !tbaa !24
  %t74 = getelementptr %"compiler/mir:Task", ptr %l8, i32 0, i32 2
  %t75 = getelementptr %"compiler/mir:Range", ptr %t74, i32 0, i32 1
  %t76 = load i32, ptr %t75, !tbaa !23
  %t78 = sext i32 %t76 to i64
  store i64 %t78, ptr %l14, !tbaa !24
  store i64 -1, ptr %l15, !tbaa !24
  %t80 = load %"compiler/eval:Ptr", ptr @G_2ecompiler_2feval_2eNullPtr
  store %"compiler/eval:Ptr" %t80, ptr %l16
  %t82 = getelementptr %"compiler/mir:Task", ptr %l8, i32 0, i32 0
  %t83 = load { i64, [7 x i64] }, ptr %t82
  store { i64, [7 x i64] } %t83, ptr %l17
  %t85 = load { i64, [7 x i64] }, ptr %l17
  %t87 = extractvalue { i64, [7 x i64] } %t85, 0
  %t88 = icmp eq i64 %t87, 0
  br i1 %t88, label %bb7, label %bb8
bb7:
  %t90 = getelementptr { i64, [7 x i64] }, ptr %l17, i32 0, i32 1
  %t91 = getelementptr { { i64, [2 x i64] }, i32 }, ptr %t90, i32 0, i32 0
  %t92 = load { i64, [2 x i64] }, ptr %t91
  store { i64, [2 x i64] } %t92, ptr %l18
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load { i64, [2 x i64] }, ptr %l18
  %t98 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2efnIndex(ptr %v0, ptr %t94, { i64, [2 x i64] } %t95)
  store i64 %t98, ptr %l86
  br label %bb10
bb10:
  %t99 = load i64, ptr %l86, !tbaa !24
  store i64 %t99, ptr %l15, !tbaa !24
  br label %bb35
bb11:
  %t100 = load { i64, [7 x i64] }, ptr %l17
  %t102 = extractvalue { i64, [7 x i64] } %t100, 0
  %t103 = icmp eq i64 %t102, 2
  br i1 %t103, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb30
bb14:
  store %olang.scope zeroinitializer, ptr %s2
  %t105 = getelementptr %"compiler/eval:task", ptr %l6, i32 0, i32 2
  %t106 = load i64, ptr %t105, !tbaa !24
  %t107 = load i64, ptr %l11, !tbaa !24
  %t108 = load i64, ptr %l12, !tbaa !24
  %t110 = mul i64 8, %t108
  %t113 = add i64 %t107, %t110
  %t114 = load i64, ptr %l13, !tbaa !24
  %t116 = mul i64 16, %t114
  %t119 = add i64 %t113, %t116
  %t120 = load i64, ptr %l14, !tbaa !24
  %t122 = mul i64 8, %t120
  %t125 = add i64 %t119, %t122
  %t128 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s2, i64 %t106, i64 %t125)
  store %"compiler/eval:Ptr" %t128, ptr %l100
  br label %bb15
bb15:
  %t129 = load %"compiler/eval:Ptr", ptr %l100
  store %"compiler/eval:Ptr" %t129, ptr %l19
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t131 = load %"compiler/eval:Ptr", ptr %l19
  %t134 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtr(ptr %v0, ptr %t130, %"compiler/eval:Ptr" %t131)
  store %"compiler/eval:Ptr" %t134, ptr %l103
  br label %bb16
bb16:
  %t135 = load %"compiler/eval:Ptr", ptr %l103
  store %"compiler/eval:Ptr" %t135, ptr %l20
  %t136 = load ptr, ptr %l0, !tbaa !29
  store ptr %t136, ptr %l104, !tbaa !29
  %t137 = getelementptr %"compiler/eval:Ptr", ptr %l19, i32 0, i32 0
  %t138 = load i64, ptr %t137, !tbaa !24
  %t139 = getelementptr %"compiler/eval:Ptr", ptr %l19, i32 0, i32 1
  %t140 = load i64, ptr %t139, !tbaa !24
  %t142 = add i64 %t140, 8
  %t145 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s2, i64 %t138, i64 %t142)
  store %"compiler/eval:Ptr" %t145, ptr %l108
  br label %bb17
bb17:
  %t146 = load ptr, ptr %l104, !tbaa !29
  %t147 = load %"compiler/eval:Ptr", ptr %l108
  %t148 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtr(ptr %v0, ptr %t146, %"compiler/eval:Ptr" %t147)
  store %"compiler/eval:Ptr" %t148, ptr %l109
  br label %bb18
bb18:
  %t149 = load %"compiler/eval:Ptr", ptr %l109
  store %"compiler/eval:Ptr" %t149, ptr %l16
  %t150 = getelementptr %"compiler/eval:Ptr", ptr %l20, i32 0, i32 0
  %t151 = load i64, ptr %t150, !tbaa !24
  %t153 = icmp ne i64 %t151, 0
  br i1 %t153, label %bb19, label %bb20
bb19:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = getelementptr %"compiler/eval:Machine", ptr %t155, i32 0, i32 50
  %t158 = load { i64, ptr }, ptr %t157, !tbaa !27
  store { i64, ptr } %t158, ptr %l114, !tbaa !27
  %t159 = getelementptr %"compiler/eval:Ptr", ptr %l20, i32 0, i32 0
  %t160 = load i64, ptr %t159, !tbaa !24
  %t161 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t164 = and i64 %t160, %t161
  %t166 = getelementptr { i64, ptr }, ptr %l114, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !27
  %t168 = getelementptr %"compiler/eval:alloc", ptr %t167, i64 %t164
  %t169 = getelementptr %"compiler/eval:alloc", ptr %t168, i32 0, i32 4
  %t170 = load i64, ptr %t169, !tbaa !24
  %t171 = load i64, ptr @G_2ecompiler_2feval_2eaCode, !tbaa !24
  %t174 = icmp eq i64 %t170, %t171
  store i1 %t174, ptr %l112, !tbaa !21
  br label %bb21
bb20:
  store i1 false, ptr %l112, !tbaa !21
  br label %bb21
bb21:
  %t176 = load i1, ptr %l112, !tbaa !21
  br i1 %t176, label %bb22, label %bb23
bb22:
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = getelementptr %"compiler/eval:Machine", ptr %t177, i32 0, i32 50
  %t180 = load { i64, ptr }, ptr %t179, !tbaa !27
  store { i64, ptr } %t180, ptr %l123, !tbaa !27
  %t181 = getelementptr %"compiler/eval:Ptr", ptr %l20, i32 0, i32 0
  %t182 = load i64, ptr %t181, !tbaa !24
  %t183 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t186 = and i64 %t182, %t183
  %t188 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t189 = load ptr, ptr %t188, !tbaa !27
  %t190 = getelementptr %"compiler/eval:alloc", ptr %t189, i64 %t186
  %t191 = getelementptr %"compiler/eval:alloc", ptr %t190, i32 0, i32 15
  %t192 = load i1, ptr %t191, !tbaa !21
  %t194 = xor i1 %t192, true
  store i1 %t194, ptr %l121, !tbaa !21
  br label %bb24
bb23:
  store i1 false, ptr %l121, !tbaa !21
  br label %bb24
bb24:
  %t196 = load i1, ptr %l121, !tbaa !21
  br i1 %t196, label %bb25, label %bb26
bb25:
  %t197 = load ptr, ptr %l0, !tbaa !29
  store ptr %t197, ptr %l129, !tbaa !29
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t200 = getelementptr %"compiler/eval:Machine", ptr %t198, i32 0, i32 32
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t203 = getelementptr %"compiler/eval:Machine", ptr %t201, i32 0, i32 50
  %t204 = load { i64, ptr }, ptr %t203, !tbaa !27
  store { i64, ptr } %t204, ptr %l133, !tbaa !27
  %t205 = getelementptr %"compiler/eval:Ptr", ptr %l20, i32 0, i32 0
  %t206 = load i64, ptr %t205, !tbaa !24
  %t207 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t210 = and i64 %t206, %t207
  %t212 = getelementptr { i64, ptr }, ptr %l133, i32 0, i32 1
  %t213 = load ptr, ptr %t212, !tbaa !27
  %t214 = getelementptr %"compiler/eval:alloc", ptr %t213, i64 %t210
  %t215 = getelementptr %"compiler/eval:alloc", ptr %t214, i32 0, i32 14
  %t216 = load i64, ptr %t215, !tbaa !24
  %t219 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2eAt_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %t200, i64 %t216)
  store { i64, [2 x i64] } %t219, ptr %l138
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t220 = load ptr, ptr %l129, !tbaa !29
  %t221 = load { i64, [2 x i64] }, ptr %l138
  %t222 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2efnIndex(ptr %v0, ptr %t220, { i64, [2 x i64] } %t221)
  store i64 %t222, ptr %l139
  br label %bb28
bb28:
  %t223 = load i64, ptr %l139, !tbaa !24
  store i64 %t223, ptr %l15, !tbaa !24
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s2)
  br label %bb35
bb30:
  br i1 true, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_ab5609012e755c90_cedd2fbfe92d4e64)
  unreachable
bb35:
  %t224 = load i64, ptr %l15, !tbaa !24
  %t226 = icmp slt i64 %t224, 0
  br i1 %t226, label %bb36, label %bb37
bb36:
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t229 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNoBody, !tbaa !27
  %t230 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t230, ptr %t228, { i64, ptr } %t229)
  br label %bb38
bb37:
  br label %bb39
bb38:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb39:
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t234 = load i64, ptr %l15, !tbaa !24
  %t235 = load i64, ptr @G_2ecompiler_2feval_2erTask, !tbaa !24
  %t236 = load i64, ptr %l2, !tbaa !24
  %t241 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2epushFrame(ptr %v0, ptr %t233, i64 %t234, i64 %t235, i64 %t236)
  store i64 %t241, ptr %l148
  br label %bb40
bb40:
  %t242 = load i64, ptr %l148, !tbaa !24
  store i64 %t242, ptr %l21, !tbaa !24
  %t243 = load i64, ptr %l21, !tbaa !24
  %t245 = icmp slt i64 %t243, 0
  br i1 %t245, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb42:
  br label %bb43
bb43:
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t249 = getelementptr %"compiler/eval:Machine", ptr %t247, i32 0, i32 89
  store ptr %t249, ptr %l22, !tbaa !29
  store i64 0, ptr %l23, !tbaa !24
  br label %bb44
bb44:
  %t251 = load i64, ptr %l23, !tbaa !24
  store i64 %t251, ptr %l153, !tbaa !24
  %t252 = load ptr, ptr %l22, !tbaa !29
  %t254 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t252)
  store i64 %t254, ptr %l155
  br label %bb45
bb45:
  %t255 = load i64, ptr %l153, !tbaa !24
  %t256 = load i64, ptr %l155, !tbaa !24
  %t257 = icmp slt i64 %t255, %t256
  %t259 = xor i1 %t257, true
  br i1 %t259, label %bb46, label %bb47
bb46:
  br label %bb52
bb47:
  br label %bb48
bb48:
  %t261 = load ptr, ptr %l22, !tbaa !29
  %t262 = load i64, ptr %l23, !tbaa !24
  %t265 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t261, i64 %t262)
  store i64 %t265, ptr %l160
  br label %bb49
bb49:
  %t266 = load i64, ptr %l160, !tbaa !24
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t269 = getelementptr %"compiler/eval:Machine", ptr %t267, i32 0, i32 92
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t269, i64 %t266)
  br label %bb50
bb50:
  br label %bb51
bb51:
  %t273 = load i64, ptr %l23, !tbaa !24
  %t276 = add i64 %t273, 1
  store i64 %t276, ptr %l23, !tbaa !24
  br label %bb44
bb52:
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t280 = getelementptr %"compiler/eval:Machine", ptr %t278, i32 0, i32 92
  store ptr %t280, ptr %l168, !tbaa !29
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t283 = getelementptr %"compiler/eval:Machine", ptr %t281, i32 0, i32 89
  %t285 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t283)
  store i64 %t285, ptr %l171
  br label %bb53
bb53:
  %t286 = load ptr, ptr %l168, !tbaa !29
  %t287 = load i64, ptr %l171, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t286, i64 %t287)
  br label %bb54
bb54:
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t290 = getelementptr %"compiler/eval:Machine", ptr %t288, i32 0, i32 92
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t293 = getelementptr %"compiler/eval:Machine", ptr %t291, i32 0, i32 91
  %t294 = load i64, ptr %t293, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t290, i64 %t294)
  br label %bb55
bb55:
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t299 = getelementptr %"compiler/eval:Machine", ptr %t297, i32 0, i32 89
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t299)
  br label %bb56
bb56:
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t303 = getelementptr %"compiler/eval:Machine", ptr %t301, i32 0, i32 91
  store i64 0, ptr %t303, !tbaa !24
  %t304 = load ptr, ptr %l0, !tbaa !29
  %t306 = getelementptr %"compiler/eval:Machine", ptr %t304, i32 0, i32 26
  %t307 = load i64, ptr %l15, !tbaa !24
  %t310 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_26_3e_2eAt_3ccompiler_2fmir_3aFn_26_3e(ptr %v0, ptr %v0, ptr %t306, i64 %t307)
  store ptr %t310, ptr %l182
  br label %bb57
bb57:
  %t311 = load ptr, ptr %l182, !tbaa !29
  store ptr %t311, ptr %l25, !tbaa !29
  store i32 0, ptr %l26, !tbaa !23
  %t312 = getelementptr %"compiler/mir:Task", ptr %l8, i32 0, i32 1
  %t313 = getelementptr %"compiler/mir:Range", ptr %t312, i32 0, i32 1
  %t314 = load i32, ptr %t313, !tbaa !23
  store i32 %t314, ptr %l27, !tbaa !23
  store i32 1, ptr %l28, !tbaa !23
  %t316 = load i32, ptr %l27, !tbaa !23
  %t317 = load i32, ptr %l26, !tbaa !23
  %t320 = icmp sgt i32 %t316, %t317
  br i1 %t320, label %bb58, label %bb59
bb58:
  %t322 = load i32, ptr %l28, !tbaa !23
  %t324 = icmp sgt i32 %t322, 0
  br i1 %t324, label %bb60, label %bb61
bb59:
  store i32 0, ptr %l187, !tbaa !23
  br label %bb63
bb60:
  %t326 = load i32, ptr %l27, !tbaa !23
  %t327 = load i32, ptr %l26, !tbaa !23
  %t330 = sub i32 %t326, %t327
  %t331 = load i32, ptr %l28, !tbaa !23
  %t334 = add i32 %t330, %t331
  %t336 = sub i32 %t334, 1
  %t337 = load i32, ptr %l28, !tbaa !23
  %t340 = sdiv i32 %t336, %t337
  store i32 %t340, ptr %l190, !tbaa !23
  br label %bb62
bb61:
  store i32 0, ptr %l190, !tbaa !23
  br label %bb62
bb62:
  %t342 = load i32, ptr %l190, !tbaa !23
  store i32 %t342, ptr %l187, !tbaa !23
  br label %bb63
bb63:
  %t343 = load i32, ptr %l187, !tbaa !23
  store i32 %t343, ptr %l29, !tbaa !23
  store i32 0, ptr %l30, !tbaa !23
  br label %bb64
bb64:
  %t344 = load i32, ptr %l30, !tbaa !23
  %t345 = load i32, ptr %l29, !tbaa !23
  %t348 = icmp slt i32 %t344, %t345
  %t350 = xor i1 %t348, true
  br i1 %t350, label %bb65, label %bb66
bb65:
  br label %bb79
bb66:
  br label %bb67
bb67:
  %t352 = load i32, ptr %l26, !tbaa !23
  %t353 = load i32, ptr %l30, !tbaa !23
  %t354 = load i32, ptr %l28, !tbaa !23
  %t357 = mul i32 %t353, %t354
  %t360 = add i32 %t352, %t357
  store i32 %t360, ptr %l31, !tbaa !23
  %t362 = load i32, ptr %l31, !tbaa !23
  %t364 = sext i32 %t362 to i64
  store i64 %t364, ptr %l209, !tbaa !24
  %t365 = load ptr, ptr %l25, !tbaa !29
  %t367 = getelementptr %"compiler/mir:Fn", ptr %t365, i32 0, i32 4
  %t369 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t367)
  store i64 %t369, ptr %l212
  br label %bb68
bb68:
  %t370 = load i64, ptr %l209, !tbaa !24
  %t371 = load i64, ptr %l212, !tbaa !24
  %t372 = icmp slt i64 %t370, %t371
  br i1 %t372, label %bb69, label %bb70
bb69:
  store %olang.scope zeroinitializer, ptr %s12
  %t374 = load ptr, ptr %l25, !tbaa !29
  %t376 = getelementptr %"compiler/mir:Fn", ptr %t374, i32 0, i32 4
  %t377 = load i32, ptr %l31, !tbaa !23
  %t379 = sext i32 %t377 to i64
  %t382 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t376, i64 %t379)
  store i32 %t382, ptr %l218
  br label %bb71
bb70:
  br label %bb77
bb71:
  %t383 = load i32, ptr %l218, !tbaa !23
  store i32 %t383, ptr %l32, !tbaa !23
  %t384 = load ptr, ptr %l0, !tbaa !29
  store ptr %t384, ptr %l219, !tbaa !29
  %t385 = load ptr, ptr %l0, !tbaa !29
  %t386 = load i64, ptr %l21, !tbaa !24
  %t387 = load i32, ptr %l32, !tbaa !23
  %t391 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2elocalPtr(ptr %v0, ptr %t385, i64 %t386, i32 %t387)
  store %"compiler/eval:Ptr" %t391, ptr %l223
  br label %bb72
bb72:
  %t392 = getelementptr %"compiler/eval:task", ptr %l6, i32 0, i32 2
  %t393 = load i64, ptr %t392, !tbaa !24
  %t394 = load i32, ptr %l31, !tbaa !23
  %t396 = sext i32 %t394 to i64
  %t397 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t398 = load ptr, ptr %t397, !tbaa !27
  %t399 = getelementptr i64, ptr %t398, i64 %t396
  %t400 = load i64, ptr %t399, !tbaa !34
  %t403 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s12, i64 %t393, i64 %t400)
  store %"compiler/eval:Ptr" %t403, ptr %l227
  br label %bb73
bb73:
  %t404 = load ptr, ptr %l0, !tbaa !29
  store ptr %t404, ptr %l228, !tbaa !29
  %t405 = load ptr, ptr %l25, !tbaa !29
  %t407 = getelementptr %"compiler/mir:Fn", ptr %t405, i32 0, i32 7
  %t408 = load i32, ptr %l32, !tbaa !23
  %t410 = sext i32 %t408 to i64
  %t413 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t407, i64 %t410)
  store %"compiler/mir:Local" %t413, ptr %l233
  br label %bb74
bb74:
  %t414 = getelementptr %"compiler/mir:Local", ptr %l233, i32 0, i32 2
  %t415 = load i32, ptr %t414, !tbaa !23
  %t416 = load ptr, ptr %l228, !tbaa !29
  %t418 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t416, i32 %t415)
  store i64 %t418, ptr %l235
  br label %bb75
bb75:
  %t419 = load ptr, ptr %l219, !tbaa !29
  %t420 = load %"compiler/eval:Ptr", ptr %l223
  %t421 = load %"compiler/eval:Ptr", ptr %l227
  %t422 = load i64, ptr %l235, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ecopy(ptr %v0, ptr %t419, %"compiler/eval:Ptr" %t420, %"compiler/eval:Ptr" %t421, i64 %t422)
  br label %bb76
bb76:
  call void @__olang_scope_close(ptr %s12)
  br label %bb77
bb77:
  br label %bb78
bb78:
  %t423 = load i32, ptr %l30, !tbaa !23
  %t426 = add i32 %t423, 1
  store i32 %t426, ptr %l30, !tbaa !23
  br label %bb64
bb79:
  %t428 = load ptr, ptr %l0, !tbaa !29
  %t429 = load i64, ptr %l21, !tbaa !24
  %t430 = load i64, ptr %l15, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eownParams(ptr %v0, ptr %t428, i64 %t429, i64 %t430)
  br label %bb80
bb80:
  %t434 = load i64, ptr %l11, !tbaa !24
  %t435 = load i64, ptr %l12, !tbaa !24
  %t437 = mul i64 8, %t435
  %t440 = add i64 %t434, %t437
  %t441 = load i64, ptr %l13, !tbaa !24
  %t443 = mul i64 16, %t441
  %t446 = add i64 %t440, %t443
  store i64 %t446, ptr %l33, !tbaa !24
  store i64 0, ptr %l34, !tbaa !24
  %t448 = load ptr, ptr %l25, !tbaa !29
  %t450 = getelementptr %"compiler/mir:Fn", ptr %t448, i32 0, i32 6
  store ptr %t450, ptr %l35, !tbaa !29
  store i64 0, ptr %l36, !tbaa !24
  br label %bb81
bb81:
  %t452 = load i64, ptr %l36, !tbaa !24
  store i64 %t452, ptr %l251, !tbaa !24
  %t453 = load ptr, ptr %l35, !tbaa !29
  %t455 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eLen_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %t453)
  store i64 %t455, ptr %l253
  br label %bb82
bb82:
  %t456 = load i64, ptr %l251, !tbaa !24
  %t457 = load i64, ptr %l253, !tbaa !24
  %t458 = icmp slt i64 %t456, %t457
  %t460 = xor i1 %t458, true
  br i1 %t460, label %bb83, label %bb84
bb83:
  br label %bb97
bb84:
  br label %bb85
bb85:
  %t462 = load ptr, ptr %l35, !tbaa !29
  %t463 = load i64, ptr %l36, !tbaa !24
  %t466 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eAt_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %t462, i64 %t463)
  store { i64, [1 x i64] } %t466, ptr %l258
  br label %bb86
bb86:
  %t467 = load { i64, [1 x i64] }, ptr %l258
  %t470 = extractvalue { i64, [1 x i64] } %t467, 0
  %t471 = icmp eq i64 %t470, 4
  br i1 %t471, label %bb87, label %bb88
bb87:
  br label %bb89
bb88:
  br label %bb90
bb89:
  br label %bb95
bb90:
  br i1 true, label %bb91, label %bb92
bb91:
  br label %bb93
bb92:
  br label %bb94
bb93:
  %t473 = load i64, ptr %l34, !tbaa !24
  %t476 = add i64 %t473, 1
  store i64 %t476, ptr %l34, !tbaa !24
  br label %bb95
bb94:
  call void @__olang_check_failed(ptr @olang_loc_f6d4fb7f4fd95721_139ddd7815176855)
  unreachable
bb95:
  br label %bb96
bb96:
  %t478 = load i64, ptr %l36, !tbaa !24
  %t481 = add i64 %t478, 1
  store i64 %t481, ptr %l36, !tbaa !24
  br label %bb81
bb97:
  store i64 0, ptr %l38, !tbaa !24
  %t483 = load i64, ptr %l34, !tbaa !24
  store i64 %t483, ptr %l39, !tbaa !24
  store i64 1, ptr %l40, !tbaa !24
  %t485 = load i64, ptr %l39, !tbaa !24
  %t486 = load i64, ptr %l38, !tbaa !24
  %t489 = icmp sgt i64 %t485, %t486
  br i1 %t489, label %bb98, label %bb99
bb98:
  %t491 = load i64, ptr %l40, !tbaa !24
  %t493 = icmp sgt i64 %t491, 0
  br i1 %t493, label %bb100, label %bb101
bb99:
  store i64 0, ptr %l271, !tbaa !24
  br label %bb103
bb100:
  %t495 = load i64, ptr %l39, !tbaa !24
  %t496 = load i64, ptr %l38, !tbaa !24
  %t499 = sub i64 %t495, %t496
  %t500 = load i64, ptr %l40, !tbaa !24
  %t503 = add i64 %t499, %t500
  %t505 = sub i64 %t503, 1
  %t506 = load i64, ptr %l40, !tbaa !24
  %t509 = sdiv i64 %t505, %t506
  store i64 %t509, ptr %l274, !tbaa !24
  br label %bb102
bb101:
  store i64 0, ptr %l274, !tbaa !24
  br label %bb102
bb102:
  %t511 = load i64, ptr %l274, !tbaa !24
  store i64 %t511, ptr %l271, !tbaa !24
  br label %bb103
bb103:
  %t512 = load i64, ptr %l271, !tbaa !24
  store i64 %t512, ptr %l41, !tbaa !24
  store i64 0, ptr %l42, !tbaa !24
  br label %bb104
bb104:
  store %olang.scope zeroinitializer, ptr %s20
  %t513 = load i64, ptr %l42, !tbaa !24
  %t514 = load i64, ptr %l41, !tbaa !24
  %t517 = icmp slt i64 %t513, %t514
  %t519 = xor i1 %t517, true
  br i1 %t519, label %bb105, label %bb106
bb105:
  call void @__olang_scope_close(ptr %s20)
  br label %bb118
bb106:
  br label %bb107
bb107:
  %t521 = load i64, ptr %l38, !tbaa !24
  %t522 = load i64, ptr %l42, !tbaa !24
  %t523 = load i64, ptr %l40, !tbaa !24
  %t526 = mul i64 %t522, %t523
  %t529 = add i64 %t521, %t526
  store i64 %t529, ptr %l43, !tbaa !24
  %t531 = load ptr, ptr %l0, !tbaa !29
  %t533 = getelementptr %"compiler/eval:Machine", ptr %t531, i32 0, i32 61
  %t534 = load { i64, ptr }, ptr %t533, !tbaa !27
  store { i64, ptr } %t534, ptr %l293, !tbaa !27
  %t535 = load ptr, ptr %l0, !tbaa !29
  %t537 = getelementptr %"compiler/eval:Machine", ptr %t535, i32 0, i32 59
  %t538 = load { i64, ptr }, ptr %t537, !tbaa !27
  store { i64, ptr } %t538, ptr %l295, !tbaa !27
  %t539 = load i64, ptr %l21, !tbaa !24
  %t541 = getelementptr { i64, ptr }, ptr %l295, i32 0, i32 1
  %t542 = load ptr, ptr %t541, !tbaa !27
  %t543 = getelementptr %"compiler/eval:frame", ptr %t542, i64 %t539
  %t544 = getelementptr %"compiler/eval:frame", ptr %t543, i32 0, i32 5
  %t545 = load i64, ptr %t544, !tbaa !24
  %t546 = load i64, ptr %l43, !tbaa !24
  %t549 = add i64 %t545, %t546
  store i64 %t549, ptr %l299, !tbaa !24
  %t550 = load i64, ptr %l43, !tbaa !24
  %t551 = load i64, ptr %l14, !tbaa !24
  %t554 = icmp slt i64 %t550, %t551
  br i1 %t554, label %bb108, label %bb109
bb108:
  %t556 = load ptr, ptr %l0, !tbaa !29
  store ptr %t556, ptr %l304, !tbaa !29
  %t557 = getelementptr %"compiler/eval:task", ptr %l6, i32 0, i32 2
  %t558 = load i64, ptr %t557, !tbaa !24
  %t559 = load i64, ptr %l33, !tbaa !24
  %t560 = load i64, ptr %l43, !tbaa !24
  %t562 = mul i64 8, %t560
  %t565 = add i64 %t559, %t562
  %t568 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s20, i64 %t558, i64 %t565)
  store %"compiler/eval:Ptr" %t568, ptr %l310
  br label %bb110
bb109:
  %t569 = load ptr, ptr %l25, !tbaa !29
  %t571 = getelementptr %"compiler/mir:Fn", ptr %t569, i32 0, i32 6
  %t572 = load i64, ptr %l43, !tbaa !24
  %t575 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eAt_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %t571, i64 %t572)
  store { i64, [1 x i64] } %t575, ptr %l315
  br label %bb112
bb110:
  %t576 = load ptr, ptr %l304, !tbaa !29
  %t577 = load %"compiler/eval:Ptr", ptr %l310
  %t578 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t576, %"compiler/eval:Ptr" %t577, i64 8)
  store i64 %t578, ptr %l311
  br label %bb111
bb111:
  %t579 = load i64, ptr %l311, !tbaa !24
  store i64 %t579, ptr %l303, !tbaa !24
  br label %bb116
bb112:
  %t580 = load { i64, [1 x i64] }, ptr %l315
  %t582 = extractvalue { i64, [1 x i64] } %t580, 0
  %t583 = icmp eq i64 %t582, 5
  br i1 %t583, label %bb113, label %bb114
bb113:
  store i64 0, ptr %l318, !tbaa !24
  br label %bb115
bb114:
  %t585 = load ptr, ptr %l0, !tbaa !29
  %t587 = getelementptr %"compiler/eval:Machine", ptr %t585, i32 0, i32 71
  %t588 = load i64, ptr %t587, !tbaa !24
  store i64 %t588, ptr %l318, !tbaa !24
  br label %bb115
bb115:
  %t590 = load i64, ptr %l318, !tbaa !24
  store i64 %t590, ptr %l303, !tbaa !24
  br label %bb116
bb116:
  %t591 = load i64, ptr %l303, !tbaa !24
  %t592 = load i64, ptr %l299, !tbaa !24
  %t593 = getelementptr { i64, ptr }, ptr %l293, i32 0, i32 1
  %t594 = load ptr, ptr %t593, !tbaa !27
  %t595 = getelementptr i64, ptr %t594, i64 %t592
  store i64 %t591, ptr %t595, !tbaa !34
  call void @__olang_scope_close(ptr %s20)
  br label %bb117
bb117:
  %t596 = load i64, ptr %l42, !tbaa !24
  %t599 = add i64 %t596, 1
  store i64 %t599, ptr %l42, !tbaa !24
  br label %bb104
bb118:
  %t601 = load ptr, ptr %l0, !tbaa !29
  %t602 = load i64, ptr %l21, !tbaa !24
  %t603 = load ptr, ptr %l25, !tbaa !29
  %t604 = load %"compiler/eval:Ptr", ptr %l16
  %t605 = load i64, ptr %l34, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eloadCaptures(ptr %v0, ptr %v0, ptr %t601, i64 %t602, ptr %t603, %"compiler/eval:Ptr" %t604, i64 %t605)
  br label %bb119
bb119:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2estepClose(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca %"compiler/eval:reg"
  %l8 = alloca i64
  %l9 = alloca %"compiler/eval:reg"
  %l11 = alloca i64
  %l14 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l21 = alloca i64
  %l23 = alloca i64
  %l24 = alloca %"compiler/eval:scope"
  %l26 = alloca ptr
  %l29 = alloca i64
  %l31 = alloca i64
  %l37 = alloca i1
  %l39 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i32
  %l47 = alloca %"compiler/eval:scope"
  %l51 = alloca i1
  %l55 = alloca %"compiler/eval:scope"
  %l57 = alloca i1
  %l61 = alloca %"compiler/eval:scope"
  %l67 = alloca %"compiler/eval:scope"
  %l73 = alloca %"compiler/eval:reg"
  %l78 = alloca ptr
  %l86 = alloca %"compiler/eval:reg"
  %l93 = alloca ptr
  %l94 = alloca i64
  %l97 = alloca i32
  %l100 = alloca %"compiler/eval:Ptr"
  %l104 = alloca %"compiler/eval:scope"
  %l111 = alloca %"compiler/eval:reg"
  %l117 = alloca ptr
  %l126 = alloca ptr
  %l135 = alloca ptr
  %l136 = alloca i64
  %l139 = alloca i32
  %l142 = alloca %"compiler/eval:Ptr"
  %l152 = alloca %"compiler/eval:scope"
  %l162 = alloca %"compiler/eval:scope"
  %l167 = alloca ptr
  %l176 = alloca ptr
  %l181 = alloca i1
  %l187 = alloca i1
  %l191 = alloca %"compiler/eval:scope"
  %l196 = alloca %"compiler/eval:scope"
  %l204 = alloca { i64, ptr }
  %l207 = alloca i64
  %l212 = alloca { i64, ptr }
  %l218 = alloca %"compiler/eval:scope"
  %l222 = alloca ptr
  %l226 = alloca %"compiler/eval:scope"
  %l231 = alloca %"compiler/eval:scope"
  %l239 = alloca %"compiler/eval:scope"
  %l243 = alloca i64
  %l246 = alloca i64
  %l247 = alloca i32
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %t43 = alloca %"compiler/eval:scope", align 8
  %t57 = alloca %"compiler/eval:scope", align 8
  %t68 = alloca %"compiler/eval:scope", align 8
  %t81 = alloca %"compiler/eval:scope", align 8
  %t159 = alloca %"compiler/eval:scope", align 8
  %t265 = alloca %"compiler/eval:scope", align 8
  %t285 = alloca %"compiler/eval:scope", align 8
  %t344 = alloca %"compiler/eval:scope", align 8
  %t355 = alloca %"compiler/eval:scope", align 8
  %t408 = alloca %"compiler/eval:scope", align 8
  %t423 = alloca %"compiler/eval:scope", align 8
  %t434 = alloca %"compiler/eval:scope", align 8
  %t454 = alloca %"compiler/eval:scope", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 63
  store ptr %t3, ptr %l26, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/eval:Machine", ptr %t4, i32 0, i32 63
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l29
  br label %bb1
bb1:
  %t9 = load i64, ptr %l29, !tbaa !24
  %t10 = sub i64 %t9, 1
  %t11 = load ptr, ptr %l26, !tbaa !29
  %t13 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t11, i64 %t10)
  store i64 %t13, ptr %l31
  br label %bb2
bb2:
  %t14 = load i64, ptr %l31, !tbaa !24
  store i64 %t14, ptr %l1, !tbaa !24
  %t15 = load i64, ptr %l1, !tbaa !24
  %t16 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t19 = and i64 %t15, %t16
  store i64 %t19, ptr %l2, !tbaa !24
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i64, ptr %l1, !tbaa !24
  %t25 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2elive(ptr %v0, ptr %t21, i64 %t22)
  store i1 %t25, ptr %l37
  br label %bb3
bb3:
  %t26 = load i1, ptr %l37, !tbaa !21
  %t27 = xor i1 %t26, true
  br i1 %t27, label %bb4, label %bb5
bb4:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/eval:Machine", ptr %t29, i32 0, i32 63
  %t33 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t31)
  %t34 = extractvalue { i32, i64 } %t33, 1
  %t35 = extractvalue { i32, i64 } %t33, 0
  store i32 %t35, ptr %l43
  %t36 = icmp ne i32 %t35, 0
  br i1 %t36, label %bb7, label %ok.37, !prof !99
ok.37:
  store i64 %t34, ptr %l42
  br label %bb6
bb5:
  br label %bb10
bb6:
  %t38 = load i64, ptr %l42, !tbaa !24
  store i64 %t38, ptr %l39, !tbaa !24
  br label %bb9
bb7:
  br label %bb8
bb8:
  br label %bb9
bb9:
  br label %ret
bb10:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/eval:Machine", ptr %t39, i32 0, i32 53
  %t42 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t43, ptr %v0, ptr %t41, i64 %t42)
  call void @llvm.memmove.p0.p0.i64(ptr %l47, ptr %t43, i64 152, i1 false)
  br label %bb11
bb11:
  %t46 = getelementptr %"compiler/eval:scope", ptr %l47, i32 0, i32 2
  %t47 = load i64, ptr %t46, !tbaa !24
  %t48 = load i64, ptr @G_2ecompiler_2feval_2esRegion, !tbaa !24
  %t51 = icmp eq i64 %t47, %t48
  br i1 %t51, label %bb12, label %bb13
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/eval:Machine", ptr %t53, i32 0, i32 53
  %t56 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t57, ptr %v0, ptr %t55, i64 %t56)
  call void @llvm.memmove.p0.p0.i64(ptr %l55, ptr %t57, i64 152, i1 false)
  br label %bb14
bb13:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb15
bb14:
  %t60 = getelementptr %"compiler/eval:scope", ptr %l55, i32 0, i32 15
  %t61 = load i1, ptr %t60, !tbaa !21
  store i1 %t61, ptr %l51, !tbaa !21
  br label %bb15
bb15:
  %t63 = load i1, ptr %l51, !tbaa !21
  br i1 %t63, label %bb16, label %bb17
bb16:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/eval:Machine", ptr %t64, i32 0, i32 53
  %t67 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t68, ptr %v0, ptr %t66, i64 %t67)
  call void @llvm.memmove.p0.p0.i64(ptr %l61, ptr %t68, i64 152, i1 false)
  br label %bb18
bb17:
  store i1 false, ptr %l57, !tbaa !21
  br label %bb19
bb18:
  %t71 = getelementptr %"compiler/eval:scope", ptr %l61, i32 0, i32 17
  %t72 = load i64, ptr %t71, !tbaa !24
  %t74 = icmp sge i64 %t72, 0
  store i1 %t74, ptr %l57, !tbaa !21
  br label %bb19
bb19:
  %t76 = load i1, ptr %l57, !tbaa !21
  br i1 %t76, label %bb20, label %bb21
bb20:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/eval:Machine", ptr %t77, i32 0, i32 53
  %t80 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t81, ptr %v0, ptr %t79, i64 %t80)
  call void @llvm.memmove.p0.p0.i64(ptr %l67, ptr %t81, i64 152, i1 false)
  br label %bb22
bb21:
  br label %bb33
bb22:
  %t84 = getelementptr %"compiler/eval:scope", ptr %l67, i32 0, i32 17
  %t85 = load i64, ptr %t84, !tbaa !24
  store i64 %t85, ptr %l3, !tbaa !24
  %t87 = load i64, ptr %l2, !tbaa !24
  store i64 %t87, ptr %l4, !tbaa !24
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/eval:Machine", ptr %t89, i32 0, i32 55
  %t92 = load i64, ptr %l3, !tbaa !24
  %t95 = call %"compiler/eval:reg" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3areg_3e_2eAt_3ccompiler_2feval_3areg_3e(ptr %v0, ptr %t91, i64 %t92)
  store %"compiler/eval:reg" %t95, ptr %l73
  br label %bb23
bb23:
  %t96 = getelementptr %"compiler/eval:reg", ptr %l73, i32 0, i32 7
  %t97 = load i64, ptr %t96, !tbaa !24
  store i64 %t97, ptr %l5, !tbaa !24
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/eval:Machine", ptr %t99, i32 0, i32 53
  %t102 = load i64, ptr %l4, !tbaa !24
  %t105 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eRefMut_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %v0, ptr %t101, i64 %t102)
  store ptr %t105, ptr %l78
  br label %bb24
bb24:
  %t106 = load ptr, ptr %l78, !tbaa !29
  %t108 = load i64, ptr %l5, !tbaa !24
  %t111 = getelementptr %"compiler/eval:scope", ptr %t106, i32 0, i32 17
  store i64 %t108, ptr %t111, !tbaa !24
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eunlinkReg(ptr %v0, ptr %t112, i64 %t113)
  br label %bb25
bb25:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/eval:Machine", ptr %t116, i32 0, i32 55
  %t119 = load i64, ptr %l3, !tbaa !24
  %t122 = call %"compiler/eval:reg" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3areg_3e_2eAt_3ccompiler_2feval_3areg_3e(ptr %v0, ptr %t118, i64 %t119)
  store %"compiler/eval:reg" %t122, ptr %l86
  br label %bb26
bb26:
  %t123 = load %"compiler/eval:reg", ptr %l86
  store %"compiler/eval:reg" %t123, ptr %l7
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/eval:Machine", ptr %t124, i32 0, i32 56
  %t127 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t126, i64 %t127)
  br label %bb27
bb27:
  %t130 = getelementptr %"compiler/eval:reg", ptr %l7, i32 0, i32 0
  %t131 = load i64, ptr %t130, !tbaa !24
  %t132 = load i64, ptr @G_2ecompiler_2feval_2egDtor, !tbaa !24
  %t135 = icmp eq i64 %t131, %t132
  br i1 %t135, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s4
  %t137 = load ptr, ptr %l0, !tbaa !29
  store ptr %t137, ptr %l93, !tbaa !29
  %t138 = load i64, ptr %l1, !tbaa !24
  store i64 %t138, ptr %l94, !tbaa !24
  %t139 = getelementptr %"compiler/eval:reg", ptr %l7, i32 0, i32 1
  %t140 = load i64, ptr %t139, !tbaa !24
  %t142 = trunc i64 %t140 to i32
  store i32 %t142, ptr %l97, !tbaa !23
  %t144 = getelementptr %"compiler/eval:reg", ptr %l7, i32 0, i32 2
  %t145 = load i64, ptr %t144, !tbaa !24
  %t146 = getelementptr %"compiler/eval:reg", ptr %l7, i32 0, i32 3
  %t147 = load i64, ptr %t146, !tbaa !24
  %t150 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s4, i64 %t145, i64 %t147)
  store %"compiler/eval:Ptr" %t150, ptr %l100
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t151 = load ptr, ptr %l93, !tbaa !29
  %t152 = load i64, ptr %l94, !tbaa !24
  %t153 = load i32, ptr %l97, !tbaa !23
  %t154 = load %"compiler/eval:Ptr", ptr %l100
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erunDtor(ptr %v0, ptr %t151, i64 %t152, i32 %t153, %"compiler/eval:Ptr" %t154)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s4)
  br label %bb32
bb32:
  br label %ret
bb33:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = getelementptr %"compiler/eval:Machine", ptr %t155, i32 0, i32 53
  %t158 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t159, ptr %v0, ptr %t157, i64 %t158)
  call void @llvm.memmove.p0.p0.i64(ptr %l104, ptr %t159, i64 152, i1 false)
  br label %bb34
bb34:
  %t162 = getelementptr %"compiler/eval:scope", ptr %l104, i32 0, i32 4
  %t163 = load i64, ptr %t162, !tbaa !24
  store i64 %t163, ptr %l8, !tbaa !24
  %t165 = load i64, ptr %l8, !tbaa !24
  %t167 = icmp sge i64 %t165, 0
  br i1 %t167, label %bb35, label %bb36
bb35:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/eval:Machine", ptr %t169, i32 0, i32 55
  %t172 = load i64, ptr %l8, !tbaa !24
  %t175 = call %"compiler/eval:reg" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3areg_3e_2eAt_3ccompiler_2feval_3areg_3e(ptr %v0, ptr %t171, i64 %t172)
  store %"compiler/eval:reg" %t175, ptr %l111
  br label %bb37
bb36:
  br label %bb53
bb37:
  %t176 = load %"compiler/eval:reg", ptr %l111
  store %"compiler/eval:reg" %t176, ptr %l9
  %t177 = load i64, ptr %l2, !tbaa !24
  %t179 = getelementptr %"compiler/eval:reg", ptr %l9, i32 0, i32 4
  %t180 = load i64, ptr %t179, !tbaa !24
  store i64 %t180, ptr %l11, !tbaa !24
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr %"compiler/eval:Machine", ptr %t182, i32 0, i32 53
  %t188 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eRefMut_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %v0, ptr %t184, i64 %t177)
  store ptr %t188, ptr %l117
  br label %bb38
bb38:
  %t189 = load ptr, ptr %l117, !tbaa !29
  %t191 = load i64, ptr %l11, !tbaa !24
  %t194 = getelementptr %"compiler/eval:scope", ptr %t189, i32 0, i32 4
  store i64 %t191, ptr %t194, !tbaa !24
  %t195 = getelementptr %"compiler/eval:reg", ptr %l9, i32 0, i32 4
  %t196 = load i64, ptr %t195, !tbaa !24
  %t198 = icmp sge i64 %t196, 0
  br i1 %t198, label %bb39, label %bb40
bb39:
  %t200 = getelementptr %"compiler/eval:reg", ptr %l9, i32 0, i32 4
  %t201 = load i64, ptr %t200, !tbaa !24
  store i64 -1, ptr %l14, !tbaa !24
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t205 = getelementptr %"compiler/eval:Machine", ptr %t203, i32 0, i32 55
  %t209 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3areg_3e_2eRefMut_3ccompiler_2feval_3areg_3e(ptr %v0, ptr %v0, ptr %t205, i64 %t201)
  store ptr %t209, ptr %l126
  br label %bb41
bb40:
  br label %bb42
bb41:
  %t210 = load ptr, ptr %l126, !tbaa !29
  %t212 = load i64, ptr %l14, !tbaa !24
  %t215 = getelementptr %"compiler/eval:reg", ptr %t210, i32 0, i32 5
  store i64 %t212, ptr %t215, !tbaa !24
  br label %bb42
bb42:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t218 = getelementptr %"compiler/eval:Machine", ptr %t216, i32 0, i32 56
  %t219 = load i64, ptr %l8, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t218, i64 %t219)
  br label %bb43
bb43:
  %t222 = getelementptr %"compiler/eval:reg", ptr %l9, i32 0, i32 0
  %t223 = load i64, ptr %t222, !tbaa !24
  %t224 = load i64, ptr @G_2ecompiler_2feval_2egDtor, !tbaa !24
  %t227 = icmp eq i64 %t223, %t224
  br i1 %t227, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s7
  %t229 = load ptr, ptr %l0, !tbaa !29
  store ptr %t229, ptr %l135, !tbaa !29
  %t230 = load i64, ptr %l1, !tbaa !24
  store i64 %t230, ptr %l136, !tbaa !24
  %t231 = getelementptr %"compiler/eval:reg", ptr %l9, i32 0, i32 1
  %t232 = load i64, ptr %t231, !tbaa !24
  %t234 = trunc i64 %t232 to i32
  store i32 %t234, ptr %l139, !tbaa !23
  %t236 = getelementptr %"compiler/eval:reg", ptr %l9, i32 0, i32 2
  %t237 = load i64, ptr %t236, !tbaa !24
  %t238 = getelementptr %"compiler/eval:reg", ptr %l9, i32 0, i32 3
  %t239 = load i64, ptr %t238, !tbaa !24
  %t242 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s7, i64 %t237, i64 %t239)
  store %"compiler/eval:Ptr" %t242, ptr %l142
  br label %bb46
bb45:
  %t243 = getelementptr %"compiler/eval:reg", ptr %l9, i32 0, i32 0
  %t244 = load i64, ptr %t243, !tbaa !24
  %t245 = load i64, ptr @G_2ecompiler_2feval_2egGen, !tbaa !24
  %t248 = icmp eq i64 %t244, %t245
  br i1 %t248, label %bb48, label %bb49
bb46:
  %t250 = load ptr, ptr %l135, !tbaa !29
  %t251 = load i64, ptr %l136, !tbaa !24
  %t252 = load i32, ptr %l139, !tbaa !23
  %t253 = load %"compiler/eval:Ptr", ptr %l142
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erunDtor(ptr %v0, ptr %t250, i64 %t251, i32 %t252, %"compiler/eval:Ptr" %t253)
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s7)
  br label %bb52
bb48:
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t255 = load i64, ptr %l1, !tbaa !24
  %t256 = getelementptr %"compiler/eval:reg", ptr %l9, i32 0, i32 1
  %t257 = load i64, ptr %t256, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ecloseGen(ptr %v0, ptr %t254, i64 %t255, i64 %t257)
  br label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb51
bb51:
  br label %bb52
bb52:
  br label %ret
bb53:
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t263 = getelementptr %"compiler/eval:Machine", ptr %t261, i32 0, i32 53
  %t264 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t265, ptr %v0, ptr %t263, i64 %t264)
  call void @llvm.memmove.p0.p0.i64(ptr %l152, ptr %t265, i64 152, i1 false)
  br label %bb54
bb54:
  %t268 = getelementptr %"compiler/eval:scope", ptr %l152, i32 0, i32 6
  %t269 = load i64, ptr %t268, !tbaa !24
  store i64 %t269, ptr %l16, !tbaa !24
  %t271 = load i64, ptr %l16, !tbaa !24
  %t273 = icmp ne i64 %t271, 0
  br i1 %t273, label %bb55, label %bb56
bb55:
  %t275 = load i64, ptr %l2, !tbaa !24
  store i64 %t275, ptr %l17, !tbaa !24
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t279 = getelementptr %"compiler/eval:Machine", ptr %t277, i32 0, i32 53
  %t280 = load i64, ptr %l16, !tbaa !24
  %t281 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t284 = and i64 %t280, %t281
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t285, ptr %v0, ptr %t279, i64 %t284)
  call void @llvm.memmove.p0.p0.i64(ptr %l162, ptr %t285, i64 152, i1 false)
  br label %bb57
bb56:
  br label %bb65
bb57:
  %t288 = getelementptr %"compiler/eval:scope", ptr %l162, i32 0, i32 7
  %t289 = load i64, ptr %t288, !tbaa !24
  store i64 %t289, ptr %l18, !tbaa !24
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t293 = getelementptr %"compiler/eval:Machine", ptr %t291, i32 0, i32 53
  %t294 = load i64, ptr %l17, !tbaa !24
  %t297 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eRefMut_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %v0, ptr %t293, i64 %t294)
  store ptr %t297, ptr %l167
  br label %bb58
bb58:
  %t298 = load ptr, ptr %l167, !tbaa !29
  %t300 = load i64, ptr %l18, !tbaa !24
  %t303 = getelementptr %"compiler/eval:scope", ptr %t298, i32 0, i32 6
  store i64 %t300, ptr %t303, !tbaa !24
  %t304 = load i64, ptr %l16, !tbaa !24
  %t305 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t308 = and i64 %t304, %t305
  store i64 0, ptr %l21, !tbaa !24
  %t310 = load ptr, ptr %l0, !tbaa !29
  %t312 = getelementptr %"compiler/eval:Machine", ptr %t310, i32 0, i32 53
  %t316 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eRefMut_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %v0, ptr %t312, i64 %t308)
  store ptr %t316, ptr %l176
  br label %bb59
bb59:
  %t317 = load ptr, ptr %l176, !tbaa !29
  %t319 = load i64, ptr %l21, !tbaa !24
  %t322 = getelementptr %"compiler/eval:scope", ptr %t317, i32 0, i32 5
  store i64 %t319, ptr %t322, !tbaa !24
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t324 = load i64, ptr %l16, !tbaa !24
  %t327 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2elive(ptr %v0, ptr %t323, i64 %t324)
  store i1 %t327, ptr %l181
  br label %bb60
bb60:
  %t328 = load i1, ptr %l181, !tbaa !21
  br i1 %t328, label %bb61, label %bb62
bb61:
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t331 = getelementptr %"compiler/eval:Machine", ptr %t329, i32 0, i32 63
  %t332 = load i64, ptr %l16, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t331, i64 %t332)
  br label %bb63
bb62:
  br label %bb64
bb63:
  br label %bb64
bb64:
  br label %ret
bb65:
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t337 = getelementptr %"compiler/eval:Machine", ptr %t335, i32 0, i32 17
  %t338 = load i1, ptr %t337, !tbaa !21
  br i1 %t338, label %bb66, label %bb67
bb66:
  %t340 = load ptr, ptr %l0, !tbaa !29
  %t342 = getelementptr %"compiler/eval:Machine", ptr %t340, i32 0, i32 53
  %t343 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t344, ptr %v0, ptr %t342, i64 %t343)
  call void @llvm.memmove.p0.p0.i64(ptr %l191, ptr %t344, i64 152, i1 false)
  br label %bb68
bb67:
  store i1 false, ptr %l187, !tbaa !21
  br label %bb69
bb68:
  %t347 = getelementptr %"compiler/eval:scope", ptr %l191, i32 0, i32 15
  %t348 = load i1, ptr %t347, !tbaa !21
  store i1 %t348, ptr %l187, !tbaa !21
  br label %bb69
bb69:
  %t350 = load i1, ptr %l187, !tbaa !21
  br i1 %t350, label %bb70, label %bb71
bb70:
  %t351 = load ptr, ptr %l0, !tbaa !29
  %t353 = getelementptr %"compiler/eval:Machine", ptr %t351, i32 0, i32 53
  %t354 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t355, ptr %v0, ptr %t353, i64 %t354)
  call void @llvm.memmove.p0.p0.i64(ptr %l196, ptr %t355, i64 152, i1 false)
  br label %bb72
bb71:
  br label %bb80
bb72:
  %t358 = getelementptr %"compiler/eval:scope", ptr %l196, i32 0, i32 3
  %t359 = load i64, ptr %t358, !tbaa !24
  store i64 %t359, ptr %l23, !tbaa !24
  br label %bb73
bb73:
  %t361 = load i64, ptr %l23, !tbaa !24
  %t363 = icmp ne i64 %t361, 0
  %t365 = xor i1 %t363, true
  br i1 %t365, label %bb74, label %bb75
bb74:
  br label %bb79
bb75:
  br label %bb76
bb76:
  %t367 = load ptr, ptr %l0, !tbaa !29
  %t369 = getelementptr %"compiler/eval:Machine", ptr %t367, i32 0, i32 18
  %t370 = load ptr, ptr %l0, !tbaa !29
  %t372 = getelementptr %"compiler/eval:Machine", ptr %t370, i32 0, i32 50
  %t373 = load { i64, ptr }, ptr %t372, !tbaa !27
  store { i64, ptr } %t373, ptr %l204, !tbaa !27
  %t374 = load i64, ptr %l23, !tbaa !24
  %t376 = getelementptr { i64, ptr }, ptr %l204, i32 0, i32 1
  %t377 = load ptr, ptr %t376, !tbaa !27
  %t378 = getelementptr %"compiler/eval:alloc", ptr %t377, i64 %t374
  %t379 = getelementptr %"compiler/eval:alloc", ptr %t378, i32 0, i32 3
  %t380 = load i64, ptr %t379, !tbaa !24
  %t381 = load i64, ptr @G_2ecompiler_2feval_2eslotBits, !tbaa !24
  store i64 %t381, ptr %l207, !tbaa !24
  %t383 = load i64, ptr %l207, !tbaa !24
  %t384 = load i64, ptr %l207, !tbaa !24
  %t385 = shl i64 %t380, %t384
  %t386 = load i64, ptr %l23, !tbaa !24
  %t389 = or i64 %t385, %t386
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t369, i64 %t389, i1 true)
  br label %bb77
bb77:
  br label %bb78
bb78:
  %t392 = load ptr, ptr %l0, !tbaa !29
  %t394 = getelementptr %"compiler/eval:Machine", ptr %t392, i32 0, i32 50
  %t395 = load { i64, ptr }, ptr %t394, !tbaa !27
  store { i64, ptr } %t395, ptr %l212, !tbaa !27
  %t396 = load i64, ptr %l23, !tbaa !24
  %t398 = getelementptr { i64, ptr }, ptr %l212, i32 0, i32 1
  %t399 = load ptr, ptr %t398, !tbaa !27
  %t400 = getelementptr %"compiler/eval:alloc", ptr %t399, i64 %t396
  %t401 = getelementptr %"compiler/eval:alloc", ptr %t400, i32 0, i32 7
  %t402 = load i64, ptr %t401, !tbaa !24
  store i64 %t402, ptr %l23, !tbaa !24
  br label %bb73
bb79:
  br label %bb80
bb80:
  br label %bb81
bb81:
  %t404 = load ptr, ptr %l0, !tbaa !29
  %t406 = getelementptr %"compiler/eval:Machine", ptr %t404, i32 0, i32 53
  %t407 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t408, ptr %v0, ptr %t406, i64 %t407)
  call void @llvm.memmove.p0.p0.i64(ptr %l218, ptr %t408, i64 152, i1 false)
  br label %bb82
bb82:
  %t411 = getelementptr %"compiler/eval:scope", ptr %l218, i32 0, i32 3
  %t412 = load i64, ptr %t411, !tbaa !24
  %t414 = icmp ne i64 %t412, 0
  %t416 = xor i1 %t414, true
  br i1 %t416, label %bb83, label %bb84
bb83:
  br label %bb89
bb84:
  br label %bb85
bb85:
  %t418 = load ptr, ptr %l0, !tbaa !29
  store ptr %t418, ptr %l222, !tbaa !29
  %t419 = load ptr, ptr %l0, !tbaa !29
  %t421 = getelementptr %"compiler/eval:Machine", ptr %t419, i32 0, i32 53
  %t422 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t423, ptr %v0, ptr %t421, i64 %t422)
  call void @llvm.memmove.p0.p0.i64(ptr %l226, ptr %t423, i64 152, i1 false)
  br label %bb86
bb86:
  %t426 = getelementptr %"compiler/eval:scope", ptr %l226, i32 0, i32 3
  %t427 = load i64, ptr %t426, !tbaa !24
  %t428 = load ptr, ptr %l222, !tbaa !29
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erelease(ptr %v0, ptr %t428, i64 %t427)
  br label %bb87
bb87:
  br label %bb88
bb88:
  br label %bb81
bb89:
  %t430 = load ptr, ptr %l0, !tbaa !29
  %t432 = getelementptr %"compiler/eval:Machine", ptr %t430, i32 0, i32 53
  %t433 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t434, ptr %v0, ptr %t432, i64 %t433)
  call void @llvm.memmove.p0.p0.i64(ptr %l231, ptr %t434, i64 152, i1 false)
  br label %bb90
bb90:
  call void @llvm.memmove.p0.p0.i64(ptr %l24, ptr %l231, i64 152, i1 false)
  %t437 = getelementptr %"compiler/eval:scope", ptr %l24, i32 0, i32 1
  store i1 false, ptr %t437, !tbaa !21
  %t438 = getelementptr %"compiler/eval:scope", ptr %l24, i32 0, i32 15
  store i1 false, ptr %t438, !tbaa !21
  %t439 = getelementptr %"compiler/eval:scope", ptr %l24, i32 0, i32 0
  %t440 = load i64, ptr %t439, !tbaa !24
  %t443 = add i64 %t440, 1
  %t445 = and i64 %t443, 274877906943
  %t447 = getelementptr %"compiler/eval:scope", ptr %l24, i32 0, i32 0
  store i64 %t445, ptr %t447, !tbaa !24
  %t448 = load ptr, ptr %l0, !tbaa !29
  %t450 = getelementptr %"compiler/eval:Machine", ptr %t448, i32 0, i32 53
  %t451 = load i64, ptr %l2, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l239, ptr %l24, i64 152, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %t454, ptr %l239, i64 152, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eSetAt_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %t450, i64 %t451, ptr %t454)
  br label %bb91
bb91:
  %t455 = load ptr, ptr %l0, !tbaa !29
  %t457 = getelementptr %"compiler/eval:Machine", ptr %t455, i32 0, i32 54
  %t458 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t457, i64 %t458)
  br label %bb92
bb92:
  %t461 = load ptr, ptr %l0, !tbaa !29
  %t463 = getelementptr %"compiler/eval:Machine", ptr %t461, i32 0, i32 63
  %t465 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t463)
  %t466 = extractvalue { i32, i64 } %t465, 1
  %t467 = extractvalue { i32, i64 } %t465, 0
  store i32 %t467, ptr %l247
  %t468 = icmp ne i32 %t467, 0
  br i1 %t468, label %bb94, label %ok.469, !prof !99
ok.469:
  store i64 %t466, ptr %l246
  br label %bb93
bb93:
  %t470 = load i64, ptr %l246, !tbaa !24
  store i64 %t470, ptr %l243, !tbaa !24
  br label %bb96
bb94:
  br label %bb95
bb95:
  br label %bb96
bb96:
  br label %ret
ret:
  ret void
}

define dso_local { { i64, ptr }, %"compiler/source:Span" } @compiler_2feval_2ecompiler_2feval_3aMachine_2ewhyStmt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, [21 x i64] } %a2) #0 {
entry:
  %l2 = alloca { i64, [21 x i64] }
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca %"compiler/mir:Lvalue"
  %l5 = alloca { i64, [15 x i64] }
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca { i64, [1 x i64] }
  %l8 = alloca { i64, [21 x i64] }
  %l14 = alloca i1
  %l18 = alloca { { i64, ptr }, %"compiler/source:Span" }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l25 = alloca i1
  %l29 = alloca { { i64, ptr }, %"compiler/source:Span" }
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, [21 x i64] }
  %l43 = alloca { { i64, ptr }, %"compiler/source:Span" }
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l49 = alloca %"compiler/source:Span"
  %l50 = alloca { { i64, ptr }, %"compiler/source:Span" }
  %l51 = alloca { i64, ptr }
  %l52 = alloca i64
  %l53 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { { i64, ptr }, %"compiler/source:Span" }
  store { i64, [21 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  call void @llvm.memmove.p0.p0.i64(ptr %l8, ptr %l2, i64 176, i1 false)
  %t1 = load { i64, [21 x i64] }, ptr %l8
  %t2 = extractvalue { i64, [21 x i64] } %t1, 0
  %t3 = icmp eq i64 %t2, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = getelementptr { i64, [21 x i64] }, ptr %l2, i32 0, i32 1
  %t6 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } }, ptr %t5, i32 0, i32 0
  %t7 = load %"compiler/source:Span", ptr %t6
  store %"compiler/source:Span" %t7, ptr %l3
  %t9 = getelementptr { i64, [21 x i64] }, ptr %l2, i32 0, i32 1
  %t10 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } }, ptr %t9, i32 0, i32 1
  %t11 = load %"compiler/mir:Lvalue", ptr %t10
  store %"compiler/mir:Lvalue" %t11, ptr %l4
  %t13 = getelementptr { i64, [21 x i64] }, ptr %l2, i32 0, i32 1
  %t14 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } }, ptr %t13, i32 0, i32 2
  %t15 = load { i64, [15 x i64] }, ptr %t14
  store { i64, [15 x i64] } %t15, ptr %l5
  br label %bb3
bb2:
  br label %bb12
bb3:
  %t17 = load %"compiler/mir:Lvalue", ptr %l4
  %t19 = call i1 @compiler_2feval_2eplaceNamesGlobal(%"compiler/mir:Lvalue" %t17)
  store i1 %t19, ptr %l14
  br label %bb4
bb4:
  %t20 = load i1, ptr %l14, !tbaa !21
  br i1 %t20, label %bb5, label %bb6
bb5:
  %t21 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyWritesGlobalVar, !tbaa !27
  %t23 = load %"compiler/source:Span", ptr %l3
  %t25 = insertvalue { { i64, ptr }, %"compiler/source:Span" } undef, { i64, ptr } %t21, 0
  %t27 = insertvalue { { i64, ptr }, %"compiler/source:Span" } %t25, %"compiler/source:Span" %t23, 1
  store { { i64, ptr }, %"compiler/source:Span" } %t27, ptr %l18
  %t28 = getelementptr { { i64, ptr }, %"compiler/source:Span" }, ptr %l18, i32 0, i32 0
  %t29 = load { i64, ptr }, ptr %t28, !tbaa !27
  store { i64, ptr } %t29, ptr %l19, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t30, 0
  store i64 %t31, ptr %l20, !tbaa !24
  %t32 = load i64, ptr %l20, !tbaa !24
  %t33 = mul i64 %t32, 1
  %t34 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t33)
  %t35 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  store { i64, ptr } %t36, ptr %l21, !tbaa !27
  %t37 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = load i64, ptr %l20, !tbaa !24
  %t42 = mul i64 %t41, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t38, ptr %t40, i64 %t42, i1 false)
  %t43 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t44 = getelementptr { { i64, ptr }, %"compiler/source:Span" }, ptr %l18, i32 0, i32 0
  store { i64, ptr } %t43, ptr %t44, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t45 = load { { i64, ptr }, %"compiler/source:Span" }, ptr %l18
  store { { i64, ptr }, %"compiler/source:Span" } %t45, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t48 = load { i64, [15 x i64] }, ptr %l5
  %t52 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2ereadsMutable(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [15 x i64] } %t48)
  store i1 %t52, ptr %l25
  br label %bb8
bb8:
  %t53 = load i1, ptr %l25, !tbaa !21
  br i1 %t53, label %bb9, label %bb10
bb9:
  %t54 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyMutableGlobal, !tbaa !27
  %t56 = load %"compiler/source:Span", ptr %l3
  %t58 = insertvalue { { i64, ptr }, %"compiler/source:Span" } undef, { i64, ptr } %t54, 0
  %t60 = insertvalue { { i64, ptr }, %"compiler/source:Span" } %t58, %"compiler/source:Span" %t56, 1
  store { { i64, ptr }, %"compiler/source:Span" } %t60, ptr %l29
  %t61 = getelementptr { { i64, ptr }, %"compiler/source:Span" }, ptr %l29, i32 0, i32 0
  %t62 = load { i64, ptr }, ptr %t61, !tbaa !27
  store { i64, ptr } %t62, ptr %l30, !tbaa !27
  %t63 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t63, 0
  store i64 %t64, ptr %l31, !tbaa !24
  %t65 = load i64, ptr %l31, !tbaa !24
  %t66 = mul i64 %t65, 1
  %t67 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t66)
  %t68 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  store { i64, ptr } %t69, ptr %l32, !tbaa !27
  %t70 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !27
  %t72 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = load i64, ptr %l31, !tbaa !24
  %t75 = mul i64 %t74, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t71, ptr %t73, i64 %t75, i1 false)
  %t76 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t77 = getelementptr { { i64, ptr }, %"compiler/source:Span" }, ptr %l29, i32 0, i32 0
  store { i64, ptr } %t76, ptr %t77, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t78 = load { { i64, ptr }, %"compiler/source:Span" }, ptr %l29
  store { { i64, ptr }, %"compiler/source:Span" } %t78, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  br label %bb24
bb12:
  call void @llvm.memmove.p0.p0.i64(ptr %l33, ptr %l2, i64 176, i1 false)
  %t79 = load { i64, [21 x i64] }, ptr %l33
  %t80 = extractvalue { i64, [21 x i64] } %t79, 0
  %t81 = icmp eq i64 %t80, 5
  br i1 %t81, label %bb13, label %bb14
bb13:
  %t83 = getelementptr { i64, [21 x i64] }, ptr %l2, i32 0, i32 1
  %t84 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t83, i32 0, i32 0
  %t85 = load %"compiler/source:Span", ptr %t84
  store %"compiler/source:Span" %t85, ptr %l6
  %t87 = getelementptr { i64, [21 x i64] }, ptr %l2, i32 0, i32 1
  %t88 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t87, i32 0, i32 1
  %t89 = load { i64, [1 x i64] }, ptr %t88
  store { i64, [1 x i64] } %t89, ptr %l7
  br label %bb15
bb14:
  br label %bb19
bb15:
  %t91 = load { i64, [1 x i64] }, ptr %l7
  %t93 = extractvalue { i64, [1 x i64] } %t91, 0
  %t94 = icmp eq i64 %t93, 2
  %t96 = xor i1 %t94, true
  br i1 %t96, label %bb16, label %bb17
bb16:
  %t98 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyDestructor, !tbaa !27
  %t100 = load %"compiler/source:Span", ptr %l6
  %t102 = insertvalue { { i64, ptr }, %"compiler/source:Span" } undef, { i64, ptr } %t98, 0
  %t104 = insertvalue { { i64, ptr }, %"compiler/source:Span" } %t102, %"compiler/source:Span" %t100, 1
  store { { i64, ptr }, %"compiler/source:Span" } %t104, ptr %l43
  %t105 = getelementptr { { i64, ptr }, %"compiler/source:Span" }, ptr %l43, i32 0, i32 0
  %t106 = load { i64, ptr }, ptr %t105, !tbaa !27
  store { i64, ptr } %t106, ptr %l44, !tbaa !27
  %t107 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t108 = extractvalue { i64, ptr } %t107, 0
  store i64 %t108, ptr %l45, !tbaa !24
  %t109 = load i64, ptr %l45, !tbaa !24
  %t110 = mul i64 %t109, 1
  %t111 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t110)
  %t112 = insertvalue { i64, ptr } undef, i64 %t109, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t111, 1
  store { i64, ptr } %t113, ptr %l46, !tbaa !27
  %t114 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !27
  %t118 = load i64, ptr %l45, !tbaa !24
  %t119 = mul i64 %t118, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t115, ptr %t117, i64 %t119, i1 false)
  %t120 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t121 = getelementptr { { i64, ptr }, %"compiler/source:Span" }, ptr %l43, i32 0, i32 0
  store { i64, ptr } %t120, ptr %t121, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t122 = load { { i64, ptr }, %"compiler/source:Span" }, ptr %l43
  store { { i64, ptr }, %"compiler/source:Span" } %t122, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  br label %bb24
bb19:
  br i1 true, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_14e567516c3eb5fb_1379a201658fd827)
  unreachable
bb24:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d3, i32 0, i32 1) }, ptr %l47, !tbaa !27
  %t123 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t123, ptr %l48, !tbaa !27
  %t124 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 0, i32 0)
  store %"compiler/source:Span" %t124, ptr %l49
  br label %bb25
bb25:
  %t125 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t126 = insertvalue { { i64, ptr }, %"compiler/source:Span" } undef, { i64, ptr } %t125, 0
  %t127 = load %"compiler/source:Span", ptr %l49
  %t128 = insertvalue { { i64, ptr }, %"compiler/source:Span" } %t126, %"compiler/source:Span" %t127, 1
  store { { i64, ptr }, %"compiler/source:Span" } %t128, ptr %l50
  %t129 = getelementptr { { i64, ptr }, %"compiler/source:Span" }, ptr %l50, i32 0, i32 0
  %t130 = load { i64, ptr }, ptr %t129, !tbaa !27
  store { i64, ptr } %t130, ptr %l51, !tbaa !27
  %t131 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t131, 0
  store i64 %t132, ptr %l52, !tbaa !24
  %t133 = load i64, ptr %l52, !tbaa !24
  %t134 = mul i64 %t133, 1
  %t135 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t134)
  %t136 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t137 = insertvalue { i64, ptr } %t136, ptr %t135, 1
  store { i64, ptr } %t137, ptr %l53, !tbaa !27
  %t138 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !27
  %t140 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !27
  %t142 = load i64, ptr %l52, !tbaa !24
  %t143 = mul i64 %t142, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t139, ptr %t141, i64 %t143, i1 false)
  %t144 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t145 = getelementptr { { i64, ptr }, %"compiler/source:Span" }, ptr %l50, i32 0, i32 0
  store { i64, ptr } %t144, ptr %t145, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t146 = load { { i64, ptr }, %"compiler/source:Span" }, ptr %l50
  store { { i64, ptr }, %"compiler/source:Span" } %t146, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, ptr }, %"compiler/source:Span" }, ptr %rv
  ret { { i64, ptr }, %"compiler/source:Span" } %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewideToFloat(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i1 %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i1
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, i64 }
  %l9 = alloca i64
  %l10 = alloca { i64, i64 }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca { i64, i64 }
  %l14 = alloca double
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l22 = alloca i1
  %l30 = alloca { i64, i64 }
  %l37 = alloca i64
  %l43 = alloca { i64, i64 }
  %l49 = alloca { i64, i64 }
  %l54 = alloca i1
  %l60 = alloca ptr
  %l64 = alloca i64
  %l66 = alloca double
  %l71 = alloca i64
  %l74 = alloca i64
  %l83 = alloca i64
  %l86 = alloca i1
  %l109 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  br i1 %a3, label %bb1, label %bb2
bb1:
  %t3 = load i64, ptr %l2, !tbaa !24
  %t5 = icmp slt i64 %t3, 0
  store i1 %t5, ptr %l22, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb3
bb3:
  %t7 = load i1, ptr %l22, !tbaa !21
  store i1 %t7, ptr %l5, !tbaa !21
  %t8 = load i64, ptr %l1, !tbaa !24
  store i64 %t8, ptr %l6, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  store i64 %t10, ptr %l7, !tbaa !24
  %t12 = load i1, ptr %l5, !tbaa !21
  br i1 %t12, label %bb4, label %bb5
bb4:
  %t14 = load i64, ptr %l1, !tbaa !24
  %t15 = load i64, ptr %l2, !tbaa !24
  %t18 = call { i64, i64 } @compiler_2feval_2eneg128(i64 %t14, i64 %t15)
  store { i64, i64 } %t18, ptr %l30
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t19 = load { i64, i64 }, ptr %l30
  store { i64, i64 } %t19, ptr %l8
  %t20 = getelementptr { i64, i64 }, ptr %l8, i32 0, i32 0
  %t21 = load i64, ptr %t20, !tbaa !24
  store i64 %t21, ptr %l6, !tbaa !24
  %t23 = getelementptr { i64, i64 }, ptr %l8, i32 0, i32 1
  %t24 = load i64, ptr %t23, !tbaa !24
  store i64 %t24, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  store i64 0, ptr %l9, !tbaa !24
  %t26 = load i64, ptr %l7, !tbaa !24
  %t28 = icmp ne i64 %t26, 0
  br i1 %t28, label %bb8, label %bb9
bb8:
  %t30 = load i64, ptr %l6, !tbaa !24
  %t31 = load i64, ptr %l7, !tbaa !24
  %t34 = call i64 @compiler_2feval_2elz128(i64 %t30, i64 %t31, i64 128)
  store i64 %t34, ptr %l37
  br label %bb10
bb9:
  br label %bb19
bb10:
  %t35 = load i64, ptr %l37, !tbaa !24
  %t36 = sub i64 128, %t35
  %t38 = sub i64 %t36, 63
  store i64 %t38, ptr %l9, !tbaa !24
  %t40 = load i64, ptr %l6, !tbaa !24
  %t41 = load i64, ptr %l7, !tbaa !24
  %t42 = load i64, ptr %l9, !tbaa !24
  %t46 = call { i64, i64 } @compiler_2feval_2eextend128(i64 %t40, i64 %t41, i64 %t42, i1 false)
  store { i64, i64 } %t46, ptr %l43
  br label %bb11
bb11:
  %t47 = load { i64, i64 }, ptr %l43
  store { i64, i64 } %t47, ptr %l10
  %t48 = getelementptr { i64, i64 }, ptr %l10, i32 0, i32 0
  %t49 = load i64, ptr %t48, !tbaa !24
  store i64 %t49, ptr %l11, !tbaa !24
  %t51 = getelementptr { i64, i64 }, ptr %l10, i32 0, i32 1
  %t52 = load i64, ptr %t51, !tbaa !24
  store i64 %t52, ptr %l12, !tbaa !24
  %t54 = load i64, ptr %l6, !tbaa !24
  %t55 = load i64, ptr %l7, !tbaa !24
  %t56 = load i64, ptr %l9, !tbaa !24
  %t60 = call { i64, i64 } @compiler_2feval_2eshr128(i64 %t54, i64 %t55, i64 %t56, i1 false)
  store { i64, i64 } %t60, ptr %l49
  br label %bb12
bb12:
  %t61 = load { i64, i64 }, ptr %l49
  store { i64, i64 } %t61, ptr %l13
  %t62 = getelementptr { i64, i64 }, ptr %l13, i32 0, i32 0
  %t63 = load i64, ptr %t62, !tbaa !24
  store i64 %t63, ptr %l6, !tbaa !24
  %t65 = getelementptr { i64, i64 }, ptr %l13, i32 0, i32 1
  %t66 = load i64, ptr %t65, !tbaa !24
  store i64 %t66, ptr %l7, !tbaa !24
  %t68 = load i64, ptr %l11, !tbaa !24
  %t70 = icmp ne i64 %t68, 0
  br i1 %t70, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l54, !tbaa !21
  br label %bb15
bb14:
  %t72 = load i64, ptr %l12, !tbaa !24
  %t74 = icmp ne i64 %t72, 0
  store i1 %t74, ptr %l54, !tbaa !21
  br label %bb15
bb15:
  %t76 = load i1, ptr %l54, !tbaa !21
  br i1 %t76, label %bb16, label %bb17
bb16:
  %t77 = load i64, ptr %l6, !tbaa !24
  %t80 = or i64 %t77, 1
  store i64 %t80, ptr %l6, !tbaa !24
  br label %bb18
bb17:
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t82 = load ptr, ptr %l0, !tbaa !29
  store ptr %t82, ptr %l60, !tbaa !29
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load i64, ptr %l6, !tbaa !24
  %t85 = load i32, ptr %l4, !tbaa !23
  %t89 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintToFloat(ptr %v0, ptr %t83, i64 %t84, i1 true, i32 %t85)
  store i64 %t89, ptr %l64
  br label %bb20
bb20:
  %t90 = load i32, ptr %l4, !tbaa !23
  %t91 = load ptr, ptr %l60, !tbaa !29
  %t92 = load i64, ptr %l64, !tbaa !24
  %t94 = call double @compiler_2feval_2ecompiler_2feval_3aMachine_2etoF64(ptr %v0, ptr %t91, i64 %t92, i32 %t90)
  store double %t94, ptr %l66
  br label %bb21
bb21:
  %t95 = load double, ptr %l66, !tbaa !26
  store double %t95, ptr %l14, !tbaa !26
  store i64 0, ptr %l15, !tbaa !24
  %t96 = load i64, ptr %l9, !tbaa !24
  store i64 %t96, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t98 = load i64, ptr %l16, !tbaa !24
  %t99 = load i64, ptr %l15, !tbaa !24
  %t102 = icmp sgt i64 %t98, %t99
  br i1 %t102, label %bb22, label %bb23
bb22:
  %t104 = load i64, ptr %l17, !tbaa !24
  %t106 = icmp sgt i64 %t104, 0
  br i1 %t106, label %bb24, label %bb25
bb23:
  store i64 0, ptr %l71, !tbaa !24
  br label %bb27
bb24:
  %t108 = load i64, ptr %l16, !tbaa !24
  %t109 = load i64, ptr %l15, !tbaa !24
  %t112 = sub i64 %t108, %t109
  %t113 = load i64, ptr %l17, !tbaa !24
  %t116 = add i64 %t112, %t113
  %t118 = sub i64 %t116, 1
  %t119 = load i64, ptr %l17, !tbaa !24
  %t122 = sdiv i64 %t118, %t119
  store i64 %t122, ptr %l74, !tbaa !24
  br label %bb26
bb25:
  store i64 0, ptr %l74, !tbaa !24
  br label %bb26
bb26:
  %t124 = load i64, ptr %l74, !tbaa !24
  store i64 %t124, ptr %l71, !tbaa !24
  br label %bb27
bb27:
  %t125 = load i64, ptr %l71, !tbaa !24
  store i64 %t125, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  %t126 = load i64, ptr %l18, !tbaa !24
  %t127 = sub i64 %t126, 1
  store i64 %t127, ptr %l83, !tbaa !24
  %t128 = load i64, ptr %l18, !tbaa !24
  %t129 = icmp slt i64 %t128, 2147483648
  %t130 = load i64, ptr %l19, !tbaa !24
  %t131 = icmp sge i64 %t130, 0
  %t134 = and i1 %t129, %t131
  store i1 %t134, ptr %l86, !tbaa !21
  br label %bb28
bb28:
  %t135 = load i64, ptr %l19, !tbaa !24
  %t136 = load i64, ptr %l18, !tbaa !24
  %t139 = icmp slt i64 %t135, %t136
  %t141 = xor i1 %t139, true
  br i1 %t141, label %bb29, label %bb30
bb29:
  br label %bb33
bb30:
  br label %bb31
bb31:
  %t143 = load i64, ptr %l15, !tbaa !24
  %t144 = load i64, ptr %l19, !tbaa !24
  %t145 = load i64, ptr %l17, !tbaa !24
  %t148 = mul i64 %t144, %t145
  %t151 = add i64 %t143, %t148
  store i64 %t151, ptr %l20, !tbaa !24
  %t153 = load double, ptr %l14, !tbaa !26
  %t156 = fmul double %t153, 0x4000000000000000
  store double %t156, ptr %l14, !tbaa !26
  br label %bb32
bb32:
  %t158 = load i64, ptr %l19, !tbaa !24
  %t161 = add i64 %t158, 1
  store i64 %t161, ptr %l19, !tbaa !24
  br label %bb28
bb33:
  %t163 = load i1, ptr %l5, !tbaa !21
  br i1 %t163, label %bb34, label %bb35
bb34:
  %t165 = load double, ptr %l14, !tbaa !26
  %t168 = fneg double %t165
  store double %t168, ptr %l14, !tbaa !26
  br label %bb36
bb35:
  br label %bb36
bb36:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load double, ptr %l14, !tbaa !26
  %t172 = load i32, ptr %l4, !tbaa !23
  %t176 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2efromF64(ptr %v0, ptr %t170, double %t171, i32 %t172)
  store i64 %t176, ptr %l109
  br label %bb37
bb37:
  %t177 = load i64, ptr %l109, !tbaa !24
  store i64 %t177, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrite(ptr %v0, ptr %a0, i64 %a1, { i64, [1 x i64] } %a2, i32 %a3, { i64, [4 x i64] } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i32
  %l4 = alloca { i64, [4 x i64] }
  %l5 = alloca i64
  %l6 = alloca i32
  %l8 = alloca { %"compiler/eval:Ptr", i64 }
  %l9 = alloca %"compiler/eval:Ptr"
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l18 = alloca { %"compiler/eval:Ptr", i64 }
  %l19 = alloca %"compiler/eval:Ptr"
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l27 = alloca { i64, i64 }
  %l33 = alloca i64
  %l36 = alloca i1
  %l43 = alloca i32
  %l49 = alloca %"compiler/eval:Ptr"
  %l53 = alloca { %"compiler/eval:Ptr", i64 }
  %l62 = alloca i64
  %l65 = alloca i64
  %l83 = alloca ptr
  %l84 = alloca i64
  %l85 = alloca ptr
  %l90 = alloca %"compiler/eval:Ptr"
  %l91 = alloca i64
  %l97 = alloca ptr
  %l98 = alloca i64
  %l102 = alloca i64
  %l108 = alloca %"compiler/eval:Ptr"
  %l112 = alloca { %"compiler/eval:Ptr", i64 }
  %l123 = alloca i64
  %l126 = alloca i64
  %l144 = alloca ptr
  %l145 = alloca i64
  %l146 = alloca ptr
  %l151 = alloca %"compiler/eval:Ptr"
  %l152 = alloca i64
  %l162 = alloca ptr
  %l163 = alloca i64
  %l167 = alloca i64
  %l172 = alloca ptr
  %l173 = alloca i64
  %l177 = alloca i64
  %l179 = alloca { i64, ptr }
  %l186 = alloca i64
  %l192 = alloca { i64, i64 }
  %l195 = alloca ptr
  %l196 = alloca i64
  %l201 = alloca { i64, ptr }
  %l205 = alloca ptr
  %l206 = alloca i64
  %l207 = alloca ptr
  %l211 = alloca i64
  %l213 = alloca i64
  %l216 = alloca ptr
  %l217 = alloca i64
  %l221 = alloca i64
  %l227 = alloca ptr
  %l228 = alloca i64
  %l229 = alloca ptr
  %l233 = alloca i64
  %l235 = alloca { i64, ptr }
  %s5 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s22 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a3, ptr %l3
  store { i64, [4 x i64] } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t7 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escopeOf(ptr %v0, ptr %t1, i64 %t2, { i64, [1 x i64] } %a2)
  store i64 %t7, ptr %l33
  br label %bb1
bb1:
  %t8 = load i64, ptr %l33, !tbaa !24
  store i64 %t8, ptr %l5, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i64, ptr %l5, !tbaa !24
  %t13 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2elive(ptr %v0, ptr %t9, i64 %t10)
  store i1 %t13, ptr %l36
  br label %bb2
bb2:
  %t14 = load i1, ptr %l36, !tbaa !21
  %t15 = xor i1 %t14, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyClosed, !tbaa !27
  %t19 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t19, ptr %t17, { i64, ptr } %t18)
  br label %bb5
bb4:
  br label %bb6
bb5:
  br label %ret
bb6:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i64, ptr %l1, !tbaa !24
  %t24 = load { i64, [4 x i64] }, ptr %l4
  %t28 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eopType(ptr %v0, ptr %t22, i64 %t23, { i64, [4 x i64] } %t24)
  store i32 %t28, ptr %l43
  br label %bb7
bb7:
  %t29 = load i32, ptr %l43, !tbaa !23
  store i32 %t29, ptr %l6, !tbaa !23
  %t30 = load i32, ptr %l3, !range !{i32 0, i32 8}
  %t32 = trunc i64 0 to i32
  %t33 = icmp eq i32 %t30, %t32
  br i1 %t33, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb31
bb10:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load i64, ptr %l1, !tbaa !24
  %t37 = load { i64, [4 x i64] }, ptr %l4
  %t41 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddr(ptr %v0, ptr %t35, i64 %t36, { i64, [4 x i64] } %t37, i64 1)
  store %"compiler/eval:Ptr" %t41, ptr %l49
  br label %bb11
bb11:
  %t42 = load %"compiler/eval:Ptr", ptr %l49
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = load i32, ptr %l6, !tbaa !23
  %t49 = call { %"compiler/eval:Ptr", i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2earrayView(ptr %v0, ptr %t43, %"compiler/eval:Ptr" %t42, i32 %t45)
  store { %"compiler/eval:Ptr", i64 } %t49, ptr %l53
  br label %bb12
bb12:
  %t50 = load { %"compiler/eval:Ptr", i64 }, ptr %l53
  store { %"compiler/eval:Ptr", i64 } %t50, ptr %l8
  %t51 = getelementptr { %"compiler/eval:Ptr", i64 }, ptr %l8, i32 0, i32 0
  %t52 = load %"compiler/eval:Ptr", ptr %t51
  store %"compiler/eval:Ptr" %t52, ptr %l9
  %t54 = getelementptr { %"compiler/eval:Ptr", i64 }, ptr %l8, i32 0, i32 1
  %t55 = load i64, ptr %t54, !tbaa !24
  store i64 %t55, ptr %l10, !tbaa !24
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/eval:Machine", ptr %t57, i32 0, i32 23
  %t60 = load i1, ptr %t59, !tbaa !21
  br i1 %t60, label %bb13, label %bb14
bb13:
  br label %ret
bb14:
  br label %bb15
bb15:
  store i64 0, ptr %l11, !tbaa !24
  %t62 = load i64, ptr %l10, !tbaa !24
  store i64 %t62, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t64 = load i64, ptr %l12, !tbaa !24
  %t65 = load i64, ptr %l11, !tbaa !24
  %t68 = icmp sgt i64 %t64, %t65
  br i1 %t68, label %bb16, label %bb17
bb16:
  %t70 = load i64, ptr %l13, !tbaa !24
  %t72 = icmp sgt i64 %t70, 0
  br i1 %t72, label %bb18, label %bb19
bb17:
  store i64 0, ptr %l62, !tbaa !24
  br label %bb21
bb18:
  %t74 = load i64, ptr %l12, !tbaa !24
  %t75 = load i64, ptr %l11, !tbaa !24
  %t78 = sub i64 %t74, %t75
  %t79 = load i64, ptr %l13, !tbaa !24
  %t82 = add i64 %t78, %t79
  %t84 = sub i64 %t82, 1
  %t85 = load i64, ptr %l13, !tbaa !24
  %t88 = sdiv i64 %t84, %t85
  store i64 %t88, ptr %l65, !tbaa !24
  br label %bb20
bb19:
  store i64 0, ptr %l65, !tbaa !24
  br label %bb20
bb20:
  %t90 = load i64, ptr %l65, !tbaa !24
  store i64 %t90, ptr %l62, !tbaa !24
  br label %bb21
bb21:
  %t91 = load i64, ptr %l62, !tbaa !24
  store i64 %t91, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb22
bb22:
  store %olang.scope zeroinitializer, ptr %s5
  %t92 = load i64, ptr %l15, !tbaa !24
  %t93 = load i64, ptr %l14, !tbaa !24
  %t96 = icmp slt i64 %t92, %t93
  %t98 = xor i1 %t96, true
  br i1 %t98, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s5)
  br label %bb30
bb24:
  br label %bb25
bb25:
  %t100 = load i64, ptr %l11, !tbaa !24
  %t101 = load i64, ptr %l15, !tbaa !24
  %t102 = load i64, ptr %l13, !tbaa !24
  %t105 = mul i64 %t101, %t102
  %t108 = add i64 %t100, %t105
  %t110 = load ptr, ptr %l0, !tbaa !29
  store ptr %t110, ptr %l83, !tbaa !29
  %t111 = load i64, ptr %l5, !tbaa !24
  store i64 %t111, ptr %l84, !tbaa !24
  %t112 = load ptr, ptr %l0, !tbaa !29
  store ptr %t112, ptr %l85, !tbaa !29
  %t113 = getelementptr %"compiler/eval:Ptr", ptr %l9, i32 0, i32 0
  %t114 = load i64, ptr %t113, !tbaa !24
  %t115 = getelementptr %"compiler/eval:Ptr", ptr %l9, i32 0, i32 1
  %t116 = load i64, ptr %t115, !tbaa !24
  %t120 = add i64 %t116, %t108
  %t123 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s5, i64 %t114, i64 %t120)
  store %"compiler/eval:Ptr" %t123, ptr %l90
  br label %bb26
bb26:
  %t124 = load ptr, ptr %l85, !tbaa !29
  %t125 = load %"compiler/eval:Ptr", ptr %l90
  %t126 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t124, %"compiler/eval:Ptr" %t125, i64 1)
  store i64 %t126, ptr %l91
  br label %bb27
bb27:
  %t127 = load ptr, ptr %l83, !tbaa !29
  %t128 = load i64, ptr %l84, !tbaa !24
  %t129 = load i64, ptr %l91, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eappendByte(ptr %v0, ptr %t127, i64 %t128, i64 %t129)
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s5)
  br label %bb29
bb29:
  %t130 = load i64, ptr %l15, !tbaa !24
  %t133 = add i64 %t130, 1
  store i64 %t133, ptr %l15, !tbaa !24
  br label %bb22
bb30:
  br label %bb109
bb31:
  %t135 = load i32, ptr %l3, !range !{i32 0, i32 8}
  %t137 = trunc i64 2 to i32
  %t138 = icmp eq i32 %t135, %t137
  br i1 %t138, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb37
bb34:
  %t140 = load ptr, ptr %l0, !tbaa !29
  store ptr %t140, ptr %l97, !tbaa !29
  %t141 = load i64, ptr %l5, !tbaa !24
  store i64 %t141, ptr %l98, !tbaa !24
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t143 = load i64, ptr %l1, !tbaa !24
  %t144 = load { i64, [4 x i64] }, ptr %l4
  %t148 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %t142, i64 %t143, { i64, [4 x i64] } %t144)
  store i64 %t148, ptr %l102
  br label %bb35
bb35:
  %t149 = load ptr, ptr %l97, !tbaa !29
  %t150 = load i64, ptr %l98, !tbaa !24
  %t151 = load i64, ptr %l102, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eappendByte(ptr %v0, ptr %t149, i64 %t150, i64 %t151)
  br label %bb36
bb36:
  br label %bb109
bb37:
  %t152 = load i32, ptr %l3, !range !{i32 0, i32 8}
  %t154 = trunc i64 1 to i32
  %t155 = icmp eq i32 %t152, %t154
  br i1 %t155, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb63
bb40:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load i64, ptr %l1, !tbaa !24
  %t159 = load { i64, [4 x i64] }, ptr %l4
  %t163 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddr(ptr %v0, ptr %t157, i64 %t158, { i64, [4 x i64] } %t159, i64 1)
  store %"compiler/eval:Ptr" %t163, ptr %l108
  br label %bb41
bb41:
  %t164 = load %"compiler/eval:Ptr", ptr %l108
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = load i32, ptr %l6, !tbaa !23
  %t171 = call { %"compiler/eval:Ptr", i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2earrayView(ptr %v0, ptr %t165, %"compiler/eval:Ptr" %t164, i32 %t167)
  store { %"compiler/eval:Ptr", i64 } %t171, ptr %l112
  br label %bb42
bb42:
  %t172 = load { %"compiler/eval:Ptr", i64 }, ptr %l112
  store { %"compiler/eval:Ptr", i64 } %t172, ptr %l18
  %t173 = getelementptr { %"compiler/eval:Ptr", i64 }, ptr %l18, i32 0, i32 0
  %t174 = load %"compiler/eval:Ptr", ptr %t173
  store %"compiler/eval:Ptr" %t174, ptr %l19
  %t176 = getelementptr { %"compiler/eval:Ptr", i64 }, ptr %l18, i32 0, i32 1
  %t177 = load i64, ptr %t176, !tbaa !24
  store i64 %t177, ptr %l20, !tbaa !24
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr %"compiler/eval:Machine", ptr %t179, i32 0, i32 23
  %t182 = load i1, ptr %t181, !tbaa !21
  br i1 %t182, label %bb43, label %bb44
bb43:
  br label %ret
bb44:
  br label %bb45
bb45:
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t185 = load i64, ptr %l5, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eappendByte(ptr %v0, ptr %t184, i64 %t185, i64 34)
  br label %bb46
bb46:
  store i64 0, ptr %l21, !tbaa !24
  %t188 = load i64, ptr %l20, !tbaa !24
  store i64 %t188, ptr %l22, !tbaa !24
  store i64 1, ptr %l23, !tbaa !24
  %t190 = load i64, ptr %l22, !tbaa !24
  %t191 = load i64, ptr %l21, !tbaa !24
  %t194 = icmp sgt i64 %t190, %t191
  br i1 %t194, label %bb47, label %bb48
bb47:
  %t196 = load i64, ptr %l23, !tbaa !24
  %t198 = icmp sgt i64 %t196, 0
  br i1 %t198, label %bb49, label %bb50
bb48:
  store i64 0, ptr %l123, !tbaa !24
  br label %bb52
bb49:
  %t200 = load i64, ptr %l22, !tbaa !24
  %t201 = load i64, ptr %l21, !tbaa !24
  %t204 = sub i64 %t200, %t201
  %t205 = load i64, ptr %l23, !tbaa !24
  %t208 = add i64 %t204, %t205
  %t210 = sub i64 %t208, 1
  %t211 = load i64, ptr %l23, !tbaa !24
  %t214 = sdiv i64 %t210, %t211
  store i64 %t214, ptr %l126, !tbaa !24
  br label %bb51
bb50:
  store i64 0, ptr %l126, !tbaa !24
  br label %bb51
bb51:
  %t216 = load i64, ptr %l126, !tbaa !24
  store i64 %t216, ptr %l123, !tbaa !24
  br label %bb52
bb52:
  %t217 = load i64, ptr %l123, !tbaa !24
  store i64 %t217, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  br label %bb53
bb53:
  store %olang.scope zeroinitializer, ptr %s11
  %t218 = load i64, ptr %l25, !tbaa !24
  %t219 = load i64, ptr %l24, !tbaa !24
  %t222 = icmp slt i64 %t218, %t219
  %t224 = xor i1 %t222, true
  br i1 %t224, label %bb54, label %bb55
bb54:
  call void @__olang_scope_close(ptr %s11)
  br label %bb61
bb55:
  br label %bb56
bb56:
  %t226 = load i64, ptr %l21, !tbaa !24
  %t227 = load i64, ptr %l25, !tbaa !24
  %t228 = load i64, ptr %l23, !tbaa !24
  %t231 = mul i64 %t227, %t228
  %t234 = add i64 %t226, %t231
  %t236 = load ptr, ptr %l0, !tbaa !29
  store ptr %t236, ptr %l144, !tbaa !29
  %t237 = load i64, ptr %l5, !tbaa !24
  store i64 %t237, ptr %l145, !tbaa !24
  %t238 = load ptr, ptr %l0, !tbaa !29
  store ptr %t238, ptr %l146, !tbaa !29
  %t239 = getelementptr %"compiler/eval:Ptr", ptr %l19, i32 0, i32 0
  %t240 = load i64, ptr %t239, !tbaa !24
  %t241 = getelementptr %"compiler/eval:Ptr", ptr %l19, i32 0, i32 1
  %t242 = load i64, ptr %t241, !tbaa !24
  %t246 = add i64 %t242, %t234
  %t249 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s11, i64 %t240, i64 %t246)
  store %"compiler/eval:Ptr" %t249, ptr %l151
  br label %bb57
bb57:
  %t250 = load ptr, ptr %l146, !tbaa !29
  %t251 = load %"compiler/eval:Ptr", ptr %l151
  %t252 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t250, %"compiler/eval:Ptr" %t251, i64 1)
  store i64 %t252, ptr %l152
  br label %bb58
bb58:
  %t253 = load ptr, ptr %l144, !tbaa !29
  %t254 = load i64, ptr %l145, !tbaa !24
  %t255 = load i64, ptr %l152, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eappendEscaped(ptr %v0, ptr %t253, i64 %t254, i64 %t255, i64 34)
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s11)
  br label %bb60
bb60:
  %t256 = load i64, ptr %l25, !tbaa !24
  %t259 = add i64 %t256, 1
  store i64 %t259, ptr %l25, !tbaa !24
  br label %bb53
bb61:
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t262 = load i64, ptr %l5, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eappendByte(ptr %v0, ptr %t261, i64 %t262, i64 34)
  br label %bb62
bb62:
  br label %bb109
bb63:
  %t265 = load i32, ptr %l3, !range !{i32 0, i32 8}
  %t267 = trunc i64 3 to i32
  %t268 = icmp eq i32 %t265, %t267
  br i1 %t268, label %bb64, label %bb65
bb64:
  br label %bb66
bb65:
  br label %bb71
bb66:
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t271 = load i64, ptr %l5, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eappendByte(ptr %v0, ptr %t270, i64 %t271, i64 39)
  br label %bb67
bb67:
  %t274 = load ptr, ptr %l0, !tbaa !29
  store ptr %t274, ptr %l162, !tbaa !29
  %t275 = load i64, ptr %l5, !tbaa !24
  store i64 %t275, ptr %l163, !tbaa !24
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t277 = load i64, ptr %l1, !tbaa !24
  %t278 = load { i64, [4 x i64] }, ptr %l4
  %t282 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %t276, i64 %t277, { i64, [4 x i64] } %t278)
  store i64 %t282, ptr %l167
  br label %bb68
bb68:
  %t283 = load ptr, ptr %l162, !tbaa !29
  %t284 = load i64, ptr %l163, !tbaa !24
  %t285 = load i64, ptr %l167, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eappendEscaped(ptr %v0, ptr %t283, i64 %t284, i64 %t285, i64 39)
  br label %bb69
bb69:
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t287 = load i64, ptr %l5, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eappendByte(ptr %v0, ptr %t286, i64 %t287, i64 39)
  br label %bb70
bb70:
  br label %bb109
bb71:
  %t290 = load i32, ptr %l3, !range !{i32 0, i32 8}
  %t292 = trunc i64 7 to i32
  %t293 = icmp eq i32 %t290, %t292
  br i1 %t293, label %bb72, label %bb73
bb72:
  br label %bb74
bb73:
  br label %bb80
bb74:
  store %olang.scope zeroinitializer, ptr %s14
  %t295 = load ptr, ptr %l0, !tbaa !29
  store ptr %t295, ptr %l172, !tbaa !29
  %t296 = load i64, ptr %l5, !tbaa !24
  store i64 %t296, ptr %l173, !tbaa !24
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t298 = load i64, ptr %l1, !tbaa !24
  %t299 = load { i64, [4 x i64] }, ptr %l4
  %t303 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %t297, i64 %t298, { i64, [4 x i64] } %t299)
  store i64 %t303, ptr %l177
  br label %bb75
bb75:
  %t304 = load i64, ptr %l177, !tbaa !24
  %t305 = icmp ne i64 %t304, 0
  br i1 %t305, label %bb76, label %bb77
bb76:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d4, i32 0, i32 1) }, ptr %l179, !tbaa !27
  br label %bb78
bb77:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d5, i32 0, i32 1) }, ptr %l179, !tbaa !27
  br label %bb78
bb78:
  %t307 = load ptr, ptr %l172, !tbaa !29
  %t308 = load i64, ptr %l173, !tbaa !24
  %t309 = load { i64, ptr }, ptr %l179, !tbaa !27
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eappendText(ptr %v0, ptr %s14, ptr %t307, i64 %t308, { i64, ptr } %t309)
  br label %bb79
bb79:
  call void @__olang_scope_close(ptr %s14)
  br label %bb109
bb80:
  %t310 = load i32, ptr %l3, !range !{i32 0, i32 8}
  %t312 = trunc i64 4 to i32
  %t313 = icmp eq i32 %t310, %t312
  br i1 %t313, label %bb81, label %bb82
bb81:
  br label %bb85
bb82:
  %t315 = load i32, ptr %l3, !range !{i32 0, i32 8}
  %t317 = trunc i64 5 to i32
  %t318 = icmp eq i32 %t315, %t317
  br i1 %t318, label %bb83, label %bb84
bb83:
  br label %bb85
bb84:
  br label %bb101
bb85:
  %t320 = load ptr, ptr %l0, !tbaa !29
  %t321 = load i32, ptr %l6, !tbaa !23
  %t324 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t320, i32 %t321)
  store i64 %t324, ptr %l186
  br label %bb86
bb86:
  %t325 = load i64, ptr @G_2ecompiler_2feval_2evWide, !tbaa !24
  %t326 = load i64, ptr %l186, !tbaa !24
  %t328 = icmp eq i64 %t326, %t325
  br i1 %t328, label %bb87, label %bb88
bb87:
  store %olang.scope zeroinitializer, ptr %s16
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t331 = load i64, ptr %l1, !tbaa !24
  %t332 = load { i64, [4 x i64] }, ptr %l4
  %t336 = call { i64, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2ewideOf(ptr %v0, ptr %t330, i64 %t331, { i64, [4 x i64] } %t332)
  store { i64, i64 } %t336, ptr %l192
  br label %bb89
bb88:
  %t337 = load i32, ptr %l3, !range !{i32 0, i32 8}
  %t339 = trunc i64 4 to i32
  %t340 = icmp eq i32 %t337, %t339
  br i1 %t340, label %bb92, label %bb93
bb89:
  %t342 = load { i64, i64 }, ptr %l192
  store { i64, i64 } %t342, ptr %l27
  %t343 = getelementptr { i64, i64 }, ptr %l27, i32 0, i32 0
  %t344 = load i64, ptr %t343, !tbaa !24
  %t346 = getelementptr { i64, i64 }, ptr %l27, i32 0, i32 1
  %t347 = load i64, ptr %t346, !tbaa !24
  %t349 = load ptr, ptr %l0, !tbaa !29
  store ptr %t349, ptr %l195, !tbaa !29
  %t350 = load i64, ptr %l5, !tbaa !24
  store i64 %t350, ptr %l196, !tbaa !24
  %t353 = load i32, ptr %l3, !range !{i32 0, i32 8}
  %t355 = trunc i64 4 to i32
  %t356 = icmp eq i32 %t353, %t355
  %t360 = call { i64, ptr } @compiler_2feval_2ewideText(ptr %s16, i64 %t344, i64 %t347, i1 %t356)
  store { i64, ptr } %t360, ptr %l201
  br label %bb90
bb90:
  %t361 = load { i64, ptr }, ptr %l201, !tbaa !27
  %t362 = load ptr, ptr %l195, !tbaa !29
  %t363 = load i64, ptr %l196, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eappendText(ptr %v0, ptr %s16, ptr %t362, i64 %t363, { i64, ptr } %t361)
  br label %bb91
bb91:
  call void @__olang_scope_close(ptr %s16)
  br label %bb100
bb92:
  store %olang.scope zeroinitializer, ptr %s18
  %t365 = load ptr, ptr %l0, !tbaa !29
  store ptr %t365, ptr %l205, !tbaa !29
  %t366 = load i64, ptr %l5, !tbaa !24
  store i64 %t366, ptr %l206, !tbaa !24
  %t367 = load ptr, ptr %l0, !tbaa !29
  store ptr %t367, ptr %l207, !tbaa !29
  %t368 = load ptr, ptr %l0, !tbaa !29
  %t369 = load i64, ptr %l1, !tbaa !24
  %t370 = load { i64, [4 x i64] }, ptr %l4
  %t374 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %t368, i64 %t369, { i64, [4 x i64] } %t370)
  store i64 %t374, ptr %l211
  br label %bb94
bb93:
  store %olang.scope zeroinitializer, ptr %s20
  %t375 = load ptr, ptr %l0, !tbaa !29
  store ptr %t375, ptr %l216, !tbaa !29
  %t376 = load i64, ptr %l5, !tbaa !24
  store i64 %t376, ptr %l217, !tbaa !24
  %t377 = load ptr, ptr %l0, !tbaa !29
  %t378 = load i64, ptr %l1, !tbaa !24
  %t379 = load { i64, [4 x i64] }, ptr %l4
  %t383 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %t377, i64 %t378, { i64, [4 x i64] } %t379)
  store i64 %t383, ptr %l221
  br label %bb97
bb94:
  %t384 = load i32, ptr %l6, !tbaa !23
  %t385 = load ptr, ptr %l207, !tbaa !29
  %t386 = load i64, ptr %l211, !tbaa !24
  %t388 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintValue(ptr %v0, ptr %t385, i64 %t386, i32 %t384)
  store i64 %t388, ptr %l213
  br label %bb95
bb95:
  %t389 = load i64, ptr %l213, !tbaa !24
  %t390 = call i64 @__olang_fmt_i64(ptr null, i64 %t389)
  %t391 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t390)
  %t392 = call i64 @__olang_fmt_i64(ptr %t391, i64 %t389)
  %t393 = insertvalue { i64, ptr } undef, i64 %t390, 0
  %t394 = insertvalue { i64, ptr } %t393, ptr %t391, 1
  %t396 = load ptr, ptr %l205, !tbaa !29
  %t397 = load i64, ptr %l206, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eappendText(ptr %v0, ptr %s18, ptr %t396, i64 %t397, { i64, ptr } %t394)
  br label %bb96
bb96:
  call void @__olang_scope_close(ptr %s18)
  br label %bb99
bb97:
  %t399 = load i64, ptr %l221, !tbaa !24
  %t401 = call i64 @__olang_fmt_u64(ptr null, i64 %t399)
  %t402 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t401)
  %t403 = call i64 @__olang_fmt_u64(ptr %t402, i64 %t399)
  %t404 = insertvalue { i64, ptr } undef, i64 %t401, 0
  %t405 = insertvalue { i64, ptr } %t404, ptr %t402, 1
  %t407 = load ptr, ptr %l216, !tbaa !29
  %t408 = load i64, ptr %l217, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eappendText(ptr %v0, ptr %s20, ptr %t407, i64 %t408, { i64, ptr } %t405)
  br label %bb98
bb98:
  call void @__olang_scope_close(ptr %s20)
  br label %bb99
bb99:
  br label %bb100
bb100:
  br label %bb109
bb101:
  %t410 = load i32, ptr %l3, !range !{i32 0, i32 8}
  %t412 = trunc i64 6 to i32
  %t413 = icmp eq i32 %t410, %t412
  br i1 %t413, label %bb102, label %bb103
bb102:
  br label %bb104
bb103:
  br label %bb108
bb104:
  store %olang.scope zeroinitializer, ptr %s22
  %t415 = load ptr, ptr %l0, !tbaa !29
  store ptr %t415, ptr %l227, !tbaa !29
  %t416 = load i64, ptr %l5, !tbaa !24
  store i64 %t416, ptr %l228, !tbaa !24
  %t417 = load ptr, ptr %l0, !tbaa !29
  store ptr %t417, ptr %l229, !tbaa !29
  %t418 = load ptr, ptr %l0, !tbaa !29
  %t419 = load i64, ptr %l1, !tbaa !24
  %t420 = load { i64, [4 x i64] }, ptr %l4
  %t424 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %t418, i64 %t419, { i64, [4 x i64] } %t420)
  store i64 %t424, ptr %l233
  br label %bb105
bb105:
  %t425 = load i32, ptr %l6, !tbaa !23
  %t426 = load ptr, ptr %l229, !tbaa !29
  %t427 = load i64, ptr %l233, !tbaa !24
  %t429 = call { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2efloatText(ptr %v0, ptr %s22, ptr %t426, i64 %t427, i32 %t425)
  store { i64, ptr } %t429, ptr %l235
  br label %bb106
bb106:
  %t430 = load { i64, ptr }, ptr %l235, !tbaa !27
  %t431 = load ptr, ptr %l227, !tbaa !29
  %t432 = load i64, ptr %l228, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eappendText(ptr %v0, ptr %s22, ptr %t431, i64 %t432, { i64, ptr } %t430)
  br label %bb107
bb107:
  call void @__olang_scope_close(ptr %s22)
  br label %bb109
bb108:
  call void @__olang_check_failed(ptr @olang_loc_8ccc3ef59c04d332_c9a1f89b24f6a8f6)
  unreachable
bb109:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewriteElems(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/eval:Ptr" %a2, i32 %a3, { i64, [1 x i64] } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/eval:Ptr"
  %l3 = alloca i32
  %l4 = alloca { i64, [1 x i64] }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca %"compiler/mir:Range"
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca %"compiler/mir:Range"
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i32
  %l20 = alloca i32
  %l21 = alloca { i64, [1 x i64] }
  %l24 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca %"compiler/eval:Ptr"
  %l32 = alloca i64
  %l41 = alloca i32
  %l44 = alloca i32
  %l62 = alloca ptr
  %l68 = alloca %"compiler/eval:Ptr"
  %l76 = alloca i8
  %l88 = alloca i32
  %l91 = alloca i32
  %l110 = alloca ptr
  %l118 = alloca i32
  %l120 = alloca { i64, [1 x i64] }
  %l121 = alloca ptr
  %l122 = alloca ptr
  %l130 = alloca %"compiler/eval:Ptr"
  %l133 = alloca i32
  %l135 = alloca i1
  %s4 = alloca %olang.scope
  %s8 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store %"compiler/eval:Ptr" %a2, ptr %l2
  store i32 %a3, ptr %l3
  store { i64, [1 x i64] } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l3, !tbaa !23
  %t5 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t1, i32 %t2)
  store i64 %t5, ptr %l24
  br label %bb1
bb1:
  %t6 = load i64, ptr %l24, !tbaa !24
  store i64 %t6, ptr %l5, !tbaa !24
  %t7 = load { i64, [1 x i64] }, ptr %l4
  %t9 = extractvalue { i64, [1 x i64] } %t7, 0
  %t10 = icmp eq i64 %t9, 0
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = getelementptr { i64, [1 x i64] }, ptr %l4, i32 0, i32 1
  %t13 = getelementptr { i64 }, ptr %t12, i32 0, i32 0
  %t14 = load i64, ptr %t13
  store i64 %t14, ptr %l6, !tbaa !24
  br label %bb4
bb3:
  br label %bb7
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l28, !tbaa !29
  %t17 = load %"compiler/eval:Ptr", ptr %l2
  store %"compiler/eval:Ptr" %t17, ptr %l29
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i32, ptr %l3, !tbaa !23
  %t22 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewidth(ptr %v0, ptr %t18, i32 %t19)
  store i64 %t22, ptr %l32
  br label %bb5
bb5:
  %t23 = load i64, ptr %l6, !tbaa !24
  %t24 = load ptr, ptr %l28, !tbaa !29
  %t25 = load %"compiler/eval:Ptr", ptr %l29
  %t26 = load i64, ptr %l32, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t24, %"compiler/eval:Ptr" %t25, i64 %t26, i64 %t23)
  br label %bb6
bb6:
  br label %bb50
bb7:
  %t28 = load { i64, [1 x i64] }, ptr %l4
  %t30 = extractvalue { i64, [1 x i64] } %t28, 0
  %t31 = icmp eq i64 %t30, 1
  br i1 %t31, label %bb8, label %bb9
bb8:
  %t33 = getelementptr { i64, [1 x i64] }, ptr %l4, i32 0, i32 1
  %t34 = getelementptr { %"compiler/mir:Range" }, ptr %t33, i32 0, i32 0
  %t35 = load %"compiler/mir:Range", ptr %t34
  store %"compiler/mir:Range" %t35, ptr %l7
  br label %bb10
bb9:
  br label %bb26
bb10:
  store i32 0, ptr %l8, !tbaa !23
  %t37 = getelementptr %"compiler/mir:Range", ptr %l7, i32 0, i32 1
  %t38 = load i32, ptr %t37, !tbaa !23
  store i32 %t38, ptr %l9, !tbaa !23
  store i32 1, ptr %l10, !tbaa !23
  %t40 = load i32, ptr %l9, !tbaa !23
  %t41 = load i32, ptr %l8, !tbaa !23
  %t44 = icmp sgt i32 %t40, %t41
  br i1 %t44, label %bb11, label %bb12
bb11:
  %t46 = load i32, ptr %l10, !tbaa !23
  %t48 = icmp sgt i32 %t46, 0
  br i1 %t48, label %bb13, label %bb14
bb12:
  store i32 0, ptr %l41, !tbaa !23
  br label %bb16
bb13:
  %t50 = load i32, ptr %l9, !tbaa !23
  %t51 = load i32, ptr %l8, !tbaa !23
  %t54 = sub i32 %t50, %t51
  %t55 = load i32, ptr %l10, !tbaa !23
  %t58 = add i32 %t54, %t55
  %t60 = sub i32 %t58, 1
  %t61 = load i32, ptr %l10, !tbaa !23
  %t64 = sdiv i32 %t60, %t61
  store i32 %t64, ptr %l44, !tbaa !23
  br label %bb15
bb14:
  store i32 0, ptr %l44, !tbaa !23
  br label %bb15
bb15:
  %t66 = load i32, ptr %l44, !tbaa !23
  store i32 %t66, ptr %l41, !tbaa !23
  br label %bb16
bb16:
  %t67 = load i32, ptr %l41, !tbaa !23
  store i32 %t67, ptr %l11, !tbaa !23
  store i32 0, ptr %l12, !tbaa !23
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s4
  %t68 = load i32, ptr %l12, !tbaa !23
  %t69 = load i32, ptr %l11, !tbaa !23
  %t72 = icmp slt i32 %t68, %t69
  %t74 = xor i1 %t72, true
  br i1 %t74, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s4)
  br label %bb25
bb19:
  br label %bb20
bb20:
  %t76 = load i32, ptr %l8, !tbaa !23
  %t77 = load i32, ptr %l12, !tbaa !23
  %t78 = load i32, ptr %l10, !tbaa !23
  %t81 = mul i32 %t77, %t78
  %t84 = add i32 %t76, %t81
  store i32 %t84, ptr %l13, !tbaa !23
  %t86 = load ptr, ptr %l0, !tbaa !29
  store ptr %t86, ptr %l62, !tbaa !29
  %t87 = getelementptr %"compiler/eval:Ptr", ptr %l2, i32 0, i32 0
  %t88 = load i64, ptr %t87, !tbaa !24
  %t89 = getelementptr %"compiler/eval:Ptr", ptr %l2, i32 0, i32 1
  %t90 = load i64, ptr %t89, !tbaa !24
  %t91 = load i32, ptr %l13, !tbaa !23
  %t93 = sext i32 %t91 to i64
  %t96 = add i64 %t90, %t93
  %t99 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s4, i64 %t88, i64 %t96)
  store %"compiler/eval:Ptr" %t99, ptr %l68
  br label %bb21
bb21:
  %t100 = load ptr, ptr %l1, !tbaa !29
  %t102 = getelementptr %"compiler/mir:Fn", ptr %t100, i32 0, i32 21
  %t103 = getelementptr %"compiler/mir:Range", ptr %l7, i32 0, i32 0
  %t104 = load i32, ptr %t103, !tbaa !23
  %t106 = sext i32 %t104 to i64
  %t107 = load i32, ptr %l13, !tbaa !23
  %t109 = sext i32 %t107 to i64
  %t112 = add i64 %t106, %t109
  %t115 = call i8 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eAt_3cU8_3e(ptr %v1, ptr %t102, i64 %t112)
  store i8 %t115, ptr %l76
  br label %bb22
bb22:
  %t116 = load i8, ptr %l76, !tbaa !22
  %t117 = zext i8 %t116 to i64
  %t118 = load ptr, ptr %l62, !tbaa !29
  %t119 = load %"compiler/eval:Ptr", ptr %l68
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t118, %"compiler/eval:Ptr" %t119, i64 1, i64 %t117)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s4)
  br label %bb24
bb24:
  %t121 = load i32, ptr %l12, !tbaa !23
  %t124 = add i32 %t121, 1
  store i32 %t124, ptr %l12, !tbaa !23
  br label %bb17
bb25:
  br label %bb50
bb26:
  %t126 = load { i64, [1 x i64] }, ptr %l4
  %t128 = extractvalue { i64, [1 x i64] } %t126, 0
  %t129 = icmp eq i64 %t128, 2
  br i1 %t129, label %bb27, label %bb28
bb27:
  %t131 = getelementptr { i64, [1 x i64] }, ptr %l4, i32 0, i32 1
  %t132 = getelementptr { %"compiler/mir:Range" }, ptr %t131, i32 0, i32 0
  %t133 = load %"compiler/mir:Range", ptr %t132
  store %"compiler/mir:Range" %t133, ptr %l14
  br label %bb29
bb28:
  br label %bb49
bb29:
  store i32 0, ptr %l15, !tbaa !23
  %t135 = getelementptr %"compiler/mir:Range", ptr %l14, i32 0, i32 1
  %t136 = load i32, ptr %t135, !tbaa !23
  store i32 %t136, ptr %l16, !tbaa !23
  store i32 1, ptr %l17, !tbaa !23
  %t138 = load i32, ptr %l16, !tbaa !23
  %t139 = load i32, ptr %l15, !tbaa !23
  %t142 = icmp sgt i32 %t138, %t139
  br i1 %t142, label %bb30, label %bb31
bb30:
  %t144 = load i32, ptr %l17, !tbaa !23
  %t146 = icmp sgt i32 %t144, 0
  br i1 %t146, label %bb32, label %bb33
bb31:
  store i32 0, ptr %l88, !tbaa !23
  br label %bb35
bb32:
  %t148 = load i32, ptr %l16, !tbaa !23
  %t149 = load i32, ptr %l15, !tbaa !23
  %t152 = sub i32 %t148, %t149
  %t153 = load i32, ptr %l17, !tbaa !23
  %t156 = add i32 %t152, %t153
  %t158 = sub i32 %t156, 1
  %t159 = load i32, ptr %l17, !tbaa !23
  %t162 = sdiv i32 %t158, %t159
  store i32 %t162, ptr %l91, !tbaa !23
  br label %bb34
bb33:
  store i32 0, ptr %l91, !tbaa !23
  br label %bb34
bb34:
  %t164 = load i32, ptr %l91, !tbaa !23
  store i32 %t164, ptr %l88, !tbaa !23
  br label %bb35
bb35:
  %t165 = load i32, ptr %l88, !tbaa !23
  store i32 %t165, ptr %l18, !tbaa !23
  store i32 0, ptr %l19, !tbaa !23
  br label %bb36
bb36:
  store %olang.scope zeroinitializer, ptr %s8
  %t166 = load i32, ptr %l19, !tbaa !23
  %t167 = load i32, ptr %l18, !tbaa !23
  %t170 = icmp slt i32 %t166, %t167
  %t172 = xor i1 %t170, true
  br i1 %t172, label %bb37, label %bb38
bb37:
  call void @__olang_scope_close(ptr %s8)
  br label %bb48
bb38:
  br label %bb39
bb39:
  %t174 = load i32, ptr %l15, !tbaa !23
  %t175 = load i32, ptr %l19, !tbaa !23
  %t176 = load i32, ptr %l17, !tbaa !23
  %t179 = mul i32 %t175, %t176
  %t182 = add i32 %t174, %t179
  store i32 %t182, ptr %l20, !tbaa !23
  %t184 = load ptr, ptr %l1, !tbaa !29
  %t186 = getelementptr %"compiler/mir:Fn", ptr %t184, i32 0, i32 19
  store ptr %t186, ptr %l110, !tbaa !29
  %t187 = load ptr, ptr %l1, !tbaa !29
  %t189 = getelementptr %"compiler/mir:Fn", ptr %t187, i32 0, i32 20
  %t190 = getelementptr %"compiler/mir:Range", ptr %l14, i32 0, i32 0
  %t191 = load i32, ptr %t190, !tbaa !23
  %t193 = sext i32 %t191 to i64
  %t194 = load i32, ptr %l20, !tbaa !23
  %t196 = sext i32 %t194 to i64
  %t199 = add i64 %t193, %t196
  %t202 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2eAt_3cI32_3e(ptr %v1, ptr %t189, i64 %t199)
  store i32 %t202, ptr %l118
  br label %bb40
bb40:
  %t203 = load i32, ptr %l118, !tbaa !23
  %t204 = sext i32 %t203 to i64
  %t205 = load ptr, ptr %l110, !tbaa !29
  %t207 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aConstNode_3e_2eAt_3ccompiler_2fmir_3aConstNode_3e(ptr %v1, ptr %t205, i64 %t204)
  store { i64, [1 x i64] } %t207, ptr %l120
  br label %bb41
bb41:
  %t208 = load { i64, [1 x i64] }, ptr %l120
  store { i64, [1 x i64] } %t208, ptr %l21
  %t209 = load ptr, ptr %l0, !tbaa !29
  store ptr %t209, ptr %l121, !tbaa !29
  %t210 = load ptr, ptr %l1, !tbaa !29
  store ptr %t210, ptr %l122, !tbaa !29
  %t211 = getelementptr %"compiler/eval:Ptr", ptr %l2, i32 0, i32 0
  %t212 = load i64, ptr %t211, !tbaa !24
  %t213 = getelementptr %"compiler/eval:Ptr", ptr %l2, i32 0, i32 1
  %t214 = load i64, ptr %t213, !tbaa !24
  %t215 = load i32, ptr %l20, !tbaa !23
  %t217 = sext i32 %t215 to i64
  %t218 = load i64, ptr %l5, !tbaa !24
  %t221 = mul i64 %t217, %t218
  %t224 = add i64 %t214, %t221
  %t227 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s8, i64 %t212, i64 %t224)
  store %"compiler/eval:Ptr" %t227, ptr %l130
  br label %bb42
bb42:
  %t228 = load i32, ptr %l3, !tbaa !23
  %t229 = load { i64, [1 x i64] }, ptr %l21
  %t230 = load ptr, ptr %l121, !tbaa !29
  %t231 = load ptr, ptr %l122, !tbaa !29
  %t232 = load %"compiler/eval:Ptr", ptr %l130
  %t235 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewriteItem(ptr %v0, ptr %v1, ptr %t230, ptr %t231, %"compiler/eval:Ptr" %t232, i32 %t228, { i64, [1 x i64] } %t229)
  store i32 %t235, ptr %l133
  %t236 = icmp ne i32 %t235, 0
  br i1 %t236, label %bb44, label %ok.237, !prof !99
ok.237:
  br label %bb43
bb43:
  br label %bb46
bb44:
  %t238 = load i32, ptr %l133, !tbaa !23
  %t239 = ashr i32 %t238, 16
  %t241 = icmp eq i32 %t239, 1
  store i1 %t241, ptr %l135, !tbaa !21
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s8)
  br label %ret
bb46:
  call void @__olang_scope_close(ptr %s8)
  br label %bb47
bb47:
  %t242 = load i32, ptr %l19, !tbaa !23
  %t245 = add i32 %t242, 1
  store i32 %t245, ptr %l19, !tbaa !23
  br label %bb36
bb48:
  br label %bb50
bb49:
  call void @__olang_check_failed(ptr @olang_loc_3aba056b97310e62_2c3874c5956ac10e)
  unreachable
bb50:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewriteItem(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/eval:Ptr" %a2, i32 %a3, { i64, [1 x i64] } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/eval:Ptr"
  %l3 = alloca i32
  %l4 = alloca { i64, [1 x i64] }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca %"compiler/eval:Ptr"
  %l12 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca %"compiler/eval:Ptr"
  %l20 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca %"compiler/eval:Ptr"
  %l30 = alloca i32
  %l35 = alloca i64
  %l38 = alloca i32
  %l39 = alloca ptr
  %l40 = alloca i64
  %l43 = alloca i64
  %l48 = alloca %"compiler/eval:Ptr"
  %l58 = alloca { i64, ptr }
  %l68 = alloca ptr
  %l69 = alloca i64
  %l70 = alloca i64
  %l74 = alloca i64
  %l76 = alloca %"compiler/eval:Ptr"
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store %"compiler/eval:Ptr" %a2, ptr %l2
  store i32 %a3, ptr %l3
  store { i64, [1 x i64] } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l3, !tbaa !23
  %t5 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t1, i32 %t2)
  store i64 %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load i64, ptr %l12, !tbaa !24
  store i64 %t6, ptr %l5, !tbaa !24
  %t7 = load { i64, [1 x i64] }, ptr %l4
  %t9 = extractvalue { i64, [1 x i64] } %t7, 0
  %t10 = icmp eq i64 %t9, 0
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = getelementptr { i64, [1 x i64] }, ptr %l4, i32 0, i32 1
  %t13 = getelementptr { i64 }, ptr %t12, i32 0, i32 0
  %t14 = load i64, ptr %t13
  store i64 %t14, ptr %l6, !tbaa !24
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l16, !tbaa !29
  %t17 = load %"compiler/eval:Ptr", ptr %l2
  store %"compiler/eval:Ptr" %t17, ptr %l17
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i32, ptr %l3, !tbaa !23
  %t22 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewidth(ptr %v0, ptr %t18, i32 %t19)
  store i64 %t22, ptr %l20
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t23 = load i64, ptr %l6, !tbaa !24
  %t24 = load ptr, ptr %l16, !tbaa !29
  %t25 = load %"compiler/eval:Ptr", ptr %l17
  %t26 = load i64, ptr %l20, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t24, %"compiler/eval:Ptr" %t25, i64 %t26, i64 %t23)
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb6:
  %t28 = load i64, ptr %l5, !tbaa !24
  %t29 = load i64, ptr @G_2ecompiler_2feval_2evFixed, !tbaa !24
  %t32 = icmp eq i64 %t28, %t29
  br i1 %t32, label %bb7, label %bb8
bb7:
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l25, !tbaa !29
  %t35 = load ptr, ptr %l1, !tbaa !29
  store ptr %t35, ptr %l26, !tbaa !29
  %t36 = load %"compiler/eval:Ptr", ptr %l2
  store %"compiler/eval:Ptr" %t36, ptr %l27
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load i32, ptr %l3, !tbaa !23
  %t41 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eelemOf(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t41, ptr %l30
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t42 = load { i64, [1 x i64] }, ptr %l4
  %t43 = load ptr, ptr %l25, !tbaa !29
  %t44 = load ptr, ptr %l26, !tbaa !29
  %t45 = load %"compiler/eval:Ptr", ptr %l27
  %t46 = load i32, ptr %l30, !tbaa !23
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewriteElems(ptr %v0, ptr %v1, ptr %t43, ptr %t44, %"compiler/eval:Ptr" %t45, i32 %t46, { i64, [1 x i64] } %t42)
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb11:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load ptr, ptr %l1, !tbaa !29
  %t50 = load { i64, [1 x i64] }, ptr %l4
  %t54 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2econstLen(ptr %v0, ptr %v1, ptr %t48, ptr %t49, { i64, [1 x i64] } %t50)
  store i64 %t54, ptr %l35
  br label %bb12
bb12:
  %t55 = load i64, ptr %l35, !tbaa !24
  store i64 %t55, ptr %l7, !tbaa !24
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load i32, ptr %l3, !tbaa !23
  %t60 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eelemOf(ptr %v0, ptr %t56, i32 %t57)
  store i32 %t60, ptr %l38
  br label %bb13
bb13:
  %t61 = load i32, ptr %l38, !tbaa !23
  store i32 %t61, ptr %l8, !tbaa !23
  %t62 = load ptr, ptr %l0, !tbaa !29
  store ptr %t62, ptr %l39, !tbaa !29
  %t63 = load i64, ptr %l7, !tbaa !24
  store i64 %t63, ptr %l40, !tbaa !24
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load i32, ptr %l8, !tbaa !23
  %t68 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t64, i32 %t65)
  store i64 %t68, ptr %l43
  br label %bb14
bb14:
  %t69 = load i64, ptr %l40, !tbaa !24
  %t70 = load i64, ptr %l43, !tbaa !24
  %t71 = mul i64 %t69, %t70
  %t72 = load i64, ptr @G_2ecompiler_2feval_2eaData, !tbaa !24
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/eval:Machine", ptr %t73, i32 0, i32 71
  %t76 = load i64, ptr %t75, !tbaa !24
  %t77 = load ptr, ptr %l39, !tbaa !29
  %t81 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eallocate(ptr %v0, ptr %t77, i64 %t71, i64 %t72, i64 %t76)
  store %"compiler/eval:Ptr" %t81, ptr %l48
  br label %bb15
bb15:
  %t82 = load %"compiler/eval:Ptr", ptr %l48
  store %"compiler/eval:Ptr" %t82, ptr %l9
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/eval:Machine", ptr %t83, i32 0, i32 23
  %t86 = load i1, ptr %t85, !tbaa !21
  br i1 %t86, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load ptr, ptr %l1, !tbaa !29
  %t91 = load %"compiler/eval:Ptr", ptr %l9
  %t92 = load i32, ptr %l8, !tbaa !23
  %t93 = load { i64, [1 x i64] }, ptr %l4
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewriteElems(ptr %v0, ptr %v1, ptr %t89, ptr %t90, %"compiler/eval:Ptr" %t91, i32 %t92, { i64, [1 x i64] } %t93)
  br label %bb19
bb19:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/eval:Machine", ptr %t99, i32 0, i32 50
  %t102 = load { i64, ptr }, ptr %t101, !tbaa !27
  store { i64, ptr } %t102, ptr %l58, !tbaa !27
  %t103 = getelementptr %"compiler/eval:Ptr", ptr %l9, i32 0, i32 0
  %t104 = load i64, ptr %t103, !tbaa !24
  %t105 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t108 = and i64 %t104, %t105
  %t110 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr %"compiler/eval:alloc", ptr %t111, i64 %t108
  %t113 = getelementptr %"compiler/eval:alloc", ptr %t112, i32 0, i32 13
  store i1 true, ptr %t113, !tbaa !21
  %t114 = load i64, ptr %l5, !tbaa !24
  %t115 = load i64, ptr @G_2ecompiler_2feval_2evPair, !tbaa !24
  %t118 = icmp eq i64 %t114, %t115
  br i1 %t118, label %bb20, label %bb21
bb20:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load %"compiler/eval:Ptr", ptr %l2
  %t122 = load i64, ptr %l7, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t120, %"compiler/eval:Ptr" %t121, i64 8, i64 %t122)
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb23
bb23:
  %t126 = load ptr, ptr %l0, !tbaa !29
  store ptr %t126, ptr %l68, !tbaa !29
  %t127 = getelementptr %"compiler/eval:Ptr", ptr %l2, i32 0, i32 0
  %t128 = load i64, ptr %t127, !tbaa !24
  store i64 %t128, ptr %l69, !tbaa !24
  %t129 = getelementptr %"compiler/eval:Ptr", ptr %l2, i32 0, i32 1
  %t130 = load i64, ptr %t129, !tbaa !24
  store i64 %t130, ptr %l70, !tbaa !24
  %t131 = load i64, ptr %l5, !tbaa !24
  %t132 = load i64, ptr @G_2ecompiler_2feval_2evPair, !tbaa !24
  %t135 = icmp eq i64 %t131, %t132
  br i1 %t135, label %bb24, label %bb25
bb24:
  store i64 8, ptr %l74, !tbaa !24
  br label %bb26
bb25:
  store i64 0, ptr %l74, !tbaa !24
  br label %bb26
bb26:
  %t137 = load i64, ptr %l70, !tbaa !24
  %t138 = load i64, ptr %l74, !tbaa !24
  %t139 = add i64 %t137, %t138
  %t140 = load i64, ptr %l69, !tbaa !24
  %t142 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s0, i64 %t140, i64 %t139)
  store %"compiler/eval:Ptr" %t142, ptr %l76
  br label %bb27
bb27:
  %t143 = load %"compiler/eval:Ptr", ptr %l9
  %t144 = load ptr, ptr %l68, !tbaa !29
  %t145 = load %"compiler/eval:Ptr", ptr %l76
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrPtr(ptr %v0, ptr %t144, %"compiler/eval:Ptr" %t145, %"compiler/eval:Ptr" %t143)
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aSnapshot_2edrop(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %lp3 = alloca ptr
  %l4 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l5 = alloca %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0"
  %l12 = alloca i64
  %l14 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l17 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l18 = alloca %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0"
  %l20 = alloca %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0"
  %l21 = alloca i32
  %l23 = alloca i1
  %l30 = alloca ptr
  %l32 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Snapshot", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %t3, i64 %t4)
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/eval:Snapshot", ptr %t7, i32 0, i32 0
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %t9, i64 %a2)
  br label %bb2
bb2:
  %t13 = call ptr @__olang_scope_hold(ptr %v0)
  %t14 = ptrtoint ptr %t13 to i64
  store i64 %t14, ptr %l12, !tbaa !24
  %t15 = load i1, ptr @olang_2esole_2ecompiler_2feval_3aSnapshot_2e5
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = call ptr @__olang_region_make(ptr %v0)
  %t18 = ptrtoint ptr %t17 to i64
  store i64 %t18, ptr %l12, !tbaa !24
  br label %bb4
bb4:
  %t19 = load i64, ptr %l12
  %t20 = inttoptr i64 %t19 to ptr
  %t21 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %t20)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t21, ptr %l14
  br label %bb5
bb5:
  %t22 = load i64, ptr %l12
  %t23 = inttoptr i64 %t22 to ptr
  %t24 = call ptr @__olang_scope_alloc_a(ptr %t23, i64 72, i64 8)
  store ptr %t24, ptr %lp3
  %t25 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l14
  %t26 = load ptr, ptr %lp3
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t25, ptr %t26
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/eval:Snapshot", ptr %t27, i32 0, i32 5
  %t31 = call %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eIter_3cI64_2c_20I64_3e(ptr %v0, ptr %v0, ptr %t29)
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t31, ptr %l17
  br label %bb6
bb6:
  %t32 = load %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l17
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t32, ptr %l4
  br label %bb7
bb7:
  %t34 = call { i32, %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3cI64_2c_20I64_3e_2eNext_3cI64_2c_20I64_3e(ptr %v0, ptr %l4)
  %t35 = extractvalue { i32, %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0" } %t34, 1
  %t36 = extractvalue { i32, %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0" } %t34, 0
  store i32 %t36, ptr %l21
  %t37 = icmp ne i32 %t36, 0
  br i1 %t37, label %bb9, label %ok.38, !prof !99
ok.38:
  store %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0" %t35, ptr %l20
  br label %bb8
bb8:
  %t39 = load %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0", ptr %l20
  store %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0" %t39, ptr %l18
  br label %bb11
bb9:
  %t40 = load i32, ptr %l21, !tbaa !23
  %t41 = ashr i32 %t40, 16
  %t43 = icmp eq i32 %t41, 1
  store i1 %t43, ptr %l23, !tbaa !21
  br label %bb10
bb10:
  br label %bb17
bb11:
  %t44 = load %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0", ptr %l18
  store %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0" %t44, ptr %l5
  %t45 = getelementptr %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0", ptr %l5, i32 0, i32 1
  %t46 = load i64, ptr %t45, !tbaa !24
  %t47 = load i64, ptr %l1, !tbaa !24
  %t50 = icmp slt i64 %t46, %t47
  br i1 %t50, label %bb12, label %bb13
bb12:
  %t52 = load ptr, ptr %lp3
  %t53 = getelementptr %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0", ptr %l5, i32 0, i32 0
  %t54 = load i64, ptr %t53, !tbaa !24
  %t55 = getelementptr %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0", ptr %l5, i32 0, i32 1
  %t56 = load i64, ptr %t55, !tbaa !24
  %t57 = load i64, ptr %l12
  %t58 = inttoptr i64 %t57 to ptr
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %t58, ptr %t52, i64 %t54, i64 %t56)
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb15
bb15:
  br label %bb16
bb16:
  br label %bb7
bb17:
  %t62 = load ptr, ptr %l0, !tbaa !29
  store ptr %t62, ptr %l30, !tbaa !29
  %t63 = load ptr, ptr %lp3
  %t64 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t63
  %t65 = load ptr, ptr %l30, !tbaa !29
  %t66 = getelementptr %"compiler/eval:Snapshot", ptr %t65, i32 0, i32 5
  %t67 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t66
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t67, ptr %l32
  %t69 = load ptr, ptr %l30, !tbaa !29
  %t70 = getelementptr %"compiler/eval:Snapshot", ptr %t69, i32 0, i32 5
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t64, ptr %t70
  %t71 = load i1, ptr @olang_2esole_2ecompiler_2feval_3aSnapshot_2e5
  br i1 %t71, label %bb18, label %bb19
bb18:
  %t73 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l32, i32 0, i32 2
  %t74 = load { i64, ptr }, ptr %t73
  %t75 = extractvalue { i64, ptr } %t74, 1
  %t76 = call ptr @__olang_region_or(ptr %t75, ptr null)
  %t77 = call ptr @__olang_region_home(ptr %t76)
  %t78 = icmp ne ptr %t77, null
  %t79 = select i1 %t78, ptr %t77, ptr null
  %t80 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l32, i32 0, i32 1
  %t81 = load { i64, ptr }, ptr %t80
  %t82 = extractvalue { i64, ptr } %t81, 1
  %t83 = call ptr @__olang_region_or(ptr %t82, ptr null)
  %t84 = call ptr @__olang_region_home(ptr %t83)
  %t85 = icmp ne ptr %t84, null
  %t86 = select i1 %t85, ptr %t84, ptr %t79
  %t87 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l32, i32 0, i32 0
  %t88 = load { i64, ptr }, ptr %t87
  %t89 = extractvalue { i64, ptr } %t88, 1
  %t90 = call ptr @__olang_region_or(ptr %t89, ptr null)
  %t91 = call ptr @__olang_region_home(ptr %t90)
  %t92 = icmp ne ptr %t91, null
  %t93 = select i1 %t92, ptr %t91, ptr %t86
  call void @__olang_region_drop(ptr %t93)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" zeroinitializer, ptr %l32
  br label %bb19
bb19:
  %t94 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e0
  br i1 %t94, label %bb20, label %bb21
bb20:
  %t96 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l32, i32 0, i32 0
  %t97 = load { i64, ptr }, ptr %t96
  %t98 = extractvalue { i64, ptr } %t97, 0
  %t99 = extractvalue { i64, ptr } %t97, 1
  call void @__olang_region_release_part(ptr %t99, i64 %t98)
  store { i64, ptr } zeroinitializer, ptr %t96
  br label %bb21
bb21:
  %t100 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e1
  br i1 %t100, label %bb22, label %bb23
bb22:
  %t102 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l32, i32 0, i32 1
  %t103 = load { i64, ptr }, ptr %t102
  %t104 = extractvalue { i64, ptr } %t103, 0
  %t105 = extractvalue { i64, ptr } %t103, 1
  call void @__olang_region_release_part(ptr %t105, i64 %t104)
  store { i64, ptr } zeroinitializer, ptr %t102
  br label %bb23
bb23:
  %t106 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e2
  br i1 %t106, label %bb24, label %bb25
bb24:
  %t108 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l32, i32 0, i32 2
  %t109 = load { i64, ptr }, ptr %t108
  %t110 = extractvalue { i64, ptr } %t109, 0
  %t111 = extractvalue { i64, ptr } %t109, 1
  call void @__olang_region_release_part(ptr %t111, i64 %t110)
  store { i64, ptr } zeroinitializer, ptr %t108
  br label %bb25
bb25:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aStop_2eText(ptr %v0, ptr %v1, ptr %v2, { i64, [5 x i64] } %a0, ptr %a1) #0 {
entry:
  %l0 = alloca { i64, [5 x i64] }
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i32, i32 }
  %l9 = alloca { i64, ptr }
  %l10 = alloca %"compiler/source:Span"
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l29 = alloca i1
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l35 = alloca { i64, ptr }
  %l37 = alloca i1
  %l40 = alloca { i32, i32 }
  %l44 = alloca { i64, ptr }
  %l45 = alloca i32
  %l46 = alloca i32
  %l48 = alloca { i64, ptr }
  %l51 = alloca i1
  %l53 = alloca { i64, ptr }
  %l56 = alloca i32
  %l58 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l64 = alloca i32
  %l66 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l77 = alloca i32
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, [5 x i64] } %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [5 x i64] }, ptr %l0
  %t3 = extractvalue { i64, [5 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d6, i32 0, i32 1) }, ptr %l13, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t6, ptr %l14, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t7, 0
  store i64 %t8, ptr %l15, !tbaa !24
  %t9 = load i64, ptr %l15, !tbaa !24
  %t10 = mul i64 %t9, 1
  %t11 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t10)
  %t12 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  store { i64, ptr } %t13, ptr %l16, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = load i64, ptr %l15, !tbaa !24
  %t19 = mul i64 %t18, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t15, ptr %t17, i64 %t19, i1 false)
  %t20 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t20, ptr %l14, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t21, ptr %rv
  br label %ret
bb4:
  %t22 = load { i64, [5 x i64] }, ptr %l0
  %t24 = extractvalue { i64, [5 x i64] } %t22, 0
  %t25 = icmp eq i64 %t24, 1
  br i1 %t25, label %bb5, label %bb6
bb5:
  %t27 = getelementptr { i64, [5 x i64] }, ptr %l0, i32 0, i32 1
  %t28 = getelementptr { i64 }, ptr %t27, i32 0, i32 0
  %t29 = load i64, ptr %t28
  store i64 %t29, ptr %l2, !tbaa !24
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t33 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t35 = call i64 @__olang_fmt_i64(ptr null, i64 %t31)
  %t36 = add i64 %t33, %t35
  %t37 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t36)
  call void @olang_textcopy(ptr %t37, ptr %t32, i64 %t33)
  %t38 = getelementptr i8, ptr %t37, i64 %t33
  %t39 = call i64 @__olang_fmt_i64(ptr %t38, i64 %t31)
  %t40 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t37, 1
  store { i64, ptr } %t41, ptr %rv
  br label %ret
bb8:
  %t43 = load { i64, [5 x i64] }, ptr %l0
  %t45 = extractvalue { i64, [5 x i64] } %t43, 0
  %t46 = icmp eq i64 %t45, 2
  br i1 %t46, label %bb9, label %bb10
bb9:
  %t48 = getelementptr { i64, [5 x i64] }, ptr %l0, i32 0, i32 1
  %t49 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t48, i32 0, i32 0
  %t50 = load i32, ptr %t49, !range !{i32 0, i32 20}
  store i32 %t50, ptr %l3
  %t52 = getelementptr { i64, [5 x i64] }, ptr %l0, i32 0, i32 1
  %t53 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t52, i32 0, i32 2
  %t54 = load %"compiler/source:Span", ptr %t53
  store %"compiler/source:Span" %t54, ptr %l4
  %t56 = getelementptr { i64, [5 x i64] }, ptr %l0, i32 0, i32 1
  %t57 = getelementptr { i32, i64, %"compiler/source:Span", { i64, ptr } }, ptr %t56, i32 0, i32 3
  %t58 = load { i64, ptr }, ptr %t57
  store { i64, ptr } %t58, ptr %l5, !tbaa !27
  br label %bb11
bb10:
  br label %bb32
bb11:
  store %olang.scope zeroinitializer, ptr %s4
  %t60 = load i32, ptr %l3, !range !{i32 0, i32 20}
  %t62 = trunc i64 0 to i32
  %t63 = icmp eq i32 %t60, %t62
  br i1 %t63, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb14
bb13:
  %t65 = load i32, ptr %l3, !range !{i32 0, i32 20}
  %t67 = trunc i64 1 to i32
  %t68 = icmp eq i32 %t65, %t67
  store i1 %t68, ptr %l29, !tbaa !21
  br label %bb14
bb14:
  %t70 = load i1, ptr %l29, !tbaa !21
  br i1 %t70, label %bb15, label %bb16
bb15:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) }, ptr %l32, !tbaa !27
  %t71 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t71, ptr %l33, !tbaa !27
  %t72 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t72, 0
  store i64 %t73, ptr %l34, !tbaa !24
  %t74 = load i64, ptr %l34, !tbaa !24
  %t75 = mul i64 %t74, 1
  %t76 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t75)
  %t77 = insertvalue { i64, ptr } undef, i64 %t74, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t76, 1
  store { i64, ptr } %t78, ptr %l35, !tbaa !27
  %t79 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = load i64, ptr %l34, !tbaa !24
  %t84 = mul i64 %t83, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t80, ptr %t82, i64 %t84, i1 false)
  %t85 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t85, ptr %l33, !tbaa !27
  call void @__olang_scope_close(ptr %s4)
  %t86 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t86, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t87 = load i32, ptr %l3, !range !{i32 0, i32 20}
  %t89 = call i1 @compiler_2fmir_2eColumned(i32 %t87)
  store i1 %t89, ptr %l37
  br label %bb18
bb18:
  %t90 = load i1, ptr %l37, !tbaa !21
  br i1 %t90, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s6
  %t91 = load ptr, ptr %l1, !tbaa !29
  %t92 = getelementptr %"compiler/source:Span", ptr %l4, i32 0, i32 0
  %t93 = load i32, ptr %t92, !tbaa !23
  %t96 = call { i32, i32 } @compiler_2fsource_2ecompiler_2fsource_3aSource_2eLineCol(ptr %v1, ptr %t91, i32 %t93)
  store { i32, i32 } %t96, ptr %l40
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t97 = load { i32, i32 }, ptr %l40
  store { i32, i32 } %t97, ptr %l6
  %t98 = getelementptr { i32, i32 }, ptr %l6, i32 0, i32 0
  %t99 = load i32, ptr %t98, !tbaa !23
  %t101 = getelementptr { i32, i32 }, ptr %l6, i32 0, i32 1
  %t102 = load i32, ptr %t101, !tbaa !23
  %t104 = load ptr, ptr %l1, !tbaa !29
  %t106 = getelementptr %"compiler/source:Source", ptr %t104, i32 0, i32 0
  %t107 = load { i64, ptr }, ptr %t106, !tbaa !27
  store { i64, ptr } %t107, ptr %l44, !tbaa !27
  store i32 %t99, ptr %l45, !tbaa !23
  store i32 %t102, ptr %l46, !tbaa !23
  %t110 = load i32, ptr %l3, !range !{i32 0, i32 20}
  %t112 = call { i64, ptr } @compiler_2fmir_2eExitText(ptr %s6, i32 %t110)
  store { i64, ptr } %t112, ptr %l48
  br label %bb22
bb22:
  %t113 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 1
  %t115 = extractvalue { i64, ptr } %t113, 0
  %t116 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t117 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t118 = add i64 %t115, %t117
  %t119 = load i32, ptr %l45, !tbaa !23
  %t120 = sext i32 %t119 to i64
  %t121 = call i64 @__olang_fmt_i64(ptr null, i64 %t120)
  %t122 = add i64 %t118, %t121
  %t123 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t124 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t125 = add i64 %t122, %t124
  %t126 = load i32, ptr %l46, !tbaa !23
  %t127 = sext i32 %t126 to i64
  %t128 = call i64 @__olang_fmt_i64(ptr null, i64 %t127)
  %t129 = add i64 %t125, %t128
  %t130 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t131 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t132 = add i64 %t129, %t131
  %t133 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t133, 1
  %t135 = extractvalue { i64, ptr } %t133, 0
  %t136 = add i64 %t132, %t135
  %t137 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t136)
  call void @olang_textcopy(ptr %t137, ptr %t114, i64 %t115)
  %t138 = getelementptr i8, ptr %t137, i64 %t115
  call void @olang_textcopy(ptr %t138, ptr %t116, i64 %t117)
  %t139 = getelementptr i8, ptr %t138, i64 %t117
  %t140 = call i64 @__olang_fmt_i64(ptr %t139, i64 %t120)
  %t141 = getelementptr i8, ptr %t139, i64 %t121
  call void @olang_textcopy(ptr %t141, ptr %t123, i64 %t124)
  %t142 = getelementptr i8, ptr %t141, i64 %t124
  %t143 = call i64 @__olang_fmt_i64(ptr %t142, i64 %t127)
  %t144 = getelementptr i8, ptr %t142, i64 %t128
  call void @olang_textcopy(ptr %t144, ptr %t130, i64 %t131)
  %t145 = getelementptr i8, ptr %t144, i64 %t131
  call void @olang_textcopy(ptr %t145, ptr %t134, i64 %t135)
  %t146 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t147 = insertvalue { i64, ptr } %t146, ptr %t137, 1
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s4)
  store { i64, ptr } %t147, ptr %rv
  br label %ret
bb23:
  %t149 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t151 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s4, { i64, ptr } %t149, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d11, i32 0, i32 1) })
  store i1 %t151, ptr %l51
  br label %bb24
bb24:
  %t152 = load i1, ptr %l51, !tbaa !21
  br i1 %t152, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s8
  %t153 = load ptr, ptr %l1, !tbaa !29
  %t155 = getelementptr %"compiler/source:Source", ptr %t153, i32 0, i32 0
  %t156 = load { i64, ptr }, ptr %t155, !tbaa !27
  store { i64, ptr } %t156, ptr %l53, !tbaa !27
  %t157 = load ptr, ptr %l1, !tbaa !29
  %t158 = getelementptr %"compiler/source:Span", ptr %l4, i32 0, i32 0
  %t159 = load i32, ptr %t158, !tbaa !23
  %t162 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aSource_2eLine(ptr %v1, ptr %t157, i32 %t159)
  store i32 %t162, ptr %l56
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t163 = load i32, ptr %l3, !range !{i32 0, i32 20}
  %t165 = call { i64, ptr } @compiler_2fmir_2eExitText(ptr %s8, i32 %t163)
  store { i64, ptr } %t165, ptr %l58
  br label %bb28
bb28:
  %t166 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t167 = extractvalue { i64, ptr } %t166, 1
  %t168 = extractvalue { i64, ptr } %t166, 0
  %t169 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t170 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  %t171 = add i64 %t168, %t170
  %t172 = load i32, ptr %l56, !tbaa !23
  %t173 = sext i32 %t172 to i64
  %t174 = call i64 @__olang_fmt_i64(ptr null, i64 %t173)
  %t175 = add i64 %t171, %t174
  %t176 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t177 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t178 = add i64 %t175, %t177
  %t179 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t180 = extractvalue { i64, ptr } %t179, 1
  %t181 = extractvalue { i64, ptr } %t179, 0
  %t182 = add i64 %t178, %t181
  %t183 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t182)
  call void @olang_textcopy(ptr %t183, ptr %t167, i64 %t168)
  %t184 = getelementptr i8, ptr %t183, i64 %t168
  call void @olang_textcopy(ptr %t184, ptr %t169, i64 %t170)
  %t185 = getelementptr i8, ptr %t184, i64 %t170
  %t186 = call i64 @__olang_fmt_i64(ptr %t185, i64 %t173)
  %t187 = getelementptr i8, ptr %t185, i64 %t174
  call void @olang_textcopy(ptr %t187, ptr %t176, i64 %t177)
  %t188 = getelementptr i8, ptr %t187, i64 %t177
  call void @olang_textcopy(ptr %t188, ptr %t180, i64 %t181)
  %t189 = insertvalue { i64, ptr } undef, i64 %t182, 0
  %t190 = insertvalue { i64, ptr } %t189, ptr %t183, 1
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s4)
  store { i64, ptr } %t190, ptr %rv
  br label %ret
bb29:
  %t192 = load ptr, ptr %l1, !tbaa !29
  %t194 = getelementptr %"compiler/source:Source", ptr %t192, i32 0, i32 0
  %t195 = load { i64, ptr }, ptr %t194, !tbaa !27
  store { i64, ptr } %t195, ptr %l61, !tbaa !27
  %t196 = load ptr, ptr %l1, !tbaa !29
  %t197 = getelementptr %"compiler/source:Span", ptr %l4, i32 0, i32 0
  %t198 = load i32, ptr %t197, !tbaa !23
  %t201 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aSource_2eLine(ptr %v1, ptr %t196, i32 %t198)
  store i32 %t201, ptr %l64
  br label %bb30
bb30:
  %t202 = load i32, ptr %l3, !range !{i32 0, i32 20}
  %t204 = call { i64, ptr } @compiler_2fmir_2eExitText(ptr %s4, i32 %t202)
  store { i64, ptr } %t204, ptr %l66
  br label %bb31
bb31:
  %t205 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t206 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t207 = extractvalue { i64, ptr } %t206, 1
  %t208 = extractvalue { i64, ptr } %t206, 0
  %t209 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t210 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t211 = add i64 %t208, %t210
  %t212 = load i32, ptr %l64, !tbaa !23
  %t213 = sext i32 %t212 to i64
  %t214 = call i64 @__olang_fmt_i64(ptr null, i64 %t213)
  %t215 = add i64 %t211, %t214
  %t216 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t217 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  %t218 = add i64 %t215, %t217
  %t219 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t220 = extractvalue { i64, ptr } %t219, 1
  %t221 = extractvalue { i64, ptr } %t219, 0
  %t222 = add i64 %t218, %t221
  %t223 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t224 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  %t225 = add i64 %t222, %t224
  %t227 = extractvalue { i64, ptr } %t205, 1
  %t228 = extractvalue { i64, ptr } %t205, 0
  %t229 = add i64 %t225, %t228
  %t230 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t229)
  call void @olang_textcopy(ptr %t230, ptr %t207, i64 %t208)
  %t231 = getelementptr i8, ptr %t230, i64 %t208
  call void @olang_textcopy(ptr %t231, ptr %t209, i64 %t210)
  %t232 = getelementptr i8, ptr %t231, i64 %t210
  %t233 = call i64 @__olang_fmt_i64(ptr %t232, i64 %t213)
  %t234 = getelementptr i8, ptr %t232, i64 %t214
  call void @olang_textcopy(ptr %t234, ptr %t216, i64 %t217)
  %t235 = getelementptr i8, ptr %t234, i64 %t217
  call void @olang_textcopy(ptr %t235, ptr %t220, i64 %t221)
  %t236 = getelementptr i8, ptr %t235, i64 %t221
  call void @olang_textcopy(ptr %t236, ptr %t223, i64 %t224)
  %t237 = getelementptr i8, ptr %t236, i64 %t224
  call void @olang_textcopy(ptr %t237, ptr %t227, i64 %t228)
  %t238 = insertvalue { i64, ptr } undef, i64 %t229, 0
  %t239 = insertvalue { i64, ptr } %t238, ptr %t230, 1
  call void @__olang_scope_close(ptr %s4)
  store { i64, ptr } %t239, ptr %rv
  br label %ret
bb32:
  %t241 = load { i64, [5 x i64] }, ptr %l0
  %t243 = extractvalue { i64, [5 x i64] } %t241, 0
  %t244 = icmp eq i64 %t243, 3
  br i1 %t244, label %bb33, label %bb34
bb33:
  %t246 = getelementptr { i64, [5 x i64] }, ptr %l0, i32 0, i32 1
  %t247 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t246, i32 0, i32 0
  %t248 = load { i64, ptr }, ptr %t247
  store { i64, ptr } %t248, ptr %l9, !tbaa !27
  %t250 = getelementptr { i64, [5 x i64] }, ptr %l0, i32 0, i32 1
  %t251 = getelementptr { { i64, ptr }, i64, %"compiler/source:Span" }, ptr %t250, i32 0, i32 2
  %t252 = load %"compiler/source:Span", ptr %t251
  store %"compiler/source:Span" %t252, ptr %l10
  br label %bb35
bb34:
  br label %bb37
bb35:
  %t254 = load ptr, ptr %l1, !tbaa !29
  %t256 = getelementptr %"compiler/source:Source", ptr %t254, i32 0, i32 0
  %t257 = load { i64, ptr }, ptr %t256, !tbaa !27
  store { i64, ptr } %t257, ptr %l74, !tbaa !27
  %t258 = load ptr, ptr %l1, !tbaa !29
  %t259 = getelementptr %"compiler/source:Span", ptr %l10, i32 0, i32 0
  %t260 = load i32, ptr %t259, !tbaa !23
  %t263 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aSource_2eLine(ptr %v1, ptr %t258, i32 %t260)
  store i32 %t263, ptr %l77
  br label %bb36
bb36:
  %t264 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t265 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t266 = extractvalue { i64, ptr } %t265, 1
  %t267 = extractvalue { i64, ptr } %t265, 0
  %t268 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t269 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t270 = add i64 %t267, %t269
  %t271 = load i32, ptr %l77, !tbaa !23
  %t272 = sext i32 %t271 to i64
  %t273 = call i64 @__olang_fmt_i64(ptr null, i64 %t272)
  %t274 = add i64 %t270, %t273
  %t275 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t276 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  %t277 = add i64 %t274, %t276
  %t279 = extractvalue { i64, ptr } %t264, 1
  %t280 = extractvalue { i64, ptr } %t264, 0
  %t281 = add i64 %t277, %t280
  %t282 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t281)
  call void @olang_textcopy(ptr %t282, ptr %t266, i64 %t267)
  %t283 = getelementptr i8, ptr %t282, i64 %t267
  call void @olang_textcopy(ptr %t283, ptr %t268, i64 %t269)
  %t284 = getelementptr i8, ptr %t283, i64 %t269
  %t285 = call i64 @__olang_fmt_i64(ptr %t284, i64 %t272)
  %t286 = getelementptr i8, ptr %t284, i64 %t273
  call void @olang_textcopy(ptr %t286, ptr %t275, i64 %t276)
  %t287 = getelementptr i8, ptr %t286, i64 %t276
  call void @olang_textcopy(ptr %t287, ptr %t279, i64 %t280)
  %t288 = insertvalue { i64, ptr } undef, i64 %t281, 0
  %t289 = insertvalue { i64, ptr } %t288, ptr %t282, 1
  store { i64, ptr } %t289, ptr %rv
  br label %ret
bb37:
  call void @__olang_check_failed(ptr @olang_loc_e6861b790824244d_fbaf0ff74301c89)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2feval_2ecountBits128(i1 %a0, i64 %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l16 = alloca i64
  %l19 = alloca i64
  %l28 = alloca i64
  %l31 = alloca i1
  %l43 = alloca i64
  %l46 = alloca i64
  %l50 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  store i64 %a3, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t3 = load i64, ptr %l6, !tbaa !24
  %t4 = load i64, ptr %l5, !tbaa !24
  %t7 = icmp sgt i64 %t3, %t4
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l7, !tbaa !24
  %t11 = icmp sgt i64 %t9, 0
  br i1 %t11, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb6
bb3:
  %t13 = load i64, ptr %l6, !tbaa !24
  %t14 = load i64, ptr %l5, !tbaa !24
  %t17 = sub i64 %t13, %t14
  %t18 = load i64, ptr %l7, !tbaa !24
  %t21 = add i64 %t17, %t18
  %t23 = sub i64 %t21, 1
  %t24 = load i64, ptr %l7, !tbaa !24
  %t27 = sdiv i64 %t23, %t24
  store i64 %t27, ptr %l19, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb5
bb5:
  %t29 = load i64, ptr %l19, !tbaa !24
  store i64 %t29, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l16, !tbaa !24
  store i64 %t30, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  %t31 = load i64, ptr %l8, !tbaa !24
  %t32 = sub i64 %t31, 1
  store i64 %t32, ptr %l28, !tbaa !24
  %t33 = load i64, ptr %l8, !tbaa !24
  %t34 = icmp slt i64 %t33, 2147483648
  %t35 = load i64, ptr %l9, !tbaa !24
  %t36 = icmp sge i64 %t35, 0
  %t39 = and i1 %t34, %t36
  store i1 %t39, ptr %l31, !tbaa !21
  br label %bb7
bb7:
  %t40 = load i64, ptr %l9, !tbaa !24
  %t41 = load i64, ptr %l8, !tbaa !24
  %t44 = icmp slt i64 %t40, %t41
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb8, label %bb9
bb8:
  br label %bb21
bb9:
  br label %bb10
bb10:
  %t48 = load i64, ptr %l5, !tbaa !24
  %t49 = load i64, ptr %l9, !tbaa !24
  %t50 = load i64, ptr %l7, !tbaa !24
  %t53 = mul i64 %t49, %t50
  %t56 = add i64 %t48, %t53
  store i64 %t56, ptr %l10, !tbaa !24
  %t58 = load i64, ptr %l10, !tbaa !24
  %t60 = icmp sge i64 %t58, 64
  br i1 %t60, label %bb11, label %bb12
bb11:
  %t63 = load i64, ptr %l10, !tbaa !24
  %t65 = sub i64 %t63, 64
  store i64 %t65, ptr %l46, !tbaa !24
  %t67 = load i64, ptr %l46, !tbaa !24
  %t68 = load i64, ptr %l46, !tbaa !24
  %t69 = ashr i64 %a2, %t68
  %t71 = and i64 %t69, 1
  store i64 %t71, ptr %l43, !tbaa !24
  br label %bb13
bb12:
  %t74 = load i64, ptr %l10, !tbaa !24
  store i64 %t74, ptr %l50, !tbaa !24
  %t76 = load i64, ptr %l50, !tbaa !24
  %t77 = load i64, ptr %l50, !tbaa !24
  %t78 = ashr i64 %a1, %t77
  %t80 = and i64 %t78, 1
  store i64 %t80, ptr %l43, !tbaa !24
  br label %bb13
bb13:
  %t82 = load i64, ptr %l43, !tbaa !24
  store i64 %t82, ptr %l11, !tbaa !24
  br i1 %a0, label %bb14, label %bb15
bb14:
  %t85 = load i64, ptr %l4, !tbaa !24
  %t87 = load i64, ptr %l11, !tbaa !24
  %t90 = add i64 %t85, %t87
  store i64 %t90, ptr %l4, !tbaa !24
  br label %bb19
bb15:
  %t92 = load i64, ptr %l11, !tbaa !24
  %t94 = icmp eq i64 %t92, 1
  br i1 %t94, label %bb16, label %bb17
bb16:
  br label %bb21
bb17:
  %t96 = load i64, ptr %l4, !tbaa !24
  %t99 = add i64 %t96, 1
  store i64 %t99, ptr %l4, !tbaa !24
  br label %bb18
bb18:
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t101 = load i64, ptr %l9, !tbaa !24
  %t104 = add i64 %t101, 1
  store i64 %t104, ptr %l9, !tbaa !24
  br label %bb7
bb21:
  %t106 = load i64, ptr %l4, !tbaa !24
  store i64 %t106, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2feval_2efitsBits(i64 %a0, i1 %a1, i64 %a2, i1 %a3) #0 {
entry:
  %l0 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i1
  %l7 = alloca i1
  %l10 = alloca i1
  %l16 = alloca i1
  %l17 = alloca i64
  %l19 = alloca i64
  %l21 = alloca i1
  %l22 = alloca i64
  %l24 = alloca i64
  %l30 = alloca i1
  %l33 = alloca i1
  %l34 = alloca i64
  %l36 = alloca i64
  %rv = alloca i1
  store i64 %a0, ptr %l0
  store i64 %a2, ptr %l2
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  br i1 %a1, label %bb1, label %bb2
bb1:
  %t3 = load i64, ptr %l2, !tbaa !24
  %t5 = icmp sgt i64 %t3, 64
  br i1 %t5, label %bb3, label %bb4
bb2:
  br label %bb9
bb3:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb8
bb4:
  %t7 = load i1, ptr %l3, !tbaa !21
  %t9 = xor i1 %t7, true
  br i1 %t9, label %bb5, label %bb6
bb5:
  %t11 = load i64, ptr %l2, !tbaa !24
  %t13 = icmp eq i64 %t11, 64
  store i1 %t13, ptr %l10, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb7
bb7:
  %t15 = load i1, ptr %l10, !tbaa !21
  store i1 %t15, ptr %l7, !tbaa !21
  br label %bb8
bb8:
  %t16 = load i1, ptr %l7, !tbaa !21
  store i1 %t16, ptr %rv
  br label %ret
bb9:
  %t17 = load i1, ptr %l3, !tbaa !21
  br i1 %t17, label %bb10, label %bb11
bb10:
  %t19 = load i64, ptr %l2, !tbaa !24
  %t21 = icmp sge i64 %t19, 64
  br i1 %t21, label %bb12, label %bb13
bb11:
  br label %bb20
bb12:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb19
bb13:
  %t23 = load i64, ptr %l0, !tbaa !24
  store i64 %t23, ptr %l17, !tbaa !24
  %t24 = load i64, ptr %l2, !tbaa !24
  %t26 = call i64 @compiler_2feval_2eminBits(i64 %t24)
  store i64 %t26, ptr %l19
  br label %bb14
bb14:
  %t27 = load i64, ptr %l17, !tbaa !24
  %t28 = load i64, ptr %l19, !tbaa !24
  %t29 = icmp sge i64 %t27, %t28
  br i1 %t29, label %bb15, label %bb16
bb15:
  %t31 = load i64, ptr %l0, !tbaa !24
  store i64 %t31, ptr %l22, !tbaa !24
  %t32 = load i64, ptr %l2, !tbaa !24
  %t34 = call i64 @compiler_2feval_2eminBits(i64 %t32)
  store i64 %t34, ptr %l24
  br label %bb17
bb16:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb18
bb17:
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = add i64 %t35, 1
  %t38 = sub i64 0, %t36
  %t39 = load i64, ptr %l22, !tbaa !24
  %t41 = icmp sle i64 %t39, %t38
  store i1 %t41, ptr %l21, !tbaa !21
  br label %bb18
bb18:
  %t43 = load i1, ptr %l21, !tbaa !21
  store i1 %t43, ptr %l16, !tbaa !21
  br label %bb19
bb19:
  %t44 = load i1, ptr %l16, !tbaa !21
  store i1 %t44, ptr %rv
  br label %ret
bb20:
  %t45 = load i64, ptr %l0, !tbaa !24
  %t47 = icmp sge i64 %t45, 0
  br i1 %t47, label %bb21, label %bb22
bb21:
  %t49 = load i64, ptr %l2, !tbaa !24
  %t51 = icmp sge i64 %t49, 63
  br i1 %t51, label %bb23, label %bb24
bb22:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb27
bb23:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb26
bb24:
  %t53 = load i64, ptr %l0, !tbaa !24
  store i64 %t53, ptr %l34, !tbaa !24
  %t54 = load i64, ptr %l2, !tbaa !24
  %t56 = call i64 @compiler_2feval_2ebmask(i64 %t54)
  store i64 %t56, ptr %l36
  br label %bb25
bb25:
  %t57 = load i64, ptr %l34, !tbaa !24
  %t58 = load i64, ptr %l36, !tbaa !24
  %t59 = icmp sle i64 %t57, %t58
  store i1 %t59, ptr %l33, !tbaa !21
  br label %bb26
bb26:
  %t61 = load i1, ptr %l33, !tbaa !21
  store i1 %t61, ptr %l30, !tbaa !21
  br label %bb27
bb27:
  %t62 = load i1, ptr %l30, !tbaa !21
  store i1 %t62, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, i64 } @compiler_2feval_2efloatToWide(double %a0) #0 {
entry:
  %l0 = alloca double
  %l1 = alloca i64
  %l2 = alloca i1
  %l4 = alloca i64
  %l7 = alloca { i64, i64 }
  %l8 = alloca i64
  %l9 = alloca i64
  %l12 = alloca i1
  %l24 = alloca double
  %l43 = alloca { i64, i64 }
  %l49 = alloca { i64, i64 }
  %rv = alloca { i64, i64 }
  store double %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load double, ptr %l0, !tbaa !26
  %t3 = fcmp ogt double %t1, 0xc3e0000000000000
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load double, ptr %l0, !tbaa !26
  %t7 = fcmp olt double %t5, 0x43e0000000000000
  store i1 %t7, ptr %l12, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l12, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  %t10 = load double, ptr %l0, !tbaa !26
  %t12 = fptosi double %t10 to i64
  store i64 %t12, ptr %l1, !tbaa !24
  %t14 = load i64, ptr %l1, !tbaa !24
  %t15 = load i64, ptr %l1, !tbaa !24
  %t17 = ashr i64 %t15, 63
  %t19 = insertvalue { i64, i64 } undef, i64 %t14, 0
  %t21 = insertvalue { i64, i64 } %t19, i64 %t17, 1
  store { i64, i64 } %t21, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t23 = load double, ptr %l0, !tbaa !26
  %t25 = fcmp olt double %t23, 0x0000000000000000
  store i1 %t25, ptr %l2, !tbaa !21
  %t27 = load i1, ptr %l2, !tbaa !21
  br i1 %t27, label %bb7, label %bb8
bb7:
  %t29 = load double, ptr %l0, !tbaa !26
  %t31 = fneg double %t29
  store double %t31, ptr %l24, !tbaa !26
  br label %bb9
bb8:
  %t33 = load double, ptr %l0, !tbaa !26
  store double %t33, ptr %l24, !tbaa !26
  br label %bb9
bb9:
  %t35 = load double, ptr %l24, !tbaa !26
  %t38 = bitcast double %t35 to i64
  store i64 %t38, ptr %l4, !tbaa !24
  %t41 = load i64, ptr %l4, !tbaa !24
  %t43 = ashr i64 %t41, 52
  %t45 = and i64 %t43, 2047
  %t47 = sub i64 %t45, 1075
  %t49 = load i64, ptr %l4, !tbaa !24
  %t50 = shl i64 1, 52
  %t52 = sub i64 %t50, 1
  %t55 = and i64 %t49, %t52
  %t56 = shl i64 1, 52
  %t59 = or i64 %t55, %t56
  %t65 = call { i64, i64 } @compiler_2feval_2eshl128(i64 %t59, i64 0, i64 %t47)
  store { i64, i64 } %t65, ptr %l43
  br label %bb10
bb10:
  %t66 = load { i64, i64 }, ptr %l43
  store { i64, i64 } %t66, ptr %l7
  %t67 = getelementptr { i64, i64 }, ptr %l7, i32 0, i32 0
  %t68 = load i64, ptr %t67, !tbaa !24
  store i64 %t68, ptr %l8, !tbaa !24
  %t70 = getelementptr { i64, i64 }, ptr %l7, i32 0, i32 1
  %t71 = load i64, ptr %t70, !tbaa !24
  store i64 %t71, ptr %l9, !tbaa !24
  %t73 = load i1, ptr %l2, !tbaa !21
  br i1 %t73, label %bb11, label %bb12
bb11:
  %t75 = load i64, ptr %l8, !tbaa !24
  %t76 = load i64, ptr %l9, !tbaa !24
  %t79 = call { i64, i64 } @compiler_2feval_2eneg128(i64 %t75, i64 %t76)
  store { i64, i64 } %t79, ptr %l49
  br label %bb13
bb12:
  br label %bb14
bb13:
  %t80 = load { i64, i64 }, ptr %l49
  store { i64, i64 } %t80, ptr %rv
  br label %ret
bb14:
  %t81 = load i64, ptr %l8, !tbaa !24
  %t82 = load i64, ptr %l9, !tbaa !24
  %t84 = insertvalue { i64, i64 } undef, i64 %t81, 0
  %t86 = insertvalue { i64, i64 } %t84, i64 %t82, 1
  store { i64, i64 } %t86, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64 }, ptr %rv
  ret { i64, i64 } %rr
}

define dso_local float @compiler_2feval_2eflushBF16(i16 %a0) #0 {
entry:
  %l0 = alloca i16
  %l3 = alloca i32
  %l7 = alloca i32
  %rv = alloca float
  store i16 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i16, ptr %l0, !tbaa !63
  %t3 = zext i16 %t1 to i32
  %t5 = shl i32 %t3, 16
  store i32 %t5, ptr %l3, !tbaa !64
  %t6 = load i16, ptr %l0, !tbaa !63
  %t8 = and i16 %t6, 32640
  %t10 = icmp eq i16 %t8, 0
  br i1 %t10, label %bb1, label %bb2
bb1:
  store i32 -2147483648, ptr %l7, !tbaa !64
  br label %bb3
bb2:
  store i32 -1, ptr %l7, !tbaa !64
  br label %bb3
bb3:
  %t12 = load i32, ptr %l3, !tbaa !64
  %t13 = load i32, ptr %l7, !tbaa !64
  %t14 = and i32 %t12, %t13
  %t16 = bitcast i32 %t14 to float
  store float %t16, ptr %rv
  br label %ret
ret:
  %rr = load float, ptr %rv
  ret float %rr
}

define dso_local float @compiler_2feval_2eflushF32(float %a0) #0 {
entry:
  %l0 = alloca float
  %l1 = alloca i32
  %l7 = alloca float
  %rv = alloca float
  store float %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load float, ptr %l0, !tbaa !25
  %t3 = bitcast float %t1 to i32
  store i32 %t3, ptr %l1, !tbaa !64
  %t5 = load i32, ptr %l1, !tbaa !64
  %t7 = and i32 %t5, 2139095040
  %t9 = icmp eq i32 %t7, 0
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i32, ptr %l1, !tbaa !64
  %t13 = and i32 %t11, -2147483648
  %t15 = bitcast i32 %t13 to float
  store float %t15, ptr %l7, !tbaa !25
  br label %bb3
bb2:
  %t17 = load float, ptr %l0, !tbaa !25
  store float %t17, ptr %l7, !tbaa !25
  br label %bb3
bb3:
  %t19 = load float, ptr %l7, !tbaa !25
  store float %t19, ptr %rv
  br label %ret
ret:
  %rr = load float, ptr %rv
  ret float %rr
}

define dso_local void @compiler_2feval_2eopFn(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2, i32 %a3, i32 %a4, i1 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i1
  %lp7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca %"compiler/mir:Range"
  %l11 = alloca i32
  %l15 = alloca { i64, ptr }
  %l16 = alloca i32
  %l19 = alloca i32
  %l20 = alloca ptr
  %l21 = alloca i64
  %l25 = alloca i32
  %l26 = alloca %"compiler/mir:Fn"
  %l30 = alloca i32
  %l32 = alloca %"compiler/mir:Range"
  %l33 = alloca ptr
  %l34 = alloca { i64, [4 x i64] }
  %l35 = alloca { i64, [4 x i64] }
  %l36 = alloca { i64, ptr }
  %l37 = alloca %"compiler/mir:Range"
  %l38 = alloca ptr
  %l39 = alloca { i64, [4 x i64] }
  %l40 = alloca { i64, ptr }
  %l41 = alloca %"compiler/mir:Range"
  %l42 = alloca ptr
  %l43 = alloca i32
  %l44 = alloca %"compiler/source:Span"
  %l46 = alloca %"compiler/mir:Lvalue"
  %l51 = alloca { i64, [21 x i64] }
  %l57 = alloca { i64, [21 x i64] }
  %l59 = alloca ptr
  %l60 = alloca i32
  %l61 = alloca %"compiler/source:Span"
  %l63 = alloca %"compiler/mir:Lvalue"
  %l66 = alloca %"compiler/mir:Fn"
  %s0 = alloca %olang.scope
  %t38 = alloca %"compiler/mir:Fn", align 8
  %t97 = alloca { i64, [15 x i64] }, align 8
  %t107 = alloca { i64, [21 x i64] }, align 8
  %t124 = alloca { i64, [21 x i64] }, align 8
  %t141 = alloca { i64, [4 x i64] }, align 8
  %t147 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a3, ptr %l3
  store i32 %a4, ptr %l4
  store i1 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i1, ptr %l5, !tbaa !21
  br i1 %t1, label %bb1, label %bb2
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load i32, ptr %l3, !tbaa !23
  %t5 = load i32, ptr %l3, !tbaa !23
  %t6 = mul i64 2, 4
  %t7 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t6)
  %t8 = insertvalue { i64, ptr } undef, i64 2, 0
  %t9 = insertvalue { i64, ptr } %t8, ptr %t7, 1
  store { i64, ptr } %t9, ptr %l15, !tbaa !27
  %t11 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !27
  %t13 = getelementptr i32, ptr %t12, i64 0
  store i32 %t4, ptr %t13, !tbaa !33
  %t15 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = getelementptr i32, ptr %t16, i64 1
  store i32 %t5, ptr %t17, !tbaa !33
  %t19 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t20 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t3, { i64, ptr } %t19)
  store i32 %t20, ptr %l16
  br label %bb3
bb2:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i32, ptr %l3, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l19
  br label %bb4
bb3:
  %t26 = load i32, ptr %l16, !tbaa !23
  store i32 %t26, ptr %l11, !tbaa !23
  br label %bb5
bb4:
  %t27 = load i32, ptr %l19, !tbaa !23
  store i32 %t27, ptr %l11, !tbaa !23
  br label %bb5
bb5:
  %t28 = load i32, ptr %l11, !tbaa !23
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l20, !tbaa !29
  store i64 %a1, ptr %l21, !tbaa !24
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i32, ptr %l4, !tbaa !23
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t31, i32 %t28, i32 %t33, i32 0, i32 0, i64 0, i1 false, i32 0, i64 0)
  store i32 %t37, ptr %l25
  br label %bb6
bb6:
  %t39 = load ptr, ptr %l20, !tbaa !29
  %t40 = load i64, ptr %l21, !tbaa !24
  %t41 = load i32, ptr %l25, !tbaa !23
  call void @compiler_2feval_2etfn(ptr %t38, ptr %v0, ptr %v1, ptr %t39, i64 %t40, i32 %t41)
  call void @llvm.memmove.p0.p0.i64(ptr %l26, ptr %t38, i64 808, i1 false)
  br label %bb7
bb7:
  %t42 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 808, i64 8)
  store ptr %t42, ptr %lp7
  %t43 = load ptr, ptr %lp7
  call void @llvm.memmove.p0.p0.i64(ptr %t43, ptr %l26, i64 808, i1 false)
  %t44 = load ptr, ptr %lp7
  %t45 = load i32, ptr %l4, !tbaa !23
  %t46 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  %t50 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v1, ptr %t44, i32 %t45, %"compiler/source:Span" %t46)
  store i32 %t50, ptr %l30
  br label %bb8
bb8:
  %t51 = load i32, ptr %l30, !tbaa !23
  store i32 %t51, ptr %l8, !tbaa !23
  %t52 = load i1, ptr %l5, !tbaa !21
  br i1 %t52, label %bb9, label %bb10
bb9:
  %t54 = load ptr, ptr %lp7
  store ptr %t54, ptr %l33, !tbaa !29
  %t55 = call { i64, [4 x i64] } @compiler_2feval_2etcopy(i64 0)
  store { i64, [4 x i64] } %t55, ptr %l34
  br label %bb11
bb10:
  %t56 = load ptr, ptr %lp7
  store ptr %t56, ptr %l38, !tbaa !29
  %t57 = call { i64, [4 x i64] } @compiler_2feval_2etcopy(i64 0)
  store { i64, [4 x i64] } %t57, ptr %l39
  br label %bb14
bb11:
  %t58 = call { i64, [4 x i64] } @compiler_2feval_2etcopy(i64 1)
  store { i64, [4 x i64] } %t58, ptr %l35
  br label %bb12
bb12:
  %t59 = mul i64 2, 40
  %t60 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t59)
  %t61 = insertvalue { i64, ptr } undef, i64 2, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t60, 1
  store { i64, ptr } %t62, ptr %l36, !tbaa !27
  %t63 = load { i64, [4 x i64] }, ptr %l34
  %t64 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = getelementptr { i64, [4 x i64] }, ptr %t65, i64 0
  store { i64, [4 x i64] } %t63, ptr %t66
  %t67 = load { i64, [4 x i64] }, ptr %l35
  %t68 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = getelementptr { i64, [4 x i64] }, ptr %t69, i64 1
  store { i64, [4 x i64] } %t67, ptr %t70
  %t71 = load ptr, ptr %l33, !tbaa !29
  %t72 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t73 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v1, ptr %s0, ptr %t71, { i64, ptr } %t72)
  store %"compiler/mir:Range" %t73, ptr %l37
  br label %bb13
bb13:
  %t74 = load %"compiler/mir:Range", ptr %l37
  store %"compiler/mir:Range" %t74, ptr %l32
  br label %bb16
bb14:
  %t75 = mul i64 1, 40
  %t76 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t75)
  %t77 = insertvalue { i64, ptr } undef, i64 1, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t76, 1
  store { i64, ptr } %t78, ptr %l40, !tbaa !27
  %t79 = load { i64, [4 x i64] }, ptr %l39
  %t80 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = getelementptr { i64, [4 x i64] }, ptr %t81, i64 0
  store { i64, [4 x i64] } %t79, ptr %t82
  %t83 = load ptr, ptr %l38, !tbaa !29
  %t84 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t85 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v1, ptr %s0, ptr %t83, { i64, ptr } %t84)
  store %"compiler/mir:Range" %t85, ptr %l41
  br label %bb15
bb15:
  %t86 = load %"compiler/mir:Range", ptr %l41
  store %"compiler/mir:Range" %t86, ptr %l32
  br label %bb16
bb16:
  %t87 = load %"compiler/mir:Range", ptr %l32
  store %"compiler/mir:Range" %t87, ptr %l9
  %t88 = load ptr, ptr %lp7
  store ptr %t88, ptr %l42, !tbaa !29
  %t89 = load i32, ptr @G_2ecompiler_2feval_2eB0, !tbaa !23
  store i32 %t89, ptr %l43, !tbaa !23
  %t90 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  store %"compiler/source:Span" %t90, ptr %l44
  %t91 = load i32, ptr %l8, !tbaa !23
  %t93 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t91)
  store %"compiler/mir:Lvalue" %t93, ptr %l46
  br label %bb17
bb17:
  %t95 = load i32, ptr %l4, !tbaa !23
  %t96 = load %"compiler/mir:Range", ptr %l9
  store { i64, [15 x i64] } zeroinitializer, ptr %t97
  %t98 = getelementptr { i64, [15 x i64] }, ptr %t97, i32 0, i32 0
  store i64 3, ptr %t98
  %t100 = insertvalue { i32, i32, %"compiler/mir:Range" } undef, i32 %a2, 0
  %t102 = insertvalue { i32, i32, %"compiler/mir:Range" } %t100, i32 %t95, 1
  %t104 = insertvalue { i32, i32, %"compiler/mir:Range" } %t102, %"compiler/mir:Range" %t96, 2
  %t105 = getelementptr { i64, [15 x i64] }, ptr %t97, i32 0, i32 1
  store { i32, i32, %"compiler/mir:Range" } %t104, ptr %t105
  %t106 = load { i64, [15 x i64] }, ptr %t97
  store { i64, [21 x i64] } zeroinitializer, ptr %t107
  %t108 = getelementptr { i64, [21 x i64] }, ptr %t107, i32 0, i32 0
  store i64 0, ptr %t108
  %t109 = load %"compiler/source:Span", ptr %l44
  %t110 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t109, 0
  %t111 = load %"compiler/mir:Lvalue", ptr %l46
  %t112 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t110, %"compiler/mir:Lvalue" %t111, 1
  %t114 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t112, { i64, [15 x i64] } %t106, 2
  %t115 = getelementptr { i64, [21 x i64] }, ptr %t107, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t114, ptr %t115
  %t116 = load { i64, [21 x i64] }, ptr %t107
  store { i64, [21 x i64] } %t116, ptr %l51
  %t117 = load ptr, ptr %l42, !tbaa !29
  %t118 = load i32, ptr %l43, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t117, i32 %t118, ptr %l51)
  br label %bb18
bb18:
  %t120 = load ptr, ptr %lp7
  %t121 = load i32, ptr @G_2ecompiler_2feval_2eB0, !tbaa !23
  %t122 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  %t123 = load i32, ptr @G_2ecompiler_2feval_2eS0, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t124
  %t125 = getelementptr { i64, [21 x i64] }, ptr %t124, i32 0, i32 0
  store i64 4, ptr %t125
  %t127 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t122, 0
  %t129 = insertvalue { %"compiler/source:Span", i32 } %t127, i32 %t123, 1
  %t130 = getelementptr { i64, [21 x i64] }, ptr %t124, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t129, ptr %t130
  %t131 = load { i64, [21 x i64] }, ptr %t124
  store { i64, [21 x i64] } %t131, ptr %l57
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t120, i32 %t121, ptr %l57)
  br label %bb19
bb19:
  %t135 = load ptr, ptr %lp7
  store ptr %t135, ptr %l59, !tbaa !29
  %t136 = load i32, ptr @G_2ecompiler_2feval_2eB0, !tbaa !23
  store i32 %t136, ptr %l60, !tbaa !23
  %t137 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  store %"compiler/source:Span" %t137, ptr %l61
  %t138 = load i32, ptr %l8, !tbaa !23
  %t140 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t138)
  store %"compiler/mir:Lvalue" %t140, ptr %l63
  br label %bb20
bb20:
  store { i64, [4 x i64] } zeroinitializer, ptr %t141
  %t142 = getelementptr { i64, [4 x i64] }, ptr %t141, i32 0, i32 0
  store i64 1, ptr %t142
  %t143 = load %"compiler/mir:Lvalue", ptr %l63
  %t144 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t143, 0
  %t145 = getelementptr { i64, [4 x i64] }, ptr %t141, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t144, ptr %t145
  %t146 = load { i64, [4 x i64] }, ptr %t141
  store { i64, [8 x i64] } zeroinitializer, ptr %t147
  %t148 = getelementptr { i64, [8 x i64] }, ptr %t147, i32 0, i32 0
  store i64 5, ptr %t148
  %t149 = load %"compiler/source:Span", ptr %l61
  %t150 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t149, 0
  %t152 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } %t150, { i64, [4 x i64] } %t146, 1
  %t153 = getelementptr { i64, [8 x i64] }, ptr %t147, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [4 x i64] } } %t152, ptr %t153
  %t154 = load { i64, [8 x i64] }, ptr %t147
  %t155 = load ptr, ptr %l59, !tbaa !29
  %t156 = load i32, ptr %l60, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t155, i32 %t156, { i64, [8 x i64] } %t154)
  br label %bb21
bb21:
  %t158 = load ptr, ptr %lp7
  call void @llvm.memmove.p0.p0.i64(ptr %l66, ptr %t158, i64 808, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l66, i64 808, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local { i64, i64, i64, i64 } @compiler_2feval_2esdivmod128(i64 %a0, i64 %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, i64 }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, i64 }
  %l12 = alloca { i64, i64, i64, i64 }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca { i64, i64 }
  %l18 = alloca { i64, i64 }
  %l28 = alloca { i64, i64 }
  %l36 = alloca { i64, i64 }
  %l43 = alloca { i64, i64, i64, i64 }
  %l53 = alloca { i64, i64 }
  %l59 = alloca { i64, i64 }
  %rv = alloca { i64, i64, i64, i64 }
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  store i1 %t3, ptr %l4, !tbaa !21
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp slt i64 %t5, 0
  store i1 %t7, ptr %l5, !tbaa !21
  %t9 = load i64, ptr %l0, !tbaa !24
  store i64 %t9, ptr %l6, !tbaa !24
  %t11 = load i64, ptr %l1, !tbaa !24
  store i64 %t11, ptr %l7, !tbaa !24
  %t13 = load i1, ptr %l4, !tbaa !21
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = load i64, ptr %l0, !tbaa !24
  %t16 = load i64, ptr %l1, !tbaa !24
  %t19 = call { i64, i64 } @compiler_2feval_2eneg128(i64 %t15, i64 %t16)
  store { i64, i64 } %t19, ptr %l28
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t20 = load { i64, i64 }, ptr %l28
  store { i64, i64 } %t20, ptr %l8
  %t21 = getelementptr { i64, i64 }, ptr %l8, i32 0, i32 0
  %t22 = load i64, ptr %t21, !tbaa !24
  store i64 %t22, ptr %l6, !tbaa !24
  %t24 = getelementptr { i64, i64 }, ptr %l8, i32 0, i32 1
  %t25 = load i64, ptr %t24, !tbaa !24
  store i64 %t25, ptr %l7, !tbaa !24
  br label %bb4
bb4:
  %t27 = load i64, ptr %l2, !tbaa !24
  store i64 %t27, ptr %l9, !tbaa !24
  %t29 = load i64, ptr %l3, !tbaa !24
  store i64 %t29, ptr %l10, !tbaa !24
  %t31 = load i1, ptr %l5, !tbaa !21
  br i1 %t31, label %bb5, label %bb6
bb5:
  %t33 = load i64, ptr %l2, !tbaa !24
  %t34 = load i64, ptr %l3, !tbaa !24
  %t37 = call { i64, i64 } @compiler_2feval_2eneg128(i64 %t33, i64 %t34)
  store { i64, i64 } %t37, ptr %l36
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t38 = load { i64, i64 }, ptr %l36
  store { i64, i64 } %t38, ptr %l11
  %t39 = getelementptr { i64, i64 }, ptr %l11, i32 0, i32 0
  %t40 = load i64, ptr %t39, !tbaa !24
  store i64 %t40, ptr %l9, !tbaa !24
  %t42 = getelementptr { i64, i64 }, ptr %l11, i32 0, i32 1
  %t43 = load i64, ptr %t42, !tbaa !24
  store i64 %t43, ptr %l10, !tbaa !24
  br label %bb8
bb8:
  %t45 = load i64, ptr %l6, !tbaa !24
  %t46 = load i64, ptr %l7, !tbaa !24
  %t47 = load i64, ptr %l9, !tbaa !24
  %t48 = load i64, ptr %l10, !tbaa !24
  %t53 = call { i64, i64, i64, i64 } @compiler_2feval_2eudivmod128(i64 %t45, i64 %t46, i64 %t47, i64 %t48)
  store { i64, i64, i64, i64 } %t53, ptr %l43
  br label %bb9
bb9:
  %t54 = load { i64, i64, i64, i64 }, ptr %l43
  store { i64, i64, i64, i64 } %t54, ptr %l12
  %t55 = getelementptr { i64, i64, i64, i64 }, ptr %l12, i32 0, i32 0
  %t56 = load i64, ptr %t55, !tbaa !24
  store i64 %t56, ptr %l13, !tbaa !24
  %t58 = getelementptr { i64, i64, i64, i64 }, ptr %l12, i32 0, i32 1
  %t59 = load i64, ptr %t58, !tbaa !24
  store i64 %t59, ptr %l14, !tbaa !24
  %t61 = getelementptr { i64, i64, i64, i64 }, ptr %l12, i32 0, i32 2
  %t62 = load i64, ptr %t61, !tbaa !24
  store i64 %t62, ptr %l15, !tbaa !24
  %t64 = getelementptr { i64, i64, i64, i64 }, ptr %l12, i32 0, i32 3
  %t65 = load i64, ptr %t64, !tbaa !24
  store i64 %t65, ptr %l16, !tbaa !24
  %t67 = load i1, ptr %l4, !tbaa !21
  %t68 = load i1, ptr %l5, !tbaa !21
  %t71 = icmp ne i1 %t67, %t68
  br i1 %t71, label %bb10, label %bb11
bb10:
  %t73 = load i64, ptr %l13, !tbaa !24
  %t74 = load i64, ptr %l14, !tbaa !24
  %t77 = call { i64, i64 } @compiler_2feval_2eneg128(i64 %t73, i64 %t74)
  store { i64, i64 } %t77, ptr %l53
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t78 = load { i64, i64 }, ptr %l53
  store { i64, i64 } %t78, ptr %l17
  %t79 = getelementptr { i64, i64 }, ptr %l17, i32 0, i32 0
  %t80 = load i64, ptr %t79, !tbaa !24
  store i64 %t80, ptr %l13, !tbaa !24
  %t82 = getelementptr { i64, i64 }, ptr %l17, i32 0, i32 1
  %t83 = load i64, ptr %t82, !tbaa !24
  store i64 %t83, ptr %l14, !tbaa !24
  br label %bb13
bb13:
  %t85 = load i1, ptr %l4, !tbaa !21
  br i1 %t85, label %bb14, label %bb15
bb14:
  %t87 = load i64, ptr %l15, !tbaa !24
  %t88 = load i64, ptr %l16, !tbaa !24
  %t91 = call { i64, i64 } @compiler_2feval_2eneg128(i64 %t87, i64 %t88)
  store { i64, i64 } %t91, ptr %l59
  br label %bb16
bb15:
  br label %bb17
bb16:
  %t92 = load { i64, i64 }, ptr %l59
  store { i64, i64 } %t92, ptr %l18
  %t93 = getelementptr { i64, i64 }, ptr %l18, i32 0, i32 0
  %t94 = load i64, ptr %t93, !tbaa !24
  store i64 %t94, ptr %l15, !tbaa !24
  %t96 = getelementptr { i64, i64 }, ptr %l18, i32 0, i32 1
  %t97 = load i64, ptr %t96, !tbaa !24
  store i64 %t97, ptr %l16, !tbaa !24
  br label %bb17
bb17:
  %t99 = load i64, ptr %l13, !tbaa !24
  %t100 = load i64, ptr %l14, !tbaa !24
  %t101 = load i64, ptr %l15, !tbaa !24
  %t102 = load i64, ptr %l16, !tbaa !24
  %t104 = insertvalue { i64, i64, i64, i64 } undef, i64 %t99, 0
  %t106 = insertvalue { i64, i64, i64, i64 } %t104, i64 %t100, 1
  %t108 = insertvalue { i64, i64, i64, i64 } %t106, i64 %t101, 2
  %t110 = insertvalue { i64, i64, i64, i64 } %t108, i64 %t102, 3
  store { i64, i64, i64, i64 } %t110, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64, i64, i64 }, ptr %rv
  ret { i64, i64, i64, i64 } %rr
}

define dso_local i64 @compiler_2feval_2ewordValue(i32 %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l39 = alloca i64
  %l45 = alloca i64
  %l51 = alloca i64
  %l57 = alloca i64
  %l63 = alloca i64
  %l67 = alloca i64
  %rv = alloca i64
  store i32 %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !range !{i32 0, i32 54}
  %t3 = trunc i64 3 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t6 = load i64, ptr %l1, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t10 = add i64 %t6, %t7
  store i64 %t10, ptr %l3, !tbaa !24
  br label %bb67
bb4:
  %t12 = load i32, ptr %l0, !range !{i32 0, i32 54}
  %t14 = trunc i64 4 to i32
  %t15 = icmp eq i32 %t12, %t14
  br i1 %t15, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t17 = load i64, ptr %l1, !tbaa !24
  %t18 = load i64, ptr %l2, !tbaa !24
  %t21 = sub i64 %t17, %t18
  store i64 %t21, ptr %l3, !tbaa !24
  br label %bb67
bb8:
  %t23 = load i32, ptr %l0, !range !{i32 0, i32 54}
  %t25 = trunc i64 5 to i32
  %t26 = icmp eq i32 %t23, %t25
  br i1 %t26, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t28 = load i64, ptr %l1, !tbaa !24
  %t29 = load i64, ptr %l2, !tbaa !24
  %t32 = mul i64 %t28, %t29
  store i64 %t32, ptr %l3, !tbaa !24
  br label %bb67
bb12:
  %t34 = load i32, ptr %l0, !range !{i32 0, i32 54}
  %t36 = trunc i64 10 to i32
  %t37 = icmp eq i32 %t34, %t36
  br i1 %t37, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t39 = load i64, ptr %l1, !tbaa !24
  %t40 = load i64, ptr %l2, !tbaa !24
  %t43 = and i64 %t39, %t40
  store i64 %t43, ptr %l3, !tbaa !24
  br label %bb67
bb16:
  %t45 = load i32, ptr %l0, !range !{i32 0, i32 54}
  %t47 = trunc i64 11 to i32
  %t48 = icmp eq i32 %t45, %t47
  br i1 %t48, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t50 = load i64, ptr %l1, !tbaa !24
  %t51 = load i64, ptr %l2, !tbaa !24
  %t54 = or i64 %t50, %t51
  store i64 %t54, ptr %l3, !tbaa !24
  br label %bb67
bb20:
  %t56 = load i32, ptr %l0, !range !{i32 0, i32 54}
  %t58 = trunc i64 12 to i32
  %t59 = icmp eq i32 %t56, %t58
  br i1 %t59, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  %t61 = load i64, ptr %l1, !tbaa !24
  %t62 = load i64, ptr %l2, !tbaa !24
  %t65 = xor i64 %t61, %t62
  store i64 %t65, ptr %l3, !tbaa !24
  br label %bb67
bb24:
  %t67 = load i32, ptr %l0, !range !{i32 0, i32 54}
  %t69 = trunc i64 13 to i32
  %t70 = icmp eq i32 %t67, %t69
  br i1 %t70, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb31
bb27:
  %t72 = load i64, ptr %l1, !tbaa !24
  %t73 = load i64, ptr %l2, !tbaa !24
  %t76 = icmp eq i64 %t72, %t73
  br i1 %t76, label %bb28, label %bb29
bb28:
  store i64 1, ptr %l39, !tbaa !24
  br label %bb30
bb29:
  store i64 0, ptr %l39, !tbaa !24
  br label %bb30
bb30:
  %t78 = load i64, ptr %l39, !tbaa !24
  store i64 %t78, ptr %l3, !tbaa !24
  br label %bb67
bb31:
  %t79 = load i32, ptr %l0, !range !{i32 0, i32 54}
  %t81 = trunc i64 14 to i32
  %t82 = icmp eq i32 %t79, %t81
  br i1 %t82, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb38
bb34:
  %t84 = load i64, ptr %l1, !tbaa !24
  %t85 = load i64, ptr %l2, !tbaa !24
  %t88 = icmp ne i64 %t84, %t85
  br i1 %t88, label %bb35, label %bb36
bb35:
  store i64 1, ptr %l45, !tbaa !24
  br label %bb37
bb36:
  store i64 0, ptr %l45, !tbaa !24
  br label %bb37
bb37:
  %t90 = load i64, ptr %l45, !tbaa !24
  store i64 %t90, ptr %l3, !tbaa !24
  br label %bb67
bb38:
  %t91 = load i32, ptr %l0, !range !{i32 0, i32 54}
  %t93 = trunc i64 15 to i32
  %t94 = icmp eq i32 %t91, %t93
  br i1 %t94, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb45
bb41:
  %t96 = load i64, ptr %l1, !tbaa !24
  %t97 = load i64, ptr %l2, !tbaa !24
  %t100 = icmp slt i64 %t96, %t97
  br i1 %t100, label %bb42, label %bb43
bb42:
  store i64 1, ptr %l51, !tbaa !24
  br label %bb44
bb43:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb44
bb44:
  %t102 = load i64, ptr %l51, !tbaa !24
  store i64 %t102, ptr %l3, !tbaa !24
  br label %bb67
bb45:
  %t103 = load i32, ptr %l0, !range !{i32 0, i32 54}
  %t105 = trunc i64 16 to i32
  %t106 = icmp eq i32 %t103, %t105
  br i1 %t106, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb52
bb48:
  %t108 = load i64, ptr %l1, !tbaa !24
  %t109 = load i64, ptr %l2, !tbaa !24
  %t112 = icmp sle i64 %t108, %t109
  br i1 %t112, label %bb49, label %bb50
bb49:
  store i64 1, ptr %l57, !tbaa !24
  br label %bb51
bb50:
  store i64 0, ptr %l57, !tbaa !24
  br label %bb51
bb51:
  %t114 = load i64, ptr %l57, !tbaa !24
  store i64 %t114, ptr %l3, !tbaa !24
  br label %bb67
bb52:
  %t115 = load i32, ptr %l0, !range !{i32 0, i32 54}
  %t117 = trunc i64 17 to i32
  %t118 = icmp eq i32 %t115, %t117
  br i1 %t118, label %bb53, label %bb54
bb53:
  br label %bb55
bb54:
  br label %bb59
bb55:
  %t120 = load i64, ptr %l1, !tbaa !24
  %t121 = load i64, ptr %l2, !tbaa !24
  %t124 = icmp sgt i64 %t120, %t121
  br i1 %t124, label %bb56, label %bb57
bb56:
  store i64 1, ptr %l63, !tbaa !24
  br label %bb58
bb57:
  store i64 0, ptr %l63, !tbaa !24
  br label %bb58
bb58:
  %t126 = load i64, ptr %l63, !tbaa !24
  store i64 %t126, ptr %l3, !tbaa !24
  br label %bb67
bb59:
  br i1 true, label %bb60, label %bb61
bb60:
  br label %bb62
bb61:
  br label %bb66
bb62:
  %t127 = load i64, ptr %l1, !tbaa !24
  %t128 = load i64, ptr %l2, !tbaa !24
  %t131 = icmp sge i64 %t127, %t128
  br i1 %t131, label %bb63, label %bb64
bb63:
  store i64 1, ptr %l67, !tbaa !24
  br label %bb65
bb64:
  store i64 0, ptr %l67, !tbaa !24
  br label %bb65
bb65:
  %t133 = load i64, ptr %l67, !tbaa !24
  store i64 %t133, ptr %l3, !tbaa !24
  br label %bb67
bb66:
  call void @__olang_check_failed(ptr @olang_loc_fe51c7873558f7ce_2759982fc28bb82a)
  unreachable
bb67:
  %t134 = load i64, ptr %l3, !tbaa !24
  store i64 %t134, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2feval_3agenRec_2ector(ptr %out, ptr %v0) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca %"compiler/eval:frame"
  %l3 = alloca i64
  %l4 = alloca %"compiler/eval:Ptr"
  %l5 = alloca i1
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca %"compiler/eval:frame"
  %l14 = alloca i64
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca i64
  %l20 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l22 = alloca %"compiler/eval:genRec"
  %t1 = alloca %"compiler/eval:frame", align 8
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l0, !tbaa !24
  store i64 0, ptr %l1, !tbaa !24
  call void @compiler_2feval_3aframe_2ector(ptr %t1, ptr %v0)
  call void @llvm.memmove.p0.p0.i64(ptr %l12, ptr %t1, i64 136, i1 false)
  br label %bb1
bb1:
  call void @llvm.memmove.p0.p0.i64(ptr %l2, ptr %l12, i64 136, i1 false)
  store i64 -1, ptr %l3, !tbaa !24
  %t2 = load %"compiler/eval:Ptr", ptr @G_2ecompiler_2feval_2eNullPtr
  store %"compiler/eval:Ptr" %t2, ptr %l4
  store i1 false, ptr %l5, !tbaa !21
  %t4 = call ptr @__olang_scope_hold(ptr %v0)
  %t5 = ptrtoint ptr %t4 to i64
  store i64 %t5, ptr %l14, !tbaa !24
  %t6 = load i1, ptr @olang_2esole_2ecompiler_2feval_3agenRec_2e6
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t8 = call ptr @__olang_region_make(ptr %v0)
  %t9 = ptrtoint ptr %t8 to i64
  store i64 %t9, ptr %l14, !tbaa !24
  br label %bb3
bb3:
  %t10 = load i64, ptr %l14
  %t11 = inttoptr i64 %t10 to ptr
  %t12 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t11, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t12, ptr %l16
  br label %bb4
bb4:
  %t13 = load i1, ptr @olang_2esole_2ecompiler_2feval_3agenRec_2e6
  br i1 %t13, label %bb5, label %bb6
bb5:
  %t15 = load i64, ptr %l14
  %t16 = inttoptr i64 %t15 to ptr
  %t17 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16, i32 0, i32 0
  %t18 = load { i64, ptr }, ptr %t17
  %t19 = extractvalue { i64, ptr } %t18, 1
  %t20 = call ptr @__olang_region_or(ptr %t19, ptr null)
  %t21 = call ptr @__olang_region_home(ptr %t20)
  %t22 = icmp ne ptr %t21, null
  %t23 = select i1 %t22, ptr %t21, ptr null
  call void @__olang_region_settle_in(ptr %t16, ptr %t23)
  br label %bb6
bb6:
  %t24 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %l6
  %t25 = call ptr @__olang_scope_hold(ptr %v0)
  %t26 = ptrtoint ptr %t25 to i64
  store i64 %t26, ptr %l18, !tbaa !24
  %t27 = load i1, ptr @olang_2esole_2ecompiler_2feval_3agenRec_2e7
  br i1 %t27, label %bb7, label %bb8
bb7:
  %t29 = call ptr @__olang_region_make(ptr %v0)
  %t30 = ptrtoint ptr %t29 to i64
  store i64 %t30, ptr %l18, !tbaa !24
  br label %bb8
bb8:
  %t31 = load i64, ptr %l18
  %t32 = inttoptr i64 %t31 to ptr
  %t33 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t32, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t33, ptr %l20
  br label %bb9
bb9:
  %t34 = load i1, ptr @olang_2esole_2ecompiler_2feval_3agenRec_2e7
  br i1 %t34, label %bb10, label %bb11
bb10:
  %t36 = load i64, ptr %l18
  %t37 = inttoptr i64 %t36 to ptr
  %t38 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l20, i32 0, i32 0
  %t39 = load { i64, ptr }, ptr %t38
  %t40 = extractvalue { i64, ptr } %t39, 1
  %t41 = call ptr @__olang_region_or(ptr %t40, ptr null)
  %t42 = call ptr @__olang_region_home(ptr %t41)
  %t43 = icmp ne ptr %t42, null
  %t44 = select i1 %t43, ptr %t42, ptr null
  call void @__olang_region_settle_in(ptr %t37, ptr %t44)
  br label %bb11
bb11:
  %t45 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l20
  %t46 = getelementptr %"compiler/eval:genRec", ptr %l22, i32 0, i32 0
  %t47 = load i64, ptr %l0, !tbaa !24
  store i64 %t47, ptr %t46, !tbaa !24
  %t48 = getelementptr %"compiler/eval:genRec", ptr %l22, i32 0, i32 1
  %t49 = load i64, ptr %l1, !tbaa !24
  store i64 %t49, ptr %t48, !tbaa !24
  %t50 = getelementptr %"compiler/eval:genRec", ptr %l22, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %t50, ptr %l2, i64 136, i1 false)
  %t51 = getelementptr %"compiler/eval:genRec", ptr %l22, i32 0, i32 3
  %t52 = load i64, ptr %l3, !tbaa !24
  store i64 %t52, ptr %t51, !tbaa !24
  %t53 = getelementptr %"compiler/eval:genRec", ptr %l22, i32 0, i32 4
  %t54 = load %"compiler/eval:Ptr", ptr %l4
  store %"compiler/eval:Ptr" %t54, ptr %t53
  %t55 = getelementptr %"compiler/eval:genRec", ptr %l22, i32 0, i32 5
  %t56 = load i1, ptr %l5, !tbaa !21
  store i1 %t56, ptr %t55, !tbaa !21
  %t57 = getelementptr %"compiler/eval:genRec", ptr %l22, i32 0, i32 6
  %t58 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t58, ptr %t57
  %t59 = getelementptr %"compiler/eval:genRec", ptr %l22, i32 0, i32 7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t45, ptr %t59
  %t61 = getelementptr %"compiler/eval:genRec", ptr %l22, i32 0, i32 8
  store i64 -1, ptr %t61, !tbaa !24
  %t63 = getelementptr %"compiler/eval:genRec", ptr %l22, i32 0, i32 9
  store i64 0, ptr %t63, !tbaa !24
  %t65 = getelementptr %"compiler/eval:genRec", ptr %l22, i32 0, i32 10
  store i64 0, ptr %t65, !tbaa !24
  %t67 = getelementptr %"compiler/eval:genRec", ptr %l22, i32 0, i32 11
  store i64 -1, ptr %t67, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l22, i64 280, i1 false)
  br label %ret
ret:
  ret void
}

@__olang_prog_scope = external thread_local(initialexec) global ptr
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define linkonce_odr void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feval_3aBlob(ptr %out, ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/eval:Blob"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %a0, i64 272, i1 false)
  %t2 = getelementptr %"compiler/eval:Blob", ptr %l1, i32 0, i32 0
  %t4 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cU8_3e(ptr %v0, ptr %t2)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t6 = getelementptr %"compiler/eval:Blob", ptr %l1, i32 0, i32 0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %t6
  %t7 = getelementptr %"compiler/eval:Blob", ptr %l1, i32 0, i32 3
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t7)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l5
  br label %bb2
bb2:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  %t11 = getelementptr %"compiler/eval:Blob", ptr %l1, i32 0, i32 3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %t11
  %t12 = getelementptr %"compiler/eval:Blob", ptr %l1, i32 0, i32 4
  %t14 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t12)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l7
  br label %bb3
bb3:
  %t15 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  %t16 = getelementptr %"compiler/eval:Blob", ptr %l1, i32 0, i32 4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %t16
  %t17 = getelementptr %"compiler/eval:Blob", ptr %l1, i32 0, i32 5
  %t19 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t17)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l9
  br label %bb4
bb4:
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  %t21 = getelementptr %"compiler/eval:Blob", ptr %l1, i32 0, i32 5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %t21
  %t22 = getelementptr %"compiler/eval:Blob", ptr %l1, i32 0, i32 6
  %t24 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t22)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %l11
  br label %bb5
bb5:
  %t25 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  %t26 = getelementptr %"compiler/eval:Blob", ptr %l1, i32 0, i32 6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %t26
  %t27 = getelementptr %"compiler/eval:Blob", ptr %l1, i32 0, i32 7
  %t29 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t27)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t29, ptr %l13
  br label %bb6
bb6:
  %t30 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  %t31 = getelementptr %"compiler/eval:Blob", ptr %l1, i32 0, i32 7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t30, ptr %t31
  %t32 = getelementptr %"compiler/eval:Blob", ptr %l1, i32 0, i32 8
  %t34 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t32)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t34, ptr %l15
  br label %bb7
bb7:
  %t35 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  %t36 = getelementptr %"compiler/eval:Blob", ptr %l1, i32 0, i32 8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t35, ptr %t36
  %t37 = getelementptr %"compiler/eval:Blob", ptr %l1, i32 0, i32 9
  %t39 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t37)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t39, ptr %l17
  br label %bb8
bb8:
  %t40 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  %t41 = getelementptr %"compiler/eval:Blob", ptr %l1, i32 0, i32 9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t40, ptr %t41
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l1, i64 272, i1 false)
  br label %ret
ret:
  ret void
}

define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@.d0 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d1 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d2 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @__olang_check_failed(ptr) cold noreturn
@__olang_empty_array = external constant [16 x i64]
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0 = weak hidden constant i1 false
declare ptr @__olang_region_make_part(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare ptr @__olang_region_or(ptr, ptr)
declare void @__olang_region_settle_in(ptr, ptr)
define linkonce_odr void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feval_3agenRec(ptr %out, ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/eval:genRec"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %a0, i64 280, i1 false)
  %t2 = getelementptr %"compiler/eval:genRec", ptr %l1, i32 0, i32 6
  %t4 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t2)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t6 = getelementptr %"compiler/eval:genRec", ptr %l1, i32 0, i32 6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %t6
  %t7 = getelementptr %"compiler/eval:genRec", ptr %l1, i32 0, i32 7
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t7)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l5
  br label %bb2
bb2:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  %t11 = getelementptr %"compiler/eval:genRec", ptr %l1, i32 0, i32 7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %t11
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l1, i64 280, i1 false)
  br label %ret
ret:
  ret void
}

declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@olang_2esole_2ecompiler_2feval_3aMachine_2e61 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
declare void @__olang_region_release(ptr) noinline
@olang_2esole_2ecompiler_2feval_3aMachine_2e59 = weak hidden constant i1 false
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
define linkonce_odr void @olang_2emir_2eHelperKind_2eZero_2ecompiler_2feval_3aframe(ptr %out) #0 {
entry:
  %l0 = alloca %"compiler/eval:frame"
  %t1 = alloca %"compiler/eval:frame", align 8
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_3aframe_2ector(ptr %t1, ptr %t2)
  call void @llvm.memmove.p0.p0.i64(ptr %l0, ptr %t1, i64 136, i1 false)
  br label %bb1
bb1:
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l0, i64 136, i1 false)
  br label %ret
ret:
  ret void
}

@.d3 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d4 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"true" }>, align 8
@.d5 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"false" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
declare i64 @__olang_fmt_u64(ptr, i64)
@olang_2esole_2ecompiler_2feval_3aSnapshot_2e5 = weak hidden constant i1 false
declare ptr @__olang_region_home(ptr)
declare void @__olang_region_drop(ptr) noinline
@olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e0 = weak hidden constant i1 false
declare void @__olang_region_release_part(ptr, i64) noinline
@olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e1 = weak hidden constant i1 false
@olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e2 = weak hidden constant i1 false
@.d6 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d7 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"an error escapes, code " }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d8 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d9 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d10 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d11 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d12 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d13 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d14 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d15 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d16 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d17 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@olang_2esole_2ecompiler_2feval_3agenRec_2e6 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2feval_3agenRec_2e7 = weak hidden constant i1 false
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cU8_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 1
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 4
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
@G_2ecompiler_2feval_2eslotMask = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2eaFree = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2erelease(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2feval_2eNullPtr = available_externally constant <{ [16 x i8] }> <{ [16 x i8] c"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare %"compiler/eval:gkey" @compiler_2feval_3agkey_2ector(ptr %v0, i64 %a0, i32 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2feval_3agkey_2c_20I64_3e_2eG_H841bd46d30f67641fdfac3080f15aea1(ptr %v0, ptr %a0, %"compiler/eval:gkey" %a1)
@G_2ecompiler_2feval_2eWhyNoBody = external constant <{ [8 x i8], ptr }>
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/eval:global" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2eAt_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2feval_2eWhyMutableGlobal = external constant <{ [8 x i8], ptr }>
@G_2ecompiler_2feval_2eWhyChangeable = external constant <{ [8 x i8], ptr }>
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2estartGlobal(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eloop(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eunwind(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2feval_2eWhyDestructor = external constant <{ [8 x i8], ptr }>
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2feval_2eaValue = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eallocate(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3)
declare %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %v0, i64 %a0, i64 %a1)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2ecopy(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, %"compiler/eval:Ptr" %a2, i64 %a3)
declare %"compiler/eval:Image" @compiler_2feval_3aImage_2ector(ptr %v0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2feval_3aBlob_2ector(ptr %out, ptr %v0)
@G_2ecompiler_2feval_2eaData = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAlign(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erdRaw(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2ePush_3cU8_3e(ptr %v0, ptr %a0, i8 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eSetAt_3cU8_3e(ptr %v0, ptr %a0, i64 %a1, i8 %a2)
@G_2ecompiler_2feval_2eslotBits = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\18\00\00\00\00\00\00\00" }>, align 8
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aBlob_3e_2ePush_3ccompiler_2feval_3aBlob_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aBlob_3e_2eAt_3ccompiler_2feval_3aBlob_3e(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aBlob_3e_2eRefMut_3ccompiler_2feval_3aBlob_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2efnIndex(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_26_3e_2eAt_3ccompiler_2fmir_3aFn_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eLen_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eRef_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2fmir_2ecompiler_2fmir_3aStmtList_2eLen(ptr %v0, ptr %a0)
declare { i64, [21 x i64] } @compiler_2fmir_2ecompiler_2fmir_3aStmtList_2eAt(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { { i64, ptr }, %"compiler/source:Span" } @compiler_2feval_2ecompiler_2feval_3aMachine_2ewhyTerm(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, [8 x i64] } %a2, ptr %a3, ptr %a4)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnchors(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_1af190ed0f8ad609_3dab539ded9f1c85 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2ePush_3cArray_3cI64_3e_3e(ptr %v0, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2eLen_3cArray_3cI64_3e_3e(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2eAt_3cArray_3cI64_3e_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2epartOffset(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2epartType(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eobjectAt(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, i32 %a2)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eregionOfObject(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1)
@olang_loc_317a6a00a16cca58_813a0e779d592254 = external constant [0 x i8]
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eappendByte(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare ptr @compiler_2feval_2ecompiler_2feval_3aMachine_2efnOfFrame(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2ejump(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@G_2ecompiler_2fmir_2eNoBlock = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2feval_2eWhyNotModelled = external constant <{ [8 x i8], ptr }>
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2ecalleeType(ptr %v0, ptr %a0, i64 %a1, { i64, [7 x i64] } %a2)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erecode(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i32 %a3)
declare %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2elocalPtr(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, i64 %a2, i64 %a3)
@G_2ecompiler_2feval_2etCall = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2efailedHere(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3agenRec_3e_2eAt_3ccompiler_2feval_3agenRec_3e(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3agenRec_3e_2eRefMut_3ccompiler_2feval_3agenRec_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2efreshDrops(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
@G_2ecompiler_2feval_2erDtor = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2ecodePtr(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrPtr(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, %"compiler/eval:Ptr" %a2)
@olang_loc_858a31b75d933e1b_7873e096df41decf = external constant [0 x i8]
declare { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eopType(ptr %v0, ptr %a0, i64 %a1, { i64, [4 x i64] } %a2)
declare { { i64, ptr }, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2epack(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ebuildScope(ptr %v0, ptr %a0, i64 %a1, { i64, [1 x i64] } %a2)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eput(ptr %v0, ptr %a0, i64 %a1, %"compiler/eval:Ptr" %a2, i32 %a3, { i64, [4 x i64] } %a4)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2feval_2evPtr = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2evPair = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtr(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %out, ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/eval:reg" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3areg_3e_2eAt_3ccompiler_2feval_3areg_3e(ptr %v0, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eRefMut_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/eval:task" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3atask_3e_2eAt_3ccompiler_2feval_3atask_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eSetAt_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %a0, i64 %a1, ptr %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e_2eAt_3ccompiler_2fmir_3aTask_3e(ptr %out, ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2feval_2efastStride = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\0B\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2efStore = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
declare { %"compiler/eval:Ptr", i32 } @compiler_2feval_2ecompiler_2feval_3aMachine_2eelement(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, i32 %a2, i64 %a3)
@G_2ecompiler_2feval_2efCopy = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2efConst = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2efLoad = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, i64 %a2)
@G_2ecompiler_2feval_2efUn = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eunary(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i32 %a3, i64 %a4)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2enumOp(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i64 %a3, i32 %a4, i32 %a5, i64 %a6)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2elocalAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3, i1 %a4)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eunmark(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrRaw(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewidth(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintValue(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i64 @compiler_2feval_2eplainLocal(%"compiler/mir:Lvalue" %a0)
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eAt_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eelemOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2enumber(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eflatOperand(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, [4 x i64] } %a2, ptr %a3, i64 %a4, i64 %a5)
@olang_loc_b3c5db2f6a543f4f_ebedfa57413dac3 = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eRemove_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3agenRec_3e_2eSetAt_3ccompiler_2feval_3agenRec_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3agenRec_3e_2ePush_3ccompiler_2feval_3agenRec_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3agenRec_3e_2eLen_3ccompiler_2feval_3agenRec_3e(ptr %v0, ptr %a0)
@G_2ecompiler_2feval_2egGen = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddReg(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3, %"compiler/eval:Ptr" %a4)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eHoldsGen(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare { %"compiler/eval:Ptr", i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2earrayView(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, i32 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fmir_2eHasFields(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2epartList(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eWeakField(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, i64 %a3)
declare i1 @compiler_2fmir_2eHasCases(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2epayloadType(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eibits(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2feval_2evInt = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2feval_2ebmask(i64 %a0)
declare i64 @compiler_2feval_2eminBits(i64 %a0)
@G_2ecompiler_2feval_2eWhyDivZero = external constant <{ [8 x i8], ptr }>
@G_2ecompiler_2feval_2eWhyDivMin = external constant <{ [8 x i8], ptr }>
@G_2ecompiler_2feval_2evUint = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2eWhyShift = external constant <{ [8 x i8], ptr }>
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2enotModelled(ptr %v0, ptr %a0)
@olang_loc_cc4a112acbde7ca1_19be4f90a96d28f5 = external constant [0 x i8]
declare { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %a0, i64 %a1, %"compiler/mir:Range" %a2, i64 %a3)
declare %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddr(ptr %v0, ptr %a0, i64 %a1, { i64, [4 x i64] } %a2, i64 %a3)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %a0, i64 %a1, { i64, [4 x i64] } %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/eval:task" @compiler_2feval_3atask_2ector(ptr %v0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3atask_3e_2ePush_3ccompiler_2feval_3atask_3e(ptr %v0, ptr %a0, %"compiler/eval:task" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3atask_3e_2eLen_3ccompiler_2feval_3atask_3e(ptr %v0, ptr %a0)
@G_2ecompiler_2feval_2evFloat = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
declare double @compiler_2feval_2ecompiler_2feval_3aMachine_2etoF64(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i1 @compiler_2feval_2efloatFits(double %a0, i64 %a1, i1 %a2)
@olang_loc_63a030dc495bebe2_de58b898255fa7b6 = external constant [0 x i8]
declare i1 @compiler_2feval_2eoverflows64(i32 %a0, i64 %a1, i64 %a2, i1 %a3)
@olang_loc_ffc454b782ecc9e3_c14f69603a3a3b57 = external constant [0 x i8]
declare float @std_2fprelude_2fnumber_2eF32_2eFma_3cF32_3e(float %a0, float %a1, float %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eLen_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %a0)
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eAt_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_6e4848ba4497940f_2fc0910286fcd483 = external constant [0 x i8]
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %a0)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escopeOf(ptr %v0, ptr %a0, i64 %a1, { i64, [1 x i64] } %a2)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %a0, i32 %a1)
declare { i64, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2ewideOf(ptr %v0, ptr %a0, i64 %a1, { i64, [4 x i64] } %a2)
@G_2ecompiler_2feval_2eWhyConvert = external constant <{ [8 x i8], ptr }>
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eputInt(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, i32 %a2, i64 %a3, i64 %a4)
declare { i64, i64 } @compiler_2feval_2eneg128(i64 %a0, i64 %a1)
declare { i64, i64 } @compiler_2feval_2eextend128(i64 %a0, i64 %a1, i64 %a2, i1 %a3)
declare i64 @compiler_2feval_2elz128(i64 %a0, i64 %a1, i64 %a2)
declare { i64, i64 } @compiler_2feval_2eshr128(i64 %a0, i64 %a1, i64 %a2, i1 %a3)
declare { i64, i64 } @compiler_2feval_2eshl128(i64 %a0, i64 %a1, i64 %a2)
@olang_loc_90562c53bc58bb00_b398839a3bffbdf4 = external constant [0 x i8]
declare { i64, i64 } @compiler_2feval_2eadd128(i64 %a0, i64 %a1, i64 %a2, i64 %a3)
declare { i64, i64 } @compiler_2feval_2esub128(i64 %a0, i64 %a1, i64 %a2, i64 %a3)
declare { i64, i64 } @compiler_2feval_2emul128(i64 %a0, i64 %a1, i64 %a2, i64 %a3)
declare { i64, i64 } @compiler_2feval_2ewideMin(i64 %a0)
declare { i64, i64, i64, i64 } @compiler_2feval_2eudivmod128(i64 %a0, i64 %a1, i64 %a2, i64 %a3)
declare i1 @compiler_2feval_2eult64(i64 %a0, i64 %a1)
declare i64 @compiler_2feval_2ecmp128(i64 %a0, i64 %a1, i64 %a2, i64 %a3, i1 %a4)
@olang_loc_124d877554f39b91_abf5664d02ded825 = external constant [0 x i8]
@olang_loc_e0c215207c57b9fa_758d150e3c60fc6e = external constant [0 x i8]
declare i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2emutableGlobal(ptr %v0, ptr %a0, %"compiler/mir:Lvalue" %a1)
@olang_loc_4b87b113311cbcf6_8401054b0e12d93a = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_Hb3133f486435530b533aaf49461c92b5(ptr %v0, ptr %a0, i32 %a1)
declare { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_H257d83b06934604763b32ef91c51c1d2(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_H64d9be73b6c9bed004c541bdf7f0ca0a(ptr %v0, ptr %a0, i32 %a1, i1 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_a8af958fc51ac952_dd02768cc282434e = external constant [0 x i8]
@olang_loc_5132488ea4d5a24a_c872bd4e98b932a6 = external constant [0 x i8]
declare i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2elive(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2feval_2esRegion = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2eWhyDepth = external constant <{ [8 x i8], ptr }>
@G_2ecompiler_2feval_2eWhyRunDepth = external constant <{ [8 x i8], ptr }>
@olang_loc_82f264fd3f63866e_1586045834f1f9b2 = external constant [0 x i8]
@olang_loc_9faf736d233c85e3_6ce3cec307115a7 = external constant [0 x i8]
@G_2ecompiler_2feval_2erCall = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2erRequest = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2estop(ptr %v0, ptr %v1, ptr %a0, { i64, [5 x i64] } %a1)
declare i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewalksLetGo(ptr %v0, ptr %a0)
@G_2ecompiler_2feval_2eWhyWalkLetGo = external constant <{ [8 x i8], ptr }>
@G_2ecompiler_2feval_2erGlobal = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2eWhyNoValue = external constant <{ [8 x i8], ptr }>
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2eRefMut_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@G_2ecompiler_2feval_2erTask = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2etaskEnded(ptr %v0, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2feval_2erClause = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2efreeTask(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_cf5f350672f7c138_c751ad896f9a9f0c = external constant [0 x i8]
@G_2ecompiler_2feval_2eWhyClosed = external constant <{ [8 x i8], ptr }>
declare { { i64, ptr }, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2etaskLayout(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i64 %a3)
declare %"compiler/mir:Lvalue" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLvalue_3e_2eAt_3ccompiler_2fmir_3aLvalue_3e(ptr %v0, ptr %a0, i64 %a1)
declare { %"compiler/eval:Ptr", i32 } @compiler_2feval_2ecompiler_2feval_3aMachine_2eplace(ptr %v0, ptr %a0, i64 %a1, %"compiler/mir:Lvalue" %a2)
declare %"compiler/mir:TaskClause" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTaskClause_3e_2eAt_3ccompiler_2fmir_3aTaskClause_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_c730e5cddf41927a_cc9c5d5e6e4d10a6 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3atask_3e_2eSetAt_3ccompiler_2feval_3atask_3e(ptr %v0, ptr %a0, i64 %a1, %"compiler/eval:task" %a2)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3atask_3e_2eRefMut_3ccompiler_2feval_3atask_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@G_2ecompiler_2feval_2eaCode = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
declare { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2eAt_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_ab5609012e755c90_cedd2fbfe92d4e64 = external constant [0 x i8]
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2epushFrame(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eownParams(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@olang_loc_f6d4fb7f4fd95721_139ddd7815176855 = external constant [0 x i8]
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eloadCaptures(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, %"compiler/eval:Ptr" %a3, i64 %a4)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eunlinkReg(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2feval_2egDtor = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2erunDtor(ptr %v0, ptr %a0, i64 %a1, i32 %a2, %"compiler/eval:Ptr" %a3)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3areg_3e_2eRefMut_3ccompiler_2feval_3areg_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2feval_2eplaceNamesGlobal(%"compiler/mir:Lvalue" %a0)
@G_2ecompiler_2feval_2eWhyWritesGlobalVar = external constant <{ [8 x i8], ptr }>
@olang_loc_14e567516c3eb5fb_1379a201658fd827 = external constant [0 x i8]
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintToFloat(ptr %v0, ptr %a0, i64 %a1, i1 %a2, i32 %a3)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2efromF64(ptr %v0, ptr %a0, double %a1, i32 %a2)
@G_2ecompiler_2feval_2evWide = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\0D\00\00\00\00\00\00\00" }>, align 8
declare { i64, ptr } @compiler_2feval_2ewideText(ptr %v0, i64 %a0, i64 %a1, i1 %a2)
declare { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2efloatText(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
@olang_loc_8ccc3ef59c04d332_c9a1f89b24f6a8f6 = external constant [0 x i8]
declare i8 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eAt_3cU8_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2eAt_3cI32_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aConstNode_3e_2eAt_3ccompiler_2fmir_3aConstNode_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_3aba056b97310e62_2c3874c5956ac10e = external constant [0 x i8]
@G_2ecompiler_2feval_2evFixed = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\0B\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2econstLen(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [1 x i64] } %a2)
declare %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eIter_3cI64_2c_20I64_3e(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3cI64_2c_20I64_3e_2eNext_3cI64_2c_20I64_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2fmir_2eColumned(i32 %a0)
declare { i32, i32 } @compiler_2fsource_2ecompiler_2fsource_3aSource_2eLineCol(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fmir_2eExitText(ptr %v0, i32 %a0)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aSource_2eLine(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_e6861b790824244d_fbaf0ff74301c89 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5, i1 %a6, i32 %a7, i64 %a8)
declare void @compiler_2feval_2etfn(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
@G_2ecompiler_2feval_2eSp0 = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare { i64, [4 x i64] } @compiler_2feval_2etcopy(i64 %a0)
declare %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2feval_2eB0 = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %a0)
declare void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
@G_2ecompiler_2feval_2eS0 = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v0, ptr %a0, i32 %a1, { i64, [8 x i64] } %a2)
@olang_loc_fe51c7873558f7ce_2759982fc28bb82a = external constant [0 x i8]
declare void @compiler_2feval_3aframe_2ector(ptr %out, ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
